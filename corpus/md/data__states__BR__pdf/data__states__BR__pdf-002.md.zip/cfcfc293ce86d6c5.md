---
doc_id: "cfcfc293ce86d6c5"
source_url: "https://dbtagriculture.bihar.gov.in/Instructions/AdvertisementforLogoDesignBRJM_Final.pdf"
ministry: "Direct Benefit Transfer (DBT), Agriculture Department, Bihar"
title: "बिहार राज्य जैविक मिशन के लिए लोगो डिजाईन एवं tagline कांटेस्ट"
date: ""
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "74bfb09c5daea673"
---

<!-- page 1 -->

DIRECTORATE OF AGRICULTURE
GOVERNMENT OF BIHAR
VIKAS BHAWAN, BAILEY ROAD PATNA

LOGO DESIGN CONTEST BEING ORGANIZED BY THE DIRECTORATE OF
AGRICULTURE, DEPARTMENT OF AGRICULTURE, GOVT. OF BIHAR
CONTEST: 1
Directorate of Agriculture, Government of Bihar is the nodal agency to promote Organic Farming in the
State. The Directorate has created a separate entity Bihar Rajya Jaivik Mission to have a comprehensive
approach towards promoting Organic Farming with a vision of making it a role model for the World.
Currently, a Jaivik Corridor Scheme has been launched in 13 districts on the bank of Ganges as a pilot
project and the same is going to be replicated in all district of State.
The Criteria for deciding the Winning Entry would be
• The logo should bring out essence of Organic Farming, Food Safety, Nutritional Security, safe and
sustainable agriculture
• The logo should communicate that the Organic Farming is a Transformational Opportunity that
will assist farmers to get better realization for their produce and a step for Toxin Free Agriculture
• The logo should be contemporary and easily understandable and can communicate across the
Stakeholders
• The logo/symbol should be vibrant and modern. Each entry should include a logo unit/symbol along
with a detailed logic and explanation of rational and creative thoughts (not more than 100 words).
Date of downloading the detailed documents
: 31.08.2021 from 10:30 hours
Date of receiving application with Logo Design : 21.09.2021 till 23:59 hours
Date of Evaluation by the Committee
: 30.09.2021
Final result of Winners
: 03.10.2021
The detailed information and documents can be downloaded from the official website of the Department
i.e. https:state.bihar.gov.in/Krishi/CitizenHome.html or http://dbtagriculture.bihar.gov.i
Selection Committee: For selection of winners for logo design, the selection committee under
chairmanship of Secretary Agriculture would be the final authority.
Rewards and Recognitions:
• Best Entry (1st Prize): INR 51,000/- (Rs. Fifty-One Thousand) and a Certificate
• Second best Entry (2nd Prize): Certificate
Please ensure you read the Terms and Conditions before submitting your entry.
Terms and Conditions

<!-- page 2 -->

1. This BRJM Logo Design Contest is being conducted by Directorate of Agriculture, Govt. of Bihar
2. Entries are open to individuals, teams and organizations from India
3. All entries must be submitted to Director, Agriculture Govt of Bihar through email
compost.bihar@gmail.com or sent to the address mentioned below.
4. The submission of entry is free.
5. The winning design/logo will be the intellectual property of the Directorate of Agriculture, Govt.
of Bihar. The winner cannot exercise any right over it, after the acceptance of the prize. The
Government of Bihar reserves the rights to use the prize-winning logo for promotional, advertising
and display purposes and to assign it to any person or group of persons. The logo can be adapted
suitably as per the requirement.
6. The logo should not have been previously published in any print and digital media and must not
contain any provocative, objectionable or inappropriate content.
7. The logo should be either in English or Hindi or Sanskrit language.
8. Multiple submissions of logo by the same participant would not be accepted.
9. The logo design must be original and should not violate any provision of the Indian Copyright Act,
1957 or any Indian law. Plagiarism/Copying of any nature would not be allowed.
10. Anyone found infringing on others’ copyright would be disqualified from the competition. The
Government of Bihar does not bear any responsibility for copyright violations or infringements of
intellectual property carried out by the participants.
11. The employees and wards of the Department of Agriculture, Govt. of Bihar and Employment or its
attached offices, or autonomous organizations / institutions working overall administrative controls
of Department of Agriculture Employment are not allowed to take part in this Contest.
12. Participant is required to ensure that his/her profile is accurate and updated since Directorate of
Agriculture would be using this for further communication. This includes details such as name,
photo and phone number. Entries with incomplete profiles will not be considered.
13. Directorate of Agriculture, Govt. of Bihar reserves the right to cancel or amend all or any part of
this Contest and/ or Terms and Conditions/ Technical Parameters/ Evaluation Criteria. However,
any changes to the Terms and Conditions/ Technical Parameters/ Evaluation Criteria, or the
cancellation of the Contest, will be communicated.
14. Directorate of Agriculture shall not use the disqualified entries for any purpose and shall have no
intellectual rights over the same.
15. The winner will be declared by way of announcing his / her name by the Directorate and the same
will be communicated by means of email sent on his/her email id registered with the Directorate.
16. Once a winner is declared, he/she will need to revert through email within 7 days or else another
winner may be chosen.
17. There will be no notification to participants of rejected entries.
18. Any legal proceedings arising out of the competition/ its entries/ winners shall be subject to local
jurisdiction of Patna courts. Expenses incurred for this purpose will be borne by the parties
themselves.

<!-- page 3 -->

Technical Parameters:
1. Participants should send the Logo in JPEG/ JPG/ PNG format only.
2. The Logo should be designed on a digital platform. The winner of the competition shall be required
to submit the design in an editable and open file format. Participants should ensure that original
designs are submitted.
3. Each entry should submit the detailed logic and explanation of rational and creative thoughts (not
more than 100 words) on designed logo in a soft copy.
4. Logo should be designed in color. The size of the logo may vary from 5cm*5cm to 30cm*30cm in
either portrait or landscape.
5. The Logo should be usable on the website/ social media such as Twitter/ Facebook, press releases
and on printed materials such as stationery, signage, labels etc., magazines, commercials, holdings,
standees, brochures, leaflets, pamphlets, souvenirs and other publicity and marketing material for
promotion of Organic Farming
6. The Logo should be in high resolution with minimum 300 DPI.
7. Logo should look clean (not pixilated or bit-mapped) when viewed on screen at 100%.
8. Entries should not be submitted in compressed or self- extracting formats.
9. The logo design should not be imprinted or watermarked.
Evaluation Criteria:
1. All the entries received by Directorate of Agriculture would be assessed for awards by Screening
Committee for an initial evaluation. After such screening, all approved entries would be assessed
by a Selection Committee for final evaluation.
2. Entries would be judged on the basis of elements of creativity, originality, composition, technical
relevance, excellence, simplicity, artistic merit and visual impact and how well they communicate
the theme of Bihar Rajya Jaivik Mission
3. The decision of the Selection Committee would be final and binding on all the contestants and no
clarifications would be issued to any participants or any decision of Selection Committee.
4. Winner shall be required to provide the original open source file of the designed logo.
5. Payment to the winner will be made through electronic mode for which the necessary bank details
will be taken after declaration of winner of the contest
All Applications shall be submitted online or sent to the below address with the Caption on envelope:
1. LOGO DESIGN CONTEST FOR BIHAR RAJYA JAIVIK MISSION
2. Address:
Director Agriculture-cum-Mission Director
Bihar Rajya Jaivik Mission
Directorate of Agriculture
2nd Floor, Vikas Bhawan
Patna 800015, Bihar
3. For any clarity you may call or write to Mrs. Sushmita Priya (sushmitapriya@kpmg.com)
Mobile No: +91-7979825237 or Mr. Neyaz Ahmad (neyazahmad@kpmg.com) Mobile No.
+91-9031421312.

<!-- page 4 -->

BIHAR RAJYA JAIVIK MISSION
Dept. of Agriculture , Patna
APPLICATION FOR CONTEST 2: TAGLINE
Apply by September 21, 2021 11.59 PM
We want to hear your ideas for making Bihar an “ORGANIC BOWL” of Nation. Submit your Tagline by
21st September 2021 11:59 PM.
First Name

Last Name

Sex

Age

Current
Profession

Contact No

Photo

Email ID
Address

▪
▪
▪
▪

Participant Self- Declaration:
I do hereby declare that I am_________________________________________________(name) of
__________________________________(city), ______________________________________(state).
I have gone through and agree to all the terms and conditions given.
The information given by me in the application form is true.
Currently I am not working ( parament/contractual ) with the Dept. of Agriculture, Govt. of Bihar nor my
relative are working with the Department of Agriculture.

(Signature)_____________________________
Full Name (in Capitals) __________________
Date
Submit to
Director Agriculture-cum- Mission Director ,
Bihar Rajya Jaivik Mission ,Directorate of Agriculture ,2nd Floor, Vikas Bhawan ,Patna 800015,
Bihar or ,EMAIL: compost.bihar@gmail.com
For any clarification, please call or write to Mrs. Sushmita Priya (sushmitapriya@kpmg.com) Mobile No: +917979825237 or Mr. Neyaz Ahmad (neyazahmad@kpmg.com) Mobile No. +91-9031421312.

Note: Attached your Tagline as an attachment separately

<!-- page 5 -->

BIHAR RAJYA JAIVIK MISSION
Dept. of Agriculture , Patna
APPLICATION FOR CONTEST 1: LOGO DESIGN
Apply by September 21, 2021 11.59 PM
We want to hear your ideas for making Bihar an “ORGANIC BOWL” of Nation. Submit your logo design
by 21st September 2021 11:59 PM.
First Name

Last Name

Sex

Age

Current
Profession

Contact No

Photo

Email ID
Address

▪
▪
▪
▪

Participant Self- Declaration:
I do hereby declare that I am_________________________________________________________(name) of
__________________________________(city), ______________________________________(state).
I have gone through and agree to all the terms and conditions given.
The information given by me in the application form is true.
Currently I am not working ( parament/contractual ) with the Dept. of Agriculture, Govt. of Bihar nor my
relative are working with the Department of Agriculture.

(Signature)_____________________________
Full Name (in Capitals) __________________
Date

Submit to
Director Agriculture-cum- Mission Director , Bihar Rajya Jaivik Mission ,Directorate of Agriculture ,2nd Floor,
Vikas Bhawan ,Patna 800015, Bihar or ,EMAIL: compost.bihar@gmail.com
For any clarification, please call or write to Mrs. Sushmita Priya (sushmitapriya@kpmg.com) Mobile No: +917979825237 or Mr. Neyaz Ahmad (neyazahmad@kpmg.com) Mobile No. +91-9031421312.

Note: Attached your logo as an attachment separately

<!-- page 6 -->

DIRECTORATE OF AGRICULTURE
GOVERNMENT OF BIHAR
VIKAS BHAWAN, BAILEY ROAD PATNA

TAGLINE CONTEST BEING ORGANIZED BY THE DIRECTORATE OF
AGRICULTURE, DEPARTMENT OF AGRICULTURE, GOVT. OF BIHAR
CONTEST: 2
Directorate of Agriculture, Government of Bihar is the nodal agency to promote Organic Farming in the
State. The Directorate has created a separate entity Bihar Rajya Jaivik Mission to have a comprehensive
approach towards promoting Organic Farming with a vision of making it as a role for the World. Currently
a Jaivik Corridor Scheme has been launched in 13 districts spread on the bank of Ganges a pilot project and
the same is being replicated in all the districts of the State.
The Criteria for deciding the Winning Entry would be
• The tagline should be succinct and short. (Recommended Word Limit: Not more than 10 words)
• The tagline should bring out the essence of Organic and Sustainable Agriculture, Toxin Free
Farming Nutritional Benefits and Food Safety.
• The tagline should be easily understandable and contemporary.
• The tagline should resonate the value of Organic Farming across different stakeholders.
Selection Committee: For selection of winners for tagline contest, the selection committee under
chairmanship of Secretary Agriculture would be the final authority.
Date of downloading the detailed documents
Date of receiving application with Tagline
Date of Evaluation by the Committee
Final result of Winners

: 31.08.2021 from 10:30 hours
: 21.09.2021 till 23:59 hours
: 30.09.2021
: 03.10.2021

The detailed information and documents can be downloaded from the official website of the Department
i.e. https:state.bihar.gov.in/Krishi/CitizenHome.html or http://dbtagriculture.bihar.gov.in
Rewards and Recognitions:
• Best Entry (1st Prize): INR 21,000/- (Rs. Twenty-One Thousand) and a Certificate
• Second best Entry (2nd Prize): Certificate
Please ensure you read the Terms and Conditions before submitting your entry.
Terms and Conditions
1. This BRJM Tagline Contest is being conducted by Directorate of Agriculture, Govt. of Bihar
2. Entries are open to individuals, teams and organizations from India
3. All entries must be submitted to Director, Agriculture Govt of Bihar through email
compost.bihar@gmail.com or sent to the address mentioned below.

<!-- page 7 -->

4. The submission of entry is free.
5. The winning tagline will be the intellectual property of the Directorate of Agriculture, Govt. of
Bihar. The winner cannot exercise any right over it, after the acceptance of the prize. The
Government of Bihar reserves the rights to use the prize-winning tagline for promotional,
advertising and display purposes and to assign it to any person or group of persons. The tagline can
be adapted suitably as per the requirement.
6. The tagline should not have been previously published in any print and digital media and must not
contain any provocative, objectionable or inappropriate content.
7. The tagline should be either in English or Hindi or Sanskrit language.
8. Multiple submissions of tagline by the same participant would not be accepted.
9. The tagline design must be original and should not violate any provision of the Indian Copyright
Act, 1957 or any Indian law. Plagiarism/Copying of any nature would not be allowed.
10. Anyone found infringing on others’ copyright would be disqualified from the competition. The
Government of Bihar does not bear any responsibility for copyright violations or infringements of
intellectual property carried out by the participants.
11. The employees and wards of the Department of Agriculture, Govt. of Bihar and Employment or its
attached offices, or autonomous organizations / institutions working overall administrative controls
of Department of Agriculture Employment are not allowed to take part in this Contest.
12. Participant is required to ensure that his/her profile is accurate and updated since Directorate of
Agriculture would be using this for further communication. This includes details such as name,
photo and phone number. Entries with incomplete profiles will not be considered.
13. Directorate of Agriculture, Govt. of Bihar reserves the right to cancel or amend all or any part of
this Contest and/ or Terms and Conditions/ Technical Parameters/ Evaluation Criteria. However,
any changes to the Terms and Conditions/ Technical Parameters/ Evaluation Criteria, or the
cancellation of the Contest, will be communicated.
14. Directorate of Agriculture shall not use the disqualified entries for any purpose and shall have no
intellectual rights over the same.
15. The winner will be declared by way of announcing his / her name by the Directorate and the same
will be communicated by means of email sent on his/her email id registered with the Directorate.
16. Once a winner is declared, he/she will need to revert through email within 7 days or else another
winner may be chosen.
17. There will be no notification to participants of rejected entries.
18. Any legal proceedings arising out of the competition/ its entries/ winners shall be subject to local
jurisdiction of Patna courts. Expenses incurred for this purpose will be borne by the parties
themselves.

<!-- page 8 -->

Technical Parameters:
1. Participants should send the tagline through email.
2. The Tagline design, if any should be designed on a digital platform. The winner of the competition
shall be required to submit the design in an editable and open file format. Participants should ensure
that original designs are submitted.
3. Each entry should submit the detailed logic and explanation of rational and creative thoughts (not
more than 100 words) on tagline in a soft copy.
4. The tagline should be usable on the website/ social media such as Twitter/ Facebook, press releases
and on printed materials such as stationery, signage, labels etc., magazines, commercials, holdings,
standees, brochures, leaflets, pamphlets, souvenirs and other publicity and marketing material for
promotion of Organic Farming
5. Entries should not be submitted in compressed or self- extracting formats.
6. The tagline should not be imprinted or watermarked.
7. The participant can use any font but they have to disclose it and the size of the font shall be 12 or
above
Evaluation Criteria:
1. All the entries received by Directorate of Agriculture would be assessed for awards by Screening
Committee for an initial evaluation. After such screening, all approved entries would be assessed
by a Selection Committee for final evaluation.
2. Entries would be judged on the basis of elements of creativity, originality, composition, technical
relevance, excellence, simplicity, artistic merit and visual impact and how well they communicate
the theme of Bihar Rajya Jaivik Mission
3. The decision of the Selection Committee would be final and binding on all the contestants and no
clarifications would be issued to any participants or any decision of Selection Committee.
4. Winner shall be required to provide the original open source file of the tagline design, if any.
5. Payment to the winner will be made through electronic mode for which the necessary bank details
will be taken after declaration of winner of the contest
All Applications shall be submitted online or sent to the below address with the Caption on envelope:
1. TAG LINE CONTEST FOR BIHAR RAJYA JAIVIK MISSION
2. Addressed to
Director Agriculture-cum- Mission Director
Bihar Rajya Jaivik Mission
Directorate of Agriculture
2nd Floor, Vikas Bhawan
Patna 800015, Bihar
1. For any clarification, please call or write to Mrs. Sushmita Priya (sushmitapriya@kpmg.com)
Mobile No: +91-7979825237 or Mr. Neyaz Ahmad (neyazahmad@kpmg.com) Mobile No.
+91-9031421312.

<!-- page 9 -->

कृषि निदे शालय
बिहार सरकार

षिकास भिि, िेली रोड पटिा
प्रतियोतििा: 2: कृति तिदे शालय, कृति तिभाि, तिहार सरकार के द्वारा आयोतिि "तिहार राज्य िैतिक तिशि"
के तलए "प्रचार िाक्य" (Tag-line) लेखि प्रतियोतििा
कृषि निदे शालय, बिहार सरकार राज्य में जैषिक खेती को िढािा दे िे के ललए िोडल एजेंसी है । निदे शालय िे निहार
में उत्पानदत कृनि उत्पाद ों क निश्व-पटल पर लािे के उद्दे श्य से "निहार राज्य जैनिक नमशि" का गठि नकया है |
िततमाि में निहार के 13 नजल ों में जैनिक खे ती के प्र त्साहि हे तु "जैनिक कॉररड र" य जिा का पररचालि नकया जा
रहा है | कालाों तर में इसे अन्य नजल ों में भी लागू करिे का प्रस्ताि है | निदे शालय इस ििसृनजत सोंस्था हे तु एक अदद
"प्रचार िाक्य" (Tag-line) ििािे की प्रनिया में है , तथा इसी उद्दे श्य से एक खुली प्रनतय नगता का आय जि नकया जा
रहा है |
निजेता प्रनिनि का मूल्ाों कि निम्ाों नकत मािदों ड ों अिुसार ह गा

• टै गलाइि सोंनिप्त ह िी चानहए। (अिुशोंनसत शब्द सीमा: 10 शब्द ों से अनिक िहीों)
• टै गलाइि में जैनिक और सतत कृनि, निि मुक्त खेती, प िण लाभ और खाद्य सुरिा का सार सामिे आिा चानहए।
• टै गलाइि आसािी से समझिे य ग्य और समकालीि ह िी चानहए।
• टै गलाइि क निनभन्न नहतिारक ों के िीच जैनिक खेती के मूल् क प्रनतध्वनित करिा चानहए।

तिस्तृि दस्तािेि डाउिलोड करिे की तिति : 31.08.2021 10:30 ििे से
"प्रचार िाक्य" (Tag-line) के साथ आिेदि प्राप्त करिे की अंतिि नतथथ : 21.09.2021 से 23:59 िजे तक
सलमनत द्िारा मूलयाांकि की नतथथ: 30.09.2021
षिजेताओां का अांनतम पररणाम: 03.10.2021
The detailed information and documents can be downloaded from the official website of the Department
i.e. https:state.bihar.gov.in/Krishi/CitizenHome.html or http://dbtagriculture.bihar.gov.in
चयि सतिति : "प्रचार िाक्य" (Tag-line) हे तु निजेताओों के चयि हे तु सनचि कृनि की अध्यिता में गनठत चयि सनमनत
अोंनतम प्रानिकार ह गा।
पुरस्कार और मान्यताएां:
• सिवश्रेष्ठ प्रिेश (प्रथम पुरस्कार): INR 21,000/- (रुपये इक्कीस हजार) और एक प्रमाण पत्र
• दू सरी सिवश्रेष्ठ प्रिेश (द्षितीय पुरस्कार): प्रमाणपत्र

<!-- page 10 -->

कृपया सुनिश्चित करें कक आपिे अपिी प्रषिश्ष्ट जमा करिे से पहले नियम और शतें पढ ली हैं।
नियम और शतें
1. "प्रचार िाक्य" (Tag-line) लेखि प्रनतय नगता कृनि निदे शालय, निहार सरकार द्वारा आय नजत की जा रही है , तथा
यह निहार एिों भारत के अन्य राज्य ों के सभी व्यक्तक्तय ,ों टीम ों और सोंगठि ों के नलए खुली हैं
2. सभी प्रषिश्ष्टयाां निदे शक, कृषि बिहार सरकार को ईमेल compost.bihar@gmail.com के माध्यम से या िीिे ददए
गए पते पर भेजी जािी िादहए।
3. प्रषिश्ष्ट जमा नििःशुलक है ।
4. षिजेता "प्रचार िाक्य" (Tag-line) कृषि निदे शालय, निहार सरकार की िौद्थिक सांपदा होगी। परु स्कार की स्िीकृनत

के िाद षिजेता उस पर अपिे ककसी अथिकार का प्रयोग िहीां कर सकता है । बिहार सरकार प्रिार, षिज्ञापि और
प्रदशवि उद्दे चयों के ललए पुरस्कार षिजेता "प्रचार िाक्य" (Tag-line) का उपयोग करिे और इसे ककसी भी व्यश्तत

या व्यश्ततयों के समूह को सौंपिे का अथिकार सुरक्षित रखती है । "प्रचार िाक्य" (Tag-line) को आिचयकता के
अिुसार उपयुतत रूप से अिुकूललत ककया जा सकता है ।

5. "प्रचार िाक्य" (Tag-line) क पहले नकसी नप्रोंट और नडनजटल मीनडया में प्रकानशत िहीों हुआ ह िा चानहए और
इसमें क ई उत्तेजक, आपनत्तजिक या अिुनचत सामग्री का उपय ग िहीों ह िा चानहए।
6. "प्रचार िाक्य" (Tag-line) अांग्रेजी ,दहांदी या सांस्कृत भािा में होिा िादहए।
7. एक ही प्रनतभागी द्िारा "प्रचार िाक्य" (Tag-line) की एक से अथिक प्रषिश्ष्टयाां स्िीकार िहीां की जाएांगी।
8. "प्रचार िाक्य" (Tag-line) नडजाइि मूल ह िा चानहए और भारतीय कॉपीराइट अनिनियम, 1957 या नकसी भारतीय
या अोंतरात िरीय कािूि के नकसी प्राििाि का उल्लोंघि िहीों करिा चानहए। सानहक्तिक च री/नकसी भी प्रकृनत की िकल
की अिुमनत िहीों ह गी।
9. जो कोई भी दस
ू रों के कॉपीराइट का उललांघि करता हुआ पाया गया, उसे प्रनतयोथगता से अयोग्य घोषित कर ददया
जाएगा। प्रनतभाथगयों द्िारा ककए गए कॉपीराइट उललांघि या िौद्थिक सांपदा के उललांघि के ललए बिहार सरकार की
कोई श्जम्मेदारी िहीां है ।
10. कृनि निभाग, निहार सरकार, इससे जु डे कायात लय ों या कृनि निभाग के समग्र प्रशासनिक नियोंत्रण में काम करिे
िाले स्वायत्त सों गठि ों / सोंस्थाि ों के कमतचारी और उिके सम्बन्धी क इस प्रनतय नगता में भाग लेिे की अिुमनत िहीों
है ।
11. प्रनतभागी को यह सुनिश्चित करिा आिचयक है कक उसकी प्रोफाइल सटीक और अद्यति है तयोंकक कृषि

निदे शालय आगे सांिार के ललए इसका उपयोग करे गा। इसमें िाम, फोटो और फोि िांिर जैसे षििरण शालमल हैं।
अपूणव प्रोफाइल िाली प्रषिश्ष्टयों पर षििार िहीां ककया जाएगा।
12. कृषि निदे शालय, निहार सरकार के पास इस प्रनतयोथगता और/या नियम और शतों/तकिीकी मापदां डों/मल
ू याांकि
मािदां ड के सभी या ककसी भी दहस्से को रद्द करिे या सांशोथित करिे का अथिकार सुरक्षित है । हालाांकक, नियम और
शतों/तकिीकी मािकों/मूलयाांकि मािदां ड में ककसी भी िदलाि या प्रनतयोथगता के रद्द होिे की सूििा दी जाएगी।

<!-- page 11 -->

13. कृनि निदे शालय नकसी भी उद्दे श्य के नलए अय ग्य प्रनिनिय ों का उपय ग िहीों करे गा और उस पर निदे शालय का
क ई िौक्तिक अनिकार िहीों ह गा।
14. निजेता के िाम की घ िणा निदे शालय द्वारा निनभन्न माध्यम से की जाएगी और इसकी सूचिा प्रनिनि पत्र में दजत
ईमेल आईडी के माध्यम से भी दी जाएगी।
15. एक िार निजेता घ नित ह िे के िाद, उसे 7 नदि ों के भीतर ईमेल के माध्यम से स्वीकार करिा ह गा अन्यथा क ई
अन्य निजेता चु िा जा सकता है ।
16. अस्िीकृत प्रषिश्ष्टयों के प्रनतभाथगयों को कोई सूििा िहीां दी जाएगी।
17. प्रनतयोथगता/इसकी प्रषिश्ष्टयों/षिजेताओां से उत्पन्ि होिे िाली कोई भी कािूिी कायविाही पटिा के अदालतों
के स्थािीय िेत्राथिकार के अिीि होगी। इस पर होिे िाला खिव पिकार स्ियां िहि करें गे।
तकिीकी पैमािे:
1. प्रनतभाथगयों को केिल जेपीईजी/जेपीजी/पीएिजी प्रारूप में ल ग यनद ह त भेजिा है ।
2. "प्रचार िाक्य" (Tag-line) नडज़ाइि , यनद ह त , क नडनजटल प्लेटफॉमत पर नडजाइि नकया हुआ ह िा चानहए।
प्रनतय नगता के निजेता क एक सोंपादि य ग्य और खुले फाइल प्रारूप में नडज़ाइि प्रस्तुत करिा आिश्यक ह गा।
प्रनतभानगय ों क यह सुनिनित करिा ह गा नक मूल नडजाइि प्रस्तुत नकए गए हैं ।
3. प्रिेक प्रनिनि के साथ नडज़ाइि नकए गए "प्रचार िाक्य" (Tag-line) पर तकतसों गत और रचिात्मक निचार ों
(100 शब्द ों से अनिक िहीों) के साथ स्पिीकरण भी सलग्न ह िा चानहए।
4. "प्रचार िाक्य" (Tag-line) िेिसाइट/स शल मीनडया जैसे निटर/फेसिुक, प्रेस निज्ञक्तप्त और मुनित सामग्री जै से
स्टे शिरी, साइिेज, लेिल इिानद, पनत्रकाओों, निज्ञापि ,ों ह क्तडोंग्स, स्टैं डी, ब्र शर (Brochure), लीफलेट, पैम्फलेट,
स्मृनत नचन्ह पर और जैनिक खेती क िढािा दे िे के नलए अन्य प्रचार और निपणि सामग्री पर प्रय ग करिे
य ग्य ह िा चानहए।
5. प्रनिनियाों सोंपीनडत (compressed) या स्वयों निकालिे िाले प्रारूप ों (Self-extracting format) में प्रस्तुत िहीों
की जािी चानहए।
6. "प्रचार िाक्य" (Tag-line) पर नडज़ाइिर का िाम या िॉटरमाकत अोंनकत िहीों ह िा चानहए।
िूल्ांकि पैिािा:
1. सभी प्राप्त प्रनिनिय ों का प्रारों नभक मूल्ाों कि कृनि निदे शालय द्वारा गनठत स्क्रीनिोंग कमेटी द्वारा नकया
जाएगा। स्क्रीनिोंग के िाद, अोंनतम मूल्ाों कि के नलए चयि सनमनत द्वारा सभी अिुम नदत प्रनिनिय ों का मूल्ाों कि
नकया जाएगा।
2. प्रनिनिय ों का मूल्ाों कि रचिात्मकता, मौनलकता, तकिीकी प्रासोंनगकता, उत्कृिता, सादगी, कलात्मक य ग्यता
और दृश्य प्रभाि के तत् ों के आिार पर नकया जाएगा तथा यह भी ध्याि नदया जाएगा नक िे निहार राज्य
जैनिक नमशि के नििय क नकतिी अच्छी तरह से सोंप्रेनित करते हैं ।
3. चयि सनमनत का निणतय अोंनतम और सभी प्रनतय नगय ों के नलए िाध्यकारी ह गा और चयि सनमनत के नकसी
भी निणतय के नलए क ई स्पिीकरण जारी िहीों नकया जाएगा।

<!-- page 12 -->

4. निजेता क नडज़ाइि नकए गए "प्रचार िाक्य" (Tag-line) (यनद ह त ) की मूल ओपि स सत फाइल प्रदाि
करिे की आिश्यकता ह गी।
5. निजेता क भुगताि इलेक्ट्रॉनिक म ड के माध्यम से नकया जाएगा नजसके नलए प्रनतय नगता के निजेता की
घ िणा के िाद आिश्यक िैंक नििरण नलया जाएगा
सभी आिेदि ऑिलाइि जमा नकए जाएों गे या नलफाफे पर कैप्शि ("प्रचार िाक्य" (Tag-line) लेखि प्रनतय नगता)
के साथ िीचे नदए गए पते पर भेजे जाएों गे:
1. निहार राज्य जैनिक नमशि के नलए "प्रचार िाक्य" (Tag-line) ििािे की प्रनतय नगता
2. पता:
तिदे शक कृति-सह-तिशि तिदे शक
निहार राज्य जैनिक नमशि
कृनि निदे शालय
दू सरी मोंनजल, निकास भिि
पटिा 800015, निहार
3. नकसी भी स्पिता के नलए श्रीमती सुक्तिता नप्रया (sushmitapriya@kpmg.com) म िाइल िोंिर: +917979825237 या श्री िेयाज अहमद (neyazahmad@kpmg.com) म िाइल िोंिर +91-9031421312 से सम्पकत
नकया जा सकता है ।
** ह िं दी एविं अिं ग्रेजी मार्गहिदे हिका में कोई हवरोधाभास ोिे पर अिंग्रेजी मार्गहिदे हिका को मान्यता दी जाएर्ी ।

<!-- page 13 -->

बिहार राज्य जैविक मिशन
कृवि विभाग, पटना

Tag Line ( प्रचार वाक्य ) तैयार करने की प्रतियोगगिा के मिए आिेदन
आिेदन 21 मििंिर, 2021 राि 11.59 िजे िक स्वीकार ककये जाएं गे

“बिहार को राष्ट्र का "Organic Bowl" िनाने िें सहयोग करें ।“
किहार राज्य जैकिक किशन के किए एक आकर्षक " प्रचार वाक्य " (Tag-Line) तैयार करे
एिं आकर्षक पुरस्कार प्राप्त करें |
नाि :
आयु

किंग

फोटो

िितिान व्यििाय
संपकष संख्या
ईिेि आईडी
पिा

प्रतिभागी स्ि-घोिणा/ Self Declaration
िैं एतद्द्िारा घोर्णा करता /ती हूँ कक िैं ____________________ (शहर)/ गां व, _______________ (राज्य) का/की
निवासी हूँ । िैं ने किए गए सभी कनयिों और शतों को पढ़ किया है और उनसे सहित हं । िेरे द्वारा आिे िन पत्र िें िी गई
जानकारी सत्य है । ितष िान िें िैं कृकर् किभाग, भारत /किहार सरकार के साथ (स्थायी /संकििात्मक) काि नहीं कर रहा/ रही हूँ
और न ही िे रे ररश्तेिार कृकर् किभाग के साथ काि कर रहे हैं ।

(हस्िाक्षर)___________________
पूरा नाि __________________
ददनांक___________________
आवेदन जमा करने का पता :
तनदे शक कृवि-िह-मिशन तनदे शक, बिहार राज्य जैविक मिशन, कृवि तनदे शािय, दि
ू री िंजजि, विकाि भिन, पटना
800015, बिहार या ईिेि: compost.bihar@gmail.com
ककिी भी स्पष्ट्टीकरण के मिए, कृपया श्रीििी िुजष्ट्ििा वप्रया (sushmitapriya@kpmg.com) िोिाइि नंिर: +91-7979825237 या
/श्री नेयाज अहिद (neyazahmad@kpmg.com) िोिाइि नंिर +91-9031421312 से सम्पकष करें |
िोट:-अपिा प्रचार वाक्य " (Tag-Line) कडज़ाइन अलग से संलग्न करें

<!-- page 14 -->

कृषि निदे शालय
बिहार सरकार

षिकास भिि, िेली रोड पटिा
प्रतियोतििा: १: कृति तिदे शालय, कृति तिभाि, तिहार सरकार के द्वारा आयोतिि तिहार राज्य िैतिक
तिशि के लिए “Logo (प्रतीक लिन्ह) ” लिज़ाइन करने की प्रनियोगििा
कृषि निदे शालय, बिहार सरकार राज्य में जैषिक खेिी को िढािा दे िे के ललए िोडल एजेंसी है । निदे शालय िे निहार
में उत्पानदत कृनि उत्पाद ों क निश्व-पटल पर लािे के उद्दे श्य से "निहार राज्य जैनिक नमशि" का गठि नकया है |
िततमाि में निहार के 13 नजल ों में जैनिक खे ती के प्र त्साहि हे तु "जैनिक कॉररड र" य जिा का पररचालि नकया जा
रहा है | कालाों तर में इसे अन्य नजल ों में भी लागू करिे का प्रस्ताि है | निदे शालय इस नवसृजित सोंस्था हे तु एक अदद
"Logo"(प्रतीक जिन्ह) ििािे की प्रनिया में है , तथा इसी उद्दे श्य से एक खुली प्रनतय नगता का आय जि नकया जा रहा
है |
निजेता प्रनिनि का मूल्ाों कि निम्ाों नकत मािदों ड ों के अिुसार ह गा
•
•

•
•

"Logo"(प्रतीक जिन्ह) ,जैषिक खेिी, खाद्य सुरक्षा, प िण सुरक्षा, सुरनक्षत और नटकाऊ कृनि के सार
क प्रदनशतत करे |
"Logo"(प्रतीक जिन्ह) के द्वारा यह सन्दे श जािा चानहए नक जैनिक खेती एक पररितत िकारी अिसर
है ज नकसाि ों क उिकी उपज के नलए िे हतर मूल् प्राप्त करिे में तथा निि मु क्त कृनि कायत में
सहायता करे गा।
Logo (प्रतीक जिन्ह) समकालीि और आसािी से समझिे य ग्य ह िा चानहए
Logo (प्रतीक जिन्ह) जीिोंत और आधुनिक ह िा चानहए। प्रत्येक प्रनिनि के साथ एक सोंनक्षप्त
तकतसोंगत और रचिात्मक निचार ों (100 शब् ों से अनधक िहीों) का स्पिीकरण सोंलग्न ह िा
चानहए।

तिस्तृि दस्तािेि डाउिलोड करिे की तिति : 31.08.2021 10:30 ििे से
Logo (प्रतीक लिन्ह) डडजाइि के साथ आिेदि प्राप्ि करिे की अंलतम निगथ : 21.09.2021 से 23:59 िजे िक
सलमनि द्िारा मूलयाांकि की निगथ: 30.09.2021
िि जेिाओां का अांनिम पररणाम: 03.10.2021
The detailed information and documents can be downloaded from the official website of the Department
i.e. https:state.bihar.gov.in/Krishi/CitizenHome.html or http://dbtagriculture.bihar.gov.in
चयि सलमनि : Logo (प्रतीक जिन्ह) डडजाइि हे िु षिजेिाओां के चयि हे िु सगचि कृषि की अध्यक्षिा में चयि सलमनि
अांनिम प्रानधकार ह गा।

<!-- page 15 -->

पुरस्कार और मान्यिाएां:
• सिवश्रेष्ठ प्रिेश (प्रथम पुरस्कार): INR 51,000/- (रुपये इक्यािि हजार) और एक प्रमाण पत्र
• दस
ू रा सिवश्रेष्ठ प्रिेश (द्षििीय परु स्कार): प्रमाणपत्र
कृपया सुनििचचि करें कक आपिे अपिी प्रषििष्ट जमा करिे से पहले नियम और शिें पढ ली हैं।

नियम और शिें
1. यह Logo (प्रतीक जिन्ह) नडजाइि प्रनतय नगता कृनि निदे शालय, निहार सरकार द्वारा आय नजत की जा रही
है , तथा यह निहार एिों भारत के अन्य राज्य ों के सभी व्यक्तक्तय ,ों टीम ों और सोंगठि ों के नलए खुली हैं
2. सभी प्रनिनियाों निदे शक, कृनि निहार सरकार क ईमेल compost.bihar@gmail.com के माध्यम से या िीचे
नदए गए पते पर भेजी जािी चानहए।
3. प्रनिनि जमा नििःशुल्क है ।
4. निजेता नडजाइि/Logo कृनि निदे शालय, निहार सरकार की िौक्तिक सोंपदा ह गी। पुरस्कार की स्वीकृनत के
िाद निजेता उस पर अपिे नकसी अनधकार का प्रय ग िहीों कर सकता है । निहार सरकार प्रचार, निज्ञापि
और प्रदशत ि उद्दे श्य ों के नलए पुरस्कार निजेता Logo (प्रतीक जिन्ह) का उपय ग करिे और इसे नकसी भी
व्यक्तक्त या व्यक्तक्तय ों के समू ह क सौोंपिे का अनधकार सु रनक्षत रखती है । Logo क आिश्यकता के अिुसार
उपयुक्त रूप से अिुकूनलत नकया जा सकता है ।
5. Logo (प्रतीक जिन्ह) क पहले नकसी नप्रोंट और नडनजटल मीनडया में प्रकानशत िहीों हुआ ह िा चानहए और
इसमें क ई उत्तेजक, आपनत्तजिक या अिुनचत सामग्री का उपय ग िहीों ह िा चानहए।
6. Logo (प्रतीक जिन्ह) अोंग्रेजी, नहों दी या सोंस्कृत भािा में ह िा चानहए।
7. एक ही प्रनतभागी द्वारा “Logo (प्रतीक जिन्ह) ” की एक से अनधक प्रनिनियाों स्वीकार िहीों की जाएों गी।
8. “प्रतीक जिन्ह नडजाइि” मूल ह िा चानहए और भारतीय कॉपीराइट अनधनियम, 1957 या नकसी भारतीय या
अंतर्ाा ष्ट्रीय कािूि के नकसी प्रािधाि का उल्लोंघि िहीों करिा चानहए। सानहक्तत्यक च री/नकसी भी प्रकृनत की
िकल की अिु मनत िहीों ह गी।
9. ज क ई भी दू सर ों के कॉपीराइट का उल्लोंघि करता हुआ पाया गया, उसे प्रनतय नगता से अय ग्य घ नित कर
नदया जाएगा। प्रनतभानगय ों द्वारा नकए गए कॉपीराइट उल्लों घि या िौक्तिक सोंपदा के उल्लोंघि के नलए निहार
सरकार की क ई नजम्मेदारी िहीों है ।
10. कृनि निभाग, निहार सरकार, इससे जुडे कायात लय ों या कृनि निभाग के समग्र प्रशासनिक नियोंत्रण में काम
करिे िाले स्वायत्त सों गठि ों / सोंस्थाि ों के कमतचारी और उिके सम्बन्धी क इस प्रनतय नगता में भाग लेिे की
अिुमनत िहीों है ।
11. प्रनतभागी क यह सुनिनित करिा आिश्यक है नक उसकी प्र फाइल सटीक और अद्यति है क् नों क कृनि
निदे शालय आगे सोंचार के नलए इसका उपय ग करे गा। इसमें िाम, फ ट और फ ि िोंिर जैसे नििरण शानमल
हैं । अपूणत प्र फाइल िाली प्रनिनिय ों पर निचार िहीों नकया जाएगा।
12. कृनि निदे शालय, निहार सरकार के पास इस प्रनतय नगता और/या नियम और शतों/तकिीकी
मापदों ड /ों मूल्ाों कि मािदों ड के सभी या नकसी भी नहस्से क रद्द करिे या सोंश नधत करिे का अनधकार सुरनक्षत
है । हालाों नक, नियम और शतों/तकिीकी मािक /ों मूल्ाों कि मािदों ड में नकसी भी िदलाि या प्रनतय नगता के
रद्द ह िे की सू चिा दी जाएगी।
13. कृनि निदे शालय नकसी भी उद्दे श्य के नलए अय ग्य प्रनिनिय ों का उपय ग िहीों करे गा और उस पर क ई िौक्तिक
अनधकार िहीों ह गा।

<!-- page 16 -->

14. निजेता के िाम की घ िणा निदे शालय द्वारा निनभन्न माध्यम से की जाएगी और इसकी सूचिा प्रनिनि पत्र में
दजत ईमेल आईडी के माध्यम से भी दी जाएगी।
15. एक िार निजेता घ नित ह िे के िाद, उसे 7 नदि ों के भीतर ईमेल के माध्यम से स्वीकार करिा ह गा अन्यथा
क ई अन्य निजे ता चुिा जा सकता है ।
16. अस्वीकृत प्रनिनिय ों के प्रनतभानगय ों क क ई सूचिा िहीों दी जाएगी।
17. प्रनतय नगता/इसकी प्रनिनिय /ों निजेताओों से उत्पन्न ह िे िाली क ई भी कािूिी कायतिाही पटिा के अदालत ों के
स्थािीय क्षेत्रानधकार के अधीि ह गी। इस पर ह िे िाला खचत पक्षकार स्वयों िहि करें गे।

िकिीकी पैमािे:
1. प्रनिभागियों को केिल जेपीईजी/जेपीजी/पीएिजी प्रारूप में Logo भे जिा है ।
2. Logo (प्रतीक जिन्ह)क नडनजटल प्लेटफॉमत पर नडजाइि नकया हुआ ह िा चानहए। प्रनतय नगता के
निजेता क एक सोंपादि य ग्य और खुले फाइल प्रारूप में नडजाइि प्रस्तुत करिा आिश्यक ह गा।
प्रनतभानगय ों क यह सुनिनित करिा ह गा नक मूल नडजाइि प्रस्तुत नकए गए हैं ।
3. प्रत्येक प्रनिनि के साथ नडजाइि नकए गए Logo (प्रतीक जिन्ह) पर तकतसोंगत और रचिात्मक निचार ों
(100 शब् ों से अनधक िहीों) के साथ स्पिीकरण भी सलग्न ह िा चानहए।
4. Logo (प्रतीक जिन्ह) का नडजाइि रों गीि ह िा चानहए। Logo का आकार प टर े ट या लैंडस्केप में
5cm*5cm से 30cm*30cm तक ह सकता है ।
5. Logo (प्रतीक जिन्ह) िेिसाइट/स शल मीनडया जैसे निटर/फेसिुक, प्रे स निज्ञक्तप्त और मुनित सामग्री जैसे
स्टे शिरी, साइिेज, लेिल इत्यानद, पनत्रकाओों, निज्ञापि ,ों ह क्तडोंग्स, स्टैं डी, ब्र शर (Brochure), लीफलेट,
पैम्फलेट, स्मृनत नचन्ह पर और जैनिक खेती क िढािा दे िे के नलए अन्य प्रचार और निपणि सामग्री
पर प्रय ग करिे य ग्य ह िा चानहए।
6. Logo (प्रतीक जिन्ह) कम से कम ३०० डीपीआई के साथ उच्च ररजॉल्ूशि में ह िा चानहए।
7. स्क्रीि पर 100% दे खिे पर Logo (प्रतीक जिन्ह) क साफ (Pixeled या Bit-mapped) िहीों नदखिा
चानहए।
8. Logo (प्रतीक जिन्ह) पर

नडजाइिर का िाम या िॉटरमाकत अोंनकत िहीों ह िा चानहए।

िूल्ाांकि पैिािा:
1. सभी प्राप्त प्रनिनिय ों का प्रारों नभक मूल्ाों कि कृनि निदे शालय द्वारा गनठत स्क्रीनिोंग कमेटी द्वारा
नकया जाएगा। स्क्रीनिोंग के िाद, अोंनतम मूल्ाों कि के नलए चयि सनमनत द्वारा सभी अिुम नदत प्रनिनिय ों
का मूल्ाों कि नकया जाएगा।
2. प्रनिनिय ों का मूल्ाों कि रचिात्मकता, मौनलकता, तकिीकी प्रासोंनगकता, उत्कृिता, सादगी, कलात्मक
य ग्यता और दृश्य प्रभाि के तत् ों के आधार पर नकया जाएगा तथा यह भी ध्याि नदया जाएगा नक
िे निहार राज्य जैनिक नमशि के नििय क नकतिी अच्छी तरह से सोंप्रेनित करते हैं ।
3. चयि सनमनत का निणतय अोंनतम और सभी प्रनतय नगय ों के नलए िाध्यकारी ह गा और चयि सनमनत
के नकसी भी निणतय के नलए क ई स्पिीकरण जारी िहीों नकया जाएगा।
4. निजेता क नडजाइि नकए गए Logo की मूल ओपि स सत फाइल प्रदाि करिे की आिश्यकता ह गी।
5. निजेता क भुगताि इलेक्ट्रॉनिक म ड के माध्यम से नकया जाएगा नजसके नलए प्रनतय नगता के निजेता
की घ िणा के िाद आिश्यक िैंक नििरण नलया जाएगा

<!-- page 17 -->

सभी आिेदि ऑिलाइि जमा नकए जाएों गे या नलफाफे पर कैप्शि “Logo (प्रतीक लिन्ह) तडिाइि” प्रनतय नगता”
के साथ िीचे नदए गए पते पर भेजे जाएों गे:
1. निहार राज्य जैनिक नमशि के नलए “Logo (प्रतीक जिन्ह) नडजाइि” प्रनतय नगता
2. पता:
तिदे शक कृति-सह-तिशि तिदे शक
निहार राज्य जैनिक नमशि
कृनि निदे शालय
दू सरी मोंनजल, निकास भिि
पटिा 800015, निहार
3. नकसी भी स्पिता के नलए श्रीमती सुक्तिता नप्रया (sushmitapriya@kpmg.com) म िाइल िोंिर: +917979825237 या श्री िेयाज अहमद (neyazahmad@kpmg.com) म िाइल िोंिर +91-9031421312 से सम्पकत
नकया जा सकता है ।
** ज ं दी एवं अं ग्रेिी मार्ाजनदे जिका में कोई जवर्ोधाभास ोने पर् अंग्रेिी मार्ाजनदे जिका को मान्यता दी िाएर्ी ।

<!-- page 18 -->

बिहार राज्य जैविक मिशन
कृवि विभाग, पटना

लोगो डिजाइन प्रतियोगगिा के मलए आिेदन
आिेदन 21 मििंिर, 2021 राि 11.59 िजे िक स्वीकार ककये जाएं गे

“बिहार को राष्ट्र का "Organic Bowl" िनाने िें सहयोग करें ।“
“किहार राज्य जैकिक किशन” के किए एक आकर्षक "प्रतीक चिन्ह "(Logo) किज़ाइन करे
एिं आकर्षक पुरस्कार प्राप्त करें |
नाि
किंग
िर्षिान व्यिसाय

फोटो

जन्मचतचि

संपकष सं ख्या
ईिेि आईिी
पर्ा

प्रतिभागी स्ि-घोिणा (Self Declarations)
िैं एिद्दद्दिारा घोिणा करिा /ती हूँ कक िैं ____________________ (शहर)/ गां व, _______________ (राज्य) का/की
चिवासी हूँ । िैंने ददए गए िभी तनयिों और शिों को पढ़ मलया है और उनिे िहिि हं । िेरे द्दिारा आिेदन पत्र िें दी गई
जानकारी ित्य है । िितिान िें िैं कृवि विभाग, भारि /किहार िरकार के िाथ (स्थायी /िंविदात्िक) काि नहीं कर रहा/ रही
हूँ और न ही िेरे ररश्िेदार कृवि विभाग के िाथ काि कर रहे हैं।

(हस्िाक्षर)___________________
परा नाि __________________
ददनांक___________________
आवेदन जमा करने का पता :
तनदे शक कृवि-िह-मिशन तनदे शक, बिहार राज्य जैविक मिशन, कृवि तनदे शालय, दिरी िंजजल, विकाि भिन, पटना
800015, बिहार या ईिेल: compost.bihar@gmail.com
ककिी भी स्पष्ट्टीकरण के मलए, कृपया श्रीििी िुजष्ट्ििा वप्रया (sushmitapriya@kpmg.com) िोिाइल नंिर: +91-7979825237 या
/श्री नेयाज अहिद (neyazahmad@kpmg.com) िोिाइल नंिर +91-9031421312 से सम्पकष करें |
िोट:-अपिा प्रतीक चिन्ह "(Logo) किज़ाइन अलग से संलग्न करें
