---
doc_id: "bc11bf7a5c1e10ce"
source_url: "https://www.jpv.ac.in/_files/ugd/732218_c25ea03e6ac74e90abc6806934ee38e2.pdf"
ministry: "Jai Prakash Vishwavidyala (University), Bihar"
title: "Tender  No. JPU/02/Store/2025-26—Supply & maintenance for water purifier & cooler (27.02.2026)     (RFP Download)"
date: ""
pages: 24
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "83d0ec7159f058c5"
---

<!-- page 1 -->

JAI PRAKASH UNIVERSITY
Rahul Sankrityayan Nagar, Chapra, Saran, Bihar-84302
Request for Proposal (RFP)
For
Supply, Installation and Maintenance of Water Purifier with inbuilt
Storage Cooler for different Buildings at J.P. University Campus for the
“ - year 2025-26
Notice inviting Tender No. JPU/02/Store/ 2025-2026
Dated- 27.02.2026
कक), ®) |
oO EE Fer
wee
4:
Issuing Authority
Prof. Narayan Das
Registrar
registrar-jpu-bih@nic.in
regjpuchapra@gmail.com
३

<!-- page 2 -->

l. Background Information है
4.], Basic Information
Jai Prakash University was established on 22,,990 by the enactment of section 3(b) of the
/ Bihar State Universities Act, 976, with Its headquarters at Chapra, after carving it out from
the then Bihar University (now BRA. Blhar University), Muzaffarpur. The territorial
Jurisdiction of the University is stretched over the whole of Saran Division, Comprising three
districts of Chapra, Siwan and Gopalgan),
Jai Prakash University has functional dimensions to strengthen the development and
management of educational infrastructure associated with Pure Science, Commerce, Social
Science, and allied professional education in Bihar University promotes quality research and
innovation in skilled techniques for mankind, There are four faculties and seventeen Post
Graduate Departments of teaching and research, which have proved their excellence in
imparting quality education in the field of Higher Education and providing opportunities to
the students in carrying out research works of international standard, coping with the needs
of the day.
Jai Prakash University invites Supply, Installation and Maintenance of Water Purifier with
inbuilt Storage Cooler Jai Prakash University, Rahul Sankrityayan Nagar, Chapra, Saran. This
Equipment will contribute towards advancement of academic and administrative work,
knowledge and research.
2. Instructions to Bidder Notice Detail /Schedules of Events
___ Document Control Sheet
| SINo. “| Event Description i Timelines
Date of Uploading and Last daw | Till 3/03/2026 up to 03:00 PM, on the
and time for Downloading the RFP) Procurement Portal(https://wwy-.eproc? bihar.gov.in}
Last date and time for submission
(upload) of online bidding 34/03/2026 up to 06:00PM, on the e-
document rocurement Portal (https.//www.eproc?.bihar.gov.in)
Time, Date of opening of 46/03/2026 at 2:00PM on thee-Procurement
Technical Bid Portal https://www,eproc?, bihar gov in)
Es To be announced later on the e-Procurement Portal Mebsite
Bid (hitpsi//www.eproc? bihargov.in)
Pre-bid meeting (Date & time)
07/03/2026 at 02:00 PM
Venue: Office of the Registrar, Jai Prakash University, Chapra
University Contact Personand Prof, Narayan Das, Registrar
ae registrar-jpu-bih@nicin, 943294030
29 Jai Prakash University,
Full Address of University Rahul Sankrityayan Nagar, Chapra, Saran, Bihar-
84302
Note: Bidders are advised to visit the jai Prakash University, Chapra website www.
website on regular basis for any updates, ov -acis and Fproca
| This RFP process will be administered through the state public Procurem: RL:
hitps://eproc2.bihargov.in). The Bidders are required to submit soft ciples Fae e
slestronicallyon the SPP Portal, using valid dial signature certificates of efhenrs dus’ oe
eo?

<!-- page 3 -->

submit the bid in e-files. More information for submitting the bids online on the SPP Portal may be obtained
at https: //eproc2.bihar.gov.in/

P All the pages of the bid must be sequentially numbered and must contain the list of contents with page
numbers. Any deficiency in the documentation may result in the rejection of the bid. Failure to submit the
bid on time could cause a bid to be rejected. The Univers! ty will not accept delivery of the Bid by fax/e-mail
or any other electronic/non- electronic means other than uploading on the procurement portal.

B The corrigendum (if any) & clarifications to the queries from all Bidders will be posted on the
www.eproc2.bihargov.in-Any such corrigendum shall be deemed to be incorporated into this RFP.

If a format for a specific document is not provided for in this RFP, the document shall be submitted ina

format that makes it legally valid / binding on the Bidder and that is acceptable to the University. In any

event, the University shall have the right to seek clarifications, modifications etc. on the document

submitted by the Bidder and the Bidder shall be obliged to provide such clarifications and modifications

within the timelines specified by the University,

Interested parties, after careful review of all the clauses of this ‘Request for Proposal’, are encouraged to
send their suggestions in writing to University. Such Suggestions, after review, may be incorporated into
this ‘Request for Proposal’ as a corrigendum, which shall be uploaded onto the e-tendering website
https://www.eproc2.bihar.gov.in and University website (www,jpv.ac.in), All eligible tenders need to be
registered on the following portals to generate login credentials and to download the bid documents for
online bid preparation / decryption etc.

6 To participate in the e-tendering process, the bidders/agencies are required to get themselves registered
with Bihar Government Centralized e-Procurement portal, Le, https://www.eproc2.bihar.gov.in, and may
contact the helpdesk at the following address, “eProc 2.0 Help Desk Address; mjunction services limited, RJ
Complex, 2nd floor, Canara Bank Campus, Kbajpura, Ashiana Road, P.S. - Shastri nagar, Patna - 800 04,
Bihar, Toll Free Number; 800 572 657 {Working hours: 8AM to 7PM, all days in week except Sunday and
few selected state holidays) or may visit the link at https:// www.eproc2.bihar.gov.in,

Tenderer may also download the tender documents (a complete set of document is available on website)
from e-Procurement Portal (https://www.eproc2.bihargov.in) and submit its tender by using the
downloaded document.

Tender Processing Fee (TPF) need to be paid as applicable through e-Payment mode (ie. NEFT-RTGS,
Internet Banking, Credit / Debit Card).

The technical and financial bids must be submitted / uploaded through e-Procurement Portal (https://
www.eproc2.bihar.gov.in) on or before the date and time specified in the NIT. The Jai Prakash University,
Chapra doesn't take any responsibility for the delay / Non-Submission of Tender / Non-Reconciliation of
online Payment caused due to non-availability of Internet Connection, Network Traffic/ Holidays or any
other reason.

"986५०
Prof. Narayan Das,
Registrar
3

<!-- page 4 -->

2.4, Right to terminate the Process
है |, University may terminate the RFP process at any time and without assigning any reason,
4 University makes no commitments, express or implied, that this process will result ina business
transaction with anyone.
i, This RFP does not constitute an offer by University. The bidder's participation in this process
may result University selecting the bidder to engage towards execution of the contract.
2.2. Submission of Technical Proposal
The bidders should submit their responses as per the format given in this RFP in the following manner:
l.  Pre-Qualification Criterion
2. Technical Evaluation Criteria
3. Financial Proposal
Prices should not be indicated in the Eligibility Criterion and Technical Evaluation Criteria but should
only be indicated in the Commercial Proposal in the format given in €-procurement portal.
2,3. Site Inspection
Bidders are advised to inspect the site and its surroundings where these equipments are to be installed
& supplied and satisfy them before submitting their tenders. A bidder shall be deemed to have full |
knowledge of the work whether he/she inspects it or not and no extra charges consequent on any
misunderstanding or otherwise shall he allowed.
24. Acceptance
The Bidder shall provide such packing of the Equipment and stationary Items etc. as is required to
prevent damage or deterioration during shipment/equipment. The Bidder shall promptly repair or
replace any Equipment and stationary Items etc, that is damaged in transit. The packing, marking, and
documentation within and outside the packages shall also comply strictly with the requirements. The
Bidder shail insert in each case a packing list, fully itemized to show case number, contents, gross and
net weight, and cubic measurement.
| if the Equipment fails to meet the specifications as mentioned in this REP and during warranty period |
due to faulty part/component, the replacement of faulty part/component must be carried out by the |
Bidder free of cost. Freight, insurance and other allied expenditure like customs duties etc. for such
part/component shall be the liability of the Bidder. Bidder will reimburse to University the cost incurred
by University, ifany, on replacement of such faulty part/component.
If it becomes necessary for the Bidder to replace or renew any defective portions of the Equipment
under this clause, if any defects be not remedied within 5 (Fifteen) days from the date of
communication thereof or within such other specific period as may be allowed by the University in his
discretion on application made to that effect by the Bidder, the University may proceed to carry out the
work at Bidder’s risk and expense, but without prejudice to any other rights which the U niversity may
have against the Bidder in respect of such defects,
2.5. Training to University
Bidder shall provide training to the personnel nominated by the University at Fespective locations to

<!-- page 5 -->

हि. Ee EEE
enable them to have sufficient knowledge and skill to effectively manage, maintain, use and operate
Equipment and to change/modify program during installation, warranty and O&M period.
On-site training during the installation of the Equipment may be arranged by the Bidder. Arrangement
of all training materials such as manuals, drawings, brochures etc. shall be the responsibility of the
Bidder.
2.6. Preparation and Submission of Proposal
2.6. Proposal Preparation Costs
The bidder shall be responsible for all costs incurred in connection with participation in the RFP
process, including, but not limited to, costs incurred in conduct of informative and other diligence
activities, participation in meetings/discussions/presentations, preparation of Proposal, in providing
any additional information required by University to facilitate the evaluation Process, and in negotiating
a definitive contract or all such activities related to the bid process.
University will in no case be responsible or liable for those costs, regardless of the conduct or outcome
of the bidding process,
262. Language
The Proposal should be filled by the bidders in English language only, if any supporting documents
submitted are in any language other than English and Hindi, translation of the same in English language
is to be duly attested by the Bidders. For purposes of interpretation of the documents, the English
translation shall govern.
2.6.3. Pre-Bid Conference
2) The University shall hold a pre-bid meeting with the Prospective Bidders as per information given
in the Fact Sheet above.
b) The Bidders will have to ensure that their queries for pre-bid meetings should reach the point of
contact (Nodal Officer) in written form either mail or in form of letter in company’s letter head
only as mentioned in the schedule of events within the timelines given. Mail Id
regjpuchapra@gmail.com or registrar-jpu-bih@nic.in.
¢) The e-mail should necessarily have subject as per the following nomenclature: "Pre-bid Query -
RFP University "*{Company’s Name)”
d) The queries should necessarily be submitted in the following format in both PDF and Editable
MS-Word/ Excel File Format:
Name of mobile number RFP
of the authorized contact | document Content of REP
person and address of | reference(s). iri Bidde
the bidder (Section | Teduiring rs Query
clarification
page
number)
at PCRS NNN Pees व्त | 8/8$झ/ |]
CF [ |
264. Evaluationprocess
A Proposai evaluation committee shall be constituted by the University. The Proposal Evaluation
Committee may ask for meetings with the Bidders to seek clarifications on their proposals.

<!-- page 6 -->

a OS eS SS SS
The Proposal Evaluation Committee reserves the right to reject any or all proposals based on any
deviations.

Each of the responses shall be evaluated as per the criteria and requirements specified in this RFP.
/ 2.65, Tender Opening
The Proposals submitted by bidders will be opened online at Time, Date as mentioned in fact
Sheet/schedules of events by University officials or any other officer authorized by University, in the
presence of such of those Bidders or their representatives who may be present at the time of opening.
In the event that no bidders are present, the tender will still be opened as scheduled
The representatives of the bidders should be advised to carry the identity card or a letter of authority
from the tendering firms to identify their bonafides for attending the opening of the proposal.
2.6.6. Tender Validity
The offer submitted by the Bidders should be valid for period of 80 days from the date of submission
of Tender,
2.6.7. Tender Process ing Fee:
Tender Processing Fee as applicable through e-payment mode (i.e, NEFT/RTGS/Credit Card/Debit
Card) on eProc2 Portal,
268. Earnest Money Deposit (EMD }:

* An EMD of Rs, 8,000/- ( Eighteen Thousand only) through €payment mode only (i.e.
NEFT/RTGS/Credit Card/Debit Card) on E-Proc2 Portal or in form of bank guarantee, well before the
last date/time for submission/ uploading of offer/Bid, failing which the bid will be rejected. This EMD
will be non-interest bearing and refundable. If the selected bidder fails to submit the requisite
performance guarantee or to execute the agreement, this EMD will be forfeited ;

*  MSME certificate state of BIHAR or start up agencies registered DPIIT along with Agency registration
with Govt. of Bihar for doing similar work, are exempted from payment of EMD, EMD exemption is
subject to submission of valid registration certificate with the bid. MSMEs with certificates from
outside the Govt. of Bihar shall have to deposit the EMD,

3. Technical Propesal

3.., Pre-Qualification Criteria
Only those Bidders fulfilling the eligibility criteria should respond to the RFP. Eligibility criterion
for the Bidder to qualify this stage is clearly mentioned below, Eligibility Criteria is attached to this
document, The bidder would need to provide Supporting documents as part of the eligibility proof.
The technical bids of only those bidders who qualify in the eligibility criteria will be evaluated.
Document/s in support of eligibility criteria are required to be submitted along with the Technical
Bid. Offers received from the bidders who do not fulfill any of the eligibility criteria are liable to be
rejected.

<!-- page 7 -->

a eS Se ee Se ee ee

3.2. Right to reject Proposal

University reserves the rightto accept or reject any proposal, and to annul the tendering process/Public

Procurement process and reject all proposals at any time prior to award of contract, without thereby

/ incurring any liability to the affected bidder or bidders or any obligation to inform the affected bidder
: or bidders of the grounds for Universit y action,
3.3. Performance Guarantee
The Jai Prakash University, Chapra will require the selected bidder to provide an irrevocably,
unconditional Performance University Guarantee, within 25 days from the Notification of award, for
a value equivalent to 5% of the total cost of ownership. The Performance Guarantee should be valid
for a period of 03 months from the date of award of contract. The Performance Guarantee shall be
kept valid till completion of the supply order, warranty period and till the completion of AMC
contract. The selected bidder shall be responsible for extending the validity date and claim period
of the Performance Guarantee as and when it is due on account of non-completion of the Supply
order and Warranty period.
in case the selected bidder fails to submit performance guarantee within the stipulated time, the Jai

Prakash University, Chapra at its discretion may cancel the order placed on the selected bidder

without giving any notice. Further, the university will extend the supply order to the L2 bidder at

the L! price.

Jai Prakash University, Chapra shall invoke the performance guarantee in case the selected Vendor

fails to discharge their contractua! obiigations during the period or Jai Prakash University, Chapra

incurs any loss due to Vendor's negligence in carrying out the supply order implementation as per
the agreed terms & conditions.

Post submission of Performance Guarantee by the successful bidder, Jai Prakash University, Chapra

shall provide purchase order to the successful bidder.,

4.4. Sub-Contracting, Consortium and Joint Ventures
Consortium, Joint venture, AOP (Association of Persons), subletting, Subcontracting and Outsourcing
will not be allowed.

3.5, Transition And Exit Plan:

i. The Selected Vendor shall ensure that the transition is smooth in case the contract is terminated
or foreclosed with mutual consent. In addition to the cancellation of contract, the University
reserves the right to charge appropriate penalties and liquidated damages from the selected
agency.

ii. All risks during transition stage shall be properly documented to ensure smooth transition
without any service disruption,

iii, The transition plan along with the period shall be mutually agreed between the firm and the
University when the situation occurs. Selected Vendor shall be released from the Project once
Successful transition is done meeting the parameters defined for the successful transition,

4. Terms and Conditions: Applicable Post Award of Contract

<!-- page 8 -->

‘4... Right to Terminate the Process
University reserves the right to cancel the contract entered with the selected bidder and recover
, expenditure incurred by University under the following circumstances; - .
/ a) The selected bidder commits a breach of any of the terms and conditions of the bid,
(

b) The bidder goes into Nquidation, voluntarily or otherwise,

€) Ifthe selected bidder fails to complete the assignment as per the timelines prescribed in the RFP
and the extension iFany allowed, it will not bea breach of contract.

व) The University reserves its right to cancel the order inthe event of delay and forfeit the bid Security
as liquidated damages for the delay,

€) Ifdeductions of account of liquidated damages exceeds more than 0% of the total contract price.

f) In case the selected bidder fails to deliver the quantity as stipulated in the delivery schedule,
University reserves the right to procure the same or similar product from alternate sources at the
risk, cost and Tesponsibility of the selected bidder.

4.2. Liquidated Damages

&) Notwithstanding University’s right to cancel the order, liquidated damages for late delivery at %
(One percent) of the undelivered portion of order value per week will be charged for every
week's delay in the specified delivery schedule subject to a maximum of 0% of the value of the
order value.

h) Liquidated damages for tate comm: issioning at L% (One percent) of the order value per week will
be charged for every week's delay in commissioning to a maximum of 0% of the value of the
order value,

i) Please note that the above LD for delay in delivery and delay in commissioning are independent
of each other and shall be levied as the case may be.

i) University reserves its right to recover the seamounts by any mode such as adjusting from any
payments to be made by University to the bidder. Liquidated damages will be calculated on per
week basis.

4.3. Limitation of Liability

a) Neither party shall be liable to the other for any special, indirect, incidental, consequential
(including loss of profit or revenue), exemplary or punitive damages whether in contract, tort
or other theories of law, even if such party has been advised of the Possibility of such damages.

b) The total cumulative liability of either party arising from or relating to this contract shall not
exceed the total amount paid to the Bidder by the client under that applicable Statement of work
that gives rise to such liability (as of the date the liability arose); provided however, that this
limitation shall not apply to any liability for damages arising from (a) Willful misconduct or (b)
Indemnification against third party claims for infringement,

44. Penalty

a) The Bidder shall perform its obligations under the agreement entered into with the University,
in a professional manner,

i NE dain The Bidder should perform all the activities as per timelines and eters stipulated b

8 \ 7

<!-- page 9 -->

pO
University in this RFP, failing which University may at Its discretion impose penalties on the
Bidder as defined in the RFP. ‘The penalties on the deli very will be deducted from the payment
to the vendor@0.5% of the Project cost per day subject to. a maximum of 0% or termination of
the contract.
4.5. Dispute Resolution Mechanism
In case any dispute between the Parties, does not settle by negotiation in the manner as mentioned
above, the same may be resolved exclusively by arbitration and such dispute may be submitted by
either party for arbitration within 20 days of the failure of negotiations. Arbitration shall be held in
Bihar and conducted in accordance with the provisions of Arbitration and Conciliation Act, 996 or
any statutory modification or re-enactment thereof. Each Party to the dispute shall appoint one
arbitrator each and the two arbitrators shall jointly appoint the third or the Presiding arbitrator.
The Provisions of this RFP shall be governed and construed in accordance with the Laws of India
and would come under the exclusive jurisdiction of the Courts in Saran, Bihar.
4.6 Force Majeure
Force Majeure is herein defined as any cause, which is beyond the control of the selected bidder or
University as the case may be which they could not foresee or with areasonable amount ofdiligence
could not have foreseen and which substantial ly affect the performance of the contract, such as:
* Natural phenomenon, including but not limited to floods, droughts, earthquakes and
epidemics.
* Acts of any government, including but not limited to war, declared or undeclared priorities,
quarantines and embargos
* Terrorist attack, public unrest in work are aprovidedeitherpartyshallwithinl 0days from
occurrence of such a cause, notifies the other in writing of such causes,
The bidder or University shall not be liable for delay in performing his/her obligations resulting
from any force majeure cause as referred to and/or defined above. Any delay beyond 30 days shall
lead to termination of contract by parties and all obligations expressed quantitatively shall be
calculated as on date of termination. Notwithstanding this, provisions relating to indemnity,
confidentiality survive termination of the contract.
4.7. Fraud or Corrupt Practices
a) The Bidders shall observe the highest standard of ethics during the Bidding Process. and after the
issue of the Letter of Intent (LOI)/Work Order (WO) and during the Subsistence of the Agreement.
Notwithstanding anything to the contrary contained in this RFP, or in LOI/WO or the Agreement,
the University may reject a bid, withdraw the LOI/WO, debar the bidder for a period of one year
from participating in the future projects of the University or terminate the Agreement, as the case
may be without being liable in any manner whatsoever to the Bidder, if it determines that the
Bidder has, directly or indirectly or through an agent, engaged in Corrupt practice, fraudulent
practice, coercive practice, undesirable practice or restrictive practices, In such an event, the
University shall, without prejudice to its any other rights or remedies, forfeit and appropriate the
Bid Security or Performance Security as mutually agreed genuine Pre- estimated compensation
and damages payable to the Authority for, inter alia, time, cost and effort of the Authority, in
regard to the RFP, including consideration and evaluation of such Bidders Proposal,
2) as re \

<!-- page 10 -->

f b) Without prejudice to the rights of the University under Clause above and the rights and remedies
which the University may have under the LOI /WO or the Agreement, if a Bidder, is found by the
Authority to have directly or indirectly or through an agent, engaged or indulged in any corrupt
practice, fraudulent practice, coercive Practice, undesirable practice or restrictive practice during
the Selection Process, or after the issue of the LOI /WO or the execution of the Agreement, such
Bidder shall not be eligible to participate in any tender or RFP issued by University during a period
of l (one) year from the date such Bidder Is found by the University to have directly or through an
agent, engaged or indulged in any Corrupt practice, fraudulent practice, coercive practice,
undesirable practice or restrictive practice, as the case may be.

¢) For the purposes of this Section, the following terms shall have the meaning here in after
respectively assigned to them:

i, "Corrupt practice” means the offering, giving, receiving, or soliciting of anything of
value, pressurizing to influence the action ofa public official in the process of tendering
and execution of the project.

ii, “Fraudulent practice” means aim is representation or omission of facts or disclosure
of incomplete facts, in order to influence the Selection Process,

iii, “Coercive practice” means impairing or harming or threatening to impairer harm,
directly or indirectly, any persons or property to influence any person participation or
action in the Selection Process.

iv. "Undesirable practice” means (i) establishing contact with any person connected
with or employed or engaged by University with the objective of canvassing, lobbying
or in any manner influencing or attempting to influence the Selection Process; or (ii)
having a Conflict of Interest.

v. “Restrictive practice” means forming a cartel or arriving at any understanding or
arrangement among Bidders with the objective of restricting or manipulating a full and
fair competition in the Selection process,

5. Technical Requirements and Evaluation

5,I. The Technical Bid for qualification stage should be complete in all respects and contain all
information asked for in this document. Price information should not be submitted along with

technical bids, if submitted along with technical bid, offer shall be rejected as non-responsive,
S..... During the period of evaluation, bidders may be asked to provide more details and explanations
about information provided in the proposals. Bidders should respond to such requests seeking
explanation time frame indicated in the portal or vendor email (provided in portal), ifthe bidder
does not comply or respond by the date, their bid will be liable to be rejected. It is the
responsibility of bidder to monitor the portal or vendor email (provided in portal) every now and
then in order to ascertain any exceptions are raised or clarifications are sought by University post
last date of bid submission. No separate intimation will be made by University to the participated

bidders for responding to the clarification sought.

5.2. Setting of evaluation criteria for selection purposes shall be entirely at the discretion of the
University. The decision of the University in this regard shall be final and no correspondence shall
be entertained in this regard,

5.I,3. The University may, atits discretion, waive any minor informality, nonconformity, or irregularity
in a bid which does not constitute a material deviation, Provided such waiver does eee prejudice
