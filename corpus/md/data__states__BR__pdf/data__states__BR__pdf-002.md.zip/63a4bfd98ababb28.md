---
doc_id: "63a4bfd98ababb28"
source_url: "https://bsbccl.bihar.gov.in/New_V/UploadedImage/TenderPDF/151146.pdf"
ministry: "Bihar State Building Construction Corporation Limited (BSBCCL)"
title: "Sri Rajeev Kumar,S/O-Late Gyanchand Prasad Sinha,Mohl.-Mohanpur,Punaichak,patna"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "343b79e156ae87e1"
---

<!-- page 1 -->

q-{iErrcr+{-i 3/erfroco(Ro)-oa-R<iqqr+tft-W-os/2o1s .... -. -/

kort e-{c6rc
qfi Frqtqr hqFr
s{aEg

qqq Ffrerdr, ffisp rrq rrqq Frqtqr Hr,q Ro, qrcr * q{id,'f,rqizF-149
frqis-12.61 .201e Er<r qftAFf, fuq1 q-q1 B ({i+<m) * erosr Sqr{, Bar-S
kqruq Rie, nqi Terc, tts i'o-oa, Tfis rI{, q-{r * arr Borr rrq :rqq
Frqfq hqq Ro } qrqtoq A Fpid RREI snqa-r qqnr €cqT e6/2o1a-19 \
enF-f, sr4 "ft66 qq qqq Frqisr ft.rq Ro, tre-cr * g@{oq wrc E6rqfrrq
+ vfrc Fiqrkqq +r Fnrt'r sr4" fr FtrEt ?i sBD d 6B+1 +.-iA(b) * ocn

c€dr t-g Project Managero NBCC (INDIA) LTD, SBG O1}ice, Patna(Bihar) *'

q-{is-gze, ftqi6-1 1 .11 .2C-17 sf{I ffi( qqF,t q;t {if,--r F5qT Tql, Gr
d"+q{r< qfr qrqr .rqrt Erl+ Rc eft g'rx ti q"iq Ffurr+ fr {rqisq +
v*ia-33651*o), B.rio-za.t2.2o1a * sru <l€tr{"r di .ii,r +lt .rfr t rc+
A;1r Hqffid rqd-crq {S-s11 Arrq n$ qgr rprTt qEiq ftiqqp, fua1 rrq elzt=r
Rqfsr f{q Ro, qrcr il{r F6R fri;sTtl fuitt{ Frqqqdr zooz ti iiF{o
cH8rrq + etrarcF H (enql 3il er6q gET{, fudT-sft fuqRlq Rjo, rrql :rqq,
irs io-oe, ,rrfiq q.n, qeolr +' F=iE{ €o-BCD uem(qfu6,Td)-ze(tqq)zzota
+r srd-t( +-{t fr ergriut +1 .r*t
R{iEF-18.02.19 dr erlq-iif,r cgq-s6-€Trrr Brrgrc-€E-fua\tq lrE.q, t{Eq
Frqlsr EqlT fr erei{qrflr ti ':rr*e-o €A{Si +' fiqiEm.cnTdi+-pT rfrqt +6.n t

{€ qqt qr ffirq<r< rdtR sRr {i}{;n {i srour :Eqrt t i'1rt'1q1ur Xsfr
6r R"fq fuq1 rq1 f,{grlr< frqr,tq q+iq-zrs+ f}qi6-25.92.19 aro ri=+++ il
sq+-{q Ern rrcr sq1 f{qpftq q+iq-gss+ f{niq-s3.s4.1e Elrr dAffi +T

rqqf,{-r t-g qrRf, B-q rrql
frqiza-1s.s4.1e fr rlfren
{frffi +ft ersq gqrr t cr<
frqiq-26.66.19 +T 3{-+pifl qgcr-Tr6-orqr srrT< eE-tr}r.r 'ri't r. .1q1 pffi1
Esrr.r dl ersqqr<fl t .:rErho {i?r<Si + ts<iffi/-fliftf,{or nq{i .igq ri rlRR
ar{T fr .r{r qfr*rqrr< {n-qm + {c€o<rt fr1 slqfq .n.t Ec r"iq FfrsTfi,
kan lrq rrq-q Bqior F+.n fto, qrcr fr orgrir+r *' crrc]m t f+<+ +
fuierc +r fi-q ers + nt md-W +-G +t ftryfq flq rq1
qRR sm Rr} qA Ft"fu + €iltr6 ti &{s sft srt"r gqR, kf,r-sft
RqrrF{ frE, qrqf rr+c, irs io-os, rrfiq q.n, qrq * F[4?rc tio-BCD
wr(q6,6;-ze(ttr)tzot+ *r .:rRqt FFto ai fi filfq t os(ma) +ai *
Ra ffi-dq_d Bqr qrot tt
flqqrtl+1aq1

60/-

eTfYriaT qgq-qE-\3T-rt cng-.r.r ,.r2-filrv aB<

sl{q fiqiur Errn, iqorr, rr.]lt

Athi.sh r 6xfi).bryi4aadsh 14s

il

<!-- page 2 -->

ilqi-+-qqq- r szerlqoco (tro ) - 0 3 -Riifi /-cnrd-q-d' o s / 2 o 1 s " " "

"' qslr'Fqi6-

qRRR,-4 erqsr tqR, Ror-*ft ruqrn.q nie, erqi gr{q' trc io-oa
q+<rtt
rrdrq q.n, qrcr * B=i*ra €o-BCD rern(aft55)-ze(tal,)tzot+ *r
q'.i srrqrqfi slH t-g i'tr-f,l

60/eimiil cgq-so-errc errg<-rlo-Etv uH<

gfrfrB:-qqFl sl?s' +' qqrc ertrT qEq' eltrc Rqiq E+rrrr'zefq-didr
qgq-{6-ercr{ srT-gffi-qE-Etlt{ qEE + 3 kl (tr''q' rlzl=I FEilr E rFtzqq
Efir€
Rqtq E.rnzqq Tiqrr{ trsTrrrzdrfi ER€rq efqziaq i}t1Fl7{rr<
tr.nrzsqi Rqrrzqrfiq qrd ftqrqzgq r€rqtiqfi(qH'rq{r)' Bdr{ BE.-flr FrqFT
-+Tqtii
q-{rzu*
erfEzifl'
gw
mf;,
Frrq
riTq-r'r
1ro"
G **..1o

F]TIiurtrqrrT/Sqefqziflnrw{rqiB6ruE,TFr/g.iqFiqercF,kerr<rqsrfi
tnlqtet }R.al
Frqt,,'i Fflq *0, *-cr *r qaqTei si enqq{tr
€O/eTlq"iil cgq-g6-srtneilg-df, -r{6-Ee=rq HEq
.fl.t,f-o*- 2 6'?' 19
anqis-e*{-r 3zerf-r+ouo(tr0)-03-Bdqqrq;16a-d -orrro.r9??.1
q1 e+rdrs
qRRR:-sr€o ao Ai-q{, Taq Frqlur frqlr 4r Eqtrftq a4fl6d

:trG ?-g \Rf,r

Brl+iil

o'ii",n, o-",r

",",o."+".

&f.ur
qgq-{r6-3rq{ :nTro-rfe-trQtv strq
