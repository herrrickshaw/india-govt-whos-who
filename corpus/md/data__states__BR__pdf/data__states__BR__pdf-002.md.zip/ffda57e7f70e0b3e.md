---
doc_id: "ffda57e7f70e0b3e"
source_url: "https://bsbccl.bihar.gov.in/New_V/UploadedImage/TenderPDF/162737.pdf"
ministry: "Bihar State Building Construction Corporation Limited (BSBCCL)"
title: "M/s Shivani Infratech Pvt. Ltd.,Sarboday nagar,Begusarai,Bihar."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "052fdbe86692b9ce"
---

<!-- page 1 -->

f{6rq trcq qrq ffiq f,+.rq fuFrds
f+grq lrron iD-I \r.D'scog
aStqr{e: www. bsbccl.bihar.gov.in

BIHAR STATE BUILDING CONSTRUCTION CORPORATION LTD.
A Government of Bihar Undertaking
Website: wurv, bsbccl.bihar.qov.in

a-;-

q-dio- frogqofroqfrorftogao-qilrqsro (ql$ut)-oa+ /2024 .'

tq'1tcr,:

srqftrq srrt{r riqr - 1-8 I/.2-o>rt
ftqrfi'-02.08.2o24 oi Performance Committee q't ildfr q ftd qt
e{fi-rs d qro F{€-4q-2 d ei-'il.fd Tata'Technology d $6qtT €

ffq d qr-dtfr d srq
ffifuo cRIeTq' e-{erl-{,

EfuqL t.Jiwrq fr q-ftffi \'q ffiq 61 ffiu1 6.Id d fuq Sfli fuq .Tg q-iq-6 M/s Shivani
Infratech Pvt. Ltd., Sarboday Nagar, Begusarai, Bihar F) gqn 5w fuet qrot t,€,0/SrsI rI6Tqi{'Er6
FcsR rrsq rlaq Frqiq f,+'rq ft6. qdcT
I

wqro-

RqTo-

/oa/zoz+

sfrfufr:- IWs Shivani Infratech Pvt. Ltd., Sarboday Nagar, Begusarai, Bihar d qqcTrf
ift-o

r

Eo/5W rAru-<WO

flqro- 3oZa

R-flo- /o / /
os

Ran vrq rrq-{ ffTI ftrq fr0. qe=TI

I

zoz+

eftftfr:-{n{o8o tiqs, G-sR trGq rflq Frqtq ft.n ft0, qsil o) qamef ifuo r ftepT t fu
---\
o1 q-fr frqq ffie tl-{ yfiq sTq-d}-s qrt-cr gfrRaa of
t

'' /'/q?87 'tp'r^,

5W r6rreu-o

ftgR 11q r14q ffq

ftrrq ft0. qd=1|

C''

kdfud orqfcqr frowofro$orfroga, ffdira lts. {nS ;Frt, qeqr-8ooo23, K{rIFt: +ei-6l2-22a4a61, fry: +s1-612-22aotzn. {-}6,6r6r.1@bihar.gov.in
Registered Office: BSBCCL, Hospital Road, Shastri Nagar, Patna - 800023, Telephone No.: +91.612.2284861, Fax: +91-612.2280324, Email: bsbccl@bihar.gov.in
