---
doc_id: "22a465fbd53efbbb"
source_url: "https://www.jpv.ac.in/_files/ugd/732218_2812f165b6814615b55070fee3798480.pdf"
ministry: "Jai Prakash Vishwavidyala (University), Bihar"
title: "Tender No. JPU/01/CE/2026—Supply 32Pages Partial BarCoded ANSWER BOOKS(19.02.2026)    (RFP available for Download)"
date: ""
pages: 20
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "cf7f31700b565508"
---

<!-- page 1 -->

&छ जय प्रकाश विश्वविद्यालय
जन राहुल सांकृत्यायन नगर, छपरा-844302, बिहार (भारत)
पट JAI PRAKASH UNIVERSITY
ae RS) RAHUL SANKRITYAYAN NAGAR, CHAPRA-84302, BIHAR (INDIA)
Email Id:- regjpuchapra@gmall.com Website:www.]|pv.ac.in
Letter No... Dated:- IS] 0a\o0a6
निविदा आमंत्रण सूचना सं - IPUIOICE./2026
आंशिक बार-कोडेड उत्तरपुस्तिकाओं की खरीद हेतु प्रतिष्ठित एजेंसी/फर्म से
मुहरबंद निविदा निम्न विवरण के अनुसार आमंत्रित किये जाते हैं :-
कार्य का नाम निविदा प्रपत्र | निविदा | खोले जाने की | निविदा | अग्रधन की
एवं मात्रा बिक्री की तिथि | प्राप्ति की | तिथि, समय एवं | प्रपत्र का राशि
अंतिम तिथि स्थान मूल्य (Earnest
एवं समय Money)
पुस्तिकाओं की प्रारंग तिथि -
आपूर्ति पं 20.02.2026
nee वाली अंतिम तिथि - | 44.03.2026 | 46.03.2026
आशिक 43.03.2026 RTE | SORTA 04:00
, . | Rs.,60,000/-
बार-कोडेड - 05 (कार्यालय-अवधि | 05:00 बजे बजे 23700 06700:
ome में (कुलसचिव
40:00 पूर्वाह्न से प्रकोष्ठ)
05:00 अपराहून
तक)
निविदा का विस्तृत विवरण विश्वविद्यालय के वेबसाइट ७५४०४ पर उपलब्ध है
जहाँ इसे देखा एवं डाउनलोड किया जा सकता है। सक्षम प्राधिकार के द्वारा बिना कोई
कारण बताए निविदा को कभी भी निरस्त किया जा सकता है।
माननीय कूलपत्ति महोदय के आदेश से
wae
4 \ . qrar el
(परो.(डॉ.) नारायण BPS sie २
#52॥॥ 800 ॥०९ #८७२८५८८७७7(७५7३०॥/00००४ऋ०॥/शरव्ड्/बव एल। caf ५ by डुलसचिय £ aes
a MM A\30 902.0. AB docxvitath Lumar

<!-- page 2 -->

Sms PRAKASH UNIVERSITY, CHAPRA
SARAN, BIHAR - 84302
| TENDER DOCUMENT |
| FOR |
Printing and supply of 32 pages Answer-Books (With partially
bar-coded OMR sheet as cover page)
Po |
|
|
ee wi
| Yn
RE gistr a” icy
: Jai Paka
i|Page

<!-- page 3 -->

= NAME
: Schedule of Expression of Interest
Si. No. Items LL eee ee
2. Name of the work | I. Printing and supply of 32 pages partially bar-
coded Answer-Books (With bar coded OMR
sheet as cover page) :
3. Date for obtaining of Between 20-02-2026 to 3-03-2026
Bid D t
aT: (0:00 AM to 05:00 PM)
Last date and time On or before up to 05:00 PM of 4-03-2026
for receipt of bids only through Registered Post/Speed Post.
3. Date and place of 6-03-2026 at 0:00 PM
opening of Bid —_|Office of the Registrar, Jai Prakash University, Chapra
ह रिक्याए। $शांरियो५/8५क १४९७, (.॥898-84]302, छा॥ववा
(India)
Vendors are requested to read the complete tender documents before submission of
Bids.
४ Other important information related to Bid
Si. No. Information Ben...
Cost of tender Documents: (To be paid | Rs.0,000/- (non-refundable)
offline at the time for obtaining of Bid] as D.D. issued in favour of
Document or it can be placed along with | Registrar, Jai Prakash University,
downloaded tender documents.) Chapra
2. | Bid-Security (Earnest money) To be
paid in the form of Bank DrafVF.D.R. | Rs. ,60,000/-
duly pledged in favour of “Registrar,
Jai Prakash University, Chapra”)
है 2|[?१86
egistrar |
है an University
Chapra

<!-- page 4 -->

ee ng
छः Contract Performance security: 0% of Bill amount and shall
: be released after successful
completion of work order,
| ie Warranty Declaration Annexure-III
है Invitation of BID :
Procedure for submission of Tender/EOI (Expression of Interest): Vendors
proposing to submit the Tender/EOI, may visit the University’s website.
www.jpv.ac.in for details of Bid document and other ‘T’ & ‘C” of the tender/Eol
including details of scope of work and the desired prerequisites. Any amendments
updates to Eol (Expression of Interest) or its terms and conditions will be uploaded on
official website of the university. The EOI has to be submitted in the prescribed
proforma along with all the supporting documents in compliance with the requirement
of the Tender/Eol.
Please refer information and guidelines mentioned below for submission of tender.
General Instructions, term and Conditions:
The tender document can be obtained from the office of Registrar, Jai Prakash
University, Chapra, Saran, Bihar -84302 or it also can be downloaded from the official
website of J P U Chapra between 20.02.2026 to 3.03.2026 up to 5:00P.M. The tender fee
of Rs. 0,000/-(RupeeTen Thousand) only is non-refundable , non-adjustable and non-
transferable and is payable through a demand draft on any nationalized bank drawn in
favour of the “Registrar, Jai Prakash University, Chapra” along with request on firm
letter head. The signed tender paper and all enclosures (Technical bid and Financial bid)
should reach in the office of the Registrar, Jai Prakash University, Chapra latest by 05:00
-P:M of 4.03.2026 in sealed manner by registered post/speed post only.
Instructions to Bidders
l. Incomplete bids, amendments and additions to bids afier opening of bids are
liable to be ignored/rejected by Jai Prakash University, Chapra, Saran.
- 3|Page
; $ ar -
Regist ‘
enn qversity
Jai Pt a

<!-- page 5 -->

& The bidder shall be responsible for the delivery of the materials, as per

specifications listed in the tender and at the sites allocated by the University
- within the stipulated time of three weeks.

3. A D.D/F.D.R. Rs. ,60,000/- which shall be drawn/pledged in favour of
“Registrar, Jai Prakash University, Chapra”, should besubmitted towards
Earnest Money Deposit (EMD) which must accompany with the bid; Bids

~ without EMD will be rejected. The EMD will be refunded to all the unsuccessful
bidders only after the work order placed to the successful bidder. Thesuccessful
bidder’s EMD will be converted to security deposit upon the bidder’ sacceptance
of the award of contract.

4. The bidder’s security may be forfeited-

(a) If the bidder withdraws his bid during the period of bid validity specified in
contract/agreement. | हि

(b)If the successful bidder fails to sign contract/ agreement within 07 days from
issue of letter of intent or award of tender.

5. The prices must be quoted in the format as specified in the tender document, and
should be inclusive of packing, forwarding, insurance, delivery at sites, duties
and taxes applicable. - -

6. All items, deliverable and price mentioned in the tender document should be valid
for acceptance up to a period of 3 months. The bidders should be ready to extend

the validity, if required by the University.

7. The bidder should commence work as per the scope mentioned in the tender
documents within ] (one) week from the date of issue of final order and/or

. entering into contract and ensure the supply of ordered items.

8. Bidders should enclose their bids with all requisite documents specified and full
details of all related experiences with documentary proofs.

9. Jai Prakash University, Chapra reserves the right to select certain items (in single
ormultiple units) and reject the other mentioned in the tender document without

: assigning any reasons whatsoever Jai Prakash University, Chapra also reserves
- the right to revise or modify or cancel the specification of the items before the
acceptance of any bids.
4|Page
: Registrar
- Jai Pyakach University

<!-- page 6 -->

= Terms and Conditions:-
_ . Performed similar work at central/state institutions will only be considered.

2. The Manufacturer self-declaration stating that he/she is not banned/debarred or
black listed by any Central/State Govt. of India/PSU/Organizations/Institutes in
India or abroad. Undertaking for the same shall be submitted by the bidder in the
company letter head.

~ 3. The buyer reserves the right to ask for samples of the quoted product before the
financial bid opening or final supply. If the samples are passed, then only order
will be finalized/complete supply will be sought.

4. Paper must be lab tested (Govt. Body) as specification with bid no. .

_ 5. Separate Affidavit Rs. 000 stamp paper by * class/2™ class magistrate must be
submitted by the bidder for acceptance of Bid ATC.
The sealed bids should be addressed and delivered by registered post or speed post
only:
Address:
Registrar
Jai Prakash University,
Rahul Sankrityayan Nagar, Chapra
Saran, Bihar, PIN Code — 84302.
yo
५ rt
Rest ess
ya PS +%ऋए
5|Page

<!-- page 7 -->

=
The corresponding sealed envelopes should be titled as “Printing and supply of 32 pages
Answer Books (with partially bar-coded OMR sheet as cover page) and address
mentioning the notification number to “The Registrar, Jai Prakash University,
Chapra and all the bids must reach on or before 4.03.2026 up to 05:00 PM Bids
received after the specified time will be rejected and no information will be sent in this
regard.
The University is not under obligation to accept the lowest bid on any bid and reserves
the right of accepting the whole or any part of the bid or portion of the quantity offered
and the bidder shall supply the same at the rate quoted. The Registrar on behalf of
Jai Prakash University, Chapra reserves the right to reject any or all offers received in
response to tender or cancel or withdraw the tender notice without assigningany reason,
whatsoever.
Any ‘specific queries/clarification of the documents may be asked from the
Registrar, Jai Prakash University, Chapra in writing not later than 5(five) days before
the proposed submission date. Any request for clarification in writing or by other
‘suitable medium of communications must be sent to the Registrar, Jai Prakash
University, Chapra They will respond by e- mail only to such request.
The bidder must enclose a copy of GST certificate, PAN Card, Tax Audit Report of
last 03 years financial statement and all other details required under eligibility criteria.
All bidders should enclose an affidavit by the First-Class Magistrate of a “Warranty
Declaration” of their firm/company’s in their bids as detailed below:
“We-shall abide by all the specification, term and conditions listed in the tender
document.
We warrant all deliverable to be supplied by us as part of the tender shall be free from
all defects and faults in materials, workmanship. All products and services shall be of
the highest quality, material and services of the type ordered, shall be in full conformity
with Specifications therein.
We accept that any deviations in the materials and/or services from that specified in the
tender document and the accepted terms are liable to be rejected. The bidder will be
-bound to supply all the goods in the specified form to the specifications as per the
order/contract and demonstrate the same at their own cost.”

९१

2०4३7 nies
ape eh eS

so । siPase

४ |

|

<!-- page 8 -->

tn |
= SPECIFICATION OF REQUIREMENT
A. Specification of Answer book with OMR/Barcode
se
rE
Cover and last page of| !.Cover pages with bar-coded OMR with details
the Answer booklet | given in the appendix as persample.
Peau) * 2. 20 gsm Maphlitho for cover pages
3. OMR sheet should be in three perforated fold.
5: Quality of other paper | l.Each and every page for 70 gsm Maphlitho.
2.Portrait format
: 3.Fine quality (ink should not spread while
writing).
: 4. Not less than 80% brightness
: 5. l- inch margin line in the left side of the paper.
6. Each page must contain parallel lines for writing
leaving I- inch top margin as per sample.
i a Fo - - 7) Page
yt os Bao

<!-- page 9 -->

f = Specifications |.All the pages of the answer book should be
perforated with JPU .
है 2. Continuous serial number on OMR Front cover
pages with each answer book .
3. The answer book and OMR sheet should be
stitched with thread .

Ts Packing Packing shall be done of answer book in the bundles
of 200 answer books in the moisture proof
corrugated box, mentioning the quality and serial

- number on top.

[ain Printing as per specified sample of University.

‘ Delivery The vendor shall deliver the number wise answer
books to the store room of the office and arrange the
same serially. The complete order must be delivered
within three weeks.

ww
\ ‘
gre
३9८ 5 8|?28९

<!-- page 10 -->

= IGIBILITY CRITERIA FOR THE BID

Below mentioned is the minimum eligibility criteria decided by the university to
identify suitable/prospective bidders; whose technical criteria bids will be opened for
the review by the University evaluation Committee.

SL... | Eligibility Criteria for the Bidder | Documentary Evidence to be attached

No.

i) Should be __ Government | For a registered Company/Agency/Firm
organisation/ Government | Registration Certificate issued by
undertaking or a company/| competent authority.

~ | registered/Partnership firm(
Companies/Agencies/Firms not
registered in India’ need not to

; apply).

ii) ~ | The Organization/Company/ | I. Purchase Orders/ Agreement copies.

Agency/Fi d to h

vo im need to nave 9 TI. Last 3 years audited balanced sheet
minimum total turnover of Rs. 0 és
along with GST annual return.

4 crore (one crore) for last three

(3) each financial years and (i.e. FLY. 2024-2025, 2023-2024 and

~ | should be profit making company | 2022-2023)
fit tax). ‘

(peotinatteetas . III. Turnover certificate by chartered

i Accountant.
७28८६. siPage
ao! 5 :
; sar BP One®
