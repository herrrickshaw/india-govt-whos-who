---
doc_id: "45fbbb3fcaafed20"
source_url: "https://basu.org.in/wp-content/uploads/2018/06/WALKING-IN-INTERVIEW.pdf"
ministry: "Bihar Animal Sciences University (BASU)"
title: "WALK-IN-INTERVIEW for the post of Dy. Registrar (Academic), Dy. Registrar (Examination), Dy. Director Resident Instruction, Dy. Director Training Information."
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "ace4c6da5417b367"
---

<!-- page 1 -->

बिलार पशु विज्ञान विश्वविद्यालय
बिहार पशुचिकित्सा महाविद्यालय प्राँगण, पटना- 800074
BIHAR ANIMAL SCIENCES UNIVERSITY
BIHAR VETERINARY COLLEGE CAMPUS, PATNA — 8000I4
Ph. No.: 062-2226644, Fax No. 062-222223, Email : registrarbasu@gmail.com
L.No. 8//8/7०४./8७5 U, Patna Dated .. as ../06/208
NOTICE
As there no candidate found suitable for the post of Dy. Registrar (Academic),
Dy. Registrar (Examination), Dy. Director Research, Dy. Director Resident
Instruction, Dy. Director Training Information. The Walking-in-interview for this
post scheduled to be held on 2.06.20I8 & 3.06.208 is cancelled.
ee acl
shat sean SET a
BC Campus,Paine
SWReg. Cell/May,I8
