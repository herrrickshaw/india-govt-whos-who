---
doc_id: "7ebdaab8e3ab5db6"
source_url: "https://nalandauniv.edu.in/wp-content/uploads/2026/02/Corrigendum-03.pdf"
ministry: "Nalanda University"
title: "Corrigendum-03"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "49346d17363794a8"
---

<!-- page 1 -->

20.02.2026

Digitally signed by Manoj
Kumar
Date: 2026.02.20 15:40:16 IST
