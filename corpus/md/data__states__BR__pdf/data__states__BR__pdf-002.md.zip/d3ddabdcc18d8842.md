---
doc_id: "d3ddabdcc18d8842"
source_url: "https://bsedc.bihar.gov.in/media/publications/primary/Policy_for_Internship_Programme_on_Emerging_Technologies.pdf"
ministry: "Bihar State Electronics Development Corporation Limited, Beltron, Patna"
title: "Policy_for_Internship_Programme_on_Emerging_Technologies.pdf"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c9822487fbe4678d"
---

<!-- page 1 -->

<!-- page 2 -->

BELTRON’s
Hands-on
Training-cum -Internship Program
on
Emerging Technologies
for
B.Tech / M.C.A./BCA Students

Bihar State Electronics Development Corporation Limited
(A Government of Bihar Undertaking)

BELTRON Bhawan, Shastri Nagar,
Patna – 800 023, Bihar
Phone: 0612- 2281242, FAX: 0612-228 1857

Page 1 of 6
Hands-on Training cum Internship Program on Emerging Technologies for B.Tech/MCA/B.Com Students

<!-- page 3 -->

Contents
1.

Background: .............................................................................................................................. 3

2.

Program Overview .................................................................................................................... 3

3.

Program Methodology .............................................................................................................. 3

4.

Internship Deliverables............................................................................................................. 4

5.

Detailed Track Modules............................................................................................................ 5

6.

Learning Outcomes ................................................................................................................... 6

Page 2 of 6
Hands-on Training cum Internship Program on Emerging Technologies for B.Tech/MCA/B.Com Students

<!-- page 4 -->

Hands-on Training cum Internship
Program on Emerging Technologies for
B.Tech/MCA/BCA Students
1. Background:
BELTRON has been playing a pivotal role in strengthening Bihar's IT ecosystem and promoting digital
governance initiatives. With rapid advancements in Artificial Intelligence, Cloud Computing, Cyber
Security, Data Analytics, Generative AI, Blockchain and Digital Public Infrastructure, there is an
increasing demand for industry-ready skilled manpower.
At present, a significant gap exists between academic curriculum and industry requirements. To bridge
this gap, BELTRON proposes to launch a structured internship and industry readiness program on the
lines of premier institutions such as Centre for Development of Advanced Computing (C-DAC).

2. Program Overview
Parameter
Duration
Target Audience
Fee Structure
Batch Size
Program Frequency
Mode

Details
4–8 Weeks (80–160 Hours)
B.Tech CSE/IT/ECE or MCA or BCA Students
₹5,000.00 (All Inclusive) for 04 weeks and ₹10,000.00
for 08 weeks
50% Concession for PH/SC/ST/EWS/Women Category
10 trainees at a time
Throughout year
Hands-on Training, Practical Laboratory Work, Guided
Assignments and Project Development

Mode of Selection

First cum First Serve basis

Certification

BELTRON Hands-on Training Certificate + Project
Completion Certificate

3. Program Methodology
The program shall be delivered primarily through practical hands-on learning, guided laboratory
exercises, technology workshops, real-world assignments and project implementation activities. The
emphasis shall be on developing industry-relevant technical skills through experiential learning rather
than conventional classroom teaching.
At least 70–80% of the program duration shall be devoted to practical work, project development, usecase implementation and interaction with technical mentors.
Page 3 of 6
Hands-on Training cum Internship Program on Emerging Technologies for B.Tech/MCA/B.Com Students

<!-- page 5 -->

4. Module Structure
Duration: 4–8 Weeks
Module 1: Foundation & Technology Orientation
Parameter
Duration
Topics
Format
Assessment

Details
1 Week (15–20 Hours)
Python Programming, APIs, Git/GitHub, Data
Structures, Development Environment Setup
Guided Practical Sessions and Hands-on Exercises
Coding Assignments and Mini Project

Module 2: Emerging Technology Specialization
Parameter
Duration
Tracks
Format
Assessment

Details
1–2 Weeks (20–40 Hours)
AI/ML, Generative AI, Cloud Computing, Cyber
Security, IoT, Blockchain
Practical Labs, Tool-Based Exercises, Use Cases and
Industry Scenarios
Track-Based Assignment and Prototype Development

Module 3: Industry Project / Capstone Project
Parameter
Duration
Format
Deliverables
Assessment

Details
2–5 Weeks (40–100 Hours)
Hands-on Project Development under Mentor Guidance
Functional Application/Prototype, Documentation,
Presentation and Demonstration
Project Evaluation, Technical Viva and Final
Demonstration

4. Internship Deliverables
Each participant shall be required to:
 Complete practical assignments in the selected technology domain.
 Develop a functional project or prototype.
 Submit source code and project documentation.
 Present project outcomes before the evaluation panel.
 Demonstrate practical understanding of industry-standard tools and technologies.

Page 4 of 6
Hands-on Training cum Internship Program on Emerging Technologies for B.Tech/MCA/B.Com Students

<!-- page 6 -->

5. Detailed Track Modules
TRACK A: ARTIFICIAL INTELLIGENCE & MACHINE LEARNING
Week

Topics

Week 3

Python for AI, NumPy, Pandas, Data Visualization

Week 4

ML Algorithms, Scikit-learn, Model Training, Deep Learning Basics

Project

AI-based solution (e.g., Image Classification, Chatbot, Prediction System)

TRACK B: INTERNET OF THINGS (IOT) & EMBEDDED SYSTEMS
Week

Topics

Week 3

IoT Architecture, Sensors, Arduino/Raspberry Pi, MQTT Protocol

Week 4

IoT Platform Integration, Cloud IoT, Real-time Monitoring

Project

Smart Home/Agriculture/Healthcare IoT System

TRACK C: CLOUD COMPUTING & DEVOPS
Week

Topics

Week 3

Cloud Fundamentals, AWS/Azure Basics, Docker, Containerization

Week 4

Kubernetes, CI/CD Pipelines, Cloud Deployment

Project

Cloud-based Application Deployment with DevOps Pipeline

TRACK D: CYBER SECURITY & ETHICAL HACKING
Week

Topics

Week 3

Network Security, Cryptography, Vulnerability Assessment

Week 4

Ethical Hacking Tools, Penetration Testing, Security Auditing

Project

Security Audit + Penetration Testing Report on Sample System

Page 5 of 6
Hands-on Training cum Internship Program on Emerging Technologies for B.Tech/MCA/B.Com Students

<!-- page 7 -->

TRACK E: BLOCKCHAIN & WEB3
Week

Topics

Week 3

Blockchain Fundamentals, Smart Contracts, Solidity

Week 4

DApp Development, Ethereum, Web3 Integration
Blockchain-based Application (e.g., Supply Chain, Voting

Project
System)

6. Learning Outcomes
Students will be able to:


Master advanced programming and emerging technology fundamentals



Build at least 1 complete project in chosen technology track



Gain hands-on experience with industry-standard tools



Prepare for campus placements and industry roles



Earn BELTRON certification recognized by industry

Page 6 of 6
Hands-on Training cum Internship Program on Emerging Technologies for B.Tech/MCA/B.Com Students
