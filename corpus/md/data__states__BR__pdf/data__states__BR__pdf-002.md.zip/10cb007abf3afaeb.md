---
doc_id: "10cb007abf3afaeb"
source_url: "https://csbc.bihar.gov.in/Advt/BHG/Notice-14-01-2021.pdf"
ministry: "Central Selection Board of Constable, Patna, Bihar"
title: "Important Notice:  Regarding amendment in Written Exam Centres of  Rohtas District ."
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0a6e6c3f80fa80be"
---

<!-- page 1 -->

dsUnzh; p;u i"kZn ¼flikgh HkrhZ½

ljnkj iVsy Hkou] CykWd&,0@626] NBk ry]
tokgjyky usg: ekxZ] iVuk&800023
¼osclkbV www.csbc.bih.nic.in½½
kr fyf[kr
foKkiu la[;k&02@2020 fcgkj x`g j{kk okfguh lsok laoxZ esa ^flikgh* ls lacaf//kr
ijh{kk ds dsUnz esa ifjorZu ds laca/k esa vfregRoiw.kZ lwpuk
fcgkj x`g j{kk okfguh lsok laoxZ esa ^flikgh* ds in ij fu;qfDr gsrq fyf[kr ijh{kk
fnuakd 24-01-2021 ¼jfookj½ dks vk;ksftr dh tk;sxhA bl laca/k esa foLr`r lwpuk igys
fuxZr dh tk pqdh gS A
2jksgrkl ftyk ds rhu ijh{kk dsUnzksa ds dqN vH;fFkZ;ksa ds ijh{kk dsUnz esa fuEukuqlkj
ifjorZu fd;k x;k gS A lacaf/kr vH;fFkZ;ksa dks lwfpr fd;k tkrk gS fd os i"kZn dh
osclkbV ls viuk u;k bZ&izos’k&i= MkmuyksM dj ysa vkSj u, ijh{kk dsUnz ij fyf[kr
ijh{kk esa lfEefyr gksa A ijh{kk dh frfFk] le; ,oa vU; 'krksZa esa dksbZ ifjorZu ugha fd;k
x;k gSA ;fn izos’k&i= MkmuyksM djus esa dksbZ vlqfo/kk gks rks vH;FkhZ i"kZn ds cSd gkfMZax
jksM ¼lfpoky; gkWYV ds fudV½] iVuk&01 fLFkr dk;kZy; ls fnukad 21-01-2021 ,oa
22-01-2021 dks iwokZg~u 10%00 cts ls la/;k 05%00 cts ds chp O;fDrxr :i ls
mifLFkr gksdj MqfIydsV bZ&izos’k&i= izkIr dj ldrs gSa A
I

D.A.V. Public School, Hansraj Nagar, Admapur, Sasaram, Rohtas-821115 -

Øekad

jkSy uEcj

Uk;k ijh{kk dsUnz

01

1219011297 TO 1219011680

02

1219011681 TO 1219012064

03

1219012065 TO 1219012448

04

1219012449 TO 1219012592

Sant Anna Uccha Vidyalaya, Budhan
Road, Sasaram, Rohtas- 821115
Mahila College Dalmiya Nagar, Dehrion-sone, Rohtas-821307
Baba Ganinath Mahavidyalaya, Dehrion-sone, Jamuhar, Rohtas.
Swami Shivanand Tirth College,
Sasaram, Rohtas-821115.

II Sri Shankar Uccha Madhyamik Vidyalaya, Takiya, Sasaram, Rohtas-13 –

Øekad

jkSy uEcj

Uk;k ijh{kk dsUnz

01

1219020889 TO 1219021224

02

1219021225 TO 1219021512

03

1219021513 TO 1219021776

Awadhoot Bhagawan Ram College,
Awadhoot Nagar, Sasaram, Rohtas-15.
Scottish Central School, Lalganj.
Sasaram, Rohtas-821115
Cambridge Convent School, Lodhi
Barao Path, Muradabad, Sasaram,
Rohtas.

1

<!-- page 2 -->

III S.P.Jain College, Sasaram, Rohtas-15 –

Øekad

jkSy uEcj

Uk;k ijh{kk dsUnz

01

1219030889 TO 1219031176

02

1219031177 TO 1219031416

03

1219031417 TO 1219031630

Residential Sun Beam Public School,
Mohan Bigha, Dehri-on-sone, Rohtas821307
Rajendra Vidyalaya, Gaurakshani,
Sasaram, Rohtas-821115
Sant Michael Academy, Sasaram,
Rohtas-821115

3- iqjkus izos’k&i= ekU; ugha gksaxs rFkk iqjkus ijh{kk dsUnz ij ijh{kk nsus dh vuqefr ugha
nh tk,xh vr% vH;FkhZ vfuok;Z :i ls u, izos’k&i= ds lkFk u, ijh{kk dsUnz ij mifLFkr
gksa A
4mijksDr rhuksa ijh{kk dsUnksa ds dsUnzk/kh{kd vius dsUnz ij bl laca/k esa lwpuk iznf’kZr
dj nsaxs A rFkkfi dksbZ vH;FkhZ muds dsUnz ij igwWaprk gS rks mls dsUnz ifjorZu dh lwpuk
nsrs gq, u, ijh{kk dsUnz ds fy, izfrfunsZf’kr dj nsaxs A
g0@&
g0@&

v/;{k]
v/;{k]
dsUnzh; p;u i"kZn ¼flikgh HkrhZ½]
fcgkj] iVuk
Kkikad 05@ds
05@ds0p0i0¼lw0½
fnuakd 14@
14@01@20
01@202
@2021
v/;{k] dsUnzh; p;u i"kZn ¼flikgh HkrhZZ½ dk dk;kZy;]
ljnkj iVsy Hkou] CykWd&,0@626] NBk ry]
tokgjyky usg: ekxZ] iVuk&800023

2
