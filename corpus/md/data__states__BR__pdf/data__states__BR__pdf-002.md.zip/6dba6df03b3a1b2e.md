---
doc_id: "6dba6df03b3a1b2e"
source_url: "https://basu.org.in/wp-content/uploads/2019/06/General-Instruction.pdf"
ministry: "Bihar Animal Sciences University (BASU)"
title: "General Instructions"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "8554e1882a19e8af"
---

<!-- page 1 -->

= INSTRUCTIONS & CONDITIONS

i ~ The prescribed qualifications and experience are minimum and the mere fact that a candidate possesses the
same will not entitle his/her for being called for interview.

2 The University reserves the right to restrict the candidates to be called for interview to a reasonable number
on the basis of qualifications and experience higher than the minimum prescribed, or by any other condition
that may deem fit.

3 The panel of selected waitlisted candidates will be valid for one year from the date of approval of competent
authority and University shall make appointments on consequential/ new vacancies.

4 — Canvassing in any form on behalf of any candidate will disqualify such candidate.

5 Candidates have to fill relevant score card for the post applying for. Selection will be made on the basis of
candidates’ previous record (as per relevant score card) and their performance in the interview.

6 The in-service candidates should apply through proper channel, failing which the application is liable to be
rejected,

7 For appointment on the posts of teachers in Veterinary, Dairy Technology, Fisheries it would be a basic
requirement for the candidates applying for the post to hold / possess respective basic professional degree at
Under-Graduate level. Professional degree means BVSc. & A.H., B.Tech. (DT) /BSc. DT or equivalent,
BF.Sc.

8 At the time of recruitment in University and its Colleges, service agreement should be signed between
University / College and the teachers which should be.lodged with the Registrar / Dean with a copy to
concerned teacher. Self-appraisal of performance should be a part of the service agreement.

9 Advance copy of application form may be considered subject to produce NoC from Employer at the time of
interview.

I0 Experience and qualifications will be reckoned as on the last date of receipt of applications.

I] Applications incomplete in any respect will not be considered.

2_ Every page of the application form and enclosures must be signed by the candidate at the bottom of the page
in the space provided.

43 Every page of the application form including enclosures must be numbered and total number of pages must
be mentioned in given space.

l4 All the enclosures must be self-attested by the candidate with date. Originals must not be enclosed with the
application form. The candidate will have to produce the original copies of all the certificates and documents
attached at the time of interview for verification.

i5 No interim queries regarding test/interview/selection will be entertained

l6 University reserves the right not to fill up the post advertised, if the circumstances so warranted.

l7__ New pension scheme will be applicable with subsequent amendments to fresh regular recruited person.

8 Incase of any disputes/suites or legal proceedings against the University, the Jurisdiction shall be restricted
to the Courts in Patna, which is the Head quarter of the University.

9 The University will have the right to relax any of the qualifications, experience, age, etc., in exceptionally
deserving cases of all posts on the recommendations of the screening and selection committee. The statutory
provision for relaxing of age in case of the candidates belonging all reserved categories of state of Bihar will
be made applicable as per GAD, Bihar norms in force at time of interview. SC/ST candidates shall have to
produce caste certificate whereas EBC/BC candidates shall have to produce non creamy layer certificates
issued by C.O. in favour of their claim of reservation. EWS candidates have to produce desirable certificates
(Candidates are advised to check GAD, Bihar website for update information). Submission of residential
certificate for the applicants of reservation categories is mandatory.

20 a) Applications of professors retired at the age of 65 yrs will be considered against the post of Professor
for appointment on Contract basis. Salary and term of appointment will be made as per provisions N.No.
3/M-63/203 Gen. Admn. Deptt. !0000/ Patna dated 0.07.205 issued by Bihar Government.

b) Tenure appointment may be done only in case of Professors for a period of 5 Yrs. or till attaining the
age of 65 Yrs. whichever is earlier. Maximum age limit for applying for the post of professor is 63 Yrs.
c) Payment shall be made on the basis of Last Salary drawn minus pension only for Retired Professors.

2l  Enrors and omissions are subject to corrections.

22 Applications received after the last date and without complete information or without requisite fee will be
summarily rejected. The University will not be responsible for any postal delay.

a.

<!-- page 2 -->

डक 2 The University shall verify the antecedents or documents submitted by a candidate at any time of selection
procedure, at the time appointment or during the tenure of the service. In case, it is detected that the
documents submitted by the candidates are fake or the candidate has a clandestine antecedents/background
and has suppressed the said information, then his services shall be terminated.

24 Whole text of publication need not be enclosed. Attach only first page/ pages showing the necessary details
of publication like- title, Author (s), date/year of publication and name of journal / publication

25 Incase of any inadvertent mistake in the process of selection, which may be detected at any stage even after
the issue of appointment letter, the University reserves the right to modify/withdraw/cancel any
communication made to the candidates.

26 In-Service Applicants may be given the advantage of their basic pay protection in the mentioned Level / Pay
Band and Grade Pay of the post.

27 Persons appointed may be transferred to any equivalent post within the jurisdiction of the University.

28 The Chairman of Selection Committee shall have the power to lay-down the procedure in respect of any
matter not mentioned above

29 The persons serving in Central/State Govt. /Universities or Research Stations may be taken on deputation
for 0l to 03 years or up to the age of superannuation.

30 Fees to be paid by the applicants as Demand Draft from any Nationalized Bank in favour of “FINANCE
COMPTROLLER, BIHAR ANIMAL SCIENCES UNIVERSITY, PATNA” Payable at Patna:

3l Application fee for UR / EBC BC Candidates; - Rs.000/- and for SC / ST Candidates: Rs. 250/-

32 Application fee once paid shall not be refunded under any circumstances.

33. Reservation shall only be applicable to the original resident of Bihar State SC, SC(F), ST, ST (F),EBC, EBC (F), BC,
BC (F), EWS, EWS (F) and WBC. Horizontal Reservations to-Divyang / Grandchild of freedom fighter, shall be
applicable as per Guidelines Govt. of Bihar.

34 As per Circular No. ]] /omo*fe—I-,/2045 Wome 2342 dated 5.02.206 in case of unavailability of female
candidate (UR3-F, SC-F, EBC-F,BC-F, EWS-F) post may be filled with male candidate of same category
in the same transaction.

35 As per (Bihar Extra ordinary Gazette, Bihar Act-2,20I9 ) The Bihar Reservation in vacancies in posts and
in Services and in Admission in the Educational Institutes (For Economically Weaker Sections) Act,20l9
Clause-, if candidate from EWS are not available to the extent of reservation percentage prescribed under
Act the vacancies of this category shall be filled up by the candidates of Open Merit Category in the same
transaction.

36 Duly filled application form, along with original Demand Draft and self-attested copies of
testimonials/certificates within the envelope superscripted “Application for the post of.............” addressed
to The Registrar, Bihar Animal Sciences University, PO: Bihar Veterinary College, Patna — 8000i4
should reach to the Office of Registrar. Last date for receipt of applications is 0/ 07 /209 till 3.30
PM.

37 Candidates called for interview shall do so at their own expenses. No TA/DA shall be paid.

38 Candidate should give a power- point presentation at the time of interview.

-
Place: Patna Registrar,
Date:z../.4.,./209 BASU, Patna
t
के
व2
