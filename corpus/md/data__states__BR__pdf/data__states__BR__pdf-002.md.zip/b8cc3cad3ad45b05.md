---
doc_id: "b8cc3cad3ad45b05"
source_url: "https://www.idabihar.com/wp-content/uploads/2024/02/Corrigendum7_14_0001.pdf"
ministry: "Infrastructure Development Authority (IDA), Bihar"
title: "Corrigendum7_14_0001"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "72723e3c4fa6a83d"
---

<!-- page 1 -->

गो आधारभूत संरचना विकास प्राधिकार
0३३ ५-० नह
N ic?) आधारभूत सरचना विकास प्राधिकार
| bh ati
(a DS i i (बिहार सरकार का एक उपक्रम)
AE DY प्रथम तल, उद्योग भवन, पूर्वी गाँधी मैदान, पटना।
/ नम _ _॒_._.॒ __ा-॥06/049॥77:6०॥ , १४९००-४०७४.०॥७॥॥३॥-८०॥, 000९:062:2675933,2675935,॥0॥0-2675934/|| | ५ १४९७-७४ ४ .0॥॥॥8।.00॥., 0॥0॥6: 062-2675933, 2675935, ॥॥४ ॥0-2675934
प्रत्नांक...... ताक,
सूचना
URUTSHT "Remaining work of Construction of Plug & Play Prefabricated
Shed at Hajipur Industrial Area, Hajipr, Vaishali, (Phase-3)" हेतु प्राधिकार द्वारा
amifaa fiftet Go NIT- O7/TEN/IDA/24 एवं परियोजना “(Re-Tender) Storm Water
Drainage Construction in Mega Leather Footwear & Accessories Cluster in
Industrial Area, Mahbal, Muzaffarpur’ @g wi@er grt aft fafaai wo
NIT- 44/TENIIDA/24 को अपरिहार्य कारणों से रद्द किया जाता है।
ह0/-
कार्यपालक अभियंता (तकनीकी)-मुख्यालय
simmies 643 ITEN feria ezlealar
प्रतिलिपि: 4. जन-संपर्क पदाधिकारी को सूचना-पद्‌ट पर प्रकाशन हेतु प्रेषित।
2. कम्प्यूटर प्रोग्रामर को प्राधिकार के वेबसाईट पर अपलोड करने हेतु प्रेषित |
टला 5५
८5007
कार्यपालक अभियंता (तकनीकी)-मुख्
