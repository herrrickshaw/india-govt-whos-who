---
doc_id: "dbc9dbca577c41ec"
source_url: "https://bsbccl.bihar.gov.in/New_V/UploadedImage/TenderPDF/191246.pdf"
ministry: "Bihar State Building Construction Corporation Limited (BSBCCL)"
title: "Pankaj Construction (Prop-Arvind Kr Singh),House No-118,Mahavir asthan,Gaurakshni,Sasaram,Rohtash-821115"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1a77eced79d7e022"
---

<!-- page 1 -->

f
I

onoifo,-qqq-rs/e1fteqe(froFoajfuF-{

G,AW;s/2r;26....

fraru vron
qqq ftqT.f fttTf.r

".fr/

vffr"r sntsr

ffi.Kffiffi.m#*#

q-rgrrsi d frq studio Apartment

ftqfq od fu rrilq-n +n.$ qe-q

(G+3), Type c (GF5) (Guest ouselprof/

,Reg No.-r2 zaffisctass-r)

"# *-","C#-"#;

fu-s. erqrq'w.*rre, qs qo-rs, qEr-fi.i

Ho-01SBD/2ozs-26 Dtd_o7.a4.zozs d qltu|q

,i,.. ,:T,qTf
.\...L

,

^,

-F{f6_

d
*.s cT{hq ETR

Asso./ Asst.prof.)

*ildT* gr$ \_dr{r{qrqT
€ q,F{Ffl_q.r
Sqr;q
I 4a o-rd 6} stw
'
"' ' ftqT

z. ml$qmtr sTfumr q_*q q_*sd,

Tttgr srcr vm q-r$ 6-1 3il_qq, fr_freror

ffifu'-ffi,%*S*:, ,TngflflT

"'\,. ",-.-:-Frd
,.. :4.Tft G w+-{6 dRt rrrrd/ft.-d rilqrffi * **r ;"+"; Gir*)q if 6qrt rrd
w*
of Wf fq Eli n-o orq-d ffi ,ft g.-* *
d, ; q1 n*,
':

--J'l q'

rI s-ffi l+qlsr 6"rd Et

dq t|$"q

dEriffi r{q€-rH (rvrr), qaql of vF &q gRT
\rf-" fi/ 'er n$o ffi
Hr-sr' f*irl, q-qr d q-ilfi-gos, ft,qio-r z.as.zo5
Tq
tqltc]n-24'49'2025
frqif24.as.202s dnT
qR-d-{q Bqtrer
)\\/4t'1t-tvYt
dRT qrq qfr*<q
N t'ro-tosi
sqFfer qtErw,.rr{n,
arvr{rr .rrurr tuJr}
fr,fi-E
glRT
ri}E_o
-T-n oT-d
Eft yru--t q'qr * ercq-o o-q ffir,or {w
F
f*s
G_
4. vfir tnd Et d-q dg furFtq wro_auz.
\cxl
frqio_o
-'d ;. ffi#"tr#:;:lJJ;,,1T-# ffi ffi-,H
JN
ysamasripur
v/t
*":
:T
:
Gi+kffiT
college
----'r'-* 6rd d An- q-q-qi
cr,l d";
, WSY1":.:'"*
\I|fll + *{j$t'ffi
'rl{rr *t
1_\_ \.
mcrcrsTl ltll+Iifi-l
"llcllc'

r

Raft Foundation d concrete zFI avg.

44fffi

q-{r, q} qFrfi t mTv't
o-q * r rncfu

compressive Strengrh 5-15 N/mmz cruu q'o-l

d s;*

F E i\i u"-trq
A"' compressi"_ uor"*rr;; ffi;;#*K",
,E r, i'li
l# F : ici
s. n-g.m qtq qa ei-Er ftri .r$ ft-frerq

Rq,* F^,,-.r^+i^.^
n
Raft
Foundation *
d concrete
6r

d sq_grf, ft.fte+"r qft.d_q_{ qT ftuiq
['Ni{i ftd 'ilfi tg 3"*
q-Eq
ftqfur ftqr{T qft .Trq*'oT t g*=*4q rrpfr or
F-aq),
rr-d;I ffi-qr *ti ru*t
"ft.*
ft"fr' # .* m
s*r 6{rd ?d frq d oTqT +t g,,ed,
ilH f}.S
qT;rfr
qr{
arcq;o
t
"a=oq
F\:ll
t
fu ftrTirrr

F E #''i m* vri qroi trlT *,d'd "il}t aqo},T fu.Eqgffi $ * B-n grTcrnr d fi-q qr
d ft{ orq5ifuT **T1 F{{ e-flq $r6e B fu.
6 [ W g orhq-dt am +-sr$ T] orqT 'frq
aft grrq-f,T i -fi *fu
R-F ut *t { orroi t, fr-q_dr
hJ'b F li w';q q-si

EerR
tl *Tn: sfiT rflft r1ffi qqrr soo yr{Tqr qrd EFtr6 Er{rrr,*{ (G+5). zoo gfqqr

qT-d eTFm u'=rcIriT

-rt

"-$7
-Y,

APartment

9*t 94 Tvpe c (G+5) {Guest House/prof/Asso./Asst.pror.l d frq o} npn *q d

vq-q d 6Ts 4t

lry

{G+3) Block *An & Brock ,,8,, Fr€rq?n qTEqrwFl d ftq studio

ffi gq q*ft Debris 6) o-rd q€rf, d qr ir*e6 oru-fi *g qq qqfu-{uftq.

Fq € qa wft d oo(wro) fufi d erqt Dispose off o-hl

I Dismantred marerials

K*$ffiffi'ffi'ff'ffi+;-.***ffitr#

<!-- page 2 -->

b{} "
Erff€ tfl frqtrsr

q'tt

-F{fr Eq frki

;"'#;.lmg

@.r

t
' ^' ' sftqT
;Fr 3rgqrc|"I
irauritt"T fl qrRr qtt q-{fi ri}E-6
"Am trl

HH,;T*.*-T*,rrFilIii
oral order
frqi6-o+'1:
.Tqt

t**

r ftil'$tt

qqrhTqTq €o-taoea / zozs
i:::".Tthe order dated
been preferrJd against
has
application
writ
whereby the
qfRd fu-qf tfq-f fu:- "The present
Division, Samastipur,
Building
Engineer,
Executive

"'*

13.10'2025, issued by

the

Technology'
petitioner/contractort.asueendirectedtodemolishtheconstructedstructul"":.:*groundthatit
National lnstitute of
in the test report oitnu
suffers from quality deficiencies

as indicated

Patna.

Patna' Learned
(i}lthasbeensubmittedbylearnedcounselforthepetitionerthatafreshtestbe
the lndian lnstitute of Technology,
n,'"rv,
agency,
conducted by an independent

No'18668

Advocate Generalhas.no "oi"ttl:-l::T:l;";,r"cted that a fresh test Patna High court CWJC
t
(ii)' In these circumstances'
petitioner shall be obtained
work executed by the
the
of
respect
2/7 repo*in
of 2025(2) dt.04_i_z-202 s
a period of six weeks

question.

pr; *d submitted-within

the site in
shall be carried out at
report, nu o"toti'ion
said
the
of
(iii). Till submission
representative sharr remain
petitioner or his authorised
thu
t*rt.,
the
of
During the conduct

from the Indian lnstitute

of rechnolosv,

-dfi it'sm fiqfuT fld 3ft

R"tq ;
7- qrfffq w- ****'l/;;
d yrant
Er-n iF{Tt 'rs 6d
{iaE-6
fi
fu"t
q,l dq ,, ,urnu t 6..,fi
xur-{f,T
"t;
- ft d..q qfr;"-{ t qfqdp El{I tn{d
,ntqt Ao qr$ 'rfr I
sq:
B' sffi ord. d fis€ frfr-q TrroeflT
q-r @TdqT€r6 sT*rdf,r, qq{
aTrqTq
s
.ort
Ro. il;
q
.,-a fld *T xr,u* ,*_ * d3r1{rqT d 31T-db
d
a-iT
'rs
q'ei-r-r:, #::o|.'Yd
srisn, *1q{sgq d
ffi[*-2*oz'oz, sw
q-*io-ra37
qeqr
*
R6R,

,present,andacopyofthereportshallbesupp|iedtothepetitionerinadvance''.

gcq 3{Rr'or

&i, ;

frd" fu{rT,

no.118, Gali No-15, Mahavir

Eq-e fu6-g R6ri diffif
dff'ffi.-Eq
*f
Gaurakshni, Sasaram, *"n"r-*'i'i

Tia-q-6. Pankaj Construction,(Prop.Arvind

Asrhan,

Kumar Sing}r),House

fuio.c RqrTiq-s-zooz d u=o

r.sqo 6d & orJ*.sT o1 ''rft

t

9"gft{if,Iq5g-s64Tqq3Tlgffi-{{6-frtqqfuqdolgfrffiIlni3lTqifu'd
t-nfi d qftfr ilI {ia-tr'
;
gg

€aqd} o Bata-</ord--mqsr

Ro,.r*0e.03.2026

""-

a

PankajConstruction,(Prop-Arvind-I-(umarSingh).Houseno-l18,GaliNo.15,MahavirAsthan'
iiu*'-D Q q6 q*r6 3'u-i
.*"e.No.-gcp-rztoo'n
qnsq -fi qftrd o-d ar
Gaurakshni, sasafam, Rohtas-821tti

*

fr{ ffifu d

po1q f-* "*' el*l A
sfro<q nq oEi ffr
d qlqq t qfr-f,
Fliqft{'qrTrrnlf,-{rf,tfiqftqFtqtr{itr_226g(q)ft[-{m_09'03'2026fl_ri.w.fftr.t"Tot
x
t"
w
fqqiu,*to.o3-2026
qiw-zztz(s)q3",
qrrf .h1 .rff qq
qqffi-d ftqr rrqT I

gt" -#'';;m{"T
frqT :rqr r n-dqiTn'{ia-{fi

ri*{6 gr{T T{qff"r

ftf$I$T{ **

ffi15-13'03.2026 @i

rrqq FHfET fuilq d

fu
w*ffrr q rrd&-s ftqT q-qr t ds.$
g vft Debris 4}

o*r d fi-{i y fit i T;

6}

"td
q't 5{: g'q.q)Tl gq{
orderagwslqi€d*s-4"31-5qa€.TdDispose:'1.fu*qI{6TBnen
reinforceme"::
sand,
chips'
":
rubbrlh, stone
* tuil'nq
Dismantled Materials i.e,
1T.-

q

"n't

ffi.n sq 13 ga1:s''"; *n ##1# r

<!-- page 3 -->

,0. 3rfu-dr s's-T-qw 3ngffi-s6-fr*q
isfuq o1 erqssr
qM d ft-a-cqzT*#\
e-qi'-.,noJro*'*t vtrFr t-- d qfrtu { enz160
Pankaj construction (Prop-ArvinjKumar
dM F+@.
singh),

House no-1lg, Gali No-r',
'"s; '#rfr Mahavir Asrhan
t sTq ,se'qrr ;-il'""s*
*''
ritr{€ 6i qtff
avr sftdwid
gr Fd fu*q o} qq
'ms
#
a
r'l
fuq
*#iu.'@rackrist)
frofq ftqr qE'r n-Erato t
uo-{+ oT
sTriyr #-oeo_*n*_
ffi
q4_o_zo.o3-2026
rrrigl
grgr $d-{fi'
Gaurakshnio sasaram

Pankaj construction (Prop-fuvind

Kumar singh),House no-lrg,
Gali No_15,
sasaram, Rohfas-g21115 (Reg.No.scD-12
2003gclass-I) zbt 3rr+gr
qt ftfu qs (,ol oui
ft'fd
d ftq mr$_qn @hcklist) ft_qr rqr
r
11. u-m srlEaT
fr-6-q irilq-s
qxo.-ss. frqim_rs .a4"2026
3T*€-Rtert
g*r
srrer qft-f,
Mahavir Asthan' Gaurakshni,

*i

*

d

d

d

qER frqT r*n | frwq

G""#";
ft fuTFr d
;*
#;
*+
#; d=* gq *=fi Debris E)
.fld*rd * g *-fr at *w
fuqT ; * t,"#*
- ' -'ra ft
vt'\' w.ft
s'! v-m
.'nr 11-64
goTu-fiT qFrs-d ergrnv qRiq
mT ft"irT uord
"'q
fr+qrigq* sffi **ft Tq-rT d oq

sv R_qT qr+qrr

B*fr er+d qqr}{q d

frHn rfi.-n vqRerd go'

uo-,*g

.rrd * fi-q Tq fiq s d*

o'dterm

mq fr pqir-2e.o5.2026 qn gq-dr{ fu{tRd

e1 .rs.
d; d'#ffi am fr*ilT d fr-{rrrEqm u_m
#*

a ord *;'-gq'qq-i ftfi *u * rrft
Debris en
t 6 q'-{t d qT€r*HTsr q-e sr)u-*
*f rffqr qr
ftofui *d

xru*
d
B) TffiTq fu_qT riqT I
12. BcreI otq-#q g{qd
{ gc< srftddT (B-dr), +rqa ftqfur f+qTr. frER, qeqT
d ART $ q-{.rd o-{En .rqT fu-sd-ff
ArT 6-*t ,r$ frE r} qEmo *r* A
da ig6ro
t Td) ordqrd-dD oTfuaT. r* ou-"., Hqrdg{
patna S o_srqr .rqr
Frtr
Nrr
t fu{#t ErrS
Td *'-d d ."rqil qFrqr * .urs1
qrqrili
nq
.,-aq
**K
ftqfuT fuilr d vs'ffir
qm trm s **fr-d
@Td et fq 6-rT-s .,.s.
**
fi 6^rqT d g"Tqrr q*fi.t .oTht
frq qrg 'rs t vqn dq qfta-qq J
$sq s{fufd-r (vw),q-aq ft,q'ur fr,q'iT, REn,
qr+r of €T'qfrTil
asqisq T{ftfr oT rrd;r ft-{ir rTqr r wftfr
6iRT 6wt n.s q$ fuqf.T
oTd qt
qq qrdr'rsrftq e*qf,
e=r $ {fl-6r ftoo" o*.,-t
sy T{, ftqfET fu wa-q6 qn
frdET ftqi .T-qT, fuqd ft€€*
qri-*q vra ;qsr€_q,
oa*
*"
q_g+r *
T{o-1s66s,/2025 q|q{ ft-q]
r-qT I vqf, ilE fr qm+q $@ qrcrcm, qd;IT
gRT G'-irs rr+
trT-d et #q ur paha
m-tT+
n*r
r*,ru d d-q q**fi t sRr$
.rS o.rd a1
qFm ,$ qrrht
l

crg-sq qrirT ffiiTi at qro

ffi

*a. t

{

t

h--T

qrq-.u

*

ft* ;,'i-rr

*

Xwatl
ftq qrqT q_sT.t
Fs raryq q-+"- e*r Fd-i qErrywf sTd et qFrF
flRrfuili \q wq_m-r
ex"r' u=rs ord d
wf
ireTersr-di 6) {q€ w rt qReftd

tfr;*#

#

sq{ffi
op:r}
3rT-dilfi
uid-{6, pankaj constru*ion (propArvind Kumar singh),House no-l
'Fff,
18, Gali No-15, Mahavir Asthan,
Gaurakshni, sasaram, Rohtas_
8zl I 15 oi *,rfr-6-d frd qr+
3rfi'-q

d

{

rr*;;
o{rgqil_rr6_ffiq r{fuq,
"-erq
at erqrirq'-ff q-s e.r
"*il

ffiuT frqFT, ft=". qeo, d gr,s
"dftilrft#
ftd rT-i.re".q
s,
v

2

Eo//vura arrtt

<!-- page 4 -->

_s\r$

( rtQtls$-\aF:

" & - "'*fq,l''t rrr, -$), l 4\rnft voa{
r

A

r

uRouolfro|-or'ffd{t{*iQf,-

15

ggqt'frFTitf'-

I 2026""""

no-118' Gali NoKumar singh)'House
Class-I1
qftfufr:--€*c[-6, pankaj construction,(prop-a"vind
(Reg'No.-BCD-.1220039
*nr,*-,,,115
***-*, Sasaral-n,
15, Mahgvir Asthan,
tg nFo
th\ qq-{"f rni eTrds{*'

orqto-'n=-r

rffii

^ :'- fn

a ,z

i

frd

ao/-

wfiR d lrftq
z' {ufut frqi-6- t el e 12-4

/ zozo"'?'6
qftfuR:-.rrcra+qaq**'*ffi'"ti*'5;;g'1FT7qer'F"htft'qFT/sn
ffiTrI/qrftiur 6Id
ftHi*=t
m#Zyryre
qT

7
srqr*+Tffi-r / erftouo*r)-::Y
a

ordrqd- ts

*-"lw*ff*(qRdriqT)'
delrtr{ frqTrT/tfo YIwq
-fifi '
tr6,*
Fiqq
o"t'da' ^sg* "uo: 61
f,qrrrq/miq
qq s*ffqn
**nu* 3Tfud-dr/q'ft ol"qqrtrF
fr6* fttu-n' TSqc+
qqq'#il
tTft=rdT"
GET*
tErq, -rs+/eq]
rdqFl / 3ts.l a"_
urlor'6'qr{r
i*a t
sTtrq-dr,rlin Fqt"T
oTfu{dr,qin
+c-{r o\ q"-{TPi qti sfiqeqfr '.'qtel
fuo'
frqq
H"F+rqft

o*-*o'il# *30,
-qT
*#'iat"e*Z1ff

/F

W
