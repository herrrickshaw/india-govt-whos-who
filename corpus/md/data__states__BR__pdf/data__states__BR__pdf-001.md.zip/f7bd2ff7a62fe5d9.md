---
doc_id: "f7bd2ff7a62fe5d9"
source_url: "https://nalandauniv.edu.in/wp-content/uploads/2019/07/office-order-procurement-committee-1.pdf"
ministry: "Nalanda University"
title: ""
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "0f3ca7d8f47f827c"
---

<!-- page 1 -->

Nalanda Nalanda University, Rajgir, District Nalanda, = 5 ०
University 20803 6, Bihar, India T +9 642 255 330 Ss
www.nalandaunivedu.in
05८ 22
।
Nalanda
UNIVERSITY
NU/37/2074-5/ QAI 289 |७॥५, 206
OFFICE ORDER
As per approval of the competent authority the Procurement Committee has
been constituted for processing procurement of products and goods, execution
of works and hiring of services above rupees twenty five lakhs for the Nalanda
University, Rajgir.
Members of the committee are as under:-
Name & Designation of the Member Position of the
Member
Mr. K Chandramoorthi, Finance Officer cum Officiating | Ex-officio Member and
Registrar Chairperson
2 Dr. Nihar Kanta Patra, University Librarian [Members
|3__| Dr. Pushpa Kumar Lakshmanan, Associate Professor [Member Cs
Shri Nagendra Sharan, Senior Audit Officer, Indian Audit Member
हे and Accounts Department, Delhi
Mr. K. Krishnasamy, Sr. Audit Officer, Office of Director | Member
General of Audit(P&T), Delhi, on deputation at
Pondicherry University as Internal Audit O} fficer
[6 _ | Mr. Ashutosh Sinha, Scientific Officer, IIT Patna [Member sd
7 Mr. R, Subramanian, Special Director General, CPWD | Member
(Retired)
Two member out of the panel of Finance committee mentioned at Sr. No.4 to7
shall be co opted for the purpose as laid down in the Nalanda University
Financial Regulation.
All the members of the Procurement Committee, other than the ex-officio
members, shall hold office for a term of one year. The quorum for a meeting shall
be four. External members will be eligible for TA/DA as per rules of the
on Kapil —
(K Chandramoorthi)
Finance Officer cum Officiating Registrar
Copy to:
l. Vice Chancellor
2. All concerned members of the committee
3. File Copy
DELHI OFFICE 2nd floor, Council for Socia! Development Building
53 Lodi Estate, New Dethi -0 003 °
T+ 9i L2 2462 2330
#+ 93 34 2464 8354
www.nalandauniv.edu.in
+
