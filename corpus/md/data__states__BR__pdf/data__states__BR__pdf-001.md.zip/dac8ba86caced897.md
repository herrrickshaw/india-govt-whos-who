---
doc_id: "dac8ba86caced897"
source_url: "https://cdn.s3waas.gov.in/s358a2fc6ed39fd083f55d4182bf88826d/uploads/2025/12/17645880446679.pdf"
ministry: "Gaya"
title: "TENDER LIGHT & SOUND ARRANGEMENT IN BODH MAHOTSAVA 2026"
date: ""
pages: 4
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "10b4bb82cb02c16b"
---

<!-- page 1 -->

\ Government of Bihar 69
~ District Magistrate, Gaya, Bihar
Invites Tender
From
Reputed Firms/Organisations/Contractors
For
Providing Sound & Light systems for stage and venue during Bodh Mahotsava at

Kalachakra Maidan, Bodhgaya

Bodh Mahotsava is an annual International event organized at Bodhgaya, land of
Buddha's enlightenment jointly by the Tourism Department, Govt of Bihar and District
Administration, Gaya. Renowned artists and cultural troupes from India and abroad perform
during the three day festival. National and International tourists and pilgrims attend this function.
This year cultural programmes and other events of repute is proposed at Kalachakra Maidan
from 22 January to 24 January 2026. In this connection District Magistrate, Gaya invites RFP
from reputed Firms/Organisations/Contractors for providing Sound & Light system during Bodh
Mahotsava. .

Preference will be given to those with proven experience in the organization of national
and international mahotsava and have at least performed three similar works of not less than
Rs 0 (Ten Lacs) or Bodh Mahotsava Bodh-Gaya like work.

Scope:of work

Scope of work shall but not limited to the following:-

4. To Provide sophisticated sound and light systems with assistants/operators and other
manpower.

2. To provide concept and art design of the stage and ground by light and sound to depict
the theme ‘Buddha & Bihar’.

3. Sound and Light system must be compatible to the musical and vocal performances.

4. It must demonstrate the state-of-the-art infrastructure and Technology keeping the
audience and dignitaries in foreground.

5. It must be structurally safe and aesthetically sound.

6. To provide quality light and sound of international standard on the stage and in the
ground.

7. To make stand-by arrangement and back up for providing lights in case of power failure.

8. Providing music band to local artists, as per requirement. :

9. Any other arrangements/ facilities required necessary for the quality arrangement of the

Mahotsava as directed by the administration.

Submission of REP *

The eligibility criteria, submission, requirement and other details can be downloaded
from the official website of Gaya District (http://gaya.nic.in). RFP (downloaded) should be
submitted along with a demand draft of Rs. 50,000/- (Fifty thousand only) as security money,
drawn on any nationalized/scheduled commercial bank in favour of District Magistrate, Gaya,
payable at Gaya.

The Expression of interest and accompanying documents must be delivered no later
than 2a Lala saeat 4500 hours in a sealed envelope clearly leveled “Providing Sound &
Light sy: on stage and venue during Bodh Mahotsava” addressed to District
Magistrate, Gaya.

For further information please contact Senior Deputy Collector cum Incharge Officer
Tourism, Gaya Mob- है mt
hel WO EGY |
Mi J.CS.T, Incharge Officer, Account Officer, 0८, rae
DIC, Gaya Gaya-IL Tourism, Gaya Gaya Gaya NGa
. Page l of 4
oa

<!-- page 2 -->

Collectorate, Gaya ©
RFP for Providing Sound & Light systems for stage and venue during Bodh Mahotsava at
; Kalachakra Maidan, Bodhgaya
/ District Magistrate, Gaya invites Request for Proposal (RFP) in sealed envelopes for
providing Sound & Light system on stage and ground during Bodh Mahotsava at Kalachakra
Maidan, Bodh Gaya.

The bidder shall be reputed and experienced agencies having specialization in
arrangement of Light & Sound in such a large mahotsava of international repute. The bidders
would have to satisfy the eligibility conditions and submit documentary proof for the following:-

i) Must have GST registration certificate & up-to-date certificate of GST return.

ii) Must be registered with income tax (PAN/TAN) authorities certification

ili) They have to show that they got one unit tender of minimum Rs. /0 (Ten) Lacs and
make quality arrangements for at least 3 National/international (Govt./Semi Govt.) events
like Bodh Mahotsava, Bodhgaya.

iv) Annual turnover must be Rs. 30.00 Lacs & above for at least two in last four year.

v) Audited balance sheet for last Three financial years-

2022-2023 (audited)

2023-2024 (audited)

2024-2025 (audited)

vi) Details of Office and Main Contact Person including Telephone number/Fax number/
e- mail.
vii) The name of the tenderer is not registered in the black list, must attach an affidavit.
vili)Must have Character certificate (last six month)
ix) Number of years of experience: Minimum 3 years of Similar Nature also provide the
detail of such works accomplished earlier.
x) Please also specify the details of light and sound system to be installed and
technical details.
xi) Bidder must submit self-attested copies of the above certification.
xii) Vender have to show photograph of theme, video and Power Point Presentation.
Note: please submit all the documentary evidence in support of the above conditions as part of
the pre-qualification criteria, DM, Gaya further reserves the right to verify the quality and
timeliness of work performance by qualifying agencies and bidder shall arrange permission for
the same.
2.7 Requirements
i) Bid document can be obtained from the office of the District Tourism Section, Gaya
or can be downloaded from the official website of Gaya District (http://gaya. nig.in).
ii) The document must be accompanied by bid security of Rs. 50,000/- (Fifty Thousand
Only) in the form of bank, guarantee of demand draft from scheduled commercial
government bank. Bid security is required to protect the risk of service
provider’s/company’s conduct, which would warrant the security's forfeiture. The bid
security shall be denominated in Indian Rupees, and shall be in the form of demand
draft drawn in favor of District Magistrate Gaya, payable at Gaya. No interest will be
payable by the district administration on the amount of the bid security. Unsuccessful
service providers’ bid security will be discharged/returned as promptly as possible,
but after the bid results are declared and after request received from the service
provider. है
iii) The D.M. Gaya may forfeit the security deposit for any failure on part of bidder to
complete its obligations under the agreement.
iv) This bid document is not transferable.
. Page 2 of 4

<!-- page 3 -->

(9.2
जज
/ 3) [Schedule of Events
oe The detailed schedule of events is as follow:
i) Refundable bid security Cost
Rs. 50,000/- (Indian Rupees Fifty thousand only) through bank guarantee of
demand draft from a scheduled bank. Drawn in favour of District Magistrate Gaya”
payable at Gaya.
ii) Issue of bid documents
Till ABJigl9e@95 up to 2.00 pm.
iii) | Submission of bid Documents
Untilga{t2/309¢ हम] [3० 3६५ at 3.00 pm venue: office of District Magistrate Gaya.
iv) Duration till which the bid should be Valid-
80 days from the opening of the bid.
v) Opening of bid :
On @2|t2 Jaen S [i2 Jeger s at 3.30 pm venue: Office of District Magistrate,Gaya
vi) Publishing of result for Successful Bidder
The information to successful bidders will be provided through official phone/mail/fax.
vii) Contact details for any clarifications
For further information please contact Senior Deputy Collector cum Incharge Officer
Tourism, Gaya Mob- 8340522028
Note: - D.M Gaya shall not be responsible for non-receipt/non-delivery of the bid document due
to any reason whatsoever.
4 Payment Terms
The entire payment will be done after successful and timely work accomplishment as per
satisfaction of District Magistrate, Gaya.
5.) Reservation Rights
The D.M Gaya reserves the right to:-

i) Extend the closing date for submission of the bids.

ii) | Amend the bid requirements at any time prior to the closing date, provided that
the amendment is notified to prospective bidders.

iii) | Seek information from or negotiate with one or more of the bidders on any issue
at any time and to continue to negotiate with one or more of the bidders.

iv) Discontinue negotiations at any time with any bidder.

v) Terminate or abandon this procedure or the entire project whether before or after
the receipt of Bids.

vi) Seek the advice of external consultants to assist the district administration in the
evaluation or review of bids.

vii) Make enquiries of any person, company or organization to ascertain information
regarding the bidder and its bid.

viii) Reproduce for the purposes of this procedure the whole or any portion of the bid
despite any copyright or other intellectual property right that may subsist in the
bid.

ix) Any other arrangements/ facilities required necessary for the quality arrangement
of the Mahotsava as directed by the administration.

. Page 3 of 4

<!-- page 4 -->

. @
“
/ COMMERCIAL BID
| (TO BE QUOTED IN SEPARATE ENVELOP)
Z Providing Sound & Light system on stage and ground during Bodh Mahotsava
Description Quantity | Rate in INR/Per unit | Total cost in INR
with GST)
Providing Sound &
4. Light System on stage
and venue during Bodh
Mahotsava with JBL
Sound.
(Details to be specified by
the bidder)
Specifications (suggestive)
For Providing Stage Lights as under
Back U - Truss, Side & FOH Towers for Lights,
00ft x I00ft truss Light
Lights with 720 Pars,
LED Pars (RGB),
Victory Scanners,
Moving Heads,
Alpha Beams,
Avolite Boards,
Haze Machines,
Follow spots,
LED colour changers,
Dimmers etc. compete with operation charges by trained technical crew
Sound System
Sound system with Electro Voice line array system with subs,
Tops, flying subs, Sound craft digit 7 Mixer,
Side files JBL SRX 725,
As per require of Artist you have must provide specific music Drum etc.
EAW Monitors,
Mikes & DI boxes as per requirement for cultural (Musical and Vocal) performances
. Page 4 of 4
