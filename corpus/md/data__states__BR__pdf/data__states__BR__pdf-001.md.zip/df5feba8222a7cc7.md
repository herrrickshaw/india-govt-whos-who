---
doc_id: "df5feba8222a7cc7"
source_url: "https://bsrdcl.bihar.gov.in/Document/20250318051535026Corrigendum.pdf"
ministry: "Bihar State Road Development Corporation Ltd (BSRDCL)"
title: "Download"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "7ed07483f4b73669"
---

<!-- page 1 -->

BIHAR STATE ROAD DEVELOPMENT CORPORATION ;
i (A Govt. of Bihar Undertaking)
~ Regd. Office: RCD Central Mechanical Workshop Campus, Near Patna Airport, Sheikhpura, Patna-8000I4
Tel: 062-22267 Fax: 062-222672, Email-bsrdcltd@gmail.com, website: http://bsrdcl.bihar.gov.in
Letter No.-BSRDC Ltd.-4473/2025 & “FH $3 Patna, Dated- (403-2 07257
CORRIGENDUM _TO_ NIT PUBLISHED THROUGH PR_No._-20656(B&C)_2024-25
Construction of ROB with Limited Height Subway (LHSW) (Between Siwan — Pachrukhi
Railway Stations) and Approach Road in lieu of L.C. No. 9i Spl on SH-89 (Babunia — Siswan)
Road in Siwan District.
S.N. Description Present Period / Extended Period /
Provision Provision
Period for downloading and 2 3
i uploading of Tender Document by | From 07.03.2025 to 0 ee 5:00
* | bidder (From 28.03.2025 upto 5:00 hours he VEN ee
Website: www.eproc2.bihar.gov.in): nours
2 Date, Time & Place of Pre-Bid 7.03.2025 at 5:00 hours at 26.03.2025 at 5:00 hours at
“| meeting: BSRDCL HQ BSRDCL HQ
| | bast Date & time for uploading | 99.93.2025 till 5:00 hours on | .04.2025 हा। 5:00 hours
3. | Tender Documents by Bidder : हे हि 5
E. . www.eproc2.bihar.gov.in on www.eproc?2. bihar.gov.in
| through E-proc2:
4 बगल गम बता 0.04.2025 till 2:30 ॥0ए5 | 2.04.2025 till 2:30 hours at
of EMD: BSRDCL HQ BSRDCL HQ
Diatel tite €:Place of opanincof 0.04.2025 at 5:30 hours, at 2.04.2025 at 5:30 hours, at |
5. | ate Gime ee pening BSRDCL HQ through BSRDCL HQ through
Technical Bid: pr062.bi ढ़ www.eproc2 bihar.gov.i
www.eproc?2. bihar.gov.in www.eproc2.bihar.gov.in
6. | Estimated Cost % 8670.00 Lakh & 7557.05 Lakh
Rest all will remain the same.
ai
Ys. N
awh
Chief General Manager
Bihar State Road Development Corporation Limited,
Patna +s
