---
doc_id: "ebf098bf7e3bee2e"
source_url: "https://www.mitmuzaffarpur.org/wp-content/uploads/2021/07/Tender-for-Vechicle.pdf"
ministry: "Muzaffarpur Institute of Technology, Bihar"
title: "Tender for Vechicle"
date: ""
pages: 8
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "1f4e00d7d70e5dcd"
---

<!-- page 1 -->

5 बिहार सरकार
. मुजफ्फरपुर इंस्टीच्यूट ऑफ टेक्नोलॉजी, मुजफ्फरपुर |
(विज्ञान एवं प्रावैधिकी विभाग, बिहार सरकार, पटना के अन्तर्गत)
मुजफ्फरपुर, दिनांकः 24/07 /2023
भाड़े & aes 8g Pfdar yaa WeM-02 / 2024-22 के वाहन हेतु निविदा संख्या-02 ,// 202-22
मुजफ्फरपुर इंस्टीच्यूट ऑफ टेक्नोलॉजी, मुजफ्फरपुर के लिए कार्यहित में एक भाड़े का मासिक दर पर
वाहन की आवश्यकता है। Wed GT WHR Sedan/SUV ay deck Model का वाहन परन्तु तीन वर्ष
से पुराना नहीं होना चाहिए। नये एवं अपेक्षाकृत बड़े वाहन को प्राथमिकता दी जायेगी। इच्छुक वाहन
मालिक (जिनका वाहन भाड़े पर चलने के लिए निबंधित हो),/पंजीकृत ट्रेवल एजेन्ट / अन्य विज्ञापन
की तिथि से अगले 24 दिनों के बीच तक (अवकाश का दिन छोड़कर) संस्थान के कार्य अवधि में
कार्यालय से निविदा फार्म रू0 500//- (पाँच सौ रूपये मात्र) का a gre “Principal, MIT,
Muzaffarpur & ver 4 oh gorrpege A भुगतेय हो” जमा कर प्राप्त कर सकते हैं। निविदा फार्म
(आवश्यक अनुलग्नकों के साथ) एवं जमानत की राशि रू0 5000 /— का बैंक gre “Principal,
MIT, Muzaffarpur} पक्ष में जो मुजफ्फरपुर में भुगतेय हो” स्पीड पोस्ट /निबंधित डाक द्वारा विज्ञापन
की तिथि से अगले 24 दिनों के बीच तक (अवकाश का दिन छोड़कर) स्वीकार किया जायेगा। भाड़े
पर लिए जाने वाले वाहन का अधिकतम भाड़ा रू0 34000/- से अधिक नहीं होना चाहिए जिसमें सभी
ant alga maf (Maintenance) ed & Br 4200 कि0मी0 प्रति माह की दूर चलने के इंधन
(Diesel/Petrol/Lubricant) ot ff wa fated erm | प्रति माह 4200 कि0मी0 से अधिक की दूरी
के परिचालन की स्थिति में केवल इंधन ()०5०/?०४०)) अतिरिक्त देय होगा। विस्तृत ब्योरा संस्थान
@ Website: www.mitmuzaffarpur.org % SIs al
Laas ow
प्राचार्य
ve OEE
Aft}

<!-- page 2 -->

TENDER
FOR
Vehicle for Official Purposes
FOR
Muzaffarpur Institute of Technology, Muzaffarpur |
Tender No.:
Tender Start date:- Date of advertisement ।
[चर 022 ण॑ 5णां5ंणा :- वी] 2] 0395 [गठा ण ९2 of advertisement |

<!-- page 3 -->

Name of Organization-
Tender Notice For Vehicle
7 Notice no,
Sealed Technical and Financial bids are invited from any service provider or owner for providing vehicle round
the clock for the MIT Muzaffarpur for annual contract period of one year, by Registered post /speed post /
| Hand delivery.
Last date of submission: 2] days later of date of advertisement.
Opening of tender:20" August 202] at :30 A.M. at Principal Chamber, MIT Muzaffarpur, Any Change in
| date will be intimated through Website.
| |
| |
| INSTRUCTIONS TO BIDDERS
| All interested vendors are requested to send their sealed quotation for supply of the above item under two bid systems
| in the following manner:
| a) Envelope — |: Technical Bid.
| b) Envelope — IL: Financial Bid. . |
| |
| NOTE: The bid documents are not transferable and the firm's seal and signature of the authorized official must appear |
| onall papers and envelopes submitted, |
| Both the envelops should be sealed, signed, marked and kept in a bigger envelop super scribed with the Tender Reference |
No. and Tender notice detail as appended hereunder.
TENDER for Vehicle |
SS oo Sh, —CC OS  r,””r—C—™—COr, |
|
| | TENDER REF. NO: FOR LAST DATE | |
| | SUBMISSION: ; |
| | ; | |
| | |
| | ‘The Principal |
|| हि |
| |
\ | |
i; | |
| | From: M/S --------—-------Contact
| | No: E-mail ID:
} |
| | | |
|| pe
iP] |
| |
| | |
Ij |
| i
Hf cence Sees ees ee, Me ee > तय 0०2 4॥ बम 2 मत ree पार न जम नप कम पी ली

<!-- page 4 -->

हि I. Terms & Conditions for Vehicle

\. Any person/contractor/registered travel agents may apply. They have to submit all documents

as per format of Technical Bid and financial Bid.

2. The vehicle should be in good condition and it should not be more than three year old.

3. The tender fee of Rs. $00/- (Five Hundred Rupees only) and E.M.D. of Rs. 5,000/- (Five Thousand
Rupees only) -only in the shape of demand draft separately on any nationalized bank in favor of
Principal, MIT Muzaffarpur payable at Muzaffarpur should accompany tender paper.
Without EMD will be ignored straightway.

4. The undersigned reserves the right to rejects any or all the tenders without assigning any reason
thereof.

5. The comparatively new vehicles and of higher model will be given priority.

6. The contact will be kept valid for a period of | ] months which can be extended on mutual
consent basis on the same terms and conditions for further I] months (max three times)

7. Vehicles deployed should be good running condition and should have commercial registration,
current comprehensive insurance and road tax coverage, permit, fitness and driving license of
driver etc.

8. Contractor should keep the vehicles in neat, clean and good running conditions with sheet cloth
covers, which should be replaced with another set of washed covers once in a week. The
contractor should carry out the periodical maintenance of the vehicles supplied and insure them
always in good condition.

9. All payment towards lubricants, repairs, insurance, any taxes etc and any other expenditure
related to vehicles is the contractor's sole responsibility, all payment to the driver towards their

salary, overtime etc is also the contractor's responsibility.

0, Payment will be made on submission of bills.

I]. The contractor can be terminated by giving one months’ notice in writing by either party. In
case of breach of terms and condition, MIT Muzaffarpur , reserves the right to terminate the |
contract without giving any notice.

I2, Incase of accident etc. MIT Muzaffarpur has no responsibility whatsoever towards, police/RTA,
court of law, injured parties, damages to the vehicle or property or any claim made for the loss
etc. All these are entirely the contractor’s responsibility.

3. Any deviation/Violation or breach of the said terms and condition will be viewed seriously, and
the contractor will be terminated without prior notice.

wie tee tot a

<!-- page 5 -->

l4. MIT Muzaffarpur reserves the ight to accept or reject any tender or part of any tender or all
tenders without assigning any reason thereof, irrespective of the fact whether the tender is the
lowest or not.

5. The maximum limit for quoted amount will be 34,000/- per month including fuel for 200 Km
lubricants, taxes & duties as per norms, maintenance cost etc.

6. In case contractor refuses to supply vehicles ordered by MIT Muzaffarpur, it will be viewed
seriously, and contract will be terminated without giving any notice and their security money
will be seized. |

7. The person/contractor/travel agent are directed to submit Technical & Financial Bid in separate |
envelope. The Financial Bid will be open only to technically qualified vendor.

8. The evaluation of tender will be done by the committee on the basis of weightage to Technical
and Financial part.

9. The breakdown of weightage will be as Technical -50 % and Financial -50%, Technical (Age
of Vehicle 30%, Price of Vehicle- 20%). The detailed breakdown of marks is provided in
evaluation sheet in sections follows.

20. After evaluation of Bid, the successful bidder will be informed separately.

2I. The agencies must put their initial on each page submitted. All pages must be numbered and a
note of this should be mentioned on covering letter. The Terms & Conditions duly signed should
be attached with tender paper.

22. The supply of vehicle has to start services within 07 days of intimation. The tenderer may change
vehicle of Quoted in tender by comparatively newer and higher model.

23. The full E.M.D. shall be forfeited in case of backing out of the offer before acceptance.

24. The award of work shall be done on QCBS basis (Quality and Cost Based Selection approach)
among the technically qualified consultant after Technical Evaluation. The lowest financial
proposal (Fm) shall be given a financial score (Sf) of 50 points. The financial score of the
proposals shall be computed as follows:

Sf =30 x Fm/F
(F - Amount of financial Bid).

25. Formula for final score = F + T
Where, T= Marks awarded for Technical Proposal and F= The marks awarded for financial
proposal
The Bidder scoring highest Combined Score shall be declared as preferred Bidder for award of
Contract.

26. In case two or more bidders achieve same combined score, the bidder who’s Financial Proposal
shall result in least cost to MIT Muzaffarpur shall be declared as selected bidder eligible for
award of Contract.

<!-- page 6 -->

= ooo
| Criteria TF Age of If Age of If Age of If Age of More than
| Vehicle < 0] Vehicle Vehicle Vehicle 36 Months |
(One Months) | between 0 between 2 between 24 |
months to !2 | months to 24 months to 36
Months) Months) Months)
ee
Criteria If Price of If Price of If Price of If Price of Less than 8
Vehicle is Vehicle Vehicle Vehicle Lakhs
more than 5 between 2 between 0 between 8
Lakhs Lakhs to 5 Lakhs to 2 Lakhs to 0
Lakhs) Lakhs) Lakhs)
i दि हि | Ps
Pate hae oe
po ee
|
|

<!-- page 7 -->

Pe eee xureel
Technical bid documents
NO Enclosure Enclosed Yes/No
\ Copy of Motor vehicle registration Certificate
2, Copy of Latest Pollution Test
3 Copy of Road Tax
4 Copy of Vehicle fitness Copy of Road Tax
5 Proof of Price of Vehicle (invoice)
6 Income Tax PAN of Agency/Individual U
7 EMD Details a
Wo
Wey
pr: ssignalrd tay iy t
Ie ule & 02८ 2 |
पर ae” |
Note ; In case of new vehicle which is proposed to be supplied SI no I to 4 is not mandatory. However it needs 7 7१%
to be provided before supply of vehicle. In this respect a declaration need to be given.
|
ह
|
|
oe

<!-- page 8 -->

—
~ z
= न 22 z
6: 2
| a
< | ~
oe
2
(2
o हें
Ss 6
= 48 s
ES 3.
3
8 g 2. Zz
ze S 5
पे 2 = =
Be g, °
Og 2 =
7 Oo = oS
au. 9 =
3 8 3 = B
<2 x :
Ge $ $ B
| Q. = fe.
35 6 डि
4 08 7 &
3.0 प्र fe
os 7 e
j 5 8 Zz C
So जा 8
S “ 3
दे & Ee
g e
2 = le
= S छः
g B
a B
es)
a is.
< + =
> \o
2 is 2
=
3G
B
g é
हू ः
rey 3
° 82.
बन वर a
2. £ ई
=e a
Ba 3
Be ;
aw
ae
ws
2s
A
प्र
4,
<
°
tr ©
4 Se
4 &
“ =
a é
How gt
“abe <
4 te yi o>
ga oo one
7» ( 5. 2
ashe ५ "2
Csr ; | 5 Af
v\ SE | a
a 5 | 5 |
= me j |
eee wv en ec ee he ««य॥- आह
