---
doc_id: "f8f3c655afb6a1ba"
source_url: "https://basu.org.in/wp-content/uploads/2023/05/Employment-Notice-No.-04_2023.pdf"
ministry: "Bihar Animal Sciences University (BASU)"
title: "Vacancy for Comptroller Ref. Employment Notification No. 04/2023"
date: ""
pages: 12
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "05cd44b8286bb447"
---

<!-- page 1 -->

७५2.
बिहार पशु विज्ञान विश्वविद्यालय, पटना
BIHAR ANIMAL SCIENCES UNIVERSITY, PATNA- 80004
(Established in 206 under Bihar Animal Science University Act-206)
VACANCY FOR COMPTROLLER
Ref. Employment Notification No.- 04/2023 dated ..6..../05/2023
Applications are invited from Indian nationals for regular appointment to the post of
Comptroller, Bihar Animal Sciences University, Patna.
This is a rolling advertisement and will remain active as per requirements. All applications
received up to .f §).9% ..++ 2023,5.00 PM shall get processed in this phase.
For further details please visit website www.basu.org.in
Sd/-
Registrar,
BASU, Patna
Page I of 4

<!-- page 2 -->

Sent
feed |e
| rt विश्वविद्यालय
(Saber
iy) (uuu
A ४॥४७७७॥१
Bihar Animal Sciences University, Patna
Rolling Advt. No. Emp. Notice No. 04/2023
BASU/2023/Administrative Position Dt. 6/05/ 2023
Rolling Advertisement for the post of Comptroller, Bihar Animal Sciences University, Patna
Bihar Animal Sciences University (BASU) has been established at Patna, Bihar through
BASU Act 2046. The University comprises of one of the oldest veterinary colleges in India i.e.
Bihar Veterinary College, Patna along with Sanjay Gandhi Institute of Dairy Technology, Patna,
College of Fisheries, Kishanganj and a new College of Veterinary & Animal Sciences has been | _
established at Kishanganj, apart from KVK and research stations in the State of Bihar. The primary
focus of the university is to provide quality education, training, research and extension in different
domains of Veterinary and Animal Sciences, Fisheries Sciences and Dairy Technology.
The University is looking for devoted candidates to work as a Comptroller, BASU, Patna.
Comptroller, Bihar Animal Sciences University, Patna
Category - UR
No. of Post- 0
Essential Qualification:

l Master degree with at-least 55% of the marks or its equivalent grade of B in the UGC seven-
point scale in any discipline from a recognized University/ Institute.

2 Atleast 5 years experience as Assistant Professor or equivalent in the AGP of Rs. 7000/- and
above or with eight years of service in the AGP of Rs. 8000/- and above including as Associate
Professor or equivalent along with experience in Educational Administration,

Or,
Comparable experience in research establishment and/or other institutions of higher education
along with experience in educational administration.
Or,
At least I5 years of administrative experience of which 8 years as Deputy Comptroller/ Deputy
Registrar (AGP of 7600/-) or an equivalent post along with experience in educational finance
administration.
Desirable:
i) Well versed in the financial/ accounting system.
ii) Experience in computer system finance/accounts related software handling for
information processing and retrieval.
lii) Officers working in organized Accounts Services of Govt. of India (Preferably from
Indian Audit & Accounts Service) with similar status will be given preference.
Page 2 of 4

<!-- page 3 -->

NOTE:-

«The prescribed essential qualifications and experience indicated are the bare minimum, and mere
possession of the same will not entitle the applicants to be called for an interview. The University
reserves the right to restrict the number of applicants to be called for interview to a reasonable limit,
on the basis of qualification and experience higher than that of the minimum prescribed in the
advertisement. Therefore, applicants should furnish details of all the qualifications and experience
possessed in the relevant field, over and above (if any) the minimum qualification prescribed along
with documentary evidence.

© Retirement age of the post is 62 years.

© The persons from other universities/institutions/organizations will be treated on deputation. However, no
deputation allowance will be admissible.

© At the time of joining, an undertaking should be submitted by the incumbent to serve the University for a
minimum period of 03 years.

Scale of Pay
Comptroller To be placed in Pay level 4 (Rs.,44,200-2,8,200)
General Instructions:-

This is a rolling advertisement. Applications will be accepted throughout the year. The
composite rolling advertisement will remain alive all the time and will be updated every time
whenever position remains vacant. The prospective applicants, therefore, can apply anytime during
the year, as per cutoff date, indicated on the website.

(4) Applicants are requested to submit the application form in the prescribed format along
with supporting documents. Incomplete applications will not be considered and will be
rejected.

(2) University adopts reservations policy as per Government of Bihar.

(3) | The University reserves the right to withdraw the advertised post at any time without giving
any reason.

(4) Candidates, who are employed in Government, Semi-Government Organizations,
Autonomous Organizations, Universities, and Educational Institutes should route their
application “Through Proper Channel” or should submit a “No Objection
Certificate” from the present employer at the time of interview, failing which they may
not be considered.

(5) The University may verify the antecedents or documents submitted by a person at the
time of appointment or during the period of the service. In case, it is detected that the
documents submitted by the candidates are fake or the candidate has clandestine
antecedents or background and has suppressed the said information, then his or her
services shall be terminated.

Page 3 of 4

<!-- page 4 -->

ow (6) Incase of any inadvertent mistake in the process of selection, which may be detected at any
stage even after the issue of appointment letter, the University reserves the right to
modify/withdraw/cancel without any communication made to the candidates.

(7) The Selection Committee may decide its own method of evaluating the performance of the
candidates in the interview.

(8) Persons appointed may be transferred to any equivalent post within the jurisdiction of the
University. .

(9) The cut- off date will be notified on the website from time to time.

(0) In case of any disputes or legal proceedings against the University, the Jurisdiction shall be
restricted to the Courts in Patna, which is the Headquarter of the University.

(7) Hard Copy of the application along with all enclosures should be sent by speed post to the
“Registrar, Bihar Animal Sciences University, Patna, Bihar, PIN- 80004”. The
Advertisement Number & Post Name should be super-scribed on the envelope.

APPLICATION FEE:-

A non-refundable Application Fee of Rs. 000/- to be paid by Bank Draft in favour of
“FINANCE COMPTROLLER, BIHAR ANIMAL SCIENCES UNIVERSITY, PATNA”
Payable at Patna.

CUT-OFF DATE All Applications Received up ॥0 46/06/2023, 5.00 PM shai be
processed in this phase.
हि ee
OR A के के के के कट औ भर मर जे मर
Page 4 of 4

<!-- page 5 -->

—
wes बिहार पशु विज्ञान विश्वविद्यालय, पटना
| Cs ee BIHAR ANIMAL SCIENCES UNIVERSITY, PATNA- 80004
i ee (Established in 20I6 under Bihar Animal Science University Act-206)
(For the post of Copmtroller)
EMPLOYMENT NOTICE - 4/2023
PLEASE INSERT INFORMATION IN BOLD LETTERS thi
Please Affix
: : self-attested
Post Applied for ३. «००००००० ३5 गया
latest
Ady. No. 2 cssesenee tele 00. photograph
Category ६. «००००००००० बूटी पर ०88 लकेल्जनइ+ 7 ड22००००० ० 42० ०००
Demand Draft Details
pe टौः
Amount (Rs.) Name and Branch of
the issuing Bank
This application contains pages (Total number of pages).
| | Name in full (In Block Letters) Dr/Mr/Mrs./Ms.
le ०9 /_/_|'
जी 9 9 |
"
— SF |
a
Page l of 8
Signature of (क्वाता096 ......................

<!-- page 6 -->

*| | |
| _—_ | |
_ 7 | |।
a = _ |e |
™ = “ = |
Present Mailing Address with PIN Code — : yy
“ Permanent Home Address with PIN Code : रु | |
Yl — ‘i
a If you are employed, mention your present designation 5
7. | Name and Designation of your present employer

(Person, office, institution) 4
8. | Have you obtained the permission of your present

employer for submitting this application (if not, you

should have to bring a ‘No Objection Certificate’ from

your employer at the time of the interview)

Have you obtained the permission of your present

employer to serve the University on deputation

preferably for five years, compulsory for three years?

(if yes, submit the desired document)
Page 2 of 8

शछांश्ञाक्षपरार त॑ (क्वाती१६6 ......................

<!-- page 7 -->

20. | Present Pay (as applicable)
i) The scale of pay + grade pay (as per 6"
CPC)
Allowances excluding house rent and CCA | Se ss
If selected, please state the joining time required
22. | Are you willing to accept the initial salary of the grade? (If
no, state what is the minimum salary acceptable with
justification thereof).
23. Academic Qualifications eS
Examination [Senior Post-Graduation Any other | Pg. No. of
Secondary Qualification | enclosure
(0+2) ;
Name of School /
College
Name of Board /
University
| TE | | |
Percentage of
Marks
a a  [[ऋ_ फट
rr
Position,
Distinction,
Prizes,
Scholarship etc.
(Attach self-attested copies of the Detailed Marks Sheets/Cards or Transcripts of all the examinations
passed)
Page 3 of 8
छांश्ाक्षापार 0 (६0046 ......................

<!-- page 8 -->

24. Employment Record
Designation Period (month Duration Pay drawn Full address | Reason for
of posts held and year both (Basic Pay + of the leaving the
should be Grade Pay + | office/firm or post
given) allowances institution
To | Years | Months | Days | except HRA
and CCA)
25. Awards/Honors /Recognitions रा
(List awards including, National awards instituted by Government of India / ICAR / University/, / State
Agency / Professional Society/ University medals (Gold Medal/first position)/ fellowships of National
academies,
Sr. | Name of Award/Honour Conferred by (Name | Year of Award
No. of Organization)
26. Institution Building (Major Contribution).
5
2.
3.
Page 4 of 8
ऊांशाक्वपार 0 (क्वाता१86 ......................

<!-- page 9 -->

27. Experience in Software handling related to Finance / Account System.
l.
2.
3.

28. Experience in Government of India Services (Preferably from Indian Audit & Account
Services).
. —
2.

29. Have you ever been punished / penalized during your service tenure? If so, please specify

30. | Have you ever been prosecuted, kept under detention or bound down/fined, convicted bya
Court of Law of any offence or debarred/disqualified by any University, Public Service
Commission from appearing at its examinations/selection? Is any case pending against you
in any court of law at the time of filling up of this application form?
If the answer is ‘Yes’; full particulars of the case, detention, fine, conviction, sentence etc.
should be given ; ;

3l. References (Please specify the names of two referees who should be responsible persons and
well acquainted with you for the last five years. One of the referees should be the present or
most recent employer).

(a) Name: ह११+++०००९०५»४०२०५९५»५+%+९१२९२०५१५+५+५«२«5«5५५5५«5५«५«२«;८ ०«५०५«०»५००००००००००५००००००००००००००००००००००००००००-०००००००००० ०००.»
Designation: अरशद >>>क>+»+>« ₹९॥ 46 ६ 84 ६ १8 8 6 $ $ 8 8 8 « »३ »-२००७००७काशातापाााकाआ 6 #3 ४ ० ० ० ० २०० ००:१३ भक्ापातकनदाकाधक५»» » ५ ५ २५
Address: ६३०००००+०«»+ककःककम७#++४७४४ 94७ +++++ ०००० * ० + 8 8 8 हड#४##कऋ#कऊ.#++++>००० ९१ ३३७३ ६६ ४###०+३७४००५००५५००००००३०५
(With Pin code) Peco eee ew ene ee RRR eee eer eNaEE SEEN ASH OTEOS SESS edaneerDOSeEOEh eed EE tasecanneneecesesecenes tee eeeee

Page 5 of 8
डांश्ञाधपार 0 (क्वावा१46 ......................

<!-- page 10 -->

E Mail: Settee ses ssa aaa eeeeeeeeeeeeeeeeeeseeeeeeeesssssseeesessseseeussssssesssssseeeetereeeesectseenes
Phone: निकल नह ०० न्‍न्‍न्‍न55 ५५५५५ ५«५«५५- ०-०५ ५०-५० ५५५५५ ५५ -
(b) Name: ककणऋऋ७€आ3 8१९३ ३ ॥ ४8 8 ४ ३ ७०»+*«००७»+# #फ़कफअऊ आफ कक आऊकक ५८4 ॥ ३० ५ ० *००० ०००३४ ३४७ +#रहअककडतक ४ #+४५ ४५4४० ००० ०००९९०५
Designation: Sttteesesses eee eeeeeeeeeeeeeeeeeeceeeeeaeesssseeeeessssesseeseesscsseeessaeseeeseeesessecteseees
Address: ह*न००२२९५५+५+५+५+%+५«««२«««« «२«२८०>००»०५»०«५»+५०;०«५२०५५५»+%+»«०«५»०«००००००००००००००००००००००००००००००००००००००००००००००० ०»
(With Pin code) One eeOLEE NG CUNNAMHED AEE ES EELS 09.09 5s vO Or EYER NNNNUNARMEAS dU 5 0 ones snt SE FER RESEENRNGRKES I65 446
E Mail: *+*००००००००००००***००००००००००००० ०“ तप ० ००००० कक... «५ ५०५ ०००००००००००००००००५५०००
32. Any other details not mentioned above, which you think, will strengthen your claim for this
appointment. ce - fs .. i
(Attach separate sheet, if necessary) : pe
33. List of copy of certificates and testimonials attached:- - a
— उकमणल--
DECLARATION
I certify that the above information is correct-and complete to the best of my knowledge and belief
and nothing has been concealed / distorted. If at any time, it is found that any information is false /
concealed / distorted then, my appointment shall be liable to summarily termination without any notice /
compensation and criminal case may be initiated against me under the relevant Provision of Indian Panel
Code and other laws as applicable. i i Bale
Further, I have gone through the general instructions and conditions mentioned in the
advertisement and website of the university before filling the application. I agree with all terms and
conditions.
Place: Signature of Candidate
Dated:
Page 6 of 8
Signature of Candidate .........0ccccccesees
