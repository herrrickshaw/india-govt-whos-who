---
doc_id: "809fefddaae473bc"
source_url: "https://bceceboard.bihar.gov.in/pdf_Tender/ADV_TEN25_03.pdf"
ministry: "Bihar Combined Entrance Competitive Examination Board (BCECEB)"
title: "Public Notice Regarding M/s Ahilesh Kumar(Tender No.BCECEB(TEN)2025/03 Dated 19.12.2025)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b639636a0166ae8e"
---

<!-- page 1 -->

800014
Website : bceceboard.bihar.gov.in / Helpdesk : helpdesk.bceceboard@bihar.gov.in

2025/03

- 19.12.2025

800001

H-1

800001
