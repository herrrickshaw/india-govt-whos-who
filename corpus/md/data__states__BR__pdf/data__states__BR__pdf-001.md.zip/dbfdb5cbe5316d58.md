---
doc_id: "dbfdb5cbe5316d58"
source_url: "https://www.jpv.ac.in/_files/ugd/732218_61f059bd024f46f1b3bfef5e31e2dbed.pdf"
ministry: "Jai Prakash Vishwavidyala (University), Bihar"
title: "Notification for Appointment of Assistant Professor in Music"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "a00a94f31e18fd5f"
---

<!-- page 1 -->

जय
© जय प्रकाश विश्वविद्यालय
‘@
A राहुल सांक्त्यायन नगर, छपरा-844302, बिहार (मारत)
] वाक।
me JAI PRAKASH UNIVERSITY
aa RR) RAHUL SANKRITYAYAN NAGAR, CHAPRA-84302, BIHAR (INDIA)
Email Id:- regjpuchapra @gmail.com Website: www. jpv.ac.in
Letter No. BASAL Dated:- 2 ros 202k
Notification
In the light of the letter no-.-I 9/A2-07/2025-266, Patna, dated-06.!0.2025 of
Deputy Secretary, Higher Education, Govt. of Bihar, Patna on the recommendation of Secretary, Bihar
State University Service Commission, Patna, Bihar vide memo no.-B.S.U.S.C./fasto-34/2023 (खण्ड-04)-
272S5dated-26.08.2025, The Hon’ble Vice-Chancellor in exercise of the power vested in him U/S 0 of
the Bihar State University Act 976 as amended up-to-date has been pleased to appoint the following
persons as Assistant Professor in the Subject Music in the Pay Scale of Rs. 57,700-,82,400/- in academic
level-I0 (7" CPC) along with D.A. and other admissible allowance as admissible by the State Govt. time
to time. They will be on probation for a period of two years from the date of joining and they are being
Posted in the Colleges mentioned against their names, subject to the approval of the Syndicate.
The payment of first salary will be made only after receiving of grant from the State Govt. for
them. .
SI.No. Name Res. Place of Posting
Cat.
| | Dr. Shivani Shukla Jai Prakash Mahila College, Chapra, Saran
Smt. Aradhana Kumari Vidya Bhawan Mahila College, Siwan
They are directed to submit their joining report within fifteen (5) days from the date of issuance
of this notification to the Principal/Prof.-in-charge of the College mentioned against each of their names.
They are also directed to submit self-attested copies of all original documents to their respective
department/college.
No T.A. shall be paid for this purpose.
By the order of the Hon’ble Vice-Chancellor
A)
r
(Prof. (Dr.) Na yan Das)
8 LS e T 992
Memo No.- AS: / Dated:- 9 H/o 6९% १
Copy Forwarded to:-
l. Concerned Persons.
2. The Dean, Faculty of Humanities, Jai Prakash University, Chapra, Saran.
3. Principal/Prof.-in-charge, Concerned Constituent College, Jai Prakash University, Chapra, Saran.
4. Secretary, Governor’s Secretariat, Bihar lok Bhawan, Patna-800022
5. Director, Higher Education, Education Department, Govt. of Bihar, Patna,
6. Secretary, Bihar Public Service Commission, Patna.
7. Secretary, University Grant Commission, Bahadur Shah Zafar Marg, New Delhi.
8. Finacail Advisor/Finance Officer, Jai Prakash University, Chapra, Saran,
9, P.A. to Hon’ble Vice-Chancellor/Registrar, Jai Prakash University, Chapra, Saran,
0. Guard File.
for information and the needful. wera és we
Registrar
dh, | हैं
