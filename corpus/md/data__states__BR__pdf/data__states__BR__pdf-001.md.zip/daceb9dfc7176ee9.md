---
doc_id: "daceb9dfc7176ee9"
source_url: "https://bshb.bihar.gov.in/Admin/tender/39.pdf"
ministry: "Bihar State Housing Board (BSHB)"
title: ""
date: ""
pages: 68
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "08d40413cb75c6b5"
---

<!-- page 1 -->

Request for Proposal (RFP)
for

Selection of a Consultant for Project Management
Unit (PMU) for Bihar State Housing Board

Procuringauthority: Bihar State Housing Board, Patna, Bihar

Issued on Date : 28-03-2026

1

<!-- page 2 -->

DISCLAIMER
The information contained in this Request for Proposal (“RFP”) document or subsequently provided
to Bidders, whetherverbally or in documentary or any other form by or on behalf of the BSHBor any of
their employees or advisers, isprovided to Bidders on the terms and conditions set out in thisRFP and
such other terms and conditions subject towhich suchinformationisprovided.
This “RFP” is not an agreement and is neither an offer nor invitation by the BSHB to the prospective
Bidders or anyother person. The purpose of this “RFP” is to provide interested parties with information
that may be useful to them inthe formulation of their Proposals pursuant to this “RFP”. This “RFP”
includes statements, which reflectvariousassumptions and assessments arrived at by the BSHB. Such
assumptions, assessments and statements do not purportto contain all the information that each Bidder
may require. This “RFP” may not be appropriate for all persons, and it isnot possible for the BSHB, its
employees or advisers to consider the objectives, technical expertise and particularneeds of each party
who reads or uses this “RFP”. The assumptions, assessments, statements and information containedin
this “RFP”, may not be complete, accurate, adequate or correct. Each Bidder should, therefore, conduct
its owninvestigations and analysis and should check the accuracy, adequacy, correctness, reliability and
completeness of theassumptions, assessments and information contained in this “RFP” and obtains
independent advice from appropriatesources.
Information provided in this “RFP” to the Bidders is on a wide rangeof matters, some of which depends
uponinterpretation of law. The information given is not an exhaustive account of statutory requirements
and should not beregarded as a complete or authoritative statement of law. The BSHB accepts no
responsibility for the accuracy orotherwise forany interpretationoropinion onthelawexpressedherein.
The BSHB, its employees and advisers make no representation or warranty and shall have no liability to
any personincluding any Bidder under any law, statute, rules or regulations or tort, principles of
restitution or unjust enrichment orotherwise for any loss, damages, cost or expense which may arise
from
or
beincurred
or
suffered
on
account
ofanythingcontainedinthis“RFP”orotherwise,includingtheaccuracy,adequacy,correctness,reliabilityorco
mpleteness of the “RFP” and any assessment, assumption, statement or information contained therein or
deemed toformpart ofthis “RFP”orarisinginany wayinthisSelectionProcess.
The BSHB also accepts no liability of any nature whether resulting from negligence or otherwise
however causedarisingfrom relianceofanyBidder uponthestatementscontained in this“RFP”.

The BSHB may in its absolute discretion, but without being under any obligation to do so, update,
amend or supplement the information, assessment or assumption contained in this “RFP”.

2

<!-- page 3 -->

CONTENTS
Section - I: Notice Inviting Tender (NIT) ............................................................................................................................... 4
Section – II (Part A) Instruction to Bidders ........................................................................................................................... 6
1.
DEFINITIONS............................................................................................................................................................................
2.
INTRODUCTION ......................................................................................................................................................................
3.
JOINT VENTURE / CONSORTIUM.........................................................................................................................................
4.
BID DOCUMENT ......................................................................................................................................................................
5.
PRE-BID MEETING ..................................................................................................................................................................
6.
BIDDER INQUIRIES ................................................................................................................................................................
7.
AMENDMENT OF BID DOCUMENT .....................................................................................................................................
8.
CONFLICT OF INTEREST .......................................................................................................................................................
9.
FRAUD AND CORRUPT PRACTICES....................................................................................................................................
10.
ELIGIBILITY CRITERIA..........................................................................................................................................................
11.
PREPARATION OF PROPOSAL..............................................................................................................................................
12.
BID SUBMISSION.....................................................................................................................................................................
13.
BID OPENING AND EVALUATION.......................................................................................................................................
14.
PROCURING AUTHORITY‟s RIGHTS ...................................................................................................................................
Section II (Part B): Bid Data Sheet ....................................................................................................................................... 23
Section – III Conditions of Contract ..................................................................................................................................... 25
Section – IV Bid Forms .......................................................................................................................................................... 32
GEN: FORM - 1: Format for Letter of Application (Bidder) ........................................................................................... 34
GEN: FORM- 2: Format for Power of Attorney for Signing of Application .................................................................... 36
GEN FORM 3: Format for Details of Applicant .............................................................................................................. 37
GEN: FORM - 4: General Profile .................................................................................................................................... 38
GEN FORM- 5: Format for Affidavit Certifying that Entity is not Blacklisted/ Debarred............................................... 39
GEN FORM- 6: Declaration regarding any Conflict of Interest and Anti-Collusion Certificate...................................... 40
TECH FORM - 1 (A): Supporting format for Project Experience of the Applicant ......................................................... 41
TECH FORM - 1 (B): Format for Project Experience of the Applicant ........................................................................... 42
TECH FORM - 2: COMMENTS AND SUGGESTIONS ON TERMS OF REFERENCE ............................................. 43
TECH FORM 3A: Format for Financial Capability of the Applicant .............................................................................. 44
TECH FORM 3B: Positive Net worth of the Applicant ................................................................................................... 45
TECH FORM- 4: Understanding of Scope with Approach and Methodology (A & M) .................................................. 46
TECH FORM- 5 Format for HR Certification of the Technical Manpower Organisational Strength .............................. 47
TECH FORM- 6: Format for sharing details of the Resources/Personnel to be deployed ................................................ 48
TECH FORM- 7: Format of Curriculum Vitae (CV) for Manpower (Key Personnel) ..................................................... 49
TECH FORM- 8 Format for HR Certification of the Technical Manpower Organisational StrengthError! Bookmark not defin
FINANCIAL FORM 1: Letter of Financial proposal ....................................................................................................... 52
FINANCIAL FORM 2: FINANCIAL PROPOSAL COVER .......................................................................................... 54
FINANCIAL FORM 3: Financial Proposal Format (amounts in INR) ............................................................................ 55
FINANCIAL FORM – 3 (A): Breakdown of Remuneration Cost ................................................................................... 56
FINANCIAL FORM 3 (B): OTHER EXPENSES ........................................................................................................... 57
FINANCIAL FORM 4: Performance Bank Guarantee .................................................................................................... 58
FINANCIAL FORM 5: Bid Security Form (Bank Guarantee) ........................................................................................ 60
SECTION V CONTRACT FORMAT .................................................................................................................................. 61
Section VI: Terms of Reference ............................................................................................................................................. 63

3

<!-- page 4 -->

SECTION - I: NOTICE INVITING TENDER (NIT)
“Selection of a Consultant for Project Management Unit (PMU) for Bihar State Housing Board”
BIHAR STATE HOUSING BOARD, PATNA, BIHAR
Phone: (0612) 2217617, 2217618
Email:Secretary.bshb-bih@gov.in
Website:https://www.bshb.bihar.gov.in
NIT No:-09/2025-26

Date:-…28/03/2026

1. BIHAR STATE HOUSING BOARD, PATNA, BIHAR, invites proposals from eligible firms to “Selection of
a Consultant for Project Management Unit (PMU) for Bihar State Housing Board”.
2. Interested Consultancy Firms may download the complete Request for Proposals (RFP) Document, from
website: https://eproc2.bihar.gov.in or https://www.bshb.bihar.gov.in

SN PARTICULARS

DETAILS

1

Website for submission of proposal

www.eproc2.bihar.gov.in/

2

Mode of Submission

Online submission through eproc2 portal
(www.eproc2.bihar.gov.in) and at the same
time submission of Hard copies of Tender fee,
Bid Security, payment proof, original copy of
affidavit, declaration regarding Blacklisting and
Power of Attorney as per RFP document at
Bihar

State

Housing

Board,

Patna,

Biharoffice at Bihar State Housing Board,
Patna, Bihar, 6, Sardar Patel Marg
3

Last date and time for Submission of 04.05.2026 up to 3:00 PM
Technical
Proposal
on
www.eproc2.bihar.gov.in

4

Date and time of Pre bid meeting

5

20.04.2026 by 11:30AM
Bihar State Housing Board, Patna, Bihar
6, Sardar Patel Marg,
Patna 800 015, Bihar INDIA
Last date and time for Submission of Hard 04.05.2026 up to 03:30 PM
Copies (Tender fee, payment proof, original Bihar State Housing Board, Patna, Bihar
copy of affidavit, Blacklisting and Power of 6, Sardar Patel Marg Patna - 800015
Attorney as per RFP document)

4

<!-- page 5 -->

6

Date and time of opening of Technical Bids

04.05.2026 at 04:00 PM

7

Date and time of opening of Financial Bids

Will be intimated later to successful bidders

8

Date and time of Presentation.

Will be intimated later to successful bidders

9

Method of Selection

QCBS (Quality and Cost Based Selection)
method of evaluation

3.

Agencies/ Firms may download the complete Request for Proposal (RFP) Document, from website:
https://eproc2.bihar.gov.inor https://www.bshb.bihar.gov.in

4.

For participating in e-RFP process, the applicant shall have to get them registered to get user ID Password and
digital Signature. This will enable them to access the website- www.eproc2.bihar.gov.in and participate in etender. Those who are not registered in e-tendering systems, they may contact "e- procurement HELPDESK,
Junction Services Limited, RJ Complex,2nd Floor, Canara Bank Campus, Khajpura, Ashiana Road, P.S.Shastri Nagar, Patna -800014" (Toll Free Number:18005726571, Emal: eproc2support@bihar.gov.in) for
registration.

5.

The RFP can be postponed or cancelled at any time due to administrative reasons and no claim shall be
entertained on this account.

6.

Modifications/Amendments/Corrigendum, if any shall not be advertised in the newspaper but shall be
published on the Bihar State Housing Board website and https://eproc2.bihar.gov.in.

7.

All the uploaded documents shall have the signature of Consultants or their authorized signatories.

8.

The scanned copies should be of the original papers and certificates.

9.

No claim shall be entertained on account of disruption of internet service being used by Consultants.

10. Consultants are advised to upload their bids well in advance to avoid last minute technical stage.
11. The undersigned reserve the right to change the terms and conditions, select/reject any application without
assigning any reason thereof.

12. The proposals must be accompanied with a non-refundable Tender fee of Rs. 10,000/-(Rupees Ten Thousand
only) and Ernest money deposit of ₹10 Lakh(Rupees Ten Lakhs only)by the agency to submit in form of
internet payment gateway (IPG) or BG in favour of „Bihar State Housing Board, Patna‟ payable at Patna,
Bank Details for BG: Bihar State Housing Board, Patna, Bank A/c No. 442920110000182,
IFSC: BKID0004429

13. The evaluation shall be done based on uploaded documents only https://eproc2.bihar.gov.in.

Secretary
Bihar State Housing Board, Patna, Bihar

5

<!-- page 6 -->

SECTION –II (PART A) INSTRUCTION TO BIDDERS
(a) "Assignment/ job" means the work to be performed by the Consultant
1. DEFINITIONS

pursuant to the Contract.
(b) "BSHB" means Bihar State Housing Board, Patna, Bihar
(c) "Client" means The Secretary Bihar State Housing Board, Patna, Bihar
(d) "Consultant" means any entity or person or associations of person that may
provide or provides the Services to the Employer under the Contract.
(e) "Contract" means the Contract signed by the Parties and all the attached
documents listed in its Clause 1, that is the General Conditions (GC), and the
Appendices.
(f) "Data Sheet" means such part of the Instructions to Consultants used to
clarify the relevant clause of Instructions to Consultant or to replace certain
clause of the Instructions to Consultant specific to the assignment.
(g) "Day" means calendar day.
(h) "Employer or Client" means the Bihar State Housing Board, Patna, Bihar
Govt. of Bihar who have invited the bids for PMU-BSHBwhich the selected
Consultant signs the Contract for the Services and to which the selected
consultant shall provide services as per the terms and conditions and TOR of
the contract.
(i) "Government" means the Government of Bihar.
(j) "Instructions to Consultants" (Section 2 of the RFP) means the document
which provides Consultants with all information needed to prepare their
proposals.
(k) "Joint Venture" means a Consultant which comprises two or more Partners
each of whom will be jointly and severally liable to the Client for all the
Consultant's obligations under the Contract.
(l) "NIT" (Section 1 of the RFP) means the Notice Inviting Tender being sent by
the Employer to the consultants.
(m) "Partner" means any of the entities that make up the Joint Venture; and
Partners means all those entities.
(n) “Personnel” means professionals and support staff provided by the
Consultant and assigned to perform the Services or any part thereof;
“Foreign Personnel” means such professionals and support staff who at the
time of being so provided had their domicile outside the Government's
country; “Domestic Personnel” means such professionals and support staff
who at the time of being so provided had their domicile in India.
(o) Project specific information” means such part of the Instructions to
Consultants used to reflect specific project and assignment conditions.
(p) “Proposal” means the Technical Proposal and the Financial Proposal.
(q) “RFP” means the Request for Proposal prepared by the Employer for the
selection of Consultants, based on the SRFP
(r) “Services” means the work to be performed pursuant to the Contract.
(s) “Standard Electronic Means” includes facsimile and email transmission
(t) “Terms of Reference” (TOR) means the document included in the RFP as
Section 5 which explains the objectives, scope of work, activities, tasks to be
6

<!-- page 7 -->

performed, respective responsibilities of the Employer and the Consultant,
and expected results and deliverables of the Assignment/job.
Bihar State Housing board (BSHB) represents a statutory authority constituted by
2. INTRODUCTION the Government of Bihar under the Bihar State Housing Board act,1982 and is
mandated with the development of various housing schemes & related
infrastructural facilities in the State.
Joint Venture/Consortium are not allowed.
3. JOINT VENTURE
/ CONSORTIUM

(i)
4. BID
DOCUMENT

5. PRE-BID
MEETING

6. BIDDER
INQUIRIES

The E-tender (Bid-document) shall be downloaded from website
https://eproc2.bihar.gov.in/ free of cost. Corrigendum, if any, would appear
only on the above website and would not be published in any News Paper”.
(ii) The bidder has to pay a sum of Rs 10,000/- (Rs. Ten Thousand only) +
applicable GST through RTGS as Tender document fee which is payable
while uploading the bid. The details of RTGS are given Below:
Bank Account Name, Account details, IFSC Code:
Please see point 12 under Section I „NOTICE INVITING TENDER (NIT)‟
(iii) The Bid Document (RFP) is not transferable to any other bidder.
(iv) The intending bidder are advised to read the terms and conditions
carefully. The bidder should only submit his tender if he considers himself
eligible and he is in possession of all the original documents required.
(v) Information and Instructions for bidder, available on Website(s) shall form
part of Tender Document.
(vi) The intending bidder must have valid digital signature to submit the Etender.
(vii) The Tender Document as uploaded can be viewed and downloaded free of
cost by anyone including intending bidder. But the E-tender should only be
submitted after uploading the mandatory scanned copy of Bank Challan for
money transfer by RTGS against EMD and cost of Bid- document & all
other required documents as mentioned in this Bid- document.
The bidders shall submit the pre-bid queries to Secretary.bshb-bih@gov.in on or
before the date mentioned below.
Date & Time of Pre-Bid Meeting:20/04/2026 by 11:00AM
Venue: Bihar State Housing Board, Patna, Bihar, 6, Sardar Patel Marg, Patna800015, Bihar
Link to attend the pre-bid meeting virtually: to be shared on request through
email: Secretary.bshb-bih@gov.in
Bidders requiring specific points of clarification may communicate with Bihar
State Housing Board before the date of pre-bid meeting using the
TECH: FORM-5: Pre-bid queries format to the email id: Secretary.bshbbih@gov.in
(i) All requests for clarifications should be sent to Secretary.bshbbih@gov.inpreferably on Word format on or before the deadline for sending
queries as mentioned in the ITB Clause 3 above. Pre–bid queries received
after due date & time shall not be accepted under any circumstances.
(ii) Telephone calls will not be accepted for clarifying the queries.
7

<!-- page 8 -->

(iii) BSHB will endeavour to provide a full, complete, accurate, and timely
response to all questions. The responses to the queries from all bidders will be
distributed to all.
(iv) The bidder or its official representative will be invited to attend the pre-bid
meeting.
(v) The purpose of the meeting is to provide bidders with information regarding
the RFP and the project requirements, and to provide each bidder with an
opportunity to seek clarifications regarding all aspect of the RFP and the
project.
1) At any time before the deadline for submission of bids, Procuring Authority
may, for any reason modify the RFP document by an amendment. All the
7. AMENDMENT
amendments/corrigendum (if any) made in the Bid Document would be
OF BID
published on the e- tendering web-site as corrigendum. All such
DOCUMENT
corrigendum/amendments shall be binding on bidder without any further act
or deed on Bihar State Housing Board part.
2) In the event of any amendment, BSHB reserves the right to extend the
deadline for the submission of the bids, in order to allow prospective Bidders
reasonable time in which to take the amendment into account while preparing
their bids
3) The bidders are advised to regularly check the e-tendering web-site
(https://eproc2.bihar.gov.in/) for updates.
1) The Consultant and its affiliates shall not engage in consulting activities that
conflict with the interest of the Procuring Authority / GoB under the contract
8. CONFLICT OF
and shall be excluded from downstream supply of goods or construction of
INTEREST
works or purchase of any asset or provision of any other service related to the
assignment.
2) Relationship with Employer's staff: Consultant (including their personnel and
sub- Consultant) that have a business or family relationship with such
member(s) of the Employer's staff or with the staff of the project
implementing agency, who are directly or indirectly involved in any part of: i) the preparation of the TOR of the contract,
ii) the selection process for such contract, or
iii) supervision of such contract; may not be awarded a contract unless it is
established to the complete satisfaction of the employing authority, for the
reason to be recorded in writing, that such relationship would not affect the
aspects of fairness and transparency in the selection process and monitoring
of Consultant‟s work.
The consultant has an obligation to disclose to the client any situation of actual or
potential conflict that impacts its capacity to serve the best interest of its client.
Failure to disclose such situations may lead to the disqualification of the Agency
or the termination of its Contract.
1) The Procuring Authority will reject a proposal for award if it determines that
the bidder recommended for award, or any of its personnel, or its agents or,
9. FRAUD AND
vendors and/or their employees, has, directly or indirectly, engaged in
CORRUPT
corrupt, fraudulent, collusive, coercive, or obstructive practices in competing
PRACTICES
for the contract in question;
2) For the purposes of this provision, the terms are set forth as follows:
3) “Corrupt practice” is the offering, giving, receiving, or soliciting, directly or
8

<!-- page 9 -->

indirectly, of anything of value to influence improperly the actions of another
party;
4) “Fraudulent practice” is any act or omission, including a misrepresentation,
that knowingly or recklessly misleads, or attempts to mislead, a party to
obtain a financial or other benefit or to avoid an obligation;
5) “Collusive Practice” is an arrangement between two or more parties designed
to achieve an improper purpose, including to influence improperly the actions
of another party;
6) “Coercive Practice” is impairing or harming, or threaten to impair or harm,
directly or indirectly, any party or the property of the party to influence
improperly the actions of a party;
“Obstructive Practices” is deliberately destroying, falsifying, altering, or
concealing of evidence material to the investigation or making false statements to
The Purchaser in order to materially impede an investigation into allegations of a
corrupt, fraudulent, collusive or coercive practice; and or threaten, harassing, or
intimidating any party to prevent it from disclosing its knowledge of matters
relevant to the investigation or from pursuing the investigation.
10.ELIGIBILITY
CRITERIA

Sl.
TECHNICAL ELIGIBILITY DOCUMENT
No.

1

2.

3.

SUPPORTING
DOCUMENTS

The bidder must be single legal entity i.e.
Company,
LLP,
Partnership
Firms,
Proprietorship, etc. registered under their Copy of Incorporation
respective Acts. registered under any of:
Certificate
- The Indian Companies Act (1956),
- Limited Liability Partnership Act (2008),
- The Partnership Act (1932),
or any other Act/Law and should have been in
operation in India for at least 7 (seven) years
with proof of registered office in India,
Incorporation/Registration
Certificate/
Commencement of Business. (Copy of
registration certificate to be attached)
The Bidder must enclose PAN card details.
Must have valid registration for income tax
and GST.
Annual Turnover & Positive Net worth:
The bidder should have a positive net worth
and a minimum average annual turnover of
INR 25 Crores in similar nature of work in
the last three financial years prior to 31st
March 2025 i.e. (2022-23, 2023-24, 20242025).

A copy of certificate
to be attached

Documents to be
submitted:
Audited
Financial
Statement and copy
of ITR for the
financial year, 202223, 2023-24, 20242025
For the avoidance of doubt, professional fees Annual
Turnover
hereunder refer to fees received by the Bidder Certificate of similar
for providing PMU and other similar nature of work and
consultancy services to its clients;
Net Worth Certificate
from
Chartered
9

<!-- page 10 -->

4

Net worth of Bidder during last audited
financial year - FY 2024-25 shall be positive.

Accountant
UDIN no.

The Bidder shall have, over the past 07
(seven) years preceding the Proposal Due
Date:

Documents to be
submitted:
Copy of Work Order,
Completion
Certificate / Payment
Certificate from the
Client,
to
be
submitted in support
of the claim and to be
signed
by
the
authorized signatory
of the organization,
without which the
experience of the
referred project will
not be considered for
evaluation.
BSHB may choose to
verify the claims of
organization.
CVs of experts duly
verified by Bidder‟s
HR

A. Provided PMU or similar support for
atleast 2 Govt. projects with minimum
professional fee of not less than INR 01
Crore.

(Copy of Work Order, Completion Certificate
/
Payment
Certificate
from
the
Client/Chartered Accountant shall be attached
without which the experience of the referred
project will not be considered for evaluation.)
(Similar nature may be considered as Project
management unit (PMU) / Project Support
Unit (PSU) / Nodal Consultant etc.)

5.

Key Personnel
(As per the list under 6. Key Personnel Proposed Team for carrying out the
assignment under Section VI: Terms of
Reference)

with

1. Team Leader cum PPP Expert
2. Urban Planner
3. Architect
4. Infrastructure Planner
5. Finance Expert
6. Legal Expert
(ii) Technical Team/Support Team
1. Financial Analyst (1 Nos.)
2. Procurement Expert (1 Nos.)
3. Project Monitoring (1 Nos.)
6.

7.

Joint Venture and Consortium
For details, please see ITB 3 and other
relevant clause/s
Bidders declared blacklisted by any State
Government/Central Government/ PSU/ULB
/DA/HB due to corrupt, fraudulent or any
other unethical business practices as on date
of bid submission shall not be eligible.

Not Allowed.

Self-Attested
Undertaking by the
Bidder Company in
Format -1
10

<!-- page 11 -->

(Format given in Section IV Bid forms)

11.PREPARATION
OF PROPOSAL

Applicants are requested to submit their Proposal strictly in the formats provided
in this RFP under Section IV Bidding Form. The BSHB will evaluate only those
Proposals that are received in the specified forms and complete in all respects.
In preparing their Proposal, Applicants are expected to thoroughly examine the
RFP Document. Bid should be valid for the period mentioned in ITB clause 9.7
The Technical Proposal and Financial Proposal should provide the documents as
prescribed in Section IV Bid Forms. No information related to financial proposal
should be provided in the Prequalification / technical proposal.
Failure to comply with the requirements spelt out above shall lead to
disqualification. Further, in such a case, BSHB will be entitled to reject the
Proposal. However, if any information related to financial proposal is included in
the technical proposal the applicant shall be disqualified and his proposal will not
be considered.

The Proposals must be digitally signed by the Authorized Representative as
detailed below:
a. by the proprietor in case of a proprietary firm; or
b. by a partner, in case of a partnership firm and/or a limited liability
partnership; or
c. by a duly authorized person under resolution of the Board, in case of a
Limited Company or a corporation;
In preparing their Proposal, Applicants are expected to thoroughly examine the
RFP Document.
The proposal submitted by Bidder and all subsequent correspondence and
11.1.
LANGUAGE OF
documents/clarifications exchanged relating to the bid between Bidder and the
THE PROPOSAL Procuring Authority shall be written in English If any supporting documents
submitted are in any language other than English, translation of the same in
English language is to be duly attested by the Bidders. For purposes of
interpretation of the documents, the English translation shall govern.
Technical proposals mean all the required technical information to be prepared in
11.2.
PREPARATION
accordance with the Section VI: Terms of Reference and submitted only in the
OF TECHNICAL formats given under Section IV Bid forms. Any change in the prescribed format
PROPOSAL
will be considered as major deviation and will be rejected for further evaluation.
Each Bidder is expected to become fully acquainted with the local conditions and
11.3.
ACQUAINTANCE factors, which may affect the performance of the contract and /or the cost.
OF LOCAL
CONDITIONS
The Bidder is expected to know all conditions and factors, which may have any
effect on the execution of the contract after issue of letter of Award as described
in the bidding document.
It is the Bidder‟s responsibility that such factors have been properly investigated
and considered before submitting the proposal. No claim, what-so-ever, including
that for financial adjustment to the contract awarded under the bidding document
will be entertained by the BSHB. Neither any change in the time schedule of the
contract nor any financial adjustments arising there-of shall be permitted by the
BSHB on account of failure of the Bidder to know the local laws / conditions.
11

<!-- page 12 -->

11.4.
COST OF BID
PREPARATION
& SUBMISSION

11.5. PROPOSAL
FORMAT

11.6.
PREPARATION
OF FINANCIAL
PROPOSAL

The bidder shall bear all costs associated with the preparation and submission of
its bid and BSHB shall in no event or circumstance be held responsible or liable
for these costs, regardless of the conduct or outcome of the bidding process. All
costs incurred in connection with participation in the bidding process, including,
but not limited to, costs incurred in participation in meetings/ discussions/
presentations, preparation of proposal, in providing any additional information
required by Selection Committee to facilitate the evaluation process and in
negotiating a definitive contract or all such activities related to the bid process
will be borne by the bidder. This RFP does not commit BSHB to award a
contract. Further, no reimbursable cost may be incurred in anticipation of award.
Bidders shall furnish the required information on their technical and financial
proposals in the prescribed formats only.
The bidder is expected to examine all the instructions, guidelines, terms and
conditions and formats in the Bid document. Failure to furnish all the necessary
information as required by the Bid Document on submission of a proposal not
substantially responsive to all the aspects of the BID Offer shall be at bidders‟
own risk and may be liable for rejection. The Formats of various pre-requisites
are given in Section IV Bid Forms.
The Bid Offers should be submitted containing the following three parts:
a) Part-A (Eligibility) shall contain the Eligibility Details (as mentioned in
bid-document).
b) Part-B (Technical Bid) shall contain the Technical Bid (as mentioned in
bid-document).
c) Part-C (Financial Bid) shall contain the Financial bid on the prescribed
format given in Fin Forms quoting the price both in words and figures. In
case of conflict between the figures and words the latter shall prevail.
Applicants are expected to take into account the various requirements and
conditions stipulated in this RFP document.
a. The Financial Proposal should be a lump sum Proposal inclusive of all the
costs including all taxes associated with the Assignment.
b. All the costs associated with the Assignment shall be included in the Financial
Proposal. These shall normally cover remuneration for all the personnel
(Expatriate and Resident, in the field, office, etc.), accommodation, air fare,
transportation, equipment, printing of documents, data collection, etc.
c. The total amount indicated in the Financial Proposal shall be without any
condition attached or subject to any assumption and shall be final and binding.
In case any assumption or condition is indicated in the Financial Proposal, it
shall be considered nonresponsive and liable to be rejected.
d. The Financial Proposal shall take into account all the expenses and tax
liabilities and cost of insurance (if any) specified in the work order, levies and
other impositions applicable under the prevailing law. For the avoidance of
doubt, it is clarified that all taxes, shall be deemed to be included in the cost
shown under different items of Financial Proposal.
e. The proposal should be submitted as per the standard Financial Proposal
submission forms prescribed in this RFP.
f. Applicants shall express the price of their services in Indian Rupees (INR)
only.
12

<!-- page 13 -->

11.7.
BID VALIDITY
11.8.
EXTENSION OF
BID VALIDITY

11.9.
CONTACTING
PROCURING
AUTHORITY
DURING THE
EVALUATION

11.10.
BID SECURITY/
EARNEST
MONEY
DEPOSIT (EMD)

The offer submitted by the Bidders should be valid for minimum period of 90
days from the date of opening of Bids. A proposal valid for shorter period shall be
rejected as non-responsive.
If need arise, the Procuring Authority before the expiration of the bid validity
period, in writing may request all eligible Bidders to extend the Proposal‟s
validity.
The bid validity extension should be unconditional, no change in prices or
substance of the bid shall be sought, offered, or permitted, any conditional
extension would result in rejection of the proposal.
The Bidder has the right to refuse to extend the validity of its Proposal. In such
case the Proposal will not be evaluated further.
From the time of bid submission to awarding the contract, no Bidder shall contact
the Procuring Authority on any matter relating to the submitted bid. Any effort by
a Bidder to influence the Procuring Authority during the processing of bids,
evaluation, bid comparison or award decisions shall be construed as a violation of
the Code of Integrity, and bid shall be liable to be rejected as nonresponsive in
addition to other punitive actions for violation of Code of Integrity as per the
Tender Document.
I.

Bidders shall submit, Bid Document Fee of Rs. 10,000 plus applicable
GST. and EMD of Rs. 10 (Ten) Lakhs through RTGS.
II.
No interest shall be payable to the bidder on the amount of the EMD.
III.
Unsuccessful bidder‟s EMD shall be discharged/ returned within 30 days
after the award of the contract to the selected bidder.
IV.
The EMD may be forfeited:
a) If a bidder withdraws his bid or increases his quoted prices during the
period of bid validity or its extended period, if any; or
b) In the case of a successful bidder if the bidder fails to sign the contract for
any reason not attributable to the BSHB or to furnish Performance Bank
Guarantee within specified time in accordance with the format given in the
BID.
c) During the bid process or even after execution of agreement or till the
completion of this assignment, if any information is found wrong /
manipulated / hidden in the bid, the decision of BSHB regarding forfeiture
of the EMD and rejection of bid or termination of contract, shall be final &
shall not be called upon question under any circumstances.
BSHB will be entitled to invoke the Earnest Money Deposit in regard to the
RFP without prejudice to BSHB‟s any other right or remedy under the
following conditions:
(iii) If an Applicant engages in a corrupt practice, fraudulent practice, coercive
practice, undesirable practice or restrictive practice as envisaged under this
RFP (including the Standard Form of work order);
(iv) If any Applicant withdraws its Proposal during the period of its validity as
specified in this RFP and as extended by the Applicant from time to time,
(v) In the case of the Selected Applicant, if the Selected Applicant fails to
accept the work order or provide the Performance Security of specified
13

<!-- page 14 -->

amount within the specified time limit, or
(vi) If the Applicant commits any breach of terms of this RFP or is found to
have made a false representation to BSHB.
(vii) If the Applicant commits any act which can or which causes any loss to
BSHB.
12. BID
SUBMISSION

12.1.
POWER OF
ATTORNEY

The Proposal shall be submitted through e-procurement portal (The procedure for
filing of e-tender is provided on the portal. The applicants are advised to
familiarize themselves with the process in advance to avoid any inconvenience at
a later stage. Files uploaded on the portal should have file name in accordance to
following format [form_name.applicant_name]. Applicant name should contain
only first two words of its name. Only Bids/ proposals submitted On-line on eproc
portal shall be opened. No proposal shall be accepted after the closing time for
submission of Proposals.
The letter of authorization must be confirmed by a written power of attorney
accompanying the proposals (as per the format given in GEN: FORM- 2:
Format for Power of Attorney)
A certified copy of the Power of Attorney on a stamp paper of Rs. 100 and duly
notarized shall accompany the proposal original should be produced subsequently
for verification and return.

12.2.
SIGNING OF BID

The Bid Document shall be signed by a person or persons duly authorized
(through power of attorney for Signing of Application) to bind the Bidder to the
Contract. The person or persons signing the Bid Document shall initial all pages
of the Bid Document, including places where entries or amendments have been
made.

12.3.
MODE OF
SUBMISSION

The Technical & Financial both the Bids shall be submitted through e-portal only
i.ehttps://eproc2.bihar.gov.in/

12.4.
UPLOADING OF
PROPOSAL / BID

a) Bid Offer can be submitted from the specified date as published in “Notice
inviting tender” in E-tendering web-site i.e. https://eproc2.bihar.gov.in/
b) The bidders are required to upload self-attested scanned copies of all the
documents mentioned in the bid-document. (for easy reference to the
bidder‟s detail list of documents is given in Section IV Compliance Sheet)
c) The bidders shall upload all documents in PDF format.
d) The bidders are required to quote strictly as per terms and conditions,
specifications, standards given in the Bid documents and not to stipulate any
deviations.
e) After submission of the tender, the bidders can re-submit revised tender any
number of times before last time and date of submission of tender as
notified.
f) If the Bidder is not found eligible after opening of tenders due to any
reason, his tender shall become invalid, and the cost of Bid-document shall
not be refunded.

12.5.
ALTERNATIVE

Only one official proposal/bid will be accepted from one organization. Alternative
Bids will not be considered.
14

<!-- page 15 -->

BIDS
12.6.
WITHDRAWAL,
SUBSTITUTION,
AND
MODIFICATION
OF BIDS
12.7.
PAYMENT OF BID
PRICE AND BID
SECURITY

Bidders may withdraw, substitute, or modify its bid only before final submission.
Once it has been submitted online and offline, no modifications are allowed
whatsoever. In case of withdrawal, the Tender Fee and EMD as bid security will
be forfeited.
As described in clause 2 of this section.

Bid Offers received after the due date and the specified time (including the
extended period if any) for any reason whatsoever, shall not beentertained.
13. BID OPENING BSHB will constitute a Tender Evaluation Committee to evaluate the responses of
the bidders.
AND
EVALUATION
The preliminary scrutiny of the bid documents will be made by the Selection
13.1. PRIMARY
EVALUATION committee on the basis of the parameters mentioned in the ITB Clause 8 above.
Incomplete details as given below will be treated as non-responsive. If Proposals:
i)
Are not submitted in as specified in the Tender document.
ii) Received without the Letter of Authorization (Power of Attorney).
iii) Are found with suppression of details
iv) With incomplete information, subjective, conditional offers and partial
offers submitted
v) Submitted without the documents requested in the compliance sheet
vi) Have non-compliance of any of the clauses stipulated in the Tender
vii) If the required documents are incomplete, not signed properly and
numbered
viii) If the required bid document Fee and EMD has not been furnished.
ix) Any entity which has been barred by the Central Government, any State
Government, a statutory authority or a public sector undertaking, as the case
may be, from participating in any project and the bar subsists as on the date
of the Proposal Due Date, would not be eligible to submit a Proposal.
x) Bidder is required to qualify in all parameters mentioned in the bid
document.Bids not conforming to such preliminary requirements will be
prima facie rejected and termed as“NotEligible”
xi) The shortlisted qualified bidder at this stage shall be termed as “Eligible
bidder”.
13.2. TECHNOA detailed evaluation of the bids shall be carried out in order to determine
COMMERCIAL
whether the bidders are competent enough and whether the technical aspects are
EVALUATION
substantially responsive to the requirements set forth in the Tender Document.
CRITERIA
Bids received would be evaluated based on the parameters defined in the table
below.
12.8.
LATE BIDS

All supporting document submitted in support of Eligibility and Technical
Evaluation matrix should comply the following: a) Soft copies of supporting documents to be submitted on online portal
however BSHB may request for hard copies in quality print as and when
required.
b) Supporting document should clearly indicate value of the completed
15

<!-- page 16 -->

project and scope of work/ services should be clearly highlighted.
c) Completion certificate should clearly indicate the value and duration of
the project.
d) In case of Bidder is having Non-Disclosure Agreement (NDA) with their
client no such experience will be counted (if agreement copy not
submitted).
e) Incomplete order copy submitted by the bidder will not be considered for
evaluation.
f) In case of projects where order for recurring /Extension and subsequent
order has been placed on the Bidder only the mentioned order value will
be considered for evaluation.
g) Proposal Presentations: Each bidder will make a presentation before
Selection committee at a date, time and venue decided by the Selection
committee. The bidders shall present their proposed solutions to the
Selection committee on parameters as prescribed in this document.
h) The bidders are required to present the proposed approach &
methodology along with the Project information submitted under
qualification and experience, the key experts details etc. as specified in
the “Criteria for Technical Evaluation” of this document.
i) Methodology of technical bid evaluation:
- Each Technical Bid will be assigned a technical score out of a
maximum of 100 points.
- Only the bidders, who score a total Technical score of 70 (Seventy)
or more, will qualify for the evaluation of their financial bid. Such
bidders shall be termed as “Technically Qualified bidder”.
- The technical scores of the bidders will be announced prior to the
opening of the financial bids.
- Bidders failing to comply any of the above the Bid will be summarily
rejected.
The Bidders are required to submit all documents in support of the evaluation
criteria in the table 2 below.
The weightage for Financial Proposal and Technical Proposal has been given
20% and 80% respectively.
The Financial Proposals shall be given scores as follows:
Pf = 100 X Fm/F
Where:
Pf is Financial Score, Fm is the Lowest Bid Price, F is the price of the proposal
under consideration
The Composite Score from Technical Proposal and Financial Proposal shall be
computed as follows:
Composite Score = (Pf X 0.2) + (Pt X 0.8),
Where:
Pt is the Technical Score of the proposal under consideration
The agency getting highest composite marks would be declared Successful.
13.3. EVALUATION

table # 2
16

<!-- page 17 -->

CRITERIA

SN Evaluationcriteria– Firm Credential- 45 Marks
1. Should have completed a PMU / PMC / Nodal Consultant assignment,
for Government client in India, involving review/ preparation of DPR/
feasibility report/ preliminary project report/ transaction advisory for
Infrastructure project combined project value of at least INR 6000
Crore in last 7 years as per the following:
Minimum 1 Projects – 5 Marks
2.

3.

More than 1 Projects – 10 Marks
Should have completed programme/ project management assignment,
for Government client in India, for overall coordination and consulting
from clients‟ office and involving activities such as review/ preparation
of detailed project reports, preparation of project revenue models,
transaction advisory and/or overall monitoring and evaluation of project
implementation, contract management in infrastructure sector (roads,
commercial, mass urban transport projects) in last 7 years, with
assignment fee value of at least INR 10 Crore and assignment duration
of more than 3 years.
Minimum Fee of 10 Cr – 10 Marks
1 Mark for additional one crore of Fee maximum 5 marks.
Should have Experience as a Transaction advisor/Asset Monetization in
Infrastructure projects in last 7 years for any govt client.

Minimum 5 Projects – 5 Marks
1 mark for each additional project maximum up to 5 marks
4. Should have Experience as consultant (completed/ongoing for atleast
one year) for providing consultancy services for Market assessment,
Financial analysis, Advertisement, marketing and sales services of
minimum built up area 25 lakh sq.ft. for township project
(Commercial/Residential).5 Marks
5. Should have Experience as a consultant for raising funds for any govt
department at least INR 2000 Crore in last 7 years. - 5 Marks
6. Technical Presentation (To be submitted at the time of presentation) –
25 Marks
 Case Study on successfully completed PMU / PMC Nodal
Consultant assignment – 10 Marks
 Understanding of Business & Scope of work – 5 Marks
 Approach and Methodology – 5 Marks
 Work Plan – 5 Marks
Key Personnel - Proposed Team for carrying out the assignment – 30 Marks

Key Personnel
There should be a minimum team committed to help on the project

17

<!-- page 18 -->

SL
.
No
.
1

Role

Educational
Requirement

Nos
.

Experience

Team
Leader cum
PPP
Expert(Maxi
mum
10
Marks)

MBA
Finance/PGDB
M in finance or
equivalent
degree

1










2.

Finance
Expert(Maxi
mum
5
Marks)

MBA/PGDM
(Finance)
or
Project
Management
from
reputed
institute

1








3.

Legal
LL.B./LLM
Expert(Maxi
mum
4

1




MBA in Finance/PGDBM
in Finance or Equivalent
degree recognized by
AICTE/UGC
Minimum 15 years of
professional experience in
Infrastructure development
Experience in Minimum 2
Projects
of
Urban
Infrastructure or Similar
Project in India. One mark
for each additional project
maximum 4 marks.
Experience as a Team
leader in any Govt
PMU/PSO/NODAL
Consultant projects have
similar scope for review of
DPR, Transaction advisory
etc.- 3 mark
Experience
as
Team
Leader in drafting Model
contract/concession
agreements/Policy
for
Infrastructure sector for
any Govt. department. - 3
mark
Post-Graduation
in
Finance or equivalent /
MBA /PGDM Finance
Minimum 10 years of
professional experience in
Infrastructure
development
Experience in Preparation
of financial model, tender
documents for Minimum
2
Projects
of
Infrastructure or Similar
Project in India. One
mark for each additional
project
maximum
3
marks.
Experience in Projects
related
to
land
development min 2
projects.- 2 Marks.
Bachelor in Law
Minimum 10 years of
professional experience in
18

<!-- page 19 -->

Marks)




4.

Urban
Planner(Ma
ximum
3
Marks)

Bachelors in
B.Arch/B.Tech
(Civil)
or
similar

1






5

6

Architect(M
B. Arch & 1
aximum 3 Registered
Architects with
Marks)
Council
of
Architecture
(COA)



MBA Finance/ 1
PGDBM
in
finance /M.Tech
/ M.Plan in
Infrastructure
from
Recognized
University.



Infrastructur
e
Planner
(Maximum
5 Marks)











Infrastructure
development
Experience as a Legal
expert in Minimum 2
Projects
of
Urban
Infrastructure or Similar
Project in India. One mark
for each additional project
maximum 2 marks.
Experience vetting of
tender
documents for
different sectors as a Legal
expert -2 Marks (Min-2
sector).
Bachelors in B.Arch/
B.Tech (Civil) or similar
Minimum 10 years of
professional experience in
Infrastructure
development
Experience in Minimum 2
Projects of Infrastructure
or Similar Project in
India. One mark for each
additional
project
maximum 3 marks.
Bachelors in B.Arch/
B.Tech (Civil) or similar
Minimum 7 years of
professional experience in
Infrastructure
development
Experience in Minimum 2
Projects of Infrastructure
or Similar Project in
India. 3 marks.
Post-Graduation
in
Finance or equivalent /
MBA / M. Tech (Civil)
Minimum 10 years of
professional experience in
Infrastructure
development
Experience in Minimum 2
Projects
of
Urban
Infrastructure or Similar
Project in India. One
mark for each additional
project
maximum
3
marks.
Experience as a sector
expert
in
urban
Infrastructure/transportati
19

<!-- page 20 -->

on project having the
project value more than
Rs 5000 Cr.- 2 Marks.
Technical team/Support Team
1
2

At least 5 Years

1

At least 5 Years

1

Post-Graduation in Finance or
equivalent / MBA / CA/ CFA
Post-Graduation in Finance or
equivalent / MBA / CA/ CFA

Bachelor‟s in engineering
(Civil) or equivalent / MBA /
CA/ CFA
A deviation/ reservation/ omission from the requirements of the Tender document
shall be considered as a substantive deviation as per the following norms,
a) which affects in any substantive way the scope, quality, or performance
standards of the Services;
b) which limits in any substantive way, inconsistent with the Tender Document,
the Procuring Authority's rights or the Bidder's obligations under the contract;
or
c) Whose rectification would unfairly affect the competitive position of other
Bidders presenting substantively responsive Bids.
3

13.4. DEVIATIONS
INFIRMITY/
IRREGULARITY/
NONCONFORMITY/
DEVIATIONS SUBSTANTIVE
OR MINOR

Financial
Analyst
Procureme
nt
Expert
Project
Monitoring

At least 5 Years

1

The rest shall be considered as Minor deviation (if any). The decision of the
Procuring Authority shall be final in this regard. Bids with substantive deviations
shall be rejected as nonresponsive. Variations and deviations and other offered
benefits (Techno-commercial or Financial) above the scope/ quantum of Services
stipulated in the Tender Document shall not influence evaluation Bids. If the bid
is otherwise successful, such benefits shall be availed by the Procuring Authority,
and these would become part of the contract.
The Procuring Authority reserves the right to accept or reject bids with any minor
deviations. Wherever necessary; the Procuring Authority shall convey its
observation, on such „minor‟ issues to Bidder by registered/ speed post/
electronically etc. asking Bidder to respond by a specified date. If Bidder does not
reply by the specified date or gives an evasive reply without clarifying the point at
issue in clear terms, that bid shall be liable to be rejected as nonresponsive.
During the evaluation of Techno commercial or Financial Bids, the Procuring
13.5.
CLARIFICATIONS Authority may, at its discretion, but without any obligation to do so, ask Bidder to
clarify its bid by a specified date. Bidder should answer the clarification within
that specified date (or, if not specified, 7 days from the date of receipt of such
request). The request for clarification shall be submitted as requested by the
Procuring Authority. No change in prices or substance of the bid shall be sought,
offered, or permitted that may grant any undue advantage to such bidder. Any
clarification submitted by a Bidder regarding its Bid that is not in response to a
request by the Purchasing Authority shall not be considered.
2) If discrepancies exist between the uploaded scanned copies and the Originals
submitted by the bidder in physical form, the original copy's text, etc., shall
prevail. Any substantive discrepancy shall be construed as a violation of the Code
of Integrity, and the bid shall be liable to be rejected as nonresponsive in addition
20

<!-- page 21 -->

to other punitive actions under the Tender Document for violation of the Code of
Conduct.
3) The Procuring Authority reserves its right to, but without any obligation to do
so, to seek any shortfall information/ documents only in case of historical
documents which pre-existed at the time of the Bid Opening, and which have not
undergone change since then and does not grant any undue advantage to any
bidder.

13.6.
VERIFICATION OF
DOCUMENTATION

13.7.
RESPONSIVENESS
OF THE
PROPOSALS
13.8. OPENING OF
FINANCIAL
BIDS

The Tender Evaluation Committee may seek clarifications from the bidders on
their proposals. Such communication will be sent to the email provided by the
bidder in the bidder information table only. Information provided through any
other email, which is not mentioned in the Bidders information table, and/or any
other information voluntarily provided by the bidder without tender evaluation
committee asking for it will not be considered for evaluation
The Procuring entity/authority may verify the documents submitted by the bidder
under eligibility and technical qualification criteria including any certification,
project experience etc.
Proposals achieved 70 technical scores out of maximum possible 100 will be
declared as responsive proposals and will be considered for the Financial Bid
opening.
Proposals achieved technical scores below 70 will be declared non-responsive and
will be rejected for further consideration.
The Financial bids of only technically successful Bidder(s) whose bids have been
awarded 70 or more marks in aggregate by the Committee will be opened.

The evaluation will be carried out whether financial bids are complete and
13.9.
CORRECTION OF computationally correct.
ERRORS
Activities and items described in the Proposal but not priced in the Financial
Proposal, shall be assumed to be included in the prices of other activities or items,
and no correction/s will be allowed in the Financial Proposal.
The Procuring authority‟s evaluation committee will correct computational or
arithmetical errors only. In case of discrepancy between
(i) a partial amount (sub-total) and the total amount, or
(ii) between the amount derived by multiplication of unit price with quantity and
the total price, or
(iii) between words and figures, the former will prevail.
13.10. PRICE
The Bidder shall ensure that the prices quoted are reasonable and competitive.
REASONABILITY The prices shall be determined based on the costs of materials, labour, services,
and other relevant factors.
The Bid Evaluation Committee will evaluate the price reasonability based on the
various parameters, such as:
- Comparison with market rates and industry benchmarks
- Comparison with recent historical prices for similar services
- Overall competitiveness of the bid
The Bid evaluation committee may request the Bidder to provide additional
information or justification for the prices quoted.
A bid may be considered abnormally low or high if:
13.11.
ABNORMALLY
- The bid price is significantly lower or higher than the estimated price or the
21

<!-- page 22 -->

market rates.
- The bid price is not supported by a detailed breakdown of costs or other relevant
information
- The Bid Evaluation Committee in detail shall determine whether the price is
reasonable and sustainable.
The bidder with the highest Final score (FS) after applying the scoring formula as
13.12. AWARD
CRITERIA
stated under ITB Clause 13.2 will be selected as the successful bidder and will be
called for agreement. In case of tie, the firm with superior technical score (TS)
would be called for agreement.
The Selection committee reserves the right to negotiate.
The Consultant who is invited for contract negotiations will, as a pre-requisite for
13.13.
NEGOTIATIONS attendance at the negotiations, confirm availability of all experts named in its
proposal except in the cases of absence on account of death or medical incapacity.
Failure in satisfying such requirements may result in the Client proceeding to
initiate the negotiation process with the next-ranked Consultant. Representatives
conducting negotiations on behalf of the Consultant must have written authority
to negotiate and conclude the Contract.
Upon closure of the negotiation procedure and mutual agreement on all technical
13.14.
NOTIFICATION
and financial aspects of the assignment, a notification of award will be issued to
OF AWARD
the successful bidder in form of an LoA by the Procuring Authority.
On award of the consultancy, the Consultant should be required to enter into an
13.15. SIGNING
OF AGREEMENT agreement with Client as per the Terms and Reference.
Upon submission of the Performance Security Bank Guarantee by the successful
bidder within stipulated time period as notified in the LoA, and after verifying of
the PSBG by the client the Agreement will be signed by the official signing
authorities of both the parties.
14. PROCURING The issue of the RFP Document does not imply that the Procuring Authority is
AUTHORITY’S bound to select bid(s), and it reserves the right without assigning any reason to
reject any or all of the Bids, or cancel the RFP process; or retender the RFP
RIGHTS
process
The procurement Authority/Entity reserves the right to conduct due diligence and
14.1. DUE
DILIGENCE/
verify the authenticity and accuracy of the documents submitted by the Bidder,
VERIFICATION including but not limited to:
OF ORIGINAL
- Certificates and diplomas
DOCUMENT
- Experience certificates and references
(IF APPLICABLE)
- Financial statements and tax returns
- Any other documents relevant to the bid
5% of the Contract value within 7 days from the issuance of LoA the successful
14.2. PSBG
PERFORMANCE bidder will submit the Performance Security Bank Guarantee (PSBG) in the
SECURITY
format given in FINANCIAL FORM - 6, to the procurement authority. The
BANK
Procurement authority shall verify the document before signing of the contract.
GUARANTEE
14.3. RETURN OF After signing of the contract, the bid securities/EMDs will be returned to all
BID SECURITY bidders.
LOW OR HIGH
BID PRICE

22

<!-- page 23 -->

Section II (Part B): Bid Data Sheet
Sl.
No.

Particulars

Details

1

Name of the Authority

Bihar State Housing Board, Patna, Bihar

2

Method of Selection

QCBS method of evaluation (80:20)

3

Proposal Validity

90 Days from the last date of bid submission

4

Date of Issue of RFP

28/03/2026

5

Bid Price

Rs 10,000/- (Rs. Ten Thousand only) + applicable GST through
RTGS

6

Deadline for Submission of
Pre-Proposal Queries

7

8

9

Pre-proposal meeting

24/04/2026 by 17:00 Hrs. by email at
Secretary.bshb-bih@gov.in
20/04/2026 at 11:00 Hrs. at
Bihar State Housing Board, Patna, Bihar,
6, Sardar Patel Marg, Patna-800015, Bihar

Last date and time for
Submission of proposal
22/04/2026 up to 05:00 PM
(online)
on
www.eproc2.bihar.gov.in
Date, time and place for
submission of physical 24/04/2026 up to 04:00 PM
copy of the proposal
Bid Security of INR 10 (Ten) Lakhs submit in form of internet
payment gateway (IPG) or BG in favour of „Bihar State

10

Earnest
(EMD)

Money

Deposit

Housing Board, Patna‟ payable at Patna,
Bank Details for BG: Bihar State Housing Board, Patna, Bank
A/c No. 442920110000182, IFSC: BKID0004429

11

12

13
14
15

16

Opening of Proposal:

Online opening at e-portal by bid opening committee
constituted by Bihar State Housing Board, Patna, Bihar

Site Visit

Bidders are advised to submit their respective Proposals only
after considering the terms and scope of work mentioned in the
ToR and validating project information.

Date
of opening of
04/05/2026 at 03:30 PM
Technical Proposal
Date
of opening of
To be informed to technical qualified bidders
Financial Proposal
Performance security Bank
5% of the Contract value
Guarantee (PSBG)
Chief Engineer,
Bihar State Housing Board, Patna, Bihar,
Contact Person
6, Sardar Patel Marg, Patna-800015, Bihar
Email:Secretary.bshb-bih@gov.in
23

<!-- page 24 -->

24

<!-- page 25 -->

SECTION – III CONDITIONS OF CONTRACT
1.
1.1.

GENERAL PROVISIONS
Unless the context otherwise requires, the following terms whenever used in
Definitions
this Contract have the following meanings:
(a) "Applicable Law" means the laws and any other instruments having the
force of law in India.
(b) “Client” / “Employer” means Bihar State Housing Board, Patna, Bihar
(c) "Contract" means the Contract signed by the Parties, to which these
Conditions of Contract are attached, together with all the documents listed
in Clause 1 of such signed Contract;
(d) “Contract Price” means the price to be paid for the performance of the
Services, in accordance with Clause 6;
(f) "Party" means the Client or the Consultants, as the case may be, and
Parties means both of them;
(g) "Personnel" means persons hired by the Consultants or by any Subconsultant as employees and assigned to the performance of the Services
or any part thereof;
(i) "Services" means the work to be performed by the Consultants pursuant to
this Contract as described; and
(j) "Sub-consultant" means any entity to which the Consultants subcontract
any part of the Services in accordance with the provisions of Clauses 3.5
and 4.

1.2

Law
Governing
the Contract

This Contract, its meaning and interpretation, and the relation between the
Parties shall be governed by the Law of contract, supplemented by the
conditions states under this section to this contract.

1.3

Language

This Contract has been executed in English, which shall be the binding and
controlling language for all matters relating to the meaning or interpretation of
this Contract.

1.4

Notices

Any notice, request or consent made pursuant to this Contract shall be in
writing and shall be deemed to have been made when delivered in person to an
authorized representative of the Party to whom the communication is
addressed, or when sent by registered mail or facsimile to such Party at the
address specified in the Contract.

1.5

Location

1.6

The Services shall be performed at such locations as are specified in RFP and,
where the location of a particular task is not so specified, at such locations,
whether in the state of Bihar or elsewhere, as the Procuring Authority may
approve.
Any action required or permitted to be taken, and any document required or
Authorized
permitted to be executed, under this Contract by the Client or the Consultants
Representatives
may be taken or executed by the officials specified in this RFP.
Authorized Representative of:
On Behalf of the
Bihar State Housing Board, Patna, Bihar
Name:
Designation
25

<!-- page 26 -->

Address:Bihar State Housing Board, Patna, Bihar,
6, Sardar Patel Marg, Patna-800015, Bihar INDIA
Phone No
Email ID
On Behalf of the Consultant:
Name
Designation
Address
Phone No
Email ID
and

The Consultants, Sub-consultants and their Personnel shall pay taxes, duties,
fees and other impositions as may be levied under the Applicable Law, the
amount of which is deemed to have been included in the Contract Price.

1.7.

Taxes
Duties

2.

COMMENCEMENT, COMPLETION, MODIFICATION AND TERMINATION OF
CONTRACT

2.1.

Effectiveness
of Contract

This Contract shall come into effect on the date the Contract is signed by both
Parties.

2.2.1 Commencement The Consultants shall begin carrying out the Services after the date the
Contract becomes effective
of Services
2.2.2 Duration
services

of

The duration of the Contract shall be 36 (thirty-six) months from the date of
signing of the Contract. The Contract may be extended for a further period of
up to 24 (twenty-four) months, subject to satisfactory performance of the
Consultant during the Contract period and at the mutually agreed terms.
An annual escalation of 5% (five percent) each year on the monthly retainer fee
shall be applicable.

2.3.

Expiration of
Contract

Unless terminated earlier pursuant to Clause 2.6, this Contract shall terminate
with completion of the consultancy in terms of conditions of this agreement to
the full satisfaction of the Client

2.4.

Modification

Modification of the terms and conditions of this Contract, including any
modification of the scope of the Services or of the Contract Price, may only be
made by written agreement between the Parties.

2.5

Force Majeure

2.5.1

Definition

For the purpose of this contract "Force Majeure" means any event or
circumstance or combination of events or circumstances beyond the reasonable
control of either Party including:
i)

Acts of God and nature including
• typhoon, flood, earthquake, fire, drought, landslide, unusually severe
weather condition or other natural disaster; and
• plague or epidemic or quarantine conditions arising there from;

ii) Air crash, shipwreck, train wrecks or failures or delays of transportation;
iii) Strikes, lock-outs, work-to-rule actions, go-slows or similar labour
difficulties other than Governmental Force Majeure that in any way have an
effect on the project;
2.5.2

No Breach of

The failure of a Party to fulfil any of its obligations under the contract shall not
26

<!-- page 27 -->

Contract

be considered to be a breach of, or default under this Contract insofar as such
inability arises from an event of Force Majeure, provided that the Party
affected by such an event (a) has taken all reasonable precautions, due care and
reasonable alternative measures in order to carry out the terms and conditions
of this Contract, and (b) has informed the other Party as soon as possible about
the occurrence of such an event.

2.5.3

Extension
Time

of

2.5.4

Payments

2.6

Termination

2.6.1

By the Client

Any period within which a Party shall, pursuant to this Contract, complete any
action or task, shall be extended for a period equal to the time during which
such Party was unable to perform such action as a result of Force Majeure.
During the period of their inability to perform the Services as a result of an
event of Force Majeure, no additional payment will be given however a time
extension in the project may be given.
The Client may terminate this Contract, by not less than thirty (30) days‟
written notice of termination to the Consultants, to be given after the
occurrence of any of the events specified in paragraphs (a) through (d) of this
Clause 2.6.1 and sixty (60) days‟ in the case of the event referred to in (e):
(a) if the Consultants do not perform their obligations under this Contract,
within thirty (30) days of receipt after being notified
(b) if the Consultants become insolvent or bankrupt;
(c) if, as the result of Force Majeure, the Consultants are unable to perform a
material portion of the Services for a period of not less than sixty (60) days;
or
(d) if the Consultant, in the judgment of the Client has engaged in corrupt or
fraudulent practices in competing for or in executing the Contract
For the purpose of this clause:
“Corrupt practice” means the offering, giving, receiving or soliciting of
anything of value to influence the action of a public official in the selection
process or in contract execution.
“Fraudulent practice” means a misrepresentation of facts in order to influence a
selection process or the execution of a contract.
(e) If the Client, in its sole discretion and for any reason whatsoever, decides to
terminate this Contract, no claim shall be entertained on this account.

2.6.2

By the
Consultants

The Consultants may terminate this Contract, by not less than thirty (30) days'
written notice to the Client, such notice to be given after the occurrence of any
of the events specified in paragraphs (a) and (b) of this Clause 2.6.2:
(a) if the Client fails to pay any money due to the Consultants pursuant to this
Contract and not subject to dispute pursuant to Clause 7 hereof within
forty-five (45) days after receiving written notice from the Consultants that
such payment is overdue; or
(b) if, as the result of Force Majeure, the Consultants are unable to perform a
material portion of the Services for a period of not less than sixty (60)
days.

2.6.3

Payment
upon
Termination

Upon termination of this Contract pursuant to Clauses 2.6.1 or 2.6.2, the Client
shall make the following payments to the Consultants:
(a) Remuneration pursuant to Services satisfactorily performed prior to the
27

<!-- page 28 -->

effective date of termination;
(b) Except in the case of termination pursuant to paragraphs (a) and (b) of
Clause 2.6.1, reimbursement of any reasonable cost incident to the prompt
and orderly termination of the Contract.
In case of delay in the conduct of Consultancy services within the time fixed or
in the event of repudiation of the contract, the Client reserves the right to
recover damage for Breach of contract.

2.6.4

Failure and
Termination

3.

OBLIGATIONS OF THE CONSULTANTS

3.1.1

General

3.1.2

Time is
Essence

3.2

Conflict of Interest

3.2.1

Consultants
Not to Benefit
from
Commissions,
Discounts,
etc.

The remuneration of the Consultants pursuant to Clause 6 shall constitute the
Consultants' sole remuneration in connection with this Contract or the Services,
and the Consultants shall not accept for their own benefit any trade
commission, discount or similar payment in connection with activities pursuant
to this Contract or to the Services or in the discharge of their obligations under
the Contract, and the Consultants shall use their best efforts to ensure that the
Personnel, any Sub-consultants, and agents of either of them, similarly shall
not receive any such additional remuneration.

3.2.2

Consultants
and Affiliates
not to be
Otherwise
Interested in
Project

The Consultants agree that, during the term of this Contract and after its
termination, the Consultants and their affiliates, as well as any Sub-consultant
and any of its affiliates, shall be disqualified from providing goods, works or
services (other than the Services and any continuation thereof) for any project
resulting from or closely related to the Services.

3.2.3

Prohibition of
Conflicting
Activities

Neither the Consultants nor their Sub-consultants nor the Personnel shall
engage, either directly or indirectly, in any of the following activities:

The Consultants shall perform the Services and carry out their obligations
hereunder with all due diligence, efficiency and economy, in accordance with
generally accepted professional techniques and practices, and shall observe
sound management practices, and employ appropriate advanced technology
and safe methods. The Consultants shall always act, in respect of any matter
relating to this Contract or to the Services, as faithful advisers to the Client, and
shall at all times support and safeguard the Client's legitimate interests in any
dealings with Sub-consultants or third parties.
of

Time shall be of the essence as regards the performance by the Agency of its
obligations under this Contract

(a) during the term of this Contract, any business or professional activities
which would conflict with the activities assigned to them under this
Contract; or
(b) after the termination of this Contract, such other activities as may be
specified in the Conditions of Contract.

3.3

Confidentiality

The Consultants, their Sub-consultants, and the Personnel of either of them
shall not, either during the term or within two (2) years after the expiration of
this Contract, disclose any proprietary or confidential information relating to
the Project, the Services, this Contract, or the Client's business or operations
without the prior written consent of the Client.

3.4

Consultants’
Actions
Requiring

The Consultants shall obtain the Client‟s prior approval in writing before
taking any action, say entering into a subcontract for the performance of any
part of the Services,
28

<!-- page 29 -->

3.5

Client’s Prior
Approval

(“Key Personnel and Sub-consultants”), and any other action that may be
specified in the Conditions of Contract.

Documents
Prepared by
the
Consultants to
be the
Property of the
Client

All plans, drawings, specifications, designs, reports, surveys and other
documents and software submitted by the Consultants shall become and remain
the property of the Client, and the Consultants shall, not later than upon
termination or expiration of this Contract, deliver all such documents and
software to the Client, together with a detailed inventory thereof.
The Consultants may retain a copy of such documents and software subject to
obtaining written approval from the client. Restrictions about the future use of
these documents, if any, shall be specified by the Client.

4.

CONSULTANTS’ PERSONNEL

4.1

Description of
Personnel

The titles, agreed job descriptions, minimum qualifications and estimated
periods of engagement in the carrying out of the Services of the Consultants‟
Key Personnel are described in RFP.

4.2

Removal
and/or
Replacement
of Personnel

a.

No changes shall be made in the Key Personnel. In case it becomes
incumbent to change any one of key personnel, the Consultants shall
forthwith provide as a replacement a person of equivalent or better
qualifications with approval of the Client.

b.

If the Client finds that any of the Personnel have

a.

i.

committed serious misconduct or has been charged with having
committed a criminal action, or

ii.

have reasonable cause to be dissatisfied with the performance of any of
the Personnel, then the Consultants shall, at the Client‟s written
request specifying the grounds thereof, forthwith provide as a
replacement a person with qualifications and experience acceptable to
the Client.
The Consultants shall have no claim for additional costs arising out of
or incidental to any removal and/or replacement of Personnel.

5.

OBLIGATIONS OF THE PROCURING AUTHORITY

5.1

Assistance
and
Exemptions

The Client shall use its best efforts to ensure that the Government shall provide
the Consultants such assistance and data as specified in the Conditions of
Contract.

5.2

Changes
in
the
Applicable
Law

If, after the date of this Contract, there is any change in the Applicable Law
with respect to taxes and duties which increases or decreases the cost of
services rendered by the Consultants, the remuneration and reimbursable
expenses otherwise payable to the Consultants under this Contract shall be
increased or decreased accordingly and corresponding adjustments shall be
made to the ceiling amounts referred to in Clause 6.2.

6.

PAYMENTS TO THE CONSULTANTS

6.1

Contract
Price

The Contract price is INR[to be entered
contract]including applicable taxes & GST

before

signing

of

the

The Contract price breakdown is provided in Clause 6.2, and the total
payments under this Contract shall not exceed this Contract price.
Any change to the Contract price specified above can be only made if the
Parties have agreed to the revised Scope of Services and/or Timeline of the
contract under clause 2.4 and have amended the Terms of Reference in
29

<!-- page 30 -->

Appendix A in writing
6.2

Payments

The Selected Agency shall submitmonthly invoices toBSHBfor processing and
payment, along with a Monthly Progress Report in the format as prescribed by
BSHB. The paymentwould be made within 15 days after invoice receipt.A
price escalation of five percent (5%) per annum shall be applicable on the
agreed rates/contract value.
Allpaymentsshallbereleasedsubjecttosatisfactoryperformanceandacceptanceoft
he Monthly Progress Report by BSHB / Competent Authority.

6.3

Additional
Manpower

If, during the Assignment, the Client requires deployment of additional
manpower, including but not limited to Structural Expert, Quantity Surveyor,
Real Estate Expert, Environmental Expert, Legal Support, Financial Analyst,
or any other professional/support staff, the same shall be provided by the
Consultant subject to prior written approval of the Client.
The remuneration for such additional manpower shall be aligned with the rates
quoted in the Financial Proposal for personnel of comparable qualification,
experience, and role. In case no comparable category exists, the rates shall be
mutually agreed, consistent with the overall rate structure of the Contract.
No additional manpower shall be deployed or paid for without prior written
approval of the Client
For the purpose of determining the remuneration due for additional services as
may be agreed under Clause 2.4.

6.4

Payment for
Additional
Services

6.5

Terms
and Payments will be made to the account of the Consultants and according to the
Conditions of payment schedule stated in the Clause 6.2 Deliverables and linked Payments
under Section III Conditions of Contract. Payments shall be made in
Payment
accordance with the conditions listed in the Payment Schedule on approval of
invoice based on the satisfactorily achieved deliverables by the Consultants.

7.

SETTLEMENT OF DISPUTES

7.1.

Amicable
Settlement

The Parties shall use their best efforts to settle amicably all disputes arising out
of or in connection with this Contract or its interpretation.

7.2.

Dispute
Settlement

In the event a dispute, differences or claim arises in connection with the
interpretation or implementation of this agreement, the aggrieved party shall
issue a written notice setting out the Dispute / differences or claim to the other
party, parties shall first attempt to resolve such dispute through mutual
consultation. If the dispute is not resolved as aforesaid within 30 days from the
date of receipt of written notice, the matter will be referred to BSHB, who will
take decision within 60 days after such reference. If the dispute is still not
resolved the matter will be referred for Arbitration.

7.3.

Arbitration

In case the dispute is not resolved, any party may issue a notice of reference,
invoking resolution of disputes through arbitration in accordance with the
provisions of The Arbitration and Conciliation (Amendment) Act, 2021.
The arbitral proceedings shall be conducted by a sole arbitrator that may be
appointed with the consent of Parties to such dispute. If there is no agreement
among the parties to the identity or appointment of such sole arbitrator within
30 days of issue of notice of reference, then the arbitral proceedings will be
conducted by a panel of three arbitrators, one arbitrator to be appointed by
BSHB and other appointed by Agency and the third arbitrator to be mutually
appointed by the other two arbitrators in accordance with provisions of The
30

<!-- page 31 -->

Arbitration and Conciliation (Amendment) Act, 2021. Arbitration proceedings
shall be conducted in and the award shall be made in English language.
Arbitration proceedings shall be conducted at Patna and following are agreed.
The arbitration award shall be final and binding on the Parties, and the Parties
agree to be bound thereby and to act accordingly.
The arbitrator may award to the Party that substantially prevails on merit, its
costs and reasonable expenses (including reasonable fees for counsel).
When any dispute is under arbitration, except for matters under dispute, the
Parties shall continue to exercise their remaining respective rights and fulfil
their remaining respective obligations under this Agreement.

31

<!-- page 32 -->

Section – IV Bid Forms
General Forms
GEN FORM - 1
GEN FORM - 2
GEN FORM - 3
GEN FORM - 4
GEN FORM - 5
GEN FORM - 6
GEN FORM - 7

Technical Forms
TECH FORM – 1 (A)
TECH FORM – 1 (B)
TECH FORM – 2
TECH FORM – 3(A)
TECH FORM – 3(B)
TECH FORM - 4
TECH FORM - 5

Format for Letter of Application (Bidder)
Format for Power of Attorney for Signing of Application
Format for Details of Applicant
General Profile
Format for Affidavit Certifying that Entity is not Blacklisted/ Debarred
Declaration regarding any Conflict of Interest and
Anti-Collusion Certificate
Pre-bid queries‟ format

TECH FORM - 6
TECH FORM - 7

Supporting format for Project Experience of the Applicant
Format for Project Experience of the Applicant
Comments And Suggestions on Terms of Reference
Format for Financial Capability of the Applicant
Positive Net worth of the Applicant
Understanding of Scope with Approach and Methodology (A & M)
Format for HR Certification of the Technical Manpower Organisational
Strength (staff strength in numbers)
Format for sharing details of the Resources/Personnel to be deployed
Format of Curriculum Vitae (CV) for Manpower (Key Personnel only)

Financial Forms
FIN FORM - 1
FIN FORM - 2
FIN FORM – 3 (A)
FIN FORM – 3 (B)
FIN FORM – 3 (C)
FIN FORM - 4
FIN FORM - 5

Letter of Financial Bid
Financial Bid FINANCIAL BID COVER
Financial Bid Format (Component 1)–Establishment of ABC Centre)
Financial Bid Format – Cost of Construction of ABC Centre
Financial Bid Format (Component 2) - Breakdown of the rates (per Dog)
Performance Security Bank Guarantee
Bid Security Form (Bank Guarantee)

32

<!-- page 33 -->

The Technical proposal should comprise of the following basic requirements. The documents mentioned in this
Compliance Sheet along with this form, needs to be a part of the Technical proposal.

Compliance Sheet
#

Specific Requirements

Documents Required

Compliance

1.
2.

Proposal Covering Letter
Bid Document Fee

Yes/No
Yes/No

3.

Power of Attorney

4.
5.

General Profile
Earnest Money Deposit

6.

Legal Entity

7.

8
9

Blacklisting declaration
Anti-Collusion Certificate
Financial Capability

10

Positive net worth

11

Project Experience

12

Approach
and
Methodology to perform
the work in this assignment

13

GEN: FORM - 1
Submitted online. The proof of
paymentsubmitted in hard copy
GEN: FORM – 2
Copy of Power of Attorney in the
name of the Authorized signatory
GEN: FORM - 4
FINANCIAL FORM 7
Original copies to be submitted
physically
GEN: FORM - 3
(including supporting documents
indicated)
GEN FORM - 5
GEN: FORM - 6
FINANCIAL FORM - 2 + Extracts
from the audited Balance sheet and
Profit & Loss; OR Certificate from
the statutory auditor
FINANCIAL FORM – 3 and
Certificate
from the statutory
auditor/Company Secretary
TECH: FORM - 1 & 2 and
Completion Certificates from the
Client/ Work Order + Self Certificate
of Completion (Certified by the
Statutory
Auditor/Company
Secretary)
TECH: FORM – 3, should highlight
the Approach and Methodology for
the proposed assignment. A copy of
the technical presentation to be
attached
TECH FORM - 4

HR Certification of the
Technical Manpower
Organisational Strength
(staff strength in numbers)
Resume of all key technical TECH FORM – 6 &
resources proposed for the TECH FORM - 7
assignment
(Project
Management
Team
Resumes)

14

Ref. & Page
No. in the
submitted bid

Yes/No

Yes/No
Yes/No

Yes/No

Yes/No
Yes/No

Yes/No

Yes/No

Yes/No

Yes/No

Yes/No

33

<!-- page 34 -->

GEN: FORM - 1: Format for Letter of Application (Bidder)
[On the Letter head of the Applicant]
Date:
To,
Secretary
Bihar State Housing Board, Patna, Bihar,
6, Sardar Patel Marg
Patna-800015, Bihar
Ref: Selection of a Consultant for Project Management Unit (PMU) for Bihar State Housing
Board
Dear Sir,
Being duly authorised to represent and act on behalf of....................................................... (Hereinafter
referred to as “the Applicant”)and having gone through and fully understood all of the eligibility and
qualification requirements and information provided, the undersigned hereby apply for Shortlisting
for the captioned assignment.
We, the undersigned, having examined the RFP (including any Corrigendum, Addendum issued), the
receipt of which is hereby duly acknowledged, offer to comply with the requirements as stated in the
RFP and abide by its Terms and Conditions.
Further, we confirm that the information contained in this response/ proposal or any part thereof,
including its exhibits, and other documents and instruments delivered or to be delivered to BSHB, is
true, accurate, verifiable and complete.
We are enclosing our Application for Qualification in one (1) original, with the details as per the
requirements of the RFP Document, for your evaluation. We fully understand and agree to comply
that on verification, if any of the information provided here is found to be misleading the selection
process, we are liable to be disqualified from the selection process or termination of the contract
during the project, if selected.

We confirm that our application is valid for a period of 90 (ninety) days from(last day of bid
submission)It is submitted:
1. We have examined and have no reservations to the Bidding Documents, including
Corrigendum/Addenda (if applicable) issued in accordance with Instructions to Bidders (ITB
Clause 5);
34

<!-- page 35 -->

2. We meet the eligibility requirements and have no conflict of interest in accordance with ITB
Clause 8;
3. We have not been suspended nor declared ineligible by the <Employer> based on execution
of a Bid Securing Declaration in the <Employer>‟s country in accordance with ITB
4. We offer to execute in conformity with the Bidding Documents the following services as per
Section VI (term of reference);
5. Our bid shall be valid for a period of 90 (ninety) calendar days from the date fixed for the bid
submission deadline in accordance with the Bidding Documents, and it shall remain binding
upon us and may be accepted at any time before the expiration of that period.
6. If our bid is accepted, we commit to obtain a performance security in accordance with the
Bidding Documents.
7. We are not participating, as a Bidder or as a sub-Agency, in more than one bid in this bidding
process in accordance with ITB clause 10.5
8. We understand that this bid, together with your written acceptance thereof included in your
notification of award, shall constitute a binding contract between us, until a formal contract is
prepared and executed; and
9. We hereby certify that we have taken steps to ensure that no person acting for us or on our
behalf will engage in any type of fraud and corruption.
Yours sincerely,
Name of the Agency:
Name and Signature of the Agency Representative:
Address:

35

<!-- page 36 -->

GEN: FORM- 2: Format for Power of Attorney for Signing of Application
(On Non – judicial stamp paper of Rs 100/- or such equivalent document duly attested bynotary public)
Power of Attorney

Know all men by these presents, we(name and addressof the registered office) do hereby constitute,
appoint and authorise Mr. / Ms .................................................. (name and residential address) who is
presently employed with us and holding the position of ............................................................... as our
attorney, to do in our name and on our behalf, all such acts, deeds and things necessary in connection
with or incidental to our application for “Selection of a Consultant for Project Management Unit
(PMU) for Bihar State Housing Board” including signing and submission of all documents and
providing information / responses to Bihar State Housing Board, Patna, Bihar, representing us in all
matters before BSHB, and generally dealing with BSHB in all matters in connection with our bid for
the said Assignment.

We hereby agree to ratify all acts, deeds and things lawfully done by our said attorney pursuant to this
Power of Attorney and that all acts, deeds and things done by our aforesaid attorney shall and shall
always be deemed to have been done by us.

For

(Signature)
(Name, Title and Address)

Accepted…

(Signature)

(Name, Title and Address of the Attorney)

Note:
▪ To be executed by the Applicant.
▪ The mode of execution of the Power of Attorney should be in accordance with the procedure, if any,

laid down by the applicable law and the charter documents of the executant(s) and when it is so
required the same should be under common seal affixed in accordance with the required procedure.
▪ In case the Application is signed by an authorised Director of the Applicant, a certified copy of the
appropriate resolution/ document conveying such authority may be enclosed in lieu of the Power of
Attorney.
governments
in
India.

36

<!-- page 37 -->

GEN FORM 3: Format for Details of Applicant
The details of Applicant: every Applicant will submit individual details) are as follows:

Sl.
No.

Parameters

Details

a.

Name of applicant with full address

b.

Tel. No.

c.

Fax No.

d.

Email

e.

Year of Incorporation.

f.

Name and address of the person
holding the Power of Attorney.

g.

Place of Business. Date of Registration.

h.

Name of Bankers with full address

i.

Regional presence (Direct office)

:

j.

GST Registration Number (copy).

:

k.

Are you presently debarred /
Blacklisted by any Government
Department /Public Sector Undertaking
/Any Employer? (If Yes, please
furnished details)

:

l.

Name and details (Tel / Mobile / Email)
of contact persons

:

37

<!-- page 38 -->

GEN: FORM - 4: General Profile
Provide here a brief description of the background and organisation of your company (include
Organisational Chart). The applicant registered under Companies Act can be a Public Ltd./Pvt
Ltd. and must be an Indian Resident/Indian Firm/Indian Company

Firm

/Agency

Profile

Proposed

Team

Profile

38

<!-- page 39 -->

GEN FORM- 5: Format for Affidavit Certifying that Entity is not Blacklisted/ Debarred
(On a Stamp-paper of relevant value)- by the Bidder Affidavit

I/We M/s. ……………… (Applicant), [the name and address of the registered office] hereby
certify and confirm that we or any of our promoter/s / director/s are not blacklisted by any State
Government or Central Government / State Government/PSU in India from participating in
Consultancy Project/s, either individually entity on

.

We further confirm that we are aware that as per the RFP No.

, our Application

for the captioned Assignment would be liable for rejection in case any material misrepresentation
is made or discovered with regard to the requirements of the RFP, any stage of the Shortlisting
Process or thereafter during the shortlisting period.

Dated this ……………………. Day of ........................... , 2026

Name of the Applicant:

… ................................................................. Signature of the Authorised Person

…………………………………………….

Name

of

the

Authorised

Person

39

<!-- page 40 -->

GEN FORM- 6: Declaration regarding any Conflict of Interest and Anti-Collusion
Certificate

[Certificate should be provided by bidder on its letterhead]

We hereby certify and confirm that in the preparation and submission of our Bid for Request for
Proposal (RFP) “Selection of a Consultant for Project Management Unit (PMU) for Bihar State
Housing Board”. against the RFPNo:<No>Dated <DD/MM/YYYY> is issued by Authority, we
have not acted in concert or in collusion with any other Bidder or other person(s) and also not done
any act, deed or thing, which is or could be regarded as anti- competitive. We further confirm that
we have not offered nor will offer any illegal gratification in cash or kind to any person or
organisation in connection with the bid.

(Signature of the Lead Member)

Printed Name and Designation

Seal
Date:
Place:
Business Address:

40

<!-- page 41 -->

TECH FORM- 1 (A): Supporting format for Project Experience of the Applicant

Sl.
No.

Name of
firm

Name
& Name
location of of
project
Client

Start
Date
–
End
Date

Project Fees Details of
(INR
the project
(Completed/
Lakh)
Ongoing)

Details
ofDocumentar
yProofattache
d

1.

2.
3.
4.
5.

41

<!-- page 42 -->

TECH FORM -1 (B): Format for Project Experience of the Applicant

Assignment name:

Value of the contract (in INR):

Country:

Duration of assignment (months):

Name of Client:

Total No of staff-months of the assignment:

Address:
Start date (month/year):

Completion date (month/year):
Narrative description of Project:
Description of actual services provided by your staff within the assignment:

Note: use separate sheet for each eligible project
Certified that the above information is correct to the best of our knowledge and no relevant
information is concealed. If at any time during or after the Selection, it is proved that the information
furnished by us is wrong, BSHB reserves the right to take necessary action against our firm as per
applicable Laws/Rules of the land.
Signature of Authorized Representative of the Firm Date
Place

Name
Designation Tel No.
Mobile No. E Mail ID
Seal/Stamp

of

the

Firm

42

<!-- page 43 -->

TECH FORM - 2: COMMENTS AND SUGGESTIONS ON TERMS OF REFERENCE

A - On the Terms of Reference

[Suggest and justify here any modifications or improvement to the Terms of Reference you
are proposing to improve performance in carrying out the Assignment/job (such as deleting
some activity you consider unnecessary, or adding another, or proposing a different phasing
of the activities). Such suggestions should be concise and to the point, and incorporated in
your Bid.]

B - On Inputs and Facilities to be provided by the employer

[Comment here on Inputs and facilities to be provided by the Client according to Paragraph
6 of the Part II Special information to Contractor/Service Providers including:
administrative support, office space, Domestic transportation, equipment, data, etc.]

43

<!-- page 44 -->

TECH FORM 3A: Format for Financial Capability of the Applicant

(Equivalent in Rs. crores)
Applicant*

Average Annual Turnover from similar services
FY

FY

FY

2022-23

2023-24

2024-25

Average

Applicant

Certificate from the Statutory Auditor/ Chartered Accountant

This is to certify that ....................(name of the Applicant) has received the payments shown above
against the respective years.

Name of the Audit firm:

Seal of the Audit firm
UDIN:Date:
(Signature, name and designation of the authorised signatory)

#

*

The Applicant should provide the Financial Capability based on its own financial statements.
Financial Capability of the Applicant's parent company or its subsidiary or any associate
company will not be considered for computation of the Financial Capability of the Applicant.
Any Applicant should fill in details as per the row titled Applicant and ignore the row below.

** The certificate must have UDIN issued by The Institute of Chartered Accountants of India (ICAI).

44

<!-- page 45 -->

TECH FORM 3B: Net worth of the Applicant

(Equivalent in Rs. crores)
Net worth of the Applicant
Applicant*
FY
2022-23

FY
2023-24

FY
2024-25

Total

Average

Certificate from the Statutory Auditor/ Chartered Accountant

This is to certify that

(name of the Applicant) has a net worth shown above against the

respective years on account of the firm. Name of the audit firm:
Seal of the audit firm
UDIN:Date:
(Signature, name and designation of the authorised signatory)

** The certificate must have UDIN issued by The Institute of Chartered Accountants of India (ICAI).

45

<!-- page 46 -->

TECH FORM- 4: Understanding of Scope with Approach and Methodology (A & M)

[Maximum of 15 pages including charts and diagrams]

a.

Agency‟s understanding of the ToR

A description of the approach, methodology and work plan for performing the assignment, including a
detailed description of the proposed methodology and staffing for training, if the Terms of Reference of
the assignment.

{Suggested structure of your Technical Bid:
a)

Technical Approach and Methodology

b)

Work Plan

c)

Organization and Staffing}

a)
Technical Approach and Methodology.{Please explain your understanding of the objectives of
the assignment as outlined in the Terms of Reference (TORs), the technical approach, and the
methodology you would adopt for implementing the tasks to deliver the expected output(s), and the
degree of detail of such output. Please do not repeat/copy the TORs in here.}

b)
Work Plan.{Please outline the plan for the implementation of the main activities/tasks of the
assignment, their content and duration, phasing and interrelations, milestones (including interim
approvals by the Client), and tentative delivery dates of the reports. The proposed work plan should be
consistent with the technical approach and methodology, showing your understanding of the TOR and
ability to translate them into a feasible working plan. A list of the final documents (including reports) to
be delivered as final output(s) should be included here. The work plan should be consistent with the
Work Schedule Form.}

c)

Organization and Staffing.{Please describe the structure and composition of your team}

46

<!-- page 47 -->

TECH FORM- 5 Format for HR Certification of the Technical Manpower Organisational Strength
Criteria

(staff strength in numbers)
Staff Strength
numbers

in

Certification

Total Staff Strength of Organisation

Certified by HR head of the
Applicant

Total Technical Staff related to
Assignment working in the organization as
on bid submission date in the organisation
(…
)

Certified by HR head of the
Applicant

Certified that the above information is correct to the best of our knowledge and no relevant
information is concealed. If at any time during or after the Selection, it is proved that the information
furnished by us is wrong, PROCURING AUTHORITY, Bihar reserves the right to take necessary
action against our firm as per applicable Laws/Rules of the land.

Signature of HR Head of the Firm
Date
Place
Name

Designation:

Tel No.
Mobile No.
E Mail ID.

Counter Signature of Authorised Representative of the Firm

47

<!-- page 48 -->

TECH FORM- 6: Format for sharing details of the Key Experts

Sl.
No

1.

Name of Proposed Role
the
resource

2.

Team
Leader
cum PPP Expert
Urban Planner

3.

Architect

4.
5.

Infrastructure
Planner
Finance Expert

6.

Legal Expert

Highest
Degree

Assignment
Related
Certifications

Relevant
Experience
related to
Project (In
Yrs)

Please
mention
[nos.]
relevant
projects
handled

Total
Experience
(In Years)

48

<!-- page 49 -->

TECH FORM- 7: Format of Curriculum Vitae (CV) for Manpower (Key Personnel)
Sl.
No.
1.

Name

2.

Current Designation in the organization

3.

Proposed Role in the Project

4.

Proposed Responsibilities in the Project

5.

Date of Birth

6.

Education

7.

Summary of Key Training and relevant
Certifications

8.

Language Proficiency

9.

Employment Record

From/To:
Employer:
Position Held:
From/To:
Employer:
PositionHeld:
From/To:
Employer:

10.

Total No. of Years of Work Experience

11.

Experience in relevant domain and skill set
as per requirement mentioned in TOR

12
.

Skill set

Years of Experience

Total No. of Years of relevant experience
for the proposed Role (as per the
requirement mentioned in TOR & ITB)

49

<!-- page 50 -->

13.

Highlights of relevant projects/assignments handled and significant accomplishments that Best
Illustrates Capability to Handle the Proposed Role (Use following format for each project)

Name of assignment or project: Client Name:
Year & Location:

Position Held:
Main project features (1-2 lines Max.): Activities performed:

50

<!-- page 51 -->

FINANCIAL FORMS

51

<!-- page 52 -->

FINANCIAL FORM 1: Letter of Financial proposal
(The bidder must accomplish the Letter of Financial Proposal on its letterhead clearly showing the
bidder’s complete name and address.)

To,
Secretary
Bihar State Housing Board, Patna, Bihar,
6, Sardar Patel Marg
Patna-800015, Bihar
Dear Sir,
We, the undersigned, declare that:

(a) We have examined and have no reservations to the Bidding Documents, including Addenda
issued in accordance with Instructions to Bidders.

(b) We offer to execute in conformity with the Bidding Documents and the Technical Proposal
submitted for the Work “Selection of a Consultant for Project Management Unit (PMU) for
Bihar State Housing Board”

(c) We do hereby undertake, that, in the event of acceptance of our bid, the Services shall be
provided as stipulated in the schedule to the Bid document and that we shall perform all the
incidental services.

(d) We enclose herewith the complete Price Bid as required by you in FINANCIAL FORM-5

(e) Our Bid shall be valid for a period of 90 (ninety) days from the date fixed for the bid subform6mission deadline in accordance with the Bidding Documents, and it shall remain binding
upon us and may be accepted at any time before the expiration of that period.

(f) If our Bid is accepted, we commit to obtain performance security in accordance with the
Bidding Documents.

(g) We understand that this bid, together with your written acceptance thereof included in your
52

<!-- page 53 -->

notification of award, shall constitute a binding contract between us, until a formal contract is
prepared and executed.

(h) We understand that you are not bound to accept the lowest evaluated bid or any other bid that
you may receive.

Name ......................................................................................

In the capacity of ....................................................................

Signed .....................................................................................

Date-…………………………………………………………

53

<!-- page 54 -->

FINANCIAL FORM 2: FINANCIAL PROPOSAL COVER

(AMOUNT IN INR)

Location, Date

To,
Secretary
Bihar State Housing Board, Patna, Bihar,
6, Sardar Patel Marg
Patna-800015, Bihar
Dear Sir:
We, the undersigned, offer to provide services for “Project Management Unit (PMU) for Bihar
State Housing Board, Patna - Bihar”in accordance with your Request for Proposal dated
and our Technical Proposal.

Our attached Financial Proposal is for the amount of INR ----------------------- (Rupees-------------------------------- ) and is inclusive of all taxes, duties, levies as may be applicable.
Our Financial Proposal shall be binding upon us until the expiration of the validity period of the
Proposal.
We understand you are not bound to accept any Proposal you receive.

We remain,
Yours sincerely,
Authorized Signature [In full and initials]:
Name and Title of Signatory:
Name of Firm:
Address:
Seal/Stamp of bidder:

54

<!-- page 55 -->

FINANCIAL FORM 3: Financial Proposal Format (amounts in INR)
PRICE BID SCHEDULE

NAME OF Assignment: - “Selection of a Consultant for Project Management Unit (PMU) for
Bihar State Housing Board”

Name of Bidder:
A. FINANCIAL BID AMOUNT (IN INR) ANNUALLY
Particulars

Amount

Total Financial Bid Amount (in Figures)
Total Financial Bid Amount (in Words)

Note: The above quote shall be exclusive of applicable GST

B. DECLARATION
1. We confirm that this Financial Proposal is unconditional and without any deviations.
2. We agree that the above quoted rates and total bid amount shall remain valid and binding as per
the validity period stated in the RFP.

Signature of the Bidder Date:
Place:
Company Seal

Important Note:
1.

For The price reasonability purpose, the Proposal Evaluation Team may ask the bidder to
provide detail break down of the quoted price.

2.

Payments to be made after approvals of the deliverables by BSHB.

55

<!-- page 56 -->

FINANCIAL FORM – 3 (A): Breakdown of Remuneration Cost
(For Key & non-key Experts)

(amounts in INR)Annually
Sl.
No.

Key Personnel

1

Team Leader cum PPP
Expert
Finance Expert
Legal Expert
Urban Planner
Architect
Infrastructure Planner
Financial Analyst
Procurement Expert
Project Monitoring Expert

2
3
4
5
6
7
8
9

Nos Total
Person
Months
input
1
12
1
1
1
1
1
1
1
1

Rateper
Month

Rate For 12
months

12
12
12
12
12
12
12
12

.
Total

TotalRemuneration =

(AmountinWords)

Note:

1. The Bidder shall quote the Consultancy Fee for 1 (First) year only, the fees for year

2nd (Second) and year 3rd (Third) shall be derived automatically by applying an
annual escalation of 5 % (five percent) on the immediately.
2. The price quoted is exclusive of all taxes including GST.
3. If there is a discrepancy between words and figures, the amount in words will

prevail for calculation of price.

56

<!-- page 57 -->

FINANCIAL FORM 3 (B): OTHER EXPENSES

Any other expenses

Reimbursable
Particular

Amount (in Rs.)

Total

57

<!-- page 58 -->

FINANCIAL FORM 4: Performance Bank Guarantee
[On Appropriate Stamp Paper]

Ref:

Bank Guarantee No.

Date

<Name>
<Designation>
<Address>
<Phone Nos.>
<Fax Nos.>
<Email id>
Whereas, [<<name of the supplier and address>>] (hereinafter called “the Agency has undertaken,
in pursuance of contract no. [<<Insert Contract No.>>] dated. [<<Date>>] to provide “Selection
of a Consultant for Project Management Unit (PMU) for Bihar State Housing Board”

And whereas it has been stipulated by in the said contract that the bidder shall furnish you with a
bank guarantee by a recognised bank for the sum specified therein as security for compliance with its
obligations in accordance with the contract;

And whereas we, [<<Name of Bank>>] a banking company incorporated and having its
head/registered office at [<<Address of Registered Office>>] and having one of its offices at
[<<Address of Local Office>>] have agreed to give the supplier such a bank guarantee.

Now, therefore, we hereby affirm that we are guarantors and responsible to you, on behalf of the
supplier, up to a total of Indian Rupees [<<Insert Value>>] (Rupees [<<Insert Value in Words>>]
only) and we undertake to pay you, upon your first written demand declaring the supplier to be in
default under the contract and without cavil or argument, any sum or sums within the limits of Indian
Rupees [<<Insert Value>>] (Rupees [<<Insert Value in Words>>] only) as aforesaid, without your
needing to prove or to show grounds or reasons for your demand or the sum specified therein.

58

<!-- page 59 -->

We hereby waive the necessity of your demanding the said debt from the bidder before presenting us
with the demand.

We further agree that no change or addition to or other modification of the terms of the contract to
be performed there under or of any of the contract documents which may be made between you and
the Master system Integrator shall in any way release us from any liability under this guarantee and
we hereby waive notice of any such change, addition or modification.

This Guarantee shall be valid until [<<Insert Date>>]) notwithstanding anything contained herein:
I.

Our liability under this bank guarantee shall not exceed Indian Rupees [<<Insert
Value>>] (Rupees [<<Insert Value in Words>>] only).

II. This bank guarantee shall be valid up to [<<Insert Expiry Date>>]
III. It is a condition of our liability for payment of the guaranteed amount or any part thereof
arising under this bank guarantee that we receive a valid written claim or demand for
payment under this bank guarantee on or before [<<Insert Expiry Date>>] failing which
our liability under the guarantee shall automatically cease.

Date

Place

Signature

Witness

Printed
name

(Bank's

common

seal)

59

<!-- page 60 -->

FINANCIAL FORM 5: Bid Security Form (Bank Guarantee)
(Bank’s Name, and Address of Issuing Branch or Office) Beneficiary: _ _ _ _ _ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _ _ _ (name and address of Employer) Date: _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
_ _ _ _ _ _ _Bid Security No.: _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

WhereasM/s
(insert the name of the Consultant)
(hereinaftercalled the “Consultant”) has submitted its technical & financial proposals for the RFP,
“Selection of a Consultant for Project Management Unit (PMU) for Bihar State Housing
Board”(hereinafter called the “Proposal”) dated _ _ _ _ _ _ _ _ against the Employer‟s Notice
Inviting Tenders (NIT) Notice Inviting Request for Proposals _ (Insert NIT/NIP/IFB numberasper
publication in newspaper or website).

Furthermore, we understand that, according to your conditions, proposals must be supported by a
Bid Security.At the request of theConsultant,we
(insert name of thebank)
hereby irrevocably undertake to pay you any sum or sums not exceeding in total amount of _ _ _ _ _ _
_ _ _ (insert bid security amountinfigures) _________________________________________
_ _ (amount in words) upon receipt by us of your first demand in writing accompanied by a written
statement stating that the Consultant is in breach of its obligation(s) under the RFP conditions, because
the Consultant has withdrawn its Proposal during the period of Proposal validity specified by the
Consultant in the Technical Proposal Form; or

(a)
(b)

Does not accept the correction of errors in accordance with the Instructions to
Consultants/Bidders (hereinafter “the ITC” / ”the ITB”) of the RFP Document;or
HavingbeennotifiedoftheacceptanceofitsProposalbytheEmployerduringtheperiodofproposal
validity, (i) fails or refuses to execute the Contract Agreement, or (ii) fails or refuses to furnish
the Performance Security, in accordance with the ITC/ITB.

This guarantee will expire: (a) if the Consultant is the successful Consultant, upon our receipt of
copies of the Contract Agreement signed by the Consultant and the performance security issued to you
upon the Instruction of the Consultant; and (b) if the Consultant is not the successful Consultant, upon
the earlier of
(i) our receipt of a copy your notification to the Consultant of the name of the successful Consultant;
or(ii) forty‐fivedays after theexpiration ofthe Consultant‟s proposal.
Consequently, any demand for payment under this guarantee must be received by us at the office on or
before that date.
This guarantee is subject to the Uniform Rules for Demand Guarantees, ICC Publication No. 458.

_ _____________ Bank’s seal and authorized signature(s) _
_________

60

<!-- page 61 -->

SECTION V CONTRACT FORMAT
Standard Contract
THIS CONTRACT for the “Consultant for Project Management Unit (PMU) for Bihar
State Housing Board” (hereinafter called the “Contract”) is entered into [number] day of
the month of [month], [year], between Bihar State Housing Board, Patna, Bihar(hereinafter
called the “Employer”) and M/s [name of Consultant] (hereinafter called the
“Consultant”), a company, and having its registered office at [insert Consultant‟s
address]; Telephone:
, Email:.
WHEREAS
the „Employer‟ has requested the Consultant to provide certain consulting services as
defined in this Contract (hereinafter called the “Services”) described in Terms of
Reference and Scope of Services of the RFP as part of the implementation of the Project;
(b) the Consultant, having represented to the „Employer‟ that it has the required
professional skills, expertise and technical resources, has agreed to provide the Services
on the terms and conditions set forth in this Contract;
(c) THE PARTIES hereby agree as follows:
3. The following documents attached hereto shall be deemed to form an integral part of
this Contract:
i.
ii.
iii.
iv.
v.
vi.
vii.
4.

The Contract Agreement
The Letter of Bid with supporting documents
The addenda Nos if any)
The Conditions of Contract;
Terms of Reference
RFP document
Price Bid

The mutual rights and obligations of the <Employer> and the Bidder shall be as set
forth in the Contract, in particular:
a. the Bidder shall carry out the [
] in accordance with the
provisions of the Contract; and
b. the<Employer> shall make payments to the Bidder in accordance with the
provisions of the Contract.

61

<!-- page 62 -->

5.

6.

The Bidder /Consultant shall perform the Services during the period commencing
[insert start date] and ending on [insert completion date] or any other period as may
be subsequently agreed by the parties in writing.
The <Employer> designates Shri…………..……. as <Employer>‟s Project Head;
the Project Head shall be responsible for the coordination of the Contract, for
receiving and approving invoices for payment, and for acceptance of the deliverables
by the <Employer>.

IN WITNESS WHEREOF, the Parties hereto have caused this Contract to be signed in
their respective names as of the day and year first above written.

For and on behalf of
Bihar State Housing Board, Patna, Bihar

For and on behalf of
[Name of Consultant]

[Authorized Representative of the
BSHB– name, title and signature]

[Authorized Representative of
Consultant – name and signature]

Signed by

Signed by

Title

the

Title:

62

<!-- page 63 -->

SECTION VI: TERMS OF REFERENCE
A. Terms of Reference

1.

Background
Bihar State Housing board (BSHB) represents a statutory authority constituted by the
Government of Bihar under the Bihar State Housing Board act,1982 and is mandated with the
development of various housing schemes & related infrastructural facilities in the State.

2.

3.

Mission:


Development of Housing & Urban Infrastructure to increase liveability of the city.
Ensure environmental development in the urban Diaspora.



Ensure adherence to Planning & Building regulations.



Create land bank for effective Urban Development.



Ensure slum Redevelopment. Provision of affordable Housing.



To undertake housing projects in the state to make affordable housing for public and
the state govt. use/ purpose



To implement Affordable housing policy for the state of Bihar

Objective of the Assignment
A Project Management Unit is envisioned to support, monitor and manage all as defined
activities in the ToR but not limited to for BSHB. Since this will involve wide spectrum of
activities covering different projects,BSHB intends to appoint a team comprising of technical
and management expertise personnels forming a Project Management Support Group.

4.

Scope of Work
Project Monitoring Unit (PMU) for Bihar State Housing Board (BSHB)
The selected Consultant shall act as the Project Monitoring Unit (PMU) and provide
comprehensive technical, procurement, financial, project management, and institutional
advisory support to the Bihar State Housing Board (BSHB) for planning, procurement,
financing, implementation, and monitoring of housing and urban development projects
undertaken by BSHB.
The Consultant shall assist BSHB in ensuring that projects are structured and implemented in a
Transparent, Efficient, Financially Viable, and Technically sound manner, while adhering
to applicable government policies, procurement guidelines, and statutory requirements.
The scope of services shall include, but not be limited to, the following components.
1. Project Conceptualization and Strategic Planning
The Consultant shall support BSHB in identifying, conceptualizing, and structuring housing
63

<!-- page 64 -->

and urban development projects across the State.
The Consultant shall assist BSHB in:
 Identification and prioritization of potential housing and urban development projects.
 Preparation of project concept notes and strategic development plans.
 Assessment of development potential of available land parcels and urban growth
corridors.
 Identification of suitable project delivery models such as EPC, PPP, Joint Development,
or Hybrid models.
 Advising on optimal project structuring considering land utilization, infrastructure
requirements, and market demand.
 Conducting preliminary assessments including land availability, connectivity,
infrastructure support, and regulatory requirements.
 Supporting BSHB in coordination with Urban Local Bodies (ULBs), State Departments,
and other agencies for project planning.
The Consultant shall also assist BSHB in aligning projects with State housing policies,
affordable housing programs, and national schemes where applicable.
2. Procurement Planning and Bid Process Management
The Consultant shall provide end-to-end advisory support to BSHB for structuring and
implementing procurement processes required for project execution.
The Consultant shall be responsible for:
 Preparation of project-wise procurement strategies and procurement plans.
 Structuring procurement packages and defining contract packaging strategies.
 Preparation of bidding documents including Notice Inviting Tender (NIT), Expression
of Interest (EOI), Request for Qualification (RFQ), Request for Proposal (RFP), and
draft agreements.
 Preparation of project information memoranda and bid data sheets.
 Defining qualification criteria, technical evaluation parameters, and financial evaluation
methodology.
 Supporting publication of tenders and marketing of projects to potential bidders and
investors.
 Conducting pre-bid meetings and issuing clarifications.
 Preparation of addenda and corrigenda where required.
 Assistance in bid opening procedures.
 Evaluation of technical and financial proposals in accordance with the RFP provisions.
 Preparation of bid evaluation reports and recommendations for award.
 Assistance to BSHB in negotiations with selected bidders where required.
 Finalization of contract documents and assistance in execution of agreements.
The Consultant shall ensure that all procurement processes are conducted in accordance with
applicable Government procurement regulations and principles of transparency,
fairness, and competitiveness.
3. Review and Monitoring of DPR Consultants
Where DPR consultants are appointed by BSHB, the Consultant shall review and monitor the
DPR preparation process to ensure quality, technical soundness, and compliance with approved
64

<!-- page 65 -->

Terms of Reference.
The Consultant shall:









Monitor DPR preparation progress against approved timelines.
Facilitate coordination between BSHB and DPR consultants.
Review surveys, investigations, and baseline studies conducted by DPR consultants.
Examine architectural planning concepts, layouts, and infrastructure planning proposals.
Review engineering designs and technical specifications.
Review cost estimates, project budgets, and implementation schedules.
Verify compliance with statutory, environmental, and regulatory requirements.
Provide technical comments and recommendations to BSHB on improvements required
in the DPR.

The Consultant shall ensure that the DPR is complete, technically sound, and suitable for
procurement and implementation.
4. Project Implementation Planning and Monitoring
The Consultant shall assist BSHB in monitoring the implementation of projects to ensure
adherence to timelines, quality standards, and contractual obligations.
The Consultant shall:
 Develop project implementation frameworks and milestone tracking systems.
 Monitor progress of projects against approved schedules.
 Review progress reports submitted by contractors, supervision consultants, and other
agencies.
 Track physical and financial progress of projects.
 Identify delays, risks, and bottlenecks in implementation.
 Recommend corrective measures and mitigation strategies.
 Facilitate coordination between contractors, consultants, and government agencies.
 Provide regular progress updates and performance reports to BSHB.
5. Contract Management and Administration
The Consultant shall provide comprehensive contract management support for projects
undertaken by BSHB.
Contract Administration
The Consultant shall:
 Review contract documents prior to execution.
 Assist in issuance of Letters of Award (LoA), Notices to Proceed (NTP), and other
contractual communications.
 Establish standardized contract administration systems and documentation processes.
 Maintain centralized contract documentation and records.
Monitoring of Contractual Compliance
The Consultant shall:
 Monitor contractor performance against contractual milestones.
 Ensure compliance with technical specifications and quality requirements.
 Verify validity of performance securities, insurances, and guarantees.
65

<!-- page 66 -->

 Monitor compliance with environmental, social, health, and safety requirements.
Financial and Payment Management
The Consultant shall:





Scrutinize interim payment certificates and contractor invoices.
Review variation orders and change requests.
Monitor project expenditures against approved budgets.
Track financial progress in relation to physical progress.

Claims and Dispute Management
The Consultant shall:
 Evaluate contractor claims including extension of time (EoT) and compensation events.
 Provide advisory support on interpretation of contractual provisions.
 Assist BSHB in dispute avoidance and dispute resolution processes.
6. Financial Structuring and Fund Raising
The Consultant shall assist BSHB in mobilizing financial resources for implementation of
housing and urban infrastructure projects.
The Consultant shall provide support in:
 Identification of potential funding sources including State Government support, financial
institutions, multilateral agencies, housing finance institutions, infrastructure funds, and
capital markets.
 Preparation of project financial models and investment frameworks.
 Structuring of financing mechanisms including PPP structures, viability gap funding
(VGF), annuity models, joint development models, and blended finance structures.
 Preparation of financial information memoranda and investment briefs.
 Engagement with financial institutions, lenders, and investors.
 Assistance to BSHB in loan structuring, negotiations, and financial closure processes.
 Identification of innovative financing mechanisms including land monetization, asset
recycling, and infrastructure investment structures.
The Consultant shall assist BSHB in developing a sustainable financing strategy to support
long-term housing development programs.
7. Risk Management and Project Reporting
The Consultant shall assist BSHB in identifying, assessing, and mitigating project risks.
The Consultant shall:
 Develop and maintain a project risk register.
 Identify technical, financial, contractual, and regulatory risks.
 Recommend mitigation strategies and risk management measures.
 Provide periodic risk assessment reports.
 Submit monthly, quarterly, and project-specific monitoring reports to BSHB.
8. Policy Advisory and Institutional Strengthening
The Consultant shall provide policy and institutional advisory support to BSHB.
The Consultant shall assist in:

66

<!-- page 67 -->






Formulation and revision of housing policies and affordable housing frameworks.
Development of standard operating procedures and procurement guidelines.
Preparation of standard bidding documents and contract templates.
Advisory support for adoption of innovative project delivery mechanisms including PPP
projects.
 Strengthening institutional capacity within BSHB for project planning, procurement, and
monitoring.
9. Stakeholder Coordination and Facilitation
The Consultant shall facilitate coordination among various stakeholders involved in project
planning and implementation.
The Consultant shall support BSHB in coordinating with:






State Government departments
Urban Local Bodies
Regulatory authorities
Consultants and contractors
Financial institutions and investors

The Consultant shall assist in organizing stakeholder consultations, coordination meetings, and
review workshops.
10.

Development of Integrated Project Monitoring Dashboard

The Consultant shall design, develop, and operationalize a centralized digital Project
Monitoring Dashboard for monitoring all projects undertaken by BSHB.
The system shall include:







Project portfolio overview
Physical progress monitoring
Financial progress tracking
Contract management alerts
Risk and issue tracking
Automated reporting and analytics

The Consultant shall ensure data security, role-based access control, system integration
capability, and periodic system maintenance.
The Consultant shall also conduct training and capacity building programs for BSHB
officials to ensure effective use of the dashboard
5.

Office Space:
A dedicated Office space will be provided within the BSHB office building to the PMU team
along with officeinfrastructure including a telephone, printer, fax a desktop computer.
As per the requirement ascertained, a project vehicle may also be allocated to the PMU, for
official use only, upon due approval from the competent authority in BSHB. If required a staff
would be deployed on full time basis from BSHB for the additional support and coordination.

6.

Contract period
The duration of the Contract shall be 36 (thirty-six) months from the date of signing of the
67

<!-- page 68 -->

Contract. The Contract may be extended for a further period of up to 24 (twenty-four) months,
subject to satisfactory performance of the Consultant during the Contract period and at the
mutually agreed terms.
An annual escalation of 5% (five percent) each year on the monthly retainer fee shall be
applicable.

***

68
