---
doc_id: "0fa2cce82e01ffe6"
source_url: "https://horticulture.bihar.gov.in/MainSite/Documents/Act_Rules/Cold_Storage_1993.pdf"
ministry: "Horticulture Directorate, Agriculture Department, Bihar"
title: "View"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "98d5e00b55e4744f"
---

<!-- page 1 -->

fcgkj xtV
¼dksYM LVksjst fofu;eu vf/kfu;e½

fcgkj xtV
vlk/kkj.k vad
fcgkj ljdkj }kjk izdkf'kr
5 QkYxqu] 1914 ¼'kñ½
iVuk cq/kokj] 24 Qjojh] 1993
¼lañ iVuk 123½

d`f"k foHkkx
vf/klwpuk
22 Qjojh 1993
thñ,lñvkjñ 13] fnukad 24 Qjojh] 1993&fcgkj&jkT;iky fcgkj jkT; dksYM LVksjst fofu;eu vf/kfu;e]
1992 ¼fcgkj vf/kfu;e 17] 1992½ dh /kkjk 45 dh mi&/kkjk ¼1½ }kjk iznÙk 'kfDr;ksa dk iz;ksx djrs gq,
fuEufyf[kr fu;ekoyh cukrs gSa %&

fu;ekoyh
1- laf{kIr uke] izlkj ,oa izkjaHk &
¼1½ ;g fu;ekoyh fcgkj jkT; dksYM LVksjst fofu;eu vuqKfIr fu;ekoyh 1993 dgh tk ldsxhA
¼2½ ;g lEiw.kZ fcgkj jkT; esa izHkkoh gksxhA
¼3½ ;g rqjar izo`Ùk gksxhA
2- ifjHkk"kk,a & tc rd fd lanHkZ esa vU;Fkk visf{kr u gks] bl fu;ekoyh esa &
¼1½ ^^dys.Mj o"kZ** esa rkRi;Z gS igyh tuojh ls bDrhl fnlEcj rd dh vof/k
¼2½ ^^izi=** ls rkRi;Z gS bl fu;ekoyh ls mikc) izi=
¼3½ ^^vf/kfu;e** ls rkRi;Z gS fcgkj jkT; dksYM LVksjst fofu;eu vf/kfu;e] 1992&
¼fcgkj vf/kfu;e 17] 1992½A
¼4½ ^^vuqlp
w h** ls rkRi;Z gS bl fu;ekoyh ls mikc) vuqlwph
¼5½ ^^/kkjk** ls rkRi;Z gS vf/kfu;e dh /kkjk
¼6½ bl fu;ekoyh esa iz;qDr fdUrq vifjHkkf"kr 'kCn rFkk inkoyh ds ogh vFkZ gksx
a ]s tks muds fy,
vf/kfu;e esa fn; x, gSA
3- vuqKfIr dh 'kÙksZ ,oa fucaf/ku&/kkjk 6 dh mi&/kkjk ¼1½ ds v/khu nh x;h ;k /kkjk 7 dh mi&/kkjk
¼1½ ds v/khu uohd`r vuqKfIr fuEufyf[kr 'kÙkksZ vkSj fuca/kuksa ds v/;/khu gksxh %&

<!-- page 2 -->

¼1½ vkosnd }kjk izLrqr fd;k x;k fooj.k lgh] iq.kZ rFkk vuqKfIr izkf/kdkjh ds iw.kZ lUrks"kizn gksuk
pkfg,A
¼2½ dksYM LVksjst /kkjk 6 ds fofunsZ'kksa ds vuq:i gks vkSj jgs rFkk vU; fofunsZ'kksa dk vuqikyu gksA
¼3½ fdjk;knkrkvksa dks LVksj fd, x;s ;k LVksj fd;s tkusokys d`f"k mRiknu dk fujh{k.k djus]
rkSyokus] ekius] uewuk ysus vkSj Js.khdj.k djus dh lqfo/kk nh tk;sxhA
¼4½ vuqKfIr lnSo dksYM LVksj ds Hkw&x`g esa j[kh tk;sxh vkSj fujh{k.k rFkk tk¡p ds fy, vuqKfIr
izkf/kdkjh }kjk ekaxs tkus ij mls izLRkqr dh tk;xhA
¼5½ vuqKfIr/kkjh dsUnzh; ;k jkT; ljdkj }kjk le;&le; ij d`f"k mRiknu 'kqYd yxkus lEcU/kh
cuk, x;s fu;eksa dk ikyu djsxkA
¼6½ ifjlj ftlesa dksYM LVksjst vf/kf"Br gks] LoPN gksxkA dksYM LVksjst ds Hkhrj izR;sd 40&45
oxZ lsUVhehVj ¼5 oxZQVq ½ LFkku ds fufer ,d okV dh nj ls fo|qr~ izdk'k dh O;oLFkk dh
tk;xhA
¼7½ ¼d½ leLRk izkax.k] ofgx`g] LVksj rFkk] Hkq&x`gkfn ds vkxe&}kj tgk¡ dksYM LVksjst vf/kf"Br gks
LoPN vkSj 'kq) j[ks tk;sx
a sA
¼[k½ dksYM LVksjst vkSj Hkw&x`gkfn ftlesa og fLFkr gks] esa fuLlaØe.k vkSj nq xZU/k gj.k dh
lafØ;k ;k mipkj mruh ckj fd;k tk;sxk ftruh ckj vko';d gks vkSj de&Lks&de ,d
dys.Mj o"kZ esa ,d ckj fd;k tk;sxkA
¼8½ vuqKfIr/kkjh dksbZ ,slk mRiknu dksYM LVksjst esa LVksj ugha djsxk tks d`f"k mRiknu ls foijhr
vFkok 'kh/kz fojks/kh gksA foijhr xU/k okys mRiknu] dksYM LVksjst ds i`Fkd d{kksa esa LVksj fd;s
tk;sx
a As
¼9½ fdlh laØked ;k lkalfxZd jksx ls xzLRk fdlh O;fDr dks dksYM LVksjst esa dke djus dh
vuqKk ugha nh tk;sxhA dksYM LVksjst esa nSfud etnwjh ij dke djus okys etnwjksa ls fHkUu
deZpkfj;ksa ds bl ijh{k.k ;k izca/k] fd os fdlh laØked ;k lkalfxZd jksx vFkok vU; jksx ls
xzLRk rks ugha gS] ,d dys.Mj o"kZ esa de&ls&de ,d ckj fd;k tk;sxkA
¼10½ dksYM LVksjst ds Hkhrj dke djus okys deZpkfj;ksa ds fy;s ,sls diM+ksa dh O;oLFkk dh tk;sxh]
tks mUgsa lnhZ ls cpk;sA fgekad fcUnq ls fuEurj n'kk esa dke djus okys deZpkfj;ksa ds fufer
cwV dh O;oLFkk dh tk;sxhA
¼11½ ok;q ds forj.k rFkk ifjlapj.k vkSj oLrq yknus vkSj mrkjus ds fufer fuEufyf[kr vuqns'kksa dk
vuqlj.k fd;k tk;xk&
¼i½ jsdksa dh nksuksa iafDr;ksa ds chp 00-75 ehVj ds de LFkku u gksxkA
¼ii½ jsd nhokykas Qj'kksa ls de&ls&de 20 lsVa h ehVj dh nwjh ij j[ks tk;saxsA
¼iii½ izR;sd jsd ds mPpre 'ksYQ esa Nr rFkk ynku ds e/; de&ls&de 30 lsVa hehVj dh [kkyh
txg j[kh tkuh pkfg,A
¼iv½ fdlh 'ksYQ rFkk vU; 'ksYQ ds e/; de&ls&de 7-5 lsUVh ehVj [kkyh txgsa j[kh tkuh
pkfg;s ijUrq og fd tc cksjs esa LVksj fd;k tk; rc mi&fu;e ¼ii½ ds [k.M ¼i½] ¼ii½] ¼iii½ ds
v/khu 'kÙkkZsa dk ikyu djrs le; fuEufyf[kr funsZ'k dk Hkh vuqlj.k fd;k tk;xk %&
¼d½ ,d LVsd esa ,d nwljs ls mij 6 ls vf/kd cksjs ugha j[ks tk;sx
a As
¼[k½ izR;sd cksjs dh drkj esa 10 lsUVh ehVj dh txg NksM+h tk;sxhA
¼x½ LVksj djus dh vof/k ds nkSjku cksjksa dks nks ckj mij uhps fd;k tk;sxk vkSj mUgsa bl
izdkj j[kk tk;sxk fd LVsd esa tks cksjk lcls uhps gS og lcls mij j[kk tk; vkSj d`f"k
mRiknu LVksj djus ds 45 fnu] ds Hkhrj igyh ckj vkSj LVksj djus ds] 90 fnuksa ds Hkhrj
nwljh ckj cksjksa dks mij&uhps fd;k tk;sxkA
¼12½ dksYM LVksjst esa ,sls FkekZehVj yxs gksx
a s ftUkds }kjk MªkbZ cYCk rFkk osV cYo rki dk iBu
fd;k tk ldsA

<!-- page 3 -->

¼13½ izR;sd vuqKfIr/kkjh izi= eas ÞykWx cqdß j[ksxk vkSj mlesa rkieku rFkk lkis{k vknzZrk rFkk
dEizs'ku dk Hkkj&okpu dksYM LVksjst ds dk;Z dj.k ds nkSjku izR;sd pkj ?kaVksa ij vgfuZ'k
vafdr djsxk tcrd fd Lopkfyr vfHkys[k ;a= vf/kf"Br u dj fn;sa x;s gksaA vuqKfIr
inkf/kdkjh vFkok mlds }kjk bl fufer ;Fkksfpr :i ls izkf/kd`r dksbZ O;fDr izR;sd fujh{k.k
ds ekSds ij O;fDrxr :i ls vfHkys[kksa dk lR;kiu djus ds mijkUr ^^ykWx cqd** ij gLRkk{kj
djsxkA
¼14½ yxkrkj 24 ?kaVs ls vf/kd le; rd dksYM LVksjst ds dk;Z u djus dh lwpuk vuqKfIr/kkjh
}kjk vuqKfIr izkf/kdkjh dks rqjUr nh tk;sxhA bl izdkj dk;Z cUn gksus dk dkj.k ^^ykWx cqd**
esa fy[kk tk;sxk vkSj mldh lwpuk vuqKfIr/kkjh izkf/kdkjh dks nh tk;xhA
¼15½ izR;sd vuqKfIr/kkjh fdlh dk;Z fnol ds lkekU; dk;Z le; esa dksYM LVksjst esa izos'k djus]
fujh{k.k djus ;k ijh{k.k djus ;k mudh e'khu vkSj midj.k ys[kk ogka ij LVksj fd;s x,
d`f"k mRikn] mlds dk;kZy;] cfg;ks]a vfHkys[kks]a i=kfn ds ijh{k.k ;k fujh{k.k djus ds fy,
lnSo ,slh lqfo/kk;sa nsxk tSlh vuqKfIr izkf/kdkjh }kjk visf{kr gks vkSj ,slh vis{kk dh tkus ij
,sls vfHkys[k izLrqr djsxk tks vuqKfIr izkf/kdkjh }kjk vf/kfu;e ds fdlh iz;kstu ds fy,
visf{kr gksA
¼16½ ;fn dksYM LVksjst esa LVksj fd;k x;k eky] ,sls dkj.kksa ls tks vuqKfIr/kkjh ds fu;a=.k ls ijs
gks] [kjkc gksus yxs rks vuqKfIr/kkjh bldh lwpuk vuqKfIr izkf/kdkjh dks rqjUr nsxkA
¼17½ fdlh 'ksYQ ;k jsd dks] tgka {kfrxzLr ;k [kjkc gqvk d`f"k mRiknu LVksj fd;k x;k gks] ;k
vLFkk;h :i ls j[kk x;k gks] ,slk mRikn gVkus ;k fuLrkfjr djus ds i'pkr] rqjUr LoPN
vkSj fuLlaØfer fd;k tk;xkA
¼18½ tgka vuqKfIr/kkjh vius dksYM LVksjst esa vius uke ls dksbZ d`f"k mRikn LVksj djuk pkgs] ogka
og ,slk djus ds fy;s vuqKk ds fufeÙk vuqKfIr izkf/kdkjh dks fyf[kr vkosnu&i= nsxk]
ftlesa mlds }kjk LVksj fd;s tkus okys d`f"k mRikn dk ifjek.k] izdkj vkSj vof/k] tcrd ds
fy;s bl izdkj LVksj djus dk fopkj gks] mfYyf[kr dh tk;xh vkSj vius }kjk fofufnZ"V d`f"k
mRikn dks LVksj djuk oLrqr% izkjEHk djus ds iwoZ vuqKfIr izkf/kdkjh dh vuqKk izkIr dj
ysxkA
¼19½ vuqKfIr/kkjh blds laca/k esa dh x;h fdlh vU; lsok ds fy;s] /kkjk 29 ds v/khu jkT; ljdkj
}kjk fuf'pr fd;s x;s izHkkj dks NksM+dj dksbZ vU; izHkkj tSls ehek izHkkj] d`f"k mRikn dh
rkSyus] dksYM LVksjst dh izlhek ls] tgka mRikn dksYM LVksjst esa LVksj djus ds fy;s
fdjk;knkrk }kjk mrkjk tk;] d`f"k mRikn ys tkus] cksjksa ds Åij&uhps djus vkSj okil djus
ds iz;kstukFkZ mRikn dh dksYM LVksjst ls ifjlhek rd ys tkus ds iz;kstukFkZ Je laca/kh izHkkj
rFkk lq[kkus] Js.khdj.k djus] NkVus vkSj nqckjk cksjksa esa Hkjus vkfn ds fy;s LFkku vkSj miLdj
dh O;oLFkk djus ds fy, izHkkj tc rd fd jkT; ljdkj }kjk vuqKk u nh tk; ugha ysxkA
4- vuqKfIr ds fy, vkosnu &
¼1½ /kkjk 6 dh mi&/kkjk ¼1½ ds v/khu vuqKfIr fn;s tkus ds fy;s vkosnu&i= izi= 2 es]a nks izfr;ksa
esa fn;k tk;xk ftu ij vkosnd dk lE;d~ :i ls gLRkk{kj gksxk%
ijUrq ;g fd vkosnd vf/kfu;e vkSj bl fu;ekoyh ds mica/kks ds vuqlkj vuqKfIr fn;s tkus
ds fy;s ,slh vfrfjDr lwpuk] tSlh vuqKfIr izkf/kdkjh }kjk vis{kk dh tk;] nsus ds fy; ck/;
gksxkA
¼2½ tgka ,d gh vkosnd ,d ls vf/kd dksYM LVksjst ds laca/k esa vuqKfIr izkIr djuk pkgs] ogka
og izR;sd dksYM LVksjst ds fy;s i`Fkd&i`Fkd vkosnu i= izLrqr djsxkA
¼3½ mi&fu;e ¼1½ vkSj ¼2½ esa fufnZ"V vkosnu&i=ksa ds lkFk ewy pkyku gksxk] ftlesa fu;e 5 ds
mi fu;e ¼3½ esa fyf[kr ys[kk 'kh"kZ ds vUrZxr dks"kkxkj esa mDr fu;e ds mifu;e ¼2½ esa
tek dh x;h fofufnZ"V vuqKfIr Qhl dk mYys[k fd;k tk;sxkA

<!-- page 4 -->

vuqKfIr Qhl &&&
¼1½ jkT; ljdkj ds LokfeRo ;k izca/k esa dksYM LVksjst esa dksbZ vuqKfIr&Qhl ugha yh tk;xhA
¼2½ mi&fu;e ¼1½ ds vUrxZr vkus okys dksYM LVksjst ds fHkUu dksYM LVksjst ds laca/k esa vuqKfIr
fn;s tksus ds fy;s ,d dys.Mj o"kZ ;k blds Hkkx ds fy, vuqKfIr Qhl fuEufyf[kr gksxh%&

¼3½ Qhl] pkyku }kjk ys[kk 'kh"kZ&0401&d`f"k izkfIr;k¡&119 dksYM LVksjst Qhl ls vk;** ds
vUrxZr dks"kkxkj esa tek dh tk;xhA
6- vuqKfIr ds fy, 'kÙkZ& vuqKfIr fn;sa tkus ds fy;s dksYM LVksjst fuEufyf[kr 'kÙkksZa dk ikyu
djsxk%&
¼1½ dksYM LVksjst bl izdkj fufeZr vkSj vuqjf{kr fd;k tk;sxk fd og vknzZrk fujks/kd rFkk m"ek
fujks/kd gks vkSj mlesa if{k;ks]a dhVks]a {kfrdkjd dhM+s&edksM]+s pwgksa] d`Urd izkf.k;ksa vkSj ,sls
vU; dhM+s&edksM+s rFkk i'kqvksa ds izos'k dks jksdk tk ldsa rFkk LVksj fd, x;s d`f"k mRikn dks
{kfr igqapkus ds fo:) lajf{kr gksA
¼2½ fdlh d`f"k mRikn dks bl izdkj LVksj fd;k tk;sxk ftlls fd mls vknZzrk] ueh] m"ek]
>a>kokr ls ;k Q'kZ] ik'oZ nhokj] njoktksa vkSj f[kM+fd;ksa vkfn ds ikuh ls cpk;k tk ldsAa
¼3½ dksYM LVksjst ds Q'kZ Nr] nhokjks]a njoktksa vkSj f[kM+fd;ksa ;k fdlh fNnz ¼vksifuax½ dk
m"ekjks/ku&¼1½ dkdZ Lysc] ¼2½ Xykl Åy] ¼3½ jkd&Åy] ¼4½ ,DlisaMsM iksfyLVhjhu ¼5½
Fkjekiksdksy ¼6½ FkjeksQkb;] ¼7½ Fkjeks,yk;V] ¼8½ Fkjeksisd ;k ,slh vU; oLrq ls fd;k tk;sxk
ftls vuqKfIr izkf/kdkjh vuqeksfnr djsAa dksYM LVksjst ds vko';drk ds vuqlkj rkieku dks
fofu;fer djus ds fy, m"ekjks/ku vkSj tyjks/ku dh izfØ;k mfpr jhfr ls dh tkuh pkfg,A
tks vuqKfIr izkf/kdkjh ds vuqeksnu ds v/;k/khu gksxkA
¼4½ tksMk+ s ls rkieku fudyus dh lHkh laHkkoukvksa dks nwj djus ds fy, ?kqekonkj] tksMk+ sa dks frjNh
djds m"ekjks/ku lkexzh ijrksa esa yxk;h tkuh pkfg,A
¼5½ dksYM LVksjst ds njoktksa esa m"ekjks/ku dh i;kZIr O;oLFkk gksxh vkSj os ;qfDr;qDr :i ls
ok;qjks/kh gksuh pkfg;sA njoktksa dh fMtkbu ,slh gksxh ftlls fd dksbZ O;fDr mls ckgj vkSj
Hkhrj nksuksa rjQ ls [kksy ldsAa
¼6½ tgk¡ dgha jsd dh O;oLFkk dh tk; ogk¡ mUgsa bl izdkj fufeZr fd;k tk;sxk fd dksYM&LVksjst
esa dk;Z djus okys deZpkfj;ksa ds thou dh [krjs esa Mkys fcuk yknus ;k mrkjus dk dk;Z
fd;k tk lds A
¼7½ fM¶;wtj ;k MkbjsDV ,Dlisa'ku ikbZi] ftuls gksdj fgedkjd nzO; ¼jsQjhtsjsUV½ tkrk gks] dksYM
LVksjst esa bl izdkj yxk;s tk;sx
a s fd lsUVhxzsM dh vuqK;
s mPpre fofHkUurk lfgr mi;qDr
rkieku vkSj 5 izfr'kr dh vuqK;
s fHkUurk ls lkis{k vknzZrk dk izfr'kr dksYM&LVksjst ds
izR;sd ,sls LFkku esa cuk jgs]a tgk¡ ij d`f"k mRikn LVksj fd;s x;s gksAa
¼8½ izR;sd dksYM LVksjst esa ,sls d`f"k mRikn dks tks [kjkc gks jgs gksa ;k ftlesa [kjkc gksus ds y{k.k
gks]a i`Fkd djus rFkk vLFkk;h :i ls LVksj djus ds mi;qDr vkSj lqfo/kktud] LFkku gksxk

<!-- page 5 -->

ftlls fd ,slk d`f"k mRikn] tcrd fd mldk fuLrkj.k u dj fn;k tk; dksYM LVksjst esa
LVksj fd;s x;s vU; d`f"k mRikn ds lEidZ esa u vk;s ;k fdlh izdkj ls mls izHkkfor u djsAa
¼9½ dksYM LVksjt ds Hkw&x`gkfn esa vfXu'kked vkSj fuLlaØe.k midj.k rFkk lkexzh lnSo iz;ksT;
n'kk esa j[kh tk;sxh rFkk ,sls miLdj vkSj lkefxz;ksa dks laHkkyus ds fy, izf'kf{kr deZpkjh Hkh
j[ksa tk;saxAs
¼10½ dksYM LVksjst ds Hkw&x`gkfn esa deZpkfj;ks]a fdjk;knkrkvksa ;k muds vfHkdÙkkZvksa ds fy;s rFkk ÍVw
vkSj xkM+h okys vU; i'kqvksa ds fy;s Hkh is;ty dh O;oLFkk gksxhA
¼11½ dksYM LVksjst rd igqap ekxZ bl izdkj cuk;k tk;sxk ftlls fd d`f"k mRikn ds ykus ys tkus
dh lqfo/kk gks ldsAa
¼12½ dksYM LVksjst esa iwoZ 'khru d{k dh O;oLFkk gksxh tgka dksYM LVksjst esa vfUre ynku ds iwoZ]
d`f"k mRikn de&ls&de 24 ?kaVs rd LVksj fd;k tk;xkA
7- vuqKfIr izi=& /kkjk 6 dh mi&/kkjk ¼1½ ds v/khu nh x;h vuqKfIr izi= 3 esa gksxhA
8- vuqKfIr dh vof/k& /kkjk 6 dh mi /kkjk ¼1½ ds v/khu nh x;h vuqKfIr ,d dys.Mj o"kZ dh
vof/k ds fy;s fof/k ekU; gksxh vkSj ml fnukad ls tc vuqKfIr nh tk;] vkxkeh 31 fnlEcj
dks og vof/k lekIr gksxhA
9- vuqKfIr&uohdj.k& /kkjk 7 esa fu/kkZfjr 'kÙkksZ ;k /kkjk 42 ds v/khu jkT; ljdkj }kjk tkjh fd,
x, funs'kksaZ] ;fn dksbZ gks ds v/;/khu] /kkjk 6 dh mi&/kkjk ¼1½ ds vuqlkj nh x;h vuqKfIr
fu;e 10 ds vUrxZr vuqKfIr/kkjh ds vkosnu&i= ij vkSj fu;e 11 esa fofgr Qhl nsus ij]
le;&le; ij] ,d dys.Mj o"kZ ds fy;s uohd`r fd;k tk;sxkA
10- vuqKfIr ds uohdj.k dk izi=& vuqKfIr uohdj.k ds fy;s vkosnu&i=] izi= 4 esa gksxk vkSj
mlds lkFk ewy] dks"kkxkj pkyu gksxk ftlesa fu;e 11 ds vuqlkj tek dh x;h Qhl
mfYyf[kr gksxhA
11- vuqKfIr uohdj.k dh Qhl& ¼1½ ,d dys.Mj o"kZ ds fy;s vuqKfIr ds uohdj.k ds fufer
vuqKfIr Qhl fuEufyf[kr gksxh%&

¼2½ Qhl fu;kekoyh ds fu;e 5 ds mi&fu;e ¼3½ esa vafdr ys[kk 'kh"kZd ds vUrxZr pyku ds
ek/;e ls dks"kkxkj esa tek dh tk;xhA
12- vuqKfIr uohdj.k ds fy, vkosnu&i= nsus dh vof/k rFkk izfØ;k &
¼1½ vuqKfIr ds uohdj.k ds fy;s vkosnu&i= ml o"kZ ds ftuds fy;s vuqKfIr dk uohdj.k
fd;k tkuk visf{kr gks fiNys o"kZ dh vf/kd ls vf/kd 31 vDrqcj rd tcrd fd jkT;
ljdkj }kjk fnukad c<+k;k u tk; vuqKfIr izkf/kdkjh ds ikl igqap tk; %
ijUrq ;g fd tgka /kkjk 6 ds v/khu vuqKfIr 31 vDrwcj dks ;k mlds i'pkr~ nh tk;]
ogka vxys dys.Mj o"kZ ds fy;s vuqKfIr ds uohdj.k ds fy;s vosnu&i= iwoZoÙkhZ o"kZ ds
31 fnlEcj rd vf/kd ls vf/kd fn;k tk ldrk gSA
¼2½ vuqKfIr ds uohdj.k ds fy;s vkosnu&i= ds lkFk /kkjk 6 ds v/khu nh x;h vuqKfIr
Hksth tk;sxhA

<!-- page 6 -->

13- uohdj.k ds fy, foyEc Qhl ds lkFk vkosnu&i= izLrqr djuk%&
¼1½ fu;e 12 esa fofufnZ"V frfFk ds i’pkr~ fdUrq 31 fnlEcj ds i’pkr~ ugha] vuqKfIr ds uohdj.k ds
fy;s izLrqr vkosnu&i= ij Hkh fofgr uohdj.k Qhl vkSj ,slh foyac Qhl tks vuqKfIr ds
uohdj.k ds fy;s Qhl dh jkf’k ds vk/ks ds cjkcj gks] nsus ij vuqKfIr izkf/kdkjh }kjk fopkj
fd;k tk;sxk %&
ijUrq ;g fd jkT; ljdkj uohdj.k dk vkosnu&i= izLrqr djus ds fy;s vafre frfFk dks c<+k
ldrh gSA
¼2½ Qhl vkSj foyac Qhl dks fu;e 5 ds mi&fu;e ¼3½ esa fofufnZ"V ys[kk 'kh"kZd ds vUrxZr pkyku
ds ek/;e ls dks"kkxkj esa tek fd;k tk;sxkA
14- vuqKfIr dh f}rh;d izfr izkIr djus dh Qhl vkSj izfØ;k %&
¼1½ ;fn dksbZ vuqKfIr [kks tk;] u"V gks tk;] QV tk;] fo:fir gks tk; ;k vU; izdkj ls
viBuh; gks tk; rks vuqKfIr dh f}rh;d izfr iPphl :i;s dh Qhl] tks fu;e 5 ds
mi&fu;e ¼3½ esa fofufnZ"V ys[kk 'kh"kZd ds vUrxZr pkyku ds ek/;e ls dks"kkxkj esa tek dh
tk;xh] nsus ij tkjh dh tk;sxhA
¼2½ vuqKfIr dks f}rh;d izfr tkjh djus ds fy;s vkosnu&i= izi= 5 esa fn;k tk;xk vkSj mlds
lkFk ewy pkyku gksxk ftlesa mi&fu;e ¼1½ esa fofufnZ"V tek dh x;h Qhl mfYyf[kr gksxhA
¼3½ tc [kksbZ gq;h vuqKfIr ds cnys esa vuqKfIr dh f}rh;d izfr visf{kr gks] rks vkosnd }kjk izi=
6 esa cU/k&i= fu"ikfnr fd;k tk;xkA
¼4½ vuqKfIr }kjk [kks;h gq;h ;k u"V gq;h vuqKfIr dh Hkh fjiksVZ Fkkus esa dh tk;xh vkSj dh xbZ
fjiksVZ dh ,d izfr vkosnu&i= ds lkFk layXu dh tk;xhA
¼5½ vkosnd] vuqKfIr dh f}rh;d izfr tkjh djus ds fy;s vuqKfIr izkf/kdkjh dks vkosnu&i= ds
lkFk ml vuqKfIr dks] tks QV x;k gks] fo:fir gks x;k gks ;k viBuh; [kks x;k gks vH;fiZr
djsxkA
¼6½ tc dksbZ vuqKfIr [kks tk; ;k u"V gks tk; rc vuqKfIr/kkjh rqjUr bl rF;] ftlesa vuqKfIr
dh la[;k vafdr dh tk;sxh dks fdlh egRoiw.kZ LFkkuh; lekpkj&i= esa ;k ;fn dksbZ LFkkuh;
lekpkj&i= u gks rks jkT; ds Hkhrj egOoiw.kZ lekpkj&i=ksa eas izdkf'kr djk;sxk vkSj
lekpkj&i= dh drju ftlesa mDr rF; izdkf’kr fd;k tk;] vuqKfIr dh f}rh; izfr fn;s
tkus ds vkosnu&i= ds lkFk layXu dh tk;sxhA
¼7½ vkosnu&i= izkIr gksus ij vuqKfIr izkf/kdkjh viuk lek/kku djus ds i’pkr~ fd fu;e 3 ds
mifu;e ¼1½] ¼2½] ¼3½] ¼4½ rFkk ¼5½ ;Fkk fLFkfr dh 'krsZ tgka rd os fopkjk/khu fof’k"V ekeys ij
ykxw gksrh gS] vkosnd }kjk iwjh dh tk pqdh gS] vuqKfIr dh f}rh; izfr tkjh djsxkA
¼8½ bl izdkj tkjh dh x;h vuqKfIr dh izR;sd f}rh; izfr esa ewy vuqKfIr ftldh ;g f}rh;d
izfr gks] dh la[;k vkSj fnukad mfYyf[kr gksxh vkSj mlds 'kh"kZ LFkku ij 'kCn f}rh;d izfr
vafdr fd;s tk;sxaAs
15- vuqKfIr dk fuyEcu ;k jÌ fd;k tkuk& ¼1½ fu;e 3 ds v/khu iznÙk vuqKfIr dks fuyafcr ;k jÌ
fd;k tk ldrk gS] ;fn vuqKfIr izkf/kdkjh dks ;g izrhr gks fd&
¼d½ /kkjk 7 dh mi&/kkjk ¼2½ esa mfYyf[kr dkj.kksa esa ls dksbZ fo|eku gksA
¼[k½ vuqKfIr/kkjh us dksYM LVksjst ij dCtk ;k fu;a=.k dks iw.kZr% ;k va’kr% vUrfjr dj fn;k gksA
¼x½ vuqKfIr/kkjh us dksYM LVksjst dk pykuk can dj fn;k gksA
¼2½ vf/kfu;e ds v/khu iznÙk vuqKfIr ds fuyEcu ;k jÌ fd;s tkus dh fLFkfr esa vuqKfIr/kkjh mlds
fy, fdlh izfrdj vFkok vuqKfIr ds fy, vius }kjk nh x;h Qhl okil ikus dk gdnkj ugha
gksxkA
16- u;k dksYM LVksjst fuekZ.k gsrq vuqKfIr&
¼1½ u;k dksYM LVksjst fuekZ.k gsrq fdlh bPNqd O;fDr dks vuqKfIr izkf/kdkjh ls blds fy, vuqKfIr
ysuh iM+sxhA
¼2½ u;k dksYM LVksjst fuekZ.k gsrq vuqKfIr izkf/kdkjh dks vkosnu&i= izi=&7 esa nks izfr;ksa esa nsuk
gksxk ftlij lE;d :i ls vkosnd ds gLrk{kj gksaxsA
¼3½ mi&fu;e ¼2½ ds v/khu fn;s x;s fdlh vkosnu&i= ds lkFk ekSfyd pkyku dh izfr layXu gksxh
ftlesa mi&fu;e ¼4½ esa fofufnZ"V u;s dksYM&LVksjst ds fuekZ.k gsrq vuqKfIr Qhl dk mYys[k
fu;e 5 ds mi&fu;e ¼3½ esa of.kZr 'kh"kZ ds v/khu jgsxkA

<!-- page 7 -->

¼4½ mi&fu;e ¼5½ esa mfYyf[kr vkosndksa ls fHkUu ls fuEukafdr vuqKfIr Qhl yh tk;xhA

¼5½ jkT; ljdkj ds LokfeRok/khu vFkok izcU/kuk/khu dksYM LVksjst ls dksYM LVksjst fuekZ.k gsrq dksbZ
vuqKfIr Qhl ugha yh tk;sxhA
¼6½ fuekZ.k gsrq vuqKfIr iznku djrs le; vuqKfIr izkf/kdkjh izLrkfor {ks= esa dk;Zjr dksYM LVksjst
dh la[;k] d`f"k mRikn dh miyC/krk vkSj dksbZ vU; foUnq tks vuqKfIr izkf/kdkjh vko’;d le>s]
ij fopkj djsxkA
¼7½ vuqKfIr iznku djrs le; vuqKfIr&izkf/kdkjh dksbZ Hkh ,slh 'krZ yxk ldrk gS] ftls og
vko’;d le>sA
17- lykgdkj i"kZn~ dk xBu&jkT; ljdkj vf/klwpuk }kjk /kkjk 3 ds vuqlkj dksYM LVksjst
lykgdkj i"kZn~ dk xBu djsxhA
ijUrq ;g fd jkT; ljdkj }kjk fcgkj fo/kku ijf"kn~ ds ,d lnL; dks Hkh fo’ks"k vkeaf=r lnL;
ds :i esa euksuhr fd;k tk ldrk gSA
18- lykgdkj i"kZn~ ds d`R; ,oa dk;Z& i"kZn~ ds d`R; rFkk dk;Z vf/kfu;e dh /kkjk 4 esa
;FkkfofufnZ"V gSA
19- HkaMkj.k fd;s x;s eky dh ;qfDr;qDr ns[k&Hkky%& izR;sd vuqKfIr/kkjh HkaMkj.k fd;s x;s eky dh
;qfDr&eqDr ns[k&Hkky /kkjk 12 ds vuqlkj djrs gq, fuEu ckrksa dk Hkh ikyu djsxkA
¼1½ eky [kjkc u gksus ikosaA
¼2½ ifjfLFkfr vU; dkj.kksa ls eky dks [kjkc u gksus nsus ds fy, lkekU; cqf) ds O;fDr tSlk
dk;Z djsx
a As
20- lwpuk dk izn’kZu&izR;sd vuqKfIr/kkjh /kkjk 13 esa micaf/kr jhfr ls lwpuk dk izn’kZu djrs gq,
fuEufyf[kr ckrksa dk Hkh /;ku j[ksxk%&
¼1½ lwpuk lnSo iBuh; gksxhA
¼2½ fjDr LFkku dk izn’kZu vko’;d :i ls djsxAsa
21- HkaMkj.k ds fy, eky Lohdkj djuk& vuqKfIr/kkjh tek djus gsrq /kkjk 14 ds vuqlkj eky Lohdkj
djus ds vykok fuEufyf[kr ckrksa ij /;ku nsx%sa &
¼1½ HkaMkj.k djus ds fy, Lohd`r eky HkaMkfjr eky dks {kfr u igqapkosaA
¼2½ fookn mBus ij vuqKfIr izkf/kdkjh dk fu.kZ; vafre gksxkA
22- LFkku dk vkj{k.k &
¼1½ fdlh dksYM LVksjst dh iw.kZ {kerk ds ipkl izfr’kr rd dk gh vkj{k.k fd;k tk ldrk gS vkSj
,slk vkj{k.k 31 tuojh rd gh fd;k tk ldsxkA
¼2½ vkj{k.k ds fy, fu/kkZfjr fdjk;k dk ¼10%½ vfxze nsuk vfuok;Z gksxkA
¼3½ ;fn vkjf{kr djk;s x;s LFkku dk mi;ksx vkj{k.k djkus okys O;fDr }kjk 15 ¼iUnzg½ ekpZ rd
ugh fd;k tkrk gS oSlh fLFkfr esa vkj{k.k Lor% jÌ le>k tk;sxk vkSj nh x;h vfxze jkf’k okil
ysus dk gdnkj ugha jgsxkA
