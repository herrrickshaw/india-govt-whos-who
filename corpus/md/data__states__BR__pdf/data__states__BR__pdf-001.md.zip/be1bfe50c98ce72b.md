---
doc_id: "be1bfe50c98ce72b"
source_url: "https://bceceboard.bihar.gov.in/pdf_Tender/ADV_TEN25_01.pdf"
ministry: "Bihar Combined Entrance Competitive Examination Board (BCECEB)"
title: "Details of Short Tender Notice Regarding Auction of Old and Damage Boxes (Tender No.BCECEB(TEN)2025/01 Dated 15.01.2025)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9b27ccf16062e42e"
---

<!-- page 1 -->

800014
Website : bceceboard.bihar.gov.in / Helpdesk : helpdesk.bceceboard@bihar.gov.in

2025/01

- 15.01.2025

(As is where is)
11.02.2025

(i) Technical Bid
(i) Technical Bid

(ii) Financial Bid
GST Registration,

"Technical Bid"
Superscribed
(ii) Financial Bid
"Financial Bid"
Superscribed
i.
Technical Bid
Financial Bid
"Bid for Advertisement No. and Name" Superscribed
ii.
"Technical Bid"

(iii)

"Technical Bid"
Financial Bid

(iv)

Security Money

Individual

08.02.2025 5.00
11.02.2025
2.00

4.00
Financial Bid

Technical Bid Qualify
goods
