---
doc_id: "dbff7deb1b462c0d"
source_url: "https://bceceboard.bihar.gov.in/pdf_Adv/ADV_UGMAC26_12.pdf"
ministry: "Bihar Combined Entrance Competitive Examination Board (BCECEB)"
title: "Corrigendum for Online Registraion and Choice filling for UGMAC-2026 Round-3 (Adv. No. BCECEB(UGMAC)-2026/12 Dated 03.10.2026)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bc76e6177ab33178"
---

<!-- page 1 -->

GOVT. OF BIHAR

BIHAR COMBINED ENTRANCE COMPETITIVE EXAMINATION BOARD
I.A.S. Association Building, Near Patna Airport, Patna-14.

Website : bceceboard.bihar.gov.in / Helpdesk : helpdesk.bceceboard@bihar.gov.in

UNDER GRADUATE MEDICAL ADMISSION COUNSELLING (UGMAC)-2026
for MBBS/ BDS/ B.V.Sc. & A.H. / B.F.Sc. in Govt. Medical / Dental / Veterinary Colleges
/ College of Fisheries and Private Medical / Dental Colleges of Bihar
Adv. No.- BCECEB(UGMAC)-2026/12 Dated : 03.10.2026

Corrigendum for Round-3 Online Application & Choice Filling
In continuation to Adv. No. BCECEB(UGMAC)-2026/09 dated 30.09.2026, it is informed to all eligible & interested NEET(UG)-2026
qualified candidates and all concerned that due to typographical mistake, some error in Heading of column 2 & 3 of Point No. 9.iv(b).
occurred which has been corrected. Corrected point no. 9.(iv) be read as follows;
"9.(iv) Step-Four (Payment of Counselling Fee & Security Deposit):
After clicking “Final Submit & Proceed to Payment” button, complete the payment procedure according to instructions appeared on
the computer screen regarding payment of Counselling Fee & Security Deposit. Paid Counselling Fee is not refundable.
Online Payment: Candidate will have to pay the Counselling Fee & Security Deposit through Online mode only i.e. Debit Card /
Credit Card / Net banking / UPI, the candidate has to pay processing charge additional to Counselling Fee & Security Deposit for
payment through online mode.
(a) Candidate has to pay Rs. 1200/- (One Thousand Two Hundred Only) for UNRESERVED / EWS / BC / EBC category and Rs. 600/- (Six
Hundred) only for SC / ST / DQ (of any category) candidates as non-refundable registration / counselling fee through online mode only
e.g. by Credit card/Debit Card/ Net Banking / UPI. But in case of Pvt. Colleges, all candidates have to pay Rs.1200/- only as nonrefundable Registration & Counselling Fee.
Sl. N. Institution/College Type
UR/ EWS/ BC/ EBC
SC/ ST/ DQ
Category
Category
i. Government Medical / Dental / Veterinary/ Fisheries College
Rs. 1200/Rs. 600/ii. Private Medical College
Rs. 1200/Rs. 1200/iii. Private Dental College
Rs. 1200/Rs. 1200/iv. Both (Private Medical & Dental) Colleges
Rs. 1200/Rs. 1200/v. Both (Government Medical / Dental / Veterinary/ Fisheries & Private
Medical) Colleges
Rs. 1200/Rs. 1200/vi. Both (Government Medical / Dental / Veterinary/ Fisheries & Private
Dental) Colleges
Rs. 1200/Rs. 1200/vii. Both (Government Medical / Dental / Veterinary/ Fisheries & Private
Medical / Dental) Colleges
Rs. 1200/Rs. 1200/viii. Government Veterinary / Fisheries Colleges
Rs. 1200/Rs. 600/(b) The details of payment of security deposit for Govt. / Pvt. Medical Colleges/ Dental Colleges/Veterinary/ Fisheries colleges will be as
follows;
Sl. N. Institution/College Type
UR/ EWS
SC/ ST/ BC/ EBC/
Category
Category
i. Government Medical / Dental / Veterinary/ Fisheries College
Rs. 10,000/Rs. 5,000/ii. Private Medical College
Rs. 2,00,000/Rs. 2,00,000/iii. Private Dental College
Rs. 50,000/Rs. 50,000/iv. Both (Private Medical & Dental) Colleges
Rs. 2,00,000/Rs. 2,00,000/v. Both (Government Medical / Dental / Veterinary/ Fisheries & Private
Medical) Colleges
Rs. 2,00,000/Rs. 2,00,000/vi. Both (Government Medical / Dental / Veterinary/ Fisheries & Private
Dental) Colleges
Rs. 50,000/Rs. 50,000/vii. Both (Government Medical / Dental / Veterinary/ Fisheries & Private
Medical / Dental) Colleges
Rs. 2,00,000/Rs. 2,00,000/viii. Government Veterinary / Fisheries Colleges
Rs. 10,000/Rs. 5,000/Note: In case of Security Deposit paid as mentioned in above Serial No. (i) & (viii), if candidates want to take admission
under Self-Financed Seats of B.V.Sc.&A.H. / B.F.Sc. courses will have to pay the security deposit amount of Rs. 50,000/-.
As per above table, the candidate has to pay the refundable security deposit, if applicable, through online mode only e.g.
by Credit card / Debit Card / Net Banking / UPI at the time of Online Registration & Submission of Application-cum-Choice
filling. The candidate has also to pay processing charge in addition to Counselling Fee & Security Deposit for payment through
online mode.
Note: (i) If the amount paid as Counselling Fee & Security Deposit is debited from your account but the fee transaction fails, then in
such case you must re-pay the desired full fee and ensure the payment. If your required Counselling fee & Security Deposit do
not reflect in Board’s account within the due date, your application form will remain incomplete and will be rejected due to
which will not be eligible for participating in the counselling process.
Your failed transaction will be refunded to your account in due course.
(ii) Any queries regarding failure of Counselling fee & Security Deposit you may contact (1) In case of payment through Billdesk
to bangalorepgsd@billdesk.com or (2) In case of Payment through ICICI Bank to cmssupport@icici.bank.in, available on
online application portal or helpdesk phone number 0612-2220230.
2. Rest of the terms / conditions of the Advertisement No.- BCECEB(UGMAC)-2026/09 Dated 30.09.2026 and 2026/11 Dated 02.10.2026
will remain same.
Controller of Examination
