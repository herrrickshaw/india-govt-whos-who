---
doc_id: "bdfb27aec2a225a0"
source_url: "https://tourism.bihar.gov.in/content/dam/bihar-tourism/catalogue/bihar-tourism-policy-guidelines-2024.pdf"
ministry: "Bhagalpur"
title: "Bihar Tourism Policy Guidelines 2024"
date: ""
pages: 42
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "e476a63cca8dddb7"
---

<!-- page 1 -->

Government of Bihar
Department of Tourism
Notification
No.- Tour dept/ estd.- 3/4 part-ll, Patna/Date-
Sub. :- Bihar Tourism policy Guidelines — 2024.
Tourism department has formulated Bihar Tourism policy guidelines -2024 to implement
Bihar Tourism Policy-2023. It aims to develop tourism sector in Bihar through joint and
collaborative approach.
4. Introduction
Department of Tourism, Government of Bihar has announced the Bihar Tourism Policy 2023,
vide Government Order No. 2825 Dated: 27.2.2023. The policy focuses on developing various
tourism projects and tourism related services by facilitating the private sector and local
entrepreneurs through Ease of Doing Business, Single Window Clearances System and availing
various attractive incentives and subsidies.
The policy shall remain operational for five years from the date of approval. It is a
comprehensive forward-looking policy to assist and encourage tourism development in the
state.
These guidelines have been prepared and issued by Department of Tourism, Government of
Bihar as per Section 8.2 of the Bihar Tourism Policy 2023. These guidelines aim to achieve the
goals and objectives of the Policy.
The guidelines have been framed with the following objectives:
» Detailing the requirements/criteria for approval of tourism units as per the Bihar Tourism
Policy 2023
» Detailing the procedures to be followed to claim incentives, subsidies for eligible projects,
disbursements of claims applicable to Tourism Units.
2. Eligible Tourism Projects
The policy has identified tourism projects which will be eligible for grant of Fiscal Incentives and
Non-fiscal incentives as per the terms and conditions laid down in these guidelines. The eligible
Tourism Project categories are as follows:
i | New Hotels/ Resorts/ Heritage Hotels (For 4-star and above category properties)
हे Renovation/ Modification/ Extension of existing Hotels and Resorts to 4-star and above
category properties
3 | Convention Center (MICE)
| 4 | Wayside Amenities — New development
5 | Wayside Amenities — Up-gradation of existing facilities
4

<!-- page 2 -->

[6 | Fixed Tented Accommodation/ Camping sites
Adventure Tourism Project
|
9
0
| Theme Park
42 | Amusement Park
EPIC SUL
a. Approved Project Cost — shall mean the cost of the project approved by Department of
Tourism after evaluation of the proposal as per the terms and conditions laid down in these
guidelines.
The Approved Project Cost shall be based on eligible cost components. All cost items which
are not eligible under this policy shall not be considered for the calculation of Approved
Project Cost.
For a project to be eligible for release of capital subsidy/ Interest subvention, the Approved
Project Cost after financial clearance stage and Verified Project Cost after physical
verification stage must be equal to or more than Minimum Project Cost.
b. Capital Investment: Means the total eligible investment in the project collectively from all
sources as prescribed in these Guidelines. The inclusions and exclusions are as given below:
i. Eligible Cost - Cost incurred on the following components shall be considered eligible
for Capital subsidy/ Interest subvention:
e Land development charges(capped at 2.5% of the final Approved Project Cost)
e Land registration charges
¢ Building construction (boundary wall, landscaping, and any other project specific
construction)
e Plant and machinery
e Project Equipment
e Interior Furnishing
e Electrical Installation
e Furniture and fixtures
e Kitchen equipment
2

<!-- page 3 -->

¢ Sewage treatment plant (STP), Effluent treatment plant (ETP) or Air treatment plant
(ATP)

e Generator and AC plant/ AC unit

e Sanitary fittings

e Others, as notified by Department of Tourism

ii. Non eligible Cost - Cost incurred on following shall not be considered eligible for Capital
Investment subsidy:
© Cost of land
e Land Lease cost
© Rent of premises
© Working Capital
e Goodwill
e Manpower cost
e Commissioning fees
© Royalty
e Pre-operative expenses
e Secondhand plant and machinery, furniture, fixtures, electrical installation etc.

Note: The list given above is indicative in nature. Department of Tourism shall have the

discretion to permit, reject or suggest revisions to project cost components.

c. Disbursement Agency (DA): Directorate of Tourism, Government of Bihar shall be the DA to
disburse incentives / subsidies / claim.

d. Differently abled Friendly: means all tourism units shall cater to the needs of the disabled,
as by offering wheelchair access

e. Eligible Tourism Project: means a project (new or expansion) which meets all eligibility
criteria defined for its category under this policy and is approved during the operative
period of the policy. To be eligible for incentives, the Tourism unit must be registered with
the Department of Tourism.

f. Eligibility for Incentives: The eligibility for incentives is as follows:

. Projects that have commenced commercial operation during the policy period with
prior Stage Clearance shall be eligible for ‘Capital Subsidy/ Interest Subvention’ and
‘Other Fiscal incentives’ available under the Policy.

2. Projects which have commenced commercial operations during the policy period
without taking prior Stage 2 clearance shall be eligible for ‘Other Fiscal Incentives’ only.
The ‘Other Fiscal Incentives’ shall be subject to the applicant obtaining all necessary
approvals specified in these guidelines.

3. Projects which have obtained Stage clearance and Financial Clearance during the
policy period and have commenced operations after the policy period shall be eligible
for all policy incentives subject to the applicant obtaining other necessary approvals

3

<!-- page 4 -->

specified in these guidelines. The incentives shall be available for a maximum period of 5
years from the date of commencement of commercial operation.

4. Projects that have commenced operations prior to policy period shall be ineligible for
incentives under this policy

g. Expansion of Tourism Project: Any existing project/ facility intending to be redeveloped/
modified/ upgraded/ renovated to attain the requirement specified for eligible tourism
project.

Note:

4. Unless specified, the Approved Project Cost of expansion must be equal to or more than
50% of Minimum Project Cost specified for New Projects in the intended project
category.

2. Expansion Projects shall not be applicable in the following Project categories:

|. Caravan Tourism
ll. High end Tourist buses and Vans
h. Financial Institutions: Commercial Banks and other financial institutions recognized by
Reserve Bank of India/ Government of India
i. Fiscal Incentives: Fiscal incentives refer to the “monetary benefits” offered to the tourism
units under this policy. Under this policy the fiscal incentives are available as follows:

I. Capital Subsidy/ Interest Subvention

Il. Other Fiscal Incentives

j- Guidelines/ Policy guidelines — Bihar Tourism Policy Guidelines 2024

k. Minimum Project Cost: The minimum cost of the project laid down for each project
category. For a project to be eligible, the Approved Project cost and Verified Project Cost
must be equal to or more than Minimum Project Cost.

I. New Tourism Projects: All eligible tourism projects/units approved by the authority and
established during the Operative Period of the Policy.

m. Non fiscal incentives: Non fiscal incentives refer to the “non-monetary benefits” offered to
the tourism units under this policy

n. Policy — Bihar Tourism Policy 2023

०. Registered Office— To be eligible for incentives under this Policy, the applicant must have a
registered Office in State of Bihar.

4

<!-- page 5 -->

p. Stamp Duty: Means the duty defined as stamp duty payable under The Indian Stamp Act

899 (as applicable to the State of Bihar)

q- Subsidy: Financial assistance granted by the Government of Bihar, Government of India, or
its departments under various expense components for tourism

tr. SGST: State Goods and Services Tax

s. Verified Project Cost - The cost of the project approved by Department of Tourism after
final verification of the project as per the terms and conditions laid down in these
guidelines. For a project to be eligible for subsidy disbursement, the Verified Project Cost
must be equal to or more than Minimum Project Cost.

CoA Munsee amet aedltay

|. Hotels/ Resorts/ Heritage Hotels(for 4-star and above category properties) - New Projects
in Bihar approved during the operative period of the Policy with a Minimum Project Cost of
INR 0.00 Cr. To be eligible, these properties must secure and retain4-star or above
category certification as per the Guidelines issued by Ministry of Tourism, Government of
India.

Il. Renovation/ Modification/ Extension of existing Hotels and Resorts to 4-star and above
category properties: Hotels/ Resorts/ heritage Hotel projects in Bihar, undertaking
expansion with a Minimum Project Cost of INR 2.50 Crore. Such projects must be approved
during the operative period of the Policy. To be eligible, the existing property undergoing
expansion must secure and retain 4-star or above category certification as per the
Guidelines issued by Ministry of Tourism, Government of India.

a. Hotels: Under this policy, Hotels must fulfill Ministry of Tourism, Government of India’s
Star classification criteria of 4-star or above category hotel.

b, Resorts: Under this policy, Resorts must fulfill Ministry of Tourism, Government of India’s
Star classification criteria of 4-star or above category hotel and fulfill the following
additional requirements:

fea Mandatory/
No Mandatory Desirable
4 | The plot on which a resort is located should admeasure at least
Mandatory
2.50 Acre
2 | Minimum 20 lettable rooms with minimum carpet area 350 sqft. |
|. हे Mandatory |
eee गण किक including attached bathrooms
ee
| |
3 Swimming Pool of minimum area 650 square feet Mandatory
5

<!-- page 6 -->

4 Located near and around Riverside, lakes, hills, forest, water body Destrabl
or similar tourist attraction cap
5 | Offer at least one facility connected with the location that helps to ॥
attract tourists

c. Heritage Hotels: shall mean hotels located in places that capitalize on its connection with

heritage structures like fort, fortress, palace, haveli, castle, hunting lodge or residence

with heritage features which were built prior to January 950 and approved by the

Ministry of Tourism, Government of India. Such Heritage Hotels must obtain necessary

category certification from the competent authority. The facade, architectural features

and general construction should have the distinctive qualities and ambience in keeping

with the traditional way of life of the area. Heritage Hotels must fulfill the following

requirements to be eligible under this policy.

i. Heritage Basic as per guidelines of Ministry of Tourism, Govt. of India. The guidelines
prescribe that minimum 50% of the floor area was built before 950.

2. It should have minimum 40 lettable rooms with attached furnished bathrooms and
dining, catering, and common seating facilities.

Ml. Convention Center (MICE): Convention Center shall mean a project (new or expansion),
approved within the operative period of the policy. The Minimum Project Cost of new
projects under this category is INR 0.00 Cr. The convention center must maintain standards
laid down for Three (3) Star or above category hotels (as per Star Rating guidelines of
Ministry of Tourism, Govt. of India) for the facilities developed and services provided. The
minimum requirements are as given below:

i. It should be located on a plot admeasuring at least 4,000 square meters

2. The ground coverage should not exceed 40%

3. It should have a main pillarless hall with minimum seating capacity of 500 pax.

4. Atleast Two Mini Convention Hall with minimum seating capacity of I00 pax.

5. The capacity should be so organized that it is possible for at least 3 separate
conferences or events to run simultaneously.

6. The conference/convention units should have adequate acoustic facility.

7. It should have a restaurant, cafeteria of adequately covered and comfortable area to
cater to at least 500 persons simultaneously.

8. An Exhibition Center having capacity to accommodate at least 30 booths of 3 mtrs by 3
mtrsin size excluding passages in between the booths.

9. It should becentrally air- conditioned.

0. It should have a vehicle parking facility for not less than two hundred cars and five
coaches/buses.

l. All conference/convention areas should be equipped with modern audio-visual
conferencing equipment, sound and light systems, public address system, slide
projection, video screening and such other facilities. It should possess its own
equipment.

6

<!-- page 7 -->

42. ॥ 5000 ॥7ए५९ 8 and E-Mail, Wi-Fi, and photocopying facility. The quantum of such
facility should be consistent with convention complex size.
3.In addition to above facilities convention Center should include the following
infrastructural facilities:
i. Landscape forefront
ii. Exhibition Management Center
iii. | Administrative facilities for corporate
iv. Trade show/Fair Facilities, High Speed Internet, Press Lounge, VIP Lounges etc.
v. Technical facilities such as plant room, stores, electric power back-up system, fire
hydrant etc.
vi. | Gate complex for stipulating entry and exit.
vii. Information booths
viii. | Public Convenience
ix. First aid with doctor on call facilities
x. Security office and booths for security arrangements.
xi. Fire safety arrangements
xii. Locker facilities
xiii. | Mini Business Center with computer, internet, photocopy facility and stationery
material.

IV. Wayside Amenities: Way Side amenities located on National Highways, state Highways or
district major roads or at locations within 00 meters of these roads with access and clear
visibility will be the center for common facilities.

It should have following minimum facilities:
4. Car/Tourist coach/ Bus parking
2. Food plaza/restaurant
3. Separate ladies & gents’ toilet and washroom with special facilities for differently abled
4. First Aid facility/Telecommunication facility.
6. 24X7 Water & Electric supply
|. Wayside Amenities - New development: This will cover a new Wayside Amenity with a
Minimum Project cost of INR .50 Crore.
ll. Wayside Amenities — Up-gradation of existing facilities: This shall mean up-gradation of
existing facility to a Wayside Amenity with a Minimum Project Cost of INR 0.75 Cr.

V. Fixed Tented Accommodation / Camping sites: “Tented Accommodation” means a project
(new or expansion), approved within the operative period of the policy. The Minimum
Project Cost of new projects in this category is INR .00 Crore.

The project must comply with the standards as per latest guidelines issued for
“Classification of Tented Accommodation” by the Ministry of Tourism, Government of India.
All Such Tented Accommodation(s) must obtain Standard or Deluxe category certification
from the Ministry of Tourism, Government of India.

zi

<!-- page 8 -->

The tented accommodation should have minimum 40 |ॉका)र९ पैशा$ शांत an

accommodation capacity for at least 20 persons. All the tents should have attached toilets.

The tents should be put on a platform raised to a minimum of 2 inches above the ground.

The facility should have adequate security.

These facilities must remain operational for a minimum period of ninety days every year

from the Date of Commencement of Commercial Operations.

VI. Adventure Tourism Project: “Adventure Tourism” project shall mean a project (new or
expansion), approved within the operative period of the policy. The Minimum Project
Cost of new projects in this category must be INR 5.00 Crore.

Such a project should have the entire technical apparatus, safety equipment, trained

manpower and other arrangements for all the proposed activities within the project

and activities must be conducted in accordance with the norms laid down by Ministry
of Tourism/ Adventure Tour Operators Association of India (ATOAI)/ any other
agency accredited by Government of India. Adventure Tourism projects shall be
permissible for operators registered with Ministry of Tourism as an Adventure Tour

Operator and may include activities under below mentioned three categories:

= Land-Based Adventure Tourism

= Water-Based Adventure Tourism

= Air-Based Adventure Tourism

Vil. Eco- Tourism Project: “Eco-Tourism” project shall mean a project (new or expansion),
approved within the operative period of the policy. The Minimum Project Cost of new
projects in this category must be INR 5.00 Crore.

Project Requirements:

i. The proposed ecotourism activities will be in strict conformance with the provisions
of the existing environmental/ Forest and wildlife law of the country, especially the
Indian Forest Act 927, Wildlife (Protection) Act 972, the Forest (Conservation)
Act, 980 and the various other directives and guidelines issued by the Government
from time to time.

2. The Entity would need to conduct carrying capacity of the proposed site to arrive at
the types and level of tourism related activity that the proposed site can sustainably
accommodate.

3. Priority will be given to developing sites near existing and known tourist
destinations.

4. The proposed project will focus on creating environmental awareness amongst all
sections and age groups, especially the youth, to be incorporated as a major activity
for each ecotourism destination.

5. The proposal should focus on providing quality experience rather than the number
of visitors, without compromising on financial viability as far as possible. Wherever
resources harnessed for ecotourism are traditionally in use by the local community,

8

<!-- page 9 -->

the proposal should be developed in consultation with them and mechanisms to
ensure flow of benefits to the community should be clearly identified.

6. Ecotourism activities to be identified and developed at any destination shall be site-
specific ie., dependent upon the potential of the site being developed which may
include Buffer zones of forest reserves, lakes, hills, bird sanctuaries etc.

7. Following are the activities and facilities that may be undertaken for promoting an
area as an ecotourism destination within the State:

I. Nature Camps
Il. Eco-friendly Accommodation:
I. Trekking and Nature Walks
IV. River Cruise
Vv. Adventure Sports
Vi. Visitor Interpretation Centers
Vil. Other Facilities that align with Eco Tourism
Vill. Wellness Tourism Resort/ Centers: “Wellness Tourism Resort” project shall mean a
project (new or expansion) approved within the operative period of the policy. The

Minimum Project Cost of new projects in this category must be INR 0.00 Crore.

Wellness centers aim to revive energy, provide a platform for personal introspection,

promote positive health, treat diseases by providing different services such as spa,

yoga, meditation, skin care treatment etc.

The Wellness Tourism Resort/ Center shall provide the following facilities:

4,  Certified/licensed medicinal facilities

2. Well-trained Yoga, Naturopathy, Ayurveda teacher with relevant certifications.

3. Minimum 20rooms of specifications and quality equivalent to three star or

above categories of hotels specified by Ministry of Tourism, Government of India

4. There shall be at least one specialty dining room which are well-equipped, well-

furnished, and well-maintained, serving high quality cuisine.

5. The kitchen and pantry shall be professionally designed to ensure efficiency of

operation and shall be well-equipped, well-maintained, clean, and hygienic.
6. Adequate parking facilities
IX. River/ Reservoir/ Lake based Tourism Project: “River/ Reservoir/ Lake based Tourism”
project shall mean a project (new or expansion) approved within the operative period
of the policy. The Minimum Project Cost of new projects in this category must be INR
2.00 Crore. This project category shall cover the following facilities:
|. Water Ride/Sailing facilities: Water based transport facilities to be used for the
movement of tourists to visit local places and enjoy local scenery through modes such as
sail boats, house boats, glass bottom boats, amphibious hovercraft etc. Any facility
should have a minimum seating capacity for 4 tourists.
9

<!-- page 10 -->

Note: The Water Ride/ Sailing facilities should be for tourism purpose and not be used
for regular ferrying of passengers. Boats/Yachts used for regular ferrying of passengers/
transport of goods or raw materials will not be covered under this definition.
ll. Cruise facilities: Reservoir, Dam, Lake, or river cruises for pleasure spanning a few
hours and up to a few days.
Project Requirements:
. Capacity to host a minimum of 25 passengers+ Crew members.
2. Facilities for on-board dining and entertainment.
For both the project categories, the following additional points are applicable:
e Security and safety amenities prescribed by the regulatory authorities and guidelines of
Govt. of India and Govt. of Bihar shall be maintained by the operators.
e Operators must be registered with regulatory authority as decided by the State
Government and comply with regulations of Govt. of India and Govt. of Bihar.
e The equipment may be manufactured or assembled outside Bihar but must be
registered in Bihar with appropriate authority where applicable.
X. Theme Park
“Theme Park” project shall mean a project (new or expansion) approved within the
operative period of the policy. The Minimum Project Cost of new projects under this
category must be INR 0.00 Crore.
The theme shall be the main part of the visitors’ experience chosen when the park is
planned to provide a focus for the design, development, and operation.
Theme parks must provide a mix of facilities such as rides, games and entertainment,
live performances, food, and beverage, retailing and relaxation and must ensure that
the environment is designed around the key theme. The Theme Park projects must
have basic amenities for tourists such as Digital Payment Facility, Information booths,
Medical Emergency Services, Adequate parking facility, Adequate Toilets, Baby feeding
room, Drinking water facility, and Solid and liquid waste management facility.
The following themes have been identified for the development of Theme Parks in the
State:
= Adventure - Excitement and action, Frightening, Mysterious, Thrill rides
" Futurism- Advances in society and technology, Discovery, Exploration of science and
technology, Robotics, Scientific, Science fiction
= International - Flavors of the world, international village, Miniature replicas, Scenic
spots, World expositions
= Nature — Animals, Floral displays, Horticultural gardens, Landscaping, Marine life,
Natural wonders, Ocean, Wildlife
"Fantasy — Animation, Cartoon characters, Childhood enchantment, Children’s play
park, Fairy tales, Magic, Make believe, Myths and legends.
20
