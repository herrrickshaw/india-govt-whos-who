---
doc_id: "3edac8ecdab6f4d5"
source_url: "https://bsrdcl.bihar.gov.in/Document/20261030120003438Corrigendum.pdf"
ministry: "Bihar State Road Development Corporation Ltd (BSRDCL)"
title: "Download"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "cf2bb83b2ede84ca"
---

<!-- page 1 -->

n nm
|[* | हा oO
०
ए- & ४0०७ न्प =
हरित [Bee] eB | 8 2 gS &
3 B) 2 | ४
B) ० ४8 ए०एछ | | 6६8. छः हु
g jess) se व 6 g 7
g) alese}e | z |B 5 3
5 2 8,
Be) eae 2|8 |@ s w
Elgg g &
s| & विलय (कि है ् Zl g
g % lems] 2 at g 6 td
S| oo RR) & ays n a
2) 2) sel 5 छह ai |
8 @ a8| 2 SJElLS 68 c a
3} 2] Sela है किये 45 डर
al @ ool हे | छः wn
Bl of SB] & 8 a S
=| =| SF a a 5 2 S
g| हू 3] 3, So Ss e
BS. 5 p S > 8 $
e| 8 w | ow
5 हैः दि moe प्र हे >
2| 8 8 426 c 5 =
2 a2 g
ढ़ हक ae 8
2 © 02 gq 9 s s
3 res 2 PD
ms o 5
ढ़ 5 ct
2] | Be 5 &
98 Seon g o
8 a |es) | zee g2
| 5 wo w lO om o = © oe wa
| ड़ 35 Sie BS 4 8 Ss °
| iQ Sle lgalesle| Fs BB
| 28/5 |s |g2les|s| Ba > Eis o
| ES & & Gol|Z/3 | Bw o io gee m
| ee) S [|S yesteeia/ee2 [S229
Bo 299 858०0 7 es S539
| BE) s/s lfecje|Cee? हि [Sieg
छः 8 Ss —lo ola 2
| ze|& |S |ecesie|/Pes 6 sig 5
| Be) 2 |) 2 |essse/FsR |e sS2g
| & S Ss |2S|§ oa] hes = Suro
| ८8 है 5 हिंद है | 359 हि दर
5 e |e |ag les = 6 g
Fel e [2 |Payrsie| see Is bigs
| 8 6? | 4 be lig & Sew ole
| हे ठ 438 छह छः gz
| 5 To ASE O
| 5 | gaz o
| 5} | Ree e389
So? ss 6
Q a= 4 Re
z Bw oe gs &
5 y ama 8 s&s
3 3 oF §& &.
an. 8 ap & > 5
ore ४8४ 7 g z
a ~ 8० 7 हे
xy = g ip oat Ez # re
5] प्‌ _ Oo lo# 9 छः ७
» : e O° 5S S pp 8 ime
4 mb] FE 85 850 डे & 3
3 3/5 > किए है हु 8 [3 & 5
x 28] ; Bj@fies/2) 8 5 me
दि 8 3 3 80 55254 | ७ 8 yo $ ¢
de BB Ss 8 68७6858| 5 हो 5 = s @&
3 a a Sle =la|— Zz 8 = Se
ga} 2 |e |pals= P *
Bw os so Sp a 3 g
BB) 8 |S [seizes g 9
छ छ Ss Belogle s
BO = = Yrs S| oe w 8
B2 | 2 | a |wsless प्र a
a 3 & /gcljer;a 0 '
8० छठ छठ Bz is = e
28) 2 |e |Se leslie & u
Pe] 2B |e [Rar ey 8 ढ़ 2
&] a a [é Bo o :
& =
a 8 igs Q °
6 5 5 :
oe a e
§ EJ
a x
