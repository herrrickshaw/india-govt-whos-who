---
doc_id: "3bff724b3f0ef4bd"
source_url: "https://bsea.bihar.gov.in/PDF/Act/Rules_BSEA_2008_Hindi.pdf"
ministry: "Bihar State Election Authority (BSEA)"
title: "बिहार रा़ज्य निर्वाचन प्राधिकार नियमावली, 2008"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c9ac0bdcd144eb83"
---

<!-- page 1 -->

fuca/u la0 ih0 Vh0 & 40

fcgkj ljdkj
vlk/kj.k vad

fcgkj ljdkj }kjk izdkf'kr
(laú iVuk 326)

23 oS'kk[k 1930 ('kú)
iVuk] eaxyokj 13 ebZ 2008
dkfeZd ,oa iz'kklfud lq/kj foHkkx
vf/lwpuk,a
13 ebZ] 2008

laú&3@,eú&48@2008@2796dkú&fcgkj jkT; fuokZpu izkf/dkj vf/fu;e] 2008 (fcgkj vf/fu;e 14]
2008) dh /kjk&16 dh mi&/kjk (1) esa iznÙk 'kfDr;ksa ds v/hu jkT; ljdkj fuEufyf[kr fu;ekoyh cukrh gS&

vè;k;&1
izkjfEHkd
1- laf{kIr uke] foLrkj ,oa izkjEHk &(1) ;g fu;ekoyh ^^fcgkj jkT; fuokZpu izkf/dkj fu;ekoyh] 2008** dgh
tk ldsxhA
(2) bldk foLrkj lEiw.kZ fcgkj jkT; esa gksxkA
(3) ;g rqjar ds izHkko ls izo`Ùk gksxhA
2- ifjHkk"kk,a & bl fu;ekoyh esa tcrd lanHkZ esa vU;Fkk visf{kr u gks&
(i) ^fuokZpu inkf/dkjh* ls vfHkizsr gS fuokZpu djkus ds fy, izkf/dkj }kjk izkf/d`r dksbZ inkf/dkjh_
(ii) ^izkf/dkj* ls vfHkizsr gS fcgkj jkT; fuokZpu izkf/dkj rFkk
(iii) blesa iz;qDr fdUrq vifjHkkf"kr 'kCnksa ,oa inksa ds ogh vFkZ gksaxs tks muds fy, fcgkj jkT; fuokZpu
izkf/dkj vf/fu;e] 2008 (fcgkj vf/fu;e 14] 2008) esa leuqnsf'kr fd;s x;s gSaA

<!-- page 2 -->

2

fcgkj xtV (vlk/kj.k)] 13 ebZ] 2008

vè;k;&2
fuokZpu izkf/dkj dh dk;Z izfØ;k
3- fuokZpu izkf/dkj ds d`R; ,oa 'kfDr &jkT; fuokZpu izkf/dkj dk dk;Z fcgkj vf/fu;e 14] 2008 dh
/kjk&4 dh mi&/kjk (1) ds vuqlkj lgdkjh lkslkbZVh] f'k{kk lfefr] LokLF; lfefr ;k vU; fdlh laLFkk ;k
laxBu ;k LFkkiuk ;k ,sls fudk;ksa ;k muds lewg ftlds laca/ esa jkT; ljdkj vf/lwpuk }kjk fofu'p; djsa] esa
izca/ lfefr dk fuokZpu djkuk gksxkA bl iz;kstukFkZ izkf/dkj dks ernkrk lwph dk fuekZ.k rFkk fuokZpu lapkyu gsrq
i;Zos{k.k] funs'ku ,oa fu;a=k.k dh 'kfDr] izkf/dkfjrk rFkk vfèkdkfjrk gksxhA
4- izkf/dkj dk vè;{k &fcgkj vf/fu;e 14] 2008 dh /kjk&3 dh mi&/kjk (2) esa ;Fkk micaf/r izkf/dkj dh
vè;{krk ,d eq[; pquko inkf/dkjh }kjk dh tk;sxhA
5- izkf/dkj ds dk;ks± dk laO;ogkj&eq[; pquko inkf/dkjh dks vius dÙkZO;ksa ds fuoZgu gsrq mrus mi&eq[; pquko
inkf/dkfj;ksa dh lgk;rk fey ldsxh ftrus fd jkT; ljdkj vf/lwpuk }kjk fu;qDr djsaA
6- iz'kklfud e'khujh& (1) izkf/dkj dks jkT; ljdkj ,sls inkf/dkjh ,oa deZpkjh miyC/ djk;sxh tSlk fd bl
vf/fu;e ds v/hu iznÙk dÙkZO;ksa ds fuoZgu gsrq vko';d gks vkSj tSlk fd bl iz;kstukFkZ in l`ftr fd;k x;k gksA
blds vykos izkf/dkj }kjk fuokZpu lapkyu ds fy, jkT; ljdkj mls vko';drkuqlkj vfrfjDr la[;k esa
inkf/dkfj;ksa ,oa deZpkfj;ksa dh lsok miyC/ djk;sxhA
(2) fuokZpu lapkyu ds fy, fuokZpu izkf/dkj] ftyk n.Mkf/dkjh] vuqe.My inkf/dkjh] iz[k.M fodkl
inkf/dkjh] vapykf/dkjh ;k ,sls vU; inkf/dkjh] tSlk fd og mfpr le>s] dks laLFkk ;k laxBu ;k
LFkkiuk ds fy, fuokZpu inkf/dkjh ds :i esa inukfer dj ldsxk vkSj fuokZpu inkfèkdkjh dh lgk;rk ds
fy, ,d ;k vf/d inkf/dkfj;ksa dks mi&fuokZpu inkf/dkjh ds :i esa inukfer dj ldsxkA
7- fdlh laLFkk ;k LFkkiuk ;k laxBu ;k ,sls fdlh fudk;ksa ds lewg esa fuokZpu ;k fuokZpuksa ds lapkyu ds
iz;kstukFkZ izkf/dkj ,slh laLFkk ;k LFkkiuk ;k laxBu ;k vU; fudk; ds laca/ esa ykxw lqlaxr vf/fu;e vFkok@vkSj
fu;ekoyh ds izko/kuksa ds vuqlkj leqfpr dkjZokbZ djsxkA bl iz;kstukFkZ izkf/dkj dks fofu;ekoyh vFkok@vkSj
fofu;ekofy;k¡ cukdj vkSj@vFkok dk;Zikyd vkns'k fuxZr dj O;oLFkk djus dh 'kfDr gksxhA

vè;k;&3
izkf/dkj ds inkf/dkfj;ksa ,oa deZpkfj;ksa dh fu;qfDr] vihy ,oa lsok 'krsZ
8- (1) osrueku 5000&8000 ls mQij ds inksa ds fo:¼ inkf/dfj;ksa ,oa deZpkfj;ksa dh lsok jkT; ljdkj miyC/
djk;sxhA osrueku 5000&8000 rd ds in xSj laoxhZ; gksaxs vkSj ,sls inksa ij fu;qfDr djus ds fy, izkf/dkj l{ke
gksxkA mDr inksa ds fy, fu;qfDr izkf/dkj eq[; pquko inkf/dkjh gksxkA osrueku 5000&8000 rd ds inksa ds fo:¼
fu;qDr dehZ lfpoky; ds fdlh lsok ;k laoxZ ds vax ugha ekus tk;saxsA
(2) jkT; ljdkj }kjk miyC/ djk;s x;s inkf/dkjh ,oa deZpkjh izkf/dkj esa inLFkkiu dh vof/ esa eq[;
pquko inkf/dkjh ds iz'kklfud fu;a=k.k eas jgsaxsA
(3) izkf/dkj ds inkf/dkfj;ksa ,oa deZpkfj;ksa dh leLr lsok'krs±] vuq'kklu ,oa vihy vkfn jkT; ljdkj
esa bl iz;kstukFkZ ykxw fu;ekofy;ksa ls 'kkflr gksaxhA

<!-- page 3 -->

3

fcgkj xtV (vlk/kj.k)] 13 ebZ] 2008

vè;k;&4
i;Zos{kdksa dh fu;qfDr] 'kfDr ,oa vf/dkfjrk
9- i;Zos{kd dk uke funsZ'ku & jkT; fuokZpu izkf/dkj ,d ;k ,d ls vf/d i;Zos{kdkas dk tks jkT; ljdkj dk
iz[k.M fodkl inkf/dkjh ls mQij dh dksfV ,oa osrueku dk inkf/dkjh ugha gksxk] fdlh laLFkk ;k LFkkiuk ;k
laxBu ;k ,sls fudk;ksa ds lewg esa fuokZpu ;k fuokZpuksa ij fuxjkuh j[kus ds fy, vkSj vU; d`R;ksa dks djus ds fy,
tSlk fd mls fuokZpu izkf/dkj }kjk lkSaik tk;] uke fufnZ"V dj ldsxk%
ijUrq ;g fd jkT; Lrjh; laLFkkvksa ;k LFkkiukvksa ;k laxBuksa esa fuokZpu ;k fuokZpuksa ds izlax esa iz[k.M
fodkl inkf/dkjh ls mPprj dksfV ds inkf/dkjh dk uke funsZ'ku i;Zos{kd ds :i esa fd;k tk ldsxkA
10- i;Zos{kdksa dh 'kfDr;k¡ ,oa vf/dkfjrk & (1) i;Zos{kd fuokZpu ds LoPN ,oa 'kkafriw.kZ lapkyu ds fy,
leqfpr i;Zos{kd j[ksxk vkSj fuokZpu dk lapkyu ds fy, izfrfu;qDr ;k dk;Zjr lHkh inkf/dkjh ,oa deZpkjh mls
leqfpr lg;ksx nsaxsA
(2) fu;e&9 ds v/hu ukefufnZ"V i;Zos{kd dks ifj.kke dh ?kks"k.kk ds iwoZ fdlh Hkh le; erksa dh x.kuk
dks LFkfxr djus vFkok ifj.kke ?kksf"kr ugha djus ds fy, fuokZpu inkf/dkjh dks funsf'kr djus dh 'kfDr gksxh] ;fn
i;Zos{kd dh jk; esa cM+h la[;k esa ernku dsUæksa ij ;k ernku ds fy, fu;qDr LFkkuksa ij dCtk fd;k x;k gks ;k
erksa dh x.kuk ;k ernku dsUæ ij iz;qDr fdUgha eri=kksa ;k ernku ds fy, fu;r LFkku ij fuokZpu inkf/dkjh dh
vfHkj{kk ls vfof/iw.kZ rjhds ls ys fy;s x;s gksa] ;k nq?kZVuko'k ;k vk'k;iwoZd u"V dj fn;s x;s gks ;k [kks x;s gksa
;k ml lhek rd fcxkM+ fn;s x;s gksa ;k NsM+&NkM+ dh x;h gks fd ernku dsUæ ;k LFkku ij ernku dk ifj.kke
lqfuf'pr ugha fd;k tk ldsxkA
(3) tgka i;Zos{kd erksa dh x.kuk jksdus ds fy, ;k ifj.kke ?kksf"kr ugha djus ds fy, bl fu;e ds v/hu
fuokZpu inkf/dkjh dks funsf'kr djsa] ogk¡ i;Zos{kd rRdky jkT; fuokZpu izkf/dkj dks ekeys dh fjiksVZ nsxk vkSj ml
ij jkT; fuokZpu izkf/dkj lHkh rkfRod ifjfLFkfr;ksa ij fopkj djus ds i'pkr leqfpr funs'k tkjh djsxkA
Li"Vhdj.k &

fu;e&9 ds iz;kstukFkZ ^i;Zos{kd* eas jkT; fuokZpu izkf/dkj dk ,slk inkf/dkjh Hkh lfEefyr gksxk
ftls bl fu;e ds v/hu fdlh laLFkk ;k LFkkiuk ;k laxBu ;k fudk;ksa ds lewg esa fuokZpu ;k
fuokZpuksa ds lapkyu ij fuxjkuh j[kus dk dÙkZO; jkT; fuokZpu izkf/dkj }kjk lkSaik x;k gksA

vè;k;&5
fuokZpu ;kfpdk
11- fuokZpu ;kfpdk&fdlh fudk; ds fdlh in ds fuokZpu dks flok; fuokZpu ;kfpdk ds iz'uxr ugha fd;k
tk;sxk%
ijUrq ;fn fdlh fudk; ds fdlh in dk fuokZpu fookfnr gks rks fuokZpu ;kfpdk ml izkfèkdkj ds le{k
nk;j gksxh tSlk fd lacaf/r laLFkk ;k LFkkiuk ;k laxBu ;k fudk; ls lacafèkr vfèkfu;e vFkok@vkSj fu;ekoyh esa
izko/kfur gSA tgk¡ ,slk dksbZ izkf/dkj micaf/r ugha gS ogk¡ ;kfpdk ml eqfUliQ ds le{k nk;j gksxh ftlds
{ks=kkf/dkj esa ,slh laLFkk ;k LFkkiuk ;k laxBu ;k fudk; vofLFkr gksA
12- fuokZpu ;kfpdk dk izkFkhZ izfroknh ;k izR;FkhZ ds :i esa fuEufyf[kr dks tksM+sxk %&
(d) tgka izkFkhZ ,slh ?kks"k.kk djus ds nkos ds vfrfjDr fd lHkh ;k fdUgha fuokZpu vH;fFkZ;ksa dk fuokZpu
voS/ gS] vU; ?kks"k.kk dk Hkh nkok djrk gS fd Lo;a mls ;k fdlh vU; vH;FkhZ dks lE;d:i ls fuokZfpr
fd;k x;k gS] izkFkhZ ds vykok lHkh fuokZpu yM+us okys vH;fFkZ;ksa dks vkSj tgk¡ dksbZ ,slh vU; ?kks"k.kk dk
nkok ugha fd;k tk; rks lHkh fuokZfpr vH;FkhZ dks_ vkSj
([k) fdlh vU; vH;FkhZ dks ftlds fo:¼ fdlh Hkz"V vkpj.k ds vkjksi dks ;kfpdk esa yxk;k x;k gksA

<!-- page 4 -->

4

fcgkj xtV (vlk/kj.k)] 13 ebZ] 2008

13- fuokZpu ;kfpdk nkf[ky djus dh iQhl lfgr izfØ;k&fuokZpu ;kfpdk nkf[ky djus dh iQhl lfgr
izfØ;k ogha gksxh tSlk fd lqlaxr vf/fu;e vkSj@vFkok fu;ekoyh esa fofgr gSA
ijUrq tgk¡ ,slk mica/ izklafxd vf/fu;d vkSj@vFkok fu;ekoyh esa ugha gS ogk¡ ,slh iQhl ,oa izfØ;k dk
fu/kZj.k jkT; ljdkj ds }kjk fuokZpu izkf/dkj ds ijke'kZ ls jkti=k esa izdkf'kr vf/lwpuk }kjk fd;k tk ldsxkA
fcgkj&jkT;iky ds vkns'k ls]
lj;qx izlkn]
ljdkj ds mi lfpoA
___________

13 ebZ 2008
laú&3@,eú&48@2008@2796dkú&vf/lwpuk la[;k 2796] fnukad 13 ebZ 2008 dk fuEufyf[kr vaxzsth
vuqokn fcgkj&jkT;iky ds izkf/dkj ds ,rn~ }kjk izdkf'kr fd;k tkrk gS tks Hkkjr lafo/ku ds vuqPNsn 348 ds [kaM
(3) ds v/hu vaxzsth Hkk"kk esa mldk izkf/d`r ikB le>k tk;sxkA
fcgkj&jkT;iky ds vkns'k ls]
lj;qx izlkn]
ljdkj ds mi lfpoA
