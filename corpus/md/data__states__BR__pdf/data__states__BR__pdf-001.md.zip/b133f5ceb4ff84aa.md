---
doc_id: "b133f5ceb4ff84aa"
source_url: "https://basu.org.in/wp-content/uploads/2022/08/Corrigendum-Empl.-Not.-052022.pdf"
ministry: "Bihar Animal Sciences University (BASU)"
title: "Corrigendum Regarding Advertisement No. 05/2022 :Recruitment for the post of Deputy Comptroller at Bihar Animal Sciences University, Patna."
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "e0747662d7863b01"
---

<!-- page 1 -->

= बिहार पशु विज्ञान विश्वविद्यालय, पटना
- BIHAR ANIMAL SCIENCES UNIVERSITY, PATNA- 8000I4
(Established in 206 under Bihar Animal Science University Act-206)
Employment Notice No.: 05/2022
CORRIGENDUM
: In the Employment Notice- 05/2022 the ‘Scale of pay
(Pay Scale, Grade Pay)” for the post of Deputy Comptroller may
be read as - After five years of working as Deputy Comptroller Comptroller
instead of after five years of working as Deputy Registrar
Sd/-
Registrar,
Bihar Animal Sciences University,
Patna
4 é Go
th
