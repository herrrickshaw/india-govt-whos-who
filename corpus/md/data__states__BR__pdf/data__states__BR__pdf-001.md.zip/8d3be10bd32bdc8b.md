---
doc_id: "8d3be10bd32bdc8b"
source_url: "https://www.bsptcl.in/admin/GuidelineDoc/12-Feb-2014-11_NIT%20No._10_PR_BSPTCL_2014.pdf"
ministry: "Bihar State Power Transmission Company Limited (BSPTCL)"
title: "12-Feb-2014-11_NIT No._10_PR_BSPTCL_2014.pdf"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fc1218b62a1bcdb8"
---

<!-- page 1 -->

BIHAR STATE POWER TRANSMISSION COMPANY LIMITED
(Through e-procurement mode only - www.eproc.bihar.gov.in)
NOTICE INVITING TENDER
Online tender are invited by the General Manager-Cum-Chief Engineer, Transmission Area, Muzaffarpur for the
following:Scope of work.
Estimated cost
Deployment
Cost of Tender
Earnest
in (Rs.)
period
paper (Rs.)
money
(Rs.)
NIT No.10/PR/BSPTCL/2014
PACKAGE (A)
Deployment of Private Security Guards in
different GSS under jurisdiction of
Transmission Circle, Muz. Transmission
Area, Muzaffarpur, T&C Division,
Twelve
Muzaffarpur, Central Store, Muzaffarpur
1,47,17,412/Months (One
16,000/2,94,350/and the colony for the Officers and
Year)
employees for the above establishment is
situated in the campus of GSS,
Muzaffarpur.
PACKAGE (B)
Deployment of Private Security Guards
for the GSSs under the jurisdiction of
Transmission Circle, Purnea. It is to be
mentioned
that
the
Officer
of
Transmission Circle, Purnea, T&C
Twelve
Division, Purnea, Trans. Division, Purnea,
63,62,655/Months (One
6,200/1,27,255/Circle Store, Purnea and the colony for the
Year)
Officers and employees for the above
establishment is situated in the campus of
GSS, Purnea.
PACKAGE (C)
Deployment of private Security Guards
for the GSSs under the jurisdiction of
Transmission Circle, Bhagalpur. It is to be
mentioned
that
the
Office
of
Twelve
Transmission Circle, Bhagalpur, T&C
24,01,219/Months
(One
6,200/48,025/Division, Bhagalpur, Trans. Division,
Year)
Sabour, Circle Store, Bhagalpur and the
colony for the Officers and employees for
the above establishment is situated in the
campus of GSS, Sabour.
Tender schedule as per given below:Period of Sale / Request of Bid / e Form documents 10.02.2014 to 21.02.2014 (up to 13:00 Hrs.) through
website www.eproc.bihar.gov.in
Online Submission of tender: 27.02.2014 (upto 14:00 Hrs.) & Original DD towards COST of BOQ & EMD in
form of DD/BG will have to be deposited to Accounts Officer, Transmission Circle, Muzaffarpur payable at
Muzaffarpur at least One Hour before opening of the Techno-Commercial Bid. (Part - 1)
Date of opening of Techno-Commercial Bid (Part - 1) 27.02.2014 (at 15:00 Hrs.)
While participating in e-tendering process, the contractor shall have to get them registered to get user
ID,Passwords and digital signature. This will enable them to access the Website: www.eproc.bihar.gov.in only.
E- Tender can be downloaded or uploaded only on website www.eproc.bihar.in
Date of opening of price part: To be notified after Technical Bid Evaluation (www.eproc.bihar.gov.in)
The tender documents are available at website www.eproc.bihar.in . Tender documents must be accompanied with scanned
copy of Demand Draft in favour of "Accounts Officer, Transmission Circle, Muzaffarpur" payable at Muzaffarpur towards
the cost of BOQ & EMD in form Bank Guarantee/ DD in favour of "Accounts Officer, Transmission Circle, Muzaffarpur"
failing which the tender shall be summarily rejected (original Demand Draft to be submitted to Accounts Officer,
Transmission Circle, Muzaffarpur.)
Sd/General Manager-Cum-Chief Engineer
Transmission Zone, Muzaffarpur
For complains regarding corruption Vigilance Help Line No.-9431821485, 0612-2504969 Consumer can deposit
electricity bills via Sahaz Vasudha Centre or via bsebbills.org
e-tendering introduced in BSPTCL for tenders above Rs. 25 lacs. For registration logon to www.eproc.bihar.gov.in
and eProcurement Help Desk First Floor, M/22, Bank Of India Building, Road No.-25, Sri Krishna Nagar, Patna800001 at 0612-2523006, Mob: 9939035696.
