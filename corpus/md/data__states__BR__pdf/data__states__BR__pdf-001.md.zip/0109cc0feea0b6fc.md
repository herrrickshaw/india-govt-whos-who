---
doc_id: "0109cc0feea0b6fc"
source_url: "https://www.bausabour.ac.in/pdf/BAU-Act/BAU-Act-(Amendment)-2022.pdf"
ministry: "Bihar Agricultural University, Sabour"
title: "View/Download"
date: ""
pages: 6
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "e9e48bb3880f6064"
---

<!-- page 1 -->

बिहार सरकार,
है कृषि विभाग |
- अधिसूचना
क्र अधि०्सं०- 4,/ कृण्शिठ्को०- 43/2020- DA4b /कृ०, पटना, दिनांक ) 6] +०4-2022
hi बिहार विधान मंडल द्वारा यथापारित एवं।बिहार गजट, असाधारण अंक में दिनांक 03
x अप्रील 2022 को यथाप्रकाशित बिहार कृषि विश्वविद्यालय (संशोधन) अधिनियम, 2022 की
ox gR-(3) के आलोक में यह उस तारीख से प्रवृत्त होगा, जो सरकार द्वारा राजपत्र में
अधिसूचना द्वारा नियत की जाय।
2. उक्त प्रावधान के आलोक में बिहार कृषि विश्वविद्यालय (संशोधन) अधिनियम, 2022,
। इस अधिसूचना के बिहार गजट में प्रकाशन की तिथि से, प्रवृत्त माना जायेगा एवं इसके
५. प्रावधान स्वतः लागू हो Se |
रे हे CL
i ९७००० & बिहार राज्यपाल[के आदेश से,
4.) बे 0. A. Ces; ‘a\
| iH { No.3 wh ८((९---
5 = | et A%
Pisa av ae 2 vate: 2/6/99 ZS) < (डॉ० एन० सरवण कुमार)
A 2060 % ‘S सचिव,
= eR ७७ 9 3 कृषि
Hee aio fincas art, Ben eat
/ज्लीपाक*५ / कृणशिव्को०- 43 /2020= /कृ०, पटना, +f —O4—~ 2022
७४ ६ Q
ere Bes lat : अधीक्षक, राजकीय मुद्रणालय, गुलजारबाग, पटना, , ई--गंजट,
Sg a वि , बिहार, पटना को अआ०्छनन की प्रति (सी.डी. एवं दो हार्ड ) बिहार गजट
के अगले असाधारण अंक में प्रकाशन हेतु प्रेषित ।
}
yer, V we 5 Ve
सचिव,
%0९ डक 55 कृषि विभाग, बिहार, पटना।
a oe 43/2020-2 3 2.6. /कृ०, पटना, a, 4+ 2022
प्र ४ महालेखाकार, बिहार, पटना को सूचनार्थ एवं आवश्यर्क कार्र्नाई हेतु प्रेषित।
ok ce dese P A :
AS sw
sie &0 ० सचिव,
' हि कृषि विभाग, बिहार, पटना।
shy ज्ञापांक- 4,/कृष्शिग्को०- 3/ 20200) FB 9.७. / Ho, पटना, te } Y—04-2022
विश्व॑विध प्रतिलिपि : बिहार कृष्षि विश्वविद्यालय, सबौर, भागलपुर की सूचनार्थ एवं ZI
‘ = ene a क्र se पु य
९ ee i र्रवाई हेतु प्रेषित । Ages Ry : को
(an a bso SG oe
Oe 5. “p) / ९१५ है
< Liais Office @ ( (ः c. aay ‘
Ree le A Bh fs ( ७ 25 2 \ कृषि विभाग, बिहार, sear
e\ 5, 9 72 % } 20४४-76: *
४१ (2) 20/4] 2 ५ ५2 9272 /%॥
जा कक 0. Af
Say, 7 ality Sa 788:
ean ib ON

<!-- page 2 -->

| ज्ञापांक- 4/कृष्शिग्को०- 43,2020- ?%0.७. /कृ०, पटना, जुटा 4+ 2022
प्रतिलिपि : माननीय मुख्यमंत्री के आप्त सचिव,/ माननीय मंत्री, कृषि के ऑप्ति सचिव को
सूचनार्थ एवं आवश्यक कार्रवाई हेतु फ्रेषित। /
सचिव,
कृषि विभाग, बिहार, पटचा। | *
ज्ञापांक-4,/कृठशिग्को०- 43,/2020- "9 3 26 /कृ०, पटना, feria LI-~O4 - 2022 \
प्रतिलिपि : मुख्य सचिव, बिहार /विकास आयुक्त, बिहार / ez वित्त
विभाग, बिहार,/ मंत्रिमंडल सचिवालय, विभाग, बिहार,/योजना एवं ब्रिंकांस , बिहार, i
पटना,/महामहिम राज्यपाल के प्रधान सचिव को सूचनार्थ प्रेषित।
L MW
हे सचिव, है ne
। कृषि विभाग, बिहार, vert. |
« ४ हे छः ।
9.0 |
; ; ‘ =, fot
a Lf 2
$
न | ji
‘ i BOP हि अर । का
sti opm aes: प- 5 . CaP eRTaaE TY TT ५ “aie
WR Fee 7 | RAIA Sys fy ei

<!-- page 3 -->

निबंधन संख्या पी0टी0-40
ram

Hie sas

Ri ae Pe

il

सत्यपेव जबते

बिहार |
3० चैत्र वश्थव (श0०) |;
(सं० पटना 234) पटना, बुधवार, 20 अप्रील 2022
कृषि विभाग
अधिसूचना
49 अप्रील 2022
Wo 4,// कृ०शि०को०-3 / 2020-2326 / कृ०---बिहार विधान मंडल द्वारा यथापारित एवं बिहार गजट,
असाधारण अंक में दिनांक 03 अप्रील 2022 को यथाप्रकाशित बिहार कृषि विश्वविद्यालय (संशोधन) अधिनियम, 2022 की
धारा-4(3) के आलोक में यह उस तारीख से प्रवृत्त होगा, जो सरकार द्वारा राजपत्र में अधिसूचना द्वारा नियत की जाय।
2. उक्त प्रावधान के आलोक गें बिहार कृषि विश्वविद्यालय (संशोधन) अधिनियम, 2022, इस अधिसूचना के
बिहार गजट में प्रकाशन की तिथि से, प्रवृत्त माना जायेगा एवं इसके प्रावधान स्वत: लागू हो जायेंगे।
बिहार-राज्यपाल के आदेश से,
डॉ० एन० सरवण कुमार,
सचिव |
अधीक्षक, सचिवालय मुद्रणालय,
बिहार, पटना द्वारा प्रकाशित एवं मुद्रित!
बिहार गजट (असाधारण) 234-574+40-डी0टी0पी0
Website: http://egazette.bih.nic.in

<!-- page 4 -->

निबंधन संख्या पी0टी0-40
Qi
Fi hy
ae ४
Le
wee wat
बिहार धारण °
STAT अक
बिहार सरकार द्दारा प्रकाशित
a फल ७०»»नन-म-नमयनामा----समननय- लत
43 चैतल्न 7944 (श०)
(सं० पटना 480) पटना, रविवार, 3 अप्रील 2022
a .
विधि विभाग
अधिसूचना
3 अप्रील 2022
सं० एल०जी०-04-02 / 2022-2840 / लेज |---बिहार विधान मंडल द्वारा यथापारित का निम्नलिखित
अधिनियम, जिसपर महामहिम राज्यपाल दिनांक 2 अप्रील 2022 को अनुमति दे चुके हैं, इसके द्वारा सर्व-साधारण
की सूचना के लिये प्रकाशित किया जाता है।
बिहार-राज्यपाल के आदेश से,
ज्योतिस्वरूप श्रीवास्तव,
सरकार के प्रभारी सचिव।

<!-- page 5 -->

2 बिहार गजट (असाधारण), 3 अप्रील 2022
रतन ee
[बिहार अधिनियम 40, 2022] *
बिहार कृषि विश्वविद्यालय (संशोधन) अधिनियम, 2022
बिहार कृषि विश्वविद्यालय अधिनियम, 200 (बिहार अधिनियम 24, 2040) का संशोधन करने के लिए अधिनियम |
भारत-गणराज्य के तिहत्तरवें वर्ष में बिहार राज्य विधानमण्डल द्वारा निम्नलिखित रूप में यह अधिनियमित हो :-
4. संक्षिप्त नाम, विस्तार और प्रारंभ |- (9) यह अधिनियम बिहार कृषि विश्वविद्यालय (संशोधन) अधिनियम,
2022 कहा जा सकेगा।
(2) इसका विस्तार सम्पूर्ण बिहार राज्य में होगा।
(8) यह उस तारीख से प्रवृत्त होगा जो, सरकार द्वारा राजपत्र में अधिसूचना द्वारा नियत की जाय।
2. बिहार अधिन्तियम 42, 200 की धारा 20(2) में संशोधन ।- बिहार कृषि विश्वविद्यालय अधिनियम, 2040
(बिहार अधिनियम 42, 2040) की धारा- 20 (2) निम्नलिखित द्वारा प्रतिस्थापित की जाएगीः-
“20 (2) कुलपति उच्चतम स्तर की क्षमता, निष्ठा, नैतिकता एवं संस्थागत प्रतिबद्धता रखने वाले व्यक्ति
होंगे। वे कृषि विज्ञान के ख्याति प्राप्त विद्वान होंगे, जिन्हें विश्वविद्यालय प्रोफेसर के रूप में न्यूनतम t0
(दस) वर्षों का अनुभव प्राप्त हो अथवा जिनके पास किसी प्रतिष्ठित शोध या अकादमिक प्रशासकीय
संगठन में न्यूनतम i0 (दस) वर्षों का अकादमिक नेतृत्व प्रदर्शन का प्रमाण हो।"
3. बिहार अधिनियम i2, 20:0 की धारा 20(3) में संशोधन Rear कृषि विश्वविद्यालय अधिनियम, 200
(बिहार अधिनियम 42, 2040) की धारा- 20 (3) निम्नलिखित द्वारा प्रतिस्थापित की जाएगी:-
“20 (3) सर्च कमिटी की सूचना का व्यापक प्रचार किया जाएगा और वह सभी कृषि
विश्वविद्यालयों / संस्थानों में जाएगी। सर्च के पैनल का कमिटी चयन करेगी और तीन नामों के पैनल का
सुझाव राज्य सरकार को देगी। कुलाधिपति के द्वारा सर्च कमिटी की अनुशंसा तथा राज्य सरकार द्वारा
अग्रसारण के आलोक में कुलपति की नियुक्ति की जायेगी |”
4. बिहार अधिनियम 42, 20:0 F ar 206) 4% deter |- बिहार कृषि विश्वविद्यालय अधिनियम, 200
(बिहार अधिनियम 42, 200) A aI 20 (6) निम्नलिखित द्वारा प्रतिस्थापित की जाएगीः-
“20 (6) कुलपति अपने पद पर आसीन होने की तारीख से पाँच वर्षों त्त अथवा 70 (सत्तर) वर्ष की आयु
त्तक जो भी पहले हो, पद घारण करेगा। प्रथम कुलपति की रिक्ति पाँच वर्ष के पूर्व होने पर पाँच वर्ष के
अवशेष अवधि के लिए पुनः राज्य सरकार कुलपति नियुक्त कर सकेगी |"
ज्योतिस्वरूप श्रीवास्तव,
सरकार के प्रभारी सचिव।
3 अप्रील 2022
Yio एल०जी०-04-02 / 2022-284 / लेज--बिहार विधान मंडल द्वारा यथापारित और महामहिम
राज्यपाल द्वारा 6॥/00-02/ ४7), 2022 को अनुमत बिहार कृषि विश्वविद्यालय (संशोधन) अधिनियम, 2022
(बिहार अधिनियम 0, 2022) का निम्नलिखित अंग्रेजी अनुवाद बिहार राज्यपाल के प्राधिकार से इसके द्वारा
प्रकाशित किया जाता है, जिसे भारतीय संविधान के अनुच्छेद-348 के खंड (3) के अधीन उक्त अधिनियम
का अंग्रेजी भाषा में प्राधिकृत पाठ समझा जायेगा ।
बिहार--राज्यपाल के आदेश से,
ज्योतिस्वरूप श्रीवास्तव,
सरकार के प्रभारी सचिव।
{Bihar Act 0, 2022]
BIHAR AGRICULTURAL UNIVERSITY (AMENDMENT) ACT, 2022
AN
ACT
To Amend the Bihar Agricultural University Act, 200 (Bihar Act, 2, 200)
Be it enacted by the legislature of the state of Bihar in the seventy third year of
the Republic of India as follows:-
4. Short title, extent and commencement. - (4) This Act may be called the Bihar
Agricultural University (Amendment) Act, 2022.
(2) It shall extend to the whole of the State of Bihar.
(3) It shall come into force on such date as may be appointed by the
Government, by notification, in the official gazette.

<!-- page 6 -->

बिहार गजट (असाधारण), 3 अप्रील 2022 3

2. Amendment in Section-20(2) of Bihar Act 2°of 200. - Section-20(2) of the

Bihar Agricultural University Act, 20i0 (Bihar Act, 2, 20i0) shall be
substituted by the following :-
“20(2) The Vice-Chancellor shall be a person possessing the highest level of
competence, integrity, morals and institutional commitment. He should be a
distinguished academician with a minimum of 0 (ten) years experience as
Professor in a University or 0 {ten) years experience in a reputed research
or Academic Administrative organization with proof of having demonstrated
Academic leadership, in the field of Agriculture"

3. Amendment in Section-20(3) of Bihar Act 2 of 20i0. - Section-20(3) of the

Bihar Agricultural University Act, 20i0 (Bihar Act, 2, 20{0) shall be
substituted by the following :-
"20(3) Notice of Search Committee shall be widely publicized and go to all
agricultural universities/institutes. The Search Committee will select and
suggest a panel of the three names to the State Government. The Chancellor
shall appoint suitable candidate as the Vice-Chancellor based on the panel
recommended by the committee and forwarded by the Government"

4. Amendment in Section-20(5) of Bihar Act 2 of 200. - Section-20(5) of the
Bihar Agricultural University Act, 20i0 (Bihar Act, 2, 200) shall be

$ substituted by the following :-

"20(5) The Vice Chancellor shall hold office for a term of five years from the
date on which he enters upon his office, or until he attains the age of 70
(seventy) years, whichever is earlier. In case of vacancy of first Vice
Chancellor created beforé five years the state government shall appoint the

Vice Chancellor for remaining period of five years."

Jyoti Swaroop Srivastava,
Secretary incharge to the Government.
अधीक्षक, सचिवालय मुद्रणालय,
बिहार, पटना द्वारा प्रकाशित एवं मुद्रित।
बिहार गजट (असाधारण) (80-57 4+400-Stottorto |
Website: http://egazette.bih.nic.in
