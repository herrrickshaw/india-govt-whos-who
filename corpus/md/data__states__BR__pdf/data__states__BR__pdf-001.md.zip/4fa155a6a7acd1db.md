---
doc_id: "4fa155a6a7acd1db"
source_url: "https://cdn.s3waas.gov.in/s3c6e19e830859f2cb9f7c8f8cacb8d2a6/uploads/2020/12/2020121527-1.pdf"
ministry: "Pashchim Champaran"
title: "Om Prakash Jayswal"
date: ""
pages: 22
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "aff82ae5752bb6b8"
---

<!-- page 1 -->

‘Scanned with CamScanner

<!-- page 2 -->

‘Scanned with CamScanner

<!-- page 3 -->

aI ee 7
Hemet aha sctige cise! Sy oa
Mogae tele oro af S
ie ei Rail te tas tena a
कि 7 2 00 0 m ‘4
Sas oem wet at क लेख क erent flee oe frvet
pe ese ageing 85 Z अ्यियों rer ‘andidates
LR Re ie Bipot Cash Register for Maintenance af Day to Day Account by Contesting ara
oo ०५ ce | ee
oo : a ee a | >
| ota Wa es कोई orn oft इस eet :
eros! be हट ie Fein a fewer oe ra ft an है उल्लिखित हैं ता ~
eee ey at
| tae / eee / Pree, ea a है हा भाग तथा सेत | mt 2 ofl
aaa ee Tes (// किसी अन्य | संख्या, na eet aA €, wa wel स्पष्ट किया
Rate | का भाभ तथा जिससे राशि घाषा की गईं Colas [१8५७ seme
fe oe | erin anton SF 2 tom he blanc ke fest | Any expec mentioned
i Rae shi other from whom the amount received vena heptane han २ ome oe 74
हिल 0४] 7 हि 200 9.५0 ‘oucher: mentioned to colon
pokes 30 sabes ered able of Part sa
ees. 77 pa बम
pero] eee Ba S| ae er
ree eee ae
eee ae Teen ay न )Ro
ABO see a | aS
gt | मर es )०॥ लिप | ८ Sb
Xx ae fos / 24 coll i A
Me eet se |. ? / पा "हब = 37०० Pat
reentry | i wha yt
a 2 0७ a
pe :
BSCR i 0 $27 Waters है
emia ५७ | cial
2. [ene | ae NY © a be ee oe खा
; ह a 02553
; , S| BAT
: 00808. | 02060: 06: | 52622 | ARP Keo > Alc =
wat a 5 ee ro | ice ba
| Gee als i RS ia asia sr Ua oneal
| ere | Meet Rt ५४५ ८4950
: Nera) Pees.) Sia aah i Re

<!-- page 4 -->

)
tar 9) =
® art) ai
(rete weak ar आस्यर्थिचों धारा शिपं-परिधित के sted verre Rey Mae ereee 3
Bank Register for Maintenance af Day ta Day Accounts by Contesting Candidates a
अभ्यर्थी का साक :- बैक का भाग हे
Name of the Canadate Name of the Bank ।-
rors eee at a, wit wh हो शात्म क। पका
ame of Peliiol हज 40७ ३५ Branch Address +
fretwr abe cred निर्धाचन लड़ा था खाता ete
Constituency froin which contested t= 02000. ४
करिणाण की घोषणा की तिथि “- ]
Date of Declaration of Result >
Prater ease oe ea पता :-
Nie and address oF Election Agent
Corres) RPE से लेकर निर्वाचन के परिणाम की घोषणा की तिथि तक, दोनो तिलियों रहित)
(From the date of nomination (0 the date of decara tlon of result of election, oth dates clave)
जमा बल a a 7
pons ae | ite | ete a
व्यक्ति,/ दल / संस्था // निकाय /” किसी \ कोई ध्यय a ba aro के स्तस्म-7
omy [TT क्या पता जिससे राशि नकद ,/चेक स्या, वंक | | [a siete है हाल मा
प्राप्त की गई, जमा की का व्यय की प्रकृति रणी के क्तम्स-2 मैं उल्लिखिल नहीं
कवर Ree Cae com, | ae | wre ware] #0 24 Z| a | Jawa यहा ee fet जाना भाडिए
दि जलकर लेक 0७१७०)/४०७ | Bank name'and mount | Cheque No. | Name of Payee | esreniare | Amount | Any expense mentloned in coum
other from whom the amount Branch | his abe and nat mentioned
received/deposited in Bank column 2 of table of Part-A should be
clarified here.
Palen see ० | 70.
.. ५० /५०४० err 2९००6, | tL
Sa lise aa Thai ७ 5९००
७७७४ ae ५७ 326 ७ 5५७&७७७० Ps ac
sonra aed १8 ॥# जब लोक प्रतिनिधित्व अधिविय), ॥॥8| की बात प7 के dts wr AR द्वार/मेरे निर्वाघन gee Ne oh eA wh & (aR ato GI & peta ef
cae ip eneaccaem bet 7 ey, oe under Sectlon 77 ofthe Representation ofthe Pewple Act, L9SI (Certificate to be furnished atte the date fo deetaralton fo result).
i dx Sey GRETA
4 wn tee 0 अभ्य्थी के हस्ताक्षर Signature ofthe Condit) ;
eee. ; bhO तु
a शशि >> 9505 ० a 050...
i ils
Scanned with CamScanner

<!-- page 5 -->

‘Scanned with CamScanner

<!-- page 6 -->

5 20 जा मम ५ !
a ee
os eine att
eee भाग-॥ अभ्यर्थी के निर्वांचन व्यय का सार विवरण
te gee PART -॥ ABSTRACT OF STATEMENT OF ELECTION EXPENDITURE OF CANDIDATE
० के ea -
पद 2020 ले; (0००० eee ‘arene reek Prater ratte दल army | arat द्वारा serrate | ge Prafern ma (rea 9.
a sete a ‘S.No, | fis — Patioutare अधि द्वारा पफणात/प्रापिकृत | हंपगत/प्राधिकृत रोशि शशि (ये हैं) एस $ का जोब)
Ree 96०2९ era (era) Cm) 30१77]: 75 हक tan pesos) .
040 4 हट ree रा हि Amt. Ineurred/Auth, Amt. Ineutred/Authorized " i"
40020 % ९ Se Tua als candatan aan by Pol, Party (in Ra.)
Poe igen.
Fa rir, tet, ogee refi ere
Fa Se eT, tet ae ref ee re
Taina ts Carafe : राजपैतिक दत्त के स्टार प्रचारक्त 95.75 «.»
ier stew होगे घाले आयोजनों को ऐोइकर) 42.+39- £ C2
es CSA See west) you ess
Bee oss) A Expenses in public meeting, rally, pro-
425 ade eat cession otc,
aan ae Va: Expenses in public mooting, rally,
areas ‘Procession etc. (ie: other than the ones
ees “with Star Campaigners of the Political
Seren te Party (Enclose as per Schedule.t) ४
ee
अं .._ ॥ | ख : स्टार प्रचारक ( को) के साथ जन
rr tat ae ge we me ( ae:
i mits: ......._| झाघारण पार्टी प्रचार वाले आयोजनों को
fase | जोड़कर) (अनुबंध 2 के अनुसार संलल Nt NI ee 20%
कि 02 4 क)३2: ३8. cect S i
Si oe ce a one For Dacre party
| लटक के; ea ean
rs ईलियों जूलूस इत्यादि में प्रयुक्त प्रचार
सामग्री को छोड़कर अन्य प्रचार सामग्री
( अनुबंध 3 के अनुसार संलग्न करें) i
Be yu |... Campaign materials other than those ey Bb (Mikes Ni
बन 20227: 0: “used un the public meeting, rally,
5 कि nes Sowa =
00720 0 220: 300 है, “५ 3 pu fencers per 8 ८ 570 . = re fe ४ * , 2
ee ee 00502 (0 50 | कि 5 5 कटा es 202
mins 0050 00023 eee sa ete ae |, 20666 aaa
ae पीपल मा डिय सहित ll 303 ae 2855 inlets Se
eee ee | eee | ARS 40600 2002: et
है re NHL | SVE TE NEE 4] NI ;
| eee प्र
ia a etwork bu | 4 | पल
- Saag | | 22222 :
4 | |
| | 5
रा प्रयुक्त प्रचार वाह | | es |
rar ern it) | Shh zoe | | oN 6: AS 23
f : कै डक यम आम |e 8 oer
४ | | iia [See ida ate sola 200 6 82000 8 Fy
fi Ne |i reae ots eee Neer esa amyiaear | coe ee oat = 3] SERCO oat ;
| मत हा छा की 2200 77020 0220 77 ree Se
। mn worker किलर पक 02000 ee
| | ee et ee ie gd
| बढ epee किक 46 मी | 9467 22 कह ae ES 568 Slat capone:
| ; छः ben pers RRR et cil Sei ah relate
है 0 00660 0 ee eee.
ae oe ee NE ee eo
2 पल ह25800 0 ५. Cl G oT aaa
aie Meee 8 erence rc i ere
| a
‘Scanned with CamScanner

<!-- page 7 -->

‘a
Scanned with CamScanner

<!-- page 8 -->

। वह है
| ५
os . 2 ee.
| aycnrae brane) emreaay |
| 4 बिहार CH BIHAR it |
\ o\92 scotia 578 Sr oa है, ।
न ॥॥॥॥॥॥॥॥॥॥॥#॥ |
, bi nora? pf |
बे : RA pa
(6. MPI-IV mT
iC pr 2
ae ee ee हा लि निर्वाचन अधिकारी के समक्ष (जिला,
राज्य “संघ हि —
Yar Sy a) sf “श्रीमती /युत्री.209: ETO. iNT. AYA TA / TH LOLLY,
77०7----आय॒.....3..3........वर्ष निवासी एतदूद्वारा ईमानदारी एवं सत्यनिष्ठापूर्वक निम्न प्रकार से घोषणा करता हूँ :-
x _§ i)
MM सह कि में aM की लोक सभा /विधानसभा के लिए साधारण निर्वाचन /उप - निर्वाचन में
ह Of eta Rebbe. PRY / UTA सभा निर्वाचन क्षेत्र से निर्वाचल लड़ने वाला अभ्यर्थी था, जिसका परिणाम
3. 3.7... को घोषित किया गया था।
(यह कि उपर्युक्त निर्वाचन के संबंध में दिनांक Loo dO: 2.020( a6 ther ara aa नामाकित किया गया था) एवं
इसके परिणाम की घोषण की तारीख, दोनों दिन को सम्मिलित करते हुए, के बीच मैंने मेरे निर्वाचन अभिकर्ता ने मेरे
एवं मेरे निर्वाचन अभिकर्ता द्वारा उपगत /प्राधिकृत सभी व्ययों का पृथक एवं सही लेख़ा-स्खा हैं।
७) यह कि उक्त लेखा, रिटर्निंग अधिकारी द्वारा इस ste किए किट एज के लिए रजिस्टर में अनुरक्षित किया गया था एवं
उक्त रजिस्टर, इस लेखा में उल्लिखित वाउचर /बिल के साथ संलग्न है।
(४)  पह कि निर्वाचन के सबंध में इसमें संलग्न मेरे निर्वाचन व्यय के लेखे में मेरे या मेरे निर्वाचन अभिकर्ता, मुझे प्रायोतिज
करने वाला राजनैतिक दल, अन्य संगठन /मुझे समर्थन देने वाले व्यक्तियों के निकायों एवं अन्य व्यक्तियों द्वारा उपगत
अथवा प्राधिकृत निर्वाचन व्यय की सभी मर्दें इसमें शामिल हैं एवं उनमें (लोक प्रतिनिधित्व अधिनियम ।95। की धारा
770॥) के अंतर्गत स्टपष्टीकरण । एवं 2 ढ्वारा इसके अन्तर्गतम नेताओं की यात्रा के संबंध में किए गए व्यय को छोड़
कर) कुछ भी छिपाया अथवा रोका /दबाया नहीं गया है।
6) यह कि निर्वाचन के संबंध में उक्त लेखा के संलग्नक - ॥। में संलग्न निर्वाचन व्ययों के सार विवरण में मेरे / मेरे निर्वाचन
अभिकर्ता, मुझे प्रायोजित करने वाले राजनैतिक दल अन्य संगठन मुझे समर्थन देने वाले व्यक्तियों के निकायों एवं
अन्य व्यक्तियों द्वारा उपगत अथवा प्राधिकृत व्यय भी emerson हैं। =
(6). यह कि पूर्व पैरा (।) से (5) तक में दिए गए कथन मेशी सर्वोत्तम जानकारी एवं: के अनुसार सत्य हैं, और इननें
कुछ भी गलत नहीं है एवं किसी भी महत्वपूर्ण तथ्य को छिपाया नहीं गया है।
अभिसाक्षी
ली गई) (साक्ष्यांकन प्राधिकारी, अर्थात्‌ प्रथम श्रेणी मजिस्ट्रेट अथवा शपथ आयुक्त या नोटशी पब्लिक के हस्ताक्षर तथा
7) WS 43055. हे
93५) of) ies SAGAS,
८८ 3. hi |
se SGN ® SASHA
Mo Y, toy |
$e ८2, (9 >» है
vt, =
«52५59, (6 Mw” ॥
“2५ atv Bdcond yt ree)
G\ 8, ast! $ od 4
\ 4 eae : ay “2822.
04 ot indi?
ent: = Betws ।
Scanned with CamScanner

<!-- page 9 -->

A
‘Scanned with CamScanner

<!-- page 10 -->

‘Scanned with CamScanner
