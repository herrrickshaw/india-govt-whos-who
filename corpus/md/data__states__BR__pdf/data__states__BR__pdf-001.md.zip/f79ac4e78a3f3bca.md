---
doc_id: "f79ac4e78a3f3bca"
source_url: "https://atmasamastipur.com/wp-content/uploads/2018/06/appoointment-letter-for-btm.pdf"
ministry: "Agriculture Technology Management Agency (ATMA), Samastipur, Bihar"
title: "Appointment letter for BTM"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "26fac028f9d83753"
---

<!-- page 1 -->

dk;kZy; d`f"k izkS|ksfxdh izca/k vfHkdj.k] vkRek] leLrhiqj A
vkns'k
fcgkj ljdkj] d`f"k foHkkx] iVuk dk i=kad 617] fnukad 30-09-2014] i=kad 807] fnukad 30-092014 ,oa i=kad 918] fnukad 10-11-2014 ds vkyksd esa us'kuy fe'ku vkWu ,xzhdYpjy ,DlVsa'ku ,.M
VsDukWyksth ds v/khu lc&fe'ku vkWu ,xzhdYpjy ,DlVsa'ku ¼vkRek ;kstuk½ ds vUrxZr lafonk vk/kkfjr
inksa ij fu;kstu gsrq Draft Merit List of Shortlisted candidates ds vk;ksftr dkmalsfyax ,oa izkIr
nkok@vkifÙk ds fu"iknu ds QyLo:Ik iz[kaM rduhdh izca/kd ds in ij Jh ----------------------------------------------------------------------firk--------------------------------------------------------------irk-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------dks fu;r ekuns; `25000-00 ¼iPphl gtkj½ :0 izfrekg esa fuEu 'krksZ ds vuqlkj fu;ksftr fd;k tkrk
gS&
1lafonk ds vk/kkj ij p;u ,d ¼01½ o"kZ ds fy, gksxk A dk;Z larks"ktud gksus ij iqu% ,d
o"kZ ds fy, uohd`r fd;k tk ldsxk A dk;Z larks"ktud ugha gksus ij ewY;kadu ds vk/kkj ij]
lsokeqDr fd;k tk ldsxk A
2-

vuqca/k dh vof/k lekfIr ds iwoZ ;fn fu;ksftr O;fDr dk iqufuZ;kstu ugha gksrk gS rks oSlh
fLFkfr esa fu/kkZfjr frfFk dks mudk fu;kstu Lor% lekIr ekuk tk;sxk vkSj blds fy, dksbZ
vkns'k fuxZr fd;k tkuk visf{kr ugha gksxk A

3-

iz[kaM d`f"k inkf/kdkjh ds izfrosnu ij lafonk ij fu;ksftr dfeZ;ksa dks gVkus dk vf/kdkj
ifj;kstuk funs'kd] vkRek] leLrhiqj dks gksxk A bl laca/k esa fdlh izdkj dh vihy ftyk
inkf/kdkjh&lg&v/;{k] vkRek'kk"kh ifj"kn] leLrhiqj ds Lrj ij dh tk;sxh] ftudk fu.kZ;
vafre gksxk A

4-

lafonk ds vk/kkj ij fu;ksftr O;fDr u rks ljdkjh lsod ekus tk;saxs vkSu u ljdkjh lsodksa
dks vuqekU; fdlh Hkh lqfo/kk ds gdnkj ekus tk;saxs A bl izdkj fu;ksftr O;fDr }kjk fu;kstu
ds Ik'pkr~ ljdkj dh lsok esa fu;ferhdj.k dk nkok fdlh Hkh ifjfLFkfr esa ekU; ugha gksxk A

5-

lafonk ds vk/kkj ij fu;ksftr dfeZ;ksa ij iz'kklfud fu;a=.k ftyk inkf/kdkjh&lg&v/;{k]
vkRek'kk"kh ifj"kn] leLrhiqj dk gksxk A

6-

lafonk ij fu;ksftr dfeZ;ksa dk nkf;Ro d`f"k ea=ky;] Hkkjr ljdkj }kjk le;&le; ij fuxZr
ekxZn'kZu ds vkyksd esa jkT; ljdkj ,oa varfoZHkkxh; dk;Z lewg ¼IDWG½ }kjk fu/kkZfjr nkf;Roksa
dk fuoZgu fu;ksftr dfeZ;ksa dks djuk gksxk A lafonk ij fu;ksftr dfeZ;ksa dk eq[; nkf;Ro {ks=
esa vkRek ;kstuk dk lQy ,oa ikjn'khZ dk;kZUo;u gksxk A

7-

pw¡fd mDr ;kstuk dsUæ izk;ksftr ;kstuk gS vr,o lafonk ds vk/kkj ij ;g fu;kstu rHkh rd
ekU; gksxk tcrd ;kstuk ds dk;kZUo;u gsrq dsUæ ljdkj ls vko';d fuf/k ¼Fund½ izkIr gksrh
jgsxh A

8-

iz[kaM rduhdh izca/kd in ij fu;ksftr O;fDr;ksa dks muds fMxzh ,oa vuqHko izek.k&i= ds
oS/krk dh tkap vof/k ¼60 fnu½ ds nkSjku ekuns; dk Hkqxrku ugha fd;k tk;sxk A

9-

iz[akM rduhdh izc/akd in ds fy, p;fur O;fDr ds fMxzh ,oa vuqHko izek.k&i= ds oS/krk dh
tkap ds fy, vf/kdre 60 fnuksa dk le; fn;k tk;sxk A

10-

60 fnu ds vanj lacaf/kr laLFkku@izkf/kdkj ls lacaf/kr O;fDr ds fMxzh ,oa vuqHko izek.k&i=
ds oS/krk dh fjiksZV izkIr ugha gksus dh fLFkfr esa leqfpr volj nsdj ml O;fDr dk fu;kstu
lekIr fd;k tk ldsxk A

<!-- page 2 -->

11-

;ksxnku ds lkFk viuh ;ksX;rk laca/kh izek.k&i=ksa ,oa vuqHko izek.k i= dh LoPN Nk;k izfr ¼nks
lsV½ esa lefiZr djuk gksxk A

12-

vlSfud 'kY; fpfdRlk&lg&eq[; fpfdRlk inkf/kdkjh ls LokLF; laca/kh ewy izek.k&i= lefiZr
djuk gkxk A

13-

p;fur O;fDr vius izek.k&i=ksa dh oS/krk laca/kh 'kiFk&i= ds lkFk ;ksxnku djsaxs A

14-

p;fur O;fDr iz[kaM rduhdh izca/kd ds in ij vkRek dk;kZy;] cktkj lfefr izkax.k] leLrhiqj
esa dk;kZy; vof/k esa fnukad 12-02-2015 rd ;ksxnku lqfuf'pr djsaxs A

15-

fnukad 14-02-2015 rd Ø0la0 1 ls 10 rd mYysf[kr 'krksZ dk ,d ,djkjukek 100 :0 ds
uu&twfMfl;y LVkEi isij ij dk;kZy; dks lefiZr djuk vfuok;Z gksxk A

vuqyXud&,djkjukek dk izk:Ik layXu gS A
ifj;kstuk funs'kd]
vkRek] leLrhiqj A
Kkikad-------------------------@vkRek] leLrhiqj] fnukad----------------------------izfrfyfi&-----------------------------------------------------------------------------------------------------------------------------------dks lwpukFkZ ,oa vko';d
dkjZokbZ gsrq izsf"kr A
ifj;kstuk funs'kd]
vkRek] leLrhiqj A

<!-- page 3 -->

,djkjukek dk izk:i
1-

lafonk ds vk/kkj ij p;u ,d ¼01½ o"kZ ds fy, gksxk A dk;Z larks"ktud gksus ij iqu% ,d
o"kZ ds fy, uohd`r fd;k tk ldsxk A dk;Z larks"ktud ugha gksus ij ewY;kadu ds vk/kkj ij]
lsokeqDr fd;k tk ldsxk A

2-

vuqca/k dh vof/k lekfIr ds iwoZ ;fn fu;ksftr O;fDr dk iqufuZ;kstu ugha gksrk gS rks oSlh
fLFkfr esa fu/kkZfjr frfFk dks mudk fu;kstu Lor% lekIr ekuk tk;sxk vkSj blds fy, dksbZ
vkns'k fuxZr fd;k tkuk visf{kr ugha gksxk A

3-

iz[kaM d`f"k inkf/kdkjh ds izfrosnu ij lafonk ij fu;ksftr dfeZ;ksa dks gVkus dk vf/kdkj
ifj;kstuk funs'kd] vkRek] leLrhiqj dks gksxk A bl laca/k esa fdlh izdkj dh vihy ftyk
inkf/kdkjh&lg&v/;{k] vkRek'kk"kh ifj"kn] leLrhiqj ds Lrj ij dh tk;sxh] ftudk fu.kZ;
vafre gksxk A

4-

lafonk ds vk/kkj ij fu;ksftr O;fDr u rks ljdkjh lsod ekus tk;saxs vkSu u ljdkjh lsodksa
dks vuqekU; fdlh Hkh lqfo/kk ds gdnkj ekus tk;saxs A bl izdkj fu;ksftr O;fDr }kjk fu;kstu
ds Ik'pkr~ ljdkj dh lsok esa fu;ferhdj.k dk nkok fdlh Hkh ifjfLFkfr esa ekU; ugha gksxk A

5-

lafonk ds vk/kkj ij fu;ksftr dfeZ;ksa ij iz'kklfud fu;a=.k ftyk inkf/kdkjh&lg&v/;{k]
vkRek'kk"kh ifj"kn] leLrhiqj dk gksxk A

6-

lafonk ij fu;ksftr dfeZ;ksa dk nkf;Ro d`f"k ea=ky;] Hkkjr ljdkj }kjk le;&le; ij fuxZr
ekxZn'kZu ds vkyksd esa jkT; ljdkj ,oa varfoZHkkxh; dk;Z lewg ¼IDWG½ }kjk fu/kkZfjr nkf;Roksa
dk fuoZgu fu;ksftr dfeZ;ksa dks djuk gksxk A lafonk ij fu;ksftr dfeZ;ksa dk eq[; nkf;Ro {ks=
esa vkRek ;kstuk dk lQy ,oa ikjn'khZ dk;kZUo;u gksxk A

7-

pw¡fd mDr ;kstuk dsUæ izk;ksftr ;kstuk gS vr,o lafonk ds vk/kkj ij ;g fu;kstu rHkh rd
ekU; gksxk tcrd ;kstuk ds dk;kZUo;u gsrq dsUæ ljdkj ls vko';d fuf/k ¼Fund½ izkIr gksrh
jgsxh A

8-

iz[kaM rduhdh izca/kd in ij fu;ksftr O;fDr;ksa dks muds fMxzh ,oa vuqHko izek.k&i= ds
oS/krk dh tkap vof/k ¼60 fnu½ ds nkSjku ekuns; dk Hkqxrku ugha fd;k tk;sxk A

9-

iz[akM rduhdh izc/akd in ds fy, p;fur O;fDr ds fMxzh ,oa vuqHko izek.k&i= ds oS/krk dh
tkap ds fy, vf/kdre 60 fnuksa dk le; fn;k tk;sxk A

10-

60 fnu ds vanj lacaf/kr laLFkku@izkf/kdkj ls lacaf/kr O;fDr ds fMxzh ,oa vuqHko izek.k&i=
ds oS/krk dh fjiksZV izkIr ugha gksus dh fLFkfr esa leqfpr volj nsdj ml O;fDr dk fu;kstu
lekIr fd;k tk ldsxk A

p;fur vH;FkhZ dk uke&

iz[kaM d`f"k inkf/kdkjh

inuke&

iz[kaM---------------------------------

gLrk{kj&
LFkku--------------------------------] fnukad------------------------------

<!-- page 4 -->
