---
doc_id: "0ba372a7fbeedf13"
source_url: "https://horticulture.bihar.gov.in/MainSite/Documents/Notice/3109_2026-08-08.pdf"
ministry: "Horticulture Directorate, Agriculture Department, Bihar"
title: "👉 Corrigendum-2-Extension of Proposal Submission Timeline regarding the Mithila Multi-Commodity Horticulture Cluster, Bihar."
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "cb09e47ff026e887"
---

<!-- page 1 -->

Govt. of Bihar
Department of Agriculture
Bihar Horticulture Development Society, Patna
(State Horticulture Mission)
2nd floor, Krishi Bhawan, Mithapur, Patna — 80000I
No. 3\OF Date: 08/08/2026
CORRIGENDUM-CUM-ADDENDUM - 02 TO THE REQUEST FOR PROPOSALS (RFP)
Subject: Extension of Proposal Submission Timeline regarding the Mithila Multi-Commodity
Horticulture Cluster, Bihar.
In pursuant of the Request for Proposals (RFP) via e-Tender for “Selection of Implementing Agency /
Agencies for Implementation of Different Verticals of the Mithila Multi-Commodity Horticulture Cluster,
Bihar for Banana, Mango and Litchi under the Cluster Development Programme (CDP) of the National
Horticulture Board” dated 09/07/2026 and Corrigendum cum addendum | dated /07/2026, to the request
for proposal (RFP), the following corrigendum-cum-addendum — 02 is hereby issued and shall form an
integral part of the Bid Document. All other terms and conditions of the tender shall remain unchanged.
Amendment to the Critical Timeline (Page 2 of the Corrigendum cum addendum | dated I/07/2026
of RFP)
The schedule for the submission of proposals has been revised as follows:
S.no | Clause & Page No. we Revised Date & Time as Revised Date & Time as per
Original कि Corri
Date & Time | Pe Corrigendum cum orrigendum cum
addendum -0I addendum -02 (As Amended)
| | RFP Publish Date 09/07/2026 09/07/2026 (Unchanged) 09/07/2026 (Unchanged)
2s Last date & time for
submission of | 24/07/2026 4/08/2026, 05:00 PM 24/08/2026, 05:00 PM
proposals with DPR
(Signature)
d Mw
hed \
Director Hi ture + cum - Mission Director
Bihar Horticulture Development Society
Department of Agriculture
Government of Bihar, Patna
