---
doc_id: "b7bb2e3b8c7cee6a"
source_url: "https://bceceboard.bihar.gov.in/pdf_Tender/ADV_TEN25_02.pdf"
ministry: "Bihar Combined Entrance Competitive Examination Board (BCECEB)"
title: "Short Tender Notice Regarding Auction of Old and Damage Boxes (Tender No.BCECEB(TEN)2025/02 Dated 15.01.2025)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "562fb0c89dca1da5"
---

<!-- page 1 -->

800014
Website : bceceboard.bihar.gov.in / Helpdesk : helpdesk.bceceboard@bihar.gov.in

2025/02

- 15.01.2025

(As is where is)
08.02.2025 5.00
11.02.2025
2.00

4.00
2025/01

bceceboard.bihar.gov.in

15.01.2025
