---
doc_id: "9ed18af5f48aedc8"
source_url: "https://www.lnjpitchapra.ac.in/wp-content/uploads/2023/05/TENDER-FOR-VEHICLE.pdf"
ministry: "Loknayak Jai Prakash Institute Of Technology (LNJPIT)"
title: "Tender Notice for Requirement for “Vehicle on hiring Basis” for the use of LNJPIT Chapra -841302"
date: ""
pages: 9
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "d24208eaeaee36cf"
---

<!-- page 1 -->

शक प्राचार्य का कार्यालय
| AYA लोकनायक जयप्रकाश प्रौद्योगिकी संस्थान,
BURI-84302
(विज्ञान एवं प्रावैधिकी विभाग बिहार सरकार, पटना के अन्तर्गत)
अल्पकालीन निविदा
भाड़े के वाहन हेतु निविदा सूचना संख्या- 02/2023-24
लोकनायक जयप्रकाश प्रौद्योगिकी संस्थान, छपरा के कार्य हेतु एक भाड़े के वाहन की मासिक दर पर
आवश्यकता है। वाहन का प्रकार $८0थ॥/507५ जो बेहतर ४006] का वाहन हो एवं एक वर्ष से पुराना
नहीं होना चाहिए। नये एवं अपेक्षाकृत बड़े वाहन को प्राथमिकता दी जायेगी। इच्छुक वाहन मालिक (जिनका
वाहन भाड़े पर चलने के लिए निबंधित हो) पंजीकृत ट्रेवल एजेन्ट / अन्य विज्ञापन की तिथि से दिनांक
20.06.2023 तक (अवकाश का दिन छोड़कर) संस्थान के कार्य अवधि में कार्यालय से निविदा फार्म रू0
500/- (पाँच सौ रू0 मात्र) का बैंक ड्राफ्ट “Principal, LNJPIT, Chapra ® vet में जो छपरा a
भुगतेय हो” जमा कर प्राप्त कर सकते हैं। निविदा फार्म (आवश्यक अनुलग्नकों के साथ) एवं जमानत की
| zt mo 5000/- (पाँच हजार रू0) का बैंक ड्राफ्ट “Principal, LNJPIT, Chapra के पक्ष में जो
। छपरा में भुगतेय हो” स्पीड पोस्ट / निबंधित डाक / हाथो- हाथ कार्यालय में विज्ञापन की तिथि से दिनांक
20.06.2023 तक (अवकाश का दिन छोड़कर) स्वीकार किया जायेगा। भाड़े पर लिए जाने वाले वाहन का
अधिकतम भाड़ा 40000/- से अधिक नहीं होना चाहिए जिसमे सभी करें सहित मरम्मति
(Maintenance) के खर्च के साथ 7200  कि0०मी0 प्रति माह की दूर चलने के इंधन
(Diesel/Petrol/Lubricant) =r भी खर्च सम्मिलित होगां। प्रति माह :200 fesozito से अधिक की
दूरी के परिचालन की स्थिति में केवल gua (Diesel/Petrol) अतिरिक्त देय होगा। विस्तृत ब्योरा संस्थान
& Website:-www.Injpitchapra.in uz sae BI
लोकनायक जयप्रकाश प्रौद्योगिकी संस्थान,
छपरा
(0000
93,0623

<!-- page 2 -->

कुछ महत्वपूर्ण बिन्दु
|

\. Fag wr yr Presentation Page Number-06 @ feeg 3 B sree et (0
Marks) vd saa& संबंधित प्रश्न-उत्तर के साथ वर्त्तमान में जिस महाविद्यालय में सेवा दे
ze 8 aet & Feedback @ ane पर 0 Marks feu arash

2. जिनकी सुरक्षा एजेंसियाँ, विज्ञान एवं प्रावैधिकी विभाग, पटना, बिहार के अंतगर्त आने वाले
एंव अलग-अलग परिसर में चलने वाली राजकीय अभियंत्रण/पोलटेक्निक महाविद्यालय को
सेवा देने वाले सुरक्षा एजेंसियाँ को वरीयता दी जायेगी। साथ ही ऐसे तीन अलग-अलग
uRee AH aaa ae April 2022 & aera में सेवारत महाविद्यालय के द्वारा जारी
अनुभव पत्र & ea yos-l wl ae) (5 Marks)

3. जिनकी सुरक्षा एरजेंसियाँ, विज्ञान एवं प्रावैधिकी विभाग, पटना, बिहार के अंतगर्त आने वाले
एवं अलग-अलग परिसर में gaat aeft ger veiftrat Infrastructure a संपूर्ण
जानकारी et yos-Il vd Il et gef wo a a we ed) (I5 Marks)

4. महाविद्यालय में छात्र/छात्राओं की गतिविधियों से संबंधित जानकारी के लिए पुछे गए पाँच
Ueat ar sae voa-IV 4 gf wo a edi (l0 Marks)

5. Insurance & PPF a पूर्ण जानकारी के लिए प्रपत्र-४ को पूर्ण रूप से भर कर जमा

। करें।

6. गर्त att af a Turn-over & Income Tax Return at oneert at wos-VI &
VIL @® are are we ed) (0 Marks)

4. वित्त विभाग के पत्र संख्या-(-4-06/2023 2988 दिनांकः- 23/03/2023 & दिशा निर्देश
का पूर्णतः पालन किया जायेगा।

8. अगर किसी निविदा कर्त्ता को निविदा के बारे में कोई समस्या हो तो दिनांकः-0--/-26-
| 2023 ws दिनांकः- (2/26/2022 & ma mm बजे महाविद्यालय में प्रो०
af Riz (Mobile Number:-945486], 940307646) & see aan wad
है या Email ID:- principallnjpitchapra@gmail.com W af ae Bad F!

लोकनायक जयप्रकाश प्रौद्योगिकी संस्थान,
छपरा (एप
99.06%

<!-- page 3 -->

TENDER
FOR
Vehicle for Official Purposes
FOR
Loknayak Jai Prakash Institutes of Technology, Chapra
Tender No.: LNJPIT / 02/2023
Sale of Tender Start date:- 3.05.2023
Last Date of submission:- 20.06.2023
r ie Lb
« ee eee Illes 2
evel! my Wass <r” 73°
Gxt, Mol ye Principal
2“ ऋठ 57७ wet 52:22 sas JOINT CHAPRA
VS S re 2 4498
oe co mkuman
9 93-06-23

<!-- page 4 -->

Loknayak Jai Prakash Institutes of Technology, Chapra
Tender Notice For Vehicle
Tender Notice no.
Sealed Technical and Financial bids are invited from any service provider or owner for providing vehicle
roundclock for the Loknayak Jai Prakash Institutes of Technology, Chapra for annual contract period of
one year, by Registered post /speed post/Hand delivery.
Last date of submission: 20.06.2023
Opening of tender 22.06.2023 at 42:30 A.M. at Principal Chamber, Loknayak Jai Prakash Institutes of
Technology, Chapra.
All interested vendors are requested to send their sealed quotation for supply of the above item under
two bid systemsin the following manner:
a) Envelope- |: Technical Bid.
b) Envelope II: Financial Bid.
NOTE: The bid documents are not transferable and the firm's seal and signatire O° TTS <“ The bid documents are not transferable and the firm's seal and signature of the authorized
official must appearon all papers and envelopes submitted. envelopes submitted.
| Both the envelopes should be sealed, signed, marked and kept in a bigger envelope super scribed with
the Tender ReferenceNo. and Tender notice detail as appended hereunder.
TENDER for Vehicle
TENDER REF. NO: LAST DATEFOR SUBMISSION:
The Principal
From: M/S Contact No:
E-mail ID:
; sale Cg
Prin
re हार ewe =
2 की री dwt, 7320 'धजशा CHAPRA
\er v | 0 ut” os, JA? won “MAR B44 9D
a ase a 07% ;

<!-- page 5 -->

|
|
|
IL INSTRUCTIONS TO BIDDERS BIDDERS

i, The vehicle (Bolero/Scorpio/Any other SUV) should be in good condition and it should not be
more than one year old.

2. The tender fee of Rs. 500/- (Five Hundred Rupees only and E.M.D. of Rs. 5,000/-(Five Thousand
Rupees only)-only in the shape of demand draft separately on any nationalized bank in favor of
Principal, Loknayak Jai Prakash Institutes of Technology, Chapra payable at Chapra should
accompany tender paper. Without tender EMD will be ignored straightway.

३, The undersigned reserves the right to reject any or all the tenders without assigning any reason
thereof.

4. The comparatively new vehicles and of higher model will be given priority.

5, The contract will be kept valid for a period of 22 months which can be extended on mutual
consent basis on the same terms and conditions for further 22 months (max three times)
current comprehensive insurance and road tax coverage, permit, fitness and driving license of
driver etc

6. Contractor should keep the vehicles in neat, clean and good running conditions with sheet
clothcovers, which should be replaced with another set of washed covers once ina week. The
contractor should carry out the periodical maintenance of the vehicles supplied and insure them

always in good condition.

7. All payment towards lubricants, repairs, insurance, any taxes etc and any other expenditure

related to vehicles is the contractor's sole responsibility, all payment to the driver towards their
salary, overtime etc. is also the contractor's responsibility.

8. Payment will be made on submission of bills.

9: The contractor can be terminated by giving one months' notice in writing by either party. Incase
of breach of terms and condition, Loknayak Jai Prakash Institutes of Technology, Chapra,
reserves the right to terminate the contract without giving any notice.

0. In case of accident etc. Loknayak Jai Prakash Institutes of Technology, Chapra has no
responsibility whatsoever towards,police/RTA, court of law, injured parties, damages to the
vehicle or property or any claim made for the loss etc. All these are entirely the contractor's
responsibility.

4i. Any deviation/Violation or breach of the said terms and condition will be viewed seriously, and
the contractor will be terminated without prior notice.

2. Loknayak Jai Prakash Institutes of Technology, Chapra reserves the right to accept or reject any
tender or part of any tender or all tenders without assigning any reason thereof, irrespective of
the fact whether the tender is the lowest or not.

43. Maximum limit for quoted amount will be 40,000/- per month including fuel for 200 Km,
Lubricants, taxes &duties as per norms, maintenance etc.

4९6४“:

a D hea ८728:
मु pores hse we at a2?" ‘ yw
#0! as | praca 4s Princip’
99975 9 १2 | Nes ce” LNuPIT CHAPRA
S » 9 See” a > oF BIHAR-#44 308

Void S408 ql 5९2: Cet. memo

93:05 23

<!-- page 6 -->

44. In case contractor refuses to supply vehicles ordered by Loknayak Jai Prakash Institutes of
Technology, Chapra, it will be viewed seriously, and contract will be terminated without giving
any notice and their security money will be seized.

45. The person/contractor/travel agent are directed to submit Technical & Financial Bid in separate
envelope.

46. The evaluation of tender will be done by the committee on the basis of weightage to Technical
and Financial part.

7. The breakdown of weightage will be as Technical -50% and Financial -50%, Technical (Ageof
Vehicle 30%, Price of Vehicle- 20%). The detailed breakdown of marks is provided inevaluation
sheet in sections follows.

48. After evaluation of Bid, the successful bidder will be informed separately.

49. The agencies must put their initial on each page submitted. All pages must be numbered and a
note of this should be mentioned on covering letter. The Terms & Conditions duly signed should
be attached with tender paper.

20. The supply of vehicle has to start services within 07 days of intimation. The tenderer may
change vehicle of Quoted in tender by comparatively newer and higher model.

24, The full E.M.D. shall be forfeited in case of backing out of the offer before acceptance.

22. The award of work shall be done on QCBS basis (Quality and Cost Based Selection
approach)among the technically qualified consultant after Technical Evaluation. The lowest
financial proposal (Fm) shall be given a financial score (SI) of 50 points. The financial score of the
proposals shall be computed as follows:

5,=30 x F,,/F
(F- Amount of financial Bid).
23. Formula for final score = F+ T
Where, T= Marks awarded for Technical Proposal and F= The marks awarded for financial
proposal
The Bidder scoring highest Combined Score shall be declared as preferred Bidder for award of
Contract.
24. In case two or more bidders achieve same combined score, the bidder who's Financial Proposal
shall result in least cost to Loknayak Jai Prakash Institutes of Technology, Chapra shall be
declared as selected bidder eligible foraward of Contract.
.
i ga मा a3
oy i x MIE a
sy “papal gs)? 2 ९ Nes Principal
ete Or ys doth: INGA LNUPIT CHAPRA
a pase 2 ० (2०2 rare OF QIAAR BAT IAL
Y ne ~ Fei tit & mkumar
9306-2 3

<!-- page 7 -->

|
I. The evaluation parameters will as follows:
Technical: Total Marks: S000 7०7 नीति 8ै8।फए“"7गप Total Marks: 50
L aE. (Ee, Ee fs नि Marks
| Criteria | If Age of If Age of If Age of If Age of If Age of
| Vehicle<Ol Vehicle Vehicle Vehicle Vehicle
| (One Months) | between 02 between 2 between 24 between 36
| months to 2 months to 24 months to 36 months to 48 |
| months months months months |
| | | |
pets 30: fot
Marks Obtained: |
2. Price of Vehicle
Criteria If Price of If Price of If Price of If Price of Less than 8
Vehicle is Vehicle Vehicle Vehicle Lakhs
more than 5 between 2 between 0 between 8 |
Lakhs Lakhs to 5 Lakhs to 2 Lakhs to 0 |
Lakhs Lakhs Lakhs
| [os Cs
| Marks Obtained:
| | Sub Total (Technical)
ne तत्व सतत |
|B. Financial Evaluation Total: 50 Marks |
—— ए 777 अल पान समन कक न कर ताक सके पतप८--4+८+२-आ+->र8++नसस+-+०- नल“ सम यपण-बनलपर टल्नटि 77775 _
Total Marks Obtained based upon clause 22
Grand Total as per clause 23 ]
aes J niltads,
ee
p ey wexk “Gas 2S
# ५52 leg " Princi
caus, Pv eae Kor em
zope ८ 26: ec uPIT GHAPRA
nh है कि
) dass >2522 OF BIHAR-€44 388
Cer ger" श्र PeKumah
5 99- 08:92

<!-- page 8 -->

| Annexure- |
Technical bid documents
2 Copy of Latest Pollution Test
| x Copy of Road Tax
| [4 __| Copy of Vehicle fitn oe ता Copy of Road Tax
[5 __| Proof of Price of Vehicle (invoice) |
| | Le ___| Income Tax PAN of डाल मर .
| 7 [empbeals /|/+/+/ ऊन मप््च््चनहढन्नञाराए-:
(Signature & Seal)
Principai
LNJPIT CHAPRA
GOVT. OF RIHAR-#44309
4
Pia
. eed
ee” o |
> /26#2
uit »| mea ///2 ..५०2
phe . A
2 Principal
ys fen ke = LNJPIT CHAP
Swen Ct ates RA
donde 2a (22 aa GOVT. OF BIHAR-#44309
_ De KA raxurna
93:05:23

<!-- page 9 -->

Annexure II
Financial Bid for supply of Vehicle (Please provide in a separately sealed envelope)
| S.No. | Name of Vehicle Monthly Rent of Vehicle including | Quoted Rate per KM after 200
(Bolero/Scorpio/Any other SUV) Diesel/Petrol for 200 KM of Travel KM of Travel
|
| a
av
, ees
re os]
gi |
/2
we पे
aks
C “
4285 C ) Yes ors
Oe clo Zeee
हा 2266४
हम : cipal 2° Go ee ye
(2४४०० Wi 2 Principal
in < as
es 6 LNJPIT CHAPRA
GOVT, OF BIHAR-@44 302
foKumor
93-06-23
