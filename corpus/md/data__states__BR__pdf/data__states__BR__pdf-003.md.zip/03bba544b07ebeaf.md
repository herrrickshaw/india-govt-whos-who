---
doc_id: "03bba544b07ebeaf"
source_url: "https://horticulture.bihar.gov.in/MainSite/Documents/Tender/Tender_2026-10-08_234.pdf"
ministry: "Horticulture Directorate, Agriculture Department, Bihar"
title: ""
date: ""
pages: 22
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "88bda965b78ec80f"
---

<!-- page 1 -->

= Horticulture Development Society - Solar Dryer RFP Tt
Govt. of Bihar
Department of Agriculture
Bihar Horticulture Development Society, Patna
(State Horticulture Mission)
2nd Floor, Krishi Bhawan, Mithapur, Patna - 80000
Phone: 062-2547772 | Email md-hort-bih@nic.in, dir-bhds-bih@nic.in | Website: horticulture. bihar.gov.in
NOTICE INVITING SHORT e-TENDER / REQUEST FOR PROPOSAL
Empanelment of OEMs / Authorized १५2६], 8... ही व) ser en ie MM Lalo Bl
Warranty Support and Maintenance of Solar 080 00 ee ere ten ee Tire es) yd
| Bid inviting authority | Mission Director, Bihar Horticulture Development Society, Patna ao ih
| Procurement portal__| hitpsi/leproc2.binar.govin/EPSV2Web)
| Capacity Categories 20/25 kg, 50 kg, 00 kg, 250 kg, 500 kg and special project 000 kg
| Covered solar crop dryers |
‘Selection method | QCBS 76:30 minimum qualifying Technical Score of 70 mans =i
Warranty Minimum 5 years comprehensive warranty; minimum 7 years structure |
—____ durability; spares supportfor7 years el
Notice Inviting Short e-Tender
Bihar Horticulture Development Society (BHDS), Department of Agriculture, Government of Bihar invites online
bids from reputed, experienced and technically qualified Original Equipment Manufacturers (OEMs) or OEM-
authorized agencies for empanelment, rate discovery and supply of solar crop dryers of approved capacities
under horticulture and allied government supply schemes in Bihar. The procurement covers design, manufacture,
testing, packing, transit insurance, transportation, installation, commissioning, training, warranty support and
maintenance on a turnkey basis.
SN pedis ०07) Ptr l ela
त | Start date and time for 6.09.2026 (0:00 Hrs.) |
|__| downloading tender document ps a se as |
{2 | Pre-bid meeting _____| 24-09-2026 (43:5 Hrs.) Hybrid/ online (link to be notified) _
3 Last date and time for bid 08-0-2026 (75:00 Hrs.) |
________ Submission/uploading | हु oe
|4 Date and time of technical bid 08-0-2026 (5:30 Hrs.) |
>> वि Z| a Baca व ० धन |
5 | Date and time of presentation To be intimated to responsive bidder only |
| 6 ‘Date and time of financial bid “| To be intimated only to technically qualified bidders |
= a OP a re | oe oe en eee ee |
8%, Contact Details Shri Pawan Kumar, Additional Director, Horticulture +9-
se | 620808789 35 sai कि
8 | Mode of selection QCBS 70:30, QCBS 70:30 minimum qualifying Technical
aoe a  OOOSIOE ZO marks © = Seer! a= asad
Mission Director, Bihar Horticulture Development Society, Patna, reserves the right to
revise/change/cancel the Tender without assigning any reason thereof.
CK
Mission Director
State Horticulture Mission,
Bihar, Patna
Paget

<!-- page 2 -->

Bihar Horticulture Development Society - Solar Dryer RFP
i. Notice Inviting Short e-Tender
Bihar Horticulture Development Society (BHDS), Department of Agriculture, Government of Bihar invites
online bids from reputed, experienced and technically qualified Original Equipment Manufacturers (OEMs)
or OEM-authorized agencies for empanelment, rate discovery and supply of solar crop dryers of approved
capacities under horticulture and allied government supply schemes in Bihar. The procurement covers
design, manufacture, testing, packing, transit insurance, transportation, installation, commissioning,
training, warranty support and maintenance on a turnkey basis.
2. Disclaimer
¢ This RFP is not an agreement and is neither an offer nor an invitation by BHDS to any applicant except on the
terms prescribed herein
¢  BHDS reserves the right to amend, modify, supplement, withdraw or cancel this RFP at any stage without
assigning any reason, subject to applicable rules and competent authority approval.
¢ — Applicants shall undertake their own due diligence on applicable laws, rules, standards, taxes, logistics,
site conditions, warranty obligations and service network requirements.
* — Cost incurred by applicants for bid preparation, demonstrations, site visits, samples, testing, clarifications
or presentations shall be borne by the applicant.
* Issuance of this RFP does not imply that BHDS is bound to empanel any applicant or award any work order.
Empanelment does not guarantee minimum quantity.
. In case of any discrepancy between the portal configuration and the provisions of the RFP, the provisions of
the RFP shall prevail.
3. Definitions
aoa Definition
Solar crop dryer Aprotected drying system using solar thermal energy and/or solar PV powered air |
| circulation/control, with optional hybrid backup, used for controlled drying of agricultural |
|e A CO DOR ee ee een
| Batch capacity Maximum wet produce loading for one drying batch under declared commodity-specific |
| Rooms loading assumptions. Capacity shall not be stated only as chamber volume. el
Food contact surface Any tray, mesh, liner or surface directly touching produce during drying. It shall be food- |
| gtadeandcorrosion-resistant. eee eed ee Sy
| Commissioning Completion of installation, safety checks, dry run, loaded test/demonstration, beneficiary |
Lo training and issue of field acceptance certificate. pest eee es eas |
| Hidden transit damage Damage not visible during unloading but detected during installation, dry run, loaded trial or |
[ee ___| within 30daysofcommissioning, | फ़खझ Seen
| Comprehensive warranty | Warranty covering parts, labour, travel, repairs, replacement, service visits and
___|_software/controller defects without extra cost to BHDS or beneficiary. =
4. Capacity Packages
rer me rarer eects feeae ces teal
Poe a
A 20/25 kg Individual farmer, kitchen garden, Portable cabinet/box/foldable dryer; low area; basic |
| ‘small medicinaV/aromatic plant thermometer; optional small PV fan; simple training.
> EO pres eS | Stele ners er eae ee |
B P50 kg Progressive farmer, small SHG, | Cabinet/tunnel dryer with forced air circulation, adequate _|
| | nursery or demo centre | tray area, insect/dusv/rain protection and optional |
fe aay soe ei 2S OMEN reer eee ees cd |
c | 700 kg SHG, FPO, village enterprise, | Active airflow, temperature/humidity display, PV fan, |
| | common facility centre | optional hybrid backup, QR asset ID, minimum field
Pe elle eet Saget CORNICE |
D | 250 kg FPO, farmer cluster, institutional | Tunnel/greenhouse/cabinet system with multiple fans, |
| buyer, mini-processing unit | improved ventilation, controller, data logging, earthingand |
eee | setvios plan. rie |
re | 500kg Large FPO, aggregation centre, | Engineered tunnel/greenhouse/hybrid system, modular |
| | processing cluster | trays/racks, safety protections, geotagged installation, |
pie eee eee | a perindlo ORM:
IX
Page2 iN

<!-- page 3 -->

Bihar Horticulture Development Society - Solar Dryer RFP
Gece cme cerns reeks Pee ear ed
Dee च
| Special | 7000 kg | Cluster/institutional project only | Allowed only after site feasibility, civil space confirmation,
| | power/backup plan, load calculation and separate approval
eer Eke Bei oo [Sea ae [Sy BHDBS ies eS aa ।
5. Scope of Work
© — Design, engineering, manufacture, factory testing, packing, loading, transit insurance, transportation,
unloading, assembly, installation, testing and commissioning of solar crop dryers at sites approved by BHDS.
© — Supply all components, including drying chamber/tunnel, trays/racks, cover/glazing, frame, fans/blowers,
sensors, controller, solar PV modules, battery/inverter where applicable, wiring, earthing, safety devices,
signage, QR asset label, manuals and installation accessories.
¢ — Ensure the dryer is suitable for fruits, vegetables, spices, medicinal and aromatic plants, flowers, grains or other
produce notified by BHDS, subject to crop-specific protocols issued during training.
* — Provide one complete user manual, maintenance manual, warranty card, electrical safety sheet and crop-wise
standard operating procedure in Hindi and English.
* — Train the beneficiary/FPO/SHG users at site and capture training acknowledgement with geotagged
photographs.
* — Provide comprehensive warranty, preventive maintenance, corrective maintenance, spare parts and service
reporting during the warranty period.
e Maintain a digital asset and service register for each installed dryer.
6. Evaluation Methodology
SE TT
Stage! | Administrative and eligibility | Pass/fail. Non-responsive bidders are rejected.
___ evaluation ees ey
|_Stage I! | Technicalscoring | Minimum 70 Marks out of 00 Marks required _ |
[Stag Stage Ill | Financial evaluation | QCBS (70:30) among technically qualified bidders only. |
| | i |
be eS ae i bei aetna aera aes |
6. Responsiveness to Minimum Eligibility Criteria
Stage-I
ES
}4 | Legal status | OEM of solar crop dryers or OEM-authorized Registration certificate, PAN, GST, OEM certificate or |
| | agency/system integrator registered in India as OEM/authorization letter. |
: 5 _.._|_company/LLP/partnership/cooperative/proprietorship. |  खघख9आ9आ9आ9आ्उ्उ्उ्उऋथऋऋऑऋऑ#ऑ#£&ः
| 2 Relevant experience | Minimum 3 years in design, manufacture, supply, | Work orders, invoices mandatorily supported by
| installation or maintenance of solar dryers/solar drying | completion certificate/payment proot
| systems in agriculture or Horticulture. Experience inalt |
L _,_thiee years is mandatory. ee Se eee eae ncn
js Installations of Solar | Minimum 25 installations of Solar Dryers in agriculture or | Work orders, Invoices mandatorily supported by
|__| Dryers. Horticulture sector in last S financial _ ____| completion centficate/payment proof
la Turnover Average annual turnover of at least RS. 7 crore from T CA certificate with UDIN, audited financials, ITR. ft
| renewable energy/agri-processing/manufacturing/supply |
| | business during last 3 financial years, subject to
| applicable MSE/startup relaxations as per Bihar Purchase
Low} | Preference Poticy, 2024 Sh pecer ewe Sy af Sa y Se eth
ts Quality management | ISO 9007:205 a Valid certificates and scope showing
| or equivalent QMS evidence; additional certificates manufacturing/installation/service of relevant
eae SS peared eh systems. _ iets
[6 Service presence | Functional service office/authorized service arrangement | Office proof/lease/authorization, service engineer
| in Binar or undertaking to establish within 30 days of list, helpline details
L— ___|-empanetment,__ seat el
क्र Non-blacklisting | No blacklisting/debarment/ineligibility by Centra State Notarized affidavit and disclosure of
} ____|_ Government/PSU/statutory authority in last 5 years. Ntigstion/perfarmance issues. _ alah a os
js Document Cost | Payment of Tender Document Fee. Proof of online payment of %5,000/- through
| | NEFT/RTGS/online mode.
[9 EamnestMoney | Submission of prescribed EMD. ___| Proof of online payment of €7,00,000/- (Rupees One
Page 3 OF

<!-- page 4 -->

Bihar Horticulture Development Society - Solar Dryer RFP
SN erin finite tire Cini

| Deposit (EMD) | | Lakh Only) through NEFT/RTGS/online mode.
kK a Faas el 207: ee er ee
Mo GST registration The bidder should possess a valid GST registration and 7. GST Registration Certificate. |
| | should be compliant with GST filing requirements. 2. GST Returns (GSTR-38/GSTR-I) for the last three |
L Ke eae sees months preceding the bid submission date. |
कक Technical The presentation should cover the company profile and Technical presentation |
| Presentation relevant experience, technical design and specifications, |
| performance and drying efficiency, proposed innovations,

| | quality and safety measures, compliance with applicable
| | | standards, installation and operation and maintenance |
| | | methodology, warranty provisions, service-level |

| | commitments and after-sales support, and experience in|

Eee | implementing similar projects. | |

— pt ०-3 न ञनल न ७33 अल “नमन न अमन J

e Bid is submitted within the prescribed timelines and through the portal specified in the bid notice.

e — Allmandatory forms, declarations, authorizations and certificates are uploaded, signed and legible.

* Financial details are not disclosed in technical bid documents.

* Bid is unconditional and free from material deviations affecting scope, quality, warranty, SLA, penalties or risk
allocation.

* — The bidder has accepted inspection, traceability, warranty, penalty, replacement and de-empanetment clauses
without reservation.

e — The bidder must satisfy all Minimum Eligibility Criteria and submit all supporting documents. Failure to comply
with any eligibility requirement shall render the bid non-responsive and it shall not be considered for Technical
Evaluation.

Stage-Il

Technical scoring

En ६५७॥७७॥४०0 (06098 Paes Be ree eed
Experience in Design, Manufacture, Supply, | 3t05 Years-70 Marks |
Installation, Commissioning & Maintenance | Above 5 Years up to 8 Years — 5 Marks
of Solar Crop Dryers/Solar Drying Systems _| Above 8 Years- 20 Marks
2 ‘Number of Solar Dryers Successfully 25-50 Installations: 0 Marks; >50-700 Installations: 5 Marks, More
Installed in Last 5 Years ‘than 400 Installations: 20 Marks
‘Average Annual Turnover During Last 3 %i-2 Crore: 5 Marks; >€2-5 Crore: 70 Marks; Above €5 Crore: 75 5
Financial Years (FY 2022-23,2023-24 and Marks
2024-25)
Quality Cartification {S0 8007:2075: 6 Marks; ISO 9007:2075 with any one additional 70
certification (I$ 4007/ISO 4500'/BIS/CE etc.): 40 Marks
Local Service Support Infrastructure Service Centre/Technical Support Facility in Bihar: 2 Marks; Service 5
Centre with Dedicated Technical Team in Bihar: § Marks
Technical Presentation on Solar Crop Drvar_| Company Profile & Relevant Experience: 6 Marks: Technical Dasien 30
& Specifications: 6 Marks; Performance, Drying Efficiency &
Innovation: 5 Marks; Quality, Safety & Standards Compliance: 3
Marks; Installation & O&M Methodology: 3 Marks; Warranty, SLA &
Service Support: 3 Marks; Similar Project Experience: 3 Marks;
Quality of Presentation/Demonstration: 2 Marks

EC el Se ee 5 के

Only those bidders who secure a minimum of 70 marks out of 00 in the Technical Evaluation shall be declared

technically qualified and eligible for opening of the Financial Bid.

6.2. Financial Evaluation - QCBS 70:30

————————— Score (TS) Marks obtained by the bidder out of 00 in the technical evaluation. Only technically

foe wes er eae qualified bidders shall be considered for financial evaluation. |

| Weighted Technical Score (WTS) WTS =TS 0.70 Sige . See ) आजा,

| Financial Score (FS) FS = (Lowest valid evaluated price among technically qualified bidders + Valid |

Se Bvalitated prige of thie DOdor Uitte On sie ATEN SEO a

नम 2 |

| Composite Score Composite Score = WTS + WFS. The technically qualified bidder obtaining the highest

= oer} eoriposite Saore stall ba ranked il tor the (espective pacxegslecnacule; ——

| Tie-break Higher technical score; if still tied, lower quoted price; if still tied, better service

Petes areas ees |_network/past performance as decided bycommittee, "“।?/?  /;

Page 4 ee

<!-- page 5 -->

Bihar Horticulture Development Society - Solar Dryer RFP
B
7, Minimum Technical Specifications
Indirect Solar Crop Dryer with Forced Convection
Application Drying of fruits, vegetables, spices, medicinal & aromatic plants, grains and other
ee agricultural or horticulture produce
Capacity Category 20 kg, 25 kg, 50 kg, 00 kg, 250 kg, 500 kg and 000 kg per batch (commodity
dependent)
Structure Design Tunnel/Polyhouse type design suitable for outdoor installation
Structural Frame Corrosion-resistant
I Gl
or
i Aluminium structure
suitable for outdoor use
Food Contact Surface
Drying Trays SS 304 Food Grade trays हू
Minimum No. of Trays 20 kg: 2-4; 25 kg: 2-4; 50 kg: 4-8; 00 kg: 8-2; 250 kg: 5-20; 500 kg: 25-35; 000 kg:
50-70
Absorber Surface Black-coated
i. छा
or
ii. SS absorber sheet
Air Circulation Forced convection through solar-powered DC fans/blowers. Fans/blowers shall be
protected by guards and be replaceable at site.
Monitoring Digital display for chamber temperature and relative humidity
on ee |
Durability Suitable for continuous outdoor operation under local climatic conditions with
warranty at no extra cost.
Structure durability Minimum 7 years against normal corrosion/failure subject to user not physically
eee ee |
Electrical & Safety Features | MCB/fuse protection, proper cable sizing, UV-resistant cables, insulated terminals,
earthing, protection from water ingress, fan/blower guards, and safety signage.
8. Capacity-wise Specification
=
| 20/25 kg Portable cabinet/box/foldable type | Food-grade trays; thermometer; natural or assisted Individual farmers and
| airflow; rain/insect cover; minimum 4 spare tray/mesh demonstrations. |
हि ०००02 5 ep epee 20020 a eel ell
50 kg Cabinet/tunnel type with forced PV/DC fan or hybrid fan; temp display; improved sealing, | Progressive 3. |
soso 5 22472: 72 washable trays; easy dismantlingforcleaning, | ३ |
300७8 Active solar crop dryer with Forced convection; temp/numidity display; QR SHGS/FPOs/CFCs.
optional hybrid backup traceability; field acceptance loaded trial; spares kit; 5-
a A ee FY BOR ea orale ge Se en ees = Sf
250 ke Engineered Multipte fans; controller; data logger preferred; earthing; | FPOs/institutions.
| tunnel/greenhouse/cabinet system | strong frame; modular racks/trays; defined ventilation, | a
500 kg | Large tunneV/greenhouse/hybrid Engineering drawing; site layout; structural anchoring; Large FPOs/clusters.
Scena | ५०७७ ०६808: 9०/शाए५टएशशक्षाभाएक्‌ १७५८० 9७; | ..0808080हऑुऑुऑु
OS
PageS

<!-- page 6 -->

Bihar Horticulture Development Society - Solar Dryer RFP
लि चतततातताता ताकत रत
optional hybrid heat source. |
|
“4000 kg Special project system Separate site feasibility, power/backup calculation, civil | Only cluster/institutional
eee ascot | _-----~-_-foundation/space requirements, safety plan and approval. | projects.  $

9. Quality Assurance, Inspection and Testing

¢ The bidder shall submit a quality assurance plan covering procurement of materials, fabrication, component
testing, electrical testing, chamber testing, packing and dispatch.

*  BHDS may conduct factory inspection/testing.

* — Pre-dispatch inspection (PD!) shall include model, capacity, BOM, serial numbers, tray count, food contact
material, frame/corrosion protection, cover material, fan/controller/PV/battery details, electrical safety and
packing quality.

¢ Field acceptance shall include physical verification, dry run, fan/controller test, temperature display test,
electrical safety/earthing test, water ingress check, loaded demonstration wherever feasible and user training
certificate.

* — Atleast 5% of supplied units or minimum one unit per district/package, whichever is higher, may be randomly
inspected in detail by BHDS/third party. BHDS may increase sampling if defects are found.

cm
Factory/PDI | Before dispatch | BOM, dimensions, material certificates, component serials, electrical
ie L See ____|_Safety, packing. 7 ee Rte eee i
Site delivery check | Atdelivery/untoading | No visible damage, all packages received, photographs, beneficiary |
lana 3 te mI UO लाए a a
Installation and | Within delivery timeline | Assembly, anchoring, wiring, fan/controller/PV/battery test, safety, |
commissioning | =| demonstration. ea ee sd
30-day hidden | 30 days after Hidden transport damage, malfunction, cracks, fan/controller failure,
| defectwindow __|_ commissioning eter be tae> fh be rectifisn/meplnced bysinpiet
90-day | 90 days after Performance and usability feedback; serious, repeated defects may |
performance | commissioning orfirst trigger payment retention, replacement or de-empanelment. |
| शा | drying season, as |
3 | BT eae ae J
Page 6

<!-- page 7 -->

Bihar Horticulture Development Society - Solar Dryer RFP
0. Traceability and Digital Asset Register
Asset ID / QR code |_ Package, year & serial number. Durable label affixed on main chamber/control panel. |
Beneficiary details | Name, farmer/FPO/SHG ID, mobile number, village, block, district, scheme reference. /
| Location details ____|_Geotagged coordinates, site photographs before and after installation. |
Model details cist OEM, model name, capacity, configuration, tray area, year of manufacture, batch number.
Component serials | PV module, controler, inverter, battery, fans/blowers, sensors, data logger, control panel and
ede ee __| other major components. _ : =
Documents linked | Invoice, PDI certificate, installation certificate, warranty card, user manual, training
श्र | certificate, servicelog. न
Servicerecord | Complaint ID, date, issue, action taken, parts replaced, closure acknowledgement.

. Transport, Transit Damage and Risk Allocation

* — The quoted price shall include packing, forwarding, insurance, freight, loading, unloading, local handling and
incidental charges up to the beneficiary/site.

¢ — Supplier shall arrange transit insurance for full replacement value. Insurance claim process shall not delay
replacement/commissioning for the beneficiary.

* Delivery acknowledgement is not acceptance. Payment shall not be released merely on delivery at site.

* — Any visible damage at delivery shall be recorded and the damaged component/unit shall be replaced within 7
days or within a period approved by BHDS considering site conditions.

* — Any hidden damage detected during installation, commissioning or within 30 days of commissioning shall be
Presumed supplier responsibility unless misuse, tampering or force majeure is established by written inspection
report.

* Repeated transit damage or poor packing may lead to rejection of batch, suspension of further dispatches,
penalty and de-empanelment proceedings.

2. Warranty, Maintenance and Service Level Agreement

rei Pee

Comprehensive system warranty | Minimum 5 years from commissioning covering parts, labour, travel and |

aE क pe L LRPLRSEM SELECT CUD COSt |

Structure durability Minimum 7 years against normal corrosion/failure subject to user not physically

eee reer a | GRIEBINE the tnt. लि eee : |

PV module warranty As per OEM standard and applicable regulations; documents to be provided if PV |

- ______#_s=s=_| modules are supplied. _ Sans ae eee
Battery/controlier/inverter/fan warranty Minimum as per OEM warranty, but bidder remains single point responsible for |
ced at tes rie as system performance forSyears. sal
‘Spare availability Supplier shall ensure spares for at least 7 years from commissioning. eo al
Preventive maintenance Quarterly in first year and half-yearly thereafter during warranty, with service |

reports and beneficiary acknowledgement.
Rees Timetine

Complaint acknowledgement | Within 24 hours = ea ed

Remote triage/phone guidance __ Within 24 hours : a

Sitevisit | Within 72 hours of complaint registration ie er

Minor repair/adjustment | Within 5 workingdays ofcomplaint es ieee

Major repair _ __Within 75 days of complaint Se ian aay wt

Component replacement if not repairable Within 30 days or faster during active drying season a ned

Standby/alternate support during peak Required if unit remains non-functional beyond 5 days due to supplier- |

| drying season हे __attributable defect Sai ee,
ee
Page?

<!-- page 8 -->

Bihar Horticulture Development Society - Solar Dryer RFP
3. Payment Terms and Securities
Performance Security | 5% of work order value including GST, valid through the warranty period plus an |
___| additional ctaim period of 60 days कर |
r | Upon delive e Solar Crop Dryer at site, iminary physical
| Payment milestone i pe H d मै ery of tht Crop D ry at site, successful preliminary physica’ |
60% | verification, and submission/verification of PDI (Pre-Dispatch Inspection)
(ou —_{Gocuments andrelated records, a सदन अनाज
| Payment milestone | Upon successful installation, commissioning, trial run/loaded demonstration, |
| 30% | training of beneficiaries/operators, and issuance of Field Acceptance Certificate by |
bi ______________| the designated authority. Se ee, |
Payment milestone After completion of 90 days of satisfactory operation of the system without any |
0% major defect, or against submission of an additional Performance/Warranty Bank
Guarantee of equivalent value, as approved by BHDS.
eel eee el gl
Payment prerequisite Geotagged photographs, QR asset entry, component serial register, warranty card, |
5 कई ____|_user training certificate and inspection report. _ =Sie He a
4. Penalties and Safeguard Mechanism
| Delay in supply/instatlation | Liquidated damages at 0.5% of delayed unit/work order value per week or part
ais se Subject to maximum 0%, without prejudice to cancellation. =
| Visible transit damage No payment for damaged unit/component. Replacement within 7 days; repeated
fst ae ______..__| _0ases attract penalty up to 2% of affected unit value and dispatch suspension. |
| Hidden damage within 30 days Free repair/replacement within prescribed SLA. Failure permits BHDS to arrange
Ee ao ___| repair/reptacement at supplier risk and cost. alts |
Failure in commissioning/acceptance | Rectification within 0 days. Second failure may lead to rejection of unit, |
: eae = ______| feplacement and penalty upto 5% of unitvalue. Sh
Substandard or substituted Immediate replacement with approved component, penalty up to 0% of affected
‘component = ______| unitvalue, batch inspection and possible de-empanetment. es ed
False Bid rejection or contract termination, forfeiture of EMD/performance security, de-
= ा empanelment/blacklisting proceedings and legal action. |
जन estes | ae ge ete
SLA default Penalty per delayed complaint per day as specified in work order; repeated default |
Sh in more than 5% units or three districts may freeze further work orders. |
Repeated complaints or warranty | Show-cause, special audit, withholding of payment, de-empanelment and |
failure के ----------.(००/७४078 proceedings as per applicable rules. “3 S|
5. Allocation of Work among Empanelled Agencies
* — Empanetment does not guarantee work. Work orders may be issued based on beneficiary choice, district
requirement, scheme priority, capacity package, past performance, service performance, complaint
record, availability of funds and administrative convenience.
*  BHDS may restrict fresh work orders to agencies with unresolved complaints, repeated SLA failures or poor
field performance, even if empanelled.
*  BHDS may require multiple agencies to agree to finalized rate/package terms where permitted, but quality
thresholds and warranties shall not be diluted.
Ce
Page 8

<!-- page 9 -->

Bihar Horticulture Development Society - Solar Dryer RFP 69

6. Disqualification and Termination

¢ — Submission of late, incomplete, conditional or materially deviating bid.

° Failure to meet eligibility or mandatory technical gate.

* — Attemptto influence, canvass or interfere with evaluation.

© — Blacktisting/debarment or concealment of material facts.
© — Forged certificates, false performance claims, altered test reports or misrepresentation.
° — Failure to establish service support in Bihar within the committed time.
* — Supply of substandard materials or failure to honour warranty/SLA obligations.
* Repeated complaints verified by district officials, third-party inspectors or BHDS committee.
i7. Empanelment Validity
* The empanetment shall remain valid for a period of two (02) financial years from the date of issuance of the

Empanetment Order and may be extended for a further period of one (07) financial year, subject to satisfactory

performance and successful completion of assigned works, at the discretion of BHDS.

Pe
Page 9

<!-- page 10 -->

Bihar Horticulture Development Society - Solar Dryer RFP
£e
(Letter Head of the Bidding Agency)
Name of Bidding Agency/OEM:
Address:
PAN No.:
GSTIN:

To,

The Mission Director,

Bihar Horticulture Development Society (BHDS)

Dept. of Agriculture

Government of Bihar

2nd Floor, Krishi Bhawan,

Mithapur, Patna — 800004

Subject: Technical Proposal for Empanelment of Original Equipment Manufacturers (OEMs)/Agencies for

Supply, Installation, Commissioning and Maintenance of Solar Crop Dryers.

Sir,

In accordance with the terms and conditions prescribed in the Request for Proposal (RFP) for Empanelment of

Original Equipment Manufacturers (OEMs)/Agencies for Supply, Installation, Commissioning and

Maintenance Solar Crop Dryers, \We hereby submit our Technical Proposal containing the following

documents:

Page

fe Covering Letter on Bidder's Letterhead See he NEMO eer Pees |
{2 Certificate of incorporation/Registration/Partnership Deed/LLP Yes/No | Page No. |
[Soe EAC ee —__ | YesiNo_ | Page No. |
| 4__[ csr Registration Certificate 0 Nes | PegeNo. |
|5___| OEM Certificate or Manufacturer Authorization Letter (MAF), wherever applicable | Yes/No | Page No. |
[8 |"Power of Attorney/Authorization Letter for Authorized Signatory || | YesiNo | PageNo.
7 Bidder Information Sheet (Annexure-t) Sp paiuee Yes/No ~ | PageNo. |
| नम EMD and Tender मिल बला नि नमन a | Pap
[9 _ Audited Financial Statements for Last Three Financial Years tb YesiNo | PageNo. |
|.l0 __| CACertified Turnover Certificate with UDIN ae _ Yes/No | Page No. |
हो Income Tax Returns (ITR) for Last Three Financial Years | Yesino | (5 आम, |
[2 Experience Details (Annexure-V) ___| Yes/No See ee oe No. tl
ris ‘Supporting Work Orders, Completion Certificates, Invoices and Payment Proofs, Client | Yes/No. Page No |
| Performance Certificates/installation Certificates, if available |
ies i4 | I80 9003:2025 Certificate, Additional Certifications (ISO 4004, ISO 450i, BIS, CE | Yes/No "| PageNo. |
Leto) any 3०342 22000 eee | 25 अं cel
LI5- Package-wise Technical Compliance Matrix (Annexure-tIl) ees Yes/No Page No.
(6 Detailed BOM with Make, Model, Material Grade and Traceability Plan (Annexure-IV)_| Yes/No —_[ Page No.
(77 Product Brochure, Catalogues, Photographs and Technical Datasheets, Engineering ee | Page No. |
| Drawings/Layout/Dimensional Details = >>
ae 38 | Warranty, SLA and Spares Availability Undertaking (Annexure-Vill) | Yes/No PRONE = S|
[49 Bihar Service Office Proof/Service Arrangement Details/Undertaking Yes/No | ‘PageNo. |

20 List of Service Engineers and Contact Details —TresNo ता ——|Yesite [a [PageNo. |
[27_ | Non-Blacklisting Affidavit (Annexure-IX)__ Ree ee ee ees Yes/No PageNo.
[22 | GST Returns (GSTR-38/GSTR-I) for Last Three Months | Yes/No | Page No. |
[23 Undertaking for Establishment of Service Support in Bihar within 30 Days of ~~ | Yes/No “| PageNo.  ——*|
| _|_Empanelment (if applicable) arr. 2 है: |
(24 |"Any other additional documents zs Ee Leo |

Further, it is certified that the information furnished in this Proposal is true and correct to the best of my/our

knowledge and belief. I/We have carefully read and fully understood all terms and conditions of the RFP and

undertake to comply with and abide by the same.

It is also certified that the bidder/OEM has not been blacklisted, debarred, or declared ineligible by any Central

Government Department, State Government Department, PSU, Statutory Body, or Government Agency. Further,

neither the firm nor its proprietors/partners/directors have been convicted in any case involving fraud, corruption,

or misrepresentation.

Page 0
