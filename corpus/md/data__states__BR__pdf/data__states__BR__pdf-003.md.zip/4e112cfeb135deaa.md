---
doc_id: "4e112cfeb135deaa"
source_url: "http://fisheries.bihar.gov.in/docs/MTMV_2026_27.pdf"
ministry: "Directorate of Fisheries, Bihar"
title: "* मुख्यमंत्री तालाब मात्स्यिकी विकास योजना हेतु स्वीकृति आदेश"
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "0c71b54d88b36d79"
---

<!-- no text layer: pending OCR -->
