---
doc_id: "b95edaf54f7b1b6c"
source_url: "https://rmdd.sikkim.gov.in/storage/notification/notificationdoc-KBz7NdnO1DTpvL5mjXNgNBBJYgzOIqp15J6D4qTv.pdf"
ministry: "Rural Development Department, Sikkim"
title: "PIU for RDD under Sikkim INSPIRES"
date: ""
pages: 2
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "5ac0af06a7612408"
---

<!-- page 1 -->

C
\Graisowess
RURAL DEVELOPMENT DEPARTMENT
GOVERNMENT OF SIKKIM, GANGTOK
Ref: No.4. / INSPIRES / RDD pate: [10.8 2.4
NOTIFICATION
Whereas, the priority Departments under Sikkim INSPIRES programme are required to
establish a Project Implementation Unit (PIU), as per clause 2 of the Notification No 05/PDD
dated 21.10.2023 issued by the Planning & Development Department, Government of Sikkim.
Accordingly, Project Implementation Unit (PIU) for Rural Development Department is hereby
constituted with the following members:
1. Additional Secretary, RDD Nodal Officer
2. Director, SIRD Member
3. Chief Executive Officer, SRLM Member
4, All ADC (Dev), RDD Member
5. Deputy Secretary, MGNREGA Sub ~ Nodal Officer
6. Deputy Chief Executive Officer, SRLM Member
7. Deputy Director, MGNREGA : Member
, _sBeputy Director — IT Member
9, Sr. Accounts Officer -SRLM Member
10. Sr, Account Officer cum D&DO Member
11. Sr. Planning Coordinator - MGNREGA Member
12. State Panchayat Coordinator (PRI) Member
13. Sr. Faculty , SIRD Member
14. Program Manager, SRLM Member
15, Deputy Program Manager, Livelihood, SRLM Member
16. MIS Coordinator. SRLM Member

<!-- page 2 -->

/ c
/
f
/ The role and responsibility of the PIU shall be as under;
a. Ensure smooth implementation and timely achievement of targets under Sikkim
INSPIRES
b. Providing support to the PD and the PMU through sharing of ideas, feedback and
ground experiences for improving the programme.
c. Enabling seamless coordination and convergence with other line departments and
agencies in project implementation. .
d. Preparing and submitting progress reports on a monthly basis to the PD.
e. Participating in the preparation of the Annual Action Plans. 2
f. Maintaining records of project activities and utilization of funds.
g. Arranging and coordinating inspections, visits and appraisals by various teams from
World Bank, GOI, GOS and other agencies.
h. Any Other responsibilities which are critical to the achievement of the overall
programme results.
This Notification is in supersession of the earlier Notification issued vide No.
22/RDD/Sikkim INSPIRES dated 8.02.2024
Sd/-
(D. Anandan, IAS)
Principal Secretary
Rural Development Department
Copy to:
. 1. PS to Pr. Secretary - RDD 5
2. PS to Secretary -RDD |
3. Project Director — Sikkim Inspires, PDD Hi
4. All Members
5, Office Copy/ File Z
Deputy Seerdtary (Adm)
Rural Development Department
Government of Sikkim
File No : GoS/RDD/1(517)/2022-23
