---
doc_id: "aedc7ede12e2559f"
source_url: "https://power.sikkim.gov.in/storage/notification/notificationdoc-W4dJU37mUvZNnNJyv7w0LvyR9UgY0wbeMSvy9hVB.pdf"
ministry: "Energy and Power Department, Sikkim"
title: "Office Order dated 29-07-2025"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "899de44fc01ba68a"
---

<!-- page 1 -->

POWER DEPARTMENT,
GOVERNMENT OF SIKKIM, GANGTOK
Dated:

IPower/Adm

No.

OFFICE ORDER

With the approval of the Competent Authority, Shri Tashi Yousal, Chief
Engineer-cum-Head of Office ,Power Department, Government of Sikkim is hereby
designated as the Media Information Officer and Spokesperson for the Department

with immediate effect. He shallbe responsible for briefing the media on all department
related matters through various social media platforms and other communication
channels.

By order

Sd/
Secretary
Power Department
Government of Sikkim

Memo No.

O3

Dated: 3 0 | I S

Copy for information to:
1. Above Officer.

2. Secretary, Power Department

3. All PrincipalChief Engineers, Power Department.
A Joint Director (.T), Power Department.
5. OSD to the Hon'ble Advisor, Power Department.
6. File &

7.

G. File copy.

Deputy 8ecretary

Power Department
Government of Sikkim
Deputy Secretary
Power Deparnent

Government of Sikkim, Gangtok
