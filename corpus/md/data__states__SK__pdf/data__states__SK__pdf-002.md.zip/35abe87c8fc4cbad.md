---
doc_id: "35abe87c8fc4cbad"
source_url: "https://power.sikkim.gov.in/storage/notification/notificationdoc-oFb2sA1CF9238jSIW59TNjwOObRWhHnwTrsmMLSO.pdf"
ministry: "Energy and Power Department, Sikkim"
title: "Notification dated 29-07-2025"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ddc00a038b4a08be"
---

<!-- page 1 -->

POWER DEPARTMENT,

GOVERNMENT OF SIKKIM. GANGTOK

No. 4

Power/Adm

Dated :

2/%+/2025

NOTIFICATION

Whercas, aworkshop was held to pave the way towards providing uninterrupted power

supply in the state capital by March.2026. The meeting was attended by allthe Engineers (HQ)
and staffi s) upto the level of Lineman. Detailed discussions were held to identify the problem
areas and to improve them accordingly. Therefore, with a view to achieve this objective, the

following officers of the Department are hereby assigned the responsibility of preparing a

comprehensive document for onward submission to the Government.

1. Shri P.CSubba, Additional Chief Engineer (HQ-IV)
2. Shri Binod Sharma, Additional Chief Engineer(HQ-II)
3. Shri Sonam T. Kaleon, Additional Chief Engineer (HQ-III)
Terms of Reference for the Committee:

1. The Committee shall discuss the issues with all the concerned Executive Engineers.

2. The Committee shall prepare a Master Plan for Gangtok based on various
shortcomings highlighted.
3. The Committee shall submit its recommendations for system improvement at bare
minimum cost to achieve stable power supply in Gangtok and its surrounding areas.

4. The Committee shall submit a complete report by 18h August,2025.
By order

Sd/

Secretary
Power Department
Govt. of Sikkim

Memo No.

Dated:

Copy for information to:
All above concerned.

2. Secretary, Power Department.

3. AllPrincipal Chief Engineers, Power Department
s Joint Director (1,.T), Power Department.
5. File & G/File copy.

Under Seeretary
Power Department
Govt. of Sikkim
