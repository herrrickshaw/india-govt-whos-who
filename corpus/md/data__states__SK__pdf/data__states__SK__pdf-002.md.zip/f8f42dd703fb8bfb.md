---
doc_id: "f8f42dd703fb8bfb"
source_url: "https://police.sikkim.gov.in/notification/notificationdoc-Tfi3FjvXtv46f1QnnGU3pwZoLA4SwAgQpwIZOB2b.pdf"
ministry: "Police Department, Sikkim"
title: "WHO IS A RESPONSIBLE CITIZEN ON THE ROAD ?"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cb7dda9dd4bcc100"
---

<!-- page 1 -->

Be a Responsible Citizen!
DO NOT throw Debris on the road and roadside!
It is Dangerous!
Clean the road and roadside of all Building Material after Construction.
DO NOT do Roadside Bird/Animal Feeding!
They can be crushed to Death or Maimed by a vehicle!
Feed you must if you feel for them but let them Live and let them be Safe.
Feed at a Distance from road for their Safety if you care for them.
DO NOT Break the Rules and Codes of Safe Driving!
DO NOT let your Driver and other Vehicles Break the Rules either!
DO NOT stand and argue on the road if there is an incident.
It creates Traffic Jam.
Move Away from the Road and then do what you think is right in a situation.
DO NOT display Police, Army, Forest, etc. on Private Vehicles.
It is wrong and exposes the intention of exploiting professional identity for securing
privileges and concessions.
DO NOT tolerate Nonsense!
We have become immune to it!
Be Responsible and Take Charge!

SIKKIM POLICE
Ed. 1-2016
