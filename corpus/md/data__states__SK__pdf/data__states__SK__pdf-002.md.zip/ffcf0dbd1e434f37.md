---
doc_id: "ffcf0dbd1e434f37"
source_url: "https://rmdd.sikkim.gov.in/storage/notification/notificationdoc-vZZgjtIoUHgTZIkKYNgwAVMfZ83RQ9TTEFL74ZIA.pdf"
ministry: "Rural Development Department, Sikkim"
title: "Samriddha Gyalshing, INTEGRATED ECONOMIC INCLUSION ACTION PLAN (IEIAP) under Sikkim INSPIRES"
date: ""
pages: 132
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "33ef2b405f52a7b3"
---

<!-- page 1 -->

<!-- page 2 -->

Samriddha Gyalshing

Integrated Economic Inclusion Action Plan
(IEIAP)
Gyalshing District

Government of Sikkim
Sikkim INSPIRES
Enable I Employ I Empower

<!-- page 3 -->

Gyalshing District IEIAP

Table of Contents
Executive Summary ............................................................................................................ 1
Chapter 1 ............................................................................................................................... 4
Background ........................................................................................................................... 4
1.1. Sikkim INSPIRES Program .......................................................................................... 5
1.2. Program objective ........................................................................................................ 5
1.3. Integrated Economic Inclusion Action Plans (IEIAPs) ................................................... 6
1.4. Rationale for the Development of the District IEIAP ...................................................... 6
1.5. Strategic Focus Areas of the Gyalshing IEIAP ................................................................ 6
1.6. Role of the IEIAP in promoting economic Inclusion for women and youth ............... 6
Chapter 2 ............................................................................................................................. 8
Gyalshing District Profile ................................................................................................... 8
2.1. Geography .................................................................................................................... 9
2.2. Demography ........................................................................................................................... 9
2.3. Socio-economic profile ...............................................................................................10
Chapter 3 ............................................................................................................................12
Methodology for development of IEIAP ............................................................................12
3. Methodology for development of IEIAP for Gyalshing District ................................... 13
Situation Analysis and SWOT of Priority Non-Farm Sectors ......................................... 19
Chapter 4 ........................................................................................................................... 19
4.1 Existing Enterprises and Employment Landscape of the District .............................. 20
4.2. Existing occupation activities .......................................................................................... 21
4.3 Key factors for economic inclusion: current scenario and limitations ..................... 22
Strategic four- year plan for employment and entrepreneurship .................................. 34
Chapter 5 ........................................................................................................................... 34
5.1. Introduction: Background, Purpose, Mission, and Vision .......................................35
5.2. Methodological Pillars of the Planning Process .......................................................35
5.3 IEIAP approach............................................................................................................ 36
5.4 Key interventions .........................................................................................................37
5.5. Institutional arrangements for IEIAP implementation.............................................. 39
5.6. Details of key interventions ....................................................................................... 42
Intervention 1: Promotion of community-based tourism in Gyalshing District with
focus on nature and rural tourism
43
Intervention 2: Support in setting up processing and value addition facilities for
farm products
50
Intervention 3: Strengthening handicrafts sector in Gyalshing District

58

<!-- page 4 -->

Gyalshing District IEIAP

Intervention 4: Promotion of Green SHG Enterprises for production of Reusable
and Ecofriendly Products
65
Intervention 5: Facilitate skill development for youth and women in non- farm
sectors

70

Intervention 6: Strengthen entrepreneurship ecosystem for women and youth
through support in business development, mentorship, and marketing support 77
Intervention 7: Improving infrastructure for marketing and last mile connectivity
for economic inclusion
86
Intervention 8: Awareness and Sensitization on Entrepreneurship and
Employment Opportunities

91

Intervention 9: Strengthening of IEIAP Implementation teams

95

Chapter 6 ........................................................................................................................... 98
Environmental and Social Management System (ESMS) for IEIAP Interventions ........ 98
Budget and Fund flow mechanism ................................................................................. 103
Chapter 7 .......................................................................................................................... 103
Budget and Fund flow mechanism ................................................................................. 104
7.1 Total proposed budget ...................................................................................................... 104
7.2 Convergence mechanism ................................................................................................. 105
7.3 Fund flow mechanism- INSPIRES fund ....................................................................106
7.4 Monitoring Plan for the IEIAP Implementation ............................................................. 108
Chapter 8 .......................................................................................................................... 112
Annual work plan ............................................................................................................. 112
Annual Work Plan for Gyalshing for the first year of IEIAP implementation

113

<!-- page 5 -->

Gyalshing District IEIAP

LIST OF FIGURES
Figure 1: Process flow for development of IEIAP ................................................................ 13
Figure 2: Methodology for development of IEIAP ............................................................................. 14
Figure 3: Key Activities in E&E Survey ............................................................................................. 15
Figure 4: Key Interventions in IEIAP................................................................................................. 36
Figure 5: Institutional arrangements for IEIAP .................................................................................. 42
Figure 6 Flow chart for EDP intervention .......................................................................................... 82
Figure 7: Fund flow mechanism. .................................................................................................... 108

LIST OF TABLES
Table 1: Process flow of IEIAP preparation....................................................................................... 13
Table 2: Details of respondents in Gyalshing District ........................................................................ 16
Table 3: Details of FGDs conducted in Gyalshing District ................................................................. 16
Table 4: Challenges and barriers in policy and program implementation ........................................... 23
Table 5: Challenges and barriers in institutions and processes ......................................................... 24
Table 6:Challenges and barriers in financial access and inclusion .................................................... 25
Table 7: Challenges in Infrastructure, Transport, and Market ............................................................ 26
Table 8: Challenges in capacities and skills ...................................................................................... 28
Table 9: Challenges in Socio-cultural factors .................................................................................... 29
Table 10: SWOT Analysis of Gyalshing’ s non-farm and off-farm sector ............................................ 30
Table 11: Methodological pillars of IEIAP planning process .............................................................. 35
Table 12: IEIAP intervention with Rational, Broad Strategy ............................................................... 37
Table 13: Sites for CBT .................................................................................................................... 44
Table 14: Beneficiary Details for EDP............................................................................................... 78
Table 15: Trainings under strengthening Entrepreneurship ecosystem ............................................. 79
Table 16: Block Level Trainings for IEIAP beneficiaries .................................................................... 80
Table 17: BFC support services ....................................................................................................... 81
Table 18: Environmental and Social Considerations ....................................................................... 100
Table 19: Monitoring Plan ...............................................................................................................110
Table 20: Studies/Assessments ......................................................................................................113
Table 21: Team Members, Potential Dept, Key responsibilities ........................................................114
Table 22: EGs and women engaged ...............................................................................................116
Table 23: Trainings on the 1st Year ..................................................................................................117

List of Abbreviations and Acronyms

<!-- page 6 -->

Gyalshing District IEIAP

Acronyms

Full Form

AIF

Agriculture Infrastructure Fund

ASPIRE

A Scheme for Promotion of Innovation, Rural Industries and Entrepreneurship

ATMA

Agricultural Technology Management Agency

ATMs

Automated Teller Machines

B2B

Business to Business

BACs

Block Administrative Centers

BLT

Block Level Team

C&I

Commerce and Industries

CBO

Community Based Organizations

CFC

Common Facility Centres

CIF

Community Investment Fund

CREI

Climate Resilient Economic Inclusion

CRPs

Community Resource Persons

CSC

Common Service Centres

CSR

Corporate Social Responsibility

CSOs

Civil Society Organizations

DAC

District Administrative Centre

DAY-NRLM

Deendayal Antyodaya Yojana - National Rural Livelihood Mission

DAY-NULM

Deendayal Antyodaya Yojana - National Urban Livelihood Mission

DDU-GKY

Deen Dayal Upadhyaya Grameen Kaushalya Yojana

DC

District Collector

DET

Department of Eco Tourism

DIC

District IEIAP Committee

DIIT

District IEIAP Implementation Team

DHH

Directorate of Handicrafts and Handloom

DLEC

District Level Executive Committee

DSC

District Skill Committee

E&E

Employment and Enterprise

ECOSS

Ecotourism and Conservation Society of Sikkim

EDC

Eco-Development Committee

EG

Enterprise Group

ESSs

Environmental and Social Standards

E-Waste

Electronic Waste

F&ED

Forests & Environment Department

FED

Food and Economic Development

FGDs

Focus Group Discussions

FPOs

Farmer Producer Organizations

FSSAI

Food Safety and Standards Authority of India

FY

Financial Year

<!-- page 7 -->

Gyalshing District IEIAP

Acronyms

Full Form

GP

Gram Panchayat

GPDP

Gram Panchayat Development Plan

GPUs

Gram Panchayat Units

GMC

Gyalshing Municipal Corporation

GoS

Government of Sikkim

GRID

Green Resilient and Inclusive Development

GSDP

Green Skill Development Programme

GST

Goods and Services Tax

HDFS

Human Development Foundation of Sikkim

ICAR

Indian Council of Agricultural Research

ICDS

Integrated Child Development Services

IEIAP

Integrated Economic Inclusion Action Plan

IIP

Indian Institute of Packaging

INR

Indian Rupee

INSPIRES

Integrated Service Provision and Innovation for Reviving Economies

IPF

Investment Project Financing

ITI

Industrial Training Institute

IT

Information Technology

ITeS

Information Technology-enabled Services

JFMC

Joint Forest Management Committee

KIIs

Key Informant Interviews

KPI

Key Performance Indicator

KVIC

Khadi and Village Industries Commission

KVK

Krishi Vigyan Kendra

M&E

Monitoring and Evaluation

MFIs

Microfinance Institutions

MGNREGA

Mahatma Gandhi National Rural Employment Guarantee Act

MIS

Management Information System

MoRD

Ministry of Rural Development

MoU

Memorandum of Understanding

MOVCDNER

Mission Organic Value Chain Development for Northeastern Region

MSME

Micro, Small, and Medium Enterprises

MVP

Minimum Viable Product

MUDRA

Micro Units Development & Refinance Agency

NABARD

National Bank for Agriculture and Rural Development

NAPS

National Apprenticeship Promotion Scheme

NGO

Non-Governmental Organizations

NHPC

National Hydroelectric Power Corporation

NID

National Institute of Design

<!-- page 8 -->

Gyalshing District IEIAP

Acronyms

Full Form

NIFT

National Institute of Fashion Technology

NIFTEM

National Institute of Food Technology Entrepreneurship and Management

NITI Aayog

National Institution for Transforming India

NRLM

National Rural Livelihood Mission

NSDC

National Skill Development Corporation

NULM

National Urban Livelihood Mission

ODOP

One District One Product

ONDC

Open Network for Digital Commerce

PC

Producer Company

PforR

Program for Result

PHCs

Primary Health Centres

PIU

Project Implementation Unit

PMEGP

Prime Minister's Employment Generation Programme

PMEGY

Prime Minister Grameen Express Yojana

PMFME

Pradhan Mantri Formalization of Micro Food Processing Enterprises

PMGSY

Pradhan Mantri Gram Sadak Yojana

PMMUDRA

Pradhan Mantri Mudra Yojana

PMSVANIDHI

Prime Minister’s Street Vendor’s AtmaNirbhar Nidhi

PMKVY

Pradhan Mantri Kaushal Vikas Yojana

PM Vishwakarma Pradhan Mantri Vishwakarma Kaushal Samman Yojana
PRA

Participatory Rural Appraisal

PRI

Panchayati Raj Institutions

PRISM

Promoting Innovations in Individuals, Startups and MSMEs

R&B

Roads and Bridges Department

RA3

Result Area 3

RDD

Rural Development Department

RSETIs

Rural Self Employment Training Institutes

RSETI

Rural Self Employment Training Institute

SC

Schedule Caste

SDD

Skill Development Department

SDG

Sustainable Development Goals

SEH

Sikkim Entrepreneurs' Hub

SFAC

Small Farmers' Agri-Business Consortium

SFURTI

Scheme of Fund for Regeneration of Traditional Industries

SHG

Self-Help Group

SICB

State Institute of Capacity Building

SIRD

State Institute of Rural Development

SME

Small Medium Enterprise

SOP

Standard Operating Procedure

<!-- page 9 -->

Gyalshing District IEIAP

Acronyms

Full Form

SRLM

State Rural Livelihood Mission

ST

Schedule Tribe

SUIDF

Sikkim Urban Infrastructure Development Fund

SULM

State Urban Livelihood Mission

SVEP

Start-Up Village Entrepreneurship Programme

SWOT

Strength, Weakness, Opportunities and Threats

SYSS

Skilled Youth Start-Up Scheme

T&CAD

Tourism and Civil Aviation Department

TISS

Tata Institute of Social Sciences

TRIFED

Tribal Cooperative Marketing Development Federation of India

UDD

Urban Development Department

ULBs

Urban Local Bodies

UPI

Unified Payments Interface

VFX

Visual Effects

VO

Village Organization

WB

World Bank

WDS

Ward Development Society

WEP

Women Entrepreneurship Platform

<!-- page 10 -->

Gyalshing District IEIAP

Executive Summary
Gyalshing District reflects a dynamic socio-economic landscape shaped by rapid urbanization,
demographic diversity, and a gradual shift from agriculture to non-farm livelihoods. Despite its
strategic advantages in tourism, creative industries, and organic agriculture, the district continues
to face structural challenges such as low female workforce participation, youth unemployment, and
limited access to formal enterprise support. These challenges, coupled with the aspirations of local
communities, underscore the need for a comprehensive, inclusive, and future-oriented economic
inclusion strategy. The Integrated Economic Inclusion Action Plan (IEIAP), developed under the
World Bank supported Sikkim INSPIRES program, responds to this imperative with a structured
roadmap to promote equitable, sustainable, and resilient economic growth of women and youth
in the non-farm sectors of the district.


Plan Formulation Process

The IEIAP has been developed using a participatory, bottom-up and evidence-based approach. A
detailed Diagnostic Study provided the foundational understanding of Gyalshing’s non-farm and offfarm economy. This was complemented by an Employment and Entrepreneurship (E&E) Survey
covering over 4,122 respondents, offering granular insights into employment patterns, enterprise
aspirations, and systemic barriers. More than 15 Key Informant Interviews (KIIs) and over 34
Focus Group Discussions (FGDs) were conducted across all blocks, engaging SHG members,
women and youth, entrepreneurs, and community leaders. Multiple multi-stakeholder
consultations brought together government officials, sector experts, civil society representatives,
and local institutions. These exercises informed the identification of sectoral opportunities,
institutional gaps, and community priorities, leading to the prioritization of 09 strategic
interventions.


Objectives

The IEIAP seeks to advance inclusive economic empowerment, foster entrepreneurship, generate
employment, and improve livelihood security for women and youth and underrepresented
groups of the district. The plan aims to address both demand- and supply-side constraints in the
non-farm and off-farm economy, while promoting convergence across departments and schemes to
build a cohesive ecosystem for economic inclusion.


Target Groups and Sectors

The plan focuses on women (18–59 years), and youth (18–35 years), with special attention to
marginalized communities and rural populations. High-potential sectors identified for intervention
include tourism and wellness, creative industries, green jobs, IT and ITeS, agro processing, and
the care economy. These sectors were selected based on their alignment with local aspirations,
resource endowments, enterprise development and employment potential.
 Key Interventions:
The initiative encompasses several key components, each designed to promote inclusive
entrepreneurship, skill development, and sustainable livelihoods across diverse sectors and
communities:

1|P a g e

<!-- page 11 -->

Gyalshing District IEIAP

1.

2.

3.

4.
5.
6.

7.

8.

9.

Community Based Tourism Development: Promoting Gyalshing District as a key tourism
destination through community-based tourism initiatives, introducing concepts such as digital
nomads, trekking trails, and certified training for tourist drivers.
Value Addition and Processing Facilities: Providing support in establishing enterprise groups for
turmeric, cherry pepper, and honey to enhance production and market access. This includes
federating these groups into producer companies and providing training for capacity building.
Souvenir Sector Development: Developing product and skill-based clusters in bamboo craft,
handloom, and traditional wool craft, with a focus on training artisans and establishing common
facility.
Promotion of Green Enterprises: Supporting the production of upcycled and reusable products
through training and common facility centres.
Facilitation for Skilling: Providing training and resources for youth and women in non-farm sector
services, along with tools and equipment for their ventures.
Entrepreneurship Development through Business Development and Market
Linkages: Creating business plans, facilitating market linkages, and establishing a challenge fund
for innovation and entrepreneurship.
Infrastructure Development and Public Transport Services Development: Developing SHG
mart for sale of SHG products and training youth and women in driving and vehicle maintenance,
along with facilitating credit linkages for transport services.
Awareness and sensitization: Conducting community-level workshops, campaigns, and
orientation sessions to build awareness on government schemes, entrepreneurship opportunities,
and livelihood prospects for SHG women and youth.
Strengthening IEIAP implementation team: Building the capacity of district teams and
revitalizing SRLM’s non-farm Sakhis for grassroots mobilization, marketing, and on-ground
implementation support.

 Implementation Strategy:
The successful implementation of the Sikkim INSPIRES initiative relies on the collaboration of various
stakeholders, including government departments, NGOs, community organizations, and private sector
partners. The Project Management Unit (PMU) would oversee the coordination of activities, ensuring
compliance with guidelines and effective monitoring of progress.
The IEIAP outlines 9 strategic interventions across six thematic areas: agro-processing and value
addition’, textiles, handicrafts, and traditional products’, green jobs, tourism and wellness’,
entrepreneurship and skill development in non-farm sectors’, and ‘transport and connectivity’.


Strategic Framework

The Strategic Four-Year Action Plan (2025–2029) provides a phased implementation roadmap for
all 9 interventions. It includes objectives, detailed timelines, activity plans, and year-wise financial
allocations to ensure systematic rollout, implementation, and adaptive learning. The Annual
Action Plan for FY 2025–26 outlines the first-year priorities with a financial allocation of 348.80
lakh (₹203.80 lakhs from Inspires and ₹145 lakhs from Convergence). Key activities in the first year
include the formation of enterprise groups, training of artisans and SHG members, feasibility
studies for green enterprises, and the launch of mentorship and innovation challenge programs.
 Financial Outlay:
The total financial outlay for the IEIAP stands at ₹2318.16 lakh. Of this, ₹1,314.66 lakh is allocated
under the Sikkim INSPIRES (RDD) project, while ₹1003.50 lakh is expected through convergence
2|P a g e

<!-- page 12 -->

Gyalshing District IEIAP

with schemes such as FED/Tourism, AIF, PMFME, SFAC, 10KFPO, SFURTI, ASPIRE, Startup
Sikkim, and others. Out of the total proposed outlay of ₹1,314.66 lakh, ₹1000.00 lakh would be
provided from the Rural Development Department (RDD) funds, and the balance amount would be
supported as the Flexi Fund.
Sector
Off-farm value addition
Souvenir sector
Green enterprise
Skilling
Community based tourism
Entrepreneurship ecosystem
Infrastructure and last mile connectivity
Sensitization and awareness
Strengthening IEIAP implementation
Total

Total Allocation
₹ 275.90 lakh
₹213.78 lakh
₹143.26 lakh
₹ 284.00 lakh
₹775.80lakh
₹266.82 lakh
₹166.50 lakh
₹49.50 lakh
₹142.60 lakh
₹1958.16 lakh

Expected Outcomes and Impact
The IEIAP is expected to directly benefit over 2000 individuals, with a strong emphasis on women
and youth. The plan supports the creation or strengthening of over 300 enterprises and anticipates
the generation of more than 1,000 direct and indirect employment opportunities. Additional
outcomes include a projected 10–20% increase in average incomes among beneficiaries, improved
access to digital and financial services, and enhanced social infrastructure to support economic
participation.


Implementation Structure

The Rural Development Department (RDD) along with the Department of Eco- Tourism (DET)
would anchor implementation, supported by the District Administrative Centre and the District
IEIAP Committee, in collaboration with partners such as SRLM, SIRD, the Skill Development
Department, the Directorate of Handicrafts and Handloom, private sector actors, NGOs,
community-based organizations (CBOs), and local bodies. The successful implementation of the
Sikkim INSPIRES initiative relies on the collaboration of various stakeholders, including government
departments, NGOs, community organizations, and private sector partners. The Project Management
Unit (PMU) would oversee the coordination of activities, ensuring compliance with guidelines and
effective monitoring of progress.


Monitoring and Evaluation

A result-based monitoring framework would be prepared, including monthly progress tracking,
quarterly reviews, annual impact assessments, and mid- and end-term evaluations. Key
performance indicators (KPIs) track progress in employment generation, enterprise formation,
income enhancement, and inclusion of outcomes. Community feedback mechanisms would
ensure responsiveness and adaptive learning.
The IEIAP depends on active collaboration among government departments, civil society, private
sector partners, and local communities. Centering women and youth in its vision and execution,
the plan would set a precedent for participatory and sustainable development in Sikkim and offer a
replicable model for other states.
3|P a g e

<!-- page 13 -->

Gyalshing District IEIAP

Chapter 1

Background

4|P a g e

<!-- page 14 -->

Gyalshing District IEIAP

1.1. Sikkim INSPIRES Program
The Government of Sikkim (GoS) has recognized the urgent need to create employment opportunities
for women and youth, drawing insights from various policy initiatives such as the Sikkim Micro, Small
and Medium Enterprises Policy 2022, State Tourism Policy 2018, Eco-Tourism Policy 2011, and
Information Technology, Electronics and Telecommunication Policy for the State of Sikkim 2021. To
support its reform agenda under the State’s Economic Growth Strategy 2022, the GoS has emphasized
promoting economic inclusion opportunities for women and youth in non-farm sectors.
In response, the GoS has launched the Sikkim Integrated Service Provision and Innovation for Reviving
Economies (INSPIRES) program, a Program for Results (PforR) initiative with funding support from the
World Bank (WB). This program aims to attract private sector investments, identify priority interventions
to prepare a workforce ready for priority sectors, and address employment and entrepreneurship
barriers, particularly for women and youth in non-farm sectors.
The INSPIRES program aligns with the World Bank Country Partnership Framework FY18-22 and the
State’s Economic Growth Strategy 2022. It adopts a pan-economy, pan-government approach to deliver
improved economic opportunities for women and youth. The program operates under two financing
modalities: Program for Results (PforR) and Investment Project Financing (IPF). The total program cost
is $216.40 million, with $100 million provided by the World Bank over five years (FY2024-25 to FY202829).
The INSPIRES Program aims to support the Government of Sikkim's efforts to enhance economic
inclusion for women and youth. It adopts a pan-economy, pan-government approach to improve
economic opportunities by addressing growth and governance challenges. Key initiatives include:







Expanding strategy and coordination: Strengthening strategy, planning, and coordination at the
state level to engage across departments, levels of government, and the private sector for inclusive
growth.
Skill training investments: Focusing on short-term skills training in non-cognitive skills, digital
readiness, socio-emotional skills, and providing placement support in priority sectors.
Enterprise growth support: Promoting growth for women-led and youth-led enterprises in nonfarm and priority sectors through financial, technical, and business development support. This
includes linking household enterprises with SMEs and encouraging new enterprises to enter
service and manufacturing segments within priority sectors.
Enabling services: Enhancing the delivery of services in mental health, digital readiness, mobility,
and care services.

The program targets women (18–59 years), youth (18–35 years), and adolescents (10–19 years) in
Sikkim.

1.2. Program objective
The key objective of the program is to promote economic inclusion opportunities for women and
youth in non-farm sectors. The program aims to train, upskill, and provide employment opportunities
to women and youth in high-growth priority sectors like Tourism, Hospitality and Wellness, IT and ITeS,
Creative Economy, Green Jobs, and Child and Elderly Care. The program's objective-level results
indicators include:
 Strengthened state systems to deliver inclusive growth: Improved systems of the state to
support employment outcomes for women and youth.
 Enhanced entrepreneurship in priority sectors for women and youth (18-35 years).
 Employment in priority sectors: Employment of female and male trainees in priority sectors,
disaggregated by gender.
5|P a g e

<!-- page 15 -->

Gyalshing District IEIAP

 Comprehensive care and safety: Creation of a comprehensive care and workplace safety
system.

1.3. Integrated Economic Inclusion Action Plans (IEIAPs)
Under Result Area 3 of the program, the focus is on enhancing the delivery of enabling services to
promote economic inclusion outcomes for women and youth through the development and
implementation of Integrated Economic Inclusion Action Plans (IEIAPs) at the district level. These plans
aim to promote employment and entrepreneurship among women and youth at the district level. The
purpose of IEIAPs is to converge ensure planning across levels and coordinate the implementation of
economic inclusion initiatives. IEIAP for the Gyalshing district is designed to ensure that the identified
interventions and investments are strategically aligned to create meaningful economic opportunities,
especially for women and youth of the district.

1.4. Rationale for the Development of the District IEIAP
The Gyalshing IEIAP has been designed to converge investments, schemes, and institutional efforts
across relevant departments to create an enabling ecosystem for economic inclusion. It aligns with the
State’s Inclusive Growth Strategy and builds local opportunities in eco-tourism, digital services, creative
livelihoods, and enterprise development. The plan gives priority to women (18–59 years), youth (18–35
years), and adolescents (10–19 years), who are identified as the primary beneficiaries of the
interventions.

1.5. Strategic Focus Areas of the Gyalshing IEIAP










Convergence of programs and resources: Unifies existing schemes and initiatives across
departments and stakeholders to avoid duplication and enhance efficiency.
District-specific economic solutions: Responds to Gyalshing’s local opportunities and
challenges, including promotion of eco-tourism, digital livelihoods, and creative economy.
Entrepreneurship and skilling support: Supports women-led and youth-led enterprises
through technical, financial, and business development assistance in non-farm sectors.
Enabling infrastructure and services: Addresses barriers such as care responsibilities,
mobility, and digital exclusion through investment in enabling infrastructure and services.
Citizen-centric and inclusive planning: Incorporates bottom-up planning through direct
engagement with communities, especially women and youth, to ensure relevance and
ownership.
Inter-departmental coordination and accountability: Led by the Rural Development
Department (RDD) and Directorate of Eco-Tourism (F&ED), with active collaboration from
departments such as C&ID, SDD, and T&CAD to enable coordinated implementation and
monitoring.
Monitoring and results tracking: Utilizes a common M&E framework to track progress against
defined results, ensuring alignment with INSPIRES Program objectives and adaptive course
correction.

1.6. Role of the IEIAP in promoting economic Inclusion for women and youth
The IEIAP for Gyalshing District has been developed as a strategic plan to promote employment and
entrepreneurship opportunities for women and youth in non-farm sectors. In alignment with the
Government of Sikkim’s INSPIRES Program, supported by the World Bank, the formulation and
implementation of district-level IEIAPs is a mandated requirement under Result Area 3 (RA3). These
plans aim to ensure that economic inclusion efforts are targeted, convergent, and responsive to the
unique socio-economic context of each district.
The IEIAP places women and youth at the centre of local economic transformation. It aims to promote
demand-responsive interventions that empower them to establish and expand enterprises across
6|P a g e

<!-- page 16 -->

Gyalshing District IEIAP

priority non-farm sectors, including eco-tourism, creative industries, wellness, care services, and
the green economy. Investments focus on entrepreneurship development, skills training, business
incubation, and support for both individual and collective enterprises, fostering a robust
ecosystem for sustainable livelihoods.
The IEIAP enables convergence across departments, ensuring that schemes and resources are
effectively integrated and targeted. It incorporates mechanisms for citizen engagement and social
accountability, strengthening responsiveness and ensuring that the community's needs, especially
those of women and youth remain central to the implementation process. This inclusive and
coordinated approach would foster meaningful participation, enhancing the capacity of women and
youth in economic activities.
The IEIAP is a foundational instrument to promote economic inclusion strategies on the ground. By
addressing both demand- and supply-side constraints, the plan serves as a pathway for unlocking
income and employment opportunities for women and youth in the district’s evolving non-farm
economy. It reflects the State’s inclusive growth vision; it is also a critical delivery mechanism under
RA3 of the INSPIRES Program.

7|P a g e

<!-- page 17 -->

Gyalshing District IEIAP

Chapter 2

Gyalshing District
Profile

8|P a g e

<!-- page 18 -->

Gyalshing District IEIAP

2.1. Geography
Sikkim, a small landlocked state situated in the Himalayan region, is known for its rich biodiversity and
mountainous terrain. Administratively, the state is divided into six districts: Gangtok, Mangan, Namchi,
Gyalshing, Pakyong, and Soreng with the districts of Pakyong and Soreng established following a
reorganization in December 2021. Each district has its respective administrative headquarters—
Gangtok, Mangan, Namchi, Gyalshing, Pakyong, and Soreng which are further divided into 16
subdivisions.
Gyalshing was formed from the reorganization of the erstwhile West District in 2022 vide Government of
Sikkim Gazette Notification published on 20 December 2021. The district is the second largest in the
state and is divided into three sub-divisions, namely Gyalshing, Dentam and Yuksom, five Block
Administrative Centres (BACs), comprising a total of 33 Gram Panchayat Units (GPUs) and 129
villages. It has one Nagar panchayat, namely Gyalshing Nagar Panchayat, divided into 5 wards.
The area of the district is 872 sq.km and it lies between 27.17’ North latitudes and 88.15’ East longitude.
It shares a boundary with Rangit Khola and Rongdong Chhu in the east, Rukel Chu in the North,
Rhododendron Sanctuary Boundary (Soreng District Boundary) in the South and a strategic boundary
with Nepal in the east making it an important area for national security and border management.
According to the ISFR report of 2023, the erstwhile West Sikkim district has a forest area of
approximately1.166 km2, covering very dense forest is 250.92 km2, of moderately dense forest 370.56
km2, and of open forest 168.13 km2. Its main physiographic units consist of hills, mountains, and
valleys.
As per the Forest Survey of India (FSI) Report 2021, the forest cover in Gyalshing spans across
51897.7152 ha, out of which, moderately dense forests (40–70% tree canopy) account for 24,882.28
ha, followed by very dense forests (≥70% canopy) at 16,523.19 ha and open forests (10–40% canopy)
at 10,492.24 ha. Scrub lands, where canopy density is below 10%, occupy 4,029.81 ha, while nonforest and water bodies comprise 28,348.88 ha and 183.69 ha respectively.
The district’s protected areas, including the Barsey Rhododendron Sanctuary (approximately 104 sq.
km), form critical habitats spanning altitudes from around 2,000 to over 4,000 meters. These forests and
alpine meadows host a rich variety of flora such as rhododendrons-including the state flower of Sikkim,
Rhododendron niveum-orchids, conifers like pine and fir, and numerous medicinal and aromatic herbs.
The sanctuary is also a refuge for diverse fauna, including elusive species like the red panda,
Himalayan black bear, leopard cat, Himalayan yellow-throated marten, and a wide array of birdlife such
as the monal pheasant and blood pheasant.

2.2. Demography
The district has majority Nepali population, along with them, Lepchas and Bhutia are the other two
dominant communities. According to the 2011 Census, the district had a population of 71,675, with a
notable urban-rural distribution of 4,013 individuals residing in urban areas and 67,662 in rural areas.
Over the years, the demographic landscape of Gyalshing District has evolved significantly over the
years. Between 2001 and 2011, the population increased from 64,419 to 71,675, reflecting a growth
rate of 11.26%, with the urban population more than doubling from 828 to 4013, representing a rise of
384.66%. In contrast, the rural population experienced a slight increase of 6.4% i.e. from 63,591 in
2001 to 67,662 in 2011. This trend would be attributed to the demand for labor in urban industries,
which has led to net out-migration from rural areas.
However, according to the 2011 census, the districts overall sex ratio stands at 925 females per 1000
males, with 67.7% literacy rate. In terms of social categories, SCs comprised 4.73% (3,391) and STs
9|P a g e

<!-- page 19 -->

Gyalshing District IEIAP

44.416% (31,847) of the district's population. This distribution underscores the balanced presence of
SC and ST communities, contributing to the district's cultural diversity and socio-economic structure.
Overall, the demographic trends in Gyalshing District reflect the ongoing processes of urbanization,
migration, and community diversity, shaping the region's socio-economic landscape and influencing
service delivery and resource distribution to meet the increasing demand.

2.3. Socio-economic profile
According to the 2011 Census, Gyalshing District has a workforce participation rate of 38,639, with
approximately 76.4% as main workers, indicating a stable economic base and around 18.6% classified
as marginal workers that face economic vulnerability due to their engagement in seasonal or part-time
work.
While, the non-working population totaled 33,036 individuals, 46.09% of the population remains
disengaged from economic activities, with women constituting 17,735 of this group, reflecting broader
social dynamics where women often face constraints due to household responsibilities and limited
access to formal job markets.
The occupational structure reveals a high dependence on agriculture, with cultivators comprising
63.74%. Gender dynamics show that men dominate the main workforce, making up 61.08% of main
workers, while women represent a larger share of the non-working population at 53.06%. This gender
disparity highlights barriers such as limited skills and socio-cultural constraints that hinder women's
participation in the workforce.
The economy of Gyalshing district in Sikkim is primarily rooted in the primary sector, with agriculture
serving as the mainstay of livelihoods and employment. Despite its challenging terrain of rocky slopes
and uneven landscapes that restrict cultivable land, farming continues to support most of the
population. The district produces ginger, oranges, vegetables, paddy, maize, millet, and pulses.
However, geographic and physiographic constraints have limited the impact of modern agricultural
technologies, prompting a gradual shift toward alternative farming systems more suitable for hilly
terrains.
Horticulture has emerged as a promising sector, with fruits such as orange, guava, banana, kiwi, and
papaya significantly contributing to household incomes and the district economy. Livestock rearing
further supplements rural livelihoods, reinforcing the agrarian base.
In the non-farm sector, Gyalshing district’s economy is dominated by micro and small enterprises, with
1,648 units registered under UDYAM, of which 99.6% are micro enterprises, reflecting limited scope for
enterprise scale-up and low formalisation. Economic activity is concentrated in food retail, small
groceries, tailoring, handicrafts, household-based food processing, tourism and hospitality services,
supported by a strong SHG presence engaged in incense, snacks, pickles, khada, bamboo craft, and
homestays. The E&E Survey of 4,122 respondents shows significant labour market challenges: 44.5%
are non-working, 25.8% engaged in seasonal or part-time work, and only 15% self-employed, with just
7% in private or MSME jobs.
Tourism remains the largest non-farm employer—accounting for nearly 40% of reported occupations—
followed by grocery/fast-food shops, food processing, beauty and wellness, and a growing cluster of
creative and digital services. Block-level consultations indicate strong potential for scaling tourismlinked services, bamboo and green enterprises, digital content creation, tailoring, and micro food
processing, especially among women and youth. However, enterprise growth is hindered by limited
market linkages, digital and financial access gaps, poor infrastructure, and mismatched skills. Overall,
Gyalshing’ s socio-economic profile is marked by a highly informal, women-led microenterprise
ecosystem, an expanding but under-supported non-farm sector, and a clear need for targeted skilling,
enterprise development, and market integration to unlock inclusive economic transformation

10 | P a g e

<!-- page 20 -->

Gyalshing District IEIAP

Overall, Gyalshing’ s economy remains largely agrarian, but with growing potential in horticulture,
sustainable tourism, and hydropower to fuel inclusive development.
At the state level, the Government of Sikkim has articulated its long-term vision of building a self-reliant
state, as outlined in the Second Session (Part-III) of the Eleventh Assembly (Budget Session 2025–26).
Tourism has been identified as a priority sector, with emphasis on sustainability that balances economic
opportunity with conservation of natural and cultural resources. In the education sector, new legislative
initiatives—such as the Atal Bihari Vajpayee Skill University Bill, 2025 (Bill No. 13 of 2025) and the
Fusion University Sikkim Bill, 2025 (Bill No. 15 of 2025)—aim to strengthen higher education and skill
development, equipping youth with industry-relevant capabilities aligned with the state’s socio-economic
priorities.
In this context, Gyalshing holds significant potential to emerge as a hub of economic transformation,
with opportunities for entrepreneurial expansion, job creation, and greater resilience for women and
youth in the non-farm economy, contributing meaningfully to Sikkim’s broader vision of inclusive and
sustainable growth.
Gyalshing district is steadily carving a niche for itself on the tourism map, attracting visitors with its
blend of natural beauty, cultural heritage, and adventure offerings. Known for its monasteries such as
Pemayangtse and Sanga Choeling, the historic Rabdentse Ruins, and the serene landscapes of
Khecheopalri Lake, the district offers a rich mix of pilgrimage, eco-tourism, and trekking opportunities.
Adventure seekers are drawn to its high-altitude trails and birdwatching sites, while village-based
tourism is gaining popularity as travellers seek authentic cultural experiences. Improved connectivity
through road expansion and tourism circuits has boosted tourist inflows, further enhancing Gyalshing’s
appeal as a vibrant tourism hub.
This growing influx of visitors has energized the local hospitality sector, leading to the expansion of
hotels, homestays, and community-based tourism enterprises. The rising demand for infrastructure has
also spurred employment in construction, transport, food services, handicraft markets, and travelrelated services, thereby strengthening local enterprises and livelihood opportunities.
Micro and small enterprises in handicrafts, agro-based products, and retail trade form an integral part of
Gyalshing’s economy. However, the scope of these is limited and would be explored for contributing to
the district’s economy. With continued policy support and improved infrastructure, Gyalshing holds
promise for building a resilient and inclusive tourism economy that is deeply rooted in community
participation and sustainable practices.
At the same time, Gyalshing has untapped potential to expand service-based enterprises, strengthen
retail trade, and create new opportunities for skilled youth in high-potential sectors like eco and villagebased tourism, agro-processing, and creative industries. By leveraging these opportunities, the district
would further diversify its economy and build a stronger foundation for women and youth employment.

11 | P a g e

<!-- page 21 -->

Gyalshing District IEIAP

Chapter 3

Methodology for
development of
IEIAP

12 | P a g e

<!-- page 22 -->

Gyalshing District IEIAP

3. Methodology for development of IEIAP for Gyalshing District
The Integrated Economic Inclusion Action Plan (IEIAP) for Gyalshing District was developed through a
systematic, participatory, and data-driven methodology. The drafting process comprised four main
stages: Situational Analysis, Stakeholder Consultations, Plan Development, and Validation &
Finalization. Each stage employed qualitative and quantitative tools to ensure the resulting plan was
grounded in local realities and tailored to the unique context of the district.

3.1 Process flow for development of IEIAP

Figure 1: Process flow for development of IEIAP
Table 1: Process flow of IEIAP preparation

Method
District-level
Diagnostic Study

Details
Review of reports, plans and
other relevant documents

Employment &
Entrepreneurship
(E&E) Survey
Focus Group
Discussions
(FGDs)
Key Informant
Interviews (KIIs)

Conducted at the household
level across the district
Held at GPUs or ULBs with
various community groups
Interviews with local leaders,
government officials, industry
experts, and financial
institution representatives

Insights
Promising sectors were identified, revealed
constraints like absence of local
processing units and inadequate transport
Employment status, livelihood activities,
skill availability, enterprise aspirations,
access to finance, and mobility constraints
Validated survey findings, enriched
planning with behavioral and socio-cultural
perspectives
Provided insights into institutional
capacities, policy implementation
challenges, and emerging economic trends
13 | P a g e

<!-- page 23 -->

Gyalshing District IEIAP

Stakeholder
consultations

Including government
agencies, private sector
representatives, civil society
organizations, and community
leaders

Facilitated collaborative dialogue, validated
findings, prioritized interventions, fostered
ownership of the IEIAP

3.2 Methodology for development of IEIAP
The methodology for drafting of the IEIAP followed these key steps:
3

2

1
Situational Analysis

IEIAP Development

Validation and finalization

District Diagnostic Study and
Benchmarking

Consolidation workshops with
DPT members

State level Consultation on key
interventions

Key Activities

Employment and Enterprise
survey

Focus Group Discussions

Harmonization and
synthesis
District Level IEIAP
Consultation

Key Informant Interviews

Consultations with youth and
women

Drafting of the IEIAP

Presentation to PGC and
approval

Prioritization of
activities

Online Feedback (from general
public)

Convergence
discussion with
Departments

Approval of the IEIAP by the
District Committee

Figure 2: Methodology for development of IEIAP

3.2.1 Situational analysis
a) District Diagnostic Study and Benchmarking
The main objective of the District Diagnostic was to assess the status of the district across several
dimensions including demographic and socio-economic profile, infrastructure, connectivity, mobility,
financial inclusion, infrastructure, non-farm economic activities. It also assessed the characteristics of
existing enterprises, their associated skills and value chain.
This analysis played a crucial role in highlighting gaps and development needs, as well as in identifying
sectors with high growth potential. It focused on economic participation challenges faced by youth and
women, laying the groundwork for targeted interventions in the IEIAP.
b) Employment and Enterprise survey
A key part of the situation analysis was the Employment and Enterprise (E and E) survey that was
rolled out across all Gram Panchayats in the district. It was designed with the objective of getting
detailed insights into employment status, key livelihood activities, skill availability, enterprise aspirations,
access to finance, mobility constraints, the barriers to economic inclusion and key suggestions.

14 | P a g e

<!-- page 24 -->

Gyalshing District IEIAP

Figure 3: Key Activities in E&E Survey

To conduct the E and E survey, enumerators were identified from every Gram Panchayat Unit by the
Rural Development Department who were trained in the survey techniques. A district level coordinator
was also nominated by the department for overall supervision and monitoring of progress. The survey
was conducted with the use of the open-source tool Kobo Collect for easy data capture and collation.

The E and E survey mainly targeted households with SHG women and youth and eliminated affluent
households as well as households with all members employed in the Government.
Inclusion Criteria




Households with SHG-affiliated women or youth aged 18–35 years
Low-income and marginalized households, particularly those identified as Below Poverty Line
(BPL)
Non-SHG youth enterprises, to broaden representation and capture diverse entrepreneurial
experiences

Exclusion Criteria
Households without women or youth in the 18–59 age group
Affluent households, including those of MPs, MLAs, or large business owners

Households where all members are employed full-time in government jobs
Households primarily engaged in agriculture, to maintain the survey’s focus on non-farm sectors.



Using these criteria, the enumerators listed out eligible households for their Gram Panchayats in
consultation with the Panchayat Offices, to provide an accurate understanding of the households to be

15 | P a g e

<!-- page 25 -->

Gyalshing District IEIAP

targeted. The survey was conducted from 20 January 25 – 28 February 25. A total of 4122 respondents
participated in the E and E survey for Gyalshing.
Table 2: Details of respondents in Gyalshing District

Age Group

Total

Female
(%)

Male
(%)

18-35 years
36-59 Years

Gender
Femal
Male
e
1319
1180
1623
0

2499
1623

52.7%
100%

47.2%
0%

Total
% out of total respondents (18-35 years)
% out of total respondents (36-59 years)

2942
32.0%
39.4%

4122
60.6%
39.4%

71.3%

28.6%

c) Focus Group Discussions
Focus Group Discussions (FGDs)
were held at GPUs or ULBs with
various community groups, including
self-help groups (SHGs), youth
collectives, informal workers, and
members of local governance
bodies. To conduct the FGDs, a
District Planning Team was formed
by the district consisting of district
officials representing SIRD, SRLM,
RDD, Gyalshing Municipality and the
District Administrative Centre.

1180
28.6%
0

Table 3: Details of FGDs conducted in Gyalshing District

Summary of FGD’s Coverage
Total GPs covered:
Total ULB’s covered:
Total FGDs conducted:
Participants:
1. Total participants
2. Average participants per FGD
Participants Profiles
No. of Elected representatives
No. of SHG/ Women groups
No. of Women members
No. of Youth members
No. of CBOs and members

Details (in No.)
33
1
34
1118
31
174
480
730
570
75

The DPTs underwent 2-day training
on the FGD design and the process
for conducting along with formats for recording the FGD outputs. FGDs were designed to capture
general understanding of natural resource availability, the key challenges for employment and
entrepreneurship development, current and potential economic activities of the GPs along with the
challenges and barriers. FGD discussions validated the E and E survey findings and enriched the
planning process by adding behavioral and socio-cultural perspectives. They underscored a strong
demand for flexible work opportunities, a willingness among women and youth to engage in sectors like
tourism, media, and care services, and a preference for collective enterprise models that foster
collaboration and shared growth.
d) Key Informant Interviews (KIIs)
KIIs were conducted with government officials, industry experts, NGO members, entrepreneurs, and
representatives of financial institutions for their critical qualitative insights into institutional capacities,
policy implementation challenges, and emerging economic trends. These interviews helped identify
systemic bottlenecks and opportunities for strengthening support mechanisms, ensuring that the
interventions are aligned with both ground realities and strategic priorities at the district and state levels.
A total of around 35 KIIs were conducted with various stakeholders who provided district specific inputs
as well as sectoral inputs that were relevant for the entire state.

e) Consultations with youth and SHGs
SHG consultation: These were conducted as part of the IEIAP drafting process to seek specific inputs
from the target groups at the district level. SHG consultation was held for 3 districts of Gyalshing,
16 | P a g e

<!-- page 26 -->

Gyalshing District IEIAP

Namchi and Soreng together at State Institute of Rural Development and Panchayati Raj on 25 July
2025. Group discussions were facilitated to understand the status of SHGs, their achievements, key
barriers and potential economic activities.
Youth consultation: Youth consultation was organized status on with the District Administrative Center
with participation of more than 50+ senior students of 2 colleges from Gyalshing District on 12 August
2025. A survey form was used to capture the opinions of the youth about their challenges and
aspirations.

3.2.2 IEIAP Development
a) District Consultations
The first district consultation meeting was held for Gyalshing district on 12 August 2025 with the
participation of the IEIAP committee, other line departments, district administration chaired by the DC.
The main objective of the consultation was to take input from the district stakeholders for the IEIAP. The
findings from E and E survey and diagnostic survey were presented to the participants. The FGD
findings were also shared by the District Planning Team members which provided the overall context
and the potential sectors that were emerging for the district. The district officials and other stakeholders
provided further inputs and ideas for potential sectors for the districts.
The findings from E and E survey and diagnostic survey were presented to the participants. The FGD
findings were also shared by the District Planning Team members which provided the overall context
and the potential sectors that were emerging for the district. The district officials and other stakeholders
provided further inputs and ideas for potential sectors for the districts.
Discussions highlighted challenges related to branding, market linkages, and common infrastructure
facilities, with suggestions for targeted support in these areas. In addition to positioning Gyalshing as a
distinctive destination for new-age travelers, stakeholders also emphasized a matrimonial service as a
unique opportunity. The need for greater awareness of government schemes and programmes,
particularly those supporting entrepreneurship, was strongly underlined. Mentorship and apprenticeship
programs for youth were identified as a long-term priority, alongside initiatives to equip young people
with essential digital skills.
b) Harmonization and synthesis
Harmonization of all the inputs coming from E and E, FGDs, and other consultations was a critical part
of the planning process.
The GP level FGD reports were compiled at the block level by the DPT members which were further
collated at the district level. A consolidation workshop was organized with the DPT members on 4 July
2025 to bring together and conduct a preliminary prioritization of the interventions. Key interventions
that were emerging were listed out and each of the interventions were discussed in terms of status,
potential for engaging women and youth, raw material availability, etc. and for developing strategies and
detailing out the targeted activities. The institutional mechanisms for conducting the activities,
possibilities for convergence and the potential clusters were also discussed by the District Planning
Team.
Besides the economic interventions, factors such as policy support, capacities, infrastructure and
mobility, financial and socio-cultural issues that influence economic inclusion of women and youth were
also closely reviewed for a deeper understanding and to formulate specific interventions in the IEIAP.
17 | P a g e

<!-- page 27 -->

Gyalshing District IEIAP

c) Prioritization exercise
Prioritization exercise for finalizing the key interventions to be included in the IEIAP from among all the
listed interventions was conducted at the district level by the District Planning Team and the District
IEIAP committee through a final stakeholder consultation on 12 August 2025. The consolidated sectors
and interventions emerging from the E and E survey, FGDs and other stakeholder consultations were
presented to the relevant stakeholders for a final review.
The key interventions to be prioritized were identified using various criteria such as potential for
engagement of women and youth, existing skills, existing programmes for convergence among others.
Following this discussion, internal meetings with the core DAC team, RDD and SRLM, were also used
to narrow down on the ley focus areas.

3.2.3 Validation and Finalization
A State-level consultation was organized on 6th January 2026 with the involvement of the Project
Management Unit and relevant departments. The draft interventions from the IEIAP were presented by
the Gyalshing District Collector. Inputs regarding convergence opportunities were sought from
participating departments, and the draft plan was subsequently circulated for additional feedback.
Based on the inputs received, the draft IEIAP was finalized.

18 | P a g e

<!-- page 28 -->

Gyalshing District IEIAP

Chapter 4

Situation Analysis
and SWOT of
Priority Non-Farm
Sectors

19 | P a g e

<!-- page 29 -->

Gyalshing District IEIAP

4. Status of economic inclusion for women and youth
Gyalshing district presents an extremely underdeveloped and underutilized scenario in the non-farm
sector. The rural economy is mostly agrarian with people mostly employed in the government sector.
Non-farm sector mostly includes activities related to small service and trading-based occupations and
agri allied value chains with micro-enterprises focused on these. Insights drawn from the Diagnostic
Study, E&E Survey (2025), and stakeholder consultations under the IEIAP point to both sectoral
concentration and untapped local potential across the non-farm sector.
Assessing the landscape of economic inclusion and identifying the primary barriers faced by women
and youth in Gyalshing district was a crucial aspect of the IEIAP formulation process. A comprehensive
analysis of the current state of economic inclusion and the associated challenges was conducted to
guide the interventions to be included in the IEIAP
The key findings regarding the status of employment and enterprise in Gyalshing district are
summarized below:

4.1 Existing Enterprises and Employment Landscape of the District
 Micro and informal enterprise dominance
Secondary data from the diagnostic study has indicated that Gyalshing has 1,648 formally registered
enterprises under the UDYAM Portal, with 1,642 categorized as micro enterprises and only 6
classified as small, while none fall under the medium category. These are primarily engaged in food
retail, tailoring, handicrafts, informal trade, and other consumer services. The scenario indicates a
narrow pipeline for enterprise graduation, formal scale-up, and productivity enhancement.
 Employment structure and participation patterns
According to Census 2011, Gyalshing district had 29,527 main workers (76.4%) and 9,112 marginal
workers (23.2%), with over 23% employed in non-agricultural occupations showing a lack of
diversity in the livelihoods practiced.
The E&E Survey covered a total of 4122 persons (female – 2942, male – 1180) and was targeted
specifically at SHG women along with youth using exclusion criteria. The findings reflect the following
on their employment status.




44.5% of the surveyed individuals (1835 out of 4122) reported themselves as non-working,
including homemakers, job seekers and not in the labor force.
Only 15% are identified as self-employed and 7% are employed in private/nonfarm/MSME
sector concentrated mostly in informal services, food processing, and support roles.
Part-time or seasonal employment is 25.8%, indicating livelihood volatility and
underemployment.

This highlights key challenges identified that includes scarcity of local job opportunities, insufficient
career advancement prospects, and mismatches between skills and job requirements, further
exacerbated by skilling gaps and limited access to enabling services.
 Gender and youth employment dynamics
In the E&E survey out of 4,122 respondents, 71.3% were women and 28.6% were men. Among
women, 27% identified as homemakers, while 15% were self-employed. Currently, only 5% of
women and 1.8% of men in are employed in the private or MSME sectors, indicating limited
participation in formal sector employment. Additionally, 22.5% of women and 17% of men reported
being unemployed and actively seeking work, indicating a strong demand for employment.
In challenges faced by women and male in their current and previous employments, limited local job
opportunities significantly impact employment, affecting 42% of women and 41% of men. In
addition, 29% of women and 31% of men report a lack of career advancement prospects,
hindering professional growth. A notable mismatch between educational qualifications and job
20 | P a g e

<!-- page 30 -->

Gyalshing District IEIAP

requirements further complicates employment for 7% of women of men. Women face distinct
challenges, with 11.3% struggling to balance work and family responsibilities, 2% citing safety
concerns, and 4.5% encountering social pressures to prioritize domestic roles. Addressing these
barriers through targeted interventions, such as localized job creation, skill alignment programs, and
supportive policies for women, is critical to fostering inclusive economic growth.

4.2. Existing occupation activities
Gyalshing recorded a labor force participation rate of 38.6% in Census 2011, with 76.4% of the
population classified as main workers and 23.6% as marginal workers. Of the 29,572 workers, 76.4%
were engaged in the main work. Gender disparities were stark: while men accounted for most of the
main workers (18,360), women were overrepresented among non-workers (17,735). Women’s
participation was higher in marginal work (5,596) and agriculture in rural areas and clustered around
education, health, and social work (5%), Arts and other services (7%) in urban areas. Agriculture
remains an important and major employment source particularly in rural areas, where 63.7% of workers
were engaged as cultivators or 6.8% are agri-based laborers.
Findings from the E and E survey highlighted that engagement in hospitality and tourism was the
highest (40%) among respondents with employment in hotels, working as tourist taxi drivers in different
taxi operator agencies. Grocery or fast-food shops were the second highest sector with 20% being
engaged in this sector. The third highest response was from the food processing sector (13%). These
were followed by other categories which include working as labor, engagement in private companies,
construction companies, agriculture laborers followed by handicrafts and handlooms, IT related sectors,
and beauty and wellness sector, and E commerce. In terms of the occupational disparity between
genders, it is found that the sector of grocery/ fast food shops, food processing, beauty and wellness
are mostly women focused.
As per the E and E survey, the self-employed comprised only 15% of respondents. Since the survey
targeted mostly SHG women, this number would also be on the lower side. Of the 620 entrepreneurs
identified in the survey, 75.4% were women, engaged mainly, in hospitality and tourism, food
processing, tailoring, wellness, grocery shops and fast-food retail. In contrast, male respondents were
concentrated in construction, trade, and transport services.
Stakeholder consultations and FGDs reinforced survey findings. Tourism, activities related to creative
jobs, local crafts (e.g., bamboo, handloom) and small household-based food processing enterprises
were identified as the current key employment domains, especially for women and youth. However,
challenges such as poor infrastructure, limited digital access, safety concerns, and inadequate
market linkages continue to suppress long-term income and employment gains, particularly for women
in remote areas. Various structural barriers were also identified such as skills mismatch, geographical
and mobility challenges, and limited financial access, soci0-cultural challenges that constraints
engagement of youth and women in the non-farm sector, while identifying the latent potential of women
and youth to drive Gyalshing’ s non-farm economic transformation.
A block-wise analysis of the FGD findings from Gyalshing district highlights distinctive enterprise trends
shaped by geography, demographics, and local value-chains. The following spatial patterns
demonstrate how rural women and youth are spearheading non-farm enterprises across the district:


Chongrang, Dentam, Gyalshing, Yuksom: Tourism and Creative Jobs

These rural blocks have a considerable number of Self-Help Groups (SHGs) actively engaged in
various farm and non-farm activities. Arithang Chongrang leads with 49 SHGs followed by
Gerethang with 42 SHGs (420 members), Tashiding with 41 SHGs and Kongri Labdang with 19 SHG
supporting small-scale food processing such as biscuit, Ladoo, and incense making. Engagement in
tourism through homestays and local guiding services, along with budding IT and social media
venture involving youths emerges as prominent activities within the block.
21 | P a g e

<!-- page 31 -->

Gyalshing District IEIAP

The block has over 300 SHGS across all the nine GPUs. Tourism is the most developed sector, with
homestays, tourist guides (27 numbers), and taxi services (more than 120 individuals involved)
concentrated in GPUs like Gitang Karmatkar, Maneybung, and Sanghu Radhu Khandu. Bamboo
handicraft and others are practiced in Bongten Gitang Karmatkar Hee Maneybung GPUs with only
limited persons being involved.
In these urban and peri-urban centres, women and youth operate a diverse range of small-scale
service enterprises, including beauty parlors, tailoring shops, social media marketing,
videography, data entry, and freelance event management. These sectors benefit from an enabling
ecosystem comprising SHGs, NGOs, Common Service Centres (CSCs), and access to targeted
start-up and skilling schemes, making these blocks hubs for tech-enabled and consumer-oriented
microservices.


Yuksom Block and Hee Martam: Green Jobs and Skilling

Both blocks together host 200+ SHGs, yet non-farm activities remain largely centred around tourism,
with Hee Martam’s tourism engagement still modest compared to Yuksom. Beyond tourism,
Yuksom shows a more developed non-farm ecosystem, including 100 canteens/shops, 10
households engaged in bamboo craft, 1 SHG producing handmade paper, and a growing digital
livelihood base with 15–20 vloggers and content creators. In contrast, Hee Martam presents a
more dispersed and small-scale non-farm landscape. Green activities here are primarily communitydriven—such as soak pits, compost pits, and plantation drives—while craft-based work spans
bamboo weaving, tailoring, knitting, damphu making, and plough making, typically involving 1–5
households per activity. The block also hosts unique microenterprises like gundri mattress making
(5 HHs) and herbal medicine preparation by a few households. Overall, while Yuksom displays
stronger enterprise-ready activities, Hee Martam reflects a wider but more fragmented mix of non-farm
practices, indicating need for structured enterprise promotion, skill upgrading, and market linkage
support across both blocks.
Strategic interventions under the IEIAP would target the gaps through gender-responsive skilling,
improved access to financial and digital services, and localized enterprise development.
Enabling infrastructure, mobility solutions, and social protection mechanisms would be essential to
empower women and youth as drivers of Gyalshing’s future-ready non-farm economy. The IEIAP would
offer an opportunity to catalyze this latent economic potential. The prioritized Strategic interventions
would address these enterprises support gaps, enhance credit and skilling access, invest in
common infrastructure, and enable gender-responsive ecosystem in the district. Special focus
would be placed on expanding market-linked livelihoods for women, and on nurturing youth-led
enterprises in high-potential sectors such as tourism, digital services, food processing, and green jobs.
Doing so would not only increase income and employment, but also lay the foundation for a resilient,
inclusive, and future-ready non-farm economy in Gyalshing district.
4.3 Key factors for economic inclusion: current scenario and limitations
The key factors that promote or hinder economic inclusion for women and youth are broadly
categorized in the following section along with the status and challenges. These are categorized into
six thematic areas based on insights from diagnostic studies, employment and enterprise surveys
(E&E), focus group discussions (FGDs), stakeholder consultations, and key informant interviews (KIIs).
These findings were used in developing the overall strategic approach for the IEIAP of the district.







Policies and programs
Institutions and processes
Financial access and inclusion
Infrastructure and market access
Capacities and skills
Socio- cultural factors
22 | P a g e

<!-- page 32 -->

Gyalshing District IEIAP

The findings on status and gaps from the secondary literature review, employment and enterprise
survey, focus group discussions, stakeholder consultations and key informant interviews for these key
factors are in the following section. Addressing these key gaps would form an important part of the
IEIAPs that would act as pillars for successful implementation of the economic activities that are being
proposed.
4.3.1 Policy and programs
The policy environment for promoting economic inclusion of women and youth has been largely
centered around employment provision, and entrepreneurship development has been a recent
emerging focus. Gyalshing district is served by a wide range of centrally and state-sponsored schemes
aimed at promoting employment, enterprise development, and livelihood security among rural and
urban populations. These include PMKVY, DDU-GKY, NRLM, PMFME, Startup Sikkim, SYSS, and
PM-SVANidhi, among others. PMFME, MOVCDNER and others support food processing
infrastructure and credit linkage. Startup Sikkim, SVEP, and Sikkim Udyami Yojana promote microenterprise development and youth-led innovation. PM Vishwakarma offers pathways for artisan’s
identity, financial and equipment support and market visibility. Green Economy Initiatives under the
SDG-aligned State Development Strategy and Swachh Bharat Mission support circular economy
interventions relevant for youth enterprises.
Table 4: Challenges and barriers in policy and program implementation
District Diagnostic

 Limited awareness
among youth and
women on existing
schemes and
programs
 Heavy dependence
of MSMEs, SHGs
and women
cooperatives, on
government
schemes, limiting
sustainability.
 Field-level utilization
remains limited.

E and E survey

Stakeholder
KIIs
consultations
 Limited awareness about  Lack of programmatic  Existing policies such
training programmes
support to promote
as SYSS need a look
(28.2%),
mentorship and
and to be made more
apprenticeship
holistic.
 Only 9% of respondents
opportunities
have their own/family run
 Limited institutional
business
 Lack of awareness on
support for effective
schemes and
implementation
 Skilled Youth Start-up
programs
Scheme (SYSS) being
 Government policies
the only scheme
 Preference for
were more leaning
accessed
Government jobs and
towards promotion of
the
stigma
attached
to
Govt jobs.
 Delays in approval or
self-employment

Institutional planning
disbursement (53%),
reinforced
by
Govt
and grassroot
 Eligibility constraints
policies
execution vary
(40%)
 Complex loan application
procedures (13%).

Interventions needed

 Mentorship programs to be institutionalized.
 Policy re-look for self-employment schemes, Provide subsidies, interest free or low interest loan without
collateral.

 Programmatic support in terms of incentivization to women and youth for access to finances such as
lowering different tax

 Improving access and knowledge of government schemes and programmes

The consultations also highlighted several challenges that hinder sustainable income generation and
employment growth, especially for women in remote areas. Key barriers include limited access to
modern tools and digital skills, weak knowledge of pricing strategies, restricted buyer networks,
inadequate shared infrastructure, poor branding, and weak market linkages. Structural constraints such
as skills mismatches, limited mobility, and restricted access to finance further reduce the participation of
women and youth in the non-farm economy. Yet, despite these hurdles, the discussions underscored
23 | P a g e

<!-- page 33 -->

Gyalshing District IEIAP

the significant untapped potential of women and youth to drive Gyalshing non-farm economic
transformation, if targeted interventions are designed to address these barriers.
4.3.2 Institutions and processes
The diagnostic study for Gyalshing district highlights the significant role of community-based
organizations (CBOs) in driving economic upliftment through diverse income-generating and community
development initiatives. Among them, Self-Help Groups (SHGs) and their federations, formed under the
Deendayal Antyodaya Yojana–National Rural Livelihood Mission (DAY-NRLM) framework, emerge as
the most prominent and active CBOs in the district.
Currently, Gyalshing has a total of five Block Development Societies (BDS), 140 Ward Development
Societies (WDS) and 1021 SHGs comprising 900+ members. There are three Farmer Producer
Organizations (FPOs) promoted by Small Farmers Agri- Business Consortium (SFAC) in the district and
two FPOs are registered under Mission Organic Value Chain Development for Northeastern Region
(MOVCD-NER) scheme phase-IV in the district. Currently there are 24 JFMCs under Territorial Forest
development agency and four EDCs (wildlife sector) in Gyalshing district under Wildlife Forest
development Agency. Moreover, there are 522 cooperatives in the district spread across various
sectors like transport, tourism, livestock and piggery, marketing fishery, labor and dairy, among others.

The E and E survey findings show that 1,829 respondents (44.3%) are engaged in different community
institutions such as SHGs and FPOs while 2,293 respondents (55.6%) are not involved in any
community institutions. Amongst these 2,293 respondents who are not part of any community
institutions, 1,113 respondents are female, and 1,180 respondents are male. Of the 1829 respondents,
100% are female and no male respondent. This indicates that community institutions in Gyalshing are
largely women-centric, with female and youth female members forming the backbone of such
structures, while youth males remain largely outside their ambit. Majority of the respondents are in SelfHelp Groups (SHGs) (98.2%) with all female respondents followed by FPO/FPC (02%) and JFMC/EDC
(0.75%). Cooperatives have the minimum number of respondents (04 respondents)
Insights from both focus group discussions and stakeholder consultations with self-help group members
of the district have shown that women accord a great deal of importance to their engagement with the
group, mentioning that being a SHG member has given them confidence, improved their social skills,
and bargaining power.
Table 5: Challenges and barriers in institutions and processes
District Diagnostic





Mostly low capital
ventures
Limited access to
business support
services
Underdeveloped
digital and
cooperative market
platforms

E and E survey






Stakeholder
KIIs
consultations
Only 7% of
 SHG/FPO members

entrepreneurs
have basic skills but
reported receiving
lack advanced
any form of
training and
institutional support
sustained follow-up

for business
support.
operations.
 Inadequate
No access to any
machinery and

institutions for
shared
business related
infrastructure
support service
restrict production
(93%)
efficiency and
Strict Eligibility
scalability.
Criteria (5.08%)
 Limited marketing
knowledge and
weak buyer
linkages hinder

Duplication of efforts
by SHGs and no
collaborative
approach.
Youth are more
focused on Govt
jobs
SRLM as an
institution needs to
be strengthened.

24 | P a g e

<!-- page 34 -->

Gyalshing District IEIAP



market access and
growth.
Low digital literacy
and poor use of emarketing tools
further constrain
outreach.

Interventions needed






Institutional strengthening of SRLM and SIRD.
Institutional strengthening for collective functioning.
Cluster based approach to be scaled up with formation of enterprise groups/ cooperatives.
Strengthening of non-farm sakhis for handholding support.
Improving access and knowledge of government schemes and programmes

4.3.3 Financial access and inclusion
Gyalshing district is served by 16 bank branches that provide access to banking services, though
coverage remains uneven across remote areas. The district shows high digital adoption of over 94% of
savings and current account holders use digital payment methods.
In terms of access to banking services, the E&E survey results showed that 97.5% of respondents
(4,017 out of 4,122) have a bank account, while only 2.5% (105 respondents) reported not having
one. However, when asked about the presence of a bank branch in their village or town, only 65% of
respondents (2,674) confirmed availability, whereas 35% (1,448 respondents) reported the absence
of a nearby branch. This indicates that while financial inclusion in terms of account ownership is nearly
universal, physical access to banking services remains limited, with distance and inadequate transport
emerging as key barriers. Long distance and limited bank branches were raised as key issues in
accessing bank services.
For SHG women, the micro credit system provides them with the most access to loans and 55%
respondents mentioned they borrow money from Self-help groups, while 15% avail credit from relatives.
67% of respondents reported that they are unable to secure loans from various formal and informal
financial institutions due to high interest rates. The data also shows that most of the borrowing is
concentrated in three areas—income generation/enterprise (28%), education (28%), and familyrelated needs such as marriage, festivals, and medical expenses (27%)—together accounting for
over four-fifths of total borrowings. Borrowing for consumption (13%), asset acquisition (3%), and
loan repayment (1%) are relatively limited. Women emerge as the largest group of borrowers, while
among youth, female youth borrow significantly more than male youth, particularly for enterprise and
family-related needs. Overall, the pattern suggests that while a large portion of borrowing is productive
and future-oriented (enterprise and education), a substantial share is also driven by social
obligations and immediate family requirements, reflecting both economic aspirations and cultural
pressures.
Table 6:Challenges and barriers in financial access and inclusion
District Diagnostic



Limited access
to credit
Few credit
facilities and high
collateral
requirements
restrict women

E and E survey




High interest rates (24%
responses)
Limited financial literacy
(15% responses)
Limited awareness or
information (18%
responses)

Stakeholder consultations




Youth lacking the
financial capital required
to start or expand a
business
Hesitant for bank loans:
Most of the SHG
members rely only on

KIIs




Women and
youth unwilling
to take loans.
High number of
rejections as
well as
defaulters

25 | P a g e

<!-- page 35 -->

Gyalshing District IEIAP

and youth
access to capital







Collateral constraints
(14%)
Lack of credit history
(10%)
Complexity of loan
application procedures
(13%).
Strict eligibility criteria
(5%),








their CIF (Community
Investment Funds) and
PMFME funds to initiate
their small venture.
Limited access to
financial literacy
programs, which
hinders their ability to
manage money
effectively.
Cumbersome
paperwork process for
accessing loans.
High interest rates from
financial institutions.
Unavailability of
documents leading to
rejections.








Lack of credit
history
Lack of
information/
knowledge on
processes.
Requirement of
collateral or
credit history not
fulfilled.
Youth-led
startups are
often viewed as
high-risk
ventures by
investors

Interventions needed





Awareness and capacity building interventions for increasing financial knowledge and inclusion.
Programmatic support to women and youth for access to finances.
Handholding of youth through common facility centres/ one stop centres.

4.3.4 Infrastructure, transport and market
Adequate support
through infrastructure and technology, and the ease with which these are available are key
determinants for effective enterprises. The district has limited access to integrated enterprise support
systems. As a result, many enterprises continue to operate in silos, with limited coordination,
inadequate support for market linkages, and restricted access to services such as credit facilitation,
legal compliance, and digital marketing.
The E & E survey had the following insights for present status of connectivity, digital infrastructure and
markets








19.7% respondents indicated the presence of entirely pukka roads, 26.6% reported kutcha
road in the district while 49.6% reported mixed that the road infrastructure was both
kutcha and pukka.
4% of respondents highlighted the absence of any road connectivity, pointing to
challenges in accessibility and mobility for those villages.
Poor road conditions are the most pressing challenge, reported by 38.7% of responses,
followed by lack of public transport options (27.7%) and high transportation costs (25%).
Limited last-mile connectivity was identified by 8.6% of responses.
39% of the respondents expressed concern about landslide related disaster risks on
roads.
Out of the total respondents who run a business (389) only 7% respondents have access to
business support services.

Table 7: Challenges in Infrastructure, Transport, and Market
District Diagnostic

 Limited market access
forces local producers to
rely on tourists and
middlemen, cutting their

E and E survey

Stakeholder
KIIs
consultations
 Only 7% of respondents
 No SHG mart
 Limited information
have access to business
spaces, and
on available
support services.
issue of market
schemes

26 | P a g e

<!-- page 36 -->

Gyalshing District IEIAP

earnings and pricing
 Marketing through digital
control.
platforms is limited.
 Heavy rainfall and
 39% reported poor road
landslides frequently
conditions as barrier
disrupt transport and
 25% high costs for
connectivity
transport.
 Road infrastructure
 24% reported delayed
remains vulnerable to
deliveries due to poor
weather disruptions,
road condition.
increasing costs for
 Limited public transport
businesses and restricting
options-28%
mobility
 Limited infrastructure and
 Inadequate waste
access to storage facility.
management and
 Lack of market
sanitation infrastructure
information.
 Remote villages face
mobility constraints,
Digital infrastructure
limiting access to training
 Poor signal or limited
centers, markets, and
connectivity by 37%,
service delivery points.
 High cost reported by
 Weak incubation and
34%,
enterprise support
 Limited digital skill infrastructure, limiting
15%.
opportunities for youth
 Lack of device-14%
and women-led startups.
 Inadequate cold chain
and storage facilities
restrict the growth of
horticulture and food
processing enterprises.

mafia in certain
sites.
 Lack of quality
products
 Packaging and
branding
challenges
 Limited
information
about costing
among SHG
enterprises.
 Insufficient
common facility
centers and
fulfilment
centers
 Inadequate postharvest facilities,
and weak supply
chains.
 Absence of cold
storage
 Regular
marketing
linkage lacking Products made
only the State
sponsored fairs
and festivals.

 Marketing is still
very local

 Road connectivity is
a big challenge for
marketing.
 Infrastructure for
aggregation and
collective
processing is
limited.
 SWAYAM Sikkim as
a brand was a
positive step, but
remained of
operational
challenges of limited
inventory, quality
control, and
duplication of
products.
 Most rural and
SHG-led enterprises
are not connected to
e-commerce, digital
payments, or
aggregator
services.
 Access to modern
tools, software, and
digital infrastructure
is limited.

Interventions needed









Shared Infrastructure such as common fulfilment centres / common facility centres for aggregation/
processing/ value addition by community institutions (EGs/ Clusters/ PC/ Cooperatives/ others)
Marketing spaces / rural marts at strategic locations
Strengthen branding and packaging (Swayam Sikkim)
Conduct market studies and value chain analysis
Organize buyer seller meets
Participation in trade fairs, etc.
Improving public transport for high economy villages with low connectivity
Improving road access for villages that have no connectivity

4.3.5 Capacities and skills
Gyalshing district has a growing but uneven skill development ecosystem. Several government
departments have supported training programs like PMKVY, SYSS, and DDU-GKY. They are still
operational; however, they often lack depth, practical application, and alignment with specific sectoral
needs. The district hosts 4 out of 41 Livelihood Schools under the State Institute of Capacity Building
(SICB), offering basic vocational training.
Infrastructure-wise, the district benefits from one Industrial Training Institute (ITI) providing both
engineering and non-engineering courses. Participation by women and rural youth remains low due to
no campus placements after course completion. The stakeholder consultation revealed a lower
inclination towards entrepreneurship, even though the courses are designed to support both
employment and entrepreneurial opportunities. The local skill base is still heavily reliant on agriculture,
while non-farm sector skills—such as those needed in tourism, digital services, wellness, and
27 | P a g e

<!-- page 37 -->

Gyalshing District IEIAP

manufacturing—remain underdeveloped. However, most of the youth are engaged in government
services under the state’s One Household One Job program, leaving only a small proportion available
to pursue entrepreneurship.
The E and E survey has shown that only 22% of the respondents have received any kind of training
within the last 3 years and 55% of respondents would like to go for further skill development under
different sectors.
Training provided to women have been sufficient in providing them with basic skills needed mainly in
sectors such as food processing, handicrafts, hospitality and tourism increasing the scope for women to
improve their proficiency and become skilled artisans is needed to address this gap.
Table 8: Challenges in capacities and skills
District Diagnostic










E and E survey

Stakeholder
KIIs
consultations
Digital skills are one
 For skill
 Necessary skills  Vocational studies are
of the limiting factors
development
to use online
stigmatized and are often
where youth/women
platforms for
seen as a last resort for
 Limited
use smartphones for
business
academically “average”
information
consumption and are
development.
students, leading to social
about training
less likely to access or
devaluation of hands-on,
opportunities
 Training not
use smartphone
skill-based careers.
(28.2%),
sufficient for skill
productively.
refinement, only  No exposure to business
 Distance from
Low exposure to
for basic skills.
related environment/mindset
home to attend
mentorship programs
for which youth/women do
training (22.4%),  Handholding
where youths/women
not develop essential
post training with
 Transportation
would observe or
entrepreneurial traits like risk
the required raw
issues (20.8%)
shadow successful
tolerance, opportunity
material,
 Family and child
entrepreneurs.
scanning or strategic
financial
obligations
networking.
Limited outreach and
linkages, etc.
(13.2%).
program awareness
was limited.
 High dropout rates linked to
 4% reported
transport, family obligations,
Limited job placement
 Training venues
training
and cost
cells, employment
were not
mismatch
exchanges, or digital
accessible.
 Poor alignment between
job portals.
training content and
 Training duration
Utilizing the skills
emerging market demand.
Training outcomes are
is not adequate.
 Insufficient
not translating into
 Career counselling and
 Lack of
capital- 37%,
livelihoods.
vocational guidance services
incubation
 Limited business
also limited
centers in the
skills - 16%,
states.
 Fear of risk 11%
 Quality training 11%
 High market
competition –
10%
 limited access to
finance (29%),
 price fluctuations
(11%),
 Limited access
to technology
(10%). Shortage
of skilled
workers or

28 | P a g e

<!-- page 38 -->

Gyalshing District IEIAP

technical
expertise (6%).
Infrastructure
constraints (9%),
limited market
information (9%),
buyer’s lobby
(3%)
Interventions needed







Longer term handholding for skill refinement.
Training partners and key experts for providing training, counselling, mentoring, and handholding.
Awareness and Training on soft skills such as communication, leadership, problem solving etc.
Training in digital literacy
Monitoring and follow up post capacity building activities.

4.3.6 Socio- cultural factors
Traditional occupations such as agriculture, horticulture, and livestock rearing continue to dominate in
Gyalshing. These socio-cultural norms significantly influence job aspirations, particularly among
women, often limiting their engagement in modern or non-farm sectors. Female participation in stable
employment remains low, with many women concentrated in marginal, seasonal work due to societal
expectations that prioritize domestic responsibilities. Mobility restrictions further exacerbate these
challenges, especially in rural areas, where limited access to training, markets, and job opportunities
hinders women's economic advancement. While there is growing interest among women in sectors like
hospitality, food services, and health and social work, barriers such as inadequate financial access, skill
development, and societal norms persist. Additionally, a strong cultural preference for government jobs
among youth, driven by the associated security and social prestige, often diverts them from exploring
entrepreneurial or private sector opportunities, thereby constraining the broader employment landscape
in the district
The E&E survey reveals that women account for 56% of unemployed persons in the district. Many
female respondents reported being confined to unpaid domestic work, with 26% identifying themselves
as homemakers. Social norms, time-poverty, and lack of mobility infrastructure were frequently cited
during FGDs as barriers to external employment.
Most of the youth, particularly in rural and peri-urban areas are opting for seasonal, part-time, or lowpaying informal work, often citing job insecurity and mismatch with aspirations. Young men tend to
gravitate toward transport and construction, while women remain concentrated in home-based activities
like tailoring or food services.
Table 9: Challenges in Socio-cultural factors

District Diagnostic E and E survey
 Socio-cultural



barriers hinder
women’s mobility
and participation in
job &
entrepreneurial
activities
Women often face
constraints due to
household
responsibilities to

Stakeholder
consultations

KIIs

 Lack of women-

 Women are often expected

 High Competition and

focused financial
services, and
discriminatory
lending
practices.
Family-related
discouragement
or restrictions,
while less critical,
still influence

to prioritize family and
household responsibilities
over entrepreneurial
aspirations
Consequences of failure
would carry significant social
stigma, which would deter
both youth and women from
pursuing entrepreneurship.

Unrealistic
Expectations.
Lack of best practices/
inspirational role
models making youths
and women unable to
visualize what
success looks like
within their socioeconomic context.







29 | P a g e

<!-- page 39 -->

Gyalshing District IEIAP

participate in
employment and
entrepreneurship
opportunities





entrepreneurial

decisions.
Limited emotional
and social
support.
Stigma around
business failure.

Limited social
recognition of
youth
entrepreneurs.


Entrepreneurship is
discouraged over
Government jobs and
pursuing a non-traditional
career path led to family
opposition.
Shortage of successful
female and young
entrepreneurial role models
in Sikkim.
Stigma Against LaborOriented Jobs – Social
biases discourage youth
from taking up manual labor
and blue-collar jobs despite
available opportunities.

 Absence of transport,





childcare, and safe
workspace
infrastructure
Lack of recognition for
youth-led ventures,
further, dampens
motivation and
reinforces a
preference for
traditional
employment.
Notable stigma around
manual or laborintensive jobs.

Interventions needed






Mentorship and apprenticeship programs
Facilitating change in perception for the entrepreneurship sector
Women and youth empowerment events
Child and elderly care integration into all programmes

4.4 SWOT Analysis of the Non-Farm and Off-Farm Economy in Gyalshing District
Table 10: SWOT Analysis of Gyalshing’ s non-farm and off-farm sector

Strengths: Enablers for Inclusion
Thematic Area
Strengths
Potential in
tourism and
hospitality





Strategic
location
Expanding
Economic
Sectors &
Entrepreneurship
Opportunities
Institutional and
community
structures



Government
Support







Gyalshing is home to nature’s bounty of scenic views, lush green forest
and picturesque valleys. It has rich cultural heritage with a unique blend of
Nepali, Lepcha, Limbu and Bhutia with their own distinct language, custom
and tradition.
Sikkim Ecotourism Policy & MEGA Homestay Scheme (1,000 new units
planned) encourage women and youth-led businesses in adventure
tourism, wellness retreats, and homestay management.
The district is less affected by weather conditions and is accessible allround the year which open avenues for all year-round inflow of tourists
Emerging sectors such as food processing, wellness, handicrafts, and ecotourism offer significant opportunities for enterprise development among
women and youth.

Gyalshing houses 1,017 Self-Help Groups (SHGs), 24 Joint Forest
Management Committees (JFMCs) / Eco-Development Committees
(EDCs), and 522 cooperatives, forming a strong institutional base for
participatory development and inclusive growth.
Government programs such as Stand-up India, Skilled Youth Startup
Scheme (SYSS), and Swadesh Darshan Scheme enable youth and
women-led startups.

30 | P a g e

<!-- page 40 -->

Gyalshing District IEIAP

Tourism



Skilling &
Workforce
Limitations



Well-established tourism assets, including scenic routes, heritage
monasteries, trekking trails, homestays, trained local guides.

Existing seasonal tourist inflow provides an established customer base for
local tourism and related services.

The district has a well-established reputation in organic farming, supported
by favorable agro-climatic conditions, traditional knowledge systems, and
state-led promotion of sustainable agricultural practices which would be
promoted.
Weaknesses: Barriers to Inclusion
Thematic Area
Weaknesses
Women form 58.1 percent of the non-working population. Additionally, they
contribute to many women confined to unpaid domestic work.

Women underrepresented in IT, finance, digital businesses, and logistics,
limiting their economic inclusion.

Shortage of skilled personnel in tourism, digital marketing, creative
industries, caregiving, wellness, and food processing

Low transition to value-added jobs and sectors

Lack of awareness on training programs

Mismatch between training received and market demand
CBOs engaged in  Few numbers of SHGs and other CBOs engaged in non-farm activities
Non-farm

Low conversion of trained individuals in sectors like food processing,
Activities
handicrafts to entrepreneurship

Post training follow-up and handholding remains nil
Access to

There are no registered credit related cooperatives.
Finance and

Limited market access for local producers/processors with limited number
Market Linkage
of active marketing cooperatives (13).

Weak branding and digital presence for handicrafts, food processing, and
SHG enterprises, reducing market reach.

Few weekly haats, rural mandis, and regulated markets, leading to
unstructured trade.

Limited cold storage and agro-processing units reduce value-addition in
spices, fruits and dairy

No structured linkages with institutional buyers, tourism-based markets, or
e-commerce platforms
Infrastructure

Absence of cold chains, packaging units, shared production hubs
Gaps

Lack of co-working spaces, digital editing studios, creative workspaces,
and logistics facilities

Limited food processing infrastructure (e.g., no dedicated zones, low
production scale)

Poor transportation and road conditions

Limited access to business support services for handholding
Gendered

High care work in their household for women burdens limit mobility and
Barriers
time for enterprise activities

Society at large discourages youth from pursuing entrepreneurship and
asks to settle for low paid government jobs
Digital Divide &

Limited access to devices, digital tools, and training in multimedia, digital
Literacy
design, and platform literacy

Youth and women underutilize digital marketing and e-commerce due to
low exposure and skills
Opportunities: Growth Avenues for Women & Youth Inclusion
Thematic Area
Opportunities
31 | P a g e

<!-- page 41 -->

Gyalshing District IEIAP

Expansion of
Women & Youth
Entrepreneurship
in High-Potential
Sectors






Tourism & Eco
tourism





Creative
Industries,
Handicrafts &
Handloom





Capitalizing
Hospitality and
Wellness Base



Food Processing







Digital & Creative
Economic
Growth






Green Jobs



Health and
Wellness



Emerging sectors such as handicrafts, eco-tourism, village tourism, organic
farming, and food processing offer avenues for inclusive enterprise
development.
Expansion of digital platforms and e-commerce offers scalable avenues for
rural producers to reach wider markets beyond the local geography
SHG product/services linkage with schools, ICDS, PHCs etc.
Develop women/youth-run eco-lodges, guided treks and homestays around
Yuksom, Barsey Sanctuary and Pemayangtse.
Leverage digital travel platforms and SWADESH Darshan circuits.
Revive Lepcha and Bhutia textile motifs via women’s SHGs and direct-toconsumer e-commerce.
Support bamboo and wood craft cooperatives for heritage markets.
Enhance local branding through GI tagging, modern design integration, and
digital marketing to access broader domestic and international markets.
Developing market linkages, improving branding, and leveraging digital
platforms has potential to enhance visibility and reach of local products and
services.
Capitalize on the strong hospitality base to foster women-led homestays,
cafés, and wellness retreats.
Integrate traditional healing and Ayurvedic practices with modern wellness
programs to create niche market offerings and job opportunities.
Develop the organic food processing sector by improving infrastructure
(e.g., cold storage) and expanding market access for products like Dalle
Khursani (Chilli), ginger and turmeric along with branding and packaging.
Opportunities exist in processing mushrooms, trout, kiwi, passion fruit, and
dragon fruit, with scope for agro-based micro-enterprises.
Youth led creative services offering poster & video designing, product
promotion, homestay marketing, event documentation, animation etc.
would be tapped.
Expanding digital infrastructure and youth interest in tech fields present an
opportunity for digital startups, freelancing, and service delivery platforms
Encouraging digital startups, e-governance, and ecommerce, creating
remote job opportunities.
Waste Management and recycling and reusing waste products has
potential to scale employment opportunities for women and youth

Scale women-led homecare, telemedicine and mobile daycare services.
Package integrated wellness retreats combining herbal therapy, meditation
at monasteries
Threats: Risks to Inclusive Enterprise Development
Thematic Area
Threats
Youth

Youth opting for migration due to low employment and enterprise returns,
Disengagement
limited career paths, and poor post-training outcomes
& Migration

Women often confined to marginal or unpaid roles.

Absence of role models in entrepreneurship
Climate and

Landslides, earthquakes and flash floods tend to damage infrastructure,
Connectivity
affect livelihood, and impact the district’s economy.
Risks

Unchecked development and human activities have potential to lead to
environmental degradation, affecting the district’s natural beauty and
ecosystem.

Perishable like vegetables suffer due to lack of storage and delayed
transport


32 | P a g e

<!-- page 42 -->

Gyalshing District IEIAP

Market
Competition &
Volatility






Fragmentation of
Local System



Lack of
Institutional
Support &
Sustainability
Risks









Competition from established urban brands and imported goods undercuts
local producers.
High cost of doing business in the hilly terrain deters private investment in
IT, tourism and green energy.
Digital market volatility (algorithm changes, no monetization) discourages
young creators
E-commerce dependence without support structures risks disengagement
SHGs, youth groups, cooperatives, PRIs function in silos
Absence of collective branding or federated value chains at block/district
level
Absence of creative/artisan incubators and business hubs
No formal mentorship or entrepreneurship development in caregiving, arts,
or wellness
MSMEs, SHGs, and women’s cooperatives heavily depend on government
schemes, limiting sustainability
The youth in Gyalshing prefer secure government positions, limiting their
engagement with private-sector entrepreneurship and self-employment

The SWOT analysis presented above offers a grounded and data-driven understanding of Gyalshing’s
district’s non-farm and off-farm economic landscape, highlighting critical strengths to build upon,
structural barriers to address, and high-potential sectors and locations to prioritize. It clearly identifies
the pathways for unlocking inclusive economic opportunities for women and youth, while also outlining
the systemic and environmental risks that would undermine progress if left unaddressed.

33 | P a g e

<!-- page 43 -->

Gyalshing District IEIAP

Chapter 5

Strategic four- year
plan for
employment and
entrepreneurship
34 | P a g e

<!-- page 44 -->

Gyalshing District IEIAP

5.1. Introduction: Background, Purpose, Mission, and Vision
The Integrated Economic Inclusion Action Plan (IEIAP) for Gyalshing District is developed under the
Sikkim INSPIRES Program, a World Bank-funded initiative that focuses on promoting economic
inclusion opportunities for women and youth. The program aims to enhance employment generation
and foster entrepreneurship development within the non-farm and off-farm sector of the economy. In
line with this overarching goal, the IEIAP seeks to address critical barriers that hinder women's and
youth's access to quality employment, entrepreneurship opportunities, and economic empowerment.
The development of the IEIAP for Gyalshing is grounded in comprehensive Employment &
Entrepreneurship (E&E) Surveys, Focus Group Discussions (FGDs), Key Informant Interviews
(KIIs), District-Level Diagnostic Study, consultations with government departments, local institutions,
and private sector organizations These efforts have identified key challenges that the IEIAP plans to
address and harness local strengths, thereby laying the foundation for transforming the district into a
vibrant, and inclusive economy.
Vision
The Vision of the IEIAP for Gyalshing District is “To empower women and youth through inclusive
growth, sustainable livelihoods, and entrepreneurship in non-farm sectors.”
The IEIAP plan specifically targets sectors such as sustainable tourism, agro-value chain, creative
industries, green entrepreneurship, and overall improvement of entrepreneurship ecosystem,
which have the potential to create new pathways for economic empowerment.
Objectives
The IEIAP has specific economic interventions of creative industries, community-based tourism,
green entrepreneurship, which have the potential to create new pathways for economic empowerment
as well as interventions that promote enabling support system for entrepreneurship. The broad
objectives of the IEIAP for Gyalshing District are 







Enhance Skills Development: Provide targeted skill training, digital literacy, and entrepreneurial
education tailored to the needs of women and youth.
Promote Access to Finance: Facilitate access to microloans, grants, and financial literacy
programs to support small business growth and self-employment.
Strengthen Market Linkages: Connect local producers, entrepreneurs, and service providers with
wider markets through fairs, partnerships, and digital platforms.
Foster entrepreneurship development: Supporting women and youth to become successful
entrepreneurs through skills training, market access, and financial support.
Build inclusive ecosystem: Fostering collaboration among government bodies, private
enterprises, and local communities to create a supportive environment for economic activities,
innovation, and sustainable growth for women and youth including vulnerable groups such as
PWD, low-income groups etc.
Address gaps in infrastructure and accessibility: Providing the necessary physical and digital
infrastructure to enable non-farm entrepreneurship, such as improved transport and mobility, digital
and sector-specific facilities.

5.2. Methodological Pillars of the Planning Process
The intervention design adheres to a structured methodology based on the following principles:

Table 11: Methodological pillars of IEIAP planning process

35 | P a g e

<!-- page 45 -->

Gyalshing District IEIAP

Methodological
pillars

Description

Cluster-based
approach

To ensure coordination, scalability, and efficiency, the key approach would be to work
on a cluster-based approach that builds strong value chains, strengthens community
ties, and facilitates targeted support.

Enablers to be
strengthened

For longer terms sustainability of all the interventions, the overall enabling
environment must be strengthened by improving financial inclusion, digital literacy,
soft-skill components, business development and social inclusions.

Inclusivity as a
design imperative

Each intervention is tailored to target women and youth—both as direct beneficiaries
and as enterprise leaders. Special emphasis is placed on reaching rural, semi-urban,
vulnerable groups of women and youth and lower-income groups, vulnerable groups
of women and youth through targeted outreach and group-based models (e.g., SHGs,
youth collectives).

Phased
implementation for
adaptive learning

A four-year roll-out plan enables piloting, refinement, and scaling. This staged
approach facilitates flexibility in design and course-correction based on learnings from
early implementation.

Results-oriented
structure

Each intervention has been mapped to output, outcomes, and key performance
indicators (KPIs). The results-based framework ensures accountability, simplifies
progress tracking, and enables data-driven decision-making.

Facilitating
Convergence

Interventions have been designed for integration with existing schemes (e.g., NRLM,
PMEGP, SFURTI-KVIC, SVEPSEVP, Skill India, DAY-NULM, SBM, Digital India, PM
Vishwakarma, etc.).

5.3 IEIAP approach
The IEIAP approach has been based on keeping the key economic activities at the core of the plan.
These key activities have been identified and prioritized based on the findings of the focus group
discussions, employment and enterprise surveys, key
informant interviews, and stakeholder consultations,
thereby reflecting local strengths, emerging
opportunities, and community aspirations.
The interventions planned in the IEIAP consist of key
economic activities for women and youth to be engaged
– tourism, creative industries, handicrafts sector, green
enterprises and care giving.
The IEIAP also focuses on strengthening enabling
factors and specific interventions are also planned to
facilitate that. The plan also envisages building existing
skills with the state bringing in the support of
entrepreneurs, NGOs, and other local agencies to be
engaged in training support, provide expertise in specific
fields, and includes scope for longer term handholding of
the enterprise groups.

Figure 4: Key Interventions in IEIAP

For all interventions that involve the formation of
Enterprise Groups (EGs) or Producer Companies (PCs), as well as the establishment of facilities to be
managed by community groups or through a PPP model, detailed sustainability plans would be
developed during the project pre-implementation. Phase. These plans would outline operational,
36 | P a g e

<!-- page 46 -->

Gyalshing District IEIAP

financial, and governance mechanisms to ensure long-term viability, including user-fee systems,
maintenance protocols, capacity-building measures, and transition strategies for community-led
management.
Prioritization exercises to identify the key economic activities were conducted with the District Planning
Team, and with district level stakeholders. The criteria for prioritization of the activities were - Existing
skills, Potential for engagement of women and youth, Market demand and potential, and scope for
leveraging other schemes. Based on the exercise the following interventions have been identified for
Gyalshing District.

5.4 Key interventions
Table 12: IEIAP intervention with Rational, Broad Strategy
Interventions
Promotion of
community-based
tourism in
Gyalshing District
with focus on nature
and rural tourism

Rationale for inclusion in IEIAP

Rich natural and cultural heritage for
tourism promotion and high demand
from all GPs

Scenic locations and off-beat locations
away from the usual touristy circuit

High potential for engagement of women
and youth.

Travelers increasingly seek immersive,
authentic experiences that connect them
with local cultures and natural
environments.

Support in setting
up processing and
value addition
facilities for key
off farm products








Strengthening
handicrafts sector






Strong potential for cluster-based
processing and value addition.
High demand for organic produce of
Sikkim.
Presence of existing schemes for
convergence.
34% prefer this sector in E and E survey
Women strongly inclined due to homebased feasibility.
Existing skills in food processing.

Readymade market through tourism for
local handicrafts souvenir.
Rich traditional knowledge of local crafts
Offer cultural preservation and livelihood
generation, especially for women.
Provide women/youth with a stable
source of income, improving their
livelihoods and fostering community
resilience

Broad strategy

Institutional strengthening for
promoting community-based tourism.

Developing site specific ecotourism
plans in collaboration FED and TCAD.

Focus on enhancing capacities and
skills of tourism service providers.

Develop tourism standards and
certification systems.

Enlist support of local tourism experts
and organizations for handholding

Strengthen basic amenities in the
tourism sites

Upgradation of tourism infrastructure
(homestays)

Develop strategy for solid waste
management to minimize tourism
impact

Conduct market study for identifying
key products

Formation and strengthening of
clusters through Enterprise Groups

Facilitate aggregation for
coprocessing, quality control and
marketing.

Provide necessary infrastructure
support for collective functioning
through CFCs.

Overall capacity building on enablers
such as financial knowledge,
business planning, digital marketing,
etc.

Conduct market study for identifying
key products

Formation and strengthening of
clusters through Enterprise Groups

Facilitate aggregation for
coprocessing, quality control and
marketing.

Provide necessary infrastructure
support for collective functioning

37 | P a g e

<!-- page 47 -->

Gyalshing District IEIAP







Promotion of
Green SHG
Enterprises for
Upcycled and
Reusable
Products








High demand for local souvenirs in the
market.
Rich traditional knowledge of local
crafts.
Offer cultural preservation and livelihood
generation, especially for women.
Existing active SHG groups in the
district.
Emerging young entrepreneurs in the
crafts sector.
Growing demand for sustainable, ecoconscious products among consumers,
businesses, and government
institutions.
Contributes to Sikkim’s green image and
plastic reduction initiatives.
SWM interventions promote circular
economy principles minimizing landfill
burden.
Support from government for
sustainable livelihood options












Enhancing Skilling
for Creative Jobs







Scope for engaging high number of
youths
High interest among youth in opting for
entrepreneurship
Market demand for creative jobs
Increasing digital literacy among youths
and connectivity in the district
With increasing local demand for
professional event services (weddings,
festivals, public programs), trained
individuals in event planning and
management might build viable
businesses












Strengthening
entrepreneurship
ecosystem for
women and youth
through support in
business
development and
mentorship






Lack of support for entrepreneurs has
emerged as a key challenge.
Lack of mentorship opportunities cited
by all youth
Limited opportunities for understanding
the entrepreneurship sector












Strengthening operations through
SOPs, HR
Overall capacity building on enablers
such as financial knowledge,
business planning, digital marketing,
etc.

Conduct market study for identifying
key products
Formation and strengthening of
clusters through Enterprise Groups
Linking with experts / entrepreneurs
for longer term handholding and skill
refinement
Provision of equipment, tools and
working capital support
Forge collaboration with relevant
departments
Overall capacity building on enablers
such as financial knowledge,
business planning, digital marketing,
etc.
Identification of correct set of
beneficiaries through campaigns and
outreach programs
Skilling through convergence with
SDD/ SICB on various sectors (focus
on digital)
Provide mentorship support through
linkage with successful
entrepreneurs.
Focus on post training handholding
through support in business
development for promising
entrepreneurs
Provide support through innovation
funds to selected entrepreneurs
Provide apprenticeship opportunities
for deserving entrepreneurs
Target all beneficiaries of the
various interventions of IEIAP on the
various sectors
Provide mentorship support to
promising entrepreneurs through
linkage with existing entrepreneurs.
Focus on post training handholding
through support in business
development
Provide marketing support for
entrepreneurs
Organize Innovation Challenges for
budding entrepreneurs and provide
seed money support to best ideas.
Set up Business Facilitation Centers
/ Common Service Centers for

38 | P a g e

<!-- page 48 -->

Gyalshing District IEIAP

single window support to
entrepreneurs

Improving
infrastructure for
marketing and last
mile connectivity
for economic
inclusion








Awareness and
Sensitization







Strengthening
IEIAP
implementation
team




The gaps in infrastructure along all value
chains have been highlighted as a key
challenge
The infrastructures foster economies of
scale and help bridge the gap between
local producers and broader markets
High issue of connectivity in the district.
Low hanging fruit for improving transport
connectivity

Limited opportunities to learn about
entrepreneurship in the educational
system
Awareness and sensitization limited for
youth
Lack of mentorship / apprenticeship
programmes
Mindset challenges for entrepreneurship
support

Need for strong team in place for IEIAP
implementation
Delineated roles and responsibility for
various institutions and teams



Use of existing Block resource centre
into One stop information centre to
serve business relation information,
support and grievance redressal.

Spread information and awareness
about the OSICs, conduct a districtwide campaign

Establishment of marketing centre
that would be managed and run by
the SHG members

Formation of market management
committee to overlook at the day-today management

Training and capacity building of the
members with necessary skills to
manage and sustain fulfilment and
marketing centres

Develop app-based solutions for car
sharing in rural spaces.

Identify villages with low public
transport for increasing transport
options.

Design and develop an effective and
long-term IEC campaign for schools
and college students.

Develop IEC material in various
mediums for supporting the
campaign.

Partner with local organizations /
educational institutions for
organizing the campaign in the
district.

Enlist support of local entrepreneurs
as resource persons for the
campaign with online talks for
providing mentorships.
Document success stories of
entrepreneurs for wider publicity through
local media/ social media.

Gap analysis for lead institutions
such as SIRD/ SRLM / District IEIAP
Committee

Capacity building of team members
at District and Block levels.

Develop clear division of roles and
responsibility


Develop robust monitoring
mechanisms

5.5. Institutional arrangements for IEIAP implementation
Rural Development Department (RDD): The Rural Development Department (RDD) is the nodal
department with the PIU (Project Implementation Unit) and would provide overall technical support,
39 | P a g e

<!-- page 49 -->

Gyalshing District IEIAP

capacity-building programs, prepare the annual budget, and monitor activities based on the IEIAP. RDD
would also be responsible for driving those interventions that are pan-state, which include all districts.
Department of Ecotourism: The Department of Ecotourism would also be a co-implementing
department around ecotourism-related activities. The DET would oversee education, training,
infrastructure development and capacity-building components. The DET would coordinate closely with
RDD to ensure integrated planning, monitoring, and delivery of project outcomes around tourism-related
interventions.
District Administrative Center: The District Administrative Center (DAC) which is headed by the
District Collector and having the coordination of all line departments present at the district level would
provide technical assistance and support. Issues related to land identification, technical vetting. etc., for
the interventions would be handled by the DAC.
District IEIAP Committee: The IEIAP committee, chaired by the District Collector, would serve as the
focal point for implementing interventions under the INSPIRES program. The DC would act as the
approval and sanctioning authority for all programs under the IEIAP. The District IEIAP Committee
would have a supervisory and monitoring role for IEIAP implementation, and quarterly meetings would
be conducted to appraise the committee on the progress made.
A District IEIAP Implementation Team (DIIT) for project implementation would be set up under the
District IEIAP committee to drive the implementation forward along with the project management and
monitoring. The DIIT members would be nominated by the DC as per the interventions that are planned
in the district IEIAP with key interventions assigned to specific team members to lead. To ensure
adequate focus and ownership, DIIT would function as a dedicated, full-time team for IEIAP
implementation.
The DIIT would consist of 4–5 full-time members, each with clearly defined implementation
responsibilities across 2–4 intervention areas. Indicative roles include Assistant Project Manager
(APM) – CBT; APM – Souvenir and Green Enterprises; APM – Off-farm Value Chain; APM – Nonfarm Skilling; APM – Entrepreneurship Development, etc. The potential department
representatives and their key responsibilities have been suggested in the Annual Action Plan. These
roles ensure the presence of appropriate domain expertise needed to manage the complexity of the
interventions.
These members would ideally be government officials deputed full-time to the DIIT team, given the
vastness and complexity of IEIAP interventions. Having DIIT members onboard full-time would ensure
adequate focus, ownership, and accountability critical for successful implementation, rather than
treating this as an additional responsibility alongside their primary roles. If no suitable resources are
available within the district for key Associate Project Manager (APM) roles required for IEIAP
implementation, the District IEIAP Committee (DIC) would initiate a formal hiring process to recruit
appropriate candidates from the open market.
The DIIT would also identify technical partners, trainers and resource persons to implement the key
interventions to be onboard with the approval of the Chair. The DIIT would provide support to the DPM
for planning, coordination, and addressing any challenges in program implementation. DIIT would
organize weekly meetings to review progress and provide updates on any delays or deviations.
The District IEIAP committee would hire/ depute a District Project Manager (DPM) to oversee the
IEIAP implementation, who would report to the Chair of the committee. The DPM would have the main
role of coordinating with the various departments, institutions, training partners, NGOs, etc. for ensuring
smooth implementation. The DPM would work closely with the DIIT members formed under the District
IEIAP committee for everyday tasks based on the interventions that the team members are assigned.
The Block Level Team would include the Block Project Manager of SRLM, Field Facilitators of SIRD,
Panchayat Development Assistants, the Block Level Coordinator from Skills Development Department,
selected DPT members and other key active people assigned by the ADC Development with the DC’s
approval. The Block Level Team would provide coordination and other necessary support in the
interventions that are implemented in the specific blocks such as helping / mobilizing participant
40 | P a g e

<!-- page 50 -->

Gyalshing District IEIAP

trainees in the block, organizing training at the field level, providing handholding support as and when
required, and ensuring the smooth implementation of all activities.
The Block Level Team would work in close operational coordination and under the guidance of the DIIT
for all block-level activities. The BLT would share field progress and challenges through the DIIT to the
DPM. This ensures a clear and streamlined reporting structure, with the flow of coordination and
updates moving from BLT → DIIT → DPM → Chair.
SRLM: SRLM would have a lead role in the implementation of the IEIAP for interventions that are built
around SHG involvement such as off-farm value-chain improvements, souvenir section, and green
SHGs. They would be instrumental in mobilization for all the interventions at the ground level. SRLM’s
existing structure and capacities would be strengthened under INSPIRES to enable them to undertake
the interventions as planned. SRLM would also be the key to enhancing the marketing of the final
products through their brand ‘SWAYAM SIKKIM’. A point person from SRLM and an implementation cell
would be designated at the State level for IEIAP implementation.
SIRD: SIRD would be the main training partner under RDD for IEIAP implementation. It would provide
all necessary training as required in the IEIAP, such as for business planning, financial management,
entrepreneurship development, etc. Capacity building for the non-farm interventions, such as off-farm
value chains and green jobs would also be taken forward by SIRD. SIRD would prepare training
modules design and conduct ToT for the rollout of training through their identified field facilitators and
CRP teams. SIRD would also prepare monitoring mechanisms to identify the impact of the training
programs on the beneficiaries and upcoming entrepreneurs.
INSPIRES Priority Departments: Priority departments such as the Department of Commerce and
Industry (C&I), Skill Development Department (SDD), Forest and Environment Department, Tourism
and Civil Aviation Department, and others would implement sector-specific initiatives that have
convergence with the IEIAP. These departments would provide resources, expertise, and support for
activities related to entrepreneurship, infrastructure, skill development, etc., as per IEIAP.
District Skill Committee: The District Skill Committee would play a key role in ensuring that duplication
of efforts from various departments is avoided. The committee would identify the key beneficiaries,
training programmes to be offered, training partners, and track the status of the trainees who have been
skilled.
Non-Government Organizations (NGOs), Civil Society Organizations (CSOs): Local NGOs, CSOs,
are envisaged to play a vital role in IEIAP implementation by bringing in their technical expertise. The
District IEIAP committee would identify these organizations through a rigorous process of selection.
These organizations would facilitate the implementation of certain components such as community
engagement and provide technical assistance as required ensuring local governance and participation
in the interventions identified under IEIAP planning. Funds would be released to NGOs/ CSOs/ CBOs
based on agreements with them for specific activities.
Training Partners: Training partners, in addition to SIRD, would be critical for the roll out of IEIAP
implementation. SICB and Skills Development Department would act as a training partner for the rollout
of certain capacity building events at the district level. IIHM and IHCAE would also be training partners
for the tourism interventions. Further, other agencies, entrepreneurs, institutions, organizations or
individuals would also be identified as training partners to engage them to provide skill development
and capacity-building programs. These training partners would be of repute with whom formal MOUs
would be done and proper procurement processes would be conducted. They would design and deliver
training modules tailored to the needs of beneficiaries, ensuring participants acquire relevant skills for
employment and entrepreneurship.
Panchayati Raj Institutions/ Urban Local Bodies: These institutions would be the main partners at
the field level for community mobilization, identification of beneficiaries, and monitoring of the activities.

41 | P a g e

<!-- page 51 -->

Gyalshing District IEIAP

Non-farm Sakhis: Non-Farm Sakhis are a trained pool of community resource women under SRLM
selected from the SHG network who play a vital role in promoting non-farm livelihoods. Their role is
envisaged to assist women and SHG members by identifying candidates for various trades, facilitating
skill development, helping prepare business plans, and linking them with financial institutions and
market opportunities. They would be critical to support the creation and strengthening of microenterprises in sectors like handicrafts, services, and small-scale manufacturing. These community
resource persons are essential for diversifying rural incomes and empowering women beyond
traditional agriculture, thereby fostering sustainable and inclusive economic growth. These Sakhis were
appointed in every district but now require revitalization to effectively support ongoing livelihood
initiatives.

Figure 5: Institutional arrangements for IEIAP

Community Institutions, User Groups, and Beneficiaries: Community institutions, including self-help
groups and cooperatives, are essential for promoting collective action and empowerment. The women
and youths from these collectives would participate in project activities. They would be mobilized into
enterprise groups, clusters, cooperatives, or producers’ company as per the need of interventions. Apart
from contributing to the economic benefits of these institutions, they would further contribute to
decision-making, and ensure the sustainability of interventions, while providing valuable feedback to
improve project implementation.

5.6. Details of key interventions
This section provides a strategic approach for prioritized interventions. It highlights the overview
and background of the intervention, the targeted beneficiaries, capacity building needs, financial
requirements, convergence opportunities, and monitoring approach.

42 | P a g e

<!-- page 52 -->

Gyalshing District IEIAP

Intervention 1: Promotion of community-based tourism in Gyalshing District
with focus on nature and rural tourism
a) Overview of the intervention
Gyalshing District has been a pioneer in community-based tourism promotion in the state. Villages of
Yuksam, Darap, Hee Bermiok, etc. have been promoting community-based tourism through the model
of homestays for the past many years, which have set the pathway for others to follow. The district is
famous for the Khangchendzonga National Park, a World Heritage Site, which attracts many trekkers
annually, contributing to the local economy. Gyalshing also has rich cultural heritage and diversity with a
mix of communities, and cultural showcase is as added tourism product that the district has to offer.
Tourism as an economic activity is one of the main aspirations highlighted during the planning process
from the focus group discussion, employment and enterprise survey and key informant interviews.
Focus group discussion have indicated that many of the GPs in all blocks of the district are at various
stages of tourism promotion. Homestays are also well integrated in the district’s tourism promotion with
many good case practices to be emulated, along with other natural and cultural products. In the FGDs,
tourism as an economic activity came across as one of the main aspirations for the community to be
included in the IEIAP for the district. Scope for eco-tourism, village tourism, and cultural tourism was
also highlighted by the stakeholders. Overall, an intervention around tourism promotion which is
community based and looks at standardization of services while minimizing tourism impacts has great
potential for the district which also provides opportunities for engaging women and youth through its
multifaceted activities.
b) Objectives
The objective of this intervention is to promote community- based tourism in Gyalshing District with the
aim to engage 300 youth and women through various tourism related activities such as awareness
generation, homestays, tourist and nature guides, taxi drivers, etc. The interventions would adopt a twopronged strategy of having a wider scale outreach of sensitization and awareness campaigns for
tourism stakeholders in the district, along with a grounded approach in selected sites wherein
community-based tourism would be initiated or strengthened. Key principles of inclusivity, environmental
sustainability and equity would underscore the intervention.
c) Beneficiary profile
The intervention would focus on youth (18–35 years) and women (up to 59 years) with priority given
to marginalized households in rural and peri-urban areas. Preference would be given to individuals with
prior exposure to tourism activities or demonstrated willingness to be in engaged in the tourism sector.
d) Strategy for implementation
The community-based tourism intervention would be implemented in coordination with Tourism and Civil
Aviation Department and Department of Ecotourism in Forest and Environment Department.
The tourism intervention would begin with institutional strengthening and capacity building by forming
or strengthening tourism bodies at identified sites to ensure participatory planning, implementation,
and monitoring. Community-based tourism planning would be central, involving mapping of natural
and cultural tourism products such as nature trails, monasteries, viewpoints, and homestays, with
wellness and meditation also prioritized. Key stakeholders—including women-led homestay operators,
bird/nature guides, wellness practitioners, and taxi drivers—would be identified, and a training needs
assessment would be conducted.

43 | P a g e

<!-- page 53 -->

Gyalshing District IEIAP

Recce of tourism attractions would be conducted with the support of tourism experts from TCAD and
local tourism bodies to generate firsthand knowledge on the status of the sites being proposed and the
gaps. Documentation of tourism products would also be a key step for supporting the interpretation as
well as for promotional purposes. This would lead to finalization and designing of tourism products
based on the existing resources of the site. Experiences for visitors would be designed to provide
immersive experiences for the tourists through homestays, guided nature walks, cultural performances,
local cuisine, etc.
Comprehensive training for service providers—such as guides, homestay operators, and cooks—
would be organized with help from ecotourism and tourism experts and agencies such as IIHM. IHCAE,
SIRD, etc. Training topics would include hospitality, biodiversity conservation, cultural interpretation, and
wellness tourism. Training modules on each of these topics would be developed along with handbooks
for guides, drivers, homestays, etc. Community-based tourism bodies, other CBOs would also be
included in the training programmes. Additionally, exposure visits and learning trips would be organized
which would help stakeholders understand and adopt best practices.
Efforts to standardize tourism services would be undertaken through stakeholder consultations to
develop codes of conduct for homestays, guides, and tourist sites. A guest feedback mechanism would
also be established to continuously improve service quality.
To support tourism infrastructure, minor upgrades to trails and interpretive elements would be made
wherever necessary. Financial support would also be provided to homestay families for minor
upgradation in necessary items to improve the quality of services for the tourists. For all CBT sites,
interpretation signages like village maps, trail maps, nature awareness signages, etc. would also be
supported. For bringing uniformity and consistency in the design for all tourism sites, interpretation
signage design shall be done for all districts by a single agency.
Minor upgrades for homestays would focus on low-cost improvements that enhance guest comfort
hygiene, and safety. This might include provision of room furnishings, bathroom repairs, solar water

Table 13: Sites for CBT
1

Tourism Sites for CBT promotion
Bermiok,

2
3
4
5
6
7

Martam
Hee Gaon
Sophaka
Uttarey
Upper Khandu
Begha

8
9
10
11
12a.
12b.

Changey
Khechuperi
Ramaythang
Tashiding
Yuksom
Yuksam Dzongri trekking trail development

Lead Dept
Tourism and Civil Aviation
Department

Forest and Environment
Department

heaters, bedding upgrades, dustbins, first-aid kits, fire extinguishers, etc.
Homestays would be selected through a transparent process to ensure that support reaches those with
both potential and genuine commitment. Priority would be given to homestays located in designated
community-based tourism (CBT) sites or clusters, those already operational but in need of small
improvements to meet basic quality and safety standards, and households willing to take part in
mandatory training on hospitality, waste management, and responsible tourism practices. Other factors
would include access to basic infrastructure—such as water, sanitation, and roads—interest in adopting
44 | P a g e

<!-- page 54 -->

Gyalshing District IEIAP

eco-friendly operations, and willingness to contribute through co-investment or linked financing
schemes. Together, these measures would help ensure participating homestays can deliver better
experiences for guests and remain sustainable well beyond the project’s duration.
For tourism promotion, infrastructure upgradation would be a key element that would need to be
addressed for improving quality of visitor experience. Investments for this component would be looked
at through on-going homestay upgradation schemes, and eco trails upgradation through Forest and
Environment Department wherever possible.
Marketing and promotion strategies involving websites, brochures, and social media would be
developed, and tourism stakeholders would be further sensitized to responsible tourism practices. For
scaling up, the project would promote sites through itinerary and package development and collaborate
with travel operators through familiarization tours. These fam tours would also be conducted for the
sites once they are ready in a cluster manner, with the travel agents covering 3 -4 sites during one visit.
10 -12 travel operators shall be part of the familiarization tour.
Digital marketing training and support for website development for the district highlighting all CBT sites,
and for social media promotion would also be provided. Key people from each of the sites would be
trained on digital marketing and social media who would be supported further for maintaining strong
social media presence for all the sites in a dedicated manner.
Monitoring mechanisms—such as visitor surveys and community check-ins—would be used to
evaluate footfall and service quality, allowing for course correction based on feedback. A guest
feedback mechanism would also be established to continuously improve service quality. Familiarization
tours for tour operators would help promote sites to larger networks, and success stories and
testimonial would be documented.
Community members and tourism stakeholders would have opportunities to participate in travel and
trade fairs, and partnerships would be formed with regional and national tour operators and booking
platforms to ensure long-term viability and visibility of the identified tourism sites.
Minimizing tourism impacts, particularly, SWM is a critical one in all tourism sites is a key priority.
Support from local experts or NGOs working in the sector would be taken for handholding and technical
assistance in managing solid waste as per the guidelines in all tourism sites. The current waste
management practice and system being adopted for managing waste in the site would be mapped and
the gaps identified for strengthening under IEIAP in close collaboration with Swachh Bharat Mission
(G). Strengthening relevant solid waste management committees at the village level involving key
stakeholders such as PRIs, SHGs, CBOs, etc. in collaboration with SBM would be facilitated.
An initial workshop would be organized at a cluster level with 3 – 4 CBT sites together to form/
strengthen the committees responsible for waste management. SWM plan and byelaws preparation
would be facilitated with provision of collecting user fees from all waste generators, no littering policies,
reducing single use plastics, and penalty provisions for long term sustainability. The workshop would
also discuss sharing SWM infrastructure at cluster level wherever feasible and explore convergence
possibilities.
With the SWM committee, the scope for having a successful waste management model run by women /
youth engagement or the committee themselves would be looked at for all tourism sites. SHG members
or youth entrepreneur or local NGO / CBO would be identified for their engagement in the initiative who
would be provided exposure to sites where women / youth are working on solid waste management
interventions within the state. The overall operations including collection, segregation and sorting,
management of segregation sheds, garbage fee collection, etc. would be the responsibility of the SHG/
youth.
The SWM committees would be supported to organize awareness programmes to improve waste
management practices as per the plan prepared. Capacity building of SHGs and SWM members would
be conducted as part of the intervention. Support from local experts or NGOs working in the sector
45 | P a g e

<!-- page 55 -->

Gyalshing District IEIAP

would be garnered for handholding and technical assistance in managing solid waste as per the
guidelines in all tourism site
Provision of waste management infrastructure would be important for implementation of the SWM
plan. These would include segregation units/ sheds, baling machines, waste sorting baskets, etc. as
additional support provided to supplement SBM activities. The infrastructure would be made to cater to
the sites at a cluster level, wherever feasible to bring down the cost.
Continued monitoring would be carried out to assess the sustainability of the waste management
intervention by the technical agency through review meetings and workshops facilitated through SBM
convergence. This includes tracking incomes from the sale of recyclable waste and household user fee
collections, exploring CSR funding opportunities, and documenting impact stories to capture learnings
and showcase progress.
At a district level, comprehensive training and sensitization program for tourist taxi drivers is also
planned to be conducted. The training would be conducted in a phased manner as a certified
mandatory course for all taxi drivers to complete within a given time frame. The training would cover
tourism-related topics along with essential soft skills such as effective communication, courteous
behavior, and promotion of the state’s waste management policies. This includes educating drivers on
the ban of plastic water bottles and encouraging the use of recyclable alternatives. Key external
resource persons would be invited to conduct the training.
A Welcome Gate is also proposed in Gyalshing district which would serve as both an entry landmark
and a showcase of local enterprise. Adjacent to the welcome gate, would be one of the marketing
spaces. In addition, the same space would also host an information desk on tourism-related places
and activities in the district. This would ensure that both tourists and locals would access reliable
information, making the centre a combined space for market access, cultural promotion, and tourism
facilitation. TCAD would play a key role in providing information about the tourism destinations in the
district through promotional materials, brochures etc. which would be available in the information desk.
E and S screening would be undertaken to ensure compliance.
Additionally, opportunities to mobilize other sources of funding such as through CSR support would be
explored to support and scale the waste management initiatives. Continued monitoring would be carried
out to assess the sustainability of the waste management intervention. This includes tracking incomes
from the sale of recyclable waste and household user fee collections, exploring CSR funding
opportunities, and documenting impact stories to capture learnings and showcase progress.
e) Institutional roles
Implementation would be led by the District IEIAP Committee and under it the District
Implementation Team would be responsible for overall coordination with the Forest and
Environment Department as part of the Working Group formed for tourism sector under Sikkim
INSPIRES
Organization
District IEIAP
Committee

District IEIAP
Implementation
Team

Roles/ Responsibilities
o
Oversight and regular monitoring
o
Ensuring convergence and coordination with relevant department
o
Financial allocations and budget sanctions
o
Identifying and finalizing technical experts as required
o
Support for social media promotion
o
District level website showcasing CBT sites, Interpretation signages for the
CBT sites
o
Overall coordination and implementation
o
Facilitate convergence with departments through regular coordination and
monitoring
o
Organize training and capacity-building programmes for tourism bodies and
tourism stakeholders
46 | P a g e

<!-- page 56 -->

Gyalshing District IEIAP

Organization
Forest and
Environment
Department
Tourism
Department

RDD- SBM

Tourism bodies/
IIHM/ IHCAE
Non-Farm
Sakhis
Community
Based Tourism
Bodies

PRIs

Roles/ Responsibilities
o
Homestay upgradation wherever required
o
Identification of key trails and sites
o
Planning and trail improvement within forest jurisdiction as required
o
Coordination for convergence mechanisms
o
Coordination for implementation and for capacity building and training,
Support in marketing and promotion
o
Setting standards and certification systems in collaboration with stakeholders
o
Providing financial support to homestays
o
Convergence for support on waste management
o
Onboarding waste management experts for the key sites
o
Awareness generation and sensitization support
o
Infrastructure support such as plastic waste management units/ segregation
sheds through convergence
o
Provide technical input for community-based tourism planning
o
Organize training of tourism service providers
o
Standardization of services, marketing and promotion
o
Mobilize and organize local community members for training and awareness
programmes and for formation of various committees
o
Support in monitoring the waste management activities
o
Mobilize and organize local community members to actively participate in
tourism activities ensuring local ownership
o
Ensure quality standards in hospitality, services, and visitor experience
o
Coordinate with government departments, tourism boards, and private
partners for capacity building, marketing, and infrastructure support
o
Facilitate responsible and sustainable tourism practices that balance
livelihood generation with environmental conservation
o
Coordination with existing community institutions such as SHGs, JFMCs,
EDCs, etc.
o
Community mobilization, planning and monitoring, support in drafting and
implementing tourism regulations

f) Expected impact:
This intervention is expected to result in the training of 300 individuals, the establishment of at least
12 tourism bodies or strengthening of existing ones, and creation of sustained employment
opportunities for at least 150 people.
g) Log Frame

47 | P a g e

<!-- page 57 -->

Gyalshing District IEIAP

Objective

Key Activities

Targets (FY 2025–26 to 2028–29)

Promote
community- based
tourism in
Gyalshing District
through various
tourism related
activities such as
homestays, tourist
and nature guides,
taxi drivers, etc.
services

1.

FY 2025–26:
1.
1.1 Recce of 6 tourism sites and tourism planning and product finalization
1.2 Community tourism bodies formed/ strengthened for the 6 CBT sites
1.3 2 Training and capacity building programmes for CBT sites at cluster level. 2.
1.4 Development of training Module
1.5 CRPs trained for providing on-ground support
1.6 First phase of drivers’ sensitization conducted for 50 drivers
1.7 Trail development work for Dzongri Trekking Trail.
1.8 Entry Gate initiated as a tourism interpretation element in the district.

2.

3.

4.

5.

6.

7.

8.
9.

Formation and
strengthening of
community tourism
bodies
Tourism planning
with community for
identification of
tourism products,
key stakeholders,
and strategies
Training and
capacity building of
tourism service
providers
Provision of
equipment and
interpretation for
enhancing visitor
experience
Marketing and
promotion of
tourism sites
Solid waste
management plans
prepared for the
sites
Capacity building
of youth/ SHGs on
SWM practices in
coordination with
SBM
Enlist support of
technical experts
Awareness and
sensitization of
community on
SWM

Output

FY 2026–27
3.
2.1 Community tourism bodies formed/ strengthened for 6 CBT sites
2.2 Recce and Tourism planning conducted for 8 more sites followed by
product finalization
4.
2.3 8 Training and capacity building programmes for CBT sites at cluster level.
2.4 Provided refresher Training for CRPs
5.
2.5 Development of training Module
2.6 Second phase of drivers training conducted for 50 drivers
2.7 Entry Gate completed as a tourism interpretation element in the district
2.8 40 homestays provided with support as per requirement
2.9 Interpretation signage and promotional material developed for 4 sites.
2.10 Installation of signage in 4 sites
2.11 Capacity building on digital marketing for 6 CBT sites (18
youth/women) and social media presence established for the sites with
follow up support
2.12 Development of brochure for 8 CBT sites (6 CBT sites from Year 1 and
2 CBT sites from year 2)
2.13 Familiarization tour for 12 tour operators to first cluster of 4 villages
2.14 District level CBT website initiated through documentation of CBT sites
2.15 3 workshops conducted through support of technical experts on SWM
for 12 CBT sites (4 sites together) and 12 SWM committees formed
and plans prepared.
2.16 12 awareness sessions conducted (1 each per site) conducted by the
SWM committees
2.17 Infrastructure and linkages for SWM set up for 6 sites
2.18 Monitoring and follow up support

FY 2027–28
3.1 3 Training and capacity building programmes for CBT sites at cluster level.
3.2 Third phase of drivers training conducted for 50 drivers
3.3 40 homestays provided with support as per requirement
3.4 9.4 Interpretation signage and promotional material developed for 4 more
sites.
3.5 Installation of signage in 4 sites
3.6 Capacity building on digital marketing for 6 more CBT sites together (18
youth/women) and social media presence established for the sites with
follow up support
3.7 Development of brochure for 8 CBT sites (6 CBT sites from Year 1 and 2
CBT sites from year 2)
3.8 Familiarization tour for 12 tour operators to 2nd and 3rd cluster of 4 villages

120
homestays
operational
300+ tourism
stakeholders
trained and
150 engaged
in tourism
allied
livelihoods
12 tourism
bodies
functional
12 CBT sites
operational
20-30 allied
business
benefited from
the
intervention

Outcome

Key Performance
Indicators (KPIs)

1.1 Employability of youth
and women improved
because of targeted skill
development, sectorspecific training, and
access to industryrelevant opportunities

1.

No. of training
sessions conducted
2. No. of youth/women
engaged in tourism
and allied sectors.
3. % of women
participated in training
and capacity building
1.2 Increased creation of
programs
tourism enterprises.
4. Number of homestays
created
1.3 Overall environmental 5. Minimum standards
benefits through
being adhered to by
reduction of landfill load
tourism service
providers
6. Number of
employment
opportunities
generated through
enterprises
7. No of code of conduct
/ byelaws for tourism
standards
8. Increase in tourist
footfall
9. Number of
interpretation facilities
SWM
1. No of functional units
of waste management
centres
2. % of homestays
segregating their
waste
3. % of waste recovered
for recycling in waste
management centres
4. % of reduction of
waste to centralized
landfills
5. No. of women and
youth working the
SWM management
sector

Monitoring
measures
1.
2.

3.

4.

5.

6.

7.

8.

9.

Training
reports
Homestay
registration
information.
Guest
registration
books
Code of
conduct
developed by
tourism
service
providers
Byelaws on
sustainable/
responsible
tourism
standards
Session and
event
documentatio
n
Youth/women
participation
and success
stories
Fund
utilization
reports and
market
launch
tracking
Feedback
mechanisms
and field
verifications

Partnerships /
Convergence














District IEIAP
Committee:
logistics, fund
allocation &
monitoring
RDD/T&CAD/FE
D/ IHM/ IHCAE:
Tourism planning
IHM/ IHCAE/
SIRD/ Other
training
partners:
Training and
capacity building
NGOs/CBOs:
Training and
capacity building
Private Sector
Partners/Industri
es: Fam tours
and support in
marketing and
promotion
Technical
Experts: product
development,
business
readiness
Convergence
with Schemes: –
GSDP/ Skilled
Youth Startup
Scheme/
Homestay
scheme:
Infrastructure
upgradation,
Capacity building
Swachh Bharat
Mission for SWM

48 | P a g e

<!-- page 58 -->

Gyalshing District IEIAP

3.9 District level CBT website launched with information available on all CBT
sites
3.10 3 review workshops conducted through support of technical experts on
SWM for 12 CBT sites (4 sites together)
3.11 12 awareness sessions conducted (1 each per site) conducted by the
SWM committees
3.12 Infrastructure and linkages for SWM set up for 6 sites
3.13 Monitoring and follow up support

FY 2028–29
4.1 2 Training and capacity building programmes for CBT sites at cluster level.
4.2 Fourth phase of drivers training conducted for 50 drivers
4.3 40 homestays provided with support as per requirement
4.4 Interpretation signage and promotional material developed for 3 more
sites.
4.5 Installation of signage in 3 sites
4.6 Updated District level CBT website with information available on all CBT
sites
4.7 12 awareness sessions conducted (1 each per site) conducted by the
SWM committees.
4.8 Monitoring and follow up support

49 | P a g e

<!-- page 59 -->

Gyalshing District IEIAP

Intervention 2: Support in setting up processing and value addition facilities
for farm products
a) Overview of the Intervention
Gyalshing’ s economy is largely agriculture-based, with most of the population engaged in farming
despite rocky slopes and uneven terrain that restrict cultivable land. Farmers grow cardamom, ginger,
and oranges as major crops, along with paddy, maize, millet, and pulses. There is also abundant
availability of raw materials such as turmeric, cherry pepper, kiwi, barley, broom grass, meat, poultry,
and dairy products. Findings from E&E Survey, Diagnostic Study, FGDs, and KIIs highlight several
challenges. Farmers face difficulties in aggregation, marketing, and branding of local products,
while the remote location of markets makes distribution costly and unreliable. There are also gaps
in labelling, packaging, and branding, coupled with weak advertising strategies and the absence of
dedicated rural processing infrastructure and marketing centres to support collective selling,
To address these challenges, this intervention seeks to transform traditional agricultural practices into
structured, off-farm enterprise models focusing on value addition and decentralized processing of
high-potential commodities. A state-wide market and value chain study, to be conducted by RDD,
would identify the most viable products for enterprise development. Importantly, there is rising interest
among women and youth to pursue agri-enterprises, which the intervention capitalizes on through
the mobilization of SHGs, producer groups, and cooperatives into collective entrepreneurship
models. The district administration has successfully identified women from Self-Help Groups (SHGs)
who are currently engaged in the production of the specified commodities. Building on their
experience, Sikkim INSPIRES would provide them with infrastructure, modern tools, finance,
branding support, and market linkages, helping them move up the value chain and strengthen their
role in the local economy.
The intervention aligns with key national schemes like PMFME, PMKSY, and NRLM, and introduces
value chain strengthening, Common Facility Centres (CFCs), and digital tools for branding and
market access. The intervention would focus on fostering collective enterprise development,
establishing strategically located Common Facility Centres (CFCs) for processing of multiple
commodities, and strengthening the technical and entrepreneurial capacities of rural producers.
The overall objective is to promote inclusive, and market-responsive entrepreneurship, enhance
income security, and catalyze locally anchored employment opportunities, particularly for women
and youth across Gyalshing district.
Insights from FGDs and KIIs confirm strong interest among SHG members and youth to shift toward
structured enterprise models, particularly in areas like digital marketing, value addition, branding,
packaging, quality control, and logistics. The intervention focuses on building backward linkages
(production, aggregation) and forward linkages (processing, packaging, marketing) to fill
systemic gaps.
b) Objective
The intervention aims to establish three to four key off-farm products for the district by strengthening
rural value chains for the identified products through collectivization of producers into Enterprise
Groups (EGs), the federation of EGs into Producer Companies (PCs), and operationalization of
three CFCs equipped for processing, packaging, and distribution. It would also address the
infrastructure and value addition gap identified in the E&E survey, FGDs, and diagnostic study to build
a decentralized ecosystem that would empower rural communities to shift from raw material selling to
higher-value product-based entrepreneurship. The focus is on creating scalable and sustainable agroprocessing enterprises with low entry barriers and high employment intensity.
50 | P a g e

<!-- page 60 -->

Gyalshing District IEIAP

c) Beneficiary profile
The beneficiaries for this intervention would be youth (18–35 years) and women (36–59 years)
residing in rural areas of Gyalshing district, who are currently engaged in the cultivation, collection,
or informal trade of commodities. These individuals often operate in fragmented value chains with
limited access to processing infrastructure, market linkages, and technical support. In addition,
the intervention would also prioritize inclusion of women and youth who are new entrants into the
workforce, those transitioning from farm to non-farm activities, as well as NEET (Not in Education,
Employment, or Training) youth to ensure equitable access and participation. Special focus would be
given to marginalized groups such as single women-headed households, vulnerable groups including
PWD and unemployed youth. The goal is to engage individuals familiar with or motivated to learn and
grow within the selected value chains through enterprise training and support.
The intervention is structured to directly engage 200 beneficiaries through the formation of 10
commodity specific Enterprise Groups (EGs). The selection process followed a participatory,
inclusive approach involving DIC, SRLM, local Panchayats, SHGs, cooperatives, and relevant
departments.
d) Strategy for implementation
A comprehensive market study and demand-supply analysis would be conducted for the identified
products to gain a thorough understanding of the complete value chain as well as the marketing
linkages. This analysis would assess various factors, including market demand, supply availability,
price trends, and seasonal patterns. Additionally, the study would examine input costs, output prices,
and potential risks associated with the market. By analyzing these elements, this intervention aims to
develop a market-based approach for value chain interventions that would effectively address the
needs and challenges within the market.
Based on extensive stakeholder consultations in Gyalshing, the following products have been
prioritized for processing and value addition to strengthen livelihoods and market linkages:


Turmeric – Cultivated widely in the district, turmeric would be processed into powder, organic
turmeric, and wellness-based products, tapping into both local and export markets.



Cherry Pepper (Dalle Khursani) – With GI recognition and high demand, cherry pepper
would be processed into pickles, sauces, and spice blends for wider commercial value.



Ginger – A traditional crop in the region, ginger would be developed into dried ginger,
powder, candies, teas, and herbal products, ensuring stable income and value addition.



Maize – Maize has scope for flour, snacks, feed, and beverages. Processing facilities would
reduce wastage and enhance its market potential.



Barley – Traditionally grown in upland areas, barley offers opportunities for health foods,
malt-based drinks, and organic niche products.



Kiwi – With favourable agro-climatic conditions, kiwi would be processed into juices, jams,
wines, and dried products, catering to both local and premium external markets.



Meat & Poultry Processing – Hygienic processing units would support production of frozen
cuts, sausages, nuggets, patties, smoked and pickled meat, and ready-to-eat packaged
items.



Dairy Processing – Dairy enterprises would be strengthened through cheese, paneer, butter,
ghee, curd, yogurt, and flavoured milk, catering to both household demand and tourism
markets.
51 | P a g e

<!-- page 61 -->

Gyalshing District IEIAP



Broom Grass –A product widely found across the district, broom grass would be processed
and branded into eco-friendly household brooms and related value-added items, creating
additional income for rural communities.

Mobilization, awareness-building, and the formation of Enterprise Groups (EGs) in the target
villages would be carried out. Altogether, 200 members would be mobilized into 10 Enterprise groups.
This process would involve conducting sensitization and orientation sessions in selected Gram
Panchayats to identify the women and youth for the activity. EGs might focus on a primary commodity
where strong availability and market potential exist but would not be restricted to a single commodity.
EGs might engage in multiple commodities depending on seasonality, production patterns, and
market opportunities, enabling diversification and risk mitigation.
In addition to initial sensitization, a structured awareness creation plan would be implemented
throughout the intervention period. This would include community outreach campaigns,
distribution of IEC materials, and regular stakeholder engagement sessions to ensure that youth
and women remain informed and actively involved in the evolving opportunities under the IEIAPs. The
Non-Farm Sakhi would play a pivotal role in facilitating these awareness activities by acting as a local
mobilizer, conducting door-to-door outreach, and providing ongoing handholding support to potential
members, particularly women and youth interested in non-farm enterprises.
One key component of the intervention is the establishment of three decentralized Common Facility
Centres (CFCs), including two supported through the INSPIRES fund and one through convergence.
Based on the findings of the market and demand–supply analysis, CFCs may be designed for
commodity-specific processing where sufficient and consistent raw material availability exists. In other
locations, CFCs would be designed to provide processing infrastructure and services for multiple
commodities relevant to the district.
The CFCs would be equipped with machinery for cleaning, drying, grading, primary processing, and
packaging, selected based on the commodities identified for processing at each CFC. This ensures
that infrastructure remains responsive to seasonal availability, market demand, and commercial
feasibility. Equipment would therefore be installed only where relevant (for example, oil extraction
units would be considered only where oilseed processing is viable), ensuring optimal utilization and
cost efficiency. The CFCs would be able to provide processing infrastructure and services for multiple
commodities relevant to the district, as identified by the market and value chain study.
The District IEIAP Committee (DIC) would be responsible for identifying government-owned land and
constructing infrastructure for these CFCs at strategic, accessible locations, considering proximity to
production clusters, transport connectivity, and mobility aspects. This location-sensitive planning is
intended to maximize women and youth participation, reduce travel time, and ensure equitable access
to processing facilities.
To ensure design and operational consistency across districts, RDD or an identified external agency
would adopt a state-wide standardized implementation approach for key elements of the CFCs. They
would develop standardized design templates covering infrastructure layout, equipment
specifications, safety and hygiene zones, waste management systems, branding and signage, and
energy-efficient features. RDD/the agency would also prepare and roll out common operational
protocols for workflow management, quality assurance, record keeping, and maintenance to maintain
uniform standards, enable easy replication, and ensure cost efficiency across districts, while allowing
customization of machinery and processing lines based on the commodities handled at each location.
Additionally, Standard Operating Procedures (SOPs) aligned with FSSAI, and environmental norms
would be prepared and implemented, alongside training on machinery use, hygiene, and record
keeping.

52 | P a g e

<!-- page 62 -->

Gyalshing District IEIAP

Infrastructure development would be undertaken through both program funding and convergence with
other funding sources. All land identification and construction activities would adhere strictly to
Environmental and Social (E&S) compliance norms, ensuring transparency, equity, and sustainability.
At a later stage, the formation of a Producer Company (PC) is envisaged to own and manage the
CFCs, ensuring shared benefits, regular monitoring, and continuous improvement. To ensure longterm viability, sustainability plans would be developed for each EG and PC, including operational,
financial, and governance strategies for the facilities established under the intervention.
The Producer Company (PC) formed at the district level would manage long-term business
operations and coordinate value chain activities across various commodities. The Producer
Company would be formed once the EGs have commenced operations and attained a certain level of
maturity. Until its formal registration, the functions envisaged for the PC would be temporarily
managed by DIIT and non-farm Sakhis. The PC would later operate and manage the CFCs. They
would be responsible for product aggregation, CFC operations, market linkages, and financial
management. PCs would also support EGs by providing mentoring support, enterprise services,
and access to credit and insurance. The non-farm Sakhis supporting the EG members would also
be trained and capacitated to support these institutions.
The enterprise groups as well as the PC would be trained in the basics of group formation, and their
roles, followed by advanced training on value chain including packaging and product quality, among
others. Beneficiaries, including EG members and selected youth/women entrepreneurs, would receive
technical, business, and compliance-oriented training, supported by exposure visits to
successful value addition enterprises and continuous mentoring from industry experts. The
enterprise training would be competency-based and aligned with emerging standards in agriprocessing and food safety.
The training programs would be supported by a range of specialized institutions, including KVKs and
ICAR centres for farm-gate and scientific techniques, NIFTEM, NIESBUD, NABARD, and FSSAI
would support food safety, quality assurance, and MSME compliance. SIRD and SSD training
partners would provide support in general technical and vocational skills. Additionally, institutions like
SIRD, KVKs, IIE, NIFTEM, and ICAR would collaboratively contribute to the development of demanddriven, context-specific training modules.
The Producer Company (PC) would be led by a CEO, supported by the Board of Directors (BOD),
responsible for overseeing raw material sourcing, product marketing, governance, finance,
procurement, and data management, while also providing support to the Common Facility Centres
(CFCs). The PC would include an Accounts and Compliance Officer to handle financial
documentation, internal controls, and regulatory filings such as FSSAI and GST. Additionally, a
Product Marketing Coordinator would focus on branding, buyer engagement, and market linkages to
drive sales and growth.
A dedicated team for the CFCs would be deployed for machine operations, processing, and
packaging. The position would be filled through the existing pools of CRPs and block level team
members possessing relevant experience. This team would ensure effective coordination, field-level
execution, and adaptive monitoring. Staffing costs for the PC and CFCs would be borne by Sikkim
INSPIRES program during the initial incubation and stabilization phase (details are provided in the
budget and year-wise phasing (FY 2026–27 to FY 2028–29)). Thereafter, the Producer Company
would progressively assume responsibility for these costs through its own revenues generated from
membership fees, processing fees, product sales and service charges, ensuring long-term
sustainability.
The intervention would also implement a market enablement strategy, which includes branding and
packaging design, participation in local and national trade fairs/melas, digital marketplace
53 | P a g e

<!-- page 63 -->

Gyalshing District IEIAP

onboarding, and facilitation of direct buyer linkages with institutional and private sector partners. To
ensure sustainability, technical partnerships would be forged with entities such as the Krishi
Vigyan Kendra (KVK), state MSME, food processing agencies, and local business mentors.
Business planning and ongoing mentorship are vital for the sustainability and growth of enterprises.
Each Enterprise Group (EG) would prepare its own business plan with support from BFCs, SRLM,
and identified local entrepreneurs/ NGOs, tailored to its commodity, production capacity, and market
opportunities, fostering local ownership and adaptability. They would also be supported by non-farm
Sakhis in developing the business plan. The Producer Company (PC) would consolidate these EG’s
plans into an integrated business plan at the district level, providing a unified strategic roadmap and
coordinated implementation. Technical support agencies, SRLM, and C&I would assist EGs in
developing sound financial and operational projections. A structured mentorship system would link EG
leaders and PC staff with experienced entrepreneurs, financial advisors, and market experts. Regular
sessions, workshops, and peer learning platforms would ensure continuous support, adaptive
management, and readiness for scaling
Overall, the implementation strategy would leverage convergence with key schemes such as PMFME,
AIF, SFAC, APEDA, CSR, TRIFED and NRLM, while being anchored by the District IEIAP
Committee (DIC) supported by the RDD and allied departments.
e) Institutional roles
Organization
District IEIAP
Committee

DIIT/ SRLM

Technical support
agencies/
Entrepreneurs/
NGOs
Commerce &
Industry
Department (C&I)
Producer
Companies

Roles/Responsibilities
o
Support in ensuring convergence for the intervention
o
Overall monitoring of the intervention – financial approvals and
sanctions
o
Oversight on procurement processes for all infrastructure related
expenditure
o
Conduct market study and value chain analysis
o
Mobilize SHGs and farmers and form Enterprise Groups and
Producer Companies along with registration and certification
o
organize training and capacity building for EGs on technical aspects,
business development, collective functioning, etc.
o
Onboarding of technical agencies for conducting specific tasks based
on formal agreements
o
Recruitment and management of the CEO and staff for CFCs
possessing the needed experience around the intervention
o
Manage CFCs until PC is formed and has the capacity to take over
their management
o
Coordination for convergence with relevant departments, NGOs and
through CSR for ensuring additional funding for infrastructure,
capacity building and marketing support
o
Monitoring and tracking of progress and timely reporting
o
Assist with business planning, mentorship, compliance, and SOP
development
o
Provide technical know-how on management of CFCs
o
o
o
o

Equipment certification and provide technology transfer
Advanced training for EGs
Branding via schemes like PMFME and help establish market
linkages and branding
Led by CEO, supported by the Board of Directors (BOD), responsible
for overseeing raw material sourcing, value added product making,
product marketing, governance, finance, procurement, and data
management
54 | P a g e

<!-- page 64 -->

Gyalshing District IEIAP

Organization

CFC coordinators
team
Line departments
(Horticulture/
Agriculture
department/Animal
husbandry)

BFC

Roles/Responsibilities
o
Providing support for the Common Facility Centres (CFCs)
o
Include an Accounts and Compliance Officer to handle financial
documentation, internal controls, and regulatory filings such as FSSAI
and GST
o
Product Marketing Coordinator would focus on branding, buyer
engagement, and market linkages to drive sales and growth
o
Responsible for smooth running of the CFC such as machine
operations, processing and packaging
o
Provide technical guidance on cultivation, varietal selection, scientific
practices, soil health, and post-harvest management
o
Support training on productivity enhancement, disease and pest
management, and quality improvement
o
Provide extension services and advisories relevant to turmeric, ginger,
cherry pepper, large cardamom, and honey value chains
o
Offer technical support for scientific beekeeping, hive management,
colony health, and honey quality (where applicable)
o
Facilitate convergence with schemes such as SFAC, NHB, MIDH,
ATMA, apiculture-related programs as well as other relevant
programs
o
Assist in strengthening backward linkages to ensure consistent raw
material supply for processing
o
Support EGs in preparing business plans, costing, pricing and
financial projections
o
Conduct orientation on compliance, licensing, and documentation
o
Connect EGs to financial institutions, subsidies and credit schemes

f) Expected impact
The intervention would directly address the structural gap between production and market access
through the creation of three CFCs, a PC, and 10 EGs led by women and youth. These efforts are
expected to generate over 200 direct and indirect employment opportunities, with beneficiaries
projected to experience a 10-20% increase in their average income. The enhancement of income is
a rough estimate, and a more reliable figure would be given after conducting the market and value
chain study. Rural producers would transition from fragmented, low-margin raw selling to
organized processing and branded product marketing, leading to greater local value retention,
income diversification, and enterprise viability. The intervention would strengthen institutional
capacities, deepen financial inclusion through formal credit access, and foster gender and youth
responsive entrepreneurship. Its alignment with central schemes, adaptive use of existing
government infrastructure, and climate-conscious design enhance scalability, costeffectiveness, and long-term sustainability. Collectively, these elements would build a resilient
rural enterprise ecosystem that drives inclusive economic growth, social equity, and value
chain integration, positioning Gyalshing as a model for hill-based agri-enterprise development.

55 | P a g e

<!-- page 65 -->

Gyalshing District IEIAP

g) Log frame

Objective
To promote rural
entrepreneurship and
enhancing incomes
of women and youth
through agro
processing and value
chains
for Turmeric, Cherry
Pepper, Ginger,
Maize, Barley, Kiwi,
meat and poultry
processing, dairy
processing and
Broom Grass and
other locally available
Agri Horti products,
with the aim of
enhancing farmer
incomes, reducing
post-harvest losses,
improving product
marketability, and
promoting rural
entrepreneurship

1.

2.

3.

4.

5.

6.

7.

Key Activities

Targets (FY 2025–26 to 2028–29)

Output

Outcome

Market study/
demand supply
assessment of the
identified products
Formation of 10
Enterprise Groups
(EGs) involving 20
members each
Registration of a
federated Producer
Company/
Enterprise.
Establishment of 3
Common Facility
Centres (CFCs) for
primary processing
and packaging
Capacity-building
training for 200
local youth and
women (member of
20 EGs)
Facilitating Market
Linkages and
Branding of ValueAdded Products
Leveraging
government
schemes and
convergence to
ensure financial
sustainability

FY 2025–26:
1.1 Operational guidelines developed
for EGs.
1.2 Non-farm Sakhis trained
1.3 10 Awareness campaign for the
formation of EGs
1.4 100 members mobilized into 5
EG formed and initially trained by
non-farm Sakhis
1.5 Market study and value chain
analysis initiated

Employment
1.1. The EGs
would bring
200 women
and youth
onto the
production
process
1.2. Minimum
50% women
participation
1.3. The
operation of
EGs and
CFCs would
create more
than 10
direct
employments
for the
youth/women

Employment:
1.1 The
engagement of
200 women and
youth in around
10 EG-led
production
activities and
the operation of
three CFCs and
a PC contribute
to enhanced
local
employment
opportunities,
particularly for
rural youth and
women.
1.2 10-20%
increase in
average income
of the EG
members

FY 2026–27
2.1 Market study and value chain
analysis completed
2.2 Non-farm Sakhis trained
2.3 10 Awareness campaign for the
formation of Enterprise groups
2.4 100 members mobilized into
another 5 EG formed and initially
trained by non-farm Sakhis
2.5 Training and capacity building
sessions/exposure visits for the
EGs on processing and value
addition
2.6 Setting up 1 integrated CFC with
machinery and equipment
2.7 Licensing/certification/compliance
for the products
2.8 10 EG Business plans developed
2.9 Branding under the Swayam
Sikkim banner
FY 2027–28
3.1 Training and capacity building
sessions/exposure visits of the
EGs
3.2 2 more integrated CFC set up
with machinery and equipment
3.3 Licensing/certification/compliance
for the products
3.4 Provided Matching/Equity Grant
Support
3.5 Drafting & finalizing byelaws
3.6 PC registration & onboarding
Board of Directors
3.7 Full-scale operations
(management cost of PC) and
training of beneficiaries

Enterprise
2.1. 10 EGs
2.2. 3 Common
Facility
Centre (2
from Inspires
and 1 from
convergence
fund)
2.3. 1 Functional
Producer
Company

Enterprise:
The establishment
of 10 EGs, a
functional Producer
Company, and
three Common
Facility Centres
would strengthen
the rural enterprise
ecosystem, foster
collective
entrepreneurship
and improve access
to infrastructure and
markets.

Key Performance
Indicators (KPIs)
1. No. of beneficiaries
mobilized
2. No. of EGs formed
3. No. of youth/women
trained
4. No. of functional
CFCs and PC
5. No. of staff recruited
in CFCs
6. No. of business
plans drafted
7. Volume of produce
aggregated and sold
by EGs.
8. Annual sales
revenue and profit
margin of EGs and
PC
9. Increase in average
income of
beneficiaries
10. No. of linkages/
MOUs created with
buyers

Monitoring measures
1.

2.

3.

4.

5.

6.
7.

Mobilization
records- MOM,
registration
documents,
EGs formation
report- meeting
minutes, and
group activity logs
Training
attendance sheets,
completion
certificates, and
pre/postassessment
reports
CFC operational
status reports,
infrastructure
setup
documentation,
and utilization logs
Baseline and
endline income
surveys,
beneficiary
interviews, and
income tracking
reports
Sales logs,
MoUs/agreements
with buyers,
transaction
records, and
market linkage
documentation

Partnerships / Convergence
District Administration: Overall
supervision and convergence coordination
2. Rural Development Dept/ SRLM: Lead
implementing agency for all field-level
activities; Technical support and
training. Infrastructure alignment;
Community mobilization, training and field
facilitation
3. SIRD/ C&I: Mobilization, governance,
training
4. Convergence with Schemes: AIF,
PMFME and SFAC – financial support for
infrastructure, equity grant
5. PMFME, AIF, MSME-CDP: Equipment,
utilities, capital investment
6. Startup Sikkim, APEDA, TRIFED:
Branding, design, certification
7. CSR, NABARD, Banks, Private Sector:
Co-investment, logistics, traceability
8. Technical agencies and NGOs: Support
for business planning, compliance, SOP
development, and mentoring
9. Horticulture/ Agriculture Department:
Convergence with Schemes: AIF, PMFME
and SFAC – financial support for
infrastructure, equity grant
10. NABARD: Co-investment for
infrastructure support and other logistics.
11. E-commerce Platforms: Market
integration (Amazon, Flipkart, Sayam
Sikkim)
12. Training partners/ local entrepreneurs
for mentoring and handholding support of
the beneficiaries
1.

56 | P a g e

<!-- page 66 -->

Gyalshing District IEIAP

3.8 PC Business plans developed
3.9 PC operational

(hiring/remuneration/office
expenses)
3.10Monitoring and Evaluation
3.115 products launched and 5+
buyers linked
FY 2028-29
4.1 Licensing/certification/compliance
for the products
4.2 Training and capacity building
sessions/exposure visits of the
EGs
4.3 PC operational
(hiring/remuneration/office
expenses)
4.4 Monitoring and Evaluation
continues
5 products launched and 5+ buyers
linked

57 | P a g e

<!-- page 67 -->

Gyalshing District IEIAP

Intervention 3: Strengthening handicrafts sector in Gyalshing District
a) Overview of the intervention
Local artisans and SHGs are already engaged in producing culturally rich and eco-friendly items.
Traditional skills in bamboo weaving, wool crafts and handmade products reflect the district’s heritage.
However, artisans face challenges in accessing modern design inputs, structured markets, and
enterprise support. This intervention in Gyalshing District promotes sustainable livelihoods by
empowering women and youth through the development, revitalization and commercialization of
traditional crafts and souvenir sector Focused on crafts like bamboo, handloom, knitting and
crocheting, weaving, traditional sheep wool craft and tailoring. The intervention would focus on
strengthening value chains through EGs, targeted skill training, Common Facility Centres (CFCs),
and branding through platforms like Swayam Sikkim—supporting micro-entrepreneurship and
preserving cultural heritage. By improving product quality, expanding market access, and
converging with relevant government schemes, the initiative aims to build resilient artisan
communities and generate sustained income.
Few local agencies are actively promoting Gyalshing’s handicraft sector. Bayul Creation is a
local enterprise based in Gyalshing primarily engaged in crochet-based products, working closely
with SHG women artisans to provide them with livelihood opportunities. They also focus on
branding, digital promotion, and market linkages, helping artisans gain visibility beyond the district.
The demand for strengthening the handicraft sector has emerged from FGDs and E&E survey. In
Gyalshing, knitting thrives across all blocks, with women-led micro-enterprises offering opportunities
for livelihood and market expansion. Bamboo is abundant, and artisans create eco-friendly products
for the tourism sector. Wool products, made from indigenous wool, offer potential for high-quality
items and natural dyeing. In Dentam Block (Karzi Labdang), a handloom production unit would be
established to blend traditional weaving with modern demand, particularly for tourism. These crafts
would enhance livelihoods while preserving Gyalshing’s cultural heritage.
Focus Area

Gyalshing Context &
Opportunities

Required Support & Actions

Bamboo
Craft

Abundant bamboo resources in the
region; strong potential for ecofriendly souvenirs, furniture, and
interior décor aligned with tourism
growth.

Handloom

Presence of cultural textile heritage
with active women weavers; scope
to blend traditional patterns with
modern aesthetics; potential for
forming local clusters and tapping
into the tourism-driven textile
market.
Diverse traditional crafts such as
clay modeling, wooden art; rising
tourist interest offering a ready
market; opportunity for cultural
preservation through product
innovation.

Skill development and training in both
traditional and modern bamboo crafting;
establishment of Common Facility Centres
(CFCs); digital branding and marketing
through platforms like Swayam Sikkim;
support for GI tagging and eco-label
certification.
Design innovation workshops; formation
and strengthening of handloom clusters;
integration with government schemes (e.g.,
Handloom Cluster Development Program);
promotion through exhibitions and online
platforms; training in sustainable practices
including natural dyeing.
Support for product diversification and
innovation; branding and packaging
training; promotion during local festivals
and tourism events; online and offline
market linkages; establishment of craftbased livelihood groups.

Handicrafts

58 | P a g e

<!-- page 68 -->

Gyalshing District IEIAP

Knitting &
Wool Craft

Local access to indigenous wool and
natural fibers; strong base of
women-led knitting activities;
opportunities in natural dyeing and
high-altitude wearables;
underutilized potential in niche
apparel markets.

Wool quality improvement programs; skill
enhancement in advanced knitting and
crocheting; eco-friendly practice training
(e.g., natural dye use); support for value
chain development; convergence with
schemes like PMFME for enterprise support
and financial access

b) Objectives:
The intervention aims to establish 5 enterprise groups mobilizing around 100 SHG members around
the crafts sector with engagement of women in the district. It would organize these trained women into
product-specific clusters, provide advanced skill development and business training, and
ensure access to infrastructure and markets to improve productivity and income. By promoting
entrepreneurship, leveraging government schemes, and other institutional support, the initiative
seeks to create inclusive economic opportunities, preserve traditional crafts, and strengthen
local value chains.
c) Beneficiary Profile for Identified Intervention:
This intervention is specifically designed to empower rural and peri-urban youth and women in
Gyalshing District. It targets two primary groups: those already engaged in artisanal activities,
and unemployed individuals, particularly youth and women who are Not in Education,
Employment, or Training (NEET) and are new entrants seeking non-farm economic opportunities. It
has been widely observed that these individuals often belong to vulnerable groups such as SCs,
STs, low-income households, and those with limited access to formal education or facing disabilities.
It has been observed that they often lack access to formal markets, modern tools, and product
development support. By focusing on skill enhancement, design innovation, upcycling, and
market access, the initiative aims to professionalize these craft-based enterprises and expand
economic opportunities for SHG members, traditional artisan families, and aspiring
entrepreneurs across rural and peri-urban clusters.
d) Strategy for implementation
The strengthening handicraft sector initiative in Gyalshing district is structured around a progressive
intervention plan over a four- year period that begins with community mobilization and artisan
clustering, and moves toward infrastructure development, capacity building, enterprise incubation,
and market integration. This strategy places a strong focus on inclusive participation, with particular
emphasis on empowering women, youth, and marginalized communities, while preserving and
promoting Gyalshing’ s craft heritage—particularly in bamboo craft, handloom weaving, handicrafts,
knitting, and traditional wool craft.
To ensure market relevance and sustainability, a comprehensive market study and demand-supply
analysis would be conducted for the identified products to gain a thorough understanding of the
complete value chain as well as the marketing linkages. The findings would guide product selection,
cluster formation, training design, infrastructure planning, and market linkage strategies,
ensuring alignment with demand trends and pricing dynamics.
Based on the study outcomes, five product-specific Enterprise Groups (EGs) would be mobilized
and formed through Self-Help Groups (SHGs), Producer Groups (PGs) under SRLM/NULM, youth
59 | P a g e

<!-- page 69 -->

Gyalshing District IEIAP

collectives, and other grassroots institutions. Awareness campaigns and orientation sessions
would be conducted at the village and cluster levels, followed by baseline mapping to identify
artisan networks, skill concentrations, and production hubs across key locations in the district.
Capacity building would be delivered in a phased and competency-based manner. Introductory
training would be provided to approximately 100 SHG members and youth artisans, focusing on
souvenir product development that integrates traditional skills with contemporary design and
utility. Advanced training would be offered to experienced artisans to promote innovation, quality
standards, and value addition. Training modules would cover craft skills, design innovation,
quality control, packaging, branding, digital literacy, financial literacy, enterprise management,
eco-friendly practices, and social media marketing. Training support would be provided by local
NGOs, professional designers, entrepreneurs, and institutions such as NID, NIFT, SIRD, and the
Department of Commerce and Industries (C&I), complemented by exposure visits, certified
workshops, and structured mentorship, aligned with SFURTI and PMFME frameworks.
A key component of the intervention is the establishment of two decentralized Common Facility
Centres (CFCs) aligned to specific craft clusters. One CFC and its related equipment and tools are
proposed to be fully funded through the INSPIRES fund, while the other CFC is planned to be
completed through convergence with the Department of Commerce and Industries or any other
relevant departments or programs. These CFCs would be equipped with production tools, safety
gear, packaging units, and quality control infrastructure, and would function as shared
production, training, and demonstration hubs. Managed through a federated model involving
EGs, SHG federations, and non-farm sakhis, the CFCs would enhance productivity,
standardization, and collaborative learning, while also serving as demonstration and outreach
spaces for artisans, students, and visitors.
A dedicated operational team, including a market linkage coordinator and CFC facilitators, would
be deployed to support processing, packaging, and day-to-day operations. These roles could be
sourced from existing CRP pools and block-level teams, ensuring effective coordination, field
execution, and adaptive monitoring.
These CFCs would be equipped with production tools, safety gear, packaging units, and quality
control infrastructure, and would function as shared production, training, and demonstration
hubs. Managed through a federated model involving EGs, SHG federations, and non-farm sakhis,
the CFCs would enhance productivity, standardization, and collaborative learning, while also
serving as demonstration and outreach spaces for artisans, students, and visitors.
A dedicated operational team, including a market linkage coordinator and CFC facilitators, would
be deployed to support processing, packaging, and day-to-day operations. These roles could be
sourced from existing CRP pools and block-level teams, ensuring effective coordination, field
execution, and adaptive monitoring.
The District IEIAP Committee (DIC) would support land identification on government-owned land
and oversee infrastructure development for the CFCs at strategic and accessible locations,
considering cluster proximity, transport connectivity, and women and youth mobility. Standard
Operating Procedures (SOPs) and environmental and social (E&S) norms would be prepared
and implemented, alongside training on machinery use, hygiene, and record keeping.
Infrastructure development would be supported through INSPIRES funding and convergence with
schemes such as SFURTI, PMFME, ASPIRE, and the Department of Commerce and Industries,
with a preference for utilizing existing structures requiring minimal refurbishment. Sustainability
plans covering operational, financial, and governance arrangements would be developed for each
EG.
60 | P a g e

<!-- page 70 -->

Gyalshing District IEIAP

Working capital and operational support would be provided as grants to EGs and CFCs through
INSPIRES grants, enabling access to raw materials, tools, and day-to-day operational inputs.
This support would reduce reliance on informal credit, improve financial stability, and enable
artisans to meet market demand and undertake larger orders. Additional financial support would be
facilitated through Community Investment Funds (CIFs) under SRLM, credit linkages, and
convergence with schemes such as PMFME, PM Vishwakarma, SFURTI, NRLM, SIDBI initiatives,
and CSR partnerships. Institutions such as the Crafts Council of India could also be engaged for
capacity building support.
The intervention would prioritize market integration and digital branding. Products would be
promoted under the “Swayam Sikkim” brand, emphasizing authenticity, eco-consciousness, and
local identity. Artisans would be supported in obtaining certifications and labelling such as
Handloom Mark and Craft Mark. Digital enablement would include onboarding onto platforms such
as Swayam Sikkim, ONDC, and selected e-commerce platforms, supported by training in digital
storytelling, brand building, and online customer engagement. Offline marketing would focus on
tourist locations, district markets, exhibitions, and cultural festivals, with linkages to tour
operators and tourism stakeholders. Local and national level expos, cultural festivals, and tourism
fairs would be leveraged to increase artisan visibility, buyer linkages, and drive sales. Collaborations
would be built with tour operators, guides, and local tourism stakeholders to integrate local crafts into
eco-tourism itineraries.
Business plans would be developed for each EG with support from Business Facilitation Centres
(BFCs), SRLM, and C&I, covering product strategy, pricing, marketing, financial planning, and
governance mechanisms. Cluster facilitators and block-level support systems would provide
ongoing handholding, supported by periodic impact assessments and beneficiary feedback
mechanisms.
The initiative would also support artisans in accessing entitlements under schemes such as
“Pehchan” by the Ministry of Textiles, ensuring linkage to skill development programs, marketing
support, and financial assistance. Cluster staff and CFC managers would assist artisans in the
application and enrolment processes.
Through this comprehensive intervention, the project aims to train over 100 artisans, improve
income levels by 15–20%, create more than 20 unique Gyalshing-based handicraft items which
would be promoted as souvenirs, and build a robust non-farm economy that reflects and preserves
the district's cultural heritage. The strategy would drive inclusive, women-led entrepreneurship and
establish Gyalshing as a prominent hub for eco-conscious, handcrafted souvenirs in the state.
d) Institutional roles:
Organization
District IEIAP
Committee

DIIT/ SRLM

Roles/Responsibilities
o
Support in ensuring convergence for the intervention
o
Overall monitoring of the intervention – financial approvals and
sanctions
o
Oversight on procurement processes for all infrastructure related
expenditure
o
Conduct market study and demand supply analysis
o
Identification of artisans and potential beneficiaries though non-farm
sakhis, basic training on functioning of EGs, and market linkage via
Swayam Sikkim

61 | P a g e

<!-- page 71 -->

Gyalshing District IEIAP

Organization

Technical support
agencies/
Entrepreneurs/
NGOs
Commerce &
Industry
Department (C&I)/
SDD

Roles/Responsibilities
o
Coordination for convergence with relevant departments, NGOs and
through CSR for ensuring additional funding for infrastructure, capacity
building and marketing support
o
MOUs processes with local NGOs, designers, entrepreneurs and
design and art institutions
o
Explore partnership with Design and art institutions like TISS, NID, and
NIFT for innovation, incubation, and product development support
o
Onboard Retail and e-commerce platforms like SWAYAM, ONDC,
Amazon, Flipkart and TRIFED to facilitate product placement and
branding
o
Crafts Council of India could also be partnered with to contribute to
artisan training, and CSR partners would support infrastructure and
capacity building
o
Monitoring and tracking of progress and timely reporting
o
Assist with business planning, design input, capacity building and
mentorship, compliance, and SOP development
o
Provide technical know-how on management of CFCs
o
o
o

SIRD
DHH
BFC

NGOs/ Expert
entrepreneurs

o
o
o
o
o
o

Non-farm Sakhis

o

Cluster facilitators
and market linkage
coordinators

o
o

Coordinate skill training efforts, ensuring they align with industry
standards to enhance employability
Equipment certification and provide technology transfer; Advanced
training for EGs
Branding via schemes like PMFME and help establish market linkages
and branding
Training on financial literacy, business planning, etc.
Support artisan registration, quality control, and design validation
Support EGs in preparing business plans, costing, pricing and financial
projections
Conduct orientation on compliance, licensing, and documentation
Connect EGs to financial institutions, subsidies and credit schemes
Work as per MOUs for field facilitation, basic training, handholding and
support in production process
Mobilizing trained self-help group (SHG) women and day to day
monitoring
Work with the trained SHG members, Non-Farm Sakhis, and other
SRLM officials at the district level
Effective planning, coordination and field level execution

f) Expected impact
The initiative is expected to strengthen Gyalshing district’s non-farm economy by creating a vibrant
and inclusive souvenir ecosystem anchored in traditional crafts and market-driven strategies. Through
the formation of five EGs and the training of 100 SHG members and youth, the project would enhance
skills, productivity, and employability, with a strong focus on women and young artisans.
The establishment of 2 Common Facility Centres (CFCs) would boost production efficiency and
product quality, supported by the provision of tools, raw materials, and operational assistance.
Development of over 20 new souvenir items and improved access to digital platforms like Swayam
Sikkim would enhance market visibility, branding, and product demand. With a target of ≥50%
women's participation, the intervention aims to foster economic empowerment, gender inclusion, and
62 | P a g e

<!-- page 72 -->

Gyalshing District IEIAP

resilient non-farm livelihoods. Beneficiaries are expected to experience a 15–20% increase in average
income; however, this figure is a preliminary estimate, and more accurate projections would be
available following the completion of a detailed market study.
The intervention would contribute to economic empowerment, gender inclusion, and resilient non-farm
livelihoods. The integration of enterprise mapping, capacity building, and collaboration with training
institutions and entrepreneurs would strengthen local value chains and entrepreneurship ecosystems.
The project would promote sustainable cultural preservation, stimulate inclusive local economic
development, and position Gyalshing’ s artisan sector as more competitive and market-ready in both
traditional and digital skills.

63 | P a g e

<!-- page 73 -->

Gyalshing District IEIAP

g) Log frame
Objective

Key Activities

Targets (FY 2025–26 to 2028–29)

Output

Outcome

To empower
women and
youth in
Gyalshing by
developing the
souvenir sector,
revitalizing
traditional
crafts,
enhancing skill
sets, and
connecting
artisans to
markets for
sustainable
livelihoods and
economic
inclusion.
(Focus:
Bamboo Craft,
Handloom,
Handicrafts,
Knitting,
Traditional Wool
Craft, herbal
soap, wood
craft etc.)

1. Market study/
demand supply
assessment of
the identified
products
2. Formation of at
least 5
Enterprise
groups
3. Capacity building
and training for
100 youth and
women artisans
4. Establishment of
2 integrated
Common Facility
Centres (CFCs)
5. Provision of
working capital
and operational
support
6. Development
and marketing of
branded
products under
"Swayam
Sikkim" and
leveraging ecommerce
platforms
7. Convergence
with government
schemes to
ensure
sustainability and
scale for
sustainability

FY 2025–26
1.1 Market study Initiated- Development of ToR, onboarding agency,
field visits for research
1.2 100 artisans mobilized and trained
1.3 10 Awareness and orientation campaign conducted
1.4 5 EGs formed and basic training in group process
1.5 1 workshop for design innovations

Employment
Generation

Employment
Generation

1.1

1.2

FY 2026–27
2.1 Market Study completed and products finalized
2.2 MOUs with local and national training partners
2.3 Training sessions for EGs on different souvenir crafts including
training on quality control, packaging, labelling and branding
2.4 Artisans receive advanced training with tools support
2.5 1 CFC formed and operationalized
2.6 1 workshop for design innovations
2.7 2 exposure visits of new designers to local designers and
handicraft artisans
2.8 10 new products launched
FY 2027–28
3.1 MOUs continued with local and national training partners for
onboarding
3.2 All 5 EGs and 1 CFC are fully operational through working capital
support
3.3 2nd CFC formed and operationalized
3.4 Training sessions organized on different crafts, quality control,
packaging, labelling and branding
3.5 Additional artisans receive tool and equipment support
3.6 Licenses/certifications/artisans’ cards as required
3.7 15+ branded products developed.
3.8 Products linked to new markets/ online platforms
FY 2028–29
4.1 Continued support from training partners.
4.2 2 CFCs fully operational
4.3 Comprehensive training in quality control, packaging, labelling

and branding
4.4 Licenses/certifications/artisans’ cards as required
4.5 20+ branded products
4.6 Monitoring and scaling of the activities

1.3

100 artisans
engaged in
production
activities
Minimum 50%
women
participation
8 direct
employment
opportunities
created for
youth and
women in EGs
and CFCs

Enterprise
Development
2.1
2.2

2.3

2.4

5 EGs formed
and operational
2 CFCs
established and
functional
20 branded
souvenir
products
introduced
100 artisans
supported with
working capital,
and market
assistance

1.1

1.2

1.3

100 artisans
actively
engaged.
At least 50%
women
participation.
8 youth and
women gain
direct
employment
through EG and
CFC operations

Enterprise
Development
2.1

2.2
2.3

2.4

Strengthened
micro-enterprise
ecosystem.
5 EGs formed
and operational
100 artisans
supported with
toolkits, working
capital, market
linkage and
mentoring
20 branded
souvenir
products
introduced in
digital platform
including
SWAYAM

Key Performance
Indicators (KPIs)
1
Number of
EGs formed
and
operational
2
Number of
artisans
trained (%
women/
youth).
3
Number of
CFCs
operational
4
Number of
products
developed
5
Number of
artisans
receiving
working
capital
6
% increase in
artisan
income
7
%
women/youth
participation

Monitoring
measures
1
Training
attendance
sheets and
certification
records.
2
Cluster/CFC
activity
progress
reports.
3
Product
development
and branding
documentation.
4
Artisan card
registry and
status updates.
5
Sales reports
and digital
platform
analytics (e.g.,
Swayam
Sikkim).
6
Utilization
reports for
working capital
and tools.

Partnerships /
Convergence
1
District IEIAP
Committee (DIC):
Implementation lead,
convergence, planning,
monitoring
2
SRLM/RDD: SHG
mobilization,
community-level
coordination, and
training support.
3
DHH (Directorate of
Handicrafts &
Handloom): Craft
validation, design
innovation, and
technical support
4
C&I/Skill Development
Dept.: Skill
formalization,
enterprise
infrastructure, and
funding support
5
Design & Market
Partners (e.g.,
Echostream, NID,
NIFT): Branding,
design, packaging, and
marketing expertise
6
NGOs/CSRs: Field
training and mentoring
support
7
Retail and Digital
Market Linkages
(Swayam Sikkim, ecommerce platforms):
Market access,
branding, and sales
channels
8
Government Schemes
Convergence: PMFME,
PM Vishwakarma,
SFURTI, AIF, NRLM,
NABARD, DC
(Handicrafts), Sikkim
INSPIRES

64 | P a g e

<!-- page 74 -->

Gyalshing District IEIAP

Intervention 4: Promotion of Green SHG Enterprises for production of
Reusable and Ecofriendly Products
(Cotton Khada, Prayer Flags, Reusable Sanitary Pads)
a) Overview of the intervention
Sikkim is a beacon state in the country for the promotion of green initiatives. The state is well known
for its best practices in sustainable waste management under the Swachh Bharat Mission, providing a
strong opportunity to align activities under Sikkim INSPIRES to further expand these green
interventions and bolster the state’s green image.
Self-help groups in the state have been engaged in various activities that promote eco-friendly
products or reduce single-use plastics. Initiatives with strong potential would be further scaled up by
identifying key products for the districts and state. However, challenges persist as the widespread use
of synthetic khadas, prayer flags, and disposable sanitary pads continue to generate nonbiodegradable waste threatening the fragile Himalayan ecosystem. SHGs working on eco-friendly
products face barriers such as limited access to raw materials, inadequate technical skills, low
product visibility, and difficulties in scaling due to restricted financial resources.
Although many of these SHGs have been running as pilots they hold good potential for scale up
provided their most pressing challenges are addressed. Hence, this intervention is proposed to be
taken up under the IEIAP in Gyalshing District.
Focus
Area

Gyalshing Context &
Opportunities

Required Support & Actions

Cotton
Khada

Existing SHG groups are already
engaged in manufacturing, waste
reduction through avoiding
synthetic products, large
customer base due to cultural
significance
Strong cultural and religious
demand sustaining year-round
sales; opportunity for eco-friendly
alternatives to synthetic flags;
potential for bulk orders from
monasteries, homestays, and
tourism outlets

Skill training on production process; eco-friendly
practice training (e.g., natural dye use);
convergence with like PMFME for enterprise
support and financial access; marketing support
and awareness programs

Prayer
Flags

Reusable
Sanitary
Pads

Opportunity to reduce
dependence on commercial
synthetic pads and promote
biodegradable options; strong
potential for institutional buyers
like schools, ICDS centres, and
health departments

Skill training on traditional and screen-printing
methods; training on natural, eco-friendly dyes;
support for design diversification (tourismfocused motifs, customized flags); convergence
with schemes under NRLM for credit and
enterprise strengthening; branding, packaging,
and market linkage support through retail outlets,
monasteries, and tourism networks
Skill training on hygienic production techniques
and quality standards; convergence with
schemes under NRLM for machinery, working
capital, and enterprise support; facilitation of
certifications (BIS/basic hygiene compliance);
linkage with health institutions and schools for
bulk orders; awareness campaigns on menstrual
hygiene to increase market acceptance and
outreach

65 | P a g e

<!-- page 75 -->

Gyalshing District IEIAP

Natural
and Herbal
Soaps

Abundance of natural ingredients
like mug wort, marigold, etc. to
be used for soap making. Basic
training received by SHGs on
soapmaking.

Formation and strengthening of clusters;
integration with government schemes, Product
promotion through tie ups and agreements with
the state’s hospitality industry, training in
packaging and branding. Policy and awareness
support for promotion of ecofriendly options.

b) Objectives
The objective is to provide support for existing and new enterprises in the green sector, specifically
waste management and provide economic opportunities to women and youth. The initiative aims to
scale up ongoing activities that promote reusable and biodegradable products to support and
strengthen the flagship Swachha Bharat Mission being implemented in the district.
The intervention aims to equip 75-80 women & youth with technical and entrepreneurial skills to
promote green initiatives for reducing plastic waste through the promotion of reusable or
biodegradable products finalized after a market study. The intervention would facilitate the
establishment of 5 EGs and 3 CFCs over four years, with potential linkages with youth entrepreneurs.
The intervention would facilitate the participation of women and youth in the capacity building
initiatives, and to overcome few economic and social barriers.
c) Beneficiary profile
The intervention would focus on youth (18–35 years) and women (up to 59 years) from low-income,
SHG-linked, or marginalized households in rural and peri-urban areas Eligible beneficiaries would
include those linked with Self-Help Groups or identified through local community organizations and
the SRLM network. Preference would be given to individuals with prior exposure to the green jobs
sector or related activities, or a demonstrated interest and aptitude for skilling and enterprise
development aligned with the sector, as well as applicants from disadvantaged social groups and
economically weaker sections to ensure inclusive participation.
d) Strategy for implementation
A market study would be initiated to understand the various single use products that would
potentially be replaced by reusable ones or natural/ biodegradable products. These would be in the
field of packaging material, plastic wrappers, workshop kits, carry bags, cutlery items, etc.
Enterprise group formation would be conducted with the support of SRLM and the block level
teams that include beneficiary identification and mobilization into clusters using the SRLM network for
rural areas. For urban areas, the support of NULM under the Urban Development Department would
be enlisted. Enterprise groups would be formed with 10 – 15 members per group, based on
preference and existing skills. To ensure long-term viability, sustainability plans would be developed
for each EG, including operational, financial, and governance strategies for the facilities established
under the intervention.
Linkage with entrepreneurs as trainers/ resource persons for product design and skill
enhancement would be a key component to begin the intervention. At least 2 resource
persons/entrepreneurs would be attached with the enterprise groups to provide long-term support in
product manufacturing, quality control, and design innovations. Product design interventions would
also be a key component to ensure that the products are attractive and affordable. Efforts for making
training as accessible to the groups as possible would also be made to ensure that the barriers posed
by distance, timing, etc. are negated.
66 | P a g e

<!-- page 76 -->

Gyalshing District IEIAP

Working capital and other operational support would be provided post training for the clusters for
equipment and linkage to raw material for long term sustainability of the intervention. For upcycled
cloth products, collaborations for sourcing of raw material would be forged with urban local bodies and
PRIs. Collection drives and storage spaces for the recovered material would be made available in
collaboration with the local bodies and NGOs working in the waste sector. Existing spaces in urban
areas for urban SHGS would also be explored to create common working facilities in convergence
with ongoing programmes like DAY-NULM.
Common Facility Centers would be established in strategic locations at the block level. CFCs would
be equipped with production tools, safety gear, packaging stations, and quality control infrastructure.
The CFCs would serve as shared facilities for artisans to work efficiently, improve quality standards,
and increase productivity. These centres would be managed through a federated model involving EGs
supported by SHGs federation and non-farm sakhis. To ensure long-term viability, sustainability plans
would be developed for each EG, including operational, financial, and governance strategies for the
facilities established under the intervention.
Land or existing building spaces would primarily be allocated by DIC, while renovation, refurbishment,
or extension works would be undertaken through INSPIRES resources or in convergence with SBM,
UDD, and other line departments. In peri-urban areas, unused municipal buildings, ward community
centres, or existing NULM spaces would be assessed and repurposed to serve as CFCs.
Business mentoring and incubation support would be provided by SIRD, RSETIs, MSME, C&I
partners and domain experts to ensure enterprise viability and compliance. BFC would support the
EGs to prepare its own business plan tailored to its commodity, production capacity, and market
opportunities, fostering local ownership and adaptability.
Facilitating marketing linkages would be a key strategy underpinning the intervention, ensuring that
SHG and artisan products reach buyers through exhibitions, tourism networks, district markets, and
other channels. In addition, policy measures would be important to support demand creation, such as
prioritizing SHG-produced reusable items in government procurement and events. To ensure a steady
local supply, the state government would be a key buyer, and policy provisions mandating the use of
SHG-produced reusable items in government events would be developed. Policy support for adoption
of reusable products of SHGS to be given preference for all Government supplies. A key marketing
strategy for soaps would also be to explore tie ups with businesses in the hospitality sector to ensure
regular supply.
Training on social media usage, digital literacy, etc. Training on social media usage, digital
literacy, etc. for SHG enterprises for marketing and promotion would be a key component. SWAYAM
Sikkim branding would be used as the main brand for the marketing of these products. SIRD’s
facilities and resource persons would also be leveraged for enhancing the capacities of the
enterprises.
e) Institutional roles
Organization
District IEIAP
Committee/ DIIT
SRLM

Roles/Responsibilities
o Facilitating convergence with relevant departments
o Space allocation wherever required
o Monitoring the overall progress of the initiative
o Provide support in conducting market study
o Identification of SHG women and potential beneficiaries though non-farm
sakhis
o Conduct basic training on functioning of EGs
o Prepare TORs for technical partners (local trainers/ entrepreneurs/ design
firms) to be onboard through formal agreements
o Onboarding of training partners for providing technical support as required
o Facilitate convergence with relevant departments and for CSR support
o Organizing workshops and training
67 | P a g e

<!-- page 77 -->

Gyalshing District IEIAP

o

SBM

o
o
o
o
o
o
o
o

BFC

o
o

Technical
experts /NGOs/
entrepreneurs

o
o
o
o
o

PRIs/ULBs

o

SIRD

C&I

Facilitate marketing channels through govt departments and tie-ups with
hospitality sector
Support in business plan development for green enterprises
Identify technical experts for implementation
Facilitate training and skilling for EGs
Support in providing business mentoring and incubation support
Provide technical training for product development
Extend support for product certification, branding and packaging
Facilitate market linkages through state-level platforms
Support in providing awareness on single use plastics eradication and
promotion of reusables
Support in policy push for SHG manufactured reusable products
Support EGs in preparing business plans, costing, pricing and financial
projections
Conduct orientation on compliance, licensing, and documentation
Connect EGs to financial institutions, subsidies and credit schemes
Provide technical support as per agreement.
Support in design inputs, conducting capacity building and mentorship.
Provide long-term handholding to groups and support in the production
process.
Identify beneficiaries and support community outreach and mobilization

f) Expected impact
This intervention is expected to result in the training of at least 75- 80 youth and women and
establishment of 5 green Enterprise Groups It would also promote reusable products and minimize
the impact of tourism in key sites thereby contributing to environmental conservation outcomes. Three
functional mini–Common Facility Centres (CFCs) would be established, enhancing infrastructure and
service delivery across interventions. Overall, the intervention aims to improve livelihoods, resulting in
a 5–10% increase in the average income of the beneficiaries.

68 | P a g e

<!-- page 78 -->

Gyalshing District IEIAP

g) Log frame
Objective

Key Activities

Equip 80 youth
and women with
technical and
entrepreneurial
skills for promoting
green initiatives for
reducing plastic
waste.

1.
2.
3.

4.

5.

6.

7.

Targets (FY 2025–26 to 2028–29)

Output

Outcome

Key Performance
Monitoring measures
Partnerships / Convergence
Indicators (KPIs)
Conduct Market
FY 2025–26:
1.1 At least 5080
Employability of
1. No of products
1. Training reports
1. District IEIAP Committee:
Study
1.1 Market study initiated
women involved youth and women
identified
2. Business registration
Fund allocation & monitoring,
Formation of 3 - 5
1.2 Operational Guidelines developed for EGs
in green
improved because of 2. % of women
and operational
Policy support for SHG
enterprise groups
1.3 10 Awareness campaigns and orientation sessions at
enterprise
targeted skill
participated in training
tracking
products promotion.
Product design and
village/cluster level
1.2 5 enterprise
development, sectorand skilling programs
3. Session and event
2. RDD/SRLM: mobilization of
co-creation
1.4 5 EGs formed and initial training conducted.
groups
specific training, and 3. Number of enterprises
documentation
SHG women, marketing and
workshops with
1.5 One onsite/offsite training/exposure visit as required
established
access to industrycreated
4. Youth/women
branding of products,
experts and SHGs
initiated
1.3 3 CFCs
relevant
4. Number of employment
participation and
3. SDD: Training and marketing
Onboarding of
established
opportunities
opportunities generated
success stories
support.
technical experts/
FY 2026–27
1.4 2 resource
through enterprises
5. Fund utilization reports 4. Technical experts/ green
entrepreneurs
2.1 Market Study completed and products finalised
persons/
Increased creation of
and market launch
entrepreneurs: Product
Capacity building for 2.2 1 Stakeholder consultation organised
entrepreneurs
formal microtracking
design, skill refinement
skill
2.3 Onboarded one training partner for module
working with SHG enterprises, and
6. Feedback mechanisms
support, monitoring.
enhancement and
development. Training and post training handholding
women
improved access to
and field verifications
5. SIRD: Business planning /
other sectoral
2.4 Three onsite/offsite training/exposure visit as required
market-linked
Digital marketing support/
training
initiated
opportunities
social media outreach
Provision of
2.5 1 CFC set up with required formalities
6. Convergence with
equipment,
2.6 1 Awareness programmes on reusable/single use
Overall
Schemes: Swachh Bharat
infrastructure and
plastics
environmental
Mission/ Skilled Youth
tools and working
benefits through
Startup Scheme-technical
capital.
FY 2027–28
reduction of single
guidance & mentoring
Support in marketing 3.1 Onboarded one training partner for continued
use plastics
linkages for products
handholding
3.2 Three onsite/offsite training/exposure visit as required
initiated
3.3 2 CFC set up with required formalities
3.4 1 Awareness programmes on reusable/single use
plastics
3.5 Market linkage through govt events and online
platforms
FY 2028–29
4.1 Onboarded one training partner for continued
handholding
4.2 Three onsite/offsite training/exposure visit as required
initiated
4.3 3 CFC fully operational and functional
4.4 1 Awareness programmes on reusable/single use
plastics
4.5 Market linkage through govt event and online
platforms

69 | P a g e

<!-- page 79 -->

Gyalshing District IEIAP

Intervention 5: Facilitate skill development for youth and women in non- farm
sectors
a) Overview of the Intervention
In the E and E survey conducted, youth showed strong interest in new-age vocations like drone
technology, photography, video editing, online education, etc. which align with both digital aspirations
and market trends. There was also a strong indication that the current skilling programmes had a
mismatch with market demand, which needs to be bridged. Consultations have also revealed that skill
training focuses only on basic skill provision, and a need for advanced training, skill refinement
training was expressed by both women and youth. This initiative aims to bring collaborative approach
for skilling the youth and women of the district on various non- farm sectors focusing on high-potential
emerging trades such as automobile repair, laundry services, furniture making, beauticians, electronic
repair, masonry, fabrication, tailoring carpentry, plumbing, digital content creation, event
management, therapy-based wellness and other related vocations.
To ensure impact and scalability, the intervention is designed to align with and leverage existing
government schemes such as PMEGP, DAY-NRLM, PMFME, Startup India, and MSME-CDP. This
alignment aims to optimize convergence of public and private resources, provide technical and
capacity-building support, and establish clear sustainability pathways for budding entrepreneurs.
b) Objectives
The objective of this intervention is to provide comprehensive training that facilitates both
entrepreneurship and employability, targeting the skilling of 300 women and youth. By addressing
critical gaps faced by first-generation entrepreneurs, particularly in skills development and support—
the initiative aims to create pathways for self-employment and enhance job opportunities in various
sectors. Through a well-planned strategy and collaboration with experienced entrepreneurs under the
District Skill Committee, the intervention seeks to improve business resilience and reduce income
inequality among low-income households. Ultimately, the broader goal is to foster a decentralized,
demand-responsive rural service economy that encourages inclusive participation from the women
and youth of Gyalshing district, empowering them to thrive in both entrepreneurial ventures and the
job market.
The objective is not only to provide training but also to facilitate both enterprise establishment as well
as employment in identified sectors such as:







Two-wheeler taxi services by women
Auto repair centers
Digital services
Handyman services for households
Solar panel repairing/technician
Other traditional non-farm skilling areas like tailoring, carpentry, electronics and electrical
repairing etc.

c) Beneficiary profile
The intervention targets mainly youth (18–35 years) as well as women (up to 59 years) from lowincome, Self-Help Group (SHG)-linked, or marginalized households in Gyalshing’ s rural and periurban areas. Preference would be given to individuals with informal exposure to service-based
activities or a demonstrated willingness to undergo skilling and enterprise development training.

70 | P a g e

<!-- page 80 -->

Gyalshing District IEIAP

d) Strategy for implementation
Strengthening the District Skill Committee
The District Skill Committee would be strengthened under the leadership of the District Collector for
carrying out coordinated and strategic efforts for skilling youth and women in the district. The
committee would be responsible for shortlisting the key training courses for the year to be offered in
the district, which would be most relevant and for identifying the training partners for conducting the
training. The list of courses would consider existing courses that are already being offered by the
Skills Development Department and others, with a clear assessment of their placement and
employment potential. New and emerging courses that are not currently offered would be prioritized
under the IEIAP in partnership with the training institutes or existing entrepreneurs, while convergence
would be sought for conducting training through ongoing schemes and programmes of the
Government. For specialized training, the training institutes would also engage other training partners.
Modalities for decentralized training venues and flexible training schedules would be considered to
maximize the participation of women and youth.
The committee would also facilitate the post-training support to be provided to the trainees, which
would be in the form of equipment and tools support, financial linkages with banks, apprenticeship
programmes, and others. Modalities of support to be provided to the participants would be worked out
based on the type of skill received, whether the support would be fully subsidized or based on a costsharing model.
Identification and selection of participants
The identification of participants for the initiative would employ a multi-channel approach to
ensure broad outreach and inclusiveness. Targeted campaigns would be launched across various
channels, including social media platforms and WhatsApp groups, community radio, local
newspapers, and institutions such as schools, Self-Help Groups (SHGs), and NRLM networks,
specifically aimed at reaching women (up to 59 years) and youth (18–35 years) from lowincome or marginalized households in rural and peri-urban areas.
Collaborations with Panchayati Raj Institutions (PRIs), SHGs, NRLM, local NGOs, vocational
training institutes, block-level authorities, and industry associations would facilitate the
identification of candidates with entrepreneurial potential or informal experience in high-demand
trades such as drone photography, video editing, tailoring, and plumbing.
The intervention would also extend support to individuals and groups who are already skilled—such
as alumni of SDD’s initiatives—but face challenges in transitioning to self or wage employment due to
lack of tools, mentoring, credit access, or other gaps. Support would similarly be available to groups
running small-scale enterprises seeking to scale up.
This process would assess applicants’ aptitude, motivation, and pre-requisite skill sets through
application forms, basic skill assessments, pre-selection interview and other processes, if needed,
ensuring that selected participants are well-aligned with the technical and entrepreneurial
requirements of the program
The initiative would prioritize inclusivity by ensuring representation from marginalized and
underrepresented groups, particularly Scheduled Castes, Scheduled Tribes, and economically
disadvantaged communities, to create a diverse pool of participants.
Skill Training and other support:
Capacity building is central to enabling women and youth to transition from informal or lowproductivity work to sustainable wage employment or self-employment. This intervention would
provide sector-specific, practical training aligned with employment opportunities, apprenticeships, and
enterprise development, alongside continuous business development and career support services,
through partnerships with training institutions, employers, mentors, and enterprise experts.
71 | P a g e
