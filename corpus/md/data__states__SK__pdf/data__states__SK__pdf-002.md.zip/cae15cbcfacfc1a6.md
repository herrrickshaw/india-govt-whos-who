---
doc_id: "cae15cbcfacfc1a6"
source_url: "https://rmdd.sikkim.gov.in/storage/notification/notificationdoc-dsMgIbX4PEM9lyoG6Pk3C8QqCgC6i9bQAPZ04qGg.pdf"
ministry: "Rural Development Department, Sikkim"
title: "Nodal Officer of Aadhar Enabled Biometric Attendance System (AEBAS)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "39e8795a2ecb265f"
---

<!-- page 1 -->

2025
International Year

of Cooperatives

GOVERNMENT OF SIKKIM

RURAL DEVELOPMENT DEPARTMENT
GANGTOK
Dated: 22/ 04 / 2026

Ref. No. 303...RDDI25-26
OFFICE ORDER

regarding initiation of the
In compliance with Letter no:8633/G/DOP dated:4.04.2026
in the departments, the following
Aadhar Enabled Biometric Attendance System (AEBAS)
been nominated as Nodal Officers.

officers of the Rural Development Department have
SL. No

Designation
Mrs. Tshering Lhaden Special Secreatry
(Administration)
Lachungpa
(T)

Name

Mrs. Sisila Lama Tam Joint Director
ang

Nominated as
Nodal
Officer
Sub Nodal
Officer

the department on the
They shall monitor and ensure onboarding of the employees ofwith
NIC and the Nodal
coordination
in
system and integratrion of AEBAS with PRANALI

Oficer, Home Department.
By order,

Sd/
(ANIL RAJ RAI, IAS)

SECRETARY
RURAL DEVELOPMENT DEPARTMENT.
Memo No:

I240

/ RDD.

Dated: 22/ 04 1 2026.

Copy to:
A AlOfficer above,
2. Nodal Officer, Home Department
3. Special Secretary, Department of Personnel

4. Staff Officer to the Chief Secretary
5. PS to Secretary, RDD
AllSection Head, RDD
7. Assistant Director, Monitoring

6.

File &
Guard.

JOINT SECRETARY (ADM) TO THE GOVT. OF SIKKIM
RORAL DEVELOPMENT DEPARTMENT
