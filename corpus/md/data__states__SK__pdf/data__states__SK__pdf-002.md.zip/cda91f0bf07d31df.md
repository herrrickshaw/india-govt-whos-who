---
doc_id: "cda91f0bf07d31df"
source_url: "https://police.sikkim.gov.in/notification/notificationdoc-RSAYkWGDGhWuDa6Jd9Xw8TvyKVxMRNdtUtDaVq3A.pdf"
ministry: "Police Department, Sikkim"
title: "FORM ‘A’ FORM OF APPLICATION FOR SEEKING INFORMATION - RTI"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "74470f465a716384"
---

<!-- page 1 -->

FORM ‘A’
FORM OF APPLICATION FOR SEEKING INFORMATION
See Rule 5 (1)
I.D.No. ---------------------------------------- (For official use)
To
The State Public Information Officer,

1.

Name of the Applicant

:

2.

Father’s name

:

3.

Permanent address

:

4.

Temporary Address

:

5.

Whether a citizen of India

:

(Please enclose your certified copy of either Sikkim Subject Certificate, Certificate of
Identification, Electoral Roll or Passport as proof).
6.

Whether affiliated to any NGO, Social Organization, Association, Political Organization
etc. If so, the particulars of NGO, Organization, Association Political Organization.

7.

Concerned department:
Particulars of Information:(i)
(ii)
(iii)
(iv)

Details of Information required (please be specific by giving details)
Period for which information asked for
The Geographical area to which the information related (with specified details)
Other details.

8.

I state that the information sought does not fall within the restrictions contained in
Section 6 of the Act and to the best of my knowledge it pertains to your office.

9.

A fee of Rs………. Has been deposited in the office of the Competent Authority vide No.
………………………………. Dated………………………..

Place:

Date:

Signature of the Applicant
Tele No. (Office) ……………..
(Residence) …………………...

Note: (i) Please ensure that the Form A is complete in all respects and there is no ambiguity in
providing the details of information required.
