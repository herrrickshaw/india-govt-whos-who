---
doc_id: "e73a56bec0dfab19"
source_url: "https://police.sikkim.gov.in/circular/circulardoc-28GgmxHKQFLMsMkEgG3jz5XwJsWdgtNxT4Z80yXI.pdf"
ministry: "Police Department, Sikkim"
title: "Advertisement for the post of Director-RFSL"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2e44d8a10c50432e"
---

<!-- page 1 -->

OFFICE OF THE INSPECTOR GENERAL OF POLICE
CRIME BRANCH - CID
Sikkim Police Headquarters
Phone: 03592-202087(O) 204297(F),
igp-cid@sikkimpolice.nic.in

Memo No: 847/ POL/CID/2022

Dated: 01/06/2022

The Police Department, Government of Sikkim invites application from Indian citizens for the
post of Director, Regional Forensic Science Laboratory, Sikkim on contractual basis. The Director will be
responsible for the general administrative matters concerning the laboratory besides guiding the scientists
in various scientific issues pertaining to analysis of crime exhibits. He will also be responsible for
implementation of various projects and schemes for the laboratory including procurement and purchase.
The details of the post including qualification, experience and age etc. are given below.
1. Name of post:
2. Nature of duties:

Director, Regional Forensic Science Laboratory, Saramsa, Sikkim
a) Take up overall administrative responsibility of the Laboratory.
b) Guide the Forensic scientists in their scientific pursuits and to
supervise the analysis of crime exhibits in different divisions to
achieve optimum output.
c) Formulate projects and schemes for the infrastructural
development of the laboratory.
d) Organize training programs for investigating officers on
application of Forensic Science in criminal cases.
e) Procurement of major and minor equipment, laboratory utilities,
chemicals etc.
f) Dealing with court matters including legal service and advice.
g) Financial matters including the budgetary aspects, submission of
plans, proposals for approval and sanction of the Government under
various schemes.

3. Tenure:
4. Monthly remuneration:

Initially for one (1) year which may be extended further.
Rs 1,00,000/- p.m. In case of retired government servant, the
remuneration shall be as per prevailing DoPT norms.
M.Sc./Ph.D in Science stream preferably in Chemistry, Physics,
Botany, Zoology, Anthropology, Forensic Science, Bio-Chemistry,
Bio-Technology, Laboratory Technology or Medical Technology.
Suitable rent free unfurnished accommodation as per existing norms
shall be provided
Suitable transport for local commutation shall be provided
Minimum 20 years of experience of working in Forensic Science
Laboratory in senior capacity.
Maximum up to 65 years.

5. Educational qualification:

6. Accommodation:
7. Transport:
8. Desirable experience:
9. Age:
10. Selection procedure:
11. Submission of application:

The selection for the post will be done by interview.
The application complete in all respects (as per Annexure A)submitted
in original in sealed envelope clearly marked “Director, RFSL,
Sikkim’’ is to be submitted by email/registered post/speed post/by hand
to the Office of IGP/CID, PHQ, Gangtok, no later than 1630 hrs on or
before date 30.06.2022 to email id igp-cid@sikkimpolice.nic.in. For
details regarding eligibility criteria, term & conditions etc., please visit
website https://sikkimpolice.nic.in or https://sikkim.gov.in.

<!-- page 2 -->

Annexure-A
APPLICATION FORM
1. Name of the position applying for:
Self-attested
2. Name of the candidate:
Passport size
3. Father’s Name:
Photograph
4. Date of Birth:
5. Nationality:
6. Gender:
7. Permanent Address:
8. Correspondence Address:
9. Contact Number:
10. Email Id:
11. Educational Qualification (from graduation to professional qualification):
Sl
No.

Name of the Board/Institution/University
degree

Year of passing % of marks
obtained

12. Details of courses/ Trainings attended, if any:
13. Whether retired government employee: Yes/ No
14. If yes, date of retirement, name of department, designation, last place of posting with all details.
15. Work Experience/ Employment Record (starting with present/ last position, list in reverse order
every employment held since graduation):
Sl
Employer/
Designation From
To
Duration
Description of
No. Organization
(date)
(date) (years/
Duties
months)

16. Languages Known (for each language indicate proficiency: good, fair or poor in speaking, reading
and writing):
Language Known
Speaking Proficiency Reading Proficiency Writing Proficiency

17. Details or previous Consultancy, if any:
18. Additional information, in any which you would like to mention in support of your suitability for
the post. Enclose a separate sheet, if need be:
19. Certification:
I, the undersigned certify that to the best of my knowledge and belief this application form
correctly describe myself, my qualifications and my experience. I understand that anywillful
misstatement described herein may lead to my disqualification or dismissal, at any stage.

(Signature of the Application)
Name of the Applicant
Date:
* Application with certification as above not duly signed by the candidate will be rejected at the outset.

<!-- page 3 -->

Note:
1. Candidates must attach:
i.
Self- attested copies of Certificates/ Mark Sheets in support of the educational
qualifications.
ii. Self- attested copies of experience certificate from respective employer clearly indicating
the date of joining, nature of works done and date of relieving. For the current
employment, a copy of employment letter issued by the employer indicating the date of
joining.
2. Application with insufficient information/ without copies of self- attested certificates are liable to
be rejected.
