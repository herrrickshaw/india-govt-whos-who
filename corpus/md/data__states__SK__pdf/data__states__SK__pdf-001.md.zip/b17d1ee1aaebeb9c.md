---
doc_id: "b17d1ee1aaebeb9c"
source_url: "https://police.sikkim.gov.in/notification/notificationdoc-erFBDgnMIKKVdYiiTyVQT8ITG3YixUhGJUsWQSVG.pdf"
ministry: "Police Department, Sikkim"
title: "SIKKIM POLICE MANUAL VOLUME - II"
date: ""
pages: 582
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f1c65949bfec8cd2"
---

<!-- page 1 -->

<!-- page 2 -->

SIKKIM POLICE
MANUAL

VOL - II

<!-- page 3 -->

Volume II
First compiled in 2013 by
SIKKIM POLICE
Gangtok - 737101
Sikkim
Website: www.sikkimpolice.nic.in

Designed & Printed by

REPROMAN
1st Floor, Mani Bhawan,
123 Church Road,
Siliguri - 734001 (WB)
Tel: +91 353 - 2431258
Fax: +91 353 - 2530645
Email: reproman01@gmail.com

<!-- page 4 -->

Volume II

CONTENTS VOL II
Chapter 23
Police Stations, Functions and Management
Regulation

Subject

Page

23.1

Introduction

1

23.2

Police Station Detachments

2

23.3

Meaning and objectives of Beats

4

23.4

Organisation of Rural/Town Beats

5

23.5

Information gathering and other duties of Beat Constables

7

23.6

Details of Information to be gathered on each important item

8

23.7

Beat Area Policing

11

23.8

Checking of Beats

12

23.9

Duties of supervising officers in relation to Beats

13

23.10

Roads and Highway Patrols

13

23.11

Procedure on return of police officers from patrolling or Beat or 13
other service

23.12

Records pertaining to Beats

14

23.13

Point Books

17

23.14

Notice Board and Police Station Name Board

17

23.15

Station Security and Guards

18

23.16

Rotation of duties and Reliefs

18

23.17

Dissemination of Intelligence

18

23.18

Schedule of Training and Instruction

19

23.19

Allocation of Duties

19

23.20

Travelling allowance/food arrangement on deployment

22

23.21

Grant of Leave and Leave Report

22

23.22

Kit Inspection

22

23.23

Development of skills - specialization and self-improvement

23

III

<!-- page 5 -->

Sikkim Police Manual

Regulation

Subject

Page

23.24

Shramdan

26

23.25

Public Relations

26

23.26

Care and custody of Arms and Ammunition

29

23.27

Cash chests of other departments

30

23.28

Lathies and Fire Arms

30

23.29

Fire Fighting Equipment

30

23.30

Necessity of prompt dissemination of information

30

23.31

Criminal Intelligence and Information

31

23.32

Report of probable presence of habitual criminals

31

23.33

Criminal Investigation Gazette (CIG)

31

23.34

Communication of intelligence to areas beyond the State

32

23.35

Deployment of Plain Clothes Men

33

23.36

Roll Call

33

23.37

Duty Roster

33

23.38

Check posts

33

23.39

Armed Outposts

35

23.40

Station House Officer

36

23.41

Other Sub-Inspectors

40

23.42

Asst. Sub-Inspector

40

23.43

Head Constable (General)

41

23.44

Constables (General)

43
Chapter 24

Police Station Records and Registers
24.1

Introduction

47

24.2

Police Station Records & Registers

48

24.3

Use of Integrated Investigation Forms

73

IV

<!-- page 6 -->

Volume II

Regulation

Subject

Page

Chapter 25
Registration of Crime and First Information Report
25.1

Introduction

75

25.2

First Information Report (FIR)

75

25.3

FIR - Whom to be sent

77

25.4

Express Reports

78

25.5

Registration of cases reported at police stations other
than the jurisdiction police station

78

25.6

Registration of cases when station limits of
occurrence are doubtful

81

25.7

FIR – its value

81

25.8

Salient points to be remembered in registering and
dispatching FIR

81

Chapter 26
Powers and duties of Investigating Officers to investigate
Cognizable and Non-cognizable crime
26.1

Power to investigate cognizable and non-cognizable offences

85

26.2

Examination of the scene of offence

86

26.3

Protection of Crime Scene

86

26.4

Recording of the Crime Scene

88

26.5

Sketching the Crime Scene

91

26.6

Crime Scene Observation Notes

99

26.7

Searching the Crime Scene for Physical Evidence

100

26.8

Types of physical evidence normally encountered

104

26.9

Instructions for lifting, packing and forwarding
physical evidence

105

26.10

Chain of custody of physical evidence

108

V

<!-- page 7 -->

Sikkim Police Manual

Regulation

Subject

Page

Chapter 27
Collection of Evidence
27.1

Introduction

111

27.2

Nature of Evidence

111

27.3

Types of Evidence

111

27.4

Oral evidence

111

27.5

Admission of police officers on duty to visit jails

112

27.6

Recording of statements of witnesses

113

27.7

Dying declaration

113

27.8

Recording of statements of witnesses and
confessions of accused by a Magistrate

115

27.9

Confessional statements made to the police

115

27.10

Recording the Confessional Statements

115

27.11

Tendering of pardon

116

27.12

Documentary Evidence

117

27.13

Documents required from Bankers

117

27.14

Procedure regarding articles/documents in the custody of
Postal or Telecom Departments both Private and Government

118

27.15

Inspection of Records of Criminal Courts by the Police

119

27.16

Inspection and obtaining of documents in the custody of
audit (including Posts and BSNL) offices

119

27.17

Expert evidence

119

27.18

Circumstantial evidence

120

27.19

Identification

121

27.20

Salient Points of Identification

121

27.21

Identification by Photographs

123

27.22

Identification through Finger and Foot impressions

123

27.23

Previous Conviction or Acquittal

123

27.24

Identification of Property

124

VI

<!-- page 8 -->

Volume II

Regulation

Subject

Page

27.25

Case Diary

124

27.26

Nature & Importance of Case Diary

124

27.27

Contents of Case Diary

125

27.28

The First Case Diary

125

27.29

Details & Description

125

27.30

Copies of Case Diary

126

27.31

The Concluding Case Diary

126

27.32

Role & Responsibility of the Subsequent IOs

126

27.33

Action when Case is transferred to CID

126

27.34

Case Diary in Inquest Case

127

27.35

Progress of Trial to be recorded

127

27.36

Use of Case Diary for Seeking Remands etc

127

27.37

Investigation Abroad and Letters Rogatory

127

27.38

Comprehensive guidelines for Investigation Abroad,
issue of Letters Rogatory, extradition request issued
by Government of India

128

27.39

Format and the contents of the Letters Rogatory

135

27.40

Extradition

136

27.41

Position in India

137
Chapter 28

Arrest, Custody, Bail, Remand & Search
28.1

Power of arrest

139

28.2

Arrest Precautions

139

28.3

Conditions necessitating Arrest

140

28.4

Arrest of Children and Women

141

28.5

Rights of Arrested persons (Cr.P.C. Sec. 50, 50A)

141

28.6

Direction to subordinates to arrest

142

VII

<!-- page 9 -->

Sikkim Police Manual

Regulation

Subject

28.7

Requirements laid down by CrPC and Police Act (section 63) 142
should be observed in all cases of arrest or detention

28.8

Guidelines for a Police Officer in making an arrest

143

28.9

Search of the arrested person by the Police

144

28.10

Treatment of the arrested persons

145

28.11

Police Custody

145

28.12

Arrest Reports

146

28.13

Procedure when arrests relate to Government employees,
armed forces personnel etc.

146

28.14

Look out notices/circulars

149

28.15

Red Corner notice

150

28.16

Extradition

150

28.17

Police lock-ups and treatment of persons in custody

153

28.18

Use of handcuffs

154

28.19

Sick prisoners

155

28.20

Scale of accommodation for prisoners

156

28.21

Confinement of other department prisoners in lockup

156

28.22

Escape from Custody

157

28.23

Bail

157

28.24

Remand of arrested accused

159

28.25

Police custody

159

28.26

Searches

160

28.27

Powers of Search

160

28.28

Procedure for Search

161

28.29

Precautions for Conducting Searches

161

28.30

Custody of Property

163

28.31

Disposal of Property if Court declines to take possession

163

28.32

Live-Stock

163

VIII

Page

<!-- page 10 -->

Volume II

Regulation

Subject

Page

28.33

Disposal of the Property coming into the hands of the Police

164

28.34

Recovery of stolen property otherwise than on house
search record of material facts

164

28.35

Reciprocal arrangements between countries for assistance

164

Chapter 29
Scientific Aids to Investigation
29.1

Introduction

165

29.2

Institutions providing Scientific Investigative Aids
to the Investigating Officers

166

29.3

Test houses and test laboratories and other technical
institutes available for assistance in criminal cases

167

29.4

Physical Evidence and its role in Crime Investigation

183

29.5

Crime Scene Processing and Physical Evidence Collection

191

29.6

Recording the Crime Scene

191

29.7

Searching the Crime Scene for Physical Evidence
& Role of the Investigating Officer

191

29.8

Principles and Laws governing Forensic Science

192

29.9

Duties and responsibilities of expert
(I.O. when expert is not visiting the scene of crime)

194

29.10

Ballistics

195

29.11

Biology

197

29.12

Bio-medical

200

29.13

Chemistry

201

29.14

Computer Forensics

203

29.15

DNA

204

29.16

Documents

208

29.17

Forensic Engineering

211

29.18

Narcotics

213

IX

<!-- page 11 -->

Sikkim Police Manual

Regulation

Subject

Page

29.19

Physics

214

29.20

Polygraph

218

29.21

Serology

219

29.22

Toxicology

223

29.23

Quick Check List for the Investigating Officers to ascertain
what type of samples to be collected in different types of
crimes and which section of FSL handles the analysis

227

29.24

Miscellaneous Police Equipment for Technical Support

228

29.25

Utility Contexts of Police Equipment

229

29.26

The Maintenance Contexts

232

Chapter 30
Final Disposal and Completion of Investigation
30.1

General

233

30.2

Disposal of cases

234

30.3

Report u/s 173(2) Cr.PC

236

30.4

Charge-sheets

236

30.5

Absconders and Proclaimed Offenders

237

30.6

Juvenile offenders

238

30.7

Conditions for initiation of prosecution

238

30.8

Final Reports

240

30.9

Reopening of the Case

241

30.10

Prosecution of complainant in false cases

241

30.11

Withdrawal of cases - Procedure

241

X

<!-- page 12 -->

Volume II

Regulation

Subject

Page

Chapter 31
Prosecution of Cases
31.1

Introduction

243

31.2

Functions and duties of the Prosecutors

244

31.3

Consultation with the Prosecutors

246

31.4

Office of the Court Inspectors

247

31.5

Commencement of Prosecution

248

31.6

Examination of witnesses in Court

248

31.7

Duties of Investigating Officers & Senior Officers

252

31.8

Giving Evidence in Court by Police Officers

253

31.9

Enhancement of Punishment

254

31.10

Prosecution of Witnesses for Perjury

255

31.11

Abscondence of Accused

255

31.12

Examination of Medical Officers

256

31.13

Summoning of Experts

256

31.14

Arguments and Summing up of the Cases

257

31.15

Privilege in Respect of Official Records

257

31.16

Action on breach of a security bond

262

31.17

Delay in the Disposal of cases in Courts

262

31.18

Pendency of cases with Magistrates

263

31.19

Procedure for filing Appeals against acquittals
and Revision petitions in the High Court

266

31.20

Watching progress in Appeals filed by accused

268

31.21

Action to be taken in case of Criticism by Courts on judgments 269

31.22

Criminal Appeals - High Court – Steps to be taken for better
representation in Criminal Appeals filed before High Court

269

XI

<!-- page 13 -->

Sikkim Police Manual

Regulation

Subject

Page

Chapter 32
Preventive Role of Police
32.1

Introduction

271

32.2

Unlawful Assemblies

271

32.3

Urgent cases of nuisance or apprehended danger
(Section 144 CrPC, 144 A Cr.PC)

272

32.4

Security for Good Behavior and keeping the Peace

273

32.5

Security for preventive breach of peace – 107 CrPC

273

32.6

Section 108 CrPC

274

32.7

Section 109 Cr.PC

275

32.8

Section 110 CrPC

275

32.9

Preventive Role under other Acts

277

32.10

Removal of Public Nuisances

277

32.11

Preventive Detention – National Security Act (NSA)

279

Chapter 33
Maintenance of Law & Order
33.1

Introduction

283

33.2

Law & Order : Concept and Dimensions

283

33.3

Perspectives on Law and Order

283

33.4

Riots

284

33.5

Collection of Information

284

33.6

Licensing power for assembly or procession

288

33.7

Instructions for the guidance of officers in regard to processions

289

33.8

Police action during industrial unrest

290

33.9

Law & Order situations due to factions

292

33.10

Investigation of Factious rioting and murder

293

33.11

Dispersal of Mobs

294

33.12

Enrollment and employment of Special Police Officers

296

XII

<!-- page 14 -->

Volume II

Regulation

Subject

Page

33.13

Additional Police

298

33.14

Campus Violence

298

33.15

Ragging

299
Chapter 34
Handling Communal Situations

34.1

Introduction

301

34.2

Causes of Communalism

301

34.3

Role of the Police

301

34.4

Preventive Action

302

34.5

Administrative Measures

303

34.6

Post Preventive Measures

304

34.7

Police Action Parameters

304

34.8

Broad Based and Comprehensive Administrative Measures

305

34.9

Strategy for efficient and effective handling of Riotous situations 306

34.10

Legal Provisions

307

34.11

Forfeiture of Blasphemous Publications u/s 95 Cr.P.C.

308

34.12

Special Provisions u/s 153-B

309

34.13

Offences Relating to Religion under Chapter 15 of IPC

309

34.14

Punitive Action

310
Chapter 35

Terrorism, Bombs & Explosives
35.1

Introduction

311

35.2

Bomb Threats

311

35.3

Bomb Threat Searches

312

35.4

Communication of Threat

312

35.5

Procedures for receiving a bomb threat by telephone

312
XIII

<!-- page 15 -->

Sikkim Police Manual

Regulation

Subject

Page

35.6

Types of Searches

313

35.7

Conduct of Search

313

35.8

Bomb Squad

337

35.9

DO’s and DONT’s for IEDs and Mines

341

35.10

Safety and Special handling precautions for Incendiaries

343

Chapter 36
Unnatural Deaths
36.1

Introduction

36.2

Action to be taken on receipt of Information of Unnatural Death 345

36.3

Enquiries under section 174 CrPC

345

36.4

Inquest Report

346

36.5

Procedure on occurrence of large-scale deaths

347

36.6

Inquest by Executive Magistrate

347

36.7

Disinterment of Bodies (Exhumation)

347

36.8

Inquest reports – Post mortem – Salient points

348

36.9

Preservation of corpse

348

36.10

Guidelines relating to Postmortem examination
and wound certificate

349

36.11

Unidentified bodies

349

36.12

Death in Encounters or in Police Custody

350

36.13

Death in Jails

351

36.14

Compensation cases – Supply of documents by police

351

36.15

Points for enquiry in death cases

351

36.16

Important points to be borne in mind about inquest

352

XIV

345

<!-- page 16 -->

Volume II

Regulation

Subject

Page

Chapter 37
Traffic Duties
37.1

The Basic Traffic Premise

355

37.2

Co-ordination Aspects

355

37.3

Objectives

355

37.4

Duties of Traffic Police

356

37.5

Organization and Supervision of Traffic Police offices

357

37.6

Briefings and timings of traffic police men on duty

357

37.7

Role of Traffic police in Law & Order Situations
& Regulation of processions

358

37.8

Work Allocation and Jurisdiction

358

37.9

Records to be maintained and functioning of Traffic office

358

37.10

Traffic Signs and Road Markings

360

37.11

Traffic Lights

383

37.12

Display of the State Emblem of India on vehicles

385

37.13

Free passage for emergency vehicles

387

37.14

Law on use of horns/siren

388

37.15

Law on parking

389

37.16

Speed limit

391

37.17

Law on use of sun film

393

37.18

Law on alcohol/drug impaired driving

393

37.19

Motor Vehicle Offences and Compounding amounts

396

37.20

Traffic warden

398

37.21

Road Safety Cell

400

XV

<!-- page 17 -->

Sikkim Police Manual

Regulation

Subject

Page

Chapter 38
Protection of Weaker Sections
38.1

Protection of weaker sections - Responsibilities of Police

401

38.2

Differences between the SC/ ST (POA) Act and the PCR Act

409

38.3

Protection of Civil Rights (PCR) Cell and its duties

411

38.4

Duties of the District Police

411

38.5

Investigation of Cases

412

38.6

Functions of National Commission for SC/ST

413

38.7

Powers of the Commission to act as a Civil Court

414

38.8

Crimes against Children - Trafficking in Children Rights of Children - Police Duties - Investigation of Crimes

414

38.9

The Juvenile Justice (Care and Protection of Children) Act, 2000

415

38.10

Other legislations to protect the interest of children

418

38.11

Crimes against Women and Duties of Police

419

38.12

Attacks against women and their modesty

421

38.13

The Dowry Prohibition Act, 1961

422

38.14

Offences relating to the Marriage

423

38.15

National and State Commissions for Women and
Protection of Child Rights

423

38.16

Commission for Protection of Child Rights

423

38.17

Arrest of Women

424

38.18

Bonded labour

424
Chapter 39

Economic offences and White collar crime
39.1

Introduction

425

39.2

Classification

426

39.3

Major Areas of Economic Offences

427

39.4

Agencies to investigate Economic offences

432

39.5

Investigation of Economic Crimes

433

XVI

<!-- page 18 -->

Volume II

Regulation

Subject

Page

Chapter 40
Organized Crimes and Police
40.1

General

437

40.2

Legal provisions

438

40.3

Important points to be borne in mind by IOs
investigating into offences by organized gangs

438

40.4

Property Offences by a Gang

440

40.5

Conspiracy

442

40.6

Investigation of Terrorist Crime

443

40.7

National Human Rights Commission’s guidelines
for investigating deaths in Police encounters

446

Chapter 41
Cyber crime and Police
41.1

Introduction

447

41.2

Computer Crime

451

41.3

Investigation of Computer Crime

456

41.4

Computer Crime and legal penal provisions

467

41.5

Sikkim Information Technology Rules, 2009

472

41.6

Powers of the Police under
Sikkim Information Technology Rules, 2009

473

Chapter 42
Crime against women
42.1

Rape

475

42.2

Registration & Investigation of Rape cases

476

42.3

Offences of sexual intercourse not amounting to rape

479

42.4

Unnatural sexual offences

479

42.5

Dowry Deaths

481

42.6

Cruelty and Harassment of married women

483

42.7

Prevention of Immoral Traffic in Women

484
XVII

<!-- page 19 -->

Sikkim Police Manual

Regulation

Subject

Page

Chapter 43
Drug Trafficking
43.1

Introduction

489

43.2

Legal Provisions

489

43.3

Guidelines issued by the Narcotics Control Bureau, New Delhi

491

43.4

Points to be noted while recording Seizure Memo

492

43.5

Procedure of drawal, storage, testing and disposal of samples
from seized narcotic drugs and psychotropic substances

493

Chapter 44
Investigation of other Specific Offences
44.1

Robbery and Dacoity

499

44.2

Classification and Modus Operandi

499

44.3

Action on receipt of Information

500

44.4

Identification of Persons and Property

501

44.5

Action on arrest

503

44.6

Preventive Measures

503

44.7

Pursuit of other accused and properties

504

44.8

Charge sheet and Court Trial

504

44.9

House Breaking or Burglary

505

44.10

Points to be noted while investigating burglary cases

506

44.11

Theft

509

44.12

Riots

514

44.13

Poisons and Poisoning

521

XVIII

<!-- page 20 -->

Volume II

Regulation

Subject

Page

Chapter 45
Foreigners
45.1

Definition

527

45.2

Acts and Rules relevant to foreigners - passports and visas

527

45.3

Exemptees under the Passport (Entry in India) Act, 1920,
529
Registration of Foreigners Act, 1939, and Foreigners Act, 1946

45.4

Formalities to be observed by foreigners

530

45.5

Registration under the Registration of Foreigners Rules, 1992

532

45.6

Hotel arrival reports - Form ‘C’

534

45.7

Registration of Pakistan Nationals

534

45.8

Bangladesh Nationals

535

45.9

Residential permits

535

45.10

Extension of stay

536

45.11

“No objection to return to India” endorsements

537

45.12

Extension of period of validity of tourist certificates

538

45.13

Arrest of Foreigners and Consular Access

538

45.14

Prosecutions

539

45.15

Correspondence relating to Passports and Visas

540

45.16

District Police to report the movements of foreigners

540

45.17

Enquiries relating to foreigners

540

45.18

Registers and Records

540

45.19

Central Foreigners Bureau and its functions

541

45.20

List of documents to be furnished by Registration Officers to
the Central Foreigners Bureau and State Registration Officer

541

45.21

Report of death of foreigners

541

45.22

Visit of Foreigners to Sikkim – Restricted/Protected Area Permit 542

XIX

<!-- page 21 -->

Sikkim Police Manual

XX

<!-- page 22 -->

Volume II

Chapter 23

Police Stations: Function and Management
23.1

Introduction

(1) Police stations are notified by the government under section 2 (s) of CrPC. Such a
notification confers certain powers and responsibilities on the police in respect of the
notified area. A police station is under the charge of an Officer not below the rank of
a Sub-Inspector of Police who is termed as the Station House Officer (SHO).
(2) Each Police station shall have a Woman and Child Protection Desk, staffed as
far as possible by women police personnel, to record complaint of crimes against
women and children and to deal with the task relating to administration of special
legislations relating to women and children.
(3) The State government shall, in Police Stations of such crime prone area or urban
areas as it may consider necessary, order separation of investigation of crime from
law and order and other police functions by creating a Special Crime Investigation
Unit (CIU), headed by an officer not below the rank of Sub-Inspector of Police,
with appropriate strength of officers and staff, for the investigation of economic
and heinous crimes.
(4) In cases where such separation of crime investigation from law & order (and other
functions) has been ordered, the officers posted to the Crime Investigation Units
will investigate crimes such as murder, kidnapping, rape, dacoity, robbery, dowry
–related offences, serious cases of cheating, misappropriation and other economic
offences as notified by the Director General of Police, besides any other cases
specially entrusted to the unit by the District Superintendent of Police. All other
crimes will be investigated by other Police Officers posted in such Police Stations.
(5) On the basis of geographical and demographic factors, crime conditions, law and
order situation, regulating protocol and other miscellaneous and specific jobs to
be performed and traffic management etc. police stations in the State have been
classified as follows:(i) Gangtok – Sadar (1) – Urban (There is a separate police station under Crime
Branch, CID having jurisdiction throughout the State of Sikkim for investigation
of crime as prescribed).
(ii) Rangpo, Melli, Singtam, Rhenock, Ranipool, Namchi, Jorethang (7) - Semi
Urban category ‘A’.

1

<!-- page 23 -->

Sikkim Police Manual

(iii) Gyalshing, Soreng, Nayabazar, Pakyong, Mangan (5) – Semi Urban category ‘B’
(iv) Rongli, Phodong, Ravangla, Temi, Hingdam, Kaluk, Sombari, Kupuk,
Sherathang, Lachung, Lachen, Chungthang, Uttarey (13) – Rural.
(6) The administrative control of Check Post Police Stations and Picket posts are
vested with the SP/Check posts whereas crime and law and order functions are
under the control of concerned District SPs. In other Police stations, full command
and control is vested in the concerned District SP. The Check post Police stations
and Picket posts are located on 3 international borders (i). Indo-Tibet Border in
North and East (ii). Indo-Nepal Border in the West and (iii). Indo-Bhutan Border
in the East.
(7) Police outpost under police stations and Picket Posts under Check post police
stations are normally provided with strength of about 5 to 7 Police Officers,
established at certain locations to ensure police presence, easy accessibility to
public, and to deal with the trouble in the area quickly. In addition armed outposts
or check posts on Inter-State border of varying strength are set up to meet certain
situations. The Inter-State border check posts are attached to local police stations.
(8) All these specified police stations carry out their specific functions for administrative
convenience but all police stations are vested with all the functions of police.
Therefore all police stations irrespective of jurisdiction shall not refuse to entertain
any cognizable complaint. They shall register such complaints forthwith and transfer
the same to the concerned police station. Refusal to register a cognizable case shall
be treated as a criminal misconduct on the part of that police station SHO.
23.2

Police Station Detachments
The authorised strength in these Police Stations is generally divided into three
detachments: (1) General detachment; (2) Traffic detachment; (3) Beat and patrol
detachment. A separate traffic detachment may not be necessary in small or rural
police stations. The general duty police staff will perform the traffic duties in case
a need arises.

(1)
(i)

2

General Detachment
The strength other than the traffic detachment and beat and patrol detachment
of the town police station shall be known as General Detachment. 1 ASI or HC
and 2 to 3 police constables should be earmarked as an Investigating Team for
directly assisting the Sub-Inspector/SHO for investigation of cases. This number
should be increased suitably depending on the number of cases a police station
has to handle, more particularly in Town Police Stations. Where the SHO is an
Inspector, one or more SIs should be earmarked for investigation of the cases

<!-- page 24 -->

Volume II

assisted by the team as indicated above. The ASI or SI in this team should also
attend the Court, in relation to the cases investigated by the Police Station. One
Station Writer and a Station Guard or watch as per requirement should also be
provided from the General Detachment. The remaining manpower should be
utilised either to reinforce the strength of any of the detachments, or for any
emergency and such other duties which the SHO considers necessary.
(ii)		 Duties of General Detachment
A. Prompt arrival at the scene of occurrence, preservation of the scene, arrest of
accused and other arrangements to maintain peace and order. The beat area
officers should accompany them if they are present in the police station or
immediately proceed to the spot on intimation from wherever they are.
B. Court work in relation to the cases investigated by police stations.
C. Act as Station reserve to meet and respond to any call for police help including
incident control and follow up action for offences occurring in the Police
Station area,
D. To provide for the Station writer and his assistant. The station writer or his
assistant should always be available in the police station and attend to all
telephone calls and messages. He will also be in charge of the case property
room (malkhana), the registers connected with it and safe maintenance of all
the case property.
E. Provide for the security of the lock up rooms and the premises of the P.S.
F. Duties outside station limits when deputed.
(iii) SHO shall hold the roll call for all personnel of the general detachment as well as
other staff who are not engaged on duty at 1700 hours every day when the duties
for the next 24 hours should be made known to them.
(iv) In the absence of the SHO, the senior-most SI, ASI or HC present will be the
SHO and perform all duties of SHO during that time in the police stations.
(v) An investigation team consisting of SI or ASI and other personnel shall be
formed by the SHO for the purpose of investigation from this detachment for
investigation of all cases by the Police.
(2)

Traffic Detachment
This detachment in a town police station shall consist of 1 HC or 3 or more
Constables based on the number of traffic points required to be manned at peak
traffic time during the day. There is no need to form a traffic detachment in towns
which do not require fixed manned traffic points or where there is an exclusive
3

<!-- page 25 -->

Sikkim Police Manual

traffic police station. If it is a mere regulation on certain days or occasions, the
number, necessary exclusively for traffic duty, or if any assistance to the traffic
police is required, the personnel may be detailed from the General Detachment.
The beat area Constables may also be asked to look after such matters during their
day patrolling. The traffic duty of the police personnel who are from general/beat
detachments will consist of regulation and assistance to the traffic police on duty,
as well as foot patrolling to keep the streets clear from obstructions and the other
prescribed traffic duties.
(3)

Beat and Patrol Detachment
The principal functions of the police are the prevention, detection of crime and
bring offenders to justice. Preventive work must receive higher priority than
other police work. Intimate knowledge of people and the conditions prevailing
in the jurisdiction, the willing involvement and cooperation of all sections of
the local community, knowledge about the nature of crimes and the movements
and activities of criminals of various categories are conditions precedent to the
successful prevention of crime. To gain such knowledge, and build cooperation of
the people and interpose between criminal and his opportunity, an efficient beat
system is vital. Patrolling and beat system is the primary function of the Police.

23.3
(1)

(2)

Meaning and objectives of Beats
Beat means a segment or part of the jurisdiction of a Police Station consisting
of a village or group of villages or a locality in a town. Each beat will be given
name in the name of Village/area/panchayat in a police station. Beat service means
performance of any of the functions and responsibilities of the police officer
assigned to the beat, in that beat area.
The objectives of beat are A. To provide police services within easy reach of the community;
B. Policing of a manageable area and households by specified Constables and
Head Constables;
C. Promote awareness and thorough understanding of the policing needs of the
community and of the law by the community;
D. Promote and build voluntary and participative support through Community
Liaison Group in preventive and detective work of police and protection of
lives and properties and honour;
E. Help understanding and reconciliation in caste, communal and group hostilities;
F. Gather, record and communicate information on crime, criminals, strangers,
factions, organised criminal gangs, terrorists, anti-national and anti-social
elements;

4

<!-- page 26 -->

Volume II

G. Provide day and night patrols to keep order, prevent crimes and intercede
when necessary;
H. Maintain effective surveillance on history sheeted persons and ex-convicts;
I. Arrest of persons in terms of section 41 CrPC;
J. Preservation of crime scenes and assistance in investigation.
23.4

Organisation of Rural / Town Beats

(1) The beats should be organised taking into consideration the crime, the vigilance
required, factions prevailing, clandestine activities being organised in the area
etc. The frequency of visits and period of stay will depend upon the sensitive
or hypersensitive nature of the area. The classification keeps changing from
time to time.
(2) The following are the types of villages/bazaar/locations to be classified as sensitive
or hypersensitive within the general beats.
A. Villages/bazaar/locations in which bad characters reside i.e., offenders,
criminals, or members of organised crime gangs or syndicates or those who
foment or incite caste, communal violence, for which history sheets are
maintained and require surveillance.
B. Villages/bazaar/locations in which there have been in the immediate past
frequent incidents or outbreaks of crime, either against persons or property.
C. Villages/bazaar/locations in which there are acute factions due to group
rivalries, political, communal or caste or other tensions, and
D. Villages/bazaar/locations in which organised criminal or drug related activity
or manufacture, trafficking in firearms and explosives exists or shelterers of
terrorists and other organised criminals exist. A shelter need not be a place. It
would include a person as well.
(3) A village/bazaar/location which is neither sensitive nor hypersensitive, but must
be traversed en-route is called route village/bazaar/locations. There may be one
or more such villages in each beat. Their names have to be entered in the column
entitled, “Route villages /bazaar/locations” in the beat book of that beat.
(4) District Superintendents of Police shall issue orders dividing the jurisdiction of every
police station, including that coming under the outposts/picket posts, into a certain
number of beats taking into consideration the geographical requirements, crime, law
& order and other problems. Each such beats shall be identified by a name.
(5) The beats in an outpost or rural police station jurisdiction should not be more
than 3 or 6 respectively. Such other factors as most convenient, accessibility, road,
communication facilities and the number of sensitive or hypersensitive localities,
5

<!-- page 27 -->

Sikkim Police Manual

villages should also be considered. Sensitive and hypersensitive villages should
be distributed in all beats and not grouped into one or two. A beat book will be
maintained for each general beat. The part II crime chart should show the areas
covered by name of each beat.
(6) Entire police station area in a town should be divided into such beats keeping
convenience, geographic contiguity, accessibility and ability to cover all the roads/
streets in the beat in one day or night on foot. The total number of beats in a town
should normally be around 3 or 4.
(7) The selection and grouping of villages/bazaar/locations as outlined above should
be reviewed by SDPO every year during annual inspections. They may order such
changes as necessary, according to the circumstances. When the necessity ceases
a sensitive/hyper sensitive village/bazaar/locations may be converted as route
village/bazaar/locations.
(8) The Sub-divisional Police Officer, during the annual inspection, must particularly
ensure whether the beats have been organised conventionally and based on all
relevant and realistic factors. He should personally tour in one or two beats along
with SHO and the police officers assigned to the beat in the same manner as a beat
Constable does, to make sure that it is organised properly and can be served in the
manner prescribed.
(9) Two police officers i.e., either two police Constables or one Constable and one
Head Constable should be allotted to each beat of rural area. For urban areas, 3-4
constables/Head constables shall be allotted to each beat. They are responsible
to visit and patrol sensitive village/bazaar/locations. The hyper-sensitive villages/
bazaar/locations should be more frequently visited. It is not necessary that all
villages in a beat should be covered every time the constables go to that beat. They
should cover the villages in the beats at least once a week not only in the day time
but also at nights. In town areas the beat officer shall cover all the roads/streets
in his beat every day. The Head Constables/Constables in-charge of beat shall
patrol their respective beats for a minimum of 15 nights in a month either together
or in two intervals spread over the month. The SHO should ensure that they are
ordinarily not allotted any other duty in the PS when the Constables/HCs in charge
of a beat proceed on beat duty once a week. The SDPO shall make a surprise visit
to at least one beat in a PS in a month in addition to regular inspections.
(10) If with the prevailing staff position of a police station in urban area, it is not
possible to implement the beat system recommended for urban areas, the beat
system recommended for rural areas may be implemented in these areas also.
(11) Depending on the strength and the rank composition in each police station, an SI or
an ASI shall be appointed the supervisor of each beat or a group of contiguous beats.
6

<!-- page 28 -->

Volume II

23.5

Information gathering and other duties of Beat Constables

(1) The Constables assigned to a beat should perform the following duties:
A. Identify through discreet enquiry, observation and verification about habitual
offenders, especially dangerous criminals, the nature of crime they are addicted
to, or gangs, including members of organised crime syndicates requiring
surveillance irrespective of their area of operation;
B. Collect information from or about travelers at camping grounds, rest houses
and other places of public resort;
C. Ascertain or verify any definite piece of information concerning crime
or criminals;
D. Service of summons and execution of warrants;
E. Gather information about movement of bad characters, suspicious strangers
and wandering gangs in the village;
F. Enquire about the movements and good and bad activities of all ex-convicts
and history sheeted persons specially with reference to their lavish expenditure
or of other persons connected with them beyond their normal means;
G. Find out the existence of any receivers of stolen property and contacts by bad
characters or strangers with them;
H. Identify liquor shops, illicit sources of liquor, vice dens, gambling houses, drug
peddlers, and unlicensed weapons;
I. Collect intelligence about agitational activities of political parties or other
organisations and clandestine activity of any organisation or their associates,
or members or supporters;
J. To notice and ascertain any fresh settlers in the village or visitors and the places
from where they have arrived and their friends and relatives in the village with
whom they are staying or providing support to them;
K. To liaise with community elders, members of the Community Liaison Group,
if any, the Village Defense Party, the Village Guard, and the residents of each
village under his charge, and to review, during every visit, the crime prevention
measures in the village;
L. To collect information relating to crimes and criminals and activities of
subversive, militant and anti-social nature, if any in the village and communicate
the same to the Station House Officer;
M. To maintain watch over history –sheeted criminals, if any, and others with
criminal record or bad characters;
7

<!-- page 29 -->

Sikkim Police Manual

N. To acquaint himself with local disputes having potential for violence or with
caste or communal overtones, and inform the Station House Officer of the
same with all available details;
O. Collection of information and evidence in the cases reported from that
particular beat;
P. Tracing absconding criminals and suspects;
Q. Verification related to issue of passports and gun licenses, tenants and domestic/
professional helps, and character and antecedents of candidates selected for
government service;
R. To carry out any other policing task in respect of the village assigned by the
District Superintendent of Police or by Station House Officer through general
or special order;
S. To record any public grievances and complaints in relation to policing; and
T. To maintain a record of aforesaid duties and responsibilities carried out by him
during his visit and submit the same regularly to the Station House Officer.
23.6

Details of Information to be gathered on each important item

(1) Crime - Crimes include all offences and all undetected crimes and hushed up/
unreported crime;
(2) Gangs - The names of the criminals of organised crime or terrorist gangs that
have passed through the village/town area, whether they stayed there, if so, the
number and duration of their stay, conduct of any activity by those gangs during
such sojourn, their source of livelihood during their stay, whether they belong to
particular caste and organized gang, the number of males, females and children,
the name of leader;
(3) Suspicious strangers - Their arrival in the village/town area and all their activities
and doings and any information of interest from police point of view; the object of
their visit; the place, relationship and antecedents of the person with whom they
stayed; any suspicious activity during their stay and basis for the suspicion; any
crime that occurred during their stay;
(4) Receivers of stolen property - Existence of any receivers of stolen property in
the village/town area; those who visit them and any suspicion about them; their
frequent absence and the places and purpose of their visits outside the village;
method of disposal of stolen property, by sale outside or by melting it (jewellery
etc.) immediately and persons who help them. In respect of other property like
antiquities or art pieces his contacts outside;
8

<!-- page 30 -->

Volume II

(5) Suspects - his presence in the village/town area or otherwise; the work in which
he is engaged, the place of his work and his earnings there from; the earnings of
his dependents, and whether the total income is sufficient for him to maintain
his family above want, or whether he lives too extravagantly for his income;
whether female members have, or wear valuable jewels or ornaments; the period
of his absence if any from village/town area and details of places visited, persons
contacted, purpose and date of return; whether, after the last visit of the police
to the village/town area, he was absent at any time from the village/town area,
either by day or night and if so, the duration of stay and his last absence and how
he accounted for his absence; and the names of his associates, frequent visitors
and their antecedents; Discreet enquiries from reliable persons about his way of
life and earning.
(6) Habitual Offenders - The compliance or otherwise of the restrictions legally
imposed upon them; and discreet enquiries relating to his style and way of life;
(7) Liquor Shops - whether any illicit sale or manufacture of liquor is prevalent;
the persons frequenting the shop most; the character and antecedents of the illicit
liquor seller; and whether the person running these shops is a receiver of stolen
property or harbourer of thieves or other offenders. Apart from this, information
on organised gangs of illicit liquor manufacture, or trade, and their active members
should be gathered;
(8) Unlicensed weapons - The persons suspected to be possessing unlicensed arms;
The sale and delivery of weapons by license-holder to an unlicensed person;
and whether the license-holder purchased the weapon from an unlicensed
seller; whether there is manufacture, trading in unlicensed weapons, explosives
and explosive substances; demand of license from a suspected person carrying
arms or ammunition, and seizure of the same under a seizure memo for any
contravention detected;
(9) Public gathering and Grama Sabhas - Meetings held and subjects discussed;
(10) Collection of money - Whether any collections are made from public, the person
collecting it, the purpose, the name of the treasurer and the use of such collections
and whether it is voluntary or by force or intimidation. All information relating to
collection of money whether clandestine or open, whether for religious purposes
or development works should be gathered. The analysis of the information and
action to be taken will be decided by SHO;

9

<!-- page 31 -->

Sikkim Police Manual

(11) Matters affecting the public peace - The important points on which information
should be gathered and nature of action to be taken in respect of communal, caste
and group tensions, factors likely to affect public order are detailed below;
(12) Communal - The nature of relationship between minority and majority
communities, whether amity prevails or points of friction and tensions exist,
the details of disputes of long standing nature, whether dormant or active efforts of village/town area community to settle amicably, militant groups who
under religious garb foment trouble and their active supporters, their activities
and grievances specific to the village, important impartial and sober elements
or Community Liaison Group members of both communities who can resolve
problems and help maintain peace, preventive measures at local or higher level
that would be necessary to prevent breach of peace. The constable in-charge of
beat should be in constant touch with SHO to enable him to deal with situations
according to the need;
(13) Caste Problems A. Number of offences reported or unreported under PCR Act, 1955 or SC & ST
Prevention of Atrocities Act, 1989; possibility of any atrocity taking place
against Scheduled Caste or Scheduled Tribe members;
B. Necessity or otherwise of DM or SP to visit and intervene personally;
C. Need or otherwise for granting or cancellation of weapons license for any person
to remove the imbalance or to ensure self defense of any person or group;
D. The activities of Village/Town/Defense Parties, Community Liaison Group
and other non-government organisations if any in the village/Town, their
composition and work to maintain cordial relations and improve awareness of
the problem;
E. The names and antecedents of militant persons, who foment, incite and take
advantage of tensions in all communities, and their antecedents;
F. To keep the SHO informed from time to time about caste tension if any to enable
the SHO or other supervisory officers to take necessary steps to maintain peace
in such a situation;
(14) Political rivalries - In almost all villages, people have political affiliations with
one or the other party. In most villages the public in general do not actively
participate in political activities on a regular basis. Majority of them show interest
only during election time, while a very small group may be active throughout.
The police is concerned only with violent clashes or possibility of offences due to
intense political rivalries - generally prior to elections or as an aftermath, and in
some instances even at other times. The political factions quite often get aligned
10

<!-- page 32 -->

Volume II

with communal or caste or village/town factions. Such situations are often a serious
threat to law and order. The beat area constables have a duty to clearly understand
these factors and keep detailed information of possible clashes in each village. A
report should be made on the existence of such rivalry and the list of anti-social
elements who take advantage of such situations;
(15) Factions - The existence of a faction, political, social, or communal, the latest
moves and plans of the factionists, their supporters likely developments or
offences, the opinion of the residents of the area, the names of active members,
their resources and weapons and their involvement in cases in the area or outside,
are the important factors which influence factious crime and public peace;
(16) Agrarian unrest - The villages in which there are serious land disputes, occupation
of Government or private property, possession or dispossession, sale or transfer of
land in scheduled areas, owner-tenant disputes, agricultural wages, water disputes
etc. are causes of unrest. Information of all such issues with a potential for law and
order situations or clashes or offences either spontaneous or instigated is required
to be collected and recorded in the village history note book (Part IV). The beat
area constables with the help of Panchayat secretary and contacts with local people
will be in a position to collect this information. In the event of likelihood of the
breach of peace, the names of parties, the object of dispute or conflict, the extent to
which the village and its residents are likely to be affected should be assessed and
regularly informed to the SHO.
23.7 Beat Area Policing
(1) Two officers of the rank of police constable/head constables should be assigned for
the rural beat and 3-4 constables/head constables should be assigned to a beat in
urban area.
(2) The police constable/head constables assigned to a beat should be thoroughly
briefed by the SHO. He should bring to their notice personally and in writing the
standing instructions and responsibilities, and should give specific instructions to
the officer regarding such matters as the nature of the work they have to perform,
the manner in which it should be performed and the time by which they should
return to the station, after each spell of duty. He should give them the benefit of his
own knowledge and explain the purpose and specific problems that require to be
looked into in each village.
(3) Constables kept in charge of a beat should not normally be changed for three years
and may be continued up to five years if possible so as to enable them to acquire
thorough knowledge of the area, population, nature of its crime and criminals, and
other matters of police interest.
11

<!-- page 33 -->

Sikkim Police Manual

(4) Efforts should be made to establish Village/Town Defense Parties and sound policepubic co-operation and interaction which in turn help in building up relevant data
and intelligence regarding all categories, suspicious strangers and other activities
of police interest in the beat area. This is the bedrock of police, crime, criminal
and police information system as well as the preventive and detective strategies
of police.
(5) Constables going on beat duty should proceed to the beat direct from the station.
Likewise on return they should report at the station before going home, hand
over reports and arms and ammunition and other equipment if any issued. Any
information during tour that deserves to be communicated should be communicated
by quickest means like telephone or fax or any other means.
(6) The departure of a constable on beat duty should be noted in the general diary,
together with the special instructions given to him by the SHO.
(7) During the day, the beat constables will make enquiries about bad characters, but
during the night, bad characters will only be checked to know their presence or
absence from the village. No enquiries should be conducted during the night.
(8) Lurking points should be identified and constables of the beat should spend
sufficient time there during patrol duty.
23.8

Checking of Beats

(1) Checking of Beats means verification of work done by beat area PCs including
information brought by them and secondly physical check during night patrolling.
The first part is done through enquiries by SHO himself or ASI or HC. The second
part is also done by the SHO or an officer deputed by him as prescribed herein. If
the SHO is Inspector or SI, SIs or ASIs respectively should check the officers on
night patrol duty by surprise.
(2) The SHO or SI or ASI should visit selected villages/locations (not the same every
time) with the beat books and compare the dates and hours of the entries in the beat
books with those in the point books. Such verification should be made even when
the SHO or ASI/SI or officer in-charge of outpost goes to a village on any other
work, such as petition enquiry or investigation. If beat books are not available, the
checking officer will note down the particulars in his notebook and compare them
with the beat book on his return to the station. Verification of information may also
be done in the same manner.
(3) The SHO should also make enquiries with villagers other than point-book holders
regarding the beat police officers’ stay or presence on the days noted in the beat

12

<!-- page 34 -->

Volume II

book. Such enquiries should be more in the nature of acquainting himself with
actual field realities rather than out of any distrust.
(4) The SHO should personally check the patrols in each beat area in his jurisdiction
at least twice a month. ASIs or OP in-charge should do so more often.
23.9

Duties of supervising officers in relation to Beats
Officers of and above the rank of SDPO visiting or inspecting a Police Station
should not only see whether beat villages/locations have been properly selected,
but also ensure that the function of beats are being achieved and the data required
is being compiled on sound lines. The fact of having done so should be embodied
in the inspection or visiting notes, together with the instructions, if any, given to
the Station House Officer. He shall go through the village permanent information
book and see if entries are made as per proforma and the information is authentic
and record his comments wherever necessary in the register.

23.10 Roads and Highway Patrols
Safety of roads in a beat area is also the responsibility of the beat in which such
roads are located. This patrolling by beat constables is different from the traffic
patrol which would be generally mobile. During the weekly beat or separately the
beat area constable should concentrate on the roads both by day and particularly
at night. The purpose of this should be to prevent crime on the roads and afford
assistance and protection to those in need of the same, particularly women and
children. They should closely liaise with the concerned traffic patrol and obtain
such assistance/information that would facilitate effective crime prevention and
protection to the needy.
23.11 Procedure on return of police officers from patrolling
or Beat or other service
(1)

When a Police Officer returns from beat duty, he should report to the SHO. An
entry should be made about the time of return of the constable/HC from beat duty
in the general diary. The SHO should verify and satisfy himself that the Police
Officer has contacted point book holders. The SHO should debrief the beat police
officers and take report on the following;
A. Collection and updating of information;
B. Surveillance over history sheeted persons;
C. Meeting public, Community Liaison Group members, village Panchayat officials
and representatives of panchayats;

13

<!-- page 35 -->

Sikkim Police Manual

D. Service of summons and execution of warrants;
E. Petition enquiries entrusted;
F. Assessment of possible breach of peace and public nuisances;
G. Their observation relating to the absence of ex-convicts and history
sheeted criminals.
(2)

The information brought by the beat constable should be verified by the SHO by
contacting the concerned police officer where the absentee criminal is said to have
gone. Similarly he must himself verify if he is elsewhere in his jurisdiction. If
there are any strangers found in the area with suspected movement he shall make
a report immediately to the concerned SHO.

(3)

The information relating to the absence or a temporary change of address given
by the ex-convict or history sheeted person shall be verified by the SHO with the
concerned police stations for the correctness of the information.

23.12 Records pertaining to Beats
The information furnished by the beat area police should be entered by the SHO
in the following records:
(1) Permanent Village Information Book: This will be maintained by the HC/senior
constable in charge of the beat after the reports and information on each column
and item have been submitted to the SHO and the summary approved by him.
Name of persons entered in Part III of VCNB of a police station shall be entered
with modus operandi, name and parentage. The sheets so approved will be filled
by the SHO in the book maintained in Form 82. SHO and SDPO shall countersign
the entries. The latter may enter details in the sheets based on their own enquiries
and information, or modification of information recorded. The proforma sheets
will be issued to them by the SHO.
(2) Beat Visiting Book: All the villages should be first arranged alphabetically leaving
some pages of the book for each village. On the pages allotted for a village, the
usual signatures of five or six inhabitants with good antecedents of that village
where point books are kept should be obtained. The inhabitants should cover all
important localities and sections of people. Three of the five persons may be a (i)
Member of Panchayat, (ii) Panchayat Secretary and (iii) member of Community
Liaison Group. The first page should carry an index to the villages with the page
numbers noted against them. The night patrolling by beat area constables to each
village will also be noted in the pages meant for each village and signed by them
on their return to the PS. The sample signature book will be in Form 83.

14

<!-- page 36 -->

Volume II

(3) Beat Books:
(I)

Every beat should have a beat book in Form 84 A. In the beats having more than
one beat officer, the SHO shall entrust the responsibility of maintaining the beat
book to one of the more intelligent and literate officers.

(II)

The beat book shall contain the following information :

(i)

Crime Map of the beat showing the location of murders for gain, dacoities,
robberies, burglaries, cable, vehicle, and other thefts for the current and
preceding two years;

(ii)

Crime map showing the automobile accidents for the current and the preceding
two years;

(iii)

Address, telephone number, name of guards and working hours of every bank;

(iv)

Details of schools/colleges of the area;

(v)

Details of markets, bazaars, haats etc. and their working hours also any vegetable
markets-many are illegal and obstructing traffic;

(vi)

Details of jewellery shops and their working hours;

(vii)

Complete information about slums and crime prone areas, their residents,
complete details of criminals, local dons etc;

(viii)

Details of all hotels, lodges and restaurants with telephone Nos;

(ix)

A list of monasteries/gumpas, temples, mosques, churches and other religious
places with prayer timings, annual festivals etc;

(x)

General information about bus station or airport;

(xi)

Information about all festivals celebrated in that area;

(xii)

Details of all professional criminals and anti-social elements;

(xiii)

Names, addresses and telephone Nos. of members of Community Liaison Group
and peace committee;

(xiv)

Areas which are prone to communal/caste conflicts;

(xv)

List of persons helpful to the police and their telephone nos;

(xvi)

Names and addresses of those persons who usually are hindrance to
police work;

(xvii) List of industries in the beat, along with names and addresses of their
owners/CEO, the strength of the labour force and details of unions and their
office bearers;
(xviii) Offices of the print/electronic media along with names of journalists and their
telephone Nos;
15

<!-- page 37 -->

Sikkim Police Manual

(xix)

Details of hospitals, clinics and dispensaries along with name and telephone
No. of the Chief Medical Officer/Doctor;

(xx)

Details of multiplexes, cinemas, theatres and video parlours;

(xxi)

Details of offices of various political parties active in the beat;

(xxii)

Details of Fire Stations, Electric Sub-stations, Doordarshan/AIR Kendra,
Telephone Exchange, TV tower- with address and telephones nos;

(xxiii)

Details of Petrol pumps;

(xxiv)

Details of gas and explosive go-downs;

(xxv)

List of individual holding arms license;

(xxvi)

List of bus/taxi stands;

(xxvii)

Details of Govt/Semi-Govt. offices;

(xxviii)

List public playgrounds for the children and what are the hours when the
rush is more;

(xxix)

List of Malls and other commercial establishments having large footfalls.

(xxx)

List of Cyber cafes;

(xxxi)

List of beauty parlours;

(xxxii)

List of 10 most influential persons from each community residing in the beat
area with their address, telephone number etc;

(xxxiii)

List of addresses of suspects residing in the beat;

(xxxiv)

List of known drug peddlers residing in the beat;

(xxxv)

List of address of Modus Operandi Criminals residing in the beat;

(xxxvi)

List with address of ex-convicts residing in the beat;

(xxxvii) Gist of important law and order incidents that have taken place in the beat in the
last two years. As and when any law and order incident takes place in the beat,
the same should be entered for the current year by the Beat in charge officer;
(xxxviii) List of liquor shops.
(III)

16

Constables in-charge of beats whenever they proceed to the area should
take the beat book along with them and note in the appropriate columns, the
information they gather, during each visit. They should obtain the signature of
at least three persons whose sample signatures are maintained in the station in
the sample signature book in the appropriate column. Such signatures should be
obtained in all the villages including “route” villages/bazaar/locations through
which they pass. If the signature of any of the persons could not be obtained,
the reasons may be mentioned in the book. The beat constables are required to

<!-- page 38 -->

Volume II

sign the point books (P.B) during night patrol duty and obtain signatures of PB
holders while on such duty.
(IV)

The beat book should also be carried and action indicated as mentioned in the
previous Order, if a constable goes on any other duty to any of the villages
in the beat. Urgent visits where a specific work is performed and return is
immediate, will not count as beat duty.

(V)

The beat books should contain in appropriate column the names of suspects,
and habitual offenders proclaimed offenders, ex-convicts, receivers and other
history-sheeted persons.

23.13 Point Books
Books in Form 84 B should be supplied to Panchayat Secretaries / Municipal or
Nagar Panchayat counselors and selected inhabitants of every village with good
antecedents including a few members of the Panchayat and Community Liaison
Group in the station limits. Constables in charge of beats and officers overseeing
their work or visiting the village for any purpose should sign the point books
whenever they visit the village, noting the date and time.
23.14 Notice Board and Police Station Name Board
(1) Every Police Station and Outpost/Picket Post shall have a display notice board,
one meter square, in the Station premises, but outside the building so as to be
visible to public who come to the police station, to display the notices of persons
wanted, rewards offered, and other information meant for public view. The notices
or bills so displayed should be sufficiently bold, clear and legible.
(2) The name of every police station and out/picket post shall be prominently displayed
on a board in front of its entrance. Such board shall be navy blue in colour with
name of the police station in semi circular shape at the top and the name of the
district at the bottom. The logo of Sikkim Police shall be in the centre. All writings
on the board and logo shall be golden yellow in colour. Similar boards written
on both sides should be fixed to a post on the road side in front of the station so
that people moving in either direction of the road are in a position to identify the
location of the police station. Similar boards indicating the beginning and end of
jurisdiction of police stations should be erected along the highways and the main
district roads.
(3) These boards should also carry the telephone number of the police station.
(4) Similar boards should be displayed at outposts/Picket post/Check post.
(5) No fancy boards are permitted, but neon signs or proper lighting is permissible.
The colours mentioned above should not be changed.
17

<!-- page 39 -->

Sikkim Police Manual

23.15 Station Security and Guards
An SI/ASI shall assist the SHO in the security and guarding, housekeeping,
reception, public relations, and other miscellaneous functions of the police
station. The security should include security of arms, ammunition and government
property, case property, prisoners, lock up rooms etc. The house keeping functions
should include cleanliness and proper maintenance of all equipment provided to
the police station including vehicles, communications and scientific equipment
and weeding out of old records. He will be in charge and responsible for posting
guards or watch depending on the assessment of the threat perception under the
orders of the SHO and availability of manpower. The strength required for these
duties shall be found from the general detachment.
23.16 Rotation of duties and Reliefs
(1) General duty staff as distinct from beat detachment of a police station should also
be sent out by turns on day duties as well as night patrol duties in any of the beat
to support or substitute the regular beat Constables. They should be sent on night
beat duties at least on 4 nights in a month. The personnel allotted to various beats
may also be given such duties of general detachment like station guard, reception
or investigation, incident control when they are not engaged with their area beats.
The rotation of duties should not disturb the assignment of police officers to various
area beats.
(2) In times of emergency, when it becomes necessary to mobilise an emergency
force, as many police officers of various ranks as can be conveniently withdrawn
from routine duties will be assembled at the stations and retained as long as may be
necessary. This mobilisation should ordinarily not include the investigation staff of
the police stations.
23.17 Dissemination of Intelligence
(1) Where there is more than one police station in a town the Station House Officers
should work in close cooperation with each other. The SDPO will ensure proper
coordination of work of all. Telephones, wireless sets or cell or mobile phones
wherever provided should be used for communicating information of interest to
other police stations and to each other.
(2) Two telephone message registers should be maintained as prescribed.
(3) The SHO of each station will communicate to the control room and other police
stations in the town every morning, reports of crimes, absence of bad characters,
arrests of suspicious strangers, cases of missing children, property lost, found,
or recovered under suspicious circumstances, and other matters of interest or
18

<!-- page 40 -->

Volume II

importance. Each SHO shall be responsible for the dissemination of intelligence
of his station to the other SHOs in nearby areas. Only in cases of breakdown of all
means of communication, information should be conveyed through messengers.
23.18 Schedule of Training and Instruction
(1) To keep the personnel well trained, up-dated and physically fit the following
schedule for physical exercises, drill and instructional classes is prescribed for all
the police stations.
Monday & Wednesday

Briefing, catechism, local information including onjob training and relevant orders of police manual.
A typical schedule should consist of reading and
explaining a Chapter or a part of it, all-important
circulars, exchange of information on crimes,
absconders, arrests and properties.

Tuesday & Friday

Physical training, Yoga, weapon training and drill
as per module designed for police stations by the
Training Branch.

Thursday & Saturday

Cleaning and maintenance of arms, equipment,
vehicles and weeding out of records. Shramadan for
the up-keep of the PS, buildings, areas and grounds
and police quarters, complexes. All police officers
present irrespective of rank shall participate.

(2) If one of the days assigned for physical exercises and drill happens to be a holiday,
drill may be held on the next working day in addition to the programme of work
for that day. Every member of staff of the PS should so regulate their duties that
they attend parades regularly.
(3) All the staff including the station writers, except those who are given a day or 24
hours off or who were on night beat or patrol duty the previous night, shall be
required to attend the above schedule.
23.19 Allocation of Duties
(1) Duty shifts to be adopted in Police Stations shall be as follows:
First shift
0800 - 1600 hours
Second shift
1600 - 2400 hours
Third shift
2400 - 0800 hours
(2) These working hours are intended for the personnel during normal days in the
police station headquarters, but not to those who go out of headquarters on beat or
other duties.
19

<!-- page 41 -->

Sikkim Police Manual

(3) The above shifts are applicable for the staff with fixed day duties like the Station
Writer and others on general duty. They should ordinarily be given weekly off on
Saturday or Sunday. They can be utilised for any emergency duty during the night
or day. The Police Officers earmarked for beat can be utilised for duties connected
with breach of peace or other situations anywhere in the Police Station area if
such deployment is justified and called for. Even while making arrangements for
peace and order duties of a widespread nature within the Police Station limits, they
should be deployed as far as possible in their beat areas which will not count as
withdrawal from the assigned beat.
(4) There may be contingencies when there is need for night patrolling on almost all
nights in all the beat areas whether in a rural police station or a town police station
or an outpost. Even in such contingencies the constables earmarked for the beat
should generally be sent on night patrolling in their beats only along with the other
personnel. This ensures maximum availability of manpower without disturbing the
hours of duty or need for emergency mobilization.
Off Duty
(5) Police Constables and other Police Officers should ordinarily have a clear day off
once a week. The SHO will announce every evening, when duties for the next day
are detailed as to who will be off duty the next day.
(6) No officer who is off duty shall leave the headquarters without prior permission.
He should leave information in his residence or with neighbor or the nearest police
station as to his whereabouts if he leaves his residence and proceeds to any place
within the village or town.
(7) On certain occasions weekly off may not be given or normal spell of 8 hours a
day may exceed. In emergencies or due to exigencies of situation the personnel
may have to be kept mobilized in a Police Station or at any other place. To cover
all such contingencies food arrangements as admissible to all ranks up to Sub
Inspector of Police may be made.
(8) The legal obligation of 24 hours deemed to be on duty should not be interpreted to
mean that every police person can be on duty indefinitely for days together for any
length of time. The following guidelines should be borne in mind on this subject.
A. Police as a body are on duty all the time;
B. A Police Officer who is off duty has certain obligations as given in the
relevant Chapters;
C. All Police Officers are obliged to forego weekly off and work longer than 8
hours when there is an emergency. For example if, an officer leaves a task
on hand abruptly at the end of 8 hours shift it will result in serious prejudice
20

<!-- page 42 -->

Volume II

to a case or injury to persons or disappearance of evidence, continuation of
disorder etc.;
D. All police work deals with emergencies in a way. Hence normal duties should
not be interpreted as emergencies warranting mobilization;
E. Inadequacy of man power at times may be due to absence of advance planning,
or adequate intelligence. If this is rectified, things can be managed in time with
available man power;
F. The responsibility to ensure that emergency mobilization is kept at a minimum
shall rest with SHO, SDPO and SP.
(9) To enable SHOs to discharge their responsibility effectively the following
guidelines are issued :
A. Make an assessment for manpower needs at the beginning of the year for such
occasions as fairs, festivals and other bandobusts in the light of past experience
likely nature of trouble and general information;
B. Collect advance intelligence as to the exact nature and spot of trouble in respect
of agitational activity and provide for bandobusts at the most troublesome
locations. In case the agitation is widespread throughout the district or the
state, no additional strength would normally be available. Hence the available
resources should be used to the maximum advantage;
C. If the police station strength is drawn for some other duty outside, mobilisation
of the existing staff may be effectively chalked out;
D. Stationary pickets consume a lot of manpower. Make the pickets mobile to
cover an area with a fixed reference point;
E. In emergency, in the case of a law and order problem, no ceremonial guard
should be mounted for any functionary by the civil police. Only security
arrangements as per requirements, information and specific orders, if any,
should be made. No route-lining or road bandobust should be made except
what is normally provided. If the situation requires the SHO may follow the
functionary purely as a security requirement and not as a ceremony;
F. Utilise the beat area constables as far as possible for any arrangements or for
collecting information in their areas and do not disturb them from their beat area;
G. Avoid sending messengers where telephonic or other means of communication
serve the purpose;
H. Plan allocation of duties, bandobusts personally and do not mechanically
repeat some existing scheme;
21

<!-- page 43 -->

Sikkim Police Manual

I. Utilise home guards, and other volunteers to make up the numbers for dealing
with large gatherings. Solicit cooperation of Community Liaison Group;
J. Guard officers are also entitled to have 24 hours off in a week. This order may
be considered to have been complied with, if a continuous 24 hours “off duty”
is allowed to a guard officer on any day in a week;
K. The weekly off is intended to give the police officers a day’s rest every week.
This facility should not be denied without sufficient reason;
L. All Superintendents of Police should personally scrutinize extra duty hours
that police personnel are called upon to perform and to ensure that such duties
are permitted only in rare and exceptional occasions where the personnel
could not be given their weekly “off duty” in the interests of public service.
All gazetted officers, including DIGP are required during their inspections, to
examine whether these instructions are being properly implemented or not.
23.20 Travelling Allowance / food arrangement on deployment
(1) Police personnel of town and rural stations should be allowed travelling allowance
admissible under the rules, when the duty on which they are posted involves journeys
beyond limits prescribed under the TA/DA rules of Government of Sikkim.
(2) Police personnel of town and rural stations deputed for bandobust duty beyond the
prescribed duration should be provided with food and refreshments at the place
where deployed at the prescribed cost by drawing feeding allowance as an advance
which could be recouped soon thereafter.
23.21 Grant of Leave and Leave Report
In granting casual leave, the SHO should be impartial and the urgency of each
individual case should be correctly assessed. In genuine cases of sickness the SHO
should be in a position to judge and make arrangement for the medical treatment
of the officer rather than leave him to fend for himself. The annual medical
examination should be conducted without fail. The entries regarding the health
in the service book of the police officers should be up-to-date. The SHO is duty
bound to know the health particulars of each one of the policemen working in the
police station and their families.
23.22 Kit Inspection
(1)

22

The Station House Officer shall inspect the kits of all Head Constables and
Constables in the first week of every quarter of the calendar year. Any Police
Officer not present on the day fixed shall produce his kit on a subsequent day.

<!-- page 44 -->

Volume II

(2)

The SDPO should verify during their visits to police stations whether the kit
inspections have been properly done and action taken to see that all Head Constables
and Constables are in possession of their kit in full and in proper condition. Any
defect noticed in the articles either in quality or manufacture should be recorded
and reported to the district police office.

(3)

The manner of presenting the kit articles and clothing should be as prescribed in
the Sikkim Police Drill Manual or Standing Orders. The police officers should
always place the latest issue of clothing when they present the kit for inspection.

23.23 Development of skills - specialization and self-improvement
(1)-A. Several skills and abilities are required for police to perform their duties in a
professional manner. The personnel in the police department spread over in a
district and State and within a police station do have these in varying degrees. In
the rustle and tumble of day-to-day work the police officers tend to ignore or do
not think of utilizing these skills to the best advantage. Apart from utilization, the
development of skills enriches the resources of an organization from PS level to
the State level. Each type of police station requires certain type of general skills.
Some skills are useful at all police stations. It may become necessary to pool
resources and skill to handle important situations or cases in the district.
B. The SHO should personally assess each Constable, Head Constable, ASI and
ascertain by talking to him the special skills each one possesses and make a note
of the same.
C. In the course of performance of duties by them, the SHO should observe and judge
the special skills exhibited in the course of his duties by each one of them and
make a suitable entry in the nominal rolls. This should be done after he confirms
his opinion on the basis of personal contacts and observation of the concerned
officer. The SHOs should try and find out the skills of each person even if the men
are reticent or reluctant to come out.
D. The SDPO concerned should take similar action in respect of all SIs and Inspectors
working in his area or under his charge and send the information to SP who will
arrange to have the entries made in the service record under a column “special
qualifications” to be set apart for this. The Addl. DGP/IGP Headquarter in DGP’s
office should ensure that this data gets into the personal records of officers
of all ranks.
E. The level of skills should be graded as very good or good only right from the level
of constable upwards. There is no need to make any entry where special skills do
not exist. The normal police capabilities need not be mentioned.

23

<!-- page 45 -->

Sikkim Police Manual

(2)

The skills, which should find mention, are those, which are useful in practical
police work like preventive action, investigation, maintenance of order etc.
or support functions. Some of the special skills which are useful for a police
officer are;
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•

24

Interrogation of suspects or accused
Intelligence gathering - criminal or other
Anti terror operations, ambush, counter ambush
Security duties
Report writing and entries in records using computers
Data entry
Computer hardware maintenance and care
Short hand or typewriting
Cartography (map making)
Observation
Sketch drawing
Photo and videography
Handling/maintenance of sound equipments
Motor mechanic
Wireless, telephone operation/mechanic
Driving
Defusing of bombs and explosives
Unarmed combat
Identification, lifting, packing and forwarding scientific clues
Special knowledge and experience in specific case investigation
Proficiency in language Nepali, Bhutia, Lepcha, English or Hindi or ability to
prepare lesson plans and reading material
Teaching
Instruction outdoor and indoor
Surveillance and shadowing
Computer software
Swimming and capacity to save persons
First aid
Fire fighting
Public relations

<!-- page 46 -->

Volume II

(3)

(4)

•
Scientific knowledge relevant to police
•
Electrician
•
Electronics
•
Information Technology
•
Law
•
Accounts and Audit
It is not the normal levels of skill out of the above which policemen are expected to
have. The level should be much higher than the minimum levels. The acquisition
of any diploma/degree does not by itself amount to acquisition of skills.
Senior officers should be aware of the special skills possessed by the police
personnel and utilize them accordingly besides making efforts for enhancement of
these skills. Following methods could do this :

A. Utilise them on duties where the skills which they possess help police investigations
or other work in addition to whatever is normally allotted to them;
B. Depute them to teach or demonstrate the skills to others in the Unit during weekly
training or on-the-job courses;
C. Provide necessary literature and depute them for specialized training when arranged
or available;
D. Where eligible, recommend them for the grant of special allowance to the
concerned. The eligibility criteria for allowance should be as prescribed;
E. Depute the personnel when requisitioned in the district, State or anywhere in the
country where their services would be useful for any special task. All additional
skills and further improvement / enhancement should be noted in the service record
of the concerned personnel annually;
F. Besides the above, helping in self-improvement of police officers is an important
aspect which should receive attention of SHO and senior supervisory officers.
The distance education packages, on-job training courses should be given priority
without affecting normal duties. The permission to appear for the examinations
must be given and the personnel relieved in such a manner that they are able to
reach the place of examination at least one day before the date of the examination.
It shall be the responsibility of SP to ensure their relief and give effect to all other
facilities for training in self-improvement without prejudice to their normal duties.
All enhancements of skills and self-improvement are intended to bring qualitative
improvement in police work and as such the skills have to be enhanced as part of
normal work and police officers should be encouraged for self-improvement.

25

<!-- page 47 -->

Sikkim Police Manual

23.24 Shramdan
(1)

Shramdan consists of cleaning and keeping in order the police grounds, the police
station and its premises, and the police quarters, white-washing of police lines and
minor repairs to the station house and police quarters, keeping the firing range if
any, in order, and maintaining the orderliness and cleanness of the premises.

(2)

Where it is possible, whitewashing of the lines should be performed by the
occupants. Where it is not possible, in the opinion of the SP, annual white-washing
can be included in the annual work to be done by Building & Housing Department.
The Municipal Corporations, Municipal Council, Nagar Panchayat and Major
Panchayats, the Zilla Parishads in respect of other Panchayats normally provide all
amenities to the Police Station and quarters and also extend support to undertake
minor repairs or white washing of PS buildings or provision of facilities to the
public like drinking water, toilets and also their maintenance.

23.25 Public Relations
(1)

(2)
(3)

(4)

26

Every police officer working in any police station is the best PRO for the department.
There is no substitute for proper public relations other than professionalism, integrity,
impartiality, desire to serve and dedication to assigned duties. It is such performance
and conduct that earns the confidence and respect of the public and credibility to the
police. Even one bad instance of misconduct or rude behavior of one officer is likely
to result in painting everyone else with the same brush. It is difficult to obliterate
that impression for quite a long time. The first step therefore in public relations is
that every police officer from Constable upwards should work and conduct himself
with responsibility, civility and courtesy whether in word or deed.
Patient hearing of people who come to police station in distress by all ranks is
necessary. The telephones must be answered promptly and politely.
A reception area within available means should be provided for people to wait,
so that each one can be individually attended to. It is better that groups of people
are met first and disposed off by the SHO himself coming out and talking to them.
Where there is rush of complaints the SHO should detail officers available, to deal
with each complainant simultaneously so that suitable disposals can be given. No
impatience or haste should be shown. The person must not only be heard, but must
get a feeling that he is heard and prompt steps if any for redressal of grievance are
being taken. Never dispose off any one by merely saying that the matter will be
looked into. Inform what you propose to do at once or soon later. If police are not
the proper authority, help him to approach the concerned.
When a cognizable case is reported register it promptly and initiate action. Keep
in touch with the complainant/victim or his close relatives and inform action
being taken either by telephone or by other means or even by utilizing the services

<!-- page 48 -->

Volume II

(5)

(6)

(7)

(8)

of beat area Constables. In their anxiety the complainants do visit the police
station themselves and in which case, receive them and inform them the action
being taken. The IO should inform about recoveries, arrests, charge sheets and
other important details to the complainant from time to time. The complainant/
victim should be taken into confidence even for the purpose of investigation.
Stay sufficiently long at the scene until all clues are collected and witnesses are
examined. Discuss doubts and clarify all points with him. Where the complainant
is a litigant or apparently pursuing a false case, misusing the legal process, do
not disclose your mind or conclusions but listen patiently. The nature of response
to complainant depends on the nature of the case. In thefts, burglaries, dacoits,
murders, cheating, hurt cases immediate steps give confidence and ensure better
help from complainant in the investigation of the case. Precautions are to be taken
not to give a false hope or cynical or unhelpful remarks. Never give a list of your
difficulties and handicaps or discuss about other officers or staff of the police
station. Give confidence to a genuine complainant and be guarded, polite, but firm,
in respect of false complainants.
When a sensational or an important case occurs it may be necessary to give
prepared statement to the media on the facts of the case and progress if any. Details,
which prejudice investigation or give clues to absconding accused, statements of
witnesses or suspects should not be disclosed, but broad picture of the case and
the efforts of the police should be given. Such developments as arrests, recoveries
should be informed to them. It is better the SP handle the media in grave crimes
personally. The SDPO and SHO should follow these guidelines.
Take the press and media into confidence when handling a sensitive case. Sometimes
they would be helpful in the investigation by proper publicity particularly in the
matter of absconding accused. Do not disclose the sources of information and
names of witnesses. Avoid personal publicity and talk of the team as a whole.
Remember to give outline of progress in cases where media interest is focused
everyday for sometime by written statements. Never give off-hand replies to
queries or enter into discussion into various theories of investigation of the case.
Never give anything that has a tendency to denigrate any person or jump to premature conclusions. Remember when the earlier conclusions go wrong on the
basis of subsequent evidence; the police will face serious problems of credibility
since investigation is a continuous process with the real facts emerging gradually,
hence the caution.
Do not react to criticism but if any wrong information appears clarify through
prepared statements. Always remember that it is not merely the police and the press
involved in this exercise but there are others like victims, witnesses, complainants,
accused, suspects and the public at large who may be affected.
27

<!-- page 49 -->

Sikkim Police Manual

(9)

Never confirm or deny suspicions unless thoroughly proved in the investigation on
that particular aspect.
(10) Media will be interested sometimes in taking photographs or live coverage of the
scene. Organise this by proper liaison without compromising the requirements of
investigation or loss of clues or prejudice to investigation. Most problems are solved
by a proper advance liaison in such cases. Some of the photographs and video graphs
taken by the press in connection with a case and interviews with certain persons
would be useful even for investigation. A good liaison will therefore be in public
interest apart from helping the people to know the information about a case from
independent media sources. It is not every case, which needs a curtain of secrecy.
It is only some cases and that too to the extent of not prejudicing the investigation
that an element of restraint and confidentiality needs to be maintained. Never be
overwhelmed or flustered in a situation or allow yourself to be intimidated or lose
your temper. Keep cool and smile away provocative questions or answer calmly
giving only the facts.
(11) In every locality of beat voluntary bodies such as Community Liaison Group are
to be encouraged and helped and liaison maintained during normal times. The
SIs and beat area Constables have a vital role to play. Besides the SHOs should
hold regular monthly meetings in various towns / villages in their jurisdictions. It
will help the public to meet the Police Officers and voice their grievances, if any.
This will also enable the Police to sensitize the public on various issues and seek
their cooperation in prevention of crime and maintenance of law and order. Thus
it will be obligatory on the part of SHO to visit town / village in his jurisdiction
along with his staff after giving advance publicity through Village Panchayat or
Panchayat Secretary and press. The senior officers should also make it a point to
attend such meetings wherever possible.
(12) Maintain close touch with the schools and youth organizations to enlist their
support, involvement and understanding of police problems, mainly in areas of
traffic regulation, injured persons, forming up of queues, conduct of sports and
cultural events. Occasional classes and printed material to help understand basic
law would be very rewarding exercise. These should be a part of systematic
programme and not to be treated as formalities like occasional rallies or festivals.
(13) Every Constable and police officer must avoid any rude behavior at all costs. There
is no place for rudeness in police work. There is only firmness for an offender and
courtesy for the law-abiding citizen.
(14) Never employ third degree methods. Respect and uphold human rights in
handing cases.
(15) Show utmost consideration to children, women, old persons, poor people, weaker
sections and those who come for protection and help.
28

<!-- page 50 -->

Volume II

(16) Ensure to hand over recovered stolen property to court and the complainant
should be kept informed and not made to run around the police station and the
court unnecessarily.
(17) Do not allow touts and brokers around the police station.
(18) Do not allow any outsider to do police work like filling up records or typing etc.
If any temporary person is to be employed on a contract basis it should be under
relevant rules and proper authority.
(19) Give information promptly of all good work done. Project the officers who did
the work.
(20) Eve-teasing and activities of local goondas badly reflect on police. Always take
tough action under the law including binding them over. The action should be swift
and effective.
(21) Prompt punishment of offenders in cases improves confidence and brings more
cooperation from the public. Pursue cases vigorously.
(22) Follow the rules of conduct scrupulously to avoid complaints of non-registration
of cases, rude behaviour and lack of integrity.
23.26 Care and custody of Arms and Ammunition
(1) The SHO and in his absence the officer holding the charge of the police station
will be in charge of the arms and ammunition in the police station. The arms
in the police station shall be kept secured in an arms-rack by means of a chain
fastened with a lock. The ammunition shall always be kept in a locked box. The
Station Writer when present in the station or, in his absence, the guard officer
shall keep the keys of the rack and ammunition box in his custody. The Station
Writer or the guard officer shall, when taking charge of the keys, check, the arms
and ammunition and satisfy himself as to their correctness. An entry to this effect
will be made in the general diary both by the officer handing over the keys and
by the one receiving them. The officer in-charge of the station for the time being
shall also check the arms and ammunition whenever he takes charge of the station
general diary and satisfy himself that they are correct.
(2) An Arms Register & Ammunition Issue Register (Form No. 85) should be
maintained in the police station, noting therein the number and name of the
Constable or Head Constable or officer to whom, each weapon is issued and obtain
his signature against the entry. The officer to whom the weapon is allotted shall
be responsible for its upkeep and cleaning etc. He should use the weapon allotted
to him for the annual practice or wherever it is to be carried in the performance
of his duty.
(3) In extremist affected areas, all the members of the station guard should always
carry rifles and sufficient ammunition with them especially in the night.
29

<!-- page 51 -->

Sikkim Police Manual

23.27 Cash chests of other departments
(1) The Cash boxes or chests of any Government department, local body, and bank
may be accepted for temporary safe custody in the police station. The SHO should
ensure that the boxes are securely locked and sealed before they are accepted,
as the police are responsible for the seals and not the contents. The sealed boxes
should be accepted only on a letter of authority from the local head of the institution
delivered in person. The SHO, before accepting any such boxes should cross check
with the head of the institution concerned on telephone in case if the officer himself
has not personally come with the boxes. As most of the banks have their own cash
chests and their own security, there may not be any need for the cash chests to be
brought to the police stations.
(2) The same procedure should be followed in respect of question papers or ballot
papers, which are brought for safe custody by authorized persons to the police
stations. These boxes should be secured in the same manner as is done to secure
the police arms and ammunition or cash.
23.28 Lathies and Fire Arms
Police Constables and Head Constables who turn out for dealing with crowds,
bandobust duty, patrols in beat areas (when rifles are not taken), and on any occasion
in which a lathi may be required for self-defense, should always be armed with
lathis of prescribed specifications. In disturbed and terrorist areas firearms should
be carried.
23.29 Fire Fighting Equipment
In police stations where hand fire pumps or other firefighting equipment are
provided, the police should be instructed in their use. All Policemen should be
trained in fire fighting and made familiar with use of modern firefighting equipment.
23.30 Necessity of prompt dissemination of information
(1) The prompt dissemination and exchange of information is one of the most important
duties of police and it must receive the close attention of officers of every rank.
(2) Station House Officers shall be responsible for the prompt circulation of lists of
property lost and descriptions of absconding offenders to stations where they are
likely to be useful. It is of utmost importance that the inter-State border check post
are given the earliest intimation to be on the lookout for absconding offenders or
the perpetrators of any particular crime.

30

<!-- page 52 -->

Volume II

23.31 Criminal Intelligence and Information
(1) Intelligence is the most basic and necessary input for police work. Timely
intelligence and information can help in the prevention, detection of offences and
maintenance of peace and order. Prompt intelligence is necessary to take preventive
steps in avoiding commission of offences, to put down terrorist violence, communal
or caste troubles or to apprehend absconding offenders. It should therefore be
promptly gathered, documented, analyzed and used in time.
(2) The beat Constables and other police officers in the station are responsible to gather
correct information and pass it on to the SHO from time to time relating to movement
of prisoners or suspicious character or relating to any other criminal activity in the
locality. The SHO on verification of information should send a consolidated report
to the DCRB directly by Fax or Radio marking a copy to his superiors.
23.32 Report of probable presence of habitual criminals
(1) In every case of crime against property and financial crime, a crime card in Form
41 shall be sent by the Station House Officer of Police Station to the District Crime
Records Bureau with a copy to the SCRB. For other crimes details Form 42 may be
used instead of the crime card. Such forms should also be sent to the Sub-Divisional
Police Officer and to the neighbouring police stations in the district, as also to the
bordering stations of adjoining districts. If the offenders are from outside, prompt
information should also be sent by wireless, fax or telephone, to the neighbouring
police stations and inter-State check post/police stations. Station House Officers
who receive the information, whether by crime card, radio or wire, or telephone
will immediately institute the necessary enquiries and with the least delay, report
the result by radio or telephone, fax or memorandum to the station from which the
information was sent. These replies will be filed with the concerned case diary.
(2) Crime cards or radio, fax messages received in a station from other stations shall
be retained for two years.
(3) The intelligence about the presence of criminals or gangs or activity, which suggests
commission of a crime with details available, should be promptly reported on the
same day to the DCRB as part of the daily report of crime and information. In urgent
cases, the information should be communicated to the concerned as indicated above.
23.33 Criminal Investigation Gazette (CIG)
(1) Notices to be sent to other districts: Notices and intelligence, which require
immediate publication without any delay, should be circulated forthwith to the
districts. The number of copies of such notices required should be obtained on
photocopier and sent.
31

<!-- page 53 -->

Sikkim Police Manual

(2) Notices of disappearance of individuals: Notices of the disappearance of individuals
should be published only when the circumstances of the disappearance give rise to
suspicion of foul play.
(3) Criminal Investigation Gazette shall cover not only cases of property, but also
cases relating to bodily offences under other laws where identity of the accused
or identity of missing or dead person is necessary. Details of stolen automobiles,
arms, explosives and ammunition, property seized or lost should also be sent for
publication in C&O sheet or CIG as per relevant guidelines.
(4) The CIG consisting of C&O sheet, crime cards or crime details forms, or other
information should be gone through by the SHO who should study the priority,
read over to his subordinates and discuss with them during training classes. The
SHO should also detail officers to pursue specific information promptly.
23.34 Communication of intelligence to areas beyond the State
(1) SHO should send information on intelligence to the areas beyond the borders
and similarly act upon the information received from those areas relating to the
suspected persons, habitual criminals, organised criminal gangs, hired goondas,
person disposing stolen property from within and outside the borders.
(2) Analysis of information is therefore important in cases where immediate action is
called for soon after the offence, sometimes requiring road checks and barricades
to save life or to get at criminals on the run, after a ghastly offence. The information
required, or as much of it as possible, particularly about persons, their description
and photographs if available should be sent to all border areas even while taking
action within one’s jurisdiction. It is such response mechanism to various situations
that should be part of training in the Police Station, so that when situation arises
the police are able to effectively intervene and close all options of escape to the
fleeing criminal.
(3) The prescribed format should be used for communication of all information and
intelligence even if it is by telephone and record kept of information circulated.
Unplanned and blind dissemination of information without proper assessment leads
to flooding every Police Station with all kinds of information, resulting in loss of
focus and priority. The orders and guidelines issued herein therefore should be
read in that spirit. For example, if a murder case accused is known and his specific
hide outs are also known to the Station House Officer, they should proceed at once,
take assistance from the concerned for his apprehension carrying all details and
letters with them needed for securing help. There would be no purpose in such a
case, to send out any lookout notice all round either by radio or fax etc. In the same
case, if accused is known but no specific information about his whereabouts are
32

<!-- page 54 -->

Volume II

available but there is a probability of his being available in a particular area of a
PS in this State or outside information and all details as prescribed should be sent
to the concerned Police Station and officers. If he has disappeared with no clues,
then the question of general broadcast or sending out all information to various
authorities arises.
(4) Collection, recording reporting, and dissemination of criminal intelligence is not
for its own sake. Its objective is to operationalise specific procedure relevant to
each case. The responsibility of supervision rests with SDPOs and SPs to ensure
compliance and give a proper direction.
23.35 Deployment of Plain Clothes Men
Personnel of the district, deputed to look out for bad characters at large and busy
taxi stands and bus stands may, at the discretion of the SHO, be allowed to wear
civilian clothes. For surveillance and shadowing duties, trained personnel in
appropriate civilian clothing may be deployed.
23.36 Roll Call
Every evening at 1700 hours duties for the next 24 hours shall be detailed. A roll
call shall be held at 1700 hours every day, which should be attended by all Police
Officers who are not out on duty. Those who are out on duty shall ascertain their
duties for the next 24 hours on their return to the station. This order shall apply
to personnel of all police stations. The roll call time should also be utilized for a
quick briefing and exchange of information or communication of instructions.
23.37 Duty Roster
(1) A duty roster in Form 86 shall be maintained in all rural/town stations. Entries
should be made as soon as the personnel are detailed for duty, which ordinarily
will be at 1700 hours for the ensuing 24 hours.
(2) All Police personnel should start their duties normally from the station itself and
not from their houses except when called upon for emergency duty or instructed
to proceed from house straight to a place where he shall report to the officer on the
spot. Such deviations from procedure should be recorded in General Diary. They
must, on return from duty report at the station before going home.
23.38 Check posts
(1) The check-posts are set up as a temporary measure or on semi-permanent/
permanent basis to conduct a thorough check of vehicles or persons passing
through or coming in at a particular place on a highway, path or road. They may
be armed or unarmed depending on the purpose on which the check-post is set up.
33

<!-- page 55 -->

Sikkim Police Manual

The officer in charge of the check-post generally will be a Sub-Inspector/ASI or a
Head Constable. Whenever the check-posts are set up its records and management
should be the same as for an outpost. The upkeep of arms and their security should
be done in accordance with the guard rules and the procedure laid down for the
safe custody of the arms. The following guidelines are issued for the setting up and
management and work relating to the check-post.
(2) The place where the check-post is to be set up should be surveyed and the selected
site should provide sufficient place for outgoing and incoming vehicles to be
parked conveniently. The vehicle should not be allowed to be parked too close
to each other. The persons in the vehicles should also not have an opportunity of
gathering into a crowd at one place.
(3) The checking arrangements should be streamlined to serve the specific purpose
for which the check-post is set up. The personnel who are to check the persons
travelling in the vehicles should be thoroughly aware of what they are looking
for. If they are looking for persons they should be briefed on the descriptive
particulars or photographs as the case may be. If they are looking for properties,
weapons and other objects it should be ensured that the frisking or searching is
done systematically.
(4) Where physical assault or use of firearms is anticipated there should be separate
armed policemen covering the search operations without being involved in it.
Security cover should also be provided in the form of an additional Sentry to cover
the check-post itself.
(5) The check-posts should be equipped with strong metal barricades to regulate and
ensure orderly flow of traffic as also to stop any vehicle. The metal barricade
should be painted with fluorescent paint preferably red and white/yellow for easy
identification in nights. In serious cases a vehicle should be provided for chasing
an errant vehicle or a person who tries to escape.
(6) As check-posts are intended for search and seizure, the composition of a checkpost should contain both armed and civil policemen.
(7) A temporary shelter preferably a pre-fabricated structure should be put up whenever
a check-post is opened with the arrangements for water and food provided at the
camp. Tents may be used for living accommodation.
(8) Communication link preferably mobile wireless sets or cell phones should form
part of the equipment of the check-post.
(9) The setting up and running of check-posts at short notice should be planned and
rehearsed during normal times for all large towns and districts. SP should visualize
the different situations and plan in advance for the setting up of check-posts and fix
responsibilities for the same.
34

<!-- page 56 -->

Volume II

23.39 Armed Outposts
Armed out posts are set up to deal with violent and extremist groups operating in
remote areas. The duties and functions of these outposts shall be as determined by
the Director General of Police and the instruction issued from time to time. The
method of setting up of armed out post the strength and other equipment to be
provided is detailed below :
(1) The strength of an armed outpost should not be less than 1 section (1 platoon in
case of terrorist groups);
(2) The arms and ammunition issued to the personnel of an armed outpost should be
of such kind and quantity so as to defend it from any attack by armed extremists;
(3) The police station should provide specified number of police officers to form part
of the armed outposts to work as guides and otherwise assist the officer in charge
of the outpost in his tasks;
(4) A temporary structure, which provides for accommodation for the personnel as also
for the weapons and other equipment should be set up. Proper fencing, lighting and
security arrangements should be built into the campus;
(5) Transport and communication facilities have to be stationed at all times. A
HF wireless station additionally apart from mobile wireless and telephonic
communication should be provided;
(6) Self contained boarding arrangements and the staff required for the purpose should
be part of the establishment. There should be no dependence for any supplies
on any local village. All requirements should be procured periodically from the
nearest town by paying the market price;
(7) The senior officer in charge of the area has to assign the tasks including the task
of collection of intelligence and method of performance of duties including raids,
combing, and search and seizure operation from time to time;
(8) First aid and necessary medicines should be provided for emergencies;
(9) The police stations will be responsible for providing necessary support and
assistance to the check-posts and armed outposts which are set up in their
jurisdiction. The SHO of the concerned police station should be in close touch
with the officers in charge of the check-posts/OPs and keep the SP informed of
all developments from time to time. The SDPO has an important responsibility to
personally ensure coordination and supervision over the work of the OPs and the
check-posts subject to the orders and instructions of the senior officers conducting
the field operations.

35

<!-- page 57 -->

Sikkim Police Manual

Powers and Duties of Officers of Police station
23.40 Station House Officer
(1)

Station House Officer (SHO) means the Officer In-charge of Police Station,
of an above the rank of Sub-Inspector of Police. The SHO is an important and
vital functionary in the police department. He shall be responsible for proper
management of the station and optimum utilisation of the resources and facilities
available. It shall be his duty to manage the staff and work of the police station
in accordance with the law and rules and to make the police station a place
where the needy public gets necessary and immediate response. The image of
the police department basically reflects on the conduct and behaviour of the
SHO and his staff in the station, as it is at that point, public has a direct access
with the police. The SHO and his staff should behave politely and courteously
with the public giving an impression of friendly approach. Active co-operation
from Community Liaison Group shall be solicited in the matters of Law &
Order, Crime Prevention etc.

(2)

He should assign duties to his staff and personally ensure that these duties are
correctly performed.

(3)

He shall take measures for the prevention of crime, for the preservation of peace,
for speedy investigation and prosecution of cases. When more than one SubInspector is employed in a police station, which is headed by a Sub-Inspector,
the junior officer shall act in accordance with the orders of the senior.

(4)

He shall maintain a notebook in which he will write then and there his daily
movements and activities in discharge of his duties. The completed notebook
will be retained for 3 years with the station records. He will hand over his current
notebook to his successor when he goes on transfer.

(5)

He shall supervise the allotted work and duties of general and beat detachments.

(6)

He shall ensure the maintenance of discipline of the police officers of all ranks
posted under his command and control.

(7)

He shall inspect the drill of his subordinates, hold inspection of their kits, and
examine their beat books and notebooks.

(8)

The police men of the station should be briefed on all matters that have bearing
on their work and conduct through written material, audio and visual aids, radio
programmes specially broadcast and also personal instructions so that they are
psychologically oriented to discharge their allotted duties in an efficient manner.

36

<!-- page 58 -->

Volume II

(9)

Communication of information by fastest means of all important or sensational
events to the SDPO and SP concerned.

(10) He should see that every officer who is supplied with kit at government cost is
responsible for keeping it in good condition, and shall be required to replace it
at his own cost any article carelessly lost or damaged.
Duties with regard to law and order & crime investigation
(11) The duties of officer in charge of a police station are set out in the Cr.PC,
Police Act, Manual and orders issued from time to time. They broadly relate to
maintenance of law and order, prevention and detection of crime, investigation
and prosecution of offences as outlined below:
(12) The SHO is responsible for the maintenance of the law and order and public
order in his jurisdiction. His duties in this regard include :
A. Personal leadership and supervision of duties and work of all the staff and
men allotted to his charge including their welfare, discipline and morale;
B. Organising and actively participating in crime prevention and detection,
maintenance of law and order and anti-terror operations, dispersal of unlawful
assemblies and prevention of breach of peace and public order;
C. Organising beats and patrols and its personal supervision;
D. Scrutiny of records of each beat, check of night beats twice a week and
personal patrol;
E. Designing and implementation of policing schemes suited to such beat areas
and securing co-operation of public and Community Liaison Group;
F. Obtaining prompt information about activities in the field of Communal,
Caste, Political, Student, or other segments of society including subversive
elements and identify trouble spots and trouble mongers and to take effective
preventive measures like launching security proceedings under Cr.P.C.;
G. Entry and Maintenance of prescribed records including those required under
Crime and Criminal Information System (CCIS);
H. Maintenance of good public relations in his station limits;
I. Visiting and spending adequate time in the villages, localities of his
station limit;
J. Maintenance of effective surveillance over bad characters, anti-social
elements, and rowdies of the area under his charge;
K. Constantly endeavour to maintain high professional standard and keep
himself updated, well informed and motivated;
37

<!-- page 59 -->

Sikkim Police Manual

L. Pursuit and apprehension of offenders on available clues and information;
M. Collection of information on all important matters relevant to police duties
and his functions and communicating the same to his immediate superior
police officer and to other concerned superior police officers promptly;
N. Make police and bandobust arrangements for public gatherings, fairs,
festivals, processions, on a proper assessment of a situation of each time;
O. Acquire intimate knowledge of the area and its problems, the unruly elements
and population in general;
P. Take timely and appropriate preventive action and for the effective control of
the bad characters from whom breach of peace is anticipated by the effective
use of sections 107 to110 of CrPC and other laws.
(13) Furnishing of reports to DCRB & SCRB relating to (a) arrest of strangers under
suspicious circumstances (b) conviction report (c) reports on the activities and
conduct of all dossier criminal residing in their area (d) out of view history sheeted
criminals (e) date of release of history sheeted and dossier criminal from jails (f)
properties seized under suspicious circumstances (g) information in r/o suicides in
his jurisdiction (h) Monthly Crime Review as per prescribed format.
Investigation and Prosecution
(14) The SHO is responsible for the investigation of all special report cases reported in
his jurisdiction except for those where the investigation is entrusted to SDPO or
other senior officers or CID. If the SHO is unable to investigate special report cases,
he shall give specific reasons and obtain permission from the SP for doing so.
(15) As officer in charge of police station he shall perform the following duties relating
to investigation and prosecution of cases :
A. Register all cognizable cases furnishing a copy to the complainant invariably
free of cost and send the original F.I.R to the courts concerned immediately
and copies to his superior officer.
B. In respect of non-cognizable offences reported in the station, he shall record
the information in the general diary and also in the non-cognizable register,
and refer the complainant to the court by an endorsement.
C. In cases of non-cognizable offences referred by court or any cognizable
offences presented by parties directly in courts but endorsed by the court to
the S.H.O, he shall register such cases and investigate.
D. Promptly arrive at the scene of crime and thoroughly examine the same for
clues and for other matters of investigation.

38

<!-- page 60 -->

Volume II

E. Make arrangements for the preservation of the scene of crime.
F. Promptly conduct investigation by identifying, preserving, collecting and
forwarding of material, to scientific experts, and collection of documentary
and oral evidence.
G. Make use of scientific methods available for investigation.
H. Hold inquest where necessary and forward the bodies for the post mortem
examination according to the necessity.
I. Examine witnesses and record their statements accurately and promptly.
J. Conduct searches, and seize material if any as per provisions of Cr.P.C.
K. Arrest persons where necessary observing the necessary provisions of law
and the decisions of the courts and send them to remand in time.
L. Forward to the court the weapons and article seized from the accused as well
as seizure affected from searches along with necessary reports.
M. Obtain investigation report from subordinate officers deputed for investigation.
N. He shall write the case diaries regularly and forward them to the superior
officers promptly to enable them to give instructions for further investigations.
O. He shall finalise the cases without delay and file charge sheets where the
evidence is sufficient for prosecution within the period of limitation imposed
by the Cr.P.C and Courts.
P. He shall ensure prompt service of summons and execution of warrants.
Q. He shall take all steps to promptly prosecute the cases where evidence is
sufficient and assist the prosecutor by producing witnesses promptly to
refresh their memory before they are examined as witnesses in Courts.
(16)		 Besides the above duties, the SHO of check post Police Station shall perform
the following functions :
		 (a)
		 (b)
		 (c)

to restrict entry of unauthorized person(s) into the Protected areas.
to check/regulate the flow of people into Protected areas.
to conduct regular checks and census of people who are permanent
residents of Protected areas and that they have valid residential permits.
		 (d) collection of intelligence considered detrimental to and compromising
the security of India.
		 (e) to prevent people/cattle from crossing the International Border.
		 (f) to carry out regular patrolling of International Border.
39

<!-- page 61 -->

Sikkim Police Manual

Daily reports from Station House Officer
(17) The station house officer shall forward daily to the SDPO, a carbon copy of the
station general daily with a docket in the form prescribed along with copies of
F.I.R. registered and case diaries of that day.
23.41 Other Sub-Inspectors
Where the SHO is an Inspector or SI, other SIs posted under the SHO shall
have the following functions :
a. to be in-charge of 2 or more beats, general detachments or police station;
b. to be in-charge of general or traffic detachment or station administration,
including guards, as allotted by the SHO.;
c. responsible for direct supervision, guidance and leadership in the field as well
as in the Police Station to the police officers attached to the beats or the
detachments committed to his care;
d. maintenance of all records and diaries prescribed for various segments of the
Police Stations of which he is in charge;
e. maintenance of station house general diary in the absence of SHO;
f. investigation of cases;
g. prompt visits to the scene of offence, or trouble, preservation of the scene and
handling of the situation;
h. to keep SHO informed of all work, situations and duties performed from
time to time;
i. preparation of pay and travelling allowance bills (He should sign them only
when the SHO is absent);
j. any other duty ordered to be performed by the SHO.
23.42 Asst. Sub-Inspector
The following shall be the duties of the Assistant Sub-Inspector :
A. Investigation of simple cases as directed by S.H.O. and assisting investigation
in all cases handled by S.H.Os and other superior officers;
B. Petition enquiry;
C. Checking of enquiries in verification rolls;
D. Supervision of service of process work;
E. To function as an officer in charge of a beat area and check patrols;
40

<!-- page 62 -->

Volume II

F. Direct supervision or handling of station scriptory work;
G. Detailing duties to the staff during Sub-Inspectors absence and exercising
supervision and control over the Constables and Head Constables;
H. Maintenance of cash book;
I. Maintenance of Arms and Ammunition and registers connected there with;
J. To be in charge of outpost or beat and perform these duties when posted there;
K. Such other work as may be entrusted to him.
23.43 Head Constable (General)
(1) Head Constables are mainly employed to be in charge of general duty in police
stations, as officer in charge of outpost and guards and also in armed reserves, and
to be in charge of beat areas in rural and town police stations. He acts as S.H.O.
in the absence of Sub-Inspector and Asst. Sub-Inspector. He is authorised to hold
inquests and make investigation when asked by the Sub-Inspector to do so.
(2)		 General Duty Head Constable – Duties
A. To work with Constables and help them to understand instructions, catechism
and drill;
B. To perform duties allotted by S.H.O;
C. To be in charge of guard or escort when deputed;
D. To visit villages in the station jurisdiction when deputed for a specific purpose;
E. To work as in charge of a particular beat area;
F. To attend to court work under the orders of S.H.O.;
G. To investigate cases when deputed by the S.H.O. and to assist the I.O. in
investigation;
H. To conduct enquiries into petty complaints;
I. To take care of arrested persons kept in police station;
J. To take care of reception and proper behaviour with the persons coming to
police station and to attend telephone calls;
K. To be present in the police station in the absence of Sub-Inspector unless called
away in an emergency. He should take approval of S.I. before leaving the
station on routine duty.
(3) Station Writer
A Head Constable/Constable shall normally be assigned the duties of station writer.
He will perform the ministerial work of the station under the direction of S.H.O.
In the absence of S.I. or A.S.I. he will allocate urgent duties to the Constables and
be in charge of station property including Arms and Ammunition and carry out the
41

<!-- page 63 -->

Sikkim Police Manual

routine work of the station. He may also be employed by S.H.O. to go on night
rounds and may occasionally be kept in charge of beat area. He is also responsible
to watch the arrested persons kept in police station and proper reception to persons
visiting police station and also for answering telephone calls when S.H.O., S.I. or
A.S.I. are not present in police station.
(4) Head Constables as investigating assistants
The head constables form the main strength of investigating team. They assist the
team leader in the investigation of cases especially in preserving, and collecting
the clues like finger prints, foot prints, materials, photographs etc. and also in :
A. Collection of information;
B. Process service;
C. Pursuit of clues and arrest of accused and recovery of property;
D. Assisting in searches and seizures;
E. Surveillance of specially marked persons;
F. Holding inquests where directed;
G. Securing the presence of witnesses;
H. Court duty to assist prosecutor when S.I. or Inspector or ASI are not able
to be present;
I. Any other work connected with the investigation of crimes;
J. Submitting reports to S.H.O. on enquiries made by them.
(5) Head Constables (ASI) as officers in charge of beat
Head Constable or Asst. Sub-Inspector is generally assigned a beat. He shall, with
the help of Constables provided, be responsible in that area for :
A. Prevention of all offences;
B. Surveillance over criminals and bad characters;
C. Collection of information and intelligence, affecting crime, security and law
and order;
D. Service of beats by night and day;
E. Preventing and dealing with public nuisances, maintaining order and
incidence control;
F. Associating with Community Liaison Group and keeping the S.H.O. informed
of all happenings;
G. Discipline and conduct of Constables of his charge;
H. Conducting such enquiries as are entrusted to him.

42

<!-- page 64 -->

Volume II

(6) Head Constables (SI/ASI) as officer in charge of out post/Picket post
a. Sub-Inspector, ASI or HC may be kept in charge of outpost/picket post. The
duty of outpost/picket post in charge is to supervise the work of Constables in
his charge, see to the proper performance of all duties attached to the outpost/
picket post and maintain the prescribed records. He should submit a copy of
the outpost/picket post general diary daily to the mother police station.
b. The outpost/picket post in-charge is not a SHO. Therefore, whenever the
information of cognizable offence is received in the outpost/picket post, he
shall forward it to the mother station for registration of F.I.R. after issuing a
receipt for the same to the complainant. He will also enter the substance of the
report in the outpost/picket post general diary. However the complainant is
entitled for a copy of the FIR from the mother police station free of cost.
c. The in-charge of an outpost/picket post may without intervention of the SHO
take action in such of the offences as can be legally taken.
d. The in-charge of outpost/picket post shall on receipt of a complaint or
information of a crime or serious occurrence, take such immediate action as
may appear necessary i.e. proceeding and preserving the scene, rendering
medical assistance to victims, arrest of accused persons etc.
e. Men on duty in outpost/picket post should be treated on the same lines as
constables allotted to beat duty as far as tenure is concerned
(7) Station Charge
In the absence of the regular SHO, the senior-most police officer above the rank
of Constable present shall be deemed to be the officer in charge in the absence of
higher ranks as per section 2 (o) of Cr.P.C.
(8) Guard In charge
Whenever a guard is detailed for Treasury or Jail or for security of a minister of a
government, a Head Constable shall be kept in charge of the guard.
23.44 Constables (General)
(1) A Constable is one who has maximum interface with public. As the most accessible
person for public, he is expected to protect the needy, rescue people from danger,
apprehend offenders and assist in securing prompt help and justice. Some of
the important roles assigned to him are organising and securing community
participation, activating himself in prevention and detection of crime and
maintenance of law and order. Another main role of the Constable is, performance
of all tasks connected with beat area and thereby help in prevention of offences and
43

<!-- page 65 -->

Sikkim Police Manual

breach of peace. The constable on traffic duty has the task of regulating traffic. All
constables in their dealings with public should inspire confidence in the efficacy
of police to protect them. The police image is directly proportionate to their good
conduct and behaviour in the public as they are the persons who are basically and
directly in touch with them. At all costs they must avoid ill treatment either to the
victims or to the accused as a first step to build a better police image.
Duties of Constables
(2) The main duties of civil Constables are :
A. To perform duties in beats, patrols and pickets;
B. Surveillance over history sheeted and other potential criminals as per orders;
C. Collection of information and intelligence relating to crimes and criminals,
subversive, terrorist and anti social elements in their areas primarily and
communication of the same to the authorised superiors;
D. Developing cordial relations with local Community Liaison Group/voluntary
organisations and knowledge of households in the beat area;
E. Convey information relating to persons and events that cause or likely to cause
law and order situation or wide spread disturbances;
F. Keep in touch with local disputes, caste/communal overtones and inform SHO;
G. Assistance to investigating officers in the matter of arrests, recoveries, searches,
identification and securing of witnesses or verification of information;
H. Execute warrants and serve summons promptly;
I. Escort prisoners, arrested persons;
J. Escort injured or dead to the hospital;
K. Guard of prisoners in custody and all station property;
L. Help and assist in dealing with calamities like Landslides, Floods, Earthquakes,
Fires, Accidents, Epidemics, extremist/terrorist attacks etc. and put in
responsible efforts to save lives and property;
M. To perform allotted duties in Fairs, Festivals, Bandhs, Agitations, Riots, Large
assemblies, Elections, bandobust and security duties;
N. To preserve and guard the scene of occurrence until necessity ceases;
O. To behave courteously with all sections of public and treat poor people,
children, women, aged and all weaker sections of society with consideration,
sympathy and helpful attitude;
44

<!-- page 66 -->

Volume II

P. To be regular and punctual in his duties, catechism, physical training and
weekly parades;
Q. To work as data entry operators in Computers and in the areas of photography
etc. wherever they have necessary skill;
R. Make entries in the prescribed register and forms and maintain records entrusted
to him particularly those relating to beat area;
S. Any other duties allotted by SHO or other superior officers or elsewhere in
this manual.
(3) The entire preventive work of the police depends on the efficiency, commitment,
professionalism and integrity of the beat area policeman. The Constable allotted
to a beat should realize that his participation in the community even in a small
measure is essential for successful policing. Professionalism and integrity but not
power and authority shall command respect and bring in a large measure of cooperation from the general public.

45

<!-- page 67 -->

Sikkim Police Manual

46

<!-- page 68 -->

Volume II

Chapter 24

Police Station Records and Registers
24.1

Introduction

(1) Crime records are an integral part of criminal intelligence system without which
no police organization can function. It is therefore necessary that all information
relating to all crimes, criminals, properties and methods of commission of crime is
collected, recorded and used on a day-to-day basis. The complexities and new forms
of crime, coupled with the advancement in information technology, transport and
communications have given a new dimension to crime prevention and detection.
Effective anti-crime strategy of the police needs up-to-date data on crime, criminals,
properties and methods. The word properties should be understood in a wider sense
not only to include stolen properties but also immovable properties, articles, weapons
used etc. The Crime, Criminal Information System as evolved by NCRB applied to
local conditions and practices obtaining in the State should be the basis of all records,
registers, and forms to be maintained. Hence, proper maintenance of police station
records is a pre-requisite for the smooth functioning of a police station.
(2) Crime Criminal Information System aims at recording of all information regarding all
crimes, criminals, properties involved, methods employed, disposals etc. to enable the
police to prevent and detect offences and bring offenders to justice. It is particularly
necessary in respect of the persons who have a tendency to repeat the same crime or
some other crime. The system in its operation acts as a deterrence to potential and
existing criminals from leading a life of crime. It helps in keeping track of criminals
as also to know the antecedents of persons. It is, if properly maintained, a useful and
necessary tool as effective as any direct tools such as science and technology.
(3) The criminal records indicated below shall be maintained by all police stations. It is the
duty of a SHO of police station to ensure that these records are kept safely, properly, upto-date and do not deteriorate from mishandling, damp, vermin or other causes.
(4) Every police station register is required to be paged in English. No page should be
torn out of a register. Any correction required to be made should be made by drawing
a line through the mistake so as to leave the words erased and by writing the corrected
words afterwards or in the margin. A piece of paper should not be pasted over a wrong
entry/mistake. All entries should be neatly and clearly written and all the corrections
should be attested by the signature of the officer making them.

47

<!-- page 69 -->

Sikkim Police Manual

(5) The National Crime Code book circulated by NCRB and the Integrated Investigation
Forms devised by NCRB constitute the basis for maintenance of these records. The
upkeep of the records either manually or in a computerized system is the primary
responsibility of the police officers at all levels particularly the SHOs.
(6) The records should be maintained in the proforma devised for the purpose using the
software and loaded into the computer systems. The backup arrangements should
be ensured. Constant updating of the records should be done. The records indicated
below should be maintained manually until such time the entire CCIS data is safely
stored in appropriate computer systems in the State. The officers in charge of the
records should however enter the data in the computer system provided to them
while maintaining the important records manually.
24.2

Police Station Records & Registers
The following registers shall be maintained in all police stations and bear the
number as indicated below :



Register No. 1: First Information Report Book/Register
a.		 The first information report register shall be maintained in the prescribed Form
No. 87. It shall be completely filled before a new register is commenced. Cases
shall bear an annual serial number in each police station for each calendar year.
Every four pages of the register shall be numbered with the same number and
shall be written at the same time by means of carbon copying process or if
computerized signed in original on each day.
b.		 The FIR in original shall be sent to the magistrate having jurisdiction without
delay. One copy of the FIR will be retained in the station and one copy will
be sent to SP through SDPO. One copy of FIR shall invariably be given to
complainant free of cost, even if complainant does not ask for it.
c. If by mistake wrong entry in the body of FIR is made, then the said FIR
should be cancelled and next FIR form should be used.



Register No. 2: General Diary

(i) This is one of the important records of the police station. A general diary will be
maintained in every police station and outpost in Form 88. The SHO is responsible
for its up-to-date and accurate maintenance. In his absence one of the SubInspectors of police station present or ASI or general duty head constable will be
the in-charge of the General Diary.
(ii) A certificate to the effect that the General diary contains 200 pages will be affixed
by SHO on the general diary before it is commenced.
48

<!-- page 70 -->

Volume II

(iii) The General Diary will be maintained in two parts:

Part A: In this, the following information and related matters shall be entered :
The taking and handing over of charge by the officers maintaining
the Diary;
(b) The name of accused person with the details including whether in custody
or remand;
(c) Information regarding commission of non-cognizable offences including
reports of enmities likely to lead to the breach of peace;
(d) The Gist of FIR giving the number of FIR, gist of offence and section of
law under which the case is registered;
(e) The effecting of searches;
(f) The seizure of property suo-motto or u/s 93 Cr.P.C and its disposal;
(g) The effecting of arrests with or without warrants and the disposal of the
arrested persons;
(h) The receipt and manner of execution of Magistrate’s order u/s 154, 156 and
159 Cr.P.C and section 17 of the P.C Act, 1988;
(i) Every officer returning from any investigation shall record his arrival
regarding the investigation made, places visited, the details of property
seized and deposited in malkhana;
(j) All case property received or released from police station malkhana;
(k) All arrivals and dispatches from police stations of persons in custody and all
admissions to and removal from police station lockup, whether temporary
or otherwise;
(l) It is mandatory for SHO to check the malkhana and properties therein twice
a week and make a report of the same on the day after checking.
Part B: In this, routine entries like arrival and departure of patrolling staff,
policemen sent for process service duties, deployment of sentry, accused guard
duty etc. shall be made. In the rural or checkpost police stations only one General
Diary may be maintained considering the low crime rate in these police stations.
(a)

(iv) This register shall be maintained in duplicate by means of carbon copying
process. There shall be two copies. The original will remain in the police station
and the carbon copy shall be sent to sub-divisional police officer in charge of the
sub-division.
(v)

The opening entry of each day shall give the name of each person in custody, the
offence of which he is accused and the date and hour of his arrest. The last entry
of each day shall show the balance of cash in hand as shown in the cash register.
49

<!-- page 71 -->

Sikkim Police Manual

(vi) The General diaries may be destroyed five years after the date of last entry, after
express permission from the Superintendent of Police of the District.
(vii) The following instructions are issued for the maintenance of General Diary :
A. At 0800 hours, the Inspector or Sub-Inspector who is the SHO shall close the
previous day’s general diary and open the general diary for the day;
B. He shall scrutinize personally the cashbook, certify to their correctness;
C. He shall examine the vehicle(s), the POL, communication equipments,
telephones, fax, and other equipments and record the maintenance details and
damages if any. He should countersign the vehicle log books daily;
D. He shall scrutinize the diaries of each beat and note in the station GD any
important matter requiring attention;
E. He shall leave specific instructions for the next 24 hours in the general diary
and also where necessary, in the diaries of any beat or the outpost;
F. When detailing HCs and PCs for any duty, he should specify the time of their
departure and return to the station after assessing the time required for the duty
proposed to be performed;
G. Whenever he goes out, he should record the duty on which and the place to
which he is proceeding, and hand over charge of the GD to the SI or ASI or GD
HC as the case may be;
H. When the SHO goes out on any work including court work, he should, after
completing the work, return to the station and record in the general diary,
the work turned out by him. Whenever the SHO goes out, he should see that
his absence from the station is to the barest minimum, a necessity to ensure
efficiency and discipline in the staff;
I. HCs or PCs sent outside the town on duty should be issued with a command
certificate under the SHO’s own signature, specifying the work he is to perform
and the hour at which and date on which he is to return;
J. Whenever the SHO returns to the station, he should take follow up action as
per entries made in the general diary or beat diaries and record the fact of his
having done so therein;
K. The days, on which the SHO does not propose to check night patrols, he should
direct, through an entry in the station general diary, the next in command to
carry out the check.
(viii) Checking of General Diaries
The SDPO concerned is responsible for scrutiny of general diaries. This is an
instrument of information, record of work and events as well as of supervision.
Bearing this in mind the SDPO may make use of it to communicate his instruction
50

<!-- page 72 -->

Volume II

and comments through the Diary. He should in case of any instructions, return
the remarked diary in original to the SHO for his compliance and reply. After
the scrutiny, the diaries should be filed in his office by the SDPO and sent to the
District Police Office on the 20th of every month for record. Inspecting Officers
should go through the general diaries; see whether the scrutiny exercised by the
SDPO has served its purpose.


Register No. 3: Cognizable Cases Register/General Crime Register
A register in Form 89 shall be maintained for all cognizable cases reported in the
Police station. Similar register shall also be maintained in the office of SDPO
and SP. Any subsequent changes in the details initially entered therein shall also
be effected under the relevant columns therein as soon as such changes occur.
Column 8 shall be filled in with the remarks “charge-sheeted”, ‘final-reported’ or
“transferred to CB-CID’, etc. as the case may be.



Register No. 4: Unnatural Death case Register
A register in Form 90 shall be maintained in each police station of all such cases
where a person has committed suicide, or has died under circumstances raising a
reasonable suspicion.

 Register No. 5: Village Crime Note book
(1) To facilitate the study of crime and criminals, the Village Crime Note book shall be
maintained in five parts in all Police stations.
Part I - Crime: Occurrence and Classification Register (Crime Register)
(i)A. The Part-I (Form 91) of the Village Crime Notebook will be known as crime register/
crime occurrence and classification register. This register will be maintained in
parts corresponding to the revenue blocks under the jurisdiction of a police station.
A separate register shall be maintained for each revenue block or group of revenue
blocks as decided by District SP. All true cases of crime relating to theft including
of automobiles, automobiles accessories, burglary, snatching, robbery, dacoity, travel,
misappropriation, criminal breach of trust, cheating, extortion, cases under Arms Act &
Explosive Act, kidnapping, abduction, culpable homicide, organized crime, possession
& receipt of stolen property reported and registered in the police station including
attempts to commit these offences, should be entered in this register, in the order of
their occurrence chronologically, in the following manner.
B. In making entries in this register, the classification given in the National Crime Code
book should be followed. The major and minor heads referred to in the Crime Code
book should be entered in column 1 of this register, in addition to the other information
relating to crime number, sections of law etc. The method as described in the National
51

<!-- page 73 -->

Sikkim Police Manual

Crime Code book should be entered in column 4 of the register. The crime details
which are ascertained after preliminary investigation and which are incorporated in
the crime details form in Form 42 should be entered in column 4 along with the other
information. The details about the criminal or suspect should also conform to the
Codebook while making entries in the columns relating to accused or suspect.
C. The entries in this register should be made at every stage and the integrated investigation
forms filled up by the IO and sent to the DCRB.
D. The nature of property stolen shall be detailed in column (6). If it is not a conventional
property offence, the value or amount involved in cheating or misappropriation or
fraud or organized crime as the case may be has to be entered. In case of offences
against persons, the value of property involved and description thereof shall be noted.
It must be understood that all crimes involving property and all crimes against persons
involving monetary gain or loss are to be covered and recorded, apart from serious
offences of murder by organized groups. The classification as applicable to the entries
of each case shall be noted in column in the language indicated in the National Crime
Code Book. If any one case falls within two or three classifications all the classifications
applicable shall be noted. In column 4 any useful information shall be noted in respect
of the offence, including the offences against persons or any discovery made during the
investigation, including the names of the known or suspected accused, with grounds of
suspicion, any peculiarity in the commission of the offence, such as the use of fire-arms
or poison, and also the result of the case.
E. A few blank pages shall be reserved after the entries relating to each year, to post the
annual review and analysis of crime for the year. This analysis and review shall be
drawn up by the SDPO having jurisdiction.
F.

The word “Casual” shall be added in brackets in red ink for the entries relating to
offences committed by casual offenders.

G. Cases in which investigation is refused under section 157(1)(b) CrPC need not be entered.
H. At every stage of investigation, charge sheet or final report, court disposal, or appeal
when the integrated investigation forms are filled and sent to DCRB and SCRB this
register should also be suitably updated.
Annual Review of Crime
(ii) An annual analysis and review of crime shall be undertaken for each police station in
the jurisdiction covered by SDPO. The main objective of the review is to undertake
a critical analysis of all crimes that have occurred in the police station, the offenders
responsible, the activities of organized criminal gangs, or individuals responsible for
series of crimes, the quality of preventive action and investigations, the reasons for
any unusual outbreak, and the specific method of dealing with them.
52

<!-- page 74 -->

Volume II

(iii) The review should specifically cover :
A. Critical and thorough analysis of crime and criminals, suggestions and directions
to be pursued by the SHO and IOs;
B. Marked fluctuations of volume of crime and any special type of crime, special
outbreak of crimes, activities of specific categories of criminals or criminal
organisations, or organized crimes, terrorist crimes, affected areas, routes and
circuit of criminal groups/gangs;
C. The probability of crimes occurring in different areas and forming a series in the
area of the sub-division;
D. The quality of preventive action under the security sections, effectiveness of
beats and surveillance as well as the specific directions regarding the future;
E. Maintenance, accuracy updating and use of criminal records system and
information and criminal intelligence;
F. Application and results of use of scientific aids and fingerprints;
G. Cases charge sheeted / final reported after investigation, pendency in courts,
reasons for acquittals and measures for successful disposal of the pending cases.
(iv) The study should be thorough and methodical to discern patterns of organized crime
and other crimes.
(v) The annual crime reviews of the police stations should be sent to the SP. After
his approval of the reviews, these should be entered in Part I of the Village Crime
Notebook/Crime Register of the PS. This process should be done before the end of
January each year.
Part II - Crime Charts
(i) Part II shall consist of a crime chart or charts showing village boundaries and the
principal physical features of the station limits and of the adjoining areas to a distance
of 3 to 5 km outside the station limits. A broad classification of the offence and the
date of occurrence should be entered on the chart at the spot representing the scene
of offence using the abbreviated classification symbols given below for convenience.
One chart should be used for property offences and another for offences against
persons, if the incidence of crimes is too heavy in the police station.
1.
2.
3.
4.

Class I M - Murder for gain
Class I MF - Murder due to faction
Class I MP - Murder due to political rivalry
Class I MC - Murder due to communal or caste
53

<!-- page 75 -->

Sikkim Police Manual

5. Class I MD - Dowry death
6. Class I MT - Murder by terrorists or organised crime
7. Class I D - Dacoity
8. Class I R - Robbery
9. Class II A - House breaking by auger hole
10. Class II B - House breaking by hole in the wall near bolt
11. Class II E - House breaking through eaves (over wall and under roof)
12. Class II H - House breaking by man-hole in wall
13. Class II L1 - House breaking by breaking or opening block fastening
14. Class II L2 - House breaking by using key to open lock
15. Class II R - House breaking by making hole in roof or through the stair case
16. Class II T - House breaking by making hole under threshold
17. Class II W - Housebreaking by removing or bending window bars or removing
window frames
18. Class II M - House breaking miscellaneous
19. Class II S - Shop burglaries of all types
20. Class III A - Automobiles
21. Class III AP - Art pieces and Antiquities
22. Class III E - Electronic or Electrical goods
23. Class III V - Vessel thefts
24. Class III P - Pocket Picking
25. Class III SI - Snatching from children
26. Class III S2 - Snatching from sleeping persons
27. Class III S3 - Snaching other than from children and sleeping persons
28. Class III M - Thefts - not classified
29. Class IV cattle thefts
30. Class V - Receiving stolen property
31. Class VI C - Cheating
32. Class VI F - Forgery and or financial frauds
33. Class VI M - Misappropriation and criminal breach of trust
34. Class VII - Making or passing the coin and notes
35. Class VIII A - Abduction
36. Class VIII AR - Arson

54

<!-- page 76 -->

Volume II

37. Class VIII C - Communal/Religion
38. Class VIII CR - Cruelty by husband/relatives
39. Class VIII E - Extortion
40. Class VIII H - Hurt and grievous hurt
41. Class VIII I - Criminal Intimidation
42. Class VIII R - Rioting
43. Class VIII SC - Atrocity against Scheduled Castes and Civil Rights
44. Class VIII ST - Atrocity against Scheduled Tribes and Civil Rights
45. Class VIII W - Wrongful restraint
46. Class IX A - Adulteration
47. Class IX E - Environmental Crimes
48. Class IX F - Fire arms
49. Class IX I - Immoral Traffic
50. Class IX N - Narcotics
51. Class IX E - Explosives
52. Class X P - Preventive Detention
53. Class X S - Security for good behavior
(ii) The object of the station crime chart is primarily to show where crime mostly occurs.
The chart may be for a year, half-year, a quarter or a calendar month depending on
the volume of crime. The SHO may have more charts for different classes of crime if
the incidence in a PS is heavy to facilitate easy location.
(iii) A note giving the scale of the map, full moon dates, and dates of important festivals
and names of the villages shall be entered on the map.
(iv) A proper official map showing all physical features, villages, roads, river, jhoras, hills
etc. of the area covered by the PS including some parts of the neighboring police
station should be used for making entries.
Part III - General Conviction Register
(i) Part III of the Village Crime Notebook shall be maintained in Form 92. The names of
the following persons shall be entered in the register :
A. Persons convicted of all offences entered in part I;
B. Persons convicted of offences under Chapter XII and XVII of the IPC, for which a
punishment of three years and upwards is prescribed;
55

<!-- page 77 -->

Sikkim Police Manual

C. Persons convicted of offences under sections 489-A to 489-D of the Indian Penal
Code (forgery of currency notes and bank notes);
D. Persons notified under the Habitual Offenders Act, convicted under section 12 of the
Act and of any of the offences narrated in the schedule to the said Act;
E. Persons bound over under section 109 or 110 of the CrPC;
F. Persons convicted under the Telegraph Wires (Unlawful Possession) Act and other
special enactments like Immoral Traffic (Prevention) Act, 1986, Forest Act, Excise
Act and FEMA, if their finger prints have been ordered to be retained by SP;
G. Unconvicted persons reasonably suspected to have committed offences with
particulars of the offences, whose inclusion has been ordered by a SDPO. These
shall be retained only so long as reasonable suspicion exists against them.
Note: After the names of casuals, shall be entered, the word “Casual” in red ink.
(ii) Entries in this register shall be made in the chronological order of conviction and in
the case of suspects, in the order of the dates of the orders of Gazetted Officers.
(iii) This register will contain convictions in cases registered at the station and of persons
living in the station limits convicted elsewhere. It is very essential that the entries
relating to this are obtained and made. If a conviction is reversed on appeal, the entry
should be crossed out, unless the person is brought under (F) of sub-regulation (i).
(iv) The names of persons registered in Part III shall be deleted after a period of ten years
from the expiry of their last sentence of last conviction, provided the history sheet has
been discontinued for those persons having dossiers. Sub-Divisional Police Officers
may affect the removal. The SDPO may, however, sanction the removal of names
at any time within the period mentioned above, if the retention of such names is
considered unnecessary.
(v) Convicted persons in respect of that area shall be enquired about whenever a member
of the Station Staff visits the village. The SHO must make detailed enquiries about
each ex-convict twice a year during his visits to the village and if he was not able to
make enquiries about an ex-convict in a particular half year, he should do so as early
as possible in the next half year. All Police Stations and Investigating Units shall
maintain this record.
Bad Character Roll
(vi) When a person whose name is entered in General Conviction Register (Part III)
moves or changes his place of residence to the limits of another police station, the fact
shall be communicated to that station by means of a Bad Character Roll Form 93A
for entry in the register of that station. The roll will be returned with the page number
of the register, on which the entry has been made, noted thereon. This page number
56

<!-- page 78 -->

Volume II

will be noted in column 3 of the Station register. The transfer of information to the
concerned police should be prompt and authentic. The fastest method of means of
communication available should be used, preferably the fax mode of communication.
The acknowledgement should be insisted upon. This work needs personal pursuit by
the SHO. It should be remembered that if conviction particulars are not recorded
at the right place, the entire crime data system in the area and all over the country
will be distorted.
(vii) It is not necessary that Bad Character Roll Form 93A should be used for the
communication of conviction particulars or for the transfer of History Sheets.
These can be done through a memorandum in Form 94. It is likewise unnecessary
to send Bad Character Rolls with History Sheets submitted to superior officers for
orders regarding their retention or closure. Orders should be obtained on the History
Sheets themselves.
(viii) If any criminal of other PS limits comes to a particular PS, it should be intimated
through Bad Character Roll Form 93B to the PS concerned.
Death of Criminals who are registered in Part III of VCNB
(ix) When a person registered in Part III dies, his name shall be struck off from Part III
and other records. The fact of his death shall also be immediately communicated to
all other stations where he has been registered, so that entries regarding him may
be struck off the registers in those stations.
Part IV – Village History
(i)

Part IV of the Village Crime Notebook (Form 96) shall contain, all crimes occurring in
the village/town, notes on important factions and disputes, especially between castes
and communities, political groups, and the commission of serious breaches of peace
and records of police bandobust for important festivals, etc. Notes shall include :
•
•
•
•
•

Extremist activity - underground extremists and sympathizers hailing from the
village or locality etc;
Faction feuds - Groups/individuals involving in faction violence, important
faction leaders-details of criminal cases;
a) Communal activities - Name of members of such organizations;
b) Fundamentalist Organisations - Details thereof;
Political activities - Different political parties – activities – important leaders,
trouble mongers - criminal cases if any against them;
Property crime - important cases with details of gangs involved, arrested and
convicted, references to operations of suspected receivers of stolen property.
Repeat offenders to be short listed for opening sheets;
57

<!-- page 79 -->

Sikkim Police Manual

(ii)

58

•

Bodily Crime - Important Murder/Attempt to murder/Other serious rioting
cases. Repeat Offenders to be short listed for opening sheets;

•

White Collar Crime - List of NBFCs/BFCs which are not recognized by
Reserve Bank of India. Child adoption centers, Chit Fund Companies, Offenders
involving in forged degree or post graduation certificates, Man Power frauds by
agents etc;

•

Names of Rowdies/ Goondas/ Gangsters/ Bootleggers/ Narcotic offenders in the
village/ area/ locality;

•

Agrarian issues and disputes - Tribal/Non-Tribal issues. Agitations by farmersPolitical parties involvement, important disputes between the Mondals and
tenants or between tenants and action taken to stop them;

•

Industrial Problems - Trade Union Activities Strikes/Dharnas etc., Important
Union Leaders and their party of affiliations, Police bandobust done on
previous occasions;

•

Student Agitations - Organisations/Unions of a students, their affiliation with
political parties if any, Names of office bearers etc;

•

Agitations against government decision in respect of projects etc;

•

Other caste-based agitations;

•

Fairs and Festivals - Bandobust required, any specific problems experienced etc.

•

Elections - Panchayat, Municipal, Local Bodies, Legislative Assembly,
Parliament etc;

•

Any other matters of interest which the Superintendent of Police considers should
find entry with special references to local conditions;

•

Other issues having a bearing on L&O and crime.

In short, any information, which may be useful to a new Station House Officer,
having no previous experience of that station, should be entered in this register. One
or more sheets, as may be necessary, should be kept for station information of a
general nature. Information relating to different villages shall be recorded on separate
sheets, headed by the names of the villages. All entries in this record based on reports
submitted by beat PC or on his own shall be edited, signed and dated by the SHO. The
SDPO should also enter any matter, which he considers important. Only the station
copy of this record is to be maintained. The SDPO will not maintain a copy with his
sub-divisional records, but a summary of all important points shall be entered in the
Sub-Division Information Book maintained by him.

<!-- page 80 -->

Volume II

Part V - History Sheets
(i)

Part V consists of History Sheets (Form – 50 A, B & C) of persons residing permanently
or temporarily in the station limits, who are known or believed to be addicted to or
aid and abet the commission of crime, whether convicted or not, or who are believed
to be habitual receivers.

(ii)

All History Sheets shall be numbered serially in each police station.

Automatic opening of History Sheets
(iii) History Sheets shall be opened automatically at the time of conviction for persons
convicted as under and shall be retained for two years after release from jail.
Persons or crime for which convicted

Number of times convicted

Persons released from life imprisonment after
Conviction under Chapters XII and XVII of the IPC

}

Professional poisoners							Once
Members of organized crime syndicates and gangs

Drug Traffickers and Smugglers
Indian Penal Code sections 395 to 402

}

Indian Penal Code sections 392 to 394, if convicted
or liable to conviction under section 75 of the
Indian Penal Code

Twice

Illicit distillation							Once
House breaking							Twice
Trafficking women, girls and children

Once

Theft									Thrice
Cheating, forgery for gain, misappropriation and
breach of trust - if individuals						Twice

}

- if organised crime involving public funds

Once

Bound over under section 109						Twice
Bound over under section 110						Once
(iv) History Sheets should be opened for habitual offenders. For any violation with regard
to registration, change of residence or failure to report the habitual offenders are
liable for prosecution. The surveillance of the police is with a view to ensure their
compliance of the rules and to watch if they are reverting to crime.
59
