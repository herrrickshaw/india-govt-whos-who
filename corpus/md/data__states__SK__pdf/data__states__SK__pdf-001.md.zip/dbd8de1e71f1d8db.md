---
doc_id: "dbd8de1e71f1d8db"
source_url: "https://sikkim.gov.in/uploads/Gazette/363_20260715.pdf"
ministry: "Co-operation Department, Sikkim"
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f7e573f474b88f60"
---

<!-- page 1 -->

SIKKIM
GOVERNMENT

GAZETTE

EXTRAORDINARY
PUBLISHED BY AUTHORITY
Gangtok

Tuesday 14th July,

2026

No. 363

GOVERNMENT OF SIKKIM
HOME DEPARTMENT
GANGTOK
No. 70/Home/2026

Dated: 14.07.2026
NOTIFICATION

The warrant signed by the Hon’ble Governor on 7 th Day of July, 2026 is hereby
published for information of the general public.
WARRANT OF APPOINTMENT
By virtue of the power vested in me by section 6 of the Sikkim Lokayukta Act, 2014,
I, Om Prakash Mathur, Governor of Sikkim do hereby appoint Ms. Sarala Rai, Retired Secretary
to the Government of Sikkim as Member [Administrative] of the Sikkim Lokayukta with effect
from the date she assumes charge of her office.
Given at Lok Bhavan, Gangtok, Sikkim on this 7th day of July, in the year 2026, of the
77 year of Republic of India.
th

R. Telang, IAS
Chief Secretary
Government of Sikkim
File No. Home/Confdl/141/2014/2

S.G.P.G. -363/ Com. 15/Gazette /13 Nos./ Dt:- 14.07.2026

-1-
