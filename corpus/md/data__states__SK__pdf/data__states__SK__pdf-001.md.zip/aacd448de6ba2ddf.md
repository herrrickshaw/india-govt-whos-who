---
doc_id: "aacd448de6ba2ddf"
source_url: "https://rmdd.sikkim.gov.in/storage/notification/notificationdoc-WaPlLX4xOQNAgtXRKyO1uLX6QapYaZGkxojlvoRd.pdf"
ministry: "Rural Development Department, Sikkim"
title: "Office Order"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2bdcc4532e130a2f"
---

<!-- page 1 -->

2025

Internationgl Year
of Co

erotives

RURAL DEVELOPMENT DEPARTMENT
GOVERNMENT OF
SIKKIM

O.0. No: 325 / RDD

Dated: 8 | 05 / 2026.

OFFICE ORDER
Mr. Norgay Lepcha, Sr. VAA under BACPassingdang, RDD is hereby
re-employed
for a period of 1 (one) year beyond the age of superannuation with effect from
the date
of joining duty in terms of Rule 102 of the Sikkim Government Service Rules, 1974.
By Order.
Sd/

(TSHERING LHADEN LACHUNGPA)
SPECIAL SECRETARY

RURAL DEVELOPMENT DEPARTMENT.
Memo No: 1351 -1356/ RDD.

Dated: OS /05/2026.

Copy to:
1. Mr. Norgay Lepcha
2. Director (Finance & Accounts), RDD
3. ADC(Dev.), Mangan, RDD

4. BDO, Passingdang BAC
5. Dy. CP & AO, Mangan
o Assistant Director (IT), CMO
Personal &
Guard file.

UNDER SECRETARY (ADM)

RURAL DEVELOPMENT DEPARTMENT

E
A
