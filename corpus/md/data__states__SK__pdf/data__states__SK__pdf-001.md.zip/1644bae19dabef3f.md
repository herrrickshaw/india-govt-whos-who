---
doc_id: "1644bae19dabef3f"
source_url: "https://sikkim.gov.in/uploads//Notifications/notice_tribalaffair_34_20261014.pdf"
ministry: "Co-operation Department, Sikkim"
title: "Notice issued by Social Welfare Department  -RefNo: 106/SCH/SWD/2026 | Date:13 10 2026   -Information & Public Relations Department   New"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "910562c926aa4ae5"
---

<!-- page 1 -->

Pee
SOCIAL WELFARE DEPARTMENT
GOVERNMENT OF SIKKIM.
TADONG, GANGTOK DISTRICT.
‘No: 106/SCH/SWDR202%6.—S~*~*~*~*~C:SS™SCSSSCS ated: 13102026
NOTICE

‘The Ministry of Tribal Affairs, Government of India, has issued directions vide
letter No :F.No.19012/06/2019-Sch (Part -1) for clearance of pending scholarship
disbursement cases under the Pre-Matric and Post-Matric Scholarship Schemes for
Scheduled Tribe students for the academic years up to 2025-26.

It has been observed that a number of cases remain pending for disbursement
due to non-seeding of Aadhaar number with the applicants’ bank account.

Therefore, such applicants having non-seeding of Aadhar number with bank
account are hereby directed to complete the Aadhaar seeding process on or before
30th October 2026, Failure to comply within the stipulated timeline shall result in
non-disbursement of the scholarship, and no further requests or claims in this regard
shall be entertained by the Department thereafter.

The list of pending applicants is available on the official website:
https://socialwelfare.sikkim.gov.in/visitor/notification,

By Order

Aa
Special Secrptary
Social Weare Department
Government of Sikkim.
. Chettri (scs)
Social ‘Gow. ‘of SikKI
