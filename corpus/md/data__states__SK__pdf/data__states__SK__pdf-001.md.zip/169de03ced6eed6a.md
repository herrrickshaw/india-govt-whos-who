---
doc_id: "169de03ced6eed6a"
source_url: "https://culture.sikkim.gov.in/storage/notification/notificationdoc-eiWnYU1Qw0WDAfexZq4cYaGM9JYMKMQIIzTO7uNX.pdf"
ministry: "Cultural Department, Sikkim"
title: "Empanelment of Contractors"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "65a2a2db96bdf3b9"
---

<!-- page 1 -->

‘ J
Empanelment of Contractors/Construction ie ;
‘The Culture Department invites ti
Contractors/Construction Firms to provide construct
in " ¥ oe aie ti
Bist é egnerinanan
