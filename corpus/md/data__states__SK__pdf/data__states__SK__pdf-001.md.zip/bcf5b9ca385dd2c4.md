---
doc_id: "bcf5b9ca385dd2c4"
source_url: "https://power.sikkim.gov.in/storage/circular/circulardoc-AgL7QLOO9urwUdan1Pskkv7oty9sCYUl8GeXAcMo.pdf"
ministry: "Energy and Power Department, Sikkim"
title: "Advertisement & Form Chairperson SSERC"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e66d260c5eb5dfb1"
---

<!-- page 1 -->

No: 3.9

IPowerlAdm

POWER DEPARTMENT,
GOVERNMENT OF SIKKIM, GANGTOK

Dated: Ls/06/36

Advertisement for filling up 1 (one) post of Chairperson, Sikkim State Electricity Regulatory
Commission (SSERC)

In accordance with sections 84, 85 & 89 of the Electricity Act 2003, the Government of Sikkim invites
applications for 1 (one) post of Chairperson , Sikkim State Electricity Regulatory Commission (SSERC) from
persons who meet the following criteria:

1. Interms of Section 84 (1) of the Electricity Act,2003, in order to be appointed as the Chairperson of the Sikkim

State Electricity Regulatory Commission (SSERC), the applicant should be aperson of ability, integrity ,and

standing, having adequate knowledge of, and have shown capacity in ,dealing with problems relating to

engineering ,finance, commerce, economics, law or management. The person should not have any financial

or other interest with any corporate entity dealing with Generation, Transmission, Trading and Distribution of
electricity in Sikkim, which is likely to affect prejudicialy his or her function as a Chairperson of the
Commission. The person must give a certificate to this effect while applying for this post.
2. In terms of the provision in Section 89 of the Electricity Act,2003, the Chairperson shallhold office for a term
of 5 (five) years from the date he/she assumes Office or till helshe attains the age of 65 (sixty five) years,
whichever is earlier.

3. The salary, allowances and other terms and conditions of service of the Chairperson shall be governed by the
Sikkim Electricity Regulatory Commission (Salary, Allowances and Other Terms and Conditions of Service of

the Chairperson) Rules,2011 read with the Sikkinm Electricity Regulatory Commission (Salary, Allowances

and Other Terms and Conditions of Service of the Chairperson) (Amendment ) Rules, 2019.
4. The Selection Committee constituted vide Notification No. 19/Power2021 in accordance with the provisions
of the Electricity Act, 2003 for purpose of making the selection to the aforementioned post, reserves the right

to consider and recommend any other person fulfilling the criteria laid down in the Act for the post of the

Chairperson apart from those who have applied against this advertisement. The Head Quarter of the Sikkim

State Electricity Regulatory Commision is in Deorali, Gangtok.
5. The interested persons may send their applications neatly typed in English and duly signed along with self
attested copies of certificates/documents in respect of proof of age, basiclessential qualifications, experience
and 'No Objection Certificate' from the concerned organization, where already enmployed . by Registered Post
or in person in asealed cover superscribed "Application for the post of Chairperson, Sikkim State Electricity
Regulatory Commission" to Shri. Bikash Deokota, Secretary, Power Department, Government of Sikkim,

Gangtok-737101,Sikkim by 4 P.M of 14th July,2026.

6. Applicants in Government Service should apply through proper channel.

7. The advertisement along with the application format and undertaking can be downloaded from the Power

Department's official website- power, sikkim.gov.in (under the section -more menu-latest updates)

Joint Sacretary

Power Department

Government of Sikkim

Gangtok

Joint Secretary

Copy for information to

1. Secrelary, Power Department, Gos.

2Joint Director (IT)-may upload the details on the website, pls.
3. File and G/File copy.

Power Departmernt
Govt. of Sikkim

<!-- page 2 -->

FORMAT OF APPLICATION FOR THE POST

OF CHAIRPERSON, SSERC

Name

1

2. Age on 01.06.2026 and Date of birth

3. Present post held
4

Details of posts previously held and
experience in any of the field of law,
economics, commerce, finance, law

or management.
5. Wlingness leter to resign from the
present post if selected for the post

of Chairperson,SSERC

6

A letterlcertificate intimating the details

of any office, employment or consultancy
agreement or arrangement which he/she

has in his/her names or in the name of his/

her relatives, carrying any or allthe following
areas of business, viz

a) Generation, Transmission, Distribution

or Supply of electricity.
b) Manufacture, sale or supply of any fuel

for generation of electricity.

c)

Manufacture,sale, lease, hire supply of

or dealing in machinery, plant, equipment,
apparatus or fittingness for the generation,

transmission, distribution, supply of electricity.

d) Any entity providing professional services to
any of the business as referred to above
e) Past administrative knowledge and experiences.

SIGNATURE

Date

NAME:
Note

:1) Please attach two copies of your recent passport size photograph along with photo copy of
your Photo ID.

2) Please attach extra sheets and copies of supporting documents to substantiate your claims
made in this application.
3) Please attach NOC from your present employer if already in Government Service

<!-- page 3 -->

Declaration
As required by the advertisement dated

invitingapplication for the post of

Chairperson,Sikkim State Electricity Regulatory Commission (SSERC), Iwould like to hereby declare that

I do not have any employment or consultancy agreement or arrangement in my name or in the name
of my relatives,carrying on any or all of the following areas of business namely:

(a) Generation, Transmission, Distribution of Supply of Electricity.
(b) Manufacture, sale or supply of any fuel for Generation of Electricity.
(c) Manufacture, sale, lease, hire supply of or dealing in machinery, plant, equipment, apparatus or

fittingness for the Generation, Transmission, Distribution, Supply of Electricity
(d) Anyentity providing professional services to any of the business as referred to above
Ifurther declare that

Ido not have any financial or other interests which is likely to affect prejudicially my

(ü)
(ii)

Place:
Date:

function/role as the Chairperson of SSERC in the event of my selection
Ihave no any vigilance caselenquiry against me
The information and details furnished by me in my application for the post of Chairperson is

correct to the best of my nowledge and belief and nothing has been suppressed

(Signature)

Name and Address
