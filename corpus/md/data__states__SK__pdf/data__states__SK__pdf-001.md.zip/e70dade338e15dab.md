---
doc_id: "e70dade338e15dab"
source_url: "https://rmdd.sikkim.gov.in/storage/notification/notificationdoc-SgSMsAmKcEKbyKuuowl3kT8ouC3JacpUOJycsvND.pdf"
ministry: "Rural Development Department, Sikkim"
title: "Office Order of Mr Palchen Chedup Lepcha compassionate appointment"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fe2cff4395cc2776"
---

<!-- page 1 -->

N

Va

RURAL DEVELOPMENT DEPARIMENT
(GOVERNMENTOF
SIKKIM

0.0. No:260

Datedt1L21026.

RDID.
OFFICE ORDER

In terms of

Notification No. J(47)385/GEN/DOP -PT-I1 dated 5/5/201 1, Mr. Palchen

Chedup Lepcha, s/o of late Tashi Samten Lepcha is hereby appointed as Plumber under BAC

Mangan,RDD on compassionate ground on a monthly pay of 19,400/- at Level -5 at Cell-I of

the Pay Matrix under Sikkim Government Service (Revised Pay) Rules. 2018. The other terms &

conditions of her appointment will be as laid down in the Mermorandum No. 503/RDD
dated: 10 /7/2026.

He is hereby placed on probation for a period of one year.

In terms of Notification No. 489/GEN/DOP dated 31/10/2011, during the period of
probation, he willdraw aconsolidated allowance of * 10,000- p.m with effect from the date of the
joining.

He shall look after the family members who were dependent on the deceased Government

servant. In case it is reported and proved at any point of time that, such family members are beino

neglected or not being properly maintained, his appointment will stand terminated.

On successful completion of his probation period-vis-å-VIS Confirmation of service. he will

draw basic pay of 19,400/-p.m at Level -5 at Cell-l of the Pay Matrix under Sikkim Governme
Service (Revised Pay) Rules 2018. plus other such allowances as admissible under the nule
The expenditure will be met from the budget Head 2501.01.001.47.72.01 salaries

This Office Order is hereby issued with the approval of the Competent Authority.
Sd/
(ANIL RAJ RAI) IAS
SECRETARY

RURAL DEVELOPMENT DEPARTMENT.
Memo No.

3164

/RDD

Dated27/2026.

Copy to:

1. Mr. Palchen Chedup Lepcha

2. ADC(Dev.) Mangan
3. Joint Secretary, DOP
A Joint Director, IT, RDD

5. BDO Mangan BAC
6. Dy.CP & AO North Mangan
File &
Guard file.

Deputy Secretary (Adm)

Rural Develepment Department.
