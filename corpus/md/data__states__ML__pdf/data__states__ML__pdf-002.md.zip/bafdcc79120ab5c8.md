---
doc_id: "bafdcc79120ab5c8"
source_url: "https://msrls.nic.in/sites/default/files/notification-final-result-post-project-manager-livestock-fisheries-enterprise-development-finance..pdf"
ministry: "Meghalaya State Rural Livelihoods Society, Meghalaya"
title: "Notification: Final Result for the Post of Project Manager - Livestock & Fisheries, Enterprise Development & Finance"
date: ""
pages: 2
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "e1f569f4a0448ad8"
---

<!-- page 1 -->

jot
MEGHALAYA STATE RURAL LIVELIHOODS SOCIETY tet
(The Nodal Agency of Govt. of Meghalaya for Implementing NRLM, Ministry of Rural Development Govt. of India)
Montfort Building, 2-4 Floor, Dhanketi. Shillong-793001
i: msrts2011@ gmail.com & msris.nic.in 3 -0364-2502130
MSRLS/SMMU/HR/S-REC/VOL-18/2380/26-27/ 524% Dated: Shillong the 15 Sept, 2026
NOTIFICATION

m pursuance to the Recruitment Notification No. MSRLS/SMMU/HR/S-REC/VOL-
18/2380/26-27/4977 Dated: Shillong the 26% August, 2026 and no. MSRLS/SMMU/HR/S-
REC/2380/26-27/4696 Dated: Shillong the 10% August, 2026, with regards to the Personal
Interview for the post of Project Manager - Livestock & Fisheries (PM-LF), Project Manager-
Enterprise Development & Finance (PM-EDF) and State Accountant at State Mission Management
Unit (SMMU) under the Meghalaya State Rural Livelihoods Society (MSRLS), the result of the

recruitment for the above mention post, is hereby declared and is given in Annexure-I (enclosed).

The selected candidates are directed to report to the State Mission Management Unit
(SMMU) Shillong between 24% to 30% September, 2026 for signing of the Agreement of
Appointment. The candidates must complete the Police Verification and obtain the Medical Fitness
Certificate issued by a Competent Authority of the Health Department, Government of Meghalaya,
to be submitted at the time of signing of the Agreement. Issuance of the Appointment Order shall
be subject to clearance of the Police Verification and the Medical Fitness Certificate.

RAL f,
a On
Z NS
o; ‘Q
Sf sro sas \* Chief Operating Officer
5 PSL oM py Chief Ope tae Fl Livelihood Society
S, fe) Meghalaya S' none
> Y
s
MSRL ‘/VOL-18/2380/26-27/S24%-® Dated: Shillong the 15+ Sept, 2026
Copy to:
1, The Secretary, C&RD Deptt., GoM and Chief Executive Officer, MSRLS, for kind
information.
2. The Chief Operating Officer — Livelihoods Promotion, MSRLS, for kind information.
3. The Finance & Administrative Officer-MSRLS for kind Information.
4. All the State Mission Manager ~ MSRLS, for kind information.
5. The Project Manager-KMC, SMMU MSRLS, for kind information and necessary action.
6. All SMMU, DMMU and BMMU staff for kind Information.
7. SMMU, Notice Board and MSRLS Website, for kind information.
8. The candidate concerned, for kind information and necessary action.
a.
Chief 0} iting Officer,
Meghalaya State Rural Livelipap@yfioelety.
Chie , aon tee Society
ja Stale
Meghaleye 21° siltong 2

<!-- page 2 -->

[bo°
Pe fee bed & —s om
GOVERNMENT OF MEGHALAYA i 5
MEGHALAYA STATE RURAL LIVELIHOODS SOCIETY = * "©
(The Nodal Agency of Govt. of Meghalaya for Implementing NRLM. Ministry of Rural Development, Govt. of India)
Montfort Building, 2" Floor, Dhanketi, Shillong-793001
(&: msris2011@gmail.com &: msts.nicin 8 -0364-2502130
MSRLS/SMMU/HR/S-REC/VOL-18/2380/26-27/ 524% Dated: Shillong the 154 Sept, 2026
Annexure-I:
A. Selected Candidates for the of Post of Project Manager - Livestock & Fisheries:
La)
2 | 1400001 ADELENE BASAIAWMoIT | Recommended for the post of
DFS-FLP
B.
ce eee
2100004 BIDAMON NONGTDU Heetamnendes fon.tite postot
C. Selected Candidates for the of Post State Accountant:
| sw | RIGISTRATION.NO | NAME OF THE CANDIDATES
1300020 MESHANDABOR KHARMALKI
1300026 RAPBORLANG GIROD LAWAI
URAL a
mee Lv a
¥, N® Chief Operafihg Officer,
alaya State Ri i .
Ky 3 — Chiet ratiepetttestety iety
S| fst: 13.23, 2013 | . { Livelinood Soc
3 is Meghalaya State Rut?
Ks 6S 2 shitlong
i cy
e “LY
SHITE
