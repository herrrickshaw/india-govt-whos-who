---
doc_id: "85dad02d84cadfad"
source_url: "https://gad.meghalaya.gov.in/assets/docs/tenders_2025/corrigendum.pdf"
ministry: "General Administration Department, Meghalaya"
title: "Corrigendum"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5dd8f1fe970e0384"
---

<!-- page 1 -->

o2,'d o

GOVERNMENT OF MEGHALAYA
GENERAL ADMINISTRATION (A) DEPARTMENT
Dated Shillong the 28tt, August, 2025

No. GAA 25 I 2076 lPt.II / 48

CORRIGENDUM

In partial modification of this Department's Notification No. GAA
25l2016lPt.l24l dated 12tt,Augt-rst,2025, the last date & time for submission of
Bids is extended up to 8th September, 2O25 till L1:OO A.M. Other particulars
remain the same.

sd/ Commissioner & Secretary to the Govt. of Meghalaya,
General Administration Department.
Memo No. GAA 25 I 2076 lPt.II I 4B-A
+Coou to:-

Dated Shillong the 28tt, August, 2025

/'

,/
-v/ fne State Informatics Officer, National Informatics Centre, Meghalaya,
Shillong for uploading the Corrigendum in the Department website
gad.meghalaya.gov.in (soft copy enclosed in CD).
By Order etc.,

Deputy Secretary to the Govt. of Meghalaya,
General Administration (A) Department.

L^

E*$$

sTi*

2 z .: o
,', b o z
5.oEo
400ir
