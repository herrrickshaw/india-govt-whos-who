---
doc_id: "efc52e249b31bbab"
source_url: "https://shillongpolice.gov.in/Acts_Rules_Meghalaya/01_Meghalaya_Prevention_Gambling(Amendment)_Act_1976.pdf"
ministry: "East Khasi Hills District Police, Shillong, Meghalaya"
title: "Meghalaya Prevention Gambling (Amendment) Act 1976"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "eeb456333caa47fa"
---

<!-- no text layer: pending OCR -->
