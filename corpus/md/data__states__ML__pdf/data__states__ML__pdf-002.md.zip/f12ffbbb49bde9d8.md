---
doc_id: "f12ffbbb49bde9d8"
source_url: "https://gad.meghalaya.gov.in/assets/docs/tenders_2024/NOTICE%20Pre-bid%20Queries.pdf"
ministry: "General Administration Department, Meghalaya"
title: "EOI for Purchase of land in Bangalore Urban District (Karnataka) by the Government of Meghalaya for Setting up of Meghalaya State House"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "424b79c0f2a8e1d6"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
GENERAL ADMINISTRATION (A) DEPARTMENT
No. GAA 80/2013/30

Dated Shillong the 15th March, 2024

EOI for Purchase of land in Bangalore Urban District (Karnataka) by the
Government of Meghalaya for Setting up of Meghalaya State House

In pursuance to EOI No.

80/2013/24 dated 20-02-2024, the Department had

received queries as on 06th March 2024, the last date for submission of pre-bid
queries. The responses to the pre-bid queries are as follows:
Sr.

Pre-bid queries Received

No.
1.

Response

The land required size given in the

Applicants who own land parcels

document is

greater than 8000 sq. mts. in size may

5000 sq mtr

also apply in the tender upto a ceiling

8000 sq mtr

of 12000 sq. mts.

So around 54000 sq ft minimum size
I have few lands.

As such, the term “8000 sq. mt.” shall

In one, it is slightly more than 8000 sq

be read as “12,000 sq. mts.” in the EOI

mtr.

document.

So can I also apply with that land also?
Or the maximum allowed is 8000 sq
mtr only.
2.

Other documents are all upto date and



An evaluation Committee will be

I am submitting with the bid. Once

notified by the Government of

selected, we can show the originals for

Meghalaya and may comprise of

verification. Do we need to come down

representatives from the General

to Shillong for the same?

Administration Department,
Tourism Department, Finance
Department, Law Department,
Planning, Investment Promotion &
Sustainable Development
Department and other
departments as required.


The Evaluation Committee shall
undertake the verification of prequalification criteria as specified
in Clause 3 and undertake the

<!-- page 2 -->

Evaluation of the Bids as specified
in Clause 6 of the EOI on behalf of
the General Administration
Department, Government of
Meghalaya.


The Evaluation Committee may
seek clarifications from the
Applicants which may include
intimating the Applicants to travel
to Shillong.



Further, the Evaluation
Committee shall deploy
authorised personnel to conduct a
physical verification of the land
parcels for which the Applicants
shall be intimated in advance to
provide necessary assistance in
the physical verification process.

3.

Any other evaluation criteria I need to

Applicants who own land parcels

be aware.

greater than 8000 sq. mts. in size may
also apply in the tender upto a ceiling
of 12000 sq. mts.
As such, the term “8000 sq. mt.” shall
be read as “12,000 sq. mts.” in the EOI
document.
All other terms and conditions remain
unchanged.

All other terms and conditions remain unchanged in the EOI document.
Sd/Secretary, General Administration Department,
Government of Meghalaya
