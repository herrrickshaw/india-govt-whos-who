---
doc_id: "cb78adefbc07206a"
source_url: "https://invest.meghalaya.gov.in/Documents/Notifications/Na2.pdf"
ministry: "Meghalaya Investment Promotion Authority (MIPA)"
title: "NA2 notification from Urban Affairs Department [No DUA(U)R/13/2019/307-B]"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7146897cd7469b1e"
---

<!-- page 1 -->

f;fJVf.:M.N~U:J'lli'TUF MF.GIIALAVA
IJIMf.:f'"TClk.ATf.: CU: Uk.HAN Af'FAIM:~::Mt:C;!IAl,AVA::,1tlU.()'11(,

No OUA(U)Rl131201WJ07•B
From

Daled - JO" 0c:100el' 202,

SM P Kr Boro (MCS)
Owector, Urb•n Affait1
Ma,gh•l•y• Shilong

To
The Deoufy Seaet•f'f OPIIT
Room No 20-4 V•nlfYa Bhawan
New Delhi· 110011
Sue,,ect Reform ro tie lmpktmented under Buu,ns Reform Action PIM! 202, as pet N
mandate O'/ DPIIT Ministry of Cornmetce & Industry GoYernrnent of lnd1a
Rei

No OUA(U)R/1~191307

Dated - Ir/' October 202,

In contInuatJOn to 1h11 offce lene, unoe, refetence 1roe folowing reforms unoe,
~ s Reform Action Plan 2024 shall be con1o1C1e,ed 'NA2" for !he State of Meo;ttalaya as tntS
reform 11, not applicable as tne Slate ,s under Scheduled Vl area

.. "'""""'

Regillrat,on

Mandate to Pubbh an onbne dashbow in p,.ibbc domain wrtn folowlng
featJSH
1 Clearly pu0111n tt'le data on number of apphcatJOns received and
granted time taken •nd lee incUfled 10 grant app,ovalslc«ttfa!e
• H,ghlign1 lhat the Gasnboara is updated preferably on ru time Of
upaated regularly (datlytweeltt',ltonn,gnuylmontl'llyJ Oa1e ana time cf
~ 1nformat10t1
~ation may tie ment.K>ned_
Youn tarthfully

;i-

DHctor. Urban Affaq
Megh1J1ya 5n11ong
Memo No 0UA(U)R/13'201!ilrl307-C
Copyto

Oat.a - W' OctObef 2024

JOlnl Secr-.ry 10 the GoY«'rrnent of ~alaya, ~ A h . r s ~
SeniQ! Monitoring Off'N:»t & ex-officio Pltnning, tnv•tn-.ni Promotion & Sustail'\Glle
[)evelop,ne:nt ~ . Government of Meghalaya

/l,
Ottector,lh~Att•irs
~l'lalayaShllong
