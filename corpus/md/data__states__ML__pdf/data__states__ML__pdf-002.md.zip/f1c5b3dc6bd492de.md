---
doc_id: "f1c5b3dc6bd492de"
source_url: "https://mudashillong.gov.in/documents/DAY-NULM_Guidelines/SEP_Guidelines.pdf"
ministry: "Meghalaya Urban Development Agency (MUDA), Meghalaya"
title: "Self-Employment Programme (SEP)"
date: ""
pages: 36
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0f9f07f90e6a3601"
---

<!-- page 1 -->

Self Employment
Programme
(Operational Guidelines)

National Urban Livelihoods
Mission

lR;eso t;rs

Government of India
Ministry of Housing & Urban Poverty Alleviation
Website: http://mhupa.gov.in

lR;eso t;rs

Government of India
Ministry of Housing & Urban Poverty Alleviation
Issued in December 2013

<!-- page 2 -->

<!-- page 3 -->

F. No. K-14014/58(10)/2012-UPA
Government of India
Ministry of Housing & Urban Poverty Alleviation
(UPA Division)
Nirman Bhawan, New Delhi
Dated: 18th December 2013
OFFICE MEMORANDUM
SUBJECT: Operational Guidelines for the Self-Employment Programme (SEP) under the
National Urban Livelihoods Mission (NULM)
The guidelines for the National Urban Livelihoods Mission (NULM) have been issued vide
OM No. K-14011/1/2013-UPA dated 24th September 2013.
2.
The operational guidelines for the Self-Employment Programme (SEP) component of NULM
are annexed herewith, which will be followed by all the implementing agencies. These guidelines
have also been uploaded on the website of the Ministry of Housing and Urban Poverty Alleviation,
and may be accessed from: http://mhupa.gov.in/NULM_Mission/NULM_Mission.htm.
3.
This issues with the approval of Hon’ble Minister for Housing & Urban Poverty Alleviation,
Government of India.

(B. K. Agarwal)
Joint Secretary to the Government of India
Ministry of Housing & Urban Poverty Alleviation

<!-- page 4 -->

<!-- page 5 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

Table of Content

1.

Introduction ......................................................................................................................1

2.

Selection of Beneficiary....................................................................................................1

3.

Educational Qualifications and Training Requirement:..............................................2

4.

Pattern of Financial Assistance: ......................................................................................3

5.

Procedure for interest subsidy:........................................................................................3

6.

Sub-Component 4.1-Individual Enterprises (SEP-I)-Loan & Subsidy......................3

7.

Sub-Component 4.2-Group Enterprises (SEP-G) -Loan & Subsidy ..........................4

8.

Procedure for Sponsoring of Applications: ...................................................................5

9.

Task Force at ULB Level...................................................................................................6

10.

Linkage with Credit Guarantee Scheme(CGS) of Ministry of Micro Small & Medium
Enterprises (MSME).........................................................................................................7

11.

Progress Reporting for SEP-I & SEP-G..........................................................................7

12.

Sub-Component 4.3- Interest Subsidy on SHG Loans (SHG-Bank Linkage) ..........8

13.

Sub-Component 4.4- Credit Card for enterprise development................................10

14.

Sub-Component 4.5–Technology, Marketing and Other Support...........................11

15.

Funding Pattern .............................................................................................................12

16.

Monitoring and Evaluation ...........................................................................................12

Annexure - I ..............................................................................................................................13
Annexure - II ............................................................................................................................15
Annexure – III............................................................................................................................18
Annexure - IV ...........................................................................................................................23
Annexure – V .............................................................................................................................26
Annexure – VI............................................................................................................................28

3

<!-- page 6 -->

<!-- page 7 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

1. Introduction
1.1. This component will focus on financial assistance to individuals/groups of urban poor
for setting up gainful self-employment ventures/ micro-enterprises, suited to their skills,
training, aptitude and local conditions. The component will also support Self Help
Groups (SHGs) of urban poor to access easy credit from bank and avail interest subsidy
on SHG loans. The component will further focus on technology, marketing and other
support services to the individuals, group entrepreneurs, SHG members and Urban street
vendors/ hawkers engaged in micro enterprises for their livelihoods. The component will
also facilitate credit cards for working capital requirement of the entrepreneurs.
1.2. The underemployed and unemployed urban poor will be encouraged to set up small
enterprises relating to manufacturing, servicing and petty business for which there is
considerable local demand. Local skills and local crafts should be particularly encouraged.
Each Urban Local Body (ULB) should develop a compendium of such activities/projects
keeping in view skills available, marketability of products, costs, economic viability etc.
1.3. The percentage of women beneficiaries under SEP shall not be less than 30 percent. SCs
and STs must be benefited at least to the extent of the proportion of their strength in
the city/town population of poor. A special provision of 3 percent reservation should be
made for the differently-abled under this programme. In view of the Prime Minister’s
15-Point Programme for the Welfare of Minorities, at least 15 percent of the physical and
financial targets under this component shall be earmarked for the minority communities.
2. Selection of Beneficiary: The Community Organisers (COs) and professionals from Urban
Local Body (ULB) will identify the prospective beneficiaries from among the urban poor.
The community structures formed under Social Mobilisation & Institutional Development
(SM&ID) component of NULM viz: Self Help Groups (SHGs) and Area Level Federations
(ALFs) may also refer prospective individual and group entrepreneurs for purpose of
financial assistance under SEP to ULB. The beneficiaries may directly approach ULB or its
representatives for assistance. Banks may also identify prospective beneficiaries at their end
and send such cases directly to ULB.

1

<!-- page 8 -->

National Urban Livelihoods Mission
lR;eso t;rs

3. Educational Qualifications and Training Requirement: No minimum educational
qualification is required for prospective beneficiaries under this component. However,
where the identified activity for micro-enterprise development requires some special skills,
appropriate training must be provided to the beneficiaries before extending financial support
by linking them for training under Component 3: Employment through Skills Training
and Placement (EST&P). Financial assistance should be extended only after the prospective
beneficiary has acquired required skills for running the proposed micro-enterprise.
3.1. Such training may not be necessary if the beneficiary has already undergone training
from a known institution, registered NGO/Voluntary Organisation or trained under any
government scheme provided requisite certificate is produced. In case the beneficiary
has acquired requisite skills from family occupation such cases should be certified by the
ULB before extending financial assistance.
3.2. Entrepreneurship Development Programme (EDP): In addition to skill training of
the beneficiaries, the ULB will also arrange to conduct Entrepreneurship Development
Programme for 3-7 days for individual and group entrepreneurs. The EDP will cover
basics of entrepreneurship development such as management of an enterprise, basic
accounting, financial management, marketing, backward and forward linkages, legal
procedures, costing and revenue etc. In addition to above topics the module should also
include group dynamics, allocation of work, profit sharing mechanism etc. for group
enterprises.
3.3. The EDP module may be developed and finalised by State Urban Livelihoods Mission
(SULM) supported by State Mission Management Unit (SMMU) with assistance of an
empaneled institution/agency or consulting firm and same may be utilised for conducting
training programme by the ULB. This EDP training may be arranged through institutions
such as Rural Self Employment Training Institutes (RSETI), reputed institutions engaged
in entrepreneurship development/ training, management/ educational institutes, reputed
NGOs engaged in entrepreneurship development/ training etc.
3.4. Any cost incurred on training of beneficiaries under this component is to be met out of
EST&P component budget.

2

<!-- page 9 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

4. Pattern of Financial Assistance: The financial assistance available to urban poor in setting
up individual and group enterprises will be in the form of Interest subsidy on the bank loans.
Interest subsidy, over and above 7% rate of interest will be available on a bank loan for setting
up of individual or group enterprises. The difference between 7% p.a. and the prevailing rate
of interest will be provided to banks under NULM. Interest subsidy will be given only in case
of timely repayment of loan. Suitable certification from banks will be obtained in this regard.
5. Procedure for interest subsidy:
5.1. All scheduled commercial banks(SCBs), Regional Rural Banks(RRBs) and cooperative
banks, which are on the Core Banking Solution (CBS) platform would be eligible for
getting interest subvention under the scheme
5.2. After disbursement of loan to the beneficiaries, the concerned branch of the bank will
send details of disbursed loan cases to ULB along with details of interest subsidy amount.
5.3. The settlement of claims made by banks would be done on quarterly basis by the ULBs,
however the submission of claims should be monthly. The ULB will check the data at
their end and will release the interest subsidy amount (difference between 7% p.a. and
prevailing rate of interest) to the banks.
5.4. A prescribed format for interest subsidy claims for loans under this component enclosed
at (Annexure-V).
5.5. The State Level Bankers Committees (SLBCs) has the option of evolving any alternative
procedure of aggregating/ sanction of claims in consultation with the state government.
5.6. The pending claims should not be more than a quarter. In case the claims of the banks are
not settled for a period of 6 months, SLBC is empowered to stop the scheme temporarily
in selected cities subject to clearance of claims by such ULBs. In such eventualities, the
claims settlement should prospectively be given to the Lead District Bank.
6. Sub-Component 4.1-Individual Enterprises (SEP-I)-Loan & Subsidy
6.1. An urban poor individual beneficiary desirous of setting up an individual micro-enterprise
for self-employment can avail benefit of subsidised loan under this component from any
bank. The norms/ specifications for individual micro-enterprise loans are as follows
6.2. Age: The prospective beneficiary should have attained the age of 18 Years at the time of

3

<!-- page 10 -->

National Urban Livelihoods Mission
lR;eso t;rs

applying for loan.
6.3. Project Cost (PC): The Maximum unit Project Cost for individual micro-enterprises
cases is Rs 200,000 (Rs Two Lakhs)
6.4. Collateral on Bank Loan: No collateral required. As per RBI Circular RPCD.SME &
NFS. BC.No. 79 /06.02.31/2009-10 dated May 6, 2010 banks are mandated not to accept
collateral security in the case of loans upto 10 lakhs extended to units in the MSE sector
(Annexure-I). Therefore only the assets created would be hypothecated/ mortgaged/
pledged to banks for advancing loans. The banks may approach Credit Guarantee Fund
Trust for Micro and Small Enterprises (CGTMSE) setup by Small Industries Development
Bank (SIDBI) and Government of India for the purpose of availing guarantee cover for
SEP loans as per the eligibility of the activity for guarantee cover (Details of the scheme
are at Annexure-II)
6.5. Repayment: Repayment schedule ranges from 5 to 7 Years after initial moratorium of
6-18 months as per norms of the banks.
7. Sub-Component 4.2-Group Enterprises (SEP-G) -Loan & Subsidy
A Self Help Group (SHG) or members of an SHG constituted under SJSRY/ NULM or a
group of urban poor desirous of setting up a group enterprise for self-employment can avail
benefit of subsidised loans under this component from any bank. The norms/ specifications
for group micro-enterprise loans are as follows
7.1. Eligibility: The group enterprise should have minimum 5 members with a minimum
of 70% members from urban poor families. The application/ intent to set up a group
ϐ Ȁ
community structures viz: SHG/ ALF formed under SJSRY/NULM.
7.2. Age: All members of the group enterprise should have attained an age of 18 years at
the time of applying for bank loan.
7.3. Project Cost (PC): The Maximum unit Project Cost for a group enterprise is Rs
10,00,000 (Rs Ten Lakhs)
7.4. Loan: ϐ  ȋ ϐȌ
made available as loan amount to the group enterprise by the bank.

4

<!-- page 11 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

7.5. Collateral Guarantee on Bank Loan: No collateral guarantee required. Only the
assets created would be hypothecated/ mortgaged/ pledged to banks for advancing
loans. The banks may approach Credit Guarantee Fund Trust for Micro and Small
ȋ ȌǦ͸ǤͶǤ
7.6. Repayment: Repayment schedule ranges from 5 to 7 Years after initial moratorium
͸Ǧͳͺ Ǥ
8. Procedure for Sponsoring of Applications:
8.1. The application for individual and group enterprise loans will be sponsored by the Urban
Local Body (ULB) which will be the sponsoring agency for the individual and group
enterprise.
8.2. The ULB will create awareness regarding SEP to the prospective beneficiaries through mass
media campaigns, IEC activities, advertisements in local newspapers, City Livelihoods
Centres (CLCs) etc. The ULB may also disseminate information regarding this component
through active involvement of Resource Organisations and its field staff.
8.3. The beneficiaries desirous of seeking financial assistance for setting up an enterprise can
submit an application of intent to the concerned ULB officials on a plain paper with basic
details viz: Name, Age, Contact details, Address, Aadhaar details (if any), amount of loan
required, bank account number (if available), type of enterprise/ activity, category etc.
The intent could also be sent by mail /post to the ULB office. The ULB shall accept such
intents throughout the year.
8.4. The community structures formed under Social Mobilisation & Institutional Development
(SM&ID) component of NULM viz: Self Help Groups (SHGs)/ Area Level Federations
(ALFs) may also refer prospective individual and group entrepreneurs for purpose of
financial assistance under SEP to ULB.
8.5. On submission/receipt of the intent from the beneficiary the respective ULB will enter the
details in a register/or MIS if available and hence will generate a waiting list of beneficiaries.
The ULB will issue an acknowledgement to the beneficiary with a unique registration
number, which may be used as a reference number for tracking the status of application.
8.6. Banks may also identify beneficiaries as per the eligibility criterion and receive the intent
letter. The applications received directly by the banks will be referred to the ULB. The

5

<!-- page 12 -->

National Urban Livelihoods Mission
lR;eso t;rs

applications in this case will also form a part of the waiting list.
8.7. ULB will call the beneficiaries in order of the waiting list to complete requisite
documentation including filling of Loan Application Form (LAF), activity details,
identity proof, address proof, bank account details etc. The SULM may develop a Loan
Application Form (LAF) in suitable format in consultation with State Level Bankers
Committee (SLBC) convenor bank. The same LAF may be utilised across the State.
8.8. The applications completed in all respect will be sent to the TASK force constituted at
ULB level for scrutiny, which will call the prospective beneficiaries for an interview
before recommending or rejecting the application or call for additional information from
the applicant if required.
8.9. The case duly recommended by the task force will be forwarded by the ULB to the
concerned banks for further processing. Such cases recommended by task force have
to be processed by concerned banks with in a time frame of 15 days. As these cases are
already recommended by the task force, such cases should be rejected by banks only in
exceptional circumstances.
8.10. The banks will send a periodic report to the ULB on the status of the applications received.
In case of MIS being used, the banks may be allowed to update the status of application
online in addition to manual report.
9. Task Force at ULB Level
9.1. A Task Force may be constituted at ULB level for recommending cases for individual and
group enterprises for onward transmission to the banks by the ULB. The Chief Executive
Officer (CEO)/ Municipal Commissioner of ULB will be responsible to constitute the
Task Force and will be The Chairman of the Task force. There could be more than 1
task force at ULB level depending upon the size/population of the ULB. The indicative
composition of the Task Force is as follows

6

<!-- page 13 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

Table No : 1
Sr No

TASK Force at ULB level

ROLE

1.

Chief Executive Officer (CEO) ULB/ Municipal Commissioner
of ULB/ or any representative authorised by CEO ULB

Chairman

2.

Lead District Manager (LDM)

Member

3.

City Project Officer (CPO), ULB/ or any authorised representative of ULB

Member
Convenor

4.

Representative from District Industries Centre (DIC)

Member

5.

Senior Branch Managers (Max-2) of banks

Member

6.

Representatives(2) of Area Level Federation / City Level Federation

Member

9.2. The ULB will forward the applications to the task force, which will be scrutinized based
on experience, skills, viability of activity, scope of the activity etc. Thereafter the Task
Force will shortlist the applications and call for interview of the applicants.
9.3. The task force will then recommend the applications if found suitable, reject if found
unsuitable or ask the beneficiary to submit further requisite information for reexamination on case to case basis.
10. Linkage with Credit Guarantee Scheme(CGS) of Ministry of Micro Small &

Medium Enterprises (MSME)
The banks may approach Credit Guarantee Fund Trust for Micro and Small Enterprises
(CGTMSE) setup by Small Industries Development Bank (SIDBI) and Government of India
for the purpose of availing guarantee cover for SEP loans as per the eligibility of the activity
for guarantee cover. The details of the scheme are provided at Annexure-II. The Reserve
Bank of India (RBI) in its circular dated 06th May 2010 has also directed the banks to take
Credit Guarantee Scheme cover instead of collateral security (Annexure-I).
11. Progress Reporting for SEP-I & SEP-G
11.1. The ULB will prepare a data sheet of the applications recommended by the TASK force
along with their status details of the sanction, disbursement and rejection (along with

7

<!-- page 14 -->

National Urban Livelihoods Mission
lR;eso t;rs

reasons) after validating the same with the respective banks. This data sheet will be sent
to SULM on a monthly basis.
11.2. The SULM will compile all the reports received from respective ULBs and will communicate
to M/o HUPA on a monthly basis.
11.3. SULM must ensure that progress under SEP is reviewed in every SLBC and District
Consultative Committe meetings. Any other important issue with regard to SEP
may be taken up by SULM with SLBC convenor bank for effective coordination and
implementation.
12. Sub-Component 4.3- Interest Subsidy on SHG Loans (SHG-Bank Linkage)
12.1. Linking of SHGs with banks have been emphasized in the Monetary policy of Reserve
Bank of India and Union Budget announcements from time to time and various guidelines
in this regard have been issued by the Reserve Bank of India(RBI) to banks. To scale
up the SHGs linkage programme and make it sustainable, banks have been advised to
consider lending to SHGs as part of their mainstream credit operations both at policy and
implementation level.
12.2. As per Master Circular on SHG-Bank Linkage Programme by Reserve Bank of India
(RPCD.FID. BC.No. 10/12.01.033/ 2013-14 dated 01 July 2013 -Annexure-III) RBI has
instructed the banks for SHG bank Linkage. SHG Bank Linkage includes Opening of
Savings Bank Account of Self Help Groups (whether registered or unregistered), which
are engaged in promoting habit of savings among their members as a starting point.
Thereafter the SHGs may be sanctioned Savings Linked Loans (varying from a saving
to loan ratio of 1:1 to 1:4) after due assessment or grading by banks. However, in case of
matured SHGs, loans may be given beyond the limit of four times the savings as per the
discretion of the bank. The RBI has also instructed that the advances to SHGs’ irrespective
of the purposes for which the members of SHGs should be included by the banks as part
of their lending to the weaker sections.
12.3. Under Social Mobilisation & Institution Development (SM&ID) component of NULM
the ULB will do necessary groundwork to open bank accounts for SHGs and facilitating
access to Revolving Fund (RF). The ULB may also engage Resource Organisation (RO)
for the purpose or may directly facilitate SHGs through its staff. (Concept & Formation
of SHGs, ROs and Revolving Fund has been detailed out in SM&ID guidelines)

8

<!-- page 15 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

12.4. With a view to provide access to credit at affordable rate of interest to the urban poor,
NULM will provide interest subsidy for SHGs accessing bank loan. The interest subsidy
will be the difference between the prevailing rate of interest charged by the bank and 7%
per annum, on all loans to SHGs of urban poor. This difference in interest amount on
SHG loan (between the prevailing rate of interest and 7% per annum) will be reimbursed
to banks.
12.5. An additional 3 percent interest subvention will be provided to all Women SHGs
(WSHGs) who repay their loan in time. The Interest subsidy will be subject to timely
repayment of the loan (as per the loan repayment schedule) and suitable certification
obtained from banks by the ULB. The additional 3% interest subvention amount will be
reimbursed to the eligible WSHGs. The banks should credit the amount of 3% interest
subvention to the eligible WHSGs accounts and thereafter seek the reimbursement.
12.6. The ULB through its field staff or Resource Organisation (ROs) will facilitate filling of
loan applications for eligible SHGs to access credit from the banks. The ULB will be
responsible to forward the Loan application of the SHGs to the concerned banks with
requisite documentation. The ULB will maintain area wise, bank-wise, ROs/ Staff wise
data of SHGs loan applications forwarded to the banks. The same will be sent to SULM
on a monthly basis.
12.7. The banks will send the details of disbursed loan cases to the ULB along with the calculation
details of the interest subsidy amount. The ULB will check the data at their end and will
release the interest subsidy amount on quarterly basis to the banks following a similar
procedure as mentioned in Para 5. The prescribed format for claiming the additional
interest subvention is enclosed at (Annexure-VI).
12.8. In order to ensure effective SHG-Bank Linkage under NULM, the SULM will monitor
and review the progress of banks on regular basis and co-ordinate with SLBC for interest
subsidy/ subvention on SHG Loans in the state. Active involvement of State level Bankers
Committee (SLBC) and lead banks may be ensured for sensitization of bank and branch
staff for financial inclusion of urban poor.
12.9. It may be noted that the identification, selection, formation and monitoring of SHGs who
are to get interest subvention would be the responsibility of State/ ULBs and banks would
not be liable for wrong identification of SHGs who get interest subvention.

9

<!-- page 16 -->

National Urban Livelihoods Mission
lR;eso t;rs

12.10.
a.

RBI guidelines for prompt repayment are as follows
For Cash Credit Limit to SHGs:
i. Outstanding balance shall not have remained in excess of the sanctioned limit/
drawing power continuously for more than 30 days.
ii. There should be regular credits and debits in the account. In any case there shall be
at least one customer induced credit during the month.
iii. Customer induced Credits during a month shall be sufficient to cover the interest
debited during the month

b.

For Term Loan to SHGs: A term loan account where all of the interest payments and/
or instalments of principal were paid within 30 days of the due date during the entire
tenure of the loans would be considered as an account having prompt payment
The prompt payment guidelines will continue to be guided by RBI guidelines on the
subject in future.

13. Sub-Component 4.4- Credit Card for enterprise development
13.1. The financial assistance to the individual entrepreneurs though subsidised loan for setting
up of enterprises under NULM could be viewed as initial impetus to facilitate livelihood
support to the urban poor. However the individual entrepreneurs require further financial
support in terms of working capital to make the enterprise economically sustainable.
This may include immediate and short term monthly requirement of cash for meeting
expenses for purchase of goods, raw materials and other miscellaneous expenditures
etc. The micro-entrepreneur does not have a regular fixed monthly cash inflow/income
to meet expenses arising out of entrepreneurial activities. Also to approach a financial
institution for such immediate credit requirement, requires procedural documentation
and consumes a lot of time. This need for working capital credit is generally met from
informal sources of credit (including money lenders) which is typically available at high
rate of interest.
13.2. In order to support the micro-entrepreneurs to meet their working capital and
miscellaneous credit needs, NULM will facilitate access to Credit Cards through banks
13.3. The SULM in consultation with the State Level Bankers Committee (SLBC) will

10

<!-- page 17 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

finalise the norms, limits and specifications for issuance of credit card to the individual
entrepreneurs. The General Credit Card Scheme (GCC), which is being implemented
by all scheduled commercial banks or any other variant of credit cards for enterprise
development of banks in urban areas, may be explored by SULM and SLBC for the same.
The details of revised GCC scheme as per RBI notification is provided at Annexure-IV
13.4. The ULB will identify the prospective beneficiaries and will facilitate linkages with banks
for issuance of credit cards. The focus is to initially facilitate issuance of credit card to
cover all the beneficiaries who have availed financial assistance under SEP. Additionally
other beneficiaries who are running their own business but have not availed assistance
under SEP may also be covered if they satisfy the norms of issuance of credit cards.
13.5. The targets for the same may be decided at ULB level and the progress under this
component is aggregated at SULM level and communicated to M/o HUPA periodically.
14. Sub-Component 4.5–Technology, Marketing and Other Support
14.1. Micro entrepreneurs often need support in order to grow and sustain their businesses.
Support needed may be for establishment, technology, marketing, and other services. Micro
entrepreneurs who run very small businesses may need to gain a better understanding
of what the market needs, demand of the products produced by them, prices, where to
sell, etc. Support services under this component are envisaged with a view to provide an
encouraging environment for development of micro enterprises.
14.2. The City Livelihood Centres (CLCs) established under NULM will offer services to the
micro-enterprises such as in establishment (licenses, certificates registration, legal services
etc.), production, procurement, technology, processing, marketing, sales, packaging,
accounting etc. for long term sustainability. CLC will also provide support in taking up
feasibility/ assessment studies on market demand and market strategy for products and
services of micro-enterprises.
14.3. All SEP individual and groups enterprises can avail the services from CLCs as per
the norms of CLCs. The CLC with support of ULB may also tie up with various other
government schemes which offer services and benefits for micro-enterprise development
for the benefit of beneficiaries.
14.4. The SULM may arrange for additional funds/professional assistance for the purpose of

11

<!-- page 18 -->

National Urban Livelihoods Mission
lR;eso t;rs

providing above services to CLCs.
15. Funding Pattern
15.1. Funding under this component will be shared between the Centre and the States in the
ratio of 75:25. In case of special category States (Arunachal Pradesh, Assam, Manipur,
Meghalaya, Mizoram, Nagaland, Sikkim, Tripura, Jammu & Kashmir, Himachal Pradesh
and Uttarakhand) this ratio will be 90:10 between the Centre and States.
15.2. The Ministry will allocate funds to the states on annual basis based on the targets assigned
to the states. The states in consultation with the respective SLBCs and ULBs will decide
the targets and corresponding funds will be allocated to ULBs so that full reimbursement
to the banks on account of Interest subvention is settled during the financial year and no
subvention amount overdue or pending with the states.
16. Monitoring and Evaluation
16.1. The SMMU at the State level and CMMU at the ULB level will closely monitor progress of
activities / targets under this component, undertake reporting and evaluation. The SULM
and the ULB/executing agencies shall report timely progress in formats prescribed by the
Mission Directorate from time-to-time, indicating the cumulative achievement monthly
and up to the end of the quarter and key issues in implementation.
16.2. In addition, under NULM, a comprehensive and robust IT-enabled NULM MIS will be
established for tracking targets and achievements. States and ULBs will be required to
submit their progress reports online and may also use this tool to monitor progress on
the ground. In the spirit of proactive disclosure of information and ensuring transparency
under NULM, key progress reports under SEP will also be made available in the public
domain in a timely manner.

*********

12

<!-- page 19 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

ANNEXURE-I

RBI/2009-10/449 RPCD.SME & NFS. BC.No. 79 /06.02.31/2009-10 May 6, 2010
The Chairman/ Managing Director
All Scheduled Commercial Banks
(Including Regional Rural Banks and Local Area Banks)

Dear Sir
Working Group to Review the Credit Guarantee Scheme for Micro and Small Enterprises
(MSEs) – Collateral free loans to MSEs
As you are aware, a Working Group was constituted by the Reserve Bank of India to review
the Credit Guarantee Scheme (CGS) of the Credit Guarantee Fund Trust for Micro and Small
Enterprises (Chairman: Shri V.K. Sharma, Executive Director, RBI) and suggest measures to
enhance its usage. The Report of the Working Group was released on March 6, 2010, which is
available on our website (www.rbi.org.in). The Working Group has, inter alia, recommended
that
“the limit for collateral free loans to the MSE sector be increased from the present level
of Rs. 5 lakh to Rs.10 lakh and it be made mandatory for banks. Banks, in turn, can take
cover for the collateral free credit facilities under CGS. In order to upscale the CGS, it is
necessary to create widespread awareness about the key features and benefits of the Scheme.
As the branch level functionaries have a predilection to lend against collaterals, the Group
recommends that the Chief Executive Officers (CEOs) of banks assume complete and total
ownership in the matter of strongly encouraging the branch level functionaries to avail of
the CGS cover, including making performance in this regard a criterion in the evaluation of
their field staff.”
The above recommendations have been accepted by the Reserve Bank of India. Accordingly,
in modification of our circular RPCD.SME & NFS.BC.No.16/06.02.31(P)/2009-10 dated
August 24, 2009, banks are mandated not to accept collateral security in the case of loans
upto Rs 10 lakh extended to units in the MSE sector.
2. Banks may also strongly encourage their branch level functionaries to avail of the CGS
cover, including making performance in this regard a criterion in the evaluation of their field
staff.

13

<!-- page 20 -->

National Urban Livelihoods Mission
lR;eso t;rs

3. You are requested to issue suitable instructions to your branches/ controlling offices for
meticulous and strict compliance in this regard.
4. Please acknowledge receipt.
Yours faithfully
(R.C. Sarangi)
Chief General Manager

14

<!-- page 21 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

ANNEXURE-II

CREDIT GUARANTEE FUND SCHEME FOR MICRO AND SMALL ENTERPRISES
Introduction
The Credit Guarantee Fund Scheme for Micro and Small Enterprises (CGMSE) was launched
by the Government of India to make available collateral-free credit to the micro and small
enterprise sector. Both the existing and the new enterprises are eligible to be covered under
the scheme. The Ministry of Micro, Small and Medium Enterprises and Small Industries
Development Bank of India (SIDBI), established a Trust named Credit Guarantee Fund
Trust for Micro and Small Enterprises (CGTMSE) to implement the Credit Guarantee Fund
Scheme for Micro and Small Enterprises. The scheme was formally launched on August
30, 2000 and is operational with effect from 1st January 2000. The corpus of CGTMSE is
being contributed by the Government and SIDBI in the ratio of 4:1 respectively and has
contributed Rs.1906.55 crore to the corpus of the Trust up to March 31,2010. As announced
in the Package for MSEs, the corpus is to be raised to Rs.2500 crore by the end of 11th Plan.
Eligible Lending Institutions
The institutions, which are eligible under the scheme, are scheduled commercial banks
(Public Sector Banks/Private Sector Banks/Foreign Banks) and select Regional Rural Banks
(which have been classified under ‘Sustainable Viable’ category by NABARD). National Small
Industries Corporation Ltd. (NSIC), North Eastern Development Finance Corporation Ltd.
(NEDFi) and SIDBI have also been made eligible institutions. As on March 31, 2010, there
were 112 eligible Lending Institutions registered as (MLIs) of the Trust, comprising of 27
Public Sector Banks, 16 Private Sector Banks, 61 Regional Rural Banks, 2 Foreign Bank and
6 other Institutions viz., NSIC, NEDFI, SIDBI and The Tamil Nadu Industrial Investment
Corporation(TNIIC).
Eligible Credit Facility
The credit facilities which are eligible to be covered under the scheme are both term loans
and working capital facility up to Rs.100 lakh per borrowing unit, extended without any
collateral security or third party guarantee, to a new or existing micro and small enterprise.

15

<!-- page 22 -->

National Urban Livelihoods Mission
lR;eso t;rs

For those units covered under the guarantee scheme, which may become sick owing to
factors beyond the control of management, rehabilitation assistance extended by the lender
could also be covered under the guarantee scheme. It is noteworthy that if the credit facility
exceeds Rs.50 lakh, it may still be covered under the scheme but the guarantee cover will
be extended for credit assistance of Rs.50 lakh only. Another important requirement under
the scheme is that the credit facility should be availed by the borrowing unit from a single
lending institution. However, the unit already assisted by the State Level Institution/NSIC/
NEDFi can be covered under the scheme for the credit facility availed from member bank,
subject to fulfillment of other eligibility criteria. Any credit facility in respect of which risks
are additionally covered under a scheme, operated by Government or other agencies, will
not be eligible for coverage under the scheme.
Guarantee Cover
The guarantee cover available under the scheme is to the extent of 75 per cent of the
sanctioned amount of the credit facility. The extent of guarantee cover is 80 per cent for (i)
micro enterprises for loans up to Rs.5 lakh; (ii) MSEs operated and/or owned by women;
and (iii) all loans in the North-East Region. In case of default, Trust settles the claim up to
75% (or 80% wherever applicable) of the amount in default of the credit facility extended by
the lending institution. For this purpose the amount in default is reckoned as the principal
amount outstanding in the account of the borrower, in respect of term loan, and amount
of outstanding working capital facilities, including interest, as on the date of the account
turning Non-Performing Asset (NPA).
Tenure of Guarantee
The Guarantee cover under the scheme is for the agreed tenure of the term loan/composite
credit. In case of working capital, the guarantee cover is of 5 years or block of 5 years.
Fee for Guarantee
The fee payable to the Trust under the scheme is one-time guarantee fee of 1.5% and annual
service fee of 0.75% on the credit facilities sanctioned. For loans up to Rs.5 lakh, the onetime guarantee fee and annual service fee is 1% and 0.5% respectively. Further, for loans in
the North-East Region, the one-time guarantee fee is only 0.75%.

16

<!-- page 23 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

Website
Operations of CGTMSE are conducted through Internet. The website of CGTMSE has been
hosted at www.cgtsi.org.in
Scheme Awareness Programmes
CGTMSE has adopted multi-channel approach for creating awareness about its guarantee
scheme amongst banks, MSE associations, entrepreneurs, etc. through print and electronic
media, by conducting workshops/seminars, attending meetings convened at various district/
state/national fora, etc. As on March 31, 2010, 1080 workshops and seminars were conducted
on Credit Guarantee Scheme. Also, CGTMSE participated in 19 exhibitions and attended 304
SLBC/meetings convened by RBI/other Government offices. Posters and mailers have been
circulated to banks, industry associations, and other stakeholders for promoting the scheme
and creating its greater awareness. With a view to imparting training to MLIs through their
training colleges, multimedia CD-ROM containing operational modalities of the scheme,
was distributed to the staff training centers/colleges of the MLIs. The Trust has recently
launched an advertisement campaign in 194 newspapers across the country through DAVP,
which has created considerable awareness about the scheme among the target audience.

17

<!-- page 24 -->

National Urban Livelihoods Mission
lR;eso t;rs

ANNEXURE-III
RPCD.FID. BC.No. 10/12.01.033/ 2013-14 July 01, 2013
The Chairman/ Managing Director/
Chief Executive Officer
All Scheduled Commercial Banks

Dear Sir,
Master Circular on SHG-Bank Linkage Programme
The Reserve Bank of India has, from time to time, issued a number of guidelines/instructions
to banks on SHG-Bank Linkage Programme. In order to enable the banks to have instructions
at one place, a Master Circular incorporating the existing guidelines/instructions on the
subject has been updated and enclosed. This Master Circular consolidates and updates
the circulars issued by Reserve Bank on the subject up to June 30, 2013 as indicated in the
Appendix.
Yours faithfully
(A. Udgata)
Principal Chief General Manager
Encl: As above

Master Circular on SHG-Bank Linkage Programme
1. Despite the vast expansion of the formal credit system in the country, the dependence of
the rural poor on moneylenders somehow continued in many areas, especially for meeting
emergent requirements. Such dependence was pronounced in the case of marginal farmers,
landless labourers, petty traders and rural artisans belonging to socially and economically
backward classes and tribes whose propensity to save is limited or too small to be mopped
up by the banks. For various reasons, credit to these sections of the population had not been

18

<!-- page 25 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

institutionalized. The studies conducted by NABARD, APRACA and ILO on the informal
groups promoted by Non-Governmental Organizations (NGOs) brought out that Self-Help
Savings and Credit Groups had the potential to bring together the formal banking structure
and the rural poor for mutual benefit and that their working had been encouraging.
2. Accordingly, NABARD launched a pilot project to cover Self-Help Groups (SHGs) promoted
by Non-Governmental Organizations, banks and other agencies under the pilot project and
supported it by way of refinance. The quick studies conducted by NABARD in a few states
to assess the impact of the linkage project brought out encouraging and positive features like
increase in loan volume of the SHGs, definite shift in the loaning pattern of the members
from non-income generating activities to production activities, nearly 100% recovery
performance, significant reduction in the transaction costs for both the banks and the
borrowers etc., besides leading to gradual increase in the income level of the SHG members.
Another significant feature observed in the linkage project was that about 85% of the groups
linked with the banks were formed exclusively by women.
3. With a view to studying the functioning of SHGs and NGOs for expanding their activities and
deepening their role in the rural sector, in November 1994, RBI constituted a working Group
comprising eminent NGO functionaries, academicians, consultants and bankers under the
Chairmanship of Shri S.K. Kalia, the then Managing Director, NABARD. The Working
Group was of the view that the linking of SHGs with the banks is a cost effective, transparent
and flexible approach to improve the accessibility of credit from the formal banking system
to the unreached rural poor, which is expected to offer the much needed solution to the
twin problems being faced by the banks, viz recovery of loans in the rural areas and the high
transaction cost in dealing with small borrowers at frequent intervals. The Group, therefore,
felt that the thrust of the policy should be to encourage the formation of SHGs and their
linking with the banks and in this regard, the banks have a major role to play. The Working
Group had recommended that the banks should treat the linkage programme as a business
opportunity and they may design area specific and group specific loan packages taking into
account inter alia the potential, local needs, available talent/skills etc.
4. The Reserve Bank constituted four informal groups in October 2002 to examine various issues
concerning micro-finance delivery. Linking of SHGs with banks have been emphasized in
the Monetary policy of Reserve Bank of India and Union Budget announcements from
time to time and various guidelines have been issued to banks in this regard. To scale up

19

<!-- page 26 -->

National Urban Livelihoods Mission
lR;eso t;rs

the SHGs linkage programme and make it sustainable, banks were advised that they may
consider lending to SHGs as part of their mainstream credit operations both at policy and
implementation level. They may include SHG linkage in their corporate strategy/plan,
training curriculum of their officers and staff and implement it as a regular business activity
and monitor and review it periodically.
5. Separate Segment under priority sector: In order to enable the banks to report their SHG
lending without difficulty, it was decided that the banks should report their lending to SHGs
and/or to NGOs for on-lending to SHGs/members of SHGs under the new segment, viz.
‘Advances to SHGs’ irrespective of the purposes for which the members of SHGs have been
disbursed loans. Lending to SHGs should be included by the banks as part of their lending
to the weaker sections.
6. Opening of Savings Bank A/c: The SHGs registered or unregistered which are engaged in
promoting savings habits among their members would be eligible to open savings bank
accounts with banks. These SHGs need not necessarily have already availed of credit facilities
from banks before opening savings bank accounts. KYC verification of all the members of SHG
need not be done while opening the savings bank account of the SHG as KYC verification of
all the office bearers would suffice. Further, it is clarified that since KYC would have already
been verified while opening the savings bank account and the account continues to be in
operation and is being used for credit linkage, no separate KYC verification of the members
or office bearers is necessary at the time of credit linking of SHGs,
7. SHG lending to be a part of planning process: Bank lending to SHGs should be included in
branch credit plan, block credit plan, district credit plan and state credit plan of each bank.
While no target is being prescribed under SHG bank linkage programme, utmost priority
should be accorded to the sector in preparation of these plans. It should also form an integral
part of the bank’s corporate credit plan.
8. Margin and Security Norms: As per operational guidelines of NABARD, SHGs may be
sanctioned savings linked loans by banks (varying from a saving to loan ratio of 1:1 to 1:4).
However, in case of matured SHGs, loans may be given beyond the limit of four times the
savings as per the discretion of the bank. Experience showed that group dynamics and peer
pressure brought in excellent recovery from members of the SHGS. The flexibility allowed to
the banks in respect of margin, security norms, etc. under the pilot project continues to be

20

<!-- page 27 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

operational under the linkage programme even beyond the pilot phase.
9. Documentation: A simple system requiring minimum procedures and documentation
is a precondition for augmenting flow of credit to SHGs. Keeping in view the nature of
lending and status of borrowers, banks should strive to remove all operational irritants and
make arrangements to expeditiously sanction and disburse credit by delegating adequate
sanctioning powers to branch managers. The loan application forms, procedures and
documents should be made simple. It would help in providing prompt and hassle-free credit.
10. Presence of defaulters in SHGs: The defaults by a few members of SHGs and/or their family
members to the financing bank should not ordinarily come in the way of financing SHGs
per se by banks provided the SHG is not in default to it. However, the bank loan may not be
utilized by the SHG for financing a defaulter member to the bank.
11. Capacity Building and Training: An important step in the Linkage Programme would be
the training of the field level officials and sensitization of the controlling and other senior
officials of the bank. Considering the need and magnitude of training requirements of bank
officers/staff both at field level and controlling office level, the banks may initiate suitable steps
to internalize the SHGs linkage project and organize exclusive short duration programmes
for the field level functionaries. In addition, suitable awareness/sensitization programmes
may be conducted for their middle level controlling officers as well as senior officers.
12. Monitoring and Review of SHG Lending: Having regard to the potential of the SHGs,
banks may have to closely monitor the progress regularly at various levels. In order to give a
boost to the ongoing SHG bank linkage programme for credit flow to the unorganized sector,
banks were advised in January 2004 that monitoring of SHG bank linkage programme may
be made a regular item on the agenda for discussion at the SLBC and DCC meetings. It
should be reviewed at the highest corporate level on a quarterly basis. Further the progress of
the programme may be reviewed by the banks at regular intervals. A progress report may be
sent to NABARD (Micro Credit Innovations Department), Mumbai, on a half-yearly basis,
as on 30 September and 31 March each year so as to reach within 30 days of the half-year to
which the report relates.
13. Encourage SHG Linkage: Banks should provide adequate incentives to their branches
in financing the Self Help Groups (SHGs) and establish linkages with them, making the
procedures absolutely simple and easy while providing for total flexibility in such procedures
to suit local conditions. The group dynamics of working of the SHGs may be left to themselves
21

<!-- page 28 -->

National Urban Livelihoods Mission
lR;eso t;rs

and need neither be regulated nor formal structures imposed or insisted upon. The approach
to financing of SHGs should be totally hassle-free and may include consumption expenditures.
14. Interest rates: The interest rate applicable to loans given by banks to Self Help Groups/
member beneficiaries would be left to their discretion.
15. Total Financial Inclusion and Credit Requirement of SHGs: Banks have been advised to
meet the entire credit requirements of SHG members, as envisaged in the Paragraph 93 of
the Union Budget announcement made by the Honourable Finance Minister for the year
2008-09 where in it was stated as under: “Banks will be encouraged to embrace the concept of
Total Financial Inclusion. Government will request all scheduled commercial banks to follow
the example set by some public sector banks and meet the entire credit requirements of SHG
members, namely, (a) income generation activities, (b) social needs like housing, education,
marriage, etc. and (c) debt swapping”.

22

<!-- page 29 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

ANNEXURE-IV

RBI/2013-14/389
RPCD.MSME & NFS. BC. No. 61/06.02.31/2013-14 December 2, 2013

The Chairman/Managing Director/ Chief Executive Officer
All Scheduled Commercial Banks
(Including Regional Rural Banks)
Dear Sir / Madam

Revised General Credit Card (GCC) Scheme
Please refer to our circular RPCD.CO.No.RRB.BC.59/03.05.33(F)/2005-06 dated December
27, 2005 and circular no. RPCD.CO.Plan.BC.No.66/04.09.01/2007-08 dated May 06, 2008 on
the General Credit Card (GCC) Scheme.
2. During Financial Inclusion Plan (FIP) review meetings held with banks during May-July
2013, it was observed that data reported by banks under GCC is not showing entrepreneurial
credit extended to individuals. In order to enhance the coverage of GCC Scheme to ensure
greater credit linkage for all productive activities within the overall Priority sector guidelines
and to capture all credit extended by banks to individuals for non-farm entrepreneurial
activity the GCC guidelines are being revised. The revised Scheme is at Annex.
3. You are further advised that any other Credit Card (e.g. Artisan Credit Card, Laghu Udyami
Card, Swarojgar Credit Card, and Weaver’s Card etc.) in existence and catering to the nonfarm entrepreneurial credit needs of individuals should be included for reporting of credit
extended through the General Credit Cards under the Financial Inclusion Plans (FIPs). As
the GCC is intended to cover all entrepreneurial credit, consumption credit extended to
individuals should not be reported under GCC.
4. The issuance of GCC does not preclude the banks from issuing any other credit card to
their customers for their consumption needs. Consumption credit provided by banks is to
be reported separately under the head of Overdraft (OD)/consumption credit in the FIP
reporting format prescribed by Reserve Bank of India.

23

<!-- page 30 -->

National Urban Livelihoods Mission
lR;eso t;rs

5. These guidelines will supersede the GCC guidelines issued by Reserve Bank of India
in December 2005 and May 2008. The revision has been done to ensure greater flow of
entrepreneurial credit to individuals, particularly to borrowers of small means.
6. All banks are advised to implement the Revised General Credit Card Scheme with
immediate effect under advice to us.
Yours faithfully
(Madhavi Sharma)
Chief General Manager
Encl: As above
1. Objectives
The objective is to increase flow of credit to individuals for entrepreneurial activity in the
non-farm sector provided through the General Credit Card.
2. Eligibility
All non-farm entrepreneurial credit extended to individuals, which is eligible for classification
under the priority sector guidelines.
3. Coverage
The scheme shall cover the entire country.
4. Nature of financial accommodation
Any credit facility extended under the Scheme would include both working capital and
term loan requirements of entrepreneurs. The GCC, preferably, may be issued as a Smart
card / Debit card (Biometric smart card compatible for use in the ATMs / Hand held Swipe
Machines and capable of storing adequate information on entrepreneur’s identity, assets and
credit profile etc.). Wherever the accounts are not digitized, the GCC may be issued as a
card/pass book or a credit card cum pass book incorporating the name, address, photograph
of the holder, particulars of borrowing limit, validity period etc. for the time being which will
serve both as an identity card as well as facilitate recording of the transactions on an ongoing
basis.

24

<!-- page 31 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

5. Quantum of credit limit
There will be no ceiling on the loan amount as long as the loan is for the purpose of nonfarm entrepreneurial activity and is otherwise eligible for classification as priority sector. The
limits should be fixed on the basis of risk assessment on a case to case basis.
6. Security
Security norms will be applicable as per Reserve Bank guidelines on collateral free lending
for micro and small units issued from time to time.
7. Rate of Interest
To be decided by banks in terms of their Board approved policies within the overall guidelines
issued by Reserve Bank on interest rates from time to time.

25

<!-- page 32 -->

National Urban Livelihoods Mission
lR;eso t;rs

ANNEXURE-V

INTEREST SUBSIDY CLAIMS UNDER NATIONAL URBAN LIVELIHOODS
MISSION (NULM)

1. Name of the Bank:

Submission of Interest subsidy claims to lend @ 7% p.a. to SEP-I, SEP-G and SHGs under
NULM for quarter ending (Figs in Rs):
We hereby apply for sanction and release of interest subsidy aggregating to
Rs…………………….. (Rupees………………………………………………………………)
covering …………………………………….. Accounts in respect of financial assistance
sanctioned to following constituent accounts numbers as per the details given below
A) SEP- I (Individual Enterprise)

S.No

1

Branch

2

1
2
3
Total

26

Name of

Loan

the bor-

Account

rower

No

3

Loan Amount
Sanc-

Disbursed

Interest
Charged

tioned
4

5

Subsidy
Claimed

6

7

8

<!-- page 33 -->

NULM Operational Guidelines for Self-Employment Programme
lR;eso t;rs

B) SEP- G (Group Enterprise)
No

Branch

1

2

Name
of the
Group

Loan Account No

3

4

Loan Amount

Interest

Sanctioned

Disbursed

Charged

Subsidy
Claimed

5

6

7

8

1
2
3
Total

c) Self Help Group (SHG Bank Linkage)
No

1

Branch

2

Name of
the SHG

3

Loan
Account
No

Loan Amount

Interest

Sanctioned

Disbursed

Charged

Subsidy
Claimed

4

5

6

7

8

1
2
3
Total

Place:

(Signature of the Authorised Officer of the Bank)

Date and Seal of the Bank

27

<!-- page 34 -->

National Urban Livelihoods Mission
lR;eso t;rs

ANNEXURE-VI

Submission of claims for additional Interest Subvention to lend Women Self Help
Groups (WSHGs) at 3% pa under NULM for the quarter ending:

Name of the Bank:

Statement for the quarterly claims: Loans disbursed/outstanding (Figs in Rs)

S.
No

Branch

1

2

Name of the
WSHG
3

Loan Account No
4

Loan Amount
Disbursed

Amount
of Interest
subvention

5

6

1
2
3
Total

We hereby certify that above loans were repaid on time and the benefit of additional interest
subvention has been passed on to the WSHG’s account, reducing effective rate of interest to
4% for the prompt payee WSHGs

Place

Date and Seal of the Bank

28

(Signature of the Authorised Officer of the Bank)

<!-- page 35 -->

<!-- page 36 -->

Self Employment
Programme
(Operational Guidelines)

National Urban Livelihoods
Mission

lR;eso t;rs

Government of India
Ministry of Housing & Urban Poverty Alleviation
Website: http://mhupa.gov.in

lR;eso t;rs

Government of India
Ministry of Housing & Urban Poverty Alleviation
Issued in December 2013
