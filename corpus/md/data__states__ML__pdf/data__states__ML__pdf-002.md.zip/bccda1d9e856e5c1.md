---
doc_id: "bccda1d9e856e5c1"
source_url: "https://megscpwd.gov.in/notifications/Nodal_Officer-CSPS_14mar2022.pdf"
ministry: "Office of the State Commissioner for Persons with Disabilities, Meghalaya"
title: "Nodal Officer for implementation of Inservice Training and Sensitisation of Key Functionaries of Central and State Govt, Local bodies and other Service Providers   [475 kb]"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "5e19130b42e766f1"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
SOCIAL WELFARE DEPARTMENT
* ORDERS BY THE GOVERNOR
NOTIFICATION
Dated Shillong the 14" March, 2022
No. SW (S) 10/2016/Pt/58: The Governor of Meghalaya is pleased to nominate Smti Bridget Warshong, Deputy
Commissioner for Persons with Disabilities, Meghalaya, Shillong as Nodal Officer for implementation of In-
Service Training and Sensitisation of Key Functionaries of Central and State Government, Local Bodies and
other Service Providers for disability related matters under Central Sector Plan Scheme which is in pursuance to
the Ministry of Social Justice & Empowerment, Department of Empowerment of Persons with Disabilities
(Divyangjan) File No 7-14/In-Service/2014/RCI dated 27.01.2022 with effect from the date of issue of this
Notification and until further orders.
Sd/-
(Sampath Kumar, IAS)
Principal Secretary to the Government of Meghalaya,
Social Welfare Department.
Memo. No. SW(S) 10/2016/P/58-A, Dated Shillong the 14" March, 2022
Copy to:-
1. The Private Secretary to the Hon’ble Chief Minister, Government of Meghalaya for favour of kind
information of the Hon’ble Chief Minister.
2. The Private Secretary to the Hon’ble Speaker, Meghalaya State Legislative Assembly for favour of
kind information of the Hon’ble Speaker.
3. The Private Secretary to the Hon’ble Leader of Opposition, Meghalaya State Legislative Assembly
for favour of kind information of the Hon’ ble Leader of Opposition.
4. The Private Secretary to the Minister /C of Social Welfare Department for favour of kind
information of the Minister.
5. The Private Secretary to the Chief Secretary, Government of Meghalaya for favour of kind
information of the Chief Secretary
6. The Private Secretary to the Principal Secretary, Social Welfare Department for favour of kind
information of the Principal Secretary.
7. The Private Assistant to the Commissioner & Secretary, Social Welfare Department for favour of
kind information of the Commissioner & Secretary.
8. The Secretary and Chairperson, RCI, Ministry of Social Justice & Empowerment, Department of
Empowerment of Persons with Disabilities (Divyangjan), 5" Floor, Pt Deendayal Atyodaya Bhavan,
CGO Complex, Lodhi Road, New Delhi 110003 for favour of kind information.
9. The Private Assistant to the Secretary, Social Welfare Department for favour of kind information of
the Secretary.
10. The Joint Secretary, Social Welfare Department for favour of kind information.
11. The Director of Social Welfare, Meghalaya Shillong for favour of kind information
12. The Director, Printing and Stationery, Meghalaya, Shillong with a request to publish the Notification
in the fext issue of the Meghalaya Gazette.
13-The Commissioner for Persons with Disabilities, Meghalaya Shillong for favour of kind information
with reference to Letter NO CPWD/TRG-In-Service/RCI/1/2022/206 dated 09.03.2022.
14. The Senior Informatics Officer, National Informatics Centre, Meghalaya, Shillong with a request to .
upload the Notification in the Department's website.
15.Guard file.
By Orders Ete.,
tL-
Deputy Secretary to the Govt. of Meghalaya,
Social Welfare Department.
