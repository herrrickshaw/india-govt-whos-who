---
doc_id: "6cdbdb685d7ffffc"
source_url: "https://mnreda.gov.in/assets/pdf/tenders/2026/TCN.pdf"
ministry: "Meghalaya New and Renewable Energy Development Agency, Meghalaya"
title: "TENDER CANCELLATION NOTICE - Tender bearing No. MNREDA/1804/2019/58, Dated: 08-06-2026, is hereby cancelled with immediate effect"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "5232159bfcb8d41b"
---

<!-- page 1 -->

(Ca)
MEGHALAYA NEW AND RENEWABLE ENERGY
DEVELOPMENT AGENCY

Near BSF camp Mawpat, Shillong 793019 Phone: 0364-2953755

Email: - mureda.dirgmuil.com Website: www.nnreda.gov.in
No. MNREDA/1804/2019/123 Dated: Shillong, The 28" July 2026

TENDER CANCELLATION NOTICE
This is for general information that It is hereby notified for general information that the Tender
bearing No. MNREDA/1804/2019/58, Dated: 08-06-2026, issued for “Empanelment of Vendors
for Design, Supply, Installation, Commissioning, Erection and Comprehensive Maintenance
of Solar Water R.O. Purification Systems in the State of Meghalaya”, is hereby cancelled with
immediate effect.
The Competent Authority, after due consideration, has decided to cancel the aforesaid tender due to
the non-receipt of any bids from vendors in response to the Notice Inviting Tender (NIT) within
the stipulated time period.

This notice is issued for information of all concerned.
oO MNREDA
