---
doc_id: "5dcae17a0c43bba0"
source_url: "https://megscpwd.gov.in/notifications/notification_dtd_21feb23.pdf"
ministry: "Office of the State Commissioner for Persons with Disabilities, Meghalaya"
title: "Bethany Society, Shillong as the empaneled agency for conducting of access audit of buildings in the State for making them accessible to Persons with Disabilities   [248 kb]"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "a837fe40e5e3fc47"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA Yow
SOCIAL WELFARE DEPARTMENT pe ow
ORDERS BY THE GOVERNOR
NOTIFICATION
Dated Shillong the 21 February, 2023
No. SW (S) 87/2016/612: In pursuance to Ministry of Social Justice & Empowerment, Department of ;
Empowerment of Persons with Disabilities (Divyangjan) letter D.O No I-14003/6/2022-AIC/E-22241 dated
18.01.2023, the Governor of Meghalaya is pleased to notify Bethany Society, Shillong as the empaneled agency
for conducting of access audit of buildings in the State for making them accessible to Persons with Disablities
with effect from the date of issue of this Notification and until further orders.
Sd/-
Sampath Kumar, IAS,
Principal Secretary to the Government of Meghalaya,
Social Welfare Department.
Memo. No. SW(S) 87/2016/612-A, Dated Shillong the 21% February, 2023
Copy to:-

1. The Private Secretary to the Chief Secretary, Government of Meghalaya for favour of kind information
of the Chief Secretary.

2. The Private Secretary to the Principal Secretary to the Government of Meghalaya, Social Welfare
Department for favour of kind information of the Principal Secretary.

3. The Private Assistant to the Commissioner & Secretary to the Government of Meghalaya, Social
Welfare Department for favour of kind information of the Commissioner & Secretary.

4. Rajesh Aggarwal, IAS, Secretary to the Government of India, Ministry of Social Justice &
Empowerment, Department of Empowerment of Persons with Disabilities (Divyangjan), 5‘ Floor, Pt
Deendayal Antyodaya Bhavan, CGO Complex, Lodhi Road, New Delhi 110003 for favour of kind
information.

S. The Private Assistant to the Secretary to the Government of Meghalaya, Social Welfare Department
for favour of kind information of the Secretary.

6. The Joint Secretary, Social Welfare Department for favour of kind information.

7. The Director of Social Welfare, Meghalaya Shillong for favour of kind information .

8. The Director, Printing and Stationery, Meghalaya, Shillong with a request to publish the Notification
inthe next issue of the Meghalaya Gazette.

9 The Commissioner for Persons with Disabilities, Meghalaya Shillong for favour of kind information.

10. The Senior Informatics Officer, National Informatics Centre, Meghalaya, Shillong with a request to
upload the Notification in the Department’s website.

11.The President, Bethany Society, Lady Veronica Lane, Laitumkhrah, Shillong 793 003 for favour of
kind information.

12.Guard file.

By Orders Ete.,
Wea, Te
, Mie -
pis, Under Secretary to the Govt. of Meghalaya,
Ble? Social Welfare Department.
