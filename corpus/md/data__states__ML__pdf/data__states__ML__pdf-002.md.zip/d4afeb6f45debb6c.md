---
doc_id: "d4afeb6f45debb6c"
source_url: "https://www.mlcuniv.in/wp-content/uploads/2025/07/Addendum-to-Notification-No-92-Reconstitution-of-ICC.pdf"
ministry: "Martin Luther Christian University, (MICU), Shillong, Meghalaya"
title: "Download the notification"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "db1e4f878379a0b6"
---

<!-- page 1 -->

RRP iis a GE SRG hs Mn ie RM seo om ar Si
dN)
Martin Luther Christian Universit
(;. Nongrah, Dongktieh, Block-1, Shillong-793 006, Meghalaya, India y
0364-253 5420, 253 5437 / 60096 02012
The Light of Truth e-mail : admin@mlcuniv.in, www.micuniv.in
FL. No: I11/8(7)/Admin June 30, 2025
Addendum to Notification No: 92
Reconstitution of the Internal Complaint Committee (ICC)
Internal Complaint Committee Members (Effective June 30, 2025, for a period of 3 years):
1. Dr. Marina B. Marwein, Professor Chairperson
2. Dr. Mellissa Dora Kyndiah, Assistant Professor Member
3. Dr. Chelmelyne Dhar, Associate Professor Member
4. Mrs. Lakynti Kharpuri, Director Education Outreach Member
5. Mr. Banpynshngain Kharlukhi, Assistant Registrar Admin Member
6. Mrs. Joy Grace Syiem, Gender and Legal Consultant Member
7. Adv. Rebina Subba, Consultant and Member of LCC Member
8. Two Student Representatives from the Student Council Student Member
9. Ms. Wanphylla Nongrum, Research Scholar Student Member
10. Ms. Aliscacia M Swett, Deputy Registrar Non-Member Secretary
Dr. ladonlang Tynsong a ig
Registrar STON
