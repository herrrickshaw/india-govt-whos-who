---
doc_id: "b8991cebb4e5f5aa"
source_url: "https://mserc.gov.in/orders/Orders_18October2024/MePDCL_True-Up_Order_2022-23_18-10-2024.pdf"
ministry: "Meghalaya State Electricity Regulatory Commission (MSERC), Meghalaya"
title: "True-up Order for FY 2022-23 of Meghalaya Power Distribution Corporation Limited   (6.91 MB)"
date: ""
pages: 162
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ea30fc993a035b2e"
---

<!-- page 1 -->

MEGHALAYA STATE ELECTRICITY REGULATORY
COMMISSION SHILLONG
Front Block Left Wing, 1st Floor, New Administrative Building,
Lower, Lachumiere, Shillong, Meghalaya 793001
Order on Case No. 36 of 2023

Petition for approval of True Up of Distribution Business of Meghalaya Power
Distribution Corporation Ltd (MePDCL) for FY 2022-23

Coram
Shri. Chandan Kumar Mondol, Chairman
Shri. Ramesh Kumar Soni, Member (Law)
Petitioner:
Meghalaya Power Distribution Corporation Ltd. (MePDCL)
Lum Jingshai, Short Round Road,
Shillong – 793 001
Order
(Dated: 18.10.2024)
The Government of Meghalaya has noti�ied the Power Sector Reforms Transfer Scheme 2010
leading to restructuring and unbundling of erstwhile Meghalaya State Electricity Board
(MeSEB) into four entities. Accordingly, Meghalaya Power Distribution Corporation Limited
has started functioning as a segregated commercial operation utility independently for
power Distribution in the state of Meghalaya with effect from 1st April 2013.

The Commission, in exercise of the powers vested in it under Sections 61 and 62 of the
Electricity Act (EA), 2003 and all other powers enabling it in this behalf, and after taking into
consideration the submissions made by MePDCL, suggestions/objections received from the
stakeholders upon public consultation process, and upon considering all other relevant
material herein, has already issued Order for the true-up of Distribution Business for FY
2021-22 dated 13.11.2023.

<!-- page 2 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

The Commission in exercise of functions vested vide Regulation 17 of MSERC Multi Year Tariff
Regulations 2014 being read along with its subsequent amendments had approved
Aggregate Revenue Requirement (ARR) for FY 2022-23 in its order dated 25.03.2022.

Further in accordance with the applicable regulatory provisions set out vide regulation 14 of
the MSERC Multi Year Tariff Regulations, 2014 being read along with its subsequent
amendments speci�ies the following:
“The Generating Company or Transmission Licensee or Distribution Licensee shall �ile
an Application for Truing up of the previous year and determination of tariff for the
ensuing year, within the time limit speci�ied in these Regulations.”

The Petitioner herein being MePDCL has �iled petition for True-Up of Distribution Business
for the FY 2022-23 along with audited statement of accounts on 29th November 2023.
This Commission had admitted the Petition provisionally on 01.12.2023, with a direction to
MePDCL that an abstract of the Petition should be published in two consecutive issues in
local dailies in Khasi, Jaintia, Garo and English. The Petitions were registered as under:



MSERC Case No. 32/2023: MYT for Fourth Control Period FY 2024-25 to FY 202627 for MePDCL and Determination of Tariff for the FY 2024-25 of MePDCL.
MSERC Case No. 36/2023: Truing up of Distribution Business for the FY 2022-23.

The Regulation-11 of MYT Regulation 2014 stipulates that the Commission shall undertake
true-up of the previous year’s expenses and revenue approved with reference to Audited
Statement of Accounts made available subject to prudence check including pass through of
impact of uncontrollable factors (if any).
Further, the Commission taking into consideration all the facts, additional information/data
and after prudence check of the claims as per the MYT Regulations, approves the true up
orders for FY 2022-23 and the detailed analysis is presented subsequently in this order.
The Commission noti�ies that the impact of true up gap/surplus shall be appropriated in the
next Tariff Order.

Sd/-

Sd/-

Ramesh Kumar Soni,
Member (Law)

Chandan Kumar Mondol,
Chairman

MSERC Order in Case No. 36 of 2023

Page 2 of 60

<!-- page 3 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

Table of Contents
1.

Background and Brief History ...............................................................................................................................................6

1.2.

Facts about this Case .................................................................................................................................................................6

1.1.
2.

3.

3.1.

Background ....................................................................................................................................................................................6

Suggestions/Objections Received, Response of MePDCL .........................................................................................9

True Up of Distribution Business for FY 2022-23 for MePDCL ........................................................................... 10

Introduction ............................................................................................................................................................................... 10

3.2.

Regulatory Provision for Filing of True Up Petition................................................................................................... 10

3.4.

Category Wise No. of Consumers, Connected Load and Energy sales for FY 2022-23 ............................... 13

3.3.

Physical Performance ............................................................................................................................................................. 12

3.5.

Availability of Energy ............................................................................................................................................................. 14

3.3.

Energy sold to Others ............................................................................................................................................................. 17

3.2.

3.4.

3.5.

3.6.

3.7.

3.8.

3.9.

3.10.

3.11.

3.12.

3.13.

Energy Sales ............................................................................................................................................................................... 15

Distribution Loss and Energy Balance............................................................................................................................ 18

Energy Balance.......................................................................................................................................................................... 21

Power Purchase Cost .............................................................................................................................................................. 23

Gross Fixed Assets (GFA) ...................................................................................................................................................... 25

Grant Adjustment and Funding Pattern ......................................................................................................................... 26

Depreciation ............................................................................................................................................................................... 29

Return on Equity ...................................................................................................................................................................... 32

Interest on Loan........................................................................................................................................................................ 33

Operation and Maintenance Expenses ........................................................................................................................... 38

Interest on Working Capital ................................................................................................................................................ 41

3.14.

Revenue From Sale of Surplus Power ............................................................................................................................. 43

3.16.

Computation of AT&C losses ............................................................................................................................................... 47

3.15.

3.17.

3.18.

3.19.

3.20.

Non-Tariff and Other Income .............................................................................................................................................. 44

Accrued Terminal Bene�its................................................................................................................................................... 50

Aggregate Revenue Requirement and Revenue Gap/Surplus for FY 2022-23 ............................................. 51

Revenue from Operations..................................................................................................................................................... 54

Revenue Gap/Surplus ............................................................................................................................................................ 55

4.

Summary of Order ................................................................................................................................................................... 56

6.

Applicability of the Order ..................................................................................................................................................... 59

5.

7.

Commission’s Directives ....................................................................................................................................................... 57

Annexure-1 ................................................................................................................................................................................. 60

MSERC Order in Case No. 36 of 2023

Page 3 of 60

<!-- page 4 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

List of Tables
Table 1: Growth in Infrastructure of MePDCL ................................................................................... 13
Table 2: Approved No. of Consumers, Connected Load and Energy Sales for FY 2022-23 ....... 13
Table 3: Proposed Energy Available to MePDCL from various sources in FY 2022-23 ............. 14
Table 4 : Proposed Comparison of Energy Sales to inside consumers in FY 2022-23 ............... 16
Table 5: Proposed Energy Sales to Others in FY 2022-23 ............................................................... 17
Table 6: Proposed Computation of Distribution Losses for FY 2022-23 ..................................... 18
Table 7: Revised Proposed Computation of Distribution Losses for FY 2022-23 ...................... 20
Table 8: Approved Computation of Distribution Losses for FY 2022-23 ..................................... 21
Table 9: Proposed Computation of Energy Balance for FY 2022-23 ............................................. 21
Table 10: Approved Computation of Energy Balance for FY 2022-23 .......................................... 22
Table 11: Proposed Power Purchase Expenses for FY 2022-23 .................................................... 23
Table 12: Proposed Reconciliation of Power Purchase Expenses for FY 2022-23 ..................... 24
Table 13: Approved Reconciliation of Power Purchase Expenses for FY 2022-23 .................... 24
Table 14: Proposed Gross Fixed Asset for FY 2022-23 .................................................................... 25
Table 15: Approved Gross Fixed Asset for FY 2022-23.................................................................... 26
Table 16: Proposed Additional Capitalization funded through Grant for FY 2022-23 ............. 27
Table 17: Approved Grant Adjustment for FY 2022-23 ................................................................... 28
Table 18: Proposed Calculation of Depreciation of 2022-23 ......................................................... 29
Table 19: Approved Computation of Depreciation for FY 2022-23 .............................................. 31
Table 20: Proposed Return on Equity for FY 2022-23 ..................................................................... 32
Table 21: Approved Return on Equity for FY 2022-23 .................................................................... 33
Table 22: Proposed Computation of Weighted Average Rate of Interest for FY 2022-23 ......... 34
Table 23: Proposed Computation of Normative Interest on Loan for FY 2022-23 .................... 34
Table 24: Proposed Actual Loan Portfolio for FY 2022-23 ............................................................. 35
Table 25: Approved Computation of Weighted Average Rate of Interest for FY 2022-23 ........ 37
Table 26: Approved Computation of Normative Interest on Loan for FY 2022-23 .................... 37
Table 27: Proposed Employee Expenses for FY 2022-23 ................................................................ 38
Table 28: Proposed R&M Expenses for FY 2022-23 ......................................................................... 39
Table 29: Proposed A&G Expenses for FY 2022-23.......................................................................... 39
Table 30: Approved A&G Expenses for FY 2022-23 ......................................................................... 41
Table 31: Approved O&M Expenses for FY 2022-23 ........................................................................ 41
Table 32: Proposed Computation of Interest on Working Capital for FY 2022-23 .................... 42
Table 33: Approved Computation of Interest on Working Capital for FY 2022-23 .................... 43
Table 34: Proposed Revenue from sale of surplus power for FY 2022-23 .................................. 43
Table 35: Proposed Details of Swapping Return During FY 2022-23 ........................................... 43
Table 36: Proposed Details of Non-Tariff Income for FY 2022-23 ................................................. 45
Table 37: Approved Details of Non-Tariff Income for FY 2022-23 ................................................ 46
Table 38: Proposed Computation of AT&C Losses for FY 2022-23................................................ 47
Table 39: Approved Computation of AT&C Losses for FY 2022-23 ............................................... 48
Table 40: Approved AT&C Losses for FY 2022-23 ............................................................................ 49
Table 41: Approved AT&C Loss penalty for FY 2022-23.................................................................. 50
Table 42: Proposed Aggregate Revenue Requirement & Revenue Gap/ (Surplus) for FY 202223 ............................................................................................................................................................... 52
Table 43: Approved Aggregate Revenue Requirement & Revenue Gap/ (Surplus) for FY 202223 ............................................................................................................................................................... 53
MSERC Order in Case No. 36 of 2023

Page 4 of 60

<!-- page 5 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
Table 44: Proposed Details of Revenue from Sale of Power for FY 2022-23 ............................... 54
Table 45: Approved Details of Revenue from Sale of Power for FY 2022-23 .............................. 54
Table 46: Proposed Revenue Gap for FY 2022-23 ............................................................................ 55
Table 47: Approved Revenue Gap for FY 2022-23 ............................................................................ 55
Table 48: Summary of Approved ARR �igures for True-Up of FY 2022-23 .................................. 56
Table 49: Commission’s Directive........................................................................................................ 57

MSERC Order in Case No. 36 of 2023

Page 5 of 60

<!-- page 6 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

1. Background and Brief History
1.1. Background
1.1.1.
1.1.2.

1.1.3.
1.1.4.

1.1.5.

The power distribution in the state of Meghalaya is carried out by Meghalaya
Electricity Power Distribution Corporation Limited (MePDCL), a wholly owned
subsidiary of Meghalaya Energy Corporation Limited (MeECL).

The Power Supply Industry in the state of Meghalaya has been under the
governance of erstwhile Meghalaya State Electricity board (MeSEB) since 21st
January 1975. The Government of Meghalaya has noti�ied the Power Sector
Reforms Transfer Scheme 2010, leading to restructuring, and unbundling of
erstwhile Meghalaya State Electricity Board (MeSEB) into four entities. After
noti�ication of amendment to the Power Sector Reforms Transfer Scheme by
the State Government on 1st April 2012, the un-bundling of MeECL into
MePDCL, MePGCL and MePTCL came into effect.

Accordingly, Meghalaya Power Distribution Corporation Limited (MePDCL)
(herein referred to as “Petitioner”) has started functioning as a segregated
commercial operation utility independently for power distribution in the state
of Meghalaya with effect from 1st April 2013.
The Meghalaya State Electricity Regulatory Commission (herein referred as
“MSERC”/“Commission”) is an independent statutory body constituted under
the provisions of the Electricity Regulatory Commissions (ERC) Act, 1998,
which was superseded by Electricity Act (EA), 2003. The Commission is vested
with the authority of regulating the power sector in the State inter alia
including determination of tariff for electricity consumers.

In exercise of the powers vested vide Regulation 16 of MSERC Multi Year Tariff
Regulations, 2014, the Commission had approved Multi Year Aggregate
Revenue Requirement (ARR) & Distribution Tariff for MePDCL vide Tariff
Order dated 25.03.2021. The Aggregate Revenue Requirement and
Distribution Tariff for the year FY 2022-23 was further revised vide order
dated 25.03.2022 in Case no. 29 of 2021.

1.2. Facts about this Case
1.2.1.
1.2.2.

The Petitioner, in compliance with the Regulation 11.2 of the Meghalaya State
Electricity Regulatory Commission (Multi Year Tariff) Regulation, 2014 along
with its subsequent amendments has �iled its application for Trueing Up of
Distribution Business for FY 2022-23 dated 29.11.2023.

This Commission dated 01.12.2023 had admitted the Petition provisionally
directing MePDCL to publish abstract of the Petition in two consecutive issues
in local dailies in Khasi, Jaintia, Garo and English.

MSERC Order in Case No. 36 of 2023

Page 6 of 60

<!-- page 7 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

1.2.3.
1.2.4.
1.2.5.
1.2.6.

1.2.7.
1.2.8.

1.2.9.

1.2.10.
1.2.11.
1.2.12.
1.2.13.

Subsequently on 07.12.2023 and 08.12.2023 abstract of the Petition were
published in The Shillong Times- Shillong Edition, U Nongsain Hima and
Salantini Janera, inviting objections/suggestions from stakeholders within 30
(thirty) days from the date of publication.
This Commission on 22.02.2024 and 23.02.2024 published notices for Public
Hearing in the daily locals viz Shillong Times, Shillong & Tura Edition,
Nongsain Hima and Salantini Janera.
On 20.03.2024, in compliance of the due regulatory procedures public hearing
of the submitted application for Trueing Up of Distribution Business for FY
2022-23 dated 29.11.2023 was conducted including the Petitioner and the
stakeholders.

This Commission had received objections/suggestions from BIA, during the
process of evaluating the submitted application for Trueing Up of Distribution
Business for FY 2022-23 dated 29.11.2023. The Petitioner has accordingly
submitted its replies / responses to the issues raised by the stakeholders
during the process which has been noted by this Commission.
Subsequently, due to the pronouncement of model code of conduct on account
of the Lok Sabha Elections, issuance of Orders of the subject matter was
upheld. The Commission dated 05.06.2024 issued the Order for Trueing Up of
Distribution Business for FY 2022-23.
Subsequently, on 01.08.2024 in pursuant to the Order dated 23.07.2024 of the
Hon’ble High Court of Meghalaya in WP(C) 217 of 2024, this Commission
admitted the revised application of the Petitioner provisionally and notice for
rehearing of the application for Trueing Up of Distribution Business for FY
2022-23 were issued.

On 23.08.2024, the Commission had recalled its earlier True Up Order for
MePDCL for the year FY 2022-23.

On 03.09.2024, this Commission again issued publication of notice for
rehearing of the application for Trueing Up of Distribution Business for FY
2022-23.

On 04.10.2024, due consultative process was followed through public hearing
of the submitted application for Trueing Up of Distribution Business for FY
2022-23 were concluded and the Petitioner and the stakeholders were
directed for submission of the objections / suggestions.
This Commission has accordingly noted all replies / responses received within
due date of 09.10.2024 from the Petitioner and the Stakeholders raised during
the public consultation process. The Commission’s analysis and ruling thereon
are elaborated in the following sections.
Further, Regulation 11.5 of the Meghalaya State Electricity Regulatory
Commission (Multi Year Tariff) Regulation, 2014 stipulates the following:

MSERC Order in Case No. 36 of 2023

Page 7 of 60

<!-- page 8 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

“11.5 The scope of the truing up shall be a comparison of the performance of
the Generating Company or Transmission Licensee or Distribution Licensee
with the approved forecast of Aggregate Revenue Requirement and expected
revenue from tariff and charges and shall comprise of the following:
a) a comparison of the audited performance of the applicant for the
previous �inancial year with the approved forecast for such previous
�inancial year, subject to the prudence check including pass-through of
impact of uncontrollable factors;
b) Review of compliance with directives issued by the Commission from
time to time;
c) Other relevant details, if any.”
1.2.14.

Further, the apportionment of MeECL expenses shall be regulated as per the
Commission’s previous noti�ications and directives subject to prudence check.

MSERC Order in Case No. 36 of 2023

Page 8 of 60

<!-- page 9 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

2. Suggestions/Objections Received, Response of MePDCL
2.1.1.

Objections/ suggestions received from stakeholders has been placed under
Annexure-1.

MSERC Order in Case No. 36 of 2023

Page 9 of 60

<!-- page 10 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3. True Up of Distribution Business for FY 2022-23 for MePDCL
3.1. Introduction
3.1.1.

The Petitioner submitted that it �illed the true up Petition for FY 2022-23 as
per the provisions of the Regulation 11 of the MSERC (Multi Year Tariff)
Regulations, 2014 (herein referred as 2014 Tariff Regulations). The extract of
the Regulation 11.5 of 2014 Tariff Regulations is as follows,

“The Scope of the truing up shall be a comparison of the performance of the
Generating Company or Transmission Licensee or Distribution Licensee
with the approved forecast of the Aggregate Revenue Requirement and
expected revenue from tariff and charges and shall comprise of:
a) A comparison of the audited performance of the applicant for the
previous �inancial year with the approved forecast for such �inancial
year, subject to the prudence check including pass-through of impact
of uncontrollable factors.
b) Review of the compliance with the directives issued by the Commission
from time to time:
c)Other relevant details.”
<Emphasis added>

3.1.2.

3.1.3.

Accordingly, the Petitioner has relied on the audited accounts of the FY 202223 for claiming most of the components of Aggregate Revenue Requirement.
The detailed assumptions and methodology adopted by the Petitioner for
various components of the ARR had been discussed in detail in the subsequent
sections of its petition.

Further, Petitioner mentioned that the Commission vide order dated
25.03.2021 in Case No. 04 of 2021 allowed the Multi Year ARR for MePDCL
including the ARR of FY 2022-23. The ARR for the year was further revised
vide order dated 25.03.2022 in Case no. 29 of 2021- Aggregate Revenue
Requirement and Distribution Tariff for FY 2022-23. Since, the Annual
Statement of Accounts for FY 2022-23 had been audited and hence in terms of
the provisions of Regulation 11 of the 2014 Tariff Regulations, MePDCL �illed
the true up Petition for FY 2022-23.

3.2. Regulatory Provision for Filing of True Up Petition
3.2.1.

The Commission has noti�ied the Meghalaya State Electricity Regulatory
Commission (Multi Year Tariff) Regulations, 2014 on 15thSeptember 2014
which is applicable for determination of tariff effective from 1 April 2015.
Regulation 11 of the said Regulations lays down the general guiding principles

MSERC Order in Case No. 36 of 2023

Page 10 of 60

<!-- page 11 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

for truing up and the provisions of the said Regulations are reproduced below
for reference:
“11. Truing-Up

11.1
Where the Aggregate Revenue Requirement and expected revenue
from tariff and charges of a Generating Company or Transmission Licensee
or Distribution Licensee is covered under a Multi-Year Tariff framework, then
such Generating Company or Transmission Licensee or Distribution
Licensee, as the case may be, shall be subject to truing up of expenses and
revenue during the Control Period in accordance with these Regulations.
11.2
The Generating Company or Transmission Licensee or
Distribution Licensee shall �ile an Application for Truing up of the previous
year and determination of tariff for the ensuing year, within the time limit
speci�ied in these Regulations:
11.3
Provided that the Generating Company or Transmission Licensee
or Distribution Licensee, as the case may be, shall submit to the Commission
information in such form as may be prescribed by the Commission, together
with the Audited Accounts including audit report by CA&G, extracts of books
of account and such other details as the Commission may require to assess
the reasons for and extent of any variation in �inancial performance from the
approved forecast of Aggregate Revenue Requirement and expected revenue
from tariff and charges
3.2.2.

It is further stated that the amendment to Regulation 11.3 of the Meghalaya
State Electricity Regulatory Commission (Multi Year Tariff) Regulations, 2014
dated 15th June 2021 is as follows,
“Provided that the Generating Company or Transmission Licensee, as the
case may be, shall submit to the Commission information in such form as may
be prescribed by the Commission, together with the Audited Accounts
including audit report by a Statutory Auditor appointed by C&AG, extracts of
books of account and such other details as the Commission may require to
assess the reasons for and extent of any variation in �inancial performance
from the approved forecast of Aggregate Revenue Requirement and expected
revenue from tariff and charges.”
11.4
Provided further that once the Commission noti�ies the
Regulations for submission of Regulatory Accounts applications for tariff
determination and truing up shall be based on the Regulatory Accounts.
11.5
The scope of the truing up shall be a comparison of the
performance of the Generating Company or Transmission Licensee or
Distribution Licensee with the approved forecast of Aggregate Revenue
Requirement and expected revenue from tariff and charges and shall
comprise of the following:

MSERC Order in Case No. 36 of 2023

Page 11 of 60

<!-- page 12 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

a) a comparison of the audited performance of the applicant for the
previous �inancial year with the approved forecast for such previous
�inancial year, subject to the prudence check including pass-through of
impact of uncontrollable factors;
b) Review of compliance with directives issued by the Commission from time
to time;
c) Other relevant details, if any.
11.6
In respect of the expenses incurred by the Generating Company,
Transmission Licensee and Distribution Licensee during the year for
controllable and uncontrollable parameters, the Commission shall carry out
a detailed review of performance of an applicant vis-a-vis the approved
forecast as part of the truing up.
11.7
Upon completion of the truing up under Regulation 11.4 above,
the Commission shall attribute any variations or expected variations in
performance for variables speci�ied under Regulation 12 below, to factors
within the control of the applicant (controllable factors) or to factors beyond
the control of the applicant (uncontrollable factors):
Provided that any variations or expected variations in performance, for
variables other than those speci�ied under Regulation 12.1 below shall be
attributed entirely to controllable factors.
11.8
Upon completion of the Truing Up, the Commission shall pass an
order recording:
a) the approved aggregate gain or loss to the Generating Company or
Transmission Licensee or Distribution Licensee on account of controllable
factors, and the amount of such gains or such losses that may be shared in
accordance with Regulation 14 of these Regulations;
3.2.3.

Commission vide order dated 25.03.2021 in Case No. 04 of 2021 has allowed
the Multi Year ARR for MePDCL including the ARR of FY 2022-23. The ARR for
the year was further revised vide order dated 25.03.2022 in Case no. 29 of
2021- Aggregate Revenue Requirement and Distribution Tariff for FY 2022-23.
Since, the Annual Statement of Accounts for FY 2022-23 have been audited and
hence in terms of the provisions of Regulation 11 of the Meghalaya State
Electricity Regulatory Commission (Multi Year Tariff) Regulation, 2014
MePDCL is �iling the true up Petition for FY 2022-23.

3.3. Physical Performance
3.3.1.

The Petitioner submitted that there has been substantial growth in terms of
the infrastructure and there has been substantial increase in the infrastructure
which shows the Petitioner’s commitment to improve the performance and
cater to the growing demand of the consumers in an ef�icient manner.

MSERC Order in Case No. 36 of 2023

Page 12 of 60

<!-- page 13 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.3.2.

The growth of infrastructure of the Petitioner is tabulated below,
Table 1: Growth in Infrastructure of MePDCL

S.No Particular
1. Number of 33/11 KV Sub-Stations
2. Transformation Capacity of
33/11 KV Sub-Stations
3. Length of 33 KV Lines
4. Number of 11/0.4 KV Sub-Stations
5. Transformation Capacity of
11/0.4 KV Sub-Stations
6. Length of 11 KV Lines
7. Number of Distribution
Transformers
8. Length of LT lines

Commission’s Analysis

3.3.3.

UOM
Nos.

2018-19
98

2019-20
101

2020-21 2021-22
107
114

2022-23
115

CKM.
Nos.

2217.03
10381

2332.93
11563

2519.41
12436

2794.05
12951

15601.68

16810.05 17886.16 19687.60 19361.24

20019.21

24928.55 27762.23 31758.38 32196.44

MVA
MVA

CKM.
Nos.

CKM.

486.58

600.33

641.88

634.45

2630.655
12798

625.75

540815.27 773490.75 834374.54 889235 922714.50
10381

11577

12495

12847

13173

The Commission notes MePDCL’s submission in terms of Physical Performance
highlights

3.4.

Category Wise No. of Consumers, Connected Load and Energy sales
for FY 2022-23

3.4.1.

The Category wise number of consumers, connected load and Energy sales
approved for True up of FY 2022-23 are as shown below,

Table 2: Approved No. of Consumers, Connected Load and Energy Sales for FY 2022-23

Sl.
No

1
2
3
4
5
6
7
8
9
1
2
3
4
5
6

Category
LT Category
Domestic
Commercial
Industrial
Agriculture
Public Lighting
Water Supply
General purpose
Kutir Jyoti
Crematorium
HT Category
Domestic
Water Supply
Bulk Supply
Commercial
Industrial
Ferro Alloys

MSERC Order in Case No. 36 of 2023

No. of
Consumers
approved for
FY 2022-23
(Number)

Connected
Load
approved for
FY 2022-23
(MVA)

6,81,146
392431
37267
784
22
78
476
2661
247426

946.47
590.68
109.56
9.90
0.12
1.54
6.89
18.99
208.64
0.15
304.20
23.11
14.49
53.23
27.59
155.34
18.91

1

873
131
70
230
230
209
3

Energy
Sales
approved
for FY
2022-23
(MU)
700.77
429.52
96.57
7.40
0.20
1.03
9.60
17.47
138.78
0.18
408.81
22.18
35.37
77.86
30.96
133.25
109.20

Page 13 of 60

<!-- page 14 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

Sl.
No

1
2
3

Category

No. of
Consumers
approved for
FY 2022-23
(Number)

Connected
Load
approved for
FY 2022-23
(MVA)

-

101.70
120.64

Energy
Sales
approved
for FY
2022-23
(MU)
0.00
671.77
263.36

1,425.18

1,781.35

Special tariff
EHT Category
Industrial
Ferro Alloys

Special tariff
Total

18

14
4
-

6,81,836

65.40
-

408.41
0.00

3.5. Availability of Energy
Petitioner’s Submission
3.1.1.

The Petitioner submitted that it has two major sources for the long-term
procurement of power i.e., power projects of MePGCL the state-owned
generation company and the allocation of power from the Central Generating
Stations of NEEPCO, NHPC, NTPC and OTPC. Further, the Petitioner mentioned
that the most of the stations from which the Petitioner is having long term
agreement for procurement of power are hydro power projects the availability
from which is maximum during the monsoon period and during the winter
season the availability from these sources go down and hence to cater to the
demand of the state and ensure uninterrupted supply of power, MePDCL is
bound to buy power from the short-term sources such as IEX/bilateral and
swapping arrangements. The comparative statement of the energy availability
from various sources as approved by the Hon’ble Commission in the tariff
order and actual availability from these sources is tabulated below:

Table 3: Proposed Energy Available to MePDCL from various sources in FY 2022-23

S No Source

Quantum
Actual
Approved Availability
(MU)
(MU)

1

MePGCL

1293.49

1043.53

3

NEEPCO

723.70

646.64

NTPC

589.50

0.00

2

NHPC

4

OTPC

6

Solar Sources

5

Total Long Terms

40.28

436.79

36.87

517.23

39.42

3123.18

2244.28

1

Kreate Energy (Swapping)

0.00

281.55

3

APPCL (Swapping)

0.00

85.74

2

Kreate Energy (IEX)

MSERC Order in Case No. 36 of 2023

0.00

27.65

Page 14 of 60

<!-- page 15 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

S No Source
4

APPCL (Bilateral Purchase)

0.00

6

GMRTEL (Swapping)

0.00

5
7
8

APPCL (IEX)

Manikaran (Swapping)

Subheksha (Swapping)

10 DSM Intra-State

3.1.3.

9.05

0.00

25.92

0.00

64.80

0.00
0.00

92.16
52.09
0.94

11 DSM Inter-State

0.00

0.00

660.72

Grand Total

3123.18

2905.00

Total Short Term

3.1.2.

Quantum
Actual
Approved Availability
(MU)
(MU)

20.83

The Petitioner also submitted that, actual availability from the long-term
sources has been 2244.28 MU against the 3123.18 MU approved by the
Commission resulting in a gap of 878.90 MU and accordingly, to cover this gap
the Petitioner has resorted to the short-term sources and has procured 660.72
MU of power from short-term sources.
Accordingly, the Petitioner requested the Commission to approve the total
availability as shown in the table above.

Commission’s Analysis
3.1.4.

It may be observed that 250 MU short supplied from State owned Generating
stations and 77.06 MU short supply from NEEPCO.

3.1.6.

Summing up of the above shortfall, petitioner has resorted to procure 170.12
MU bilaterally from power traders, IEX, DSM Interstate and Intrastate, while
490.60 MU procured in Swapping arrangement.

3.1.5.

3.1.0.

There was no supply from NTPC Bongaigoan for 589.50 MU as projected.
Petitioner has not procured Energy from Solar sources approved for ARR at
39.42 MU.

Commission considers availability of power for 2905.00 MU for True up of
FY 2022-23.

3.2. Energy Sales
Petitioner’s Submission
3.2.1.

The Petitioner submitted that it has been operating four of its sub-divisions
through distribution franchisee. The distribution franchisee is Input Based
Distribution Franchisee in nature where in the input energy is being provided
to the franchisee at the injection points of the four sub-divisions. The

MSERC Order in Case No. 36 of 2023

Page 15 of 60

<!-- page 16 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.2.2.

3.2.3.

distribution franchisees are billed at the input energy provided to them at the
injection point. Thus, Petitioner mentioned that, technically there is no
distribution loss on the energy provided to the franchisee.

Accordingly, the Petitioner mentioned that the total energy sales in the state
during FY 2022-23 has been 1718.83 MU which can be veri�ied from the
Audited Statement of Accounts, however, since after providing the input
energy to the franchisee the losses in the respective sub-divisions is borne by
the franchisee, MePDCL for the purpose of Petition has proportionately
distributed the input energy provided to the franchisee into the consumer
categories in proportion to consumption of each category in the area of
franchisee. The detailed calculation has been submitted by the Petitioner in an
excel model along with the Petition.

The Petitioner further added that the revenue from sale of power is also
accounted in the statement of accounts in a similar manner. The revenue from
the consumers is accounted separately and revenue from distribution
franchisee is accounted separately. Those the method adopted for arriving at
the sale to consumers is such so that there is parity between the audited
accounts and the true up petition.

Table 4 : Proposed Comparison of Energy Sales to inside consumers in FY 2022-23
Energy Sales
approved for FY
2022-23
(MU)

Actual Sales
FY 2022-23
(MU)

% Variation

LT Category

606.14

700.77

16%

2

Commercial

77.28

96.57

25%

4

Agriculture

0.78

Sl.No. Category

1
3

Domestic

Industrial

5

Public Lighting

7

General purpose

6

404.7
6.21

0.12

429.52
7.40

0.20

6%

19%

-74%

1.03

762%

17.47

0%

Water Supply

12.76

Kutir Jyoti

Crematorium

86.55

HT Category

0.22

138.78

475.44

0.18

408.81

-14%

1

Domestic

25.15

22.18

-12%

3

Bulk Supply

103.64

77.86

-25%

Industrial

150.58

133.25

-12%

8
9
2
4
5
6

Water Supply
Commercial

Ferro Alloys

MSERC Order in Case No. 36 of 2023

17.52

33.35

27.87

36.28

9.60

35.37
30.96

109.20

-25%
60%

-16%
6%

11%

201%

Page 16 of 60

<!-- page 17 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

Sl.No. Category

Actual Sales
FY 2022-23
(MU)

% Variation

7

Special tariff

EHT Category

98.57

465.8

0.00

671.77

-100%

1

Industrial

53.41

263.36

393%

3

Special tariff

64.85

0.00

-100%

2

3.2.4.

Energy Sales
approved for FY
2022-23
(MU)

Ferro Alloys

347.54

Total

1547.38

408.41

1781.35

44%
18%

15%

The Petitioner requested the Commission to approve the sales of FY 2022-23
as 1781.35 MU for the purpose of truing up and calculation of T&D losses and
AT&C losses.

Commission’s Analysis
3.2.5.

The licensee has reported category wise sales for FY 2022-23 which amounted
to 1718.83 MU vide note no. 24.1 of SOA as against actual sales after
considering the explanation given in the petition, the energy sales has been
approved as 1781.35 MU.

3.3. Energy sold to Others
Petitioner’s Submission
3.3.1.

The Petitioner submitted that it is heavily dependent on the hydro power
projects for the power procurement. In the monsoon season there is surplus
available with the Petitioner which is sold in short-term markets such as IEX/
Bilateral Sales and swapping arrangements. The details of the surplus shortterm power sold in FY 2022-23 is tabulated below,
Table 5: Proposed Energy Sales to Others in FY 2022-23
S No. Particular

MU

a. Sales on IEX and Bilateral
1

GMR Energy (IEX)

2

Kreate Energy (IEX)

4

DSM Intra State

3
5

50.72

APPCL (IEX)

38.05

Kreate Energy (Bilateral)

20.25

Sub-Total Sales

b. Details of Swapping

MSERC Order in Case No. 36 of 2023

1.33

35.66

146.01

Page 17 of 60

<!-- page 18 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
1

Kreate Energy (Swapping)

290.99

3

GMR Energy (Swapping)

29.23

2
4
5

APPCL (Swapping)

99.09

Manikaran (Swapping)

58.25

Sub-Total Swapping

501.65

SAPL (Swapping)
Grand Total

24.09

647.66

Commission’s Analysis
3.3.2.

3.3.3.

The Source wise sale of surplus power reported vide note no. 24.3 of Audited
accounts found to be 647.66 MU.

The Sale of Surplus power as claimed in the petition for 647.66 MU is
considered for True up of FY 2022-23.

3.4. Distribution Loss and Energy Balance
Petitioner’s Submission
3.4.1.

The Petitioner based on the availability of power in terms of MU and the sales
in terms of MU depicted, computed the distribution losses for the state for FY
2022-23 and energy balance of the state for FY 2022-23 which are as follows,
Table 6: Proposed Computation of Distribution Losses for FY 2022-23

Sl.
No.

Particulars

Calculation

1
2
3
4

Energy purchase from Eastern Region (ER)
Inter-State Transmission Loss in ER
Net Power purchased from ER
Power purchase from CGS including Pallatana North Eastern
Region (NER)
Total Power at NER
Inter-State Transmission Loss in NER
Net Power available at state bus from external sources on long
term
Power purchase from MePGCL

A
B
C=A(1-B%)

True-Up for FY
2022-23
(Claimed)
0
1.80%
0

E=C+D
F

1200.74
3%

5
6
7
8
9
10
11
12

Power purchase from other sources (both from outside &
within the State) (incl.swap/UI/bilateral)

Power sold to others (both outside & inside the State)
(incl.swap/UI/bilateral)

Net power available at State Bus for sale of power within the
state
State Transmission Loss %

MSERC Order in Case No. 36 of 2023

D

1200.74

G=E*(1-F%)

1164.72

I

660.72

H

J

K=G+H+I-J
L

1043.53

647.66

2221.32
4.00%

Page 18 of 60

<!-- page 19 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
Sl.
No.

Particulars

13

State Transmission Loss MU

15

16
17
18
19

Sub-Transmission Loss and Aux Consumption (@4%)

Net power available of Discom for sale of power within the
state
Power sold to consumers within the state
Distribution Losses
Distribution Losses (%)

3.4.2.

3.4.3.

Calculation
M=K*L
N=K-M

O
P=N-O
Q=P/N

True-Up for FY
2022-23
(Claimed)
88.85
88.85

2043.62

1781.35
262.27
12.83%

The Petitioner would like to submit that the sub-transmission losses based on
empirical studies done in house have been considered as 2% for the purpose
of calculation of the T&D losses. Further, the Petitioner had also mentioned
that it has several sub-stations, sub- division of�ices, head of�ice, workshops
etc. where substantial amount of energy is consumed. Hence, it has considered
2% of the input energy as auxiliary consumption for the purpose of calculation
of T&D losses.
The Petitioner requested the Commission to approve the distribution losses
of 12.83% for the FY 2022-23.

Commission’s Analysis
3.4.4.

3.4.5.

3.4.6.

The Commission observed that the petitioner MePDCL has projected sub
transmission loss plus Auxiliary consumption at 4% over and above the State
Transmission losses for 4% for computation of Energy Balance while
projecting 12.83 % overall T&D losses vide table no.06 of True up petition for
FY 2022-23.

The Commission had also observed that the petitioner has submitted that sub
transmission losses based on empirical studies done in-house have been
considered as 2% for the purpose of calculation of the T&D losses. Further,
MePDCL has several sub-stations, sub-division of�ices, head of�ice, workshops
etc. where substantial amount of energy is consumed. Hence, MePDCL has
considered 2% of the input energy as auxiliary consumption for the purpose
of calculation of T&D losses. Thus, the Transmission and sub transmission
losses projected for True up would amount becomes equal to 4+4 = 8 % in all
for FY 2022-23, whereas the Commission had approved 3.70% Transmission
loss in the business plan for FY 2022-23 as against the projected Transmission
loss of 3.80 % considering the Transmission network addition contemplated
for the control period FY 2020-21 to FY 2023-24.
In view of the above, Commission directed the Petitioner to furnish the
Authority and norms for claiming 8% Transmission and Sub Transmission
losses for computation of Distribution loss and Energy balance beyond the
approved Transmission losses of 3.70% in the Business Plan for FY 2022-23.

MSERC Order in Case No. 36 of 2023

Page 19 of 60

<!-- page 20 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.4.7.

3.4.8.

In reply of the Commission’s query, the Petitioner submitted that the Ministry
of Power, Government of India, Transmission Division vide Noti�ication dated
01.09.2021 has stated that on an average the sub-transmission losses are at
4.8% on an average. However, MePDCL has considered only 2% as subtransmission losses. The Copy of the same has been provided by the Petitioner.
Moreover, the Petitioner con�irmed that it will make efforts to meter the
premises of several division and sub-division of�ices of MePDCL, workshops
which use electric furnaces to ascertain the actual energy consumed by them
and request the Commission to consider the 2% auxiliary consumption as
claimed in the petition.
Further, the Petitioner submitted that it considered an intra-state transmission
loss of 4% in place of 3.7% as approved by the Commission in the business
plan of MePTCL based on the practice followed by Commission in all the
previous true ups. However, in case the intra-state transmission losses are to
be considered as 3.7%, the Inter-State transmission losses should also be
considered at actuals instead of normative 3%. The actual average inter-state
transmission losses as per the POSOCO for FY 2022-23 comes out to be 3.57%.
The details of the week wise ISTS losses as reported by POSOCO and
consequential impact on computation of T&D losses and energy balance had
been shared by the Petitioner.

Table 7: Revised Proposed Computation of Distribution Losses for FY 2022-23
Sl.
No.
1
2
3
4
5
6
7
8
9

10
11
12
13
14
15
16
17

Particulars

Calculation

Energy purchase from Eastern Region (ER)
Inter-State Transmission Loss in ER
Net Power purchased from ER
Power purchase from CGS including Pallatana North
Eastern Region (NER)
Total Power at NER
Inter-State Transmission Loss in NER
Net Power available at state bus from external sources
on long term
Power purchase from MePGCL
Power purchase from other sources (both from outside
& within the State) (incl.swap/UI/bilateral)

A
B
C=A(1-B%)

True-Up for FY
2022-23 (Claimed)
0
1.80%
0

E=C+D
F

1200.74
3.57%

Power sold to others (both outside & inside the State)
(incl.swap/UI/bilateral)
Net power available at State Bus for sale of power
within the state
State Transmission Loss %
State Transmission Loss MU
Sub-Transmission Loss and Aux Consumption (@4%)

Net power available of Discom for sale of power within
the state
Power sold to consumers within the state
Distribution Losses
Distribution Losses (%)

MSERC Order in Case No. 36 of 2023

D

1200.74

G=E*(1-F%)

1157.88

I

660.72

H

1043.53

J

2214.48

L
M=K*L

3.70%
81.94

N=K-M

2043.96

K=G+H+I-J

O
P=N-O
Q=P/N

647.66

88.58

1781.35
262.61
12.85%

Page 20 of 60

<!-- page 21 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.4.9.

Commission has considered the Intra-state Transmission losses for the
Transmission network under MePTCL as 3.16% same as claimed by MePTCL
in its True-up petition for FY 2022-23 and recomputed the Distribution Losses
for FY 2022-23 as follows,
Table 8: Approved Computation of Distribution Losses for FY 2022-23

Sl.
No.

Particulars

Calculation

1
2
3
4

Energy purchase from Eastern Region (ER)
Inter-State Transmission Loss in ER
Net Power purchased from ER
Power purchase from CGS including Pallatana
North Eastern Region (NER)
Total Power at NER
Inter-State Transmission Loss in NER
Net Power available at state bus from external
sources on long term
Power purchase from MePGCL

5
6
7
8
9

Power purchase from other sources (both from
outside & within the State) (incl.swap/UI/bilateral)

10
11
12
13

15

16
17
18
19

Power sold to others (both outside & inside the
State) (incl.swap/UI/bilateral)
Net power available at State Bus for sale of power
within the state
State Transmission Loss %
State Transmission Loss MU
Sub-Transmission Loss and Aux Consumption
(@4%)
Net power available of Discom for sale of power
within the state
Power sold to consumers within the state
Distribution Losses
Distribution Losses (%)

3.5. Energy Balance

A
B
C=A(1-B%)

True-Up for
FY 2022-23
(Claimed)
0
1.80%
0

True-Up for
FY 2022-23
(Approved)
0
1.80%
0

E=C+D
F

1200.74
3.57%

1200.74
3.57%

D

1200.74

1200.74

G=E*(1-F%)

1157.88

1157.88

I

660.72

660.72

H

1043.53

1043.53

J

647.66

2214.48

2214.48

L
M=K*L

3.70%
81.94

3.16%
69.98

N=K-M

2043.96

2144.50

K=G+H+I-J

O
P=N-O
Q=P/N

647.66

88.58

0.00

1781.35
262.61
12.85%

1781.35
363.15
16.93%

Petitioner’s Submission
3.5.1.

The Petitioners have requested the Commission to allow the distribution
losses of 12.83% for the FY 2022-23. Accordingly, the Energy Balance
computed by the Petitioner for FY 2022-23 and submitted its revised table in
the reply of Additional Information 8 vide dated 30.04.2024 as shown in the
Table below:
Table 9: Proposed Computation of Energy Balance for FY 2022-23

Sl.
No.
1
2
3

Particulars

Calculation

Quantity

Energy purchase from Eastern Region (ER)
Inter-State Transmission Loss in ER
Net Power purchased from ER

A
B
C=A(1-B%)

0
1.80%
0

MSERC Order in Case No. 36 of 2023

Page 21 of 60

<!-- page 22 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
Sl.
No.
4
5
6
7
8
9

10
11
12
13
14
15
16
17
18

Particulars
Power purchase from CGS including Pallatana North Eastern
Region (NER)
Total Power at NER
Inter-State Transmission Loss in NER
Net Power available at state bus from external sourcess on long
term
Power purchase from State generating stations within the state
Power purchase from other sources (both from outside &
within the State)
Net power available at state bus for sale of power within the
state
Total power sold
Distribution Losses (%)
T&D Losses in terms of MU
Energy Requirement for sale by Discom within state
Energy Requirement for sale within state at state bus
Surplus Energy at state bus
Power sold to others at state bus (both outside & inside the
State) (incl.swap/UI/bilateral)
Unaccounted Energy

Calculation

Quantity

D

1200.74

H
I

1043.53
660.72

E=C+D
F
G=E*(1-F%)

J=G+H+I

K
L
M=N-K
N = K/(1-L)
O = N/(1-4%)
P = J-O
Q

R=P-Q

1200.74
3.57%
1157.86

2862.12

1781.35
12.85%
262.59
2043.94
2214.45
647.67
647.67
0.00

Commission’s Analysis

3.5.2.

3.5.3.

The Commission observes that the Petitioners have submitted the energy
balance based on the actual average inter-state transmission losses as per the
POSOCO for FY 2022-23 which comes out to be 3.57%, whereas the Intra-State
transmission losses have been claimed as approved by the Commission in
Business Plan Order for MePTCL.

Based on the approved Intra-state Transmission loss as 3.16% and considering
the Inter-state Transmission loss equal to 52 weeks of average actual losses of
FY 2022-23 i.e. 3.57% , Commission approves the energy balance for FY 202223 as shown in the below table,
Table 10: Approved Computation of Energy Balance for FY 2022-23

Sl.
No.
1
2
3
4
5
6
7
8
9

Particulars

Calculation

Quantity

Energy purchase from Eastern Region (ER)
Inter-State Transmission Loss in ER
Net Power purchased from ER
Power purchase from CGS including Pallatana North Eastern
Region (NER)
Total Power at NER
Inter-State Transmission Loss in NER
Net Power available at state bus from external sources on long
term
Power purchase from State generating stations within the state
Power purchase from other sources (both from outside & within
the State)

A
B
C=A(1-B%)

0
1.80%
0

MSERC Order in Case No. 36 of 2023

D

1200.74

G=E*(1-F%)

1157.88

I

660.72

E=C+D
F
H

1200.74
3.57%
1043.53

Page 22 of 60

<!-- page 23 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
Sl.
No.
10

Particulars

11
12
13
14
15

Total power sold
Distribution Losses (%)
T&D Losses in terms of MU
Energy Requirement for sale by Discom within state

Net power available at state bus for sale of power within the
state

Energy Requirement for sale within state at state bus

16
17

Surplus Energy at state bus
Power sold to others at state bus (both outside & inside the
State) (incl. swap/UI/bilateral)
Unaccounted Energy

18

Calculation

Quantity

J=G+H+I

2862.14

K
L
M=N-K
N = K/(1-L)
O = N/(13.16%)
P = J-O
Q

R=P-Q

1781.35
16.93%
69.98
2144.50
2214.48
647.66

647.66
0.00

3.6. Power Purchase Cost
Petitioner’s Submission
3.6.1.

The Petitioner has strictly considered the Power Purchase as per the audited
statement of accounts. Further, since the Commission has been disallowing the
delayed payment surcharge on the power procurement bills, the same has not
been considered in the power purchase. Also, the Petitioner added that the
delayed payment surcharges billed by NTPC amounting to Rs. 85.07 Cr has
been booked in the statement of accounts under the head power purchase
expenses which has been excluded from the power purchase expenses claimed
in the ARR. Further, an amount of Rs. 17.04 Cr pertaining to the energy bills of
NHPC have been wrongly classi�ied in the statement of accounts as delayed
payment surcharge due to oversight. Since these expenses are legitimate
expenses against the power purchased from NHPC the same has been included
in the Power Purchase expenses in the ARR. The detailed statement of power
purchase as submitted by the Petitioner is tabulated below:
Table 11: Proposed Power Purchase Expenses for FY 2022-23

S No

Source

A
1
2
3
4
5
6

Long Term Sources
MePGCL
NHPC
NEEPCO
OTPC
NTPC
Solar Sources
Total Long Terms
Shot Term Purchase
Kreate Energy (IEX)

B1
1
2

APPCL (Bilateral Purchase)

MSERC Order in Case No. 36 of 2023

Quantum
Approved

Quantum
Procured

Amount
Rs. Cr

Per
Unit
Cost

1293.49
40.28
723.70
436.79
589.50
39.42
3123.18

1043.53
36.87
646.64
517.23
0.00

2244.28

241.67
17.04
402.56
149.07
4.20

814.54

2.32
4.62
6.23
2.88
0.00

0.00

27.65

2.89

1.04

0.00

9.05

21.68

3.63

6.20

Page 23 of 60

<!-- page 24 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
S No

Source

Quantum
Approved

Quantum
Procured

Amount
Rs. Cr

3
4
5

APPCL (IEX)
DSM Intra-State
DSM Inter-State
Sub-Total Purchase from Short Term
Sources

0.00
0.00
0.00

25.92
0.94
20.83
84.39

Per
Unit
Cost

7.88

32.44

3.62

B2
1
2
3
4
5

Power Swapped In
Kreate Energy (Swapping)
APPCL (Swapping)
GMRTEL (Swapping)
Manikaran (Swapping)
Subheksha (Swapping)
Sub-Total Energy Swapped In
Total Short Term
Grand Total
Transmission and Other Charges
Transmission Charges MePTCL
Transmission Charges PGCIL
POSOCO Charges
VAR Charges
Total Power Purchase Cost
Less RRAS Settlement
Net Power Puchase Cost

0.00
0.00
0.00
0.00
0.00

281.55
85.74
92.16
64.80
52.09
576.34
660.72
2905.00

0.84
0.26
0.30
0.22
0.17
1.78
34.23
848.77

0.03
0.03
0.03
0.03
0.03
0.03
0.52
2.92

1
2
3
4
5

3.6.2.

0.00
3123.18

3123.18

73.49
103.11
1.21
0.54
1027.11
-0.27
1026.84

2905.00

3.84

3.53

The Petitioner requested the Commission to allow the Power Purchase
expenses of Rs. 1026.84 Cr. for FY 2022-23 and submitted the reconciliation
as follows,

Table 12: Proposed Reconciliation of Power Purchase Expenses for FY 2022-23
Reconciliation of Power Purchase with Accounts
Power Purchase as Per Accounts
Less: Surcharge
Less: NTPC Surcharge Included
Net Power Purchase Expenses
Considered
Difference

Commission’s Analysis
3.6.3.

Amount (Rs Cr)
1113.24
1.06
85.07
1027.11
1027.11
0.00

Commission has checked the SOA as submitted by the Petitioner and veri�ied
the Power Purchase Cost. Accordingly, Commission determines the
Reconciliation of Power Purchase cost with Audited Accounts as shown below,

Table 13: Approved Reconciliation of Power Purchase Expenses for FY 2022-23
Reconciliation of Power Purchase with Accounts
Power Purchase as Per Accounts
Less: surcharge on power purchase
Less: Wheeling charges
a) MePTCL Charges

MSERC Order in Case No. 36 of 2023

Amount (Rs Cr)
1113.24
17.65
73.49

Page 24 of 60

<!-- page 25 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
Reconciliation of Power Purchase with Accounts
b) Outside party charges
Less: NTPC Surcharge Included
Add: Energy bill of NHPC wrongly added under DPS
Power Purchase Cost

Amount (Rs Cr)
103.56
85.07

Add: Transmission Charges (PGCIL)
Add: Transmission Charges (MePTCL)
Less RRAS Settlement
Net Power Purchase Cost

3.6.4.

17.04

850.51
103.11
73.49
-0.27
1026.84

Commission approves Power Purchase cost at Rs. 1026.84 Crore with an
adjustment of RRAS Settlement Cost of Rs 0.27 Cr for True up of FY 202223 as claimed by the Petitioner.

3.7. Gross Fixed Assets (GFA)
Petitioner’s Submission
3.7.1.

The Petitioner has considered the opening GFA equal to the closing GFA for FY
2021-22 as considered by the Commission in the order dated 21/11/2023 in
Case No. 01 of 2023 for Truing Up of Expenses for FY 2021-22. The addition
and deletion have been considered as per actuals based on the audited
statement of accounts. The GFA submitted by the Petitioner for FY 2022-23 is
shown in the table below:
Table 14: Proposed Gross Fixed Asset for FY 2022-23
Particular

Amount (Rs Cr)

Opening GFA

1010.19

Deletion During the Year

0.00

Addition During the Year
Closing GFA

Commission’s Analysis
3.7.2.

483.59

1493.78

In line with the Commission’s approach in previous true-up orders, the closing
Gross Fixed Assets (GFA) as approved in the True-Up Order for FY 2021-22,
amounting to Rs. 1,010.19 Crore for the has been considered as the opening
balance for FY 2022-23. The Petitioner reported addition of Rs. 483.59 Crore
during the FY 2022-23 and no Disposals/ Deduction has been considered for
FY 2022-23 as per SOA. The Commission allows the same the opening and
closing GFA for the year, consistent with the Statement of Accounts submitted
by the petitioner. The asset wise breakup for True up order of FY 2022-23 is
given below.

MSERC Order in Case No. 36 of 2023

Page 25 of 60

<!-- page 26 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
Table 15: Approved Gross Fixed Asset for FY 2022-23
(Rs. Cr)
Sl
No

Particulars

1
2
3
4
5
6
7
8
9

Land
Buildings
Plant and Equipment
Furniture and Fixtures
Vehicles
Office equipment
Others
Hydraulic Works
Other Civil Works
Lines and Cable Network
Total

10

3.7.3.

Value of Assets at
Additions
the beginning of
during the
the year
year
(01.04.2022)
1.86
0.17
13.60
31.68
106.16
118.35
0.99
0.69
2.20
1.62
0.09
3.04
881.56
331.77
1,010.19
483.59

Disposals and/
or Deductions
during the year

Asset Value at the
end of the year
(31.03.2023)

-

2.03
45.28
224.52
0.99
0.69
3.81
0.09
3.05
1,211.14
1,491.60

Commission approves Closing GFA as Rs. 1,491.60 Crore for True up of
FY 2022-23 for MePDCL.

3.8. Grant Adjustment and Funding Pattern
Petitioner’s Submission
3.8.1.

The Petitioner submitted that the accounting of the grants in the Audited
Accounts is governed by the India Accounting Standard (Ind AS 20). The
relevant extract of Indian Accounting Standard 20 is speci�ied below:

“A government grant is not recognised until there is reasonable
assurance that the entity will comply with the conditions attaching to
it, and that the grant will be received. Receipt of a grant does not of
itself provide conclusive evidence that the conditions attaching to the
grant have been or will be ful�illed.”

3.8.2.

Accordingly, the Petitioner mentioned that the above extract of the Indian
Accounting Standard 20 clearly states that the Petitioner has to account for the
grants received even if the asset against the grant is not capitalized. Hence, the
Petitioner submitted that the consideration of entire grants in the statement
of accounts against the Gross Fixed Assets would not be a correct methodology.
Further the basic accounting equation that implies that the assets are equal to
liabilities can be ful�illed only when the Commission considers the GFA and
CWIP on the asset side and the Grants, Equity and loans borrowed on the
liability side. In view of the above the Petitioner projected the Opening and
Closing Grant and the apportionment of the same in GFA as described in Para
3.9.1.

MSERC Order in Case No. 36 of 2023

Page 26 of 60

<!-- page 27 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

Commission’s Analysis
3.8.3.
3.8.1.

3.8.2.

As per the extant MSERC MYT Tariff Regulations 2014, any grant obtained for
execution of the project shall not be considered for the purpose of computation
of the capital structure for calculation of Debt & Equity and there after
Depreciation & Return on Equity.

In this regard, Commission had asked the petitioner to share the audited
certi�icated of actual year wise grant received and the utilization thereof across
various projects under the heads of GFA and CWIP along with a detailed
amortization schedule of the capitalized grants on a yearly basis, to ensure that
the components of the tariff structure can be determined more transparently
and unambiguously.
In response to the above requirement of the Commission, the petitioner has
only been able to submit their estimate of the grant utilization in the additional
capitalization executed in the current year under consideration i.e. for FY
2022-23. In reply of the Commission’s query, the Petitioner vide dated
09.10.2024, submitted the following details,
Table 16: Proposed Additional Capitalization funded through Grant for FY 2022-23

Financial
Year
FY 2022-23

3.8.3.

Additional
Capitalization
Claimed in FY
2022-23 (Rs Cr)
483.59

Additional
Capitalization funded
through Grant (Rs Cr)
368.12

Additional
Capitalization
funded through
Equity (Rs Cr)
5.65

Additional
Capitalization funded
through Debt (Rs Cr)
109.82

Due to lack of additional data at this stage with the Commission to ascertain
the exact amount of grant across each of the operational projects, for the
current context Commission has decide to follow the following principle to
determine the tariff components:
Step-1: Opening Grant:

For individual projects that have been commissioned, the Commission has
taken the opening grant for the current year i.e. FY 2022-23 as the closing
grant considered by Commission in its True up order for FY 2021-22, subject
to a maximum of the closing GFA for the respective project as has been
approved by Commission in its True up order for FY 2022-23.
Step-2: Additional Grant Capitalization:

The current year addition of grant through additional capitalization, has been
considered to be equivalent to what has been submitted by Petitioner as part
of additional submission, with the restriction that the net depreciation (i.e.,
post adjustment of yearly Grant amortization value from the yearly gross
depreciation value calculated considering the total GFA) is never negative.

MSERC Order in Case No. 36 of 2023

Page 27 of 60

<!-- page 28 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

Step-3: Closing Grant:
The Closing value of capitalized grant in individual commissioned asset is
calculated by adding the opening grant as considered in step-1 & additional
grant as considered in step-2 above.
Step-4: Additional Debt & Equity Capitalization:

3.8.4.
Sl No

1
2
3
2
3
4
5
6
7

8
9

3.8.5.
3.8.6.

The balance amount of additional capitalization in the present year after
adjustment of the current year additional grant capitalization, shall be split
into debt and in the ratio of 70% & 30% respectively.

The grant fund considered by Commission is tabulated below;
Table 17: Approved Grant Adjustment for FY 2022-23

Particular

Gross Fixed Asset (GFA)
Opening GFA
Closing GFA
Average GFA

Grant
Opening Grant
Closing Grant
Average Grant

Addition to GFA
Deduction from GFA

Add Cap funded through Grant

Addition of fresh loan for current year add-cap
(Sl No.2- Sl No.3)*70%
Addition of fresh equity for current year add-cap
(Sl No.2- Sl No.3)*30%

True up for FY
2021-22
(Approved by
Commission)
(Rs Cr)

True-Up for FY
2022-23
(Approved by
Commission)
(Rs Cr)

1007.4
2.95
0.16
1010.19
1008.80

1010.19
483.59
0.00
1491.60
1250.90

1006.98

1010.19
368.12
1,378.31
1194.25

1186.79
1096.89
-

80.83
34.64

Since the closing grant in commissioned assets for FY 2021-22 cannot be more
than the approved closing GFA, so according the same is restricted to Rs
1010.19 Cr instead of Rs 1186.79 cr. And the same is thereafter used as
opening grant for FY 2022-23.
Commission considers an average capitalized grant of Rs 1194.25 Cr. for
the True Up order of FY 2022-23.

MSERC Order in Case No. 36 of 2023

Page 28 of 60

<!-- page 29 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.9. Depreciation
Petitioner’s Submission
3.9.1.

The depreciation has been computed as per the methodology adopted by
Hon’ble Commission in the previous true ups. Further the opening balance of
GFA has been considered as per the GFA approved by Hon’ble Commission in
the order dated 21/11/2023 in Case No. 01 of 2023 in true up of 2021-22. The
calculation of depreciation is tabulated below.
Table 18: Proposed Calculation of Depreciation of 2022-23
As on
31st
March
2023
(Rs
Cr)

Asset
Details

As on
1st April
2022
(Rs Cr)

Additions
(Rs Cr)

Disposals /
deductions
(Rs Cr)

Land

1.86

0.17

0.00
0.00

224.52

165.35

0.00

0.69

0.69

Buildings

13.60

31.68

Plant and
Equipment

106.18

118.35

Vehicles

0.69

0.00

Furniture
and Fixtures
Office
equipment
Others

Hydraulic
Works

Other Civil
Works
Lines and
Cable Network
Total

0.99

Depreciation
on Grants

45.28

0.00%

0.00

5.28%

8.73

29.44

3.34%

0.98

0.99

6.33%

0.06

0.00

2.20

1.62

0.00

3.81

3.00

6.33%

0.19

0.09

0.00

0.00

0.09

0.09

5.28%

0.00

881.56

331.77

0.00

1211.14

1046.35

5.28%

55.25

3.05

1010.20

0.00

483.59

0.00

0.00

0.99

1.94

Depreciation Depreciation
(Rs Cr)
Rate

0.00

Rate of
Depreciation

Average Grants
in GFA

0.00

2.03

Average
GFA
(Rs Cr)

3.05

1491.60

3.05

1250.90

9.50%

3.34%

0.07

0.10

65.39

5.23%

615.77

Claim of
Depreciation

MSERC Order in Case No. 36 of 2023

32.19

33.20

Page 29 of 60

<!-- page 30 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.9.2.

The Petitioner requested the Commission to allow the depreciation of Rs.33.20
Cr as for FY 2022-23.

Commission’s Analysis
3.9.3.
3.9.4.

Commission observed that the Petitioner has claimed the depreciation of Rs.
33.20 crore after adjusting the average grant of Rs. 615.77 Crore which is
basically adjusted grant in proportion to GFA and CWIP based on Closing GFA
approved in previous True-Up Order dated 13.11.2023.
As per the Regulation 33 of MSERC Regulations 2014:

“33.1 For the purpose of tariff determination, depreciation shall be
computed in the following manner:
a) The asset value for the purpose of depreciation shall be the
historical cost of the assets as approved by the Commission where:
The opening asset’s value recorded in the Balance Sheet as per the Transfer
Scheme Noti�ication shall be deemed to have been approved, subject to such
modi�ications as may be found necessary upon audit of the accounts, if such
a Balance Sheet is not audited. Consumer contribution or capital
subsidy/ grant etc shall be excluded from the asset value for the
purpose of depreciation.
….
c) The salvage value of the assets shall be considered at 10% and
depreciation shall be allowed upto maximum of 90 % of the capital
cost of the asset.

Depreciation shall be calculated annually as per straight-line method at
the rates speci�ied in CERC (Terms and Conditions of Tariff) Regulations,
2009 as may be amended from time to time.
Provided that land is not a depreciable asset and its cost shall be
excluded from the capital cost while computing the historical cost of
the asset
…..”
<Emphasis added>
3.9.5.

Accordingly, the Commission observed that the Govt. Grants and contributions
are infused under the Additional Capitalization during the year FY 2022-23 is
Rs 368.12 Cr and Opening Grant available with the licensee has been
considered as Rs 1010.29 Cr Govt, as detailed out in Paragraph 3.9.5 of this
order. Based on the asset wise Depreciation Rate, the Commission determined
the Gross Depreciation over 90% of the Average Asset. Moreover, the
Commission computed the Amortization of “Consumer contribution and
Grants” on the basis of the calculated ‘Weighted Average Rate of Depreciation’

MSERC Order in Case No. 36 of 2023

Page 30 of 60

<!-- page 31 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

as 5.07% for FY 2022-23 and deducted 90% of Amortization of Grants from
the Gross Depreciation and Accordingly, the Net depreciation approved for FY
2022-23 is as follows;
Table 19: Approved Computation of Depreciation for FY 2022-23

Asset Details

Land

Buildings

Opening
GFA
(Rs Cr)

Additions
(Rs Cr)

1.86

0.17

13.60
0.69

0.00

Others

0.00

2.03

1.95

0.00

0.00%

0.00

5.28%

7.86

0.00

Vehicles

2.20

Depreciation
Rate

Amount
of
Deprecia
tion
(Rs Cr)

0.00

118.35

Of�ice equipment

90% of
GFA
(Rs Cr)

0.00

106.16
0.99

Average
GFA
(Rs Cr)

31.68

Plant and Equipment

Furniture and Fixtures

Retirements
(Rs Cr)

Closing
GFA
(Rs Cr)

1.62

45.28

29.44

26.49

0.00

224.52

165.34

148.81

0.00

0.69

0.69

0.62

0.00

0.99
3.81

0.99
3.01

3.34%

0.89

6.33%

0.06

2.71

6.33%

0.17

9.50%

Hydraulic Works

0.09

0.00

0.00

0.09

0.09

0.08

5.28%

Lines and Cable Network

881.56

331.77

0.00

1211.14

1046.35

941.72

5.28%

Other Civil Works
Total

3.04

1010.19

0.00

483.59

Average assets

Grant Capitalized during
the Year
Closing Grant

1010.19

368.12

Average Grants in GFA
90% of Average Grant in
GFA
Less : Depreciation on
90% of Avg Grants and
contributions
Net Depreciation for the
year
(+) 1/3rd Dep on MeECL
assets
Net depreciation for FY
2022-23

3.9.6.

0.00

3.05

1491.60

3.04

1250.90

2.74

1124.06

1250.90

Rate of Depreciation
Opening Grant

0.00

1378.31

0.88

3.34%

0.06
0.00
0.09

49.72

58.85

5.24%

1194.25

1074.82

56.27
2.58
0

2.58

Commission approves Depreciation as Rs. 2.58 Crore for True up of FY
2022-23 for MePDCL.

MSERC Order in Case No. 36 of 2023

Page 31 of 60

<!-- page 32 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.10. Return on Equity
Petitioner’s Submission
3.10.1.

The Petitioner submitted that it calculated the return on equity in line with the
provisions of Regulation 27 of the 2014 Tariff Regulations and the capital
structure presented in the paragraph 3.9.2 of this order. The calculation of
Return on Equity as submitted by the Petitioner is tabulated below,
Table 20: Proposed Return on Equity for FY 2022-23
Particulars
Opening Equity

127.59

Average Equity

158.85

Return on Equity

22.24

Closing Equity

Rate of Return on Equity

Commission’s Analysis
3.10.2.
3.10.3.

Amount (Rs Cr)
190.12
14%

Commission observed that the Petitioner has claimed the Return on Equity of
Rs. 22.24 crore which is basically based on Apportionment methodology the
Petitioner followed on its Capital Structure and the proportion of Opening GFA
as approved in previous True-Up Order dated 13.11.2023.
The Return on Equity shall be computed as per Regulation 31 read with
Regulation 27 of Meghalaya State Electricity Regulatory Commission (Multi
Year Tariff) Regulation, 2014. The relevant Regulations 33 is reproduced as
under,

“33.1 Return on equity shall be computed on the equity base determined
in accordance with regulation 27 and shall not exceed 14%.
….”

<Emphasis added>
3.10.4.

Further, Regulation 27 of the Meghalaya State Electricity Regulatory
Commission (Multi Year Tariff) Regulation, 2014 states the following,
“27 Debt-Equity Ratio

27.1 For a project declared under commercial operation on or after 1.4.2015,
if the equity actually deployed is more than 30% of the capital cost, equity in
excess of 30% shall be treated as normative loan;
Provided that where equity actually deployed is less than 30% of the capital
cost, the actual equity shall be considered for determination of tariff.

MSERC Order in Case No. 36 of 2023

Page 32 of 60

<!-- page 33 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

Provided further that equity invested in foreign currency shall be designated
in Indian rupees on the date of each investment.
Provided any grant obtained for execution of the project shall not be
considered as a part of capital structure for the purpose of debt-equity
ratio.
……”
<Emphasis added>
3.10.5.

The Commission has accordingly allowed a Return on Equity (RoE) at 14% on
the normative equity, calculated based on the approved average GFA, excluding
the average grants and contributions as outlined in para 3.9.2. The approved
equity and RoE for FY 2022-23 are as follows,
Table 21: Approved Return on Equity for FY 2022-23

Particulars

3.10.6.

Opening GFA
Addition
Retirements
Closing GFA
Average GFA
Less: Average Grants
Net Average Asset (not funded through grants)
Average 70% Debt component
Average 30% Equity component
Rate of Return on Equity (%)
Return on Equity @ 14%

Amount (Rs Cr)
1,010.19
483.59
1,491.60
1,250.90
1,194.25
56.65
39.65
16.99
14%
2.38

Commission approves Return on Equity as Rs. 2.38 Crore for True up of
FY 2022-23 for MePDCL.

3.11. Interest on Loan
Petitioner’s Submission
3.11.1.
3.11.2.

In view of the MYT Regulations 2014, the Petitioner submitted that since the
Commission has restricted the equity to 30% of the GFA, the Petitioner
considered the normative loan (70% of the GFA less grants in GFA and equity
in GFA) as opening balance for the purpose of calculating the interest on loan.

Further, the Petitioner added that since the Commission has been considering
the actual repayment of loan in the previous years, the total repayment made
till date has been considered as cumulative repayment for arriving at net
normative loan. The addition in the normative loan has been considered in
proportion to the capitalization during the year and the repayment has been
considered at actuals. The interest booked in the statement of account against
each of the actual loan has been considered for the purpose of arriving at the
weighted average rate of interest. This weighted average rate of interest has

MSERC Order in Case No. 36 of 2023

Page 33 of 60

<!-- page 34 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.11.3.

been used for calculating the interest on loan by multiplying it with the average
normative loan. The other �inancing charges such as guarantee fees have been
claimed as per actuals in the audited statement of account.

Accordingly, the Petitioner submitted that the Interest on loan has been
computed as per the provisions of Regulations 27 and Regulation 32 of the
2014 Tariff Regulations. The weighted average rate of interest has been
computed on the actual loans running as tabulated below,

Table 22: Proposed Computation of Weighted Average Rate of Interest for FY 2022-23
S
No.

Details of Loan

Opening
Balance

Fresh
Drawl

Repayment

1

Restructured REC
Loan

9.55

0

6.07

82.36

0

0.00

2

PFC Loan RAPDRP A

33.89

4

PFC Loan IPDS

5.19

3

PFC Loan RAPDRP B

WAROI

3.11.4.

0

0

130.99

Closing
Balance

Average
Loan

Interest in
2022-23 as
Per SOA

Rate of
Interest

3.48

6.52

0.22

3.44%

82.36

7.41

9.00%

0.00

33.89

33.89

0.37

4.82

5.00

6.44

82.36

124.55

127.77

3.05

9.00%

0.54

10.80%

11.23

8.79%

The calculation of interest on loans as submitted by the Petitioner is provided
below:

Table 23: Proposed Computation of Normative Interest on Loan for FY 2022-23
Particular

Amount (Rs Cr)

Gross Normative Loan-Closing

297.71

Net Normative Loan-Opening

211.77

Repayment

6.44

Cumulative Repayment
Addition

85.94

145.49

Net Normative Loan-Closing

350.82

Weighted Average Rate of Interest
Interest on Loan

8.79%

Other Financing Charges

8.16

Average Normative Loan-Closing

Total Interest and Financing Charges

MSERC Order in Case No. 36 of 2023

324.26
28.49

36.65

Page 34 of 60

<!-- page 35 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

Commission’s Analysis
3.11.5.

As per the Regulation 32.1 and 32.2 of MSERC Regulations 2014:

32.1 Interest and �inance charges on loan capital shall be computed on the
outstanding loans, duly taking into account the schedule of loan
repayment, terms and conditions of loan agreements, bond or
debenture and the lending rate speci�ied therein.
Provided that the outstanding loan capital shall be adjusted to make it
consistent with the loan amount determined in accordance with
regulation 27.
32.2 The interest and �inance charges attributable to capital work in
progress shall be excluded.
Provided that neither penal interest nor overdue interest shall be allowed
for computation of tariff.
<Emphasis added>

3.11.6.

Further Regulation 27 of the 2014 Tariff Regulations states that:

“27.1 For a project declared under commercial operation on or after
1.4.2015, if the equity actually deployed is more than 30% of the
capital cost, equity in excess of 30% shall be treated as normative
loan;
Provided that where equity actually deployed is less than 30% of the capital
cost, the actual equity shall be considered for determination of tariff.”
<Emphasis added>

3.11.7.

Accordingly, the Commission directed the Petitioner to submit Actual Loan
Pro�ile duly certi�ied by Auditor in a speci�ic tabular format and in response,
the Petitioner submitted the below details,
Table 24: Proposed Actual Loan Portfolio for FY 2022-23

As on
01.04.2022

Sl.No.

1
2
3
4
5

Particulars

REC
Reschedulement
PFC 325crs
PFC IPDS Loan
PFC
Atmanirbhar
REC
Atmanirbhar

Loan
Outstanding
(Rs)
95,500.14

27,58,468.96
51,881.64

During the Year
Loan
Withdrawal
(Rs)

-

55,06,775.00
55,06,775.00

MSERC Order in Case No. 36 of 2023

As on 31.03.2023

Principal
due during
the year
(Rs)

Rate of
Interest
(%)

Interest
accrued
during the
year
(Rs)

Loan
Outstanding
(Rs)

77,289.29

8.00%

2,243.68

34,800.24

4,64,285.71
3,782.60

12.65%
11.15%
9.50%
9.50%

3,10,242.01
5,399.85

5,29,367.97
5,58,685.49

21,78,111.82
48,161.64

55,06,775.00
55,06,775.00

Page 35 of 60

<!-- page 36 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
As on
01.04.2022

Sl.No.

6
7
8

Particulars

PFC RAPDRP
Part A
PFC RAPDRP
Part B
State
Government
Loan
Total

3.11.8.

Loan
Outstanding
(Rs)

During the Year
Loan
Withdrawal
(Rs)

Principal
due during
the year
(Rs)

1,21,940.00

17,54,458.10

1,68,36,422.84

Rate of
Interest
(%)

Interest
accrued
during the
year
(Rs)

Loan
Outstanding
(Rs)

9.00%

30,504.60

1,21,940.00

9.00%

10,40,624.00

-

5,45,357.60

As on 31.03.2023

74,126.16

10,40,624.00

15,40,704.11

1,61,91,645.80

30,134.37

17,54,458.10

In the previous True-up order dated 13.11.2023, Commission had quoted that,
“2.5.
….
Licensee has been projecting outstanding loans against the R-APDRP-A and
R-APDRP- B schemes through the Audited accounts. The R-APDRP A&B
Scheme provides that loans drawn were to be utilized to strengthen the
network of the licensee and achieve the loss Reduction. As soon as the
objective has been achieved the licensee should have submitted proposal
for conversion of loans as Grant through the state government.
The Licensee has been utilizing the borrowed money under the R-APDRPA&B schemes for the infra structural works contemplated to achieve loss
reductions and network ef�iciency for the period FY 2015-16 to FY 2020-21
and Commission has been allowing interest cost in the True up process.
….
Commission considers that the Licensee has failed to submit the proposals
for conversion of loans as grant through the State Govt. along with the
project appraisals as envisaged in the sanction of funding by the Ministry
of power, Govt. of India.
It is imperative that the interest so far allowed in the Tariffs as detailed in
the statement shall be a surplus of approved True up ARR which could be
considered claw back from the future interest liabilities.

3.11.9.

Commission does not consider allowance of interest in the true up ARR
against the outstanding loans availed from PFC for improvement of
network ef�iciency to reduce the AT&C losses contemplated in the RAPDRP
A&B projects.”

In view of the above, Commission disallowed the interest on R-APDRP – A and
R-APDRP – B loans for FY 2022-23. Additionally, Commission has disallowed

MSERC Order in Case No. 36 of 2023

Page 36 of 60

<!-- page 37 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.11.10.

the loan on account of Atmanirbhar Bharat Abhiyan Scheme for the Petitioner
has not shared any relevant document w.r.t utilization of the same in the core
Distribution Business.
In consideration of the above, Commission has approved the Weighted Average
Rate of Interest based on the Actual Loan Portfolio submitted by petitioner as
follows,

Table 25: Approved Computation of Weighted Average Rate of Interest for FY 2022-23
S
No.
1
2
3
4
5
6

Details of Loan
8% Restructured
REC Loan
9% PFC Loan RAPDRP A
9% PFC Loan RAPDRP B
12.65% PFC Loan /
PFC 325crs
11.15% PFC Loan
IPD Scheme
State Government
loan Semi Annual
Repayment
Total

3.11.11.

Opening
Balance
(Rs Cr)

Addition
during
the Year
(Rs Cr)

9.55

Repayment
(Rs Cr)

Closing
Balance
(Rs Cr)

Average
Loan
(Rs Cr)

Interest
Cost
(Rs Cr)

0

7.73

3.48

6.52

0.22

104.06

0

0.00

104.06

104.06

0.00

5.19

0

0.38

4.82

5.00

12.19

275.85
175.45

582.29

0

0
0

0.00

46.43

54.54

12.19

217.81
175.45

517.81

12.19

0.00

246.83

31.02

175.45

3.01

550.05

Wt.
Average
Rate of
Interest
(%)

0.54

34.80

6.33%

For calculation of the actual interest on loan admissible to Petitioner through
ARR, Commission had considered the Approved Closing Loan Balance of the
previous True-up order for FY 2021-22 as Normative Opening Loan Balance of
FY 2022-23 i.e. Rs 107.43 Cr. and the Addition of loan equal to 70% of ‘Net
Addition to GFA’ after deducting the ‘Addition of Grant in GFA’ during the Year
as detailed out in Para 3.9.7 i.e. Rs 80.83 Cr. Further, the Normative Repayment
of Loan during the year has been considered equivalent to the net Depreciation
for the �inancial year of FY 2022-23 i.e. Rs 2.58 Cr. Accordingly, Commission
computes the Normative Interest on Loan and approves Rs 12.74 Cr as shown
in the table below,

Table 26: Approved Computation of Normative Interest on Loan for FY 2022-23

Particular
Net Normative Loan-Opening
Addition
Repayment
Net Normative Loan-Closing
Average Normative Loan
Weighted Average Rate of Interest
Interest on Loan
Other Financing Charges

MSERC Order in Case No. 36 of 2023

True-Up for FY
2022-23
(Claimed by
Petitioner)
(Rs Cr)
211.77
145.49
6.44
350.82
324.26
8.79%
28.49
8.16

True-Up for FY
2022-23
(Approved by
Commission)
(Rs Cr)
107.43
80.83
2.58
185.68
146.56
8.70%
12.74
0.00

Page 37 of 60

<!-- page 38 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

Particular
Total Interest and Financing Charges

3.11.12.

True-Up for FY
2022-23
(Claimed by
Petitioner)
(Rs Cr)
36.65

True-Up for FY
2022-23
(Approved by
Commission)
(Rs Cr)
12.74

Commission approves Interest and Finance charges at Rs. 12.74 Crore for
True up of FY 2022-23.

3.12. Operation and Maintenance Expenses
Petitioner’s Submission
3.12.1.

The Petitioner submitted that as per the settled practice followed by the
Commission in past the operation and maintenance expenses have been
claimed as per the audited accounts of FY 2022-23. The details of operation
and maintenance expenses are tabulated below:
a. Employee Expenses

Employee expenses have been claimed as per the audited accounts. Petitioner
further reiterated that the actuarial valuation for the FY 2022-23 has already
been done and the terminal bene�its have been accounted in the accounts as
per the same.
Table 27: Proposed Employee Expenses for FY 2022-23

S
No

Particular

Amount
(Rs. Cr.)

1

Salaries and Wages

147.35

3

Leave Encashment Expenses

22.41

Contribution to PF

6.50

2
4
5
6

Gratuity Expenses
Pension Expenses

6.05

44.33

Apportionment of Employee Benefit of Holding Company
Total

238.56

1/3rd of Employee Expenses of MeECL

1.62

Total

11.92

240.18

The Petitioner requested the Commission to allow the employee expenses of
Rs. 240.18 Cr for FY 2022-23.

MSERC Order in Case No. 36 of 2023

Page 38 of 60

<!-- page 39 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

b. R&M Expenses
R&M expenses have been claimed as per the audited statement of accounts.
The MeECL expenses have been apportioned in the three companies in equal
proportion.
Table 28: Proposed R&M Expenses for FY 2022-23

S No

Particular

Actual in Rs. Cr.

1

Buildings

0.16

3

Civil Works

0.04

5

Vehicles

2
4
6
7

Plant and Equipment

1.64

Lines and Cables

4.07

Furniture and Fixtures

0.04

0.11

Office Equipment
Total

6.28

1/3rd of MeECL

0.34

Total R&M Expenses

0.22

6.62

The Petitioner requested the Commission to allow the R&M expenses of
Rs.6.62 Cr for FY 2022-23
c. A&G Expenses

In line with the claims of the employee expenses and R&M expenses the A&G
expenses have also been claimed by the Petitioner as per the statement of
accounts. The Petitioner has apportioned A&G expenses of MeECL in the three
companies in equal proportion.

The Petitioner further submitted that the A&G expenses of MeECL also
includes the penalty of Rs.1.21 Cr which has been excluded from the claim.
Table 29: Proposed A&G Expenses for FY 2022-23

S No. Particular
1

Insurance Expenses

3

Billing Software Expenses

2
4

Rent, Rates and Taxes

Amount (Rs Cr)
0.02

0.09

4.12

Postage Expenses

0.15

6

Printing and Stationary

0.38

8

Consultancy Charges

5
7

Training and Conveyance
Auditor's Remuneration

MSERC Order in Case No. 36 of 2023

8.37

0.06

0.31

Page 39 of 60

<!-- page 40 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
S No. Particular
9

License and Registration Charges

Amount (Rs Cr)
0.00

10

Technical Fees

0.02

12

Fee and Subscription

0.00

Legal and Professional Charges

0.61

11
13
14
15

Books and Periodicals
Advertisement

0.15

Meter Reading Expenses

0.00

Electricity and Water Charges

18

Franchisee Commission

19

0.19

MSERC Fees

16
17

0.00

0.53

0.84

Franchisee Transmission Loss

1.03

21

Stamp Duty

0.01

23

GST Expenses

25

Entertainment Expenses

20
22
24
26
27

Discount Allowed

0.25

Bank Charges

0.13

ROC Charges

0.01

0.01

0.01

Compensation for Injuries
Misc. Expenses

0.13

Total

17.60

1/3rd of MeECL Expenses

0.61

Grand Total

0.17

18.21

The Petitioner requested the Commission to allow the A&G expenses of
Rs.18.21 Cr for FY 2022-23
Commission’s Analysis
a. Employee Expenses
3.12.2.
3.12.3.

Commission observed that the Petitioner had reported Employee bene�it
expenses at Rs.238.56 Crore vide note no.27 of SoA for FY 2022-23.

Commission considered the Employee Bene�it Expenses for the Petitioner
including the 1/3rd of share of Employee Bene�it expenses of holding company
as per note no. 23 of MeECL and approved the Employee Expenses of Rs
240.18 Cr as on Actual Basis.

MSERC Order in Case No. 36 of 2023

Page 40 of 60

<!-- page 41 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

b. R&M Expenses
3.12.4.

Commission observed that the Petitioner had reported total R&M Expenses
vide note no.30 of SoA of FY 2022-23 for MePDCL and note no.26 of SoA of
MeECL for FY 2022-23. Hence, the R&M expenses projected for True up of
FY 2022-23 is Rs.6.62 Crore found to be admissible, and Commission
approves the same on actual basis.
c. A&G Expenses

3.12.5.
3.12.6.

Commission considered that as reported by Petitioner vide note no.30 of SoA
for FY 2022-23, the A&G expenses projected for True up of FY 2022-23 at
Rs.17.60 Crore includes Franchisee Transmission loss for Rs.1.03 Crore
which shall not be considered.

Hence, Net Admissible A&G expenses shall be Rs.16.57 Crore for MePDCL and
1/3rd share of MeECL Adm General expenses as claimed in the petition for
Rs.0.61 Crore is allowed for True up of FY 2022-23 and the Net A&G expense
allowed is detailed in the table below,
Table 30: Approved A&G Expenses for FY 2022-23

3.12.7.

Particulars
A&G Expenses claimed by MePDCL
Less: Franchisee Transmission Loss
Add: 1/3rd A&G expenses of MeECL
Total A&G expenses

Accordingly, the O&M expense approved vis-à -vis claimed by the Petitioner is
shown in the table below,
Table 31: Approved O&M Expenses for FY 2022-23

Particulars

3.12.8.

Amount (Rs.Cr)
17.60
1.03
0.61
17.18

Employee expenses
R&M Expenses
A&G expenses
Total O&M expenses

Amount (Rs.Cr)
(Claimed by
Petitioner)
240.18
6.62
18.21
265.01

Amount (Rs Cr)
(Approved by
Commission)
240.18
6.62
17.18
263.98

Commission approves O&M Expenses at Rs. 263.98 Crore for True up of
FY 2022-23.

3.13. Interest on Working Capital
Petitioner’s Submission
3.13.1.
3.13.2.

Petitioner submitted that Regulation 34.3 of the 2014 Tariff Regulation details
out the methodology of the computation of the Interest on Working Capital for
distribution business.
As per the Regulation 34.3.

MSERC Order in Case No. 36 of 2023

Page 41 of 60

<!-- page 42 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

“34.3 Distribution Business

(i) The Distribution Licensee shall be allowed interest on the estimated
level of working capital for the Distribution Business for the �inancial
year, computed as follows:
Operation and maintenance expenses for one month; plus
Maintenance spares at one (1) per cent of the historical cost escalated at
6% from the date of commercial operation; plus
Receivables equivalent to two (2) months of the expected revenue from
charges for use of Distribution at the prevailing tariffs; minus
Interest shall be allowed at a rate equal to the State Bank Advance Rate”
3.13.3.

In line with the provisions of the above Regulations, the Petitioner computed
the interest on working capital which is tabulated below. The State Bank of
India Advance Rate as on 01.04.2022 has been considered for the purpose of
computation of the interest on working capital.

Table 32: Proposed Computation of Interest on Working Capital for FY 2022-23
S No.

Particular

Claimed for
FY 2022-23
(Rs Cr)

1

O&M Expenses (1 month)

22.08

3

Receivables (2 Months)

182.25

5

Rate of Interest

2
4
6

Maintenance Spares

Total Working Capital Requirement
Interest on Working Capital

5.73

210.07

12.30%
25.84

Commission’s Analysis
3.13.4.

As per Regulation 34.3 of MYT MSERC Regulations 2014,

“The Distribution Licensee shall be allowed interest on the estimated level of
working capital for the Distribution Business for the �inancial year,
computed as follows:
•
•
•

Operation and maintenance expenses for one month; plus
Maintenance spares at one (1) per cent of the historical cost escalated
at 6% from the date of commercial operation; plus
Receivables equivalent to two (2) months of the expected revenue from
charges for use of Distribution at the prevailing tariffs; minus

Interest shall be allowed at a rate equal to the State Bank Advance Rate
(SBAR) as on 1st April of the �inancial year in which the Petition is �iled.”
MSERC Order in Case No. 36 of 2023

Page 42 of 60

<!-- page 43 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.13.5.

Accordingly, the Commission computed the Interest on working capital as
depicted in the table below,

Table 33: Approved Computation of Interest on Working Capital for FY 2022-23

Sl No.

Particulars

1

O&M expenses for 1 Month

2

3
4
5
6

3.13.6.

Maintenance Spares at *1% of Opening GFA escalated at 6%
Receivables for 2 Months (Net ARR*2/12)
Total Working Capital
Interest Rate (%) (SBIAR as on 01.04.2022)
Interest on Working Capital

Approved for
FY 2022-23
(Rs Cr.)
22.00
10.71

178.24
210.94
12.30%
25.95

Commission approves Interest on Working Capital at Rs. 25.95 Crore for
True up of FY 2022-23.

3.14. Revenue From Sale of Surplus Power
Petitioner’s Submission
3.14.1.

The Petitioner submitted that the Revenue from sale of surplus power has
been claimed as per the audited statement of accounts. The details of revenue
from sale of surplus power are tabulated below,
Table 34: Proposed Revenue from sale of surplus power for FY 2022-23

Particular

3.14.2.

Sale of Power On IEX
Inter State DSM Charges
Total

MU

Amount
(Rs.Cr)

Rate Discovered
(Rs./kWh)

110.34
35.66
146.00

54.77
19.54
74.31

4.96
5.48
5.09

Further, the Petitioner mentioned that it had entered into swapping
arrangements where in the Petitioner provides return power in lieu of the
power swapped depending on the availability of surplus and de�icit in the
power. The ratio of return is generally 1:1.05. The Petitioner further
emphasized that these transactions do not have any monetary value as they
are settled in terms of energy only. The details of swapping return are provided
below,
Table 35: Proposed Details of Swapping Return During FY 2022-23
Particular
Kreate Energy (Swapping)
APPCL (Swapping)
GMR Energy (Swapping)
Manikaran (Swapping)
SAPL (Swapping)
Total

MSERC Order in Case No. 36 of 2023

MU
290.99
99.09
29.23
58.25
24.09
501.66

Page 43 of 60

<!-- page 44 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.14.3.

The Petitioner requested the Commission to approve the revenue from sale
of surplus power as Rs.74.31 Cr for FY 2022-23

Commission’s Analysis
3.14.4.
3.14.5.

Commission observed that the Petitioner has submitted Revenue from sale of
surplus power at Rs.74.31 Core for 146 MU sold under UI & IEX which is also
reported through audited accounts vide note no.24 found to be acceptable.
Commission approves Revenue from sale of surplus power at Rs.74.31
Crore for True up of FY 2022-23.

3.15. Non-Tariff and Other Income
Petitioner’s Submission
3.15.1.

The Petitioner submitted that the Non-Tariff Income has been considered as
per the audited statement of account with following exclusions,

i. Amortization of grants shown in the audited accounts in non-tariff income
has been excluded from the claim as the entire movement in grants has
been considered at the time of calculation of return on equity and
depreciation. Since the amortization of grants is not an actual income and
has been accounted in the statement of accounts for the purpose of the
complying with the relevant accounting standards issued by ICAI hence
the same is not in the nature of revenue.
ii. Grants received under UDAY scheme shown under the head other income
in the books of accounts are the grants provided by the Government of
India for improving the �inancial viability of the DISCOM and does not
classify as the capital grants. Hence, these grants are not for the purpose
of passing on the bene�it of the same to the consumers. Revenue grants are
provided to meet the gap between the cost that is being recovered from
the tariff and actual cost incurred, hence if these grants are considered as
reduction from ARR the purpose of these grants is defeated.

iii. The Petitioner submitted that the Commission has been considering the

delayed payment surcharge as accounted in the books of accounts.
However, MePDCL would like to submit that the delayed payment
surcharge accounted in books of account is the amount that has been billed
to consumers and not the actual amount collected from them. Hence, the
delayed payment surcharge actually collected from the consumers in FY
2022-23 has been considered as Non-Tariff Income.

3.15.2. The details of the Non-Tariff Income for FY 2022-23 is tabulated below,
MSERC Order in Case No. 36 of 2023

Page 44 of 60

<!-- page 45 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
Table 36: Proposed Details of Non-Tariff Income for FY 2022-23
S No Particular
A

From Banks

2.57

Sub-Total A

2.57

From Others

0.00

Other Non-Operating Income
Rental and Hiring Income

0.00

Sale of scrap, tender forms and others

0.05

Fees and Penalties

0.00

Miscellaneous receipts

7.60

Revenue Grants for UDAY

0.00

Revenue Grants for Other Expenditures
Sub-Total B
C

(Rs. Cr.)

Other Income
Interest Income

B

Amount

0.09

7.74

Other Operating Income
Meter Rent

8.57

Delayed Payment Charges Collected From Consumers

20.29

Other Charges From Consumers
Cross Subsidy Surcharge

19.14

Sub-Total C

60.49

Grand Total

70.80

Reconnection Fees

Rebates on Purchase of Energy

0.00

4.91

7.58

Commission’s Analysis
3.15.3.
3.15.4.
3.15.5.

Commission observed that the Petitioner has reported Non-Tariff and Other
income and Cross subsidy surcharge vide note no. 24, 24.2 and 25 of Statement
of Accounts of MePDCL.

The Other income of MeECL as reported in Note no. 22 of Audited Accounts is
Rs.9.49 Crore, out of which, Rs.0.38 Crore representing the share of subsidiary
companies (share of MePGCL amounted to Rs.0.10 Crore + share of MePTCL
amounted to Rs.0.09 Crore + share of MePDCL amounted to Rs.0.20 Crore).

The balance Rs.9.11 Crore (Rs 9.49 Cr – Rs 0.38 Cr) shall be shared among
three subsidiary companies equally i.e. Rs.3.04 Crore shall be apportionable to
MePDCL. Accordingly, the Revenue from other income corresponding to

MSERC Order in Case No. 36 of 2023

Page 45 of 60

<!-- page 46 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.15.6.

MeECL amounted to Rs.3.24 Crore in total, must be included under Non-Tariff
Income of MePDCL.

Accordingly, the Commission approved the Non-Tariff Income as tabulated
below:
Table 37: Approved Details of Non-Tariff Income for FY 2022-23

S No

Particular

A
1
2
3
4
B
5
6
7
8
9
10
11
12
13
14
C
15
16
17

Other Income
Interest Income
From Banks
From Others
Sub-Total A
Other Non-Operating Income
Rental and Hiring Income
Fees and Penalties
Sale of scrap, tender forms and others
Miscellaneous receipts
Amortization of Grants and Subsidies
Amortization of Consumer Contributions
Refund of surcharge from NEEPCO
Revenue Grants for Other Expenditures
Revenue Grants for UDAY
Sub-Total B
Other Operating Income
Meter Rent
Reconnection Fees
Delayed Payment Charges Collected From Consumers

18
19
20
21

D

3.15.7.

3.15.8.

Rebates on Purchase of Energy
Other Charges From Consumers
Cross Subsidy Surcharge
Sub-Total C
The Other Income from MeECL apportioned share
reported in note no.22 of audited accounts (C) (Rs.
0.20 Cr + Rs. 3.04 Cr)
Grand Total

Amount (Rs Cr)
(Approved)

2.57
0.002
2.57
0.002
0.001
0.05
7.60
0.00
0.00
0.00
0.09
0.00
7.74
8.57
0.004
36.83

4.91
19.14
7.58
77.03
3.24
90.58

The Petitioner submitted that it has received Rs 100 Crore grant from Govt. of
Meghalaya under the Uday scheme to mitigate their balance sheet losses. It is
an established fact that the scheme of Uday was constituted to facilitate
reduction of the pending losses of the state Distribution utilities. Thus, in the
present case Commission has considered not to deduct the receipt of Rs 100
Cr. received by the MePDCL from Govt. of Meghalaya under the extant Uday
scheme while calculating the total Non-Tariff Income.
Commission approves Non-Tariff and Other Income at Rs. 90.58 Crore
for True up of FY 2022-23.

MSERC Order in Case No. 36 of 2023

Page 46 of 60

<!-- page 47 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.16. Computation of AT&C losses
Petitioner’s Submission
3.16.1.

3.16.2.

3.16.3.

The Petitioner submitted that it has adopted the settled practice followed by
the Commission in the previous years. Further, the Petitioner added that since
the energy sold to distribution franchisee as the input energy hence technically
there are no losses involved there. Accordingly, the sales of 1781.35 MU has
been considered for calculation of AT&C losses. Further, the opening debtors
and closing debtors have been considered as per the statement of accounts for
computation. Further, the sub-transmission losses and auxiliary consumption
have been considered as per the methodology adopted in the calculation of
T&D losses.
The computation of the AT&C losses is tabulated below,

Table 38: Proposed Computation of AT&C Losses for FY 2022-23

S No
1
2
3
4
5
6
7
8
9
10
11

Particular
Legend
Input Energy (MU)
A
Transmission Losses (MU)
B
Net Input Energy (MU)
C=(A-B)
Energy Sold (MU)
D
Revenue from Sale of Power (Rs. Cr.)
E
Adjusted Revenue (Rs. Cr)
F
Opening Debtors (Rs Cr)
G
Closing Debtors (Rs. Cr.)
H
I=(F+G-H)/E
Collection Ef�iciency (%)
Units Realized (MU)
J=I*D
Units Un Realized (MU)
K=C-J
AT&C Loss (%)
L=K/C

Value
2257.34
213.73
2043.62
1781.35
1093.51
1093.51
444.68
593.46
86.39%
1538.98
504.64
24.69%

The Petitioner requested the Commission to allow the AT&C losses for FY
2022-23 as 24.69%.

Commission’s Analysis

3.16.4.

The Commission observed the AT&C loss computation arrived at in the Format
D2 (A) as submitted by the Petitioner in Additional Information 2.
Format-D2 (A)

Information regarding Distribution Loss and AT & C Loss of Licensee FY 2022-23
SI.
No
1
2

Particulars
Generation (own as well as any other
connected generation, net after deducting
auxiliary consumption) within area of supply
of
DISCOM
Input energy (metered import) received at
interface points of DISCOM network

MSERC Order in Case No. 36 of 2023

Calculation

Unit

Previous Years
FY 2021-22
(Actuals)

Current Year
FY 2022-23
(R.E)

A

MU

2428.80

2905.00

B

MU

2343.40

2691.27

Page 47 of 60

<!-- page 48 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

SI.
No
3
4
5
6
7
8
9

10

11
12
13

Particulars

Calculation

Unit

Previous Years
FY 2021-22
(Actuals)

Input Energy (metered Export) by the
DISCOM at interface point of DISCOM
C
MU
network including
balance surplus energy
Total energy available for sale within the
licensed area to the consumers of the DISCOM
D=B-C-4%
MU
periphery
Energy billed to metered consumers within the
E
MU
licensed area of the DISCOM
Energy billed to unmetered consumers within
F
MU
the licenses area of the DISCOM
G=E+F
MU
Total Energy billed
Amount billed to consumer within the
H
Rs.Cr
licensed area of DISCOM
Amount realized by the DISCOM out of the
I
Rs.Cr
amount Billed at H
Collection efficiency (%) (=Revenue realized
J=(I/H)X100
%
Amount billed)
K= GxJ
Energy realized by the DISCOM
MU
Distribution Loss (%)
%
L={(D –G)/D}x100
AT&C Loss (%)
M={(D-K)/D}x100
%

3.16.5.

Current Year
FY 2022-23
(R.E)

293.91

647.66

2049.49

2043.61

1603.60

1781.35

-

-

1603.60

1781.35

861.49

944.73

910.29

1093.51

94.64%

86.39%

1517.63
21.76 %
25.95 %

1534.98
12.83%
24.69%

However, the Petitioner has failed to justify / substantiate the �igures
submitted in the Format D2 (A) and hence the Commission has recomputed
the AT&C loss% in the following format as provided below:
Table 39: Approved Computation of AT&C Losses for FY 2022-23

Particular
Input energy (metered import) received at interface points
of DISCOM network
Input Energy (metered Export) by the DISCOM at interface
point of DISCOM network including balance surplus
energy
Total energy available for sale within the licensed area
to the consumers of the DISCOM periphery
Energy billed to metered consumers within the licensed
area of the DISCOM
Energy billed to unmetered consumers within the licenses
area of the DISCOM
Total Energy billed
Amount billed to consumer within the licensed area of
DISCOM
Amount realized by the DISCOM out of the amount Billed
at H
Collection ef�iciency (%) (=Revenue realized Amount
billed)
Energy realized by the DISCOM
Distribution Loss (%)
AT&C Loss (%)

MSERC Order in Case No. 36 of 2023

Calculation

Unit

Current
Year FY
2022-23

A

MU

2862.14

C=(A-B)* (13.16%)

MU

2144.50

D

MU

1781.35

MU

1781.35

B

MU

647.66

E

MU

G

Rs.Cr

1093.51

I=(H/G)X100

%

80.31%

F=D+E
H

J= FxI
K={(C –F)/C}x100
L={(C-J)/C}x100

-

Rs.Cr
MU
%
%

878.18

1430.57
16.93%
33.29%

Page 48 of 60

<!-- page 49 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.16.6.
Sl.No
1
2
3
4
5
6
7
8

Accordingly, Commission approved the AT&C Loss (%) as shown in the table
below,
Table 40: Approved AT&C Losses for FY 2022-23

Particulars
Opening balance of receivables as approved closing balance for FY 2021-22 (as
per audited accounts of FY 2021-22)
Revenue from sale of power within the state in FY 2022-23 (Note no.24 of SoA)
Total
Less: Closing balance of receivables as at Note no. 7 of SOA
Revenue realized in FY 2022-23 from sale of power within the state (Sl.no.3-4)
Collection Ef�iciency (%) (941.34/1093.51*100)
Distribution losses (%) (vide table no. 9(A))
AT&C Losses (%) (As computed above)

Value
(Approved)
689.98

1093.51
1783.49
905.32
878.18
80.31%
16.93%
33.29%

3.16.7.

Commission approves AT&C Loss (%) at 33.29% for True up of FY 202223.

3.16.8.

Regulation 83.1 of MSERC MYT Regulations speci�ies that,

AT&C Loss Penalty
“(a) The licensee shall provide complete information of the total AT & C
Losses during the previous year and that projected for the year for which the
application is being made, including the basis on which such losses have been
worked out.

Provided that it shall be obligatory on the licensee whose AT&C losses during
the previous year are in excess of 30 percent, to project reduction of such
losses by a minimum of 3 percent during the year for which a Tariff
Application is made. Any shortfall in the projected level of AT&C losses for
such year, in this regard, may be penalized by an amount equivalent to the
cost of the quantum of energy to be lost due to inability of the licensee to plan
and achieve reduction of AT&C losses by a minimum of 3 percent from the
previous year’s level as may be allowed. Such amount shall be calculated at
the average-over-all-unit-cost of sale of power, as approved by the
Commission for such year.
Provided also that in the case of a licensee whose AT&C losses during the
previous year were less than 30 percent, it would be obligatory for such
licensee to reduce such AT&C losses by a minimum of 1.5 percent only during
the year for which a Tariff Application is made. Failure to achieve this level
of reduction may be penalized in the same manner as set out in clause (a)
above. Further, provided that the overall penalty, of any, may be limited by
relevant Central Guidelines, as may be noti�ied from time to time.”
3.16.9.

Accordingly, the Commission considers the AT&C loss penalty as detailed in
the table below,

MSERC Order in Case No. 36 of 2023

Page 49 of 60

<!-- page 50 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

Table 41: Approved AT&C Loss penalty for FY 2022-23
Particular

Unit

Value
(Approved)

1

Actual AT&C loss for FY 2021-22

%

25.95%

3

Actual AT&C loss for FY 2022-23 as recomputed

%

33.29%

Sl. No

2
4
5
6
7

Target level for FY 2022-23 (1.5% less of Sl.no.1)

%

Short fall over the Targeted Level (Sl.no.3-2)

AT&C loss in terms of Energy for FY 2022-23 (1781.35 x 3.58%)

Average Unit cost of sale of power as per Reg.83.1 (1093.51/1781.35)
Penalty to be levied on the short fall of AT&C loss (sl.no.5x6)

3.16.10.

%

24.45%
8.84%

MU

157.49

Rs. Cr

96.68

Rs/Kwh

6.14

Commission approves AT&C loss penalty at Rs. 96.68 Crore for not
achieving the AT&C loss target.

3.17. Accrued Terminal Bene�its
Petitioner’s Submission
3.17.1.

The Petitioner submitted before the Commission that as per the directions of
the Hon’ble Commission it has done the actuarial valuation for the terminal
bene�its. The terminal liabilities for the period from 2013 to 2022-23 after
considering the payment of Rs. 860 Cr made to the trust comes out to be Rs.
2441.39 Cr which has been accounted for as Actuarial Loss in the FY 2022-23
in the books of accounts of MePDCL, MePGCL, MePTCL and MeECL as under,
Company
MeECL
MePDCL
MePGCL
MePTCL
Total

Amount
(Rs. Cr
21.15
1272.22
749.84
398.17
2441.39

3.17.2.

The Petitioner further submitted that the terminal bene�its are an integral part
of the employee expenses and are ought to be recovered through tariff.

3.17.4.

In view of the above, the Petitioner proposed that the terminal liabilities that
have been accrued in 10 years may be allowed in 15 equal installments
without any carrying cost. Hence, the Petitioner proposed an additional
recovery of Rs.84.81 Cr for FY 2022-23 and Rs.0.47 Cr on account of the
recovery of terminal bene�its of MeECL. MePDCL would also like to submit that

3.17.3.

However, the Petitioner also takes the cognizance of the fact that the liabilities
accrued for the period of 10 years cannot be allowed by the Commission in one
year as that would result in substantial tariff shock.

MSERC Order in Case No. 36 of 2023

Page 50 of 60

<!-- page 51 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.17.5.

the amount of recovery of the accrued liabilities shall be over and above the
annual contribution towards terminal bene�its. Also, the Petitioner mentioned
that since these are not the actual O&M expenses, it would not claim the said
expenses for computation of working capital and escalation of O&M expenses.
Accordingly, the Petitioner requested the Commission to allow the additional
recovery of Rs. 85.28 Cr in 2022-23.

Commission’s Analysis
3.17.6.

3.17.7.

3.17.8.

3.17.9.

Commission in its earlier orders has declined the consideration of additional
revenue requirement on account of past terminal liabilities due to noninstitutionalization of the Pension Fund which was supposed to be created to
take care of the terminal liability payments. However, Petitioner has submitted
documentary evidence w.r.t institutionalization of the Pension trust in the
current period of FY 2022-23, hence the Commission is of the view that
pension claim can be evaluated for necessary consideration.
The Petitioner has also shared an Actuarial Valuation report of terminal
liabilities where the cut-off date for the actuarial valuation is taken as on
31.03.2023. Additionally, Petitioner in its True Up petition for FY 2022-23, has
also claimed that they would like the legitimate dues of the Terminal Liabilities
to be recovered in 10 to 15 equal instalments.

In consideration of the above points, this Commission is of the view that the
legitimate claim of the Petitioner w.r.t the past Terminal Labilities can be
relooked and if found in order can be allowed to be recovered over 10 equal
instalments, starting from FY 2023-24. Thus, Commission has decided that no
additional consideration w.r.t recovery of past Terminal Liabilities shall be
considered in True Up order for FY 2022-23 to calculate the Gap/Surplus, but
at the same time Commission has consented to allow the Petitioner to recover
the current year i.e., FY 2022-23 pension liability cost through its current year
O&M expenses.
The Commission considers Nil pass through of Accrued Terminal
Liabilities in the current year True Up order for FY2022-23.

3.18. Aggregate Revenue Requirement and Revenue Gap/Surplus for FY
2022-23
Petitioner’s Submission
3.18.1.

Based on the computation of various components of ARR as detailed out in
previous paragraphs the ARR for 2022-23 is estimated as under:

MSERC Order in Case No. 36 of 2023

Page 51 of 60

<!-- page 52 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
Table 42: Proposed Aggregate Revenue Requirement & Revenue Gap/ (Surplus) for FY 2022-23
Approved in
Tariff Order
2022-23
(Rs. Cr.)

Actual as Per
True Up
(Rs. Cr.)

Variation

Power Purchase cost

856.32

850.51

-1%

Transmission Charges (MePTCL)

73.49

73.49

Sl.No Particulars

1
2
3

Transmission Charges (PGCIL)
Less RRAS Settlement

68.38

103.11

51%

-0.27

0%

0%

4

Employee Expenses

182.86

240.18

31%

6

Administration & General Expenses

12.63

18.21

44%

8

Interest and Finance charges

10.14

36.65

261%

Bad & Doubtful Debt

0

0%

Gross Annual Revenue Requirement (ARR)

0

22.24

1234.05

1409.77

14.24%

Less: Non-Tariff Income and Other Income

104.71

70.80

-32%

5
7
9

10
11
12

Repair & Maintenance Expenses

Depreciation

Interest on working capital

Return on Equity

6.46

6.62

0

33.20

23.77

25.84

2%

0%

9%

13

Less: Sale of Surplus Power
Net ARR

395.72

733.62

1264.66

14

Add: True up Gap/(Surplus) for FY 2018-19

-15.88

-15.88

16

ARR for FY 2022-23

15

Add: True up Gap for FY 2019-20

179.43

897.17

74.31

179.43

1428.21

0%

-81%

72.39%

59.19%

3.18.2.

The Petitioner requested the Commission to approve the ARR for FY 2022-23
as Rs.1428.21 Cr.

3.18.3.

True up petition �iled by the Petitioner has been scrutinized considering the
Additional information/data, Audited accounts with reference to the MSERC
MYT Regulations 2014.

Commission’s Analysis

3.18.4.
3.18.5.

Moreover, the past adjustments i.e., Gap/(Surplus) from the Trued-up year, as
already taken into account by the Commission in the Order for ARR of FY 202223, have also been taken into consideration in the present year True-Up
exercise.

Accordingly, Commission approves the admissible expenses for True up of FY
2022-23 as depicted in table below.

MSERC Order in Case No. 36 of 2023

Page 52 of 60

<!-- page 53 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
Table 43: Approved Aggregate Revenue Requirement & Revenue Gap/ (Surplus) for FY 2022-23
True-Up for
FY 2022-23
(Claimed)
(Rs Cr)

True-Up for
FY 2022-23
(Approved)
(Rs Cr)

Sl. No.

Particulars

1

Power Purchase cost

850.51

850.51

3

Transmission Charges (MePTCL)

73.49

73.49

2

Transmission Charges (PGCIL)
Less RRAS Settlement

103.11
-0.27

103.11
-0.27

4

Employee Expenses

240.18

240.18

6

Administration & General Expenses

18.21

17.18

36.65

9.27

5
7

Repair & Maintenance Expenses

6.62

6.62

Depreciation

33.20

Interest on working capital

Return on Equity

25.84

Bad & Doubtful Debt

22.24

25.95

Gross (ARR)

1409.77

0.00

1330.99

12

Less: Non-Tariff Income and Other Income

70.80

90.58

14

Less: Penalty for AT&C loss

1264.66

96.68

1069.42

-15.88

-15.88

8
9

10
11
13

15
16

17

18

3.18.6.

Interest and Finance charges

Less: Sale of Surplus Power
Net ARR

Add: True up Gap/(Surplus) for FY 2018-19
dated 03.10.2022
Add: True up Gap for FY 2019-20
dated 03.10.2022
Total ARR recoverable for FY 2022-23
(excluding Pension Liability)

Comprehensive Income/ Expenses (Pension)
Comprehensive Income/ Expenses (1/3
MeECL) (Pension)
Total ARR recoverable for FY 2022-23
(including Pension Liability)

74.31

2.58

2.38

74.31

179.43

179.43

1428.21

1232.97

84.81

0.00

0.47

0.63

1513.50

1233.60

Commission approves Annual Revenue Requirement at Rs. 1233.60
Crore for True up of FY 2022-23.

MSERC Order in Case No. 36 of 2023

Page 53 of 60

<!-- page 54 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

3.19. Revenue from Operations
Petitioner’s Submission
3.19.1.

As per the settled methodology adopted by the Hon’ble Commission the
Revenue from Sale of Power has been considered as per the audited statement
of accounts. MePDCL would like to humbly submit that the as of now the
practice of accounting the revenue for certain categories are clubbed together,
however, MePDCL is in process of further bifurcating the revenue accounting
into further categories as determined by Hon’ble Commission.

Table 44: Proposed Details of Revenue from Sale of Power for FY 2022-23
Categories of other Consumers:
Domestic and Residential

Commercial
Industrial Medium and Low Voltage
Industrial High and Extra High Voltage
Public Lighting
Irrigation and Agriculture
Public Water Works
Bulk Supply to others
Miscellaneous and General Purpose
Construction Project High Tension
Revenue from sale of power through Franchisee
Total

Amount (Rs Cr)
282.23

113.51
4.76
563.42
1.25
0.03
35.14
67.49
1.16
24.52
1,093.51

3.19.2.

The Petitioner requested the Commission to approve the revenue for FY 202223 as Rs. 1093.51 Cr.

3.19.3.

The net Revenue from operations amounted to Rs.1093.51 Crore for FY 202223 as reported vide note no.24 of audited accounts as detailed below,

Commission’s Analysis

Table 45: Approved Details of Revenue from Sale of Power for FY 2022-23

Categories of other Consumers:
Revenue from Sale of Surplus power outside state
Cross Subsidy Surcharge
RRAS of NTPC & NEEPCO adjusted from the power purchase bills
Domestic and Residential
Commercial
Industrial Medium and Low Voltage
Industrial High and Extra High Voltage
Public Lighting
Irrigation and Agriculture
Public Water Works
Bulk Supply to others
Miscellaneous and General Purpose

MSERC Order in Case No. 36 of 2023

Amount (Rs Cr)
74.31
7.58
0.27
282.23
113.51
4.76
563.42
1.25
0.03
35.14
67.49
1.16

Page 54 of 60

<!-- page 55 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
Categories of other Consumers:
Construction Project High Tension
Revenue from sale of power through Franchisee
Total
Less: Revenue from Sale of Surplus power outside state
Less: Cross Subsidy Surcharge
Less: RRAS of NTPC & NEEPCO adjusted from the power purchase bills
Revenue from Sale of power within the state

3.19.4.

Amount (Rs Cr)
0.00
24.52
1,175.68
74.31
7.58
0.27
1,093.51

Commission approves Revenue from operations at Rs.1093.51 Crore for
True up of FY 2022-23.

3.20. Revenue Gap/Surplus
Petitioner’s Submission
3.20.1.

Based on the ARR and Revenue presented above the Revenue Gap for FY 202223 is presented below
Table 46: Proposed Revenue Gap for FY 2022-23

Particulars
Aggregate Revenue Requirement
Less: Revenue from Sale of Power
Net Gap / (Surplus) for FY 2022-23

Amount (Rs. Cr.)
1513.50
1093.51
419.99

Commission’s Analysis
3.20.2.

Commission has analyzed the True up ARR with reference to the additional
information �iled by the licensee and also as per Regulations, Revenue
Gap/Surplus has been computed in the table below,
Table 47: Approved Revenue Gap for FY 2022-23

Particulars

3.20.3.

Net ARR
Less: Revenue from Sale of Power
Net Gap / (Surplus) for FY 2022-23

Amount (Rs. Cr.)
(Claimed)
1513.50
1093.51
419.99

Amount (Rs. Cr.)
(Approved)
1233.60
1093.51
140.09

Commission approves Net Gap at Rs. 140.09 Crore for True up of FY 202223 and shall be appropriated in the next Tariff Order.

MSERC Order in Case No. 36 of 2023

Page 55 of 60

<!-- page 56 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

4. Summary of Order
4.1.1.

The summary of True up Order for Distribution Business for MePDCL for FY
2022-23 is represented in the table below,
Table 48: Summary of Approved ARR �igures for True-Up of FY 2022-23
Sl.
No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16

17
18
19

Particulars
Power Purchase cost
Transmission Charges (PGCIL)
Transmission Charges (MePTCL)
Less RRAS Settlement

Employee Expenses
Repair & Maintenance Expenses
Administration & General Expenses
Depreciation
Interest and Finance charges
Interest on working capital
Return on Equity
Bad & Doubtful Debt
Gross (ARR)
Less: Non-Tariff Income and Other Income
Less: Sale of Surplus Power
Less: Penalty for AT&C loss
Net ARR
Add: True up Gap/(Surplus) for FY 2018-19
dated 03.10.2022
Add: True up Gap for FY 2019-20
dated 03.10.2022
Total ARR recoverable for FY 2022-23
(excluding Pension Liability)

Comprehensive Income/ Expenses (Pension)
Comprehensive Income/ Expenses (1/3 MeECL)
(Pension)
Total ARR recoverable for FY 2022-23
(including Pension Liability)
Less: Revenue from Sale of Power
Net Gap / (Surplus) for FY 2022-23

MSERC Order in Case No. 36 of 2023

True-Up for
FY 2022-23
(Claimed)

True-Up for
FY 2022-23
(Approved)

850.51
103.11
73.49
-0.27

850.51
103.11
73.49
-0.27

240.18
6.62
18.21
33.20
36.65
25.84
22.24

1409.77
70.80
74.31
1264.66
-15.88

240.18
6.62
17.18
2.58
9.27
25.95
2.38
0.00
1330.99
90.58
74.31
96.68
1069.42
-15.88

179.43

179.43

1428.21

1232.97

84.81

0.00

1513.50

1233.60

1093.51
419.99

1093.51
140.09

0.47

0.63

Page 56 of 60

<!-- page 57 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

5. Commission’s Directives
The Commission hereby directs the Petitioner the following directives and is of the view that non-compliance of the directives may lead to nonadmittance of the future petitions.
Table 49: Commission’s Directive
Sl.
No.

1.

Particulars
Petitioner to submit Additional Capitalization funding structure for the respective year
Total Additional Funded through Funded though Funded through
Particulars
Capitalization
Grant
Equity.
Debt
(In Rs. Cr.)
(In Rs. Cr.)
(In Rs. Cr.)
(In Rs. Cr.)

Petitioner to provide annual Grant data capturing the following details:
a. Scheme wise grant allocation details
Sl. No.

2.

Timeline

1
2
3

Scheme of Grant

Total Grant received

Scheme-1
Scheme-2
Scheme-M

b. Grant Capitalization details
Particulars

Opening Balance
(As on1st April)

To be provide during the Next
True-Up petition for FY 2023-24

Closing Balance
(As on31st March)

Grant Allocated

Grant Capitalized

Grant Amortized during the
year

MSERC Order in Case No. 36 of 2023

Page 57 of 60

<!-- page 58 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL
Sl.
No.
3.

Particulars
Petitioner to provide yearly Loan data capturing the following details:
a. As per Normative calculation/ Regulatory Accounts
Particulars
Loan
Opening balance
Additional Loan drawl
Repayment
Closing Balance
Applicable Interest rate
Interest on Loan

Loan -1

b. As per Actual /�inancial account
Particulars
Loan -1
Loan
Opening balance
Additional Loan drawl
Repayment
Closing Balance
Applicable Interest rate
Interest on Loan

4.
5.

Timeline

Loan -2

Loan-N

Loan -2

Loan-N

Petitioner to provide (in excel and PDF �ile) LT/HT/EHT Category (including the details of Kutir Jyoti and Special Tariff Category) wise,
Metered/Unmetered sub-category wise and Slab wise Billing Determinants (No. of connections, Connected Load, Energy Sale) along with
the Revenue earned from those consumer categories for the respective years.
Petitioner is directed to submit the RPO compliance during the year with proper documentation including the details of availability of
Power from Renewable generators as per PPA singed as well as its own renewable generation vis-à -vis Renewable Power procured with
respect to the RPO percentage (%) mentioned in the MSERC RPO regulation.

MSERC Order in Case No. 36 of 2023

Page 58 of 60

<!-- page 59 -->

MSERC Order on True Up of Distribution Business for FY 2022-23 for MePDCL

6. Applicability of the Order
This Order shall come into effect from 1st April 2024.

The Petition of Meghalaya Electricity Power Distribution Corporation Limited (MePDCL) in Case No.
36 of 2023 stands disposed of accordingly.

Sd/-

Sd/-

Ramesh Kumar Soni,
Member (Law)

Chandan Kumar Mondol,
Chairman

MSERC Order in Case No. 36 of 2023

Page 59 of 60

<!-- page 60 -->

7. Annexure-1

<!-- page 61 -->

47

48-79

<!-- page 62 -->

1
BEFORE THE MEGHALAYA STATE ELECTRICITY REGULATORY
COMMISSION, SHILLONG

IN THE MATTER OF:
TRUE UP OF DISTRIBUTION BUSINESS FOR FY 2022-23 UNDER MSERC
(MULTI YEAR TARIFF) REGULATIONS, 2014 AND UNDER SECTION 62 AND
64 READ WITH SECTION 86 OF THE ELECTRICITY ACT 2003.

AND IN THE MATTER OF:
Meghalaya Power Distribution Corporation Limited (MePDCL)
Lum Jingshai, Short Round Road,
Shillong - 793 001, Meghalaya

… Petitioner
V/s

Byrnihat Industries Association (BIA)
Upper Baliyan, Umtru Road,
Byrnihat, Ri Bhoi District,
Meghalaya – 793101

… Objector

SUGGESTIONS/ OBJECTIONS ON BEHALF OF BYRNIHAT INDUSTRIES
ASSOCIATION
MOST RESPECTFULLY SHOWETH:
1.

The Objector, M/s Byrnihat Industries Association (“BIA”) is filing the
present objections to the petition filed by the Meghalaya Power Distribution
Corporation Limited (hereinafter referred to as ‘MePDCL/ Petitioner’)
seeking True Up of Distribution Business for FY 2022-23. The
aforementioned petition has been filed under the Meghalaya State

<!-- page 63 -->

2
Electricity Regulatory Commission (Multi Year Tariff) Regulations, 2014
(hereinafter referred to as “MYT Regulations 2014”) and under Sections 62
& 64 read with Section 86 of the Electricity Act 2003 (hereinafter referred to
as ‘The Act’). The objections are being filed in pursuance to the public notice
inviting objections and representations from the stake-holders in the State
of Meghalaya.
2.

The Objector is an Association of industrial consumers in the Byrnihat area
in the State of Meghalaya. The Industrial consumers are few in number but
at the same time contribute a substantial part of the revenue requirements
of the electricity utilities in the state. The special characteristics of the
Industrial consumers that benefit the Utilities are:
i. They are the subsidizing category of consumers for the utilities. Hence,
they are the revenue earners ensuring better returns for the utilities.
ii. The Load curve and consumption pattern enable better capacity
utilization and low Cost of Service for the Utilities in comparison to LT
consumer categories.

3.

In recent years, Meghalaya has witnessed firming up of power capacity from
several sources and an increase in own generation capacity, thus moving
towards becoming a net power exporter from being a power deficit State.
Being abundantly rich in Hydro Power Generation, the consumers in the
State of Meghalaya ought to have considerably lower power procurement
costs resulting into lower tariffs across all the categories along with the
reasonable industrial tariffs. However, the tariff hikes in the recent years in
Meghalaya is in higher side commensurate with the other states in India,
which have disproportionately burdened the industrial consumers of

<!-- page 64 -->

3
Meghalaya but also seriously reduce the Industrial Growth throughout the
state. In view of this, the Petition filed by the Petitioner is of utmost
relevance as it would have a direct impact on the various stakeholders
involved.
4.

It is submitted that the Objector regularly participates in the proceedings
related to determination of ARR and Tariff by the Hon’ble Meghalaya State
Electricity Regulatory Commission (hereinafter referred to as “Hon’ble
Commission” or “Hon’ble MSERC”) and takes up the other issues
concerning its members and is therefore an unparalleled stakeholder.

5.

In order to submit a comprehensive and detailed analysis of the instant
Petition, the Objector has worked with expert consultant, Energy Optimaa.
A copy of the report prepared by the expert consultant, Energy Optimaa, is
annexed as Annexure A.

6.

The Objector is making issue-wise submissions in the following manner:
ENERGY SALES

7.

The Petitioner has submitted that there has been substantial growth in terms
of the infrastructure and there has been substantial increase in the
infrastructure. However, it can be observed from the Table 1 in the Petition
and as highlighted below, that over the period there is growth of around 5%
in last 5 years except LT lines and transformers. However, the YoY growth
is very marginal in FY 2022-23 compared to FY 2021-22 which clearly
highlights that the development of Distribution infrastructure in the State

<!-- page 65 -->

4
has been highly ignored and there has been no breakthrough in achievement
of any growth in the power sector.
Table Error! No text of specified style in document.-1: Physical Parameter of
Distribution System
Particulars
Number of 33/11
KV Sub-stations
Transformation
Capacity of 33/11
KV Sub-Stations
Length of 33 KV
Lines
Number of 11/0.4
KV Sub-stations
Transformation
Capacity of
11/0.4 KV SubStations
Length of 11 KV
Lines
Number of
Distribution
Transformers

Uni
ts

FY
201819

FY
201920

FY
202021

FY
202122

FY
202223

CA
GR

YoY

No
s.

98

101

107

114

115

4%

1%

487

600

642

634

626

6%

-1%

2,217

2,333

2,519

2,631

2,794

6%

6%

10,381

11,563

12,436

12,798

12,951

6%

1%

MV
A
CK
M.
No
s.

5,40,81 7,73,49 8,34,37 8,89,23 9,22,71
14%
MV
5
1
5
5
5
A
CK
15,602 16,810 17,886 19,688 19,361 6%
M.

No
s.
CK
Length of LT lines
M.
8.

4%

-2%

10,381

11,577

12,495

12,847

13,173

6%

3%

20,019

24,929

27,762

31,758

32,196

13%

1%

The Petitioner has submitted that the total energy sales in the state during
FY 2022-23 has been 1718.83 MU which can be verified from the Audited
Statement of Accounts. However, it has been observed that there is a minor
difference in energy sales as computed by the Petitioner and the sales as
provided in the Annual accounts. Further, the Category wise sales reported
through Audited Accounts vide note no.24.1 are not matching with the

<!-- page 66 -->

5
category wise Energy sales reported in the True up petition, which may be
due to the allocation of bulk power sales distributed to the other category of
consumers. The details of the energy sales are outlined below:
Table Error! No text of specified style in document.-2: Energy Sales for FY 202223 (MU)

LT Category – (A)
Domestic
Commercial
Industrial
Agriculture
Public Lighting
Water Supply
General purpose
Kutir Jyoti
Crematorium
HT + EHT
Category (B = B1
+ B2)
HT Category (B1)
Domestic
Water Supply
Bulk Supply
Commercial
Industrial
Ferro Alloys

606.14
404.70
77.28
6.21
0.78
0.12
12.76
17.52
86.55
0.22

700.75
429.52
96.57
7.40
0.20
1.03
9.60
17.47
138.78
0.18

16%
6%
25%
19%
-74%
758%
-25%
0%
60%
-18%

As per
FY
%
Annual 2021-22
Growth
Accounts Sales
639.21
595.42 17.69%
410.10
395.99
8.47%
86.06
62.20
55.26%
5.95
5.61
31.91%
0.13
0.15
33.33%
1.03
0.56
83.93%
8.97
11.20
-14.29%
15.32
15.20
14.93%
111.47
104.39 32.94%
0.18
0.12
50.00%

941.24

1,080.59

15%

1,002.00

1,008.18

7.18%

475.44
25.15
33.35
103.64
27.87
150.58
36.28

408.82
22.18
35.37
77.86
30.96
133.25
109.20

-14%
-12%
6%
-25%
11%
-12%
201%

-

405.27
15.68
20.88
29.41
70.4
69.11
106.48

Special tariff

98.57

-

-100%

0.88%
41.45%
69.40%
164.74%
-56.02%
92.81%
2.55%
100.00%

465.80

671.77

44%

53.41
347.54

263.36
408.41

64.85

-

Category of
Consumers

EHT Category
(B2)
Industrial
Ferro Alloys
Special tariff
Bulk Supply (C)

Approved FY 2022%
sales
23 Sales variation

93.31
-

602.91

11.42%

393%
18%

45.94
426.32

-100%

130.65

473.27%
-4.20%
100.00%

77.63

<!-- page 67 -->

6
Category of
Consumers

Approved FY 2022%
sales
23 Sales variation

Total – A + B + C

1,547.38

9.

1,781.35

15%

As per
FY
%
Annual 2021-22
Growth
Accounts Sales
1,718.85 1,603.60 11.08%

Further, it is observed that there has been overall increase in Energy Sales at
15%, while LT: HT ratio of sales recorded at 39:61 which is also in line with
the approved ratio. However, it is observed that major increase in sales is in
EHT category by 44% but hardly any growth has been witnessed in the
infrastructure in transmission petition or in distribution petition to serve
such consumption and hence there is a need for proper development of infra
for higher voltage level. Further, abnormal sales variation on YoY basis has
been observed in various category of consumers for which proper
justification may be provided by the Petitioner. Therefore, it is prayed that
this Hon’ble Commission only true-up the energy sales after conducting
prudence check.
ENERGY AVAILABILITY

10.

The Petitioner has computed the energy balance considering the
distribution loss of 12.83%, Intra-State Transmission loss of 4% and InterState Transmission loss of 3%. It is requested to the Hon’ble Commission to
allow the distribution loss of 12% as per trajectory approved in the business
plan and in the tariff order.

11.

Further, the Petitioner has not provided any justification / calculation on
consideration of Inter-State Transmission loss of 3%. It is submitted that post
November 2020, the Hon’ble CERC has revised the computation of PoC
losses as per CERC (Sharing of Inter-State Transmission Charges and

<!-- page 68 -->

7
Losses) Regulations, 2020 and has come into force w.e.f. 01 November 2020
vide notification dated 08 August-2020. The new regulations have replaced
the extant CERC Regulations (notified in 2010), which has been in effect
since

July

2011

and

modify

the

existing

point

of

connection

(PoC)mechanism of tariff computation. As per POSOCO’s guidelines, Inter
State Transmission System transmission loss will be calculated on PAN
India basis by NLDC for each week. The Regional Load Dispatch Centre also
published the weekly average transmission loss of a region on its website
for each year and also for the last week which is used by the stakeholders
for calculation of transmission losses, calculation of transmission charges
and billing of energy and energy management. Accordingly, the Petitioner
need to highlight the inter-state loss based on the loss as declared by RLDC
for FY 2022-23 and provide the detail calculation of the same.
12.

With regards to intra-State transmission Loss, the Petitioner has considered
4% loss however the petition filed by MePTCL, it has declared the
Transmission loss of the state as 3.16% for FY 2022-23. It is requested to the
Hon’ble Commission to recompute the energy balance statement based on
the above and in case of any surplus, the same to be disallowed from power
purchase cost. The Objector has tried to work out the same and the details
of calculation is provided below:

Table Error! No text of specified style in document.-3: Energy Balance Proposed
for FY 2022-23 (MU)
Particulars
Energy purchase from
Eastern Region (ER)

Formula
A

Claimed
Approved Claimed
Allowable
rectified
-

-

<!-- page 69 -->

8
Particulars

Formula

Inter-State Transmission
B
Loss in ER
Net Power purchased from
C=A(1-B%)
ER
Power purchase from CGS
including Pallatana North
D
Eastern Region (NER)
Total Power at NER
E=C+D
Inter-State Transmission
F
Loss in NER
Net Power available at state
bus from external sources on G=E*(1-F%)
Long Term
Power purchase from State
generating stations within
H
State
Power purchase from other
sources (both from outside
I
within the State)
Net power available at state
bus for sale of power within
J=G+H+I
the state
Total power sold
K
Distribution Losses (%)
L
T&D Losses in terms of MU
M=N-K
Energy Requirement for sale N = K/(1by Discom within state
L)
O = N/(1Energy Requirement for sale
Intra Tx
within state at state bus
Loss%)
Surplus Energy at state bus
P = J-O
Power sold to others at state
bus (both outside & inside
Q
the State)
(incl.swap/UI/bilateral)
Unaccounted Energy
R=P-Q

Claimed
Approved Claimed
Allowable
rectified
1.80%

1.80%

1.80%

-

-

-

-

1,829.69

1,200.74

1,200.74

1,200.74

1,829.69

1,200.74

1,200.74

1,200.74

3.00%

3.00%

3.00%

3.00%

1,774.80

1,164.72

1,164.72

1,164.72

1,293.49

1,043.53

1,043.53

1,043.58$

-

660.72

660.72

660.72

3,068.29

2,868.97

2,868.97

2,869.02

1,547.38
12.00%
211.01

1,781.35
12.83%
262.27

1,781.35
12.83%
262.27

1,718.84
12.00%
234.39

1,758.39

2,043.62

2,043.62

1,953.23

1,831.65

2,221.32*

2,128.77

2,016.96

1,236.64

647.65

740.20

852.05

1,236.64

647.65

647.65

647.65

0.00

-

92.56

204.41

<!-- page 70 -->

9
*- The petitioner in their submission has considered the Intra-State Transmission
loss of 8%against the proposed loss of 4% which has been rectified resulting in
unaccounted energy of 92.56 MU as per Petitioner submission.
$-As per MePGCL True-up petition
13.

Accordingly, the Objector request the Hon’ble Commission to the adjust the
cost of surplus power of 204.36 MU for the FY 2022-23 in the overall power
purchase cost claim of the Petitioner

POWER PURCHASE COST

14.

The Petitioner has claimed Rs. 848.77 Crore towards purchase of 2,905 MU
at an Average Rate of Rs. 2.92 /kWh (excl. Transmission charges) for the FY
2022-23. Considering the impact of Transmission charges, the average rate
comes out to be Rs. 3.53/unit. Further, the Petitioner has stated that an
amount of Rs. 17.04 Cr pertaining to the energy bills of NHPC have been
wrongly classified in the statement of accounts as delayed payment
surcharge due to oversight. Since these expenses are legitimate expenses
against the power purchased from NHPC the same has been included in the
Power Purchase expenses in the ARR. The Objector submits that the annual
accounts provided by Petitioner is the audited annual accounts by a
statutory auditor whereby question on the authenticity of the classification
of such expenses needs to be revalidated by way of a certificate from the
statutory auditor and supporting documents. It is prayed that these costs
may not be allowed as pass through without supporting documents.

15.

Further, the cost of surplus power of 204.36 MU for the FY 2022-23 needs to
be adjusted in the overall power purchase cost claim of the Petitioner. As

<!-- page 71 -->

10
per the average power purchase cost proposed by the Petitioner, the
Objector submits the Hon’ble Commission must disallow the excess power
purchase cost to the extent of Rs. 59.67 Crore (204.36 MU x Rs.
2.92/kWh/10). Further in line with the approach adopted by the Hon’ble
Commission in the past order, Surcharge and Interest claims due to delay in
payment of power purchase bills shall not be considered for determination
of Tariff.
16.

To summarise, it is prayed that this Hon’ble Commission may consider the
following :
 Even though there is no power procurement from NTPC, the cost of Rs.
4.20 Crore has been considered without any justification for the same.
The Hon’ble Commission may call for data showing efforts made by
Petitioner to surrender PPAs executed with NTPC.
 For reconciliation purpose, MePDCL has considered surcharge of Rs.
1.06 Crore. However, as per Audited Statement the Surcharge is Rs. 17.65
Crore. Even if MePDCL submission of non-consideration of DPC charges
of Rs. 17.04 Cr pertaining to the energy bills of NHPC is adjusted, the
related surcharge amount will be Rs. 0.61 Crore resulting in difference of
Rs. 0.45 Crore. This Hon’ble Commission may reconcile the delayed
payment surcharge while determining the true-up.
 The Surplus power purchase cost due to revised distribution and
transmission loss of 204.41 MU (specified in Table 2-3) needs to be
disallowed.
 The resultant shortfall in power availability from the approved sources
to the extent of 878.91 MU (specified in Table 2-4) has resulted into
additional power procurement from IEX/Bilateral at Rs. 6.20 against the

<!-- page 72 -->

11
actual cost of Rs. 3.63/kWh incurred from such approved sources
resulting into additional burden on the consumers. Such additional
burden should not be passed through to the consumers.
 The Petitioner has not considered 1% rebate on the power Purchase cost
which is the approach adopted by the Hon’ble Commission in the past
tariff order as per the MYT Tariff Regulations 2014. Accordingly, the
same is required to be considered while approving the power purchase
cost.
17.

Considering the above submission, the Objector hereby submits the power
purchase cost probably to be allowed and computed as follows:

Table Error! No text of specified style in document.-4: Power Purchase Cost for
FY 2022-23

Particulars

Quant
um
Procur
ed

Amou
nt Rs.
Cr

Per
Unit
Cost

Quant
um
Procur
ed

Claimed

Amou
nt Rs.
Cr

Per
Unit
Cost

Quant
um
Procur
ed

Audited

Amou
nt Rs.
Cr

Per
Unit
Cost

Allowable

Long Term
Sources
MePGCL
NHPC
NEEPCO
OTPC
NTPC
Kreate
Energy (IEX)
APPCL
(Bilateral
Purchase /
IEX)

1,043.5
3
36.87
646.64
517.23
27.65

241.67

2.32

17.04
402.56
149.07
4.20

4.62
6.23
2.88

2.89

1.05

1,043.5
3
36.87
646.64
517.23
-

241.67

608.85

2.32

3.27

1,043.5
8
36.87
646.64
517.23
27.65

241.67

2.32
160.51
-

591.81

-

62.62
34.97

21.68

6.20

34.97

-

<!-- page 73 -->

12
Particulars

Quant
um
Procur
ed

Amou
nt Rs.
Cr

Per
Unit
Cost

Quant
um
Procur
ed

Claimed
DSM Intra
/ Inter State
Kreate
Energy
(Swapping)
APPCL
(Swapping)
GMRTEL
(Swapping)
Manikaran
(Swapping)
Subheksha
(Swapping)
Grand Total
Transmissio
n and Other
Charges
Transmissio
n Charges
MePTCL
Transmissio
n Charges
PGCIL
POSOCO
Charges
VAR
Charges
Less RRA
Settlement
Other
Charges
Net Power
Purchase
Cost

Amou
nt Rs.
Cr

Per
Unit
Cost

Quant
um
Procur
ed

Audited

21.77

7.88

3.62

281.55

0.84

85.74

Amou
nt Rs.
Cr

Per
Unit
Cost

Allowable
21.77

-

0.03

281.55

-

0.26

0.03

85.74

-

92.16

0.30

0.03

92.16

-

64.80

0.22

0.03

64.80

-

52.09

0.17

0.03

52.09

-

2,905.0
0

848.78

2.92

73.49

21.77

576.34

2,905.0
0

850.52

2.93

73.49

2,905.0
5

833.48

73.49

103.11

103.11

1.21

1.21

103.29

0.54

0.54

-0.27

-0.27

178.08
2,905.0 1,026.8
0
6

2.87

176.78
3.53

2,905.0 1,027.3
0
0

178.08
3.54

2,905.0 1,011.5
5
6

3.48

<!-- page 74 -->

13
Quant
um
Procur
ed

Particulars

Amou
nt Rs.
Cr

Per
Unit
Cost

Claimed
Less :
Surplus
power
purchase
cost to be
disallowed
Less: 1%
Rebate on
power
purchase
cost as per
Regulations
Net Power
Purchase
Cost

Quant
um
Procur
ed

Amou
nt Rs.
Cr

Per
Unit
Cost

Quant
um
Procur
ed

Audited

Amou
nt Rs.
Cr

Per
Unit
Cost

Allowable

204.41

59.72

9.91

2,905.0 1,026.8
0
6

3.53

2,905.0 1,027.3
0
0

3.54

2,905.0
5

941.92

DISTRIBUTION LOSSES
18.

2.92

MePDCL has requested the Hon’ble Commission to approve the
distribution losses of 12.83% for the FY 2022-23 against the approved
trajectory of 12% which may be disapproved outrightly as such inefficiency
result in burden of cost on the end consumers. Further, the Petitioner has
stated that it has include sub-transmission losses of 2% based on empirical
studies done in house and additional 2% for substantial amount of energy
consumed by MePDCL several sub-stations, subdivision offices, head office,
workshops for calculation of T&D Loss. Such claim without any
substantiating document or supporting may not be accepted by the Hon’ble
Commission. Such claim needs to be supported by the detail study and

3.24

<!-- page 75 -->

14
energy consumed by MePDCL may be outlined separately rather than
adjusting in the T&D Loss.
19.

Further, in the tariff order dated 25.03.2021, in Case No. 4 of 2021, this
Hon’ble Commission has approved the T & D losses for the Petitioner at 12%
as projected in the business plan. It is submitted that the trajectory has been
determined by this Hon’ble Commission pursuant to Regulation 10 & 82 of
the Tariff Regulations, 2014 which provides as below:
“10 Specific trajectory for certain variables 10.1 While approving the Business
Plan/MYT Petition, the Commission shall stipulate a trajectory for the
variables, which shall include, but not be limited to Operation &
Maintenance expenses, target plant load factor, distribution losses and
collection efficiency: …
82 Distribution Losses
82.1 The Licensee shall furnish information on Distribution losses for previous
year and Current year and the basis on which such losses have been worked
out for ensuing years.
82.2 The licensee shall also propose a loss reduction programme for the ensuring
year as well as for the next three years duly indicating details of the
measures proposed for achieving the same.
82.3 Based on the information furnished and field studies carried out and the
loss reduction program proposed by the licensee, the Commission shall fix
suitable targets for reduction of Distribution losses for the period specified
by the Commission.”

20.

Since this Hon’ble Commission has determined the distribution loss
trajectory based on data and business plan of the Petitioner, there is no

<!-- page 76 -->

15
justifiable reason for allowing higher distribution losses. It is respectfully
submitted that after issuing regulations in terms of Section 61 of the
Electricity Act 2003, this Hon’ble Commission is required to strictly
implement the same. Therefore, no further T & D losses may be allowed over
and above the levels approved by order dated 25.03.2021.
21.

Further, it is pertinent to note this Hon’ble Commission’s in its order dated
11.04.2023 tariff for FY 2023-24 has refrained from allowing higher T & D
Losses as sought by the Petitioner. In fact, this Hon’ble Commission has
allowed lower T & D losses at 12% as determined in the order dated
25.03.2021. The relevant extract of tariff order dated 11.04.2023 is as below:
“Commission’s Analysis
The T&D and AT&C loss trajectory was notified in the MYT order dated
25.03.2021 considering the tripartite agreement entered by the Govt. of India,
Govt. of Meghalaya and MePDCL for implementation of UDAY Scheme on
09.03.2017 subject to certain mandatory performance parameters. The T&D
and AT&C losses now projected for 21.43% and 22.25% respectively for FY
2023-24 cannot be considered. The T&D and AT&C losses shall be regulated in
the True up process for FY 2023-24 after audited performance is submitted. The
T&D and AT&C losses as approved in MYT order dated 25.03.2021 shall be
prevailing for FY 2023-24 as noted below…”

22.

Therefore, it is prayed that this Hon’ble Commission may not allow higher
T&D losses. It is submitted that the Petitioner is simply asking for increased
T & D losses without any justification. The Petitioner has been acting in
violation of its commitments under the UDAY Scheme to lower T & D losses.
It is pertinent to note that in a recent judgment by this Hon’ble Commission

<!-- page 77 -->

16
in Case No. 2 of 2022, the Petitioner has been directed to implement the
milestones envisaged under the Uday Scheme. The relevant extracts of order
dated 22.09.2022 in Case No. 2 of 2022 is as below:
“In view of the submission of the Respondent MePDCL the following
Directives are passed.
Respondent MePDCL shall ensure implementation of the activities
contemplated in the UDAY Scheme expeditiously while achieving the set of
targets in the areas of T&D and AT&C losses.
Implementation of capital investment plan utilizing the Govt. Grants and
contributions borrowings if any for achieving the network up gradation and
efficiency parameters.
MePDCL shall file voltage wise network cost and ensure Energy audit upto 11
kv level for assessment of voltage wise losses in order to segregate the
Distribution business and retail tariffs.
A time bound program may be fixed to file the above data and submitted to the
commission.”

23.

In Clause 1.3(g) of the MoU executed pursuant to the Uday Scheme, the
Petitioner had undertaken to implement several activities to achieve lower
T & D losses. However, it appears that the Petitioner has acted in complete
violation of its undertaking as it has once again failed to achieve lower T &
D losses. Hence, this Hon’ble Commission may not allow pass through of
higher T & D losses as it would be only encourage inefficiencies in the state.
Also, many of the direction which is necessary to control the T&D loss is
either not complied by the Petitioner or no status has been provided in the

<!-- page 78 -->

17
petition. Such as Voltage wise network cost or energy audit upto 11 kv is not
undertaken, status of the activities as envisaged in UDAY scheme is not
provided.
24.

Further, Regulation 12.2 of the Tariff Regulations 2014 also assigns
“Variations in technical and commercial losses of Distribution Licensee” as
a controllable factor. Regulation 14 of the Tariff Regulations 2014 deal with
the treatment to be given to losses on account of controllable factors. Hence,
as per Regulation 14, no ground has been made out by the Petitioner for pass
through of increased distribution losses to the detriment of the consumers
of the state. In view of the above, it would be imprudent if the cost of the
Petitioner’s inefficiency is passed onto the consumers. Therefore, the Cost of
the surplus power procured by the Petitioner as a consequence of increased
distribution losses should be disallowed by the Hon’ble Commission as a
pass through in the Tariff.

GROSS FIXED ASSETS

25.

The Petitioner has mentioned that the Opening Gross Fixed Assets have
been considered as the closing GFA allowed by the Hon’ble Commission in
the true up order dated 21.11.2023 for the FY 2021-22. However, there seems
to be an inadvertent error by the Petitioner in reference to the date
mentioned. It is humbly submitted that the Hon’ble Commission has
undertaken the Approval of True-up of Transmission Business for FY 202122 vide Case No. 1/2023 vide order dated 13.11.2023. Hence the reference of
the date in the petition is required to be corrected. Also, it is observed that
there is a minor difference of Rs. 2.17 Crore between the approved GFA and

<!-- page 79 -->

18
GFA as per Audited accounts (Without INDAS adjustment). MePDCL to
provide the justification for the difference in the GFA opening balance.
26.

The Petitioner has submitted that as per IND AS 20, MePDCL has to account
for the grants received even if the asset against the grant is not capitalized
and hence consideration of entire grants in the statement of accounts against
the Gross Fixed Assets would not be a correct methodology. However, the
Petitioner has failed to provide the accounting treatment of the grants
specified in the said IND AS. As per “Indian Accounting Standard (Ind AS)
20 - Accounting for Government Grants and Disclosure of Government
Assistance”, it states the following reference:
“12 Government grants shall be recognised in profit or loss on a systematic
basis over the periods in which the entity recognises as expenses the related
costs for which the grants are intended to compensate.
Presentation of grants related to assets
24 3 Government grants related to assets, including non-monetary grants at
fair value, shall be presented in the balance sheet either by setting up the
grant as deferred income or by deducting the grant in arriving at the
carrying amount of the asset.
25 4 Two methods of presentation in financial statements of grants or the
appropriate portions of grants related to assets are regarded as acceptable
alternatives.
26 5 One method recognises the grant as deferred income that is recognised in
profit or loss on a systematic basis over the useful life of the asset.

<!-- page 80 -->

19
27 6 The other method deducts the grant in calculating the carrying amount of
the asset. The grant is recognised in profit or loss over the life of a
depreciable asset as a reduced depreciation expense.”

27.

As stated in the above para of IND AS -20, it clearly stated that though the
grant is to be recognized as balance sheet item, as per the income approach,
the government grants should be recognized in profit or loss on a systematic
basis over the periods in which the entity recognizes as expenses the related
costs for which the grant is intended to compensate which is depreciation.
Hence, when depreciation on assets has been calculated which is funded by
the Grant as an expenditure, the deferred income of the grant also is
required to be address on a systematic basis.

28.

Accordingly, the Hon’ble Commission has considered the approach of prorata basis of the depreciation in proportion to the grant to be considered as
income and adjusted in depreciation amount which is a correct approach.
Further, as submitted by MePDCL with respect to approach adopted by
other State Commission on inclusion of CWIP cost, it is necessary to
maintain details of Grant received asset wise so as to identify the grant
which has been capitalized and the grant which is under CWIP. Since
considering the cash flow position, the grant as received is considered for
the capitalisation of the assets based on the required cash flow, the whole
grant has been considered against the capitalisation of the assets which
seems to be a correct issue. Alternatively, MePDCL may have to provide the
details of the grant unutilized in capitalisation and scheme wise details of
allocation of amount.
