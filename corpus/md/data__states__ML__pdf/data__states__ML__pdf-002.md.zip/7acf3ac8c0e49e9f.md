---
doc_id: "7acf3ac8c0e49e9f"
source_url: "https://khadc.nic.in/acts_rules_regulations_bills/Notification_update/IT_Materials_Scrab.pdf"
ministry: "Khasi Hills Autonomous District Council (KHADC), Meghalaya"
title: "AUCTION NOTICE Sealed Bids are Invited"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "a2547df0959e976b"
---

<!-- no text layer: pending OCR -->
