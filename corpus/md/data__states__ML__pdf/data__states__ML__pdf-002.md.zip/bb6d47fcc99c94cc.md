---
doc_id: "bb6d47fcc99c94cc"
source_url: "https://megdca.gov.in/docs/notification-07-02-20.pdf"
ministry: "District Council Affairs Department, Meghalaya"
title: "No.DCA.13/2019/110 dated 7th February, 2020"
date: ""
pages: 2
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "f6f9664d5051040b"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
DISTRICT COUNCIL AFFAIRS DEPARTMENT
ORDERS BY THE GOVERNOR
NOTIFICATION

Dated Shillong, the 7‘ February, 2020
No.DCA.13/2019/110:- Whereas, the Governor of Meghalaya, in exercise
of the powers conferred by sub paragraph (2) of Paragraph 16 of the Sixth
Schedule to the Constitution of India has assumed to himself the
administration of the Khasi Hills Autonomous District vide his Order
published in the Notification No.DCA.13/2019/109 dated Shillong, the 7
February, 2020;

And, whereas, under paragraph (b) of the said Order the Governor
may also appoint such person or authority for the discharge of the functions
and powers of the Khasi Hills Autonomous District Council;

Now, therefore, in exercise of the powers conferred by paragraph (b) of
the aforesaid order, the Governor is pleased to appoint the Deputy
Commissioner, East Khasi Hills District to exercise all the functions and
powers exercisable by the Executive Committee, Chief Executive Member,
Deputy Chief Executive Member, Chairman, Deputy Chairman and
Executive Member for the aforesaid District Council subject to such
direction as may be issued by the Governor from time to time;

In exercising the functions and powers under this order the Deputy
Commissioner, East Khasi Hills District shall be designated as the
“Administrator, Khasi Hills Autonomous District Council.”

Sd/-W. Rapthap
Deputy Secretary to the Govt. of Meghalaya,
District Council Affairs Department
ele
Memo.No.DCA.13/2019/110 (A) Dated Shillong, the 7» February, 2020
Copy forwarded to:-
1. The Secretary to the Governor of Meghalaya, Raj Bhavan, Shillong.
2. The Private Secretary to the Chief Minister/ Deputy Chief Minister for
kind information of the Chief Minister/ Deputy Chief Minister.
. 3. The Private Secretary to the Minister In-charge District Council Affairs
for kind information of the Minister.
4. The Private Secretary to all the Ministers for kind information of the
Ministers.
Page 1 of 2

<!-- page 2 -->

5. The Private Secretary to the Chief Secretary Government of Meghalaya
for kind information of the Chief Secretary.

6. The Private Secretary to the Additional Chief Secretary to the
Government of Meghalaya for kind information of the Additional Chief
Secretary.

7. The Deputy Commissioner, East Khasi Hills District, Shillong for
information and necessary action.

8. The Principal Secretary, Law Department for information.

9. The Secretary, Khasi Hills Autonomous District Council, Shillong for
information and necessary action.

10. The Secretary, Executive Committee, Khasi Hills Autonomous District
Council, Shillong.

11-the State Informatics Officer, NIC Building, Shillong for favour of
updating in the official website of the Department.

12. The Director, Printing & Stationery, Meghalaya, Shillong for favour of
publication of the above notification in the Extra-ordinary Gazette of
date and to supply 20 copies of the printed notification to this
Department.

By Order etc.,
ia
Deputy Secretary to the Govt. of Meghalaya,
District Council Affairs Department.
Page 2 of 2
