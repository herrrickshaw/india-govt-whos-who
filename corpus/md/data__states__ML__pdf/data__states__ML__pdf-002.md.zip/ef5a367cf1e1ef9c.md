---
doc_id: "ef5a367cf1e1ef9c"
source_url: "https://megahvt.gov.in/tenders/Vaccines_288_23Sept_2022.pdf"
ministry: "Animal Husbandry and Veterinary Department, Meghalaya"
title: "Empanelment as Supplier(s) of Veterinary Vaccines at the Animal Husbandry & Veterinary Department, Meghalaya, Shillong"
date: ""
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b5b68f365b8fb39d"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
DIRECTORATE OF ANIMAL HUSBANDRY & VETERINARY
MEGHALAYA::SHILLONG

Phone No. 94361-81849

Email: meghvety01@gmail.com
dated Shillong, the 23rd September 2022

No.MVD/Acctt/G-39/2022-23/288,

NOTICE INVITING TENDER (NIT)
TENDER FOR EMPANELMENT AS SUPPLIER(S) OF VETERINARY VACCINES AT
THE ANIMAL HUSBANDRY & VETERINARY DEPARTMENT,
MEGHALAYA, SHILLONG

Sealed Tenders affixing non-refundable Court Fee Stamp of ₹250/- (Rupees Two
Hundred Fifty only) are invited from reputed Manufacturers, Registered/Authorized Dealers
for “Empanelment as Supplier(s) of Veterinary Vaccines at the Animal Husbandry &
Veterinary Department, Meghalaya, Shillong”.
The details of tender and tender document can be obtained from the Directorate of
A.H & Veterinary or downloaded from http://megahvt.gov.in on payment of ₹ 1,000/(Rupees one thousand only) by DD/IPO drawn in favour of “The Director of AH &
Veterinary, Meghalaya, Shillong” and payable at Shillong which is non-refundable.
CRITICAL DATE SHEET AND OTHER DETAILS
Published date
Bid document download / Sale start date
Bid submission start date
Bid submission end date
Bid opening date
Place of opening of bid
Address for communication

24th September 2022
24th September 2022
26th September 2022
25th October 2022 at 2:00 PM
25th October 2022 at 2:30 PM
Directorate of AH & Veterinary,
Lumdiengjri, Shillong 793002
The Director of AH & Veterinary,
Lumdiengjri, Shillong 793002

All future modification/corrigendum to the Tender Document shall be made available
in the Department’s web site only.

Sd/Director A.H. & Veterinary
Meghalaya, Shillong
******

<!-- page 2 -->

GOVERNMENT OF MEGHALAYA
DIRECTORATE OF ANIMAL HUSBANDRY & VETERINARY
MEGHALAYA::SHILLONG

Phone No. 94361-81849

Email: meghvety01@gmail.com

No.MVD/Acctt/G-39/2022-23/288,

dated Shillong, the 23rd September 2022

TENDER DOCUMENT
Sealed Tenders affixing non-refundable Court Fee Stamp of ₹250/- (Rupees Two
Hundred Fifty only) are invited from reputed Manufacturers, Registered / Authorized Dealers
for “Empanelment as Supplier(s) of Veterinary Vaccines at the Animal Husbandry &
Veterinary Department, Meghalaya, Shillong” as per following details and Terms and
Conditions:

1. NATURE & SCOPE OF WORK:
1.1

“Empanelment as Supplier(s) of Veterinary Vaccines at the Animal Husbandry &
Veterinary Department, Meghalaya, Shillong” as per terms and conditions
mentioned herein.

2. ELIGIBILITY CRITERIA:
2.1

Bidder intending to bid shall fulfill the following eligibility criteria:

2.1.1 Shall be reputed Manufacturers, Registered/Authorized Dealers of Veterinary Vaccines
having at least 3 (three) years’ experience in supplying such items to the AH &
Veterinary Department, Government of Meghalaya.
2.1.2 Should have proven Financial Status capability, proof of which shall be in the form of
last 5 years’ balance sheet / audited statement of accounts.
2.1.3 Should not have been banned / blacklisted / temporary suspended by any Government
Department / Organisation.
3. INSTRUCTIONS TO BIDDERS:
3.1

The tender document can be obtained from the Directorate of A.H & Veterinary or
downloaded from http://megahvt.gov.in on payment of ₹1000/- (Rupees one

Page 1 of 17
Authorized Signatory of firm with seal

<!-- page 3 -->

thousand only) by DD/IPO drawn in favour of “The Director of AH & Veterinary,
Meghalaya, Shillong” and payable at Shillong which is non-refundable.
3.2

The Bidder qualifying the above criteria at Sl. 2 shall submit the bids in TWO
SEPARATE SEALED ENVELOPES.

3.3

Sealed Envelope (A) which is the “TECHNICAL BID” inside which all documents
morefully described at Sl. 4 of this document shall be kept.

3.4

Sealed Envelope (B) which is the “FINANCIAL BID” inside which the format duly
filled up as per Annexure-IV is to be kept.

3.5

Both Envelope (A) and Envelope (B) must then be placed in one larger sealed
Envelope (C)

which is the

“MAIN ENVELOPE”

and

superscribed as

“Empanelment as Supplier(s) of Veterinary Vaccines at the Animal Husbandry &
Veterinary Department, Meghalaya, Shillong”. The same is to be addressed to the
Director of Animal Husbandry & Veterinary, Lumdiengjri, Meghalaya, Shillong –
793002.
3.6

The name, address, email and contact number of the firm submitting the Tender
must appear distinctly on every sealed envelope.

3.7

The sealed “MAIN ENVELOPE” shall be dropped at the designated box in the
office of the Director of AH & Veterinary, Lumdiengjri, Meghalaya, Shillong-793002.

3.8

Unsealed materials will not be accepted. Bidder shall be responsible for proper sealing
of the Bid Documents to prevent accidental opening.

3.9

Bids must be written in English.

3.10 Price should be quoted in Indian Rupee both in figures and in words.
3.11 The last date of receiving the Tender is on the 25th October 2022 upto 2:00 PM and
will be opened on the same day at 2:30 PM in the Office Chamber of the Director
of A.H. & Veterinary Meghalaya, Shillong. Tenderers or their representatives if
desired may be present at the time of opening of the Tender.
3.12 Financial Bid will be opened at a later date to be intimated accordingly.
Page 2 of 17
Authorized Signatory of firm with seal

<!-- page 4 -->

3.13 Any Bid(s) received after the deadline for submission will be rejected outright and
bidder will have to collect their bid document at their own expenses. In case any
unscheduled holiday occurs on the prescribed closing/opening date the next working
day shall be the prescribed date of closing/opening of the Tender.
3.14 All Tenders should be accompanied with an Earnest Money Deposit which shall
morefully described at Sl. 6 of this document.
3.15 Every sheet of Tender Document, complete in all respect, and all Forms/
Annexures/ Enclosures, shall be signed by the person/persons duly authorized to sign
on behalf of the applicants as a token of having understood and accepted all terms and
conditions mentioned in Tender Document. Any /all corrections made in the offer shall
be duly authenticated by the signature of the authorized signatory. Tenders received
without signature with seal of the firm(s) on all pages will be rejected.
3.16 The submitted documents are not transferable and the seal and signature of the
authorized official of the firm(s) must appear on all the papers and envelopes
submitted.
3.17 Clarification on Tender document: Applicants may seek clarification on the tender
document within 10 (ten) working days from the date of appearing of advertisement in
local dailies. Any request for clarification must be sent by email to the Director’s
email address ONLY (meghvety01@gmail.com).
3.18 At any time prior to the date of submission of Tender, Director of AH & Veterinary,
Meghalaya, Shillong, may, for any reason, either of its own or in response to a
clarification from an interested firm, modify the NIT by an amendment / corrigendum.
Any such amendment / corrigendum as deemed necessary by the Director, AH &
Veterinary Department, will be notified through the Department’s website only.
Interested firms are advised to check the Department’s website every now and then for
any amendment / corrigendum.
3.19 In order to provide reasonable time to take the amendment into account in preparing the
documents, Director of AH & Veterinary, Meghalaya, Shillong may extend the date
and time for submission of Tender.

Page 3 of 17
Authorized Signatory of firm with seal

<!-- page 5 -->

3.20 The Director of AH & Veterinary, Meghalaya, Shillong reserves the right to
accept, reject or partially accept any Tender or any items without assigning any
reasons thereof.
3.21 The Director of AH & Veterinary, Meghalaya, Shillong is not bound to accept the
lowest quotation / highest discount, offered.
3.22 Conditional Tender not acceptable: All the terms and conditions mentioned herein
must be strictly adhered to by all the firms. Conditional Tender shall not be accepted on
any ground and shall be rejected straightway. Conditions mentioned in the Tender
submitted by vendors will not be binding on Director of AH & Veterinary, Meghalaya,
Shillong.
4.

DOCUMENTS TO BE SUBMITTED WITH THE TENDER:

4.1

The following documents are to be enclosed with the Tender in Sealed Envelope
(A) which is the “TECHNICAL BID” otherwise the bid will not be considered:
4.1.1

Declaration as per format at Annexure I.

4.1.2

EMD in the form of Demand Draft which is morefully described at Sl. 6 of
this document.

4.1.3

Brief history/background of the Firm along with complete details of
personnel authorized to take up the project.

4.1.4

Similar assignment done by applicant during the previous three financial
years which is to be supported by documents. A NIL declaration may be
submitted in the event of bidder(s) not having the experience.

4.1.5

Details of Financial status of applicant in the form of last 5 (five) years’
balance sheet / audited statement of accounts.

4.1.6

Compliance Certificate as per format at Annexure-III.

4.1.7

Distributorship Certificate: Tenders submitted by authorized dealers for a
particular Company should furnish necessary documents as proof of being
authorized dealer(s).
Page 4 of 17

Authorized Signatory of firm with seal

<!-- page 6 -->

4.1.8

Authenticated copy of the Product Catalogue(s)

4.1.9

Authenticated copy of Price list(s) in hard and soft copy (in excel or word
file only)

4.1.10

Authenticated copy of valid Drugs License issued by the Competent
Authority.

4.1.11

Authenticated copy of valid GST Registration Certificate.

4.1.12

Authenticated copy of valid Professional Tax Clearance Certificate.

4.1.13

Authenticated copy of Income tax clearance or Scheduled Tribe Certificate
by Tribal Firm(s).

4.1.14

Authenticated copy of valid Trading License Certificate for Firms/
Suppliers other than Scheduled Tribe of the State.

4.1.15

Authenticated copy of valid PAN/ TIN.

4.1.16

Proof of payment of Tender document in the form of a Receipt from the
Cashier of the Directorate of AH & Veterinary or DD/IPO drawn in favour of
“The Director of AH & Veterinary, Meghalaya, Shillong” and payable at
Shillong

4.2

The following documents are to be enclosed with the Tender in Sealed Envelope
(B) which is the “FINANCIAL BID” otherwise the bid will not be considered:
4.2.1

Financial bid as per format at Annexure IV duly filled up and signed by
authorized person of firm (Soft copy also to be submitted in word or excel file
only)

5. PERIOD OF VALIDITY:
5.1

The period of contract shall initially be for a period of one year with effect from
date of issue of contract order and is extendable for one more year on satisfactory
performance, under the same terms and conditions or with such amendments as may be
mutually agreed to, and also subject to the necessary approval of the Competent
Page 5 of 17

Authorized Signatory of firm with seal

<!-- page 7 -->

Authority. The entire period of contract shall not exceed three years, unless otherwise
notified by the Director of AH & Veterinary, Meghalaya, Shillong.
5.2

Should the Director of AH & Veterinary deem necessary to extend the period of
contract, the Bidder’s consent for the same shall be made in writing. On agreement of
extension, the Security Deposit provided shall also be suitably extended. A Bidder may
refuse the request without forfeiting the Security Deposit.

6. EARNEST MONEY DEPOSIT(EMD):
6.1

The Bidder(s) shall furnish, as a part of its bid, Earnest Money of Rs.1.00 Lakh for
general category bidder(s) & Rs.50.00 thousand in case of tribal bidder(s).

6.2

The Earnest Money is required to protect the Director of Animal Husbandry &
Veterinary against the risk of Bidder’s conduct, which would warrant the security’s
forfeiture.

6.3

The Earnest Money shall be in the form of Demand Draft pledged in favour of the
Director Animal Husbandry & Veterinary, Meghalaya payable at Shillong. Under
no circumstances cash, cheque or any other mode of payment will be accepted as
Earnest Money.

6.4

Any bid not accompanied by Earnest Money will be rejected.

6.5

Unsuccessful Bidder’s Earnest Money will be discharged or returned as promptly as
possible as but not later than ninety (90) days from the date of furnishing of contract by
the successful bidder.

6.6

The successful Bidder’s Earnest Money will be released upon the Bidder signing the
contract and depositing of Security Deposit.

6.7

The Earnest Money shall be forfeited:
6.7.1 If a Bidder withdraws his/ their bid during the period of bid validity specified by
the Bidder on the Bid Form; or
6.7.2 In case of a successful Bidder, fails to sign the contract; or

Page 6 of 17
Authorized Signatory of firm with seal

<!-- page 8 -->

6.7.3 In case any Bidder alters/ modifies their tenders after expiry of the deadline for
receipt of tender till the date of validity of tenders.
7. TERMS & CONDITIONS:
7.1

Prices quoted should be in Indian Rupees only and price quotations should be
submitted as per format given in Annexure–IV.

7.2

The purpose of the tender is to empanel all ELIGIBLE reputed Manufacturers,
Registered/Authorized Dealers as Supplier(s) of Veterinary Vaccines for the AH &
Veterinary Department. The Financial quotation will be assessed on the basis of the
discount offered by the Manufacturers or Registered/ Authorized Dealers. The
Tenderer(s) quoting at the highest discount for any particular company(s) will be
empaneled

for

that

particular

company(s).

Those

Manufacturers,

Registered/Authorized Dealers whose quoted discount fall short of the highest, but
are willing to give the same level of discount subsequently, would also be eligible
for empanelment.
7.3

The rates should be quoted inclusive of all taxes and transportation upto
destination. Taxes to be charged if any should be quoted clearly against each of the
taxable item.

7.4

The firms shall indicate discount offered, if any, on catalogue price in clear/visible
figures as well as in words and shall not alter/overwrite/make cutting in the quotation.
In case of a mismatch, the discount offered in words will prevail. Usage of “White ink”
to erase and then rewrite the discounts will not be accepted. Bidders are advised to
strike out wrong entries and rewrite clearly beside them. In such cases, the bidder shall
have to sign and place their official seal for every corrected entry.

7.5

Special discount(s), if any, applicable to supply at Institutions/ Government supply,
should be quoted separately.

7.6

If there is any change in catalogue price offered due to statutory levy increases like
taxes and duties by original manufacturer, the vendors need to submit the new
catalogue with an application to the Director of AH & Veterinary, Meghalaya, Shillong.

Page 7 of 17
Authorized Signatory of firm with seal

<!-- page 9 -->

The same will be allowed on submission of documentary evidence. However, the
discount offered shall remain same as per original rate.
7.7

Distributorship Certificate: Tenders submitted by authorized dealers for a particular
Company should furnish necessary documents as proof of being authorized dealer(s)
against their Principals/ Companies otherwise their Tender will not be entertained.
Tenderers shall hold responsibility on any infringement of other Manufacturer’s
products.

7.8

Authenticated copy of the Product Catalogue should be submitted otherwise their
Tender will not be entertained.

7.9

Authenticated copy of Price list should be submitted both in hard and soft copy (in
excel or word file only) otherwise their Tender will not be entertained.

7.10 The firms must attach a copy of valid GST Registration Certificate, failing which the
quotation will be rejected.
7.11 All Tenders must be accompanied with the following documents failing which the
Tender will not be considered:
a) copy of valid Professional Tax Clearance Certificate
b) copy of valid PAN/ TIN
c) Scheduled Tribe Certificate by Tribal Firm(s), and
d) Valid Trading License Certificate for Firms/ Suppliers other than
Scheduled Tribe of the State of Meghalaya, issued from the respective
District Councils of the State
7.12 Tenderer dealing with Chemicals, Drugs, Vaccines should furnish a valid copy of the
drugs license issued by the Competent Authority.
7.13 Preference will be given to Manufacturers or Registered/Authorized Dealers having
proven Financial Status capability and having experience in supplying Veterinary
Vaccines for the past 3 (three) financial years to the AH & Veterinary Department,
Government of Meghalaya.

Page 8 of 17
Authorized Signatory of firm with seal

<!-- page 10 -->

7.14 Successful bidder(s) will be officially informed. On award of the contract, the
successful bidder(s) should execute an agreement with Directorate of Animal
Husbandry & Veterinary on non-judicial stamp paper of ₹100/- (Rupees one hundred)
while incorporating all the Terms and Conditions of the contract. This shall be at the
expense of the supplier and shall be executed within 15 (fifteen) days of final
acceptance of the Tender.
7.15 Successful bidder other than Scheduled Tribe of the State of Meghalaya has to
obtain Trading License from the respective Autonomous District Councils of the
State of Meghalaya at their own cost.
7.16 No supply order shall be affected unless the deed of contract is executed and the
security money is deposited. If the security money is not deposited within the time
fixed for the purpose, the amount deposited as earnest money shall be forfeited and
credited to the Government. The firms who fail to execute the Agreement after the rate
have been approved, shall have to make good the loss caused to Government through
their inability, default on delay caused to comply with terms and conditions of the
Tender Notice and in the first instance their earnest money shall remain forfeited to the
Government.
7.17 Once the contract is made the Supplier shall have to maintain a regular supply of
items when ordered for. If the supplier fails to maintain a regular supply of the
approved articles against any order, his contract shall be liable to be terminated and the
security deposit forfeited to Government.
7.18 The supplier shall have to supply the articles indented for within 1 (one) month from
the date of placing orders, failing which the orders will automatically be treated as
cancelled and their earnest money shall be forfeited and the excess value paid thereof
will be deducted from the security deposit. However, the Indenting Officers may extend
the time of supply on receipt of a specific request from the Suppliers for their inability
to supply any item on some genuine ground.
7.19 Loss, Damage and Shortage: The required Veterinary items must be supplied to the
Indenting Officer at the risk of the Firm / Supplier(s) who shall be responsible for any
leakage, damage or loss in transit. Payment shall be made for materials received in
Page 9 of 17
Authorized Signatory of firm with seal

<!-- page 11 -->

good conditions only and no articles will be received which are damaged in any form.
Any damage or shortage noticed on delivery, the same must be replaced within 7
(seven) days after intimation.
7.20 Payment: No advance payment shall be made by the Department to the awardee. 100%
payment within 30 (thirty) days from date of delivery and only after the Provisional
Acceptance Certificate (PAC) is received duly certifying that the items have been
received in good condition as per the specifications of the contract.
7.21 Procuring Entity’s right to vary quantity:
7.21.1 At the time of award of contract, the quantity of Drugs/ Vaccines, originally
specified in the bidding documents may be increased or decreased. There will
not be any minimum quantity guaranteed against bid quantity. The bid quantity
is only indicative. Actual purchase can be more or less than the bid quantity
based on actual consumption by the Department.
7.21.2 If the procuring entity does not procure any subject matter of procurement, or
procures less than the quantity specified in the bidding documents due to change
in circumstances, the bidder shall not be entitled for any claim or compensation.
7.22 The contract can be terminated at any time by giving one month’s notice from
either side. However, if the selected supplier(s) fail(s) to comply with the terms and
conditions of the contract, then the Director of AH & Veterinary is empowered to
terminate the contract with short notice of one week.
7.23 If the rate quoted is signed at a lower price with any other organization subsequent to
award of contract by Director of AH & Veterinary, the firm(s) must supply the
items/materials under the rate contract at those rates.
7.24 Force Majeure: If the performance of the obligation of either party is rendered
commercially impossible by any of the events hereafter mentioned that party shall be
under no obligation to perform the agreement under order after giving notice of
15(fifteen) days from the date of such an event in writing to the other party, and the
events referred to are as follows:

Page 10 of 17
Authorized Signatory of firm with seal

<!-- page 12 -->

7.24.1

Any law, statute or ordinance, order action or regulations of the Government.

7.24.2

Any kind of natural disaster, and

7.24.3

Strikes, acts of the Public enemy, war, insurrections, riots, lockouts, sabotage.

7.25 Taxes and duties: The supplier shall be entirely responsible for all taxes and duties etc.
incurred until completion of the contract. TDS wherever applicable shall be deducted at
source as per extant laws.
8. SECURITY MONEY
8.1

Within 15 (fifteen) days of award of contract, the successful bidder shall be required to
furnish a security money at the rate to be determined after finalization of Tender.

8.2

The Security Deposit shall be in one of the following forms:
8.2.1

Bank Guarantee, issued by a reputable bank, or

8.2.2

Deposit at Call Receipt in favour of The Director A.H. & Veterinary,
Meghalaya, Shillong and payable at Shillong.

8.3

The proceeds of the Security Deposit shall be payable to the Director of Animal
Husbandry & Veterinary as compensation for any loss resulting from the Supplier’s
failure to complete the obligations under the contract.

8.4

Failure of the successful Bidder(s) to sign the Contract and/or furnish the Security
Deposit shall constitute sufficient grounds for the annulment of the award and forfeiture
of the Earnest Money. In that event, the Director of Animal Husbandry & Veterinary
shall have the liberty to award the Contract to the second lowest responsive tenderer.

8.5

The Security Deposit will be released by the Director of Animal Husbandry &
Veterinary and returned to the Supplier not later than 90 days following the date of
completion of the Supplier’s performance obligations under the contract.

Page 11 of 17
Authorized Signatory of firm with seal

<!-- page 13 -->

9. NOTIFICATION OF AWARD
9.1

Prior to the expiration of the period of bid validity, the Director of Animal Husbandry
& Veterinary will notify the successful bidder(s) in writing.

9.2

The notification of award will constitute the formation of the contract.

10. PENALTY CLAUSE
10.1 For non-performance/delayed performance, the following penalties may be imposed on
the successful bidder, without assigning any reasons thereof. This is however subject to
obtaining of extension in writing from the Director of Animal Husbandry & Veterinary
on valid ground before expiry of delivery period:
10.1.1

Terminate the contract / purchase order in whole or in part

10.1.2

Forfeiture of Security Deposit

10.1.3

Imposition of penalty @ 5% (five percent) of the total value of the item

covered
10.1.4

in supply order, per week of delay.
Procurement of the items, in such terms and in such manner, as is deemed
appropriate by the Director of AH & Veterinary, Meghalaya, Shillong, items
similar to the undelivered items/products and the defaulting supplier shall be
liable to compensate Director of AH & Veterinary, Meghalaya, Shillong for

any

extra expenditure involved towards goods and services obtained.

11. RIGHT TO ACCEPT ANY BID AND TO REJECT ANY OR ALL BIDS:
11.1 The Director of Animal Husbandry & Veterinary reserves the right to accept or reject
any bid, and to annul bid process and reject all bids at any time prior to contract award,
without thereby incurring any liability to the affected Bidder or bidders or any
obligation to inform the affected Bidder or bidders of the grounds for the Director of
Animal Husbandry & Veterinary’s action.
12. SAVING CLAUSE
12.1 No suit, prosecution or any legal proceedings shall lie against Bid Inviting

Authority or any person for anything that is done in good faith or intended to be
done in pursuance of Bid.

Page 12 of 17
Authorized Signatory of firm with seal

<!-- page 14 -->

13. RESOLUTION OF DISPUTES
13.1 The Director of Animal Husbandry & Veterinary and the Agency/Firm shall make
every effort to resolve amicably by direct informal negotiation any disagreement or
dispute arising between them under or in connection with the contract, failing which
either party may approach a competent court having jurisdiction to resolve the dispute.
In connection with this tender, cases, if any, shall be subject to the jurisdiction of
competent court at Shillong.
13.2 For resolution of disputes, appropriate legal action shall be initiated in consultation with
Law Department, Government of Meghalaya. Relevant sections of Indian laws as
amended from time to time shall be applicable and binding on the bidder.

Sd/Director A.H. & Veterinary,
Meghalaya, Shillong
******

Page 13 of 17
Authorized Signatory of firm with seal

<!-- page 15 -->

ANNEXURE I
(Format of Declaration to be printed in Letter Head of Firm/ Agency & to be enclosed with
Tender)
DECLARATION
I/We, _____________________________________the authorised signatory on behalf of
_______________________________________________________, do solemnly declare that:
1. I/We have carefully read and agreed with all Terms and Conditions of Tender for

“Empanelment as Supplier(s) of Veterinary Vaccines at the Animal Husbandry &
Veterinary Department, Meghalaya, Shillong”.
2. All information furnished by me/us in respect of fulfilments of eligibility criteria and
qualification information of this Tender is complete, correct and true.
3. If any information furnished by me/us in support of the information furnished by me/us is
found to be false/incorrect at any time, the Director of Animal Husbandry & Veterinary,
Meghalaya, Shillong may cancel my Tender and action as deemed fit may be taken against me/us,
including termination of the contract, forfeiture of Earnest Money and banning/ delisting of our
firm and all partners of the firm for a minimum period of 01 (one) year.
4. I/We have never been banned or delisted/ black listed by any Govt. or Quasi Govt. Agency or
any Public Sector Undertaking.
5. All documents / credentials submitted along with this tender are genuine, authentic, true and
valid.

Full Signature & seal of the Authorized person
Date & Place: ________________________

Page 14 of 17
Authorized Signatory of firm with seal

<!-- page 16 -->

ANNEXURE II
A. TENTATIVE LIST OF REQUIRED VETERINARY VACCINES
Sl.No
1

Category
Poultry vaccines

Vaccines
a) Marek’s Disease
b) Ranikhet Disease
c) Infectious Bursal Disease (IBD)
d) Fowl Pox
e) Inclusion Body Hepatitis (IBH)
f) Avian Infectious Bronchitis Vaccine
g) Infectious coryza vaccine
h) Fowl Cholera Vaccine
i) Salmonella Vaccine

2

Livestock

a) Goat Pox Vaccine
b) Peste Des Petits Ruminants Vaccine
c) Enterotoxaemia Vaccine
d) Haemorrhagic SepticaemiaVaccine
e) Blackquarter Vaccine
f) Haemorrhagic Septicaemia+ Blackquarter Vaccine
g) Anthrax Spore Vaccine

3

Others

a) Anti Rabies vaccine

Page 15 of 17
Authorized Signatory of firm with seal

<!-- page 17 -->

ANNEXURE III
(To be filled by the Bidder & enclosed with Tender)
COMPLIANCE CERTIFICATE
Sl. No. NIT Terms and Conditions

Yes/No

1.

Discounts quoted as per instruction

2.

Payment term agreed

3.

Delivery terms agreed

4.
5.

Authorized Dealership / distributorship certificate (in case of dealers/agents)
provided
Manufacturer certificate provided (if applicable)

6.

Resolution of disputes terms agreed

7.

Copies of supply / empanelment order from AH&Vety. Deptt. submitted

8.

GST Certificate provided

9.

PAN / TIN provided

10.
11.

Soft copy and hardcopy of Product Catalogue and Price list submitted as
instructed
Earnest Money Deposit (EMD) submitted as instructed

12.

Proof of financial status of the agency submitted as instructed

13.

Valid Professional Tax Certificate submitted as instructed

14.

Brief history of Firm along with authorized contact person submitted

Note: It is mandatory to attach the authenticated/ self-attested copy of required
certificates/proof with above information

Signature with Seal:..…………….

Date & place: ___________________________
Name of Supplier/Firm: ..………………

Page 16 of 17
Authorized Signatory of firm with seal

<!-- page 18 -->

ANNEXURE – IV
(To be submitted in Bidder’s letter head SEPARATELY for each category and each company
and enclosed with Tender)
(Soft copy also to be submitted in excel or word file only)
FORMAT OF FINANCIAL BID FOR SUPPLY OF VETERINARY VACCINES
Category of Veterinary Vaccines: POULTRY/ LIVESTOCK/ OTHERS (strike out not
related category)
Name of Company: ___________________________________________
Sl. No. Cat. No. Description

Make/
Brand/
Mark

Unit/
packing

Rate
(in₹)

Percentage of
discount
(if any)

Special discount
(if any)

Figures Words Figures Words

Certified that the Price List/ Product Catalogue of M/s._________________________
(Name of the company) for Items at Sr.No.___ to ____, submitted against NIT
No.MVD/Acctt/G-39/2022-23/______ dated Shillong, the ____________ 2022 for the
year 2022-23 is uniform price list throughout the territory of India and we are not giving
higher discount to any other Institute/Department, etc.
We have carefully read and understood the terms and conditions of the bid document and
we do hereby undertake to supply as per these terms and conditions.

Signature with Seal:..………………..…….
Name of Supplier/Firm: ..………………
Address…………………………………….
Phone/ Mobile No. ………………………..
Email ……………………………………...
Date ………………………………………..

Page 17 of 17
Authorized Signatory of firm with seal
