---
doc_id: "d02baed5cbd9936e"
source_url: "https://ditmeghalaya.gov.in/pdf/Clarifications_corrigendum_addendum.pdf"
ministry: "Information Technology & Communication Department, Meghalaya"
title: "Clarifications Corrigendum Addendum for 'Construction of IT Park at Tura, West Garo Hills District, Meghalaya'"
date: ""
pages: 4
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "0f0500bd0884b967"
---

<!-- page 1 -->

= ee ot eS te TT
Cy Meghalaya
Information Technology Society
cites. pte,
NIC Building, Secretariat Hill, Shillong 793 001.
Si eter on
No. MITS.27/2023/Pt/45+ , Dated Shillong the 2" February, 2024
CLARIFICATION , CORRIGENDUM AND ADDENDUM
Request for Proposal (RFP) for the Construction of IT Park at
Tura, West Garo Hills District, Meghalaya on Design,
Engineering, Procurement and Construction (EPC) Basis
(RFP No. MITS.27/2023/Pv2 , dated 17" February, 2024)
Further toRFP, amendments are notified as below. All other requirements
infc tion/ Te 1d Conditie hall remai hi -
information/ Terms and Conditions shall remain VS
LS, em

<!-- page 2 -->

A. CLARIFICATIONS
Queries by Badri Rai & Co.
So ee ee ats ea ve
ITT/ Clause No: 8.0 he Bidder shall furnish, as part of its Bid, a Bid security in| EMD-BG format. MD-BG format as per Annexure V of NIT.
he form of Demand Draft / Bank Guarantee issued by an
jationalized / Scheduled Bank located in India, of Rupees,
ifty Lakhs pledged in favour of "Member Secretary,
leghalaya Information Technology Society”, payable at!
Shillong, Meghalaya.
Queries by ATW (INDIA) Pvt. Ltd.
fel Cl: No. of NIT
ee | Description of the clause as per NIT Query/Clarification Reply
1 |ITT/ Clause No: 8.0 he Bidder shall furnish, as part of its Bid, a Bid security inBank details of client required for making Bank A/c No:30035959316
he form of Demand Draft / Bank Guarantee issued by an’ BG. FSC Code:SBIN0006320.
lationalized / Scheduled Bank located in India, of Rupees|
ifty Lakhs pledged in favour of "Member Secretary,
leghalaya Information Technology Society", payable at!
hillong, Meghalaya.
MEORMae~
Se & Sep.
Leas \ 4
oO A =
Z x

<!-- page 3 -->

B. CORRIGENDUM
1 ITT/ Clause No: 8.0 1 Bidder shall furnish, as part of its Bid, a Bid security in the form of DemandThe Bidder Shall furnish, as part of its Bid, a Bid security in the form
Draft / Bank Guarantee issued by any Nationalized / Scheduled Bank locatedof Demand Draft / Bank Guarantee issued by any Nationalized
in India, of Rupees Fifty Lakhs pledged in favour of "Member Secretary,Scheduled Bank located in India, of 1% for Tribals and 2% for Non
leghalaya Information Technology Society", payable at Shillong, Meghalaya. |Tribals/Firms/Joint Ventures/Others of the Tender Value pledged in|
favour of "Member Secretary, Meghalaya Information Technolog
Society", payable at Shillong, Meghalaya.
WFEOR,,>
ae Nv
SS N&, eZ
’ E/ OXe -
of eo a
eye ran x
Neti 9)
NSoos ee

<!-- page 4 -->

: C. ADDENDUM- NIL
<p INFO,
Lae a
ONG (oe)
Wy Ys
Vy ie O55 rete
