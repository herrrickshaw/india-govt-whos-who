---
doc_id: "3e9d9dec0b85d8fa"
source_url: "https://gad.meghalaya.gov.in/assets/docs/tenders/corrigendum_27_05_26.pdf"
ministry: "General Administration Department, Meghalaya"
title: "Corrigendum: Extension of submission of bids"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "5a32e8c2deb96235"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
GENERAL ADMINISTRATION (A) DEPARTMENT
No. GAA 25/2016/264 Dated Shillong the 27 May, 2026
CORRIGENDUM
In partial modification of this Department’s Corrigendum No. GAA
25/2016/Pt.III/13 dated 14! April, 2026, the last date & time for submission of
Bids is extended up to 12t* June,2026 till 11:00 A.M. Other particulars remain
the same.
Sd/
Secretary to the Govt. of Meghalaya,
General Administration Department.
Memo No. No. GAA 25/2016/264-A Dated Shillong the 27 May, 2026
ee Informatics Officer, National Informatics Centre, Meghalaya,
Shillong for uploading the Corrigendum in the Department website
gad.meghalaya.gov.in (soft copy enclosed in CD).
2. The Director of Information & Public Relation, Meghalaya, Shillog to
publish on any 1(one) leading News Paper i;e English, Khasi & Garo.
By Order etc.,
Under Secretary to the Govt. of Meghalaya,
General Administration (A) Department.
