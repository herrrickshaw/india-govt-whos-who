---
doc_id: "db5e8640e6af0edf"
source_url: "https://megdca.gov.in/docs/notification128-14-02-22.pdf"
ministry: "District Council Affairs Department, Meghalaya"
title: "No.DCA.81/2015/Pt I/128 dated 14th February, 2022"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "b1f820b823288e56"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
DISTRICT COUNCIL AFFAIRS DEPARTMENT
ORDERS BY THE GOVERNOR
NOTIFICATION 5
Dated Shillong, the 14th February,2022

No.DCA.81/2015/Pt I/128:- It is hereby notified for general information that

the Garo Hills Autonomous District Council in its Special Session held on 31st

January, 2022 (Monday), at Tura, has duly elected Shri Rakesh A. Sangma, as

the new Chief Executive Member of the Council.

Sd/- T.Lyngwa, IAS
Secretary to the Govt. of Meghalaya,
District Council Affairs Department

Memo.No.DCA.81/2015/Pt 1/128 (A) Dated Shillong, the 14t» February,2022

Copy forwarded to:

1. The Commissioner & Secretary to the Governor of Meghalaya, Raj
Bhavan, Shillong.

2. The P.S to the Chief Minister for kind information of the Chief Minister.

3. The P.S to the Deputy Chief Minister for kind information of the Deputy
Chief Minister

4. The P.S. to the Minister In-charge DCA Department/All Ministers for
kind information of the Minister/ Ministers.

5. The Private Secretary to the Chief Secretary, Government of Meghalaya,
for kind information of the Chief Secretary.

6. The Private Secretary to the Additional Chief Secretary to the
Government of Meghalaya, for kind information of the Additional Chief
Secretary.

io The Deputy Commissiofier, West Garo Hills District, Tura.

8. The Secretary, Law Department, for information.

9. The Chief Executive Member, Garo Hills Autonomous District Council,
Shillong.

10. The Chairman, Garo Hills Autonomous District Council, Shillong, for
information.

11. The Secretary to the District Council, Garo Hills Autonomous District
Council, Shillong with reference to letter No.GDC-L/23/2004/46 dated
31st January, 2022

12. The Secretary, Executive Committee, Garo Hills Autonomous District

_ Council, Shillong.

130 The State Informatics Officer, NIC Building, Shillong for favour of
updation of the official website of the Department.

14. The Director, Printing & Stationery, Meghalaya, Shillong for favour of
publication of the above notification in the Extra-ordinary Gazette of date
and to supply 20 copies of the printed notification to this Department.

By Order etc..,
al WW
i | vr)
Under Secretary to the Government of Meghalaya,
District Council Affairs Department.
