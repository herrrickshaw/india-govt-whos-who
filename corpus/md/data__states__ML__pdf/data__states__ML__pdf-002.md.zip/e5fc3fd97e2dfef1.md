---
doc_id: "e5fc3fd97e2dfef1"
source_url: "https://megcooperation.gov.in/actsnrules/The%20Meghalaya%20Cooperative%20Society%20Rule.pdf"
ministry: "Co-operation Department, Meghalaya"
title: "The Meghalaya Cooperative Society Rules (Assam Rules 1953 as adapted by Meghalaya)"
date: ""
pages: 48
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3df3649de3d80021"
---

<!-- page 1 -->

THE MEGHALAYA CO-OPERATIVE SOCIETIES RULES
(ASSAM RULES, 1953 AS ADAPTED BY MEGHALAYA)
CHAPTER I
Preliminary
Serial No. of Rules
1. Short title and extend.
2. Definations.
CHAPTER II
Registration of societies
3. Ristriction on acquisition of shares in society.
4. Charge of liability.
5. Application for registration.
6. Conditions of registration of a society and refusal to register.
7. Restriction and limit of Membership.
8. Provisions in the bye -laws of society.
9. Amendment of bye-laws.
10. Mode of Amendment of bye -laws.
11. Amendment of bye-laws at the direction of the Registrar.
12. Amendment of bye-laws at the suggestion of affiliating society.
13. Adaption of rules of procedure
14. Non-official helpers.
CHAPTER III
Right and Liabilities o f members of registered societies
15. Exercise of rights of membership.
16. Disqualification for voting.
17. Promoters of unlimited liability society and member of all other societies, seeking
loan to furnish information as to financial position
18. The manner of recalling a loan not utilised for the purpose for which advanced.
19. Restrictions on transfer of shares or interest.
20. Nomination of transferee.
21. Procedure for calculating the value of shares or interest of ceased members.
22. Manner of determining value of land.
CHAPTER IV
Management
23. Chairman of General Meeting.
24. Quorum of General Assembly
25. Voting in meeting of General Assembly.
26. Records of meetings.
27. Election and retirement of Directors in a Primary Society other than non-agricultural
credit society.
Serial No. of Rules
28. Election and retirement of Directors in Non-agricultural Credit Societies.
29. Appointment of Directors by the Registrar.
30. Qualification of members of Administrative Council and Managing Committee.
31. Disqualification for membership of Administrative Council and Managing Body.
32. Ceasation of membership of Administrative Council and Managing Body.

<!-- page 2 -->

33. Removal, expulsion, etc., of the Secretary, Treasurer, Directors and other office
bearers.
34. Procedure of convening meetings of the Administrative Council and Managing
Body.
35. Power of the Administrative Council and Managing Body.
36. Duties of the Administrative Council and Managing Body.
37. Deputation of the Government servant to manage the affairs of a Co-operative
Society.
38. Duties of Executive Officer.
39. Procedure in case of difference of opinion.
40. Executive officer-Cost of his service, withdrawal, etc.
41. Suspension or supervision of an Administrative Council, a Managing or any body
42. Appointment of person or persons to manage the affairs of a Society.
CHAPTER V
Duties of Registered Society
43. Documents to be kept open to inspection.
44. Right of members of Co-operative Society with unlimited liability to see accounts.
45. Fees for inspection of documents, bye -laws, etc.
46. Fees for certified copies of documents.
47. Borrowing limit.
48. Restriction on borrowings of society with unlimited liability.
49. Restriction on borrowings of limited liability society.
50. Restrictions on borrowings by societies (I) fixed deposits.
51. Provision for fluid resources or liquid covers
52. Registrar’s power to permit a decrease in the proportion of fluid resources, etc.
53. Restriction on issue of loans.
54. Maximum and normal credit to members.
CHAPTER VI
Property and Funds of registered society
55. Investment of Funds.
56.Reserve Fund and its object.
57. Creation of reserve fund in a society
58. Use of reserve fund in the business of a society
59. Contribution to charitable purposes.
Serial No. of Rules
60. Charitable purposes.
61. Distribution of Net profits.
62. Patronage dividend or rebate
63. Payment of bonus or reuneration
64. Provision for bad and doubtful debts.
65. Provision for Building fund
66. Payment of invest on share capital.
CHAPTER VII
Audit
67. Explanation of bad or doubtful asset.
68. Writing off of bad debts
69. Date of audit of Co-operative Society

<!-- page 3 -->

70. Procedure of audit
71. Procedure of audit
72. Form of Audit statements.
73. Audit Fee.
74. Collection and assessment of audit fees.
75. Chief Auditor
76. Employment of staff for audit
77. Audit classification.
78. Audit of societies under liquidation.
CHAPTER VIII
Inquiry and Inspection
79. Procedure of incquiry under Section 60 and inspection under Section 61.
80. Inspection of affiliated societies by members of the paid staff of financing bank.
CHAPTER IX
Settlment of disputes
81. Reference of dispute
82. Disputes and appointment of arbitrators
83. Person qualified to be appointed as arbitrator
84. Payment of remuneration to arbitrators.
85. Payment of expenses of disputes referred to the Registrar.
86. Reference of a dispute
87. Fee for filing a dispute.
88. Procedure for disposal of dispute.
89. Decision or Award
90. Withdrawal of a reference by the Registrar.
91. Execution of decision or award.
92. Disposal of Records.
93. Certified copy.
94. Procedure for conditional attachment of property.
CHAPTER X
Dissolution of Society
Serial No. of Rules
95. Obligatory cancellation of registration
96. Remuneration of liquidators.
97. Procedure of taking over change and preparation of final balance sheet.
98. Issue of summons, notice, etc., by a liquidator.
99. Distribution of assets and priority of claims.
100. Termination of liquidation proceedings obligatory on the Registrar in certain cases.
101. Disposal of the records of liquadation proceedings
CHAPTER XI
Recovery of sums due and enforcement of obligations
102. Charge and surcharge
103. Gross neligence
104. Penalty.

<!-- page 4 -->

THE MEGHALAYA CO-OPERATIVE SOCIETIES RULES
* The Assam Co-operative Societies Rules, 1953 made by the Governor of Assam and
published Vide Notification No. CG 38/50/253, dated 4th February, 1953 (printed below) :“The 4th February, 1953”
No. CG. 38/50/253 - Inexcise of the powers conferred by Section 100 of the Assam Cooperative Societies Act, 1949. (Act I of 1950), the Governor Of Assam is please to make the
following rules in order to carry out the purposes of the said Act in the State of Assam.
2. The rules framed under the Co-operative Societies Act II of 1912 and adapted under
Notification No. 963 L. S. G. (A), dated the 18th April, 1941 are hereby recinded.
THE MEGHALAYA COOPERATIVE SOCIETIES RULES (ASSAM RULES, 1953
AS ADAPTED BY MEGHALAYA)
CHAPTER – 1
Preliminary
1. Short title – these rules may be called the Meghalaya Cooperative Societies Rules.
2. Definition In these rules unless there is any thing repugnant in the subject or context
:(a) “Act” shall mean the Meghalaya Cooperative Societies Act, Assam Act 1 of 1950 as
adapted by Meghalaya)
(b) words and expressions used in these rules shall be the meanings respective assigned to
them in the Act.
(c) “Section” Means a section of the Act.
(d) “Schedule” means the Schedule of forms appended to these rules:
(e) “society” means a registered Cooperative society registered or deemed to have been
registered under the Act and includes a society formed after amalgamation of such
two or more societies or by division of such an existing Society: a registered
Cooperative society may also be called a “Cooperative”.
(f) “director” Means a member of an administrative council managing Committee or any
managing body of a society as the case may vested with the powers of its
management.
(g) “borrowed Capital” means the total of loans deposits and other borrowings of a
cooperative society;
(h) “owned Capital” means the total of paid up share capital and accumulated reserve and
other funds created out of profits of a Cooperative society;
(i) “working Capital” means the total capital of Cooperative society consisting of
borrowed capital and owned capital.
CHAPTER II
3. Restriction on acquisition of share in society – Where the liability of members is
limited by share, no member other than a registered shall:(a) Hold more than portion of the share Capital of the society, subject to a maximum of
one-forth, as may be prescribed by the bye-laws of the society, or.

<!-- page 5 -->

(b) Have or claim any interest in the share of the society exceeding five thousand rupees,
provided that if the society is a distribution of an article or any special type of society,
a member may have or claim and interest in the shares of the society not exceeding
Rs. 25,000. In such cases. The registrar will decide whether the maximum limit of
share allowed to an individual member should be Rs. 25,000 or less and his decision
shall be final.
4. Change of liability :- (!) when a registered society resolves to change its from of
liability, it shall convene a special meeting of the General Assembly for the purpose
and shall adopted proposals for such amendment of its bye - laws as may be
consequential and necessary for the safe conduc t of its business and submit an
application in the manner as provided in the rule for registration of such amendments.
(2) at least clear fifteen days written notice of such meeting with the special agenda shall
be given to its members together with a copy of the proposed resolution with regard to the
change of liability.
(30 a copy of such resolution shall be sent to the Registrar within fifteen days of its
adoption.
(4) the notice required under sub-section (I)(i) of Section 9 of the Act shall be issued
under a Certificate of posting ; provided that this shall not be necessary in the case of a
primary agricultural credit Society.
5. Application for registration – (I) Every application for the registration of a Society
under sub-section (i) of section 10 shall be in the form set forth in the schedule appended to
these rules and shall be submitted in triplicate to the Registrar and each copy of the form for
application for registration shall be signed by the promoters.
Registrar may consult the Deputy Commissioner or the Sub-divisional Officer or the
Political Officer concerned whenever he considers necessary.
(2) Where a Co-operative Society is an applicant, the application shall be signed by an
office -bearer of such Society duly authorised by a resolution to sign the application for
registration and the bye-laws on its behalf.
(3) If the society intends to be a members of central society, another copy of the bye-laws
signed by the president of the inaugural general meeting, in addition to the copy of the
bye-laws which are required under sub-section (3) of section 10 of the Act, shall be
forwarded therewith
6. Conditions of registration of a society and refusal to register – (1) On receipt of
the application for registration, the registrar shall examine the application for registration and
the bye-laws in order to satisfy himself(a) that the application and the Bye -laws are in conformity with the Act and the rules,
(b) that the bye -Laws are suitable for carrying out the objects of the Society and ensure
safe conduct of its business, and
(c) that the proposed society has reasonable chances of success having regard to local
conditions, and may call for further information or make such enquiry as he may
deem necessary.
(2) (a) If the registrar is satisfied on all the points mentioned in clauses (a), (b) and (c) of
sub rule (!) he may register the society and its Bye Laws.

<!-- page 6 -->

(b) such registration shall be entered in a General register kept for the purpose in the
form found suitable and the entry of such registration shall be attested by the seal and
signature of the Registrar.
(3) when a society is registered, the Registrar shall grant a certificate of registration in the
form set forth in the schedule.
(4) The certificate of registration together with a copy of the bye-Laws as approved by the
Registrar duly stamped with his official seal be sent to the applicants,. Of the three
remaining copies of the registered Bye laws, one shall be retained in the office of the
registrar, one sent to the Assistant Registrar and the third to the Inspector concerned with
a copy of the certificate of registration.
(5) if the Society intends to be member of any “affiliating society ‘ an extra copy shall be
authenticated and sent to the society concerned.
(6) if the registrar is to register a society or its bye -laws he shall record in writing the
reasons for his refusal and shall communicate his decision to the applicants.
7. Registration and limit of membership – (10 No person or society qualified under the
bye-Laws to be member of a Cooperative society shall be excluded from membership without
sufficient cause;
Provided that without the sanction of the Registrar(i)

No registered Society with unlimited liability shall have more that 100
members, except with the approval of the registrar which will not be given
except for special reasons to be recorded in writing.
(ii)
No registered society with unlimited liability shall have more than 50
members at the start; the member may be increased by not more than 20
members a year upto the maximum prescribed above.
(2) in case of amalgamation of societies as provided in Section 15 and change of liability
under Section 9, the restrictions and limits set forth above shall not be operative
8. Provisions in the Bye -Laws of a society – (i) Every Society shall make bye Law in
respect of the following matters namely(a) the name of the registered address of the Society and its branches, if any.
(b) The area of its operation
(c) The objects of the Society;
(d) The purpose to which its funds may be applied;
(e) Qualification required for membership and terms of admission of members;
(f) The right and liabilities of membership;
(g) The maximum number of members that may be admitted;
(h) The nature and amount of the share Capital, if any of the society and where there is a
share capital, the maximum share capital which a single members can hold;
(i) The manner in which capital may be raised by means of share and debentures,
borrowing from non-members, deposits of members or otherwise;
(j) The entrance and other fees and the fines, if any to be collected from the members;
(k) Withdrawal, removal and expulsion of members and the payment, if any, to be made
to such members;
(l) Transfer of share or interest of a member;

<!-- page 7 -->

(m) The circumstances under which withdrawal from membership shall be permitted and
the procedure to be followed in cases of with drawal, ineligibility and death of
members;
(n) The mode of appointment and removal of directors and office bearers of the Society
and the duties and powers of the managing body and other committees or bodies
which may be formed and society the composition of such bodies, their powers,
duties;
(o) The mode of summoning and conducting meeting and the right of working, fixing of
quorum for meetings
(p) Subject to the provisions of rules and, manners of making altering and abrogating
bye-laws;
(q) The ge neral conduct of the business of the society;
(r) The disposal of profits;
(s) Creation and use of reserve and other funds;
(t) The mode of custody and the investment of funds outside the business and the custody
of books, accounts and securities;
(u) The mode of keeping accounts.
(v) Settlement of disputes ;
in the case of a credit Society –
(a) the condition under which loans may be granted; fixing of the maximum and normal
credit of members and the maximum loan admissible to a member;
(b) the rate of interest on loans and the system of calculation of interest;
(c) purposes for which loans may be granted;
(d) security of repayment of loans;
(e) period of repayment and recovery of loans;
(f) extension of the period of repayment and renewal of loans; and in the case of noncredit Societies(a) the mode of conducting business;
(b) procedure to be followed in conducting business, purchasing, selling, stock
taking and other matters relating to stores, raw materials and finished
products.
9. Amendment of Bye –laws. -- by altering or rescinding them or by making a new byelaw by altering or rescinding them or by making a new bye-laws provided that(i)
(ii)

(2)

(i)
(ii)

every such amendment shall be made only by a resolution passed by a
majority of the members at a meeting of the General Assembly and at
which not less than two-thirds of the members of the Society are present;
no such resolution shall be valid unless not less than clear fifteen days
notice of such meetings has been given of the proposal to alter or rescind
the bye-laws .
The Registrar may, in special cases, registrar an amendment which is
passed by two-thirds of the members present at a meeting of the General
Assembly or at an adjourned meeting of the General Assembly at which
the number of members required by the above rule was not present, if he is
satisfied for reasons to be recorded in writingthat it is impracticable for the Society to secure the attendance of two-thirds
of the total number of members at a meeting of the General Assembly.
That the adoption of the proposal amendment, is in the interest of the
Society ; and

<!-- page 8 -->

(iii)

That such amendment is likely to meet with the approval of the general
body of members.

10.
Mode of amendment of bye -laws. – (1) In every case of amendment of byelaws, an application in the form as set forth in the schedule for registration of a new or
altered bye-law shall be submitted to the Registrar, within the time prescribed in sub-section
(2) of Section 13, signed by the members of the Managing Body. The application will show
(a) the date of meeting of the General Assembly at which the amendment was passed;
(b) the number of members on the roll of the Society on the date of issuing the notice of
the General Assembly meeting.
(c) Number of members present at the meeting; and
(d) The number of members who voted in support of t he amendment.
(2)

(3)

(4)

The application for registration of the amendment of the bye-laws shall be
accompanied by a copy of the resolution making the amendment passed at the
Meeting , the General Assembly along with fourth copy of the existing bye-laws
and a fifth copy of such amendments of bye-laws, is the Society is a member of any
affiliating Society.
When the Registrar registers an amendment of bye -laws, he shall return to the
Society, the copy of the old bye-laws duly corrected and attested by him. Of the
remaining two copies, one will be sent to the Assistant Registrar and the other to the
Inspector concerned, duly sealed and signed by the Registrar as a token of
registration.
When the Registrar refuses to register an amendment of bye-laws he shall record in
writing reasons for his refusal and communicate his decision to the Society.

11.
Amendment of bye laws at the direction of the Registrar.----(1) When the
Registrar directs any Society to amend its bye -laws in accordance with the amendment
drafted and forw arded to the Society provided in rule 10 to consider the making of such
amendment within two months or such longer period as may be specified in the order .When
the Society adopts any amendments of bye-laws, action shall be taken provided in rule 10 for
registration.
(2) In case, however, the Society proposes to file any objection, the case shall be
represented before the Registrar within fifteen days of the meeting along with a copy of the
proceedings of the meeting of the General Assembly considering the drafted amendment,
signed by the Chairman of the meeting. The Registrar after considering the objection of the
Society may.
(i) withdraw the direction for a amendment of the bye-law ; or
(ii) register the same.
(3) In case of registration copy of the amendment of the bye-law as registered shall be
forwarded to the Society together with a certificate signed by him amendment of the bye-laws
will be duly entered and certified by the Registrar in the copy of the bye-laws retained in his
office. The Assista nt Registrar and the Inspector concerned will also be supplied with a copy
signed by Registrar for being incorporated in their copies of the bye-laws
12.
Amendment of bye -laws at the suggestion of affiliating Society. (1) When it
appears to an affiliating Society that an amendment of the bye-laws of a Society which is
affiliated and indebted to it is necessary or desirable, it may direct such a Society to make
the amendment, only in respect of matters pertaining to­

<!-- page 9 -->

(a) the constitution of its administrative council and the managing body;
(b) the investment of funds.
(2) The affiliating Society in suggestion any such amendment to the affiliated
Society shall, by definite resolution of the Administrative Council or the Managing Body as
the case may be direct the Society to make the amendment within specified time.
(3) The affiliating Society shall forward to the Society concerned by registered
post,(a) a copy of the proposed amendment of the bye-laws; and
(b) copy of the resolution approving such amendment.
(4) The affiliated Society, on receipt of the direction for such amendment shall
proceed in the manner provided in rule 9.
(5) If within the period as specified affiliating Society from the date of receipt the
direction, the Society. —
(a) fails to make the amendment of its bye -laws
(b) files an objection to such an amendment the affiliating Society, after considering the
objections of the Society, if any, may__
(i) Withdraw the direction for amendment of the bye-law; or
(ii) forward the amendment together with the objections, if any, filed by the Society
and its comments thereon to the Registrar for consideration and registration.
13 Adoption of rules of procedure ._ Subject to provision in the bye-laws, the managing
body of a Society by whatever name, it is called, shall fra me rules for their own guidance
regarding._
(a)
the manner of receipt and disbursement of money ;
(b)
the made of keeping custody of books accounts, securities and funds,
and
(c)
the terms of service of salaried officers dealing with pay, leave,
discharge and dismissal.
The adoption of the rules thus framed will require the prior approval of
the Registrar and they shall remain in force until duly modified or rescinded.
14. Non-Official helpers - (a) The Government of Meghalaya may appoint not person as
a non-official adviser to help Co-operative Societies in certain specified areas. The name of
persons so a appointed who will be designated as “Honorary Organiser of Co-operative
Societies” shall be published in the Gazette of Meghalaya.
(b)Functions of the “Honorary Organiser of Co-operative Societies” will be to
(i)
(ii)

take active interest in the working of existing Co-operative;
prepare grounds by educating the people of the locality in the principle of
co-operation and
(iii)
inspect Cooperative societies within his jurisdiction, submitting his report
in the form prescribed by the Registrar for the purpose; and
(iv)
perform any other functions as may consigned to his by the Registrar from
time to time.
© the “Honorary Organiser of Cooperative Societies” shall be entitled to travelling allowance
to cover expenses of journeys undertaken at rates to be fixed for the purpose

<!-- page 10 -->

CHAPTER III.
Rights and liabilities of members of regional societies.
15. Exercise of rights of membership -(i) No member of a society shall exercise the right of
a member unless and until he has made such payments to the society in respect of
membership or acquired such interest in the society as may be prescribed in the bye-laws
subject to the following conditions.
(a) Every applicant for admission as a member must agree to pay an application fee as may
be prescribed in the bye -laws , but such fee shall not be less than eight annas or exceed two
rupees.
(b) Every applicant for admission as a member must also agree to pay such admission fee as
may be prescribed in the bye -laws. Such fee shall not be less than one rupee where the
applicant is an individual and five rupees where the applicant is a registered society.
©
Where the capital is to be raised by the issue of shares, each member must agree to subscribe
to at least one share or the minimum number of shares as prescribed in the bye-laws and has
paid the dues on account of such share or shares as required under the provision of the byelaws.
(2) No person shall be accepted as one of the applicant for the registration of a society or
admitted as a member.
(a) who does not satisfy the requirements of the act and rules or
(b) who is legally or mentally disabled or
© who is bankrupt or
(d) who is convicted of a criminal offence, involving moral turpitude.
(3) No person who has ceased within a period of four years, to be a member of any society
with unlimited liability shall be allowed to be a member of Another society with unlimited
liability without special permission of the Registrar.
(4) Any member who may at any time be found disqualified for any of the reasons in
clauses (2) and (3) shall be removed from the society.
(5) In cases of any doubt, the Registrar shall decide whether a person is or is not eligible as
an applicant for registration or liable to be removed from the society.
16. Disqualification for voting - no member of a Co-operative society shall be eligible for
appointment to enable him to vote in the affairs of another co-operative society, of which his
society is a member.
(a) If such member is any way disqualified under the provisions of the rules or any bye-laws
of the society for voting in the affair of the society of which he is a member or for being
appointed as a director or
(b) If in the case of a credit society, the member is a habitual defaulter and no extension of
time for payment of the instalments defaulted has been granted by the managing body.
© If in the case of any other type of societies, the member is in arreas in any way in payment
of his dues or is not loyal, to the society as required under the bye -laws.
Explanation- “a habitual defaulter’ referred to in clause (b) means member of a credit society
who has failed to pay three instalments already due immediately proceeding the election.

<!-- page 11 -->

17. Promoters of unlimited liability society and member of all other societies, seeking
loans to furnish information as to financial position – A full true and accurate statements
of assests including immovable property and liabilities shall also be furnished(a) by a promoter signing the application for registration of a society with unlimited
liability, together with the application for registration of the society and
(b) by a member of a limited society applying for a loan or for acceptance as a surety for
a loan.
Such statement signed by member in the form that may be prescribed by Registrar from
time to time, showing assests and liabilities at the time of admission as well as on the last
date of each co-operative year shall be preserved by the society.
Form for furnishing statement of assests and liabilities by member of
unlimited liability society.
18. The manner of recalling a loan not utilized for the purpose for which advancedwhen the managing body of a co-operative society is convinced or has reasons to believe that
a member has not utilized a loan fully or in part for the purpose for which it was advanced, it
may by a written notice direct the member.
(1) to show cause within a reasonable time specified in the notice why the loan shall not be
recalled. Where no cause is shown to the satisfaction of the society within the specified
period, the Managing body may recall the loan and if the loan is not refunded
immediately it shall apply to the registrar for an award under section 70 in order to
recover the loan.
19. Restriction on transfer of share or interest- The transfer or charge of the share or
interest of a member in the capital of a society shall be subject to maximum holding as
prescribed in rule 3 (b)
20. Nomination of transferee- (1) A member may by writing under his hand deposited with
the society during his life time or by a statement signed by the member made in any book
kept by the society nominate any person or persons to whom under section 23 his share or
interest in the society or so much thereof as may be specified in such nomination shall be
paid or transferred on his death. A nominee may become a member only, if admitted by the
managing Committee.
(2) A nomination so made may be revoked or varied by another nomination similarly made.
(3) The mane and address of every person nominated under sub-rule (1) above shall be
entered in the registrar of members.
21. Procedure for calculating the value of shares or interests of ceased members- Where
a co-operative society has to make a refund of the value of share or interest of a person who
has ceased to be a member under Section 25, the value of the share shall be deemed to be
equal to the amount actually paid up on the share, provided that where a position of the
assests is estimated to be had or doubtful in the latest audited balance sheet and is not
covered by funds created for the purpose out of profits, the Managing Committee may for

<!-- page 12 -->

the purpose of such payment, reduce the value of the share proportionately taking into
consideration, the assests which are bad or doubtful.
(2) Where a transfer of share or interest is to be made, the value of the share or interest be
deemed to be the sum actually paid by the member for the acquisition of such share or
interest.
22. Manner of determining value of land- (1) Value of land for the purpose of clauses (3)
and (5) of Section 27 shall be determined by the society in the manner detailed below (a) by reference to any recorded sale of similar land in the locality during recent periods,
or
(b) if no record of such sale is available the value of the land shall bear such proportion
to the annual rent payable to the society for the land as may be notified by the Registrar or,
© if no rent has been assessed for the land the value shall be determined by the Managing
body subject to the approval of the registrar.
2. Any dispute as to the value of such la nd shall be referred to the Registrar whose decision
thereon shall be final.
CHAPTER IV.
M a n a g e m e n t.
23. Chairman of the general Meeting - (a) (1) The Chairman or in his absence, the vice
Chairman of a society shall preside over the meetings of its General Assembly. If both the
chairman and vice Chairman are absent or are unwilling to act as Chairman the members
present and entitled or are unwilling to act as Chairman, the members present and entitled to
vote shall elect from amongst themselves to preside over the meeting, provided however,
where the bye-laws of a society provides for any outsider to preside over the meetings of the
General Assembly, such as an outsider if elected shall preside.
(ii) The Chairman of a meeting of the General Assembly shall maintain order in the meeting
and shall control and conduct proceedings in such manner as may be conducive to
expeditions and effective disposal of business. He shall decide all points of order and his
decision upon such points shall be final,
(iii0 The Chairman of the meeting of the general Assembly may direct any member to
withdraw for disorderly conduct and the member so ordered shall immediately withdraw and
unless otherwise directed by the chairman shall remain absent during the remaining period of
the meeting and shall not be entitled to vote without the permission of the chairman.
(iv) In the event of disorder, the Chairman of the meeting may suspend the meeting and
adjourn it to such a date and time as he may think fit subje ct to the provision of the bye-laws.
24. Quorom of meeting of General Assembly- (i) Unless otherwise provided in the byelaws the quorum of a meeting of the general Assembly shall be one -fifth of the total number
of members existing as such as on the date of issue of the notice of the meeting or one
hundred whichever is less.

<!-- page 13 -->

(ii) no business shall be transacted at any meeting of the General Assembly unless there is a
quorum at the time when the business of the meeting is due to commence.
(iii) If within half an hour from the time fixed for the meeting of the general Assembly a
quorum is not present, the meeting shall stand adjourned ordinarily to the same day in the
next week at the same time and place but the chairman of the meeting may, however, decide
to adjourn the meeting to a date not later than fourteen days or as may be provided in the
bye-laws of the society.
Provided thatA meeting of the General Assembly which has been called on the requisition of members
under clause © of sub-section (i) of Section 33 shall not be adjourned but dissolved.
(iv) if at any time during a meeting of the General Assembly attendance of members falls
below the quorum as prescribed above, the Chairman of the meeting on his attention being
drawn to the fact or on his own initiative may adjourn the meeting to such a date, time and
place as he may convenient and the business to be transacted at this meeting shall be
disposed of in the usual manner at the adjourned meeting even without a quorum.
25. Voting in meeting of General Assembly- (1) Except where otherwise prescribed all
matters brought before a meeting of the general Assembly shall be decided by a majority of
votes.
(2) a resolution which is put to the value at a meeting of the General Assembly shall be
decide d by show of hands unless a poll is demanded by at least ten members and agreed by
the chairman of the meeting.
(4) If a poll is decided, the vote shall be taken in such manner and at such time as the
chairman of the meeting may direct subject to any provision in the byelaws in this behalf
and the result of such poll shall be deemed to be the decision regarding the resolution.
26. Records of meetings- (i) The names of the members present in a meeting of the General
Assembly shall be entered in the proceedings of the meetings which shall be recorded in a
book kept for the purpose.
(ii) The proceedings shall be signed by the chairman of the meeting after being read to and
confirmed by the members present at that meeting or at the next meeting.
(iii) The chairman in his discretion may admit any person not being a member, to any
meeting of the general Assembly for the purpose of giving expert advice, Such person shall
not be entitled to vote.
Proceedings of all meetings of General Assembly shall be submitted to the Registrar or to the
person/persons in the manner as may be prescribed by him from time to time for approval
and until such approval is obtained proceedings of such meetings shall not be valid.
A list showing the total number of members on the date of holding meetings and
number of members present thereat with their names shall be attached to all proceedings
when submitted to the registrar or the person authorised by him in his behalf for obtaining
approval.

<!-- page 14 -->

27. Election and retirement of directors in a primary society, other than a nonagricultural credit society- The directors of a Primary society other than a non-agricultural
Credit Society shall retire annually from office but shall be eligible for re-election.
Provided that except with the previous permission of the Registrar which should only be
given in exceptional cases, no member shall hold office for more than four years in
succession or having already held office for four years be re-elected within a shorter interval
than two years form the date on which he ceased to be a director.
(ii) The vacancies caused by the retirement of the directors shall be filled up by election at
the annual meeting of the General meeting Assembly at which they retire.
28. Election and retirement of directors in non-agricultural Credit Societies (i) At the
first annual meeting of the General Assembly of a non-Agricultural Credit Society held after
the commencement of these Rules, the entire body of directors shall retire but shall be
eligible for re-election:
Provided that no director who has held office for more than four years in succession
shall be eligible for re-election for two years from the date of his retirement without the
previous permission of the Registrar.
(ii)
In subsequent years one third of the directors electors elected by the members
shall retire from office at the next annual meeting of the General Assembly and
shall be eligible for re-election for one year from the date of retirement
(iii)
The vacancies caused by the retirement of directors under sub-rule (i) or sub-rule
(ii) shall be filled up by election at the annual meeting of the General Assembly at
which they retire.
(iv)
The directors who are to retire in accordance with sub-rule (ii) at the second and
the third annual meeting of the General Assembly shall be determined by lot in a
meeting of the administrative council or the Managing Body as the case may be
within three months from the date of its first constitution after the commencement
of these rules. In subsequent annual meeting of the General Assembly, the
directors who have been longest in office shall retire.
Explanation:- For the purpose of this sub-rule the term of office of any member elected
to fill a casual vacancy in the administrative council or managing body shall be deemed to
include the period of membership of his predecessors.
29. Appointment of directors by the Registrar:- (i) In order to safeguard and represent
appropriate interest in a Co-operative Society, the Registrar shall have powers to appoint all
or fraction of the number of members provided in the bye-laws or appoint additional
members to the administrative council or the Managing Body not exceeding one-half of the
number of the elected directors.
(ii)
The members so appointed shall hold office till the next election of directors
appointed under this rule may or may not be members of the society.
(iii)
If any vacancy occurs in the office of such an appointed director, the vacancy
shall be filled up by appointment.
30. Qualification of members of Administrative Council and Manag ing Committee:Subject to the provision of the rules, every members of a society above the age of 21 years
shall be eligible for election or for appointment as member of the administrative council and
the Managing Body

<!-- page 15 -->

31. Disqualification for membership of Administrative Council and Managing
Body: - A member shall not be eligible for being chosen, or for being appointed, as a member
of the administrative council and the affiliated if such member(a)
Is adjudged by a competent Court to be insolvent or of unsound mind.
(b)
Has been punished with imprisonment for an office involving moral turpitude;
(c)
Is concerned or participates in the profits of any contract with the society;
(d)
In s credit society has failed to pay in three consecutive years immedia tely
preceding the election at least an mount equivalent to one year’s installment fixed for the
repayment of the loan.
32. Cessation of membership of Administrative Council and Managing Body:- A
director shall cease to hold office,(a) If he becomes subject to any disqualification mentioned in rule 321, or
(b) If he resigns his office by notice in writing to the administrative council or the
managing body concerned ; or
(c) If, without the consent of the administrative council or the managing body, he is
absent from meeting for more than three consecutive meeting; or
(d) If the society of which he is a representative is dissolved or disaffiliated.
33. Removal, expulsion, etc., of the Secretary, Treasurer, Directors and other officebearers:-(i) The Secretary or Treasurer of a society or any other office-bearer may be
removed from office by a resolution of a meeting of the General Assembly specially
convened for the purpose.
(2) Unless otherwise provided in the bye-laws in the terms of appointment, any office of
a society appointed by the administrative council or the managing body may be removed
from his office by the said council or body.
34. At least fifteens days’ notice of all meetings of the administrative council and at least
four days’ notice all meetings of the managing body shall be given to each member
specifying the date, hour and place of the meeting with a statement of business to be
transacted threat:
Provided that(i)
No business transacted at meeting of the administrative council or the managing
body so convened shall be deemed invalid on account of non-receipt of the notice
by a member in due time; and
(ii)
Provided that any urgent business though not included in the agenda
accompanying the notice, may be brought up and considered with the consent of
all the members present at the meeting.
35.
Powers of the Administrative Council and Managing Body:- The administrative
council or the managing body shall exercise all or nay of the following powers as may be
provide in the bye-laws(i)
To admit new members and to suspend, fine, remove or expel existing member;
(ii)
To raise funds;
(iii)
To invest funds;
(iv)
To appoint salaried or non-salaried officers for proper conduct of the business, on
such terms as to remuneration, security, etc., and with such powers ands
authorities including the powers to enter contracts on behalf of the society as they
may deem fit and to fine their duties;
(v)
To dismiss, suspend or punish each officers mentioned in sub-clause (iv)

<!-- page 16 -->

(vi)
(vii)
(viii)
(ix)

To institute, defend or compromise legal proceedings;
To dispose of applications for loan and to determine the security to be taken;
To appoint sub-committees as may be deemed necessary from time to time; and
To delegate, with or without conditions, or any of the power exercisable by the
administrative council or the managing body to any office-bearer or to any
committee formed.

36. Duties of the Administrative Council and the Managing Body:-The administrative
council or the managing body shall observe in all their transactions the provisions of the Act,
Rules, bye-laws and directions of the Registrar sand shall cause to performed the following
duties namely:(1) To provide for the management of the affairs of the society;
(2) To receive and disburse money;
(3) To maintain true account of money received and expended and of assets and
liabilities;
(4) To prepare for submission to the annual meeting of the general assembly(a) An annual report on the working of the society;
(b) An annual statement of accounts which shall include:(i)
Cash account;
(ii)
Balance sheet;
(iii)
Trading account (if any);
(iv)
Profit and loss account; and
(v)
Profit and loss appropriation account,
(5) To prepare the statement of account to requires for audit and to place them before the
auditors;
(6) To prepare and submit all statements and returns required by the Registrar in such
forma as he may direct;
(7) To enter account of the society regularly in proper registers:
(8) To maintain a register of members up-to-date;
(9) To facilitate the inspection of books and records by the inspecting officers;
(10)
To convene meetings of the general assemble on requisition;
(11)
To convene the annual meeting of General Assembly in due time;
(12)
To watch that the loans are applied for the purposes they are advanced and that
they are repaid punctually.
(13)
To examine and take prompt action in cases of all arrears and defaults in
respect of repayment of loan;
(14)
To examine the stack register and verify the actual stock;
(15)
To supervise and examine the work of the sub-committees and the officebearers; and
(16)
To perform such other duties as may be entrusted by the General Assembly.
(17) (a)
No society, without pr ior approval of the Registrar, shall take into
consideration any balance sheet at its annual general meeting or make any distribution of
its profits by way of dividend or bonus or otherwise among its office -bearers, employees
and members, unless and until the balance sheet ( for the period during which such profits
have accrued) shall have been certified to be a true and correct statement of the financial
position of the society by the Registrar or the person authorized by him in that behalf.
(b) All societies with limited liabilities shall obtain the Registrar’s approval to their
proposal of the distribution of the profits whether to their office-bearers or employees
or members before considering it at the annual general meeting.

<!-- page 17 -->

37. Deputation of government servant to manage the affairs of a Cooperative society: (1)
A Government servant when deputed to the service of a Cooperative Society by the
Government of Meghalaya under Section 35 shall be called the executive Officer of the
society.
(2) subject to any condition to the contrary that the government of Meghalaya may in any
particular case think fit to impose he shall be under the general control of the administrative
council or the managing body of the Society as the case may be and shall exercise the
following powers in the conduct of the business of the society, namely ;(a) have full control over the staff of the society with power to punish, suspend or dismiss any
member therof; provided that the poser of dismissal shall be exercised with the previous
concurrence of the administrative council or the managing body as the case may be;
(b) to institute, defend or compromise legal proceedings
38. Duties of executive officer- Unless otherwise directed by the administrative council or
the managing body as the case may be the executive shall perform the following duties
namely :(i) receive all money on behalf of the society and issue receipts;
(i) Pay all costs of management and working expenses out of the funds of the society, e.g.
salaries of the staff travelling and other contingent expenses, necessary for the work of the
Society;
(iii) deposits all money received on behalf of the society as well as securities and other effects
as prescribes under rule 55;
(iv) maintain regular and accurate accounts;
(v) maintain records in prescribed form;
(vi) convene meeting of the administrative council or the managing body as may be necessary
from time to time;
(vii) Submit such statement as required by the administrative council or the managing body
39 Procedure in case of different of opinion – In the event of any different of opinion
between the Executive Officer and the Administrative council or the managing body of the
Society, with regard to any matter concerning its management not expressly covered by the
Act, the rules, the Bye-laws and conditions laid down by the government of Meghalaya at the
time of appointment, the Executive Officer may refer the matter to the Registrar whose
decision shall be final.
40. Executive Officer:- cost of his service, withdrawal, e tc.. The Executive officer shall be
indemnified out of the funds of the Co-operative Society for all cost, charges, travelling and
other expenses incurred by him in the discharge of his duties in conducting its business and
no suit or legal proceeding whatever shall lie against him in respect of anything done in good
faith or intended to be done in accordance with the powers conferred on him.
(2) At any time the government of Meghalaya may after giving one month’s notice withdraw
the service of the Government servant deputed to manage the affairs of the society.
(3) The society at any time by a resolution, in the meeting of the General Assembly apply to
the State government for withdrawing any government servant so deputed.
(4) the society shall make contribution towards the cost of the deputation of the officer as the
government of Meghalaya may direct.

<!-- page 18 -->

41. suspension or supersession of an Administrative Council a Managing or any other
Body :- (1) In case where the administrative council or the managing body of a society after
receipt of a notice fails to carry out the direction of the Registrar issue under Section 36 or
forwards its reasons for not so doing, the Registrar after due consideration of the reasons
given, may be an order in writing(i) withdraw or modify the order; or
(ii) dissolve the administrative Council or the managing body.
(2) (i) where as an emergent measure the Registrar of considers it necessary to suspend
forthwith the administrative Council, managing or other bodies, and appoint a pe rson or
persons, to be in full control of the suspended body until a new body has been elected or
action has been taken in accordance with Section 37, the registrar shall fix the date and time
by which the person or persons appointed shall take over charge of the society from the
suspended body and prescribe the condition under which they will work.
(ii) Rule 40 shall be applicable in case of person or persons so appointed.
42. Appointment of person or persons to manage the affairs of a Society: -(1) When
the Registrar orders the administrative council managing or any other body as the case any be
of a society to be dissolved and appoints a persons under Section 37 he shall fix(i) The date and time by which charge of the society shall be taken over from the
dissolved body;
(ii) The condition under which work shall be carried on;
(iii)
The remuneration, if any, to be paid to manage the affairs of the society;
(iv)
The security if any to be furnished by those appointed; and
(v)
The date by which a new administrative council, managing or other body, as the
case may be, is to be elected.
(2) Unless otherwise directed by the Registrar, the remuneration of any person or persons
appointed under Section 37 shall be defrayed out of the funds of the society.
CHAPTER V
Duties of Registered society.
43. Document to be kept open to inspection. – In addition to the provisions of Section 41,
every society shall keep documents and allow inspection by any member of the society –
(i) the register of members,
(ii) the register of the members of the administrative council if any and of the
Managing body, and
(iii) other books and records of the society.
44. Rights of members of Co-operative Society with unlimited liability to see accounts –
The members of Cooperative Societies with unlimited liability shall have a right to see the
accounts of all the borrowers of such societies in the offices of the Societies Concerned.
45. Fees for Inspection of documents, bye -laws, etc.- Members of Cooperative Societies on
a written application stating the purpose may on payment of a fee of two rupees for each
document on each occasion of inspection, and with the permission of Registrar inspect any
public documents exclusive of documents privileged under Sections 123, 124, 129 and 131 of
the India n Evidence Act, I of 1872, such as –

<!-- page 19 -->

(i)
(ii)
(iii)
(iv)
(v)
(vi)
(vii)

general Register,
certificate of Registration,
bye-laws,
amendments of bye -laws
orders for its cancellation
the annual cash account, balance sheet and revenue accounts, and
Audit memorandum.

46. Fees for certified copies of documents.- Certified copies of any document, which any
person has right under the foregoing sub-rule to inspect, shall be supplied on payment of two
rupees for a certificate of registration of a Cooperative Society and in case of other
documents a calculated at the rate of four annas for each hundred words of the copy taken,
subject to a minimum of rupees two.
47. (1) The maximum amount which a Society may receive as deposit and borrow from its
members and non-members shall be determined at an Annual General Meeting of the Society
shall borrow beyond the maximum amount so determined and in force for the time being.
Provided that Registrar or any person authorized by him may at any time, reduce the limit
fixed by the General Assembly.
(2) Save as is provided in rule 48 no society shall incur liabilities from persons who are not
members in excess of the maximum limit fixed from time to time in a meeting of the General
Assembly subject to the approval of the Registrar.
48. Restriction of borrowings of society with unlimited liability.- A Cooperative Society
with unlimited liability which is a member of an affiliating financing bank shall not take
loans from any non-member without the sanction of the affiliating society and where the
Society is not a member of such affiliating society, without the previous sanction of the
Registrar.
49. Restriction on borrowings of limited liability Society.- No society with limited liability
shall, by accepting deposits, or loans or in any other way incur liabilities exceeding fifteen
times the sum of the paid up share capital and the reserve fund for the time being separately
invested outside the business of the society.
Provided that –
(a)
The Apex Bank or a Central Cooperative Bank for the purpose of financing its
affiliated societies the Apex Bank may incur liabilities by floating debentures, accepting
deposits or in any other way to the extent of twenty times the value of paid up share capital
and the reserve fund for the time being separately invested, unless relaxation is made by
Registrar by an order in writing.
(b)
An agricultural society or a bank financing such societies may with the
permission of the Registrar or any person authorized on his behalf and under such conditions
as he may impose, incur liabilities for the purpose of advancing seasonal loans to members
for production of crops and for financing the disposal of produce, repayable within a period
of twelve months, irrespective of the amount of its paid up share capital or reserve fund
separately invented outside the business.

<!-- page 20 -->

50. Restrictions on borrowings by Societies
(1) Fixed deposits
(1) Cooperative Societies may accept fixed deposits from members and
non-members, subject of such rules and restrictions and for such periods as the Registrar may
deem fir to impose, provided always that efficient management is ensured and that adequate
fluid resources are maintained according to the rules prescribed.
(2) All Cooperatives Societies with, limited liability other than agricultural credit
(2) Saving Bank deposits
societies and other types of societies in rural areas which make
adequate provision for fluid resources as provided for in the rules, may accept savings bank
deposits both from members and non-members, subject to rules for deposits framed by the
Society and approved by the Registrar.
(3) No Cooperative Society undertake current deposit accounts business without the
(3) Current Deposits.
sanction of the Registrar and such sanction shall not be given
by the Registrar unless he is satisfied about the stability of the concern and of its provisions
for adequate fluid resources as prescribed under the rules.
51. Provision for fluid resources or liquid covers .- Any Cooperative Society, accepting
loans and deposits as provided in the foregoing rules shall keep the maximum fluid resources
against loans and deposits held by it according to the following scale:(i)

(ii)
(iii)
(iv)

25 percent of the amount held in fixed deposits and loans due for
repayment within the ensuing six months (less the amounts for which
written notice of renewal has been received);
33 percent of the amount held in savings deposits;
60 percent of the amount held in current deposit; and
the entire amount of undrawn cash credits granted.

Explanation.- “Fluid Resources” means any assets which can be converted into ready cash at
once and which are maintained in one or more of the following forms :(a) Cash in hand, or in banks or with bankers approved by the Registrar;
(b) Government securities, including post office cash certificates;
© Deposits in Post Office Savings Banks;
(c) Other investment of a liquid nature in outside concerns approved by the Registrar;
and
(d) the undrawn portion of assured cash credit with –
(i)
(ii)

any joint-stock bank or private banker approved by the Registrar; or
the Apex Bank or any other Coope rative Bank approved by the
Registrar.

52. Registrar’s power to permit a decrease in the proportion of fluid resources, etc.Under special circumstances, the Registrar may, by general or special order, empower any
particular society or any class of socie ties to reduce the proportions of the fluid resources as
mentioned in rule 51.
53. (1) Restriction on issue of loans. – Every credit society of unlimited liability shall
from time to time, fix in the annual general meeting of the
(1) Fixation of maximum
General Assembly the maximum liability a member may
liability of a member of
incur. The maximum limit so fixed shall be subject to the

<!-- page 21 -->

credit society with un sanction of the Registrar or some person
limited liability.
Authorized by him who may if he thinks fit, reduce it or impose
such conditions as he may think necessary. No loan shall be granted to an individual member
of a society which shall bring his total debts to the society exceeding the maximum amount
so fixed.

(2) In any Cooperative S ociety in which the liability of the members is
Limited by shares, no loan shall be granted to a member exceeding
(2) Fixation of maxi- ten times the amount of the share capital paid by him but not
mum liability of a
exceeding the limit provided in the bye-laws or determined by the
member of limited
annual general meeting of the General Assembly. liability society.
(a) a society may grant loans to its members upto twenty times the amount of share
capital paid up by a member, in case of such loans bring issued on mortgage or valuable
security, as provided in sub-section (2) (c) of Section 44 of the Act;
(b) the Apex Bank or any other financing bank may grant loans to any affiliated
Cooperative land mortgage bank upto twenty times the amount of share capital paid up by the
land mortgage bank;
© the Apex Bank may advance loans to an affiliated society engaged in the purchase of
production and disposal of goods of its members in excess of ten times the share capital paid
up by such society;
(c) an agricultural society may grant loans to its members repayable within a period of
twelve months for facilitating the production or disposal of produce, irrespective of the
amount of the share capital paid up by such member with the previous permission of the
Registrar and under such conditions as he may impose.
54. Maximum and normal credit to members .- A Cooperative Society shall determine
and fix the maximum of normal credit of its members in a manner as it thinks fit; provided
that –
(a)

(b)

in a Primary non-agricultural credit society, the maximum or normal credit
of a member shall be determined by taking into consideration his assets,
liabilities and his repaying capacity;
in a Primary agricultural credit society the maximum or normal credit
shall not exceed one-half of the total value of the agricultural lands of a
member which is actually under his cultivation during the period of
assessing normal credit or two thirds of the total estimated net income
from such lands during the period of the repayment of the loan whichever
is less.
CHAPTER – VI
Property and Funds of Registered Society.

55. Investment of Fund.- In addition to the provision made in Section 51, a Cooperative
Society may invest or deposit its funds –
(i)
with the Meghalaya Cooperative Apex Bank Limited, or
(ii)
in the purchase or leasing of land buildings; or

<!-- page 22 -->

(iii)

in the construction of buildings, provided that the purchase of such land or
the construction of such building, is likely to be advantageous to the
society in its working ;or
(iv)
in any other manner permitted by the Registrar.
56. Reserve Fund and its object. - (i) Every society shall form and maintain a reserve
fund which shall belong to the society as a whole and shall be built up by carrying in each
year not less than twenty five percent of its net profits. The fund shall be indivisible and no
member shall have any claim or share in it
(ii) With the previous sanction of the Registrar, a Cooperative Society with shares and with
limited liability may meet the loss of any year partly or wholly from the reserve fund
provided that no dividend or share, bonus, patronage dividend or rebate is paid during the
year out of the profit. No less than fifty percent of the reserve shall be separately invested
every year not to be utilized in the ordinary working of the Society subject to Rule 58.
57.
Creation of reserve fund in a Society. – (i) In every registered Society with
unlimited liability and without shares not less than three -fourth of the net profits in any year
shall be carried to the reserve fund
(ii). In every Cooperative Society with shares and with unlimited liability not less than
one-half of the net profits in any year shall be carried to the reserve fund until that fund sis
equal to one-half of the total borrowed capital ; thereafter not less than one-third of the net
profits in any year until the reserve fund equals the amount of borrowed capital and thereafter
not less than one -fourth of the net profits in any year shall be carried to the reserve fund.
Provided that if by any increase in the borrowed capital the pr oportion of the
reserve fund to the borrowed capital is reduced in any year, the share of the net profits to be
credited to the reserve fund shall be raised to the extend required until the proportion is
restored.
58. Use of reserve fund in the business of a society.- A Cooperative Society may,
subject to the approval of the Registrar and to such conditions as he may impose, use in its
business –
(i)
upto one-third of its reserve fund when the owned capital is less than the
borrowed capital ;
(ii)
upto two thirds of its reserve fund when the owned capital is equal to or
exceeds the borrowed capital ; and
(iii)
the entire reserve fund when there is no borrowed capital :
Provided that a society not being a credit society may, with the special sanction of the
Registrar utilize the whole of its reserve fund in its business.
59. Contribution to Charitable purposes. - (1) After the proportion required by subsection (1) of rule 56 above has been carried to the reserve fund from the profits of the year
every Cooperative Society –
shall, in the manner prescribed, contribute an amount not exceeding 6 ¼ percent
of the year’s net profits for Cooperative education and for
Co -operative Devesuch other purposes, as prescribed herein, to be credited to
lopment Fund.
a fund to be called “ The Cooperative Development Fund”
(hereinafter referred to as the Fund).

<!-- page 23 -->

Provided that if the net profit of any year of a society do not exceed Rs.200, the society
shall not be required to contribute anything towards Cooperative Development Fund for that
year.
(2) (i) The fund shall be administered by a Committee appointed by the State Government
composed of –
(a) the Registrar (Ex-officio) ;
(b) the Deputy Registrar of Cooperative Societies (Ex-officio) ;
© an Economist ;
(d) a representative of rural credit societies ;
(e) a representative of trading and consumer societies, and
(f) a representative of other types of Societies ;
(g) one member of the State Legislative Assembly ;
One or two other members connected with the Cooperative Movement likely to be helpful
may be co-opted if necessary.
(ii). The Registrar shall be the Chairman with the Deputy Registrar of Cooperative Societies
as the Secretary and the Treasurer of the Committee. The Registrar shall frame rules for the
detailed procedure of working and disposal of the Fund.
(3). Every Cooperative Society shall, at the close of each Cooperative year after
consideration of the audited balance sheet in the General Assembly, make such contribution
to the fund as may be approved by the General Assembly.
(4). All sums so contributed shall forthwith be sent by the respective societies to the Apex
Bank or to such other bank as the Registrar may direct.
(5). The fund may be utilized for any one of the following purposes, namely –
(a)
the education of members of Cooperative Societies in co-operative principles
and practice ; or
(b)
the development of new types of Co-operative Societies ; or
©
the improvement of Cooperative Societies in general.
60. Charitable purposes. - A Cooperative Society may build up a fund and contribute not
more than 6 ¼ percent of net profits for any charitable purpose including relief of the poor,
education, medical relief and the advancement of any other object of general public utility.
Purposes relating exclusively to religious teaching or worship are, however, excluded. Any
contribution out of the fund shall be made with the approval of the Registrar.
61. Distribution of net profits .- After making the allocation to the reserve fund as prescribed
in Rules 56 and 59, the remaining “ net profits “ may be distributed according to the
provision in the bye-laws of the society subject to –
(a)

No Cooperative Society shall pay its share holders in any year a dividend
exceeding twelve and a half percent on the paid-up
(1) Payment of dividend on
shares unless otherwise permitted by the Registrar
shares.
In writing :

<!-- page 24 -->

Provided that is any Cooperative Society other than a credit society is enable to pay a
dividend of four percent of any year, it may make good the deficit by paying the difference
out of profits in future years at any time not later than five years immediately succeeding the
year of such deficit :(b)

no dividend shall be paid by any Cooperative Society with shares and
unlimited liability without the previous sanction of the Registrar and that the
rate of such dividend shall not exceed 6 ¼ percent per annum on the paid-up
shares ;
(c)
no Cooperative Society shall declare a dividend at a rate exceeding that
recommended by its administrative Council, or Managing Body.
a Society may credit in any year a sum out of the dividend allotted under
(d)
(a) above not exceeding 3 percent on the
Dividend Equalization Fund.
paid-up share capital to a fund called the
“Dividend Equalization Fund” till the total
amount in such fund accumulates to 9 percent of the paid-up share capital :
Provided that except for the purpose of paying a dividend no withdrawals from
such fund shall be made without the previous written sanction of the Registrar.
62. Patronage dividend or rebate. – A Cooperative Society may set apart a certain
percent of its net profits as provided in the bye -laws for the payment of patronage dividend or
rebate to its members in proportion to the money value of the business transacted by them
during the year with the society as buyers, sellers, wage earning producers, or otherwise, if
such payment is recommended by the Managing Body and approved by the General
Assembly.
(b). In case advance patronage dividend is allowed to be paid under Section 54
(2), the total amount of such patronage dividend shall not exceed the limit as provided in the
bye-laws.
63. Payment of bonus or remuneration. – A Cooperative Society may set apart not
more than 30 percent of its net profits as provided in the bye -laws for the payment of bonus
or remuneration to its members, office bearers, salaried, officers, employees or other helpers
if such payment is recommended by the Managing Body and approved by the General
Assembly.
64. Provision for bad and doubtful debts. – All Cooperative Soc ieties other than the
Societies with unlimited liability and without shares, shall be required to make adequate
provisions for bad and doubtful assets if any such asset is declared bad or doubtful as
prescribed in sub-section 2 (b) of section 54.
Unless such provision has been made or any exemption has been granted, by the
Registrar on the recommendation of the Audit Officer, no society shall pay any dividend,
bonus, remuneration, patronage dividend or rebate.
65. Provision for building fund.- A Cooperative Society may create a separate fund
out of profits for the purpose of constructing buildings for conducting its business and such a
fund shall be called a “ Building Fund “. The amount of such fund, when not used for the

<!-- page 25 -->

purpose for which it has been created may be utilized in the business or be invested or
deposited with any Bank approved by the Registrar.
66. Payment of interest on share capital. – Fixed interest on share capital may be
paid to members as provided in the bye -laws but such interest shall be taken into account
before arriving at net profits.
CHAPTER VII.
AUDIT.
67. Explanation of bad or doubtful asset.- Any asset in a Society declared as bad or
doubtful by an audit officer in his report as provided in sub-section (2) (b) of Section 54 shall
be interpreted in the following manner(a) If a member fails for three consecutive years without reasonable acceptable to the
Managing Committee to pay at least 25 percent of each of the installments of principal and
interests fixed for repayment of a loan at the time of its issue, then notwithstanding that on an
examination of his assests and the assests of his sureties, if any, the debt appears to be
covered by the value of such assests, the debt may be considered as doubtful.
(b) (i) when the total amount due
by a member to a Cooperative Society by way of principal and interest exceeds the total of
his assests and the available assests of his sureties, if any, and the amount due by way of
arrear interest exceeds three years demand, suc h excess of his total dues including interest
over the total assests shall be considered as bad debt. Besides, where a member has
inadequate repaying capacity and ha and his sureties have no available assests, the debt shall
be termed as bad debt.
(ii) A debt considered as doubtful if not recovered after action has been taken under
Chapter X or section 70 of the Act to recover it or the recovery of which has become barred
by limitation shall be considered as a bad debt.
68. Writing off of bad debts- (i) Best proceedings to take action to write off any assest
considered bad, all possible steps shall be taken by the Managing Committee including
amicable persuasion, action under Chapter X or Section 70 of the Act.
(2) Any debt considered bad shall if so approved by the Registrar be written off by the
annual meeting of the General Assembly, in the following order against (i) the bad debt fund or any created out of profits as provision for bad debts,
(ii) any other fund created out of prof its but not earmarked for any specific purpose.
(iii) the reserve fund constituted under Rules 56 and 59.
When the Society is affiliated to a financing Bank and is indebted to it the Registrar
shall consult the financing bank before sanctioning the writing off of any debt.
69. Date of audit of Cooperative Society- Unless the Registrar directs otherwise for any
Society or Class of Societies, the annual statutory audit as provided in Section 55, shall be
conducted and the audit report shall be submitted.
(i) in case of a primary agricultural credit society, within nine months and
(ii) in case of any order society, within six months, from the date of close of the Co-operative
year.

<!-- page 26 -->

70. Procedure of audit- (1) Unless the Registrar directs otherwise the audit of a Cooperative Society be conducted in the registered office of the Society.
(2) Previous and timely intimation shall always be given, to the society by the audit officer
before the audit is commenced. Provided that the verification or examination required under
clauses (i) (ii) and (iii) of Section 37 may be carried out by any audit officer without any
previous intimation to the society.
(3) The defects and errors detected in course of audit and which can be remedied on the spot
shall be rectified by the audit officer and he shall also convene a meeting of the Managing
body for rectification of all defects including account irregularities which can be remedied by
the Managing Committee. All other defects of a serious nature shall be remedied in the
annual meeting of the General Assembly subject to provisions under Sections 58 and 59.
(4) The officers and employees of the society shall give the audit officer all assistance
necessary for the conduct and completion of the audit and for this purpose in particular
prepare such statements and take such action with regard to the verification or examination of
its accounts as he may require.
71. (i) When the annual audit of a Cooperative Society is completed, the audit officer
wull re cord a certificate in the Cash Book in the following form ‘’ Certified that I have this day completed the audit of the --------------------------------------for
the period from----------------------------- to ----------------------------and that a copy of the
balance sheet together with the statement of accounts audited and the audit report with the
statement as required under Section 58 shall be sent within a week to the Society for record ‘’
(2) The audit certificate in the balance sheets of the audit officer shall be in the following
formI report that I have audited the Balance sheets as at--------------------------------- and the
annexed profit and loss account for the year ended-----------------------------and have obtained
all the informations and explanations I required. In my opinion the Balance Sheet and the
profits and loss account have been drawn up in conformity with the law and subject to my
separate report of even date, the balance sheet exhibits a true and correct view of the state of
the society’s affairs according to the best of my information and the explanations given to me
and as shown by the books of the society.
72. Form of Audit statements - The statement of accounts shall be prepared by the managing
body in such forms as the Registrar may prescribe or approve.
73. Audit fee- (i) For the purpose of audit of a registered society the Cooperative year shall
begin on the 1st July and end on the 30th June each year and a physical stock taking shall be
done by every appropriate society to ascertain the actual value of stock as it stands on the 30th
June.
(2) Every registered society shall be assessed audit fees at the rate and in the manner as
prescribed in sub-rules (3) and (4) of this rule and such fees shall be collected at the time of
audit for the year to which the audit relates.

<!-- page 27 -->

(3) Audit fees of a registered Society shall be assessed on the networking capital of the
society as it stood of the previous year which shall include (a) share capital (b) deposits (c)
borrowings (d) undistributed profits and all others funds of the society utilized inj the
business of the Society.
(4) Audit fees of a registered Society or a class of registered Societies shall be assessed at the
following rates :(a) Primary Credit Societies------------------------------at annas 8 per one hundred rupees
subject to a maximum of Rs.150.
(b) All other Cooperative societies -----------------------at Rs.1 per one hundred rupees to a
maximum of Rs.5,000 unless the society has regional branches in which case the
maximum shall be Rs.10,000.

(5)
The Registrar may at his discretion for reasons to be recorded in writing remit wholly
or in part the audit fees payable by any registered society under these rules.
74. (a) Collection and assessment of audit fees- (1) An auditin g officer on completion of
the audit of a registered society shall cause to be filled up the relevant columns of the ‘Return
of Audit Fees’ by the Secretary or the Manager of the Society in 6 copies in Form no.1
annexed to these rules on the spot and shall collect the total sum payable on this provisional
assessment by the society as shown against item 11 of form no.1 then and there and shall
furnish an official printed receipt ,the counterfoil receipt being kept by him. A copy of the
‘Return of Audit Fees’ shall be retained by the society.
(2) In case of default the total sum payable shall be realized under section 83 (1) of the Act.
(3) The auditing officer shall immediately after the collection of the audit fees of a registered
society deposits them in a treasury or Sub-Treasury under the “XXXL -Co-operation-I Audit
Fees”.
(4) The auditing officer, after filling up the relevant column of the remaining 5 copies of the
“Return of Audit Fees” and certifying the particulars to be correct shall forward 4 copies
thereof, together with the receipted copy of the treasury challan to his Regional Auditor.
CHAPTER VIII
INQUIRY AND INSPECTION
79.
Procedure of enquiry under section 60 and inspection under section 61-(1) Unless
the Registrar otherwise directs the enquiry regarding the affairs of a Co-operative Society
under section 60 shall, be conducted in its registered office.
(2)
Timely intimation shall be given to the society before the enquiry is held:
Provided that the verification of the cash balance and securitie s or the examination of any
particular register and registers may be carried out without any previous intimation to the
society.
(3)
The officers, employees and other members shall furnish all information
required by the inspecting officer for the completion of the enquiry and for this purpose they
shall prepare such statements and take such action as may be necessary for the verification

<!-- page 28 -->

and examination of society’s records as required by him to look into its constitution, working
and financial condition under section 60 or section 61
(4) (i)
The Registrar or any person authorized by him under sections 45, 55, 60,61
and 76 of the Act shall have power to required by summons the production at a convenient
places of any books documents or accounts relating to the affairs of society or of cash
belonging to the society by the person in possession of such books, documents or cash
(ii)
Such summons may be sent by registered post or served in the manner
prescribed by Rule 98 (2).
(iii)Any person duly summoned sub-rule (i) above to appear or to produce any
document or cash shall be liable to the same penalties as provided in Rule 105.
80.
Inspection of affiliated societies by members of the paid staff of a financing
bank– A member of the paid staff of a financing bank may be certified as competent to
inspect Co-operative Societies if he(i) is regular employee of the bank and has received training in institution or in any
other way approved by the Registrar adequate for supervising and inspecting a
society; and
(ii) possesses such qualifications as the Registrar may from time to time require.

CHAPTER IX
Settlement of disputes
81.
A. dispute referred to under section 63 shall include claims by a Cooperative Society for debts or any other demands due to it from a member or past member or
the heirs or assets of a past member or from others as provided in sub-sections (a), (b), (c)
and (d) of Section 63 whether such debts or demands be admitted or not
Provided, however, that if the question at issue between a Co-operative
society and a claimant or different claimants, is one involving complicated questions of law
and fact, the Registrar may, if he thinks fir, suspend proceedings in the matter until the
question has been tried by a regular suit instituted by one of the parties or by the society
concerned. If no such suit is instituted within three months of the Registrar’s order
suspending proceedings, the Registrar shall take action as prescribed in Section 64.
82 Disputes and appointment of arbitrators- (1) When the Registrar decided to refer a
dispute made under section 63 for disposal to a Board composed of more than one arbitrators
he shall –
(i)
Issue a notice calling on each of the parties to nominate one person as its
nominee within such time as he direct and where a party consists of more than
one person shall jointly make only one nomination.
(ii)
Shall nominate the third arbitrator who shall act as Chairman.
(2)
In case of difference of opinion within the appointed the two arbitrators,
the Chairman’s verdict will prevail
.
(3)
If a party fails to make a nomination within the appointed, the Registrar
may himself make the nomination

<!-- page 29 -->

(4)
If one of the arbitrators fails to attend or refuses to work as an arbitrator,
the remaining arbitrators shall refer the case to the Registrar who shall cancel the
appointment of the arbitrators, and may either(a) Constitute a new Board under sub-section (i) (b) of Section 64 and sub-rule (1) above;
or
(b) Appoint only one arbitrator; or
(c) Decide the case himself by making an award in the manner as provided in Rules 88
and 89.
83. Pe rson qualified to be appointed as arbitrators.- The Registrar may appoint an
arbitrator or arbitrators from(i)
Officers of the Co-operative Department;
(ii)
Officer of any other department of Government of Meghalaya
(iii)
Members officers or paid employees of Co-operative Societies
(iv)
Members of any local body;
(v)
Teachers of any educational institutions; or
(vi)
Registrar accountants
84. Payment of remuneration to arbitrators -(a) Remuneration may be paid to arbitrators in
such cases as the Registrar thinks proper.
(b)
Remuneration to the arbitrators will be fixed by the Registrar subject to a
minimum of five rupees and maximum of fifty rupees to each arbitrator in each case, payable
from the funds of the society and would be found due by the arbitrator or arbitrators or the
Chairman.
(c)
When any remuneration is to be paid to the arbitrators it shall be deposits
with the Registrar by the society concerned in such manner as he may direct before the
arbitrator is appointed
(d)
No remuneration shall be payable to an arbitrator till the dispute referred to
his is finally decided.
85. Payment of expenses of disputes referred to the Registrar- The Registrar or his
nominee and the arbitrators shall have power to order the expenses of determining the dispute
to be paid out of the funds of the society, or by such party or parties to the dispute as they
may think fir, according to a scale as laid down by the Registrar. The Registrar may fix fees
to be paid to his nominee out of the expenses so recovered.
86. Reference of a dispute:- A reference to the Registrar of any dispute under section 63
shall be in writing and shall be accompanied by(a)
Statement of the subject-matter of the dispute referred to, in the form set forth
in the schedule;
(b)
A statement of the claims in the form as set forth in the schedule;
(c)
Copy of the ledger account of the defendant in respect of money suit; and
(d)
Such other statement or records as may be required by the Registrar
87. Fee for filling a dispute:- Every application for reference of a dispute to the Registrar
under section 63 shall bear a court-fee stamp of one rupee the Registrar permits otherwise.
88. Procedure for disposal of dispute :- in such proceeding, the Registrar or his nominee or
the arbitrator appointed under sub-section (1) (b) of Section 64 shall fix the date, hour and the
place of the hearing of the dispute and issue notices to the parties concerned in form as set

<!-- page 30 -->

forth in the schedule. The arbitrator shall have power to appoint or remove guardians and
next friends
(2)The arbitrator may issue summons or notices at least fifteen days before the date fixed for
the hearing of the dispute requiring(i)
The attendance of the parties concerned and of witnesses; and
(ii)
The production of all books and documents relating to the matter in dispute ;
and
(iii)
Shall have the power to administer oaths of all parties concerned.
(3) Summons or notices may be served by(i)
Personal service through the Chairman or the Secretary or a member of the
staff of the society or any of the dispute; or
(ii) Registered post with acknowledgment due; or
(iii) Aff ixing a copy of the summons or notice at the last known place of residence or
business of the person concerned though any office bearer or employee of the
society, when he refuses to accept the notice and sign the acknowledgment or he
cannot be found.
(4) Service of summons or notice on the Chairman the Secretary or the principal executive
office by whatever designation known shall be regarded as service on that society.
(5) Where the serving office delivers or tenders a copy of the summons personally to the
person summoned or to an agent or other person on his behalf, he shall required the signature
of the person to whom the copy is so delivered or tendered to an acknowledgment of service
endorsed on the original summons.
(6) The serving office in all cases, in which the summons has been served under clauses (i)
and (iii) of sub-rule (3), cause to be endorsed on, or annexed to, the original summons, a
return, stating the time when and the manner in which the summons was served and the name
and address of the person, if any, identifying the person concerned and witnessing the
delivery or tender of the summons.
(7) The sufficiency of proof of service of summons or notice shall be decided by the authority
issuing the same
(8) In the case of absence of any part y to the suit duly summoned, the dispute may be
decided ex-part.
(9) In these proceedings neither party shall be represented by any legal practitioner.
89. Decision or Award _ (1) The Registrar of his nominee, the arbitrator deciding the dispute
shall record a brief note in English or in the vernacular of the proceedings together with a
memorandum of the statements of the parties who attend and of such witnesses as are
examined, and upon evidence so recoded, and after consideration of any documentary
evidence produced by the parties shall give a decision or make an award as the case may be
in accordance with justice, equity and good conscience; he shall record his decision or award
in writing in the form as set forth in the schedule, sign and date it and shall communicate it to
the parties concerned.
(2) If no award is made immediately, upon the conclusion of the hearing of the parties,
the Registrar and his nominee, the arbitrator shall fix the date, and [lace of delivery of the
award and shall, except for reasons to be recorded in writing, deliver the award on the date so
fixed.
(3) The award shall be communicated to the parties by(i)
Pronouncement of the award; or

<!-- page 31 -->

(ii)

Registered post to any party absent on such date.

90. Withdrawal of a reference by Registrar:- On an application by any party to an
arbitration proceeding pending before an authority other than the Registrar deciding the
dispute, the Registrar may for reasons to be recorded in writing withdraw the reference from
the authority appointed to decide the dispute and may decide the dispute himself or make
fresh appointment.
91. Execution of decision or award:- (1) in any dispute other than a claim in respect of any
sum payable to or by a Co-operative Society, the decision or the award of the Registrar or his
nominee the arbitrator shall be enforceable by any civil court having local jurisdiction in the
same manner as a decree of such court upon application, as if it were as decree of the court.
(2) When an award in a monetary dispute has been obtained against a society, it shall not be
executed except against the assets of the society, including amounts dues to the society by its
members.
(3) When an award in a monetary dispute has been obtained, it should be sent to the Registrar
of such other officer as may have powers delegated to hi m in this behalf, for reducing the
award in the for of a Co-operative Demand Certificate under 83, if the amount has not been
realized within two months from the date of the award.
(4) When the Co-operative Demand Certificate is received from the issuing office duly
signed, it will then be submitted to the head of the local administration having jurisdiction,
for the recovery of the amount as arrears of land revenue.
92 Disposal of Records (1) The original records of dispute proceedings after the decision or
award has been delivered shall be kept in such place and manners as the Registrar may direct
from time to time
(2)
Any document or record tendered by a party in any dispute may on application be
returned to the party after the disposal of appeal, if any or after the period for appeal.
93 Certified copy:- A copy of the decision or award shall, on application be given to a party
by the Registrar duly certifies on payment of such fees as the Registrar may fix, subject to a
maximum limit of four annas for each hundred words or a part thereof.
94. Procedure for conditional attachment of property:- (1) An application for a condition
order of attachment under sub-section (3) of Section 64 shall be made to the Registrar and
shall contain(a)

Evidence in support of the contention that the party is about to dispose of the whole
or any part of his property or is about to remove the whole or part of his property
from the local limit of the jurisdiction of the Registrar, and that the party has failed
to furnish additional security even on demand; and
(b) Full details of the property to be attached, its estimated value and the claim of the
society.
(2) The Registrar on receipt of an application for a conditional order of attachment may
direct the defendant, within a time to be fixed by him either to furnish security, in such sum
as may be specified in the order to produce and place at the disposal of the Registrar, when
requires the said property or its value, or such portion thereof as may be sufficient to satisfy
the decision or to appear and shoe cause why he should not furnish security.

<!-- page 32 -->

(3) Order of attachment, if any, passed by the Registrar shall be served by such person as the
Registrar may empower. The person so empowered shall follow, as far as possible, the
procedure laid down in order XXI of the First Schedule to the Code of Civil Procedure, 1908.
(4) The Registrar may also in the order direct the conditional attachment of the whole or any
portion of the said property so specified.
(5) Conditional order of attachment shall continue in force until withdrawn for cancelled by the
Registrar.
(6) Such conditional order of attachment, when passed by the Registrar shall be reduced to the
form set forth in the schedule.
CHAPTER –X
Dissolution O f Society
95. Obligatory cancellation of registration – The Registrar shall cancel; the registration of a
societies under sub-section (2) (i) and (ii) of Section 65 which –
(i)
(ii)

has not commenced working within a period of twelve months from the date
of regis tration ; and
has not carried on business during the previous eighteen months ; after giving
the societies a notice in writing in such manner as he thinks fit.

96. Remuneration of liquidators – (a) The Registrar may permit a liquidator to utilize such
percentage of the collected assets of a dissolved society, as may be determined by him for
maintenance of his office and office staff in such manner as the Registrar may determine.
97. Procedure of taking over charge and preparation of final balance sheet- The
liquidator while taking over of the dissolved society as provided in Sections 65(3) and 66(2)
shall(i)
prepare a list of the books, records, cash and other properties of the society
taken charge of;
(ii)
prepare an up-to - date list of(a)
Members,
(b)
Past members with dates of their withdrawal, and
(c)
Deceased members, with dates of their decease, name of the legal
heirs who represent their estates;
(iii)
Make a final audit of the accounts of the society;
(iv)
Draw up final balance sheet as it stands on the date of cancellation of
registration; and
(v)
Prepare a statement in the prescribed form, showing assets and liabilities
as in the final balance sheet
98. Issue of summons, notices, etc., by a liquidator.- (1) For carrying out the Purposes of
Section 66, the liquidator may issue summons to persons whose attendance is requires either
to give evidence or to produce documents. He may compel the attendance of any person to
whom summons have been issued and for that purpose issue a warrant for his arrest.
(2) The liquidator shall sent all such notices, summons or warrant for service to the
Districts, Sub divisional and Political officers concerned. He may also send such notices and
summons by registered post

<!-- page 33 -->

(3) The District, Sub divisional or Political Officers on receipt thereof shall proceed as if
such notices summoned or warrants had been issued by him and shall return them to the
liquidator with a report of service
(4) Any person duly summoned by the liquidator to appear before him or to produce any
document shall be subject to the same obligations and liable to the same penalties as in the
case of summons issued by the court under the provision of the Code of Civil Procedure,
1908.
(5) The liquidator shall keep short notes of the depositions of the Liquidator to keep
persons thus summoned to give evidence.
(6) The liquidator shall then make an order noting names of members, past members and
heirs of the deceased members of the society and the amount to be realized from each as debt
or contributions under clause © and (d) of Section 66, the cost of liquidation under cla use (e)
of the same sub-section.
(7) All orders relating to fixation of contributions by the liquidator in respect of
deficiency in assets shall be submitted to the Registrar for approval.
(8) All assets and contribution recoverable, shall be reduced to the form of the Cooperative Demand Certificate according to the provision of Section 83.
(9) The Liquidator shall prepare Co-operative Demand Certificate under Section 83 in
duplicate and forward the same to the Registrar or such officer as may have powers
delegated to him in this behalf., for signature. One copy shall be retained by the issuing
office and the other copy will be returned to the liquidator who will the submit it to the
Deputy Commissioner, Sub-divisional Officer or Political Officers having jurisdiction for
recovery of the amount as arrears of land revenue.
(10)
Each Demand Certificate submitted for signature shall be supported by a
specific order of the liquidator to that effect separately, and accompanied by a copy of the
notice as required in the Co-operative Demand Certificate, duly serve upon the certificate
debtor.
(11)
The Demand Certificate submitted for signature shall submit to the Registrar
or any other officer empowered in this behalf by the Registrar a half-yearly progress
Statement in the prescribed form and such other reports and returns as may be called for by
the Registrar from time to time.
(12) All proceedings and transactions of the liquidator in connection the with liquidation
proceedings shall be recorded in the order sheet in prescribed for.
99. Distribution of assets and priority of claims- (1) All Government dues including audit
fees and all cost, charges and expenses incurred in the winding up of the society, including
the remuneration of the liquidator shall be payable liabilities other n to all other claims
(2) After the liabilities other than owned capital as they stood on the date of winding up
are paid off, the liquidator will submit to the Registrar his proposal for the distribution of the
assts, if any, left with for employment in the following orders of priority(vi)
all loans including those from Central and Apex Bank;
(vii) deposits from non-members; and

<!-- page 34 -->

(viii) deposits from members.
(2)
After the liabilities mentioned in sub-clause (2) are paid off, the assets, if any,
left with the liquidator shall be employed in refunding share capital and divided on shares, if
any, at a rate not exceeding 6 ¼ percent per annum payable as shown in the final balance
sheet.
N.B.- (a) Payments shall always be made rateably on a pro-rate basis ,
(b) Payment of interest included in the claims of the above categories shall be
deferred until full payment of principal has been made to all creditors.

100. Termination of liquidation proceedings obligatory on the Registrar in certain
cases:- The liquidation proceedings of a society shall be closed within a period of three years
from the date from which the cancellation of registration takes effects, unless the period is
extended by the Registrar :
Provided that the Registrar shall not grant any extension for a period
exceeding one year at a time of five years in all.
Explanation:- in the case of a society which is under liquidation at the
commencement of these rules, the order for the winding up of liquidation proceedings of the
society shall be deemed to have been passed on the date on which these rules come into
operation.
101. Disposal of the records of liquidation proceedings:- After the expiry of three years
from the date of the order of the Registrar under Section 68 for the closure of the liquidation
proceedings and direction to the liquidator to deposit the records, the Registrar may order the
destruction of records.
CHAPTER –XI
Recovery of sums due and enforcement of obligations
102.
Charge and surcharge(1) When the Registrar holds an enquiry under section 71, he
shall draw up proceeding against any members, officer, employee, past or present of the
society concerned showing the charges against him and shall(i)
Supply the person concerned with a copy of the proceedings and a summary of
the evidence which prima facie appear against him;
(ii)
Call on the person concerned to furnish his explanation by a specified date;
(iii)
Allow him an opportunities to look into relevant records pf the Society if
required for furnishing and explanation of charges include in the proceedings
drawn up against him.
(iv)
Receive and record such evidence as may be adduced;
(v)
Record a decision
(2)

(a)
The Registrar passing any order in writing under sub-section (3) of Section 71
of the Act, require such member, officer or employee when found liable, to pay a sum
not exceeding, Rupees fifty with interest to the Society by way of compensation in
respect of any payment or loss or failure to restore any property
(b)
The Registrar may, by an order in writing, fix a sum not exceeding Rupees
twenty-five to meet the cost of the proceeding under sub-section (3) of Section 71 of
the Act.

103. Gross negligence:- the following matters shall be deemed to be gross negligence within
the meaning of clause (b) of sub-section (1) of Section 71­

<!-- page 35 -->

(i) Investment, custody and employment of funds contrary to the provisions of the Act,
rules or Bye-laws or any written direction of the Registrar given in accordance
therewith;
(ii) Failure to remedy audit defects and irregularities in time when directed by the
Registrar under Section 59; and
(iii)
Failure to file disputes against defaulters and to execute any decree or award
within the period of limitation.
104.

If a register Societies or an officer or member or employees or agents thereof
contravenes any of the provisions of these rules, he shall be punishable with a fine
which may extend to fifty rupees for every offence.
SCHEDULE

Form of application for the registration of a co-operative Society with Limited
/Unlimited liability under Section 11 of the Meghalaya co-operative Societies Act (Assam
Act I of 1950 as adapted by Meghalaya
[Rule 5 (1)]
To
The Registrar of Cooperative societies,
Meghalaya, Shillong
Dated ……. The ……..19
Sir,
We apply for registration of the society mentioned herein as a cooperative
society with Limited / Unlimited under Section 11 (2) of the Meghalaya cooperative societies
Act (Assam Act I of 1950 as adapted by Meghalaya)
1. The Name of the proposed Society :2. The Registered address of the Society is Village / Town
Post Office ………………Mouza / Chowkidari circle Thana.
Sub division …………………………… district………………………..
3. The liability of t he members shall be Limited / Unlimited
4. The area of operation……..
5. the object of the Society.
6. Language in which the books and accounts will be kept…..
7. Four copies of proposed bye-laws signed by resident of the
inaugural meeting are sent herewith.
8. Each member shall pay an admission fee of a… and subscribe
to at least one share of nominal value of Rs….
9. A copy of the proceeding of the inaugural mee ting of the
proposed society is enclosed herewith.

<!-- page 36 -->

10. Three copies of the application for registration with signatures
of the applicants and particulars as required, are submitted in
the prescribed form.

the
of

Number of
subscribed

Signature
applicant

share

the
of
Occupation
applicant

Residence of the
applicant and postal
address

Age of the Applicant

Father’s Husband’s
name of the applicant

Serial
No.

Name of the applicant
for registration

(2) Further we, the undersigned, hereby agree to the memorandum of Association and also
agree to conform to the condition of the Meghalaya C o-operative Societies Act (Assam Act I
of 1950 as adapted by Meghalaya) and rules that are made there under.

FORM OF CERTIFICATE OF REGISTRATION
[Rule 6 (3)]
Certificate of Registration No……. of 19…. In the Office of the Registrar of
Cooperative Societies, Assam.
Under
Meghalaya Co-operative Societies, Act, (Assam Act I of 1950 as adapted by
Meghalaya).
In the matter of the application of …….. and ……. Others for the registration of a
Cooperative Society at ……. Village…. P.O ……… P. S. ….. in the district / Sub
division…….
I do hereby certify that pursuant to section II (2) of the Meghalaya Co-operative
Societies, Act (Assam Act I of 1950 as adapted by Meghalaya), the said society has been
registered in my office as a Co-operative Society with Limited / Unlimited liability under the
title of the …… and numbered as No……. of …… 19…. Dated this the ….. day of the year
one thousand nine hundred and ….. Anno Domini
2. The Bye-Laws adapted by the said Society have also been registered.
3. The following is the area of operation of the society.

Registrar of Cooperative societies, Meghalaya

<!-- page 37 -->

FORM OF APPLICATION FOR THE REGISTRATION OF AMENDMENT OF
BYE-LAWS OA A REGISTERED SOCIETY
[Rule 10 (1)]
The Registrar of Cooperative societies, Meghalaya.
(Through the Assistant Registrar of Cooperative societies……….)
(through the Inspector of Cooperative societies ……)
date ……. The …….. 197..
Sir,
we, the undersigned, beg to enclose herewith
1. The proposed amendment in triplicate / Quadruplicate the marginally noted
of bye-Law No….
amendment of the bye -laws of the ….. at village……
P.O. ….. P.S……..
2. Recession of Bye-law
No………

Submission … in the district of ………
……………………. And to apply for registration

3. A complete amendment
of the amendment under section 13 (20 of the Meghalaya
stituting entire set of byeCoop: societies Act (Assam Act I of 1950 as adapted by laws in
supersession
Meghalaya0. The necessar y particulars about the meeting
of all previous bye-laws
of the General Assembly at which the amendment was passed
are noted below
(a) (1) Date of the meeting.
(2)
the total number of member of member of the society on the date of
issue of notice of the meeting of General Meeting.
(3)
Number of members present at the meeting.
(4)
Number and Names of members who voted in support of the
amendment.
(5)
Number and names of members who voted against the amendment.
(b) For reasons noted below the quorum required under rule 10 (i) could not be
secured.
We certify that the adaption of the amendment of the bye -laws would be in the
interest, and that such amendment has been duly approved by the General body of members
CHAIRMAN ………..
Signature of

Secretary ………….
Members of the Managing committee
(1)
(2)

<!-- page 38 -->

Certificate of registration of amendment of bye -laws
[Rule 10 (3)]

In the office of the registrar of Cooperative societies, under the Meghalaya cooperative societies Act (Assam Act I of 1950 as adapted by Meghalaya).
I do hereby certify that pursuant of the Meghalaya Cooperative Societies Act, (Assam
Act of 1950 as adapted by Meghalaya) the amendments shown in the enclosed document of
bye-laws of the ….. a Cooperative Society registered under the aforesaid Act on the …….
Day of …. 19 … under No……. in the district of …… has been duly registered. The
following is the area of operation of the society.

The bye-laws amended and registered this day are as follows:Complete amendment of previous bye-laws.

Partial amendment of bye-laws Nos…………..

Registrar of Cooperative S ocieties, Meghalaya,
Dated this….. day of ………
One thousand nine hundred and …..

<!-- page 39 -->

FORM No. 1
Return of audit fees.
[Rule 74 (a)]

1.

Name of the Society.

---------------------------------------­

2.

Address

--------------------------------------­

3.

Registration No. and Date

--------------------------------------­

4.

Assessment year of Audit Fee

--------------------------------------­

5.

Total Capital

---------------------------------------­

6.

Funds separately invested

---------------------------------------­

7.

Net working capital to the nearest hundred rupees
[see rule 36 (3)] i.e. item 5 minus item 6.

8.

Rate of audit fees per hundred of rupees
[see rule 36(4)]

----------------------------------------­

9.

Provisional assessment of audit Fee –
Payable to the nearest rupee

----------------------------------------­

10.

Deduction or addition on account of previous
Years’s over or under payment (see item 14
Of previous year’s assessment)

11.

Total amount due (item 9 and 10)

12.

Amount paid vide receipt and chalan (give ----------------------------------------Nos. and date) to be filled in by auditing officer.

13.

Final order of assessment by Regional Auditor

14.

Remarks (Regional Auditor to state amount
-------------------------------Of refund or extra payment due in next year’s audit)
Submitted to the Auditor of coop: societies.

------------------------------­

-------------------------------­

----------------------------------------­

-------------------------------­

(through the Cooperative Branch of the ……………………………….
Development Office)
Dated ……. 197

Secretary of the Society.

<!-- page 40 -->

FORM NO. 2
RULE 74 (7)]
REGISTER OF COLLECTION OF AUDIT FEES
To be maintained by the chief Auditor and Auditors, District/Subdivision by District/Subdivision, each society of the
subdivision being entered in serial order of the registration number)
Name of District/S ubdivision ………………………………..

(As in column 4)

8

(As in column 3)

7

(As in column 4)

6

Year

(As in column 3)

5

Year

(As in column 4)

4

Year
(As in column 3)

3

Year
(As in column 4)

2

Year

Office reference
No. (i.e. file No
plus page in the
file at which the
“return of audit
Fees” has been
placed)

(As in column 3)

1

Year
Amount
collected
(item 12 of
form No. 1)

(As in column 4)

Name and
registered
number of
society

(As in column 3)

Sl.
No

9

10

11

12

13

14

<!-- page 41 -->

OFFICE OF THE REGISTRAR OF REGISTRAR OF COOPERATIVE SOCIETIES,
MEGHALAYA

Notice to show cause why a decision should not be given
[Rule No. 88 (1)]
Case No………….of 197.
Notice under rule 88 (1) of the rules made Meghalaya Cooperative Societies Act (Assam
Act I of 1950) (as adapted by Meghalaya).
Notice is hereby given in the name of ………………………………………….………and
his surety …………………………………………………………………..member of the
…………………………………………………………………
2. Whereas the Committee members of the ………………………………….…………..
have applied to the Registrar, that a sum of Rs…………………………………………
(Rupees……………………………………only) on account of principal……………….
Rs…………….(Rupees…………………….only) on account of interest has been due
from you which you did not pay on the date it fell due from you did not pay the overdues
in time and that you not pay the said sum to the Society demanding the same.
3. And whereas the said society have referred the dispute to me for a decision
under rules 81 and 86 of the rules framed under section 100 of he Meghalaya Cooperative Societies Act (Assam Act I of 1950) (as adapted by Meghalaya). I do hereby
give notice that within two weeks of the receipt of this notice you should show cause by
a registered letter why a decision should be given to the society against you.
4. Take notice that in the even of the claim not being contested by a decision
shall be given ex-parte.

Give under ny hand and the seal of my office at …………............this………………..
this …………………………………day ……………………..197.

SEAL

Registrar of Cooperative Societies, Meghalaya.

<!-- page 42 -->

Memo No……………………, dated
at………………………………the…………..of…………………….197.

Copy of the notice with …………….notices to the abovementioned borrower and his
surely/sureties is forwarded herewith to ……………………………………Chairman of
the ………………………………..village…………………………………
P.O…………………..District…………………..for service to the persons concerned.

2. Notice are to be served on the persons concerned and signature (in ink) or
thumb impression* (if illiterate) is to be taken on the back notice in acknowledgement of
the notice by the persons concerned.

3. In case of the borrower or the surely refusing to accept the notice or is not
available, the notice is to be served by hanging in the doors of persons concerned and
take signatures or thumb impressions of two witnesses to that effect.

4. Notice are returnable on or before the…………and if the notices are not returned
after service within the time specified, the Chairman will be made personally liable for
any loss suffered by the society on this account.

Registrar of Co-operative Societies, Meghalaya.
To be attested duly with two witnesses.

<!-- page 43 -->

INTIMATION OF AWARD OF AWARD GIVEN TO THE JUDGEMENT DEBTOR
(Rule No. 89)
OFFICE OF THE REGISTRAR OF COOPERATIVE SOCIETIES,
MEGHALAYA

Reference Case No.

of 19
.
No……………….,dated at………
The day……… of……………19

To
……………………………….
Member of the ………………
Through the Secretary………………..…………………………………………….is
hereby informed that a dispute having been referred to the undersigned for decision by
the………………………………………………….a decree has been awarded against
him and his surety…………………………….for Rs…………………………………..on
account of principal and Rs……………………….on account of the interest on the
principal sum adjudged at the rate of……………………….per cent per annum
from…………………………..together with all cost till date of realization.
Registrar of Co-operative Societies, Meghalaya.
Memo No…………….., dated……………………………………………….
Copy to Surety ………………for information and necessary action.
Registrar of Co-operative Societies, Meghalaya.
INFORMATION OF AWARD TO THE CHAIRMAN
(Rule No. 89)
To,
The Chairman of the…………………………………………….
Village…………………………………………
P.O………………………………………..
Reference Case No………………….of 19 .
Sir,
Award passed against ………………………… and surety ……………….
Is sent herewith necessary action.
2. If the amount adjust in the award is nor released within two months, from the date of
this award, the award should be sent immediately to the ………………………… for
reducing in it to the form of a Cooperative Demand certificate under section 83 of the
Act, with request of issue of certificate in the name of the ……………… society and to
deliver to him to be recovered as an area of land revenue.
3. Notices to the borrower and surety enclosed herewith should be delivered concern
party forthwith
Yours faithfully,
Registrar of Cooperative Societies, Meghalaya

<!-- page 44 -->

FORM OF SIMPLE AWARD
(RULE No89)
OFFICE OF THE ………………………………
case No
19
district / sub division / Political Area
In the matter of
Vrs.
Members of the
Where as the committee member of the ………… has made a reference in written
complaining that member of the society , Owes Rs. ……… by way of Principal
……………………………..and Rs………………..by way of interest

Up to the……………………………….and evades payment of the same and whereas the
said …………………………………………………………………………………………
After being served with a notice to show cause why a decision in favour of the
said…………………………………………………………………………………………
Should not be given has submitted an explanation which is quite unsatisfactory and
evasive and in which.
Not submitted any explanation and the full extent of the liability as claimed by the
aforesaid Society has been denied.
Not therefore, I in accordance with Rule 88 of the Rules framed by the
Government of Meghalaya under Section 100 of the Megha laya Co-operative Societies
Act (Assam Act I of 1950) ( as adapted by Meghalaya), hereby make the following
decision against the said, viz., that he does pay to the

Rs……………………………….as principal and Rs……………………………as interest
which was due on the ………………………………and
further interest on the
principal sum adjudged at the rate of………………………………………………percent
per annum from………..together with all cost till date of realization within a period of 2
months from the date of this award failing which the dues covered by this award shall
be reduced to the form of a C-operative Demand Certificate as provided in Section 83 of
the Act to be recoverable as an arrear of land revenue under the provision of the
Meghalaya Land and Regulation (Assam Regulation I of 1886) (as adapted by
Meghalaya).
Give under my hand and seal, at……………………………………this
……………………………………………day of…………………………….19

Registrar of Co-operative Societies, Meghalaya.

<!-- page 45 -->

FORM OF MORTGAGE AWARD
(Rule No.89)
OFFICE OF THE……………………………………………..case No.
of 19
District/Subdivision/Political area.
In the matter of the
Versus
Member of the ……………………………….
Whereas the Committee members of the ……………………………
………………………………..have made a reference in writing to me complain it at
……………………………………………………….member of that Society, owes it
Rs…………………………………………….by
way
o
principal
and
Rs……………………………….by way of interest up to the…………..and evades
payment of the same and whereas the said …………………….............after being served
with a notice to show cause why a decision in favour of the
said……………………………………………………………………………….should
not be given has submitted an submitted an explanation which is quite unsatisfactory
and evasive and in which not submitted any explanation and the full extent of the liability
as claimed by the aforesaid Society has not been denied.
Now therefore, I, in accordance with Rules 89 of the Rules framed by the State
Government under Section 100 of the Meghalaya Co-operative Societies Act (Assam
Act 1 of 1950) (as adapted by Meghalaya), hereby make the following decision against
the said……………………………………………..viz.; that he
does pay to
the…………..Rs………………………………..as
principal
and
Rs……………………as interest which was due on the………………………………and
further interest of the principal and Rs…………………………….as interest which was
due on the and further interest of the principal sum
adjudged at the rate
of……………….. percent per annum from…………………………….together with all
costs till the date of realization, within a period of 2 months from the date of this
award, failing which the right, title and interest of the dependant in the n properties set
out and described in the Schedule below will be sold under a Co- operative Demand
Certificate to be sought and issued on that behalf under Section 83 of the said Act to be
recoverable as an arrear of land revenue under the provisions of the Meghalaya Land and
Revenue Regulation ( Assam regulation I of 1886) ( as adapted by Meghalaya and that if
the sale proceeds should be found insufficient to discharge the dues with subsequent
interest at the above rate till the date of realization and cost in full, the balance will be
realized by attachment and sale of other movable and immovable properties of the
judgement debtor similarly being included under a Certificate to be issued on that behalf
under the said Section of the Act.
Give under my hand and seal, at ………………this………………………………
Day of ……………………..19.
Registrar of Co-operative Societies, Meghalaya,

<!-- page 46 -->

NOTICE TO FURNISH SECURITY FOR FULFILMENT OF DECREE
{Rule No. 94 (2) }
Under sub-section (3) of Section 64 of the Meghalaya Co -operative Societies
Act (Assam Act 1 of 1950 as adapted by Meghalaya).

To…………………………………….member of the…………………………..
WHEREAS the Committee members of the …………………………………..a
dispute to me that a sum of Rs…………………………..on account of principal/ or
……….................and Rs………on account of interest thereon up to……………..has
been due from you which you did not pay in spite of demands and that with intent to
defeat or delay the execution of any decision that may be passed against you theron, you
are about to dispose or remove your property or any part of the same, you are hereby
directed on or before the……………………. Day of……………….197, either to furnish
security for the sum of Rs……………..(Rupees………………only) to produce and place
at the disposal of this Court when required, the said property………………….or the
value thereof. Or such portion of the value as may be sufficient to satisfy any decision
that may be passed against you or appear on…………….at…………in my office and
show cause why you should not furnish security.
Given under my hand and seal of the Court, at…………………….
this………………day of……………..19.

Registrar of Cooperative Societies, Meghalaya.

FORM OF CONDITIONAL ORDER OF ATTACHMENT
BEFORE AWARD
[Rule No.94 (6)]
OFFICE OF THE REGISTRAR OF COOPERATIVE SOCIETIES,
MEGHALAYA
Case No.
In the matter of the
Versus
………………………………………………………………………………………
member of the…………………………………………..
Whereas the Committee members of the………………………have made a
reference in writing to me complaining that……………………member of that
Society, owes it Rs.
by way of Principal/compensation with interest at and
Rs………………..by way of interest up to the date of realization and evades payment of
the same and whereas the said Committee members of the Society further declare that

<!-- page 47 -->

the same member
is about to dispose of the property from the local units of
the jurisdiction of the Registrar and whereas I am satisfied as to bona fide of Committee’s
reference and declaration and accordingly the said member was called upon to furnish
security for the sum of Rs………to produce and place at my disposal or the value vide
my orders dated……….and whereas the member failed to furnish the security. Now,
therefore, I, in accordance with Section 64 (3) (b) of the Meghalaya Co-operative
Societies’ Act (Assam Act I of 1950 as adapted by Meghalaya) hereby make the
following order against the said………………… that the right, title and interest of the
defendant in the properties set out and described in the Schedule below be forthwith
attached and shall remain attached until further orders.

This attachment will be vacated at any time if the defendant furnishes
security to the satisfaction of the Registrar
This decision is enforceable as a decree of the Civil Court having local
jurisdiction.
Date
The

19

|
| Registrar of Co-operative Societies, Meghalaya.

SCHEDULE
Form of Order Sheet
[Rule No.98 (6) (12)]
No.of Proceeding or
Orders

Order or Proceedings

Signature of Liquidator
With date

<!-- page 48 -->

Notice of change of registered address
Address of societies -----Notice is hereby given, pursuant to Section 40 of the
Meghalaya Co-operative Societies’ Act (Assam Act I of 1950 as adapted by
Meghalaya),by ……………… (name of Society) registered on………………under
certificate of registration No……….of …………………………..of the alteration in the
address of the registered office of the Society.
Previous address

Present address

Date changes

Certified that the change of address of the Society set forth above was adapted
under resolution No……………………….of the meeting of the Administrative
____________
Managing

Council/Committee
Signature of

(1)
(2)
(3)
(4)
(5)

dated, the ……………….197
Signature of (1)……………………….
CHAIRMAN

(2) …………………….
SECRETARY
