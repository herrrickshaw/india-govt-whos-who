---
doc_id: "8bbfe809f00b1fed"
source_url: "https://megipr.gov.in/tenders/RFP%20for%20providing%20Social%20Media%20Management%20Services%20for%20the%20Chief%20Minister%E2%80%99s%20Office%20(CMO),%20Meghalaya..pdf"
ministry: "Information and Public Relations Department, Meghalaya"
title: "Request for Proposal (RFP) for providing Social Media Management Services for the Chief Minister’s Office (CMO), Meghalaya"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3a164101dc1b0626"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
DIRECTORATE OF INFORMATION & PUBLIC RELATIONS
MEGHALAYA: SHILLONG
No.DAE 8/ 2024/12

Dated Shillong the 24th July, 2024

REQUEST FOR PROPOSAL (RFP) FOR PROVIDING SOCIAL MEDIA
MANAGEMENT SERVICES FOR THE CHIEF MINISTER’S OFFICE (CMO),
MEGHALAYA.”
Request for Proposal (RFP) are invited from bonafide, established, reputed agencies desirous of
association with the Directorate of Information and Public Relations, Government of Meghalaya,
Shillong for providing Social Media Management Services for the Chief Minister’s Office
(CMO), Meghalaya.
Intending agencies must note that the bid has to be submitted in two parts, Technical Bid
and Financial Bid in separate covers for each RFP. The “Technical Bid” will contain the CD/Pen
drive for power point presentation and other documents as mentioned in the RFP details. The
“Financial Bid” will contain the financial proposal with only one rate (No optional rate will be
accepted). The two separate covers will have to be inserted in a Third Cover duly sealed and
submitted as RFP offer.
The RFP should be addressed to the Director of Information and Public Relations,
Meghalaya, Shillong – 793001 by designation only. The word “for providing Social Media
Management Services for the Chief Minister’s Office (CMO), Meghalaya” should be super
scribed on the third sealed cover containing Technical Bid and Financial Bid.
Agencies may submit their application with all supporting documents on or before 8th
August, 2024 by 2:00 P.M. either by post or by hand. The application should be accompanied
with non-refundable Court fee stamp of Rs. 1,000/- (one thousand), Non-refundable processing fee
of Rs.1,000/- (one thousand) and Bid Security (EMD) @ 5% of the total quoted value in the form
of Demand Draft in favour of “Director of Information and Public Relations, Meghalaya, Shillong”
payable at Shillong. 2.5% of the quoted value in case of tenderer belonging to Scheduled
Caste/Scheduled Tribe.
This Directorate shall not be responsible for postal delay, if any.
SCOPE OF WORK
The activities to be undertaken would include the following (but not limited to):


The purpose of the Tender is to invite interested agencies with proven credentials to bid
as content providers - text, image, video, animation, creatives, etc. for CMO,
Meghalaya’s Social Media presence, which includes Facebook, Twitter, YouTube,
Instagram and any other social media platform relevant to engaging in a positive manner
with the citizens.



To develop a strategy to enhance CMO, Meghalaya’s presence on social media (CMO’s
Social Media handles on Twitter, Instagram, Facebook, LinkedIn, and any other) and to
engage a wider audience.



Make the platform multilingual (Khasi, Garo, English) --- as the content will have the
potential of much more engagement and interaction by the users of this page. Stories are to

<!-- page 2 -->

be done in multilingual format so that quite a satisfactory engagement as compared to the
other stories can be achieved.


Present success stories: This could be a combination of text, photographs, creatives and short
videos (social platform-friendly).



Create interfaces, including for feedback on different Social Media Platforms, for public
interface as well as run them.



The Agency shall be responsible to develop content including text, picture, infographic,
blogs, articles, audio-visuals, ensure live streaming of events on social media channels,
translations, etc. as and when required, with impeccable spelling and grammar.



Implementation of Social Media Analytics (using Social Media analysis) to gather useful
and credible information on issues trending on social media at the local, regional, national
and international level.



Identification of digital communication opportunities, managing response and designing a
strategic social media communication plan for the CMO, Meghalaya. This includes
undertaking social media monitoring across 150-200 keywords on a daily basis. The Social
Media Monitoring Program to create and manage a Monitoring platform, which will be
both predictive and reactive in approach.



To undertake comprehensive campaigns for events on social media including but not
limited to Twitter, Facebook, Youtube, Instagram etc.



To produce coverage reports of social media campaigns in a presentable format, preferably
using tools for data visualization.



To produce quality content and creatives, including graphics, GIFs, animations for use of
CMO, Meghalaya on its social media platforms and otherwise, on demand.



To produce quality AV content for use of CMO, Meghalaya on its social media platforms
and otherwise, on demand. This may include obtaining of stock footage, creation/purchase
of background music or voice-overs, scripting including time coding.



The AV content produced should be of HD format, mov file/high resolution mp4 and of
international quality, in English/Khasi/Garo as per requirement communicated on a caseby-case basis.



To produce quality presentations, including on MS PPT or other softwares as suitable with
animations, transitions, attractive visuals, etc on demand.



The content created has to be edited/uploaded on CMO’s Social Media/YouTube handles
as per CMO’s requirement on immediate basis.



Ability to convert all kinds of content (video/audio/files) from one format to another for
given assignments as and when required by the Ministry.



24x7 Social Media management and analysis with on-site support. A minimum team size
of 15 people with minimum 10 deployed on-site.

<!-- page 3 -->

MINIMUM ELIGIBILITY CRITERIA
A. Technical Bid:
The Tender should be accompanied with the following:1. Non-refundable processing fee of Rs. 1,000/2. Bid Security (EMD) @ 5% of the total quoted value in the form of Demand Draft in favour of
“Director of Information and Public Relations, Meghalaya, Shillong” payable at Shillong. 2.5%
of the quoted value in case of tenderer belonging to Scheduled Caste/Scheduled Tribe. Copy
of ST/SC certificate is mandated for the said purpose.
3. Court fee stamp of Rs. 1,000/- (one thousand) (Non-Refundable)
4. A bid not accompanied with a Processing Fee, Bid Security (EMD) and court Fee Stamp shall
be rejected as non responsive. This Directorate shall not be responsible for postal delay, if any.
5. Attested copy of the Goods and Services Tax (GST) registration Certificate/ Permanent
Account Number and up-to-date Income Tax Clearance Certificate.
6. Trading license: The successful bidder/tendered has to submit a Trading License from the
Khasi/Jaintia/Garo Autonomous District Council indicating the purpose of which license is
issued before undertaking the work, failing which the work order will be cancelled.
7. An undertaking stating that the tendered himself/herself is satisfied with the terms & condition
of the RFP and agrees to abide by the same for this tender.
8. Soft copy of the presentation/proposal to be presented before the Tender Committee.
9. The financial bid of the Bidder who submits the above required documents will be eligible for
financial bid opening.

B. Financial Bid:
1. Rates quoted:
(a) Should be inclusive of all charges. However, the GST of the above mentioned taxes if
any should be shown separately.
(b) Should be valid for one calendar year from the date of acceptable of tender.
(c) Should be written clearly in figure and in words. Any alternation or overwriting must
be duly signed by the Tenderers.
(d) Once the rates offered in the tender are accepted enhancement will not be entertained
under any circumstances and Agencies will be liable to complete the works at the
accepted rate.

<!-- page 4 -->

C. Bid Evaluation:
A.

Sl.
1.
2.

The proposals so received will be evaluated in terms of both Technical and Financial
parameters with respective weightage of 50% and 50% as per the table below:
Particulars
Presentation before the Tender Committee on
operational plan to execute the scope of works, quality
of previous works and firm knowledge and
understanding of social media analytic and algorithms

Maximum Mark
50

Financial Offer/Parameters
Total

50
100

Minimum qualifying marks in Technical Bid will be 30
The bidder quoting the lowest will be equated with maximum of 30 marks and for all other
applications marks will be calculated downwards on pro rata basis as per the formula below:
Formula for financial bid:
L1
L2, L3, L4, L5

= Maximum Mark i.e. 30
= Amount quoted by L1 x Total Mark
Amount quoted by L2/L3/L4/L5

General Terms and conditions:
1)

The Proposals should be addressed to the Director of Information and Public Relations,
Government of Meghalaya, Lower Lachumiere, Shillong 793001 by the designation only.
The bid has to be submitted in two parts, Technical Bid and Financial Bid in separate
envelope / covers. The sealed outer envelope should be clearly written “RFP FOR
PROVIDING SOCIAL MEDIA MANAGEMENT SERVICES OF THE CHIEF
MINISTER’S OFFICE (CMO), MEGHALAYA”

2)

All proposals must reach this Office on or before 2:00 P.M. on the 8th August, 2024 and
will be opened on the same day and time in presence of the tenderers or their authorized
representatives. If the date of submission happens to be a holiday, tenders will be opened on
the next working day. This Directorate shall not be responsible for postal delay, if any.

3)

In the event of failure implement the work within the stipulated time and requirement,
confirming to the approved specification or refusal to undertake the work allotted, the
Earnest Money which is retained as Security Deposit shall be forfeited and work order will
be cancelled.

4)

The Tenderer or Bidder cannot be an associates or consortium.

5)

The Director of Information and Public Relation, Government of Meghalaya, Shillong is not
bound to accept the lowest tender and reserves the right to accept or reject any proposal
without assigning any reason thereof. The best quality sample with reasonability of rate will
get priority for selection.

6)

The procedure adopted by the Director of Information and Public Relation, Government of
Meghalaya for opening the proposal shall be final and binding on all the parties.

7)

Undertaking/Letter of Acceptance to the terms and conditions of the RFP.

<!-- page 5 -->

8)

The agency has to give an affidavit on a non-judicial stamp paper of Rs.10/- attested by the
Notary Public (in original) that there is no Vigilance/CBI case or arbitration cases pending
with the Government of Meghalaya against the firm/supplier and that the
Proprietor/Director/Members of the Board of Directors of the bidder has never been
blacklisted by any institution Government or Private.

9)

The “Director” shall also be competent to alter/modify the specifications of any item/items
in the scope of work in the best interest of the Department during the process of finalization
of a contract viz. placement of work order.

10)

The successful agency should ensure to immediately undertake the work once the work order
is issued to them and they are bound to implement the work as per the conditions approved
by the Committee. If at any stage it is found that the work implemented by the firms is not
according to what was by approved by the Committee, action as deemed fit will be taken
against the Firm.

11)

The Price Bid shall not be opened of those proposals who have not complied with the
provisions of the bid Document or EMD clause or who have not complied with the
provisions/technical specification of the bid document.

12)

Any effort by a bidder to influence the Purchaser in its decision on bid evaluation, bid
comparison or contract award may result in rejection of the Bidder’s bid.

13)

The Director of Information and Public Relation, Government of Meghalaya may rescind
forthwith the contract in writing if,
(a)

An agency assigns or sublets any contract in respect of contract or any other contract
entered into with the Government.

(b)

Agency or his/her agent/employee are found guilty of fraud of this contract or any
other contract.

14)

To call for Re-Tender in case the Tender Committee is not satisfied with the design(s)
submitted by the participating Firms, the decision of the Tender Committee will be final and
no claims or objections on any ground shall be entertained whatsoever.

15)

No conditional tender shall be accepted.

Sd/Director
Information & Public Relations
Meghalaya, Shillong

<!-- page 6 -->

CERTIFICATE OF ACCEPTANCE OF TERMS AND CONDITIONS
(To be furnished along with the RFP)

I/We have read and fully understood the terms and conditions as laid down in the No.DAE
8/ 2024/12 Dated Shillong the 24th July, 2024 in respect of RFP for providing Social Media
Management Services for the Chief Minister’s Office (CMO), Meghalaya. to the Office of
the Director of Information and Public Relations, Meghalaya, Shillong due to be opened on 8th
August, 2024.
I/We agree to abide by the same.
I/We have signed all the pages of the Tender Documents as laid down.

Tenderer or

Signature and Seal of the His/Her Authorized

Signatory
Dated ………………………………………………
Name ……………………………………………….
Mobile No. …………………………………………
Email address ………………………………………
Address …………………………………………….
………………………………………………………
