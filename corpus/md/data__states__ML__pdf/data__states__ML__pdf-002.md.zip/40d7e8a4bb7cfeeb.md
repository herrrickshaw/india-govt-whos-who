---
doc_id: "40d7e8a4bb7cfeeb"
source_url: "https://megipr.gov.in/tenders/ML-10-2022-Pt-21.pdf"
ministry: "Information and Public Relations Department, Meghalaya"
title: "NIT for printing of departmental publications 2023 i.e Meghalaya Chronicle 2023"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "eccb91eedfaf2dc9"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
DIRECTORATE OF INFORMATION AND PUBLIC RELATIONS
::::
No. ML.10/2022/Pt/21
Dated Shillong the

Oct, 2023

DRAFT TENDER NOTICE
Tender are invited from bonafide, reputed printing press firm/agency affixing non-refundable
Court fee stamp of Rs.1,000 (One thousand) only each for printing of departmental publications 2023
i.e Meghalaya Chronicle 2023.
Detailed documents can be obtained on all working days during office hours from 20th
October, 2023 to 8th November, 2023 or the same can be downloaded from the Department website
www.megipr.gov.in. Last date for submission of Tender will be at 2:00 pm on 8th November, 2023.
The Technical Bid will be opened on the same date and time in the presence of the participants or their
authorized representative. If the date of submission happens to be a holiday, Tender will be opened on
the next working day.
Tenders received after the above date and time will not be entertained.

Director of Information and Public Relations,
Meghalaya, Shillong.
Memo.No. ML 10/2022/Pt/21 -A

Dated Shillong, the

Oct, 2023

Copy to:1.
2.
3.
4.
5.

The Under Secretary to the Government of Meghalaya, Information and Public Relations
Department for information and necessary action.
The Director of Printing and Stationery, Govt. of Meghalaya for publishing the Tender in the next
issue of the Meghalaya Gazette.
State Informatics Officer, NIC, Shillong for uploading the Tender documents in the Departmental
website.
The Advertisement Branch for publication in Local Newspaper in one issue each.
Notice Board.

Director of Information and Public Relations,
Meghalaya, Shillong.

<!-- page 2 -->

PRINTING OF MEGHALAYA CHRONICLE 2023
Technical Details of the Tender Notice:
The sizes and quality of the paper will have to meet the specification as described below:
SCOPE OF WORK:
(a) Printing of Meghalaya Chronicle 2023
TECHNICAL BIDS:
1.

Size of the Chronicle

: 21.5 cm x 28.5 cm (approx)

2.

Paper

: Inside pages: On 130 GSM Sinarmas/Art paper/
(Sample to be enclosed)
Cover: On 210 GSM Sinarmas/Art paper/ in Maplitho
(Sample to be enclosed)

3.

No. of Copies

: 9000 copies (3000 nos. English, 3000 nos. Khasi and
3000 nos. Garo)

4.

No of Pages

: 20 Pages

5.

No of Issues

: 4 (Four) issues per year (quarterly)

6.

Total No of Issues

: 11 (Eleven) issues

<!-- page 3 -->

TENDER DETAILS
Scope of work Printing of Meghalaya Chronicle 2023.
A. Technical Bid:
The Tender should be accompanied with the following:1. The application should be accompanied with a non-refundable processing fee of Rs. 1,000/- and
Bid Security (EMD) @ of Rs. 50,000/- (Rupees fifty thousand) only in the form of Demand Draft
in favour of “Director of Information and Public Relations, Meghalaya, Shillong”payable at
Shillong and 50% of EMD in case of tenderers belonging to Scheduled Caste/Scheduled Tribe
copy of ST/SC certificate need to be mandated for the said purpose. The EMD is refundable to
unsuccessful tenderers. In case of successful tenderer, the EMD will be retained as security deposit
till satisfactory completion of the job.
This Directorate shall not be responsible for postal delay, if any. A bid not accompanied with a
processing fee and Bid Security (EMD) of the stated amount shall be rejected as non responsive.
2. Court fee stamp of Rs. 1,000/- (Non Refundable).
3.

Submission of sample paper. A copy of the selected sample paper will be retained for final
comparison at the time of delivery of the articles. Tenders without paper sample will be summarily
rejected.

4. Specimen of similar works done by the Tendering Firm with statement of work experience/profile
for the last 3 years, indicating details thereof along with testimonials and certificates for such
works.
5. Minimum annual turnover of Rs.75 lakh (Printing) during the last 3 (three) financial years duly
certified by Chartered Accountant.
6. Tendering firms will have to furnish details of the printing press viz. Certificate of Registration,
name of the press, name of the proprietor, full postal address and copy of valid ISO 9001
certificate.
7. Attested copy of the Goods and Services Tax (GST) registration Certificate/ up-to-date Income
Tax Clearance Certificate and PAN number.
8. Trading license: The Non Tribal bidder must submit Trading
KHADC/JHADC/GHADC (Mandatory) or else tender will be rejected.

License

from

9. Copy of Audited Balance Sheet for the last 3 years from a Chartered Accountant.
10. Bankers solvency certificate issued by the Nationalized Bank for an estimated value of
Rs. 20,00,000/- (Rupees Twenty lakh) only.
B. Financial Bid:
1. Rate should be quoted for the first 1000 copies and subsequent 1000 copies.
2. Rates quoted should be inclusive of all taxes and charges including loading and unloading charges,
freight charges, cost of packing, and delivery to Office of the DIPR, Shillong and Office of the
Assistant Director/ District Public Relations Officer/Sub-Divisional Public Relations Officer,
Tura/Jowai/Williamnagar/Nongpoh/Nongstion/Baghmara/Resubelpara/Mairang/Ampati/Mawkyrw
at/Khliehriat/Sohra/Dadenggre/Amlarem/Pynursla/Chokpot/Raksamgre/Mawshynrut.
3. The price quoted by the bidder shall remain fixed and shall not be subject to any variation for a
period of the contract being 1 (one) year. A bid submitted with an adjustable price quotation will
be treated as non responsive and rejected. The price quoted shall be provided separately under the
Financial Bid enclosed in the main tender for each category and item presented in the Technical
Bid duly specified and signed.

<!-- page 4 -->

4. The bidder shall submit the tender document in original duly signed on each and every page. The
bidders are advised to keep a photo copy (at his own cost) of the bid document for his own
reference.
C. Bid Evaluation:
The proposals so received will be evaluated in terms of both Technical and Financial parameters
with respective weightage of 70% and 30% as per the table below:
Sl.
1

2

Particulars
1.
2.
3.
1.
2.

3

4

3.
1.
2.
3.
4.
1.
2.
3.
4.
1.
2.

5

Tender Fee
Bid Security
Court fee stamp
Annual turnover of Rs.75 Lakh (Printing) during the last 3 financial
years duly certified by Chartered Accountant
Audited Balance Sheet for the last 3 years from a Chartered
Accountant
Trading License from KHADC/JHADC/GHADC
Permanent Account Number
GST registration
ISO Certificate
GST return up to date.
Experience in printing field for at least 3 years particularly in printing
calendars and diaries
Details of the printing press/ Certificate of Registration as printing
Press
Bankers solvency certificate
Non-Blacklist affidavit
Sample paper
Meghalaya Chronicle

Maximum
Mark
6

10

12

12

20

SUB TOTAL

60

Financial Offer

40

TOTAL

100

Minimum qualifying marks in Technical Bid will be 45
The financial weightage carrying 40 marks will be computed on the basis of overall percentage
of agency charges quoted for designing and printing. The bidder quoting the lowest will be equated
with maximum of 40 marks and for all other applicants marks will be calculated downwards on pro
rata basis as per the formula below:
Formula for financial bid:
L2, L3,L4,L5 =

L1

= Maximum Mark i.e. 40

Amount quoted by L1 x Total Mark
Amount quoted by L2/L3/L4/L5

<!-- page 5 -->

General Terms and conditions:
1.

Before final printing, a proof copy in final form has to be shown to the Director, Information &
Public Relations, Meghalaya, Shillong and approval obtained in writing, failing which he is not
bound to accept delivery of the Meghalaya Chronicle in case there is/are printing mistake(s) of the
same.

2.

Articles meant for delivery should be properly packed to avoid damage during transit. If any
damage/shortage is detected during actual counting of the articles received, the cost of such
damage/shortage will be adjusted against the final bill.

3.

In the event of failure to supply the articles within stipulated time/date confirming to the approved
specification or refusal to undertake the work allotted the Earnest Money which is retained as
Security Deposit shall be forfeited and work order will be cancelled.

4.

The Tenderer or Bidder cannot be an associates or consortium.

5.

The Quotation should be addressed to the Director of Information and Public Relations,
Government of Meghalaya, Lower Lachumiere, Shillong 793001 by the designation only. The bid
has to be submitted in two parts, Technical Bid and Financial Bid in separate envelop/ covers for
each items of work. The sealed outer envelope should be clearly written “Tender for Printing of
Meghalaya Chronicle 2023”

6.

All Tenders must reach this office on or before 2:00 P.M. on the 8th November, 2023 and will be
opened on the same day and time in presence of the tenderers or their authorized representatives.
If the date of submission happens to be holiday, tenders will be opened on the next working day.
This Directorate shall not be responsible for postal delay, if any.

7.

The Director of Information and Public Relations, Government of Meghalaya, Shillong is not
bound to accept the lowest tender and reserves the right to accept or reject any tender without
assigning any reason thereof. The best quality sample with reasonability of rate will get priority
for selection.

8.

The procedure adopted by the Director of Information and Public Relations, Meghalaya for
opening the tender shall be final and binding on all the parties.

9.

Undertaking/Letter of Acceptance to the terms and conditions and also accepting the period of
delivery for supply of the same and the standard rate for a year.

10. The firm has to give an affidavit on a non-judicial stamp paper of Rs.10/- attested by the Notary
Public (in original) that there is no Vigilance/CBI case or arbitration cases pending with the
Government of Meghalaya against the firm/supplier and that the Proprietor/Director/Members of
the Board of Directors of the bidder and the Principal Manufacturer on whose behalf they have
quoted has never been blacklisted by any institution Government or Private.
11. The “Director” shall also be competent to alter/modify the specifications of any item/items for
purchasing in the best interest of the Department during the process of finalization of a contract
viz. placement of supplier order.
12. The successful tenderer should ensure immediate supplies if supply order is placed on them and
they are bound to supply material strictly as per the conditions approved by the Committee. If at
any stage it is found that material supplied by the firms is not according to be approved by the
Committee, action as deemed fit will be taken against the Firm.

<!-- page 6 -->

13. The Price Bid shall not be opened of those bidders who have not complied with the provisions of
the bid Document or EMD clause or who have not complied with the provisions/technical
specification of the bid document.
14. All the stores supplied shall be of the best quality, specification, trade mark and in accordance
with the approved standards, catalogue, samples if provided. In case of any articles supplied not
being approved, same shall be liable to be rejected or replaced and any expenses as a result of
rejection or replacement of supplies, shall be entirely at the cost of the tenderer.
15. No payment will be made for rejected stores. Rejected items must be removed by the bidders
within two weeks of the date of rejection at their own cost and are to be replaced immediately. In
case they are not removed the same will be auctioned off the risk and responsibility of the vendor
without further notice.
16. Any effort by a Bidder to influence the Purchaser in its decision on bid evaluation, bid
comparison or contract award may result in rejection of the Bidder’s bid.
17. To call for Re-Tender in case the Tender Committee is not satisfied with the design(s) submitted
by the participating Firms, the decision of the Tender Committee will be final and no claims or
objections on any ground shall be entertained whatsoever.
18. No conditional tender shall be accepted.

Director
Information and Public Relations,
Meghalaya, Shillong
