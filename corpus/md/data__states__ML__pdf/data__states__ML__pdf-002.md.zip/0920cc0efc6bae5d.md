---
doc_id: "0920cc0efc6bae5d"
source_url: "https://megcooperation.gov.in/personnel/chap14.pdf"
ministry: "Co-operation Department, Meghalaya"
title: "Transfer and posting of Government employees"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "66d5cc66c2eb7183"
---

<!-- page 1 -->

CHAPTER – XIV
TRANSFER AND POSTING OF GOVERNMENT EMPLOYEES
District Departmental Heads retained in same Station for long periods
O.M. No. PER. 1. Government have decided that District Departmental Heads holding
(AR)183/83/Pt/26,
transferable posts have been retained in the same station for almost indefinite
dt. 6 th Sept, 1994

periods. Government consider that periodical change of posting of District
Departmental Heads is desirable both in the Officers’ interest and the public
interest. It has accordingly been decided that such officers should not remain in
the same place of posting for more than four years save in exceptional cases
where the period of continuous stay in one station may be extended upto five
years.

O.M.No.PER.
93/81/45, dtd.
9 th Dec, 1981

2. Cases have come to the notice of the Government where Government
employees posted or attached to Offices of Heads of Departments holding
transferable posts as well as District Departmental Heads and other Government
employees holding transferable posts at District and Sub-Divisional levels have
been retained at the same station for almost indefinite period. Government
firmly hold that periodical change in the posting of Officers is desirable and
have decided that the period of posting of such officers in the same station
should be normally for a period of three years and no more than four years save
in exceptional cases.
(Effective from 9 th December,1981)
Categorisation of places of posting of Government employees holding
transferable posts

O.M.No.PER.
114/81/164,dt
21 st Feb,1985

3.1. Categorisation of different places of posting in the State of Government
employees holding transferable posts was considered by the Government. In
order that all Officers holding transferable posts should have reasonable opportunity
of serving in coveted as well as difficult postings Government have decided to
categorise the different places of posting as Categories A, B and C as follows:­

<!-- page 2 -->

Category

Station

A

Shillong, Tura and Jowai

B

Nongstoin, Williamnagar, Baghmara, Mairang, Cherrapunjee, Resubelpara
and Nongpoh.

C

All other Stations not included under Category ‘A’ and ‘B’ above.
3.2.
All Administrative Departments and Heads of Departments are,
hereby directed to take necessary steps to ensure rotation of Officers holding
transferable posts under their control within these three categories at regular
interval so that Officers holding posts in Category ‘A’ are transferred to
Category ‘C’ and from Category ‘C’ to Category ‘A’. An officer may be
transferred from Category ‘B’ to Category ‘C’ or ‘A’ depending on whether
his earlier posting was ‘A’ or ‘C’ respectively. The period of posting of such
officer in the same place should normally be for three years and not more than
four years, save in exceptional circumstances in accordance with the
instruction contained in Para e above. The rotation of such Officers should not
be only category-wise but also District-wise so that an Officer does not spend
too long a period within the same District.
Note :­

O.M. No.PER
58/85/4, dtd.
1 st July, 1985

Effective from 21st February, 1985

4.1. Instances have come to the notice of Government that some Government
servants have been retained in the same place of posting for more than 4 years.
This is contrary to the instructions already issued under Office Memorandum
No. PER. 93/81/45, dtd. 9th December, 1981 (refer Para 2 above) and O.M. No.
PER. 114/83/164, dtd. 21 st February, 1985 (vide Para 3.1 & 3.2 above) with a
view to see that no officer spends too long a period within the same District.
4.2.
A statement has also been made in the Assembly that Government
would adhere to the policy that the period of posting of such officers in the
same place should normally be for a period of three years and not more than
four years, save in exceptional cases.
4.3. These instructions are, therefore, to be strictly followed by all concerned.
Any departure from these instructions, namely, transfer of a Government

<!-- page 3 -->

servant from a place before three years or retention in a place beyond four
years should be brought to the notice of Personnel Department along with
special circumstances necessitating such action.
POSTING OF DISTRICT LEVEL OFFICER IN THE NEWLY
CREATED DISTRICTS RI BHOI AND SOUTH GARO HILLS
5. With the inauguration of two new districts, namely, Ri Bhoi and South
No.PER (AR) Garo Hills Districts, it has become necessary for posting district level Officers
163/88/74, dt. to Nongpoh and Baghmara. The opening up of districts will be meaningful
16 th July ,1992
when the people of the area can approach district level officers for their needs
and problems. This is particularly relevant for major departments, such as
Agriculture, Animal Husbandry & Veterinary, Health, Education, Transport,
Police and Food and Civil Supply Departments. Government attach the
greatest importance to effective functioning of the two new districts and
immediate arrangement for posting of district level officers in Nongpoh and
Baghmara to be made most expeditiously.
Meghalaya Secretariat Service Officers/staff serving for more than five
years in the same Department – Transfer thereof : ­

O.M.No.PER.
144/85/116, dt.
21 st July ,1988

6. The question of transferring Officers and staff of different Department
who have been serving for more than five years in the same Department
in the Secretariat has been engaging the attention of the Government.
After careful consideration of the matter, Government have decided that
in order to afford a chance to all members of the Meghalaya Secretariat
Service and the Meghalaya Secretariat Subordinate Service to have
working knowledge in as many Departments as practicable, all Officers
and staff should not serve in the same Department at a stretch for more
than 5 years. In the case of any officers and staff who have served in the
same Department for more than 5 years he / she will be transferred to
another Department of the Secretariat immediately. This will be
applicable in all cases excepting those requiring high specification.
(Decision effective from 21st May, 1988).

<!-- page 4 -->

Frequent and random transfer of Officers from one Department/ Office/
Place to another before completion of minimum period of three years
Finance(EA)
Deptt.O.M
No.FEA.83/9
3/145, dtd. 4 th
July, 1994, &
O.M.No.PER.
58/85/117, dt.
2.11.1996.

O.M.No.58/85/
123, dt. 18th
Nov. 1998

7.
Some Government employees holding transferable posts are being
frequently transferred and posted from one place/station to another even before
completion of the minimum period of three years. This is contrary to the
instructions contained under Paras 2.3.1. and 2.3.2. above and leads to
avoidable expenditure on transfer travelling allowance, etc., and dislocation in
administration which the State can ill-afford in the current financial crunch. It
has, therefore, been decided that transfer of all officials holding transferable
posts from one station to another before completion of three years will not be
permitted except transfer under exceptional circumstances with the prior
approval of the Chief Minister.
8.1. There has been instances of random transfer of officers from one
Department to another Department or from one branch to another branch and
from one place/station to another, sometimes even before completion of the
minimum period of three years. This action of the concerned Departments
violates Government instructions issued from time to time.
8.2. All Departments should strictly adhere to the above instructions of the
Government. In case exceptional circumstances exist necessitating such
transfer, detailed proposal is to be submitted to the Personnel & A.R.
Department for obtaining prior approval of the Chief Minister, as necessary.
No such transfer should be made without the prior approval of the Chief
Minister.
Charge reports / handling & taking over of charges

9. Government have noticed that some Officers submitted Charge Reports of
No.PER.39/76 handing and taking over charge without signing legibly resulting in delay in
/116, dtd. 24th the issue of Pay-Slips, etc., by the Accountant General to the Officer
Nov., 1998
concerned. While inviting a reference to Para 7.1. of the Assam Government
Circular No. AAA. 44/51/1 dated 1st June, 1955 incorporated at page 123 of
the Hand Book of General Circulars (extract reproduced below) it is re­

<!-- page 5 -->

emphasised that these instructions should be carefully followed. Also, the
relevant Government notifications/orders, etc., should be quoted in the Charge
Reports submitted by them.
“ Para 7.1. Also Officers signing the Transfer Charge Certificate
as “Relieving” or “Relieved” Officers should write their names
in full, in block letters (first name, middle name and surname)
under their signature, with brackets, while signing the Certificate
of Transfer of Charge”.
Discontinuance of submission of Charge Report by Gazetted Officers
authorised to draw pay from the Establishment Pay Bill
No.PER.316/
76/28, dt. 30th
Nov., 1977

10.
A reference is invited to Finance Department’s O.M. No. FEG.45/75/9,
th
dtd. 7 November, 1977, extract of which is given below for guidance.
“….A reference is invited to Rule 145 of the Assam Finance
Rules as adapted by the Government of Meghalaya and to say
that the Governor of Meghalaya is pleased to decide that
submission of Charge Report by Gazetted Officers who are
allowed to draw pay from the Establishment Pay Bill while
proceeding on or returning from leave should be dispensed with.
However, a Gazetted Officer may submit a joining report in the
enclosed Form (Annexure) in duplicate to the administratio n, one
copy of which should be forwarded to the Drawing and
Disbursing Officer duly countersigned by the Administrative
Authority for regulating his salary bill. Where the transfer of
charge involves assumption of responsibility for cash, valuables,
stores, secret documents, etc., a statement regarding items of
charge should be prepared and submitted to the Controlling
Officer duly signed by both the relieving and the relieved
officers”.

<!-- page 6 -->

ANNEXURE
Department of ………………………………………………………………….
Joining Report
I hereby report myself for duty this day ……………forenoon /afternoon
after availing of leave, from ………too …….. sanctioned vide Department of
…………. Order No. ……… dated …………..
Signature ……………………………….
Name in Block letters …………………..
Designation ……………………………
No.PER.44/83/3,
dt.21st Apr,1983.

11. While forwarding the Charge Reports to the Accountant General,
Meghalaya, the following procedures should be strictly followed by all
Officers concerned (refer Para 9 above) :(a)

In cases of first appointment , the Charge Report of the officers
are required to be furnished through the Head of the
Department or Controlling Officer concerned.

(b)

Their names are required to be written legible.

(c)

Specific remarks are to be inserted when an Officer is allowed
to hold dual/additional charge.

(d)

Charge Reports are to be furnished to the Accountant General
in duplicate stating the date and hour of taking/handing over
the charge.

Refusal / Delay in handing over charge on transfer / promotion
12.1. It has come to the notice of the Government that in certain cases of
transfer, promotion, etc., the relieved officer has pleaded inability to hand
over on the ground that the Officer was assigned/entrusted with some special

<!-- page 7 -->

works which had to be completed before handing over charge, or on some
other grounds. In certain other cases, transfers effected by Government are not
complied with even after long periods of time. Such refusal to hand over
charge to the relieving Officer has often put the relieving officer in great
difficulty, which becomes further compounded if he has already handed over
charge of his substantive post.
12.2. The matter has accordingly been considered in details. Since transfer
orders, once issued are meant to be complied with immediately, it has been
decided by the Government that whenever transfer orders are issued, the same
should invariably be effected, without fail, within a period of 15 days of the
orders being issued or before the end of the month when the transfer order is
issued, whichever is later. In case an officer does not hand over charge within
the prescribed period, the officer would be deemed to have been relieved
forthwith, immediately after expiry of the above mentioned period.
12.3. In case of any compelling reasons which prevent a transfer from being
effected, the relevant transfer orders are either to be stayed or kept in abeyance
by the concerned authority within this period. If the transfer orders are not
stayed or kept in abeyance within this specific period, then the transferred
officer would be deemed to have been automatically relieved from his post as
detailed above.
Unilateral handing/taking over of charges and non-submission of Charge
Reports to the Administrative Department(s)
13.1. Instances have come to notice that in cases of transfer, promotion, etc.,
the concerned officers have handed over charge unilaterally or taken over
charge on their own, and in different Charge Reports. This is not correct, since
handing and taking over charge of any post in Government should be done
simultaneously so that the post is not left vacant at any point of time. The
matter becomes more complicated when the assumption of
charge/responsibilities of the new post involves assumption of responsibilities
of cash, stores, etc.
13.2. Unilateral taking/handing over charge is permissible only in either of
the following circumstances :­

<!-- page 8 -->

(1) When there is a specific Government direction to this effect, when
an Officer previously holding charge of a post is relieved of his
charge with immediate effect, and the relieving officer can thus
take over unilaterally; and
(2) When the Officer taking over/handing over do not take charge of
the same post, e.g., Principal Secretary, Commissioner & Secretary
or Secretary. In such cases also the charge reports may be (drawn
up) separate(ly) indicating the posts respectively handed over or
taken over. However, even in these circumstances, it is necessary
that the handing/taking over should be done after prior
consultation and discussion, so that the handing over and taking
over of the posts is done at the same time and the post is not left
vacant and unmanned.
13.3. Government have also noticed that charge reports are not submitted
by the Officers to their Administrative Departments whenever they proceed
on transfer, promotion, leave, etc. Non-receipt of the charge reports
especially by the Administrative Department(s) concerned defeats the
purpose of maintaining of records and also leads to avoidable and
unwarranted difficulty in managing the cadre smoothly and sometimes the
Officer himself is put to difficulties because of his act of omission and
commissio n.
13.4. It is, therefore, to be ensure that whenever charges of a post are to be
made between two Officers of the same level, the charge report are to be
signed by the two concerned Officers and in no case unilateral
handing/taking over should be resorted to, except in case of the exceptions
indicated at Para 13.2 above. Further a copy of the charge report are to be
invariably submitted to the Administrative/Cadre controlling Departments.
