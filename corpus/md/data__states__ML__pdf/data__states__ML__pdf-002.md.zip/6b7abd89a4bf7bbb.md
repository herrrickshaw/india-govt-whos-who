---
doc_id: "6b7abd89a4bf7bbb"
source_url: "https://megpolice.gov.in/sites/default/files/circular_02_2012_0.pdf"
ministry: "Home (Police) Department, Meghalaya"
title: "Circular No. 02/2012 : Take steps to remove unauthorised construction from the Govt. premises"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "592e3ab5c9e4b6e5"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA

OFFICE OF THE DIRECTOR GENERAL OF POLICE
MEGHALAYA ::::: SHILLONG
Email [d- phq-mcg_i).;llaya@yahoo.in

II

I

;

CIRCULAR No. 2/2012(PE)
It has come to the notice of the Police Headquarters that there have been a

i
n~ber of unauthorised construction of temporary structures within the premises of Police land.
i

Sucp constructions have created problems for the Department as whenever the Department plans
I

for i expansion of accommodation and other facilities, evicting the occupants of such

con~tructions becomes difficult and at times the Department has to take recourse to legal remedy.
I

Th¢ Heads of the Districts/Units/Organisations are therefore directed to take immediate steps to

re~ove unauthorised constructions from the Govt. premises under their control to avoid
I

I

aforesaid situation. If necessary, legal remedy may be sought wherever required, to evict and
I

disfuantle the unauthorised constructions.
I
i
!
i

I

I

Sd/(Rajiv Mehta, IPS)
Director General of Police,
Meghalaya, Shillong.
. Dated Shillong, the 19th November, 2012.

M~mo No. PE.51SNP-GEN11112006127-A
Copy for favour of information and necessary action to:!I 1. The Addl. Director General ofPolice, (HQRS) I (SB)
I (TAP) I (CID) I (L&O),
.
1
Meghalaya, Shillong.
12. The Inspector General of Police, (H~CID) I (F&ES) I (OPS) I (WR), Meghalaya,
Shillong.
13. The Deputy Inspector General ofPolice, (CID) I (ER), Meghalaya, Shillong.
~ 4. The Director, (MPRO) I (FSL), Meghalaya, Shillong.
js. The Asstt. Inspector General of Police (Admn) I (Estt), Meghalaya, Shillong.
! 6. The Principal, Police Training School, Golflink, Shillong.
j 7. The Spl. Superintendent of Police (CID) I (SB-I) I (SB-11), Meghalaya, Shillong.
8. The Superintendent of Police, (EKH) I (WKH) I (SWKH) I (WJH) I (EJH) I (RIBHOI) I
1
i (WGH) I (EGH) I (SGH) I (NGH) I (SWGH) I (F&ES) I (Infi}), Meghalaya.
The Commandants, Ist MLP I 2nd MLP I Jrd MLP I 4th MLP / 516 MLP I 6th MLP
Meghalaya.
110. The Registrar, 0/o the Director General ofPolice, Meghalaya, Shillong.
1 11. The In-charge, Computer Wing, PHQ, Shillong.
112. The In-charge, Record Room PHQ, Meghalaya, Shillong.
1

19.
J

Ii

!

:0~!::

Asstt. lns0?LofPolice (R),
Shillong.
