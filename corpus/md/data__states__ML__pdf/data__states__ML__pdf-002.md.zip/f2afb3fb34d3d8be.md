---
doc_id: "f2afb3fb34d3d8be"
source_url: "https://megamb.gov.in/Documents/Empanelment_of_Agencies_for_Market_Linkage_Advisory_2026.pdf"
ministry: "Meghalaya State Agricultural Marketing Board, Meghalaya"
title: "EOI – Empanelment of Agencies for Market Linkage Advisory & Value Chain Development   MSAMB invites eligible agencies, consultants, firms, and professionals for empanelment to provide consultancy services for market linkage advisory and value chain development of agricultural & allied products in Me"
date: ""
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d82519ec8cd0b4cb"
---

<!-- page 1 -->

REQUEST FOR EXPRESSION OF INTEREST (EOI)

(Off-line)

For

Empanelment of Agencies for Market Linkage Advisory and Value Chain Development of
Agricultural & Allied Products in Meghalaya

Reference No:
Dated: ___________ 2026

Issued by: Meghalaya State Agricultural Marketing Board (MSAMB)
Cleve Colony, Shillong – 793003
Meghalaya, India

1

<!-- page 2 -->

NOTICE INVITING EOI
This EOI is issued by the undersigned inviting Expressions of Interest from eligible consultants for
empanelment to provide consultancy services for Market Linkage Advisory and Value Chain Development
of Agricultural and Allied Products in Meghalaya.
Reference No: NO.MSAMB/ESTT/MLVCD/65/2026-27/9

Dated:18/05/2026

1. IMPORTANT DATES
Sl No
1

Key Information/ Events

Time/Venue/Address

Date of Issuance of EoI

Date: 18/05/2026

Last Date & Time of Receipt of Queries

Date: within 30 days of
publication

2

Email: ambmg-meg@nic.in
3

Hybrid:
Pre-submission Meeting

Online:
In-person:

4

Last Date & Time of Submission of Technical
Proposal.

Date: Within 30 days of
Publication

(Note: No need to submit any financial proposal)

Time:
Date: 24th June, 2026

5
Date & Time of Opening of Technical Proposals

Time: 11 a.m
6

Website for Downloading the EOI

https://megamb.gov.in/

2

<!-- page 3 -->

Sl No

Key Information/ Events

7

Time/Venue/Address
Joint Managing Director,
MSAMB, Cleve Colony-793003.

Address for Submission & Opening

8

______________________
Meghalaya State Agricultural
Marketing Board (MSAMB),
Officer Inviting the EOI

Cleve Colony, Shillong –
793003
Meghalaya, India

Sd/Managing Director,
MSAMB

3

<!-- page 4 -->

1. INTRODUCTION
Meghalaya State Agricultural Marketing Board (MSAMB), Department of Agriculture and
Farmers’ Welfare, Government of Meghalaya invites Expressions of Interest (EOI) from
eligible and experienced firms, agencies, consulting organizations, and individual
professionals for empanelment to provide advisory support, market linkage facilitation,
and value chain development services for agricultural and allied products of Meghalaya.
This EOI is exclusively for technical empanelment. No financial proposals are required to
be submitted by the agencies. The objective is to establish a pre-qualified panel of up to
fifteen (15) competent agencies with proven domain expertise. Post-empanelment,
specific work assignments shall be awarded to empanelled agencies through limited
tender as per the prevailing norms of MSAMB and the Government of Meghalaya. No
minimum volume of work is guaranteed.
Interested applicants meeting the eligibility criteria are invited to submit their proposals in
accordance with the requirements outlined in this EOI document.
Further details, if any, may be obtained by sending email to: ambmg-meg@nic.in
VENUE AND DEADLINE FOR SUBMISSION
A. The sealed envelope shall be submitted to:
The Joint Managing Director
Meghalaya State Agricultural Marketing Board
Cleve Colony, Shillong – 793003
The proposal should clearly mention on the outer envelope:
a) Name and address of the firm/ organization/Individual
b) “EOI for Empanelment of Agencies for Market Linkage Advisory and Value Chain
Development of Agricultural & Allied Products in Meghalaya”
c) EOI Reference No.
B. TERMS AND CONDITIONS
•

MSAMB reserves the right to accept or reject any EOI without assigning any reason.

•

This EOI is for technical empanelment only. No financial bids are invited or will be
opened.

•

The initial empanelment shall be valid for a period of 1 (one) year. However further
extension beyond one (1) year depends upon the requirement of the procuring entity
and performance of the agency.

4

<!-- page 5 -->

•

The submitted credentials will be verified by the Evaluation Committee.

•

Empanelment does not guarantee any minimum volume of work. Individual
assignments will be awarded separately through a limited tender process among
empaneled agencies, wherein the Scope of Work will be issued and agencies will be
invited to submit their financial proposals. The award of work will depend on the
specific nature and requirements of each project, as outlined in the Letter of Intent
(LoI) issued post-empanelment when inviting financial proposals.

•

The authority reserves the right to withdraw the engagement at any stage in the
interest of the program by serving one (1) months’ notice period. However, the same
notice period shall be applicable in the event that the agency intends to withdraw.

•

Any revision in terms shall be communicated in writing and mutually agreed upon.

•

All amendments will be uploaded on __________

2. BACKGROUND
The Meghalaya State Agricultural Marketing Board (MSAMB), Government of Meghalaya,
is mandated to strengthen the agricultural marketing ecosystem in the state of Meghalaya,
enhance farmer access to markets, and promote value addition across key commodities.
Meghalaya is known for its high-value, low-volume agricultural produce, much of which is
naturally organic. Key products include:
a. GI-tagged Lakadong Turmeric
b. Ginger
c. Pineapple
d. Khasi Mandarin
e. Indigenous spices, horticultural produce, etc.
The State has invested significantly in:
a. Processing infrastructure (freeze-drying, IQF, dehydration)
b. Spice processing units
c. Collection and aggregation units
Further, Meghalaya has actively participated in global and national platforms such as
Biofach and World Food India, leading to growing demand.

5

<!-- page 6 -->

3. OBJECTIVES OF THE EOI
The primary objective of this EOI is to empanel qualified and experienced agencies who
can provide technical advisory services, market linkage support, and value chain
development for agricultural and allied products of Meghalaya.
The specific objectives of this empanelment are as follows:
a) To create a pre-qualified panel of domain experts with proven experience in
agricultural marketing, value chain development, and market linkage facilitation.
b) To provide market intelligence and strategic advisory to strengthen the
commercialization of fresh and processed agricultural products.
c) To support value chain development through commodity mapping, gap analysis,
and business model development.
d) To facilitate domestic and international market linkages for FPOs, cooperatives, and
producer groups.
e) To assist in infrastructure planning, branding, packaging, and certification support.
f) To strengthen the market readiness and institutional capacity of FPOs and
cooperatives through targeted capacity-building interventions.

4. SCOPE OF WORK
The empanelled firms, agencies, consulting organizations, or individual professionals shall
provide advisory and technical support to MSAMB on an assignment basis. The scope of
work shall include, but not be limited to, the following components:
4.1 Agricultural Value Chain Development:
a) Commodity mapping and cluster identification
b) Value chain gap analysis
c) Identification of high-potential markets
d) Business model development
4.2 Market Linkages & Commercialization:
a) Buyer-seller linkage development
b) Retail, institutional and export market access
c) Integration with digital platforms (e-NAM, e-commerce, etc.)
4.3 Product Development & Standardization:
a) Product positioning and branding
b) Packaging and certification (Organic, GI, export standards etc.)
c) Compliance with domestic and international norms

4.4 Processed & Value-Added Product Promotion:
6

<!-- page 7 -->

Scaling of:
•
•
•
•
•

Freeze-dried products
IQF products
Dehydrated products
Processed spices, etc.
Any other products

4.5 Infrastructure & Investment Advisory:
a. DPR preparation for:
• Collection and aggregation centers
• Cold storage & warehouses
• Processing units like Prime Hubs etc.
• Any other requirement
b. CPPP (Community Public Private Partnership)/ PPP structuring and investor
outreach
4.6 Capacity Building:
a) Training of FPOs, cooperatives and stakeholders
b) Exposure visits and workshops

5. PRODUCT CATEGORIES:
a) Fresh Fruits like Pineapple, Khasi Mandarin and other fruits
b) Fresh Vegetables & Perishables
c) Spices (Raw & Processed) like lakadong turmeric, ginger, black pepper, long
pepper, Cinnamon, etc.
d) Processes & Value-Added Products such as,
• Pulp, puree, juices
• Dehydrated products
• Freeze-dried products
• IQF products
• Processed spices
e) FMCG & Retail Products
• Packaged food
• Ready-to-cook / ready-to-eat
• Branded agri-products
• Any other

7

<!-- page 8 -->

6. IMPLEMENTATION FRAMEWORK
The engagement with the empaneled firms, agencies, consulting organizations, or
individual professionals shall be implemented through a structured approach coordinated
by the MSAMB. The framework will broadly include the following steps:
•
•

•
•
•

•

Identification of Requirements: MSAMB will identify priority commodities,
clusters, FPOs/cooperatives, and stakeholders requiring advisory support, market
linkage, and value chain development interventions.
Assignment of Empanelled Entity: Based on the requirement and the expertise of
the empanelled firms/agencies, MSAMB will issue work orders or enter into
contracts with empaneled agencies through limited tender.
Initial Assessment: The empanelled entity may conduct an initial assessment to
understand the existing value chain, market potential, infrastructure gaps, and
commercialization requirements.
Preparation of Action Plan: Based on the assessment, the empanelled entity shall
prepare a structured engagement plan outlining the proposed activities related to
market linkage, branding, certification, product development, and value addition.
Implementation of Activities: The empanelled entity shall facilitate buyer-seller
linkages, domestic and export market access, capacity building, and other advisory
services as required.
Monitoring and Reporting: The empanelled entity shall submit periodic progress
reports to MSAMB and participate in review meetings as and when required.

7. KEY DELIVERABLES
Empaneled agencies will be required to deliver measurable outcomes aligned with the
objectives of MSAMB. Key deliverables may include, but are not limited to:
a) Inception reports
b) DPRs/feasibility reports
c) Strategy papers
d) Progress reports
e) Final reports
However, the specific deliverables may vary on a case-by-case basis, depending on the nature
and requirements of the assignments awarded after empanelment.

8. PRE-QUALIFICATION CRITERIA for the Bidders
Applicants must satisfy the following mandatory eligibility requirements. Failure to comply
with any mandatory criterion will lead to outright rejection of the proposal.

8

<!-- page 9 -->

Sl
No
1

Documents to be
submitted

Criteria

Legal Status: The applicant must be a legally
registered entity such as a company, LLP,
partnership or proprietorship or an individual.

a. In case of
Organization: A
Certificate of
Incorporation/
Registration or any other
acceptable document
must be submitted as
proof of compliance with
this criterion.
i. GST Certificate
ii. PAN
b. In case of Individual:
Resume with Cover letter

2

Past Experience: The bidder must have successfully
completed at least two contracts with any
Government agency, Public Sector Undertaking
(PSU), or large corporate entity in India during the
last 7 years preceding April 2026, in at least one of
the following areas:
•
•
•
•
•
•

Agri-marketing / Agricultural marketing
advisory
Market linkage / sourcing / procurement
Domestic
or
international
trade
(import/export)
Value chain development of agricultural /
allied products
Product commercialization / branding /
packaging / certification support
Food processing / FMCG / retail supply chain
engagement

Note: Ongoing assignments will be considered,
provided that at least six months of work has
been successfully completed.

9

a. Work Orders.
b. Completion/Client
certificates
c. Experience Certificate
Note: The work order or
completion/client
certificate must clearly
specify the scope of
work.

<!-- page 10 -->

Sl
No

Documents to be
submitted

Criteria

3

Blacklisting: The applicant must not be blacklisted or
debarred by any Government, PSU, or donor agency
as of the proposal submission date.

Self-declaration.

4

Conflict of Interest: The applicant must not have any
conflict of interest in relation to this EOI and the
proposed engagement with MSAMB.

Self-declaration.

9.

Technical Qualification Criteria

Only bidders who meet the Pre-Qualification Criteria will be eligible for technical
evaluation. Bidders must submit all required documents in accordance with the prequalification criteria, technical qualification criteria, and other provisions of the EoI
document. The technical proposals will be evaluated based on the following parameters:
Sl
No
1

Marks

Parameter

The bidder must have successfully completed at
30 •
least two contracts with any Government agency, Marks
•
Public Sector Undertaking (PSU), or large
corporate entity in India during the last 7 years
•
preceding April 2026, in at least one of the
following areas:
•Agri-marketing / Agricultural marketing
advisory
•Market linkage / sourcing / procurement
•Domestic or international trade
(import/export)
•Value chain development of agricultural / allied
products
•Product commercialization / branding /
packaging / certification support

10

Documents to be
submitted
Work Orders /
Agreements
Completion
Certificates
Client credentials
clearly indicating
nature of work

<!-- page 11 -->

Sl
No

Parameter

Marks

Documents to be
submitted

35 •
Marks

Approach &
Methodology
Note (not more
than 10 pages)
Work plan with
timelines (Activity
plan)

•Food processing / FMCG / retail supply chain
engagement
Note: Ongoing assignments will be considered,
provided that at least six months of work has
been successfully completed.
➢ 2 Contracts = 20 Marks
➢ 3 Contracts = 25 Marks
➢ 4 or more Contracts = 30 Marks
2

Approach, Methodology: Evaluation will be
based on
a) Understanding of Assignment –
(Demonstrates clear understanding of
Meghalaya’s agricultural ecosystem, value
chains, key commodities, market structure,
and overall scope of market linkage and value
chain development under MSAMB) = 10
Marks
b) Approach & Methodology
(Logical, structured, and practical
methodology aligned with market linkage
and value chain development)
= 10 Marks
c) Implementation strategy and Work Plan:
(Realistic work plan with defined activities,
timelines, milestones, and deliverables) = 5
Marks
d) Innovation and Value addition: (Practical
strategies to improve market outcomes and
price realization) = 5 Marks
e) Feasibility and Practicality: (Ground-level
applicability, scalability, and alignment with
Meghalaya context) = 5 Marks

11

•

<!-- page 12 -->

Sl
No
3

Technical Presentation: Evaluation based on:
•
•
•
•

•

4

Marks

Parameter

Clarity and structure of presentation = 4
Marks
Demonstration of relevant experience = 5
Marks
Case studies / past success stories = 5 Marks
Understanding of agri value chains and
market systems (preferably
Meghalaya/Northeast) = 5 Marks
Team strength and responsiveness to queries
= 6 Marks

Regional Presence / Experience: Presence /
Experience in implementing similar projects in
any of the North Eastern States in India during
last 7 years preceding April 2026.

Documents to be
submitted

25
Agencies shall be
Marks separately
notified
about the schedule
for the presentation,
which
may
be
conducted in online
or offline mode

10
•
Marks
•

Work Orders /
Completion
Certificates
Client certificates

Note: If a bidder has completed four similar
projects/contracts in the last seven years
preceding April 2026, they will be awarded 10
marks under Criterion 4 and 30 marks under
Criterion 1. Similarly, if a bidder has completed
four projects, none of which have been
implemented in any of the North Eastern States,
they will receive 30 marks only under Criterion 1
and no marks under Criterion 4.
Note:
• Bidders must score at least 75 marks out of 100 in the technical evaluation to
qualify for empanelment.
• Up to fifteen (15) highest-scoring technically qualified bidders shall be
empanelled.
• Tie-Breaking Rule: If two or more bidders secure the same total technical score,
the ranking shall be determined by the higher score in the following sequence:
1.
2.
3.
4.

Approach, Methodology & Work Plan (Parameter 2)
Relevant Experience (Parameter 1)
Technical Presentation (Parameter 3)
Length of relevant experience in the North Eastern States (Parameter 4)

12

<!-- page 13 -->

Sl
No

Marks

Parameter

•
•
•

Documents to be
submitted

If a tie persists after all these steps, the Authority may, at its discretion, either
empanel all such remaining tied bidders (up to a maximum) or decide the final
ranking by draw of lots.
All claims must be supported by documentary evidence; unsupported claims may
not be considered.
The authority reserves the right to verify submitted credentials independently.
In case of false, misleading, or unverifiable information, the proposal shall be
rejected.

10. DURATION OF EMPANELMENT
The empanelment of the agency shall be initially valid for a period of one (1) year from the
date of issuance of the empanelment letter. However, the empanelment may be extended
beyond the initial period based on: I) Requirement of the programme, and II) Performance
of the agency/individual consultant during the initial engagement.
Any extension shall be mutually agreed upon in writing between the agency and the
Meghalaya State Agricultural Marketing Board (MSAMB).

11. REPORTING AND MONITORING
The empanelled Training Agencies will report to the designated officer at the Meghalaya
State Agricultural Marketing Board (MSAMB). Monitoring will include:
•
•

Submission of Periodic progress reports
Participation in review meetings as scheduled

12. PROPOSAL SUBMISSION GUIDELINES & EVALUATION METHODS
The bidders are required to submit their technical proposals using a Single Sealed
Envelope containing the Technical Proposal only. No financial proposal is to be
submitted.
Outer Envelope: The envelope shall be clearly superscripted with:
•

•

"Technical Proposal for Expression of Interest (EOI) for “Empanelment of Agencies
for Market Linkage Advisory and Value Chain Development of Agricultural & Allied
Products in Meghalaya”
EOI Reference No.

13

<!-- page 14 -->

•
•

Name and Address of the Bidder
Contact Details (Email & Phone)

Contents of Technical Proposal:
The Technical Proposal shall include:
1. Covering Letter
2. Company Profile
3. Documents supporting Pre-Qualification Criteria
4. Documents supporting Technical Qualification Criteria
5. Approach, Methodology & Training Plan (not more than 10 pages)
6. Details of Relevant Training Experience & Project Credentials
7. Self-declarations:
• Non-blacklisting
• Conflict of Interest declaration
8. Any other supporting documents as mentioned in this EOI
Note: All documents must be self-attested by the authorised signatory. The authority
reserves the right to seek additional documents or clarification from any applicant.

13. SUBMISSION PROCESS
The Technical Proposals must be submitted in a sealed envelope to the address specified
in this EOI on or before the deadline indicated in Section 1 (Important Dates). Late
submissions shall not be entertained and will be summarily rejected.

14. OPENING OF PROPOSALS & EVALUATION METHOD
Step 1: Technical Proposal Opening
Technical proposals shall be opened on the date and time specified in Section 1, in
the presence of bidders or their authorized representatives who choose to attend.
Step 2: Pre-Qualification Evaluation
All proposals will first be evaluated against the mandatory Pre-Qualification
Criteria. Only proposals meeting all eligibility requirements will proceed to
technical evaluation.
Step 3: Technical Evaluation
Technical proposals shall be evaluated as per the Technical Qualification Criteria
defined in Section 9. Bidders scoring a minimum of 75 marks out of 100 will be
considered for empanelment.

14

<!-- page 15 -->

15. EVALUATION METHODOLOGY
Stage 1: Pre-Qualification Evaluation
•
•
•

All technical proposals received shall first be evaluated against the Pre-Qualification
Criteria outlined in Section 8.
Only those bidders who meet all eligibility requirements and submit the required
supporting documents shall proceed to technical evaluation.
Proposals not meeting pre-qualification criteria shall be rejected and will not proceed
to technical evaluation.

Stage 2: Technical Evaluation (100 Marks)
•
•
•
•
•

The technical proposals of eligible bidders shall be evaluated based on the Technical
Qualification Criteria specified in Section 9.
The maximum marks for technical evaluation shall be 100 marks.
The Bidders must score at least 75 marks out of 100 in the technical evaluation to
qualify.
The top fifteen (15) scoring bidders shall be empanelled.
If two or more bidders achieve the same total score, the Tie‑Breaking Rule set out in
Section 9 shall be applied to determine the ranking.

Stage 3: Empanelment
•
•

The shortlisted bidders shall be notified and invited to enter into a Framework
Empanelment Agreement with MSAMB.
Specific work assignments will subsequently be contracted through limited tender
among the empanelled agencies, in accordance with MSAMB’s procurement
norms.

16. CONFIDENTIALITY
All information shared during the engagement between MSAMB and the empanelled
agency shall be treated as strictly confidential. The agency shall not disclose any
information related to MSAMB operations, programmes, or activities to any third party
without prior written consent from MSAMB

17. CONFLICT OF INTEREST
Applicants must disclose any potential conflict of interest in relation to this EOI and the
proposed engagement with MSAMB. Any agency found to have a conflict of interest shall
be disqualified from the selection process. A Self-declaration of no conflict of interest must
be submitted as part of the Technical Proposal.

15

<!-- page 16 -->

18. EXECUTION OF AGREEMENT & POST-EMPANELMENT TERMS
Upon completion of the selection process, each empaneled agency shall enter into a
Framework Agreement with MSAMB. The agreement shall be effective from the date of
its execution and shall remain valid for the duration of empanelment as defined in Section
11, unless terminated earlier in accordance with the terms of the agreement.
Post-Empanelment Engagement Process:
•
•
•
•
•
•
•

Empanelment constitutes pre-qualification only and does not guarantee any
minimum volume of work.
The agreement shall constitute a binding contract between MSAMB and the
empanelled Agency.
Specific assignments shall be awarded to empanelled agencies through limited
tender invitations restricted to the empanelled panel.
MSAMB reserves the right to invite proposals from all or selected empaneled
agencies depending on the specific requirements of each assignment.
The agreement may be amended or extended only with the written consent of both
parties.
MSAMB reserves the right to terminate the agreement in case of non-performance,
breach of terms, or in the interest of the programme.
All terms agreed upon in the EOI, including scope of work, deliverables, and payment
structure, shall be incorporated into the agreement unless otherwise amended in
writing and mutually agreed.

19. RIGHTS OF THE AUTHORITY
MSAMB reserves the right to:
•
•
•
•
•
•

Accept or reject any proposal without assigning any reason.
Seek clarification from applicants at any stage of evaluation process.
Modify this EOI if necessary; with amendments uploaded on ______
De-list any empanelled Agency at any stage if found unsatisfactory or noncompliant with the terms of engagement.
Determine the number of agencies to be empanelled
Not proceed with the empanelment process at any stage without assigning any
reason.

20. DISPUTE SETTLEMENT CLAUSE
Amicable Resolution:

16

<!-- page 17 -->

In the event of any dispute, disagreement, or claim arising out of or relating to this EOI, the
selection process, or the subsequent engagement/agreement, the parties shall first
attempt to resolve the matter amicably through mutual consultation.
Escalation to Senior Officials:
If the dispute cannot be resolved through consultation within 15 (fifteen) days from the
date of notice of the dispute, the matter shall be escalated to the Joint Managing Director
of MSAMB and the authorized representative of the Agency for negotiation and
resolution.
Arbitration:
•

Any dispute that cannot be resolved amicably or through escalation shall be finally
resolved by arbitration under the Arbitration and Conciliation Act, 1996 (as
amended from time to time).

•

Arbitration proceedings shall be conducted by a sole arbitrator mutually
appointed by the parties. If the parties are unable to agree on the appointment,
the arbitrator shall be appointed by the Joint Managing Director of MSAMB.

•

The arbitration proceedings shall be conducted in English, and the venue of
arbitration shall be Shillong, Meghalaya.

Binding Award:
The decision or award rendered by the arbitrator shall be final, conclusive, and binding on
both parties. The parties undertake to comply with and carry out such award without
delay.
Governing Law:
This EOI, the subsequent engagement, and the agreement shall be governed by and
construed in accordance with the laws of India.
Interim Relief:
During the pendency of any dispute resolution process, the Agency shall continue to
perform its obligations under the agreement unless otherwise directed by MSAMB in
writing.
*********************************************************************

17
