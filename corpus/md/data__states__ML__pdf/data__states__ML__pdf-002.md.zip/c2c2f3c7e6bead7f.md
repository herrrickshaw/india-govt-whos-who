---
doc_id: "c2c2f3c7e6bead7f"
source_url: "https://khadc.nic.in/acts_rules_regulations_bills/Notification_update/Online_Payment_Notification.pdf"
ministry: "Khasi Hills Autonomous District Council (KHADC), Meghalaya"
title: "NOTIFICATION Dt. 23.04.2024 (Online Payment of Professional Tax)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f8cbe7373c04eb4a"
---

<!-- page 1 -->

OFFICE OF THE EXECUTIVE COMMITTEE
KHASI HILLS AUTONOMOUS DISTRICT COUNCIL
SHILLONG.

NO.DC.XXIII/TW/114/2020-2024/47/2

Dated : Shillong, the 23r" April, 2024
NOTIFICATION

This is or general information to all Professional Tax payers under the Meghalaya

Professions, Trades, Callings and Employments (Amendment) Rules, 2022 within the jurisdiction of the
Khasi Hills Autonomous District Council having issues in respect to Online Payment of Professional Tax
are hereby requested to approach the office of the undersigned.

Sd/

Superintendent (Taxation)
Khasi Hills Autonomous District Council,

Shillong
Memo NO.DC.XXIII/TW/114/2020-2024/47/2

Dated : Shillong, the 23" April, 2024

Copy to the:

1. The Chief Executive Member,
2. Executive Member, i/c Taxation, etc.,
3

Executive Member ilc

etC.,»

Khasi Hills Autonomous District Council,
Shillong for favour of kind information

3. Secretary to the Executive Committee,

4. Dy.Secy. Taxation,
5
Under Secy. Taxation,

6.System Analyst, IT Department for favour of kind information and necessary action.

Cirne2

Superintendent (Taxation)
KhasiHills Autonomous District Council,

Shillong
