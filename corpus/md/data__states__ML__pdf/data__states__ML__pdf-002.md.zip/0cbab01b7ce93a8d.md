---
doc_id: "0cbab01b7ce93a8d"
source_url: "https://megipr.gov.in/tenders/TenderNotice_MP_1_2023_5.pdf"
ministry: "Information and Public Relations Department, Meghalaya"
title: "NIT for designing and printing of departmental publications i.e.(1) Multi Paged Colour Wall Calendar -2024 (2)Multi Paged Colour Desk Calendar -2024 and (3) Deluxe Diary-2024"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bc6dede78a8eed62"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
DIRECTORATE OF INFORMATION AND PUBLIC RELATIONS
::::
No.MP.1/2023/5
Dated Shillong, the 27th June, 2023
TENDER NOTICE
Tender are invited from bonafide, reputed printing press firm/agency affixing nonrefundable Court fee stamp of Rs.1,000 (One thousand) only for each item for designing and
printing of departmental publications i.e.(1) Multi Paged Colour Wall Calendar -2024 (2)
Multi Paged Colour Desk Calendar -2024 and (3) Deluxe Diary-2024.
Detailed documents can be obtained on all working days during office hour from 28th
June, 2023 to 12th July, 2023 or the same can be downloaded from the Department website
www.megipr.gov.in. Last date for submission of Tender will be at 2:00 pm on 12th July,
2023. The Technical Bid will be opened on the same date and time in the presence of the
participants or their authorized representative. If the date of submission happens to be a
holiday, Tender will be opened on the next working day.
Tenders received after the above date and time will not be entertained.

Sd/Director of Information and Public Relations,
Meghalaya, Shillong.
