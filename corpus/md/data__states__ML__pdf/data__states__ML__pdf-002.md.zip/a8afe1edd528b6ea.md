---
doc_id: "a8afe1edd528b6ea"
source_url: "https://megipr.gov.in/tenders/Short%20Tender%20Notice-Printing%20of%20publication%20-%202026.pdf"
ministry: "Information and Public Relations Department, Meghalaya"
title: "Short Tender Notice for designing and printing of Departmental Publications i.e. (1) Multi Paged Colour Wall Calendar 2026 (2) Multi Paged Colour Desk Calendar 2026 and (3) Deluxe Diary 2026"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "71b91e0c919fb7ee"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
DIRECTORATE OF INFORMATION AND PUBLIC RELATIONS
::::
No.MP.1/2025/4
Dated Shillong, the 9th October, 2025
TENDER NOTICE
Tender in sealed cover are invited from bonafide, reputed printing press firm/agency
affixing non-refundable Court fee stamp of Rs.1,000 (Rupees One thousand) only for each item
for designing and printing of departmental publications i.e. (1) Multi Paged Colour Wall Calendar
-2026 (2) Multi Paged Colour Desk Calendar -2026 and (3) Deluxe Diary-2026.
Detailed documents can be obtained on all working days during office hours from 10th
October, 2025 to 30th October, 2025 or the same can be downloaded from the Department
website www.megipr.gov.in. Last date for submission of Tender will be at 2:00 PM on 30th
October, 2025. The Technical Bid will be opened on the same date and time in the presence of
the participants or their authorized representatives. If the date of submission happens to be a
holiday, Tender will be opened on the next working day.
Tenders received after the above date and time will not be entertained.

Sd/Director of Information and Public Relations,
Meghalaya, Shillong.
