---
doc_id: "2cfca34ca060e4db"
source_url: "https://msrls.nic.in/sites/default/files/notification-shortlisted-candidates-written-examination-posts-dfs-ibcb-yp-fnhw-and-district-accounts.pdf"
ministry: "Meghalaya State Rural Livelihoods Society, Meghalaya"
title: "Shortlisted candidates"
date: ""
pages: 4
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "e3af8cf3d60b1fc4"
---

<!-- page 1 -->

(2

% F; ; 4
AG Fa GOVERNMENT OF MEGHALAYA i 3
MEGHALAYA STATE RURAL LIVELIHOODS SOCIETY See

(The Nodal Agency of Govt. of Meghalaya for Implementing NRLM, Ministry of Rural Development. Govt. of India)

Montfort Building, 2! Floor, Dhanketi, Shillong-793001
(&: msris2011@gmait.com & msris.nic.in 8 :0364-2502130
ee en pian
MSRLS/SMMU/HR/D-REC/2157/26-27/ 5332 Dated: Shillong the 1 October, 2026
FICATION

In pursuance to the Recruitment Advertisement No. MSRLS/SMMU/HR/REC/D-
ADVT/2158/25-26/4675 Dated: Shillong the 29% July, 2026 with regards to the advertisement of
various post at various District Mission Management Unit (DMMUs), under the Meghalaya State Rural
Livelihoods Society (MSRLS).

Based on the Qualification and Experience: - Essential and Desirability, the candidates who
had submitted their application through online mode have been shortlisted in Annexure-I & II, along
with the Registration Numbers for appearing the Written Examination and Skill Test (practical) and
the Standard Admit Card is at Annexure -IIJ. All candidates are to report to the examination centre
one (1) hour before the start of the exam. No TA/DA can be claimed for appearing the said
examination. The venue and time of the said Written Examination & Skill Test (practical) is mentioned
as under:

Examination Date
[se|memeren [Seem [time [ome [PS
District Functional
Specialist- Institution .
1 | Building & Capacity ° pee hd KJP Assembly
Building (DFS-IBCB) | Written 5 po B eonn Hal, Barik IGP
Young Professional- | Examination 10:30am-12:30 pn { Pot Shillong,
2 Food , Nutrition,
Health & Wash
(FNH! 16% October,
© Reporting Time: | Tech Services, 2026
F 9:30am- 10:20 am | Lower
pale Tet © Duration of exam | Lachumiere near
(Practical)
a 10:30am-12:30 pm | Malki point
District Accounts Shillong.
Assistai ~
int *Reporting Time: | KJP Assembly
Written 1:20pm- 1:50 pm Hall, Barik IGP
Examination _| Duration ofexam_| point Shillong.
2:00pm- 4:00 pm
= V2. sz
/ &/ Va\ a .
/
1S] perm : 3432 24 Jy Chief Opgratin, Officer ity
." 3] Meghalaya State ROMO tigotsnnaels $°°
\e seus/sumy ApPP-REC/2157/26-27/-5 332 4 patseahifiiler the 1S0LQLr, 2026
‘THieSecretary, CARD Deptt,, GoM and CEO, MSRLS, for kind information.
2. The Deputy Commissioner & Chairman, DMMU MSRLS- EKH, EJH, EWKH, RB, SWKH, WJH,
WKH, for kind information.
3. The Project Director & Nodal Officer, DMMU MSRLS- - EKH, EJH, EWKH, RB, SWKH, WIH,
WKH, for kind information,
4. The Chief Operating Officer-LP, MSRLS for kind information.
5. The Finance & Administrative Officer, MSRLS for kind information.
6. All the State Mission Manager - MSRLS for kind information.
7. The Project Manager-KMC, YP-KMC, for kind information and necessary action.
8. All SMMU, DMMUs and BMMUs staff for kind information.
9. SMMU, DMMUs, BMMUs Notice Board, MSRLS & Website, for information.
10. The candidates concerned, for information and necessary action.
Kn
i Chief Opfrating Officer,
Meghalaya State Rt Livelihoods Society.
Ohicer
chief Opsrating rr is Soclety
taya State Rural Live
Maghataye SS stillone

<!-- page 2 -->

me
- s ~
(48D) . GOVERNMENT OF MEGHALAYA i eS ;
MEGHALAYA STATE RURAL LIVELIHOODS SOCIETY aN >
(The Nodal Agency of Govt. of Meghalaya for Implementing NRLM, Ministry of Rural Development, Govt. of India)
Montfort Building, 2! Fioor, Dhanketi, Shillong-793001
(S: msris2011@gmait.com &: msris.nic.in B-0364-2502130
EE
MSRLS/SMMU/HR/D-REC/2157/26-27/ 5322 - (B Dated: Shillong the 1% October, 2026
ANNEXURE - I: Registration Number of Shortlisted candidates for appearing the Written
Examination:
A.
a=
NO. CANDIDATES = No CANDIDATES
AMBIANGMIKI S MEBANSHANLANG
KHARSHIING
NONGHULOO
LAMIN
B, Post: Young Professional- Food, Nutrition, Health & Wash (ENHW):
NO CANDIDATES NO CANDIDATES
MAWLONG.
NONGKYNRIH | 2100014 | PURNIMA MUKHIM___—i|
KHARKONGOR
SHYLLA
MAITSHAPHRANG NIL
eee
oe ON
“S) 2, (o
a.
a gay tk Nay Chief! ating Officer,
Bl ese 3 Meghalaya State Rurdl llivelihoods Society.
“ [a Officer
oY Chief Oper eltoods Secely
VP *, State Rural Live!
+> Meghalaya F
* SON? Shillong

<!-- page 3 -->

c
y2>
G&D) = GOVERNMENT OF MEGHALAYA i eS 3
MEGHALAYA STATE RURAL LIVELIHOODS SOCIETY weer
(The Nodal Agency of Govt. of Meghalaya for Implementing NRLM, Ministry of Rural Development. Govt. of India)
Montfort Building, 2-4 Floor, Dhanketi. Shillong-793001

[Bi msrts2011@gmail.com EE msris.nic.in 8 :0364-2502130
MSRLS/SMMU/HR/D-REC/2157/26-27/ 53 32- C Dated: Shillong the 1* October, 2026

ANNEXURE - Il: Registration Number of Shortlisted candidates for appearing the Written

Examination & Skill Test (Practical):
C. Post: District Accounts Assistant:

|___3100007 | DAKANIPAIA PYRTUH
<a hte LiVer

ef hn (a

7) ao a la

2{ oe 2 Chief Operating Officer,

eA aaa Ij Meghalaya State RufallLivelihoods Society.

Sy, ing Officer
Qy e hel oat Pert welods Society
+ sHUe Megheley Shillong

<!-- page 4 -->

bd _
AGES, a GOVERNMENT OF MEGHALAYA i CH 3
MEGHALAYA STATE RURAL LIVELIHOODS SOCIETY * weave
(The Nodal Agency of Govt. of Meghalaya for Implementing NRLM, Ministry of Rural Development, Govt. of India)
Montfort Building, 2~! Floor, Dhanketi. Shillong-793001
(i: msris2011@gmail.com &: msris.nic.in 8 :0364-2502130
Neen e a ee eee
ADMIT CARD FOR RECRUITMENT FY:2026-27
REGISTRATION NUMBER:
POST NAME: Paste recent passport
NAME OF CANDIDATE: size photograph
and Sign across the
DATE OF BIRTH: photo.
VENUE:
TIME OF THE EXAMINATION
MORNING SESSION 10:30 AM - 12:30 PM
|_____EVENINGSESSION | 2:00PM- 4:00PM
GENERAL INSTRUCTION FOR THE CANDIDATE
1. Candidates must carry this admit card to the examination centre without fail.
2. Entry will not be permitted without a valid photo ID proof (e.g., Aadhaar Card, Passport,
Driving License, etc.).
3. Candidates should reach the examination centre at the mentioned reporting time.
4. No entry shall be entertained after the examination starts.
5. No electronic gadgets (mobile phones, calculators, smartwatches, etc.) are allowed inside
the examination hall.
6. Candidates must follow all instructions given by the invigilator during the examination.
7. Use only blue/black ballpoint pen unless specified otherwise.
8. Any form of malpractice or misconduct will lead to disqualification.
9. Candidates must sign the attendance sheet in the presence of the invigilator.
10. Rough work should be done only in the space provided in the question booklet or sheet
provided.
11. Candidates are permitted to leave the Examination Hall only after 1 hour of the start of
the Exam
12. Candidates who are currently employed must produce a No Objection Certificate (NOC)
from their present employer at the time of certificate verification to be permitted to
appear for the interview.
13. Candidates are advised to keep this admit card safe until the completion of the
recruitment/examination process.
Recruitment Details | Date _| Candidate's Signature | _Invigilator’s Signature _|
ee a es
Skill Test/ Rural
Attachment Test.
[renonainoriew PP
Page 1of 1
