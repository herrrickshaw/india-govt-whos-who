---
doc_id: "33b5bedca4db6e0d"
source_url: "https://meghealth.gov.in/news/2026-09-11-DHSMER-Estt-Para-Med-44-2026-5614.pdf.pdf"
ministry: "Health and Family Welfare Department, Meghalaya"
title: "Notification - List of Selected Candidates to Study in Paramedical/Allied Courses in seats allotted to the State of Meghalaya for the academic session 2026-27"
date: ""
pages: 4
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "24df594552d8d27f"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
OFFICE OF THE DIRECTOR OF HEALTH SERVICES
MEDICAL EDUCATION & RESEARCH (DME), MEGHALAYA,
PASTEUR HILLS, SHILLONG
Email ID:dmeshillong@gmail.com Tel.Ph.No.: 0364 2591510/
No.DHSME&R/Estt/Para-Med/44/2026/56 14 Dtd. Shillong, the 11" September, 2026
NOTIFICATION
In pursuance of the Government order vide No. Health.163/2026/Pt/15, dated 11" September 2026, the
Director of Health Services, Medical Education & Research is pleased to publish the list of Selected
Candidates to study in Paramedical/A lied Courses in the institution shown against each candidate with respect
to seats allotted to the State of Meghalaya for the academic session 2026-2027.
SI.
“Mt — conse
1. EMIKA SARIANG Khasi & 99.44% 98.91% | BPHAR | pipans
Jaintia M
JOLLIFY SUJA 98.60% | 98.00% | BPHAR |  pipans
Jaintia M
Khasi &
3. ELEAZER TLANG Taintia 92.50% 90.60% B.OPT RIPANS
ADIAM MUKHIM Khas & 88.30% 85.00% | BMRIT RIPANS
5s. | RIAKADKHAR Khasi & | 530% | 83.00% | BAsLp | RIMS.
Jaintia Imphal
lo. | AMAN BANIA 35.30% | 93.00% | PPAAR |  pupsar
WAITING LIST
| ame sm | om [| |_|
MAFIA AKHTAR 84.66% | 82.00% | - |  - ‘|
RASIDUL AHMED 84.33% | 82.00% [= | = |
Khasi & Jaintia Catego
SI.
PCB/PC | PCBE/PC
Conese
oO.
Khasi &
MANTIKORTI MYLLIEM Taintia 83.38% | 86.00% | BMLS RIPANS
2 | LANIARIKA TYMTHAI Khasi & 1 33.90% | 85.25% | BMLT | RIMS.
Jaintia Imphal
WINNERSON DHAR Masi & 81.66% | 83.50% | BMLS | RIPANS
LASKY DKHAR 81.30% | 81.00% RIPANS
Jaintia
Page | 1

<!-- page 2 -->

Khasi & Jaintia Catego:
Sl.
PCB/PC | PCBE/PC

SS] me | caeery Coes
ILAPYNSUK SYNREM Khasi & | g1.00% | 78.25% BPMAR | RIPSAT
| | DEIBORMI RNGAD Mhasi & | g0.30% | 79.50% pe
DAFI TARIANG 79.60% | 79.00% | BMRIT | RIPANS
| | RIMEKA NONGRUM 79.00% | 80.00% RIPANS
| RAPHAEL SWER 73.30% | 77.20% | BRIAR)  pupsar
|| MAYA EMIKA SUSNGI Khasi ©) 78.00% | 80.00% RIPANS
LABET WANNIANG 77.60% | 81.25% RIPANS
SARADAPHI SUTING 76.60% | 78.50% | BRIAR)  pipsar
13.|___ NABALASUKLANG Khasi & DPHAR| AMC,
ba ee 7330% | 9028%
PHIDAMUT GYMPAD 75.00% | 79.50% |PDAVAR|  Ripsat
15. Khasi & DPHAR| AMC,

Khasi & DPHAR| AMC,
IDAHUNSHISHA POHTMI 73.33% | 70.25% Pf
EPORCHICHIA SYIEM Khasi fe 73.00% | 77.75% Po ft
IBANYLLA BAREH Khasi & |) 72.33% | 76.25% Po ft
ISANIDA WAR pn 72.00% | 75.00% Po ft
Garo Category
Some [te ow a cosee
CANO WACHIO 80.67% | 79.00% | BRHAR |  Ripans
GRAHAM SANGMA 80.00% 71.15% BMRIT RIPANS
RIKCHIMCHI MOMIN 78.67% | 78.00% | BAAR
NINO MARAK 76.00% | 76.75% | BEAR |  pipsat
SAINTWANT SANGMA 76.00% 75.50% BMLS RIPANS
| 6. | SNESHA MOMIN B.67% 77.00% RIPANS

Page | 2

<!-- page 3 -->

Garo Category
SL.
No Categor | PCB/PC | PCBE/PCM Course College
y M E
SAN OMALGRING 73.67% | 74.50% | BOPT |  RIPANS
I | MIMICO MARAK 73.67% | 73.50% | BMLT | RIMS,
| ENDRICASH MARAK 71.67% | 67.25% | BFAAR | pupsar
| 10. | REBIKHA MOMIN 70.33% 72.15% RIPANS
1. | ABRIO SANGMA Garo | 70.33% | 68.50% | DPHAR | — AMC,
M Dibrugarh
12. D.PHAR AMC,
13. D.PHAR AMC,
14. | DANORAIS A SANGMA Garo | 66.30% | 66.50% | DPHAR | AMC,
M Dibrugarh
15. D.PHAR AMC,
KAMBECHI MARAK Garo | 62.30% | 62.00% | DPHAR | — AMC,
M Dibrugarh
MIMAKIMCHI MARAK 2.00% | 64.25% | PPAR |  pupsar
WAITING LIST
[1. | CHIGRIKESA SANGMA 60.70% 62.60% | - | - |
DEGAME MARAK 60.67% | 64.25% |  - | = |
3. | SALJAME ROKIME
ARCHIE MARAK 59.30% | 63.75% | - |  - |
SC/OST Catego:
| 1. | DEBOJIT SAHA SC/OST | 79.66% 83.50% AMC, Dibrugarh
TAPOTI KOCH SC/OST | 78.60% 71.00% RIPANS
[1. [APU DAS SC/OST | 74.66% 76.50% | - |  - |
KABITA KOCH SC/OST | 73.30% 77.50% | - | - |
KRITIKA HAJONG SC/OST | 69.30% 65.25% | - [| - |
The selected candidates are directed to download the Nomination Letter from the official e-mail id:
dmeshillong@gmail.com and proceed to the allotted institute for completion of the admission process
positively — on or before 15" September 2026.
Selected candidates who fail to report for the admission process on the allotted date i.e. 15"" September 2026,
will forfeit the seat automatically.
The above seat with then be allotted to the next candidate on the waiting list.
Page | 3

<!-- page 4 -->

After completion of the admission process, a letter of acceptance duly signed by the candidate is to be
submitted at the office of the Directorate of Health Services (Medical Education & Research), Health
Complex, Red Hill Road, Laitumkhrah during office hours within 10 days of completion of admission.
For any queries contact dmeshillong@gmail.com or +91-9485 106663. ie
Director of Health Services
Medical Education & Research (DME),
Meghalaya, Shillong
SIO I kr
M.No.DHSME&R/Estt/Para-Med/44/2026/5614-A Dtd. Shillong, the 11"
Sept., 2026
Copy to:-
1. The Under Secretary to the Government of Meghalaya, Health & Family Welfare Department for
information. ;
2. The Director of Information & Public Relations, Meghalaya, Shillong for kind publication in the print
and electronic media for information of concerned.
3. The Director of Health Services (MI), Meghalaya, Shillong for information.
4. The Director of Health Services (MCH&FW), Meghalaya, Shillong for information.
5. The State Informatics Officer, National Informatics Centre, Meghalaya State Centre, Shillong with a
request to upload the list in the Government website for information of all concerned.
UU of Health Services
Medical Education & Research (DME),
Meghalaya, Shillong
2 OR tok
Page | 4
