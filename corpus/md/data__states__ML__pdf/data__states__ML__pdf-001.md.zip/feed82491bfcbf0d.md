---
doc_id: "feed82491bfcbf0d"
source_url: "https://megartsculture.gov.in/tenders/DAC-ARCH-SL-6-2019-Pt-III.pdf"
ministry: "Arts and Culture Department, Meghalaya"
title: "Inviting Tender for Supply, Installation, Testing and Commissioning of Stage Lighting, Stage Craft System, Audio and Video System for Little Theatre and the Black Box Theatre at SICPAC, Shillong � RFPNO.DCA/ARCH/SL/6/2019/Pt.III/48 dated 15.09.2021"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "314c7c02025f957f"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
DIRECTORATE OF ARTS & CULTURE:: MEGHALAYA, SHILLONG
NO.DCA/ARCH/SL/6/2019/Pt.III/
dated Shillong, the 18th October 2021
FURTHER NOTICE
Inviting Tender for Supply, installation, Testing and Commissioning of Stage
Lighting, Stage Craft System, Audio and Video System for Little Theatre and the Black Box
Theatre at SICPAC, Shillong vide RFPNO.DCA/ARCH/SL/6/2019/Pt.III/48 dated
15.09.2021, all prospective bidders are hereby informed that the last date of bid submission
has been extended to 25th October, 2021 before 3 PM due to the declaration of the Model
Code of Conduct (MCC) in view of the bye election to Meghalaya Legislative Assembly
2021.
All others terms and conditions shall remain unchanged.

.
