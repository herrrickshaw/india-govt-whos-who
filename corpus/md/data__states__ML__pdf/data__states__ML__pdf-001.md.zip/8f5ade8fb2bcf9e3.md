---
doc_id: "8f5ade8fb2bcf9e3"
source_url: "https://megartsculture.gov.in/documents/not-2026.pdf"
ministry: "Arts and Culture Department, Meghalaya"
title: "Request For Proposal (RFP) for 'Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer (DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public Private Partnership (PPP) Basis, at Mawkasiang, New Shillong,"
date: ""
pages: 90
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6f02b8d23c96d994"
---

<!-- page 1 -->

<!-- page 2 -->

ARTS AND CULTURE DEPARTMENT
GOVERNMENT OF MEGHALAYA

invites

REQUEST FOR PROPOSAL (RFP)
for

Development, Operation and Management of 5 Star Resort under
Design, Build, Finance, Operate and Transfer (DBFOT) Model, along with
the Operation and Maintenance of the Lariti Performing Centre on a
Public–Private Partnership (PPP) Basis, at Mawkasiang, New Shillong,
Meghalaya

February 2026

(This document is meant for exclusive purposes of submitting the proposal against this RFP document and shall
not be transferred, reproduced or otherwise used for purposes other than that for which it is specifically issued)

<!-- page 3 -->

Volume 1:
Instructions to Bidders (ITB)

<!-- page 4 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

DISCLAIMER
The information contained in this Request for Proposal (RFP) document or subsequently provided to Bidders,
whether verbally or in documentary form by or on behalf of Arts & Culture Department, Government of
Meghalaya or any of its employees or advisors (herein referred to as “Authority”), is provided to
“Bidders/Applicants” on the terms and conditions set out in this RFP document and any other terms and conditions
subject to which such information is provided.
The RFP contains brief information about the project for the Development, Operation and Maintenance of 5 Star
Resort under Design, Build, Finance, Operate and Transfer (DBFOT) Model, along with the Operation and
Maintenance of the Lariti Performing Centre on a Public–Private Partnership (PPP) Basis, at Mawkasiang, New
Shillong, Meghalaya (herein referred to as “Project”), by a private participant being the Selected Bidder /
Concessionaire selected through a competitive Bidding Process. The purpose of this RFP is to provide the Bidder(s)
with information that may be useful to them in the formulation of their bids (including Financial Bids) (the “Bids” or
“Proposal”) pursuant for this RFP and for no other purpose.
This RFP document is not a contract and is not an offer or invitation to any other party. The purpose of this RFP
document is to provide the Bidders with information to assist the formulation of their proposal submission. This
RFP document does not purport to contain all the information each Bidder may require. This RFP document may
not be appropriate for all persons, and it is not possible for the Authority and their employees or advisors to
consider the investment objectives, financial situation and particular needs of each Bidder. Certain Bidders may
have a better knowledge of the proposed Project than others. Each recipient must conduct its own analysis of the
information contained in this RFP document or to correct any inaccuracies that may appear in this RFP document
and is advised to carry out its own investigation into the proposed Project, the legislative and regulatory regimes
which apply thereto and by and all matters pertinent to the proposed Project and to seek its own professional
advice on the legal, financial, regulatory and taxation consequences of entering into any contract or arrangement
relating to the proposed Project.
Information provided in this RFP to the Bidder(s) is on a wide range of matters, some of which may depend upon
interpretation of law. The information given is not intended to be an exhaustive account of statutory requirements
and should not be regarded as a complete or authoritative statement of law. The Authority accepts no
responsibility for the accuracy or otherwise for any interpretation or opinion on law expressed herein.
The possession or use of this RFP in any manner contrary to any applicable law is expressly prohibited. The Bidders
shall inform themselves concerning, and shall observe, any applicable legal requirements. The information does not
purport to be comprehensive or to have been independently verified. Nothing in this RFP shall be construed as
legal, financial or tax advice.
The Authority, its employees, advisors or consultants make no representation or warranty and shall have no
liability to any person, including any Bidder under any law, statute, rules or regulations or tort, principles of
restitution or unjust enrichment or otherwise for any loss, damages, cost or expense which may arise from or be
incurred or suffered on account of anything contained in this RFP or otherwise including the accuracy, adequacy,
correctness, completeness or reliability of the RFP and any assessment, assumption, statement or information
contained therein or deemed to form part of this RFP or arising in any way for participation in this Bid Stage.
Neither the information in this RFP nor any other written or oral information in relation to the Bidding Process for
implementing the Project or otherwise is intended to form the basis of or the inducement for any investment
activity or any decision to enter into any contract or arrangement in relation to the Project and should not be relied
as such.

Volume-I: Instructions to Bidders (ITB)

3|Page

<!-- page 5 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya
The Authority its advisors/ consultants/ representatives/ employees accept no liability of any nature whether
resulting from negligence or otherwise, howsoever caused, arising from reliance of any Bidder upon the statements
contained in this RFP.
The Authority may in its absolute discretion, but without being under any obligation to do so, update, amend or
supplement the information, data, statements, assessment or assumptions contained in this RFP or change the
evaluation or eligibility criteria at any time or annul the entire Bidding Process.
The issue of this RFP does not imply that the Authority is bound to select or to appoint the Selected Bidder or
Concessionaire, as the case may be, for the Project and the Authority reserves the right to reject all or any of the
Bid or Bids without assigning any reasons whatsoever.
The Bidder shall bear all its costs associated with or relating to the preparation and submission of its Bid including
but not limited to preparation, copying, postage, delivery fees, expenses associated with any demonstrations or
presentations which may be required by the Authority or any other costs incurred in connection with or relating to
its Bid including costs relating to submission and maintenance of various fees, undertakings and guarantees
required pursuant to this RFP and also any cost relating to updating, modifying or re-submitting its Bid pursuant to
the RFP being updated, supplemented or amended by the Authority. All such costs and expenses will be incurred
and borne by the Bidder and the Authority shall not be liable in any manner whatsoever for the same or for any
other costs or other expenses incurred by a Bidder in preparation or submission of the Bid, regardless of the
conduct or outcome of the Bidding Process (hereinafter defined).
The Bidders are prohibited from any form of collusion or arrangement in an attempt to influence the selection and
award process of the Bid. Giving or offering of any gift, bribe or inducement or any attempt to any such act on
behalf of the Bidder towards any officer/employee/ advisor/ representative of the Authority or to any other person
in a position to influence the decision of the Authority for showing any favour in relation to this RFP or any other
contract, shall render the Bidder to such liability/penalty as the Authority may deem proper, including but not
limited to rejection of the Bid of the Bidder and forfeiture of its Bid Security.

Volume-I: Instructions to Bidders (ITB)

4|Page

<!-- page 6 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Table of Contents
DISCLAIMER..............................................................................................................................................3
Project Summary......................................................................................................................................8
1.

INVITATION FOR PROPOSAL ................................................................................................ 13

1.1

Introduction ................................................................................................................................... 13

1.2

Schedule of Bidding Process ......................................................................................................... 14

1.3

Pre-Bid Conference........................................................................................................................ 15

1.4

Authority’s Authorized Representative........................................................................................ 15

2.

PROJECT DETAILS .................................................................................................................. 16

2.1

Project Overview ........................................................................................................................... 16

2.2

Business Potential: Hospitality & MICE facilities - Tourism Industry .......................................... 16

2.3

Project Description & Site Appreciation ....................................................................................... 21

2.4

Implementation Schedule ............................................................................................................. 25

2.5

Key Terms ...................................................................................................................................... 25

2.6

Bid Variable ................................................................................................................................... 25

2.7

Pay-outs to the Authority ............................................................................................................. 25

3.

INSTRUCTIONS FOR BIDDING .............................................................................................. 28

A. General................................................................................................................................................. 28
3.1

General Terms of Bidding.............................................................................................................. 28

3.2

Qualification / Shortlisting of Bidders .......................................................................................... 30

3.3

Proposal submitted by a Consortium ........................................................................................... 36

3.4

Change in Ownership .................................................................................................................... 38

3.5

Number of Bids and costs thereof ................................................................................................ 39

3.6

Site visit and verification of information ...................................................................................... 39

3.7

Verification and Disqualification .................................................................................................. 40

3.8

Right to accept or reject any or all Bids/ Bids .............................................................................. 41

B. Documents ......................................................................................................................................... 41
3.9

Contents of the RFP ....................................................................................................................... 41

3.10

Clarifications .................................................................................................................................. 42

3.11

Amendment of RFP ....................................................................................................................... 42

C. Preparation and Submission of Bid ............................................................................................. 43
3.12

Language ........................................................................................................................................ 43

3.13

Format and signing of Bid ............................................................................................................. 43

3.14

Sealing, Marking and Submission Proposals /Bids ...................................................................... 43

3.15

Late Bids......................................................................................................................................... 45

Volume-I: Instructions to Bidders (ITB)

5|Page

<!-- page 7 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

3.16

Modifications/ Substitution/ Withdrawal of Bids ....................................................................... 46

3.17

Rejection of Bids ............................................................................................................................ 46

3.18

Validity of Bids............................................................................................................................... 46

3.19

Confidentiality ............................................................................................................................... 46

3.20

Correspondence with the Bidder .................................................................................................. 47

D. Bid / Proposal Security................................................................................................................... 47
3.21

Bid / Proposal Security .................................................................................................................. 47

3.22

Performance Security .................................................................................................................... 47

3.23

Proprietary data ............................................................................................................................ 48

4.

EVALUATION OF BIDS ............................................................................................................ 49

4.1

Opening and Evaluation of Bids .................................................................................................... 49

4.2

Tests of responsiveness................................................................................................................. 50

4.3

Selection of Bidder ........................................................................................................................ 50

4.4

Avoidance of Contact during Bid Evaluation ................................................................................ 51

4.5

Bids of other Bidders ..................................................................................................................... 52

5.

FRAUD AND CORRUPT PRACTICES ................................................................................... 53

5 Fraud and Corrupt Practices ................................................................................................................. 53
6.

PRE-BID CONFERENCE .......................................................................................................... 55

7.

MISCELLANEOUS ..................................................................................................................... 56

8.

APPENDICES.............................................................................................................................. 57

APPENDIX-A. Letter of Bid & Interest ...................................................................................................... 57
APPENDIX-B. General Information of the Bidder .................................................................................... 61
APPENDIX-C. Affidavit .............................................................................................................................. 63
APPENDIX-D. Power of Attorney ............................................................................................................. 64
APPENDIX-D-1: Format for Power of Attorney for Authorized Signatory ............................................... 64
APPENDIX-D-2: Format for Power of Attorney for Lead Member of the Consortium ............................ 66
APPENDIX-E: Minimum Eligibility Criteria ................................................................................................ 69
APPENDIX-E-1: Bid Response Sheet 1 ....................................................................................................... 70
Format for Technical Capacity .................................................................................................................. 70
Technical Capacity: CRITERIA: A- Bidder with HOSPITALITY EXPERIENCE ............................................... 70
APPENDIX-E-1: Bid Response Sheet 2 ....................................................................................................... 71
Format for Technical Capacity .................................................................................................................. 71
Technical Capacity: CRITERIA: B – Bidder with CONSTRUCTION EXPERIENCE and Tie-up with Operator
from Hospitality Sector ............................................................................................................................. 71
APPENDIX-E-2: Bid Response Sheet 2 ....................................................................................................... 75

Volume-I: Instructions to Bidders (ITB)

6|Page

<!-- page 8 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Format for Financial Capacity ................................................................................................................... 75
Financial Capacity ...................................................................................................................................... 75
APPENDIX-E-3: Bid Response Sheet 3 ....................................................................................................... 77
Certificate from the Statutory Auditor regarding Associate ................................................................... 77
APPENDIX-F: Acknowledgement Letter.................................................................................................... 78
APPENDIX-G: Acknowledgement Letter ................................................................................................... 79
APPENDIX-H: Format for Bid Security (Bank Guarantee) ........................................................................ 80
APPENDIX-I: Draft Consortium/ Joint Bidding Agreement ...................................................................... 82
APPENDIX-J: O & M Undertaking.............................................................................................................. 87
APPENDIX-K: Format for Financial Proposal ............................................................................................ 88

Volume-I: Instructions to Bidders (ITB)

7|Page

<!-- page 9 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Project Summary
Sl No

Parameters

Details

1.

Project Title

Development, Operation and Management of 5-star Resort under Design,
Build, Finance, Operate and Transfer (DBFOT) Model, along with the
Operation and Maintenance of the Lariti Performing Centre on a Public–
Private Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya.

2.

Land Area

3.

Project Scope
(Refer Section 2
for details)

1. For 5-star Resort Development – 9.5 acres
2. Lariti Performing Centre – 8.5 acres (Constructed and being
operated by Arts & Culture Dept., Govt. of Meghalaya)
This RFP is floated for selection of Concessionaire for Development,
Operation and Management of 5 Star Resort under Design, Build, Finance,
Operate and Transfer (DBFOT) Model, along with the Operation and
Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya..
Scope of work for the Project entails:
1. Development, Operation and Management of 5 Star Resort under
Design, Build, Finance, Operate and Transfer (DBFOT) Mode on PPP.
► Development of a minimum 5-star Resort with minimum 100 keys
and ancillary facilities as per applicable development norms and
regulations and in adherence to the standards of Resort & Restaurant
Approval Classification Committee (HRACC), Ministry of Tourism,
applicable to a 5 Star Category Resort facility or above.
► Obtaining and maintaining accreditation of minimum 5 Star Resort
category facilities or above, from Ministry of Tourism, Government of
India and ensuing that facilities are maintained as per the category
throughout the Concession Period.
► Financing for development, operation and maintenance of the Project
► Undertake Operation & Maintenance of the Project for the
Concession Period and transfer the property on transfer date.
► Obtaining all approvals as may be required for the implementation
and operation & maintenance of the Project.
► Compliance with all applicable rules, regulation, stipulations and
guidelines as applicable and amended from time to time.
2. Operation, Management, Maintenance and Transfer of Lariti
Performing Centre
► The Lariti Performing Centre shall be utilized to its fullest potential for
MICE activities, conventions, and related events, and shall form an
integral part of the proposed Resort development.
► To undertake Operation, Management and Maintenance Lariti
performing centre as per the terms laid down in the Concession

Volume-I: Instructions to Bidders (ITB)

8|Page

<!-- page 10 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Sl No

Parameters

Details
Agreement
► The following is built up area statement of Lariti performing centre

Area statement
Land Area (Acre)

8.5

Total BUA (Sq.M)

25,000

Built up area statement (Sq.M)
Basement

348.13

Lower Ground Floor 1

8255.48

Lower Ground Floor 2

3294.19

Gound Floor

6145.64

First Floor

4093.88

Second Floor

2536.27

Terrace

208.85

3. The following facilities are available in Lariti performing centre
► Multipurpose Theatre -1749 Pax
► Black Box – 574 Pax
► Small Theatre – 302 Pax
► Open Air Theatre – 15000 Pax
► A contemporary Art Gallery,
► A Sky Theatre,
► A Special Exhibitions Space,
► VIP Banquet Hall, VIP Lounge, VIP Restroom, VIP Enclosure Area
► Auditoriums
► Meeting rooms
► Automated elevators
► Tribal Museum
► A Media Centre
► Television & AV Studio
► Library
► Food Court and administrative workspace
4.

Authority

Arts and Culture Department, Government of Meghalaya

5.

Implementation
Public Private Partnership (PPP)
Format

6.

Concession
Format

7.

Institutional
Structure for

Design-Build-Finance-Operate-Transfer (DBFOT)
The Selected Bidder (single entity or consortium of entities), shall
undertake to incorporate a Special Purpose Vehicle (SPV) under the
Companies Act, 2013 as such prior to execution of the Concession

Volume-I: Instructions to Bidders (ITB)

9|Page

<!-- page 11 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Sl No

Parameters

Details

Implementation Agreement (the “Concessionaire”) that shall be exclusively responsible for
designing, engineering, financing, procurement, construction, marketing,
operation, management and maintenance of the Project under and in
accordance with the provisions of the Concession Agreement, to be
entered into between the Concessionaire and the Authority.
8.

Term of the
Agreement
(Concession
Period)

The Concession Period shall be 60 (Sixty) Years from the Appointed Date
which includes Three Years for construction/development of the 5-star
Resort.

9.

Minimum
Development
Obligations
(MDOs)

The Minimum Development Obligation shall include development of a
Resort with minimum 100 keys (adhering to the minimum standards of a 5
Star Category Luxury Resort) with all ancillary amenities including Rooms,
Restaurants, Cafes, Spa, Swimming Pool, and other facilities as applicable
within 36 (thirty-six) months from the Appointed Date as per the
specifications provided in the Concession Agreement.

10.

Consortium
(Refer Clause
3.3 for details)

Maximum 3 members (including the Lead Member)

Appointed Date

► The date of issuance of Certificate of Compliance after fulfilment of

11.

The Concession Period may be extended subject to satisfactory
performance of the Concessionaire and terms and conditions as stipulated
in the Concession Agreement and at the sole discretion of the
Concessioning Authority.

Conditions Precedent by both the Parties. The Certificate of
Compliance if issued at two different dates, the issuance of the
certificate at later date shall be reckoned as Appointed Date.
► Appointed Date shall be achieved within 180 (one hundred and eighty)
days of date of signing of Agreement, subject to extension as per
terms of Article 4 of Draft Concession Agreement.
12.

Selection
Process (Refer
Clause 4.1 for
details)

Step 1 – Assessment of Technical Capacity and Financial Capacity to
determine Technically Qualified Bidders (Detailed process outlined in
Clause 4.1)

13.

Bid Variable
(Refer Clause
2.6 for details)

Bidder quoting maximum Revenue Share over and above the minimum
threshold shall be declared as successful bidder.

14.

Financial
Covenants

Non-Refundable Bid Document Fee (Payable online):

Step 2 – Financial Proposals of only Technically Qualified Bidders shall be
opened to select the Successful Bidder

Volume-I: Instructions to Bidders (ITB)

10 | P a g e

<!-- page 12 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Sl No

Parameters

Details

(Refer Clause
3.21 for details)

INR 85,000/- (Rupees Eighty-Five Thousand Only)
Bid / Proposal Security:
INR 85 Lakhs (Rupees Eighty-Five Lakhs Only)
Performance Security:
The Successful Bidder must furnish Performance Securities before signing
the contract in the manner as mentioned below:
► From the date of execution of the Contract till COD (Commercial

Operations Date): INR 8.5 Crores with validity of 60 (sixty) days
beyond the Construction/Development period
► From COD till expiry of Concession Period: INR 3 Crore with validity of
60 (sixty) days beyond the Concession Period
Note: Performance Security of Concession Period shall be renewed and
escalated every 5 years based on WPI of every fifth year.
15.

16.

Estimated
CAPEX
(Estimated
Project Cost)
Consideration
to Authority

Estimated CAPEX: INR 85 Crore

Described in detail in Clause 2.7
➢ One-time Upfront Premium – Rs 12.5 Crores (Indian Rupees twelve
crore and fifty lakhs only)
➢ Annual Concession Fee - INR 1 Lakh escalated @ 10% in every three
years
➢ Annual Lease Rental – INR 12,50,000/- (Indian Rupees twelve lakhs and
fifty thousand only) which is 1% of Upfront Premium. The Annual Lease
Rent shall be escalated by 10% in every 3 years.
➢ Revenue Share - Percentage of Gross Revenue for each accounting
year which shall be considered as Bid Variable/Bid Parameter to select
bidder (must not be less than 4% which is the Reserve Price). The
Bidder has to quote a revenue share over and above the threshold of
4% of Gross Revenue for each Accounting Year.
➢ The Government may book facilities at the Lariti Performing Centre for
a maximum of 45 days per year free of facility charges. Food &
Beverage (F&B) expenses shall be paid as per actuals.

Applicable facilities:

Volume-I: Instructions to Bidders (ITB)

11 | P a g e

<!-- page 13 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Sl No

Parameters

Details
▪
▪
▪
▪
▪

Multi-Purpose Theatre
Blackbox Theatre
Little Theatre
Open Air Theatre
Auditorium, Meeting rooms etc.

➢ If the Government requires any of the facilities beyond the 45 free days
in a year, the applicable hall charges shall be paid as per the rates fixed
by the concessionaire at that time.

Note: Capital subsidy and various incentives under Meghalaya Industrial &
Investment Promotion Policy (MIIPP)-2024 and Uttar Poorva
Transformative Industrialisation Scheme (UNNATI)-2024 shall be
applicable to the project.

Volume-I: Instructions to Bidders (ITB)

12 | P a g e

<!-- page 14 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

1. INVITATION FOR PROPOSAL
1.1

Introduction

1.1.1

Meghalaya, the abode of clouds, is known to be one of the richest biodiversity areas in the
world. The famed monsoons, the rich traditional festivals, and the dramatic terrain are just
some of the many things the state is famous for. The state is endowed with lofty mountain
ranges with interplay of lush green valley, cascading rivers, sprawling water bodies,
waterfalls, caves, and living root bridges. Meghalaya has two national parks and three
wildlife sanctuaries. Shillong is Meghalaya’s state capital and the main cultural hub. It is a
microcosm of the entire North-East region with its status as a regional academic nerve
centre – home to a young, creative, and aspiring population. The charm of the old hill town
still resonates, and its culture and landscape provide a perfect blend of modern world and
deep tradition. Bustling cafes and restaurants dot its commercial centers, and the town is
also a wonderful stop for avid shoppers. The city’s nightlife attracts revellers and live music
venues provide the stage for many a famous local and international musician.

1.1.2

The Arts and Culture Department, Government of Meghalaya has the mandate to develop,
operate and manage a 5-star Resort on a contiguous land measuring 9.5 Acres at
Mawkasiang, New Shillong. They intend to carry out this development on a Public Private
Partnership (PPP) mode. The site also includes the Lariti Performing Centre, built over 8.5
Acres of land with all modern infrastructure and facilities. The Government intends to
capture the operation and maintenance of this cultural centre in the same PPP contract and
offer a composite proposal to the PPP partner. The prime reason for proposing this concept
is the complementing infrastructure among the assets.

1.1.3

The Authority shall carry out a transparent competitive bid process for selection of the
Private Sector Partner for the project.
This Request for Proposal (RFP) is for the selection of developer for “Development,
Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and
Transfer (DBFOT) Model, along with the Operation and Maintenance of the Lariti
Performing Centre on a Public–Private Partnership (PPP) basis, at Mawkasiang, New
Shillong, Meghalaya” (the “Project”) for a Concession Period of Sixty (60) years from the
Appointed Date.

1.1.4

1.1.5

A “Single-Stage Two-Envelope” Bidding Process is to be followed for determining the
Selected Bidder for the Project:
Step 1 – Qualification and Shortlisting
The Bidders are required to meet the Minimum Eligibility Criteria, as set out in Section 3.2.6
of this RFP document, to qualify for the Project (“Technically Qualified” Bidder).
Step 2 – Financial Proposal Evaluation and Selection
The Financial Proposal of the Technically Qualified Bidders would be opened and evaluated. The
Technically Qualified bidder quoting the highest bid variable shall be declared as the Selected
Bidder.
The Bid Document for the Project shall comprise of the Instruction to Bidders (ITB), Draft

Volume-I: Instructions to Bidders (ITB)

13 | P a g e

<!-- page 15 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Concession Agreement (DCA), Schedules to Draft Concession Agreement and any
subsequent addendum or corrigendum issued by the Authority thereof. This ITB contains
information about the Project, bid evaluation process, proposal submission details and
qualification requirements. All proposals would be evaluated in terms of financial and
technical capability of the Bidder.
1.1.6

Interested
Bidders
may
download
the
Bid
Documents
from
https://meghalayatenders.gov.in/. A non-refundable fee of INR 85,000/- (Rupees EightyFive Thousand Only) to be paid through online. Bids unaccompanied with the Bid Document
Fee or a receipt of payment thereof shall be liable to rejection by the Authority.

1.1.7

The Technical Proposals shall be submitted in hard copy. The hard copy of Technical
Proposals must be in the manner specified in the RFP document at the address given below:
To,
The Director
Directorate of Arts & Culture
Government of Meghalaya
I.G.P. Point, Ground Floor of the State Central Library Complex, Shillong, Meghalaya 793001
Phone No: +91 9774281282
E-mail : artsandculturemegh@gmail.com

1.1.8

The Technical Proposal and the Financial Proposal are jointly termed as “Proposal/s in this
RFP. The Authority shall not be responsible for any delay in receiving the Proposals and
reserves the right to reject / accept any or all Proposals without assigning any reason
thereof.

1.1.9

The Selected Bidder shall, prior to execution of the Concession Agreement (the “Concession
Agreement”), incorporate as per the terms of this RFP, an appropriate Special Purpose
Vehicle (the “SPV”) under the Companies Act, 2013 to execute the Agreement and
implement the Project and such SPV (the “Concessionaire”) shall be responsible for
development, operation and maintenance of the Project under and in accordance with the
provisions of the Agreement to be entered into between the Concessionaire and the
Authority.

1.1.10 A Contract (the “Concession Agreement” or the “Agreement”) will be drawn up between
the “Authority” and the “Concessionaire” pursuant to issuance and acceptance of LOA.

1.2

Schedule of Bidding Process

Authority shall endeavour to adhere to the following schedule:
Sl No
1.
2.
3.
4.

Event Description
Start date of Downloading of RFP document
Pre-Bid Conference
Last date for receiving queries
Response to the Pre Bid Queries

Volume-I: Instructions to Bidders (ITB)

Date
13.02.2026
20.02.2026, 4:30 PM
23.02.2026, 1:00 PM
26.02.2026

14 | P a g e

<!-- page 16 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Sl No
5.
6.
7.
8.
9.
10.
11.
12.

Event Description
Start Date of Bid Submission
End Date of Bid Submission / Bid Due Date
Opening of Technical Proposal
Opening of Financial Proposals
Letter of Award (LOA)
Acceptance of LOA
Signing of Agreement between Authority & Selected
Bidder
Validity of Bids

Date
13.02.2026
06.03.2026, 1:00 PM
06.03.2026, 3:00 PM
To be announced
To be announced
To be announced
To be announced
180 Days from the Bid Due Date

Bid Due Date
Bid should be submitted on the Application Due Date (Clause 1.2), at the address provided in Clause
1.1.7 in the manner and form as detailed in this RFP.

1.3

Pre-Bid Conference

1.3.1

The date, time and venue of the Pre-Bid Conference shall be:

► Date: 20.02.2026
► Time: 4:30 PM
► Venue: Committee Room II, Main Secretariat

Shillong 793001, Meghalaya, India
► The Bidders may attend the Pre -Bid Conference at the venue mentioned above or through
Video Conference, the link of the VC shall be provided on request and also made available on
the website https://meghalayatenders.gov.in/ at least 24 hrs prior to the scheduled date and
time.
1.3.2 The minutes of the Pre-Bid Conference incorporating the clarifications shall be uploaded
online only and shall form part of this RFP document. Queries raised after last date for
receiving queries shall not be entertained.

1.4
1.4.1

Authority’s Authorized Representative
The Bidders may, during the Bid process, contact the Authority’s Authorized Representative
as below, for any clarification. However, it may be noted, that only those clarifications,
sought as per the procedure laid out in Clause 3.10, shall be answered by the Authority.
Neither the Authority, nor any of its representatives, shall be responsible for any other
verbal clarifications / communications. The Authority may be contacted, for clarifications, at
the following address through post.
To,
The Director
Directorate of Arts & Culture
Government of Meghalaya
I.G.P. Point, Ground Floor of the State Central Library Complex, Shillong, Meghalaya 793001

Volume-I: Instructions to Bidders (ITB)

15 | P a g e

<!-- page 17 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Phone No: +91 9774281282
E-mail : artsandculturemegh@gmail.com

2. PROJECT DETAILS
2.1

Project Overview

Meghalaya also known as “abode of clouds” in Sanskrit is one of India’s and a jewel for North East India.
The state is part of the seven north eastern states (known as Seven Sisters), is bounded by Assam on the
North and East and Bangladesh on the South and West. Spread over an area of 22,429 sq. kms, the state
is one of the most picturesque states of India. The panoramic landscapes, foggy hills, cascading
waterfalls, serpentine rivers and terraced slopes make the destination as a soulful tourist destination.
Gifted with incredible natural beauty Meghalaya possesses great tourism potential.
Shillong is the capital city of Meghalaya as well as the District Headquarter of East Khasi Hill District. The
name Shillong is derived from U-Shyllong, a powerful deity and is situated at an altitude of 1,491m
above sea level. The presence of many well reputed educational institutions, many of them established
by various missionary groups make Shillong the hub of education for the entire north- east.
The Arts & Culture Department, Government of Meghalaya had developed the high-end and modern
Lariti Performing Centre over 8.5 Acres of land at Mawkasiang, New Shillong. The Centre was
inaugurated in November 2022 and around 70 events have already taken place at the performing
centre. The Department also intends to develop a 5-star Resort/Resort over 9.5 Acres adjoining the
centre. The Department intends to develop the project on a Public Private Partnership (PPP) mode and
include the operation and maintenance of the Lariti Performing Centre within the same PPP contract.
Accordingly, the Arts & Culture Department, Government of Meghalaya is taking up the project for
“Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate
and Transfer (DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing
Centre on a Public–Private Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya”.

2.2

Business Potential: Hospitality & MICE facilities - Tourism Industry

2.2.1 The global tourism industry: an overview
Tourism sector remains a key contributor to the global economy
The tourism sector globally has emerged as a key contributor to economic and social growth. As per
World Travel and Tourism Council (WTTC), the travel and tourism industry accounted for nearly 10.3%
of global GDP and 330 million jobs, or one in 10 people in 2019. The sector grew by 3.5% in 2019, a rate
higher than that of the global economy for the ninth consecutive year, thereby enriching local
communities at a faster rate than many other sectors.
Over the past ﬁve years, as many as one in four new jobs created across the world has been in travel
and tourism. The tourism estimates for FY23 indicates strong rebound in terms of tourism arrivals as
well as receipt.

Volume-I: Instructions to Bidders (ITB)

16 | P a g e

<!-- page 18 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Source: ASSOCHAM & EY published paper
Strong recovery from the set back of pandemic observed across continents.
The tourism industry was one of the key sectors to be severely hit by the pandemic situation. However,
the sector is experiencing a recovery trend since 2023 which is expected to further strengthen in the
near future. Reliable estimates from UNWTO (nine months ending September 2023 tourism arrivals)
indicates a strong recovery from the pandemic setbacks with most destinations reaching and some even
exceeding the pre pandemic levels (see ﬁg below).

While the recovery of Asia and Paciﬁc Region is slow, it is pertinent to note that South Asia has reached
a level of 95% of the pre pandemic arrival. The relatively slow recovery in Asia/Paciﬁc is largely
attributable to West Asia. Overall, the 2023 tourism arrivals are expected be to the tune of 95% of preCOVID period.

2.2.2 The Indian tourism industry: an overview
Tourism in India remains a key sector for growth.
In 2019, travel and tourism were one of the largest sectors in the country, accounting for 6.90% of the
national GDP (US$191.3 b). However, due to the COVID-19 pandemic, the sector contribution to GDP
dropped to US$121.9 b in 2020 reﬂecting a decline of 36.3%. As per WEF’s Travel and Tourism
Development Index 2021, India is ranked 54th globally, while remaining a top performer in South Asia.
However, post pandemic the sector exhibited strong recovery trends with steady growth in tourism
footfalls and spendings. As per the Draft National Tourism Policy 2022 (July 2022) targets, the industry’s
GDP is projected to reach US$1trillion by 2047. In 2019–20, the tourism sector contributed 15% to total
jobs in India, with total jobs standing at approximately 80 million. This ﬁgure is projected to reach 400
million by 2047.

Volume-I: Instructions to Bidders (ITB)

17 | P a g e

<!-- page 19 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

2.2.3 NER tourism: key trends
The North-East Indian States are blessed with a unique blend of tourism assets and a range of tourism
offerings including wildlife tourism, tea and golf tourism, river tourism, religious and spiritual tourism,
heritage tourism, cultural and culinary tourism, adventure tourism and agro and rural tourism.
The region is a melting pot of cultures and traditions, with each state having its unique identity. This
diversity is reﬂected in the food, festivals, music, and dance of the region, making it a perfect
destination for cultural tourism. Northeast India is also home to several historical monuments and
temples, including Kamakhya Temple in Assam, which is one of the oldest and most revered shrines in
India, and the living root bridges of Meghalaya, which are a unique attraction and a testament to the
ingenuity of the local people.
The region is home to many wildlife sanctuaries like Kaziranga National Park famous for the one horned
rhinoceros, Manas National Park, Nameri, Orang, Dibru Saikhowa in Assam, Namdhapha in Arunachal
Pradesh, Balpakram in Meghalaya, Keibul Namjao in Manipur, Intanki in Nagaland, Khangchendzonga in
Sikkim. The Brahmaputra ﬂows through the length of Assam where tourists can enjoy memorable river
cruises and the ﬂowing rivers of Arunachal Pradesh which feed the Brahmaputra offering incredible
white water rafting experiences.
The sector shows strong growth story and potential of the region:
Over the previous decade, there has been a consistent growth in the inﬂow of tourists into the
Northeast States. Additionally, between 2014 and 2019, foreign tourist visits to the Northeast region
grew at a record CAGR of 26%.

Volume-I: Instructions to Bidders (ITB)

18 | P a g e

<!-- page 20 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

2.2.4 Meghalaya Tourism: Overview
According to the Economic Survey of India 2019-20, the Tourism Direct Gross Value Added (TDGVA)
share in the Gross Value Added (GVA) in the state of Meghalaya was 5.22% (in the year 2015-16). The
share of tourism employment in Meghalaya state employment was 10.44% (in the year 2015-16).
The total Capital Expenditure and Revenue Expenditure on Economic Development of Meghalaya and
the Tourism share for the 8 financial years 2016-17, 2017-18, 2018-19, 2019-20, 2020-21, 2021-22 and
2022-23 were:

Volume-I: Instructions to Bidders (ITB)

19 | P a g e

<!-- page 21 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Meghalaya is blessed with plethora of tourism assets and offers wide variety of experiences for all
categories of tourists. The State has witnessed increasing tourist footfalls, and the unique opportunities
of Meghalaya hold a lot potential waiting to be tapped. In 2019, the tourist footfall in the State stood at
about 12.7 lakhs (including 25,000 foreigners) which decreased to 1.5 lakhs in 2021 due to COVID-19.
Pre-pandemic, out of the total tourist visits in 2019, domestic tourist footfalls stood at 12,45, 633 while
the number of foreign visitors reached 25,813.
Tourism in Meghalaya has shown an increasing trend, increasing tourist footfalls is an indicator of the
achieved growth. This has been possible primarily due to:
Proximity of Shillong from Guwahati – among one of the main contributors of footfall in
Meghalaya
► The natural tourism assets of the state (more than 100 identified spots)
► Changing preferences of the tourists.
►

As per Meghalaya Tourism Policy 2023, the tourism sector plays a prominent role in providing livelihood
opportunities to almost 50,000 people in the State. Since the ban on coal mining in 2014 which
eventually resumed in 2019 (except the export of coal), tourism became one of the key contributors to
the economy of Meghalaya. It has been estimated that the sector contributes about 4.1% to the State’s
GSDP. State’s tourism budget has been steadily increasing which has led to an increase in tourist
footfalls.
The state has an abundance of forest cover ~76% with rich biodiversity (wildlife, sacred forests etc.) serene landscapes and nature experiences (falls, rivers, lakes etc.) with multiple adventure
opportunities (trekking, caving, boating etc.). Additionally, the State’s welcoming culture and low crime
rate is well appreciated by domestic and international visitors. States rich tourism assets have created a
strong pull factor for the tourists. Meghalaya has over 100 tourist spots almost half of which are in the
East Khasi Hill district.
Owing to the rich assets, the tourism landscape of Meghalaya served as an encouraging destination,
even during COVID times. The states assets, combined with the changing preferences of tourists, of
visiting off beat and serene locations, make Meghalaya an important destination on the tourism map of
India. The key drivers of the tourism potential of Meghalaya are as follows.

Volume-I: Instructions to Bidders (ITB)

20 | P a g e

<!-- page 22 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Connectivity - Meghalaya, over the years has gained popularity due to its improved connectivity and
exotic offerings. Shillong is well connected to all the major cities of the country via Guwahati which is a
little over 2 hours via road. Shillong is also directly connected to Delhi and Kolkata via direct flights .
Recognition/ Recall Value – Shillong also known as Scotland of East, is known for its picturesque
landscape, Cherrapunjee also known as Sohra & Mawsynram are known as the lands of Rain & Peace.
While the natural treks and caves also cater to the adventure tourists Wishlist. With increasing
popularity of NH7 weekender music festival, the state has been able to create of recall value among the
millennials.
Safety & Welcoming Culture: Shillong makes a welcoming destination for the tourists, especially
women and international tourists. The indigenous culture and the distinct communitarian way of life
have been a major attraction for the state.

2.3

Project Description & Site Appreciation

2.4.1 Project Location
The project site is located at Mawkasiang, New Shillong at a distance of 39.5 Kms from the Shillong
Airport.
The site includes the Lariti Performing Centre developed over 8.5 Acres of land and at a distance of 12.5
Kms from the centre of Shillong city i.e. the Police Bazar.

Volume-I: Instructions to Bidders (ITB)

21 | P a g e

<!-- page 23 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Project Site

2.4.2 The Lariti Performing Centre

Volume-I: Instructions to Bidders (ITB)

22 | P a g e

<!-- page 24 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Infrastructures Available at LARITI

Volume-I: Instructions to Bidders (ITB)

23 | P a g e

<!-- page 25 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Infrastructures/Utilities Available at LARITI

2.4.3 Applicable Development Control Regulations
As per Meghalaya Building Bylaws 2021, ‘Special Projects’ – Means those projects / buildings with large
scale activities such as Resorts, Public Institutions, Healthcare, shopping malls, Multiplexes, ICT / BPO’s,
Educational Institution having a minimum plot area of 50,000 sq. ft and a minimum single covered area
of 40% of the plot area.

Type of
Occupancy

Maximum
permissible
F.A.R

Volume-I: Instructions to Bidders (ITB)

Maximum
permissible
Plot Coverage

Maximum no. of Permissible
Floors (Inclusive of
Basement / Lower Ground
Floor / Underground Floor /
Cellar)

Maximum Building Height in
metres (Inclusive of Basement
/ Lower Ground Floor /
Underground Floor /
Cellar/mezzanine floor /
Service Floor)

24 | P a g e

<!-- page 26 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Special Project

2.4

3

40%

7

27

Implementation Schedule

The Concessionaire shall undertake all necessary activities to completely operationalise the 100 Key
Resort, including procuring equipment, necessary civil work, marketing, etc., within 36 (thirty-six)
months of Appointed Date.

2.5

Key Terms

The following shall apply to the Concessionaire:
a) The Concessionaire shall hold lease title to the land and built-up area provided by the Authority
along with its right of way for development of 5-Star Resort over 9Turn.5 Acres of land
b) Additionally, the Concessionaire shall hold the lease title to the land and Lariti Performing
Centre, including all facilities and peripheral infrastructure, existing over the 8.5 Acre of land.
c) The Concessionaire shall develop the Resort as per its own discretion as long as it is in
accordance with the applicable building bye laws and other regulations applicable to the site.
d) The Concessionaire shall earn revenues from the 5-Star Resort as per rates to be set by them
from time to time as per market and seasonal requirements.
e) The Concessionaire shall earn revenues from the Lariti Performing Centre as per rates to be set
by them from time to time as per market and seasonal requirements.
f) However, Government may book facilities at the Lariti Performing Centre for a maximum of 45
days per year free of any facility charges. Food & Beverage (F&B) expenses shall be paid as per
actuals.
g) If the Government requires any of the facilities beyond the 45 free days in a year, the applicable
hall charges shall be paid as per the rates fixed by the operator at that time.
h) The Concessionaire shall be responsible for obtaining all applicable permits, incl. building
permits and other approvals required for development of the Project.

2.6

Bid Variable
i)

Revenue Share quoted over and above the minimum threshold of 4% (Four Percent) of Gross
Revenue for each accounting year shall be the Bid Variable. Any bidder quoting below the
threshold shall summarily be rejected.
j) Technically Qualified Bidder quoting the highest Revenue Share for the Project shall be declared
as the Successful Bidder
k) The Revenue Share means the Gross Revenue Share earned from both the properties including
the 5-Star Resort and the Lariti Performing Centre.

2.7

Pay-outs to the Authority

In consideration to the award of the Project, the Concessionaire would pay the following to the
Authority which is a composite consideration for both the 5-Star Resort and Lariti Performing Centre:
a) Upfront Premium
i.
ii.
iii.

Upfront Premium for the Project: INR 12.5 Crore (Rupee Twelve Crore Fifty Lakh only)
Upfront Premium to be paid prior to or simultaneous to signing of the Concession Agreement.
This amount is not refundable in any circumstances except if the Concession Agreement is
terminated due to Authority not being able to complete its Condition Precedents as per
timelines mentioned in this Agreement and termination thereof as per terms of this Agreement.

Volume-I: Instructions to Bidders (ITB)

25 | P a g e

<!-- page 27 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

b) Annual Concession Fees ("ACF”) – INR 1,00,000 (Indian Rupee One Lakh only) p.a., payable on or
before the Appointed Date and subsequently upon each Anniversary of the Appointed Date thereon
with escalation @ 10% in every three years
i.

ii.
iii.

Annual Concession Fee (“ACF”): In consideration of the grant of the Concession, the
Concessionaire shall during the Concession Period, pay to the Authority by way of concession
fee a sum of Rs. 1,00,000/- (Rupees One Lakhs) per annum, payable on or before the Appointed
Date.
The ACF will be escalated @ 10% in every three years
First payment of ACF shall be made on a pro-rata basis (calculated as the number of days
between the Appointed Date and 31st March of the following year. The payment shall be due
on or before the 1st Anniversary of the Appointed Date, i.e. due date for the first payment of
ACF. Every subsequent payment of ACF shall be due and payable within 15 (fifteen) days of the
commencement of the Accounting Year.

For the purpose of illustration, if the Appointed Date is 15th May 2025, then:
The first payment of ACF shall be due on or before 1st April, 2026.
► ACF payable on that date would be 321/365 * ACF;
► ACF for the next year shall be, and shall be payable on or before 1st April, 2027;
► Subsequent payments of ACF shall be made on or before 1st April of each year post escalation
for the financial year, as applicable.
►

c) Annual Lease Rental (ALR)i.
ii.
iii.

iv.

Annual Lease Rental – INR 12.5 Lakhs (Indian Rupees Twelve Lakhs Fifty Thousand only),
which is 1% of Upfront Premium.
Annual Lease Rental -The Annual Lease Rent shall be escalated by 10% in every 3 years.
First payment of Annual Lease Rental shall be made on a pro-rata basis (calculated as the
number of days between the end of the Construction Period (i.e. which shall be a period of 3
(three) years from the Appointed Date) or COD, whichever is earlier and 31st March of the year
or following year, which ever applicable and payment to be made within 15th April of the year
concerned.
Every subsequent payment of Annual Lease Rental shall be due and payable within 15 (fifteen)
days of the closure of the subsequent Accounting Year. The subsequent payments shall be due
and payable within 15 (fifteen) days of every subsequent accounting year.
Lease Moratorium: No Annual Lease Rental to be paid during the construction period of the 5Star Resort i.e. which shall be a period of 3 (three) years from the Appointed Date. In-case of
Construction Period extends beyond three years; the lease moratorium period will not be
extended beyond the three-year period. If the Commercial Operation Date (COD) is achieved
within the designated Construction Period of three years, the lease moratorium period
concludes on the date of COD achievement.

d) Revenue Share amount (“Revenue Share Amount”) for the Project as quoted by the selected bidder
over and above the minimum threshold of 4% of the Gross Revenue from the Project.

Volume-I: Instructions to Bidders (ITB)

26 | P a g e

<!-- page 28 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

i.

The Concessionaire agrees to pay to the Authority, for every year of the Concession
Period, commencing from the Project COD, as quoted over and above 4% (Four per cent)
of the Gross Revenue as its share in the revenues earned from the Project (the
“Revenue Share”). The Revenue Share shall be calculated and payable in the following
manner:

ii.

The Revenue Share shall be payable in monthly instalments. Within 7 (seven) days of
the end of each month, the Concessionaire shall pay to the Authority against the
Revenue Share, a provisional amount calculated on the basis of Gross Revenue of the
immediately preceding month and final settlement thereof, based on audited accounts
of the Concessionaire, shall be made within 120 (one hundred and twenty) days of
completion of the respective Accounting Year.

"Gross Revenue" for any Financial Year shall mean the total amount of Project revenue and receipts
of every kind (from both cash and credit transactions computed prior to payment of any commission
or service charge or fee thereon) derived by the Concessionaire/ or any agency appointed by the
Concessionaire for operation and maintenance of the Resort (“Operating Partner") from the
operation of the Project Facilities / Project and its facilities and operation and maintenance of the
Lariti Performing Centre, as certified by the statutory auditors of the Concessionaire, including but
not limited to receipts from room occupancy charges, telephone, telefax and telex charges, laundry,
sale of food, beverages, liquor, recreational amenities (outdoor pool, health club, spa, sauna,
fitness facility etc.), outdoor catering, receipts from vending machines; parking, commercial or other
spaces on account of rent and fee of every description and kind, receipts from various banquet
facilities and theatres at the Lariti Performance Centre, and the recovery in respect of any other
service or facility provided by the Concessionaire/ Operating Partner to the users / guests of the said
Project, which are availed/ realized by the Concessionaire from outside party(ies) at a consideration
but shall exclude and be arrived at after deducting the following:a) all statutory applicable indirect taxes such as luxury tax, sales tax, entertainment tax,
expenditure tax, service tax, goods & services tax and the like by whatever name called
now or in future, which the Concessionaire has agreed to pay or is bound to pay;
b) revenue on sale of assets of capital nature owned by the Concessionaire; and
c) interest income from investments made.
For the avoidance of doubt, Gross Revenue shall also include any amount received by any
Affiliate/third party agency to whom the Concessionaire/ Operating Partner has contracted
any Associated Services, Hospitality Services and/or any other activity related to the Project,
and any amount received by the Concessionaire/ Operating Partner from a third party to whom
it has contracted any Associated Services, Hospitality Services and/or any other activity related
to the Project.

Volume-I: Instructions to Bidders (ITB)

27 | P a g e

<!-- page 29 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

3. INSTRUCTIONS FOR BIDDING
A. General
3.1

General Terms of Bidding

3.1.1

No Bidder shall submit more than one Bid for the Project. A Bidder bidding individually or as a
member of a Consortium shall not be entitled to submit another Bid either individually or as a
member of any Consortium, as the case may be. In the event, multiple bids received by the
Authority from the same Bidder bidding individually or as a member of a Consortium, all Bids
shall not be eligible for consideration and shall be summarily rejected.

3.1.2

Notwithstanding anything to the contrary contained in this RFP, the detailed terms specified in
the Concession Agreement shall have overriding effect; provided, however, that any conditions
or obligations imposed on the Bidder hereunder shall continue to have effect in addition to its
obligations under the Concession Agreement.

3.1.3

The Bidder shall deposit a Bid / Proposal Security, in accordance with the provisions of this RFP.
The Bidder shall provide the Bid / Proposal Security in the form of Demand Draft (DD) or online
transfer through Real Time Gross Settlement (RTGS) / National Electronic Funds Transfer
(NEFT) to the account set out below or through an irrevocable and unconditional Bank
Guarantee as per format H.
Beneficiary Name
Bank’s name
Account Number
Branch
Address
IFSC

Director of Arts and Culture
State Bank of India
30847057575
Secretariat Branch
Meghalaya Secretariat, IGP Point, Shillong - 793001
SBIN0006320

3.1.4

The Bidder should submit a Power of Attorney as per the format in Format D-1, authorizing the
signatory of the Bid to commit the Bidder. In case the Bidder is a Consortium, the Members
thereof should furnish a Power of Attorney in favour of the Lead Member in the format
provided in Format-D-2.

3.1.5

Any condition or qualification or any other stipulation contained in the Bid shall render the Bid
liable to rejection as a non-responsive Bid.

3.1.6

The Bid and all communications in relation to or concerning the Bidding Documents and the Bid
shall be in English language.

3.1.7

The document, including this RFP and all attached documents, provided by the Authority are
and shall remain or becomes the property of the Authority and are transmitted to the Bidders
solely for the purpose of preparation and the submission of a Bid in accordance herewith.
Bidders are to treat all information as strictly confidential and shall not use it for any purpose

Volume-I: Instructions to Bidders (ITB)

28 | P a g e

<!-- page 30 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

other than for preparation and submission of their Bid. The provisions of this Clause 3.1 shall
also apply mutatis mutandis to Bids and all other documents submitted by the Bidders, and the
Authority will not return to the Bidders any Bid, document or any information provided along
therewith.
3.1.8

i.

ii.
iii.

iv.
v.

vi.

A Bidder shall not have a conflict of interest (the “Conflict of Interest”) that affects the Bidding
Process. Any Bidder found to have a Conflict of Interest shall be disqualified. Without limiting
the generality of the above, a Bidder shall be deemed to have a Conflict of Interest affecting the
Bidding Process, if:
the Bidder, its Member or Associate (or any constituent thereof) and any other Bidder, its
Member or any Associate thereof (or any constituent thereof) have common controlling
shareholders or other ownership interest; provided that this disqualification shall not apply in
cases where the direct or indirect shareholding of a Bidder, its Member or an Associate thereof
(or any shareholder thereof having a shareholding of more than 5% ( five per cent) of the paid
up and subscribed share capital of such Bidder, Member or Associate, as the case may be) in the
other Bidder, its Member or Associate, is less than 5% ( five per cent) of the subscribed and paid
up equity share capital thereof; provided further that this disqualification shall not apply to any
ownership by a bank, insurance company, pension fund or a public financial institution referred
to in Section (72) of the Companies Act, 2013. For the purposes of this Clause 3.1.8, indirect
shareholding held through one or more intermediate persons shall be computed as follows:
a. where any intermediary is controlled by a person through management control or
otherwise, the entire shareholding held by such controlled intermediary in any other
person (the “Subject Person”) shall be taken into account for computing the
shareholding of such controlling person in the Subject Person; and
b. subject always to sub-clause(a) above, where a person does not exercise control over
an intermediary, which has shareholding in the Subject Person, the computation of
indirect shareholding of such person in the Subject Person shall be undertaken on a
proportionate basis; provided, however, that no such shareholding shall be reckoned
under this sub-Clause (b) if the shareholding of such person in the intermediary is less
than 26% of the subscribed and paid up equity shareholding of such intermediary; or
a constituent of such Bidder is also a constituent of another Bidder; or
such Bidder, its Member or any Associate thereof receives or has received any direct or indirect
subsidy, grant, concessional loan or subordinated debt from any other Bidder, its Member or
Associate, or has provided any such subsidy, grant, concessional loan or subordinated debt to
any other Bidder, its Member or any Associate thereof; or
such Bidder has the same legal representative for purposes of this Bid as any other Bidder; or
such Bidder, or any Associate thereof, has a relationship with another Bidder, or any Associate
thereof, directly or through common third party/ parties, that puts either or both of them in a
position to have access to each other’s information about, or to influence the Bid of either or
each other; or
such Bidder or any Associate thereof has participated as a consultant to the Authority in the
preparation of any documents, design or technical specifications of the Project.

Volume-I: Instructions to Bidders (ITB)

29 | P a g e

<!-- page 31 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

3.1.9

A Bidder shall be liable for disqualification and forfeiture of Bid Security if any legal, financial or
technical adviser of the Authority in relation to the Project is engaged by the Bidder, its
Members or any Associate thereof, as the case may be, in any manner for matters related to or
incidental to such Project during the Bidding Process or subsequent to the (i) issue of the LOA or
(ii) execution of the Concession Agreement. In the event any such adviser is engaged by the
Selected Bidder or Concessionaire, as the case may be, after issue of the LOA or execution of the
Concession Agreement for matters related or incidental to the Project, then notwithstanding
anything to the contrary contained herein or in the LOA or the Concession Agreement and
without prejudice to any other right or remedy of the Authority, including the forfeiture and
appropriation of the Bid Security or Performance Security, as the case may be, which the
Authority may have thereunder or otherwise, even after the issuance of the LOA or execution of
the Concession Agreement, as the case may be, shall be liable to be withdrawn or terminated
without the Authority being liable in any manner whatsoever to the Selected Bidder or
Concessionaire for the same. For the avoidance of doubt, this disqualification shall not apply
where such adviser was engaged by the Bidder, its Member or Associate in the past but its
assignment expired or was terminated 6 (six) months prior to the date of issue of RFP for the
Project. Nor will this disqualification apply where such adviser is engaged after a period of 3
(three) years from the date of commercial operation of the Project.

Explanation:
In case a Bidder is a Consortium, then the term Bidder as used in this Clause 3.1.8, shall
include each Member of such Consortium.
► In the event of disqualification of a Bidder due to Conflict of Interest found during the Bidding
Process, the Authority shall be entitled to forfeit and appropriate the Bid Security.
► In the event such Conflict of Interest is discovered after signing of Concession Agreement with
the Selected Bidder, the Authority has a right to initiate termination proceedings under
Concessionaire Default. The provisions of the Draft Concession Agreement shall apply.
►

3.2

Qualification / Shortlisting of Bidders

3.2.1

The Bidder may be a single entity OR a group of members (subject to maximum of 3 Consortium
Members) coming together to implement the Project (the “Consortium”). However, no Bidder
applying individually or as a member of a Consortium, as the case may be, can be member of
another Bidder. The term ‘Bidder’ used herein would apply to both a single entity and a
Consortium.

3.2.2

A Bidder may be an Individual, Sole Proprietorship, Partnership firm, LLP under the Limited
Liability Partnership Act, 2008 or a Company (Public or Private Ltd.) incorporated under the
Companies Act 1956/2013 or any combination of them with a formal intent to enter into an
agreement or under an existing agreement to form a Consortium. All the entities shall be
required to submit proof of their statutory registration/ incorporation as per their respective
governing Statutes/ Acts. Consortium shall be eligible for consideration subject to the conditions
set out in Clause 3.1.8.
An individual Bidder or a Consortium member shall not be allowed to be a member of any other
Consortium.

Volume-I: Instructions to Bidders (ITB)

30 | P a g e

<!-- page 32 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

3.2.3
3.2.4
3.2.5

The Bidder should be legally competent to enter into a contract as per prevailing Indian Laws.
This RFP is not transferable.
Only those Bidders meeting Minimum Eligibility Criteria as per Clause 3.2.6 and other provisions
of Volume-I: ITB of the RFP Document will be considered “Technically Qualified” for the Project.
Any entity which has been blacklisted or barred by the [Central/ State Government, PSUs or any
entity controlled by it,] from participating in any project (PPP or otherwise), and the bar subsists
as on the date of Application, would not be eligible to submit an application, either individually
or as member of a Consortium. An undertaking / Affidavit in respect of this shall be enclosed.
An Applicant including any Consortium Member or Associate should, in the last 3 (three) years,
have neither failed to perform on any contract, as evidenced by imposition of a penalty by an
arbitral or judicial authority or a judicial pronouncement or arbitration award against the
Applicant, Consortium Member or Associate, as the case may be, nor has been expelled from
any project or contract by any public entity nor have had any contract terminated any public
entity for breach by such Applicant, Consortium Member or Associate. An undertaking /
Affidavit in respect of this shall be enclosed.

3.2.6

Minimum Eligibility Criteria

A Bidder should satisfy both A. Technical Capacity and B. Financial Capacity, as per this Clause 3.2.6, in
order to meet and satisfy the minimum eligibility criteria (“Minimum Eligibility Criteria").

A. Technical Capacity
For demonstrating Technical Capacity, the Bidder shall be required to satisfy the Technical Capacity
conditions below:

I.

CRITERIA: A- HOSPITALITY EXPERIENCE- The Bidder should have an experience of
developing or owning or managing and operating hotel(s) / resort(s) property with a minimum
of 500 keys in aggregate, in any 12 consecutive months during the past 10 financial years
preceding the Bid Due Date. In case the Bidders participating in Consortium, at least 1(one)
member of the consortium should independently meet the aggregate 500 keys threshold.

OR
II.

CRITERIA: B – CONSTRUCTION EXPERIENCE – The Bidder shall, over the past 10 (ten)
financial years preceding the Bid Due Date, shall satisfy Technical Capacity Criteria as below:
1.

2.

Developed/paid for development of Eligible Project(s); (Real Estate and/ or Core Sector
Projects)
AND/OR
Paid for or received payments for construction of Eligible Project(s); (Real Estate and/ or
Core Sector Projects).
such that the sum total of the above is more than INR 100 crore. (INR Hundred Crores)

Eligible Project(s) shall mean the following

Volume-I: Instructions to Bidders (ITB)

31 | P a g e

<!-- page 33 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

i.

ii.

iii.
iv.

Real Estate projects would include hotels / resorts, townships, convention centres, exhibition
centres, commercial complex, community centres, commercial offices, clubs, banquets, retail
high street / malls, residential etc. Real estate development shall not include residential flats
unless they form part of a real estate complex or township which has been built by the
applicant
Core Sector projects would include Power, Telecom, Ports, Airports, Roads and Highways,
Railways, Metro Rail, Industrial parks/ estates, Logistic parks, Pipelines, Irrigation, Water supply,
Sewerage, etc.
Projects in Real Estate/Core Sector with Project Cost of minimum INR 50 crore to qualify as an
Eligible Projects
The project cost will not include the cost of land.

Tie-up with Operator from Hospitality Sector
In the event that the applicant does not have the requisite Developing/Owning/ Operation &
Maintenance/ Management experience of Hotels/Resorts i.e., bidders applying under Criteria B will be
required to tie-up with any leading brand of a hospitality service provider with an overall portfolio of
managing 500 operational rooms as on the bid due date (“Operator O&M experience criteria”) and
should satisfy the Criteria-A: Hospitality Experience, of its own.
► Affidavit/Declaration from the O&M operator of the Hospitality Sector as per Appendix -J, and
►
►
►
►

requisite experience as per for Appendix E-1, Bid Response Sheet -1;
Such O & M operator will not be eligible to participate in bid as single entity if it ties up with
other bidder applying under Criteria B
Such O&M operator’s Brand shall have to be onboarded at-least 6 months prior to the COD;
The submission of the O&M Agreement will be condition precedent of the Concession
Agreement.
Such operator should be engaged in O&M of the project from COD to at least 15 years post COD
(“Operator Lock in Period”).

Format for submission
1.
2.
3.
4.

The Bidder should furnish details of technical capacity under Criteria A as per Appendix E-1 Bid
Response Sheet-1 and under Criteria B as per E-1 Bid Response Sheet-2.
A certificate from appropriate authorities / clients certifying completion of the project, clearly
showing project cost, size, scope of the Bidder and completion date.
In case of owned projects, certificate from an independent architect or a statutory auditor
certifying the details.
In case of Eligible Projects awarded under PPP / EPC mode: Relevant pages of the work order /
letter of award / contract / agreement. Relevant pages shall mean the Preamble of such contract
/ agreement detailing the parties, section containing information on project details like size / cost,
and the last pages detailing the signatories.

B. Financial Capacity
For the purpose of Financial Capacity, the Bidder shall be evaluated on the following:

Volume-I: Instructions to Bidders (ITB)

32 | P a g e

<!-- page 34 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

I.

NET WORTH – The Bidder shall have a Net Worth of Rs. 25 Crores (Rupees Twenty-Five
Crore only) at the closing of the preceding Financial Year before the Bid Due Date.
For the purposes of this RFP the term Net Worth means following:
"Net Worth" for company shall mean the sum of subscribed and paid-up equity and
reserves from which shall be deducted the sum of revaluation reserves, miscellaneous
expenditure not written off and reserves not available for distribution to equity
shareholders.
“Net Worth” for Partnership Firm would mean: [Fixed Assets +Trade Receivables +
Current Assets] – [Firms Loan +Current Liabilities]
“Net Worth for Sole Proprietorship” would mean: Total Assets- Total Liabilities

II.

TURNOVER – Average Annual Turnover in 3 (three) years of last 5 (five) financial years
i.e., 2020-21, 2021-22, 2022-23,2023-24 and 2024-25 should be at least INR 35 Crs (INR
Thirty-Five Crore).

Format for Submission
The Bidder should furnish details of Financial Capacity as per Appendix E and submit proofs
specified therein.
NOTE:
I.

The credentials of a Bidder’s (or Consortium member’s) Associate(s) shall also be considered for
the purpose of satisfying Minimum Eligibility Criteria as per Clause 3.2.6.

For purposes of this RFP, “Associate” means, in relation to the Bidder/ Consortium Member, a person
who controls, is controlled by, or is under the common control with such Applicant/ Consortium
Member (the “Associate”). As used in this definition, the expression “control” means, with respect to a
person which is a company or corporation, the ownership, directly or indirectly, of more than 50% (fifty
per cent) of the voting shares of such person, and with respect to a person which is not a company or
corporation, the power to direct the management and policies of such person by operation of law.
It is clarified that a certificate from a qualified external auditor who audits the book of accounts of the
Bidder shall be provided to demonstrate that a person is an Associate of the Bidder.
II.

In case of a Consortium
► Technical Capacity of Consortium shall be calculated as a sum of Technical Capacities of
individual Consortium Members who hold at least 26% equity stake in the consortium.
► Financial Capacity of Consortium shall be calculated as a sum of Financial Capacities of
individual Consortium Members who hold at least 26% equity stake in the consortium.

The Bidders meeting the aforesaid minimum eligibility criteria shall be considered as “Eligible Bidders”
and shall be marked as per the following technical marking criteria.
Note: Minimum 70 marks will be required for technical qualification and financial bid will be opened only
of those bidders who will qualify with minimum 70 marks after evaluation of technical presentation. The
marking system of the technical presentation is as mentioned below

Volume-I: Instructions to Bidders (ITB)

33 | P a g e

<!-- page 35 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

CRITERIA: A- Bidder with HOSPITALITY EXPERIENCE
Sl No
A
B
C

Sl No

Criteria
Firm’s Experience
Financial Capacity
Technical Presentation including Business Plan and market linkages
TOTAL

Criteria

Maximum Marks
40
30
30
100

Maximum Marks

A. Firm’s Experience (Maximum Marks= 40)

1

2

3

Experience of developing or owning or managing and operating
hotel(s) / resort(s) property, in any 12 consecutive months during
the past 10 financial years preceding the Bid Due Date.
• 500 keys in aggregate: 5 marks
• From 501 keys to 600 keys: 7.5 marks
• From 601 keys to 700 keys: 10 marks
• From 701 keys to 800 keys: 12.5 marks
• More than 800 keys: 15 marks
Operational experience of 5 Star Luxury Hotel/Resort (as approved
by Ministry of Tourism) with minimum 50 keys/ lettable rooms – 1
Mark for 1 project
The operational experience of minimum 12 consecutive months
during the last 5 financial years preceding the Bid Due Date.
Operational experience of 5 Star Luxury Hotel/Resort in Northeast,
India (as approved by Ministry of Tourism) with minimum 50 keys/
lettable rooms – 5 Marks for 1 project
The operational experience of minimum 12 consecutive months
during the last 5 financial years preceding the Bid Due Date

15

10

15

B. Financial Capacity (Maximum Marks= 30)

1

2

Net worth (as on 31st March 2025):
• INR 25 Crore up to INR 50 Crore (5 marks)
• More than INR 50 Crore & up to INR 100 Crore (7.5 marks)
• More than INR 100 Crore & up to INR 200 Crore (10 marks)
• More than 200 Crore& up to INR 300 Crore (12.5 marks)
• More than INR 300 Crore (15 marks)
Average Annual Turnover in 3 (three) years of last 5 (five) financial
years i.e., 2020-21, 2021-22, 2022-23,2023-24 and 2024-25

Volume-I: Instructions to Bidders (ITB)

15

15

34 | P a g e

<!-- page 36 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Sl No

Criteria
•
•
•
•
•

Maximum Marks

INR 35 Crore up to INR 100 Crore (5 marks)
More than INR 100 Crore & up to INR 200 Crore (7.5 marks)
More than INR 200 Crore & up to INR 300 Crore (10 marks)
More than 300 Crore & up to INR 400 Crore (12.5 marks)
More than INR 400 Crore (15 marks)

C. Technical Presentation including Project Implementation Plan,
Business Plan and Market Linkages (Maximum Marks= 30)

30

TOTAL

100

CRITERIA: B – Bidder with CONSTRUCTION EXPERIENCE and Tie-up with Operator
from Hospitality Sector
Sl No
A-1
A-2
B
C

Sl No

Criteria

Maximum Marks

Operator’s Experience (Hospitality Sector Tie up)
Construction Experience (Category B-1 or B-2)
Financial Capacity
Technical Presentation including Business Plan and market linkages
TOTAL

Criteria

30
20
20
30
100

Maximum Marks

A-1. Operator’s Experience (Hospitality Sector Tie up) (Maximum Marks= 30)

1

2

3

Experience of developing or owning or managing and operating
hotel(s) / resort(s) property, in any 12 consecutive months during
the past 10 financial years preceding the Bid Due Date.
• 500 keys in aggregate: 2.5 marks
• From 501 keys to 600 keys: 5 marks
• From 601 keys to 700 keys: 7.5 marks
• From 701 keys to 800 keys: 10 marks
• More than 800 keys: 12.5 marks
Operational experience of 5 Star Luxury Hotel/Resort (as approved
by Ministry of Tourism) with minimum 50 keys/ lettable rooms – 1
Mark for 1 project
The operational experience of minimum 12 consecutive months
during the last 5 financial years preceding the Bid Due Date.
Operational experience of 5 Star Luxury Hotel/Resort in Northeast,
India (as approved by Ministry of Tourism) with minimum 50 keys/
lettable rooms – 2.5 Marks for 1 project
The operational experience of minimum 12 consecutive months
during the last 5 financial years preceding the Bid Due Date

12.5

10

7.5

A-2. Construction Experience (Maximum Marks= 20)
1

Construction Experience: (Clause 3.2.6, as applicable)

Volume-I: Instructions to Bidders (ITB)

10

35 | P a g e

<!-- page 37 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Sl No

Criteria

Maximum Marks

1. Developed/paid for development of Eligible Project(s); (Real
Estate and/ or Core Sector Projects)
AND/OR
2. Paid for or received payments for construction of Eligible
Project(s); (Real Estate and/ or Core Sector Projects).
•
•
•
•

2

INR 100 Crore up to INR 200 Crore (2.5 marks)
More than INR 200 Crore & up to INR 300 Crore (5 marks)
More than INR 300 Crore & up to INR 400 Crore (7.5 marks)
More than 400 Crore (10 marks)

Construction Experience in NORTHEAST INDIA: (Clause 3.2.6, as
applicable and Projects to be executed/location to be Northeast
India only)
1. Developed/paid for development of Eligible Project(s); (Real
Estate and/ or Core Sector Projects)
AND/OR
2. Paid for or received payments for construction of Eligible
Project(s); (Real Estate and/ or Core Sector Projects).

10

• INR 100 Crore up to INR 200 Crore (2.5 marks)
• More than INR 200 Crore & up to INR 300 Crore (5 marks)
• More than INR 300 Crore & up to INR 400 Crore (7.5 marks)
• More than 400 Crore (10 marks)

B. Financial Capacity (Maximum Marks= 20)
1

2

Net worth (as on 31st March 2025):
• INR 25 Crore up to INR 50 Crore (5 marks)
• More than INR 50 Crore & up to INR 100 Crore (7.5 marks)
• More than INR 100 Crore (10 marks)
Average Annual Turnover in 3 (three) years of last 5 (five) financial
years i.e., 2020-21, 2021-22, 2022-23,2023-24 and 2024-25
• INR 35 Crore up to INR 100 Crore (5 marks)
• More than INR 100 Crore & up to INR 300 Crore (7.5 marks)
• More than INR 300 Crore (10 marks)

C. Technical Presentation Project Implementation Plan, Business
Plan and Market Linkages (Maximum Marks= 30)
TOTAL

3.3

Proposal submitted by a Consortium

3.3.1

There can be a maximum of 3 (three) members in a Consortium.

Volume-I: Instructions to Bidders (ITB)

10

10

30
100

36 | P a g e

<!-- page 38 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

3.3.2

In case of a Consortium, the combined (aggregate) Technical capacity & Financial capacity of
those members, who shall have an equity share of at least 26% (twenty six percent) each in the
SPV, should satisfy the above conditions of eligibility under clause 3.2.6; provided that each such
member shall for a period of 5 (five) years from the date of commercial operations (COD), hold
equity share capital not less than 26% of the subscribed and paid up equity of the SPV.
However, the Lead Member nominated at the time of submission of the Proposal, shall continue
to hold for the Concession Period with a minimum shareholding of 26% till the 10 th anniversary
of COD.

3.3.3

Any material changes in the membership of a Bidder will be rejected by the Authority. Proposals
submitted by a Consortium must provide a written agreement (“Consortium Agreement”/
“Joint Bidding Agreement”) to be signed by each member in that Consortium which describes
the responsibilities of each member in the Consortium. One of the Consortium members would
be required to be nominated as Lead Member and the same shall also be mentioned in the
Consortium/Joint Bidding Agreement.

3.3.4

Members of the Consortium shall be liable jointly and severally for the execution of the Project
in accordance with the terms of the Agreement and a statement to this effect shall be included
in the Consortium Agreement mentioned under this section, as well as in the Proposal and in
the Agreement. The Authority may require such documents / undertakings / indemnities as it
may deem fit from Consortium members before or at the time of issuance of Letter of Award /
Signing of Agreement.

3.3.5

The representative of the Lead Member shall hold authorization in the form of Power of
Attorney. The Proposal must designate one or more person(s) to represent the Bidder in its
dealings with the Authority. Unless specifically advised to the contrary, Authority will assume
that the person(s) designated is authorized to perform all tasks, including, but not limited to,
providing information, responding to inquiries and entering into contractual commitments on
behalf of the Company or the Consortium as the case maybe. Any and all limitations on the
Authority of the designated person(s) should be detailed in the Proposal.

3.3.6

Members of the Consortium shall enter into a binding Joint Bidding/ Consortium Agreement,
substantially in the form specified at Appendix-I (the “Consortium Agreement”/ Joint Bidding
Agreement), for the purpose of making the Application and submitting a Bid in the event of
being short-listed. The Jt. Bidding Agreement, to be submitted along with the Application, shall,
inter alia:
i.
convey the intent to form an SPV with shareholding/ ownership equity commitment(s)
in accordance with this RFP, which would enter into the Concession Agreement and
subsequently perform all the obligations of the Concessionaire in terms of the
Concession Agreement, in case the Project is awarded to the Consortium;
a) clearly outline the proposed roles and responsibilities, if any, of each member;
b) commit the minimum equity stake to be held by each member;

Volume-I: Instructions to Bidders (ITB)

37 | P a g e

<!-- page 39 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

c) commit that each of the members, whose experience will be evaluated for the purposes
of this RFP, shall subscribe to 26% (twenty six per cent) or more of the paid up and
subscribed equity of the SPV and shall further commit that each such member shall, for
a period of 5 (five) years from the date of commercial operation of the Project, hold
equity share capital not less than: (i) 26% (twenty six per cent) of the subscribed and
paid up equity share capital of the SPV;
d) commit that the Lead Member nominated at the time of submission of the Proposal,
shall continue to hold for the Concession Period with a minimum shareholding of 26%
till the 10th anniversary of COD.
e) include a statement to the effect that all members of the Consortium shall be liable
jointly and severally for all obligations of the Concessionaire in relation to the Project
until the Financial Close of the Project is achieved in accordance with the Concession
Agreement; and
f) except as provided under this RFP and the Bidding Documents, there shall not be any
amendment to the Jt. Bidding Agreement without the prior written consent of the
Authority.
3.3.7

Change in composition of the Consortium
3.3.7.1

Where the Bidder is a Consortium, change in composition of the Consortium may be
permitted by the Authority during the Bid Stage, only where:
a) the Lead Member continues to be the Lead Member of the Consortium;
b) the substitute is at least equal, in terms of Technical Capacity or Financial
Capacity, to the Consortium Member who is sought to be substituted and the
modified Consortium shall continue to meet the pre-qualification and shortlisting criteria for Applicants; and
c) the new Members) expressly adopts) the Application already made on behalf
of the Consortium as if it were a party to it originally and is not an
Applicant/Member/ Associate of any other Consortium bidding for this
Project.

3.3.7.2

Approval for change in the composition of a Consortium shall be at the sole discretion
of the Authority and must be approved by the Authority in writing. The Bidder must
submit its application for change in composition of the Consortium no later than 15
(fifteen) days prior to the Bid Due Date.
The modified/ reconstituted Consortium shall submit a revised Jt. Bidding Agreement
and a Power of Attorney, substantially in the format as per Appendix, prior to the Bid
Due Date.

3.3.7.3

3.4

Change in Ownership

3.4.1

Subject to Clause 3.2, by submitting the Bid, the Bidder acknowledges that it was pre-qualified
and short-listed on the basis of Technical Capacity and Financial Capacity of those of its
Consortium Members who shall, hold equity share capital of not less 26% of the subscribed and

Volume-I: Instructions to Bidders (ITB)

38 | P a g e

<!-- page 40 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

paid-up equity of the Concessionaire for a period of 5 years from COD, and thereafter the Lead
Member must hold a minimum equity share capital of 26% of the subscribed and paid- up
equity of the Concessionaire till the 10th anniversary of COD.
3.4.2

By submitting the Bid, the Bidder shall be deemed to have acknowledged and agreed that in the
event of a change in control of an Associate whose Technical Capacity and/or Financial Capacity
was taken into consideration for the purposes of short-listing and pre-qualification under and in
accordance with this RFP, the Bidder shall be deemed to have knowledge of the same and shall
be required to inform the Authority forthwith along with all relevant particulars about the
same and the Authority may, in its sole discretion, disqualify the Bidder or withdraw the LOA
from the Selected Bidder, as the case may be. In the event such change in control occurs after
signing of the Concession Agreement, it would, notwithstanding anything to the contrary
contained in the Concession Agreement, be deemed to be a breach of the Concession
Agreement, and the same shall be liable to be terminated without the Authority being liable in
any manner whatsoever to the Concessionaire. In such an event, notwithstanding anything to
the contrary contained in the Concession Agreement, the Authority shall be entitled to forfeit
and appropriate the Bid / Proposal Security or Performance Security, as the case may be, as
Damages, without prejudice to any other right or remedy that may be available to the Authority
under the Bidding Documents and/ or the Concession Agreement or otherwise.

3.5

Number of Bids and costs thereof

3.5.1

Each Bidder shall submit only 1 (One) Bid/ Proposal.
disqualification of the Bidder.

3.5.2

All Bidders are required to submit a detailed Proposal in accordance with the guidelines set
forth in this RFP Document. The cost of preparation of Proposal and related expenses shall be
borne by the Bidders themselves.

3.6

Site visit and verification of information

3.6.1

Bidders are encouraged to submit their respective Applications after visiting the Project site and
ascertaining for themselves the site conditions, traffic, location, surroundings, climate,
availability of power, water and other utilities for construction, access to site, handling and
storage of materials, weather data, applicable laws and regulations, and any other matter
considered relevant by them.

3.6.2

It shall be deemed that by submitting a Bid, the Bidder has:
a. made a complete and careful examination of the Bidding Documents;
b. received all relevant information requested from the Authority;
c. accepted the risk of inadequacy, error or mistake in the information provided in the
Bidding Documents or furnished by or on behalf of the Authority relating to any of the
matters referred to in this RFP;
d. satisfied itself about all matters, things and information including matters referred to in
Clause3.6 hereinabove necessary and required for submitting an informed Bid,

Volume-I: Instructions to Bidders (ITB)

Violation of this shall lead to

39 | P a g e

<!-- page 41 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

execution of the Project in accordance with the Bidding Documents and performance of
all of its obligations thereunder;
e. acknowledged and agreed that inadequacy, lack of completeness or incorrectness of
information provided in the Bidding Documents or ignorance of any of the matters
referred to in Clause3.6 hereinabove shall not be a basis for any claim for
compensation, damages, extension of time for performance of its obligations, loss of
profits etc. from the Authority, or a ground for termination of the Concession
Agreement by the Concessionaire;
f. acknowledged that it does not have a Conflict of Interest; and
g. agreed to be bound by the undertakings provided by it under and in terms hereof.
3.6.3

The Authority shall not be liable for any omission, mistake or error in respect of any of the
above or on account of any matter or thing arising out of or concerning or relating to RFP, the
Bidding Documents or the Bidding Process, including any error or mistake therein or in any
information or data given by the Authority.

3.7

Verification and Disqualification

3.7.1

The Authority reserves the right to verify all statements, information and documents submitted
by the Bidder in response to the RFP and the Bidder shall, when so required by the Authority,
make available all such information, evidence and documents as may be necessary for such
verification. Any such verification or lack of such verification, by the Authority shall not relieve
the Bidder of its obligations or liabilities hereunder nor will it affect any rights of the Authority
thereunder.
The Authority reserves the right to reject any Bid and appropriate the Bid Security if:

3.7.2

(a) at any time, a material misrepresentation is made or uncovered, or
(b) the Bidder does not provide, within the time specified by the Authority, the supplemental
information sought by the Authority for evaluation of the Bid.
Such misrepresentation/ improper response shall lead to the disqualification of the Bidder. If
the Bidder is a Consortium, then the entire Consortium and each Member may be disqualified /
rejected. If such disqualification / rejection occurs after the Bids have been opened and the
Highest Bidder gets disqualified / rejected, then the Authority reserves the right to:
i) invite the remaining Bidders to submit their Bids in accordance with Clauses 4.3; or
(ii) take any such measure as may be deemed fit in the sole discretion of the Authority, including
annulment of the Bidding Process.
3.7.3

In case it is found during the evaluation or at any time before signing of the Concession
Agreement or after its execution and during the period of subsistence thereof, including the
Concession thereby granted by the Authority, that one or more of the pre-qualification
conditions have not been met by the Bidder, or the Bidder has made material misrepresentation
or has given any materially incorrect or false information, the Bidder shall be disqualified
forthwith if not yet appointed as the Concessionaire either by issue of the LOA or entering into
of the Concession Agreement, and if the Selected Bidder has already been issued the LOA or has

Volume-I: Instructions to Bidders (ITB)

40 | P a g e

<!-- page 42 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

entered into the Concession Agreement, as the case may be, the same shall, notwithstanding
anything to the contrary contained therein or in this RFP, be liable to be terminated, by a
communication in writing by the Authority to the Selected Bidder or the Concessionaire, as the
case may be, without the Authority being liable in any manner whatsoever to the Selected
Bidder or Concessionaire.
In such an event, the Authority shall be entitled to forfeit and appropriate the Bid Security or
Performance Security and Upfront Premium, as the case may be, as Damages, without prejudice
to any other right or remedy that may be available to the Authority under the Bidding
Documents and/ or the Concession Agreement, or otherwise.

3.8

Right to accept or reject any or all Bids/ Bids

3.8.1

Notwithstanding anything contained in this RFQ, the Authority reserves the right to accept or
reject any Application and to annul the Bidding Process and reject all Applications/ Bids, at any
time without any liability or any obligation for such acceptance, rejection or annulment, and
without assigning any reasons therefor. In the event that the Authority rejects or annuls all the
Bids, it may, in its discretion, invite all eligible Bidders to submit fresh Bids hereunder.

B. Documents
3.9

Contents of the RFP

3.9.1

This RFP comprises the Disclaimer set forth hereinabove, the contents as listed below and will
additionally include any Addenda issued in accordance with Clause3.11.

Instruction to Bidders (ITB)
Section 1: Invitation for Proposal
Section 2: Project Details
Section 3: Instructions for Bidding
Section 4: Evaluation of Bids
Section 5: Fraud and Corrupt Practices
Section 6: Pre-Bid Conference
Section 7: Miscellaneous
Appendices
A – Letter of Bid & Interest
B – General Information of the Bidder
C– Affidavit
D1– Format for Power of Attorney for Authorized Signatory
D2 – Format of Power of Attorney by each Member of Consortium in favour of Lead Member
E– Minimum Eligibility Criteria

Volume-I: Instructions to Bidders (ITB)

41 | P a g e

<!-- page 43 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

F– Acknowledgement Letter (to be submitted by each Member of Consortium)
G – Statement of Legal Capacity
H – Format of Bank Guarantee towards Bid / Proposal Security
I – Draft Consortium Agreement
J – Format for O & M Undertaking
K – Format for Financial Proposal
The draft Concession Agreement, along with Schedules, provided by the Authority as part of the Bidding
Documents shall be deemed to be part of this RFP.

3.10

Clarifications

3.10.1 Bidders requiring any clarification on the RFP may notify the Authority in writing by speed post/
courier/ e-mail at the address provided in Clause 1.4. They should send in their queries on or
before the date mentioned in the Schedule of Bidding Process specified in Clause1.2. The
responses will be published online on the website only. The Authority will publish all the queries
and its responses thereto on the website without identifying the source of queries.
3.10.2 The Authority shall endeavour to respond to the questions raised or clarifications sought by the
Bidders. However, the Authority reserves the right not to respond to any question or provide
any clarification, in its sole discretion, and nothing in this Clause shall be taken or read as
compelling or requiring the Authority to respond to any question or to provide any clarification.
3.10.3 The Authority may also on its own motion, if deemed necessary, issue interpretations and
clarifications to all Bidders. All clarifications and interpretations issued by the Authority shall be
deemed to be part of the Bidding Documents. Verbal clarifications and information given by
Authority, or its employees or representatives shall not in any way or manner be binding on the
Authority.

3.11

Amendment of RFP

3.11.1 At any time prior to the Bid / Proposal Due Date, Authority may for any reason, whether at its
own initiative or in response to clarifications requested by a Bidder, modify the RFP Document
through the issuance of Addenda.
3.11.2 Any Addendum and Corrigendum thereto, thus issued shall be part of the RFP and shall be
published online only. The Authority will assume no responsibility for receipt of the Addendum
and Corrigendum.
3.11.3 To give prospective Bidders reasonable time in which to take any Addendum and/or
Corrigendum into account in preparing their Bids, the Authority may, at its sole discretion,
extend the Due Date.

Volume-I: Instructions to Bidders (ITB)

42 | P a g e

<!-- page 44 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

C. Preparation and Submission of Bid
3.12

Language

3.12.1 The Application and all related correspondence and documents in relation to the Bidding
Process shall be in English language. Supporting documents and printed literature furnished by
the Applicant with the Application may be in any other language provided that they are
accompanied by translations of all the pertinent passages in the English language, duly
authenticated and certified by the Applicant. Supporting materials, which are not translated into
English, may not be considered for evaluation purpose. For the purpose of interpretation and
evaluation of the Application, the English language translation shall prevail.
3.12.2 Any currency for the purpose of the Proposal / Bid shall be in form of Indian National Rupee
(INR).

3.13

Format and signing of Bid

3.13.1 The Bidder shall provide all the information sought under this RFP. The Authority will evaluate
only those Bids that are received in the required formats and complete in all respects.
3.13.2 The Bid shall be typed or written in indelible ink and signed by the authorized signatory of the
Bidder who shall also initial each page, in blue ink. In case of printed and published documents,
only the cover shall be initialled. All the alterations, omissions, additions or any other
amendments made to the Bid shall be initialled by the person(s) signing the Bid.

3.14

Sealing, Marking and Submission Proposals /Bids
The proposal shall be submitted in 2 (Two) parts in 2 (Two) separate envelopes/packages put
together in 1 (one) single outer envelope. The outer envelope should be superscribed with the
Bidder Name and Bid Number.

3.14.1 Submission of Bid
The Proposals shall be sealed, marked and submitted as explained below:
The 2 parts (collectively referred to as ‘Proposal’) shall be:
Part-A: Technical Proposal.
Part 1, the “Technical Proposal” should have the following documents.
a.
b.
c.
d.
e.
f.

Bid / Proposal Security and the receipt of online payment of Bid Document Fee
Letter of Application and Interest (As per Format A);
General Information of the Bidder (As per Format B);
Affidavit (As per Format C);
Power of Attorney for Authorized Signatory (As per Format D1);
Power of Attorney by each Member of the Consortium in favour of Lead Member (As
per Format D2), if applicable.
g. Minimum Eligibility Criteria (As per Format E);
h. Acknowledgement (As per Format F);
i. Statement of Legal Capacity (As per Format G);
Volume-I: Instructions to Bidders (ITB)

43 | P a g e

<!-- page 45 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

j. Consortium Agreement (As per Format I), if applicable.
k. O & M undertaking (As per format J), if applicable
l. Supporting documents (duly signed) such as:
i. Certificate of Registration / Incorporation
ii. Annual Reports and Audited financial statements for last 5 financial years (FY
25, FY24, FY23, FY22 and FY21 )
iii. Supporting documents to support Technical Capacity (as per Clause 3.2.6)
Part 2- Financial Proposal
The Part 2, the “Financial Proposal” should be submitted as per the format for Financial Bid
given in APPENDIX-K: Format for Financial Proposal.
Note:
a. Financial Proposal shall not be submitted with Part-1, and if submitted, the bid will be rejected.
b. All the above envelopes shall be enclosed in an outer cover / envelope marked as “Development,
Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a
Public–Private Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya”..
c. The Envelope shall be addressed to:
To,
The Director
Directorate of Arts & Culture
Government of Meghalaya
I.G.P. Point, Ground Floor of the State Central Library Complex, Shillong, Meghalaya 793001
Phone No: +91 9774281282
E-mail: artsandculturemegh@gmail.com
The hard copies / physical bid shall be submitted to the above address on or above the Bid Due Date as
per Clause 1.2. It is being clarified here that the information as asked from the Bidder should be in the
format as provided.
If the envelope is not sealed and marked, as instructed above, the Authority assumes no responsibility
for the misplacement or premature opening of the Proposal submitted. In that case, the prematurely
opened Proposals will be rejected.
Any Proposal received by the Authority after the Proposal / Bid Due Date will be liable for rejection.
3.14.2 Submission Formats
a) The Technical proposal (Part A) and Financial Proposal (Part B) must be inserted in separate
sealed envelopes, along with bidder’s name and address on the envelope and clearly marked as
follows:
Part-A:
Technical proposal for

Volume-I: Instructions to Bidders (ITB)

44 | P a g e

<!-- page 46 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

“DEVELOPMENT, OPERATION AND MANAGEMENT OF 5 STAR RESORT UNDER DESIGN, BUILD,
FINANCE, OPERATE AND TRANSFER (DBFOT) MODEL, ALONG WITH THE OPERATION AND
MAINTENANCE OF THE LARITI PERFORMING CENTRE ON A PUBLIC–PRIVATE PARTNERSHIP (PPP)
BASIS, AT MAWKASIANG, NEW SHILLONG, MEGHALAYA”
Part-B:
Financial proposal for
“DEVELOPMENT, OPERATION AND MANAGEMENT OF 5 STAR RESORT UNDER DESIGN, BUILD,
FINANCE, OPERATE AND TRANSFER (DBFOT) MODEL, ALONG WITH THE OPERATION AND
MAINTENANCE OF THE LARITI PERFORMING CENTRE ON A PUBLIC–PRIVATE PARTNERSHIP (PPP)
BASIS, AT MAWKASIANG, NEW SHILLONG, MEGHALAYA “Both the envelopes i.e. envelope for Part-A
and Envelope for Part-B must be packed in a separate sealed outer cover and clearly super scribed with
the following:
Proposal for
“DEVELOPMENT, OPERATION AND MANAGEMENT OF 5 STAR RESORT UNDER DESIGN, BUILD,
FINANCE, OPERATE AND TRANSFER (DBFOT) MODEL, ALONG WITH THE OPERATION AND
MAINTENANCE OF THE LARITI PERFORMING CENTRE ON A PUBLIC–PRIVATE PARTNERSHIP (PPP)
BASIS, AT MAWKASIANG, NEW SHILLONG, MEGHALAYA “The Bidder’s Name & address shall be
mentioned in the left-hand corner of the outer envelope. The inner and outer envelopes shall be
addressed to the following address:
To,
The Director
Directorate of Arts & Culture
Government of Meghalaya
I.G.P. Point, Ground Floor of the State Central Library Complex, Shillong, Meghalaya 793001
Phone No: +91 9774281282
E-mail: artsandculturemegh@gmail.com
Note:
i.

ii.

3.15

If the outer envelope and the financial proposal envelope is not sealed and marked as
mentioned above, then Authority will assume no responsibility for the tender’s misplacement or
premature opening. Telex, cable or facsimile tenders will be rejected.
Any deviation from the prescribed procedures / information / formats / conditions shall result in
out-right rejection of the proposal. All the pages of the proposal have to be signed by the
authorized representative of the bidder. Bids with any conditional offer shall be out rightly
rejected. All pages of the proposal must have to be sealed and signed by the authorized
representative of the bidder. Any conditional bids will be rejected.

Late Bids
Bids received by the Authority after the specified time on the Bid Due Date shall not be eligible
for consideration and shall be summarily rejected.

Volume-I: Instructions to Bidders (ITB)

45 | P a g e

<!-- page 47 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

3.16

Modifications/ Substitution/ Withdrawal of Bids
The Bidder may modify, substitute or withdraw its Bid after submission, provided that written
notice of the modification, substitution or withdrawal is received by the Authority prior to the
Bid Due Date. No Bid shall be modified, substituted or withdrawn by the Bidder on or after the
Bid Due Date.
The modification, substitution or withdrawal notice shall be prepared, sealed, marked, and
delivered in accordance with Clause3.14, with the envelopes being additionally marked
“MODIFICATION”, “SUBSTITUTION” or “WITHDRAWAL”, as appropriate.
Any alteration/ modification in the Bid or additional information supplied post the Bid Due Date,
unless the same has been expressly sought for by the Authority, shall be disregarded.

3.17

Rejection of Bids
Notwithstanding anything contained in this RFP, the Authority reserves the right to reject any
Bid or to annul the Bidding Process and reject all Bids at any time without any liability or any
obligation for such acceptance, rejection or annulment, and without assigning any reasons
thereof. In the event that the Authority rejects or annuls all the Bids, it may, in its sole
discretion, invite all eligible Bidders to submit fresh Bids hereunder.
The Authority reserves the right not to proceed with the Bidding Process at any time, without
notice or liability, and to reject any Bid without assigning any reasons thereof.

3.18

Validity of Bids
The Proposal shall remain valid for a period not less than 180 (one hundred and eighty) days
from the Proposal Due Date (the “Proposal Validity Period”). The Authority reserves the right to
reject any Proposal that does not meet this requirement. Validity of Bid Security shall be
extended for a specified additional period at the request of the Authority to the Bidder.
A Bidder agreeing to the request will not be allowed to modify his Proposal but would be
required to extend the validity of his Bid / Proposal Security for the period of extension.
Upon the extension, the Proposal Validity Period for the Proposal / Bid Security submitted by
the Selected Bidder shall be extended till the date of execution of the Concession Agreement.

3.19

Confidentiality
Information relating to the examination, clarification, evaluation, and recommendation for the
short-listed pre-qualified Applicants shall not be disclosed to any person who is not officially
concerned with the process or is not a retained professional advisor advising the Authority in
relation to, or matters arising out of, or concerning the Bidding Process. The Authority will treat
all information, submitted as part of Application, in confidence and will require all those who
have access to such material to treat the same in confidence. The Authority may not divulge any
such information unless it is directed to do so by any statutory entity that has the power under
law to require its disclosure or is to enforce or assert any right or privilege of the statutory
entity and/ or the Authority or as may be required by law or in connection with any legal
process.

Volume-I: Instructions to Bidders (ITB)

46 | P a g e

<!-- page 48 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

3.20

Correspondence with the Bidder
Save and except as provided in this RFP, the Authority shall not entertain any correspondence
with any Bidder in relation to acceptance or rejection of any Bid.

D. Bid / Proposal Security
3.21

Bid / Proposal Security
The Bid / Proposal shall be accompanied by a Bid / Proposal Security for a value of INR 85 Lakhs
(Rupees Eighty-Five Lakhs Only) (as per Appendix A – Letter of Bid).
Any Proposal submitted without the Bid / Proposal Security or not in the form as specified in the
RFP Document shall be declared as non-responsive and shall be summarily rejected.
The Authority shall not be liable to pay any interest on the Bid / Proposal Security.
The Bid Security shall be forfeited as Damages without prejudice to any other right or remedy
that may be available to the Authority under the Bidding Documents and/ or under the
Concession Agreement, or otherwise, under the following conditions:
a) If a Bidder submits a non-responsive Bid;
b) If a Bidder engages in a corrupt practice, fraudulent practice, coercive practice,
undesirable practice or restrictive practice as specified in Clause 4 of this RFP;
c) If a Bidder withdraws its Bid during the period of Bid validity as specified in this RFP and
as extended by mutual consent of the respective Bidder(s) and the Authority;
d) In the case of Selected Bidder, if it fails within the specified time limit i.
to sign and return the duplicate copy of LOA;
ii.
to sign the Concession Agreement; or
iii.
to furnish the Performance Security within the period prescribed therefor in the
Concession Agreement; or
e) In case the Selected Bidder, having signed the Concession Agreement, commits any
breach thereof prior to furnishing the Performance Security.

Note:
Bid / Proposal Security of only H1, H2 & H3 Bidders would be retained till the Concession Agreement is
signed between the Selected Bidder and the Authority. The Bid / Proposal Security of other Bidders would
be returned, without interest, within 60 (Sixty) day of opening of Financial Proposals.
The Bid / Proposal Security of the Selected Bidder will be retained till the later of
i.
ii.

3.22

signing of Concession Agreement between the Selected bidder and the Authority, or
submission of Performance Security.

Performance Security
The Selected Bidder, for due and faithful performance of its obligations under the Concession
Agreement, shall be required to provide “Performance Security” as per Article 9 of the Draft
Concession Agreement.

Volume-I: Instructions to Bidders (ITB)

47 | P a g e

<!-- page 49 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

3.23

Proprietary data
All documents and other information supplied by the Authority or submitted by an Applicant to
the Authority shall remain or become the property of the Authority. Applicants are to treat all
information as strictly confidential and shall not use it for any purpose other than for
preparation and submission of their Application. The Authority will not return any Application or
any information provided along therewith.

Volume-I: Instructions to Bidders (ITB)

48 | P a g e

<!-- page 50 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

4. EVALUATION OF BIDS
4.1

Opening and Evaluation of Bids
The received Technical Proposals shall be opened, by the tender opening committee of the
Authority, in presence of the Bidders at scheduled time on the Bid Due Date, unless intimated
otherwise. The date for opening of Financial Proposals shall be intimated in advance to the
Technically Qualified Bidders.
The Authority, reserves the right to reject any Proposal, if
a) It is not signed, sealed and marked as stipulated in Clause3.14.
b) The information and documents have not been submitted as requested and in the formats
specified in the RFP Document.
c) There are inconsistencies between the Proposal and the supporting documents.
d) It does not mention the Proposal Validity Period as set out in Clause3.18.
e) There are conditions proposed with the Proposal.
f) It provides the information with material deviations.
For avoidance of doubt, a material deviation or reservation is one:
a) Which affects in any substantial way, the scope, quality, or performance of the Project, or
b) Which limits in any substantial way, inconsistent with the RFP Document, the Authority’s
rights or the Bidder’s obligations, or
c) Which would affect unfairly the competitive position of other Bidders’ presenting
substantially responsive bids.
To facilitate evaluation of Bids, the Authority may, at its sole discretion, seek clarifications in writing
from any Bidder regarding its Bid.
No request for modification or withdrawal shall be entertained by the Authority in respect of such
Proposals.
The evaluation and award shall be done in 3 (three) steps as explained below:

Step 1 – Qualification and Shortlisting
Step 1A: Proposals shall be tested for responsiveness as per Test of Responsiveness in
Clause4.2.
Step 1B: The Bid / Proposal Security in Envelope–1 shall be checked. Proposals without Bid /
Proposal Security shall be rejected.
Step 1C: The submission(s) in Envelope–2 shall be checked.
►

►

The Technical Capacity and Financial Capacity of the Bidder should be sufficient as per
Clause 3.2.6 of this RFP.
The bidders meeting the minimum eligibility conditions shall be evaluated based on the
technical marking criteria laid down under clause 3.2.6 of this RFP wherein a technical
presentation of the proposed project shall be made by the respective bidders to the
Authority.

Volume-I: Instructions to Bidders (ITB)

49 | P a g e

<!-- page 51 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya
►

The Proposals not meeting the prescribed criteria as per Clause 3.2.6 will be rejected
outright. All Bidders passing Step–I of the evaluation by meeting the minimum eligibility
criteria and with technical marking above the threshold limit will be considered as
Technical Qualified Bidders and shall be considered for the next stage.

All Bidders passing Step–I of the evaluation will be considered as Technical Qualified Bidders
and shall be considered for the next stage.

Step – 2: Financial Proposal Evaluation and Selection
The Financial Proposals of only those Bidders who have passed Step–1 shall be opened in presence
of the nominees of the Authority and Bidders. The Highest Bidder shall be declared as the Selected
Bidder / Successful Bidder. Financial Proposals of Bidders who do not qualify the Step–I of
evaluation shall not be opened. In this RFP, the term “Highest Bidder” shall mean the Bidder who is
offering the highest Bid Variable. Bidders shall be ranked H1, H2, H3, etc. in decreasing order of
their financial offers, with H1 being the Bidder quoting the highest Bid Variable. In case two Bidders
quote the same Bid Variable, the Bidder having highest technical score will be considered as the
Highest Bidder.

4.2

Tests of responsiveness
Prior to evaluation of Bids, the Authority shall determine whether each Bid is responsive to the
requirements of this RFP. A Bid shall be considered responsive if:
a) it is received as per the formats attached in Appendices;
b) it is received by the Bid Due Date including any extension thereof pursuant to Clause1.2;
c) it is signed, sealed, bound together in hard cover and marked as stipulated in
Clause3.14;
d) it is accompanied by the Bid / Proposal Security as specified in Clause3.21;
e) it is submitted as required in the RFP;
f) it contains all the information (complete in all respects) as requested in this RFP and/or
Bidding Documents (in formats same as those specified);
g) it does not contain any condition or qualification; and
h) it is not non-responsive in terms hereof.
The Authority reserves the right to reject any Bid which is non-responsive and no request for
alteration, modification, substitution or withdrawal shall be entertained by the Authority in
respect of such Bid. Provided, however, that the Authority may, in its discretion, allow the
Bidder to rectify any infirmities or omissions if the same do not constitute a material
modification of the Bid.

4.3

Selection of Bidder
Subject to the provisions of Clause 3.13, the Bidder whose Bid is adjudged as responsive in
terms of Clause 4.2, who meets the Eligibility Criteria as per Section 3.2.6 and who is declared as
the Highest Bidder as per Section 2.6.b., shall ordinarily be declared as the selected Bidder (the
“Selected Bidder” or “Successful Bidder”). In the event that the Authority rejects or annuls all
the Bids, it may, in its discretion, invite all eligible Bidders to submit fresh Bids hereunder

Volume-I: Instructions to Bidders (ITB)

50 | P a g e

<!-- page 52 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

In the event that two or more Bidders quote the same amount of Bid Variable (the “Tie
Bidders”), the Authority shall select the Bidder basis process outlined in Clause 4.1. In the event
that the Highest Bidder withdraws or is not selected for any reason in the first instance (the
“first round of bidding”), the Authority may either cancel the bid process or alternately, invite all
the remaining Bidders to revalidate or extend their respective Bid / Proposal Security, as
necessary, and match the Bid of the aforesaid Highest Bidder (the “second round of bidding”). If
in the second round of bidding, only one Bidder matches the Highest Bidder, it shall be the
Selected Bidder. If two or more Bidders match the said Highest Bidder in the second round of
bidding, then the Bidder whose Bid was higher as compared to other Bidder(s) in the first round
of bidding shall be the Selected Bidder. For example, if the third and fifth highest Bidders in the
first round of bidding offer to match the said Highest Bidder in the second round of bidding, the
said third highest Bidder shall be the Selected Bidder.
In the event that no Bidder offers to match the Highest Bidder in the second round of bidding as
specified above, the Authority may, in its discretion, invite fresh Bids (the “third round of
bidding”) from all Bidders except the Highest Bidder of the first round of bidding, or annul the
Bidding Process, as the case may be. In case the Bidders are invited in the third round of bidding
to revalidate or extend their Bid / Proposal Security, as necessary, and offer fresh Bids, they
shall be eligible for submission of fresh Bids provided, however, that in such third round of
bidding only such Bids shall be eligible for consideration which are higher than the Bid of the
second highest Bidder in the first round of bidding.
After selection, a Letter of Award (the “LOA”) shall be issued, in duplicate, by the Authority to
the Selected Bidder and the Selected Bidder shall, within 7 (seven) days of the receipt of the
LOA, sign and return the duplicate copy of the LOA in acknowledgement thereof. In the event
the duplicate copy of the LOA duly signed by the Selected Bidder is not received by the
stipulated date, The Authority may, unless it consents to extension of time for submission
thereof, appropriate the Bid / Proposal Security of such Bidder as Damages on account of failure
of the Selected Bidder to acknowledge the LOA, and the next eligible Bidder may be considered.
After acknowledgement of the LOA as aforesaid by the Selected Bidder, the Authority shall
cause the Concessionaire to execute the Concession Agreement within the period prescribed in
Clause 1.2. The Selected Bidder shall not be entitled to seek any deviation, modification or
amendment in the Concession Agreement.

4.4

Avoidance of Contact during Bid Evaluation
Bids shall be deemed to be under consideration immediately after they are opened and until
such time the Authority makes official intimation of award/ rejection to the Bidders. While the
Bids are under consideration, Bidders and/ or their representatives or other interested parties
are advised to refrain, save and except as required under the Bidding Documents, from
contacting by any means, the Authority and/ or their employees/ representatives on matters
related to the Bids under consideration.

Volume-I: Instructions to Bidders (ITB)

51 | P a g e

<!-- page 53 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

4.5

Bids of other Bidders
The Authority shall return the Bid/ Proposal Security received from the Bidders who have not
qualified in Step–I of the evaluation, within 60 (sixty) days of opening of the Technical Proposal.
The Bid / Proposal Security shall be returned without payment of any interest.

Volume-I: Instructions to Bidders (ITB)

52 | P a g e

<!-- page 54 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

5. FRAUD AND CORRUPT PRACTICES
5 Fraud and Corrupt Practices
The Bidders and their respective officers, employees, agents and advisers shall observe the highest
standard of ethics during the Bidding Process and subsequent to the issue of the LOA and during the
subsistence of the Concession Agreement. Notwithstanding anything to the contrary contained
herein, or in the LOA or the Concession Agreement, the Authority may reject a Bid, withdraw the
LOA, or terminate the Concession Agreement, as the case may be, without being liable in any
manner whatsoever to the Bidder or Concessionaire, as the case may be, if it determines that the
Bidder or Concessionaire, as the case may be, has, directly or indirectly or through an agent,
engaged in corrupt practice, fraudulent practice, coercive practice, undesirable practice or
restrictive practice in the Bidding Process. In such an event, the Authority shall be entitled to
forfeit and appropriate the Bid / Proposal Security or Performance Security, as the case may be, as
Damages, without prejudice to any other right or remedy that may be available to the Authority
under the Bidding Documents and/ or the Concession Agreement, or otherwise.
Without prejudice to the rights of the Authority under Clause 5 hereinabove and the rights and
remedies which the Authority may have under the LOA or the Concession Agreement, or otherwise if
a Bidder or Concessionaire, as the case may be, is found by the Authority to have directly or
indirectly or through an agent, engaged or indulged in any corrupt practice, fraudulent
practice, coercive practice, undesirable practice or restrictive practice during the Bidding Process, or
after the issue of the LOA or the execution of the Concession Agreement, such Bidder or
Concessionaire shall not be eligible to participate in any tender or RFP issued by the Authority during
a period of 2 (two) years from the date such Bidder or Concessionaire, as the case may be, is found
by the Authority to have directly or indirectly or through an agent, engaged or indulged in any
corrupt practice, fraudulent practice, coercive practice, undesirable practice or restrictive practices,
as the case may be.
For the purposes of this clause, the following terms shall have the meaning hereinafter respectively
assigned to them:
a) “corrupt practice” means the offering, giving, receiving, or soliciting, directly or indirectly,
of anything of value to influence the actions of any person connected with the Bidding Process
(for avoidance of doubt, offering of employment to or employing or engaging in any manner
whatsoever, directly or indirectly, any official of the Authority who is or has been associated in
any manner, directly or indirectly, with the Bidding Process or the LOA or has dealt with
matters concerning the Concession Agreement or arising therefrom, before or after the
execution thereof, at any time prior to the expiry of one year from the date such official resigns
or retires from or otherwise ceases to be in the service of the Authority, shall be deemed to
constitute influencing the actions of a person connected with the Bidding Process);
b) “fraudulent practice” means a misrepresentation or omission of facts or suppression of facts or
disclosure of incomplete facts, in order to influence the Bidding Process;
c) “coercive practice” means impairing or harming, or threatening to impair or harm, directly or
indirectly, any person or property to influence any person’s participation or action in the
Bidding Process;

Volume-I: Instructions to Bidders (ITB)

53 | P a g e

<!-- page 55 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

d) “undesirable practice” means (i) establishing contact with any person connected with or
employed or engaged by the Authority with the objective of canvassing, lobbying or in any
manner influencing or attempting to influence the Bidding Process; or (ii) having a Conflict of
Interest; and
e) “restrictive practice” means forming a cartel or arriving at any understanding or arrangement
among Bidders with the objective of restricting or manipulating a full and fair competition in
the Bidding Process.

Volume-I: Instructions to Bidders (ITB)

54 | P a g e

<!-- page 56 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

6. PRE-BID CONFERENCE
Pre-Bid Conference for the interested Bidders shall be convened at the designated date, time and place.
A maximum of two representatives of each Bidder shall be allowed to participate on production of
authority letter from the Bidder.
During the course of Pre-Bid Conference, the Bidders will be free to seek clarifications and make
suggestions for consideration of the Authority. The Authority shall endeavour to provide clarifications
and such further information as it may, in its sole discretion, consider appropriate for facilitating a fair,
transparent and competitive Bidding Process.
The Bidders should send in their queries prior to the Pre-Bid Conference date specified in the Schedule
1.2 of the RFP. Authority shall endeavour to respond to the queries within the period specified therein.
Any query received after the Pre-Bid Conference shall not be entertained.
“Queries concerning RFP for Development, Operation and Management of 5 Star Resort under
Design, Build, Finance, Operate and Transfer (DBFOT) Model, along with the Operation and
Maintenance of the Lariti Performing Centre on a Public–Private Partnership (PPP) Basis, at
Mawkasiang, New Shillong, Meghalaya”
Sl No

Clause/Page No.

Content of the RFP requiring
clarifications

Change/clarification
Requested

1
2
3

Authority shall endeavor to respond to the questions raised or clarifications sought by the Bidders.
However, Authority reserves the right not to respond to any question or provide any clarification, in its
sole discretion, and nothing in this Clause shall be taken or read as compelling or requiring Authority to
respond to any question or to provide any clarification.
Authority may, on its own, if deemed necessary, issue interpretations and clarifications to all Bidders. All
clarifications and interpretations issued by Authority shall be deemed to be part of the RFP. Verbal
clarifications and information given by Authority or its employees or representatives shall not in any
way or manner be binding on Authority.

Volume-I: Instructions to Bidders (ITB)

55 | P a g e

<!-- page 57 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

7. MISCELLANEOUS
The Bidding Process shall be governed by, and construed in accordance with, the laws of India and the
Courts in Shillong shall have exclusive jurisdiction over all disputes arising under, pursuant to and/ or in
connection with the Bidding Process.
The Authority, in its sole discretion and without incurring any obligation or liability, reserves the right, at
any time, to;
a) suspend and/ or cancel the Bidding Process and/ or amend and/ or supplement the Bidding
Process or modify the dates or other terms and conditions relating thereto;
b) consult with any Bidder in order to receive clarification or further information;
c) retain any information and/ or evidence submitted to the Authority by, on behalf of, and/ or in
relation to any Bidder; and/ or
d) independently verify, disqualify, reject and/ or accept any and all submissions or other
information and/ or evidence submitted by or on behalf of any Bidder.
It shall be deemed that by submitting the Bid, the Bidder agrees and releases the Authority, its
employees, agents and advisers, irrevocably, unconditionally, fully and finally from any and all liability
for claims, losses, damages, costs, expenses or liabilities in any way related to or arising from the
exercise of any rights and/ or performance of any obligations hereunder, pursuant hereto and/ or in
connection with the Bidding Process and waives, to the fullest extent permitted by applicable laws,
any and all rights and/ or claims it may have in this respect, whether actual or contingent, whether
present or in future.

Volume-I: Instructions to Bidders (ITB)

56 | P a g e

<!-- page 58 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

8. APPENDICES

APPENDIX-A. Letter of Bid & Interest
(To be signed and submitted by the Bidder’s authorized signatory on Bidder’s Letter Head)
The Director
Directorate of Arts & Culture
Government of Meghalaya
I.G.P. Point, Ground Floor of the State Central Library Complex, Shillong, Meghalaya 793001
Phone No: +91 9774281282
E-mail : artsandculturemegh@gmail.com
Subject:

RFP for Development, Operation and Management of 5 Star Resort under Design,
Build, Finance, Operate and Transfer (DBFOT) Model, along with the Operation and
Maintenance of the Lariti Performing Centre on a Public–Private Partnership (PPP)
Basis, at Mawkasiang, New Shillong, Meghalaya.

Dear Sir,
1.

With reference to your RFP document dated ******, I/we, having examined the Bidding
Documents and understood their contents, hereby submit my/our Bid(s) for the aforesaid
Project. The Bid(s) is(/are) unconditional and unqualified.

2.

I/We offer a Bid Security of ……………… (Rupees ……….) to the Authority.

3.

I /We acknowledge that Arts & Culture Department, Government of Meghalaya,
hereinafter called ‘the Authority’ will be relying on the information provided in the Bid and
the documents accompanying the Bid for selection of the Concessionaire for the aforesaid
Project, and we certify that all information provided therein is true and correct: nothing has
been omitted which renders such information misleading; and all documents
accompanying the Bid are true copies of their respective originals.

4.

This statement is made for the express purpose of our selection as Concessionaire for the
aforesaid Project.

5.

I/We shall make available to the Authority any additional information it may find necessary
or require to supplement or authenticate the Bid.

6.

I/We acknowledge the right of the Authority to reject our Bid without assigning any
reasons or otherwise and hereby waive, to the fullest extent permitted by applicable law,
our right to challenge the same on any account whatsoever.

7.

I/We certify that in the last three years, we / any of our Consortium Members or our/ their
Associates have neither failed to perform on any contract, as evidenced by
imposition of a penalty by an arbitral or judicial authority or a judicial pronouncement or

Volume-I: Instructions to Bidders (ITB)

57 | P a g e

<!-- page 59 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

arbitration award, nor been expelled from any project of contract by any public authority
nor have had any contract terminated by any public authority for breach on our part.
8.

I/We declare that:
a. I/We have examined and have no reservations to the Bidding Documents, including
any Addendum issued by the Authority; and
b. I/We do not have any conflict of interest in accordance with the RFP document; and
c. I/We have not directly or indirectly or through an agent engaged or indulged in any
corrupt practice, fraudulent practice, coercive practice, undesirable practice or
restrictive practice, as defined in Section 5 of the RFP document, in respect of any tender
or request for Proposal issued by or any agreement entered into with the Authority or
any other public-sector enterprise or any government, Central or State; and
d. I/We confirm that I/we are not blacklisted with any Ministry or Department of the
Central Government, or by any of the State Governments / UT as on date. We further
confirm that we will inform the Authority immediately in case of any change in this
situation.; and
e. I/We hereby certify that we have taken steps to ensure that in conformity with the
provisions of Section 5 of the RFP, no person acting for us or on our behalf has engaged
or will engage in any corrupt practice, fraudulent practice, coercive practice, undesirable
practice or restrictive practice; and
f.
the undertakings given by us along with the Application in response to RFP for
the Project were true and correct as on the date of making the Application and are also
true and correct as on the Bid Due Date and I/we shall continue to abide by them

9.

I /We understand that you may cancel the Bidding Process at any time and that you are
neither bound to accept any Bid that you may receive not to invite the Bidders to Bid for
the Project, without incurring any liability to the Bidders, in accordance with the terms and
conditions of the RFP.

10. The Authority and its authorized representatives are hereby authorized to conduct any
inquiries / investigation to verify the statements, documents and information submitted in
connection with the Bid and to seek clarification from our banker regarding any financial
and technical aspects. This letter of Bid will also serve as authorization to any individual or
authorized representative of any institution referred to the supporting information, to
provide such information deemed necessary as requested by yourselves to verify
statements and information provided in the Bid or with regard to the resources, experience
and competence of the Bidder.
11. I/We believe that I/we satisfy the Technical Capacity and Financial Capacity for the Project,
and meet the requirements as specified in the RFP document.

Volume-I: Instructions to Bidders (ITB)

58 | P a g e

<!-- page 60 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

12. I /We declare that we/any Member of the Consortium, or out/its Associates are not a
Member of a/any other Consortium submitting a Bid for the Project.
13. I/We certify that in regard to matters other than security and integrity of the country,
we/any Member of the Consortium or any of our/their Associates have not been
convicted by a Court of Law or indicted or adverse orders passed by a regulatory authority
which could cast a doubt on our ability to undertake the Project or which relates to a grave
offence that outrages the moral sense of the community.
14. I/We further certify that in regard to matters relating to security and integrity of the
county, we/any Member of the Consortium or any of our/their Associate have not been
charge-sheeted by any agency of the Government or convicted by a Court of Law.
15. I/We further certify that no investigation by a regulatory authority is pending either against
us or against our Associates or against our CEO or any of our
directors/managers/employees.
16. I/We undertake that in case due to any change in fact or circumstances during the Bidding
Process, we are attracted by the provisions of disqualification in terms of the guidelines
referred to above, we shall intimate the Authority of the same immediately.
17. {I/We acknowledge and undertake that our Consortium will be selected based on the basis
of Technical Capacity and Financial Capacity of those of its Members who shall hold equity
share capital of not less than 26% (Lead Member and Non-Lead Member respectively) of
the subscribed and paid-up equity of the Concessionaire for a period of 5 years from COD,
and thereafter the Lead Member must hold a minimum equity share capital of 26% of the
subscribed and paid-up equity of the Concessionaire till the 10th anniversary of COD.} We
further agree and acknowledge that the aforesaid obligation shall be in addition to the
obligations contained in the Concession Agreement in respect of Change in Ownership
18. I /We acknowledge and agree that in the event of a change in control of Associates whose
Technical Capacity and/or Financial Capacity was taken into consideration for the
purposes of selection under and in accordance with the RFP, I/We shall inform the
Authority forthwith along with all relevant particulars and the Authority may, in its sole
discretion, disqualify us or withdraw the Letter of Award, as the case may be. I/We further
acknowledge and agree that in the event such change in control occurs after signing of the
Concession Agreement but prior to Financial Close of the Project, it would, notwithstanding
anything to the contrary contained in the Agreement, be deemed a breach of thereof and
the Concession Agreement shall be liable to be terminated without the Authority being
liable to us in any manner whatsoever.

Volume-I: Instructions to Bidders (ITB)

59 | P a g e

<!-- page 61 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

19. I/We understand that the Selected Bidder shall either be an existing Company incorporated
under the Indian Companies Act or shall incorporate prior to execution of the Concession
Agreement.
20. I/We hereby irrevocably waive any right or remedy which we may have at any stage at law
or howsoever otherwise arising to challenge or question any decision taken by the Bidding
Process itself, in respect of the above-mentioned Project and the terms and
implementation thereof.
21. In the event of my/our being declared as the Selected Bidder, I/we agree to enter into a
Concession Agreement in accordance with the draft that has been provided to me/us prior
to the Bid Due Date. We agree not to seek any changes in the aforesaid draft and agree to
abide by the same.
22. I /We have studied all the Bidding Documents carefully and also visited the Project. We
understand that except to the extent as expressly set forth in the Concession Agreement,
we shall have no claim, right or title arising out of any documents or information provided
to us by the Authority or in respect of any matter arising out of or relating to the Bidding
Process including the award of Concession.
23. The Bid / Proposal Security is enclosed in the Envelope–1 marked “Bid / Proposal Security”.
24. I/We agree and understand that the Bid is subject to the provisions of the Bidding
Documents. In no case, I /We shall have any claim or right of whatsoever nature if the
Project/Agreement is not awarded to me/us or our Bid is not opened or rejected.
25. The Bid Variable has been quoted by me/us after taking into consideration all the terms
and conditions stated in the RFP, draft Concession Agreement, our own estimates of cost
and demand and after a careful assessment of the site and all the conditions that may
affect the project cost and implementation of the Project.
26. I/We agree and undertake to abide by all the terms and conditions of the RFP document.
27. I/We shall keep this offer valid for 180 (one hundred and eighty) days from the Bid Due
Date specified in the RFP or extension thereof as per the RFP.
28. We, the Consortium Members agree and undertake to be jointly and severally liable for all
the obligations of the Concessionaire under the Concession Agreement till occurrence of
Financial Close in accordance with the Concession Agreement.
Authorized signatory

Date:

Name and seal of Bidder

Place:

Volume-I: Instructions to Bidders (ITB)

60 | P a g e

<!-- page 62 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Note: In case the Bidder is not a consortium, please delete the applicable clauses related to
Consortium.

APPENDIX-B. General Information of the Bidder
(To be printed on A4 paper and signed by the Bidder’s authorized signatory)
1. Details of Bidder (To be given separately by each Consortium member, in case the Bidder is a
Consortium)
a. Name:
b. Legal Status:
c. Country of incorporation:
d. Address of the corporate headquarters (if any) in India:
e. Year of Incorporation:
2. Details of individual(s) who will serve as the point of contact / communication for the Authority
within the Company:
a. Name:
b. Designation:
c. Company:
d. Address:
e. Telephone Number and Fax Number:
f. E-Mail Address:
3. Brief description of the entity including details of its main lines of business and proposed role and
responsibilities in this Project:
4. In case of Consortium:
a. Information above (1 -3) should be provided for all the members of the Consortium.
b. Information regarding role of each member should be provided:
Sl No
Name of Member
Equity Stake
1
2
3
4.
* Specify whether Lead Member / Ordinary Member

Role*

5. Details of Associates, whose credentials are counted as part of Minimum Eligibility Criteria:
6. The following information shall also be provided for Bidder/each member of the Consortium/
Associates:
Sl No
1

Criteria
Yes
Has the Bidder/ Consortium Member/Associate been barred by the

Volume-I: Instructions to Bidders (ITB)

No

61 | P a g e

<!-- page 63 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Sl No

2
3

Criteria
Yes
[Central/ State Government, or any entity controlled by it,] from
participating in any project (PPP or otherwise), and the bar subsists as
on the date of Application,
If the answer to 1 is yes, does the bar subsist as on the date of Bid?
Applicant including any Consortium Member or Associate should, in
the last 3 (three) years, have neither failed to perform on any
contract, as evidenced by imposition of a penalty by an arbitral or
judicial authority or a judicial pronouncement or arbitration award
against the Applicant, Consortium Member or Associate, as the case
may be, nor has been expelled from any project or contract by any
public entity nor have had any contract terminated any public entity
for breach by such Applicant, Consortium Member or Associate.

No

7. A statement by the Bidder and each of the members of its Consortium (where applicable) or any of
their Associates disclosing material non-performance or contractual noncompliance in past projects,
contractual disputes and litigation/ arbitration in the recent past is given below (Attach extra sheets, if
necessary):

Signed by:
(Name of the Authorised Signatory) For and on behalf of
(Name of the Bidder)
Designation
Place:
Date:

Volume-I: Instructions to Bidders (ITB)

62 | P a g e

<!-- page 64 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

APPENDIX-C. Affidavit
(To be executed on a Stamp Paper of INR 100; To be Notarized)
(To be given separately by each Consortium member, in case the Bidder is a Consortium)
I, _________, s/o _________, resident of _________, the _________ (insert designation) of the
_________ (insert name of the Bidder), do solemnly affirm and state as follows:
1.

2.

3.

4.

5.

6.

That I am the authorized signatory of _________(insert name of Company/ Consortium)
(hereinafter referred to as “Bidder / Consortium Member”) and I am duly authorized by the
bidder organization / Consortium to swear and depose this Affidavit on behalf of the bidder
organization / Consortium.
That I have submitted information with respect to our eligibility for the Request for Proposal
(RFP) for RFP for Development, Operation and Management of 5 Star Resort under Design,
Build, Finance, Operate and Transfer (DBFOT) Model, along with the Operation and
Maintenance of the Lariti Performing Centre on a Public–Private Partnership (PPP) Basis, at
Mawkasiang, New Shillong, Meghalaya (hereinafter referred to as “Project”) and I further state
that all the said information submitted by us is accurate, true and correct and is based on our
records available with us.
That, we hereby also authorize and request any bank, authority, person or firm to furnish any
information, which may be requested by the Authority to verify our credentials / information
provided by us under this tender and as may be deemed necessary by the Authority.
That if any point of time including the Concession Period, in case of the Authority, requests any
further / additional information regarding our Financial and / or Technical capabilities, or any
other relevant information, we shall promptly and immediately make available such information
accurately and correctly to the satisfaction of the Authority.
That, we fully acknowledge and understand that furnishing of any false or misleading information
by us in our RFP shall entitle us to be disqualified from the tendering process for the said Project.
The costs and risks for such disqualification shall be entirely borne by us.
That all the terms and conditions of the Request for Proposal (RFP) Document have been duly
complied with.

DEPONENT
(Name, Designation and Address)
VERIFICATION:
I, the above-named deponent, do verify that the contents of paragraphs 1 to 6 of this affidavit are true
and correct to my knowledge. No part of it is false and nothing material has been concealed.
Verified at __________, on this _________ day of _________, 2024.
DEPONENT
(Name, Designation and Address)

Volume-I: Instructions to Bidders (ITB)

63 | P a g e

<!-- page 65 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

APPENDIX-D. Power of Attorney
APPENDIX-D-1: Format for Power of Attorney for Authorized Signatory
(To be executed on a Stamp Paper of INR 100; To be Notarized)

Know all men by these presents, We___________________________________ (name of the firm and
address of the registered office) do hereby irrevocably constitute, nominate, appoint and authorize Mr/
Ms (name), __________________ son/daughter/wife __________________________and presently
residing at __________________, who is [presently employed with us/ the Lead Member of our
Consortium and holding the position of _________________________], as our true and lawful attorney
(hereinafter referred to as the “Attorney”) to do in our name and on our behalf, all such acts, deeds and
things as are necessary or required in connection with or incidental to submission of our Bid to Art &
Culture Department, Government of Meghalaya (“Authority”) for RFP for Development, Operation and
Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer (DBFOT) Model,
along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya (the “Project”) proposed or being
developed by the Authority including but not limited to signing and submission of all Bids and other
documents and writings, participate in Pre-Bids and other conferences and providing information/
responses to the Authority, representing us in all matters before the Authority, signing and execution of
all contracts including the Concession Agreement and undertakings consequent to acceptance of our
Bid, and generally dealing with the Authority in all matters in connection with or relating to or arising
out of our Bid for the said Project and/ or upon award thereof to us and/or till the entering into of the
Concession Agreement with the Authority.
AND we hereby agree to ratify and confirm and do hereby ratify and confirm all acts, deeds and things
lawfully done or caused to be done by our said Attorney pursuant to and in exercise of the powers
conferred by this Power of Attorney and that all acts, deeds and things done by our said Attorney in
exercise of the powers hereby conferred shall and shall always be deemed to have been done by us.
IN WITNESS WHEREOF WE, ____________________, THE ABOVE-NAMED PRINCIPAL HAVE XECUTED
THIS POWER OF ATTORNEY ON THIS ____ DAY OF ________, 20**

For………………………………………….

Accepted

…………………… (Signature)

(Name, Title and address) of the Attorney

Volume-I: Instructions to Bidders (ITB)

64 | P a g e

<!-- page 66 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Note:
i.
ii.

iii.

iv.
v.

To be executed by the sole Bidder or the Lead Member in case of a Consortium as the case may
be.
The mode of execution of the Power of Attorney should be in accordance with the procedure, if
any, laid down by the applicable law and the charter documents of the executant(s) and when it
is so required the same should be under common seal affixed in accordance with the required
procedure.
Wherever required, the Bidder should submit for verification the extract of the charter
documents and documents such as a resolution/ power of attorney in favor of the person
executing this Power of Attorney for the delegation of power hereunder on behalf of the Bidder.
For a Power of Attorney executed and issued in India, the notarization is to confirm that the
document was executed in the presence of a notary.
For a Power of Attorney executed and issued overseas, the document will also have to be
legalized by the Indian Embassy. However, the Power of Attorney provided by Bidders from
countries that have signed the Hague Legislation Convention 1961 are not required to be
legalized by the Indian Embassy if it carries conforming Apostille certificate.

Volume-I: Instructions to Bidders (ITB)

65 | P a g e

<!-- page 67 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

APPENDIX-D-2: Format for Power of Attorney for Lead Member of the Consortium
(To be executed on a Stamp Paper of INR 100; To be Notarized)

Dated --------POWER OF ATTORNEY
TO WHOMSOEVER IT MAY CONCERN
Whereas Arts & Culture Department, Government of Meghalaya, (the “Authority”) has invited Bids
from interested parties for “RFP for Development, Operation and Management of 5 Star Resort under
Design, Build, Finance, Operate and Transfer (DBFOT) Model, along with the Operation and
Maintenance of the Lariti Performing Centre on a Public–Private Partnership (PPP) Basis, at
Mawkasiang, New Shillong, Meghalaya” (the “Project”).
Whereas,______________, …………………….., ………………………… and ______________ (collectively the
“Consortium”) being Members of the Consortium are interested in bidding for the Project in accordance
with the terms and conditions of the Request for Proposal document (RFP)and other connected
documents in respect of the Project, and
Whereas it is necessary for the Members of the Consortium to designate one of them as the Lead
Member with all necessary power and authority to do for and on behalf of the Consortium, all acts,
deeds and things as may be necessary in connection with the Consortium’s bid for the Project and its
execution.
NOW THEREFORE KNOW ALL MEN BY THESE PRESENTS
We, ……………………………….. having our registered office at______________, [the name and address of
the registered office], M/s ……………………………….. having our registered office at______________, [the
name and address of the registered office] ……………………………….. having our registered office
at______________, [the name and address of the registered office], ……………………………….. having our
registered office at______________, [the name and address of the registered office],
(hereinafter
collectively referred to as the “Principal”) do hereby irrevocably designate, nominate, constitute,
appoint and authorize M/s_________________________ having its registered
office at
__________________, being one of the Members of the Consortium, as the Lead Member and true and
lawful attorney of the Consortium (hereinafter referred to as the “Attorney”). We hereby irrevocably
authorize the Attorney (with power to sub delegate)to conduct all business for and on behalf of the
Consortium and any one of us during the Bidding Process and, in the event the Consortium is awarded
the Concession/Contract, during the execution of the Project and in this regard, to do on our behalf and
on behalf of the Consortium, all or any of such acts, deeds or things as are necessary or required or
incidental to the submission of its bid for the Project, including but not limited to signing and submission
of all Bids, bids and other documents and writings, participate in bidders and other conferences,
respond to queries, submit information/ documents, sign and execute contracts and undertakings
consequent to acceptance of bid of the Consortium and generally to represent the Consortium in all its
dealings with MTDC and/ or the Authority, and/ or any other Government Agency or any person, in all
matters in connection with or relating to or arising out of the Consortium’s bid for the Project and/ or
upon award thereof till the Concession Agreement is entered into with the Authority.

Volume-I: Instructions to Bidders (ITB)

66 | P a g e

<!-- page 68 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

AND hereby agree to ratify and confirm and do hereby ratify and confirm all acts, deeds and things
lawfully done or caused to be done by our said Attorney pursuant to and in exercise of the powers
conferred by this Power of Attorney and that all acts, deeds and things done by our said Attorney in
exercise of the powers hereby conferred shall and shall always be deemed to have been done by us/
Consortium.
IN WITNESS WHEREOF WE THE PRINCIPALS ABOVE NAMED HAVE EXECUTED THIS POWER OF ATTORNEY
ON THIS _____ DAY OF _____20**

By
___________
[the Authorising Company]
Signature
___________
[Signature of Authorised signing
officer]
Name ___________
[Name of Authorised signing officer]
Title
___________
[Title of Authorised signing officer]

By
___________
[the Authorising Company]
Signature
___________
[Signature of Authorised signing
officer]
Name ___________
[Name of Authorised signing officer]
Title
___________
[Title of Authorised signing officer]

By
___________
[the Authorising Company]
Signature
___________
[Signature of Authorised signing
officer]
Name ___________
[Name of Authorised signing officer]
Title
___________
[Title of Authorised signing officer]

By
___________
[the Authorising Company]
Signature
___________
[Signature of Authorised signing
officer]
Name ___________
[Name of Authorised signing officer]
Title
___________
[Title of Authorised signing officer]

(Executants)

Witness 1
Signature ______
Name _________
Address_______

Witness 2
Signature ________
Name_________
Address_______

Note:
i.

To be executed by all the Members of the Consortium.

Volume-I: Instructions to Bidders (ITB)

67 | P a g e

<!-- page 69 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

ii.

iii.

iv.
v.

The mode of execution of the Power of Attorney should be in accordance with the procedure, if
any, laid down by the applicable law and the charter documents of the executant(s) and when it
is so required the same should be under common seal affixed in accordance with the required
procedure.
Wherever required, the Bidder should submit for verification the extract of the charter
documents and documents such as a resolution/ power of attorney in favor of the person
executing this Power of Attorney for the delegation of power hereunder on behalf of the Bidder.
For a Power of Attorney executed and issued in India, the notarization is to confirm that the
document was executed in the presence of a notary.
For a Power of Attorney executed and issued overseas, the document will also have to be
legalized by the Indian Embassy. However, the Power of Attorney provided by Bidders from
countries that have signed the Hague Legislation Convention 1961 are not required to be
legalized by the Indian Embassy if it carries conforming Apostille certificate.

Volume-I: Instructions to Bidders (ITB)

68 | P a g e

<!-- page 70 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

APPENDIX-E: Minimum Eligibility Criteria
GUIDELINES
1. The Statutory Auditor / Chartered Accountant issuing the certification for Experience of the
Bidder must hold a valid Certificate of Practice. The CA Certificate shall be accompanied with a
valid UDIN.
2. For conversion of US Dollars to INR, the rate of conversion shall be INR 80 (Eighty) to a US
Dollar. In case of any other currency, the same shall first be converted to US Dollars as on the
date 60 (sixty) days prior to the Bid Due Date, and the amount so derived in US Dollars shall be
converted into INR at the aforesaid rate. The conversion rate of such currencies shall be the
daily representative exchange rates published by the International Monetary Fund for the
relevant date.
3. Documentary evidence must be submitted along with the Proposal, to support Technical and
Financial Capacity claim, as per Clause 3.2.6.
4. Refer to the following format for establishing experience of Bidder.

Volume-I: Instructions to Bidders (ITB)

69 | P a g e

<!-- page 71 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

APPENDIX-E-1: Bid Response Sheet 1
Format for Technical Capacity
(To be submitted on A4 paper | To be signed by both Authorized Signatory and Statutory Auditor)

Technical Capacity: CRITERIA: A- Bidder with HOSPITALITY EXPERIENCE
Use the same format for Details of the Firm from Hospitality Sector
Details of Hotels/ Resorts:

Sl No

Name & Address of
Hotels/ Resorts

Owner Entity

No. of
Rooms

Operational
Date
(MM/YYYY)

Operational
Till
(MM/YYYY)

Total Period
of
Operations
(months)

1
2
3
4
5
6
7
….

Note:
1. Financial Years considered for the purpose of Technical Capacity shall be 2024-25, 2023-2024,
2022-23, 2021-22, 2020-21, 2019-20, 2018-19, 2017-18, 2016-17and 2015-16.
2. In case the credentials of an Associate of a Bidder are used, a certificate from a qualified
external auditor, who audits the book of accounts of the Bidder, shall be provided to
demonstrate that the person is an Associate of the Bidder.
3. The form may also be submitted separately for Consortium Members, with certification by
the respective statutory auditor of each Consortium Member. In such case, the Bidder must
also submit a summary sheet, with aggregate experience of all Consortium Members, signed
and verified by the Lead Member.
4. The following documentary evidence must be submitted along with the Proposal:
a. In support of the claimed experience, the Bidder (or each Consortium Member claiming
experience) should provide certificate(s) from its statutory auditor(s) stating the veracity
of the above experience.
b. Copy of the certificate for the star categorization of hotel issued by the Ministry of
Tourism, Government of India
c. It may be noted that in the absence of any detail in the above certificates, the
information would be considered inadequate and could lead to exclusion of the relevant
experience.
(Signature of Authorised Signatory)
Company seal & stamp

Volume-I: Instructions to Bidders (ITB)

70 | P a g e

<!-- page 72 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

Signature, Name, Address and Membership number of Statutory Auditor

APPENDIX-E-1: Bid Response Sheet 2
Format for Technical Capacity
(To be submitted on A4 paper | To be signed by both Authorized Signatory and Statutory Auditor)

Technical Capacity: CRITERIA: B – Bidder with CONSTRUCTION EXPERIENCE and Tie-up with
Operator from Hospitality Sector
The Bidder needs to submit the following:
► Table 1: To be submitted separately for each Consortium Member / Associate and certified by the
statutory auditor of the consortium member / Associate, Authorized Signatory, and the authorized
signing officer of the respective consortium member / Associate.
► Table 2: To be a summary form for all consortium members / Associates and certified by Authorized
Signatory.

TABLE- 1: Details of Eligible Projects: To be filled compulsorily in all cases
Sl
No
1
2
3
4
5
6
7
8
9

i
ii
iii
iv
v
vi
vii

Details

Project1

Project2

Project3

Projectn

Member Code (SE / LM / NLM-1 /NLM-2 )
Name and nature of the Project
Type: (Real Estate/ Core Sector)
Role-Developer/Prime contractor/ Subcontractor / Owner
Type of Project – PPP / EPC / Own Development
Project Location
Total Project cost (i.e. Construction Cost / CAPEX) (INR crore),
excluding cost of land
Value of Contract awarded to the entity claiming experience
(INR crore)
Total amount:
a) Developed/paid for development of Eligible Project(s)
b) Paid for or received payments for construction of
Eligible Project(s);
by the entity claiming experience, over last 10 financial years
(i.e. starting from 1st April 2014)
FY15-16
FY16-17
FY17-18
FY18-19
FY19-20
FY20-21
FY21-22

Volume-I: Instructions to Bidders (ITB)

71 | P a g e

<!-- page 73 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya
Sl
No
viii
ix
x

Details

Project1

Project2

Project3

Projectn

FY22-23
FY23-24

FY 24-25
TOTAL (A)

11
12

Date of commencement of Construction works
Date of Completion of construction works (Expected date in
case of ongoing projects)
Date of commencement of operations
Authority / Client for whom the project is carried out,
applicable
Equity holding at the time of execution/ construction, in case
the project is undertaken as part of a consortium or
partnership (with period during which the equity was held)
Details of Proof Submitted

13
14
15

16

Note:
1. Only the eligible projects that satisfy Criteria-B shall be included.
2. All the currency numbers are to be given in INR.
3. In case of the use of credentials of an Associate of a Bidder / Consortium Member, a certificate
from a qualified external auditor who audits the book of accounts of the Bidder, or the
Consortium Member shall be provided to demonstrate that the person is an Associate of the
Bidder or the Consortium Member, as the case may be.
4. The following documentary evidence must be submitted along with the Proposal, to support
Criteria-B claim:

a. PROOF OF PROJECT COST (As per ROW 7 of Table-1 above)
i.
ii.

A certificate from appropriate authorities / clients certifying project cost. OR
In case of owned projects, certificate from statutory auditor.

AND
b. PROOF OF EXPERIENCE AND ROLE (As per ROW 4,5 & 8 of Table-1 above)
i.
ii.
iii.

Letter of Award / Contract AND a certificate from appropriate authorities / clients certifying
other details not given in Letter of award / contract. OR
In case of owned projects, certificate from statutory auditor. OR
In case of Eligible Projects awarded under PPP / EPC mode:
Relevant pages of the work order / letter of award / contract / agreement. Relevant pages shall
mean the Preamble of such contract / agreement detailing the parties, section containing
information on project details like size / cost, and the last pages detailing the signatories.

AND

Volume-I: Instructions to Bidders (ITB)

72 | P a g e

<!-- page 74 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

c.

PROOF of AMOUNTS PAID FOR OR RECEIVED FOR DEVELOPMENT AND/OR
CONSTRUCTION (As per ROW 9 of Table-1 above)
► Certificate from statutory auditor OR
► Certificate from Client / project owning authority.

AND
d. AUDITED FINANCIAL STATEMENTS FOR EACH FINANCIAL YEAR.

(Signature of Authorized signing officer of the consortium member / Associate)
Company seal & stamp

(Signature of Authorized Signatory)
Company seal & stamp

Signature, Name, Address and Membership number of Statutory Auditor

Volume-I: Instructions to Bidders (ITB)

73 | P a g e

<!-- page 75 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

TABLE- 2A: If the Bidder/ Consortium fulfil CRITERIA B
Sl
No

Particulars

1
2
3

Proposed shareholding in the Consortium, if applicable
Total number of Eligible Projects, as per Table 1
Sum total of amount
a) Developed/paid for development of Eligible Project(s)
b) Paid for or received payments for construction of
Eligible Project(s);
(i.e. sum of Row [9] in Table 1 above
Sum total for the Bidder, across all Consortium
members (INR crore)

4

Single Entity/
Consortium
Lead Member

Consortium
Member-2

Consortium
Member-3

Note: Special Conditions for a Consortium
1) The Technical Capacity of the Bidder would be taken as aggregate of all members of the
Consortium, who hold and shall continue to hold at least 26% equity shareholding till 5 years
from COD.
2) The Technical Capacity of Associates can be taken into account while calculating Technical and
Financial Capacity of Bidders / member of Consortium.

(Signature of Authorized Signatory)
Company seal & stamp

Signature, Name, Address and Membership number of Statutory Auditor

Volume-I: Instructions to Bidders (ITB)

74 | P a g e

<!-- page 76 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

APPENDIX-E-2: Bid Response Sheet 2
Format for Financial Capacity
(To be submitted on A4 paper | To be signed by both Authorized Signatory and Statutory Auditor)

Financial Capacity
To be mentioned separately for each Consortium Member / Associate of Bidder
Financial Capacity

Single Entity/
Consortium Lead
Member

Consortium
Member-2

Consortium
Member-3

Associates,
if any

A. NET WORTH
st

Net Worth as of 31 March 2025
Aggregate Net Worth

B. TURNOVER
Turnover in 2020-21
Turnover in 2021-22
Turnover in 2022-23
Turnover in 2023-24
Turnover in 2024-25
Average Annual Turnover of (3 years of
the Last 5 Years in Crores)
Aggregate of Average Annual Turnover

Note:
1. All the Financial numbers are to be given in Indian Rupees.
2. In case of the use of credentials of an Associate of a Bidder, a certificate from a qualified
external auditor who audits the book of accounts of the Bidder shall be provided to
demonstrate that the person is an Associate of the Bidder.
3. The form may also be submitted separately for the Consortium Members, with certification by
the respective statutory auditor of each of the Consortium Members. In such case, the Bidder
must also submit a summary sheet, with aggregate average turnover and net worth of all
Consortium Members, signed and verified by the Lead Member.
4. The following documentary evidence must be submitted along with the Proposal, to support
Financial Capacity claim:
a)
The Bidder, or each Consortium Member / Associate claiming experience, shall attach
copies of the P&L, Balance sheet and Annual Reports for 5 (five) years preceding the Bid
Due Date. The financial statements must be:
a. be audited by a statutory auditor AND
b. be complete, including all notes to the financial statements.
b)

It may be noted that in the absence of any detail in the above certificates, the
information would be considered inadequate and could lead to exclusion of the relevant
experience.

Volume-I: Instructions to Bidders (ITB)

75 | P a g e

<!-- page 77 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

(Signature of Authorised Signatory)

Company seal & stamp

Signature, Name, Address and Membership No. of Statutory Auditor

Volume-I: Instructions to Bidders (ITB)

76 | P a g e

<!-- page 78 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

APPENDIX-E-3: Bid Response Sheet 3
Certificate from the Statutory Auditor regarding Associate
OPTIONAL – IN CASE THE BIDDER HAS USED CREDENTIALS OF ITS ASSOCIATES TO MEET TECHNICAL /
FINANCIAL CAPACITY
(To be printed on Letter Head)
Based on the authenticated record of the Company, this is to certify that more than 50% (fifty per cent)
of the subscribed and paid-up voting equity of ______ (name of the Bidder/ Consortium
Member/Associate) is held, directly or indirectly1, by ………………. (name of Associate/ Bidder/
Consortium Member). By virtue of the aforesaid shareholding, the latter exercises control over the
former, who is an Associate in terms of Clause 3.2.5 of the ITB.
A brief description of the said equity held, directly or indirectly, is given below:
……………….……………….……………….……………….……………….……………….

{Describe the shareholding of the Bidder/ Consortium Member and the Associate. In the event the
Associate is under common control with the Bidder/ Consortium Member, the relationship may be
suitably described and similarly certified herein.}

--Signature of Statutory Auditor of Bidder / Consortium Member

--Signature of Authorized signing officer of the consortium member, whose Associate is certified herein.

--Signature of Authorized Signatory

1

In the case of indirect shareholding, the intervening companies in the chain of ownership should also be Associates i.e., the
shareholding in each such company should be more than 50% in order to establish that the chain of “control” is not broken

Volume-I: Instructions to Bidders (ITB)

77 | P a g e

<!-- page 79 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

APPENDIX-F: Acknowledgement Letter
(To be submitted on Company’s Letter Head by Single Bidder / each Consortium members separately))

I _____________________________ (full name), s/o ___________________________________, the
__________________________________
(insert designation) of
the
___________________________________ (insert name of the single Bidder / Consortium member,
in case of a Consortium), state as follows :
a. Have reviewed the entire Proposal.
b. Proposal submitted is in accordance with each key element of the Proposal, including, but not
limited to, its Technical and Financial components, description of the member’s responsibilities and
commitments to the Project, and the designated person(s) who will represent the Consortium
during the negotiation process.
c. Have participated in only one Proposal for a given Project.
d. Each of the Consortium members will be jointly and severally liable to the Authority.
e. Acknowledges that the Authority reserves the right to reject any / all Proposals including the highest
Proposal or withdraw the invitation of the Proposal at any stage without citing any reason.

Authorised signatory

Date:

Name and seal of the Bidder

Place:

Volume-I: Instructions to Bidders (ITB)

78 | P a g e

<!-- page 80 -->

Development, Operation and Management of 5 Star Resort under Design, Build, Finance, Operate and Transfer
(DBFOT) Model, along with the Operation and Maintenance of the Lariti Performing Centre on a Public–Private
Partnership (PPP) Basis, at Mawkasiang, New Shillong, Meghalaya

APPENDIX-G: Acknowledgement Letter
(To be submitted on Company’s Letter Head by Single Bidder / Lead Member of the Consortium)

Ref.

Date:

To,
The Director
Directorate of Arts & Culture
Government of Meghalaya
I.G.P. Point, Ground Floor of the State Central Library Complex, Shillong, Meghalaya 793001
Phone No: +91 9774281282
Email: artsandculturemegh@gmail.com
Dear Sir,
We hereby confirm that we/ our members in the Consortium (constitution of which has been described
in the Proposal) satisfy the terms and conditions laid out in the RFP document.
We have agreed that ........................ (insert member’s name) will act as the Lead Member of our
Consortium.
We have agreed that ....................... (insert individual’s name) will act as our representative/ will act as
the representative of the Consortium on its behalf and has been duly authorized to submit the RFP.
Further, the authorized signatory is vested with requisite powers to furnish such letter and
authenticate the same.

Thanking you,

Yours faithfully,
(Signature, name and designation of the authorised signatory)
For and on behalf of..................................

Volume-I: Instructions to Bidders (ITB)

79 | P a g e
