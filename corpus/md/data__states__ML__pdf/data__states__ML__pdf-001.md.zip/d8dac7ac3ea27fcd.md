---
doc_id: "d8dac7ac3ea27fcd"
source_url: "https://megpolice.gov.in/sites/default/files/Circular38_2011.pdf"
ministry: "Home (Police) Department, Meghalaya"
title: "Circular No. 38/2011"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "50a6801deb3dedb6"
---

<!-- page 1 -->

/
OFFICE OF THE DIRECTOR GNEERAL & INSPECTOR GENERAL OF POLICE:
MEGHALAYA:::::: SlllLLONG.

C I R C U LA R N 0. 38/2011
Subject:-

CrPC (Amendment) Act. 2008 -Reg.

The amendments of some of the important sections of the CrPC as per the
CrPC Amendment Act, 2008 were notified by the Government of India vide S.O 3313 {E) dt 30th Dec, 2009 with
regard to the 30 important provisions of the CrPC.
It is essential that the police personnel at the cutting edge level of police
stations and outposts should be well conversant with these new changes in the law so that the law can be
enforced in a just and fair manner upholding the rights that are now given to the accused, complainant,
witnesses and victims of crimes.
Following are the operative parts of the aforesaid 30 amended provisions for
strict compliance. They have been simplified for an easy understanding. However, you are also instructed to
consult the new amended version of the CrPC.
New provisions regarding how arrest is to be made and other related subjects:

a.

Sub section 1 has been added to Section 46 relating to the power of arrest. Now the new Sec 46(1)
requires that where a woman has to be arres~ed, unless the circumstances indicate to the contrary,
her submission to custody on an oral intimation of arrest is presumed.

b. The other important provision is that unless the circumstances otherwise require or unless the police
officer is a female, the police officer shall not touch the person of the woman for making her arrest.

c.

Mandatory Medical examination of arrested person: - The old Section 54 has been
substituted by a new Section 54 which now requires that when any person is arrested
then soon after arrest is made, he shall be examined by a medical officer in the service of
Central or State Government.

It should be noted that in case such medical officer is not available the arrested person
can be examined by a registered medical practitioner.
However, If the arrested person is a female, the examination of her body shall be done
only by or under the supervision of a female medical officer and in case the female
medical officer is not available, then she can be examined by a female registered medical
practitioner.
Provision has been to the effect that the medical officer who conducts the examination of
the arrested person shall prepare the record of such examination, mentioning therein any
injuries or marks of violence upon the person arrested and the approximate time when
such injuries or marks may have been inflicted.
Where such medical examination is made, a copy of the report of such examination shall
be furnished by the medical officer or registered medical practitioner, as the case maybe,
to the arrested person or the person nominated by such arrested person.
Police officer investigating the case should see that such medical reports are actually
received by the arrested person of by the person nominated by such arrested persons to
rule out any allegation of police brutality or breach of law as prescribed above.
Production of ACCUSED in court or through vide linkage:
With the amendment to Sec 167 CrPC, detention in police custody of the accused will be
authorized only on the mandatory physical production of the accused in the court. This is
provided in the amended sub clause (b) of the proviso to Section 167 (2) .
Extension of detention in judicial custody can now be allowed by the court on the
production of accused either in person or through some electronic video media such as
video conferencing.
According to the new amendment, production of accused persons before the magistrates
directly or through the video linkage is to be proved by the signature of the accused on the
detention order or by the order certified by the magistrate as to the production of the
accused person through the medium of electronic linkage, as the case may be.
Electronic records of statement of witnesses:
The amended Section 161{3) says that the statement taken by the police will also include
recording by audio, video or electronic means.. Police now can prepare electronic record of
Instruction in the wake of the CrPC (Amendment Act, 2008}.

•

·--

·-

---------------------­

<!-- page 2 -->

the statement of witnesses under S.161, CrPC, in keeping with changes in the Indian
Evidence Act and Information Technology Act, 2000.
Section 164(1) has also been amended and according to the amended provision, electronic
recording by audio-video means of the statement/ confession recorded under the section
before a magistrate is permitted if it is done in the presence of the advocate of the person
accused of an offence.
Section 275 CrPC regarding recording of evidence of witnesses in warrant cases has been
amended and it allows the evidence to be recorded by audio/video means in the presence
of the advocate of the person accused of the offence.
Section 242, CrPC which deals with prosecution evidence in trial of warrant case instituted
on a police report by magistrates has been amended and now it provides that the
magistrate shall supply, in advance to the accused, the statements of witnesses recorded
by the police.
Insertion of witness statement in case diary :
The amendment to Section 172 makes it mandatory that the statement of witnesses
recorded during the course of investigation has now to be incorporated in the case diary.
Further, the case diary has to be well organized in a volume and that the case diary must
be paginated.
Special provisions for investigation of offences relating to women:
The amended Section 157 now prescribes that in relation to the crime of rape, the
statement of the victim shall be recorded at the residence of the victim or at the place of
her choice.
The recording of the statement as aforesaid, as far as practicable, should be done by a
woman police officer in the presence of her parents or guardians or near relatives or social
workers of the locality.
Importantly, as per the amended Section 173, the investigation of a case of rape of a child
may be completed within · 3 months from the date on which the information was recorded
by the officer in charge of a police station.
The final form as per Section 173(1)(g) must mention whether report of medical
examination of the woman has been attached where the investigation relates to an offence
under Section 376, and 376A to D of the IPC.
As regards Section 327 (2) relating to the "in camera" trial cases of offences under
Section 376, 376 A to D, the new amendment provides that "in camera" trial shall be
conducted as far as possible by a women judge or magistrate.
Section 327 (3) which bars printing/ publishing any matter in relation to such 'in camera'
proceedings except with the previous permission of the court has been relaxed and as
such the ban may be lifted but the names and addresses of the parties concerned must be
kept confidential.
Complaint in case of intimidation of witnesses:
A new sub section has been added to the Section 195 A in the Cr.PC, under

which a

witness or any other person can file a complaint in relation to threat by any person to give
false evidence prescribed U/S 195 A of the IPC.
Compounding of offences:
The scope of compounding offences under Sections 320 has been enhanced . The following
Section have been added to the list of offences which can now be compounded and the
permission of court for compounding is no longer required under the new amendment.

335, 243, 344, 346, 379, 403, 407, 411, 414, 417, 419, 421, 422, 423, 424, 428,
429, 430, 451, 482, 483 and 486.
Please note that Section 312 has been included in the list of offences . This implies that the
offence, under the said section can be compounded by the persons detailed in the tabl~
with the permission of Court before which such prosecution is pending.
S.354 has been deleted from the table of compoundable offences.
Instruction in the wake of the CrPC (Amendment Act, 2008}.
4
- ,~ .........WIUCIIC Met, LUUB).

<!-- page 3 -->

Who is a victim of crime? :
According to the new Section 2 (wa) a victim is defined as a person who has suffered any
loss or injury caused by reason of the act or omission for which the accused person has
been charged and the expression "victim" includes his or her guardian or legal heir.
Compensation to the victims of crimes:
According to the new Section 357A, the State Government in coordination with the Central
Government shall prepare schemes for providing funds for compensation to victims. On
recommendation of the Court for compensation, the District/ State Legal Services
Authorities are now to decide the quantum of compensation to be awarded to the victims.
This recommendation may be made if the compensation under Section 357 is considered
inadequate or when the victim needs rehabilitation :
Please note that even in cases where no trial is held and where the accused is not
identified or where the accused is untraced or if the case is undetected, under such
circumstances , an application can be filed by the victim or his dependents to the State/
District Legal Services Authorities, for award of compensation . The new law is that within 2
months the process from recommendation to the award after due enquiry, should be
completed.
The amendment in the law also empowers the State/ District Legal Services Authority to
pass order of immediate free first aid/ other medical facilities, or any other interim relief as
deemed fit in order to alleviate the suffering of the victim of crime on the certificate of the
police officer not below the rank of the officer in charge of a police station or the
mag istrate of the area concerned.

Sd/Director General of Police,
Meghalaya, Shillong.

***********
Dated Shillong the 11th April, 2011.
Memo No. MG/XII-985/2011/11
Copy to :1. The Addl. Director General of Police,(R/PR), Meghalaya, Shillon .
2. The Add. Director General of Police,(CID), Meghalaya, Shillong.
3. The..Addl. Director General of Police,(L&O), Meghalaya, Shillong
j-. · t'he Add I. Director General of Po lice,(SB), Meghalaya, Shillong.
For favour of kind
5. The Addl. Director General ofPolice,(F&ES),Meghalaya, Shillong.
lnfonnation.
6. The Add I. Director General of Police,(TAP), Meghalaya, Shillong.
The Inspector General of Pol ice,(TAP), Meghalaya, Shi !long.
The spector General ofPolice (R/PR), Meghalaya, Shillong.
1e Inspector General of Police (CID), Meghalaya, Shillong.
10 .The Inspector General of Police (SB), Meghalaya, Shillong.
11 . The Inspector General of Police (L&O), Meghalaya, Shillong.
12. The Dy. In spector General of Police (W/R), Meghalaya, Tura.
13. The Spl. Superintendent of Police, (CID), Meghalaya, Shillong.
14. The Superintendent of Police, East Khasi Hills, Shillong
15. The Superintendent of Police, South Garo Hills, Baghmara.
16. The Superintendent 9f Police, West Khasi Hills, Nongstoin.
17. The Superintendent of Police, Jaintia Hills, Jowai
18. The Superintendent of Police, West Garo Hill s, Tura.
19. The Superintendent of Police, Ri-Bhoi District, Nongpoh .
20. The Superintendent of Police, East Garo Hills, Williamangar
21. The Superintendent of Police, (SCRB), Meghalaya, Shillong for infor

For information and
necessary action.

tion and necessary posting in web.

**********
