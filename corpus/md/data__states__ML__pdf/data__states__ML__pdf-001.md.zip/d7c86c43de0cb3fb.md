---
doc_id: "d7c86c43de0cb3fb"
source_url: "https://megeducation.gov.in/edu_dept/notices_and_circulars/2026/MTET_Guidebook_%20Paper%20_%20II.pdf"
ministry: "Education Department, Meghalaya"
title: "MTET 2026 guidebook : Paper II  (PDF)   (opens in a new window)"
date: ""
pages: 360
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ab04830d6ca10501"
---

<!-- page 1 -->

i

<!-- page 2 -->

ii

<!-- page 3 -->

Message
Education is the most powerful tool we have to transform the future of Meghalaya. It is the foundation upon which our youth build their dreams and
the engine that drives our state’s progress. At the heart of this transformative
journey is the Teacher.
Under the Right of Children to Free and Compulsory Education (RTE) Act,
2009, quality education is now a Fundamental Right for every child. To ensure this right is upheld, the National Council for Teacher Education (NCTE)
has mandated the Teacher Eligibility Test (TET) as an essential qualification
for all elementary school teachers.
The Meghalaya Teacher Eligibility Test (MTET) 2026 is a significant milestone in our mission to enhance educational standards. The examination is
crucial as it includes aspiring candidates working toward fulfilling this mandatory professional requirement. By clearing the MTET, you are not only
complying with national standards but also reaffirming your commitment to
providing the best possible learning experience for our students.
This CM MTET Guidebook 2026 has been specifically designed to support
you in this journey. With its collection of model questions and practice materials, it serves as a practical tool to build your confidence and sharpen your
content knowledge and pedagogical skills required to excel in the examination.
As you prepare for this milestone, remember that your professional growth
contributes directly to a "Prosperous Meghalaya." By mastering these competencies, you are choosing a lifetime of service and mentorship that will shape
the calibre of our next generation.
I encourage you to approach your preparation with diligence and a deep
sense of purpose. I wish each of you the very best in your pursuit of excellence.

Sd/Conrad K. Sangma
Chief Minister of Meghalaya
15 April 2026

iii

<!-- page 4 -->

iv

<!-- page 5 -->

Message
It gives me immense pleasure to present this MTET Guidebook 2026. This
publication is more than just a study aid; it is a vital resource designed to
support you as you strive to enter one of the most impactful and noble
professions in our society.
In accordance with the Right of Children to Free and Compulsory Education
(RTE) Act, 2009, quality education is now recognized as a Fundamental Right
for every elementary learner. To uphold this standard, the National Council
for Teacher Education (NCTE) has established the Teacher Eligibility
Test (TET) as an essential qualification. Passing the MTET ensures that
our educators possess the foundational knowledge and pedagogical skills
necessary to provide our children with the high-quality learning experiences
they deserve.
This Guidebook has been meticulously curated by the Directorate of
Educational Research & Training (DERT). It provides a comprehensive
overview of the syllabus and includes model questions and practice
materials tailored to help you navigate the complexities of the examination
with confidence and clarity.
Whether you are beginning your journey or seeking to fulfil professional
requirements, your dedication to this process is a testament to your
commitment to the youth of Meghalaya. By mastering these competencies,
you are preparing to lead classrooms that will inspire curiosity and foster
excellence in the next generation.
I urge every aspirant to utilize this resource to its fullest potential. I wish you
every success in your preparation and look forward to your contributions to
the future of education in our state.

Sd/Lahkmen Rymbui,
Minister, i/c Education Department,
Government of Meghalaya
15 April 2026

v

<!-- page 6 -->

Paper- II
Content
Syllabus

1.

Child Development & Pedagogy

2.

Language – II (English)

3.

Mathematics & Science

4.

Social Science

5.

Language- I (Khasi/Garo)

Sl. No

Page No

1

Set- I

1

2

Set-II

38

3

Set-III

79

4

Set-IV

116

5

Set-V

155

6

Set-VI

193

7

Set- VII

232

8

Set-VIII

272

9

Set- IX

312

vi

<!-- page 7 -->

MEGHALAYA TEACHER ELIGIBILITY TEST
(MTET)

SYLLABUS FOR PAPER - II

vii

<!-- page 8 -->

MEGHALAYA TEACHER ELIGIBILITY TEST (MTET)
3

61. After reading
partCHILD
of a book, 30DEVELOPMENT
pages were left. How many pages
are there
in the book?
SYLLABUS
FOR
AND
PEDAGOGY
4
(a) 100
(b) 110(PAPER II : UPPER PRIMARY LEVEL)
(c) 120
(d) 130

Total Marks:
30many prime numbers are there between 100 and 120?
62. How

(a) 6 Development and Pedagogy syllabus for Class VI-VIII Level assesses teacher
The MTET Child
(b) 7
candidates’
of child development, inclusive education, learning theories and
(c)knowledge
5
(d) 4
assessment
methods. It aims to equip candidates with the skills needed to meet the
learning needs of students in Classes VI–VIII effectively.
63. The sum of the exponents of the prime factors in the prime factorization of 102 is
Key Competencies
(a) 2
(b) 3
The Child Development and Pedagogy syllabus for MTET aims to ensure that teacher
(c) 4
candidates
(d): 7
1.

2.

Demonstrate an understanding of growth and development during childhood and

64.
Three numbers are in the ratio 3 : 4 : 5 and their LCM is 2400. Find their HCF.
adolescence, along with the factors influencing development in diverse socio(a) 40
cultural
(b)
80 contexts.
(c) 120
Analyse various aspects of child development, including physical, cognitive, socio(d) 200
emotional and moral development and their implications for classroom learning.

3. 65.
Understand
the3rd
concept
genderJohn
development,
recognize
genderOnbiases
David has every
day off inof
November.
has every 5th day
off in November.
which in
date
for the first
time David
and John
have a day off
together? classroom approaches.
educational
practices
and
promote
gender-sensitive
(a) November 9
4. Apply
appropriate
(b) November
15 methods of child study, such as observation, portfolios, reflective
(c)
November
20 studies, to assess and document children’s progress.
journals and case
(d) November 30
5. Develop strategies to support inclusive education and effectively address the
6.
7.

learning needs of Children with Special Needs (CWSN).
A bag has ₹ 785 in the denominations of ₹ 2, ₹ 5 and ₹ 10 coins. The coins are in the ratio of
66.

6 : 9 : 10. How
many coins ofteaching-learning
₹ 5 are there in the bag?approaches (e.g., Piaget, Vygotsky)
Implement
constructivist
(a) 50
that
learner-centered pedagogy.
(b)prioritise
45
(c)diverse
40
Use
assessment techniques, including formative, summative and school(d) 35
based assessments, to evaluate student learning outcomes and provide remedial
measures.

67. The ratio of boys and girls in a school is 12: 5. There are 840 girls in the school. What is the
total number of students in the school?

Topics
(a) 1190

(b) 2380
(c) 2856
(d) 2586

1. Understanding Child
Development

Sub-Topics

• Meaning and concept of growth and development.
• Developmental characteristics of childhood and adolescence.
• Development of children in socio-cultural contexts and its
relationship to learning.
• Factors influencing development.
viii

<!-- page 9 -->

• Physical and motor development.
2. Aspects of
Developmen

• Cognitive development (Piaget’s theory of cognitive development).
• Socio-emotional development.
• Moral development (Kohlberg’s theory of moral development).
• Difference between gender and sex.
• Stages of gender development.

3. Gender Development

• Stereotypes in gender development.
• Gender bias and its influence on educational practices.
• Gender identity within families and in matrilineal societies.
• Cross-sectional, longitudinal and case studies.

4. Methods of Child
Study

• Naturalistic and participant observation.
• Reflective journals and student portfolios.
• Anecdotal records, interviews and narratives.
• Piaget’s clinical method of child study.
• Concepts and meaning of inclusive education.

5. Inclusive Education
• Difference between integrated and inclusive education.
and Children with
Special Needs (CWSN) • Understanding disabilities and types of disabilities.
• Barriers and challenges to inclusive education.
• Concept of learning and factors affecting learning.
• Information processing approaches: Working memory, longterm memory, attention, encoding and retrieval.

• Piaget’s

constructivism : Relationship between learning

and development.

• Vygotsky’s constructivism : Scaffolding and the Zone of
6. Learning and
Pedagogy

Proximal Development (ZPD.

• Teacher-centred
teaching.

vs.

learner-centred

approaches

to

• Teaching skills and activities for active learning.
• Steps

in

lesson

preparation:

Pre-teaching,

teaching

transactions, post-teaching (including lesson planning).

• Use of learning resources and teaching-learning materials
(TLMs).

ix

<!-- page 10 -->

• Concepts of assessment: Assessment for learning, assessment as learning and assessment of learning.
• School-Based Assessment (SBA.: Purpose, features and
techniques.
7. Assessment of

• Formative and summative assessment methods.

Students’ Performance • Tools and techniques for assessment: Activity-based assessments, observation, rubrics and achievement tests.
• Blueprint design and types of questions.
• Diagnosis of learning difficulties and strategies for remedial
teaching.
Essential Readings
1.

Understanding the Primary School Child, Basic Issues in Child Development – IGNOU.

2.

D.El.Ed Curriculum Meghalaya (2015). DERT, Government of Meghalaya, Shillong.

x

<!-- page 11 -->

MEGHALAYA TEACHER ELIGIBILITY TEST (MTET)
SYLLABUS FOR ENGLISH
PAPER II:
Total Marks: 30
The English syllabus for Classes VI–VIII is designed to assess candidates’ knowledge, skills
and pedagogical competencies to teach English at this level effectively. It emphasizes

developing language proficiency, applying pedagogical approaches and fostering
reflective and inclusive classroom practices.
Key Competencies
The English syllabus for the MTET aims to ensure that teacher candidates:
1.
2.
3.
4.
5.
6.
7.

Demonstrate a strong understanding of the constructivist approach to language

learning, including functional and social aspects of language.

Develop oral language skills through meaningful and activity-based strategies

that promote literacy and engagement.

Enhance reading skills by fostering comprehension across various text types and

contexts, including content-based and narrative texts.

Foster writing skills through purposeful and process-oriented approaches, making

connections between reading and writing.
Apply

effective

assessment

strategies

in

constructivist,

classrooms, including tools like portfolios and reflective journals.

process-oriented

Understand and address real classroom dynamics, including the influence of

multilingualism, the role of mother tongue and the status of English in India.

Demonstrate proficiency in language comprehension, grammar and verbal ability,

including interpreting unseen passages and applying grammatical concepts
effectively
Topics

1. Functional Aspects of
Language

2. Oral Language
Development

Sub-Topics

• What is language ? Purpose and meaningful use of language.
• Social context of language: Influence of mother tongue,
multilingual classrooms and the status of English in India.
• Strategies for oral language development: Activities for
developing extempore speech.
• Communicative Competence in children -roleplay, recitation,
storytelling, debates, extempore speech, etc
• Developmental stages of reading and writing.
xi

<!-- page 12 -->

• Types of reading: Reading across the curriculum (contentbased and narrative texts).
3. Reading Skills

• Role of schema in reading comprehension.
• Reading beyond textbooks: Encouraging critical engagement
with diverse texts

4. Writing Skills

5. Assessment in
Language Learning
7. Language
Comprehension and
Grammar

• Writing as a process and purpose-driven activity: Emphasis
on audience, purpose and process over product.
• Connecting reading and writing to reinforce comprehension
and creativity.
• Process-oriented assessment in constructivist classrooms :
Evaluating content over form and structure.
• Use of portfolios and reflective journals for ongoing
evaluation.
• Reading unseen passages (prose/poetry) for comprehension
and inference.
• Composition and grammar: Application of grammatical
rules in writing and speaking.

Essential Readings
1.

D.El.Ed Curriculum Meghalaya (2015). DERT. Government of Meghalaya: Shillong.

2.

Hunsakes, R.A. (1990) Understanding and Developing the Skills of Oral Communication:

3.

Parrot. M. (1993) Tasks for Language Teachers Cambridge: Cambridge University

4.

Crystal, D (1999) The Cambridge Encyclopaedia of the English Language. Cambridge

Speaking and listening, 2nd edition, New York, NY.

Press: Cambridge.

University Press : Cambridge.

xii

<!-- page 13 -->

MEGHALAYA TEACHER ELIGIBILITY TEST (MTET)
SYLLABUS FOR MATHEMATICS
PAPER II
Total Marks: 30
The Mathematics syllabus for Paper II evaluates candidates’ knowledge, understanding and

pedagogical skills in mathematics for teaching Classes VI-VIII. It emphasizes developing
mathematical thinking, problem-solving abilities and practical applications in real-life
scenarios.

Key Competencies
The Mathematics syllabus for the MTET aims to ensure that teacher candidates:
1.
2.
3.

Understand the foundational structure of mathematics, including axioms,

definitions, conjectures, proofs and counterexamples.

Relate mathematical concepts taught in the classroom to real-life applications

and foster practical problem-solving skills.

Utilise appropriate teaching methods (e.g., inductive-deductive, problem-

solving, project-based learning) to make mathematical concepts engaging and
accessible.

4.
5.
6.
7.

Incorporate ICT tools and resources into teaching to enhance students’

mathematical understanding.

Apply effective assessment and evaluation techniques to measure students’

progress and provide constructive feedback.

Appreciate and Utilise community mathematics programs and resources to

promote collaborative learning and local context integration.

Demonstrate proficiency in key mathematical concepts, including numbers,

geometry, algebra and statistics and their relevance to real-world contexts.

Topics

1. Foundations of
Mathematics

Sub-Topics

• Building blocks of mathematics : Definitions, axioms,
conjectures, proofs and counter examples.
• Place of Mathematics in the school curriculum.
• Mathematics outside the classroom: Relating mathematical
concepts to daily life.

xiii

<!-- page 14 -->

2. Teaching Methods in
Mathematics

• Methods of teaching mathematics: Inductive-Deductive,
Analysis-Synthesis, Problem-solving, Project-based learning
and Discovery methods.
• ICT tools and resources: Learning apps, software and
interactive tools for teaching mathematics.
• Community Mathematics: Using local resources and
collaborative programs to enhance learning.

3. Assessment and
Evaluation

• Assessment techniques: Formative and summative
assessments and tools for evaluating mathematical
understanding and application.
• Natural numbers, whole numbers, integers and rational
numbers.

4. Number Systems

• Prime and composite numbers, divisibility, factors and
multiples.
• Finding LCM and HCF and their applications in real-life
problem- solving.

5. Ratio and Proportion

• Concepts of ratio and proportion and their applications.
• Introduction to algebra: Variables, coefficients and constants.

6. Algebra

• Linear equations and algebraic identities e.g., (a ± b.2, (a2b2) and their applications.
• Lines, angles, triangles and their properties.

7. Geometry

• Symmetry: Reflection, line of symmetry and symmetrical
figures.
• Area and perimeter of triangles, rectangles, parallelograms
and circles, including applications.

8. Statistics and Data
Handling

• Measures of central tendency: Mean, median and mode.
• Bar graphs: Reading, interpreting and representing data
graphically.

xiv

<!-- page 15 -->

MEGHALAYA TEACHER ELIGIBILITY TEST (MTET)
SYLLABUS FOR SCIENCE
PAPER II
Total Marks: 30
The MTET Science syllabus for this Level (Classes VI–VIII) is designed to assess the knowledge,

skills and pedagogical competencies of teacher candidates. It emphasizes conceptual

understanding, application of scientific knowledge and innovative teaching strategies
appropriate for the Upper Primary level.
Key Competencies
The Science syllabus for MTET aims to ensure that teacher candidates:
1.
2.
3.
4.
5.
6.

Understand the nature of science and its key aspects, including scientific knowledge,

inquiry and attitudes.

Apply the objectives of science education as outlined in the NCF 2005, focusing on

holistic and contextual learning.

Use effective assessment techniques to monitor and support students’ progress,

including remedial teaching.
Employ

innovative

teaching-learning

approaches

such

as

observation,

experimentation and concept mapping to connect science to real-life scenarios.

Utilise diverse teaching-learning resources, including local materials, ICT, field trips

and science exhibitions, to foster a deeper understanding of scientific concepts.

Demonstrate a comprehensive understanding of key scientific concepts, including

motion, heat, light, states of matter and biological processes in plants and animals.
Sub-Topics

Topics

Nature of Science

Scientific knowledge and inquiry.
Scientific methods and attitudes.

Learning Objectives Aims and objectives of teaching Science as outlined in NCF 2005.
Assessment

Types, purpose, tools and techniques of assessment in Science.
Remedial teaching strategies.

Approaches to
Teaching-Learning

Observation, experiment, hands-on activities and concept
mapping.
Application of inquiry-based and experiential learning methods.
xv

<!-- page 16 -->

Teaching-Learning
Resources

Local resources, ICT, textbooks, laboratories, films and field trips.
Organization of science exhibitions and use of visual aids.

Science Content
Areas

Motion: Different views and principles of motion.
Heat and Temperature: Concepts and applications.
Light and Electricity: Understanding basic principles and their reallife implications.
States of Matter: Properties and applications of solids, liquids and
gases.
Acids, Bases and Salts: Identification, properties and their
applications.
Water and Air: Properties and their importance in daily life.
Plant and Animal Cells: Structure and functions.
Biological Processes: Nutrition, respiration, locomotion and
movement in plants and animals.

Essential Readings
•

D.El.Ed Curriculum Meghalaya (2015). DERT. Government of Meghalaya: Shillong.

•

MBOSE textbooks for Science (classes VI to VIII)

xvi

<!-- page 17 -->

MEGHALAYA TEACHER ELIGIBILITY TEST (MTET)
SYLLABUS FOR SOCIAL SCIENCE
PAPER II
Total Marks: 30
The MTET Social Science syllabus for this Level (Classes VI–VIII) assesses candidates’

understanding of key concepts, historical and geographic knowledge, civic principles
and pedagogical strategies. It emphasizes critical thinking, reflective learning and
interdisciplinary teaching approaches.
Key Competencies
The Social Science syllabus for MTET aims to ensure that teacher candidates :
1.
2.

Understand the nature and scope of Social Science, including their distinct purposes

and integration in the school curriculum.

Apply a variety of pedagogical strategies, such as inquiry-based learning,

cooperative learning and contextualization teaching, to make Social Science
engaging and meaningful.

3.
4.

Demonstrate proficiency in historical, geographic, political and economic concepts,

including local, national and global contexts.

Utilize diverse learning resources, including print, non-print and digital media, to

enhance the teaching-learning process.

5. Design and apply effective assessment tools and techniques, including formative,
summative assessments and to evaluate student understanding.

6.

Relate Social Science concepts to real-life scenarios, promoting active citizenship

and critical thinking in learners.

Sub-Topics

Topics

1. Nature and
Scope of
Social Science

• Concept of Social Science.
• Differences between Social Science and Social Science.
• Aims of Social Science Education.
• Approaches in Social Sciences: Systematic and Regional Approach.
• Traditional and Modern Approach.
• Reconstruction of History through evidences.
• Inter-Disciplinary Approach.
• Theme based approach.
• Inquiry and Reflective Approach.
xvii

<!-- page 18 -->

2. Pedagogical
Strategies

• Oral Histories.
• Issue based learning.
• Co-operative Learning.
• Experiential Learning.
• Concept Mapping and Mind Mapping.
• Discovery Learning.
• Problem Solving.
• Contextualization.
• Inquiry learning.
• Digital Pedagogy.

3. Learning
Resources

• Print; Non-Print; Digital Learning Resources.

• Formative and Summative Assessment.
4. Assessment
for Social Sci• Assessment Techniques and Tools.
ence
• Recording, Reporting and Documentation of assessment outcomes.
5. Social Science
Knowledge

History
• Sources of History.
• Earliest civilizations.
• The Mughal Empire in India.
• Indian National Movements and Contributions of Tirot Sing, Kiang
Nangbah and Pa Togan Sangma in the Indian National Movement.
• Partition, Transfer of Power and Making of the Indian constitution.
• Hill State Movement in Meghalaya.
Civics
• The Indian Constitution: Preamble and Salient Features of Indian Constitution.
• Organs of the Government.
• Forms of Government: Democracy (Direct, Indirect and Representative
Democracy) and Dictatorship.
• Structure of Government: Unitary and Federal, Parliamentary and
Presidential Government.
• Concept of Nation and State.
• Social Structure and Social Stratification.
xviii

<!-- page 19 -->

• Community and Socio-Political groups.
• Government for Development.
• Understanding Media.
Geography
• Map: Features and Types.
• The Earth and its Movements.
• Rocks and Minerals.
• Weather and Climate.
• Drainage system.
• Oceans Currents.
• Physical features of India G Meghalaya.
• Resources of India (Land and soil, Water, Forest, Minerals).
• Agriculture of India G Meghalaya.
• Manufacturing Industries of India.
• Transport and Communication of India.
• Demography of India and Meghalaya.
Economics
• Sectors of the Indian Economy.
• Understanding Banking; Types of Accounts.
• Understanding Banking; Types of Accounts.
Essential Readings
•

Pedagogy in Social Sciences by S.K. Mangal and U. Mangal.

•

D El Ed Curriculum, DERT, 2015.

•

MBOSE Social science Textbooks.

•

NCERT Social Science Textbooks.

•

Source Books on Assessment for Classes VI-VIII.

•

Pedagogy in Social Sciences, NISHTHA, NCERT Officials

Additional Readings
•

National Curriculum Framework-School Education-2023.

•

National Curriculum Framework-2005.

•

Learning Curve, Azim Premji Foundation.

•

Coded Learning Outcomes (Social Science), DERT Publication.
xix

<!-- page 20 -->

MEGHALAYA TEACHER ELIGIBILITY TEST (MTET)
SYLLABUS FOR KHASI
PAPER II
Total Marks: 30
This syllabus is designed to assess the knowledge, skills and pedagogical competencies

of teacher candidates for teaching Khasi at the Upper Primary Level (Classes VI to VIII).

It emphasizes developing language proficiency, applying pedagogical approaches and
fostering reflective and inclusive classroom practices.
Key Competencies
The MTET Khasi Paper II syllabus aims to assess the following key competencies in teacher
candidates :
•
•
•
•
•
•
•

Ka jinglah ban shemphang ia ka jingthoh prous bym pat ju iohi da kaba pyniasnoh

bad ki jait skima ba u nongpule u la don lypa.

Ka jinglah ban shemphang ia ka jingthoh poitri bym pat ju iohi da kaba pyniasnoh

bad ki jait skima ba u nongpule u la don lypa.

Ka jingtip bad jingsngewthuh kumno ban pyndonkam ia ka skima bad kumno ka

jabieng ka leh haba ngi pyrshang ban sngewthuh ia kaei kaei kaba ngi pule.

Ka jingtip bad jingsngewthuh ia ki jait jingthoh ba bunjait bad kumno ki iapher

kawei na kawei pat.

Ka jingtip bad jingsngewthuh ia ki rukom hikai ba bun jait ba dei ban pyndonkama

katkum ki jait lynnong.

Ka jingnang ban pynshongdor ia ka jinglah jong ki khynnah da kaba pyndonkam

ia ki buit bad tiar pynshongdor kiba iahab katkum ki khep.

Ka jingtip bad jingsngewthuh ia ki jinglong tynrai jong ka ktien Khasi.
Topics

Sub-Topics

• Ka jingthoh bym pat ju Ban jubab ia ki jingkylli ba la ai halor ka jingthoh prous kaba ym
iohi (unseen passage pat ju iohi.
Ka skima (schema. – Kaei ka skima, ki jait skima, rukom
• Ka poim bym pat ju pyndonkam ia ka haba pule kot,
iohi (unseen poem)
kumno u nonghikai u tei ia ka ha ki nongpule, kumno u khynnah
u pyndonkam ia ka.
Ki rukom shemphang ia ka jingthoh ba ngi pule: Top-down
model, Bottom-up model bad Interactive model.

Ki jait bad rukom pule ia kano kano ka jait jingthoh – Summarizing,
Skimming, Scanning, Know-Want-Learnt (KWL), SurveyQuestion- Read- Write and Recite (SQ3R), note- taking,
think aloud.
xx

<!-- page 21 -->

Ki rukom thoh ba bun jait: Ki jait jingthoh creative, expository,
• Ki
bynta
kiba
summarizing,
arguing/persuading,
narrating,
iasnoh bad ka expressive,
j i n g p y r s h a n g evaluating, analyzing, responding, examining/investigating, thoh
sngewthuh ia kaei
shithi, thoh application, thoh notice, pyndap form.
ba ngi pule
Ki rukom hikai ba bun jait ha ka kyrdan Upper Primary
• Ki
rukom
thoh
jingthoh
ha
ki Ka plan hikai
kyrdan ba kham
Ka mind mapping bad concept mapping
shalor
Ki tiar iarap hikai

• Kumno ban hikai ia Continuous and comprehensive evaluation
ka ktien
Ki buit (techniques) thew jingtip – Observation, Oral testing,
Written Test, Practical work

Ki tiar (tools) ban thew jingtip ha ka jingnang ia ka ktien: Port-folio,
Questionnaire, Check-list, Rubric, Observation schedule,
Rating scale, Anecdotal records worksheet, homework,
project work

• Ki
rukom
thew Ka Kramar
jingtip
bad 		 1. Ki adverb
pynshongdor
		 2. Ki dak sangeh
3.

Ka rukom pyndonkam ia kajuh ka kyntien ha ka dur jong ka
Noun ne ka Berb ne kiwei pat ki jait klas kyntien.

Ki jinglong tynrai jong ka ktien

1.

Ki Sur sawa ha ka Ktien Khasi

2. Ki Ktien Kynnoh

3. Ki Ktien phawer pharshi

4. Ki Ktien ba iajan jingmut/Ïapher jingmut

• Ka kramar bad ki
jinglong tynrai jong
ka ktien Khasi
Essential Reading :
•

D.El.Ed Curriculum Meghalaya (2015). DERT, Government of Meghalaya, Shillong.

•

Khasi textbooks (Classes VI to VIII) prescribed by MBOSE.

xxi

<!-- page 22 -->

MEGHALAYA TEACHER ELIGIBILITY TEST (MTET)
SYLLABUS FOR GARO
PAPER II
Total Marks: 30
This syllabus is designed to assess the knowledge, skills and pedagogical competencies

of teacher candidates for teaching Garo at the Upper Primary Level (Classes VI to VIII).
It emphasizes developing language proficiency, applying pedagogical approaches and
fostering reflective and inclusive classroom practices.
Key Competencies
The MTET Garo Paper II syllabus aims to assess the following key competencies in teacher
candidates :
•

Schemani gimin tale u·ia aro uko jakkale poraiae u·iani aro miksonganiko bikotna

sapa.

•

Poraianio tarisamsoaniko name ma·sie uko nangani kri jakkalna sapa.

•

Sentenceara maia, uni niamrangko aro maidakgipa bewalrango jakkala uko u·ie

•

ra·na man·a.

Dingtang dingtang skiani bewalrang aro skina tarisamsoanirangko jakkale prose

aro poetryko skiani bewalrangko jakkalna sapa.

•

Dingtang dingtang seani bewalrangko masie ra·na man·a.

•

Continuous aro Comprehensive Evaluation-o pangchake dingtang dingtang

•

porikka ra·ani cholrangko u·ie jakkalna sapa.

Songsalo agan-me·apa aro Katta Ku·jikseko maikai somoini kri jakkale uarangni

ning·tugipa miksonganirangko aro bewalrangko u·ie ra·ani
Topics

• Poraie u·iani aro
miksonganiko bikotaniSchema theory

Sub-Topics

•

Miksongani (meaning)

•

Schemako jakkalani (activating Schema. Schemako
ong·atani (building Schema.

•

KWL

•

See ra·aniko tariani (Note- taking)

•

•
• Poraianina tarisamsoani

•
•
•

Kam (role)

SQ3R

Kan·dike agangopani (Summarising)
Skimming
Scanning

Miksonganiko bikotaniko mesokna skigipani gam·e
chanchiani
xxii

<!-- page 23 -->

• Grammarko skiani

Poraianio tarisamsoaniko name ma·sie uko nangani kri
jakkalna sapa.

• Dingtang dingtang skiani
bewalrang aro skina

tarisamsoanirangko jakkale
maikai prose aro poetryko

Sentenceara maia, uni niamrangko aro maidakgipa
bewalrango jakkala uko u·ie ra·na man·a.

skigen.

• Curriculumko ga·bate

Seani (writing across the
curriculum)

• Porikka niani (Assessment):
Continuous aro Comprehensive Evaluation

• A·chik ku·siko bikote seani
(Composition)

Dingtang

dingtang

skiani

bewalrang

aro

skina

tarisamsoanirangko jakkale prose aro poetryko skiani
bewalrangko jakkalna sapa.
Continuous
pangchake

aro

Comprehensive

dingtang

dingtang

cholrangko u·ie jakkalna sapa.
Songsaloagan-me·apa
maikai

somoini

kri

aro

jakkale

Evaluation-o

porikka

Katta

uarangni

ra·ani

Ku·jikseko

ning·tugipa

miksonganirangko aro bewalrangko u·ie ra·ani

Essential Readings :
1.

A·chik Grammar, E.G. Philips, M.A, Tura Book Room, West Garo Hills, Meghalaya.

2.

Handbook on Continuous and Comprehensive Evaluation: Directorate of Educational
Research G Training (DERT). Meghalaya, Shillong.

3.

A·chik Composition by Keneth M. Momin. Tura Book Room, Tura

4.

D.El.Ed Curriculum Meghalaya (2015) DERT, Government of Meghalaya: Shillong.

5.

Garo Textbooks (Classes VI to VIII) prescribed by MBOSE.

xxiii

<!-- page 24 -->

MEGHALAYA TEACHER ELIGIBILITY TEST (MTET)
SYLLABUS FOR HINDI
PAPER II
Total Marks: 30
This syllabus is designed to assess the knowledge, skills and pedagogical competencies
of teacher candidates for teaching Hindi at the Upper Primary Level (Classes VI to VIII).
It emphasises developing language proficiency, applying pedagogical approaches and
fostering reflective and inclusive classroom practices.
Key Competencies
The MTET Hindi Paper II syllabus aims to assess the following key competencies in teacher
candidates :
•

Hindi Bhasa main sahitya ke vibhinna vidhaon/rupon jaise kavita, kahani nivandh,
lekh aur natak aadi ko samajh kar padh sakenge aur apne rai, vichar, bhav aadi ko
tarkik rup main maukhik, sanketik evam likit roop main abhivyakth kar sakenge.

•

Bhasha Kaushal ke vibhinna rupon ke prabhavi vikas aur Hindi vyakarna ki samajh
se sahi aur prabhavshali bhasha paryog main sahayak aur saksham honge.
Topics

Unit I: PADYA

1. Pushpa Ki Abhilasha

2. Christmas ka Bara Din
3. Basanti Hawa

4. Krishna Ki Chetavani
Unit II: GADYA

1. Namak Ka Daroga
2. Galta Loha

3. Bharatmata

4. Adarsh Mahila-Sita

Unit III: Vyakaran Aur Rachana
1. Bhasha Kaushal Vikas
2. Sarvanam
3. Visheshan
4. Kriya

5. Sandhi

6. Paryayavachi Shabda
7. Vilom Shabda

8. Muhavare Aur Lokoktiyan
Essential Readings :
•
D.El.Ed Curriculum Meghalaya (2015). DERT, Government of Meghalaya, Shillong.
•
Hindi textbooks (Classes VI to VIII) prescribed by MBOSE.
xxiv

<!-- page 25 -->

MEGHALAYA TEACHER ELIGIBILITY TEST (MTET)
SYLLABUS FOR ASSAMESE
PAPER II
Total Marks: 30
This syllabus is designed to assess the knowledge, skills and pedagogical competencies of
teacher candidates for teaching Assamese at this Level (Classes VI to VIII). It emphasizes
developing language proficiency, applying pedagogical approaches and fostering
reflective and inclusive classroom practices.
Key Competencies
The MTET Assamese Paper II syllabus aims to assess the following key competencies in
teacher candidates :
•

Asamiya bhasha aru Asamat basabas kara bibhinna janagosthir bishaye jyan
labh Kariba pariba

•

Asamiya sahityar Jonaki jugar bibhinna sahittikar sahittik nidarshan samparke
jyan labh Kariba pariba

•

Matribhashar prayojaniyata aru iyar upajogitar bishaye buji paba

•

Natta Bidhi aru Shatta Bidhir niyam samuh jani loi iyaksuddhakoi byabahar Kariba
pariba

•

Sandhir bibhinna prakarsamuhar bishaye jani loi Asamiya bhasha kaote aru likhote
nar Shuddha byabahar Kariba pariba

•

Pratay samparke jani loi iyar Shuddha byabahar Kariba pariba
Topics

Sub-Topics

Asamiya bhasha aru Asamar

a. Asamiya bhashar Parichay

janagosthi

b. Asamar bibhinna janagosthisamuhar parichay

Asamiya Sahityar Buranji [Jonaki

Lakkhinath Bejbaruah, Chandra Kumar Agarwala,

jug]

Hemchandra Goswami ittadi (all others sahittik)

Matribhashar prayojaniyata aru
upajogita
Shraban, Kirtan,Pathan,Likhan,
Uccharan adir dharana

xxv

<!-- page 26 -->

Natta Bidhi aru Shatta Bidhi

Natta Bidhi aru Shatta Bidhir niyamsamuh

Sandhi prakaran

Swar sandhi,Byanjan sandhi,Bisarga sandhi

Pratay

Krit pratay,Taddhit pratay

Essential Readings
•

D.El.Ed Curriculum Meghalaya (2015) DERT, Government of Meghalaya: Shillong.

•

Assamese Textbooks (Classes VI to VIII) prescribed by MBOSE.

•

Asamiya Sahityar Samikkhatmak Itibrita, by Satyendranath Sharma

•

Asamiya matribhashar sikkhan paddhati by Haliram Das

•

Bhashabijyan by Upendranath Goswami

xxvi

<!-- page 27 -->

MEGHALAYA TEACHER ELIGIBILITY TEST (MTET)
SYLLABUS FOR BENGALI
PAPER II
Total Marks: 30
This syllabus is designed to assess the knowledge, skills and pedagogical competencies
of teacher candidates for teaching Bengali at the Upper Primary Level (Classes VI to VIII).
It emphasizes developing language proficiency, applying pedagogical approaches and
fostering reflective and inclusive classroom practices.
Key Competencies
The MTET Bengali Paper II syllabus aims to assess the following key competencies in teacher
candidates:
1.

Exhibit understanding of the constructivist approach in language learning.

2.

Promote reading skills and comprehension across various texts, types and contexts.

3.

Foster writing skills purposefully.

4.

Display proficiency in applying grammatical concepts effectively.
Topics

• Dhwani paribartan

Sub-Topics

a. Swarsangati,

Swarbhakti,

Apinihiti,

Abhishruti

Bomobiparjoy Swaragam, Bornodwitto, Samibhabon.

• Sandhi Bicched
• Sadhubhasa theke cholita bhasay O Chalita theke sadhu bhasay paribartan.
• Somaccharita Bhinnartak
Shobdo
• Arthasaha Bagdhara
• Shabda bhandar
• Samas

Tatsama Shabda, Tadbhaba Sabda, Ardha Tatsama
Shabda
Byas bakya soha somar nirnoy

• Bakya Songkochon (Ek Kothay Prakash)

xxvii

<!-- page 28 -->

• Sahityik Parichiti

Ishwarchandra Vidyasagar, Micheal Madhusudan Dutta
Rabindranath Thakur, Kazi Nazrul Islam, Sharat Chandra
Chattopadhyay, Tarashankar Bondyapadhyay Shanka
Gosh.

• Nirbachita Gadya O Padya Gadya
•

Postmaster -by Rabindranath Tagore

•

Samudrer swadh-by Manik Bandyopadhaya

•

Bharatbassha-by S. Wazed Ali

•

Padya

•

Bharat tirtha- Rabindranath Tagore

•

kandari hushiyar- Nazrul Islam

•

Banglar mukh- by Jibonananda Dash

Essential Readings
•

D.El.Ed Curriculum Meghalaya (2015). DERT, Government of Meghalaya, Shillong.

•

Nepali textbooks (Classes VI to VIII) prescribed by MBOSE.

xxviii

<!-- page 29 -->

MEGHALAYA TEACHER ELIGIBILITY TEST (MTET)
SYLLABUS FOR URDU
PAPER II
Total Marks: 30
This syllabus is designed to assess the knowledge, skills and pedagogical competencies of
teacher candidates for teaching Urdu at this Primary Level (Classes VI to VIII). It emphasizes
developing language proficiency, applying pedagogical approaches and fostering
reflective and inclusive classroom practices.
Key Competencies
The MTET Urdu Paper II syllabus aims to assess the following key competencies in teacher
candidates :
•

To understand and reflect on objectives of language teaching in terms of language
skills-listening and speaking, reading, writing, grammar vocabulary and so on.

Topics

[A] Language
comprehension

Sub-Topics

Unseen passages :
Two passages one prose or drama and one poem with

questions on comprehensions,inference,grammer and
verbal ability (prose passage may be literary,scientific
or discursive)

[Gair nazri iqtabasat padhna] : 2 ektibas,ek nasar ya
drama aur ek nazm jis me tafheem,maakhaj,qawaid
aur zabani salahiyaton per mubni sawalaat pooche
jayenge.(nasri

iqtibaas,

istadaali ho sakta hai

xxix

adbi,scienci,wazahati

ya

<!-- page 30 -->

[B]. Pedagogy of Language Zaban ki nash-o-nama ka ilm Tadrees:
Development:
1. Learning and acquisition (aamojash aur iktisab /
hasuli)

2.

Principles of language teaching (tadrees zaban ke

3.

Role of listening and speaking, function of language

asool nazaryat)

and how children use it as a tool. (sunne aur bolne

ka kirdar,zaban ka kaam,aur bache zaban ko bator
waseela kaise istemal karte hain)
4.

Critical perspective on the role of Urdu grammar

in learning a language for communicating ideas
verbally and in written form. (zabani aur tehreeri taur

per khiyalaat ki tarseel keliye zaban ki aamojash me
qawayed ke kirdaar ka tanquidi pehlu)
5.

Challenges of teaching urdu language in a diverse

classroom, language difficulties, error and disorder

(kaseer laasani zamayat me zaban ki tadrees ke
masail, zaban ki pecheedgiyan, galtiyan aur naqayes)
6.

Language skills (zabani maharatein)

7.

Evaluating language comprehension and proficiency:
speaking, listening, reading and writing Urdu language.

(zaban ki tafheem aur salahiyat ka andaj-o-qadar
karna,urdu adab sunna,bolna,parhna aur likhna.
8.

Teaching-Learning material: Textbook, multi- media,

material, multilingual resource of the classroom.

(Tadreesi, aamojashi, mawad dari kitaab, multimedia
mewaad, class room ke kaseer laasani wasayal.)
9.

Remedial teaching. (islaahi tadrees)

Essential Readings
•

Urdu textbooks (Classes VI to VIII) prescribed by MBOSE.

xxx

<!-- page 31 -->

MEGHALAYA TEACHER ELIGIBILITY TEST (MTET)
SYLLABUS FOR MIZO
PAPER II
Total Marks: 30
This syllabus is designed to assess the knowledge, skills and pedagogical competencies
of teacher candidates for teaching Mizo at the Upper Primary Level (Classes VI to VIII).
It emphasises developing language proficiency, applying pedagogical approaches and
fostering reflective and inclusive classroom practices.
Key Competencies
The MTET Mizo Paper II syllabus aims to assess the following key competencies in teacher
candidates :
•

read, and learn to seek information, gain knowledge and learn how to apply
in practical life. Helps them to know and understand the meaning of life and
responsibility.

•

help in reciting poems, words, poetical words and phrases, learn more words,
pronunciation, correct reading and knowledge.

•

use and learn correct words and grammatically correct sentences. Helps to know
more new words and knowledge.
Topics

Prose

Sub-Topics

1.

Sihchangnei i thawnthu

3.

Thailungi

5.

Nungcha

1.

Lawmthu Kan Hrilh Che

3.

Aw Chhandamtu Sual Leh Buaina Karah -

2.

4.
6.
Poetry

2.

4.
5.

6.
Grammar

Zuk leh hmuam
Ho Mai Mai

Liandova te unau

Bei La, Beinawn Rawh
Tlawmngaihna Hlu

Kanu Hmangaihna Aw Nern Chuan
Zotui Thiang Te

1.

Gender

2.

Comprehension
xxxi

<!-- page 32 -->

Essential Readings
•

Thanseia-MBSE

•

R.C.Thanga-MBSE

•

C. Saikhuma-MBSE Zosapthara-MBSE Suakliana-MBSE Thanga-MBSE Rokunga- MBSE

•

C. Chhuanvawra-MBSE Kaphleia- MBSE

•

Lettu-Biakliana-MBSE

•

Mizo School textbooks (Classes VI to VIII) prescribed by MBOSE.

M.S.Dawngliana-MBSE

xxxii

<!-- page 33 -->

Paper- II
(Set-I)
Content
1.

Child development & Pedagogy

2.

Language – II (English)

3.

Mathematics & Science

4.

Social Science

5.

Language- I (Khasi/Garo)

xxxiii

<!-- page 34 -->

xxxiv

<!-- page 35 -->

Child Development & Pedagogy-II
SET – 1
1.

What is the primary role of teacher in a child- centered classroom?
a.
To lecture and impart knowledge
b.
To facilitate and guide learning
c.
To discipline and control students
d.
To evaluate and grade performance

2.

Which of the following is a formative assessment technique?
a.
Quiz
b.
Annual exam
c.
Final project
d.
Semester – end test

3.

The Kohlberg’s theory of moral development focuses on:
a.
Equality and fairness
b.
Justice and rights
c.
Freedom and just
d.
World Peace

4.

Which of the following is a key factor influencing a child’s language development?
a.
Genetics alone
b.
Environmental stimulation
c.
Birth order
d.
All of the above

5.

What is the term for the process of providing temporary support and guidance to help a child
learn a new concept or skill?
a.
Scaffolding
b.
Modelling
c.
Conditioning
d.
Reinforcement

6.

Which of the following stages of development starts from the on- set of puberty to the age of
maturity (generally from 13 to 19 years)?
a.
Infancy stage
b.
Childhood stage
c.
Adolescent stage
d.
Adulthood

7.

According to Jean Piaget’s theory, which stage of cognitive development is characterized by the
ability to think logically about concrete objects and events?
a.
Sensorimotor Stage (0-2 years)
b.
Preoperational Stage (2-7 years)
c.
Concrete Operational stage (7-11 years)
d.
Formal Operational Stage (11 years and up)
1

<!-- page 36 -->

8.

What is the primary focus of the ‘Zone of Proximal Development’ (ZPD. concept, as proposed
by Lev Vygotsky?
a.
Individualized instruction
b.
Standardized testing
c.
Social interaction and scaffolding
d.
Independent learning

9.

What is the primary difference between ‘sex’ and ‘gender’?
a.
Sex refers to social roles, while gender refers to biological characteristics
b.
Sex refers to biological characteristics, while gender refers to social and cultural roles
c.
Sex and gender are interchangeable terms
d.
Sex is about personality, while gender is about physical traits

10.

What is the term for a research method where a researcher studies a child’s behavior in a natural
setting, like a playground or classroom?
a.
Case study
b.
Survey
c.
Naturalistic observation
d.
Experimental design

11.

What is the main difference between integrated and inclusive education?
a.
Integrated education focuses on special needs, while inclusive education focuses on general education
b.
Integrated education involves placing students with disabilities in regular classrooms,
while inclusive education involves adapting the curriculum to meet diverse needs
c.
Integrated education is for students with disabilities, while inclusive education is for all
students
d.
Integrated education is a more recent concept than inclusive education

12.

How can teachers effectively use learning resources to support diverse learning needs?
a.
By using only digital resources
b.
By adapting resources to suit different learning styles
c.
By using only textbook resources
d.
By ignoring student’s feedback

13.

What is the purpose of writing learning objectives in a lesson plan?
a.
To confuse students
b.
To outline the teacher’s schedule
c.
To specify what students should achieve by the end of the lesson
d.
To list the topics to be covered

14.

What is the main purpose of using rubrics in assessment?
a.
To make grading more subjective
b.
To clarify expectations and grading criteria
c.
To reduce student anxiety
d.
To increase teacher workload
2

<!-- page 37 -->

15.

According to Erik Erikson’s theory of psychosocial development, what is the primary conflict
that children face during the ‘Industry vs. Inferiority’ stage (around 6-12 years)?
a.
Trust vs. Mistrust
b.
Autonomy vs. Shame and doubt
c.
Initiative vs. Guilt
d.
Learning new skills vs. Feeling inadequate

16.

Which of the following statements best describes the nature of Growth?
a.
It is a lifelong process that continues until death.
b.
It refers to qualitative changes in an individual.
c.
It is a physical process referring to quantitative changes like height and weight.
d.
It cannot be measured accurately.

17.

The Proximodistal trend of development refers to growth that proceeds from:
a.
Head to toe
b.
General to specific
c.
The centre of the body outward to the extremities
d.
Concrete to abstract thinking

18.

In terms of motor development, Childhood is the best time for a child to learn new skills like
swimming or cycling because:
a.
Their bodies are less flexible.
b.
They have high levels of physical plasticity and a natural urge for activity.
c.
They have reached full adult height.
d.
They are not yet capable of social interaction.

19.

Which developmental characteristic is most common during early adolescence?
a.
High levels of self-consciousness and concern about physical appearance.
b.
Preference for playing with toys over social interaction.
c.
Absolute obedience to authority without question.
d.
Minimal interest in peer approval.

20.

Development in socio-cultural contexts” means a teacher should:
a.
Ignore the child’s home background and focus only on textbooks.
b.
Recognize how family, community, and culture shape a child’s learning behaviours.
c.
Treat every child exactly the same regardless of their environment.
d.
Focus only on the biological aspects of growth

21.

The Zone of Proximal Development (ZPD. suggests that learning is most effective when:
a.
A child works strictly alone to build independence.
b.
The task is far beyond the child’s current reach.
c.
The task is something the child can do with the guidance of a “More Knowledgeable
Other” (MKO).
d.
The child is only given tasks they have already mastered.

3

<!-- page 38 -->

22.

In a matrilineal society, such as those often found in Meghalaya, a child’s Socio-Cultural Context
may specifically influence their identity through:
a.
Only biological inheritance from the father.
b.
Lineage and inheritance patterns traced through the mother.
c.
A lack of any gender roles.
d.
Strict isolation from community traditions.

23.

Which environmental factor is most critical during the Pre-natal stage of development?
a.
The child’s peer group in the future.
b.
The mother’s nutritional and emotional state.
c.
The availability of digital learning resources.
d.
Exposure to environmental toxins or teratogens.

24.

A child’s “Socio-Economic Status” (SES) is an example of which type of influence?
a.
Biological influence.
b.
Environmental/Social influence.
c.
Genetic influence.
d.
Maturational influence.

25.

The Cephalocaudal law of physical development states that development proceeds from:
a.
Centre of the body to the extremities.
b.
The feet upwards to the head.
c.
The head downwards to the toes.
d.
General movements to specific movements.

26.

In the context of the classroom, why is it important for a teacher to understand motor development?
a.
To predict the child’s future career.
b.
To design age-appropriate physical activities and writing tasks.
c.
To ignore children who develop slowly.
d.
To focus only on academic grades.

27.

According to Piaget, the process of taking in new information into our previously existing schemas is known as:
a.
Accommodation
b.
Assimilation
c.
Equilibrium
d.
Organization

28.

Piaget’s Clinical Method of child study primarily involves:
a.
Large-scale standardized testing.
b.
Flexible, open-ended interviewing and observation of children’s reasoning.
c.
Biological brain scanning.
d.
Purely statistical analysis of school grades.

4

<!-- page 39 -->

29.

The Socialization process in childhood is best defined as:
a.
The biological growth of the brain.
b.
The process by which children learn the values, beliefs, and customs of their society.
c.
The ability to solve complex mathematical problems.
d.
The transition from liquid to solid food.

30.

Empathy, a key component of socio-emotional development, refers to the ability to:
a.
Feel sorry for yourself when things go wrong.
b.
Understand and share the feelings of another person.
c.
Follow school rules only when being watched.
d.
Memorize social etiquette from a textbook.
***************

Answer Keys:
Question No

Answer

Question No

Answer

Question No

Answer

1

b

11

b

21

c

2

a

12

b

22

b

3

b

13

c

23

b

4

d

14

b

24

b

5

a

15

d

25

c

6

c

16

c

26

b

7

c

17

c

27

b

8

c

18

b

28

b

9

b

19

a

29

b

10

c

20

b

30

b

5

<!-- page 40 -->

SET 1
Paper II
Language II ENGLISH
Choose the correct option.
31.

32.

33.

Children construct knowledge about the world around thema.

by playing games

b.

by singing songs

c.

through recitations

d.

through meaningful interactions with others

Children learn languagea.

without explicit instruction

b.

artificially

c.

when taught grammar explicitly

d.

Above options are all correct

Who gave the following definition of language?
“We can define language as a system of communication using sounds or symbols that enables
us to express our feelings, thoughts, ideas, and experiences”

34.

35.

36.

a.

Edward Sapir

b.

E. Bruce Goldstein

c.

Noam Chomsky

d.

Ferdinand de Saussure

When an individual satisfies the need by asking for something, this function of language is a.

Heuristic

b.

Interactional

c.

Instrumental

d.

Regulatory

For effective language learning on the part of children a.

teacher needs to teach songs

b.

teacher should teach them grammar every day

c.

teacher needs to provide them ample space and opportunity

d.

teacher should always make children write essays

Language that is learned naturally in the home environment is a.

the school language

b.

the mother tongue

c.

English

d.

Hindi
6

<!-- page 41 -->

37.

38.

39.

40.

41.

42.

43.

Home language influences the learning of second language.
a.

Partially correct

b.

Not Correct

c.

Correct

d.

Correct in few cases.

One of the effective strategies to manage multilingual classroom is a.

segregation of students who cannot speak the school language

b.

scaffolding

c.

exposure trip

d.

forcing children to speak the school language

The term ‘Standard Language’ may be referred to as a.

the English language

b.

the language spoken by large number of people

c.

the language used by educated people

d.

the dialect which is chosen and standardised for formal usage.

Awareness of print happens in the following developmental stage of reading
a.

Transitional reading stage

b.

Early Reading stage

c.

Emergent Pre-reading stage

d.

Intermediate reading stage

Which Education Commission and Policy suggested that “English should be the most useful library language in higher education and our most significant window on the world”?
a.

National Education Policy, 2020

b.

The Kothari Commission, 1964-66

c.

National Policy on Education, 1986

d.

Above options are all correct.

Which of the following options is not related to activities for oral language development of children?
a.

Oral requests and commands

b.

Conversation

c.

Analysing

d.

Story telling

Content literacy meansa.

Writing across the curriculum

b.

Reading across the curriculum

c.
d.

Summarisation
Extensive reading
7

<!-- page 42 -->

44.

Which of the following does not come under authentic reading material ?
a.
Journals
b.
Newspaper
c.
Blogs
d.
Textbooks

45.

The smallest sound unit in a language is called a.
Diphthongs
b.
Segmentation
c.
Phonology
d.
Phoneme

46.

Background knowledge of different text types and genres is referred to as a.
Linguistic schemata
b.
Content schemata
c.
Formal schemata
d.
None of the above options is correct.

47.

The main purpose of writing across the curriculum is to–
a.
encourage students to write with correct grammar.
b.
motivate students to write with appropriate punctuation marks.
c.
encourage students express their ideas, thoughts and feelings using their own creativity
and originality in writing.
d.
encourage students to write stories.

48.

Which of the following is not related to the process of writing?
a.
Prewriting
b.
Transcription
c.
Writing
d.
Rewriting

49.

Assessment of both Scholastic and co-scholastic areas of learning is termed as a.
Portfolio
b.
Observation
c.
Comprehensive evaluation
d.
All round assessment technique

50.

Continuous process of assessment may also be referred to as a.
Summative assessment
b.
Assignment
c.
Class test
d.
Formative Assessment

51.

Which is the correct order of the following words?
“Rome was a day not built in”
a.
Rome was built in a day
b.
Rome was built not in a day
c.
Rome was built in days
d.
Rome was not built in a day
8

<!-- page 43 -->

52.

After a long discussion, I prevailed ________ him to accept the proposal.
a.
on
b.
against
c.
upon
d.
above

53.

Choose the correct Indirect speech of the sentence below:
He said, “Alas! I am ruined.”
a.
He exclaimed with regret that I am ruined.
b.
He exclaimed sadly that he was ruined.
c.
He said sadly that he was ruined.
d.
He said Alas that he was ruined.

54.

The cafeteria is filled with litter and sweaty customers, _______________ ?
a.
is she
b.
aren’t she
c.
are they
d.
isn’t it

55.

John _______________ in the library this morning.
a.
is study
b.
studying
c.
is studying
d.
are studying

56.

I agree _______________ your brilliant idea.
a.
on
b.
with
c.
in
d.
for

57.

The boy _______________ mother writes poems speaks Chinese.
a.
who
b.
whom
c.
which
d.
whose

58.

My hens lay _______________eggs every morning.
a.
several
b.
a large amount
c.
more
d.
much number of

9

<!-- page 44 -->

59.

“I am reading a book” Here, the word ‘reading’ isa.
A present participle
b.
A verb
c.
A noun
d.
A gerund

60.

“Reading is my hobby”. Here, the word ‘reading’ isa.
A present participle
b.
A verb
c.
A noun
d.
A gerund

SET 1
Answer Key
QUESTION
NUMBER

ANSWER
KEY

QUESTION
NUMBER

ANSWER
KEY

QUESTION
NUMBER

ANSWER
KEY

31.

d

41.

b

51.

d

32.

a

42.

c

52.

c

33.

b

43.

a

53.

b

34.

c

44.

d

54.

d

35.

c

45.

d

55.

c

36.

b

46.

c

56.

b

37.

c

47.

c

57.

d

38.

b

48.

b

58.

a

39.

d

49.

c

59.

b

40.

c

50.

d

60.

d

10

<!-- page 45 -->

MATHEMATICS PAPER II
SET I
61.

A teacher asks students to justify their answers. This develops:
a.
Memorization
b.
Reasoning ability
c.
Speed
d.
Drill

62.

The inductive method proceeds from:
a.
General to specific
b.
Specific to general
c.
Easy to difficult
d.
Known to unknown

63.

Which assessment helps improve learning during teaching?
a.
Summative
b.
Formative
c.
Placement
d.
Diagnostic

64.

A child repeatedly makes the same mistake. The teacher should:
a.
Ignore
b.
Punish
c.
Diagnose error
d.
Give homework

65.

Which of the following is NOT a mathematical skill?
a.
Estimation
b.
Visualization
c.
Guessing randomly
d.
Generalization

66.

Best method for teaching geometry is:
a.
Lecture
b.
Activity-based
c.
Drill
d.
Dictation

67.

Learning by doing is emphasized in:
a.
Lecture method
b.
Project method
c.
Drill method
d.
Explanation method
11

<!-- page 46 -->

68.

Which tool helps in teaching graphs effectively?
a.
Blackboard
b.
ICT tools
c.
Notebook
d.
Chalk

69.

Formative assessment focuses on:
a.
Ranking
b.
Certification
c.
Improvement
d.
Grading

70.

Mathematics learning should be:
a.
Rote-based
b.
Fearful
c.
Meaningful
d.
Mechanical

71.

Peer learning helps in:
a.
Isolation
b.
Collaboration
c.
Memorization
d.
Punishment

72.

Teaching should connect with:
a.
Textbook only
b.
Real life
c.
Exams
d.
Homework

73.

ICT tools help in:
a.
Reducing learning
b.
Enhancing understanding
c.
Confusing students
d.
Memorization

74.

Which of the following is NOT formative assessment?
a.
Quiz
b.
Observation
c.
Final exam
d.
Assignment

75.

Children learn best through:
a.
Fear
b.
Punishment
c.
Activity
d.
Strict supervision
12

<!-- page 47 -->

76.

Which strategy helps conceptual clarity?
a.
Rote learning
b.
Explanation with activity
c.
Drill only
d.
Homework only

77.

Teaching aids are used to:
a.
Save time
b.
Enhance learning
c.
Replace teacher
d.
Reduce syllabus

78.

Which of the following promotes critical thinking?
a.
Memorization
b.
Problem-solving
c.
Copying
d.
Drill

79.

Assessment should be:
a.
Punitive
b.
Continuous
c.
Occasionally
d.
Random

80.

A teacher gives feedback regularly. This improves:
a.
Classroom discipline
b.
Learning
c.
Competating spirit
d.
Stress

81.

Smallest natural number is:
a.
0
b.
1
c.
-1
d.
2

82.

HCF of 12 and 18 is:
a.
3
b.
6
c.
12
d.
18

83.

Two bells ring every 15 minutes and 20 minutes respectively. When will they ring together again?
a.
30 min
b.
45 min
c.
60 min
d.
90 min
13

<!-- page 48 -->

84.

A prime number has:
a.
1 factor
b.
2 factors
c.
3 factors
d.
Infinite factors

85.

Which of the following is a rational number?
a.
√2
b.
π
c.
1/2
d.
√3

86.

“If a class of 48 students is split into equal groups, which of these group sizes is impossible to
create without having an incomplete row?
a.
6 rows
b.
8 rows
c.
7 rows
d.
12 rows

87.

A student says 1/3 = 0.3. The correct explanation is:
a.
It is exact
b.
It is approximation
c.
It is wrong
d.
It is irrational

88.

Which of the following is a composite number?
a.
7
b.
11
c.
9
d.
13

89.

Ratio of 4:8 in simplest form is:
a.
1:2
b.
2:1
c.
4:1
d.
8:4

90.

A recipe uses sugar : flour = 1:4. For 20 kg flour, sugar needed is:
a.
4 kg
b.
5 kg
c.
6 kg
d.
10 kg

14

<!-- page 49 -->

Answer Key
Question

Answer

Question

Answer

Question

Answer

61

b.

71

b.

81

b.

62

b.

72

b.

82

b.

63

b.

73

b.

83

c.

64

c.

74

c.

84

b.

65

c.

75

c.

85

c.

66

b.

76

b.

86

c.

67

b.

77

b.

87

b.

68

b.

78

b.

88

c.

69

c.

79

b.

89

a.

70

c.

80

b.

90

b.

15

<!-- page 50 -->

Science Paper – II
SET - I
91.

A plant cell can be differentiated from an animal because of the presence of
a.
cell membrane
b.
nucleus
c.
cell wall
d.
ribosomes

92.

During photosynthesis, solar energy is converted into
a.
hydro energy
b.
kinetic energy
c.
thermal energy
d.
chemical energy

93.

The state animal of Meghalaya is
a.
Neofelis nebulosa
b.
Nycticebus bengalensis
c.
Felis bengalensis
d.
Felis chaus

94.

The digestive fluid bile is produced in _____
a.
pancreas
b.
liver
c.
gall bladder
d.
duodenum

95.

Unlike other animals, cows and buffaloes have a special digestive organ that helps to break down
tough cellulose and plants fibers. The name of this specific organs is
a.
omasum
b.
esophagus
c.
reticulum
d.
rumen

96.

Which of the following is the odd one?
a.
lungs.
b.
gills.
c.
skin.
d.
liver.

97.

The growing of parts of a plant towards water is known as
a.
phototropism
b.
hydrotropism
c.
geotropism
d.
thigmotropism
16

<!-- page 51 -->

98.

Which of the following will not help in the conservation of biodiversity?
a.
encouraging the conservation of local species of plants.
b.
use of organic manures and pesticides.
c.
practicing of mix farming.
d.
extensive use of exotic species.

99.

Living organisms are made up of basic structural and functional unit called ,
a.
atoms
b.
molecules
c.
cells
d.
tissues

100. Aerobic respiration takes place in the presence,
a.
CO2
b.
O2
c.
H2
d.
N2
101. Which of the following is a transparent material?
a.
Mirror
b.
b. Glass tumbler
c.
Stainless steel plate
d.
Water bottle
102. The process of separation of lint from seeds is called:
a.
Harvesting
b.
Weaving
c.
Ginning
d.
Spinning
103. Which component of food is known as body-building food?
a.
Carbohydrates
b.
Fats
c.
Proteins
d.
Vitamins
104. The method used to separate insoluble solid particles from a liquid is:
a.
Evaporation
b.
Sedimentation
c.
Filtration
d.
Decantation
105. Which acid is present in our stomach to help in digestion?
a.
Sulphuric acid
b.
Hydrochloric acid
c.
Nitric acid
d.
Citric acid
17

<!-- page 52 -->

106. The image formed by a plane mirror is always:
a.
Real and inverted
b.
Virtual and inverted
c.
Virtual and erect
d.
Real and erect
107. The transfer of heat in liquids occurs by:
a.
Conduction
b.
Convection
c.
Radiation
d.
Insulation
108. The process of turning sugar solution into alcohol is called:
a.
Nitrogen fixation
b.
Fermentation
c.
Pasteurization
d.
Distillation
109. Which of the following is an inexhaustible natural resource?
a.
Coal
b.
Petroleum
c.
Sunlight
d.
Natural gas
110. The SI unit of force is:
a.
Joule
b.
Pascal
c.
Newton
d.
Watt
111. A common device used to measure temperature is:
a.
Thermometer
b.
Barometer
c.
Speedometer
d.
Ammeter
112. The movement of water and nutrients in plants occurs through:
a.
Stomata
b.
Xylem
c.
Phloem
d.
Root hair
113. Which of the following is a magnetic material?
a.
Plastic
b.
Aluminum
c.
Iron
d.
Wood
18

<!-- page 53 -->

114. Which of the following is an exhaustible natural resource?
a.
Sunlight
b.
Coal
c.
Air
d.
Wind
115. The SI unit of pressure is
a.
Newton
b.
Joule
c.
Pascal
d.
Watt
116. The nature of science isa.
Tentative, empirical requiring observation and interpretation.
b.
To study living and non-living organisms in the environment.
c.
It consists of a set of facts, principles and theories.
d.
Related to a collection of viewpoints made by scientists.
117. Etymologically the word “Scientia” meaning Science has been derived froma.
Greek
b.
Latin
c.
Roman
d.
Indian
118. Scientific knowledge is tentative becausea.
No one can prove or disprove scientific knowledge.
b.
Scientists must give their personal opinion and expertise.
c.
It is subject to change in light of new evidence.
d.
It is mostly guess-work made by scientists.
119. Which of the following is not correct about Hypothesis?
a.
A hypothesis should be consistent with existing observations and known information
regarding the question.
b.
A hypothesis must be presented as a statement of the predicted outcome, not as a question.
c.
A hypothesis is formulated before the experiment, not after the experiment.
d.
A hypothesis will become a theory after the experiment is done.
120. One of the ways in which a teacher can help students understand the difference between observation and inference is to:
a.
Conduct a test related to the difference between observation and inference.
b.
Conduct a field trip to a nearby park where students can observe.
c.
Plan an essay competition for the students related to observation.
d.
Ask them to read about observation from the textbook.

19

<!-- page 54 -->

ANSWER KEYS
Question
Number

Answer

Question
Number

Answer

Question
Number

Answer

91

c

101

b

111

a

92

d

102

c

112

b

93

a

103

c

113

c

94

b

104

c

114

b

95

d

105

b

115

c

96

d

106

c

116

a

97

b

107

b

117

b

98

d

108

b

118

c

99

c

109

c

119

d

100

b

110

c

120

b

20

<!-- page 55 -->

SOCIAL SCIENCE
SET - I
61.

Which of the following, best describes the primary aim of Social Science for classes 6-8?
a.
Memorizing dates and events
b.
Understanding how society functions
c.
Developing spatial thinking
d.
Excelling in competitive exams

62.

The specific teaching-learning objective in Social Science is to________.
a.
make students memorize past events
b.
develop critical thinking about social issues
c.
focus on a specific region
d.
prioritize economic theories

63.

Field trip in social science learning is primarily used to
a.
teach students outside classroom environments
b.
engage students in experiential learning
c.
conduct regular classroom assessment
d.
reduce the teaching workload

64.

Project work in teaching-learning of Social Sciences emphasizes on
a.
Individual work
b.
Group collaboration and practical application
c.
Passive learning
d.
Rote memorization

65.

Which of the following is the most effective tool to assess the understanding of historical events?
a.
Multiple choice tests
b.
Reflective essays
c.
Debate
d.
Quizzes

66.

Formative assessment techniques in Social Science include:
a.
Final exams
b.
Regular quizzes and group discussions
c.
Standardized tests
d.
Entrance exams

67.

A good Social Science teacher should
a.
dictate notes
b.
encourage questioning
c.
focus on textbook learning
d.
focus on exam only.
21

<!-- page 56 -->

68.

The pedagogy most suitable to Social Science is?
a.
Note taking
b.
Discussion and debate
c.
Dictation
d.
Lecture

69.

Social Science learning is best when:
a.
Facts are memorized
b.
Concepts are related to life
c.
Stick to the text book
d.
Teacher dominates

70.

Which of the following options promotes critical citizenship?
a.
Blind obedience
b.
Discussion of issues
c.
Rote learning
d.
Textbook reading

71.

Study of the ___________ should begin first in learning geography.
a.
World
b.
Country
c.
Local environment
d.
Continents

72.

Mock parliament is most appropriate for concepts relating to
a.
Physiographic regions
b.
Historical dates
c.
Autonomous District Council
d.
Money

73.

Social Science as a curricular area is expected to develop value such as
a.
Secularism
b.
Appreciation of beauty
c.
Health and Fitness
d.
Self-control

74.

The Constitution of India is learnt better through
a.
Reading
b.
Lecture only
c.
Discussion and Debates
d.
Dictation

75.

The study of the past should be learnt to
a.
glorify the past
b.
develop critical understanding of change
c.
learn the dates
d.
remember past rulers
22

<!-- page 57 -->

76.

One of the key challenges of social science teaching is
a.
has learning strategies which can be used according to the students’ needs
b.
completion of the course due to content load
c.
less dependent on technical skills
d.
connected to the daily life of students

77.

Problem-solving is one of the relevant pedagogies in Social Science.It develops__________ in
the students.
a.
Memory
b.
Logical thinking
c.
Fear
d.
Systematic reading

78.

Which of the activity mentioned below promotes democratic classroom?
a.
Teacher Monologue
b.
Group discussion
c.
Dictation
d.
Essay writing

79.

Which skill is developed through Social Science?
a.
Physical strength
b.
Social awareness
c.
Mechanical skills
d.
Speed writing

80.

Which approach is best suited in Social Science?
a.
Textbook centric
b.
Lecture only
c.
Experiential Learning
d.
Limited interaction

81.

What is one of the purposes of assessment in Social Science?
a.
To certify the students in language skills
b.
To assess the understanding of core ideas, facts and concepts
c.
To assess application of calculations of numbers
d.
To ensure accuracy in experiments

82.

The term that refers to an organized and patterned system of social relationship is
a.
Social Structure
b.
Social Organization
c.
Social Institution
d.
Social Control

83.

Which of the following is not a part of social structure?
a.
Social institution
b.
Social issues
c.
Social norms
d.
Social groups
23

<!-- page 58 -->

84.

Caste – based stratification is:
a.
Open
b.
Achieved
c.
Ascribed
d.
All the above

85.

Movement from one stratum to another by one of the possible stratification hierarchies is called
a.
Horizontal mobility
b.
Upward mobility
c.
Downward mobility
d.
Vertical mobility

86.

A map without scale is
a.
very accurate
b.
accurate
c.
not shown accurately
d.
Measured exactly

87.

Geography helps students to
a.
escape society
b.
understand the environment
c.
avoid responsibility
d.
memorise places

88.

From the given options, which is a service sector?
a.
Primary
b.
Secondary
c.
Tertiary
d.
Agricultural

89.

Earthquakes are caused mainly due to
a.
weather changes
b.
volcanic eruption
c.
tectonic plate movement
d.
ocean current

90.

Which is a renewable resource?
a.
Coal
b.
Petroleum
c.
Natural Gas
d.
Wind Energy

91.

The longest river in India is
a.
Yamuna
b.
Godavari
c.
Ganga
d.
Brahmaputra
24

<!-- page 59 -->

92.

Which of the following, prepare development plans in India?
a.
Reserve Bank of India
b.
National Institution of Transforming India Ayog
c.
Planning Commission
d.
Finance Ministry

93.

Which of the given options, is a commercial crop?
a.
Rice
b.
Wheat
c.
Cotton
d.
Pulses

94.

A narrow strip of land joining two landmasses is known asa.
Strait
b.
Isthmus
c.
Island
d.
Bay

95.

Which one of the following continents is smallest in size?
a.
Australia
b.
Africa
c.
Europe
d.
South America

96.

The main sources of information on Harrapan Civilization is
a.
Religious text
b.
Oral traditions
c.
Archaeological remains
d.
Foreign travelers

97.

__________was the movement started by Mahatma Gandhi in 1920?
a.
Civil Disobedience
b.
Quit India
c.
Non – Cooperation
d.
Khilafat

98.

The Permanent Settlement was introduced by
a.
Lord Dalhousie
b.
Lord Cornwallis
c.
Warren Hasting
d.
Lord Curzon

99.

Who wrote the book Indica?
a.
Fahien
b.
Megasthenes
c.
Hiuen Tsang
d.
Al – Biruni
25

<!-- page 60 -->

100. The Rowlat Act was passed in
a.
1905
b.
1913
c.
1919
d.
1925
101. The study of coins is called
a.
Numismatics
b.
Aerobiology
c.
Caliology
d.
Archaeology
102. The earliest manuscripts were written on
a.
Palm leaves
b.
Stones
c.
Paper
d.
Wood
103. Which period is longest in human history?
a.
Paleolithic age
b.
Megalithic age
c.
Mesolithic age
d.
Neolithic age
104. An archive is a place were
a.
historical manuscripts and documents are kept
b.
excavated bones of the animals and birds are kept
c.
remains of the buildings made of stones and bricks found by archaeologists are kept
d.
sculptures found in excavations are kept
105. In the Indian Freedom Struggle, Dandi March marked the beginning of?
a.
Swadeshi Movement
b.
Home Rule Movement
c.
Quit India Movement
d.
Civil Disobedience Movement
106. The Constitution of India came force on
a.
15th August,1947
b.
26th January,1950
c.
26th November,1949
d.
2nd October,1950
107. The Constitution of India was framed by
a.
Lok Sabha
b.
Rajya Sabha
c.
Vidhan Parishad
d.
Constituent Assembly.
26

<!-- page 61 -->

108. The Governor of State is appointed by the President on the advice of
a.
Vice President
b.
Prime Minister
c.
Chief Justice
d.
Chief Minister
109. Which one of the following does not constitute the electoral college for electing the President?
a.
Elected members of Lok Sabha
b.
Elected members of the Legislative Assembly of each state
c.
Elected members of the Legislative Council
d.
Elected members of Rajya Sabha
110. Which of the following appointments is not made by the President?
a.
Chief of the Army
b.
Chief Justice of India
c.
Speaker of the Lok Sabha
d.
Chief of the Air Force
111. A person who is not a member of Parliament can be appointed by the President for a maximum
period of
a.
3 months
b.
12 months
c.
6 months
d.
4 months
112. The Constitution of India was amended for first time in
a.
1950
b.
1951
c.
1952
d.
1953
113. Which among the following is not a constitutional body?
a.
Election Commission
b.
Union Public Service Commission
c.
NITI Aayog
d.
Finance Commission
114. Originally, how many subjects were present in the State List of the Indian Constitution
a.
58
b.
59
c.
60
d.
66
115. Which of the following states is not covered under the Sixth Schedule of the Indian constitution?
a.
Assam
b.
Meghalaya
c.
Nagaland
d.
Tripura
27

<!-- page 62 -->

116. Which political party in Meghalaya spearheaded Hill State Movement in 1960
a.
HSPDP
b.
INC
c.
APHLC
d.
UDP
117. The word ‘Secularism’ was added to the Preamble to the Constitution of India by which amendment
a.
42nd
b.
40th
c.
44th
d.
46th
118. The procedure for amending the Constitution of India is
a.
Rigid
b.
Flexible
c.
Partly rigid and flexible.
d.
None of these
119. Part III of the Indian Constitution deal with
a.
Fundamental Duties
b.
Fundamental Rights
c.
Directive Principle of State Policy
d.
Citizenship
120. How many seats in the Lok Sabha are reserved for Scheduled Tribes?
a.
47
b.
29
c.
34
d.
17

28

<!-- page 63 -->

ANSWER KEYS
Question No.

Answer key

Question No.

Answer key

Question No.

Answer key

61

b.

81

b.

101

a.

62

b.

82

a.

102

a.

63

b.

83

b.

103

a.

64

b.

84

c.

104

a.

65

b.

85

d.

105

d.

66

b.

86

c.

106

b.

67

b.

87

b.

107

d.

68

b.

88

c.

108

d.

69

b.

89

c.

109

c.

70

b.

90

d.

110

c.

71

c.

91

c.

111

c.

72

c.

92

b.

112

b.

73

a.

93

c.

113

c.

74

c.

94

b.

114

d.

75

b.

95

a.

115

c.

76

b.

96

c.

116

c.

77

b.

97

c.

117

a.

78

b.

98

b.

118

c.

79

b.

99

b.

119

b.

80

c.

100

c.

120

a.

29

<!-- page 64 -->

LANGUAGE - KHASI
PAPER-II
SET - I
Pule ia kane ka jingthoh bad sa jubab ia ki jingkylli kiba bud: (1-5)
Ka ‘imlang ka sahlang ka dei ka jylli ha kaba ngi im, ngi trei bad ngi iaid ngi ieng baroh shi lynter
ka jingim. Ka imlang ka sahlang ha kaba ngi hi ngi don, ka dei ka jong ngi hi. Ngi dei ban kam trai ia
ka kumba ka long ia la ka jong ka ing ka sem. Namar kata ki kamram jong ngi ia ka imlang sahlang ki
long kiba bun bad ba khia. Lada don kano kano kaba sniew ha ka imlang sahlang, kata kan ktah ia ngi
baroh bad yn ym don mano mano ruh ba lait. Haba don pat ka jingbha kata la la ia bha lang baroh.
Ha ka imlang sahlang ha shnong ha thaw, ha syndah jongngi, don ki lok ki jor, ki marjan marpa,
kiba ha ing bad ki kha ki man. Ka dei ka kamram jong ngi ban ia ieid ia burom iwei pa iwei pat. Ka dei
ka kamram jong uwei pa uwei ban pyrkhat lem, ban sngewlem bad ban iarap iabeh ia ki marjan marpa
ha la jingdonkam ba bun jait bad ha ki por baroh.
121. Ka phang bala kren ha katei ka jingthoh ka deia.
Ka jylli ba ngi im
b.
Ka imlang ka sahlang
c.
Ka kamram jong ngi
d.
Ka kamram jong ngi ha ka imlang sahlang.
122. Ka kyntien ‘jylli’ ha katei ka jingthoh ka thew iaa.
Ka shnong ka thaw
b.
Ki lok ki jor
c.
Ka Imlang sahlang
d.
Ki marjan marpa.
123. Katno sien ka kyntien ‘imlang sahlang’ ka paw ha katei ka jingthoh?
a.
3-lai
b.
4-saw
c.
5-san
d.
6-hynriew
124. Ngi dei ban kam trai ia ka imlang sahlang kum kaa.
Shnong lajong
b.
Jaka lajong
c.
Ing lajong
d.
Bynta lajong
125. Kano na kine kam dei ka kamram jong ngi ha ka imlang sahlang
a.
Iaieid ia burom
b.
Iarap iabeh
c.
Pyrkhat lem sngewlem
d.
Ia bishni pihuin

30

<!-- page 65 -->

126. Ka rukom pule na ki dak sha ka kyntien, ki kyntien sha ka senten ban sngewthuh ia ki jingmut
kiba don ha ka, la khot kaa.
Top-down Model
b.
Bottom-down Model
c.
Interactive Model
d.
Bottom-up bad Interactive Model.
127. Ka pule ia ka jingthoh ban ioh ia ka jingmut ba kyllum jong kata ka lynnong ngi khota.
Summarising
b.
Scanning
c.
Skimming
d.
Think aloud
128. Katno jait ki rukom pule ki don?
a.
4-saw
b.
5-san
c.
6-hynriew
d.
7-hynniew
129. Haba pule ban buh jingthoh dei ban thoha.
Ha la ki jong ki kyntien
b.
Shai ia ka jubab
c.
Ia kaba kiwei ki ai nuksa
d.
Kumba don ha ka kot.
130. ‘Think aloud’ ka mut
a.
Kaba pule jam
b.
Kaba pule da ka jingsngewthuh
c.
Ban pynpaw ia kaei kaba pyrkhat haba pule
d.
Ban pule bniah
131. Ka Jing pynshong dor kaba ‘Iai bteng’ ka thew ia ka rukom thew jingtip ka ba –
a.
Man la ka teng
b.
Tista bad iai bteng
c.
Pud teng teng
d.
Bteng shilynter
132. Kano na kine ka dei ka ktien kynnoh jong ka kyntien ‘thad’ –
a.
Wah
b.
Rkhiang
c.
Bad
d.
Phriang
133. Ka trei ka ktah jong u kam thikna. Ka ktien kynnoh ‘Ka trei ka ktah’ ka hap ha kano na kine ?
a.
Berb
b.
Adverb
c.
Intensifier
d.
Abstract Noun
31

<!-- page 66 -->

134. Jied ia dak sangeh kiba iahap bad kane ka jing ong – Sngap jar sngap jar shaei phi ia buh ia ka
akor kumne pleng phi ia shahshkor ia ka ktien ki Nonghikai
a.
!!?,!
b.
|?!,!
c.
||?!,
d.
|,!?!
135. Ka ba mareh thar thar ka thew ia ka rukom mareh ka ba –
a.
Sted bad pynsting ialade
b.
Beit khlem da kyrtiang
c.
Beit khlem da kyllain
d.
Khlem suitniew iaei iaei ruh
136. Ka “SQ3R” ka mut –
a.
Jurip, Kylli jingkylli, Pule bniah, Pule lyndet, Pule biang
b.
Jurip, Kylli jingkylli, Pule lyndet, Pule bniah, Pule biang
c.
Jurip, Pule bniah, Kylli jingkylli, Pule lyndet, Pule biang
d.
Jurip, Pule bniah, Kylli jingkylli, Pule biang, Pule bniah
137. Ka buit pule kot khubor kaba pule tang ïa ki mat kiba ha khmat eh –
a.
Skimming
b.
Scanning
c.
Summarizing
d.
Note-taking
138. “Ka kyntiew ïa ka jingtbit jong ka kynhun ban ïashimbynta lang haba pule ïa ka lynnong.” Kano
na kine ki rukom pule kaba ïahab eh bad katei ka jingong?
a.
Think-aloud
b.
KWL
c.
SQ3R
d.
Note-taking
139. Kaba thoh ïa ki jingthoh sngewtynnad na lade (Creative writing), ka –
a.
Ai khubor ïa baroh
b.
Pynshlur ïa kiba bun
c.
Ka pynkhlaiñ ïa ka bor jingmutdur
d.
Ka pyni nuksa ïa kiwei
140. Kano na kine ki jait jingthoh harum kaba ïahab bad ki jingpynbna ha ki kot khubor?
a.
Ki jingthoh ba ïathuh
b.
ki jingthoh ba pyntip
c.
Ki jingthoh ba pynpaw
d.
Ki jingthoh ba batai

32

<!-- page 67 -->

141. Ha kano ka rukom ka mind map ka kyntiew ïa ka jingnang ïa ka ktien bad pynneh slem ha ka bor
kynmaw?
a.
Da kaba pynïasnoh ïa ki kyntien ba donkam, ki dur bad ki rong ki rup
b.
Pynleit jingmut halor ka jingthoh ban ïoh ïa ka jingsngewthuh
c.
Buh ryntih ïa kawei pa kawei ka kyntien ban ai jingtip ïa ki khynnah
d.
Pyndonkam ïa ki kyndon ka krammar ha ka rukom kaba bniah
142. Ka jingpyndonkam ïa ka ‘mind map’ ka pynlah ïa ki khynnah ban –
a.
Pynïasnoh bad bun ki jingtip ba don jingïadei
b.
Pyniar ïa la ka jingtip
c.
Ϊoh jingmut kham bun
d.
Mang lypa bad buh ryntih ïa ki jingmut jingpyrkhat
143. Haba pynkhreh ïa ka Mind map, ka phang ka dei ban sdang na –
a.
Ka diang ka sla kot
b.
Pdeng ka sla kot
c.
Khlieh ka sla kot
d.
Kamon ka sla kot
144. Kano na kine harum ka dei kawei na ki jinglong jong ka Lesson Plan?
a.
Ka Lesson Plan ka don Lai bynta
b.
Ka Lesson Plan ka lah ban don bun rukom
c.
Ϊa ka Lesson Plan dei ban hikai hapoh 30 minit
d.
Shisien ba la shna ïa ka, dei ban bud thik ha ka por hikai
145. Ka Rubrik ka dei ka tiar thew jingtip da ka kaba –
a.
Shu tik ïa ki jingleh bad jingbymleh ki khynnah
b.
Khmih bniah ïa ki kam ki khynnah ha kamra klas
c.
Bud dien ïa ki jingbuh jingthoh shaphang ki khynnah
d.
Buh kyrdan ïa ka jinglah u khynnah kat kum ka thup ki jinglah ban leh kam
146. “Ka Skima kaba lah ban pyniasnoh bad ki jingtip ba la shong tynrai ha ki nongpule.” Kano na
kine ki jait skima kaba iahab eh bad katei ka jingong?
a.
a. Ka Linguistic Schema
b.
b. Ka Formal Schemata
c.
c. Ka Content Schemata
d.
d. Baroh kim dei
147. “Ka kyntiew Ia ka jingtbit jong ka kynhun ban iashim bynta lang haba pule Ia ka lynnong.” Kano
na kine ki rukom pule kaba iahab eh bad katei ka jingong?
a.
Note-taking
b.
KWL
c.
SQ3R
d.
Summarizing

33

<!-- page 68 -->

148. Ka Mind Map ka long ka buit pyntreikam ba lah ban—
a.
Thoh ryntih ia ki jingthoh
b.
Mang lypa bad buh ryntih Ia ki jingmut jingpyrkhat
c.
Thoh ia ki jingmut
d.
Iathuh bniah
149. Ka tiar thew jingtip kaba lum thup ia ki jingtrei bad jingkam jong ki khynnah, ka dei—
a.
Ka Checklist
b.
Ka Rating scale
c.
Ka Portfolio
d.
Ka Anecdote
150. Ki kyntien ‘shong-sadhai’ ki thew ia ka rukom ba shong—
a.
Slem hajuh khlem khih
b.
Iabun bad sngewtynnat
c.
Shong kyrthai
d.
Shong hajuh bad thiah syndon

34

<!-- page 69 -->

Questions No.

Answer keys

121
122
123
124
125
126
127
128
129
130
131
132
133
134
135
136
137
138
139
140
141
142
143
144
145
146
147
148
149
150

d
c
c
c
d
b
a
d
a
c
b
c
d
a
a
a
d
b
d
b
a
d
b
d
d
c
b
b
c
b

35

<!-- page 70 -->

Garo
(Paper II)
SET – I
Ka·mao on·sogimin sing·anirangna aganchakbo:
121. Poraimiting somoio bi·sarangko uamangni janggi tanganio u·i-ma·sisogiminrangko ra·dime
jakkalchapatode, poraianio apalbate u·i-ma·sina man·a. Ia rokomo poraiani kam-bewalkon_________minga.
a.
Skimming
b.
Scanning
c.
Schema
d.
SQ3R
122. KWLko maidakmiting somoio jakkalgenchim?
a.
Poraimitingo
b.
Semitingo
c.
Bi·sarang baksa agan-golpogrikmitingo
d.
Kosako janapgipa gimikan ong·tokaia.
123. SQ3R-ni chu·gimik miksonganiara mai?
a.
Survey, Question, Read, Recite aro Review
b.
Survey, Question, Recall, Recognition aro Record
c.
Scanning, Question, Revise aro Recall
d.
Kosako sesogipa gimikan ong·aia.
124. Bi·sarangko Scanningko dakatengon maiko simsake am·sandina nanggenchim?
a.
Dingtangmanchagipa katta bichong ba miksonganiko
b.
Man·gopgipa katta bichong ba miksonganiko
c.
Napsepgipa katta bichong ba miksonganiko
d.
Watchanggipa katta bichong ba miksonganiko
125. Skimmingko klaso dakatengon maiko sandina nanga?
a.
Dingtangmanchagipa orto ba miksonganiko
b.
Man·gopgipa orto ba miksonganiko
c.
Napsepgipa orto ba miksonganiko
d.
Watchanggipa orto ba miksonganiko
126. Summarisingko dakanio maikai dakna nanga?
a.
Pilak kattarangko watchangna nangja.
b.
Nangchongmotgipa kattarangkosan ra·na nanga.
c.
Pilak kattarangkon che·em che·em talatna nanga.
d.
Kattatangchi sentencerangko ritchurorona nanga.
127. Gam·e chanchiani (Loud thinking) ine aganode ka·mao on·sogiminoniko mingsako miksonga.
a.
Bi·sarangna chanchianiko on·e uko gam·e aganna sapaniko
b.
Bi·sarangna chanchianiko on·e uko gisiko gam·e chanchina sapaniko
c.
Bi·sarangna chanchianiko on·e uko gisiko mangmang chanchina sapaniko
d.
Kosako janapgipa gimikan ong·tokja.
36

<!-- page 71 -->

128. A·bachenggipa gadango ( elementary level) mai skiani bewalko jakkale Grammarko skigen?
a.
Inducto-deductive method
b.
Deducto-inductive method
c.
Inductive method
d.
Deductive method
129. Ka·mao on·sogimin sentencerangoni badia Interjectionko tik ong·e jakkalaha, basebo.
a.
Aiao ! aski do·me nitobea.
b.
Aiao, aski do·me nitobea!
c.
Aiao aski do·me nitobea !
d.
Aiao ! aski do·me nitobea!
130. “A·rankari sokbaoa A·chikrang a·a o·a.’’ Ia on·sogimin sentence badia sentenceni ma·ao
ga·akea?
a.
Bringija sentence
b.
Donbrina sentence
c.
Mitapgipa sentence
d.
Kosako janapgipa gimikan ong·tokaia.
131. “Makkre boloni ta·rake ong·one katangaha.” Ia sentenceo salsretgipa katta mai Caseni ma·a
ong·a, basebo.
a.
Nominative
b.
Dative
c.
Ablative
d.
Vocative
132. Proseko skina golpo agananiko dakengon, mai mairangko skigipa jakkalna nanggenchim?
a.
Voice modulation aro intonation
b.
Gesture
c.
Noksa, model aro realia
d.
Kosako janapgipa gimikkon nanga
133. Modulation-o mai mai ku·rangni gadangrang donga ?
a.
Kosakbatgipa gadang ( High pitch)
b.
Bijangchigipa gadang ( Middle pitch)
c.
Onbatgipa gadang ( Low pitch)
d.
Kosako janapgipa gimikan donga.
134. Golpo agananio maiko mancha ‘ Intonation’ ine minga ?
a.
Ku·rangni tang·ona aro tang·doaniko
b.
Ku·rangni apsan gadango donganiko
c.
Ku·rangni kosakbatgipa gadango dongkamaniko
d.
Ku·rangni onbatgipa gadango dongkamaniko
135. Poedoko skiani mongsonggipa miksonganiara maia?
a.
Poedoko mingna sapatna mangmang
b.
Poedoni nitoaniko/ su·uaniko bi·sarangna skie on·na
c.
Poedoni miksongani mangmangkosan bi·sarangna u·iatna
d.
Kosako janapgipa gimikan ong·tokja.
37

<!-- page 72 -->

136. Poedo minganio mongsongbatgipa___________ ong·a.
a.
Rhyme aro Rhythmko name ja·rike mingani
b.
Mingmitingo sronge chadengani.
c.
Ta·rake mingna sapani
d.
Mikosto mingna sapani
137. Ka·mao on·sogiminrangoniko badia ong·a basebo.
a.
Proseko skia gita, poedoko skimitingo raka kattarang dongode uko somoi gimik bi·sarangna talatna jotton ka·na nanga.
b.
Proseko skia gita, poedoko skimitingode raka kattarang dongoba uko somoi gimik bi·sarangna talatna jotton ka·na nangja.
c.
Proseko skia gita, poedoko skimitingode raka kattarangko am·sandie uarangko che·em
che·em talatna nanga.
d.
Proseko skia gita, poedoko skimitingode Grammarni bakrangko am·sandie uarangko
che·em che·em talatna nanga.
138. Ka·mao on·sogimin sentencerangoni badia ong·ja basebo.
a.
Proseko skiengmitingo skigipa name rhyme aro rhythmko jakkalna nanga.
b.
Proseko skiengmitingo skigipa Grammarni bakrangkoba skijolna man·a.
c.
Proseko skiengmitingo skigipa bi·sarangni janggi tanganio nangchape talatjolna man·a.
d.
Proseko skiengmitingo skigipa modulation aro intonationko jakkale skiode nambata.
139. Golpo gnanggipa lessonko skina nambatsranggipa skia bewalrangde iarang ong·ja.
a.
Golpo aganachi skiani
b.
Dakmesokanichi skiani
c.
Noksarangko jakkale skiani
d.
Minganiko dakatani ( Recitation)
140. Skigipani bi·sarangna poraie mesokani ( model reading) maini gimin gamchata?
a.
Gam·atanirangko tik ong·e ja·rikatna dakchaka.
b.
Chinrangni kri poraina dakchaka.
c.
Bi·sarangko ku·greng salatna dakchaka ( fluent)
d.
Kosako janapgipa gimikan ong·toka.
141. Prose ba poedoko skiengon badiaba lessonrangko skiode asol bostu ba bimangko ra·bae klaso
skina man·a. Indide ua skiao jakkalgni bostuko mai minga?
a.
Realia
b.
Model
c.
Chart
d.
Noksa
142. Bi·sarangko porika ra·anio, badita bi·sarang skie ra·ahachim, uko jadoko ba bilsi bon·ao porikka
ra·e niode, uara ka·mao on·sogiminoni badiao ga·akea?
a.
Formative
b.
Summative
c.
Diagnostic
d.
Kosako sesogimin gimikan ong·tokaia.
38

<!-- page 73 -->

143. Scholastic area ine aganode uara maiko miksonga?
a.
Klaso ra·enggipa pilak subjectrang
b.
Kitchen gardenko dakatanirang
c.
Badiaba biapchi bi·sarangko rimdilange skie on·anirang.
d.
Kal·anirang (Games) aro sport-rangko skulo ong·atanirang.
144. Skulo skigipa bi·sani sakgipinrang baksa kal·grikani ba skie ra·ani somaio uni cholon aro skie
ra·ani bewalrangko name dake nie, porika ra·na see-jote rakkianikon indake minga.
a.
Portfolio record
b.
Rubric record
c.
Anecdotal record
d.
Progress record
145. Absolute grading maiko minga?
a.
a. Skanggipa bi·sarangni markrangko ra·chenge ja·mano uni kri letter grade on·aniko
b.
Joljol bi·sana letter grade on·aniko
c.
Jeko aro o janapa minggnian ong·aia.
d.
Jeko aro o janapa minggnian ong·ja.
146. Agan-me·apao ‘A·kim gaa’ ine aganon, ka·mao on·sogiminoni badiako miksonga?
a.
Cha·senga
b.
Chawari sing·a
c.
Jakgitok ra·a
d.
Nokma songa
147. ‘Kratcha·chaka’ ine agan-bewalo agananiko Agan-me·apao aganskaode indake ong·skaa:
a.
Miknageng sata, penateng doka
b.
Mikkolsia, Wakidika
c.
Mikgil jamdap pina, ki·sang medop daka
d.
Mikron miksong sala.
148. Sko kimkatekoba,________________ iano katta –Ku·jikseko gapatna ka·mao on·sogiminoniko
sandibo.
a.
Bimang rongdimeloba
b.
Bimang anggal dakoba
c.
Bimang do·pinchepoba
d.
Bimang mikchikkimoba
149. ________ , Silchi chima. Iano gimaenggipa katta ku·jikseko ka·mao on·sogimirangoni badia?
a.
Kakwa doka
b.
Rang doka
c.
Adil sika
d.
Kram doka
150. ‘Ja·rik –ja·sana’ ia Katta Ku·jikseni orto mai?
a.
Am·a, sandia
b.
Ja·man re·a
c.
Srik srik time nia
d.
Skang skang re·a
39

<!-- page 74 -->

121
122
123
124
125
126
127
128
129
130
131
132
133
134
135
136
137
138
139
140
141
142
143
144
145
146
147
148
149
150

Answer keys
c
c
a
a
b
b
a
a
a
b
c
d
d
a
b
a
b
a
d
d
a
b
a
c
a
a
b
c
a
a

40

<!-- page 75 -->

Paper - II
(Set - II)
Content
1.

Child development & Pedagogy

2.

Language – II (English)

3.

Mathematics

4.

Environmental Studies

5.

Language- I (Khasi/Garo)

41

<!-- page 76 -->

Child Development & Pedagogy-II
SET - 2
1.

According to Kohlberg’s theory of moral development “A child who obeys school rules primarily
to avoid being scolded by the teacher” in which stages?
a.
Social Contract Orientation
b.
Punishment and Obedience Orientation
c.
Good Boy / Nice Girl Orientation
d.
Universal Ethical Principle Orientation

2.

Who is considered the father of educational psychology?
a.
Jean Piaget
b.
B.F Skinner
c.
Edward Thorndike
d.
Lev Vygotsky

3.

Gender is best described as a ________ construct.
a.
Biological
b.
Social
c.
Physiological
d.
Genetic

4.

In the context of a classroom, Gender Socialization refers to:
a.
Grouping students by their height.
b.
The process by which children learn the values and behaviors society deems appropriate
for their sex.
c.
Ensuring all students have the same textbooks.
d.
The biological growth of children during puberty.

5.

At what age do most children typically reach the stage of Gender Identity, where they can label
themselves and others as a boy or a girl?
a.
2–3 years
b.
6–12 months
c.
5–7 years
d.
10–12 years

6.

According to Lawrence Kohlberg’s theory, Gender Stability is the stage where a child understands
that:
a.
Gender remains the same over time (boys grow up to be men).
b.
Gender is a social construct.
c.
Gender changes based on the clothes one wears.
d.
They can choose their gender regardless of biology.

42

<!-- page 77 -->

7.

A teacher consistently asks boys to carry heavy desks and girls to decorate the bulletin board.
This is an example of:
a.
Gender neutrality
b.
Effective classroom management
c.
Gender stereotyping in educational practices
d.
Biological determinism

8.

To promote gender equality and challenge stereotypes, the teacher should:
a.
Use gender-neutral language and diverse examples in textbooks.
b.
Separate boys and girls for competitive activities.
c.
Reinforce traditional roles to maintain cultural stability.
d.
Ignore gender issues entirely in the classroom.

9.

Gender Bias in educational practices can lead to which of the following for students?
a.
Increased self-esteem for all genders.
b.
Limited career aspirations and reinforced social inequalities.
c.
Better academic performance in all subjects.
d.
A complete elimination of gender roles.

10.

When discussing gender identity within the family, the teachers should recognize:
a.
That the patriarchal model is the only “standard” for development.
b.
That matrilineal societies do not face any gender-based challenges.
c.
The diversity of family structures and how they influence a learner’s self-concept.
d.
That family structure has no impact on classroom behavior.

11.

A teacher performs an in-depth, intensive investigation of a single student who is highly gifted
but struggling with social anxiety. This detailed individual profile is known as a:
a.
Case study
b.
Longitudinal survey
c.
Cross-sectional analysis
d.
Portfolio assessment

12.

What is a major disadvantage of a Longitudinal study?
a.
It cannot show individual change over time.
b.
It is time-consuming and risks attrition.
c.
It only provides a snapshot of a specific moment.
d.
It involves too many different age groups at once.

13.

An Anecdotal Record is best described as:
a.
A cumulative record of a student’s grades over five years.
b.
A brief, objective narrative account of a specific significant incident or behavior
observed in a child.
c.
A formal personality test conducted by a school psychologist.
d.
A list of all the books a student has read during the semester.

43

<!-- page 78 -->

14.

When a teacher conducts an Unstructured Interview with a student, the primary goal is to:
a.
Assign a numerical score to the student’s speaking ability.
b.
Follow a rigid script of “Yes/No” questions.
c.
Allow the child to express their thoughts and feelings freely in a conversational manner.
d.
Discipline the child for a specific classroom rule violation.

15.

Which of the following is a potential limitation of using the Clinical Method in a classroom?
a.
It provides too much objective data.
b.
It is highly time-consuming for a teacher to perform with every student.
c.
It does not allow for any individual differences.
d.
It relies too heavily on computerized scoring.

16.

In an inclusive classroom, teachers should:
a.
Follow one teaching method for all
b.
Ignore individual differences
c.
Adapt teaching to meet diverse needs
d.
Focus only on learners

17.

The main aim of inclusive education is to:
a.
Separate children with disabilities
b.
Promote competition
c.
Focus only on academic achievement
d.
Provide equal learning opportunities for all

18.

Inclusive Education is based on the philosophical idea that:
a.
Some children are unteachable in a regular setup.
b.
Integration is the final goal of special education.
c.
Education is a fundamental right for all, and diversity is a resource, not a problem.
d.
Children with disabilities should only interact with their peers during lunch breaks.

19.

A school that provides ramps, Braille books, and specialized teacher training to ensure every
child learns together in the same classroom is practicing:
a.
Exclusion
b.
Segregation
c.
Integrated Education
d.
Inclusive Education

20.

A student in your class can read a text fluently but cannot answer simple comprehension questions
about what they just read. They also struggle to understand social cues and maintain eye contact.
Which condition is most likely being described?
a.
Dyslexia
b.
Attention Deficit Hyperactivity Disorder (ADHD.
c.
Autism Spectrum Disorder (ASD.
d.
Dyscalculia

44

<!-- page 79 -->

21.

A child with Dyspraxia is likely to face the most significant challenge in which of the following
classroom activities?
a.
Solving complex mental math problems.
b.
Remembering a list of historical dates.
c.
Activities involving fine motor skills, such as using scissors or tying shoelaces.
d.
Silent reading of a long story.

22.

A school has enrolled a student with a physical disability but the classrooms are located on the
second floor with no lift. This is an example of:
a.
A pedagogical barrier.
b.
A psychological barrier.
c.
An environmental/structural barrier.
d.
A socio-economic barrier.

23.

Why is a Rigid Curriculum considered a major challenge to inclusive education?
a.
Because it ensures all students are graded on the same high standards.
b.
Because it does not allow for the flexibility needed to accommodate different learning
styles and paces.
c.
Because it focuses too much on extracurricular activities.
d.
Because it is updated too frequently for teachers to keep up.

24.

Piaget’s view that children construct their own understanding of the world implies that they are:
a.
Passive recipients of information from teachers.
b.
“Little Scientists” who actively explore and experiment with their environment.
c.
Tabula rasa (blank slates) at birth.
d.
Only capable of learning through rote memorization.

25.

When a child changes their existing schema to fit new information that doesn’t fit their current
way of thinking, Piaget calls this:
a.
Assimilation
b.
Scaffolding
c.
Accommodation
d.
Centration

26.

The Zone of Proximal Development (ZPD. is best defined as the gap between:
a.
What a child knows and what they will never be able to learn.
b.
A child’s physical age and their mental age.
c.
What a learner can do independently and what they can do with the help of a more
capable peer or teacher.
d.
The school curriculum and the child’s home environment.

27.

A teacher provides a student with a hint or a half-solved example to help them solve a complex
math problem. In Vygotsky’s theory, this temporary support is known as:
a.
Assimilation
b.
Scaffolding
c.
Equilibrium
d.
Negative Reinforcement
45

<!-- page 80 -->

28.

29.

30.

Which of the following classroom activities best exemplifies the “Inquiry-based Learning”
approach?
a.

Students underlining keywords in a textbook while the teacher reads aloud.

b.

Students memorizing a list of chemical elements for a weekly quiz.

c.

Students investigating why local water sources are polluted by collecting samples and
interviewing community members.

d.

Students copying a diagram of a plant cell from the blackboard into their notebooks.

In the Teaching Transaction phase, the teacher’s primary role is to:
a.

Finalize the syllabus for the term.

b.

Facilitate the interaction between the learner, the content, and the environment.

c.

Write the end-of-year examination questions.

d.

Review the previous year’s student portfolios.

Why is Lesson Planning considered a crucial part of the Pre-teaching phase?
a.

It serves as a rigid script that the teacher must follow without change.

b.

It provides a logical framework to ensure all learning objectives and diverse needs are
addressed.

c.
d.

It is required only for administrative record-keeping purposes.
It replaces the need for actual classroom interaction.

Answer Keys :
Question No

Answer

Question No

Answer

Question No

Answer

1

b

11

a

21

c

2

c

12

b

22

c

3

b

13

b

23

b

4

b

14

c

24

b

5

a

15

b

25

c

6

a

16

c

26

c

7

c

17

d

27

b

8

a

18

c

28

c

9

b

19

d

29

b

10

c

20

c

30

b

46
