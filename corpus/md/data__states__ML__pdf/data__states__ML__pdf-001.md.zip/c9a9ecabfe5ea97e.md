---
doc_id: "c9a9ecabfe5ea97e"
source_url: "https://homepolitical.meghalaya.gov.in/pdf/acts/the_meghalaya_benami_transaction_amendment_act-2016.pdf"
ministry: "Home (Political) Department, Meghalaya"
title: "Download"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e4dbc2c3f8f01ff1"
---

<!-- page 1 -->

Postal Registration No. N. E.-771/2006-2008

The Gazette of Meghalaya
EXTRAORDINARY
PUBLISHED BY AUTHORITY
No. 53

Shillong, Wednesday, April 6, 2016,

17th Chaitra-1938 (S. E.)

PART-IV
GOVERNMENT OF MEGHALAYA
LAW (B) DEPARTMENT
ORDERS BY THE GOVERNOR

NOTIFICATION

The 6th April, 2016.
No.LL(B)77/74/301.-The Meghalaya (Benami Transactions Prohibition)

(Amendment) Act, 2016 (Act NO.4 of 2016) is hereby published for general
information.

MEGHALAYA ACT NO.4 OF 2016.
(As passed by the Meghalaya Legislative Assembly)
Received the assent of the Governor on 5th April, 2016.
Published in the Gazette of Meghalaya Extra-Ordinary issue dated 6th April, 2016.

<!-- page 2 -->

346

THE GAZETTE OF MEGHALAYA (EXTRAORDINARy) APRIL 6, 2016

[PAR -IV

THE MEGHALAYA (BENAMI TRANSACTIONS PROHIBITION) (AMENDMENT)
ACT,2016.
An
Act

further

to

amend

the

Meghalaya

(Benami

Tran~actions

Prohibition)

Act, 1980.
Be it enacted by the Legislature of the State of Meghalaya In the
Sixty-seventh year of the Republic of India as follows,­

Short title and
commencement.

1.

(1)

This

Act

may

be

called · the

Meghalaya

(Benami Transactions Prohibition) (Amendment) Act, 2016.
(2) It shall come into force from the date of notification
in the Official Gazette.

Amendment of
Section 2(a).

In section 2 of the Meghalaya (Benami

2.

ran

s

Prohibition) Act, 1980 (hereinafter referred to as the principal
Act)(i) in clau se (a) the words "or on behalf" shall be

omitted;

"(ii) in clause (d) after the words" as amended from time
to time" the punctuation full stop ".. shall be
inserted and thereafter the words "and for the
purpose of this Act shall also include the Rabhas,
Kacharis and Koch resident in Meghalaya" shall be
omitted.

Amendment of
Section 3.

3. In section 3 of th~ principal Act, in second proviso for
the existing Explanation (ii), the following shall "be
substituted, namely,­

<!-- page 3 -->

PART-IV]

347

THE GAZETTE OF MEGHALAYA (EXTRAORDINARy) APRIL 6, 2016

"(ii) "members of the same family" means either
one of the spouses is a tribal and includes the
childreh either of whose parent is or was a tribal."

Amendment of
Section 4.

4.

For the existing section 4 of the principal Act, the

following new section 4 shall be substituted, namely,"Constitution of
Committee or
Authority.

The

State

notification

In

4(1)

Government may,
the

Official

by

Gazette,

constitute a committee or an authority for
receiving and causing verification of a
complaint or information of a transaction
in benami in the State.
(2)

On

receivIng a complaint or

information under sub-section (1), the
committee or the authority so constituted
shall cause verification of such complaint
or information and after such verification
and if prima Jacie objectively satisfied and
after giving opportunity of being heard to
the person against whom a complaint or
information of transaction in benami is
received, the committee or the authority
may refer the matter to the Superintendent
of Police for further investigation.
(3)

The committee or the authority

constituted under sub-section (1) may
detect and identify any transaction in
benami and if the committee or authority

<!-- page 4 -->

348

THE GAZETTE OF MEGHALAYA (EXTRAORDINARy) APRIL 6,2016

[PART-IV

finds any such transaction to be benami
after following due process of verification
as provided for in sub-section (2) above, it
may refer the same to the Superintendent
of Police for further investigation.
(4)

The committee or the authority

constituted under sub-section (1) above
shall have the power to require the
presence

of an

officer

of the

State

Go ernment or local authority or any

person

ho ·s responsible for maintaining

books of acco

or other documents

containing a record of any transaction
relating to any property

a sac e

in

benami or any other matter relevant for the
purposes of this Act.
(5) On receipt of a reference from the
committee

or

the

authority,

the

Superintendent of Police by himself or by
any officer of Police not below the rank of
Sub-In~pector duly authorised by him may

enter and search at all reasonable hours,
any premises where he has reason to
believe that any register of account or other
documents relating to or having any
bearing on ~uch transaction are kept in
electronic form or otherwise and such
police officer may direct any person whom

<!-- page 5 -->

PART-IV]

THE GAZETTE OF MEGHALAYA (EXTRAORDINARy) APRIL 6, 2016

349

he has reason to believe to be in custody of
such register, books of account or other
documents relating with the transaction to
produce them for his inspection and if
required may seize such register, books of
account or other documents or records or
electronic systems".

Amendment of
Section 4A.

5. In Section 4A of the principal Act, in the proviso to subsection

(1) and in sub-section

(2)~

the word , "person"

respectively appearing therein shall be omitted and further for
the figure, bracket and letter "4(a)" appearing in the aforesaid
proviso and also in sub-section (2), the figure and bracket
"4(1)" shall be substituted.

Subatitution or
Section 6.

6. For the existing section 6 of the principal Act, the following
new section 6 shall be substituted~ namely,"Offences to be 6. Offence under section 3 shall · be
bailable or non cognizable and bailable but whoever
bailable.
wilfully refuses or fails to comply with any
direction or lawful order made under
section 4 such offence shall be nonbailable."

lnsertlon of new 7. After Section 6 of the principal Act, the following new
Section 6A.
Section 6A shall be inserted, namely,6A (1) Where any Qffence punishable under
"Offences by
Companies and
this Act has been committed by a Company
Partnership
Firms.
or Partnership firm, every person who at the
time of the offence is committed, is in charge
,
of, and is responsible to the Company for the
conduct of the business of the Company, or
Partnership of Partnership firm shall be
deemed to have committed an .offence under
this Act:

<!-- page 6 -->

350

THE GAZETTE OF MEGHALAYA (EXTRAORDINARy) APRIL 6,2016

[PART-IV

Provided that nothing contained in this
sub-section shall render any such person
liable to any punishment, if he proves· that
the offence was committed without his
knowledge or that he had exercised all due
diligence to prevent the commission of such
offence.
(2)

Notwithstanding anything contained in

sub-section ('1), in relation to any offence
committed under this Act by a Company or
Partnership firm, it is proved that the
offence

has

been

committed with

the

consent or connivance of or is attributable
to any negligence on the part of any
Director, Manager Secretary
officer or Partner ·

an

0

er

.. willy or collectively

shall also be deemed to have committed an
offence under this Act.
EzplaDation:

For the purposes of this Section:(a) "Company" means a body corporate
and

includes

a

firm

or

an

association of individuals;
(b) "Director" in relation to a company
also includes Managing Director;
and
(c) "Partner" in relation to a Partnership
firm includes managing partner."
Substitution of
section 7.

8. For the existing section 7 of the principal Act, the following
new section 7 shall be substituted, narnely,­

<!-- page 7 -->

PART-IV]

351

THE GAZETTE OF MEGHALAYA (EXTRAORDINARy) APRIL 6, 2016

"Penalty.

7. Whoever commits an offence under
Sections 3 and 6A or wilfully refuses or fails
to comply with any direction or lawful order
made under sub-section (3) of section 4
shall, on conviction by a court of Judicial
Magistrate First Class, be punishable with
imprisonment for a term · not exceeding six
months or with fine not exceeding twenty
thousand rupees or with both:
Provided

that

the

mInImum

punishment for the second and sub~equent
offence under section 3 shall be with
imprisonment for a term not less than
three months and also with fine of not less
ihan ten thousand rupees or both."

L. M. SANGMA,

Special Secretary to the Govt. of Meghalaya,
Law Department.

SHILLONG : Printed and Published by the Director, Printing and Stationery, Meghalaya , Shillong .
(Extraordinary Gazette of Meghalaya) No. 105 - 730 + 300 - 6 - 4 - 2016 .
website:- htto://megpns.goy.in/gazette/gazette.asp
