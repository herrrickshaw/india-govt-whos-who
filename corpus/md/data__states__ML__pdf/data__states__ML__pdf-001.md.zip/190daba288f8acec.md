---
doc_id: "190daba288f8acec"
source_url: "https://megamb.gov.in/Documents/AGRI_E_57_2021_Pt_I_31.pdf"
ministry: "Meghalaya State Agricultural Marketing Board, Meghalaya"
title: "Notification – Promotions and Postings under Meghalaya Agriculture Service   In pursuance of the recommendations of the Departmental Promotion Committee and under the provisions of the Meghalaya Agriculture Service Rules, 1996, several officers have been promoted to Grade-II of the Meghalaya Agricul"
date: ""
pages: 3
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "f227414c2d3809a9"
---

<!-- page 1 -->

7 |
i : GOVERNMENT OF MEGHALAYA
” DEPARTMENT OF AGRICULTURE & FARMERS’ WELFARE
~ ORDERS BY THE GOVERNOR
NOTIFICATION
Dated Shillong, the I July, 2025

No. AGRI(E)57/202 1/Pt-1/31 — In the interest of public service, Smti. Alma W. Momin. Secretary, Mawiong Market
Committee, Shillong is hereby reverted to the Parent Department. On her reversion she is transferred and posted as
Assistant Director of Agriculture (Agronomy), Nongstoin with effect from the date of taking over charge, vice Shri
Walseng D. Sangma, transferred.
No.AGRI(E)57/2021/Pt-1/31 — A - In pursuance of the recommendation of the Departmental Promotion Committee
and under provision of rule 7 (3) of the Meghalaya Agriculture Service Rules 1996, Shri Handerson Chulet.
Horticulture Development Officer, Shillong is hereby promoted to the post of Grade-II of the MAS under L-16 of
the pay matrix plus usual allowances as admissible under the Rules, and posted as Assistant Director of Agriculture
(Information), Upper Shillong with effect from the date of taking over charge, vice, ‘Smti. Darisha Nongpiur. on dual
charge.

On his joining to the post of Assistant Director of Agriculture, (Information), Upper Shillong on promotion
he is proposed to go on deputation as Secretary, Mawiong Market Committee, Shillong, vice Smti. Alma W. Momin,
reverted to Parent Department.

No. AGRI(E)57/2021/Pt-1/31 — B - In pursuance of the recommendation of the Departmental Promotion Committee
and under provision of rule 7 (3) of the Meghalaya Agriculture Service Rules 1996, Dr. (Smti.) Dayohimi Rymbai.
Scientific Officer (Research), Jowai is hereby promoted to the post of Grade-Il of the MAS under L-16 of the pay
matrix plus usual allowances as admissible under the Rules. and posted as Assistant Director of Agriculture
(Information), Upper Shillong with effect from the date of taking over charge. vice, Shri Handerson Chulet, on
deputation.

No. AGRI(E)57/2021/Pt-1/31 — C - In pursuance of the recommendation of the Departmental Promotion Committee
and under provision of rule 7 (3) of the Meghalaya Agriculture Service Rules 1996, Dr. (Smti.) Palmsey M. Sangma.
Scientific Officer (Soil), Tura is hereby promoted to the post of Grade-Il of the MAS under L-16 of the pay matrix
plus usual allowances as admissible under the Rules, and posted as Assistant Director of Agriculture (PP), O/o the
District Agriculture Officer, East Khasi Hills, Shillong with effect from the date of taking over charge, vice, Smti.
Rikadakini Lamare, transferred.

No. AG RI(E)57/202 1/Pt-I/31 — D - In pursuance of the recommendation of the Departmental Promotion Committee
and under provision of rule 7 (3) of the Meghalaya Agriculture Service Rules 1996, Smti, Genialda Nongtdu,
Scientific Officer (Research), Jowai is hereby promoted to the post of Grade-I! of the MAS under L-16 of the pay
matrix plus usual allowances as admissible under the Rules, and posted as Assistant Director of Agriculture (Farmers”
Training), Jowai with effect from the date of taking over charge, vice, Shri Shembha Syngkon, on dual charge.

<!-- page 2 -->

_ No. AGRI(E)57/2021/Pt-1/31 — E- In pursuance of the recommendation of the Departmental Promotion Committee
~ and under provision of rule 7 (3) of the Meghalaya Agriculture Service Rules 1996, Shri Deebune Shilla Lamare,
Agriculture Development Officer, Mairang is hereby promoted to the post of Grade-II of the MAS under L-16 of the
pay matrix plus usual allowances as admissible under the Rules, and posted as Assistant Director of Agriculture (PP),
Nongpoh with effect from the date of taking over charge, vice, Shri Gerald Ford Kharkrang, on dual charge.
No. AGRI(E)57/202 1/Pt-1/31 — F - In pursuance of the recommendation of the Departmental Promotion Committee
and under provision of rule 7 (3) of the Meghalaya Agriculture Service Rules 1996, Dr. (Smti.) Salvadora Buhroy,
Horticulture Development Officer, Mawphlang C & R D Block is hereby promoted to the post of Grade-II of the
MAS under L-16 of the pay matrix plus usual allowances as admissible under the Rules, and posted as Assistant
Director of Horticulture (Planning, Admn & Acctts), HQ with effect from the date of taking over charge. vice, Shri
Blawanmon Keri, on dual charge.
No. AG RI(E)57/2021/Pt-I/3! —G - In pursuance of the recommendation of the Departmental Promotion Committee
and under provision of rule 7 (3) of the Meghalaya Agriculture Service Rules 1996, Shri Deimonlangki P. Thubru,
Horticulture Development Officer (PVFF), Jowai is hereby promoted to the post of Grade-II of the MAS under L-16
of the pay matrix plus usual allowances as admissible under the Rules, and posted as Assistant Director of
Agriculture, Mawkyrwat with effect from the date of taking over charge, vice, Smti. Minchi L. G. Momin. on dual
charge.
No. AGRI(E)S7/202 1/Pt-1/31 — H - In pursuance of the recommendation of the Departmental Promotion Committee
and under provision of rule 7 (3) of the Meghalaya Agriculture Service Rules 1996, Smti. Domesticity Lyngdoh,
Horticulture Development Officer, Mushroom, Upper Shillong is hereby promoted to the post of Grade-II of the
MAS under L-16 of the pay matrix plus usual allowances as admissible under the Rules, and posted as Assistant
Director of Horticulture. Mairang with effect from the date of taking over charge, vice, against the newly created
post.
No. AG RI(E)57/2021/Pt-U/31.—1- In pursuance of the recommendation of the Departmental Promotion Committee
and under provision of rule 7 (3) of the Meghalaya Agriculture Service Rules 1996, Smti. Ridalang W. Rangad.
Horticulture Development Officer, Thadlaskein, C & R D Block is hereby promoted to the post of Grade-II of the
MAS under L-16 of the pay matrix plus usual allowances as admissible under the Rules, and posted as Assistant
Director of Agriculture (Agro). AICRIP, Upper Shillong with effect from the date of taking over charge, vice, Smti.
Olivia Susngi, on dual charge.
On her joining to the post of Assistant Director of Agriculture (Agro), AICRIP, Upper Shillong she is
redeployed to the Directorate of Agriculture.
No. AGRI(E)S7/202 /Pt-1/31 — J - In pursuance of the recommendation of the Departmental Promotion Committee
eee ‘ : “ Medals “ect Service Rules 1996, Dr. (Shri) Basanda Gabil Momin,
L-16 of the pay matrix plus usual oo inane ae to the post of Grade-U ofthe MAS under
Agriculture (BATC), Upper Shillong with effect from he : : i" ae meee : iene
ee — e date of taking over charge, vice, Smti. Bankyntiew

<!-- page 3 -->

No.AGRI(E)S7/2021/Pt-U31 - K - In the interest of 6. 1.4 :
oe ae i In the interest of Public service, Smti, Sanday Chezel Ch. Marak, Horticulture
si a . Mawkyrwat, DHO, Mawkyrwat is transferred and posted as Scientific Officer (Soil),
c ura with effeet from the date of taking over charge. vice Dr (Smti.) Palmsey M. Sangma, promoted.
y a
(Sibhi CAadhuAaS)
Secretary to the Gow. of Meghalaya
Department of Agriculture & Farmers’ Welfare.
Memo.No.AGRI(E)S87/Pt-1/29 - L Dated Shillong, the I" July, 2025.
Copy to +
|. The Private Secretary to the Minister, Ic Department of Agriculture & Farmers Welfare for favour of
information of the Minister
2. The Private Secretary to the Chief Secretary for favour of information of the Chief Secretary.
3. The P.S. to the Chairman, Meghalaya Farmers (Empowerment) Commission for information of the
Chairman.
4. The P.S/P.A. to the Principal Secretary’/Secretary, Community & Rural Development Department.
3. The P.A. to the Commissioner & Secretary, Department of Agriculture & Farmers Welfare for kind
information of the Commissioner & Secretary.
6. The Commissioner & Secretary to the Govt. of Meghalaya, Personnel & AR Department.
7. The Secretary to the Govt. of Meghalaya, Department of Agriculture & Farmers Welfare.
8. The Accountant General (A&E), Meghalaya, Shillong.
9. The Director of Agriculture/Horticulture/RTTV/OSD, Food Processing, Meghalaya, Shillong.
10, The Managing Director, MgSFAC, Meghalaya, Shillong.
11. The Director Printing & Stationery, Meghalaya, Shillong for favour of publication of the above Notification
in the next issue of the Meghalaya Gazette.
12. Personnel & AR (A) Department/Community & Rural Development Department.
13. The Joint Director of Agriculture. Garo Hills, Tura.
\4. The Agriculture Executive Engineer (Mech) I/c Superintending Engineer -cum- Jt. Director of Agriculture
(Mech).
15, The Secretary, MSAMB, Meghalaya, Shillong,
16. The Principal BATC, Upper Shillong.
17. The District Agriculture Officer,
Shillong/Jowai/Nongpoh/Nongstoin/ Mawkyrwat/Mairang/K hlichrial/ Williamnagar/Baghmara
Tura/Resubelpara/A mpati.
18. The District Horticulture Officer, Shillong/Jowai/Nongpoh/Nongstoin/Mawkyrwat/Mairang/Khliehtiat/
Williamnagar/Baghmara/ Tura/ Resubelpara/A mpati.
19. The Treasury Officer,
Shillong (North) Jowai/NongpohNongstoin/Mawkyrwat/Mairang/K hlichriat Williamnagar’ Baghmara
Tura/Resubelpara/A mpati.
20. The Research Officer, District & Local Research Station & Laboratories, Shillong/Jowai Tura.
21. Officer concerned.
22. Personal File,
23. Office Copy.
By Orders ete.,
Joint Secretary to the Govt. of Meghalaya,
Department of Agriculture & Farmers’ Welfare
