---
doc_id: "c3ddf480e1dd70dd"
source_url: "https://megscpwd.gov.in/notifications/SW_S_87_2016_Pt_508.pdf"
ministry: "Office of the State Commissioner for Persons with Disabilities, Meghalaya"
title: "Constitution of the State Level Consultative Committee for monitoring the functionality of accessible transportation to Persons with Disabilities   [374 kb]"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e1e402593ab7f4cc"
---

<!-- page 1 -->

GOVERNMENTOFMEGHALAYA
SOCIAL WELFARE DEPARTMENT
NOTIFICATION
Dated Shillollg the 1F" August, 2023

No SW (S) 87/2016/Ptl508: The Governor of Meghalaya is pleased to constitute the State Level
Consultative ConU11ittee for monitoring the functionality of accessible transportation to Persons with
Disabilities with the followin g members:­

1. Chief Secretary to the Govt. of Meghalaya,

Chairperson

2. Principal Secretary/Commissioner & Secretary,

Co-Chairperson

Social Welfare Department
3. Commissioner for Persons with Disabilities, Shillong

Member-Secretary

4. Director of Social Welfare, Shillong

Member

5. Superintendent of Police, Shillong

Member

6. Superintendent of Police (Traffic), Shillong

Member

7. Commissioner of Transport, Shillong

Member

8. Director of Urban Affairs, Shillong

Member

9. Chief Engineer, PWD (Roads), Shillong

Member

10. Secretary, Meghalaya Urban Development Affairs, Shillong

Member

1[. Executive Director, Bethany Society, Shillong

Member

12. President, Federation of Persons with Disabilities, Shillong

Member

Functions of the Committee
I.
To work out on the different programmes for stakeholders on the various issues and problems
faced by Persons with Disabilities.
11.
To monitor the implementation of concession/benefits meant for Persons with Disabilities

Sd/Sam path Kumar, lAS ,
Principal Secretary to the Government of Meghalaya,
Social Welfare Department
