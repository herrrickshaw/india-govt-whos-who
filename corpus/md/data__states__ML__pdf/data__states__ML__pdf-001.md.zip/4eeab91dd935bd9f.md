---
doc_id: "4eeab91dd935bd9f"
source_url: "https://megsird.gov.in/publications/Guidelines_Installation_Biodigesters.pdf"
ministry: "State Institute of Rural Development (SIRD), Meghalaya"
title: "Guidelines for the Installation of Bio-digesters in Meghalaya"
date: ""
pages: 12
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "109343b3f0b81489"
---

<!-- page 1 -->

—___ GUIDELINES FOR
oe _—_
i mane a = ee —_
COMMUNITY AND RURAL DEVELOPMENT DEPARTMENT
GOVERNMENT OF MEGHALAYA

<!-- page 2 -->

GUIDELINES FOR
INSTALLATION OF BIODIGESTERS
IN
MEGHALAYA

<!-- page 3 -->

lOBS GUIDELINES
GUIDELINES FOR INSTALLATION OF BIODIGESTERS IN MEGHALAYA AS PER NOTIFICATION No. CDD.43/2014/199
Dated Shillong the 28" January 2015.
CONTENTS
CS
Ps ewe
Pa emesis sieges
Ta rainrimesreaigae
ee
a
iii

<!-- page 4 -->

IOBS GUIDELINES

ABBREVIATIONS
foe sreananees SY
iv

<!-- page 5 -->

IOBS GUIDELINES
1. Introduction:
The Installation of Biodigester (IOB) Scheme aims to provide assistance to the rural households that have
no toilets or do not have adequate facilities for safe sanitation. This Scheme is a part of the larger strategy
of the Community and Rural Development Department to eradicate the practice of open defecation, and
support the ongoing efforts of the Government to develop environmentally sound habitations all over
the State. The Biodigester should be seen not merely as a toilet, but as an asset that supports livelihood,
symbolizes social position and promotes hygiene and sanitary habits as a cultural expression. A good
sanitized home harmonizes with the natural environment, protecting the family from diseases, leaving an
enduring feeling of well-being.
2. The Rationale:
As per the estimates made by UNICEF and WHO, about 1/7th of world population still openly defecate in
the absence of toilets and 60% of this population lives in India. According to Census of india 2011, 69%
households in rural areas and 19% in urban areas have no access to toilets, leading to open defecation.
This earns India the dubious distinction of being a number one country in the world in open defecation.
The global impact of poor sanitation on human health and infant/child mortality is profound where almost
10 million children under 5 die globally every year, out of which 2.4 million die in India.
=
ca
&
we a Se a
80.0 ae ‘
60.0 ait | 2021
40.0 go | 2 s ” 2003
0.0
Total Rural Urban
Percentage of households without latrines in India (Source: 2001-2011 Census)
Open defecation is mainly due to the absence of toilets or because the available toilets are unusable due to
| dirtiness or for being located far from the habitat. Open defecation is unpleasant aesthetically and leads to
a number of health and environmental hazards that include pollution of water sources and contamination
of food. Some of the water borne diseases arising out of open defecation are viral gastroenteritis, typhoid,
cholera, diarrhoea (that annually kills 5 lakhs children) and viral hepatitis (100 cases per 100,000 people).
Eradication of open defecation is therefore a big challenge but it can, be most certainly achieved through
awareness, education, and the implementation of various sanitation programmes.
1

<!-- page 6 -->

lOBS GUIDELINES
3. The Meghalaya Scenario:
As per the 2011 census, the population in Meghalaya is 29,64,007 and the decennial growth rate stood at
a staggering 27.82 per cent which is among the highest in the country. The 2011 census data on houses,
household amenities and assets, highlighted that out of a total of 5,38,299 households in the state, 34.3
per cent still practice open defecation.
Of the 4,22,197 households in rural Meghalaya, open defecation is practiced by 43.1 per cent households,
while the percentage in urban areas consisting of 1,16,102 households is 2.4. Only 67 per cent of the
schools in Meghalaya have functional toilets. Though the percentage of households not having latrines
has decreased from 48.8 per cent in 2001 to 37.1 per cent in 2011, which is a positive trend, but still a lot
of work needs to be done.
Sewage disposal is through septic tanks with or without soak pit which require periodic sludge cleaning.
With the “Prohibition of employment as manual scavengers and their rehabilitation Act, 2013” engagement
of manual labour for septic tank cleaning is an offence and cleaning is permitted only through mechanical
means. Hence there is an urgent need to adopt better and innovative technologies such as installation of
biodigesters as a replacement as they leave no sludge, and are zero maintenance structures.
Though the Nirmal Bharat Abhiyan (NBA), earlier known as the Total Sanitation Campaign (TSC), is being
implemented in Meghalaya the coverage of households and educational institutions still falls short by 37.1
per cent and 33% respectively. To augment the coverage and improve sanitation by way of eradicating
open defecation, the Government of Meghalaya proposes to Install Biodigesters under the State Rural
Infrastructure Development Initiative (SRIDI). :
4, The Biodigester Technology — An Eco-friendly solution for disposal of Human Waste:
The Defense Research & Development Establishment (DRDE), Gwalior has introduced the Biodigester
technology as a solution for human waste disposal with the following objectives:
(i) To provide an eco-friendly & cost-effective sanitation solution that will have wide applicability under
different climatic conditions and is easy to transport and install even in hilly terrains.
(ii) To minimize water consumption.
(iii) To recycle effluent water by reusing of liquid water for gardening and irrigation purposes.
(iv) To reduce organic waste by more than 90%.
(v) To reduce pathogens by more than 99%,
(vi) To generate odourless and inflammable biogas that can be used for cooking and lighting.
The Biodigester technology is a system that breaks down human excreta into usable water and gas
through anaerobic process. Anaerobic means the micro-organisms digest the food in the absence of
oxygen. Biodigesters does not have any geographical or temperature limitation and they dispense the
2

<!-- page 7 -->

lOBS GUIDELINES
need to set up large sewerage networks. The human wastes are sent to the special chamber that consists
of anaerobic bacteria. The bacteria in the chamber will digest all the human wastes, and in the process of
digestion the bacteria releases methane gas which can be used for cooking or lighting. The liquid effluent
discharged from the digester can be used for irrigation, household gardening etc. which enhances soil
fertility.The bacteria consortium degrades night soil at an atmospheric temperature between -55°C to
+60°C and produces reusable water and the smell is eliminated almost completely. The DRDO has come
up with this innovative technology for sanitation which can replace the conventional septic-tank model of
sanitation by innovative biodigester tanks using anaerobic micro-organism which is superior but cheaper
than the septic-tank model. It is a continuous biological/biodegradation process and works on the principle
of anaerobic biodegradation. Large polymers are converted into simpler monomers and these simple
monomers are then converted into volatile fatty acids which are then converted into acetic acid, carbon
dioxide and hydrogen; finally giving out methane and carbon dioxide. .
5. Advantages of Biodigesters:
(i) Disposes human waste in a 100% eco-friendly manner.
(ii) Does not require any septic tank, sewage tank connectivity.
(iii) Almost 100% maintenance free.
(iv) More than 99% elimination of pathogens.
(v) Economically viable.
(vi) Size: 1/4th to 1/10th compared to a septic tank.
(vii) Less space requirement.
(viii) Low material/ construction cost.
(ix) Can treat bathroom/ kitchen wastewater as well.
(x) No foul smell.
6. Aims and Objectives of IOB Scheme:
The aims and objectives of IOB Scheme are to:
(i) Achieve zero open defecation and accelerate sanitation coverage in all villages by 2017.
(ii) Construct eco-friendly and cost-effective toilets.
(iii) Encourage the use of recycled effluent water for irrigation purpose.
(iv) Improve health conditions of the rural people through proper hygiene.
(v) Bring about an improvement in the overall quality of life in the rural areas.
3

<!-- page 8 -->

IOBS GUIDELINES

(vi) Motivate communities / village councils to promote sustainable sanitation facilities through awareness
and health education.

(vii) Cover all schools in the rural areas with proper sanitation facilities and undertake proactive promotion
of hygiene education and sanitary habits among students.

(viii) Develop community managed environmental sanitation systems focusing on solid and liquid waste
management for overall cleanliness in the rural areas.

7. Institutional Mechanism and Planning Process:

(i) State Level: The Community and Rural Development (C&RD) Department will be the Nodal Department
that will designate a Project Implementing Agency (PIA) under its administrative control having
within it a Technical Support Team (TST) to undertake the planning, implementation, monitoring and
evaluation of the IOB Scheme at the state, district, block and village levels. A team of trained Project
Engineers will constitute the TST.

During Phase — | of the Programme, the SIRD, Nongsder, Meghalaya will be the PIA, covering about
150 toilets in 3 Blocks, on a pilot scale. Once the Phase — | is complete and the systems are perfected,
the implementation will be handed over to the Deputy Commissioners and Block Development
Officers for Phase — Hl.

The State SRIDI Committee will decide on the proposals for locating the Biodigester Toilets and the
Directorate of C&RD and SIRD, will provide all the requisite support to the State SRIDI Committee in
this regard.

(ii) District Level: The Deputy Commissioner (DC) of each district will be the District Project Coordinator
(DPC). The Project Director of DRDA will be function as the Additional District Project Coordinator. The
District Implementation Committee (DIC) headed by the Deputy Commissioner will be constituted, to
undertake the planning activities at the district level. The Committee will ensure that no duplication
of efforts will be done between NBA and IOBS.

(iii) Block Level: The Block Development Officer (BDO) shall be the Chairman of the Block Implementation
Committee (BIC) comprising of representatives from relevant Line Departments in the Block. The TST
will assist the BIC in the implementation of the project.

8. Implementation Process:

(i) Scheme Of Implementation:

Scheme-1: Construction and commissioning of new bio-tank: A new bio-tank of suitable capacity
can be constructed for the house or cluster of houses according to the specifications in the Technical
Manual. This approach is suitable where sufficient space for new construction is available. Alternatively,
readymade FRP bio-tank can also be installed by obtaining the same as per the norms prescribed in
the Procurement Manual from certified agencies/TOT holders of DRDE technology depending on the
cost and suitability.

4

<!-- page 9 -->

IOBS GUIDELINES

In the case where the existing septic tank system is already in dilapidated condition and beyond

economic repair the existing septic tank can be abandoned and a new bio-tank of suitable capacity

can be constructed or installed. This scheme is most suitable where a new bio-tank is constructed to
cater to a cluster of households.

Scheme-2: Modification of existing septic tank into bio-tank: In all the other areas where availability

of land is a constraint and/or the existing septic tank is in good working condition, its modification

into bio-tank may be considered. Modification of existing septic tank can be planned in the following
steps and may take 15-20 days:

(a) The existing septic tank should be bypassed for the period of modification and the existing toilets
can be connected to a readymade mobile FRP bio-tank of suitable size so that users continue to
use their toilets during this transition period. FRP bio-tank for this purpose will be supplied by
the certified agencies/TOT holders of DRDE and the same will be used for other projects of this
nature.

(b) The existing septic tank should be opened and de-sludge. It should then be cleaned thoroughly
and left open for 3-4 days for drying.

{c) Necessary repair and modification of existing septic tank should be carried out as per requirement
by constructing required partition walls, inlet and outlets, fixing poly-grass mats on side and
partition walls etc. This work may be carried out as prescribed in the Technical Manual.

{d) After commissioning of new bio-tank, the portable FRP bio-digester tank may be shifted to new
location/place of work and above procedure is repeated.

(i) Implementation: The implementation of works should be taken up as per the approved plans
and estimates and the same shail be supervised by the TST. No deviation from the approved plan,
Technical Manual and Procurement Manual will be permitted.

(iii) Technical Inputs: Designs and specifications prescribed in the Technical Manual shail be scrupulously
followed for the installation of biodigesters.

{iv) Procurement of Materials: Procurement of materials shall be done in accordance with the norms,
terms and conditions prescribed in the Procurement Manual.

9. Financial Management:

(i) Financial Resources: C&RD Department being the Nodal Department will mobilise funds through
various sources that will be utilised for the |OBS or through convergence with other programmes well
ahead of time and and indicate the number of projects that can be undertaken in a year.

(ii) Release Of Funds: Upon approval of the projects by the State SRIDI Committee, funds will be
transferred to the PIA concerned by the Directorate of C&RD/SRES (fund channelling agency), who
will in turn transfer them into the specific account of the District implementation Committee (DIC).

5

<!-- page 10 -->

{OBS GUIDELINES
The funds will be transferred to the respective Blocks by the respective Deputy Commisioners then
to the respective accounts of the partners, by the BDOs.
Funds will be released in two instalments to the DIC in the ratio of 50:50. Release of funds will be
only through e-transfer. Upon utilization of 60 percent of the funds of the first instalment the BDO
shall seek next instalment through a prescribed format and release will be subject to the following
conditions:
(1) Submission of utilization certificates on the funds utilized.
(2) Submission of progress reports, both physical and financial.
(3) Confirmation of the receipt of partner’s contribution.
The release of funds for the next financial year will depend on the submission of the audit report and
utilization certificate of the previous year, to the satisfaction of the Nodal Department. The Nodal
Department may suspend assistance to the concerned partner for improper utilisation of funds and
further assistance will be retored only after remedial measures have been affected. The Deputy
Commissioners may initiate legal action and recover the amount release, in cases of default.

(ili) Partner’s Contribution: The Partner’s contribution shall be 25% of the cost of Biodigesters. The
details of the various slabs of partner’s contributions are laid down in detail, in the Procurement
Manual that is separately notified

(iv) Allocation of Funds: 95% of the total budget shall be utilised for installation of biodigesters under
Scheme-I and Scheme-ll. The administrative expenses shal! be limited to 5% of the total allocation
including capacity building and training.

10. Training and Capacity Building:

Training and Capacity Building shall be an integral part of the IOBS. Training of personnel/agencies

responsible will be done systematically.

(i) The State Institute of Rural Development (SIRD) shall be the nodal agency for Capacity Building and
Training under the IOBS.

(ii) Knowledge Sharing and familiarization of all stakeholders on the guidelines, technical aspects, mode
of implementation, etc. is necessary.

(iii) All key functionaries will need to be trained in discharging their responsibilities. This will include the
Partners, Block level, District and State level personne! involved in implementing the programmes.
Basic training on core issues will be arranged by the State Government with priority accorded to
its key functionaries, especially the Districts Program Coordinator, the Block Development Officer
and other key functionaries. The SIRD shail empanel competent master trainers at the District
and Block level who will undergo an intensive training at the SIRD and who shall in turn train the
stakeholders.

6
