---
doc_id: "7a4c748cdf2bf3fa"
source_url: "https://gad.meghalaya.gov.in/assets/docs/tenders/2026/CorrigendumSohraCircuitHouse.pdf"
ministry: "General Administration Department, Meghalaya"
title: "Corrigendum: Onboarding Operators for Furnishing and Operation & Maintenance of New Circuit House, Sohra, Shillong"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "9131fbdb5b1593f5"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
GENERAL ADMINISTRATION (A) DEPARTMENT
No. GAA. 28/2026/7 Dated Shillong theyuly, 2026
CORRIGENDUM
In partial! modification of this Department’s Request For Proposal No. GAA. 28/2026,
relating to Onboarding Operators for Furnishing and Operation & Maintenance of New Circuit
House, Sohra, Shillong is hereby extended as follows:
a . 10" July, 2026 . il at:
Last date of receiving queries uy, at 5 P.M through email at
meghalayagad@gmail.com
21" July, 2026 at 10 A.M at Committee Room
Pre-Bid Confe 2
4, Main Secretariat, Shillong.
Last date for submission of the Bids On 4" August, 2026 before 5 P.M.
Sd/-
Under Secretary to the Govt. of Meghalaya
General Administration Department (A)
Memo. No. GAA. 28/2026/7 Dated Shillong theshuly, 2026
Copy to:-
U- The State Informatics Officer, National Informatics Centre, Meghalaya, Shillong for
uploading the Corrigendum in the Department website gad.meghalaya.gov.in
2. The Director of Information & Public Relation, Meghalaya, Shillong to publish on any |
(one) leading local News Paper i.e English, Khasi & Garo for circulation
By Order ete,.
Under Secretary to the Govt. of Meghalaya
General Administration Department (A)
orNiag
zy
wy NAG
mS
