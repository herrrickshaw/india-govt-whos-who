---
doc_id: "8364ecffdba64cb8"
source_url: "https://mshec.megeducation.gov.in/documents/tenders/tender-notice-extension-pmusha.pdf"
ministry: "Meghalaya State Higher Education Council"
title: "Tender Notice - Extension of Sale of Tender(s) & date of submission for Projects under PM-USHA"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7bb7484f7bcac4ef"
---

<!-- page 1 -->

STATE HIGHER EDUCATION COUNCIL [SHEC]
MEGHALAYA ::: SHILLONG
MEGHALAYA ACT NO.3 OF 2018
Vide Notification No. LL(B).78/2017/16, dated 27.04.2018

_______________________________________________________________________________

_________________________

EXTENSION OF NOTICE INVITING TENDER
In Continuation to Short Tender Notice No. SHEC/PM-USHA/CORR/58/2024-25/2
Dated 08.10.2024 the date for Tender and last date of submission is hereby extended and
renotified as mentioned below:A
Sr. No.

Particulars

Details
No. SHEC/PM-USHA/CORR/58/2024-25/5 Dated
23.10.2024
a. Construction of Classroom 2nd Floor Building in
Captain Williamson Memorial Government College
including providing & fitting of Furnitures,
Bolsalgre, Baghmara.
a. . 3,48,72,957.00 (Rupees. Three Crore Forty Eighty
Lakhs Seventy Two Thousand Nine Hundred Fifty
Seven) only
b. . 1,28,20,051.00 (Rupees. One Crore Twenty Eight
Lakhs Twenty Thousand Fifty One) only
. 4,000.00/- non-refundable, in the form of Demand Draft/
B.G in favor “State Higher Education Council,
Meghalaya”.
18 (Eighteen) Months from the date of issue of Final Work
Order.
2% (two percent) of the Tender value for the general and
1% (one percent) for the Scheduled Caste/Tribe shall have
to be enclosed (refundable) with the tender in the form of
Demand Draft/ BG in favor “State Higher Education
Council, Meghalaya”
Rates are to be quoted on flat percentage basis i.e. AT PAR
/ ABOVE the Schedule of Rates for Building Works for
2021-22 as applicable in Khasi Hills/Garo Hills District and
AT PAR / ABOVE the Schedule of Rates for Electrical
Works for 2021-22 as applicable in the state of Meghalaya.

1

Tender Notice No

2

Description of work

3

Approximate Tender Value

4

Cost of Tender Document

5

Time of Completion

6

Earnest Money Deposit

7

Rates

8

Date of Sale of Tender

9

Last date for Sale of Tender Document

06th November 2024 till 03:00pm

10

Last date of submission of Tender Document
(Technical Bid)

06th November 2024 till 04:00pm

11

Opening of Tenders (Technical Bid)

11th November 2024 at 11:00am

12

Opening of Financial Bid (only for
qualified bidders)

To be notified

14th October 2024

Sd/- A.Ch. Marak, I.A.S.,
Secretary to the Government of Meghalaya &
State Project Director, PM-USHA
Education Department
Meghalaya ::: Shillong

1

<!-- page 2 -->

STATE HIGHER EDUCATION COUNCIL [SHEC]
MEGHALAYA ::: SHILLONG
MEGHALAYA ACT NO.3 OF 2018
Vide Notification No. LL(B).78/2017/16, dated 27.04.2018

_______________________________________________________________________________

_________________________

EXTENSION OF NOTICE INVITING TENDER
In Continuation to Short Tender Notice No. SHEC/PM-USHA/CORR/58/2024-25/3
Dated 08.10.2024 the date for Tender and last date of submission is hereby extended and
renotified as mentioned below:B
Sr. No.

Particulars

1

Tender Notice No

2

Description of work

Details
No.

SHEC/PM-USHA/CORR/58/2024-25/6

Dated

23.10.2024
Construction of Indoor Stadium and Auditorium at
Williamnagar Government College, Williamnagar
. 4,77,33,357.00 (Rupees. Four Crore Seventy Seven

3

Approximate Tender Value

Lakhs Thirty Three Thousand Three Hundred fifty
Seven) only
. 4,000.00/- non-refundable, in the form of Demand Draft/

4

Cost of Tender Document

B.G

in

favor

“State

Higher

Education

Council,

Meghalaya”.
Time of Completion

18 (Eighteen) Months from the date of issue of Final Work
Order.
2% (two percent) of the Tender value for the general and 1%
(one percent) for the Scheduled Caste/Tribe shall have to be

5

Earnest Money Deposit

enclosed (refundable) with the tender in the form of Demand
Draft/ BG in favor “State Higher Education Council,
Meghalaya”
Rates are to be quoted on flat percentage basis i.e. AT PAR /
ABOVE the Schedule of Rates for Building Works for 2021-

6

Rates

22 as applicable in Khasi Hills/Garo Hills District and AT
PAR / ABOVE the Schedule of Rates for Electrical Works
for 2021-22 as applicable in the state of Meghalaya.

7

Date of Sale of Tender

8

Last date for Sale of Tender Document

9
10
11

14th October 2024
06th November 2024 till 03:00pm

Last date of submission of Tender Document

06th November 2024 till 04:00pm

(Technical Bid)

11th November 2024 at 11:00am

Opening of Tenders (Technical Bid)
Opening of Financial Bid (only for

To be notified

qualified bidders)

Sd/- A.Ch. Marak, I.A.S.,
Secretary to the Government of Meghalaya &
State Project Director, PM-USHA
Education Department
Meghalaya ::: Shillong

2

<!-- page 3 -->

STATE HIGHER EDUCATION COUNCIL [SHEC]
MEGHALAYA ::: SHILLONG
MEGHALAYA ACT NO.3 OF 2018
Vide Notification No. LL(B).78/2017/16, dated 27.04.2018

_______________________________________________________________________________

_________________________

EXTENSION OF NOTICE INVITING TENDER
In Continuation to Short Tender Notice No. SHEC/PM-USHA/CORR/58/2024-25/1
Dated 08.10.2024 the date for Tender and last date of submission is hereby extended and
renotified as mentioned below:C
Sr. No.

Particulars

Details
No.
SHEC/PM-USHA/CORR/58/2024-25/4
Dated
23.10.2024
Supply of Lab Equipments and various other items for Skill
Courses in St. Edmund’s College, Shillong.
. 5,000/- non-refundable, in the form of Demand Draft/
B.G in favor “State Higher Education Council,
Meghalaya”.
2% (two percent) of the Tender value for the general and 1%
(one percent) for the Scheduled Caste/Tribe shall have to be
enclosed (refundable) with the tender in the form of Demand
Draft/ BG in favor “State Higher Education Council,
Meghalaya”

1

Tender Notice No

2

Description of work

3.

Cost of Tender Document

4.

Earnest Money Deposit

5.

Tender Value

6.

Date of Sale of Tender

7.

Last date for Sale of Tender Document

06th November 2024 till 03:00pm

8.

Last date of submission of Tender
Document(Technical Bid)

06th November 2024 till 04:00pm

9.

Opening of Tenders(Technical Bid)

11th November 2024 at 11:00am

10.

Opening of Financial Bid(only for
qualified bidders)

To be notified

Rs. 5,00,00,000.00 (Rupees. Five Crore) only
14th October 2024

Copy of Tender documents may please be purchased from State Higher Education Council, Meghalaya on
payment of the cost of tender and the Cost of tender document along with EMD mentioned above may please be
deposited in the form of ‘demand draft’/‘pay order’/ Receipt in favour of ‘State Higher Education Council’, Payable
at Shillong. Please write the name of company on the reverse side of the ‘Demand Draft’/’Pay order’/Receipt. Please
note that the downloaded tender document is subject to verification with original document as given in the Website.
The Secretary to the Govt. of Meghalaya, Education Department, Meghalaya reserves the right to reject any or all the
tenders
without
assigning
any
reason.
Note: Any changes or any further notifications in respect to the above Tender document shall be made
available only at the above-mentioned website. Hence respective vendors are advised to visit the
website regularly for the above purpose.
1.
Non-Tribal Contractors shall have to produce valid Trading License before purchasing Tender Forms failing
which no tender papers will be issued. Other details can be seen in the Detailed Notice Inviting Tender.
2.
The Secretary, Education Department, Govt. of Meghalaya, Shillong, reserves the right to accept or reject
any or all tender without assigning any reason thereof.
Sd/- A.Ch. Marak, I.A.S.,
Secretary to the Government of Meghalaya &
State Project Director, PM-USHA
Education Department
Meghalaya ::: Shillong

3
