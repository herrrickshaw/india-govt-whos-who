---
doc_id: "4abc8abcb69eb874"
source_url: "https://cdn.s3waas.gov.in/s3b86e8d03fe992d1b0e19656875ee557c/uploads/2022/02/2022022314.pdf"
ministry: "East Jaintia Hills"
title: "Revised Order dt. 19.02.2022, regarding Plying of Vehicles through Sonapur Bridge"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "69fdec32e5797aba"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA

Phone No. 03655 - 230713

OFFICE OF THE DEPUTY COMMISSIONER
EAST JAINTIA HILLS DISTRICT

Fax No. 03655
e-mail id :

230033

inform

the

dc.khliehriat@gmail.com

KHLIERIAT

NOTICE

No.

EJHD/CON.11/2013/PT.IV/193.

(19.02.2022)
This

is

to

that

orders

No.

EJHD/CON.11.2013/PT.IV/178, Dt. 17.02.2022, No. EJHD/CON.11.2013/PT.IV/189, Dt. 18.02.2022
and No. EJHD/CON.11.2013/PT.IV/190, Dt. 18.02.2022 is hereby withdrawn with immediate effect
till further orders. However, only one vehicle is alowed to pass through the said bridge at a time
including the convoy vehicles travelling on Election Duties to the state of Manipur.

Sd/-Deputy Commissioner
East Jaintia Hills District

Khliehriat

Memo No. EJHD/CON.11/2013/PT.IV/193 (A).

Dated Khliehriat the 19h February 2022

Copy forwarded to:
1.

PS to the Hon'ble Chief Minister of Meghalaya with a request to bring to the notice of the

2.

Hon'ble Chief Minister accordingly.
PS to the Hon'ble Deputy Chief Minister of Meghalaya with a request to bring to the notice of
the Hon'ble Deputy Chief Minister accordingly.

3.

PS to the Chief Secretary to the Government of Meghalaya with a request to bring to the notice

of the Chief Secretary with a request to take up with the counterparts of Assam, Mizoram,
Manipur and Tripura.

4.
5.
6.

The Commissioner of Division, Khasi, Jaintia & Ri Bhoi Districts for favor of kind information.
The Deputy Commissioner, Cachar, Karimganj and Hailakandi Districts, Assam with a
request to kindly cause wide publicity within your jurisdiction.
The Deputy Commissioner, Aizawl, Lunglei, Champhai, Siaha, Kolasib, Serchhip

Lawngtlai, Mamit, Saitual, Hnahtaial and Khawzawl Districts, Mizoram with a request to
kindly cause wide publicity within your jurisdiction.

Deputy

Commissioner,

Dhalai,

Gomati,

Khowai,

North Tripura,

Sipahijala,

1.

The

8.

wide publicity within your jurisdiction.
The Deputy Commissioner, Bishnupur, Chandel, Churachandpur, Imphal East, Imphal

9.

Tengnoupal, Thoubal and Ukhrul Districts, Manipur, with a request to kindly cause wide
publicity within your jurisdiction.
The Deputy Commissioner West Jaintia Hills District/Ri Bhoi District for information and

South Tripura, Unakoti and West Tripura Distries Tripura with a request to kindly cause

West, Jiribam, Kakching, Kamjong, Kangpokpi, Noney, Pherzawl, Senapati, Tamenglong

necessary action.

10.

The Secretary to the Government of Meghalaya, Home (Police) Department for favor of kind

information.
11.

The Secretary to the Government of Meghalaya, Political Department for favor of kind
information.

<!-- page 2 -->

The Secretary to the Ciovernment of Meghalaya, Public Works (R&B) Department, Shillong for
information.

13.

The Superintendent of Police, East Jaintia l lills District/West JaintiaIlills/Ri Bhoi Districts, for
information and nccessary action. He is also to take up with his counterparts of Assam

14.

The Superintendent of Police, Cachar, Karimganj and Hailakandi, Assam for information and
necessary action.

15.

The Supcrintendent of Police, Aizawl, Lunglei, Champhai, Siaha, Kolasib, Serchhip,
Lawngtlai, Mamit, Saitual, Hnahtaial and Khawzawl Districts, Mizoram for information
and necessary action.

16.

17.

18.

19
20.
21.

22
23
24.

The Superintendent of Police, Dhalai, Gomati, Khowai, North Tripura, Sipahijala,
South Tripura, Unakoti and West Tripura Districts Tripura for information and necessary
action.

The Superintendent of Police, Bishnupur, Chandel, Churachandpur, Imphal East, Imphal
Pherzawl, Senapati, Tamenglong,
West, Jiribam, Kakching, Kamjong, Kangpokpi, Noney,
and necessary action.
Tengnoupal, Thoubal and Ukhrul Districts, Manipur for information
The Chief Engineer (National Highway) PWD (Roads) Meghalaya, Shillong for information.
Khliehriat for
The Executive Engineer, PWD NEC Division, East Jaintia Hills District,
information and necessary action.

Khliehriat for
The Block Development Officer, Khliehriat Block, East Jaintia Hills District,
information and necessary action.
Khliehriat for
The District Information & Public Relation Officer, East Jaintia Hills District,
information and necessary action.
in the district
The District Informatics Officer, East Jaintia Hills District with a request to upload

website accordingly.
The Project Director, NHAI, Lower Lachumiere, Near Superintendent Engineer, 3 Floor, PWD,
Shillong for information and necessary action.
The Waheh Chnong of Kuliang, Borsara, Pyrtakuna, Lumphyllut, Lumsoskie, Umkiang,
Donaskul, Dona Umbluh, Donanhoi, Ratacherra, Malidor, Shymphlong, Lummyrli, Huroi,
Hingaria, Leijri and Lahalein for information and necessary

action.

Additional Deputy Commissioner
East Jaintia Hills District
Khliehriat
