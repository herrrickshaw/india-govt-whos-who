---
doc_id: "3dea20bd4cfe7ee7"
source_url: "https://megamb.gov.in/Documents/addenum_260827_181905.pdf"
ministry: "Meghalaya State Agricultural Marketing Board, Meghalaya"
title: "Addendum to Notice Inviting Tender – Digital Traceability System for Lakadong Turmeric   With reference to the Notice Inviting Tender (NIT) for the  Design, Development & Implementation of a Digital Traceability System for Lakadong Turmeric , the Tender/Proposal Processing Fee of  ₹5,000/-  and Earn"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4035bede675a782f"
---

<!-- page 1 -->

THE MEGHALAYA STATE AGRICULTURAL MARKETING BOARD
CLEVE COLONY, SHILLONG – 793003
Directorate of Agriculture, Cleve Colony, Shillong-793001

Dtd:27th August, 2026
Addendum to Notice Inviting Tender
Original NIT Reference No.: MSAMB/IDTS/68/2026-27/1
NIT Date: 3rd August, 2026
With reference to the above-mentioned Notice Inviting Tender (NIT) issued by the
Meghalaya State Agricultural Marketing Board (MSAMB) for the Design, Development &
Implementation of a Digital Traceability System for Lakadong Turmeric, the following
amendments/additions shall be read as part of the NIT:
1. Clause 6 – Tender/Proposal Processing Fee: The Tender/Proposal Processing Fee of
₹5,000/- may be paid through NEFT/RTGS. Proof of payment/transaction details shall be
submitted along with the bid.
2. Clause 7 – Earnest Money Deposit (EMD): The EMD of ₹60,000/- may be paid through
NEFT/RTGS. Proof of payment/transaction details shall be submitted along with the bid.
3. Clause 11 – Submission of Proposal: Bidders may submit their bids online through email
at ambmg-meg@nic.in on or before 31st August, 2026. Technical and Financial Proposals shall be
submitted as separate files and clearly identified accordingly.
All other terms and conditions of the NIT shall remain unchanged.
Sd/Managing Director
MSAMB, Shillong
