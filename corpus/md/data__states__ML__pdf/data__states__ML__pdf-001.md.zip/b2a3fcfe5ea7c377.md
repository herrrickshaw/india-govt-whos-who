---
doc_id: "b2a3fcfe5ea7c377"
source_url: "https://megscpwd.gov.in/notifications/not-24-09-25.pdf"
ministry: "Office of the State Commissioner for Persons with Disabilities, Meghalaya"
title: "Constitution of the Governing body to manage the Meghalaya State Fund for Persons with Disabilities for a period of three years"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c33f8b995ca4753b"
---

<!-- page 1 -->

G OVERI\MENT OF 1VIE GHALAYA

SOCIAL WELFARE DEPARTMENT

i\OTIFICATION
Dated Shillong the 24th September, 2025

f{o SW (S) 146/20231Pt lll0: In supersession to this Department's Notification No SW (S)
ru612A23l19 dated 11.08.2023 and in pursuance to Section 41 (1) of the Central Rules on the

Rights of Persons with Disabilities Rules, 2A17, the Governor of lvleghalaya is pleased to
constitute the Governing body to manage the Meghalaya State Fund for Persons with
Disabilities for a period of three years with effect from the date of issuing this Notification and

until further orders with the following members:-

1. Additionai Chief Secretary/Principal Secretary/Commissioner

2. Corntnissioner for Persons with Disabilities, Shillong 3. -Ioint Secretary, Social Welfare Department
4. Joint Secretary, Health & Family Welfare Department 5. Additional Chief Executive Officer, SSIRPD (SRCDA)
5" Financial Adviser, Sccial Weifare Department
. F inance Account Otficer, Oio CPWD
8. Srnti tser1ha C Dkhar, CEO, Bethany Scciety, Laitumkhrah 9. VIrs Jasrnine Sangma, Montfort Centre for'Education, Tura & Secretary, Social Welfare Department

7

Chairperson
Member Secretary
Member
Member
Member
Member
Member
N,{ember

Member

Functions of the Governing tsody
i. The Comrnittee w:ill verify and e,raluate the application submitted by the eligible
organisations.
ii. The Comrnittee will submit its report for consideration and sanctioning of the proposal
by the state government,

sd/(Sampath Kumar, IAS),
Principal Secretary to the Governrnent of Meghalaya,
Social W'elfare Department
