---
doc_id: "e9f2feeb5e5bd5f1"
source_url: "https://gad.meghalaya.gov.in/assets/docs/notifications/2026/allotment_quarters_pwds.pdf"
ministry: "General Administration Department, Meghalaya"
title: "Office Memorandum: Allotment and provision of accessible infrastructure in Government residential quarters for persons with Disabilities (PwDs)   (2.05 MB)"
date: ""
pages: 3
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "ecad3e84ea523d11"
---

<!-- page 1 -->

| GOVERNMENT OF MEGHALAYA
GENERAL ADMINISTRATION (B) DEPARTMENT
No.GAB.34/2026/1 Dated Shillong, the 28" July, 2026.
OFFICE MEMORANDUM
Subject: Allotment and provision of accessible infrastructure in Government
residential quarters for Persons with Disabilities (PwDs).
The undersigned is directed to say that the Government has been considering measures to
ensure equitable access, inclusive residential accommodation and barrier-free infrastructure
in Government residential quarters for Persons with Disabilities (PwDs).
In pursuance of the Rights of Persons with Disabilities Act, 2016 and in order to facilitate
accessible residential accommodation for eligible Government employees with benchmark
disabilities, the following provisions shall be observed in respect of Government residential
quarters under the administrative control of the General Administration Department:
1. Applicabili:
1.1. These provisions shall apply to Government residential quarters under the administrative
control of the General Administration Department.
1.2. The provisions shall apply to regular Government employees possessing disabilities
certified under the Rights of Persons with Disabilities Act, 2016.
2. Eligibility:
To qualify for allotment under PwD category, an applicant shall:
2.1 Possess a valid Unique Disability Identity (UDID) Card or disability certificate issued by
the competent authority;
2.2 Fulfill any other such conditions as may be prescribed by the Government from time to
time.
3. Allotment of Quarters
3.1. Ground-floor quarters shall, as far as practicable, be preferentially allotted to employees
with locomotor disabilities or severe mobility impairments.
3.2. Preference may also be accorded for allotment of quarters located in proximity to the
employee’s place of posting, subject to availability.
3.3. A separate waiting list for PwDs shall be maintained.
5, Accessibility and Barrier-Free Infrastructure
As far as practicable, designated quarters earmarked for PwD employees shall incorporate
accessible and barrier-free features in conformity with applicable accessibility standards and
Government guidelines, including the following: .
Page | of 3

<!-- page 2 -->

5.1. Access and Entry Facilities
The approach to and entry into residential quarters shall be designed or Modified, wherever
feasible, to permit safe and convenient access for persons with disabilities, At least one
entrance to the residential unit shall be accessible and clearly identifiable. Ramps, where
provided, shall be constructed with non-slip surfaces and suitable gradients and shall be
equipped with handrails on both sides. Entrance landings shall provide adequate space for
wheelchair users to maneuver comfortably. Appropriate tactile or textural indicators may also
be provided for the benefit of persons with visual impairments.
5.2. Sanitary and Bathroom Facilities
Toilets and bathrooms in designated quarters shall, as far as practicable, be adapted to
facilitate safe and independent use by persons with disabilities. Such facilities may include
non-slip flooring, grab bars, support rails, level-entry access, accessible washbasins and
fittings, and sufficient maneuvering space for wheelchair users. Easy-to-operate fixtures and
emergency assistance mechanisms may be installed wherever feasible.
5,3. Staircases and Vertical Movement
Where staircases form part of the access route, appropriate safety features shall be provided
to facilitate movement by persons with disabilities. Such features may include continuous
handrails, warning tiles, tactile indicators, contrasting edge markings and other measures
intended to improve visibility, orientation and safety. Braille indicators may also be provided
wherever practicable.
5.4. Internal Accessibility and Essential Utilities
The internal layout of designated quarters shall, as far as practicable, permit convenient
movement and use by persons with disabilities. Doorways, corridors and circulation spaces
shall be designed or adapted to facilitate wheelchair access. Electrical switches, service
controls and other frequently used fixtures shall be installed at accessible heights and
locations. Corridors and common circulation areas shall remain unobstructed and adequately
illuminated.
5.5. Accessible Parking Facilities
Where parking facilities are available, designated parking spaces may be reserved for eligible
PwD allottees. Such parking spaces shall, as far as practicable, be located close to building
entrances and designed to facilitate safe boarding, alighting and movement of persons with
disabilities. Appropriate signage indicating reserved parking shall be prominently displayed.
5.6. Pedestrian Pathways and External Circulation
Pathways, walkways and other pedestrian access routes within residential complexes shall, as
far as practicable, be maintained in a manner that facilitates safe movement by persons with
disabilities. Such pathways shall be reasonably level, free from unnecessary obstructions,
adequately illuminated and provided with suitable tactile or visual indicators wherever
feasible. Consideration shall also be given to minimizing conflicts between pedestrian and
vehicular movement

Page 2 of 3

<!-- page 3 -->

5.7. Emergency Safety and Evacuation Measures .
Appropriate measures shall be taken, wherever feasible, to ensure the safety of
disabilities during emergencies. Such measures may include audible au Persons with
systems, illuminated emergency signage, accessible evacuation oer cai alarm
arrangements necessary for safe evacuation and emergency response. and other
6. Maintenance and Grievance Redressal
6.1. The Estate Officer shall ensure periodic inspection and maintenance of accessibility
features in designated quarters.
6.2. A grievance redressal mechanism shall be made available for addressing complaints
relating to allotment, accessibility barriers, infrastructure deficiencies and maintenance
issues.
6.3. Complaints received from PwD allottees shall be accorded priority for redressal.
Sd/-
(Shri. C. V. D. Diengdoh, IAS)
Commissioner & Secretary to the Government of Meghalaya
General Administration Department
Memo No.GAB.34/2026/1 -A Dated Shillong, the 28"" July, 2026.
Copy to:
1. The P.S. to the Hon’ble Chief Minister, for kind information of the Hon’ble Chief
Minister.
2. The P.S. to the Hon’ble Minister i/c General Administration Department, for kind
information of the Minister.
3. The PS. to the Chief Secretary to the Government of Meghalaya for kind information.
4. The P.A. to the Commissioner & Secretary to the Government of Meghalaya, General
Administration Department, for kind information.
5. The P.A. to the Commissioner & Secretary to the Govt. of Meghalaya, Social Welfare
Department.
6. The P.A. to the Commissioner & Secretary to the Govt. of Meghalaya, Public Works
Department.
7, The P.A. to the Secretary to the Govt. of Meghalaya, General Administration
Department.
8. The Estate Officer, General Administration Department.
are. Meghalaya for uploading in the official website.
10. All Administrative Departments.
11. Office copy.
12. Guard file.
By Order etc.,
Deputy Secretary Bader of Meghalaya
General Administration (B) Department
Page 3 of 3
