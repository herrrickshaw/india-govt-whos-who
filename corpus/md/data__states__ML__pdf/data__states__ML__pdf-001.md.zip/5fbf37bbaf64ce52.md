---
doc_id: "5fbf37bbaf64ce52"
source_url: "https://megsird.gov.in/tenders/EOI_DDUGKY_MEGHALAYA.pdf"
ministry: "State Institute of Rural Development (SIRD), Meghalaya"
title: "Floating of the EOI from DDU-GKY"
date: ""
pages: 16
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "d661f2c8a6c327ca"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
DEEN DAYAL UPADHYAYA GRAMEEN KAUSHALYA YOJANA _®/ypu-cxy
Under Community & Rural Development Department Ye
SIRD Campus, Nongsder, Ri Bhoi District, Meghalaya - 793103
Email : ddugkymegha@gmail.com
i
No.DDU-GK Y/EOI/2017-18/47/Pt-I/ 21 Dated: 20" May,2025
EXPRESSION OF INTEREST (EOI)
UNDER DDU-GKY FOR THE FY 2025-26 IN THE STATE OF MEGHALAYA
Deen Dayal Upadhyaya Grameen Kaushalya Yojana(DDU-GKY), Meghalaya invites
Expression of Interest (EOI) from cligible/registered entity to become Project
Implementing Agencies (PIAs) under DDU-GKY 2.0 to train and place the rural poor
unemployed youth of Meghalaya. DDU-GKY is one of the cluster of initiatives aimed at
livelihood diversification and poverty reduction under Deen Dayal Antyodaya Yojana -
National Rural Livelihoods Mission of the Ministry of Rural Development, Government of
India. This flagship skill development programme rural youth from poor families, providing
high quality training and sustainable employment opportunities to foster inclusive growth and
poverty alleviation. DDU-GKY seeks to promote sustainable livelihoods for rural youth
through placement linked skilling programs.
Date of Publication | 20/05/2025
Last date of receiving queries 30/05/2025 ( upto 5:00 PM)
Proposal submission last date 05/06/2025 ( upto 5:00 PM)
Email for Queries ddugkymegha@gmail.com
For the Financial Year (FY) 2025-26, the state of Meghalaya, a total of 3152 rural poor
unemployed youth are to be trained and placed under the programme.
1. Eligibility Criteria
PIAs interested in participating must meet the following criteria:
« Registration: Must be registered with MoRD and possess a valid Permanent
Registration Number (PRN).
+ Legal Status: Registered under Indian Trust Acts or any State Society Registration
Act or any State Cooperative Societies or the Companies Act 2013 or Limited .
Liability Partnerships Act 2008, or SHGs and its federations namely Cluster Level Korein ‘
1 A tdi . >
Nye  /S
O\MEGHALAYA ZS
BS ny,
CesT»

<!-- page 2 -->

Federation/Block Level Federations or be a Government/semi-government
organization at the State and National Levels.
e Experience: Demonstrated experience in skill development projects, preferably under
DDU-GKY or similar schemes.
¢ Financial Stability: Positive net worth for at least two of the last three financial years
(not applicable for NSDC partners).
¢ Operational History: Operational as a legal entity in India for over three financial
years (not applicable for NSDC partners).
¢ Turnover: Annual turnover exceeding 25% of the proposed project cost.
¢ Sector Expertise: Capability to deliver training in high-demand sectors such as IT,
healthcare, manufacturing, hospitality, agriculture, or others as specified by the
SRLM.
« Placement Record: Proven track record of successful candidate placements.
e Non-Blacklisted: Not blacklisted by MoRD, SRLMs, or any government
undertaking.
1.1 Category of PIAs under DDU-GKY shall be as follows
PIA
1. | Priority A Captive Employer Average Annual Turnover (Last 3 years) = 25 Cr
or more per year for last three financial year
2. | Priority B Existing Skilling | Average Annual Turnover (Last 3 years) = 2 Cr
agencies having | or More per year for last three financial year
experience of greater
than 50% placement
_ outcome achievement
3. | Priority C Skilling Agencies that | Average Annual Turnover (Last 3 years) = 2 Cr
do not have any DDU- | or More per year for last three financial year
GKY experience
Priority D Start-ups for killing | The organization should be in existence for
recognized by | minimum of 3 years and having positive
Department for | combined net worth in last 3 years.
Promotion of Industry
and Internal Trade,
Ministry of Commerce
& Industry, Gol
e Be more than three years old at the time of application except Start-ups.
1.2 The following PIAs shall not be eligible for applying in DDU-GKY 2.0:
1. Existing PI[As who got DDU-GKY Projects sanctioned and hay. recovery proceedings
GRAMEES.
going on. ame
ay ye XZ)
2 S| 83> 2 f
a) Sal /5; hj
Was MEGHSLAYA hf
Ws 22h
as 4

<!-- page 3 -->

2. Existing PIAs who were unable to place 50% of trained candidates under DDU-GKY.

3. Skilling agencies having officials at key managerial personnel as per accounting
standard 18, who were earlier associated with defaulting PIAs against whom recovery
proceedings were initiated due to default.

4. Sister concern/subsidiary of any organisation against whom default action for recovery
of funds initiated.

5. Skilling Agencies having Directors involved in agencies that defaulted earlier with
DDU-GKY. A provision shall be built into the system for validating the DIN of
directors of the applicant organisation through MCA database.

6. Skilling Agencies blacklisted by Government.

7. No consortium shall be allowed.

2. Scope of Work:
2.1 Selected Programme Implementing Agencies will undertake the following
responsibilities:

¢ Mobilization: Identify and enroll rural youth from poor families, prioritizing those
from MGNREGA households, BPL families, or self-help groups.

e Training: Deliver skill training aligned with National Skill Qualification Framework
(NSQF) standards, using approved curricula and certified trainers. Training of
sanctioned target should be completed on or before 31December,2025 and
appointment for placement on or before 31% March,2026.

+ Placement: Ensure at least 70% of trained candidates are placed in wage
employment, with a minimum placement period of 6 months. (The placement of six-
month including placement proof submission, to be achieved within 9-12 months of
completion of training.)

« Post-Placement Support: Track and support placed candidates for at least 12 months
to ensure retention and career progression.

« Compliance: Adhere to DDU-GKY 2.0 guidelines, SOPs, and reporting
requirements.

« Infrastructure: Maintain adequate training facilities, including labs and equipment,
as per program standards.

The Project duration is for a maximum of | year with proposals spanning from 3 months to 9
months duration. Training may cover sectors (trades/courses) such as at ANNEXURE - I
PEM
eB
3 s E
a\ nm = /E
aaah f ES
Cnars >

<!-- page 4 -->

3. Submission of Proposals
3.1 The interested Agencies having valid PRN allotted by Ministry of Rural Development
(MoRD) Government of India may apply online at www.kaushal.rural.gov.in The Agencies are
advised to go through the detailed Guidelines and SOP of DDU GKY 2.0 (available on
www.ddugky.gov.in) before applying online and must submit proposals in the prescribed
format, available on the DDU-GKY website. Proposals should include:
¢ Organizational Details: Registration documents, PRN, and legal status.
¢ Experience: Details of past skill development projects, including placement
outcomes.
¢ Training Plan: Proposed sectors, job roles, curriculum, and training methodology.
¢ Infrastructure: Description of training centers, equipment, and facilities.
e Placement Strategy: Employer tie-ups, placement commitments, and post-placement
tracking plans.
e Financial Proposal: Cost estimates aligned with DDU-GKY cost norms.
« References: Testimonials or references from previous projects.
3.2 The Project Applicant Agencies will have to pay non-refundable Initial Screening fee of
Rs. 25,000.00/- (Rupees Twenty five thousand only plus applicable GST @18% per proposal).
Further, the Project Applicant Agencies will have to pay non-refundable Qualitative Appraisal
fees of Rs.1,25.000/- (Rupees One lakh twenty five thousand only plus applicable GST 18%
per proposal) if the Initial Screening is successful and recommended for Qualitative Appraisal,
payable in favour of National Institute of Rural Development and Panchayati Raj
(NIRD&PR), (Project Appraisal Agency(PAA) under DDUGKY 2.0 for the state of
Meghalaya). The Payment Mode through RTGS to the below given bank account:
BDU-GKY Savings Bank Accouni
PAN AAAAN4871B
GSTN | 36AAAAN4871B1ZT
Account No. 62431332037
IFSC Code SBIN0020965
State Bank of nd
Branch NIRD Campus, Rajendranagar,
Hyderabad — 500030, TELANGANA
PEND
a Se
> 4 A
4 Z| am Jey
ONNEGHALAYA é&
QW

<!-- page 5 -->

Proposals should be submitted online via the MoRD DDU-GKY ERP portal on or before 5:00
PM, 5'" June, 2025. Applications received after the scheduled date and time shall not be
considered. The hard copies of the proposals along with the complete set of supporting
documents should be submitted to DDU-GKY Meghalaya, State Institute of Rural
Development (SIRD) Campus, Nongsder, Ri Bhoi Meghalaya-973103.
4. General Information:
(General instructions for filling an application form)
4.1 Document to upload:
(a) Information contained in the scanned documents should be legible; it should not be blurred
or washed out.
(b) The scan should be preferably of the original document and not photocopied document.
(c) If user find that the documents scanned by user are more than 5 MB, resize them using
appropriate software.
4.2 If user have any issue/ query/ suggestion user can raise a ticket on Portal.
4.3 Project application filing process
A project application for DDU-GKY project, has to be filed only on designated Portal. Project
Applicant Agencies can only apply as a Single entity. No consortium is allowed under DDU-
GKY 2.0. All the documents (including initial screening and qualitative appraisal would have
to submitted at time of application itself.) Documents once uploaded and submitted shall not
be allowed to change under any circumstances.
4.4. The stages in the Project Implementing Agency registration, project applications and its
appraisal are as follows:
4.5 Initial Screening:
a. Mandatory Documents for Initial Screening:
Name of the mandatory documents. Document accepted ]
iterate
candidate by DGT/ SSC (If, applicable) | SSC/NSQF aligned agency to candidate
trained by applicant PIA.
Department for latest three Assessment
Years (AY)
3. |CA Certificate of Statutory Auditor/ | Standard Form 1B.8: CA Certificate of
Annual Auditor, supported by Balance | Statutory Auditor/Annual Auditor on
ec a iti
3 = (
% S
Ow KS

<!-- page 6 -->

sheet and Profit and Loss account
_ Statement
4. Copies of Sanction order for previous | Sanction order/ letter of work order issued to
skills and training projects PIA in last five years
5. | Client Certificate for previous skills | Standard Form 1B.10: Format for Client
and training. Project closure certificate | certificate/Project Closure Report
for closed/ fore closed projects. (whichever is applicable)
Employer Certificate for Overseas | Standard Form 1B.11: Format for Employer
Placement Certificate for Overseas Placement
7. | Certificate for captive Placement Standard Form 1B.12: Format for Certificate
for Captive Placement
Scanned copy or the Screen-shot of the | Legible and clear copy with transaction id
NEFT/RTGS transaction made for | and amount details
application fee R.25000 plus applicable
GST
Letter of Intent from Potential | Standard Form 1B.6: The letter of intent
Employer (s) (LOI
10. | Self-Certification for Training | No specific format(Self declaration on letter
Institution head of organisation only)
Applicant Training Manual for | No specific format
Training Activities
(b) Checking Blacklisting of the PIA.
(c) Successful applications shall be recommended for Qualitative Appraisal. In all other cases,
the application shall be rejected, PIA shall be informed and information placed before PAC.
List of documents for qualitative appraisal based on Standard Form 1A, 1B, 1C & 1D.
(a) For Priority - A Applicant: (Captive Employer)
1. Company Incorporation/Registration Certificate (CIN)
2. NITI Aayog registration details in case organisation is in NGO category i.e. Trusts/
Society / Cooperatives Societies.
3. Proof of Industry having Valid EPFO/ESIC/Factory Registration Number.
4. Proof Industry having Valid TIN/TAN/GST Number.
5. Proof of Industry having Valid Bank Account Number linked to Aadhar /PAN.
6. CA certificate indicating Annual turnover of = 25 Cr or More per year for last three
financial year.
7. Proof of Past Training Experience for more than 2 years.
8.Declaration to provide commitment for assessment and certification femmthe govt.
Ay RA MES
recognized awarding body. &S ©,
<
. I
6 woke re
\4)\ MEGHALAYA 4) )
C2
LIF me >)

<!-- page 7 -->

9. Letter of intent to Provide employment to 500 or more jobs in own or subsidiary

agencies/ companies, during the last three years from the date of application for a

project.

10. Declaration to provide placement in Own Organization or Affiliate Companies to

70% of the trained candidates for the minimum period of 6 months.

11. Declaration to provide placement for = 10,000 or minimum wages whichever is

higher to 70% of the trained candidates for the training courses less than six months.

12. Declaration to provide placement for % 12,000 or minimum wages whichever is

higher to 70% of the trained candidates for the training courses more than six months.

(b) For Priority B Applicant: (Existing Skilling Agencies having more than 50%

placement)

1. Company Incorporation/Registration Certificate (CIN).

2. NITI Aayog registration details in case organisation is in NGO category i.e. Trusts/

Society / Cooperatives Societies.

3. Work order/Completion certificate/client certificate for Experience in Skill

Development Projects.

4. Work order/Completion certificate/client certificate for Multi State Experience.

5. Proof of Trained Candidates during last 3 Years.

6. Proof of placement record certified by authorised signatory of Applicant PIA.

7. Proof of Infrastructure related Capacity which include Lease agreements, ownership

documents, photos, and details of the training centres.

8. Agreements with Potential Employers — LOIs.

9. Proof of Proposed salaries for all trainers, considering appropriate to attract good

talent in the market.

10. Proof of Average Annual Turnover and Working Capital during Last 3 Years.

11. Solvency Certificate (A solvency certificate is a legal document that confirms an

individual or entity's financial stability and ability to meet their financial obligations).

12. Proof of No Outstanding Liabilities/recovery with any Government Agencies.

13. Affidavit or declaration signed by the authorized signatory and supported by a

statement from a competent authority for Previous Penalties/Blacklisting.

14. Certified CIBIL score report of promoters/WTD obtained from authorized agencies

of CIBIL that is Transunion.

15. CIBIL Reports (TransUnion) for Company Credit Report (CCR) of the applic; PX CRAMERS

PIA. ky Ee

7 5 z
a\ are " x,
regs)
230%

<!-- page 8 -->

16. ITR and Audit Reports (Last 3 Years) Audited financial statements for each of the

applicants for the last three fiscal years, along with, auditor’s opinion and all footnotes.

17. CA certified free fund flow statement for last three years.

18. PIA's projected free fund flow statement for next three years, reflecting quarterly or

monthly balance of working capital.

19, DOCWC 3: Projected DDU-GKY project cash flow based on a tentative prospective

project work schedule and release of instalments (PPWS).

20. DOC WC 2 & Doc WC 3 to be accompanied by a chartered accountant's statement

issued in line with SAE 3400 (AAS 35), Compute the number of months of project

expenses that can be covered using the net working capital.

21. ITR and Audit Reports (Last 3 Years) Audited financial statements for each of the

applicants for the last three fiscal years, along with, auditor’s opinion and all footnotes.

(c) For Priority C Applicant: (Evaluation Framework for Skilling Agencies that do

not have any DDUGKY experience)

1. Company Incorporation/Registration Certificate (CIN).

2. NITI Aayog registration details in case organisation is in NGO category i.e. Trusts/

Society / Cooperatives Societies.

3. Work order/Completion certificate/client certificate for Experience in Skill

Development Projects.

4. Profiles of promoters/investors; CA/CS certified with UDIN no.

5. Internal Training mechanism employees of the applicant PIA duly signed by the

authorised signatory.

6. Proof of Trained Candidates since incorporation of organization.

7. Prior centre operation experience since incorporation of the organisation supported

by Lease agreements, ownership documents, photos, and details of the training centres.

8. Agreements with Potential Employers — LOIs stamped and duly signed by employer.

9. Proof of Proposed salaries for all trainers, considering appropriate to attract good

talent in the market.

10. Proof of Average Annual Turnover and Working Capital during Last 3 Years.

11. Project handling Experience (Turnover from Skill Development Projects) in

supported by Work orders, Sanction orders letters, or completion certificates for skill

development projects handled.

12. Solvency Certificate (A solvency certificate is a legal document that confirms an, AA ON

individual or entity's financial stability and ability to meet their financial obligation; ey y a
eee

o 2d [s
KS
» vay

<!-- page 9 -->

13. Proof of No Outstanding Liabilities/recovery with any Government Agencies.

14. Affidavit or declaration signed by the authorized signatory and supported by a

statement from a competent authority for Previous Penalties/Blacklisting.

15. Certified CIBIL score report of promoters/WTD obtained from authorized agencies

of CIBIL that is Transunion.

16. CIBIL Reports (TransUnion) for Company Credit Report (CCR) of the applicant

PIA.

17. ITR and Audit Reports (Last 3 Years) Audited financial statements for each of the

applicants for the last three fiscal years, along with, auditor’s opinion and all footnotes.

18. CA certified free fund flow statement for last three years.

19. PIA's projected free fund flow statement for next three years, reflecting quarterly or

monthly balance of working capital.

20. DOCWC 3: Projected DDU-GKY project cash flow based on a tentative prospective

project work schedule and release of instalments (PPWS).

21. DOC WC 2 & Doc WC 3 to be accompanied by a chartered accountant's statement

issued in line with SAE 3400 (AAS 35), Compute the number of months of project

expenses that can be covered using the net working capital.

22. ITR and Audit Reports (Last 3 Years) Audited financial statements for each of the

applicants for the last three fiscal years, along with, auditor’s opinion and all footnotes.

(d) For Priority D Applicant: (Evaluation Framework for Start ups for skilling

recognized by Dept of Industrial Policy & Promotion, Ministry of Commerce &

Industry, Gol)

1. Company Incorporation/Registration Certificate (CIN).

2. NITI Aayog registration details in case organisation is in NGO category i.e. Trusts/

Society / Cooperatives Societies.

3. Profiles of promoters/investors; CA/CS certified with UDIN no.

4. Internal Training mechanism employees of the applicant PIA duly signed by the

authorised signatory.

5. Agreements with Potential Employers — LOIs stamped and duly signed by employer.

6. Proposed ToT process along with Trainer certification.

7. Proposed Placement Salaries of candidates supported by Salary agreements with

employers 8. Placement Support Mechanism supported by Placement strategy

document & Proposed team roles. Ke ¢ SION
xf 4

<!-- page 10 -->

9. Internal Audit Mechanism supported by Audit Report of the concerned
agency/organization to be uploaded.
10. Certified CIBIL score report of promoters/WTD obtained from authorized agencies
of CIBIL that is Transunion.
11. CA certified Free fund flow statement for last three years.
12. PIA's projected free fund flow statement for next three years, reflecting quarterly or
monthly balance of working capital.
13. DOCWC 3: Projected DDU-GKY project cash flow based on a tentative prospective
project work schedule and release of instalments (PPWS).
14. DOC WC 2 & Doc WC 3 to be accompanied by a chartered accountant's statement
issued in line with SAE 3400 (AAS 35), Compute the number of months of project
expenses that can be covered using the net working capital.
15. ITR and Audit Reports (Last 3 Years) Audited financial statements for each of the
applicants for the last three fiscal years, along with, auditor’s opinion and all footnotes.
5. The State Project Approval Committee (SPAC) shall have the final authority for sanctioning
of the Project proposals.
For any further information, please write to ddugkymegha@gmail.com
State bn Director,
DDU-GKY, Meghalaya
o/
5
Sa
10
