---
doc_id: "fe1df4aa3ebc4a19"
source_url: "https://megdca.gov.in/docs/notification-22-07-26.pdf"
ministry: "District Council Affairs Department, Meghalaya"
title: "Notification: Appointment of PIO, APIO, AA under RTI Act"
date: ""
pages: 2
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "6f18f2ea17d37142"
---

<!-- page 1 -->

é 1210
GOVERNMENT OF MEGHALAYA
DISTRICT COUNCIL AFFAIRS DEPARTMENT
ORDERS BY THE GOVERNOR
NOTIFICATION
Dated Shillong, the 22" July, 2026
No. DCA.27/2005/913: In supersession of this Department’s letter No.DCA 27/2005/593
dated 14.02.2022 and in exercise of the power delegated under sub-section (1) & (2) of Section
5 & sub-section (1) of Section 19 of the Right to Information Act, 2005 (Central Act No.22 of
2005); the Governor of Meghalaya is pleased to appoint the following as Public Information
Officer, Assistant Public Information Officer & Appellate Authority under the District Council
Affairs Department.
Name of Public Authority | Designation of the Officer | Designation of the Officer
under the RTI Act
DISTRICT COUNCIL 1. Appellate Authority | Senior most Secretary to the
AFFAIRS DEPARTMENT Govt. of Meghalaya, District
| Council Affairs Department
2. Public Information| Deputy Secretary/ Under
Officer Secretary to the Govt. of
Meghalaya, District Council
Affairs Department.
3. Assistant Public | Superintendent, District
Information Officer | Council Affairs Department.
ns Sd/-
a MLR. Synrem, IAS,
_ “a Principal Secretary to the Govt. of Meghalaya
il a District Council Affairs Department
Memo No. DCA.27 oe Dated Shillong, the 22" July, 2026
Copy forwarded a
1 P.S. to ini iste r of Meghalaya, for kind information of Chief
ES, r /e District Council Affairs Department for kind
35 P.S. to . of Meghalaya, for kind information of the Chief
oS 4. PS t he Govt. of Meghalaya, District Council Affairs
ees pant ghalaya, District Council Affairs Department for
oS eghalaya, Personnel & A.R. (A) Department
ee 5 Contd/2

<!-- page 2 -->

a The Senior Technical Director & State Informatics Officer, National Informatics Centre

(NIC), Shillong for uploading in the website of District Council Affairs Department.

9. The Director of Printing & Stationery, for publication in the Meghalaya Gazette.

10. All Administrative Departments
By orders ete.,

Under Secretary to the/Govt. of Meghalaya,

District Council Affairs Department

ae
aes Bc
eae
a
