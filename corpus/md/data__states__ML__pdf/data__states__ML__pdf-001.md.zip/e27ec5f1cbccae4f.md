---
doc_id: "e27ec5f1cbccae4f"
source_url: "https://megcooperation.gov.in/notifications/Cancellation_NonFunctioning_CS_01May2023.pdf"
ministry: "Co-operation Department, Meghalaya"
title: "List of Cooperative Societies that was Cancelled as per the Meghalaya Cooperative Societies Act, 2015 under Sec 66 as on 1st May 2023"
date: ""
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8e5c1c8d6fe4bb8e"
---

<!-- page 1 -->

COOPERATIVE SOCIETIES THAT WAS CANCELLED
AS PER THE MEGHALAYA COOPERATIVE SOCIETIES ACT, 2015
UNDER SEC 66

Cancellation of Registration of Non Functioning Cooperative Societies
The Commissioner and Secretary, Cooperation Department in the review meeting with the
District Heads held on the 7th. July, 2021 instructed to adopt a fast track cancellation approached on Non
Functioning Cooperative Societies.
As previously done the Liquidator cum Bakijai Officer on receiving the Inspection and Inquiry
Report of the Meghalaya Cooperative Societies Act, 2015 on the Non Functioning Cooperative Societies
done by the Auditing Officers. He/She will thereby personally serve the 1st notice with Acknowledgement
Card under Sec 61(3) /62(3) to the Non Functioning Cooperative Societies.
In order to implement the fast track cancellation approach, the Branch has instructed all District
and Sub- Division that the Auditors whose transaction of Non Functioning remained dormant for more
than 3(three) years, before conducting the audit of such societies, should be prepared to go for Inquiry and
Inspection as mentioned above and in respect of societies whose members have expressed their

un-

willingness to re-activate the working of their Cooperative Societies and no interest in reviving the same
should simultaneously served the 1st Notice with Acknowledgement Card and submit the same to their
respective District/Sub- Divisional Officers.
After a period of 30 days the Registrar of Cooperative Societies shall served the Notification for
cancellation of the concerned Non Functioning Cooperative Societies as per provision of Sec. 66 of the
Meghalaya Cooperative Societies Act, 2015.
The Liquidator cum Bakijai Officer will take over the Liquidation proceeding thereafter as per
Sec. 67 of the Act.

***

<!-- page 2 -->

The Cooperative Societies that was registered under the Meghalaya
Cooperative Societies Act, 2015 and has been cancelled till the 1 st May 2023 are as follows :Sl.

Name of the Districts / Sub – Divisions

Total Number of

No.

Remarks

Cooperative Societies
cancelled

1

2

3

4

1.

O/o Assistant Registrar Of Cooperative Societies,

45

List enclosed in PDF

25

List enclosed in PDF

16

List enclosed in PDF

33

List enclosed in PDF

31

List enclosed in PDF

08

List enclosed in PDF

03

List enclosed in PDF

08

List enclosed in PDF

06

List enclosed in PDF

09

List enclosed in PDF

184

x

East Khasi Hills District, Shillong
2.

O/o Assistant Registrar Of Cooperative Societies,
West Jaintia Hills District, Jowai

3.

O/o Assistant Registrar Of Cooperative Societies,
West Khasi Hills District, Nongstoin

4.

O/o Assistant Registrar Of Cooperative Societies,
Ri - Bhoi District, Nongpoh

5.

O/o Assistant Registrar Of Cooperative Societies,
West Garo Hills District, Tura

6.

O/o Assistant Registrar Of Cooperative Societies,
East Garo Hills District, Williamnagar

7.

O/o Assistant Registrar Of Cooperative Societies,
South Garo Hills District, Baghmara

8.

O/o Sub - Registrar Of Cooperative Societies,
South West Khasi Hills District, Mawkyrwat

9.

O/o Sub - Registrar Of Cooperative Societies,
Sohra (C) Sub Division, Sohra

10.

O/o Sub - Registrar Of Cooperative Societies,
Amlarem (C) Sub Division, Amlarem
TOTAL CANCELLATION AS ON
THE 1

ST

MAY 2023

***

<!-- page 3 -->

LIST OF CANCELLATION OF REGISTRATION OF COOPERATIVE SOCIETIES
O/o THE ASSISTANT REGISTRAR OF COOPERATIVE SOCIETIES,
E.K.H. DISTRICT, SHILLONG

1. EAST KHASI HILLS DISTRICT, SHILLONG
Sl.
No.
1

Cooperative Society’s Name

Date of Issue of Notification

Mawkohmoh Multi Purpose Cooperative Society No.MCL21/2021/22-A/5755-61,
Ltd.

2

Dt.19-02-2021

Pasteur Hills Government Employees Cooperative No.MCL23/2021/7-A/5740-5746,
Society Ltd.

3

Mawsynram

Dt.19-02-2021
Circle

Regional

Marketing No MCL.24/2020/9-A/5719-5725,

Cooperative Society Ltd.
4

Mylliem

Farmers

Dt.19-02-2021
Regional

Marketing No.MCL 20/2021/12-A/5733-39,

Cooperative Society Ltd.
5
6

Madan

Umsaw

Multi

Dt.19-02-2021
Purpose

Cooperative No.MCL 22/2021/22-A/5726-32,

Society Ltd.

Dt.19-02-2021

Laitbah Multi Purpose Cooperative Society Ltd.

No. MCL 4/2017/18-A/7087-7093,
Dt.24-03-2021

7

Cantonment Area Consumer Cooperative Society No.MCL 59/2021/15-A/975-981,
Ltd.

8

Dt.16-09-2021

Umsaw Mawtawar Milk Producers Cooperative No.MCL 114/2021/13-A/1649-1655,
Society Ltd.

9

Mawphlang

Dt.11-10-2021
Lyngdohship

Multi

-

Purpose No.MCL 115/2021/15-A 1616-1622,

Cooperative Society Ltd.
10

Dt.8-10-2021

Mawlyngngot Multi Purpose Cooperative Society No.MCL 116/2021/11-A 1637-1643,
Ltd.

11

Dt.8-10-2021

Mawjam Handicraft Weavers Cooperative Society No.MCL 130/2021/12-A 1538-1544,
Ltd.

12

Dt.7-10-2021

Mawslang Multi Purpose Cooperative Society No.MCL 126/2021/12-A/1609-1615,
Ltd.

13

Dt.8-10-2021

Mawkynrew Umtong Multi Purpose Cooperative No.MCL 119/2021/12-A/1646-1642,
Society Ltd.

14

Dt.11-10-2021

Banraplang Multi Purpose Cooperative Society No.MCL 117/2021/12-A/1623-1629,
Ltd.

15

Dt.11-10-2021

Umshing Campus University Teachers Consumer No.MCL 118/2021/14-A/1630-1636,
Cooperative Society Ltd.

16
17

Dt.8-10-2021

Khlieh Lyngkhoi Piggery Farming Cooperative No.MCL 129/2021/15-A/1510-1516,
Society Ltd.

Dt.7-10-2021

Umsaw Multi Purpose Cooperative Society Ltd.

No.MCL 128/2021/13-A/1564-1570,
Dt.8-10-2021

18
19

Horticultural

Producers

and

Marketing No.MCL 127/2021/13-A/1557-1563,

Cooperative Society Ltd.

Dt.8-10-2021

Jzee Consumer Cooperative Society Ltd.

No.MCL 134/2021/10-A/3104-3110,
Dt.9-11-2021

20

Khasi Pnar Primary Housing Cooperative Society No.MCL 146/2021/18-A/3492-99,
Ltd.

Dt.22-11-2021

Page 1 of 3

<!-- page 4 -->

21

Pongtung

Sohpieng

Industrial

Cooperative No.MCL 148/2021/16-A/3441-47,

Society Ltd.
22
23

Dt.22-11-2021

Nohwet Lumpeng Shyrngam Multi Purpose No.MCL 4/2018/25-A/5483-5499,
Cooperative Society Ltd.

Dt.22-11-2021

Dewsaw Multi Purpose Cooperative Society Ltd.

No.MCL 151/2021/12-A/3709-3715,
Dt.2-12-2021

24
25

Lamjingshai

Progressive

Multi

Purpose No.MCL 152/2021/14-A/3716-3755,

Cooperative Society Ltd.

Dt.2-12-2021

Pynthorbah Consumer Cooperative Society Ltd.

No.MCL 28/2011/15-A/3723-29,
Dt.2-12-2021

26
27

Iaiminot Industrial Allied Activities Cooperative No.MCL 150/2021/15/3434-40,
Society Ltd.

Dt._______

Tyllaw Multi Purpose Cooperative Society Ltd.

No.MCL 33/2021/31-A/4729-35,
Dt.1-2-2022

28

Wahmawpat Transport Cooperative Society Ltd.

No.MCL 13/2022/14-A,
Dt.25-2-2022

29

Mawsynram Bazar Bus Transport Cooperative No.MCL 13/2022/14-A/5648-5654,
Society Ltd.

30

Dt.25-2-2022

Happy Valley Ex-Service Men/Widow/Consumer No.MCL 15/2022/13-A/5698-04,
CS. Ltd.

31
32

Dt.25-2-2022

Mawtepiew Multi Purpose Cooperative Society No.MCL 16/2022/13-A/6554-60,
Ltd.

Dt.25-3-2022

Assam Rifles Coop: MBF Ltd.

No.MCL 17/2022/19-A/6561-67,
Dt.25-3-2022

33

Riwar Tribal Multi Purpose Cooperative Society No.MCL 18/2022/13-A/6575-81,
Ltd.

34
35

Dt.25-3-2022

Mawkhan Women Multi Purpose Cooperative No.MCL 65/2015/26,
Society Ltd.

Dt.18-03-2020

Nongkseh Consumer Cooperative Society Ltd.

No.MCL 8/2017/16-A/4287-33
Dt.

36

Nongtrai Multi Purpose Cooperative Society Ltd.

No.MCL 22/2017/16-A/969-75
Dt.

37

Green Field Cooperative Society Ltd.

No.MCL 3/2018/16-A/2744-2750
Dt.

38

State Bank of India Cooperative Society Ltd.

No.MCL 25/2016/115-A/6818-26,
Dt.15-02-2018

39

Hotel Pinewood Employee Consumer Cooperative No.MCL 21/2017/17-A/2790-2796,
Society Ltd.

40

Wahingdoh

Dt.10-09-2018
Women

Industrial

Society Ltd.
41
42

Cooperative No.MCL 20/2022/19-A/196-202,
Dt.13-4-2022

Synroplang Piggery Poultry Agro Activities CS No.MCL 2/2022/14-A/203-209,
Ltd.

Dt.13-4-2022

Seven Star Multi Purpose CS Ltd.

No. MCL 27/2022/7-A/802/808,
Dt.2.6.2022

Page 2 of 3

<!-- page 5 -->

43

Meghalaya Economics Development MPCS Ltd.

No. MCL 31/2022/13-A/2277-2283,
Dt.21.9.2022

44

Iai Jyrngam Vegetable CS Ltd.

No.MCL 35/2022/21-A/3038-3044,
Dt.19-10-2022

45

Ibakyntiew Industrial CS Ltd

No.MCL 2/2023/18-A/4905-4911,
Dt. 09-03-2023

Page 3 of 3

<!-- page 6 -->

LIST OF CANCELLATION OF REGISTRATION OF COOPERATIVE SOCIETIES

O/o THE ASSISTANT REGISTRAR OF COOPERATIVE SOCIETIES,
WEST JAINTIA HILLS DISTRICT, JOWAI
5. WEST JAINTIA HILLS DISTRICT, JOWAI

Sl.

Cooperative Society’s Name

No.
1

Robin Primary Milk Producer CS Ltd.

Date of Issue of Notification
No.MCL 9/2020/16-A/5149-5155,
Dt.22-01-2021

2

Leimow Labour Contract CS Ltd.

No.MCL 7/2018/16-A/5756-62,
Dt.22-1-2021

3

Mihmyntdu Primary Milk Producer CS Ltd.

No.MCL 7/2020/17-A/5142-5143,
Dt.22-1-2021

4
5
6

Kdongsari Fishery cum Piggery & Poultry CS Ltd

No.MCL 8/2019/16/1532-1538,

.

Dt.11-8-2020

Sunapyrdi Border Area Development Piggery &

No.MCL 14/2016/31-A/1488-1491,

Poultry CS Ltd.

Dt.6-8-2020

Iengkarnat Chilliang Multi Purpose CS Ltd.

No.MCL 132/2021/17-A/5218-5224,
Dt.9-2-2022

7

Topcem Employees CS Ltd.

No.MCL 85/2021/20-A/5169-5175,
Dt.9-2-2022

8

Samsapleri Multi Purpose CS Ltd.

No.MCL 133/2021/17-A/5162-5168,
Dt.9-2-2022

9

Demthring Multi Purpose CS Ltd.

No.MCL 131/2021/17-A/5225-5231,
Dt.9-2-2022

10

U Para-Ri Industrial CS Ltd.

No.MCL 14/2022/12-A/5676-5682,
Dt.25-2-2022

11

Barato Transport CS Ltd.

No.MCL 7/2022/15-A/5978-5984,
Dt.7-2-2022

12

Iawthymmei CS Ltd.

No.MCL 10/2022/18-A/2655-5661,
Dt.25-2-2022

13

Chilok-I-Spices CS Ltd.

No.MCL 9/2022/16-A/5662-5668,
Dt. 25-2-2022

14

Myntoilang Handloom Women CS Ltd.

No.MCL 84/2021/30-A/3111-3117,
Dt.8-Nov-2021

15

Salonsar Dairy Milk Producer CS Ltd.

No.MCL 39/2013/9-A/168-174,
Dt.23-4-14

16

Pnar Livestock & Birds CS Ltd.

No.MCL 31/2012/20-A/1558-4264,
Dt.26-10-2014

17

Moolamylliang Multi Purpose CS Ltd.

No.MCL 41/2013/18-A /169-9170,
Dt.8-3-2016

18

Thwai Syiem Multi Purpose CS Ltd.

No.MCL 9/2017/24/2026,
Dt. 14-08-2016

19

Nongbah Joint Farming CS Ltd.

No.MCL 8/2020/28-A/5101-5107,
Dt. 10-03-2023

Page 1 of 2

<!-- page 7 -->

20
21

Maitshaphrang Industrial Livestock Farming Women

No.MCL 7/2023/13-A/5080-5086,

Group CS Ltd.

Dt. 21-03-2023

Pnar Multipurpose CS Ltd.

No.MCL 8/2023/14-A/5115-5121,
Dt. 21-03-2023

22

Khahnar Dairy Farming CS Ltd.

No.MCL 9/2023/13-A/5094-5100,
Dt. 21-03-2023

23

Mookyndur Dairy Farming CS Ltd.

No.MCL 10/2020/29-A/5108-5114, Dt. 21-032023

24

Baite Women Handloom CS Ltd.

No.MCL 10/2023/12-A/5087-5093,
Dt. 21-03-2023

25

Tlangpui Taituk Dairy CS Ltd.

No.MCL 11/2023/13-A/5722-5128
Dt. 21-03-2023

Page 2 of 2

<!-- page 8 -->

LIST OF CANCELLATION OF REGISTRATION OF COOPERATIVE SOCIETIES

O/o THE ASSISTANT REGISTRAR OF COOPERATIVE SOCIETIES,
WEST KHASI HILLS DISTRICT, NONGSTOIN
6. WEST KHASI HILLS DISTRICT, NONGSTOIN

Sl.
No.
1

Cooperative Society’s Name
Alga Eden Eco Tourism Development CS Ltd.

Date of Issue of Notification
No.MCL 36/2021/12-A/6836-6842,
Dt.18-3-2021

2

Mawiaban Joint Farming CS Ltd.

No.MCL 37/2021/11-A/6667-6673,
Dt.15-3-2021

3

Mawkadiang Industrial CS Ltd.

No.MCL 38/2021/13-A/6924-30,
Dt.20-3-2021

4

Baneh Mulbery Silk Growers CS Ltd.

No.MCL 35/2021/9-A/6826-6832,
Dt.18-3-2021

5

Monlang Multi Purpose CS Ltd.

MCL 30/2021/13-A/5899-5905,
Dt.25-2-2021

6

New Nongstoin Saw Mill Industrial CS Ltd.

No.MCL 33/2021/7-A/5985-91,
Dt.25-2-2021

7

Sonapahar Rural Housing CS Ltd.

No.MCL 34/2021/13-A/5976-82,
Dt.25-2-2021

8

Mawiang Multi Purpose CS Ltd.

MCL 27/2021/6-A/5771-5777,
Dt.22-2-2021

9

Myriem Byrki Dairy Farming CS Ltd.

No.MCL 26/2021/11-A/5778-5784,
Dt.22-2-2021

10

Nongkroh Multi Purpose CS Ltd.

No.MCL 25/2021/7-A/5785-5791,
Dt.22-2-2021

11

Ramsiej Dairy Farming CS Ltd.

No.MCL 28/2021-11-A/5888-5893,
Dt.24-2-2021

12

Nongstoin Milk Producer CS Ltd.

No.MCL 29/2021/13-A/5883-5888,
Dt.24-2-2021

13

Marngor Dairy Farming CS Ltd.

MCL 31/2021/5-A/6895-6901,
Dt.20-3-2021

14

Marngor Women Industrial CS Ltd.

No.MCL 32/2021/11-A/6917-23,
Dt.20-3-2021

15

Nongstoin Tailoring Industrial CS Ltd.

No. MCL 32/2022/19-A/2419-2425,
Dt.26.9.2022

16

Mawdoh Cane & Bamboo Industrial CS Ltd.

No. MCL 33/2022/13-A/2426-2432,
Dt. 26.9.2022

8|Page

<!-- page 9 -->

LIST OF CANCELLATION OF REGISTRATION OF COOPERATIVE SOCIETIES

O/o THE ASSISTANT REGISTRAR OF COOPERATIVE SOCIETIES,
RI-BHOI DISTRICT, NONGPOH
4. RI-BHOI DISTRICT, NONGPOH

Sl.
No.

Cooperative Society’s Name

Date of Issue of Notification

1

Panki Multi Purpose CS Ltd.

No.MCL 72/2021/7-A/6805-6811, Dt.18-03-2021

2

Umphieng Multi Purpose CS Ltd.

No.MCL 70/2021/7-A/6945-5, Dt.20-03-2021

3

Nongwah Mawlein Multi Purpose CS Ltd.

No.MCL 71/2021/11-A/6783-6789, Dt.18-03-2021

4

Ri-Bhoi Sepngi Multi Purpose CS Ltd.

No.MCL 73/2021/13-A/6952-58, Dt.20-03-2021

5

Iaiminot Women Multi Purpose CS Ltd.

No.MCL 77/2021/7-A/7059-7065, Dt.23-03-2021

6

Myntoilang Women Multi Purpose CS Ltd.

No.MCL 76/2021/11-A/7052-7058, Dt.25-03-2021

7

Pynroi Multi Purpose CS Ltd.

No.MCL 80/2021/11-A/7025-31, Dt.23-03-2021

8

Khnan Multi Purpose CS Ltd.

No.MCL 79/2021/18-A/7010-16, Dt.23-03-2021

9

Mawlyndep

No.MCL 78/2021/9-A/7018-24, Dt.23-3-2021

10

Jiwon Area Rural Housing CS Ltd.

No.MCL 92/2021/11-A/411-417, Dt.19-07-2021

11

Three Star Handloom & Handicraft CS Ltd.

No.MCL 91/2021/14-A/425-431, Dt.19-07-2021

12

Halari Tourism CS Ltd.

No.MCL 90/2021/14-A/418-42 , Dt.19-07-2021

13

Umden Eri Cluster Development CS Ltd.

No.MCL 110/2021/14-A/989-99 , Dt.16-09-2021

14

Imlang Workshop & Allied Multi Purpose

No.MCL 112/2021/12-A/1010-1016, Dt.16-09-2021

CS Ltd.
15

Ri – Bhoi Tea Growers CS Ltd.

No.MCL 111/2021/12-A/996-1002, Dt.16-09-2021

16

Down Gate Multi Purpose CS Ltd.

No.MCL 113/2021/13-A/1003-1009, Dt.16-09-2021

17

Mawknor Multi Purpose CS Ltd.

No.MCL 57/2021/12-A/982-988, Dt.1-09-2021

18

Jingkyrmen Multi Purpose CS Ltd.

No.MCL 120/2021/14-A/1524-1530, Dt.7-10-2021

19

Soidaka Agro Product Processing CS Ltd.

No.MCL 121/2021/11-A/1507-1523, Dt.7-10-2021

20

Pynroilang Multi Purpose CS Ltd.

No.MCL 122/2021/13-A/1571-1577, Dt.8-10-2021

Page 1 of 2

<!-- page 10 -->

21

Narlein Multi Purpose CS Ltd.

No.MCL 123/2021/13-A/1671-1677, Dt.11-10-2021

22

Syrdohlang Multi Purpose CS Ltd.

No.MCL 124/2021/14-A/1531-1537, Dt.7-09-2021

23

Jirang Rural Housing CS Ltd.

No.MCL 23/2022/9-A/333-340, Dt.25-04-2022

24

All Jirang Handicraft & Weaving CS Ltd.

No.MCL 22/2022/5-A/341-347, Dt.25-04-2022

25

Pynker Area Multipurpose CS Ltd.

No.MCL 4/2023/8-A/4912-4918, Dt 09-03-2023

26

Hill View Mawsmai Multipurpose CS Ltd

No. MCL 5/2023/10-A/4919-4925, Dt.09-03-2023

27

Nangroi Multipurpose CS Ltd.

No. MCL 30/2022/10-A/2207-2213, Dt.09-03-2023

28

Umtyrkhang Multipurpose CS Ltd.

No. MCL. 39/2022/13-A/2958-2964,Dt 18-10-2022

29

Umtyrkhang Women Sericulture & Allied

No.MCL 37/2022/12/2965-2971, Dt.18-10-2022

30

Shaphrang Multipurpose CS ltd.

No. MCL 40/2022/13-A/3052-3058, Dt.19-10-2022

31

Nongtraw Multipurpose CS Ltd.

No. MCL 36/2022/9/3045-3051, Dt.19-10-2022

32

Iakunai Multipurpose CS Ltd.

No. MCL 38/2022/12-A/2972-2978, Dt. 18-10-2022

33

RiBhoi Industrial CS Ltd.

No. MCL 6/2023/12-A/4989-4995, Dt. 15-03-2023

Page 2 of 2

<!-- page 11 -->

LIST OF CANCELLATION OF REGISTRATION OF COOPERATIVE SOCIETIES
O/o THE ASSISTANT REGISTRAR OF COOPERATIVE SOCIETIES, W.G.H. DISTRICT, TURA
2. WEST GARO HILLS DISTRICT, TURA

Sl.

Cooperative Society’s Name

No.
1

Associate Sangma Stone Crushing CS Ltd.

Date of Issue of Notification
No.MCL 44/2021/11-A/6674-6680,
Dt.15-03-2021

2

Dalu Nurseryman CS Ltd.

No.MCL 48/2021/5-A/6938-44,
Dt.20-03-2021

3

Okkapara Silk Producers CS Ltd.

No.MCL 43/2021/13-A/6902-6908,
Dt.20-03-2021

4

Rural Transport CS Ltd.

No.MCL 45/2021/14-A/6636-6642,
Dt.15-03-2021

5

Tura Women Handicraft CS Ltd.

No.MCL 42/2021/11-A/6629-6635,
Dt.15-03-2021

6

Sonagre Handicraft CS Ltd.

No.MCL 46/2021/5-A/6643-6649,
Dt.15-03-2021

7

Rongram Tea Growers Processing CS Ltd.

No.MCL 39/2021/12-A/6819-6825,
Dt.18-03-2021

8

Balapara Rajapala Fishery CS Ltd.

No.MCL 40/2021/11-A/6812-6818,
Dt.18-3-2021

9

Forest Ading Women Handicraft CS Ltd.

No.MCL 49/2021/10-A/6688-6694,
Dt.15-3-2021

10

Zekabari Multi Purpose CS Ltd.

No.MCL 41/2021/8-A/6681-6687,
Dt.15-3-2021

11

Duramong Poultry Farming CS Ltd.

No.MCL 44/2021/12-A/6657-6663,
Dt.15-3-2021

12

Ringrey Chering Consumer CS Ltd.

No.MCL 49/2021/11-A/6931-37,
Dt.20-3-2021

13

ICAR Employees & Consumer CS Ltd.

No.MCL 89/2021/17-A/1293-1299,
Dt.28-9-2021

14

Dimchang Balsrigittim Multi Purpose CS Ltd.

MCL 136/2021/18-A/3030-3035,
Dt.25-10-2021

15

Tura Multi Purpose CS Ltd.

MCL 137/2021/10/3004-3009,
Dt.3-10-2021

16

Senford Colony Consumer CS Ltd.

MCL 138/2021/10/3066-3071,
Dt.5-10-2021

17

Educated Unemployed Transport CS Ltd.

MCL 139/2021/9/3048-3053,
Dt.5-10-2021

18

Asibra Multi Purpose CS Ltd.

MCL 145/2021/9/3060-3065,
Dt.5-10-2021

19
20

MCAB Phulbari Branch Employees Thrift CS

MCL 143/2021/8-A/3042-47,

Ltd.

Dt.8-10-2021

J.B. Spice CS Ltd.

MCL 142/2021/8-A/3054-3059,
Dt.5-10-2021

Page 1 of 2

<!-- page 12 -->

21

Durama Songmeng Handicraft CS Ltd.

MCL 141/2021/10-A/3036-3041,
Dt.3-10-2021

22

Selbalgre Fishery CS Ltd.

MCL 144/2021/9-A/3024-3029,
Dt.3-10-2021

23

Green Hills Transport CS Ltd.

MCL 140/2021/12-A/3018-3023,
Dt.3-10-2021

24
25

Agriculture Employees Thrift & Consumer CS

MCL 149/2021/8-A/3448-3454,

Ltd.

Dt.22-11-2021

Ajakra Poultry Development CS Ltd.

MCL 1/2022/20-A/5106-5112,
Dt.8-2-2022

26

Phulbari Primary Housing CS Ltd.

MCL 2/2022/9-A/5141-51__,
Dt.8-2-2022

27

Mahendraganj Yring Industrial CS Ltd.

MCL 3/2022/15-A/5120-5126,
Dt.8-2-2022

28
29

Meghalaya Apex Bank Employees Thrift CS

MCL 4/2022/13-A/5127-5133,

Ltd.

Dt.9-2-2022

Dakopgre Dairy & Livestock CS Ltd.

MCL 5/2022/9-A/5134-5140,
Dt.8-2-2022

30

Koasi Mindure Thrift and Credit CS Ltd.

MCL 6/2022/7-A/5113-5119,
Dt.8-2-2022

31

Muga Silk Culture Ltd.

MCL 19/2022/26-A/6568-6574,
Dt.25-3-2022

Page 2 of 2

<!-- page 13 -->

LIST OF CANCELLATION OF REGISTRATION OF COOPERATIVE SOCIETIES
O/o THE ASSISTANT REGISTRAR OF COOPERATIVE SOCIETIES, EAST GARO HILLS DISTRICT,
WILLIAMNAGAR
3. EAST GARO HILLS DISTRICT, WILLIAMNAGAR

Sl.
No.
1

Cooperative Society’s Name
Williamnagar Leather CS Ltd.

Date of Issue of Notification
No.MCL 51/2021/16-A 6797-6803,
Dt.18-03-2021

2

Maniganj Silk Reeling and Spinning CS Ltd.

No.MCL 74/2021/16-A 6790-6796,
Dt.18-03-2021

3

Digisirigre Horticulture CS Ltd.

No.MCL 50/2021/14-A 6909-6915,
Dt.20-03-2021

4

Kentra Mandasam Handloom Weaver CS Ltd.

No.MCL 53/2021/12-A 6297,
Dt.

5

Damas Rubber Growers cum Processing CS Ltd.

No.MCL 52/2021/12-A 6650-6656,
Dt.15-03-2021

6

Dobu Tea Growers cum Processing CS Ltd.

No.MCL 75/2021/6-A/75/ 7080-7086,
Dt.24-03-2021

7

Tengba Fishery CS Ltd.

No.MCL 54/2021/9-A 7013-,
Dt.24-03-2021

8

Williamnagar Leather CS Ltd.

No.MCL 51/2021/16-A 6797-6803,
Dt.18-03-2021

Page 1 of 1

<!-- page 14 -->

LIST OF CANCELLATION OF REGISTRATION OF COOPERATIVE SOCIETIES
O/o THE ASSISTANT REGISTRAR OF COOPERATIVE SOCIETIES,
SOUTH GARO HILLS DISTRICT, BAGHMARA
7. SOUTH GARO HILLS DISTRICT, BAGHMARA
Sl.
No.

Cooperative Society’s Name

1

Baghmara Sub-Divisional Employees
Thrift CS Ltd.

2

Sibbari Cashewnut Growers CS Ltd.

3

Baghmara Sub-Divisional Govt.
Employees Consumer CS Ltd.

Date of Issue of Notification
MCL 103/2021/4-A/
456-462, Dt.22-7-2021
MCL 106/2021/5-A/
465-471, Dt.22-7-2021
No.MCL 104/2021/4/
449-455, Dt.22-7-2021

9|Page

<!-- page 15 -->

LIST OF CANCELLATION OF REGISTRATION OF COOPERATIVE SOCIETIES

O/o THE ASSISTANT REGISTRAR OF COOPERATIVE SOCIETIES,
SOUTH WEST KHASI HILLS DISTRICT, MAWKYRWAT
8. SOUTH WEST KHASI HILLS DISTRICT, MAWKYRWAT

Sl.
No.

Cooperative Society’s Name

1

Mawmerang Lyngdoh Sohshiah Fishery CS Ltd.

2

Laitnong Joint Farming CS Ltd.

3

Mawbidong Fishery CS Ltd.

4

Sohkhyllam Fishery CS Ltd.

5

Mawhati MPCS Ltd.

6

Syndongklieh Goat Rearing cum Dairy Farming

7

Ngunraw Industrial CS Ltd.

8

Phlanglongpa Fishery CS Ltd.

Date of Issue of Notification
No.MCL 55/2021/15-A/7073-7079,
Dt.24-3-2021
No.MCL 56/2021/14-A/ 7096-7102,
Dt.24-3-2021
No.MCL 81/2021/14-A/ 7110-7116,
Dt.24-3-2021
No.MCL 135/2021/14-A/4743-4749,
Dt.1-2-2022
No. MCL 34/2022/14-A/2433-2439,
Dt.26.9.2022
No. MCL 42/2022/14-A/3731-3737,
Dt. 08-12-2022
No. MCL 43/2022/15-A/3724-3730,
Dt.08-12-2022
No. MCL 41/2022/14-A/3717-3723,
Dt.08-12-2022

Page 1 of 1

<!-- page 16 -->

LIST OF CANCELLATION OF REGISTRATION OF COOPERATIVE SOCIETIES

O/o THE ASSISTANT REGISTRAR OF COOPERATIVE SOCIETIES,
SOHRA SUB-DIVISION, SOHRA
9. SOHRA SUB-DIVISION, SOHRA

Sl.
No.
1

Cooperative Society’s Name
Mawphu Ropeway Goods Transport CS Ltd.

Date of Issue of Notification
No.MCL 18/2021/11/5202-5209,
Dt.25-1-2021

2

Iatreilang Shipara Multi Purpose CS Ltd.

No.MCL 87/2021/14-A 198-204,
Dt.19-4-2021

3

Laitiam Ropeway Goods Transport CS Ltd.

No.MCL 88/2021/13-A/191-97,
Dt.19-4-2021

4

Mattirilang Trade & Bamboo Promotion CS Ltd.

No.MCL 154/2021/59-A/4736-4742,
Dt.1-2-2022

5
6

Laitsohplian Subakarai Rural Tourism & Allied

MCL 8/2022/58-A/5690-5696,

Activities CS Ltd.

Dt.25-2-2022

Mawlong Multi Purpose CS Ltd.

MCL 11/2022/31-A/5669-5695,
Dt.25-2-2022

11 | P a g e

<!-- page 17 -->

LIST OF CANCELLATION OF REGISTRATION OF COOPERATIVE SOCIETIES

O/o THE ASSISTANT REGISTRAR OF COOPERATIVE SOCIETIES,
AMLAREM SUB-DIVISION, AMLAREM
10. AMLAREM SUB-DIVISION, AMLAREM

Sl.
No.
1

Cooperative Society’s Name
Jarain Tourism CS Ltd.

Date of Issue of Notification
No.MCL 86/2021/17-A 198-204,
Dt.19-4-2021

2

Darrang Transport CS Ltd.

No.MCL 97/2021/12-A,
Dt.16-9-2021

3

Monlang Fishery CS Ltd.

No.MCL 98/2021/11-A 968-974,
Dt.16-9-2021

4

Amlateng Multi Purpose CS Ltd.

No.MCL 99/2021/10-A/ 1033-1039,
Dt.16-9-2021

5

Dongmihngi Multi Purpose CS Ltd.

No.MCL 100/2021/10-A/ 1678-1684,
Dt.11-10-2021

6

Wahlyntiar Multi Purpose CS Ltd.

No.MCL 101/2021/10-A/ 1664-1670,
Dt.11-10-2021

7

Ampyut Fishery CS Ltd.

No.MCL 102/2021/16-A 1019-1025,
Dt.16-9-2021

8

Amhi Livestock Farming CS Ltd

No.MCL 25/2022/24-A/ 462-468,
Dt.06-05-2022

9

Amhali Livestock Farming CS Ltd.

No.MCL 26/2022/14-A/809-815,
Dt.02-06-2022

Page 1 of 1
