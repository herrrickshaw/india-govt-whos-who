---
doc_id: "aece75d61ca0b1c1"
source_url: "https://megamb.gov.in/Documents/Corregendum_for_NIT_for_Design.pdf"
ministry: "Meghalaya State Agricultural Marketing Board, Meghalaya"
title: "Corrigendum – NIT for Design, Development & Implementation of a Digital Traceability System for Lakadong Turmeric   With reference to NIT No.  MSAMB/DTS/68/2026-27/1  dated 3rd August, 2026, the Meghalaya State Agricultural Marketing Board (MSAMB) has clarified that the Pre-Bid Meeting for the Desig"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "09b2506373fb079a"
---

<!-- page 1 -->

THE MEGHALAYA STATE AGRICULTURAL MARKETING BOARD
CLEVE COLONY, SHILLONG _— 793003
Directorate of Agriculture, Cleve Colony, Shillong-793001
CORRIGENDUM
NIT for Design, Development & Implementation of a Digital Traceability System for
Lakadong Turmeric
With reference to NIT No. MSAMB/IDTS/68/2026-27/1 dated 34 August, 2026 for
Design, Development & Implementation of a Digital Traceability System for Lakadong
Turmeric, it is hereby clarified that the Pre-Bid Meeting shall be held on 21%t August, 2026,
instead of the date mentioned in the NIT.
Accordingly:
Pre-Bid Meeting: 21% August, 2026
All other terms and conditions of the NIT shall remain unchanged.
Bidders are advised to take note of the above clarification and participate accordingly.
Sd/-
Joint Managing Director
MSAMB, Shillong
a pe ee
