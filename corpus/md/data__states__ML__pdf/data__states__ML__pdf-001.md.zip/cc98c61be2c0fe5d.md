---
doc_id: "cc98c61be2c0fe5d"
source_url: "https://megpolice.gov.in/sites/default/files/Circular37_2011.pdf"
ministry: "Home (Police) Department, Meghalaya"
title: "Circular No. 37/2011"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "031f95e62f5fb23a"
---

<!-- page 1 -->

OFFICE OF THE DIRECTOR GNEERAL & INSPECTOR GENERAL OF POLICE
MEGHALAYA:: SHILLONG.

C I R C U L A R N O. 37/2011
Subject :-

MONITORING INVESTIGATION OF CASES –Reg.
Police being a principal player in the proper working of the criminal justice system,

it can deliver the results only if proper supervision of cases is ensured. It is observed that position
regarding progress in the investigation of cases including writing of CDs is not monitored at the
level of the Circle Inspector, Dy. Superintendent of Police, (Crime/Hqrs) Superintendent to Police
and Range Dy. Inspector General of Police levels. This has resulted in a situation in which, very
often, the Investigating officers are taking years in disposing of cases. In several instances, it is
found that the investigating officers have not written a single case dairy after the cases

were

endorsed to them. Such an approach and attitude toward investigation of crime runs counter to the
principal of criminal justice.
In view of the above, in order to monitor position in this regard in each district,
henceforth, information in the following format should be sent to the office of the Addl. Director
General of Police, (CID), Meghalaya, Shillong every month so as to reach within 1 st week of the
following month.
“The statement of the pending cases with details of CDs in respect of __________district for the
month of ________
Name of Police Station.
Sl.
No

Case No. with section of Name
of No & date of each case Remarks
Law (SR & Non SR both) the present dairy written by I/O
I/O
during the month

Sd/Director General of Police,
Meghalaya, Shillong.
