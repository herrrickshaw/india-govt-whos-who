---
doc_id: "fb6a16e336ccfdd8"
source_url: "https://mserc.gov.in/notifications/Corr_MSERC_13November2024.pdf"
ministry: "Meghalaya State Electricity Regulatory Commission (MSERC), Meghalaya"
title: "Corrigendum to the Order under Regulation 9.5 of the Meghalaya State Electricity Regulatory Commission (Renewable Energy Purchase Obligation & its Compliance) Regulations, 2018   (406 KB)"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "adce1ae5c5ab6387"
---

<!-- page 1 -->

MEGHALAYA STATE ELECTRICITY REGULATORY
COMMISSION SHILLONG
Front Block Left Wing, 1st Floor, New Administrative Building,
Lower, Lachumiere, Shillong, Meghalaya 793001
_______________________________________________________
F. No. MSERC/RPO/Regulations/2018/2024/259

Dated 13th November 2024

CORRIGENDUM
In partial modification of Order F. No. MSERC/RPO/COMP/2024/250 dated 4th November
2024, the Meghalaya Non-conventional and Rural Energy Development Agency shall
continue to be the “State Agency” as per Regulation 2.0 Definition and Interpretations and
sub-clause t.
However, in exercise of the power conferred under Regulation 9.5 and Regulation 23.0 of
the Meghalaya State Electricity Regulatory Commission (Renewable Energy Purchase
Obligation & its Compliance) Regulations, 2018, the Commission hereby directs that the
Meghalaya State Load Despatch Centre (SLDC), in addition to its functions as a Verifying
Agency shall assume with immediate effect the following functions previously assigned to
the State Agency:
a.
b.
c.

d.

Maintaining and settling accounts in respect of certificates,
Repository of transactions in certificates, and
Shall formulate procedures and develop RPO Compliance and Monitoring Web
Tool for RPO compliance monitoring and reporting. It may also suggest
appropriate action to the Commission, if required, for compliance of the
renewable purchase obligation.
Shall carry out other functions incidental to the implementation of renewable
energy certificate mechanism as may be assigned by the Commission from time to
time.

Accordingly, functions assigned to the State Agency under sub-clauses 9.1(c), 9.1 (e), 9.1(f)
and 9.3 stand withdrawn.
It is further directed that all the obligated entities to submit the RPO compliance report
within 15 (fifteen) days after the quarter ending, to the SLDC, to ensure that the
Commission receive the compliance reports promptly.
Furthermore, the obligated entities concerned, as to be determined by the SLDC, are
directed to furnish all claims of meeting the RPO, with all supporting

<!-- page 2 -->

certificates/documents, to the SLDC for verification of RPO compliance from the FY 201819 onwards.
In respect of those obligated entities claiming RPO compliance through Captive Power
Plants, the Verifying Authority, in accordance with sub-clause 2.1 u. of the Meghalaya State
Electricity Regulatory Commission (Renewable Energy Purchase Obligation & its
Compliance) Regulations, 2018, shall continue to be Inspectorate of Electricity,
Government of Meghalaya.

Sd/-

Sd/-

Ramesh Kumar Soni
Member (Law)

Chandan Kumar Mondol
Chairman
