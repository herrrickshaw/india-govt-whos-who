---
doc_id: "d79ffc7fea706c2e"
source_url: "https://megamb.gov.in/Documents/iaffullnotification.pdf"
ministry: "Meghalaya State Agricultural Marketing Board, Meghalaya"
title: "Full Notification"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8e3546a13eab8c34"
---

<!-- page 1 -->

INVITES ONLINE APPLICATIONS FROM UNMARRIED INDIAN MALE AND FEMALE CANDIDATES FOR SELECTION TEST FOR AGNIVEERVAYU INTAKE 01/2025 UNDER AGNIPATH SCHEME

ONLINE REGISTRATION DATES: FROM 17 JANUARY 2024 TO 06 FEBRUARY 2024
ONLINE EXAM DATES: FROM 17 MARCH 2024 ONWARDS
AGNIVEERVAYU INTAKE 01/2025

CAUTION
SELECTION IN THE INDIAN AIR FORCE IS ‘FAIR & TRANSPARENT’ AND ON MERIT ONLY. AT NO STAGE ANY BRIBE IS REQUIRED TO BE PAID TO ANYONE FOR SELECTION OR RECRUITMENT
IN THE INDIAN AIR FORCE. CANDIDATES SHOULD NOT FALL PREY TO UNSCRUPULOUS PERSONS POSING AS RECRUITING/SELECTING AGENTS.
1. Pursuant to the New HR methodology for induction of Agniveervayu under ‘Agnipath Scheme’, aimed to provide an opportunity to Nation’s youth to
experience military way of life for a period of four years, Indian Air Force invites ONLINE applications from unmarried Indian male and female
candidates for selection test from 17 March 2024 onwards to join the IAF as an AGNIVEERVAYU. The number and employability of female
candidates will be decided as per service requirement.

(k)
Gender (For female candidates): Any candidate if found to have predominant characteristics of the opposite gender as
evident on external physical examination, will be rejected as Unfit. Any candidate having undergone gender reassignment surgery will
be declared Unfit.
(l)
Pregnancy (For female candidates):
rejected.

(THE SELECTION TEST IS NOT FOR SELECTION AS COMMISSIONED OFFICERS/ PILOTS/ NAVIGATORS/AIRMEN)
2. Application is required to be filled only ONLINE by the candidates and detailed instructions to fill up the same are available
at https://agnipathvayu.cdac.in.
3.

This examination is valid for AGNIVEERVAYU INTAKE 01/2025.

4. ONLINE REGISTRATION shall commence at 1100h on 17 January 2024 and will close at 2300h on 06 February 2024. Only ONLINE
REGISTERED applications shall be accepted. For registration log on to https://agnipathvayu.cdac.in .
Note: - Candidates are advised to register at the earliest opportunity as no extension of registration dates will be accommodated.
ELIGIBILITY CRITERIA
5.

Details of medical standards are available on CASB web portal https://agnipathvayu.cdac.in .

9.
Consumption of Narcotic Drugs and Psychotropic Substance (NDPS). Consumption of Narcotic Drugs and Psychotropic
substances banned under the NDPS Act 1985 shall be a reject criteria for selection into the IAF. AGNIVEERVAYU found either in
possession or storing or distributing or consuming such drugs and substances after enrolment shall be liable for disciplinary action including
dismissal from the IAF. ZERO TOLERANCE POLICY TO ALCOHOLISM AND SUBSTANCE ABUSE IS FOLLOWED IN IAF.
10.
Body Tattoo. Permanent body tattoos are not permitted, however, tattoos only on inner face of the fore arms (inside of elbow to the
wrist), back (dorsal) part of the hand/reverse side of the palm and Tribals with tattoo which are as per the custom and traditions of their tribes may
be considered. Offensive, obscene, indecent, sexist or racist tattoos are prohibited regardless of location on the body. However, right to consider
a tattoo acceptable or unacceptable will rest with the selection centre. Candidates with permanent body tattoos are to submit two Postcard
size photographs (close up and distant view) with details of size and type of the Tattoo during the second phase of testing.

11.

Age.
(a)

(m)

Date of Birth Block. Candidate born between 02 January 2004 and 02 July 2007 (both dates inclusive) are eligible to apply.

Only Sikh candidates, whose religion prohibits cutting of hair or shaving of face, shall be permitted to grow hair and/or retain beard and
moustache. Accordingly, those Sikh candidates willing to retain the same as per laid down specification are to get their photographs with beard
and moustache.

(b) In case, a candidate clears all the stages of the Selection Procedure, then the upper age limit as on date of enrolment should be
21 years.
6.
Marital Status and Pregnancy. Only unmarried candidates (male & female) will be eligible for enrolment as Agniveervayu and they shall
undertake not to marry during the defined engagement period of four years. Keeping in view limited period of engagement of Agniveervayu inclusive of
training, skill development activities, practical as well as formative assessment and organisational requirement of continued service of Agniveervayu
during the engagement period, longer absence of Agniveervayu during the engagement period will adversely affect the operational efficiency of the Indian
Air Force. Agniveervayu who marry during the said period shall be discharged from the service. Further, only unmarried Agniveervayu will be eligible for
selection in regular cadre as Airman. Female candidates additionally shall be required to undertake not to get pregnant during the engagement period of
four years. Such women Agniveervayu on becoming Low Medical Category (LMC) due to pregnancy shall be liable to be discharged from service.
Pregnancy will debar the women Agniveervayu for selection into Regular Cadre. At the time of enrolment, candidates shall require to sign a voluntary
undertaking accepting above conditions”.
7.

Educational Qualification
(a)

TERMS AND CONDITIONS
12.
Agniveervayu will be enrolled in the Indian Air Force under Air Force Act 1950, for a period of FOUR years. Agniveervayu would form a
distinct rank in the Indian Air Force, different from any other existing ranks. The Indian Air Force is not obliged to retain Agniveervayu beyond the
engagement period of four years.
13.
On completion of four years of service, based on organisation’s requirements and policies promulgated by the Indian Air Force,
Agniveervayu will be offered an opportunity to apply for enrolment in the regular cadre of the Indian Air Force as Airmen. These applications will be
considered in a centralised manner based on objective criteria, including performance during their four-year engagement period and up to 25% of
each specific batch of Agniveervayu will be enrolled in regular cadre of IAF. Agniveervayu will not have any right to be selected for further
enrolment into the Indian Air Force. Selection of the Agniveervayu for further enrolment, if any, shall be at the discretion of the
Government of India.
14.
Employability. Agniveervayu enrolled under this entry are liable to be assigned any duty in organisational interest at the discretion of the
Indian Air Force.

Science Subjects
Candidates should have passed Intermediate/10+2/ Equivalent examination with Mathematics, Physics and English from Education
Boards recognized by Central, State and UT with minimum 50% marks in aggregate and 50% marks in English.
OR
Passed Three years Diploma Course in Engineering (Mechanical / Electrical / Electronics / Automobile / Computer Science /
Instrumentation Technology / Information Technology) from Central, State and UT recognized Polytechnic institute with 50% marks in
aggregate and 50% marks in English in Diploma Course (or in Intermediate/Matriculation, if English is not a subject in Diploma
Course).
OR
Passed Two years Vocational Course with non-vocational subject viz. Physics and Mathematics from Education Boards recognized
by Central, State and UT with 50% marks in aggregate and 50% marks in English in Vocational Course (or in Intermediate / Matriculation,
if English is not a subject in Vocational Course).

(b)

Other than Science Subjects

15.

Training. On being enrolled, Agniveervayu will be imparted military training based on Indian Air Force requirements.

16.
Leave. Grant of leave will be subject to exigencies of the Indian Air Force. The following leave is applicable for Agniveervayu during their
engagement period: (a)

Annual Leave. 30 days per year.

(b)

Sick Leave. Based on medical advice by competent Medical Authority.

17.
Medical and CSD Facilities. For the duration of their engagement period in the Indian Air Force, Agniveervayu will be entitled for medical
facility at Service Hospitals as well as CSD provisions.
18.
Pay, Allowances and Allied Benefits. Agniveervayu enrolled under this Scheme will be paid an Agniveer package of Rs. 30,000/- per
month with a fixed yearly increment. In addition, Risk and Hardship allowances (as applicable in IAF), Dress and Travel allowances will be paid.
Perks such as ration, clothing, accommodation and Leave Travel Concession (LTC) shall also be provided as per the existing rules.
19.
Terminal Benefits - Seva Nidhi Package. AGNIVEERVAYU will be given one time ‘Seva Nidhi’ package comprising their monthly
contribution along with matching contribution by the Government on completion of their engagement period, as indicated below: -

Passed Intermediate / 10+2 / Equivalent Examination in any stream/subjects from Education Boards recognized by Central, State and UT
with minimum 50% marks in aggregate and 50% marks in English.

Contribution to
Agniveers Corpus
Fund (30%)
All Figures in Rs. (Monthly Contribution) (Approximately)

Year

Customised Package
(Monthly)

In Hand (70%)

1st Year

30,000/-

21,000/-

9,000/-

9,000/-

2nd Year

33,000/-

23,100/-

9,900/-

9,900/-

3rd Year

36,500/40,000/-

OR
Passed two years Vocational Course from Education Boards recognized by Central, State and UT with minimum 50% marks in aggregate
and 50% marks in English in Vocational Course (or in Intermediate / Matriculation if English is not a subject in Vocational Course).
Note - 1: Candidates eligible for Science Subjects examination (Including Intermediate/ 10+2/three years’ diploma course in engineering or two
years’ vocational course with non-vocational subjects of Physics and Maths) are also eligible for Other than Science Subjects and would be given
an option of appearing in both Science Subjects and Other than Science Subjects examination in one sitting while filling up the online registration
form.

4th Year

Exit after 4
years

Note - 3: Exact aggregate Percentage of marks before decimal as written in the marks sheet of 10+2/Intermediate/Equivalent Examination/Three
years Diploma Course/Two years Vocational Course OR calculated as per the rules of concerned Education Board / Polytechnic Institute shall only
be considered (For example 49.99% should be taken as 49% and not to be rounded off to 50%).
Mandatory Medical Standards. General Medical Standards for AGNIVEERVAYU male & female candidates are as follows:(a)

Height:
(i)

For Male candidates: Minimum acceptable height is 152.5 cms.

(ii)
For Female candidates: Minimum acceptable height is 152 cms. For candidates belonging to North East or hilly regions of
Uttarakhand, a lower minimum height of 147 cms will be accepted. In case of candidates from Lakshadweep, the minimum height will be
150 cms.
Note:
Candidates availing height relaxation for being domicile of North East/Hilly Regions of Uttarakhand/Lakshadweep are to submit
domicile certificate with endorsement of domicile status at the time of Phase-II testing. Further, candidates from hilly regions of Uttarakhand
must have specific endorsement of hilly region in their domicile certificate.
(b)

Weight: Proportionate to height and age.

(c)

Chest:
(i)
For Male Candidates: The chest wall should be well proportioned and well developed. Minimum chest circumference should be
77 cms and the chest expansion should be atleast 05 cms.
(ii)
For Female candidates: The chest wall should be well proportioned and well developed with the minimum range of expansion of
05 cms.
.

(d)

Hearing: Candidate should have normal hearing i.e. able to hear forced whisper from a distance of 6 meters by each ear separately.

(e)

Dental: Should have healthy gums, good set of teeth and minimum 14 dental points.

(f)

Visual standards
Visual Acuity
6/12 each eye, correctable to 6/6 each
eye

(g)

Maximum limits of Refractive error
Hypermetropia: +2.0D
Myopia: 1D
Including ± 0.50 D Astigmatism

25,550/10,950/28,000/12,000/All Figures in Rs. (Monthly Contribution) (Approximately)

Total Contribution in Agniveers Corpus Fund after four years

Note - 2: Education Boards recognized by Central, State and UT as on date of registrations shall only be considered.

8.

Any candidate, if found pregnant shall be disqualified and her candidature will be

Colour Vision
CP-II

Rs. 5.02 lakh

Contribution to Corpus
fund by GoI

10,950/12,000/Rs. 5.02 lakh

Approximately Rs. 10.04 Lakhs as Seva Nidhi Package
(Absolute amount excluding interest)

Note 1: AGNIVEERVAYU will not be required to contribute to any Provident Fund in Indian Air Force.
Note 2: There shall be no entitlement to gratuity and any kind of pensionary benefits.
20.
Insurance, Death and Disability Compensation.
AGNIVEERVAYU will be provided non-contributory Life Insurance cover of
Rs. 48 Lakhs for the duration of their engagement period as AGNIVEERVAYU in the Indian Air Force. AGNIVEERVAYU will not be governed by
provisions contained in the Pension Regulations/Rules for Indian Air Force. For details of Death/Disability compensation log on to
https://agnipathvayu.cdac.in .
21.
‘Agniveer Skill Certificate’. At the end of engagement period, a detailed Skill-Set certificate will be provided to the AGNIVEERVAYU,
highlighting the skills and level of competency acquired by the personnel during their engagement period.
22.‘
Not Entitled to the ESM Status’. Agniveervayu enrolled under this Scheme will not be eligible for Ex-Servicemen status after their
discharge from the Service on completion of four years engagement period.
23.
Agniveervayu will not be permitted to appear in any examination for commissioning in Army/Navy/IAF during the engagement period of
four years unless he/she has applied for said exam before getting enrolled.
24.
Release at own request prior to completion of engagement period will not be permissible for Agniveervayu. However, in exceptional cases,
personnel enrolled as Agniveervayu may be released, with approval of the Competent Authority.
SEQUENCE OF EXAMINATION

MOBILE PHONES / SMART WATCHES / ELECTRONIC DEVICES ARE PROHIBITED IN TESTING AREAS
DURING PHASE-I AND PHASE-II. CANDIDATES FOUND IN POSSESSION OF MOBILE PHONES/ELECTRONIC
DEVICES SHALL BE DEBARRED PERMANENTLY
Phase - I
25. Online Test. Eligible candidates will be sent admit cards for Phase - I of testing on their registered e-mail IDs between 48-72 hrs prior to
the examination. Candidates are required to download the admit card, take a colour printout and carry the same to the
examination centre. Name of city & exam date will be intimated to the candidates at an earlier date to enable them to plan their movement.
This provisional admit card can also be downloaded by the candidate under candidates login on CASB web portal https://agnipathvayu.cdac.in.
All candidates in possession of provisional admit card will undertake Online Test at centres designated / allotted as per their admit card. Online
test will be objective type and questions will be bilingual (English & Hindi) except for English paper. Candidates are to bring one blue / black pen
and original AADHAAR card along with them for Phase - I testing. Details of the test are as follows: (a)
Science Subjects. Total duration of the online test shall be 60 minutes and shall comprise of Physics, Mathematics and
English as per 10+2 CBSE syllabus.

Corneal Surgery (PRK/LASIK) is not acceptable.
Note: Candidates should bring prescription and spectacles for corrected vision, if being used. The latest prescription should contain
diopter measurement, Ophthalmologist’s registration number, stamp, signature and date of prescription should be within a month prior to
appearing for medical examination.

(h)
General Health: Candidate should be of normal anatomy without loss of any appendages. He / She should be free from any active or
latent, acute or chronic, medical or surgical disability or communicable disease, infection and skin ailments. Candidate shall be physically and
mentally FIT to perform duty in any part of the world, in any climate and terrain.
(j)
Gynaecological Examination (For female candidates): The examination covers external genitalia, hernia orifices and the perineum, any
evidence of stress urinary incontinence or genital prolapse outside introitus.

(b)
Other than Science Subjects. Total duration of the online test shall be 45 minutes and shall comprise of English as per 10+2
CBSE syllabus and Reasoning & General Awareness (RAGA).
(c)
Science Subjects & Other than Science Subjects. Total duration of the online test shall be 85 minutes and shall comprise of
Physics, Mathematics and English as per 10+2 CBSE syllabus and Reasoning & General Awareness (RAGA).
(d)

Marking pattern for online test: (i)
(ii)
(iii)

One mark for every correct answer.
Nil (0) marks for unattempted question.
0.25 marks shall be deducted for each wrong answer.

BEWARE, IMPERSONATORS WILL BE PROSECUTED

<!-- page 2 -->

Note: Above examination methodology has been designed to facilitate selection process based on qualifications of candidates.
Irrespective of the examination methodology AGNIVEERVAYU enrolled under this entry are liable to be assigned any duty in organisational
interest, at the discretion of the Indian Air Force.

35.
The recruitment medical officer and the specialist doctors of Armed Forces are the final authorities on declaring a candidate fit or unfit
during initial medical examination, appeal medical board and medical examination prior to enrolment. The candidates shall be governed by Armed
Forces standards which may be at variance from civil standards. There is no provision for representation or review after the appeal medical board.

26.
Marks scored by the candidates in STAR Phase-I Testing will be “Normalised” by using the formula as published on the web site
https://agnipathvayu.cdac.in, to take into account variation in difficulty levels of the question papers across different sessions. Candidates are to
note that the application of Cut-Off for shortlisting of candidates for STAR Phase-II testing and preparation of Final Merit List for selection will be
based on “Normalised Marks” and not on the “Actual Marks” scored by the candidate in STAR Phase-I testing. Further, on normalisation, marks
scored by a candidate in a subject may become less/more than actual marks, and more than total marks of that subject in exceptional cases.

Note-1: Candidates are advised to get tartar and stains removed from their teeth before appearing for the Medical Examination. Ears should be
free of wax. Candidates should be prepared to stay for the medical examination for four to five days under their own arrangement. No TA/DA shall
be admissible.

27.
CANDIDATES ARE TO QUALIFY IN EACH PAPER INDIVIDUALLY IN SCIENCE SUBJECTS AND OTHER THAN SCIENCE
SUBJECTS, with normalised marks.
The result of Phase-I and shortlisting for Phase-II, based on their performance in
Phase-I Online test, will be uploaded in candidate’s individual log in ID on https://agnipathvayu.cdac.in .

Note-3: Request for change of Medical Examination Centre or Date of Medical Examination shall not be entertained.

Phase - II

36.

Candidates are to fill ONLINE Applications by logging on to https://agnipathvayu.cdac.in.

28.
Soon after the declaration of the result of Phase-I (Online) Test, a cut off will be applied on the normalised marks scored by the
candidates in the Phase-I Test and SHORTLISTED candidates will be sent a New admit card on their registered e-mail IDs for Phase-II test at a
designated ASC. This admit card for Phase-II exam can also be downloaded online under candidate’s login on CASB web portal
https://agnipathvayu.cdac.in. Candidates have to report on the stipulated date and time for Phase-II at the designated ASC along with following:-

37.

During online registration, the following documents are to be uploaded as applicable by respective candidates: -

(a)

Colour print out of Phase-II admit card.

(b)

Colour print out of duly filled application form downloaded on completion of online registration.

(c)

HB pencil, eraser, sharpener, glue stick, stapler and black/blue ball point pen for writing.

(d)

Eight copies of un-attested passport size colour photograph (which was used for the online application registration).

Note-2: Passing in the medical examination is not a guarantee for employment in the Indian Air Force.

HOW TO APPLY

(a)
(b)

Intermediate/10+2 or equivalent mark sheet.

(c)

Higher education Qualification/Additional skill certificates, if any.
OR

3 Yrs Engineering Diploma Final Year Mark sheet (if applying on the basis of 3 Yrs Engineering Diploma from a Govt. recognised
polytechnic in prescribed stream) and Intermediate/Matriculation mark sheet (if English is not a subject in Diploma Course).
OR

(e)
Original and four self-attested photocopies of matriculation passing certificate (required for verification of candidate’s name,
father’s name and his/her date of birth).

2 Yrs Vocational course mark sheets of non-vocational course with subjects English, Physics and Mathematics.

(f)
Original and four self-attested photocopies of matriculation marks sheet (only applicable for three years’ Diploma / two years
Vocational Course holders when English is not a subject in Diploma / Vocational Course).
(g)

(d)
Passport size recent colour photograph (taken not before December 2023) of size 10 KB to 50 KB (front portrait in light
background without facemask and head gear except for Sikhs). The photograph is to be taken with candidate holding a black slate in front
of his/her chest with his/her name and date of photograph taken, clearly written on it with white chalk in capital letters. Change in
appearance like growing beard, head gear etc., in comparison to the photograph may result in cancellation of candidature for STAR online
examination and Phase-II.

Original and four self-attested photocopies of Intermediate/10+2/equivalent examination passing certificate and marks sheet.
OR
Original and four self-attested photocopies of three years diploma course passing certificate and marks sheets of all semesters.
OR

Original and four self-attested photocopies of two years Vocational course passing certificate and all marks sheets including
non-vocational course with subjects English, Physics and Mathematics.
(h)
Certificate for COAFP (Children of Air Force Personnel), including certificate for children of serving/retired/deceased Air Force
civilian employees paid out of defence estimates are to be downloaded as the case may be, from the download section of CASB web portal
and brought along while reporting for Phase-II of the examination.
(j)

Original Phase-I admit card used during Phase-I test bearing Air Force seal and invigilator’s signature.

(k)

Original and four self-attested photocopies of NCC ‘A’, ‘B’ or ‘C’ certificate (if applicable).

Note: Original NCC certificate must have serial No., round seal of issuing authority and stamp of signing authority. Photo affixed
on the certificate must have been attested by issuing authority with stamp.
Note:

Candidates discharged from the IAF for any reason are not eligible to appear in the selection test.

29.
Additional Skills/Qualifications/Achievements. Candidates with any additional skills / qualifications / achievements in fields, including but
not limited to, Information Technology, Motor Vehicle driving / maintenance, Hospitality, Logistics, Accounting, Catering, Welding, Typing Skill,
Sports etc. are required to upload supporting certificates / documents through a link provided along with Phase-II call letter and also furnish them at
the time of Phase-II testing.
30.
Verification of Eligibility. Candidates should be in possession of the documents mentioned at para 28 & 29 above, when
appearing for the selection test which would be scrutinised/verified prior to commencement of Phase-II to ascertain the eligibility
prima-facie. Detailed verification of all the documents listed at para 28 & 29 above shall be carried out in respect of candidates who pass
Physical Fitness Test. Candidature of those who do not meet the laid down educational criteria shall be cancelled during initial verification of
original certificates & mark sheets and also during detailed verification at ASC.

Class 10th /matriculation passing certificate.

(e)

Candidate’s left hand thumb impression image (Size 10 KB to 50 KB).

(f)

Candidate’s signature image (Size 10 KB to 50 KB).

(g)
Candidate’s parent’s (Father/Mother) / Guardian’s signature image (if candidate is below 18 years on the date of filling the online
application).
38.
Examination Fee: Examination fee of Rs. 550/- plus GST is to be paid online by the candidate while registering for the online
examination. The payment can be made by Debit Cards/ Credit Cards/Internet Banking through payment gateway. Candidates are advised to
follow the instructions/steps given on the payment gateway, and also print/keep transaction details for their records.
39.
Refund of multiple payments: If multiple payments are received from a candidate against single application, then that will be refunded
back to the originating account after closing of registration and re-conciliation of all payment records. However, if candidate is found to have filled
multiple applications, only one application will be accepted and the amount with respect to other applications not considered for recruitment process
will not be refunded. Fee once paid shall not be refunded under any circumstances and shall not be kept in reserve for any other examination or
selection.
40.

Candidate must have his/her valid E-mail ID and Mobile No. for successful online registration.

41.
Candidate should enter AADHAAR number in on-line application. Candidates from J&K, Ladakh, Assam and Meghalaya are exempted for
the same, if not having AADHAAR card.
42.
Candidates are to reach at the examination Centre with colour print out of provisional admit card. Candidates shall be debarred from
appearing in the online test in case anomalies / irregularities/ incorrect information are observed during initial verification at the examination venue or
at any subsequent stage of selection process.
43.
The candidates should carry his/her AADHAAR Card (as displayed on their Admit Card) as proof of identity whenever they report for the
Selection Test (Phase-I & II) and Medical Test. Candidates from J&K, Ladakh, Assam and Meghalaya are to carry any other valid ID Proof, if not
having AADHAAR Card.

Note-1: In the case of COAFP, the name of the candidate, parent’s name and the date of birth of the candidate as mentioned in the discharge
book / service book / service particular certificate / casualty certificate (as applicable) must be the same as mentioned in the matriculation passing
certificate of the candidate.

44.
Details about required educational qualification and physical/medical standards are available on CASB web portal
https://agnipathvayu.cdac.in under the candidate’s login and this information can be accessed by the candidate without signing in.

Note-2: Under no circumstances, the candidates shall be permitted to appear in Phase-II of the selection test without original educational marks
sheets/passing certificates & documents mentioned above in paragraph 28. However, candidates with photocopies of educational marks sheets/
passing certificates may be permitted to appear in the selection test only on production of a certificate from college/school principal certifying that
educational certificates/marks sheets are deposited with college/school. In exceptional circumstances, DigiLocker verified certificates will be
accepted and candidates will be issued with CSV (Certificate Subject to Verification) status. Candidates are thereafter required to submit original
certificates to nearest ASC within one month from date of issue of CSV, to clear the CSV status.

GENERAL
45.

General instructions for candidates are as follows: (a)
Candidates must indicate five choices of examination centre for STAR ONLINE EXAM and thirteen choices of ASCs for Phase-II, in
order of preference while filling up the online application form. However, CASB reserves the right to allot any centre other than those
mentioned in the application.

Note-3: The original passing certificates/marks sheets shall not be retained by the selection centre. The same shall be returned to the candidates
on completion of detailed verification.
Note-4: Internet copy of mark-sheet not acceptable.
Note-5: Candidates are strictly prohibited from doing any rough work or write anything anywhere on the Admit Cards issued for Phase-I
and Phase-II. Such candidates will be DEBARRED PERMANENTLY.

MALE CANDIDATE
Test
10 Push-ups
10 Sit-ups
20 Squats

Max Time Period
01 minute
01 minute
01 minute

Remarks
Test will be conducted after 10 minutes break on completion of run
Test will be conducted after 02 minutes break on completion of 10 Push-ups
Test will be conducted after 02 minutes break on completion of 10 Sit-ups

FEMALE CANDIDATE
Test
10 Sit-ups
15 Squats

Max Time Period
01 minute and 30 seconds
01 minute

Remarks
Test will be conducted after 10 minutes break on completion of run
Test will be conducted after 02 minutes break on completion of 10 Sit-ups

Note: Candidates are advised to bring their sports shoes and shorts/track pants. Detailed procedure on expected technique for Push-ups, Sit-ups
and Squats is available on CASB Web Portal https://agnipathvayu.cdac.in
32.
Candidates shall sign a consent form prior to appearing in physical fitness test/medical test for selection in IAF. He / She shall appear in
these tests at his / her own risk and shall not be paid any compensation by IAF for injury/casualty if any, sustained by him / her during such tests.
The consent form shall be signed by parents/guardian of candidates below 18 years of age. The consent form is appended with Phase-II admit card.
33.
Adaptability Test-II. All candidates who pass Physical Fitness Test will have to undertake Adaptability Test-II as per policy in vogue.
Adaptability Test-II is for selection of candidates who can adapt to the environment of the Indian Air Force and are able to adjust to the military way
of life.

34.
Medical Examination. Candidates who qualify Adaptability Test-II shall be issued with medical appointment letter at respective ASCs.
Medical examination shall be conducted by Air Force Medical Team as per IAF medical standards and policy in vogue on subject issue.
Medical examination would also include the following Baseline Investigations: -

(d)
(e)
(f)
(g)

Candidate should apply only once in response to this advertisement.

NOTE: PRESIDENT, CASB RESERVES THE RIGHT TO ALLOT EXAMINATION CENTRE FOR PHASE - I AND II WHICH MAY OR
MAY NOT BE AS PER CHOICE OF THE CANDIDATE.
46.

COVID-19 INSTRUCTIONS FOR CANDIDATES APPEARING FOR SELECTION TEST
(a) Given the risk of COVID-19, candidates are advised to follow all instructions / guidelines issued by Central/State Governments
from time to time.
(b) At the entrance any candidate showing symptoms of Influenza Like Illness (ILI), will not be allowed for the test considering the
safety of other persons.

47.
If there is any variation between English & Hindi/any other regional language versions of the advertisement, English version shall be taken
as authentic.
48.
Any CORRIGENDUM/CHANGES/UPDATES shall be available ONLY on CASB web portal https://agnipathvayu.cdac.in and
NO INTIMATION SHALL BE GIVEN IN ANY NEWS PAPER/ANY OTHER MEDIA. All candidates are required to see the web portal of this office
from time to time.
49.
PROVISIONAL SELECT LIST (PSL).
The Provisional Select List (PSL) (merit-wise) will be prepared after the completion of
selection test and the same will be displayed at all the ASCs and also on web portal https://agnipathvayu.cdac.in on 11 November 2024.
Inclusion of names of candidates in the Provisional Select List (PSL) depends upon the performance of the candidates in the selection test and the
same is determined by application of cut off marks vis-à-vis number of qualified candidates in phase-II testing and anticipated vacancies. Inclusion
of name in Provisional Select List (PSL) does not guarantee automatic enrolment. IAF reserves the right to cancel the Selection Process even
after publication of the Provisional Select List (PSL), if necessary. Enrolment is strictly in order of merit subject to medical fitness, availability of
vacancies, not exceeding the age of 21 years on date of enrolment and meeting all the laid down eligibility criteria as and when called for enrolment.
The validity of the Provisional Select List (PSL) shall be 06 months from the date of display and shall be applicable only for
AGNIVEERVAYU INTAKE 01/2025.
50.
ENROLMENT LIST. List of candidates finally called for enrolment in AGNIVEERVAYU INTAKE 01/2025 will be published on
28 November 2024. E-Call letter ONLY shall be sent to candidates called for enrolment on their Registered e-mail IDs.

Phase - III

(a)
(b)
(c)

Duplicate / Incomplete / erroneously filled applications shall be rejected.

(h)
Candidature of candidates who apply MORE THAN ONCE IN RESPONSE TO THIS ADVERTISEMENT AND OBTAINS different
registration numbers SHALL BE REJECTED.

Female Candidates
Within 08 minutes

PFT- II Candidates who qualify PFT-I to undergo PFT-II after 10 minutes of recuperation time. The sequence of exercises and maximum
time period for male and female candidates are as follows:-

Candidates not reporting for the test on due date and time shall not be accommodated on other dates/shifts.

(d)

(g)

Maximum permissible time

1.6 Km run

(c)

(f)
Candidates are required to provide an active e-mail ID which will be used by CASB for all communications till culmination
of the entire selection process and enrolment for the particular intake. It is also advised to preserve e-mail ID and password for
all future communications.

PFT- I Candidates have to complete 1.6 Kms run as per the following timings to qualify for PFT-II:Male Candidates
Within 07 minutes

REQUESTS FOR CHANGE OF EXAMINATION CENTRE OR DATE OF SELECTION TEST SHALL NOT BE ENTERTAINED.

(e)
Candidates should be prepared to stay for the entire duration of the tests under their own arrangement. No TA/DA shall be
admissible.

31.
Physical Fitness Test (PFT). Names of the shortlisted candidates, who qualify the online test, shall be displayed on the CASB Web
Portal https://agnipathvayu.cdac.in and on a stipulated date shall be called at designated ASC for Physical Fitness Test (PFT) and Adaptability
Test-II. PFT consists of two parts, PFT-I and PFT-II.

Test

(b)

Blood Haemogram - Hb, TLC, DLC
Urine RE/ME
Biochemistry
(i) Blood Sugar Fasting & PP
(ii) Serum Cholesterol
(iii) Urea, Uric acid, Creatinine
(iv) LFT- Serum Bilurubin, SGOT, SGPT
X- Ray chest (PA view)
Ultrasonography of lower abdomen & Pelvis (For female candidates only)
ECG (R)
Any other test necessary in the opinion of the Medical Officer.

51.
FOR ANY QUERY VISIT ONLINE QUERY PORTAL OF CDAC AND CONTACT CASB, BRAR SQUARE, DELHI CANTT,
NEW DELHI - 110010, TELEPHONE NO. 011-25694209/ 25699606 AND E-MAIL: casbiaf@cdac.in OR LOG ON TO CASB WEB PORTAL
https://agnipathvayu.cdac.in UNDER CANDIDATE’S LOG IN. For queries pertaining to filling up of online application form, candidates may
also contact on Telephone No. 020-25503105/25503106
DISCLAIMER
THE TERMS AND CONDITIONS GIVEN IN THE ADVERTISEMENT ARE GUIDELINES ONLY AND ORDERS ISSUED BY THE
GOVERNMENT, AS AMENDED FROM TIME TO TIME, WILL APPLY FOR THE SELECTED CANDIDATES .
THE DATA ENTERED DURING REGISTRATION WILL BE FINAL AND NO CHANGES WILL BE PERMITTED LATER. ENTRY OF WRONG
DATA WILL DISQUALIFY CANDIDATURE.

Candidates declared medically unfit can avail the option for ‘Appeal Medical Board’ (AMB) against their unfitness by depositing Rs. 40/- in
a Government Treasury/RBI/SBI through Electronic Military Receivable Order (e-MRO) / Military Receivable Order (MRO). The application for AMB
along with original copy of e-MRO / MRO, photocopy of Unfitness Certificate are to be submitted to the representative of ASC within three working
days of medical examination.

CANDIDATES FOUND INDULGING IN ANY TYPE OF MALPRACTICES / UNFAIR MEANS DURING THE
EXAMINATION SHALL BE DEBARRED PERMANENTLY.
FOR DETAILED SYLLABUS, MODEL QUESTION PAPERS, PROVISIONAL SELECT LIST AND ENROLMENT LIST, LOG ON TO CASB
WEBPORTAL: https://agnipathvayu.cdac.in
IAF RESERVES THE RIGHT TO CANCEL ENTIRE SELECTION PROCESS AT ANY STAGE WITHOUT ASSIGNING ANY REASONS

BEWARE, IMPERSONATORS WILL BE PROSECUTED
