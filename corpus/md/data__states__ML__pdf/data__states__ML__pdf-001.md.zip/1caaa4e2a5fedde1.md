---
doc_id: "1caaa4e2a5fedde1"
source_url: "https://cdn.s3waas.gov.in/s31efa39bcaec6f3900149160693694536/uploads/2022/02/2022021279.pdf"
ministry: "East Khasi Hills"
title: "Order POL.75 /2020/Pt.I/122"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5e70b435fd8e6af2"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
HOME (POLITICAL) DEPARTMENT
No. POL. 7 5 l2020lPt.I I 122,

Dated: Shillotrg, the llth Febru iltyr2022.
ORDER

In partial modification to the order No.7512020Pt.U116, dt 03-01 -2022 regarding
Preventive Measures to Contain Spread of Covid-l9, the said order is modified as follows

I

All persons entering the State, who are fully vaccinated will not be required to undergo
RTPCR test at the COVID Screening Centres.

All others have to produce an RTPCR negative report valid 72 hours prior to arrival at
the Covid Screening Centre at the entry points or have to undergo a mandatory RTPCR
test at the entry points. For those being tested at the Covid Screening Centres at the entry

points, it is mandatory to be isolated till the receipt of the report.

Children below 15 years of age do not have to produce RTPCR negative report or
undergo testing at Covid Screening Centres unless they are symptomatic.
2

Private Vehicles are allowed to ply subject to the Odd-Even rule with those registration
numbers ending in odd number to ply on Monday and those ending in even number to

ply on Tuesday and to follow the odd-even sequence thereafter, as per orders to be
issued by respective Deputy Commissioners. On Sundays the restriction on Odd Even

rule shall not apply.
3

Night Curfew shall be lifted by respective Deputy Commissioners.

4

Only fully vaccinated persons are permitted entry to restaurants/cinema halls/
bars/clubs.

All persons should follow Covid appropriate behavior including wearing of masks in
public places, maintaining social distancing.

sd/(R.V.Suchiang)
Chief Secretary to the Government of Meghalaya.

Contd l-2.

<!-- page 2 -->

Memo No. POL.75t2O2OtPt.A122-A, Dated: Shillong, the llth February,2L22.
Copy to: l. The Secretary to the Governor of Meghalaya for kind information of the Hon'ble
Governor.
2. The Private Secretary to the Chief Minister, Meghalaya for kind information of the
Chief Minister.
3. The Private Secretary to the Deputy Chief Minister, Meghalaya for kind information
of the Deputy Chief Minister.
4. The Private Secretary to the Speaker, Meghalaya for kind information of the

5.
6.
7.
8.
9.
10.
11.
12.

Speaker.

The Private Secretary to the Leader of Opposition, Meghalaya for kind information
ofthe Leader of Opposition.
The Private Secretary to the Health Minister, Meghalaya for kind information of the
Health Minister.
The Private Secretary to all the Hon'ble Ministers, Meghalaya for kind information
ofHon'ble Minister.
The Private Secretary to Chief Secretary, Government of Meghalaya for favour of
information of the Chief Secretary.
The Additional Chief Secretaries /Principal Secretaries / Commissioners &
Secretaries / Secretaries of all the Departments, Government of Meghalaya.
The Director General of Police, Meghalaya, Shillong for favour of information and
necessary action.
The Secretary, North Eastern Council Secretariat, Nongrim Hills, Shillong-793003.
The Principal Secretary Health & Family Welfare Department for information and
necessary action.

13. The Commissioner and Secretary, Transport Department.
14. The Director, Information and Public Relations for wide publicity of the Order.
15. The Director of Health Services (MD/ MCH&FW)/ Research), Meghalaya, Shillong.
16. The Director, All India Radio for wide publicity of the above Order.
17. The Director, Doordarshan Kendra Shillong for wide publicity of the above Order.
18. The Secretary, KHADC, Shillong/ JHADC, JowaT GHADC, Tura.
19. All Deputy Commissioners, Shillong / Nongstoin / Mairang / Mawkyrwat I Jowai I
Khliehriat /\iongpoh I Tura / Ampati / Resubelpara / Williamnagar lBaghmara for
20.
21.

information and necessary action.
All Superintendents of Police, Shillong / Nongstoin /Mairang / Mawkyrwat I Jowai /
Khliehriat Allongpoh / Tura / Ampati / Resubelpara / Williamnagar lBaghmara for
information and necessary action.
The Chief Executive Officer, Municipal Board, Shillong/ Tura/ Jowai/ Resubelpara/
Baghmara.

Secretary

of Me ghalaya,

Home (Political) Department.
