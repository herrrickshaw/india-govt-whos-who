---
doc_id: "adecd7536b5be0bc"
source_url: "https://megeducation.gov.in/dhte/notices_and_circulars/2025/Adv%20PMS%20ST%202526.pdf"
ministry: "Education Department, Meghalaya"
title: "Advertisement for Pre and Post Matric Scholarship schemes for ST students  (PDF)   (opens in a new window)"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "56dc3795e712dade"
---

<!-- page 1 -->

GOVERNMENT OF MEGHALAYA
DIRECTORATE OF HIGHER AND TECHNICAL EDUCATION
MEGHALAYA:::::SHILLONG
No. CE/SCHOL/AD/1/2018-19/135 Dated Shillong, the 1 July 2025
ADVERTISEMENT
Fresh and Renewal applications for Umbrella Scheme of scholarships of Ministry of
Tribal A ‘fairs, GOI (for Scheduled Tribe students) are invited from students who are
permane tt residents of Meghalaya studying within and outside the State for the year 2025-
26.

1. Pre Matric Scholarship for Scheduled Tribe Students in Classes IX and Class X in
recogr ized schools/ institutes whose Institute Nodal Officers are registered in NSP 2.0.
Annue| income of parents from all sources should not exceed %. 2.50 Lakhs p.a.

2. Post Matric Scholarship for Scheduled Tribe Students who are pursuing higher studies
in different courses from Classes XI to Post Graduation in recognized Colleges/ institutes
whose Institute Nodal Officers are registered in NSP 2.0. Annual income of parents
from all sources should not exceed 2. 2.50 Lakhs p.a.

Applicants are to apply online only in the National Scholarship Portal (NSP 2.0) at
URL hitpsy/scholarships.gov.in
Applicants are required to upload all the necessary documents as mentioned in the
portal. Failure to do so will result in their applications to be defected. Moreover,
applicints are advised to track their applications online from time to time so that the
necessary corrections (if any) may be made within the stipulated timeline. Further, all
applicints are required to properly link/seed their Aadhaar with their bank accounts to
enable Aadhaar-based payment.
The following schedule of applications will be followed:
Openir g Date of Application for Registration By st
Students (For Fresh and Renewal Hr ily, 2025
Closing date of Application Registration By Students th
or Fresh and Renewal 28 November, 2025
Last date for Verification of Aj lications by Institutes 19" December, 2025
This is for further information to all Institutions which are not yet registered in
NSP 2.0 and have not been Aadhaar authenticated, they would be required to complete’
the same to enable their students to avail the scholarships. Institutions which have
already registered are required to update the Courses and Fees for all the years (of the
course) and the fee amount should be filled for an entire Academic Year (and not for 1
semester only). For further details, you may visit the office of the undersigned or contact
us via. email at scholarshipregn@gmail.com }
Sd/-
Director of Higher & Technical Education
Meghalaya:::Shillong
