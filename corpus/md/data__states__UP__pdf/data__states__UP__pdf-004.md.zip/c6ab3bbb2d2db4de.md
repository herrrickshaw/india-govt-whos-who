---
doc_id: "c6ab3bbb2d2db4de"
source_url: "https://cdn.s3waas.gov.in/s39872ed9fc22fc182d371c3e9ed316094/uploads/2023/03/2023030141.pdf"
ministry: "Deoria"
title: "Tourism Policy 2022"
date: ""
pages: 16
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "017b629eed61fee9"
---

<!-- page 1 -->

Tourism Policy 2022
Uttar Pradesh
af. आदी eS age के
te
io

<!-- page 2 -->

५. ४.
Land of Diversity &
T 5 eae
Immense Tourism Opportunities

«Uttar Pradesh is the 4? largest state in India 7 ja of 2.4 lakh sq.kms.
There are 75 districts, 689 towns and 8 divisions in tht

=e

* The State shares inland borders with 7 States and 7 Mational border with
Nepal.

* — India's 3" largest economy growing at 7% annually and contributes more than 8%
of India's GDP. The state has India's largest consumer base with population size of
nearly 24 crore. UP has a major advantage of demographic dividend (56% of its
population size under working age group), which will be a key driver for future
growth.

It holds the 2nd rank in Ease of Doing Business under the Business Reforms
Action Plan. This remarkable jump of 0 positions in ease of doing business
rankings over the last 3 years clearly explains the tremendous efforts put in by the
Govt of UP to readily transform the investment climate in the State.

* In 2024, domestic tourist arrivals in the State stood at approx. 86.2 million,
second highest in the country, while foreign tourist arrivals crossed 0.9 million,
third highestin the country.

“The State has three UNESCO world heritage monuments namely Taj Mahal (one
ofthe Seven Wonders of the World), Fatehpur Sikri and Agra Fort .

* One amongst the lesser-known geological treasures is the Salkhan Fossil Park or
Sonbhadra Fossil Park. This park has fossils which are estimated to be over .4
billion years old.

“Two major rivers of the country, the Ganges and its tributary Yamuna, meet at the
Triveni Sangam in Prayagraj, a Hindu pilgrimage site in Uttar Pradesh. Kumbh
Mela, considered to be the world's largest congregation of religious pilgrims (over
420 million people) is also held at the banks of the Sangam.

I

<!-- page 3 -->

Internationally acclaimed as the land of Lord Rama, Lord Krishna and Buddha,
Uttar Pradesh possesses over 5000 religious, heritage and cultural sites of
international importance such as Ayodhya, Varanasi, Sarnath, Kushinagar,
Mathura, Vrindavan, Jhansi, Kalinjar apart from several other Buddhist, Jain and
Sufi Sites.

* Uttar Pradesh = ajor Buddhist tourism destinations in the world. The
important places id in the Buddhist circuit tour in the state are Kapilvastu
where Gautam spent his twenty-nine years of life; Kaushambi where he
visited after his enlightenment; Kushinagar where one Buddha attained
Mahaparinirvana; Sarnath where Gautam Buddha delivered his first sermon; and
Sravasti where it believed that he spent 24 years.

~ Uttar Pradesh possesses 6,620 sq km of natural forest area. It includes major
eco-tourism destinations such as / National Park,  १॥॥0॥४8 Sanctuaries, 24 Bird
Sanctuaries, 8 Ramsar sites and over 00 dams and water reservoirs.

$ There is a huge potential for rural and agro tourism. Tourism products based on
agro, and experiential tourism are being developed in over one lakh villages in Uttar
Pradesh that are famous for cultivating mangoes, dragon fruit, strawberries, anda
huge sugarcane belt. The Allahabad Surkha Guava, Mango Malihabadi Dusseheri,
Kalanamak Rice, Basmati Rice, Rataul Mango and Mahoba Desawari Pan have
registered Gl tags.

«Uttar Pradesh’s unique topography is conducive to the development of Adventure
Tourism, especially in areas like Bundelkhand, Sonbhadra, Chitrakoot and
Ramgarh Tal.

* Dating back to the prehistoric era, the artistic creations of are a part of the history
and culture of Uttar Pradesh. The plethora of art, crafts, carvings, sculptures,
performances, traditions, and many masterpieces handcrafted by the skilled
artisans of the trade add to the fascinating range of arts and crafts. These also
include prehistoric rock paintings found in the Bundelkhand region of Uttar Pradesh
highlighting a rich cultural tourism basket.

* Efforts in popularising new thematic tourism products such as YUVA (Youth)
tourism, eco-tourism, adventure tourism and rural tourism as niche tourism
products to build interest in new age tourists and travellers

2

<!-- page 4 -->

VA <a A
ra ae) ceil
दर है दा
-INDIA ./ ~
wh
A
of
ss Pradesh 7

<!-- page 5 -->

& है et! 44 27 5
: . ’ e
Ganga Arti, Varanasi -
ba ‘
NRO, rg
. <
कली. न a मर ५
I~“ re SERS 4
ee age a } SAN 4
~ + हर a - ba ‘ “Dy \ a
५ हे $ ) a 5 / (१ “a
a रु ¢ की ——
. ‘ (५ tf
= 0 ; ,
Vd e Fz 4
श्र 7 A t fa
है 5 8 ०
Period of Operation
d Coverage of Policy
This policy comes into effect from 23 Nov 2022 to 22 Nov 2027 or until substituted
Special Provisions
Tourism units built/ under construction/ semi-constructed/ non-operational after
Ist February 208 but registered under the Tourism Policy 2078.
Tourism units which have already availed benefits under the tourism policy of
| 2076 and 2078, implemented earlier, will get benefits within the permissible limits
of expansion.
All classified buildings constructed before Ist February 206 converted into
| tourism units through adaptive reuse as approved by a Departmental Screening
Committee
All buildings that would be provided the status of heritage building during the
operative period of this policy as approved by the committee.
| All categories of tourism units registered under Tourism Policy 2022.
(4)

<!-- page 6 -->

Tourism units
Eligible Categories
Hotels «+ Adventure Tourism Projects
“ Eco-Tourism Stays * Farm Stays and Agri-Tourism Projects
* Eco-Tourism Projects > Innovative and Alternative Accommodation
* Resorts Budget Hotels
<+ Caravan parks > River Cruises
“ Theme Park/ Amusement Park * Wellness Centres
“ Mega Projects * Dhabas
>
“ Fixed Tented Accommodation * Rural Homestay
ec
“ Convention Centre (MICE) # Caravans
c “ Golf Course
Yoga Centres
< Sound and light show/ Laser shows
« Camping/ Perennial Accommodation
+ Pilgrimage Dormitories
* Tour and Travel Operators
Tourist Village/ Rural and Cultural
* Public Museums and Galleries village
Revolving Restaurants / Fly dining  Flotels/Floating Restaurants
restaurants
; * Tourism and Hospitality Training
Heritage Hotels Institutes
Heritage Homestays Cultural Centres/Crafts
Markets/Culinary Fests and other
<+ Wayside Amenities cultural projects

<!-- page 7 -->

० ०
Thematic Tourism Sectors
°
in Uttar Pradesh
6
a2)
Heritage, Art and Water based YUVA Tourism
Culture Tourism activities
As Wed
2 éB QB
Spiritual and Wellness and Cuisine Tourism
Religious Tourism Medical Tourism
ot PY
Nature and Adventure Wedding Tourism
Wildlife Tourism Tourism
I: © ey
(2: 0)
QQ
Meeting, Incentives, Rural/Village/Tribal/ Film Tourism
Conferences and Agri-based Tourism
Exhibitions (MICE)
SS
6]

<!-- page 8 -->

Reclining Buddha, Kushinagar . ‘ei:
हे a.
a 5 es aay & +* ५
Ww “ , रे | f !
y > je 5 हे ] i
\ “Se, \ } ry
% \ \ ९ \! See है
Ps \ y ie rod a
= BN ears : &
१५ =~ 4 «हे! Ne 2 है
aX _ MAX'S — =
के . कक! iy
Mega Circuits under
e Ramayana Circuit Or Swantantrata Sangram Circuit
(५ Ayodhya, Chitrakoot, Shringverpur, (Meerut, Shahjahanpur, Kakori, Bawan Imii
2% Bijethua Mahaviran, Bithoor (Kanpur), 2% (Fatehpur), Chauri-Chaura (Gorakhpur),
Others. * ~ Mahua Dabur (Basti), Others.
Bundelkhand Circuit Buddhist Circuit
Charkhari_ (Mahoba), Chitrakoot, Kapilvastu, Sarnath, —_ Kushinagar,
Kalinjar, Jhansi, Deogarh, Lalitpur, Kaushambi, Shravasti, Sankisa, Atranji
Banda, Hamirpur, Jalaun, Others Khera (Etah), Devdeh (Maharajganj)
Rm Krishna/Braj Circuit Sufi Kabir Circuit
agigey Baldev Mandir, Vrindavan, Goverdhan, Jayas (Amethi), Maghar (SantKabir Nagar),
YAR Gokul, Barsana, Nandgaon, Mahaban, Salim Chishti Dargah (Fatehpur Sikri),
Others nominated by UPBTVP. Dewa Sharif (Barabanki), Dargah Marehra
Sharif (Etah), Dargah Sufi Shah Sharif
tem y (Firozabad), Dargah Shafi Shah Sharif
th Mahabharata Circuit (Firozabad), Lahartara Ashram Kabir
s ( Hastinapur,  Kampil_ _ (Farukkhabad), Janam Sthali, Khangah-e-Niyazia (Bareilly),
Sy" Ahichchhatra,  Barnava__—(Baghpat), Kichhauchha Sharif (Ambedkarnagar)
Mathura, Kaushambi, Gonda, Lakshagraha
Handia (Prayagraj), Keechakvadh Sthal
(Hamirpur), Vidhurkuti (Bijnor), Others.

<!-- page 9 -->

R Jain Circuit Wildlife & Eco Tourism Circuit
Deogarh, Hastinapur, Vahelna, Baghpat, 04 dudhwa National Park, Pilibhit Tiger
Bateshwar, Kampilya  (Farrukhabad), Ww Reserve, Bakihra Sanctuary, Chandra
Parshwanath, Shreyansanatha, Suparshva- Prabha wildlife Sanctuary, Hastinapur
natha, Chandraprabhu, Chandravar Jain wildlife Sanctuary, Kaimoor Sanctuary,
Mandir, Bahubali Jain Mandir, Manga- Katarniaghat Wildlife Sanctuary, Kishanpur
layatan Jain Mandir, Ahikshetra Parshwa- Wildlife Sanctuary, Lakh Bahosi Sanctuary,
nath Digambar Jain Mandir, Others. Mahavir Swami Sanctuary, Nawabganj Bird

Sanctuary, Parvati Bird Sanctuary, Patna
हे ee Bird Sanctuary, Ranipur Sanctuary, Shekha
Shakti Peeth Circuit Jheel Aligarh, Sur Sarovar Pakshi Vihaar,
Vindhyavasini Devi (Vindhyachal), Jwala Amangarh Tiger Reserve, Lion Safari Park,
Devi (Sonbhadra), Sita Samahit Sthal Etawah, Others as nominated by ETDB
(Bhadohi), Lalita Devi (Prayagraj), Alopi
Devi (Prayagraj), Kadavasini (Kaushambi),
Shivani Devi (Chitrakoot), Gayatri Aadhyatmik Ciruit
Shakyipeeth (Sumerpur), Pateshwari Devi Gorakhpur, Balrampur, Ghazipur, Goriya
Devipatan (Balrampur), Lalita Devi (Mathura), Sant Ravidas Sthal, Mauni
(Naimisharanya),  Shakumbhari Devi Baba, Chochakpur, Pavhari Baba Ashram,
(Saharanpur), Katyayini Devi (Mathura), Kinaraam Ashram, Triveni Sangam,
Sheetala Chaukia Dham (Jaunpur), Bhardwaj Ashram, Ghuisarnath Dhaam,
Vishalakshi Devi (Varanasi), Belha Devi Bhrigu Rishi Ashram, Vyaaspeeth Kalpi,
(Hamirpur), Bairagarh Mata, Konch Gola Gokarn Nath, Maa Parmeshwari
(Jalaun), Chandika Devi, Buxar (Unnao), Devi, Bhrigu Ashram — Baleshwar,
Kushmanda Devi, Ghatampur (Kanpur Dugdheshwar Shiv Sthal, Makhauda
Dehat), Devkali Mandir (Auraiya), Maa Dhaam, Shiv Mandir Shrankhla, Others.
Tarkulha Devi Dham (Gorakhpur), Maa
Sheetla Mata Sthal (Mau), Others.
Craft Circuit
खडे Marble Inlay and Zardozi (Agra), Glass Craft (Firozabad), Glass beeds Craft, Purdil Nagar
~SF (Hathras), Tarkashi Craft (Mainpuri), Brass Craft (Moradabad), Brass Craft and Tala (Aligarh),
Wooden Craft (Saharanpur), Muda Craft (Hapur), Hathkargha Pilkhuwa (Hapur), Banarasi Saree
(Varanasi), Gulabi Meenakari (Varanasi), Wooden Toys (Varanasi), Stone Carving (Varanasi), Zari
work (Jaunpur), Brass Utensils (Mirzapur), Pottery Udyog (Chunar), Brass Craft, Jakhora
(Lalitpur), Brass Craft, Amra (Jhansi) Silverfish Craft, Maudaha (Hamirpur), Shazar Stone Craft
(Banda), Paper Craft, Kalpi (Jalaun), Glazed Pottery (Rampur), Carpet Craft (Amroha), Khurja
Pottery (Bulandshahr), Carpet Craft (Sambhal), Terracotta (Gorakhpur), Others.
a oo =~ > | ey ae
me न" ५५ i
od (/
4 =~
गे Wer
mig Pa ४ yy i
के, I\S Se
4) n/N ad
- GANZ
ae COA: Ie

<!-- page 10 -->

Rampura Fort, Bundelkhand ९ ३7 5 IE बस रा, आय! दे
3 ies =i > = कु : .
कं ak
by °
375 ar
—_ = a
a =, = = ,
५७ कं “न w "a os
4 a 5 = — डर =
9" | bal ata ae aa
“ spo
: ५ Ls य a |
४... = fl ops
“4 ee . —
° oye
Incentives, Subsidies
and Concessions
—~—0_== Capital Investment Subsidy
Capital and interest subsidy shall be
SE | 5७७४५, ERT provided only to the tourism units that are
ecw (६७) |7/०७॥००० | ५७५५ located within 20 km of the sites identified in
tourism circuits and at unserved destinations
20 lakhs Upto 0 crore as notified by the Department.
Additional 5% subsidy to women/SC/ST
owned Enterprises.
~ Additional 5% subsidy for new tourism units.
Upto 500 crore in unserved and Focus Tourism Destinations
More thateOOerore (as notified by the Department).
 Sumofallincentives capped at 30%.
~ Land Purchased included in ECI.
PPP projects can also availincentives.
2 नमन subsidy
5% for a period of 5 years ona bank loan upto INR 5 crore.
Unit can apply for either capital or interest subsidy.
| 3 पल duty
00% exemption of stamp duty for the first transaction only.
