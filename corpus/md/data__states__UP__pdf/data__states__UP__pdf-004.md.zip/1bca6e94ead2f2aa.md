---
doc_id: "1bca6e94ead2f2aa"
source_url: "https://kgmu.org/upload_file/user_download/f42c977a59180ba389ab7c75f82b176d.pdf"
ministry: "King George's Medical University, Lucknow, Uttar Pradesh"
title: "Post marketing Analysis of Centchroman (Prospective study) in Uttar Pradesh, India (Department of Obstetrics and Gynaecology)"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "95e020ef97d5c7c5"
---

<!-- page 1 -->

Department of Obstetrics & Gynaecology
King George Medical University, Lucknow
Advertisement
Applications in prescribed format are invited from eligible candidates for the following posts on
purely temporary basis under Gates Foundation funded project entitled "Post marketing Analysis of
Centchroman (Prospective study) in Uttar Pradesh, India" under principal investigator Prof
Soniya Nityanand, Hon'ble. Vice Chancellor, KGMU, Lucknow as per details given below:
The essential qualifications & experience etc. required for the position have been mentioned below.
S.No

1

Description

Details

Name of the Post

Research Officer (Non-Medical)

Number of Post

12

Upper Age limit

40 Years as on (date of interview)

Place of Work

1. Department of Obstetrics & Gynaecology, KGMU,
Lucknow
2. Veerangna Awanti Bai District Women Hospital
3. Veerangna Jhalkari Bai District Women Hospital
4. District Women Hospital, Sitapur
5. District Women Hospital, Lakhimpur
6. District Women Hospital, Shrawasti

Tenure

Temporary basis (initially for 1 year), Renewable based on
satisfactory performance for 1 year

Remuneration

Rs. 25000/ month

Qualification

Essential Qualification:
Graduate degree in Nursing/ Midwifery/Life Sciences/Social
Science/Public Health

Experience
Preferably 1-2 years experience in Reproductive Health,
Family Planning, and Community Based research.
Skill
 Well-versed in using the internet and tablets/
mobile/smartphones for data collection.
 Good verbal communication (Hindi).
Job responsibilities

1. Participant Identification and Recruitment
 Identify potentially eligible participants attending OPDs.
 Assess basic reproductive and contraceptive history
 Screen participants according to the approved study
inclusion and exclusion criteria.
Page 1 of 4

<!-- page 2 -->

 Explain the study objectives, procedures, potential
benefits and risks to eligible participants.
 Facilitate voluntary participation
 Enrol eligible participants
2. Obtain written informed consent as per approved
study protocol
3. Provide family-planning counselling
 Explain available contraceptive methods accurately and
without bias in respectful and non judgmental manner.
 Discuss effectiveness, advantages, disadvantages,
common side effects, warning signs and follow-up.
 Address myths and misconceptions.
 Support informed and voluntary choice, without
coercion or preferential promotion of a particular method.
4.Data Collection
 Collect baseline demographic, reproductive,
contraceptive and relevant clinical information.
 Administer study questionnaires and interview
schedules.
 Complete case record forms accurately and completely.
 Enter collected information into the study
database/electronic data-capture system.
 Verify data for completeness and consistency.
 Maintain source documents and study records according
to the study protocol.
5.Participant Follow-up
 Maintain a participant follow-up schedule.
 Contact participants as permitted by the study
protocol.
 Document continuation, discontinuation, switching
or non-use of contraceptive methods.
 Record side effects, adverse events and other
relevant outcomes.
 Identify participants requiring clinical review and
facilitate appropriate referral.

2

Name of the Post

Research Co-ordinator

Number of Post

7

Upper Age limit

40 Years as on (date of interview)

Place of Work

1. Department of Obstetrics & Gynaecology, KGMU,
Lucknow (2 Post)
2. Veerangna Awanti Bai District Women Hospital
(1 Post)
3. Veerangna Jhalkari Bai District Women Hospital
(1 Post)
Page 2 of 4

<!-- page 3 -->

4. District Women Hospital, Sitapur (1 Post)
5. District Women Hospital, Lakhimpur (1 Post)
6. District Women Hospital, Shrawasti (1 Post)
Tenure

Temporary basis (initially for 1 year), Renewable based on
satisfactory performance for 1 year

Remuneration

Rs. 38000/ month

Qualification

Essential Qualification:
Post Graduate degree in Nursing/ Midwifery/ Life
Sciences//Public Health/ Social Science
Candidates with GNM/ANM qualification and relevant
experience in family planning, reproductive health or
hospital-based research may also be considered

Job responsibilities

Experience
Preferably 1-2 years experience in reproductive
health, Family Planning, Community Based research.
Knowledge of Data collection and follow-up of study
participants desirable.
Skill
 Well-versed in using the internet and tablets/
mobile/smartphones for data collection.
 Good knowledge of using computer for data recording
and analysis.
 Good verbal communication (Hindi).
1. Participant Identification and Recruitment
 Identify potentially eligible participants attending OPDs.
 Assess basic reproductive and contraceptive history
 Screen participants according to the approved study
inclusion and exclusion criteria.
 Explain the study objectives, procedures, potential
benefits and risks to eligible participants.
 Facilitate voluntary participation
 Enrol eligible participants
2. Obtain written informed consent as per approved
study protocol
3. Provide family-planning counselling
 Explain available contraceptive methods accurately and
without bias in respectful and non judgmental manner.
 Discuss effectiveness, advantages, disadvantages,
common side effects, warning signs and follow-up.
 Address myths and misconceptions.
 Support informed and voluntary choice, without
coercion or preferential promotion of a particular method.
4.Data Collection
 Collect baseline demographic, reproductive,
contraceptive and relevant clinical information.
 Administer study questionnaires and interview
schedules.
Page 3 of 4

<!-- page 4 -->

 Complete case record forms accurately and completely.
 Enter collected information into the study
database/electronic data-capture system.
 Verify data for completeness and consistency.
 Maintain source documents and study records according
to the study protocol.
5.Participant Follow-up
 Maintain a participant follow-up schedule.
 Contact participants as permitted by the study
protocol.
 Document continuation, discontinuation, switching
or non-use of contraceptive methods.
 Record side effects, adverse events and other
relevant outcomes.
 Identify participants requiring clinical review and
facilitate appropriate referral.
6.Administrative Responsibilities
 Prepare monthly recruitment and follow-up reports.
 Track study milestones and participant numbers.
 Assist the Principal Investigator in preparing
progress reports.
 Assist with preparation of data summaries and
preliminary reports when required
th
Last date of application 28 September 2026
Date of interview
1st October 2026
Terms & Conditions:
1. Interested candidates may send their filled application in the prescribed format, Biodata,
experience certificate, testimonials along with 1 set of self attested photocopies of all the
relevant documents to the HOD office Department of Obstetrics & Gynaecology, KGMU,
Lucknow till 2:00 PM on 28th September 2026. Also email softcopy in word document to
fogsiemoc_lko@yahoo.co.in
2. Candidates reporting time for interview start at 10:00 am on 1st October 2026
3. Incomplete application will not be considered
4. No TA/DA will be paid for attending interview
5. The salary mentioned is consolidated sum without any other benefits.
6. Age/Education qualification/Experience will be considered till the date of interview.
7. Person working in government & Public sector undertaking should produce "No Objection
Certificate" at the time of interview.
8. The posts are filled-up on purely temporary basis, co-terminus with the project & the
candidate will have no right to claim for permanent employment.

Page 4 of 4

<!-- page 5 -->

<!-- page 6 -->
