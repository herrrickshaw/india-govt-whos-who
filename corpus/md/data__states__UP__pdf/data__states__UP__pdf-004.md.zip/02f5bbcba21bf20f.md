---
doc_id: "02f5bbcba21bf20f"
source_url: "https://kgmu.org/upload_file/user_download/f7bd57eb55964eaf5617bbde67f29e8b.pdf"
ministry: "King George's Medical University, Lucknow, Uttar Pradesh"
title: "Regarding Instructions for Allied and Healthcare Sciences (Paramedical) Diploma Admission Batch 2026-27 3rd Round Document Verification (16 to 19 October 2026)."
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "11bee17115945a98"
---

<!-- no text layer: pending OCR -->
