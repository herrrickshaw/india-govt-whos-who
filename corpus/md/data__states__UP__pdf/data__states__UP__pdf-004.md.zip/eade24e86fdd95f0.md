---
doc_id: "eade24e86fdd95f0"
source_url: "https://upscec.gov.in/pdf/niyamwali2014.pdf"
ministry: "Uttar Pradesh State Cooperative Society Election Commission, Uttar Pradesh"
title: "निर्वाचन नियमावली 2014"
date: ""
pages: 46
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d43183313f9207d7"
---

<!-- page 1 -->

mÙkj Áns'k 'kklu
lgdkfjrk vuqHkkx&1
la[;k 579@49&1&2014&8 ¼56½13 Vh0lh0&I
y[kuÅ fnukad 19 ebZ] 2014
vf/klwpuk
mÙkj Áns'k lgdkjh lfefr vf/kfu;e] 1965 ¼mÙkj Áns'k vf/kfu;e la[;k 11] lu~ 1966½ dh
/kkjk 130 ds v/khu cuk;h x;h mÙkj Áns'k lgdkjh lfefr fu;ekoyh] 1968] le;&le; ij la'kksf/kr]
ds fu;e 470 ds v/khu 'kfDr dk Á;ksx djds mDr vf/kfu;e dh /kkjk 2 ds [k.M ¼¥¥½ ds vuqlj.k esa
xfBr mÙkj Áns'k jkT; lgdkjh lfefr fuokZpu vk;ksx }kjk vius fuokZpu lEcU/kh dk;ksZa dks fofu;fer
djus dh n`f"V ls jkT; ljdkj ds iwokZuqeksnu ls ,rn~}kjk fuEufyf[kr fu;ekoyh cuk;h tkrh gS%&
mÙkj izns'k jkT; lgdkjh lfefr fuokZpu fu;ekoyh] 2014
v/;k;&1
ÁkjfEHkd
¼1½ ;g fu;ekoyh ÞmÙkj Áns'k jkT; lgdkjh lfefr fuokZpu fu;ekoyh] 2014ß dgh tk;sxhA
¼2½ ;g fu;ekoyh xtV esa Ádkf'kr gksus ds fnukad ls Áo`Ùk gksxhA
1&¼1½ tc rd Álax ;k lUnHkZ ls vU;Fkk visf{kr u gks] bl fu;ekoyh esa %&
¼d½ Þvf/kfu;eß dk rkRi;Z mÙkj Áns'k jkT; lgdkjh lfefr vf/kfu;e] 1965 ls gS(
¼[k½ Þvk;ksxß dk rkRi;Z ÞmÙkj Áns'k jkT; lgdkjh lfefr fuokZpu vk;ksxß ls gS(
¼x½ Þlgdkjh fu;ekoyhß dk rkRi;Z mÙkj Áns'k lgdkjh lfefr fu;ekoyh 1968 ls gS(
¼?k½ ÞfuokZpuß dk rkRi;Z%&
¼1½ Áfrfuf/k;ksa] ;k
¼2½ ÁcU/k desVh ds lnL;ksa ;k
¼3½ lgdkjh lfefr ds lHkkifr@milHkkifr] vFkok vU; lfefr dks Hksts tkus okys Áfrfuf/k ds
fuokZpu ls gS(
¼³½Þernkrkß dk rkRi;Z fdlh ,sls lnL;@Áfrfuf/k ls gS] tks vf/kfu;e] fu;e vkSj lfefr dh
mifof/k;ksa ds v/khu ernku djus dk gdnkj gks vkSj blds vUrxZr fdlh lgdkjh lfefr dh
ÁcU/k desVh esa vf/kfu;e dh /kkjk&24 ;k /kkjk&29¼7½ ds v/khu uke fufnZ"V ;k fu;e&42¼[k½
;k 450 ds v/khu lg;ksftr ;k fu;e&451 ds v/khu uke fufnZ"V O;fä Hkh gS vkSj mlds uke
fuokZpu ds fy;s rS;kj dh xbZ lEc) lfefr ;k fuokZpu {ks= dh vfUre ernkrk lwph esa gksa(
¼p½ Þernkrk lwphß dk rkRi;Z fuEufyf[kr ls gS&
¼,d½ÁcU/k desVh ds lnL; ds fuokZpu dh fLFkfr esa] lkekU; fudk; ds] ;FkkfLFkfr Áfrfuf/k;ksa@lnL;ksa
dh lwph(
¼nks½lfefr ds lHkkifr] milHkkifr ;k Áfrfuf/k;ksa ds fuokZpu dh fLFkfr esa] ljdkjh lsodksa ls
fHkUu ÁcU/k desVh fuokZfpr] lg;ksftr vkSj uke fufn`"V lnL;ksa dh lwph(
¼rhu½lnL; ds Áfrfuf/k ds fuokZpu dh fLFkfr esa] ml {ks= ds ;k tgk¡ ls lEc) lfefr ds lkekU;
fudk; esa Áfrfuf/k fuokZfpr fd;k tkuk gks] lnL;ksa dh lwph(
¼N½ ÞmEehnokjß dk rkRi;Z vf/kfu;e] fu;e ;k lfefr dh mifof/k;ksa ds v/khu ik= ,sls ernkrk ls gS]
tks fuEufyf[kr :i esa fuokZpu yM+us ds fy, uke&funsZ'ku i= nkf[ky djrk gS%&
¼,d½&Áfrfuf/k ds :Ik esa] ;k
¼nks½&ÁcU/k desVh ds lnL; ds :Ik esa] ;k
¼rhu½&lgdkjh lfefr ds lHkkifr ;k milHkkifr ds :i esa(

<!-- page 2 -->

¼t½Þvuqlwfpr tkfrß] Þvuqlwfpr tutkfrß vkSj Þukxfjdksa ds vU; fiNM+s oxksZaß dk ogh rkRi;Z gS] tks
mÙkj Áns'k yksd lsok ¼vuqlwfpr tkfr;ksa] vuqlwfpr tutkfr;ksa vkSj vU; fiNM+ oxksZa ds fy,
vkj{k.k½ vf/kfu;e 1994 esa muds fy, fn;k x;k gS(
¼>½Þe.Myh; lgdkjh fuokZpu vf/kdkjhß dk rkRi;Z lgdkjh lfefr ds eq[;ky; ls lEcfU/kr tuin ds
e.My ds e.Myh; la;qä vk;qä@mi vk;qä ,oa e.Myh; la;qä fucU/kd@e.Myh; mi fucU/kd]
lgdkfjrk] mÙkj Áns'k vFkok ,sls vf/kdkjh ls gS] tks mä in ds drZO;ksa ds fuoZgu gsrq l{ke
Ákf/kdkjh }kjk vf/kd`r fd;k x;k gks(
¼¥½Þftyk lgdkjh fuokZpu vf/kdkjhß dk rkRi;Z ml tuin ds ftyk eftLVªsV ls gS] ftlesa lEcfU/kr
lfefr dk eq[;ky; fLFkr gks(
¼V½Þftyk lgk;d fuokZpu vf/kdkjhß dk rkRi;Z lgdkjh lfefr ds eq[;ky; ls lEcfU/kr tuin ds
Þlgk;d vk;qä ,oa lgk;d fucU/kdß] lgdkfjrk vFkok ,sls vf/kdkjh ls gS tks mä in ds drZO;ksa
ds fuoZgu ds fuoZgu gsrq l{ke Ákf/kdkjh }kjk vf/kd`r fd;k x;k gks(
¼B½ÞfuokZpu vf/kdkjhß dk rkRi;Z jkT; ljdkj ds fdlh ,sls vf/kdkjh ls gS] ftls vk;ksx ds funsZ'kksa ds
v/khu ftyk lgdkjh fuokZpu vf/kdkjh }kjk fdlh lgdkjh lfefr ;k lgdkjh lfefr ds oxZ ;k
oxksZa ;k fdlh {ks= ;k {ks=ksa ds fy, bl fufeÙk fuokZpu vf/kdkjh fu;qä fd;k x;k gks(
¼M½Þlgk;d fuokZpu vf/kdkjhß dk rkRi;Z fuokZpu vf/kdkjh ds d`R;ksa ds lEiknu esa lgk;rk djus ds
fy;s ftyk lgdkjh fuokZpu vf/kdkjh }kjk fu;qä ,d ;k ,d ls vf/kd fu;qä vf/kdkjh ls gS(
¼<½Þernku vf/kdkjhß dk rkRi;Z fuokZpu vf/kdkjh }kjk fdlh fof'k"V {ks= ;k {ks=ksa esa ernku LFky ds
fy;s fu;qä vf/kdkjh ls gS ftls fuokZpu vf/kdkjh ds d`R;ksa ds lEiknu esa lgk;rk djus vkSj ,sls
vU; dk;Z gsrq fu;qä fd;k x;k gks] tks bl fu;ekoyh ds v/khu visf{kr gksa(
¼.k½Þlgdkjh fuokZpu i;Zos{kdß dk rkRi;Z ,sls vf/kdkjh ls gS] ftls vk;ksx }kjk fdlh fof'k"V {ks= ;k
{ks=ksa ;k lfefr;ksa ds fdlh oxZ ;k oxksZa dh lEiw.kZ fuokZpu ÁfØ;k dh fu"i{krk ,oa fu;e laxr
dkjZokbZ dk i;Zos{k.k fd;s tkus gsrq fu;qä fd;k x;k gks(
¼r½ Þpquko fpUgß dk rkRi;Z vk;ksx }kjk lgdkjh lfefr ds mEehnokjksa ds fuokZpu gsrq vuqeksfnr Árhd
fpUg ls gS(
¼Fk½ ÞfuokZpu {ks=ß dk rkRi;Z ,sls {ks= ls gS] tgk¡ ls fufnZ"V la[;k esa lkekU; fudk; ds Áfrfuf/k vFkok
ÁcU/k desVh ds lnL; ds fuokZpu gsrq ftyk lgk;d lgdkjh fuokZpu vf/kdkjh vFkok bl Á;kstu
gsrq Ákf/kd`r vf/kdkjh }kjk vo/kkfjr fd;k tk;(
¼n½ ÞfuokZpu LFkyß dk rkRi;Z lfefr ds dk;kZy; ;k eq[;ky; ;k ftyk lgk;d lgdkjh fuokZpu
vf/kdkjh }kjk vf/klwfpr dk;kZy; ;k eq[;ky; ds ;FkklEHko fudVre fdlh lkoZtfud LFky ls
gS(
¼/k½ Þernku LFkyß dk rkRi;Z lfefr ds dk;kZy; ;k eq[;ky; ;k ftyk lgk;d lgdkjh fuokZpu
vf/kdkjh }kjk vf/klwfpr fdlh lkoZtfud LFky ls gS rFkk lkekU; fudk; ds xBu gsrq Áfrfuf/k;ksa
ds fuokZpu ds ekeys esa ernku LFky] lfefr ds dk;kZy; ;k eq[;ky; ;k 'kk[kk ds vfrfjä dksbZ
vU; lkoZtfud LFkku gksxk] tSlk fuokZpu vf/kdkjh }kjk vo/kkfjr fd;k x;k gks(
¼u½ ÞfuokZpu oknß dk rkRi;Z lgdkjh lfefr ds fuokZpu ds i'pkr~ fuokZpu ls {kqC/k i{kdkjksa }kjk
vf/kfu;e dh /kkjk 70 ds v/khu lafLFkr okn ls gSA
2&bl fu;ekoyh esa Á;qä ijUrq vifjHkkf"kr 'kCnksa vkSj inksa ds ogh vFkZ gksaxs tks vf/kfu;e vkSj
lgdkjh fu;ekoyh esa Øe'k% muds fy, leuqnsf'kr gSaA
v/;k;&2
lgdkjh lfefr;ksa ds fuokZpu ds lkekU; fu;e
3&mifof/k;ksa esa fdlh ckr ds gksrs gq, Hkh] fdlh lgdkjh lfefr ;k lfefr;ksa ;k lgdkjh lfefr;ksa ds
fdlh oxZ ;k oxksZa dk fuokZpu vf/kfu;e vkSj bl fu;ekoyh ds micU/kksa ds vuqlkj gksxkA

<!-- page 3 -->

4&lgdkjh lfefr ds lfpo vFkok ÁcU/k funs'kd dk ;g drZO; gksxk fd fuokZfpr ÁcU/k desVh ds
dk;Zdky ds lekfIr ds fnukad ds 4 ekl iwoZ] ml ftys] ftlesa lfefr dk iathd`r eq[;ky; fLFkr
gS] ds ftyk lgk;d lgdkjh fuokZpu vf/kdkjh vFkok ml Ákf/kdkjh] ftls lfefr ds fdlh oxZ ;k
oxksZa ds fy, vk;ksx }kjk] ,sls Ák;kstu ds fy, vf/kd`r fd;k x;k gks] dks fyf[kr :Ik ls lfefr dh
fuokZfpr ÁcU/k desVh ds dk;Zdky lekIr gksus ds fnukad dh lwpuk nsxk vkSj vo/kkj.k 'kqYd tek
fd, tkus dk Áek.k ÁLrqr djrs gq, lfefr ds fuokZpu djk, tkus dk vuqjks/k djsxkA
5&¼d½ lgdkjh lfefr;ksa dh ÁcU/k desVh ds dk;Zdky ds lekIr gksus dh lwpuk ÁkIr gksus ij ftyk
lgk;d lgdkjh fuokZpu vf/kdkjh dk ;g drZO; gksxk fd og tuin dh leLr ,slh lfefr;ksa]
ftudk dk;Zdky vkxkeh 4 ekl ds Hkhrj lekIr gks jgk gks] dh ladfyr lwpuk vk;ksx dks ns vkSj
fuokZpu gsrq frfFk fu/kkZfjr fd;s tkus dh laLrqfr djsA
¼[k½lgdkfjrk ,oa vU; foHkkxksa dh lgdkjh lfefr;ksa dks iathd`r djus okys vf/kdkjh dk ;g drZO;
gksxk fd] og vius {ks=kf/kdkj dh lgdkjh lfefr;ksa ds fuokZpu gsrq visf{kr lwpuk ,oa vfHkys[k
ftyk lgk;d lgdkjh fuokZpu vf/kdkjh ,oa vk;ksx dks ;k vk;ksx ds Ákf/kd`r vf/kdkjh dks vis{kk
fd;s tkus ij miyC/k djk,A
6&mÙkj Áns'k lgdkjh lfefr fu;ekoyh] 1968 esa fdlh ckr ds gksrs gq, Hkh fucU/kd dk ;g
mÙkjnkf;Ro gksxk fd fdlh ubZ lfefr dks iathd`r djus ds Ik'pkr~ vFkok /kkjk 35 ds v/khu ÁcU/k
desVh dks voØfer fd;s tkus vFkok lfefr ds lekesyu] foHkktu] voØkUr ;k vU; vkdfLed
n'kkvksa esa xfBr vUrfje desVh dh rRdky lwpuk ÁcU/k desVh ds lE;d~ fuokZpu djkus ds mÌs'; ls
vk;ksx dks Ánku djsA
mä ds vfrfjä fucU/kd dk ;g Hkh mÙkjnkf;Ro gksxk fd fdlh lfefr dks ifjlekfir fd;s
tkus vFkok fucU/ku fujLr fd;s tkus dk vkns'k fn;s tkus ij mä vkns'k ds lEcU/k esa vk;ksx dks
lalwfpr djrs gq, ;g vuqjks/k djsa fd lEcfU/kr lfefr dk fuokZpu u djk;k tk;A
7&ftyk lgk;d lgdkjh fuokZpu vf/kdkjh ;k fucU/kd ;k lfefr ds lfpo vFkok ÁcU/k funs'kd ls
fuokZpu djk;s tkus dh lwpuk ÁkIr gksus ij vk;ksx lfefr;ksa ds fdlh oxZ ;k oxksZa ds fy;s fuokZpu
frfFk fu/kkZfjr djsxkA vk;ksx }kjk ,slk fd;s tkus ij ml ftys dk ftyk eftLVsªV ;k ftyk
lgdkjh fuokZpu vf/kdkjh] tgk¡ lfefr dk eq[;ky; fLFkr gks] fu;r fnukadks dks fuokZpu djkus ds
fy, dkjZokbZ djsxk] vkSj bl Á;kstu ds fy, fdlh Hkh ljdkjh deZpkjh ;k vf/kdkjh dh lsokvksa dh
mlds }kjk vis{kk dh tk ldrh gS vkSj ;fn fdlh deZpkjh ;k vf/kdkjh ds lEcU/k esa ,slk dksbZ
vkns'k ftyk eftLVsªV ;k ftyk lgdkjh fuokZpu vf/kdkjh }kjk tkjh fd;k x;k gS rks mldk ikyu
u djuk vijk/k le>k tk;sxk] ftlds fl) gksus ij] og tqekZus ls tks rhu gtkj :Ik;s rd gks
ldrk gS ;k dkjkokl ls tks rhu ekg rd gks ldrk gS ;k nksuksa ls nf.Mr fd;k tk;sxk%
ÁfrcU/k ;g gS fd mÙkj Áns'k lgdkjh xzke fodkl cSad fyfeVM] y[kuÅ dh 'kk[kkvksa ds
lnL;ksa ds Áfrfuf/k;ksa ds fuokZpu djkus dk Ákf/kdkj ml ftys ds ftyk eftLVªsV esa fufgr gksxk tgk¡
,slh 'kk[kk fLFkr gks%
8& fdlh lgdkjh lfefr ;k lfefr;ksa ;k lgdkjh lfefr;ksa ds fdlh oxZ ;k oxkaZs dk fuokZpu ,sls
fnukad dks gksxk] tks vk;ksx fu;r djs vkSj lEc) ftyk lgdkjh fuokZpu vf/kdkjh bl Ádkj
fu;r~ fd;s x;s fnukad ij] bl Ák;kstu ds fy, lfefr;ksa ds fHkUu&fHkUu oxZ ;k oxksZa ds fy, ;k
fHkUu&fHkUu {ks=ksa ds fy, ,d ;k ,d ls vf/kd fuokZpu vf/kdkjh fu;qä djsxk%
ÁfrcU/k ;g gS fd ml foHkkx dk tks lfefr ds ÁcU/k ;k Á'kklu ls lEc) gks] dksbZ
vf/kdkjh@deZpkjh] fuokZpu vf/kdkjh fu;qä ugha fd;k tk;sxkA
9& fuokZpu vf/kdkjh ,sls leLr d`R;ksa dk lEiknu djsxk tks bl fu;ekoyh ds v/khu O;kfn"V fd;s
tk,a ;k mlds drZO;ksa dk ikyu djus ds fy;s Áklafxd ;k vko';d gksa] fdUrq fdlh fuokZpu
vf/kdkjh dh vuqifLFkfr esa dksbZ lgk;d fuokZpu vf/kdkjh vFkok ernku vf/kdkjh ftls ftyk

<!-- page 4 -->

lgdkjh fuokZpu vf/kdkjh }kjk ,slk djus ds fy;s Ákf/kd`r fd;k x;k gks] fuokZpu vf/kdkjh
ds drZO;ksa dk ikyu djsxkA
10&bl fu;ekoyh ds fdUgh vU; micU/kksa esa fdlh ckr ds gksrs gq, Hkh fuokZpu vf/kdkjh ÁR;sd
fuokZpu {ks= ds fy;s ,sls ljdkjh lsodksa esa ls] tks lfefr;ksa ds ÁcU/k vkSj Á'kklu ls lEc)
u gks] fuokZpu ds lapkyu esa viuh lgk;rk ds fy;s ernku vf/kdkjh Áfrfu;qä dj ldrk
gSA
11&lfefr dh ÁcU/k desVh rFkk lEc) lgdkjh lfefr dk ÁR;sd vf/kdkjh] fuokZpu djkus es
fuokZpu vf/kdkjh dks iwjh lgk;rk nsus ds fy;s ck/; gksaxs vkSj ,sls lHkh vfHkys[k miyC/k
djk;saxs ftudh fuokZpu vf/kdkjh }kjk bl Á;kstu gsrq vis{kk dh tk;A
Š12&¼d½ lfefr dk lfpo vFkok ÁcU/k funs'kd le;&le; ij vk;ksx }kjk fn;s x;s funs'kksa
;k rRle; Áo`Ùk micU/kksa ds vuqlkj leLr ernkrkvksa dh lwph] ftuds uke ds lEeq[k
vf/kfu;e] bl fu;ekoyh vFkok mifof/k;ksa esa ;Fkk of.kZr dksbZ vugZrk,a] ;fn dksbZ gks]
mfYyf[kr dh tk;sxh] rS;kj djsxk vkSj fuokZpu ds fnukad ds 45 fnu iwoZ lE;d~ :Ik ls
ukekafdr lnL;] lk/kkj.k lnL; ;k lgkuqHkwfr lnL; lfEefyr fd;s tk;saxs%
izfrcU/k ;g gS fd ,slh lfefr;ksa] tks ifjlekiuk/khu gks vFkok izcU/k desVh ds
fuokZpu u gksus ds dkj.k fuyfEcr@vf/kØfer dh xbZ gksa] ds izfrfuf/k mDr ernkrk lwph esa
lfEefyr ugha fd;s tk;saxsA
13&fu;e&12 ds vuqlkj rS;kj dh xbZ vfUre lwph] fuokZpu vf/kdkjh }kjk ml fnukad] le;
vkSj LFkku ij tks fuokZpu dk;ZØe esa vf/klwfpr dh tk;] iznf'kZr dh tk;sxhA
14&dksbZ mEehnokj] izcU/k desVh ds ,d ls vf/kd in ds fy, lkFk&lkFk fuokZpu yM+us ds fy,
vgZ u gksxkA ;fn ,d ls vf/kd in ds fy;s uke&funsZ'ku i= oS/k ik;sa tk;s rks mls dsoy
,d in ds fy;s fodYi nsuk gksxk rFkk vU; ds fy, viuk uke&funsZ'ku&i= okil ysxkA
,slh okilh ds fy, fuf'pr fnukad ds iwoZ ;fn og vius fodYi dk iz;ksx djus esa pwd djs]
rks mlds leLr uke&funsZ'ku&i= voS/k gks tk;saxsA
15&lgdkjh lfefr ds vgZ lk/kkj.k ,oa lgkuqHkwfrdj lnL; dks] pkgs lfefr dh iwath esa mlds
fgr dh ek=k fdruh gh D;ksa u gks] lfefr ds fuokZpu esa dsoy ,d er nsus dk vf/kdkj
gksxkA
16&;fn fdlh vH;FkhZ] ftldk ukekadu fu;e 49 ds v/khu fof/k }kjk ekU; ik;k x;k gks vkSj
ftlus viuh vH;fFkZrk okil u yh gks] e`R;q gks tkrh gS vkSj ernku gksus ds iwoZ mldh e`R;q
dh lwpuk çkIr gks tkrh gS rks fuokZpu vf/kdkjh] ml vH;FkhZ dh e`R;q ds rF; ds lEcU/k esa
viuk lek/kku dj ysus ds i'pkr~ lEcfU/kr fuokZpu {ks= ds ernku dks LFkfxr dj nsxk
vkSj bldh lwpuk ftyk lgdkjh fuokZpu vf/kdkjh vkSj vk;ksx dks nsxk vkSj ml fuokZpu
{ks= ;k in ds fy;s ukekadu u;s fljs ls nkf[ky fd;s tk;sxs- fdUrq ml O;fä ds fy, tks
ernkuLFkfxr fd;s tkus ds le; fuokZpu ds fy;s vH;FkhZ Fkk] dksbZ vfrfjä ukekadu
vko';d u gksxk] vkSj ,slk O;fä ftlus ernku LFkfxr dj fn;s tkus ds iwoZ viuk ukekadu
Š 'kklukns'k la[;k&990@49&01&2017&8¼56½&13Vhlh&I y[kuÅ] 18 tqykbZ] 2017

<!-- page 5 -->

okil fy;k Fkk] og ,sls LFkxu fd;s tkus ds i'pkr ukekadu nkf[ky fd;s tkus ds fy;s
vugZ u gksxk vkSj ernku ,sls LFkxu ds i'pkr ml fnukad dks gksxk tks vk;ksx }kjk fu;r
fd;k tk;A
17&lfefr ds fuokZpu ls lEcfU/kr çfd;k çkjEHk gks tkus ij] fu;e&16 esa mfYyf[kr dkj.kksa ds
vfrfjä fdlh vU; dkj.k ls dksbZ fuokZpu çfØ;k jksdh ugha tk;sxh]
ijUrq ;g fd ;fn ernku LFky ij cyos ;k [kqyh fgalk ds dkj.k ernku ;k fuokZpu dh fdlh
dk;Zokgh esa O;o/kku mRiUu gks tk; ;k fdlh çk—frd vkink ds dkj.k fuokZpu djk;k tkuk lEHko u
gks rks ,sls fuokZpu ds fy, fu;qä fuokZpu vf/kdkjh] ckn esa vf/klwfpr fd;s tkus okys vkxkeh fnukad
rd ds fy;s fuokZpu ds LFkxu dh ?kks"k.kk djsxkA ,sls LFkxu dh lwpuk rRdky ftyk lgdkjh fuokZpu
vf/kdkjh vkSj vk;ksx dks nh tk;sxh ftl ij vk;ksx fuokZpu ds fy;s u;k fnukad fu;r djsxk]
ijUrq ;g vkSj fd] fuokZpu vf/kdkjh }kjk ç;ksx dh tk jgh ernku Mk;jh esa iwjs ?kVukØe dk
Øec)@le;c) o.kZu djus ds i'pkr~ gh fuokZpu çfØ;k LFkfxr dh tk,xhA
18&;fn fdlh dkj.k ls fuokZpu vf/kdkjh }kjk fdlh lfefr dk fuokZpu jksdk x;k gS rks fuokZpu dh
çfØ;k ml çØe ls] tgk¡ ij mls jksdk x;k Fkk] ;k mlds iwoZ ds çØe ls ;k u;s fljs ls] tSlk
fd vk;ksx fofu'p; djs] çkjEHk dh tk;sxh]
çfrcU/k ;g gS fd ;fn ukekadu ds i'pkr oS/k uke&funsZ'ku i=ksa ij pquko fpUgksa dk vkoaVu
dj fn;k x;k gS rks fuokZpu dh dk;Zokgh vkxs pyk;h tk;sxh vkSj fuokZpu ,sls fnukad dks djk;k
tk;sxk tks vk;ksx fu;r djsa]
vxzrj çfrcU/k ;g gS fd fdlh lgdkjh lfefr dk fuokZpu vf/kfu;e dh /kkjk&29 dh mi/kkjk ¼3½
ds çfrcU/kkRed [k.M ds v/khu vk;ksx }kjk LFkfxr fd;k tkrk gS rks fuokZpu dh leLr çfØ;k u;s
fljs ls çkjEHk dh tk;sxhA
19&çR;sd fuokZpu esa ernku lekIr gksus ds i'pkr~ eri=ksa dh x.kuk fuokZpu vf/kdkjh }kjk fu;e 44
esa fofgr jhfr vkSj vk;ksx ds fn'kk&funsZ'kksa ds v/khu djk;h tk;sxh vkSj çR;sd vH;FkhZ] mlds
fuokZpu vfHkdrkZ vkSj x.kuk vfHkdrkZ dks ;g vf/kdkj gksxk fd og x.kuk ds le; mifLFkr jgsaA
20&vf/kfu;e ds micU/k ,oa bl fu;ekoyh ds v/khu tkjh fd;s x;s lgdkjh fu;e] vkns'k ,oa
fn'kk&funsZ'k çR;sd iqueZrnku ij mlh çdkj ykxw gksaxs] tSls fd og ewy ernku esa ykxw gksrs gSaA
21&¼1½;fn fuokZpu ds i'pkr~ fdlh lfefr dh çcU/k desVh esa fuokZfpr lnL;ksa dh la[;k] fuokZfpr
fd;s tkus okys fofgr la[;k ls de ik;h tkrh gS rks fjä LFkkuksa ds fy, fuokZpu] ;FkklEHko 'kh?kz
djk;s tk;saxs]
çfrcU/k ;g gS fd lHkkifr@milHkkifr vkSj çfrfuf/k;ksa ds fuokZpu ds fy, erkf/kdkj çkIr lnL;ksa
dh la[;k ds vk/ks ls vf/kd lnL; dk gksuk vfuok;Z gSA
¼2½ ;fn vk;ksx dk ;g lek/kku gks tkrk gS fd lfefr dh fuf"Ø;rk ;k vU; dkj.kksa ls fdlh lfefr
dk fuokZpu djk;k tkuk lEHko ugha gS] rks vk;ksx ,slh lfefr fo'ks"k dks ifjlekIr fd;s tkus ds
fy, lEcfU/kr çkf/kdkjh dks laLrqfr dj ldrk gS vkSj lEcfU/kr çkf/kdkjh dk ;g drZO; gksxk fd
lfefr dks lquokbZ dk volj nsrs gq, fof/k vuqlkj lfefr dks ifjlekIr djus ;k lfefr dk
iathdj.k fujLr fd;s tkus dh dkjZokbZ djsA
22&lgdkjh lfefr;ksa ds fuokZpu ds lEcU/k esa vk;ksx }kjk le;&le; ij fuxZr funsZ'k ck/;dkjh
gksaxsA

<!-- page 6 -->

v/;k;&3
lkekU; fudk; ,oa çcU/k desVh ds fuokZpu {ks= dk vo/kkj.k
23&vk;ksx }kjk fdlh lgdkjh lfefr v/kok lgdkjh lfefr;ksa ds fdlh oxZ ;k oxksaZ ds fy, fuokZpu
frfFk;k vf/klwfpr fd, tkus ds i'pkr~ lEcfU/kr lgdkjh lfefr vFkok lgdkjh lafefr;ksa ds fdlh
oxZ ;k oxksZa ds fuokZpu ds fy, {ks= vo/kkj.k dh dkjZokbZ dh tk,xhA
24&leLr çdkj dh çkjfEHkd lgdkjh lfefr;ksa ds iath—r eq[;ky; ls lEcfU/kr ftyk lgk;d
lgdkjh fuokZpu vf/kdkjh }kjk fu;e&27 ,oa 28 esa fofgr jhfr ,oa vk;ksx }kjk fn, x;s fn'kk
funsZ'kksa ds v/khu vko';d gksus ij lkekU; fudk; ds çfrfuf/k;ksa] lgdkjh lfefr dh çcU/k desVh
ds enL;ksa] lHkkifr] mi lHkkifr rFkk vU; lgdkjh lfefr;ksa esa Hksts tkus okys çfrfuf/k;ksa ds
fuokZpu gsrq {ks= vo/kkj.k dh dk;Zokgh dh tk,xhA
çfrcU/k ;g gS fd] ftyk dsUæh; lgdkjh lfefr;ksa dh fLFkfr esa {ks= vo/kkj.k dh dkjZokbZ e.Myh;
lgdkjh fuokZpu vf/kdkjh }kjk dh tk,xhA
25&jkT; Lrjh;@'kh"kZ lgdkjh lfefr dh n'kk esa {ks= vo/kkj.k dh dkjZokbZ vk;ksx ds çkf/k—r
vf/kdkjh }kjk dh tk,xhA
26&fuokZpu {ks=ksa ds vo/kkj.k ds fy, lfefr dk lfpo vFkok ;FkkfLFkfr çcU/k funs'kd] og leLr
lwpuk,a vFkok rF;] ftldh vis{kk ftyk lgk;d lgdkjh fuokZpu vf/kdkjh vFkok e.Myh;
lgdkjh fuokZpu vf/kdkjh vFkok vk;ksx ds çkf/k—r vf/kdkjh }kjk le;&le; ij dh tk,]
miyC/k djk;sxkA
27&¼1½ lgdkjh lfefr dh çcU/k desVh ds lnL;ksa ;k ;FkkfLFkfr] lgdkjh lfefr ds lkekU; fudk; ds
çfrfuf/k;ksa ds fuokZpu ds ç;kstukFkZ ftyk lgk;d lgdkjh fuokZpu vf/kdkjh vFkok e.Myh;
lgdkjh fuokZpu vf/kdkjh vFkok vk;ksx vFkok çkf/k—r vf/kdkjh] lgdkjh lfefr dh mifof/k;ksa esa
fdlh ckr ds gksrs gq, Hkh] lgdkjh lfefr ;k ;FkkfLFkfr lgdkjh lfefr ds fdlh oxZ ;k oxksaZ ds
fuokZpu ds fy, vufUre :i ls fuEufyf[kr ckrksa dk vo/kkj.k djsxk%&
¼d½ fuokZpu {ks=ksa dh la[;k] ftlesa lgdkjh lfefr ds dk;Z{ks= dks foHkkftr fd;k tk;sxk¼[k½ çR;sd fuokZpu {ks= dk foLrkj]
¼x½ çR;sd fuokZpu {ks= ds fy, vkoafVr LFkkuksa dh la[;k]
¼?k½ {ks= dk fpUgkadu rFkk vkjf{kr LFkkuksa dh la[;k%
çfrcU/k ;g gS fd fuokZpu {ks=ksa dk uke fgUnh o.kZekyk esa mfYyf[kr fd;k tk;sxkA
¼2½&rnqijkUr ftyk lgk;d lgdkjh fuokZpu vf/kdkjh@e.Myh; lgdkjh fuokZpu vf/kdkjh@l{ke
çkf/kdkjh vufUre :i ls fd;s x;s vo/kkj.kk ij vkifÙk;ka vkeaf=r djus ds fy,] lquokbZ dh frfFk
vafdr dj mä vo/kkj.k dks fdlh çeq[k nSfud lekpkj i= esa çdkf'kr djsxk] ftlesa ,sls çdk'ku
ds fnukad ls 7 fnu ds Hkhrj vkifÙk;ka vkeaf=r dh tk;saxhA ftldh ,d çfrfyfi lEc) lfefr
dks Hkh Vhdk&fVIi.kh ds fy, Hksth tk;sxh
çfrcU/k ;g gS fd çkjfEHkd] ftyk@dsUæh; lgdkjh lfefr;ksa dh fLFkfr esa çdk'ku e.My ls
çlkfjr gksus okys çeq[k nSfud lekpkj i= esa çdkf'kr fd;k tk;sxk vkSj jkT; Lrjh;@'kh"kZ lgdkjh
lfefr dh n'kk esa çdk'ku e.My Lrjh; nSfud lekpkj i= ds lHkh laLdj.kksa esa çdkf'kr fd;k tk;sxk%
vxzrj çfrcU/k ;g gS fd ,slh çkjfEHkd] ftyk@dsUæh; lgdkjh lfefr] ftldk dk;Z{ks= ,d
jktLo tuin ls vf/kd gks] ds vufUre vo/kkj.k dk çdk'ku ,sls çeq[k nSfud lekpkj i=] tks lfefr
ds dk;Z{ks= esa çlkfjr gksrk gks] esa fd;k tk;sxkA
¼3½&fuokZpu {ks= ds vo/kkj.k dk ekin.M fuEufyf[kr esa ,d ;k vf/kd gks ldrk gS] vFkkZr%&
1- jktLo {ks=
2- lnL;rk dk@ds oxZ
3- lfefr ds dk;Z{ks= ds lEcU/k esa vU; rxZlaxr vk/kkj%

<!-- page 7 -->

çfrcU/k ;g gS fd çkjfEHkd —f"k _.k lfefr vFkok çkjfEHkd xUuk lfefr@nqX/k lfefr dh
fLFkfr esa vo/kkj.k dh bdkbZ ;FkklEHko lfefr ds dk;Z{ks= ds vUrxZr vkus okyh ,d ;k vf/kd xzke
iapk;r gksxhA
¼4½&¼d½vufUre vo/kkj.kk ds v/khu çkIr vkifÙk;ksa vkSj fVIif.k;ksa ij ftyk lgk;d lgdkjh fuokZpu
vf/kdkjh@e.Myh; lgdkjh fuokZpu vf/kdkjh@l{ke çkf/kdkjh }kjk ,sls çdk'ku ds
X;kjgosa@ckjgoas@rsjgosa fnu] tSlk fd vufUre vo/kkj.k esa mfYyf[kr gks] esa lEcfU/kr vkifÙkdrkZ
es lquokbZ dj fopkj djsxk vkSj lquokbZ ds i'pkr~ lEcfU/kr iaftdk ij vkifÙk ,oa lquokbZ esa çkIr
dFku dk laf{kIr fooj.k vafdr dj ml ij vkifÙkdrkZ ls gLrk{kj djk;sxk vkSj Lo;a Hkh gLrk{kj
djsxkA
¼[k½&ç'uxr lquokbZ esa fy;s x;s fu.kZ; ls lEcfU/kr mfYyf[kr rF;ksa dh çfrfyfi vkifÙkdrkZ }kjk nl
:i;s çfr i`"B tek dj çkIr dh tk ldrh gSA
¼5½&rnqijkUr] ftyk lgk;d lgdkjh fuokZpu vf/kdkjh@e.Myh; lgdkjh fuokZpu
vf/kdkjh@l{keçkf/kdkjh }kjk çkIr vkifÙk;ka ds fuLrkj.k ds lEcU/k esa ;Fkk vko';d fVIi.kh
lEcfU/kr iaftdk esavafdr djrs gq, fuokZpu {ks=ksa] LFkkuksa dh la[;k vkSj vkjf{kr LFkkuksa dh la[;k
dk vfUre vo/kkj.k djsxkA bl çdkj fd;s x;s vfUre vo/kkj.k dks vufUre çdk'ku ds iUægosa
fnu ,sls lekpkj i= esa çdkf'kr djsxk] tSlk mifu;e ¼2½ esa mfYyf[kr gSaA ,sls vo/kkj.k dh ,d
çfrfyfi lEc) lfefr dks Hkh tk;sxhA
28&ftyk lgk;d lgdkjh fuokZpu vf/kdkjh@e.Myh; lgdkjh fuokZpu vf/kdkjh@l{ke
çkf/kdkjhvf/kfu;e dh /kkjk 29¼5½ ds çfrcU/kkRed [k.M ds micU/kksa ds v/khu vkjf{kr LFkkuksa ds
fy, fuokZpu {ks=@{ks=ksa dks vkjf{kr djsxk vkSj ,slk vkj{k.k ml fuokZpu {ks=@{ks=ksa ds] tgka ls
çcU/k desVh ds lnL;ksa dk fuokZpu fd;k tkuk gks] ukeksa ds fgUnh o.kZekyk ds Øe esa j[kdj
pØkuqØe esa ml lhek rd fd;k tk;s] tgka rd LFkku vkjf{kr fd;k tkuk vko';d gks%
çfrcU/k ;g gS fd bl çdkj vkjf{kr {ks=ksa dks fuEu çdkj ls fgUnh o.kZekyk ds Øe esa vkoafVr
fd;k tk;sxk%&
¼1½ ,d vuqlwfpr tkfr;ksa@vuqlwfpr tutkfr;ksa ds fy,]
¼2½ ,d ukxfjdksa ds vU; fiNM+s oxksaZ ds fy,]
¼3½ nks efgykvksa ds fy,]
vxzrj çfrcU/k ;g gS fd tgka ,d ls vf/kd fuokZpu {ks=ksa ds uke dk çFke v{kj ,d leku
gks] ogka ,sls ekeyksa esa vkj{k.k ,d fuokZpu {ks= ds uke ds vxys v{kj }kjk fofu;fer fd;k tk;sxkA
29&ftyk lgk;d lgdkjh fuokZpu vf/kdkjh@e.Myh; lgdkjh fuokZpu vf/kdkjh@l{ke çkf/kdkjh dk
;g Hkh drZO; gksxk fd lfefr;ksa ds vo/kkj.k ls lEcfU/kr vufUre ,oa vfUre vo/kkj.k dh ,d
çfr lEcfU/kr ftyk eftLVªsV@ftyk lgdkjh fuokZpu vf/kdkjh rFkk vk;ksx dks Hkh miyC/k
djk;sxkA
v/;k;&4
lkekU; fuokZpu çfØ;k
30&vk;ksx }kjk fdlh lgdkjh lfefr ;k lfefr;ksa ds fdlh oxZ ;k oxksZa ds fuokZPku dh vf/klwpuk
fuxZr fd, tkus ij ml ftys dk ftyk lgdkjh fuokZpu vf/kdkjh@ftyk eftLVªsV] ftlesa lfefr
dk eq[;ky; fLFkfr gks] vk;ksx ds fn'kk&funsZ'kksa ds v/khu jgrs gq, fuokZpu vf/kdkjh dh fu;qfä
djsxkA
31&ftyk lgk;d lgdkjh fuokZpu vf/kdkjh vius vf/kdkfjrk {ks=@{ks=ksa dh ,slh lgdkjh lfefr;ksa]
ftudk eq[;ky; mlds lEcfU/kr ftys esa gS vkSj ftudk fuokZpu gksuk gS] ds fuokZPku ls lEcfU/kr

<!-- page 8 -->

vk;ksx }kjk vf/klwfpr fuokZpu dk;ZØe dks LFkkuh; nSfud lekpkj i= esa vufUre {ks= vo/kkj.k
ds i'pkr~ çdkf'kr djsxkA
32&mä fuokZpu dk;ZØe ds çdk'ku esa] ftyk lgk;d fuokZpu vf/kdkjh@l{ke çkf/kdkjh fuokZpu gsrq
fuokZpu LFky ,oa ernku LFky dk fu/kkZj.k djsaxs vkSj mls lwpuk esa vafdr djsaxs vkSj lfpo vFkok
çcU/k funs'kd] tSlh fLFkfr gks] ls ;g vis{kk djsaxs fd mä dk;ZØe dh ,d çfr lfefr ds lwpuk
iV ij pLik dh tk;%
çfrcU/k ;g gS fd ernku dk LFkku lfefr dk dk;kZy; ;k eq[;ky; gksxk ijUrq] vifjgk;Z
dkj.kksa ls ftyk lgk;d lgdkjh fuokZPku vf/kdkjh@l{ke çkf/kdkjh }kjk fofu'p; fd;k x;k ernku
LFky] lfefr ds dk;kZy; ;k eq[;ky; ds ;FkklEHko fudV dksbZ lkoZtfud LFky Hkh gks ldrk gS%
vxzlj çfrcU/k ;g gS fd lgdkjh fu;ekoyh ds fu;e&84&d ds mi fu;e&¼4½ esa ;Fkk
mfYyf[kr lfefr ds çfrfuf/k;ksa ds pquko ds ekeysa esa ernku dk LFky lfefr ds dk;kZy; ;k eq[;ky;
;k 'kk[kk ds vfrfjä dksbZ vU; lkoZtfud LFkku] tSlk fd ftyk lgk;d lgdkjh fuokZpu
vf/kdkjh@l{ke çkf/kdkjh }kjk vo/kkfjr fd;k tk;] gks ldrk gSA
33&¼d½ lfefr ds lfpo vFkok çcU/k funs'kd dk ;g mÙkjnkf;Ro gksxk fd lfefr ds fuokZPku dk;ZØe
,oa ernku LFky dh lwpuk vufUre ernkrk lwph çdkf'kr gksus dh frfFk ls de 15 fnu iwoZ
lfefr ds lwpuk iV ij çnf'kZr djsa%
çfrcU/k ;g gS fd mä lwpuk çkjfEHkd lgdkjh lfefr dh fLFkfr esa] lEcfU/kr fodkl [k.M]
ftyk@dsUnzh; lgdkjh lfefr dh fLFkfr esa lEcfU/kr ftyk eftLVªsV ds dk;kZy; ,oa jkT;
Lrjh;@'kh"kZ lgdkjh lfefr dh fLFkfr esa vk;qä ,oa fucU/kd rFkk vk;ksx ds dk;kZy; ds lwpuk iV
ij Hkh çnf'Zkr dh tk,xhA
¼[k½ fuokZpu dk;ZØe esa fuEufyf[kr dks çnf'kZr fd;k tk;sxk%&
¼,d½vufUre ernkrk lwph ds çn'kZu dk fnukad(
¼nks½ vufUre ernkrk lwph ij vkifÙk;ka nkf[ky djus vkSj muds fuLrkj.k dk fnukad] le;vkSj LFkku(
¼rhu½ vafre ernkrk lwph ds çn'kZu dk fnukad(
¼pkj½ uke&funsZ'ku i= nkf[ky djus dk fnukad] le; vkSj LFkku(
¼ik¡p½ uke&funsZ'ku i=ksa ds ifjfujh{k.k dk fnukad] le; vkSj LFkku(
¼N%½ uke&funsZ'ku i= okil ysus dk fnukad] le; vkSj LFkku(
¼lkr½ fuokZPku fpUg vkoafVr djus vkSj vafre uke&funsZ'ku çnf'kZr djus dk fnukad] le; vkSj LFkku(
¼vkB½ ernku dk fnukad] le; vkSj LFkku(
¼ukS½ og LFkku tgk¡ ernkrk }kjk ernkrk lwph dk fujh{k.k fd;k tk ldrk gS(
¼nl½ fuokZPku {ks=ksa ds uke] ftlesa vkjf{kr fuokZpu {ks= Hkh lfEefyr gS vkSj fuokZpu fd;s tkus okys
O;fä;ksa dh la[;k(
çfrcU/k ;g gS fd] Øekad&¼,d½ ls ¼vkB½ esa fnukad ,oa le; og gksxk] tks vk;ksx }kjk
fu/kkZfjr fd;k tk; rFkk Øekad&nl dh lwpuk ,oa LFkku og gksxk] tks ftyk lgk;d lgdkjh fuokZPku
vf/kdkjh@l{ke çkf/kdkjh }kjk fofuf'pr fd;k tk;A
34&fuokZPku ls lEc) lfefr dk lfpo@çcU/k funs'kd fu;e&12 ds v/khu jgrs gq, fuEufyf[kr
vk/kkj ij vufUre ernkrk lwph rS;kj djsxk&
¼,d½mu lfefr;ksa dh fLFkfr esa ftuds lkekU; fudk; esa vyx&vyx lnL; gksa] ;k mu lfefr;ksa dh
fLFkfr esa ftuds lkekU; fudk; esa vyx&vyx lnL;ksa ds çfrfuf/k gksa]
¼nks½ mu lfrfr;ksa dh fLFkfr esa] ftuds lkeU; fudk; esa vyx&vyx lnL; vkSj lfefr lnL;
lfEefyr gksa] vyx&vyx lnL;ksa dh ,d lwph rhu çfr;ksa esa rS;kj djk;sxk ftlesa mu fnukad

<!-- page 9 -->

dks tks vk;ksx }kjk fofufnZ"V fd;k tk;] lfefr dh iqfLrdkvksa esa vafdr uke] firk dk uke] irk]
vugZrk ;fn dksbZ gks] fn[kk;k tk;sxk] ftls vkxs vufUre lwph dgk x;k gS vkSj ;g lwph
fuEufyf[kr jhfr ls rS;kj dh tk;sxh%&
¼d½ çkjfEHkd d`f"k _.k lgdkjh lfefr;ksa] çkjfEHkd xUuk lfefr;ksa ,oa çkjfEHkd nqX/k lfefr;ksa dh
fLFkfr esa xzke iapk;r@jktLo xzkeokj]
¼[k½ uxj {ks= esa fLFkr çkjfEHkd lgdkjh lfefr;ksa ftlesa miHkksäk lgdkjh lfefr;k¡ Hkh gaS] esa
eksgYykokj@okMZokj vkSj uxj {ks= ls fHkUu {ks=ksa esa xzke iapk;rokj]
¼x½ vU; lfefr;ksa dh fLFkfr esa fuokZpu {ks=okj ;k lHkh lnL;ksa ds vuqikfrd Øekuqlkj@fuokZpu
{ks=okj ;k vU; fdlh rdZlaxr vk/kkj tSlk fd] vk;ksx }kjk fofuf'pr fd;k tk;s%
çfrcU/k ;g gS fd ,slh lgdkjh lfefr dh fLFkfr esa ftldh lnL; vU; lfefr;k¡ ;k [k.M&¼2½
ds vUrxZr vkus okyh lfefr;k¡ gks] ,slh lwph lfefr ds fuokZfpr çfrfuf/k;ksa ds uke ,oa irk lfgr] ;k
;fn fuokZfpr çfrfuf/k;ksa ds uke vufUre ernkrk lwph çdkf'kr gksus ds iwoZ çkIr u gks] rks orZeku
çfrfuf/k;ksa ds uke lfgr] fVIi.kh vafdr djrs gq, fuokZpu vf/kdkjh dks çLrqr dh tk;sxh%
vxzrj izfrcU/k ;g gS fd mRrj izns'k lgdkjh xzke fodkl cSad fy0] y[kuÅ dh 'kk[kkvksa ;k
,slh lfefr;ksa ftudk dk;Z{ks= ,d ls vf/kd jktLo ftys esa gks vkSj ftldh lnL;rk esa vyx&vyx
lnL; gksa] ,slh lwph] ;FkkfLFkfr] mi dk;kZy; ds izHkkjh ;k lEc) 'kk[kk ds 'kk[kk izcU/kd }kjk rS;kj
dh tk;sxh vkSj fuokZpu vf/kdkjh dks izLrqr dh tk;sxhA
¼3½ vufUre ernkrk lwph dks lfefr ds lfpo@çcU/k funs'kd] tSlh fLFkfr gks] }kjk gLrk{kj ,oa eqgj
vafdr djrs gq, fuokZpu vf/kdkjh dks ;Fkkle; miyC/k djk,xkA
35&fuokZpu vf/kdkjh mä vufUre ernkrk lwph dks fuokZpu dk;ZØe esa fu/kkZfjr frfFk ,oa le; ij
lfefr ds eq[;ky; ;k vko';drkuqlkj lfefr ds midk;kZy;@'kk[kkvksa ds dk;kZy; esa çnf'kZr
djsxkA
36&vfUre ernkrk lwph ds lEcU/k esa vkifÙk;k¡ ;fn dksbZ gks] fuokZpu vf/kdkjh }kjk fu;r fnukad]
le; vkSj LFkku ij lquk tk;sxk vkSj mldk fuLrkj.k djrs gq, vfUre ernkrk lwph rS;kj dh
tk,xhA
37&vfUre ernkrk lwph tks fuokZPku&{ks=okj] fuokZpu vf/kdkjh }kjk mä fuLrkj.k djrs gq, rS;kj dh
x;h Fkh] dks ml ij vius gLrk{kj vafdr djrs gq, mls fuokZpu LFky] lfefr ds eq[;ky; vkSj
vko';rkuqlkj lfefr ds midk;kZy; ;k 'kk[kk esa çnf'kZr fd;k tk;sxkA ernkrk lwph :0 nl çfr
i`"B vFkok vk;ksx }kjk le;&le; ij ;Fkk fu;r ewY; dk Hkqxrku djus ij fuokZpu vf/kdkjh
vFkok mlds }kjk çkf/kd`r vf/kdkjh ls lfefr ds eq[;ky;@'kk[kk ls çkIr dh tk ldsxhA
38&vfUre ernkrk dh lwph dh ,d çfr fuokZPku vf/kdkjh }kjk ftyk lgk;d fuokZpu
vf/kdkjh@l{ke çkf/kdkjh dks Hkh rRdky miyC/k djk;h tk;sxhA
39¼1½&dksbZ vH;FkhZ fuEufyf[kr Qhl nsdj uke&funsZ'ku çi= ¼çi=&V½ fuokZpu vf/kdkjh ls çkIRk dj
ldrk gS%&
¼d½ çkjfEHkd lgdkjh lfefr;ksa dh LFkfr esa%&
¼,d½ çcU/k desVh ds lnL; ds ukekadu gsrq&
¼nks½ lHkkifr@milHkkifr in ij ukekadu gsrq&
¼rhu½çfrfuf/k in ij ukekadu gsrq&

ik¡p lkS :i;s
,d gtkj :i;s
,d lkS :i;s

¼[k½ ftyk@dsUnzh; lgdkjh lfefr;ksa dh fLFkfr esa%&
¼,d½ çcU/k desVh ds lnL; ds ukekadu gsrq&

,d gtkj :i;s

<!-- page 10 -->

¼nks½ lHkkifr@milHkkifr in ij ukekadu gsrq&
¼rhu½ çfrfuf/k in ij ukekadu gsrq&

nks gtkj :i;s
ik¡p lkS :i;s

¼x½ jkT; Lrjh;@'kh"kZ lgdkjh lfefr;ksa dh fLFkfr esa%&
¼,d½ çcU/k desVh ds lnL; ds ukekadu gsrq&
nks gtkj :i;s
¼nks½ lHkkifr@milHkkifr in ij ukekadu gsrq&
ik¡p gtkj :i;s
¼rhu½çfrfuf/k in ij ukekadu gsrq&
,d gtkj :i;s
¼2½mifu;e ¼1½ esa fu/kkZfjr 'kqYd dh /kujkf'k] vk;ksx }kjk fu;r~ cSad [kkrs vFkok fuokZPku vf/kdkjh dks
vnk djds çiV ^V* ,oa lEcfU/kr 'kqYd dh jlhn vH;FkhZ }kjk çkIr dj ukekadu çi= mä jlhn
ds lkFk çLrqr fd;k tk,xkA
¼3½ lfefr ds fuokZPku vf/kdkjh dk ;g drZO; gksxk fd ukekadu 'kqYd ,ao vU; enksa esa çkIr /kujkf'k]
çR;sd n'kk esa fuokZpu ifj.kke ?kksf"kr gksus ds ,d lIrkg ds Hkhrj vk;ksx }kjk fu;r~ fd;s x;s cSad
[kkrk esa tek dj mldk fooj.k ,oa çek.k ftyk lgk;d fuokZpu vf/kdkjh@çkf/kd`r vf/kdkjh dk
miyC/k djk;sxkA
40&¼1½ fdlh Hkh O;fä dk uke funsZ'ku çi= lfefr dk fuokZpu vf/kdkjh Lohdkj ugha djsxk] ;fn og
O;fä&
d&ernku ds fy, ik= u gks(
[k&vf/kfu;e] fuokZpu fu;eksa ;k lfefr dh mifof/k;ksa ds micU/kksa ds v/khu vugZ
gks vFkok
vk;ksx }kjk fuokZPku ds fy, vugZ ?kksf"kr fd;k x;k gksA
¼2½ uke funsZ'ku ds fy, çLrko çi= ^^V** esa fuokZpu vf/kdkjh dks lEcksf/kr fd;k tk;sxkA
uke&funsZ'ku ds lEcU/k esa vkifÙk Hkh mls lEcksf/kr dh tk;sxh vkSj ,slh vkifÙk fdlh ernkrk }kjk
gh dh tk;sxhA
¼3½ mEehnokj viuk uke&funsZ'ku O;fäxr :i ls ;k vius çkf/kd`r vfHkdrkZ ds ek/;e ls fuokZPku
vf/kdkjh dks çLrqr djsxk vkSj fuokZPku vf/kdkjh }kjk mldh çfof"V ,d jftLVj esa] çR;sd n'kk esa
dkykuqØe esa dh tk;sxh vkSj og mldh çkfIr Hkh Lohdkj djsxk vkSj çi= ^^V** dh çkfIr jlhn
lEcfU/kr mEehnokj ;k mlds ukfer vfHkdrkZ dks miyC/k djk;h tk;sxh%
izfrcU/k ;g gS fd uke funsZ'ku dk izLrkod vkSj vuqeksnd mEehnokj ls fHkUu dksbZ vU; vgZ
ernkrk mlh fuokZpu {ks= dk gksxkA
¼4½ fuokZPku vf/kdkjh }kjk jftLVj esa fuEufyf[kr ckrsa mfYyf[kr dh tk;sxh%&
¼d½ mEehnokjksa dk uke] firk dk uke] irk(
¼[k½ çLrkod vkSj vuqeksnd dk uke] firk dk uke ,oa irk(
¼x½ uke&funsZ'ku i= çkIRk gksus dk fnukad] le; vkSj ml ij fuokZpu vf/kdkjh }kjk gLrk{kj fd;k
tk;sxkA
¼5½ fuokZPku vf/kdkjh] uke&funsZ'ku i= nkf[ky djus dk le; lekIr gks tkus ds i'pkr~ jftLVj esa
vfUre uke&funsZ'ku i= dh çfof"V ds uhps ,d iM+h js[kk [khapsxk] mlds uhps 'kCn ¼uke&funsZ'ku
lekIr½ fy[ksxk vkSj fnukad vkSj le; lfgr viu gLRkk{kj djsxkA uke&funsZ'ku dh ,d lwph]
le; lekIr gksus ds i'pkr~ ;Fkk'kh?kz] lfefr ds lwpuk iV ij iznf'kZr dh tk;sxhA
¼6½ fuokZPku vf/kdkjh uke&funsZ'ku i=ksa dh ifjfujh{kk dk dk;Z fofuZfn"V fnukad dks o.kZekyk Øe esa
djsxk vkSj mEehnokj@mldk çLrkod ;k vuqeksnd ifjfujh{kk ds le; mifLFkr jg ldrk gSA
¼7½ uke&funsZ'ku dh ifjfujh{kk djrs le; fuokZpu vf/kdkjh&
¼d½ uke&funsZ'ku i=ksa esa uke ;k la[;k ds lEcU/k esa fdlh fyfidh; Hkwy dks ernkrk lwph esa lekuqorhZ
çfof"V;ksa ds vuq:i djus ds fy, vuqKk ns ldrk gS(

<!-- page 11 -->

¼[k½ tgka vko';d gks] ogka ;g funsZ'k ns ldrk gS fd mä çfof"V;ksa esa fdlh eqnz.k lEcU/kh =qfV ij /;ku u
fn;k tk;A
¼8½ ifjfujh{kk ds le;] fuokZpu vf/kdkjh çR;sd uke&funsZ'ku i= ij mls Lohdkj djus ;k vLohdkj djus
ds lEcU/k esa fofu'p; i`"Bkafdr djsxkA vLohdkj fd;s tkus dh fLFkfr esa] og ,sls vLohdj.k ds fy,
vius dkj.kksa dk ,d laf{kIr fooj.k vfHkfyf[kr djsxkA ftl mEehnokj dk uke funsZ'ku vLohdkj fd;k
tk;] og 10 :i;s dh Qhl fuokZPku vf/kdkjh ds ikl udn tek dj] vLohdj.k vkns'k dh ,d çfr
çkIr dj ldrk gSA
¼9½ uke&funsZ'ku okil ysus ds fy, vkosnu i= fu;r çi= esa dsoy lEc) mEehnokj }kjk O;fäxr :i ls
fuokZpu vf/kdkjh dks fn;k tk;sxkA
¼10½ tgka fuokZfpr vf/kdkjh uke&funsZ'ku okil ysus ds i'pkr~ uke&funsZ'ku dks vfUre :i ns ns] ogka ij
vk;ksx }kjk vuqeksfnr fpUgksa dh lwph ls ,d fpUg@fPkUgksa ds mlh Øe esa ftl Øe esa og vuqeksfnr
lwph esa bafxr fd;k x;k gS] çR;sd fof/kekU; uke&funsZ'ku ds fy, vkoafVr djsxk vkSj ;fn fof/kekU;
uke&funsZ'ku dh la[;k vk;ksx }kjk vuqeksfnr fpUgksa dh la[;k ls vf/kd gks rks fuokZPku vf/kdkjh dksbZ
vU; fpUg vkoafVr dj ldrk gS] tks vk;ksx }kjk vuqeksfnr fpUgksa ls fHkUu] fdUrq mlls lkE; j[krk
gksA bl çdkj vkoafVr fpUg lEc) mEehnokj ds fy, cU/kudkjh gksxkA
¼11½vfUre uke&funsZ'kuksa dh lwph] ftlesa mEehnokjksa ds uke] firk dk uke muds vius&vius fpUg vkSj
uke&funsZ'ku i=ksa esa fn;s x;s irksa lfgr fgUnh o.kZekyk Øe esa fn;s x;s gksaxs] fu/kkZfjr dk;ZØe ij
fu;e 36 esa fofgr jhfr ls çnf'kZr dh tk;sxhA
41&çR;sd ernku xqIr eri= }kjk gksxk vkSj çR;sd vf/kdkjh] deZpkjh ;k dksbZ O;fä ftls ernku djkus
ds fy, ;k eri=ksa dh x.kuk ds fy, fu;qä fd;k x;k gks] ,slh dksbZ lwpuk fdlh ,sls O;fä ;k
O;fä;ksa dks tks bls çkIr djus ds fy, fof/kd :i ls vf/kd`r u gks] ugha nsxk ;k ,slk dksbZ d`R; ugha
djsxk] ftlls ernku dh xksiuh;rk çHkkfor gksrh gksA
42&dksbZ O;fä tks fuokZpu vf/kdkjh gS] ;k fuokZpu djkus ds fy, fu;qä fd;k x;k gS ;k fdlh lfefr dk
dksbZ vf/kdkjh ;k dksbZ iqfyl vf/kdkjh] ftls fuokZpu ds lapkyu esa lgk;rk djus ds fy, fu;qä fd;k
x;k gS] fuokZPku dh çfØ;k ds nkSjku ,slk dksbZ d`R; ugha djsxk] ;k fdlh ernkrk ;k vH;FkhZ dks bl
çdkj çHkkfor ugh djsxk] ftlls fdlh mEehnokj ds fuokZpu esa lQy gksus dh lEHkkouk esa o`f) ;k
gzkl gksrk gksA
43&¼1½ tgka fof/kekU; uke&funsZ'kuksa dh la[;k fuokZfpr fd;s tkus okys O;fä;ksa dh la[;k ds cjkcj ;k
vf/kd u gks] ogka fuokZpu vf/kdkjh] uke okilh ds i'pkr~ rRdky mlh fnukad dks mUgs lE;d~
:i ls fuokZfpr ?kksf"kr djsxk%
¼2½ tgka fof/kekU; uke&funsZ'kuksa dh la[;k fuokZfpr fd;s tkus okys O;fä;ksa dh la[;k ls vf/kd gks]
og fuokZpu vf/kdkjh fu;r~ le; ,oa fnukad dks ernku djkus dk çcU/k djsxkA
¼3½ çR;sd ernkrk dks ,d 'kykdk i= fn;k tk;sxk] tks vk;ksx ds }kjk eqfnzr gksxk] ftlij fgUnh
o.kkZuqØe ds vuqlkj fuokZpu yM+us okys mEehnokjksa dks vkoafVr pquko fpUg eqfnzr gksxkA blesa ,d
[kkyh LrEHk ernkrk }kjk ml O;fä ;k mu O;fä;ksa ds uke ds lkeus] ftUgsa og ernku djuk
pkgs] ,d fpUg (X)vafdr djus ds fy, Hkh gksxkA
¼4½ 'kykdk&i= Øekafdr gksaxs vkSj mu ij lfefr dh eksgj vkSj lEc) ernku dsUnz ds fuokZpu
vf/kdkjh@ernku vf/kdkjh ds gLRkk{kj Hkh gksaxsA
¼5½ ernku xqIr 'kykdk i= }kjk gksxkA ernkrk ml mEehnokj ds uke ds lkeus] ftls og ernku
djuk pkgrk gS] ,d Økl dk fpUg (X)yxk;sxk vkSj rn~mijkUr 'kykdk i= dks xqIr :i esa
'kykdk isVh esa Mku nsxkA
¼6½ çR;sd ernkrk ds mrus er gksaxs] ftrus O;fä;ksa dk fuokZpu fd;k tkuk gS fdUrq dksbZ ernkrk
fdlh ,d mEehnokj dks ,d ls vf/kd er ugh nsxkA

<!-- page 12 -->

¼7½ fuokZpu yM+us okyk dksbZ mEehnokj ;k mldk çkf/kd`r vfHkdrkZ 'kykdk i= tkjh fd;s tku ds iwoZ
fuokZpu vf/kdkjh dks çR;sd vkifÙk ds fy, nl :i;s dh Qhl nsdj ernkrk ds vfHkKku ds
lEcU/k esa vkifÙk dj ldrk gSA
¼8½ fuokZpu vf/kdkjh vkifÙk dh laf{kIrr% tk¡p djsxk vkSj ;fn ,slh tk¡p ds i'pkr~ mldh ;g jk;
gks fd vkifÙk çekf.kr ugh gksrh gS] rks og vkifÙkd`r O;fä dks 'kykdk i= nsxk ftlds i`"B ij
fuokZpu vf/kdkjh viuh gLrfyfi esa 'kCn ^^vkifÙkd`r er**i`"Bkafdr djsxk vkSj gLrk{kj djsxkA
¼9½ ,slk çR;sd O;fä] mifu;e ¼3½ ds v/khu 'kykdk i= fn;s tkus ds iwoZ fofufnZ"V çi= esa ,d lwph
esa vius ls lEcfU/kr çfof"V ds lkeus viuk gLrk{kj djsxk ;k ;fn fuj{kj gks rks og vius vaxwBs
dk fu'kku yxk;sxkA
¼10½ mifu;e ¼8½ ds v/khu 'kykdk i= çkIr gksus ij lEc) O;fä 'kykdk i= ij ml mEehnokj ds
uke ds lkeus] ftls og er nsuk pkgrk gS] xqIr :i ls Økl dk fpUg (X) yxkdj viuk er
vfHkfyf[kr djsxk vkSj 'kkykdk i= fuokZPku vf/kdkjh dks nsxk tks mls rqjUr bl ç;kstuksa ds
fy, fo'ks"k :i ls j[ks x, fyQkQs esa j[ksxkA
¼11½ ;fn dksbZ ,slk O;fä tks Lo;a dks ernkrk lwph esa fn;s x;s fdlh fof'k"V ernkrk :i esa crk;s]
,sls ernkrk ds :i esa] nwljs O;fä }kjk igys ls gh er nsus ds i'pkr~] 'kykdk i= ds fy,
vkosnu djrk gS] rks mls fuokZkpu vf/kdkjh dks vius igpku ds lEc) esa lek/kku djus ds
i'pkr~ ,d 'kykdk i= fn;k tk;sxk] ftlds i`"B Hkkx ij fuokZpu vf/kdkjh }kjk viuh gLRkfyfi
esa 'kCn ^^fufonÙk 'kykdk i=** i`"Bkafdr fd;k tk;sxk vkSj gLrk{kj fd;k tk;sxkA
¼12½ çR;sd ,slk O;fä] fufonÙk 'kkykdk i= fn, tkus ds iwoZ fofufnZ"V çi= esa ,d lwph esa vius ls
lEcfU/kr çfof"V ds lkeus viuk gLRkk{kj djsxk ;k ;fn og fuj{kj gks rks og vius vaxwBs dk
fu'kku yxk;sxkA
¼13½ mifu;e 11 ds v/khu 'kykdk i= çkIr gksus ij og O;fä 'kykdk i= ij ml mEehnokj ds uke
ds lkeus] ftls og er nsuk pkgrk gS] xqIr :i ls Økl dk fpUg (X) yxkdj viuk er
vfHkfyf[kr djsxk vkSj fufonÙk 'kykdk i= fuokZpu vf/kdkjh dks nsxk tks mls rqjUr bl ç;kstu
ds fy, fo'ks"k :i ls j[ks x, fyQkQs esa j[ksxkA
¼14½ ernku djus okys ernkrk dks vius er dks ç;ksx fd;s tkus ds iwoZ vk;ksx }kjk fufnZ"V igpku
i=ksa esa ls fdlh ,d igpku i= ls fuokZpu vf/kdkjh dks vius igpku ds lEcU/k esa lUrq"V fd;k
tkuk vfuok;Z gksxkA
¼15½ ;fn gLrk{kfjr eri= cp tkrk gS rks mls ,d vyx fyQkQs esa j[kk tk;sxk vkSj ernku ds
i'pkr~ fu/kkZfjr çk:i ij ç;ksx fd;s x;s eri=] gLrk{kfjr 'ks"k eri=] 'ks"k lkns eri= vkfn
dh lwpuk Hkjdj fyQkQs esa j[kk tk;sxkA
¼16½ fuokZpu vf/kdkjh }kjk Mk;jh 'kkfUriw.kZ <ax ls fuokZpu lEiUu gksus dh fLFkfr esa fVIi.kh vafdr
djrs gq, Mk;jh dks vyx fyQkQs esa vyx j[kk tk;sxkA mä Mk;jh dks fuokZpu ifj.kke ?kksf"kr
gksus ds i'pkr~ lEcfU/kr vfHkys[kksa ds lkFk lqjf{kr vfHkj{kk esa fu/kkZfjr vof/k rd j[kk tk;sxkA
44&¼1½¼d½ ernku lekIr gksus ds i'pkr~ rqjUr erksa dh x.kuk dh tk;sxh vkSj ;fn ernku lekIr gksus
ds i'pkr~ rqjUr erx.kuk djuk lEHko u gks rks] er isfV;k¡ fuokZpu vf/kdkjh }kjk eksgj cUn dj
nh tk;sxh vkSj fudVLFk iqfyl Fkkus esa fujkin vfHkj{kk esa j[kh tk;sxhA mEehnokj ;k mldk
vfHkdrkZ Hkh viuh eksgj] ;fn ,slk pkgs] yxk ldrk gSA
¼[k½fufonÙk er ,oa vkifÙkd`r er dh x.kuk mUgha ifjfLFkfr;ksa esa dh tk;sxh tc dqy iM+s erksa ls
ifj.kke ?kksf"kr fd;k tkuk lEHko u gks vFkkZr~ fdUgh nks ;k vf/kd mEehnokjksa ds erks dh la[;k
cjkcj gks tk;sA
¼2½ dksbZ 'kykdk&i= vLohdkj dj fn;k tk;sxk] ;fn&
¼1½ ml ij ernkrk dh igpku ds fy, dksbZ gLRkk{kj gks]

<!-- page 13 -->

¼2½ ml lfefr dh eksgj vkSj lEc) ernku dsUnz ds fuokZpu vf/kdkjh@ernku vf/kdkjh dk gLrk{kj
u gks]
¼3½ ml ij ernku bafxr djus dk dksbZ fpUg u gks]
¼4½ ml ij Hkjs tkus okys LFkku@LFkkuksa dh la[;k ls vf/kd fpUg gks]
¼3½ ;fn fdlh 'kykdk&i= in mEehnokj ;k mEehnokjksa ds fy, fpUg bl çdkj gks ftlls ;g Li"V u
gks fd fdu mEehnokjksa dks er fn;k x;k gS rks mls vLohdkj dj fn;k tk;sxkA
¼4½ fuokZpu&vf/kdkjh] x.kuk iwjh gks tkus ds i'pkr~ ;Fkk'kh?kz] çR;sd mEehnokj }kjk çkIr erks dh
la[;k crkrs gq, fuokZpu ifj.kke dh ?kks"k.kk djsxkA
¼5½ cjkcj&cjkcj er gksus dh fLFkfr esa ekeys dk fofu'p; ipkZ Mkydj fd;k tk;sxkA
Li"Vhdj.k&fuokZpu vf/kdkjh }kjk leku jax ,oa vkdkj dh iphZ ij mEehnokjksa ds uke fy[kdj
rFkk iPkhZ dks bl çdkj eksM+dj dh mEehnokj dk uke i<+k u tk lds] 'kykdk i= isVh esa Mkysxk vkSj
mEehnokj ls fHkUuk fdlh vU; O;fä ls isVh ls ,d iphZ fudyok;sxkA ml iphZ ij vafdr uke okys
mEehnokj dks fot;h ?kksf"kr fd;k tk,xkA
¼6½ fuokpZu&vf/kdkjh] fuokZfpr mEehnokjksa dh lwph lfefr ds lwpuk iÍ ij vkSj ,sls lkoZtfud LFkku
ij Hkh tgka og mfpr le>s] çnf'kZr djsxk%
çfrcU/k ;g gS fd mÙkj çns'k lgdkjh xzke fodkl cSad fy0] y[kuÅ dh 'kk[kkvksa ;k ,slh
lfefr;ksa dh fLFkfr esa ftudk dk;Z{ks= ,d ls vf/kd ftys esa gks] lwph dk çn'kZu ,slh lgdkjh lfefr
ds 'kk[kk dk;kZy; ;k mi dk;kZy; esa fd;k tk;sxkA
¼7½ mifu;e ¼6½ ds v/khu rS;kj dh xbZ lwph dh ,d çfrfyfi ftyk lgk;d lgdkjh fuokZpu
vf/kdkjh] vk;ksx ;k lEcfU/kr lgdkjh lfefr ds lfpo@çcU/k funs'kd }kjk çkf/kd`r fdlh
vf/kdkjh dks Hksth tk;sxhA
¼8½ fuokZpu lEcU/kh ç;qä “kykdk i= vkSj vU; vfHkys[k fdlh fyQkQs ;k vk/kku ¼dUVsuj½ esa j[ks
tk;saxs vkSj fuokZPku vf/kdkjh@ernku vf/kdkjh mUgas lfefr ds lfpo@çcU/k funs'kd dks Hkst
nsxk] tks mldh çkfIr Lohdkj djsxk vkSj ;fn fuokZpu ds lEcU/k esa dksbZ fookn ftyk eftLVªsV
vFkok vk;ksx dks fufnZ"V u fd;k tk; rks nks ekg rd mldh vfHkj{kk ds fy, mÙkjnk;h gksxk]
çfrcU/k ;g gS fd fdlh fuokZpu okn vFkok fdlh U;k;ky; esa fuokZpu ;kfpdk ds yfEcr
u jgus dh fLFkfr esa lfefr ds lfpo ;k çcU/k funs'kd] tSlh Hkh fLFkfr gks] ds }kjk ,d o"kZ O;rhr
gks tkus ij ml u"V dj fn;k tk;sxkA
vxzrj çfrcU/k ;g gS fd lfpo ;k çcU/k funs'kd] tSlh Hkh fLFkfr gks] dk ;g mÙkjnkf;Ro
gksxk fd vfHkys[kksa dks u"V fd;s tkus ds iwoZ vk;ksx }kjk fofgr çk:i ij mldk laf{kIr fooj.k
vafdr djs vkSj mls lgdkjh lfefr esa j[kk tk;sxkA
¼9½ fo'ks"k ifjfLFkfr;ksa ,oa vifjgk;Z dkj.kksa esa vk;ksx tuin dh lHkh vFkok fdlh oxZ ;k oxksZ ;k fdlh
fof'k"V lfefr dh er x.kuk vU; LFkku ij djkus ds funsZ'k ns Lkdrk gS vkSj ,slh erx.kuk
vk;ksx }kjk ;Fkk fu;r fnukad dks gh djk;h tk,xhA

<!-- page 14 -->

v/;k;&5
lHkkifr@milHkkifr ,oa vU; lfefr;ksa dks Hksts tkus okys izfrfuf/k;ksa dk fuokZpu
Š45&¼1½ lEcfU/kr lgdkjh lfefr dh izcU/k desVh ds lnL;ksa ds fuokZpu ifj.kke dh
?kks"k.kk ds Ik'pkr~ lHkkifr@milHkkifr ,oa vU; lfefr;ksa dks Hksts tkus okys
izfrfuf/k;ksa dk fuokZpu]fofufnZ"V vuqns'kksa vkSj fofufnZ"V fnukad ds v/khu djk;k
tk;sxk] ftldh lEiw.kZ izfØ;k ,slh gksxh] tSlk Åij mfYyf[kr fu;eksa esa micfU/kr dh
x;h gSA
¼2½ lHkkifr ,oa milHkkifr] izcU/k desVh ds fuokZfpr lnL;ksa esa ls fuokZfpr fd;s tk;saxsA
¼3½ izcU/k desVh ds lnL; vU; lgdkjh lfefr ds] ftldh og lgdkjh lfefr lnL; gks]
lkekU; fudk; esa lgdkjh lfefr dk izfrfuf/kRo djus ds fy, izfrfuf/k;ksa dk fuokZpu
lkekU; fudk; ds vgZ lnL;ksa esa ls djsaxsA
dk;Zdky%&
46&¼1½ izR;sd lgdkjh lfefr dh izcU/k desVh dk dk;Z dky 5 o"kZ gksxk] ftldh x.kuk
mlds dk;ZHkkj xzg.k djus dh frfFk ls dh tk;sxhA
Li"Vhdj.k&izcU/k desVh dk dk;Zdky lekIr gksus ds iwoZ fdlh lgdkjh lfefr dk
fuokZpu gksus dh n'kk esa uofuokZfpr izcU/k desVh dk dk;ZHkkj fuorZeku izcU/k desVh ds
dk;Zdky lekIr gksus ds Ik'pkr~ izcU/k desVh dk fuokZpu gksus dh fLFkfr esa izcU/k desVh
dk fuokZpu ifj.kke ?kksf"kr gksus ds fnol ls dk;Zdky dh x.kuk gksxhA
¼2½ lHkkifr@milHkkifr dk dk;Zdky izcU/k desVh ds dk;Zdky ds lgfOkLrkjh gksxkA
¼3½ lg;ksftr lnL; dk dk;Zdky izcU/k desVh ds dk;Zdky ds lgfoLrkjh gksxkA
izfrcU/k ;g gS fd ;fn izcU/k desVh dk dk;Zdky mlds ekSfyd dk;Zdky ds vk/ks
ls de gks rks izcU/k desVh esa gqbZ fdlh vkdfLed fjfä dh iwfrZ ml lgdkjh lfefr ds
vgZ lnL;ksa esa ls ftlesa vkdfLed fjfä gqbZ gS] izcU/k desVh }kjk uke&funsZ'ku }kjk dh
tk ldrh gSA
Š 'kklukns'k la[;k&662@49&01&2017&8¼56½&13 Vhlh&1]y[kuÅ] 26 ebZ] 2017

<!-- page 15 -->

v/;k;&6
vugZRkk
47&¼1½ dksbZ Hkh O;fä fdlh lgdkjh lfefr dh izcU/k desVh dk lnL; gksus ;k cus jgus
dk ik= u gksxk] ;fn&
¼d½ mldh vk;q 21 o"kZ ls de gks(
¼[k½ og fnokfy;k ?kksf"kr gks(
¼x½ og fod`r fpÙk dk gks(
¼?k½ mls] vk;ksx dh jk; esa uSfrd iru ls lEcfU/kr vijk/k ds fy, nks"kh Bgjk;k x;k gks
vkSj ,slh nks"k flf) vihy esa jn~n u dh x;h gksa(
¼³½ og ;g vk;ksx dh jk; esa] mlds ifjokj dk dksbZ lnL; fucU/kd dh vuqKk ds fcuk]
lgdkjh lfefr ds dk;Z{ks= ds Hkhrj mlh izdkj dk dkjksckj djuk 'kq: djs ;k djrk
gks] tSlk lgdkjh lfefr }kjk Lo;a fd;k tk jgk gks(
¼p½ og vf/kfu;e ;k lgdkjh lfefr dh mifof/k;ksa ds micU/kksa ds izfrdwy lgdkjh lfefr
ds lkFk dksbZ O;ogkj ;k lafonk djs(
¼N½ og lgdkjh lfefr ds v/khu ;k fdlh vU; lgdkjh lfefr tks ,slh lfefr ls lEc)
gks] ds v/khu ;k dksbZ ykHk dk in Lohdkj djs ;k /kkj.k djrk gks(
izfrcU/k ;g gS fd] ;g izfrcU/k ,sls mRikndksa ;k deZdkjksa dh lfefr;ksa ij ykxw
ugha gksxk] ftudks jkT; ljdkj us vuqKk ns nh gks fd os viuh mifof/k;ksa esa deZpkfj;ksa
}kjk lgdkjh lfefr ds izcU/k esa Hkkx ysus dh O;oLFkk dj ldrs gS(
¼t½ og lgdkjh lfefr ds lkekU; fudk; dk lnL; u gks(
izfrcU/k ;g gS fd] bl [k.M ds micU/k vf/kfu;e dh /kkjk 29 dh mi/kkjk ¼6½ ,oa
¼8½ ds vUrxZr vkus okys o`fRrd O;fä;ksa ds lg;kstu ij ykxw u gksaxs(
¼>½ og vf/kfu;e ;k fu;eksa ds v/khu fdlh vijk/k ds fy, nks"kh fl) fd;k x;k gks] tc
rd fd nks"k flf) ds fnukad ls rhu o"kZ dh vof/k O;rhr u gks x;h gks(
¼¥½ og ,slk O;fä gks] ftlds fo:) fdlh lgdkjh lfefr ds vf/kfu;e dh /kkjk 91 ds
v/khu vkns'k izkIr dj fy;k gks vkSj ml vkns'k dh iwfrZ u gqbZ gks(
¼V½ og vius }kjk fy;s x;s _.kksa ds lEcU/k esa lgdkjh lfefr dk ¼de ls de 6 ekl dh
vof/k ls½ ckdhnkj gks] ;k og lgdkjh lfefr dk vf/k&fu.khZr _.kh gks(
¼B½ og ,d gh le; esa rhu lgdkjh lfefr;ksa vFkkZr~ ,d izkFkfed ,d dsUnzh; vkSj ,d
'kh"kZ lgdkjh lfefr dh izcU/k desVh dk igys ls gh lnL; gks] fQj Hkh og rhu ls
vf/kd lgdkjh lfefr;ksa dh izcU/k desVh dh lnL;rk ds fy, pquko yM+us ds fy,
gdnkj gksxkA Åij fofufnZ"V rhu ls vf/kd lfefr;ksa dh izcU/k desVh esa mlds
fuokZfpr gksus dh n'kk esa mls ,d ekg ds Hkhrj ,slh lfefr ;k lfefr;ksa dh izcU/k
desVh ls R;kxi= nsuk iM+sxk rkfd og rhu ls vf/kd lfefr;ksa dh izcU/k desVh dk
lnL; u cuk jg ldsA ;fn og fofufnZ"V vof/k ds Hkhrj R;kxi= nsus essa foQy jgrk
gS rks ,slh vof/k dh lekfIr ij ;g le>k tk;sxk fd mlus ,d 'kh"kZ lgdkjh lfefr
vkSj ,d dsUnh; lgkdjh lfefr vkSj ,d izkFkfed lgdkjh lfefr] ftl ij og ckn
esa fuokZfpr gqvk gS] ds flok; leLr lgdkjh lfefr ls R;kxi= ns fn;k gS(

<!-- page 16 -->

¼M½ og jktdh; lsok ;k fdlh lgdkjh lfefr dh lsok ;k fuxfer fudk; ls diV]
nqjkpj.k ;k v'kqfprk djus ds fy, inP;qr fd;k x;k gks vkSj inP;qfr dk ,slk vkns'k
vihy esa jn~n u fd;k x;k gks(
¼<+½ og ,slh fdlh lgdkjh lfefr ds fucU/ku ds izkFkZuki= esa lfEefyr gks ;k mldh
izcU/k desVh dk lnL; jgk gks] tks fucU/kd }kjk /kkjk 72 dh mi/kkjk ¼2½ ds [k.M
¼d½ ds v/khu bl vk/kkj ij lekfIkr dj nh x;h gks fd lgdkjh lfefr dk] fucU/ku
diViwoZd djk;k x;k Fkk vkSj fucU/kd dk ,slk vkns'k vihy esa mRØfer u fd;k
x;k gks(
¼.k½ og vf/kfu;e ;k fu;e ;k lgdkjh lfefr dh mifof/k;ksa ds fdlh micU/k ds v/khu
vU;Fkk vugZ gks(
¼r½ ;fn og fdlh xSj _.k lgdkjh lfefr] tks dsUnzh; lgdkjh cSad vFkok m0iz0
dksvkijsfVo cSad dk izfrfuf/k gS vkSj og lgdkjh lfefr 90 fnuksa ls vf/kd dh
cdk;snkj gS(
¼Fk½ ;fn og izkjfEHkd d`f"k _.k lgdkjh lfefr esa dsoy tek djus ds mn~ns'; ls lnL;
cuk gks vkSj mlds }kjk ,slh lfefr esa tek /kujkf'k ,d gtkj :Ik;s ls de gks x;h
gks(
¼n½ vk;ksx dh jk; esa fdlh O;fä }kjk fuokZpu esa Hkz"V vkpj.k vFkok tkucw> dj dksbZ
diViw.kZ d`R; vFkok dwV jfpr vfHkys[k ds vk/kkj ij fuokZpu esa Hkkx fy;k x;k gks]
ftlds izHkko esa mldh mEEkhnokjh ,oa mlds ifj.kke ij izHkko iM+k gks(
¼/k½ ;fn mls fdlh vijk/k ds fy, fdlh U;k;ky; ls nks o"kZ ls vf/kd dk dkjkokl gqvk
gks vkSj ftlds fo:) dksbZ LFkxukns'k izkIr u fd;k x;k gks ;k fdlh l{ke U;k;ky;
}kjk vkns'k dks vikLr u fd;k x;k gks(
Š¼u½ og fdlh lgdkjh cSad dk iwoZ dkfeZd gks]
izfrcU/k ;g gS fd ;g [k.M] [k.M ¼i½ esa mfYYkf[kr 16 ftyk lgdkjh cSadksa dh
izcU/k desVh ds lEcU/k esa ykxw gksxk]
¼i½ ;g ykblsUl gsrq foÙkh; lgk;rk@vuqnku@va'kiWwth@_.k izkIr fuEufyf[kr 16 ftyk
lgdkjh cSad dh izcU/k desVh ds fuokZpu ds iwoZorhZ 10 o"kZ iwoZ rd dh vof/k esa cSad
dh izcU/k desVh dk lnL; jgk gks%&
ftyk lgdkjh cSad fy0] nsofj;k] cgjkbp] fl}kFkZuxj] lqYrkuiqj] tkSuiqj] xksj[kiqj]
vktex<+] cfy;k] cLrh] gjnksbZ] Qrsgiqj] lhrkiqj] okjk.klh] bykgkckn] xkthiqj ,oa
QStkcknA
Š 'kklukns'k la[;k&859@49&01&2016&8¼56½&13 Vhlh&1]y[kuÅ] 31 ebZ] 2016

<!-- page 17 -->

¼2½ fdlh lgdkjh lfefr dh izcU/k desVh dk dksbZ lnL;] tks izcU/k desVh dh rhu
yxkrkj cSBdksa esa fcuk fdlh mfpr dkj.k ds vuqifLFkr jgs] izcU/k desVh dk lnL;
cus jgus dk gdnkj u gksxkA
¼3½ mifu;e ¼2½ ds micU/k fdlh lgdkjh lfefr dh izcU/k desVh ds uke&fufnZ"V ;k
insu lnL; ij ykxw ugha gksxsa(
¼4½ dksbZ O;fä tks fdlh lgdkjh lfefr dh izcU/k desVh dh lnL;rk ds fy, fuokZpu
yM+s fdUrq ,sls fuokZpu esa gkj tk;] vkesyu ;k uke&funsZ'ku }kjk izcU/k desVh dk
lnL; gksus ds fy, ik= u gksxkA
¼5½ mifu;e ¼1½ ds v/khu fu/kkZfjr vugZrk,a fuEufyf[kr 'krksZa ds v/khu ykxw gksaxh(
¼d½[k.M t esa fu/kkZfjr vugZrk,a izcU/k desVh ds fdlh uke&fufnZ"V ;k insu lnL; ;k
izcU/k desVh ds ,sls lg;ksftr lnL; ij ykxw u gksaxh ftlds lg;kstu gsrq lgdkjh
lfefr dh mifof/k;ksa ds v/khu lkekU; fudk; dh lnL;rk dksbZ 'krZ ugha Fkh(
¼[k½mifu;e ¼1½ ds [k.M ¼?k½ ;k [k.M ¼M½ esa fu/kkZfjr vugZrk nks"k flf) ds v/khu]
vFkZn.M nsus ;k nks"k fl) gksus ij n.M ik ysus ds ;k inP;qfr ds vkns'k ds ckn] tSlh
Hkh fLFkfr gks] 5 o"kZ dh lekfIr ds Ik'pkr~ lekIr gks tk;sxh(
¼x½ mifu;e ¼1½ ds [k.M ¼[k½ esa nh x;h gqbZ vugZrk fdlh ,sls ljdkjh deZpkjh ij ykxw
u gksxh] ftldks /kkjk 34 ds vUrxZr fdlh lgdkjh lfefr dh izcU/k desVh esa
ukekafdr fd;k x;k gks(
¼?k½ dkjkxkj ds cfUn;ksa ds dY;k.k ,oa iquokZl ds fy, tsy esa cuh lgdkjh lfefr;ksa dh
izcU/k desVh ds lnL;ksa ds lEcU/k esa fu;e 47 ds mifu;e ¼1½ dk mi[k.M ¼d½] ¼N½]
¼>½] ¼M½] o ¼/k½ ykxw ugha gksaxs(
48&fdlh lgdkjh lfefr dh izcU/k desVh dk ;g drZO; gksxk fd ,slk dksbZ O;fä tks
fdlh Hkh izdkj vugZ gks tk;] izcU/k desVh dk lnL; dk in /kkj.k u fd;s jgsA T;ksa
gh ;g rF; izcU/k desVh dhtkudkjh esa vk;s] fd dksbZ lnL; fdlh izdkj vugZ gks
x;k gS] pkgs og ,sls lnL; ds iwoZ ;k mlds Ik'pkr~ vugZ gqvk gks] desVh bl fo"k;
ij ,d cSBd esa fopkj djsxh] tks bl iz;kstu ds fy, cqykbZ tk;sxhA ,slh cSBd dh
dk;Zlwph dh ,d izfr ml lnL; dks] ftlds fo:) dkjZokbZ djus dk izLrko gks]
O;fDrxr :Ik ls ;k jftLVªh Mkd }kjk ¼izkIr vfHkLohd`fr½ nh tk;sxhA ;fn lEcfU/kr
O;fä dks ,slh vugZrk ds dkj.k desVh dh lnL;rk ls gVkus dk ladYi ikfjr gks
tk;s rks ,sls LkadYi dh ,d izfr Hkh lEcfU/kr O;fDr dks jftLVªh Mkd }kjk ¼izkIr
vfHkLohd`fr½ Hksth tk;sxh vkSj rn~mijkUr ,sls lnL; dks fdlh vU; izdkj ls izcU/k
desVh ds lnL; ds :Ik esa izcU/k desVh dh fdlh cSBd esa dk;Z djus ;k mifLFkfr
gksus dh vuqKk ugha nh tk;sxhA ,sls lnL; dk in fjDr ?kksf"kr fd;k tk;sxkA ;fn
og O;fDr ,slh dk;Zokgh ls {kqC/k gks rks og uksfVl izkIr gksus ds fnukad ls 30 fnu ds
Hkhrj vf/kfu;e rFkk fu;eksa ds micU/kksa ds v/khu iapfu.kZ; djk ldrk gSA
49&¼1½ ;fn fdlh lnL; ;k lnL;ksa dh vuZgrk lEcU/k esa laKku esa vkus ij izcU/k desVh
}kjk ;Fkk&fu;r~ dk;Zokgh ;qfDRklaxr le; ij ugha dh tkrh gS] rks vk;ksx dks ;g

<!-- page 18 -->

vf/kdkj gksxk fd vf/kfu;e dh /kkjk ¼38½ ds v/khu ,sls vugZ lnL; ;k lnL;ksa dh izcU/k
lfefr ls fudkys tkus ds fy, fucU/kd vFkok izkf/kd`r vf/kdkjh dks funsZf'kr dj ldrk gSA
¼2½ vk;ksx ,sls funsZ'ku ds Ik'pkr~ fucU/kd vFkok izkf/kd`r vf/kdkjh dk ;g drZO; gksxk fd /kkjk 38 esa
fofgr izfØ;k dk ikyu djus ds fy, ;Fkk vko';d dk;Zokgh djsxkA
v/;k;&7
fuokZpu okn
50&¼1½ fdlh lgdkjh lfefr ds fdlh inkf/kdkjh ;k izfrfuf/k ds fuokZpuls {kqC/k i{kdkjksa }kjk
vf/kfu;e dh /kkjk 70 ds v/khu fuokZpu okn izLrqr fd;k tk ldrk gS&tks fuEukuqlkj vfHkfn"V
fd;k tk;sxk&
¼d½ izkjfEHkd ,oa dsUnzh;@tuin Lrjh; lfefr;ksa dh n'kk esa lEcfU/kr ftyk eftLVsªV dks tks
izkjfEHkd lgkdjh lfefr dh n'kk esa fookn dk fu.kZ; Lo;a dj ldrk gS vFkok vius v/khu
ijxukf/kdkfj;ksa esa ls fdlh ,d dks] ;FkkfLFkfr] e/;LFk vFkok e/;LFk e.My ds v/;{k ds :i esa dk;Z
djus ds fy, fu;qä dj ldrk gS vkSj dsUnzh; lgdkjh lfefr;ksa dh n'kk esa ftyk eftLVªsV fookn dk
fu.kZ; Lo;a dj ldrk gS vFkok vius v/khu vij ftykf/kdkjh esa ls fdlh ,d dks] ;FkkfLFkfr] e/;LFk
vFkok e/;LFk e.My ds v/;{k ds :i esa dk;Z djus ds fy, fu;qä dj ldrk gSA
¼[k½ fdlh jkT; Lrjh;@'kh"kZ lgdkjh lfefr dh n'kk esa vk;ksx dks fd;k tk;sxk] tks fookn
dk fu.kZ; Lo;a vFkok fdlh fuokZpu vk;qä dks e/;LFk ;k e/;LFk e.My ds v/;{k ds :i esa fu;qä
dj ldrk gSA
¼2½ fdlh lgdkjh lfefr ds fuokZpu ds lEcU/k esa flok; fuEufyf[kr vk/kkj ds e/;LFk }kjk ;k vU;Fkk
:i ls vkifÙk ugha dh tk ldsxh&
¼d½ fuokZpu esa Hkz"Vkpkj] fj'or~ ;k vuqfpr izHkko dk iz;ksx gksus ds dkj.k og fuokZpu fu"i{k
ugha gqvk gS];k
¼[k½ fuokZpu ds ifj.kke ij fuEufyf[kr dkj.kksa ls lkjoku~~ izHkko iM+k gks%&
¼1½
fdlh uke&funsZ'ku i= dks vuqfpr :i ls Lohdkj djus] ;k vLohdkj djus ds }kjk] ;k
¼2½
er dks vuqfpr :i ls xzg.k djus ;k xzg.k djus ls bUdkj djus ;k jn~~n djus ds }kjk] ;k
¼3½
vf/kfu;e ;k fu;ekoyh ;k lfefr dh mifof/k;ksa ds micU/kksa dk vuqikyu djus esa ?kksj pwd
djus ds }kjkA
Li"Vhdj.k%&bl fu;e ds iz;kstukFkZ Hkz"Vkpkj] fj'or~~ ;k vuqfpr izHkko ds ogh vFkZ gksxs]
tks yksd izfrfuf/kRo vf/kfu;e 1951 dh /kkjk 123 ds v/khu izR;sd ds fy, fn;s x;s gSaA
¼4½
fuokZpu ls lEcf/kr dksbZ Hkh okn fuokZpu ifj.kke dh ?kks"k.kk ds 45 fnu ds Hkhrj O;fFkr i{k
}kjk fufnZ"V fd;k tk ldsxkA
¼5½
fu;ekoyh esa fdlh vU; ckr ds gksrs gq, Hkh fuokZpu okn nkf[ky djus okys oknh }kjk jkT;
ljdkj }kjk fu;r~ fd;s x;s ys[kk 'kh"kZd esa fuEuor~ 'kqYd tek dj ewy jlhn okn ds lkFk
layXu dj izLrqr dh tk;sxh%&
d& izkjfEHkd lgdkjh lgdkjh lfefr;ksa dh fLFkfr esa&:0 ,d gtkj
[k& tuin@dsUnzh; lgdkjh lfefr;ksa dh fLFkfr esa&:0 nks gtkj
x& jkT; Lrjh;@'kh"kZ lgdkjh lfefr dh fLFkfr esa&:0 ikap gtkj
izfrcU/k ;g gS fd 'kqYd dh jlhn izLrqr u fd;s tkus ij okn Lohdkj ugha fd;k tk;sxkA

<!-- page 19 -->

v/;k;&8
vijk/k ,oa 'kkfLr;ka
51&lgdkjh lfefr dh fuokZfpr izcU/k desVh dk dk;Zdky lekIr gksus ds iwoZ lfpo vFkok izcU/k
funs’kd tSlh Hkh fLFkfr gks ds }kjk vf/kfu;e dh /kkjk 29 dh mi/kkjk ¼4½ ,oa fu;e 4 ds v/khu
fufnZ"V vof/k ds Hkhrj lwpuk u fn;s tkus vFkok fuokZpu {ks=ksa ds vo/kkj.k gsrq ftyk lgk;d
lgdkjh fuokZpu vf/kdkjh vFkok e.Myh; lgdkjh fuokZpu vf/kdkjh vFkok vk;ksx vFkok mlds
izkf/kd`r vf/kdkjh dks visf{kr leLr lwpuk,a u fn;s tkus ij] vk;ksx }kjk izkjfEHkd lgdkjh
lfefr dh fLFkfr esa lEcfU/kr lfpo ;k izcU/k funs’kd] tSlh Hkh fLFkfr gks ds fo:) :0 ikap gtkj
rd dk vFkZn.M yxk;k tk ldrk gS rFkk ftyk@dsUnzh; ,oa jkT; Lrjh;@’kh"kZ lgdkjh lfefr
dh fLFkfr esa lEcfU/kr lfpo ;k izcU/k funs’kd] tSlh Hkh fLFkfr gks] ds fo:) :0 nl gtkj rd
dk vFkZn.M yxk;k tk ldrk gS vkSj vFkZn.M yxk;stkus lEcfU/kr vkns’k lEcfU/kr
deZpkjh@vf/kdkjh dh pfj= iaftdk esa vafdr djrs gq, pLik dh tk;sxhA
izfrcU/k ;g gS fd vFkZn.M yxk;s tkus ds iwoZ lecfU/kr O;fä dks lquokbZ ,oa viuk i{k
j[ks tkus dk ;qfälaxr ,d volj vk;ksx }kjk iznku fd;k tk;sxkA
52&ftyk lgk;d lgdkjh fuokZpu vf/kdkjh@l{ke izkf/kdkjh }kjk vk;ksx dks fu/kkZfjr le;kof/k ds
Hkhrj tuin dh ,slh lgdkjh lfefr;ksa ftudh izcU/k desVh dk dk;Zdky vkxkeh 4 ekl esa
lekIr gks jgk gS] dh lwpuk u fn;s tkus vFkok vk;ksx }kjk fdlh lfefr ;k lfefr;ksa ds fdlh
oxZ ;k oxksZa dh lgdkjh lfefr;ksa ds fuokZpu gsrq fnukad fu;r~ fd;s tkus ij fu/kkZfjr le;kof/k
ds Hkhrj {ks= vo/kkj.k dh dkjZokbZ u fd;s tkus ij lEcfU/kr vf/kdkjh ds fo:) vk;ksx }kjk :0
ikap gtkj rd dk vFkZn.M yxk;k tk ldrk gS vkSj vFkZn.M yxk;s tkus lEcfU/kr vkns’k
lEcfU/kr vf/kdkjh dh pfj= iaftdk esa vafdr djrs gq, pLik dh tk;sxh%
izfrcU/k ;g gS fd] vU; foHkkx ls lEcfU/kr lgdkjh lfefr;ksa ds fuokZpu ls lEcfU/kr
visf{kr lwpuk ,oa vfHkys[k ftyk lgk;d lgdkjh fuokZpu vf/kdkjh dks lEcfU/kr foHkkx ds
tuin Lrjh; vFkok vius foHkkx dh lgdkjh lfefr;ksa dks iathd`r djus okys vf/kdkjh }kjk
;Fkkle; miyC/k u djk;s tkus ij lEcfU/kr vf/kdkjh :0 ikap gtkj ds vFkZn.M dk nk;h gksxk
vkSj vFkZn.M yxk;s tkus lEcU/kh vkns’k lEcfU/kr vf/kdkjh dh pfj= iaftdk esa vafdr djrs gq,
pLik dh tk;sxh%
vxzrj izfrcU/k ;g gS fd vFkZn.M yxk;s tkus ds iwoZ lECkfU/kr vf/kdkjh dks lquokbZ ,oa viuk
i{k j[ks tkus dk ;qfälaxr ,d volj vk;ksx }kjk iznku fd;k tk;sxk%
vxzrj ;g Hkh izfrcU/k gS fd vFkZn.M yxk;s tkus ds i’pkr~ Hkh ;fn lEcfU/kr vf/kdkjh }kjk
vius drZO;ksa esa yxkrkj pwd dh tkrh gS rks ,sls vf/kdkjh ds fo:) vk;ksx }kjk lEcfU/kr fu;qfä
izkf/kdkjh dks vuq’kklukRed dkjZokbZ fd;s tkus dh vuq’kalk dh tk ldrh gS vkSj fu;qfä izkf/kdkjh ds
fy, vk;ksx dh vuq’kalk ij dkjZokbZ fd;k tkuk ck/;dkjh gksxkA
53&ftyk lgk;d lgdkjh fuokZpu vf/kdkjh rFkk vU; fu;qfä vf/kdkfj;ksa }kjk vifjgk;Z dkj.kksa dks
NksM+dj vius drZO;ksa dk ikyu u fd;k tkuk vijk/k le>k tk;sxk] ftlds nks"k fl) gksus ij
tqekZus ds :i esa tks :0 nks gtkj rd dk gks ldrk gS] ;k dkjkokl ls tks N% ekl rd gks ldrk
gS vFkok nksuksa n.M ls n.Muh; gksxkA
54&fu;e&41 ds mYya?ku esa fd;k x;k dksbZ d`R; ;k nh x;h ;k izdV dh x;h lwpuk dks vijk/k
le>k tk;sxk vkSj ,sls O;fä ;k O;fä;ksa] ftuds fo:) ,slk vijk/k fl) gks tk;] dkjkokl ls]
tks N% ekl rd gks ldrk gS] ;k tqekZus ls tks :0 nks gtkj rd gks ldrk gS ;k nksuksa ls nf.Mr
fd;k tk;sxkA
55&fu;e&42 ds mYya?ku esa fd;s x;s fdlh d`R; ds fl) ik;s tkus ij vk;ksx lEcfU/kr O;fä ds
fo:) U;wure :0 nks gtkj vkSj vf/kdre :0 nl gtkj dk vFkZn.M vFkok mldh pfj= iaftdk
esa bl vk’k; dh izfrdwy izfof"V fd;s tkus dh vuq’kalk dj ldrk gSA

<!-- page 20 -->

56&fdlh lgdkjh lfefr dk fuokZpu yM+us okys mEehnokj }kjk diViw.kZ <ax ls dksbZ rF; izLrqr fd;s
tkus] fuokZpu lEcU/kh fdlh vfHkys[k dks fod`r djus ;k mlesa ifjorZu djus ;k mldks u"V djrk
gS vFkok ,slk fd;s tkus ds fy, fdlh dks vfHkizsfjr djrk gS] ,slk d`R; vijk/k le>k tk;sxk vkSj
nks"k fl) gksus ij nks o"kZ ls vuf/kd ds dkjkokl ;k :0 ikap gtkj ds vFkZn.M ;k nksuksa ls
n.Muh; gksxkA
57&bu fu;eksa esa mfYyf[kr fdlh vijk/k ds fd;s tkus ij] lEcfU/kr O;fä fo’ks"k izFke lwpuk fjiksVZ
lEcfU/kr ftyk lgk;d lgdkjh fuokZpu vf/kdkjh }kjk ;k mlds }kjk izkf/kd`r fdlh jktif=r
vf/kdkjh }kjk djk;h tk;sxhA
58&lgdkjh lfefr ds fuokZpu vf/kdkjh@lgk;d fuokZpu vf/kdkjh dk ;g drZO; gksxk fd lfefr ds
fuokZpu djk;s tkus esa mEehnokjksa vFkok fdlh vU; en esa izkIr /kujkf’k vk;ksx }kjk fu;r~ dks"k
vFkok fu;r~ izkf/kdkjh dks fuokZpu lekfIr ds ,d lIrkg ds Hkhrj gLrxr djsxk vkSj ,slk u fd;s
tkus ij vk;ksx }kjk lEcfU/kr O;fä ds fo:) vuq’kklukRed dkjZokbZ fd;s tkus dh vuq’kalk vFkok
tqekZuk tks :0 ikap gtkj rd gks ldrk gS] dk vFkZn.M vFkok nksuksa dj ldrk gSA
59&;fn vk;ksx dh jk; esa] fdlh mEehnokj }kjk fuokZpu esa Hkz"V vkpj.k tkucw>dj dksbZ diViw.kZ
d`R; vFkok dwVjfpr vfHkys[k ds vk/kkj ij fuokZpu esa Hkkx fy;k x;k gS] ftlds izHkko ls mldh
mEehnokjh ,oa mlds ifj.kke ij lkjoku~ izHkko iM+k gS rks vk;ksx ,sls O;fä fo’ks"k@fuokZfpr lnL;
dks vugZ ?kksf"kr dj ldrk gS rFkk Hkfo"; esa fuokZpu esa Hkkx ysus gsrq de ls de 3 o"kZ ,oa
vf/kdre 6 o"kZ ds fy, v;ksX; ?kksf"kr dj ldrk gSA
60&d&;fn dksbZ O;fä] vk;ksx }kjk ml ij vkjksfir vFkZn.M dks fofuZfn"V vof/k ds Hkhrj tek djus
esa foQy jgrk gS rks lEcfU/kr fu;qfä izkf/kdkjh dk ;g drZO; gksxk fd mDr /kujkf’k lEcfU/kr
vf/kdkjh@deZpkjh ds osru ls dVkSRkh dj vk;ksx }kjk fufnZ"V [kkrs esa tek dj vk;ksx dks
lalwfpr djsxkA
vU; O;fä dh n’kk esa tqekZus dh /kujkf’k Hkw&jkTkLo ds cdk;s dh Hkkafr olwy dh tk;sxhA
[k&mDr drZO;ksa dk vuqikyu u fd;s tkus ij vk;ksx] jkT; ljdkj dks lEcfU/kr vf/kdkjh ds fo:)
dkjZokbZ fd;s tkus dh vuq’kalk dj ldrk gSA
v/;k;&9
fofo/k
61&¼d½lgdkjh lfefr;ksa ds Lora=] LoPN ,oa fu"i{k fuokZpu djk;k tkuk lqfuf'pr djus dh n`f"V ls
vk;ksx tuin@e.My@lfefr ;k lfefr;ksa gsrq fuokZpu i;Zos{kd fu;qDr dj ldrk gSA
¼[k½ lgdkjh fuokZpu i;Zos{kd ds vf/kdkj ,oa drZO; ds lEcU/k esa vk;ksx }kjk fuxZr fn'kk&funsZ'k
ck/;dkjh gksaxsA
62&lgdkjh lfefr ds fuokZpu gsrq fu;qDr fdlh Hkh fuokZpu vf/kdkjh@lgk;d fuokZpu vf/kdkjh]
ernku vf/kdkjh@x.kuk vf/kdkjh dks ;k=k HkRrk muds vius ewYk foHkkx ds ctV ls ns; gksxkA
63&fdlh lgdkjh lfefr ds lfpo ;k izcU/k funs'kd ;k lgdkjh lfefr;ksa ds fdlh oxZ ;k oxkZsa ds
fuokZpu djk;s tkus gsrq fdlh O;fDr fo'ks"k] ftls vk;ksx }kjk vf/kd`r fd;k x;k gks] leqfpr jhfr
ls fuokZpu lEiUu djk;s tkus esa vko';drkuqlkj] izf'k{k.k ,oa fuokZpu lkexzh ij y?kq O;; fd;k
tkrk gS] rks ml O;; dh izfriwrhZ] ftyk lgk;d lgdkjh fuokZpu vf/kdkjh }kjk ftyk lgdkjh
fuokZpu vf/kdkjh ds vuqeksnu ls dh tk;sxhA
64&d&fdlh lgdkjh lfefr ;k fdlh oxZ ;k oxksZa dh lgdkjh lfefr;ksa ds fuokZpu djkus gsrq /kujkf'k
dk fu/kkZj.k vk;ksx }kjk] fo'ks"k ;k lkekU; vkns'k ls vo/kkfjr fd;k tk;sxk vkSj ;g /kujkf'k ml
lgdkjh lfefr] ftldk fuokZpu fd;k tkuk gS] dh fuf/k ls ns; gksxhA
[k&lEcfU/kr lgdkjh lfefr dk lfpo vFkok izcU/k funs'kd] tSlh Hkh fLFkfr gks] drZO; gksxk fd mDr
/kujkf'k vk;ksx }kjk fu;r~ cSad [kkrk esa tek djsxk vkSj [k.M ¼d½ esa vo/kkfjr 'kqYd tek djus
dk izek.k&i= layXu djrs gq;s fuokZpu djkus dk vuqjks/k djsxk]

<!-- page 21 -->

izfrcU/k ;g gS fd vo/kkj.k 'kqYd tek u gksus dh fLFkfr esa lgdkjh lfefr dk fuokZpu ugha
djk;k tk;sxk vkSj ,slh fLFkfr esa fuokZpu u gks ikus gsrq lEcfU/kr foHkkx dk l{ke vf/kdkjh mRrjnk;h
gksxkA
65&lgdkjh lfefr;ksa ds fuokZpu fu;r jhfr ,oa fu"i{k :i ls djk;s tkus ds mn~ns'; ls vk;ksx }kjk
lgdkjh fuokZpu vkpkj lafgrk iz[;kfir dh tk ldrh gS tks fdlh lgdkjh lfefr ;k lgdkjh
lfefr;ksa ds fdlh oxZ ;k oxksZa gsrq fuokZpu fnukad vf/klwfpr gksus dh frfFk ls vk;ksx }kjk fu;r
fd;s x;s O;fDr ;k O;fDr;ksa ;k izkf/kdkjh ;k izkf/kdkfj;ksa ij vk;ksx }kjk fu/kkZfjr frfFk rd izHkkoh
jgsxhA
66&fuokZpu izfdz;k ds nkSjku fuokZpu ls lEcfU/kr lHkh vf/kdkjh@deZpkjh vk;ksx ds fu;a=.k] i;Zos{k.k
,oa ekxZn'kZu ds v/khu gksaxsA
67&bl fu;ekoyh esa fuokZpu ls lEcfU/kr fdlh izkfo/kku ds lEcU/k esa la'k; dh fLFkfr esa vk;ksx dk
fofu'p; vfUre gksxkA
68&lgdkjh lfefr;ksa ds fuokZpu ds lEcU/k esa ,slk dksbZ fo"k; ftlds lEcU/k esa fu;eksa esa dksbZ Li"V
izkfo/kku mfYyf[kr u gks rks ,sls esa vk;ksx ds fn'kk&funsZ'k ykxw gksaxsA
69&;fn vk;ksx ds laKku esa dksbZ ,slk lUnHkZ yk;k tkrk gS] tks bl fu;ekoyh ds fdlh
izkfo/kku@micU/k ls vkPNkfnr u gks rks ,sls izdj.k ij vk;ksx }kjk ;Fkksfpr fu.kZ; fy;k tk;sxk]
tks vfUre vkSj ck/;dkjh gksxkA
70&bl fu;ekoyh ds izkfo/kkuksa ds vlaxr fdlh lgdkjh lfefr dh mifof/k;ksa esa fdlh ckr ds gksrs
gq;s Hkh bl fu;ekoyh ds izkfo/kku gh izHkkoh gksaxsA
vkKk ls]
nsck'kh"k i.Mk
izeq[k lfpoA

<!-- page 22 -->

mÙkj Áns'k 'kklu
lgdkfjrk vuqHkkx&1
la[;k 579@49&1&2014&8 ¼56½13 Vh0lh0&I
y[kuÅ fnukad 19 ebZ] 2014
vf/klwpuk
mÙkj Áns'k lgdkjh lfefr vf/kfu;e] 1965 ¼mÙkj Áns'k vf/kfu;e la[;k 11] lu~ 1966½ dh
/kkjk 130 ds v/khu cuk;h x;h mÙkj Áns'k lgdkjh lfefr fu;ekoyh] 1968] le;&le; ij la'kksf/kr]
ds fu;e 470 ds v/khu 'kfDr dk Á;ksx djds mDr vf/kfu;e dh /kkjk 2 ds [k.M ¼¥¥½ ds vuqlj.k esa
xfBr mÙkj Áns'k jkT; lgdkjh lfefr fuokZpu vk;ksx }kjk vius fuokZpu lEcU/kh dk;ksZa dks fofu;fer
djus dh n`f"V ls jkT; ljdkj ds iwokZuqeksnu ls ,rn~}kjk fuEufyf[kr fu;ekoyh cuk;h tkrh gS%&

mÙkj izns'k jkT; lgdkjh lfefr fuokZpu fu;ekoyh] 2014
v/;k;&1
ÁkjfEHkd
¼1½ ;g fu;ekoyh ÞmÙkj Áns'k jkT; lgdkjh lfefr fuokZpu fu;ekoyh] 2014ß dgh tk;sxhA
¼2½ ;g fu;ekoyh xtV esa Ádkf'kr gksus ds fnukad ls Áo`Ùk gksxhA
1&¼1½ tc rd Álax ;k lUnHkZ ls vU;Fkk visf{kr u gks] bl fu;ekoyh esa %&
¼d½ Þvf/kfu;eß dk rkRi;Z mÙkj Áns'k jkT; lgdkjh lfefr vf/kfu;e] 1965 ls gS(
¼[k½ Þvk;ksxß dk rkRi;Z ÞmÙkj Áns'k jkT; lgdkjh lfefr fuokZpu vk;ksxß ls gS(
¼x½ Þlgdkjh fu;ekoyhß dk rkRi;Z mÙkj Áns'k lgdkjh lfefr fu;ekoyh 1968 ls gS(
¼?k½ ÞfuokZpuß dk rkRi;Z%&
¼1½ Áfrfuf/k;ksa] ;k
¼2½ ÁcU/k desVh ds lnL;ksa ;k
¼3½ lgdkjh lfefr ds lHkkifr@milHkkifr] vFkok vU; lfefr dks Hksts tkus okys Áfrfuf/k ds
fuokZpu ls gS(
¼³½Þernkrkß dk rkRi;Z fdlh ,sls lnL;@Áfrfuf/k ls gS] tks vf/kfu;e] fu;e vkSj lfefr dh
mifof/k;ksa ds v/khu ernku djus dk gdnkj gks vkSj blds vUrxZr fdlh lgdkjh lfefr dh
ÁcU/k desVh esa vf/kfu;e dh /kkjk&24 ;k /kkjk&29¼7½ ds v/khu uke fufnZ"V ;k fu;e&42¼[k½
;k 450 ds v/khu lg;ksftr ;k fu;e&451 ds v/khu uke fufnZ"V O;fä Hkh gS vkSj mlds uke
fuokZpu ds fy;s rS;kj dh xbZ lEc) lfefr ;k fuokZpu {ks= dh vfUre ernkrk lwph esa gksa(
¼p½ Þernkrk lwphß dk rkRi;Z fuEufyf[kr ls gS&
¼,d½ ÁcU/k desVh ds lnL; ds fuokZpu dh fLFkfr esa] lkekU; fudk; ds] ;FkkfLFkfr
Áfrfuf/k;ksa@lnL;ksa dh lwph(
¼nks½ lfefr ds lHkkifr] milHkkifr ;k Áfrfuf/k;ksa ds fuokZpu dh fLFkfr esa] ljdkjh lsodksa ls fHkUu
ÁcU/k desVh fuokZfpr] lg;ksftr vkSj uke fufn`"V lnL;ksa dh lwph(
¼rhu½ lnL; ds Áfrfuf/k ds fuokZpu dh fLFkfr esa] ml {ks= ds ;k tgk¡ ls lEc) lfefr ds lkekU;
fudk; esa Áfrfuf/k fuokZfpr fd;k tkuk gks] lnL;ksa dh lwph(
¼N½ ÞmEehnokjß dk rkRi;Z vf/kfu;e] fu;e ;k lfefr dh mifof/k;ksa ds v/khu ik= ,sls ernkrk ls gS]
tks fuEufyf[kr :i esa fuokZpu yM+us ds fy, uke&funsZ'ku i= nkf[ky djrk gS%&
¼,d½&Áfrfuf/k ds :Ik esa] ;k
¼nks½&ÁcU/k desVh ds lnL; ds :Ik esa] ;k
¼rhu½&lgdkjh lfefr ds lHkkifr ;k milHkkifr ds :i esa(

<!-- page 23 -->

¼t½ Þvuqlwfpr tkfrß] Þvuqlwfpr tutkfrß vkSj Þukxfjdksa ds vU; fiNM+s oxksZaß dk ogh rkRi;Z gS] tks
mÙkj Áns'k yksd lsok ¼vuqlwfpr tkfr;ksa] vuqlwfpr tutkfr;ksa vkSj vU; fiNM+ oxksZa ds fy,
vkj{k.k½ vf/kfu;e 1994 esa muds fy, fn;k x;k gS(
¼>½ Þe.Myh; lgdkjh fuokZpu vf/kdkjhß dk rkRi;Z lgdkjh lfefr ds eq[;ky; ls lEcfU/kr tuin
ds e.My ds e.Myh; la;qä vk;qä@mi vk;qä ,oa e.Myh; la;qä fucU/kd@e.Myh; mi
fucU/kd] lgdkfjrk] mÙkj Áns'k vFkok ,sls vf/kdkjh ls gS] tks mä in ds drZO;ksa ds fuoZgu gsrq
l{ke Ákf/kdkjh }kjk vf/kd`r fd;k x;k gks(
¼¥½ Þftyk lgdkjh fuokZpu vf/kdkjhß dk rkRi;Z ml tuin ds ftyk eftLVªsV ls gS] ftlesa lEcfU/kr
lfefr dk eq[;ky; fLFkr gks(
¼V½ Þftyk lgk;d fuokZpu vf/kdkjhß dk rkRi;Z lgdkjh lfefr ds eq[;ky; ls lEcfU/kr tuin ds
Þlgk;d vk;qä ,oa lgk;d fucU/kdß] lgdkfjrk vFkok ,sls vf/kdkjh ls gS tks mä in ds drZO;ksa
ds fuoZgu ds fuoZgu gsrq l{ke Ákf/kdkjh }kjk vf/kd`r fd;k x;k gks(
¼B½ Þ fuokZpu vf/kdkjhß dk rkRi;Z jkT; ljdkj ds fdlh ,sls vf/kdkjh ls gS] ftls vk;ksx ds funsZ 'kksa
ds v/khu ftyk lgdkjh fuokZpu vf/kdkjh }kjk fdlh lgdkjh lfefr ;k lgdkjh lfefr ds oxZ
;k oxksZa ;k fdlh {ks= ;k {ks=ksa ds fy, bl fufeÙk fuokZpu vf/kdkjh fu;qä fd;k x;k gks(
¼M½ Þlgk;d fuokZpu vf/kdkjhß dk rkRi;Z fuokZpu vf/kdkjh ds d`R;ksa ds lEiknu esa lgk;rk djus ds
fy;s ftyk lgdkjh fuokZpu vf/kdkjh }kjk fu;qä ,d ;k ,d ls vf/kd fu;qä vf/kdkjh ls gS(
¼<½ Þernku vf/kdkjhß dk rkRi;Z fuokZpu vf/kdkjh }kjk fdlh fof'k"V {ks= ;k {ks=ksa esa ernku LFky ds
fy;s fu;qä vf/kdkjh ls gS ftls fuokZpu vf/kdkjh ds d`R;ksa ds lEiknu esa lgk;rk djus vkSj ,sls
vU; dk;Z gsrq fu;qä fd;k x;k gks] tks bl fu;ekoyh ds v/khu visf{kr gksa(
¼.k½ Þlgdkjh fuokZpu i;Zos{kdß dk rkRi;Z ,sls vf/kdkjh ls gS] ftls vk;ksx }kjk fdlh fof'k"V {ks= ;k
{ks=ksa ;k lfefr;ksa ds fdlh oxZ ;k oxksZa dh lEiw.kZ fuokZpu ÁfØ;k dh fu"i{krk ,oa fu;e laxr
dkjZokbZ dk i;Zos{k.k fd;s tkus gsrq fu;qä fd;k x;k gks(
¼r½ Þpquko fpUgß dk rkRi;Z vk;ksx }kjk lgdkjh lfefr ds mEehnokjksa ds fuokZpu gsrq vuqeksfnr Árhd
fpUg ls gS(
¼Fk½ ÞfuokZpu {ks=ß dk rkRi;Z ,sls {ks= ls gS] tgk¡ ls fufnZ"V la[;k esa lkekU; fudk; ds Áfrfuf/k vFkok
ÁcU/k desVh ds lnL; ds fuokZpu gsrq ftyk lgk;d lgdkjh fuokZpu vf/kdkjh vFkok bl Á;kstu
gsrq Ákf/kd`r vf/kdkjh }kjk vo/kkfjr fd;k tk;(
¼n½ ÞfuokZpu LFkyß dk rkRi;Z lfefr ds dk;kZy; ;k eq[;ky; ;k ftyk lgk;d lgdkjh fuokZpu
vf/kdkjh }kjk vf/klwfpr dk;kZy; ;k eq[;ky; ds ;FkklEHko fudVre fdlh lkoZtfud LFky ls
gS(
¼/k½ Þernku LFkyß dk rkRi;Z lfefr ds dk;kZy; ;k eq[;ky; ;k ftyk lgk;d lgdkjh fuokZpu
vf/kdkjh }kjk vf/klwfpr fdlh lkoZtfud LFky ls gS rFkk lkekU; fudk; ds xBu gsrq Áfrfuf/k;ksa
ds fuokZpu ds ekeys esa ernku LFky] lfefr ds dk;kZy; ;k eq[;ky; ;k 'kk[kk ds vfrfjä dksbZ
vU; lkoZtfud LFkku gksxk] tSlk fuokZpu vf/kdkjh }kjk vo/kkfjr fd;k x;k gks(
¼u½ ÞfuokZpu oknß dk rkRi;Z lgdkjh lfefr ds fuokZpu ds i'pkr~ fuokZpu ls {kqC/k i{kdkjksa }kjk
vf/kfu;e dh /kkjk 70 ds v/khu lafLFkr okn ls gSA
2&bl fu;ekoyh esa Á;qä ijUrq vifjHkkf"kr 'kCnksa vkSj inksa ds ogh vFkZ gksaxs tks vf/kfu;e vkSj
lgdkjh fu;ekoyh esa Øe'k% muds fy, leuqnsf'kr gSaA

v/;k;&2
lgdkjh lfefr;ksa ds fuokZpu ds lkekU; fu;e
3&mifof/k;ksa esa fdlh ckr ds gksrs gq, Hkh] fdlh lgdkjh lfefr ;k lfefr;ksa ;k lgdkjh lfefr;ksa ds
fdlh oxZ ;k oxksZa dk fuokZpu vf/kfu;e vkSj bl fu;ekoyh ds micU/kksa ds vuqlkj gksxkA

<!-- page 24 -->

4&lgdkjh lfefr ds lfpo vFkok ÁcU/k funs'kd dk ;g drZO; gksxk fd fuokZfpr ÁcU/k desVh ds
dk;Zdky ds lekfIr ds fnukad ds 4 ekl iwoZ] ml ftys] ftlesa lfefr dk iathd`r eq [;ky; fLFkr
gS] ds ftyk lgk;d lgdkjh fuokZpu vf/kdkjh vFkok ml Ákf/kdkjh] ftls lfefr ds fdlh oxZ ;k
oxksZa ds fy, vk;ksx }kjk] ,sls Ák;kstu ds fy, vf/kd`r fd;k x;k gks] dks fyf[kr :Ik ls lfefr dh
fuokZfpr ÁcU/k desVh ds dk;Zdky lekIr gksus ds fnukad dh lwpuk nsxk vkSj vo/kkj.k 'kqYd tek
fd, tkus dk Áek.k ÁLrqr djrs gq, lfefr ds fuokZpu djk, tkus dk vuqjks/k djsxkA
5&¼d½ lgdkjh lfefr;ksa dh ÁcU/k desVh ds dk;Zdky ds lekIr gksus dh lwpuk ÁkIr gksus ij ftyk
lgk;d lgdkjh fuokZpu vf/kdkjh dk ;g drZO; gksxk fd og tuin dh leLr ,slh lfefr;ksa]
ftudk dk;Zdky vkxkeh 4 ekl ds Hkhrj lekIr gks jgk gks] dh ladfyr lwpuk vk;ksx dks ns vkSj
fuokZpu gsrq frfFk fu/kkZfjr fd;s tkus dh laLrqfr djsA
¼[k½lgdkfjrk ,oa vU; foHkkxksa dh lgdkjh lfefr;ksa dks iathd`r djus okys vf/kdkjh dk ;g drZO;
gksxk fd] og vius {ks=kf/kdkj dh lgdkjh lfefr;ksa ds fuokZpu gsrq visf{kr lwpuk ,oa vfHkys[k
ftyk lgk;d lgdkjh fuokZpu vf/kdkjh ,oa vk;ksx dks ;k vk;ksx ds Ákf/kd`r vf/kdkjh dks vis{kk
fd;s tkus ij miyC/k djk,A
6&mÙkj Áns'k lgdkjh lfefr fu;ekoyh] 1968 esa fdlh ckr ds gksrs gq, Hkh fucU/kd dk ;g
mÙkjnkf;Ro gksxk fd fdlh ubZ lfefr dks iathd`r djus ds Ik'pkr~ vFkok /kkjk 35 ds v/khu ÁcU/k
desVh dks voØfer fd;s tkus vFkok lfefr ds lekesyu] foHkktu] voØkUr ;k vU; vkdfLed
n'kkvksa esa xfBr vUrfje desVh dh rRdky lwpuk ÁcU/k desVh ds lE;d~ fuokZpu djkus ds mÌs'; ls
vk;ksx dks Ánku djsA
mä ds vfrfjä fucU/kd dk ;g Hkh mÙkjnkf;Ro gksxk fd fdlh lfefr dks ifjlekfir fd;s
tkus vFkok fucU/ku fujLr fd;s tkus dk vkns'k fn;s tkus ij mä vkns'k ds lEcU/k esa vk;ksx dks
lalwfpr djrs gq, ;g vuqjks/k djsa fd lEcfU/kr lfefr dk fuokZpu u djk;k tk;A
7&ftyk lgk;d lgdkjh fuokZpu vf/kdkjh ;k fucU/kd ;k lfefr ds lfpo vFkok ÁcU/k funs'kd ls
fuokZpu djk;s tkus dh lwpuk ÁkIr gksus ij vk;ksx lfefr;ksa ds fdlh oxZ ;k oxksZa ds fy;s fuokZpu
frfFk fu/kkZfjr djsxkA vk;ksx }kjk ,slk fd;s tkus ij ml ftys dk ftyk eftLVsªV ;k ftyk
lgdkjh fuokZpu vf/kdkjh] tgk¡ lfefr dk eq[;ky; fLFkr gks] fu;r fnukadks dks fuokZpu djkus ds
fy, dkjZokbZ djsxk] vkSj bl Á;kstu ds fy, fdlh Hkh ljdkjh deZpkjh ;k vf/kdkjh dh lsokvksa dh
mlds }kjk vis{kk dh tk ldrh gS vkSj ;fn fdlh deZpkjh ;k vf/kdkjh ds lEcU/k esa ,slk dksbZ
vkns'k ftyk eftLVsªV ;k ftyk lgdkjh fuokZpu vf/kdkjh }kjk tkjh fd;k x;k gS rks mldk ikyu
u djuk vijk/k le>k tk;sxk] ftlds fl) gksus ij] og tqekZus ls tks rhu gtkj :Ik;s rd gks
ldrk gS ;k dkjkokl ls tks rhu ekg rd gks ldrk gS ;k nksuksa ls nf.Mr fd;k tk;sxk%
ÁfrcU/k ;g gS fd mÙkj Áns'k lgdkjh xzke fodkl cSad fyfeVM] y[kuÅ dh 'kk[kkvksa ds
lnL;ksa ds Áfrfuf/k;ksa ds fuokZpu djkus dk Ákf/kdkj ml ftys ds ftyk eftLVªsV esa fufgr gksxk tgk¡
,slh 'kk[kk fLFkr gks%
8& fdlh lgdkjh lfefr ;k lfefr;ksa ;k lgdkjh lfefr;ksa ds fdlh oxZ ;k oxkaZs dk fuokZpu ,sls
fnukad dks gksxk] tks vk;ksx fu;r djs vkSj lEc) ftyk lgdkjh fuokZpu vf/kdkjh bl Ádkj
fu;r~ fd;s x;s fnukad ij] bl Ák;kstu ds fy, lfefr;ksa ds fHkUu&fHkUu oxZ ;k oxksZa ds fy, ;k
fHkUu&fHkUu {ks=ksa ds fy, ,d ;k ,d ls vf/kd fuokZpu vf/kdkjh fu;qä djsxk%
ÁfrcU/k ;g gS fd ml foHkkx dk tks lfefr ds ÁcU/k ;k Á'kklu ls lEc) gks] dksbZ
vf/kdkjh@deZpkjh] fuokZpu vf/kdkjh fu;qä ugha fd;k tk;sxkA
9& fuokZpu vf/kdkjh ,sls leLr d`R;ksa dk lEiknu djsxk tks bl fu;ekoyh ds v/khu O;kfn"V fd;s
tk,a ;k mlds drZO;ksa dk ikyu djus ds fy;s Áklafxd ;k vko';d gksa] fdUrq fdlh fuokZpu
vf/kdkjh dh vuqifLFkfr esa dksbZ lgk;d fuokZpu vf/kdkjh vFkok ernku vf/kdkjh ftls ftyk

<!-- page 25 -->

lgdkjh fuokZpu vf/kdkjh }kjk ,slk djus ds fy;s Ákf/kd`r fd;k x;k gks] fuokZpu vf/kdkjh ds
drZO;ksa dk ikyu djsxkA
10&bl fu;ekoyh ds fdUgh vU; micU/kksa esa fdlh ckr ds gksrs gq, Hkh fuokZpu vf/kdkjh ÁR;sd
fuokZpu {ks= ds fy;s ,sls ljdkjh lsodksa esa ls] tks lfefr;ksa ds ÁcU/k vkSj Á'kklu ls lEc) u gks]
fuokZpu ds lapkyu esa viuh lgk;rk ds fy;s ernku vf/kdkjh Áfrfu;qä dj ldrk gSA
11&lfefr dh ÁcU/k desVh rFkk lEc) lgdkjh lfefr dk ÁR;sd vf/kdkjh] fuokZpu djkus es fuokZpu
vf/kdkjh dks iwjh lgk;d nsus ds fy;s ck/; gksaxs vkSj ,sls lHkh vfHkys[k miyC/k djk;saxs ftudh
fuokZpu vf/kdkjh }kjk bl Á;kstu gsrq vis{kk dh tk;A
Š 12&¼d½ lfefr dk lfpo vFkok ÁcU/k funs'kd le;&le; ij vk;ksx }kjk fn;s x;s funs'kksa ;k
rRle; Áo`Ùk micU/kksa ds vuqlkj leLr ernkrkvksa dh lwph] ftuds uke ds lEeq[k vf/kfu;e] bl
fu;ekoyh vFkok mifof/k;ksa esa ;Fkk of.kZr dksbZ vugZrk,a] ;fn dksbZ gks] mfYyf[kr dh tk;sxh]
rS;kj djsxk vkSj fuokZpu ds fnukad ds 45 fnu iwoZ lE;d~ :Ik ls ukekafdr lnL;] lk/kkj.k lnL;
;k lgkuqHkwfr lnL; lfEefyr fd;s tk;saxs%
izfrcU/k ;g gS fd ,slh lfefr;ksa] tks ifjlekiuk/khu gks vFkok izcU/k desVh ds fuokZpu
u gksus ds dkj.k fuyfEcr@vf/kØfer dh xbZ gksa] ds izfrfuf/k mDr ernkrk lwph esa lfEefyr ugha
fd;s tk;saxsA
13&fu;e&12 ds vuqlkj rS;kj dh xbZ vfUre lwph] fuokZpu vf/kdkjh }kjk ml fnukad] le; vkSj
LFkku ij tks fuokZpu dk;ZØe esa vf/klwfpr dh tk;] iznf'kZr dh tk;sxhA
14&dksbZ mEehnokj] izcU/k desVh ds ,d ls vf/kd in ds fy, lkFk&lkFk fuokZpu yM+us ds fy, vgZ u
gksxkA ;fn ,d ls vf/kd in ds fy;s uke&funsZ'ku i= oS/k ik;sa tk;s rks mls dsoy ,d in ds
fy;s fodYi nsuk gksxk rFkk vU; ds fy, viuk uke&funsZ'ku&i= okil ysxkA ,slh okilh ds fy,
fuf'pr fnukad ds iwoZ ;fn og vius fodYi dk iz;ksx djus esa pwd djs] rks mlds leLr
uke&funsZ'ku&i= voS/k gks tk;saxsA
15&lgdkjh lfefr ds vgZ lk/kkj.k ,oa lgkuqHkwfrdj lnL; dks] pkgs lfefr dh iwath esa mlds fgr dh
ek=k fdruh gh D;ksa u gks] lfefr ds fuokZpu esa dsoy ,d er nsus dk vf/kdkj gksxkA
16&;fn fdlh vH;FkhZ] ftldk ukekadu fu;e 49 ds v/khu fof/k }kjk ekU; ik;k x;k gks vkSj ftlus
viuh vH;fFkZrk okil u yh gks] e`R;q gks tkrh gS vkSj ernku gksus ds iwoZ mldh e`R;q dh lwpuk
çkIr gks tkrh gS rks fuokZpu vf/kdkjh] ml vH;FkhZ dh e`R;q ds rF; ds lEcU/k esa viuk lek/kku
dj ysus ds i'pkr~ lEcfU/kr fuokZpu {ks= ds ernku dks LFkfxr dj nsxk vkSj bldh lwpuk ftyk
lgdkjh fuokZpu vf/kdkjh vkSj vk;ksx dks nsxk vkSj ml fuokZpu {ks= ;k in ds fy;s ukekadu u;s
fljs ls nkf[ky fd;s tk;sxs- fdUrq ml O;fä ds fy, tks ernku LFkfxr fd;s tkus ds le;
fuokZpu ds fy;s vH;FkhZ Fkk] dksbZ vfrfjä ukekadu vko';d u gksxk] vkSj ,slk O;fä ftlus
Š 'kklukns'k la[;k&990@49&01&2017&8¼56½&Vhlh&I y[kuÅ] 18 tqykbZ] 2017
ernku LFkfxr dj fn;s tkus ds iwoZ viuk ukekadu okil fy;k Fkk] og ,sls LFkxu fd;s tkus ds
i'pkr ukekadu nkf[ky fd;s tkus ds fy;s vugZ u gksxk vkSj ernku ,sls LFkxu ds i'pkr ml
fnukad dks gksxk tks vk;ksx }kjk fu;r fd;k tk;A

<!-- page 26 -->

17&lfefr ds fuokZpu ls lEcfU/kr çfd;k çkjEHk gks tkus ij] fu;e&16 esa mfYyf[kr dkj.kksa ds
vfrfjä fdlh vU; dkj.k ls dksbZ fuokZpu çfØ;k jksdh ugha tk;sxh]
ijUrq ;g fd ;fn ernku LFky ij cyos ;k [kqyh fgalk ds dkj.k ernku ;k fuokZpu dh fdlh
dk;Zokgh esa O;o/kku mRiUu gks tk; ;k fdlh çk—frd vkink ds dkj.k fuokZpu djk;k tkuk lEHko u
gks rks ,sls fuokZpu ds fy, fu;qä fuokZpu vf/kdkjh] ckn esa vf/klwfpr fd;s tkus okys vkxkeh fnukad
rd ds fy;s fuokZpu ds LFkxu dh ?kks"k.kk djsxkA ,sls LFkxu dh lwpuk rRdky ftyk lgdkjh fuokZpu
vf/kdkjh vkSj vk;ksx dks nh tk;sxh ftl ij vk;ksx fuokZpu ds fy;s u;k fnukad fu;r djsxk]
ijUrq ;g vkSj fd] fuokZpu vf/kdkjh }kjk ç;ksx dh tk jgh ernku Mk;jh esa iwjs ?kVukØe dk
Øec)@le;c) o.kZu djus ds i'pkr~ gh fuokZpu çfØ;k LFkfxr dh tk,xhA
18&;fn fdlh dkj.k ls fuokZpu vf/kdkjh }kjk fdlh lfefr dk fuokZpu jksdk x;k gS rks fuokZpu dh
çfØ;k ml çØe ls] tgk¡ ij mls jksdk x;k Fkk] ;k mlds iwoZ ds çØe ls ;k u;s fljs ls] tSlk
fd vk;ksx fofu'p; djs] çkjEHk dh tk;sxh]
çfrcU/k ;g gS fd ;fn ukekadu ds i'pkr oS/k uke&funsZ'ku i=ksa ij pquko fpUgksa dk vkoaVu
dj fn;k x;k gS rks fuokZpu dh dk;Zokgh vkxs pyk;h tk;sxh vkSj fuokZpu ,sls fnukad dks djk;k
tk;sxk tks vk;ksx fu;r djsa]
vxzrj çfrcU/k ;g gS fd fdlh lgdkjh lfefr dk fuokZpu vf/kfu;e dh /kkjk&29 dh mi/kkjk ¼3½
ds çfrcU/kkRed [k.M ds v/khu vk;ksx }kjk LFkfxr fd;k tkrk gS rks fuokZpu dh leLr çfØ;k u;s
fljs ls çkjEHk dh tk;sxhA
19&çR;sd fuokZpu esa ernku lekIr gksus ds i'pkr~ eri=ksa dh x.kuk fuokZpu vf/kdkjh }kjk fu;e 44
esa fofgr jhfr vkSj vk;ksx ds fn'kk&funsZ'kksa ds v/khu djk;h tk;sxh vkSj çR;sd vH;FkhZ] mlds
fuokZpu vfHkdrkZ vkSj x.kuk vfHkdrkZ dks ;g vf/kdkj gksxk fd og x.kuk ds le; mifLFkr jgsaA
20&vf/kfu;e ds micU/k ,oa bl fu;ekoyh ds v/khu tkjh fd;s x;s lgdkjh fu;e] vkns'k ,oa
fn'kk&funsZ'k çR;sd iqueZrnku ij mlh çdkj ykxw gksaxs] tSls fd og ewy ernku esa ykxw gksrs gSaA
21&¼1½;fn fuokZpu ds i'pkr~ fdlh lfefr dh çcU/k desVh esa fuokZfpr lnL;ksa dh la[;k] fuokZfpr
fd;s tkus okys fofgr la[;k ls de ik;h tkrh gS rks fjä LFkkuksa ds fy, fuokZpu] ;FkklEHko 'kh?kz
djk;s tk;saxs]
çfrcU/k ;g gS fd lHkkifr@milHkkifr vkSj çfrfuf/k;ksa ds fuokZpu ds fy, erkf/kdkj çkIr lnL;ksa
dh la[;k ds vk/ks ls vf/kd lnL; dk gksuk vfuok;Z gSA
¼2½ ;fn vk;ksx dk ;g lek/kku gks tkrk gS fd lfefr dh fuf"Ø;rk ;k vU; dkj.kksa ls fdlh lfefr
dk fuokZpu djk;k tkuk lEHko ugha gS] rks vk;ksx ,slh lfefr fo'ks"k dks ifjlekIr fd;s tkus ds
fy, lEcfU/kr çkf/kdkjh dks laLrqfr dj ldrk gS vkSj lEcfU/kr çkf/kdkjh dk ;g drZO; gksxk fd
lfefr dks lquokbZ dk volj nsrs gq, fof/k vuqlkj lfefr dks ifjlekIr djus ;k lfefr dk
iathdj.k fujLr fd;s tkus dh dkjZokbZ djsA
22&lgdkjh lfefr;ksa ds fuokZpu ds lEcU/k esa vk;ksx }kjk le;&le; ij fuxZr funsZ'k ck/;dkjh
gksaxsA

v/;k;&3
lkekU; fudk; ,oa çcU/k desVh ds fuokZpu {ks= dk vo/kkj.k
23&vk;ksx }kjk fdlh lgdkjh lfefr v/kok lgdkjh lfefr;ksa ds fdlh oxZ ;k oxksZa ds
fy, fuokZpu frfFk;k vf/klwfpr fd, tkus ds i'pkr~ lEcfU/kr lgdkjh lfefr vFkok
lgdkjh lafefr;ksa ds fdlh oxZ ;k oxksZa ds fuokZpu ds fy, {ks= vo/kkj.k dh dkjZokbZ
dh tk,xhA

<!-- page 27 -->

24&leLr çdkj dh çkjfEHkd lgdkjh lfefr;ksa ds iath—r eq[;ky; ls lEcfU/kr ftyk
lgk;d lgdkjh fuokZpu vf/kdkjh }kjk fu;e&27 ,oa 28 esa fofgr jhfr ,oa vk;ksx
}kjk fn, x;s fn'kk funsZ'kksa ds v/khu vko';d gksus ij lkekU; fudk; ds çfrfuf/k;ksa]
lgdkjh lfefr dh çcU/k desVh ds enL;ksa] lHkkifr] mi lHkkifr rFkk vU; lgdkjh
lfefr;ksa esa Hksts tkus okys çfrfuf/k;ksa ds fuokZpu gsrq {ks= vo/kkj.k dh dk;Zokgh dh
tk,xhA
çfrcU/k ;g gS fd] ftyk dsUæh; lgdkjh lfefr;ksa dh fLFkfr esa {ks= vo/kkj.k dh
dkjZokbZ e.Myh; lgdkjh fuokZpu vf/kdkjh }kjk dh tk,xhA
25&jkT; Lrjh;@'kh"kZ lgdkjh lfefr dh n'kk esa {ks= vo/kkj.k dh dkjZokbZ vk;ksx ds
çkf/k—r vf/kdkjh }kjk dh tk,xhA
26&fuokZpu {ks=ksa ds vo/kkj.k ds fy, lfefr dk lfpo vFkok ;FkkfLFkfr çcU/k funs'kd]
og leLr lwpuk,a vFkok rF;] ftldh vis{kk ftyk lgk;d lgdkjh fuokZpu
vf/kdkjh vFkok e.Myh; lgdkjh fuokZpu vf/kdkjh vFkok vk;ksx ds çkf/k—r
vf/kdkjh }kjk le;&le; ij dh tk,] miyC/k djk;sxkA
27&¼1½ lgdkjh lfefr dh çcU/k desVh ds lnL;ksa ;k ;FkkfLFkfr] lgdkjh lfefr ds
lkekU; fudk; ds çfrfuf/k;ksa ds fuokZpu ds ç;kstukFkZ ftyk lgk;d lgdkjh fuokZpu
vf/kdkjh vFkok e.Myh; lgdkjh fuokZpu vf/kdkjh vFkok vk;ksx vFkok çkf/k—r
vf/kdkjh] lgdkjh lfefr dh mifof/k;ksa esa fdlh ckr ds gksrs gq, Hkh] lgdkjh lfefr
;k ;FkkfLFkfr lgdkjh lfefr ds fdlh oxZ ;k oxksZa ds fuokZpu ds fy, vufUre :i
ls fuEufyf[kr ckrksa dk vo/kkj.k djsxk%&
¼d½ fuokZpu {ks=ksa dh la[;k] ftlesa lgdkjh lfefr ds dk;Z{ks= dks foHkkftr fd;k tk;sxk¼[k½ çR;sd fuokZpu {ks= dk foLrkj]
¼x½ çR;sd fuokZpu {ks= ds fy, vkoafVr LFkkuksa dh la[;k]
¼?k½ {ks= dk fpUgkadu rFkk vkjf{kr LFkkuksa dh la[;k%
çfrcU/k ;g gS fd fuokZpu {ks=ksa dk uke fgUnh o.kZekyk esa mfYyf[kr fd;k tk;sxkA
¼2½&rnqijkUr ftyk lgk;d lgdkjh fuokZpu vf/kdkjh@e.Myh; lgdkjh fuokZpu
vf/kdkjh@l{ke çkf/kdkjh vufUre :i ls fd;s x;s vo/kkj.kk ij vkifÙk;ka vkeaf=r
djus ds fy,] lquokbZ dh frfFk vafdr dj mä vo/kkj.k dks fdlh çeq[k nSfud
lekpkj i= esa çdkf'kr djsxk] ftlesa ,sls çdk'ku ds fnukad ls 7 fnu ds Hkhrj
vkifÙk;ka vkeaf=r dh tk;saxhA ftldh ,d çfrfyfi lEc) lfefr dks Hkh
Vhdk&fVIi.kh ds fy, Hksth tk;sxh
çfrcU/k ;g gS fd çkjfEHkd] ftyk@dsUæh; lgdkjh lfefr;ksa dh fLFkfr esa çdk'ku
e.My ls çlkfjr gksus okys çeq[k nSfud lekpkj i= esa çdkf'kr fd;k tk;sxk vkSj jkT;
Lrjh;@'kh"kZ lgdkjh lfefr dh n'kk esa çdk'ku e.My Lrjh; nSfud lekpkj i= ds lHkh
laLdj.kksa esa çdkf'kr fd;k tk;sxk%
vxzrj çfrcU/k ;g gS fd ,slh çkjfEHkd] ftyk@dsUæh; lgdkjh lfefr] ftldk
dk;Z{ks= ,d jktLo tuin ls vf/kd gks] ds vufUre vo/kkj.k dk çdk'ku ,sls çeq[k
nSfud lekpkj i=] tks lfefr ds dk;Z{ks= esa çlkfjr gksrk gks] esa fd;k tk;sxkA

<!-- page 28 -->

¼3½&fuokZpu {ks= ds vo/kkj.k dk ekin.M fuEufyf[kr esa ,d ;k vf/kd gks ldrk gS]
vFkkZr%&
1- jktLo {ks=
2- lnL;rk dk@ds oxZ
3- lfefr ds dk;Z{ks= ds lEcU/k esa vU; rxZlaxr vk/kkj%
çfrcU/k ;g gS fd çkjfEHkd —f"k _.k lfefr vFkok çkjfEHkd xUuk lfefr@nqX/k
lfefr dh fLFkfr esa vo/kkj.k dh bdkbZ ;FkklEHko lfefr ds dk;Z{ks= ds vUrxZr vkus
okyh ,d ;k vf/kd xzke iapk;r gksxhA
¼4½&¼d½vufUre vo/kkj.kk ds v/khu çkIr vkifÙk;ksa vkSj fVIif.k;ksa ij ftyk lgk;d
lgdkjh fuokZpu vf/kdkjh@e.Myh; lgdkjh fuokZpu vf/kdkjh@l{ke çkf/kdkjh }kjk
,sls çdk'ku ds X;kjgosa@ckjgoas@rsjgosa fnu] tSlk fd vufUre vo/kkj.k esa mfYyf[kr
gks] esa lEcfU/kr vkifÙkdrkZ es lquokbZ dj fopkj djsxk vkSj lquokbZ ds i'pkr~
lEcfU/kr iaftdk ij vkifÙk ,oa lquokbZ esa çkIr dFku dk laf{kIr fooj.k vafdr dj
ml ij vkifÙkdrkZ ls gLrk{kj djk;sxk vkSj Lo;a Hkh gLrk{kj djsxkA
¼[k½&ç'uxr lquokbZ esa fy;s x;s fu.kZ; ls lEcfU/kr mfYyf[kr rF;ksa dh çfrfyfi
vkifÙkdrkZ }kjk nl :i;s çfr i`"B tek dj çkIr dh tk ldrh gSA
¼5½&rnqijkUr] ftyk lgk;d lgdkjh fuokZpu vf/kdkjh@e.Myh; lgdkjh fuokZpu
vf/kdkjh@l{keçkf/kdkjh }kjk çkIr vkifÙk;ka ds fuLrkj.k ds lEcU/k esa ;Fkk vko';d
fVIi.kh lEcfU/kr iaftdk esavafdr djrs gq, fuokZpu {ks=ksa] LFkkuksa dh la[;k vkSj
vkjf{kr LFkkuksa dh la[;k dk vfUre vo/kkj.k djsxkA bl çdkj fd;s x;s vfUre
vo/kkj.k dks vufUre çdk'ku ds iUægosa fnu ,sls lekpkj i= esa çdkf'kr djsxk] tSlk
mifu;e ¼2½ esa mfYyf[kr gSaA ,sls vo/kkj.k dh ,d çfrfyfi lEc) lfefr dks Hkh
tk;sxhA
28&ftyk lgk;d lgdkjh fuokZpu vf/kdkjh@e.Myh; lgdkjh fuokZpu vf/kdkjh@l{ke
çkf/kdkjhvf/kfu;e dh /kkjk 29¼5½ ds çfrcU/kkRed [k.M ds micU/kksa ds v/khu vkjf{kr
LFkkuksa ds fy, fuokZpu {ks=@{ks=ksa dks vkjf{kr djsxk vkSj ,slk vkj{k.k ml fuokZpu
{ks=@{ks=ksa ds] tgka ls çcU/k desVh ds lnL;ksa dk fuokZpu fd;k tkuk gks] ukeksa ds
fgUnh o.kZekyk ds Øe esa j[kdj pØkuqØe esa ml lhek rd fd;k tk;s] tgka rd
LFkku vkjf{kr fd;k tkuk vko';d gks%
çfrcU/k ;g gS fd bl çdkj vkjf{kr {ks=ksa dks fuEu çdkj ls fgUnh o.kZekyk ds Øe
esa vkoafVr fd;k tk;sxk%&
¼1½ ,d vuqlwfpr tkfr;ksa@vuqlwfpr tutkfr;ksa ds fy,]
¼2½ ,d ukxfjdksa ds vU; fiNM+s oxksZa ds fy,]
¼3½ nks efgykvksa ds fy,]
vxzrj çfrcU/k ;g gS fd tgka ,d ls vf/kd fuokZpu {ks=ksa ds uke dk çFke v{kj
,d leku gks] ogka ,sls ekeyksa esa vkj{k.k ,d fuokZpu {ks= ds uke ds vxys v{kj }kjk
fofu;fer fd;k tk;sxkA

<!-- page 29 -->

29&ftyk lgk;d lgdkjh fuokZpu vf/kdkjh@e.Myh; lgdkjh fuokZpu vf/kdkjh@l{ke
çkf/kdkjh dk ;g Hkh drZO; gksxk fd lfefr;ksa ds vo/kkj.k ls lEcfU/kr vufUre ,oa
vfUre vo/kkj.k dh ,d çfr lEcfU/kr ftyk eftLVªsV@ftyk lgdkjh fuokZpu
vf/kdkjh rFkk vk;ksx dks Hkh miyC/k djk;sxkA
v/;k;&4
lkekU; fuokZpu çfØ;k
30&vk;ksx }kjk fdlh lgdkjh lfefr ;k lfefr;ksa ds fdlh oxZ ;k oxksZa ds fuokZPku dh
vf/klwpuk fuxZr fd, tkus ij ml ftys dk ftyk lgdkjh fuokZpu vf/kdkjh@ftyk
eftLVªsV] ftlesa lfefr dk eq[;ky; fLFkfr gks] vk;ksx ds fn'kk&funsZ'kksa ds v/khu jgrs
gq, fuokZpu vf/kdkjh dh fu;qfä djsxkA
31&ftyk lgk;d lgdkjh fuokZpu vf/kdkjh vius vf/kdkfjrk {ks=@{ks=ksa dh ,slh lgdkjh
lfefr;ksa] ftudk eq[;ky; mlds lEcfU/kr ftys esa gS vkSj ftudk fuokZpu gksuk gS] ds
fuokZPku ls lEcfU/kr vk;ksx }kjk vf/klwfpr fuokZpu dk;ZØe dks LFkkuh; nSfud
lekpkj i= esa vufUre {ks= vo/kkj.k ds i'pkr~ çdkf'kr djsxkA
32&mä fuokZpu dk;ZØe ds çdk'ku esa] ftyk lgk;d fuokZpu vf/kdkjh@l{ke çkf/kdkjh
fuokZpu gsrq fuokZpu LFky ,oa ernku LFky dk fu/kkZj.k djsaxs vkSj mls lwpuk esa
vafdr djsaxs vkSj lfpo vFkok çcU/k funs'kd] tSlh fLFkfr gks] ls ;g vis{kk djsaxs fd
mä dk;ZØe dh ,d çfr lfefr ds lwpuk iV ij pLik dh tk;%
çfrcU/k ;g gS fd ernku dk LFkku lfefr dk dk;kZy; ;k eq[;ky; gksxk ijUrq]
vifjgk;Z dkj.kksa ls ftyk lgk;d lgdkjh fuokZPku vf/kdkjh@l{ke çkf/kdkjh }kjk
fofu'p; fd;k x;k ernku LFky] lfefr ds dk;kZy; ;k eq[;ky; ds ;FkklEHko fudV
dksbZ lkoZtfud LFky Hkh gks ldrk gS%
vxzlj çfrcU/k ;g gS fd lgdkjh fu;ekoyh ds fu;e&84&d ds mi fu;e&¼4½ esa
;Fkk mfYyf[kr lfefr ds çfrfuf/k;ksa ds pquko ds ekeysa esa ernku dk LFky lfefr ds
dk;kZy; ;k eq[;ky; ;k 'kk[kk ds vfrfjä dksbZ vU; lkoZtfud LFkku] tSlk fd ftyk
lgk;d lgdkjh fuokZpu vf/kdkjh@l{ke çkf/kdkjh }kjk vo/kkfjr fd;k tk;] gks ldrk
gSA
33&¼d½ lfefr ds lfpo vFkok çcU/k funs'kd dk ;g mÙkjnkf;Ro gksxk fd lfefr ds
fuokZPku dk;ZØe ,oa ernku LFky dh lwpuk vufUre ernkrk lwph çdkf'kr gksus dh
frfFk ls de 15 fnu iwoZ lfefr ds lwpuk iV ij çnf'kZr djsa%
çfrcU/k ;g gS fd mä lwpuk çkjfEHkd lgdkjh lfefr dh fLFkfr esa] lEcfU/kr
fodkl [k.M] ftyk@dsUnzh; lgdkjh lfefr dh fLFkfr esa lEcfU/kr ftyk eftLVªsV ds
dk;kZy; ,oa jkT; Lrjh;@'kh"kZ lgdkjh lfefr dh fLFkfr esa vk;qä ,oa fucU/kd rFkk
vk;ksx ds dk;kZy; ds lwpuk iV ij Hkh çnf'Zkr dh tk,xhA
¼[k½ fuokZpu dk;ZØe esa fuEufyf[kr dks çnf'kZr fd;k tk;sxk%&

<!-- page 30 -->

¼,d½vufUre ernkrk lwph ds çn'kZu dk fnukad(
¼nks½ vufUre ernkrk lwph ij vkifÙk;ka nkf[ky djus vkSj muds fuLrkj.k dk fnukad]
le; vkSj LFkku(
¼rhu½ vafre ernkrk lwph ds çn'kZu dk fnukad(
¼pkj½ uke&funsZ'ku i= nkf[ky djus dk fnukad] le; vkSj LFkku(
¼ik¡p½ uke&funsZ'ku i=ksa ds ifjfujh{k.k dk fnukad] le; vkSj LFkku(
¼N%½ uke&funsZ'ku i= okil ysus dk fnukad] le; vkSj LFkku(
¼lkr½ fuokZPku fpUg vkoafVr djus vkSj vafre uke&funsZ'ku çnf'kZr djus dk fnukad] le;
vkSj LFkku(
¼vkB½ ernku dk fnukad] le; vkSj LFkku(
¼ukS½ og LFkku tgk¡ ernkrk }kjk ernkrk lwph dk fujh{k.k fd;k tk ldrk gS(
¼nl½ fuokZPku {ks=ksa ds uke] ftlesa vkjf{kr fuokZpu {ks= Hkh lfEefyr gS vkSj fuokZpu fd;s
tkus okys O;fä;ksa dh la[;k(
çfrcU/k ;g gS fd] Øekad&¼,d½ ls ¼vkB½ esa fnukad ,oa le; og gksxk] tks vk;ksx
}kjk fu/kkZfjr fd;k tk; rFkk Øekad&nl dh lwpuk ,oa LFkku og gksxk] tks ftyk lgk;d
lgdkjh fuokZPku vf/kdkjh@l{ke çkf/kdkjh }kjk fofuf'pr fd;k tk;A
34&fuokZPku ls lEc) lfefr dk lfpo@çcU/k funs'kd fu;e&12 ds v/khu jgrs gq,
fuEufyf[kr vk/kkj ij vufUre ernkrk lwph rS;kj djsxk&
¼,d½ mu lfefr;ksa dh fLFkfr esa ftuds lkekU; fudk; esa vyx&vyx lnL; gksa] ;k mu
lfefr;ksa dh fLFkfr esa ftuds lkekU; fudk; esa vyx&vyx lnL;ksa ds çfrfuf/k gksa]
¼nks½ mu lfrfr;ksa dh fLFkfr esa] ftuds lkeU; fudk; esa vyx&vyx lnL; vkSj lfefr
lnL; lfEefyr gksa] vyx&vyx lnL;ksa dh ,d lwph rhu çfr;ksa esa rS;kj djk;sxk
ftlesa mu fnukad dks tks vk;ksx }kjk fofufnZ"V fd;k tk;] lfefr dh iqfLrdkvksa esa
vafdr uke] firk dk uke] irk] vugZrk ;fn dksbZ gks] fn[kk;k tk;sxk] ftls vkxs
vufUre lwph dgk x;k gS vkSj ;g lwph fuEufyf[kr jhfr ls rS;kj dh tk;sxh%&
¼d½ çkjfEHkd d`f"k _.k lgdkjh lfefr;ksa] çkjfEHkd xUuk lfefr;ksa ,oa çkjfEHkd nqX/k
lfefr;ksa dh fLFkfr esa xzke iapk;r@jktLo xzkeokj]
¼[k½ uxj {ks= esa fLFkr çkjfEHkd lgdkjh lfefr;ksa ftlesa miHkksäk lgdkjh lfefr;k¡ Hkh
gaS] esa eksgYykokj@okMZokj vkSj uxj {ks= ls fHkUu {ks=ksa esa xzke iapk;rokj]
¼x½ vU; lfefr;ksa dh fLFkfr esa fuokZpu {ks=okj ;k lHkh lnL;ksa ds vuqikfrd Øekuqlkj@
fuokZpu {ks=okj ;k vU; fdlh rdZlaxr vk/kkj tSlk fd] vk;ksx }kjk fofuf'pr fd;k
tk;s%
çfrcU/k ;g gS fd ,slh lgdkjh lfefr dh fLFkfr esa ftldh lnL; vU; lfefr;k¡
;k [k.M&¼2½ ds vUrxZr vkus okyh lfefr;k¡ gks] ,slh lwph lfefr ds fuokZfpr çfrfuf/k;ksa
ds uke ,oa irk lfgr] ;k ;fn fuokZfpr çfrfuf/k;ksa ds uke vufUre ernkrk lwph
çdkf'kr gksus ds iwoZ çkIr u gks] rks orZeku çfrfuf/k;ksa ds uke lfgr] fVIi.kh vafdr djrs
gq, fuokZpu vf/kdkjh dks çLrqr dh tk;sxh%

<!-- page 31 -->

vxzrj izfrcU/k ;g gS fd mRrj izns'k lgdkjh xzke fodkl cSad fy0] y[kuÅ dh
'kk[kkvksa ;k ,slh lfefr;ksa ftudk dk;Z{ks= ,d ls vf/kd jktLo ftys esa gks vkSj ftldh
lnL;rk esa vyx&vyx lnL; gksa] ,slh lwph] ;FkkfLFkfr] mi dk;kZy; ds izHkkjh ;k
lEc) 'kk[kk ds 'kk[kk izcU/kd }kjk rS;kj dh tk;sxh vkSj fuokZpu vf/kdkjh dks izLrqr dh
tk;sxhA
¼3½ vufUre ernkrk lwph dks lfefr ds lfpo@çcU/k funs'kd] tSlh fLFkfr gks] }kjk
gLrk{kj ,oa eqgj vafdr djrs gq, fuokZpu vf/kdkjh dks ;Fkkle; miyC/k djk,xkA
35&fuokZpu vf/kdkjh mä vufUre ernkrk lwph dks fuokZpu dk;ZØe esa fu/kkZfjr frfFk ,oa
le; ij lfefr ds eq[;ky; ;k vko';drkuqlkj lfefr ds midk;kZy;@'kk[kkvksa ds
dk;kZy; esa çnf'kZr djsxkA
36&vfUre ernkrk lwph ds lEcU/k esa vkifÙk;k¡ ;fn dksbZ gks] fuokZpu vf/kdkjh }kjk fu;r
fnukad] le; vkSj LFkku ij lquk tk;sxk vkSj mldk fuLrkj.k djrs gq, vfUre
ernkrk lwph rS;kj dh tk,xhA
37&vfUre ernkrk lwph tks fuokZPku&{ks=okj] fuokZpu vf/kdkjh }kjk mä fuLrkj.k djrs
gq, rS;kj dh x;h Fkh] dks ml ij vius gLrk{kj vafdr djrs gq, mls fuokZ pu LFky]
lfefr ds eq[;ky; vkSj vko';rkuqlkj lfefr ds midk;kZy; ;k 'kk[kk esa çnf'kZr
fd;k tk;sxkA ernkrk lwph :0 nl çfr i`"B vFkok vk;ksx }kjk le;&le; ij ;Fkk
fu;r ewY; dk Hkqxrku djus ij fuokZpu vf/kdkjh vFkok mlds }kjk çkf/kd`r vf/kdkjh
ls lfefr ds eq[;ky;@'kk[kk ls çkIr dh tk ldsxhA
38&vfUre ernkrk dh lwph dh ,d çfr fuokZPku vf/kdkjh }kjk ftyk lgk;d fuokZpu
vf/kdkjh@l{ke çkf/kdkjh dks Hkh rRdky miyC/k djk;h tk;sxhA
39¼1½&dksbZ vH;FkhZ fuEufyf[kr Qhl nsdj uke&funsZ'ku çi= ¼çi=&V½ fuokZpu vf/kdkjh
ls çkIRk dj ldrk gS%&
¼d½ çkjfEHkd lgdkjh lfefr;ksa dh LFkfr esa%&
¼,d½ çcU/k desVh ds lnL; ds ukekadu gsrq&
¼nks½ lHkkifr@milHkkifr in ij ukekadu gsrq&
¼rhu½çfrfuf/k in ij ukekadu gsrq&

ik¡p lkS :i;s
,d gtkj :i;s
,d lkS :i;s

¼[k½ ftyk@dsUnzh; lgdkjh lfefr;ksa dh fLFkfr esa%&
¼,d½ çcU/k desVh ds lnL; ds ukekadu gsrq&
¼nks½ lHkkifr@milHkkifr in ij ukekadu gsrq&
¼rhu½ çfrfuf/k in ij ukekadu gsrq&

,d gtkj :i;s
nks gtkj :i;s
ik¡p lkS :i;s

¼x½ jkT; Lrjh;@'kh"kZ lgdkjh lfefr;ksa dh fLFkfr esa%&
¼,d½ çcU/k desVh ds lnL; ds ukekadu gsrq&
¼nks½ lHkkifr@milHkkifr in ij ukekadu gsrq&
¼rhu½ çfrfuf/k in ij ukekadu gsrq&

nks gtkj :i;s
ik¡p gtkj :i;s
,d gtkj :i;s

<!-- page 32 -->

¼2½ mifu;e ¼1½ esa fu/kkZfjr 'kqYd dh /kujkf'k] vk;ksx }kjk fu;r~ cSad [kkrs vFkok fuokZP ku
vf/kdkjh dks vnk djds çiV ^V* ,oa lEcfU/kr 'kqYd dh jlhn vH;FkhZ }kjk çkIr dj
ukekadu çi= mä jlhn ds lkFk çLrqr fd;k tk,xkA
¼3½ lfefr ds fuokZPku vf/kdkjh dk ;g drZO; gksxk fd ukekadu 'kqYd ,ao vU; enksa esa
çkIr /kujkf'k] çR;sd n'kk esa fuokZpu ifj.kke ?kksf"kr gksus ds ,d lIrkg ds Hkhrj
vk;ksx }kjk fu;r~ fd;s x;s cSad [kkrk esa tek dj mldk fooj.k ,oa çek.k ftyk
lgk;d fuokZpu vf/kdkjh@çkf/kd`r vf/kdkjh dk miyC/k djk;sxkA
40&¼1½ fdlh Hkh O;fä dk uke funsZ'ku çi= lfefr dk fuokZpu vf/kdkjh Lohdkj ugha
djsxk] ;fn og O;fä&
d&ernku ds fy, ik= u gks(
[k&vf/kfu;e] fuokZpu fu;eksa ;k lfefr dh mifof/k;ksa ds micU/kksa ds v/khu vugZ
gks vFkok vk;ksx }kjk fuokZPku ds fy, vugZ ?kksf"kr fd;k x;k gksA
¼2½ uke funsZ'ku ds fy, çLrko çi= ^^V** esa fuokZpu vf/kdkjh dks lEcksf/kr fd;k tk;sxkA
uke&funsZ'ku ds lEcU/k esa vkifÙk Hkh mls lEcksf/kr dh tk;sxh vkSj ,slh vkifÙk fdlh
ernkrk }kjk gh dh tk;sxhA
¼3½ mEehnokj viuk uke&funsZ'ku O;fäxr :i ls ;k vius çkf/kd`r vfHkdrkZ ds ek/;e ls
fuokZPku vf/kdkjh dks çLrqr djsxk vkSj fuokZPku vf/kdkjh }kjk mldh çfof"V ,d
jftLVj esa] çR;sd n'kk esa dkykuqØe esa dh tk;sxh vkSj og mldh çkfIr Hkh Lohdkj
djsxk vkSj çi= ^^V** dh çkfIr jlhn lEcfU/kr mEehnokj ;k mlds ukfer vfHkdrkZ
dks miyC/k djk;h tk;sxh%
izfrcU/k ;g gS fd uke funsZ'ku dk izLrkod vkSj vuqeksnd mEehnokj ls fHkUu dksbZ
vU; vgZ ernkrk mlh fuokZpu {ks= dk gksxkA
¼4½ fuokZPku vf/kdkjh }kjk jftLVj esa fuEufyf[kr ckrsa mfYyf[kr dh tk;sxh%&
¼d½ mEehnokjksa dk uke] firk dk uke] irk(
¼[k½ çLrkod vkSj vuqeksnd dk uke] firk dk uke ,oa irk(
¼x½ uke&funsZ'ku i= çkIRk gksus dk fnukad] le; vkSj ml ij fuokZpu vf/kdkjh }kjk
gLrk{kj fd;k tk;sxkA
¼5½ fuokZPku vf/kdkjh] uke&funsZ'ku i= nkf[ky djus dk le; lekIr gks tkus ds i'pkr~
jftLVj esa vfUre uke&funsZ'ku i= dh çfof"V ds uhps ,d iM+h js[kk [khapsxk] mlds
uhps 'kCn ¼uke&funsZ'ku lekIr½ fy[ksxk vkSj fnukad vkSj le; lfgr viu gLRkk{kj
djsxkA uke&funsZ'ku dh ,d lwph] le; lekIr gksus ds i'pkr~ ;Fkk'kh?kz] lfefr ds
lwpuk iV ij iznf'kZr dh tk;sxhA
¼6½ fuokZPku vf/kdkjh uke&funsZ'ku i=ksa dh ifjfujh{kk dk dk;Z fofuZfn"V fnukad dks
o.kZekyk Øe esa djsxk vkSj mEehnokj@mldk çLrkod ;k vuqeksnd ifjfujh{kk ds
le; mifLFkr jg ldrk gSA
¼7½ uke&funsZ'ku dh ifjfujh{kk djrs le; fuokZpu vf/kdkjh&

<!-- page 33 -->

¼d½ uke&funsZ'ku i=ksa esa uke ;k la[;k ds lEcU/k esa fdlh fyfidh; Hkwy dks ernkrk lwph esa
lekuqorhZ çfof"V;ksa ds vuq:i djus ds fy, vuqKk ns ldrk gS(
¼[k½ tgka vko';d gks] ogka ;g funsZ'k ns ldrk gS fd mä çfof"V;ksa esa fdlh eqnz.k lEcU/kh
=qfV ij /;ku u fn;k tk;A
¼8½ ifjfujh{kk ds le;] fuokZpu vf/kdkjh çR;sd uke&funsZ'ku i= ij mls Lohdkj djus ;k
vLohdkj djus ds lEcU/k esa fofu'p; i`"Bkafdr djsxkA vLohdkj fd;s tkus dh fLFkfr esa]
og ,sls vLohdj.k ds fy, vius dkj.kksa dk ,d laf{kIr fooj.k vfHkfyf[kr djsxkA ftl
mEehnokj dk uke funsZ'ku vLohdkj fd;k tk;] og 10 :i;s dh Qhl fuokZPku vf/kdkjh
ds ikl udn tek dj] vLohdj.k vkns'k dh ,d çfr çkIr dj ldrk gSA
¼9½ uke&funsZ'ku okil ysus ds fy, vkosnu i= fu;r çi= esa dsoy lEc) mEehnokj }kjk
O;fäxr :i ls fuokZpu vf/kdkjh dks fn;k tk;sxkA
¼10½ tgka fuokZfpr vf/kdkjh uke&funsZ'ku okil ysus ds i'pkr~ uke&funsZ'ku dks vfUre :i
ns ns] ogka ij vk;ksx }kjk vuqeksfnr fpUgksa dh lwph ls ,d fpUg@fPkUgksa ds mlh Øe esa
ftl Øe esa og vuqeksfnr lwph esa bafxr fd;k x;k gS] çR;sd fof/kekU; uke&funsZ'ku ds
fy, vkoafVr djsxk vkSj ;fn fof/kekU; uke&funsZ'ku dh la[;k vk;ksx }kjk vuqeksfnr
fpUgksa dh la[;k ls vf/kd gks rks fuokZPku vf/kdkjh dksbZ vU; fpUg vkoafVr dj ldrk gS]
tks vk;ksx }kjk vuqeksfnr fpUgksa ls fHkUu] fdUrq mlls lkE; j[krk gksA bl çdkj vkoafVr
fpUg lEc) mEehnokj ds fy, cU/kudkjh gksxkA
¼11½vfUre uke&funsZ'kuksa dh lwph] ftlesa mEehnokjksa ds uke] firk dk uke muds vius&vius
fpUg vkSj uke&funsZ'ku i=ksa esa fn;s x;s irksa lfgr fgUnh o.kZekyk Øe esa fn;s x;s gksaxs]
fu/kkZfjr dk;ZØe ij fu;e 36 esa fofgr jhfr ls çnf'kZr dh tk;sxhA
41&çR;sd ernku xqIr eri= }kjk gksxk vkSj çR;sd vf/kdkjh] deZpkjh ;k dksbZ O;fä ftls
ernku djkus ds fy, ;k eri=ksa dh x.kuk ds fy, fu;qä fd;k x;k gks] ,slh dksbZ lwpuk
fdlh ,sls O;fä ;k O;fä;ksa dks tks bls çkIr djus ds fy, fof/kd :i ls vf/kd`r u gks]
ugha nsxk ;k ,slk dksbZ d`R; ugha djsxk] ftlls ernku dh xksiuh;rk çHkkfor gksrh gksA
42&dksbZ O;fä tks fuokZpu vf/kdkjh gS] ;k fuokZpu djkus ds fy, fu;qä fd;k x;k gS ;k
fdlh lfefr dk dksbZ vf/kdkjh ;k dksbZ iqfyl vf/kdkjh] ftls fuokZpu ds lapkyu esa
lgk;rk djus ds fy, fu;qä fd;k x;k gS] fuokZPku dh çfØ;k ds nkSjku ,slk dksbZ d`R;
ugha djsxk] ;k fdlh ernkrk ;k vH;FkhZ dks bl çdkj çHkkfor ugh djsxk] ftlls fdlh
mEehnokj ds fuokZpu esa lQy gksus dh lEHkkouk esa o`f) ;k gzkl gksrk gksA
43&¼1½ tgka fof/kekU; uke&funsZ'kuksa dh la[;k fuokZfpr fd;s tkus okys O;fä;ksa dh la[;k ds
cjkcj ;k vf/kd u gks] ogka fuokZpu vf/kdkjh] uke okilh ds i'pkr~ rRdky mlh
fnukad dks mUgs lE;d~ :i ls fuokZfpr ?kksf"kr djsxk%
¼2½ tgka fof/kekU; uke&funsZ'kuksa dh la[;k fuokZfpr fd;s tkus okys O;fä;ksa dh la[;k ls
vf/kd gks] og fuokZpu vf/kdkjh fu;r~ le; ,oa fnukad dks ernku djkus dk çcU/k
djsxkA
¼3½ çR;sd ernkrk dks ,d 'kykdk i= fn;k tk;sxk] tks vk;ksx ds }kjk eqfnzr gksxk]
ftlij fgUnh o.kkZuqØe ds vuqlkj fuokZpu yM+us okys mEehnokjksa dks vkoafVr pquko

<!-- page 34 -->

fpUg eqfnzr gksxkA blesa ,d [kkyh LrEHk ernkrk }kjk ml O;fä ;k mu O;fä;ksa ds
uke ds lkeus] ftUgsa og ernku djuk pkgs] ,d fpUg (X)vafdr djus ds fy, Hkh
gksxkA
¼4½ 'kykdk&i= Øekafdr gksaxs vkSj mu ij lfefr dh eksgj vkSj lEc) ernku dsUnz ds
fuokZpu vf/kdkjh@ernku vf/kdkjh ds gLRkk{kj Hkh gksaxsA
¼5½ ernku xqIr 'kykdk i= }kjk gksxkA ernkrk ml mEehnokj ds uke ds lkeus] ftls
og ernku djuk pkgrk gS] ,d Økl dk fpUg (X)yxk;sxk vkSj rn~mijkUr 'kykdk
i= dks xqIr :i esa 'kykdk isVh esa Mku nsxkA
¼6½ çR;sd ernkrk ds mrus er gksaxs] ftrus O;fä;ksa dk fuokZpu fd;k tkuk gS fdUrq dksbZ
ernkrk fdlh ,d mEehnokj dks ,d ls vf/kd er ugh nsxkA
¼7½ fuokZpu yM+us okyk dksbZ mEehnokj ;k mldk çkf/kd`r vfHkdrkZ 'kykdk i= tkjh fd;s
tku ds iwoZ fuokZpu vf/kdkjh dks çR;sd vkifÙk ds fy, nl :i;s dh Qhl nsdj
ernkrk ds vfHkKku ds lEcU/k esa vkifÙk dj ldrk gSA
¼8½ fuokZpu vf/kdkjh vkifÙk dh laf{kIrr% tk¡p djsxk vkSj ;fn ,slh tk¡p ds i'pkr~
mldh ;g jk; gks fd vkifÙk çekf.kr ugh gksrh gS] rks og vkifÙkd`r O;fä dks
'kykdk i= nsxk ftlds i`"B ij fuokZpu vf/kdkjh viuh gLrfyfi esa 'kCn ^^vkifÙkd`r
er**i`"Bkafdr djsxk vkSj gLrk{kj djsxkA
¼9½ ,slk çR;sd O;fä] mifu;e ¼3½ ds v/khu 'kykdk i= fn;s tkus ds iwoZ fofufnZ"V çi=
esa ,d lwph esa vius ls lEcfU/kr çfof"V ds lkeus viuk gLrk{kj djsxk ;k ;fn fuj{kj
gks rks og vius vaxwBs dk fu'kku yxk;sxkA
¼10½ mifu;e ¼8½ ds v/khu 'kykdk i= çkIr gksus ij lEc) O;fä 'kykdk i= ij ml
mEehnokj ds uke ds lkeus] ftls og er nsuk pkgrk gS] xqIr :i ls Økl dk fpUg
(X)yxkdj viuk er vfHkfyf[kr djsxk vkSj 'kkykdk i= fuokZPku vf/kdkjh dks nsxk
tks mls rqjUr bl ç;kstuksa ds fy, fo'ks"k :i ls j[ks x, fyQkQs esa j[ksxkA
¼11½ ;fn dksbZ ,slk O;fä tks Lo;a dks ernkrk lwph esa fn;s x;s fdlh fof'k"V ernkrk :i
esa crk;s] ,sls ernkrk ds :i esa] nwljs O;fä }kjk igys ls gh er nsus ds i'pkr~]
'kykdk i= ds fy, vkosnu djrk gS] rks mls fuokZkpu vf/kdkjh dks vius igpku ds
lEc) esa lek/kku djus ds i'pkr~ ,d 'kykdk i= fn;k tk;sxk] ftlds i`"B Hkkx ij
fuokZpu vf/kdkjh }kjk viuh gLRkfyfi esa 'kCn ^^fufonÙk 'kykdk i=** i`"Bkafdr fd;k
tk;sxk vkSj gLrk{kj fd;k tk;sxkA
¼12½ çR;sd ,slk O;fä] fufonÙk 'kkykdk i= fn, tkus ds iwoZ fofufnZ"V çi= esa ,d lwph
esa vius ls lEcfU/kr çfof"V ds lkeus viuk gLRkk{kj djsxk ;k ;fn og fuj{kj gks rks
og vius vaxwBs dk fu'kku yxk;sxkA
¼13½ mifu;e 11 ds v/khu 'kykdk i= çkIr gksus ij og O;fä 'kykdk i= ij ml
mEehnokj ds uke ds lkeus] ftls og er nsuk pkgrk gS] xqIr :i ls Økl dk fpUg
(X)yxkdj viuk er vfHkfyf[kr djsxk vkSj fufonÙk 'kykdk i= fuokZpu vf/kdkjh
dks nsxk tks mls rqjUr bl ç;kstu ds fy, fo'ks"k :i ls j[ks x, fyQkQs esa j[ksxkA

<!-- page 35 -->

¼14½ ernku djus okys ernkrk dks vius er dks ç;ksx fd;s tkus ds iwoZ vk;ksx }kjk
fufnZ"V igpku i=ksa esa ls fdlh ,d igpku i= ls fuokZpu vf/kdkjh dks vius
igpku ds lEcU/k esa lUrq"V fd;k tkuk vfuok;Z gksxkA
¼15½ ;fn gLrk{kfjr eri= cp tkrk gS rks mls ,d vyx fyQkQs esa j[kk tk;sxk vkSj
ernku ds i'pkr~ fu/kkZfjr çk:i ij ç;ksx fd;s x;s eri=] gLrk{kfjr 'ks"k eri=]
'ks"k lkns eri= vkfn dh lwpuk Hkjdj fyQkQs esa j[kk tk;sxkA
¼16½ fuokZpu vf/kdkjh }kjk Mk;jh 'kkfUriw.kZ <ax ls fuokZpu lEiUu gksus dh fLFkfr esa
fVIi.kh vafdr djrs gq, Mk;jh dks vyx fyQkQs esa vyx j[kk tk;sxkA mä Mk;jh
dks fuokZpu ifj.kke ?kksf"kr gksus ds i'pkr~ lEcfU/kr vfHkys[kksa ds lkFk lqjf{kr
vfHkj{kk esa fu/kkZfjr vof/k rd j[kk tk;sxkA
44&¼1½¼d½ ernku lekIr gksus ds i'pkr~ rqjUr erksa dh x.kuk dh tk;sxh vkSj ;fn
ernku lekIr gksus ds i'pkr~ rqjUr erx.kuk djuk lEHko u gks rks] er isfV;k¡
fuokZpu vf/kdkjh }kjk eksgj cUn dj nh tk;sxh vkSj fudVLFk iqfyl Fkkus esa fujkin
vfHkj{kk esa j[kh tk;sxhA mEehnokj ;k mldk vfHkdrkZ Hkh viuh eksgj] ;fn ,slk pkgs]
yxk ldrk gSA
¼[k½fufonÙk er ,oa vkifÙkd`r er dh x.kuk mUgha ifjfLFkfr;ksa esa dh tk;sxh tc dqy iM+s
erksa ls ifj.kke ?kksf"kr fd;k tkuk lEHko u gks vFkkZr~ fdUgh nks ;k vf/kd mEehnokjksa
ds erks dh la[;k cjkcj gks tk;sA
¼2½ dksbZ 'kykdk&i= vLohdkj dj fn;k tk;sxk] ;fn&
¼1½ ml ij ernkrk dh igpku ds fy, dksbZ gLRkk{kj gks]
¼2½ ml lfefr dh eksgj vkSj lEc) ernku dsUnz ds fuokZpu vf/kdkjh@ernku
vf/kdkjh dk gLrk{kj u gks]
¼3½ ml ij ernku bafxr djus dk dksbZ fpUg u gks]
¼4½ ml ij Hkjs tkus okys LFkku@LFkkuksa dh la[;k ls vf/kd fpUg gks]
¼3½ ;fn fdlh 'kykdk&i= in mEehnokj ;k mEehnokjksa ds fy, fpUg bl çdkj gks ftlls
;g Li"V u gks fd fdu mEehnokjksa dks er fn;k x;k gS rks mls vLohdkj dj fn;k
tk;sxkA
¼4½ fuokZpu&vf/kdkjh] x.kuk iwjh gks tkus ds i'pkr~ ;Fkk'kh?kz] çR;sd mEehnokj }kjk çkIr
erks dh la[;k crkrs gq, fuokZpu ifj.kke dh ?kks"k.kk djsxkA
¼5½ cjkcj&cjkcj er gksus dh fLFkfr esa ekeys dk fofu'p; ipkZ Mkydj fd;k tk;sxkA
Li"Vhdj.k&fuokZpu vf/kdkjh }kjk leku jax ,oa vkdkj dh iphZ ij mEehnokjksa ds
uke fy[kdj rFkk iPkhZ dks bl çdkj eksM+dj dh mEehnokj dk uke i<+k u tk lds]
'kykdk i= isVh esa Mkysxk vkSj mEehnokj ls fHkUuk fdlh vU; O;fä ls isVh ls ,d iphZ
fudyok;sxkA ml iphZ ij vafdr uke okys mEehnokj dks fot;h ?kksf"kr fd;k tk,xkA
¼6½ fuokpZu&vf/kdkjh] fuokZfpr mEehnokjksa dh lwph lfefr ds lwpuk iÍ ij vkSj ,sls
lkoZtfud LFkku ij Hkh tgka og mfpr le>s] çnf'kZr djsxk%

<!-- page 36 -->

çfrcU/k ;g gS fd mÙkj çns'k lgdkjh xzke fodkl cSad fy0] y[kuÅ dh 'kk[kkvksa ;k
,slh lfefr;ksa dh fLFkfr esa ftudk dk;Z{ks= ,d ls vf/kd ftys esa gks] lwph dk çn'kZu
,slh lgdkjh lfefr ds 'kk[kk dk;kZy; ;k mi dk;kZy; esa fd;k tk;sxkA
¼7½ mifu;e ¼6½ ds v/khu rS;kj dh xbZ lwph dh ,d çfrfyfi ftyk lgk;d lgdkjh
fuokZpu vf/kdkjh] vk;ksx ;k lEcfU/kr lgdkjh lfefr ds lfpo@çcU/k funs'kd }kjk
çkf/kd`r fdlh vf/kdkjh dks Hksth tk;sxhA
¼8½ fuokZpu lEcU/kh ç;qä “kykdk i= vkSj vU; vfHkys[k fdlh fyQkQs ;k vk/kku
¼dUVsuj½ esa j[ks tk;saxs vkSj fuokZPku vf/kdkjh@ernku vf/kdkjh mUgas lfefr ds
lfpo@çcU/k funs'kd dks Hkst nsxk] tks mldh çkfIr Lohdkj djsxk vkSj ;fn fuokZpu
ds lEcU/k esa dksbZ fookn ftyk eftLVªsV vFkok vk;ksx dks fufnZ"V u fd;k tk; rks nks
ekg rd mldh vfHkj{kk ds fy, mÙkjnk;h gksxk%
çfrcU/k ;g gS fd fdlh fuokZpu okn vFkok fdlh U;k;ky; esa fuokZpu ;kfpdk
ds yfEcr u jgus dh fLFkfr esa lfefr ds lfpo ;k çcU/k funs'kd] tSlh Hkh fLFkfr gks]
ds }kjk ,d o"kZ O;rhr gks tkus ij ml u"V dj fn;k tk;sxkA
vxzrj çfrcU/k ;g gS fd lfpo ;k çcU/k funs'kd] tSlh Hkh fLFkfr gks] dk ;g
mÙkjnkf;Ro gksxk fd vfHkys[kksa dks u"V fd;s tkus ds iwoZ vk;ksx }kjk fofgr çk:i ij
mldk laf{kIr fooj.k vafdr djs vkSj mls lgdkjh lfefr esa j[kk tk;sxkA
¼9½ fo'ks"k ifjfLFkfr;ksa ,oa vifjgk;Z dkj.kksa esa vk;ksx tuin dh lHkh vFkok fdlh oxZ ;k
oxksZ ;k fdlh fof'k"V lfefr dh er x.kuk vU; LFkku ij djkus ds funsZ'k ns Lkdrk
gS vkSj ,slh erx.kuk vk;ksx }kjk ;Fkk fu;r fnukad dks gh djk;h tk,xhA
v/;k;&5
lHkkifr@milHkkifr ,oa vU; lfefr;ksa dks Hksts tkus okys izfrfuf/k;ksa dk fuokZpu
Š 45&¼1½ lEcfU/kr lgdkjh lfefr dh izcU/k desVh ds lnL;ksa ds fuokZpu ifj.kke dh

?kks"k.kk ds Ik'pkr~ lHkkifr@milHkkifr ,oa vU; lfefr;ksa dks Hksts tkus okys
izfrfuf/k;ksa dk fuokZpu] fofufnZ"V vuqns'kksa vkSj fofufnZ"V fnukad ds v/khu djk;k
tk;sxk] ftldh lEiw.kZ izfØ;k ,slh gksxh] tSlk Åij mfYyf[kr fu;eksa esa micfU/kr dh
x;h gSA
¼2½ lHkkifr ,oa milHkkifr] izcU/k desVh ds fuokZfpr lnL;ksa esa ls fuokZfpr fd;s tk;saxsA
¼3½ izcU/k desVh ds lnL; vU; lgdkjh lfefr ds] ftldh og lgdkjh lfefr lnL; gks]
lkekU; fudk; esa lgdkjh lfefr dk izfrfuf/kRo djus ds fy, izfrfuf/k;ksa dk fuokZpu
lkekU; fudk; ds vgZ lnL;ksa esa ls djsaxsA
dk;Zdky%&
46&¼1½ izR;sd lgdkjh lfefr dh izcU/k desVh dk dk;Z dky 5 o"kZ gksxk] ftldh x.kuk
mlds dk;ZHkkj xzg.k djus dh frfFk ls dh tk;sxhA

<!-- page 37 -->

Li"Vhdj.k&izcU/k desVh dk dk;Zdky lekIr gksus ds iwoZ fdlh lgdkjh lfefr dk
fuokZpu gksus dh n'kk esa uofuokZfpr izcU/k desVh dk dk;ZHkkj fuorZeku izcU/k desVh ds
dk;Zdky lekIr gksus ds Ik'pkr~ izcU/k desVh dk fuokZpu gksus dh fLFkfr esa izcU/k desVh
dk fuokZpu ifj.kke ?kksf"kr gksus ds fnol ls dk;Zdky dh x.kuk gksxhA
¼2½ lHkkifr@milHkkifr dk dk;Zdky izcU/k desVh ds dk;Zdky ds lgfOkLrkjh gksxkA
¼3½ lg;ksftr lnL; dk dk;Zdky izcU/k desVh ds dk;Zdky ds lgfoLrkjh gksxkA
izfrcU/k ;g gS fd ;fn izcU/k desVh dk dk;Z dky mlds ekSfyd dk;Zdky ds vk/ks
ls de gks rks izcU/k desVh esa gqbZ fdlh vkdfLed fjfä dh iwfrZ ml lgdkjh lfefr ds
vgZ lnL;ksa esa ls ftlesa vkdfLed fjfä gqbZ gS] izcU/k desVh }kjk uke&funsZ'ku }kjk dh
tk ldrh gSA
Š 'kklukns'k la[;k&662@49&01&2017&8¼56½&13 Vhlh&1]y[kuÅ] 26ebZ] 2017

v/;k;&6
vugZRkk
47&¼1½ dksbZ Hkh O;fä fdlh lgdkjh lfefr dh izcU/k desVh dk lnL; gksus ;k cus jgus
dk ik= u gksxk] ;fn&
¼d½ mldh vk;q 21 o"kZ ls de gks(
¼[k½ og fnokfy;k ?kksf"kr gks(
¼x½ og fod`r fpÙk dk gks(
¼?k½ mls] vk;ksx dh jk; esa uSfrd iru ls lEcfU/kr vijk/k ds fy, nks"kh Bgjk;k x;k gks
vkSj ,slh nks"k flf) vihy esa jn~n u dh x;h gksa(
¼³½ og ;g vk;ksx dh jk; esa] mlds ifjokj dk dksbZ lnL; fucU/kd dh vuqKk ds fcuk]
lgdkjh lfefr ds dk;Z{ks= ds Hkhrj mlh izdkj dk dkjksckj djuk 'kq: djs ;k djrk
gks] tSlk lgdkjh lfefr }kjk Lo;a fd;k tk jgk gks(
¼p½ og vf/kfu;e ;k lgdkjh lfefr dh mifof/k;ksa ds micU/kksa ds izfrdwy lgdkjh lfefr
ds lkFk dksbZ O;ogkj ;k lafonk djs(
¼N½ og lgdkjh lfefr ds v/khu ;k fdlh vU; lgdkjh lfefr tks ,slh lfefr ls lEc)
gks] ds v/khu ;k dksbZ ykHk dk in Lohdkj djs ;k /kkj.k djrk gks(
izfrcU/k ;g gS fd] ;g izfrcU/k ,sls mRikndksa ;k deZdkjksa dh lfefr;ksa ij ykxw
ugha gksxk] ftudks jkT; ljdkj us vuqKk ns nh gks fd os viuh mifof/k;ksa esa deZpkfj;ksa
}kjk lgdkjh lfefr ds izcU/k esa Hkkx ysus dh O;oLFkk dj ldrs gS(
¼t½ og lgdkjh lfefr ds lkekU; fudk; dk lnL; u gks(
izfrcU/k ;g gS fd] bl [k.M ds micU/k vf/kfu;e dh /kkjk 29 dh mi/kkjk ¼6½ ,oa
¼8½ ds vUrxZr vkus okys o`fRrd O;fä;ksa ds lg;kstu ij ykxw u gksaxs(
¼>½ og vf/kfu;e ;k fu;eksa ds v/khu fdlh vijk/k ds fy, nks"kh fl) fd;k x;k gks] tc
rd fd nks"k flf) ds fnukad ls rhu o"kZ dh vof/k O;rhr u gks x;h gks(
¼¥½ og ,slk O;fä gks] ftlds fo:) fdlh lgdkjh lfefr ds vf/kfu;e dh /kkjk 91 ds
v/khu vkns'k izkIr dj fy;k gks vkSj ml vkns'k dh iwfrZ u gqbZ gks(

<!-- page 38 -->

¼V½ og vius }kjk fy;s x;s _.kksa ds lEcU/k esa lgdkjh lfefr dk ¼de ls de 6 ekl dh
vof/k ls½ ckdhnkj gks] ;k og lgdkjh lfefr dk vf/k&fu.khZr _.kh gks(
¼B½ og ,d gh le; esa rhu lgdkjh lfefr;ksa vFkkZr~ ,d izkFkfed ,d dsUnzh; vkSj ,d
'kh"kZ lgdkjh lfefr dh izcU/k desVh dk igys ls gh lnL; gks] fQj Hkh og rhu ls
vf/kd lgdkjh lfefr;ksa dh izcU/k desVh dh lnL;rk ds fy, pquko yM+us ds fy,
gdnkj gksxkA Åij fofufnZ"V rhu ls vf/kd lfefr;ksa dh izcU/k desVh esa mlds
fuokZfpr gksus dh n'kk esa mls ,d ekg ds Hkhrj ,slh lfefr ;k lfefr;ksa dh izcU/k
desVh ls R;kxi= nsuk iM+sxk rkfd og rhu ls vf/kd lfefr;ksa dh izcU/k desVh dk
lnL; u cuk jg ldsA ;fn og fofufnZ"V vof/k ds Hkhrj R;kxi= nsus essa foQy jgrk
gS rks ,slh vof/k dh lekfIr ij ;g le>k tk;sxk fd mlus ,d 'kh"kZ lgdkjh lfefr
vkSj ,d dsUnh; lgkdjh lfefr vkSj ,d izkFkfed lgdkjh lfefr] ftl ij og ckn
esa fuokZfpr gqvk gS] ds flok; leLr lgdkjh lfefr ls R;kxi= ns fn;k gS(
¼M½ og jktdh; lsok ;k fdlh lgdkjh lfefr dh lsok ;k fuxfer fudk; ls diV]
nqjkpj.k ;k v'kqfprk djus ds fy, inP;qr fd;k x;k gks vkSj inP;qfr dk ,slk vkns'k
vihy esa jn~n u fd;k x;k gks(
¼<+½ og ,slh fdlh lgdkjh lfefr ds fucU/ku ds izkFkZuki= esa lfEefyr gks ;k mldh
izcU/k desVh dk lnL; jgk gks] tks fucU/kd }kjk /kkjk 72 dh mi/kkjk ¼2½ ds [k.M
¼d½ ds v/khu bl vk/kkj ij lekfIkr dj nh x;h gks fd lgdkjh lfefr dk] fucU/ku
diViwoZd djk;k x;k Fkk vkSj fucU/kd dk ,slk vkns'k vihy esa mRØfer u fd;k
x;k gks(
¼.k½ og vf/kfu;e ;k fu;e ;k lgdkjh lfefr dh mifof/k;ksa ds fdlh micU/k ds v/khu
vU;Fkk vugZ gks(
¼r½ ;fn og fdlh xSj _.k lgdkjh lfefr] tks dsUnzh; lgdkjh cSad vFkok m0iz0
dksvkijsfVo cSad dk izfrfuf/k gS vkSj og lgdkjh lfefr 90 fnuksa ls vf/kd dh
cdk;snkj gS(
¼Fk½ ;fn og izkjfEHkd d`f"k _.k lgdkjh lfefr esa dsoy tek djus ds mn~ns'; ls lnL;
cuk gks vkSj mlds }kjk ,slh lfefr esa tek /kujkf'k ,d gtkj :Ik;s ls de gks x;h
gks(
¼n½ vk;ksx dh jk; esa fdlh O;fä }kjk fuokZpu esa Hkz"V vkpj.k vFkok tkucw> dj dksbZ
diViw.kZ d`R; vFkok dwV jfpr vfHkys[k ds vk/kkj ij fuokZpu esa Hkkx fy;k x;k gks]
ftlds izHkko esa mldh mEEkhnokjh ,oa mlds ifj.kke ij izHkko iM+k gks(
¼/k½ ;fn mls fdlh vijk/k ds fy, fdlh U;k;ky; ls nks o"kZ ls vf/kd dk dkjkokl gqvk
gks vkSj ftlds fo:) dksbZ LFkxukns'k izkIr u fd;k x;k gks ;k fdlh l{ke U;k;ky;
}kjk vkns'k dks vikLr u fd;k x;k gks(
Š¼u½ og fdlh lgdkjh cSad dk iwoZ dkfeZd gks]
izfrcU/k ;g gS fd ;g [k.M] [k.M ¼i½ esa mfYYkf[kr 16 ftyk lgdkjh cSadksa dh
izcU/k desVh ds lEcU/k esa ykxw gksxk]

<!-- page 39 -->

¼i½ ;g ykblsUl gsrq foÙkh; lgk;rk@vuqnku@va'kiWwth@_.k izkIr fuEufyf[kr 16 ftyk
lgdkjh cSad dh izcU/k desVh ds fuokZpu ds iwoZorhZ 10 o"kZ iwoZ rd dh vof/k esa cSad
dh izcU/k desVh dk lnL; jgk gks%&
ftyk lgdkjh cSad fy0] nsofj;k] cgjkbp] fl}kFkZuxj] lqYrkuiqj] tkSuiqj] xksj[kiqj]
vktex<+] cfy;k] cLrh] gjnksbZ] Qrsgiqj] lhrkiqj] okjk.klh] bykgkckn] xkthiqj ,oa
QStkcknA
Š 'kklukns'k la[;k&859@49&01&2016&8¼56½&13 Vhlh&1]y[kuÅ] 31ebZ] 2016

¼2½ fdlh lgdkjh lfefr dh izcU/k desVh dk dksbZ lnL;] tks izcU/k desVh dh rhu
yxkrkj cSBdksa esa fcuk fdlh mfpr dkj.k ds vuqifLFkr jgs] izcU/k desVh dk lnL;
cus jgus dk gdnkj u gksxkA
¼3½ mifu;e ¼2½ ds micU/k fdlh lgdkjh lfefr dh izcU/k desVh ds uke&fufnZ" V ;k
insu lnL; ij ykxw ugha gksxsa(
¼4½ dksbZ O;fä tks fdlh lgdkjh lfefr dh izcU/k desVh dh lnL;rk ds fy, fuokZpu
yM+s fdUrq ,sls fuokZpu esa gkj tk;] vkesyu ;k uke&funsZ'ku }kjk izcU/k desVh dk
lnL; gksus ds fy, ik= u gksxkA
¼5½ mifu;e ¼1½ ds v/khu fu/kkZfjr vugZrk,a fuEufyf[kr 'krksZa ds v/khu ykxw gksaxh(
¼d½[k.M t esa fu/kkZfjr vugZrk,a izcU/k desVh ds fdlh uke&fufnZ"V ;k insu lnL; ;k
izcU/k desVh ds ,sls lg;ksftr lnL; ij ykxw u gksaxh ftlds lg;kstu gsrq lgdkjh
lfefr dh mifof/k;ksa ds v/khu lkekU; fudk; dh lnL;rk dksbZ 'krZ ugha Fkh(
¼[k½mifu;e ¼1½ ds [k.M ¼?k½ ;k [k.M ¼M½ esa fu/kkZfjr vugZrk nks"k flf) ds v/khu]
vFkZn.M nsus ;k nks"k fl) gksus ij n.M ik ysus ds ;k inP;qfr ds vkns'k ds ckn] tSlh
Hkh fLFkfr gks] 5 o"kZ dh lekfIr ds Ik'pkr~ lekIr gks tk;sxh(
¼x½ mifu;e ¼1½ ds [k.M ¼[k½ esa nh x;h gqbZ vugZrk fdlh ,sls ljdkjh deZpkjh ij ykxw
u gksxh] ftldks /kkjk 34 ds vUrxZr fdlh lgdkjh lfefr dh izcU/k desVh esa
ukekafdr fd;k x;k gks(
¼?k½ dkjkxkj ds cfUn;ksa ds dY;k.k ,oa iquokZl ds fy, tsy esa cuh lgdkjh lfefr;ksa dh
izcU/k desVh ds lnL;ksa ds lEcU/k esa fu;e 47 ds mifu;e ¼1½ dk mi[k.M ¼d½] ¼N½]
¼>½] ¼M½] o ¼/k½ ykxw ugha gksaxs(
48&fdlh lgdkjh lfefr dh izcU/k desVh dk ;g drZO; gksxk fd ,slk dksbZ O;fä tks
fdlh Hkh izdkj vugZ gks tk;] izcU/k desVh dk lnL; dk in /kkj.k u fd;s jgsA T;ksa
gh ;g rF; izcU/k desVh dh tkudkjh esa vk;s] fd dksbZ lnL; fdlh izdkj vugZ gks
x;k gS] pkgs og ,sls lnL; ds iwoZ ;k mlds Ik'pkr~ vugZ gqvk gks] desVh bl fo"k;
ij ,d cSBd esa fopkj djsxh] tks bl iz;kstu ds fy, cqykbZ tk;sxhA ,slh cSBd dh
dk;Zlwph dh ,d izfr ml lnL; dks] ftlds fo:) dkjZokbZ djus dk izLrko gks]
O;fDrxr :Ik ls ;k jftLVªh Mkd }kjk ¼izkIr vfHkLohd`fr½ nh tk;sxhA ;fn lEcfU/kr

<!-- page 40 -->

O;fä dks ,slh vugZrk ds dkj.k desVh dh lnL;rk ls gVkus dk ladYi ikfjr gks
tk;s rks ,sls LkadYi dh ,d izfr Hkh lEcfU/kr O;fDr dks jftLVªh Mkd }kjk ¼izkIr
vfHkLohd`fr½ Hksth tk;sxh vkSj rn~mijkUr ,sls lnL; dks fdlh vU; izdkj ls izcU/k
desVh ds lnL; ds :Ik esa izcU/k desVh dh fdlh cSBd esa dk;Z djus ;k mifLFkfr
gksus dh vuqKk ugha nh tk;sxhA ,sls lnL; dk in fjDr ?kksf"kr fd;k tk;sxkA ;fn
og O;fDr ,slh dk;Zokgh ls {kqC/k gks rks og uksfVl izkIr gksus ds fnukad ls 30 fnu ds
Hkhrj vf/kfu;e rFkk fu;eksa ds micU/kksa ds v/khu iapfu.kZ; djk ldrk gSA
49&¼1½ ;fn fdlh lnL; ;k lnL;ksa dh vuZgrk lEcU/k esa laKku esa vkus ij izcU/k desVh
}kjk ;Fkk&fu;r~ dk;Zokgh ;qfDRklaxr le; ij ugha dh tkrh gS] rks vk;ksx dks ;g
vf/kdkj gksxk fd vf/kfu;e dh /kkjk ¼38½ ds v/khu ,sls vugZ lnL; ;k lnL;ksa dh
izcU/k lfefr ls fudkys tkus ds fy, fucU/kd vFkok izkf/kd`r vf/kdkjh dks funsZf'kr
dj ldrk gSA
¼2½ vk;ksx ,sls funsZ'ku ds Ik'pkr~ fucU/kd vFkok izkf/kd`r vf/kdkjh dk ;g drZO; gksxk
fd /kkjk 38 esa fofgr izfØ;k dk ikyu djus ds fy, ;Fkk vko';d dk;Zokgh djsxkA
v/;k;&7
fuokZpu okn
50&¼1½ fdlh lgdkjh lfefr ds fdlh inkf/kdkjh ;k izfrfuf/k ds fuokZpuls {kqC/k i{kdkjksa
}kjk vf/kfu;e dh /kkjk 70 ds v/khu fuokZpu okn izLrqr fd;k tk ldrk gS&tks
fuEukuqlkj vfHkfn"V fd;k tk;sxk&
¼d½ izkjfEHkd ,oa dsUnzh;@tuin Lrjh; lfefr;ksa dh n'kk esa lEcfU/kr ftyk
eftLVsªV dks tks izkjfEHkd lgkdjh lfefr dh n'kk esa fookn dk fu.kZ; Lo;a dj ldrk gS
vFkok vius v/khu ijxukf/kdkfj;ksa esa ls fdlh ,d dks] ;FkkfLFkfr] e/;LFk vFkok e/;LFk
e.My ds v/;{k ds :i esa dk;Z djus ds fy, fu;qä dj ldrk gS vkSj dsUnzh; lgdkjh
lfefr;ksa dh n'kk esa ftyk eftLVªsV fookn dk fu.kZ; Lo;a dj ldrk gS vFkok vius
v/khu vij ftykf/kdkjh esa ls fdlh ,d dks] ;FkkfLFkfr] e/;LFk vFkok e/;LFk e.My ds
v/;{k ds :i esa dk;Z djus ds fy, fu;qä dj ldrk gSA
¼[k½ fdlh jkT; Lrjh;@'kh"kZ lgdkjh lfefr dh n'kk esa vk;ksx dks fd;k tk;sxk]
tks fookn dk fu.kZ; Lo;a vFkok fdlh fuokZpu vk;qä dks e/;LFk ;k e/;LFk e.My ds
v/;{k ds :i esa fu;qä dj ldrk gSA
¼2½ fdlh lgdkjh lfefr ds fuokZpu ds lEcU/k esa flok; fuEufyf[kr vk/kkj ds e/;LFk
}kjk ;k vU;Fkk :i ls vkifÙk ugha dh tk ldsxh&
¼d½ fuokZpu esa Hkz"Vkpkj] fj'or~ ;k vuqfpr izHkko dk iz;ksx gksus ds dkj.k og
fuokZpu fu"i{k ugha gqvk gS];k
¼[k½ fuokZpu ds ifj.kke ij fuEufyf[kr dkj.kksa ls lkjoku~ izHkko iM+k gks%&
¼1½ fdlh uke&funsZ'ku i= dks vuqfpr :i ls Lohdkj djus] ;k vLohdkj djus ds
}kjk] ;k

<!-- page 41 -->

¼2½

er dks vuqfpr :i ls xzg.k djus ;k xzg.k djus ls bUdkj djus ;k jn~n djus ds
}kjk] ;k
¼3½ vf/kfu;e ;k fu;ekoyh ;k lfefr dh mifof/k;ksa ds micU/kksa dk vuqikyu djus esa
?kksj pwd djus ds }kjkA
Li"Vhdj.k%&bl fu;e ds iz;kstukFkZ Hkz"Vkpkj] fj'or~ ;k vuqfpr izHkko ds ogh
vFkZ gksxs] tks yksd izfrfuf/kRo vf/kfu;e 1951 dh /kkjk 123 ds v/khu izR;sd ds
fy, fn;s x;s gSaA
¼4½ fuokZpu ls lEcf/kr dksbZ Hkh okn fuokZpu ifj.kke dh ?kks"k.kk ds 45 fnu ds Hkhrj
O;fFkr i{k }kjk fufnZ"V fd;k tk ldsxkA
¼5½ fu;ekoyh esa fdlh vU; ckr ds gksrs gq, Hkh fuokZpu okn nkf[ky djus okys oknh
}kjk jkT; ljdkj }kjk fu;r~ fd;s x;s ys[kk 'kh"kZd esa fuEuor~ 'kqYd tek dj ewy
jlhn okn ds lkFk layXu dj izLrqr dh tk;sxh%&
d& izkjfEHkd lgdkjh lgdkjh lfefr;ksa dh fLFkfr esa&:0 ,d gtkj
[k& tuin@dsUnzh; lgdkjh lfefr;ksa dh fLFkfr esa&:0 nks gtkj
x& jkT; Lrjh;@'kh"kZ lgdkjh lfefr dh fLFkfr esa&:0 ikap gtkj
izfrcU/k ;g gS fd 'kqYd dh jlhn izLrqr u fd;s tkus ij okn Lohdkj ugha fd;k
tk;sxkA
v/;k;&8
vijk/k ,oa 'kkfLr;ka
51&lgdkjh lfefr dh fuokZfpr izcU/k desVh dk dk;Zdky lekIr gksus ds iwoZ lfpo
vFkok izcU/k funs’kd tSlh Hkh fLFkfr gks ds }kjk vf/kfu;e dh /kkjk 29 dh mi/kkjk ¼4½
,oa fu;e 4 ds v/khu fufnZ"V vof/k ds Hkhrj lwpuk u fn;s tkus vFkok fuokZpu {ks=ksa
ds vo/kkj.k gsrq ftyk lgk;d lgdkjh fuokZpu vf/kdkjh vFkok e.Myh; lgdkjh
fuokZpu vf/kdkjh vFkok vk;ksx vFkok mlds izkf/kd`r vf/kdkjh dks visf{kr leLr
lwpuk,a u fn;s tkus ij] vk;ksx }kjk izkjfEHkd lgdkjh lfefr dh fLFkfr esa lEcfU/kr
lfpo ;k izcU/k funs’kd] tSlh Hkh fLFkfr gks ds fo:) :0 ikap gtkj rd dk vFkZn.M
yxk;k tk ldrk gS rFkk ftyk@dsUnzh; ,oa jkT; Lrjh;@’kh"kZ lgdkjh lfefr dh
fLFkfr esa lEcfU/kr lfpo ;k izcU/k funs’kd] tSlh Hkh fLFkfr gks] ds fo:) :0 nl
gtkj rd dk vFkZn.M yxk;k tk ldrk gS vkSj vFkZn.M yxk;s tkus lEcfU/kr vkns’k
lEcfU/kr deZpkjh@vf/kdkjh dh pfj= iaftdk esa vafdr djrs gq, pLik dh tk;sxhA
izfrcU/k ;g gS fd vFkZn.M yxk;s tkus ds iwoZ lecfU/kr O;fä dks lquokbZ ,oa
viuk i{k j[ks tkus dk ;qfälaxr ,d volj vk;ksx }kjk iznku fd;k tk;sxkA
52&ftyk lgk;d lgdkjh fuokZpu vf/kdkjh@l{ke izkf/kdkjh }kjk vk;ksx dks fu/kkZfjr
le;kof/k ds Hkhrj tuin dh ,slh lgdkjh lfefr;ksa ftudh izcU/k desVh dk
dk;Zdky vkxkeh 4 ekl esa lekIr gks jgk gS] dh lwpuk u fn;s tkus vFkok vk;ksx
}kjk fdlh lfefr ;k lfefr;ksa ds fdlh oxZ ;k oxksZa dh lgdkjh lfefr;ksa ds fuokZpu
gsrq fnukad fu;r~ fd;s tkus ij fu/kkZfjr le;kof/k ds Hkhrj {ks= vo/kkj.k dh dkjZokbZ
u fd;s tkus ij lEcfU/kr vf/kdkjh ds fo:) vk;ksx }kjk :0 ikap gtkj rd dk

<!-- page 42 -->

vFkZn.M yxk;k tk ldrk gS vkSj vFkZn.M yxk;s tkus lEcfU/kr vkns’k lEcfU/kr
vf/kdkjh dh pfj= iaftdk esa vafdr djrs gq, pLik dh tk;sxh%
izfrcU/k ;g gS fd] vU; foHkkx ls lEcfU/kr lgdkjh lfefr;ksa ds fuokZpu ls
lEcfU/kr visf{kr lwpuk ,oa vfHkys[k ftyk lgk;d lgdkjh fuokZpu vf/kdkjh dks
lEcfU/kr foHkkx ds tuin Lrjh; vFkok vius foHkkx dh lgdkjh lfefr;ksa dks
iathd`r djus okys vf/kdkjh }kjk ;Fkkle; miyC/k u djk;s tkus ij lEcfU/kr
vf/kdkjh :0 ikap gtkj ds vFkZn.M dk nk;h gksxk vkSj vFkZn.M yxk;s tkus lEcU/kh
vkns’k lEcfU/kr vf/kdkjh dh pfj= iaftdk esa vafdr djrs gq, pLik dh tk;sxh%
vxzrj izfrcU/k ;g gS fd vFkZn.M yxk;s tkus ds iwoZ lECkfU/kr vf/kdkjh dks lquokbZ
,oa viuk i{k j[ks tkus dk ;qfälaxr ,d volj vk;ksx }kjk iznku fd;k tk;sxk%
vxzrj ;g Hkh izfrcU/k gS fd vFkZn.M yxk;s tkus ds i’pkr~ Hkh ;fn lEcfU/kr
vf/kdkjh }kjk vius drZO;ksa esa yxkrkj pwd dh tkrh gS rks ,sls vf/kdkjh ds fo:) vk;ksx
}kjk lEcfU/kr fu;qfä izkf/kdkjh dks vuq’kklukRed dkjZokbZ fd;s tkus dh vuq’kalk dh tk
ldrh gS vkSj fu;qfä izkf/kdkjh ds fy, vk;ksx dh vuq’kalk ij dkjZokbZ fd;k tkuk
ck/;dkjh gksxkA
53&ftyk lgk;d lgdkjh fuokZpu vf/kdkjh rFkk vU; fu;qfä vf/kdkfj;ksa }kjk vifjgk;Z
dkj.kksa dks NksM+dj vius drZO;ksa dk ikyu u fd;k tkuk vijk/k le>k tk;sxk]
ftlds nks"k fl) gksus ij tqekZus ds :i esa tks :0 nks gtkj rd dk gks ldrk gS] ;k
dkjkokl ls tks N% ekl rd gks ldrk gS vFkok nksuksa n.M ls n.Muh; gksxkA
54&fu;e&41 ds mYya?ku esa fd;k x;k dksbZ d`R; ;k nh x;h ;k izdV dh x;h lwpuk dks
vijk/k le>k tk;sxk vkSj ,sls O;fä ;k O;fä;ksa] ftuds fo:) ,slk vijk/k fl) gks
tk;] dkjkokl ls] tks N% ekl rd gks ldrk gS] ;k tqekZus ls tks :0 nks gtkj rd
gks ldrk gS ;k nksuksa ls nf.Mr fd;k tk;sxkA
55&fu;e&42 ds mYya?ku esa fd;s x;s fdlh d`R; ds fl) ik;s tkus ij vk;ksx lEcfU/kr
O;fä ds fo:) U;wure :0 nks gtkj vkSj vf/kdre :0 nl gtkj dk vFkZn.M vFkok
mldh pfj= iaftdk esa bl vk’k; dh izfrdwy izfof"V fd;s tkus dh vuq’kalk dj
ldrk gSA
56&fdlh lgdkjh lfefr dk fuokZpu yM+us okys mEehnokj }kjk diViw.kZ <ax ls dksbZ
rF; izLrqr fd;s tkus] fuokZpu lEcU/kh fdlh vfHkys[k dks fod`r djus ;k mlesa
ifjorZu djus ;k mldks u"V djrk gS vFkok ,slk fd;s tkus ds fy, fdlh dks
vfHkizsfjr djrk gS] ,slk d`R; vijk/k le>k tk;sxk vkSj nks"k fl) gksus ij nks o"kZ ls
vuf/kd ds dkjkokl ;k :0 ikap gtkj ds vFkZn.M ;k nksuksa ls n.Muh; gksxkA
57&bu fu;eksa esa mfYyf[kr fdlh vijk/k ds fd;s tkus ij] lEcfU/kr O;fä fo’ks"k izFke
lwpuk fjiksVZ lEcfU/kr ftyk lgk;d lgdkjh fuokZpu vf/kdkjh }kjk ;k mlds }kjk
izkf/kd`r fdlh jktif=r vf/kdkjh }kjk djk;h tk;sxhA
58&lgdkjh lfefr ds fuokZpu vf/kdkjh@lgk;d fuokZpu vf/kdkjh dk ;g drZO; gksxk
fd lfefr ds fuokZpu djk;s tkus esa mEehnokjksa vFkok fdlh vU; en esa izkIr /kujkf’k
vk;ksx }kjk fu;r~ dks"k vFkok fu;r~ izkf/kdkjh dks fuokZpu lekfIr ds ,d lIrkg ds

<!-- page 43 -->

Hkhrj gLrxr djsxk vkSj ,slk u fd;s tkus ij vk;ksx }kjk lEcfU/kr O;fä ds fo:)
vuq’kklukRed dkjZokbZ fd;s tkus dh vuq’kalk vFkok tqekZuk tks :0 ikap gtkj rd gks
ldrk gS] dk vFkZn.M vFkok nksuksa dj ldrk gSA
59&;fn vk;ksx dh jk; esa] fdlh mEehnokj }kjk fuokZpu esa Hkz"V vkpj.k tkucw>dj dksbZ
diViw.kZ d`R; vFkok dwVjfpr vfHkys[k ds vk/kkj ij fuokZpu esa Hkkx fy;k x;k gS]
ftlds izHkko ls mldh mEehnokjh ,oa mlds ifj.kke ij lkjoku~ izHkko iM+k gS rks
vk;ksx ,sls O;fä fo’ks"k@fuokZfpr lnL; dks vugZ ?kksf"kr dj ldrk gS rFkk Hkfo"; esa
fuokZpu esa Hkkx ysus gsrq de ls de 3 o"kZ ,oa vf/kdre 6 o"kZ ds fy, v;ksX; ?kksf"kr
dj ldrk gSA
60&d&;fn dksbZ O;fä] vk;ksx }kjk ml ij vkjksfir vFkZn.M dks fofuZfn"V vof/k ds
Hkhrj tek djus esa foQy jgrk gS rks lEcfU/kr fu;qfä izkf/kdkjh dk ;g drZO; gksxk
fd mDr /kujkf’k lEcfU/kr vf/kdkjh@deZpkjh ds osru ls dVkSRkh dj vk;ksx }kjk
fufnZ"V [kkrs esa tek dj vk;ksx dks lalwfpr djsxkA
vU; O;fä dh n’kk esa tqekZus dh /kujkf’k Hkw&jkTkLo ds cdk;s dh Hkkafr olwy dh
tk;sxhA
[k&mDr drZO;ksa dk vuqikyu u fd;s tkus ij vk;ksx] jkT; ljdkj dks lEcfU/kr
vf/kdkjh ds fo:) dkjZokbZ fd;s tkus dh vuq’kalk dj ldrk gSA
v/;k;&9
fofo/k
61&¼d½lgdkjh lfefr;ksa ds Lora=] LoPN ,oa fu"i{k fuokZpu djk;k tkuk lqfuf'pr djus
dh n`f"V ls vk;ksx tuin@e.My@lfefr ;k lfefr;ksa gsrq fuokZpu i;Zos{kd fu;qDr
dj ldrk gSA
¼[k½ lgdkjh fuokZpu i;Zos{kd ds vf/kdkj ,oa drZO; ds lEcU/k esa vk;ksx }kjk fuxZr
fn'kk&funsZ'k ck/;dkjh gksaxsA
62&lgdkjh lfefr ds fuokZpu gsrq fu;qDr fdlh Hkh fuokZpu vf/kdkjh@lgk;d fuokZpu
vf/kdkjh] ernku vf/kdkjh@x.kuk vf/kdkjh dks ;k=k HkRrk muds vius ewYk foHkkx ds
ctV ls ns; gksxkA
63&fdlh lgdkjh lfefr ds lfpo ;k izcU/k funs'kd ;k lgdkjh lfefr;ksa ds fdlh oxZ
;k oxkZsa ds fuokZpu djk;s tkus gsrq fdlh O;fDr fo'ks"k] ftls vk;ksx }kjk vf/kd`r
fd;k x;k gks] leqfpr jhfr ls fuokZpu lEiUu djk;s tkus esa vko';drkuqlkj] izf'k{k.k
,oa fuokZpu lkexzh ij y?kq O;; fd;k tkrk gS] rks ml O;; dh izfriwrhZ] ftyk
lgk;d lgdkjh fuokZpu vf/kdkjh }kjk ftyk lgdkjh fuokZpu vf/kdkjh ds vuqeksnu
ls dh tk;sxhA
64&d&fdlh lgdkjh lfefr ;k fdlh oxZ ;k oxksZa dh lgdkjh lfefr;ksa ds fuokZpu
djkus gsrq /kujkf'k dk fu/kkZj.k vk;ksx }kjk] fo'ks"k ;k lkekU; vkns'k ls vo/kkfjr fd;k
tk;sxk vkSj ;g /kujkf'k ml lgdkjh lfefr] ftldk fuokZpu fd;k tkuk gS] dh fuf/k
ls ns; gksxhA

<!-- page 44 -->

[k&lEcfU/kr lgdkjh lfefr dk lfpo vFkok izcU/k funs'kd] tSlh Hkh fLFkfr gks] drZO;
gksxk fd mDr /kujkf'k vk;ksx }kjk fu;r~ cSad [kkrk esa tek djsxk vkSj [k.M ¼d½ esa
vo/kkfjr 'kqYd tek djus dk izek.k&i= layXu djrs gq;s fuokZpu djkus dk vuqjks/k
djsxk]
izfrcU/k ;g gS fd vo/kkj.k 'kqYd tek u gksus dh fLFkfr esa lgdkjh lfefr dk
fuokZpu ugha djk;k tk;sxk vkSj ,slh fLFkfr esa fuokZpu u gks ikus gsrq lEcfU/kr foHkkx dk
l{ke vf/kdkjh mRrjnk;h gksxkA
65&lgdkjh lfefr;ksa ds fuokZpu fu;r jhfr ,oa fu"i{k :i ls djk;s tkus ds mn~ns'; ls
vk;ksx }kjk lgdkjh fuokZpu vkpkj lafgrk iz[;kfir dh tk ldrh gS tks fdlh
lgdkjh lfefr ;k lgdkjh lfefr;ksa ds fdlh oxZ ;k oxksZa gsrq fuokZpu fnukad
vf/klwfpr gksus dh frfFk ls vk;ksx }kjk fu;r fd;s x;s O;fDr ;k O;fDr;ksa ;k
izkf/kdkjh ;k izkf/kdkfj;ksa ij vk;ksx }kjk fu/kkZfjr frfFk rd izHkkoh jgsxhA
66&fuokZpu izfdz;k ds nkSjku fuokZpu ls lEcfU/kr lHkh vf/kdkjh@deZpkjh vk;ksx ds
fu;a=.k] i;Zos{k.k ,oa ekxZn'kZu ds v/khu gksaxsA
67&bl fu;ekoyh esa fuokZpu ls lEcfU/kr fdlh izkfo/kku ds lEcU/k esa la'k; dh fLFkfr esa
vk;ksx dk fofu'p; vfUre gksxkA
68&lgdkjh lfefr;ksa ds fuokZpu ds lEcU/k esa ,slk dksbZ fo"k; ftlds lEcU/k esa fu;eksa esa
dksbZ Li"V izkfo/kku mfYyf[kr u gks rks ,sls esa vk;ksx ds fn'kk&funsZ'k ykxw gksaxsA
69&;fn vk;ksx ds laKku esa dksbZ ,slk lUnHkZ yk;k tkrk gS] tks bl fu;ekoyh ds fdlh
izkfo/kku@micU/k ls vkPNkfnr u gks rks ,sls izdj.k ij vk;ksx }kjk ;Fkksfpr fu.kZ;
fy;k tk;sxk] tks vfUre vkSj ck/;dkjh gksxkA
70&bl fu;ekoyh ds izkfo/kkuksa ds vlaxr fdlh lgdkjh lfefr dh mifof/k;ksa esa fdlh
ckr ds gksrs gq;s Hkh bl fu;ekoyh ds izkfo/kku gh izHkkoh gksaxsA
vkKk ls]
nsck'kh"k i.Mk
izeq[k lfpoA

<!-- page 45 -->

Š

'kklukns'k la[;k&990@49&01&2017&8¼56½&13Vhlh&I y[kuÅ] fnukad 18-07-2017 }kjk
fu;e la[;k&12 ¼d½ esa fuEu izdkj la'kks/ku fd;k x;k gS ,oa 12 ¼[k½ fudky fn;k x;k gSA

Š 12&¼d½ lfefr dk lfpo vFkok ÁcU/k funs'kd le;&le; ij vk;ksx }kjk fn;s x;s funs'kksa
;k rRle; Áo`Ùk micU/kksa ds vuqlkj leLr ernkrkvksa dh lwph] ftuds uke ds lEeq[k
vf/kfu;e] bl fu;ekoyh vFkok mifof/k;ksa esa ;Fkk of.kZr dksbZ vugZrk,a] ;fn dksbZ gks]
mfYyf[kr dh tk;sxh] rS;kj djsxk vkSj fuokZpu ds fnukad ds 45 fnu iwoZ lE;d~ :Ik ls
ukekafdr lnL;] lk/kkj.k lnL; ;k lgkuqHkwfr lnL; lfEefyr fd;s tk;saxs%
izfrcU/k ;g gS fd ,slh lfefr;ksa] tks ifjlekiuk/khu gks vFkok izcU/k desVh ds
fuokZpu u gksus ds dkj.k fuyfEcr@vf/kØfer dh xbZ gksa] ds izfrfuf/k mDr ernkrk lwph esa
lfEefyr ugha fd;s tk;saxsA

Š 'kklukns'k la[;k&662@49&01&2017&8¼56½&13 Vhlh&1]y[kuÅ fnukad 26-052017fu;e 45 ¼1½ dks fuEu izdkj la'kksf/kr djrs gq;s izfrcU/kkRed [k.M fudky fn;k x;k
gSA
Š45&¼1½ lEcfU/kr lgdkjh lfefr dh izcU/k desVh ds lnL;ksa ds fuokZpu ifj.kke dh
?kks"k.kk ds Ik'pkr~ lHkkifr@milHkkifr ,oa vU; lfefr;ksa dks Hksts tkus okys
izfrfuf/k;ksa dk fuokZpu] fofufnZ"V vuqns'kksa vkSj fofufnZ"V fnukad ds v/khu djk;k
tk;sxk] ftldh lEiw.kZ izfØ;k ,slh gksxh] tSlk Åij mfYyf[kr fu;eksa esa micfU/kr dh
x;h gSA
¼2½ lHkkifr ,oa milHkkifr] izcU/k desVh ds fuokZfpr lnL;ksa esa ls fuokZfpr fd;s tk;saxsA
¼3½ izcU/k desVh ds lnL; vU; lgdkjh lfefr ds] ftldh og lgdkjh lfefr lnL; gks]
lkekU; fudk; esa lgdkjh lfefr dk izfrfuf/kRo djus ds fy, izfrfuf/k;ksa dk fuokZpu
lkekU; fudk; ds vgZ lnL;ksa esa ls djsaxsA
Š 'kklukns'k la[;k&859@49&01&2016&8¼56½&13 Vhlh&1]y[kuÅ fnukad 31-05-2016 }kjk fu;e
la[;k&47 ¼1½ ¼/k½ ds i'pkr fuEu izdkj c<+k;k x;k%&
47¼1½

¼u½og fdlh lgdkjh cSad dk iwoZ dkfeZd gks]
izfrcU/k ;g gS fd ;g [k.M] [k.M ¼i½ esa mfYYkf[kr 16 ftyk lgdkjh cSadksa dh izcU/k
desVh ds lEcU/k esa ykxw gksxk]
¼i½ ;g ykblsUl gsrq foÙkh; lgk;rk@vuqnku@va'kiWwth@_.k izkIr fuEufyf[kr 16 ftyk
lgdkjh cSad dh izcU/k desVh ds fuokZpu ds iwoZorhZ 10 o"kZ iwoZ rd dh vof/k esa cSad
dh izcU/k desVh dk lnL; jgk gks%&
ftyk lgdkjh cSad fy0] nsofj;k] cgjkbp] fl}kFkZuxj] lqYrkuiqj] tkSuiqj] xksj[kiqj]
vktex<+] cfy;k] cLrh] gjnksbZ] Qrsgiqj] lhrkiqj] okjk.klh] bykgkckn] xkthiqj ,oa
QStkcknA

<!-- page 46 -->
