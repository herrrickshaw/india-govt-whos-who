---
doc_id: "2e8edadf0393bfab"
source_url: "https://fms.aktu.ac.in/Resources/aktu/pdf/Recruitment/AKTU%20Instructions%2025-08-2026.pdf"
ministry: "Dr. A.P.J. Abdul Kalam Technical University, Lucknow, Uttar Pradesh"
title: ""
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8d6661f1bf9014fa"
---

<!-- page 1 -->

Mk0 ,0ih0ts0 vCnqy dyke izkfof/kd fo'ofo|ky;] mRrj izns'k
Tkkudhiqje foLrkj] lsDVj&11] lhrkiqj jksM] y[kuÅ&226031
foKkiu la[;k&,0ds0Vh0;w0@dql0dk0@Hk.Mkj@2026@2037

fnukad%24-08-2026

xSj&”kS{kf.kd inksa ij lh/kh HkrhZ
foKkiu la[;k&,0ds0Vh0;w0@dql0dk0@Hk.Mkj@2024@886 fnukad&15-03-2024 ds ek/;e ls
izdkf”kr xSj&“kS{kf.kd inksaa ds foKkiu dks vfrdzfer djrs gq, iqu% fo”ofo|ky;] fo”ofo|ky;
ds laLFkku mRrj iznss”k baLVhV~;wwV vkQ fMtkbu] uks,Mk ,oa lsUVj Qkj ,MokaLM LVMht]
y[kuÅ ds fjDr xSj&“kS{kf.kd inksaa ¼fo”ofo|ky; osclkbV ij foKkiu ds lkFk iznf”kZr rkfydk
esaa lwphc)½ ij lh/kh HkrhZ gsrqq Hkkjrh; ukxfjdksaa ls vkWuykbu vkosnu i= vkeaf=r djrk gSA
fofHkUu inksaa gsrqq fu/kkZfjr vgZrk ,oa vuqHko dk fooj.k fo”ofo|ky; dh osclkbV ij miyC/k
gSA HkrhZ gsrqq vkosnu ls lacaaf/kr leLr lwpuk,a fo”ofo|ky; dh osclkbV https://aktu.ac.in
ij fnukad 26-08-2026 ls miyC/k gksaaxh rFkk vkuykbu vkosnu djus dh vafre frfFk 15-092026 gksxhA vkosnu i= dh gkMZ dkih lHkh layXudksaa lfgr tek djus dh vafre frfFk 22-092026 gksxhA fu/kkZfjr frfFk ds mijkUr izkIr gksuss okyh gkMZ dkih dks Lohdkj ugha fd;k tk;sxk
,oa vkosnu i= dks fujLr ekuk tk;sxkA iwoZZ esaa izdkf”kr mDr foKkiu esaa ftu vH;fFkZ;ksaa }kjk
vkosnu fd;k x;k Fkk] mu vH;fFkZ;ksaa dks u;k vkosnu djrs le; viuk iqjkuk jftLVªs”ku uEcj
,oa VªkUtsD”ku vkbZ0Mh0 vafdr djuk vfuok;Z gksxkA mDr foKkiu ds lkis{k iwoZZ esaa ftu
vH;fFkZ;ksaa }kjk vkosnu fd;k x;k Fkk mudks nksckjk fu/kkZfjr “kqYd ns; ugha gksxkA fjDr inksa
dh la[;k fcuk fdlh iwoZZ lwpuk ds ifjofrZr dh tk ldrh gS vkSj bl laca/k esa dksbZ nkok
Lohdkj ugha fd;k tk,xkA fdlh in ;k leLr inksaa dks u Hkjus dk vf/kdkj fo”ofo|ky; ds
ikl lqjf{kr gSA jkT;iky lfpoky;@mRrj iznss”k “kklu }kjk le;&le; ij fuxZr lqlaaxr
fu;e ,oa vkns”k ykxw gksaaxssA mDr foKkiu ds lacaa/k esaa ;fn dksbZZ “kqf)i= tkjh gksrk gS rks og
fo”ofo|ky; dh osclkbV https://aktu.ac.in ij gh tkjh gksxkA
dqylfpo

<!-- page 2 -->

DR. APJ ABDUL KALAM TECHNICAL UNIVERSITY
JANKIPURAM VISTAR. SECTOR-11, SITAPUR ROAD LUCKNOW-226031

ADD. NO: AKTU/RO/STORE/2026/2037

Date:24-08-2026

Direct Recruitment for Non Academic Posts
In continuation of Advt. No. AKTU/Kus. Ka./Store/2024/886 dated 15.03.2024 for
non-academic posts in the University and its Colleges, namely, Uttar Pradesh Institute
of Design, Noida and Centre for Advanced Studies, Lucknow, fresh applications are
hereby invited. The details of eligibility and experience prescribed for various posts
are available on the University website. All information relating to the online
application for recruitment will be available on the University website
https://aktu.ac.in from 26.08.2026, and the last date to apply will be 15.09.2026. The
last date for submission of the hard copy of the application form along with all
attachments will be 22.09.2026. Hard copies received after the due date will not be
accepted, and the application form will be treated as rejected. In the case of candidates
who had applied against the said advertisement published earlier, it will be mandatory
to mention their old registration number and transaction ID while applying afresh.
Candidates who had applied earlier will not be required to pay the prescribed fee
again against the said advertisement. The number of vacancies may be changed
without any prior notice, and no claim in this regard will be entertained. The right to
fill any or all posts is reserved with the University. Relevant rules and orders issued
from time to time by the Governor's Secretariat, Uttar Pradesh Government, will be
applicable. Any amendment to the above advertisement shall be available only on the
University website: [https://aktu.ac.in.
Registrar

<!-- page 3 -->

MkW0 ,0ih0ts0 vCnqy dyke izkfof/kd fo”ofo|ky; mRrj izns”k] y[kuÅ esa
Lkh/kh HkrhZ ds ek/;e ls Hkjs tkus okys inksa dk fooj.k

¼d½ MkW0 ,0ih0ts0 vCnqy dyke izkfof/kd fo”ofo|ky; mRrj izns”k] y[kuÅA
dz0la0

Iknuke

inksa dh la[;k

ysoy

“kklukns”k ds vuqlkj “kSf{kd ;ksX;rk

1-

fof/k vf/kdkjh

01¼lkekU;½

07

2-

lgk;d dqylfpo 02 ¼lkekU;½

08

ekU;rk izkIr fo”ofo|ky; ls izFke Js.kh esa
,y0,y0ch0 mikf/k ,oa fdlh U;k;ky; ls
vFkok futh midze@laLFkk esa dslst djus
dk vFkok ckj dkmfUly ls iathdj.k ds
lkFk ek0 mPp U;k;ky; Lrj ij ,MoksdsV
ds :i esa 05 o’kZ dk vuqHkoA
izFke Js.kh@mPp f}rh; Js.kh esa ijkLukrd
ds lkFk iz”kkldh; dk;ksZa dk 05 o’kZ dk
dk;kZy; v/kh{kd Lrj dk vuqHko ,oa m0iz0
ljdkj ,oa fo”ofo|ky; fu;eksa dk KkuA

¼[k½ lsUVj Qkj ,MokLM LVMht] ,0ds0Vh0;w0] y[kuÅA
dz0la0
1-

2

Iknuke
lgk;d
iqLrdky;k/;{k

inksa dh la[;k ysoy
01 in
10
01¼lkekU;½

fjlpZ bathfu;j
@lgk;d
vfHk;Urk

02 in
01 ,l0lh0
01 vks0ch0lh

10

“kSf{kd ;ksX;rk
d½ U;wure çFke Js.kh vFkok led{k ds
lkFk
iqLrdky;
foKku@lwpuk
foKku@çys[khdj.k foKku esa LukRkdksÙkj
fMxzh vFkok led{k O;kolkf;d fMxzh rFkk
iqLrdky; ds dEI;wVjhdj.k ds Kku ds
lkFk fujarj mRÑ’V “kS{kf.kd fjdkMZA
[k½ ;wthlh }kjk bl iz;kstukFkZ lapkfyr
jk’Vªh; Lrj dh ijh{kk vFkok ;wthlh }kjk
vuqeksfnr blh ds led{k vU; fdlh
ijh{kk esa vgZrkA
dEI;wVj foKkiu@ usVofdZax@ lacaf/kr
czkUp esa LukrdksRrj ,oa “kS{kf.kd
laLFkku@bUMLVªh@ySCl esa 02 o’kZ dk;Z
djus dk vuqHkoA

¼x½ mRrj izns”k baLVhV~;wV vkQ fMtkbu] ,0ds0Vh0;w0] uks,MkA
dz0la0
1-

Iknuke

inksa dh la[;k

mi iqLrdky;k/;{k 01lkekU;

ysoy
12

“kSf{kd ;ksX;rk
Lkgk;d ykbZczsfj;u ds in ij 05 o’kZ dh
lsok iw.kZ gks] in gsrq fu/kkZfjr vU; “krksZa
dks iwjk djuk ¼tSls ih,p&Mh0 fMxzh ;k
led{k izdkf”kr fMIVh ykbZcszfj;u ds fy,
dk;Z vkfn½ tSlkfd ,0vkbZ0lh0Vh0 bZ0
}kjk fu/kkZfjr fd;k x;k gks

<!-- page 4 -->

2-

lgk;d dqylfpo

01 ¼lkekU;½

7

izFke Js.kh@mPp f}rh; Js.kh esa Lukrd ds
lkFk iz”kklfud dk;ksaZ dk 05 o’kZ dk
dk;kZy; v/kh{kd Lrj dk vuqHko ,oa
m0iz0 ljdkj ,oa fo”ofo|ky; fu;eksa dk
Kku] rduhdh ljdkjh laLFkkuksa ds
vf/k’Bku vkSj lkekU; iz”kklu dh
tkudkjhA

uksV% fo”ofo|ky; }kjk mDr fjfDr;ksa ij vkosnu i= fo”ofo|ky; dh osclkbV https://aktu.ac.in ij
miyC/k fyad ds ek/;e ls fnukad 26 vxLr] 2026 ls vku&ykbu Hkjk tk;sxkA vkuykbu vkosnu i=
dh vfUre frfFk 15-09-2026 gS rFkk mldh gkMZ dkih fnukad 22-09-2026 ;k mlls igys tek dj
ldrs gSaA ;gk¡ ij ;g Hkh mYys[kuh gS fd iwoZ esa ftu vH;fFkZ;ksa }kjk mijksDr inksa ds lkis{k fd;k
tk pqdk mUgsa uohu vkosnu djus dh vko”;drk ugha gksxh ijUrq og mlds lkis{k vius vkosnu dks
v|ru dj ldrs gSA mijksDr inksa ds lkis{k ftu vH;fFkZ;ksa }kjk u;k vkosnu fd;k tk;sxk mudks
fuEukuqlkj vkosnu “kqYd vukjf{kr] vU; fiNM+k oxZ ,oa vkfFkZd :Ik ls detksj oxZ ds vH;fFkZ;ksa dks
vkosnu “kqYd :0 2000@& rFkk vuqlwfpr tkfr ,oa vuqlwfpr tutkfr ds vH;fFkZ;ksa ls :0 1500@&
ns; gksxkA
