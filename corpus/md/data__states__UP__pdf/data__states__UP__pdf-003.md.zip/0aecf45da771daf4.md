---
doc_id: "0aecf45da771daf4"
source_url: "http://gbpssi.in/admin/documents/GBPSSIMUSEUM.pdf"
ministry: "Govind Ballabh Pant Social Science Institute, Allahabad, Uttar Pradesh"
title: "Click to download Tender Reference No. GBPSSI/PRYJ/03/2026"
date: ""
pages: 10
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "bed2665998702d4f"
---

<!-- page 1 -->

NOTICE INVITING TENDER
G. B. Pant Social Science
Institute, Prayagraj-209
NOTICE FOR INVITING TENDER (LTE)
Sealed Item rate online tenders are invited from civil contractors (registered with Allahabad
University) for the following works.
Name of work and | Estimated cost put to
ti & ot ie
location bid है 894 rol
sa | o =| eu |»
Sis g§aa08]8
है | sis |ca ee] 59
5 a |5 65 asa] ey
= Elas|/e2eeg/es
wz 6/3/85 eg}/su
a Ole ss} 535 8g] ४४
g =e |5 8 दे 8&323 858
2 s/f 8|ae8 S| sz
मे छल |228e2/9
कु fa) 2is s 4 Og 8
fo} 5 |e ao Rat a
s|2 als gH S]/E
Z2/E a sa छः
alZ 7a 8
ieee a al
व ae
a
HOS
225
g=° ° 9
a aq
go. S S
8५ 8 Ns oe
gos fe) Gal
ola od मा 3 =
Sife %:- 8,75,424/- / = s Fd
o/ot > le a
Sle 5 2 & | # is S g
8०७ i) ws a 6 6
७8 9५% ge a on = =
ole gts Sola S = a
S| a. gs ‘oie 52 a S
lo sd b te a 3 §
mam a 9 3S
ala oF > 6 a
S|“ .8 8 <
Alo 6 g <
Ble 2% a
ala ob «७ =}
Rie sf 5
बीना:
ao है|
& 39 se
In the event of any date indicated above is declared as holiday, the next working day of the Institute
shall be considered as the due date for receiving & opening of tenders. Late/delayed offer will not be
accepted.
The Govind Ballabh Pant Social Science Institute, Pryaygraj administration reserves the right to accept
or reject any or all the Tender/s without assigning any reason and to split up work or items of work to
divide or distribute the whole work among more than one contractor. The GL. will have
no option to refuse such splitting
* /rejection.
Administrative Offider
6.8. Pant Social Science Institute, Prayagraj
है

<!-- page 2 -->

INFORMATION AND INSTRUCTIONS FOR BIDDERS FOR E-TENDERING
FORMING PART OF BID DOCUMENT AND TO BE POSTED ON WEBSITE

i. The intending bidder must read the terms and conditions carefully. He should only submit his
bid if he considers himself eligible and he is in possession of all the documents required.

2. Information and Instructions for bidders posted on website shall form part of bid document.

3. The bid document consisting of plans, specifications, the schedule of quantities of various types
of items to be executed and the set of terms and conditions of the contract to be complied with
and other necessary documents can be seen and downloaded from website www.gbpssi.in,
www.eprocure.gov.in but online tender will be uploaded on www. eprocure.gov.in

4, But the online bid can only be submitted after depositing of original EMD in the office of
Administrative Officer of G.B.Pant Social Science Institute, Prayagraj within the period of bid
submission and uploading the mandatory scanned documents such as Demand Draft or Pay
order or Banker's Cheque or Deposit at call Receipt or Fixed Deposit Receipts and Bank
Guarantee of any Scheduled Bank towards EMD in favor of Administrative officer Govind Ballabh
Pant Social Science Institute, Pryagraj as mentioned in NIT, receipt for deposition of original EMD
to office of the Administrative officer Govind Ballabh Pant Social Science Institute, Prayagraj
and other documents as specified.

5. Those contractors not registered on the website mentioned above, are required to get
registered beforehand.

6. The intending bidder must have valid class-III digital signature to submit the bid.

Fs Contractor can upload documents in the form of JPG format and PDF format.

8. Contractor must ensure to quote rate of each item.

List of Documents to be scanned and uploaded within the period of bid submission:

L Treasury Challan/Demand Draft/Pay order or Banker‘s Cheque /Deposit at Call
Receipt/FDR/Bank Guarantee of any Scheduled Bank against EMD.

IL Certificate of Registration for GSTN No.

I. Copy of receipt of deposition of original EMD issued from Office of the Administrative Officer
Govind Ballabh Pant Social Science Institute, Prayagraj.

IV. Copy of registration with concerned department.

2

<!-- page 3 -->

RECEIPT OF DEPOSITION OF ORIGINAL EMD
(Receipt NO. .....................०००_«वैं पैब९...............००.००))
L Name of Work: -“Repair and Renovation of Basement Hall, Lobby, Stair, Passage etc.
of Museum Building.”, G.B. Pant Social Science Institute, Prayagraj.”
i, NIT No. : GBPSSI/PRYJ/03/2026
2. Estimated Cost: t 8,75,424/-
3. Amount of Earnest Money Deposit:%. 7,508/-
2. Last date of submission Of Bid: .............- ween UPTO 5:00 P.M,
$. Name of Contractor.......eeseeccceeceeeseenneeerneeesnneeee HE
2. (Fort Of EMD ....२२२०-००+बक&>बबससबससन> कक स9 59 «्कब «न बन 39 » «_««««०«ः..
3. Amount of Earnest Money Deposit #
4, Date of submission of EMD Ht
Signature, Name and Designation of EMD
Receiving person along with office stamp
3

<!-- page 4 -->

E-Tendering
i. Item rate bids are invited from approved and eligible contractors (registered with Allahabad
University) for the work of-“Repair and Renovation of Basement Hall, Lobby, Stair, Passage
etc. of Museum Building.”, G.B. Pant Social Science Institute, Prayagraj.”
The enlistment of the contractors should be valid on the last date of submission of bids.
Incase the last date of submission of bid is extended, the enlistment of contractor should be
valid on the original date of submission of bids.

ain The work is estimated to cost % 8,75,424/-. This estimate, however, is given merely as a rough
guide.

2. Agreement shall be drawn with the successful bidders on prescribed Form.Bidders shall quote
his rates as per various terms and conditions of the said form which will form part of the
agreement.

3. The time allowed for completion of the work is 5 (Fifteen) days from the date of issue of the Letter
of Acceptance (LOA) or from the date of handing over of the site to the contractor, whichever is earlier.

4, The site for the work is available.

5 The bid document, consisting of plans, specifications, the schedule of quantities of various
types of items to be executed and the set of terms and conditions of the contract to be complied
with and other necessary documents can be seen on website www.gbpssiin,
www. eprocure.gov.inl

6. After submission of the online bid the contractor can re-submit revised bid any number of
times but before last time and date of submission of bid as notified.

7. While submitting the revised bid, contractor can revise the rate of one or more item(s) any
number of times (he need not re-enter rate of all the items) but before last time and date of
submission of bid as notified.

8. Earnest Money in the form of Treasury Challan or Demand Draft or Pay order or Banker's
Cheque or Deposit at Call Receipt or Fixed Deposit Receipt (drawn in favor of Administrative
Officer, Govind Ballabh Pant Social Science Institute, Prayagraj)shall be scanned and uploaded
to the e-Tendering website within the period of bid submission. The original EMD should be
deposited in the Office of Administrative Officer, Govind Ballabh Pant Social Science Institute,
Prayagraj within the period of bid submission. The Office of the Administrative Officer, Govind
Ballabh Pant Social Science Institute, Prayagraj shall issue a receipt of deposition of earnest
money deposit to the bidder in a prescribed format (enclosed) uploaded by the tender inviting
authority.

This receipt shall also be uploaded to the e-tendering website by the intending bidder up to the
specified bid submission date and time.
Documents as specified in the bid document shall be scanned and uploaded to the e-Tendering website
within the period of bid submission. Further, the certified copies of all the scanned and uploaded
documents, if required, shall be submitted by the lowest bidder physically in the Office of the
Administrative Officer, G.B. Pant Social Science Institute, Prayagraj, within 3 (three) days of opening of the
tender.

4

<!-- page 5 -->

Online bid documents submitted by intending bidders shall be opened only of those bidders,
whose original EMD deposited with Office of the Administrative Officer, Govind Ballabh
Pant Social Science Institute, Prayagraj.

The bid submitted shall be opened at 0:00 AM on 23.03.2026

9. The bid submitted shall become invalid if:

(i) The bidder is found ineligible.

(ii) The bidder does not deposit original EMD Office of the Administrative Officer, Govind

Ballabh Pant Social Science Institute, Prayagraj

(iii) The bidder does not upload all the documents (including GSTN) as stipulated in the bid

document including the copy of receipt for deposition of original EMD.

(iv) If any discrepancy is noticed between the documents as uploaded at the time of
submission of bid and hard copies as submitted physically by the bidder in the office
of bid opening authority.

v) If a tenderer quotes nil rates against each item in item rate tender or does not quote
any percentage above/below on the total amount of the tender or any section/sub head
in percentage rate tender, the tender shall be treated as invalid and will not be
considered as lowest tenderer.

i0. The contractor whose bid is accepted will be required to furnish performance guarantee of

. 40% (Ten Percent) of the bid amount within 03 (three) days from the date issue of LoA. This
guarantee shall be in the form of Fixed Deposit Receipts drawn in favor of Administrative

Officer, Govind Ballabh Pant Social Science Institute, Prayagraj. In case the contractor fails to

deposit the said performance guarantee within the period including the extended period ifany,

the Earnest Money deposited by the contractor shall be forfeited automatically without any
notice to the contractor. The earnest money deposited along with bid shall be returned after
receiving the aforesaid performance guarantee.

4. Description of the work is as follows: -“Repair and Renovation of Basement Hall, Lobby, Stair,
Passage etc. of Museum Building, G.B. Pant Social Science Institute, Prayagraj.”Bidders are
advised to inspect and examine the site and its surroundings and satisfy themselves
before submitting their bids as to the nature of the ground and sub-soil (so far as is
practicable), the form and nature of the site, the means of access to the site, the
accommodation they may require and in general shall themselves obtain all necessary
information as to risks, contingencies and other circumstances which may influence
or affect their bid. A bidders shall be deemed to have full knowledge of the site whether
he inspects it or not and no extra charge consequent on any misunderstanding or
otherwise shall be allowed. The bidders shall be responsible for arranging and
maintaining at his own cost all materials, tools & plants, water, electricity access,
facilities for workers and all other services required for executing the work unless
otherwise specifically provided for in the contract documents. Submission of a bid by
a bidder implies that he has read this notice and all other contract documents and has
made himself aware of the scope and specifications of the local conditions and other
factors having a bearing on the execution of the work.

42 The competent authority on behalf of the Director, Govind Ballabh Pant Social Science Institute,
Pryagraj does not bind itself to accept the lowest or any other bid and reserves to itself the
authority to reject any or all the bids received without the assignment of any reason. All bids
in which any of the prescribed condition is not fulfilled or any condition including that of
conditional rebate is put forth by the bidders shall be summarily rejected.

5

<!-- page 6 -->

43. Canvassing whether directly or indirectly, in connection with bidders is strictly prohibited and
the bids submitted by the contractors who resort to canvassing will be liable for rejection.

4,. The competent authority on behalf of Director, Govind Ballabh Pant Social Science Institute,
Pryagraj reserves to himself the right of accepting the whole or any part of the bid and the
bidders shall be bound to perform the same at the rate quoted.

45. The contractor shall not be permitted to bid for works in the Institute if his near relative is
posted as an employee in any capacity in the Institute. He shall also intimate the names of
persons who are working with him in any capacity or are subsequently employed by him and
who are near relatives to any faculty/officer/staff in Govind Ballabh Pant Social Science
Institute. Any breach of this condition by the contractor the Institute will recommend
CPWD/University of Allahabad to remove the firm from the approved list of contractors of
CPWD/University of Allahabad .

6. No Engineer of Gazetted Rank or other Gazetted Officer employed in Engineering or
Administrative duties in an Engineering Department of the Government of India is allowed to
work as a contractor for a period of one year after his retirement from Government service,
without the prior permission of the Government of India in writing. This contract is liable to be
cancelled if either the contractor or any of his employees is found any time to be such a person
who had not obtained the permission of the Government of India as aforesaid before
submission of the bid or engagement in the contractor's service.

6 # The bid for the works shall remain open for acceptance for a period of 30 days. If any
bidders withdraws his bid before the said period or issue of letter of acceptance, whichever is
earlier, or makes any modifications in the terms and conditions of the bid which are not
acceptable to the department, then the Institute shall, without prejudice to any other right or
remedy, be at liberty to forfeit 50% of the said earnest money as aforesaid. Further the bidders
shall not be allowed to participate in the rebidding process of the work.

8. This notice inviting Bid shall form a part of the contract document. The successful
bidders/contractor, on acceptance of his bid by the Accepting Authority shall within 5 days
from the stipulated date of start of the work, sign the contract consisting of:-

(a) The Notice Inviting Bid, all the documents including additional conditions, specifications and
drawings, if any, forming part of the bid as uploaded at the time of invitation of bid and the
rates quoted online at the time of submission of bid and acceptance thereof together with any
correspondence leading thereto.

49.

बद्र The bidders must associate himself, with agencies of the appropriate class eligible to
bid for each of the minor component individually.

9.4.2 The eligible bidders shall quote rates for all items of major component as well as for all
items of minor components of work.

9.2.3 Final bill of whole work shall be finalized and recommendation for payment will be
made by the Institute J.E. in charge of minor component(s) will prepare and forward
the bills to the Administrative Officer Office G.B. Pant Social Science Institute, Pryagraj.

9,2.4 In case of any dispute arising out of any content the decision of the Director, Govind
Ballabh Pant Social Science Institute, Pryagraj will be final & binding upon both the
parties.

9.4.5 All disputes are subject to Hon'ble High Court of Judicature of Allahabad, Pryagraj.

6

<!-- page 7 -->

(A) Tender for the work of:-“Repair and Renovation of Basement Hall, Lobby, Stair, Passage
etc. of Museum Building.”, G.B. Pant Social Science Institute, Prayagraj.”
(i) To be uploaded latest by 05:00 PM hours on 44,03,2026 at www.eprocure.gov.in
(ii) To be opened in presence of tenderers who may be present at 230०0:0०00 AM hours
on
jutsu in the Committee Room of the Institute.
TENDER

I/We have read and examined the notice inviting tender, Specifications applicable, Drawings &
Designs, General Rules and Directions, Conditions of Contract, clauses of contract, Special conditions,
Schedule of Quantity & other documents and Rules referred to in the conditions of contract and all
other contents in the tender document for the work.
I/We hereby tender for the execution of the work specified for the Govind Ballabh Pant Social Science
Institute, Prayagraj within the time specified in the tender document viz., schedule of quantities and in
accordance in all respect with the specifications, designs, drawing and instructions in writing and with
such materials as are provided for, by, and in respect of accordance with, such conditions so far as
applicable.
We agree to keep the tender open for 30 days and not to make any modification in its terms and
conditions.
Asum of Rs................is hereby forwarded in Treasury Challan or Demand Draft or Pay order or Banker's
Cheque or Deposit at Call Receipt or Fixed Deposit Receipt (drawn in favour of Administrative officer
Govind Ballabh Pant Social Science Institute, Prayagraj) issued by a scheduled bank as earnest money
in the form of Demand Draft drawn in favor of Administrative officer Govind Ballabh Pant Social
Science Institute, Prayagraj is scanned and uploaded (strike out as the case may be)
If I/We fail to furnish the prescribed performance guarantee within prescribed period, [/We agree that
the said the Director, Govind Ballabh Pant Social Science Institute, Prayagraj or his successors, in office
shall without prejudice to any other right or remedy, be at liberty to forfeit the said earnest money
absolutely. Further, if I/We fail to commence work as specified, I/We agree that the administrative
officer Govind Ballabh Pant Social Science Institute, Prayagraj or the successors in office shall without
prejudice to any other right or remedy available in law, be at liberty to forfeit the said performance
guarantee absolutely. The said Performance Guarantee shall be a guarantee to execute all the works
referred to in the tender documents upon the terms and conditions contained.
Further, I/We agree thatin case of forfeiture of Earnest Money or Performance Guarantee as aforesaid,
I/We shall be debarred for participation in the re-tendering process of the work.
I/We undertake and confirm that eligible similar work(s) has/have not been got executed through
another contractor on back to back basis. Further that, if such a violation comes to the notice of
Department, then I/we shall be debarred for tendering in Govind Ballabh Pant Social Science Institute,
Prayagraj in future forever.

7

<!-- page 8 -->

Also, if such a violation comes to the notice of Institute before date of start of work, the Administrative
officer,Govind Ballabh Pant Social Science Institute, Pryagraj shall be free to forfeit the entire amount
of Earnest Money Deposit/Performance Guarantee.
I/We hereby declare that I/We shall treat the tender documents drawings and other records
connected with the work as_ secret/confidential documents and shall not communicate
information/derived there from to any person other than a person to whom I/We am/are authorized
to communicate the same or use the information in any manner prejudicial to the safety of the State.
I/We have filled and signed the tender documents on each page and the same are enclosed herewith.
Dated Signature of Contractor
Witness: Postal Address
Address:
Occupation:

8

<!-- page 9 -->

BILL OF QUANTITY
NAME OF WORK: - “Repair and Renovation of Basement Hall, Lobby, Stair, Passage, etc. of
Museum Building, G.B. Pant Social Science Institute, Prayagraj.”
NIT No. : GBPSSI/PRYJ/03/2026
No.
PIL Vitrified floor tiles 600x600mm
= See प्रकार
2 [शात्रा। शाला plaster of mix :4 c.m.
|? | (ee | aor
eae जद
Code/208/I5.56
डक के ALS
Code/208/4..3
5 Wall painting with plastic emulsion 385.60 Sqm
paint on old work
Code/208/I3.98.I
Removing white or colour wash by 335.60 Sqm
scrapping
Code/208/3.88
ewe od
Code/208/I3.80
Painting with synthetic enamel paint | 80.00 Sqm
on old work
Code/208/3.99.I
शिया पड कर]
Code/208/3.03.
0 | P/F of aluminum work with anodised | 50.00 Sqm
ieee न
Code/208/2I.L..I
P/F of I2 mm thick Pre-laminated 5.50 Sqm
particle board with decorative
lamination on both sides
Code/208/2.2.2
2. | P/F Glazing in aluminum door with 5.50 Sqm
float glass panes of 5 mm thickness
Code/208/2.3,.2
I3 | P/F Aluminium handels, IST 2.00 Nos
marked,andoised
Code/9.00.4
l4 | P/F Aluminium tower bolts, ISI 2.00 Nos
ee कि लि
Code/9.97.4
iene Sa
Code/9.70.2
PI bof i
Code/9.96.
॥7. | P/F chromium plated brass !00 mm .00 Nos
mortice latch and lock with 6 levers
Code/9.88
P/F of aluminium die cast body .00 Nos.
tublar type universal hydraulic door
closer
9

<!-- page 10 -->

[ rs es ee ee]
9 | Providing and fixing double action 7.00 Nos.
hydraulic floor spring of approved
brand
Code/208/2.4.I
20 | P/F of fly proof SS grade304 wire 30.00 Sqm
gauge to window
Code/9.35.4
2l | Renewing glass panes, with putty and | 5.00 Sqm
nails float glass panes of nominal
thickness 4 mm
Code/208/4.5.I
22 | Refixing old glass panes with putty 40.00 Sqm
and nails
Code/208/4.0
बहार
Signature and Address of Contractor
Administrative Officer
GB Pant Social Science Institute, Pryagraj
व0
