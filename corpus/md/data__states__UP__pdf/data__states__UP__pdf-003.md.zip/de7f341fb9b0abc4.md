---
doc_id: "de7f341fb9b0abc4"
source_url: "https://www.iitbhu.ac.in/contents/institute/admin/doc/executive_council_ecr_04oct2012.pdf"
ministry: "Indian Insttitute of Technology (BHU), Varanassi"
title: "Resolutions of the Executive Council, BHU (which was functioning as BoG at that time)"
date: ""
pages: 16
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "e2017136a9d9ac0b"
---

<!-- page 1 -->

COPY OF ECR NO.67 DATED OCTOBER 4, 20i2
ECR 67
ITEM 7 CONSIDERED the orders dated 8.8.20i2 of Chairman, Board of
Governors, IIT(BHU) regarding appointment of Dean (Academic
Affairs), Professor In charge (Students & Alumni Affairs) and
Professor In Charge (Research & Development).
The Executive Council noted that the IITs have several Deans to look
after different activities of the Institute like Academics, Recruitments,
Student Affairs, Research etc., whereas the erstwhile IT-BHU had
only one Dean. For ease of operations, a request was made by the
Director, IIT to appoint Professor In charge (Students & Alumni
Affairs) and Professor In Charge (Research & Development) to act as
deans till the Statutes and Ordinances of IIT(BHU) are implemented,
apart from the usual dean who shall now be Dean (Academic
Affairs). This proposal has been approved by the Vice- Chancellor in
the capacity of Chairman, BoG.
RESOLVED that the orders of the Vice-Chancellor,
BHU in the capacity of Chairman, Board of
Governors of IIT(BHU) appointing Prof. Surendra
Kumar, Dept. of Chemical Engg. as Dean (Academic
Affairs), Prof. S. K. Sharma, Dept. of Mechanical
Engg. as Professor-in-Charge (Student & Alumni
Affairs) and Prof. B. N. Dwivedi, Department of
Applied Physics as Professor-in-Charge (Research &
Development) be ratified and approved.
Dated: October 25, 2042
Copy forwarded to the Director, Indian Institute of T hehe
BHU, for information and necessary action. —_ 5 का
ish)
DEI
EXECUTIVE INCIL CELL

<!-- page 2 -->

COPY OF ECR NO.68 DATED OCTOBER 4, 2042
ECR 68
ITEM 8 CONSIDERED the orders dated 2i.8.202 of Chairman, Board of

Governors, IIT(BHU), Varanasi regarding appointment of Acting
Registrar at IIT(BHU).
The Executive Council noted that the IITs normally have a Registrar
who has to perform certain statutory functions. The erstwhile IT-BHU
had only one post of Dy. Registrar. Upon request from the Director,
IIT(BHU), the incumbent Dy. Registrar has been given the charge of
Registrar of IIT(BHU) under orders of the Vice-Chancellor in the
capacity of the Chairman, Board of Governors. The issue was
discussed in detail and the Executive Council felt that since the post
of Registrar is as such not existing in IIT(BHU), it is imperative that
the post is urgently created. In view of this, the following was
resolved:

RESOLVED that creation of post of Registrar in

the Pay-band IV and Grade Pay of Rs. 0000/-

be approved.

RESOLVED FURTHER that consequent upon

creation of the post, the incumbent Dy.

Registrar of IIT(BHU) be permitted to officiate

on the post till the post is regularly filled up or

till further orders in this regard is made,

whichever is earlier. During this period, he shall

be eligible for officiating allowance in

consonance with the provisions available in

IIT-Kanpur.

<!-- page 3 -->

RESOLVED STILL FURTHER that a corrigendum
be issued modifying to this extent, the orders of
the Vice-Chancellor, BHU in the capacity of
Chairman, Board of Governors of IIT(BHU)
dated 2.8.202, giving the charge of Registrar
of IIT(BHU) to the incumbent Dy. Registrar of
IIT(BHU).
Dated: October 25, 202
Copy forwarded to the Director, Indian Institute of Gets nology(BHU),
BHU, for information and necessary action. _ y
४] shy LU
Ex! COUNCIL CELL

<!-- page 4 -->

COPY OF ECR NO.69 DATED OCTOBER 4, 20i2
ECR 69
ITEM9 CONSIDERED the orders dated 5.9.20i2 of Chairman, Board of
Governors, IIT(BHU), Varanasi regarding constitution of Institute
Advisory Committee (IAC), Department Faculty Affairs Committee
(DFAC), Institute Faculty Affairs Committee(IFAC).
The Executive Council noted that in the selection procedure of IITs
requires certain committees, namely Institute Advisory Committee
(IAC), Department Faculty Affairs Committee (DFAC) and Institute
Faculty Affairs Committee (IFAC). Till the new Ordinances and
Statutes of IIT(BHU) are implemented, the Institutes of Technology
(Amendment) Act, 20i2 provides that the Ordinances and Statutes of
IIT- Kanpur shall be applicable with modifications as required.
Accordingly, upon proposal from Director, IIT(BHU), the Vice-
Chancellor, in the capacity of the Chairman, Board of Governors of
ITT(BHU) had approved the constitution of the these Committees.
RESOLVED that the orders of the Vice-
Chancellor, BHU in the capacity of Chairman,
Board of Governors of IIT(BHU) dated 5.9.202
approving the constitution of Institute Advisory
Committee (IAC), Department Faculty Affairs
Committee (DFAC), Institute Faculty Affairs
Committee (IFAC) of IIT(BHU) be ratified and
approved.
Dated: October 25, 2042
Copy forwarded to the Director, Indian Institute of Technology(BHU),
BHU, for information and necessary action. Qos: ia
© yo}
RE R
EXECUTIVE COUNCIL CELL

<!-- page 5 -->

COPY OF ECR NO.70 DATED OCTOBER 4, 20i2
ECR 70
ITEM 40 CONSIDERED the orders dated 28.7.202 of the Vice

Chancellor, BHU & Chairman, Board of Governors, IIT(BHU),
Varanasi regarding appointment of Heads of Departments in
ITT(BHU).

The Executive Council noted that the Institutes of Technology
(Amendment) Act, 20i2 provides that the Ordinances and
Statutes of IIT- Kanpur shall be applicable to शा (BHU) with
modifications as required till the new Ordinances and Statutes
of IIT(BHU) are ready and implemented. Accordingly, the Vice
Chancellor, BHU & Chairman, Board of Governors, IIT(BHU)
had ordered that the Director, IIT(BHU) may follow the
relevant rules of IITs regarding appointment of Heads of
Departments in the Institute. Subsequent to this, the Director,
IIT (BHU) has been appointing Heads of the
Departments/Coordinators of the Schools of IIT (BHU) in
accordance with the provisions contained in the Statutes of IIT-
Kanpur. The Executive Council, considering the provisions in
Ordinances of IIT-Kanpur regarding appointment of Heads of
Departments as good, resolved as under:

<!-- page 6 -->

RESOLVED that the orders of the Vice-
Chancellor, BHU in the capacity of
Chairman, Board of Governors of IIT(BHU)
dated 28.7.20i2, that the Director,
IIT(BHU) may follow the relevant rules of
IIT regarding appointment of Heads of
Departments in the Institute be ratified
and approved.
Dated: October 25, 2042
Copy forwarded to the Director, Indian Institute of
Technology(BHU), BHU, for information and ne Thien anton: है
जी
EXECUTIV! INCIL CELL

<!-- page 7 -->

COPY OF ६0२॥१0.74 DATED OCTOBER 4, 2042
ह्टार 74
ITEMii CONSIDERED the constitution of Senate of Indian Institute of
Technology (Banaras Hindu University), Varanasi in accordance
with the Institute of Technology Act 96i, Institute of
Technology (Amendment Act), 20i2 and Statute 4() of IIT-
Kanpur.
The Executive Council noted that the Senate of the IIT (BHU)
- has been constituted in accordance with the provisions
contained in Section 4 of the Institute of Technology Act 964,
read with Section 9 of the Institute of Technology
(Amendment) Act, 20i2 and as per Statute 4() of IIT-Kanpur.
Following the IIT Act, the Vice-Chancellor, in the capacity of
Chairman, Board of Governors, had nominated three persons in
consultation with the Director, IIT(BHU) who are not
employees of the Institute, from among educationists of
repute, one each from the fields of Science, Engineering and
Humanities : Prof M.S. Sodha, Ex-Professor & HoD, Deptt. Of
Physics & Ex-Dy. Director, IIT Delhi; Prof. Kripa Shanker Ex-Dy.
Director, IIT Kanpur & Professor, Industrial & Mgmt. Engg.
Deptt., IIT Kanpur; and Prof. H. R. Tiwari, Deptt. Of Humanities
& Social Sciences, IIT, Kharagpur. Further, in accordance with
the provisions contained in Statute of IIT Kanpur, six members
of the staff have been nominated by the Vice-Chancellor in the
capacity of Chairman, BoG, in consultation with the Director,
IIT(BHU), to the Senate.

<!-- page 8 -->

RESOLVED that the orders of the Vice-
Chancellor, BHU in the capacity of
Chairman, Board of Governors of IIT(BHU)
dated 4.07.20i2 and 05.09.20i2,
nominating members to the Senate and
approving constitution of the Senate be
ratified and approved.
Dated: October 25, 20i2
Copy forwarded to the Director, Indian Institute of
Technology(BHU), BHU, for information and nece; Cte: action.
ae
EXECUTIVI L CELL

<!-- page 9 -->

COPY OF ECR NO.73 DATED OCTOBER 4, 20i2
ECR 73
ITEM 3 CONSIDERED the order dated 0i.0.20i2 of the Chairman,
BoG, IIT (BHU), Varanasi regarding fixing sitting fee of experts/
members nominated to various committees of the Institute.
The Executive Council noted that on the proposal of the
Director, IIT(BHU), the sitting charges for all experts and
members nominated to the selection committees, Board of
Governors, Finance Committee and the Building & Works
Committee has been approved by Vice-Chancellor in the
capacity of Chairman, BoG, as Rs. 2000/- per expert/ member,
per sitting. This rate has been taken from that available at IIT-
Kanpur.
RESOLVED that the orders of the Vice-
Chancellor, BHU in the capacity of
Chairman, Board of Governors of IIT(BHU)
dated 4.40.2042, regarding fixing sitting
fee of experts/ members nominated to
various committees of the Institute be
ratified and approved.
Dated: October 25, 20i2
Copy forwarded to the Director, Indian Institute of
Technology(BHU), BHU, for information and nece: me
5४! |] tL
Ae
EXECUTIVE INCIL CELL

<!-- page 10 -->

COPY OF ECR NO.82 DATED OCTOBER 4, 20i2
ECR 82
ITEM 22 CONSIDERED the adoption of Stores and Purchase Manual
with suitable modifications/adaptation and customization for
implementation in ITT (BHU).
The Executive Council noted that presently, the IIT (BHU) is
following the Purchase Procedure of Banaras Hindu University.
After conversion of the erstwhile IT, BHU into IIT (BHU), it is
appropriate to adopt the Stores and Purchase Manual of IIT—
Kanpur with suitable _=modifications/adaptation and
customization in ITT (BHU), Varanasi.
RESOLVED that the Stores and Purchase
Manual of IIT—Kanpur be adopted in IIT
(BHU) with suitable modifications/
adaptation and customization.
Dated: October 25, 2042
Copy forwarded to the Director, Indian Institute of
Technology(BHU), BHU, for information and ae ry actor
59]! | Au
EXECUTIVE INCIL CELL
