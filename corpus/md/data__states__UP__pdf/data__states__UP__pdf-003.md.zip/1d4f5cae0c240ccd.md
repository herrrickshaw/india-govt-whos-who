---
doc_id: "1d4f5cae0c240ccd"
source_url: "https://www.gbu.ac.in/Admissions/DownloadFile?nName=93732316_ac4f9e64.pdfScan10092025.pdf"
ministry: "Gautam Buddha University, Uttar Pradesh"
title: "Advisory for Students/Parents on Deposition of Semester/ Annual/Miscellaneous Fees"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "4fa1fd2fd4b8da07"
---

<!-- page 1 -->

। Gautam Buddha University
Greater Noida, Gautam Buddha Nagar (GCP.)
G.B.U.-003/Finance/Fees-advisory/2025 BUT Dated : 0/09/2025
Office Advisory
Advisory for Students/Parents on Deposition eye
Advisory for Students/Parents on Deposition
f . F
of Semester/Annual/Miscellaneous Tees Semester/Annual/Miscellaneous Fees
In order to ensure smooth, transparent, and timely deposition of Semester/Annual/Miscellaneous
fees, all students and parents are hereby advised to kindly follow the instructions given below:
. Mode of Fee Payment
« All fees shall be deposited only through the University’s official payment portal or
designated bank account, as notified on the University website from time to time.
+» Cash transactions are strictly prohibited.
« Permissible payment modes include Net Banking, Debit/Credit Card, UPI, or Bank
Draft (where specifically permitted).
2. Timely Payment of Fees
+ Students are required to deposit the prescribed Semester/Annual/Miscellaneous fees within
the due dates notified by the University.
+ Any payment made after the due date shall attract late fee/penalty as per University rules.
« Failure to deposit fees may result in withholding of examination forms, results, or
registration for subsequent semesters.
3. Verification of Payment
* Students must download, print, and preserve the fee receipt/transaction confirmation
for future reference.
« Incase of any discrepancy, the same must be immediately reported to the Finance &
Accounts Department along with proof of payment for rectification.
4, Precautions for Parents/Students
+ Deposit fees only through official University channels; do not make payment to any
unauthorized individual or third party.
+ Before making payment, always verify the beneficiary name, account number, and
payment link from the official University website.
« The University shall not be responsible for any payment made to unauthorized or
fraudulent accounts. if
OMPU,
hive Xe
f= CEIVED ¢'
Cc? sy
पा cy fi d [2
3:53 ५ eee ee

<!-- page 2 -->

Gautam Buddha University
Greater Noida, Gautam Buddha Nagar (U.P.)
5, Miscellaneous Fees
e Any charges related to hostel, transport, examination, or other facilities must also be
deposited strictly as per the notifications issued by the concerned section/department.
6. Contact Details for Support
For any clarification or assistance regarding fee payment, please contact:
Finance Department, Gautam Buddha University, Greater Noida
Email: accounts@gbu.ac.in / ao@gbu.ac.in ; Phone: 020-234232
Swatantra Kumar Gupta
Finance Officer
Copy to:
l. Office of the Hon’ble Vice Chancellor — for kind information of the Hon’ble Vice
Chancellor
2. Dean (Academics)
3. Registrar
4. Deans/Heads of all concerned Schools
5. Notice Boards of all Schools
6. Notice Boards of all Hostels
7. System Manager — for uploading on the official website
8. Concerned File
pt tg
jo
Finance Officer
202
a
