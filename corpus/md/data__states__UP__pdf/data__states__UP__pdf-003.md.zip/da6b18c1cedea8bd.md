---
doc_id: "da6b18c1cedea8bd"
source_url: "https://www.gbu.ac.in/Admissions/DownloadFile?nName=19335040_97d20d39.pdfOffice%20Order%20regarding%20applicability%20of%20Hostel%20and%20Mess%20Charges%20in%20various%20cases.pdf"
ministry: "Gautam Buddha University, Uttar Pradesh"
title: "Office Order regarding applicability of Hostel and Mess Charges in various cases"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "237f36bec75704ac"
---

<!-- page 1 -->

=
Gautam Buddha University
a Greater Noida, Gautam Budh Nagar, U.P.
GBU-02/DSA/032/027/2026- 0 oy Dated: 24/0/2026
:: Office Order::
As per the approval granted by the Competent Authority, regarding applicability of
Hostel and Mess Charges in various cases related to Hostel No-Dues, withdrawal from
hostel, semester-wise hostel allotment, and stay in hostel as a guest, are hereby notified
for implementation, as detailed below:
l. Newly Admitted Students
. Withdrawal within 30 Days
Newly admitted students who obtain Hostel No-Dues within 30 days from the
official reporting date or the date of issuance of the admission letter, whichever is
later, shall be permitted to withdraw from hostel facilities. है
e Insuch cases, hostel and mess charges shall be applicable only up to the end
of the month in which Hostel No-Dues is obtained.
.2 All Other Cases
In all other cases, minimum hostel and mess charges for one semester shall be
applicable.
2. Students Other Than Newly Admitted
2.] General Provision
Once a hostel is booked, minimum Hostel & Mess charges for one semester shall
be applicable.
2.2 Withdrawal after Odd Semester and not to continue hostel accommodation
in the Even Semester
Ifa student avails hostel facilities during the Odd Semester and opts not to continue
hostel accommodation in the Even Semester of the same academic session, and
obtains Hostel No-Dues prior to the commencement of the Even Semester:
e Hostel & mess charges shall be applicable only for the Odd Semester.
3. Hostel Allotment in Even Semester Only (Applicable for All Students)
If a student avails hostel facilities only in the Even Semester of an academic session
and was not allotted a hostel room in the Odd Semester:
e Hostel & Mess charges shall be applicable only for the Even Semester.
4. Stay in Hostel as Guest
4. Guest Stay up to 4-5 Days
If a student seeks to stay in the hostel as a guest for a duration of up to 4-5 days,
such stay may be permitted:
¢ Onpayment of prescribed guest charges, and
¢ Subject to prior approval of the Dean, Student Affairs/Chief Warden
AS. (M/F).
2०8९१ of 2 acy

<!-- page 2 -->

4.2 Guest Stay Beyond 5 Days
Stay as a guest in the hostel for a duration exceeding five (5) days shall be
permitted only during the End/Mid Term Examinations of Odd and Even
Semesters, as per the official date-sheet of the concerned programme.

e Such cases shall be permitted subject to verification of the examination
schedule and prior approval of the Dean, Student Affairs. The student
shall be required to pay the prescribed guest charges for the entire
duration for which the examinations of the concerned programme are
scheduled. Payment for a selected or partial duration shall not be
permissible.

The above rules shall be applicable from Academic Session 2025-26.
Prof. Chander Kumar Singh
Ve Registrar
Copy to:-
. Staff of the Hon’ble Vice-Chancellor for kind information to V.C. Sir.
2. Dean Academics, for information.
3. Finance Officer, for kind information.
4. All School Deans, for kind information and display on school notice boards &
circulation among students.
5. Chief Warden (M/F), for information and display on hostel notice boards &
hostels website.
6. System Manager, for circulating the office order to all Deans/HoDs/Faculty
Members via E-Mail, and to display this at University Website.
7. Concerned file & office order file.
८९५
Ye Registrar
Page 2 of 2
