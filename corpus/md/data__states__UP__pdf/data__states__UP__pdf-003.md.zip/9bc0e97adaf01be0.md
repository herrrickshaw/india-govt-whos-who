---
doc_id: "9bc0e97adaf01be0"
source_url: "https://dgmup.gov.in/MediaGallery/GO/C_202007011728343262.pdf"
ministry: "Directorate of Geology & Mining, Uttar Pradesh"
title: ""
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cf66471e23fe5f29"
---

<!-- page 1 -->

-6 /86-2020
-N-q-11— / 01
-4,
-pcs tuff 1m
300 IN-1,1
6TRITh-rtt,
\H 41to f -q-VN

cc-' 1e7T I
cj
41-11T
1
PIcb4 31-

c•1.-1\31

30

2020

ffER:1:-1TO TIM Tft-d. 3114-171- TT 3-1)-070 -(_,cz11-670/2018 31-0 -Ntg
TETitff 3-7tT it-- 1* 28.02.2020
Rci 4-1 -)11c,14 f 3T
LiqicNul, chi Lc4 ic1c11
1cT171
31-

't-1 4-G1-rcT

1 c

1

Tn-rA-ff 3t070
TiTzt>cl--d TITO 7rTerz1 Tft-ff 3ff4wRiTr,
31-1
Rcic-1-1
1. 1c1I
cfri
t0-670/2018 3-70 fti.-g T4151,1
3T1V
q,
cl').1 4)1 vWtZ c0 .41I cP 28.02.2020 4)1 cqt-H-11
ii
1:1iR
uiRiiAyw
#10
ftt
ffER4
ct7)
TITZt>cl-a cil
1at14

GI114-1
t0-44/2016
4-1070 740-16/2020 # TITftd 31T-

cfri Lcl i1cicI1 qRici 44%1IC'1
ct-)c)
T ft-11--. 19.02.2020 c01

ct t:—
41 crrp-Trt 3f-u
311a-t4T 1t91-- 28.02.2020 LIT{ta ftqf 7711.
9 The seized vehicles may be dealt with as per order of this Tribunal as modified recently vide
"
order dated 19.02.2020 in M.A. No. 16/2020 In Original Application No. 44/2016, Mushtakeem v.

MoEF & CC & Ors., as follows:
"5. Having regard to the above practical difficulty, we modify the orders dated 05.04.2019 and
26.07.2019 as follows:
Sr.
No.
1

Category of Vehicle

Penalty Amount

Vehicles/Equipments/Excavators with showroom value more than Rs. Rs. 4 lacs
25 lacs and less than 5 years old.
Vehicles/Equipments/Excavators with showroom value more than Rs. Rs. 3 lacs
2
25 lacs and more than 5 years but less than 10 years old.
For the remaining Vehicles older than 10 years/Equipments/ Rs. 2 lacs
3
Excavators which are otherwise Rs. 2 lacs 17 legally permissible to be
operated and not covered by Serial No. 1 and 2.
Note - I: On repetition of the offence by the same vehicle/ equipment, Order dated 05.04.2019 will
be applicable.
Note - II: The option of release may be available for a period of one month from the date of seizure
and thereafter, the vehicles may be confiscated and auctioned.
The State may issue an appropriate Office r er u e to the above ettect and puDllsfl tne same.
6.
Needless to say that any private contract between a financer and a debtor cannot affect the States'
sovereign power to protect the environment and take incidental coercive measure for enforcement of
rule of law. Lien of the State will override any private interest. The above compensation regime will be
over and above any existing Rules or provisions. The amount collected may be remitted to the State
PCBs/PCCs for being utilized for restoration of the environment.

<!-- page 2 -->

We direct the Chief Secretary, Uttar Pradesh to ensure further action in the light of the contents
10.
of the reports if such action has not already been taken. Copies of the reports be forwarded to the Chief
Secretary, Uttar Pradesh. The Committee constituted by this Tribunal may continue to monitor further
action in the light of the above reports. Compliance report may be filed by the Chief
Secretary
ct)I Pipfr
31-j:1
2.
T ff9-11T 28.02.2020 Z 3171-6 c,f) TITzF+-11:1Tftff 31"-

ft 170 'VrerziRci3T-ruf .gT7T
chl4c11g1 ct-P0) 4)1

c1)

A6(4T--4)
\9cqii 1iicp‘3t-NlctdivN41?{N 14--111Z5c-1 cs-k-c-m12-fi
j1eiCfl t-Pcick f44-TP-r, 3010 Ik11co)31cb -11
74p- d1c1,
14i
—r11)-296 /81-7-2020-44(f)/2016, 1k.ff1.-- 25.06.2020
4-1u5e-11T-171,
V- 1co TL--04 T4r4q
fdtEr dFC1 ici3-121ft-Ri7, 13-Cq
31--qTrd-pf
71-ftq,

-citu gl-rzrur

c,m.-16,)
-qtg, Q-k6,.)

ITF-4-F
3fiT
(F4

Ri6 ell4c1)
7if -q I
