---
doc_id: "a898adc7cbfaf8c6"
source_url: "https://dpsup.up.gov.in/app/writereaddata/UploadGazette/corrigendum/pdf/C_202610301101565108.pdf"
ministry: "Directorate of Printing and Stationery, Uttar Pradesh"
title: "Government and Private Ordinary Gazette  [ Gazette ]"
date: ""
pages: 133
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "16beb19da87f8df5"
---

<!-- page 1 -->

jftLVMZ ua å &,åMhå&4
ykbls U l la å &MCY;w å ihå&41
¼ykbls U LM Vw iks L V fcnkmV iz h is e s U V½

[k.M 80]

iz;kxjkt] 'kfuokj] 24 vDVwcj] 2026 bZå ¼dkfrZd 02] 1948 'kd laor~½ [la[;k 43
-

fo"k;

-

i`"B la[;k

lEiw.kZ xtV dk ewY;
Hkkx 1& foKfIr&vodk'k] fu;qfDr]
LFkku&fu;qfDr] LFkkukUrj.k] vf/kdkj 633&674
vkSj nwljs oS;fDrd uksfVl
Hkkx 1&d& fu;e] dk;Z-fof/k;ka]
vkKk;sa] foKfIr;ka bR;kfn] ftudks
mÙkj Áns'k ds jkT;iky egksn;] 1147&1172
fofHkUu foHkkxksa ds v/;{k rFkk
jktLo ifj"kn~ us tkjh fd;k
Hkkx 1&[k ¼1½ vkS|ksfxd U;k;kf/kdj.kksa
ds vfHkfu.kZ;
Hkkx 1&[k ¼2½&Je U;k;ky;ksa ds
vfHkfu.kZ;
Hkkx 2 vkKk;sa] foKfIr;ka] fu;e vkSj
fu;e fo/kku] ftudks dsUnzh; ljdkj
vkSj vU; jkT;ksa dh ljdkjksa us tkjh
--fd;k] gkbZ dksVZ dh foKfIr;ka] Hkkjr
ljdkj ds xtV vkSj nwljs jkT;ksa ds
xtVksa dk m)j.k

okf"kZd
pUnk

fo"k;

i`"B
la[;k

#0
3075

1500

okf"kZd
pUnk
#0

Hkkx 5&,dkmUVsUV tujy] mŸkj izns'k
Hkkx 6&¼d½ fcy] tks Hkkjrh; laln esa
ÁLrqr fd;s x;s ;k ÁLrqr fd;s tkus
ls igys Ádkf'kr fd;s x;s
¼[k½ flysDV desfV;ksa dh fjiksVZ
d&Hkkjrh; laln ds ,sDV
Hkkx 7&¼d½ fcy] tks jkT; dh /kkjk
lHkkvksa esa ÁLrqr fd;s tkus ds igys
Ádkf'kr fd;s x;s

975

¼[k½ flysDV desfV;ksa dh fjiksVZ
Hkkx 7&d mÙkj Áns'kh; /kkjk lHkkvksa ds ,sDV
Hkkx 7&[k bysD'ku deh'ku vkWQ
bafM;k dh vuqfofgr rFkk vU;
fuokZpu lEcU/kh foKfIr;ka

---

975

---

975

---

975

Hkkx 3 Lok;Ùk 'kklu foHkkx
dk ØksM+i=] [k.M x&fuokZpu
¼LFkkuh; fudk;½ rFkk [k.M
?k&ftyk iapk;r

---

975

Hkkx 8 uxjikfydk ifj"kn~] uxj
iapk;r] ljdkjh dkxt-i=] nckbZ
gqbZ :bZ dh xkBksa dk fooj.k-i=]
tUe-ej.k ds vk¡dM+s] jksxxzLr gksus 2103-2167 975
okyksa vkSj ejus okyksa ds vk¡dM+s]
Qly vkSj _rq lEcU/kh fjiksVZ]
cktkj Hkko] lwpuk] foKkiu bR;kfn

Hkkx 4& funs'kd] f'k{kk foHkkx]
mŸkj izns'k

---

975

LVkslZ&ipZst foHkkx dk ØksM+ i=

94 d

---

1425

<!-- page 2 -->

634

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½
foKfIr-vodk'k] fu;qfDr] LFkku-fu;qfDr] LFkkukUrj.k] vf/kdkj vkSj nwljs oS;fDrd uksfVlA

vuqHkkx-1
21 Qjojh] 2024 bZ0
la0 881@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr
osru eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks
vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
vH;FkhZ dk
uke loZJh
uke loZJh@
Jherh@lqJh

1

2

3

4

92

54400037766

usgk frokjh

W/o vfer

dqekj

x`g
tuin

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky;
,oa tuin

5

6

7

Qjhnkckn
vfer dqekj]
gfj;k.kk ,Q0lh0,0 384] xyh
ua0-18] Hkhde
dkyksuh] Qjhnkckn]
gfj;k.kk-121004

15 'kS¸;k
jk0vk;q0fp0]
gkiqM+

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990
¼;Fkkla'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990
¼;Fkkla'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&

<!-- page 3 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

635

1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A
8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr-i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU;
vkijkf/kd@fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

<!-- page 4 -->

636

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

la0 882@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr
osru eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks
vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

1

2

3

4

5

95

54400039454

izrhd enku

S/o lqUnj

vyoj]
jktLFkku

yky enku

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

6

7

izrhd enku C/o
jk0vk;q0fp0]
lqUnj yky enku] thriqjk] eFkqjk
edku ua0-117] fot;
uxj] fu;j tsy
lfdZy] vyoj]
jktLFkku-301001

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A

<!-- page 5 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

637

6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A
8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr-i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU; vkijkf/kd@
fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

la0 884@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZn fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i= la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx

<!-- page 6 -->

638

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk la'kksf/kr½ ds vUrxZr iqujhf{kr
osru eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks
vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

1

2

3

4

97

54400016824

mek flag
lpku

W/o jes'k

dqekj

5

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

6

7

dkuiqj
jkds'k dqekj flag
jk0vk;q0fp0]
uxj lpku] ,Q-59] xqtSuh] jktsiqj] mUuko
dkuiqj uxj-208022

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A

<!-- page 7 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

639

8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr-i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU; vkijkf/kd@
fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

la0 885@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk la'kksf/kr½ ds vUrxZr iqujhf{kr

<!-- page 8 -->

640

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

osru eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks
vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

1

2

3

4

98

54400048009

lR;e ;kno

S/o deyk

'kadj ;kno

5

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

6

7

lar
deyk 'kadj ;kno]
jk0vk;q0fp0]
jfonkl 17 e[knweiqj] nqnok] Hkoj[k] fetkZiqj
uxj dqd:Fkh] lar jfonkl
¼Hknksgh½ uxj ¼Hknksgh½-221409

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A

<!-- page 9 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

641

8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr-i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU; vkijkf/kd@
fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

la0 886@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr
osru eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks
95 d

<!-- page 10 -->

642

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

1

2

3

4

101

54400089352

ikjl tSu

S/o vHk;

dqekj tSu

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

5

6

7

yfyriqj

vHk; dqekj tSu]
edku ua0-1309
yfyriqj jksM 2]
bfUnjk pkSjkgk]
egjkSuh] yfyriqj284405

25 'kS¸;k
jk0vk;q0fp0]
eÅjkuhiqj]
>kalh

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A

<!-- page 11 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

643

7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A
8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr-i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU;
vkijkf/kd@fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

887@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds jktdh;
vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr laLrqfr
i= la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx esa
m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr osru eSfVªDl

<!-- page 12 -->

644

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks
vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

1

2

3

4

103

54400045774

dapu 'kqDyk

W/o vk'kqrks"k

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

5

6

7

vesBh

dapu 'kqDyk]
dq'khrkyh] rkyk]
vesBh ¼lh0,l0,e0
uxj½-227405

jk0vk;q0fp0]
yksgjkeÅ]
lqYrkuiqj

dqekj ik.Ms;

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A

<!-- page 13 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

645

8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr-i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU; vkijkf/kd@
fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

la0 888@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i= la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr osru
eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks vk;qosZn

<!-- page 14 -->

646

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

1

2

3

4

104

54400051395

dfork 'kekZ

W/o fufru

Hkkj}kt

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

5

6

7

xkSre
cq)
uxj

jktohj 'kekZ] dyiqjk]
>k>j] xkSrecq) uxj203203

jk0vk;q0fp0]
[kqtkZ]
cqyUn'kgj

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkkvkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A

<!-- page 15 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

647

8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU; vkijkf/kd@
fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

la0 889@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr osru
eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks vk;qosZn

<!-- page 16 -->

648

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

1

2

3

4

105

54400007844

fiz;adk
dukSft;k

W/o [kse pan

5

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

6

7

mUuko fiz;adk dukSft;k] 700]
, ch uxj] mUuko209801

15 'kS¸;k
jk0vk;q0fp0]
?kkVeiqj]
dkuiqj uxj

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A

<!-- page 17 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

649

8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU;
vkijkf/kd@fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

la0 890@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr osru
eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks vk;qosZn
96 d

<!-- page 18 -->

650

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

1

2

3

4

106

54400105632

;ksxs'k

S/o vkse

izdk'k

5

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

6

7

>Ttj] vkse izdk'k] 342 okMZ
gfj;k.kk ua0-6] usrk th uxj
xyh ua0-1] >Ttj]
gfj;k.kk-124507

jk0vk;q0fp0]
cM+kSr] ckxir

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A

<!-- page 19 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

651

8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr-i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU; vkijkf/kd@
fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

la0 891@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr osru
eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks vk;qosZn

<!-- page 20 -->

652

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
vH;FkhZ dk
uke loZJh
uke loZJh@
Jherh@lqJh

1

2

3

4

107

54400046807

jeu oekZ

S/o dsyk'k

pUnz oekZ

x`g
tuin

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky;
,oa tuin

5

6

7

Q:Z[kkckn dsyk'k pUnz oekZ] nhu jk0vk;q0fp0]
n;ky ckx] vesBh
jkekJe]
dksguk] Q:Z[kkckn- dUukSt HWC
209601

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A

<!-- page 21 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

653

8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU;
vkijkf/kd@fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

la0 892@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr
osru eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks

<!-- page 22 -->

654

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
vH;FkhZ dk
uke loZJh
uke loZJh@
Jherh@lqJh

1

2

3

108

54400063882

T;ksfr flag

x`g
tuin

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

4

5

6

7

D/o larks"k

iz;kxjkt

larks"k dqekj flag]
cjkekj uhoh uSuh]
uSuh] iz;kxjkt211008

25 'kS¸;k
jk0vk;q0fp0]
[kkxk] Qrsgiqj

dqekj flag

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A

<!-- page 23 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

655

8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr-i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU; vkijkf/kd@
fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

893@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds jktdh;
vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr laLrqfr
i= la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx esa
m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr osru eSfVªDl
ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks vk;qosZn

<!-- page 24 -->

656

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

1

2

3

4

5

110

54400017212

Jqfr jLrksxh

D/o dqynhi

cgjkbp

pUnz

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

6

7

dqynhi pUnz] 469
jk0vk;q0fp0]
fu;j yksfg;k pkSjkgk xM+klk] lhrkiqj
clhjxat] xqnM+h]
cgjkbp-271801

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A

<!-- page 25 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

657

8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU; vkijkf/kd@
fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

la0 894@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr
osru eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks
97 d

<!-- page 26 -->

658

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
vH;FkhZ dk
uke loZJh
uke loZJh@
Jherh@lqJh

1

2

3

113

54400000814

jatuk nsoh

x`g
tuin

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky;
,oa tuin

4

5

6

7

W/o vfuy

lqyrkuiqj

vfuy dqekj]
vykmn~nhuiqj]
cuxok Mhg]
lqyrkuiqj-228172

jk0vk;q0fp0]
iV~Vh ujsUnziqj]
tkSuiqj HWC

dqekj

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990
¼;Fkkla'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990
¼;Fkkla'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A

<!-- page 27 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

659

8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZfnd fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU; vkijkf/kd@
fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

la0 895@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr
osru eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks

<!-- page 28 -->

660

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

1

2

3

4

115

54400043952

fouhr dqekj

S/o lriky

flag

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

5

6

7

T;ksfrck
Qqysuxj
¼vejksgk½

lriky flag] xzkeNTtwiqjk rxk]
vgjkSyk ekQh]
T;ksfrck Qqysuxj244231

jk0vk;q0fp0]
c`t?kkV] gkiqM+

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A

<!-- page 29 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

661

8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU; vkijkf/kd@
fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

la0 896@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr
osru eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks

<!-- page 30 -->

662

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
vH;FkhZ dk
uke loZJh
uke loZJh@
Jherh@lqJh

1

2

3

116

54400033104

izhrh oekZ

x`g
tuin

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

4

5

6

7

W/o Mk0

iz;kxjkt

jkeewfrZ Lo.kZdkj]
nqnqgok] mrjkoka]
iz;kxjkt-225108

25 'kS¸;k
jk0vk;q0fp0]
jlM+k] cfy;k

vjfoan
Lo.kZdkj

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A

<!-- page 31 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

663

8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZfnd fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr-i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU; vkijkf/kd@
fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

la0 897@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr
osru eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks

<!-- page 32 -->

664

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph
esa Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk x`g tuin
vH;FkhZ dk
uke loZJh
uke loZJh@
Jherh@lqJh

1

2

3

4

117

54400101098

fnokdj
[kUroky

S/o jke

izlkn
[kUroky

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky;
,oa tuin

5

6

7

ikS<+h]
mRrjk[k.M

fnokdj [kUroky
C/o jke izlkn
[kUroky] viksftV
izkbejh Ldwy
fe;kokyk] iksLVgj~jkokyk] nsgjknwu]
mRrjk[k.M-248001

jk0vk;q0fp0]
l<kSyhgfj;k]
lgkjuiqj

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A

<!-- page 33 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

665

6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A
8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr-i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU;
vkijkf/kd@fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA
98 d

<!-- page 34 -->

666

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

la0 898@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr
osru eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks
vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

1

2

3

4

118

54400048799

jkds'k dqekj
ik.Ms;

S/o jke

5

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

6

7

lUr
jkds'k dqekj ik.Ms;
25 'kS¸;k
ykspu ik.Ms; jfonkl S/o jkeykspu ik.Ms;] jk0vk;q0fp0]
uxj
cgiqjk] iksLV-bVgjk]
ea>uiqj]
¼Hknksgh½ lUrjfonkl uxj- dkS'kkEch HWC
221309

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A

<!-- page 35 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

667

3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A
8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU; vkijkf/kd@
fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

<!-- page 36 -->

668

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

la0 899@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr
osru eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks
vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

1

2

3

4

119

54400092648

Kku T;ksfr
pkS/kjh

W/o vkuUn

flag

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

5

6

7

y[kuÅ

vkuUn flag] lh-80
HAL] Vkmuf'ki
HAL, bfUnjk uxj]
y[kuÅ-226016

jk0vk;q0fp0]
gsrekiqj]
ckjkcadh

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`RrgksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkkvkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA

<!-- page 37 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

669

4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A
8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr-i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU;
vkijkf/kd@fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

<!-- page 38 -->

670

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

la0 900@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr osru
eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks vk;qosZn
fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

1

2

122

54400065389

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

3

4

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

6

7

Mk0 ds0,u0 frokjh
oSHko Mk;XuksfLVd
lsaVj] lqjfHk dkyksuh]
lqxj QSDVjh jksM]
isVªksy iEi vkWQ
xksfu;k pkSjkgk]
ihyhHkhr-262001

jk0vk;q0fp0]
ca'khiqj] cjsyh

5

vatuh dqekj S/o f=;qxh ihyhHkhr
'kqDyk
ukjk;.k 'kqDyk

HWC

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A
2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A

<!-- page 39 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

671

3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A
8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU;
vkijkf/kd@fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA
¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA

<!-- page 40 -->

672

[ Hkkx 1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

la0 901@96-vk;q"k-1-2024-66@2011&yksd lsok vk;ksx] mÙkj çns'k] ç;kxjkt }kjk mÙkj çns'k ds
jktdh; vk;qosZfnd fpfdRlky;ksa esa vk;qosZn fpfdRlkf/kdkfj;ksa ds inksa ij lh/kh HkrhZ }kjk p;u ds mijkUr çkIr
laLrqfr i=-la[;k-508¼4½@04@Mh0vkj0@,l0-9@2020-21] fnukad 21 fnlEcj] 2023 ds vk/kkj ij vk;q"k foHkkx
esa m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkkla'kksf/kr½ ds vUrxZr iqujhf{kr
osru eSfVªDl ysoy-10 ¼ç;ksT; ysoy dh çFke dksf"Bdk dh jkf'k½ esa fuEufyf[kr rkfydk esa vafdr vH;FkhZ dks
vk;qosZn fpfdRlkf/kdkjh ds in ij vkSicfU/kd :i ls fu;qDr@rSukr djus dh Jh jkT;iky lg"kZ Loh—fr çnku
djrh gS&
ek0 vk;ksx
}kjk fuxZr
eq[; lwph esa
Øekad

jftLVªs'ku
Øekad

p;fur
firk@ifr dk
x`g
vH;FkhZ dk
uke loZJh
tuin
uke loZJh@
Jherh@lqJh

1

2

3

4

124

54400016523

fofiu iaokj

S/o Hkhe flag

LFkk;h irk

rSukrh LFky@
jktdh;
vk;qosZfnd
fpfdRlky; ,oa
tuin

5

6

7

'kkeyh
¼izcq)
uxj½

fofiu iaokj] 12@40
iaokj fDyfud fudV
cM+h ugj folkbM~l
bafM;u cSad] 'kkeyh
¼izcq) uxj½-247775

jk0vk;q0fp0]
iqjuiqj uoknk]
ckxir

mDr fu;qfDr@rSukrh fuEufyf[kr 'krksaZ ,oa çfrcU/kksa ds v/khu gksxh&
¼1½& lEcfU/kr fpfdRlkf/kdkjh dks m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ ds fu;e-17 ds v/khu lkekU;r;k 02 o"kZ dh ifjoh{kk vof/k ij j[kk tk;sxkA
¼2½& fu;qDr vH;FkhZ dks mDr osrueku esa osru ds vfrfjDr le;-le; ij tkjh 'kklukns'kksa ds vUrxZr
vuqeU; eagxkbZ HkÙkk rFkk vU; HkÙks vkfn Hkh ns; gksaxsA
¼3½& foÙk ¼lkekU;½ vuqHkkx-3 dh vf/klwpuk la[;k-lk-3-379@nl-2005-31¼9½@2003] fnukad 28 ekpZ]
2005 }kjk ykxw uoifjHkkf"kr va'knku isa'ku ;kstuk izo`Rr gksxhA
¼4½& lEcfU/kr fpfdRlkdkfj;ksa ij m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok fu;ekoyh] 1990 ¼;Fkk
la'kksf/kr½ esa mfYyf[kr çkfo/kku ykxw gksaxsA
¼5½& fu;qfDr LFkku ij dk;ZHkkj xzg.k djus gsrq fdlh çdkj dk ;k=k-HkÙkk vkfn ns; ugha gksxkA
¼6½& dk;ZHkkj xzg.k djus ds le; lEcfU/kr vH;FkhZ dks fuEu çek.k-i= çLrqr djus gksaxs&
1& 02 ,sls jktif=r vf/kdkjh tks lfØ; lsok esa gks vkSj muls iw.kZ :i ls ifjfpr gks] fdUrq
muds lEcU/kh u gks] ls vPNs pfj= dk çek.k-i=A

<!-- page 41 -->

Hkkx 1 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

673

2& vfHk;kstu u pyk;s tkus rFkk ek0 U;k;ky; }kjk nf.Mr u fd;s tkus ds lEcU/k esa 'kiFk-i=A
3& m0ç0 Hkkjrh; fpfdRlk ifj"kn }kjk fn;s x;s LFkk;h iathdj.k dh 02 çekf.kr çfr;kaA
4& vksFk vkQ ,yhft;Ul dk çek.k-i=A
5& xksiuh;rk dk çek.k-i=A
6& py rFkk vpy lEifÙk dk çek.k-i=A
7& ,d ls vf/kd iRuh@ifr thfor u gksus dk çek.k-i=A
8& leLr 'kS{kf.kd ;ksX;rk dh lR;rk lEcU/kh bl vk'k; dk 'kiFk-i= dh ;fn 'kS{kf.kd ;ksX;rk
lEcU/kh vfHkys[k xyr ik;s tkrs gSa rks mudh fu;qfDr fujLr dj nh tk;sxh rFkk bl lEcU/k esa mUgsa dksbZ vkifÙk
ugha gksxhA
¼7½& lEcfU/kr] fpfdRlkf/kdkjh mijksDr çLrj-6 esa vafdr lHkh çek.k-i= vkoafVr tuin ds {ks=h;
vk;qosZfnd ,oa ;wukuh vf/kdkjh ds le{k ,d ekg ds vUnj çLrqr djds ;ksxnku dh lwpuk nsaxs ;fn mDr vof/k
ds Hkhrj viuh rSukrh LFky ij ;ksxnku dh lwpuk ugha nsrs gSa rks mudk vH;FkZu fujLr djus ij 'kklu Lrj ij
fopkj fd;k tk;sxkA
¼8½& m0ç0 jkT; fpfdRlk ¼vk;qosZn ,oa ;wukuh½ lsok laoxZ esa mDr fpfdRlkf/kdkjh dh ofj"Brk yksd
lsok vk;ksx] m0ç0 }kjk çkIr Js"Brk Øe ds vk/kkj ij ;Fkk le; fu;ekuqlkj fu/kkZfjr dh tk;sxhA
¼9½& ifjoh{kk vof/k esa fpfdRldksa dks LFkkukUrj.k dh lqfo/kk vuqeU; ugha gksxh] ;g lqfo/kk mUgsa lQyrk
iwoaZd ifjoh{kk vof/k iw.kZ djus ds mijkUr gh çkIr gksxhA
;fn uofu;qDr vk;qosZn fpfdRlkf/kdkjh ,sls vkns'kksa ds fo:) ncko Myokus dk ç;kl djsxk] rks mlds
bl —R;@vkpj.k dks ^ljdkjh deZpkjh vkpj.k fu;ekoyh-1956^ ds fu;e-27 dk mYya?ku ekurs gq;s mlds
fo:) ^mÙkj çns'k ljdkjh lsod] ¼vuq'kklu ,oa vihy½ fu;ekoyh-1999^ ds lqlaxr çkfo/kkuksa ds vuqlkj
dk;Zokgh dh tk;sxhA
¼10½& lEcfU/kr vf/kdkjh }kjk vH;FkhZ dks dk;ZHkkj xzg.k djus ds iwoZ muds ewy-çek.k i= ,oa fMfxz;ksa
dh vko';d tkap Lo;a djkuk lqfuf'pr djsaxsA
¼11½& vH;FkhZ dks mDr vkSicfU/kd fu;qfDr bl 'krZ ds lkFk çnku dh tk jgh gS fd ;fn vH;FkhZ dk
pfj= ,oa iwoZo`Ùk lR;kfir ugh gksrk gS ;k vH;FkhZ }kjk vius Lo%lR;kiu ;k Lo%?kks"k.kk-i= esa dksbZ xyr lwpuk
nh x;h gS] rks vkSicfU/kd fu;qfDr-i= rRdky fujLr dj fn;k tk;sxk vkSj ifj.kke Lo:i vU; vkijkf/kd@
fof/kd dk;Zokgh Hkh dh tk;sxhA
¼12½& ;g fu;qfDr furkUr vkSicfU/kd ,oa vLFkkbZ gSA ;fn ckn esa vH;FkhZ ds lEcU/k esa fn;s x;s çek.ki= ,oa vU; lsok 'krksZ dks vlR; ik;k tkrk gS] rks mudh lsok;sa fcuk dksbZ dkj.k crk;s rRdky lekIr dj nh
tk;sxh vkSj vlR; çek.k-i= fn;s tkus ds lEcU/k esa fu;ekuqlkj foHkkxh; vijkf/kd ¼fØfeuy½ dk;Zokgh dh
tk;sxhA

99 d

<!-- page 42 -->

674

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 1

¼13½& mDr fu;qfDr fjV ;kfpdk la[;k-7778@2023] fojsUæ flag dq'kokgk o vU; cuke m0ç0 jkT; o
vU;] 10321@2023 jkWfcu ckny cuke m0ç0 jkT; o vU; 7272@2023 jkekuUnu jkBkSj cuke m0ç0 jkT; o
vU; 10391@2023 Jherh f'kYdh iVsy cuke m0ç0 jkT; o vU; rFkk 2640@2023 fojsUæ flag dq'kokgk o vU;
cuke m0ç0 jkT; o vU; esa ek0 U;k;ky; }kjk ikfjr gksus okys vfUre fu.kZ; ds v/khu jgsxkA
vkKk ls]
yhuk tkSgjh]
izeq[k lfpoA

ih0,l0;w0ih0&30 fgUnh xtV&Hkkx 1&2026 bZ0A
eqnzd ,oa izdk'kd&funs'kd] eqnz.k ,oa ys[ku-lkexzh] mÙkj izns'k] iz;kxjktA

<!-- page 43 -->

jftLVMZ ua å &,åMhå&4
ykbls U l la å &MCY;w å ihå&41
¼ykbls U LM Vw iks L V fcnkmV iz h is e s U V½

ç;kxjkt] 'kfuokj] 24 vDVwcj] 2026 bZå ¼dkfrZd 02] 1948 'kd laor~½
fu;e] dk;Z fof/k;ka] vkKk;sa] foKfIr;ka bR;kfn] ftudks mRrj izns'k ds jkT;iky egksn;]
fofHkUu foHkkxksa ds v/;{k rFkk jktLo ifj"kn~ us tkjh fd;kA

-

¼vf/kfu;e dh /kkjk-11 dh mi /kkjk ¼1½ ds vUrxZr½
21 flrEcj] 2026 bZ0
la[;k 773@vkB&fo0Hkw0v0v0@cyjkeiqj@2026&Hkwfe vtZu] iquokZlu vkSj iquO;ZoLFkkiu esa mfpr
izfrdj vkSj ikjnf'kZrk dk vf/kdkj vf/kfu;e&2013 dh /kkjk&11 dh mi/kkjk ¼1½ ds v/khu dysDVj Ckyjkeiqj
¼leqfpr ljdkj½ dk mn~ns';@jk; gS] fd tuin cyjkeiqj esa ek¡ ikVs'ojh nsoh efUnj eq[; xsV ls cyjkeiqj
phuh fey rd ekxZ ds pkSM+hdj.k ,oa lqn`<+hdj.k gsrq rglhy rqylhiqj ijxuk rqylhiqj ds xzke ikVu esa fLFkr
{ks=Qy 0-60205 gs0 Hkwfe yksd ifj;kstu gsrq vko';drk gS] ftlds fy, Hkwfe vtZu] iquokZlu vkSj iquO;ZoLFkkiu
esa mfpr izfrdj vkSj ikjnf'kZrk dk vf/kdkj vf/kfu;e&2013 esa fufgr izko/kkuksa ds vUrxZr leqfpr ljdkj]
ftyk ds dysDVj gSaA
lkekftd lek?kkr fu/kkZj.k dk v/;;u ukfer ,tsUlh }kjk fd;k x;k gS] rFkk leqfpr
ljdkj@dysDVj cyjkeiqj dks viuh vuq'kalk izLrqr dh x;h gS] ftls leqfpr ljdkj@dysDVj cyjkeiqj }kjk
vuqeksfnr fd;k x;k gSA
lkekftd lek?kkr fu/kkZj.k fjiksV dk lkjk¡'k bl izdkj gS%&
vuqHkkfod lk{;ksa ds xq.kkRed fo'ys"k.k ,oa ek¡ ikVs'ojh nsoh efUnj eq[; xsV ls cyjkeiqj phuh fey rd
ekxZ ds pkSM+hdj.k ,oa lqn`<+hdj.k gsrq ifj;kstuk ds vUrxZr lkekftd ,oa vkfFkZd n`f"V ls lek?kkfrr yksxksa ls
laokn ,oa lk{kkRdkj ls izkIr fu"d"kkZas ds vk/kkj ij ;g Li"V gS fd bl ifj;kstuk ds fuekZ.k] fØ;kUo;u ls
157 [k

<!-- page 44 -->

1148

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 1-d

laHkkfor udkjkRed izHkkoksa ds lkis{k ldkjkRed izHkko vf/kd gSA ;g ifj;kstuk tuin esa lEidZ O;oLFkk dks
lqn`<+ djus rFkk lexz ifjogu usVodZ dks csgrj cukus ds lUnHkZ esa vR;Ur egRoiw.kZ gS] lkFk gh ;g Hkh laLrqfr
dh tkrh gS ^^fd ifj;kstuk gsrq tks Hkwfe@{ks= vf/kxzg.k gsrq fpfUgr gS] ml Hkwfe dh fLFkfr dks ns[krs gq, ;g
csgrj vkSj vfUre fodYi gSA^^
bl ifj;kstuk ds vUrxZr lkekftd ,oa vkfFkZd n`f"V ls Hkwfe vtZu ds dkj.k dksbZ ifjokj foLFkkfir
ugha gks jgk gSA
vr% leqfpr ljdkj@dysDVj cyjkeiqj] lkoZtfud iz;kstu gsrq fuEufyf[kr vuqlwph esa mfYyf[kr
Hkwfe dks lkekU; lwpuk gsrq vf/klwfpr djus ds fy, lgefr nsrs gSaA

tuin

rglhy

ijxuk

xzke

xkVk la[;k

izLrkfor {ks=Qy
¼gs0esa½

1

2

3

4

5

6

cyjkeiqj

rqylhiqj

rqylhiqj

ikVu

272

0-031570

271

0-017625

270

0-015800

286

0-010900

292

0-006700

293

0-018690

295

0-003700

296

0-023400

297

0-016030

298

0-009710

301

0-000390

303

0-010800

305

0-007910

307

0-030290

309

0-001950

313

0-008800

162

0-036450

164

0-003700

165

0-004200

<!-- page 45 -->

Hkkx 1-d ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

1149

1

2

3

4

5

6

cyjkeiqj

rqylhiqj

rqylhiqj

ikVu

166

0-002600

168

0-009900

170

0-030300

171

0-007000

213

0-058800

220

0-234835

vf/kfu;e dh /kkjk&15 ds vUrxZr dksbZ O;fDr] ftldk fgr Hkwfe eas fufgr gks] vf/klwpuk ds izdk'ku
ds 60 fnu ds vUnj vius {ks= esa Hkwfe vf/kxzg.k ds fo:) fyf[kr :i ls dk;kZy; fo’ks"k Hkwfe v/;kfIr vf/kdkjh
xks.Mk esa vkifRr izLrqr dj ldrk gSA
vf/kfu;e dh /kkjk&11¼4½ ds vUrxZr dksbZ O;fDr vf/klwpuk ds izdk'ku dh frfFk ls Hkwfe vf/kxzg.k dh
dk;Zokgh iw.kZ gksus rd dysDVj ds iwoZ vuqeksnu ds fcuk izkjfEHkd vf/klwpuk esa fufnZ"V Hkwfe dk lO;ogkj ;Fkk
foØ;@Ø; ;k ml Hkwfe esa dksbZ Hkkj mRiUu ugha dj ldrk gSA
mDr Hkwfe dk LFkyh; uD'kk dysDVj cyjkeiqj@fo'ks"k Hkwfe v/;kfIr vf/kdkjh xks.Mk ds
dk;kZy; esa ns[kk tk ldrk gSA
fofiu dqekj tSu]
l{ke izkf/kdkjh@
dysDVj] cyjkeiqjA
OFFICE, COMPETENT AUTHORITY / COLLECTOR, BALRAMPUR
[ Under Sub-Section (1) of Section 11 of the Act ]
NOTIFICATION
September 21, 2026
N0. 773/VIII-S.L.A.O. /Balrampur/2026--The Collector, Balrampur (the Appropriate Government),
under sub-section (1) of Section 11 of the Right to Fair Compensation and Transparency in Land
Acquisition, Rehabilitation and Resettlement Act, 2013, is of the opinion that land Area 0.60205 hectares
situated in Village Patan, Tehsil Tulsipur, ParganaTulsipur, District Balrampur, Is required for the public
project of widening and strengthening the road from the Main Gate of Maa Pateshwari Devi Temple to
Balrampur Chini Mill. For this purpose, Land Acquisition is required in accordance with the provisions
contained in the Right to Fair Compensation and Transparency in Land Acquisition, Rehabilitation and
Resettlement Act, 2013, under which the Appropriate Government is the District Collector.
2. The Social Impact Assessment study has been conducted by the designated agency, and its
recommendations have been submitted to the Appropriate Government/Collector, Balrampur, which have
been approved by the Appropriate Government/Collector, Balrampur.
3. The summary of the Social Impact Assessment Report is as follows:

<!-- page 46 -->

1150

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 1-d

Based on the Qualitative analysis of empirical evidence and the findings obtained through
consultations and interviews with people affected Socially and Economically by the project for the widening
and strengthening of the road from the Main Gate of Maa Pateshwari Devi Temple to Balrampur Chini Mill,
it is evident that the positive impacts likely to result from the construction and implementation of the project
outweigh the potential negative impacts.The project is extremely important for strengthening the
connectivity system in the district and improving the overall transportation network. It is also recommended
that, considering the existing condition of the Land/Area identified for Acquisition for the project, this
option is the better and final alternative.

4. Under this project, no family is being displaced due to Land Acquisition from a Social
and Economic perspective.
5. Therefore, the Appropriate Government/Collector, Balrampur, agrees to notify the land
mentioned in the following schedule for public purposes, for general information.
SCHEDULE
District

Tehsil

Pargana

Village

Plot No.

Area

1

2

3

4

5

6
Hectares

Balrampur

Tulsipur

Tulsipur

Patan

272

0.031570

271

0.017625

270

0.015800

286

0.010900

292

0.006700

293

0.018690

295

0.003700

296

0.023400

297

0.016030

298

0.009710

301

0.000390

303

0.010800

305

0.007910

307

0.030290

309

0.001950

313

0.008800

162

0.036450

164

0.003700

<!-- page 47 -->

Hkkx 1-d ]
1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½
2

3

4

5

1151
6
Hectares

Balrampur

Tulsipur

Tulsipur

Patan

165

0.004200

166

0.002600

168

0.009900

170

0.030300

171

0.007000

213

0.058800

220

0.234835

Total...

0.60205

6. Under Section 15 of the Act, any person having an interest in the land may, within
60 days from the date of publication of the notification, submit an objection in writing against
the Acquisition of the land within his/her Area to the Office of the Special Land Acquisition
Officer, Gonda.
7. Under Section 11(4) of the Act, no person shall, without the prior approval of the Collector, sell,
purchase, or otherwise deal with the land specified in the preliminary notification, or create any
encumbrance on such land, from the date of publication of the notification until completion of the
proceedings for acquisition of the land.
Note: The site map of the aforesaid land may be inspected at the office of the Collector, Balrampur
/Special Land Acquisition Officer, Gonda.
Vipin Kumar Jain,
Competent Authority/
Collector, Balrampur.

¼vf/kfu;e dh /kkjk-11 dh mi /kkjk ¼1½ ds vUrxZr½
21 flrEcj] 2026 bZ0
la[;k 768@vkB&fo0Hkw0v0v0@cyjkeiqj@2026&Hkwfe vtZu] iquokZlu vkSj iquO;ZoLFkkiu esa mfpr
izfrdj vkSj ikjnf'kZrk dk vf/kdkj vf/kfu;e] 2013 dh /kkjk&11 dh mi/kkjk ¼1½ ds v/khu dysDVj Ckyjkeiqj
¼leqfpr ljdkj½ dk mn~ns';@jk; gS] fd tuin cyjkeiqj esa ek¡ ikVs'ojh nsoh efUnj eq[; xsV ls cyjkeiqj
phuh fey rd ekxZ ds pkSM+hdj.k ,oa lqn`<+hdj.k gsrq rglhy rqylhiqj ijxuk rqylhiqj ds xzke uxj iapk;r
'khryk iqj esa fLFkr {ks=Qy 0-0566 gs0 Hkwfe yksd ifj;kstu gsrq vko';drk gS] ftlds fy, Hkwfe vtZu] iquokZlu

<!-- page 48 -->

1152

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 1-d

vkSj iquO;ZoLFkkiu esa mfpr izfrdj vkSj ikjnf'kZrk dk vf/kdkj vf/kfu;e&2013 esa fufgr izko/kkuksa ds vUrxZr
leqfpr ljdkj] ftyk ds dysDVj gSaA
lkekftd lek?kkr fu/kkZj.k dk v/;;u ukfer ,tsUlh }kjk fd;k x;k gS] rFkk leqfpr
ljdkj@dysDVj cyjkeiqj dks viuh vuq'kalk izLrqr dh x;h gS] ftls leqfpr ljdkj@dysDVj cyjkeiqj }kjk
vuqeksfnr fd;k x;k gSA
lkekftd lek?kkr fu/kkZj.k fjiksV dk lkjk¡'k bl izdkj gS%&
vuqHkkfod lk{;ksa ds xq.kkRed fo'ys"k.k ,oa ek¡ ikVs'ojh nsoh efUnj eq[; xsV ls cyjkeiqj phuh fey rd
ekxZ ds pkSM+hdj.k ,oa lqn`<+hdj.k gsrq ifj;kstuk ds vUrxZr lkekftd ,oa vkfFkZd n`f"V ls lek?kkfrr yksxksa ls
laokn ,oa lk{kkRdkj ls izkIr fu"d"kkZas ds vk/kkj ij ;g Li"V gS fd bl ifj;kstuk ds fuekZ.k] fØ;kUo;u ls
laHkkfor udkjkRed izHkkoksa ds lkis{k ldkjkRed izHkko vf/kd gSA ;g ifj;kstuk tuin esa lEidZ O;oLFkk dks
lqn`<+ djus rFkk lexz ifjogu usVodZ dks csgrj cukus ds lUnHkZ esa vR;Ur egRoiw.kZ gS] lkFk gh ;g Hkh laLrqfr
dh tkrh gS ^^fd ifj;kstuk gsrq tks Hkwfe@{ks= vf/kxzg.k gsrq fpfUgr gS] ml Hkwfe dh fLFkfr dks ns[krs gq, ;g
csgrj vkSj vfUre fodYi gSA^^
bl ifj;kstuk ds vUrxZr lkekftd ,oa vkfFkZd n`f"V ls Hkwfe vtZu ds dkj.k dksbZ ifjokj foLFkkfir
ugha gks jgk gSA
vr% leqfpr ljdkj@dysDVj cyjkeiqj] lkoZtfud iz;kstu gsrq fuEufyf[kr vuqlwph esa mfYyf[kr
Hkwfe dks lkekU; lwpuk gsrq vf/klwfpr djus ds fy, lgefr nsrs gSaA

tuin

rglhy

ijxuk

xzke

xkVk la[;k

izLrkfor
{ks=Qy¼gs0esa½

1

2

3

4

5

6

cyjkeiqj

rqylhiqj

rqylhiqj

Ukxj iapk;r

464@1

0-0060

'khrykiqj

464@2

0-0060

327

0-0040

332

0-0120

333@1

0-0100

326

0-0186

<!-- page 49 -->

Hkkx 1-d ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

1153

vf/kfu;e dh /kkjk&15 ds vUrxZr dksbZ O;fDr] ftldk fgr Hkwfe eas fufgr gks] vf/klwpuk ds izdk'ku
ds 60 fnu ds vUnj vius {ks= esa Hkwfe vf/kxzg.k ds fo:) fyf[kr :i ls dk;kZy; fo'ks"k Hkwfe v/;kfIr vf/kdkjh
xks.Mk esa vkifRr izLrqr dj ldrk gSA
vf/kfu;e dh /kkjk&11¼4½ ds vUrxZr dksbZ O;fDr vf/klwpuk ds izdk'ku dh frfFk ls Hkwfe vf/kxzg.k dh
dk;Zokgh iw.kZ gksus rd dysDVj ds iwoZ vuqeksnu ds fcuk izkjfEHkd vf/klwpuk esa fufnZ"V Hkwfe dk lO;ogkj ;Fkk
foØ;@Ø; ;k ml Hkwfe esa dksbZ Hkkj mRiUu ugha dj ldrk gSA
mDr Hkwfe dk LFkyh; uD'kk dysDVj cyjkeiqj@ fo'ks"k Hkwfe v/;kfIr vf/kdkjh xks.Mk ds
dk;kZy; esa ns[kk tk ldrk gSA
fofiu dqekj tSu
l{ke izkf/kdkjh@
dysDVj] cyjkeiqjA
OFFICE, COMPETENT AUTHORITY / COLLECTOR, BALRAMPUR
[ Under Sub-Section (1) of Section 11 of the Act ]
NOTIFICATION
September 21, 2026
No. 768/VIII-S.L.A.O./Balrampur/2026--The Collector, Balrampur (the Appropriate Government),
under sub-section (1) of Section 11 of the Right to Fair Compensation and Transparency in Land
Acquisition, Rehabilitation and Resettlement Act, 2013, is of the opinion that land Area 0.0566 hectares
situated in Nagar Panchayat Shitlapur, Tehsil Tulsipur, Pargana Tulsipur, District Balrampur, Is required for
the public project of widening and strengthening the road from the Main Gate of MaaPateshwari Devi
Temple to Balrampur Chini Mill. For this purpose, Land Acquisition is required in accordance with the
provisions contained in the Right to Fair Compensation and Transparency in Land Acquisition,
Rehabilitation and Resettlement Act, 2013, under which the Appropriate Government is the District
Collector.
2. The Social Impact Assessment study has been conducted by the designated Agency, and its
recommendations have been submitted to the Appropriate Government/Collector, Balrampur, which have
been approved by the Appropriate Government/Collector, Balrampur.
3. The summary of the Social Impact Assessment Report is as follows:
Based on the Qualitative analysis of empirical evidence and the findings obtained through
consultations and interviews with people affected Socially and Economically by the project for the widening
and strengthening of the road from the Main Gate of Maa Pateshwari Devi Temple to Balrampur Chini Mill,
it is evident that the positive impacts likely to result from the construction and implementation of the project
outweigh the potential negative impacts. The project is extremely important for strengthening the
connectivity system in the district and improving the overall transportation network. It is also recommended

<!-- page 50 -->

1154

[ Hkkx 1-d

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

that, considering the existing condition of the Land/Area identified for Acquisition for the project, this
option is the better and final alternative.

4. Under this project, no family is being displaced due to Land Acquisition from a Social
and Economic perspective.
5. Therefore, the Appropriate Government/Collector, Balrampur, agrees to notify the land
mentioned in the following schedule for public purposes, for general information.
SCHEDULE
District

Tehsil

Pargana

Village

Plot No.

Area to be acquired

1

2

3

4

5

6
Hectares

Balrampur

Tulsipur

Tulsipur

Nagar Panchayat Shitlapur

464/1

0.0060

464/2

0.0060

327

0.0040

332

0.0120

333/1

0.0100

326

0.0186

Total...

0.0566

6. Under Section 15 of the Act, any person having an interest in the land may, within 60
days from the date of publication of the notification, submit an objection in writing against the
Acquisition of the land within his/her Area to the Office of the Special Land Acquisition Officer,
Gonda.
7. Under Section 11(4) of the Act, no person shall, without the prior approval of the Collector, sell,
purchase, or otherwise deal with the land specified in the preliminary notification, or create any
encumbrance on such land, from the date of publication of the notification until completion of the
proceedings for acquisition of the land.
Note: The site map of the aforesaid land may be inspected at the office of the Collector, Balrampur
/Special Land Acquisition Officer, Gonda.
Vipin Kumar Jain,
Competent Authority/
Collector, Balrampur.

<!-- page 51 -->

Hkkx 1-d ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

1155

[ fu;e-20 dk mifu;e ¼2½ ]
¼vf/kfu;e dh /kkjk-11 dh mi /kkjk ¼1½ ds vUrxZr½

12 vDVwcj] 2026 bZ0
la0 2347@vkB&fo0Hkw0v0v0¼la0la0½@okjk.klh@2026&Hkwfe vtZu] iquokZlu vkSj iquO;ZoLFkku esa mfpr
izfrdj vkSj ikjnf'kZrk dk vf/kdkj vf/kfu;e 2013 dh /kkjk 11 dh mi/kkjk ¼1½ ds v/khu tuin&pUnkSyh ds
lqfu;ksftr fodkl gsrq m0iz0 ljdkj@dysDVj dh jk; gS fd tuin pUnkSyh eas Hkkjrh; vUrnsZ'kh; tyekxZ
izkf/kdj.k ds ek/;e ls lkoZtfud iz;kstu gsrq eYVh ekMWy VfeZuy ¼cUnjxkg½] jkeuxj okjk.klh dks thoukFkiqj
jsyos LVs'ku ls tksM+us ds fy, xzke&rkfgjiqj] gehniqj] xksikyiqj o iVuk] rglhy&ia0 nhun;ky mik/;k; uxj]
ftyk&pUnkSyh esa dqy jdck&9-759 gs0 Hkwfe dh vko';drk gSA
2&leqfpr ljdkj }kjk ^^,Vyl eSustesaV dalYVsalh lfoZlst çkbosV fyfeVsM 114@,] v'kksd iqje] jksM
4 ds lkeus] v'kksd uxj] jkaph** }kjk lkekftd lek?kkr fu/kkZj.k v/;;u fd;k x;k gS rFkk viuh vuq'kalk izLrqr
dh x;hA v/;;u fjiksVZ dk vkadyu fo'ks"kK lewg }kjk fd;k x;k] ftls leqfpr ljdkj }kjk fnukad 10-09-2026
dks vuqeksfnr fd;k x;k gSA
3&lekftd lek?kkr fjiksVZ dk lakjk'k bl izdkj gS%&
I-tuin pUnkSyh eas thoukFkiqj jsyos LVs'ku ls jkeuxj ds jkYgwiqj esa fLFkr eYVh ekWMy VfeZuy dks

tksM+us gsrq ubZ jsy ykbZu ds fuekZ.k dk mn~ns'; lkoZtfud iz;kstu@tufgr ls lEcfU/kr gS vkSj fo'ks"kK lewg
ifj;kstuk dh vko';drk ,oa mi;ksfxrk dks Lohdkj djrk gSA
II-ifj;kstuk ds fuekZ.k ls lEHkkfor ykHk Hkwfe ds vtZu ls izfrdwy lkekftd lek?kkr dh rqyuk esa dgh

vf/kd gSA
4&Hkwfe&vtZu ds dkj.k iz'uxr xzke esa dksbZ ifjokj foLFkkfir gksus dh lEHkkouk ugha gSA
mRrj izns'k 'kklu }kjk tkjh 'kklukns'k la0&414@,d&13&2014&7d¼8½@2014 y[kuÅ fnukad&06
vxLr 2014] ds vuqØe esa miftykf/kdkjh] ia0 nhun;ky mik/;k; uxj] pUnkSyh dks izHkkfor ifjokjksa ds iquokZlu
,oa iquO;ZoLFkkiu ds mn~ns'; ls iz'kkld fu;qDr fd;k tkrk gSA
5&vr% jkT;iky lkoZtfud iz;kstu gsrq fuEufyf[kr vuqlwph esa mfYyf[kr Hkwfe dks lkekU; lwpuk gsrq
vf/klwfpr djus ds fy;s lg"kZ lgefr nsrs gSaA
Ø0
la0

tuin

rglhy

ijxuk

xzke

Hkw[k.M la[;k

vftZr fd;s tkus
okyk {ks=Qy

1

2

3

4

5

6

7
gsDVs;j

1
2

pUnkSyh

ia0 nhun;ky
mik/;k; uxj

jkYgwiqj

rkfgjiqj

3

13 mi

0.207

15 mi

0.0230

17 mi

0.1800

;ksx - 158 [k

0.410

<!-- page 52 -->

1156
1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½
2

3

4

5

6

[ Hkkx 1-d

7
gsDVs;j

4

154

0.008

162

0.144

6

163

0.218

7

164

0.024

8

168

0.036

9

184

0.001

10

187

0.006

11

185

0.281

12

186

0.062

13

188

0.090

14

190

0.017

15

199

0.075

16

200

0.012

17

301

0.079

18

303

0.097

19

304

0.012

20

305

0.101

21

306

0.116

22

307

0.097

23

310

0.095

24

312

0.105

25

313

0.195

26

320

0.059

27

78

0.013

28

79

0.511

29

83

0.039

30

86

0.237

31

98

0.071

32

147

0.001

33

150

0.077

5

pUnkSyh

ia0 nhun;ky
mik/;k; uxj

jkYgwiqj

gehniqj

<!-- page 53 -->

Hkkx 1-d ]
1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½
2

3

4

5

6

1157
7
gsDVs;j

34

pUnkSyh

ia0 nhun;ky
mik/;k; uxj

jkYgwiqj

151

0.124

152

0.158

36

153

0.192

37

77

0.050

38

192

0.179

39

193

0.004

40

203

0.133

41

308

0.217

42

309

0.126

43

311

0.050

;ksx - -

4.112

35

44

gehniqj

xksikyiqj

26 mi

0.2700

45

25 mi

0.1220

46

3 mi

0.3680

47

22 mi

0.1310

48

20 mi

0.1520

49

19 mi

0.1750

50

18 mi

0.3820

51

51 mi

0.0060

52

56 mi

0.0060

53

57 mi

0.1260

;ksx&
54

iVuk

1.738

598

0.138

55

658

0.010

56

589

0.010

57

587

0.304

58

582

0.231

59

575

0.019

60

573

0.105

61

660

0.208

<!-- page 54 -->

1158
1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½
2

3

4

5

6

[ Hkkx 1-d

7
gsDVs;j

62

pUnkSyh

ia0 nhun;ky
mik/;k; uxj

jkYgwiqj

659

0.096

603

0.065

64

599

0.052

65

602

0.080

66

601

0.020

67

574

0.064

68

543

0.038

69

544

0.154

70

583

0.099

71

580

0.108

72

581

0.064

73

579

0.067

74

490

0.024

75

491

0.304

76

493

0.028

77

597

0.016

78

548

0.225

79

656

0.062

80

649

0.303

81

650

0.055

82

546

0.144

83

648

0.284

84

549

0.063

85

572

0.057

86

550

0.002

;ksx - -

3.499

dqy ;ksx --

9.759

63

iVuk

6&vf/kfu;e dh /kkjk&12 ds vUrxZr fufnZ"V ,oa izkfo/kkfur Hkwfe vf/kxzg.k ds iz;kstu gsrq vko';d
dne mBk;s tkus ds fy;s rFkk Hkwfe dk losZ{k.k] fdlh Hkwfe ds fy;s leryhdj.k] [kqnkbZ djus rFkk dk;Z ds
leqfpr fØ;kUo;u gsrq lHkh vko';d fØ;k;sa djus ds fy;s jkT;iky dysDVj izkf/kd`r djus gsrq funsZ'k nsrs gSaA

<!-- page 55 -->

Hkkx 1-d ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

1159

7&vf/kfu;e dh /kkjk&15 ds vUrxZr dksbZ Hkh O;fDr] ftldk fgr Hkwfe esa fufgr gks vf/klwpuk ds
izdk'ku ds 60 fnu ds vUnj vius {ks= esa Hkwfe vf/kxzg.k ds fo:) fyf[kr :i ls dysDVj] pUnkSyh dks vkifRr
izLrqr dj ldrk gSA
8&vf/kfu;e dh /kkjk&11¼4½ ds varxZr dksbZ O;fDr vf/klwpuk ds izdk'ku frfFk ls Hkwfe vf/kxzg.k dh
dk;Zokgh iw.kZ gksus rd dysDVj] pUnkSyh ds iwoZ vuqeksnu ds fcuk izkjfEHkd vf/klwpuk esa fufnZ"V Hkwfe dk
lO;ogkj ;Fkk foØ;@Ø; ;k ml Hkwfe esa dksbZ Hkkj mRiUu ugha dj ldrk gSA
mDr Hkwfe dk LFky uD'kk dysDVj] pUnkSyh ds dk;kZy; esa ns[kk tk ldrk gSA
¼g0½ vLi"V]
jkT; ljdkj@ftyk dysDVj]
pUnkSyhA

DEPARTMENT, INLAND WATER WAYS AUTHORITY OF INDIA
FORM-18
[ Sub-rule (2) of rule 20 ]
[ Under Sub-Section (1) of Section 11 of the Act ]
NOTIFICATION
October 12, 2026
No. 2347/VIII/S.L.A.O./Varanasi/2026--Under Sub-section (1) of section 11 of the Right to Fair
Compensation and Transparency in Rehabilitation and Resettlement Act, 2013, whereas the Government of
Uttar Pradesh / Collector for the purpose of Deployment of the Connecting the Multi-Modal Terminal (port)
at Ramnagar, Varanasi, in Chandauli District to Jeevnath pur railway station at Villages-Tahirpur,
Hamidpur, Gopalpur, and Patanwa, Tehsil: Pt. Deen Dayal Upadhyaya Nagar, District: Chandauli is
satisfied that a total Area of 9.759 hectares of land is required in the Village-Tahirpur, Hamidpur, Gopalpur,
and Patana, Tehsil: Pt. Deen Dayal Upadhyaya Nagar, District: Chandauli through Inland Waterways
Authority of India Department.
2. Social Impact Assessment study was carried out by "Atlas Managment Consultancy Services Pvt.
Ltd. 114/A, Ashok puram, Opposite Road 4, Ashok nagar, Ranchi"and it has submitted its recommendations
to the Appropriate Government Agency which has approved its recommendations on dated 10.09.2026.
3. The summary of Social Impact Assessment as follows:I-The objective of constructing a new Railway line to connect Jeevnathpur Railway Station in
Chandauli District to the Multi-Modal Terminal located at Ralhupur in Ramnagar is related to a
public purpose/public interest, and the expert group acknowledges the necessity and utility of
the project.
II- The potential benefits from the construction of the project are significantly higher compared to
the adverse social impacts caused by the land acquisition.
4-There is no possibility of any family being displaced in the Village in question due to the
land acquisition.

<!-- page 56 -->

1160

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 1-d

In the sequence of Government Order No. 0.414/One-13-2014-7A(8)/2014 Lucknow dated 06
August 2014, issued by the Government of Uttar Pradesh, The Sub-Divisional Officer, Pt. Deen Dayal
Upadhyaya Nagar, Chandauli is appointed as Administrator for the purpose of rehabilitation and
resettlement of the affected families.
5-Therefore, the Governor is pleased to accept and notify for general information that the land
mentioned in the Schedule given below is needed for public purpose.
SCHEDULE
Sl.
No.

District

Tehsil

Pargana

Village

Plot no.

Area to be
acquired

1

2

3

4

5

6

7
Hectares

1.

13 mi

0.207

15 mi

0.0230

17 mi

0.1800

Total…

0.410

154

0.008

5.

162

0.144

6.

163

0.218

7.

164

0.024

8.

168

0.036

9.

184

0.001

10.

187

0.006

11.

185

0.281

12.

186

0.062

13.

188

0.090

14.

190

0.017

15.

199

0.075

16.

200

0.012

17.

301

0.079

18.

303

0.097

19.

304

0.012

20.

305

0.101

21.

306

0.116

22.

307

0.097

23.

310

0.095

2.

Chandauli

Pt. Deen Dayal
Upadhyaya Nagar

Ralhupur

Tahirpur

3.

4.

Hamidpur

<!-- page 57 -->

Hkkx 1-d ]
1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½
2

3

4

5

6

1161
7
Hectares

24.

312

0.105

313

0.195

26.

320

0.059

27.

78

0.013

28.

79

0.511

29.

83

0.039

30.

86

0.237

31.

98

0.071

32.

147

0.001

33.

150

0.077

34.

151

0.124

35.

152

0.158

36.

153

0.192

37.

77

0.050

38.

192

0.179

39.

193

0.004

40.

203

0.133

41.

308

0.217

42.

309

0.126

43.

311

0.050

Total…

4.112

26 mi

0.2700

45.

25 mi

0.1220

46.

3 mi

0.3680

47.

22 mi

0.1310

48.

20 mi

0.1520

49.

19 mi

0.1750

50.

18 mi

0.3820

51.

51 mi

0.0060

52.

56 mi

0.0060

53.

57 mi

0.1260

Total…

1.738

25.

44.

Chandauli

Pt. Deen Dayal
Upadhyaya Nagar

Ralhupur

Hamidpur

Gopalpur

<!-- page 58 -->

1162
1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½
2

3

4

5

6

[ Hkkx 1-d
7
Hectares

54.

598

0.138

658

0.010

56.

589

0.010

57.

587

0.304

58.

582

0.231

59.

575

0.019

60.

573

0.105

61.

660

0.208

62.

659

0.096

63.

603

0.065

64.

599

0.052

65.

602

0.080

66.

601

0.020

67.

574

0.064

68.

543

0.038

69.

544

0.154

70.

583

0.099

71.

580

0.108

72.

581

0.064

73.

579

0.067

74.

490

0.024

75.

491

0.304

76.

493

0.028

77.

597

0.016

78.

548

0.225

79.

656

0.062

80.

649

0.303

81.

650

0.055

82.

546

0.144

83.

648

0.284

55.

Chandauli

Pt. Deen Dayal
Upadhyaya Nagar

Ralhupur

Patna

<!-- page 59 -->

Hkkx 1-d ]
1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½
2

3

4

5

6

1163
7
Hectares

84.
85.

Chandauli

Pt. Deen Dayal
Upadhyaya Nagar

Ralhupur

Patna

86.

549

0.063

572

0.057

550

0.002

Total…

3.499

All Total…

9.759

6-The Hon'ble Governor is also pleased to authorize the Collector, District Chandauli for the
purpose of land acquisition to take necessary steps to enter upon, conduct survey of land, take levels of any
land, dig are sub-soil in to and do all the Acts required for the proper execution of work as provided and
specified under section 12 of the Act.
7-Under section 15 of the Act, any person interested in the land may within 60 days after the
publication of this notification, make an objection to the acquisition of land in the locality in writing to
the Collector.
8-Under section 11(4) of the Act, no person shall make any transaction or cause any transaction of
land i.e. sale/ purchase, specified in the preliminary notification or create any encumbrances on such land
from the date of publication of such notification till such time as the proceedings of land acquisition is
completed, without prior approval of the Collector.
NOTE: A plan of the land may be inspected in the Office of the Collector, For the purpose
of acquisition.
(Sd.) Illegible,
State Government/Collector,
Chandauli.

[ fu;e-27 dk mifu;e ¼1½ ]
¼vf/kfu;e dh /kkjk-19 dh mi /kkjk ¼1½ ds vUrxZr½

12 vDVwcj] 2026 bZ0
la0 312@vkB&,y0,0lh0@jkeiqj@2026&jkeiqj fodkl izkf/kdj.k] jkeiqj ds }kjk O;kseds'k vkoklh;
;kstuk ds fodkl gsrq ftyk jkeiqj esa rglhy lnj ds jktLo xzke igkM+h] cM+iqjk 'kdhZ] rk'kdk] HkejkSvk esa dqy
7-3541 gsDV;j Hkwfe ds lEcU/k esa Hkwfe vtZu] iquokZlu vkSj iquO;ZLFkkiu esa mfpr izfrdj vkSj ikjnf'kZrk dk
vf/kdkj vf/kfu;e 2013 dh /kkjk 11 dh mi/kkjk ¼1½ ds vUrxZr tks izkjfEHkd vf/klwpuk la[;k
40@vkB&,y0,0lh0 ¼Hkw0v0½@jkeiqj fnukad 18 twu] 2026 dks fuxZr dh x;h Fkh rFkk vfUre :Ik ls nks
nSfud lekpkj-i= fgUnqLrku esa fnukad 26-06-2026 ,oa 28-06-2026 ,oa nSfud tkxj.k esa fnukad 26-06-2026 ,oa
159 [k

<!-- page 60 -->

1164

[ Hkkx 1-d

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

fnukad 28-06-2026 dks izdkf'kr dh x;hA mi ftykf/kdkjh] lnj dks viuh {ks=h; vf/kdkfjrk ds Hkhrj izHkkfor
ifjokjksa ds iquokZlu ,oa iquO;ZoLFkkiu ds mÌs'; ls iz'kkld fu;qDr fd;k x;k FkkA
vf/kfu;e dh /kkjk&15 dh mi/kkjk&¼2½ ds izko/kkuksa ds vuqikyu esa dysDVj }kjk izLrqr fjiksVZ ds
fopkjksijkUr /kkjk&19 ¼1½ ds vUrxZr jkT;iky ?kks"k.kk djus dk funsZ'k nsrs gS afd mUgsa ;g lek/kku gks x;k gS fd
vuqlwph ßdÞ esa of.kZr Hkwfe dk {ks=Qy lkoZtfud iz;kstu gsrq vko';d gSA ifj;kstuk ds vUrxZr foLFkkfir gksus
okys ifjokjksa dh la[;k 'kwU; gS vr% vuqlwph ß[kÞ esa mfYyf[kr ftyk jkeiqj rglhy lnj ds xzkeigkM+h] cM+iqjk
'kdhZ] rk'kdk] HkejkSvk dh foLFkkfir ifjokjksa ds iquokZlu ,oa iquO;ZoLFkkiu gsrq iquokZlu ,oa iquO;ZoLFkkiu {ks= ds
:Ik esa dksbZ Hkwfe fpfUgr djus dh vko';drk ugha ik;h xbZA
jkT;iky vf/kfu;e dh /kkjk&19 dh mi/kkjk ¼2½ ds v/khu bl izHkko dh ?kks"k.kk ds izdk'ku ds lkFk
iquokZlu ,oa iquO;ZoLFkkiu ;kstuk ds lkjka'k ds izdk'ku gsrq dysDVj jkeiqj dks funsZf'kr djrs gSaA
O;kseds'k vkoklh; ;kstuk ds fodkl gsrq tuin jkeiqj dh rglhy lnj ds ifj;kstuk ls izHkkfor xzkeksa
esa Hkwfe vtZu ls dksbZ ifjokj foLFkkfir u gksus ds dkj.k iquZoklu ,oa iquZO;oLFkkiu gsrq fdlh Hkwfe dks fpfUgr
djus vksj iquZoklu ,oa iquZO;oLFkkiu ;kstuk ds lkjka'k ds izdk'ku dh vko';drk ugh gSA
¼izLrkfor vtZu ds vUrxZr Hkwfe½
tuin

rglhy

ijxuk

xzke

Hkw[k.M la[;k

vftZr fd;s tkus okyk
{ks=Qy

1

2

3

4

5

6
gsDVs;j

jkeiqj

lnj

lnj

igkM+h

cM+iqjk 'kdhZ

Rkk'kdk

167

0-1180

259

0-0860

333

0-3950

359

0-0800

368

0-0770

13fe0

0-0242

35

0-1700

51

0-0094

452

1-0370

464@2

0-5310

470

0-0260

<!-- page 61 -->

Hkkx 1-d ]
1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½
2

3

4

5

1165
6
gsDVs;j

jkeiqj

lnj

lnj

Rkk'kdk

HkejkSvk

478

0-2530

479

0-5400

480

0-2750

481

0-1700

482

2-1000

483

0-3040

484

0-2090

485

0-2020

486

0-3040

487

0-3170

494

0-1265
;ksx

7-3541

¼foLFkkfir ifjokjksa ds fy, O;oLFkkiu {ks= ds :i esa fpfUgr Hkwfe½
tuin

rglhy

ijxuk

xzke

Hkw[k.M la[;k

iquokZlu gsrq
fpfUgr {ks=Qy

1

2

3

4

5

6
gsDVs;j

'kwU;

'kwU;

'kwU;

'kwU;

'kwU;

'kwU;

fVIi.kh&mDr Hkwfe dk LFky uD'kk dysDVj] jkeiqj ds dk;kZy; esa ns[kk tk ldrk gSA
¼g0½ vLi"V]
Leqfpr ljdkj@
dysDVj] jkeiqjA

<!-- page 62 -->

1166

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 1-d

RAMPUR DEVELOPMENT AUTHORITY, RAMPUR
FORM-19
[ Sub-rule (1) of rule 27 ]
Declaration by Appropriate Government/Collector
[ Under Sub-Section (1) of Section 19 of the Act ]
NOTIFICATION
October 12, 2026
No. 312/VIII/.L.A.C./Rampur/2026--For the development of the Vyomkesh Residential Scheme by the
Rampur Development Authority, Rampur, a preliminary notification bearing number 40/8-LAC (L.A.)/Rampur dated
June 18, 2026 was issued under Section 11(1) of the Right to Fair Compensation and Transparency in Land
Acquisition, Rehabilitation and Resettlement Act, 2013. The notification concerned a total of 7.3541 hectares of land
across the revenue villages of Pahadi, Barhpura Sharqi, Tashka and Bhamraua in Tehsil Sadar, District Rampur was
subsequently published in two daily newspapers “Hindustan” on June 26, 2026, and 28.06.2026 and “Dainik Jagran” on
26 June, 2026 or June 28, 2026. The Sub-Divisional Magistrate (Sadar) was appointed as the Administrator for the
purpose of the rehabilitation and resettlement of affected families within their territorial jurisdiction.
Upon consideration of the report submitted by the Collector in compliance with the provisions of Section
15(2) of the Act, the Governor, under Section 19(1), directs the issuance of a declaration, being satisfied that the land
area described in Schedule 'A' is required for a public purpose. As the number of families to be displaced under the
project is zero, no land has been found necessary to be identified as a rehabilitation and resettlement area for the
rehabilitation and resettlement of displaced families from the villages of Pahadi, Barhpura Sharqi, Tashka, and
Bhamraua (Tehsil Sadar, District Rampur) mentioned in Schedule 'B'.
The Governor directs the Collector of Rampur to publish the summary of the Rehabilitation and Resettlement
Scheme, along with the publication of the declaration to this effect, under sub-section (2) of Section 19 of the Act.
Since no families are being displaced due to land acquisition in the villages affected by the Vyomkesh
Residential Scheme project (located in Tehsil Sadar, District Rampur), there is no need to identify land for
rehabilitation and resettlement or to publish a summary of the rehabilitation and resettlement plan.
SCHEDULE-A
(LAND UNDER PROPOSED ACQUISITION)

District

Tehsil

Pargana

Village

Plot no.

Area to be
acquired

1

2

3

4

5

6
Hectares

Rampur

Sadar

Sadar

Pahadi

167

0.1180

259

0.0860

333

0.3950

359

0.0800

368

0.0770

<!-- page 63 -->

Hkkx 1-d ]
1

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½
2

3

4

1167

5

6
Hectares

Rampur

Sadar

Sadar

Barhpura Sharqi

Tashka

13m

0.0242

35

0.1700

51

0.0094

452

1.0370

464/2

0.5310

470

0.0260

478

0.2530

479

0.5400

480

0.2750

481

0.1700

482

2.1000

483

0.3040

484

0.2090

485

0.2020

486

0.3040

487

0.3170

494

0.1265

Bhamraua

Total

7.3541

SCHEDULE-B
(LAND IDENTIFIED AS SETTLEMENT AREA FOR DISPLACED FAMILIES)

District

Tehsil

Pargana

Village

Plot no.

Area to be acquired

1

2

3

4

5

6

NO. OF DISPLACED FAMILIES IS “ZERO”

NOTE: A plan of land may be inspected in the Office of the Collector Rampur for the purpose of
acquisition.
(Sd.) Illegible,
Appropriate Government/
Collector, Rampur.

<!-- page 64 -->

1168

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 1-d

¼vf/kfu;e dh /kkjk-11 dh mi /kkjk ¼1½ ds vUrxZr½
23 vDVwcj] 2026 bZ0
la0 864 @vkB&fo0Hkw0v0v0@xks.Mk@2026&Hkwfe vtZu] iquokZlu vkSj iquO;ZoLFkkiu esa mfpr izfrdj
vkSj ikjnf”kZrk dk vf/kdkj vf/kfu;e&2013 dh /kkjk&11 dh mi/kkjk ¼1½ ds v/khu dysDVj xks.Mk ¼leqfpr
ljdkj½ dk mn~ns”;@jk; gS] fd tuin xks.Mk dh rglhy rjcxat ijxuk uokcxat xzke bLekbyiqqj ,grekyh
esa 60-00 eh0 pkSM+s lkfyM fiad LVksu ls fufeZr izos”k }kj ¼guqeku }kj½ ds fuekZ.k gsrq 0-2103 gs0 Hkwfe yksd
ifj;kstuk gsrq vko”;drk gS] ftlds fy, Hkwfe vtZu] iquokZlu vkSj iquO;ZoLFkkiu esa mfpr izfrdj vkSj
ikjnf”kZrk dk vf/kdkj vf/kfu;e&2013 esa fufgr izko/kkuksa ds vUrxZr leqfpr ljdkj] ftyk ds dysDVj gSaA
lkekftd lek?kkr fu/kkZj.k dk v/;;u ukfer ,tsUlh }kjk fd;k x;k gS] rFkk leqfpr
ljdkj@dysDVj xks.Mk dks viuh vuq”kalk izLrqr dh x;h gS] ftls leqfpr ljdkj@dysDVj xks.Mk }kjk
vuqeksfnr fd;k x;k gSA
lkekftd lek?kkr fu/kkZj.k fjiksVZ dk lkjk¡”k bl izdkj gS %&
tuin xks.Mk ds rglhy rjcxat ijxuk uokcxat ds xzke bLekbyiqj ,grekyh esa v;ks/;k&cLrh jk’Vªh;
jktekxZ&27 ij xzke bLekbyiqqj ,grekyh esa 60-00 eh0 pkSM+s lkfyM fiad LVksu ls fufeZr izos”k }kj ¼Jh guqeku
}kj½ ds fuekZ.k gsrq Hkwfe vf/kxzg.k dh lkekftd lkek?kkr vkdyu dh vafre vk[;k dk ewY;kadu rFkk
Hkw&Lokfe;ksa ls laokn vkSj LFky Hkze.k ds i”pkr fo”ks’kK lewg bl urhts ij igq¡pk gS fd Jh guqeku }kj dh ;g
ifj;kstuk iw.kZ :Ik ls lkoZtfud yksdfgr esa vkSj vke tuekul ds fy, mi;ksxh gSA Hkw&Lokfe;ksa }kjk eqvkots
;k Hkqxrku] Hkwfe vtZu] iquokZlu vkSj iquO;ZoLFkkiu esa mfpr izfrdj vkSj ikjnf”kZrk dk vf/kdkj vf/kfu;e&2013
,oa 2016 ds vuq:i fn;k tkuk pkfg,A Jh guqeku }kj fuekZ.k ds fy, Hkwfe dk vf/kxzg.k vafre fodYi gS vkSj
izLrkfor Hkwfe rduhdh :i ls lokZsRre gSA bu leLr rF;kas ds ijh{k.k ds i”pkr~ cgq”kk[kh; fo”ks’kK lewg
loZlEefr ls bl ifj;kstuk ds fufeZr Hkwfe vtZu ij lkekftd lek?kkr fu/kkZj.k fjiksVZ ,oa lkekftd lek?kkr
izcU/ku ;kstuk ls lger gksrs gq, vko”;d Hkwfe dk vf/kxzg.k fd;s tkus dh laLrqfr dh gSA rduhdh O;ogkfjdrk
dh n`f’V ls Hkh xks.Mk tuin ds bl Jh guqeku }kj ds fuekZ.k gsrq Hkwfe dk vf/kxzg.k vafre fodYi gS vkSj
izLrkfor Hkwfe rduhdh :i ls lokZsRre gSA ifj;kstuk gsrq tks Hkwfe@{ks= vf/kxzg.k gsrq fpfUgr gS] ml Hkwfe dh
fLFkfr dks ns[krs gq, ;g csgrj vkSj vfUre fodYi gSA ifj;kstuk esa fdlh Hkh izdkj dh foLFkkiu dh fLFkfr
mRiUu gksus dh laHkkouk ugha gSA ifj;kstuk ds fy, vko”;d dqy Hkwfe ds lkis{k iz”uxr vtZu gsrq izLrkfor Hkwfe
vR;Ur de gSA
bl ifj;kstuk ds vUrxZr lkekftd ,oa vkfFkZd n`f’V ls Hkwfe vtZu ds dkj.k dksbZ ifjokj foLFkkfir
ugha gks jgk gSA
vr% leqfpr ljdkj@dysDVj xks.Mk] lkoZtfud iz;kstu gsrq fuEufyf[kr vuqlwph esa mfYyf[kr Hkwfe
dks lkekU; lwpuk gsrq vf/klwfpr djus ds fy, lgefr nsrs gSaA

<!-- page 65 -->

Hkkx 1-d ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

1169

tuin

rglhy

ijxuk

xzke

xkVk la[;k

izLrkfor {ks=Qy

1

2

3

4

5

6
gsDVs;j

xks.Mk

rjcxat

uokcxat

bLekbyiqj ,grekyh

287

0-0274

292

0-0060

586

0-0900

300

0-0230

301

0-0639

vf/kfu;e dh /kkjk&15 ds vUrxZr dksbZ O;fDr] ftldk fgr Hkwfe eas fufgr gks] vf/klwpuk ds izdk”ku
ds 60 fnu ds vUnj vius {ks= esa Hkwfe vf/kxzg.k ds fo:) fyf[kr :i ls dk;kZy; fo”ks’k Hkwfe v/;kfIr vf/kdkjh
xks.Mk esa vkifRr izLrqr dj ldrk gSA
vf/kfu;e dh /kkjk&11¼4½ ds vUrxZr dksbZ O;fDr vf/klwpuk ds izdk”ku dh frfFk ls Hkwfe vf/kxzg.k dh
dk;Zokgh iw.kZ gksus rd dysDVj ds iwoZ vuqeksnu ds fcuk izkjfEHkd vf/klwpuk esa fufnZ’V Hkwfe dk lO;ogkj ;Fkk
foØ;@Ø; ;k ml Hkwfe esa dksbZ Hkkj mRiUu ugha dj ldrk gSA
mDr Hkwfe dk LFkyh; uD”kk dysDVj xks.Mk@fo”ks’k Hkwfe v/;kfIr vf/kdkjh xks.Mk ds
dk;kZy; esa ns[kk tk ldrk gSA
fiz;adk fujatu]
l{ke izkf/kdkjh@
dysDVj] xks.MkA

OFFICE COMPETENT AUTHORITY/COLLECTOR, GONDA
[ Under Sub-Section (1) of Section 11 of the Act ]

NOTIFICATION
October 23, 2026
No.864/VIII-S.L.A.O./Gonda/2026–The Collector, Gonda (the appropriate government),
under Sub-section (1) of Section 11 of the Right to Fair compensation and Transparency in land
acquisition, Rehabilitation and Resettlement Act, 2013, is of the opinion that 0.2103 hectares of
land is required for a public purpose for the construction of an entrance Gate (Hanuman Gate),
made of solid pink stone and measuring 60.00 metre-wide, in Village-Ismailpur Ahatmali, ParganaNawabganj, Tehsil-Tarabganj, District- Gonda.For this purpose, Land Acquisition is required in
accordance with the provisions contained in the Right to Fair compensation and Transparency in
land acquisition, Rehabilitation and Resettlement Act, 2013, under which the appropriate
Government is the District Collector.

<!-- page 66 -->

1170

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 1-d

2. The Social Impact Assessment study has been conducted by the designated Agency, and
its recommendations have been submitted to the appropriate Government/Collector, Gonda, which
have been approved by the appropriate Government/Collector, Gonda.
3. The summary of the Social Impact Assessment Report is as follows :–
After evaluating the final report of the Social Impact Assessment (S.I.A.) for the acquisition
of Land for the construction of a 60.00 metre-wide Entrance Gate made of Solid Pink Stone (Shri
Hanuman Dwar) on the Ayodhya–Basti National Highway-27, at Village-Ismailpur Ahatmali,
Pargana-Nawabganj, Tehsil-Tarabganj, District-Gonda, and after Interacting with availble
landowners and a site inspection, the expert group has reached the conclusion that the Shri
Hanuman Dwar project is entirely in the public interest and beneficial to the general public. The
landowners should be provided with compensation or payment in accordance with the provisions of
the Right to Fair compensation and Transparency in land acquisition, Rehabilitation and
Resettlement Act, 2013, and the applicable provisions of 2016. The acquisition of land for the
construction of Shri Hanuman Dwar is the last resort, and the proposed land is technically the most
suitable one. After examining all these facts, the multidisciplinary expert group, by consensus,
agrees with the Social Impact Assessment Report and the Social Impact Management Plan prepared
for the Land Acquisition for this project and recommends that the should be required land be
acquired. From the perspective of technical feasibility as well, land acquisition for the construction
of Shri Hanuman Dwar in Gonda District is the last resort, and the proposed land is technically the
most suitable one. Considering the existing condition of the land/area identified for acquisition for
the project, this option is the best one and the final alternative. There is no possibility of any kind of
displacement arising from the project. The land proposed for acquisition is very small in
comparison to the total land required for the project.
4. Under this project, no family are individual being displaced due to land acquisition from
a social and economic perspective.
5. Therefore, the appropriate Government/Collector, Gonda, agrees to notify the land
mentioned in the following Schedule for public purposes, for general information–
SCHEDULE
District

Tehsil

Pargana

Village

Plot No.

Area to be
Acuired

1

2

3

4

5

6
Hectares

Gonda

Tarabganj

Nawabganj

Ismailpur
Ahatmali

287

0.0274

292

0.0060

586

0.0900

300

0.0230

301

0.0639

Total ...

0.2103

<!-- page 67 -->

Hkkx 1-d ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

1171

6. Under Section 15 of the Act, if any person having any issue in the above mention land
may, within 60 days from the date of publication of the notification, submit an objection in writing
against the acquisition of the land within his/her area to the Office of the special land acquisition
Officer, Gonda.
7. Under Section 11(4) of the Act, no person shall, without the prior approval of the
Collector, sell, purchase, or otherwise deal with the land specified in the preliminary notification, or
create any encumbrance on such land, from the date of publication of the notification until
completion of the proceedings for acquisition of the land.
Note: The site map of the aforesaid land may be inspected at the Office of the Collector, Gonda/
special land acquisition Officer, Gonda.
Priyanka Niranjan,
Competent Authority,
Collector, Gonda.

13 ebZ] 2026 bZ0

dk;kZy; vkns'k la[;k 155 [k¼funs0½@2026&mRrj izns'k yksd lsok vk;ksx] iz;kxjkt ds i=
la[;k&125¼9½@64@ih@,l&1¼9½@2024&25 fnukad 08 ebZ] 2026 ds vuqØe esa eqnz.k ,oa ys[ku lkexzh foHkkx
esa lgk;d funs'kd ¼ys[ku lkexzh½ ds fjDr in ij izksUufr ds fy, mRrj izns'k jktdh; eqnz.kky; ,oa lEc)
vf/k"Bku ¼jktdh;½ ¼jktif=r vf/kdkjh½ lsok fu;ekoyh&1981 ds lqlaxr fu;eksa ,oa mRrj izns'k yksd lsok
vk;ksx ds lijke'kZ ls vk;ksftr p;u lfefr dh cSBd fnukad 06-05-2026 ds Øe esa vk;ksx dh laLrqfr ds
vUrxZr Jh txnh'k ukjk;.k mik/;k;] iz'kklfud vf/kdkjh] funs'kky;] eqnz.k ,oa ys[ku lkexzh m0iz0 iz;kxjkt
dks dk;kZy; vkns'k fuxZr gksus ds fnukad ls eSfVªDl ysoy&7 #0 44]900@& ls #0 1]42]400@& ¼xzsM is&4600½
esa furkUr vLFkkbZ :i ls lgk;d funs'kd ¼ys[ku lkexzh½ ds fjDr in ij inksUufr djrs gq;s funs'kky; esa
dk;ZHkkj xzg.k djus dh frfFk ls nks o"kZ dh ifjoh{kk vof/k ij j[ks tkus dk vkns'k fd;k tkrk gS&

1

Jh txnh'k ukjk;.k mik/;k;]

2024&2025

iz'kklfud vf/kdkjh

lgk;d funs'kd
¼ys[ku lkexzh½

lEcfU/kr vf/kdkjh vius rSukrh LFkku ij dk;ZHkkj xzg.k djsaA
iquhr dqekj frokjh]
funs'kd]
eqnz.k ,oa ys[ku lkexzh]
m0iz0] iz;kxjktA
160 [k

<!-- page 68 -->

1172

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 1-d

-

13 ebZ] 2026 bZ0

la[;k LFkk0funs0&III&596&vf/k0oxZ@26&izekf.kr fd;k tkrk gS fd eqnz.k ,oa ys[ku lkexzh foHkkx]
m0iz0 iz;kxjkt ds dk;kZy; vkns'k la[;k&155[k¼funs0½@26 fnukad 13-05-2026 ds vuqikyu esa lgk;d funs'kd
¼ys[ku lkexzh½ ds in ij izksUufr ds QyLo:i fnukad 13-05-2026 ds iwokZUg ls dk;ZHkkj xzg.k fd;k x;kA

eqDr vf/kdkjh

gLrk{kj

ekspd vf/kdkjh

txnh'k ukjk;.k mik/;k;
izfrgLrk{kfjr
funs'kd
eqnz.k ,oa ys[ku lkexzh]
m0iz0] iz;kxjkt
iquhr dqekj frokjh]
funs'kd]
eqnz.k ,oa ys[ku lkexzh]
m0iz0] iz;kxjktA

ih0,l0;w0ih0&30 fgUnh xtV&Hkkx 1-d&2026 bZ0A
eqnzd ,oa izdk'kd&funs'kd] eqnz.k ,oa ys[ku-lkexzh] mÙkj izns'k] iz;kxjktA

<!-- page 69 -->

jftLVMZ ua å &,åMhå&4
ykbls U l la å &MCY;w å ihå&41
¼ykbls U LM Vw iks L V fcnkmV iz h is e s U V½

ç;kxjkt] 'kfuokj] 24 vDVwcj] 2026 bZå ¼dkfrZd 02] 1948 'kd laor~½
uxjikfydk ifj"kn~] uxj iapk;r] ljdkjh dkxt-i=] nckbZ gqbZ :bZ dh xkaBksa dk fooj.k-i=] tUe-ej.k
ds vkadM+s] jksxxzLr gksus okyksa vkSj ejus okyksa ds vkadM+s] Qly vkSj _rq lEcU/kh fjiksVZ]
cktkj-Hkko] lwpuk] foKkiu bR;kfnA
NOTICE
No Legal Responsibility is accepted for the Publication of Advertisements/Public Notices in this Part of the
Gazette of Uttar Pradesh. Persons Notifying the Advertisements/Public Notices will remain Solely, Responsible for the
Legal Consequences and also for any other Misrepresentation etc.
By Order,
Director.

30 tqykbZ] 2025 bZ0
la0 253@u0ia0yk0@mifof/k@2025&'kklukns'k la[;k-925@ukS-9-2025-bZ-1853096 uxj fodkl
vuqHkkx-9 y[kuÅ fnukad 09 ebZ] 2025 ,oa uxj iapk;r lfefr dh cSBd fnukad 21 uoEcj] 2025 ds ladYi
la[;k&06 rFkk la;qDr çkUr uxj ikfydk vf/kfu;e] 1916 ¼la0ç0 ,sDV la[;k 2 1916½ dh /kkjk 147 vkSj /kkjk
298 dh mi/kkjk ¼1½ ds v/khu çkIr vf/kdkjksa dk ç;ksx djds uxj iapk;r ykoM+ us viuh lhek ds vUrxZr
cuk;h gSA ftls mDr ,sDV dh
/kkjk 301 ¼1½ ds vUrxZr vkifÙk;k¡ ,oa lq>ko gsrq fnukad 30 tqykbZ] 2025 ls fnukad 29 vxLr] 2025 rd ds
fy;s bl dk;kZy; ds i=-la[;k 253@u0ia0yk0@mifof/k@2025 fnukad 30 tqykbZ] 2025 ds }kjk jk"Vªh; lekpkj
i= nSfud HkkLdj esa çdkf'kr fd;k x;k FkkA mDr vof/k esa dksbZ vkifÙk;ka bl dk;kZy; esa çkIr ugh gqbZ gSA

¼1½ ;g mifof/k uxj iapk;r ykoM+ esjB ¼fu/kkZj.k lwph esa la'kks/ku vkSj ifjorZu½ lEcU/kh mifof/k] o"kZ
2024 dgyk;sxhA
264 V

<!-- page 70 -->

2104

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 8

¼2½ ;g mifof/k mRrj izns'k lk/kkj.k xtV esa izdkf'kr gksus ds fnukad ls ;k uxj iapk;r
lfefr@fofgr izkf/kdkjh dh Lohd`fr ls lhek esa izHkkoh gksxhA
¼1½ tc rd fo"k; ;k lUnHkZ esa dksbZ ckr izfrdwy u gks] bl mifof/k esa&
¼d½

**

** dk rkRi;Z la;qDr izkUr uxj ikfydk vf/kfu;e] 1916 ¼la0iz0 ,sDV la[;k 2]

1916½ ls gSA
¼[k½ **
** dk rkRi;Z ,sls {ks= ls gS tks jktLo vfHkys[kksa esa vkcknh ds :Ik eas vfHkfyf[kr gks
vkSj ftldk mi;ksx uxj iapk;r ykoM+ lhek esa ml {ks= ds lfEefyr gksus ds fnukad dks mlds fuokfl;kas ds
vkokl vkSj rRlEcU/kh iz;kstuksa ds fy;s fd;k tk jgk gksA
¼x½ **
fu/kkZj.k lwph ls gSA

* dk rkRi;Z vf/kfu;e] 1916 dh /kkjk 141 ds v/khu rS;kj dh xbZ dj

¼?k½ **
lwph esa la'kks/ku vkSj ifjorZu ls gSA
¼M½ **

** dk rkRi;Z vf/kfu;e] 1916 dh /kkjk 147 ds v/khu dj fu/kkZj.k

** dk rkRi;Z ;FkkfLFkfr fdlh Hkou ;k Hkwfe ;k nksuks ls gSA

¼p½ **
** dk rkRi;Z uxj iapk;r ykoM+ lhek esa vofLFkr Hkouksa ;k Hkwfe;ksa ;k nksuks ds
okf"kZd ewY; ij yxk;s tkus okys lkekU; dj@Hkou dj] ty dj] ty fuLrkj.k dj vkSj LoPNrk dj ls gSA
¼2½ bl mifof/k esa iz;qDr fdUrq vifjHkkf"kr 'kCnksa vkSj inksa ds ogh vFkZ gksxas tks vf/kfu;e esa muds
fy;s Øe'k% leuqnsf'kr gksA
¼1½ vf/kfu;e] 1916 dh /kkjk-144 ds v/khu uxj iapk;r ykoM+ esjB dk;kZy; esa tek izek.khd`r dj
fu/kkZj.k lwph eas la'kks/ku vkSj ifjorZu mDr vf/kfu;e] 1916 dh /kkjk-147 ds v/khu mfYYkf[kr dkjdksa ds izksn~Hkwr
gksus dh fLFkfr eas fd;k tk;sxkA
¼2½ ,slk O;fDr tks fu/kkZj.k lwph ds izek.khd`r gksus ds Ik'pkr~ fdlh dkj.ko'k djk/kku ds fy;s nk;h
gks x;k gS] mldk uke lwph esa lfEefyr djds fu/kkZj.k lwph esa la'kks/ku vkSj ifjorZu fd;k tk;sxkA
¼3½ ¼d½ fdlh lEifRr ds LokfeRo ds gLrkUrj.k ;k LokfeRo lkekU;rk fuEu ds vk/kkj ij izkIr gksxk&
¼,d½ iathd`r foØ;-i= }kjk]
¼nks½ iathd`r olh;r }kjk]
¼rhu½ iathd`r foHkktu foys[k }kjk]
¼pkj½ iathd`r nku-i= }kjk]
¼ik¡p½ fof/kd mRrjkf/kdkj }kjk]
¼[k½ fdlh lEifRr ds v/;klh ds LFkku ij fdlh O;fDr ds uke dh izfof"V dh fLFkfr lkekU;rk
bl izdkj gks ldsxh&
¼,d½ uxj iapk;r ykoM+ lhek esa uo lfEefyr vkcknh {ks= esa fLFkr lEifRr]
¼nks½ xSj tehankjh mUewyu ¼uku tsM0,0½ {ks= dh lEifRr]
¼rhu½ fdlh lEifRr ftldk fdjk;k fn;k tkrk gks ;k ns; gksA

<!-- page 71 -->

Hkkx 8 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

2105

¼pkj½ lEifRr dk fdjk;k eqDr fdjk;snkj vkSj vuqKkihA
¼4½
¼d½ lEifRr ds =qfViw.kZ ewY;kadu] okf"kZd ewY; vkSj dj dh nj esa o`f)@ifjorZu gksus ls dj
fu/kkZj.k lwph eas la'kks/ku vkSj ifjorZu fd;k tk ldsxkA
¼[k½ fdlh Hkh le; tc ;g Li"V gks tk;s fd fdlh lEifRr dk ewY;kadu vkSj dj fu/kkZj.k lEifRr
ds Lokeh@v/;klh }kjk xyr fooj.k nsus ds vk/kkj ij] ;k rF;ksa ds fNikus ij HkzkUr dFku ;k fdlh Hkwy ds dkj.k
fd;k x;k gS rks mlesa fd;s x;s lq/kkj dh izfof"V dj rnuqlkj dj fu/kkZj.k lwph la'kksf/kr dh tk ldsxhA
¼5½ Hkou esa fd;s x;s ifjorZu vkSj ifjo/kZu ds QyLo:Ik mlds okf"kZd ewY;kadu vkSj dj dh /kujkf'k
esa o`f) djds fu/kkZj.k lwph esa la'kks/ku fd;k tk ldsxkA
¼1½
¼d½ fu;e 3 ds v/khu fu/kkZj.k lwph esa O;fDr ;k lEifRr dk fooj.k NwV tkus] uo fuekZ.k ;k
iqufuZekZ.k gksus ij Lokeh ;k v/;klh fu/kkZfjr izi= ds lkFk lEifRr dk Lodj fu/kkZj.k dj ds lEifRr dj dh
/kujkf'k uxj iapk;r }kjk ;Fkk fufnZ"V cSad ;k dk;kZy; eas tek dj ldsxkA uxj iapk;r ds vf/k'kklh vf/kdkjh
;k mlds }kjk bl fufeRr izkf/kd`r fdlh vf/kdkjh }kjk Lodj fu/kkZj.k izi= ds vk/kkj ij visf{kr izfof"V;k¡
fu/kkZj.k lwph esa dh tk;sxhA
¼[k½ vU;Fkk fLFkfr eas lEifRr dk Lokeh ;k v/;klh fofgr izi=-1 esa visf{kr lwpuk fuekZ.k ;k
iqufuekZ.k ds lekiu vFkok v/;klu ds fnukad tks Hkh igys gks ds 60 fnolksa ds Hkhrj vf/k'kklh vf/kdkjh dks
vfuok;Z :Ik ls nsxkA vf/k'kklh vf/kdkjh rnqijkUr fu;ekuqlkj lEifRr dk ewY;kadu vkSj dj fu/kkZj.k dj
fu/kkZj.k lwph eas izfof"V djsxkA
¼2½
¼d½ lEifRr ds LokfeRo ;k v/;klu ds gLrkUrj.k ds QyLo:Ik dj fu/kkZj.k lwph ds la'kks/ku
vkSj ifjorZu ds fufeRr vkosnd uxj iapk;r dks izi=-2 eas viuk izksQkby cukdj vkosnu djsxkA
¼[k½ vkosnd uxj iapk;r }kjk fu/kkZfjr vkosnu 'kqYd] tks #0 100-00 izfr vkosnu ls vf/kd u
gksxk] dks vkuykbu Hkqxrku djsxk vkSj ;FkkfLFkfr fuEufyf[kr vfHkys[kks dks miyC/k djk;sxk&
-

1

vkosnd dh QksVks ¼ts0ih0th0 izk:Ik esa½







2

vkosnd dh igpku dk izek.k ¼ts0ih0th0
izk:Ik esa½







3

vkosnd dk 'kiFk-i= ¼ih0Mh0,Q0 izk:Ik esa½







4

iathd`r foØ;-foØ; ;k nkui=@ foHkktu
foys[k ¼ih0Mh0,Q0 izk:Ik esa½

&



&

5

mRrjkf/kdkj izek.k-i= ¼ih0Mh0,Q0 izk:Ik esa½



&

&

6

e`R;q izek.k-i= ¼th0vkbZ0,Q0] ih0,u0th0]
ts0ih0th0]
ts0ih0bZ0th0]
ih0Mh0,Q0
izk:Ik esa½



&



<!-- page 72 -->

2106

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

7

jftLVªhd`r
olh;r
ih0,u0th0]
ts0ih0th0]
ih0Mh0,Q0 izk:Ik esa½

8
9

¼th0vkbZ0,Q0]
ts0ih0bZ0th0]

[ Hkkx 8

&

&



Ekwy iV~Vk foys[k dh izfrfyfi





&

iwoZ es tkjh ukekUrj.k i= dh izfrfyfi ;fn
dskbZ gks







¼x½ vkosnu dkj.k izksnHkwr gksus ds vf/kdre rhu ekg ds Hkhrj izLrqr fd;k tk ldsaxkA bl
vof/k ds i'pkr~ uxj iapk;r }kjk fu;r foyEc 'kqYd ds lkFk vkosnu izLrqr fd;s tk ldsxasA
¼?k½ vf/k'kklh vf/kdkjh ;k mlds }kjk ,rnFkZ izkf/kd`r vf/kdkjh fu;e-6 ds vuqlkj izHkkj dh
/kujkf'k dh x.kuk djsxk vkSj vkosnu djus dh frfFk ls ik¡p dk;Z fnolkas ds vUnj vkosnd dks rRlEcU/k esa
vkuykbu Hkqxrku gsrq Hkh lwfpr fd;k tk;sxkA vkosnd }kjk rn~uqlkj iw.kZ /kujkf'k vkxkeh vf/kdre lkr fnolksa
esa Hkqxrku dh tk;sxhA fu/kkZfjr vof/k esa Hkqxrku izkIr gks tkus ij izLrkfor ifjorZu ;k la'kks/ku ds lEcU/k esa
izk:i-3 ij bl vk'k; dh de ls de ,d eghus dh uksfVl lHkh lEcfU/kr fgrc} O;fDr;kas dks tkjh dh tk;sxh
vkSj mldh ,d izfr vkosnd dks Hkh nh tk;sxhA
¼M½ [k.M ¼?k½ ds v/khu tkjh uksfVlksa dh lHkh i{kksa dks lE;d~ vkSj lUrks"ktud rkehyh u gksus
dh fLFkfr esa mDr uksfVl ml uxj iapk;r {ks= esa ifjpkyu okys de ls de nks nSfud lekpkj-i=ksa esa izdkf'kr
djkbZ tk;sxhA lekpkj-i= esa uksfVl ds izdk'ku dk 'kqYd mlds okLrfod O;; ds vuqlkj vkosnd }kjk tek
fd;k tk;sxkA oSdfYid :Ik esa vkosnd mls uxj iapk;r }kjk bl fufeRr fu/kkZfjr izfØ;k ds vuqlkj vius futh
O;; ij uxj iapk;r {ks= esa ifjpkyu okys nks nSfud lekpkj-i=ksa esa mDr uksfVl lh/ks izdkf'kr djk ldrk gSA
¼p½ [k.M ¼?k½ ds v/khu lalwfpr /kujkf'k dk Hkqxrku fu;e vof/k esa u fd;s tkus ij ,d vU;
volj iznku djrs gq, iqu% ,d lIrkg dk le; fn;k tk;sxkA bl vof/k es Hkh izHkkj dh /kujkf'k u tek djus
ij vkosnu fujLr dj fn;k tk;sxkA
¼N½ [k.M ¼?k½ vkSj [k.M ¼M½ ds vUrxZr tkjh uksfVl esa vafdr vof/k O;rhr gksus ds Ik'pkr~ dksbZ
mRrj ;k vkifRr izkIr u gksus dh fLFkfr eas vf/k'kklh vf/kdkjh }kjk vfHkYks[kksa ds fu;e lEer ik;s tkus ij
rnuqlkj vkns'k ikfjr djrs gq, fu/kkZj.k lwph esa ;FkkfLFkfr la'kks/ku ;k ifjorZu dj fn;k tk;sxk vkSj lwph
izek.khdj.k ds fy;s izkf/kd`r vf/kdkjh ds gLrk{kjksa ls mls izek.khd`r fd;k tk;sxkA
¼t½ [k.M ¼?k½ vkSj [k.M ¼M½ ds v/khu tkjh uksfVl eas fu;r vof/k ds Hkhrj mRrj ;k vkifRr
izkIr gksus dh n'kk eas vf/k'kklh vf/kdkjh ;k mlds }kjk bl fufeRr izkf/kd`r vf/kdkjh laf{kIr tk¡p vkSj lEcfU/kr
i{kks@vkifRrdrkZvksa ;k fgrc} O;fDr;ksa dks lE;d~ lquckbZ dk volj iznku djus ds Ik'pkr~ miyC/k vfHkYks[kh;
lkexzh xq.k-nks"k ds vk/kkj ij mudk fuLrkj.k djus vkSj leqfpr vkns'k ikfjr djus gsrq vf/k'kklh vf/kdkjh dks
vxzlkfjr djsxkA fdlh izdkj ds LoRokf/kdkj ls lEcfU/kr fookfnr izdj.k ij l{ke U;k;ky; dk fu.kZ; visf{kr
gksxkA
¼>½ fu/kkZj.k lwph esa la'kks/ku@ifjorZu lEcU/kh izHkkjksa lfgr vU; leLr ns;kas ds Hkqxrku izkIr
gksus ds fnukad ls vf/kdre 45 dk;Z fnolksa dh vof/k esa vfookfnr izdj.kksa lEcU/kh vkosnu dk fuLrkj.k fd;k
tk;sxkA
¼3½
¼d½ dj fu/kkZj.k lwph esa lEifRr ds v/;klu ds vk/kkj ij vafdr v/;kfl;ksa ds lEcU/k eas
la'kks/ku vkSj ifjorZu mDr vf/kfu;e] 1916 dh /kkjk-2 ds [k.M ¼11½ ds v/khu ifjHkkf"kr v/;klh ds i{k eas fd;s
tk ldsaxasA

<!-- page 73 -->

Hkkx 8 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

2107

¼[k½ dj fu/kkZj.k lwph ,oa rRlEcU/kh tkjh vkns'k esa ,sls la'kks/ku@ifjorZu fd;s tkus ij
'kCn dk Li"V mYys[k fd;k tk;sxk ftls izek.khd`r fd;k tk;sxkA
¼x½ v/;klu ds vk/kkj ij fd;s x;s dj fu/kkZj.k ds fo"k; esa okMZokj dj fu/kkZj.k lwph i`Fkd ls
rS;kj dh tk;sxh vkSj mls esa la'kks/ku@ifjorZu lEcU/kh visf{kr izfof"V;k¡ dh tk;sxhA
¼4½ fu/kkZj.k lwph ds la'kks/ku vFkok ifjorZu dk iz;kstu ek= Hkou] Hkwfe ;k nksuks ds lEifRr dj dh
olwyh ds n`f"Vxr gksxkA
¼1½ tc fdlh lEifRr ds lEifRr dj ds Hkqxrku ds fy;s izFker% nk;h fdlh O;fDr dk LoRokf/kdkj
gLrkUrfjr gksrk gS rks og O;fDr ftldk LoRokf/kdkj gLrkUrkfjr gqvk gS vkSj og O;fDr ftls og gLrkUrfjr
fd;k x;k gS] gLrkUrj.k foys[k ds fu"ikfnr gksus ds rhu ekg ds Hkhrj ,sls gLrkUrj.k dh lwpuk vf/k'kklh
vf/kdkjh dks nsxasA
¼2½ iwoksZDrkuqlkj izFker% nk;h fdlh O;fDr dh e`R;q dh n'kk esa og O;fDr ftls mRrjkf/kdkjh ds :Ik eas
;k vU;Fkk e`rd dk LoRokf/kdkj gLRkkUrfjr gqvk gS] vf/k'kklh vf/kdkjh dks e`rd dh e`R;q ds N% ekg ds Hkhrj
,sls gLrkUrj.k dh lwpuk nsxkA
¼3½ vf/k'kklh vf/kdkjh ;k mlds }kjk bl fufeRr izkf/kd`r vf/kdkjh dks mDr lwpuk ds ek/;e ls ,slk
gLrkUrj.k LkaKku esa vkrs gS] bl mifof/k ds izko/kkuksa ds vuqlkj vUrfjrh dk uke fu/kkZj.k lwph esa izfo"V dj
fn;k tk;sxkA
¼4½ izR;sd O;fDr tks vf/k'kklh vf/kdkjh dks bl izdkj dh lwpuk fn;s fcuk iwokZsDror~ gLrkUrj.k djrk
gS] ,slh mis{kk ls mn~Hkwr vU; ns;rk ds lfgr gLrkUrfjr lEifRr ij fu/kkZfjr lEifRr dj ds Hkqxrku dk nkf;Ro
fujUrj cuk jgsxk tc rd fd og bl lEcU/k esalwpuk@vkosnu ugh nsrk vFkok tc rd fd ,slk gLrkUrj.k
fu/kkZj.k lwph esa vfHkfyf[kr ugh fd;k tkrkA
¼5½ tc ,slh lwpuk@vkosnu fu;r vof/k esa izLrqr ugh fd;k x;k gksa rks uxj iapk;r }kjk fu;r
foYkEc 'kqYd ds lkFk bls izLrqr fd;k tk ldrk gSA
¼6½ ;fn dksbZ Hkou fxjk fn;k x;k gks ;k /oLr gks x;k gks rks rc rd vf/k'kklh vf/kdkjh dks bldh
uksfVl u ns xbZ gks] rc rd Lokeh@v/;klh lEifRr dj ds Hkqxrku dk nk;h gksxk tSlk fd og Hkou fxjk,
tkus ;k /oLr u fd;s tkus dh fLFkfr esa nk;h FkkA
¼1½ tgk¡ dj fu/kkZj.k lwph ds la'kks/ku vkSj ifjorZu gsrq vkosnu uxj iapk;r dks izLrqr fd;k tk; ogk¡
vkosnd ls izHkkj bl mifof/k ds vuqlkj mn~x`ghr fd;k tk;sxkA izHkkjkas dh njsa fuEuor~ gksxh&
¼d½ fdlh fof/kd mRrjkf/kdkjh ;k jftLVªhd`r olh;r ds ekeys esa izHkkj dh njsa fuEuor~ gksxh&

oxZQhV&

#i;s&

1

1000 rd

500-00

2

1001&2000 rd

1]000-00

3

2001&3000 rd

1]500-00

4

3001 ls vf/kd

2]500-00

<!-- page 74 -->

2108

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 8

¼[k½& fu;e-3 ds mifu;e ¼3½ ds v/khu vU; lHkh ekeyksa esa izHkkjksa dh nj ftykf/kdkjh }kjk fu;r
lfdZy jsV ;k iathdj.k foys[k eas vafdr /kujkf'k] tks Hkh vf/kd gks] ds vk/kkj ij fuEUkor~ gksxh&

#i;s&

#i;s&

1

#0 5 yk[k rd

500-00

2

#0 5 yk[k ls #0 10 yk[k rd

1]000-00

3

#0 10 yk[k ls #0 15 yk[k rd

15]00-00

4

#0 15 yk[k ls #0 50 yk[k rd

25]00-00

5

#0 50 yk[k ls Åij

5]000-00

¼2½& mi;qZDr njksa eas ifjorZu vf/kfu;e 1916 dh /kkjk 92 ds izkfo/kkuksa ds vUrxZr uxj iapk;r cksMZ dh
Lohd`fr@vuqefr ls fd;k tk ldsxkA
¼3½& mifu;e ¼1½ ds [k.M ¼d½ ds v/khu ,d ls vf/kd e/;orhZ la'kks/ku vkSj ifjorZu dh fLFkfr esa
izR;sd la'kks/ku vkSj ifjorZu ij mlesa fofufnZ"V /kujkf'k ds 10 izfr'kr dh nj ls vfrfjDr izHkkj ns; gksxkA
¼4½& ;fn mifu;e ¼1½ ds [k.M ¼[k½ ds ekeyksa esa ,d ;k ,d ls vf/kd e/;orhZ foØ; ;k vU; vUrj.k
gksa vkSj lEcfU/kr lEifRr e/;orhZ Øsrkvksa ;k vUrfjrh ds uke ls fu/kkZj.k lwph esa vUrfjr u dh xbZ gks rks
izR;sd e/;orhZ foØ; foys[k@vUrj.k ij bl mifof/k ds vuqlkj mifu;e-¼1½ ds [k.M ¼[k½ esa fofufnZ"V /kujkf'k
ds 25 izfr'kr dh nj ls vfrfjDr izHkkj mn~x`ghr fd;k tk;sxkA
¼5½& ;fn ml lEifRr ds lEcU/k esa uxj iapk;r ls lEcfU/kr dksbZ /kujkf'k ns; gks rks mldk Hkqxrku
fu/kkZj.k lwph ds la'kks/ku vkSj ifjorZu gsrq ns; izHkkjksa ds lkFk fd;k tk;sxkA
tgk¡ vf/k'kklh vf/kdkjh Lor% ;k vU;Fkk] ,slh tk¡p tSlk og mfpr
le>s ls lUrq"V gS fd lwph esa la'kks/ku ;k ifjorZu NYk] lkjoku rF;ksa ds nqO;Zins'ku djds vFkok rF;ksa dsk
fNikdj vFkok feF;k] v'kq) vkSj viw.kZ vfHkys[kksa ds vk/kkj ij fd;k x;k gS rks og lEcfU/kr O;fDr dks lquokbZ
dk ;qfDr;qDr volj nsrs gq, iqu% lquokbZ dj ldrk gS vkSj fyf[kr :Ik eas dkj.kksa dks vfHkfyf[kr djrs gq,
la'kks/ku ;k ifjorZu fujLr dj ldrk gS] mls la'kksf/kr dj ldrk gS vFkok ifjofrZr dj ldrk gSA
vf/k'kklh vf/kdkjh ds fdlh vkns'k ls {kqC/k dksbZ O;fDr ml fnukad ftl fnukad dks mls fofu'p;
lalwfpr fd;k x;k gS] ls rhl fnu ds Hkhrj mRrj izns'k uxj ikfydk vf/kfu;e 1916 dh /kkjk-160 ds v/khu
vihy dj ldrk gSA
-

1- Hkou Lokeh@v/;klh dk uke
2- Hkou la[;k@vkbZ0Mh0 lfgr Hkou dh vofLFkfr
3- Hkou dk orZeku okf"kZd ewY;

<!-- page 75 -->

Hkkx 8 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

2109

4- lEifÙk dj Hkqxrku dh v|ru jlhn la0
5- iwoZ ls fufeZr Hkou dk vkPNkfnr {ks=Qy
6- uo fuekZ.k] iqufuZekZ.k ;k ifjo/kZu va'k dk {ks=Qy
7- uo&fuekZ.k] iqufuZekZ.k ;k ifjo/kZu ds lekiu dh frfFk
8- v/;klu dh frfFk
9- vU; fooj.k& ;fn dksbZ gksA

LFkku&

gLrk{kj Hkou Lokeh@v/;klh

fnukad&

irk&
eksckbZy ua0&
-

1- vkosnd dk uke] fir` uke vkSj irk&
2- lEifÙk dk fooj.k&
¼1½& foØ; vkSj nku vkfn ds ekeyksa esa&
¼d½& lEifÙk la[;k@vkbZ0Mh0 vkSj orZeku Lokeh dk uke
¼[k½ Hkwfe dk {ks=Qy@Hkou dk vPNkfnr {ks=Qy
¼x½ orZeku okf"kZd ewY;
¼?k½ vUrfjrh dk uke] fir` uke vkSj irk
¼M+½ gLrkUrj.k dh ç—fr-fcØh@nku
¼p½ vUrj.k foys[k ds fucU/ku dh frfFk
¼N½ dksbZ vU; fooj.k
¼2½& e`R;q] olh;r vk/kkfjr mÙkjkf/kdkj ds ekeyksa esa&
¼d½ lEifÙk la[;k vkSj orZeku Lokeh dk uke
¼[k½ Hkwfe dk {ks=Qy@Hkou dk vPNkfnr {ks=Qy
¼x½ orZeku okf"kZd ewY;
¼?k½ O;fDr dk uke ¼ e`R;q frfFk lfgr½] fir` uke rFkk irk ftlds lkis{k mÙkjkf/kdkjh }kjk nkok
fd;k x;k gSA

<!-- page 76 -->

2110

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 8

¼³½ vkosnd dk e`rd ls lEcU/k
¼p½ mÙkjkf/kdkfj;ksa dk fooj.k vkSj va'k
¼N½ mÙkjkf/kdkj dk vk/kkj ¼iSr`d] olh;r vkfn½
¼t½ dksbZ vU; fooj.k
¼3½& HkzkUr dFku] Hkwy ;k yksi ds ekeyksa esa&
¼d½ lEifÙk la[;k vkSj orZeku Lokeh dk uke
¼[k½ Hkwfe dk {ks=Qy@Hkou dk vkPNkfnr {ks=Qy
¼x½ orZeku okf"kZd ewY;
¼?k½ HkzkUr dFku] =qfV ;k yksi dh ç—fr dk fooj.k
¼M+½ HkzkUr dFku] =qfV ;k yksi dh iqf"V esa lk{;
¼p½ dksbZ vU; fooj.k
mi Øekad ¼1½ ¼2½ ¼3½ esa ls ;Fkk ykxw fooj.k HkjsaA
3- vkosnu 'kqYd Hkqxrku dk fooj.k
4- viyksM fd;s x;s vfHkys[kksa dk fooj.k&
¼1½

¼2½

¼3½

¼4½

-

Jh@Jherh --------------------------------------------- iq=@iq=h@iRuh Jh@Jherh ------------------------------------------ fuoklh ------------------------------------------------------------------- dk uke uxj iapk;r ykoM+ dh dj fu/kkZj.k lwph esa vafdr gSA
2& ¼1½& Jh@Jherh ---------------------------------------- iq=@iq=h@iRuh Jh@Jherh ------------------------------------------ fuoklh ------------------------------------------------------- }kjk bl lEcU/k es vkosnu çLrqr fd;k x;k gS fd Jh@Jherh -------------------------------------------iq=@iq=h@iRuh Jh@Jherh ------------------------------------------------- dh e`R;q fnukad ------------------------------------------------------ dks gks xbZ
gS og@os muds fof/kd mÙkjkf/kdkjh gSa vkSj lk{; :i esa ----------------------------------------------------- çLrqr fd;k x;k gSA
¼2½& muds }kjk viuk uke çfo"V dj] fu/kkZj.k lwph dks la'kksf/kr@ifjofrZr djus dk vuqjks/k fd;k
x;k gSA
3& ;fn fdlh O;fDr@O;fDr;ksa dks mijksDr ds fo:) dksbZ vkifÙk gks rks og@os viuh vkifÙk;k¡ fyf[kr :i esa
lk{;ksa lfgr bl uksfVl ds çdkf'kr@çkIr gksus ds fnukad ls 30 fnu ds Hkhrj uxj iapk;r ykoM+ ds dk;kZy;
esa çLrqr dj ldrk@ldrh gSA mDr frfFk rd dksbZ vkifÙk çkIr u gksus dh fLFkfr esa vkosnd@vkosndksa dk
uke lwph esa çfo"V dj fn;k tk;sxk vkSj dksbZ i'pkorhZ nkok] xzg.k ugh fd;k tk;sxkA

<!-- page 77 -->

Hkkx 8 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½
lEifÙk vkbZ0Mh0

lEifÙk la[;k

tkjh djus dh frfFk
eqgj

2111

vofLFkfr
gLrk{kj
tkjh djus okys vf/kdkjh dk uke
inuke lfgr

çfrfyfi%& fuEufyf[kr dk lwpukFkZ&
1- leLr fgrc) O;fDr;ksa ds uke
2- vkosnd dk uke
vkQrkc csxe]
v/;{k]
uxj iapk;r ykoM+]
tuin esjBA
-

30 tqykbZ] 2025 bZ0
la0 254@u0ia0yk0@;w0pk0la'kksa0@2025-26&uxj iapk;r ykoM+ esjB ds }kjk ;wtj pktZ mifof/k 2023
ds lEcU/k esa mÙkj çns'k xtV] 27 tuojh] 2024 bZ0 ¼ek?k 07] 1945 'kd laor~½ çdkf'kr dh x;h FkhA ftlds
la'kks/ku gsrq vkifÙk;k¡ ,oa lq>ko gsrq fnukad 30 tqykbZ] 2025 ls fnukad 29 vxLr] 2025 rd ds fy;s bl
dk;kZy; ds i= la[;k 254@u0ia0yk0@;w0pk0la'kks0@2025-26 fnukad 30 tqykbZ] 2025 ds }kjk jk"Vªh; lekpkj
i= nSfud HkkLdj esa çdkf'kr fd;k x;k FkkA mDr vof/k esa dksbZ vkifÙk;ka bl dk;kZy; esa çkIr ugh gqbZ gSA
uxj ikfydk vf/kfu;e 1916 dh /kkjk 98] 296 ds v/khu 'kfDr;ksa dk ç;ksx djds uxj iapk;r lfefr
dh cSBd ds ladYi la[;k&07 fnukd 21 uoEcj] 2025 ds v/khu çkIr vf/kdkjksa dk ç;ksx djds uxj iapk;r
ykoM usa viuh lhek ds vUrxZr ;wtj pktZ mifof/k esa fuEuor la'kks/ku fd;k tkrk gS&
-

Øe
la0

miHkksDrk dh Js.kh

1
14

2
fjgk;'kh edku ¼Mksj Vw Mksj
dysD'ku½
gyokbZ] pkV idkSMh] QkLV
QwM] vkbLØhe] xUus dk jl
,oa vU; twl] lCth ,oa QwV
vkfn Bsyk O;olkf;;ksa ij

15

iwoZ esa çdkf'kr
lg;ksx jkf'k
¼miHkksDrk }kjk½
çfrekg uxj
iapk;r ykoM+
{ks=@çfrekg
3
#0 50@&
#0 100@&

miHkksDrk dh Js.kh

4
fjgk;'kh edku ¼Mksj Vw Mksj
dysD'ku½
gyokbZ] pkV idkSMh] QkLV
QwM] vkbLØhe] xUus dk jl
,oa vU; twl] lCth ,oa QwV
vkfn Bsyk O;olkf;;ksa ij

orZeku esa çdkf'kr
lg;ksx jkf'k
¼miHkksDrk }kjk½
çfrekg uxj
iapk;r ykoM+
{ks=@çfrekg
5
#0 20@&
#0 20@&

vkQrkc csxe]
v/;{k]
uxj iapk;r ykoM+]
tuin esjBA
265 V

<!-- page 78 -->

2112

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 8

30 tqykbZ] 2025 bZ0
la0 255@u0ia0yk0@esjB@,Q,lVhih@mifof/k@2025-26&la;qDr izkUr uxj ikfydk vf/kfu;e] 1916
¼la0iz0 ,sDV la[;k 2] 1916½ dh /kkjk 298¼2½ ds v/khu izkIr vf/kdkjksa dk iz;ksx djds uxj iapk;r ykoM+ dh
lhek gsrq lfefr cSBd fnukad 21 uoEcj] 2025 ds ladYi la[;k-08 ds vUrxZr viuh lhek ds vUrxZr iznRr
vf/kdkjksa dk iz;ksx djrs gq, vkWulkbV LoPNrk O;oLFkk ds vif'k"V ¼Qhdy Lyt]lsIVst vkSj vif'k"V ty½ ds
Mh-Lyftax] ifjogu ,oa VªhVesaV rRlacU/kh vkSj izklafxd vFkok vuqlafxd ekeyksa ds fy;s mifof/k cuk;h gS]
ftlls mDr ,sDV dh /kkjk 301 ¼1½ ds vUrxZr vkifÙk;¡k ,oa lq>ko gsrq fnukad 30 tqykbZ] 2025 ls fnukad
29 vxLr] 2025 rd ds fy;s bl dk;kZy; ds i=-la[;k 255@u0ia0yk0@esjB@,Q,lVhih@mifof/k@2025-26
fnukad 30 tqykbZ] 2025 ds }kjk jk"Vªh; lekpkj-i= nSfud HkkLdj esa izdkf'kr fd;k x;k FkkA mDr vof/k esa dksbZ
vkifRr;ka bl dk;kZy; esa izkIr ugh gqbZ gSA

mÙkj çns'k uxj ikfydk vf/kfu;e] 1916 }kjk çnÙk 'kfDr;ksa dk ç;ksx djrs gq,] uxj iapk;r] ykoM+
}kjk ?kj@Hkou@çfr"Bku esa v‚ulkbV lsfuVs'ku flLVe ¼lsfIVd VSad@fiV@lks[rk½ ds laxzg.k] <qykbZ vkSj
mlls tqM+s ekeyksa ds fy;s fuEufyf[kr mifof/k;ka cukbZ x;h gSaA
& ;s mifof/k fuEufyf[kr çko/kkuksa dks ykxw djus okyk l{ke <kapk gS&
¼d½& mÙkj çns'k jkT; lsIVst çca/ku uhfr] 2019
¼[k½& Qhdy Lyt ,oa lsIVst çca/ku dh jk"Vªh; uhfr] 2017
¼x½& lhih,pbZbZvks eSuqvy v‚u lhojst vkSj Qhdy Lyt ,oa lsIVst çca/ku 2013
¼?k½& e‚My fuekZ.k mifof/k] 2016 rFkk vU; ykxw Hkou mifof/k
¼³½& çksfgfc'ku v‚Q ,EIy‚;esaV ,st eSuqvy LdSoastlZ ,aM ns;j fjgSfcfyVs'ku ,sDV-2013 vkbZ,l dksM
2470 Hkkx-I vkSj II] 1985 ¼1996 jhvQlZ~V½-lsfIVd VSad laLFkkfir djus ds fy;s dk;Z O;ogkj lafgrk
¼p½& dsaæh; dkuwu] fu;e vkSj fofu;eu i;kZoj.k ¼laj{k.k½ vf/kfu;e] 1986
¼N½& ty ¼çnw"k.k ij jksd vkSj fu;a=.k½ vf/kfu;e] 1974
¼t½& mÙkj çns'k ds jktdh; dkuwu tSls ty vkSj LoPNrk lEcU/kh] tSls fd ;w0ih0 ty vkiwfrZ ,oa
lhojst vf/kfu;e] 1975] mÙkj çns'k ty laLFkku tykiwfrZ ,oa lhojst mifof/k] 2008 rFkk vU; dksbZ çklafxd
jktdh; dkuwuA
;s mifof/k uxj iapk;r ykoM+ ¼ftls Hkfo"; esa uxj iapk;r ykoM+ ds uke ls tkuk
tk;sxk½ dh ç'kklfud lhek ds Hkhrj Qhdy Lyt ,oa lsIVst çca/ku esa layXu lHkh fgr/kkjdksa ij ykxw gksrs gSa]
ftles lsfIVd VSad okys ?kjksa ds ekfyd ,oa mi;ksxdrkZ] lsfIVd VSad lQkbZ v‚ijsVj rFkk fudk; ds mipkj vkSj
fuLrkj.k esa layXu tokc nsg ,tsafl;ka 'kkfey gSaA ;g mifof/k lHkh lkoZtfud] futh] vkoklh;] okf.kfT;d]
laLFkkxr] çLrkfor] fu;ksftr ;k fudk; uxj iapk;r ykoM+ Hkouksa ij ykxw gksxkA
¼d½& bu mifof/k;ksa dks uxj iapk;r] ykoM+ Qhdy Lyt ,oa lsIVst çca/ku ¼FSSM½ mifof/k]
2025 dgk tk ldrk gSA

<!-- page 79 -->

Hkkx 8 ]

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

2113

¼[k½& ;s xtV esa çdkf'kr gksus dh rkjh[k ls fØ;kfUor gksaxs vkSj fudk; dh ç'kkldh; ijhlhek ds
vanj ykxw gksaxhA
¼1½&
dk vFkZ gS fujh{k.k] lQkbZ rFkk vU; j[kj[kko dk;Z gsrq lsfIVd VSad@fiV esa
vanj tkus ds fy;s Nsn ;k jkLrk ftldks <Ddu ;k vkoj.k ls can fd;k gksA
¼2½&
fudk;] 'kgjh LoPNrk lfefr] vkSj ;k] dksbZ vU; lacaf/kr çklafxd vf/k—r
lfefr ds lnL;ksa ls fey dj cuk ,d lewg gS ftldk mn~ns'; mifof/k;ksa ls lacaf/kr fdlh Hkh fookn] vihy ;k
eqn~ns dk lacks/ku djuk gSA
¼3½&
ml çfØ;k dks dgrs gSa ftlesa lhost mipkj
lqfo/kk ¼,lVhih½ esa] 'kgjksa ds lhoj ds tfj, ls ys tkus okys ?kjsyw lhost ds mipkj ds vykok] fofHkUu v‚ulkbV LoPNrk ç.kkfy;ksa ds Qhdy Lyt vkSj lsIVst ¼,Q,l,l½ dk Hkh mipkj fd;k tkrk gSA
¼4½&
mipkj ds fy;s i;kZIr çko/kku miyC/k gksA

dk rkRi;Z gS ,slk lhost VªhVesaV IykaV ftlesa fQdy Lyt ds

¼5½&
DWWT
dk rkRi;Z gS ,slh i)fr ls gS
ftlesa futh vkoklksa] vkoklh; ladqyksa] ,dy leqnk;ksa] m|ksxksa] laLFkkuksa ;k mRiknu LFky ds fudV vif'k"V ty
dk laxzg.k] mipkj fd;k tkrk gS vkSj fuLrkj.k@nqckjk bLrseky ;ksX; cuk;k tkrk gSA ;s ç.kkyh vif'k"V ty
ds rjy vkSj Bksl nksuksa ?kVdksa ds fy;s ç;qDr gksrs gSaA
¼6½&
fudk; dk ,slk vf/kdkjh ftls vf/k'kklh vf/kdkjh }kjk ykblsal tkjh
djus ds fy;s vFkok mls lkSais x;s fdlh vU; dk;Z djus ds fy;s vf/k—r fd;k x;k gksA
¼7½&
dk rkRi;Z gS ykblsal/kkjh v‚ijsVj vFkok fudk; ds çf'kf{kr lQkbZ deZpkfj;ksa
}kjk lsfIVd VSad@fiV ls Qhdy Lyt ,oa lsIVst fudkyus dh çfØ;kA
¼8½&

dk rkRi;Z gS Qhdy Lyt ,oa lsIVst dk vf/klwfpr LFkku rd ifjogu ,oa

¼9½&

dk rkRi;Z gS lsfIVd VSad ls fudyus okyk vf/kIykoh ¼æo½A

fuoZguA
¼10½&
esa teh gqbZ ;k uhps cSBh gqbZ lkexzhA

dk rkRi;Z gS lsfIVd VSad vFkok v‚ulkbV lsfuVs'ku ç.kkfy;ksa

¼11½&
FSTP
dk rkRi;Z gS lqjf{kr fuLrkj.k vkSj nqckjk
bLrseky ds fu/kkZfjr ekun.M ds vuqlkj Bksl vkSj rjy ?kVdksa dks gVkus oyk Lora= Qhdy Lyt ,oa lsIVst
mipkj la;a=A
¼12½&
dk rkRi;Z gS ?kjsyw vif'k"V ty ls gS ftlesa ekuo ey ugha gksrkA ;g ?kj dh
lQkbZ ls fudyk ikuh] jlksbZ vkSj Luku?kj dk ikuh gks ldrk gSA
¼13½&
dk rkRi;Z gS og fudk; tks mipkj la;a= ds lapkyu vkSj j[k-j[kko ds
fy;s ftEesnkj gksrk gS vkSj tks la;a= esa fudVorhZ fudk; ds Qhdy Lyt ,oa lsIVst dks mipkj dh vuqefr nsrk
gSA viuh vf/kdre {kerk dks gkfly djus rd gksLV fudk; ^gksLV^ cuk jgsxkA
¼14½&
dk rkRi;Z mu 'kkSpky;ksa ls gS tgka jk[k dh feêh ¼ey-dhpM+½ dks
fdlh ekuo ;k tkuojksa }kjk <ks;k ;k gVk;k tkrk gS] rFkk ey dhpM+ dks [kqyh ukfy;ksa ;k xïksa esa Mky fn;k
tkrk gSA

<!-- page 80 -->

2114

mŸkj izns'k xtV] 24 vDVwcj] 2026 bZ0 ¼dkfrZd 02] 1948 'kd laor~½

[ Hkkx 8

¼15½&
dk vFkZ gS fdlh O;fDr dks nh xbZ fyf[kr vuqefr gS] ftldh ea'kk Qhdy
Lyt ,oa lsIVst çca/ku lsokvksa dks iwjk djuk gksrh gS] ftlesa mís';] le; vof/k] uke] irk vkSj ekxZ vkfn dk
mYys[k fudk; ds vf/k—r gLrk{kjdrkZ ds gLrk{kj ds varxZr fd;k tkrk gSA
¼16½&
¼ykblsal/kkjh½ dk vFkZ gS ,slk O;fDr ftls Qhdy Lyt ,oa
lsIVst çca/ku lsok;sa çnku djus gsrq fudk; }kjk iath—r fd;k x;k gksA
¼17½&
dk vFkZ gksrk gS fudk; }kjk ifjHkkf"kr vkSj fu/kkZfjr Qhdy Lyt ,oa
lsIVst dh vkiwfrZ vkSj fuLrkj.k dk LFkkuA
¼18½&
,slh LoPNrk ç.kkyh gS tks iwjh rjg ls
futh@ O;kolkf;d@ljdkjh vkokl vkSj mlds vkl-ikl ds Hkw-[kaM ij fLFkr gksrk gSA
¼19½&
dk rkRi;Z ,sls O;fDr ls gS tks Qhdy Lyt ,oa lsIVst fudkyus vkSj mlds
ifjogu ds O;olk; esa layXu gS]
¼20½&
fdlh fgLls dk ekfyd gks]

dk vFkZ gS og O;fDr tks fudk; dh lhek ds Hkhrj fLFkr fdlh Hkou ;k mlds

¼21½&
dk rkRi;Z ,d ,ls O;fDr ls gS ,d ,tsalh] ,d VªLV] ,d lekt] ,d QeZ ;k
,d daiuh dks lanfHkZr djrk gS çklafxd dkuwuksa ds rgr fuxfer daiuh] O;fDr;ksa dk ,d la?k ;k O;fDr dk ,d
fudk; pkgs fuxfer gks ;k ugha]
¼22½&
dk vFkZ gksxk lsfIVd VSad vFkok dksbZ vks,l,l vFkok Hkwfexr lhojst
ç.kkyh ls tqM+s 'kkSpky; vkSj ew=ky; ds çdkj vkSj cukoV tks ey ¼vifpr eyew=½ ds lqjf{kr ifjjks/ku vkSj
fuLrkj.k dks lqfuf'pr djrk gks] ftuesa ls çR;sd dk fuekZ.k fudk; }kjk tkjh fd;s x;s fMtkbu fofunsZ'k vkSj
fn'kkfunsZ'k ds vuq:i fu;ekuqlkj fd;k x;k gks]
¼23½&
Hkwfexr fufeZr VSad gS tks vkaf'kd :i ls Bksl teko vkSj vok;oh; ikpu
ds la;kstu }kjk vkaf'kd :i ls Qhdy Lyt ,oa lsIVst dk mipkj djrk gS] ftldk fuekZ.k vkbZ,l dksM 2470
ds fMtkbu fofunsZ'k ;k fudk; }kjk tkjh fn'kkfunsZ'kksa ds vuqlkj fd;k x;k gSA
¼24½&
dk vFkZ gS dsaæh; yksd LokLF; ,oa i;kZoj.k bathfu;fjax laxBu
¼lhih,pbZbZvks½ dh vuq'kalkvksa ds vk/kkj ij 2-3 o"kksaZ ds varjky ij vks,l,l dks fu;fer :i ls [kkyh djkus dh
çfØ;kA
¼25½&
Lyt ,oa lsIVstA

dk vFkZ gS vPNh rjg fMtk;u fd;s gq;s lsfIVd VSad ls fudyus okyk Qhdy

¼26½&
dk vFkZ gS CySd vkSj xzs ikuh dk feJ.k gS ftls lhojksa ds ek/;e ls çokfgr fd;k
tkrk gSA bls osLV o‚Vj@;wTM o‚Vj Hkh dgk tkrk gSA
¼27½&
dks cgk;k tkrk gSA

oks ç.kkyh ¼lhoj ykbu@ikbi ykbu½ ftlds ek/;e ls leqnk; ds vif'k"V ty

¼28½&
dk vFkZ gksrk gS 'kgj esa lhoj usVodZ ds iai-gkml dk HkaMkj.k
vkSj laxzg d{k] tgk¡ ls lhost ;kuh ey ty ;k viokg dks fufnZ"V LFkku ij iai djds Hkstk tkrk gSA
¼29½&
dk vFkZ ml LFkku ls gS tgka lqjf{kr fuLrkj.k vkSj nqckjk mi;ksx
ds fy;s fu/kkZfjr ekudksa ds vuqlkj ey ty dk mipkj fd;k tkrk gSA
