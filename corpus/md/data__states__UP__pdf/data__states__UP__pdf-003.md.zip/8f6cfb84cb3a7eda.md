---
doc_id: "8f6cfb84cb3a7eda"
source_url: "https://information.up.gov.in/admin/UploadDocument/CmPress/compressed_16052025025449AccreditionRules.pdf"
ministry: "Information & Public Relations Department, Uttar Pradesh"
title: "Listing Rules"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8d35814e41fe2e61"
---

<!-- page 1 -->

la[;k&2130@19&1&2003&89@2001
izs’kd]

lsok esa]

djuSy flag
izeq[k lfpo
mRrj izns”k “kkluA
funs”kd
lwpuk ,oa tu lEidZ foHkkx
mRrj izns”k] y[kuÅA

lwpuk vuqHkkx&1

y[kuÅ %% fnukad 18 fnlacj] 2003

fo’k;%&foKkiu ekU;rk ,oa forj.k izfØ;k ,oa ekxZn”kZd fl)kUrA
egksn;]

“kklukns”k la[;k&1223@mUuhl&1&2001&89@2001] fnukad 19 flrEcj] 2001 }kjk
foKkiu ekU;rk ,oe~ forj.k laca/kh izfØ;k fopkjksijkUr~ iwoZ esa fuxZr mDr ,oa leLr vU; vkns”kksa
dk vfrØe.k djrs gq;s Jh jkT;iky egksn; foKkiu ekU;rk o forj.k gsrq fuEufyf[kr izfØ;k o
ekxZn”kZd fl)kUr fu/kkZfjr fd;s tkus dh lg’kZ Lohd`fr iznku djrs gSa%&
foKkiu forj.k izfØ;k
1-1 lekpkj i=@ if=dkvksa dh Js.kh esa] foKkiu ek= foHkkx esa lwphc) izdk”kuksa dks miyC/k
djk;s tk;saxsA fdlh fo”ks’k uhfr dk O;kid izpkj&izlkj djus dh n`f’V ls fn[kkoVh ¼fMLiys½
foKkiu fuXkZr djus dk vf/kdkj lwpuk funs”kd dk gksxkA
1-2 lekpkj i=@ if=dkvksa dks vf/kdkj Lo:Ik dksbZ Hkh foKkiu vuqeU; ugha gksxk vkSj bl
laca/k esa lwpuk funs”kd dk fu.kZ; vafre gksxkA
1-3 foKkiu laca/kh fdlh fookn ds fy;s okn {ks= y[kuÅ gksxkA
1-4 ,sls lekpkj i=@ if=dkvksa dk] ftudk izfr laLdj.k l”kqYd izlkj 3000 izfr;ksa ls de
u gks] mUgsa foKkiu miyC/k djk;s tk ldsaxs] fdUrq&
fuEufyf[kr Js.kh ds i=@ if=dkvksa dks fuEuor NwV nh tk ldsxh%&
¼d½ mnwZ] laLd`r ,oa {ks=h; Hkk’kkvksa esa izdkf”kr gksus okys lekpkj&i=@ if=dkvksa ds fy, izfr
laLdj.k l”kqYd izlkj la[;k 3000 ds LFkku ij 2000 gksxhA
¼[k½ vaxzsth lekpkj i=@ if=dkvksa dks Hkh fgUnh lekpkj i=ksa dh HkkWafr foKkiu tkjh fd;k
tk;sxkA
¼x½ funs”kd dks fdlh lekpkj i=@ if=dk ds izos”kkad ds fy, bl “krZ esa f”kfFkyrk iznku
djus dk vf/kdkj gksxkA
2iqLrdksa@ Lekfjdkvksa@ lekpkj i=ksa o if=dkvksa ls fHkUu Js.kh ds vU; izdk”kuksa esa
foKkiu izdk”kuksa dh mi;ksfxrk o xq.koRrk ds vk/kkj ij funs”kd dh Lohd`fr ls fuxZr fd;s
tk;saxsA blds lkFk esa ;g Hkh “krZ gksxh fd ,sls izdk”ku esa dqy izdkf”kr dh tkuh okyh izfr;ksa
dh la[;k 1000 ls de u gksA

<!-- page 2 -->

3lekpkj&i=@ if=dk ds foKkiu ds vkosnu i= esa iathdj.k dh la[;k vafdr
djrs gq;s mlds lkFk vkj0,u0vkbZ0 }kjk tkjh fd;s x;s iathdj.k izek.k&i= dh
Loizekf.kr lgh izfr layXu djuh gksxhA
4lekpkj i=@ if=dkvksa dh l'kqYd izlkj la[;k ds lac/ak esa pkVZMZ ,dkmUVs.V ds
izek.k i= ij vf/kdre ,d o"kZ dh le;kof/k ds vUnj ijUrq blds i'pkr~ ek=
vkj0,u0vkbZ0 }kjk izekf.kr izlkj la[;k@ Mh0,0oh0ih0 }kjk tkjh izek.k i= ds lkFk
vkosnu i= izLrqr djuk vfuok;Z gksxkA
5vuSfrd ,oa lekt fojks/kh vijk/kksa ¼ekjy VihZV~;wM½ ds fy;s U;k;ky; }kjk nf.Mr
O;fDRk;ksa }kjk izdkf'kr@eqfnzr ,oa lEikfnr lekpkj&i=ksa dks foKkiu iznku ugha fd;s
tk;saxsA
6foKkiu fuxZr fd;s tkus gsrq lacaf/kr lekpkj&i=ksa dk U;wure eqfnzr vkdkj fuEu
izdkj ls gksxk%&
Øekad
fu;rdkfydrk
eqfnzr vkdkj
4 i`"B
1½
nSfud i= 33 ls0eh0 X 45 ls0eh0 7 dkye
4 i`"B
2½
lka/; nS0 25 ls0eh0 X 38ls0eh0 5 dkye
6 i`"B
3½
lk0l0i= 25 ls0eh0 X 38 ls0eh0 5 dkye
8 i`"B
4½
ik0l0i= 25 ls0eh0 X 38 ls0eh0 5 dkye
32 i`"B
5½
if=dk ¼eSxthu ½ 15 ls0eh0 X 23 ls0eh0
¼lekpkj i= ds dkye ls0eh0 ls vk'k; U;wure eqfnzr vkdkj 5 ls0eh0 pkSM+kbZ ekud ls
gSA ½
7foKkiu forj.k ds mn~ns'; ls lekpkj i=ksa dks fuEu Jsf.k;ksa esa oxhZd`r fd;k
tk;sxk%&
y?kq lekpkj i=& ,sls lekpkj i= ftuds izR;sd laLdj.k dh izlkj la[;k 25]000 ;k
mlls de gSA
e/;e lekpkj i=& ,sls lekpkj i= ftuds izR;sd laLdj.k dh izlkj la[;k 25]001 ls
75]000 ds chp gSA
cM+s lekpkj i=& ,sls lekpkj i= ftuds izR;sd laLdj.k dh izlkj la[;k 75]000 ls
vf/kd gSA
8lkekU;r% lekpkj i=@ if=dkvksa dks foHkkx }kjk gh foKkiu fn;s tk;saxs ijUrq
fo'ks"k ifjfLFkfr;ksa esa foHkkx }kjk iathd`r ,tsafl;kas ds ek/;e ls foKkiu fn;s tkus dk
vf/kdkj lwpuk funs'kd esa lqjf{kr jgsxkA
9oxhZd`r foKkiu 5000 ls vf/kd la'kqYd izlkj la[;k okys mUgha nSfud lekpkj i=ksa
dks fn;s tk;saxs ftUgsa mudh l'kqYd izlkj la[;k rFkk izdk'ku dh fu;ferrk dh iqf"V
ftyk lwpuk dk;kZy;@ funs'kky; dh fujh{kk 'kk[kk ls izkIr djds funs'kky; }kjk lwphc)
fd;k tk;sxkA ,slk djrs le; y?kq ,oa e/;e lekpkj i=ksa dks foKkiu iznku djus esa
fo'ks"k egRo iznku fd;k tk;sxkA ftu tuinksa eas 5000 ls vf/kd l'kqYd izlkj la[;k okys

<!-- page 3 -->

nSfud lekpkj i= izdkf'kr ugha gksrs gSa] muesa 5000 ls vf/kd l'kqYd okys mijksDr izdkj
ls lwphc) lkIrkfgd i=ksa dks Hkh oxhZd`r foKkiu fn;s tk ldrs gSaA
10- lkekU; n'kk esa oxhZd`r foKkiu vf/kdre rhu lekpkj i=ksa esa fn;s tk;saxs fdUrq
foKkiu ds egRo o izpkj dh vkok';drk dks ns[krs gq;s funs'kd }kjk mUgsa vko';drkuqlkj
rhu ls vf/kd lekpkj i=ksa dks Hkh fuxZr fd;k tk ldsxkA
11- Vs.Mj dh eki fu/kkZfjr djus ds fy;s fuEufyf[kr izfØ;k viuk;h tk;sxh %&
d½ vkQlsV ls fudkys tk jgs lekpkj i=ksa dks fgUnh esa 10 o vaxzsth esa 8 IokbaV dk
vk/kkj ekuk tk;sxk vkSj Vs.Mj esa 'kCnksa dh la[;k fxudj mldk 0-10 ls xq.kk djds eki
fudkyh tk;sxhA
[k½ ysVj izsl ij Nis gq, lekpkj i=ksa dks fgUnh o vaxzsth esa 12 IokbaV dk vk/kkj ekuk
tk;sxk vkSj eki ds vkx.ku ds fy, 'kCnksa dh la[;k dks 0-16 ls xq.kk fd;k tk;sxkA
x½ mnwZ ds lekpkj&i=ksa esa tks fdrkcr ls Nirs gSa] mUgsa Vs.Mj nsus ds fy, 'kCnksa dks
la[;k dh 0-22 ls xq.kk fd;k tk;sxk rFkk dEI;wVj dEiksftax ls Nis i=ksa ds fy, ^^d** ,oa
^^[k** dks gh ekud ekuk tk;sxkA
12- lkekU; n'kk esa foKkiu vf/kdre ,d i`"B dk gh fn;k tk;sxk]
foKkiu dh vko';drk ij mPpkns'k izkIr djuk gksxkA

blls vf/kd

13- ¼d½ foHkkx }kjk tkjh fd;s x;s ewy dk;kZns'k ¼R.O.½ ds vk/kkj ij gh Hkqxrku fd;k
tk;sxk vU;Fkk ughaA
¼[k½ ewy dk;kZns'k [kks tkus dh fLFkfr esa :0 100-00 'kqYd foHkkxh; [ktkus esa tek
djus ds mijkUr gh dk;kZns'k dh nwljh izfr tkjh dh tk;sxhA
foKkiu njksa dk fu/kkZj.k%&
14- ftu lekpkj i=ksa dh foKkiu nj] foKkiu ,oa n`'; izpkj funs'kky; }kjk fu/kkZfjr
gS] mUgsa foHkkx }kjk ogh nj nh tk;sxhA ftu lekpkj i=ksa@ if=dkvksa dh Mh0,0oh0ih0
nj fu/kkZjr ugha gS mUgsa foHkkxh; nj nh tk;sxhA U;wure nj l'kqYd izlkj la[;k ds vk/kkj
ij ns; gksxhA
15- pkVZMZ ,dkmUVs.V ds izek.k i= dh ekU;rk ds lac/ak esa mijksDRk izLrj&4 esa n'kkZ;h
x;h 'krsZa ykxw gksaxhA
16- lekpkj i=@ if=dkvksa esa ftl foHkkx dk foKkiu izdkf'kr gksxk ml foHkkx dks
lekpkj i= dh 5 izfr Hkstuk vfuok;Z gksxkA foHkkx dks Hksts x;s i= dh jlhn chtd ds
lkFk izLrqr djus ij gh Hkqxrku fd;k tk;sxkA
17- Hkqxrku rHkh fd;k tk;sxk tc fuEu ckrksa dh iqf"V dh tk;sxh %&
¼d½ Nih gqbZ foKkiu lkexzh iBuh; lqO;ofLFkr rFkk nkx /kCcksa jfgr gksxh ,oa mlesa
dkV&ihV ugha gksxhA

<!-- page 4 -->

¼[k½ lekpkj i=@ if=dkvksa ds eq[; i`"B ij i= dk uke] o"kZ] vad] dqy eqfnzr i`"B]
ewY;] LFkku] fnu o fnuakd rFkk izR;sd i`"B ij lepkj i=@ if=dk dk uke] i`"B la[;k o
fnukad eqfnzr gksuh pkfg,A
¼x½ lekpkj i=@ if=dkvksa dh fizUV ykbu esa eqnzd] izdk'kd LoRokf/kdkjh ,oa LFkkuh;
irk vkfn dk Li"V mYys[k gksuk pkfg,A lEiknd dk mYys[k vyx ls gksuk pkfg,] tks
izdkf'kr lkexzh ds p;u ds fy, ih0vkj0ch0 ,DV ds v/khu ftEesnkj gksaxsA
¼?k½ foKkiu ftl vad@ fo'ks"kkad ds fy, fuxZr fd;k x;k gS] mlh esa izdkf'kr fd;k
x;k gksA
18- fu;ekoyh ykxw gksus ds mijkUr ,slh vof/k tks lwpuk funs'kd }kjk fu/kkZfjr dh
tk;s] esa iwoZ ds yfEcr chtdksa tks rhu ekg ls vf/kd ds gksa] dh izLrqfr funs'kky; esa djuh
vfuok;Z gksxhA
¼[k½ foKkiu izdkf'kr gksus dh frfFk ls foyEcre 3 ekg ds vUnj Hkqxrku gsrq chtd esa
izLrqr djuk vfuok;Z gksxkA 3 ekg ls iqjkus rFkk foxr foRrh; o"kZ ds chtdksa ij Hkqxrku
ugha gksxkA
¼x½ Hkqxrku foHkkxh; ctV esa /ku dh miyC/krk ds vk/kkj ij izFke vkxr ds
vuqØekuqlkj fd;k tk;sxkA
foKkiu ds fy, izdk'kuksa dh CySdfyfLVax%&
19- foHkkx }kjk lwphc) izdk'kdksa dks fuEu dkj.kksa ds vk/kkj ij fdlh Hkh
lekpkj&i=@if=dk dks foHkkx }kjk Hkfo"; esa foKkiu u nsus gsrq CySd fyLV fd;k tk
ldsxkA
¼d½ lekpkj i=@ if=dk dh izlkj la[;k dh tkap foHkkx }kjk xyr izekf.kr gksus ijA
¼[k½ lekpkj i=@ if=dk ds eqnzd@ izdk'kd@ lEiknd ds vuSfrd ,oa lekt fojks/kh
vijk/k ¼ekjy VihZV~;wM½ dk nks"kh fl) gksus ijA
¼x½ lekpkj i=@ if=dk ds eqnzd@ izdk'kd@ lEiknd ds vuSfrd ns'knzksgh
vkradoknh ,oa lekt fojks/kh vijk/k ¼ekjy VihZV~;wM½ dk nks"kh fl) gksus ijA
¼p½ lekpkj i=@if=dk ds laca/k esa ;g izekf.kr gksus ij fd mlus xyr rF; izLrqr
djds foKkiu izkIr fd;k gSA
¼N½ lekpkj i=@ if=dk dk izdk'ku vfu;fer gksus ij ¼fu;ferrk 80 izfr'kr ls de
ugha gksuh pkfg,½A
¼t½ tks lekpkj i=@ if=dk@ ,tsfUl;ka foHkkx }kjk tkjh foKkiuksa dks izdkf'kr djus
ls euk djsaxs] mUgsa funs'kd dh vuqefr ls N% ekg ds fy, fuyfECkr fd;k tk ldsxkA
20- mijksDr izLrj esa of.kZr dkj.k laKku esa vkus ij funs'kd }kjk tkap djk;h tk;sxh
rFkk tkap esa rF;ksa dh iqf"V gksus ij lacaf/kr izdk'ku ds izdk'kd@eqnzd vFkok lEiknd dks
uksfVl nsrs gq;s mudk Li"Vhdj.k izkIr djds ml ij fopkj djrs gq;s CySd fyfLVax ds
vkns'k ikfjr fd;s tk;saxsA ;fn izdk'kd }kjk CySd fyfLVax ds fo:) lquokbZ dh ekax
djrk gS rks mls foKkiu ekU;rk lykgdkj lfefr ds le{k lquokbZ dk volj fn;k
tk;sxkA CySd fyfLVax ds i'pkr~ lacaf/kr izdk'ku es afoKkiu rc rd ugha fn;k tk;sxk

<!-- page 5 -->

tc rd fdlh iqufoZpkj ds QyLo:Ik ,sls izdk'ku dks CySd fyLV ls fudky u fy;k
tk;A
lwphc) ds fy, ekin.M
lekpkj i=@ if=dkvksa dh Js.kh esa foHkkx esa lwphc) izdk'kuksa dks gh foKkiu
miyC/k djk;s tk;saxsA i=@ if=dkvksa dks 6 ekg ds fu;fer izdk'ku ds i'pkr~ gh
foKkiu gsrq lwphc) fd;k tk;sxkA lwphc) fd;s tkus gsrq fu/kkZfjr izk:i ij vkosnu
djuk gksxk] ftlds lkFk vkj0,u0vkbZ0 iath;u izek.k&i= ;Fkk izLrj&4 esa bafxr
O;oLFkkuqlkj izlkj la[;k dk izek.k&i= layXu fd;k tkuk vfuok;Z gksxkA foKkiu gsrq
lwphc) i= fuEu rhu Js.kh esa lwphc) fd, tk;saxs %&
1& jkT; Lrjh; lekpkj i=
2& e.My Lrjh; lekpkj i=
3& ftyk Lrjh; lekpkj i=
jkT; Lrjh; i=ksa gsrq ekin.M%&
1i= dk izdk'ku de ls de 16 i`"Bksa eas fd;k tk; rFkk izdk'ku jkT; eq[;ky; ls
fd;k tkuk vfuok;Z gksxkA
2i=ksa dh izlkj la[;k izns'k ds lHkh egRoiw.kZ tuinksa esa gks rFkk i= Mh0,0oh0ih0 ls
ekU;rk izkIr gksA
3i= yxHkx lHkh egRoiw.kZ tuinksa ds lekpkj dojst djrs gksaA ;fn i= dk vU;
dksbZ laLdj.k izdkf'kr gksrk gks rks mls lwphc) ugha fd;k tk;sxkA
e.My Lrjh; i=ksa gsrq ekin.M%&
1e.My Lrjh; i=ksa dh izlkj la[;k de ls de 50]000 gks rFkk i= Mh0,0oh0ih0 ls
ekU;rk izkIr gksaA i= dk izdk'ku e.My eq[;ky; ls gksuk vfuok;Z gSA
2e.My Lrjh; i= dh e.My ds v/khu lHkh tuinksa esa de ls de 5]000 izfr;ka
izlkfjr gksrh gks] ftldh iqf"V ftyk lwpuk dk;kZy; ls djkbZ tk;sxhA
3e.My Lrjh; i=ksa esa e.My ls vkPNkfnr tuinksa ds lekpkjksa dk dojst gksuk
pkfg, rFkk i= dk izdk'ku de ls de 8 ls 10 i`"Bksa rd vfuok;Z :i ls fd;k tk;A
tuinh; i=ksa gsrq ekin.M%&
1½
jkT; Lrjh; o e.My Lrjh; ds ekin.M u iwjs djus okys lekpkj i= ftyk Lrjh;
ekus tk;saxsA i=ksa dks lwphc) djus ds iwoZ i= dh Lojuhfr Lrj rFkk Hkk"kk'kSyh vkfn dh
tkap lacaf/kr ftyk lwpuk dk;kZy; ds vfrfjDRk fujh{kk 'kk[kk ls Hkh djk;h tk;sxhA
2½
igyh ckj i=@if=dkvksa dks lwphc) djus dh frfFk ls 31 fnlacj rd ds fy,
lwphc) fd;k tk;sxkA mlds i'pkr~ uohuhdj.k dk vkosnu i= izkIr gksus ij xq.k&nks"k
ds vk/kkj ij rhu o"kZ ds fy, lwphc) fd;k tk;sxkA
uohuhdj.k gsrq vkosnu i= o"kZ ds 30 uoEcj rd vfuok;Z :i ls izkIr gks tkuk
pkfg,A blds ckn izkIr vkosnu i=ksa ij dksbZ fopkj ugha fd;k tk;sxkA
3½
;fn dksbZ i=@ if=dk vfu;fer gks tk;sxk rks foKkiu ds fy, ik= ugha jg
tk;saxsA ,sls i=@ if=dkvksa dks iqu% 6 ekg rd fu;fer izdk'ku ds mijkUr gh fu;fer

<!-- page 6 -->

ekuk tk;sxkA i=@ if=dkvksa dks fu;fer jgus gsrq 80 izfr'kr izdk'ku fd;k tkuk
vfuok;Z gksxkA
nSfud lekpkj i=ksa ds fy, viuk izsl gksuk vfuok;Z gksxkA ftu nSfud lekpkj
i=ksa ds ikl eqnz.k e'khu ugha gksxh mUgsa lwphc) ugha fd;k tk;sxkA
4½
le;&le; ij lekpkj i=@if=dkvksa ds vfu;fer gks tkus dh lwpuk ftyk lwpuk
vf/kdkjh ds }kjk foHkkx dks miyC/k djkuk vfuok;Z gksxkA
21- 'kklu dks mijksDRk izfØ;k ,oa ekxZn'kZd fcUnqvksa dks vko';drkuqlkj f'kfFky djus
dk vf/kdkj gksxkA
mijksDRk vkns'kksa@ funsZ'kksa dk vuqikyu dM+kbZ ls lqfuf'pr djk;k tk;A
Hkonh;
¼djuSy flag½
izeq[k lfpoA
la[;k&2130@mUuhl&1&2003 rn~fnukadA
izfrfyfi fuEufyf[kr dks lwpukFkZ ,oa vko”;d dk;Zokgh gsrq iszf’kr%&
1
egkys[kkdkj mRrj izns”k] bykgkcknA
2
futh lfpo] izeq[k lfpo] lwpuk mRrj izns”k “kkluA
3
vij funs”kd] lwpuk ,oa tu lEidZ foHkkx] m0iz0 y[kuÅA
4
la;qDr funs”kd@ mi funs”kd@ lgk0 funs”kd@ foRr ,oa ys[kkf/kdkjh] lwpuk ,ao
tu lEidZ foHkkx] m0iz0] y[kuÅA
5
foKkiu izHkkx] lwpuk ,oa tu lEidZ foHkkx] mRrj izns”k] y[kuÅA
6
foRr ¼O;;&fu;a=.k½ vuqHkkx&7A
7
xkMZ i=koyh gsrqA
vkKk ls]
¼lat; HkkfV;k½
fo”ks’k lfpoA

<!-- page 7 -->

mRrj izns'k ljdkj
lwpuk ,ao tu lEidZ foHkkx
¼foKkiu izHkkx½
la[;k&602@lw0,aot0la0fo0¼foKk0½@1173@89
y[kuÅ %% fnuakd 26 ebZ] 2004
oSHkkfxd vkns'k
,rn~}kjk vkns'k la[;k&219@lw0,oa0t0la0fo0¼foKk0½&1173@89] fnukad 10 Qjojh]
2004 dks rkRdkfyd izHkko ls fujLr djrs gq;s lekpkj i=ksa dh izlkj la[;k ds vk/kkj ij
iznku dh tkus okyh foKkiu njsa fuEukuqlkj fu/kkZfjr dh tkrh gSA
nSfud lekpkj i=
Ikzfr oxZ ls0eh0 nj :i;s
nSfud vaxzsth

Ikzfr oxZ ls0eh0 nj :i;s
nSfud fgUnh Hkk"kk

2.16
2.55
3.15
3.78
4.35
4.98
5.64
6.21
6.84
7.41
8.01
11.76

2.46
2.76
3.27
3.78
4.35
4.98
5.64
6.21
6.84
7.41
8.01
11.76

Lk'kqYd izlkj la[;k

Ikzfr oxZ ls0eh0 nj :i;s
vaxzsth

Ikzfr oxZ ls0eh0 nj :i;s
fgUnh Hkk"kk

2000 rd
2001 ls 5000 rd
5001 ls 10]000 rd
10]001 ls 15]000 rd
15]001 ls 20]000 rd
20]001 ls 25]000 rd
25]001 ls 30]000 rd
30]001 ls 35]000 rd
35]001 ls 40]000 rd
40]001 ls 45]000 rd
45]001 ls 50]000 rd
50]000 ls Åij

2.61
2.97
3.54
4.17
4.71
5.34
5.91
6.48
7.08
7.69
8.22
13.29

2.97
3.27
3.76
4.17
4.71
5.34
5.91
6.48
7.08
7.69
8.22
9.78

Lk'kqYd izlkj la[;k
2000 rd
2001 ls 5000 rd
5001 ls 10]000 rd
10]001 ls 15]000 rd
15]001 ls 20]000 rd
20]001 ls 25]000 rd
25]001 ls 30]000 rd
30]001 ls 35]000 rd
35]001 ls 40]000 rd
40]001 ls 45]000 rd
45]001 ls 50]000 rd
50]000 ls Åij

lkIrkfgd@ikf{kd lekpkj i=

<!-- page 8 -->

Ekkfld] }Sekfld rFkk =Sekfld if=dkvksa dh njsa
izlkj la[;k
2000 rd
2002 ls 5000 rd
5001 ls 10]000 rd
10]001 ls 20]000 rd
20]001 ls 30]000 rd
30]001 ls 40]000 rd
40]001 ls 50]000 rd
50]001 ls 60]000 rd
60]001 ls 70]000 rd
70]001 ls 80]000 rd
80]001 ls 90]000 rd
90]001 ls 1]00]000 rd
1]00]000 ls Åij

2-

nj izfr i`"B ¼:i;s½
3000.00
3500.00
4000.00
4500.00
5000.00
5500.00
6000.00
6500.00
7000.00
7500.00
8000.00
8500.00
9000.00

;g njsa vfxze vkns'kksa rd izHkkoh jgsxhA
¼lat; HkkfV;k½
lwpuk funs'kdA

la[;k& @lw0,aot0la0fo0¼foKk0½&1173@89 rn~fnukafdrA
izfrfyfi fuEukafdr dks lwpukFkZ ,oa vko';d dk;Zokgh gsrq izsf"kr %&
1futh lfpo] lwpuk lfpoA
2la;qDr funs'kd ¼Jh jke vorkj izlkn½
3la;qDr funs'kd ¼Jherh vfHkyk"kk dqyJs"B½
4foRr ,oa ys[kkf/kdkjh@ leLr mi funs'kd] lwpuk foHkkxA
¼lat; HkkfV;k½
lwpuk funs'kdA

<!-- page 9 -->

izs"kd]

fufru jes'k xksd.kZ]
lfpo]
mRrj izns'k 'kkluA
lsok esa]
funs'kd]
lwpuk ,oa tu lEidZ foHkkx]
mRrj izns'k] y[kuÅA
lwpuk vuqHkkx&1

la[;k& 173@mUuhl&1&2007&89@2001

y[kuÅ %% fnuakd 14 Qjojh] 2007

fo"k;% foKkiu ekU;rk ,oa forj.k izfØ;k ,oa ekxZn'kZd fl)kUr esa la'kks/ku fo"k;dA
egksn;]
'kklukns'k la0&2130@mUuhl&1&03&89@2001 fnuakd 18-12-03 }kjk fuxZr foKkiu
ekU;rk ,oa forj.k izfØ;k ,oa ekxZn'kZd fl)kUr esa Jh jkT;iky egksn; fuEufyf[kr
la'kks/ku fd, tkus dh lg"kZ Lohd`fr iznku djrs gSa %&
^^,sls lekpkj i= ftudk Hkkjr ljdkj ds Mh0,0oh0ih0 }kjk nj fu/kkZfjr fd;k x;k
gks] ml le;kof/k ds fy;s lwpuk foHkkx }kjk lwphc) ekuk tk;sxkA
2mDr 'kklukns'k fnukad 18-12-2003 bl lhek rd la'kksf/kr le>k tk;sA
Hkonh;]
fufru jes'k xksd.kZ
lfpo
la[;k& 173¼1½ mUuhl&1&2007 rn~fnukadA
izfrfyfi fuEufyf[kr dks lwpukFkZ ,oa vko';d dk;Zokgh gsrq iszsf"kr%&
1& egkys[kkdkj] mRrj izns'k] bykgkcknA
2& la;qDr funs'kd@ mi funs'kd@ lgk;d funs'kd@ foRr ,oa ys[kkf/kdkjh lwpuk
,oa tu lEidZ foHkkx] mRrj izns'k] y[kuÅA
3& foKkiu izHkkx] lwpuk ,oa tu lEidZ foHkkx] mRrj izns'k] y[kuÅA
4& foRr ¼O;;&fu;a=.k½ vuqHkkx&7A
5& xkMZ i=koyhA
vkKk ls]
¼jktk jke½
vuqlfpoA

<!-- page 10 -->

mRrj izns'k ljdkj
lwpuk vuqHkkx&1
la[;k&1340@mUuhl&1&08&89@2001
y[kuÅ %% fnuakd 22 vxLr] 2008
dk;kZy;&vkns'k
,rn~}kjk funs”kd] lwpuk ,ao tulEidZ foHkkx ds i= la[;k&6144@lw0,oat0la0fo0
¼foKk0½&737@2007] fnuakd 24 tqykbZ] 2008 }kjk “kklukns”k la[;k&2130@mUuhl&1&
2003&89@2001] fnukad 18 fnlEcj] 2003 ds izLrj&6¼3½ esa vkaf”kd la”kks/ku ds izLrko ij
lE;d fopkjksijkUr~ mDr “kklukns”k esa fuEuor~ vkaf”kd la”kks/ku fd, tkus dh Jh jkT;iky
lg’kZ Lohd`fr iznku djrs gS %&
orZeku O;oLFkk
la”kks/ku
“kklukns”k la[;k&2130@mUuhl&1&2003& izLrj 6¼3½& lkIrkfgd lekpkj i= 700 LVs
89@2001] fnukad 18 fnlEcj] 2003 dk dkW0 ls0eh0@3500 oxZ ls0eh0¼25 ls0eh0 x
izLrj&6¼3½&lk0l0i= 25 ls0eh0 X 38 38 ls0eh0½ 5 dkye] 4 i`’BA
ls0eh0] 5 dkye&eqfnzr vkdkj 6 i`’B
2&

mDr “kklukns”k fnuakd 18 fnlEcj] 2003 dks bl lhek rd la”kksf/kr le>k tk;A
fot; “kadj ik.Ms;
izeq[k lfpo

la[;k&1340¼1½@mUuhl&1&08&89@2001] rn~fnuakdA
izfrfyfi fuEufyf[kr dks lwpukFkZ ,oa vko”;d dk;Zokgh gsrq izsf’kr%&
1
egkys[kkdkj] m0iz0] bykgkcknA
2
futh lfpo] izeq[k lfpo] lwpuk] m0iz0 “kkluA
3
vij funs”kd] lwpuk ,oa tulEidZ foHkkx] m0iz0 y[kuÅA
4
foKkiu izHkkx] lwpuk ,oa tulEidZ foHkkx] m0iz0 y[kuÅA
5
foRr ¼O;;&fu;a=.k½ vuq0&7A
6
xkMZ i=koyhA
vkKk ls]
¼lquhy dqekj½
lfpoA
