---
doc_id: "65db76aaeefbb7b2"
source_url: "https://csjmu.ac.in/wp-content/uploads/docs/2025/01/tender-Diagnosic-kit.pdf"
ministry: "Chhatrapati Shahu Ji Maharaj University, Kanpur, Uttar Pradesh"
title: "Tender notice for supply of laboratory diagnostic kits"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "abc0ab50ccf4b6cc"
---

<!-- page 1 -->

eProcurement System Government of Uttar Pradesh
Tender Details
Date : 14-Jan-2025 12:01 PM
Print

Basic Details
Organisation Chain

Chhatrpati Shahu Ji Maharaj University Kanpur

Tender Reference Number

csjmu/purchase/89/2025 date 08/01/25

Tender ID

2025_CSJMU_991996_1

Withdrawal Allowed

Yes

Tender Type

Open Tender

Form of contract

Percentage

Tender Category

Goods

No. of Covers

2

General Technical Evaluation
Allowed

No

ItemWise Technical Evaluation Allowed

No

Payment Mode

Offline

Is Multi Currency Allowed For BOQ

No

Is Multi Currency Allowed For
Fee

No

Allow Two Stage Bidding

No

Payment Instruments

Cover Details, No. Of Covers - 2

Offline S.No

Instrument Type
DD - Demand Draft

Cover No

Cover

Document Type

Description

1

1

Fee/PreQual/Technical

.pdf

Techanical

2

FDR - Fixed Deposit

2

Finance

.xls

Financial

Tender Fee Details, [Total Fee in ₹ * - 23,600]
Tender Fee in ₹

23,600

Fee Payable To

Finance Officer

Tender Fee Exemption
Allowed

No

EMD Fee Details

Fee Payable At

Kanpur

EMD Amount in ₹

60,000

EMD Exemption Allowed

No

EMD Fee Type

fixed

EMD Percentage

NA

EMD Payable To

Finance Officer

EMD Payable At

Kanpur

Work /Item(s)
Title

rate contract for supply of laboratory diagnosic kits to csjm university, kanpur

Work Description

rate contract for supply of laboratory diagnostic kits to csjm university, kanpur

Pre Qualification Details

Please refer Tender documents.

Independent External Monitor/
Remarks

NA

Tender Value in ₹

20,00,000

Product Category

Laboratory and scientific equipment

Sub category

NA

Contract Type

Rate Contract

Bid Validity(Days)

180

Period Of Work(Days)

365

Location

csjm university, kanpur

Pincode

208024

Pre Bid Meeting Place

NA

Pre Bid Meeting Address

NA

Pre Bid Meeting Date

NA

Bid Opening Place

CSJMU

<!-- page 2 -->

eProcurement System Government of Uttar Pradesh

2 of 2

Should Allow NDA Tender

https://etender.up.nic.in/nicgep/app?component=%24DirectLink&page=FrontEndTenderDetai...

No

Allow Preferential Bidder

No

Critical Dates
Publish Date

14-Jan-2025 11:00 AM

Bid Opening Date

23-Jan-2025 11:00 AM

Document Download / Sale Start Date

14-Jan-2025 11:00 AM

Document Download / Sale End Date

22-Jan-2025 05:00 PM

Clarification Start Date

NA

Clarification End Date

NA

Bid Submission Start Date

14-Jan-2025 11:00 AM

Bid Submission End Date

22-Jan-2025 05:00 PM

Tender Documents
NIT Document

Work Item
Documents

Document Size (in
KB)
10714.48
10714.48

S.No

Document Name

Description

1
2

Tendernotice_1.pdf
Tendernotice_2.pdf

tender documents
Tender Notice

S.No

Document Type

Document Name

Description

1

BOQ

BOQ_1752791.xls

BOQ

Document Size (in
KB)
224.50

Tender Inviting Authority
Name

Registrar

Address

CSJM University Kanpur

14-01-2025, 12:01
