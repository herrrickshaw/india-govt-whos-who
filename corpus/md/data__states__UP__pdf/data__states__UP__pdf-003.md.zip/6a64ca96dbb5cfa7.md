---
doc_id: "6a64ca96dbb5cfa7"
source_url: "https://www.iitbhu.ac.in/contents/institute/admin/doc/executive_council_ecr_28feb2013.pdf"
ministry: "Indian Insttitute of Technology (BHU), Varanassi"
title: "Resolutions of the Executive Council, BHU (which was functioning as BoG at that time)"
date: ""
pages: 11
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "5003c5ae06c60aa0"
---

<!-- page 1 -->

COPY OF ECR NO.i00 DATED FEBRUARY 28, 20i3
ECR 400
ITEM 72 CONSIDERED the orders of the Vice-Chancellor, BHU in the capacity of
Chairman, Board of Governors of IIT(BHU) regarding various
administrative affairs pertaining to IIT(BHU).
The Executive Council noted that the Vice-Chancellor, Banaras Hindu
ar University, in the capacity of Chairman, BOG, IIT(BHU), has approved the
following proposals छः
जज PARTICULARS
ORDER
4. | That the Legal Cell ofthe BHU will continue to | 06.42.20i2
perform such functions for the IIT(BHU) also, till
the Legal Cell of the Institute is established
‘ 2. That though the other IiTs are following five-day 03.42.2042
week system, the IIT(BHU) to follow the hours of
attendance and holidays pattern, which are being
observed in BHU in view of the requirement of
close cooperation between the two institutions
| 3. | That the constitution of Institute Works Committee | 37.07.2043
for IIT(BHU) under the chairmanship of Prof. A.K.
Kapoor, Department of Electrical Engineering,
{IT(BHU) be approved.
हु के That some new appointments of Professor ०७४ णणाय
a ' Incharges and minor reshuffling in the areas of i
the existing ones be approved as follows: |
Prof S.K. Sharma Deptt. of Mechanical Engg. -Professor-in-charge
{Student Affairs)
Prof. A.K. Kapoor, Deptt. ‘of Electrical Engg.-Professor-in-
charge(Resource Planning & Gen.)
Prof. B.N. Dwivedi Deptt. of Applied Physics-Professor-in-charge(Faculty
& Alumni Affairs)
Prof. Rajiv Prakash S.M.S.T. - Professor-in-charge (Research &
___| Development) ——E सन
5. | That the following Current Accounts be opened | 03.47.2042
for IIT(BHU):
Non-Plan; uthorized official(s)
है Plan) uthorized official(s)

<!-- page 2 -->

3. | (PF and NPS) authorized official (s
IIT(BHU) Main Registrar or other
accounts (Special authorized official (s)
Fund
{IT(BHU)-Alumni Director/Registrar or other
5 account thorized official (s)
Project Account authorized official (s)
That the guidelines for payment of honorarium to 2.072073
retired teachers/research scholars/guest lectures
for taking classes on per lecture basis be
approved.
7. | That the constitution of Investment Committee as | 04.2.20i2
follows be approved
4. Prof. A.K. Kapoor Chairman ne
Department of Electrical Engineering, IIT (BHU)
2. Prof.H.C. Chaudhary Member
Faculty of Management Studies, BHU
(Chairman, Investment Committee, BHU)
३. Prof. G.V.S. Sastry Member
Department of Metallurgical Engineering
4. CABrajesh Jaiswal - Investment Expert
Siddhartha Complex, Sigra, Varanasi
5. Dr.S.P.Mathur Member Secretary
Actg. Registrar, IIT (BHU) है
8. | That the proposal of the Director, IIT(BHU) for} 34.0.2043
constitution of a Women Grievance Cell as
follows for IIT(BHU) be approved
4. Dr. Vijay Laxmi Yadav Chairperson
Department of Chemical Engg. & Tech.
2. Dr. Kalpana Choudhary Member
i Department of Electrical Engg. &Tech. |
s, Dr. Medha Jha Member
Department of Civil Engg., IIT(BHU)
4. Mrs. Renu Kaila Member Secretary
$.0.,IIT(BHU) Directorate :
9. | That the Director, IIT(BHU) be authorized to | 05.42.20i2 =
i ; choose one expert member as Board of |
Governors nominee to the Selection Committee |
from among the Metallurgist Fellows of Indian
National Sciences Academy, Indian Academy of व
Sciences, National Academy of Science of India
___| and Indian National Academy of Engineering. ee
40. | That the proposal of the Director, IIT(BHU) to | 07.42.20i2
constitute the Building & Works Committee for
IIT(BHU) as follows be approved:
4. Prof. Dhananjai Pandey Chairman
Director, IIT(BHU), Varanasi
2. Prof. A.K. Jain . Member
Professor & Head, Department of Civil Engg, liT
Delhi, New Delhi-0 0i6
3. Prof. Pradeep Bhargawa Member
Department of Civil Engineering, IIT Roorkee,
Roorkee-247 667
4, The Director or his nominee Member
not below the rank of Reader}

<!-- page 3 -->

ae
5. SriN. Nanjappa Member
(Ex-Senior Superintending Engineer, CCMB,
Hyderabad) Flat No.202, “Grand Residency”,
No.4-7-02/8, Lane No.2, Sai Enclave,
Habsiguda, Hyderabad-500 007
6. Prof. R. Mahanty Member
Department of Electrical Engg. IIT(BHU), Varanasi
7. Dr. S.P. Mathur Member Secretary
Actg. Registrar, IIT(BHU), Varanasi
4i. | That the Director, IIT(BHU) be permitted to | 08.42.20i2
proceed further for registration under Section
(4i). of FCRA for acceptance of foreign
contribution by the IIT(BHU) alumni and submit to
the Secretary, Government of India, Ministry of
Home Affairs, FCRA Wing/Foreigners Division,
New Delhi. तु
42. | That the proposal for submission of XIl-Plan | 23.44.2072
budget for remaining period of the current
financial year 202-3 .to the MHRD, New Delhi
for consideration be approved.
43. [वां the panel of five architectural firms | 34.07.2073
empanelled by BHU may also be consulted by the
IIT(BHU).
4. | That the creation of new heads of accounts which
did not exist in the BE 202-43 and BE 202-4
as approved by the Executive Council at its
meeting held on 04.40.202 be approved.
45. | That the minutes of the GTAC Management
Committee held on 05.0i.20i3 be approved
regarding revision of room rent with the following
modifications:
4. The rates for official purpose shall be applicabie
to both the IIT(BHU) and BHU. (Category 4)
2. Category 2 rates shall be applicable to visitors
| from Academic institutions to both the IIT(BHU) | |
| | and BHU. |
३,028०90५ 3 wiil also be applicable for both the
lIT(BHU) and BHU.
{6. | That the Minutes of Senate as also actions on! 72.0i.20/3
decisions taken in the Senate Meeting be
approved
47. | That the Stores & Purchase Manual, of liT(BHU)
be approved. Further, the Actg. Registrar be
authorized to chair the Purchase Committee until
the Institute appoints a Deputy Director. He be
also authorized as Competent Financial Authority.
48. | That the proposal of the Director , IIT(BHU) to
constitute a Purchase Committee under the
chairmanship of Prof. Rajiv Prakash, Professor
incharge(R&D), School of Material Science &
Technology, IIT(BHU) for purchase of equipment
for Centralized Instruments Facility be approved.

<!-- page 4 -->

| | 9. | That the recommendation of the Committee for | 48.02.203
assigning the work of preparing all the account
books along with balance sheet to M/s. Krishna
Anurag & Co. for the financial year 202-43 be
___| approved. _
20. | That the modified Project Guidelines to be
followed in IIT(BHU) be approved.
2{. | That the guidelines to be followed for utilizing of | 44.2.203
CPDA in the IIT(BHU) be approved as
recommended in the meeting of the Institute
Advisory Committee held on 2.2.20/3 which has
made recommendations in this behalf.
RESOLVED that the orders of the Vice-Chancellor in the oe
capacity of Chairman of BoG of IIT(BHU), as detailed above
be ratified and approved.
Dated: April 7, 2073
Copy forwarded for information-and necessary action to the Director,
ITT(BHU), BHU with the request to send the compliance report to the
undersigned as-soon'as possible to place the same before the
Executive Council in its next meeting.
i
०६०७० REGISTRAR
EXECUTIVE COUNCIL CELL

<!-- page 5 -->

COPY OF ECR NO.i08 DATED FEBRUARY 28, 2043 28, 20i3
ECR 408
ITEM 20 CONSIDERED the adoption the letters /OMs of MHRD/Ministry of Finance/
\IT Council regarding the pay of teaching and other staff in Centrally
Funded Technical Institutions (CFTIs) and mobility of faculty and non-
faculty personnel to the established Central Educational Institutes (CEls)/
Scientific Institutions.
The Executive Council Several MHRD letters / OMs governing the pay and
service conditions of teachers and non-teaching staff, applicable to
IIT(BHU) need to be adopted for IIT(BHU). Considering this, the Executive
Council resolved as under;
RESOLVED that the letters / OMs of MHRD/ Ministry of
Finance/ |lIT Council regarding the pay of teaching and
other staff in Centrally Funded Technical Institutions
(CFTIs) and mobility of faculty and non-faculty personnel to
the established Central Educational Institutes (CEls)/
Scientific Institutions be adopted for IIT(BHU) as per
Appendix 208 to 20M of Agenda .
है Dated: April , 2043
Copy forwarded for information and necessary action to the Director
IITT(BHU), BHU with the request to send the compliance report to the
undersigned as soon as possible to place the same before the
Executive Council in its next meeting.
Ot: Yee Poke
—— न a= i
y Serb necisran
ay EXECUTIVE COUNCIL CELL
I \

<!-- page 6 -->

COPY OF ECR NO.09 DATED FEBRUARY 28, 2043

ECR 09

ग्दा। 24 CONSIDERED the adoption of BHU's Contributory Health Scheme Rules-
2005, as amended from time to time for implementing in IIT(BHU).
The Executive Council noted that presently BHU's Contributory Health
Scheme Rules-2005, as amended from time to time is being used for the
faculty and non-faculty members of the IIT (BHU).
As per details available on the website of IIT-Kanpur, the employees of
\IT(K) are entitled to reimbursement of the medical expenses incurred on
themselves and their families in accordance with the Statutes 3(6) as set
out in Schedule ‘AA’. Also, there is a there is a Post-Retirement Medical
Scheme(PRMS) for retired employees of the Institute.
It was’ appraised to the Executive Council that since the IIT (BHU) is
situated in the BHU campus which has University Employees Health Care
Complex, University Students Health Care Complex and Sir Sunderlal
Hospital for extending medical services to the in-service and retired
employees, besides students, of the University, looking at the special
circumstances of the Institute, it may be appropriate to adopt BHU’s
Contributory Health Scheme Rules-2005, as amended from time to time,
mutatis-mutandis to apply to the students, employees and pensioners of
IIT (BHU). ‘
The issue was discussed by the Executive Council and it was felt that
covering the employees and staff of IIT(BHU) within the University
Employees Health Care Complex and University Students Health Care
Complex would involve a lot of issues including the procedure for medical
reimbursement, payment of medical charges and cost of medicines etc. In
view of this the Executive Council decided to resolve as under:

<!-- page 7 -->

RESOLVED THAT the adoption of BHU’s Contributory Health
Scheme Rules-2005 for implementing in IIT(BHU) be covered as
part of a larger MoU between IIT(BHU) and BHU.
Dated: April 4, 203
Copy forwarded for information and necessary action to the Director
IIT(BHU), BHU with the request to send the compliance report to the
undersigned as soon as possible to place the same before the
Executive Council in its next meeting.
ऐसे है Fi पट UL Ys
Soe (74५ k DEPUTY REGISTRAR
EXECUTIVE COUNCIL CELL

<!-- page 8 -->

COPY OF ECR NO.i0 DATED FEBRUARY 28, 2043 OF ECR NO.i0 DATED FEBRUARY 20i3
ECR 440 :
ITEM 22 CONSIDERED the arrangement during the absence of the Director of
\IT(BHU) from the headquarters.
The Executive Council noted that no Deputy Director has yet been
appointed in the IIT(BHU). The Dean (Academic Affairs) has been
appointed and besides him there are four Professors in-Charges in the
areas of Research & Development, Faculty Affairs & Alumni Affairs,
Student Affairs and Resource Planning & Generation. Normally, the
Director gives the charge to the Dean (Academic Affairs) on his absence
from the Headquarters. On some occasions, the Dean (Academic Affairs)
is also on leave during the absence of the Director from the headquarters.
Considering the various options, the Executive Council resolved as under:
RESOLVED that in the case of absence of the Dean
(Academic Affairs) from the station, the Director IIT(BHU)
may authorize one of the Professor In-Charges to look after
his duties during the absence of Dean (Academic Affairs).
: Dated: April 7, 2043
Copy forwarded for information and necessary action to the Director
IIT(BHU), BHU with the request to send the compliance report to the
undersigned as soon as possible to place the same before the
Executive Council in its next meeting.
| (\ a
Soo ha poe ar —J
“Yul 4 DEPUTY REGISTRAR
) EXECUTIVE COUNCIL CELL

<!-- page 9 -->

9S,
Shap,
. COPY OF ECR NO.ii5 DATED FEBRUARY 28, 20i35 28, 20i3 :

ECR 445 ;

ITEM 26(b) CONSIDERED the constitution of a Committee to decide the terms of
interaction and cooperation between the IIT (BHU) and BHU on all issues
concerning the two institutions, and to draft a MoU and a MoA to be signed
between the two institutions that will guide the interaction and cooperation
providing adequate synergy to both the institutions.

= The Executive Council noted that there are several issues in which the
roles and responsibilities of the two institutions needs to be clearly defined
and codified. It was felt that the terms of agreement between the two
institutions should be such that will promote growth and development of
both the institutions, in a synergy that ensures spilling over of benefits of
development of one institution to the other and vice versa. At the same
time, areas need to be identified where the benefits of specialization
available in one of them is available to the other, at the same time ruling
out possibilities of exacting benefits at the cost of the other institution.

~ The Executive Council therefore felt a need of constituting a suitable
committee involving the leadership of both the institutions to chalk out the
modalities of the draft MoU and MoA covering all aspects of activities and
the minute details as well. The issue was discussed in detail, following
which, the Executive Council resolved as under:
RESOLVED that a committee be constituted comprising of
members from both the institutions, who shall be nominated
by the Vice-Chancellor, BHU and the Director, IIT(BHU), who
themselves shall not be members of the Committee.
RESOLVED FURTHER that the recommendations of the
Committee as well as the drafted code/ MoU shall be

<!-- page 10 -->

approved by the Executive Council of BHU as well as 806
of IIT(BHU) before being signed by the two institutions.
Dated: April , 2043
Copy forwarded for information and necessary action to the
following with the request to send the compliance report to the
undersigned as soon as possible to place the same before the
Executive Council in its next meeting:
i. The Director IIT(BHU), BHU
2. The Deputy Registrar & Secretary to Vice-Chancellor
A
=-T - }
DEI REGISTRAR
EXECUTIVE COUNCIL CELL
