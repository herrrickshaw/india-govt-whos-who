---
doc_id: "fafa39dc7d2fda8b"
source_url: "https://cdn.s3waas.gov.in/s349182f81e6a13cf5eaa496d51fea6406/uploads/2024/03/2024030569.pdf"
ministry: "Amroha"
title: "Notification"
date: ""
pages: 5
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "7c4bd48863c7d0a5"
---

<!-- page 1 -->

प्रेषक,
विशेष भूमि अध्याप्ति अधिकारी,
(संयुक्त-संगठन), अमरोहा |
सेवा में,
निदेशक,
मुद्रण एवं लेखन सामग्री उ0प्र0,
इलाहाबाद |
पत्रांक ॥५ I3 /आठ--वि0भू0अ0अ0 (सं0सं0) / अमरोहा / 2024 दिनांक 9 ७ ०१ —_2024
विषयः- मध्य गंगा नहर परियोजना (द्वितीय चरण) के निर्माण हेतु ग्राम चकगुलाम अम्बिया
तहसील हसनपुर के भू-अर्जन प्रस्ताव में भूमि अर्जन पुनर्वासन और पुनर्व्यवस्थापन में
उचित प्रतिकर और पारदर्शिता का अधिकार अधिनियम-2043 की धारा i9 की
उपधारा (3) के अन्तर्गत जिला कलेक्टर महोदय अमरोहा द्वारा जारी की गयी
अधिसूचना संख्या-.)॥4...9....// आठ-वि0भू0अ0अ0 / अमरोहा दिनोक2262,64 का
गजट में प्रकाशन कराने के सम्बन्ध में।
महोदय,
उपरोक्त विषयक, जनपद अमरोहा में मध्य गंगा नहर परियोजना द्वितीय चरण के
निर्माण हेतु ग्राम चकगुलाम अम्बिया तहसील हसनपुर में रकवा o3ti0 हे0 के भू-अर्जन प्रस्ताव में
भूमि oom qk और पुनर्व्यवस्थापन में उचित प्रतिकर और पारदर्शिता का अधिकार
अधिनियम-2043 की धारा i9 की उपधारा (3) के अन्तर्गत जिला कलेक्टर महोदय अमरोहा द्वारा
अधिसूचना संख्या-.])4॥.9...,// आठ-वि0भू0अ0अ0 / अमरोहा Parte aay fo. को जारी की गयी हैं,
जिसका गजट में प्रकाशन कराया जाना है। /
अतः आपसे अनुरोध है कि जिला कलेक्टर महोदय अमरोहा द्वारा जारी की गयी
संलग्न अधिसूचना का शीघ्र गजट में प्रकाशन कराने का कष्ट करें तथा प्रकाशित गजट की एक प्रति
इस कार्यालय को उपलब्ध कराने का कष्ट करें।
संलग्नक-उपरोक्तानुसार | ae
विशेष भूमि अध्याप्ति अधिकारी,
(संयुक्त-संगठन), अमरोहा।
संख्या व दिनांक STRIATE |
प्रतिलिपि:- निम्नलिखित को इस आश्य से प्रेषित कि संलग्न की जा रही अधिसूचना को अपने
कार्यालय के नोटिस बोर्ड पर चस्पा कराने का कष्ट करें।
4. तहसीलदार हसनपुर।
2. अधिशासी अधिकारी, नगर पालिका, हसनपुर |
3. ग्राम प्रधान चकगुलाम अम्बिया तहसील RAG |
4. अधिशासी अभियन्ता, मध्य गंगा नहर निर्माण as-is, गढमुक्तेश्वर जनपद हापुड़ को जिला
कलेक्टर महोदय अमरोहा द्वारा जारी की गयी अधिसूचना की प्रति इस आशय से संलग्न कर प्रेषित है
कि संलग्न विज्ञप्ति का प्रकाशन राजकीय गजट में प्रकाशन के उपरान्त गजट का प्रकाशन स्थानीय
प्रचलित दो दैनिक समाचार पत्रो जिनमें से एक प्रादेशिक भाषा में हो, में कराकर समाचार पत्रों की
तीन--तीन प्रतियाँ इस कार्यालय को उपलब्ध कराने का कष्ट करें।
_s-forr सूचना विज्ञान अधिकारी कलक्ट्रेट, अमरोहा को इस आशय से प्रेषित कि संलग्न अधिसूचना
जिला अमरोहा की वेब-साईट पर अपलोड करने का कष्ट करें।
संलग्नक-उपरोक्तानुसार | &
विशेष भूमि अध्याप्ति अधिकारी,
(संयुक्त-संगठन), अमरोहा।

<!-- page 2 -->

VA
री
प्रारूप-49
Pas का sae (॥)
मे समुचित सरकार / कलेक्टर द्वारा घोषणा
thas की धारा-49 की उपधारा () के अन्तर्गत) है हू
उत्तर प्रदेश सरकार ‘
gay प्रदेश Rie, Beret aoa reer -
अधिसूचना सच्या-क१]9-/275- मे oe 0340 eF
> दिनांक Gorey ० ५
; SE प्रवेश Rae, विधाग द्वारा अधिएशगिए सध्य गंगा Ra esta, गढ़गुक्तेश्वर, अपेक्षित निकाय का
जागो के होश one सार्वजनिक प्रयोजन यथा...... मध्य, गंगा, नहर. परियोजना (द्वितीय ..चरण).....परियोजना हेतु
जिला, अमझोह्टा तहसील AG परगना... हसनपुर्‌.......ग्राम.. चकगुलाम अम्बिया, में feers,.03i.20 भूमि के
सम्बन्ध में भूमि अर्जन, पुनर्वासन और पुनर्व्यवस्थापन में उचित प्रतिकर और पारदर्शिता का अधिकार अधिनियम,
on et की उपधारा-() के अन्तर्गत जो प्रारम्भिक अधिसूचना संख्या
42i8 /ane—faoypsioso / अमरोहा // 28 दिनांक 2022028 को निर्गत की गयी थी तथा अन्तिम रूप से
प्रकाशित दिनांक 44.02.2023 को प्रकाशित की गयी थी। डिप्टी कलेक्टर /असिस्टेट कलेक्टर अमरोहा को
परियोजना प्रभावित परिवारों के पुनर्वासन एवं पुनर्व्यवस्थापन के उद्देश्य से प्रशासक नियुक्त किया गया था।
अधिनियम की aris की उपधारा (2) के प्राविधानों के अनुपालन में कलेक्टर द्वारा प्रस्तुत रिपोर्ट के
विच्यारोपरान्त a—s0(t) के अन्तर्गत राज्यपाल घोशणा करने का निर्देश देते है कि उन्हें यह समाधान हो गया है
कि अनुसूची vw” में वर्णित भूमि का क्षेत्रफल सार्वजनिक प्रयोजन हेतु आवश्यक है तथा अनुसूची “ख” में
उल्लिखित जिला. अमरोहा तहसील हसनपुर, परगना... BT. चकगुलाम अम्बिया ...में स्थित भूमि को
'विश्थापित परिवारों के पुनर्वासन एवं पुनर्वावस्थापन हेतु पुनर्वासन एवं पुनर्व्यवस्थापन एवं पुनर्व्यवस्थापन क्षेत्र के रूप “
: 3) favs किया गया- है।
राज्यपाल अग्नेत्तर निवेश देते है कि अधिनियम की ar-i9 की उपधारा (2) के अधीन इस प्रभाव की
घोषणा के प्रकाषन के साथ पुनर्वासन एवं पुनर्व्ववस्थापन योजना के सारांश के प्रकाशन हेतु अमरोहा कलेक्टर को
निर्देशित करते है| पुनर्व्यवस्थापन योजना का सारांश इसके साथ संलग्न है। :
अनुसूची-क'
(प्रस्तावित अर्जन के अन्तर्गत भूमि)
| जनपद |. तहसील eset | ग्राम | = भूखण्ड to |... अर्जित के जाने वाला
ee eee eS वन — E __ ten 4)
(Sas Oe re ee a 5 i sore :
; अमरोहा | हसनपुर | हसनपुर चकगुलाम | —35_ sami SOD)
| | अम्बिया | ee
| | | । ear Pee a OS
| | | | 98 Soa OUST :
| | es fac 0.028
लेन | Eo Se a
मिलन ली लिन ie का | fi te El iain न
हि ert छः oN Q oe 4 eS शिकारी
45 nye a जम ae 2 er oe जिला
RAT गंगा नहर निर्माण WTS ehh है महर निर्माण खण्ड-१0 aor गंगा जहर निर्माण र ol ~ Sorter
गंदगुक्तेश्वर (STE) wT gree (FES) a as stearate aici
4 au ऊ ee गठमुक्तेश्वर (हापुड़)
ere
yy
पक dws), अमरोडा

<!-- page 3 -->

अनुसूची-ख
(विस्थापित परिवारों के लिए व्यवस्थापन क्षेत्र के रूप में चिहिन्त भूमि)
जनपद लि गा, Bate oe “Tag संग grates हेतु चिच्हित क्षेत्रफल
" eee Ss की लि ace cae ea SSS sear
| 7 ---- विश्थांपित परिवार की ea शेर ———_——_-——
“Poh उक्त भूमि का स्थल Fae... कलेक्टर के का जा सकता है।
आज्ञा से
सचिव / प्राधिकृत अधिकारी
कलेक्टर द्वारा घोषणा की अधिसूचना
अधिनियम की घारा-49 की उपधारा (2) के अन्तर्गत
उत्तर प्रदेश सिंचाई Sart द्वारा iBone मध्य गंगा निर्माण ख़ण्ड-.3,गढ़मुक्तेश्वर (हापुड)........(अपेक्षित
निकाय का नाम) के माध्यम से सार्वजनिक प्रयोजन की . मध्य गंगा नहर परियोजना (व्रितीय चरण)...परियोजना हेतु जिला
2 SEMEL तहसील ELL परगना,..हसुनुपूर......ग्राम चकगुलाम अम्बिया .......में ARere,.0,324, Bo भूमि के लिए प्रकाशित
अधिसूचना संख्या.......................विनांक................के क्रम में मेरे द्वारा घोषणा का प्रकाशन कर दिया गया है तथा सरकारी हू
अधिसूचना के साथ पुनर्वासन एवं पुनर्व्यवस्थापन योजना का यासंश संलग्न कर दिया गया है। पुनर्वासन एवं पुनर्व्यवस्थापन
योजना का सारांश निम्नवत्‌ है- ५
a भूमि का स्थल नक्शा करणेक्टर के कार्यालय में भूमि अर्जन के उद्देश्य से देखा जा सकता है।
हि सर
iy
erin नहर निर्माण ease हु
बाहुमवेतेश्तर (ETE) साहा ge निभोण OSS SHORT Stas
loge spat ate (ergs) मध्य गंगा नहर निर्माण रू ड-१३
३ भूमि अध्याप्ति अधिकारी :

<!-- page 4 -->

FORM-I9
[Sub-rule({) of rule 27]
PRELIMINARY NOTIPLACTION BY APPROPRIATE GOVERMENT/COLLECTOR
[UNDER SUB-SECTIO} 27 SECTION 9 OF THE ACT]
GOVERMENT OF UTTAR PRADESH
IRRIGATION AND WATER RESOURCES DEPARTMENT, UTTAR PRADESH
NOTIFICATION NO. 00.2०) a] wr ha
DATE .. 20 agp
NOTIFICATIONS 2९2५
Whoreas Preliminary notification no. 248/VITI- §.L.A.0/Amroha/2023 dated 02.02.2023 was issued
Under Sub-seetion () of section Li of the Right te Pair Compensation and Transparency in Rehabilatation
and Resettlement Act,203, in respect of a total of 0.53 hectare of land is required in the Village
Chakgulamambia, Parg Hasanpur, Tehsil —!asanpur, District Anwoha is required for public purpose,
; namely, project MADITYA GANGA CANAL PHASE 2" through IRRIGATION AND WATER
RESOURCES DEPARTMENT, UPEAR PRADESH, THROUGH EXECUTIVE ENGINEER, MADHYA
; GANGA CANAL CONSTRUCTION DIV-I3, GARHMUKTESHWAR (Name of Acquiring body) and lastly
published on dated 4.02.2023 The Deputy Collector / Assistant Collector Amroha was appointed as
Adnynistrator for ‘he purpose of rehabilitation and resettlement of the project affected families.

After considering the report of the Collector submitted in pursuance to provision under sub section
(2) of the section {5 of the Act, the Governor । sid to declare under section £9(4) of the Act that he is
satisfied that the area of the land mentioned in the given schedule ‘A’ is needed for public purpose and the
land to he extent in Village —-Dhabarsi Pargann- !osanpur, Tehsil- Hasanpur, District — Amroha, as given in
schedule ‘B? has been identiod as the Rehabiliation and Resettlement area for the purpose of Rehabiliation
and Resettlement of the displaced families.

The Governor is further pleased under sub section (2) of section 9 of the Act, to divert the Collector
of AMROHA fo publish a summary of the Rehabilition and Resettlement scheme with publication of the
Declaration to this effect. The summary of the Rehabiliation and Resettlement scheme is attached herewith.

DISTRICT FEHSIL | PARGANA | VILLAGE | iF i: - BE
| i i ACQUIRED (IN
| i 2 | 3 ae eae | Soe ano
। जा | Hasanpur | ~~ Havanpar "Chakgulamambia । 35 0./50
॥ | | es Ee 0.03I

| | | Sees s 0.03I
| | | | bases Tem al STA
| | | | ae 40 0,037
| 5 sranp Tora | 03it
if a
ces ८ डे ee \ we प्र
i निर्माण खण्ड-3 जन on TF
TETRA ai लहर f vex गंगा TER निर्माण 33
रवि y
(8:22

<!-- page 5 -->

“~~.
e
NOTIFICATION OF DECLARATION BY COLLECTOR
{UNDER SUB SECTION 3” SECTION 9 OF THE ACT}

By the Order of Declaration made under Government notification no.
rs src GACD .................-०० 0.342  heetare of land is required in the Village
Chakgulamambia Pargana — Hasanpur, Tehsil — Hasanpur, District- Amroha is required for
public purpose, namely, project MADHYA GANGA CANAL PHASE 2™ through
IRRIGATION AND WATER RESOURCES DEPARTMENT, UTTAR PRADESH, -
THROUGH EXECUTIVE ENGINEER ‘ORY A GANGA CANAL CONSTRUCTION
0-3३, GARHMUKTESHWAR (Name of Acquiring body) and I hereby Published the
declaration made therein and summar y of Rehabilitation and Resettlement scheme along
wit Government notification. A summary of the Rehabiliation and Resettlement scheme is

. given below:- :
The plan of land may be inspected in the office of the Collector AMROHA for the purpose
of Acquisition,
= . BY Ofder :
J ५ Galette
2 YG ips ८2४
मध्य गंगा नहर निर्माण खण्ड--3 eras अभियन्‍्ला-तृत्तोय A,
गढ़मुक्तेश्वर (हापुड) मध्य गया नह है
7X x
हि थम जध्याप्ति अधिकारी
OT सगठन), अमरोहा
