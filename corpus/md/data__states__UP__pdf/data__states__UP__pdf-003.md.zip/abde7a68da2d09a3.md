---
doc_id: "abde7a68da2d09a3"
source_url: "https://www.upkrishivipran.in/pdf/67_Go.pdf"
ministry: "Directorate of Agricultural Marketing and Agriculture Foreign Trade, Uttar Pradesh"
title: "शासनादेश देखें"
date: ""
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "fa17901bca0ecc32"
---

<!-- page 1 -->

उत्तर प्रदे श शासन
कृषि षिपणन एिं कृषि षिदे श व्यापार अनुभाग-2
सं ख्या-08/2026/29/अस्सी-2-2026/80-2099/6/2026-E-2020445

लखनऊ षदनांक 02 षसतम्बर, 2026

अषिसू चना
उत्तर्‍ प्रदे श्‍ कृनि्‍ उत्पादन्‍ मण्डी्‍ ननयमावली,1965्‍ के्‍ ननयम्‍ 58-क्‍ के्‍ साथ्‍ पनित्‍ उत्तर्‍ प्रदे श्‍ कृनि्‍
उत्पादन्‍मण्डी्‍अनिननयम,1964्‍(उत्तर्‍प्रदे श्‍अनिननयम्‍संख्या-25्‍सन््‍ 1964)्‍की्‍िारा्‍7-क्‍की्‍उपिारा्‍(1)्‍के्‍
अिीन्‍शक्तियों्‍का्‍प्रयोग्‍करके,्‍राज्यपाल्‍घोििा्‍करते्‍हैं ्‍नक्‍ग्राम्‍बहुआ्‍दे हात, परगना्‍अयाहशाह, तहसील्‍और्‍
नजला्‍ फतेहपु र्‍ में्‍ मै0 पवन्‍ ग्रामोद्योग्‍ सेवा्‍ संसथान,्‍ गां िी्‍ नगर बहुआ,्‍ नजला्‍ फतेहपु र्‍ के्‍ स्वानमत्वािीन्‍ नीचे्‍
ब्यौरे वार्‍ क्षेत्र,्‍ इस्‍ अनिसूचना्‍ के्‍ सरकारी्‍ गजट्‍ में्‍ प्रकानशत्‍ नकये ्‍ जाने्‍ के्‍ नदनां क्‍ से्‍ नवनननदि ष्ट्‍खाद्यान्न,्‍दलहन,्‍
नतलहन,्‍फल्‍एवं्‍ सब्जी्‍के्‍थोक्‍सौदों्‍ हे तु्‍ बीस्‍(20) विि्‍ की्‍अवनि्‍के्‍नलए्‍इस्‍शति्‍ के्‍साथ्‍मण्डी्‍उपसथल्‍के्‍
रूप्‍में्‍कायि्‍ करे गा्‍नक्‍कृिक-नवक्रेता्‍से्‍ कोई्‍मण्डी्‍शुल्क्‍प्रभाररत्‍नहीं्‍ नकया्‍जाएगा्‍और्‍पू वोि्‍सथान्‍फुटकर्‍
व्यापार्‍हे तु्‍प्रयु ि्‍नहीं्‍नकया्‍जाएगा।
मण्डी उपस्थल की खसरा एिं चौहद्दी
्‍्‍्‍्‍्‍्‍कृनि्‍उत्पादन्‍मण्डी्‍सनमनत,्‍फतेहपु र,्‍नजला्‍फतेहपु र्‍के्‍मण्डी्‍क्षेत्र्‍के्‍भीतर्‍अवक्तसथत्‍गाटा्‍
संख्या-433्‍का्‍कुल्‍भूनम्‍क्षेत्रफल्‍0.9432हे 0
पू रब्‍्‍्‍्‍्‍-्‍्‍्‍गाटा्‍संख्या्‍430्‍नहर।
पनिम्‍्‍्‍-्‍्‍्‍गाटा्‍संख्या्‍302्‍बांदा्‍सागर्‍रोड।
उत्तर्‍्‍्‍्‍-्‍्‍्‍गाटा्‍संख्या्‍432्‍श्रीमती्‍कमला्‍नसंह्‍आनद्‍की्‍भूनम्‍(आबादी)।
दनक्षि्‍्‍्‍-्‍्‍्‍गाटा्‍संख्या्‍434्‍उ0मा0्‍नवद्यालय्‍बहुआ(रानी्‍लक्ष्मीबाई्‍बानलका्‍इण्टर्‍कालेज)।
आज्ञा्‍से,

रनवन्द्र
प्रमुख्‍सनचव।
सं ख्या-08/2026/29(1)/अस्सी-2-2026/80-2099/6/2026-E-2020445, तषद्दनांक।
प्रनतनलनप्‍ननम्ननलक्तखत्‍को्‍सूचनाथि्‍एवं्‍आवश्यक्‍कायि वाही्‍हे तु्‍प्रे नित्‍:-्‍
1)

संयुि्‍ ननदे शक,्‍ राजकीय्‍ मुद्रिालय,्‍ ऐशबाग,्‍ लखनऊ्‍ को्‍ उपरोि्‍ अनिसूचना्‍ की्‍ अँ ग्रेजी्‍ प्रनत्‍
सनहत्‍इस्‍अनुरोि्‍के्‍साथ्‍प्रे नित्‍नक्‍कृपया्‍नदनांक 02नसतम्बर,2026्‍के्‍असािारि्‍गजट्‍के्‍नविायी्‍
पररनशष्ट्‍ के्‍ भाग-4्‍ के्‍ खण्ड-(ख)्‍ में्‍ प्रकानशत्‍ कराते्‍ हुए्‍ उि्‍ गजट्‍ की्‍ 50्‍ प्रनतय ं्‍ शासन्‍ को्‍
उपलब्ध्‍कराने्‍का्‍कष्ट्‍करें ।

1-

यह शासनादे श इलेक्ट्राननकली जारी नकया गया है, अत: इस पर हस्‍ताक्षर की आवश्‍यकता नही है ।

2- इस शासनादे श की प्रमानिकता वेब साइट http://shasanadesh.up.gov.in से सत्‍यानपत की जा सकती है ।

<!-- page 2 -->

2)

ननदे शक,कृनि्‍नवपिन्‍एवं्‍कृनि्‍नवदे श्‍व्यापार्‍ननदे शालय,उ0प्र0,लखनऊ।

3)

ननदे शक,राज्य्‍कृनि्‍उत्पादन्‍मण्डी्‍पररिद,उ0प्र0,लखनऊ।

4)

नजलानिकारी,फतेहपु र।

5)

उप्‍ननदे शक,्‍(प्रशासन/नवपिन)्‍मण्डी्‍पररिद,्‍प्रयागराज।

6)

सनचव/सभापनत,्‍कृनि्‍उत्पादन्‍मण्डी्‍सनमनत,्‍फतेहपु र।

7)

सहायक्‍कृनि्‍नवपिन्‍अनिकारी,्‍प्रयागराज।

8)

ज्येष्ठ्‍कृनि्‍नवपिन्‍ननरीक्षक,फतेहपु र।

9)

श्री्‍नवजेन्द्र्‍बहादु र्‍नसंह्‍पु त्र्‍श्री्‍प्रताप्‍नसंह,्‍प्रोपराइटर,्‍फमि्‍मै0 पवन्‍ग्रामोद्योग्‍सेवा्‍संसथान्‍पता्‍गां िी्‍
नगर बहुआ,्‍जनपद्‍फतेहपु र।

10)

गाडि ्‍बु क।

्‍टी0 के0्‍नशबु
्‍नवशेि्‍सनचव।्‍

1-

यह शासनादे श इलेक्ट्राननकली जारी नकया गया है, अत: इस पर हस्‍ताक्षर की आवश्‍यकता नही है ।

2- इस शासनादे श की प्रमानिकता वेब साइट http://shasanadesh.up.gov.in से सत्‍यानपत की जा सकती है ।

<!-- page 3 -->

Uttar Pradesh Shasan
Krishi Vipran Evam Krishi Videsh Vyapar Anubhag-2
In pursuance of the provisions of clause (3) of Article 348 of the Constitution, the
Governor is pleased to order the publication of the following English translation of Notification
no.08/2026/29/अस्सी-2-2026/80-2099/6/2026-E-2020445 dated 02 September, 2026

NOTIFICATION
No.08/2026/29/अस्सी-2-2026/80-2099/6/2026-E-2020445
Lucknow Dated 02 September, 2026

In exercise of the powers under sub-section (1) of section 7-A of the Uttar Pradesh
Krishi Utpadan Mandi Adhiniyam, 1964 (U.P. Act No. 25 of 1964) read with rule 58-A of Uttar
Pradesh Krishi Utpadan Mandi Niyamawali 1965, the Governor is pleased to declare that the
area detailed below owned by M/s Pawan Gramodyog Seva Sansthan, Gandhi Nagar Bahua,
District Fatehpur in Village Bahua Dehat, Pargana Ayahshah, Tehsil and District Fatehpur shall
function as Market Sub-Yard for specified wholesale transaction of foodgrains, pulses, oilseeds,
fruits and vegetables for a period of twenty (20) years with effect from the date of publication of
this notification in the Official Gazette, with the condition that no market fee shall be charged
from the agriculturist-seller and the aforesaid place shall not be used for retail trade.
Khasra and Boundaries of the Market Sub-Yard
Gata no. 433, Total land Area of 0.9432 hectares, located within the market area of Krishi
Utpadan Mandi Samiti, Fatehpur District Fatehpur.
East - Gata No. 430 Canal.
West - Gata No. 302 Banda Sagar Road.
North - Gata No. 432 Land of Mrs. Kamla Singh, etc. (Aabaadee).
South - Gata No. 434 Higher Secondary School Bahua (Rani Lakshmi Bai Girls
Inter College).

By order,

Ravinder
Principal Secretary.

1-

यह शासनादे श इलेक्ट्राननकली जारी नकया गया है, अत: इस पर हस्‍ताक्षर की आवश्‍यकता नही है ।

2- इस शासनादे श की प्रमानिकता वेब साइट http://shasanadesh.up.gov.in से सत्‍यानपत की जा सकती है ।
