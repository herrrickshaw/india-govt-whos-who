---
doc_id: "f708be9b63dd7fed"
source_url: "https://iitbhu.ac.in/contents/institute/2023/notification/noti_ibc_12372.pdf"
ministry: "Indian Insttitute of Technology (BHU), Varanassi"
title: "Institute Biosafety Committee"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "03e26a2227df4c64"
---

<!-- page 1 -->

Ze
©) भारतीय INDIAN
i!
: (S) प्रौद्योगिकी INSTITUTE OF
y SS हु संस्थान TECHNOLOGY
काशी हिन्दू विश्वविद्यालय BANARAS HINDU UNIVERSIT:
—«T—--. OS EE ee
कुलसचिव कार्यालय Office of the Registrar
प्रशासन General Administration
(सामान्य ) ( )
Ref. No. IIT(BHU)/GAD/2(94)/ Institute Biosafety Committee/Comm./ \2B¥2 Dated: 24.07.2023
NOTICE ~
The following Institute Biosafety Committee has been constituted with immediate effect. The committee shall look
into the matter pertaining to the Biosafety in the Institute.
I. Dean (R&D), IIT(BHU), Ex-officio - Chairman
2. DBT Nominee - Member (To be nominated by DBT)
3. Prof. Gopal Nath, Deptt. of Microbiology, IMS, BHU - Biosafety Officer
4. Prof. Ragini Srivastava, Deptt. of Biochemistry, IMS, BHU - External Member
5. Dr. Sanjeev Kumar Mahto, Associate Professor, - Internal Member
School of Biomedical Engg., IIT(BHU)
6. Dr. Abhishek Suresh Dhoble, Assistant Professor, - Member
School of Biochemical Engg. IIT(BHU) :
7. Dr. Vinod Tiwari, Associate Professor, - Member Secretary
Deptt. of Pharmaceutical Engg. & Tech.,IT(BHU)
The term of the above Committee shall be for 02 years or till further orders whichever is earlier.
This issues ‘Ra, the approval of the Competent Authority.
Deputy Registrar (G) a
Ref. No. IIT(BHU)/GAD/2(94) Institute Biosafety Committee/Comm,/ 342 Dated: 24.07.2023
Copy forwarded to the following for information and necessary action.
I. All the Deans
2. All the Associate Deans
3. All the Heads of Departments/Coordinators of Schools
4. The Coordinators/Incharge of Units/Centers/Offices
5. All the Professor In-charges
6. The Chief Councillor, Gymkhana
7. The Chairman, Institute Works Department
8. Professor In-charge, Shreenivas Deshpande Library
9. The Coordinator, IIT-Cafeteria
!0. The Chairman, Council of Wardens *
Il. The Chairman, Web Management & E-mail Services Committee — (with a request to upload the san : on the
Institute website)
!2. The Chairman, Press & Publ icity Committee
I3. The Coordinator, GTAC
I4. All the Member Concerned
!5. The Chief Proctor, IIT(BHU)
!6. All Admin. Wardens/Wardens, IIT(BHU)-Hostels
!7, All the Joint Registrars
_ आ ख आ ख ह इ एइृऊपप7.7ोण|/।/,.प7णण/ण/ण०/“/“ रंींंफ./तऔऔै
aa. भारतीय प्रौद्योगिकी संस्थान(का.हि.वि.) वाराणसी - 224005 ie
6, भारत ae
Indian Institute of Technology(BHU) Varanasi-
22005 India
Tel Nov * 0849-7266476 Fax No - 0547-7369478 Fmail: office gad@ithhi ac in Web: iithhn ac in
