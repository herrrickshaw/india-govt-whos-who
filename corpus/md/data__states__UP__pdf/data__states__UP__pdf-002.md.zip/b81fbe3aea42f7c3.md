---
doc_id: "b81fbe3aea42f7c3"
source_url: "https://www.iitbhu.ac.in/contents/institute/cf/misc/doc/innovation_start_up_policy.pdf"
ministry: "Indian Insttitute of Technology (BHU), Varanassi"
title: "Start-up Policy"
date: ""
pages: 20
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "48f11d12c9fdc95c"
---

<!-- page 1 -->

i: © पी प्रौद्योगिकी INSTITUTE OF | (7953
Ws संस्थान TECHNOLOGY “al Sine Abe:
Sees काशी हिन्दू विश्वतिधालय BANARAS HINDU UNIVERSITY ४७७७७
Innovation and Start-up Policy
Indian Institute of Technology (Banaras Hindu University)
Varanasi — 22005
ee eG tet Oh if 2 हक as =
ae es a ee oS

<!-- page 2 -->

Revision History
Sl.No. Particulars Version
L. Initial Draft 0.2
2. Reviewed and approved by the committee 2.0

<!-- page 3 -->

Contents
INtrODUCtION .............. ५५ "__न्‍जन्‍त_न_ॉ्--न लनलनतत ललित ललित न लननननन नमन नर 3
Capacity Building Programs: 3
Awards and Recognition: 3
ALLEN Ane: ......essesssssesssesseessecesseseeseenenseseescactessersessessessacssescenesearseneseecescenscssseansarssesseseneenaseaneseeseansnenes 4
Semester/Year Break: 4
ACCOMMODATIONS ........ccccsecssessesneenneassessecucenserscesesseceeeenteassoseesensesanectecanenennscneanseneneecencaneaneey 4
Incubation Support: 5
Financial AsSistamCe:..........cscccecsesssccsnecessnsssecsecansenessesansanssussaceneaneesarsssenenseenseracenesersenesseeneaneessenceneseenseneesesseD
EDAPT Hub 70 प्रापी0ा................ "०० ""न्‍--->-््््नननननन लत ननन रन न नननिनिनननिननननिनिननननननननिननन नितिन नननलह > नी.
Ideation Innovation & Incubation (!-3} Foundation (I3F) 8
NCL-IIT (BHU) Incubation Centre (॥॥९) ..................--.-------- »_्>नन_द-- >ततभननललन न ननञ न ननन्‍ न ल्‍ >> LO
RKVY-RAFTAAR Agri Business Incubator (३-७8॥) .....................०----० ६ "ब_ब्ननननन्नान्‍ननग-ननननननननन्लननञनन्> tL
= CISCO thingQbator .......essssesssecsessesecsseeeerseneecseessneseeeeesesssnesanesanesrssssssesssessussasneesnsesssssesananesaeeesesseeseaseensee LB,
E-Cell. हक
. General Policy Guidelines. 44
Intellectual Property & Operation Information 6
PUDIICAIONS ......ccsseesecsseeseeseessesseesecsecsnesnssueesscsscsseqneateseseeneanensessessesaeseesnesiesanssnsesisenseaserectstenentennenacaseenceasenrte LD
Termination of Contract.......cscccsssessesssessssesseessesnesssssecsssseesseessaseeseessecssssreasensecsesserseteaseicseesetserseerentensensette LB
Governing Law & Arbitration 38
FOrCE Majeure ..............----------- ">> ल्‍ नल नमन नल हनन नननिननन न ननलनन नर नननन नमन नन नल LB,
AMMOUNCEMENL. ose ecceeceecseeeceseeseeesnneessessseensersssssensesscesnecssecesseessseanessnecessetaeesanastaaeeanesanssaninearernenneesseatsaeesses LB:
NOtiCeS. sess esesseesssssssecsecssessssseeseessesssvsssneeanessssssaneesesesassonsseaessaessaseescesneconeccasscctseeaeeqneetiecssatesessnessnetsneeseee LO
Indemnity oo. ceeeeeccceeseseceeeeeseeseceeneessaresssesecsesseressserenesecsnsesseesssescesnenssessssesesesessessenesnsesesseesieensnsertesseeeanses LO
2

<!-- page 4 -->

Introduction

The Ministry of Human Resource Development released the National Innovation and Start-up Policy in

2029 for students and faculty of Higher Education Institutions (HEIs). The Policy is in line with the focus of

Central Government on entrepreneurial projects.

The framework was created to enable the institutes to actively engage students, faculties and staff in

innovation and entrepreneurship related activities as well as to bring uniformity across HEls in terms of

Intellectual Property ownership management, technology licensing and institutional level Start-up policy.

Thus, enabling creation of a robust innovation and start-up ecosystem across all HEls.

To promote innovation and entrepreneurship, following enablers are implemented in IIT (BHU) Varanasi.

Capacity Building Programs:

+ The institute encourages training and development of faculty and staff involved in innovations and

. entrepreneurship development activities.

* To achieve better engagement in entrepreneurial activities, institutional policy on career

. development of faculty and staff would be modified with constant up skilling.

*  Cross-departmental linkages are strengthened to facilitate research and entrepreneurial activities
with multidisciplinary approach and to gain maximum utilization of internal resources and expertise.

* Periodically some external subject matter experts such as guest lecturers are engaged for strategic
advice and to bridge the gap of industry academia.

* Faculty and staff are encouraged to do courses on innovation, entrepreneurship management, and
venture development.

Awards and Recognition:

+ ॥ order to attract and retain talent, institute provides academic and non-academic incentives and
reward mechanisms for ali faculty, staff and stakeholders that are actively contributing to or
supporting innovation and entrepreneurship activities.

* The reward system for the faculty includes sabbaticals, office and lab space for entrepreneurial
activities, reduced teaching loads, awards, trainings, etc.

+ The recognition to the stakeholders may include offering use of facilities and services, strategy for
shared risk, working as a guest faculty, fellowships etc.

* A performance matrix may be developed and used annually for assessment and evaluation.

3

<!-- page 5 -->

Attendance:
Students involved in setting up of start-ups may be given a relaxation in attendance up,to 20%.
Semester/Year Break:
* Students: {IT (BHU) promotes entrepreneurship activities among students through sensitization
workshops, ideation workshops and elective subjects.
The detailed policy to promote entrepreneurship activities among students is in progress. It will be
published on the institute’s website soon
+ Faculty & Staff: The faculty/staff members can own the company or can be associated with any
company in an executive capacity or can also be the promoter of the company after taking permission
from the Institute. They can get themselves associated or start a new business venture in the
prescribed application format at the Ideation Innovation & Incubation (I-3) Foundation (I3F)/I-DAPT
. HUB Foundation /any other section 8 companies in IIT (BHU) Varanasi. The faculty member can join a
company as, (a) take a sabbatical leave and work full-time in the business or (b) dedicate part of the
हि working hour to the business idea.
The detailed policy to promote entrepreneurship activities among faculty is published on the website.
Click here https://intranet.iitbhu.ac.in/dord/doc/dord_ faculty enterpreneurship_policy.pdf to see
detailed faculty entrepreneurship policy of the institute.
Accommodation:
The institute may provide accommodation to the student entrepreneurs within the campus for some
period of time, depending upon availability of accommodation.
IPR Facilitation:
IIT (BHU) focuses to bring excellence in education, research and innovation, It is equally important to
protect the Intellectual property. Therefore, the institute facilitates assistance to cover all different classes
. of Intellectual Property - Patent, Copyright, Design, Registration, Trademark, and Non-Disclosure
Agreements.
When institute facilities / funds are used substantially or when IPR is developed as a part of curriculum/
academic activity, IPR is jointly owned by inventors and the institute. Inventors and institute can together
license the product / IPR to any commercial organization.
4

<!-- page 6 -->

Click here https://www.litbhu.ac.in/contents/institute/2024/notification/noti_gad_ipr_24036.pdf to see
detailed IPR policy of the institute. +
Incubation Support:
Pre-incubation and incubation support in physical and virtual mode is offered by the institute to the start-
ups for a period based on various schemes they have applied through.
Financial Assistance:
* The predominant model of start-up financing is debt funding. It is a big burden on the entrepreneurs.
So, equity funding is also provided on case-to-case basis.
+ The Institute works in association with external funding agencies of state and central government
such as DST, NSTEDB, MSME, Start-up India, Invest India UP IT Policy and RKVY-RAFTAAR.
+ The institute works in association with corporates such as Northern Coal Fields Ltd. HDFC Bank Ltd.
हु Cisco & NASSCOM Foundation, to generate funds, under Corporate Social Responsibility (CSR) as per
Section 35 of the Company Act 2043.
है * The Institute has a worldwide alma matter and is actively engaged with them for mentoring,
marketing and angel funding support to the Start-ups.
|-DAPT Hub Foundation
It is a nodal center and Technology Innovation Hub (TIH) for activities in “Data Analytics and Predictive
Technologies” under National Mission on Interdisciplinary Cyber Physical Systems (NMICPS).
The area of Data Analytics and Predictive Technologies (DAPT) has been identified as one of the emerging
fields which will impact significantly on a number of verticals of the economy, such as,
Telecommunications, Power, Road Transport & Highways, Defense Research and Development and
Health & Family Welfare. Further relevant areas are urban smart city initiatives, including city-wide water
distribution, waste management, air quality monitoring & control, as well as manufacturing and
; governance at national and international scales.
The term smart states that the corresponding system or “verticals” (for example: an urban transportation
network, soldier protection or healthcare diagnostics) is being enhanced by DAPT technology. The work
on each vertical segment depends on the integration of several techniques or “horizontals” (for example:
sensors, wireless communication, cloud computing and data analytics). With the increasing need for
5

<!-- page 7 -->

efficient utilization of scarce resources such as water and energy, increasing urbanization,
diagnostic/therapeutic delays, and increasing awareness of the impact. i
For details please visit the website https://www.idapthub.org/
Mission:
Creating environment for Innovation, Entrepreneurship & Start-up Ecosystem, Technology Development,
Skill Development and Establishment of Centre of Excellence through international linkages &
collaborations
Objectives:
* To nurture the ideas and innovations emerging from the scientific, technological and
knowledge capital
* To generate commercially viable and socially impactful Products/Processes/Services
पु * To contribute to the economic development and social wellbeing of the Region and the
Country
Primary thrust areas:
*  Telecommunications
* Power
* Road Transport and Highways
* Defence Research and Development
* Health & Family Welfare
Concept Mentors:
ach pre-incubation team / start-ups will have a concept mentor who has knowledge in the respective
field and may be able to give advice and share their expertise with them directly. Preferably, the concept
. mentor will be from IITs, liSc or other Institute of National Importance.
Incubation programs:
+ Pre-Incubation Program
* Incubation Program
Pre-Incubation Program:
6

<!-- page 8 -->

The Pre-incubation Program is planned to empower inventors (final year undergraduate students /
postgraduate students / PhD student / postdoctoral fellow / faculty members} to take up the
exploratory projects on their product or process oriented innovative ideas.
The program will be offered for 2 months during summer vacation. The pre-incubation teams will be
supported with a stipend of INR 8000 per month and they will be entitled to use all common facilities
of the TIH.
Pre-incubation selection criteria:
List of product ideas is available on the webpage of !-DAPT and will be updated from time to time.
Apart from this fist, if the pre-incubation team provides any other Data analytics and Predictive
Technology related idea for social impact, that may also be considered. The pre-incubation teams will
submit a proposal in consultation with the concept mentor(s) against the advertisement. The
committee will evaluate the proposal and inform the teams,
Incubation Program:
है Under Incubation program, |-DAPT Hub Foundation incubates start-ups in two stages —
Early-Stage Incubation:
List of product ideas is available on the webpage of IDAPT and will be updated from time to time.
Apart from this list, if the start-up provides any other Data analytics and Predictive Technology related
idea for social impact, that may also be considered. The innovators shall prepare a plan of product
development and submit a proposal for review. The proposal should also have (i) a market survey
component and (ii) feasibility of commercialization.
Monitoring committee will monitor the proposal and if found suitable will be considered for the early-
stage incubation with a financial support of up to {NR 20 Lakhs per idea.
Expansion-Stage incubation: हु
If the progress of the early-stage incubation team is Very Good/ Excellent, the team qualifies for the
हु expansion-stage incubation program. Various supports under this program includes —

> Funding support of up to INR 20 Lakhs for additional two years

» Assistance on further fund raising

>» All other supports of the early-stage incubation program will be applicable for the

Expansion-Stage Incubation program as well.
7

<!-- page 9 -->

Ideation Innovation & Incubation (I-3) Foundation (I3F)
I3F is an initiative at IIT (BHU), Varanasi for fostering innovation and entrepreneurial ecosystem in East UP
region. I3F has been working under dynamic leadership of Hon’ble Director, IIT(BHU) Varanasi. I3F is an
umbrella for sector specific units that are governed by various committees to run day-to-day activities.
Vision:
To contribute toward raising the GDP of the nation through Entrepreneurial activities — initiating start-ups
and supporting SMEs in East UP region
Mission:
Identifying, exploring and developing regional competitiveness, enhancing links between universities and
research institutions and contributing to growth and success of the start-ups.
Objectives:
43F has been established with the following objectives-

* To foster and promote entrepreneurship culture among students and society in the region

. «To create support system for Innovation-based enterprises/start-ups

* To encourage technology transfer and commercialization.

* To promote job creation and support “Make in India” Model

* To provide R & 0 support to SMEs and business incubators of the region

© To forge a close linkage between new business & academia R & 0
Managing Committee:
Managing Committee of I3F has been formed to monitor innovation and entrepreneurship activities from
time to time. The Committee has seven members comprising of the Director, IIT (BHU) Varanasi,
Coordinator, I3F and faculty of the Institute, The committee would be revised time and again once the
tenure is completed.

8

<!-- page 10 -->

Organization Chart —I3F
Se ‘
Se
—————
or oy ae Se eo ee
om es
i
a
or ae
a. ehh
Ea
I3F - Services Offered:
oO
O sk |
hha
TECHNICAL DUE-DILIGENCE TRAINING MENTORING LEGAL ADVICE
(00 re = = fo
-
IP CREATION AND PROTECTION FUNDING SUPPORT NETWORKING SUPPORT
9
