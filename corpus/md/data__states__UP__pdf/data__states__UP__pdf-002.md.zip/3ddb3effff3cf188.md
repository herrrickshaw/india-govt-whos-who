---
doc_id: "3ddb3effff3cf188"
source_url: "https://jn.upsdc.gov.in/site/writereaddata/UploadTender/pdf/C_202610231116169490.pdf"
ministry: "Uttar Pradesh Jal Nigam (Urban), Uttar Pradesh"
title: "“Laying of overflow pipe from existing manhole to existing drain including plugging of existing manhole, interconnection of overflow pipe to existing manhole and pumping arrangement near Mumfordganj Sewage Pumping Station in Municipal Corporation Prayagraj, District- Prayagraj”"
date: ""
pages: 7
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "a36587a5ff5cca48"
---

<!-- page 1 -->

हे _pNeR-EECI jOTEND 63/202 '6-EECDI-UPJNU-DEVPRJ I/754998072026
बल Fy, उत्तर जल
6 २ उत्तर प्रदेश जल निगम (नगरीय)
है कार्यालय अधिशासी etiam, निर्माण खण्ड (प्रथम),
कै) ०, १३ यमुना बैंक रोड, कीडगंज, प्रयागराज-२११००३
गम जीव Email : eecdalld@rediffimail.com
wim T Tis diigo [aeve [TEMD]es RTO lone
पत्रांक - J / IS 4 | (86 | 2096 | TEwD lez दिनांक: |7/// 0 / 2026
Short Term E-Tender Notice
On behalf of the Chairman, U.P. Jal Nigam (Urban) online e-tenders on percentage rate basis
in Two bid system for following works are hereby invited from the reputed contractors having
requisite work experience & financial capabilities. The bidders should submit their bids only if they
consider themselves eligible and are in possession of all the requisite documents.
a Estimated 7
* ie pe t Last Date | Time, date &
pits के & time of Place of
OST ota submission opening of
: Description of work & Tacs Money |Cost of bid} Period of ay Pr
Location (excluding | (Rs. In | document |completion| creas ae
N. GST & Li specified in | qualification
incluail oe) the bid Cum
थक documents | Technical Bid
Labour
Cess)
ee RT 5 eae छत सदा 8
“Laying of overflow
pipe from existing
manhole to existing
drain including On
plugging of existing 06..2026
manhole, (Rs At !/.00 Hrs
interconnection of| 3000+ Upto Office of the
38.33 0.77 T 05..2026 | Executive
l | overflow pipe 00 Lakh Lakh GST@I8! 4 Month up to 7:00 Engineer,
existing manhole and 4 %)=Rs. ? Hts. Construction
pumping arrangement 3540.00 Division-I,
near Mumfordganj aa
Sewage Pumping Prayagraj
Station in Municipal
Corporation Prayagraj,
District-Prayagraj’’
The Bid document may be downloaded from"https:// etender.up.nic.in"w.e.f dated 22.0.2026

4. Pre bid meeting date, time & venue: - 27.0.2026 at .30 AM in office of the
Executive Engineer, Construction Division-I, U.P. Jal Nigam (Urban),.

2. The Bid should be valid for 20 days from the last date of submission of bids,

3, If the date of opening of technical bid happens to be a holiday, the bid shall be
opened on the next working day at the same time for which no separate
communication shall be sent.

4. Bidders having criminal record will not be allowed to participate in Bid “Lh

Page l of 7

<!-- page 2 -->

ch ne
/PRJ-EECIOTEND/63/2026-EECDI-UPJNU-DEVPR] I/954I80/2026
4 5, A person registered with any State Bar Council will not be eligible to participate in
the Bid.
6. As per Government norms, GST at Applicable rate will be paid extra.
Te Joint Venture:- Not allowed.
8... Eligibility:-
Contractors who inter alia fulfill the following requirements shall be eligible to
apply.
(a) Firm should have successfully completed and commissioned similar works
(Similar work means “Completed and Commissioned work of
Maintenance of Sewer or Laying of Sewer including its appurtenant
works” mentioned be during last Ten years as on date of publication of NIT,
satisfying followings:-
Three Completed, Tested and Commissioned Similar Works each Costing not less than the
amount equal to 30% of estimated Cost put to tender (Le Rs. .50 Lakh each)
OR
Two Completed, Tested and Commissioned Similar Works each Costing not less than the
amount equal to 40% of estimated Cost put to tender (ie Rs. 5.33 Lakh each)
OR

One Completed, Tested and Commissioned Similar Work each Costing not less than the

amount equal to 60% of estimated Cost put to tender (i.e Rs. 23.00 Lakh)

PARTICULAR CONDITION:

The experience of Maintenance of Sewer or Sewer Laying must also include one work of

2/3rd size of maximum diameter mentioned in BOQ(Le. 600 mm x (2/3) = 400 mm dia ) of

this NIT in a minimum length of 500 m.

The bidders may submit additional experience certificate to qualify in above particular

condition category if certificates submitted to fulfill financial criteria do not contain the

category wise qualifying conditions,

Note:- The bidder should have experience of work contract including testing &
commissioning in last 0 years on date of publication of NIT.

(i) The certificates should be certified by an officer not below the rank of Executive Engineer/
Project Manager or equivalent. All the performance certificates submitted should be clear
and exhaustive enough to establish similarity with the work under Bid. Ambiguous
Performance Certificates will not be considered for evaluation.

(ii) The experience in foreign countries of a subsidiary or parent company will also be
considered for qualification. In case the company is not registered in India, the experience
has to be certified by the respective Embassy office/ Apostille (in case of members of
Hague Apostille Convention).

(iii) Sub-contracting / subletting experience shall be considered valid only if the Experience
certificate is directly issued to the sub-contractor by the department and work Experience
provides all relevant information and supported by relevant documents like 26 AS, a proof
of payment received from the client.

(b) Turn Over :- Should have average audited annual financial turnover during immediate
last 3 (three) consecutive financial years on construction works, equal to at least 30% of
the cost of work put to tender, ie. Rs. 4.50 lacs. Any Year in which no tumover is shown
will also be considered for working out the average.

(c) Net Worth :-The bidder must have a positive net worth in the = laf} financial
year and same should be certified by Statutory Auditor/Chartered Accountant. [/ Further,

Page 2 of 7

<!-- page 3 -->

#१|-550/ण-%80/63/2026-55ट94-ए20१-0६पएश्र I7454980/2026
; net worth of all the partners in a JV should individually be positive. At the time of Submission of
bid, contractor has to upload certificate from statutory Auditor/ Chartered Accountant of the
firm mentioning year wise audited financial turnover on Construction Works of last 05 years.
Further details , if required may be asked from the contractor after opening of technical bids.
(d)Solvency :- Certificate of minimum 40% of the tender value i.e. Rs. 5.33 lacs will be
required to be submitted.

* — Solvency Certificate issued by any Scheduled Commercial Bank shall be accepted,
which will be valid for a period of one year from the date of issue unless
otherwise mentioned.

Or

e Solvency Certificate issued by District Magistrate will also be accepted, which will

have a validity of one year from date of issue unless otherwise mentioned.
(e) Inflation Factor :-
The value of turnover on construction works/value of experience shall be brought to
current costing level by enhancing the actual values @ 7% per year calculated from the
date of completion to the date of publication of NIT. A typical index is given below.
Financial Year
Second Year .07
Fifth Year 4.28

9. This NIT and other information/corrigenda/addenda and Instruction for bidders
posted on website shall form part of bid document.

l0. The quantities given in the Bill of Quantities are estimated and provisional, and are
given to provide a common basis for bidding. These are liable to change up to any
extent for which no claim except as provided under contract shall be admitted.

ll. | The bid document consisting of Technical (eligibility) bid & financial bids including
specifications, the bills of quantities of various types of items to be executed and the
set of terms and conditions of the contract to be complied with and other necessary
document are available on "https://e-tender.up.nic.in".

2. | The technical bid shall be opened first on due date and time as mentioned above.
The time and date of opening of financial bid of contractors, qualifying the technical
bid shall be communicated to them on a later date through e-tender portal/ website.

3, If the Bidder feels that technical credentials of his own or other Bidders have been
wrongly evaluated/verified, he may raise objections within 2 (two) working days
from the date of uploading of result. No requests/objections shall be entertained
beyond above limit, else it may be treated as an obstruction in tender process and
shall be dealt with accordingly.

l4. U.P. Jal Nigam (Urban) reserves the right to reject any prospective application or to
cancel entire bid process without assigning any reason what so ever.

\5. E-tender document fee is non-refundable. It shall be deposited in the account of
Executive Engineer, Construction Division (0), UP Jal Nigam (Urban), Prayagraj
only by RTGS/NEFT in Union Bank of India, Chowk, Prayagraj, A/c No.-
394302070994456, IFSC Code- UBIN0807095.

l6, Earnest Money:

(a) EMD will be 2 % for works up to Rs 5.00 Cr. and | % or Rs 0.00 lacs
whichever is higher for works above Rs 5.00 Cr.
(b) EMD should be paid through RTGS or in the form of FDR/ f ik Guarantee
issued by any scheduled commercial Bank. f
Page 3 of 7

<!-- page 4 -->

>शु-६६070६90/63/2026-55009-00)]-08५शस् I/I549980/2026

(c) This Bank Guarantee must be in the prescribed format given in Annexure-6
of tender document and it should be valid for 65 days beyond the validity
period of Tender.

(d) The RTGS component of earnest money shall be deposited in the account of
Executive Engineer, Construction Division (I), UP Jal Nigam(Urban),
Prayagraj only by RTGS/NEFT in Union Bank of India, Chowk, Prayagraj,
A/c No.- 39430200994456, IFSC Code- UBIN0807095.

(e) The bidder shall deposit tender fees and earnest money separately in account
mentioned as above. Further he shall upload digitally signed copies of
original receipts of bank showing clearly the above details and/or the Bank
Guarantee.

() का case EMD is submitted in the form of Bank Guarantee/FDR, bidder
should ensure that such Original Bank Guarantee/FDR is mandatorily
deposited in the office of Executive Engineer, Construction Division(I),Uttar
Pradesh Jal Nigam(Urban), Prayagraj on or before the day of scheduled
date (during office hours) of opening of Technical Bid, either in person or by
Speed Post. The liability for timely submission shall lie with the Bidder, U.P.
Jal Nigam(Urban) shall not be responsible for delay on account of any
reason whatsoever.

(g) ‘It is made clear that Tender Fee and Earnest Money deposited in any other
form besides as mentioned above sub-paras shall render the bid non-
responsive.

(h) EMD if submitted in the form of BG/FDR should be pledged only in the
favour of Executive Engineer, Construction Division (I), Uttar Pradesh Jal
Nigam(Urban), Prayagraj.

l7. All the Bank Guarantees/FDR submitted towards EMD/Performance
Security/Additional Performance Security should be verifiable and cashable
from a branch situated in a city where the office of Divisional Officer is
located.

8. All the documents as specified in the technical bid/eligibility bid document
should be uploaded within the period of bid submission. U.P. Jal
Nigam(Urban)will not be liable for incomplete/inaccurate/non-submission of
bid for any reason whatsoever including technical reasons. It is made clear
that separate submission of originals of any documents (except Bank
Guarantee/FDR) other than scanning and uploading them, are not required,
unless called for, after opening of financial bid.

9. The bid submission shall become invalid if:

(i) The bidder is found ineligible.

(ii) The bidder does not upload all the documents as stipulated in the
bid document.

(iii) If any discrepancy is noticed between uploaded documents and
originals/hard copies submitted later.

(iv) If subsequent to due date of submission of bid and/or after its
submission bidder makes any further communication/
representation with regard to the bid (whether technical or
financial) than otherwise called for by the undersigned as a
clarification.

(ए) Ifa bidder does not quote any percentage above/below/par on the
total amount of the tender or any section/sub head in percentage
rate tender. Further the tender will not be considered as lowest
bid.

Page 4 of 7

<!-- page 5 -->

>धभग-६६यएण्रहा7/63/2026-६&६094-090॥४9-0६५थश /95480/2026
(vi) Conditional tenders or Tenders without e-tender document fee &
eamest money or invalid earnest money shall be summarily
rejected.
20. Performance Guarantee/ Security Money:
Performance guarantee @ 0% of the contract cost will have to be submitted at the
time of signing the contract in the form of FDR/ Bank Guarantee from any
scheduled commercial Bank Guarantee from any scheduled commercial Bank.
Alternatively on request of the contractor/firm, 5% of the performance Guarantee
will be accepted at the time of signing of contract and rest 5% may be deducted
from the initial running bill in a single deduction or at the rate of minimum 0% of
the gross bill amount of running bill. However, in any case whole amount of
balance performance guarantee shall be deducted within one year.
Works for which the cost of the tender received is more than 0 % below the
estimated. cost of works, in such situation, the performance security for firstl0%
below shall be 0% thereafter, additional performance security @ 0.50% for each
% further below than 0 % shall be deposited by the firm in order to safeguard
against contractor leaving the works.
24. The available bid Capacity of the Bidder at the expected time of bidding shall be
more than the total estimated cost of the work for which the tender is invited.
The available Bid Capacity shall be assessed using following formula:-
Assessed Available Bid Capacity = 2xAxN- B Where
A=Maxinium turnover during the last five financial year (corrected to the current
level of value)
N=Stipulated period of execution of the work for which the tender is invited in
year, (Here N will be consider as l)
B=value of existing commitments to be completed during the execution period
of bid.
The turnover shall be corrected to the current level of value by multiplying
with the updation factor given elsewhere with NIT/bid Document.

22. Intending Bidders are advised to inspect and examine the site and its surroundings
and satisfy themselves before submitting their bids as to the nature of the ground and
sub-soil (so far as is practicable), the form and nature of the site, the means of access
to the site, the accommodation they may require and in general shall themselves
obtain all necessary information as to risks ,contingencies and other circumstance
which may influence or affect their bid a bidder shall be deemed to have full
knowledge of the site, whether he inspects it or not, and no extra charge consequent
fo any misunderstanding or otherwise shall be allowed. The bidder shall be
responsible for arranging and maintaining at his own cost all materials, tools &
plans, water, electricity access, facilities for workers and all others services required
for executing the work unless otherwise specifically provided for in the contract
documents. Submission of a bid by a bidder implies that he has read this notice and
all other contract documents and has made himself aware of the instructions, scope
and specifications of the work to be done and local conditions and other factors
having a bearing on the execution of the work.

23. Canvassing whether directly or indirectly in connection with bids is strictly
prohibited and the bids submitted by the bidders who resort to canvassing will be
liable for rejection & will be debarred from future tender in UP Jal Nigam(Urban).

24, The bidder shall not be permitted to bid for works under supervisory control +
Executive Engineer concerned who is responsible for execution of work, in which y

Page 5 of 7

<!-- page 6 -->

शशर|-5६&एएण90/63/2026-58609-02|90॥-0६५शशु I/954I980/ 2026
his near relative is posted. He shall also intimate the names of persons who are
working with him in any capacity or are subsequently employed by him and who are
near relatives to any officer in the UP Jal Nigam(Urban). Any breach of this
condition by the contractor would render him, if empanelled with U P Jal Nigam
(Urban), liable to be removed from the approved list of contractors of U P Jal
Nigam(Urban) and make him liable for black listing.

25. No Engineer or other Gazetted Officer employed in Engineering or Administrative
duties in an Engineering U.P. Department of the STATE GOVERNMENT/State
Undertaking is allowed to work as a contractor for a period of two years after his
relirement from Government service, without the prior permission of the
Government of U.P. in writing. This contract is liable to be cancelled if either the
contractor or any of his employees is found any time to be such a person who had
not obtained the permission of the Government of U.P. as aforesaid before
submission of the bid or engagement in the contractor's ee

(Ashutosh Yaday)
Executive Engineer
Endt. No.- tf i Date -
Copy to the following for information and necessary action Please:-.
l. Managing Director, UP Jal Nigam (Urban), Lucknow.
2. Chief Engineer (PPRBD), UP Jal Nigam (Urban), Lucknow.
3. Chief Engineer (Nagar), UP Jal Nigam (Urban),6, Rana Pratap Marg, Lucknow.
4. Chief Engineer (Prayagraj zone), UP Jal Nigam (Urban), Prayagraj.
5. District Magistrate, Prayagraj.
6. Municipal Commissioner, Prayagraj.
7. General Manager, Jal Kal Vibhag, Nagar Nigam, Prayagraj
8. Public Relation Officer, UP Jal Nigam(urban), 6- Rana Pratap Marg, Lucknow
along with 6 copies of brief version of tender notice for publishing the same in at
least two National level News Papers (Hindi & English) on two consecutive days.
9. Superintending Engineer, Construction Circle, U.P. Jal Nigam (Urban), Prayagraj.
0. Executive Engineers, EDP Cell, UP Jal Nigam (Urban),Lucknow for publishing on UPIN
(Urban) website.
I]. Notice Board. Digitally signed by
Ashutosh Yadav
Date: 7-0-2026
5:27:39
Executive Engineer
Page 6 of 7

<!-- page 7 -->

eee SS = __ ae. नं छू तामाकऋ ह न
| _vPRJ-EECIOTEND/63/2026-EECDI-UPJNU-DEVPR} 4/454980/2026
(Fr, उत्तर प्रदेश जल निगम (नगरीय)
: 9 कार्यालय अधिशासी अभियन्ता, निर्माण खण्ड (प्रथम),
क्‍ रो... १३ यमुना बैंक रोड, कीडगंज, प्रयागराज-२११००३
ह Email : eecdalld@rediffmail.com
Ger Tice ibelaoae [TenD]e3 Rm ता अं TT al
wig - JT | [£4) (Q0 [koe / TEND [63 दिनांक:/ 7 //o / 2026
SHORT TERM E-TENDER NOTICE IRT TERM E-TENDER NC TICE
(Short description of the E-Tender Notice for publication in newspapers)
On behalf of the Chairman, U.P. Jal Nigam (Urban) invites Online percentage plus/minus
(+#-) rate e-tenders on Turn-key basis in Two bid system for execution of “Laying of overflow
pipe from existing manhole to existing drain including plugging of existing manhole,
interconnection of overflow pipe to existing manhole and pumping arrangement near
Mumfordganj Sewage Pumping Station in Municipal Corporation Prayagraj, District-
Prayagraj” are hereby invited from eligible, reputed and experienced bidder. E-bid documents
will be available for download from 22.0.2026 by 2:00 Hrs. Pre-bid meeting will be held on
dated 27.0.2026 at :30 AM in office of the Executive Engineer, Construction Division-I, UP
Jal Nigam (Urban), Prayagraj. E-bids can be submitted till 05.4.2026 up to 7:00 Hrs. and
technical bid shall be opened on 06..2026 at :00 Hrs. in office of the Executive Engineer,
Construction Division-I, U.P. Jal Nigam (Urban), Prayagraj in presence of contractor or their
authorized representative, E-tender Cost is (Rs.3000+ GST@8%) = Rs. 3540.00. Details are
available on U.P. Govt. e- procurement portal http://etender.up.nic.in & U P £ figam (Urban)
website http://www.jn. upsde.gov.in xa
(Ashutdsh Yadav)
Executive Engineer
Page 7 of 7
