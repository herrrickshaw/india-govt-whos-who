---
doc_id: "77fbb1f7cdad5af5"
source_url: "https://www.iitbhu.ac.in/contents/institute/admin/doc/admin_rpn_amendment_01072026.pdf"
ministry: "Indian Insttitute of Technology (BHU), Varanassi"
title: "III"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "2d05956d3358b0c5"
---

<!-- page 1 -->

( oe j) भारतीय ff “i INDIAN
(( @) ) sitehfrast | | | | || INSTITUTE OF
Nae संस्थान | | रा । fe TECHNOLOGY
SOR” काशी हिन्दू विश्वविद्यालय | a io Ee BANARAS HINDU UNIVERSITY
Email : administration@ithhu.ac.in, office.establishment@itbhuacin
“peat eae कार्यालय Office of the Registrar
(प्रशासन) (Administration)
No. |IT(BHU)/ADM/8/RR/Gen/2026-27/ 43 99 Dated: 0.07.2026
OFFICE MEMORANDUM
SUBJECT: AMENDMENTS IN THE RECRUITMENT AND PROMOTION NORMS, 2049
न This is for information to all concerned that the Board of Governors at its 240 meeting held on 2.05.2026 have approved
the following modifications in the Recruitment and Promotion Norms, 2049 of the Institute:
Ss. Category =e Modified हर approved by the 806
N.
हु 4. Change in | Level-6: Junior Hindi Translator Level-6: Junior Translation Officer
Nomenclature for | (कनिष्ठ हिन्दी अनुवादक) (कनिष्ठ अनुवादक अधिकारी)
Rajbhasha Cadre | | ०५४०-४8: Hindi Translator Level-8: Senior Translation Officer
(हिन्दी अनुवादक) (वरिष्ठ अनुवादक अधिकारी)
2. | Change in | In the recent 234 meeting of the BoG held on | Now, the work experience requirement for
Experience for 4 this post will be read as 'AND' instead of
i 6.04.2026, the work experience requirement | ,-/S के के
the post of Hindi for this post was categorized as per details ‘OR’, as per details below:
Officer (Level-0) below:
under the clause i “AND
of Educational नि 8 years’ experience of terminological work
and other | “OR in Hindi and translation work from English
qualifications 8 years’ experience of terminological work in | to Hindi or vice-versa, technical or
required for | Hindi and translation work from English to | scientific literature in pay level 6 or above
direct recruits Hindi or vice-versa, technical or scientific | or at least 5 years of relevant experience
literature in pay level 6 or above or at least 5 | in the Pay Matrix level 7 and above in a
years of relevant experience in the Pay Matrix feputed Educational Institute/ University
level 7 and above in a reputed Educational System/Research Institute/Central
Institute/. University System/Research | Government Departments”
Institute/Central Government Departments.”
3, Change in | Promotion: Bachelor's Degree/Diploma in | Promotion: All Junior Engineers,
experience for the | relevant discipline with at least 05 years (for | irrespective of degree or diploma
post of Assistant | Bachelor's degree holders) or 08 years’ (for | qualification, be considered eligible for
Engineer (Level | Diploma holders) of relevant post qualification | promotion to the post of Assistant
08) to be filled | experience as Junior Engineer. Engineer on completion of 05 years of
through fegular service in Pay Level-6 at the
Promotion. हि _ Institute. _
To, Ras
All the non-faculty employees (staff.all@itbhu.ac.in). 07.07 2026
REGISTRAR
a
Copy for information to: कुलसचिव
4... /७| the Deans/Associate Deans Regie
2. All the Professor In-charges. भारतीय संस्थान
3. All the Heads of the Departments/Coordinators of the Schools काशी हिन्दू विश्वविद्यालय)
4. The Coordinators/In-charge of Units/Centres/Offices Indian Instinute,ot Teche
5. The Chairman, Institute Works Department. (Banaras indu $I-227005
6. The Chairman, Council of Wardens वाराणसी /Varana |
7. The Chairman, Web Management & E-mail Services Committee (chai.wmes@iitbhu.ac.in) - with the request to
upload the same on the Institute Website.
8. PS to the Director
9. PA to the Registrar
0. Confidential Unit - for record.
le
