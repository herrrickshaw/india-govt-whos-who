---
doc_id: "ce618cecebc7cbcb"
source_url: "https://dpsup.up.gov.in/app/writereaddata/UploadGazette/corrigendum/pdf/C_202610301611225973.pdf"
ministry: "Directorate of Printing and Stationery, Uttar Pradesh"
title: "THE CENTRAL EXCISE (AMENDMENT) ACT, 2025  [ Gazette ]"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0dd3cf3134c5dfb7"
---

<!-- page 1 -->

Øe-la[;k&179 ¼'k 'k 'k½

jftLVªs'ku uaå&,lå,låihå@,yå&
MCywå@,uåihå@91@2014&16
ykblsUl Vw iksLV ,sV dUls'kuy jsV

—

¼dsUnzh; vf/kfu;e½
~
mRrj çns'k ljdkj
&&&&&&&&
la[;k 101 ¼izk0½-79-fo-2&2026
y[kuÅ] 22 ebZ] 2026
&&&&&&&&

vf/klwpuk

Hkkjr ljdkj] fof/k ,oa U;k; ea=ky; ¼fo/kk;h foHkkx½] ubZ fnYyh ls izkIr dsUæh; vf/kfu;e
"The Central Excise (Amendment) Act, 2025 ¼vf/kfu;e la0 34 o"kZ 2025½"A
MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 11th December, 2025/Agrahayana 20, 1947 (Saka)
The following Act of Parliament received the assent of the President on the
11th December, 2025 and is hereby published for general information:—
THE CENTRAL EXCISE (AMENDMENT) ACT, 2025
NO. 34 OF 2025
[11th December, 2025.]
AN Act further to amend the Central Excise Act, 1944.
BE it enacted by Parliament in the Seventy-sixth Year of the Republic of India
as follows:–
Short title and
1. (1) This Act may be called the Central Excise (Amendment) Act, 2025.
commencement.
(2) It shall come into force on such date as the Central Government may, by
notification in the Official Gazette, appoint.

397 RPH (Kendriya Adhyadesh) 2026 Data 1e

<!-- page 2 -->

mRrj çns'k vlk/kkj.k xtV] 22 ebZ] 2026

2

2. In the Central Excise Act, 1944, in the Fourth Schedule, in
Section IV, for the Table occurring under the sub-heading “Supplementary
Notes”, the following Table shall be substituted, namely:––

Amedment
of Fourth
Schedule.

‘Tariff item

Description of goods

(1)

Unit Rate of duty

(2)

(3)

(4)

2401

Unmanufactured Tobacco; Tobacco Refuse

2401 10

-

Tobacco, not stemmed or stripped:

2401 10 10

---

Flue cured virginia tobacco

kg.

70%

2401 10 20

---

Sun cured country (natu) tobacco

kg.

70%

2401 10 30

---

Sun cured virginia tobacco

kg.

70%

2401 10 40

---

Burley tobacco

kg.

70%

2401 10 50

---

Tobacco for manufacture of biris,
not stemmed

kg.

70%

2401 10 60

---

Tobacco for manufacture
chewing tobacco

of

kg.

70%

2401 10 70

--- Tobacco for manufacture of cigar
and cheroot

kg.

70%

2401 10 80

---

kg.

70%

2401 10 90

--- Other

kg.

70%

2401 20

-

Tobacco, partly or wholly stemmed or stripped :

2401 20 10

---

Flue cured virginia tobacco

kg.

70%

2401 20 20

---

Sun cured country (natu) tobacco

kg.

70%

2401 20 30

---

Sun cured virginia tobacco

kg.

70%

2401 20 40

---

Burley tobacco

kg.

70%

2401 20 50

---

Tobacco for manufacture of biris

kg.

70%

2401 20 60

---

Tobacco for manufacture
chewing tobacco

of

kg.

70%

2401 20 70

---

Tobacco for manufacture of cigar
and cheroot

kg.

70%

2401 20 80

---

Tobacco for manufacture
hookah tobacco

kg.

70%

2401 20 90

---

Other

kg.

70%

2401 30 00

-

Tobacco refuse

kg.

60%

Tobacco for manufacture of hookah
tobacco

of

2402

Cigars, cheroots, cigarillos and cigarettes, of tobacco or of
tobacco substitutes

2402 10

-

Cigars, cheroots and cigarillos, containing tobacco:

2402 10 10

---

Cigar and cheroots

Tu

25% or

Rs. 5000 per thousand
whichever is higher
397 RPH (Kendriya Adhyadesh) 2026 Data 1e

1 of 1944.

<!-- page 3 -->

mRrj çns'k vlk/kkj.k xtV] 22 ebZ] 2026
(1)

(2)

3

(3)

(4)

Tu

25% or
Rs. 5000 per
thousand
whichever
is higher

2402 10 20

--- Cigarillos

2402 20

--- Cigarettes, containing tobacco:

2402 20 10

--- Other than filter cigarettes, of length
not exceeding 65 millimetres

Tu

Rs. 2700 per
thousand

2402 20 20

--- Other than filter cigarettes, of length
exceeding 65 millimetres but not
exceeding 70 millimetres

Tu

Rs. 4500 per
thousand

2402 20 30

---

Filter cigarettes of length (including
the length of the filter, the length of
filter being 11 millimetres or its
actual length, whichever is more)
not exceeding 65 millimetres

Tu

Rs. 3000 per
thousand

2402 20 40

---

Filter cigarettes of length (including
the length of the filter, the length of
filter being 11 millimetres or its
actual length, whichever is more)
exceeding 65 millimetres but not
exceeding 70 millimetres

Tu

Rs. 5200 per
thousand

2402 20 50

---

Filter cigarettes of length (including
the length of the filter, the length of
filter being 11 millimetres or its
actual length, whichever is more)
exceeding 70 millimetres but not
exceeding 75 millimetres

Tu

Rs. 7000 per
thousand

2402 20 90

--- Other

Tu

Rs. 11000
per
thousand

2402 90

--- Other:

2402 90 10

--- Cigarettes of tobacco substitutes

Tu

Rs. 5000 per
thousand

2402 90 20

--- Cigarillos of tobacco substitutes

Tu

14% or
Rs. 5000 per
thousand
whichever
is higher

2402 90 90

--- Other

Tu

14% or
Rs. 5000 per
thousand
whichever
is higher

397 RPH (Kendriya Adhyadesh) 2026 Data 1e

<!-- page 4 -->

mRrj çns'k vlk/kkj.k xtV] 22 ebZ] 2026

4

(1)
2403

(2)
(3)
(4)
Other manufactured tobacco and manufactured tobacco
substitutes; “Homogenised” or “Reconstituted” tobacco;
Tobacco extracts and essences
--

2403 11

--

Smoking tobacco, whether or not
tobacco substitute in any proportion;

containing

Water pipe tobacco specified in Sub-heading Note to this

Chapter:
2403 11 10

---

Hookah or gudaku tobacco

kg.

40%

2403 11 90

---

Other

kg.

40%

2403 19

--

Other:

2403 19 10

---

Smoking mixtures for pipes and
cigarettes

kg.

325%

---

Biris:

2403 19 21

----

Other than paper rolled biris,
manufactured without the aid of
machine

Tu

10%

2403 19 29

----

Other

Tu

10%

2403 19 90

---

Other

kg.

22%

-

Other:

2403 91 00

--

“Homogenised” or “reconstituted”
tobacco

kg.

70%

2403 99

--

Other:

2403 99 10

---

Chewing tobacco

kg.

100%

2403 99 20

---

Preparations containing chewing
tobacco

kg.

100%

2403 99 30

---

Jarda scented tobacco

kg.

100%

2403 99 40

---

Snuff

kg.

70%

2403 99 50

---

Preparations containing snuff

kg.

70%

2403 99 60

---

Tobacco extracts and essence

kg.

70%

2403 99 70

---

Cut-tobacco

kg.

10%

2403 99 90

--Other
kg.
125%
Products containing tobacco, reconstituted tobacco,
nicotine, or tobacco or nicotine substitutes, intended for
inhalation without combustion; other nicotine
containing products intended for the intake of nicotine
into the human body

2404

-

Products intended for inhalation without combustion

397 RPH (Kendriya Adhyadesh) 2026 Data 1e

<!-- page 5 -->

mRrj çns'k vlk/kkj.k xtV] 22 ebZ] 2026
(1)

(2)

5

(3)

(4)

2404 11 00

--

Containing tobacco or reconstituted
tobacco

kg.

100%

2404 12 00

--

Other, containing nicotine

kg.

…..

2404 19 00

--

Other

kg.

100%

-

Other:

2404 91 00

--

For oral application

kg.

…..

2404 92 00

--

For transdermal application

kg.

…..

2404 99 00

--

Other

kg.

…..’.

DR. RAJIV MANI,
Secretary to the Govt. of India.
---------By order,
RAHUL DUBEY,
Vishesh Sachiv Evam Apar Vidhi Paramarshi.

ih0,l0;w0ih0&,0ih0 397 jkti=&2026&¼831½&599$46=645 izfr;ka ¼Mh0Vh0ih0@vkWQlsV½A
397 RPH (Kendriya Adhyadesh) 2026 Data 1e
