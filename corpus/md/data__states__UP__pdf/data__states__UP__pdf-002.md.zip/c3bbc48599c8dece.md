---
doc_id: "c3bbc48599c8dece"
source_url: "https://cdnbbsr.s3waas.gov.in/s325db67c5657914454081c6a18e93d6dd/uploads/2026/09/20260917840346059.pdf"
ministry: "Joint Entrance Examination Council (Polytechnic), Uttar Pradesh"
title: "Instructions for Pharmacy Counseling 2026"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "78f47d68d24d514e"
---

<!-- page 1 -->

la;qDr izos’k ijh{kk ifj”kn] m0iz0] y[kuÅ
la;qDr izos’k ijh{kk ¼ikyhVsfDud½&2026 dh QkesZlh ikB~;Øe dh dkmfUlfyax gsrq funsZ’k
la;qDr izos’k ijh{kk ¼ikyhVsfDud½&2026 dh ijh{kk ds ifj.kke ds vk/kkj ij vH;fFkZ;ksa dks laLFkk o ikB~;Øe
dk vkoaVu mudh esfjV] muds }kjk fn;s x;s fodYiksa o vkj{k.k ds vuqlkj vkuykbu dkmfUlfyax osclkbV
¼https://jeecup.admissions.nic.in½ ds ek/;e ls fd;k tk;sxkA vH;FkhZ eksckby u0 ,oa bZesy vkbZ0Mh0 dks
iwjh dkmfUlfyax vof/k esa fØ;k’khy j[ksaA lHkh egRoiw.kZ lwpuk,a ,oa vks0Vh0ih0 eksckby u0 ij Ásf”kr gksxhA
vH;fFkZ;ksa dh dkmfUlfyax lEcU/kh leLr vks0Vh0ih0] vkoaVu&i=] ikloMZ] ijh{kk ifj.kke bR;kfn lwpuk,a ,oa
vfHkys[k lans’k ,si ¼Sandes App½ ij Hkh miyC/k jgsaxsA ,sls vH;FkhZ tks fd LekVZ Qksu j[krs gSa] Hkkjr ljdkj
ds jk”Vªh; lwpuk foKku dsUnz }kjk fodflr bl ,si dks android mi;ksxdrkZ Google Playstore rFkk iOS
mi;ksxdrkZ App store ls MkmuyksM dj iz;ksx dj ldrs gSaA Nk=ksa dks ;g lykg nh tkrh gS fd dkmfUlfyax
gsrq fn;s x;s funsZ’kksa dh fÁUV dkWih ysdj iwjh rjg ls funsZ’kks dk v/;;u dj ysaA Áos’k i=] Ldksj dkMZ] jftLVªs’ku
QkeZ] lhV ,DlsIVsal ‘kqYd :0 3250@& ¼ftlesa :0 3000@& f’k{k.k ‘kqYd esa lek;ksftr fd;k tk;sxk rFkk
250@& dkmfUlfyax ‘kqYd ds :i esa ns; gksxk½ dh jlhn] lhV ,ykVesUV ysVj] MkD;wesUV osjhfQds’ku ysVj ,oa
,Mfe’ku ysVj dh ,d&,d Áfr vius ikl vyx ls lnSo lqjf{kr j[ksaA

dkmfUlfyax ds fy, vH;fFkZ;ksa gsrq lkekU; funsZ’k
1- lHkh izfØ;k,a fn;s x;s dkmfUlfyax f’kM~;wy ds vuqlkj lEikfnr gksaxhA dkmfUlfyax f’kM~;wy
https://jeecup.admissions.nic.in iksVZy ij miyC/k gSA d`i;k /;ku j[ksa fd lhV vkoaVu dkmfUlfyax
dh leLr izfØ;k vkuykbu lEikfnr gksuh gS] vr% fofHkUu izfØ;kvksa gsrq dkmfUlfyax f’kM~;wy esa fu/kkZfjr
frfFk ,oa le; dk fo’ks”k /;ku j[kk tk;sA
2- dkmfUlfyax izfØ;k fofHkUu 5 pj.kksa esa vkuykbu lEiUu dh tk;sxhA dkmfUlfyax dk dksbZ Hkh pj.k vkWQykbu
ugha gksxkA dkmfUlfyax pj.kksa dh la[;k fu;ked laLFkk ih0lh0vkbZ0 }kjk fu/kkZfjr vfUre frfFk ds
vuqlkj ?kVk;h vFkok c<+k;h tk ldrh gSA
3- vH;FkhZ ;g lqfuf’pr dj ysa fd dkmfUlfyax ds le; muds ikl U;wure ‘kSf{kd vgZrk dk izek.k&i=] oS/k
vkj{k.k Áek.k&i= ¼bZ0MCyw0,l0@vks0ch0lh0@,l0lh0@,l0Vh0½ ,oa vkj{k.k mioxZ izek.k&i=
¼fnO;kax@lSfud vkfJr@Lora=rk laxzke lsukuh vkfJr½ tks ykxw gks] uohure ewy:Ik esa miyC/k gksA MkD;wesUV
osjhfQds’ku esa ewy Áek.k i=ksa dh vko’;drk gksxhA
4- dkmfUlfyax esa lhV ,DlsIVsal ‘kqYd :0 3250@& ¼ftlesa :0 3000@& f’k{k.k ‘kqYd esa lek;ksftr fd;k
tk;sxk rFkk 250@& dkmfUlfyax ‘kqYd ds :i esa ns; gksxk½] vH;fFkZ;ksa ds ykWfxu esa miyC/k fyad ds ek/;e
ls vkuykbu gh tek gksxkA
5- jftLVsª’ku ds le; vH;FkhZ }kjk fdlh Hkh tuin ds lgk;rk dsUnz ij tkdj MkD;wesUV osjhfQds’ku dh izfØ;k
iw.kZ dh tk;sxhA bldk pquko vH;FkhZ viuh lqfo/kkuqlkj djsaA vfHkys[k lR;kiu ¼MkD;wesUV osjhfQds’ku½ ds
vfrfjDr vU; lHkh dkmfUlfyax lEcU/kh dk;Z vH;FkhZ lgk;rk dsUnz ij tkdj vFkok dgha ls Hkh
dEI;wVj@VSc@LekVZ Qksu dk mi;ksx dj iw.kZ dj ldrk gSA vH;FkÊ Pokbl fQfyax@iwN&rkN ;k dkmfUlfyax
ls lEcfUèkr fdlh Hkh vU; dk;Z ds fy, çns'k ds leLr tuinksa esa LFkkfir jktdh; ,oa vuqnkfur lgk;rk
dsUæksa ds ekè;e ls djk ldrs gSaA jkT; vgZrk ds lEcU/k esa osclkbV ij miyC/k fooj.k&iqfLrdk ij fn;s x;s
fooj.k dks vo’; i<+ ysaA mRrj izns’k jkT; dh vgZrk u j[kus okys vH;FkhZ prqFkZ pj.k ls dkmfUlfyax ds
fy, ik= gksaxsA
6- jftLVªs’ku] fodYi p;u ,oa lhV vkoaVu ds i’pkr lhV ,DlsIVsal ‘kqYd :0 3250@& ¼ftlesa :0 3000@&
f’k{k.k ‘kqYd esa lek;ksftr fd;k tk;sxk rFkk 250@& dkmfUlfyax ‘kqYd ds :i esa ns; gksxk½ fn;s x;s fodYiksa
;Fkk& usV cSfdax] MsfcV@ØsfMV dkMZ@;wihvkbZ ds ek/;e ls tek djuh gksxhA dkmfUlfyax Qhl fdlh Hkh
n’kk esa okil vFkok gLrkUrfjr ugha dh tk;sxhA
1

<!-- page 2 -->

7- vH;FkhZ Pokbl fQfyax ¼laLFkk ,oa ikB~;Øe fodYi dk p;u½ dk dk;Z ykWfxu vkbZ0Mh0 o ikloMZ dh lgk;rk ls
djsaxsA izR;sd vH;FkhZ dks mlds xqzi rFkk vkj{k.k oxZ ds vuqlkj laLFkk o ikB~;Øe ds fodYi fn[ksaxs] ftlesa og
vius ojh;rkØe ds vk/kkj ij fodYiksa dk p;u dj ldrk gSA p;u dk Øe Åij ls uhps dh vksj ojh;rk ds
vk/kkj ij ekuk tk;sxkA vH;FkhZ pqus x;s fodYiksa dks vius ojh;rkØe ds vuqlkj ifjofrZr dj ldsxkA fodYi
Hkjus dk dk;Z iw.kZ gksus ds mijkUr vH;FkhZ }kjk fodYiksa dh lwph dks vius ikloMZ }kjk ykWd fd;k tk;sxkA fodYi
ykWd djus ds mijkUr ml pj.k esa dksbZ Hkh fodYi cnys ugha tk ldrs gSaA
 dkmfUlfyax ds izR;sd pj.k esa vlhfer fodYi Hkjus dh lqfo/kk gksxhA Hkjs x;s fodYiksa dks vH;FkhZ
viuh lqfo/kkuqlkj ifjofrZr dj ldrk gSSA Hkjs x;s fodYiksa ds vk/kkj ij gh lhV vkoaVu fd;k
tk;sxkA
8- lhV vkoaVu &izR;sd pj.k esa fu/kkZfjr frfFk dks lhV vkoaVu gksxkA vH;fFkZ;ksa dk vkoaVu esfjV] laLFkk o ikB~;Øeksa
ds fodYiksa] vkj{k.k rFkk lhVksa dh miyC/krk ds vk/kkj ij fd;k tk;sxkA fdlh Hkh vH;FkhZ dks mlds }kjk p;fur
fodYiksa ds vk/kkj ij dsoy ,d lhV vkoafVr dh tk;sxhA lhV vkoaVu ds i’pkr vH;FkhZ dh ykWfxu vkbZ0Mh0
ij mldk vkoaVu&i= miyC/k gksxkA
9- Freeze vFkok Float fodYi dk p;u & izFke ,oa f}rh; pj.k esa lhV vkoaVu izkIr gksus ij vH;FkhZ dks vius
ykWfxu ls Freeze vFkok Float dk fodYi pquuk gksxkA
¼v½ Freeze fodYi & tks vH;FkhZ vkoafVr laLFkk@ikB~;Øe esa v/;;u ds bPNqd gksa mUgsa Freeze
fodYi dk p;u djuk gksxkA ;fn vH;FkhZ Freeze dk fodYi pqurk gS rks mls lhV ,DlsIVsal ‘kqYd
:0 3250@& ¼ftlesa :0 3000@& f’k{k.k ‘kqYd esa lek;ksftr fd;k tk;sxk rFkk 250@& dkmfUlfyax
‘kqYd ds :i esa ns; gksxk½ vkuykbu ek/;e ls tek djuk gksxkA ‘kqYd tek djus ds i'pkr mls vius
p;fur lgk;rk dsUnz@MkD;wesUV osjhfQds’ku lsUVj ij tkdj vius lHkh ewy vfHkys[kksa dk lR;kiu
djkuk gksxkA vfHkys[kksa ds lR;kiu ds ckn fu/kkZfjr frfFk ds vUnj vH;FkhZ dks vkoafVr laLFkk esa mifLFkr
gksdj vo’ks”k izos’k ‘kqYd izR;sd pj.k gsrq fu/kkZfjr frfFk ,oa le; rd tek djuk vko’;d gksxk]
vU;Fkk dh fLFkfr esa mldks vkoafVr lhV fujLr gks tk;sxhA r`rh; pj.k ds vkoaVu ds i'pkr lHkh
vH;FkhZ Lor% Freeze gks tk;saxsA
¼c½ Float fodYi & lhV vkoaVu izkIr vH;FkhZ ;fn vkoafVr laLFkk vFkok ikB~;Øe esa lq/kkj ds bPNqd
gSa rks ,slh fLFkfr esa mUgas Float fodYi dk p;u djuk gksxkA izFke ,oa f}rh; pj.k ds lhV vkoaVu
ds i'pkr ;fn vH;FkhZ Float dk fodYi pqudj fu/kkZfjr lhV ,DlsIVsal ‘kqYd :0 3250@& ¼ftlesa
:0 3000@& f’k{k.k ‘kqYd esa lek;ksftr fd;k tk;sxk rFkk 250@& dkmfUlfyax ‘kqYd ds :i esa ns;
gksxk½ vkuykbu ek/;e ls tek djrk gS rks og f}rh;@r`rh; pj.k ds fy, vgZ gks tk;sxkA ,sls vH;FkhZ
dks vkoafVr lhV rc rd lqjf{kr jgsxh tc rd fd mls dksbZ vU; lhV vkoafVr u gks tk;sA r`rh;
pj.k eas vkoafVr lhV Lor% Freeze ekuh tk;sxh rFkk vkoafVr laLFkk@ikB~;Øe esa izos’k ysuk vfuok;Z
gksxk] vU;Fkk vkoafVr lhV fujLr gks tk;sxh ,oa tek dh xbZ lhV ,DlsIVsal ‘kqYd dh jkf’k tCr dj
yh tk;sxhA
10- izFke ,oa f}rh; pj.k ds lhV vkoaVu ds i'pkr vH;FkhZ dks vius ykWfxu ls Freeze vFkok Float dk fodYi
pquuk vfuok;Z gksxkA Float / Freeze fodYi dk p;u u djus okys vFkok fodYi p;u ds i'pkr lhV
,DlsIVsal ‘kqYd (Seat Acceptance Fee) :0 3250@& u tek djus okys vFkok Freeze fodYi dk p;u
djus ds mijkUr vfHkys[k lR;kiu u djkus okys vH;FkhZ dkmfUlfyax ds r`rh; pj.k rd ds fy, izfØ;k ls ckgj
gks tk;saxsA r`rh; pj.k esa lhV vkoaVu ds i'pkr lHkh vH;FkhZ Freeze ekus tk;saxsA
11- prqFkZ pj.k esa lhV vkoaVu ikus okys vH;fFkZ;ksa ds fy, Freeze vFkok Float dk fodYi miyC/k jgsxk rFkk
vU; izfØ;k;sa fcUnq la[;k&09 ds vuqlkj gh dh tk;saxhA ;g izfØ;k iw.kZ u djus ij vH;FkhZ iape pj.k dh
dkmfUlfyax ,oa izos’k izfØ;k ls ckgj gks tk;sxkA
iape pj.k ds vkoaVu ds i'pkr lHkh vH;FkhZ Lor% Freeze gks tk;saxs rFkk mUgsa lhV ,DlsIVsal ‘kqYd
:0 3250@& ¼ftlesa :0 3000@& f’k{k.k ‘kqYd esa lek;ksftr fd;k tk;sxk rFkk 250@& dkmfUlfyax ‘kqYd
2

<!-- page 3 -->

ds :i esa ns; gksxk½ vkuykbu ek/;e ls tek djuk gksxkA ‘kqYd tek djus ds i'pkr mls vius p;fur
lgk;rk dsUnz@MkD;wesUV osjhfQds’ku lsUVj ij tkdj vius lHkh ewy vfHkys[kksa dk lR;kiu djkuk gksxkA
vfHkys[kksa ds lR;kiu ds rqjUr ckn vH;FkhZ dks vkoafVr laLFkk esa mifLFkr gksdj vo’ks”k izos’k ‘kqYd izR;sd
pj.k gsrq fu/kkZfjr frfFk ,oa le; rd tek djuk vko’;d gksxk] vU;Fkk dh fLFkfr esa mldks vkoafVr lhV
fujLr gks tk;sxhsA
‘kqYd u tek djus okys vH;fFkZ;ksa dh lhV fujLr gks tk;sxh rFkk ,sls vH;FkhZ bl o”kZ dh dkmfUlfyax
,oa izos’k izfØ;k gsrq ik= ugha jgsxkA
12- MkD;wesUV osjhfQds’ku &izFke pj.k ls iape pj.k rd vH;fFkZ;ksa dks lhV vkoaVu ds i'pkr vfHkys[kksa ds lR;kiu
ds fy, muds }kjk izns’k esa LFkkfir fdlh Hkh lgk;rk dsUnzkas ij fu/kkZfjr vof/k esa Lo;a lHkh ewy vfHkys[kksa rFkk
bldh Lo%izekf.kr Nk;kizfr rFkk nks QksVksxzkQ ds lkFk mifLFkr gksuk gksxkA jfookj ds fnuksa esa MkD;wesUV osjhfQds’ku
dk dk;Z lgk;rk dsUnzkas ij ugha fd;k tk;sxkA
MkD;wesUV osjhfQds’ku ds le; ;fn vH;FkhZ ds izek.k&i=ksa esa deh ik;h tkrh gS rks fuEu izdkj ds
fu;eksa ds vuqlkj lgk;rk dsUnz izHkkjh@dkmUlyj }kjk fu.kZ; fy;s tk;saxsA
1- ;fn deh bl izdkj dh gS] ftldk fujkdj.k lEHko ugha gS] ;Fkk&vH;FkhZ U;wure ‘kSf{kd ;ksX;rk ugha
j[krk gS@vH;FkhZ dh vk;q fnukad 01-07-2026 dks 14 o”kZ ls de gS] rks vH;FkhZ dks vkoafVr lhV fujLr
gks tk;sxh rFkk vH;FkhZ lEiw.kZ dkmfUlfyax izfØ;k ls bl o”kZ ds fy, ckgj gks tk;sxkA
2- ;fn deh bl rjg dh gS] ftlls vH;FkhZ dks vkoafVr lhV ij izHkko iM+rk gS ;fn vH;FkhZ dks fdlh
vkj{k.k oxZ ¼GEN EWS, OBC, SC, ST½@mioxZ ¼MP, FF, PH½@efgyk dksVs@m0iz0 jkT; ls lhV
vkoafVr gksrh gS] ijUrq vH;FkhZ ds ikl vkj{k.k ¼oxZ@mioxZ@jkT;½ dk izek.k&i= ugha gS rks mlds
vkj{k.k oxZ@mioxZ@ts.Mj @jkT; dks fuEukuqlkj vH;FkhZ dh fyf[kr lgefr ls iksVZy ij MkD;wesUV
osjhfQds’ku ds le; ifjofrZr dj fn;k tk;sxkA ,sls vH;FkhZ vxys pj.k dh dkmfUlfyax ds fy, ik=
gksxk] ijUrq vH;FkhZ dk vkoaVu ml pj.k esa fujLr dj fn;k tk;sxk rFkk mls vxys pj.k esa cnys gq,
vkj{k.k oxZ@mioxZ@ts.Mj@jkT; ds vuqlkj dkmfUlfyax gsrq vgZ ekuk tk;sxkA
SC/ST – MP/FF/PH
OBC-NCL – MP/FF/PH
GEN EWS – MP/FF/PH
GEN EWS – MP/FF/PH

SC/ST
OBC-NCL
GEN EWS

UNRESERVED
UNRESERVED
UNRESERVED
UNRESERVED

 lkekU; oxZ ls vkj{k.k oxZ esa ifjorZu ugha gks ldsxkA
 vukjf{kr mioxZ ls vkjf{kr mioxZ esa ifjorZu ugha gks ldsxkA
 vH;FkhZ ds ts.Mj esa dksbZ Hkh ifjorZu fd;k tk ldsxkA
 vU; jkT; ls mRrj izns’k jkT; esa ifjorZu ugha gks ldsxkA
 mRrj izns’k ls vU; jkT; esa ifjofrZr fd;s tkus ij vH;FkhZ dkmfUlfyax ds pj.k&1] 2 o 3
ls ckgj gks tk;sxk] ijUrq pj.k&4 ls iqu% vgZ gks tk;sxkA
MkD;wesUV osjhfQds’ku dh izfØ;k iw.kZ u djus okys vH;fFkZ;ksa dh lhV fujLr gks tk;sxh rFkk ,sls vH;FkhZ
dkmfUlfyax ,oa izos’k izfØ;k gsrq ik= ugha jgsxkA vH;FkhZ }kjk tek fd;k x;k lhV ,DlsIVsal ‘kqYd :0
3250@& fujLr ekuk tk;sxk rFkk fdlh Hkh n’kk esa vH;FkhZ dks okil ugha gksxkA ,sls vH;FkhZ ;fn fo’ks”k
dkmfUlfyax esa izfrHkkx djrs gSa rks mUgsa lhV ,DlsIVsal ‘kqYd :0 3250@& iqu% tek djuk gksxkA
13- izos’k ‘kqYd & lhV vkoaVu ,oa fodYi p;u ds i'pkr vH;FkhZ fu/kkZfjr lhV ,DlsIVsal ‘kqYd :0 3250@& ¼ftlesa
:0 3000@& f’k{k.k ‘kqYd esa lek;ksftr fd;k tk;sxk rFkk 250@& dkmfUlfyax ‘kqYd ds :i esa ns; gksxk½
vkuykbu ek/;e ls tek djsaxsA vfHkys[k ijh{k.k ds i’pkr vo‘ks”k ‘kqYd vkoafVr laLFkk esa mifLFkr gksdj tek
djuk gksxkA fofHkUu laLFkkvksa gsrq fu/kkZfjr ‘kqYd dk fooj.k m0iz0 izos’k ,oa Qhl fu;eu lfefr dh osclbV
www.afrcup2018.in ij iznf’kZr gSA
;fn fdlh laLFkk }kjk l{ke Lrj ls fu/kkZfjr ‘kqYd ds vfrfjDr fdlh /kujkf’k dh ekax dh tkrh gS
rks vH;FkhZ izR;sd tuin ds jktdh; ,oa vuqnkfur ikyhVsfDud laLFkk esa LFkkfir lgk;rk dsUnz vFkok la;qDr
3

<!-- page 4 -->

izos’k ijh{kk ifj”kn ds y[kuÅ fLFkr dk;kZy; esa mifLFkr gksdj vf/kd ‘kqYd dh ekax djus okyh laLFkk dh
fyf[kr f’kdk;r djrs gq, ml laLFkk esa izos’k gsrq fu/kkZfjr ‘kqYd tek dj izos’k ys ldrk gSA
14- izksohtuy ,Mfe’ku ysVj &‘kqYd tek djus ds i'pkr viuk izksohtuy ,Mfe’ku ysVj MkmuyksM dj vius ikl
lqjf{kr j[ksaxsA vH;fFkZ;ksa dk vkuykbu izos’k iw.kZr;k vLFkk;h gSA izosf’kr laLFkk esa vH;FkhZ fu/kkZfjr vfUre frfFk ls
iwoZ mifLFkr gksaxsA laLFkk esa ewy vfHkys[kksa dh iqu% tkap gksxhA ;fn dksbZ vH;FkhZ vik= ik;k tkrk gS rks laLFkk esa
mldk izos’k fujLr dj fn;k tk;sxkA vH;FkhZ ds }kjk ijh{kk ‘kqYd] chek ‘kqYd] Nk=kokl ‘kqYd rFkk vU; ‘kqYd
tek djuk gksxkA
15- Withdrawal from counseling process: ;fn dksbZ vH;FkhZ o”kZ&2026&27 esa izos’k ysus dk bPNqd
ugha gS rks vH;FkhZ dkmfUlfyax ds vfUre pj.k ls iwoZ ds pj.k rd vkoafVr lhV dks [kkyh djrs gq, tek fd;k
x;k lhV ,DlsIVsal ‘kqYd :0 3000@& okil ys ldrk gSA bl fodYi dk p;u djus ds mijkUr vH;FkhZ bl
‘kSf{kd l= esa izos’k ysus ls iw.kZr;k oafpr gksxk ,oa fdlh Hkh n’kk esa dkmfUlfyax izfØ;k esa iqu% lfEefyr ugha gks
ldsxkA vr% mfpr gksxk fd vH;FkhZ bl fodYi ds p;u ls iwoZ Hkyh&Hkk¡fr fopkj djrs gq, fu.kZ; ysA
¼v½ ‘kqYd dh okilh vH;FkhZ@vfHkHkkod ds cSad [kkrs esa gh dh tk;sxhA vU; fdlh [kkrs esa ‘kqYd okilh
lEHko ugha gks ldsxhA
¼c½ bl izfØ;k gsrq vH;FkhZ vius ykWfxu ls fyad ij tkdj viuk Lo;a@vfHkHkkod dk cSad fooj.k ;Fkk&
[kkrk la[;k] vkbZ0,Q0,l0 dksM] cSad ,oa ‘kk[kk dk uke HkjsaxsA tek fd;s x;s lhV ,DlsIVsUl Qhl
¼:0 3000@&½ ‘kqYd dh okilh blh cSad [kkrs esa dh tk;sxhA
‘kqYd okilh dh izfØ;k o”kZ&2026 dh dkmfUlfyax izfØ;k dh lekfIr ds i'pkr dh tk;sxhA

izos’k ‘kqYd& dkmfUlfyax }kjk vkoafVr vH;FkhZ MkD;wesUV osjhfQds’ku ds i'pkr vius laLFkk esa tkdj
vo’ks”k izos’k ‘kqYd tek djsaxsA jktdh;] vuqnkfur] ih0ih0ih0 ,oa futh ikyhVsfDud laLFkkvksa
esa vkoaVu izkIr djus okys vH;FkhZ vius ykWfxu esa miyC/k fyad ds ek/;e ls lhV ,DlsIVsal
‘kqYd :0 3250@& ¼ftlesa :0 3000@& f’k{k.k ‘kqYd esa lek;ksftr fd;k tk;sxk rFkk
250@& dkmfUlfyax ‘kqYd ds :i esa ns; gksxk½ vkuykbu tek djsaxs rFkk ‘ks”k ‘kqYd laLFkk
esa izos’k dh vkSipkfjdrk iw.kZ djrs le; tek fd;k tk;sxkA

uksV % laLFkkvksa esa miyC/k Nk=kokl ,oa laLFkk lEcU/kh fofHkUu fooj.kksa gsrq d`i;k lEcfU/kr laLFkk dh osclkbV
dk voyksdu dj lEcfU/kr laLFkk esa lEidZ djsaA vH;FkhZ viuh leL;kvksa ds fujkdj.k gsrq fuEukuqlkj
lEidZ dj ldrs gSa %&
nwjHkk”k% 0522&2630667] 2630106] 2630695] 2636589
bZesy% jeecuphelp@gmail.com

4
