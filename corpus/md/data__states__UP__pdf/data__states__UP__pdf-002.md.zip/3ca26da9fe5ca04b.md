---
doc_id: "3ca26da9fe5ca04b"
source_url: "https://jn.upsdc.gov.in/site/writereaddata/UploadTender/pdf/C_202610051455092411.pdf"
ministry: "Uttar Pradesh Jal Nigam (Urban), Uttar Pradesh"
title: "Supply, Installation, Testing & Commissioning of 01 No. 400 KVA CPCB IV+ Silent DG Set with AMF Panel at 15 MLD STP Jharkhandi Mahadev, Gorakhpur."
date: ""
pages: 6
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "5d74ac31d4a03323"
---

<!-- page 1 -->

RRS eo Email ID: pm4emgkp@gmail.com
i é कै Office of the Executive Engineer,
eae Construction Division (E/M), U.P. Jal Nigam (Urban),
a7 30 MLD STP Campus, Gorakhpur
'':'— — sdWg #6 eee ee ५ ५ ५ ५ ५ ७५७५७ ७
Letter No: पाउठय / छा8. / 04 Date: 29/ 09 /2026
SHORT TERM NOTICE FOR INVITATION OF E-TENDERS (NIT) INVITATION OF E-TENDERS (NI
On behalf of the Chairman, U.P. Jal Nigam (Urban) online e-tenders on percentage rate basis in Two
bid system for following works by Major Replacement Fund under One City One Operator Programme is
hereby invited from the reputed contractors/ Authorized vendor of manufacturers/ Manufacturers having
Tequisite work experience & financial capabilities. The bidders should submit their bids only if they consider
themselves eligible and are in possession of all the requisite documents.
“Name of work & Location | Estimate | Earnest |Cost of bid] Period of |Last date &| Time, Date &
dcost of | Money | document| completion | time of | Place of
work (Rs. In Submission| opening of
put to Lacs) of bid as | technical bids
bid in specified in
Lacs the bid
(excludi documents
ng
GS
7 22.0.2026 at
Supply, Installation, Testing} Rs. 5:00 Hrs
& Commissioning of 0 No Rs. 5000.00 Up to in Office of
400 KVA CPCB IV+ Silent] Rs.40.00] 9.39 | “443% | 3 Months |” Sy non लक,
DG Set with AMF एश्ञाल 8 |... ७ | pas | Gs c || ase Gees
5 MLD STP Jharkhandi =5900.00 (Urban),
Mahadev, Gorakhpur Gorakhpur.
The Bid document may be downloaded from "https://etenderup.nic.in" w.e.f. 03. 0.2026 at 2:00 hrs.
l. The Bid should be valid for 90 days from the last date of submission of bids,
2. If the date of opening of technical bid happens to be a holiday, the bid shall be opened on the next
working day at the same time for which no separate communication shall be sent.
3. Bidders having criminal record will not be allowed to participate in Bid process. हु :
4. A person registered with any State Bar Council will not be eligible to participate in the Bid.
5. As per Government norms GST at Applicable rate will be paid extra.
6. Eligibility:-
(a) Experience :
TT ८ who inter alia fulfill the following requirements shall be eligible to apply.
I | Invitation of e-Tenders for Gorakhpur.
& Scanned with OKEN Scanner

<!-- page 2 -->

| Firm should have successfully completed similar works (Similar work means: Supply,
a Installation, Testing & Comm) issioning of DG Set considered for bidder qualification) mentioned
| below for Govt/PSU Organization during last Ten years as on date of publication of NIT, Satisfying
followings:- |
The bidder may submit additional experience certificates to qualify in above particular condition - |
category individually if certificates submitted to fulfil financial criteria do not contain the category wise |
qualifying conditions. |
—— Three similar work completed of successfully Supply, Installation, Testing & Commissioning of DG
set for Govt/PSU organizations not less than the amount equal to 30% of estimated cost put to tender
(ie. Rs. 2.00 lacs).
or,
ii) Two similar work completed of successfully Supply, Installation, Testing & Commissioning of DG
set for Govt./PSU organizations not less than the amount equal to 40% of estimated cost put to tender
| (ie. Rs. 6.00 lacs).
or,
| Gi) One similar work completed of successfully Supply, Installation, Testing & Commissioning of DG
set for Govt/PSU organizations not less than the amount equal to 60% of estimated cost put to tender
| (i.e. Rs. 24.00 lacs).
| Special Condition:
|
| ‘The experience must include the works of minimum 2/3rd capacity of maximum capacity proposed in
| scope of work/BOQ.
| Note:- Capacity shall be in terms of HP. in the case of pumping plants and in terms of KVA in the case of
| sub-station/Voltage Stabilizer/Generating Set.
| The Certificate should be certified by an officer not below the rank of Executive Engineer or equivalent. All
| the performance certificates submitted should be clear and exhaustive enough to establish similarity with
| the work under Bid. Ambiguous Performance Certificates will not be considered for evaluation.
| The Experience in foreign countries of a subsidiary or parent company will also be considered for
। qualification. In case the company is not registered in India, the experience has to be certified by the
| respective Embassy office/Apostille (in case of members of Hauge Apostille Convention).
|
। Turn Over :-
| (b) Average annual financial turnover during the immediate last three consecutive financial years on
| construction works should be at least 30% of the project cost put to tender i.e. Rs. 2.0 Lacs.
| (c) The Firm should have positive net worth in the immediate last financial year and same should be certified
| by Statutory Auditor.
(d) The value of turnover on construction works / Value of experience shall be brought to current costing level
by enhancing the actual values @7% per year calculated from the date of completion to the date of
publication of NIT. A typical index is given below.
| Financial Year Escalation/ Enhance factor
Year | !,00
Year 2 ,07
Year 3 4
Year 4 .2]
Year 5 ,28
(e) Solvency :- : a
Solvency Certificate of minimum 40% of the tender value will be required to be submitted.
o Solvency Certificate issued by any Scheduled Commercial Bank shall be accepted, which will be valid
for a period of one year from the date of issue unless otherwise mentioned. (२५५
TT inition ofTendeas in Gos 7 — दमकल जम का कक क सनक स बम नक कक म नली. >+वविया मल
| 2 T Invitation of e-Tenders for Gorakhpur.
GE Scanned with OKEN Scanner

<!-- page 3 -->

or
© Solvency Certificate issued by District Magistrate will also be accepted, which will have a
validity of one year from date of issue unless otherwise mentioned.

7. This NIT and other information/corrigenda/addenda and Instruction for bidders posted on website
shall form part of bid document.

8. The quantities given in the bill of quantities are estimated and provisional, and are given to provide a
common basis for bidding. These are liable to change up to any extent for which no claim except 85 |
provided under contract shall be admitted.

9 The bid document consisting of Technical (eligibility) bid & financial bids including specifications, |
the bills of quantities of various types of items to be executed and the set of terms and conditions of
the contract to be complied with and other necessary document are available on “https://e-
tender.up.nic.in".

l0. The technical bid shall be opened first on due date and time as mentioned above. The time and date
of opening of financial bid of contractors, qualifying the technical bid shall be communicated to
them on a later date through portal.

ll, If the Bidder feels that technical credentials of his own or other Bidders have been wrongly
evaluated/verified, he may raise objections within 2 (two) working days from the date of uploading
of result. No request/objections shall be entertained beyond above limit, else it may be treated as an
obstruction in tender process and shall be dealt with accordingly.

2. U.P. Jal Nigam (Urban) reserves the right to reject any prospective application or to cancel entire bid
process without assigning any reason whatsoever.

3, E-tender document fee is non-refundable. It shall be deposited in the account of Executive
Engineer, Construction Division(E&M), UP Jal Nigam (Urban), Gorakhpur. only by
RTGS/NEFT in Panjab National Bank, Vikas Bhawan, Gorakhpur A/c No. 66700000023466,
IFSC Code — PUNB0475500.

4. Earnest Money:

a. EMD will be 2% for works up to Rs 5.00 Cr. and !% or Rs 0.00 Lac whichever is higher for works

above 5.00 Cr.

b. EMD up to Rs 20.00 Lac may be paid through RTGS or in the form of FDR/Bank Guarantee issued
by any scheduled commercial Bank. .

५. EMD above Rs 20,00 Lac should be in the form of RTGS/Bank Guarantee issued by any scheduled
commercial Bank.

d. Validity of BG will be at least 35 days beyond the validity of Tender.

e. The component of earnest money shall be deposited in the account of Executive Engineer,
Construction Division(E&M), UP Jal Nigam (Urban), Gorakhpur only by RTGS/NEFT in
Panjab National Bank, Vikas Nagar, Gorakhpur A/c No. 66700000023466, IFSC Code —
PUNB0475500.

f. The bidder shall deposit tender fees and earnest money separately in account mentioned as above.
Further he shall upload digitally signed copies of original receipts of bank showing clearly the above
details and/or the Bank Guarantee.

g In case EMD is submitted in the form of Bank Guarantee, bidder should ensure that such Original
Bank Guarantee is mandatorily deposited in the office of undersigned on the day of scheduled
date (during office hours) of opening of Technical Bid, either in person or by speed post, The
liability for timely submission shall lie with the Bidder, U.P. Jal Nigam (Urban) shall not be
responsible for delay on account of any reason whatsoever.

h, — Subject to limit as described in foregoing para, EMD may also be submitted in the form of
CDR/FDR issued by a scheduled commercial Bank and duly pledged in the favour of tender inviting
authority, unless otherwise mentioned Jt is made clear that Tender Fee and Earnest Money
deposited in any other form besides as mentioned above sub-paras shall render the bid non-
responsive, .

i, In case of JV the EMD should be in the name/ from the account of JV or lead partner as specified in
the JV agreement.

5. All the Bank Guarantees submitted towards EMD/Performance Security/Additional Performance
Security should be verifiable and encashable from a branch situated in a city where the office of
Divisional Officer is located.

“ST itavitation ofe-Tenders ३ T Invitation of e-Tenders for Gorakhpur.
GE scanned with OKEN Scanner

<!-- page 4 -->

6... & the documents as specified in the technical bid/eligibility bid document should be uploaded
within the period of bid submission. U.P. Jal Nigam (Urban) will not be liable for
incomplete/inaccurate / non-submission of bid for any reason whatsoever including technical
Teasons. It is made clear that separate submission of originals of any documents (except Bank
Guarantee) other than scanning and uploading them, are not required, unless called for, after
opening of financial bid.

7, The bid submission shall become invalid if:

@) The bidder is found ineligible.

Gi) The bidder does not upload all the documents as stipulated in the bid document.

(ii) If any discrepancy is noticed between uploaded documents and originals/hard copies
submitted later.

(iv) _ If subsequent to due date of submission of bid and/or after its submission bidder makes any
further communication/ representation with regard to the bid (whether technical or financial)
than otherwise called for by the undersigned as a clarification.

(v) Ifa bidder does not quote any percentage above/below on the total amount of the tender or
any section/sub head in percentage rate tender. Further the tender will not be considered as
lowest bid.

(vi) Conditional tenders or tenders without e-tender document fee & earnest money or invalid
eamest money shall be summarily rejected.

8. Additional Security/ Performance Security:

All tenders/ contracts issued/concluded the performance guarantee @0% of the contract
cost will have to be submitted at the time of signing the contract in the form of FDR/ Bank Guarantee
from any scheduled commercial Bank Guarantee from any scheduled commercial Bank, alternatively
on request of the contractor/firm, 5% of the performance Guarantee will be accepted at the time of
signing of contract and rest 5% may be deducted from the initial running bill in a single deduction or
at the rate of minimum 0% of the gross bill amount of running bill. However, in any case whole
amount of balance performance guarantee shall be deducted within one year.

Works for which the cost of the tender received is below the estimated cost of works,
additional performance security to be deposited by the firm shall be at following rates :-

a) Upto 0% below the estimated cost of works- Nil

b) Beyond 0% below - @ 0.5% for each .00% quoted below.

9. Intending Bidders are advised to inspect and examine the site and its surroundings and satisfy
themselves before submitting their bids as to the nature of the ground and sub-soil (so far as
practicable), the form and nature of the site, the means of access to the site, the accommodation they
may require and in general shall themselves obtain all necessary information as to risks,
contingencies and other circumstance which may influence or affect their bid. A bidder shall be
deemed to have full knowledge of the site, whether he inspects it or not, and no extra charge
consequent to any misunderstanding or otherwise shall be allowed. The bidder shall be responsible
for arranging and maintaining at his own cost all materials, tools & plans, water, electricity access,
faculties for workers and all others services required for executing the work unless otherwise ही
specifically provided for in the contract documents. Submission of a bid by a bidder implies that he
has read this notice and all other contract documents and has made himself aware of the instructions,
scope and specifications of the work to be done and local conditions and other factors having a
bearing on the execution of the work. हु

20. Canvassing whether directly or indirectly, in connection with bids is strictly prohibited and the bids
submitted by the bidders who resort to canvassing will be liable for rejection &will be debarred from
future tender in U. P. Jal Nigam(Urban).

2l. The available bid capacity of the bidder at the expected time of bidding shall be more than the total
estimated cost of the work for which the tender is invited.

The available bid capacity shall be assessed using following formula:-

Assessed Available Bid Capacity =2x AxN - छे

Where

A= Maximum tumover during the last five financial year ( corrected to the current level of value )

N= Stipulated period of execution of the work for which the tender is invited in years .

B= value of existing commitments to be completed during the execution period of bid .

The turnover shall be corrected to the current level of value by multiplying with the updation factor

given elsewhere with NIT/ bid documents.

22. The bidder shall not be permitted to bid for works under supervisory control of Superintending
Engineer and Executive Engineer concemed who is responsible for execution of work, in which his

_ sii, Sa T Invitation of e-Tenders for Gorakhpur.
GE Scanned with OKEN Scanner

<!-- page 5 -->

near relative is posted, He shall also intimate the names of persons who are working with him in any |
capacity or are subsequently employed by him and who are near relatives to any officer in the U.P. |
Jal Nigam (Urban), Any breach of this condition by the contractor would render him, if empanelled |
with U.P. Jal Nigam (Urban), liable to be removed from the approved list of contractors of U.P. Jal |
‘Nigam (Urban) and make him liable for black listing. |
23. No Engineer or other Gazetted Officer employed in Engineering or Administrative duties in an
Engineering U.P. Jal Nigam (Urban) of the State Government/State U.P. Jal Nigam (Urban)
Undertaking is allowed to work as a contractor for a period of two years after his retirement from
Government service, without the prior permission of the Government of U.P. in writing. This
contract is liable to be cancelled if either the contractor or any of his employees is found any time to
be such a person who had not obtained the permission of the Government of U.P. as aforesaid before
submission of the bid or engagement in the contractor's service.
(Vivek Kushwaha)
Executive Engineer
Endt. No i / Dated: -
Copy to the following for information and necessary action please: -
l. Chief Engineer (Gorakhpur. Zone), U.P. Jal Nigam (Urban) Gorakhpur.
2. Chief Engineer (E/M), U.P. Jal Nigam (Urban) Lucknow.
3. Superintending Engineer, Construction Circle(E/M), U.P. Jal Nigam (Urban), Lucknow.
4, Superintending Engineer, Construction Circle, U.P. Jal Nigam (Urban), Gorakhpur
5. PRO, 6-Rana Pratap Marg, U.P. Jal Nigam (Urban), Lucknow with a request for uploading the tender
notice at U.P. Jal Nigam (Urban) website & tender notice to publication in at least two Hindi/English
National News papers.
6. Executive Engineer, EDP Cell, U.P. Jal Nigam (Urban), Lucknow with a request to get the tender
notice placed, at U.P. Jal Nigam website.
7. Executive Engineer, Construction Division U.P. Jal Nigam (Urban), Gorakhpur.
8. M/s Toshiba Water Solution Pvt. Ltd, Gurugram.
9. Notice Board.
(es
wn
Execut gineer
SJ invitation ofe-Tenders forGorakhpu. —=~C*~“‘S*~*~*<“‘“‘< 3D T Invitation of e-Tenders for Gorakhpur.
GE Scanned with OKEN Scanner

<!-- page 6 -->

tian, Email ID: pmdemgkp@gmail.com
हर oe, se SN E . ५
ie é Yon Office of the Executive Engineer,
x a. j' Construction Division (E/M), U.P. Jal Nigam (Urban),
a 30 MLD STP Campus, Gorakhpur
Letter No: 737 / ि->ा8 / 04 Date: 29/ 09 /2026
Short Term E-Tender Notice
On behalf of the Chairman, U.P. Jal Nigam(Urban) E-bids are invited for
execution of “Supply, Installation, Testing & Commissioning of 0l No 400 KVA
CPCB IV+ Silent DG Set with AMF Panel at 5 MLD STP Jharkhandi Mahadev,
Gorakhpur by Major Replacement Fund under One City One Operator
Programme in Distt. Gorakhpur,” in two bid system on the basis of percentage rate
from eligible, reputed and experienced bidder. E-bid documents will be available on
U.P. Govt. e-procurement portal http://etender.up.nic.in & UPJN website
www.jn.upsde.gov.in for download from 03.0.2026 by 42:00 Hrs. E-bids can be
submitted till 2.0.2026 up to 7:00 Hrs. and technical bid shall be opened on
22.0.2026 at 5:00 Hrs. in the Office of the Executive Engineer, Construction
Division(E/M), U.P. Jal Nigam (Urban), Gorakhpur in presence of contractor or their
authorized representatives, E-tender Cost is Rs 5000.00+GST@8% for tender. Details
are available on U.P. Govt. e-procurement portal http://etender.up.nic.in & UPJN
website www.jn.upsdc.gov.in.
| हे
of
ave ushwaha)
Executive Engineer
या गा Tends ev Goaiipas आ जा.
6 T Invitation of e-Tenders for Gorakhpur.
GE Scanned with OKEN Scanner
