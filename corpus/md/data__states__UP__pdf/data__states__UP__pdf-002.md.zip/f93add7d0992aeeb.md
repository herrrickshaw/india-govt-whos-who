---
doc_id: "f93add7d0992aeeb"
source_url: "https://cdnbbsr.s3waas.gov.in/s332e05616c8ed659463f9af00b142dd6f/uploads/2026/07/202607131571573022.pdf"
ministry: "Harcourt Butler Technical University, Admission and eCounselling Services"
title: "Updated Guidelines of B.Tech , B.Tech Bio-Tcch . & B. Pharm. (Lateral Entry)"
date: ""
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "666510e00f993c7f"
---

<!-- page 1 -->

GUIDELINES
FOR ADMISSION TO VARIOUS PROGRAMS (LATERAL ENTRY) IN 2ND YEAR
AT HBTU, KANPUR FOR SESSION: 2026-27
LATERAL ENTRY PROGRAMS/ COURSES:
B.TECH. (ENGINEERING/TECHNOLOGY), B. TECH. (BIOTECHNOLOGY) & B.PHARM.

1.

Applications for admission to Lateral Entry programs of B.Tech. (Engineering/
Technology), B.Tech. (Biotechnology) & B. Pharm. for supernumerary seats in 2nd year at
HBTU, Kanpur are invited for the academic session: 2026-27.

2.

Candidates are advised to read the guideline CAREFULLY. Check the eligibility and
applicable reservation category etc. before filling and submitting the Online Registration Form
using link available at the website: https://hbtu.admissions.nic.in. or www.hbtu.ac.in (Note:
Detailed counseling procedure is explained at point number 14).

3.

Admissions will be made on the basis of Merit of Combined University Entrance Test (UG)2026 [CUET (UG)-2026]. In addition the candidate must possess the requisite Academic
Eligibility as described below. (Please check the course wise subject list required for
admission)
Programs/ Courses
for Lateral Entry [LE]
Admission: 2026-27

Subject type for
CUET(UG)-2026

B.Tech.
(Engineering/Technology)

Domain specific

B.Tech. Biotechnology

General Aptitude Test
Candidates has to secure
score in any one of the
subjects

1

Name of the subject (code)
-Mathematics (Sub. Code: 319)
OR
-Computer Science/Informatics Practices
(Sub. Code: 308)
-General Test (Sub. Code: 501)
-Biology/Biological
Studies/Biotechnology/Biochemistry
(Sub. Code: 304)
OR
-Chemistry (Sub Code: 306)
OR
-Mathematics/Applied Mathematics (Sub.
Code: 319)
OR
-Physics (Sub. Code: 322)

<!-- page 2 -->

B. Pharm.

4.

Candidate has to secure
score in any one of the
subjects

-Biology/Biological
Studies/Biotechnology/Biochemistry
(Sub. Code: 304)
OR
-Chemistry (Sub Code: 306)
OR
-Mathematics/Applied Mathematics (Sub.
Code: 319)
OR
-Physics (Sub. Code: 322)

The University shall conduct its own counselling on the basis of merit of CUET (UG)-2026 with
following Academic Eligibility:
For B.Tech. (Engineering/ Technology)
(a) Candidates must have passed three years Engineering Diploma from an Institution located
in U.P. and recognized by the Board of Technical Education, U.P. with minimum 55%
marks (50% for SC/ST/OBC-NCL / Persons with Disability (PwD) candidates) in any
branch of Engineering (except Agriculture Engg., Pharmacy and Architecture).
OR
*(b) Candidates passed BSc Degree from recognized University by UGC with minimum 55%
marks (50% for SC/ST/OBC-NCL / Persons with Disability (PwD) and passed 10+2
examination with Mathematics as subject.
*(Students belonging to BSc stream shall be considered only after filling the supernumerary seats in
this category with students belonging to Diploma stream)

(c) Candidates with criteria (a) or (b) and fulfill the domicile requirement (mentioned under
point 6 of the guidelines), are eligible for admission to Second year B.Tech. in any branch
of Engineering /Technology.
For B.Tech. (Biotechnology)
(a) Candidates must have passed three years Engineering Diploma from an Institution located
in U.P. and recognized by the Board of Technical Education, U.P. with minimum 55%
marks (50% for SC/ST/OBC-NCL / Persons with Disability (PwD) candidates) in any
branch.
OR
*(b) Candidates passed *BSc Degree from recognized University by UGC with minimum
55% marks (50% for SC/ST/OBC-NCL / Persons with Disability (PwD) and passed 10+2
examination with Mathematics/Biology as subject.
*(Students belonging to BSc stream shall be considered only after filling the supernumerary seats in
this category with students belonging to Diploma stream)

(c) Candidates with criteria (a) or (b) and fulfill the domicile requirement (mentioned under
point 6 of the guidelines), are eligible for admission to Second year B.Tech.
Biotechnology course.
2

<!-- page 3 -->

For B. Pharm. Course
a. Candidate passed D. Pharm. from an Institution approved u/s 12 of the Pharmacy Act with
minimum 55% (50% for SC/ST/OBC-NCL / Persons with Disability (PwD) aggregate).
b. Candidates with criteria (a) and fulfill the domicile requirement (mentioned under point 6
of the guidelines), are eligible for admission to Second year B. Pharm course.
Important note: All candidates whose Qualifying Examination result is not declared kindly
refer to point 11 of this guideline
5.

In case, Board / University awards only letter grades for qualifying examination without
providing an equivalent percentage of marks, the candidate should obtain a certificate from the
Board / University specifying equivalent marks before the scheduled ONLINE Document
Verification. In case, such a certificate is not available with the candidate, the decision of the
Admission Committee regarding his / her eligibility shall be final.

6.

Domicile requirements:
(a) A candidate who has passed the qualifying examination from Institution located in U.P. is
eligible for counselling and will be treated domicile of Uttar Pradesh.(no requirement of
Domicile certificate)
(b) In case, the candidate has passed qualifying examination from outside U.P., he / she has to
upload Permanent Residence Certificate (issued after 1st April 2026) of his / her parent
(Father or Mother). [Please refer to certificate no.3]
(c) Candidates who are wards of Defense Personnel settled or posted in UP on the date of
Entrance Examination of CUET (UG)-2026 or Officers /Employees of All India Services
belonging to UP Cadre are also eligible. They are required to upload Certificate No. 10 to claim
the benefit.

7.

Accepting admission in HBTU Kanpur implies the acceptance by the candidate and his / her
parents or guardians of all the terms and conditions laid down by the University. Any change in
the rules, regulations, fee and other specific conditions etc. of the University shall apply mutatis
mutandis to the admitted candidates.

8.

Candidates claiming advantage of reserved categories, subcategories are required to indicate the
same in the Online Registration Form.

9.

Candidates if allotted seat will have to participate in the ONLINE document verification with all
relevant documents and have to deposit of Full Academic Fee/ Partial Academic Fee (for Float
option).

10. Formats for various certificates to be submitted are enclosed with this guideline and are available
on the HBTU, Kanpur website (www.hbtu.ac.in). These formats are subject to change as per the
orders of Government of Uttar Pradesh. Note that the certificate for OBC candidates will be
entertained only if it is issued on or after 01.04.2026 (mandatory condition for non-creamy
layer OBC candidates).
11. The candidates for whom the result of the qualifying examination has not been declared till the
date of ONLINE Document Verification have been given a chance to apply as appearing
candidate with undertaking that if they are not able to produce the final year result by 30th
3

<!-- page 4 -->

September 2026 or if their result does not satisfy the percentage criteria as stated above in
point 4 of guideline then their seat will be cancelled and the candidate will bear the sole
responsibility.
12. If any document / declaration submitted by the candidate are found to be false at any stage, his /
her admission will be cancelled and he / she may be liable for prosecution under the law. In case
of any legal dispute, the jurisdiction will be limited to Kanpur Court only.
13. The candidates must ensure their eligibility for admission to B.Tech. (Engineering/Technology), B.
Tech. (Biotechnology) & B. Pharm. (Lateral entry) programs at HBTU Kanpur while applying.
University will not be responsible for any error of judgement on the part of the candidate.
14. Detailed Online-ONLINE Counseling Procedure[I]- Online Registration (for all programs), Upload Documents, Choice Filling and Document
Verification:
i. A student can register using links available at https://hbtu.admissions.nic.in or
www.hbtu.ac.in under UG counselling by filling all the details.
ii. The candidate is required to upload Scanned Copies of all relevant documents (like qualifying
examination marksheet, age proof (10th pass Certificate), category certificate, domicile
certificate if required etc.) for Online Document Verification. (Refer Table 5).
iii. Depositonline Registration Fee of Rs. 2,500=00 (non-refundable).
iv. After deposition of registration fee Online document verification process done, if any
candidate has application discrepancy raised during document verification, then query will
be raised. The query will be resolved by the candidate during prescribed timing.
v. After successful document verification candidate are advised to complete the branch
Choices filling within prescribed time.
vi. The candidates are advised to complete Registration & Choice Filling within the
stipulated time slot.
vii. If the candidate fails to upload documents for Online Document Verification within prescribed
date and time (table-2), the candidature will be cancelled and the candidate will be out of
counselling process.
[II]- View result, and Pay Acadmic/ Partial Fee Online (if a seat is allotted).
(a) First Round Results & Seat Allotment:
i.
In case of seat allotment to a candidate

• If chosen FLOAT option, then candidates have to deposit Partial academic
Fee of Rs. 60,000=00 and waits for next round of seat allotment result.
• If chosen FREEZE option, then must deposit Full Academic Fee of Rs.
1,35,000=00 in stipulated time period and may be able to download
Provisional Admission letter.
ii.

Candidates selected FREEZE option & after paying Full Academic Fee has to give his /
her option Yes/No for Internal Sliding on his/ her Login portal (see point no. III & IV on
Page 7).

4

<!-- page 5 -->

Important Note:
• Non-deposition of fee (Full academic Fee/ Partial academic Fee as the case may be) will
lead to cancellation of allotted seat. This seat will be considered vacant for next round of
counselling.
• Candidates must download the Provisional admission letter after depositing full academic fee
as proof of admission in University and for future reference.
iii. If the documents are not in proper format, then the candidate will be asked to submit proper
document in prescribed date and time (the tentative time line for each activity is mentioned in
Table-2).
iv. Candidates must check their login on admission website regularly until their admission letter
not generated successfully.
v.

If candidate fails to submit proper document within prescribed time (Table-2), the allotted seat
will be cancelled and the candidate will be out of counselling process.

vi. If the candidate is not interested to further participate in counselling process, he/she may
exercise ‘WITHDRAWL’ option (check Table-1). In such cases, Seat Acceptance Fee/
Academic Fee submitted will be refunded as per Refund Policy. Candidate must fill the
WITHDRAWAL FORM using his/her login for getting refund in time else the candidate will
be responsible for delay.
vii. Withdrawal form once filled will automatically cancel the allotted seat and the candidate will
be out of counselling process.
-In case of no seat allotmentThe candidates are advised to wait and check the next round of seat allotment results.
Important Instructions for candidatesa. All notices/ information will be uploaded on https://hbtu.admissions.nic.in and
www.hbtu.ac.in.
b. Candidates are advised to continuously check their Login id/ website
(https://hbtu.admissions.nic.in) for queries raised/ information displayed by counselling/
admission team.
c. Candidates must read the Admission Guidelines very carefully before participating in the
Counselling process. Please note: slight changes in the guidelines can be made in due course
of time if necessary, so candidates are requested to regularly check the admission website for
any modification.
d. During Registration Candidates must fill all the information and do the choice filling (for
B. Tech Engineering/Technology) etc. VERY CAREFULLY. Information / choices once
filled and locked then no corrections are possible.
e. Any missing information/ misinterpretation will be the sole responsibility of candidate.
f. If the candidate seeking admission in B.Tech. (Engineering/Technology) gets the seat of first
choice, he / she will have only ‘FREEZE’ option and has to deposit Full Academic Fee
Rs.1,35,000=00 in stipulated time period. Non-deposition of fee will lead to cancellation of
allotted seat. This seat will be considered vacant for next round of counselling.
g. Candidate must refer table -5 for the requirements during ONLINE document verification
and fee deposition at HBTU, Kanpur as per schedule.

5

<!-- page 6 -->

(b) Second Round Results & Seat Allotment:
Case-1: If the seat is allotted to the candidate in Second Round (not allotted in first round)-

•

If chosen FLOAT option, then candidates have to deposit Partial academic Fee of
Rs. 60,000=00 and waits for next round of seat allotment result.
If chosen FREEZE option, then must deposit Full Academic Fee of Rs.
1,35,000=00 in stipulated time period and may be able to download Provisional
Admission letter.

•

•

Candidates after paying Full Academic Fee i.e. Rs. 1,35,000=00 has to choose yes/No for
Internal Sliding (see point no. III & IV below, pg 7). Other candidates have to only register on
University ERP.

Case-2: If the seat was allotted earlier in First Round of counselling•

If candidate feel satisfied (i.e. the candidate gets the seat of their choice in the second round
of result), then they have to choose ‘FREEZE’ option and pay Balance Academic Fee i.e. Rs.
75,000=00 [Rs. 1,35,000=00 - 60,000=00] for all candidates ONLINE using their Login ID.

•

If candidate not feel satisfied, then choose FLOAT option

•

These candidates have to download Provisional Admission letter using their Login ID after
paying Full Academic Fee.

•

Candidates selected FREEZE option & after paying Full Academic Fee have to choose Yes/No
for Internal Sliding (see point no. III & IV below, page 7).

•

Candidates can also withdraw from counselling process in this round by choosing
WITHDRAWL option. Deposited Fee will be refunded as per the Refund policy.

•

Candidates are required to be very particular about prescribed date and time in completing the
activities. Not taking prompt action in prescribed time will lead to cancellation of allotted
seat.

(c) Third Round Results & Seat Allotment (NO Float Option Available):
Case-1: If the seat is allotted to the candidate in Third Round (not allotted in first and second round)-

•

If chosen FREEZE option, then must deposit Full Academic Fee of Rs.
1,35,000=00 in stipulated time period and may be able to download Provisional
Admission letter.
No FLOAT Option available.

•
•

Candidates after paying Full Academic Fee i.e. Rs. 1,35,000=00 has to choose yes/No for
Internal Sliding (see point no. III & IV below, pg 7). Other candidates have to only register on
University ERP.

Case-2: If the seat was allotted earlier in First and Second Round of counselling•

If candidate feel satisfied (i.e. the candidate gets the seat of their choice in the third round of
result or seat is retained), then they have to choose ‘FREEZE’ option and pay balance
academic Fee i.e. Rs. 75,000=00 [Rs. 1,35,000=00 - 60,000=00] for all candidates ONLINE
using their Login ID.

•
•

No FLOAT Option available.
These candidates have to download Provisional Admission letter using their Login ID after
paying Full Academic Fee.
6

<!-- page 7 -->

•

Candidates selected FREEZE option & after paying Full Academic Fee have to choose Yes/No
for Internal Sliding (see point no. III & IV below, page 7).

•

Candidates can also withdraw from counselling process in this round by choosing
WITHDRAWL option. Deposited Fee will be refunded as per the Refund policy.

•

Candidates are required to be very particular about prescribed date and time in completing the
activities. Not taking prompt action in prescribed time will lead to cancellation of allotted
seat.

[III] Online Registration on University ERP (Very Important Activity)
• All students who have paid full academic fee are essentially required to register
on University ERP to confirm their admission.

• This is an Important and mandatory activity required to be exercised by all the
provisionally admitted candidates. Candidates who will not Register on ERP will be
considered as not interested for Admission and his/her allotted seat will be cancelled.
[IV] Internal Sliding : In any of the two rounds of Counselling, after choosing the FREEZE option
and paying Full academic fee, the candidate has to give his/her consent for the Internal
sliding. The sliding will be done considering the branch choices filled during the registration
process. If the candidate is satisfied with the Allotted Seat or his/her First Choice is allotted
or do not want to participate in Internal Sliding then Option NO can be chosen, otherwise he/
she may opt YES for a chance to upgrade the seat while keeping the allotted seat in hand.
Note: Internal Sliding will be done based on the available vacant seats and considering the
prefilled choice preference given by the candidate at the time of choice filling during
Registration. Further during sliding Category upgradation may take place.
15. The allotment of seats through counselling will be carried out strictly on merit/Rank in
accordance with the CUET(UG)-2026 score of the candidate subject to the order of choice
preference given for the seat and the availability of seat in the category. [For Rank calculation
refer point 20]
16. All the information in connection with B.Tech. (Lateral Entry) Admission 2026 shall be made
available
through
the
admission
website:
https://hbtu.admissions.nic.in
and
https://www.hbtu.ac.in. The candidates are advised to visit these websites regularly. University
will not be responsible for any loss to candidate due to the lack of communication.
17. Category Definitions
a) Candidates who have passed the qualifying examination from an Institution located in the State
of Uttar Pradesh and who do not claim any reserved category are eligible for admission to all
the courses at HBTU, Kanpur against available General (OPEN) seats.
[Code: UPGE] No category certificate is required from such candidates.
b) Candidates who have passed the qualifying examination from an Institution located in State of
U.P. and are permanent resident of Uttar Pradesh and belong to Scheduled Caste (SC) of Uttar
Pradesh / Scheduled Tribe (ST) of Uttar Pradesh / Other Backward Classes (Non Creamy
Layer- NCL) of Uttar Pradesh are eligible for admission against available reserved seats of their
category.
[Respective Code: UPSC / UPST / UPBC] Certificate No. 1 or 2, as applicable, is required.
7

<!-- page 8 -->

c) Candidates who have passed the qualifying examination from an Institution located outside
Uttar Pradesh and whose parents are domicile of Uttar Pradesh and who have not claimed for
any reserved category, are also eligible for admission to courses offered at HBTU, Kanpur
under General (OPEN) category. Such candidates have to upload the Permanent Residence
Certificate of his / her parents (Father or Mother only) for ONLINE Document Verification.
[Code: UPGD] Certificate No. 3 is required from such candidates.
d) Candidates who have passed the qualifying examination from an Institution located outside
Uttar Pradesh and whose parents are domicile of Uttar Pradesh and who belong to Scheduled
Caste of Uttar Pradesh / Scheduled Tribe of Uttar Pradesh / Other Backward Classes (NCL) of
Uttar Pradesh are also eligible for admission against reserved seats of their category.
[Respective Codes: GDSC / GDST / GDBC] Such candidates have to upload the Permanent
Residence Certificate of his / her parent (Father or Mother only) (Certificate No. 3) and
category certificate (Certificate No. 1 or 2 as applicable for ONLINE document verification.)
e) The domicile requirement to son / daughter of the following is relaxed and admission is permitted:
•

•

18.

Defence Personnel settled in Uttar Pradesh on the date of Entrance Examination of
CUET(UG)-2026 after retirement / being disabled in action or Defence Personnel killed in
action and the dependents settled in Uttar Pradesh on the date of Entrance Examination of
CUET(UG)-2026. (Certificate no. 5 is required).
• Defence Personnel who are not domicile of Uttar Pradesh but are posted in Uttar Pradesh on
the date of Entrance Examination of CUET(UG)-2026. (Certificate no. 5 is required)
Wards of Employees of All India Services belonging to Uttar Pradesh cadre. (Certificate no. 10 is
required) [Code: GDDA] GDDA candidate will be considered as UPGD category for all other
benefits.
Reservation of Seats

a) Vertical Reservation:
Category
Percentage of Reservation
(a) Scheduled Caste of U.P.
21%
(b) Scheduled Tribe of U.P.
02%
(c) Other Backward Classes of U.P.
27%
b) Request for the change of category filled in the form during Online Registration shall not be
entertained under any circumstances.
c) Category claims must be supported by the relevant certificates as per the formats provided and will
be produced by the candidate at the time of Document Verification. Otherwise, the allotment will
be cancelled and the candidates shall be treated in General Category in the next round of
counselling.
19. Medical Standards
a) Candidates will have to submit a certificate of Medical Fitness / Handicapped on Certificate no. 8.
b) The medical standards prescribed are given below:
Height
Candidates should be physically fit to pursue his / her
Weight
studies in opted course.
Chest measurement
Heart and lungs

No abnormality
8

<!-- page 9 -->

Hernia, Hydrocele, Piles etc.
Vision

Presence of any of these is to be corrected before joining
Normal, if defective, it must be got corrected to 6/9 in the
better eye and 6/12 in the worse one. Eyes should be free
from congenital or any other disease

Hearing

Normal, If defective, it must be got corrected before
joining.

20. Formula for Rank Calculation / Merit List preparation using CUET (UG) 2026 result:
For admission to B.Tech. & B. Pharm. (Lateral Entry) the Merit list will be prepared by adding the
normalized scores obtained by candidates in prescribed two test papers (other than B.Tech.
Biotechnology & B.Pharm.) i.e. domain specific subject 1 or 2 and general test subject as stated below:
Programs/ Courses
Subject type for
Name of the subject (code)
for Lateral Entry [LE]
CUET(UG)-2026
Admission: 2026-27
-Mathematics (Sub. Code: 319)
B.Tech.
Domain specific
OR
(Engineering/Technology)
-Computer Science/Informatics Practices (Sub. Code:
308)
General Aptitude Test
-General Test (Sub. Code: 501)
B.Tech. Biotechnology
Candidates has to
-Biology/Biological
secure score in any
Studies/Biotechnology/Biochemistry
one of the subjects
(Sub. Code: 304)
OR
-Chemistry (Sub Code: 306)
OR
-Mathematics/Applied Mathematics (Sub. Code: 319)
OR
-Physics (Sub. Code: 322)
B. Pharm.
Candidate has to
-Biology/Biological
secure score in any
Studies/Biotechnology/Biochemistry
one of the subjects
(Sub. Code: 304)
OR
-Chemistry (Sub Code: 306)
OR
-Mathematics/Applied Mathematics (Sub. Code: 319)
OR
-Physics (Sub. Code: 322)

Formula for Rank GenerationFor B.Tech. in Engineering/Technology
•

Total Normalized Score = Normalized Score in domain specific Subject 1 (Sub. Code: 319) or
Subject 2 (Sub. Code: 308) + Normalized Score in General Test (Sub. Code: 501)
Note: Normalized Score with up to 5 decimal points will be considered.

•

Rank 1 will be given to the candidate with Highest Total Normalized Score

Tie breaking in case of Equal Total Normalized Scores:
If there is a tie in Total Normalized Scores obtained by two or more candidates, the order of merit of
such candidates shall be decided in the following order:
9

<!-- page 10 -->

1.

Rank determination by normalized score obtained in General Test (Sub. Code: 501) in CUET
(UG)-2026. Candidate obtaining higher normalized score in General Test will be given better
rank.

2.

If still there is a tie break, then, Rank will be determined by normalized score obtained in DomainSpecific Subject 1 or 2 (Sub. Code: 319/ (Sub. Code: 308) in CUET (UG)-2026. Candidates
obtaining higher normalized score in their domain specific subject will be given the better rank.

3.

If still there is a tie break, then, Rank determination by age of the candidate. The older candidate
will be given better rank compared to younger one.

-

For B.Tech. in Biotechnology and B. Pharm. courses
Candidate obtaining highest normalized score in any one of the prescribed subjects will be given
Rank 1.
For tie break cases
1. Candidate with highest aggregate Qualifying Examination marks will be given better rank.
2. If tie break is between candidate where one candidate has the qualifying degree, and other is
awaiting result, then the candidate with degree will be given better rank.
3. If still there is a tie break for any reason, then, Rank determination by age of the candidate. The
older candidate will be given better rank.

20.

University reserves the right to modify the Guidelines as and when required. So it is advised to
regularly visit admission website for latest updates.

Table 1: Stepwise Counseling procedure and Fee deposition for B. Tech. & B.Pharm. (Lateral Entry)
programs
STEP 1

1.1.1.: Candidate has to start Online Registration at https://hbtu.admissions.nic.in & fill all the
details.
1.1.2: Upload all relevant documents for Online Document Verification (Refer Table 5) for all
candidates.
1.1.3: Deposit Registration Fee of Rs. 2500=00 (Non-Refundable).
1.1.4: Online Document Verification and Query Resolved.

STEP 2

After Successful Document Verification, Candidates must fill the branch choices VERY
CAREFULLY within prescribed time.
(Note: Choices once filled will be considered for all the rounds of the counseling, No change in choice
will be considered in between.)

STEP 3

FIRST ROUND COUNSELLING STARTS AFTER THE DISPLAY OF SEAT ALLOTMENT
RESULT

3.1

3.1.1 :

View Result

3.2

3.2.1 :

If Seat is allotted
(i) If chosen FREEZE option (Confirmation of allotted seat)
• Deposit Full Annual Academic Fee Rs. 1,35,000=00 and
(ii) If Chosen FLOAT option (for next round of counseling)
• Deposit Partial Academic Fee i.e. Rs. 60,000=00 for all candidates.
• Wait for the next round of results
(iii) Choose option YES/NO for internal sliding (for Freeze Option).

3.3

3.3.1 Withdrawal / Cancellation
• If candidate opts for Withdrawal option or fails to satisfy any of the above activity in stipulated
10

<!-- page 11 -->

STEP 4
4.1

time, the candidate will automatically be out of counseling process.
• Refund will be made in due course of time as per refund policy.
• Candidate must fill the WITHDRAWAL FORM using his/her login. Else no refund will
be entertained.
SECOND ROUND COUNSELLING STARTS AFTER THE DISPLAY OF SEAT
ALLOTMENT RESULT
4.1.1 :

View Result

4.1.2 :

If Seat is allotted First time in this round.
(i) If chosen FREEZE option (Confirmation of allotted seat)
• Deposit Full Annual Academic Fee Rs. 1,35,000=00 and
(ii) If Chosen FLOAT option (for next round of counseling)
• Deposit Partial Academic Fee i.e. Rs. 60,000=00 for all candidates.
• Wait for the next round of results
(iii) Choose option YES/NO for internal sliding (for Freeze Option).

4.1.3

Candidate who got seat allotment in first round and in this round their seat might be
upgraded or remains unchanged have to• If feel statisfied with seat allotted, then deposit Balance Academic Fee (for
those who have Partial Academic Fee in First Round) Rs. 75,000=00 for all
candidates Online using their Login ID.
• If not feel statisfied with seat allotted then choose FLOAT option and wait for
next round result.
• After depositing full Academic Fee, Download Provisional Admission letter.
• Choose option YES/NO for internal sliding (for FREEZE option).

4.2 4.2.1 : Withdrawal / Cancellation
• If candidate opts for Withdrawal option or fails to satisfy any of the above activity in stipulated
time, then the candidate will automatically be out of counseling process.
• Refund will be made in due course of time as per refund policy.
• Candidate must fill the WITHDRAWAL FORM using his/her login. Else no refund will
be entertained.
STEP 5
5.1

THIRD ROUND COUNSELLING STARTS AFTER THE DISPLAY OF SEAT ALLOTMENT
RESULT
5.1.1 :
5.1.2 :

View Result
If Seat is allotted First time in this round.
(i) If chosen FREEZE option (Confirmation of allotted seat)
• Deposit Full Annual Academic Fee Rs. 1,35,000=00 and
(ii) No FLOAT option is avaliable.
(iii) Choose option YES/NO for internal sliding (for Freeze Option).

5.1.3

Candidate who got seat allotment in first and Second round and in this round their
seat might be upgraded or remains unchanged have to• If feel statisfied with seat allotted, then deposit Balance Academic Fee (for
those who have Partial Academic Fee in First Round) Rs. 75,000=00 for all
candidates Online using their Login ID.
• No FLOAT option is avaliable.
• After depositing full Academic Fee, Download Provisional Admission letter.
• Choose option YES/NO for internal sliding (for Freeze Option).

5.2 5.2.1 : Withdrawal / Cancellation
• If candidate opts for Withdrawal option or fails to satisfy any of the above activity in stipulated
11

<!-- page 12 -->

•
•

time, then the candidate will automatically be out of counseling process.
Refund will be made in due course of time as per refund policy.
Candidate must fill the WITHDRAWAL FORM using his/her login. Else no refund will
be entertained.

STEP 6 Internal Sliding Result
(For candidates opted Yes for internal sliding)
Additional Round and ONLINE-On campus (Spot) counseling will be notified later

Note:
1. ONLINE counseling process is a time bound process. Candidates are advised to do the needful
strictly within the time frame given for the activity. Otherwise, the Candidate will
automatically be out of counseling process.
2. Candidates are further advised to visit University Website: www.hbtu.ac.in or
https://hbtu.admissions.nic.in regularly for timely update.
3. Date-wise schedule is given in table no. 2
REFUND POLICY:
If the student chooses to withdraw from the programme of study in which he/she is enrolled, the University
will follow the rules as per the University/UGC norms•

According to UGC rules, if a student cancels their admission before the formally notified last date
of admission, the university will deduct ₹5000 as processing charges, and the rest of the money
will be refunded.

•

In case of student withdraws after the notified last date of admission, the refund of fees will be as
per the following table:Sr. No

When You withdraw Admission

1.

Percentage of Refund of Fees
(includes processing Fees)
80%

2.

50%

More than 15 days but less than 30 days from the
formally notified last date of admission.

3.

0%

More than 30 days after the formally notified last
date of admission.

15 days or less after the formally notified last date
of admission

(Important Note:

➢ All refunds will be processed after the last date of Admissions for session 2026-27
➢ Please fill all the BANK ACCOUNT related information VERY CAREFULLY for timely
refund.
➢ If the refund gets stuck or goes to the wrong account due to the incorrect/ wrong
information furnished by the candidate, then the University will not be responsible.)

12

<!-- page 13 -->

Table 2: *Tentative Schedule / Timeline for ONLINE Counseling for admission to Second Year B.Tech.
& B.Pharm. (Lateral Entry) at HBTU, Kanpur for Session 2026-27
Sl.
No.

Activity

Sub Activity

•
•

1.

Online Registration,
Document
Verification &
Choice Filling

•

Online Registration, fill all details.
Upload all the relevant document for ONLINE
Document Verification.
Pay Registration fee.

Document Verification and Query Resolved
After Successful Document, candidate must fill branch
choices.

2.

3.

1st Round
Counselling

2nd Round
Counselling

1st Round Seat Allotment
View Result
If Seat is allotted• if FREEZE option is chosen. Deposit Full
Academic Fee Rs. 1,35,000=00.
• if FLOAT option is chosen. Deposit Partial
Academic Fee Rs. 60,000=00 (for all candidates)
and wait for next round result.
• Choose Yes/No for internal sliding (For Freeze
option).
• Failing any of the step in mentioned time
duration will lead to cancellation of your seat
and you will be out of counselling process.
Withdrawal (FILL WITHDRWAL FORM)
2nd Round Seat Allotment
View Result
(i) If Seat is allotted first time in this round• if FREEZE option is chosen. Deposit Full
Academic Fee Rs. 1,35,000=00.
• if FLOAT option is chosen. Deposit Partial
Academic Fee Rs. 60,000=00 (for all candidates)
and wait for next round result.
• Choose Yes/No for internal sliding (For Freeze
option).
• Failing any of the step in mentioned time
duration will lead to cancellation of your seat
and you will be out of counselling process.
(ii) Candidate who got seat allotment in first round and
in this round their seat might be upgraded or remains
unchanged.
• if FREEZE option is chosen. Deposit Balance
Academic Fee Rs. 75,000=00.
• if FLOAT option is chosen. wait for next round
Result.
• Choose Yes/No for internal sliding (For Freeze
option).
Failing any of the step in mentioned time duration will
lead to cancellation of your seat and you will be out of
13

Dates

July 11 - 20, 2026
End Time: 05:00
PM
July 13 - 21, 2026
End Time: 05:00
PM
July 13 - 22, 2026
End Time: 05:00
PM
July 23, 2026
July 23 - 25, 2026

July 27, 2026
July 27 - 29, 2026

<!-- page 14 -->

counselling process.
Withdrawal (FILL WITHDRWAL FORM)
3rd Round Seat Allotment
View Result

4.

3rd Round
Counselling

(i) If Seat is allotted first time in this round• if FREEZE option is chosen. Deposit Full
Academic Fee Rs. 1,35,000=00.
• No FLOAT option is available.
• Choose Yes/No for internal sliding (For Freeze
option).
• Failing any of the step in mentioned time
duration will lead to cancellation of your seat
and you will be out of counselling process.
(ii) Candidate who got seat allotment in first and second
round and in this round their seat might be upgraded or
remains unchanged.
• if FREEZE option is chosen. Deposit Balance
Academic Fee Rs. 75,000=00.
• No FLOAT option is available.
• Choose Yes/No for internal sliding (For Freeze
option).

July 31, 2026
July 31 – Aug 2,
2026

Note: Failing any of the step in mentioned time duration
will lead to cancellation of your seat and you will be out
of counselling process.
4.

Internal sliding

5.

ERP Registration

6

Physical Reporting

*

Withdrawal (FILL WITHDRWAL FORM)
View result and this will be the final allotted seat only
for candidates opted Yes for internal Sliding
Online Registration on University ERP for direct
admission to 2nd year B.Tech
Date of Physical Reporting in the University

Aug 5, 2026
Aug 6-8, 2026
To be announced
Later

Important Notes:
• All activities are to be completed in time bound manner so candidates are advised to do the
needful within the time/ date specified. Any inaction/delay on the part of the candidate will
lead to the cancellation of allotted seat.

• The dates may change in due course of time so kindly visit admission website regularly
for latest updates (https://hbtu.admissions.nic.in)

14

<!-- page 15 -->

TABLE 3: FEE STRUCTURE FOR B.TECH.(Engineering/Technology), B.Tech.
(Biotechnology) & B.PHARM. (L.E.) PROGRAMS FOR SESSION 2026-27
S.
No .

Particular

A

Tuition Fee

B

Other than Tuition Fee

Fee in (Rs.)
75000

(i) Registration, Examination & Certification

10000

(ii) Facility

30500

(iii) Medical Fee

3000

(iv) Training & Placement

4000

(v) Activity Charges

3000

(vi) Other Charges
Caution Money

5000

University Alumni Fund

1500

Student Aid Fund

1500

Contingency & Miscellaneous Charges

1500

Total (i+ii+iii+iv+v+vi)

60000

Grand Total (A+B)

1,35,000.00

15

<!-- page 16 -->

OPNO

BCNO

SCNO

STNO

Total available Seat

CS

COMPUTER SCIENCE & ENGINEERING

3

2

1

0

0

3

IT

INFORMATION TECHNOLOGY

3

2

0

1

0

3

ET

ELECTRONICS ENGINEERING

3

2

1

0

0

3

EE

ELECTRICAL ENGINEERING

3

1

1

1

0

3

ME

MECHANICAL ENGINEERING

3

2

1

0

0

3

CE

CIVIL ENGINEERING

3

1

1

1

0

3

CH

CHEMICAL ENGINEERING

3

2

1

0

0

3

BE

CHEMICAL TECHNOLOGY (BIOCHEMICAL
ENGINEERING)

3

2

1

0

0

3

FT

CHEMICAL TECHNOLOGY (FOOD
TECHNOLOGY)

3

1

1

1

0

3

OT

CHEMICAL TECHNOLOGY (OIL TECHNOLOGY)

3

2

0

1

0

3

PT

CHEMICAL TECHNOLOGY (PAINT
TECHNOLOGY)

3

1

1

1

0

3

PL

CHEMICAL TECHNOLOGY (PLASTIC
TECHNOLOGY)

3

2

0

1

0

3

LT

CHEMICAL TECHNOLOGY (LEATHER &
FASHION TECHNOLOGY)

3

1

1

1

0

3

B.Tech.
(Biotechnology.)

BT

BIOTECHNOLOGY

3

2

1

0

0

3

B.Pharm

BP

B.PHARM.

3

2

1

0

0

3

Total

45

25

12

8

0

45

Lateral Entry Programs

B.Tech.
(Engineering/Technology)

BRANCH_ABB

Total Seats

Table 4 : Seat Matrix for B.TECH.(Engineering/Technology), B.Tech. (Biotechnology.) &
B.PHARM. (Lateral Entry) program 2026-27 at HBTU, Kanpur

Branch

Table 5: List of Documents required for verification at HBTU Kanpur

Sl. No. List of documents
16

<!-- page 17 -->

1.

CUET (UG) Result 2026

2.

10th Certificates & Marksheets

3.

12th Certificates & Marksheets

4.

Category Certificate : SC / ST and EWS/OBC certificate on or after 01.04.2026

5.

Sub Category Certificate (if required)

6.

Birth Certificate

7.

Domicile Certificate (if required)

8.

Income Certificate (if required) on or after 01.04.2026

9.

Character Certificate

10.

Transfer / Migration Certificate

11.

Medical Certificate

12.

Aadhar Card Copy

13.

Passport Size Photos (05 Nos)

17
