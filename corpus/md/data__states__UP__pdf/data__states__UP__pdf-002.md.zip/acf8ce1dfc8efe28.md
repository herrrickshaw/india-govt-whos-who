---
doc_id: "acf8ce1dfc8efe28"
source_url: "https://mdamoradabad.up.gov.in/uploads/rules_and_regulations/1753515725-THE_RI~4_REGISTERED-NO.-DL—(N)04_0007_2003—15.PDF"
ministry: "Moradabad Development Authority, Uttar Pradesh"
title: "THE_RI~4_REGISTERED NO. DL—(N)04_0007_2003—15"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f707756170a38b4d"
---

<!-- page 1 -->

jftLVªh lañ Mhñ ,yñ—(,u)04@0007@2003—15

REGISTERED NO. DL—(N)04/0007/2003—15

vlk/kkj.k
EXTRAORDINARY
Hkkx II — [k.M 1
PART II — Section 1

izkf/kdkj ls izdkf'kr
PUBLISHED BY AUTHORITY
lañ 28]

ubZ fnYyh] 'kfuokj] ebZ 30] 2015@ T;s"B 9] 1937 ¼'kd½

No. 28]

NEW DELHI, SATURDAY, MAY 30, 2015/ JYAISTHA 9, 1937 (SAKA)

bl Hkkx esa fHkUu i`"B la[;k nh tkrh gS ftlls fd ;g vyx ladyu ds :i esa j[kk tk ldsA
Separate paging is given to this Part in order that it may be filed as a separate compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 30th May, 2015/Jyaistha 9, 1937 (Saka)

THE RIGHT TO FAIR COMPENSATION AND TRANSPARENCY IN
LAND ACQUISITION, REHABILITATION AND RESETTLEMENT
(AMENDMENT) SECOND ORDINANCE, 2015
NO. 5 OF 2015
Promulgated by the President in the Sixty-sixth Year of the Republic of India.
An Ordinance further to amend the Right to Fair Compensation and Transparency in Land
Acquisition, Rehabilitation and Resettlement Act, 2013.
WHEREAS the Right to Fair Compensation and Transparency in Land Acquisition,
Rehabilitation and Resettlement (Amendment) Ordinance, 2014 to amend the Right to Fair
Compensation and Transparency in Land Acquisition, Rehabilitation and Resettlement
Act, 2013 (RFCTLARR Act, 2013) was promulgated by the President on the 31st day of
December, 2014;
AND WHEREAS, the RFCTLARR (Amendment) Bill, 2015 was introduced on the
24th February, 2015 in the House of the People to replace the said Ordinance and the said
Bill was passed alongwith amendments on the 10th March, 2015 in the House of the People,
but the same could not be passed by the Council of States and is pending in that House;
AND WHEREAS, the RFCTLARR (Amendment) Ordinance, 2015 incorporating the
amendments made by the House of the People was promulgated by the President on
3rd April, 2015;

<!-- page 2 -->

2

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

AND WHEREAS, the RFCTLARR (Amendment) Second Bill, 2015 was introduced in the
House of the People on 11th May, 2015;
AND WHEREAS, the House of the People referred the RFCTLARR (Amendment) Second
Bill, 2015 to the Joint Committee of the Houses;
AND WHEREAS, it is considered necessary to give continued effect to the provisions
of the RFCTLARR (Amendment) Ordinance, 2015;
AND WHEREAS,Parliament is not in session and the President is satisfied that
circumstances exist which render it necessary for him to take immediate action;
Now, Therefore, in exercise of the powers conferred by clause (1) of article 123 of the
Constitution, the President is pleased to promulgate the following Ordinance:—
Short title
and commencement.

1. (1) This Ordinance may be called the Right to Fair Compensation and Transparency
in Land Acquisition, Rehabilitation and Resettlement (Amendment) Second Ordinance,
2015.
(2) It shall be deemed to have come into force on the 31st day of December, 2014.

Substitution
of certain
expression
throughout
the Act.

2. In the Right to Fair Compensation and Transparency in Land Acquisition,
Rehabilitation and Resettlement Act, 2013 (hereinafter referred to as the principal Act), for
the words "private company" wherever they occur, the words "private entity" shall be
substituted.

Amendment
of
section 2.

3. In the principal Act, in sub-section (2) of section 2, after the second proviso , the
following proviso shall be inserted, namely: —

30 of 2013.

"Provided also that the acquisition of land for the projects listed in sub-section
(1) of section 10A and the purposes specified therein shall be exempted from the
provisions of the first proviso to this sub-section.".
Amendment
of section 3.

4. In the principal Act, in section 3,—
(i) in clause (j), in sub-clause (i), for the words and figures "the Companies Act,
1956", the words and figures "the Companies Act, 2013" shall be substituted;
(ii) after clause (y), the following clause shall be inserted, namely:—
'(yy) "private entity" means any entity other than a Government entity or
undertaking and includes a proprietorship, partnership, company, corporation,
non-profit organisations or other entity under any law for the time being in
force;'.

Insertion of
new Chapter
IIIA.

5. In the principal Act, after Chapter III, the following Chapter shall be inserted,
namely:—
"CHAPTER IIIA
PROVISIONS OF CHAPTER II AND CHAPTER III NOT TO APPLY TO CERTAIN PROJECTS

Power of
appropriate
Government
to exempt
certain
projects.

10A. (1) The appropriate Government may, in the public interest, by notification,
exempt any of the following projects from the application of the provisions of Chapter II and
Chapter III of this Act, namely: —
(a) such projects vital to national security or defence of India and every part
thereof, including preparation for defence or defence production;
(b) rural infrastructure including electrification;
(c) affordable housing and housing for the poor people;

1 of 1956.
18 of 2013.

<!-- page 3 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

3

(d) industrial corridors set up by the appropriate Government and its
undertakings (in which case the land shall be acquired up to one kilometer on both
sides of designated railway line or roads for such industrial corridor); and
(e) Infrastructure projects including projects under public private partnership
where the ownership of land continues to vest with the Government:
Provided that the appropriate Government shall, before the issue of notification,
ensure the extent of land for the proposed acquisition keeping in view the bare minimum
land required for such project.
(2) The appropriate Government shall undertake a survey of its wasteland including
arid land and maintain a record containing details of such land, in such manner as may be
prescribed by the appropriate Government.
6. In the principal Act, in section 24, in sub-section (2), after the proviso, the following
proviso shall be inserted, namely:—

Amendment
of section 24.

"Provided further that in computing the period referred to in this sub-section,
any period or periods during which the proceedings for acquisition of the land were
held up on account of any stay or injunction issued by any court or the period
specified in the award of a Tribunal for taking possession or such period where
possession has been taken but the compensation is lying deposited in a court or in
any designated account maintained for this purpose, shall be excluded.".

2 of 1974.

7. In the principal Act, in section 31, in sub-section (2), in clause (h), after the words
"affected families", the words "including compulsory employment to at least one member of
such affected family of a farm labourer" shall be inserted.

Amendment
of section 31.

8. In the principal Act, in section 46, in sub-section (6), in the Explanation, in clause(b),
the words "any person other than" shall be omitted.

Amendment
of section 46.

9. In the principal Act, after section 67, the following section shall be inserted, namely—

Insertion of
new section
67A.

"67A. The Authority shall, after receiving reference under section 64 and after
giving notice of such reference to all parties concerned, hold the hearing in the
district where the land acquisition takes place for settlement of the objections raised
in the reference.".

Hearing to be
held by
Authority in
district or
districts to
decide
grievances.

10. In the principal Act, for section 87, the following section shall be substituted,
namely:—

Substitution
of new
section for
section 87.

"87. Where an offence under this Act has been committed by any person who
is or was employed in the Central Government or the State Government, as the case
may be, at the time of commission of such alleged offence, the court shall take
cognizance of such offence provided the procedure laid down in section 197 of the
Code of Criminal Procedure, 1973 is followed.".

Offences by
Government
officials.

11. In the principal Act, in section 101, for the words "a period of five years", the
words, "a period specified for setting up of any project or for five years, whichever is later,"
shall be substituted.

Amendment
of section
101.

12. In the principal Act, in section 105,—
(i) for sub-section (3), the following sub-section shall be substituted, namely:—
"(3) The provisions of this Act relating to the determination of
compensation in accordance with the First Schedule, rehabilitation and

Amendment
of section
105.

<!-- page 4 -->

4

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II— SEC. 1]

resettlement in accordance with the Second Schedule and infrastructure
amenities in accordance with the Third Schedule shall apply to the enactments
relating to land acquisition specified in the Fourth Schedule with effect from
1st January, 2015.";
(ii) sub-section (4) shall be omitted.
Amendment
of section
109.

Amendment
of section
113.

13. In the principal Act, in section 109, in sub-section (2),after clause (d), the following
clause shall be inserted, namely:—
" (dd) the manner of undertaking a survey of waste land including arid land and
maintenance of the record containing the details of such land under sub-section (2)
of section 10A;'.
14. In the principal Act, in section 113, in sub-section (1),—
(i) for the words "the provisions of this Part", the words "the provisions of this
Act" shall be substituted;
(ii) in the proviso, for the words "a period of two years", the words "a period
of five years" shall be substituted.

Repeal and
saving.

15. (1) The Right to Fair Compensation and Transparency in Land Acquisition,
Rehabilitation and Resettlement (Amendment) Ordinance, 2015, is hereby repealed.
(2) Notwithstanding such repeal, anything done or any action taken under the principal
Act, as amended by the Right to Fair Compensation and Transparency in Land Acquisition,
Rehabilitation and Resettlement (Amendment) Ordinance, 2015, shall be deemed to have
been done or taken under the principal Act, as amended by this Ordinance.

PRANAB MUKHERJEE,
President.
————

DR. SANJAY SINGH,
Secretary to the Government of India.

PRINTED BY THE GENERAL MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI—2015.

GMGIPMRND—2012GI(S3)—30-05-2015.

Ord. 4 of 2015.

4 of 2015.
