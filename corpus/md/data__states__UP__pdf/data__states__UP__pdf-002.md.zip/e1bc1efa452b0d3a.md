---
doc_id: "e1bc1efa452b0d3a"
source_url: "https://cdnbbsr.s3waas.gov.in/s332e05616c8ed659463f9af00b142dd6f/uploads/2026/07/20260713702896645.pdf"
ministry: "Harcourt Butler Technical University, Admission and eCounselling Services"
title: "Updated Guidelines for Admission to MCA Programme"
date: ""
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f706e7776d1540ee"
---

<!-- page 1 -->

GUIDELINES FOR ADMISSION TO MCA PROGRAMME
SESSION 2026-27
1.

Applications are invited for Admission into Two Years Master of Computer Applications
(MCA) Programme at HBTU, Kanpur for the session 2026-27. These guidelines are being
released for information purpose only. Online Registration and Fee Payment of Rs. 2500/(Non-refundable) shall be made Online through the website: https://hbtu.admissions.nic.in
or www.hbtu.ac.in

2.

Admissions will be made on the basis of merit of NIMCET-2026. All the information in
connection with MCA Admission 2026 shall be made available through the admission
website: https://hbtu.admissions.nic.in and https://www.hbtu.ac.in. The candidates are
advised to regularly visit these websites. University will not be responsible for any loss to
candidate due to the lack of communication.

3.

The allotment of seats through counselling will be carried out strictly on merit in accordance
with the NIMCET-2026 rank of the candidate.

4.

Candidates are advised to read these guidelines carefully, check their eligibility and applicable
reservation category etc. before filling and submitting the Online Registration Form.
University will not be responsible for any error of judgement on the part of the candidate.

5.

All eligible Indian residents may apply for the MCA programme. There is no age limit for the
candidates seeking admission to the MCA programme at HBTU Kanpur.

6.

Academic Qualifications
Bachelor’s Degree under 10+2+3 or 4 years pattern of education in Mathematics /
Statistics / Engineering / Technology or relavant Bachlor’s degree in Science with
mathmatics as a subject or Bachelor in Computer Application with a minimum aggregate
of 55% marks or equivalent CGPA (50% or equivalent CGPA for SC/ ST / OBC-NCL /
PwD) from a University recognized by UGC.

7.

All candidates whose qualifying examination result is pending may participate in the admission
process with appearing status. However, such candidates must submit their qualifying
examination result and produce the original documents at the time of Offline Document
Verification at HBTU, Kanpur, before seat allotment. Failure to submit the required documents
within the prescribed time shall result in cancellation of candidature.

8.

Accepting admission in HBTU, Kanpur implies the acceptance by the candidate and his / her
parents or guardians of all the terms and conditions laid down by the University. Any change

<!-- page 2 -->

in the rules, regulations, fee and other specific conditions etc. of the University shall apply
mutatis mutandis to the admitted candidates.
9.

Candidates claiming the benefit of any reserved category or sub-category must indicate the
same in the Online Registration Form and upload the relevant supporting documents during
the document-upload period. All such candidates shall be required to appear physically at
HBTU, Kanpur for Offline Document Verification and produce the original certificates along
with one self-attested photocopy of each document. The formats of the required certificates
shall be available on the University website. The OBC certificate shall be accepted only if it is
issued on or after 01.04.2026, as applicable for Non-Creamy Layer status. Candidates
belonging to states other than Uttar Pradesh shall be eligible only for vertical reservation,
subject to submission of a valid category certificate issued by the Central Government.
Horizontal reservation benefits shall be applicable only as per the applicable rules and
submission of valid supporting documents. (Offline Document Verification shall not be conducted
on Saturdays, Sundays and notified public holidays.)

10. If any document / declaration submitted by the candidate is found to be false at any stage, his
/ her admission will be cancelled and he / she may be liable for prosecution under the law.
11. Tentative schedule of Online Counselling, Procedure, MCA Seat Matrix, Fee Deposition
details are listed in Table 1, Table 2 and Table 3, respectively.
12. Reservation of Seats
a) Vertical Reservation:
Category
(a) Scheduled Caste
(b) Scheduled Tribe
(c) Other Backward Classes

Percentage of Reservation
21%
02%
27%

b) Horizontal Reservation (Sub-categories):
Sub-category

Code

a. Dependents of Freedom Fighters
b. Sons / Daughters of Defence Personnel
retired (superannuated) or killed /
Disabled in action
c. Handicapped / Disabled persons
d. Girls

FF
AF

Maximum Percentage
of Total Seats
02%
05%

PH
GL

05%
20%

c) The candidates can be given only one type of horizontal reservation out of FF / AF /
PH(Certificate no. 4, 5 & 6 respectively). However, the Girl candidates can also claim
for any one of FF / AF / PH along with GL category.
d) Economically Weaker Section (EWS) Quota / Reservation : Candidates who wish to
avail the benefit of EWS quota must not be covered under the existing scheme of
reservation for the Scheduled Castes, Scheduled Tribes and the Socially and Economically

<!-- page 3 -->

Backward Classes. They must produce Certificate No. 12 issued by the Government Officer
not below the rank of Tehsildar to claim the benefit of this reservation.
e) Requests for the change of category / sub-category filled during Online Registration
Form shall not be entertained under any circumstances.
f) Category / sub-category claims must be supported by the relevant certificates as per the
format provided at the time of Document Verification. Otherwise, the allotment will be
cancelled and the candidates shall be treated in General Category in the next round of
counselling.
g) Advantage of horizontal reservation in Armed Forces sub-category is available to sons /
daughters of Defence Personnel.
h) Benefits of GL subcategory will automatically be given to all eligible female candidates.
i) Candidates belonging to other states will have to produce category certificate according to
the Centre Government list for reserved category.
13. Medical Standards
a) Candidates will have to submit a certificate of Medical Fitness / Handicapped on relevant
Certificate at the time of Verifications at HBTU, Kanpur.
b) The medical standards prescribed are given below:
Height
Weight
Chest measurement
Heart and lungs
Hernia, Hydrocele, Piles etc.
Vision

Hearing

Candidates should be physically and mentally fit to
pursue his / her studies in an opted course.
No abnormality
Presence of any of these is to be corrected before
joining
Normal, if defective, it must be got corrected to 6/9
in the better eye and 6/12 in the worse one. Eyes
should be free from congenital or any other disease
Normal, If defective, it must be got corrected before
joining.

Physically Handicapped / Disabled:
Physically Handicapped / Disabled persons will have a minimum of 5% reservation on the
basis of impairment and mentioned below:
Type I
Type II
Type III

Minimum 40% permanent Visual impairment
Minimum 40% permanent Locomotors disability
Minimum 40% permanent speech and Hearing
impairment
Note: Physically handicapped / Disability certificate should be issue by CMO of the district.
14. All the formats of certificates will be available on Admission
www.hbtu.admissions.nic.in and University website www.hbtu.ac.in.
15. University reserves the right to modify the Guidelines as and when required.

Website

<!-- page 4 -->

16. Detailed stepwise Online Counselling Procedure(Note: Read the instruction carefully. All steps are time bound as stated in Table- 3)
[I]- Online Registration and Document Upload:
i.

Candidates shall register online through https://hbtu.admissions.nic.in by
depositing the Registration Fee of Rs. 2,500/- (Non-Refundable).
During registration, candidates shall fill in all personal, academic, category and
other required details carefully. Once the registration form is submitted, no
correction or modification shall be permitted.
Candidates shall upload scanned copies of all required documents, including
qualifying examination mark sheets, Class X certificate for date of birth proof,
category certificate, domicile certificate, income certificate, sub-category
certificate and other applicable documents (Table-1).
Candidates who fail to complete online registration, fee payment or document
upload within the prescribed period shall not be considered for the admission
process.

ii.

iii.

iv.

[II]- Offline Document Verification:
i.

The candidates shall be required to visit HBTU, Kanpur for Offline Document
Verification on the date and time notified by the University.
During Offline Document Verification, candidates must produce all original
documents along with one set of self-attested photocopies for verification and
submission.
Candidates who fail to appear for Offline Document Verification or fail to produce
the required original documents within the prescribed period shall not be
considered for seat allotment.
Only those candidates whose documents are successfully verified shall be treated
as eligible for seat allotment.

ii.

iii.

iv.

[III]- First Round Results & Seat Allotment: View result, pay academic fee (if seat is
allotted)
In case of seat allotmenti.

The candidate will be allowed to deposit full Academic Fee of Rs. 1,20,000/- in
stipulated time period and may be able to download Provisional Admission letter. Also,
candidate has to enroll on HBTU ERP through the University website: www.hbtu.ac.in.
Note:


Non-deposition of fee will lead to cancellation of allotted seat. This seat will be
considered vacant for next round of counselling.



Candidates must download all the letters like document verification letter as
counselling process progresses. Finally download Provisional admission letter after

<!-- page 5 -->

depositing full academic fee as proof of admission in University and for future
reference.
ii.

If the candidate is not interested in further counselling process, he/she may exercise
‘WITHDRAWN’ option (check table-1). In such cases, Academic Fee will be
refunded as per Refund Policy.

In case of no seat allotmentThe candidates are advised to wait and check the next round of seat allotment results.
[III] Second Round Results & Seat Allotment: View result, pay academic fee (if seat is
allotted)
In case of seat allotmenti.

The candidate will be allowed to deposit full Academic Fee of Rs. 1,20,000/- in
stipulated time period and may be able to download Provisional Admission letter. Also,
candidate has to enroll on HBTU ERP through the University website: www.hbtu.ac.in.
Note:


Non-deposition of fee will lead to cancellation of allotted seat. This seat will be
considered vacant for next round of counselling.



Candidates must download all the letters like document verification letter as
counselling process progresses. Finally download Provisional admission letter after
depositing full academic fee as proof of admission in University and for future
reference.

iii.

If the candidate is not interested in further counselling process, he/she may exercise
‘WITHDRAWN’ option (check table-1). In such cases, Academic Fee will be
refunded as per Refund Policy.

In case of no seat allotmentThe candidates are advised to wait and check the next round of seat allotment results.
[III] Third Round Results & Seat Allotment: View result, pay academic fee (if seat is
allotted)
In case of seat allotmenti.

The candidate will be allowed to deposit full Academic Fee of Rs. 1,20,000/- in
stipulated time period and may be able to download Provisional Admission letter. Also,
candidate has to enroll on HBTU ERP through the University website: www.hbtu.ac.in.
Note:


Non-deposition of fee will lead to cancellation of allotted seat. This seat will be
considered vacant for next round of counselling.



Candidates must download all the letters like document verification letter as

<!-- page 6 -->

counselling process progresses. Finally download Provisional admission letter after
depositing full academic fee as proof of admission in University and for future
reference.
iv.

If the candidate is not interested in further counselling process, he/she may exercise
‘WITHDRAWN’ option (check table-1). In such cases, Academic Fee will be
refunded as per Refund Policy.

In case of no seat allotmentThe candidates are advised to wait and check the next round of seat allotment results.

<!-- page 7 -->

Table 1: Ist phase online counselling based on NIMCET-2026 Score
STEP

Activity

Details

STEP 1

Online Registration

Online Registration at https://hbtu.admissions.nic.in &
Deposit Registration Fee of Rs. 2500/- (Non Refundable)

STEP 2

Online Document Upload

STEP 3

Offline Document Verification

STEP 4

First Round Seat Allotment

STEP 5

Second Round Seat Allotment

Candidates shall upload all required documents through
the admission portal.
Candidates shall visit HBTU, Kanpur with original documents
and one set of self-attested photocopies for Offline Document
Verification.
View Result
Deposit Annual Academic Fee Rs. 1,20,000/-.
Withdrawal / Cancellation
If candidate opts for Withdrawal or fails to satisfy any of
the above activity in stipulated time, then the candidate
will automatically be out of counselling process.
Refund will be made in due course of time as per refund policy.
View Result
Deposit Annual Academic Fee Rs. 1,20,000/-.

STEP 6

Third Round Seat Allotment

Withdrawal / Cancellation
If candidate opts for Withdrawal or fails to satisfy any of
the above activity in stipulated time, then the candidate
will automatically be out of counselling process.
Refund will be made in due course of time as per refund policy.
View Result
Deposit Annual Academic Fee Rs. 1,20,000/-.
Withdrawal / Cancellation
If candidate opts for Withdrawal or fails to satisfy any of
the above activity in stipulated time, then the candidate
will automatically be out of counselling process.
Refund will be made in due course of time as per refund policy.

2nd phase online counselling based on NIMCET-2026 Score,
If Any Seats Remain Vacant After Phase 1
STEP 1

Online Registration

STEP 2

Online Document Upload

STEP 3

Offline Document Verification

STEP 4

First Round Seat Allotment

Online Registration at https://hbtu.admissions.nic.in &
Deposit Registration Fee of Rs. 2500/- (Non Refundable)
Candidates shall upload all required documents through
the admission portal.
Candidates shall visit HBTU, Kanpur with original documents
and one set of self-attested photocopies for Offline Document
Verification.
View Result
Deposit Annual Academic Fee Rs. 1,20,000/-.
Withdrawal / Cancellation
If candidate opts for Withdrawal or fails to satisfy any of
the above activity in stipulated time, then the candidate
will automatically be out of counselling process.
Refund will be made in due course of time as per refund policy.

<!-- page 8 -->

STEP 5

Second Round Seat Allotment

View Result
Deposit Annual Academic Fee Rs. 1,20,000/-.
Withdrawal / Cancellation
If candidate opts for Withdrawal or fails to satisfy any of
the above activity in stipulated time, then the candidate
will automatically be out of counselling process.
Refund will be made in due course of time as per refund policy.

REFUND POLICY:
If the student chooses to withdraw from the programme in which he/she is enrolled, the University will follow
the rules as per the University/UGC norms

According to UGC rules, if a student cancels his/her admission before the formally notified last date
of admission, the university will deduct ₹5000 as processing charges, and the rest of the money will
be refunded.



In case of student withdraws after the notified last date of admission, the refund of fees will be as per
the following table:-
Sr.
No
1.

Percentage of Refund of Fees
(including processing Fee)
80%

When You withdraw Admission

2.

50%

More than 15 days but less than 30 days from
the formally notified last date of admission.

3.

0%

More than 30 days after the formally notified
last date of admission.

15 days or less after the formally notified last
date of admission

Important Note:

 All refunds will be processed after the last date of Admissions for session 2026-27.
 Please fill all the BANK ACCOUNT related information VERY CAREFULLY
for timely refund.
 If the refund gets stuck or goes to the wrong account due to the incorrect/ wrong information
furnished by the candidate, then the University will not be responsible.
 All requests regarding withdrawal process and admission fee refund must be communicated
through refunds@hbtu.ac.in. Communication via other means will not be acceptable.

<!-- page 9 -->

TABLE 1a: TENTATIVE ACTIVITY SCHEDULE

Ist phase online counselling based on NIMCET-2026 Score
Sl.
No.

Activity

1.

Online Registration
Online Document
Upload

2.

Document
Verification

Sub Activity
Online Registration & Registration Fee
Payment
Upload all required documents through
the admission portal.
Candidates shall visit for Physical
Document Verification at University
(Offline Document Verification shall not
be conducted on Saturdays, Sundays and
notified public holidays.)
1st Round Seat Allotment

3.

4.

1st Round
Counselling

2nd Round
Counselling

3rd Round
Counselling

09-07-2026 (Thursday)
to
20-07-2026 (Monday)
13-07-2026 (Monday)
to
22-07-2026 (Wednesday)
(10:00 AM to 05:00 PM)
24-07-2026 (Friday)

View Result
Deposit Full Academic Fee.

24-07-2026 (Friday)
to
27-07-2026 (Monday)

2nd Round Seat Allotment
View Result

28-07-2026 (Tuesday)

Deposit Full Academic Fee.
Withdrawal
3rd Round Seat Allotment
View Result

5.

Dates

Deposit Full Academic Fee.
Withdrawal

28-07-2026 (Tuesday)
to
30-07-2026 (Thursday)
30-07-2026 (Thursday)
31-07-2026 (Friday)
31-07-2026 (Friday)
To
01-08-2026 (Saturday)
01-08-2026 (Saturday)

FORMALLY NOTIFIED LAST DATE OF ADMISSION (PHASE 1) - 05-08-2026


Candidates must check the One-Time Payment limit of their debit card, credit card or
other selected payment mode before initiating payment.



Candidates are advised to complete the fee payment well before the last date and should
not wait until the final day or final hours. Since banks may remain closed on Saturdays,
Sundays and public holidays, candidates must ensure that their bank account,
debit/credit card, internet banking facility and transaction limits are active and sufficient
in advance. The University shall not be responsible for payment failure or delay due to
bank closure, transaction-limit restrictions, technical issues or any other reason.

<!-- page 10 -->

2nd phase online counselling based on NIMCET-2026 Score,
If Any Seats Remain Vacant After Phase 1
1.

Online Registration
Online Document
Upload

2.

3.

4.

Document
Verification

1st Round
Counselling

2nd Round
Counselling

Online Registration & Registration Fee
Payment
Upload all required documents through
the admission portal.
Candidates shall visit for Physical
Document Verification at University
(Offline Document Verification shall not
be conducted on Saturdays, Sundays and
notified public holidays.)
1st Round Seat Allotment
View Result
Deposit Full Academic Fee.
Withdrawal
2nd Round Seat Allotment
View Result
Deposit Full Academic Fee.
Withdrawal

03-08-2026 (Monday)
to
09-08-2026 (Sunday)
05-08-2026 (Wednesday)
to
12-08-2026 (Wednesday)
(10:00 AM to 05:00 PM)

To be announced later

<!-- page 11 -->

Table 2: MCA Seat Matrix for Academic Session 2026-27

Total Available Seats

78

OPNO

20

OPGL

6

OPAF

2

OPFF

1

OPPH

1

EWSNO

5

EWSGL

2

EWSAF

0

EWSFF

0

EWSPH

1

BCNO

14

BCGL

4

BCAF

1

BCFF

0

BCPH

1

SCNO

11

SCGL

3

SCAF

1

SCFF

0

SCPH

1

STNO

1

STGL

0

STAF

0

STFF

0

STPH

0

TFW

3

<!-- page 12 -->

Table 3: Fee Structure for MCA program 2026-27 1st Year Batch
S. No.
A
B
(i)
(ii)
(iii)
(iv)
(v)
(vi)

Particular
Tuition Fee
Other than Tuition Fee
Registration, Examination & Certification
Facility
Medical Fee
Training & Placement
Activity Charges
Other Charges
Caution Money
University Alumni Fund
Student Aid Fund
Contingency & Miscellaneous Charges
Total (i+ii+iii+iv+v+vi)
Grand Total (A+B)

Fee in (Rs.)
60000
10000
30500
3000
4000
3000
5000
1500
1500
1500
60000
1,20,000.00

Checklist for offline document verification:
1.

Original Marksheet of class 10+2/ intermediate/ qualifying examination (All
Years).
2. Original Class-X/ 10th certificate for date of birth proof.
3. Original category certificate. [SC/ST/OBC/EWS/PWD etc.]
4. Original certificate for domicile/ resident proof (If applicable).
5. Original income / tuition Fee waiver certificate (If applicable).
6. Original Sub category certificate (If applicable).
7. Medical certificate/ undertaking for medical fitness.
8. 4 Passport size photographs
9. Self-attested photocopies of all the above relevant documents for submission.
10. Gap Affidavit
11. Online Modes of Fee payment (Fee amount Rs.1,20,000/-[one Lakh Twenty
thousand only]):
* Candidates must check the One Time Payment limit of their debit/credit card.
*Full payment will be through any one of the above modes (partial payment is not
allowed).
