---
doc_id: "aab27fdec3a380cc"
source_url: "https://uphorticulture.in/pdf/cda1.pdf"
ministry: "Horticulture and Food Processing Department, Uttar Pradesh"
title: "E-Tender Technical Document"
date: ""
pages: 3
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "972f963e716558ee"
---

<!-- page 1 -->

निदेशालय उद्यान एवं खाद्य प्रसंस्करण विभाग
उद्यान भवन 2-सप्रू al, लखनऊ।
दूरभाष : 0500--4008358.,,7052457777 ई-मेल #30॥002045 & gmail.com, dir.rfrac-up@gov.in
— nn i ee

पत्रांक-- £77 / FROST / सी०डीएएफ्मैंगोई- ‘7 2024-20 fea 26 Ari 2022
सेवा में, | & zh |

निदेशक, | 30 MAR 222 |

निदेशालय सूचना एवं जनसम्पर्क विभाग, | ; i

SOU, TTS | [69 प्रापाकर्ता ........ Cay \ |

ey eer”

विषय:- ई-निविदा सूचना प्रकाशित कराये जाने TA BON |
महोदय,

निदेशालय, उद्यान एवं खाद्य प्रसंस्करण विभाग, उ0प्र०0 लखनऊ के अन्तर्गत स्थापित रिजनल फूड रिसर्च
एण्ड एनालिसिस सेन्टर GiRobso) हेतु ई-निविदा सूचना में अंकित विवरण अनुसार सी0डी0ए0 मैंगो, लखनऊ
हेतु राष्ट्रीय / अन्तर्राष्ट्रीय स्तरीय wat द्वारा की जानी है। अतः सम्बन्धित निविदा सूचना छः-छ: प्रतियों में सीडी
सहित संलग्नकर आपकी सेवा में इस अनुरोध के साथ प्रेषित हैं कि कृपया इसका प्रकाशन प्रदेश एवं राष्ट्रीय स्तर
के प्रमुख समाचार पत्रों यथा दैनिक जागरण, अमर उजाला, हिन्दुस्तान (हिन्दी) व टाइम्स ऑफ इण्डिया एवं
हिन्दुस्तान टाइम्स आदि (अंग्रजी संस्करणों) में निःशुल्क प्रकाशित कराने का कष्ट ot) सम्बन्धित समाचार पत्रों की
एक-एक प्रति अधोहस्ताक्षरी को भेजने हेतु भी सम्बन्धित समाचार पत्र को निर्देशित करने का कष्ट करें।
संलग्नक:- SIGE |

भवदीय
(डॉ0 आरएके/तोमर)
निदेशक
पृष्ठांकन der / तद्‌ दिनांक।
प्रतिलिपि:-- निम्नलिखित की सेवा में सूचनार्थ प्रेषित:-
4. अपर मुख्य Aad, उद्यान एवं खाद्य प्रसंस्करण, उ0प्र0 शासन लखनऊ।
डॉ aie
निदेशक

<!-- page 2 -->

निदेशालय उद्यान एवं खाद्य प्रसंस्करण विभाग
क्षेत्रीय खाद्य अनुसंधान एवं विश्लेषण केन्द्र,
उद्यान भवन 2-सप्रू मार्ग लखनऊ |
दूरभाष : 0500--4008358,,705257777 ई-मेल #॥30॥002045& gmail.com, dir.rfrac-up@gov.in
web site:www.rfracgov.in,www.uphorticulture.in
—_————————————————————E—————EeEEE——eeeeeeeeeeeeeeeeeeee
qWaie— 677 /आर/णफैक0,/ सी0डी0ए०मैंगो /202:-22 दिनांक: 30 मार्च,2022
ई-निविदा सूचना के माध्यम से क्लस्टर विकास एजेंसी सी0डी0ए0 मैंगो हेतु निविदा सूचना
आमन्त्रण
राष्ट्रीय बागवानी बोर्ड (एनएचबी), कृषि और किसान कल्याण मंत्रालय द्वारा क्षेत्रीय खाद्य अनुसंधान और
विश्लेषण केंद्र (आर-फैक), उत्तर प्रदेश को क्लस्टर विकास एजेंसी (सीडीए) के रूप में नामित किया गया है।
लखनऊ को आम aR विकास कार्यक्रम (सीडीपी) के कियान्वयन के लिए उत्तर प्रदेश को आम फसल हेतु
की मूल्य श्रृंखला के लिए लखनऊ wer के विभिन्‍न कार्यक्षेत्रों के कार्यान्वयन के लिए कार्यान्वयन
एजेंसी / एजेंसियों (आईएएस) की संस्तुति करेगा, अर्थात।
अ) पूर्व-उत्पादन और उत्पादन।
ब) फसल कटाई के बाद प्रबंधन और मूल्य संवर्धन ।
स) wae, विपणन और ब्रांडिंग |
आर-फैक, उत्तर प्रदेश, ऑनलाइन पोर्टल (http:/Avww.nhb.goy.in/Online Application/
Registration Form.aspx) के माध्यम से लखनऊ क्लस्टर विकास के लिए cacy विकास कार्यक्रम के
कार्यान्वयन के लिए अपने प्रस्ताव प्रस्तुत करने के लिए पात्र कार्यान्वयन एजेंसियों से प्रस्ताव आमंत्रित करता है।
इच्छुक एजेंसियां वेबसाइट जज ग्र0,200.॥ , www.rfracgov.in और www.uphorticulturein से
“प्रस्तावों के लिए कॉल” प्रस्तुत करने की प्रक्रिया और अधिक जानकारी प्राप्त कर सकती हैं।
4 निविदा का मूल्य : 40,000+जी0एस0टी
2 आरएएफए0पी0 पब्लिश डेट : 08-04-2022
30 प्री-बिड कन्फेन्स वाया वर्चुअल प्लेटफॉर्म : 26-04-2022
4 2 प्री-बिड़ कन्फेन्स वाया वर्चुअल प्लेटफॉर्म : 20-05-2022
5 लास्ट डेट एण्ड टाईम OR सबमिशन आफ द : 08-06-2022
कमप्लीट प्रोपोजल्स एलोग विद डी0पी0आर0
6 प्रेजेंटेशन बाई शॉर्टलिस्ट एजेंसी : दू बी नोटिफाइड लाटर
प्रस्ताव प्रस्तुत करने की अंतिम तिथि 08.06.2022 (इस आरएफपी के जारी होने की तारीख से 60 दिन)
है। आर-फैक, उत्तर प्रदेश, किसी भी समय बोली को रद्द करने या किसी भी नियम और शर्तों में
संशोधन,/ वापस लेने का अधिकार सुरक्षित रखता है। बिना कोई कारण बताए आरएफपी दस्तावेज में निहित है।
(डॉ0 ही
निदेशक, आर-फैक

<!-- page 3 -->

Horticulture and Food Processing,U.P.
Regional Food Research and analysis centre,Udyan Bhawan,
2-sapru marg,Lucknow-226002
Telephone:0522-4008358,7052I57777 Email: rfraclko20I5@gmail.com, dir.rfrac-up@gov.in
web site:www.rfracgov.in, www.uphorticulture.in
ee eee
-E-TENDER NOTICE FOR THE CLUSTER DEVELOPMENT AGENCY CDA MANGO
File No. 677 Date: March 30, 2022
Regional Food Research and Analysis Centre (RFRAC), Uttar Pradesh has been identified as a Cluster
Development Agency (CDA) by National Horticulture Board (NHB), Ministry of Agriculture & Farmers
Welfare for the implementation of Cluster Development Programme (CDP) in Lucknow Mango
Cluster of Uttar Pradesh. The CDA shall recommend the Implementing Agency / Agencies (IAs) for
the implementation of different verticals of Lucknowcluster for Value chain of Mango crop, namely,
a) Pre-Production and Production
b) Post-Harvest Management and Value addition
c) Logistics, Marketing and Branding
RFRAC, Uttar Pradesh,invites proposals from the eligible Implementing Agencies to submit their proposals
for implementation of Cluster Development Programme for Lucknow cluster through online
portal(hitp://www.nhb.gov.in/OnlineApplication /RegistrationForm.aspx).
Interested agencies may obtain further information and the procedure for submitting the “Call for
Proposals” from the websites: www.nhb.gov.in , www.rfracgov.in and www.uphorticulture.in
i Activity Description Date
4,__ [Tender Fee 0,000+GST
2. |RFP Publish date 08% April 2022
3. |I*Pre-Bid Conference via virtual platform 26" April 2022
4. [24 Pre-Bid Conference via virtual platform | व6ण May 2022
5. |Last date and time for submission of the complete proposals along with| 08० June 2022 |
DPR
Presentation by shortlisted agencies To be notified
later
Last date for submission of proposals is 08/06/2022(60 days from the date of issuance of this RFP).RFRAC,
Uttar Pradesh, reserves the right to cancel the bid at any time or amend / withdraw any of the terms and
conditions contained in the RFP document without assigning any reason thereof. \
(Dr. S.K. ee
Director,rfrac
