---
doc_id: "4bcbabde1c331a2c"
source_url: "https://cdnbbsr.s3waas.gov.in/s304048aeca2c0f5d84639358008ed2ae7/uploads/2023/08/2023080110.pdf"
ministry: "Madan Mohan Malaviya University of Technology, Uttar Pradesh"
title: "Counselling Guidelines for Admissions through CUET(PG)-2023"
date: ""
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "45f598187469e1fe"
---

<!-- page 1 -->

Counselling Guidelines
for
Admissions through CUET(PG)-2023
MTech/MBA/MCA/M.Sc./B.Tech-II (Lateral Entry) for BSc
Graduates

Madan Mohan Malaviya University of Technology
Gorakhpur-273010

Wednesday, 21 September 2023

Page 1

<!-- page 2 -->

Information cum-Guidelines for Admission through CUET(PG)-2023
MTech/MBA/MCA/M.Sc./B.Tech-II (Lateral Entry) for BSc Graduates
1. Applications for admission to following programs for the academic session 2023-24 are to
be submitted online only:
a.
b.
c.
d.
e.

MTech
MBA
MCA
M.Sc.
B.Tech.-II (Lateral Entry) for BSc Graduates

2. Candidates are required to fill the Application Form online for counselling through online
mode using the link provided on university website www.mmmut.ac.in.
3. All the eligible candidates of CUET(PG)-2023 may apply for online counselling for the
admission in MTech/MBA/MCA/M.Sc./B.Tech.-II (Lateral Entry) for BSc Graduates at M. M.
M. University of Technology, Gorakhpur for the academic session 2023-23 as per their
eligibility criteria given in University Admission Brochure-2023.
4. The online counselling registration fee is Rs. 2500/- (Non-Refundable) which can be paid in
online mode during online registration process.
5. Candidates are advised to read these guidelines carefully, check their eligibility and
applicable reservation category, subcategory, gender etc. before filling and submitting the
online registration form. The university shall not be responsible for any mistake committed
by the candidates in filling the online application form.
6. The admission to MTech/MBA/MCA/M.Sc/B.Tech.-II (Lateral Entry) for BSc Graduates is
open to CUET(PG)-2023 qualified candidates in respective program who have passed the
qualifying examination from an institution located in U.P. or whose parents are domicile of
U.P subject to the eligibility conditions given in the guidelines/University admission
brochure-2023. If the candidate has passed qualifying examination from outside U.P.,
he/she has to upload domicile certificate at the time of uploading of the documents.
Candidates whose parents are defence personnel settled or posted in UP on the entrance
date of CUET(PG)-2023 or whose parents are officers or employees of All India Services
belonging to UP cadre must upload relevant certificates. (See Category Definitions at point
3.3 of University Admission Brochure-2023 available at www.mmmut.ac.in).
7. The candidates who register online, pay registration fee, lock their choices etc. successfully
within stipulated time will be considered for seat allotment and document verification.
8. There is no provision to change/modify the locked choices (for MTech/B.Tech-II only) at any
stage of the counselling.
9. No fresh candidate will be allowed to register for counselling after the last date of the
registration, as per the counselling schedule available on the website.

2

<!-- page 3 -->

10. For any clarification regarding eligibility, category, subcategory, etc. for admission at
MMMUT, Gorakhpur, please refer to the University Admission Brochure-2023. The
information given in University Admission Brochure-2023 shall be final and binding upon all
the candidates.
11. Accepting admission in MMMUT Gorakhpur implies the acceptance by candidate and
his/her parents/guardians with all the provisions given in the guidelines. Any change in the
rules, regulations, fee etc. of the University shall apply mutatis mutandis to the admitted
candidates.
12. Candidates claiming the benefits of EWS reservation have to upload EWS certificate issued
after March 31, 2023 on the prescribed format given in Admission Brochure-2023, failing
which the candidate will be considered for seat allotment as per her/his General Rank.
13. Candidates claiming benefits of OBC reservation have to upload OBC certificate issued after
March 31, 2023 (mandatory due to the condition of creamy layer for OBC) on the
prescribed format given in Admission Brochure-2023, failing which the candidate will be
considered for seat allotment as per her/his General Rank.
14. All the relevant original documents will be verified at the time of physical reporting at
university along with one set of self-attested copy of required documents, failing which the
provisional admission offered by university will be cancelled and fee deposited will be
forfeited.
15. MTech/MBA/MCA/M.Sc./B.Tech-II (Lateral Entry) for BSc Graduates candidates, whose
result of the qualifying examination is awaited till the date of uploading the scanned copy
of original document, due to any reason whatsoever shall have to upload an undertaking
that they will produce their original documents on or before 30 September 2023, failing
which admission of such candidates will be cancelled and fee deposited will be forfeited.
16. If a candidate fails to upload the relevant documents against the claim made by the
candidate in the application form submitted to CUET(PG)-2023 or her/his claim in
application form within stipulated time, will be liable for rejection of that claim and
allotment of seats will be done as per modified record of the candidate.
17. If any information (document/declaration etc.) given/uploaded/submitted by the
candidate is found false at any stage, his/her admission shall be cancelled, deposited
University fee will be forfeited, and he/she may be liable for prosecution under the law. In
case of any legal dispute, the jurisdiction will be limited to Gorakhpur court only.
18. The candidate has to deposit the confirmation fee of Rs. 40,000.00 (Rupees Forty Thousand
only) within stipulated time period after the seat allotment and document verification,
failing which his/her allotted seat will be cancelled, and he/she cannot participate in
subsequent rounds of seat allotment.
19. If a candidate wants to withdraw his / her candidature after seat allotment and deposition
of the confirmation fee, then fee will be refunded as per below University Fee Refund
policy.
3

<!-- page 4 -->

S No.
1.

Date of Receipt of Application
On or before the 11 September 2023 11:59PM

2.
3.

From 12 September 2023
Tentative Date for reporting

Amount to be refunded
Total deposited fee minus Rs. 1000
(Processing Fee)
Only Caution Money
6 September, 2023

Process for withdrawal/cancellation of admission and fee refund
(i)
(ii)
(iii)

The candidate may submit an application for the cancellation of his/her admission and fee
refund request through the login of counselling portal.
Once the cancellation request will be received, it will be processed, and refund amount will be
credited to the same account through which the fee was deposited.
Any cancellation request sent through other than counselling portal will not be entertained.

#As per Guideline issued by AICTE for the Academic Session 2023-24.
20. If any of the qualifying examination Board/University awards letter grades without
providing an equivalent percentage of marks on the grade sheet, then the candidate must
obtain a certificate from the Board/ University specifying equivalent marks/percentage and
upload along with qualifying examination marksheet at the time of document uploading. In
case, such certificate is not provided by the candidate, the decision of the University
Admission Committee regarding his/her eligibility shall be final.
21. The allotment of seats through counseling will be carried out strictly in accordance with the
Merit list prepared by the University based on CUET(PG)-2023 results of the candidates,
subject to the order of preference given for the seat and availability of seat in the category
and their respective sub-category.
22. No relaxation of confirmation fee will be given to any candidate at the time of granting
admission.
23. All information in connection with Admissions-2023 shall be made available through the
University website www.mmmut.ac.in. The candidates are advised to refer the website
regularly/frequently, failing which MMMUT Gorakhpur will not be responsible for any loss
due to the lack of communication.
Note: For detail information, University Admission Brochure-2023 shall be referred.

4

<!-- page 5 -->

Merit List Preparation using CUET(PG)-2023 Result

2.1 Admission in MTech/MBA/MCA/M.Sc./B.Tech. -II (Lateral Entry) for BSc Graduates
The seats in MTech/MBA/MCA/M.Sc. /B.Tech.-II (Lateral Entry) for BSc Graduates will be filled
through the CUET(PG)-2023 as per the Merit List prepared by the University based on CUET(PG)-

2023 results of the candidates, who have passed the qualifying examination from any institution
located in U.P. or whose parents are domicile of U.P subject to the eligibility conditions given in this
section. If the candidate has passed qualifying examination from outside of U.P., he/she must upload
domicile certificate at the time of uploading the document.
2.1.1 Eligibility for Admission in MTech:
Civil Engineering Department:
Test Paper for CUET(PG) -2023: MTQP02
(i) MTech (Environmental Engineering): B.E./B.Tech. or equivalent Engineering degree in Civil/
Environmental/ Chemical/ Structural/ Agricultural/ Construction Technology/ Construction
Technology and Management with First Division or, if a division is not awarded, and
CGPA/CPI is adopted, 6.75 will be considered equivalent to first division.
(ii) MTech (Hill Area Development Engineering): B.E./B.Tech. or equivalent Engineering degree
in Civil/ Environmental/ Structural/ Agricultural/ Construction Technology/ Construction
Technology and Management with First Division or, if a division is not awarded, and
CGPA/CPI is adopted, 6.75 will be considered equivalent to first division.
(iii) MTech (Structural Engineering): B.E./B.Tech. or equivalent Engineering degree in Civil/
Structural/ Construction Technology/ Construction Technology and Management with First
Division or, if a division is not awarded, and CGPA/CPI is adopted, 6.75 will be considered
equivalent to first division.
(iv) MTech (Earthquake Engineering and Seismic Design): B.E./ B.Tech. or equivalent Engineering
degree in Civil/ Structural/ Construction Technology/ Construction Technology and
Management with First Division or, if a division is not awarded, and CGPA/CPI is adopted,
6.75 will be considered equivalent to first division.
Computer Science & Engineering Department:
Test Paper for CUET(PG) -2023: MTQP04
(i) MTech (Computer Science and Engineering): B.E./B.Tech. or equivalent Engineering degree
in Computer Science/ Computer Sc. and Engineering/ Computer Engineering/ Software
Engineering with First Division or, if a division is not awarded, and CGPA/CPI is adopted, 6.75
will be considered equivalent to first division.
Information Technology & Computer Application Department
Test Paper for CUET(PG) -2023: MTQP04
(i) MTech (Information Technology): B.E./B.Tech. or equivalent Engineering degree in
Information Technology/Computer Science/Computer Sc. and Engineering/Computer

5

<!-- page 6 -->

Engineering/Software Engineering/MCA with First Class or, if a class/ division is not awarded,
and CGPA/CPI is adopted, 6.75 will be considered equivalent to first division.
Electrical Engineering Department
Test Paper for CUET(PG) -2023: MTQP10
(i) MTech (Power Electronics& Drives): B.E./B.Tech. or equivalent Engineering degree in either
Electrical Engineering (EE) or Electrical and Electronics Engineering (EN) with First Division or,
if a division is not awarded, and CGPA/CPI is adopted, 6.75 will be considered equivalent to
first division.
(ii) MTech (Control & Instrumentation): B.E./B.Tech. or equivalent Engineering degree in
Engineering /Technology in Electrical Engineering, Electrical and Electronics Engineering,
Instrumentation and Control Engineering, and Instrumentation Engineering with First
Division or, if a division is not awarded, and CGPA/CPI is adopted, 6.75 will be considered
equivalent to first division.
Electronics & Communication Engineering Department
Test Paper for CUET(PG) -2023: MTQP05
(i) MTech (Nanoelectronics & VLSI): B.E./B.Tech. or equivalent Engineering degree in Electronics
Engineering,
Electronics
and
Communication
Engineering,
Electronics
and
Telecommunication Engineering and Nano Technology with First Division or if a division is not
awarded, and CGPA/CPI is adopted, 6.75 will be considered equivalent to first division.
(i) MTech (Wireless and Optical Communication): B.E./B.Tech. or equivalent Engineering degree
in Electronics Engineering, Electronics and Communication Engineering, Electronics and
Telecommunication Engineering, Electrical and Electronics Engineering, Electronics &
Instrumentation Engineering, Electronics Instrumentation & Control and Internet of Things
with First Division or, if a division is not awarded and CGPA/CPI is adopted,6.75 will be
considered equivalent to first division.
Mechanical Engineering Department
Test Paper for CUET(PG) -2023: MTQP07
(i) MTech (Computer Integrated Manufacturing): B.E./B.Tech. or equivalent. Engineering degree
in Mechanical / Production / Industrial / Manufacturing / Automobile / Aerospace
Engineering/Aeronautical Engineering with First Divisionor,if a division is not awarded and
CGPA/CPI is adopted,6.75 will be considered equivalent to first division.
(ii) MTech (Energy Technology and Management): B.E./B.Tech. or equivalent Engineering degree
in Mechanical / Production / Industrial /Energy /Chemical /Automobile/ Aerospace
Engineering /Space Engineering and Rocketry with First Division or, if a division is not
awarded and CGPA/CPI is adopted,6.75 will be considered equivalent to first division.
2.1.2 Eligibility for Admission in MBA.:
(a) The candidate should have passed the recognized bachelor’s degree of minimum three years
duration from any University of India as recognized by UGC with at least 50% marks (45% in
case of candidates belonging to SC/ST category) in the qualifying examination.

6

<!-- page 7 -->

(b) Qualified in Test Paper for CUET(PG) -2023: COQP12
2.1.3 Eligibility for Admission in MCA:
(a) The candidate should have passed BCA/ bachelor’s degree in computer science engineering
or equivalent degree OR passed B.Sc./ B.Com./ B.A. with minimum passing mark in
Mathematics at 10+2 Level or at Graduation Level AND obtained minimum 50% marks (45%
in case of candidates belonging to SC/ST category) in the qualifying examination.
(b) Qualified in Test Paper for CUET(PG) -2023: SCQP09
2.1.4 Eligibility for Admission in MSc Physics:
(a) The candidate should have passed the recognized bachelor’s degree in science stream of
minimum three years duration from any University of India as recognized by UGC. The
candidates must have passed qualifying examination with Physics as a subject for all the
three years and with mathematics as another subject for at least two years and obtained
minimum 50%marks (45% in case of candidates belonging to SC/ST category) in the qualifying
examination.
(b) Qualified in Test Paper for CUET(PG) -2023: SCQP24
2.1.5 Eligibility for Admission in MSc Mathematics:
(a) The candidate should have passed the recognized bachelor’s degree in science stream of
minimum three years duration from any University of India as recognized by UGC. The
candidates must have passed qualifying examination with Mathematics as a subject for all
the three years and obtained minimum 50% marks (45% in case of candidates belonging to
SC/ST category) in the qualifying examination.
(b) Qualified in Test Paper for CUET(PG) -2023: SCQP19
2.1.6 Eligibility for Admission in MSc Chemistry:
(a) The candidate should have passed the recognized bachelor’s degree in science stream of
minimum three years duration from any University of India as recognized by UGC. The
candidates must have passed qualifying examination with Chemistry as a subject for all the
three years and obtained minimum 50% marks (45% in case of candidates belonging to SC/ST
category) in the qualifying examination.
(b) Qualified in Test Paper for CUET(PG) -2023: SCQP08
2.1.7 B.Sc. graduates:
(a) Passed three years B.Sc. degree from any recognized University of India as defined by UGC
with at least 60% marks (55% in case of candidates belonging to SC/ST category) and having
passed 10+2 exam with Mathematics as a subject.
The candidates belonging to B.Sc. Graduates shall be considered only on remaining vacant
seats after filling the seats with the candidates belonging to the Diploma Holder through
CUET(UG)-2023
(b) Qualified in Test Paper for CUET(PG) -2023: SCQP19

Merit List Preparation
The Merit List will be prepared by using normalized score obtained by candidates in the
respective Test Papers for MTech/MBA/MCA/M.Sc./B.Tech. -II (Lateral Entry) for BSc
Graduates.
7

<!-- page 8 -->

Tie Breaking in case of Equal Normalized Score
If there is a tie in the normalized score obtained by two or more candidates, the order of merit
for such candidates shall be decided in the following order
1. Rank determination by normalized score of Qualifying Test Papers in CUET(PG)-2023.
Candidates obtaining higher normalized score will be given a better rank.
2. Rank determination by age of the candidate. If one candidate is older than another, then the
older candidate will have a higher rank compared to the younger candidate.
3. Rank determination by Counselling Registration ID provided to candidates by MMMUT.
Candidate having lesser Registration ID will have a higher rank compared to higher Registration
ID.

8

<!-- page 9 -->

Counselling Process
Steps of the Online Counselling Process
The candidates are required to read the following steps of online counselling carefully before
proceeding for online registration followed by online choice filling etc.
Step-1: Online Registration for Counselling
All the candidates eligible for counselling, will have to use their CUET(PG)-2023 application form
number, mobile number and email id to register for counselling through website
“www.mmmut.ac.in”.
Note:
If the personal data of the candidate is found incorrect at the time of online verification of
certificates either at the time of reporting or at any later stage, the allotment of seat/ admission
is liable to be cancelled and his/her university fee will be forfeited.
Step-2: Payment of Counseling Fee
After successful registration, the candidate must pay the counselling Fee of Rs. 2500/- (nonrefundable) using online payment gateway.
Step-3: Choice Filling (Only for MTech/BTech-II)
After successful payment of counselling fee, the candidate is required to fill the choices in order
of his/her preference available as per his/her applied course for admission.
Step-4: Choice Locking (Only for MTech/BTech-II)
Once the choices are filled-in, the candidate is required to check the order of preference of
choices thoroughly and if any alterations in the order of preference are required, rearrange
them. Once the order of preference of choices are final, the candidate can lock the choices by
clicking the submit button.
After the choices are locked, candidates will not be able to change their choices under any
circumstances. A printable version of the list of choices locked along with the terms and
conditions agreed by the candidate at the time of registration will be displayed. Candidates
must take a printout (hard copy) of printable document for his/her future references .
MTech/B.Tech-II registered candidates who do not fill any choices will not be considered for
seat allotment. His/her registration fee will also not be refunded. The registered candidates
who have filled the choices but forgotten to locked choices, their filled choices will be
considered automatically locked and candidate will be considered for seat allotment.
Note: Please note that the choices (order of preference), once submitted and locked, are not
allowed to be altered/modified under any circumstances. All rounds of allotment will use this
locked choice for seat allotment.
Step-5: Merit List and Seat Allotment

9

<!-- page 10 -->

The Merit list will be prepared by the university and seat allotment will be done based on the
Merit list, final locked choices of the candidates etc., if any.
Step-6: Willingness to FREEZE or FLOAT (For MTech/B.Tech-II only)
The candidate with the allotted branch as per his/her locked choices must submit the willingness
to FREEZE or FLOAT after seat allotment. However, the candidate can also freeze his/her allotted
seat at later stage after satisfactory allotment.
Step-7: Uploading of Documents
After successful payment of counselling fee, the candidate must upload all the required
relevant documents online.
Step 8: Document Verification
All the relevant and original documents will be verified within the stipulated time at the
university. Candidates are required to bring one set of self-attested copies of required
documents. If a candidate does not report for document verification within the stipulated
time, the provisional allotment letter will be cancelled, and allotted seat will be given to other
candidate as per merit during next round of seat allotment. The candidature of such candidate
shall not be considered in any subsequent round of seat allotment except spot counselling.
Step-9: Deposition of Confirmation Fee
• The candidate is required to take the printout of the provisional allotment letter from their
login, in case of seat allotment. There is no provision of sending allotment letter individually
to the candidate by post.
• Candidates are required to pay complete Confirmation fee of Rs. 40,000.00 (Rupees Forty
Thousand only) online using the payment gateway services within the stipulated time
mentioned in the allotment letter, failing which the provisional admission offered to the
candidate will be cancelled and the offered seat will be allotted to another candidate as per
the merit. The candidature of such candidate shall not be considered in any subsequent round
of seat allotment except spot counselling.
Step-10: Deposition of remaining University Fee
Candidates are required to deposit their remaining university fee after deducting confirmation
fee before registration/reporting for academic session 2023-24.
Step 11: Physical Document Verification at University
After provisional admission, all the relevant and original documents will be verified at the time
of physical reporting at university along with one set of self-attested copy of required
documents, failing which the provisional admission offered will be cancelled and University fee
will be forfeited.

10

<!-- page 11 -->

Documents Required at the time of Uploading the Document
At the time of document uploading, scanned copy of following original documents shall be
required.
1.

Certificate of High school or equivalent examination for verification of date of birth.

2.

The candidates seeking admission in MTech/MBA/MCA/M.Sc./B.Tech-II (Lateral Entry) for
BSc Graduates should upload the scanned copy of original marksheet of their qualifying
examination. In case the result of the qualifying examination is awaited till the date of
uploading the scanned copy of original documents, the candidate shall have to upload an
undertaking (Format given at the end of this document) that they will produce their original
documents on or before September 30, 2023. In case of non-fulfilment of the eligibility
conditions by the stipulated time, the admission shall be cancelled, and the University fee will
be forfeited whatsoever the reason may be.

3.

Domicile certificate of Parents of the candidate, issued by the competent authority on
prescribed format given in University Admission Brochure -2023 must be uploaded by the
candidates, for the candidates who have passed qualifying examination from the states other
than U.P. The candidates who have passed qualifying examination from U.P need not to upload
the domicile certificate of parents.

4.

Category certificate for EWS candidate issued by the competent authority issued after March
31, 2023, if applicable, on prescribed format available in University Admission Brochure-2023.

5.

Category certificate for OBC candidate issued by the competent authority, if applicable, on
the prescribed format given in University Admission Brochure-2023 and issued after March
31, 2023 (mandatory due to the condition of the creamy layer of the society).

6.

Category certificate for SC/ST candidate issued by the competent authority, if applicable, on
the prescribed format given in University Admission Brochure-2023.

7.

Physically handicapped candidate will be required to upload a certificate issued by the Chief
Medical Officer in the prescribed format given in University Admission Brochure-2023. A
medical board, consisting of a general physician, orthopaedist, and ophthalmologist may be
referred to verify the claim of the certificate if there is any doubt.

8.

The candidate of Armed Forces category (UPAF) will be required to upload a certificate issued
by the competent authority on the prescribed format given in University Admission Brochure2023 available on the university website.
Note: Priority must be mentioned in certificate as per Govt. Order.

9.

Candidate belonging to freedom fighter's category (UPFF) will be required to upload a
certificate to this effect issued by the competent authority on the prescribed format given in
University Admission Brochure-2023 available on the university website.

10. A medical fitness certificate as prescribed in University Admission Brochure-2023 available on
university website at the time of reporting to the University.

12

<!-- page 12 -->

Important Note:
Following Candidates are not eligible to participate in various rounds of seat allotment:
a. Candidates who have not registered within stipulated time in-spite of having good mark.
b. Candidates who have registered but not filled the choices within stipulated time.
c. After seat allotment, the candidate fails to upload relevant documents within stipulated
time due to any reason whatsoever.
d. Candidate failed in online document verification.
e. The candidate fails to deposit the Seat Acceptance/Confirmation fee.

13

<!-- page 13 -->

Seat Matrix for Admission to M.Tech. programmes through CUET (PG)-2023
S.N.
1
2
3
4
5
6
7
8
9
10
11
12

M.Tech Programmes (Specialization)
Hill Area Development Engineering
Environmental Engineering
Earthquake Engineering and Seismic Design
Structural Engineering
Computer Science and Engineering
Information Technology
Power Electronics and Drives
Control and instrumentation

Intake #
22
23
22
23
23
22
23
22
23
22
23
22
270

Nanoelectronics and VLSI
Wireless and Optical Communication

Computer Integrated Manufacturing
Energy Technology and Management
Total
#

OP EWS
9
2
9
3
9
3
7
1
9
1
9
2
9
3
9
2
8
2
9
2
10
2
9
2
106 25

OBC
6
6
6
6
6
6
6
6
6
6
6
6
72

SC
4
5
4
4
5
5
4
5
5
5
5
4
55

ST
1
0
0
1
1
0
0
0
1
0
0
1
5

Remaining vacant seats after admitting GATE qualified candidates.

Intake

GN

GNOP

GNGL

GNAF

GNFF

GNHC

EWS

EWOP

EWGL

EWAF

EWFF

EWHC

BC

BCOP

BCGL

BCAF

BCFF

BCHC

SC

SCGL

SCAF

SCFF

SCHC

ST

STOP

STGL

STAF

STFF

STHC

MBA
MCA
MSc Phy
MSc Maths
MSc Chy

75
75
30
30
30

32
32
13
13
13

24
24
11
11
11

6
6
2
2
2

1
1
0
0
0

0
0
0
0
0

1
1
0
0
0

7
7
3
3
3

6
6
3
3
3

1
1
0
0
0

0
0
0
0
0

0
0
0
0
0

0
0
0
0
0

20
20
8
8
8

14
14
7
7
7

4
4
1
1
1

1
1
0
0
0

0
0
0
0
0

1
1
0
0
0

15 12 3
15 12 3
6 5 1
6 5 1
6 5 1

0
0
0
0
0

0
0
0
0
0

0
0
0
0
0

1
1
0
0
0

1
1
0
0
0

0
0
0
0
0

0
0
0
0
0

0
0
0
0
0

0
0
0
0
0

SCOP

Course

Seat Matrix for MBA/MCA/M.Sc. for Admission through CUET(PG)-2023 Merit

Seat Matrix for B.Tech-II Lateral (for BSc Graduates) for Admission through CUET (PG)-2023
•
•

The total seats for B.Tech.-II Lateral (for Diploma holders) Admission through CUET (UG)-2023 are mentioned in the Admission Brochure-2023.
Please note that B.Tech.-II (Lateral) seats will be filled firstly through CUET(UG)-2023 from Diploma holder candidates, if seats remain vacant after
filling the seats from Diploma Holders, the seats will be allotted to BSc Graduates through CUET(PG)-2023.
14

<!-- page 14 -->

UNDERTAKING BY CANDIDATE
(Whose Result of Qualifying Examination is awaited)
Date:_______________

I ________________________________________________________ son/daughter of
_________________________________ seeking admission in _______________
hereby submit my undertaking that I will submit/produce the evidence of having passed
the qualifying examination securing the minimum passing marks as prescribed by the
University by September 30, 2023. I am fully aware that if I fail to submit the required
document on or before September 30, 2023, my admission will be cancelled and no
claim to refund the fee will be made by me whatsoever the reason may be.

___________________________
___________________________
Counter Signed by Father/ Guardian

Signature of the Candidate
CUET(PG)-2023 Roll No___________
Mo. No. _______________________
Email Id________________________
Address_______________________
___________________________

15
