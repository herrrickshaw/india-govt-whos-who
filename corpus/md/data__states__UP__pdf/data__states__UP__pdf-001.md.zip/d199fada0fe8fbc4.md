---
doc_id: "d199fada0fe8fbc4"
source_url: "https://upite.gov.in/MediaGallery/Policies/Data-Centre-Policy-eng-2021.pdf"
ministry: "Department of IT & Electronics, Government of Uttar Pradesh"
title: "UP Data Center Policy 2021     Download Pdf       Type :  Pdf    Size :  2.30 MB    Language :  English"
date: ""
pages: 17
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "ad2b41ac85e6941d"
---

<!-- page 1 -->

\ ५ ४ हि es, WS : /
ey, || Mv \ / OF Ur : al
“A / eA / > | Wee / |
\ an : & bd A lf |
_&- \ 4 ess . > > Os 2S, a) \\ क्र \ x / |
2. ON eee’ pees \ Jn} \
- UttarPradesh..
» / = | /् \ /
( eo. \ |
Data Center Policy 2027.
\)
a |] 5 x = = Zi श् गा
wes lay === —s A as Lo
रा - = g | विज : = : = %
sit ८ 4 Yy j N N , है —
— [i 4 हू N 5 >>
Department of IT & Electronics
overnment. of Uttar. Pra radesh
eae BE. Si = = 2a = == ==

<!-- page 2 -->

2 es me)
Uttar Pradesh
Data Center Policy 202
Department of IT & Electronics, Government of Uttar Pradesh

<!-- page 3 -->

= L.c/20i9TC
Lok Bhawan, Lucknow-226002
ae LON Date : 09 April 2024 2 J
>
Qe 4 /' /
Yogi Adityanath
Chief Minister
MESSAGE Uttar Pradesh
lam delighted to announce the Uttar Pradesh Data Center 20॥0५-2024 . This
is the first Data Center Policy of Uttar Pradesh. Priorto this, there was no policy for
setting up data center parks and data center units inthe state.

UP Data Center Policy 202 sets a target investment of INR 20,000 Crores by
developing 250MW Data center industry. This will pave the way for establishment
of Data Center industry across all regions of the State.

Technology is rapidly changing our way of life and the data has become the
basic need in our lives. With more than 4 billion mobile and 45 million internet
users, the Data Centre industry growth in India is faster as compared to rest of the
world. Currently, 20 percent of the world's total data is generated in India whilst
data storage capacity within the country is limited to meager 2 percent; therefore,
most of the data is stored outside the country. Demand for data protection is also
growing in the country in view of increasing data traffic and usage as well as
confidentiality of the data. The presentation of the Data Protection Bill in the
Parliament by the Government of India in December 209 underlines the
importance of keeping the country's data in the country itself.

Development of integrated infrastructure is targeted through Uttar
Pradesh Data Center Policy-202, under the vision of 'Ease of Doing Business’.
With this, land, water, electricity, and broadband facilities will be made available
simultaneously. For the development of Purvanchal and Bundelkhand regions of
the state, financial incentives have been made more attractive. The policy also
proposes protection of consumer data within the country's border, promoting
cloud services for easy access to e-Governance services under "Digital India" and
promotion of solar energy through development of Green Data Center Parks. To
cater the need of energy for the Data Center industry, the establishment of solar
energy parks have also been envisaged.

lam confident that the Uttar Pradesh Data Center Policy-202! will prove to
be a milestone in terms of establishment and development of Data Centers in the
state.

(0५ Pax -_
(Yogi Adityanath)

<!-- page 4 -->

= L.C/209TC
99-00, Vidhan Bhawan Lucknow
Date : 09 April 2022
Fe Ss 2)
‘Re
Dr. Dinesh Sharma
Deputy Chief Minister
Uttar Pradesh
MESSAGE

To accelerate the development of the Data Center ecosystem, the Data
Center Policy-202 has been promulgated, which has provided incentives to
promote investmentin all geographical areas of the state.

The state's policy has been made in line with the proposed National Data
Center Policy of the country. The objective of this policy is to establish Uttar
Pradesh as the most suitable place for the data center industry. This will speed up
the establishment of Data Center Parks and Units, which will not only give a boost
to the economy but willalso generate direct and indirect employment in the state.

To provide a conducive policy environment for upgradation of Data Center
industry with globally competitive infrastructure, we have adopted innovative
and emerging technologies through effective utilization of skilled manpower fora
holistic and sustainable development of Data Centre ecosystem leading to the
overall economic development of the country and the state. This policy has been
initiated as an important growth driver for all-round development.

| congratulate the Department of IT and Electronics for drafting this data
center policy and encouraging Data Center ecosystemsin the state.

(Dr. Dinesh Sharma)

<!-- page 5 -->

2 L.c/20i9TC
Bapu Bhawan, UP Sachivalaya, /2 F Block,
Third Floor, Lucknow
Date : 09 April 2022
‘Se coe io q
Ko
ya
Ajit Singh Pal
State Minister
Information Technology, Electronics
Uttar Pradesh
MESSAGE

The Uttar Pradesh government has identified the Data Center industry as a
priority area for the state's economy. | am extremely pleased to announce the
Data Center Policy - 2024, with the vision of establishing Uttar Pradesh as the most
suitable place for setting up Data Center Parks and Units.

The government is keen to develop a data center ecosystem matching
global standards. Through this policy, we will become the flag bearers of Data
Center investment in the country.

Our policy promises to provide a more conducive environment to Data
Center firms in the state, keeping in mind the needs of an evolving ecosystem.
linvite the Data Center industry to come forward and take advantage of this new
policy for investment inthe state.

छा
(Ajit Singh Pal)

<!-- page 6 -->

Contents
Ly, Preamble ..naceessreororsansvanioncinavreswereanensennsarrenvonaseseannnnsasovelsriswertannenentennitenenntententnondaiyevnnocetmnnesennatenceneeio
2. Vision, Mission and Target a
Z., General Tarins!& Conditions: .iccarersesereeuersenveonenseareoneensenonnestoveeteonvctoninansenonansieneesneteanvensinentseeaeenoei’
A, Policy PrOMOUION ०००७३३७७२#००७-३६७७७७३७७३७७७७७४७७७७७७७७७७४७७४७७३७७७७#७७७७७७७#७७#-#--#########--##हरदैं
9. GOVERNANCE sisscssisssssssssvesssaccasvensursssvanecinavsesasiessns asvosaunsevosens ascanvnniensaxtavacecatanenesssinianesw cian oneennsivesensanteae
Sits ७9 लें /७७०३#४००७००७७७७७७७/७७७७४७/७॥७७७७७४७७७७४७७/#४४४७४७७॥४७७४७७७॥४७७७४७#७#####७#ह
5.2. Policy Implementation Unit [श७)५६६४७-७बबकबबललबसबनबनबलबब9न9 9959 +5 5७ 995 54७9३स_ ५4%) + ६८६ ८६६४६०४६०६६६६०४४६६६४८६ है
5:3. Empowered Cominitted ५...२०ू२०ूलललललसककससस बस भ 99 कम प सन 9+ बस $ 4 कप _न्‍बक 99» थ9 + 9 कक भ9 ४ क5 99 कब 9भ 9 +क 99 बक 4५ >9+4+४५८८ ० रह
BH. 2 . 5)... मिपलनरनललल ली लक नल कल की नली ज नल सकल जल लक कस तक सम लत तमिल कलम कल लक बल...
6... एलीगांपगा$........... ७६०६६ हरि हर हल कह हल कह कल हल बह हल
GL, Data Center शाह 0229 9/0३७७७३७७०७४४०४०००००४०४०७४०७७७७३४७४४७७०७४४७४४७७४४/७#/४८_रन्‍ह्_नह मे
68 छाए ५ ध्बनसकलकतलससस७ स9क बू9वन9स>»99»49५ ८ 4७६८६७४४७४४४६४४६७४६४८०६६६४४४४६४६७४४४०६४६४४४४४४४७४४८४४४८०३६ं
6.3. Data Center Park Developer. 4
7. Financial Incentives .......sssssssssssssesssesssssecssesssssessuussessiesusssessaeasnsseessescesnseseansecessvesasscessavessesscesneness
Tele ‘Data Celiter Parks ०००३६२३७२5२०००७०७७७७७७७७७७३७७४७७७४॥७४७४०७७४७४७/७७७७७७४४०७७७७७०७७७४४७७७/४७३/४४० रह कं
R22. Data Cite Units .,..८.२-०२७४+;>>>सन>कबबल्‍ब-बबन७७89८५६ध३८४ा४६५४३६४४४०४४३६४४०६६४६६४४६६६८६६४४६५॥६४०६४४०६४६४४४६६६००६४४६६४६४
WeS IMSMES/Startups\.ovcvervsscisennereenmrensmmmseniscanannanesiraserersenansencenmesenedsmereasecensonnsneteveenl
8. Non-Financial Incentives वैलपापाडदडडडाडददडदडदडाडदादउदददददद दाद,
8.7... Mission Critical Infrastructure ५५:०३०%८६०३३३३३३४०७३३२०७००१४०७४०६३७५१७४३३७४०४४०००३४३४०४३४४७४४२४०७४६२७-#३ 2
82. Wate 5090 iesisissieicesiiiniriciinnnnnvanncnianninnnrnniawaimnamamnnnniele
8.3. Special provisions in building MOPMS ........... cece te ese ceeeeeeecneecnesenenereseessetetsensestaeerseneee 7
8.4... Electricity Supply ...................... "० cece ceseeeee cece eesececeeeee cone cesceceeceesacereeeseeeeseesceesererereerereeeeee B
8.5. Other 5फ्०णा........................ ७५०" न_ब>_नबनन न हनन नल हनन नल हनन हल नल नह नह हल नल >० D
9: Abbreviation wiancinnanncnnnernenm ae 0

<!-- page 7 -->

4. Preamble
Data Consumption in India is at an all-time high. The rapid increase in data
traffic and consumption is driving the data storage demand and leading to
expansion of the Data Center market in the country. India’s share in the world
data is estimated to be around 20% whereas only 2% in data storage capacity.
Recent estimates say India’s 375-Megawatt (MW) Data Center capacity is
growing rapidly and expected to add more than 750 MW capacity by the end of
2025. These capacity additions would require greenfield investments to the tune
of USD 4.9 billion to fuel the future development of the sector. The data
localization mandate from Government of India is likely to further boost the
investment in Data Center businesses.
State of Uttar Pradesh has always been a major player in the IT/ITeS sector
having Noida as one of the key IT clusters in the country. Noida has emerged as
a planned, integrated, modern industrial city which has attracted investments in
IT and Electronics sectors from leading players across the globe.
The focus of State Government is also increasingly reliant on IT enabled public
delivery system leading to improved transparency in governance and speedy
delivery of services to citizens. Various e-Governance services and online service
delivery platforms are turning the State Government into a major consumer of
cloud storage for these Data Centers.
The Policy aims to build a conducive policy environment for the Data Center
industry to flourish in the state. The locational advantage, strong IT ecosystem,
readily employable quality talent are some of the key ingredients to keep Uttar
Pradesh a promising destination for investment in Data Center industry.

2. Vision, Mission and Target
2.4 Vision
To establish Uttar Pradesh as the preferred investment destination for Data
Center Industry

2.

<!-- page 8 -->

2.2 Mission
To build a world class Data Center ecosystem in the state by attracting
investments from global as well as Indian players and nurture MSMEs/ start-ups
to support the localization of the Data Center industry
2.3 Target
= To develop 250 MW Data Center industry in the state
= To attract investment worth INR 20,000 Crores in the state
= Establish at least 3 state of the art Private Data Center Parks
3. General Terms & Conditions

i. This policy will be valid for 5 years from the date of notification or till the time any new
policy/amendment is introduced by the Government of Uttar Pradesh, whichever is
earlier.

ii. Policy is applicable for the proposals submitted after the notification of this policy.
Investments must be made as well as commercial production commenced within the
policy period. The Empowered Committee constituted under the policy shall decide
upon the extension of the policy period.

iii, Proposals where investment has already commenced on the date of notification of the
policy, shall be eligible to avail non-financial incentives of the policy.

iv. All incentives and benefits proposed under the policy shall be applicable post release
of Letter of Comfort.

v. Doubts relating to interpretation of any term or any provision under this policy will be
referred to the Department of IT & Electronics, Government of Uttar Pradesh, for
clarification/resolution. The decision of the State government shall be final and binding
for all.

vi. Investors shall not be eligible to claim financial incentives under the same head from
Central and State Governments both.

4. Policy Promotion
Marketing and branding strategy shall be formulated by Project Management Unit (PMU) to
promote the policy at national/international forums for attracting investment in the state.
The following tasks will be handled by the PMU under the supervision of Nodal Agency:

i. Promoting the state as preferred destination for attracting investment in Data Center
industry

2

<!-- page 9 -->

ii. Organizing and participating in national and international conferences, summits, road
shows and events to promote the policy
iii. Use of print, electronic and social media to create awareness about state's
attractiveness for DC industry
5. Governance
5.. Nodal Agency
A Nodal Agency under the Department of IT & Electronics, Govt. of Uttar Pradesh shall be
nominated for effective implementation of the Data Center Policy 202. The Nodal Agency
shall be responsible for creating a conducive policy environment for sustained growth of Data
Center ecosystem in the state. Nodal Agency will utilize “Nivesh Mitra” portal to act as Single
Window system for investors to avail timely clearances. Nodal Agency will also set up a
dedicated Project Management Unit (PMU) adequately staffed with outsourced
professionals/ consultants to manage the investment promotion activities and ensure
effective implementation of the policy.
5.2. Policy Implementation Unit (PIU)
A PIU under the chairmanship of Principal Secretary, Department of IT & Electronics shall be
set up to oversee the work of the Nodal Agency. PIU shall be responsible for effective
implementation of the Policy including the approval of investment proposals, disbursement of
incentives, making recommendations to Enpowered Committee etc. Other responsibilities of
PIU include coordination with government functionaries, engagement with industry
associations, stakeholders, corporates, promotion of the policy etc.
5.3. Empowered Committee
A state level Empowered Committee under the chairmanship of Chief Secretary shall be set
up to monitor the effective implementation of the Policy. The charter of the committee shall
be pertaining to the effective implementation of the policy and inter-departmental
coordination with respect to timely resolution of investor issues at all levels. Projects worth
more than INR 200 Crore will be subject to approval from the state cabinet on the
recommendations of Empowered Committee.
5.4. Special Task Force
A special task force shall be established with representation from multiple departments such
as Fire Safety, Public Works Department, Town Planning, and Pollution Control to study the
emerging trends in the industry and technical standards for suggesting improvements in the
regulatory norms adopted in the DC policy, so that the State Regulations are kept in line with
the best industry standards. Recommendations of the Task Force shall be implemented under
the Policy through Government Notifications.
3

<!-- page 10 -->

6. Definitions

6.l. Data Center Park

A Minimum 40 MW Data Center capacity for locating Data Centre Unit(s) shall be considered

under the definition of Data Center Park.

6.2. Data Center Unit

A Data Center Unit is a dedicated secure space within a building / centralized location where

computing and networking equipment is concentrated for the purpose of collecting, storing,

processing, distributing or allowing access to large amounts of data. Captive Data Centers
shall not be considered under this policy.

6.3. Data Center Park Developer

Data Centre Park Developer is an entity who would be responsible to build the facility of DC

park covering land, park area (Water, Sewage, Road, Parking, Green Area, etc.), provision of

DC essentials setup / equipment (i.e. Electricity, Network / Fibre connectivity, Mechanical

Electrical and Plumbing equipment (MEP), etc,).

7. Financial Incentives

7., Data Center Parks

The following financial incentives shall be available to the Data Centre Park developers:

a) Interest Subsidy

Reimbursement of interest subsidy up to 60% of annual interest for 7 years subject to INR 0

Crore per year with an overall ceiling of INR 50 Crore per park shall be provided.

b) Land Subsidy

i. 25% Land subsidy on prevailing sector rates shall be provided on purchase/lease of land
from State Agencies in Madhyanchal and Paschimanchal regions.

ii. 50% Land subsidy on prevailing sector rates shall be provided on purchase/lease of land
from State Agencies in Bundelkhand and Purvanchal regions.

iii. Land subsidy provided in (i) and (ii) above shall be limited to 7.5% of the total project cost
or INR 75 Crore, whichever is less.

iv. Leasing of agricultural land for Solar park shall be allowed in accordance with Revenue
Code.

v. Land subsidy shall be disbursed by the State Government to the concerned Authority post
commercialization of the project in proportion to the area of the land utilized in phases
within the policy period. The Authority shall adjust the subsidy in payment plans of the
enterprise.

4
