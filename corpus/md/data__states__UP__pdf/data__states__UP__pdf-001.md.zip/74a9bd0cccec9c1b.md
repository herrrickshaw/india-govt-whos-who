---
doc_id: "74a9bd0cccec9c1b"
source_url: "https://upgwd.gov.in/MediaGallery/MPStateWaterPolicy_7.pdf"
ministry: "Ground Water Department, Uttar Pradesh"
title: "विवरण"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7ca7fe43d8dd5e2b"
---

<!-- page 1 -->

STATE WATER POLICY (YEAR 2003)

Para.No.

SUBJECT

1

Necessity of State Water Policy:

2

Information system

3

The use of available water wealth for different purposes.

4

Project planning

5

Maintenance and modernization

6

Ground water development

7

Water allocation priorities

8

Drinking water and quality control

9

Irrigation and land management

10

Rationalization of water rates

11

Participation in water management

12

Participation of non governmental institutions

13

Establishment of water zone and watershed management

14

Flood control and management

15

Scarcity area management

16

Science and Technology

17

Training

(1) Necessity of State Water Policy:
Water is a natural resource, fundamental need of living being and invaluable national wealth. In
the developmental planning of the state, water is a decisive and multifaceted component. For
environmental balance, skillful and planned management for all types of developmental
activities, economic use on the equitable basis and in view of the prime importance of water for
all human and other living beings, an effective and sound water policy is necessary.
Under the constitution, water resource is recognized as a state subject. State Water Policy is
prescribed in accordance to the guidelines and general directions in the National Water Policy,
keeping in view the specific necessity for the state of Madhya Pradesh. In view of the inter-state
water disputes, the State Water Policy has specific importance.
(2) Information system:
Developed information system is the principal necessity in the planning of water resources.
Apart from availability of water and data of its actual use, this system should be able to
indicate the availability of water for different purposes in future by way of credible and broader
projections.
Present information and data network including data of processing capabilities should be
improved to make it broader, modern and effective. Emphasis should be given for greater use
of Remote Sensing technique. It should be made mandatory for users and regulatory
departments to maintain all necessary data for compilation of storage of surface and ground
water.

(3) The use of available water wealth for different purposes:
The water resources development shall be planned on the basis of river basin or sub-basin.

<!-- page 2 -->

Each development project shall be designed in such a manner that each basin or sub-basin is
inherently integrated water resources planning so that the best alternative can be identified.

(4) Project planning:
The scope of water resource planning shall be multipurpose and it shall be essential to have
the provision for drinking water and development of hydroelectricity. For enhancement of
fisheries production integrated development projects shall be taken up.
Policy for development of inter-state navigation be decided and possibilities of in-land
navigation be explored. The study regarding impact of projects on life and profession of human
being and their economy, social and other aspects should be an essential part of the project
planning. The study of impact on the quality and environmental balance should be considered
at first in the planning, execution and operation of the projects. The delay in construction of
water resources projects, increase in their cost and reduction of benefits should be secured by
upgrading the quality of projects preparation and management.
In view of providing benefits to the schedule tribes, schedule casts and other special backward
classes, special projects of water resources development should be taken up and
representation of these groups in operation and maintenance of projects shall be ensured.

(5) Maintenance and modernization:
A time bound upkeep of the dams and canal systems should be carried out and time-to-time
programmes for their rehabilitation should be undertaken. It is an immediate need to
reconstruct and rehabilitate the vast irrigation network of the state for future requirements.
These canal systems need modernization and enhancement in their efficiencies. The guidelines
issued for the safety of dams should be examined, from time to time and revised, if necessary.
(6) Ground water development:
While planning projects, attention should be given for development and conjunctive use of
surface and ground water, and it should be made part of the project. Availability of ground
water potential should be assessed after every ten years compulsorily and exploitation of
ground water should be controlled on the scientific basis. The ground water should be utilised
only to the extent, which can be recharged. For recharging the ground water methods of
construction of minor irrigation tanks/percolation tanks should be adopted.
Priority should be given to exploitation of ground water resources for drinking water purposes.
Within the jurisdiction of municipal bodies ground water shall not be utilised without their
permission for private use or any other purpose. If availability of ground is more than the
requirement of drinking water of a municipal body then the ground water can be used for any
other purpose with due permission of the body.

(7) Water allocation priorities:
In the planning and operation of system water allocation priorities shall be as under:
· Drinking water supply
· Irrigation and afforestation.
· Power generation/industrial and other uses.
· Tourism
Water resources department shall be made a nodal department for permitting different uses of
water resources. Clear provision for reservation of drinking water shall be made. in proposed
irrigation projects of the state, on river, reservoirs, tanks etc.

<!-- page 3 -->

(8) Drinking water and quality control:
The facility of sufficient drinking water shall be extended to the entire urban and rural
population. The quality of the surface water and ground water shall be tested on regular basis
by concerned departments. It should be made mandatory to treat the industrial and urban
waste to the required standards before these are allowed to flow in a stream .The necessary
laws should be formulated for protecting the water resources from unauthroised encroachment
and also for maintaining the standard quality of water.

(9) Irrigation and land management:
In water resources planning, amongst the available options/alternatives, optimum cost benefit
alternative shall be selected. The policies of land use and its levelling shall be co-related with
the policy of water use. Irrigation potential shall be utilised to the maximum, so that the gap
between irrigation potential and actual Irrigation can be reduced. The provision shall be made
to provide irrigation on priority basis in the fields of marginal and small farmers. To promote
drip and sprinkle irrigation there is a need to set up model farms in the command areas of
every canal with the help of Agriculture Department.

(10) Rationalisation of water rates:
Water rates should be such which conveys the beneficiary the scares value of water, its
importance and motivates them for the economical use of water. Water rates necessarily shall
be such that the project shall be self-supported. For the use of water for private purposes, rates
shall be determined in such a manner so that the water can be used strictly in accordance to
the prescribed priorities laid down in the policy. Due to the importance of the forest for
protection of environment, concessional rates of water shall be fixed for afforestation
(10-A) Institutional administration: (As per Corrigendum-1 in the State Water Policy)
Presently concerned departments are carrying out Water Resource Planning for different uses.
Considering scarcity and necessity of multi- dimensional planning for development of water
resources, there is a need to prepare development plans for water resources at the level of
apex institutions of the state.
The water resources planning structure which is at present based on water availability should
be correlated with demand base of water distribution and necessary institutional reforms be
taken.
(11) Participation in water management:
To improve water planning, avoid disparity in water distribution and status of available services
rendered to farmers, participation of beneficiary groups in operation and maintenance shall be
ensured.

(12) Participation of non-governmental Institutions:
In water sector, the non-governmental agencies and commercial organizations should have
financial and management participation. This type of participation shall be at all levels in
project planning, construction and maintenance.

(13)Establishment of water zones and water shed management:
On the basis of availability of water the state shall primarily be divided into three regions (East,
Central and West) per hectare cost of Irrigation development shall be based on separate
criteria in the East, Central and West regions, strictly in accordance to geographical & climatic
conditions.
Special attention shall be given to catchment area treatment and water shed management.
Watershed management shall also include soil conservation, catchment area treatment, forest

<!-- page 4 -->

conservation and afforestation programme. To improve soil-recharging capacity, plantation by
demarcating green belts shall be done, wherever possible. Special water resources
development projects shall be formulated for hilly region.

(14) Flood control and management:
Master Plan shall be prepared for flood-affected areas for controlling the flood and providing
protection. The additional storage capacity of water shall be provided in the reservoirs for
accommodating the flood water. An intensive network for flood forecasting shall be established.
Erosion of soil caused by the rivers shall be minimized by adopting economical remedial
measures. Efforts shall be made to prevent the uncontrolled use of river and river banks for
habitation and farming, to control the on going economic activities in the area.

(15) Scarcity area management:
In drought prone areas, to reduce the problem and severeness related to drought, measures
like water harvesting, soil humidity protection, works related to increase the ground water table
and transfer of water from area having surplus water to scarce water area etc shall be adopted.
Development of grazing fields, afforestation and similar other works shall be encouraged.
Priorities shall be given to the scarcity areas in the planning of water resources development
and a special water management system shall be developed for economical use of water in
these areas.
(15-A) Planning to interlink rivers: (As per Corrigendum-1 in the State Water Policy)
For integrated development of water resources interlinking river system plan shall be prepared,
safeguarding the interest of the state.

(16) Science and technology:
It is necessary that multifaceted exposure and avenues be provided to the technical knowledge
for efficient and appropriate water resources management. Intensive research work is essential
in the following areas:
- Hydrometeorology
- Hydrology
- Ground water science and recharging of the ground water
- Economical use of water
- Appropriate methods for the conservation of water in the fields, development of water wealth
in the catchment areas.
- Economical design of water resources projects
- Continuity of flow of water in the rivers and purity of drinking water
- Scientific study of crop-pattern
- Study of silting processing in the reservoirs and measures to minimize it.
- Safety of water conservation structures
- Research on river formation works and construction material
- Water distribution system
- Remote sensing techniques
- Purification of water and its likely reuse.
- Effective water drainage system

<!-- page 5 -->

- Risk analysis and Disaster Management

(17)Training:
There shall be inclusion of regional planning for information system, designing of project,
construction, operation and efficient water distribution system for providing standarized
training. Farmers shall also be included with personnel of all levels involved in the water
resources management for training. The prime object of the training shall be to achieve
maximum production from per unit use of water.
