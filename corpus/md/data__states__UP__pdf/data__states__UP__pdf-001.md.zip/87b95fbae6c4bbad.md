---
doc_id: "87b95fbae6c4bbad"
source_url: "https://upgwd.gov.in/MediaGallery/GWDLogo.pdf"
ministry: "Ground Water Department, Uttar Pradesh"
title: "विभागीय लोगो (प्रतीक चिन्ह) के सम्बन्ध में 'वेबसाइट के माध्यम से पब्लिक ओपिनीयन' प्राप्त कर तदनुसार यथावश्यक संशोधित लोगो (प्रतीक चिन्ह) उपलब्ध कराने के निर्देश दिये गये है ।"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "00253beabdfba1e7"
---

<!-- page 1 -->

<!-- page 2 -->

HkwxHkZ ty foHkkx] mŒizŒ dk foHkkxh; yksxks ¼izrhd fpUg½ tuekul ds lq>ko gsrq izsf"kr
fd;k tk jgk gSA foHkkxh; yksxks ¼izrhd fpUg½ esa lq/kkj rFkk u;s yksxks ¼izrhd fpUg½ ds
lq>ko fn;s tkus gsrq vkeaf=r gSA vki vkius lq>ko foHkkxh; bZ&esy
upgwd.in@gmail.com ij fnukad 30-11-2022 rd miyC/k djk ldrs gSA
