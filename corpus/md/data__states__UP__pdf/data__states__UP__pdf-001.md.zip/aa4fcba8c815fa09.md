---
doc_id: "aa4fcba8c815fa09"
source_url: "https://upgwd.gov.in/MediaGallery/TenderNoticeLT_902.pdf"
ministry: "Ground Water Department, Uttar Pradesh"
title: "संक्षिप्त निविदा सूचना"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "75699ada182166de"
---

<!-- page 1 -->

f
} Governmentof Uttar Pradesh
if Office of the Director, Ground Water Department
j/ Bhujal Bhawan (State Ground Water Information System Centre),
}/ Village- Hariharpur, Shaheed Path, Lucknow — 226002
oil Ph. No, — 0522-2287068, 2287233
Website: www.upgwd.gov.in, E-mail: upgwd@gmail.com
N. Gor r Z
No: | /GWD/ Lko Theme Park/ 2024-25 Lucknow: Dated 2० September, 2024
ABRIDGED TENDER NOTICE
The Ground Water Department, Uttar Pradesh on behalf of Governor of Uttar
Pradesh invites Request for Proposals for Engagement of Consultant for Development of
Theme Park at Janeshwar Mishra Park in Lucknow for Sustainable Development of Ground
Resources and Management through e-procurement portal littps://etender.up.nic.in from
registered firms/consultants/agencies/companies. The detail Request for Proposal (RFP)
document can be downloaded from the e-procurement portal. Interested
bidders/consultants/firms are requested to upload their proposals in accordance with the
requirement of RFP latest by 4-40-2024 45.00 hours on the e-procurement portal. The
Technical Proposals shall be opened online through the e-portal same day at 45.30 hours.
The details may be obtained from the RFP document available at htips://etenderup.nicin.
For any further clarifications please contact upgwd@sgrail.comA virtual pre-proposal
conference open to all prospective consultants will be held on 04-40-2024 @ 45:00 hrs.
Google Meet joining info Video call link: https://meet.google.cor/sic-ytim-xof
S)
Dr Rajesh Kumar Prajapati
) IAs
2G) Wy Director
a

<!-- page 2 -->

ह EEE कक
Ji
i
/, कार्यालय निदेशक,
५ है भूगर्भ जल विभाग, उत्तर प्रदेश,
j भूजल भवन (रा०भू0सू0प्र0के0),
if ग्राम-हरिहरपुर, शहीद पथ, लखनऊ-226002
Ph- No-0522-2287068, 2287233
Website- www.upgwd.gov.in, E-mail- upgwd@gmail.com
संख्या- १५० भू0ज0वि0 / लखनऊ थीम पार्क / 2024-25 लखनऊ:दिनांकःसितम्बर, 2० 2024
संक्षिप्त निविदा सूचना

उत्तर प्रदेश के राज्यपाल की ओर से भूगर्भ जल विभाग, उत्तर प्रदेश भूगर्भ संसाधनों
के सतत्‌ विकास और प्रबंधन के लिए लखनऊ में जनेश्वर मिश्र पार्क में थीम पार्क के विकास
के लिए सलाहकार की नियुक्ति के लिए ई-प्रोक्योरमेंट पोर्टल https://etender-up-nic-in के
माध्यम से पंजीकृत फर्मो/परामर्शदाताओं/एजेंसियों/कंपनियों से प्रस्ताव आमंत्रित करता है।
प्रस्ताव के लिए विस्तृत अनुरोध (आरएफपी) दस्तावेज ई-प्रोक्योरमेंट पोर्टल से डाउनलोड
किया जा सकता है। इच्छुक एजेन्सियों / कंपनियों / परामर्शदाताओं/फर्मों से अनुरोध है कि वह
आरएफपी की आवश्यकता के अनुसार अपने प्रस्ताव दिनांक 74-70-2024 को 45.00 बजे
तक ई-प्रोक्योरमेंट पोर्टल पर अपलोड कर सकते हैं। तकनीकी प्रस्ताव उसी दिन ॥ 5.30 बजे
ई-पोर्टल के माध्यम से ऑनलाइन खोले जाएंगे। विवरण https://etender-up-nic-in पर
उपलब्ध आरएफपी दस्तावेज से प्राप्त किया जा सकता है। किसी भी अन्य स्पष्टीकरण के
लिए कृपया upgwd@gmail.com पर संपर्क करें। सभी संभावित सलाहकारों के लिए एक
वर्चुअल प्री-प्रपोजल कॉन्फ्रेंस दिनांक o4—t0-2004 को i500 बजे आयोजित की जाएगी |
Google मीट जॉइनिंग जानकारी वीडियो कॉल लिंक: https://meet-google-com/sjc-ytim-xof

(So राजेश कुमार प्रजापति)
आई0ए0एस0
निदेशक > 4० lou,
. शी a =
