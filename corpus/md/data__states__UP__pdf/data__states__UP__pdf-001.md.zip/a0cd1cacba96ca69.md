---
doc_id: "a0cd1cacba96ca69"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "28bed37f6f60666b"
---

<!-- page 1 -->

f UTTAR PE cSH ६
f 4 SEWAPR RADESH SHASAN
/ OK S yy /
/ ' ABANDHAN ANUBHAG
iy) pursuance of the provisions of clmuse (2) of Article 348 Of the Consntuti MA bes
i हू i भा € fe is ५ ndia, the Govern
ix plengerl to order the publication of the following Tvgleh tranelation of Nettie sian ja, the Governor
| oo 2044 dated ag Novernber, 2027 ne BSE (9i-2024-
\ NOWPICA TION
| No.256 #94-209)-09/204
Tucknow: Dated e¢November. 202
avrcise of the powers under sect न
जा In e ene een T ae T Section 3 ता the Uttar Pradesh Jantit Caarantee Adhinvyam. 20) |
(UP Aci ne, FoF 20T0) 4 ३ शत] हे section 2 of the Unar Pradesh General Clauses Act, ]04 (U.P Act no | of
6 Governor is pleas 0 mal ith eff मु BR :
} bala ), ne ee : Dani OL effect from the date of publication of this notification jn the
Gavette, the रि At ga m Jovermment Notification no, 2)98/)-[4-2059-3 [00)-200T © -f
dated January TS, 20]7 as amended from time to time-
AMENDMENT
In the ahaa Nae in the Schedule after entries at serial number 45. the following entries
shall, with effect from the date of publication of this notification in the Gazette. column-wise be inserted.
namely:- ०
Schedule
- : a ;
Sr Name el thd Services Designated Stipulated time limits | First \ppeal | Stipalarted T Second Appellate | Sripolatest
| ne, | Departments Officer for services Officer time — limits | \athority | स्तर. हिला
| for disposal | for
| of First | aspecal of
Appeal \ Secomd |
Officer | | आकलन |
ट्रक
] is ae ae न a 3 a |
86 | Ground T- Registration of | Member 30 working days Chairman’ | 30 working | Member | 34 |
Water Well Secretary! District days Seerstary) Suc | working
Department Chief Magistrate, Grape Water ३ days.
LP, Development District Mangement and
Officer, Ground | Regulatory |
District Water | Authonty | |
Ground Water beats te | Bel nae |
ron a ||
Managment silos ol : | आग i |
* | Council of concerning ee |
district Men क्र
हु हे Jo working days Chairman. 30 workung T Member w
2 Grant of Member ae का toys Sacer कल |
Authorization) Secretary | Magistras | ieound  Wanee | ais
for Chief Distriet Mangement and
Ground Water | Deselopment Ground Relators | |
abstnction Officer Water Authors | |
District Managinent Oirectar. | |
Ground Water ‘Cuunedl of | Grown Water
Managemen cancecing | Deparment
Count oF | isu |S ee! bid
goncemming a
distnct_ जता 7
By order, —
f
—fitl a
20! अनिल
ie
(Jitendra kun}ar)
PRAMUKH SACHIV
Yer

<!-- page 2 -->

लोक उत्तर प्रदेश शासन
wee सेवा प्रबन्धन अनुभाग
लखनऊ 288 /9i~2924—-09 / 2044
खनऊ दिनांक: ०१ नवम्बर, 2024
दो पे olathe ae खण्ड अधिनियम, 4904 (उत्तर प्रदेश अधिनियम संख्या ॥ सन्‌ 4904) की घारा
at 8 के अधीन अव्तियों I जनहित TRS अधिनियम, 20:7 (उत्तर प्रदेश अधिनियम संख्या 3 सन्‌ 2072) की
से ! 3 के अधीन शक्तियों erties प्रयोग करके, राज्यपाल इस अधिसूचना के गजट में प्रकाशित किये जाने के दिनांक
समय-समय पर Tay सरकारी अधिसूचना संख्या-2498 / एक-44--200-33(00)-2040 टी0सी०-ना,
दिनांक, 45 जनवरी, 207 में निम्नलिखित संशोधन करती हैं :-
संशोधन
पूर्वोक्त अधिसूचना में, ore में, कम संख्या 85 की प्रविष्टियों के पश्चात्‌, निम्नलिखित प्रविष्टियाँ, इस
अधिसूचना के गजट में प्रकाशित किये जाने के दिनांक से स्तम्भवार बढ़ा दी जायेंगी, अर्थात्‌ —
अनुसूची
किस | विभाग का | सेवाएँ | पदाभिहित | सेवाओं के लिए [प्रथम अपीलीय | = ) fiche अपीलीय | te 7]
a | | ant अपीलीय |
७५७७ | - | अधिकारी | नियत समय सीमा | अधिकारी Vanes अधिकारी 5
| 4 | | | Rarer | freer |
| | | | | हेतु नियत | | Saree |
| | समय सोम | समय-सीमा
| | | । lo 4 |
Cae a — बा बन बहा व = Se
2 aes ee ———— किक्त | सतत ne 8 a
| 86 | मूगर्भ जल I कूप का | wee सचिव> | 3 कार्य दिवस | अध्यक्ष”... 30 कार्य | सदस्य सचिव, | 30 कार्य |
| विभाग | पंजीकरण सम्बंधित जिला | pias | दिवस | राज्य भूगर्भ | दिवस |
| का मुख्य विकास जिला wr | | प्रबच्चन एवं |
| | अधिकारी, जिला | जिलाधिकारी, | | विनियामक
क्‍ | | | | |
भू-गर्भ जल | (जिला | | प्राधिकरण / |
| | | | प्रबन्धन परिषद | | gor जल | | निदेशक, भूगर्भ | |
| | प्रबन्धन । जल विभाग,
| | | | परिषद उत्तर प्रदेश
| ae eS 2 मम eg वि =
| (2- भूगर्भ जल सदस्य | 30 कार्य दिवस | अध्यक्ष / | 30 सदस्य सचिव, | 30 कार्य |
| | निष्कर्षण सचिव / सम्बंधित |संम्बंधित | कार्य | राज्य भूगर्भ जल दिवस
| | | iter at | जिला का मुख्य जिला का| दिवस | प्रब्धन एवं | |
| | |. स्वीकृति विकास अधिकारी, जिलाधिकारी, | | विनियामक |
| | जिला मू-गर्भ | जिला | प्राधिकरण /
| जल प्रबन्धन | भू-गर्भ जल | निदेशक, भूगर्भ
| | परिषद | प्रबन्धन | जल विभाग, | ||
| | ie | परिषद _ | उत्तर प्रदेश। | \
आज्ञा से, +»
|
at के _
प्रमुख ie |
है w
