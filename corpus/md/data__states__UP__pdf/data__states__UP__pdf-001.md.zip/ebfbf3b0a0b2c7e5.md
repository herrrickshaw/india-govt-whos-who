---
doc_id: "ebfbf3b0a0b2c7e5"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 5
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "bb3d2284c2110ca8"
---

<!-- page 1 -->

उ र

दे श शासन

टा प एवं र ज

े शन अनुभाग-2,

सं या-11/2023/320/94- टा0िन0-2-2023
लखनऊ: दनांक- 12 अ ैल, 2023
अिधसूचना
आदे श
साधारण ख ड अिधिनयम, 1897 (अिधिनयम सं या 10 सन ् 1897) क धारा 21 के साथ प ठत

उ र

दे श म अपनी

वृ

के संबंध म समय-समय पर यथा संशोिधत भारतीय

टा प

अिधिनयम, 1899 (अिधिनयम सं या 2 सन ् 1899) क धारा 9 क उपधारा (1) के ख ड (क) के
अधीन श

य का

दनांक से उ र
इकाई/पाक क

योग करके रा यपाल इस अिधसूचना के गजट म

दे श सौर ऊजा नीित, 2022 के अधीन उसम
थापना हे तु नीचे सारणी के

पूव त नीित के

टा प शु क म छूट

योजनाथ नई

त भ-4 म यथा दिशत िलखत के स ब ध म

दान करती है :-

त भ-3 म यथा

छूट

उ र दे श सौर
ऊजा नीित,

योजन

क

तर
2
नीित के अधीन रा य म कह ं भी सौर
ऊजा इकाई क

12.2

विन द ट

तर-12.2, 13.2, 13.10.1, 13.10.2, 13.10.3 के अनुसार

उ ल खत सीमा तक

2022 का
1

कािशत कये जाने के

भूिम

थापना हे तु िनजी

सीमा
3
100%

य करने अथवा प टा पर लेने

िलखत क

कृ ित

4
भारतीय टा प अिधिनयम 1899 क
अनुसूची 1(ख) के अनु छे द 23 के ख ड–
(क) के अधीन ह ता तरण और

पर

अनु छे द 35 के अधीन प टा के िलखत
पर

नीित के अधीन रा य म कह ं भी सौर
ऊजा प रयोजना/सौर ऊजा पाक क
13.2

थापना हे तु भूिम

100 %

य करने अथवा

भारतीय टा प अिधिनयम 1899 क
अनुसूची 1(ख) के अनु छे द 23 के ख ड–
(क) के अधीन ह ता तरण और

उसे प टा पर लेने पर

अनु छे द 35 के अधीन प टा के िलखत
पर

5
13.10.1

MW

से

अिधक

(Capacity) वाले

धा रता

टै ड अलोन सौर

ऊजा प रयोजना हे तु भूिम के
अथवा प टा पर लेने पर

1-

क

यह शासनादे श इले

2- इस शासनादे श क

ािनकली जार

य

100 %

भारतीय टा प अिधिनयम 1899 क
अनुसूची 1(ख) के अनु छे द 23 के ख ड–
(क) के अधीन ह ता तरण व अनु छे द
35 के अधीन प टा के िलखत पर

कया गया है , अत: इस पर ह ता र क आव यकता नह है ।

मा णकता वेब साइट http://shasanadesh.up.gov.in से स या पत क जा सकती है ।

<!-- page 2 -->

सौर ऊजा पाक वकासकता को भूिम
य करने अथवा उसे प टा पर लेने

13.10.2

100 %

पर

भारतीय टा प अिधिनयम 1899 क
अनुसूची 1(ख) के अनु छे द 23 के ख ड–
(क) के अधीन ह ता तरण व अनु छे द
35 के अधीन प टा के िलखत पर

5 MW से कम क धा रता (Capacity)
वाले

13.10.3

टै ड

अलोन

प रयोजना हे तु भूिम

सौर

ऊजा

100 %

य करने अथवा

भारतीय टा प अिधिनयम 1899 क

अनुसूची 1(ख) के अनु छे द 23 के ख ड–
(क) के अधीन ह ता तरण व अनु छे द

उसे प टा पर लेने पर

35 के अधीन प टा के िलखत पर
ल खत छूट िन निल खत

इस अिधसूचना के अधीन पूव

ितबंध /शत के अ यधीन

दान क जाती है :–
1- जला म ज
उ तर

े ट/उपायु , उ ोग को ह ता तरण/प टा िलखत क पु

दे श सौर ऊजा नीित, 2022 के अधीन िन पा दत कया जा रहा है और उ ह उ त

योजनाथ सा ी के

प म भी ह ता र करना होगा।

2-यू0पी0एन0ई0ड 0ए0 के प
बक

करनी होगी क वलेख

म

याभूित, ऐसे वलेख के र ज

जायेगी। बक

टा प शु क क छूट के समतु य धनरािश क अप रवतनीय
करण के समय िनबंधन अिधकार के सम

तुत क

याभूित क अविध प रयोजना पूण करने हे तु नीित म यथा व हत अविध से कम

अविध नह ं होनी चा हए।
3- कसी अ य नीित के अधीन
और अिधसूचना के अधीन

टा प शु क छूट क

सु वधा

टा प शु क माफ /छूट के िलए पा

ा त कर चुक इकाई इस नीित
नह ं होगी।
आ ा से,
लीना जौहर
मुख सिचव।

सं या: 11/2023/320/94- टा0िन0-2-2023, दनांक: 12 अ ैल, 2023
हं द एवं अं ेजी अिधसूचना क

ित स हत संयु त िनदे शक, राजक य मु णालय

ऐशबाग लखनऊ को इस अनुरोध के साथ

े षत क वह कृ पया इसे दनांक 12 अ ैल,

2023 के असाधारण गजट के वधायी प रिश ट भाग-4 ख ड(ख) म अव य
करा द और त प चात ् गजट क 100
50

ितयॉं आयु त

कािशत

टा प, उ0 0 लखनऊ को तथा

ितयॉं शासन के इस वभाग को उपल ध कराने का क ट कर।

रवीश गु ता

1-

यह शासनादे श इले

2- इस शासनादे श क

ािनकली जार

कया गया है , अत: इस पर ह ता र क आव यकता नह है ।

मा णकता वेब साइट http://shasanadesh.up.gov.in से स या पत क जा सकती है ।

<!-- page 3 -->

वशेष सिचव।
सं या: 11/2023/320/94- टा0िन0-2-2023, दनांक: 12 अ ैल, 2023
ितिल प िन निल खत को सूचनाथ एवं आव यक कायवाह हे तु
1- महालेखाकार लेखापर
2-

ा ( थम एवं

तीय), उ र

दे श,

े षतः-

यागराज।

टॉफ आफ सर, मु य सिचव, उ0 0 शासन।

3- अव थापना एवं औ ोिगक वकास आयु त।
4-

मुख सिचव, मु यमं ी, उ0 0 शासन।

5- अपर मु य सिचव, अित र त ऊजा

ोत वभाग, उ0 0 शासन।

6- सम त म डलायु , उ0 0।
7- महािनर

क िनबंधन/आयु त

टा प, उ0 0।

8- सम त जलािधकार , उ0 0।
9- सम त अपर जलािधकार , ( व0/रा0) पदे न जला िनबंधक, उ0 0।
10- सम त उप महािनर

क िनबंधन, उ0 0।

11- सम त सहायक महािनर

क िनबंधन, उ0 0।

12- वधायी अनुभाग-1, उ0 0 शासन।
13- भाषा अनुभाग-5, उ0 0 शासन।
14- गाड फाइल।
आ ा से,
कुलद प िसंह
अनु सिचव,
टा प एवं र ज

1-

यह शासनादे श इले

2- इस शासनादे श क

ािनकली जार

े शन वभाग।

कया गया है , अत: इस पर ह ता र क आव यकता नह है ।

मा णकता वेब साइट http://shasanadesh.up.gov.in से स या पत क जा सकती है ।

<!-- page 4 -->

UTTAR PRADESH SHASAN
STAMP EVAM REGISTRATION ANUBHAG-2
In pursuance of provisions of clause (3) of Article 348 of the Constitution, the Governor is
pleased to order the publication of the following English translation of Government
notification no. 11/2023/320/94-S.R.-2-2023 dated 12 April, 2023
Notification
Order
No. 11/2023/320/94-S.R.-2-2023
Lucknow, dated 12 April, 2023
In exercise of the powers under clause (a) of sub-section (1) of section 9 of the Indian
Stamp Act ,1899 (Act no. 2 of 1899) as amended, from time to time, in its application to Uttar
Pradesh read with section 21 of the General Clauses Act,1897 (Act no. 10 of 1897), the
Governor, from the date of publication of this notification in the Gazette, is pleased to remit
the Stamp Duty, for establishing new unit/Park under the Uttar Pradesh Solar Energy
Policy,2022, in accordance with the Para 12.2, 13.2, 13.10.1, 13.10.2, 13.10.3 of the
aforesaid Policy for the purposes specified therein, to the limit as mentioned in column 3 of
the table below in relation to the Instrument as shown in column 4
Para of Uttar
Pradesh Solar
Energy Policy,
2022
1
12.2

13.2

13.10.1

13.10.2

13.10.3

1-

Exemption
Limit

Purpose
2
On purchasing private land or
taking it on lease for setting
up solar energy unit anywhere
in the state under the policy

3
100%

On purchasing land or taking it
on lease for establishment of
solar power project/solar park
anywhere in the state under
the policy
On purchase or lease of land
for a stand alone solar power
project with a capacity of
more than 5 MW

100 %

On purchase or lease of land
to Solar Park Developer

100 %

On purchase or lease of land
for stand alone solar power
project with capacity less than
5 MW

100 %

यह शासनादे श इले

2- इस शासनादे श क

ािनकली जार

100 %

Nature of Instrument
4
On the instrument of conveyance
under Clause-(a) of Article-23 &
Article 35 of Schedule-1(b) of the
Indian Stamp Act, 1899.
On the instrument of conveyance
under Clause-(a) of Article-23 &
Article 35 of Schedule-1(b) of the
Indian Stamp Act, 1899.
On the instrument of conveyance
under Clause-(a) of Article-23 &
Article 35 of Schedule-1(b) of the
Indian Stamp Act, 1899.
On the instrument of conveyance
under Clause-(a) of Article-23 &
Article 35 of Schedule-1(b) of the
Indian Stamp Act, 1899.
On the instrument of conveyance
under Clause-(a) of Article-23 &
Article 35 of Schedule-1(b) of the
Indian Stamp Act, 1899.

कया गया है , अत: इस पर ह ता र क आव यकता नह है ।

मा णकता वेब साइट http://shasanadesh.up.gov.in से स या पत क जा सकती है ।

<!-- page 5 -->

The aforementioned exemption under this notification is subject to the following prohibitions
/conditions:1-The District Magistrate/ Deputy Commissioner of Industries shall confirm in the
Instrument of conveyance/ Lease that the deed is being executed under the Uttar Pradesh
Solar Energy Policy, 2022 and also signs as a witness for the said purpose.
2-Irrrevocable bank guarantee of the amount equivalent to the remission of stamp duty in
favour of the UPNEDA shall be presented before the registration officer at the time of
registration of such deed. The period of the Bank guarantee shall not be less than the
period, as prescribed in the policy, for the completion of project.
3-The unit which has obtained the benefit of stamp duty exemption under any other policy
shall not be eligible for a stamp duty remittance/ exemption under this policy and
notification.
By order,
Leena Johri
Principal Secretary

1-

यह शासनादे श इले

2- इस शासनादे श क

ािनकली जार

कया गया है , अत: इस पर ह ता र क आव यकता नह है ।

मा णकता वेब साइट http://shasanadesh.up.gov.in से स या पत क जा सकती है ।
