---
doc_id: "fbaace0fc2677bf5"
source_url: "https://bmssy.wblabour.gov.in/downloads/gazette-notification-no-255.pdf"
ministry: "Bina Mulya Samajik Suraksha Yojana, West Bengal"
title: "VIEW"
date: ""
pages: 2
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "b519c7200abddeaa"
---

<!-- page 1 -->

Registered No. WB/SC-247 No. WB(Part-I)/2017/SAR-190
SERS
Kolk |||! 6
olkata «= 7360
Extraordinary
Published by Authority
CAITRA 16] THURSDAY, APRIL 6, 2017 [SAKA 1939
PART I—Orders and Notifications by the Governor of West Bengal, the High Court, Government Treasury, etc.
GOVERNMENT OF WEST BENGAL
LABOUR DEPARTMENT

L.W. BRANCH

No. Labr./255/(LC-LW) Kolkata, the 3rd April, 2017
LW/5M-112/16

AMENDMENT

The Government of India enacted the Unorganised Workers' Social Security Act, 2008 on 30.12.2008. In terms of
Sub-Section (1) of Section 6 of the said Act, the Government of West Bengal in the Labour Department constituted the
West Bengal State Social Security Board vide Notification No. 1025-IR dated 06.11.2009.

2. The Board recommended for adoption of a scheme for the social security of the transport workers of the State
and accordingly, the scheme under the name of West Bengal Transport Workers' Social Security Scheme, 2010 was
introduced under Labour Department, IR Branch Resolution No. 907-IR/Eil/l-A-4/110 dated 13th August 2010 read with
IR Branch Notification No. 183-IR/Eil/I-A-01/10 dated 16th February 2015.

3. The said Scheme provides various social security benefits to the Transport workers like Pension, Family
pension, Benefits due to normal death and accidental death, Hospitalisation benefit, Cashless Medical benefit as per the
model of RSBY, benefits due to surgical operation, Maternity benefit and Financial Assistance for education of children
of beneficiaries etc.

4. The matter regarding converging of social security benefits excepting the Pension, Cashless Medical benefit
and Surgical Operation available to the Transport workers into a single and consolidated social security scheme was
under active consideration of the Government for sometime past.

5. Now, after careful consideration of the matter and in exercise of power conferred under clause 24 of the West
Bengal Transport Workers Social Security Scheme, 2010, the Governor is herby pleased to revise the social security
benefits available to the Transport workers to the extent as mentioned below:

51. Name of the Eligibility Amount (in Rs.)
No. benefit
ie Pension On attaining the age of 60 years and the | @1500/- only p.m. with an increase of
beneficiary has remained under the Rs 10/- only for each completed year of
scheme for a continuous period of not | enrolment as a beneficiary in excess of
less than five years five years

<!-- page 2 -->

2 THE KOLKATA GAZETTE, EXTRAORDINARY, APRIL 6, 2017 [Part 1
——— ১২-৯১-২৯৯২ ৯৯৯২২ -২- »
নল ল ছল লা উ লই ললল
91. Name of the Eligibility Amount (in Rs.)
No. benefit
i, Family pension @50% of the amount last drawn by the
beneficiary
3: Medical Benefit Cashless medical benefits in case of Maximum Rs. 30,000/- only, based on
auto and taxi drivers only Rashtriya Swasthya Bima Yojana
(RSBY) Model
In case of surgical operation Maximum Rs. 1,00,000/- only for self
and Rs. 1,50,000/- only for family
members including self per annum
6. All other provisions of the existing scheme except relating to benefits under Para-5 are repealed.
7. This revised scheme will be effective from 1st April 2017.
8. This notification is issued with concurrence of the Finance Department vide their U.O No. Group L/2016-
2017 dated 21.03.2017.
By order of the Governor,
GOPAL KRISHNA
Additional Chief Secretary to the Government of West Bengal.
ne ee eee eee eee |
Published by Labour Department (L.W. Branch), West Bengal and printed at Saraswaty Press Ltd.
(Government of West Bengal Enterprise), Kolkata 700 056.
