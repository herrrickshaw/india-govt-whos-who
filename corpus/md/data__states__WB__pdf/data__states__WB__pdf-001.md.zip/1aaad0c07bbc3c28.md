---
doc_id: "1aaad0c07bbc3c28"
source_url: "https://icad.wb.gov.in/wb-admin/uploads/tenders/8084451623941742370667.pdf"
ministry: "Information and Cultural Affairs Department, West Bengal"
title: ""
date: ""
pages: 19
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bb81b6dd77d4d615"
---

<!-- page 1 -->

Government of West Bengal
Information & Cultural Affairs Department
325 S.C. Road Nabanna, Howrah-711102
Memo. No. 1046- ICA(N)

Date: 18.03.2025

Tender Notice
In connection with the “Rabindra-Janmotsov-2025”, scheduled to be held from 09th May 2025 to 24th
May 2025, sealed tenders are invited by the undersigned on behalf of the Information & Cultural
Affairs Department, Government of West Bengal from the bona fide and reputed agencies having
sufficient experience for procurement of Invitation Card as mentioned in the annexure. Interested
bidders may be submitted their tender papers as per annexure.
The Tender Forms, tender documents containing detailed specifications, terms & conditions etc. shall
be obtained from the following address on the basis of the applications of the interested bidders.
Room No. 907, 9th Floor, Nabanna, 325, Sarat Chatterjee Road, Howrah-711102 or Tender form
may be downloaded from the website: www.wb.gov.in / www.egiyebangla.gov.in
The tender documents will be available between 12 noon. to 5 P.M. from 18.03.2025 to 24.03.2025
excluding Saturday, Sunday and other Government holidays and the last date of submission of duly
filled up tender papers is on 25.03.2025 up to 1.00 pm and duly filled up tender paper shall be
submitted at above mentioned address. Technical bid will be opened on 25.03.2025 at 2.00 pm in the
Conference Room, Room No. 901, 9th Floor, Nabanna, 325, Sarat Chatterjee Road, Howrah711102.

Memo. No. 1046/(12) -ICA(N)

Sd/Director of Culture
I & CA Department, Govt. of W.B
Nabanna, Howrah
Date: 18.03.2025

Copy forwarded for favour of kind information and necessary action for wide publicity:
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.

All Member of the Departmental Tender Committee
The CEO, Nandan, 1/1 AJC Bose Road, Kolkata -700020
The Additional Director of Culture, 1/1 AJC Bose Road, Kolkata -700020
The Administrative Officer, Rabindra Sadan, 1/1 AJC Bose Road, Kolkata -700020
The Secretary, Paschimbanga Bangla Academy, 1/1 AJC Bose Road, Kolkata -700020
The Administrative Officer, Paschim Banga Natya Academy, 1/1 AJC Bose Road, Kolkata -700020
The Deputy Director of Culture and A.O. Sisir Mancha, 1/1 AJC Bose Road, Kolkata -700020
The Administrative Officer, Madhusudan Mancha, Dhakuria, Kolkata -700031
The Administrative Officer, Girish Mancha, 76/1 , Bagbazar Street , Kolkata -700003
P.A. to the Pr. Secretary, I & CA Department, Govt. of West Bengal, Nabanna, Howrah- 711102
Section Officer, Cell-IV, I & CA Department, Nabanna, Howrah- 711102
Copy for Guard file

Sd/Director of Culture
I & CA Department, Govt. of W.B
Nabanna, Howrah

<!-- page 2 -->

Bid Letter Form
(To be filled by the bidder)

From : ___________________

Date: ………………

(Registered name and address of the Bidder.)

To: Director of Culture,
Department of Information & Cultural Affairs,
325, Sarat Chatterjee Road,
Howrah-711102.
Sir / Madam,
Having examined the tender documents, I/we the undersigned, offer the rates as per prescribed Financial Bid Format for the following
works as per detailed in the bid document in response to your ‘Notice inviting Tender vide your No. 1046-ICA(N) dated 18.03.2025 :
For procurement of Invitation Card relating to the Rabindra-Janmotsov-2025

If our Bid is accepted, we undertake to:
1. Implement the prescribed work as per delivery schedule in conformity with the bid documents at the rate as
offered by us in the bid document.
2. Earnest Money of Rs. 2,000/- (Rupees Two Thousand ) only by Demand Draft drawn in favour of “Secretary, Folk
and Tribal Cultural Centre”, payable at Kolkata shall be deposited along with the offer.
3. Execute all contractual documents as required in the bid document.
4. Abide by all the terms & condition as mentioned in the Tender Documents.
5. Maintain validity of the contract until completion of the programme from the date of opening of the tender as
specified in the bid documents that shall remain binding upon us on acceptance of our offer.
6. All tender papers duly signed by the authorized person are enclosed herewith.
Dated. this _______ day of ____________.
Witness:
Signature:
Address:

(in the capacity of Duly Authorised to sign bid for and on behalf of …………………………..).

2

<!-- page 3 -->

A. General Terms and Conditions for Annexure
1. The tender papers should be submitted in the following manner:
a) One sealed envelope should contain documents for Technical Bidding with the mention
on the envelope as “TECHNICAL BID DOCUMENTS”
b) Another sealed envelope should contain the Financial Quotation with the mention on
the envelope as “FINANCIAL BID- Not be opened before Technical Bidding.
c) The above mentioned two envelopes should be put in a bigger envelope with the
mention of category i.e. (Annexure) and it should be submitted in a sealed manner.
2. The technical bid documents will contain the following papers:
i.
Copy of previous work orders having such type of services rendered with I&CA
Department.
ii.
All papers as mentioned in the heading “Qualifying Requirements (QR)”
iii. Earnest Money of Rs. 2,000/- (Rupees Two Thousand ) only by Demand Draft
drawn in favour of “Secretary, Folk and Tribal Cultural Centre”, payable at
Kolkata shall be deposited along with the offer.
3. The rates will be inclusive of all charges like transport charges etc.
4. The rates are to be quoted both in words and figures. The evaluation would be made on technical
merits and financial quotes as per prescribed evaluation policy.
5. Quality of works or materials should be maintained by the agency.
6. The last date and time for submission of quotation is on 25th March, 2025 up to 1 pm. The
quotation will be opened on 25th March, 2025 at 2 pm. The bidders or his authorized person
may like to present at the time of opening of the tender.
.
7. The authority reserves the right to accept or reject any tender without assigning reason
whatsoever.
8. The Tender needs to be submitted in favour of The Director of Culture, Department of
Information & Cultural Affairs, Nabanna, 325 Sarat Chatterjee Road, Mandirtala,
Shibpur, Howrah – 711102.
9. The agency should have at least 3 years of experience of same nature and volume of work.
10. Selection of agency should be done on the basis of rates & technical parameters submitted
by the bidders.
11. In order to assure quality of Invitation Card relating to the Rabindra-Janmotsov-2025, evaluation
of the bids will be made taking into consideration of both the technical (non-price criteria) and
financial (price bid) parameters. More over since the programme demands the assurance of
quality. The Financial Proposal will be opened only for those bidders whose technical proposal
receive the minimum qualifying marks by the Evaluation Committee, i.e. more than 70 marks.

3

<!-- page 4 -->

Procedure of evolution of bid would be as follows:
Stage -1
Technical evolution Criteria
(Non-price criteria)100

1

2

3

4
5

Maximum
Score

Experience/ Credentials of handling
similar nature of work for any
Department/ agency of the State
Government in the past 3 years
Experience/ Credentials of handling
similar nature of work for Information
and Cultural Affairs Department of the
State Government in the past 3 years
Quality of performance / service
delivered in similar nature of work for
Information and Cultural Affairs
Department of the State Government
in the past 3 years

Marks allotted by the
evaluator

20

20

20

20

Equipment quality & Brand

20

All necessary documents for
participation in bid

Total marks scored
at stage 1

100

Selection Stage – I (Technical Bid Evaluation)

On the basis of technical evaluations a short list will be prepared on the basis of the marks obtained by the
respective bidder and the list will be prepared. To qualify for the financial bid, the bidders must have to
score more than 70 marks for technical bid.
Selection Stage – II (Financial Bid Evaluation)

The Financial Proposal will be opened only for those bidders whose technical/creative proposals receive the
minimum qualifying marks by the Evaluation Committee. If a Technical Bid does not receive the minimum
specified marks, the corresponding Financial Bid will not be opened.

4

<!-- page 5 -->

Qualifying Requirements (QR):

The Bidder shall provide:

(a)

Trade License

(b)

Proof of office address

(c)

GSTIN Registration Certificate (if any)

(d)

PAN Card

(e)

Testimonial from at least two clients

(f)

P Tax Registration Certificate

(g)

Latest income tax return

(h)

Last one year audit report

(i)

Work experience certificate.
Earnest Money of Rs. 2,000/- (Rupees Two Thousand ) only by Demand
Draft drawn in favour of “Secretary, Folk and Tribal Cultural Centre”,
payable at Kolkata shall be deposited along with the offer.

(j)

Dated this _______ day of ____________.

Signature
Address:

(in the capacity of Duly Authorized to sign bid for and on behalf of
…………………………..).

5

<!-- page 6 -->

ANNEXURE
( Enclosure to tender notice no. 1046-ICA(N) dated 18.03.2025
Financial Bid Format
(Price to be quoted here in this sheet)

Sl.
no.

1

Procurement of Invitation Card for Rabindra-Janmotsov-2025
Name of the
Rate
Specification
Qunty.
articles

(in Rs.)

Invitation Card
with envelop for
inaugural
ceremony

11”x5.5” (to be folded) multicolour offset printing, 300
GSM art board (folded size6.5”x6.5”) with envelop-7”x7”,
130 GSM Colour paper, multicolour print

Amount (in
Rs)

6000 nos.

TOTAL
Total Rupees in Word

Note:- GST to be added at the time of submission of bill.

Date :

Signature of the Bidder
Stamp:

6

<!-- page 7 -->

Government of West Bengal
Information & Cultural Affairs Department
325 S.C. Road Nabanna, Howrah-711102
Memo. No. 1047- ICA(N)

Date: 18.03.2025

Tender Notice
In connection with the “Rabindra-Janmotsov-2025”, scheduled to be held from 09th May 2025 to 24th
May 2025, sealed tenders are invited by the undersigned on behalf of the Information & Cultural
Affairs Department, Government of West Bengal from the bona fide and reputed agencies having
sufficient experience for procurement of Printing Materials as mentioned in the annexure. Interested
bidders may be submitted their tender papers as per annexure.
The Tender Forms, tender documents containing detailed specifications, terms & conditions etc. shall
be obtained from the following address on the basis of the applications of the interested bidders.
Room No. 907, 9th Floor, Nabanna, 325, Sarat Chatterjee Road, Howrah-711102 or Tender form
may be downloaded from the website: www.wb.gov.in / www.egiyebangla.gov.in
The tender documents will be available between 12 noon. to 5 P.M. from 18.03.2025 to 24.03.2025
excluding Saturday, Sunday and other Government holidays and the last date of submission of duly
filled up tender papers is on 25.03.2025 up to 1.00 pm and duly filled up tender paper shall be
submitted at above mentioned address. Technical bid will be opened on 25.03.2025 at 2.00 pm in the
Conference Room, Room No. 901, 9th Floor, Nabanna, 325, Sarat Chatterjee Road, Howrah711102.

Memo. No. 1047/(12) -ICA(N)

Sd/Director of Culture
I & CA Department, Govt. of W.B
Nabanna, Howrah
Date: 18.03.2025

Copy forwarded for favour of kind information and necessary action for wide publicity:
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.

All Member of the Departmental Tender Committee
The CEO, Nandan, 1/1 AJC Bose Road, Kolkata -700020
The Additional Director of Culture, 1/1 AJC Bose Road, Kolkata -700020
The Administrative Officer, Rabindra Sadan, 1/1 AJC Bose Road, Kolkata -700020
The Secretary, Paschimbanga Bangla Academy, 1/1 AJC Bose Road, Kolkata -700020
The Administrative Officer, Paschim Banga Natya Academy, 1/1 AJC Bose Road, Kolkata -700020
The Deputy Director of Culture and A.O. Sisir Mancha, 1/1 AJC Bose Road, Kolkata -700020
The Administrative Officer, Madhusudan Mancha, Dhakuria, Kolkata -700031
The Administrative Officer, Girish Mancha, 76/1 , Bagbazar Street , Kolkata -700003
P.A. to the Pr. Secretary, I & CA Department, Govt. of West Bengal, Nabanna, Howrah- 711102
Section Officer, Cell-IV, I & CA Department, Nabanna, Howrah- 711102
Copy for Guard file

Sd/Director of Culture
I & CA Department, Govt. of W.B
Nabanna, Howrah

<!-- page 8 -->

Bid Letter Form
(To be filled by the bidder)

From : ___________________

Date: ………………

(Registered name and address of the Bidder.)

To: Director of Culture,
Department of Information & Cultural Affairs,
325, Sarat Chatterjee Road,
Howrah-711102.
Sir / Madam,
Having examined the tender documents, I/we the undersigned, offer the rates as per prescribed Financial Bid Format for the following
works as per detailed in the bid document in response to your ‘Notice inviting Tender vide your No. 1047-ICA(N) dated 18.03.2025 :
For procurement of Printing Materials relating to the Rabindra-Janmotsov-2025

If our Bid is accepted, we undertake to:
1. Implement the prescribed work as per delivery schedule in conformity with the bid documents at the rate as
offered by us in the bid document.
2. Earnest Money of Rs. 2,000/- (Rupees Two Thousand ) only by Demand Draft drawn in favour of “Secretary, Folk
and Tribal Cultural Centre”, payable at Kolkata shall be deposited along with the offer.
3. Execute all contractual documents as required in the bid document.
4. Abide by all the terms & condition as mentioned in the Tender Documents.
5. Maintain validity of the contract until completion of the programme from the date of opening of the tender as
specified in the bid documents that shall remain binding upon us on acceptance of our offer.
6. All tender papers duly signed by the authorized person are enclosed herewith.
Dated. this _______ day of ____________.
Witness:
Signature:
Address:

(in the capacity of Duly Authorised to sign bid for and on behalf of …………………………..).

2

<!-- page 9 -->

A. General Terms and Conditions for Annexure
1. The tender papers should be submitted in the following manner:
a) One sealed envelope should contain documents for Technical Bidding with the mention
on the envelope as “TECHNICAL BID DOCUMENTS”
b) Another sealed envelope should contain the Financial Quotation with the mention on
the envelope as “FINANCIAL BID- Not be opened before Technical Bidding.
c) The above mentioned two envelopes should be put in a bigger envelope with the
mention of category i.e. (Annexure) and it should be submitted in a sealed manner.
2. The technical bid documents will contain the following papers:
i.
Copy of previous work orders having such type of services rendered with I&CA
Department.
ii.
All papers as mentioned in the heading “Qualifying Requirements (QR)”
iii. Earnest Money of Rs. 2,000/- (Rupees Two Thousand ) only by Demand Draft
drawn in favour of “Secretary, Folk and Tribal Cultural Centre”, payable at
Kolkata shall be deposited along with the offer.
3. The rates will be inclusive of all charges like transport charges etc.
4. The rates are to be quoted both in words and figures. The evaluation would be made on technical
merits and financial quotes as per prescribed evaluation policy.
5. Quality of works or materials should be maintained by the agency.
6. The last date and time for submission of quotation is on 25th March, 2025 up to 1 pm. The
quotation will be opened on 25th March, 2025 at 2 pm. The bidders or his authorized person
may like to present at the time of opening of the tender.
.
7. The authority reserves the right to accept or reject any tender without assigning reason
whatsoever.
8. The Tender needs to be submitted in favour of The Director of Culture, Department of
Information & Cultural Affairs, Nabanna, 325 Sarat Chatterjee Road, Mandirtala,
Shibpur, Howrah – 711102.
9. The agency should have at least 3 years of experience of same nature and volume of work.
10. Selection of agency should be done on the basis of rates & technical parameters submitted
by the bidders.
11. In order to assure quality of Printing Materials relating to the Rabindra-Janmotsov-2025,
evaluation of the bids will be made taking into consideration of both the technical (non-price
criteria) and financial (price bid) parameters. More over since the programme demands the
assurance of quality. The Financial Proposal will be opened only for those bidders whose
technical proposal receive the minimum qualifying marks by the Evaluation Committee, i.e.
more than 70 marks.

3

<!-- page 10 -->

Procedure of evolution of bid would be as follows:
Stage -1
Technical evolution Criteria
(Non-price criteria)100

1

2

3

4
5

Maximum
Score

Experience/ Credentials of handling
similar nature of work for any
Department/ agency of the State
Government in the past 3 years
Experience/ Credentials of handling
similar nature of work for Information
and Cultural Affairs Department of the
State Government in the past 3 years
Quality of performance / service
delivered in similar nature of work for
Information and Cultural Affairs
Department of the State Government
in the past 3 years

Marks allotted by the
evaluator

20

20

20

20

Equipment quality & Brand

20

All necessary documents for
participation in bid

Total marks scored
at stage 1

100

Selection Stage – I (Technical Bid Evaluation)

On the basis of technical evaluations a short list will be prepared on the basis of the marks obtained by the
respective bidder and the list will be prepared. To qualify for the financial bid, the bidders must have to
score more than 70 marks for technical bid.
Selection Stage – II (Financial Bid Evaluation)

The Financial Proposal will be opened only for those bidders whose technical/creative proposals receive the
minimum qualifying marks by the Evaluation Committee. If a Technical Bid does not receive the minimum
specified marks, the corresponding Financial Bid will not be opened.

4

<!-- page 11 -->

Qualifying Requirements (QR):

The Bidder shall provide:

(a)

Trade License

(b)

Proof of office address

(c)

GSTIN Registration Certificate (if any)

(d)

PAN Card

(e)

Testimonial from at least two clients

(f)

P Tax Registration Certificate

(g)

Latest income tax return

(h)

Last one year audit report

(i)

Work experience certificate.
Earnest Money of Rs. 2,000/- (Rupees Two Thousand ) only by Demand
Draft drawn in favour of “Secretary, Folk and Tribal Cultural Centre”,
payable at Kolkata shall be deposited along with the offer.

(j)

Dated this _______ day of ____________.

Signature
Address:

(in the capacity of Duly Authorized to sign bid for and on behalf of
…………………………..).

5

<!-- page 12 -->

ANNEXURE
( Enclosure to tender notice no. 1047-ICA(N) dated 18.03.2025
Financial Bid Format
(Price to be quoted here in this sheet)

Procurement of Printing Materials for Rabindra-Janmotsov-2025
Sl.
no.

Name of the articles

Specification

Qunty.

1

Badges

6”x4”, ID Card multi-colour
print with lamination &
printed ribbon for rest of the
programme

5000 nos.

2

ECS Mandate Forms

A4 size single colour print

1500 nos.

3

ECS Claim Forms for
performers

A4 size with duplicate copy

3500 nos.

4

ECS Claim Forms for
staff

A4 size with duplicate copy

300 nos.

5

Attendance sheet for
performers

A4 size single colour print

250 pcs.

6

Artistes list for group
performance

A4 size single colour print

100 pcs.

7

Car parking sticker

6”x4” multi-colour print

400 nos.

8

Invitation letter

A4 size single colour print

3500 nos.

9

Envelops

Office envelop with print

3500 nos.

Rate (in
Rs.)

Amount
(in Rs)

TOTAL
Total Rupees in Word

Note:- GST to be added at the time of submission of bill.

Date :

Signature of the Bidder
Stamp:

6

<!-- page 13 -->

Government of West Bengal
Information & Cultural Affairs Department
325 S.C. Road Nabanna, Howrah-711102
Memo. No. 1048- ICA(N)

Date: 18.03.2025

Tender Notice
In connection with the “Rabindra-Janmotsov-2025”, scheduled to be held from 9th May 2025 to 24th
May 2025, sealed tenders are invited by the undersigned on behalf of the Information & Cultural
Affairs Department, Government of West Bengal from the bona fide and reputed agencies having
sufficient experience for procurement of Stationary Articles as mentioned in the annexure. Interested
bidders may be submitted their tender papers as per annexure.
The Tender Forms, tender documents containing detailed specifications, terms & conditions etc. shall
be obtained from the following address on the basis of the applications of the interested bidders.
Room No. 907, 9th Floor, Nabanna, 325, Sarat Chatterjee Road, Howrah-711102 or Tender form
may be downloaded from the website: www.wb.gov.in / www.egiyebangla.gov.in
The tender documents will be available between 12 noon. to 5 P.M. from 18.03.2025 to 24.03.2025
excluding Saturday, Sunday and other Government holidays and the last date of submission of duly
filled up tender papers is on 25.03.2025 up to 1.00 pm and duly filled up tender paper shall be
submitted at above mentioned address. Technical bid will be opened on 25.03.2025 at 2.00 pm in the
Conference Room, Room No. 901, 9th Floor, Nabanna, 325, Sarat Chatterjee Road, Howrah711102.

Memo. No. 1048/(12) -ICA(N)

Sd/Director of Culture
I & CA Department, Govt. of W.B
Nabanna, Howrah
Date: 18.03.2025

Copy forwarded for favour of kind information and necessary action for wide publicity:
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.

All Member of the Departmental Tender Committee
The CEO, Nandan, 1/1 AJC Bose Road, Kolkata -700020
The Additional Director of Culture, 1/1 AJC Bose Road, Kolkata -700020
The Administrative Officer, Rabindra Sadan, 1/1 AJC Bose Road, Kolkata -700020
The Secretary, Paschimbanga Bangla Academy, 1/1 AJC Bose Road, Kolkata -700020
The Administrative Officer, Paschim Banga Natya Academy, 1/1 AJC Bose Road, Kolkata -700020
The Deputy Director of Culture and A.O. Sisir Mancha, 1/1 AJC Bose Road, Kolkata -700020
The Administrative Officer, Madhusudan Mancha, Dhakuria, Kolkata -700031
The Administrative Officer, Girish Mancha, 76/1 , Bagbazar Street , Kolkata -700003
P.A. to the Pr. Secretary, I & CA Department, Govt. of West Bengal, Nabanna, Howrah- 711102
Section Officer, Cell-IV, I & CA Department, Nabanna, Howrah- 711102
Copy for Guard file

Sd/Director of Culture
I & CA Department, Govt. of W.B
Nabanna, Howrah

<!-- page 14 -->

Bid Letter Form
(To be filled by the bidder)

From : ___________________

Date: ………………

(Registered name and address of the Bidder.)

To: Director of Culture,
Department of Information & Cultural Affairs,
325, Sarat Chatterjee Road,
Howrah-711102.
Sir / Madam,
Having examined the tender documents, I/we the undersigned, offer the rates as per prescribed Financial Bid Format for the following
works as per detailed in the bid document in response to your ‘Notice inviting Tender vide your No. 1048-ICA(N) dated 18.03.2025 :
For procurement of Stationary Articles relating to the Rabindra-Janmotsov-2025

If our Bid is accepted, we undertake to:
1. Implement the prescribed work as per delivery schedule in conformity with the bid documents at the rate as
offered by us in the bid document.
2. Earnest Money of Rs. 2,000/- (Rupees Two Thousand ) only by Demand Draft drawn in favour of “Secretary, Folk
and Tribal Cultural Centre”, payable at Kolkata shall be deposited along with the offer.
3. Execute all contractual documents as required in the bid document.
4. Abide by all the terms & condition as mentioned in the Tender Documents.
5. Maintain validity of the contract until completion of the programme from the date of opening of the tender as
specified in the bid documents that shall remain binding upon us on acceptance of our offer.
6. All tender papers duly signed by the authorized person are enclosed herewith.
Dated. this _______ day of ____________.
Witness:
Signature:
Address:

(in the capacity of Duly Authorised to sign bid for and on behalf of …………………………..).

2

<!-- page 15 -->

A. General Terms and Conditions for Annexure
1. The tender papers should be submitted in the following manner:
a) One sealed envelope should contain documents for Technical Bidding with the mention
on the envelope as “TECHNICAL BID DOCUMENTS”
b) Another sealed envelope should contain the Financial Quotation with the mention on
the envelope as “FINANCIAL BID- Not be opened before Technical Bidding.
c) The above mentioned two envelopes should be put in a bigger envelope with the
mention of category i.e. (Annexure) and it should be submitted in a sealed manner.
2. The technical bid documents will contain the following papers:
i.
Copy of previous work orders having such type of services rendered with I&CA
Department.
ii.
All papers as mentioned in the heading “Qualifying Requirements (QR)”
iii. Earnest Money of Rs. 2,000/- (Rupees Two Thousand ) only by Demand Draft
drawn in favour of “Secretary, Folk and Tribal Cultural Centre”, payable at
Kolkata shall be deposited along with the offer.
3. The rates will be inclusive of all charges like transport charges etc.
4. The rates are to be quoted both in words and figures. The evaluation would be made on technical
merits and financial quotes as per prescribed evaluation policy.
5. Quality of works or materials should be maintained by the agency.
6. The last date and time for submission of quotation is on 25th March, 2025 up to 1 pm. The
quotation will be opened on 25th March, 2025 at 2 pm. The bidders or his authorized person
may like to present at the time of opening of the tender.
.
7. The authority reserves the right to accept or reject any tender without assigning reason
whatsoever.
8. The Tender needs to be submitted in favour of The Director of Culture, Department of
Information & Cultural Affairs, Nabanna, 325 Sarat Chatterjee Road, Mandirtala,
Shibpur, Howrah – 711102.

9. The agency should have at least 3 years of experience of same nature and volume of work.

10. Selection of agency should be done on the basis of rates & technical parameters submitted
by the bidders.

11. In order to assure quality of Stationary Articles relating to the Rabindra-Janmotsov-2025,
evaluation of the bids will be made taking into consideration of both the technical (non-price
criteria) and financial (price bid) parameters. More over since the programme demands the
assurance of quality. The Financial Proposal will be opened only for those bidders whose
technical proposal receive the minimum qualifying marks by the Evaluation Committee, i.e.
more than 70 marks.

3

<!-- page 16 -->

Procedure of evolution of bid would be as follows:
Stage -1
Technical evolution Criteria
(Non-price criteria)100

1

2

3

4
5

Maximum
Score

Experience/ Credentials of handling
similar nature of work for any
Department/ agency of the State
Government in the past 3 years
Experience/ Credentials of handling
similar nature of work for Information
and Cultural Affairs Department of the
State Government in the past 3 years
Quality of performance / service
delivered in similar nature of work for
Information and Cultural Affairs
Department of the State Government
in the past 3 years

Marks allotted by the
evaluator

20

20

20

20

Equipment quality & Brand

20

All necessary documents for
participation in bid

Total marks scored
at stage 1

100

Selection Stage – I (Technical Bid Evaluation)

On the basis of technical evaluations a short list will be prepared on the basis of the marks obtained by the
respective bidder and the list will be prepared. To qualify for the financial bid, the bidders must have to
score more than 70 marks for technical bid.
Selection Stage – II (Financial Bid Evaluation)

The Financial Proposal will be opened only for those bidders whose technical/creative proposals receive the
minimum qualifying marks by the Evaluation Committee. If a Technical Bid does not receive the minimum
specified marks, the corresponding Financial Bid will not be opened.

4

<!-- page 17 -->

Qualifying Requirements (QR):

The Bidder shall provide:

(a)

Trade License

(b)

Proof of office address

(c)

GSTIN Registration Certificate (if any)

(d)

PAN Card

(e)

Testimonial from at least two clients

(f)

P Tax Registration Certificate

(g)

Latest income tax return

(h)

Last one year audit report

(i)

Work experience certificate.
Earnest Money of Rs. 2,000/- (Rupees Two Thousand ) only by Demand
Draft drawn in favour of “Secretary, Folk and Tribal Cultural Centre”,
payable at Kolkata shall be deposited along with the offer.

(j)

Dated this _______ day of ____________.

Signature
Address:

(in the capacity of Duly Authorized to sign bid for and on behalf of
…………………………..).

5

<!-- page 18 -->

ANNEXURE
( Enclosure to tender notice no. 1048-ICA(N) dated 18.03.2025
Financial Bid Format
(Price to be quoted here in this sheet)
Procurement of Stationary Articles for Rabindra-Janmotsov-2025
Sl.
No.

Name of the articles

Qunty.

1

A4 paper (Copy power)

20 rim

2

Legal paper (Copy power)

5 rim

3

Four folder file

20 pcs.

4

Clip board

12 pcs.

5

Small stapler

12 pcs.

6

File tag

1 pkt.

7

Flag

2 pkt.

8

Cartridge (88A) [HP]

4 pcs.

9

Cartridge (12A) [HP]

1 pc.

10

Highlighter Pen

1 box

11

Pen (use & throw)

1 box

12

Two way pen

1 box

13

CD Marker

6 pcs.

14

Permanent Marker

6 pcs.

15

Whitener

6 pcs.

16

Register Khata (4 no.)

12 pcs.

17

Register Khata (6 no.)

6 pcs.

18

Polymer rubber stamp (matter to be provided separately)

20 pcs.

19

Stamp pad (Small)

12 pcs.

6

Rate (in
Rs.)

Amount (in
Rs)

<!-- page 19 -->

20

Alpin

4 box.

21

Scale (1 ft.)

12 pcs.

22

Wood pencil

12 pcs.

23

Eraser

12 pcs.

24

Paper Scraper

1 Gross

25

Crockery Set

2
Dozens

26

Clove

1 Kg

27

Black Cardamom

1 Kg

28

Cutting Sugar Candy

1.5 Kg

29

Ginger

1.5 Kg
TOTAL

Total Rupees in Word

Note:- GST to be added at the time of submission of bill.

Date :

Signature of the Bidder
Stamp:

7
