---
doc_id: "e0d9aabaeeb833d0"
source_url: "https://home.wb.gov.in/public/assets/frontend/pdf/transport_of_animals_rules_1978.pdf"
ministry: "Home and Hill Affairs Department, West Bengal"
title: "0 2  TRANSPORT OF ANIMALS RULES, 1978"
date: ""
pages: 21
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "eec6834343b99eac"
---

<!-- page 1 -->

Transport of Animals, Rules, 1978.
In exercise of the powers conferred by clause (h) of sub-section (2) of Section 38 of the
Prevention of Cruelty to Animals Act, 1960 (59 of 1960); the Central Government hereby makes
the following rules, the same having been previously published as required by the said Section,
namely :
Transport of Animals Rules, 1978.
Chapter I
1. Short Title
These rules may be called the Transport of Animals, Rules, 1978.
2. Definitions :
In these rules, unless the context otherwise requires
(a)
qualified veterinary surgeon means one who holds a diploma or a degree of a recognised
veterinary college.
(b) "Schedule" means a schedule appended to these rules.
CHAPTER II
Transport of Dogs and Cats
3.
Rules 4 to 14 shall apply to the transport of dogs and cats of all breeds whether by rail,
road, inland, waterway, sea or air.
4. (a)

A valid health certificate by a qualified veterinary surgeon to the effect that the dogs
and cats are in a fit condition to travel by a rail, road, inland waterway, sea or air and
are not showing any sign of infectious or contagious disease including rabies, shall
accompany each consignment and the certificate shall be in the form specified in
Schedule - A.

(b) In the absence of such a certificate, the carrier shall refuse to accept the consignment for
transport.
5.

No dog or cat in an advanced stage of pregnancy shall be transported.

<!-- page 2 -->

6. (a)

Dogs or cats to be transported in the same container shall be of the same
species
and breed.

(b) Unweaned puppies of kittens shall not be transported with adult dogs or cats
other than their dams.
(c) No female dog or cat in season (cestrus) shall be transported with any male.
7. (a) Any dog or cat reported to be vicious or exhibiting a vicious disposition shall be
transported individually in a cage, muzzeled and labelled to give warning to the
handlers.
(b) In extreme cases, the dogs and cats shall be adminsitered with sedative drugs by a
qualified verterinary surgeon.
8. (1) When dogs or cats are to be transported for long distances:

9.

(a)

they shall be fed and given water atleast two hours prior to their transport and
shall not be packed for transport if they are hungry or thirsty. they should be
exercised as late as possible before despatch.

(b)

they shall be given adequate water for drinking every four hours in summer or
every six hours during winter.

(c)

they shall be fed once in twelve hours in the case of adult dogs or cats and
they shall be fed once in four hours in the case of puppies and kittens in
accordance with the instructions of the consignors if any.

(e)

adequate arrangements shall be made for their care and management during
the journey.

(2)

When the dogs or cats are to be transported by rail involving a journey of
more than, six hours, an attendent shall accompany the dogs or cats to supply
them with food and water on the way and the attendent shall have access to the
dogs or cats for this purpose at all stations and no dog or cat shall be exposed
to the direct blast of air during such journey.

Where dogs or cats are to be transported for short distance by road in a public vehicle,
the following precautions are to be taken namely:
(a)

they shall be put in a cage and the cage containing the dogs or cats
shall not be put on the roof of the vehicle but shall be put inside the
vehicle preferably near the end of the vehicle

(b)
the vehicle transporting the dogs or cats shall as far as possible
maintain constant speed, avoiding sudden stops and reducing effects of shocks
and jolts to the minimum.

<!-- page 3 -->

(c)

10.

at least one attendant shall be present at all times during transit who
shall ensure that proper transit conditions are observed and shall also
replenish food and water whenever necessary.

Where dogs or cats are to be transported by air:
(a)

the cages shall be properly cleaned and disinfected before the dogs or cats are
put in the cages.

(b)

sufficient paddy straw or saw dust or paper cuttings shall be provided for cats
in the cages as resting material.

(c)

for international transport, the dogs or cats shall be kept in pressurized
compartment with regulated temperature.

11.

The size and type of crates for transport of dogs and cats shall confirm as clearly as
may be to the size and type specified in Schedule - B and Schedule - C respectively.

12.

All containers of dogs or cats shall be clearly labelled showing the names address and
telephone number (if any) of the consignor.

13.

The consignee shall be informed about the train or transport arrival or flight number
and its time of arrival in advance.

14.

Consignment of dogs or cats to be transported by rail or road shall be booked by the
next passenger or main train or bus and should not be detained after accepting the
consignment for booking.
CHAPTER III
Transport of Monkeys

15.

Rules 16 to 23 shall apply to the transport of all types of monkeys from the trapping
area to the nearest rail-head.

16. (a) A valid health certificate by a qualified veterinary surgeon to the effect that the
monkeys are in a fit condition to travel from the trapping area to the nearest unit-head
and are not showing any sign of infections or contagious disease shall accompany
each consignment.
(b) In the absence of such a certificate, the carrier shall refuse to accept the consignment
for transport.
(c) The certificate shall be in a form specified in Schedule - D.
17. (1) Monkeys from one trapping area shall not be allowed to mix with monkeys from any
other trapping area for preventing the dangers of cross - infection.
(2) The time in transit from trapping area to the nearest rail-head shall be as short as
possible and factors causing stress to monkeys shall be reduced to the minimum.

<!-- page 4 -->

(3) If the travel time is longer than six hours provision shall be made to feed and to give water to the monkeys en route.
(4) During transit, precautions shall be taken to protect the monkeys from extreme
weather conditions and monkeys that die en route shall be removed at the earliest
available opportunity.
18.

Monkeys that are not completely weaned, that is, under 1.8 kilogram in weight, shall
not be transported except when specifically permitted by the Central Government.

19. (a) Pregnant and nursing monkeys shall not be transported except when specifically
permitted by the Central Government.
(b) Pregnant and nursing monkeys as well as monkeys weighing more than 5
kilograms-shall be transported in compartmented cages.
20. All monkeys in the same cage shall be of the same species and of approximately the
same weight and size.
21. Monkeys captured within their natural habitat shall be placed in new, sterilized or
thoroughly cleaned cages and subsequent transfer, if any, shall also be new, disinfected
or thoroughly cleaned cages.
22. Monkeys shall be transported from trapping area to the nearest rail-head by the fastest
means of transport available and the monkeys shall not be left un-attended at any time
during the journey.
23. 1. (a)

Monkeys shall be transported in suitable wooden or bamboo cages, so
constructed as not to allow the escape of the monkeys but permit sufficient
passage of air ventilation.

(b)

No nails, metallic projections or sharp edges shall be exposed on the exterior
or in the interior of the cages.

(c)

Each cage shall be equipped with appropriate water and feed receptacles
which are leak proof and capable of being cleaned and refilled during transit.

(2)

The floor of the cages shall be made of bamboo reapers and the space between each
reaper shall range between 20 mm and 30mm.

(3)

To facilitate carriage of these cages, provision may be made for rope loops at the four
top ends.

(4)

The weight of any one loaded cage shall not exceed 45 kilograms.

(5)

The following two sizes of cages shall be used.

<!-- page 5 -->

(a)

910 x 760 x 510 mm - to contain not more than twelve monkeys, weighing
between 1.8 and 3.00 kilograms each or ten monkeys weighing between 3.1
and 5.0kilograms,each.

(b) 710 x 710 x 510 mm - to contain not more than ten monkeys weighing
between 1.8 and 3.00 kilograms each or eight monkeys weighing between 3.1
and 5.00 kilograms each.
Provided that wooden cages as specified in Schedule - F to these rules may
also be used for carrying monkeys from the trapping area to the nearest
rail-head.
(6)

The construction details of two types of cages shall be given in Schedule - E.

24. Rules 25 to 32 shall apply to transport of monkeys from a rail - head to another railhead
or from a rail-head to nearest airport.
25.

(a)

Loading and unloading shall be carried out quickly and efficiently.

(c)
Cages shall be stored in such a manner that ventilation is adequate and
the monkeys are not exposed to drought and direct heat or cold.
(d) Monkeys found dead shall be removed as quickly as possible for suitable
disposal.
26. The transport cages shall be in accordance with specifications given in rule 28.
27. (1) Due provision shall be made by the sender for a sufficient supply of food and water
for the journey.
(2) In case the journey is over six hours an attendant shall accompany the monkeys to
supply them food, water, and such other things, on route and he shall have access to the
monkeys for feeding, giving water and attention at all stations en route.
(3) The food and water containers shall be checked at least every six hours and refilled, if
necessary.
(4) Monkeys shall not be disturbed during the night hours.
28. Not more than one cage shall be placed over the other and gunny packing shall be
placed between two cages, when one is placed over the other.
29. Monkeys shall be brought to the airport sufficiently early.
30. Monkeys shall be provided with food and water immediately before loading on the
aircraft.
31. (a) The cages shall be clearly labelled showing the name, address and telephone number
(if any) of the consignor and the consignee in bold red letters.

<!-- page 6 -->

(b) The consignee shall be informed about the train in which the consignment of monkeys
is being sent and its, arrival time in advance.
(c) The consignment of monkeys to be transported shall be booked by the next passenger
or main train and should not be detained after the consignment is accepted for booking.
32 (a) A valid health certificate by a qualified Veterinary Surgeon to the effect that the
monkeys are in a fit condition to travel from the nearest rail-head to another railhead or from
a rail-head to the nearest airport and are not showing any signs of infectious or contagious
disease shall accompany each consignment.
(b) In the absence of such a certificate, the carrier shall refuse to accept the consignment
for transport.
(c) The certificate shall be in a form specified in Schedule - D.
33.

Rules 34 to 45 shall apply in relation to the transport of monkeys by air.

34. The time in transit shall be as short as possible and factors causing stress to monkeys
shall be reduced to the minimum.
35.

Monkeys that are not completely weaned, that is, under 1.8 kilograms in weight, shall
not be transported except when specifically permitted by the Central Government.

36.

Pregnant and nursing monkeys shall not be transported except when specifically
permitted by the Central Government. Pregnant and nursing monkeys and monkeys
weighing over 5 kilograms shall be transported in specially designed individual cages.

37.

All monkeys in the some cage shall be of the same species and of approximately the
same weight and size.

38. (1) In view of the dangers of infection, only monkeys of the same species shall be
transported in the same cabin or compartment of the aircraft.
(2) Apparently sick or disabled monkeys exhibiting external injuries or infested with
parasites shall not be transported.
(3) Transport of other species of animals, birds, fish food stuff or poisonous materials,
such as pesticides and insecticides, in the same cabin or compartment shall not be
permitted.
39. (1) At no time during transit shall the monkeys be left unattended when carried in a
freighter aircraft.
(2) At least one attendant shall be present at all times when the aircraft is on the ground.
40. (1) Monkeys shall be transported in suitable wooden cages, so constructed as not to allow
the escape of the monkeys and shall allow sufficient passage of air for ventilation; no
nails, metallic projections or sharp edges shall be exposed in the interior or on the
exterior of such cages. Each cage shall be equipped with water and food receptacles

<!-- page 7 -->

which shall be leak - proof and be capable of being cleaned and refilled during transit.
A suitable absorbent material such as saw dust shall be kept in the dropping trays.
(2) The weight of any one loaded cage shall not exceed 45 kilograms in any case.
(3) The following two sizes of cages shall be used:
(a) 460 x 460 x 460 mm - to contain not more than ten monkeys weighing from 1.8 to
3.0 kilograms each or four monkeys weighing from 3.1 to 5.0 kilograms each; and
(b) 760 x 530 x 460 mm - to contain not more than ten monkeys weighing from 1.8 to
3.0 kilograms each or eight monkeys weighing from 3.1 to 5.0 kilograms each.
(4) The construction details of the two types of cages shall be as given in Schedule - F.
(5) The construction details of the two types of cages used for the transport of pregnant
and nursing monkeys shall be as given in Schedule - G.
4 1. (a) The cages shall be clearly labelled showing the name, address and telephones number
(if any) of the consignor and the consignee in bold red letters.
(b) The consignee shall be informed in advance about the flight number of the freighter
aircraft in which the consignment of monkeys is being sent and its arrival time.
(c)The consignment of monkeys to be transported shall be booked by the next flight of
the freighter aircraft and should not be detained after the consignment is accepted for
booking.
42. (1) A valid health certificate by a qualified veterinary surgeon to the effect that the
monkeys are fit to travel by air and are not showing any signs of infectious or
contagious disease shall accompany each consignment of monkeys.
(2) In the absence of such a certificate, the carrier shall refuse to accept the consignment
for shipment.
(3) The form of certificate under sub-rule (1) be as given in Schedule - D.
43. (1) The air shall be changed not less than twelve times per hour and droughts shall be
avoided and there shall be no dead pockets of air.
(2) Except when the monkeys are being fed and given water; they shall travel in semi
darkness to make them quieter and less inclined to fight and thus give them better
opportunities of resting.

44.The food and water containers shall be checked at every stop and refilled ; if necessary,
and a sufficient stock of food shall be available on the aircraft and at likely stopping
places.

<!-- page 8 -->

Note : About 85 grams of food per monkey is required daily. Suitable foods are dry cereal
grains or gram. It is recommended that whole gram made into biscuits or wheat meal bread
should be fed. A minimum of 140 ml. of water shall be allowed for each monkey per day.
45. An empty cage of the usual dimensions with its sides covered except 50mm at the top
to allow for ventilation shall be provided in the freighter aircraft for housing the monkeys
which fall sick or are injured during the journey.
CHAPTER IV
Transport of Cattle
46.

Rules 47 to 56 shall apply to the transport by rail of cows, bulls, bullocks, buffaloes,
yaks and calves. (hereinafter in these rules referred to as cattle).

4 7. (a) A valid certificate by a qualified veterinary surgeon to the effect that the cattle are in
a fit condition to travel by rail or road and are not suffering from any infectious or
contagious or parasitic diseases and that they have been vaccinated against rinderpest
and any other infectious or contagious or parasitic diseases, shall accompany each
consignment.
(b) In the absence of such a certificate, the carrier shall refuse to accept the consignment
for transport.
(c) The certificate shall be in the form specified in Schedule - E.
48. Veterinary first-aid equipment shall accompany all batches of cattle.
4 9. (a) Each consignment shall bear a label showing in bold red letters the name, address and
telephone number (if any) of the consignor and consignee, the number and types of
cattle being transported and quantity of rations and food provided.
(b)The consignee shall be informed about the train or vehicle in ' which the
consignment of cattle is being sent and its arrival time in advance.
(c)The consignment of cattle shall be booked by the next train or vehicle and shall not
be detained after the consignment is accepted for booking.
50. The average space provided per cattle in Railway wagon or vehicle shall not be less
than two square metres.
51. (a) Suitable rope and platforms should be used for loading cattle from vehicles.
(b) In case of railway wagon the dropped door of the wagon may be used as a ramp when
loading or unloading is done to the platform.
52. Cattle shall be loaded after they are properly fed and given water.
53.

Cattle in advanced stage of pregnancy shall not be mixed with young cattle in order to
avoid stampede during transportation.

<!-- page 9 -->

54. (1) Watering arrangements on route shall be made and sufficient quantities of water shall
be carried for emergency.
(2) Sufficient feed and fodder with adequate reserve shall be carried to last during the
journey.

(3) Adequate ventilation shall be ensured.
55. When cattle is to be transported by rail.
(a)

An ordinary goods wagon shall carry not more than ten adult cattle or fifteen calves
on broad gauge, not more than six adult cattle or ten calves on metre guage, or not
more than four adult cattle or six calves on narrow gauge.

(b)

every wagon carrying cattle shall have at least one attendant.

(c)

cattle shall be loaded parallel to the rails, facing each other.

(d)

rations for padding, such as straw, shall be placed on the floor to avoid injury if a
cattle lies down and this shall not be less than 6 cms thick.

(e)

rations for the journey shall be carried in the middle of the wagon.

(f)

to provide adequate ventilation, upper door of one side of the wagon shall be kept
open properly fixed and the upper door of the wagon shall have wire gauge closely
welded mesh arrangements to prevent burning cinders from the engines entering the
wagon and leading to fire outbreak.

(g)

cattle wagons should be attached in the middle of the train.

(h)

cooking shall not be allowed in the wagons nor hurricane lamps without chimneys.

(i)

two breast bars shall be provided on each side of the wagon, one at height of 60 to 80
cm and the other at 100 to 110 cm.

(j)

Cattle-in-milk shall be milked at least twice a day and the calves shall be given
sufficient quantity of milk to drink.

(k)

As far as possible, cattle may be moved during the nights only.

(1)

during day time, if possible, they should be unloaded, fed, given water and rested and
if in milk, milking shall be carried out.

56. When cattle are to be transported by goods vehicle the following precautions are to be
taken namely
(a)

Specially fitted goods vehicles with a special type of tail board and padding around the
sides should be used.

<!-- page 10 -->

(b)

Ordinary goods vehicles shall be provided with anti-slipping material, such as coir
matting or wooden baord on the floor and the superstructure, if low, should be raised.

(c)

no goods vehicle shall carry more than six cattle.

(d)

each goods vehicle shall be provided with one attendant.

(e) while transporting, the cattle, the goods vehicle shall not be loaded with any other
merchandise; and
(f)

to prevent cattle being frightened or injured, they should preferably, face the engine.
CHAPTER V
Transport of Equines

57. Rules 57 to 63 shall apply to the transport by rail, road or sea or horses, mules and
donkeys (hereinafter-in these rules referred to as 'equines')
5 8. (a) A valid certificate by a qualified veterinary surgeon to the effect that the equines are
in a fit condition to travel by rail; road or sea and are not suffering from any infectious
or contagious disease or diseases shall accompany each consignment.
(b)In the absence of such a certificate, the carrier shall refuse to accept the consignment
for transport.
(c)The certificates shall be in a form specified in Schedule - 1.
59. (a) Each consignment shall bear a label showing in bold red letters the name address and
telephone number (if any) of the consignor and consignee the number and type of
equines being transported and quantity of rations and food provided.
(b) The consignee shall be informed in advance about the train or vehicle or ship in which
the consignment of equines is being sent and its arrival time.
(c) The consignment of equines shall be booked by the next train or vehicle or ship and
shall be accepted for booking.
60. (a) Pregnant and young equines shall not be mixed with other animals.
(b) Different species of equines shall be kept separately.
(c) Equines shall be loaded after being fed and given water adequately, watering
arrangements shall be made enroute and sufficient food carried to last during the
journey.
(d) Veterinary first-aid equipment shall accompany all batches of equines.
(e) Adequate ventilation shall be ensured.

<!-- page 11 -->

(f) Suitable ramps and platforms, improvised where not available, shall be used for
loading and unloading equines.
61. For the transport of equines by rail, the following precautions shall be taken
(a) Equines shall be transported by passenger or mixed trains only;
(b)Ordinary goods wagon when used for transportation shall carry not more than eight to
ten horses or ten mules or ten donkeys on braod guage and not more than six horses or
eight donkeys on metre-gauge
(c) in extreme hot, water shall be sprinkled over the wagons containing equines by the
railway authorities to bring down temperature. Ice slabs in specially made containers
may be placed inside the wagan, if recommended by a qualified veterinary surgeon;
(d) every wagon shall have two attendants if the equines are more than two in number;
(e) equines shall be loaded parallel to the rails, facing each other;
(f) material for padding, such as paddy, straw, shall be placed on the floor to avoid injury
if an animal lies down and this shall not be less than 6 cm thick;
(g) to provide adequate ventilation, upper door of the side of the wagon shall be kept
open and properly fixed and the upper door of the wagon shall have wire guage
closely welded mesh arrangements to prevent burning cinders from the engines
entering the wagon and leading to fire break out;
(h) two breast bars shall be provided on each side of the wagon, one at a height of 50 to
80 cm and the other at 110 cm.
62. For the tranport of equines by goods-vehicles, the following precautions shall be taken,
namely :
(a) Specially fitted vehicles with a special type of tail-board and padding around the
sides shall be used ;
(b) ordinary goods vehicles shall be provided with antislipping material on the floor
and the super structure, if low, should be raised;
(c) bamboo poles of at least 8 cm diameter between each animal and two stout batons
at the back shall be provided to prevent the animal from falling;
(d) to prevent horses from being frightened or injured their heads should face left
away from the passing traffic;
(e) each vehicle shall not carry more than four to six equines;
(f) each vehicle shall be provided with one attendant;
(g) these vehicles shall be driven at a speed not more than 35 kilometers per hour;

<!-- page 12 -->

63. For the transport of equines by sea the following precautions shall be taken, namely:
(a) horses may normally be accommodated in single stalls and mules in pens, each
pen holding four to five mules;
(b) ample ventilation shall be ensured by keeping portholes and providing permanent
air trunks or electric blowers on all decks, and exhaust fans shall be installed to
blow out foul air;
(c) all standings shall be athwart the ship with heads facing inwards;
(d) to avoid distress specially during hot weather, the ship may go underway
immediately after embarking and disembarking shall be done as early as possible
after anchoring.
(e) colts and fillies shall be kept on the exposed decks;
(f) a pharmacy and spare stalls for five per cent of equines shall be available;
(g) passage between two rows of pens shall not be less than 1.5 metres.
CHAPTER - VI
Transport of Sheep and Goats
64. Rules 65 to 75 shall apply to the transport of sheep and goats by rail or road involving
journeys of more than six hours.
65. (a) A valid health certificate by a qualified veterinary surgeon to the effect that the sheep
and goats are in a fit condition to travel by rail or road and are not suffering from
infectious or contagious or parasitic disease shall accompany each consignment.
(b) In the absence of such a certificate, the carrier shall refuse to accept the consignment
for transport.
(c) The certificate shall be in a form specified in Schedule - J
66. (a) Each consignment shall bear a label showing in bold red letters the name, address and
telephone number (if any) of the consignor and consignee the number and type of
sheep or goats being transported and quanity of rations and food provided.
(b) The consignee shall be informed in advance about the train or vehicle in which the
consignment of sheep or goats are being sent and its arrival time.
(c) The consignment of sheep or gaots shall be booked by the next train or vehicle and
shall not be detained after the consignment is accepted for booking.
67. (a) First-aid equipment shall accompany the sheep or goats in transit.
(b) Suitable romps shall be provided for loading and unloading the sheep or goats.

<!-- page 13 -->

(c) In the case of a railway wagon, when the loading or unloading is done on the plot
form the dropped door of the wagon shall be used as a ramp.
68. Sheep and goats shall be transported seperately; but if the lots are small special partition shall
be provided to separate them.
69. Rams and male young stock shall not be mixed with female stock in the same
compartment.
70. Sufficient food and fodder shall be carried to last during the journey and watering facility
shall be provided at regular intervals.
71. Material for padding, such as straw, shall be placed on the floor to avoid injury if an
animal lies down, and this shall be not less than 5 cm. thick
72. The animals shall not be fettered unless there is a risk of their jumping out and their legs
shall not be tied down.
73. The space required for a goat shall be the same as that for a woolled sheep and the
approximate space required for a sheep in a goods vehicle or a railway wagon shall be as
under:Approximate weight of animal in Kilogram
Space required in Square metres
Woolled
0.18
0.20
0.23
0.28

Not more than 20
More than20 but not more than 25
More than 25 but not more than 30
More than 30

Shorn
0.16
0.18
0.22
0.26

74. (a) No railway wagon shall accommodate more than the following number of the sheep
or goats :
Broad gauge

Metre gauge

Narrow gauge

(1)

(2)

(3)

(4)

(5)

Area of
wagon

Area of
Wagon

Area of
Wagon

Area of Wagon

Less than

21.1

Less than

12.5

21.1

Square Metres
And above

12.5

Square
above

70

100

50

60

Metres

and
25

<!-- page 14 -->

(b) Adequate ventilation shall be provided in every wagon. Upper door of one side of
wagon shall be kept open and properly fixed and the upper door of the wagon shall
have wire guage closely welded mesh arrangements to prevent burning cinders from
the engines entering the wagon and leading to fire breakout.
75. (1) Goods vehicles of capacity of 5 or 4 1/2.tons, which are generally used for
transporting animals, shall carry not more than forty sheep or goats.
(2) In the case of large goods vehicles and wagons, partition shall be provided at every
two or three metres across the width to prevent the crowding and trapping of sheep and
goats.
(3) In the case of ewes, goats or lambs or kids under six weeks of age, separate panels
shall be provided.
I.SCHEDULAE - A
(SEE RULE 4)
Proforma for certificate of fitness to Travel - Dogs / Cats
This Certificate should be completed and signed by a qualified Veterinary Surgeon
Date and time of examination : ................................................................….
Species of dogs / cats : ............................................................................…..
Number of cages :…………………… Number of Dogs / cats ……………
Breed and identification marks, if any ............................................................
Transported from ..................................To .....………..Via…………………
I hereby certify that I have read rules 8 to 14 in Chapter 11 of the Transport of Animals
Rules, 1978.
1.

That, at the request of (consignor) ........................................I have examined the above
mentioned dogs / cats in their travelling cages not more than 12 hours before their
departure.

2.

That each of the dogs / cats appeared to be in good health, free from signs of injury,
contagious and infectious disease including rabies and in a fit condition to travel by rail
/ road / inland / waterway / sea / air.

3.

That the dogs / cats were adequately fed and watered for the purpose of the journey.

4.

That the dogs / cats have been vaccinated.

(a) Type of vaccine/s:

<!-- page 15 -->

(b) Date of vaccination/s:
Signed ............................................
Address..........................................
………………………………….
………………………………….
Qualifications.................................

Date ..........................................

2.SCHEDULE - B
(SEE RULE 11)
Size and Type of Crate for Transport of Dogs
The design of the cage mentioned in rule 11 in Chapter 11 of the Transport of Animals Rules,
1978 shall be as per the design as printed on page 7 of IS: 4746 - 1968 published by the
Indian Standards Insitution.
- All dimensions in centimetres
By Rail / Road / Inland Waterways Sea, By Air

Length (L)

A x 1 1/2

A + C + 10

Width (W)

A

D + 2 + 10

Height (H)

B + 15

B+0

Length - tip of nose to root of tail (A)
Width - width across the shoulders (D)
Height - Tip of ears to toe while standing (13)
Elbow size - Toe to tip of elbow (C)
Note : Cages, Cartons or crates, used to transport dogs, shall be of such material which will
not tear or crumble. They shall be well constructed, well ventilated and designed to protect
the health of dogs by giving them adequate space and safety. It is essential that wire mesh
should be nose and pow proof; suitable material is that welded wire mesh of not less than

<!-- page 16 -->

3mm with a spacing 12 x 12 mm. Expanded metal and wire netting are unsuitable for this
purpose. There should be no protuding nails or unprotected edges of wire. Dogs Kennels in
rail coaches shall be so placed as to give protection to dogs from extremes of temperature and
disturbance from birds and by giving them adequate space for health and safety.
3. SCHEDULE - C
(SEE RULE 11)
Size and Type of Crate for Transport of Cats
The design of the cage mentioned in rule 11 in Chapter 11 of the Transport of Animals Rules,
1978 shall be as per the design as printed on page 8 of ISI 4746 - 1968 published by the
Indian Standards Institution.
All dimensions in Centimetres
By rail / road / inland waterways sea by air
Length (L)

Ax2

Ax2

Width (W)

A

A

Height (H)

B + 15

B + 10

Length - Tip of nose to root of tail (A)
Width - Width across the shoulders (D)
Height - Tip of ears to toe while standing (B)
Elbow size - Toe to tip of elbow (C)
Note: Cages, cartons or crates, used to transport cats, shall be of such material which will not
tear or crumble. They shall be well constructed, well ventilated and designed to protect the
health of the cats by giving them adequate space and safety. It Is essential that wire mesh
should be nose and paw proof; suitable material is a welded wire mesh of not less than 3mm
with a spacing 12 x 12 mm. Expanded metal wire netting are unsuitable for this purpose.
There should be no protruding nails or unprotected edges of wire. Cats Kennels in rail
coaches shall be so placed as to give-protection to cats from extremes of temperature and
disturbance from birds and by giving them adequate space for health and safety.
4. SCHEDULE - D
(SEE RULE 16 AND 32)
Proforma for Certificate of fitness to Travel Monkeys
This Certificate should be completed and signed by a qualified Veterinary Surgeon.

<!-- page 17 -->

Date & time of examination: .................................................................. ………
Species of Monkeys : ............................................................................………..
Number of Cages ………………………..Number of Monkeys ………………
Sex…………………………Age……………………………………………….
Breed and identification marks, if any ....................................…………………
Transported from ................................. To………………Via …………………
I hereby certify that I have read rules 15 to 45 in Chapter III of the Transport of
Animals Rules, 1978.
1. That, at the request of (consignor) ............................................I have examined the above
mentioned monkeys in their travelling cages not more than 12 hours before their
departure.
2. That each monkey appeared to be in a fit condition to travel from the trapping area to the
nearest rail-head / from the nearest rail-head to another rail-head / from the rail - head to
the nearest airport / by air and is not showing any signs of infectious or cantagious
diseases.
3. That the monkeys appeared to be under 6 months of age and that no animal appeared to
be pregnant.
4.

That the monkeys were adequately fed and watered for the purpose of the journey.

5.

That the monkeys have been vaccinated.
(a) Type of vaccine/s:
(b) Date of vaccination/s:
Signed.........................................
Address
....................................................
....................................................
Qualifications…………………..
Date ..........................................

<!-- page 18 -->

5. SCHEDULE - E
[See Rule 23(5) (a) and Rule 23(6)]
Size and Type of Crate for transport of
Monkeys from Trapping area to nearest Rail-head
The construction details of two types of cages mentioned in rule 22(5) (a) in Chapter III of
the Transport of Animals Rules, 1978 shall be as per the dimensions and design as printed on
page 5 of IS: 3699 (Part - 1) - 1966 published by Indian Standards Institution.
6. SCHEDULE - F
[See Rule 40 (4)]
Size and Type of Crate for Transport of Monkeys by Air
The construction details of two types of cages mentioned in rule 40(3) (a) and (b) in Chapter
III of the Transport of Animals Rules, 1978 shall be as per the dimensions and design as
printed on page 6 of IS: 3059 - 1965 published by Indian Standards Institution.
7. SCHEDULE - G
[See Rule 40 (5)]
Size and Type of Crate for Transport by Air of pregnant and Nursing
Monkeys and Monkeys weighing over 5 kg.
The construction details of two types of cages mentioned in rule 40(5) in Chapter III of the
Transport of Animals Rules, 1978 shall be as per the dimensions and design as printed on
page 7 of IS: 3059 -1965 published by Indian Standards Institution.
8. SCHEDULE - H
[See Rule 47]
Proforma for Certificate of fitness to travel Cattle
This Certificate should be completed and signed by a qualified Veterinary Surgeon
Date and time of examination : ..................................................................
Species of cattle : .......................................................................................
Number of Trucks / Railway Wagons .............................................................
Number of cattle : ................................ ................................................................
Sex……………………………Age ……………………………………………..
Breed and identification marks, if any ..........................................................…..

<!-- page 19 -->

Transported from ................................. To ...................Via………………….
I hereby certify that I have read rules 46 to 56 in Chapter IV of the Transport of Animals
Rules, 1978.
1.

That, at the request of (consignor) .........................................I have examined the above
mentioned Cattle in the goods vehicle/ railway wagons not more than 12 hours before
their departure.

2.

That each cattle appeared to be in a fit condition to travel by rail/road and is not
showing any signs of infectious or contagious or parasitic disease and that it has been
vaccinated against rinderpest and any other infectious or contagious or parasitic
diseases(s).

3.

That the cattle were adequately fed and watered for the purpose of the journey.

4.

That the cattle have been vaccinated.

(a) Type of vaccine :
(b) Date of vaccination:
Signed .........................................................
Address ...................................................
...............…………………………………
Qualifications ................................................
Date ..........................................
9. SCHEDULE - I
[See Rule 58]
Proforma for Certificate of fitness to travel Equines
This Certificate should be completed and signed by a qualified Veterinary Surgeon.
Date and time of examination : ..................................................................
Specles of Equines: ....................................................................................
Number of Equines: ....................................................................................
Sex……………… ....................................Age ............................... ... .. ..
Breed and identification marks, if any...…………………………………..

<!-- page 20 -->

Transported from ……………..To ...... ……..Via…. ..... ………………..
I hereby certify that I have read rules 57 to 63 in Chapter V of the Transport of Animals
Rules, 1978.
1.

That, at the request of (consignor) .......................... I examined the above mentioned
equines not more than 12 hours before their departure.

2.

That each equine appeared to be in a fit condition to travel by rail/road/sea and is not
showing any signs of any infectious or contagious disease(s) and that it has been
vaccinated against any infectious or contagious diseases(s).

3.

That the equines were adequately fed and watered for the purpose of the journey.

4.

That the equines have been vaccinated.

(a) Type of vaccine (s) :
(b) Date of vaccination:

Signed……………………………..
Address.........……………………
……………………………
Qualifications…………………
Date ..........................................
10. SCHEDULE - J
[See Rule 651
Proforma for Certificate of fitness to Travel - Sheep and Goats
This Certificate should be completed and signed by a qualified Veterinary Surgeon
Date and time of examination : ..................................................................
Species of Animals : ....................................................................................
Number of Animals : .................................................................................
Sex……………. .......................................Age …………………………
I hereby certify that I have read rules 64 to 75 in Chapter VI of the Transport of Animals
Rules, T978.

<!-- page 21 -->

1. That, at the request of (consignor) ............................................I have examined the above
mentioned animals not more than 12 hours before their departure.
2. Thai each animal appeared-to be in a fit condition to travel by rail/road and is not showing
any signs of any infectious or contagious or parasitic disease(s) and that it has been
vaccinated against any infectious or contagious or parasitic disease(s),
3. That the animals were adequately fed and watered for the purpose of the journey.
4. That the animals have been vaccinated.
(a) Type of vaccine(s):
(b) Date of vaccination:
Signed .........................................................
Address .........................................................
. .............................……………………….
Qualifications ................................................
Date ..........................................
