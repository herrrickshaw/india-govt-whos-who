---
doc_id: "5a15f7e4cbf5ba7c"
source_url: "https://www.wbhidcoltd.com/upload_file/NIT-19_2026-27_AGM(E)-4.pdf"
ministry: "West Bengal Housing Infrastructure Development Corporation Limited, (WBHIDCO), West Bengal"
title: "Emergent rain damage repairing of MAR-1111 surface from 7th Intersection to Haldiram Bridge (Towards Airport) in NEW TOWN KOLKATA.(e-Tender)"
date: ""
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "56bd1cc49385e7d0"
---

<!-- page 1 -->

WEST BENGAL HOUSING INFRASTRUCTURE DEVELOPMENT CORPORATION LIMITED
(A Government of West Bengal Undertaking)
HIDCO BHABAN, Premises No.35-1111, Near 3rd Rotary, New Town, Kolkata-700156.

Notice Inviting e-Tender No. 19 -of 2026-27
Memo. No.

431/HIDCO/AGM(Engg)-IV/33/Reapiring/NIT-19/2026-27

Dated:

30.10.2026

Additional General Manager (Engg)-IV, on behalf of WB HIDCO invites e-tender for the work detailed in the table below. (Submission of Bid
through online)
List of Schemes:
Sl.
No

Name of the work
(1)`

Rs.65,81,057.00
(Rupees
Sixty
Fifty Lakh Eighty
One Thousand and
Fifty Seven Only)

Rs.1,31,621.00
(Rupees One Lakh
Thirty
One
Thousand
Six
Hundred
and
Twenty One Only)
to be submitted
online through any
net banking enable
bank account or
offline
through
any
bank
by
generating NEFT /
RTGS
Challan
from
the
ETendering portal.

1.

Period of
Completion
(4)

Name of the
Concerned
Officer
(5)

Additional General Manager (Engg)-IV, WB HIDCO

Earnest Money
(Rs.)
(3)

1 (One) Month from the date of commencement.

Estimated Amount
(Rs.)
(2)

Eligibility of Contractor
(6)
i)Intending tenderers should produce credentials of a
similar nature of completed work of the minimum
40% of the estimated amount put to tender during 5
(five) years prior to the date of issue of the tender
notice; or,
ii)Intending tenderers should produce credentials of 2
(two) similar nature of completed work, each of the
minimum value of 30% of the estimated amount put to
tender during 5(five) years prior to the date of issue of
the tender notice; or,
iii)Intending tenderers should produce credentials of
one single running work of similar nature which has
been completed to the extent of 80% or more of the
desired value at above (i)
In case of running works, only those tenderers who
will submit the certificate of satisfactory running
work from concerned Executive Engineer, or
equivalent competent authority will be eligible for the
tender. In the required certificate it should be clearly
stated that the work is in progress satisfactorily and
also that no penal action has been initiated against the
executed agency, i.e., the tenderer.
iv)Intending tenderers should not be black listed from
any Govt. Organization during last 5 (five) years.
Agency must have own running Batch Mix Plant of
minimum capacity 90-120 TPH at a distance within
10Km form the work site and Sensor Paver Machine
and Tandem Roller, Static Roller, Dumper.
Agency will provide the suitable facility to check the
activities of Batch Mix Plant during & before
execution.

1.

Emergent
rain
damage
repairing
of
MAR-1111
surface from 7th
Intersection
to
Haldiram
Bridge
(Towards Airport)
in
NEW TOWN
KOLKATA.

1)

In the event of e-filling, intending bidder may download the tender documents from the website http://etender.wb.nic.in directly with
the help of Digital Signature Certificate.
The process of deposit of earnest money through offline instruments like Bank Draft, Pay Order etc. has been stopped for
e tender procurement of this office. Necessary Earnest Money will be deposited by the bidder electronically online through
his net banking enabled bank account, maintained at any bank or offline through any bank by generating NEFT / RTGS
Challan from the e-tendering portal. Intending Bidder will get the Beneficiary details from e-tender portal with the help of
Digital Signature Certificate and may transfer the EMD from their respective Bank as per the Beneficiary Name & Account
No., Amount, Beneficiary Bank Name (ICICI Bank) & IFSC Code and e-Proc Ref. No.
Intending bidder who wants to transfer EMD through NEFT / RTGS must read the instruction of the Challan generated from
E Procurement site.
Bidders are also advised to submit Earnest Money of their bid, at least 03 (three) working days before the bid submission
closing date, if payment is made offline through any bank by generating NEFT / RTGS as it requires time for processing of
Payment of EMD.

2)

Both Technical Bid and Financial Bid are to be submitted concurrently duly digitally signed in the website http://etender.wb.nic.in

3)

Tender documents may be downloaded from website and submission of Technical Bid and Financial Bid will be done as per Time
Schedule stated in Sl. No. 15

4)

The FINANCIAL OFFER of the prospective tenderer will be considered only if the TECHNICAL BID of the tenderer is found qualified
by the ‘Tender Evaluation Committee’ formed by the authority of WB HIDCO Ltd. The decision of the ‘Tender Evaluation Committee’
will be final and absolute in this respect. The list of Qualified Bidders will be displayed in the website.

Seal and Signature of the Tenderer.

Additional Geneal Manager (Engg)-IV,

WB HIDCO

<!-- page 2 -->

Notice Inviting e-Tender

5)

Eligibility criteria for participation in the tender.
i)

As per e-NI-T detail table (Sl.No.6) above and Affidavit – in form ‘A’ would be after publication of E.NIT date & should be
mentioned in the body of Affidavit the e.NIT No. & date.

Income Tax Acknowledgement Receipt for the latest Assessment year, P.T. Deposit Challan for the current year , Pan Card, GST
Registration Certificate are to be accompanied with the Technical Bid Documents.
[Non-statutory documents]
The prospective bidders or any of their constituent partner shall neither have abandoned any work nor any of their contract have been
rescinded during the last 5 (Five) years. Such abandonment or rescission will be considered as disqualification towards eligibility. (A
declaration in this respect through affidavit has to be furnished by the prospective bidders without which the Technical Bid shall be treated as
non-responsive.)
In case of Proprietorship, Partnership Firms and Company, Tax Audit Report in 3CD Form are to be furnished along with the Balance Sheet
and Profit and Loss Account, and all the documents along with schedules forming the part of Balance Sheet and Profit & Loss Account
should be in favour of applicant. No other name alongwith applicant’s name in such enclosure will be entertained.
[Non-statutory documents]
The prospective bidders should own or arrange through lease hold registered agreement, the required plant and machineries. Conclusive
proof of ownership in favour of owner or leaser of plant and machineries in working condition shall have to be submitted. (Ref. Section – B,
Form – III)
[Non-statutory documents]
Registered Partnership Deed for Partnership Firm only along with Power of Attorney is to be submitted. The company shall furnish the Article
of Association and Memorandum.
[Non-statutory documents]
Joint Ventures will not be allowed.
A prospective bidder shall be allowed to participate in a particular job either in the capacity of individual or as a partner of a firm. If found to
have applied severally in a single job, all his applications will be rejected for that job, without assigning any reason thereof.
The executing agency may not get a running payment unless the gross amount of running bill is minimum 30% of the tendered amount.
Provisions in Clause(s) 7, 8 & 9 contained in W.B. Form No.2911(ii) so far as they relate to quantum and frequency of payment are to be
treated as superseded.
Adjustment of price in respect of construction materials shall not be applicable. The bidders shall quote their rate accordingly.
Mobilization advance
No mobilisation advance and secured advance will be allowed.
Security Deposit:
Retention money towards performance Security amounting to 10% (Ten percent) of the value of the work shall be deducted from the running
account bill of the tenderer as per prevailing order. No interest will be paid on Security Deposit.
Agencies shall have to arrange land for erection of Plant & Machineries, storing of materials, labour shed, laboratory etc. at their own cost
and responsibility.
All materials required for the proposed work shall be of specified grade inconformity with relevant code of practice (latest revision)
accordingly and shall be procured and supplied by the agency at their own cost including all taxes. If required by the Engineer-in-Charge,
further testing from any Government approved Testing Laboratory shall have to be conducted by the agency at their own cost.
Constructional Labour Welfare CESS @ 1% (one percent) of cost of construction will be deducted from every Bill of the selected agency.
There shall be no provision of Arbitration.
Bid shall remain valid for a period not less than 180 (one hundred eighty) days from the last date of submission of Financial Bid / Sealed Bid.
If the bidder withdraws the bid during the validity period of bid, the earnest money as deposited will be forfeited forthwith without assigning
any reason thereof.

Seal and Signature of the Tenderer.

Additional General Manager (Engg)-IV

WB HIDCO

<!-- page 3 -->

Notice Inviting e-Tender

6)

Date and Time Schedule:

Sl.
No.

Particulars

Date & Time

1

Date of uploading of N.I.T. & other Documents (online)

2

Documents download/sell start date (Online)

3010.2026 from 06.00 P.M.

3

Documents download/sell end date (Online)

14.11.2026 upto 02.00 P.M

4

Bid submission start date (On line)

30.10.2026 from 06.00 P.M.

5

Bid Submission closing (On line)

14.11.2026 upto 02.00 P.M

6

Bid opening date for Technical Proposals (Online)

17.11.2026 at 03.00 P.M

7

Date of uploading the final list of Technically Qualified Bidder(online) after disposal of

30.10.2026

To be Notified later

appeals, if any.

8
7)

To be Notified later

Date for opening of Financial Proposal (Online)

The Prospective Bidder shall have to execute the work in such a manner so that appropriate service level of the work is maintained
during progress of work and a period of 1 (One) year from the date of successful completion of the work to the entire satisfaction of
the Engineer-in-Charge. If any defect / damage is found during the period as mentioned above, the contractor shall make the
same good at his own cost to the specification at par with instant project work. On failure to do so, penal action against the
contractor will be imposed by the Department as deem fit. The contractor may quote his rate considering the above aspect.
Refund of Security Deposit will only be made after successful maintaining of appropriate service level of the work as mentioned
above for 1 (one) year from the date of completion of the work. Provision in Clause No. 17 of Form No. 2911(ii) shall be treated as
superseded.

8)

Site of work and necessary drawings may be handed over to the agency phase wise. No claim in this regards will be entertained.

9)

Earnest Money- a) As mentioned above.
Additional performance security @10% of the tendered amount shall have to be deposited in the form of bank Guarantee
by the successful bidder if the accepted bid value is 80% or less of the estimated value put to tender.

10)

The Bidder, at his own responsibility and risk is encouraged to visit and examine the site of works and its surroundings and obtain
all informations that may be necessary for preparing the Bid and entering into a contract for the work as mentioned in the Notice
Inviting Tender, before submitting offer with full satisfaction, the cost of visiting the site shall be at his own expense.

11)

The intending Bidders shall clearly understand that whatever may be the out come of the present invitation of Bids, no cost of
Bidding shall be reimbursable by the Department.The tender accepting authority of WBHIDCO Ltd. reserves the right to accept
or reject any offer without assigning any reason whatsoever and is not liable for any cost that might have been incurred by any
Tenderer at the stage of Bidding.

12)

Refund of EMD: The Initial Earnest Money of all the unsuccessful tender deposited online through e-procurement portal of
Government of West Bengal Website http://etender.wb.nic. in with the tender will be refunded accordingly to the order of Finance
Department of Government of West Bengal vide no.-3975-F(Y) of 28th July 2016.

13)

Prospective applicants are advised to note carefully the minimum qualification criteria as mentioned in ‘Instructions to Bidders’
stated in Section – ‘A’ before tendering the bids.

14)

Conditional / Incomplete tender will not be accepted under any circumstances.

15)

The intending tenderers are required to quote the rate online.

16)

Contractor shall have to comply with the provisions of (a) the contract labour (Regulation Abolition) Act. 1970 (b) Apprentice Act.
1961 and (c) minimum wages Act. 1948 of the notification thereof or any other laws relating there to and the rules made and order
issued there under from time to time.

Seal and Signature of the Tenderer.

Additional General Manager (Engg)-IV

WB HIDCO

<!-- page 4 -->

Notice Inviting e-Tender

17)

Guiding Schedule of Rates:

Rates have been taken from latest P.W.D. (W.B.) Schedule of Rates for “Road & Bridge Works”,

“Building Works” and “Sanitary & Plumbing Works” along with upto date corrigenda & addenda and approved rates of the
Superintending Engineer, Project Construction Circle, Public Works (C.B.) Directorate, Government of West Bengal.
18)

During scrutiny, if it comes to the notice of the tender inviting authority that the credential or any other paper found incorrect /
manufactured / fabricated, that bidder would not be allowed to participate in the tender and that application will be rejected without
any prejudice.

19)

The Addl. General Manager-IV, WBHIDCO reserves the right to cancel the N.I.T. due to unavoidable circumstances and no claim
in this respect will be entertained.

20)

If there be any objection regarding prequalifying the Agency that should be lodged on line to the Chairman of Tender Evaluation
Committee within 2 (two) days from the date of publication of list of qualified agencies and beyond that time schedule no objection
will be entertained by the Tender Evaluation Committee.

21)

Before issuance of the WORK ORDER, the tender inviting authority may verify the credential and other documents of the lowest
tenderer if found necessary. After verification if it is found that the documents submitted by the lowest tenderer is either
manufactured or false in that case work order will not be issued in favour of the said Tenderer under any circumstances.

22)

If any discrepancy arises between two similar clauses on different notification, the clause as stated in later notification will
supersede former one in following sequence:
1)

Form No. 2911(ii)

2)

N.I.T.

3)

Special Terms & Conditions

4)

Technical Bid

5)

Financial Bid

23 ) Qualification criteria:
The tender inviting and Accepting Authority through a “Tender Evaluation Committee” will determine the eligibility of each bidder.
The bidders shall have to meet all the minimum criteria regarding:
1)

Financial Capacity

2)

Technical Capability comprising of personnel & equipment capability

3)

Experience / Credential

The eligibility of a bidder will be ascertained on the basis of the document(s) in support of the minimum criteria as mentioned in (a),
(b) & (c) above and the declaration executed through prescribed affidavit in non-judicial stamp paper of appropriate value duly
notarized. If any document submitted by a bidder is either manufactured or false, in such cases the eligibility of the bidder /
tenderer will be rejected at any stage without any prejudice

Seal and Signature of the Tenderer.

Additional General Manager (Engg)-IV

WB HIDCO

<!-- page 5 -->

Notice Inviting e-Tender

24.

Escalation of Price on any ground and consequent cost over run shall not be entertained under any circumstances. Rates should be
quotedaccordingly.

25. No. price preference and other concession asper order no. 1110F dated: 10/02/2006 will be allowed.

Memo. No.

431/HIDCO/AGM(Engg)-IV/33/Reapiring/NIT-19/2026-27

Dated:

30.10.2026

Copy forwarded for information to:1)

Joint Managing Director-I, WB HIDCO.

2)

Chief Engineer, WBHIDCO

3)

Chief Finance Officer, WB HIDCO.

Seal and Signature of the Tenderer.

Additional General Manager (Engg)-IV

WB HIDCO

<!-- page 6 -->

Section - B

SECTION - A
INSTRUCTION TO BIDDERS
General guidance for e-Tendering:
Instructions / Guidelines for electronic submission of the tenders have been annexed for assisting the contractors to participate in
e-Tendering.
i.

Registration of Contractor:
Any contractor willing to take part in the process of e-Tendering will have to be enrolled & registered with the Government eProcurement System, through logging on to https://etender.wb.nic.in (the web portal of WBHIDCO the contractor is to click on
the link for e-Tendering site as given on the web portal.

ii.

Digital Signature certificate (DSC):
Each contractor is required to obtain a Class-II or Class-III Digital Signature Certificate (DSC) for submission of tenders from
the approved service provider of the National Informatics Centre (NIC) on payment of requisite amount. Details are available at
the Web Site stated in Clause A.1. above. DSC is given as a USB e-Token.

iii.

The contractor can search & download N.I.T. & Tender Document(s) electronically from computer once he logs on to the
website mentioned in Clause A.1. using the Digital Signature Certificate. This is the only mode of collection of Tender
Documents.

iv.

Participation in more than one work:
A prospective bidder shall be allowed to participate in the job either in the capacity of individual or as a partner of a firm. If
found to have applied severally in a single job all his applications will be rejected for that job.

v.

Submission of Tenders:
Tenders are to be submitted through online to the website stated in Clause A.1. in two folders at a time for each work, one in
Technical Proposal & the other is Financial Proposal before the prescribed date &time using the Digital Signature Certificate
(DSC). The documents are to be uploaded virus scanned copy duly Digitally Signed. The documents will get encrypted
(transformed into non readable formats).
Technical Proposal:
The Technical proposal should contain scanned copies of the following in two covers (folders).
(a). Statutory Cover Containing the following documents:

1)

PREQUALIFICATION DOCUMENTS:
•

Prequalification Application (Sec-B, Form – I)

•

Demand Draft towards cost of tender documents as prescribed in the N.I.T. against each of the serial of work in favour of the
WBHIDCO LTD.

•

Demand Draft towards Earnest Money (EMD) as prescribed in the N.I.T. against each of the serial of work in favour of the
WBHIDCO LTD.

4)

HIDCO 2911

5)

Tender Document

6)

N.I.T.
(NIT, Tender Document and 2911 downloaded properly and upload the same Digitally Signed). The rate will be quoted in the
B.O.Q. Quoted rate will be encrypted in the B.O.Q. under Financial Bid. In case quoting any rate in HIDCO 2911, the tender is
liable to be summarily rejected.)

7)

Special terms & conditions and specification of works.

8)

TECHNICAL DOCUMENTS

9)

•

Affidavit [Ref. Format]

•

Experience profile [Form No-IV] Section B.

•

Contractor’s Equipment [Form No-III] Section B.

Financial Proposal:a)

The rate will be quoted in the B.O.Q. Quoted rate will be encrypted in the B.O.Q. under Financial Bid. Downloaded properly
and upload digitally signed.

Seal and Signature of the Tenderer.

Additional General Manager (Engg)-IV

WB HIDCO

<!-- page 7 -->

Section - B

(b).

Non-statutory Cover Containing the following documents:

i.

Professional Tax (PT) deposit receipt challan for the financial year 2024-2025, Pan Card, IT, Saral for the Assessment year 20242025, GST Registration Certificate.

ii.

Registration Certificate under Company Act. (if any).

iii.

Registered Deed of partnership Firm / Article of Association & Memorandum.

iv.

Power of Attorney (For Partnership Firm / Private Limited Company, if any).

v.

Tax Audited Report in 3 CD form along with Balance Sheet & Profit & Loss A/c. for the last 3 (three) years (year just preceding the
current Financial Year will be considered as year – I)

vi.

List of machineries possessed by own / arranged through lease hold agreement along with authenticated copy of invoice, challan
& waybill [Ref.:- Sl. No. 5(viii) of this N.I.T. and (Section –B, Form IV)]

vii.
ix)

List of Technical staffs along with structure & organization (Section – B, Form – III).
For Registered Unemployed Engineers’ Co-operative Societies and Registered Labour Co-operative Societies having Credential
for completion of at least one similar nature of work under the authority of State / Central Government, statutory bodies under
State / Central Government constituted under the statute of the State / State Government having a magnitude of 60% (Sixty
percent) of the Estimated amount put to tender during the last 3 (three) years prior to the date of issue of this N.I.T. is to be
furnished. [Ref. Sl. No. 5(i) & 7 of this NIT and (Section – B, Form – V)]. Scanned copy of Original Credential Certificate as
stated in Sl. No. 5.(i). of N.I.T.
N.B.:

Failure of submission of any of the above mentioned documents as stated in Sl. No. A.5.(a). and Sl. No.

A.5.(b). will render the tenderer liable to be rejected for both statutory & non statutory cover.
THE ABOVE STATED NON-STATUTORY/TECHNICAL DOCUMENTS
SHOULD BE ARRANGED IN THE FOLLOWING MANNER
Click the check boxes beside the necessary documents in the My Document list and then click the tab “ Submit Non Statutory Documents’ to
send the selected documents to Non-Statutory folder.
Next Click the tab “ Click to Encrypt and upload” and then click the “Technical” Folder to upload the Technical Documents.
Sl.
No.

Category Name

Sub-Category Description

Detail(s)
GST Registration Certificate & Acknowledgement.
PAN.

A.

Certificate(s)

Certificate(s)

P Tax (Challan) (2024-25).
Latest IT Receipt.
IT-Saral for Assessment year 2024-25.

B.

Company Detail(s)

Company Detail

Credential -1
C.

Credential

Proprietorship Firm (Trade License) -Structure & Org.]
Partnership Firm (Partnership Deed, Trade License)
Ltd. Company (Incorporation Certificate, Trade License)
Society (Society Registration Copy, Trade License)
Power of Attorney, Memorandum of Association and Articles of Association of
the Company.
Similar nature of work done & completion certificate which is applicable for
eligibility in this tender as per Form –IV Section –B.

Credential -2
D

Equipment

Machineries

Tax Audited Report in 3 CD form along with Balance Sheet & Profit & Loss
A/c. for the last 3 (three) years (year just preceding the current Financial Year
will be considered as year – I)
Authenticated copy as per Form – III, Section-B.

Man Power

Technical Personnel

List of Technical Staffs with Qualifications & Experience.

Financial Info

E.
F.

Seal and Signature of the Tenderer.

Additional General Manager (Engg)-IV

WB HIDCO

<!-- page 8 -->

Section - B

Tender Evaluation Committee (TEC)
Evaluation Committee constituted by the Competent Authority of WBHIDCO LTD will function as Evaluation Committee for selection of
technically qualified contractors.
Opening & evaluation of tender:
If any contractor is exempted from payment of EMD, copy of relevant Government Order needs to be furnished.
Opening of Technical Proposal:
Technical proposals will be opened by the Concerned Tender Inviting Authority or his authorized representative electronically from the
website using their Digital Signature Certificate (DSC).
Intending tenderers may remain present if they so desire.
Cover (folder) for Statutory Documents (Ref. Sl. No. A.5.(a).) will be opened first and if found in order, cover (folder) for Non-Statutory
Documents (Ref. Sl. No. A.5.(b).) will be opened. If there is any deficiency in the Statutory Documents the tender will summarily be
rejected.
Decrypted (transformed into readable formats) documents of the non-statutory cover will be downloaded & handed over to the Tender
Evaluation Committee.
Summary list of technically qualified tenderers will be uploaded online.
Pursuant to scrutiny & decision of the Tender Evaluation Committee the summary list of eligible tenderers & the serial number of work for
which their proposal will be considered will be uploaded in the web portals.
During evaluation the committee may summon of the tenderers & seek clarification / information or additional documents or original hard
copy of any of the documents already submitted & if these are not produced within the stipulated time frame, their proposals will be liable
for rejection.
1.

Financial Proposal

The financial proposal should contain the following documents in one cover (folder) i.e. Bill of Quantities (BOQ). The contractor is to quote
the rate (Presenting Above / Below / At per) online through computer in the space marked for quoting rate in the BOQ.
Only downloaded copies of the above documents are to be uploaded virus scanned & Digitally Signed by the contractor.
Financial capacity of a bidder will be judged on the basis of information furnished in Section - B.
Penalty for suppression / distortion of facts:
If any tenderer fails to produce the original hard copies of the documents like Completion Certificates and any other documents on demand
of the Tender Evaluation Committee within a specified time frame or if any deviation is detected in the hard copies from the uploaded soft
copies, it may be treated as submission of false documents by the tenderer and action may be referred to the appropriate authority for
prosecution as per relevant IT Act.
Rejection of Bid:
Employer reserves the right to accept or reject any Bid and to cancel the Bidding processes and reject all Bids at any time prior to the award
of Contract without thereby incurring any liability to the affected Bidder or Bidders or any obligation to inform the affected Bidder or Bidders
of the ground for Employer’s action.
Award of Contract
The Bidder whose Bid has been accepted will be notified by the Tender Inviting & Accepting Authority through acceptance letter / Letter of
Acceptance.
The notification of award will constitute the formation of the Contract.
The Agreement in From No. 2911(i) will incorporate all agreements between the Tender Accepting Authority and the successful bidder. All
the tender documents including N.I.T. & B.O.Q. will be the part of the contract documents. After receipt of Letter of Acceptance, the
successful bidder shall have to submit requisite copies of contract documents downloading from the website stated in Sl. No. 1 of N.I.T.
along with requisite cost through Demand Draft / Pay Order issued from any nationalised bank in favour of the WB HIDCO LTD within time
limit to be set in the letter of acceptance.

Seal and Signature of the Tenderer.

Additional General Manager (Engg)-IV

WB HIDCO

<!-- page 9 -->

Section - B

SECTION – B

FORM – I
PRE-QUALIFICATION APPLICATION
To
Additional Geneal Manager (Engg)-IV, WB HIDCO
HIDCO BHABAN,
4th FLOOR, NEW TOWN,
KOLKATA.

Ref

:

Tender for
(Name of work)

e-N.I.T. No.: HIDCO/AGM(E)IV/RP/NIT19/26-27
Dear Sir,
Having examined the Statutory, Non-statutory & N.I.T. documents, I /we hereby submit all the necessary information and relevant
documents for evaluation.
The application is made by me / us on behalf of

in the capacity
duly authorized to submit the order.

The necessary evidence admissible by law in respect of authority assigned to us on behalf of the group of firms for Application and for
completion of the contract documents is attached herewith.
We are interested in bidding for the work(s) given in Enclosure to this letter.
We understand that:
1)

Tender Inviting & Accepting Authority / Engineer-in-Charge can amend the scope & value of the contract bid under this project.

2)

Tender Inviting & Accepting Authority / Engineer-in-Charge reserve the right to reject any application without assigning any reason.

Enclosure(s): e-Filling:1)

Statutory Documents.

2)

Non Statutory Documents.

Date:

Seal and Signature of the Tenderer.

Additional General Manager (Engg)-IV

WB HIDCO

<!-- page 10 -->

Section - B

SECTION – B

AFFIDAVIT – “Y”
(To be furnished in Non – Judicial Stamp paper
of Rs.100.00 (One Hundred only) duly notarized)

1)

I, the under-signed do certify that all the statements made in the attached documents are true and correct. In case of any
information submitted proved to be false or concealed, the application may be rejected and no objection/claim will be raised by the
under-signed.

2)

The under-signed also hereby certifies that neither our firm M/S

nor any of

constituent partner had been debarred to participate in any tender by any Govt. Organization / Undertaking during the last 5 (five)
years prior to the date of this N.I.T.
3)

The under-signed would authorize and request any Bank, person, Firm or Corporation to furnish pertinent information as deemed
necessary and/or as requested by the Department to verify this statement.

4)

The under-signed understands that further qualifying information may be requested and agrees to furnish any such information at
the request of the Department.

5)

Certified that I have applied in the tender in the capacity of individual/ as a partner of a firm and I have not applied severally for the
same job.

Signed by an authorized officer of the firm.
Title of the officer

Name of the Firm with Seal
Date:

Seal and Signature of the Tenderer.

Additional General Manager (Engg)-IV

WB HIDCO

<!-- page 11 -->

Section - B

SECTION – B
FORM – II
STRUCTURE AND ORGANISATION

1)

Name of Applicant

:

2)

Office Address

:

Telephone No.

:

Fax No.

:

3)

Name and Address of Bankers

:

4)

Attach an organization chart showing the
structure of the company with names of
Key personnel and technical staff with Biodata.

:

Note:

Application covers Proprietary Firm, Partnership, Limited Company or Corporation.

Signature of applicant including title
and capacity in which application is made.

Seal and Signature of the Tenderer.

Additional General Manager (Engg)-IV

WB HIDCO

<!-- page 12 -->

Section - B

SECTION – B
FORM – II
FINANCIAL STATEMENT

B. 1. Name of Applicant:B. 2. Summary of Annual Turnover on the basis of the audited financial statement
of the last three financial years.

(Attach copies of the audited financial

statement of the last three financial years)

Year 2021-2022

Year 2022-2023

Year 2023-2024

(Rs. In Lakh)

(Rs. In Lakh)

(Rs. In Lakh)

a)Annual Turnover

b)Average Turnover

Certified and Signed by the
Chartered Accountant of the firm

Sign by :-

Membership No. :- ………………………………………..

Name of the Officer …………………………….

Name of the Firm with Seal

Seal and Signature of the Tenderer.

Additional General Manager (Engg)-IV

WB HIDCO

<!-- page 13 -->

Section - B

SECTION – B
FORM – III
Contractor’s Equipment
Name of the Applicant:
Whereas it is entirely the responsibility of the Contractor to deploy sufficient plant and mechanical equipment to ensure compliance with his
obligations under the Contract, the following list is an indicative list of the minimum essential basic holding of plant and mechanical
equipment which the Contractor must own or arrange through lease hold registered agreement. The contractor must furnish the documents
in support of ownership or lease hold registered agreement.

Sl. No.

TYPE OF EQUIPMENT

CAPACITY

SUPPORTING
DOCUMENTS

1

Signature of applicant including title
and capacity in which application is made.

Seal and Signature of the Tenderer.

Additional General Manager (Engg)-IV

WB HIDCO

<!-- page 14 -->

Section - D

SECTION – B
FORM – IV
Experience Profile
Name of the Firm:

Name of
Employer

Name,
Location &
nature of
work

Name of Consulting
Engineer responsible
for supervision

Contract
price in
Indian Rs.

Percentage of
Participation of
company

Original
Date of start
of work

Original Date of
completion of
work

Actual Date
of starting
the work

Actual Date of
completion of
work

Reasons for
delay in
completion
(if any)

Note:
1)

Certificate from the Employers to be attached

2)

Non-disclosure of any information in the Schedule will result in disqualification of the firm

Signature of applicant including title
and capacity in which application is made.

Seal and Signature of the Tenderer.

Additional General Manager (Engg)-IV

WB HIDCO
