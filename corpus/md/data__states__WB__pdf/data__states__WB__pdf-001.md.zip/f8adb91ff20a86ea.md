---
doc_id: "f8adb91ff20a86ea"
source_url: "https://www.wbhidcoltd.com/assets/frontend/pdf/guideline_ews.pdf"
ministry: "West Bengal Housing Infrastructure Development Corporation Limited, (WBHIDCO), West Bengal"
title: "Guideline"
date: ""
pages: 43
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9ba92b40b8ef0369"
---

<!-- page 1 -->

Welcome to Online Application of HIDCO
Home Page

<!-- page 2 -->

Home Page

Click here for
User
Registration

Anyone who does not have valid
email id their mail id will be
"mobile_no@ews.com

<!-- page 3 -->

Check Live Scheme

Click here to
check
Documents

Click here to
Apply for any
Scheme

Click here to
check scheme
details

<!-- page 4 -->

View Scheme Details 1

<!-- page 5 -->

View Scheme Details 1.1

<!-- page 6 -->

Download Document

<!-- page 7 -->

User Registration - Step 1

Note for Registration:

Applicants are requested to use their email id for user registration on website. In case
of not having email id, applicants can use email id in format i.e. “Mobile
Number@ews.com” (example : 7818083391@ews.com)

<!-- page 8 -->

User Registration -1.1

<!-- page 9 -->

Verify OTP Send to Registered Mobile Number and Email id

<!-- page 10 -->

Applicants Profile – Step 2

<!-- page 11 -->

Applicants Profile – Step 2.1

<!-- page 12 -->

Upload Supporting Documents

Allows max 20 MB
size Only

<!-- page 13 -->

Complete User Registration

Allows max 20 MB
size Only

Click here to
complete user
registration

<!-- page 14 -->

Login

Click here to login

<!-- page 15 -->

Enter Registered User Id and Password

Note for Forgot Password:
Applicants have to send SMS from their registered mobile number to “6354910186”
(Support Team) to reset password.
Sample SMS Text from the Registered Mobile Number :
I have forgot my password, Kindly reset Password for the email id “”mobile no@ews.com”

<!-- page 16 -->

After Login Screen for Applicant

Click here to check my
profile and edit
profile

<!-- page 17 -->

Check Scheme Details – Documents and Apply

Check
Details
Check
Documents
Click here to
Apply

<!-- page 18 -->

View Scheme Notice

<!-- page 19 -->

View Scheme Notice 1.1

<!-- page 20 -->

View and Download Scheme related document

Click here to
download
Documents

<!-- page 21 -->

Apply for any Scheme – Step 1

Select and Click
Submit

<!-- page 22 -->

Apply for any Scheme – Step 1.1

Indicator/Suggestion
Steps to Complete
the Application
Process

<!-- page 23 -->

Applicant Profile 1

<!-- page 24 -->

Applicant Profile 1.1

On selection of “Yes” system will replicate the Same form
for Applicant to Fill the details of Co-Applicant

Click Submit

<!-- page 25 -->

Application Profile Completed

First Step Removed
by system from
suggestion box

<!-- page 26 -->

Select Scheme and Select Category

<!-- page 27 -->

Upload Document

Browse Document
and Upload

<!-- page 28 -->

Select Document

<!-- page 29 -->

Document uploaded Successfully

<!-- page 30 -->

Make Online Payment

Select Category

Click Pay

<!-- page 31 -->

Select Payment Options

<!-- page 32 -->

Select Payment Options Cards or Net Banking

Select Card Options
and Click Pay Now

<!-- page 33 -->

Payment Through Cards

<!-- page 34 -->

Payment Through Net Banking

Select Net Banking
Options select Bank
& Click Pay Now

<!-- page 35 -->

Payment Through Net Banking

Enter Your Net
Banking ID & Pwd

<!-- page 36 -->

Payment Through Net Banking

<!-- page 37 -->

Payment Transaction History

User can download
Payment Receipt
from Download
Option

<!-- page 38 -->

Payment Receipt

<!-- page 39 -->

Final Submission

Click on Final
Submission to
Complete the
Application

Note: Pls verify the
application before
Final Submission

<!-- page 40 -->

Final Submission

Pls read the
declaration & Click
on I Agree for Final
Submission

Click on Final
Submission

<!-- page 41 -->

Final Submission

Pls read the
declaration & Click
on I Agree for Final
Submission

Click on Final
Submission

<!-- page 42 -->

Final Submission

After Successful Final
Submission User will get
Application No. along with
Application Submission Date
& Time and IP Address

<!-- page 43 -->

Thank You
