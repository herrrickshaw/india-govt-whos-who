---
doc_id: "7b8bae07ef092bbd"
source_url: "https://www.wbcsconline.in/UploadDocument/Notice/730/1.NOTIFICATION.pdf"
ministry: "West Bengal College Service Commission, West Bengal"
title: "Download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "84bb82e7bec326fb"
---

<!-- page 1 -->

THE WEST BENGAL COLLEGE SERVICE COMMISSION
INTERVIEW FOR THE POST OF PRINCIPAL IN STATE-AIDED GENERAL DEGREE
COLLEGES IN WEST BENGAL (ADVT. NO. 2/2024)

NOTICE
The West Bengal College Service Commission will conduct the Interview on 7TH, 8TH, 9TH , 16TH, 21ST, 22ND ,
23RD , 28TH, 29TH, and 30th August 2025 for selection & recommendation to the post of Principal in different
State-aided General Degree Colleges of West Bengal as per the schedule available in the websites
www.wbcsconline.in and www.wbcsc.org.in. Candidates are hereby requested to follow the above
mentioned websites for the interview schedule.
Candidates are further requested to follow the INSTRUCTIONS (available in the websites) carefully before
appearing in the Interview.

Date: 23-07-2025

By Order
Secretary
