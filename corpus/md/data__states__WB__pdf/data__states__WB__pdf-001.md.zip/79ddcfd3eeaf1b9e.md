---
doc_id: "79ddcfd3eeaf1b9e"
source_url: "https://gcect.ac.in/download/Tenders/GCECT-Notice-Inviting-Tender(NIT)-regarding-Canteen-01072026.pdf"
ministry: "Government College of Engineering & Ceramic Technology (GCE&CT), Kolkata, West Bengal"
title: "View"
date: ""
pages: 7
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "11461cbb67f4e84c"
---

<!-- page 1 -->

|
[০]
মল বহর
GOVERNMENT OF WEST BENGAL
GOVERNMENT COLLEGE OF ENGINEERING & CERAMIC
TECHNOLOGY
An Autonomous Institute under M.A.K.A.U.T.
73, Abinash Chandra Banerjee Lane, Kolkata — 700010
URL: www.gcect.ac.in | E-mail: gcectwb@gmail.com
এটা
NOTICE INVITING TENDER (NIT) ৫৮২৬৯
2)
(Single-Bid / Single-Envelope System) ১ [/ oe 22
ati 7
For Operation of the College Canteen 3\ (৩৮০ LEIS
Tender / NIT No.: GCECT/CAN-I/ 252 /2026-27 Date of Issue: 01.07.2026 og |
Estimated Tenure of Contract: 1 (one) year, extendable Mode: In one sealed envelope
Sealed quotations are invited by the undersigned, on behalf of the Government College of Engineering & Ceramic
Technology, Kolkata (an Autonomous Institute under M.A.K.A.U.T.), from recognized, experienced and eligible
vendors/firms for the operation and running of the College Canteen on a contractual basis, strictly on the terms and
conditions set out below and in conformity with applicable Government of West Bengal financial and procurement
norms.
Bidders shall submit their Eligibility Documents (credentials) and Financial Bid (rate quotation as per
Proforma-1 and Proforma-2) together in ONE sealed envelope, superscribed “Quotation for Operation of
College Canteen - GCECT”, addressed to the Principal.
1.. Eligibility Criteria for Bidders

1. The bidder must be an individual/ proprietorship/ partnership firm or registered entity engaged in the
food/catering business, holding a valid Trade Licence and Food Licence (23541) as on the date of tender
submission.

2. The bidder must have এ minimum of 3 (three) years' documented experience in operating a canteen/catering
service in an academic institution, research institution, Government office, PSU or similar establishment of
comparable scale.

3. The bidder must not have been blacklisted or debarred by any Government department, autonomous body, PSU
or educational institution and must submit a self-declaration to this effect (Annexure-B).

4. The bidder must possess a valid PAN and, where applicable, GST registration; sole proprietors must additionally
submit their Aadhaar card.

5. The bidder must have filed Income Tax Returns for the last 3 (three) financial years

The College reserves the right to verify all credentials submitted and to reject any bid that is found to be false,
incomplete, or unsupported by documentary evidence.

2. Mode of Evaluation

Bids meeting the eligibility criteria at Clause 2 and found technically responsive (i.e., complete in all respects with all
requisite documents and EMD) shall be evaluated on a combined basis, giving due weightage to:

1. Lowest quoted rates against the ceiling rates prescribed in Proforma-| and Proforma-2;

2. Quality, freshness and variety of food items proposed, including tea and snacks, as assessed through
sampling/tasting where the Tender Evaluation Committee deems necessary;

3. Experience in operating canteen services in academic institutions, Government offices, or similar establishments.
The decision of the Tender Evaluation Committee constituted by the College Authority shall be final and binding.
4. Scope of Work

+ Space for operation of the canteen shall be provided free of cost by the College.

+ The canteen shall function from 9:00 a.m. to 6:00 p.m. on all working days and shall not remain closed during

operational hours without prior written permission of the College Authority.

+ The canteen shall cater to students, faculty members, officers, staff members and guests of the College.

+ All food items approved by the College Authority and included in the notified menu shall be made available

throughout operational hours, subject to reasonable demand.

<!-- page 2 -->

+ No new food item, or change in the notified menu/rates, shall be introduced without prior written approval of the
College Authority,

+ The canteen premises — kitchen, dining area, utensils and equipment — shall at all times be maintained in a neat,

clean and sanitary condition, in compliance with applicable food safety standards.

+ Serving stale, spoiled, contaminated or unfit food shall be treated as a serious breach of contract and may result

in penal action, including termination and forfeiture of the Security Deposit.

+ Drinking water shall be supplied only {rom the College's approved water-purification system, served in clean,

transparent containers maintained in hygienic condition.

+ Refreshments required for official meetings, examinations, seminars, conference, academic activities and

students’ welfare programmes shall be supplied by the College Canteen strictly at the approved/quoted rates.

+ The vendor shall employ adequately trained staff, maintain personal hygiene standards, and ensure sta (f undergo

periodic medical fitness/health check-ups as may be required by the College Authority.

+ The canteen operator shall deliver the required food items to the college staff within the college building whenever

required.
5. Utilities and Infrastructure
The College shall provide electricity, solely for the operation of the refrigerator, lights, fans and mixer-grinder. The
use of electric heaters, immersion rods or any other heating, appliances shall be strictly prohibited. The vendor shall
bear the entire cost of LPG/cooking gas and of any additional equipment or electrical appliances not permitted by the
College.
6. Commencement of Service
The selected vendor shall commence canteen operations within 7 (seven) days from the date of issue of the Work Order,
failing which the offer of award may be withdrawn and the EMD forfeited.
7. Documents to be Submitted with the Bid
Self-attested photocopies of the following documents must be enclosed along with the sealed bid, in addition to the
original Demand Drafts for Tender Fee and EMD:

eb 1)

No ocument Enclosed (Yes/No).
Food (FSSAD Licence (valid, current) mo |
PAN Card of the proprietor / firm [
‘Aadhaar Card of the proprietor(s) Met |
GST Registration Certificate, if applicable |]

6 Income Tax Returns for the last 3 (three) financial years 855. eS]
7 Proof of experience / work orders / completion certificates from previous institutions
(min. 3 years)
| 3 | Demand Draft towards Tender Fee (if downloaded copy is used) | Pee |
Demand Draft towards Earnest Money Deposit (EMD) |]
| 10 | Duly filled and signed Proforma-| and Proforma-2 (rate quotation) [ere |
[ou | Self-declaration of non-blacklisting (Annexure-B) |]
Signed acceptance of Terms & Conditions (Annexure-A) [|
8. Financial Bid — List of Food Items and Rates
As this is a single-bid tender, the rate quotation forms an integral part of the same sealed envelope submitted by the
bidder. Bidders shall quote rates strictly at or below the ceiling rate indicated against each item. Quotations above the
ceiling rate for any compulsory item shall render the bid liable to rejection.
G, & Cera
79৮৮৯

ma

০1: ৬১০০

afd (weer) 2) 3

Sls A 78/5

৬৩৭ ৬ LS

১২ রড,
০5 *

<!-- page 3 -->

PROFORMA = 1: Compulsory Regular Items
a sh Name st litem Ceiling a ARS) Not more Poy (ate nice
i by bidder) |
1 | Tea~ Small Cup (Paper/Earthen/Ceramic) 65 ml | 500] 1
2:1750-178 Cup (Paper/Larthen/Ceramic) 100 ml so |_|
0
Sandwich (2 pes)- Vey/Egg/Chicken [20000004000 | |
6 | Egg Toast, 2 pes (with quarter-pound bread) ee ee
7-841755/55-2-৫৯৮প৯৮7৮-57717৮777
মধ এ০৮৮//৮5৮/০০০০০৫৭) demo
9 Pintiwincumapstanidsiy
781074০৮৮০৮৮2০০০৭577৮6717
[1 79০০৮৮৮৭৮০৮৪৭৮/০১৮৭77৮৮77-7
[a [Mitr Soo Kahu wih পো নেসএন__7৮1
Pa fome
তো YOO
Fir 051৮1৩০17০০ Sis
a
Fy frownatege SSS
Far [aise
a 77
7৮-০7-9158
৯9৮ 777 দত
efoto
a
ছাট 1 fi
ছাট 0” dC
FhikenGnvenin=RigPe/Smalrae SY sanoco
2
=e aT] te |
29 | Chutney, Papad — Miniket / Banskati rice only; no extra charge for
additional rice)
[০০5 পনললনত 70557
Far | rancor, nein ge aia Retw7GaPowy [som
ae [oer th per roig teal rr erer 78৮45557
০৮০০০০০৬৮০০০-২৮০/৭৮৫৪/এ৭57৮1৮৮77
(881৩৬ 7775757
fs [ooo (nines) sa
Keventer, Mother Dairy, or other equivalent brands of similar quality. ১ ২৩ aa J

<!-- page 4 -->

PROFORMA —2: Items on Demand / Instruction
দাদি 07172178105) Not | Quoted Rate (Rs. (to
No. না eta More than be filled by bidder)
1 | Nan/Naan Puri with Curry, 2 pes (big size) 25.00
4 | Chicken Biryani with potato 100g Chicken) 100.00 |]
Egg Devil (Standard size) 12.00 |
[৮1০৮০০০৫৮77
Chicken Chop (Standard size) 15.00 |
| 14 | Chilli Chicken, with bone (5 pes) 60.00 |]
[19 _| Mixed Fried Rice (big plate) 100.00 fs
Veg Fried Rice (big plate) 80.00 |
‘Tandoori Roti — Plain / Butter (1 pe) 15.00 / 20.00 samy
নি ved
Stuffed Kulcha 15.00 /20.00 | LG BBRO
> ONO
Mutton Biryani with potato (100g Mutton) 220.00 ee fe AP
51516)
26. | Khichuri (Standard Plate) with potato/ carrot /beans/ Pano oN 5 nd
- | Coli flower (Seasonal) : 222
Golapjam/Rajbhog/Jolbhora (Standard Size) 15.00 ২799,
Note: Rates for items not listed above, or for special/seasonal items, shall be mutually decided with prior written
approval of the College Authority. GST, if applicable, shall be included within the quoted rate and shall not be charged
separately from students/staff unless expressly permitted.
9. Language of Tender
The bid shall be submitted in English or Bengali, on the prescribed proforma, duly signed by the bidder or authorised
signatory on every page.
10. Security Deposit
1. The successful bidder shall deposit a sum of Rs. 15,000/- (Rupees Fifteen Thousand only) as interest-free Security
Deposit, by Demand Draft in favour of “Principal, Government College of Engineering & Ceramic Technology”,
payable at Kolkata, before/at the time of issue of the Work Order.
2. The Security Deposit shall be refunded on satisfactory completion/termination of the contract, subject to
adjustment against any dues, damages, or losses caused to College property.
3. The Security Deposit is liable to forfeiture, in whole or in part, in the event of breach of any terms and conditions
of this tender or the resultant agreement.
11. Issue, Submission and Opening of Tender
1. Tender documents are also downloadable free of cost from the College website www.gcect.ac.in.
2. Sealed bids must be submitted. by hand or by post, so as to reach the office of the undersigned not later than 3:00
p.m. on 14.07.2026. Bids received after the stipulated date and time shall not be entertained.
3. Technical & Financial bids (single sealed envelope) shall be opened on 15.07.2026 at 1:00 p-m., in the presence
of bidders or their authorised representatives who may choose to be present.

<!-- page 5 -->

12. Right of Acceptance / Rejection

The undersigned reserves the right to accept or reject any or all bids, in part or in full, and to cancel the tender process
al any stage, without assigning any reason whatsoever, and without any liability towards the bidders whatsoever.

13. Contract Period, Validity and Termination

1. The bid shall remain valid for acceptance for a period of 90 (ninety) days from the date of opening of the tender.

2. The contract shall be initially for a period of I (one) year from the date of commencement of service, extendable
for a further period on a year-to-year basis, for a maximum of 3(three) years in total, on mutual consent and
subject to satisfactory performance, at the sole discretion of the College Authority and without a fresh tender
process, provided rates/terms are mutually reviewed.

3. In case of unsatisfactory food quality, hygiene lapses, or repeated/substantiated complaints, the College Authority
reserves the right to terminate the contract by giving 2 (two) months' written notice, or with immediate effect in
case of a serious/repeated violation, without any compensation to the vendor.

4. The vendor may likewise withdraw services by giving 2 (two) months’ prior written notice to the College
Authority.

5. The contract is personal to the vendor and shall not be assigned, sublet, or transferred to any other party under
any circumstances,

14. Statutory Compliance and General Conditions

+ The vendor shall comply with all applicable laws, including the Food Safety and Standards Act, 2006, Shops and
Establishments Act, labour laws (minimum wages, PF/ESI where applicable), and any other statute governing
the operation of a food business.

+ Use of any type of plastic (single-use plastic, plastic carry bags, plastic cutlery, etc.) is strictly prohibited within
the Institute premises, in line with applicable plastic-waste rules.

* The possession, storage, sale, distribution or consumption of tobacco products, alcohol, gutkha, or any other
prohibited or harmful substance within the Institute premises is strictly prohibited. Any violation of this condition
shall be viewed seriously and may invite appropriate legal and disciplinary action in accordance with the
applicable laws and regulations.

+ All garbage and canteen waste shall be removed daily and disposed of outside the College campus in a proper,
hygienic and environmentally responsible manner, at the vendor's own cost.

+ The vendor shall be solely responsible for the conduct, discipline and verification (police/character) of canteen
staff engaged by them.

+ The vendor shall maintain adequate fire-safety and first-aid arrangements in the canteen area and shall be liable
for any accident, loss, or damage arising from negligence in operations.

+ The College shall not be liable for any loss, theft, or damage to the vendor's equipment, stock, or belongings kept
within the canteen premises.

+ The vendor shall indemnify the College against any claim, loss, or liability arising out of food poisoning,
adulteration, or any act/omission of the vendor or its staff.

+ Interested vendors may visit and inspect the site at their own discretion, prior to submission of the bid; no claim
on this account shall be entertained subsequently.

15. Dispute Resolution and Jurisdiction
Any dispute or difference arising out of or in connection with this tender/contract shall, in the first instance, be resolved
through mutual discussion between the vendor and the College Authority. Failing amicable settlement, the matter shall
be referred to arbitration in accordance with the Arbitration and Conciliation Act, 1996 (as amended), the seat of
arbitration being Kolkata. Subject to the above, the Courts at Kolkata alone shall have jurisdiction over all matters
arising out of this tender/contract.
16. Force Majeure
Neither party shall be held responsible for any delay or failure in performance of its obligations to the extent such
delay or failure is caused by circumstances beyond its reasonable control, including but not limited to natural
calamity, fire, riot, war, government order, or pandemic-related restriction, provided timely written notice is given to
the other party.
17. Amendment of Tender Terms
The College Authority reserves the right to amend, modify, or clarify any term or condition of this tender at any time
prior to the deadline for submission of bids, by way of a corrigendum published on the College website and/or notice
board, which sha) anyategral part of this tender document.
wile Soe \2\2 K .chokd
COS a rincipa
Copy to: ২ Principe neering
1. College Notice Board ০০৫-591225 Technology
2. College Website (www.gcect.ac.in) Kolkata-700010 \
Govt. of West Beng
Principal's Office: 033-2370-1264 | Registrar's Office: 033-2363-2072 | Accounts Section: 033-2363-3674 \ FAX: 033-2363-2072

<!-- page 6 -->

. Gey
(1
০75
লুজ
GOVERNMENT OF WEST BENGAL
GOVERNMENT COLLEGE OF ENGINEERING & CERAMIC
TECHNOLOGY
An Autonomous Institute under M.A.K.A.U.T.
73, Abinash Chandra Banerjee Lane, Kolkata — 700010
URL: www.gcect.ac.in | E-mail: gcectwb@gmail.com
৯৯৯৮৯১১১৮৪৯
ANNEXURE-A
Undertaking / Acceptance of Terms & Conditions
I/We, the undersigned, having carefully read and understood the Notice Inviting Tender and all Terms
& Conditions for operation of the College Canteen at Government College of Engineering & Ceramic
Technology, Kolkata, hereby unconditionally accept and agree to abide by all the said terms and |
conditions in their entirety, and undertake to operate the canteen strictly in accordance therewith, without
any deviation.

I/We further undertake that the rates quoted in Proforma-1 and Proforma-2 shall remain firm and
binding throughout the tenure of the contract, unless revised with the prior written approval of the
College Authority.
mN
Place:

Date:
Signature of Bidder with Seal
58157
টি টু
Cj ol
505. Ese 83
১৩৫৮
ORIEL
2 HOD

<!-- page 7 -->

They
|]
[0]
ফর কন
GOVERNMENT OF WEST BENGAL
GOVERNMENT COLLEGE OF ENGINEERING & CERAMIC
TECHNOLOGY
An Autonomous Institute under M.A.K.A.U.T.
73, Abinash Chandra Banerjee Lane, Kolkata — 700010
URL: www.gcect.ac.in | E-mail: gcectwb@gmail.com
ANNEXURE - B
Self-Declaration (Non-Blacklisting / No Conflict of Interest)
I/We, ১ proprietor/authorised signatory of
ce, do hereby solemnly
declare that:

1. My/Our firm has not been blacklisted, debarred, or declared ineligible by any Government
department, autonomous body, PSU, or educational institution in India as on the date of this
declaration.

2. No criminal case / FIR relating to food adulteration, cheating, or fraud is pending against me/us or
my/our firm.

3. I/We hereby declare that I/We have no relative or close associate employed by the College or by
any agency engaged by the College who is involved in the tender evaluation or award process, nor
do I/We have any relationship that could give rise to a conflict of interest.

4. All information and documents furnished by me/us along with this bid are true and correct to the
best of my/our knowledge; in case any information is found false at any stage, my/our bid/contract
is liable to be cancelled and the EMD/Security Deposit forfeited, besides any other legal action.

Place:
Date:
<amic Te Signature of Bidder with Seal
Ce রহ
০/২১৬
of ৯৪২ টু
28 88)2)
৬৩১৬১ LF
OD SY
OTIS
৪০১7৩
