---
doc_id: "0327caca0baacd30"
source_url: "http://csp.res.in//docs/notices/ten/Tender_Civil_birbhum.pdf"
ministry: "Indian Centre for Space Physics, Kolkata"
title: "Download/view"
date: ""
pages: 4
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "a546175442f72945"
---

<!-- page 1 -->

রিকি সর্ট নিউ লক নলম্ল মর সী রন লিলি সালললসল নালা কু এসিসিররররিসরা সারা ্যারালানিস্াসরাপ্পানাদ
( |] Indian Centre for Space Physics
(- oF, [Autonomous Institute registered under Section 25, The Company Act 1956]
\ রা 1 466, Barakhola, Netai Nagar, Kolkata — 700 099, West Bengal
YL) Webpage - http://csp.res.in, Email _ root@csp.res.in
rege ee peecsp.res.in, Email—root@csp.res.in
NOTICE INVITING TENDER
ENS TP ENNVERNN
: Tender Ref. No.: ICSP/ SBFICSP/Main Building/2024-2025/01 Dated: 27/12/2024
Sealed tenders are invited from bona fide contractors with credential
for construction of proposed two storied educational building,
boundary wall, strong room, plumbing and electrification work
(Complete work on a Turnkey basis) of Stratospheric Balloon Facility
of Indian Center For Space Physics at P.S. Rajnagar, mouza-
Chandrapur, J.L.No -90, District:- Birbhum.
02
Oe

<!-- page 2 -->

a a a করা রন কি কন ীরাসরারনর সরু সনাযাল বস সং রসারসরগনাপারলাল
Terms and Condition:

a. All potential bidders should visit the plot before submitting the bid. No queries after
the submission will be entertained.

. 2. A Hardcopy will be posted at the security room of ICSP head quarter (address given in
letter head). Anybody requiring hardcopy of the tender document must collect from
the head quarter of ICSP. Contact 9163409293 if necessary. For tender related queries
contact 9874874672

3: The construction must be certified by qualified LBS and ESE

4. All cements related work must be done with Ultratech / ACC / equivalents

5. The bidder is solely responsible for the security of all building materials inside the
construction area.

6. The lowest bidder will be interview by our expert committee when the original
credential have to be produce any minor changes of the construction related
activities, scheduling etc have to be done during this meeting.

re Allclarification have to be made before the work order issued

8. The completed structure has to be handed over to ICSP within 8 months of receiving
the Work Order.

9 The money can be paid only in two instalments during the period of work order issue
and the completion of the work.

10. Any accidents (including injuries, disease etc.) taking place during construction
activity are to be taken care of by the bidder.

11. —Alldisputes are to be settled through discussion.

12. The entire schedule of work must be submitted including the timeline.

13. The cost of electricity must be borne by the bidder.

14. The authority of ICSP can and will inspect the progress of the work at any time of its
choice.

15. An Affidavit has to be signed prior to receiving the work order. The bidder is bound to
complete the work once the advance is accepted. If the job is left incomplete or not as

per the tender document, the bidder is liable to return the full advance amount
independent of the progress of the work.

16. | The combined turnover of past two financial years (22-23 and 23-24) must not be less
than 1.5 Crore.

. 17. The bidder must employ unskilled labour only if they have MGNREGA job card.
/
০০৮
Vg
/

<!-- page 3 -->

ee ee
SCHEDULE OF TENDERING:
. Date of uploading of N.I.T. & other Documents
(online) (Publishing Date)
4. Documents download end date (Online) & Bid | 13/01/2025 up to 17:00 IST
Submission Last Date & Time at Indian Centre
for Space Physics, 466 Borakhola, Netai Nagar,
Kolkata 700084
Documents to be Submitted Bidder should submit the
scanned copies in the electronic
. format at proper place of the
following documents:-
i) Valid Trade License
of the Company
ii) PAN CARD
iii) Valid
Acknowledgement of
IT returns (For last 3
years)
iv) PT Certificate for
Last three years
v) Valid document for
GST registration and
up to date copy of
return submission
vi) The credential /
completion
. certificate of similar
nature of work
ye
F ৮৫
# Z

<!-- page 4 -->

ডি... ক কিক কি টি সি ইসির নি রর রর ee
as Annexure |
FURNISHING BASIC INFORMATION
(To be furnished in the company’s official letter pad)
a স্টীল
:
Communication
[3 [contactNumberfs) |
4 [Emi 7
. Trade License No.
(Please enclose copy of
Trade License)
1৮৮০ ০প______
of PAN card)
7. | GST No.(Please enclose
[sac পপ
Do you have previous
experience for supplying
similar nature of items
(Please enclose copy of
purchase order & user list,
if yes)
Annual Turnover as per | 2021-22: RS....-ssssseseesestessseeseeneneetene
Audited P/L ACCOUNTS & | 2022-23: 95...
BALANCE SHEET 2023-24: 35...
Average Annual TUrnover: RS...... sss resets
10. | Status of the bidder(Please Manufacturer/Dealer/Distributer/Selling Agent/ contractor
. enclose copy | (Please put tick mark)
authenticating your status)
| hereby declare that the above information is true and correct to the best of my knowledge
and belief. In case of any false/wrong/misleading information, | shall be bound to take the
| decision taken by the Tender Inviting Authority.
Signature of the Bidder
| (With Seal)
