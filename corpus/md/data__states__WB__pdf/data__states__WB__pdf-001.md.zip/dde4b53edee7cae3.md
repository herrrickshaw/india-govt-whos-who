---
doc_id: "dde4b53edee7cae3"
source_url: "https://www.wbsschelpdesk.com/info/downloads/rulesAT/rules-upper.pdf"
ministry: "West Bengal Central School Service Commission, West Bengal"
title: "Upper Primary Level"
date: ""
pages: 15
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "51a21caaf3908f56"
---

<!-- page 1 -->

Registered No. WB/SC-247 No. WB(Part-1)/2016/SAR-368
SENT
1]
olkata MK asette
Extraordinary
Published by Authority
-- লা লু .- -ল ঁ
BHADRA29] TUESDAY, SEPTEMBER 20, 2016 [SAKA 1938
rr 884১১83৯881 14151571177
PART I—Orders and Notifications by the Governor of West Bengal, the High Court, Government Treasury, etc.
GOVERNMENT OF WEST BENGAL
School Education Department
(Secondary Branch)
Bikash Bhawan, Salt Lake, Kolkata 700091
No. 1104-SE/S/1S-26/2010 (Pt.-III) Dated the 20th September, 2016.
NOTIFICATION
In exercise of the power conferred by sub-section (1) of section 17, read with section 8 and clause (d) of sub-
section (2) section 17, of the West Bengal School Service Commission Act, 1997 (West Ben. Act IV of 1997), and in
supersession of the West Bengal School Service Commission (Selection of Persons for Appointment to the Posts of
Teachers in Upper Primary Level) Rules, 2015, issued with this Department notification No.485-SE(S)/1S-26/2010
(Part I), dated the 3rd June, 2015, published in the Kolkata Gazette, Extraordinary, Part I, dated the 3rd June, 201 5, the
Governor is pleased hereby to make the following rules regulating the manner and scope of selection of persons for
appointment to the posts of Teachers for Upper Primary Level of Schools:—
Rules
1. Short title and commencement. — (1) These rules may be called the West Bengal School Service Commission
(Selection for Appointment to the Posts of Teachers for Upper Primary Level of Schools) Rules, 2016.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. Definitions.— (1) In these rules, unless the context otherwise requires,-—
(a) “Act” means the West Bengal School Service Commission Act, 1997 (West Ben. Act IV of 1997);
(b) “Category” means Subject Category, medium of instruction category, reservation category, and gender
category in each subject group or in Physical Education or Work Education as the case may be;
(c) “concerned subject”, in relation to a post, means a subject against which a vacancy has been reported
for the purpose of selection of a person to the post:
Provided that the Central Commission shall determine equivalence of any subject with the approval of
the State Government as per clause (e) of sub-section (2) of section 17 of the Act;
(৫) “Degree or Diploma” means Graduation or Post-Graduation froma University recognised by the University
Grants Commission, or a professional qualification duly recognised by the National Council for Teacher
Education (NCTE), as the case may be;

<!-- page 2 -->

2 THE KOLKATA GAZETTE, EXTRAORDINARY, SEPTEMBER 20, 2016 [যা
_ লু ললললললললললললল্ললললললল
(e) “interview list”, in respect of SLST, means—

(i) incase of vacancies other than Physical Education/Work Education vacancies, a list of candidates
to be called for personality test category-wise on the basis of merit (weightage of TET, academic
and professional qualification) in the ratio of 1:1.4 of final vacancies;

(ii) in case of Physical Education/Work Education vacancies, a list of candidates to be called for
personality test category-wise on the basis of merit (marks in written test, academic and professional
qualification) in the ratio of 1:1.4 of final vacancies;

(f) “merit list”, in respect of SLST, means—

() 10. case of posts other than Physical Education and Work Education, a list of candidates prepared
category-wise on the basis of merit (weightage of TET, academic and professional qualification
and marks obtained in personality test) from Interview List;

(ii) in case of posts of Physical Education and Work Education, a list of candidates prepared category-
wise on the basis of merit (marks of written test, academic and professional qualification and
marks obtained in personality test) from Interview List;

(g) “Panel” means a list of candidates (category-wise) of the merit list equal to the number of final vacancies
and includes a panel (region-wise) on the basis of the option exercised by the candidates;

(h) “waiting list” means a list of candidates from the merit list (category-wise) but not included in the panel;

(i) “Post” means a whole-time post of Teacher for Upper Primary Level of Schools against declared and
sanctioned vacancy in respect of any of the following subjects:—

(0) Mathematics and Science group (Biological Science and Pure Science);

(ii) Social Studies Group (History and Geography);

(iii) Language Group (Bengali, English, Urdu, Arabic, Nepali, Santhali, Oriya, Persian, French, Sanskrit,
Hindi, Telegu or any other language) notified in the Official Gazette for inclusion in this group;

(iv) Physical Education;
(v) Work Education;
0) “Reserved Category” means category of reservation in respect of the Schedule Castes, the Scheduled
Tribes, the Other Backward Classes (Group A and Group B) and Physically Handicapped candidates;
(k) “Schedule” means Schedules appended to these tules;
(1) “State” means the State of West Bengal;
(m) “State Government” means the Government of West Bengal in the School Education Department,
(n) “State Level Selection Test (SLST)” means the test to be conducted by the Central School Service
Commission for recruitment of Teachers of the categories stated in these rules;
(0) “sub-rule” means sub-rule of a rule in which the word or expression occurs;
(p) “vacancy” means a vacancy in the post of a Teacher for classes of Upper Primary Level caused by-—
(i) creation of a new post;
(ii) superannuation;
(0) death;
(iv) resignation;
(v) _ transfer;
(vi) removal or dismissal;
(vii) any other reason, apart from the above, as the State Government may, by order, determine;
(q) “NCTE” means the National Council for Teacher Education (a statutory body of the Government of
India);
0) “Teacher Eligibility Test (TET)” means Teacher Eligibility Test of the classes for Upper Primary Level
covered under these Rules conducted by the State Government or through its specified agency as per
NCTE Guidelines and other notifications issued by the Ministry of Human Resource Development,

<!-- page 3 -->

Parr] THE KOLKATA GAZETTE, EXTRAORDINARY, SEPTEMBER 20, 2016 3
a ee 84454
_ললললললললললললললললললললল্ল্ললললললললললা লু ঁ লহ
Government of India, from time to time in this regard and the State Government or such agency shall
issue a Certificate to be known as ‘TET Certificate’ to the Candidates who have qualified in TET;
(s) “Upper Primary” means general education above primary level till completion of Elementary Education
within the meaning of RTE Act for admission in Secondary Education stage;
(t) “Physical Education/Work Education vacancy” means vacancy for the post of a teacher in a school for
classes covered under these Rules for the purpose of pertaining teaching in Physical Education/Work
Education;
(u) “Professional qualification (except Physical Education or Work Education)” includes as follows:—
(i) 2-year Diploma in Elementary Education (by whatever name known),
(ii) 1-year Bachelor in Education (B.Ed.),
(ii) 1-year Bachelor in Education (B.Ed.) in accordance with the NCTE (Recognition norms and
procedure) Regulation issued from time to time in this regard,
(iv) 1-year B.Ed. (Special Education),
(v) 2-year Bachelor in Education (B.Ed.) in accordance with the NCTE (Recognition norms and
procedure) Regulation issued from time to time in this regard,
(vi) 4-year BA/B.Sc Ed. Or BA Ed/B.Sc. Ed,
(vii) 4-year Bachelor in Elementary Education (B. EI. Ed) includes Bachelor Degree along with
professional qualification as integrated course,
(viii) 2-years B.Ed. Programme through Open Distance Learning (ODL) method conducted by Netaji
Subhash Open University and Approved by Rehabilitation Council of India (RCI).
Note 1.— Diploma /Degree Course in Teacher Education recognised by the National Council for Teacher
Education (NCTE) only shall be considered. However, in case B.Ed. (Special Education), a course
recognized by the Rehabilitation Council of India (RCI) only shall be considered.
Note 2.— B.Ed. (Special Education degree holder) shall have to undergo 6 months training on special
programme in Elementary Education in an NCTE recognize institution after appointment.

(v) “Qualification” includes qualification of the teachers as notified by the NCTE and relaxation of
qualifications, if any, extended by the Central Government from time to time up to the date of publication
of advertisement;

(w) “RTE Act” means the Right of Children to Free and Compulsory Education Act, 2009.

(2) Words and expressions used and not defined in these tules but defined in the Act, shall have the same
meanings as respectively assigned to them in the Act.

3. Method of recruitment. — The appointment of persons to the posts mentioned in Schedule I shall be made

by selection (direct recruitment) through SLST by the West Bengal School Service Commission in the manner

as mentioned in rule 7.

4. Name of post, essential qualification and age. — (1) The name of the posts, and its qualification shall,

subject to rule 5, be such as specified in Schedule I:

Provided that the candidates possessing valid TET Certificates shall be eligible for appearing in the selection under
these rules, in spite of the fact that they have exceeded upper age-limit, subject to the condition that the age of such
candidate on first day January of the Year of holding the TET has been within the prescribed age-limit.

Provided further that the qualification for the posts of Teacher includes academic qualification and professional
qualification of teachers for Upper Primary Level of Schools notified by NCTE and includes the relaxation of qualification,
if any, extended by the Central Government or NCTE, as the case may be, from time to time on the date of advertisement
by the Central Commission or in case of Work Education, relaxation of qualification as may be notified by the State
Government.

Provided also that certificates received on or before the last date of the application and mentioned in the application
form, shall be counted for academic and professional qualification.

(2) The age-limit for the post shall be such as specified in Schedule I:

Provided that a non-teaching staff or a Teacher having post-graduate degree but holding lower category of post,
may apply with maximum age of 55 years as on the Ist day of January of the year of advertisement.

<!-- page 4 -->

4 THE KOLKATA GAZETTE, EXTRAORDINARY, SEPTEMBER 20, 2016 [যা
2১১২-১১-৭১ ২১১১১৬২২২২৯:
হল লু

5. Additional essential qualification of candidate— A candidate willing to be selected as a Upper Primary
Teacher having Bengali or English or Hindi or Nepali or Oriya or Santhali or Telegu or Urdu as the medium of
instruction, shall have Bengali or English or Hindi or Nepali or Oriya or Santhali or Telegu or Urdu, as the case
may be, as first or second or third language at Secondary level of the Board or equivalent or at Higher
Secondary level of the Council or equivalent.

6.  Disqualification.(1) No person shall be eligible for selection for appointment to the post of teachers for
Upper Primary Level of Schools unless he is a citizen of India.

(2) No person shall be eligible for selection for appointment to the post of teachers for Upper Primary Level
of Schools if he/she is convicted by any Court of law or who is under suspension from any school or
removed from service from any school or against whom criminal case is pending in any court of law.

7. Manner of selection.— (1) Selection to the post of such Teacher (except Physical Education and Work
Education) shall be made category-wise on the basis of merit (weightage of TET, academic and professional
qualification and marks obtained in personality test), in the manner as specified in Part A of Schedule III.

(2) Selection to the post of such Teacher in Physical Education and Work Education shall be made on the
basis of the results of the written examination conducted by the Central Commission, evaluation of academic
and professional qualifications and personality tests of the candidates in the manner as specified in Part B of
Schedule III.

(3) The Central Commission may, in its discretion, fix qualifying marks, to be scored by the candidates, in
written examination or in aggregate or in both and/or relax the qualifying marks on reasonable grounds and
reasons to be recorded in writing.

8. Information regarding vacancies.— (1) The District Inspectors of Schools (Secondary Education) shall,
on being asked by the Director of School Education, prepare a report regarding the number of vacancies in
posts, Subject group-wise, subject-wise, medium-wise, gender-wise and reservation category-wise for the
posts of Teachers and send it to the Directorate of School Education.

(2) Onreceipt of report under sub-rule (1), the Directorate of School Education shall, with due approval of
the State Government, send the Subject group-wise, subject-wise, medium-wise, gender-wise and reservation
category-wise vacancy report compiled region-wise, earmarked vacancies such posts, if any, declared by the
State Government for any year, to the Central Commission.
(3) The report as mentioned in sub-rule (2), shall be sent to the Central Commission in the following manner:—
(a) firstly, before the date of publication of the advertisement inviting application; and
(b) lastly, fifteen (15) days before the date of publication of the result of the written examination or
Interview list, as the case may be.
(4) The State Government may, by notification, earmark upto 10% of the total vacant posts with a view to
provide adequate representation of the Para Teachers without disturbing 100 point roster as may be notified
from time to time. If there is no notification to earmark the posts or if the posts remain vacant due to non-
availability of suitable candidates, the earmarked posts shall be filled up as per general procedures as mentioned
in these rules from the qualified eligible candidates.

9. Advertisement.— (1) The Central Commission shall, on receipt of the report of region-wise vacancies under

tule 8, issue an advertisement through newspapers in the State in English, Bengali, Hindi and/or in any other
languages, if necessary, as may be decided by the Commission and also through the website of the Commission.
(2) Such advertisement shall be issued specifying the vacancies, qualification, age as on the Ist day of
January of the year of advertisement and other necessary information relating to such posts, details of which
may be obtained through the website of the Central Commission and from the Offices of Central Commission
and Regional Commissions.
(3) While specifying the vacancies in the advertisement, the Central Commission shall, for the said posts of
such Teachers, publish a tentative number of vacancy at the time of inviting applications for State Level
Selection Test (SLST) that have been reported under clause (a) of sub-rule (3) of rule 8 and a final vacancy
list at the time of publication of Interview list except Physical Education and Work Education and in case of
Physical Education and Work Education at the time of publication of the result of the written examination
declaring the actual vacancies that have been reported under clause (b) of sub-rule (3) of rule 8. Subject-wise
vacancies in each group shall be clearly mentioned and candidates may choose hisher subject group which
he/she had in TET Examination and the subject chosen shall be a subject in his/her Graduation level for
vacancies except Physical Education and Work Education.

<!-- page 5 -->

Parr] THE KOLKATAGAZETTE, EXTRAORDINARY, SEPTEMBER. 20,2016 5

10. Form of application.— (1) The form of application for State Level Selection Test (SLST) for appointment to
the posts shall be such, as may be determined by the Central Commission from time to time.

(2) The proforma of the form of application may be published in the Newspapers or the Commission’s
Website as may be determined by and at the discretion of the Central Commission.
(3) The fees of SLST shall be such as may be fixed by the Central Commission from time to time.

11. Submission of applications.— The applications shall be submitted within such time and in such manner as
may be specified by the Central Commission in the advertisement.

12. Method of SLST for selection of candidates and preparation of panel for teachers (except Physical
Education and Work Education).—(1) The Central Commission shall arrange for proper custody of all
online applications which may be received by it against the vacancies,

(2) The Central Commission after receiving application forms shall prepare list of eligible candidates for the
purpose of preparation of a computer generated database of all the candidates.
(3). The Central Commission shall verify the validity of TET Certificate, academic and professional qualification
of the candidates having valid TET Certificates and marks obtained in TET and other academic and professional
qualification shall be evaluated in the manner mentioned in Part A of Schedule II.
(4) The Central Commission shall prepare and publish in their website and Interview List with all details of
the candidates to be called for personality test, category-wise on the basis of merit as mentioned in Part A of
Schedule II in the ratio of 1:1.4 of final vacancies.
(5) After interview, the Central Commission shall, from Interview List, prepare and publish a merit list
category-wise on the basis of merit (weightage of TET, academic and professional qualification and marks
obtained in personality test) as per Part A of Schedule III.
(6) The Central Commission shall also prepare and publish in their website a Panel of candidates (category
wise) equal to the number of vacancies and a category-wise waiting list of the rest of the candidates from
merit list who were not included in the panel. From the panel the Central Commission shall prepare Region-
wise lists of candidates on the basis of the option exercised by the candidates and publish in their website.
Provided that the Central Commission shall publish in their website the appropriate answers of the Questions
for general information.
Provided further if more than one candidate obtain the same aggregate (total marks) the merit position of the
candidates shall be determined according to their date of birth, i.e. candidates with earlier date of birth shall
be preferred and if the aggregate and date of birth shall also be same, the candidates obtaining higher academic
score shall be preferred and if the aggregate, date of birth and academic score shall be same, the candidates
obtaining higher weightage in TET shall be preferred.
(7) The Central Commission shall publish such panel and waiting list of candidates in the website of the
Commission as well as the Offices of the concerned Regional Commissions. A. copy of the same will be
submitted to the School Education Department and the Directorate of School Education for information.

13. Method of SLST for selection of. candidates and preparation of panel for Teachers for Physical Education
and Work Education.—(1) The Central Commission shall arrange for proper custody of all online applications
which may be received by it against the vacancies.

(2) The Central Commission after receiving application forms shall prepare list of eligible candidates for the
Purpose of preparation of a computer generated database of all the candidates.

(3) The admit cards for written examination shall be issued by the Central Commission by any mode as may
be determined by the Central Commission.

(4) The Central Commission shall arrange written examination.

(5) The Central Commission shall determine the method of written examinations, contents of; paper, duration
of examination, time and venue of examination and other matters relating to such State Level Selection Test.
(6) The Central Commission shall decide the procedure and the manner of. conducting the Selection Test.
(9) The admit cards for written examination shall be issued by the Central Commission by any mode as may
be determined by the Central Commission.
(8) The Central Commission shall arrange written examination.

<!-- page 6 -->

6 THEKOLKATA GAZETTE, EXTRAORDINARY, SEPTEMBER 20, 2016 [Parr I
(9) After the evaluation of the OMR Sheet or answer-sheet of the written examination, the Central Commission
shall prepare and publish the Interview List in their website with all details of the candidates to be called for
personality test, category-wise on the basis of merit (Marks of written test, Academic and Professional
Qualifications as mentioned in Part B and C of Schedule II) in the ratio of 1:1.4 of final vacancies.

(10) The Central Commission shall prepare and publish in their website a merit list of candidates prepared
category-wise on the basis of marks obtained in written test, evaluation of academic and professional
qualifications and marks of personality test as per Part B and Schedule III.
(11) The Central Commission shall also prepare and publish in their website a Panel of candidates (category-
wise) equal to the number of vacancies and a category-wise waiting list of the rest of the candidates from
merit list who were not included in the panel. From the panel the Central Commission shall prepare Region-
wise lists of candidates on the basis of the option exercised by the candidates and publish in their website.
Provided that written answer scrip/OMR shall not be reviewed or re-evaluated.
Provided further that the Central Commission shall publish in their website the appropriate answers of the
questions for general information.
Provided also that the number of qualified candidates to be called for the personality test shall not exceed 1.4
times the number of actual vacancies published at the time of declaration of the result of written examination
under clause (b) of sub-rule (3) of rule 8:
Provided also that if the marks at the last position of the qualified list of candidates shall be same for more
than one candidate, all such candidates at that position shall be called for the personality test even if the last
candidate exceeds limit of 1.4 times.
Provided also that if any candidate makes omission or commits error or makes any mistake of any nature to
fill in the OMR sheet or any defect crept in the OMR sheet of such candidate, the answer script of such
candidate will not be evaluated and the candidature of such candidate will not be considered.
(12) If more than one candidate obtain the same aggregate (total marks) the merit position of the candidates
shall be determined according to their date of birth, i.e. candidates with earlier date of birth shall be preferred
and if the aggregate and date of birth shall also be same, the candidates obtaining higher academic score shall
be preferred and if the aggregate, date of birth and academic score shall be same, the candidates obtaining
higher marks in written examination shall be preferred.
(13) The Central Commission shall publish such panel and waiting list of candidates in the website of the
Commission as well as the Offices of the concerned Regional Commissions. A copy of the same will be
submitted to the School Education Department and the Directorate of School Education for information.
14. Duties of the Central Commission in regard to selection.— (1) Save as otherwise provided under these
rules, the Central Commission shall perform the following functions in general:—
(0) tokeep liaison with the department to resolve different issues and chalk out the programme for conducting
Selection Test;
(ii) to finalize the details of the programme for Selection Test;
(1) to appoint paper setters;
(iv) to issue notification and/or advertisement for conducting Selection Test;
(v) to determine the format of application along with brochure (information related to filling Application
form) and mode of publication thereof;
(vi) to appoint district observers for conduct of Selection Test;
(vii) to constitute Personality Test Board consisting of members as specified in Schedule III;
(viii) to determine the procedure for preparation of Merit List and Panel;
(ix) to fix up the mode of publication of notice, merit list, vacancies, etc.;
(x) to do such other act as may be necessary for proper conduct of the Selection Test;
(xi) other duties as may be required to perform in connection with the selection test.
(2) The Central commission may assign any of the above functions to the Regional Commissions and may
take any assistance of the Regional Commissions in conducting the Selection Test.

<!-- page 7 -->

Parr I] THE KOLKATA GAZETTE, EXTRAORDINARY, SEPTEMBER 20, 2016 যা
15. Duties of the Regional Commissions in regard to selection. _ Save as otherwise provided in other
provisions of these rules, each Regional Commission shall, in the process of selection of Persons for
recommendation, perform the following functions:-—
(i) _ to assist to process application forms received at the Central Commission;
(ii) to arrange for counselling and recommend persons for appointment from the concerned region-wise
list prepared by the Central Commission;

(iii) to do such other duties apart from the above, as may be assigned to it by the Central Commission.

16. Validity of panel and waiting list. — (1) Each panel and waiting list shall remain valid for one year from the
date of publication of the panel and waiting list, or the date of advertisement for the next Recruitment Process
whichever is earlier:

Provided that the names of candidates shall not be recommended against any post other than the post applied
for or against any vacancy which has not been notified in terms of sub-rule (3) (b), of rule (8).

(2) Notwithstanding anything contained in sub-rule (1), a panel, waiting list, merit list prepared by each of the
Regional Commissions before coming into force of these rules, such panel, waiting list, merit list shall remain
valid according to the rules prevalent at that material point of time.

17. Recommendation of candidates for appointment.— (1) The Regional Commission shall hold counselling
with a view to recommending the name of the candidate from the list for appointment against each vacancy.
(2) Thereafter, the Regional Commission shall recommend the name of only one candidate against each
vacancy depending on his/her position in the panel and availability of requisite vacancy and a copy of the letter
recommending the name shall be sent through speed post or in such other mode to the candidate, to the
concemed authority of the School as well as concerned District Inspector of Schools (SE) where the particular
vacancy exists.

(3) Arecommendation letter shall remain valid for a period of ninety days from the date of issue:
Provided that the Regional Commission may, if it thinks expedient to extend the validity of the recommendation
beyond the period of ninety days for any reasonable cause, for the reasons to be recorded in writing, extend
the period of validity of such recommendation letter for a further period not exceeding sixty days.
(4) The concerned School authority shall on the basis of the recommendation of the Commission, issue the
letter of appointment to the candidate allowing joining time of not less than thirty (30) days through registered
post with acknowledgement due and upon receipt of appointment letter from the concerned school authority
the candidate shall join the post within the stipulated period as mentioned in the appointment letter on verification
of original Certificates, Documents of the candidate by Headmaster/ Headmistress or Teacher in Charge.
Provided that if the School authority has any doubt about the vacancy position, it shall intimate the same to
the Central Commission/Regional Commission, District Inspector of Schools (Secondary Education) and
Director of School Education.
(5) If-

(a) candidate refuses to accept his/her allotment of post during counseling, or

(b) the Central Commission gets information from any school or from the District Inspector of Schools

(Secondary Education), or otherwise, that a candidate recommended for appointment has not
accepted the offer of appointment or join the post within the stipulated period, or

(c) such a candidate refuses to accept appointment, or

(d) on further scrutiny it appears that the candidate has misrepresented the facts,
the Central Commission may do away with his name from the panel and will be deemed to have been
depanelled and recommend the name of a candidate from the waiting list strictly within the validity period of
the panel and waiting list.
(6) If a candidate, whose name has been recommended by the Regional Commission for appointment,
cannot be appointed to the vacancy for which he/she was recommended for the reason that such vacancy
ceased to exist, the managing committee, by whatever name it is called, or the ad-hoc committee or the
administrator or the concerned District Inspector of Schools (Secondary Education), as the case may be,
shall send an information in this regard to the Regional Commission and Regional Commission may, on
receipt of such information, recommend his/her name for any other appropriate vacancy.

<!-- page 8 -->

8 THE KOLKATA GAZETTE, EXTRAORDINARY, SEPTEMBER 20, 2016 [Parl
(7) Ifthe managing committee, by whatever name it is called, or ad-hoc Committee or the administrator, if
any, of any School does not appoint the candidate on the recommendation of School Service Commission
having jurisdiction, the Regional Commission shall forward the matter to the School Education Department
through the Central Commission for taking action under section 9A of the Act.

(8) Male candidate shall not be recommended for appointment in any girls’ school.

18. Cancellation or withdrawal of Recommendation.- If prior to or after recommendation or during the
course of selection process, it is found that any candidate concealed or suppressed or misrepresented or
made false declaration in his/her application or at any subsequent stage or any mistake or fault committed by
the Commission in granting recommendation wrongly to any candidate in contradiction to the provisions of
the Act, Rules or other conditions as may be laid down, such candidate will be treated as disqualified and his/
her recommendation will be cancelled and/or withdrawn at any stage and further his/her appointment, if any,
shall stand terminated/cancelled and in such cases the decision of the Central Commission shall be final.
Further the Central Commission may also take steps to fill up such post/s from Waiting List within the validity
period of the Panel and Waiting List, by issuing suitable direction to the concerned Regional Commission.

19. Carry forward of vacancy. — The vacancies, which are not filled up for unsuitability of candidates or for any
other reasons, as the Central Commission may by order mention, shall be carried forward for the next
recruitment/transfer process.

20. Interpretation. — (1) If any question arises regarding any decision of Central Commission, a reference may
be made to the State Government and the decision taken by it shall be final.

(2) Inregard to the interpretation of any provision of these rules, the decision of the State Government shall
be final.

21. Savings. _ (1) Nothing in these rules shall affect reservation, relaxation of age-limit and other concessions
required to be provided for the Scheduled Castes, the Scheduled Tribes, Other Backward Classes (Group A
and Group B) and other special categories of persons and Para Teachers in accordance with the orders issued
by the State Government from time to time in this regard.

(2) Nothing in these rules shall affect any act done or cause to be done in accordance with the provisions of
the earlier rules made or notifications or orders issued under the Act.

22. Preservation of written examination answer scripts.— The written answer scripts/OMRs of examinations
shall be destroyed by the Commission after 1 year from the date of publication of the panel.

SCHEDULE -I
[See rules 3 & 4]
PARTA
Educational qualification including professional qualifications for selection of
Assistant Teachers for Upper Primary Level Classes in Schools.
Name of post} Educational qualification including professional qualifications Age limit
Essential:
(a) Graduation and 2 year Diploma in Elementary Education (by
whatever name known);
OR Minimum 20 years and
Graduation with at least 50% marks and 1 year Bachelor in maximum 40 years. Upper
Education (B.Ed.); age limit is however
OR relaxable by 5 years for
Graduation with at least 45% marks and 1 year Bachelor in Bepedules Faeeaceheduled
Education (B.Ed.), in accordance with the NCTE (Recognition Pe i oe spe Jae
Norms and Procedure) Regulations issued from time to time ১2753 Se eng
in this regard; candidates and 8 years for
4 OR the Physically Handicapped
4 F q : Candidates.
Senior Secondary (or its equivalent) with at least 50% marks
and 4-year Bachelor in Elementary Education (B.El. Ed.);

<!-- page 9 -->

Parr] THE KOLKATA GAZETTE, EXTRAORDINARY, SEPTEMBER 20, 2016 9
১০১০১১১১০৬৭ he he ee
-ললল্ল্ল্লললললল্ললল্লললল্ল্্্ল্ ললল্ল্ললাউ ঁলল১
Name of 79930] Educational qualification including professional qualifications Age limit
OR
Senior Secondary (or its equivalent) with at least 50% marks
and 4-year BA/B.Sc. Ed. or B.A.Ed./B.Sc. Ed.;
OR
Graduation with at least 50% marks and 1-year B.Ed. (Special
Education);
AND
(b) Pass in the Teacher Eligibility Test (TET), to be conducted by
the appropriate Government in accordance with the Guidelines
framed by the NCTE for the purpose.
Explanation— The expression “Diploma or Degree Course in
Teacher Education” means—
(i) _adiploma or degree course in teacher education recognized
by the National Council for Teacher Education (NCTE);
and
(ii) ৪ diploma in Education (Special Education) and B.Ed.
(Special Education) recognized by the Rehabilitation
Council of India (RCI);
Note The minimum qualification as prescribed by the NCTE and
relaxation of qualifications if any extended by the Central Government
from time to time on the date of publication of advertisement, shall
also be considered.
PARTB y
Educational qualification including professional qualifications for selection of Assistant
Teachers for Physical Education and Work Education under for Upper Primary Level Classes in Schools.
gree il Educational qualification including professional qualifications
1 Assistant Essential: Minimum 20
Teacher for (a) Senior Secondary (Class XII or its equivalent) with at least 50% | years and
Physical marks from recognized Board; maximum 40
Primary Candidates who have passed the Senior Secondary Examination Eas a
Teveloe (+2) or its equivalent and have participated in sports/games 1 M
(7 atleast school/college/district level in accordance with the 5 1 ui 1৩৫
National Council for Teacher Education (Recognition norms and ral fe a i 4
procedure) Regulations 2007 notified on 10-12-2007; aa F _ gi
candi-
OR dates, 3 years
Senior Secondary (Class XII or its equivalent) with at least 45% for Backward
marks from recognized Board in accordance with the National Class candidates
Council for Teacher Education (Form of application for and 8 years for
recognition, the limit of submission of application, determination the Physically
of norms and standards for recognition of Teacher Education Handicapped
Programmes and permission to start new course or training) Gandidutes
Regulations 2002 notified on 13-11-2002; i
AND
(b) Certificate/Diploma in Physical Education of duration not less
than 2 years ( or its equivalent) from any National Council for
Teacher Education recognized Institution;

<!-- page 10 -->

10 THE KOLKATA GAZETTE, EXTRAORDINARY, SEPTEMBER 20, 2016 [Parr
ললললললললললললললললললললললললললললল ল্ললললল_ু
51. Name of 5 ॥ কী fo রর / রী nee
. No 1) Educational qualification including professional qualifications Age limit
Note. The minimum qualification as prescribed by the NCTE and
relaxation of qualifications if any extended by Central Government or NCTE
from time to time on the date of publication of advertisement shall also be
considered.
2° Assistant Essential: Minimum 20
Rees en. for (a) Graduate from a recognised university with Post Graduate Basic Bars! and 40
oe ee Training or Work Education as a subject in Bachelor of Education ee
Education in = ডি রটে years. Upper
Upper in regular course from a Teachers’ Training Institution duly চি
এ recognised by the National Council for Teacher Education
Primary (NCTE); however
Level of 9; relaxable by 5
Schools OR years for
Graduate with Degree or Diploma in Art and Craft from any Scheduled
recognised University/any recognised educational Institution Caste/
affiliated to any University; Scheduled
Tribe
IR
z 2 i রা candidates, 3
Graduate with Degree or Diploma in Tailoring and needle work years for
from any Institution duly recognised by any recognised) Backward
University/from any institute recognized by any Department of] Class
the Government of West Bengal; candidates and
OR 8 years for the
Graduate from recognised University with at least two years Physically
Degree or Diploma in the Work Education curriculum awarded ae te
by any recognised University; 8
OR
Graduate Degree in Home Science or Agriculture or Graduate in
Computer Science or Information Technology or Software
systems from any recognized University;
OR
Graduate in General Stream in Arts/Science/Commerce with
Computer Science or Computer Application as a subject of at
least 300 marks at the degree level from any recognised
University;
OR
Graduate Degree in Home Science or Agriculture or Graduate in
Computer Science or Information Technology or Software
systems from any recognized University;
OR
Graduate in General Stream in Arts/Science/Commerce with
Computer Science or Computer Application as a subject of at
least 300 marks at the degree level from any recognised
University.
Desirable:
Degree in Bachelor of Teaching/Bachelor of Education/Post-
Graduate Basic Training from any recognized University or any training
recognized by the State Government as equivalent to Bachelor of
: Teaching/Bachelor of Education/Post-Graduate Basic Training from a
Teachers’ Training Institution duly recognized by the National Council
for Teacher Education (NCTE)/ Rehabilitation Council of India (RCI)
in the relevant academic session;
