---
doc_id: "a11deebbfd66b2ce"
source_url: "https://www.darahwb.org/upload/actsrules/actsrules_7.pdf"
ministry: "Animal Resources Development Department, West Bengal"
title: ""
date: ""
pages: 4
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "5c3d4feb7dcf5d00"
---

<!-- page 1 -->

“ . |
| |
West Bengal Act 22 of 1950+
THE WEST BENGAL ANIMAL SLAUGHTER CONTROL
ACT, 1950.
Amended by West Ben. Act 19 of 1979.
{ 6th April, 1950. } |
An Act to contro! the slaughter of certain animals.
Wuermas it is expedient to control the slaughter of certain animals
with a view to increase the supply of milk and to avoid the wastage of 1
; animal power necessary for improvement of agriculture ; ; |
It Is hereby enacted as follows :— 1.
1, SHORT TITLE, EXTENT AND COMMENCEMENT, 0) This 1
Ast may be called the West Bengal Animal Slaughter Control Act, 1950, He
(2) It extends to the whole of West Bengal. ! ;
(3) It shall coms into *force on such date or dates as the State 4
\ Government may, by notification in the Oficial Gazette, appoint and | ie
/ different dates may be appoiated for different parts of West Bengal. | a
2. APPLICATION OF ACT. This Act applies to 05910100815 | rd
specified in the Schedule, ba
3. DEFI{NITIONS. in this Act, unless there is anything repugnant : Ea
in the subject or context,— | el
রর (i) “animal”? means aa animal to which this Act applies ; . |
(ii) “Calcutta” has the sam2 meaning a3 in clause (11) of section 3 of | টা
the Calcutta. Municipal Act, 19835 ; | oY
‘ ‘(iii) “President” means,— | 2
(a) in relation to a municipality, any person presiding over the | ঃ
affairs of any municipal authority, and | @
(b) in relatioa to a Panchayat Samiti, any person presiding over the ] ক
. affairs of any Panchayat Samiti, ad
by whatever name called, and includes any person nominated by:him ( না
for the purposes of this Act ; and . | a
4 * (iv) “prescribed” means prescribed by cules made under this Act ; । রা
26) “Veterinary Surgeon” means,— i | ad
(a) im areas other than Calcutta, a Veterinary Surgeon, and 11 i
(০) in Calcutta, a Veterinary Surgeon of the Directorate of Veterin- | " | od
acy Services, Goverameat of West Bengal, actiag within the local limits 1) i
of his jurisdiction, and.’ ]
(vi) “Veterinary Officer’ means— 11) Ee
(a) in areas other thaa Calcutta, District Voteriaary Offizer, and i ?
1. Clause (iii) substituted by West Bengal Act 19 of 1979. ij 13]
2. Clause (৮) substituted by West 80481. Act 19 of 1979. * a
| 1]
ia — 11

<!-- page 2 -->

tf
| \ = 262 ‘pH WEST BENGAL LAWS [s-3
+ ®
it (b) in Calcutta, a Superintendent of Veterinary Services (Head-
I t quarters ) of the West Bengal Civil Veterinary Department acting within
[| the local limits of his jurisdiction. নি
| j \4, PROHIBITION OF SLAUGHTER OF ANIMAL WITHOUT 1
{| CERTIFICATE. (1) Notwithstanding anything in any other law for /
| the time being in force or in any usage to the contrary, no person shall { "
i" | slaughter any animal unless he has obtained in respect thereof a i
| certificate under sub-section (2) or sub-section (3)‘that the animal is |
] fit for slaughter. j
‘i (2) *[{The President of a Municipality or a Panchayat Samiti, as ৃ
। the case may be, and the Veterinary Surgeon] may issue a certificate
i under their joint signatures that an animal is fit for slaughter if they are
i both of opinion ( which shall be recorded ) that —
I 4 (a) the animal is over foutteen years of age and unfit for work or
[ \ breeding, or
? ? ৮৪): the animal has become permanently incapacitated from work 4
a or breeding due to age, injury, deformity or any incurable disease.
ti (3) Where there is a difference of opinion between 4[the President
4 of Municipality or a Panchayat Samiti, as the case may be, and the i
i Veterinary Surgeon] as to the issue of a certificate under sub-section (2), if
i the matter shall be referred to the Veterinary Officer and a certificate {
f shall be issued or refused according as the Veterinary Officer is of opinion |
‘ that the animal is fit to be slaughtered or is not so fit, |
) (4) Where under sub-section (3) a certificate is issued or refused 1
4 the order granting or refusing the issue. of the certificate shall be |
signed by the Veterinary Officer. t
1 (5) Any person aggrieved by the refusal to issue a certificate 2
Lae under this section may, within fifteen days from the date of communi-
1.1 cation to him of such refusal, appeal to the State Government against 11
1: the order “of refusal, and the State Government may pass such orders x «
i thereon as it thinks fit, ana
2 | , (6) The State Government may, at any time for the purpose of satis- . Ve ]
tl fying itself as to the legality or propriety of any action taken under this BY 1
ae section, call for and examine the record of any case, and may passsuch 7
] orders thereon as it thinks fit. * 4 4
i (7) Subject to the provisions of this section, any action taken co ]
| under this section shall be final and shall not be called in question in .*  *
H any court. se i
i! 5. PROHIBITION OF SLAUGHTER OF ANIMALS IN PLACES ef
f NOT PRESCRIBED FOR-THE PURPOSE, No. animal in respect of i |
i 3. These words substituted by West Bengal Act 19 of 1979. |
i 4. These. words substituted by West Bengal Act 19 of 1979. ‘ : / |

<!-- page 3 -->

s-12) THE W. BENGAL ANIMAL SLAUGHTER CONTROL ACT (22 or 1950) 263 te
which a certificate has been issued under section 4 shall be slaughtered | q
in any place other than a place prescribed in this behalf. 4 bial
. 6. (1) POWER TO ENTER AND INSPECT PREMISES. For the ie | bod
¢ purposes of enforcing the provisions of this Act, [the President of a ] 1 ae
Municipality or a Panchayat Samiti, as the case may be, or the Veterinary | hae
Surgeon] or any person authorised by the Veterinary Assistant Surgeon in i ॥ ue
writing in this behalf shall have power to enter and inspect any premises eet
within the local limits of his jurisdiction where he has reason to believe ৫)
that an offence under this Act has been or is likely to be committed. 1 8
॥ (2) .Every person in occupation of any such premises as is specified f i
in sub-section (1) shall allow ®[the President of a Municipality or a ] ['
Panchayat Samiti, the Veterinary Surgeon] or the person authorised, as ] cae
the case may be, such access to the premises as he may require for the {| |.
aforesaid purpose, and shall answer any question put to him by ®(the t ia
President of a Municipality or a Panchayat Samiti, the Veterinary Surgeon] ' বু
\ authorised, as the case may be, to the best of his knowledge or belief. 1 1 ee
j পি, PENALTIES, Whoever contravenes any of the provisions —
contained in this Act shall be punishable with imprisonment for a term) 1 os
! which may extend to six months, or with fine which may extend to one i
thousand rupees, or with both. টা
u "8. OFFENCES TOBE COGNIZABLE. Notwithstanding anything Baik
contained in the Code of Criminal Procedure, 1898, all offences under i ee
i this Act shall be cognizable. |
টু 9. ABETMENTS AND ATTEMPIS. Whoever abets any offence |
; punishable under this Act or attempts to commit any such offence shall
: t be punished with the puaishment provided in this Act for such offence. 1.1
10. OFFICERS EXERCISING POWERS UNDER THIS ACT i
DEEMED TO BE PUBLIC SERVANTS, “[All Presidents of Municipalities i
or Panchayat Samities, Veterinary Surgeons], Veterinary Officers and other 1
persons exercising powers under this Act shall be deemed to be public i |
i servants within the meaning of section 21 of the Indian Penal Code. |!
ia , IL, PROTECTION OF PERSONS ACTING IN GOOD FAITH. | q |
No suit, prosecution or other legal proceeding shall be instituted against | 11
any person for anything which is in good faith done or intended to be ছি
| done under this Act or the rules made thereunder. |]. ধু
] 12, POWER TO GRANT EXEMPTIONS, The State Government i |
he may, by general or special order and subject to such conditions as it may BE
think fit to impose, exempt from the operation of this Act the slaughter of ak
any animal for any religious, medicinal or research purposes. i ]
5. These words substituted by West Bengal Act 19 of 1979. 118 | i
6. These words substituted by West Bengal Act 19 of 1979.
7. These words substituted by West Bengal Act 19 of 1979. । |
“ (

<!-- page 4 -->

eng 1 = ]
og 264 5 THE WEST BENGAL LAWs [s-a3 |
ie pe
} ] Hl 13. DELEGATION OF FUNCTIONS. The State Government |
4071) j may, by notification in the Official Gazette, ‘delegate to any officer of |
a ] State Government all or any of ils powers or functions under sub-sections _ fi
i (5) and (6) of section 4, or section 12, sy
aad | ] 1. -৮০%/2 TO MAKE RULES, (1) The State Government may,
He | i by notification in the Official Gazette make *rules to carry out the
] ] purposes of this Act. :
a | (2) In particular and without Prejudice to the generality of the fore~
৮২. ছে going power, such rules may provide for—
43 Ad if (a) the form and manner in which applications for certificates under co রর
if i section 4 shall be made ;
{ i (b) the fees payable for any’ certificate which may be issued under‘
1) ii section 4 and the form of such certificates ;
Ht i °(©)_ the time and the places at which animals may be slaughtered in ?
1 i) a municipality or a Block in Pursuance of this Act,,”” ডি.
] 1 (৫) the conditions subject to which the Slaughter of any animal may ]
ছা be permitted under Section 12, |
——— জা
i The Schedule
| ] ( See section 2 ) ‘ রর
i Bulls. : রর : ie
4 Bullocks, ‘
i Cows. us
i Calves. ‘ ie
Hi Male and female buffaloes. এ
Buffalo calves, : 4 .
ik Castrated buffaloes, ae
me টা 1
11 £ া।
1111]
10 5. Clause. (c). substituted by West Bengal Act 19 of 197, 7.
7 . রী সঃ |
Ba hen Sa Ct oy Eps SST Te
