---
doc_id: "bd0e61ce2a2c13bc"
source_url: "https://www.wbfdc.com/uploads/tender_files/pson.pdf"
ministry: "West Bengal Forest Development Corporation Ltd. (WBDFC), Kolkata, West Bengal"
title: "view details"
date: ""
pages: 4
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "94e0a721ce96d185"
---

<!-- page 1 -->

gone
fe hati
(eae
we
Stil
The West Bengal Pulpwood Development Corporation Limited
(A Joint Sector Company)
CIN:U20211WB1982PLC034704
“ARANYA BIKASH”, 3RD FLOOR,KB-19,SECTOR-IILK D1.Ki TA-700106
E-Mail ID: wbpulpwooddevcorpn.Itd@gmail.co 1)
No: ABS WBPDC/ I-65 , Date: 22,10, 2024,
NIQ No 05/WBPDCL/COLOUR PRINTER/2026-27'
Quotations are invited from bonafide experienced suppliers/contractors/manufacturer/agencies for supply of branded colour
printer (EPSON EcoTank L6570 Wi-Fi Duplex Multifunction ADF Ink Tank Office Printer;black variant) for official use at
the office of the Ex-officio Divisional Manager, The West Bengal Pulpwood Development Corporation Limited which is
located at “Aranya Bikash”, KB-19, Sector-III, Salt Lake City, Kolkata-700106.
© Details of Work:
SLNo Description Oty Rate including GST and
valid till 31 March,2027
টি Rs
Branded Colour Printer(copy+scan+wifi) (black variant) 1
(EPSON EcoTank L6570 Wi-Fi Duplex Multifunction ADF
Ink Tank Office Printer)
Note: Guaranty/Warranty are mandatory and required documents regarding this should be accompanied with
Model.
¢ Time and Date:
Date _
Date for beginning of distribution of Quotation Papers 29-10-2026 ____ | 11:00 AM
Last Date of submission of quotation paper(offline on] 06-11-2026 04:15 PM
Date and time of distribution and submission of quotation 29-10-2026 11:00AM to 5:15PM
paper 30-10-2026 11:00AM to 5:15PM
02-11-2026 11:00AM to 5:15PM
03-11-2026 11:00AM to 5:15PM
04-11-2026 11:00AM to 5:15PM
05-11-2026 11:00AM to 5:15PM
06-11-2026 _ 11:00AM to 4:15PM
06-11-2026 — [4:15 PM
Bidders can also collect the quotation notice online from the website www,wbfde.com
Mode of submission of quotation paper is offline only at “Aranya Bikash”, KB-19,3" Floor, Secior-III, Saltlake City, Kolkata-
700106
No other mode of submission of quotation paper will be entertained.
Note:
1) In case of any unscheduled holiday or on days of Bandh or natural calamity on the aforesaid dates, the next working day will be
treated as scheduled / prescribed date for the same purpose.
2) The Quotation Inviting Authority may change the venue of opening the quotation paper in case of exigent circumstances like
breakdown of communications link or conditions of force majeure.
3) The Quotation Inviting Authority reserves the right to defer the date of opening of quotation paper , if required.
¢ The interested supplier/contractor/manufacturer/agencies are requested to quote their rate for the aforesaid work by 06-
11-2026 4:15 PM in sealed envelope by the name of the undersigned.
¢ All quoted rate should be inclusive of all taxes.

<!-- page 2 -->

২২
(6০
১
NY
The West Bengal Pulpwood Development Corporation Limited
(A Joint Sector Company)
CIN:U20211WB1982PLC034704
“ARANYA BIKASH”, 3RD FLOOR,KB-19,SECTOR-II,.KOLKATA-700106
E-Mail ID: wbpulpwooddevcorpn.Itd@gmail.com
No: 455 /WBPDC/ 11765) Date: 28,10 +209 |
¢ Period of Work: Work to be completed within 07 days of receipt of final work order.
© Quotation will be submitted with Authorised seal & Signature. Addressed in the name of the Ex-officio Divisional
Manager, The West Bengal Pulpwood Development Corporation Limited at “Atanya Bikash”, KB-19, Sector-III,
Saltlake City, Kolkata-700106
¢ Delivery will be made at The West Bengal Pulpwood Development Corporation Limited, “Aranya Bikash”, 3"
Floor,KB-19, Sector-III, Saltlake City, Kolkata-700106.
© Technical Documents: -
1, Latest PTax Deposit Challan to the Govt of West Bengal
2. GST Registration Certificate for the state of West Bengal. If GST Registration is not applicable, a declaration to
be submitted by the bidder specifying the ground of such non-registration.
3. ITR Acknowledgement Reciept for last assessment year.
4. PAN Card.
5. Trade License issued by Local Bodies under Govt of West Bengal
6. For Proprietorship Firm- Trade License issued by Local Bodies under Govt of West Bengal; for partnership
firm- Registered Partnership Deed, registered power of attorney, Trade Licvnse issued by Local Bodies under
Govt of West Bengal; for Pvt. Ltd Company-registration/incorporation certificate under Company’s Act, MOA
& AOA. Registered Power of Attorney, Trade License issued by Local Bodies under Govt of West Bengal.
Please furnish self-attested documents.
7. Credential for similar nature of completed work during 5 (five) years prior to the date of issue of quotation
notice. Credential Certificate issued by the Executive Engineer/Divisional Forest Officer or equivalent or
Competent Authority of a State/Central Government, State/Central Government undertakings,
Statutory/Autonomous bodies constituted the Central/ State statute on the executed value of completed/running
work will be taken as credential.
Terms and Conditions

1. The West Bengal Pulpwood Development Corporation Limited shall not be responsible for any untoward or
accidental incident in the course of work or maintenance.

2. Rates quoted shall be valid till 319 March,2027.

3. Under any circumstances, any rate to be quoted which is over & above the Maximum Retail Price (MRP) of the
items. If such a thing comes to notice, it will be summarily rejected & quotationer will be barred to take part in any
quotation/tender process of this office thereafter. Please note if such higher rates are found even at a later stage, no
payment will be made beyond MRP.

4. The products which normally come to the market in a sealed state, must be delivered in sealed state. If the sealed
condition is found to be violated, it will not be accepted and no payment will be made against it.

5. Work Order will be issued after approval of quotation inviting authority and payment will be made after satisfactory
completion of work. Submit your bill with mentioning our GST No.(if applicable) with 3(three) copies of bill. (GST
No 19AABCT1517H2ZG) also including receipted copy of challan.

6. Pattern of Quotation: Invitation of quotations is purely indicative in nature. It is being floated in anticipation of
administrative approval and subsequent financial section. In case of non-availability of such approval and fund the
quotation shall be cancelled outright without assigning any further reason.

7. Validity of the quotation will be 1(one) year from the date of submission. The validity can be extended upto another
6(six) months subject to satisfactory performance of the successful bidders.

<!-- page 3 -->

গে
The West Bengal Pulpwood Development Corporation Limited
| (A Joint Sector Company)
CIN:U20211WB1982PLC034704
“ARANYA BIKASH”, 3RD FLOOR,KB-19,SECTOR-III,KOLKATA-700106
E-Mail ID: wbpulpwooddevcorpn.Itd@gmail.com
No: 455/wBPDC/ 17697 Date: 28 «10-90%,

8. The undersigned reserves the right to place order for work for 20% more or less of the quantity (if mentioned here)
is so required.

9. Upon selection and approval of the successful bidder (L1), a Work Order will be issued establishing the approved
unit rates, terms, and period of validity. Actual supply shall strictly be governed by individual Supply Orders /
Delivery Orders / Requisitions issued from time to time on an ‘as and when required’ basis during the currency of
the contract. The Contractor shall not execute any supply without receiving an official Supply Order against the
Work Order. Each individual Supply Order will specify the required items, quantity, and specific delivery location.
The supplier must execute the supply within 7(seven) working days from the date of issue of each individual
Supply Order.

10. The estimated quantities indicated in the Bill of Quantities (BOQ) are purely tentative and indicative. The Ex-
officio Divisional Manager, The West Bengal Pulpwood Development Corporation Limited reserves the right to
decrease, or completely omit any item quantity depending on actual organizational requirements, and no claim for
compensation or revision of rates shall be entertained on account of variation in quantities.

11. The rates quoted by the bidder shall remain firm, fixed, and binding throughout the Period of Work from the date of
issuance of the Work Order. No price escalation or variation shall be permissible on any grounds during this period.

12. The supplier must guarantee that the color printer supplied under this contract are 100% original, brand-new,
genuine, and manufactured directly by the respective Original Equipment Manufacturer (OEM). The supply of
compatible, remanufactured, counterfeit, or duplicate product is strictly prohibited. Each item delivered must bear
the original OEM barcode, security seal/hologram, and batch details intact.

13. If the printer supplied is found or suspected to be duplicate, fake, or non-genuine upon inspection, testing, or usage
The Quotation Inviting Authority reserves the right to reject the entire consignment immediately. The supplier shall,
at their own expense, collect the rejected material and replace it with genuine product.within 7(seven) working days
of notification. If the supplier fails to replace the rejected items within the stipulated timeframe The Quotation
Inviting Authority reserves the right to cancel the work order with immediate effect and to forfeit any pending
payment payable to the contractor. Penal action will be initiated against the contractor as per exciting financial
norms of Government of West Bengal.

14. The Quotation Inviting Authority has full right to accept or reject any quotation without assigning any reason.

15. The Quotation Inviting Authority has full right to accept or reject any quotation on technical ground.

16. The undersigned is not bound to accept the lowest rate quoted by the quotationers and he is not bound to assign any
reason whatsoever for such non acceptance.

17. All products should be of mentioned brand or reputed quality of certified standards. Their size and quality should be
as per general norms. The undersigned reserves the right to accept or deny the supplied articles if those are not up to
his satisfaction.

18. If produces get depreciated/damage/destroyed during supply or transportation or installation, it will not be received.
If such damaged products are found at the later stage, recovery will be made from the quotationer(s) as per rates
offered including imposing of necessary penalties/fines as the undersigned deems fit.

19. While engaging the labourers, if any, payment as per the Minimum Wage Act must be made to them

20. L; Bidder will be selected based on the overall rate quoted, not for individual items ..

21. The undersigned, his superior authorities or his representatives will inspect the works, take necessary measurements
and perform tests as and when required. The successful quotationers should render all cooperation in this regard,
irrespective of time and place and during the inspection by the undersigned, his superior authorities or his
representatives, if quality of the supply is not found up to the standard, the quotationer/

<!-- page 4 -->

2২
8409
The West Bengal Pulpwood Development Corporation Limited
(A Joint Sector Company)
CIN:U20211WB1982PLC034704
“ARANYA BIKASH”, 3RD FLOOR,KB-19,SECTOR-III,KOLKATA-700106
E-Mail ID: wbpulpwooddeveorpn.Itd@gmail.com ~
No: 45h /WBPDC/ 19766, Date: 29,10, 206 .

supplier/contractor/manufacturer/agencies is bound to rectify the same up to the satisfaction of him. No additional
payment will be entertained.

22. The quantity mentioned against each quotation is purely tentative in nature. Work/supply order will be placed only
after necessary administrative approval and financial sanction from appropriate authority that is too in actually
required quantity. The undersigned reserves the right to increase/decrease the quantity amount up to 20% of what is
mentioned in quotation.

23. Timely supply of all products will be the sole responsibility of the successful quotationer. But the quotationer shall
not be held responsible in default, if delay in execution occurs due to causes beyond his or her control such as acts
of God, natural calamities, civil wars, fire, strike, frost, floods, riot and acts of unsurpassed power. In the event of
delay due to such causes the quotationer may apply for extension of time for that period. The undersigned as per
direction received from the Managing Director, WBPDCL in this regard may extent for a length of time equal to the
period of force majeure or such period as he thinks suitable for that or may reject the application. Such cancellation
would be without any liability what so ever on the part of the undersigned.

24. Materials will have to be supplied by the quotationers by themselves following the standard and specification as
fixed by this office of the undersigned or his higher official.

25. All tools & plants required for execution of works should be procured by the contractor at his own cost. The
standard of such tools & plants shall be as per the specification of P.W.Dpt/PHE of the Govt. of West Bengal

26. In case of Each and Every bill initially 80% payment will be made and balance 20% payment will be made after
proper reflection of GSTR- | and GSTR 3B in stipulated time, in case of failure of such payment (tax return) or
mismatch of Tax Return Corporation will be recovering the amount from the balance payment (As per G.O. No
4679-F(y) dated 21-11-2022). y

27. The mode of payment for successful completion of the works will be made vy NB TGS.

28. The total value of the quotation shall be within I(one) lakh.

C মা eh
(Satyajit Roy,WBFS) রা
ডি
The West Bengal Pulpwo: elopment Corporation Limited
Copy forwarded to: 4.

1. The Managing Director, The West Bengal Pulpwood Development Corporation Limited

2. The Range Manager (HQ), WBPDCL is instructed to distribute the quotation notice on behalf of the Ex-officio
Divisional Manager, WBPDCL

3. Official Website of WBFDCL p

4. Notice Board of KFCD, WBFDCL. ৮

5. Notice Board of WBPDCL vA

CE
(
(Satyajit Roy,WBFS) লিল
Ex-officio Divisional Manager
The West Bengal te an Corporation Limited
a,
