---
doc_id: "85beb8ce28cfd9a7"
source_url: "https://www.sjda.org/pdf/1142608171WOrder_NIQ_11.pdf"
ministry: "Siliguri Jalpaiguri Development Authority (SJDA), West Bengal"
title: ""
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "81d549bf430ff7a1"
---

<!-- page 1 -->

siliguri Jalpaiguri Development Authority
A Statutory Authority Under Department of UDMA
An IS/ISO 9001:2008 Certified Organisation
Tenzing Norgey Road, Pradhan Nagar, Siliguri-734003
Phone: Siliguri -0353-2512922/2515647 Jalpaiguri - 03561-230874 E-mail: sjdawb@gmail.com

646/

Memo No

uss /51/22

Date:29/n/22

/SIDA

Acceptance cum Work Order
To:

MODERN DIGITAL SURVEY

Kamrangaguri, Opp. Uttarkanya
Satellite Township, Siliguri, Pin- 734015
Phone no. - 75013-19535

Email ID-info@moderndigitalsurvey.com
Name of Work

:DetailSurvey with TS Instrument for Termac Area of Truck Terminus at Paribahan
Nagar,
Matigara, District-Darieeling.

NIQ No

011/ENGG/ 2022-23 of SJDA (Off-Line)

Ref

Lowest Quoted Amount-Rs. 7.000.00/ Acre

Dear Sir(s),

Your offered Quoted Amount in the bid after

opening the Quotation for the work is Rs. 7,000.00/ Acre (Seven
Thousand Rupees per Acre) only has been
accepted by the undersigned for and on behalf of Siliguri Jalpaiguri
Development Authority subject to the condition that there will be no provision for Arbitration, Price
amendment,

Escalation, Mobilization advance and Secured advance as per conditions of the NIQ.
You are requested to contact with the concerned Assistant

Engineer of the Sub-Division to receive necessary
instruction in connection with the above mentioned work and start the work at the earliest. The
time allowed for carrying
out the work is 07 (Zero Seven) days and date of commencement will be reckoned
from the issue of this Acceptance cum
Work Order.
The stipulation is hereby made that the work should be restricted to

Quotation Amount. No excess work or

Supplementary work will be allowed without any prior approval.

Yours faithfully,

Encl.:-As stated above.

7

25/
Chief Executiyé Offícer,

Siliguri Jalpaiguri Development Authority

WORK ORDER- NIQ 011/ENGG/2021-22 of SJDA (3" Call)

Page-1 of2

<!-- page 2 -->

siliguri Jalpaiguri Development Authority
A Statutory Authority Under Department of UDMA
An IS/ISO 9001:2008 Certified Organisation
Tenzing Norgey Road, Pradhan Nagar, Siliguri-734003
Phone: Siliguri - 0353-25 12922/2515647 Jalpaiguri - 03561-230874

Memo No.

/SJDA

E-mail: sjdawb@gmail.com

Date

Copy forwarded to:
1.
2.
3.
4.
5.
6.

The Additional Chief Engineer, SJDA, Zone-01, for information.
The Assistant Executive Officer, SJDA, for information.
The Finance Officer, SJDA
The Executive Engineer, Div.-(), SJDA
Astt. Engineer, Sub-Div.- (), SJDA
Sri Simulendu Bhuiya, Sub-Assistant Engineer (Civil), SJDA

7.

Sri Manoj Roy, UDA, Engg. Section/SJDA,..

8.

Office Copy.

**********
.Requested to ensure uploading & e-Mailing of

Acceptance cum Work Order.

Chief Executive Officer,

SiliguriJalpaiguri Development Authority

WORK ORDER- NIQ 011/ENGG/2021-22 of SJDA (3'" Call)

Page-2 of2
