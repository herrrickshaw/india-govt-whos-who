---
doc_id: "cbfdc7ca91d496dd"
source_url: "https://dodl.klyuniv.ac.in/download/M.A.Semester-III(2024-26)_InternalAssessmentNotification.pdf"
ministry: "Directorate of Open and Distance Learning (DODL) - University of Kalyani, West Bengal"
title: "Read more"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "326a3f75aeb14fd4"
---

<!-- page 1 -->

University of Kalyani
Directorate of Open & Distance Learning
Kalyani-741235, West Bengal, India

Phone: 033 – 2502-2212, Email: dodlklyuniv@gmail.com
URL: http://dodl.klyuniv.ac.in

Prof. (Dr.) Ashis Kumar Panigrahi,
PhD, D.Sc, FZS, FBZS, FNAS

DIRECTOR
Ref. No. KU/DODL/212/26

Dated: 30.09.2026

NOTICE
This is to inform all students of M.A. Semester III (Academic Session: 2024–
2026), of KU Main Campus under the Directorate of Open & Distance Learning (DODL),
University of Kalyani, that the First and Second (Combined) Internal Assessment will
be conducted on 11.10.2026 (Sunday) through online mode using Google Forms, except
for Bengali, for which the assessment will be conducted through home assignments.

Time of the Examination
12:00 noon-3:30 p.m. (Education and English)
12:00 noon-3:00 p.m. (History)
The details of the internal assessment for each subject are given below.
Subject

Paper Code(s) Marks in First
Internal
Assessment
for Each
Paper

Bengali

B-CORE – 309
B-CORE – 310
DSE – 301
DSE – 302
DSE – 303
(Rabindra
Literature/
Linguistics/
Drama & Stage)
SEC

05

Marks in
Second
Internal
Assessment
for Each
Paper
05

Total
Marks

Mode of
Internal
Assessment

10
(For each
paper)

Home
Assignments
(To be
submitted at
the DODL
office)
Date of
Submission:
29.10.2026
&
30.10.2026
Time: 12:004:00 pm
DODL
Building

<!-- page 2 -->

Education

English

History

COR – 310
COR – 311
COR – 312
COR – 313
COR – 314
DSE – 301
SEC

5 questions

5 questions

10

For COR – 310,
311, 312, 314
and DSE – 301

For COR –
310, 311, 312,
314 and DSE –
301

(For COR –
310, 311,
312, 314
and DSE –
301)

(each question
carries 1 mark)

COR - 309
DSE - 301
DSE - 302
DSE - 303
DSE - 304
DSE - 305
SEC

05
(5 Questions each carries
1 mark)

COR - 309
COR - 310
COR - 311
COR - 312
DSE - 301
(Modern
Southeast Asia
or USA)
GE - 301

05
(5 Questions each carries
1 mark)

(each question
carries 1 mark)
COR – 313 and
SEC
(5 questions:
Each carries
1 mark)
05
(5 Questions each carries
1 mark)

05
(5 Questions each carries
1 mark)

5 for COR –
313 and
SEC paper

10
(For each
COR and
DSE paper)

Online mode
via Google
from

(There will be
separate google
form links for
each paper)
Online mode
via Google
form

5 for SEC
paper

(There will be
separate google
form links for
each paper)

10
(For each
paper)

Online mode
via Google
form

(There will be
separate google
form links for
each paper)

Separate Google Form links will be provided for each paper.
Important Instructions:
1. All students are instructed to ensure the availability of a stable internet connection and a
valid e-mail ID to participate in the online internal assessment.
2. Students must submit their responses within the prescribed examination time.
3. Students are advised to check the relevant Google Form links and follow the instructions
provided for each paper.
4. Students appearing for the Bengali internal assessment must submit their home
assignments at the DODL office on the specified dates and within the prescribed time.
