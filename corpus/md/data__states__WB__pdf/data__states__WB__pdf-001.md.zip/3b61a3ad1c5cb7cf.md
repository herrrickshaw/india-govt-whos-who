---
doc_id: "3b61a3ad1c5cb7cf"
source_url: "https://gcect.ac.in/download/Miscellaneous/GCECT_NIQ_RFID_Dropbox_Tender122024.pdf"
ministry: "Government College of Engineering & Ceramic Technology (GCE&CT), Kolkata, West Bengal"
title: "View Notice"
date: ""
pages: 1
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "0db43604e220ff8a"
---

<!-- page 1 -->

চা GOVERNMENT OF WEST BENGAL
দারা ~=Government College of Engineering & Ceramic Technology
fo 10 ৬ AN AUTONOMOUS INSTITUTE UNDER MAKA.U,T.
Gord 73, Abinash Chandra Banerjee Lane, Kolkata-700010
কর বি URL:www.gcect.ac.in E-Mail: gcectwb@gmail.com
Memo no: GCECT/ #37 = / E-Tender-I /2024-25 Date: December 27, 2024
রঙ Invitation of Quotation for “RFID BOOK 101২017১30৮
E_Tender is invited for the under-mentioned items with terms and conditions below in detail:-
Description oo Specifications —
1 | RFID Book Drop Box. 1. Book Drop box with
display monitor
| 2. UHF RFID reader and
| thermal printer.
| 3. 22° LCD screen, 32 bits
| true color,
| 4. Book Cart with trolly.
| Intel Dual Core
| CPU 1.6GHZ or Higher
| 4GB RAM, 320 GB SSD
RS-232, USB
Video Card,
Ethernet Interface.
Terms and Condition

1. The Vendor should have an office for support in Kolkata, West Bengal.

2. The Vendor must be a registered enterprise under the Companies Act.

3. The Vendor must be a listed paid support vendor in Koha Community.

4. The Vendor should be sole supplier of all the products (Software/ Hardware). No third party/ Joint
venture/Subsidiary/ will be entertained.

5. The Vendor must provide valid photocopies of GST, Professional TAX, and IRT Assessment for the last
three financial years.

6. The Vendor must have a turnover of a minimum of 50 Lakhs for the last two financial years.

7. The Vendor should have implemented and automated at least 30 libraries (including a minimum of 2 Govt.
Universities) of higher education institutes using Koha in India, Kindly attach valid purchase orders or
completion certificates. The vendor must show one credential. No third party/ joint venture/ subsidiary/
will be entertained.

8. The Vendor must have successfully implemented (UHF) RFID in 10 libraries.
(institutes/colleges/Universities) in India.

9, The Vendor must provide contact numbers of their existing clients for feedback purposes.

K. cha 1০১ ahs 9
2৮1৮৭
Prof. Krishnendu Chakrabarty
Principal
Govt. College of Engg. & Ceramic Technology
Page 1 of 1
