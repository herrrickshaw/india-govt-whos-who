---
doc_id: "2ef04edcdfa80db0"
source_url: "https://www.sjda.org/pdf/887593093corrigenda.pdf"
ministry: "Siliguri Jalpaiguri Development Authority (SJDA), West Bengal"
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8261518ed5c721f9"
---

<!-- page 1 -->

Siliguri Jalpaiguri Development Authority
An autonomous body under Department of UDMA
An l5/l5O 9001:2008 Certified Organisation
Himanchal Vihar, Near - Passport Sevalaghu Kendr4Matigara-734010

phone: Siliguri - 0353-2515647 Jalpaiguri - 03561-230874 E-mail: sjdawb@gmail.com

*o

No: [i f{ ltr,/ ,, /i : . ', -

'

"'{,

"

I

Date:-oslp-3!g]1]"

/SJDA

Corrigenda - 01
Tender Reference No. EOI CUM RFP (e - TENDER) NO. OO1 / ENGG

I 2026' 2I27of SJDA

Designing and
Name of Work : Expression of lnterest (EOl) cum Request for Proposal (RFP) for Planning,
periodicalArchitectural Supervision of the Proposed Housing Complex Project at Kawakhali,
adjacent to Siliguri, Dist. - Jalpaiguri, West Bengal'
Reference

)age no. 3, cl. no. 8
DPR Preparation and

iubmission Time)

ln place of

To be read as

Time allowed for PreParation and

Time allowed for preparation and submission of
vetted DPR in all respect is 60 days from the date
of issuance of the Work order.

submission of vetted DPR in all
respect is 45 daYs from the date of
issuance of the Work Order.

?age no. 3, cl. no.
iscope of Work)

The work will include preparation of
details of Architectural Drawings,

The work will include preparation of details

preparation of detailed estimates of

the proposed Housing Complex including

electrical, firefighting arrangements,

required), other ancillaries etc. and othei

Structural Designs including

of Architectural Drawings, Structural Designs
including preparation of detailed estimates of

the proposed Housing ComPlex sanitary, plumbing, electrical, firefighting
including sanitarY, Plumbing, arrangements, provision of air conditioning (if
provision of air conditioning, if project components with Bill of Quantities
required, other ancillaries etc. and (BOQ), LUCC from SJDA, necessary approval
from concerned GP/Mahakuma Parishad/ Jilla
Parishad subject to compliance of the provisions
of No Objection Certificates from other
Authorities/Departments, as applicable' The
detailed estimates will have to be prepared on
the basis of prevailing SoRs. ln case of nonscheduled items, analysis of rates will also
the work will include Periodical have to be provided. ln addition to the
supervision of execution in the field. above, the work will include periodical
The selected Consultant will have to supervision of execution in the field. The

other project components with Bill
of Quantities (BOQ). The detailed
estimates will have to be PrePared
on the basis of Prevailing SoRs. ln
case of non-scheduled items,
analysis of rates will also have to be
provided. ln addition to the above,

provide the followings:

selected Consultant will have to provide the

followings:
)age no. 6, cl. no, 14

29,10.2026 at 11:00 Hour at SJDA

30.10.2026 at 11:00 Hour at SJDA Office,

Date &

Office, Himanchal Vihar, near Passport
Seva Kendra, Matigara-734 010

Matigara-734 010

Time

ichedule), sl. no. 5 of
:able (Location, Date
& Time of Opening of

Himanchal Vihar, near Passport Seva Kendra,

fechnical Proposals
lPart-l) (online).)

OtherTerms and Conditions will remain unchanged,
i
,i
\c
u'- ;--4
Chief Executive Officer,
Siliguri Jalpaiguri Development Authority.
