---
doc_id: "fb55b5fb30e5faff"
source_url: "https://www.iiswbm.edu/wp-content/uploads/2026/03/teaching-position-instructions.pdf"
ministry: "Indian Institute of Social Welfare and Business Management (IISWBM), West Bengal"
title: "Apply for Teaching Position"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2aba602785874bef"
---

<!-- page 1 -->

INDIAN INSTITUTE OF SOCIAL WELFARE AND BUSINESS MANAGEMENT
MANAGEMENT HOUSE
College Square West, Kolkata 700 073
Advt. No. IISWBM/104/2026

Dated: March 27, 2026

Teaching Positions:

In continuation of our earlier Advertisement (Advt. No. IISWBM/101/2025 dated 08th
October, 2025), applications are invited from Indian citizens for the positions of Professor,
Associate Professor, Assistant Professor, and Professor of Practice in the following
disciplines:
•
•
•

IT & Business Analytics
Production & Operations
Logistics & Supply Chain

Eligibility:
Essential Qualification: A good academic record with a Ph.D. Degree in the
concerned/allied/relevant disciplines. The candidate must have first class or equivalent in the
preceding degree in appropriate branch and evidence of the ability to pursue independent
research.
Experiences: As per UGC/ AICTE rule for each stage of faculty position.
Scale of Pay: As per UGC/ AICTE rule for each stage in addition to allowances admissible as per
Institute’s rules.
The Self-Attested photocopies of the following documents should be enclosed with filled in
Application
1. Birth certificate or AADHAR card or Class X Admit card or Passport (for proof of Date of
Birth)
2. All educational mark-sheet and certificates
3. Category certificate (SC/ST/OBC), if applicable
4. Physically Handicapped certificate, if applicable
5. Copies of Five Best Research paper of your choice, if applicable
Candidates are solely responsible for ensuring that they meet the essential qualifications, experiences, and
other requirements specified in this advertisement as on last date of submission of application before
applying for the position(s). They are entirely accountable for the authenticity of the information and
documents submitted. If, at any stage of the selection process or even after appointment, it is discovered

<!-- page 2 -->

that the candidate does not meet the prescribed qualifications and experiences, their candidature or
appointment will be immediately cancelled or terminated.

Mere eligibility will not vest any right on any candidate for being short listed for interview. The
Institute reserves the right to call only the requisite number of candidates for interview after short
listing with reference to the candidate’s qualification, suitability, experience, publications etc.
The decision of the Institute in all matters will be final.
No interim correspondence will be entertained. Canvassing in any manner would entail
disqualification of the candidature.
The selected candidates will be appointed initially on contractual basis for three years, out of
which first year will be on probation. The contract may be renewed every year after probation
period and likely to be permanent depending on performance at the discretion of the competent
authority at the end of the third year of continuous service in this Institute.
The vacant positions in any or all of the categories may be increased or decreased, at the time of
each round of selection depending upon the availability of post at that stage. No separate
notification will be issued for it. The Institute reserves the right to fill or not to fill any or all the
posts advertised.
Candidates possessing the requisite qualification and experience may submit their Application
(Five Copies) on the prescribed form downloaded from Institute’s official website
<www.iiswbm.edu> to
The Director, Indian Institute of Social Welfare and Business management (IISWBM)
Management House, College Square West, Kolkata 700073
AND
Email to: kma_director@iiswbm.edu
The candidates applying from Government organizations and Public Sector undertaking should
have their application duly forwarded by their present employer. Applicants desiring to apply more
than one discipline should send separate application for each discipline.
The envelope containing application should bear the Advertisement No. and the name of the
position. The applicant must state on the top of the first page of the applicant’s Email address and
Mobile number to enable the Institute to contact them at short notice.
Any legal proceedings in respect of any matter of claim or dispute arising out of this advertisement
and / or an application in response thereto can be instituted only in Kolkata and
courts/tribunals/forums at Kolkata only shall have sole and exclusive jurisdiction to try and such
cause /dispute.
Last date of Applications: The application must reach on or before April 17, 2026.

Download Application Form
