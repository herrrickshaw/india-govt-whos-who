---
doc_id: "2a352bcd04dfdfe1"
source_url: "https://www.darahwb.org/upload/actsrules/actsrules_4.pdf"
ministry: "Animal Resources Development Department, West Bengal"
title: ""
date: ""
pages: 2
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "996101afac93c44b"
---

<!-- page 1 -->

The West Bengal Animal Shaughtgr Control Rules, 1950. AO 4 (as
15. These rules may be called the Wet Bengal Animal Slaughter a 4 |
Control Rules, 1950. A 7!
2. Application for certificate Applications from persons for”: Bi
obtaining certificates for slaughter of animals’ shall be madé 4
to the Vety.sAssistant Surgoon concerned 41) Form 1 appended to by
these rules. ; ‘ ee
3. Form of cortific -te- The certific:te to be issued to a person 3
to the effect that the animal is fit for slaughter, shall beyin :
. Form II appended to thesa rulas and shall be valid tall thesday: 5)
: following the date of issues তা
4, Fee for certificate A fee of rupee one per animal shall be paid"
4 non-judicial stomps and shall be filed before the cartificate’t
3 issued. es
5, | Place for slaughter of animale- No animal in respect of which a “i
cortific to has bean issued shall be slaughtered -at a place: othortt
than the municipal slaughter house maintained by the Conmis'sionerg
. of a municipality within the municipal ‘areas ০003700৭১20 4
6. . Branding of animals fit for slaughter- Thé animals cortifldd . A
to be fit for slaughter shall be branded and no animal unless 9০ a
branged shall bo allowed to enter the slaughter houses © . 71 a
Te Conditions subject ta which exemption may, be gen ০০ The provic}
sions of tha West Bengal Animal Slauyhter Control. Act, 1950 0955 4
Bengal Act XXId of 1950) shall not apply ‘to the laughter ofany
animals for religious, medicinalor research purposes subject to.
the condition that such slaughter does not affect the religtous 1
. sentiment of the neighbours of the person or persons perfeming. ¢
: such slaughter and that the previous pormiession: of: the Stata 7) -
\ Govt. or any officer authorised by it 18 obtaindd before, the} —
“" Slaughter. রি তি তি না
8. Control of slaughtor of animals by ৬০৮৮9640978 and Vetye 7) 4
Assistant Sugeons- Vety. Officers ‘and Vety. Assistant Surgédns 4
shu shall attend slaughter houses to control the ca ler of animalss ।
undex the authority given in 01511591081 by tho Dbkrector of Wet Ye: '
: Services, West Bengal, respectively, in‘Forms III‘ and IV appended | 1
2 Wea 985৪ Pp : 8১
্ to thege rules. : Be এটি
9, Submission of fortnightly statement relating to ৪807১22২১77,
of animals, ~ The Votye Asstt. Surgoon attending a slaughtet: \ 7
: house shall submit to the Director of VetysServicas, এ forte, \ |
nightly statement tn Form V appended to these rules during: 4 |
: the next fortnight showing tho number of certificates 4৩ 9১96... 4 |
for slaughtering animals at that slaughtor house during thas, ; x |
previous fortnight. ; ee ees \ |

<!-- page 2 -->

- “ew পু

৪03) Vhore 11122 Le a difference of opinion botveen the mur A ;
of a municipallty and the Veterinary Assistant Surgeon as to the
issuo of a certificate under Sub-Soection (2), tho mattor shall be
[ধুম to fae yoleninary Officer and a certificate shall be

Ssued or refused according as the Veterinery Officer ts of opinion
that the animal fs fit to be slaughtered or ts not so itt: | :
; (4) are under sub-section(3) a certiffeate ig issued" or. refused,
f 9 order granting or refusing the {ssue of the certificate shall
i be signad by the Vaterinary Officer.
1 ‘
(5) Any person aggriaved by the refusal to issue a i (
. ag Sa 5 a certificate unde

. this section may, within fiftoen Jays from the date of ও -
৯1২45 tioh to hin of nuch refusal, appoal to the State Govt., :
against the order of rofusal and the State Govt, may pass .such i
ordors thereon as it thinks (Lt. fy .
(6) The State Govt. may at any time for the purpoke of satis— ॥
fying itself as to the legality or propriety of any action taken
under this section, call for and examine the record of any case, 1
and may pass such orders thereon as it thinks fit. এ. ৮ ‘

. (7) Subject to the provisions of this section any action taken’ 5]
under this aectlon shall be final and shall not be called in pe
questSon 4n any court. é . " . : | i

‘
oe Prohibition of slaughter of animals in places not prescribed ©!
for the puxposo — No animal in respect of which a cortificate has \f
boon 189190 under section 4 shall bo slaughtered tn any place 1
other than a place prescribed Jn this bohalf. ‘t
6. Power to enter and inspect promises ~(1) For the purpose of -
enforcing the provisions of this Act, the Prosident of a munici 1
pality or the Veterinary Assistant Surgeon or ony person, autha H
rised by the Vety.sAssistant Surgeon fn writing in this behalf, |
shall have power to enter and inspect any premises within the H
local limits of his jurisdiction 01016 he has reason to believe H
that an offence under this Act has heen or 15 likely to be H
committed. 4

3 |

(2) Every person in occupation of any spch premises 79 45 spect ¢ }
fied in sub section (1) shall allow the “resident of A munici— |
pality, the Veterin=ry Assictant Surgoon or the person antho- i
rised as tho case may be such access to the promises “s he may |
roquire for the aforosaid purpose, and shat) answer any question i
“put to him by the Prosident of a municipality the Veterinary |
Assistant Surgoon or the parson authorised, as the case moy be, |
to the best of h&s knowledge or belief. |
hie Penalties —- Whoever contravenes dny of the provisions con ‘ay
tainod in this Act shall be punishable with imprisonment for a H
term which may extend to six months, or with fine which may extend 1
to ong thousand rupees, or with both. এ |
\

8, Offences to be cognizable- Notwithstanding anything contained i
in the Code of Criminal Procedure, 1090 (/০৮ V of 1898) ,all offences,
under this Act shall be cognizable.

|
9৯ Abotmonts and attempts= Whoever abets any offence pubishable 1
under this Act or attompts to commit any such offence shall be punts
with the punishment provided in this Act for such’ offences 1
10. Officors exercising powers under this Act deemed to be public |
servants ~ All residents of municipalities, Veterinary Assistant i
Surgeons, Veterinary Officers and other persons exercising powers |
under this fet shall be decmed to be public servants within the i
meaning of section 21 of the Indian Penal Code(Act XLV of 1960). 1
|
|
i
