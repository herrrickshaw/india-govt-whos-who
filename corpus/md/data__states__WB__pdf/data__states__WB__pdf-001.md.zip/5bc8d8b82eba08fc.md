---
doc_id: "5bc8d8b82eba08fc"
source_url: "https://wbsldc.in/uploads/files/57.pdf"
ministry: "State Load Despatch Center (SLDC), Howrah, West Bengal"
title: "Procedure, Terms and Conditions for grant of Transmission Licence and other related matters (Amendment) Regulations 2010"
date: ""
pages: 2
method: "tesseract:ben+eng"
script: "BENGALI"
needs_ocr: false
sha1: "6360197356e2bd0d"
---

<!-- page 1 -->

‘ হিজরী Wo Bo হুল-33004/99 ~REGD, NO. D. £:-3300499
15 Gazette of India
arerercor
EXTRAORDINARY
sm ao ক
PART Ul—Seetion 4
সামিক্দাত & সক্দাহান
| PUBLISHED BYAUTHORITY
| 4% 145] _. সু বিজলী, gear, WE 26, 2010/78 5, 1932 oe
No, 1451 NEW DELHI, WEDNESDAY, MAY 26, 2010/JYAISTHA 5, 1932
ata fiega faba জামী wy ae far জল অনুবদিলাতী 25 অর্থ et আইপি srafy
ag বিজ্ঞ, 25 HE, 2010 arin ওঘশীবলা আ অলবা & ভিন ক্ষা মাছি কলে জী fam ইজ
আম. হল-7/1650180)/2098-জঁতিনিআা.__কীরীয faye | Peer od কহ অনা যা Oe হী মলা অনা জী ae ate
শিলিান্ক জাবীম, firga afer, 2003 (2003 কা 36) ফী. আহিবনী ক্ষ সন্মান জী লিহ sad sect জীনলক্কাল কী হীন আগ
খায় 178 কী আমীন অব wierd dar ga লিমিল ae ore কী fare জানহযন্ত at ।
ameter utara a সমীন ad ভু, নথা yd সন্কাহান a (3) জন্তা ঘাইসগ saferal লী thew ক্কা samen অমিলিঘন
Tear dita লিম্বুন লিলিযামক্ক আলীম Catan আনুজছি সবান. জী ঘা 62 আঁ sata onan gro কিঘা যা ই আভা 25 ad at
So জী ক্যা, freer অগা wd ললা জন্য afte লাললী) অনঘি ক are teh oneal ইমা sae তম মনন জাদু
জিপিমন, 2009 (জি হর কমল ewes weeny “দুল নিলি. ইবি শিলিযসী জট আনুজাহ fier আহা ।
wer যা ই) কযা জং deters কলে ন্ট লিহ লিজিত্তিন লিনিষন (4) Sef হন জিনিযনা at অপ্রিফৃ্লা a ata কী অমিলিযন
মনানা উট rai ait ঘা 63 & মীন সলিফঘ্থা diet ্ট omer মং ঘহিখীজনা fare
1. অধিনে সাদ wer সামেস.--01) উল শ্রিলিষমী জা ‘Sree কষা orgy fear মতা et যা অহিযীজলাহ হী মহ ভা, অহা অনুজ
firs সাল ala faye লিনিযানন arin Cora agate জী জারিক্ক অসি ক নার det মাংস আবিব্ী ক Sg কা
হাল কলে কী wf, লিঘঘল cen হান wen অন্য জনমমিল ara) অনধারগে লিল্ললিত্তিন unless মিত্তানী কট আলুলায fear আহা :
ম্নেহীঘল) নিলিঘল, 2010 8 । (i) ছিল আলি কজিনতী কী dam, শট লি, det আগা
(2) বমিলিষন wera 4 ware কী আাহীভ্র a সনু et | আমীম প্রায় স্জালান আন্র ss জাঘীল we BU, জুল weiss
2, farm 15 er অ্ীঘল,_দুল নিলিমন কট fate 30% মা 25 ae জী Boni Wt ভুলনঘস জী আানুলাং অিসীত্রনা
13 ক জান ঘং, Preafefed var sem, জানি — W frdfirs জাঙবলিক্ dfs, জী শী জম ভী, wah;
“93, onpaftr et আ্রমি---(1) খাতা srqafta, qa Gi) জন্ম fata লগা লক্ষলীল্দী অনিষম, sei fied জান eect,
we অন্যথা ued ্রলিমন্তৰ ল কী oe, at নে at FUR সাজ, SUS হস ae, জ্ঞাকজে Yt We কাজ, লঙ্য
ate 3 25 অর্থ কী জমি ক লিহ সনু কী | ওজ্খলা, সন্তান আবি বং sa arf, জিজনী সবুজ et
(2) যতি te orem আজিব, জিলন্ট লিহ ota আনুহাছি আরশি safe cura a wi জী, জী tem অমিমার্জী উবিক্
জী at মই, an suck জীললক্যাল 25 অর্থ at অনি ক মা লিমা ক আঘাহ মং fre কিমা আহ্মা।
frenfis fren জানা 8 লী ara ua জীং orate জী fare aga (3) সলিজ্মঘা শালী a aren 8 festa কিহ আৰ are
অহান wea ক গ্রীক WAS অং MPT আমা we লিলা aK যী ari ঘহিতীঅনাওী ঈ লিহ, মীলীক্ঘাঁজী জট fer afore
Fant জিম fag sateen অনুষট্বি at onfirs আমি কী. সঙ্গাজল at ante a 35 অর্থ aw Site বাদী aie fea আসা
arta ক হী অর্ধ od জিলিঘল 7 লী oem odes কব জলীনা : অন ten fire অং steht Yeates কী লিহ fran কিনা orem:
2011 GI/2010 (1)

<!-- page 2 -->

2 THE GAZETTE OF INDIA: EXTRAORDINARY. (Parrl—Sec.4] og
wa we fe সহি হন জীহ aati F অনুষদি সহগাল at Provided that when the licensee does not make an
জানী ই লী 35 ad ae লিজলাহিত stafiy জী লিহ Sher ate অহ application for grant oflicence beyond the initial period of a
৯ অনঘিন at নী fore আঁ সাং * যা ATT । ; or formulate such schemes as it may deem necessary for
(6) af হল নিলিবল S We (4) war (5) F আন নাল operation of the transmission assets for the remaining part
Tem আনুজদিঘাধী, arqaita vi জার্সি orate নী aver ofits useful life.
Te wre er aaron car আঘুলিকীন্দতো ay ক্ধলে BT (3) Where the tariff of the transmission assets has
নিলিহলব area 2 লী ae লহ agate সবান eel & লিছ andar been determined by the Commission under Section 62 of
qa লর্রীক্ীয না amyfrataren ara জী অনুমীহ্ন নস 0৩ Act nw fer Such assets beyond the period of *
, 5 ্ অঙ্গার জলিঘলী হী years shall be determined in accordance with the tari
লি না ir Ke লাম অপিগানী a regulations applicable at that point of time.
অন্তুজাং TTA TAT ATT | (4) Where the Request for Proposal (RFPs) for the
ares Gan, অনিল projects have been issued or the projects have been = *
[নিযাদন 171/4/150/2010-তাজা.] awarded on the basis of competitive bidding under Section 7
fea : মুল fafran, ana 8 যাজঘস, star, WeT 94 63 ofthe Acton the date of notification of these regulations,
ক শামা, GS [৬ লী 26 AE, 2009 ক্ধী সকাল কিছ the tariff of such transmission assets beyond the initial
7 “~™ period of licence shall be determined in accordance with
me the following guidelines :
CENTRAL ELECTRICITY REGULATORY ()  Eor computation of Return on Equity, equity base shall
COMMISSION রি be 30% of the Gross Block or the actual equity invested
NOT IFICATION in the project as per balance sheet as at the end of 25th
New Delhi, the 25th May, 2016 year whichever is lower, subject to prudence check by
No. L-7/165(180)/2008-CERC.—In exercise of the Commission;
ey conrad under Section 178 এ) চা (i) Other financial and technical norms i.e. Return on
2067 and alt other powers enabling it in this behalf, an Equity, Interest on Loan, O & M Expenses, Interest on
after previous publication, the Central Electricity Regulatory working capital, target availability, incentive ete, shall
Commission hereby makes the following regulations, to be considered on the basis of norms of tariff prevalent
05 রাত সভা during the period in which the initial period of licence
cedure, Terms 2 tions for 90195 is due to expire,
Licence and other related matters) Regulation, 2009, (5) For all future projects to be developed through
bereinafer referred to as “the principal regulations”, rapetitive bidding, the bidders shall be required to quote
id Short tite and te{1) Th the tariffup to 35th year from date of commercial operation
৮ ort title and commencement.— 1038 i 7 7 j
which shall be considered for bid evaluation :
regulations may be called the Central Electricity Regulatory Provided that in case the licence is granted for
Commission (Procedure, Terms and Conditions for grant 9 চর ৪ ও 20
of Transmission Licence and other related matters) another term, the tariff for the extended period up to 35th,
(Amendment) Regulations 2010 year shall be payable on the basis of the rate quoted at the
“ (2) These regulations shall come into force with effect bidding and adopted by the Commission for the respective
“ ‘ year of operation.
from the date of their publication in the Official Gazette. , ia . :
2, Amendment of Regulation 13.— Regulation 13 of (6) In case the ransntiss:on licensee covered under
the principal regulations shall be substituted as under, clauses @ and (5) of this regulation decides to undertake
lye renovation and modernization of the transmission system
namely: . . রা afier the initial period of licence, it shall make an application
13. Term of Licence.-(1) The transmission licence for approval of the cost of renovation and modernization
shall, unless revoked carlier, continue to be in force for a along with the application for grant of fresh licence, which
period of 25 years from the date of issue, . shall be considered by the Commission in accordance with
(2) If the useful life of the transmission asset for the prevalent norms,”
which transmission licence has been issued extends ALOK KUMAR, Secy
beyond the period of 25 years, the Commission may ADVT tL / 1502010 এ
consider on merit of each case to grant licence for another . . 1 ADVTHV/4/150/2010-Exty.]
term for which the licensee may make an application in Note: The principal regulations were published on
accordance with Regulation 7 two years before the expiry 26th May, 2009 Part Ill, Section 4 of the Gazette of
| of the initial period of licence. India, Extraordinary No, 94. _
| ~~" printed by the Manager, Government of India Press, Ring Road, Mayapari, New Deihi-ti0064 -
and Published by the Controller of Publications, Delhi-1 10054.
