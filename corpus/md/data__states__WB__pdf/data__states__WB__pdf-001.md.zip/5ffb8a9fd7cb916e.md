---
doc_id: "5ffb8a9fd7cb916e"
source_url: "https://wbuhs.ac.in/wp-content/uploads/2026/10/Notification-of-PhD-Annual-Seminer-2026.pdf"
ministry: "The West Bengal University of Health Sciences, West Bengal"
title: "Notification for PhD Annual Seminar 2026  new"
date: ""
pages: 2
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "b4d2b03daf586e7e"
---

<!-- page 1 -->

pee THE WEST BENGAL UNIVERSITY OF HEALTH SCIENCES
s “es 3 DD-36, Sector-I, Salt Lake, Kolkata 700 064
a e pI Website: www.wbuhs.ac.in
“tee Phone (EPBX): 2321-3461 Fax:2358-0100
—————
Memo No. : WBUHS/Dean/2026/0 4.59 Date: 4 - fo .2026
NOTIFICATION
(Annual Seminar Schedule for PhD Scholars)
As directed by the competent authority, the following PhD scholars are hereby informed
that the Annual Seminar of the PhD program will be conducted as per the schedule mentioned below:
MAUMITA DAS FACULTY OF MODERN 23.11.2026
MEDICINE (Monday)
রা তা
1 31 NABANITA CHAKRABORTY [Dow [Dow
__4.|  DEBDUTTAHALDAR [Dow Doe
| 5] 874২39173১০ Do
6.1. WRITTIKACHATTARAT [Dow Doe
L_8.[ SATABDIMITRA [Dow Doe
1971 SUKANTI BHATTACHARYYA 7১০ 2৮
| 10 টিটি ০ Cth)
HEALTH CARE (Thursday)
1] 11. ADRWADASBISWAS | Dow Do
| 12.) SUDIPABASU [Doe Dow
[13 70২5813/3 Doe 7১০
ৃ
[NDA Wve
| 161 OINDRILAPAUL [Don ০
(Monday)
|__18[ANINDITADAS 7১০ 1] 4১০
|__19.|SUNETRAMONDAL [Dow Doe
|__20.| _NABANITASINHA 770০ 1] 4১০1
1] 21. _INDRANIBANERJEE [Dow Dow
[221 IPSITABAGCHT [Doe Doe
| 23.) MALABHOWMIK 13১০0 Dow
| 24) NABANITASAHU 77১০1 3১০1
pas] NN at
1 (Thursday)
|__26.| __TANUSREEBISWAS [Dow 1 4১০
| 27] RANJITAMITRA [Dow 3১০]
| 28 ANTARAROY [Dow 11 4১০ 7
|_29.|_BARNALIMUKHERJEE 7১০1 Doe
|__30.|___SHUKLABANERJEEDEY 7 7১০ 1 Doe
|__31.| DEBAYAN BANDYAPADHYAY | FACULTY OF AYURVED | -Do- |
|__32|ARPITASARKAR [Dow | Do
সং টিসি পি 1 ।
SCIENCES
PT. 0.
1|

<!-- page 2 -->

All concerned candidates are directed to take careful note of the following instructions:
e Reporting Time: 11:30 AM
e Venue: Meeting Room, WBUHS
e Mode of Presentation: Oral with PowerPoint Presentation (PPT)
(Candidates must carry a soft copy of their presentation.)
e Duration of Presentation: 12 minutes
e Discussion Time: 8 minutes (immediately following presentation)
e All supervisors of the concerned candidates are earnestly requested to attend the seminar.
Candidates are further instructed to:
e Bring all duly authenticated Half-Yearly Progress Reports and the Research Proposal during the annual
seminar.
e Note that requests for change in the date of presentation will not be entertained under any
circumstances.
e Be informed that PhD regulations will be strictly applicable in case of failure to present during the
scheduled seminar.
e Candidate will have to submit the requisite fee for annual seminar as applicable for PhD
Regulation,2023
All the aforementioned PhD scholars are earnestly requested to ensure their presence at the annual seminar as
per the scheduled date and time.
. 10.
oe CF, 1.7 «| ( [2
৬
x ‘SS ০ 5, DeaPean, WBUHS
a/ “Qs i Faculty of Modern Medicine
«| চি ky The West Bengal University of Health Sciences
৮১ র্‌
১
১5292
9৩
ul g
