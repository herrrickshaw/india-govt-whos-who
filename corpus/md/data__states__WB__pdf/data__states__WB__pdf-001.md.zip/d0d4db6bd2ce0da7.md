---
doc_id: "d0d4db6bd2ce0da7"
source_url: "https://wbiidc.wb.gov.in/assets/eodb/scan0876.pdf"
ministry: "West Bengal Industrial Infrastructure Development Corporation (WBIIDC), West Bengal"
title: "Notification"
date: ""
pages: 1
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "30b5ca7a146a9c36"
---

<!-- page 1 -->

B 033 2334 5806 / 5807
e-mail : wbiidc.ho@gmail.com
Website : wbiidc.wb.gov.in
VN West Bengal Industrial Infrastructure Development Corporation
C . (Established under West Bengal Act XXV of 1974)
Woy, Block DJ, Plot No. 10, Sector II, Salt Lake City, Kolkata 700.091
No: Infra /Accounts/e-Office /IE-2/2021/1002 Date: 15/05/2024
Notice
Implementation of eOffice in West Bengal Industrial
Infrastructure Development Corporation
All the employees of WBIIDC are hereby notified that the West Bengal
Industrial Infrastructure Development Corporation is starting towards
paperless workplace to facilitate efficiency and transparency in the governance.
With these objectives in mind, the Corporation has decided to adopt eOffice to
achieve the aim of creating a digital office. For the interest of this corporation
eOffice has been started from 21.05.2024
Chief MW
WBIIDC
