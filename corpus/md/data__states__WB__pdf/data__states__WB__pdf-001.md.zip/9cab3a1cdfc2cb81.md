---
doc_id: "9cab3a1cdfc2cb81"
source_url: "https://www.wbsschelpdesk.com/info/downloads/tendernotice/WBCSSC_AT_information.pdf"
ministry: "West Bengal Central School Service Commission, West Bengal"
title: "Information regarding recruitment to the post of Assistant Teachers in Secondary and Higher Secondary Schools ..."
date: ""
pages: 1
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "ce273e032e21d4ac"
---

<!-- page 1 -->

০51 ACHARYA SADAN:
ew 11 & 11/1, Block-EE, Salt Lake: Kolkata-700091
NOTICE
(Sub: Information in respect of recruitment to the post of Assistant Teachers of
Secondary and Higher Secondary Schools)

Memo, No. 561/6982/CSSC/ESTT/2022 Dated: 05.05.2022 &
It is hereby notified for the information of all concerned the West Bengal Central
School Service Commission will soon issue an advertisement for recruitment to the post
of Assistant Teachers in Secondary and Higher Secondary schools. All the relevant
details regarding the selection process, viz; the application submission mode and dates,
Application fees, mode of payment of Application fees, date of the written test, method
of the written examination to be conducted; the counseling process and tentative number
of vacancies etc. will be given in the advertisement. 29

০৩৪25
WB Central School Service Commission
