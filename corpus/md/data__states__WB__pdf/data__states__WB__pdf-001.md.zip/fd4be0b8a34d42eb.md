---
doc_id: "fd4be0b8a34d42eb"
source_url: "https://www.bankurauniv.ac.in/uploads/tempimagepdflink/1778231340.pdf"
ministry: "Bankura University, West Bengal"
title: "Notification regarding verification of Scholarships under the purview of SVMCM Portal, Aikyashree Portal and OASIS Portal"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5cec42b9d24020ae"
---

<!-- page 1 -->

BANKURA UNIVERSITY
(West Bengal Act XIX of 2013- Bankura University Act, 2013)
Main Campus, Bankura Block-II, P.O.: Purandarpur,
Dist.: Bankura, Pin- 722155, West Bengal

Office of the System Administrator
…………………………………………………………………………………………………………………………………………………………….

SA/BKU/003/2026

07.05.2026

Notification
This is to notify that students who are applying for Scholarship (Scholarships under the purview
of SVMCM Portal, Aikyashree Portal and OASIS Portal) are directed to submit the filled
in application form along with all relevant documents to the Scholarship Section,
Administrative Building for Institution Level Verification as per the schedule mentioned
below:
Name of the Department
Bengali, Chemistry
English, Education
History, Law
Mathematics, Physics
Philosophy, Political Science
Santali, Sanskrit
Social Work, Pending if any
Integrated B. Lib. I. Sc. - M. Lib. I.
Sc. and Journalism and Mass
Communication

Date
12.05.2026,13.05.2026 and
14.05.2026
15.05.2026, 18.05.2026 and
19.05.2026
20.05.2026, 21.05.2026 and
22.05.2026
25.05.2026, 28.05.2026 and
29.05.2026
01.06.2026 and 02.06.2026
03.06.2026, 04.06.2026 and
05.06.2026
08.06.2026 and 09.06.2026

Time

11 AM to 2 PM
&
2.30 PM to 4.30 PM

10.06.2026 and 11.06.2026

The students should provide a self-declaration that they are not receiving any other scholarship
from any other source in their application to be forwarded by the HOD/TIC of the department
concerned.
Please ignore the above notification if Institution Level Verification is already completed.
Sd/System Administrator &
Nodal Officer, Scholarships
Copy forwarded for information and necessary action to:
1. All the Officers of Bankura University;
2. All the HODs/TICs of the Academic Departments of Bankura University
3. Secretary to Vice Chancellor, Bankura University;
4. Office notice board;
5. Guard file;
Sd/System Administrator &
Nodal Officer, Scholarships
