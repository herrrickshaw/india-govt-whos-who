---
doc_id: "a6f8bd8fb0a2f54e"
source_url: "https://gcect.ac.in/download/Miscellaneous/MTech2026-Spot-Decentralized-Admission-Corrigendum_26092026.pdf"
ministry: "Government College of Engineering & Ceramic Technology (GCE&CT), Kolkata, West Bengal"
title: "View Notice"
date: ""
pages: 1
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "495178fbb0dfb3c1"
---

<!-- page 1 -->

REG Government of West Bengal
1 Government College of Engineering & Ceramic Technology
10110 AN AUTONOMOUS INSTITUTE UNDER M.A.K.A.U.T.
১07 73, Abinash Chandra Banerjee Lane, Kolkata-700010
Trea অভ URL: Www. gcect.ac.in E-Mail: geectwb@gmail.com
a উরু ২২২ ২.২, শু ক
Corrigendum
Procedure for M.Tech Spot / Decentralised Counselling and Admission — 2026 (Academic Session
2026-27)
In partial modification of the previous notice regarding M.Tech Spot / Decentralised Counselling and
Admission — 2026, it is hereby informed that, due to an inadvertent typographical error, the number of
vacant seats was incorrectly mentioned.
The correct category-wise vacant seat position is given below:
ix cho Jug —
Principal 26 69-26
Principal
11999 of Engineering
ও Technology
Kolkata-700010
৫৯ Govt. of West Ben
/%9২৯২
3 Ba N%
Sf Re NZ
২০ Cou. of =
Qe NY 8৪৫ ZS,
১৫৭ মা vA
Principal's Office: 033-2370-1264 Registrar’s Office: 033-2363-2072 Accounts Section: 033-2363-3674
FAX: 033-2363-2072
