---
doc_id: "038a9f0ee83efbcd"
source_url: "https://home.wb.gov.in/public/uploads/notices/2026/notice_84_20260720.pdf"
ministry: "Home and Hill Affairs Department, West Bengal"
title: "Repartriation order for 49 Police personnel"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "994ced7042afc807"
---

<!-- page 1 -->

GOVERNMENT OF WEST BENGAL

/

Home & Hill Affairs Department
Police Establishm ent Branch
Nabanna. Howrah-711 102

Dated, 17.07.2026

No.1820-P L/PB/14M -49/2014
From : Senior Special Secretary
to the Governmen t of West Bengal
To

: 1) The Director General & Inspector General of Police
Bhawaru Bhaban, Alipore, Kolkata-700027.
2) The Commissioner of Police, Kolkata
18, Lalbazar St. Kolkata-700001

Sub.- Repatriation of 49(forty nine) police personnel from West Bengal Police to their parent unit under
Kolkata Police.
Ref.(i) Memo No.647 / CRO dt. 13.05.2026 of KP
(ii) Memo No.275/Per s-I dt. 16.06.2026 of WBPD
With reference to the above the undersigned is directed to state that the proposal of Kolkata Police
(Niemo No.647 / CRO dt. 13.05.2026) for repatriation of 66(sixty-six) police personnel of KP who have been
working at different units under WBP on deputation since long, was under active considerati on of this
Department.
After careful consideration of the matter, the Governor is pleased to accord approval for
2.
repatriation of the following 49(forty nine) police personnel of Kolkata Police out of 66(sixty-six) police
personnel under deputation in various units of WBP to their respective parent units under K olkata Police as per
list given below:
SI.
No

Rank

Present Unit
under KP where
to be repatriated

Present place of posting on
Deputation under WBP

Name

GLNo

( 6_) ___
~ ( 1) --- ------ (2) ______.f--(-'-'3)_1-------------------------(4) ------------------------- ------------- -------------"-(5_):__ __ _ _-+__________
_ _ _~
RF

(I_N.c-)-a--"-----~------1---A_C__:_
Jnsp (IN)
2
lnsp (IN)
3
lnsp (JNf4
Insp (IN)
5

_____Jayanta Chakraborty__ __________________ ____________________ Darjee Iing __________________

SVSPA, Barrackpore
-Dib-c°Mtt), Uttardinajpur
Dib, Barasat Pd
ADPC

Mani Sankar Mazumder
Papindar Singh Randhawa
Alex Manish Kandulna
Goutam Halder

-

SCO
_ _ _~
_ H_G_O
DD
- SB________ -

l~~~,B~~c-= :=:=~-- :---- :~~------~~Y.Y.~- -- -- - ----_ _ _ _ :_:-:A~~,
~;~:;~~
~;
~
~~~;
-----{~;;~~~
~----_
----~--SB
----.
Birbhum
Sinha
Amit
__ SI

-~~~I~- si1
-_-__4_ -----~--~- ~ -~ _-__.__~-~-__ -~_,_
---Ts---·--A

16
17

___L~---

18882 Prabir Manna
ASI
3246"-- ·-s~umen Hore
CONST
- ~g-~~~ ---!i?_'-~----:~a~kar--Das

-~i-- ~{~t:;-- ~}}~;- _'_

---------------------- ----- --------------- -- AD Pc

SWD

-------------------Bi-~bh~~~------------- ---- ----------TP

----------------------------- Darjeeling

-----------------------,-------------------Maida___ _____

2nd BN

I

ss

--,

------------:::::::::::::~~l~~:::::::::::::::::::::·:1:J ::=::===:~J?---------------

:~:::~u~:I Das-------------------------,'
TP
ADPC
....-- ~ ----------- --------~- - - -----·-r-··--------------jaJpai"g~-~j-------------- -------]st BN
--~_(_____~_9-_NST ______I 8054 __ 1__Krish~a-~ada Mudi
,-st BN
Ashok Kumar Dara·-----------------r 1sia;;p-~~-r"6Tr iischT~--Medinipur /
514
22
CONST

I

%~~

,
1

Contd ....

<!-- page 2 -->

7

-2-

- - --

'

-

- ~ --

=: - - - - ~
/i 'Is l!..r -Ra;;;n;-i;k: -fcci:L'iiN~o~ - - -~Nam
Present place of posting on
e
No

Deputation under WBP

/

al
---4T---CONST___ 7466 Dibye ndu Ghos
------al
Mond
~I
--Rah
I
--68T
___
NST
---44____ ---CO
___4_5____--co~is-r ----8052 Biswaj it Howly

-r-- ;:= :::: -~~ 7
Present Unit
under KP where
to be repatriated

Jalpaiguri
Jalpaiguri,

!________
- ----1------: _~9_-~-~~
BAT

Darjeeling

COMBAT ---

COM

Raiganj Pd______________________________COM BAT _____ -Bi man Roy
2772
COMBAT
Jhargram
5650 -- Rajkumar Halder
47
COMBAT
Purulia
Sagar Biswas
4694
- - - --- -------------------------.-----CONST
---·48
------------------------·
-------------------------------COMBAT
-·----------------Bankura
·/- - - -- --- ------------ --------Asim Kumar Haldar
I770
P/DR
49

~ 46

CONST
CONST

.

) police
release the afore men tione d 49(forty nine
The DG & IG P is here by requested to
ata Polic e.
to enab le them to join their pare nt unit, of Kolk
perso nnel from the resp ective units unde r WBP
po lice
to issue posting orde r in resp ect of thos e
Com miss ione r of Kolkata Police is requested
4.
personnel in the corre spon ding ranks.
3.

5.

This orde r is issued in the interest of public

auth
service with the ap pro ~e com pete nt

,

,nd it will rake imm edi,i e effect.

ority

J~.g,il,}f '11.

Seni or Special Secretary
to the Gov ernment of Wes t Beng al

D ated, 17.07.2026

No.1820/1(5)-PL/PB/14M-49 /201 4
Copy forwarded for information and necessary
1.
2.
3.
4.
5.

actio n:

Principle Acco unta nt General(A&E), WB
Inspecto r General o f Police(Personnel), WB
WB
Dep uty Inspector Gen eral of Police,(A dmn ),
a Police
Join t Commiss ioner of Police, (Hqr.) K olkat
t.
PS to Principle Secretary o f this D epar tmen

Seci1 ~iel;try

to the GO\-cmm ent o f \XIest Beng:il
