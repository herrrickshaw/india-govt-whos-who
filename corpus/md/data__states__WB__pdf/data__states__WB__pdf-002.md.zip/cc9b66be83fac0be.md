---
doc_id: "cc9b66be83fac0be"
source_url: "https://wberc.gov.in/sites/default/files/The%20Electricity%20Rules%202005.pdf"
ministry: "West Bengal Electricity Regulatory Commission (WBERC), West Bengal"
title: "View More"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5aaa170af0da4d1b"
---

<!-- page 1 -->

(Published in Part II, Section 3, Sub-section (i) of the Gazette of India, Extraordinary )
GOVERNMENT OF INDIA
MINISTRY OF POWER
New Delhi, the 8th, June, 2005
NOTIFICATION
G.S.R. 379(E). - In exercise of powers conferred by section 176 of the Electricity Act,
2003 (Act 36 of 2003), the Central Government hereby makes the following rules,
namely:1.

Short title and commencement.(1)
(2)

2.

These rules shall be called the Electricity Rules,
2005.
These Rules shall come into force on the date of
their publication in the Official Gazette.

Definitions.In these rules, unless the context otherwise, requires:

3.

(a)

“Act” means the Electricity Act, 2003;

(b)

the words and expressions used and not defined herein but defined in the
Act shall have the meaning assigned to them in the Act.

Requirements of Captive Generating Plant.(1)
No power plant shall qualify as a ‘captive generating plant’ under section
9 read with clause (8) of section 2 of the Act unless(a)

in case of a power plant (i) not less than twenty six percent of the ownership is held by the captive
user(s), and
(ii) not less than fifty one percent of the aggregate electricity generated in
such plant, determined on an annual basis, is consumed for the captive
use:
Provided that in case of power plant set up by registered
cooperative society, the conditions mentioned under paragraphs at (i)
and (ii) above shall be satisfied collectively by the members of the cooperative society:

<!-- page 2 -->

Provided further that in case of association of persons, the
captive user(s) shall hold not less than twenty six percent of the
ownership of the plant in aggregate and such captive user(s) shall
consume not less than fifty one percent of the electricity generated,
determined on an annual basis, in proportion to their shares in
ownership of the power plant within a variation not exceeding ten
percent;
(b)
in case of a generating station owned by a company formed as special
purpose vehicle for such generating station, a unit or units of such generating
station identified for captive use and not the entire generating station satisfy (s)
the conditions contained in paragraphs (i) and (ii) of sub-clause (a) above
including Explanation :(1)
The electricity required to be consumed by captive users shall be
determined with reference to such generating unit or units in
aggregate identified for captive use and not with reference to
generating station as a whole; and
(2)
the equity shares to be held by the captive user(s) in the generating
station shall not be less than twenty six per cent of the proportionate of the
equity of the company related to the generating unit or units identified as
the captive generating plant.
Illustration: In a generating station with two units of 50 MW each namely
Units A and B, one unit of 50 MW namely Unit A may be identified as the
Captive Generating Plant. The captive users shall hold not less than
thirteen percent of the equity shares in the company (being the twenty six
percent proportionate to Unit A of 50 MW) and not less than fifty one
percent of the electricity generated in Unit A determined on an annual
basis is to be consumed by the captive users.
(2) It shall be the obligation of the captive users to ensure that the consumption
by the Captive Users at the percentages mentioned in sub-clauses (a) and (b) of
sub-rule (1) above is maintained and in case the minimum percentage of captive
use is not complied with in any year, the entire electricity generated shall be
treated as if it is a supply of electricity by a generating company.
Explanation.- (1) For the purpose of this rule.a. “Annual Basis” shall be determined based on a financial year;
b. “Captive User” shall mean the end user of the electricity
generated in a Captive Generating Plant and the term “Captive
Use” shall be construed accordingly;

<!-- page 3 -->

c. “Ownership” in relation to a generating station or power plant
set up by a company or any other body corporate shall mean
the equity share capital with voting rights. In other cases
ownership shall mean proprietary interest and control over the
generating station or power plant;
d. “Special Purpose Vehicle” shall mean a legal entity owning,
operating and maintaining a generating station and with no
other business or activity to be engaged in by the legal entity.
4.
Distribution System.- The distribution system of a distribution licensee in terms
of sub-section (19) of section 2 of the Act shall also include electric line, sub-station and
electrical plant that are primarily maintained for the purpose of distributing electricity in
the area of supply of such distribution licensee notwithstanding that such line, substation or electrical plant are high pressure cables or overhead lines or associated with
such high pressure cables or overhead lines; or used incidentally for the purposes of
transmitting electricity for others.
5.

Compliance with the directions by Transmission Licensee.-

(1)
The National Load Despatch Centre, Regional Load Despatch Centre, as the case
may be, or the State Load Despatch Centre, may, under section 26, sub-section (3) of
section 28, sub-section (1) of section 29, sub-section (2) of section 32 and sub-section (1)
of section 33 read with clause (b) of section 40 of the Act, give such directions, as it may
consider appropriate for maintaining the availability of the transmission system of a
Transmission Licensee and the Transmission Licensee shall duly comply with all such
directions.
(2) The Appropriate Commission, on an application filed by the National Load
Despatch Centre, the Regional Load Despatch Centre or the State Load Despatch Centre
and after hearing the Transmission Licensee, if satisfied that the Transmission Licensee
has persistently failed to maintain the availability of the transmission system, may issue
such directions to the National Load Despatch Centre, the Regional Load Despatch
Centre or the State Load Despatch Centre to take control of the operations of the
transmission system of such Transmission Licensee for such period and on such terms,
as the Commission may decide.
(3) The direction under sub-rules (1) and (2) above shall be without prejudice to any
other action which may be taken against the Transmission Licensee under other
provisions of the Act.
6.
The surcharge under section 38 : The surcharge on transmission charges under
section 38, the manner of progressive reduction of such surcharge and the manner of
payment and utilization of such surcharge to be specified by the Central Commission
under sub-clause (ii) of clause (d) of sub-section (2) of section 38 shall be in accordance
with surcharge on the charges for wheeling, the manner of progressive reduction of such

<!-- page 4 -->

surcharge and the manner of payment and utilization of such surcharge as may be
specified by the Appropriate Commission of the State in which the consumer is located
under sub-section (2) of section 42 of the Act.
7.

Consumer Redressal Forum and Ombudsman.- (1) The distribution licensee
shall establish a forum for redressal of grievances of consumers under sub-section
(5) of section 42 which shall consist of officers of the licensee.
(2) The Ombudsman to be appointed or designated by the State Commission
under sub-section (6) of section 42 of the Act shall be such person as the State
Commission may decide from time to time.
(3)
The Ombudsman shall consider the representations of the consumers
consistent with the provisions of the Act, the Rules and Regulations made
hereunder or general orders or directions given by the Appropriate Government or
the Appropriate Commission in this regard before settling their grievances.
(4) (a) The Ombudsman shall prepare a report on a six monthly basis giving
details of the nature of the grievances of the consumer dealt by the ombudsman,
the response of the Licensees in the redressal of the grievances and the opinion of
the ombudsman on the Licensee’s compliance of the standards of performance as
specified by the Commission under section 57 of the Act during the preceding six
months.
(b)
The report under sub-clause (a) above shall be forwarded to the State
Commission and the State Government within 45 days after the end of the
relevant period of six months.

8.

Tariffs of generating companies under section 79.- The tariff determined by the
Central Commission for generating companies under clause (a) or (b) of subsection (1) of section 79 of the Act shall not be subject to re-determination by the
State Commission in exercise of functions under clauses (a) or (b) of sub-section
(1) of section 86 of the Act and subject to the above the State Commission may
determine whether a Distribution Licensee in the State should enter into Power
Purchase Agreement or procurement process with such generating companies
based on the tariff determined by the Central Commission.

9.

Inter-State trading Licence.- A licence issued by the Central Commission under
section 14 read with clause (e) of sub-section (1) of section 79 of the Act to an
electricity trader for Inter-State Operations shall also entitle such electricity trader
to undertake purchase of electricity from a seller in a State and resell such
electricity to a buyer in the same State, without the need to take a separate licence
for intra-state trading from the State Commission of such State.

10.

Appeal to the Appellate Tribunal.- In terms of sub-section (2) of section 111
of the Act, the appeal against the orders passed by the adjudicating officer or the

<!-- page 5 -->

appropriate commission after the coming into force of the Act may be filed within
forty-five days from the date, as notified by the Central Government, on which
the Appellate Tribunal comes into operation.
11.

Jurisdiction of the courts.- The Jurisdiction of courts other than the special
courts shall not be barred under sub-section (1) of section 154 till such time the
special court is constituted under sub-section (1) of section 153 of the Act.

12.

Cognizance of the offence- (1) The police shall take cognizance of the offence
punishable under the Act on a complaint in writing made to the police by the
Appropriate Government or the Appropriate Commission or any of their officer
authorized by them in this regard or a Chief Electrical Inspector or an Electrical
Inspector or an authorized officer of Licensee or a Generating Company, as the
case may be.

(2)

The police shall investigate the complaint in accordance with the general law
applicable to the investigation of any complaint. For the purposes of investigation
of the complaint the police shall have all the powers as available under the Code
of Criminal Procedure, 1973.

(3)

The police shall, after investigation, forward the report along with the complaint
filed under sub-clause (1) to the Court for trial under the Act.

(4)

Notwithstanding anything contained in sub-clauses (1), (2) and (3) above, the
complaint for taking cognizance of an offence punishable under the Act may also
be filed by the Appropriate Government or the Appropriate Commission or any of
their officer authorized by them or a Chief Electrical Inspector or an Electrical
Inspector or an authorized officer of Licensee or a Generating Company, as the
case may be directly in the appropriate Court.

(5)

Notwithstanding anything contained in the Code of Criminal Procedure 1973,
every special court may take cognizance of an offence referred to in sections 135
to 139 of the Act without the accused being committed to it for trial.

(6)

The cognizance of the offence under the Act shall not in any way prejudice the
actions under the provisions of the Indian Penal Code.

13.

Issue of Orders and Practice Directions.The Central Government may from time to time issue Orders and practice
directions in regard to the implementation of these rules and matters incidental or
ancillary thereto as the Central Government may consider appropriate.
[F.No. 23/54/2004-R&R]
(Ajay Shankar)

<!-- page 6 -->

Additional Secretary
