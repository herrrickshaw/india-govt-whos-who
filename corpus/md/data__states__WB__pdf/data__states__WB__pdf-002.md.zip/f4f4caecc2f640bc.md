---
doc_id: "f4f4caecc2f640bc"
source_url: "https://cnci.ac.in/backend/public/uploads/2024/11/13/EOI%20for%20empanlment%20of%20firms%20at%20CNCI.pdf"
ministry: "Chittaranjan National Cancer Institute (CNCI)"
title: "Tender File"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "56b86d6d30012123"
---

<!-- page 1 -->

eProcurement System Government of India

Page 1 of 3

eProcurement System Government of India
Tender Details
Date : 24-Oct-2024 12:11 PM
Print

Basic Details
Organisation Chain

Chittaranjan National Cancer Institute - Kolkata

Tender Reference
Number

CNCI/N/SP/282/2024/EMPANEL

Tender ID

2024_CNCI_832221_1

Withdrawal Allowed

Yes

Tender Type

Open Tender

Form of contract

Empanelment

Tender Category

Works

No. of Covers

1

General Technical
Evaluation Allowed

No

ItemWise Technical
Evaluation Allowed

No

Payment Mode

Not Applicable

Is Multi Currency Allowed For
No
BOQ

Is Multi Currency
Allowed For Fee

No

Allow Two Stage Bidding

No

Cover Details, No. Of Covers - 1
Cover No

Cover

Document Type

Description

1

Fee/PreQual/Technical/Finance

.pdf

EOI for empanelment of
firms

Other Important Documents
S.No Category

Sub Category

1

Certificate Details

Permanent Account Number

2
3
4
5

Certificate Details
Certificate Details
Certificate Details
Certificate Details

6

Certificate Details

7

Certificate Details

8

Financial Details

9
10

Purchase Order Details
Purchase Order Details

11

Work Details

Registration Certificate
Income Tax Certificate
Character Certificate
Labour License
Employees State Insurance
Certificate
GST Registration Certificate
Annual Turn over certificates
from CA
Purchase Orders - 1
Purchase Orders - 2
Work Completed Certificate
Copies

Tender Fee Details, [Total Fee in ₹ * - 0.00]
Tender Fee in ₹

0.00

Fee Payable To

Nil

Tender Fee
Exemption
Allowed

No

Fee Payable At

Sub Category Description
Permanent Account Number
Details
Registration Certificate Details
Income Tax Certificate Details
Character Certificate
Labour License
Employees State Insurance
Certificate
GST Registration Certificate
Annual Turn over certificates
from CA
Purchase Orders - 1
Purchase Orders - 2
Work Completed Certificate
Copies

Format/File

EMD Fee Details
EMD Amount in ₹

0.00

EMD Exemption
Allowed

No

EMD Fee Type

fixed

EMD Percentage

NA

EMD Payable To

Nil

EMD Payable At

Nil

Nil

Click to view modification history

Work /Item(s)
Title

Expression of Interest Inviting applications for empanelment at CNCI, Kolkata

https://eprocure.gov.in/eprocure/app?component=%24DirectLink&page=PublishedView...

10/24/2024

<!-- page 2 -->

eProcurement System Government of India

Page 2 of 3

Work Description

Expression of Interest Inviting applications for empanelment at CNCI, Kolkata

Pre Qualification
Details

As per EOI

Independent External NA
Monitor/Remarks
Show Tender Value in No
Public Domain
Tender Value in ₹

0.00

Product Category

Civil Works

Sub category

NA

Contract Type

Empanelment

Bid Validity(Days)

270

Period Of Work(Days) 0

Location

CNCI, Kolkata

Pincode

700160

Pre Bid Meeting Place NA

Pre Bid Meeting
Address

NA

Pre Bid Meeting Date

NA

Bid Opening Place

Should Allow NDA
Tender

No

Allow Preferential
Bidder

No

CNCI, Kolkata

Critical Dates
Publish Date

24-Oct-2024 01:00 PM

Bid Opening Date

19-Nov-2024 01:00 PM

Document Download / Sale Start
Date

24-Oct-2024 01:00 PM

Document Download / Sale End
Date

18-Nov-2024 01:00 PM

Clarification Start Date

NA

Clarification End Date

NA

Bid Submission Start Date

24-Oct-2024 01:00 PM

Bid Submission End Date

18-Nov-2024 01:00 PM

Tender Documents
NIT
Document

S.No
1

Work Item
Documents

Document
Name
Tendernotice_1.pdf

Document
Size (in KB)
989.98

Description
EOI

S.No Document Type

Document Name

Description

1

EOI.pdf

EOI

Tender Documents

Document
Size (in KB)
974.05

Bid Openers List
S.No
1.
2.
3.

Bid Opener Login Id
drsuparna1@gmail.com
dr.sankars@gmail.com
pankaj.s38@gmail.com

Bid Opener Name
SUPARNA MAZUMDER
Sankar Sengupta
Pankaj Srivastava

Certificate Name
SUPARNA MAZUMDER
SANKAR SENGUPTA
PANKAJ SRIVASTAVA

Tender Properties
Auto Tendering
Process allowed

No

Show Technical bid status

Yes

Show Finance bid
status
BoQ Comparative
Chart model
BoQ Comparative
Chart Rank Type

Yes

Stage to disclose Bid Details in
Public Domain

Technical Bid Opening

NIL

BoQ Compartive chart decimal
places
Form Based BoQ

2

NIL

No

TIA Undertaking
S.No
1

Undertaking to Order
PPP-MII Order 2017

Tender complying with Order
Agree

Reason for non compliance of Order
Agree

https://eprocure.gov.in/eprocure/app?component=%24DirectLink&page=PublishedView...

10/24/2024

<!-- page 3 -->

eProcurement System Government of India

2

MSEs Order 2012

Agree

Page 3 of 3

Agree

Tender Inviting Authority
Name

Director, CNCI

Address

CNCI, Kolkata

Tender Creator Details
Created By

Pankaj Srivastava

Designation

Technical Officer (Store and Purchase)

Created Date

24-Oct-2024 11:55 AM

https://eprocure.gov.in/eprocure/app?component=%24DirectLink&page=PublishedView...

10/24/2024
