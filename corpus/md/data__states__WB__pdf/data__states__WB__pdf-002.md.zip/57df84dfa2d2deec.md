---
doc_id: "57df84dfa2d2deec"
source_url: "https://icad.wb.gov.in/wb-admin/uploads/tenders/9433260311191721657401.pdf"
ministry: "Information and Cultural Affairs Department, West Bengal"
title: ""
date: ""
pages: 1
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "b3fe4cf1b0466260"
---

<!-- page 1 -->

॥
৮ ©
GOVERNMENT OF WEST BENGAL
DISTRIBUTION SECTION, DEPARTMENT OF INFORMATION & CULTURAL AFFAIRS
118 Hem Chandra Naskar Road, Kolkata-700010
No. 0010 -ICA/Distri/2024 — ee Date: Kolkata, the 22.07.2024
TENDER NOTICE
Quotations with GST break-up. are invited from well-experienced and bonafide agencies for making
and repairing the following consignments:
1] 10 standard 4X6 sq. ft. wooden based iron structure book stand making, 2] supply of 2 new computer
tables, 3] supply of 4 new moveable chairs, 4] rexin repair of 10 existing wooden chairs, 5] fourteen
table top rexin repairs in the office of the Distribution Section at | 18 Hem Ch Naskar Road. Kolkata-700010,
‘The entire process to be finished for within 30 working days in 4" week of August. 2024.
Detailed work schedule, terms & conditions will be available at Distribution office at 118 Hem Ch.
Naskar Road. Kolkata-700010 trom 1.00 PM on 23.07.2024 till 12 Noon on 26.07.2024,
Quotations addressed to the Business Manager, Distribution Section, 1404৯ and submitted within
12.00 Noon on 26" July, 2024 will be opened at 3.00 p.m. on the same day considering the urgency at the
chamber of Business Manager in presence of the representative of aforesaid agencies.
The Business Manager will reserve the right to accept or reject any or all quotations without assigning
any reasons.
৬.৫. Jn
Officer In-Charge & Business Manager,
Distribution Section, I&CA
Memo No. QO10-ICA/Distri/2024 Date: Kolkata, the 22.07.2024
Copy forwarded for information and necessary action to:
1. Director of Information, I&CA, Nabanna, 9" Floor. 325 Sarat Chatterjee Road. Shibpur. Howrah-7 11102
2. Officer In-charge, Kolkata Information Centre with a request to publish this on the notice board.
3. Officer-in-charge. G2C Portal with a request to upload the above notice in the official website.
Officer In-Charge & Business Manager,
Distribution Section, 14404
