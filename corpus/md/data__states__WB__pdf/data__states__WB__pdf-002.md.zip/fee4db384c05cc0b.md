---
doc_id: "fee4db384c05cc0b"
source_url: "https://www.rbu.ac.in/upload/eb74282ac1c984a650fb2fa41fafc90f.pdf"
ministry: "Rabindra Bharati University, West Bengal"
title: "Notification regarding Intermediate Even Semester Examinations, 2020  December 31 2020"
date: ""
pages: 2
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "1e25e403f1a36e61"
---

<!-- page 1 -->

(৮০
ise
নেনে
RABINDRA BHARATI UNIVERSITY
KOLKATA .
EXAMINATION DEPARTMENT
Notification regarding Intermediate Even Semester Examinations, 2020 for eligible students
Memo No. : Exam. / 7009 Date: 31.12.2020
This is for information of all concerned that Intermediate Even Semester Examinations,
2020 for eligible Students of UG and PG academic programmes (for both CBCS and non CBCS semester
system) of all departments under the Faculties of Arts, Fine Arts and Visual Arts of the University will be
conducted as per resolutions adopted by the Executive Council in its emergency meetings held on 15.12.2020
and Examination Task Force in its meetings held on 23.12.2020, on the basis of the UGC Guidelines on
Examinations and Academic Calendar in view of COVID-I9 Pandemic [vide D.O. NO. F1-1/2020 (Secy),
dated 29th April, 2020 and vide D.O. NO. F1-1/2020 (Secy), dated 6th July, 2020], the verdict of Hon’ble
Supreme Court dated August 28, 2020 issued in this matter. University shall strictly abide by the Guidelines
issued by the University Grants Commission (UGC) regarding modalities of examinations and spirit in the
best interest of students maintaining the sanctity of examination.

Detailed modalities of Intermediate Even Semester Examinations, 2020 for the eligible Students of UG
and PG academic programmes of all departments under the Faculties of Arts, Fine Arts and Visual Arts of
the University are mentioned below:

1. Intermediate Even Semester Examinations, 2020 [i.e. for UG (Arts and Fine Arts) - 2nd and 4th

Semester; for UG (Visual Arts) - 2nd, 4th and 6th Semester; for PG (Arts, Fine Arts and Visual Arts)
- 2nd Semester] of UG and PG academic programmes (for both CBCS and non CBCS semester
system) of all departments under the Faculties of Arts, Fine Arts and Visual Arts of the University
will be conducted by composite of 50% marks for each course on the basis of the Continuous Internal
Assessment (CIA) and the remaining 50% marks for each course can be awarded on the basis of
performance in previous semester SGPA only (if available). In the situations where previous semester
SGPA are not available, 100% evaluation for each course may be done on the basis of Continuous
Internal Assessment (CIA).
However, this above-mentioned provision shall be applicable only for the current academic session
2019-20 as a one-time measure as per UGC guidelines.
Candidates having any supplementary course/s [i.e. for UG (Arts and Fine Arts) - 2nd and 4th
Semester; for UG (Visual Arts) - 2nd, 4th and 6th Semester; for PG (Arts, Fine Arts and Visual Arts)
- 2nd Semester], don’t have to sit for Continuous Internal Assessment (CIA) for that supplementary
course. CIA marks would be carried forward from earlier examination of that course, i.e. those
candidates who already have 20% CIA marks but failed in that course, their 20% CIA marks of that
course will be converted into 50% CIA marks on pro-rata basis.
Example: A candidate appearing at the B.A. 4th Semester Examination, 2020, having back in any
course in the B.A. 2nd Semester Examination, then the above-mentioned CIA calculation will be
valid.

Page 1 of 2

<!-- page 2 -->

2. Full marks of Continuous Internal Assessment (CIA) for the courses like CC, AECC, SEC, CEC,
OEC (if any), DSE ete. will be 25 and for GE course it will be 50 under the Faculties of Arts and Fine
Arts of the University.

Full marks of Continuous Internal Assessment (CIA) for all the courses will be 25 under the Faculty
of Visual Arts of the University.

3. All such examinees under the Faculties of Arts, Fine Arts and Visual Arts of the University would be
required to undergo the online Examination Form fill up process through University web portal. In
online Examination Form fill up process, student would mention his/her University Registration
Number, SUIN, Exam Roll No, specialization ie. CC, GE, AECC, SEC, CEC, OEC (if any), DSE,
current Email ID and mobile phone number etc.

Detailed schedule of such process will be announced in due course of time through University website.
After completion of Examination Form fill up process, student would download the Admit Card from
the Examination Portal of the University.

4. Examination Fees and Admission Fees (if any) will be collected during distribution of Grade Card.

5. Candidates (“Persons with Benchmark Disabilities’), who want to write Examination with Scribe may
apply (as per Format attached) to the Joint Registrar (Exam.) using University designated portal at the
time of online Examination Form fill up process with all necessary documents of the candidate and
the Scribe.

6. Concerned Department will conduct the Continuous Internal Assessment of theoretical and practical
examinations (wherever applicable) as per UGC guidelines preferably by 15.01.2021.

7. As per latest guidelines published by UGC on July 06, 2020, the period of lockdown shall be treated
as ‘deemed to be attended’ by all the students.

8. Ifa candidate appeared in the process of Continuous Internal Assessment in a course of the academic
programme but failed in that course, then his/her Continuous Internal Assessment marks will be
carried forward and whenever he/she appears in that course in near future, this 50% CIA marks will
be converted into 20% CIA marks on pro-rata basis.

9. Ifa candidate is unable to get his/her Continuous Internal Assessment done in each course in due time,
then his/her candidature will be cancelled, in spite of filling up of examination form in due time.

10. If a candidate fails to fill up his/her examination form fill up in due time, his/her result will not be
published.

11. University will announce the detailed Provisional Eligibility List of the candidates for Intermediate
Even Semester Examinations, 2020, Schedule for Examination Form fill up in due course of time.
Students are requested to visit the University website: www.rbu.ac.in regularly.

12. In case, a student of Intermediate Even Semester is unable to appear in the Intermediate Even Semester
Examinations, 2020 conducted by the University for whatsoever the reason(s) may be, he/she will be
given opportunity to appear in special examinations for such course(s), which shall be conducted by
the university as and when feasible, so that the student is not put to any inconvenience/ disadvantage.
This provision shall be applicable only for the current academic session 2019-20 as a one-time
measure.

hos ae
Joint ররর Exam
Page 2 of 2
