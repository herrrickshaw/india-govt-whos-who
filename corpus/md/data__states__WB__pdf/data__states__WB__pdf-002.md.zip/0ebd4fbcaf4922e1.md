---
doc_id: "0ebd4fbcaf4922e1"
source_url: "https://www.iiswbm.edu/wp-content/uploads/2022/04/anti-ragging-committee-policy.pdf"
ministry: "Indian Institute of Social Welfare and Business Management (IISWBM), West Bengal"
title: "- Anti Ragging Committee"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "84aa9559f74549bc"
---

<!-- page 1 -->

Anti Ragging Committee
AICTE Permanent ID: 1-6200491
Date:01/07/2026
Address: Indian Institute of Social Welfare and Business Management, Management House, College
Square West, Kolkata-73
Phone no: 8240416431/033-22415793
Website: www.iiswbm.edu
Email: kma_director@iiswbm.edu
In accordance with the AICTE Regulations on Curbing the Menace of Ragging in Higher Educational
Institutions, 2009, (as amended from time to time), Institute has an Anti-Ragging Policy (available at the
website: https://www.iiswbm.edu/institute/governance/anti-ragging-committee-policy/) and has
established an Anti-Ragging Committee (https://www.iiswbm.edu/wp-content/uploads/2026/06/
antiragging-circular-290526.pdf/) as follows:

Sl.No
1
2
3
4.
4.
5.
6.
7
8.
9.

Name
Prof.Dr. K.M.Agrawal
Prof. Angshuman Sarkar
Prof.Dr.Tanima Ray
Prof.Dr.Archana Sharma
Prof.Dr. B.K.Choudhury
Prof.Dr.Sudeepa Banerjee
Dr.Madhab Milan Ghosh
Ms. Sayaree Dutta
Mr.Manis Das
Ms.Atreyee Chakraborty

Designation
Chairman
Member
Member
Member
Member
Member
Member
Student Counsellor
Parent Representative
Student Member (MBA Day)

Prof. (Dr) K. M. Agrawal
Director

INDIAN INSTITUTE OF SOCIAL WELFARE AND BUSINESS MANAGEMENT
MANAGEMENT HOUSE, College Square West, Kolkata – 700 073
EPABX : 2241 – 3756 / 5792 / 8694 / 8695, Fax : (033) 2241 3975
E-mail : iiswbm@iiswbm.edu, Website : www.iiswbm.edu
