---
doc_id: "da7e3e2b502afef4"
source_url: "https://forest.wb.gov.in/upload/final/raiganj.pdf"
ministry: "Forest Department, West Bengal"
title: "182. S.O. 5836(E) [26.11.2018] Final Notification declaring Eco Sensitive Zone around Raiganj Wildlife Sanctuary, West Bengal"
date: ""
pages: 23
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "d4a3f51302257db8"
---

<!-- page 1 -->

jftLVªh laö Mhö,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (ii)
PART II—Section 3—Sub-section (ii)
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 4615]

ubZ fnYyh] सोमवार] uoEcj 26] 2018@vxzgk;.k 05] 1940

No. 4615]

NEW DELHI, MONDAY, NOVEMBER 26, 2018/AGRAHAYANA 05, 1940

पयावरण, वन और जलवायु परवतन मं ालय
अिधसूचना
नई दली,

का.आ. 5836(अ).— ा

22 नवबर, 2018

प अिधसूचना भारत सरकार के पयावरण, वन और जलवायु प!रवतन मं$ालय क%

अिधसूचना सं. का.आ. 3343 (अ) तारीख 12 अ&तूबर, 2017 'ारा भारत के राजप$ असाधारण म(

िजसम( उन सभी .ि/य0 से, िजनको उससे
राजप$ क%

कािशत क% गई थी

भािवत होने क% संभावना थी, उस तारीख से, िजसको उ/ अिधसूचना क%

ितयां जनता को उपल4ध करा दी गई थ5, साठ दन क% अविध के भीतर, आ8ेप और सुझाव आमंि$त कए

गए थे;

और, उ/

और,

ा

ा

प अिधसूचना राजप$ क%

ितयां जनता को तारीख 16 अ&तूबर, 2017 को उपल4ध करा दी गई थ5;

प अिधसूचना के उ;र म( .ि/य0 और पणधा!रय0 से कोई भी आ8ेप और सुझाव

ा< नह5 =ए;

और, रायगंज व>यजीव अभयार?य 8े$ 1.30 वग कलोमीटर पिAम बंगाल म( और 25°39’ और 25° 40’ उ;र

अ8ांश और 88°8’ पूव देशांतर के बीच िBथत है। यह पिAम बंगाल म( उ;र दनाजपुर, िजला, पी.एस. रायगंज के अंतगत
मौजा-सोहरोई, भEादधी और अ4दुलघाट म( िBथत है। अभयार?य को सरकारी आदेश संGया 1901-एफ ओ आर/11एस86/82 तारीख 11 अ ैल, 1985 के िलए घोिषत कया गया है और रायगंज व>यजीव अभयार?य, रायगंज शहर के ब=त

िनकट है और मानव िनवास और कृिष 8े$0 से िघरा =आ है;

और, अभयार?य के चार0 ओर Bतनधारी क% 4

और मछिलय0 क% 30

जाितय0, पि8य0 क% 86

जाितय0 एवं िततिलय0 क% 67

जाितय0

जाितय0 क% पहचान क% गई है। इनके अलावा सांप, कछुआ आद भी पाए जाते है। 8े$ म( Bथािनक

जाितयां नह5 है हाल ही म( जलोढ़ िमEी है। िचकनी लोम क% लोम बनावट है। चEान अनुपिBथत है &य0क यह महान गंगा

6854 GI/2018

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

समतल 8े$ है जहां िमEी क% गहराई 1000 फ%ट क% गहराई से अिधक है। बडे पPथर 250 से 300 फ%ट क% गहराई म( पाए
जाते हQ और िमEी ब=त उपजाऊ और उPपादक है;

और, अभयार?य व>यजीव (संर8ण) अिधिनयम, 1972 (1972 का 53) के अनुसूची–I से IV के अंतगत िनSदT

अनासटोमुस ओसक टंस
अरदेइदेअ)
िल!टल कॉमYर( ट
फालाकरोकोरक नीगेर
नयकटीकोरास पप.) Zकगफ़शर
अलकेदीनीदेअ
4लैक बै&ड
\ाउन ]लाईकैचर मुसक कापा लतीरोसरीइस
(कलांडरला रयपाल
आवासी प8ी
^ॉ कोरवुस पलदांस
पसीाकु ला करमेरी Bपॉटवेट
टरेपटोपेिलया
चीनेउसीस), उलू (टयटोके पिसस
_ी िपक ददरोक ा वगाबुंदा)
अकरीदोथेरेस टरीसटीस
बंगा स के म लेउस
नाजा नाजा
वीपेरा सेली
जाितय0 क% संGया का संभरण करता है िजसम( (1) आवासी

बगुला

(

(

,

(

),

),

वुडपीकर,

(2)

-

वासी ओपन िबल सटाक (

हाउस

),

बुलबुल,

(3) सांप- कैरात (

बगुला

(

(

(

),

नाईट

,

), सैड लारक

पराकेइट

(

),

(

), कोबरा (

), सफेद

,

कबूतर (

इं िडयन मैना (

), वाइपर (

)

),

) और गैर िवषैले जैसे वॉटर सांप,

क%ल बैक, चूहा सांप आद, और (4) पशु- बनिबलार (फेिलस चाउस), िसयार (कैिनस अयरे उस), सामा>य लोमड़ी, सामा>य

कोटोफ लुस हाथी),

पीला चमगादड़ (

िगलहरी, नेवला, यलोव मॉिनटर िछपकली

है। अभयार?य एिशया म( एिशयन ओपन िबल Bटोक क% सबसे बड़ी
और सफेद बगुला के िलए अbछा वास

वरनुस फलावेसक स) और अ>य

(

शािमल

जनन भूिम है। यह जलीय पि8य0 जैसे बगुल0, जलकौआ

दान करता हQ;

और, कुलीक नदी जो अभयार?य के पूवc Bथल म( बहती है, जो जल का बारहमासी dोत है। इसके अलावा

अभयार?य म( नहरो क% संGया है िजसम( पि8य0 का संवाहक पयावरण

दान है और अभयार?य के अंतगत कुलीक नदी और

आवास के महeवपूण भाग, वषा ऋतु के दौरान मुGय ओ&सीबो झील एवं नहर कुलीक से ऊपर बहती है। इस मुGय ऑ&सीबो
झील पि8य0 का मुGय dोत है।

अतः, इसिलए, के>hीय सरकार, पयावरण (संर8ण) िनयम, 1986 के िनयम 5 के उपिनयम (3) के साथ प!ठत

पयावरण (संर8ण) अिधिनयम, 1986 (1986 का 29) क% धारा 3 क% उपधारा (1) और उपधारा (2) के खंड (v) और खंड
(xiv) और उपधारा (3) 'ारा

द; शि/य0 का

योग करते =ए, पिAम बंगाल राiय के रायगंज व>यजीव अभयार?य क%

सीमा के चार0 ओर 100 मीटर तक के िवBता!रत 8े$ को रायगंज व>यजीव अभयार?य पा!रिBथितक% संवेदी जोन (िजसे

इसम( इसके पjचात् पा!रिBथितक% संवेदी जोन कहा गया है) के

प म( अिधसूिचत करती है, िजसके िववरण िनlानुसार है,

अथात् :--

1.

पारिथितक संवेेेदी जोन का िवतार और सीमाएं.--(1) यह पा!रिBथितक% संवेदी जोन का 8े$ 0.12 वग

कलोमीटर है, रायगंज व>यजीव अभयार?य क% सीमा के साथ 100 मीटर का िवBतार है।

(2) पा!रिBथितक% संवेदी जोन पिAम बंगाल के उ;र दनाजपुर िजला म( और 25°39’ और 25° 40’ उ;र अ8ांश और
88°8’ पूव म( देशांतर के बीच िBथत है।

(3) व>यजीव अभयार?य और पा!रिBथितक% संवेदी जोन के िनदmशांक, सीमा िववरण, मानिच$ उपाबंध I के nप म( उपाबo
है। pाम0 क% सूची उपाबंध II के nप म( उपाबo है ।

2.

पारिथितक संवेेेदी जोन केेे िलए आंचिलक महायोजना – (1) राiय सरकार, पा!रिBथितक% संवेदी जोन के

के िलए राजप$ म( इस अिधसूचना के

योजन

काशन क% तारीख से दो वष क% अविध के भीतर, Bथानीय .ि/य0 के परामश से और

इस अिधसूचना म( दए गए अनुबंध0 का पालन करते =ए आंचिलक महायोजना तैयार करे गी।

<!-- page 3 -->

¹Hkkx IIµ[k.M 3(ii)º
(2)

Hkkjr dk jkti=k % vlk/kj.k

3

राiय सरकार 'ारा पा!रिBथितक% संवेदी जोन के िलए आचंिलक महायोजना ऐसी रीित से जो इस अिधसूचना म(

िविनSदqट कए गए है के अनुसार तथा सुसंगत क(hीय और राiय िविधय0 के अनुnप और क(hीय सरकार 'ारा जारी
मागिनदmश0, यद कोई ह0, 'ारा तैयार होगी ।

(3)

आंचिलक महायोजना, उ/ योजना म( पा!रिBथितक% और पयावरणीय बात0 को समाकिलत करने के िलए राiय

सरकार के िनlिलिखत िवभाग0 के परामश से तैयार होगी, अथात्:—

(4)

(i)

पयावरण;

(ii)

वन और व>यजीव;

(iii)

कृिष;

(iv)

राजBव;

(v)

नगर िवकास;

(vi)

पयटन;

(vii)

pामीण िवकास;

(viii)

tसचाई और बाढ़ िनयं$ण;

(ix)

नगरपािलका;

(x)

पंचायती राज;

(xi)

लोक िनमाण िवभाग।

(xii)

राजमाग;

(xiii)

पिAम बंगाल राiय

दूषण िनयं$ण बोड।

आंचिलक महायोजना अनुमोदत िवuमान भू-उपयोग, अवसंरचना और ^याकलाप0 पर कोई िनबvधन अिधरोिपत

नह5 करे गी जब तक क इस अिधसूचना म( इस

कार िविनSदqट न हो और आचंिलक महायोजना सभी अवसंरचना और

^याकलाप0 म( जो अिधक द8ता और पा!रिBथितक% अनुकूल ह0 का संवधन करे गी ।

(5)

आंचिलक महायोजना म( अनाbछादत 8े$0 के जीणYoार, िवuमान जल िनकाय0 के संर8ण, आवाह 8े$0 के

जल-संभर0 के

बंधन, भूतल जल के

बंधन,

बंधन, मृदा और नमी संर8ण, Bथानीय समुदाय0 क% आवjयकताw तथा पा!रिBथितक%

और पयावरण से संबंिधत ऐसे अ>य पहलुw, िजन पर xयान देना आवjयक है, के िलए उपबंध ह0गे ।

(6)

आंचिलक महायोजना सभी िवuमान पूजा Bथल0, pाम0 और नगरीय बिBतय0, वन0 के

8े$0, ऊपजाऊ भूिम, ह!रत 8े$ जैसे उuान और उसी

कार और कBम0, कृिष

कार के Bथान, उuान कृिष 8े$, फलोउuान, झील0 और अ>य जल

िनकाय0 का अyयकंन करे गी । इस योजना के मानिच$ के साथ िवuमान और

Bतािवत भूिम उपयोग िवशेषताw का िववरण

अनुसमzथत होगा ।

(7)

आंचिलक महायोजना पा!रिBथितक% संवेदी जोन म( िवकास को िविनयिमत करे गी और सारणी म( सूचीबo

ितिषo

और िविनयिमत ^याकलाप0 का अनुपालन करे गी और Bथानीय समुदाय0 के पा!रिBथितक% अनुकूल िवकास के िलए
जीवकोपाजन को सुरि8त करने के िलए सुिनिAत कया जा सकेगा।

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

(8) इस

[PART II—SEC. 3(ii)]

कार अनुमोदत आंचिलक महायोजना इस अिधसूचना के उपबंध0 के अनुसार िनगरानी के अपने काय{ को करने के

िलए िनगरानी सिमित के िलए एक संदभ दBतावेज तैयार करे गी ।

राय सरकार ारा कए जाने वाले उपाय-- राiय सरकार इस अिधसूचना के उपबंध0 को

3.

भावी करने के िलए

िनlिलिखत उपाय करे गी, अथात्:--

(1) भू-उपयोग –पा!रिBथितक% संवेदी जोन म( वन0, उuान-कृिष 8े$0, कृिष 8े$0, आमोद- मोद के

योजन के िलए िचि>हत

कए गए पाक{ और खुले Bथान0 का वािणिiयक और औuोिगक संबo िवकास ^याकलाप0 के िलए उपयोग या संप!रवतन
नह5 होगा:

परं तु पा!रिBथितक% संवेदी जोन के भीतर कृिष और अ>य भूिम का संप!रवतन मानीटरी सिमित क% िसफा!रश पर
और राiय सरकार के पूव अनुमोदन से, Bथानीय िनवािसय0 क% िनlिलिखत आवासीय आवjयकताw को और ^याकलाप0
को पूरा करने के िलए अनु|ात कया जाएगा, जैसे:-

(i) िवuमान सड़क0 को चौड़ा करना और उ>ह( सुद ृढ करना तथा नई सड़क0 का संिनमाण;

(ii) बुिनयादी ढांच0 और नाग!रक सुिवधाw का संिनमाण और नवीकरण;

दूषण उPप~ न करने वाले लघु उuोग;

(iii)

(iv) कुटीर उuोग0 िजनके अंतगत pामीण उuोग भी हQ; सुिवधाजनक भ?डार और Bथानीय सुिवधाw सहायक है िजसम(

पा!रिBथितक% पयटन म( pह वास सिमिलत है; और
(v) पैरा 4 के अंतगत दया गया संवzधत ^याकलाप है:
परं तु यह और क राiय सरकार के पूव अनुमोदन और संिवधान के अनुbछेद 244 और तPसमय

वृ; िविध के

उपबंध0 के अनुपालन के िबना, िजसके अंतगत अनुसूिचत जनजाित और अ>य परं परागत वन िनवासी (वन अिधकार0 क%
मा>यता) अिधिनयम, 2006 (2007 का 2) भी है, वािणिiयक या उuोग िवकास ^याकलाप0 के िलए जनजातीय भूिम का
उपयोग अनु|ात नह5 होगा:

परं तु यह और भी क पा!रिBथितक% संवेदी जोन के भीतर भू-अिभलेख0 म( उपसंजात कोई $ु!ट, मानीटरी सिमित के
िवचार

ा< करने के पAात् राiय सरकार 'ारा

Pयेक मामले म( एक बार संशोिधत होगी और उ/ $ु!ट के संशोधन क% सूचना

क(hीय सरकार के पयावरण, वन और जलवायु प!रवतन मं$ालय को दी जाएगी।

परं तु यह और भी क उपयु/ $ु!ट के संशोधन म( इस उप पैरा के अधीन यथा उपबंिधत के िसवाय कसी भी दशा म( भूउपयोग का प!रवतन सिमिलत नह5 होगा;

परं तु यह और भी क िजससे ह!रत 8े$ म( जैसे वन 8े$, कृिष 8े$ आद म( कोई पा!रणािमक कटौती नह5 होगी और

अन यु&त या अनुPपादक कृिष 8े$0 म( पुन: वनीकरण करने के

(2)

ाकृ ितक जल ोत -- आचंिलक महायोजना म( सभी

यास कए जाएंगे ।

ाकृितक जल ोत0, नदय0, जलसरणी के आवाह 8े$0 क% पहचान

क% जाएगी और उनके संर8ण और नवीकरण के िलए योजना सिमिलत होगी और राiय सरकार 'ारा ऐसे 8े$0 पर या उनके
िनकट िवकास ^याकलाप

(3)

ितिषo करने के िलए ऐसी रीित से मागिनदmश तैयार कए जाएंगे ।

पयटन– (क) पा!रिBथितक% संवेदी जोन के भीतर सभी नए पा!रिBथितक% पयटन ^याकलाप या िवuमान पयटन

^याकलाप0 का िवBतार पयटन महायोजना के अनुसार आंचिलक महायोजना के िलए होगा ।

<!-- page 5 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

5

(ख) पयट न महायोजना राiय पयटन िवभाग 'ारा राiय पयावरण और वन िवभाग के परामश से तैयार होगी ।
(ग) पयटन महायोजना आंचिलक महायोजना के एक घटक के

प म( होगी ।

(घ) पा!रिBथितक% पयटन संबंधी ^याकलाप िनlिलिखत के अधीन िविनयिमत ह0गे, अथात् :संरि8त 8े$ क% सीमा से एक कलोमीटर के भीतर या पा!रिBथितक% संवेदी जोन के िवBतार तक, इनम( जो भी िनकट है,

(i)

नये वािणिiयक होटल और !रसोट अनु|ात नह5 ह0गे।
परं तु, व>यजीव अभयार?य क% सीमा से एक कलोमीटर क% दूरी से परे पा!रिBथितक% संवेदी जोन के िवBतार तक होटल0 और
सैरगाह0 का Bथापन केवल पूव प!रभािषत और नामिनSदT 8े$0 म( पयटन महायोजना के अनुसार पा!रिBथितक% पयटन
सुिवधाw के िलए ही अनु|ात होगा;

(ii) पा!रिBथितक% संवेदी जोन के भीतर नए पयटन ^याकलाप0 या िवuमान पयटन ^याकलाप0 का िवBतार क(hीय
सरकार के पयावरण, वन और जलवायु प!रवतन मं$ालय के मागदशक िसoांत0 के 'ारा तथा राq_ीय या संर8ण

ािधकरण, 'ारा जारी पा!रिBथितक% पयटन (समय-समय पर यथा संशोिधत) मागदशक िसoांत0 के अनुसार होगा;

(iii) आंचिलक महायोजना का अनुमोदन कए जाने तक, पयटन के िलए िवकास और िवuमान पयटन ^याकलाप0 के िवBतार
को वाBतिवक Bथल िविनSदT संवी8ा और मानीटरी सिमित क% िसफा!रश पर आधा!रत संबंिधत िविनयामक

ािधकरण0

'ारा अनु|ात कया जाएगा और पा!रिBथितक% संवेदी जोन के अंदर कसी नये होटल या सैरगाह या वािणिiयक

ित ान का

संिनमाण अनु|ात नह5 कया जायेगा ।

(4)

नैस गक िवरासत -- पा!रिBथितक% संवेदी जोन म( महPवपूण नैसzगक िवरासत के सभी Bथल0 जैसे सभी जीन कोश

आरि8त 8े$, शैल िवरचनाएं, जल

पात0, झरन0, घाटी माग{, उपवन0, गुफाएं, Bथल0, मण, अरोहण,

पात0 आद क%

पहचान क% जाएगी और उ>ह( संरि8त कया जाएगा तथा उनक% सुर8ा और संर8ा के िलए इस अिधसूचना के अंितम

काशन

क% तारीख से छह मास के भीतर, उपयु/ योजना बनाएगी और ऐसी योजना आंचिलक महायोजना का भाग होगा ।

(5)

मानव िन मत िवरासत थल - पा!रिBथितक% संवेदी जोन म( भवन0, संरचनाw, िशप-तय, ऐितहािसक, कलाPमक और

सांBकृितक महPव के 8े$0 क% पहचान क% जाएगी और इस अिधसूचना के

काशन क% तारीख से छह मास के भीतर उनके

संर8ण क% योजना तैयार करनी होगी तथा आंचिलक महायोजना म( सिमिलत क% जाएगी ।

(6)

#विन दूषण -- पयावरण (संर8ण) अिधिनयम 1986 के अधीन xविन

म( िनयत उपबंध0 के अनुसार म( पा!रिBथितक% संवेदी जोन म( xविन

(7) वायु

दूषण -- पा!रिBथितक% संवेदी जोन म(, वायु

दूषण (िविनयमन और िनयं$ण) िनयम, 2000

दूषण के िनयं$ण के िलए िविनयम0 को कायाि>वत करे गा

दूषण क% रोकथाम और िनयं$ण वायु ( दूषण िनवारण और िनयं$ण)

अिधिनयम, 1981 (1981 का 14) के उपबंध0 के अनुसार अनुपालन कया जाएगा ।

(8)

बिहाव का िनसारण -- पा!रिBथितक% संवेदी जोन म( उपचा!रत बिहाव का िनBसारण, जल ( दूषण िनवारण तथा

िनयं$ण) अिधिनयम, 1974 (1974 का 6) और उसके अधीन बनाए गए िनयम0 के उपबंध0 के अनुसार होगा ।

(9) ठोस

अपिश+ -- ठोस अपिशT0 का िनपटान और

बंधन िनlिलिखत

(क) पा!रिBथितक% संवेदी जोन म( ठोस अपिशT िनपटान और

प म( होगा-

बंधन समय-समय पर संशोिधत ठोस अपिशqट

बंधन िनयम,

2016, जो भारत सरकार के पयावरण, वन और जलवायु प!रवतन मं$ालय क% अिधसूचना सं. का.आ. 1357(अ) तारीख

8 अ ैल, 2016 'ारा

कािशत कए गए थे, के उपबंध0 के अनुसार कया जाएगा;

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

(ख) Bथानीय

[PART II—SEC. 3(ii)]

ािधकरण जैव िनlीकरणीय और अजैव िनlीकरणीय संघटक0 म( ठोस अपिशT0 के संपृथन के िलए योजनाएं

तैयार कर( गे;

(ग) जैव िनlीकरणीय सामpी को अिधमानतः खाद बनाकर या कृिम खेती के माxयम से पुनःच^त कया जाएगा;

(घ) अकाबिनक सामpी का िनपटान पा!रिBथितक% संवेदी जोन के बाहर पहचान कए गए Bथल पर कसी पयावरणीय

Bवीकृत रीित म( होगा और पा!रिBथितक% संवेदी जोन म( ठोस अपिशqट0 को जलाना या भqमीकरण अनु|ात नह5 होगा।

(10)

जैव िचक.सीय अपिश0ट- पा!रिBथितक% संवेदी जोन म( जैव िचकPसीय अपिशT0 का िनपटान भारत सरकार के

पयावरण, वन और जलवायु प!रवतन मं$ालय क% समय-समय पर यथा संशोिधत अिधसूचना सं.का.िन 343(अ) तारीख
28 माच 2016 'ारा

(11)

कािशत जैव िचकPसीय अपिशT

बंध िनयम, 2016 के उपबंध0 के अनुसार कया जाएगा ।

1लािटक अपिश+ बंधन: - पा!रिBथितक% संवेदी जोन म( लािBटक अपिशT

बंध का िनपटान भारत सरकार के

पयावरण, वन और जलवायु प!रवतन मं$ालय क% समय-समय पर यथासंशोिधत अिधसूचना सा.का.िन 340(अ), तारीख
18 माच, 2016 'ारा

(12)

कािशत लािBटक अपिशT

बंध िनयम 2016 के उपबंध0 के अनुसार कया जाएगा।

संिनमाण और िव#वंस अपिश+ बंधन: - पा!रिBथितक% संवेदी जोन म( संिनमाण और िवxवंस अपिशT

बंध भारत

सरकार के पयावरण, वन और जलवायु प!रवतन मं$ालय क% समय-समय पर यथासंशोिधत अिधसूचना सा.का.िन. 317(अ),
तारीख 29 माच, 2016 'ारा

कािशत संिनमाण और िवxवंस

अपिश+:- पा!रिBथितक% संवेदी जोन म( ई–अपिशT

(13) ई–

बंध िनयम, 2016 के उपबंध0 के अनुसार कया जाएगा ।

बंध का िनपटान भारत सरकार के पयावरण, वन और जलवायु

प!रवतन मं$ालय 'ारा समय-समय पर यथासंशोिधत ई–अपिशT

(14)

बंध िनयम, 2016 के उपबंध0 के अनुसार कया जाएगा।

यानीय परवहन: - प!रवहन क% यानीय संचालन आवास के अनुकूल रीित म( िविनयिमत ह0गी और इस संबंध म(

आंचिलक महायोजना म( िविनSदT उपबंध समािवT कए जाएंगे और आंचिलक महायोजना के तैयार होने और राiय सरकार

के स8म

ािधकारी के 'ारा अनुमोदत होने तक, मानीटरी सिमित सुसंगत अिधिनयम0 तथा तदधीन बनाए गए िनयम0 और

िविनयम0 के अधीन यानीय संचलन के अनुपालन को मानीटर करे गी ।

(15)

यानीय दूषण:- लागू िविधय0 के अनुसार वाहन

दूषण क% रोकथाम और िनयं$ण का अनुपालन कया जाएगा।

Bवbछक धन उदाहरण के िलए सीएनजी आद के उपयोग के िलए

(16)

यास कए जाएगे ।

औ5ोिगक ईकाइयां: - (i) पा!रिBथितक% संवेदी जोन म( भीतर कोई भी नए

दूिषत उuोग0 क% Bथापना क% अनुमित

नह5 दी जाएगी।

(ii) पा!रिBथितक% संवेदी जोन के क(hीय

वगcकरण के अनुसार केवल गैरिविनSदT न हो इसके अित!र/ गैर

(17)

दूषण िनयं$ण बोड 'ारा फरवरी, 2016 के जारी दशािनदmश0 म( दये गये

दूिषत उuोग0 क% Bथापना क% अनुमित दी जाएगी, जब तक क इस अिधसूचना म(
दूषणकारी कुटीर उuोग0 को बढ़ावा दया जाएगा।

पहाड़ी ढलान को संर:ण: - पहाड़ी ढलान0 का संर8ण िनlानुसार कया जाएगा:
(क)

आंचिलक महायोजना म( पहाड़ी ढलान0 पर 8े$0 को उपदzशत कया जाएगा जहां कसी भी

संिनमाण क%

अनुमित नह5 दी जाएगी ।
(ख) कटाव के एक उ िडpी के साथ िवuमान खड़ी पहाड़ी ढलान0 या ढलान0 पर कसी भी संिनमाण क% अनुमित

नह5 दी जाएगी ।

<!-- page 7 -->

¹Hkkx IIµ[k.M 3(ii)º
4.

Hkkjr dk jkti=k % vlk/kj.k

7

पारिथितक संवेेेदी जोन म; ितिष< या िविनयिमत कए जाने वाले >याकलाप क सूची - पा!रिBथितक% संवेदी जोन

म( सभी ^याकलाप, पयावरण (संर8ण) अिधिनयम, 1986 (1986 का 29) के उपबंध0 और तटीय िविनयमन जोन
(सीआरजेड) अिधसूचना, 2011 एवं पयावरणीय

भाव आकलन (ईआईए) अिधसूचना, 2006

सिहत उसके अधीन बने

िनयम0 और वन (संर8ण) अिधिनयम, 1980 (1980 का 69), भारतीय वन अिधिनयम, 1927 (1927 का 16), व>यजीव
(संर8ण) अिधिनयम, 1972 (1972 का 53) सिहत अ>य लागू िनयम0

तथा उनम( कए गए संशोधन0 के अनुसार शािसत ह0गे

और नीचे दी गई सारणी म( िविनSदT रीित से िविनयिमत ह0गे,

सारणी

म सं.

याकलाप

(1)

टीका-ट पणी
(2)

(3)

क. ितिष याकलाप
1.

वािणियक खनन, प थर क
उनको तोड़ने क इकाइयां ।

खदान और

कार के नए और िवमान खनन (लघु और वृहत खिनज), प थर
क खान और उनको तोड़ने क इकाइयां वातिवक थानीय िनवािसय क
घरे लू आवयकता िजसम िनजी उपयोग के िलए मकान के संिनमाण या
मरमत के िलए धरती को खोदना और मकान बनाने के िलए देशी टाइ!स
या "ट का िनमाण करना भी सिमिलत है, के िसवाय नह% हगी ;

(क) सभी

सं'(याएं, माननीय उ+तम ,यायालय क -रट यािचका
(िसिवल) सं. 1995 का 202 टी.एन. गौडाबमन िथ1मूलपाद बनाम भारत
संघ के मामले म आदेश तारीख 4 अगत, 2006 और -रट यािचका (सी)
सं. 2012 का 435 गोवा फाउं डेशन बनाम भारत संघ के मामले म तारीख
21 अ ैल, 2014 के आदेश के अनुसरण म चालन होगा ।
(ख) खनन

2.

3.

4.

5.

उोग क थापना िजसके अंतगत (जल, (क) पा-रिथितक संवेदी जोन म कोई नया उोग या दूषण फै लाने वाले
वायु, मृदा, >विन आ'द) दुषण का-रत करने उोग के िवतार क अनुमित नह% दी जाएगी।
वाले नए तेल और गैस खोज उोगो भी है।
(ख) पा-रिथितक संवेद ी जोन के भीतर क Fीय दूषण िनयंGण बोड Hारा
फरवरी, 2016 म जारी 'दशािनदNश म 'कए गए उोग के वगOकरण के
अनुसार केवल गैर- दूिषत उोग को थापना को अनुPात 'कया जाएगा
इसके अित-रQ गैर दूषकारी कु टीर उोग का ो साहन 'दया जाएगा।
तापीय और बृहत जल िवुत
लागू िविधय के अनुसार ितिषS (अ,यथा उपबंिधत के िसवाय) हगे ।
प-रयोजना क थापना ।
'कसी प-रसंकटमय पदाथT का उपयोग या लागू िविधय के अनुसार ितिषS (अ,यथा उपबंिधत के िसवाय) हगे ।
उ पादन या संकरण।
ाकृ ितक जल िनकाय या UेG भूिम म लागू िविधय के अनुसार ितिषS (अ,यथा उपबंिधत के िसवाय) हगे ।
अनुपचा-रत बिहVाव का िनसारण ।
बृहत

िमल क थापना।

6.

नई आरा

7.

"ट भW क थापना करना।

8.

जलावन लकड़ी का

9.

वािणियक उपयोग A
पोिलथीन बैग का उपयोग ।

10.

वािणियक होटल और -रसोटT क थापना ।

पा-रिथितक संवेदी जोन के भीतर नई और िवमान आरा िमल का
िवतार अनुPात नह% होगा ।
लागू िविधय के अनुसार ितिषS (अ,यथा उपबंिधत के िसवाय) हगे ।
लागू िविधय के अनुसार ितिषS (अ,यथा उपबंिधत के िसवाय) हगे ।
लागू िविधय के अनुसार ितिषS (अ,यथा उपबंिधत के िसवाय) हगे ।

ख.िविनयिमत याकलाप

पा-रिथितक पयटन '(याकलाप संबंधी लघु अथायी संरचना के
िसवाय संरिUत UेG क
सीमा से एक 'कलोमीटर के भीतर या
पा-रिथितक संवेदी जोन के िवतार तक, इनम जो भी िनकट है, नए

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

वािणियक होटल और िवYाम थल को अनुPात नह% 'कया जाएगा ।
परं तु, पा-रिथितक संवेदी जोन के आगे या उसके िवतार तक, जो भी
िनकट हो के संरिUत UेG क सीमा से एक 'कलोमीटर से सभी नए पयटन
'(याकलाप या िवमान '(याकलाप का िवतार पयटन महायोजना और
यथा लागू मागदशO िसSांत के अनुZप होगा।
11.

12.

फम[, कं पिनय Hारा बड़े पैमाने पर लागू िविधय के अधीन िविनयिमत हगे
वािणियक पशु और पो!\ी फामT क
थापना ।
संिनमाण '(याकलाप ।
(क) संरिUत UेG क सीमा से एक 'कलोमीटर के भीतर या पा-रिथितक
संवेदी जोन क सीमा तक, इनम जो भी अिधक िनकट हो, 'कसी भी कार
के नये वािणियक संिनमाण क अनुPा नह% होगी:
थानीय लोग को अपनी आवास सब,धी िन^िलिखत आवयकता
को पूरा करने के िलए, पैरा 3 के उप पैरा (1) म सूचीबS '(याकलाप
सिहत अपने योग के िलए, अपनी भूिम म भवन उप-िविधय के अनुसार,
संिनमाण करने क अनुPा होगी।
परं तु

दूषणकारी लघु उोग से संबंिधत संिनमाण '(याकलाप लागू
िनयम और िविनयम, य'द कोई ह, के अनुसार सUम ािधकारी क पूव
अनुमित से िविनयिमत 'कए जाएंगे और वे ,यूनतम हगे ।
(ग) एक 'कलोमीटर UेG से आगे ये आंचिलक महायोजना के अनुसार
िविनयिमत हगे ।
(ख) गैर–

13.

14.

दूषण उ प_ न करने वाले लघु उोग ।

वृU क कटाई ।

फरवरी, 2016 म के ,Fीय दूषण िनयंGण बोड Hारा जारी उोग म
वगOकरण के अनुसार गैर- दूषणकारी उोग और अप-रसंकट म, लघु और
सेवा उोग, कृ िष, पु`प कृ िष, उान कृ िष या पा-रिथितक संवेदी जोन से
देशी सामaी से उ पाद को उ प_ करने वाले कृ िष आधा-रत उोग सUम
ािधकारी Hारा अनुPात हगे।
राय सरकार म सUम ािधकारी क पूव अनुमित के िबना वन,
सरकारी या राजव या िनजी भूिम पर या वन म वृU क कटाई नह%

(क)

होगी ।
(ख)

वृU क कटाई संबंिधत क Fीय या राय अिधिनयम या उसके अधीन
िनयम के उपबंध के अनुसार िविनयिमत होगे ।

बनाए गए
15.

16.

17.

18.

19.

उ पाद और गैर का`ठ वन उ पाद का लागू िविधय के अधीन िविनयिमत हगे ।
संaहण (एनटीएफपी) ।
वन

िवुत और दूरसंचार टावर का प-रिनमाण लागू िविधय के अधीन िविनयिमत हगे । (भूिमगत केबल िबछाए जाने को
और के बल िबछाना और अ,य बुिनयादी ढांचे ।
ो सािहत 'कया जाएगा)।
नाग-रक सुख सुिवधा सिहत बुिनयादी लागू िविधय के अनुसार ,यूनीकरण उपाय िनयम और िविनयमन और
ढांचे।
उपलcध 'दशािनदNश के साथ 'कए जाएंगे।
िवमान सड़क को चौड़ा करना और उ,ह लागू िविधय के अनुसार ,यूनीकरण क उपाय के साथ, िनयम और
सुद ृढ करना तथा नवीन सड़क का संिनमाण ।
िविनयमन और उपलcध 'दशािनदNश के साथ िविनयिमत हगे।
पयटन से संबंिधत अ,य '(याकलाप जैसे गम लागू िविधय के अधीन िविनयिमत हगे ।
वायु
गुcबार,
हेलीकाeटर,
fोन,
माइ(ोलाइटस आ'द Hारा पा-रिथितक
संवेदी जोन UेG के ऊपर से उड़ना जैसे
'(याकलाप करना।

<!-- page 9 -->

¹Hkkx IIµ[k.M 3(ii)º
20.
21.
22.

23.

24.
25.

26.

27.
28.
29.

Hkkjr dk jkti=k % vlk/kj.k

9

पहाड़ी ढाल और नदी तट का संरUण ।
लागू िविधय के अधीन िविनयिमत हगे ।
रािG म यािनक यातायात का संचलन ।
लागू िविधय के अधीन वािणियक योजन के िलए िविनयिमत हगे ।
थानीय समुदाय Hारा चल रही कृिष और थानीय लोग के उपयोग के िलए लागू िविधय के अधीन अनुPात हगे ।
बागवानी
था के साथ दुगधशाला, दुiघ
उोग, कृिष और मछली पालन ।
ाकृ ितक जल िनकाय या सतही UेG म उपचा-रत जल िनकाय म बिहVाव के अपिशj जल िनसारण से बचा
उपचा-रत बिहVाव का िनसारण ।
जाएगा और उपचा-रत अपिशj जल के पुन:च(ण और पुन:उपयोग के िलए
यास 'कए जाएंगे और अ,यथा लागू िविधय के अनुसार उपचा-रत
बिहVाव के पुनच(ण/ वाह के िनवहन को िविनयिमत 'कया जाएगा।
सतह और भूजल का वािणियक िन`कषण ।
लागू िविधय के अधीन िविनयिमत हगे ।
खुले कुंआ, बोर कुंआ, आ'द कृ िष और अ,य
लागू िविधय के अधीन िविनयिमत हगे और सबS ािधकारी Hारा
उपयोग के िलए ।
'(याकलाप क सkती से िनगरानी क जाएगी।
ठोस अपिशj
बंधन / जैव िच'क सा लागू िविधय के अधीन िविनयिमत हगे ।
अपिशj बंधन।
िवदेशी जाितय को लाना ।
लागू िविधय के अधीन िविनयिमत हगे ।
पा-रिथितक पयटन।
वािणियक साइन बोड और होlडiस ।

30.

वषा जल संचयन ।

31.

जैिवक खेती।

32.

सभी

लागू िविधय के अधीन िविनयिमत हगे ।
लागू िविधय के अधीन िविनयिमत हगे ।

ग.संवधत याकलाप

'(य Zप से बढ़ावा 'दया जाएगा ।
'(य Zप से बढ़ावा 'दया जाएगा ।
स'(य Zप से बढ़ावा 'दया जाएगा ।

स

स

गितिविधय के िलए ह-रत ौोिगक
aहण करना ।
कुटीर उोग िजसके अंतगत aामीण कारीगर
भी हm ।
नवीकरणीय ऊजा Vोत और "धन का
को

33.

34.

'(य Zप से बढ़ावा 'दया जाएगा ।

स

, सौर काश इ या'द को स'(य 1प से बढ़ावा 'दया जाना है ।

बायोगैस

उपयोग ।
35.
36.
37.
38.

39.
5.

कृ िष वािनक ।
पा-रिथितक अनुकूल प-रवहन का उपयोग ।

'(य Zप से बढ़ावा 'दया जाएगा ।
स'(य Zप से बढ़ावा 'दया जाएगा ।
कौशल िवकास ।
स'(य Zप से बढ़ावा 'दया जाएगा ।
िन^ीकृ त भूिम या वन या ाकृ ितक वास का स'(य Zप से बढ़ावा 'दया जाएगा ।
जीण[Sार।
पयावरणीय जाग1कता ।
स'(य Zप से बढ़ावा 'दया जाएगा ।
स

मानीटरी सिमित- क(hीय सरकार, पा!रिBथितक% संवेदी जोन के

भावी मानीटरी के िलए एक मानीटरी सिमित का गठन

करे गी जो िनlिलिखत से िमलकर बनेगी, अथात् :(i)

िजला मिजB_ेट, उ;र दनाजपुर िजला, पिAम बंगाल सरकार

-अxय8;

(ii)

मुGय व>यजीव वाडन, पिAम बंगाल का

–सदBय;

(iii)

राiय

(iv)

पिAम बंगाल सरकार 'ारा गैर-सरकारी संगठन0 का

दूषण िनयं$ण का

ितिनिध

ितिनिध

–सदBय;

(पयावरण, िजसके अंतगत िवरासत संर8ण है, के 8े$ म(

काय करने वाले) नामिनSदT एक
(v)

ितिनिध

पिAम बंगाल सरकार 'ारा पा!रिBथितक% और पयावरण के
8े$ से नामिनSदT कया जाने वाला एक

(vi)

–सदBय;

कृिष िवभाग का

ितिनिध

–सदBय;

ितिनिध, पिAम बंगाल सरकार

–सदBय;

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

(vii)

(viii)
(ix)

6.

शहरी िवकास और आवास िवभाग का

[PART II—SEC. 3(ii)]

ितिनिध, उ;र दनाजपुर

िजला, पिAम बंगाल सरकार

–सदBय;

राiय सरकार 'ारा नािमत जैविविवधता का िवशेष|

–सदBय;

भारी व>यजीव अभयार?य

–सदBय सिचव।

िनद?श–िनबंधन:- (i) पा!रिBथितक% संवेदी जोन सिमित इस अिधसूचना के उपबंध0 के अनुपालन को मानीटर करे गी।

(ii) िनगरानी सिमित का कायकाल तीन वष तक या राiय सरकार 'ारा नई सिमित के पुन: गठन तक के िलए होगा और बाद

म( िनगरानी सिमित राiय सरकार 'ारा ग!ठत क% जाएगी।
(iii) पा!रिBथितक% संवेदी जोन म( भारत सरकार के तPकालीन पयावरण और वन मं$ालय क% अिधसूचना सं. का.आ.
1533(अ), तारीख 14 िसतंबर, 2006 क% अनुसूची के अधीन सिमिलत ^याकलाप0 और इस अिधसूचना के पैरा 4 के
अधीन सारणी म( िविनSदqट

ितिषo गितिविधय0 के िसवाय आने वाले ऐसे ^याकलाप0 क% दशा म( वाBतिवक िविनSदT

Bथलीय दशाw पर आधा!रत िनगरानी सिमित 'ारा संवी8ा क% जाएगी और उ/ अिधसूचना के उपबंध0 के अधीन पूव
पयावरण िनकासी के िलए के>hीय सरकार के पयावरण, वन और जलवायु प!रवतन मं$ालय को िनSदT क% जाएगी ।

(iv) इस अिधसूचना के पैरा 4 के अधीन यथा िविनSदT

ितिषo ^याकलाप0 के िसवाय, भारत सरकार के तPकालीन

पयावरण और वन मं$ालय क% अिधसूचना संGयांक का.आ. 1533(अ), तारीख 14 िसतंबर, 2006 क% अिधसूचना के अनुसूची
के अधीन ऐसे ^याकलाप0, िज>ह( सिमिलत नह5 कया गया है, परं तु पा!रिBथितक% संवेदी जोन म( आते हQ, ऐसे ^याकलाप0

क% वाBतिवक िविनSदT Bथलीय दशाw पर आधा!रत मानीटरी सिमित 'ारा संवी8ा क% जाएगी और उसे संबo िविनयामक
ािधकरण0 को िनSदT कया जाएगा ।
(v) मानीटरी सिमित का सदBय-सिचव या संबo कल&टर या संबंिधत उuान उप वन संर8क ऐसे .ि/ के िव

o, जो इस

अिधसूचना के कसी उपबंध का उलंघन करता है, पयावरण (संर8ण) अिधिनयम, 1986 क% धारा 19 के अधीन प!रवाद
फाइल करने के िलए स8म होगा ।

(vi) मानीटरी सिमित मुा दर मुा के आधार पर अपे8ाw पर िनभर रहते =ए संबo िवभाग0 के

औuोिगक संगम0 या संबo पणधा!रय0 के

ितिनिधय0 या िवशेष|0,

ितिनिधय0 या िवशेष|0 को अपने िवचार-िवमश म( सहायता के िलए आमंि$त कर

सकेगी ।

(vii) मानीटरी सिमित

Pयेक वष क% 31 माच तक राiय के मुGय व>यजीव वाडन को अपने ^याकलाप0 क% अपनी वाzषक

कार वाई !रपोट उपाबंध III म( संल

ोफामा म( उ&त वष के 30 जून तक

Bतुत करे गी ।

(viii) के>hीय सरकार का पयावरण, वन और जलवायु प!रवतन मं$ालय मानीटरी सिमित को अपने कृPय0 के

भावी िनवहन

के िलए समय-समय पर ऐसे िनदmश दे सकेगा, जो वह ठीक समझे ।

7.

अितर@ उपाय:- इस अिधसूचना के उपबंध0 को

भाव देने के िलए क(hीय सरकार और राiय सरकार अित!रक्त उपाय,

यद कोई ह0, िविनSदqट कर सक(गे ।

8.

सुीम कोट, आद केेे आदेश.- इस अिधसूचना के उपबंध, भारत के माननीय उतम >यायालय या उ >यायालय या

राq_ीय ह!रत

ािधकरण 'ारा पा!रत कोई आदेश या पा!रत होने वाले कसी आदेश, यद कोई ह0, के अधीन ह0गे ।

[फा. सं. 25/46/2016-ईएसजेड-आरई]

डॉ. सतीश च>h गढ़कोटी , वै|ािनक ‘जी’

<!-- page 11 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

11
उपाबंध I

रायगंज

वCयजीव अभयारEय केेे पारिथितक संवेेदी जोन का मानिच

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

वयजीव अभयार य के िनदशांक
बदु पर
व"यजीव
अभयार%य क&
सीमा

िड(ी

अ ांश (उ)
िमनट

सेक)) ड

1.

23

0

2.

23

3.

िड(ी

देशांतर(पू)
िमनट

सेक)) ड

1.33

88

0

14.19

59

53.37

88

0

14.13

23

59

48.34

88

0

10.28

4.

23

59

42.42

88

0

12.08

5.

23

59

38.77

88

0

7.51

6.

23

59

44.74

88

0

10.10

7.

23

59

51.12

88

0

10.52

8.

23

59

55.52

88

0

12.14

सेक)) ड

पारिथितक संवेेदी जोन के िनदशांक
बदु पर
पारि*थितक& संवेेदी
जोन क& सीमा

िड(ी

अ ांश (उ)
िमनट

सेक)) ड

िड(ी

देशांतर(पू)
िमनट

1ए

24

0

4.59

88

0

14.61

2ए

23

59

51.71

88

0

17.44

3ए

23

59

49.72

88

0

15.09

4ए

23

59

40.35

88

0

15.27

5ए

23

59

38.77

88

0

7.51

6ए

23

59

43.91

88

0

5.34

7ए

23

59

53.59

88

0

6.43

8ए

23

59

58.51

88

0

7.39

सीमाएं:-

उ;र… मौजाभाEादीगी, 8े$ािधकार सूची सं.104 और मौजा पीरोजपुर, 8े$ािधकार सूची सं.. 98
दि8ण… मौजाकोथगरम, 8े$ािधकार सूची सं..107
पूव… कुलीक नदी और मौजमोहनबती, 8े$ािधकार सूची सं.151 और मौजाबदुघाट 8े$ािधकार सूची सं.153.
पिAम… मौजासोहेराइ 8े$ािधकार सूची सं.106
उपाबंध-II

.सं

पुिलस *टेशन का
नाम

Fाम क सूची

मौजा का नाम

(ाम

ेे. हे0टेयर म)

ेे.ािधकार
सूची सं.

भूिम क& ि*थत

1

रायगंज

अबदु!गहाटा

अबदु!गहाटा

44.56

153

राजव aाम

2

रायगंज

सोहाराइ

मनीपारा,

18.30,

106

राजव aाम

खारीपारा

40.35

भाWादीगही

26.79

104

राजव aाम

3

रायगंज

भाWादीगही

<!-- page 13 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

13
उपाबंध III

पारिथितक संवेेेदी जोन मानीटरी सिमित - क गई कारवाई क रपोट का Gप िवधान

1. बैठक0 क% संGया और तारीख ।
2. बैठक0 का कायवृत : कृपया मुGय उलेखनीय tबदुw का वणन कर( । बैठक के कायवृPत को एक पृथक अनुबंध म(
उपाबo कर( ।

3. आंचिलक महायोजना क% तैयारी क%

ािBथित िजसके अंतगत पयटन महायोजना भी है।

4. भू-अिभलेख म( सदृjय $ु!टय0 के सुधार के िलए 4यौहार कए गए मामल0 का सारांश । 4यौरे उपाबंध के

प म(

संल कए जाएं ।

5. पयावरण समाघात िनधारण अिधसूचना, 2006 के अधीन आने वाली गितिविधय0 क% संिव8ा के मामल0 का
सारांश । 4यौरे एक पृथक् उपाबंध के

प म( संल कए जाएं ।

6. पयावरण समाघात िनधारण अिधसूचना, 2006 के अधीन न आने वाली गितिविधय0 क% संवी8ा के मामल0
का सारांश । 4यौरे एक पृथक् उपाबंध के

प म( संल कए जाएं ।

7. पयावरण (संर8ण) अिधिनयम, 1986 क% धारा 19 के अधीन दज क% गई िशकायत0 का सारांश ।
8. कोई अ>य महPवपूण िवषय ।

MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE
NOTIFICATION
New Delhi, the 22nd November, 2018
S.O. 5836(E).—WHEREAS, a draft notification was published in the Gazette of India,
Extraordinary, vide notification of the Government of the India in the Ministry of Environment, Forest and
Climate Change number S.O. 3343(E), dated the 12th October, 2017, inviting objections and suggestions
from all persons likely to be affected thereby within the period of sixty days from date on which copies of the
Gazette containing the said notification were made available to the public;
AND WHEREAS, the copies of the Gazette containing the said draft notification were made
available to the public on the 16th October, 2017;
AND WHEREAS, no objections and suggestions were received from all persons and stakeholders in
response to the aforesaid draft notification;
AND WHEREAS, the Raiganj Wildlife Sanctuary having an area of 1.30 sq kilometer is situated
in West Bengal and lies between 25°39’ and 25° 40’ North and longitude 88°8’ in the East; it is located in
Mouzasoharoi, Bhattadighi and Abdulghate under P.S.Raiganj, District, Uttar Dinajpur in West Bengal; the
Sanctuary has been declared vide Government order number 1901-For/11S-86/82, dated the 11th April 1985
and is very close to Raiganj Town and surrounded by human habitation and agricultural fields;
AND WHEREAS, there are 4 species of mammal, 86 species of birds, 67 species of butterflies and
30 species of fishes are identified in and around the Sanctuary, and apart from these snakes, tortoise etc. are
also found; there are no endemic species in the area; the soil is of recent alluvium and texture is loam to
clayey loam and rocks are absent as it is part of the great gangetic plains where soil depth is more than 1000
feet depth and large boulders are found in the substrata 250 to 300 feet depth and the soil is very fertile and
productive;
AND WHEREAS, the Sanctuary supports a number of species specified under Schedules – I to IV
of the Wildlife (Protection) Act. 1972 (53 of 1972) including inter alia the (1) Residential Migratory - Open
Bill Stork (Anastomus oscitans), Egrets (Ardeidae), Little Cormorant (Phalacrocorak niger), Night Heron

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(Nycticoras spp.), Kingfisher (Alcedinidae), Black Backed Woodpecker, Brown Flycatcher (Muscicapa
latirostries), Sand Lark (Calandrella rypal); (2) Residential Birds- House Crow (Corvus splendans), Parakeet
(Psittacula krameri), Spotted Dove (Streptopelia chineusis), Owls (Tyto capensis), Bulbuls, Tree Pic
(Dendrocitta vagabunda), Indian myna (Acridotheres tristis); (3) Snakes- Krait (Bngarus caeruleus), Cobra
(Naja naja), Viper (Vipera russelli) and Non-poisonous like Water snake, Keel Back, Rat snake etc; and
(4) Animal- Jungle Cat (Felis chaus), Jackal (Canis aureus), Common Fox, Common yellow bat (Scotophilus
heathi), Squirrels, Mongoose, Yellow Monitor lizard (Varanus flavescens) and others; the Sanctuary holds one
of the largest of breeding ground of Asian Open Bill stork in Asia and it also provides good habitats for the
aquatic birds like herons, cormorants and egrets;
AND WHEREAS, the kulik river which flows along the eastern site of the Sanctuary, is the
perennial source of water, besides there are a numbers of canals in the Sanctuary which provide the conducive
environment of birds and the river kulik itself and important parts of habitat, during rainy season over flowing
kulik flashes the main oxbow lake and canal within the Sanctuary; this oxbow lake is the prime source of the
birds.
NOW THEREFORE, in exercise of the powers conferred by sub-section (1) and clauses (v) and
(xiv) of sub-section (2) of section 3 of the Environment (Protection) Act 1986 (29 of 1986), read with subrule (3) of rule 5 of the Environment (Protection) Rules, 1986, the Central Government hereby notifies an
area, to an uniform extent of 100 meters from the boundary of the Raiganj Wildlife Sanctuary in the State of
West Bengal as the Raiganj Wildlife Sanctuary eco-sensitive zone (herein after referred to as the Eco-sensitive
Zone) details of which are as under, namely:1. Extent and Boundaries of the Eco-Sensitive Zone .- (1)The area of Eco-sensitive Zone is 0.12
square kilometers with uniform extent of 100 meters from the boundary Raiganj Wildlife Sanctuary .
(2) The Eco-sensitive Zone is situated in Uttar Dinajpur District of West Bengal and lies between
25°39’ and 25° 40’ North and longitude 88°8’ in the East.
(3) The map, boundary description, and co-ordinates of the Wildlife Sanctuary and Eco-Sensitive
Zone are appended as Annexure-I and the list of villages is appended as Annexure-II.
2. Zonal Master Plan for Eco-sensitive Zone. –(1) The State Government shall, for the purpose of
effective management of the Eco-Sensitive Zone, prepare a Zonal Master Plan within a period of two years
from the date of publication of this notification in the Official Gazette, in consultation with local people and
adhering to the stipulations given in this Notification for approval of Competent Authority in the State
Government.
(2) The Zonal Master Plan for the Eco-sensitive Zone shall be prepared by the State Government in
such manner as is specified in this notification and also in consonance with the relevant Central and State laws
and the guidelines issued by the Central Government, if any.
(3) The Zonal Master Plan shall be prepared in consultation with the following State Departments,
for integrating environmental and ecological considerations into the said plan:(i)

Environment;

(ii)

Forest and Wildlife;

(iii)

Agriculture;

(iv)

Revenue;

(v)

Urban Development;

(vi)

Tourism;

(vii)

Rural Development ;

(viii)

Irrigation and Flood Control;

(ix)

Municipal;

(x)

Panchayati Raj;

(xi)

Public Works Department;

<!-- page 15 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

(xii)

Highways;

(xiii)

West Bengal State Pollution Control Board.

15

(4) The Zonal Master Plan shall not impose any restriction on the approved existing land use,
infrastructure and activities, unless so specified in this notification and the Zonal Master Plan shall factor in
improvement of all infrastructure and activities to be more efficient and eco-friendly.
(5) The Zonal Master Plan shall provide for restoration of denuded and degraded areas, conservation
of existing water bodies, management of catchment areas, watershed management, groundwater management,
soil and moisture conservation, needs of local community and such other aspects of the ecology and
environment that need attention.
(6) The Zonal Master Plan shall demarcate all the existing worshipping places, villages and urban
settlements, types and kinds of forests, agricultural areas, fertile lands, green area, such as, parks and like
places, horticultural areas, orchards, lakes and other water bodies with supporting maps and the Plan shall be
supported by maps giving details of existing and proposed land use features.
(7) The Zonal Master Plan shall regulate development in Eco-sensitive Zone and adhere to
prohibited and regulated activities listed in the Table in paragraph 4 and also ensure and promote eco-friendly
development for livelihood security of local communities.
(8) The Zonal Master Plan so approved shall be the reference document for the Monitoring
Committee for carrying out its functions of monitoring in accordance with the provisions of this notification.
3. Measures to be taken by State Government.-The State Government shall take the following
measures for giving effect to the provisions of this notification, namely:(1) Land use. –Forests, horticulture areas, agricultural areas, parks and open spaces earmarked for
recreational purposes in the Eco-sensitive Zone shall not be used or converted into areas for commercial or
residential complex or industrial activities:
Provided that the conversion of agricultural and other lands, within the Eco-sensitive Zone may be
permitted on the recommendation of the Monitoring Committee, and with the prior approval of the State
Government to meet the residential needs of the local residents and for activities such as :(i)

widening and strengthening of existing roads and construction of new roads;

(ii)

construction and renovation of infrastructure and civic amenities;

(iii)

small scale industries not causing pollution;

(iv)cottage industries including village industries; convenience stores and local amenities supporting
eco-tourism including home stay; and
(v)

promoted activities given in paragraph 4:

Provided further that no use of tribal land shall be permitted for commercial and industrial
development activities without the prior approval of the State Government and without compliance of the
provisions of article 244 of the Constitution or the law for the time being in force, including the Scheduled
Tribes and Other Traditional Forest Dwellers (Recognition of Forest Rights) Act, 2006 (2 of 2007):
Provided also that any error appearing in the land records within the Eco-sensitive Zone shall be
corrected by the State Government, after obtaining the views of Monitoring Committee, once in each case and
the correction of said error shall be intimated to the Central Government in the Ministry of Environment,
Forest and Climate Change:
Provided also that the above correction of error shall not include change of land use in any case
except as provided under this sub-paragraph:
Provided also that there shall be no consequential reduction in green area, such as forest area and
agricultural area and efforts shall be made to reforest the unused or unproductive agricultural areas with
afforestation and habitat restoration activities.
(2) Natural water bodies. - The catchment areas of all natural springs, rivers and channels shall be
identified and plans for their conservation and rejuvenation shall be incorporated in the Zonal Master Plan and

<!-- page 16 -->

16

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

the guidelines shall be drawn up by the State Government in such a manner as to prohibit development
activities at or near these areas which are detrimental to such areas.
(3)Tourism.- (a) All new tourism activities or expansion of existing tourism activities within the
Eco-Sensitive Zone shall be as per the Tourism Master Plan for the Eco-sensitive Zone.
(b)The Tourism Master Plan shall be prepared by the State Department of Tourism in consultation
with State Departments of Environment and Forests.
(c) The Tourism Master Plan shall form a component of the Zonal Master Plan.
(d) The activities of tourism shall be regulated as under, namely:(i) no new construction of hotels and resorts shall be allowed within one kilometers from the
boundary of the protected area or upto the extent of the Eco-sensitive Zone, whichever is nearer:
Provided that beyond the distance of one kilometer from the boundary of the protected area till the
extent of the Eco-sensitive Zone, the establishment of new hotels and resorts shall be Permitted only in predefined and designated areas for eco-tourism facilities as per the Tourism Master Plan;
(ii) all new tourism activities or expansion of existing tourism activities within the Eco-sensitive
Zone shall be in accordance with the guidelines issued by the Central Government in the Ministry of
Environment, Forest and Climate Change and the eco-tourism guidelines issued by National Tiger
Conservation Authority (as amended from time to time) with emphasis on eco-tourism;
(iii) till the Zonal Master Plan is approved, development for tourism and expansion of existing
tourism activities shall be permitted by the concerned regulatory authorities based on the actual site specific
scrutiny and recommendation of the Monitoring Committee and no new hotel or resort or commercial
establishment construction shall be permitted within the Eco-sensitive Zone.
(4) Natural heritage.- All sites of valuable natural heritage in the Eco-sensitive Zone, such as the
gene pool reserve areas, rock formations, waterfalls, springs, gorges, groves, caves, points, walks, rides, cliffs,
etc. shall be identified and a heritage conservation within a period of six months from the date of publication
of this notification in the Official Gazette and such plan shall form part of the Zonal Master Plan.
(5) Man-made heritage sites.- Buildings, structures, artifacts, areas and precincts of historical,
architectural, aesthetic and cultural significance shall be identified in the Eco-sensitive Zone and heritage
conservation plan for their conservation shall be prepared within a period of six months from the date of
publication of this notification in the Official Gazette and such plan shall form part of the Zonal Master Plan.
(6) Noise pollution. - The Prevention and control of noise pollution in the Eco-sensitive Zone shall
be carried out with in accordance with the provisions of the noise pollution (Regulation and Control) Rules,
2000 under the Environment (Protection) Act, 1986 as amended from time to time.
(7) Air pollution.- Prevention and control of air pollution in the Eco-sensitive Zone shall be
complied with in accordance with the provisions of the Air (Prevention and Control of Pollution) Act, 1981
(14 of 1981) and rules made there under as amended from time to time.
(8) Discharge of effluents. - Discharge of treated effluent in Eco-sensitive Zone shall be in
accordance with the provisions of the Water(Prevention and Control of Pollution) Act, 1974(6 of 1974) and
the rules made there under as amended from time to time.
(9) Solid wastes. - Disposal and Management of solid wastes shall be as under:
(a)

the solid waste disposal and management in Eco-sensitive Zone shall be carried out in
accordance with the Solid Waste Management Rules, 2016, published by the Government of
India in the Ministry of Environment, Forest and Climate Change vide notification number
S.O. 1357 (E), dated 8th April, 2016 as amended from time to time;

(b)

the local authorities shall draw up plans for the suggestion of solid waste into bio-degradable
and non bio-degradable components;

(c)

the bio-degradable material shall be recycled preferably through composting or vermiculture;

(d)

the inorganic material may be disposed in an environmentally acceptable manner at site
identified outside the Eco-sensitive Zone and no burning or incineration of solid waste shall be
permitted in the Eco-sensitive Zone.

<!-- page 17 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

17

(10) Bio-medical waste. - The bio-medical waste disposal in the Eco-sensitive Zone shall be carried
out in accordance with the Bio-Medical Waste Management Rules, 2016, published by the Government of
India in the Ministry of Environment, Forest and Climate Change vide notification number GSR 343 (E),
dated the 28th March,2016 as amended from time to time.
(11) Plastic waste management.- The plastic waste management in the Eco-sensitive Zone shall be
carried out as per the provisions of the Plastic Waste Management Rules, 2016, published by the Government
of India in the Ministry of Environment, Forest and Climate Change vide notification number G.S.R. 340(E),
dated the 18th March, 2016, as amended from time to time.
(12) Construction and demolition waste management. - The construction and demolition waste
management in the Eco-sensitive Zone shall be carried out as per the provisions of the Construction and
Demolition Waste Management Rules, 2016, published by the Government of India in the Ministry of
Environment, Forest and Climate Change vide notification number G.S.R. 317(E), dated the 29th March,
2016, as amended from time to time.
(13) E-waste. - The e- waste management in the Eco-sensitive Zone shall be carried out as per the
provisions of the E-Waste Management Rules, 2016, published by the Government of India in the Ministry of
Environment, Forest and Climate Change and as amended from time to time.
(14) Vehicular traffic. - The vehicular movement of traffic shall be regulated in a habitat friendly
manner and specific provisions in this regard shall be incorporated in the Zonal Master Plan and till such time
as the Zonal Master plan is prepared and approved by the Competent Authority in the State Government, the
Monitoring Committee shall monitor compliance of vehicular movement under the relevant Acts and the rules
and regulations made thereunder.
(15) Vehicular pollution. - Prevention and control of Vehicular Pollution shall be carried out in
accordance with applicable laws and efforts shall be made for use of cleaner fuel for example CNG etc.
(16) Industrial units.- (i) No new polluting industries shall be permitted to be set up within the Ecosensitive Zone.
(ii) Only non-polluting industries shall be permitted within Eco-sensitive Zone as per classification
of Industries in the Guidelines issued by the Central Pollution Control Board in February 2016, unless so
specified in this notification, and non-polluting cottage industries shall be promoted.
(17) Protection of hill slopes.- The protection of hill slopes shall be as under.(a)

the Zonal Master Plan shall indicate areas on hill slopes where no construction shall be
permitted;

(b)

no construction on existing steep hill slopes or slopes with a high degree of erosion shall be
permitted.

4. List of activities prohibited or to be regulated within Eco-sensitive Zone.All activities in the Eco sensitive Zone shall be governed by the provisions of the Environment
(Protection) Act, 1986 (29 of 1986) and the rules made there under including the Coastal Regulation Zone
(CRZ), 2011 and the Environmental Impact Assessment (EIA) Notification, 2006 and other applicable laws
including the Forest (Conservation) Act, 1980 (69 of 1980), the Indian Forest Act, 1927 (16 of 1927) the
Wildlife (Protection) Act 1972 (53 of 1972) and amendments made thereto and be regulated in the manner
specified in the Table below, namely:—

TABLE

S. No.

Activity

Remarks

(1)

(2)

(3)
A. Prohibited Activities

1.

Commercial
mining,
stone
quarrying and crushing units.

(a) All new and existing mining (minor and major minerals), stone
quarrying and crushing units shall be prohibited except for
meeting the domestic needs of bona fide local residents
including digging of earth for construction or repair of houses
and for manufacture of country tiles or bricks for housing for
personal consumption.

<!-- page 18 -->

18

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(b) The mining operations shall be carried out in accordance with the
order of the Hon’ble Supreme Court dated the 04th August, 2006 in the
matter of T.N. Godavarman Thirumulpad Vs. UOI in W.P.(C) No.202 of
1995 and dated the 21st April, 2014 in the matter of Goa Foundation Vs.
UOI in W.P.(C) No.435 of 2012.
2.

Setting of industries including
new oil and gas exploration
causing pollution (Water, Air,
Soil, Noise, etc.).

(a) No new industries and expansion of existing polluting industries in the
Eco-sensitive zone shall be permitted.
(b) Only non-polluting industries shall be permitted within Eco-sensitive
Zone as per classification of Industries in the guidelines issued by the
Central Pollution Control Board in February 2016, unless otherwise
specified in this notification, and non-polluting cottage industries shall
be promoted.

3.

Establishment of major thermal
and major hydroelectric project.

Prohibited (except as otherwise provided) as per applicable laws.

4.

Use or production or processing
of any hazardous substances.

Prohibited (except as otherwise provided) as per applicable laws.

5.

Discharge of untreated effluents
in natural water bodies or land
area.

Prohibited (except as otherwise provided) as per applicable laws.

6.

Setting of new saw mills.

No new or expansion of existing saw mills shall be permitted within the
Eco-sensitive Zone.

7.

Setting up of brick kilns.

Prohibited (except as otherwise provided) as per applicable laws.

8.

Commercial use of fire wood.

Prohibited (except as otherwise provided) as per applicable laws.

9.

Use of plastic bags.

Prohibited (except as otherwise provided) as per applicable laws.
B. Regulated Activities

10.

Commercial establishment of
hotels and resorts.

No new commercial hotels and resorts shall be permitted within one
kilometre of the boundary of the Protected Area or upto the extent of
Eco-sensitive Zone, whichever is nearer, except for small temporary
structures for eco-tourism activities:
Provided that, beyond one kilometre from the boundary of the Protected
Area or upto the extent of Eco-sensitive Zone, whichever is nearer, all
new tourist activities or expansion of existing activities shall be in
conformity with the Tourism Master Plan and guidelines as applicable.

11.

Establishment of large-scale
commercial livestock and poultry
farms by firms, companies, etc.

Regulated under applicable laws.

12.

Construction activities.

(a) No new commercial construction of any kind shall be permitted
within one kilometre from the boundary of the Protected Area or upto
extent of the Eco-sensitive Zone, whichever is nearer:
Provided that, local people shall be permitted to undertake construction in
their land for their use including the activities listed in sub-paragraph (1)
of paragraph 3 as per building byelaws to meet the residential needs of
the local residents.
(b) The construction activity related to small scale industries not causing
pollution shall be regulated and kept at the minimum, with the prior
permission from the competent authority as per applicable rules and
regulations, if any.
(c) Beyond one kilometre it shall be regulated as per the Zonal Master
Plan.

13.

Small scale
industries.

non

polluting

Non polluting industries as per classification of industries issued by the
Central Pollution Control Board in February 2016 and non-hazardous,
small-scale and service industry, agriculture, floriculture, horticulture or
agro-based industry producing products from indigenous materials from
the Eco-sensitive Zone shall be permitted by the competent authority.

<!-- page 19 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

14.

(a) There shall be no felling of trees on the forest or Government or
revenue or private lands without prior permission of the competent
authority in the State Government.

Felling of trees.

19

(b) The felling of trees shall be regulated in accordance with the
provisions of the concerned Central or State Act and the rules made
thereunder.
15.

Collection of Forest Produce or
Non-Timber Forest Produce
(NTFP).

Regulated under applicable laws.

16.

Erection of electrical and
communication towers and laying
of
cables
and
other
infrastructures.

Regulated under applicable law. (underground cabling may be
promoted).

17.

Infrastructure
amenities.

civic

Shall be done with mitigation measures, as per applicable laws, rules and
regulation and available guidelines.

18.

Widening and strengthening of
existing roads and construction of
new roads.

Shall be done with mitigation measures, as per applicable laws, rules and
regulation and available guidelines.

19.

Under taking other activities
related to tourism like over flying
the Eco-Sensitive Zone area by
hot air balloon, helicopter,
drones, microlites, etc.

Regulated under applicable laws.

20.

Protection of hill slopes and river
banks.

Regulated under applicable laws.

21.

Movement of vehicular traffic at
night.

Regulated for commercial purpose under applicable laws.

22.

Ongoing
agriculture
and
horticulture practices by local
communities along with dairies,
dairy farming, aquaculture and
fisheries.

Permitted under applicable laws for use of locals.

23.

Discharge of treated waste
water/effluents in natural water
bodies or land area.

The discharge of treated waste water/effluents shall be avoided to enter
into the water bodies and efforts shall be made for recycle and reuse of
treated waste water, and the discharge of treated waste water/effluent
shall be regulated as per applicable laws.

24.

Commercial extraction of surface
and ground water.

Regulated under applicable laws.

25.

Open well, bore well etc. for
agriculture or other usage.

Regulated under applicable laws and the activity shall be monitored by
the concerned authority.

26.

Solid waste management/biomedical waste management.

Regulated under applicable laws.

27.

Introduction of exotic species.

Regulated under applicable laws.

28.

Eco-tourism.

Regulated under applicable laws.

29.

Commercial sign boards and
hoardings.

Regulated under applicable laws.

including

C. Promoted Activities
30.

Rain water harvesting.

Shall be actively promoted.

31.

Organic farming.

Shall be actively promoted.

<!-- page 20 -->

20

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

32.

Adoption of green technology for
all activities.

Shall be actively promoted.

33.

Cottage industries
village artisans, etc.

Shall be actively promoted.

34.

Use of renewable energy and
fuels.

Bio gas, solar light etc. shall be actively promoted.

35.

Agro-forestry.

Shall be actively promoted.

36.

Use of eco-friendly transport.

Shall be actively promoted.

37.

Skill development.

Shall be actively promoted.

38.

Restoration of degraded land/
forests/ habitat.

Shall be actively promoted.

39.

Environmental awareness .

Shall be actively promoted.

5.

including

Monitoring Committee.- The Central Government hereby constitutes a Monitoring Committee for

effective monitoring of the Eco-sensitive Zone, which shall comprise of the following, namely:-

6.

(i)

District Magistrate, Uttar Dinajpur District, Government – Chairman;
of West Bengal

(ii)

Representative of the Chief Wildlife Warden, West
Bengal

-Member;

(iii)

Representative of State Pollution Control

-Member;

(iv)

One representative of Non-Governmental Organisations - Member;
working in the field of environment (including heritage
conservation) to be nominated by the Government of
West Bengal

(v)

An expert in the area of ecology and environment to be - Member;
nominated by the Government of West Bengal

(vi)

Representative of Agriculture Department, Government of
West Bengal

(vii)

Representative of Urban
Department, Uttar Dinajpur
Bengal

(viii)

Expert in Biodiversity nominated by the State Government

-Member;

(ix)

In-charge Wildlife Sanctuary

-MemberSecretary.

-Member;

Development and Housing -Member;
District Government of West

Terms of reference.- (i) The Monitoring Committee shall monitor the compliance of the provisions

of this notification.

<!-- page 21 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

21

(ii) The tenure of the Monitoring Committee shall be for a period of three years or till the re-constitution of
the new Committee by the State Government and subsequently the Monitoring Committee shall be
constituted by the State Government.
(iii) The activities that are covered in the Schedule to the notification of the Government of India in the
erstwhile Ministry of Environment and Forests number S.O. 1533 (E), dated the 14th September, 2006, and
are falling in the Eco-sensitive Zone, except for the prohibited activities as specified in the Table under
paragraph 4 thereof, shall be scrutinised by the Monitoring Committee based on the actual site-specific
conditions and referred to the Central Government in the Ministry of Environment, Forest and Climate
Change for prior environmental clearances under the provisions of the said notification.
(iv) The activities that are not covered in the Schedule to the notification of the Government of India in the
erstwhile Ministry of Environment and Forests number S.O. 1533 (E), dated the 14th September, 2006 and
are falling in the Eco-sensitive Zone, except for the prohibited activities as specified in the Table under
paragraph 4 thereof, shall be scrutinised by the Monitoring Committee based on the actual site-specific
conditions and referred to the concerned regulatory authorities.
(v) The Member Secretary of the Monitoring Committee or the concerned Deputy Commissioner(s) shall be
competent to file complaints under section 19 of the Environment (Protection) Act, 1986 against any person
who contravenes the provisions of this notification.
(vi) The Monitoring Committee may invite representatives or experts from concerned Departments,
representatives from Industry Associations or concerned stakeholders to assist in its deliberations depending
on the requirements on issue to issue basis.
(vii) The Monitoring Committee shall submit the annual action taken report of its activities as on 31st March
of every year by 30th June of that year to the Chief Wildlife Warden in the State as per pro- forma given at
Annexure III.
(viii) The Central Government in the Ministry of Environment, Forest and Climate Change may give such
directions, as it deems fit, to the Monitoring Committee for effective discharge of its functions.
7. Additional measures.-The Central Government and State Government may specify additional measures, if
any, for giving effect to provisions of this notification.
8. Supreme Court, etc. orders.-The provisions of this notification shall be subject to the orders, if any,
passed, or to be passed, by the Hon’ble Supreme Court of India or the High Court or National Green Tribunal.

[F. No.25/46/2016-ESZ-RE]
Dr. SATISH C. GARKOTI Scientist ‘G’

<!-- page 22 -->

22

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

ANNEXURE – I
MAP SHOWING THE ECO-SENSITIVE ZONE OF RAIGANJ WILDLIFE SANCTURY

Co-ordinates of Wildlife Sanctuary
Point On
WLS
Boundary
1.
2.
3.
4.

dd

Latitude (N)
mm

sec

dd

Longitude (E)
mm

sec

23
23
23
23

0
59
59
59

1.33
53.37
48.34
42.42

88
88
88
88

0
0
0
0

14.19
14.13
10.28
12.08

<!-- page 23 -->

¹Hkkx IIµ[k.M 3(ii)º
5.
6.
7.
8.

23
23
23
23

Hkkjr dk jkti=k % vlk/kj.k
59
59
59
59

38.77
44.74
51.12
55.52

23

88
88
88
88

0
0
0
0

7.51
10.10
10.52
12.14

Co-ordinates of Eco-Sensitive Zone
Point On
ESZ
Boundary
1a
2a
3a
4a
5a
6a
7a
8a

dd

Latitude (N)
mm

sec

dd

Longitude (E)
mm
sec

24
23
23
23
23
23
23
23

0
59
59
59
59
59
59
59

4.59
51.71
49.72
40.35
38.77
43.91
53.59
58.51

88
88
88
88
88
88
88
88

0
0
0
0
0
0
0
0

14.61
17.44
15.09
15.27
7.51
5.34
6.43
7.39

BOUNDARIES:North… Mouzabhattadighi, Jurisdiction List No.104 and Mouza Pirojpur, Jurisdiction List No. 98
South…Mouzakothgram, Jurisdiction List No..107
East…Kulik River and Mouzmohanbati, Jurisdiction List No.151 and Mouzaabdulghata Jurisdiction List No.153.
West… Mouzasoharai Jurisdiction List No.106
Annexure –II
List of villages
Sl.
No.

Name of Police
Station

Name of
Mouza

1
2

Raiganj
Raiganj

Abdulghata
Soharai

3

Raiganj

Bhattadighi

Village
Abdulghata
Manipara ,
Kharipara
Bhattadighi

44.56
18.30, 40.35

Jurisdicti
on List
No.
153
106

Revenue Village
Revenue Village

26.79

104

Revenue Village

Area in
hectors

Status of Land

Annexure III
Proforma of Action Taken Report: - Eco-sensitive Zone Monitoring Committee.1.
2.
3.
4.
5.
6.
7.
8.

Number and date of meetings.
Minutes of the meetings: Mention main noteworthy points. Attached minutes of the meeting on separate Annexure.
Status of preparation of Zonal master Plan including Tourism master Plan.
Summary of cases dealt for rectification of error apparent on face of land record. Details may be attached as
Annexure.
Summary of cases scrutinised for activities covered under Environment Impact Assessment Notification, 2006.
Details may be attached as separate Annexure.
Summary of case scrutinised for activities not covered under Environment Impact Assessment Notification, 2006.
Details may be attached as separate Annexure.
Summary of complaints lodged under section 19 of Environment (Protection) Act, 1986.
Any other matter of importance.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
Digitally signed
by ALOK KUMAR
Date: 2018.11.28
12:00:22 +05'30'

ALOK
KUMAR
