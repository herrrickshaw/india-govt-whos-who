---
doc_id: "1b5eea2faf83dc2b"
source_url: "https://cdn.s3waas.gov.in/s343ec517d68b6edd3015b3edc9a11367b/uploads/2025/12/17667606587812.pdf"
ministry: "Purulia"
title: "Guidelines_Yogyashree-5K-2027_No. 967 dt 17-11-2025 (1) (272 KB)"
date: ""
pages: 5
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "f88bdd8c0921752c"
---

<!-- page 1 -->

3
Government of West Bengal
Department of Backward Classes Welfare
‘Administrative Building’, DJ — 04, Sector — II, Salt Lake City, Kolkata — 700 091
Memo No.: 967 (22)-Secy/BCW Date: 17/11/2025
From : Secretary to the Govt. of West Bengal
To : District Magistrate (All Districts)
Sub: Yogyashree - Pre-examination training of 5,000 SC, ST, General, OBC &
Minority Students for JEE/WB JEE/NEET-2027
Madam/Sir,

Two trainings for JEE/WB JEE/NEET-2026 under ‘Yogyashree’, one for 2,000 SC/ST
students & another for 3,000 Gen/OBC/Minority students have simultaneously been running
successfully. Merging of both the training programmes to bring uniformity was under active
consideration of the State Govt. for some time past. Now the State Govt has decided to merge
both the training programmes leading to a combined training scheme of total 5,000 SC, ST,
OBC, General & Minority students for JEE/WB JEE/NEET-2027 under ‘Yogyashree’ to be
undertaken through 110 centres across the State. Duration of the training will be 350 hours
including mock tests. Training cost will be proportionately shared by School Education, MA &
ME, BCW & Tribal Development Departments.

Open advertisement seeking applications from eligible students is likely to be published
by 3% week of November, 2025. Application can be submitted both on-line
(https://wbbcdev.webstep.in) & offline at the training centres. Call centres shall be set up to
assist the applicants. Classes are likely to commence from 4" January, 2026. The enrolled
students will be provided with study materials in Bengali/ English as per their choice. On-line
subject-based study materials and mock test facility will also be available.

At district level, PO-cum-DWOs/ DWOs may continue to function as Nodal Officers for
implementation of the programme while WB SC ST OBC Dev & Fin Corporation has been
assigned as Nodal Implementing Agency. School Education set up & DOMA of your District may
please be sensitized to coordinate with PO-cum-DWOs/ DWOs for successful implementation of
this programme. A detailed guideline for implementation of the scheme is enclosed herewith for
your ready reference.

Necessary arrangements may please be made also for wide publicity of the programme
to ensure larger participation.

Yours faithfully,
Encl.: As stated,
(S. Bansal, TS
Secretary to the Govt. of West Bengal
Memo No.: 967 (22)/1 (5)-Secy/BCW Date: 17/11/2025
Copy forwarded for kind information & necessary action to: -
1. The Principal Secretary, School Education Department
2. The Principal Secretary, Tribal Development Department
3. The Secretary, MA & ME Department \
4. The Commissioner, BCW & TD Dte. £
5. The Managing Director, WBSCSTOBCDFC
Secretary to the Gave of west Bengal
al

<!-- page 2 -->

Guidelines for implementation (SOP)
Pre-examination Training of SC/ST/General/OBC/ Minority Students for
JEE/WBJEE/NEET — 2027 under “Yogyashree” Scheme

1. WB SC ST & OBC Dev & Fin Corporation has been entrusted with implementation of the “Pre-
examination training for JEE/WBJEE/NEET” for the SC/ST/General/OBC/Minority students under
‘Yogyashree’ Scheme. Students aspiring for admission in Technical/ Medical education through JEE/
WBJEE/NEET 2027 can avail the opportunity. In the 1% year, 5,000 students @ 1,000 in each of the
General/OBC/Minority category & 2,000 under SC/ST categories will be taken on board in 110 centres
across the state.

2. PO-cum-DWOs/ DWOs shall continue to be the Nodal Officers at district level for implementation of this
pre-examination training also. Services of District Managers may be utilized, if required. They will
finalize the centre locations in consultation with the Corporation and intimate the same to the entrusted
Agency for execution.

3. National Computer Saksharata Mission (NCSM) having its registered office at 166/A, Canal South Road,
Metropolitan, Beliaghata, Kolkata - 700 105 has been awarded the contract for this Pre-examination
training for the 1% Year. They will select suitable classrooms in the existing venues and the Centre-in-
Charges in consultation with the schools. They will publish a detailed advertisement with co-ordinates of
110 designated centers inviting applications in prescribed format in Leading Dailies by 3° week of
November, 2025. The advertisement will also be published in “Karmasangsthan” and “Employment
News”, The advertisement shall also be published in the website of BCW, TD, MA & ME & School
Education Department as well as in the website of Corporation.

4. A copy of the advertisement and application form will be sent to all districts for further publicity through
School Education Department network, in the Notice Boards of Districts, Sub~Division and Block Offices.
PO-cum-DWOs/ DWOs may arrange further publicity through local print and audio-visual media.

5. NCSM to visit the designated centres, discuss with school authorities and make necessary arrangements
to keep the centre premises/ venue open or accessible during the application process. PO-cum-DWOs/
DWOs shall also cause to pass on necessary instructions to the centre venues through the DI of
Schools. The entire process shall be brought into the knowledge of the School Education
Department.

Page lof 4

<!-- page 3 -->

6. NCSM shall deploy centre-in-charges and provide list along with their particulars and report to the
concerned PO-cum-DWOs/DWOs about the arrangements made by them for receiving applications,
scrutiny etc.

7. Centre location, contact nos. & details of centre-in-charges shall be published in the advertisement for
convenience of the interested candidates. In addition, NCSM shall set up a dedicated Call Center to
address any issues/queries from the interested candidates. Facility for receiving on-line application has
been made available through https://wbbcdev.webstep.in. Application Forms will also be available at
the respective centres. Forms can be downloaded from the website.

8. Interested candidates may submit Offline application forms duly filled in along with necessary
enclosures to respective centers / Online application till 24/12/2025.

9. Application forms are to be scrutinized at the Center Level and list of selected candidates shall be
finalized by a committee consisting of the following Members:

a. ADM, BCW - Chairman

0. PO-cum-DWO —Member Convenor

c. Concerned SDOs — Member

d. DOMA — Member

e, DI of School (Secondary) - Member

f. Representative of entrusted Agency - Member

g. Representative of School, where the centre is located - Member

PO-cum-DWO/DWOs are to ensure constitution of the committee and hold a meeting to discuss
about application process, scrutiny, interview if required, selection of eligible candidates and preparing
merit list.

10. Criteria for selection shall be:

a. Annual family income within ₹ 3, 00,000.00.

b. Studying in Class XI (with Science Subjects having Physics, Chemistry, Mathematics, Biology)

c. Secured in 10' Standard examination at least 70% marks for General/Minority candidates, at
least 65% marks for OBC candidates, at least 60% marks for SC candidates & at least 50%
marks for ST candidates.

11. Total No. of Centres = 110 (50 + 60)

For training of SC & ST students: 40 students per centre x 50 centres = 2,000 students
For training of Gen, OBC & Minority students: 50 students per centre x 60 centres = 3,000 students
Total nos. of students = 5,000
Page 2 of 4

<!-- page 4 -->

12. For SC & ST students: The committee is to prepare merit list of 40 candidates on the basis of marks
secured in 1011 standard examination from the eligible candidates. Two separate Merit Lists, one for
SC and other for ST students shall be prepared (32 for SC Category and 8 from ST Category). In
case of non-availability of students of a particular category the quota is to be filled in from the other
category and the decision of Selection Committee shall be final. The Committee shall prepare a wait
list of additional 20 candidates on the basis of merit as a measure to fill in vacant seat subsequent
to publication of final list.

13. For Gen, OBC & Minority students: The committee is to prepare merit list of 50 candidates on the basis
of marks secured in 10% standard examination from the eligible candidates. Three separate Merit Lists,
one for General, one for Minority and one for OBC students shall be prepared (16 from General, 17
from Minority & 17 from OBC Category). In case of non-availability of students of a particular category
the quota is to be filled in from the other category and the decision of Selection Committee shall be
final. The Committee shall prepare a wait list of additional 30 candidates on the basis of merit as a
measure to fill in vacant seats after publication of the final list.

14. Center wise merit list is to be finalized by 30/12/2025 and to be mailed to: dm.scstdfc@amail.com by
31/12/2025 for publication in the websites.

15. The Selection Committee may call for an interview of eligible candidates, if it is absolutely necessary. In
such cases candidates should be called in batches at the respective venues. NCSM shall make necessary
infrastructure, hospitality and other arrangements for written test / interview. Selected candidates shall
be called to attend the class on the first day preferably on 04/01/2026 physically.

16. The selected students are entitled to get a stipend @ Rs. 300/- per month for the entire training period
provided their minimum attendance is 70%.

17. PO-cum-DWOs/ DWOs to co-ordinate with DI of Schools and make necessary arrangements for keeping
the centers open during application process, selection process and first day of class.

18.The entrusted Agency immediately after advertisement shall make necessary infrastructure
arrangements in all the 110 designated centers for holding classes. They will keep the study materials
ready along with class plan and test schedule which should be delivered to students preferably on the
very first day of orientation session.

19. The entrusted Agency shall also keep the teachers/trainers ready for holding offline & online classes.
Online classes may be held additionally.

Page 3 of 4

<!-- page 5 -->

20. There will be physical monitoring by Government Officials periodically.

21. Offline/online test both monthly and quarterly shall be held and progress of each of the students shall
be recorded.

22. The entrusted Agency to submit .a copy of study materials and all other documents relevant to the
training to the Nodal Officer of Corporation for verification and record.

23. The entrusted Agency is required to submit list of teachers/ trainers, subject wise, taken on board along
with their qualification & experience for teaching JEE/NEET students.

24. The entrusted Agency to arrange special classes through Google meet/ zoom/ their own App by expert
teachers periodically.

25. The entrusted Agency to identify meritorious students to fori : cial group and arrange residential
training.

Secretary C
Backward Classes Welfare Department
Page 4 of 4
