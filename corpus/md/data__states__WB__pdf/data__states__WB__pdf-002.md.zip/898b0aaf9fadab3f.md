---
doc_id: "898b0aaf9fadab3f"
source_url: "https://www.wbfdc.com/uploads/tender_files/Q-32.pdf"
ministry: "West Bengal Forest Development Corporation Ltd. (WBDFC), Kolkata, West Bengal"
title: "view details"
date: ""
pages: 3
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "7a349a203c55a889"
---

<!-- page 1 -->

WEST BENGAL FOREST DEVELOPMENT CORPORATION LIMITED
(A GOVERNMENT OF WEST BENGAL UNDERTAKING)
OFFICE OF THE DIVISIONAL MANAGER
টি ০০০০২ MEDINIPUR FOREST CORPORATION DIVISION
9৫ ১% HIJLI, KHARAGPUR, PASCHIM MEDINIPUR, 721306
[হু] 5 e-mail: mfcd@wbfdc.com
i, Cee, GSTIN- 19AAACW3562A5ZG
Fim -oS
Since 197"
ee
Memo No. 1661/28-38(Q)/(26-27 Dated-, Kharagpur,13.10.2026
QUOTATION No- 32/MFCD/2026-27
Sealed quotation are invited from suppliers/Reputed Firms/ Agencies /Govt.
Contractor /Resourceful contractors for Supply of Stationary and Sanitary articles at Jhargram
Prakriti Parjatan Kendra of Lodhasuli Range under Medinipur Forest Corporation Division.
Sealed quotations are to be submitted either by post or by hand by name of Shri Ayan Ghosh,
WBES, Divisional Manager,Medinipur Forest Corporation Division on or before 30.10.2026 at
5.00P.M.and same will be open in presence of Committee on 02.11.2026 at 3.00 P.M.in the office
of undersigned. Details of Terms & Conditions of such work annexed herewith.
Maximum
acceptable
sl UNIT rates per Offered rate
fig units (Inclusive all
ae" (Inclusive taxes)
| items all taxes)
01 | Goodnight Machine 112.00
Room freshener(Odonil) 1 no. 123.00 ea
141 Surf Excel (500 gm.) _ 7 1 no. 71.00 ei
৮ Harpio Toilet Cleaner (Iit) =
সি 2 a a a a
09 ) Pencil Battery (Big)(AA Eveready) 1 no.
10 | Pencil Battery (Small)(AAA Eveready) — 1 no. 18.00
Phenyl (1 Ltr.) 142.00

<!-- page 2 -->

লা
ভি
ডি ea
Tissue Roll 51.00 aa
78১
= astm rpc} ——J
2 জেদ is
228৯
Eile eA ০০াটা রে
Fe a কক
Vim Bar (Big) 1 No. ll
feof} —
2 Ee ela BAT
Toliet Cleaner Brush 1 No. 4
The quotations should reach to this office by 30.10.2026 up to 5.00 p.m. positively.
The quotations will be opened tentatitely on 02.11.2026 at 3:00 p.m. The quotationers may
remain present at the time of opening of the quotations papers.
সস
1. The quotationers will have to produce valid GSTIN certificate, Trade Licence, and PAN
2. ears is not bound to accept the lowest rate or any rate quoted may reject
any part or all work without assigning any reason.
3. The undersigned reserved the right to demand from the quotationers the clarification
and justification against their offer, if required.

<!-- page 3 -->

4. The quotationers should inspect the site of works before the submission of the
quotation.
5. All tools and plants, required for the works will have to be supplied by the contractor at
his own cost.
| 6. The Contractor is liable to pay the skilled, unskilled including transport & logistics and
other labour(if needed) the wages as mentioned in the PWD schedule in the district
currently.
7. In case of any dispute the interpretation of the undersigned will be final.
8. The execution of the works as mentioned to the schedule will have to be started as
mentioned in work order, which will pevail, except job of parpetual nature.
9. The payment will be made after completion of all work and proper checking by the
Forest Officials.
10. Work order will be issued on approval of competent authority & as per availability of
fund under suitable Head of Service.
11. Payment will be made through cheque payment only.
12. Income tax and labourCess(if applicable) will be deducted from bill.
13.Payment will be made after receiving completion certificate from the concerned
Range Manager and Bills submitted in the manner of Tax Invoice with HSN Code
indicating GSTIN of this office.
(Ay: (0917, WBFS)
Th isional Manager,
Medinipur Korest Corporation Division
No. 1661 / 28-38(Q)/ (26-27) Dated: 13.10.2026
Copy forwarded with a request to make a wide publicity through their “Notice Board to:
1. The Sabhadhipati, Paschim Medinipur Zilla Parishad.
2. The General Manager (H.Q.) West Bengal Forest Development Corporation Ltd.
3. The Divisional Forest Officer, Medinipur, Jhargram, Rupnarayan, Kharagpur&Purba
Medinipur Forest Division.
4. The Divisional Manager, Kolkata/Bankura/Purulia Forest Corporation Division.
5. The District Information Officer, PaschimMedinipur.
6. All Range Managers, Medinipur Forest Corporation Division.
7. Asstt. Accounts Officer, Medinipur Forest Corporation Division.
8. Notice Board.
(Ay sh,-WBFS)
The ional Manager,
5 Medini Forest Corporation Division
