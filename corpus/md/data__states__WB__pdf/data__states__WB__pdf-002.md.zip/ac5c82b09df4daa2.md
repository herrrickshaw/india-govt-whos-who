---
doc_id: "ac5c82b09df4daa2"
source_url: "https://www.bankurauniv.ac.in/uploads/tempimagepdflink/1679719746.pdf"
ministry: "Bankura University, West Bengal"
title: "Tender Notice for printing & supply of Identity Cards for the students"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8c274905c9325e37"
---

<!-- page 1 -->

BANKURA UNIVERSITY
(West Bengal Act XIX of 2013- Bankura University Act, 2013)
Main Campus, Bankura Block-II, P.O.: Purandarpur,
Dist.: Bankura, Pin- 722155, West Bengal

Office of the Registrar
.............................................................................................................................................................................................
No: RO/BKU/251/2023
Date: 24/03/2023

Tender Notice
Sealed quotations are invited from the reputed Print House, Agencies and Vendors for Printing & supply of
Identity Cards for the students of the Bankura University.
The quotations are to be submitted to the Registrar, Bankura University, Bankura Block-II, P.O.Purandarpur, Bankura, Pin- 722155. Last date of submission of quotation is on 31.03.2023 up to 3.00 p.m.
Eligibility criterion of participation in the tender:
a) Bonafide, resourceful and reliable Vendors/Print Houses.
b) An undertaking should be given stating thereby that the firm has not been debarred or penalized for any
reasons out of work by any Government Department.
c) Subletting of suppliers is strictly prohibited.
d) The prospective bidders must have valid upto date clearance of Income Tax return / Professional Tax
clearance certificate / P.T (Deposit Challan) / PAN Card / GST registration certificate.
e) The prospective bidders must have valid Trade License/ Enlistment.
f) The suppliers who have been delisted or debarred by any government department shall not be eligible in
any way.
g) Past performance for vender will be judged (please attached three largest clients other than the Bankura
University).
h) Rate is to be inclusive of all taxes and transport charges etc.
i) The rates will be valid upto 30.09.2023.
j) The University reserves the right to accept or reject any quotation without assigning any reason
whatsoever.
Detail specifications of the identity cards are given below:
Sl.
No.

Name of the
Item

1.

Identity Card
for the
Students

Quantity
/Number

Specifications
300 GSM Paper with laminated, multicolor both side printing, size8.5 cm X 5.5 cm and Blue colored ribbon with transparent Holder
(Printed Bankura University on the ribbon)

800 Nos

*Note : Quantity/Number may be changed.
Sd/Dr. Saurabh Dutta
Registrar (Addl. Charge)
Bankura University

<!-- page 2 -->

Memo No. RO/BKU/251/2023

Date: 24/03/2023

Copy Forwarded to:
1. The Finance Officer, Bankura University.
2. System Administrator, Bankura University with a request to upload the notice in the university website
3. Central Store, Bankura University
4. Office Notice Board.
5. Guard file
Sd/Dr. Saurabh Dutta
Registrar (Addl. Charge)
Bankura University
