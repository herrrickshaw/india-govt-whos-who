---
doc_id: "77dbf0cfe9ca335c"
source_url: "https://kolkatatrafficpolice.gov.in/OrderofSCofIndia_Sbus.pdf"
ministry: "Kolkata Traffic Police, West Bengal"
title: "Guidelines for carrying school children in different categories of Contract Carriages like motor cabs / maxi-cabs / omni buses etc."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6c48f13ab8404ca6"
---

<!-- page 1 -->

Guidelines to be strictly followed for carrying school children
to and from schools in different categories of Contract Carriages
like motor cabs / maxi-cabs / omni buses etc.

Hon’ble Supreme Court of India was pleased to issue elaborate instructions in W.P. (Civil)
13029 of 1985 regarding steps to be taken for transport of school children to and from schools in school
buses. In view of the said orders of Hon’ble Supreme Court of India, the following guidelines are being
issued for carrying school children to and from schools in different categories of motor cabs / maxi-cabs
/ omni buses etc. :
1.

There must be appropriate permit for the vehicle issued by competent authority as
‘passenger transport vehicle’.

2.

‘On School Duty’ must be permanently written on the back and front of every vehicle
carrying such school children.

3.

No such vehicle shall carry children in excess of its permitted seating capacity. No child
should be allowed to sit on the lap of others, if any.

4.

There must be a First-aid box and drinking water strictly in the vehicle.

5.

The seat belts, wherever applicable, must be fastened properly.

6.

School name and telephone no. must be displayed.

7.

Every vehicle for carrying school children must be driven by a driver, who has minimum 5
years of experience in driving such categories of vehicles and must not have any record of
previous traffic offences.

8.

Whenever a contract carriage is used for carrying school children, the owner of the vehicle
must give intimation to the O.C. of local police station as well as to D.C. (Traffic),
Kolkata Police / S.P. of the district indicating the name of the driver and particulars of the
vehicle etc.

9.

There must be an attendant in every such vehicle to ensure safe travel of the children and
render adequate assistance for safe embarking and dis-embarking of the children.
----------
