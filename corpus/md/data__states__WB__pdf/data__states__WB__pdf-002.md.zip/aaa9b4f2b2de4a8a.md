---
doc_id: "aaa9b4f2b2de4a8a"
source_url: "https://kolkatatrafficpolice.gov.in/TA_Korunamoyee.pdf"
ministry: "Kolkata Traffic Police, West Bengal"
title: "Traffic advisory in connection with Closure of Korunamoyee Bridge."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "39467c40bd970e48"
---

<!-- page 1 -->

Traffic Advisory

Notice is hereby given for the information of public that the Korunamoyee Bridge shall
remain closed for vehicular traffic from 09.00 hrs of 11-05-2020 to 05.00 hrs of 14-05-2020 for
conducting
Static
Load Test, Dynamic Load Test, Benkelman Bear Beam Deflection Test,
undertaken by KMDA. During full closure of Korunamoyee Bridge, vehicular circulation will be
made in the following manners:
1) North/East bound big vehicles, availing Korunamoyee Bridge from M G Road or M L Gupta
Road or James Long Sarani, will avail D H Road for their onward journey.
2) North/East bound small vehicles, availing Korunamoyee Bridge from M G Road or M L Gupta
Road or James Long Sarani, will be diverted from Korunamoyee Crossing to avail B L Shah
Road from Siriti Crossing.
3) South bound all types of vehicles of D P S Road, availing Korunamoyee Bridge, will be diverted
from D P S Road/ T C Road Crossing via T C Road.
4) South bound small vehicles of D P S Road, availing Korunamoyee Bridge, will also be diverted
from D P S Road/ Izzatullah Lane Crossing via Izzatullah Lane – B L Shah Road.
5) Vehicles coming from N S C Bose Road, for Korunamoyee Bridge, will be diverted from D P S
Road/ N S C Bose Road Crossing via Izzatullah Lane – B L Shah Road or via T C Road.
This will come into force from 09.00 hrs of 11-05-2020 and will continue up to 05.00 hrs of
14-05-2020.

Published in the interest of public by Kolkata Metropolitan Development Authority and
Kolkata Police.
--------------------------------------------------
