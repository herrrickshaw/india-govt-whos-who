---
doc_id: "aa1e1f66fc4e15ae"
source_url: "https://finance.wb.gov.in/writereaddata/Compendium_of_Important_Government_Orders.pdf"
ministry: "Finance Department, West Bengal"
title: "Download"
date: ""
pages: 264
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "288cde2a95cd95ee"
---

<!-- page 1 -->

COMPENDIUM OF
IMPORTANT GOVERNMENT ORDERS OF
THE FINANCE DEPARTMENT

Finance Department,
Government of West Bengal

January, 2013

<!-- page 2 -->

COMPENDIUM OF
IMPORTANT GOVERNMENT ORDERS OF
THE FINANCE DEPARTMET

Finance Department,
Government of West Bengal

January, 2013
i

<!-- page 3 -->

Principal Secretary
Finance Department
Government of West Bengal
Writers’ Buildings
Kolkata 700 001
: 033-2214 3695, Fax: 033-2214 1391
e-mail: fs-wb@nic.in

H.K. Dwivedi, IAS

8th January, 2013.

PREFACE
The Finance Department has during the recent period issued various notifications and
circulars pertaining to delegation of administrative and financial powers, amendments in
financial rules, procurement of Goods and Services, Public-Private Partnership and such
other matters. It was felt that a compilation of the notifications and circulars should be brought
out in the form of a compendium to serve as a ready reference for the administrative
departments.
In bringing out this compendium, I have received sincere assistance from the officers
of the Finance Department and the Directorate of Treasuries & Accounts, Government of
West Bengal.
Utmost care has been taken to make the compendium exhaustive and error free.
However, errors and omissions, if any, should be brought to the notice of the Finance
Department, Government of West Bengal for necessary rectification.

( H.K. Dwivedi )
Principal Secretary
Finance Department
Government of West Bengal

<!-- page 4 -->

iv

<!-- page 5 -->

INDEX
Related to

Sl.no.

Order no.
and date

Gist of the order

Page
no.

Delegation of power
Financial power - Plan

1

No.1880-F
dt.7.3.07
No.8651-F(Y)
dt.24.8.2010
No.8325-F(Y)
dt.24.8.2011
No.9144-F(Y)
dt.22.9.11
No.95-FB
dt.18.4.2012
No. 10184-F(A-II)
dt. 13.12.2012

Administrative approval upto Rs.3 crore to be
given by DAC
Procedure for according administrative approval
to plan projects by DAC
Enhancement of financial power of DAC for
projects/schemes for which GOI assistance available
Power of DAC for administrative approval
enhanced from Rs.3 crore to Rs.5 crore
Administrative approval to project/scheme upto
Rs.10 lakh may be given by Departmental Secretary
Method of according administrative & financial
approval to projects involving inter-departmental
transfer of project land
Corrigendum of 10184-F(A-II) dt. 13.12.2012

3-4

Delegated power of purchase for IT and
communication items in amendment of item no.
29 of Schedule ‘A’ of DFPR, 1977.
Memo. no.96-FB
Unlimited power of DAC to accord administrative
dt.18.4.12
approval to the schemes approved by HLMC under
13th Finance Commission
No.3053(14)-FB
Administrative approval and financial sanction
dt.17.03.2012
to BRGF schemes
No.2425-FB
Addl.Chief Secretary/Principal Secretary/Secretary
dt.27.12.2011
of 14 administrative departments empowered to
release central share and state matching share
subject to some conditions.
No.801-FB
Validity of FD order no.2425-FB dt,27.12.2011
dt.31.7.2012
extended upto 31.3.2013
No.152-FB
FA’s Power of administrative approval and fund
dt.27.4.2012
release for plan and non-plan schemes other than
new scheme. Administrative approval to plan
schemes upto Rs.10 crore (applicable to 6 dptts)
No.5275-F(Y)
Post related to IFA system created in 6 adminisdt.21.6.2012
trative dptts including the posts of FA and DFA.
Memo. no.1056-FB FA’s Power to accord administrative approval for
dt.10.9.12
13th Finance Commission and BRGF schemes.
Responsibility of budget preparation, expenditure
monitoring, budgetary control and reconciliation
of departmental accounts with AGWB’s Books
(applicable to 6 dptts)
No.1232-F(Y)
Addl.Chief Secretary/Principal Secretary/Secretary
dt.09.02.2012
of the Department given authority to retain and
hire vehicles subject to some conditions.

11-12

2
3
4
5
6

7
Financial power Plan/Non-Plan

8

Financial power Finance Commission

9

Financial power BRGF
Financial power Central Sector/
Centrally sponsored/
Centrally assisted
State Plan

10

Financial power - Plan
and Non-Plan‘Integrated Financial
Adviser’ system

11(1)

11(2)
12(1)

12(2)
12(3)

Hired vehicles

13

No. 10257-F(A-II)
dt. 18.12.2012
No.5320-F(Y)
dt.22.6.2012

5
6
7
8
9

10

13

14
15-18

19
20-24

25
26-28

29

v

<!-- page 6 -->

Related to

Sl.no.

Financial power – Plan
(medical college)

14

Order no.
and date

Administrative approval may be accorded by the
CLAC with concurrence of FA of the committee
to the following original, replacement and
renovation works:—
i. individual project cost not exceeding Rs.10 lakh
for civil works;
ii.individual project cost not exceeding Rs.5 lakh
for electrical works.
Financial power 15
No.3687-F(Y)
Power delegated to pay security agencies minimum
Security agency charge
dt.2.5.2012
wages fixed by the labour dptt without FD approval
Service matters
16(1) No.1885-F(P)
Some specified service matters delegated to the
dt.02.03.2012
Administrative groups for decision within rules
without reference to Group-P
16(2) No.3266-F(P)
Some more specified service matters delegated
dt.18.4.2012
to the Administrative groups for decision within
rules without reference to Group-P
RURAL INFRASTRUCTURE DEVELOPMENT FUND (RIDF)
RIDF
17(1) No.964(27)LDA with UC may be furnished by the nodal
FB/O/4P-25/12
officer of the Departments straightaway to
dt.27.8.12
NABARD
17(2) No.976(27)Specimen signature of nodal officers to be sent to
FB/O/4P-25/12
NABARD through FD
dt.28.8.12
WBFR (Tender rules)
Purchase (tender
18(1) No.5400-F(Y)
(a)Purchase by quotation, tender- earlier limit
rule) amendment of
dt.25.6.12
enhanced,(b)purchase by two-bid tender,
WBFR
(c) purchase through DGS&D and NICSI rate
contract, (d) works authorized to be executed
through agency PSUs against fees.
18(2) No.8183-F(Y)
Amendment of 5400-F(Y) dt.25.6.12
dt.26.9.12
18(3) No.9754-F(Y)
Procedure of re-tender
dt.03.12.2012
Amendment of
19
Memo. no.8648Note – 1 below sub-rule (3) of Rule 47A of WBFR
purchase policy
F(Y) dt.12.10.12
deleted withdrawing the preferential treatment
earlier given to Mackintosh Burn, Westinghouse
Saxby Farmer and Britannia Engineering while
making purchase.
e-tender
20(1) No.3739-F(Y)
Mandatory publication of e-tender on e-tender
dt.3.5.12
portal
20(2) No.4109-F(Y)
Designated Nodal Officers for e-tender facilitation
dt.17.05.2012
20(3) No.5424-F(Y)
Dptts may adopt e-tender for value less than
dt.26.06.2012
Rs.50 lakh
20(4) No.6424-F(Y)
Formation of state level core committee for e-tender
dt.25.7.12
20(5) No.9701-F(Y)
e-Tender facilitation measures
dt.30.11.2012

vi

No.2895-F(Y)
dt.5.4.2012

Gist of the order

Page
no.
30-32

33
34-35

36-37

41

42

45-51

52-53
54-55
56

57-64
65
66
67
68-70

<!-- page 7 -->

Related to

Sl.no.

Order no.
and date

Works tender acceptance and contract
Works contract
21
No.8182-F(Y)
dt.26.9.2012
Technical
22(1) No.6427-F(Y)
Sanction/Tender
dt.25.7.12
acceptance
22(2) No. 5458-F(Y)
dt.27.6.12
GRANT-IN-AID
Grant-in-aid
23(1) No.8327-F(Y)
dt.3.10.2012
23(2) No.2552- F(Y)
dt.27. 3.2012
PUBLIC-PRIVATE-PARTNERSHIP (PPP)
PPP policy and
24(1) No.5266-F(H)
guideline
dt.21.6.2012
24(2) No.5811-F(H)
dt.6.7.2012
24(3) No.6522-F(H)
dt.27.7.2012
24(4) No.5267-F(H)
dt.21.6.2012
24(5) No.6524-F(H)
dt.27.7.2012
24(6) No.6523-F(H)
dt.27.7.2012
24(7) FS-116(PPP
cell)/2012
dt.10.09.2012
24(8) No.119/PPP-C
dt.04.10.2012
Treasury and Government Receipts
Government receipts
25(1) No.6426-F(Y)
dt.25.07.2012
25(2) No.8298-F(Y)
dt.3.10.2012
25(3) No.9668-F(Y)
dt.30.11.2012
25(4) No. 10578-F(Y)
dt. 28.12.2012
Recruitment and service related
Annual increment
26
No.5760-F(P)
dt.7.6.2011
Casual workers

27

No.9008-F(P)
dt.16.09.2011

Gist of the order

Page
no.

Amendment of clause 25 related to dispute
resolution of works contract
Clarification of memo. no.5458-F(Y) dt.27.6.2012

73-74

Delegated Power of engineers to accord technical
sanction and accept works tender

76-77

Revised form of utilization certificate

81-82

Standard format of grant-in-aid sanctioning order

83-87

PPP policy resolution of the State Government

91-98

Amendment of para 4 of 5266-F(H) dt.21.06.2012.

99

Amendment of para 6.2 (ECOS) of resolution
no.5266-F(H) dt.21.6.2012
Finance Department designated as Nodal Dptt
for PPP
Constitution of Empowered Committee of
Secretaries for PPP
Creation of PPP cell in Finance Dptt. Budget
branch
Panels of pre-qualified Transaction Advisers for
PPP

100

75

101
102
103
104-106

Process for seeking financial bids from empanelled 107-130
TAs and preparation of project information sheet
for proposed PPP projects
More banks authorized to do Govt receipts
133
transactions
Receipts of tax and non-tax revenue through
134-146
Government Receipt Portal System (GRIPS)
List of Banks authorized to do Government
147-148
transactions.
Revised procedure for Over the Counter Receipt
149
through GRIPS & inclusion of more Banks in GRIPS.
DDO authorized to grant annual increment
without any formal increment order from the
HOO/ controlling officer
Amendment in service conditions of casual/daily
rated/contractual workers employed in Govt
dptts/directorates/regional offices etc.

153
154-156

vii

<!-- page 8 -->

Related to

Sl.no.

HB loan

28

Leave

29

Asset statement

30

GPF

31

Recruitment rules &
Change of date of
birth
Creation of posts and
filling up of vacancy

32
33(1)
33(2)

Order no.
and date
No.2233-FB
dt.29.11.2011
No.1364-F(P)
dt.15.02.2012
No.1853-F(P)
dt.02.03.2012
No.8912-F(J)
dt.01.11.2012
No.9145-F(P)
dt.09.11.2012
No. 1488-F(P)
dt. 20.02.2012
No. 707-F(P)
dt. 24.01.2012
No.9266-F(P)
dt.16.11.2012

Subsistence allowance

34

Office procedure
Receipt and dispatch
of official letters

35

No.3289-F(H)
dt.19.04.2012

File tracking system

36

No.1340-F.B.
dt.01.11.2012

e-Payment of salary and COSA
e-payment of salary
37
COSA

38(1)
38(2)

No.6261-F(Y)
dt.17.6.11
No.1829-F(Y)
dt.1.3.12
No.6037-F(Y)
dt.13.7.2012

38(3)

No.4111-F(Y)
dt.17.5.2012
38(4) No.9368-F(Y)
dt.20.11.2012
38(5) No. 10618-F(Y)
dt. 31.12.2012
Financial management of Forest Department
Withdrawal of fund
39
No.5020-F(Y)
by Forest offices
dt.15.6.2012
Pension
New Pension Scheme
for All India Services

viii

40

No.1069-F(Y)
dt.03.02.2012

Gist of the order

Page
no.

HB Loan ceiling withdrawn for the employees
taking loan from Banks
Child Care Leave for female state Govt. employees

157
158

Revised procedure of preparation and submission
159
– assets, articles costing less than two months
basic pay need not be mentioned
GPF subscriptions can be changed within a
160
financial year more than once
Amendment of WB(recruitment to clerical cadre) 161-162
rules, 2010 for recruitment through Staff selection
commission
Proposals with information to be furnished in
163
attached format to Finance Department
When change in date of birth is permissible
164
Procedure of review of subsistence allowance-note 165-166
below rule71(4) of WBSR,Pt-I
Changed procedure of receipt and dispatch of
169-173
letters/articles/files through Department of Posts
(for Govt. offices located at Writers, Buildings,
N.S.Sctt Bldgs, Bhabani Bhavan, Alipore and
Purta Bhavan, Salt lake.
Web-enabled workflow based file tracking system 174-175
introduced in Finance Department
Modification of e-payment of salary system

179-181

Upgraded COSA package as suggested by 13th
182-194
FC, technical support and infrastructure
development for the package
Extension of date for mandatory use of COSA
195-200
package for salary bills and manner of procurement
of hardware to be used for the purpose
Mandatory use of COSA package and procurement 201
of computer in anticipation of allotment
Date for mandatory use of COSA package
202-203
extended to 01.03.2013
e-paymant system extended to all Government
204-206
Payments
Amendment of WBTR,2005 in consonance with
209-216
the revised procedure of financial management of
the Forest offices
Procedure of operationalising NPS for all India
219-250
Service officers of West Bengal Cadre and role and
responsibilities of the stakeholders of the system.

<!-- page 9 -->

Finance Department

DELEGATION OF POWER

Delegation of Power

1

<!-- page 10 -->

Important Government Orders

2

Delegation of Power

<!-- page 11 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Writers’ Buildings, Kolkata – 700 001.
No. 1880-F

March 7, 2007

MEMORANDUM
Sub.: Procedure for according administrative approval to plan projects/ schemes
The Governor is pleased to lay down the following procedure for according administrative approval to
plan projects/ schemes:
A.

Projects/ schemes with project cost not exceeding Rs.3 crore.

1. Each Department shall constitute a Departmental Approval Committee (DAC) comprising of the
following:
(i)

Additional Chief Secretary / Principal Secretary / Secretary

- Chairman

(ii) Special Secretary (or where there is no Special Secretary, the
Joint Secretary) in Charge of the Administrative Group of the
Finance Department that corresponds to the Administrative
Department

- Member

(iii) Technical Head of the Department, or the head of the
Directorate entrusted with implementation of the scheme

- Member

(iv) Special Secretary / Joint Secretary of the Department as may be
nominated by the Additional Chief Secretary / Principal Secretary/
Secretary

- Member

2. All plan projects / schemes with project cost not exceeding Rs.3 crore shall be placed before the
DAC. The Special Secretary or the Joint Secretary, as the case may be, of the Finance Department shall
perform the function of Financial Advisor (F.A.) of the Administrative Department in the DAC. The F.A. shall
play a key role in the Committee and in his absence no meeting of the DAC shall be held.
3. The Committee shall have the power to accord administrative approval of projects/schemes with
cost estimate not exceeding Rs.3 crore.
4. No project / scheme shall be approved by the DAC without the consent of the F.A. The specific
opinion of the F.A. in regard to all the schemes will have to be recorded in the proceedings of the meeting.
5. Where the F.A. does not give his consent for approval of a project / scheme, he will give his reasons
for disagreement, which will form part of the proceedings of the meeting.
6. A statement of projects / schemes approved by the DAC along with a record of proceedings shall be
handed over to the F.A. in duplicate, who will return one copy to the Administrative Department with the
U.O. Number of the Finance Department forthwith.
7. If notwithstanding the note of dissent of the F.A., the Department is still of the view that the proposal
should be pursued, then it should be sent to Finance Department for consideration.
Delegation of Power

3

<!-- page 12 -->

Important Government Orders
Projects / schemes with project cost exceeding Rs.3 crore but not exceeding Rs.20 crore.

B.

In case of plan projects / schemes for which the project cost exceeds Rs.3 crore but does not exceed
Rs.20 crore. Administrative Department shall send the proposal to the Finance Department with all
relevant particulars including the estimate of the projects duly vetted by the competent technical authority.
The proposal shall include the objectives of the project, the benefits accruing out of it, the means of
financing, etc. and shall also contain a statement indicating how the project / scheme fits in the overall
perspective plan of the Department. Decision shall be taken by the Finance Department after due
examination of the project.
C.

Project with project cost exceeding Rs.20 crore.
The plan projects / schemes for which the project cost exceeds Rs.20 crore shall be referred to the
State Planning Board in the first instance with all relevant details as mentioned under (B) above and
thereafter the same shall be sent to Finance Department along with the observations of the State Planning
Board. Decision shall be taken by the Finance Department keeping in view the recommendation of the
State Planning Board.
This supersedes all previous notifications / orders on the subject.
Appropriate amendment to the Delegation of Financial Power Rules will be made in due course.

Sd/- Samar Ghosh
Principal Secretary to the
Government of West Bengal.

4

Delegation of Power

<!-- page 13 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 8651-F(Y)

Date :24.8.2010

MEMORANDUM
Sub.: Procedure for according administrative approval to plan projects/ schemes
In continuation of this Department Memorandum no. 1880-F dt.07.03.2007, the undersigned is
directed to state that:i)
Projects / schemes under State Plan and having project cost more than Rs.3.00 (three) crores which
are submitted by different departments to Finance Deptt., for concurrence should have the approval of
the Minister-in-charge / Minister of State in-charge of the concerned department; and
ii) Only those plan projects / schemes for which the State share of project cost exceed Rs.20 crore need
be placed before the State Planning Board before sending the same to Finance Department for concurrence.

Sd/- C.M. Bachhawat
Principal Secretary to the
Government of West Bengal.

Delegation of Power

5

<!-- page 14 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 8325-F(Y)

Kolkata, the 24th August, 2011

MEMORANDUM
Sub.:

Enhancement of power of Departmental Approval Committee to accord administrative
approval of projects / schemes

In continuation of this Department Memorandum No. 1880-F dated 07.03.2007 read with Memorandum
no. 8651-F(Y) dt.24.08.2010, the undersigned is directed to state that the Governor is pleased to enhance the
power of the Departmental Approval Committee (DAC) to accord administrative approval of project / schemes
from the existing Rs.3.00 crore to Rs.5.00 crore, where such projects are under Aided/Government of India
schemes with partial contribution or 100% contribution from Government of India, such as Central Sector
schemes, Centrally Sponsored schemes or schemes with Additional Central Assistance from Government of
India under State Plan or otherwise.
Necessary amendments to the Delegation of Financial power Rules will be made in due course.

Sd/- C.M. Bachhawat
Principal Secretary to the
Government of West Bengal
Finance Department.

6

Delegation of Power

<!-- page 15 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 9144-F(Y)

Kolkata, the 22nd September, 2011

MEMORANDUM
Sub.:

Enhancement of power of Departmental Approval Committee to accord administrative
approval of projects / schemes

In modification of this Department Memorandum no.8325-F(Y) dt.24.8.2011, read with Memorandum
no.8651-F(Y) dt.24.8.2010 the undersigned is directed to state that the Governor is pleased to enhance the
power of the Departmental Approval Committee (DAC) to accord administrative approval of all Plan projects
/ schemes from the existing Rs.3.00 crore to Rs. 5.00 crore, whether such projects are under State Plan or
under Aided / Government of India schemes with partial contribution or 100% contribution from Government
of India, such as Central Sector Schemes, Centrally Sponsored schemes or schemes with Additional Central
Assistance from Government of India under State Plan or otherwise.
Necessary amendments to the Delegation of Financial power Rules will be made in due course.

Sd/- C.M. Bachhawat
Principal Secretary to the
Government of West Bengal
Finance Department.

Delegation of Power

7

<!-- page 16 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Budget Branch
No. 95-F.B.

Dated, Kolkata, the 18th April, 2012

MEMORANDUM
Sub.:

Delegation of power to the Departmental Secretaries for according administrative
approval to the schemes where the cost estimate is limited to Rs. 10.00 lakhs.

In this Department Memo no. 1880-F dated 7.3.2007, it was laid down that the Department Approval
Committee shall have the power to accord administrative approval to the schemes with cost estimate not
exceeding Rs. 3.00 crore. This was further modified under this Department Memo no. 9144-F(Y) dt.22.9.2011
and the power of the Department Approval Committee to accord administrative approval was enhanced from
Rs. 3.00 crore to Rs. 5.00 cr. The power of sanctioning expenditure for administratively approved schemes are
delegated to the Departmental Secretaries in the orders issued by the Finance Department for allotment of
fund.
2. The Government has been considering, for some time past, for delegation of power to the
Departmental Secretaries for according administrative approval to the schemes.
3. After a careful consideration of the matter, the Governor has been pleased to decide to delegate
power to the Additional Chief Secretary/Principal Secretary/Secretary of the Administrative Departments for
according administrative approval to the scheme where the cost estimates is limited to Rs. 10.00 lakhs subject
to the following conditions.
(I)

No creation of new post is involed

(II) No purchase of new vehicle is involved
(III) For purchase of office equipments and installation of new telephones existing orders of the
Finance Department are followed.
4. While issuing administrative approval, the Administrative Departments should indicate the following
in such order.
“This order issues in exercise of powers delegated under Finance Department Memo. No. 95-F.B.
dated 18.04.2012”.

(A.R. Chakraborty)
Special Secretary

8

Delegation of Power

<!-- page 17 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 10184-F(A-II)

Dated, the 13th December, 2012

NOTIFICATION
Sub.:

Administrative and financial approval for the projects on land involving interdepartmental transfer.

The procedure of inter-departmental transfer of Govt. land from one Department of the State Govt. to
another is governed by Rule 469 of the West Bengal Land & Land Reforms Manual, 1991. The extract of the
Rule is given as under:
“469 (i) Proposals for transfer of Government land from one department of the State Government to another
should be submitted through Divisional Commissioner to Government in the department to which transfer is
proposed along with objects and condition of the proposed transfer, particulars of the area, market value and
estimated yearly rental.
(ii) If the administrative department approves the proposal, it will first consult the department from
which land is proposed to be transferred. The proposals with the concurrence of the department owning the
land will be sent to the Land & Land Reforms Department. The Land & Land Reforms Department will return
the case to the administrative department with the memorandum sanctioning the transfer of the land and
stating conditions of transfer, if any. The administrative department will then send a copy of the said
memorandum to the officers concerned accompanied by such orders as may be necessary.”
2. It has been observed that, in some cases, even after concurrence has been given by the Govt.
department owning the land to relinquish the said land in favour of the other State Govt. department, the
completion of all formalities as provided in Rule 469 of the WBL&LR Manual, 1991, takes some time. As per
the existing practice, administrative and financial approval of the projects on such land is not given pending
approval of the L&LR Department as provided in the referred Rule. As such, there is avoidable delay in starting
such projects resulting in cost and time overrun.
3. After careful consideration, the Governor is pleased to decide that development projects on Govt.
land proposed for transfer from one department to another will be accorded administrative and financial
approval by the appropriate authority provided the Collector of the District has recommended the proposal
after making inquiries regarding the area, ownership, availability, character, nature of the land and whether
the land is free from encroachment and litigation and administrative department of the State Govt. owning the
land has given its concurrence for relinquishing such land in favour of the requiring department. The
administrative department to which the land is proposed to be transferred shall not start the execution of the
project unless all the formalities as provided in Rule 469 of the WBL&LR Manual, 1991 have not been fully
complied with. It may, however, complete all other works like completion of tender formalities, selection of
executing agencies, etc.
4.

The order will take immediate effect.

Sd/- H.K.Dwivedi
Secretary to the
Government of West Bengal
Delegation of Power

9

<!-- page 18 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 10257-F(A-II)

Dated, the 18th December, 2012

CORRIGENDUM
The last but one sentence of Para No.3 of Notification No.10184-F(A-II) Dated, the 13th December,
2012 should be read as "The administrative department to which the land is proposed to be transferred shall
not start the execution of the project till all the formalities provided in Rule 469 of the WBL&LR Manual, 1991
have been fully complied with".

Sd/- D. Mukhopadhyay
Joint Secretary to the
Government of West Bengal

10

Delegation of Power

<!-- page 19 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 5320-F(Y)

Dated, Kolkata, the 22nd June, 2012.

NOTIFICATION
In exercise of the power conferred by clause (3) of article 166 of the Constitution of India the Governor is
pleased hereby to make the following amendment in the Delegation of Financial Power Rules, 1977 published
under this Department’s Notification No. 9751-F dated 17.11.1977, as subsequently amended (hereinafter
referred to as the ‘said rules’)

AMENDMENT
In the said rules, in Schedule ‘A’ under Rule (18), insert new entries after item no.29(b) as given belowItem
no.

Items of
expenditure

S.D.O/
Head of office

District officers
(collectors in
charge of a
district)

Heads of Dptt
(other than
Additional Chief
Secretary /
Principal Secretary
/ Secretary /
Commissioner.

Additional Chief
Secretary /
Principal
Secretary /
Secretary /
Commissioner

29

(c) Purchase and
repairs of
computer with
peripherals
including UPS and
printer, LAN,
Storing devices,
such as, Pen drive,
CD, Removable
hard discs
(d) Broadband
connection in
already installed
landline telephone.
(e) Purchase and
repair of
photocopier & Fax
machine for
already installed
landline
connection

Rs. 1 lakh per
annum for his
own office &
the subordinate
offices under
his control and
for
(c),(d),(e)and (f)
taken together
subject to the
conditions
given below.

Rs. 3 lakh per
annum for his
own office &
the subordinate
offices under
his control and
for (c),(d),(e)
and (f) taken
together subject
to the
conditions
given below.

Rs. 5 lakh per
annum for his own
office & the
subordinate offices
under his control
and for
(c),(d),(e),(f) and
(g) taken together
subject to the
conditions given
below.

Rs. 20 lakh per
annum for his
own office & the
subordinate
offices under his
control and for
(c),(d),(e),(f) and
(g) taken together
subject to the
conditions given
below.

Nil

Nil

(f) Fees for digital
signature certificate
from National
Informatics Centre.
(g) Laptop and
data card –
purchase of

Delegation of Power

11

<!-- page 20 -->

Important Government Orders
(i)

In case of need to relax the financial power of heads of department other than Additional Chief
Secretary / Principal Secretary / Secretary / Commissioner sanction may be accorded by the Additional
Chief Secretary / Principal Secretary / Secretary / Commissioner within his delegated power of Rs.20
lakh p.a. taking together all such sanctions to subordinate office and purchase for his own office
under item nos. 29(c), 29(d), 29(e),29(f) and 29(g). In case of need to relax the financial power of
Additional Chief Secretary / Principal Secretary / Secretary / Commissioner, concurrence of the
Finance Department is necessary.

(ii) The concerned Administrative Department/Head of Department/Head of Office shall maintain year wise Register for sanction of the above mentioned items for his office and the subordinate offices
under his control and shall strictly monitor so that the sanctioned expenditure does not exceed the
delegated financial power as mentioned above.
(iii) Officers of and above the rank of Special Secretary, Directors having requirement of Laptop and
Data card during official tour for efficient discharge of their official duty may be allowed such
devices. Each Administrative Departmental head may sanction expenditure for purchasing not more
than two units of Laptops within the period of five years and there shall be not more than five units
of data cards in one Department. The data card shall be under most economic plan and shall be
used in most economical manner for official purpose only. Necessary certificate shall be furnished
by The ‘Head of Office’ while preferring bill in this regard.
(iv) All the officers of and above the rank of SDO/Head of office at Sub-Divisional level, District level
and State level having no Broadband connection are eligible for a broadband connection strictly
according to their official requirement. The broadband connection shall be the most economic plan
of BSNL for single user.
(v)

The Departments shall develop a computerized management information system and set up
Monitoring Committees at State, District and Block levels for guidance, monitoring, coordination
and taking appropriate action for optimum utilization of the machines, devices and equipments run
on information and communication technology.

(vi) In case of purchase of new machines and equipments in replacement old ones, the rate should be
invited on ‘buy back’ terms.
(vii) No new landline telephone connection for the fax machine shall be sanctioned.
(viii) While deciding on the purchase, availability of fund under the particular detailed head of appropriate
head of account of the concerned Department shall be ensured.
(ix) While making the purchase the related purchase procedure of the West Bengal Financial Rules shall
be observed.
(x)

While purchasing the computer and its peripherals the purchase procedure contained in memo
no. 1782-F dt.1.3.2006 read with memo no. 3876-F dt.2.5.2005 shall be followed.

Sd/- H. K. Dwivedi
Secretary to the
Government of West Bengal.
12

Delegation of Power

<!-- page 21 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Budget Branch
MEMORANDUM
No. 96-F.B.

Dated, Kolkata, the 18th April, 2012
Sub.:

Administrative approval for schemes to be executed with the grants under the
recommendation of the Thirteenth Finance Commission

The Government had been considering, for some time past, to simplify the procedure of according
administrative approval to the schemes to be executed with the grants under the recommendation of the
Thirteenth Finance Commission, where such administrative approval is necessary. At present, the grants under
the recommendation of the Thirteenth Finance Commission are available in the following cases.
(i)

Local Bodies Grants

(ii)

Water Sector Management

(iii)

Grants for Forests

(iv)

District Innovation Fund

(v)

Improvement of Statistical system

(vi)

Employees and Pensioners data Base

(vii) Incentive for Issuing Unique Identifications
(viii) Maintenance of Roads and Bridges
(ix)

Improvement in Justice Delivery

(x)

Elementary Education

(xi)

Disaster Relief and Capacity Building

(xii) Police Training and Police Housing
(xiii) Embankments/Drainage in Sunderban
(xiv) Upgradation of Fire and Emergency services
(xv)

Construction of Health Centres

(xvi) Construction of Anganwadi Centres
(xvii) Road Infrastructure in Border Areas
(xviii) Maintenance of Historical Monuments
2. In the above cases except grants for Local Bodies, Elementary Education, Disaster Relief and Capacity
Building, Action Plans/Working plans are approved by the High Level Monitoring Committee (HLMC).
3. The Governor has now been pleased to decide that the Departmental Approval Committee shall accord
administrative approval to the schemes to be implemented under the recommendation of Thirteenth Finance
Commission, irrespective of the amount, for which the Action Plans/Working Plans have been approved by
the High Level Monitoring Committee.
(A.R. Chakraborty)
Special Secretary
Delegation of Power

13

<!-- page 22 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
BUDGET BRANCH
No. 3053(14)-F.B.

Dated 17th March, 2012

MEMORANDUM
Sub.: Administrative Approval and Financial Sanction.
The undersigned is directed to inform that the Planning Commission, Government of India has approved
several schemes forwarded by the State Government under Backward Region Grant Fund –Special Plan for
State of West Bengal with a total project cost of Rs.8661.56 crore.
Ministry of Finance, Government of India has already released Rs.2251.19 crore for implementation of
said schemes.
In the circumstances, the undersigned is directed to accord administrative approval for the schemes
under BRGF (Special) under different Sectors with a total project cost of Rs.8661.56 crore as per enclosed
statement.
The undersigned is further directed to the approval of the financial sanction for the schemes of various
administrative departments, amount of which as indicated against each of the department as per enclosed
statement.
The concerned administrative departments are requested to take necessary steps to undertake the schemes
at the earliest.

Sd/- A.R. Chakraborty
Special Secretary

14

Delegation of Power

<!-- page 23 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
BUDGET BRANCH
No. 2425-F.B.

Kolkata the 27th December, 2011.

MEMORANDUM
In continuation of this Department Memo No. 2105-FB dated 02.11.11 and in cancellation of this
Department Memo Nos.2410-FB dated 27.12.11 and No.2411-FB dated 27.12.11, the undersigned is directed
by order of the Governor to say that in the interest of public service and for expeditious implementation of the
Centrally Sponsored/ Central Sector/ Centrally Assisted State Plan schemes, Governor has been pleased to
empower the Additional Chief Secretary/Principal Secretary/ Secretary of (1) Agriculture Department (2) Food
& Supplies Department (3) Health & Family Welfare Department (4) Minority Affairs and Madrasah Eduction
Department (5) Municipal Affairs Department (6) Panchayats & Rural Development Department (7) Urban
Development Department (8) Public Health Engineering Department (9) Women & Child Development
and Social Welfare Department (10) Agricultural Marketing Department (11) Forests Department (12) Irrigation
& Waterways Department (13) School Education Department (14) Water Resources Investigation &
Development Department to release States matching share as well as Central Share up to the current year's
budget provision, subject to the following conditions:
1. The Administrative Departments will be required to take a written confirmation direct from the
Finance Department, Budget Branch (Group-N) that the central share has been credited to the State
Exchequer.
1.1. Wherever Administrative Department receives funds direct from the respective Ministries of
Government of India, such as under SSA, NRHM, NREGA etc., written confirmation from Finance
Department would not be required for release of State Share up to the Budget provision.
2. The Administrative Department will ensure release of fund as per requirement of the specific schemes
and exercise all necessary precautions to ensure the effective utilization of such project funds within
overall budget provisions and also that the budgetary allocations are not exceeded in any manner.
3. The Administrative Departments may ensure before releasing any fund on these accounts that the
previous released amounts have been substantially utilized, so that the moneys do not remain idle
in the bank accounts.
4. The Administrative Departments will have to approach the Finance Department in case of releases
beyond the budgetary allocation or in case of advance release of State share where Central share has
not been received, in schemes where the State share is required to be released in advance.
5. Processing for release of fund will not be done in the Finance Department, hence Additional Chief
Secretary/Principal Secretary/ Secretary of the Administrative Departments are advised to be extra
careful in view of the increased responsibilities. The Administrative Department will in fact be
combining the role of Finance Department to that extent.
6. It may be ensured that expenditures are made on approved items as per approved project/scheme
and also to be careful that expenditures are not incurred on inadmissible items against which Central
share will not be available.
7. It may be ensured that releases are made only for the administratively approved projects. Thus
Administrative approvals will be needed for new scheme as per the existing procedure.
Delegation of Power

15

<!-- page 24 -->

Important Government Orders
8. West Bengal Financial rules including tender rules are to be strictly observed and for any deviations
concurrence of Finance Department will be necessary.
9. The Administrative Department shall ensure that the releases are uploaded immediately on the
Website of the Finance Department. (www.wbfin.nic.in).
10. Administrative Departments will submit monthly reports on the releases made during the month by
the 7th Day of the following month to the Finance (Budget) Department. This is extremely important
for management of fund flows of the State Government. Format is enclosed herewith.
11. A meeting will be held every month on 7th day of the month at 11 A.M. or succeeding working day
if 7th is holiday in the chamber of Addl. Secretary (ARC) by Principal Secretary, Finance Department
to gather information regarding monthly release of funds by the concerned Administrative Department.
This order will take effect from 01.01.2012 and will remain valid upto 31.07.2012.

Sd/- (S. Dutta)
OSD & EO Joint Secretary to the
Government of West Bengal

16

Delegation of Power

<!-- page 25 -->

Delegation of Power

11

10

9

8

7

6

5

4

3

2

1

Sl.
No.
1
3

2

TOTAL Rs.

Head of Account

G.O. No. & Date

Department _______________________________________
Amount released
(Rs. in lac)
4

Cumulative release
up to the month
6

______________________ Department

Joint Secretary to the
Government of West Bengal

GRAND TOTAL Rs.

U.O. No. & Date of the
Finance Department
5

Demand No. _________________

PARTICULARS REGARDING RELEASE OF CENTRAL SHARE RELATING TO CENTRALLY SPONSORED,
CENTRAL SECTOR, CENTRAL ASSISTED STATE PLAN SCHEMES FOR THE MONTH OF _________________

Finance Department

17

<!-- page 26 -->

18

11

10

9

8

7

6

5

4

3

2

1

Sl.
No.
1
3

2

TOTAL Rs.

Head of Account

G.O. No. & Date

Department _______________________________________
Amount released
(Rs. in lac)
4

Cumulative release
up to the month
6

______________________ Department

Joint Secretary to the
Government of West Bengal

GRAND TOTAL Rs.

U.O. No. & Date of the
Finance Department
5

Demand No. _________________

PARTICULARS REGARDING RELEASE OF STATES SHARES RELATING TO CENTRALLY SPONSORED,
CENTRAL SECTOR, CENTRAL ASSISTED STATE PLAN SCHEMES FOR THE MONTH OF _________________
Important Government Orders

Delegation of Power

<!-- page 27 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Budget Branch
No. 801-F.B.

Kolkata, the 31st July, 2012

MEMORANDUM
Sub.:

Delegation of power to the Additional Chief Secretary/ Principal Secretary/ Secretary
for releasing States matching share & Central Share up to the current financial year
budget provision.

The undersigned is directed by order of the Governor to say that in the interest of public service and for
expeditious implementation of the Centrally Sponsored/Central Sector/Centrally Assisted State Plan schemes,
the Governor has been pleased to extend the validity of this Deptt. Memo No. 2425-FB dated 27.12.2011 for
a further period up to 31.03.2013.

Sd/- (S. Datta)
OSD & EO Joint Secretary to the
Government of West Bengal

Delegation of Power

19

<!-- page 28 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Budget Branch
No. 152-FB

Dated Kolkata the 27th April, 2012

MEMORANDUM
Sub.: Introduction of Financial Adviser in different Departments
Under the present Delegation of Financial Powers, the Administrative Departments are required to send
the proposals to the Finance Department for incurring expenditure out of the State Plan Funds beyond the
powers delegated to them. The State Government vide Finance Department's Memo No.1880-F dated March
7, 2007 constituted a Departmental Approval Committee (DAC) for granting administrative approval to projects/
schemes with estimated cost not exceeding Rs.3 crore. The powers of the DAC were enhanced from Rs.3
crore to Rs.5 crore vide Finance Department's Memo No.9144-F(Y) dated September 22, 2011. Now, in order
to further facilitate expeditious implementation of development and welfare programmes, the State Government
has decided to enhance the financial powers of the Administrative Departments and improve their competence
in the field of financial management by effectively delegating certain financial powers to Administrative
Departments.
Keeping these objectives in view, the Governor has been pleased to introduce the system of Financial
Advisers in the Administrative Departments. The new system requires that all proposals for expenditure on
schemes/projects are subjected to detailed financial scrutiny by the Financial Adviser of the Administrative
Department instead of being sent to the Finance Department. The present financial powers delegated to the
Secretaries will also continue.
1.

Role of Financial Advisers

The Financial Advisers will have the following responsibilities subject to the conditions prescribed in
para 4 of the Memorandum:
(i) Render advice to the Additional Chief Secretary/Principal Secretary/ Secretary/ Special Secretary-inCharge of the Department on all financial matters including procurement proposals which would
otherwise have required concurrence of the Finance Department.
(ii) To screen all expenditure proposals requiring to be referred to Finance Department for concurrence
or comments.
(iii) To ensure maintenance of accounts of expenditure against the grants or Appropriations.
(iv) To advise the Drawing and Disbursing Officers (DDOs) in proper maintenance of Accounts.
(v) To watch and review the progress of expenditure against sanctioned grants through maintenance of
necessary Control Registers and to issue timely warnings to Controlling Authorities where the progress
of expenditure is not even.
(vi) To screen the proposals for supplementary demands for grants.
(vii) Monitoring Non-tax Revenue Receipts.
(viii) To watch the settlement of audit objections, Inspection Reports, draft audit paras, etc.
(ix) To ensure prompt action on Audit Reports and Appropriation Accounts, Reports on Public Accounts
Committee, Estimates Committee and Committee on Public Undertakings.
20

Delegation of Power

<!-- page 29 -->

Finance Department
(x) To ensure regular and timely submission of reports to the Finance Department and to ensure immediate
uploading of release of funds on the website of the Finance Department. (www.wbfin.nic.in).
(xi) To ensure timely submission of monthly reports on the releases made during the month by the 7th
Day of the following month to the Finance (Budget) Department.
2.

Delegation of Financial Powers Rules
The FA shall exercise the following delegated powers under the West Bengal Financial Rules:
(i) Accord concurrence for administrative approval of any plan expenditure upto Rs.10 crore within
the budgetary allocation and subject to general directions issued by Finance Department from time
to time. Government Orders for administrative approval and financial sanction will be issued by
Joint Secretary or Special Secretary authorized by the Departmental Secretary.
(ii) According concurrence for release of fund from schemes for which Central Assistance is available,
subject to the following:
(a)

FA will be required to take a written confirmation direct from the Finance Department, Budget
Branch (Group-N) that the Central share has been credited to the State Exchequer.

b)

FA will ensure release of fund as per requirement of the specific schemes and exercise all
necessary precautions to ensure the effective utilization of such project funds within overall
budget provisions and also that the budgetary allocations are not exceeded in any manner.

c)

FA may ensure before according concurrence for releasing any fund on these accounts that the
previous released amounts have been substantially utilized, so that the money do not remain
idle in the bank accounts.

d)

It may be ensured that expenditures are made on approved items as per approved project/
scheme and also to be careful that expenditures are not incurred on inadmissible items against
which Central share will not be available.

e)

It may be ensured that releases are made only for the administratively approved projects. Thus,
Administrative approvals will be needed for new scheme as per the existing procedure.

(iii) In case of release of State Share of Centrally Sponsored Schemes/Centrally Assisted Schemes the FA
will be competent to accord concurrence for release within budget provision provided that the
Central share has been credited to the State Exchequer or in the Bank Account of the implementing
agency.
(iv) To accord concurrence for re-appropriation of any amount within the sub-detailed heads under
detailed head 01-Salaries, 13-Office Expenses and 21-Material & Supplies/Stores & Equipments of
the Demand of the Department provided the approval of the head of the administrative department
is there. But this re-appropriation will have to be done through software that will be made available
in the Finance Department's website www.wbfin.nic.in. The Departments will be allotted a user
code and password for this purpose. The re-appropriation of fund is also subject to the following
condition:
a)

That the grant is not exceeded.

b)

That the expenditure which will be met by the Re-appropriation does not involve the undertaking
of a new or unapproved or recurring liability.

c)

That the savings are known in sufficient time to permit their being spent to good purpose and
that the expenditure is not incurred merely to prevent lapse of savings.

Delegation of Power

21

<!-- page 30 -->

Important Government Orders

3.

d)

That a re-appropriation sanctioning the undertaking of a new service is not involved.

e)

Any appropriation or re-appropriation within the grant of a year can be authorized at any time
before, but not after the expiry of financial year to which it relates.

f)

Re-appropriation of funds from one grant to another grant are not permissible, as such
re-appropriation will have the effect of reducing or increasing amounts of the grant concerned
as specified in the schedule of authorised expenditure appended to the Appropriation Act and
will thus be ultra vires of the provisions of the constitution.

g)

No re-appropriation from a "voted" to a "charged" head and vice versa is admissible.

h)

Re-appropriation of fund from revenue to capital/loan heads and vice versa is not admissible.

i)

Provisions under plan scheme including Centrally Sponsored /Central Sector scheme should
not be diverted to non-plan scheme and vice versa.

j)

Provision of Office Expenses should not be increased by reappropriation.

k)

Re-appropriation from Salary to Non-Salary head is not admissible.

FAs will not be authorized to accord concurrence in respect of the following items:
(i) Any new scheme and continuing scheme, in which there are deviations from the existing norms and
yardstick as approved by the Finance Department.
(ii) Sanction any augmentation of fund.
(iii) Relax any tender Rules.
(iv) Sanction any matter relating to pay and any allowances of any type or any other establishment
matters that require approval of Finance Department. Such proposals of Administrative Departments
must be routed through the FA and FA will record his view in writing before the proposal is sent to
the Finance Department.
(v) Sanction creation of posts including promotional post, Recruitment/appointment of Officer/staff,
Casual or contractual appointment, Fixation of remuneration/pay etc. and other Service matters.
Creation of new offices, Declaration of Head of Office and DDO, purchase or hiring of new vehicles.
(vi) Sanction to open any bank account, grant or increase of 'Permanent Advance', Advance Drawal of
fund, grant of tiffin or any sort of extra allowances other than those already approved by Finance
Department.
(vii) Sanction scheme/projects which involves introduction of a new policy/practice likely to lead to
increased expenditure in future.
(viii) Sanction new telephone or internet connection and any non-plan expenditure beyond the delegated
powers of the Additional Chief Secretary/ Principal Secretary/ Secretary of the Department.
(ix) Matters pertaining to the following schemes/subjects will be dealt exclusively by the Budget Branch
(Group 'N') of the Finance Department subject to any Special delegation made in respect of any of
these schemes/subjects. Matters relating to these schemes/ subjects shall be referred to the Finance
Department through FA or with the comments of FA :

22

a)

Externally Aided Projects (EAP).

b)

Rural Infrastructure Development Fund (RIDF).

c)

Schemes implemented with assistance from HUDCO.
Delegation of Power

<!-- page 31 -->

Finance Department
d)

Schemes implemented with assistance from NCDC.

e)

National Social Assistance Programme (NSAP)

f)

Upgradation/special problem grants and local body grants recommended by the Thirteenth
Finance Commission.

g)

Schemes implemented out of one-time Additional Central assistance (ACA).

h)

Release of fund under State Finance Commission's recommendations.

i)

Prime Minister's Gramoday Yojana (PMGY).

j)

Schemes of RKVY.

k)

State Government guarantee.

I)

Conversion of loan into grant/equity.

m) Writing off of loans.

4.

n)

Partial or full waiver of interest.

o)

Authorization of LOC.

p)

Grant of Loan.

q)

Sanction of Subsidy

r)

Raising of loan.

General Instructions
1.

The Additional Chief Secretary/ Principal Secretary/ Secretary of the Department or any officer not
below the rank of Joint Secretary specifically authorized by the Additional Chief Secretary/ Principal
Secretary/ Secretary of the Department will refer the files of the Department to the Financial Adviser.

2.

The FA will send all files directly to the head of the Administrative Department (Additional Chief
Secretary/ Principal Secretary/ Secretary).

3.

After the concurrence of the Financial Adviser the order will be issued by the competent authority as
may be specified under the internal delegation orders of the Department. The following line has to
be inserted “This issues with the concurrence of the Financial Adviser of the ............................
Department vide his U.O. No .............................. dated .................................“

4.

FAs would be consulted in all cases relating to the exercise of the financial powers delegated in
terms of the Memorandum. While normally FAs advice would be expected to be adhered to, there
could be instances/cases in which the Departmental Secretary feels that there are valid reasons for
some modification/deviation. In such rare instances, Secretaries of the Administrative Departments
can exercise their power to overrule FAs advice by an order in writing. All such decisions should be
forthright communicated to the Finance Secretary.

5.

The head of the Administrative Department and other functionaries will continue to enjoy the powers
delegated to them under the W.B.F.R, as amended or under any special delegation without
any reference to FAs. However, they may seek on their own accord the advice of the FAs on any
matter within their delegated financial powers and the FAs shall render necessary advice on such
matter.

6.

FAs are not expected to do any routine administrative functions.

Delegation of Power

23

<!-- page 32 -->

Important Government Orders
5.

Organizational Structure
There shall be an FA Branch in each Department where FA system consisting of the following personnel:
(i) Financial Adviser
He will be equivalent in the rank and status of Special Secretary or Joint Secretary of Finance
Department. The Department of Personnel and Administrative Reforms, Government of West Bengal
would be responsible for posting FAs to the Departments.
ii) Deputy Financial Adviser(s)
There will be one or two posts of Deputy Financial Adviser who would be responsible for Accounts
and Audit Branch. The Deputy FA will be in the rank of Deputy Secretary. The Department of
Personnel and Administrative Reforms/Department of Finance, Government of West Bengal would
be responsible for posting DFAs to the Departments.
iii) Accounts Officer/(s)
The post will be borne in the cadre of West Bengal Audit and Accounts Service (10 years in service).
The Finance Department, Government of West Bengal would be responsible for posting of Account
Officer(s) to the Departments.
v) Section officer
vi) Upper Division Assistant
vii) Lower Division Assistant
viii) Group-D
The Support Staff outlined above at SI.No.(v) to (viii) shall be arranged by the Administrative
Departments from the existing manpower.
ix) The officers and staff posted to FA Branch shall not be entrusted with any other departmental work.

6. This new system shall be introduced in the following departments in the first instance:
i) Home Department.
ii) Health & Family Welfare Department.
iii) Urban Development Department.
iv) Public Health Engineering Department.
v) Public Works Department.
vi) Panchayat & Rural Development Department.
The present system of Departmental Approval Committee will stand dissolved in the above
Departments.
7. The FA System will take effect from 01.6.2012 in the above Departments.

Sd/H.K. Dwivedi
Secretary to the
Government of West Bengal.
24

Delegation of Power

<!-- page 33 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Writers’ Buildings,
Kolkata – 700 001.
No. 5275-F(Y)

Dated Kolkata the 21st June, 2012

MEMORANDUM
Sub.: Creation of the posts for introducing the system of Financial Advisers
The undersigned is directed to say that the system of Financial Adviser has been introduced in the
following six (6) Departments vide Finance(Budget) Department Memo No : 152-FB dated 27.04.2012.
1.
2.
3.
4.

Home Department
Health and Family Welfare Department
Urban Development Department
Public Health Engineering Department

5. Public Works Department
6. Panchayats and Rural Development Department
Consequent upon the introduction of the system of Financial Advisers in the aforesaid Administrative
Departments, it has become necessary to create the requisite posts so that the system may run smoothly.
2. After a careful consideration of the matter the Governor has been pleased to accord sanction to the
creation of following posts for each of the six Departments as indicated at para 1 above, for a period
of one year with effect from 01.06.2012.
a. Financial Adviser (to be filled up by an officer
in the rank of Special Secretary or
Joint Secretary )
—
1 (one)
b. Deputy Financial Adviser(to be filled up by an
officer in the rank of Deputy Secretary)
—
2 (two)
c. Accounts Officer (In the cadre of West Bengal
Audit and Accounts Service)
—
4 (four)
d. Section Officer
—
2 (two)

3
4
5

e. Upper Division Assistant
—
4 (four)
f.
Lower Division Assistant
—
4 (four)
g. Group'D'
—
6 (six)
The charge will be debitable to the head of accounts from which the charge of the Secretariat
establishment of the concerned Administrative Departments is met.
This Order issues with the concurrence of Group -'P' of Finance Department vide their U.O. No.1391
Gr.-P (Service) dated 16.04.2012.
The Accountant General (A&E) West Bengal is being informed.
Sd/-H.K. Dwivedi
Secretary to the
Government of West Bengal.

Delegation of Power

25

<!-- page 34 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Budget Branch
No. 1056-FB

Dated Kolkata the 10th September, 2012

MEMORANDUM
Sub.: Amendment and Clarification regarding Introduction of Financial Advisers
In continuation of this Department Order No. 152-FB dated 27.04.2012, State Government has decided
to include the following two items in the ‘Role of Financial Advisers’ as follows:
After clause 1(XI) insert the following clause:
(XII) Budget formulation and preparation as per the direction of Departmental Secretaries.
(XIII) Reconciliation of receipts and expenditure with Accountant General (Account and Entitlement) West
Bengal periodically.
After issuance of the aforesaid order various clarifications have been sought by different Departments
regarding the role, duties, responsibilities and procedure of work of the Financial Advisers. Following points
may be clarified in this respect:
1.

Financial Adviser shall perform the duties assigned to them in terms of the provisions as indicated in
this Department Memorandum No. 152-FB dated 27.04.2012, under 'Role of Financial Advisers'
independently with the help of the officers and staff under his/her control. The set up of the officers
and staff, created for this purpose, has been mentioned at para-5 of the said order. In terms of para1 under 'Role of Financial Advisers', Financial Adviser should monitor both plan and non-plan
expenditure. For the purpose of uploading the data for the release of 'Plan Fund' User Identity and
Password should be used from the end of Financial Adviser.

2.

It has been mentioned at SI. No. 6 of Memo No. 152-FB dated 27.04.2012 that DAC shall stand
dissolved in the Departments where F.A. System has been introduced. Financial Adviser shall enjoy
all the powers of DAC including the enhanced delegated power of Rs.10 Crore under directions of
the Administrative Head of the Department. DAC shall stand merged under the F.A. System.

3.

(i)

The new scheme would refer to any expenditure arising out of a new policy decision of the
State Government including new activity or a new form of investment or which involves creation
of additional posts/ deployment of additional personnel and hiring of additional vehicles and
providing of new telephones.

(ii) New Scheme would refer to any new construction or execution of new programme beyond
Rs. 10 Cr. under existing head of account subject to budget provision.
(iii) The additions /alterations/renovations of existing works upto Rs.10 Cr. will not fall under new
schemes.
4.

26

In case, where it is required to open a new head of account, whether receipt or payment, such
proposal should come to Finance Department after obtaining the view of the Financial Adviser.
After obtaining the concurrence of the Finance Department and the Accountant General (A&E) West
Delegation of Power

<!-- page 35 -->

Finance Department
Bengal, necessary G.O. shall be issued by the concerned Administrative Department informing the
opening of the new head to all concerned including Financial Adviser, Finance Budget Department
and Director of Treasuries and Accounts, West Bengal Subsequently, suitable proposal of
re-appropriation/ augmentation should be submitted to Finance Department Group-'N' through the
Financial Adviser for provision of fund.
5.

Administrative approval for Central Sector Schemes (CN) / Centrally Sponsored Schemes (CS) within
Rs.10 Cr shall be approved as per the existing guidelines of the Government of India by the Financial
Adviser. Those cases pertaining to increase in the commitment of the State Government or where a
new CN/CS is introduced or the existing sharing norm is altered, should be referred to the Finance
Department for prior concurrence.

6.

Financial Adviser shall be competent to accord Administrative Approval for the projects/schemes
under 13th Finance Commissions Grants or under Backward Regions Grant Fund (Special) irrespective
of the amount of each project/scheme. In case of release of fund the proposals should be referred to
the Finance (Budget) Department for concurrence.

7.

The Financial Adviser, shall be required to monitor expenditure for the funds released as grants in
favour of Autonomous Bodies, Local Bodies, Societies, Corporations/Companies under the
Administrative control of the Department.

8.

Financial Adviser shall be competent to release 'Grants-in-Aid' subject to budget provision. The
quantum of grants may be decided on merit on case to case basis on the recommendation of the
Administrative Department.

9.

The Financial Adviser will have to play a vital role in implementing different schemes of the State
Government pertaining to his Department.

10. Financial Advisor shall not accord approval for new construction or implementation of new
programme to be executed by any Corporation/Autonomous body/Government Company under
the Administrative control of the Department out of interest accrued on such fund sanctioned by the
Department, other than the purpose, for which the fund was sanctioned.
11. The Financial Adviser will be responsible for allotment of fund and total budgetary control including
Plan Fund and Non-Plan Fund under the grants of the Department and carry on the duties as mentioned
in clause1(i) to l(XI) of the Finance Department Memo No.152FB dated 27.04.2012, along with the
additions mentioned in this order.
12. For inserting U.O. No. Inter Departmental Register(Outwards) as per form V(VI) of Secretariat
Manual is to be maintained in the following format:
SI.
No.

Date on
which
sent

To
whom

File
No.

Subject

Receipt of
Department

Date on which
received back

Remarks

1

2

3

4

5

6

7

8

Delegation of Power

27

<!-- page 36 -->

Important Government Orders
The serial number in the register along with date shall be recorded as U.O.No and date.
13. However the following Inter Departmental Register (Inwards) as per form V(VII) of Secretariat Manual
is to be maintained in the following format for recording the receipt of files.
SI.
No.

Date on
receipt

From whom
received

File
No.

Subject

Date on
which
returned

Receipt of
Department

Remarks

1

2

3

4

5

6

7

8

Sd/- H.K. Dwivedi
Secretary to the
Government of West Bengal.

28

Delegation of Power

<!-- page 37 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 1232-F(Y)

Date: 09.02.2012

MEMORANDUM
Sub.: Delegation of power to Heads of Departments to sanction retention of hiring of vehicles
The undersigned is directed by the order of the Governor to say that the Governor is pleased to authorize
the Additional Chief Secretary / Principal Secretary / Secretary of a Department to sanction retention of hiring
of vehicles of that Department and its subordinate offices on existing terms and conditions subject to the
condition that the vehicle was originally hired with the approval of Finance Department and also subject to
the condition that continuance of hiring is required in the interest of public service.
2.

The undersigned is further directed to state that the Governor is also pleased to authorize the Additional
Chief Secretary / Principal Secretary / Secretary of a Department to allow hiring of a new vehicle
(Non-AC) as replacement of an existing one provided the existing vehicle was hired with the approval
of Finance Department.

3.

In all cases retention of a hired vehicle has to be sanctioned for a period not exceeding one year at
a time.

4.

While issuing sanction orders for retention of hiring of vehicles and allowing hiring of a new vehicle
as replacement of existing one in exercise of the powers delegated under this memorandum, the
following sentence should be inserted in such orders “This order issues in exercise of the powers
delegated under Finance Department Memo. No. 1232-F(Y) dated 09.02.2012”.

5.

For fresh hiring of vehicles concurrence of Finance Department will be required.

6.

This order shall take immediate effect.

Sd/- H.K. Dwivedi
Secretary to the
Government of West Bengal.

Delegation of Power

29

<!-- page 38 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 2895-F(Y)

Date: 05/04/ 2012

ORDER
In terms of G.O.No.1880-F dt. 07.03.2007 read with G.O. No.9144-F(Y) dt. 22.09.2011 of Finance Deptt.
each Department has constituted a “Departmental Approval Committee” (DAC) for according administrative
approval to Plan projects/Schemes with project cost not exceeding Rs.5 crore.
Now, the Government feels it necessary to decentralize the function of the DAC to Medical/Dental
College level in respect of Health & Family Welfare Department in order to speed up sanction and execution
of the essential and urgent Plan Projects/Schemes having low project cost, on constituting a "College Level
Approval Committee" (CLAC) for each Medical/Dental College under the State Government
As such in addition to existence of the DAC of Health and Family Welfare Department the Governor is
pleased to lay down the following procedure for according administrative approval of Plan Projects/Schemes :A)

Health & Family Welfare Deptt. shall constitute a “College Level Approval Committee” (CLAC)
comprising the following for each Medical/Dental College in the State by notification :i)

Principal/Director of Medical/Dental College

-

Chairman

ii)

Medical Superintendent and Vice Principal of
Medical College and Hospital/Vice Principal of
Dental College

-

Member

iii) Executive Engineer of the Concerned
Division or Assistant Engineer of the Concerned
Sub-Division of PWD/PW (CB)
entrusted with Civil Works

-

Member

iv)

Executive Engineer of the Concerned Electrical
Division or Assistant Engineer (Electrical) of the
Concerned Sub-Division of PWD/PW (CB)
entrusted with the electrical Works

-

Member

v)

Officer of the Finance Deptt. belonging to
WBA&AS cadre attached to the Medical College
& Hospital

-

Member

vi)

Officer of the Finance Department belonging to
WBA&AS cadre Officer attached to Medical College.

-

Convenor

N.B. — In respect of Dental College, officer of Finance Department belonging to WBA&AS cadre attached to
nearby Medical College will be the Convener.
2.

30

All Plan Project/Schemes with individual Project cost not exceeding Rs. 10 lakh for civil works and not
exceeding Rs. 5 lakh for Electrical Works shall be placed before the CLAC for consideration of the
Committee for according administrative approval. Officer of the Finance Deptt. belonging to WBA&AS
cadre functioning as Accounts Officer attached to Medical College shall perform the function of the
Financial Adviser (FA) of the Committee and in his absence no meeting shall be held.
Delegation of Power

<!-- page 39 -->

Finance Department
3.

No Project/Scheme shall be approved by the CLAC without the consent of the F.A.

4.

Where the F.A. does not give his consent for approval of a particular project/scheme, his disagreement
with reasons thereof to be recorded in the proceeding by the Committee.

5.

In the event of such disagreement, if the College authority is of the view that the proposal should be
pursued, then it should be sent to the Health & Family Welfare Deptt. for consideration by the DAC.

6.

This Committee should have the power to accord administrative approval of all Plan projects/schemes
both for Original Works and Replacement & Renovation works subject to the ceiling limit as stated in
para A (2) above.

7.

A "Scheme Appraisal Note" should be prepared by the College authority for each scheme to be placed
before the Committee specifying therein : Unique identification No. of the scheme, name of works to be
done, brief reasons for taking up of work, project cost, name of the executing PWD Division and estimate
no., Budget head of a/c in which the scheme is to be executed, total initial Distribution amount pertaining
to the Budget head at the beginning of the year (so communicated by the Health & Family Welfare Deptt.
at the beginning of the financial year), total administrative approval accorded so far upto the last meeting
from the Budget head out of initial Distribution amount, balance available thereof for according further
administrative approval.

8.

A statement of projects/schemes accorded administrative approval by CLAC along with a record of
proceedings should be sent to the Health & Family Welfare Deptt. in duplicate by the College authority
and Health & Family Welfare Deptt. in turn retain one copy and return the other copy along with U.O.
No. and date of the Department as concurrence. Thereafter the Princiapl/Director of the College will
issue administrative approval in favour of the Chief Engineer concerned for execution of the scheme.

9.

While issuing such order of administrative approval the following sentence should be incorporated:This order issue with the power delegated vide Finance Deptt. Memo No.2895-F(Y) dt. 05.04.2012 read
with the concurrence of Health & Family Welfare Deptt. vide their U.O. No................... dt.........................

B)

Provision of making Distribution of fund to Colleges for according administrative approval by CL AC :-

1.

Upto 40% of Budget provision of a particular financial year pertaining to Detail head "53-Major works/
Land and Buildings" sub-ordinate to those Plan heads of account (Capital head) only adjudged suitable
for taking up of Original/Replacement & Renovation works by the CLAC should be earmarked by Health
& Family Welfare Deptt. for Distribution.

2.

College wise Distribution of such fund (not allotment) under the relevant Plan heads of a/c should be
intimated to the College authority by 1st week of May of each financial year, so that CLAC can take up
scheme/projects for execution round the year and accord administrative approval to the Schemes/Projects
out of the fund Distributed to them. The balance amount (rest 60%) of Budget Provision under those Plan
heads of a/c will be retained with Health & Family Welfare Deptt. for according administrative approval
by DAC centrally.

C)

To accord Financial Sanction by the College authority :The Governor is also pleased to delegate the power to the Principal/Director of Medical/Dental Colleges
to accord financial sanction time to time in respect of those schemes/projects for which administrative
approval has already been accorded by the CLAC.

2.

Such financial sanction should be given by the Principal/Director on obtaining :i)

Comparative Statement of Tender from concerned Executive authority of PWD,

Delegation of Power

31

<!-- page 40 -->

Important Government Orders
ii)

Knowing physical percentage of work done or progress of work from the executing authority of
PWD.

3.

Accord Sanction of fund in favour of the Concerned Chief Engineer out of fund allotted to the Principal/
Director of the College by the Health & Family Welfare Deptt. and also to place the sanctioned amount
to Chief Engineer concerned in order to enable him to issue L. O. C. in favour of the concerned Executive
Engineer of the Division for payment.

4.

Principal Secretary of Health & Family Welfare Deptt. shall allot fund time to time in favour of the
Principal/Director of Colleges in terms of Finance (Budget) Deptt's delegation to him regarding release of
fund, so are being issued in each quarter of a particular financial year by the Finance (Budget) Deptt.

D)

General aspect:-

1)

Prior intimation regarding Distribution of fund to college authority is mandatory before taking up of
administrative approval by CLAC.

2)

Distribution of fund under the particular Plan head should be limited upto 40% of Budget provision for
all the Colleges together.

3)

Distribution of fund is to be made judging the requirement at College & Hospital level.

4)

Distribution of fund within the above limit can be changed in a financial year taking into view the
Administrative Approval already given by the respective CLACs.

5)

Proper training to be given :
i)

for preparation of appraisal note of the scheme for CLAC meeting.

ii)

writing of proceedings to accord administrative approval under the relevant Plan head of a/c by
CLAC.

iii) issuance of administrative approval & financial sanction by CLAC.
6)

For each scheme/project a Unique Identification no. is to be assigned by the College Authority pertaining
to a particular type of works (either civil or electrical). Health & Family Welfare Deptt. should generate
alpha-numeric Unique Identification Code for each College & intimate the same to the College Authority.
Such Identification no. is to be noted in Scheme Appraisal Note, the record of proceedings, Statement of
Projects/Schemes after approval by CLAC, in the order of Administrative approval/financial sanction.

7)

Model of draft proceedings, draft administrative approval & draft financial sanction are to prepared &
circulated by the Health & Family Welfare Deptt. so that all College authorities follow the same pattern.

8)

One particular officer preferably convenor of CLAC be assigned to deal with the entire matter. All the
works to be done through computers as repetition is involved in such work and also to speed up work at
College authorities level.
This order will take effect immediately.

Necessary amendments to the Delegation of Financial Power Rules will be made in due course.

Sd/- H.K. Dwivedi
Secretary
Finance Department.
32

Delegation of Power

<!-- page 41 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 3687-F(Y)

Kolkata, the 2nd May, 2012

MEMORANDUM
Sub:

Payment of consolidated monthly charges to the Private Security Agencies deployed
in Government establishments

The undersigned is directed to state that engagement of Private Security Agencies, deployed in Government
establishments for safety and protection of Government property, is made through due process of tender and
based on recommendations of Tender Selection Committee of Administrative Department for a particular
period with the approval of Finance Department.
The consolidated monthly charges paid to Private Security Agencies has two parts – in one, the security
guards get minimum wages as prescribed by the Labour Department from time to time and in another, service
charges fixed through due process of tender and service tax. The State Government through Labour Department
revises minimum wages time to time, which involves obtaining fresh concurrence from the Finance Department.
With a view to ensure quicker payment of wages to the security guards engaged by the security agencies,
the Governor is pleased to take the following decisions with regard to payment of monthly consolidated
charges to the Private Security Agencies deployed in Government establishments :i)

Monthly security charges payable to such security agencies will be revised automatically based on
the revised Minimum Wages as declared by Labour Department of the State Government from time
to time without obtaining fresh concurrence from Finance Department by the concerned
Administrative Department.

ii)

Tender formalities must be observed for selection of Security Agency in respect of Service Charge by
the Tender Selection committee and after due process of tender, the Agency quoting L-1 rate may be
accepted by the Departmental Heads of the Government in respect of the establishments where
deployment of Security Agency has already been agreed to by Finance Department.

iii) There will be no need to refer such proposal to Finance Department for concurrence unless otherwise
necessary.
iv)

The Administrative Department may release such Agency charges as per circular issued by Finance
Department from time to time in respect of release of funds.

Sd/-S.K. Paul
Special Secretary to the
Government of West Bengal,
Finance Department.

Delegation of Power

33

<!-- page 42 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 1885-F(P)

Dated, the 2nd March, 2012

MEMORANDUM
It has been observed that different Administrative Departments are sending some files relating to conditions
of service of the employees, which can easily be decided on the basis of existing rules and orders at their level.
The concerned group of Finance Department, i.e., Group-P which is already overburdened is facing problem
in disposing important files due to such avoidable references from the departments.
To avoid such references and so lessen the burden upon Group-P of Finance Department, the undersigned
is directed by order of the Governor to say that the Governor has been pleased to direct that the Administrative
Departments may not make any references on the following matters to his Department and decide on these
issues following provisions of extant rules and orders:
MATTERS WHICH MAY BE DISPOSED OF
BY THE ADMINISTRATIVE DEPARTMENTS AT THEIR LEVELS
(i)

Compliance of court orders where there is no scope to prefer appeal or appeal has failed. Opinion
of Ld. L.R., W.B in such cases may be invariably taken.

(ii) Regularization of service due to unauthorized absence by granting leave within the ceiling as
prescribed under the Rule. (Rule 34 of WBSR Part -1)
(iii) Approval of Ticket cancellation charge.
(iv) Permission for tour or training in foreign countries where there is no financial implication upon the
State Government subject to approval of Chief Secretary and Hon’ble Chief Minister.
(v)

L.T.C. claims to be disposed of following existing G.Os, viz. Finance Department Memo. no. 9924F dated 07.12.2005 read with no.607-F dated 20.01.2006 and no.4367-F dated 13.06.2006.

(vi) Extension of tenure of Part-time Sweepers / Water carriers as these are not against any sanctioned
post and paid out of contingency as per F.D. Memo. No.8626-F dated 07.09.2009.
(vii) Renewal of special allowance or additional remuneration for operating photocopier machines,
duplicating machines. The employees who are in receipt of such special allowances may continue
if they are entrusted with the jobs by specific orders of the Admn. Deptt. Such drawal is subject to
the condition that the machine is functioning.
(viii) Admissibility of CAS, MCAS unless it involved counting of past ad-hoc service or appointment in
other posts.
(ix) Reconstruction of Service Book, when the original one is lost. This may be done under the order of
the Head of the Administrative Department following the procedure laid done under Section IV of
Appendix 7 of WBSR Part – I.
(x)

34

Proposal for re-employment after retirement. Those may be sent to the P&AR Department for
consideration of the Screening Committee constituted vide Cabinet Circular No.1-CC/11 dated
03.08.2011.
Delegation of Power

<!-- page 43 -->

Finance Department
(xi) Matters relating to promotional disputes if the same does not involve creation of posts. (Recruitment
rules for the promotion post and existing norms of promotion should be strictly followed).
(xii) Matters relating to deputation within the State Government may be settled by the Administrative
Departments. The maximum period of deputation may be four years. There will be no further extension
and as such no reference is to be made with the Finance Department. Provision of F.D. Memo.
No.9326-F dated 12.10.1979 and subsequent G.Os issued from time to time may be strictly followed.
(xiii) Settlement / alteration of date of birth. The Departments may seek opinion of Ld. L.R.,W.B. where
necessary. Provisions of F.D.Memo. no.707-F(P) dated 24.01.2012 should be strictly followed.
(xiv) Retention of posts / service. Those may be sent to concerned Administrative Group of Finance
Department. Counting of past service for pensionary benefit may also be settled in consultation with
Pension Branch of the Department without making any reference to Group P.
(xv) Permission for study Leave upto two years. The matters may be decided by the concerned authority
under the provisions of Appendix 5 of WBSR Part I.
(xvi) Besides the above, matters not related to pay and allowance / conditions of service of the employee
should not be referred to Group P.
2.

The files which are necessary for reference to Group-P of Finance Department should be sent mentioning
specific points of reference and with the approval of the Secretary / Principal Secretary /Additional Chief
Secretary of the Department. In case of files relating to creation of posts and filling up of vacant posts the
same must be sent in the prescribed proforma already circulated under this Department Memo. No.
1488-F(P) dated 20.02.2012 after having approval of the concerned Hon’ble Minister-in-Charge of that
Department.

Sd/- H.K. Dwivedi
Secretary to the
Government of West Bengal.

Delegation of Power

35

<!-- page 44 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
Writer’s Buildings, Kolkata-700 001
No. 3266-F(P)

Date: 18/04/2012

MEMORANDUM
In continuation of Finance Department Memo. No. 1885-F(P) dt. 2.3.2012, the undersigned is directed
by order of the Governor to say that the Governor has been pleased to direct that the Administrative Departments
may take decision in the following matters according to the provisions of extant rules and order, without
making any reference to Finance Department :(1) Conversion of temporary posts sanctioned on regular basis in permanent establishments continuing
for more than three years into permanent one by the Administrative Department following the
provision of Finance Department Memo. No. 6059-F dt. 25.06.1979. Periodical yearly retention of
such posts continuing for less than three years in such establishments may also be decided by the
Administrative Department.
(2) Retention of temporary posts created for time bound projects / schemes or sanctioned to be filled up
on contract basis for the said purpose may be retained by the Administrative Department upto the
originally sanctioned period of the concerned projects / schemes. In case retention is felt necessary
beyond the said period due to extension of the project / scheme consultation with the Finance
Department will be obligatory.
(3) Extension of lien under clause (iv) of Note 2 below Rule 19 of WBSR Part I. No further extension
beyond the period of three years shall be allowed.
(4) Post-facto permission for acquisition / disposal of immovable property by an employee. The matters
may be disposed of under Clause (2) of Rule 5 of the WBS (Duties, Rights, and obligations) Rules,
1980.
(5) Cases regarding grant of Child Care Leave under Finance Department Memo. No. 1364-F(P)
dt.15.02.2012.
(6) Proposal regarding re-employment of retired employees belonging to Group-A will be referred to
P & AR Department following the guidelines laid down under that Department Memo. No. 180PAR(Gene) dt.30.01.2012.
Clause (x) of Finance Department Memo. No. 1885-F(P) dt.02.03.2012 stands modified to that
extent.
(7) As per rule 34(A) of WBSR Part-I resignation tendered by an employee cannot be withdrawn after
the date from which same is to take effect. The resignation becomes irrevocable and operative after
the aforesaid date of resignation, irrespective of the fact whether it has been accepted formally or
not. So question of withdrawal of the same and taking back such employee in service does not arise
at all. Therefore, such matter should not be referred to Finance Department.
Sd/- H.K. Dwivedi.
Secretary to the
Government of West Bengal.
36

Delegation of Power

<!-- page 45 -->

Delegation of Power

1

2

3

4

5

6

7

8(a)

8(b)

9

10

11

12

13

14

15

If addl. Remarks,
No. of
Justification
Job
Concurrence Financial Addl.
Total Budget Upto
Sanctioned Existing In case of No. of
strength strength vacancy,
impli- Financial financial provision date Financial if any
posts description for creation posts to be of Finance
for
date of proposed of the post
surrenof addl.
Deptt.
implication for impliactual implication
cation
8(a) &
occurrence to be proposed to Posts if such dered,
Obtained
cation salary expen- can be
if any, during current
against col.(9)
8(b)
created be created, category of
diture accommo
dated
and its
if it is new posts are
financial
and
col.(4)
year for
col.(10)
within the
scale of
already
and scale
Budget
pay
there
of pay
Creation Filling
provision
up

Finance Department

37

<!-- page 46 -->

<!-- page 47 -->

Finance Department

RURAL INFRASTRUCTURE
DEVELOPMENT FUND (RIDF)

Rural Infrastructure Development Fund (RIDF)

39

<!-- page 48 -->

Important Government Orders

40

Rural Infrastructure Development Fund (RIDF)

<!-- page 49 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Budget Branch
Writers’ Buildings
No. 964 (27)-FB/O/4P-25/12

Dated, Kolkata, the 27th August, 2012

MEMORANDUM
The undersigned is directed to say that funds are released to the concerned Departments for execution of
projects of different Tranches under RIDF, which are reimbursable from NABARD as per prevailing norms
framed by them. Accordingly, after utilization of the said funds, claims for reimbursement are required to be
submitted to NABARD in prescribed form for ‘Loan Drawal Application with Utilisation Certificate (LDA with
UC)’.
The present practice is that the concerned Departments submit LDA with UC to the Finance Department.
After checking, Nodal Officer of Finance Department endorses the said LDA with UC to the West Bengal
Regional Office of NABARD at ABHILASHA, 2nd Floor, 6, Loyd Street, Kolkata-700016 for realization of the
claims of reimbursement in favour of the Government in Finance Department.
After careful consideration, it has been decided that the concerned Departments may now sanction LDA
with UC directly to the office of NABARD to ensure speedy disposal instead of sending to the Finance
Department.
The undersigned is, therefore, directed by order of the Governor to authorize the Nodal Officer of project
works under RIDF of the respective Departments to furnish the LDA with UC after checking directly to the
NABARD.

Sd/- A.R. Chakraborty
Special Secretary.

Rural Infrastructure Development Fund (RIDF)

41

<!-- page 50 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Budget Branch
Writers’ Buildings
No. 976(27)-FB/O/4P-25/12

Dated, Kolkata, the 28th August, 2012

MEMORANDUM
The undersigned is directed to refer to this Department Memo. No. 964 (27)-FB/O/4P-25/12 dated
27.08.2012 and to say that three sets of signature of the Nodal Officer entrusted with the RIDF works of his
Department duly attested (as per format prescribed in Annexure enclosed) may be sent to this Department as
soon as possible for onward transmission to the office of the NABARD.

Sd/- (A.R. Chakraborty)
Special Secretary
To
The Addl Chief Secretary / Pr. Secretary /Secretary to the Government of West Bengal
-------------------------------------------------------------- Department
----------------------------------------------------------------------------------------------------------------------------------------------------------------Annexure
With ref. to Finance Department Memo. No.976(27)-FB/O/4P-25/12 dated 27.08.2012
Sl. no.

Name in full

Designation

Signature

1
2
3
Attested

Addl. Chief Secretary /
Pr. Secretary / Secretary
42

Rural Infrastructure Development Fund (RIDF)

<!-- page 51 -->

Finance Department

WBFR (TENDER RULES)

WBFR (Tender Rules)

43

<!-- page 52 -->

Important Government Orders

44

WBFR (Tender Rules)

<!-- page 53 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
Writers’ Buildings
No. 5400-F(Y)

Date, Kolkata, the 25th June, 2012

NOTIFICATION
In exercise of the power conferred by Clause (3) of Article 166 of the Constitution of India, the Governor
is pleased hereby to make the following amendments in the West Bengal Financial Rules, Volume-I, and in
partial modification of Notification No.10500-F dated 19th November 2004, (hereinafter referred to as the said
Rules), namely:AMENDMENTS
In the said Rules, (I) for sub-rules 8, 9 and 10 of Rule 47 substitute the following sub-rules:Rule 47(8) — Subject to Notes-1 to 5 below, orders should be placed only after open tenders or quotations
have been invited and in the cases where the lowest tender or quotation is not accepted, reasons should be
recorded under signature of the officer in charge of purchase.
Note-1. – Subject to the special rules or order or procedure that may be prescribed by the Government in
respect of a particular department, open tender shall invariably be invited for the supply of articles or stores or
for execution of works and services worth Rs.1,00,000=00 or more. For high-value purchase exceeding Rs.10
lakh or for purchasing plant, machinery, etc., of complex and technical nature, bids may be invited in two parts
under two-bid system laid down in rule 47C below. Selection of agency should be made on the basis of at least
three tenders, which shall be opened in presence of willing agents. If the number of tenders received is less
than three, tender should be invited afresh. In case of invitation of tender under two-bid system, if the number
of tenderers/bidders qualified in the technical bid is less than three, tender should be invited afresh. Purchase
upto Rs.10,000=00 may be made without any tender or quotation. The purchasing authority shall certify that
the purchase has been made at reasonable market price in cases of purchase from the open market without
tender/quotation. Purchase above Rs.10,000=00 and upto Rs.1,00,000=00 shall be made after inviting
quotations from at least four reliable firms, which shall be opened in presence of willing agents. In such cases
of purchase by invitation of quotation, procurement shall be finalised on recommendation of Local Purchase
Committee to be constituted in each office. In respect of offices outside Kolkata, the notice for quotation shall
be issued through notice board of the concerned office, the offices of the District Magistrate and the SubDivisional Officer and the Panchayat, Municipality of that locality. In Kolkata, such notice shall be circulated
by displaying in the notice board of Local Offices and by sending the same to suppliers etc.
Note -2 — Tender notice shall always be given due publication through the leading dailies in English, Hindi
and Bengali. The use of intermediate general suppliers should be discouraged. Open tender for supply of
articles or stores or for execution of works worth Rs.1,00,000/- or more shall be invited in the following
manner:
Sl. No.

Item

Manner of Tender

i.

For supply of articles or stores or for
execution of works and services with
estimated value exceeding Rs.10,000
upto Rs.1 lakh.

Publication of the work on the notice board and on
the official website of the administrative department,
if maintained.

WBFR (Tender Rules)

45

<!-- page 54 -->

Important Government Orders
Sl. No.

Item

Manner of Tender

ii.

For supply of articles or stores or for
execution of works and services with
estimated value exceeding Rs.1 lakh
upto Rs.5 lakh.

Publication of the work on the notice board and on
the website of the administrative department, if
maintained and also brief referral advertisement in
one daily Bengali newspaper [in case of hill areas of
Darjeeling District in Nepali newspaper].

iii.

For supply of articles or stores or for
execution of works and services with
estimated value exceeding Rs.5 lakh
upto Rs.10 lakh.

iv.

For supply of articles or stores or for
execution of works and services
with estimated value exceeding
Rs.10 lakh.

Publication of the work on the notice board and on
the website of the administrative department, if
maintained and also brief referral advertisement in
two daily newspapers, one in Bengali [in case of hill
areas of Darjeeling District in Nepali newspaper] and
the other in English.
Publication of the work on the notice board and on
the website of the administrative department if
maintained, and also in the official website of
Government of West Bengal, and also brief referral
advertisement in three daily newspapers, one each in
Bengali [in case of hill areas of Darjeeling District in
Nepali newspaper], in English and in Hindi.

Explanation: Brief referral advertisement will contain only certain title information such as name and location
of the scheme, last date for submission of tender, names of the websites where details are available.
The administrative departments are permitted to issue advertisements directly to the newspapers having
sufficient circulation for the said purpose of procurements, wherever necessary, at the rates approved by the
Information & Cultural Affairs Department, Government of West Bengal.
For Tender value of Rs. 50 lakh and above, e-tendering through the centralized e-Tender
Portal [http://wbtenders.gov.in] is mandatory, in addition to publication in print media.
Note-3 — A minimum period, as stated below, shall be allowed for submission of the tenders from the final
publication date.
Sl. No.

Item

Minimum period for submission of
tender from the last date of publication

a.

For supply of articles or stores or for
execution of works and services with
estimated value not exceeding Rs.10 lakh.

7 days

b.

For supply of articles or stores or for
execution of works and services with
estimated value exceeding Rs.10 lakh
upto Rs.1 Crore.

14 days

c.

For supply of articles or stores or for
execution of works and services with
estimated value exceeding Rs.1 Crore.

21 days

Note-4. – The head of the Office is authorised to purchase the supply fittings, sanitation and sewage plant
fittings and parts for pumps, compressors, engine and motors in use in the water supply and conservancy work
in the establishment, only in case of emergencies such as sudden failure of machines, etc. when it is not
possible to make the purchases after calling tenders or quotations. A certificate should always be recorded in
each such occasion over the signature of the head of the Office.
46

WBFR (Tender Rules)

<!-- page 55 -->

Finance Department
Note-5. – Foodstuffs for the hostels attached to Government schools and colleges may be purchased from the
open market, if it proves advantageous having regard to the price and quality of the articles and if the supplier
fails to supply the essential items for hostels.
Rule 47(9) (a) In selecting the tender to be accepted the financial status of the individuals and firms tendering
shall be taken into consideration in addition to all other relevant factors. Subject to the provisions of rule 47C
below where tender is invited in two-bid system, financial bid should not be opened until the technical bid is
opened and assessed for selection of the qualified bidder.
(b) Sales Tax and Income Tax Clearance Certificate should be furnished by the contractors for contract
value above Rs. 50,000=00.
(c) In the case of private individuals and firms tendering in foreign countries for contracts of large
value, that is, contracts of over Rs. 25 Lakh, the Head of the Indian Mission post concerned
should be consulted.
Rule 47(10) — The Comptroller and Auditor General and under his direction other Audit authorities shall
have power to examine contracts and to bring before the Public Accounts Committee any cases where competitive
tenders have not been sought or tenders other than L1 or H1, as applicable, have been accepted or where other
irregularities have come to light. Authorities who are authorised to enter into contracts or agreements should
send copies of all contracts and agreements valued over Rs.5 Lakh to the Principal Accountant General (A & E),
West Bengal, Principal Accountant General (Audit), West Bengal and Accountant General (Local Bodies Audit),
West Bengal.
(II) for sub-rules (7) and (8) of Rule 47B insert / substitute the following sub-rules —
Rule 47B. (7) Materials for which the Director General of Supplies and Disposals (DGS&D) and National
Informatics Centre Services Incorporated (NICSI) rate contracts are available can be purchased directly from
the enlisted agencies of DGS&D and NICSI at approved rate contracts.
(8) Drawing and Disbursing Officers, while preferring bills on purchases of articles to Kolkata Pay & Accounts
Offices/Treasuries in Districts, shall furnish a certificate on the body of the bills that purchases have been made
in strict compliance of the stores purchase policy of the State Government and Pay & Accounts Officers/
Treasury Officers shall, while scrutinizing the bills, ensure that such certificates are furnished.
Purchase of Duplicating machine, Computer and peripherals, printers, photocopiers and other office equipments
for use in Government Offices and liveries for use of the Government employees shall continue to be governed
by the Finance Department orders issued from time to time.
(III) after rule 47B insert the following rules —
Rule 47C–Two-bid System — For high value purchase exceeding Rs.10 lakh or for purchasing plant,
machinery, equipments etc, of complex and technical nature, bids shall be invited in two parts as under:
(a) The technical bid consisting of all technical details along with commercial terms and conditions;
(b) Financial bid indicating item-wise price for the items mentioned in the technical bid.
The technical bid and the financial bid should be sealed by the bidder in separate cover duly superscribed
and both the sealed covers are to be put in a bigger cover which should also be sealed and duly superscribed.
The technical bids shall be opened by the purchasing department/office at the first instance and evaluated by a
competent committee or authority. At the second stage, financial bids of only the technically acceptable offers
shall be opened for furnishing value and ranking before finalization and awarding of the contract. After evaluation
the lowest rate (L1) financial bid from among the technically qualified bidders shall be accepted.
Rule 47D –(1) (a) State Government Corporations and Autonomous Bodies, listed in Annexure – ‘C’ may be
nominated for execution of Government works as agency of the Government.
WBFR (Tender Rules)

47

<!-- page 56 -->

Important Government Orders
(b) Central organizations / Public Sector Enterprises / Companies / Undertakings specialized in construction
of roads, bridges, buildings etc., and listed in Annexure – ‘D’ may also be engaged as agency for the purpose
of Sate Government works.
(2) Action to engage these organizations by the Departments should be to supplement the function of Public
Works Department of the Government and resorted to in cases where the departments consider that the work
is of urgent nature. The Department should satisfy itself that it will be economical and in public interest to
engage such Organization for Agency function.
(3) The various procedural matters as laid down in Public Works Department codes, manuals etc. as well as
the rules prescribed herein shall be equally applicable for the purpose of execution of works through the State
and Central Organizations as mentioned at clause (1) above. The organizations nominated as the State
Government agency shall execute the entrusted works after engagement of contractors to be selected observing
the normal tendering procedure and accepting the L1 rate when the job involves making payment for jobs done
and H1 rate when the tender is for sale of materials connected with execution of the entrusted works.
(4) The agency fees to be allowed and terms and conditions of the Contract/Memorandum of Understanding
(MOU) to be entered into with the agency are as follows :(a) The Contract/MOU may be for composite works and may be a combination of “Lump Sum Contract”
and “Percentage Rate Contract”/“Item Rate Contract”. Estimated cost shall be based on Public Works Department
Schedule of Rates for the scheduled items of work and market rate as approved by the head of the Engineering
wing of the Agency organization for the non-scheduled items of work. Component-wise break-up of the agency
fee is given at clause (6) below.
(b) (i) The nominated agency organization will first prepare a forecast estimate of cost of the work on
the basis of standard unit cost as per the State Public Works Department Schedule of Rates in case of works
within the state and Central Public Works Department Schedule of Rates in case of works outside the State on
the basis of preliminary drawings of the work supplied by the concerned department of the state Government
or prepared by the agency, if asked to do so, and submit it to the employing department of the Government to
enable it to obtain Administrative Approval for the work at appropriate level. On receipt of the Administrative
Approval for the concerned work indicating scope of the work and approximate cost, the concerned agency
organization will prepare the detailed cost estimate of the work on the basis of drawings received from the
employing department of the government or prepared by the organization itself, as the case may be, and send
it to the employing department of the Government for acceptance.
(b) (ii) All projects with the estimated cost of Rs. 5 crore and above shall be vetted by a duly
constituted Technical Committee in the Finance Department.
(c)

Drawing and design by the Department -

i)
In cases where work is to be executed as per design and drawing of the department, all the detailed
working drawings, both architectural and structural must be prepared before hand, and should form part
of the preliminary documents to be given to the selected organization. It should also contain complete and
detailed specifications of the work. The preliminary documents must set out complete scope of the work.
Only the drawings and the detailed specifications as contained and/or referred to in the preliminary
documents shall form the basis of execution and payment.
ii) The extra payment or recovery over and above the accepted rate shall be called for only in the event
of authorized deviations from the drawings and specifications (as given and/or referred to in the preliminary
documents) in course of execution and not otherwise.
48

WBFR (Tender Rules)

<!-- page 57 -->

Finance Department
(d) Drawing and design by the agency i)
In cases where the detailed architectural and structural drawings are to be provided by the agency,
all information regarding the work to be executed through the Agency Organisation such as the architectural
and structural parameters, details of the functional requirement and complete specification thereof, as available,
must be passed on by the concerned Department to the Agency Organisation. The Agency Organisation shall
prepare the preliminary documents of the work to be executed through Agency Organisation. The preliminary
documents must contain complete and detailed specifications of the work, working drawings, both architectural
and structural and should set out complete scope of the work. Only the drawings and the detailed specifications
as contained and/or referred to in the preliminary documents shall form the basis of execution and payment.
ii) A condition should be stipulated in the preliminary documents that the work shall be executed
through the Agency Organisation as per detailed design and architectural drawings to be prepared by the
agency conforming to the given parameters and functional requirements as mentioned in the preliminary
documents, and submitted to the employing department within specified time after the award of work. The
agency shall accordingly get the design/drawings approved by the employing department before taking up the
execution of the work.
iii) In case any modification for any reason is ordered in course of execution, suitable adjustment for
extra payment or recovery shall be effected only if such modification results in change in the scope of work as
given in the preliminary documents, or any change from the specified parameters.
e)
i)

I)
The composite works offer documents shall contain:
the detailed architectural and structural drawings,

ii)

detailed specifications for the various items and components of the work,

iii) the schedule of quantities for the various items and components of the work,
iv) the inclusions in and exclusions from the scope of the contract, if required, for better clarity, and,
v) monitoring and supervision of the various stages of work, the percentage of work done on the contract
value and release of intermediate and final payments.
II) The schedule of quantities referred to above is only limited for the purpose of assessing the quantum of
work involved. It is not meant for subsequent measurement and payment in the course of execution of the
work. Deficiencies noticed, if any, by the agency should be immediately brought to the notice of the employing
department, who shall examine the same, and make necessary corrections, if required, to the offer documents
before assignment of the work.
III) The agency organization shall arrange for execution of the work through the contractor as per the drawings
and specifications as given in the documents. No claim for any payment on account of deviations and variations
in quantity of any item(s) or component(s) of the work shall be entertained, unless they are authorized deviations
from the parameters drawings and specifications contained in the documents.
IV) The rate of deviated items shall be determined as per terms and conditions of Contract/MOU between the
agency organization and the employing Government department.
V) The concerned Agency Organisation shall monitor, supervise and physically verify that the work has been
done in each stage in conformity with the drawings and specifications contained in the offer/preliminary
documents, and certify the same before recommending release of the stage payment.
(5) The agency job will be broken into following components: i) preparation of estimate, design and detailed drawing
ii) invitation of tender, evaluation of bids and award of work
iii) supervision of work, checking of bills, payment and submission of utilization certificate, completion
certificate.
WBFR (Tender Rules)

49

<!-- page 58 -->

Important Government Orders
(6) Agency Fee
Component-wise agency fee will be as follows:
A. For buildings above G+3, buildings with basements and roads and bridges.
i)

For preparation of estimate, design and detailed drawing
* 3% of estimated cost for exclusive and customized drawing and design;
* 2% of the estimated cost for standard drawing and design.
(at least 5 sets each of the documents under this component should be submitted)

ii)

invitation of tender, evaluation of bids and award of work
* 2% of estimated cost of the works

iii) supervision, monitoring, checking of bills, payment and submission of utilization certificate, completion
certificate
* 3.5% of estimated cost of the works.
Thus the agency fee comes to 8.5% of sanctioned cost estimate in case of works involving exclusive and
customized drawing and design and 7.5% of sanctioned cost estimate in case of works involving standard
drawing and design.
B. for buildings upto G+3 (without basement) for (i) exclusive and customized design and drawings and (ii)
standard design and drawings.
5% of estimated cost for all the components taken together.
The rate of deviated items shall be determined as per terms and conditions of Contract/MOU between the
agency organization and the employing Government department. No contingency / overhead charge shall be
payable other than the 8.5 % / 7.5 % / 5 % as mentioned hereinabove.
(7) Qualified Staff – In case project cost exceeds Rs.1 crore but within Rs.5 crore at least one qualified
Graduate Engineer along with two Diploma Engineers should be engaged in supervision and monitoring of the
job. In case of project cost exceeding Rs.5 crore, requisite number of qualified and experienced Graduate
Engineers along with Diploma Engineers should be engaged according to the value of the project for proper
supervision and monitoring of the work.
(8) Specifications – In case of absence of specifications for any job in the State Public Works Department
Code /Manual, the Central Public Works Department specifications should be followed.
(9) Mobilization Advance- Mobilization advance not exceeding 10% of the sanctioned estimated cost may
be given, if requested by the agency organization in writing within one month of the order to commence the
work. Such advance shall be in two or more installments to be determined by the competent authority of the
employing department at his/her sole discretion.
By order of the Governor
Sd/(H. K. Dwivedi)
Secretary to the
Government of West Bengal.
50

WBFR (Tender Rules)

<!-- page 59 -->

Finance Department
ANNEXURE – C
(See Rule 47D)

State Bodies and Corporations
1.

West Bengal Industrial Infrastructure Development Corporation

2.

Mackintosh Burn Ltd.

3.

Britannia Engg. Ltd.

4.

Wasting House Saxby Farmer

5.

Hooghly River Bridge Commissioners

6.

Development authorities under Urban Development Department.

7.

Other State Organizations/Corporations to be selected by the State Government from time to time.

ANNEXURE – D
(See Rule 47D)

Central Organizations/Public Sector Enterprises/Companies/undertakings
1. Central Public Works Department
2. National Building Construction Corporation (NBCC)
3. RITES
4. IRCON International Limited (formerly Indian Railways Construction Company Ltd.)
5. Bridge & Roof
6. Balmer Lawrie
7. HSCL (Hindustan Steelworks Construction Limited)
8. EIL (Engineers India Limited)
9. Other Central Organizations/Corporations to be selected by the State Government from time to time.

WBFR (Tender Rules)

51

<!-- page 60 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 8183-F(Y)

Kolkata, the 26th September, 2012.

MEMORANDUM
Sub.: Clarification regarding engagement of 'Agency' under Rule 47D of Finance Department's
Notification No.5400-F(Y) dt.25.6.2012
The Governor is pleased to insert the following item in Annexure - D after serial no.9 of this Department
Notification No.5400-F(Y) dt.25.6.2012 and issue the following clarifications :
In Annexure-D after serial No. 9
"10. "Engineering Projects (India) Limited."
2. In connection with para (II), rule 47B(7) of the aforesaid Notification the rates of various items under rate
contract of the Director General of Supplies & Disposals [DGS&D], Government of India can be viewed at
their website www.dgsnd.gov.in.
3. After issuance of the aforesaid Notification various clarifications have been sought by different Departments
regarding the appointment of Government Agency for execution of work in terms of rule 47D. In order to clear
the confusions over scope of Rule 47D included in the Finance Department Notification no. 5400- F(Y)
dt.25.6.2012, the undersigned is directed to issue the following clarifications:
(I) Under Rule 47D, Administrative Departments, other than the Works Departments of the State
Government viz. Public Works Department, Irrigation & Waterways Department, Public Health Engineering
Department, Housing Department etc., can engage Government Agency on nomination basis from the
list appended as Annexure ‘C’ and Annexure ‘D’ of the aforesaid notification.
(II) The Administrative Department, other than Works Department, can engage an Agency for assisting
it in the execution of works only when the Departmental Secretary is satisfied that the Works Department
of the State Government is not in a position to execute the job within the required timeframe.
(III) The Government Agency shall perform the job like Works Department at the fees prescribed in the
above mentioned Notification.
(IV) the Agency so engaged by the Administrative Department shall not execute the work on its own and
has to get the work executed by a contractor to be selected through a transparent tendering process. Also,
it cannot bid for the work for which it has been engaged to perform the agency functions.
(V) The Department/ Office appointing such Government Organisation as "Agency" for execution of
work shall enter into an agreement/Memorandum of Understanding [MoU] with that Organisation in this
regard.
(VI) Normally, the Agency shall perform the following jobs on behalf of the Administrative Department:
(a)

52

Prepare the Drawing & Design including detailed architectural and structural drawings and
specifications of the works as per standard code of the Bureau of Indian Standard [BIS]/Indian
Road Congress [IRC].
WBFR (Tender Rules)

<!-- page 61 -->

Finance Department
(b) Submit the Drawing & Design including detailed architectural and structural drawings and
specifications of the works to the concerned Department/office for Administrative approval.
(c)

After getting Administrative Approval, prepare the detailed cost estimate and detailed specification
of works as per schedule of rates of the P.W. Department for 'schedule' items and market rate
for 'non-schedule' items. Submit the detailed cost estimate for administrative and financial approval
of the Department.

(d) After getting administrative and financial approval for the project from the Administrative
Department, invite tender observing the existing rules and procedures of the State Government.
Select the L1 rate in case of procurement and H1 rate in case of sale/disposal.
(e)

Enter into agreement with the selected contractor for detailed execution of work and terms of
payment.

(f)

Execute the works through the selected Contractor. Monitor and supervise the works in order to
ensure that the work conform to specifications and drawings.

(g)

(i) Verify the running account bill of the contractor, (ii) raise a summary bill along with a 'certificate
on work done conforming to specification and quality' on the basis of that running account bill,
and (iii) submit the bill with certificate as at (ii) to the employing Administrative Department for
payment. All payments to the contractor shall be routed through the Agency.

(h) Bill for Agency Fee shall be raised separately.
(i)

Submit completion certificate for the completed works immediately after its full execution,

(VII). The Administrative Department shall make a primary verification of the claim with reference to
work done and scrutinise the Bills for Agency fee and charges for work done. After satisfaction about the
claim, the Administrative Department shall process the bill of the Agency for payment through Treasury/
Pay & Accounts Office using Contingency Bill Form [T.R. Form No. 26] along with the sub-voucher of the
Agency and work done certificate.
(VIII). On the basis of the completion certificate the Administrative Department shall make necessary
entry of such fixed asset of the State Government in the Fixed Asset Register of the Department.

Sd/[H. K. Dwivedi]
Secretary to the
Government of West Bengal.

WBFR (Tender Rules)

53

<!-- page 62 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 9754-F(Y)

Kolkata, 3 rd December, 2012

MEMORANDUM
Laying down the procedure of re-tender has been engaging attention of the Government for some time
past since the existing Tender rule of the State Government does not stipulate any such procedure. Various
Government Departments and offices are frequently enquiring about the same. In these circumstances, it is felt
necessary to prescribe the re-tender procedure and number of times it may be resorted to in case of the number
of qualified bidders falling below three. Now, therefore, the Governor is pleased to prescribe the following
procedure of re-tender :
1.

If the response to Tender (including e-Tender) is less than three, then Tender should be invited afresh in
terms of note 1 below rule 47(8) of West Bengal Financial Rules as amended by this department notification
no. 5400-F(Y) dt.25.6.2012 . Such Re-Tender notice shall be published in widely circulated dailies for
conventional Notice Inviting Tender’ (NIT) and also through e-Tender portal in case of e-Tender. Prior to
invitation of Re-Tender or fresh Tender the eligibility criteria and other terms & conditions as contained in
the first ‘Notice Inviting Tender’ shall have to be reviewed by the Tender Inviting Authority to ascertain
whether (i) it was too much restrictive, say, specifications and qualifications were fixed at higher standard
than required, (ii) advertisements in the widely circulated Newspapers were properly published and (iii)
other related procedural matters were observed in its entirety. Even if, after taking appropriate steps, the
response to the Re-Tender is less than three, that tender may be accepted without reference to the Finance
Department, provided the rates do not exceed the estimated or the schedule rates beyond 5% in case of
works estimate and reasonable prevailing market price for goods and service in other cases. Otherwise,
such cases should be referred to the Finance Department for decision.

2.

The Tender Inviting Authority shall maintain a ‘Tender Register’ in the proforma as enclosed in Annexure-I.

This order shall take immediate effect.
West Bengal Financial Rules will be amended to incorporate the above provisions in due course.

Sd/- H. K. Dwivedi
Secretary to the
Government of West Bengal.

54

WBFR (Tender Rules)

<!-- page 63 -->

WBFR (Tender Rules)

1

2

3

4

5

6

7

8

Nos &names
of parties not
qualified after
technical
evaluation

9

10

11

13

14

Signature of the officer-in-charge

12

Nos & names
Whether
Contract
Name of Value of Scheduled date
of parties not
contract
no. & date contractor contract of complection
qualified
awarded to
after Financial lowest tenderer
evaluation
evaluated L1;
if not, reason
thereof

TENDER REGISTER

Tender Item/Nature Mode of
Date of
Type of
Last date of Nos of
No.
of work
tender Publication Bidding
receipt of tenders
enquiry
of NIT
(single/two
tender
received
bid system)

Annexure – I
[Enclosure of No.9754-F(Y) dt.03.12.2012]

Finance Department

55

<!-- page 64 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 8648-F(Y)

Kolkata, the 12th October, 2012

MEMORANDUM
The West Bengal Financial Rules provided for preferential treatment by way of 10% price preference to the
State Government organizations, namely, M/s. Mackintosh Burn Ltd., M/s, Britannia Engineering Ltd., and
M/s. Westinghouse Saxby Farmer Ltd., vide Note-1 below sub-rule (3) of rule 47A of West Bengal Financial
Rules. Note-1 below sub-rule (3) of rule 47A reads as follows:"Note-1. — The following concessions are allowed to M/s. Mackintosh Burn Ltd., M/s. Westinghouse
Saxby Farmer Ltd., and M/s. Britannia Engineering Ltd. :(i) M/s. Mackintosh Burn Ltd., M/s. Westinghouse Saxby Farmer Ltd., and M/s. Britannia Engineering Ltd.
shall be eligible to be allowed 10% preference in rate vis-a-vis other organizations engaged in similar activities.
Such preference shall, however, be given only for the purpose of selection, but once selected on the basis of
such preference, the companies shall have to execute the work at the lowest valid price bid received in the
process of selection, failing which orders will be placed with the organization/firm offering the lowest valid
rate;
(ii) The Companies shall be exempted from submitting earnest money for all tenders from the Government of
West Bengal, State Government Undertakings and Statutory Bodies, directly controlled by the State Government;
(iii) Security deposit for all works controlled directly or indirectly by the State Government and executed by
the Companies shall be limited to Rs. 1 Lakh."
2. The withdrawal of the preferential treatment given to the State Government organizations, mentioned
above, has been under consideration of the Government for some time now. Therefore, the undersigned is
directed by order of the Governor to withdraw the preferential treatment earlier given to M/s. Mackintosh Burn
Ltd., M/s. Westinghouse Saxby Farmer Ltd,, and M/s. Britannia Engineering Ltd, and make the following
amendment in Rule 47 A of West Bengal Financial Rules:
Note - 1 below sub-rule (3) of Rule 47A is deleted.
3. This order will take immediate effect. Necessary amendment in West Bengal Financial Rules will be made
in due course.

Sd/(H. K. Dwivedi)
Secretary to the
Government of West Bengal.
56

WBFR (Tender Rules)

<!-- page 65 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 3739-F(Y)

Kolkata, the 3rd May,2012

NOTIFICATION
Sub.: Mandatory publication of 'Tender Inviting Notice' on e-Tender Portal
For some time past the Government was considering improving the present system of inviting Tender by
different Departments of the State Government with a view to establish accountability, transparency and
uniformity in the system in a centralised manner.
Keeping in view the above object, the National Informatics Centre [NIC], an organisation of Government
of India, developed a portal [http://wbtenders.gov.in] exclusively for uploading the tender related documents of
the State Government.
The 'e-Procurement Solution' will help both the Government buyers and the suppliers to reduce the cycle
time, unnecessary paper work, waiting in long queues and simultaneously enhance the transparency in the
entire process thereby ensuring good governance. It is an easy-to-use, web-based solution for conducting
dynamic exchanges in an on-line environment. It will provide real-time bidding solutions for the Government
buyers and sellers. Some State Government Departments are already using this portal for inviting their
e-Tender.
For the purpose of gainful utilisation of the said portal, the Governor has been pleased to decide that:
1. In addition to existing system of inviting tender, it will be mandatory for all State Government
Departments, their subordinate Offices and all Autonomous Bodies / Local Bodies / Corporations / PSUs under
their control to publish their 'Tender Related Information' [TRI] on the centralized e-Tender Portal [http://
wbtenders.gov.in] if the Tender Value is Rs.50 lakhs and above. The Tender Value less than Rs.50 lakhs may
also be uploaded on the centralized e-Tender Portal [http://wbtenders.gov.in] at the discretion of the Tender
floating authority or the concerned Department.
2. ' The Tender Related Information' means and covers e-Procurement, e-Tendering, e-Selling and eAuction, Request for Proposal, Request for Expression of Interest, Notice for Pre-Qualification, Registration of
the Contractors, Notice inviting Tender/Bid or Proposal in any form, Tender Enquiries, Corrigenda and also the
details of the contract awarded as a result of finalization of the Tender process.
3. The Departments or its subordinate offices that are already publishing their 'Tender Related
Information' on their own websites and/or on any other websites shall ensure that their 'Tender Related
Information' are simultaneously published / mirrored on the centralized e-Tender Portal [http://wbtenders.gov.in].
4. The Digital Signature Certificate, which is essential, for e-Tendering shall be obtained from the NICCA which is also acting as a Certifying Authority.
5. This Order shall take effect from 1st July 2012.
In order to facilitate implementation of aforesaid decisions regarding e-Publication of 'Tender Related
Information' on the centralized e-Tender Portal, the NIC will provide detailed guidelines for using the said
Portal. The guidelines will also be available on the centralized e-Tender Portal [http://wbtenders.gov.in]. On
registration by the Government user, 'User ID' and 'Password' will be created and mailed to the users. The
Government of West Bengal will also make arrangements for necessary training to the concerned officials,
with technical support from NIC for the users of the e-Tendering Portal.
A Roadmap for implementation of the e-Procurement Process in the Government Departments is enclosed
with this Order.
The Departmental heads are requested to circulate this Notification to their subordinate Offices and the
Autonomous Bodies / Local Bodies / Corporations / PSUs under their control.
Sd/- H.K. Dwivedi
Secretary to the
Government of West Bengal.
WBFR (Tender Rules)

57

<!-- page 66 -->

Important Government Orders
Roadmap for implementation of e-Procurement Process in the Government Departments

10.

1.

Each Department shall nominate at least one 'Nodal Officer' for implementation and monitoring of
the e-Procurement in the respective department.

2.

The Nodal Officer of the Department shall handover to NIC the organisation chart related to tendering
in his Department mentioning the offices from where tenders will be floated or published in the
Portal.

3.

Nodal Officer shall apply to NIC for Digital Signature Certificate [DSC] as Nodal Officer on behalf of
that Department for implementing e-Procurement.

4.

The other Departmental Officers who will be authorised to float e-Tender under a Department shall
be required to obtain DSC from NIC through the Nodal Officer of that Department. The cost of
obtaining DSC from NIC is Rs.555/- per user. Application Form for Digital Signature Certificate
[DSC] along with detailed information regarding Digital Signature Certificate is enclosed with this
Roadmap.

5.

For uploading the e-Tender document in the Tender Portal it will be required to have minimum two
(2) authorised officers who have their own DSC. The DSC is neither transferable nor it can be delegated
to other officer.

6.

The DSC issued is Department specific and officer specific. So, it will not be possible for the authorised
Officers (having DSC) of one Department to upload e-Tender of other Department.

7.

In the headquarter, each Department shall nominate at least two officers who will be members of
each Tender Committee under that Department, so that they can upload the e-Tender document in
the Tender Portal on the authorisation of their DSC.

8.

Similarly, in each District or Region ( as per requirement of the Department) the Department shall
nominate at least two officers who will be members of each Tender Committee on behalf of that
Department, so that they can upload the e-Tender document in the Tender Portal on the authorisation
of their DSC.

9.

Summary information in respect of the Tender progress in relation to the Tender has to be uploaded
in the web-server of the Tender Portal. Documents relating to 'Notice Inviting Tender' [NIT] shall be
loaded as a .pdf file and the financial bid in the prescribed .xls format. For the financial bid NIC has
developed three templates that have to be strictly adhered to. The Tendering Authority shall select
any one of the three formats which will be suitable for them for that particular Tender. The software
developed by NIC shall take care for selection of L1 rates. The Software shall make automatic
encryption of the Financial Bid and no one shall be allowed to open the Financial Bid prior to the
date & time earmarked for opening the Financial Bid. Tender should normally be floated in two parts,
one Technical bid and other Financial Bid. After evaluation of the Technical Bid, those who qualify
their Financial Bid shall be opened.
(i) NIC at headquarter or at any central location, preferably within Writers Buildings, shall provide a
"Helpdesk" to render necessary help to the authorised officers of the Departments within Kolkata
(including Bidhannagar) to float e-Tender.
(ii) The District Information Officers [DIO] of NIC at the District shall provide a "Helpdesk" to
render necessary help to the authorised officers of the Departments at the District level.

58

WBFR (Tender Rules)

<!-- page 67 -->

Finance Department
Necessary information regarding Digital Signature Certificate [DSC]
1. What is a Digital Signature Certificate?
Digital Signature Certificates (DSC) are the digital equivalent (that is electronic format) of physical or paper
certificates. Examples of physical certificates are drivers' licenses, passports or membership cards. Certificates
serve as a proof of identity of an individual for a certain purpose; for example, a driver's license identifies
someone who can legally drive in a particular country. Likewise, a digital certificate can be presented electronically
to prove your identity, to access information or services on the Internet or to sign certain documents digitally.
2. Why is Digital Signature Certificate (DSC) required?
Like physical documents are signed manually, electronic documents, for example e-forms are required to be
signed digitally using a Digital Signature Certificate. Transactions that are done using Internet if signed using a
Digital Signature certificate becomes legally valid.
3. Who issues the Digital Signature Certificate?
A licensed Certifying Authority (CA) issues the digital signature. Certifying Authority (CA) means a person who
has been granted a license to issue a digital signature certificate under Section 24 of the Indian IT-Act 2000. The
National Informatics Centre is also authorised to issue the Digital Signature Certificate.
4. What are the different types of Digital Signature Certificates valid for e-Tendering programmme ?
The different types of Digital Signature Certificates are;
Class 2: Here, the identity of a person is verified against a trusted, pre-verified database.
Class 3: This is the highest level where the person needs to present himself or herself in front of a Registration
Authority (RA) and prove his/ her identity.
5. What type of Digital Signature Certificate (DSC) is to be obtained for e-Filing on the e-Tendering Portal?
DSC of Class 2 and Class 3 category issued by a licensed Certifying Authority (CA) needs to be obtained for
e-filing on the e-Tendering Portal.
6. How to obtain DSC for dept users?
NIC hqrs is authorised to issue the DSC for officials in Govt depts./PSUs and the fees are:
For Govt Officials Rs. 555 for USB e-Token (at present)
The validity period for the Smart Card is 2 years.
The DD should be drawn in favour of "Accounts Officer, National Informatics Centre, New Delhi".
7. How much time do CAs take to issue a DSC?
The time taken by Certifying Authorities to issue a DSC may vary from three to seven days.
8. What is the validity period of a Digital Signature Certificate?
The Certifying Authorities are authorized to issue a Digital Signature Certificate with a validity of one or two
years. The maximum period for which the DSC is issued is only two years. On the expiry of the term, the
Digital Signature Certificate can be revalidated by paying the fees again.
9. What is the legal status of a Digital Signature?
Digital Signatures are legally admissible in a Court of Law, as provided under the provisions of IT?
10. Is a company required to obtain a Digital Signature Certificate in its own name for e-Tendering?
Digital Signature Certificate (DSC) is not required by Companies but by individuals. For example the Director
or the Authorized signatory signing on behalf of the Company requires a DSC.
11. Can I do e-filing of documents if I do not possess a DSC?
No. It is mandatory to have a valid digital signature certificate for e-filing the forms on e-Tendering portal.
WBFR (Tender Rules)

59

<!-- page 68 -->

Important Government Orders
Page-1

NIC Certifying Authority
National Informatics Centre
Ministry of Communications and Informantion Technology
Government of India

Ref. No. ..................

(To be filled by NICCA)

DIGITAL SIGNATURE CERTIFICATE REQUEST FORM
NOTE:
1.
2.
3.
4.
5.
6.
7

This application form is to be filled by the applicant.
Please fill the form in BLOCK LETTERS.
Please Tick (9) the appropriate option.
All subscribers are advised to read Certificate Practice Statement of CA.
Incomplete/Inconsistent applications are liable to be rejected.
Validity period should not exceed the date of superannuation of the applicant.
Asterisk (*) marked entries should not be left blank as these are reflected in the Digital Signature Certificate.

Affix Recent
Passport Size
Photograph

1.

Category of Applicant

:

Government / Judiciary /PSU & Statutory Bodies / Registered Companies

2.

Class of Certificate Required (see pt. 11 at page 4)

:

Class I /Class II /Class III

3.

Certificate Required (Usage) (see pt. 11 at page 4)

:

Individual (Signing) / Encryption / SSL Server

4.

Certificate Validity (Max. 2 Years)

:

Two years / Specify validity (if less than 2 years)

5.

Date of superannuation* (dd/mm/yyyy)

:

__________________________________________________________________

6.

Name*

:

__________________________________________________________________
(First Name)
(Middle Name)
(Last Name)

7.

Designation

:

__________________________________________________________________

8.

Email ID* (Official email-ID preferred)

:

__________________________________________________________________

9

Ministry/Department
:

__________________________________________________________________

a) Office Address

__________________________________________________________________
Telephone (Official)__________________(Resi/Mobile) _________________
b) Residential Address

:

__________________________________________________________________
__________________________________________________________________

10. Identification Details (Tick any one)
[Employee ID / Passport No. / PAN Card No. / Voter ID
Card No. / Driving License No. / PF No. /Bank Account
Details /Ration Card No.]
11. Certificate Subject Details*
(These will be used in Certificate subject.)

:

__________________________________________________________________
__________________________________________________________________

:

Organization* ____________________________________________________

:

Organization Unit* _______________________________________________
City _____________
State* _________
Country*

12. SSL Certificate Details

:

INDIA

Web Server _______________________________________________________

(In case the application is for a device then details of

:

Services __________________________________________________________

Server/Device for which the certificate is being applied

:

IP Address ________________________________________________________

for must be filled.)

:

URL/Domain Name _______________________________________________

:

Physical Location __________________________________________________

Date: ....................

........................................

Place : .........................

(Signature of the Applicant)
(For NICCA Office use only)

Smart Card/USBToken Sr. No.: ................................
Authorised Signatory / RAA

Request No. : .......................................
RA Code :....................................

Name: .............................................
Date: ...............................

60

Remarks:.................................

WBFR (Tender Rules)

<!-- page 69 -->

Finance Department
Declaration by the Subscriber
I hereby declare and understand that
1.

I have read the subscriber agreement under Resources (https://nicca.nic.in).

2.

I shall keep the private key safe and will not share with others.

3.

I shall verify the contents and the correctness of the certificate before accepting the DSC.

4.

I shall send a signed mail to NIC-CA (support@camail.nic.in) to acknowledge the acceptance of the DSC. I also undertake to sign an
additional declaration form in case of Encryption Certificate.

5.

I shall not use the private key before acceptance of the DSC.

6.

I authorize NIC-CA to publish the certificate in the NIC-CA repository after acceptance of the DSC.

7.

If the private key of my DSC is compromised, I shall communicate to NICCA without any delay as per requirement mentioned in Regulation
6 of Information Technology (Certifying Authority) Regulations, 2001. (Doc ID CA2-50027.pdf, available under Repository>CPS &
Forms>All Forms at https://nicca.nic.in)

8.

I understand the terms and conditions of issued DSC and will use the DSC under the terms of issue as in the Certificate Practice Statement.

9.

I understand that on cessation of my employment, I shall inform NICCA and my present employer for revocation of my Digital Signature
Certificate.

10. I certify the following: (Tick whichever is applicable)
o I have not applied for a DSC with NIC-CA earlier.
o I have been issued a DSC by NICCA with User ID ________________________________________________________________which is
Valid/Revoked/Suspended/Expired.
The information furnished above is true to the best of my knowledge and belief. I will comply with the terms and conditions of Subscriber (as in section
40-42 of the IT Act 2000) and those of the Certificate Practice Statement of the NIC-CA. If at a later stage any information is found to be incorrect or
there is non-compliance of the terms and conditions of use of the DSC, NIC-CA will not be responsible for the consequences/ liabilities and will be free
to take any action including cancellation of the DSC.
Date : .....................................
Place : ....................................

..................................................
(Signature of the Applicant)
Verification and Declaration by Head of Office of Applicant

1. This is to certify that Mr. /Ms. ________________________________ has provided correct information in the Application form for issue of Digital
Signature Certificate for subscriber to the best of my knowledge and belief. I have verified the credential of the applicant as per the records and the
guidelines given at page 5. I hereby authorize him/her, on behalf of my organization to apply for obtaining DSC from NICCA for the purpose as
specified at point 3 of page-1.
2. It is noted that the organization shall inform NICCA for revocation of DSC on the cessation/superannuation of his/her employement.
Date : ................................

(Signature of Officer with stamp of Org./Office)

Place: ................................

Name of Officer with Designation:

Office Email:
Forwarded by SIO / NIC Coordinator
(Only for Class-2 & Class-3 Certificate)

(Signature of SIO /NIC Coordinator)
Name:

............................................

Date: ...........................
Office Seal:
This form is to be forwarded to the respective RA Office of NIC-CA.

WBFR (Tender Rules)

61

<!-- page 70 -->

Important Government Orders
Additional Declaration by the Subscriber for Encryption Certificate
I hereby declare and understand that
1

I am solely responsible for the usage of these Certificates/Tokens/ Technology. I shall not hold NICCA responsible for any data loss
damage, arising from the usage of the same.

2.

I am aware that Key Escrow/Key Archiving of Encryption keys is not done by NICCA and I shall not hold NICCA responsible or approach
NICCA for recovery of my private Encryption Key, in case of its loss or otherwise.

3.

I shall be responsible for compliance to the relevant sections of the IT Act/Indian Telegraphic Act and other Acts/laws of the Indian legal
system, pertaining to Encryption/Decryption of any message or document or electronic data, and I shall be liable for associated penal actions,
for any breaches thereof.

4

NICCA shall not be held responsible and no legal proceedings shall be taken against NICCA for any loss and damage that may occur due to
any reason whatsoever including technology upgradation, malfunctioning or partial functioning of the software, USB token, Smart Card or
any other system component.

5.

I am aware that the Encryption Certificate, issued by NICCA is valid only for the suggested usage and for the period mentioned in the
certificate. I undertake not to use the Certificate for any other purpose.

6.

I am conversant with PKI technology, and understand the underlying risks and obligations involved in usage of Encryption Certificate.

7.

I certify the following: (Tick whichever is applicable)
o I have not applied for an Encryption Certificate with NIC-CA earlier.
o I have been issued an Encryption Certificate by NICCA with User ID________________________________________________which is
Valid / Revoked / Suspended / Expired.

The information furnished above is true to the best of my knowledge and belief. I will comply with the terms and conditions of Subscriber (as in section
40-42 of the IT Act 2000) and those of the Certificate Practice Statement of the NIC-CA. If at a later stage any information is found to be incorrect or
there is non-compliance of the terms and conditions of use of the Encryption Certificate, NIC-CA will not be responsible for the consequences/ liabilities
and will be free to take any action including cancellation of the Encryption Certificate.
Date : .....................................
Place : ....................................

..................................................
(Signature of the Applicant)
Declaration by Head of Office of Applicant

I hereby authorize Mr./Ms _________________________________________________________________________ employed in this Organization, to apply
for Encryption Certificate from NIC-CA. It is further certified that a Policy/Procedure is in place, which describes the complete process for Encryption
Key Pair Generation, Backup Procedure, safe-keeping of Backups and associated Key Recovery Procedures. Tho consequences of loss of tho koy have
been explained to the user and he/she has been advised about securing the key and making it available to relevant authorities, in case of emergency.

Date : .........................

(Signature of Officer with stamp of Org /Office)

Place : ........................

Name of Officer with Designation:

Office Email:
Forwarded by SIO / NIC Coordinator
(Only for Class-2 & Class-3 Certificate)
(Signature of SIO /NIC Coordinator)
Name:
Date:
Office Seal:
This form is to be forwarded to the respective RA Office of NIC-CA.

62

WBFR (Tender Rules)

<!-- page 71 -->

Finance Department
Instructions for DSC Applicants
1.

NIC-CA abides by the Information Technology Act, 2000, laid down by the Govt. of India. The applicant is advised to read this IT Act 2000
under Resources (https://nicca.nic.in).

2.

To use DSC for exchanging Digitally signed Email, S/MIME compatible Mail clients should be used (Outlook Express, etc.). Also, please
ensure that your email-id is issued from a POP compatible Mail server. For security reasons, NICCA prefers usage of Official E-mail ID.

3.

Subscriber is required to send one copy of DSC request form, duly signed and forwarded by Head of Office. Applicant is advised to retain
a copy of the same, for filling up the form online while generating Keypair.

4.

The forwarded DSC application form is processed at NIC-CA for issue of DSC. If all particulars are in order, a User-Id, password and the
profile for the applicant is created using the details submitted. This user-id will only be valid for 90 days (i.e., applicant has to generate key
pair request and download certificate within 90 days) failing which, user is required to submit fresh DSC application for DSC issuance.

5.

It is very important to keep the private key securely.

6.

If the private key is compromised, applicant should immediately inform NIC-CA office by phone 011- 24366176 or e-mail at
support@camail.nic.in and Login with his user-Id and password at NIC-CA website. The User has to send Request for Revocation/
Suspension/Activation form (CA2-50027.pdf)

7.

For viewing all valid DSCs and CRLs, the user can access the website (https://nicca.nic.in/) under Repository.

8.

DSCs are normally issued on FIPS-140 Level-2 compliant smart card/USB crypto-tokens, which allows only maximum ten numbers
of Incorrect attempts for entering pass phrase/ pin. It is advisable to be careful while entering the passphrase as repeated incorrect
entries may block the same. On exceeding this limit, special efforts may be required to unblock the device.

9.

It is important to note that email-id given by the applicant is functional and applicant accesses the same on regular basis as all communications
w.r.t DSC like generation, revocation, renewal, expiry details are communicated through the given email-id.

10. For any further clarification, user can write to support@camail.nic.in or visit the NIC-CA website (https://nicca.nic.in).
11. Types of Classes: Depending upon requirement of assurance level and usage of DSC as described below, the
applicant may select one of the classes.
Class-1 Certificate:
Assurance Level: Provides minimum level of assurance. Subscriber's identity is proved only with help of Distinguished Name -DN and
hence provides limited assurance of the identity.
Suggested Usage: Signing certificate primarily be used for signing personal emails and encryption certificate is to be used for encrypting
digital emails and SSL certificate is used to establish secure communications through the use of secure socket layer (SSL).
Category Issued to the Individual from Govt., PSU/Statutory Bodies, Government Registered Companies and Web Servers/Servers within
NIC domain.
Class-2 Certificate:
Assurance Level: Provides higher level of assurance confirming the details submitted in the DSC Request Form, including photograph and
documentary proof in respect of at least one of the identification details.
Suggested Usage: In addition to the 'suggested usage' mentioned in class I, the class II Signing certificate may also be used for digital
signing, code signing, authentication for VPN Client, web form signing, user authentication, Smart Card Logon, single sign-on and signing
involved in e-procurement/ e-governance applications.
Category Issued to the Individual from Govt., PSU/Statutory Bodies, Government Registered Companies and Web Servers/Servers in open
domain.
Class-3 Certificate:
Assurance Level: Provides highest level of assurances, as verification process is very stringent. Proves existence of name of organizations
such as Government Departments/Agencies, PSU/ Govt. Registered Companies and assures applicant's identity authorized to act on behalf
of the Government/PSU/Statutory/Autonomous bodies/ Government registered Companies.
Suggested Usage: In addition to the 'suggested usage' mentioned in class-1 & class-2, class-3 signing certificate may also be used for digital
signing for discharging his/her duties as per official designation. Class-3 encryption certificate may also be used for encryption requirement
as per his/her official capacity.
Category Issued to individuals from Government entities/Head of the Institutions, Statutory/Autonomous bodies, Government registered
Companies.

WBFR (Tender Rules)

63

<!-- page 72 -->

Important Government Orders

Guidelines for verification by Head of Office
y The Head of Office (HO) of DSC requestor has to verify the identity /credentials of applicants. They will be solely
responsible for authentication and validation of each subscriber/applicant within the organisation.

y They have to ensure verification process as described below, depending upon the class of certificate as applied by
the applicant.

y Types of Classes: Depending upon requirement of assurance level and usage of DSC as described
below, the applicant may select one of the classes.
Verification Process:
o

Class-1 Certificate: HO has to ensure the validity of the details given in the DSC Request Form and
verify the same.

o

Class-2 Certificate: HO has to ensure the validity of the details given in the DSC Request Form and
authenticate the same. HO has to further send it to SIO/NIC-Coordinator for forwarding to NICCA. HO has
to utilize various procedures to obtain probative evidence in respect of identity of the applicants by way of
seeking photograph and documentary evidence of one of the items under point no. 10 (Identification
details} for individual certificate.
For SSL server certificate the HO has to ensure attestation of URL for Web Servers by Domain Name
Registering Agency, location of web server.

o

Class-3 Certificate: In addition to the verification process required for the class II certificates, the
applicant's of class III certificates are required to be personally present with proof of their identity to the
NIC-CA for issuance of DSC.

y On receipt of DSC application form, SIO/ DIO/HOD/NIC-Co-ordinator is required to ensure that the application
form is signed by the HO(Head of Office)/JS/Company Secretary/Superior Officer of the applicant along with the
seal of the office.

64

WBFR (Tender Rules)

<!-- page 73 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 4109-F(Y)

Kolkata, the 17 th May, 2012

MEMORANDUM
This Department vide Notification No. 3739-F(Y) dated 03.05.2012 has made it mandatory from 01.07.2012
for all State Government Departments and their subordinate offices to publish their Tender on the centralized
e-Tender Portal [http://wbtenders.gov.in] if the Tender Value is Rs.50 lakh or more.
In order to facilitate implementation of e-Publication of Tender on the centralized e-Tender Portal by the
Departments and to render necessary help and advice to the Departments in this regard, this Department has
designated the following two officers to act as ‘Nodal Officer’:
1. Sri P. K. Pramanik, Sr. Technical Director, National Informatics Centre [NIC], West Bengal State Unit, Bidyut
Bhavan [Gr. Fl.], Salt Lake [ Contact no. 9432341691 / e-mail: <pk.pramanik@nic.in> ]
2. Sri Goutam Chatterjee, Joint Director of Treasuries & Accounts, 4, Lyons Range, Kolkata – 700001 [ contact
No. 9433123844 / e-mail: <dta@wb.gov.in> ].

Sd/- Swapan Kumar Paul.
Special Secretary to the
Government of West Bengal.

WBFR (Tender Rules)

65

<!-- page 74 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 5424-F(Y)

Kolkata, the 26th June, 2012

MEMORANDUM
In continuation of this Department’s Notification no. 3739-F(Y) dated 03.05.2012 regarding mandatory
e-tendering through centralized portal for tender value of rupees fifty lakh and above following points are
clarified:
1. For e-Tendering all tender related activities should be processed through the e-Tender portal [http://
wbtenders.gov.in] by the concerned Department/office inviting tender.
2. Prior to issuance of this Department’s Notification no. 3739-F(Y) dated 03.05.2012 e-Tender was in
vogue in some Departments for tender value of less than Rs.50 lakh. That system should be continued i.e., any
Department may go for e-Tendering for tender value less than Rs.50 lakh as per their Department’s regulation/
order.

Sd/- H. K. Dwivedi
Secretary to the
Government of West Bengal.

66

WBFR (Tender Rules)

<!-- page 75 -->

Finance Department

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 6424-F(Y)

Kolkata, the 25th July, 2012

MEMORANDUM
This Department vide Notification No. 3739-F(Y) dated 03.05.2012 has made it mandatory from 01.07.2012
for all State Government Departments and their subordinate Offices to process their Tender related activities
through the centralized e-Tender Portal [http://wbtenders.gov.in] for the Tender Value of Rs. 50 lakh and above.
This is a Mission Mode Project under National e-Government Project of the Ministry of Commerce &
Industry, Department of Commerce, Government of India. For smooth implementation of e-Tender process by
the different Departments and their subordinate offices and for monitoring the project throughout the State, the
Governor is pleased to constitute a 'State Level Core Committee' with the following members:
i)

Sri Swapan Kumar Paul, Special Secretary, Group-T, Finance Department -Chairman.

ii)

Sri P.K. Pramanik, Senior Technical Director, NIC, WB - Member.

iii) Sri Amitava Bose, Technical Director, NIC, WB - Member.
iv)

Sri Paul Varghese Mathai, Scientist - C, NIC, WB - Member.

v)

Sri Kanakendu Sinha, Executive Engineer, City Division, PWD - Member.

vi)

Sri Rajkapur Sharma, Executive Engineer, DVC Cell, Irrigation & Water Ways Department - Member.

vii) Sri Uttam Pahari, Law Officer, Law Department - Member.
viii) Sri Goutam Samanta, Joint Commissioner, Internal Audit, Finance Department - Member.
ix)

Sri Goutam Chatterjee, Joint Director of Treasuries & Accounts - Member.

The Core Committee shall follow the guidelines and advices of the Project Advisory Committee [PAC] of the
Ministry of Commerce & Industry, Department of Commerce, Government of India and shall be entrusted with
the following jobs:
a)

Arrangement for handholding training of the Government Officers related to e-Tender process and
also for the prospective bidders,

b)

Arrangement for establishing 'Helpdesk' for implementation of the e-Tender process by different
Government Offices,

c)

Development of Standard bid / tender documents including Standard Formats of Financial Bid
Evaluation and BOQ compatible with the e-Tendering.

d)

Customization of the State's e-Tender Portal [http://wbtenders.gov.in] keeping in view the overall
requirements of all the Departments/offices of the State Government.

Sd/- H. K. Dwivedi
Secretary to the
Government of West Bengal.
WBFR (Tender Rules)

67

<!-- page 76 -->

Important Government Orders

GOVERNMENT OF WEST BENGAL
Finance Department
Audit Branch
No. 9701-F(Y)

Kolkata, 30th November, 2012

MEMORANDUM
E-Tender for Procurement of goods and services for the State Government has been made mandatory for
goods and services valued at Rs.50 lakh and above vide Finance Department Notification no. 5400-F(Y)
dt.25.6.2012.
E-Tender is a Mission Mode Project [MMP] approved by the Ministry of Commerce, Government of India.
The Server for e-Tender Portal has been provided by the National Data Centre, New Delhi with all its application.
Six manpower support has been provided by the Government of India for this purpose. As per guideline of the
MMP and in order to implement the e-tender procedure a ‘State Level Core Committee’ [SLCC] was constituted
to recommend to the Government the steps to be taken to switch over to the new method of purchase through
e-tender.
The core committee has made some specific recommendation to facilitate e-Tender by the State Government
Offices. It was decided that the infrastructure of the Public Works Department and Irrigation & Waterways
Department shall be used for facilitation of e-Tender by the State Government Offices. At present for obtaining
‘Digital Signature Certificate’ from NIC the Application Form is to be submitted at their New Delhi Office. It
takes a lot of time to obtain the Digital Signature Certificate. It has been decided to establish a Centre for Digital
Signature Registering Authority of NIC in West Bengal, at the ground floor of the Jalasampad Bhavan, Salt Lake
at the earliest.
After considering the recommendations of the State Level Core Committee on e-Tender the Governor has
been pleased to take the following decisions in the interest of facilitation of switchover from the existing
procedure of tender to e-tender for procurement of the State Government:
1. There shall be two Centralised Training Centre one at Kolkata and the other at Salt Lake, one at the Training
Hall of the Public Works Department at Pranjali, Hastings, Kolkata and the other at the Training Hall of the
Irrigation & Waterways Department at Jalasampad Bhavan, Salt Lake. The Officials of the State Government
including the State Government Undertakings and Autonomous Bodies and the prospective Bidders can avail
such Training Programme. All the trainings for orientation of e-tender will be organised centrally and imparted
in the two training locations mentioned above. The names of the contact persons for availing such training is
given in Annexure-I.
2.

There shall be seven (7) Helpdesks at following places in West Bengal:
Sl
no.

Helpdesk in the district

I

Kolkata at Pranjali, Hastings

68

May be availed by the offices in
Kolkata and Districts
(i)
(ii)
(iii)

Kolkata (except Salt Lake)
South 24-Parganas
Howrah
WBFR (Tender Rules)

<!-- page 77 -->

Finance Department
Sl
no.

Helpdesk in the district

May be availed by the offices in
Kolkata and Districts

II

Salt Lake at Jalasampad Bhavan

(i)
(ii)

Salt Lake
North 24-Paganas

III

Medinipore Town

(i)
(ii)
(iii)

Purba Medinipore
Paschim Medinipore
Bankura

IV

Burdwan Town

(i)
(ii)
(iii)

Hoogly
Burdwan
Purulia

V

Berhampore Town

(i)
(ii)
(iii)

Nadia
Murshidabad
Birbhum

VI

Malda Town

(i)
(ii)
(iii)

Malda
Uttar Dinajpur
Dakshin Dinajpur

VII

Siliguri Town

(i)
(ii)
(iii)
(iv)

Darjeeling
Siliguri
Jalpaiguri
Cooch Behar

The Support Personal at the Helpdesks shall provide necessary assistance to the Officials of the State Government
including the State Government Undertakings and Autonomous Bodies and also to the prospective Bidders in
smooth implementation of the e-Tender formalities. The detail list along with names of contact persons at such
Helpdesks is given at Annexure-I.
3.

Sale price of bid documents is hereby dispensed with for e-tender / e-bid.

4. In case of re-tender no bid security / EMD is required for the bidders who responded to the first tender
but did not get back the EMD deposited with the first bid.
This order shall take immediate effect.

Sd/-H. K. Dwivedi
Secretary to the
Government of West Bengal.

WBFR (Tender Rules)

69

<!-- page 78 -->

Important Government Orders
Enclosure to Memo No. 9701-F(Y) Dated 30th November, 2012
Annexure-I
A.

The names of the contact persons for Training on e-Tender:

Sl.
No.

Name & Designation

Contact No.

e-mail

1

Sri Amitava Bose,
Technical Director, NIC

09830610378

amitava.bose@nic.in

2

Sri Paul Varghese Mathai,
Scientist – C, NIC.

09433230135

paul.mathai@nic.in

B.

The detail list along with names of contact persons at Helpdesks for implementation of e-Tender:

Sl.
No.

Helpdesk in the district

Contact No.

e-mail

I

Kolkata at Pranjali, Hastings
O/o. Executive Engineer,
City Division, PWD

033-2223-6236

ee1ctdpwd@wb.gov.in

II

Salt Lake at Jalasampad
Bhavan, O/o. Executive
Engineer, DVC Cell, 7th Floor,
Irrigation & Water Ways
Department

033-2334-6098

irrigationhelpdesk
@gmail.com

III

Medinipore Town
O/o. Executive Engineer,
Midnapore Highway Division-II

03222-275672

hripwdmed@gmail.com

IV

Burdwan Town
O/o. Executive Engineer-I,
Burdwan Division, PWD

0342-2662497

hripwd.burdwan.helpdesk
@gmail.com

V

Berhampore Town
O/o. Superintendent Engineer,
SHC-III, PWD (Roads).

03482-250627

hripwdmsd@gmail.com

VI

Malda Town
O/o. Executive Engineer,
Malda Division, PWD.

03512-252497

hripwdmld@gmail.com

VII

Siliguri Town
O/o. Executive Engineer-I,
PWD, NBCD.

0353-2431529

hripwddjg@gmail.com

70

irrigation.nic@gmail.com

WBFR (Tender Rules)

<!-- page 79 -->

Finance Department

WORKS TENDER AND
CONTRACT

Works Tender and Contract

71

<!-- page 80 -->

Important Government Orders

72

Works Tender and Contract
