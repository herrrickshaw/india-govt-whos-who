---
doc_id: "5d7f6dffcdd0a82b"
source_url: "https://www.wbhidcoltd.com/upload_file/875e99174decf358b8b620e21d0b9e69.pdf"
ministry: "West Bengal Housing Infrastructure Development Corporation Limited, (WBHIDCO), West Bengal"
title: "NOTIFICATION"
date: ""
pages: 1
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "75034713753b00c4"
---

<!-- page 1 -->

:
*
No. 552/HIDCO/ADMN-3117/2016 (Pt) Date : 08/03/2022
NOTIFICATION
Employees working in WBHIDCO in different capacities and having diploma in
Civil/Electrical Engineering from a recognized Institution may apply for the post of
Sub-Assistant-Engineer (Civil)/(Electrical) in WBHIDCO with necessary Bio-Data giving all the
details alongwith supporting documents. Application should reach the undersigned by
t
21-03-2022.
This has the approval of the Competent Authority.
Joint ene. (Admin)
No. 552/1(4)/HIDCO/ADMN-3117/2016 (Pt) Date : 08/03/2022
Copy forwarded for information and necessary action to:
2 Engineer-in- Chief, WBHIDCO.
2. Chief Engineer, WBHIDCO.
3. Addl. Chief Engineer, WBHIDCO.
4. Sr. PS to Managing Director, WBHIDCO. kee টি
Joint Managing Director (Admin)
Re ১০2১১: ৭ ১১২
WEST BENGAL HOUSING INFRASTRUCTURE DEVELOPMENT CORPORATION LTD.
(A Govt. of West Bengal Undertaking)
“HIDCO BHABAN”, Premises No. : 35 - 1111, Biswa Bangla Sarani, 3rd Rotary, New Town, Kolkata-700156
Telephone : (033) 2324-6037/6038, Fax No. : (033) 2324-4833/3016/6009, e-mail : wbhidcoltd@gmail.com / info@wbhidco.in
Website : www.wbhidcoltd.com CIN £ U70101WB1999SGC089276
