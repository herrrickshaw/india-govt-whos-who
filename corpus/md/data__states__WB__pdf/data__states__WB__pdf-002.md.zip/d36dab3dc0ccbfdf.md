---
doc_id: "d36dab3dc0ccbfdf"
source_url: "https://www.rbu.ac.in/upload/afbd4e13be1aa3899391c4b06dea8908.pdf"
ministry: "Rabindra Bharati University, West Bengal"
title: "Notification regarding DTL and PGDMP Examinations,2020  December 31 2020"
date: ""
pages: 2
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "4385a0cab3b7ecdb"
---

<!-- page 1 -->

ene
িঃ
৬ 9
RABINDRA BHARATI UNIVERSITY
KOLKATA
EXAMINATION DEPARTMENT.
Notification regarding DTL and PGDMP Examinations, 2020

Memo No. : Exam. / 7010 Date: 31.12.2020

This is for information of all concerned that Diploma in Tagore Literature (DTL)
Examinations, 2020 and Post Graduate Diploma in Manuscriptology and Palaeography (PGDMP)
Examinations, 2020 for eligible Students under the Faculty of Arts of the University will be conducted in
the blended mode (offline and online) as per resolutions adopted by the Executive Council in its emergency
meetings held on 15.12.2020 and Examination Task Force in its meetings held on 23.12.2020, on the basis of
the UGC Guidelines on Examinations and Academic Calendar in view of COVID-I9 Pandemic [vide D.O. |
NO. F1-1/2020 (Secy), dated 29th April, 2020 and vide D.O. NO. F1-1/2020 (Secy), dated 6th July, 2020],
the verdict of Hon’ble Supreme Court dated August 28, 2020 issued in this matter. University shall strictly
abide by the Guidelines issued by the University Grants Commission (UGC) regarding modalities of
examinations and spirit in the best interest of students maintaining the sanctity of examination.

Detailed modalities of Diploma in Tagore Literature (DTL) Examinations, 2020 and Post

Graduate Diploma in Manuscriptology and Palaeography (PGDMP) Examinations, 2020 for eligible Students
under the Faculty of Arts of the University are mentioned below:

1. Diploma in Tagore Literature (DTL) Examinations, 2020 and Post Graduate Diploma in
Manuscriptology and Palaeography (PGDMP) Examinations, 2020 for eligible Students under the
Faculty of Arts of the University will be conducted in blended mode (online + offline).

2. All such examinees under the Faculty of Arts of the University would be required to undergo the
online Examination Form fill up process through University web portal. In online Examination Form
fill up process, student would mention his/her University Registration Number, SUIN, Exam Roll No,
current Email ID and mobile phone number etc.

Detailed schedule of such process will be announced in due course of time through University website.
After completion of Examination Form fill up process, student would download the Admit Card from
the Examination Portal of the University before appearing in the Examination.

3. Examination Fees and Admission Fees (if any) will be collected during distribution of Mark Sheet.

4. Candidates (‘Persons with Benchmark Disabilities’), who want to write Examination with Scribe may
apply (as per Format attached) to the Joint Registrar (Exam.) using University designated portal at the
time of online Examination Form fill up process with all necessary documents of the candidate and
the Scribe.

Page 1 of 2

<!-- page 2 -->

5. Concerned Department will conduct the Continuous Internal Assessment (CIA) of theoretical and

practical examinations (wherever applicable) of Post Graduate Diploma in Manuscriptology and
Palaeography (PGDMP) Examinations, 2020 for eligible Students as per UGC guidelines preferably
by 15.01.2021.
If a candidate having supplementary in any Paper/s, then he/she have to attend only End-Term
Examinations for that supplementary paper/s. He/she don’t have to sit for Continuous Internal
Assessment (CIA) for any supplementary paper/s. CIA marks would be carried forward from earlier
examination of that paper/s.

6. As per latest guidelines published by UGC on July 06, 2020, the period of lockdown shall be treated
as ‘deemed to be attended’ by all the students.

7. Theoretical examinations would be conducted in blended mode (online + offline).

8. For DTL Examination, duration of examination will be 3 hours for full marks of 100 [where the

number of questions to be attempted will be 5 out of 10 questions]. Each question may be sub-divided,
if required. (Marks =20x5 = 100).
For PGDMP Examination, duration of examination will also be 3 hours for full marks of 80 [where
the number of questions to be attempted will be 4 out of 8 questions]. Each question may be sub-
divided, if required. (Marks =20x4 = 80). Practical Examination will be conducted through written
examination with practical approach.

9. Question Papers will be made available on the University’s Examination Portal and the students will
have to download these question papers at the scheduled time (i.e. 30 min. before the commencement
of the Examination) on the date of examination, write their answers on standard quality A4 size paper
within stipulated words as desired by the concerned Department, bearing the SUIN, Registration
Number, Examination Roll Number, Name of the Paper in each page with sequential numbering of
the pages, scan or take images of these scripts, save these images in Pdf/JPEG/JPG format and upload
these to the university’s examination portal immediately after completion of the said examination
within the stipulated time.

10. Examination Department would announce the Provisional Eligibility List of the candidates for the
said examinations, Schedule for Examination Form fill up and detailed schedule of Examinations in
due course of time.

11. If a candidate fails to fill up his/her examination form in due time, his/her result will not be published.

12. In case, a student is unable to appear in the above-mentioned examinations conducted by the
University for whatsoever the reason(s) may be, he/she will be given opportunity to appear in special
examinations for such Paper(s), which shall be conducted by the university as and when feasible, so
that the student is not put to any inconvenience/ disadvantage.

This provision shall be applicable only for the current academic session 2019-20 as a one-time
measure.
2” a
a
Joint Registrar (Exam
Page 2 of 2
