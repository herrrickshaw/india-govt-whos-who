---
doc_id: "2fdef0eecf532e9e"
source_url: "https://gcect.ac.in/download/Tenders/Gcect-Tender-NOTICE-01-03-2023.pdf"
ministry: "Government College of Engineering & Ceramic Technology (GCE&CT), Kolkata, West Bengal"
title: "Tender 73"
date: ""
pages: 1
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "678b16f6e8f579a9"
---

<!-- page 1 -->

ia
sina Government College of Engineering & Ceramic Technology
(3১ An Autonomous Institute under M.A.K.A.U.T
উজ 73, Abinash Chandra Banerjee Lane, Kolkata-700010
URL: www.gcect.ac.in E-mail: gcectwb@gmail.com
Memo No. GCECT/ 202 /1-P(4)/2022-23 Date: 01.03.2023
Due date: 17.03.2023
Sealed and superscripted quotations for Sign Board for College Main Building Entrance are invited by the
undersigned for.........+
1 Sign Board for College Main Building Entrance ( Length 01:85
7 14 ft x Breath 3ft) with SCP sheet and Iron Structure .
Interested parties are requested to visit the institute to ascertain the scope of the work in any working day to
submit their lowest quotation to the undersigned by above mentioned date in a sealed cover.
K. ০৯,০০০ 127
Principal
Govt. college of Engg. & Ceramic Technology
Govt. of West Bengal
