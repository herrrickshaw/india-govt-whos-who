---
doc_id: "cade63627cead3ec"
source_url: "https://finance.wb.gov.in/writereaddata/WB%20Contingency%20Fund%20(Amendment)%20Act,%202022.pdf"
ministry: "Finance Department, West Bengal"
title: "Download   (81.08 KB)"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "63ef0c83ae7665c2"
---

<!-- page 1 -->

Registered No. WB/SC-247

No. WB(Part-III)/2022/SAR-5

The
Gazette

Kolkata
Extraordinary
Published by Authority
CHAITRA 10]

THURSDAY, MARCH 31, 2022

[SAKA 1944

PART III—Acts of the West Bengal Legislature.
GOVERNMENT OF WEST BENGAL
LAW DEPARTMENT
Legislative
NOTIFICATION
No. 318-L.—31st March, 2022.—The following Act of the West Bengal Legislature, having been assented to by
the Governor, is hereby published for general information:—

West Bengal Act V of 2022
THE CONTINGENCY FUND OF WEST BENGAL
(AMENDMENT) ACT, 2022.
[Passed by the West Bengal Legislature.]
[Assent of the Governor was first published in the Kolkata Gazette,
Extraordinary, of the 31st March, 2022.]

An Act to amend the Contingency Fund of West Bengal Act, 1950.
WHEREAS it is expedient to amend the Contingency Fund of West Bengal Act, 1950,
for the purpose and in the manner hereinafter appearing;
It is hereby enacted in the Seventy-third Year of the Republic of India, by the
Legislature of West Bengal, as follows:—
Short title and
commencement.

1. (1) This Act may be called the Contingency Fund of West Bengal (Amendment)
Act, 2022.

West Ben. Act
XL of 1950.

<!-- page 2 -->

2

THE KOLKATA GAZETTE, EXTRAORDINARY, MARCH 31, 27
2022

[PART III

The Contingency Fund of West Bengal
(Amendment) Act, 2022.
(Section 2.)
(2) It shall come into force on the 1st day of April, 2022.
Amendment of
section 2 of West
Ben. Act XL of
1950.

2. In section 2 of the Contingency Fund of West Bengal Act, 1950, for the words
“a sum of twenty crores of rupees”, the words “a sum of two hundred crores of rupees”
shall be substituted.
——————

By order of the Governor,
PARTHA SARATHI SEN,
Secy. to the Govt. of West Bengal,
Law Department.

Published by Law Department, Government of West Bengal and
Printed at Saraswaty Press Ltd.(Government of West Bengal Enterprise), Kolkata 700 056.
