---
doc_id: "8a6befbbcc4eddb8"
source_url: "https://www.bankurauniv.ac.in/uploads/tempimagepdflink/1688194615.pdf"
ministry: "Bankura University, West Bengal"
title: "Notification regarding cancellation of tender notice vide no. RO/BKU/455/2023 dated 26.06.2023"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5f64f022a6b91875"
---

<!-- page 1 -->

BANKURA UNIVERSITY
(West Bengal Act XIX of 2013- Bankura University Act, 2013)
Main Campus, Bankura Block-II, P.O.: Purandarpur,
Dist.: Bankura, Pin- 722155, West Bengal

Office of the Registrar
.............................................................................................................................................................................................
No: RO/BKU/ 455/2023
Date: 30 /06/2023

Notice
As directed by the competent authority, tender notice vide no. RO/BKU/447/2023 dated 26.06.2023 is
hereby cancelled due to unavoidable circumstances.
Sd/Dr. Saurabh Dutta
Registrar (Addl. Charge)
Bankura University
Memo No. RO/BKU/455/1(5)/2023

Date: 30/06/2023

Copy Forwarded to:
1. The Finance Officer, Bankura University.
2. System Administrator, Bankura University with a request to upload the notice in the university website
3. Central Store, Bankura University
4. Office Notice Board.
5. Guard file
Sd/Dr. Saurabh Dutta
Registrar (Addl. Charge)
Bankura University
