---
doc_id: "cd8ffc8dbb8b26b9"
source_url: "https://wberc.gov.in/sites/default/files/The%20Appeal%20to%20the%20Appellate%20Authority%20Rules%202004.pdf"
ministry: "West Bengal Electricity Regulatory Commission (WBERC), West Bengal"
title: "View More"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c6a19c92b3131520"
---

<!-- page 1 -->

[Contains amendment vide Notification No. GSR 537(E) dated 7th September, 2006)]
GOVERNMENT OF INDIA
MINISTRY OF POWER
Notification
New Delhi, the 16th April, 2004
G.S.R. 265(E).- In exercise of the powers conferred by clause (u) of sub-section (2) of section 176 of the
Electricity Act, 2003 (36 of 2003) the Central Government hereby makes the following rules prescribing
the appellate authority for preferring appeal against the orders of the assessing officer, namely:1.

Short title and commencement – (1) These rules may be called Appeal to the Appellate Authority
Rules, 2004.
(2) They shall come into force on the date of their publication in the Official Gazette.

2.

Definitions.– In these rules, unless the context otherwise requires,(a) “Act” means the Electricity Act, 2003 ;
(b) “Section ” means a section of the Act.
(2) Words and expression used and not defined in these rules but defined in the Act, 2003 shall
have the meanings respectively assigned to them in Act.

3.

Appellate Authority - For the purpose of appeal under section 127, the State Government may, by
notification in the Official Gazette, constitute an Appellate Authority consisting of one or more
prsons such that one of the persons shall have knowledge of matters related to assessment of
electricity charges and none of them shall be directly related to the affairs of the territorial
jurisdiction of the licensee or supplier of the electricity”.
Sd/(Ajay Shankar)
Additional Secretary to the Government of India
F.No. 23/63/2003-R&R

To
The Manager,
Government of India Press,
Mayapuri, New Delhi

180
