---
doc_id: "b72a0c6f4f9cdfdc"
source_url: "https://cdn.s3waas.gov.in/s343ec517d68b6edd3015b3edc9a11367b/uploads/2026/09/17906023365671.pdf"
ministry: "Purulia"
title: "NIT20tendernotice (9 MB)"
date: ""
pages: 20
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "c7d7ff595e4f1d2d"
---

<!-- page 1 -->

]
Government of West Bengal
Directorate of Forests
Office of the Divisional Forest Officer
Kangsabati North Division
Raghabpur More, P.O. & Dist. — Purulia, Pin - 723101
(Ph.)-03252-222231 ,(Fax)-227468 & E-Mail: dfokn-wb@nic.in
LLL STE RT TTT TM EE ET TT aa
Memo No: 2555/2-456/) Dated Purulia, the, 21/09/2026.
Notice Inviting e-Tender: - NIT20/WBFOR/DFOKND/FP/26-27.
E-TENDER ENAGAEMMENT OF LABOUR & VECHILE FOR PROTECTION OF FORESTS AT RANGE JURIDICTION OF

PUNCHA RANGE, KANGSABATI NORTH DIVISION, PURULIA DURING FINANCIAL YEAR 2026-27.

The Divisional Forest Officer, Kangsabati North Division, Purulia, West Bengal, on behalf of the Governor, West Bengal
invites e-Tenders for the following work(s) from the eligible Contractors as detailed in the table below. [Collection (downloading) and
Submission (uploading) of e-Tender can be made online through the website https://wbtenders.gov.in only]. Terms and Conditions of
this Tender Notice is duly followed the Memorandum of Finance Dept. vide No. 5696 F(Y) dated 01/10/2019.

SCHEDULE OF [1৩১ WITH LOCATION DETAILS
Cost of
rain ta Earnest the
F = Money | Security | tender লী
Details of Work Excluding রী Period of
NIT No. GST (in Rs.) Money | docum completion
in Rs. 2% ents
(in Rs.) in Rs.
Engagement of Labour &
Hiring Vehicle for As per
protection of forests at I. 10% of
areca Range Jurisdiction of Rs. 156250/- | Rs. 3305/- accepted | 1000.00 Loe
Lat Puncha Range, offer rate. the Authority.
Kangsabati North 5
Division, Purulia
SCHEDULE OF DATES
[Ste [Patient ise
[71 | Date of uploading N.LT. Documents—Online (Publishing Date) 23/09/2026 from 11.30 a.m.
[2 | Documents download start date (Online) 23/09/2026 from 11.30 a.m.
Documents download end date (Online)
[747 Bid submission start date (Online) 23/09/2026 from 11.30 a.m.
[5s | Bid submission closing date (Online) 03/10/2026 at 05.00 pm
| 6 | Bid opening date for Technical Proposal (Online) 05/10/2026 at 05.00 pm
Date of uploading technically qualified bidders (Online) To be notified in due course
ঢুররাহজানদূজা ; To be notified during uploading of Technical
za Date of opening Financial Bids (Online) লাক
Date of uploading of list of bidders along with final rate, after negotiation Tob ified in ৫ a
with all bidders if necessary (Offline) 9751091৩118 due course
Last date & time of submission of bids online is: 03/10/2026 at 05.00 pm
Note: 1). In case of any unscheduled holiday or on days of National Holidays or strike or natural calamity on the aforesaid dates, the next working day
will be treated as scheduled / prescribed date for the same purpose.
2). The Tender Inviting Authority may change the venue of opening the Technical or Financial Bids in case of exigent circumstances like
breakdown of communications link or conditions of force majeure.
3). The Tender Inviting Authority reserves the right to defer the date of opening of either Technical or Financial Proposal or both, if required.
Page 1of 20

<!-- page 2 -->

Terms & conditions Ca
ANALYSIS OF THE ESTIMATES & PRE-REQUISITE SPECIAL CONDITIONS

1, Model estimates for Maintenance Work 2026-27 FY been provided above. The estimated cost is inclusive of all maintainance
work. Successful bidder/s should carry out the works by deploying labours from local JFMCs only by paying minimum wage
for the time in vogue. As, each of the activity requires specialized skill and experience, 10110 members who are conversant in
carrying out such types of activities should be given preference while deploying labour for such types of jobs. While payment is
required to be made by the contractor concerned, decision taken by the concerned Range Officer on technical ground shall be final
and binding with respect to carrying any particular activities mentioned in the model estimates.

2. The estimate is indicative in nature. Thus, it might be so that some of the items mentioned in the estimates do not require to be
implemented in the field and some of the items need to be implemented more than once, repeated or enhanced as per field
requirements especially for Thus, the Intending bidders need to quote the rates accordingly and will have to follow the instructions
of Forest Officials only who will have the liberty to change the inner items mentioned in the estimates, without changing the rate
or the amount of that particular item. Intending bidder/s is (are) expected to have that flexibility.

3. The labour rates etc. given in the estimates are as per existing Government Rules which may be revised as per orders in vogue.

4. Rate Quoted below 20% shall be subject to rate analysis which shall require to be provided based on technical grounds to be
ascertained by the Tender Committee constituted for the purpose. Rate analysis which is not technically viable shall not be
acceptedat this end and the candidature of the contractor concerned shall liable to be cancelled at once. No rates quoted above
the estimated rate will be entertained.

5. Credentials: The Applicant in the same name and style as prime contractor should have successfully completed at least one
contract of similar type of work at least 40% value of the proposed contract within the last 5 Years from date of
publication of this NIT or of 2 (Two) similar nature of Work, each of minimum value of 30% of the estimated amount put
to tender during last 5 Years prior to issuance of this NIT. or intending tenderers should produce credential of one single
running works of similar nature which has been completed to the extent of 80% or more and value of which is not less than the
desired value at (i) above. In case of running works, only those tenderers who will submit the certificate of satisfactory running
work from the concerned executive engineer, or equivalent competent authority will be eligible for the tender. In the required
certificate it should be clearly stated that the works is in progress satisfactorily and also that no penal action has been initiated
against the execute agency, i.e.,the tenderer.

6. From the above analysis, it follows logically that R.A bills shall be admissible in this regard provide the concerned ROs
Completion Certificate.

vA Issuance of work order to the L1 Bidders is subject to administrative approval and availability of fund. Similarly, payments
of bills are also subject to availability of funds; the undersigned will not be liable in any such case of non-payment or delayed
payment or cancellation of the tender or any other circumstances.

8. Bidders cannot claim payment of Contingency amount in any way, as it is within the cost of tender publication etc.

9. ‘Whereas it has been observed that in most of the cases tender are not being finalized in 1* call and even in 2™ call to due to
non availability of qualified tenderes on account of the extent credential policy as laid down in Rule 226(1) of PWD Code,
Volume /Iwhich was amended vide this office Notification no.137/1-A/PW/0/10C-02/14 dated 24.04.2014 and published in
Kolkata Gazette dated 28.04.2024 resulting in unnecessary delay in implementation of the project/ Scheme.

10. Whereas it has been observed that in most of the cases bids are Tie and therefore follow this order no.2320-F(Y) dated
07.06.2022 by Finance Department Audit Branch Group T, (File No.293799).

11. Intending Bidder should read carefully read the Cl No 41 of GCC regarding the suspension and debarment policy before
participating the tender.

12. Payment shall be made to the successful bidders only for those items which he/she has carried out at field on pro rata basis as per
the rate offered by the L1 & as per the instructions of the undersigned or his authorized representatives. Each item of the estimates
has a definite time line, beyond which the item is very difficult to be implemented in the field. Thus, any item, which is not
possible to be implemented in the field within due time, can only be implemented after having due permission in this regard from
the appropriate authority. Successful bidders are required to prepare bill for making payment accordingly. Running bill payment
may also be allowed subject to recommendation of the concerned field Officers; Range Officers.

13. Since the items are very much technical and needs to be implemented properly as per correct Silvicultural technique,
understanding of all the items is a prerequisite for the Bidders. In case of any confusion in later part regarding implementation of
any item the decision of the undersigned or his authorized representative shall be final & binding.

14. The undersigned will always reserve the rights to cancel tender/ contract at any moment; even after issuance of work order,
without assigning any reason whatsoever.

15. The plant inputs like chemical fertilizers, organic manures, insecticides, hormones etc. of proper brand approved by the
undersigned only, should be applied as per amount prescribed in the Model Estimate.

16. Experience in Forestry Work is desirable.

17. The payment will be processed as per guideline of State Development Project.

Page 2 of 20

<!-- page 3 -->

INSTRUCTION TO BIDDERS (ITB)
Section- A
1, General Guidance for e-Tendering:
1,1 Instructions / Guidelines for e-Tenderers for electronic submission of the e-Tenders online have been shown in Web site
https://wbtenders.gov.in
1.2 Registration of Contractors .
Any contractor willing to take part in the process of e-Tendering will have to be enrolled and registered with the Government e-
Procurement System.
1.3 Digital Signature Certificate (DSC) .
Each contractor is required to obtain a Class-II or Class-II Digital Signature Certificate (DSC) for submission of e-Tenders.
1.4 Collection of e-Tender Documents ..
The contractor can search and download NIT and e-Tender documents electronically from computer once he logs on to the website
mentioned in Clause 1.1 using the Digital Signature Certificate. This is the only mode of collection of e-Tender documents.
1.5 Participation in more than one work
A prospective bidder shall be allowed to participate in the job either in the capacity of individual or as a partner of a firm or registered
company. If found to have applied severally in a single job, all his applications will be rejected for that job.
2. Submission of e-Tenders:
2.1 General process of submission:
Tenders are to be submitted online through the website stated in Clause 1.1 in two folders, at a time for each work, one is Technical
Proposal and the other is Financial Proposal, before the prescribed date and time mentioned in the list attached. Using the Digital
Signature Certificate (DSC), the documents are to be uploaded, virus scanned and digitally signed. Tenderers should specially take
note of all the addendum/corrigendum related to the e-Tender and upload the latest documents as part of the e-Tender.
2.2 Technical Proposal:
The Technical Proposal should contain scanned copies and/or a declaration in standardized formats of the following in two covers
(folders).
Technical File (S Cover) —
i. NOTICE INVITING E-TENDER (NIT) (to be submitted in “NIT” Folder).
ii. Section B (Form I, Form II, Form III and AFFIDAVIT — Y) (to be submitted in “FORMS” Folder).
iii. Earnest Money Deposit (EMD) by the Tenderer as mentioned in the NIT document the 2% Earnest Money of the tender amount
should be NEFT/RTGS through ICICI Bank payment gateway in favour of “The Divisional Forest Officer, Kangsabati North
Division” payable at Purulia (to be submitted in “EMD” folder) The Earnest Money will not be exempted in any ground.
iv. Instructions to Bidders. (to be submitted in “ITB” Folder)
v. General Terms & Conditions of Contract. (to be submitted in “GT AND CC” Folder)
vi. Technical Specification. (to be submitted in “TS” Folder)
vii. Drawing if Any to (“DRAWING” Folder)
viii) Addenda/Corrigendum, if published: Contractors are to keep track of all the Addendum/Corrigendum issued with a
particular e-Tender and upload all the above, digitally signed, along with the NIT. Tenders submitted without the
Addendum/Corrigendum will be treated as invalid and liable to be rejected,
Page 3 of 20

<!-- page 4 -->

4৬ ১1১ Document (Non-Statutory Cover)
[17110] (For details see Clause 3 of ITB & relevant clauses of NIT)
০০
| | Earnest Money Deposit.
P.T. deposit receipt Challan
A. | CERTIFICATES CERTIFICATES Valid GST Registration Certificate &Latest GST Return of the last
month.
[ 4 | LT.R. Acknowledgement Receipt for last 3 (three) years
| 5 | LT. PAN Card, Voter Card, Aadhaar Card.
ESI & EPF Registration Certificate including updated challan (If
EPF and ESI are not required by law, declaration with proper
justification is to be submitted on letter head of the Company
/Firm prop Stamped.
| 1 | Proprietorship Firm - Trade License.
2 Partnership Firm - Registered Partnership Deed,
Registered Power Attorney, Trade license.
COMP: COMPANY DETAILS
DETAILS 3 | Pvt. Ltd. Company - Registration Certificate under
Company's Act, MOA & AOA, Registered Power
of Attorney, Trade license.
Registered Un-employed Engineers and Labour Co-operative
Societies Limited.
1 _ | Experience Profile- List of completed Projects works regarding
Similar Nature of works.
Bidder’s Annual Turnover should be at least 100% of estimated
C. | CREDENTIAL CREDENTIAL project of this NIeT in the last 3 ding years.
Completion Certificate, Payment Certificate from the concerned
authority (Mandatory)
PLANT&MACHINER | Authenticated copy of invoice, challan, and waybill (Machinery)
EQUIPME IES (OPTIONAL)
LABORATORY Authenticated copy of invoice, challan, and waybill (Labo:
(OPTIONAL) Opy ice, challan, and waybill (Laboratory)
TURN OVER Authenticated copy of the Income Tax RETURNS
FINANCIAL 177 cq =
(INFO) PAYMENT Only Payment Certificate of work issued by the Concerned
CERTIFICATE Supervisor and not the TDS certificate
STRUCTURE & 1 | Details of Structure and Organization ITB Section B Form III.
DECLARATION | ORGANISATION
‘An affidavit made that no adverse report against the bidder
An affidavit mentioning the name of the technical staff as described
TECHNICAL STAFF [১] 10012856309.
র Profit Certificate Bidder’s profit should have made after last taxes for each of these
G. | Audit ৮:5৮, last 3 financial years.
Balance Sheet |? | Profit and loss balance sheet for last 3 financial years.
দিল
2.3. Financial Proposal
i) The financial proposal should contain the Bill of Quantities (B,O.Q.) in one cover (folder). The contractor is to quote the rate in the
space marked for quoting rate in the B.O.Q. - .
ii) Only downloaded copy of the B.O.Q. are to be uploaded quoting the rate, virus scanned & digitally signed by the contractor.
Page 4 of 20
~

<!-- page 5 -->

নি
ং 4 3. Eligibility Criteria for participation in e-Tender:

ও) The intending bidders should have proper license for engaging labourers on contract.

(©) All categories of prospective Tenderers shall have to submit valid and upto date Professional Tax receipt Chillan, GST
registration certificate and latest GST return, Income Tax return Acknowledgement receipt for last 3 (three) years, PAN card
issued by Income Tax Department, Voter ID card and Trade license in respect of the prospective Tenderer. In addition to the
above, any contractor who has executed any type of e-Tender works in Directorate of Forests, Govt. Of West Bengal, should
submit previous credentials for his past performance, completion certificate from respective employer, the completion
certificate and credentials should be signed by the officer not below the rank of Deputy Conservator of Forest, any other
certificate signed by other officials will not be entertained (Non Statutory Documents). All categories of intending Tenderers
shall have satisfactorily completed as a prime agency having taken up similar work during the last 5 (five) years prior to the date
of issue of this Tender Notice as per the PWD, West Bengal G.O. No. 04-A/PW/O/10C-02/14, dt. 18.03.2015. Credentials
within 5(Five) years shall be preferred.

(©) Where an individual person holds a Certificate in his own name duly issued to him against the company or the firm of which he
happens to be a director or partner, such individual person shall, while submitting any e-Tender for and on behalf of such
company or firm, invariably submit a copy of registered power of attorney showing clear authorization in his favour, by the rest
of the directors of such company or the partners of such firm, to submit such e-Tender. The Power of Attorney shall have to be
registered in accordance with the provisions of the Registration Act, 1908. (Non-statutory Documents).

(@) Neither prospective Tenderer nor any of the constituent partners had been debarred to participate in any e-Tender by Forest
Dept., P.W.D., P.W.(R)D & P.W.(C.B.) D, Housing Department, W.B. or C.P.W.D. or M.E.S or Railways; during the last 5
(five) years prior to the date of this NIT. Such debarring will be considered as disqualification towards eligibility. (A declaration
in this respect must be furnished by the prospective bidders as per prescribed format). [Non-statutory Documents]

(©) The partnership firm shall furnish the Registered Partnership Deed and the Company shall furnish the Memorandum of
Association (MOA) and Article of Association (AOA.) [Non-statutory Documents]

9. Registered Un-employed Engineers’ Co-operative Societies / Labour Co- operative Societies are required to furnish the
following documents: - [Non-statutory Documents]

i) Current "No Objection Certificate" from the Assistant Registrar of Co-operative Societies.

ii) | Supporting documents showing area of operation.

iii) _Bye-laws duly approved by the Assistant Registrar of Co-operative Societies.

iv) Name with address and signature (in original) of the present Board of Directors of the Co-operative Society

v) Copies of-Minutes of last Annual General Meeting and Audit Report of the Co-operative Society with the
evidence of submission of the same to the concerned Authorities, duly attested.

(g) The prospective Tenderers or any of their constituent partner shall neither have abandoned any work nor any of their contract
have been rescinded during the last 5 (five) years. Such abandonment or rescission will be considered as disqualification towards

(h) A prospective Tenderer shall be allowed to participate in the job either in the capacity of individual or as a partner of a firm. If
the prospective Tenderer is found to have applied severally in a single job, all his applications will be rejected for that job.

0). No conditional / Incomplete e-Tender will be accepted under any circumstances.

@). The Financial Eligibility:

a. The bidder should have a minimum average annual turnover of least 100% of estimated project cost of the e-Tender in
the last three 3 preceding years (the turnover of the lead member will be considered in case of joint venture).

b. For Ist Call - The bidder should have successfully completed at least one similar type of work / Similar nature of
work & construction civil Works etc. during last five (5) years for a single similar nature contract of value not less than
40% or two contacts of value not less than 30% or a single running work of similar nature which has been
completed to the extent of 80% or more and value of which is not less than the desired value at (i) above.

For 2™ Call - The bidder should have successfully completed at least one similar type of work work / Similar
nature of work & construction civil Works etc. during last five (5) years for a single similar nature contract of value not
1555 than 30% or two contacts of value not less than 25% or a single running work of similar nature which has been
completed to the extent of 75% or more and value of which is not less than the desired value at (i) above..

c. For 3" Call - The bidder should have successfully completed at least one similar type of work work / Similar nature
of work & construction civil Works etc.during last five (5) years for a single similar nature contract of value not less
than 20% or a single running work of similar nature which has been completed to the extent of 70% or more and
value of which is not Jess than the desired value at (i) above as per the P.W.D, order no, 04 - A/ PW/ O/ 10C- 02/
14, dt, 18/03/2015 .

4. The bidders should also have made profits after taxes for each of these last three (3) financial years,

(k). Employees’ Provident Fund and Miscellaneous Provisions Act, 1952 and Employees State Insurance Act, 1948 shall be
mandatory and strictly adhered to as per Government of West Bengal Labour Department No. 1137-IR/IR/MISC-11/11,
Dated: 14.11.2011.

Page 5 of 20

<!-- page 6 -->

0). Any Tenderer who has a bad reputation for his /101 workmanship and/or history of non-completion of any project under this ০
Division within the schedule time frame may be debarred from participating in the e-Tender.

(m) Engagement of Technical Supervisor _ Successful Tenderer while executing the project work, it is mandatory to engage at least 1
(one) no. Technical supervisor (Engineer with at least diploma in civil engineering having at least 5 (five years) experience in
supervision of similar construction works) who will supervise the entire work till successful completion of the project.

4. Opening of Technical Proposal
i, Technical proposals will be opened by the authorized representatives electronically from the website stated in Clause 2.1,

using their Digital Signature Certificate. . . .

ii, Intending Tenderers may remain present, at the time of opening of e-Tender, if they so desire.

iii, Cover (Folder) for Statutory Documents should be opened first, if found in order, Cover (Folder) for Non-statutory
Documents will be opened. If there is any deficiency in the Documents, the e-Tender will summarily be rejected.

3৮ Decrypted (transformed into readable formats) documents of the Non statutory Cover will be downloaded, and handed over
to the e-Tender Evaluation Committee (constituted for evaluation of e-Tenders).

5. Uploading of summary list of technically qualified Tenderers (Ist round)

Pursuant to scrutiny and decision of the e-Tender Evaluation Committee (TEC), the summary list of eligible Tenderers with the serial

number of work(s) for which their Financial Proposals will be considered will be uploaded in the web portals.

While evaluation, the Committee may summon the Tenderers and seek clarification / information or additional documents or

original hard copy of any of the documents already submitted and if these cannot be produced within the stipulated time frame, their

Proposals will be liable for rejection.

6. Final publication of summary list of ‘technically qualified Tenderers

Date of opening of financial bid will to be intimated in the final summary list.

7. Opening and Evaluation of Financial Proposal

i) Financial proposals of the Tenders declared technically eligible by the e-Tender Evaluation Committee will be opened electronically

from the web portal stated in clause 2 on the prescribned date.

ii) The encrypted copies will be decrypted and the rates will be read out to the contractors remaining present at that time. After

evaluation of Financial Proposal, by the appropriate Authority of WBFOREST, may upload the final summary result containing

inter-alia, name of contractors and the rates quoted by them against each work provided E-Tender evaluation committee is satisfied
that the rate obtained is fair and reasonable and there is no scope of further lowering down of rate.

iii) After evaluation of Financial proposal, by the Divisional Forest Officer, Kangsabati North Division, Purulia the final summary

result will be uploaded in the web site, which will contain, name of contractors and the rates quoted by them against each work.

8. Procedures to be followed when one / two technically qualified Tenderers participated in any e-Tender:

Financial bid of technically qualified single / two Tenderers may not be opened. Re-Tender may be invited immediately in the

process of evaluation as per norms of e-Tender as per G.O. No. 925/F(Y) dated 14/02/2017.

9. Acceptance of e-Tender (Technically eligible/ qualified)

Lowest valid rate should normally be accepted. However, the e-Tender Accepting Authority does not bind himself to do so and
reserves the right to reject any or all the e-Tenders, for valid reasons and also reserves the right to distribute the work amongst more
than one e-Tenderer at the accepted rate after formal consultation with L1 (accepted rate) bidder and taking consent of L1 bidder for
smooth & quick completion of the work.

10. Penalty for suppression / distortion of facts

If any e-Tender fails to produce the original hard copies of the documents (especially completion certificates and audited balance
sheets), or any other documents on demand of the E-Tender Evaluation Committee within a specified time frame or if any deviation
is detected in the hard copies from the uploaded soft copies or if there is any suppression, the e-Tenderer will be suspended from
participating in the e-Tenders on e-E-Tender platform for a period of 3 (Three) years. In addition, his user ID will be deactivated and
Eamest Money Deposit will stand forfeited. Besides, the WBFOREST DEPARTMENT may take appropriate legal action against
such defaulting e-Tenderer.
11. Brief details on the nature of work:
Engagement of Labour (FY 2025-26) & Hiring Vehicle for protection
Name of the Project of forests at Range Jurisdiction at Puncha Range, Kangsabati North
Division, Purulia
a 7
a 0 __________________]
| 4) _| Nature of Work [: | Labour Oriented work.
Contractors eligible to submit the e- As per Sl, No, 03 of the NIT
Tender
Page 6 of 20

<!-- page 7 -->

f
12, Earnest Money Deposit (EMD):
a) Mode of EMD Payment: Payment by NET BANKING (any listed bank) though ICICI bank payment gateway:

* — On selection of net banking as the payment mode, the bidder will be directed to ICICI bank payment gateway web page
(along with a string containing a unique ID) where he will select the bank through which he wants to do the transaction.

© Bidder willmake the payment after entering his unique ID and Password of the bank to process the transaction.

* 810৩1 will receive a confirmation message regarding success or failure of the transaction. .

© Ifthe transaction is successful, the amount paid by the bidder will get credited in the respective polling account the State
Government / PSU/ autonomous body / local body / PRIs etc. maintained with the focal point branch of ICICI bank at
RN. Mukherjee Road, Kolkata for collection of EMD or Tender fees.

© Ifthe transaction is failure, the bidder shall again try for payment by going back to the first step.

13. Opening of e-Tender: . . .

a) The Technical Bid shall be publicly opened by the authority receiving e-Tender or by his Authorized representative, as per
the Date & time Schedule mentioned in NIT. . .

b) Prospective Tenderers or their authorized representatives may be present during the opening process.

©) Financial Bids of only those Tenderers who would qualify in the Technical Bid evaluation will be opened.

d) The intending Tenderers shall clearly understand that whatever may be the outcome of the present Invitation of e-Tender,
no cost of e-Tendering shall be reimbursable by the Government. The Divisional Forest Officer, Kangsabati North
Division Purulia, W-B. reserves the right to reject any e-Tender or all Tenders without assigning any reason whatsoever
and is not liable for any cost that might have incurred by any Tenderer at any stage of Tendering.

e) The acceptance of the Tender rests with the The Divisional Forest Officer, Kangsabati North Division Purulia, W.B.
who does not bind himself to accept the lowest Tender and reserves to himself the authority to reject any or all the Tenders
received without assigning any reason thereof.

f) Intending Tenderers are encouraged to inspect the site of work and get them thoroughly acquainted with the local condition
and all factors which may affect their rates. Prior to the site visit the intending Tenderers must inform The Divisional
Forest Officer, Kangsabati North Division Purulia, W.B. about the time and date of the visit.

14. The selected Contractor must arrange to procure all materials required for the proper completion of the work (as per the Technical
Specifications of the e-Tender document). The Employer will not on any account be responsible for procuring the same.

15. The selected contractor shall apply to The Divisional Forest Officer, Kangsabati North Division Purulia, W.B. for seeking
permission for utilization of land at the proximity of the site for arranging required plant & machineries, store of materials etc. at his
own cost and responsibility. All such temporary shed etc. shall have to be dismantled and all debris etc. cleared from site post
completion of the work or as directed by The Divisional Forest Officer, Kangsabati North Division Purulia,. Once an order to the
effect is issued from The Divisional Forest Officer, Kangsabati North Division Purulia,W.B. in this regard, it shall be brought to
effect by the contractor without contest.

16. Validity of Bids:

a) Bid shall remain valid for one year. Bid validity for a shorter period shall be rejected by e-Tender Accepting Authority as
non-responsive.

b) If any Tenderer withdraws his offer before Bid validity period without giving any satisfactory explanation for such
withdrawals, he may be barred from submission of any further e-Tender to this Office and to the Directorate of Forests,
Government of West Bengal for a minimum period of 1 (one) year.

০) 17111091110 ned by the Tender A: tit ithorit id will not be allowed for withdrawal.

17. Verification of credentials/onsite projects:

Before issuance of the work order, the e-Tender Accepting Authority may verify the credential and other documents of the
lowest Tenderer if found necessary. After verification, if it is found that such documents submitted by the lowest Tenderer is
either manufactured or false in that case, work order will not be issued in favour of the Tenderer under any circumstances and
legal action will be taken against him. In the middle of the implementation of the work any dispute notices in any documents of
the lowest bidder, the work order will be cancelled and legal action will be taken against the bidder.

18. Cancellation of e-Tender:

The Divisional Forest Officer, Kangsabati North Division Purulia, W.B. reserves the right to cancel this N.I.T. due to

unavoidable circumstances and no claim in this respect will be entertained.
19, Security Deposit:
a) The successful Tenderer to whom a Letter of Acceptance has been issued shall submit within 10(ten) days from the date of

Letter of এসি

(fen Percent) of the contracted value of work as per the G.O. NO. 796 - F (Y), dt. 25/02/2022; this shall have to be deposited

in the Portal of GRIPS (Paid Challan).

5784/PW/L&A/2m-175/2017, dt, = 12-09-2017 from the date of final payment to the
রঃ ০১০4৫ -4 nt to the successful tenderer. No interest on
Security Deposit will be paid by the Tender accepting Authority, 2
৮) If the accepted bid value is 80% or less of the Estimate iti it
put to tender the Additional Performance Security @ 10% of the
age fender 2০৫ amount as the G.O. NO. 4608 - F(Y), dt. 18/07.2018 which shall have to be submitted by the successful bidder in the
০

<!-- page 8 -->

i ff the Work Order. If the bidder fails to submi
form of Bank Guarantee from a0 Schl ee ne days fom | the date of issuance of Letter of Acceptance, his Ear
কিল উদ ike black listing of the contractor, etc, maybe taken. The Bank Guarantee
Money will be forfeited and ০1 A ingly, if required.
shall have to be valid up to end of the Contract Period and shall be renewed accordingly, if req
16107 of the Contract and pa t of bills. If the bidder fails to
The Bank Guarantee shall be returned after successful comp! 7 t ment i ae
complete the work successfully, the ‘Additional Performance Security shall be forfeited at any time during the pendency of
contract period.
এ নিক i from the last date of payment of bill for the
d) The security deposit will be released to the successful contractor after 6 (six) months on n ডি
) work, provided a0 irregularities are noticed during this period. In case of any irregularities are seen, the security deposit will be
forfeited and in addition any legal action as deemed fit may be initiated.
20. Technical Specification and Quality of Works: . . রী এ ee
All works are to be carried out as per plan, specification and estimate of works subject to modification made in writing by the
undersigned or his authorized officer.
21, Deduction of Taxes etc: . Fi 4
The applicable income tax, GST and any other existing tax from the contractor's bill if any new tax is added will be কা as
per Govt. Rule 1% (one percent) of the work cost @ Labour Welfare Cess will be deducted from each bill of the sel
organization.
22. Maintenance Period: . was
The Contractor will be liable to maintain the supply work at the appropriate service level to the satisfaction of The Divisional
Forest Officer, Kangsabati North Division Purulia, W.B. at his own cost for a period of Ses Pe iod/Maintenance iod, as
PWD Noti ion no 5951-7 W/2m-175/2017, dt. - 02-11-2017 read_with notification no. '84/PW / /2m-
175/2017, dt. — 12-09-2017 from the / completion of the work in all res; If any defect/damage is found during the period
as mentioned above, the Agency shall make the same good at his own cost. Failure to do so, penal action against the Agency will be
imposed by the Government as deem fit. The Agency will have to quote his rate considering the above aspect. Also, the Prospective
Tenderers shall have to execute the works in such a manner so that appropriate service level of the work is kept during progress of
work and the period of maintenance.
23. Removal of Discrepancy: ; রা
If any discrepancy arises between two similar clauses on different notification, the clause as stated in later notification will
supersede former one in following sequence: -
a. Form of Agreement
b. e-Tender Form
c. Technical Specifications
d. General Terms and Conditions
e. Relevant PWD(W.B.) Schedule of Rates
f. Instructions to Bidders
g NIT
24. Mobilization Advance/ Cost over Run:
No Mobilisation Advance and Secured Advance will be allowed. Time / cost overrun and consequent cost of escalation for any
materials, labour, P.O.L. etc. will not be allowed unless approved otherwise.
25. Canvassing in connection with the e-Tender is strictly prohibited.
26. Site of work and necessary drawings/maps may be handed over to the successful Tenderer along with the work order or in a
phase wise manner as deemed fit by The Divisional Forest Officer, Kangsabati North Division Purulia, W.B. No claim in this
regard will be entertained. \
27. The successful Tenderer will have to start the work as per the work order. He must complete different stages of work as per time
frame specified in the NIT/work order. However, The Divisional Forest Officer, Kangsabati North Division Purulia, W.B may
subsequently alter time frame as deems fit.
28. The Successful Tenderer will be required to obtain valid registration certificate & labour license from respective offices mandatory
where work by them is proposed to be carried out under the Contract Labour (Regulation & Abolition) Act, 1970 and the same
should be submitted to The Divisional Forest Officer, Kangsabati North Division Purulia, W.B.
29. The successful Tenderer shall have to comply with the provision of (a) the Contract Labour (Regulation & Abolition) Act, 1970
and (b) the Minimum Wages Act, 1948 and the Notifications thereof or other laws relating thereto, and the rules made and orders
issued there under from time to time. Failure to do so will be treated as breach of contract and The Divisional Forest Officer,
Kangsabati North Division Purulia, W.B. may in his discretion cancel the contract. The contactor shall also be liable for any
liability arising on account of any violation by him of the provisions of the Act and Rules made there under time to time.
30. The contractor shall not be entitled for any compensation for any loss suffered by him due to delay arising out for modification of
the work, due to non-delivery of the possession of site and / or modification of work.
31. Prevailing safety norms must be followed by the successful Tenderer during execution of the work so that LTI (Loss of time due
to injury) is zero.
32. Guiding schedule of works should be followed as per existing norms, patterns, lying in the working division.
Page 8 of 20

<!-- page 9 -->

Sf
33. The contractor shall abide by all acts and i ॥ 141 iodiversi
70181 A rules, especially but not limited to the field of Forests, Wildlife and Biodiversity.
/ Violation of any of these will be treated stringently as per law and offenders will also be prosecuted.
pt sat ol is to quote in figures as well as in words, his rates in the following forms in his cases against the estimated value put to
35, In the event of a e-Tender being submitted by a firm, it must be signed by a member ot members of the firm having legal authority
* ene

to do so and if called for, legal documentations in support thereon must be produced for inspection and in the case of a firm carried

out by one member or a joint family it must disclose that the firm is duly registered under the Indian Partnership Act.

36. The Tenderer must sign at the bottom of each page of the e-Tender documents as a proof ‘of acceptance of terms and conditions of

the e-Tender. Overwriting shall not be allowed. All corrections, alternations etc. must be duly signed.

37. It must be clearly understood that the quantities of the various items indicated in the schedule or probable items are approximate

only and may be increased or decreased during actual execution. The contractor shall remain effected by alteration.

38. The estimated cost is inclusive of all statutory taxes & Cess as applicable. The detail brake up GST and Cess as applicable

should be provided in the R.A Bill/ Final Bill as per prevalent order of the Finance Department Govt. of West Bengal in this

respect.

39. Payment will be done in favour of the L1 bidder (in normal case) subject to availability of fund and receipt of requisite

approval from the competent Authority

40. No child labour should be engaged.

41. RATES ARE FIRM FOR THE PERIOD OF THE PROJECT. IN CASE ANY ABNORMAL DEVIATION IS OBSERVED
DURING THE COURSE THE E-TENDER ACCEPTING AUTHORITY MAY REFER TO THE APPROPRIATE
HIGHER AUTHORITY OF DIRECTORATE OF FORESTS, GOVT. OF WEST BENGAL IN DECIDING ON THE
RATE REVISIONS (IF NEEDED).

42. The Contractor must engage local JFMC members as labourer for execution of plantation works. No outer labourer will be
considered for this purpose. The Wages of labourer should be paid in right time. No excuse is considered in this regard.

43. Work Order will be issued after getting administrative approval and financial sanction from the higher authorities.

44. The Contractor must abide by the NOTIFICATION No. 1140 PRD-33011/1/2024-MGNREGA SEC, dt. 07.03.2024. for
implementation of “KARMASHREE SCHEME” and Job card holders shall be engaged as unskilled labourers.

45. The Contractor will also be blacklisted if he/she will fail to complete the work in due time, unless there is Act of God or any
natural calamity or any other incident.

46. If it is noticed during course of work that any document of the bidder, submitted is false or forged, the work order of the said
work will be cancelled and the bidder will be black listed.

Divisional icer,
Kangsabati Ni ivision,
Page 9 of 20

<!-- page 10 -->

Section - B
FORM-I a
APPLICATION

To,

The Divisional Forest Officer,

Kangsabati North Division,

Purulia.

Subject: Name of the Work with e-Tender reference no, ____.
Reference: (N.I.T No.).

Dear Sir,

Having examined the Statutory, Non-statutory and NIT documents; I/We hereby submit all the necessary information and relevant
documents for evaluation.

The necessary evidence admissible by law in respect of authority assigned to us on behalf of the group of firms for application and for
completion of the contract documents is attached herewith.

1/We are interested in bidding for the work mentioned above.

1/We understand that

(a) e-Tender Inviting Authority and Accepting Authority can amend the scope and value of the contract bid under this
project
(b) e-Tender Inviting Authority and Accepting Authority reserve the right to reject any e-Tender without assigning any
reason.

The application is made by me/us on behalf of in the capacity of duly authorized to
submit the e-Tender.

Enclosure:

(1) Technical Proposal (Envelop-1/Folder)

(2) Financial Proposal (Envelop-2/Folder)
Date:
Signature of authorized officer of the firm:___—
Title & Capacity of the offices
Name of the Firm with Seals
Page 10 of 20
