---
doc_id: "bc1a853cfd3cfe0d"
source_url: "https://wberc.gov.in/sites/default/files/The%20Distribution%20of%20Electricity%20Licence%20Rules%202005.pdf"
ministry: "West Bengal Electricity Regulatory Commission (WBERC), West Bengal"
title: "View More"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a07f50b60a5dcca5"
---

<!-- page 1 -->

[Published in the Gazette of India, Extraordinary, Part II, Section 3, Sub Section (i)].
Government of India
Ministry of Power
New Delhi, the 23rd March, 2005.

Notification
G.S.R. 188(E) - In exercise of the powers conferred by sub-section (1) of, and clause (b) of subsection (2) of, section 176 of the Electricity Act, 2003 (Act 36 of 2003), the Central Government
hereby makes the following rules, namely:1.

Short title and commencement - (1) These rules may be called the Distribution of Electricity
Licence (additional requirements of Capital Adequacy, Creditworthiness and Code of Conduct)
Rules, 2005.
(2) They shall come into force on the date of their publication in the Official Gazette.

2.

Definitions - In these rules, unless the context otherwise requires, (a) ‘Act’ means the Electricity Act, 2003;
(b) Words and expression used and not defined in these rules but defined in the Electricity
Act, 2003 (36 of 2003), shall have the meanings respectively assigned to them in that Act.

3.

Requirements of capital adequacy and creditworthiness - (1) The Appropriate Commission
shall, upon receipt of an application for grant of licence for distribution of electricity under subsection (1) of section 15 of the Electricity Act, 2003, decide the requirement of capital investment for distribution network after hearing the applicant and keeping in view the size of the area
of supply and the service obligation within that area in terms of section 43.
(2) The applicant for grant of licence shall be required to satisfy the Appropriate Commission
that on a norm of 30% equity on cost of investment as determined under sub-rule (1), he
including the promoters, in case the applicant is a company, would be in a position to make
available resources for such equity of the project on the basis of networth and generation
of internal resources of his business including of promoters in the preceding three years
after excluding his other committed investments.

Explanation :- For the grant of a licence for distribution of electricity within the same area in
terms of sixth proviso to section 14 of the Act, the area falling within a Municipal Council or a
Municipal Corporation as defined in the article 243(Q) of the Constitution of India or a revenue
district shall be the minimum area of supply.
4.

Requirement of Code of Conduct - The applicant for grant of licence shall satisfy the Appropriate Commission that he has not been found guilty or has not been disqualified under any of the
205

<!-- page 2 -->

following provisions within the last three years from the date of the application for the grant of
licence:
(a) section 203, section 274, section 388B or section 397 of the Companies Act, 1956;
(b) section 276, section 276B, section 276BB, section 276C, section 277 or section 278 of the
Income tax Act, 1961;
(c) section 15C, section 15G, section 15H or section 15HA of the Securities and Exchange Board
of India Act 1992;
(d) clause (b), (bb), (bbb), (bbbb), (c) or (d) of sub-section (1) of section 9 of the Excise Act 1944;
(e) section 132 or section 135 of the Customs Act 1962,
and that the applicant is not a person in whose case licence was suspended under section 24 or
revoked under section 19 of the Act, within the last three years from the date of application:
Provided that where the applicant is a company, it shall satisfy the Appropriate Commission in
addition to provisions of this rule that no petition for winding up of the company or any other
company of the same promoter has been admitted under section 443 (e) of the Companies Act,
1956 on the ground of its being unable to pay its debts.
[F.No. 23/18/2003-R&R]
Sd/Ajay Shankar,
Additional Secretary to the Government of India.

206
