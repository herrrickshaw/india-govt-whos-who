---
doc_id: "03bfceb46ac8fe45"
source_url: "https://addaonline.in/wp-content/uploads/2019/11/Corrigendum-notice.pdf"
ministry: "ASANSOL Durgapur Development Authority, West Bengal"
title: "Download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7ad3a513bde15bce"
---

<!-- page 1 -->

ASANSOL DURGAPUR DEVELOPMENT AUTHORITY
A S掘uめry Aufhority q笹舶Go准仰men噂Wes鵬gng。l
恒nder Urban Development & Munic圃A楠l「s Depa輔ent)

⊆QRRIGENDUM NOTIC聖
断rence・・掬autho砂memo no‑ADD4/ASZ〃844/mO8 dded2709.辺Z2

/

In reference to the notice above published for e‑Auction of land for industrial puapose
at ADDA Layout PIot No‑ D‑7 in MSTP, Raniga扇is hereby, reVised regarding

Last Date

for Submission of Hard Copies of application. along with security Deposit & Auction
Processing Fees" extended from date O4.11.2019 to O5・11.2019 upto 3:00 PM, due to
declared Public Holiday on the submission date. Other scheduled dates & ti叩e will remain

Sane Vide notice reference mentioned above.

AsansoI Durgapur Development Authority
