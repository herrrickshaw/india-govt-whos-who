---
doc_id: "02eb7a6edeea673d"
source_url: "https://kolkatapolice.gov.in/wp-content/uploads/2026/01/Tender-7th-BN-KAP.pdf"
ministry: "Kolkata Police, West Bengal"
title: "Download"
date: ""
pages: 3
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "8d16dfd58b7e6be9"
---

<!-- page 1 -->

in aaa. wears
sont et
Government of West Bengal
Office of the Deputy Commissioner of Police
7 Battalion, Kolkata Armed Police
7, Diamond Harbour Road, Kolkata - 700 027
Memo No. ৪৪ _/ HAZ Bn KAP Dated _§2. 01 72028
NOTICE
Sub: Replacement of (06) six nos. Tr. PVC water storage tank with allied work on the roof of
Barrack No. 04 at B.G. Lines’ at 7, Diamond Harbour Road, Kolkata _ 700 027 during the
year 2025 - 2026
৫
Ref: Tender No. 7” Bn., KAP / Tender - 04 (Minor Works) / 2025 _ 2026 Dated 02” January, 2026
NOTICE INVITING TENDER
(Percentage rate type)

1 Sealed tenders are invited for the following works from eligible tenderers as per particulars given below:
Replacement of (06) six nos. Tr. PVC water
storage tank with allied work on the roof of
Barrack No. 04 B.G.Lines, 7, Diamond Harbour
Road, Kolkata-700027 during the year 2025 -
2026.

(8) | Who are eligible to submit All bonafide Contractors / Firms / Local Body
having such business and knowledge in this
regard and having necessary & sufficient financial
capacity & experience.

[৭] Last date for receipt of Tender | 09-01-2026 up to 17:00 Hrs. (IST)
Glico i
Estimated amount put to tender Rs.99,626.00 (Rupees Ninety Nine Thousand Six
Hundred & Twenty Six) only
Time allowed for completion of works 10 (Ten) days after the issue date of the Work
Order
Earnest Money Deposit (EMD) ]:। Rs,2000.00 (Rupees Two Thousand) only

*** Earnest Money Deposit (EMD) does not require for those Contractors / Firms / Local Body if they are

covered as per provision of MSME (Ministry of Micro, Small & Medium Enterprise)

2. The tender documents and other relevant particulars (if any) may be seen by the intending tenderers during
office hours in the Office of the Deputy Commissioner of Police, 7” Battalion, Kolkata Armed Police (B.G.L.
Compound), 7, Diamond Harbour Road, Kolkata _ 700 027 during the year 2025 - 2026,

3. The Contractors should deposit EMD along with his own bid, payable to “The Deputy Commissioner of Police, 7”
Battalion, Kolkata Armed Police (B.G.L. Compound), 7, Diamond Harbour Road, Kolkata - 700 027” as Demand
Draft from any Nationalised Bank,

4. The Contractor shall submit filled tender documents enclosed with valid & current Trade Licence (Photocopy,
Self-Attested), G.S.T, Registration Certificate (Photocopy, Self-Attested), PAN (Photocopy, Self-Attested),
Professional Tax Recelpt (Photocopy, Self-Attested) & latest IT Return (Self Attested).

Page 1 of 2

<!-- page 2 -->

5. - Sealed Tender addressed to “The Deputy Commissioner of Police, 7 Battalion, Kolkata Armed Police (B.G.L.
Compound), 7, Diamond Harbour Road, Kolkata — 700 027” should be sent in a sealed cover super scribing the
envelope as name of tender “Replacement of (06) six nos. Tr. PVC water storage tank with allied work
on the roof of Barrack No. 04 at B.G.Lines at 7, Diamond Harbour 7, Diamond Harbour Road, Kolkata _ 700
027 during the year 2025 — 2026” to be dropped in the sealed TENDER DROP BOX, kept at the office of the Head
Assistant, 7" Battalion, Kolkata Armed Police(B.G.L. Compound) of 7, Diamond Harbour Road, Kolkata—700 027
on or before 09" January, 2026 within 17.00 Hrs. or, may also be sent by Registered Post / Speed Post to reach
on or before 09" January, 2026 within 17.00 Hrs.

6. The Tender Committee reserves the right to reject any/or all the tenders without assigning any reason. If
requires, the undersigned & also the Chairman of the Tender Committee holds the right to change / alter &
addition of rules of the tender. The undersigned also reserves the right not to enter in any contract with
tenderers at all.

7s The Tender Committee will open the sealed tenders in the office of the Deputy Commissioner of Police, Liat
Battalion, Kolkata Armed Police (B.G.L. Compound), 7, Diamond Harbour Road, Kolkata _ 700 027. The tenderers
may be present or send their authorised representatives at the time of opening the sealed tenders on 14" |
January, 2026.

“ Terms & Conditions of Tenders:

1. All works to be carried out in a manner according to specification for original work

2. All materials, tools, labour & transport will have to be provided by the contractor at their own cost inclusive of all
taxes and other.

3. No extra work shall be allowed without prior approval of the competent authority.

4. In no case, there shall be any change in the amount of Rs.99,626.00.00 (Rupees Ninety Nine Thousand Six
Hundred & Twenty Six) only.

5. The contractors shall inspect the schedule of nature of works at site to assess all eventualities connected with
works. Any other information connected with this work may be obtained from the B.O. & D.D.O., 7" Battalion,
Kolkata Armed Police(B.G.L. Compound) of 7, Diamond Harbour Road, Kolkata _ 700 027. No deviation after
submission of tender by the contractors will be considered.

eputy Commissipner of Police pj. nn
88177137170,
7th Bn., Kolkata ‘Armed Police :

<!-- page 3 -->

ANNEXURE =
" তা ক ( Nazrul Abas) at Body
ith allied work on the roof of barrack no.-4 (
Name of works: Replacement of six nos, 2000 tr.PVC water storage tank with allied wor :
“Giiard-Lines,Kolkata,During the year 2025-2026.
1০১ No So an of GST উট SL Sinead top SHI Td টুক লট উজ তিন
এ — Supping PVG. walt slags lank of SppTavaT Guay WIN Geel tp wiih Td
Item-6 (Black) - Multilayer.(d) 2000 litre capacity :
(S&P)
5. ch 154.00 each 924,00
2) Page- 37 Labour for hoisting plastic water storage 0040) Above 1500 litre upto 5000 litre 6.00 ea
Item-10 _capacity..(a) 1st story from 0.৮
/ (S&P) . h 72.00 each 1296.00
/ 0 Extra for each additional story a যা ৫ Saas
ঠা] ও page-38 Labour for punching hole in plastic water storage tank upto 50 mm dia. 18.00 each 194 8
রঃ ০
) 4 Page-4 Supplying, fitting and fixing Peet's valve fullway gunmetal standard Pattern best
1 tem-4 quality of approved brand bearing 1.8.1. marking with fittings (tested to 21 kg per
| be ae) “2516.0
4 ২ fv 32mm রা রা 2 টি
(9 40mm 3.00 each 1646.00 cach a
4 liv) 50 mm dia 3.00 each 2362.00 ~— cach 00
] + Pagel2_ Supplying, fitting and fixing Pvc Pipes of approved make of Schedule 80 (medium ?
Tez 101) co's) conforming to ASTMD - 1785 and threaded to match with GI Pipes as per IS:
p (Sar] 1259 (Part-I). with all necessary accessories, epeciala viz. socket, bend, tee, union,
{ cross, elbo, nipple, longscrew, reducing socket, reducing tee, short plece etm, fitted 7
: Rin holder bats clamps, including cutting pipes, making threads fitting, fixing etc. 7
i complete in all respect including cost of all necessary fittings as required jointing
aterials and two coats of painting with approved paint in any rosition ebre :
ground. (Payment will be made on the centre line measurements of tetal pipe line
including all specials. No separate payment will be made for accesories, specials,
Payment for painting will be made seperately)
(a) For Exposed Work -- PVC Pipes (Dia) :
25 mm 3.00 mtr 177.00 mtr 531.00
32mm 3.00 mtr 236.00 mtr 708.00
40 mm 3.00 mtr 292.00 mtr 876.00
50 mm- ; 3.00 mtr 384.00 mtr 1152.00
25580 Cleaning and disinfecting upto 2000 litre Water Tank including masonry 4.00 each :555.00 cach 620.00
Ttem-14 Teseryoir.
(sap
A ——
83593.00
Add 9% for casT 7523.37
Add 9% for scsr 7523.37
——
Total 98639.74
; ae Add 1% L.W.Ceas 986.40
—
Grand Total 99626.14
7 Say Rs 99626.00
(Rupees Ninety Nine Thousand Six Hundred and ‘Twenty Six Only }
A
ঘর
