---
doc_id: "a480d6c55cea6cae"
source_url: "https://cnci.ac.in/backend/public/uploads/2024/12/10/Tendernotice_1%20%2824%29.pdf"
ministry: "Chittaranjan National Cancer Institute (CNCI)"
title: "Tender File"
date: ""
pages: 35
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "05228e8e67aee63e"
---

<!-- page 1 -->

CHITTARANJAN NATIONAL CANCER INSTITUTE
(An Autonomous Body Under Ministry of Health & Family Welfare, Govt. of India)
1st Campus: 37, S.P. Mukherjee Road, Kolkata- 700026
2nd Campus: Street No 299, DJ-01, AA-1D, Newtown, Rajarhat, Kolkata-700160
Tender No. CNCI/e NIT-79/2024-25

Date: 10.12.2024

NOTICE INVITING TENDER
1. Tender for “Modification work of 1st floor laboratory of CNCI 2nd campus.”. Sealed item rate tenders in
two bid system are invited by CHITTARANJAN NATIONAL CANCER INSTITUTE (i.e. CNCI) for the works
“Modification work of 1st floor laboratory of CNCI 2nd campus.” The two bid system of tender shall
consist of Techno- commercial part (Envelope-I) duly sealed and super scribed with the words “Technocommercial Part” and “Price Bid” (Envelope-II) super scribed with the words “Price-Bid”. Both the
envelopes shall be kept in third envelope duly super scribed with the words “Modification work of 1st
floor laboratory of CNCI 2nd campus.”. The works for which tender is invited are as follows:
Sl. Name of Work
No
A. “Modification work of 1st floor
laboratory of CNCI 2nd campus.”

Estimated
Cost (in Rs.)

--

Earnest Money Cost of Tender
document (in Rs)
(in Rs.)

--

--

Duration

30 Days

The brief scope of work in this tender shall include (but not limited to) providing all labour, materials, tools
and plant, transportation to site, storage and safe custody of the materials, erection testing and commissioning
all complete including rectification, repair etc. during defect liability period etc.
Apart from above, any other service required for completeness of the services and as per direction of CNCI is
deemed to be included in the scope of work. The work is to be carried out on item rate basis as per bill of
quantities and tender conditions.
The detailed scope of work is given in the tender documents.
Time schedule of tender activities:
i)

Date & Time for submission of Tender Documents: to 30/12/2024 up to 14.00 hrs.

ii)

Date & Time of Opening of Technical Bid: On 31/12/2024 at 14:30 hrs.

iii)
Date & Time of Opening of Commercial Bid: To be Communicated to the qualifying
tenderer later
3.0
Contractors who fulfill the following basic qualifying requirements are eligible to participate in this
tender.
a) Bidder should have completed /substantially completed during last 7 (seven) years from the last date of
submission of the bid the following “similar works”.
Three similar works, each of costing minimum 40% of the estimated cost put to this tender.
OR
Two similar works each of costing minimum 60% of the estimated cost put to this tender.
OR
One similar work costing minimum 80% of the estimated cost put to this tender.

Page 1 of 5

<!-- page 2 -->

CHITTARANJAN NATIONAL CANCER INSTITUTE
(An Autonomous Body Under Ministry of Health & Family Welfare, Govt. of India)
1st Campus: 37, S.P. Mukherjee Road, Kolkata- 700026
2nd Campus: Street No 299, DJ-01, AA-1D, Newtown, Rajarhat, Kolkata-700160
The substantially completed works shall be the works where at least 80% billing of total awarded value
has been achieved. The certificates issued by client with billed value of work shall form the basis of evaluation.

“Similar Works does not mean General Civil works. The bidder should have similar
experience as per the scope of work.” (If the bidder fails to submit the work order, may be
summarily rejected).
b) For evaluation purpose, the completion cost of works mentioned in the completion certificate shall be
enhanced by 7% per annum till the end of month prior to date of NIT.
c) Should have had Average Annual Financial Turnover of at least 100% of the estimated cost of the work in
the last three consecutive years ending 31.03.2024 duly certified by a Chartered Accountant.
d) Should not have incurred any loss in more than two years during the immediate last five consecutive
financial years ending 31.03.2024. Copies of balance sheet / certificate from Chartered Accountant are to be
submitted.
g) Should have valid Permanent Account Number of Income Tax Should have a valid trade license. Copies of
documentary evidence are to be submitted.
h) Should have valid GST Registration number. In case the bidder does not have GST Registration, the same
shall be obtained by the successful bidder within one month from the date of LOI or before release of 1st RA
Bill whichever is earlier. An undertaken shall be submitted by the bidder for the submission of GST required
in the line with the above.
i) The experience certificates issued by Government Organizations / Semi Government Organizations / State
Government Public Works Department / Central Government / Public Sector Undertakings / Government
Autonomous Bodies/ Municipal Bodies / Reputed Private Organizations shall be accepted for assessing the
eligibility of tender.
j) The contractors who are in litigation with CNCI currently or for last five years are not eligible to participate
in this tender. In case it is subsequently found in the tendering stage that the tenderer has participated in the
tender even though he is already in litigation with CNCI his offer shall be rejected and his EMD shall be forfeited
by CNCI. In case such a tenderer is awarded with the work his contract will be terminated forthwith and all his
securities will be forfeited by CNCI.
k) Even though an applicant may satisfy the eligibility criteria, CNCI reserves the right for not issuing the
tender document if the applicant has record of poor performance such as abandoning work, not properly
completing the work, delay in completion of work, poor quality of work, financial failure / weakness etc.
l) All corrigendum and addendum shall be part of tender documents and are to be submitted duly signed and
stamped by the tenderer. Even if tenderer fails to submit corrigendum and addendum duly signed by him, he
will be deemed to have gone through such addendums/ corrigendum if any, and no claim shall be entertained
by CNCI on account of any omission /error on his part.
m)

Should have an office setup in Kolkata, West Bengal.

Page 2 of 5

<!-- page 3 -->

CHITTARANJAN NATIONAL CANCER INSTITUTE
(An Autonomous Body Under Ministry of Health & Family Welfare, Govt. of India)
1st Campus: 37, S.P. Mukherjee Road, Kolkata- 700026
2nd Campus: Street No 299, DJ-01, AA-1D, Newtown, Rajarhat, Kolkata-700160
4.0

Tender documents comprising of the following:
a) Volume –I:
a. Notice Inviting Tender
b. Checklist of Documents to be submitted
c. Letter of undertaking
b) Volume –II: Price Bid with Bill of Quantity

5.0 Relevant experience certificates and other documents shall be self-attested by the tendered. Completion
Certificates from clients shall be in the name of the Company who is submitting the tender. The bidder has to
produce original documents for verification at the time of opening of tender or as and when demanded. The
Tender of any tenderer shall be rejected if on detailed scrutiny, documents submitted along with the tender
are found to be unsatisfactory/ forged and the EMD submitted by him shall stand forfeited by CNCI. The
decision of CNCI in this regard shall be final and binding on the tenderer.
6.0 All Tenders shall be valid up to 90 days from the due date of submission including any extension thereof
and must be accompanied by Earnest Money Deposit payable favoring, “Director, Chittaranjan National
Cancer Institute”, payable at Kolkata in form of DD. The EMD shall be valid for a minimum period of 90 days
(NinetyDays) from the date of publication of Tender. Tenders submitted without EMD or with inadequate
amount of EMD shall be rejected. However, exemption will be granted for submission of EMD to applicable
firms/agencies as per Govt. of India norms.
7.0 All Tenderers are requested to submit a details of Contact persons with their phone no and email id of
which organizations Completion certificate they are giving.
8.0 The Terms & Conditions contained in this NIT and tender documents shall be applicable. In case of any
unscheduled holiday taking place on the last day of issue of tender/submission of tender, the next working day
will be treated as scheduled day and time for issue/submission of Tender.
9.0 CNCI reserves its right to take appropriate action including disqualification of tenderer(s) as may be
deemed fit and proper by CNCI at any time without giving any notice to the tenderer in this regard. The decision
of CNCI in the matter of disqualification shall be final and binding on the Tenderers.
10.0 CNCI reserves the right to accept any tender or reject any or all tenders or annul this tendering process
without assigning any reason and liability whatsoever and to re-invite tender at its sole discretion. The
corrigendum or addendum, extension, cancellation of this NIT, if any, shall be hosted on the CNCI website.
The bidders are required to check CNCI’s website regularly for this purpose, to take into account before
submission of tender. All Corrigendum and addendum are to be submitted duly signed & stamped.
11.0 The price bid of those bidders whose bids have been found to be prima-face techno-commercially
accepted on the basis of documents submitted along with the bid (Techno-commercial part) shall be opened
with prior intimation to them. Hence, the participating tenderers must furnish their e-mail id and contact
phone numbers on the techno-commercial part.
12.0 In case of tie-tender, where two firms are biding lowest, CNCI reserves the right to split the work among
these bidders and / or CNCI will reserve the right to award the tender to any one of such bidder. Further CNCI
does not bind itself to accept the lowest tender. The decision of CNCI in this regard shall be final and binding
on the tenderers.

Page 3 of 5

<!-- page 4 -->

CHITTARANJAN NATIONAL CANCER INSTITUTE
(An Autonomous Body Under Ministry of Health & Family Welfare, Govt. of India)
1st Campus: 37, S.P. Mukherjee Road, Kolkata- 700026
2nd Campus: Street No 299, DJ-01, AA-1D, Newtown, Rajarhat, Kolkata-700160
13.0 Tender is uploaded in CPP portal and CNCI website dated 10.12.2024
14.0 SUBMISSION OF TENDER
A. Help for bidders, FAQ, Information about DSC and Bidders Manual Kit containing the detailed
guidelines for e‐Procurement system are also available on Central Public Procurement Portal.
[https://eprocure.gov.in/eprocure/app]
B. It is mandatory for all the bidders to have a valid Digital Signature Certificate (in the name of person
having power of attorney to sign the Bid) from any of the licensed Certifying Agency (Bidders can see
the list of licensed CA’s from the link www.cca.gov.in) to participate in e‐Procurement of
Chittaranjan National Cancer Institute.
C. It is mandatory for the bidders to get their firm /company registered with e‐procurement portal
https://eprocure.gov.in/eprocure/app to have user ID & password.
D. Tender documents will be available online on website https://eprocure.gov.in/eprocure/app which
can be downloaded free of cost.
E. Bidders may download and refer the “Instructions for Online Bid Submission” from
F. (https://eprocure.gov.in/eprocure/app).
G. The tender documents shall be submitted online in the prescribed format given on the websites and
technical bids received online shall be opened as per NIT or Corrigendum thereof. No other mode of
submission is acceptable. Detailed credentials as per the requirement of eligibility criteria and all
tender papers except Bill of Quantities are to be submitted in “Technical Bid”.
H. Bill of Quantities with rates duly filled in is to be submitted in the format provided online in the name
of “Financial Bid”. Hence, physical submission of the documents is limited to submission of original
Earnest Money and Tender document fee. Deposit in the form of Demand Draft as per provision given
in NIT.
I.

Representative of the bidder, who chooses to attend, may attend the online opening of the technical
bids on the scheduled date and time of Bid opening. However, such representatives shall be allowed
to attend the opening of the Technical Bids, only, if such person presents the letter of authority issued
in his name by the bidder on his letter head.

J.

Bidders cannot submit the tender after the due date and time of e‐bid submission. Time being
displayed on Central Public Procurement Portal https://eprocure.gov.in/eprocure/app (“Server
System Clock Time”) shall be final and binding on the bidder. E‐Bids are required to be submitted by
bidders, only as per the Indian Standard Time (IST) and not the time as per their location/country.

K. The bidders are advised to submit their e‐bids well before the e‐bid due date. CNCI shall not be
responsible for any delay in submission of e‐bids for any reason including server and technical
problems.
L. The Technical and Financial Bid shall be digitally signed by the Authorized Signatory of the bidder &
submitted “on‐line” only. The authorized signatory of the bidder must be in possession of Power of
Attorney before submitting the digitally signed bid. Scanned copies of various documents can be
prepared in .pdf file format.
M. Any tender received without original Earnest Money and Tender document fee in the form as specified
Page 4 of 5

<!-- page 5 -->

CHITTARANJAN NATIONAL CANCER INSTITUTE
(An Autonomous Body Under Ministry of Health & Family Welfare, Govt. of India)
1st Campus: 37, S.P. Mukherjee Road, Kolkata- 700026
2nd Campus: Street No 299, DJ-01, AA-1D, Newtown, Rajarhat, Kolkata-700160
in NIT shall not be considered and shall be summarily rejected.
N. CNCI reserves the right to cancel the tenders before submission/opening of tenders, postpone the
tender submission/opening date and to accept/reject any or all tenders without assigning any
reasons thereof. CNCI’s assessment of suitability as per eligibility criteria shall be final and binding.
15.0

Contact details for site related Queries / Visit:

a. Name: Shri Niladri Saha
b. Phone: +91-33-3506-0600 Ext. 2620
Chittaranjan National Cancer Institute,
299, DJ-01, AA-1D, Newtown, Rajarhat,
Kolkata-700160

DIRECTOR,
CNCI, KOLKATA

Page 4 of 5

Page 4 of 5

Page 5 of 5

<!-- page 6 -->

CHITTARANJAN NATIONAL CANCER INSTITUTE
(An Autonomous Body Under Ministry of Health & Family Welfare, Govt. of India)
1st Campus: 37, S.P. Mukherjee Road, Kolkata- 700026
2nd Campus: Street No 299, DJ-01, AA-1D, Newtown, Rajarhat, Kolkata-700160

GENERAL CONDITIONS OF CONTRACT

ENGINEERINGDIVISION

1

<!-- page 7 -->

CONDITIONS OF CONTRACT
Definitions:
1) The Contract means the documents forming the tender and acceptance/undertakings there and
the formal agreement executed between the director – CNCI and the Contractor/ Service
Provider together with the documents referred to therein including these conditions, the
specifications, designs, drawings and instructions issued from time to time by the Engineer-inCharge and all these documents taken together shall form one contract and shall be
complementary to the another.
2) In the contract, the following expression shall unless the context otherwise requires have the
meaning hereby respectively assigned to them.
a) The expression „WORKS‟ or „WORK‟ shall unless there be something either in the subject or
context repugnant to such construction be constructed and taken to means the works by or by
virtue of the contract constructed to be executed whether temporary or permanent and whether
original altered substituted or additional.
b) „SITE‟ means the land area and other places on, under, in or through which the works are to be
executed or carried out and any other land or places provided by CNCI or used for the
purposeof the agreement.
c) „CHITTARANJAN NATIONAL CANCER INSTITUTE‟, hereinafter called „CNCI‟ shall mean
Owner/ Client.
d) „CONTRACTOR/ SERVICE PROVIDER/SERVICE PROVIDER‟ shall mean the individual or firm
or company whether incorporated or not undertaking the works and shall include the legally
authorized personal representative or such individual or the persons composing such firm or
company or the successors or such firm or company and the permitted assignees of such
individual or firm or company.
e) The „DIRECTOR‟ means the Director of CNCI and his successors.
f)

The „ENGINEER-IN-CHARGE‟ means who shall supervise and bein charge of the work on
behalf of the Director-CNCI.

g) „APPROVAL‟ means approved in writing including subsequent written confirmation of
previous verbal approval.
h) „WRITING‟ means any manuscript typed written or printed statement under or over
signature and/or seal as the case may be.
i)

„MONTH‟ means English Calendar month. „Day‟ means a Calendar day of 24 Hrs each.
2

<!-- page 8 -->

j)

„CONTRACT VALUE‟ means the sum for which the Tender is accepted as per the
Agreement/ Letter of Acceptance/ Letter of Intent.

k) LANGUAGE: All documents and correspondence in respect of this contract shall be in
English Language.
l)

„BILL OF QUANTITIES or SCHEDULE OF QUANTITIES‟ means the priced and completed
Bill of Quantities or Schedule of Quantities forming part of the Tender. TENDER means the
Contractor/ Service Provider‟s priced offer to CNCI for the execution and completion of the
work and the remedying of any defects therein in accordance with the provisions of the
Contract, as accepted by the Letter of Intent or Award letter. The word TENDER is
synonymous with Bid and the word TENDER DOCUMENTS with “Bidding Documents” or
“offer documents”.

3) SITE VISIT AND COLLECTING LOCAL INFORMATION
Before tendering, the tenderer is advised to visit the Site, its surroundings to assess and
satisfy themselves about the local conditions such as the working and other constraints at
Site, approach roads to the Site, availability of water & power supply, applicability of taxes,
duties and levies etc., nature of ground, soil and sub-soil condition, underground water table
level, accommodations they may require etc., river regime, river water levels, other details of
river, streams & any other relevant information required by them to execute the complete
scope of work. The tenderer may obtain all necessary information as to risks, weather
conditions, contingencies & other circumstances (insurgencies etc.) which may influence or
affect their tender prices. Tenderer shall be deemed to have considered Site conditions
irrespective of the fact whether he has inspected it or not and/or have satisfied himself in all
respects before quoting his rates and no claim or extra charges whatsoever in this regard
shall be entertained / payable by CNCI at a later date.
4) SCOPE OF WORK
The scope of work covered in this Tender shall be as per the Bill of Quantities,
Specifications,

Drawings,

Instructions,

Orders

issued

to

the

Contractor/

Service

Provider/Service Provider from time to time during the pendency of work. Refer NIT for brief
scope of work.
The quantities of various items as entered in the “BILL OF QUANTITIES” are indicative only
and may vary depending upon the actual requirement. The Contractor/ Service Provider shall
3

<!-- page 9 -->

be bound to carry out and complete the stipulated work irrespective of the variation in individual
items specified in the Bill of Quantities.
5)

EARNEST MONEY DEPOSIT

Earnest Money Deposit (EMD) @ 2% of the value of work, required to be submitted along
with the Tender as mentioned in “Notice Inviting Tender” in favor of “Director, Chittaranjan
National Cancer Institute”, payable at Kolkata in form of DD from any Nationalized bank /
Scheduled Bank.
5.1

EMD shall accompany the offer and placed in the sealed envelope cover of the offer as
detailed in Instructions to Tenderer. Any tender not accompanied with the requisite
Earnest Money Deposit along with „Letter of Undertaking‟ shall not be accepted and be
rejected and such tenderer(s) will not be allowed to attend the opening of bids.

5.2

The EMD of all unsuccessful tenderers (i.e. except evaluated lowest tenderer) shall be
returned within Fifteen (15) days of the opening of price bids by CNCI.

5.3

Once the tenderer has given an unconditional acceptance to the tender conditions in its
entirety, he is not permitted to put any remark(s)/conditions(s) (except unconditional
rebate on price, if any) in/ along-with the Tender.

5.4

In case, the condition 5.3 mentioned above is found violated at any time after
opening of Tender, the Tender shall be summarily rejected and CNCI shall, without
prejudice to any other right or remedy, be at liberty to forfeit the full Earnest Money said.

5.5

No interest will be payable by CNCI on the said amount covered under EMD/Other
security documents.

5.6

EMD of successful tenderer, if deposited in the form of Demand Draft, will be treated
as part of Retention Money.

5.7

At any time after the due date of the Tender, if any tenderer alters /modifies/withdraws
his tender within the validity period (or the extended validity period) of his tender or fails
to execute the “Contract Agreement” within the prescribed time period after the
placement of LOI on him, CNCI without prejudice to any other rights or remedies shall
be at liberty to forfeit the Earnest Money deposited by the tenderer. In the event of retender, such tenderer shall not be allowed to submit tender.

6)

MOBILIZATION OF MEN, MATERIALS AND MACHINERY

6.1

All expenses towards mobilization at Site and de-mobilization including bringing in
4

<!-- page 10 -->

equipment, work force, materials, clearing the Site etc. shall be deemed to be included in
prices quoted and no separate claim for payment on account of such expenses shall be
entertained.
6.2

It shall be entirely the Contractor/ Service Provider‟s responsibility to provide, operate and
maintain all necessary construction equipment, scaffoldings and safety gadget, lifting
tackles, tools and appliances to perform the work in a workman like and efficient manner
and complete all jobs as per the specifications and within the schedule time of completion
of work.

6.3

It is mandatory for the Contractor/ Service Provider to provide safety equipment and
gadgets to its all workers, supervisory and Technical staff engaged in the

execution of

the work and while working. The minimum requirement (but not limited to) shall be
gumboots, safety helmets, Rubber hand gloves, facemasks, safety nets, belts, goggles etc.
as per work requirements. Sufficient nos. of these equipments and gadgets shall also be
provided to CNCI by the Contractor/ Service Provider at his own cost for use of CNCI
Officials and/ or workforce while working/ supervision at Site. The contractor shall ensure
that no staff/ worker shall be allowed to enter the Site without these equipments/ gadgets.
The cost of the above equipments/ gadgets are deemed to be included in the rates quoted
by the Contractor/ Service Provider for the items & works as per Bill of Quantities and
Contractor/ Service Provider shall not be entitled for any extra cost in these regard. The
above norm is to be strictly complied with at Site. In case the Contractor/ Service Provider
is found to be deficient in providing Safety Equipments/ Gadgets in the opinion of EngineerIn-Charge, the Engineer-In-Charge at his option can procure the same at the risk & cost of
Contractor/ Service Provider and provide the same for the use of worksite and shall make
the recoveries from the bills of the Contractor/ Service Provider for the same. The decision
of the Engineer-In-Charge shall be final and binding on Contractor/ Service Provider in this
regard.

5

<!-- page 11 -->

7)

TAXES &DUTIES

7.1

To enable CNCI to avail GST Input tax credit, CONTRACTOR/ SERVICE PROVIDER shall
submit GST compliant Tax invoice containing all the particulars according to the GST Rules
& Law. Such invoice shall be submitted within prescribed time limit in the name of CNCI and
must contain the address and GSTIN of CNCI.

7.2

In case GST credit is delayed/denied to CNCI or subsequently recovered from CNCI due to
non/delay in filing of GSTR-1 Return or delay in/non-payment of tax to Govt, by
CONTRACTOR/ SERVICE PROVIDER for any other reasons not attributable to CNCI, in
such case, any financial implication on CNCI on account of delay/loss/recovery from CNCI
of such GST Credit along with interest levied/ leviable on CNCI till the time GST credit is
available to CNCI, shall be recovered/ realized from the CONTRACTOR/ /SERVICE
PROVIDER‟s running bill/ security deposit.

7.3

Irrespective of refund of GST Credit and interest thereon to CNCI by GST portal upon
subsequent declaration of such invoice by CONTRACTOR/ SERVICE PROVIDER in his
GSTR-1 for any period after due date of such return and/or payment of GST thereon by
CONTRACTOR/ SERVICE PROVIDER on GST portal, the notional interest for delayed
period of GST credit (i.e. delay for the period when GST credit is actually allowed and the
period when GST credit should have been allowed had CONTRACTOR/ SERVICE
PROVIDER declared such invoice in his GSTR-1 and paid tax thereon in the relevant
month as per GST law) shall be recovered/ realized from CONTRACTOR/ SERVICE
PROVIDER.

7.4

GSTIN of CNCI will be provided to the CONTRACTOR/ SERVICE PROVIDER along with
the work order.

7.5

Any statutory changes as and when made applicable by the Government shall become
applicable against documentary evidence.

7.6

Payment to the CONTRACTOR/ SERVICE PROVIDER will be subjected to TDS as per
rules in force from time to time. The Tax Deduction at Source (TDS) shall be done as per
the provisions of Income Tax Act & GST, as amended from time to time and a certificate to
this effect shall be provided to the CONTRACTOR/ SERVICE PROVIDER by CNCI.

7.7

Applicable GST shall also be recoverable from the CONTRACTOR/ SERVICE PROVIDER
in case of LD recovery/penalty on account of breach of terms of contract.

7.8

Income tax deductions shall be made from all payments made to the CONTRACTOR/
SERVICE PROVIDER including advances against work done, in accordance with the
Income Tax act prevailing from time to time.
6

<!-- page 12 -->

8)

ESCALATION / PRICE VARIATION
All rates as per Bill of Quantities (BOQ)/Price-Bid quoted by Contractor/ Service Provider
shall be firm and fixed for entire contract period. No claim on account of any Price Variation /
Escalation on whatsoever ground shall be entertained at any stage of works. No
escalation/price variation clause shall be applicable on this contract.

9)

LIQUIDATED DAMAGE (LD)
The time allowed for carrying out the work as entered in the tender shall be strictly
observed by the contractor and shall deemed to be of the essence of the contract on the
part of the contractor and shall be reckoned from the Seventh day after the date on which
the order to commence the work is issued to the contractor. The work shall throughout the
stipulated period of the contract be proceeded with all due diligence and the contractor shall
pay as compensation as amount equal to one percent for each week of delay or part
thereof subject to maximum 10% on the contract value and the decision of the Engineer in
charge in this regard is final.

10) COMPLETION CERTIFICATE
Within ten days of the completion of the work, the Contractor/ Service Provider shall give notice
of such completion to the Engineer-in-Charge and within ten / thirty days of the receipt of such
notice, Engineer-in-Charge shall inspect the work, and if there is no defect in the work, he shall
furnish the Contractor/ Service Provider with a certificate of completion otherwise a provisional
certificate of completion indicating defects to be rectified by the Contractor/ Service Provider
and/or for which payment will be made at reduced rates. No certificate of completion provisional
or otherwise shall be issued nor shall the work be considered to be complete until the
Contractor/ Service Provider shall removes from the premises on which the work shall be
executed all scaffolding surplus materials and rubbish and all huts and sanitary arrangements
required for his/their work people on the site in connection with the execution of the work as
shall have been executed or constructed by the Contractor/ Service Provider (s) and cleaned of
the dirt from all wood work door windows walls floors or other part of any building, in, upon or
about which the work is to be executed or of he may have had possession for the purpose of
the execution thereof, and not until the work shall have been measured by the Engineer-inCharge. If the Contractor/ Service Provider shall fail to comply with the requirements of this
Clause as to removal of scaffolding, surplus materials and rubbish and all hut and sanitary
arrangement as aforesaid and cleaning off dirt or before the date fixed for the completion of the
7

<!-- page 13 -->

work the Engineer-in-Charge may at the cost and expense of the Contractor/ Service Provider
remove such scaffolding, surplus materials and rubbish etc. and dispose of the same as it thinks
fit and clean of such dirt as aforesaid and the Contractor/ Service Provider shall have no claim
against CNCI except for any sum actually realized by the sale thereof.
11) INSURANCE UNDER WORKMEN’S COMPENSATION ACT

Contractor/ Service Provider/Service Provider is required to take insurance cover as per
requirement of the Workmen‟s Compensation Act, 1923 amended from time to time from an
Approved Insurance Company and pay premium charges thereof. Whenever required by
CNCI, the Contractor/ Service Provider shall produce the policy or the policies of Insurance
and the receipt of payment of the current premiums.
12) LABOUR LAWS TO BE COMPLIED WITH BY THE CONTRACTOR/ SERVICE ROVIDER
The Contractor/ Service Provider/Service Provider shall obtain a valid licence under the contract
labour (Regulation Abolition) Act 1970 and the Contract Labour Act (R&A) Central Rules 1971
and amended from time to time, and continue to have a valid licence until the completion of the
work including defect liability period. The Contractor/ Service Provider/Service Provider shall
also abide by the provision of the child labour (Prohibition and Regulation) Act. 1986 and as
amended from time to time. Any failure to fulfill this requirement shall attract the penal
provisions of this contract arising out of the resultant non-execution of the work.
The Contractor/ Service Provider/Service Provider shall comply with the provisions of the
payment of Wages Act, 1936, Minimum Wages Act, 1948, Employer's Liability Act, 1938,
Workmen's Compensation Act, 1923, Maternity Benefit Act, 1961 and Mines Act -1932,
Industrial Disputes Act, 1947 or any modifications thereof or any other law relating thereto and
rules made there under from, time to time.
12.1 No labour below the age of 18 years shall be employed on the work.
13) LABOUR SAFETY PROVISION
The Contractor/ Service Provider/Service Provider shall be fully responsible to observe the
labour safety provisions.
14) OBSERVANCE OF LABOUR LAWS
The Contractor/ Service Provider/Service Provider shall be fully responsible for observance
of all labour laws applicable including local laws and other laws applicable in this matter and
shall indemnify and keep indemnified CNCIagainst effect of non- observance of any such
8

<!-- page 14 -->

laws. The Contractor/ Service Provider/Service Provider shall be liable to make payment to
all its employees, workers and make compliance with labour laws. In case of any default to
the contractor, CNCI is held liable as “Principal Employer” to pay any amount or
contributionsetc. under legislation of Govt. or Court decision in respect of the employees of
the

Contractor/

Service

Provider/Service

Provider,

then

the

Contractor/

Service

Provider/ServiceProvider would reimburse the amount of such payments, contribution etc. to
CNCI and/ or same shall be deducted from the payments, Retention Money etc. of the
Contractor/ ServiceProvider/Service Provider.
15)

LAWS GOVERNING THE CONTRACT

This Contractor/ Service Provider/Service Provider shall be governed by the Indian Laws
for the time being in force and amended from time to time.
16)

LAWS, BYE LAWS RELATING TO THE WORK

The Contractor/ Service Provider/Service Provider shall strictly abide by the provisions, for
the time being in force, of law relating to works or any regulations and bye laws made by
any local authority or any water & lighting agencies or any undertakings within the limits of
the jurisdiction of which the work is proposed to be executed. The Contractor/ Service
Provider/Service Provider shall be bound to give to the authorities concerned such notices
and take all approvals as may be provided in the law, regulations or bye laws as aforesaid,
and to pay all fees and taxes payable to such authorities in respect thereof.
17)

EMPLOYMENT OF PERSONNEL

17.1 The Contractor/ Service Provider shall employ only Indian Nationals as his
representatives, servants and workmen after verifying their antecedents and loyalty. He
shall ensure that no personnel of doubtful antecedents & integrity and any other
nationality in any way are associated with the works.
18.1 a) The contractor/ service provider shall ensure that the persons employed in the work site,

do not engage in trade union activities, picket up, Gherao, raising slogans, putting up
festoons, disrupting the work of the CNCI.
18.2

CNCI shall have full power to get removed immediately any representative, agent,
servant and workmen or employees of the Contractor/ Service Provider/Service Provider
on account of misconduct, negligence or incompetence or whose continued employment
may in the opinion of the Engineer-In-Charge be undesirable without assigning any
9

<!-- page 15 -->

reason for the removal. The Contractor/ Service Provider/Service Provider shall not be
allowed any compensation on this account whatsoever.
18)

TECHNICAL STAFF FOR WORK

The Contractor/ Service Provider shall employ at his cost the adequate number of
technical staff during the execution of this work depending upon the requirement of
work. For this purpose the numbers to be deployed, their qualification, experience as
decided by CNCI shall be final and binding on Contractor/ Service Provider. The
Contractor/ Service Provider shall not be entitled for any extra payment in this regard.
The technical staff should be available at Site, whenever required by CNCI to take
instructions.
19)

WORKMEN’S COMPENSATION ACT

The Contractor/ Service Provider shall at all times indemnify CNCI against all claims for
compensation under the provision of Workmen‟s Compensation Act,1923 or any other
law in force, for any workmen employed by the Contractor/ Service Provider in carrying
out the contract and against all costs and expenses incurred by CNCI therewith.
20 a) The Contractor/ Service Provider shall take all slips to ensure safety of woman workers
against sexual harassment.
20)

MINIMUM WAGES ACT

The Contractor/ Service Provider shall comply with all the provisions of the Minimum
Wages Act, 1948, Contract Labour Act (R&A) 1970, and rules framed there under and
other labour laws/local laws affecting contract labour that may be brought into force from
time to time.
21)

MEASUREMENTS OF WORKS

21.1

Unless otherwise mentioned in the Bill of Quantities the measurements of works shall be
done as per CPWD specifications (as specified in Technical Specification of the Tender)
and if the same is not given in the CPWD Specifications, the same shallbe measured
as per latest relevant BIS codes in force. The quantity of steel reinforcement and the
structural steel sections incorporated in the work shall be measured & paid on the basis
of standard coefficients of sections as per BIS Codes of practice.

10

<!-- page 16 -->

21.2

The Engineer-In-Charge shall accept as otherwise stated ascertain and determine by
measurement the value of work done in accordance with the contract.

21.3

All items having financial value shall be entered in Measurement Book, level book, etc.
prescribed by CNCI so that a complete record is obtained of all work performed under
thecontract. Items of non-financial value (which are not payable) may also be entered in
Measurement Book at the sole discretion of the Engineer-In-Charge.

21.4

Measurements shall be taken jointly by the Engineer-In-Charge or his authorized
representative and by the Contractor/ Service Provider or his authorized representative.

21.5

Before taking measurements of any work the Engineer- In-Charge or the authorized
person deputed by him for the purpose shall give a reasonable notice to the Contractor/
Service Provider. If the Contractor/ Service Provider fails to attend or send an authorized
representative for measurement after such a notice or fails to countersign or to record
the objection within a week from the date of measurement, then in any such event
measurement taken by the Engineer-In-Charge or by the person deputed by him shall
be taken to be correct and final measurements of the work.

21.6

The Contractor/ Service Provider shall, without extra charge provide assistance with
every appliance, labour and other things necessary for measurement.
Measurements shall be signed and dated by both parties each day on the Site on
completion of measurement.

22)

PAYMENTS

22.1

The bill shall be submitted by the Contractor/ Service Provider Quarterly on or before the
date fixed by the ENGINEER-IN-CHARGE for all works executed in previous months.
The Contractor/ Service Provider shall prepare computerized bills using the program as
approved by Engineer-In-Charge as per prescribed format/ pro-forma. The Contractor/
Service Provider shall submit three numbers of hard copies for all bills.

22.2

All payments shall be released by CNCI through RTGS/ BY CHEQUE directly to the
Contractor/ ServiceProvider account.

22.3

No running payment for the bill will be done by CNCI.

23)

WORK TO BE EXECUTED IN ACCORDANCE WITH SPECIFICATIONS,
DRAWINGS, ORDERS, ETC.
The Contractor/ Service Provider shall execute the whole and every part of the work in
11

<!-- page 17 -->

the most substantial and workman like manner both as regards materials, workmanship
and otherwise in every respect in strict accordance with the specifications. The
Contractor/ Service Provider shall also conform exactly, fully and faithfully to the Design,
Drawings and Instructions in writing in respect of the work assigned by the Engineer-InCharge and the Contractor/ Service Provider shall be furnished free of charge one copy
of the Contract Documents together with Specifications, Designs, Drawings.
The Contractor/ Service Provider shall comply with the provisions of the contract and
execute the works with care and diligence and maintain the works and provide all labour
and materials, tools and plants including for measurements and supervision of all works,
structural plans and other things of temporary or permanent nature required for such
execution and maintenance in so far as the necessity for providing these is specified or
is reasonably inferred from the contract. The Contractor/ Service Provider shall take full
responsibility for adequacy, suitability and safety of all the works and methods of
construction.
24)

DIRECTION FOR WORKS

24.1

All works to be executed under the contract shall be executed under the direction and
subject to approval in all respect of the Engineer-In-Charge of CNCI who shall be
entitledto direct at what point or points and in what manner works are to be commenced
and executed.

12

<!-- page 18 -->

24.2

The Engineer-In -Charge and his representative shall communicate or confirm their
instructions to the Contractor/ Service Provider in respect of the execution of work during
their Site inspection in a „Works Site Order Book‟ maintained at the site office of
Engineer-In-Charge. The Contractor/ Service Provider or his authorized representative
shall confirm receipt of such instructions by signing against the relevant orders in the
book. The Contractor/ Service Provider shall be bound to sign the site order book as and
when required by Engineer-In-Charge and carry out compliance of instructions promptly
to the satisfaction of Engineer-In-Charge.

25)

Alterations, in specification and designs
The Engineer-in-Charge shall have power to make any alterations in omissions from
additions to or substitutions or the original specifications, drawings, designs, and instructions,
that may appear to him to be necessary during the progress of the work and the Contractor/
Service Provider shall carry out the work in accordance with any instructions which may be
given to him in writing signed by the Engineer-in-Charge and such alterations, omission,
additions substitutions shall not invalidate the Contract any altered additional or substituted
work which the Contractor/ Service Provider may be directed to do in the manner above
specified as part of the work shall be carried out by the Contractor/ Service Provider on the
same conditions in all respects on which he agreed to do the main work. The time of the
completion of the work shall be extended in the proportion that the altered, additional or
substituted work bears to the original contract work, and the certificate of the Engineer-inCharge shall be conclusive as to such proportion Over and above this a further period to the
extend of 25 percent such extensions shall be allowed to the Contractor/ Service Provider.
The rates for such additional, altered or substituted work under this clause shall be worked
out in accordance with the following provisions in their respective order.
i)

If the rates for the additional, altered or substituted work are specified in the Contractor/
Service Provider for the work, the Contractor/ Service Provider is bound to carry out the
additional, altered or substituted work at the same rates as are specified in the contract
for the work.

ii)

If the rates for the additional altered substituted work are not specifically provided in the
contract for the work, such rates will be derived from the rates for a similar class of work
as are specified in the contract for the work.

iii)

If the altered additional or substituted work includes any work which no rates is specified
in the contract for the work and cannot be derived from the similar class of work in the
13

<!-- page 19 -->

contract, than such work shall be carried out at the rates entered in CPWD Schedule of
Rates in operation minus / plus percentage which the tenderedamount of the concerned
component work bears to the concerned component estimatedcost of the entire work put
to tender.
iv)

If the rates of the altered additional or substituted work cannot be determined in the
manner specified in the sub-clauses (i) to (iii) above than the rates for such work shall be
worked out on the basis of the concerned Schedule of Rates of the District specified
above minus plus the percentage which the tendered amount of the concerned
component work bears to the estimated cost the concerned component work put to
tender. Provided always that if the rate for a particular part or parts of the item is not in
the Schedule of Rates, the rate for such part or parts will be determined by the
Engineer-in-Charge on the basis of the prevailing market rates when the work was done.

v)

It the rates for the altered, additional or substituted work cannot be determined in the
manner specified in sub-clause (i) to (iv) above, then the contract shall within 7 days of
the date of receipt of order to carry out the work inform the Engineer-in-Charge of the
rate which it is his intention to Charge for such class of the work supported by analysis
of the basis of prevailing market rates. However, the Engineer-in-Charge, by notice in
writing will be liberty to carry out assessment of such class of work and arrange to carry
it out in such manner as he may consider advisable. But under no circumstances, the
Contractor/ Service Provider shall suspend the work on the place of non-settlement of
rates of items falling under the clause.

26)

DEFECTS LIABILITY PERIOD

The Contractor/ Service Provider shall be responsible for the rectification of defects in
the works for a period of 18 months from the date of taking over of the works by the
Owner/ Client. Any defects discovered and brought to the notice of the Contractor/
Service Provider forthwith shall be attended to and rectified by him at his own cost and
expense. In case the Contractor/ Service Provider fails to carry out these rectifications,
the same may without prejudice to any other right or remedy available, be got rectified
by CNCI at the cost and expense of the Contractor/ Service Provider.
27)

ARBITRATION

27.1

Before resorting to arbitration as per the clause given below, the parties if they so agree
may explore the possibility of conciliation as per the provisions of Part- III of the

14

<!-- page 20 -->

Arbitration and Conciliation Act. 1996. When such conciliation has failed, the parties
shall adopt the following procedure for arbitration:
Except where otherwise provided for in the contract, any disputes and differences
relating to the meaning of the Specifications, Design, Drawings and Instructions herein
before mentioned and as to the quality of workmanship or materials used in the work or
as to any other question, claim, right, matter or thing whatsoever in any way arising out
of or relating to the Contract, Designs, Drawings, Specifications, Estimates, Instructions,
or these conditions, or otherwise concerning the works or the execution or failure to
execute the same whether arising during the progress of the work or after the
completion or abandonment thereof shall be referred for arbitration to the Sole
Arbitration of the Director of CNCI, or any other person discharging the functions of
DIRECTOR of CNCI and if DIRECTOR or such person discharging the functions of
DIRECTOR of CNCI is unable to act, to the sole Arbitration, some other person
appointed by DIRECTOR of CNCI or such other person discharging the functions of
DIRECTOR of CNCI shall act and function as sole Arbitrator and the award thereof
passed shall be binding.
28)

TERMINATION OF CONTRACT ON DEATH OF CONTRACTOR/ SERVICE PROVIDER

If the Contractor/ Service Provider is an individual or a proprietorship concern and the
individual or the proprietor dies then unless the Engineer-In-Charge is satisfied that the
legal representatives of the individual Contractor/ Service Provider or of the proprietor of
the proprietary concern and in the case of partnership firm, the surviving partners, are
capable of carrying out and completing the contract, CNCI shall be entitled to cancel the
contract as to its in completed part without CNCI being in any way liable to payment of
any compensation to the estate of the deceased Contractor/ Service Provider and/or to
surviving partners of the Contractor/ Service Provider‟s firm on account of cancellation of
the contract. Such cancellation of Contract shall be without prejudice to any of the rights
& remedies available to CNCI under the contract. The decision of CNCI that the legal
representatives of the deceased Contractor/ Service Provider or the surviving partners of
the Contractor/ Service Provider‟s firm cannot carry out and complete the contract shall
be final and binding on the parties.

15

<!-- page 21 -->

29)

CLARIFICATION AFTER TENDER SUBMISSION

Tenderer‟s attention is drawn to the fact that during the period, the bids are under
consideration, the bidders are advised to refrain from contacting by any means, CNCI
and/or his employees/ representatives on matters related to the bid under consideration
and that if necessary, CNCI will obtain clarifications in writing or as may be necessary.
The Tender evaluation and process of award of works is done by duly authorized
Tender Scrutiny Committee and this committee is authorized and competent to discuss
and get clarification from the tenderers.
30)

ADDENDA/ CORRIGENDA

Addenda/Corrigenda to the Tender Documents may be issued prior to the date of
opening of the Tender to clarify or effect modification in specification and/or contract
terms included in various Tender Documents. The tenderer shall suitably take into
consideration such Addenda/Corrigenda while submitting his tender. The tenderer shall
return such Addenda/ Corrigenda duly signed and stamped as confirmation of its receipt
and submit along with the Tender Document. All Addenda/ Corrigenda shall be signed
and stamped on each page by the tenderer and shall become part of the Tender and
contract documents.

31)

Performance Security:

There will be a performance security deposit amounting to the total value excluding
taxes, which shall be submitted by the successful tenderer to the Tender Inviting
Authority within 10 days from the date of issuance of “Letter of Intent”/ Purchase Order.

32)

PBG:

Performance Bank Guarantee of @5% of PO value is applicable in this tender.

16

<!-- page 22 -->

LABOUR SAFETY PROVISIONS
1.0

Suitable scaffolds should be provided for workmen for all works that cannot safely be
done from the ground, or from solid construction except such short period work as can
be done safely from ladders. When a ladder is used an extra mazdoor shall be engaged
for holding the ladder and if the ladder is used for carrying materials as well, suitable
footholds and handholds shall be provided on the ladder and the ladder shall be given
an inclination not steeper than 1/4 to 1 (1/4 horizontal and 1 vertical).

2.0 Scaffolding or staging more than 3.6m (12 feet) above the ground or floor, swung or
suspended from an overhead support or erected with stationery support shall have a
guard rail properly attached or bolted, braced and otherwise secured at least 90 cm. (3
feet) high above the floor or platform of such scaffolding or staging and extending along
the entire length of the outside and ends thereof with only such opening as may be
necessary for the delivery of materials. Such scaffolding or staging shall be fastened and
secured to prevent it from swaying from the building or structure.
3.0 Working platforms, gangways, and stairways should be so constructed that they should not
sag unduly or unequally, and if the height of the platform or the gangway or the stairway
is more than 3.6m (12 feet) above ground level or floor level, they should be closely
boarded, should have adequate width & should be suitable fastened as described in
(2.0) above.
4.0 Every opening in the floor of a building or in a working platform shall be provided with
suitable means to prevent the fall of persons or materials by providing suitable fencing or
railing whose minimum height shall be 90 cm (3 feet).
5.0

Safe means of access shall be provided to all working platforms and other working
places. Every ladder shall be securely fixed. No portable single ladder shall be over 9m.
(30 feet) in length while the width between side rails in rung ladder shall in no case be
less than 29 cm. for ladder up to and including 3m (10 feet) in length. For longer ladders
this width should be increased at least 1/4” for each additional 30 cm (1 ft.) of length.
Uniform step spacing shall not exceed 30 cm (12”). Adequate precautions shall be taken
to prevent danger from electrical equipment. No materials on any of the sites of the work
shall be so stacked or placed as to cause danger or inconvenience to any person or the
public. The Contractor/ Service Provider shall provide all necessary warnings, fencing
and lights to protect the public from accident, and shall be bound to bear the expenses
of defence of every suit, action or other proceeding at law that may be brought by an
17

<!-- page 23 -->

person for injury sustained owing to neglect of the above precautions and to pay any
damages and cost which may be awarded in any such suit, action or proceedings to any
such person or which may, with the consent of the Contractor/ Service Provider, be paid
to compensate any claim by any such person.
6.0

EXCAVATION AND TRENCHING

All trenches, 1.2mts.(four feet) or more in depth, shall at all times be supplied with at least one
ladder for each 30m. (100 feet) in length or fraction thereof, Ladder shall be extended
from bottom of the trench to at least 90 cm (3feet) above the surface of the ground. The
sides of the trenches, which are 1.5m. (5feet) or more in depth shall be stepped back to
give suitable slope or securely held by timber bracing, so as to avoid the danger or
sides to collapsing. The excavated materials shall not be placed within 1.5m (5 feet) of
the edges of the trench or half of the depth of the trench whichever is more. Cutting shall
be done from top to bottom. Under no circumstances undermining or undercutting shall
be done

7.0

DEMOLITION
Before any demolition work is commenced and also during the progress of the work:

7.1

All roads and open areas adjacent to the work Site shall either be closed or suitably
protected and signage of work in progress shall put up for display.

7.2

No electric cable or apparatus which is likely to be a source of danger or a cable or
apparatus used by the operator shall remain electrically charged.

7.3

All practical steps shall be taken to prevent danger to persons employed from risk or fire
or explosion or flooding. No floor, roof or other part of the building shall be overloaded
with debris or materials as to render it unsafe.

8.0

All necessary personal safety equipments as considered adequate by the Engineer-InCharge and experts should be kept available for the use of persons employed on the
Site and maintained in a condition suitable for immediate use, and the Contractor/
Service Provider should take adequate step to ensure proper use of equipment by those
concerned- The following safety equipment shall be invariably provided.

8.1

Workers employed on mixing asphaltic materials, cement and lime mortars shall be
provided with protective footwear and protective goggles.
18

<!-- page 24 -->

8.2

Those engaged in white washing and mixing or stacking of cement bags or any
materials which are injurious to the eye shall be provided with protective goggles.

8.3

Those engaged in welding works shall be provided with welder‟s protective eye shields.

8.4

Stone breakers shall be provided with protective goggles and protective clothing and
seated at sufficiently safe interval.

8.5

When workers are employed in sewers and manholes, which are in active use, the
Contractor/ Service Providers shall ensure that the manhole covers are opened and
ventilated at-least for an hour before the workers are allowed to get into the manholes,
and the manholes so opened shall be cordoned off with suitable railing and provided
with warning signals or boards to prevent accident the public. In addition, the Contractor/
Service Provider shall ensure that the following safety measures are adhered to:
a.

Entry for workers into the line shall not be allowed except under supervision of
the JE or any other higher officer.

19

<!-- page 25 -->

b.

At least 5 to 6 manholes upstream and down stream should be kept open for at
least 2 to 3 hours before any man is allowed to enter into the manholes for
working inside.

c.

Before entry, presence of Toxic gases should be tested by inserting wet lead
acetate paper which changes colour in the presence of such gases and gives
indication of their presence.

d.

Presence of Oxygen should be verified by lowering a detector lamp into the
manhole. In case, no Oxygen is found inside the sewer line, workers should be
sent only with Oxygen kit.

e.

Safety belt with rope should be provided to the workers. While working
inside the manholes such rope should be handled by two men standing
outside to enable him to be pulled out during emergency.

f.

The area should be barricaded or cordoned of by suitable means to avoid
mishaps of any kind. Proper warning signs should be displayed for the safety of
the public whenever cleaning works are undertaken during night or day.

g.

No smoking or open flames shall be allowed near the blocked manhole being
cleaned.

h.

The malba obtained on account of cleaning of blocked manholes and sewer lines
should be immediately removed to avoid accidents on account of slippery nature
of the malba.

i.

Workers should not be allowed to work inside the manhole continuously. He
should be given rest intermittently.

j.

Gas masks with Oxygen Cylinder should be kept at Site for use in emergency.

k.

Air-blowers should be used for flow of fresh air through the manholes. Whenever
called for, portable air-blowers are recommended for ventilating the manholes.
The Motors for these shall be vapour proof and of totally enclosed type. Nonsparking gas engines also could be used but they should be placed at-least 2
meters away from the opening and on the leeward side protected from wind so
that they will not be a source of friction on any inflammable gas that might be
present.

20

<!-- page 26 -->

l.

The workers engaged for cleaning the manholes/ sewers should be properly
trained before allowing them to work in the manhole. m. The workers shall be
provided with Gumboots or non-sparking shoes, bump helmets and gloves nonsparking tools, safety lights and gas masks and portable air blowers (when
necessary). They must be supplied with barrier cream for anointing the limbs
before working inside the sewer lines.

m.

Workmen descending a manhole shall try each ladder step or rung carefully
before putting his full weight on it to guard against insecure fastening due to
corrosion of the rung fixed to manhole well.

n.

If a man has received a physical injury, he should be brought out of the sewer
immediately and adequate medical aid should be provided to him.

o.

The extent to which these precautions are to be taken depend on individual
situation but the decision of the Engineer-In-Charge regarding the steps to be
taken in this regard in an individual case will be final.

8.6

The Contractor/ Service Provider shall not employ minor men and women below the age
of 18 years on the work of painting with products containing lead in any form wherever
men above the age of 18 are employed on the work of lead painting the following
precautions should be taken.

8.6.1 No paint containing lead or lead products shall be used except in the form of paste or
readymade paint.
8.6.2 Suitable facemasks should be supplied for use by the workers when paint is applied in
the form of spray or a surface having lead paint is dry rubbed and scrapped.
8.6.3 Overall shall be supplied by the Contractor/ Service Provider to the workmen and
adequate facilities shall be provided to enable the working painters to wash during the
cessation of work.
8.6.4.1 a.

White lead, sulphate or lead work products containing those pigments shall not
be used in painting operation except in the form of paste or of paints ready for
use.

c.

Measures shall be taken whenever required in order to prevent danger arising
from the application of paint in the form of spray.

21

<!-- page 27 -->

d.

Measures shall be taken, whenever practicable to prevent danger arising out of
dust caused by dry rubbing down and scrapping.

8.6.4.2 a. Adequate facilities shall be provided to enable working painter to wash during
and on cessation of work.
b.

Suitable arrangements shall be made to prevent clothing put off during working
hours being spoiled by painting materials.

8.6.4.3 a)

Cases of lead poisoning and of suspected lead poisoning shall be notified and
shall be subsequently verified by a medical man appointed by the competent
authorities of the Consultant.

b)

CNCI may require when necessary a medical examination of workers.

c)

Instructions with regard to the special hygienic precautions to be taken in the
painting trade shall be distributed to working painters.

9.0 When the work is done near any place where there is risk of drowning, all necessary
equipments should be provided and kept ready for use and all necessary steps taken for
prompt rescue of any person in danger and adequate provisions should be made for
prompt first aid treatment of all injuries likely to be obtained during the course of the
work.
10.0 Use of hoisting machines and tackle including their attachment encourage and supports
shall conform to the following standard of conditions.
10.1 a)

These shall be of good mechanical construction, sound material and
adequate strength and free from patent, defects and shall be kept
required in good working order.

b)

Every rope used in hoisting or lowering materials or as a means of suspension
shall be of durable quality and adequate strength, and free from patent defects.

10.2

Every crane driver or hoisting appliance operator shall be properly qualified and no
person under the age of 21 years should be in-charge of any hoisting machine including
any scaffolding, winch or giving signals to operator.

10.3

In case of every hoisting machine and of every chain ring hook, shackle swivel and
pulley block used in hoisting or as means of suspension the safe working load shall be
ascertained by adequate means. Every hoisting machine and all gear referred to above
22

<!-- page 28 -->

shall be plainly marked with the safe working load. In case of a hoisting machine having
a variable safe working load, each safe working load and the conditions under which it is
applicable shall be clearly indicated. No part of any machine or any gear referred to
above in this paragraph shall be loaded beyond the safe working load except for the
purpose of testing.
10.4

In case of machines provided by CNCI, the safe working load shall be notified by the
Engineer-In-Charge. As regards Contractor/ Service Provider‟s machines the Contractor/
Service Provider shall notify the safe working load of the machine to the Engineer-InCharge whenever he brings his machines to Site of work and get verified by the
Engineer-In-Charge.

11.0 The Contractor/ Service Providers must ensure and satisfy itself the motors gearing,
transmission electric wiring and other dangerous parts of hoisting appliances is provided
with efficient safeguard, hosting appliances with such means as will reduce to the
minimum the risk of accidental descent of the load. Adequate precautions should be
taken to reduce the minimum the risk of any part of a suspended load becoming
accidentally displaced. When workers are employed on electrical installations, which are
already energized, insulating mats, wearing apparel, such as gloves sleeves and boots
as may be necessary, be provided. The worker should not wear any rings, watches and
carry keys or other materials, which are good conductors of electricity.
12.0 The Contractor/ Service Providers must ensure all scaffolds, ladders, and other safety
devices mentioned or described herein shall be maintained in safe condition and no
scaffold ladder or equipment shall be altered or removed while it is in use. Adequate
washing facilities should be provided at or near places of work.
13.0

Safety provisions are brought to the notice of all concerned by display on a notice board
at a prominent place of work spot. The person responsible for compliance of the safety
codes shall be named therein by the Contractor/ Service Provider.

14.0 To ensure effective enforcement of the rules and regulations relating to safety
precautions the arrangements made by the Contractor/ Service Provider shall be open
to inspection by the or their representatives.
15.0 Notwithstanding the above Clauses from (i) to (xiv) there is nothing in these to exempt
the Contractor/ Service Provider from the operations of any other Act or Rule in force in
the Republic of India.
23

<!-- page 29 -->

16.0 Material shall not be thrown from the height. If required, the area shall be barricaded and
one person shall be posted outside the barricading for preventing the trespassers from
entering the area.
17.0 Other than electricians no one is allowed to carry out electrical connections, repairs on
electrical equipment or other jobs related thereto. Inserting of bare wires fortapping the
power from electrical sockets is completely prohibited.
18.0 All underground cables for supplying construction power shall be routed using conduit pipes.
Tapping of power by cutting electric cables in between must be avoided. Proper junction
boxes must be used.

MODEL RULES FOR THE PROTECTION OF HEALTH AND
SANITARY ARRANGEMENTS FOR WORKERS
The Contractor/ Service Provider shall abide by the model rules set out hereunder:
1.0

APPLICATION

These rules shall apply to all building and construction works in which 20 (twenty) or
more workers are ordinarily employed or are proposed to be employed in any day during
the period during which the Contractor/ Service Provider work is in progress.
2.0

DEFINITION

Work place means a place where twenty or more workers are ordinarily employed or are
proposed to be employed in connection with construction work on any day during the
period during which the Contractor/ Service Provider work is in progress.
3.0

FIRST-AID FACILITIES

3.1

At every work place first aid facilities shall be provided and maintained, so as to be
easily accessible during working hours, First-Aid boxes at the rate of not less than one
box per 150 contract labour or part thereof ordinarily employed.

3.2

The First-Aid box shall be distinctly marked with a red cross on white ground and shall
contain the following equipments:-

24

<!-- page 30 -->

3.2.1 a)

For work places in which number of contract labour employed does not
exceed 50, Each First-Aid box shall contain the following equipments:

3.3

i)

6 small sterilized dressings.

ii)

3 medium size sterilized dressings.

iii)

large size sterilized dressings.

iv)

3 large sterilized burn dressings.

v)

1 (30 ml) bottle containing a two percent alcoholic solution of iodine.

vi)

1(30 ml) bottle containing salvolatile having the dose and mode of
administration indicated on the label.

vii)

1 snake-bite lancet.

viii)

1 (30 gms) bottle of potassium permanganate crystals.

ix)

1 pair of scissors.

x)

1 copy of the First-Aid leaf-let issued by the Director General, Factory
Advise Service & Labour Institutes, Government of India.

xi)

1 bottle containing 100 tablets (each of 5 grams) of aspirin.

xii)

Ointment for burns.

xiii)

A bottle of suitable surgical antiseptic solution.

Adequate arrangements shall be made for immediate recoupment of the equipment
when necessary.

3.4

Nothing except the prescribed contents shall be kept in the First Aid box.

3.5

The First Aid box shall be kept in charge of a responsible person who shall always be
readily available during the working hours of the work place.

4.0

DRINKING WATER

4.1

In every work place, there shall be provided and maintained at suitable places, easily
accessible to labour, a sufficient supply of cold water fit for drinking.

4.2

Where drinking water is obtained from an intermittent public water supply, each work
place shall be provided with storage where such drinking water shall be stored.

4.3

Every water supply of storage shall be at a distance of not less than 50 feet from any
latrines drain or other source of pollution, where water has to be drawn from an existing
well which is within such proximity of latrine, drain or any other source of pollution, the
well shall be properly chlorinated before water is drawn from it for drinking. All such wells
25

<!-- page 31 -->

shall be entirely closed in and be provided with a trap-door which shall be dust and
waterproof.
4.4

A reliable pump shall be fitted to each covered well, trap-door shall be kept locked and
opened only for cleaning or inspection which shall be done at least once a month.

5.0

ANTI MALARIAL PRECAUTIONS

The Contractor/ Service Provider shall at his own expense, conform to all anti-malarial
instructions given to him by the Engineer- In-Charge including the filling up of any
borrows pits which may have been dug by him.
6.0
AMENDMENTS
CNCI may from time to time, add to or amend these rules and issue such directions as it may consider
necessary for the purpose of removing any difficulty which may arise in the administration

26

<!-- page 32 -->

Detail BOQ for Modification work of 1st floor laboratory of CNCI 2nd campus.
SLNo.
1

2

3

4

5

6

7

8

9

10
11
12
13
14
15

16

17

Description of Work
Wall painting with premium acrylic emulsion paint of interior grade, having VOC content less than
50 grams/lit of approved brand and manufacture to give an even shade including applying
additional coats wherever required to achieve even shade and color: Two coats (Asian
Royale/Berger Silk/Equivalent)
Applying priming coats with primer of approved brand and manufacture, having low VOC (Volatile
Organic Compound ) content. With water thinnable cement primer on wall surface having VOC
content less than 50 grams/litre
Removing dry or oil bound distemper, water proofing cement paint and the like by scrapping, sand
papering and preparing the surface smooth including necessary repairs to scratches etc.
complete.
Dismantling aluminum/ Gypsum partitions, doors, windows, fixed glazing and false ceiling
including disposal of unserviceable material and stacking of serviceable material with in 50 meters
lead as directed by Engineer-in-charge. (As per CPWD Specification). After removing the old false
ceiling materials contractor have to remove the rubbish outside of CNCI premises.
Providing and fixing false ceiling with 12.5 mm thick tapered edge gypsum moisture resistant
board (As per CPWD Specifications)
Table making with 19mm thick Marine plywood (century/green) and 1.0mm thick laminate
(century/green/merino) finish as per users choice. Invisible portion of table and drawer may be
finished with 0.8mm thick white or off white laminate. The table should have keyboard drawer and
side drawer with locker provisions. The top of the table will be 750mm wide and height of table as
per standard or users choice. Mode of Measurement of Table will be as per the Top measurement
only.
Providing and fixing aluminium work for doors, windows, ventilators and partitions with extruded
built up standard tubular sections/ appropriate Z sections and other sections of approved make
conforming to IS: 733 and IS: 1285, fixing with dash fasteners of required dia and size, including
necessary filling up the gaps at junctions, i.e. at top, bottom and sides with required EPDM
rubber/ neoprene gasket etc. Aluminium sections shall be smooth, rust free, straight, mitred and
jointed mechanically wherever required including cleat angle, Aluminium snap beading for glazing
/ paneling, C.P. brass / stainless steel screws, all complete as per architectural drawings and the
directions of Engineer-in-charge. (Glazing, paneling and dash fasteners to be paid for separately)
: For fixed portion Powder coated aluminium (minimum thickness of powder coating 50 micron)
For Shutters of Doors, windows and ventilators including providing and fixing hinges/pivots and
making provision for fixing of fittings whereever required including the cost of EPDM rubber/
neoprene gasket required (No Extra payment for sliding fittings instead of plain hinges if required)
Powder coated aluminium (minimum thickness of powder coating 50 micron)
Providing and fixing glazing in aluminium door, window, ventilator shutters and partitions etc. with
EPDM rubber / neoprene gasket etc. complete as per the architectural drawings and the
directions of engineer-in-charge . With float glass panes of 5 mm thickness (weight not less than
12.50 kg/sqm)
Providing and fixing 12 mm thick prelaminated particle board flat pressed three layer or graded
wood particle board conforming to IS: 12823 Grade l Type ll, in panelling fixed in aluminum doors,
windows shutters and partition frames with C.P. brass / stainless steel screws etc. complete as
per architectural drawings and directions of engineer-in-charge.
Granite Fixing with moulding at table top
Supply and fixing 12mm toughened glass of size (600X370) with all fittings for Shelves
2X2.5 Sqmm with 1 No. 2.5 sqmm PVC FRLS insulated, copper conductor for earthing. (For
Lighting and Subcircuit)
2X4 Sqmm with 1 No. 4 sqmm PVC insulated FRLS copper conductor for earthing. (For Submain)
Supplying and fixing suitable Module GI box in recess including providing and fixing 3 pin 5/6
amps. modular socket outlet with shutters and 5/6 amps. modular type switch with indicator type,
base plate, modular cover plate, connections etc. and all civil works 'complete as required.
Supplying drawing, connecting and testing of 0.5mm dia
annealed copper conductor
PVC insulated PVC sheathed telephone Wire/cables in recessed PVC conduit or a racks as
required.
2 pair Telephone cable. (0.5 mm)
Supply, fixing, connecting and testing of telephone modular sockets modular plate anodised
MS box and blanking plate in surface / recessed including connectionetc as required.
Telephone socket outlet (RJ-11 telephone Jack Single with Shutter)

27 of
2

Unit

Approx.
Qnty

Sqm

60.00

Sqm

60.00

Sqm

60.00

Sqm

30.00

Sqm

30.00

Sqft

86.00

Kg

75.00

Kg

45.00

Sqm

6.00

Sqm

36.00

Sqm
Nos

3.00
3.00

Metre

30

Metre

40

Each

2

Meter

50

Each

2

<!-- page 33 -->

CHECK LIST OF THE DOCUMENTS TO BE SUBMITTED WITH THE TENDER
(on Company’s Letter Head)
Confirm the enclosure of all the below listed man d at or y documents without which tenderer
may not be eligible to participate in the tender.

Sl
No.

Confirm
(Strike off
whichever not
applicable)

Item

1
2
3

Letter of Undertaking for acceptance of tender conditions
Original Demand Draft for Earnest Money
The firm should have at least 3 years and more experience in similar kind of
job. Suitable documentary evidence (Work Order/performance
certificate/agreements / any documentary evidence in support of their work
experience.) is to be submitted along with the Tender application.

Yes/No
Yes/No
Yes/No

4
5

The self-attested copy of Notice Inviting Tender.
Banker’s Certificate from a Scheduled Bank for Solvency. Solvency Certificate
is to be submitted from a scheduled bank for an amount not less than
Rs.1 crore. The Banker should be any of the scheduled Banks as per RBI Act.
EPF, ESIC Registration Certificate.

Yes/No
Yes/No

Bidder should not have been blacklisted by any Central/State/Govt. agency
and submit an undertaking on an affidavit on a Non-judicial stamp paper of
Rs.100/- in this respect.
Photocopy of Valid Trade License
Photocopy of GST Registration Certificate and latest return (GSTR 1)
Photocopy of Permanent Account Number
Photocopy of Income Tax Return (Acknowledgement) for last three
assessment years.

Yes/No

Photocopy of Audited Balance sheet of the bidder as per ITCC or Profit & loss
statement for last 3 year.
The self-attested copy of General Conditions Of Contract.
Acceptance of Warranty/Defect Liability Period Clause as per GCC
The vendors should have support/service center in Kolkata with valid
certificate from WB.

Yes/No

6
7
8
9
10
11
12
13
14
15

Yes/No

Yes/No
Yes/No
Yes/No
Yes/No

Yes/No
Yes/No
Yes/No

Date:
Place:
Signature of Authorized Person
Full name:
Company's seal:

<!-- page 34 -->

LETTER OF UNDERTAKING
(On Company letter head)

To,
The Director
Chittaranjan National Cancer Institute,
Street No 299, DJ-01, AA-1D, Newtown, Rajarhat, Kolkata-700160

REF: e-Tender for …………………………………………………….

Sir,
UNDERTAKING FOR ACCEPTANCE OF TENDER CONDITIONS

1.

The Tender Documents for the work have been issued to me / us by Chittaranjan National
Cancer Institute and I / We hereby unconditionally accept the tender conditions and
Tender Documents in its entirety for the above

2.

The contents of clauses of the Tender Documents have been noted wherein itis clarified
that after unconditionally accepting the tender conditions in its entirety and the same has
been followed in the present case. In case this provision of the Tender is found violated at
any time after opening “Price Bid”, I / We agree that my/our tender shall be summarily
rejected and CNCI shall, without prejudice to any other right or remedy be at liberty to
forfeit the full said Earnest Money absolutely.

3.

The required Earnest Money for this work is enclosed herewith.
Yours faithfully,
(Signature of the Tenderer)
Seal of Tenderer
Dated:

<!-- page 35 -->

BID SECURITY DECLARATION CERTIFICATE
(AS PER APPLICABILITY)
To
The Director,
Chittaranjan National Cancer Institute,
Street No 299, DJ-01, AA-1D, Newtown, Rajarhat, Kolkata-700160
Reference: Tender Document No.

_ Tender Title:

Sir/ Madam
We, the undersigned, solemnly declare that:

1.

2.

We understand that according to the conditions of this Tender Document, the bid must be supported
by a Bid Securing Declaration in lieu of Bid Security. We unconditionally accept the conditions of this
Bid Securing Declaration. We understand that we shall stand automatically suspended from being
eligible for bidding in any tender in Procuring Organisation for 2 years from the date of opening of this
bid if we breach our obligation(s) under the tender conditionsif we:-

(a)

Withdraw/ amend/ impair/ derogate, in any respect, from our bid, within the bid
validity; OR being notified within the bid validity of the acceptance of our bid by the
Procuring Entity.

(b)

Refused to or failed to produce the original documents for scrutiny or the required
Performance Security within the stipulated time under the conditions of the Tender
Document (where applicable).

(c)

Fail or refuse to sign the contract.

We know that this bid-Securing Declaration shall expire if the contract is not awarded to us, upon:

(a)
(b)
(c)
(d)

Receipt by us of your notification.
Of cancellation of the entire tender process or rejection of all bids or
Of the name of the successful bidder or
Forty-five days after the expiration of the bid validity or any extension to it.

(Signature with date)
………………………..
(Name and designation)
Duly authorized to sign bid for and on behalf of……………………….
[name & address of Bidder and seal of company]
Dated on …………. day of
[insert date of signing]
Place… [ insert place of signing]
DATE:………………………………………………

Signature Not Verified
Digitally signed by SANKAR SENGUPTA
Date: 2024.12.10 14:53:48 IST
Location: eProcure-EPROC
