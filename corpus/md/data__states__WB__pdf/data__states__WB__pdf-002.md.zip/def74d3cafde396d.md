---
doc_id: "def74d3cafde396d"
source_url: "https://home.wb.gov.in/public/assets/frontend/pdf/ais_discipline_and_appeal_rules.pdf"
ministry: "Home and Hill Affairs Department, West Bengal"
title: "0 4  AIS DISCIPLINE AND APPEAL RULES"
date: ""
pages: 63
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "10394eaeeb35b966"
---

<!-- page 1 -->

12. 1THE ALL INDIA SERVICES (DISCIPLINE AND
APPEAL) RULES, 1969
In exercise of the powers conferred by sub-section (I) of Section 3 of the All India
Services Act, 1951 (61 of 1951), the Central Government, after consultation with the
Governments of the States concerned, hereby makes the following rules, namely:—
1. Short title and commencement.—
1(1) These rules may be called the All India Services (Discipline and Appeal)
Rules, 1969.
1(2) They shall come into force on the date of their publication in the Official
Gazette.
2. Definitions.— In these rules, unless the context otherwise requires:—
2(a)
2(b)

‘Commission’ means the Union Public Service Commission;
‘disciplinary authority’ means the authority competent under these rules to
impose on a member of the service any of the penalties specified in rule 6;

2

2(c) ‘Government’ means—
(i)

in the case of a member of the Service serving in connection with the
affairs of a State, or who is deputed for service in any company,
association or body of individuals whether incorporated or not, which is
wholly or substantially owned or controlled by the Government of a
State, or in a local authority set up by an Act of the Legislature of a
State, the Government of that State;

(ii)

in any other case, the Central Government;

3

2(d) member of the service means a member of an All India Service as defined
in Section 2 of the All India Services Act, 1951 (61 of 1951).
4

(dd)

‘Probationer’ means a person appointed to the Service on probation;

2(e) ‘State Government concerned’ in relation to a joint cadre, means the
Government of all the States for which the joint cadre is constituted and
includes the Government of a State nominated by the Government of all
such States to represent them in relation to a particular matter.
PART II—SUSPENSION
3. Suspension.—
(1) If, having regard to the circumstances in any case and, where articles of
charge have been drawn up, the nature of the charges, the Government of a
State or the Central Government, as the case may be, is satisfied that it is
necessary or desirable to place under suspension a member of the Service,
1

Principal rules were published vide Notification No. 7/15/63-AIS-II dt. 20.3.1969
Substituted vide DP&AR Notification No. 6/9/72-AIS-III dt. 5.7.1975 (GSR No. 872, dt. 19.7.1975)
3
Substituted vide DP&AR Notification No. 31/7/72-AIS-III dt. 22.5.1972.
4
Inserted vide DP&AR Notification No. 11018/4/76-AIS(III), dt. 25.2.1977 (GSR No. 358 dt. 19.3.1977)
2

263

<!-- page 2 -->

against whom disciplinary proceedings are contemplated or are pending,
that Government may—
(a)

if the member of the Service is serving under that Government, pass an
order placing him under suspension, or

(b)

if the member of the Service is serving under another Government
request that Government to place him under suspension, pending the
conclusion of the disciplinary proceedings and the passing of the final
order in the case.
Provided that, in cases, where there is a difference of opinion,—
(i)

between two State Governments, the matter shall be referred to
the Central Government for its decision ;

(ii)

between a State Government and the Central Government, the
opinion of the Central Government shall prevail:

5

Provided further that the Chief Secretary, Director General of Police and the
Principal Chief Conservator of Forests, who are the heads of the respective
Services, shall not be placed under suspension without obtaining prior
approval of the Central Government:.
6

Provided also that, where a State Government passes an order placing
under suspension a member of the Service against whom disciplinary
proceedings are contemplated, such an order shall not be valid unless,
before the expiry of a period of forty-five days from the date from which the
member is placed under suspension, or such further period not exceeding
forty-five days as may be specified by the Central Government for reasons
to be recorded in writing, either disciplinary proceedings are initiated against
him or the order of suspension is confirmed by the Central Government.
7

(1A) If the Government of a State or the Central Government, as the case
may be, is of the opinion that a member of the Service has engaged himself
in activities prejudicial to the interests of the security of the State, that
Government may—

(a)

if the member of the Service is serving under that Government, pass an
order placing him under suspension, or

(b)

if the member of the Service is serving under another Government,
request that Government to place him under suspension, till the
passing of the final order in the case:
Provided that, in cases, where there is a difference of opinion—
(i)

between two State Governments, the matter shall be referred to
the Central Government for its decision;

(ii)

between a State Government and the Central Government, the
opinion of the Central Government shall prevail.

5

Substituted vide Notification No. 11018/3/97-AIS-III, dt. 13.7.1998 (GSR No. 130 dt. 25.7.1998) and again substituted
vide Notification No.11018/3/2004-AIS-III dt.30.09.2009 (GSR No.714(E) dt. 30.09.2009)
6
Substituted vide Notification No.11018/3/2004-AIS-III dt.30.09.2009 (GSR No.714(E) dt. 30.09.2009)
7
Deleted/inserted/substituted vide DP&AR Notification No. 6/9/72-AIS-III, dt. 5.7.1975 (GSR No. 872,dt. 19.7.1975)

264

<!-- page 3 -->

8

(1B) The period of suspension of a member of the Service on charges other
than corruption shall not exceed one year and the inquiry shall be completed
and appropriate order shall be issued within one year from the date of
suspension failing which the suspension order shall automatically stand
revoked:
Provided that the suspension can be continued beyond one year only on
the recommendations of the Central Ministry’s Review Committee:
Provided further that the period during which the disciplinary proceedings
remain stayed due to orders of a Court of Law, shall be excluded from this
limit of one year.

9

(1C) The period of suspension of a member of the Service on charges of
corruption shall not exceed two years and the inquiry shall be completed and
appropriate order shall be issued within two years from the date of
suspension failing which the suspension order shall automatically stand
revoked:
Provided that the suspension can be continued beyond two years only on
the recommendations of the Central Ministry’s Review Committee:
Provided further that the period during which the disciplinary proceedings
remain stayed due to orders of a Court of Law, shall be excluded from this
limit of two years.
10

(1D) The composition and functions of the Central Ministry’s Review
Committee and the procedure to be followed by them shall be as specified
in Schedule 2 annexed to these rules.

(2)A member of the Service who is detained in official custody whether on a
criminal charge or otherwise for a period longer than forty-eight hours, shall
be deemed to have been suspended by the Government concerned under
this rule.
(3) A member of the Service in respect of, or against, whom an investigation,
inquiry or trial relating to a criminal charge is pending may, at the discretion
of the Government11 be placed under suspension until the termination of all
proceedings relating to that charge, if the charge is connected with his
position as a [member of the Service] or is likely to embarrass him in the
discharge of his duties or involves moral turpitude.
(4) A member of the Service shall be deemed to have been placed under
suspension12 by the Government concerned with effect from the date of
conviction, if, in the event of conviction for a criminal offence, if he is not
forthwith dismissed or removed or compulsorily retired consequent on such
conviction provided that the conviction carries a sentence of imprisonment
exceeding forty-eight hours.

8

Inserted vide Notification No.11018/3/2004-AIS-III dt.30.09.2009 (GSR No.714(E) dt. 30.09.2009)
Inserted vide Notification No.11018/3/2004-AIS-III dt.30.09.2009 (GSR No.714(E) dt. 30.09.2009)
10
Inserted vide Notification No.11018/3/2004-AIS-III dt.30.09.2009 (GSR No.714(E) dt. 30.09.2009)
11
Substituted vide DP&AR Notification No. 6/9/72-AIS-III, dt. 5.7.1975 (GSR No. 872 dt. 19.7.1975)
12
Inserted/substituted vide DP&AR Notification No. 6/9/73-AIS-III, dt. 26.7.1975 (GSR No. 985 dt. 9.8.1975)
9

265

<!-- page 4 -->

13

Explanation.— The period of forty-eight hours referred to in sub-rule (4) shall be
commuted from the commencement of the imprisonment after the conviction and for this
purpose, intermittent periods of imprisonment, if any, shall be taken into account.
(5) Where a penalty of dismissal, removal or compulsory retirement from
service imposed upon a member of the Service under suspension is set
aside in appeal or on review under these rules and the case is remitted for
further inquiry or action or with any other directions, the order of his
suspension shall be deemed to have continued in force on and from the
date of the original order of dismissal, removal or compulsory retirement and
shall remain in force until further orders.
(6) Where a penalty of dismissal, removal or compulsory retirement from
service imposed upon a member of the Service is set aside or declared or
rendered void in consequence of or by a decision of a Court of Law, and the
disciplinary authority, on a consideration of the circumstances of the case,
decides to hold further inquiry against him on the allegations on which the
penalty of dismissal, removal or compulsory retirement was originally
imposed, the member of the Service shall be deemed to have been placed
under suspension by the Central Government from the date of original order
of dismissal, removal or compulsory retirement and shall continue to remain
under suspension until further orders:
14

Provided that no such further inquiry shall be ordered unless it is intended
to meet a situation where the court has passed an order purely on technical
grounds without going into the merits of the case.
15

(6A) Where an order of suspension is made, or deemed to have been made,
by the Government of a State under this rule, detailed report of the case
shall be forwarded to the Central Government ordinarily within a period of
fifteen days of the date on which the member of the Service is suspended or
is deemed to have been suspended, as the case may be.

(7) (a)

An order of suspension made or deemed to have been made under this
rule shall continue to remain in force until it is modified or revoked by
the authority competent to do so.

16

(b) Where a member of the Service is suspended or is deemed to have
been suspended, whether in connection with any disciplinary
proceeding or otherwise, and any other disciplinary proceeding is
commenced against him during the continuance of that suspension, the
authority competent to place him under suspension may, for reasons to
be recorded in writing, direct that the member of Service shall continue
to be under suspension subject to sub-rule (8).

(c)

An order of suspension made or deemed to have been made under this
rule may at any time be modified or revoked by the authority which
made or deemed to have made the order.

13

Inserted vide DP&AR Notification No. 11018/6/78-AIS-III, dt. 16.11.1978 (GSR No. 1415 dt. 2.12.1978)
Inserted vide DP&AR Notification No. 11018/18/81-AIS-III, dt. 3.8.1983 (GSR No. 612, dt.20.8.1983)
15
Inserted vide DP&AR Notification No. 6/9/72-AIS-III, dt. 5.7.1975 (GSR No. 872 dt. 19.7.1975)
16
Substituted vide DOP&T Notification no. 11018/3/97-AIS-III, dt. 13.7.1998 (GSR No. 130 dt. 25.7.1998)
14

266

<!-- page 5 -->

17

(8) (a)

An order of suspension made under this rule which has not been
extended shall be valid for a period not exceeding ninety days and an
order of suspension which has been extended shall remain valid for a
further period not exceeding one hundred eighty days, at a time, unless
revoked earlier.

(b)

An order of suspension made or deemed to have been made or
continued, shall be reviewed by the competent authority on the
recommendations of the concerned Review Committee.

(c)

The composition and functions of the Review Committees and the
procedure to be followed by them shall be as specified in the
18
Schedule 1 annexed to these rules.

(d)

The period of suspension 19[under this rule] may, on the
recommendations of the concerned Review Committee, be extended
for a further period not exceeding one hundred and eighty days at a
time:
Provided that where no order has been passed under this clause, the
order of suspension shall stand revoked with effect from the date of
expiry of the order being reviewed.

(9) Every order of suspension and every order of revocation shall be made, as
nearly as practicable, in the appropriate standard form appended to these
rules.
4. Subsistence allowance during suspension—
20

(1)

A member of the Service under suspension or deemed to have been
placed under suspension by the Government concerned shall be entitled to
receive from that Government:—
(a)

a subsistence allowance at an amount equal to the leave salary which
a member of the Service would have drawn if he had been on leave on
half-average pay or on half pay and in addition, dearness allowance, if
admissible on the basis of such leave salary:
Provided that where the period of suspension exceeds 21three months,
the authority which made or is deemed to have made the order of
suspension shall be competent to vary the amount of subsistence
allowance for any period subsequent to the period of the first three
months as follows:
(i)

the amount of subsistence allowance may be increased by a
suitable amount, not exceeding 50 per cent of the subsistence
allowance admissible during the period of the first three months, if,
in the opinion of the said authority, the period of suspensions has
been prolonged for reasons, to be recorded in writing, not directly
attributable to the member of the Service;

17

Inserted vide DOP&T Notification No. 11018/3/97-AIS-III dt. 13.7.1998 (GSR No. 130 dt. 25.7.1998
Inserted vide Notification No.11018/3/2004-AIS-III dt.30.09.2009 (GSR No.714(E) dt. 30.09.2009)
19
Inserted vide Notification No.11018/3/2004-AIS-III dt.30.09.2009 (GSR No.714(E) dt. 30.09.2009)
20
Substituted vide DP&AR Notification No. 11018/11/78-AIS-III dt. 16.6.1979
21
Substituted vide DP&AR Notification no. 28013/2/78-AIS-III dt. 12.1.1982 (GSR No. 92 dt. 30.1.1982)
18

267

<!-- page 6 -->

(b)

(ii)

the amount of the subsistence allowance may be reduced by a
suitable amount, not exceeding 50 per cent of the subsistence
allowance admissible during the period of the first three months, if
in the opinion of the said authority, the period of suspension has
been prolonged for reasons, to be recorded in writing directly
attributable to a member of the Service;

(iii)

the rate of the dearness allowance will be based on the increased
or, as the case may be, the reduced amount of subsistence
allowance admissible under sub-clause (i) or sub-clause (ii)
above.

any other compensatory allowance admissible from time to time on the
basis of pay of which a member of the Service was in receipt on the
date of suspension, subject to the fulfilment of other conditions laid
down for the drawal of such allowance.

(2) No member of the Service shall be entitled to receive payment under subrule (1) unless he furnishes a certificate that he is not engaged in any other
employment, business, profession or vocation.
(3) The authority to grant subsistence allowance shall be the suspending
authority.
22

5. Admissibility of pay and allowances and treatment of service on
reinstatement after dismissal, removal or compulsory retirement as a result of
appeal or review.—
(1) When a member of the Service, who has been dismissed, removed or
compulsorily retired is reinstated as a result of appeal or review or would
have been so reinstated but for his retirement under the All India Services
(Death-cum-Retirement Benefits) Rules, 1958, while under suspension or
not, the authority competent to order reinstatement shall consider and make
a specific order—
(a)

regarding the pay and allowances to be paid to the member of the
Service for the period of his absence from duty including the
suspension preceding his dismissal, removal or compulsory retirement,
as the case may be; and

(b)

whether or not the said period shall be treated as a period spent on
duty.

(2) The member of the Service shall, subject to the provisions of sub-rule (6) be
paid the full pay and allowances to which he would have been entitled, had
he not been dismissed, removed or compulsorily retired or suspended prior
to such dismissal, removal or compulsory retirement, as the case may be, in
cases:—
(i)

22

where the authority competent to order reinstatement is of opinion that
the member of the Service who had been dismissed, removed or
compulsorily retired has been fully exonerated, or

Substituted vide DP&AR Notification no. 28013/2/78-AIS-III dt. 12.01.1982 (GSR No. 92 dt. 30.1.1982)

268

<!-- page 7 -->

(ii)

where the order of dismissal, removal or compulsory retirement from
service is set aside by the appellate or reviewing authority solely on the
ground of non-compliance with the requirements of clause (1) or clause
(2) of article 311 of the Constitution and no further inquiry is proposed
to be held:
Provided that where such authority is of the opinion that the termination
of the proceedings instituted against the member of the Service had
been delayed due to reasons directly attributable to the member of the
Service, it may, after giving him an opportunity to make his
representation and after considering the representation, if any,
submitted by him, direct, for reasons to be recorded in writing, that the
member of the Service shall, subject to the provisions of sub-rule (7),
be paid for the period of such delay, only such proportion of such pay
and allowances as it may determine.

(3) In a case falling under sub-rule (2), the period of absence from duty
including the period of suspension preceding dismissal, removal or
compulsory retirement, as the case may be, shall be treated as a period
spent on duty for all purposes.
(4) In cases other than those covered by sub-rule (2) the member of the Service
shall, subject to the provisions of sub-rule (6) and (7), be paid such
proportion of the full pay and allowances to which he would have been
entitled, had he not been dismissed, removed or compulsorily retired or
suspended prior to such dismissal, removal or compulsory retirement, as the
case may be, as the authority competent to order reinstatement may
determine after giving notice to the member of the Service of the quantum
proposed and after considering the representation, if any, submitted by him,
in that connection within 60 days from the date on which the notice
aforesaid is served on the member of the Service.
(5) In a case falling under sub-rule (4), the period of absence from duty
including the period of suspension preceding his dismissal, removal or
compulsory retirement, as the case may be, shall not be treated as a period
spent on duty, unless the authority competent to order reinstatement
specifically directs that it shall be so treated for any specified purpose:
Provided that if the member of the Service so desires, such authority may
direct that the period of absence from duty including the period of
suspension preceding his dismissal, removal or compulsory retirement, as
the case may be, shall be converted into leave of any kind due and
admissible to the member of Service.
(6) The payment of allowances under sub-rule (2) or sub-rule (4) shall be
subject to all other conditions under which such allowances are admissible.
(7) The portion of the full pay and allowances determined under the proviso to
sub-rule (2) or under sub-rule (4) shall neither be equal to the full pay and
allowances nor less than the subsistence allowance and other allowances
admissible under rule 4, as the case may be.

269

<!-- page 8 -->

(8) Any payment made under this rule to a member of the Service on his
reinstatement shall be subject to adjustment of the amount, if any, earned
by him through an employment during the period between the date of
removal, dismissal or compulsory retirement, as the case may be, and the
date of reinstatement. Where the pay and allowances admissible under this
rule are equal to or less than the amounts earned during the employment
elsewhere, nothing shall be paid to the member of the Service.
23

5A. Admissibility of pay and allowances and treatment of service on
reinstatement where dismissal, removal or compulsory retirement is set aside by
a Court of Law.—
5A(1) Where the dismissal, removal or compulsory retirement of a member of the
Service is set aside by a Court of Law and such member is reinstated
without holding any further inquiry, the period of absence from duty shall be
regularised and the member of the Service shall be paid pay and
allowances in accordance with provisions of sub-rule (2) or (3) subject to the
directions, if any, of the Court.
5A(2) (i)

In cases other than those covered by sub-rule (3), the member of the
service shall be paid such portion of the full-pay and allowances to
which he would have been entitled had he not been dismissed,
removed or compulsorily retired, or suspended prior to such dismissal,
removal or compulsory retirement, as the case may be, as the authority
competent to order reinstatement may determine, after giving notice to
the member of the Service of the quantum proposed and after
considering the representation, if any, submitted by him, in that
connection, within 60 days from the date on which the notice aforesaid
is served on the member of the Service:
Provided that any payment under this sub-rule to a member of the
Service shall neither be equal to the full pay and allowances nor less
than the subsistence allowance and other allowances admissible under
rule 4 as the case may be.

(ii)

The period intervening between the date of dismissal, removal or
compulsory retirement, including the period of suspension preceding
such dismissal, removal or compulsory retirement, as the case may be,
and the date of judgement of the Court shall be regularised in
accordance with the provisions contained in sub-rule (5) of rule 5.

5A(3) Where the dismissal, removal or compulsory retirement of a member of the
Service is set aside by a Court on the merits of the case, or where the
dismissal, removal or compulsory retirement of a member of the Service is
set aside by a Court-solely on the ground of non-compliance with the
requirements of clause (1) or clause (2) of article 311 of the Constitution and
no further enquiry is proposed to be held, the period intervening between
the date of dismissal, removal or compulsory retirement as the case may be,
and the date of reinstatement shall be treated as duty for all purpose and he
shall be paid full pay and allowances for the period to which he would have
been entitled, had he not been dismissed, removed or compulsorily retired

23

Substituted vide DP&AR Notification No. 28013/2/78-AIS-III dt. 12.01.1982 (GSR No. 92 dt. 30.01.1982)

270

<!-- page 9 -->

or suspended prior to such dismissal, removal or compulsory retirement, as
the case may be.
5A(4) The payment of allowances under sub-rule (2) or sub-rule (3) shall be
subject to all other conditions under which such allowances are admissible.
5A(5) Any payment made under this rule to a member of the Service on his
reinstatement shall be subject to adjustment of the amount, if any, earned
by him through an employment during the period between the dismissal,
removal or compulsory retirement and the date of reinstatement. Where the
pay and allowances admissible under this rule are equal to or less than
those earned during the employment elsewhere, nothing shall be paid to the
member of the Service.
24

5B. Admissibility of pay and allowances and treatment of Service on
reinstatement after suspension.—
5B(1) When a member of the Service under suspension is reinstated or would
have been so reinstated but for his retirement under the All India Services
(Death-cum-Retirement Benefits) Rules, 1958 while under suspension, the
authority competent to order reinstatement shall consider and make a
specific order—
(a)

regarding the pay and allowances to be paid to the member of the
Service for the period of suspension ending with reinstatement or the
date of his retirement on superannuating, as the case may be; and

(b)

whether or not the said period shall be treated as a period spent on
duty.

5B(2) Notwithstanding anything contained in rule 4, where a member of the
Service under suspension dies before the disciplinary or court proceedings
instituted against him are concluded, the period between the date of
suspension and the date of death shall be treated as duty for all purposes
and his family shall be paid the full pay and allowances for that period to
which he would have been entitled had he not been suspended, subject to
adjustment in respect of subsistence allowance and other allowances
already paid.
5B(3) Where the authority competent to order reinstatement is of the opinion that
the suspension was wholly unjustified, the member of the Service shall,
subject to the provisions of sub-rule (8), be paid the full pay and allowances
to which he would have been entitled, had he not been suspended, subject
to adjustment in respect of subsistence allowance and other allowances
already paid:
Provided that where authority is of the opinion that the termination of the
proceedings instituted against the member of the Service had been delayed
due to reasons directly attributable to the member of the Service, it may,
after giving him an opportunity to make his representation and after
considering the representation, if any, submitted by him, direct, for reasons
to be recorded in writing, that the member of the Service shall be paid for
the period of such delay only such proportion of such pay and allowances as
it may determine.
24

Substituted vide DP&AR Notification No. 6/9/73-AIS-III dt. 26.7.1975 (GSR No. 985 dt. 9.8.1975)

271

<!-- page 10 -->

5B(4) In cases falling under sub-rule (3) the period of suspension shall be treated
as a period spent on duty for all purposes.
5B(5) In case other than those falling under sub-rules (2) and (3), the member of
the Service shall subject to the provisions of sub-rules (8) and (9) be paid
such proportion of the full pay and allowances to which he would have been
entitled had he not been suspected, as the authority competent to order
reinstatement may determine, after giving notice to the member of the
Service of the quantum proposed and after considering the representation, if
any, submitted by him in that connection within 25[Sixty days from the date
on which the notice aforesaid is served on the member of the Service.]
5B(6) Where suspension is revoked pending finalization of the disciplinary
proceeding or proceedings in a court any order passed under sub-rule (1)
before the conclusion of the proceedings against the member of the Service,
shall be reviewed on its own motion after the conclusion of the proceedings
by the authority mentioned in sub-rule (1) who shall make an order in
accordance with the provisions contained in sub-rule (3) or sub-rule (5), as
the case may be.
5B(7) In a case falling under sub-rule (5) the period of suspension shall not be
treated as a period spent on duty, unless the authority competent to order
reinstatement specifically directs that it shall be so treated for any specified
purpose:
Provided that if the member of the Service so desires such authority may
order that the period of suspension shall be converted into leave of any kind
due and admissible to the member of the Service.
5B(8) The payment of allowances under sub-rule (2), sub-rule (3) or sub-rule (5)
shall be subject to all other conditions under which such allowances are
admissible.
5B(9) The proportion of the full pay and allowance determined under the proviso to
sub-rule (3) or sub-rule (5) shall neither be equal to full pay and allowances
nor shall it be less than the subsistence allowance and other allowances
admissible under rule 4.
PART III—PENALTIES AND DISCIPLINARY AUTHORITIES.
6. Penalties.—
6(1) The following penalties may, for good and sufficient reasons and as
hereinafter provided be imposed on a member of the Service, namely:—
Minor Penalties:
(i)

censure;

(ii)

withholding of promotion;

(iii)

recovery from pay of the whole, or part of any pecuniary loss caused to
Government, or to a company, association or body of individuals,
whether incorporated or not, which is wholly or substantially owned or
controlled by Government, or to a local authority set up by an Act of

26

25
26

Modified vide DP&AR Notification No.28013/2/78-AIS(III) dated 12.01.1982 (GSR No.92 dt.30.10.1982)
Substituted vide DP&AR Notification No. 6/5/74-AIS-III dt. 28.7.1975(GSR No. 988 dt. 9.9.1975)

272

<!-- page 11 -->

Parliament or of the Legislature of a State, by negligence or breach of
orders;
(iv)
27

(iv) a

withholding of increments of pay;
Reduction to a lower stage in the time scale of pay for a period not
exceeding three years, without cumulative effect and not adversely
affecting his pension.

Major Penalties:
(v)

reduction to a lower stage in the time scale of pay for a specified period
with further directions as to whether or not the member of the Service
will earn increments during the period of reduction and whether, on the
expiry of such period, the reduction will or will not have the effect of
postponing future increments of his pay;

(vi)

reduction to a lower time scale of pay, grade or post which shall
ordinarily be a bar to promotion of the member of the Service to the
time scale of pay, grade or post from which he was reduced, with or
without further direction regarding conditions of restoration to the grade
or post from which the member of the Service was reduced and his
seniority and pay on such restoration to that grade or post;

(vii)

compulsory retirement:
Provided that, if the circumstances of the case so warrant, the authority
imposing the penalty may direct that the retirement benefits admissible
to the member of the Service under the All India Services (Death-cumRetirement Benefits) Rules, 1958, shall be paid at such reduced scale
as may not be less than two-thirds of the appropriate scales indicated
in Schedules ‘A’ and ‘B’ of the said rules;

(viii)

removal from Service which shall not be a disqualification for future
employment under the Government;

(ix)

dismissal from Service which shall ordinarily be a disqualification for
future employment under the Government.
28

Provided that every case in which 29the charge of possession of the
assets disproportionate to known sources of income or the charge of
acceptance from any person of any gratification, other than legal
remuneration, as a motive or reward for doing or for bearing to do any
official act is established, the penalty mentioned in clause (viii) or clause
(ix) shall be imposed.
Provided further that in any exceptional case, and for special reasons
recorded in writing any other penalty may be imposed.

Explanation—The following shall not amount to a penalty within the meaning of this
rule, namely:—

27
28
29

Inserted vide DOP&T Notification No.11018/3/98-AIS-III dated 01.06.2000 (GSR No.212. dt. 17.06.2000)
Inserted vide DOP&T Notification No. 11018/7/87-AIS-III dated 26.02.1988
Inserted vide DP&T’s Notification No.11018/5/2000-AIS(III) dated 04.04.2002 (GSR No.118 dt. 13.04.2002)

273

<!-- page 12 -->

(i)

Withholding of increments of pay of a member of the Service for failure
to pass a departmental examination in accordance with the rules or
orders governing the service;

(ii)

Stoppage of a member of the Service at the efficiency bar in the timescale of pay on the ground of his unfitness to cross the bar;

(iii)

non-promotion of a member of the Service, whether in a substantive or
officiating capacity, to a post in the senior time-scale of pay on the
ground of lack of adequate length of service and experience or nonconfirmation in the service, or failure to pass the departmental
examination;

30

(iii) a

non-promotion of a member of the Service, whether in a
substantive or officiating capacity, after due consideration of his
case to the selection grade or to a post carrying pay above the
time-scale of pay.

(iv)

reversion of a member of the Service officiating in a higher grade or
post, to which promotions are made by selection, to a lower grade or
post after a period of trial not exceeding three years on the ground that
he is considered unsuitable for such higher grade or post, or on any
administrative ground unconnected with his conduct;

(v)

reversion of a member of the Service, appointed on probation to the
Service, to State Service, during or at the end of the period of
probation, in accordance with the terms of appointment or the rules and
orders governing such probation;

(vi)

replacement of the services of a member of the Service whose services
have been borrowed from a State Government at the disposal of the
State Government concerned;

(vii)

compulsory retirement of a member of the Service under the Provisions
of the All India Services (Death-cum-Retirement Benefit) Rules, 1958;

(viii)

termination of the service of a member of the Service, appointed on
probation, during or at the end of the period of probation in accordance
with the terms of the service or the rules and orders governing such
probation.

(2) 31[ ]
7. Authority to institute proceedings and to impose penalty—
32

(1) Where a member of the Service has committed any act or omission which
renders him liable to any penalty specified in rule 6—
(a)

if such act or omission was committed before his appointment to the
Service—
(i)

30
31
32

the State Government, if he is serving in connection with the
affairs of that State, or is deputed for service in any company,
association or body of individuals, whether incorporated or not,

Substituted vide DP&AR Notification No. 12/2/69-AIS-III dt. 13.04.1971 (GSR No. 588 dt. 24.04.1971)
Omitted vide DP&AR Notification No. 31/7/72-AIS-III dated 22.05.1973
Substituted vide DP&AR Notification No. 6/9/72-AIS-III dt. 05.07.1975 (GSR No. 872 dt. 15.07.1975)

274

<!-- page 13 -->

which is wholly or substantially owned or controlled by the
Government of that State or in a local authority set up by an Act of
the Legislature of that State; or
(ii)

(b)

the Central Government, in any other case, shall alone be
competent to institute disciplinary proceedings against him and,
subject to the provisions of sub-rule (2), to impose on him such
penalty specified in rule 6 as it thinks fit;

If such act or omission was committed after his appointment to the
Service—
(i)

while he was serving in connection with the affairs of a State, or is
deputed for service under any company, association or body of
individuals, whether incorporated or not, which is wholly or
substantially owned or controlled by the Government of a State, or
in a local authority set up by an Act of the Legislature of that State,
the Government of that State; or

(ii)

while he was on training, the Central Government, unless the
selection for the training was done by the State Govt. and the cost
of the training was entirely borne by the State Government.

(iii)

while he was on leave, the Government which sanctioned him the
leave; or

(iv)

while he was under suspension, the Government which placed
him or is deemed to have placed him under suspension; or

(v)

if such act or omission is willful absence from duty after the expiry
of leave, the Government which sanctioned the leave; or

(vi)

while he was absent from duty otherwise than on leave, the
Government which would have been competent to institute
disciplinary proceedings against him, had such act or commission
been committed immediately before such absence from duty; or

(vii)

the Central Government, in any other case, shall alone be
competent to institute disciplinary proceedings against him and,
subject to provisions of sub-rule (2), to impose on him such
penalty specified in rule 6 as it thinks fit, and the Government,
company associations, body of individuals or local authority, as
the case may be under whom he is serving at the time of
institution of such proceedings shall be bound to render all
reasonable facilities to the Government instituting and conducting
such proceedings.

33

Explanation.— For the purposes of clause (b) of sub-rule (1) where the Government
of a State is the authority competent to institute disciplinary proceedings against a
member of the Service, in the event of a reorganisation of the State, the Government on
whose cadre he is borne after such reoganisation shall be the authority competent to
institute disciplinary proceedings and, subject to the provisions of sub-rule (2), to impose
on him any penalty specified in rule 6.
33

Substituted vide Notification No. 11018/1/98-AIS-III dt. 25.08.1998 (GSR No. 177 dt. 12.09.1998)

275

<!-- page 14 -->

34

(1A)Notwithstanding anything contained in sub-rule (1) the Director, Lal Bahadur
Shastri National Academy of administration, the Director, Sardar
Vallabhbhai Patel National Police Academy or the President, Forest
Research Institute and Colleges, shall be empowered to initiate disciplinary
proceedings against a probationer who is undergoing training at the Lal
Bahadur Shastri National Academy of Administration, Sardar Vallabhbhai
Patel National Police Academy or Forest Research Institute and Colleges,
as the case may be, in respect of any misconduct or misbehavior during the
period he spends at the said Academy/Institute in accordance with the
prescribed procedure laid down in rule 10 of these rules. Thereafter the
Director/President shall refer the case to the Central Government with the
relevant records for passing orders under rule 6 in consultation with the
Commission.

35

(1B)Notwithstanding anything contained in sub-rule (1), if in any case, a
question arises as to the Government competent to institute disciplinary
proceedings, it shall be decided by the Central Government and the
Government so decided by the Central Government, as being competent to
institute disciplinary proceedings (which may include the Central
Government also), shall alone be competent to institute disciplinary
proceedings against him and, subject to the provisions of sub-rule (2), to
impose on him such penalty specified in rule 6 as it thinks fit, and
Government, company association, body of individuals, or the local
authority, as the case may be, under whom he is serving at the time of the
institution of such proceedings shall be bound to render all reasonable
facilities to the Government instituting and conducting such proceedings.

(2) The penalty of dismissal, removal or compulsory retirement shall not be
imposed on a member of the Service except by an order of the Central
Government.
(3) Where the punishing Government is not the Government on whose cadre
the member is borne, the latter Government shall be consulted before any
penalty specified in rule 6 is imposed:
36

Provided that in relation to the members of the Service borne on a Joint
Cadre, the punishing Government shall consult the Joint Cadre Authority:
Provided further that where the Government concerned are the Central
Government and the State Government or two State Governments and
there is a difference of opinion between the said Government in respect of
any matter referred to in this rule, the matter shall be referred to the Central
Government for its decisions, which shall be passed in consultation with the
Commission.
PART IV—PROCEDURE FOR IMPOSING PENALTIES
8. Procedure for imposing major penalties.—
8(1) No order imposing any of the major penalties specified in rule 6 shall be
made except after an inquiry is held as far as may be, in the manner
34
35
36

Inserted vide DP&AR Notification No. 11018/4/76-AIS-III dated 25.02.1977 (GSR No. 358 dt. 19.3.1977)
Inserted vide DP&AR Notification No. 11018/4/76-AIS-III dated 25.02.1977 (GSR No. 358 dt. 19.3.1977)
Substituted vide DOP&T Notification No. 13/1/71-AIS-III dated 11.01.1972

276

<!-- page 15 -->

provided in this rule and rule 10 or provided by the Public Servants
(Inquiries) Act 1850 (37 of 1850) where such inquiry is held under that Act.
8(2) Whenever the disciplinary authority is of the opinion that there are grounds
for inquiring into the truth of any imputation of misconduct or misbehaviour
against a member of the Service, it may appoint under this rule or under the
provisions of the Public Servants (Inquiries) Act 185037, as the case may be,
an authority to inquire into the truth thereof.
8(3) Where a Board is appointed as the inquiring authority it shall consist of not
less than two senior officers provided that at least one member of such a
Board shall be an officer of the Service to which the member of the Service
belongs.
8(4) Where it is proposed to hold an inquiry against a member of the Service
under this rule and or rule 10, the disciplinary authority shall draw up or
caused to be drawn up—
(i)

the substance of the imputations of misconduct or misbehavior into
definite and distinct articles of charge;

(ii)

a statement of the imputations of misconduct or misbehavior in support
of each article of charge, which shall contain—
(a)

a statement of all relevant facts including any admission or
confession made by the member of the Service;

(b)

a list of documents by which, and a list of witness by whom the
articles of charge are proposed to be sustained.

8(5) The disciplinary authority shall deliver or cause to be delivered to the
member of the Service a copy of the articles of charge, the statement of the
imputations of misconduct or misbehavior and a list of documents and
witnesses by which each article of charge is proposed to be sustained and
shall require the member of the Service to submit, within such time as may
be specified, a written statement of his defence and to state whether he
desires to be heard in person.

37

8(6) (a)

On receipt of the written statement of defence the disciplinary authority
may appoint, under sub-rule (2), an inquiring authority for the purpose
of inquiring into such of the articles of charge as are not admitted and
where all the articles of charge have been admitted by the member of
the Service in his written statement of defence, the disciplinary
authority shall record its finding on each charge and shall act in the
manner laid down in rule 9.

(b)

If no written statement of defence is submitted by the member of the
Service, the disciplinary authority may, if it considers it necessary to do
so, appoint under sub-rule (2), an inquiring authority for the purpose.

(c)

Where the disciplinary authority appoints an inquiring authority for
holding an inquiry into such charge it may by an order, appoint a
Government servant or a legal practitioner, to be known as the
“Presenting Officer” to present on its behalf the case in support of the
articles of charge.

Circulated vide DOP&T letter No. 2506/80/AIS-III dated 05.08.1980

277

<!-- page 16 -->

8(7) The disciplinary authority shall forward to the inquiring authority—
(i)

a copy of the articles of charge and the statement of imputations of
misconduct or misbehaviour;

(ii)

a copy of the written statement of defence if any submitted by the
member of the Service;

(iii)

a copy of the 38[statements] of witness, if any, referred to in sub-rule (4)

(iv)

evidence proving the delivery of the documents referred to in sub-rule 4
to the member of the Service; and

(v)

a copy of the order appointing the “Presenting Officer”.

8(8) The member of the Service shall be required to appear in person before the
inquiring authority at any time prescribed after the expiry of ten working days
from the date of receipt of the articles of charge and statement of
imputations of misconduct or misbehavior, or within such further time, not
exceeding ten days, as the inquiring authority may allow.

39

8(9) (a)

The member of the Service may take the assistance of any other
Government servant to present the case on his behalf but may not
engage a legal practitioner for the purpose unless the Presenting
Officer appointed by the disciplinary authority is a legal practitioner, or,
the disciplinary authority, having regard to the circumstances of the
case, so permits.

8(9) (b)

A member of the Service may also take the assistance of a retired
Government servant to present the case on his behalf, subject to such
conditions as may be specified by the President from time to time by
general or special order in this behalf.

40

NOTE: The member of the Service shall not take the assistance of any other
Government servant who has two or more pending disciplinary cases on
hand in which he has to give assistance.

8(10) If the member of the Service who has not admitted any of the articles of
charge in his written statement of defence or has not submitted any written
statement of defence appears before the inquiring authority, such authority
shall ask him whether he is guilty or has any defence to make and if he
pleads guilty to any of the article of charge, the inquiring authority shall
record the plea, sign the record and obtain the signature of the member of
the Service thereon.
8(11) The inquiring authority shall return a finding of guilt in respect of [those]
articles of charge to which the member of the Service pleads guilty.
8(12) The inquiring authority shall, if the member of the Service fails to appear
within the specified time or refuses or omits to plead, require the Presenting
Officer to produce the evidence by which he proposes to prove the articles
of charge and shall adjourn the case to a later date, not exceeding thirty

38
39
40

Substituted DP&AR Notification No. 6/9/72-AIS-III dt. 5.7.1975 (GSR No. 872 dt. 19.7.1975)
Inserted vide DP&AR Notification No. 6/9/72-AIS-III dt. 5.7.1975 (GSR No. 872 dt. 19.7.1975)
Inserted vide DP&AR Notification No. 11018/12/76-AIS-III dt. 12.7.1977 (GSR No. 983 dt. 30.7.1977)

278

<!-- page 17 -->

days, after recording an order that the member of the Service may, for the
purpose of preparing his defence:

NOTE :

(i)

inspect, within five days of the order or, within such further time not
exceeding five days as the inquiring authority may allow, the document
specified in the list referred to in sub-rule (4);

(ii)

submit a list of witness to be examined on his behalf;
If the member of the Servicees applies orally or in writing for the supply of
copies of the statement of witness mentioned in the list referred to in subrule (4), the inquiring authority shall furnish him with such copies as early
as possible and in any case not later than three days before the
commencement of the examination of the witness on behalf of the
disciplinary authority.

(iii)

NOTE :

give a notice within ten days of the order or, within such further time not
exceeding ten days as the inquiring authority may allow, for the
discovery or production of any documents which are in the possession
of Government but not mentioned in the list referred to in sub-rule (4).

The member of the Service shall indicate the relevance of the documents
required by him to be discovered or produced by the Government.

8(13) The inquiring authority shall, on receipt of the notice for the discovery or
production of documents, forward the same or copies thereof to the
authority in whose custody or possession the documents are kept with a
requisition for the production of the document by such date as may be
specified in such requisition:
Provided that the inquiring authority may, for reasons to be recorded by it in
writing, refuse to requisition such of the documents as are, in its opinion, not
relevant to the case.
8(14) On receipt of the requisition referred to in sub-rule (13), every authority
having the custody or possession of the requisitioned documents shall
produce the same before the inquiring authority:
Provided that if the authority having the custody or possession of the
requisitioned documents is satisfied, for reasons to be recorded by it in
writing, that the production of all or any of such documents would be against
the public interest or security of the State, it shall inform the inquiring
authority accordingly and the inquiring authority shall, on being so informed,
communicate the information to the member of the Service and withdraw the
requisition made by it for the production or discovery of such documents.
8(15) On the date fixed for the inquiry, the oral and documentary evidence by
which the articles of charge are proposed to be proved shall be produced
by, on behalf of, the disciplinary authority. The witnesses shall be examined
by, or on behalf of, disciplinary authority. The witnesses shall be examined
by, or on behalf of the Presenting Officer and may be cross-examined by, or
on behalf of, the member of the Service. The Presenting Officer shall be
entitled
to
re-examine the witnesses on any point, on which they have been crossexamined, but not on any new matter, without the leave of the inquiring

279

<!-- page 18 -->

authority. The inquiring authority may also put such questions to the
witnesses as it thinks fit.
8(16) If it shall appear necessary before the close of the case on behalf of the
disciplinary authority, the inquiring authority may, in its discretion, allow the
Presenting Officer to produce evidence not included in the list given to the
member of the Service or may itself call for new evidence or recall and reexamine any witness and, in such case, the member of the Service shall be
entitled to have, if he demands it, a copy of the list of further evidence
proposed to be produced and an adjournment of the inquiry for three clear
days before the production of such new evidence, exclusive of the day of
adjournment and the day to which the inquiry is adjourned. The inquiring
authority shall give to the member of the Service an opportunity of
inspecting such documents before they are taken on the record. The
inquiring authority may also allow the member of the Service to produce
new evidence, if it is of opinion that the production of such evidence is
necessary in the interests of justice.
NOTE:

New evidence shall not be permitted or called for or any witness shall not
be recalled to fill up any gap in the evidence. Such evidence may be
called for only when there is an inherent lacuna or defect in the evidence
which has been produced originally.

8(17) When the case for the disciplinary authority is closed, the member of the
Service shall be required to state his defence, orally or in writing, as he may
prefer. If the defence is made orally, it shall be recorded and the member of
the Service shall be required to sign the record. In either case, a copy of
the statement of defence shall be given to the Presenting Officer, if any
appointed.
8(18) The evidence on behalf of the member of the Service shall then be
produced. The member of the Service may examine himself in his own
behalf if he so prefers. The witnesses produced by the member of the
Service shall then be examined and shall be liable to cross-examination, reexamination and examination by the inquiring authority according to the
provisions applicable to the witnesses for the disciplinary authority.
8(19) The inquiring authority may, after the member of the Service closes his
case, and shall, if the member of the Service has not examined himself,
generally question him on the circumstances appearing against him in the
evidence for the purpose of enabling the member of the Service to explain
any circumstances appearing in the evidence against him.
8(20) The inquiring authority may, after the completion of the production of
evidence, hear the Presenting Officer, if any, appointed, and the member of
the Service or permit them to file written briefs of their respective cases, if
they so desire.
8(21) If the member of the Service, to whom a copy of the articles of charge has
been delivered, does not submit the written statement of defence on or
before the date specified for the purpose or does not appear in person
before the inquiring authority or otherwise fails or refuses to comply with the
provisions of this rule, the inquiring authority may hold the inquiry ex-parte.

280

<!-- page 19 -->

8(22) (a)

Where a State Government which has caused to be inquired into the
articles of any charge and, having regard to its decision on any of the
findings of any inquiring authority appointed by it is of the opinion that
the penalties specified in clauses (vii) to (ix) of rule 6 should be
imposed on the member of the Service, the State Government shall
forward the records of the inquiry to the Central Government
suggesting imposition of the penalties specified in clauses (vii) to (ix) of
rule 6.

8(22) (b)

The Central Government may act on the evidence on the record or
may, if it is of the opinion that further examination of any of the witness
is necessary in the interest of justice, recall the witnesses and examine,
cross-examine and re-examine such witnesses. If the Central
Government do not find justification for imposing one of the penalties
specified in clauses (vii) to (ix) of rule 6 in a case referred to it by a
State Government, then it shall refer it back to the State Government.

8(23) Whenever an inquiring authority, after having heard and recorded the whole
or any part of the evidence in an inquiry, ceases to exercise jurisdiction
therein and is succeeded by another inquiring authority which has, and
which exercises, such jurisdiction, the inquiring authority so succeeding may
act on the evidence so recorded by its predecessor, or partly recorded by its
predecessor and partly recorded by itself:
Provided that, if the succeeding inquiring authority is of the opinion that
further examination of any of the witnesses whose evidence has already
been recorded is necessary in the interest of justice, it may recall, examine,
cross-examine and re-examine any such witness as here in before provided.
8(24) (i)

After the conclusion of the inquiry, a report shall be prepared and it
shall contain—
(a)

the articles of charge and the statement of imputations of
misconduct or misbehaviour;

(b)

the defence of the member of the Service in respect of each
article of charge;

(c)

an assessment of the evidence in respect of each article of
charge; and

(d)

the findings on each article of charge and the reasons therefor.

Explanation— If in the opinion of the inquiring authority the proceedings of the
inquiry establish any article of charge different from the original articles of charge, it may
record its findings on such article of charge:
Provided that the findings on such article of charge shall not be recorded unless the
member of the Service has either admitted the facts on which such article of charge is
based or has had a reasonable opportunity of defending himself against such article of
charge.
(ii)

The inquiring authority shall forward to the disciplinary authority the
records of inquiry which shall include—
(a)

the report prepared by it under clause (i);

281

<!-- page 20 -->

(b)

the written statement of defence, if any, submitted by the member of
the Service;

(c)

the oral and documentary evidence produced in the course of the
inquiry;

(d)

written briefs, if any, filed by the Presenting Officer or the member of
the Service or both during the course of the inquiry; and

(e)

the orders, if any, made by the disciplinary authority and the inquiring
authority in regard to the inquiry.

9. Action on the inquiry report.—
9(1) The disciplinary authority may, for reasons to be recorded by it in writing,
remit the case to inquiring authority for further inquiry and report, and the
inquiring authority shall thereupon proceed to hold the further inquiry
according to the provisions of rule 8 as far as may be.
41

9(2) The disciplinary authority shall forward or cause to be forwarded a copy of
the report of the inquiry, if any, held by the disciplinary authority or where
the disciplinary authority is not the inquiring authority, a copy of the report of
the inquiring authority together with its own tentative reasons for
disagreement, if any with the findings of inquiry authority on any article of
charge to the Member of the Service who shall be required to submit, if he
so desires, his written representation of submission to the disciplinary
authority within fifteen days, irrespective of whether the report is favourable
or not to the Member of the Service.

42

9(2-A)The disciplinary authority shall consider the representation, if any,
submitted by the Member and record its findings before proceeding further
in the matter as specified in sub-rules (3) and (4).

9(3) If the disciplinary authority, having regard to its findings on all or any of the
articles of charge, is of the opinion that any of the penalties specified in
clause (i) to (iv) of rule 6 should be imposed on the member of the Service,
it shall notwithstanding anything contained in rule 10, make an order
imposing such penalty:
Provided that, in every case the record of the inquiry shall be forwarded by
the disciplinary authority to the Commission for its advice and such advice
shall be taken into consideration before making any order imposing any
penalty on the member of the Service.
43

9(4)If the disciplinary authority having regard to its findings on all or any of the
articles of charge and on the basis of the evidence adduced during the
inquiry is of the opinion that any of the penalties specified in clause (v) to (ix)
of rule 6 should be imposed on the member of the Service, it shall make an
order imposing such penalty and it shall not be necessary to give the
member of the Service any opportunity of making representation on the
penalty proposed to be imposed:

41
42
43

Substituted vide DoPT Notification No.11018/1/2002-AIS-III dt.26.06.2003 (GSR No.249 dt.12.07.2003)
Inserted vide DoPT Notification No.11018/1/2002-AIS-III dt.26.06.2003 (GSR No.249 dt.12.07.2003)
Substituted vide DP&AR Notification No. 11018/15/78-AIS-III dated 13.10.1981 (GSR No. 959 dt. 31.10.1981)

282

<!-- page 21 -->

Provided that in every case, the record of the inquiry shall be forwarded by
the disciplinary authority to the Commission for its advice and such advice
shall be taken into consideration before making an order imposing any such
penalty on the member of the Service.
10. Procedure for imposing minor penalties—
10(1) Subject to the provision of sub-rule (3) of Rule 9 no order imposing on a
member of the Service any of the penalties specified in clauses (i) to (iv) of
rule 6 shall be made except after:—
(a)

informing the member of the Service in writing of the proposal to take
action against him and of the imputations of misconduct or misbehavior
on which it is proposed to be taken and giving him a reasonable
opportunity of making such representation as he may wish to make
against the proposal;

(b)

holding an inquiry, in the manner laid down in sub-rules (4) to (23) of
rule 8, 44(in every case in which it is proposed to withhold increments of
pay for a period exceeding three years, or with cumulative effect for
any period, or so as to adversely affect the amount of pension payable
to him, or in which the disciplinary authority is of the opinion that such
inquiry is necessary.

(c)

taking the representation, if any submitted by the member of the
Service under clause (a), and the record of inquiry, if any, held under
clause (b) into consideration;

(d)

recording a finding on each imputation of misconduct or misbehavior,
and

(e)

consulting the Commission.

10(2) The record of proceedings in such cases shall include:—
(i) a copy of the intimation to the member of the Service of the proposal to
take action against him;
(ii) a copy of the statement of imputations of misconduct or misbehavior
delivered to him;
(iii) his representation, if any;
(iv) the evidence produced during the inquiry;
(v) the advice of the Commission;
(vi) the findings on each imputation of misconduct or misbehavior; and
(vii) the orders on the case together with the reasons therefor.
11. Cases of difference of opinion to be referred to Central Government.—
When there is any difference of opinion between a State Government and the
Commission on any matter covered by these rules such matter shall be referred to the
Central Government for its decision.

44

Substituted vide DP&AR Notification No.6/9/72-AIS(III) dated 05.07.1975 (GSR No.872 dated 19.07.1975)

283

<!-- page 22 -->

12. Communication of orders.— Orders made by the disciplinary authority shall
be communicated to the member of the Service who shall also be supplied with a copy
of the report of the inquiring authority and a statement of the finding of the disciplinary
authority, together with brief reasons for its disagreements, if any, with the findings of the
inquiring authority (unless they have already been supplied to him) and also a copy of
the advice, if any, given by the Commission and, where the disciplinary authority has not
accepted the advice of the Commission, a brief statement of the reasons for such nonacceptance.
13. Common proceeding.— Where two or more members of the Service are
concerned in any case, the Government may make an order directing that disciplinary
action against all of them may be taken in a common proceeding.
14. Special procedure in certain cases.— Notwithstanding anything contained in
rules 8 to 12—
(i) where any penalty is imposed on a member of the Service on the ground of
conduct which has led to his conviction on a criminal charge; or
(ii) where the disciplinary authority is satisfied, for reasons to be recorded by it
in writing, that if, is not reasonably practicable to hold an inquiry in the
manner provided in these rules; or
(iii) where the President is satisfied that, in the interest of the security of the
State, it is not expedient to hold an inquiry in the manner provided in these
rules, the disciplinary authority may consider the circumstances of the case
and make such orders thereon as it deems fit;
45

Provided that the member of the Service may be given an opportunity of making a
representation on the penalty proposed to be imposed before any order is made in a
case under clause (i) of this rule:
Provided 46further that except in cases where consultation with the Union Public
Service Commission is not necessary in accordance with the provisions of the Union
Public Service Commission (Exemption from Consultation) Regulations, 1958, the Union
Public Service Commission shall be consulted before any order is made in any case
under this rule.
PART V—Appeals
15. Orders against which no appeal lies.—
15(1) Notwithstanding anything contained in this part, no appeal shall lie
against:—

45
46

(i)

any order made by the President;

(ii)

any order of an interlocutory nature or of the nature of step-in-aid for
the final disposal of a disciplinary proceeding, other than an order of
suspension;

(iii)

any order passed by an inquiring authority in the course of inquiry
under rule 8;

Inserted vide DP&T Notification No.11018/2/87-AIS(III) dated 09.02.1888
Substituted vide Deptt. of p &AR Notification No.6/5/74-AIS(III), dated 28/7/75 (GSR No.988, dated 9.8.75)

284

<!-- page 23 -->

(iv)

any order by a competent authority withholding an appeal under rule
23.

15(2) Nothing in clause (i) and clause (iv) of sub-rule (1) shall be deemed to affect
or abridge the right of a member of the Service to submit a memorial to the
President under, and in accordance with, the provisions of rule 25.
16. Orders against which appeal lies.—Subject to the provisions of rule 15 and
the explanations to rule 6, a member of the service may prefer an appeal to the Central
Government against all or any of the following orders, namely:—
(i) an order of suspension made or deemed to have been made under rule 3;
(ii) an order passed by a State Government imposing any of the penalties
specified in rule 6;
(iii) an order of a State Government which—
(a)

denies or varies to his disadvantage his pay, allowance [ ]47 or other
conditions of service as regulated by rules applicable to him; or

(b)

interprets to his disadvantage the provisions of any such rule; or

(c)

has the effect of superseding him in promotion to a selection post;

(iv) an order of the State Government—
(a)

stopping him at the efficiency bar in the time scale of pay on the ground
of his unfitness to cross the bar; or

(b)

reverting him while officiating in a higher grade or post to a lower grade
or post, otherwise than as a penalty; or

48

(c)

deleted

(d)

determining the subsistence and other allowances to be paid to him for
the period of suspension or for the period during which he is deemed to
be under suspension or for any portion thereof; or

(e)

determining his pay and allowances—
(i) for the period of suspension, or
(ii) from the date of dismissal, removal or compulsory retirement from
service, or from the date of reduction to a lower grade, post, timescale of pay or stage in a time-scale of pay, to the date of
reinstatement or restoration to be paid to him on his reinstatement or
restoration; or

(f)

47
48

determining whether or not the period from the date of suspension or
from the date of dismissal, removal, compulsory retirement or reduction
to a lower grade post, time scale of pay or stage in a time scale of pay,
to the date of his reinstatement or restoration shall be treated as a
period spent on duty for any purpose.

The word pension deleted vide DPAR Notification No.6/9/72-AIS(III), dated 5.7.75 (GSR No.872, dt. 19.7.75)
Deleted vide Notification No. 6/9/92-AIS(III)dated 5.7.72-AIS(III), (GSR No.872 dt. 19.7.75)

285

<!-- page 24 -->

49

Explanation.—In this rule, the expression ‘member of the Service’ includes a
person who has ceased to be a member of the Service.
17. Period of limitation of appeals.—No appeal preferred under these rules shall
be entertained unless such appeal is preferred within a period of forty-five days from the
date on which a copy of the order 50appealed against is delivered to the appellant:
Provided that the appellate authority may entertain the appeal after the expiry of the
said period if it is satisfied that the appellate had sufficient cause for not preferring the
appeal in time.
18. Form and content of appeal.—
18(1) Every member preferring an appeal shall do so separately and in his own
name.
18(2) Every appeal preferred under these rules shall be addressed to the
Secretary to the Government of India in the 51Department or the Ministry, as
the case may be, dealing with the All India Service concerned and shall—
(a)

contain all material statements and arguments relied on by the
appellant;

(b)

contain no disrespectful or improper language; and

(c)

be complete in itself.

18(3) Every such appeal shall be submitted through the head of the office under
whom the appellant is for the time being serving and through the
Government from whose order the appeal is preferred.
18(4) The authority which made the order appealed against shall, on receipt of a
copy of every appeal, which is not withheld under rule 21, forward the same
with its comments thereon together with the relevant records to the
appellate authority without any avoidable delay and without waiting for any
direction from the Central Government.
19. Consideration of Appeal.—
19(1) In the case of an appeal against an order of the State Government imposing
any penalty specified in rule 6, the Central Government shall consider—
(a)

whether the procedure laid down in these rules has been complied
with, and, if not, whether such non-compliance has resulted in violation
of any provision of the Constitution of India or in the failure of justice;

(b)

whether the findings of the disciplinary authority are warranted by the
evidence on record; and

(c)

whether the penalty imposed is adequate, inadequate or severe and
pass orders—
(i)

49
50
51

confirming, enhancing, reducing or setting aside the penalty; or

Substituted vide DPAR Notification No.6/9/72-AIS(III), dated 5.7.75 (GSR No. 872 dated 19.5.75
Substituted vide DPAR Not. No. 6/9/72-AIS(III), dated 5.7.75 (GSR No.872 dated 19.5.75)
Substituted vide DPAR Notification No.6/9/72-AIS(III) dated 05.07.1975 (GSRNo.872, dated 19.05.1975)

286

<!-- page 25 -->

(ii)

remitting the case to the authority which imposed the penalty or to
any other authority with such direction as it may deem fit in the
circumstances of the case.

Provided that—
(i) the Commission shall be consulted before an order confirming, enhancing,
reducing or setting aside a penalty is passed;
(ii) if the enhanced penalty which the Central Government proposes to impose
is one of the penalties specified in clauses (v) to (ix) of rule 6 and an inquiry
under rule 8 has not already been held in the case, the appellate authority
shall, subject to the provisions of rule 14, itself hold such inquiry or direct
that such inquiry be held in accordance with the provisions of rule 8 and
thereafter, on a consideration of the proceedings of such inquiry 52[ ] make
such orders as it may deem fit;
(iii) if the enhanced penalty which the Central Government proposed to impose
is one of the penalties specified in clause (v) to (ix) of rule 6 and an inquiry
under rule 8 has already been held in the case, the Central Government
shall, 53[ ] make such orders as it may deem fit; and
(iv) no order imposing an enhanced penalty shall be made in any other case
unless the appellant has been given a reasonable opportunity as far as may
be in accordance with the provisions of rule 10, of making representation
against such enhanced penalty.
19(2) In an appeal against any other order specified in rule 16 the Central
Government shall consider all the circumstances of the case and make such
orders as it may deem just and equitable.
20. Implementation of orders on appeal—Every order passed by the Central
Government in appeal under any of the relevant provisions of these rules shall be final
and the State Government concerned shall forthwith give effect to such order.
21. Circumstances in which appeals may be withheld.—
21(1) The State Government, from whose order an appeal is preferred, may
withhold the appeal if—
21(1) (a) it is an appeal in a case in which under these rules there is no right of
appeal, or
21(1) (b) it does not comply with the provisions of rule 18, or
21(1) (c) it is not preferred within the period specified in rule 17 and no
reasonable cause is shown for the delay, or
21(1) (d) it is a repetition of a previous appeal which has already been decided
and no new facts or circumstances are adduced which afford grounds
for a reconsideration of the case.
21(2) In every case in which an appeal is withheld, the appellant shall be
informed of the fact and the reasons therefore.

52
53

Deleted vide Notification No. 11018/15/78-AIS(III) dated 13.10.1981 (GSR No.955, dated 31.10.1981)
Substituted vide Notification No. 6/9/75-AIS(III), dated 5.7.75 ( GSR No. 872, dt. 19.7.75)

287

<!-- page 26 -->

21(3) An appeal withheld on account only of failure to comply with the
provisions of rule 18 may be resubmitted at any time within one month of
the date on which the appellant has been informed of the withholding of
the appeal, and, if resubmitted in a form which complies with the said
provisions, shall not be withheld.
22. List of appeals withheld.— The State Government shall forward to the Central
Government on the first day of January and July every year a list of appeals to the
Central Government withheld by them under rule 21 during the preceding six months
together with the reasons for withholding the same.
23. Appellate authority may call for any appeal withheld.— The Central
Government may call for any appeal which has been withheld by any State Government
under rule 21, dealt with it in the manner laid down in rule 19 and pass such orders
thereon as the Central Government thinks fit.
54

PART VI— REVISION, REVIEW AND MEMORIALS

24. Revision.—
24(1) Notwithstanding anything contained in these rules, the Central
Government or the State Government concerned, as the case may be,
may at any time not exceeding 6 months from the date of the order
passed in appeal, if an appeal has been preferred, and where no such
appeal had been preferred, within one year of the original order which
gives the cause of action, either on its own motion or otherwise call for
the records of any order relating to suspension or any inquiry and revise
any order made under these rules or under the rules repealed by rule 30
from which an appeal is allowed. But from which no appeal has been
preferred or from which no appeals is allowed, 55 [ ] and may:
(a) confirm, modify or set aside the order; or
(b) confirm, reduce, enhance or set aside the penalty imposed by the
order, or impose any penalty where no penalty has been imposed, or
(c) remit the case to the authority which made the order directing such
authority to make such further inquiry as it may consider proper in the
circumstances of the case; or
(d) pass such orders as it may deem fit:
Provided that no order imposing or enhancing any penalty shall be
made unless the member of the Service concerned has been given a
reasonable opportunity of making a representation against the penalty
proposed and where it is proposed to impose any of the penalties
specified in clauses (v) to clause (ix) of rule 6 or to enhance the penalty
imposed by the order sought to be revised to any of the penalties
specified in these clauses, no such penalty shall be imposed except
after an inquiry in the manner laid down in rule 8 and 56except after
consultation with the Commission:
54
55
56

Substituted/inserted vide DPAR Notification No. 11018/19/81-AIS(III), dated 3.2.84 (GSRNo.162, dt. 18.2.84)
Deleted vide DPAR Notification No.6/9/72-AIS(III) dated 05.07.1975 (GSR No.872, dt. 19.07.1975)
Deleted vide Notification No.11018/15/78-AIS(III) dated 13.10.1981,(GSR No.959, dt. 31.10.1981)

288

<!-- page 27 -->

Provided further that where the original order was passed by the
Central Government or the State Government concerned, as the case
may be, after consultation with the Commission, it shall not be revised
except after consultation with the Commission.
23(2) No proceeding for revision shall be commenced until after—

23(3)

(i)

the expiry of the period of limitation for an appeal, or

(ii)

the disposal of the appeal, where any such appeal has been preferred.

An application for revision shall be dealt with in the same manner as if it
were an appeal under these rules.

57

24-A. Review.—The Central Government may at any time, either its own motion
or otherwise, review any order passed under these rules, when any new material or
evidence which could not be produced or was not available at the time of passing the
order under review and which has the effect of changing the nature of the case, has
come, or has been brought, to its notice:
Provided that no order imposing or enhancing any penalty shall be made by the
Central Government unless the member of the Service concerned has been given a
reasonable opportunity of making a representation against the penalty proposed or
where it is proposed to impose any of the major penalties specified in rule 6 or to
enhance a minor penalty imposed by the order sought to be reviewed to any of the major
penalties and if an enquiry under rule 8 has not already been held in the case, no such
penalty shall be imposed except after inquiring in the manner laid down in rule 8, subject
to the provisions of rule 14, and except after consultation with the Commission.
25. Memorials.—
25(1) A member of the Service shall be entitled to submit a memorial to the
President against any order of the Central Government or the State
Government by which he is aggrieved within a period of three years from
the date of the passing of such order.
58

Explanation.— In this sub-rule, the expression ‘member of the Service’ includes a
person who has ceased to be a member of the Service.
25(2) Every such memorial shall be authenticated by the signature of the
memorialist and submitted by the memorialist on his own behalf.
25(3) Every memorial submitted under these rules shall—
25(3) (a) contain all material statements and arguments relied upon by the
memorialist;
25(3) (b) contain no disrespectful or improper language;
25(3) (c) be complete in itself; and
25(3) (d) end with a specific prayer.
57
58

Substituted/inserted vide D/oP&R Notification No.11018/19/81-AIS(III) dated 03.02.1984 (GSR No.162 dt.18.02.1984)
Inserted vide D PAR Notification No. 6/9/72-AIS(III), dt. 5.7.75 (GSR No.872,dt.19.7.75)

289

<!-- page 28 -->

59

25(4)If the memorial is against the orders of a State Government, it shall be
submitted through the State Government concerned and if the memorial
is against the orders of the Central Government, it shall be submitted
through the Ministry or the authority concerned in the Central
Government, and the State Government concerned, or as the case may
be, the Ministry or authority in the Central Government shall forward the
same together with a concise statement of facts material thereto and,
unless there are special reasons to the contrary, with an expression of its
opinion thereon:
Provided that if the memorialist is for the time being serving under a State
Government, or under a Ministry or an authority in the Central Government,
which has not passed the orders against which the Memorial is submitted
then, the memorial shall be submitted through that State Government, or
that Ministry or authority in the Central Government, under which he is for
the time being serving.

60

25(5)A memorial submitted under the proviso to sub rule (4) shall be referred to
the State Government, or as the case may be, to the Ministry or authority in
the Central Government, against whose orders the memorial is submitted,
and the State Government concerned or, as the case may be, the Ministry
or authority in the Central Government, shall return the memorial together
with a concise statement of facts material thereto, and, unless there are
special reasons to the contrary, with an expression of its opinion
thereon.

61

25(5a)If the memorial is against an order imposing any of the penalties specified
in rule 6, no such order shall be revised except after consultation with the
Commission.
25(6) The authority against whose orders a memorial is submitted under this rule
shall give effect to any order passed thereon by the President.

26. Forwarding of advance copies — In cases where an appeal is preferred or a
memorial is submitted under these rules, the appellant or the memorialist, as the case
may be, may, if he do desires, forward an advance copy to the appellate authority in the
case of an appeal or to the President of India in the case of a memorial.
PART VII—MISCELLANEOUS
27. Service of orders, notices etc — Every order, notice and other process made
or issued under these rules shall be served in person on the member of the Service
concerned or communicated to him by registered post.
28. Power to relax time limit and condone delay — Save as otherwise expressly
provided in these rules, the Central Government or the State Government, as the case
may be, may, for good and sufficient reasons or if sufficient cause is shown extend the

59
60
61

Substituted vide DPAR Notification No. 11018/7/79-AIS(III), dt. 11.11.80 (GSR No. 1220 datted29.11.80)
Inserted vide DPAR Notification No.6/9/72-AIS(III),dt. 5.7.75 (GSR No.872, dt. 19.7.75)
Inserted vide DPAR Notification No.6/9/72-AIS(III), dated 5.7.75 (GSR No.872, dt. 19.7.75)

290

<!-- page 29 -->

time specified in these rules for anything required to be done under these rules or
condone any delay.
29. Supply of copy of Commission’s advice — Whenever the Commission is
consulted as provided in these rules, a copy of the advice by the Commission and,
where such advice has not been accepted, also a brief statement of the reasons for such
non-acceptance, shall be furnished to the member of the Service concerned along with a
copy of the order passed in the case.
30. Repeal and Saving — The All India Services (Discipline and Appeal) Rules,
1955, are hereby repealed.
Provided that—
(a) such repeal shall not affect the previous operation of the said rules, or
anything done, or any action taken, hereunder;
(b) any proceedings under the said rules, pending at the commencement of
these rules shall be continued and disposed of, as far as may be, in
accordance, with the provisions of these rules, as if such proceedings were
proceedings under these rules.
(2) Nothing in these rules shall be construed as depriving any person to whom
these rules apply of any right of appeal which had accrued to him under the rules hereby
repealed (hereinafter referred to as the repealed rules).
(3) An appeal pending at the commencement of these rules against any order made
before such commencement under the repealed rules shall be considered and orders
thereon shall be made, in accordance with these rules, as if such orders were made and
the appeal was preferred under these rules.
(4) As from the commencement of these rules any appeal or application for review
against any order made before such commencement under the repealed rules shall be
preferred or made under these rules, as if such orders were made under these rules:
Provided that nothing in these rules shall be construed as reducing any period of
limitation for any appeal or review provided by the repealed rules.
31. Removal of doubts:— Where a doubt arises as to the interpretation of any of
the provisions of these rules, the matter shall be referred to the Central Government for
its decision.
[No. 7/15/63—AIS(III) dated 20.3.69 GSR No. 926 dated 12.4.69]

291

<!-- page 30 -->

62

SCHEDULE 1

{see rule 3(8)(c) }
1. Composition of Review Committees:—
(a) The Review Committee constituted by the Central Government shall consist
of
(i)

Secretary to the Government
Ministry/Department — Chairman.

(ii)

Additional Secretary/Joint Secretary in charge of Administration in the
concerned Ministry/Department—Member.

(iii)

Any other Additional Secretary/Joint Secretary in the concerned
Ministry/Department—Member.

Note:

of

India

in

the

concerned

The Committee may, if considered necessary, co-opt an officer of the
Department of Personnel and Training with the approval of Secretary
(Personnel), Ministry of Personnel, Public Grievances and Pensions.
(b)

The Review Committee constituted by the State Government shall
consist—
(i)

Chief Secretary—Chairman.

(ii)

Senior most Additional Chief Secretary/Chairman, Board of
Revenue/ Financial Commissioner or an officer of equivalent rank
and status—Member.

(iii)

Secretary, Department of Personnel in the State Government—
Member Secretary.

Note: (i) The Home Secretary/Director General (Police) of the concerned States
may be co-opted wherever a case concerning a member of the Indian
Police Service is considered.
(ii) The Secretary Forest/Principal Chief Conservator of forest of the
concerned State may be co-opted wherever a case concerning a member
of the Indian Forest Service is considered by the Committee.
(iii) In States where Civil Services Board have been constituted, the State
Government may entrust the work of the Review Committee to the Board.
2. Functions:—
(a) The Review Committee/ Civil Services Board shall review the cases of
officers under suspension in order to determine whether they are of
sufficient grounds for continuation of suspensions.
(b) In every case the review shall be done within 90 days from the date of order
of the suspension. In a case where the period of suspension has been
extended, the next review shall be done within a period of 180 days from the
date of last extension.
3. Procedure :—
62

Renumbered vide Notification No.11018/3/2004-AIS-III dt.30.09.2009 (GSR No.714(E) dt. 30.09.2009)

292

<!-- page 31 -->

(a) The Review Committee/ Civil Services Board while assessing the
justification for further continuance of any suspension, shall look into the
progress of any enquiry/investigation against the officer by obtaining
relevant information from the authorities enquiring/investigating into the
charges.
(b) The Review Committee/ Civil Services Board while examining a case shall
consider the possibility of the officer under suspension tampering with the
evidence, his influencing the process of enquiry or investigation and
deprivation of his services during suspension.
(c) The Review Committee/Civil Services Board shall submit a detailed report to
the competent authority, clearly stating its recommendations and the
reasons for arriving at the recommendations relating to the continuance of
suspension.
63SCHEDULE 2

[See rule 3 sub-rule (1B), (1C) and (1D)]
1. Composition of the Review Committees.- The Central Ministry’s Review
Committee constituted by the Central Government: shall consist of –
(i)

Secretary to the Government of India in the concerned
Ministry/Department.

Chairperson

(ii)

Additional Secretary/Joint Secretary in charge of
Administration in the concerned Ministry

Member

(iii)

Any other Additional Secretary/Joint Secretary in the
concerned Ministry/Department.

Member

Note: The Committee may, if considered necessary, co-opt an officer of the
Department of Personnel and Training with the approval of Secretary
(Personnel), Ministry of Personnel, Public Grievances and Pensions.
2. Functions.- On a reference being made by the Government that has ordered
the suspension seeking extension beyond the period stipulated, the Central
Ministry’s Review Committee shall review the cases of officers under
suspension on charges other than corruption in order to determine whether
there are sufficient grounds for continuation of suspension beyond the period of
one year and review the cases of officers under suspension on charges of
corruption in order to determine whether there are sufficient grounds for
continuation of suspension beyond the period of two years.
3. Procedure:- (a) The Central Ministry’s Review Committee while assessing the
justification for further continuation of any suspension beyond the period of one
year, where the member of the Service is placed on suspension on charges
63

Inserted vide Notification No.11018/3/2004-AIS-III dt.30.09.2009 (GSR No.714(E) dt. 30.09.2009)

293

<!-- page 32 -->

other than corruption, shall look into the progress of any enquiry or
investigation against the member of the Service by obtaining relevant
information from the authorities enquiring or investigating into the charges;
(b) The Central Ministry’s Review Committee while assessing the justification
for further continuation of any suspension beyond the period of two years,
where the member of the Service is placed on suspension on charges of
corruption, shall look into the progress of any enquiry or investigation against
the member of the Service by obtaining relevant information from the
authorities enquiring or investigating into the charges;
(c) The Central Ministry’s Review Committee shall satisfy itself that the delay
has occurred for reasons beyond the control of the disciplinary authority and
reinstatement of the officer may result in his tampering with the evidence or
otherwise influencing the process of enquiry or investigation;
(d) The Central Ministry’s Review Committee shall submit a detailed report to
the Central Government, clearly stating its recommendations and the reasons
for arriving at the conclusions relating to the continuance of suspension.
STANDARD FORMS
{see rule 3(9)}
Note:—
1. The order should be signed by the competent authority himself.
2. Where an order has to be made in the name of the President of India/Governor
of a State, the phrase ‘By order and in the name of the President/Governor or State of
..............’ should be inserted above the signatures. Such an order/communication should
be signed by an officer in the appropriate Ministry/Department who is authorised under
the Constitution to authenticate the orders on behalf of the President of India/Governor
of a State.
3. The form should not be used mechanically. Wherever necessary, suitable
modifications should be made in the form to meet the requirements of a particular case.
FORM I
STANDARD FORM FOR ORDER OF SUSPENSION ORDER
Whereas a disciplinary
proceeding against Shri...
(name and designation) is
contemplated/pending
under investigation/
Inquiry/trial.

Whereas a case against
Shri......….(name and
Designation) in respect
of a criminal offence is
contemplated/pending
under investigation/
Inquiry/trial.

Now, therefore, the .......(Authority competent to place under suspension), in
exercise of powers conferred by clause(a) of sub-rule (i) of rule 3 of the All India

294

<!-- page 33 -->

Services (Discipline and Appeal) Rules,1969, hereby places the said Shri........under
suspension with immediate effect.
It is further ordered that during the period that this order shall remain in force, the
Headquarters of Shri ...... shall be............(name of place and the said Shri ............ shall
not leave the said Headquarters without obtaining the permission of the undersigned.
Signature..................
Name and Designation of the suspending authority
No............ Dated, the..................
Copy to Shri .......... (name and designation): Order regarding subsistence
allowance admissible to him during the period of his suspension will issue separately.
Note: Copies should be endorsed to the Pay and Accounts Officer who authorizes
the drawal of his salary; to the Cash and Accounts Section of the Department; to the
Establishment Section for making an entry in the Service Book; to the Appointing
Authority, if the order is made by some other authority; and to the Lending Authority in
the case of borrowed officer. The reasons for suspension should be communicated to
the Appointing Authority and the Lending Authority, separately, through confidential
letters.
FORM II
STANDARD FORM FOR ORDER OF DEEMED SUSPENSION
ORDER
WHEREAS a case against Shri.......... (name and designation of the member of the
service) in respect of a criminal offence is under investigation/inquiry/trial; AND
WHEREAS the said Shri ..........was detained in custody on ........ for a period exceeding
forty—eight hours;
NOW, THEREFORE, the said Shri..... is deemed to have been placed under
suspension by an order of the appointing authority w.e.f .............. in terms of sub
rule..............of rule 3 of the All India Services (Discipline and Appeal) Rules, 1969 until
further orders.
Signature.........................
Name and designation of the Appointing authority
Copy to Shri .............(name and designation). Order regarding subsistence
allowance admissible to him during the period of his suspension will issue separately.
Note:— Copies should be endorsed to the Pay and Accounts Officer who
authorizes the drawal of his salary; to the cash and Accounts Section of the Department;
to the Establishment Section for making an entry in the Service Book; to the Appointing
Authority, if the order is made by some other authority; and to the Lending Authority in
the case of borrowed officer. The reasons for suspension should be communicated to
the Appointing Authority and the Lending Authority, separately, through confidential
letters.

295

<!-- page 34 -->

FORM III
STANDARD FORM FOR REVOCATION OF
ORDER OF SUSPENSION
ORDER
WHEREAS an order placing Shri ...........(name and designation), under
suspension, was made/was deemed to have been made by..............on..............
Now, therefore, the President/undersigned, in exercise of the powers conferred by
Rule..........(here mention the relevant rule) hereby revokes the said order of suspension,
with immediate effect.
Signature
Name and designation of the authority competent to revoke the order of suspension
No……..

Dated, the…………………

Copy to Shri…………..(name, designation and address of the officer during
suspension).
Copies should also be endorsed to the Treasury Officer/Pay and Accounts Officer,
to the Cash and Accounts Section of the Department; to the Establishment Section for
making an entry in the Service books to the Appointing Authority, if the order is made by
some other authority; and to the lending authority (in case of a borrowed officer).

296

<!-- page 35 -->

GOVERNMENT OF INDIA’S INSTRUCTIONS/DECIONS/ORDERS
(I)

GOVERNMENT OF INDIA’S INSTRUCTIONS TO STATE GOVERNMENTS
FURNISHIG THE REVISED PROFORMA FOR TIMELY AND COMPLETE
REFERENCE TO UPSC

I am directed to invite a reference to letter No. 6/6/72—AIS(III), dated the 8th
January, 1973 issued by the Department of Personnel on the subject mentioned above,
and to say that as a sequel to the amendment of Article 311(2) of the Constitution and
the provisions contained in Rule 9, 19 and 24, of the All India Services (Discipline &
Appeal) Rules, 1969 it is no longer necessary to issue a show cause notice in cases
where the disciplinary authority proposes to impose any of the major penalties or where
it is proposed to enhance an existing penalty. As a result some changes in the proforma
to be used for consulting the Union Public Service Commission have become necessary.
It has also been found necessary to make certain modifications in items 1, 2, 4, 7, 12
and 13 of the proforma. Revised proforma which may hereafter be used for consulting
the U.P.S.C. is forwarded herewith.
2. It has been observed by the Commission that, even though the proforma clearly
provides that it should be signed by an officer of the State Government etc. making the
reference, in some cases the proforma is forwarded to the Commission without ensuring
that entries contained herein are appropriate and reflect the correct position. The
importance of making correct entries in the proforma cannot be over emphasised. It is,
therefore, requested that it may kindly be ensured that reference to the Commission in
disciplinary cases are made to the Commission in the prescribed proforma complete in
all respect, duly signed by an officer of the State Government.
[D.P & A.R. letter No. 11018/7/82—AIS (III), dated the 13th July, 1983.]
∗

ANNEXURE

Particulars relating to the disciplinary case referred to the Union Public Service
Commission
with letter No.............................
Date.............................
----------------------------------------------------------------------------------------------------*1. Name of accused officer and the Service to which he belongs.
----------------------------------------------------------------------------------------------------*2. (i)
(ii)

Whether confirmed in the Service.
Date of such confirmation.

----------------------------------------------------------------------------------------------------∗

Inserted vide DP & AR Notification No.6/9/72-AIS(III) dated 05.07.1972 (GSR No.872, dt.19.07.1975)

297

<!-- page 36 -->

3. Post held:
(a)

Designation.

(b)

Scale of Pay.

(c)

Pay Drawn.

(d)

Date from which Pay shown against (c) drawn.

----------------------------------------------------------------------------------------------------4. Date of next increment.
----------------------------------------------------------------------------------------------------5. Date of Birth.
----------------------------------------------------------------------------------------------------6. Date of Joining Govt. Service.
----------------------------------------------------------------------------------------------------7. Date when due to retire or date of actual retirement in case of persons who
have already retired.
----------------------------------------------------------------------------------------------------8. (a)
(b)

(i)

Amount of monthly pension admissible.

(ii)

Amount of monthly pension sanctioned.

(i)

Amount of gratuity admissible

(ii)

Amount of gratuity sanctioned.

(This information is required only in respect of cases of recovery from or
withholding of pension/special additional pension)
----------------------------------------------------------------------------------------------------9 (a)

Appointing authority.

(b)

Punishing authority.

(c)

Appellate authority.

10. Whether an
been held.

oral

enquiry,

if

required,

under

the

rules

has

----------------------------------------------------------------------------------------------------11. Name and designation of the Enquiry Officer, appointed, if any.
----------------------------------------------------------------------------------------------------12. Whether all the relevant documents, in original, particularly the following
have been enclosed with the letter seeking the Commission’s advice/letter
forwarding the case to the Central Government in the case of certain major
penalties, appeals and memorials).
(A) In the case of original enquiries:

298

<!-- page 37 -->

(i)

Papers relating to preliminary enquiry, if any. In case the preliminary
enquiry as done by S.P.E. their report together with all the depositions
recorded by them.

(ii)

Suspension order, if any.
(a)

Order revoking suspension, if any.

(iii)

Order of the Competent Authority for joint / common proceedings.
Where issued, if two or more Govt. servants are involved in the case.

(iv)

Charge-sheet with the statement of imputations of misconduct or
misbehaviour and other enclosures.

(v)

Reply of the accused officer to the charge sheet.

(vi)

Order of appointment of the Inquiry Officer.

(vii)

Order appointing the Presenting officer.

(viii)

Record of the oral inquiry:
(a)

Daily order sheet

(b)

Correspondence file of the Inquiry officer.

(c)

Depositions.

(d)

Questions put to the accused officer by the I.O

(e)

Statement of defence before the Inquiry officer

(f)

Written briefs of:

(g)

(i)

the Presenting Officer.

(ii)

the Charged Officer.

Inquiry Officers’ report.

(ix)

Miscellaneous documents regarding evidence such as exhibits,
statements etc. referred to in items (i) to (viii) above.

(x)

Sanction of the Central Govt. for institution of departmental
proceedings, where necessary.

(xi)

Show cause notice for withdrawing/withholding the pension.

(xii)Reply of the accused officer to the show cause notice
(B) In the case of appeals:
In addition to the documents specified under (A) above, the following:
(i)

Order of the punishing authority.

(ii)

Appeal, if any, of the accused officer.

(iii) Comments on the appeal as required under rule18(4) of the A.I.S.
(Discipline and Appeal) Rules, 1969.
(C) In the case of Memorials: or Suo Motu Review
In addition to the documents specified under (A) & (B) above, the following:

299

<!-- page 38 -->

(i)

Orders, if any, on the appeal.

(ii)

Memorial, if any, from the accused officer.

(iii) Note indicating the reasons for modifying the existing order of penalty
and precise extent of such modification.
----------------------------------------------------------------------------------------------------13. Miscellaneous documents such as extracts of relevant Rules, Codes Acts,
Judgements, Manuals etc., referred to in the charge-sheet, statement of
allegations, statement of defence, Inquiring Authority’s Report, reply to show
cause notice, appeal, State Government’s comments.
----------------------------------------------------------------------------------------------------14. In case where no enquiry has been held and factual and procedural points
have been raised in the officer’s explanation.
A note explaining such points.
----------------------------------------------------------------------------------------------------15. Whether comments on procedural points, if any raised by the officer in his
explanation to the charge sheet/reply to show cause notice/appeal, have
been given.
----------------------------------------------------------------------------------------------------16. Whether complete and up to date confidential roll of the officer has been
enclosed.
----------------------------------------------------------------------------------------------------Signature _________________________
Name in Block Letters of officer of the State Govt. signing the statement: ____________
Designation ___________________
Date ___________________
Telephone Number _________________
II

INSTRUCTIONS TO STATE GOVERNMENTS TO KEEP IN MIND THE
JUDGEMENT OF SOME COURT CASES ON THE QUESTION OF STANDARD
OF PROOF IN DEPARTMENTAL PROCEEDINGS.

1. A copy of the Ministry of Home Affairs’ D.O. Letter No. 24/25/62-AVD, dated 26-51962 along with extracts from some judgements of High Courts which were circulated
among Vigilance Officers to apprise them of the establishment law on the question of
“standard of proof” in departmental enquiries against Government servants is enclosed.
The same issue came up for consideration before the Supreme Court in the case of
India Vs. Sardar Bahadur (1972). A copy of the judgement of the Supreme Court in this
case is also enclosed.

300

<!-- page 39 -->

2. It is requested that State Governments may kindly keep in mind the observations of
the Supreme Court, especially the observations of the Court reproduced below, while
dealing with disciplinary cases against the members of the All India Services:—
(i) “A disciplinary proceedings is not a criminal trial. The standard of proof required
is that of preponderance of probability and not proof beyond reasonable doubt.”
(ii) “A finding cannot be characterised as perverse or unsupported by any relevant
materials if it is a reasonable inference from proved facts.” This observation has
been made in the context of the facts as stated in para 14 of the judgement.
(iii) Where there are some relevant materials which the authority has accepted and
which materials may reasonably support the conclusion that the officer is guilty, it
is not the function of the High Court exercising its jurisdiction under Article 226 to
review the materials and to arrive at an independent finding on the materials. If
the enquiry has been properly held the question of adequacy or reliability of the
evidence cannot be canvassed before the High Court.
(iv) “Now it is settled by the decision of this Court in State of Orissa V. Vidyabhushan
Mahapatra (6) that if the order of punishing authority can be supported on any
finding as to substantial misdemeanour for which the punishment can be
imposed, it is not for the Court to consider whether charge proved alone would
have weighed with the authority in imposing the punishment. The Court is not
concerned to decide whether the punishment imposed, provided it is justified by
the rules, is appropriate having regard to the misdemeanour established.”
[D.P. & A.R. letter No. 11018/2/75—AIS(III), dated 30th June, 1975.]
Copy of D.O. No. 24/75/62-AVD, dated 26-5-1962.
1. You may perhaps be aware of the decisions of certain courts in which it has been held
that officers holding inquiries in departmental proceedings are not under any obligation
to follow strictly the rules of evidence as laid down in the Evidence Act or the procedure
prescribed in the Criminal Procedure Code. In this connection, I forward herewith
relevant extracts from the judgements of the courts for your information.
2. I shall be grateful, if you would kindly bring these decisions to the notice of all
authorities dealing with disciplinary cases, as the principle of these decisions, if followed,
should enable the competent authority to deal with disciplinary cases more
expeditiously. ******** (All Vigilance Officers)

III.

VIOLATION OF RULE 20 OF THE AIS(CONDUCT) RULES, 1968 REGARDING
CONSUMPTION OF ALCOHOL BEVERAGES IS A GOOD AND SUFFICIENT
REASON FOR TAKING DISCIPLINARY ACTION

1. The provisions contained in rule 20 of the All India Services (Conduct) Rules, 1968,
are of special importance in the context of the latest endeavor to reduce the
consumption of alcoholic beverages and drugs. While it is expected that every member
of the All India Services will scrupulously adhere to the provisions of the All India
Services (Conduct) Rules, 1968, mentioned above, it is also expected of the disciplinary

301

<!-- page 40 -->

authorities to keep a strict watch on the conduct of members of the All India Services in
regard to matters covered by the aforesaid Rules. Violation of any of the provisions of
rule 20 of the All India Services (Conduct) Rules, 1968 will constitute a good and
sufficient reason for taking disciplinary action against a member of the All India Service.
While any of the penalties specified in rule 6 of the All India Service (Discipline and
Appeal) Rules, 1969 can be imposed on a member of an All India Service for good and
sufficient reasons after following the prescribed procedure, the disciplinary authorities
should take a very serious view of any violation of rule 20 of the All India Services
(Conduct) Rules, 1968,and should not hesitate to impose the severest punishment on
such members of the All India Services who are proved guilty of violating the said Rule.
2. I am to request that the contents of this letter may be brought to the notice of all
members of the All India Services working under the State Government.
[Extract of letter No. 11017/1/76—AIS(III), dated 5-2-76.]
IV.

PROVIDING LEGAL AND FINANCIAL ASSISTANCE TO RETIRED
GOVERNMENT SERVANT-EXTENSION OF GOI O.M.No. 28022/1/75—
Estt.(A), DATED THE 20TH JANUARY, 1977 TO MEMBERS OF THE ALL
INDIA SERVICES.

1. The instructions contained in this Department’s Office Memorandum No.
28022/1/75—Estt.(A), dated the 20th January, 1977, are extended to the retired
members of the All India Services.
[letter No. 11018/3/77-AIS(III), dated 29-4-77.]
(i) Copy of D.P. & A.R. letter No. 28022/1/75—Estt.(A), dated 20th January, 1977
1. A question has been raised whether, and if so, under what circumstances,
Government should provide legal and financial assistance to a retired Government
servant for the conduct of legal proceedings instituted against him by a private party in
respect of matters connected with his official duties or position before his retirement.
This has been considered by the Government and it has been decided that the
provisions contained in paragraph 2(c) of the Ministry of Home Affairs’ O.M.No. 45/5/53Estt(A), dated 8th January, 1959. (Copy enclosed) should be extended also to be retired
Government servants. Accordingly, the provisions contained in the aforesaid paragraph,
with the exception of the provision regarding grant of advance from Provident Fund, will
apply also to Government servants who have retired from service other than those who
have been compulsorily retired from service as a measure of punishment. Further, the
amount of interest free advance that may be granted to a retired Government servant
will be subject to a maximum limit of Rs. 500/-.
2. The form of declaration to be obtained from a retired Government servant when the
Government undertakes his defence and the form of Bond to be obtained from him, if
advance is granted to cover legal expenses, are enclosed as Annexure ‘A’ and ‘B’ to this
Office Memorandum.
3. The provisions regarding consultation with Union Public Service Commission and the
authority competent to take decision in each case will be the same as those contained in
Ministry of Home Affairs Office Memorandum dated 8th January, 1959.
(ii) Copy of MHA O.M. No. 45/5/53—Est(A), dated 8-1-59.

302

<!-- page 41 -->

1. A question has been raised whether, and if so, under what circumstances,
Government should provide legal and financial assistance to a Government servant for
the conduct of legal proceedings by or against him. The following decisions which have
been taken in consultation with the Ministries of Law and Finance and the Comptroller
and Auditor General are circulated for information and guidance.
2.

(a) Proceedings initiated by Government in respect of matters connected
with official duties or position of the Government servant.
Government will not give any assistance to a Government servant for his
defence in any proceedings, civil or criminal instituted against him by the
State in respect of matters arising out of or connected with his official duties
or his official position. Should, however the proceedings conclude in favour
of the Government servant, Government will entertain his claim for
reimbursement of costs incurred by him for his defence, and if Government
are satisfied from the facts and circumstances of the case that the
Government servant was subjected to the strain of the proceedings without
proper justification they will consider whether the whole or any reasonable
proportion of the expenses incurred by the Government servant for his
defence should be reimbursed to him.
(b)

Proceedings in respect of matters not connected with official
duties or position of the Government servant.

Government will not give any assistance to a Government servant or
reimburse the expenditure incurred by him in the conduct of proceedings in
respect of matters not arising out of, or connected with, his official duties or
his official position, irrespective of whether the proceedings were instituted
by a private party against the Government servant or vice versa.
(c)

Proceedings instituted by a private party against a Government
servant in respect of matters connected with his official duties or
position.
(i)

If the Government on consideration of the facts and circumstances
of the case consider that it will be in the public interest that
Government should themselves undertake the defence of the
Government servant in such proceedings and if the Government
servant agrees to such a course, the Government servant should
be required to make a statement in writing as in Annexure A and
thereafter Government should make arrangements for the conduct
of the proceedings as if the proceedings had been instituted
against Government.

(ii)

If the Government servant proposes to conduct his defence in
such proceedings himself, the question of reimbursement of
reasonable costs incurred by him for his defence may be
considered in case the proceedings conclude in his favour. In
determining the amount or costs to be so reimbursed,
Government will consider how far the Court has vindicated the
acts of the Government servant. The conclusion of proceedings in

303

<!-- page 42 -->

favour of the Government servant will not by itself justify
reimbursement.
To enable the Government servant to meet the expenses of his
defence, Government may sanction, at their discretion, an interest free
advance not exceeding Rs.500/- or the Government servant’s
substantive pay for three months, whichever is greater, after obtaining
from the Government servant a bond in the form reproduced as
Annexure B. The amount advanced would be subject to adjustment
against the amount, if any, to be reimbursed as above.
The Government servant may also be granted any advance from any
Provident Fund to which he is a subscriber not exceeding three
months’ pay or one half of the balance standing to his credit, whichever
is less. This advance will be repayable in accordance with the rules of
the Fund.
(d)

Proceedings instituted by a Government servant of his being
required by Government to vindicate his official conduct.

A Government servant may be required to vindicate his conduct in a
Court of Law in certain circumstances, [vide Ministry of Home Affairs
O.M. No. F. 25/32/54-Estt(A), dated 8th January, 1959]. The question
whether costs incurred by the Government servant in such cases
should be reimbursed by the Government and if so; to what extent
should be left over for consideration in the light of the result of the
proceedings. Government may, however, sanction an interest-free
advance, in suitable instalments, of any amount to be determined by
them in each case on the execution of a bond by the Government
servant in the form reproduced in Annexure B.
In determining the amount of costs to be reimbursed on the conclusion
of the proceedings, the Government will consider to what extent the
Court has vindicated acts of the Government servant in the
proceedings. Conclusion of the proceedings in favour of the
Government servant will not by itself justify reimbursement.
(e)

Proceedings instituted by a Government servant suo motu,
with the previous sanction of Government to vindicate his
conduct arising out of or connected with his official duties or
position.

If a Government servant resorts to a Court of Law with the previous
sanction of Government to vindicate his conduct arising out of or
connected with his official duties or position, though not required to do
so by Government, he will not ordinarily be entitled to any assistance
but Government may, in deserving cases, sanction advances in the
manner indicated in sub-para c(ii) above, but no part of the expenses
incurred by the Government servant will be reimbursed to him even if
he succeeds in the proceedings.

304

<!-- page 43 -->

3. Clause (d) of article 320(3) of the Constitution requires consultation with the Union
Public Service Commission on any claim of Government servant for the reimbursement
of the costs incurred by him in defending legal proceedings instituted against him in
respect of acts done or purporting to be done in the execution of his duty. In other cases
consultation with the Union Public Service Commission is not obligatory, but it will be
open to Government to seek the Commission’s advice, if considered necessary.
4. The question whether a case falls under article 320(3)(d) of the Constitution so as to
require consultation with the Commission may at times be difficult to determine. It may
be stated generally that the consultation is obligatory in a case where a reasonable
connection exists between the act of the Government servant and the discharge of his
official duties. The act must bear such relation to the official duties that the Government
servant could lay a reasonable but not a pretended or a fanciful claim that he did it in the
course of the performance of his duties.
5. The appropriate authority for taking decision in each case will be the administrative
Ministry of the Government of India concerned who will consult the Finance and Law
Ministries, where necessary. The Comptroller and Auditor General of India will exercise
the powers of an administrative Ministry in respect of the personnel of the Indian Audit
and Accounts Department.
6. In so far as persons serving in the Indian Audit and Accounts Department are
concerned, these orders are issued in consultation with the Comptroller and Auditor
General.
ANNEXURE A
(Here enter description of the proceedings)
The Government of India having been pleased to undertake my defence in the
above proceedings, I hereby agree to render such assistance to Government as may be
required for my defence and further agree that I shall not hold Government in any way
responsible if the proceedings end in a decision adverse to me.
Date................................
Signature of the retired Government servant.
ANNEXURE B
BY THIS BOND 64I __________________ ________________ a retired
Government servant at present residing at ____________________ having taken an
advance of Rs _________________(Rupees _________________ only) from the
President of India (hereinafter called the “Government”) promise and undertake to refund
and pay to the Government the said sum of Rs. _________ in ____________
64

Here give the name and other particulars of the retired Government servant including the post held by him before
retirement

305

<!-- page 44 -->

____________ 65equal monthly ______________ instalment ___________ of Rs.
____________________ payable by the 10th of every month commencing from
__________________ 66 ____________________.
2. And I agree that in case I fail to pay any of the above mentioned instalment on
due date, the entire balance of the amount then remaining due shall at once become
due and payable by me to the Government and if I fail to pay the same within six months
from the date on which the balance of the amount thus becomes due for payment, the
Government shall have the right to recover the same from me by due process of Law.
Dated this ________________ day of ________________ 20 .

(Signature of the retired Government servant)
Witness to signature.
Accepted.
1. _____________________
2. _____________________

67

Signature

(Designation)
for and on behalf of the President of India.
V.

CONDITIONS PRESCRIBED FOR A MEMBER OF THE SERVICE TO TAKE
THE ASSISTANCE OF A RETIRED GOVERNMENT SERVANT.

1. In pursuance of the provision contained in clause(b) of sub-rule (9) of rule 8 of the All
India Services (Discipline and Appeal) Rules, 1969, the President hereby prescribes the
following conditions subject to which a member of the Service may take the assistance
of a retired Government servant to present the case on his behalf:
Sub para (i) & (ii)—Deleted68
(i) No retired Government servant can take up more than three cases at a time.
At the time of appearance before the Inquiry Officer, the retired Government
servant should certify that he has only three cases on hand at that time.
(ii) A retired Government servant cannot assist a member of an All India
Service in disciplinary proceedings after the expiry of three years from the
65

Here mention the number of instalments
Here mention the date of commencement of the first installment.
67
Here mention the designation of the officer who is authorized to execute the bond under article 299(!) of the
constitution.
68
Vide DP&T letter No.11018/5/86-AIS(III)dated 20.01.1987
66

306

<!-- page 45 -->

date of retirement. The retired Government servant should produce before
the Inquiry Officer, a declaration regarding his date of retirement.
(iii) If the retired Government servant is also a legal practitioner, the restrictions
on engaging a legal practitioner by a delinquent Government servant to
present the case on his behalf as contained in rule 8(9) of the All India
Services (Discipline and Appeal) Rules, 1969, would apply.
(iv) In the matter of payment of travelling and other expenses to the retired
Government servant assisting a member of the Service in disciplinary
proceedings, the instructions contained in the Ministry of Home Affairs
Office Memorandum No. 16/122/56—AVD, dated the 18th August, 1960 will
apply. The retired Govt. servant concerned will be deemed to belong to the
grade of Government servants to which he belonged immediately before his
retirement, for the purpose of these instructions. The expenditure on
account of travelling and other expenses will be borne by the State
Government/ Department to which the delinquent Govt. servant belongs.
Explanation.—Any person, who has retired from service under the Central
Government, or the Government of a State or a Union Territory may be engaged by the
member of the Service to assist him in the disciplinary proceedings.
2. The decision contained in this letter may be brought to the notice of all concerned.
[DP&AR, letter No. 11018/12/78—AIS(III), dated the 14th August, 1978.]
VI.

GUIDELINES TO BE FOLLOWED FOR ADHERING THE TIME LIMITS OF
COMPLETION OF VARIOUS STAGES OF DISCIPLINARY PROCEEDINGS
FOR EXPEDITIOUS DISPOSAL

1. Time limits for completing certain stages of inquiry into charges against members of
the All India Services are laid down in sub-rule (8) and (12) of rule 8 of the All India
Services (Discipline and Appeal) Rules, 1969. However, experience has shown that very
often, disciplinary proceedings are inordinately delayed. It is felt that if the guidelines laid
down below are followed, it will ensure expeditious disposal of disciplinary cases.
2. Sub-rule (8) of rule 8 provides that a member of the Service shall be required to
appear in person before the Inquiring Authority at any time prescribed after the expiry of
10 working days from the date of the receipt of the charge-sheet. It would therefore, be
justified if the charged officer is given not more than 10 days for submitting his written
statement of defence in reply to the charge-sheet under sub-rule (5) of rule 8 ibid.
2. 1The statement of defence under rule 8(5) ibid is expected to be limited simply to
admitting or denying the charges communicated to the officer, and for such admission or
denial inspection of documents is not necessary. Therefore, a request for inspection of
documents at this stage made by the delinquent officer may not be accepted and it may
be explained to the officer that he would get full opportunity to inspect the listed
documents during the course of inquiry as per rule 8(12) ibid.
2.2. Although no time limit, as such, has been stipulated for the admission of the report
by the Inquiry Officer after completion of the oral inquiry, ordinarily it should be possible
for an Inquiry Officer to submit the inquiry report within a period of one month from the
conclusion of the inquiry proceedings.

307

<!-- page 46 -->

2.3 If these time limits and principles are assiduously observed, the period from the date
of serving a charge-sheet in a disciplinary case to the submission of the report by the
Inquiring Officer should ordinarily not exceed six months.
3. After submission of the Inquiry Report by the Inquiring Officer, where the State
Government comes to the conclusion that a major penalty may be imposed on an officer,
they may issue a show cause notice to the officer, or remit the case to the Central
Government under rule 8(22) (a) ibid, as the case may be, within one to one and a half
months from the receipt of the inquiry report. In cases where the State Government
considers that a minor penalty would be enough, a reference to the U.P.S.C. may also
be made for their advice, within one to one and a half months of the receipt of the inquiry
report.
4. While processing disciplinary cases against members of the All India Services, the
guidelines mentioned above may be kept in view for completion of inquiries promptly.
The State Government may also consider the desirability of issuing suitable instructions
and that where a case is delayed at a particular stage beyond the time-limit stipulated for
that stage, it be reported to the next higher authority with a statement of reasons for the
delay.
[D.P. & A.R. letter No. 11018/7/78—AIS(III), dated 16-8-1978.]
VII.

PROCEDURE TO BE FOLLOWED UNDER RULE 8(20) OF THE AIS(D&A)
RULES

1. I am directed to forward herewith a copy of this Department’s Office Memorandum No.
11012/18/77—Ests(A), dated the 2nd September, 1978 and to state that rule 14(19) of
C.C.S. (C.C. & A) Rules, 1965 corresponds to sub rule (20) of rule 8 of the All India
Services (Discipline and Appeal) Rules, 1969.
2. The clarification contained therein may please be brought to the notice of all
concerned. With regard to its application in respect of sub-rule (20) of rule 8 of the AIS
(D&A) Rules, 1969.
[Letter No. 11018/19/78—AIS (III), dated 15th January, 1979.]
Office Memorandum No. 11012/18/77—Est(A), dated 2nd September, 1978.
SUBJECT:

CCS (CCA) Rules, 1965—Procedure to be followed under rule 14(19)
thereof.

1. The undersigned is directed to say that according to rule 14(19) of the CCS (CCA)
Rules, 1965 the inquiring authority may, after the completion of the production of
evidence, hear the Presenting Officer, if any appointed, and the Government servant or
permit them to file written briefs of their respective cases, if they so desire. With
reference to this rule, a question has been raised whether the written brief filed by the
Presenting Officer should be made available to the accused Government Servant before
he files his own written brief. The matter has been examined in consultation with the
Ministry of Law and the position is explained in the succeeding paragraph.
2. It will be seen from the phraseology of rule 14(19) that the inquiring authority has to
hear arguments that may be advanced by the parties after their evidence has been
closed. But he can, on his own or on the desire of the parties, take written briefs. In case
he exercises the discretion of taking written briefs, it will be but fair that he should first

308

<!-- page 47 -->

take the brief from the Presenting Officer, supply a copy of the same to the Government
Servant and then take the reply brief from the Government Servant. In case the copy of
the brief of the Presenting Officer is not given to the Government Servant, it will be like
hearing arguments of the Presenting Officer at the back of the Government servant. In
this connection, attention is also invited to the judgment of the Calcutta High Court in the
case of Collector of Customs Vs. Mohd Habibul (SLR 1973 (1) Calcutta, 321) in which it
is laid down that the requirement of rule 14(19) of the CCS (CCA) Rules, 1965 and the
principles of natural justice demanded that the delinquent officer should be served with a
copy of the written brief filed by the Presenting Officer before he is called upon to file his
written brief.
3. Ministry of Finance etc., are requested to bring the above clarification to the notice of
all concerned authorities under their control.
VIII.

PROCEDURE FOR INTIMATION OF DISCIPLINARY PROCEEDINGS
AGAINST THE OFFICERS OF THE ALL INDIA SERVICES SERVING UNDER
THE GOVT. OF INDIA AND ORGANIZATIONS UNDER THE GOVT. OF INDIA.

1. Rule 7 of the AIS(Discipline & Appeal) Rules, 1969 stipulates the authority competent
to institute proceedings and to impose penalty on the members of the All India Services.
The said rule vests this authority either with the State Government or with the Central
Government depending upon the circumstances explained therein. Powers of the
Central Government in respect of members of the IAS while they are on deputation with
the Central Government are exercised by the Department of Personnel & Training and in
respect of Indian Police Service and IFS Ministry of Home Affairs and Ministry of
Environment & Forests respectively.
2. With a view to avoiding delay in the processing of cases in respect of members of All
Service pertaining to the period of their central deputation the following procedure may
be followed while forwarding such cases to the cadre controlling authority, namely
Department of Personnel & Training/MHA/ Ministry of Environment & Forests, as the
case may be:—
(i) Any proposal to place an officer under suspension should be sent to the Cadre
controlling Department only with the approval of the Minister in charge of the
Department/Ministry administratively concerned.
(ii) Any proposal to initiate disciplinary proceedings should be forwarded only after a
decision has been taken at the level of the Minister in charge of the
Department/Ministry after obtaining the preliminary explanation of the officer and
after considering the same. In cases having a vigilance angle, administrative
Ministries/Departments are also required to consult the Central Vigilance
Commission and obtain its first stage advice before submitting the papers to the
Minister.
(iii) If an officer is transferred to another Ministry/Department, the Ministry concerned
where the alleged misconduct was committed by the officer will have to take a
view on the case in the light of the facts of the case and the explanation of the
concerned officer at the level of the Minister before forwarding the case records
for further necessary action. They must also give an intimation in this regard to
the Ministry where the officer may be working for the time being.

309

<!-- page 48 -->

(iv) Where it is proposed to initiate disciplinary proceedings, the proposal shall
always be accompanied by a draft charge sheet along with imputations of
misconduct and two sets of certified list of documents.
(v) In cases where it is decided not to formally proceed against an officer but only to
convey a caution/waning/displeasure of the Government, this will be
communicated to the officer by the Ministry/Department concerned, through the
administrative Ministry where he may be working at that time and two copies of
the same shall be endorsed to the respective cadre controlling Department for
record.
(vi) In a case, where there is no full fledged investigation by the CBI and where
formal action for major penalty is instituted by the concerned cadre controlling
Ministry after due consideration of a proposal received from the administrative
Ministry or otherwise, the administrative Ministry shall also nominate an officer
who is well versed with the facts of the case for being appointed as the
Presenting Officer.
(vii) All communications meant for the officers proceeded against would be served
through the Ministry/Department where the officer is working for the time being.
3. It may be ensured that the above procedure is followed while referring cases of
members of the All India Services to the cadre controlling Ministries namely, Department
of Personnel & Training, Ministry of Home Affairs and Ministry of Environment & Forests,
for initiation of Disciplinary Proceedings under the AIS(D&A) Rules.
[O.M. No.11018/3/98—AIS(III) the 9th June 1995 of Ministry of Personnel, PG.& D/o
Pension (D/o Personnel & Trg.)]
IX.

DISCIPLINARY PROCEEDINGS AGAINST THE MEMBERS OF THE ALL
INDIA SERVICES MAY BE CLOSED IN THE EVENT OF HIS/HER DEATH
DURING THE PENDENCY OF ENQUIRY

1. I am directed to say that this Department has been receiving references seeking
clarifications whether disciplinary cases initiated under the All India Services (Discipline
& Appeal) Rules, 1969 should be closed in the event of the death of the accused
member of the All India Services during pendency of the proceedings.
2. After careful consideration of the issues involved, it has been decided that where a
member of the All India Service dies during the pendency of enquiry, i.e. without charges
being proved against him, imposition of any of the penalties prescribed under the All
India Service (Discipline & Appeal) Rules, 1969, would not be justifiable. Therefore,
disciplinary proceeding should be closed immediately on the death of the alleged
member of the Service.
[DOPT letter No. 11018/1/99-AIS(III) dated 14.5.1999]
X.

EXTRACTS OF THE JUDGEMENTS OF HIGH COURTS ON DEPARTMENTAL
PROCEEDINGS
Extracts from judgements of High Courts
A.I.R. 1958 Punjab 27.

310

<!-- page 49 -->

It has been argued on behalf of the petitioner that an Inquiry Officer performs in the
course of inquiry quasi—judicial functions and the proceedings held by him are in the
nature of criminal or at least quasi—criminal proceeding, and, therefore, he must
comply, at least in substance, with the provisions of S.173(4) of the Criminal Procedure
Code.
It is, therefore, necessary to determine the nature of the inquiry held under the
Punjab Civil Services (Punishment and Appeal) Rules, 1952. It is stated before me that
the charges which the petitioner has been called upon to meet are in substance the
same as will be covered by S.5(2) of the Prevention of Corruption Act, and Sections 161
and 109 of the Indian Penal Code, and I shall decide this case on this assumption.
Rule 7(2) lays down the procedure, which should be observed in the course of an
inquiry.
The Punjab Civil Services Rules are only statutory rules regulating terms of service
between the Government and its employees. The identical Rules called the Civil
Services (Classification, Control and Appeal) Rules and also the provisions of the Public
Servants (Inquiries) Act, 1850, were discussed by their Lordships of the Supreme Court
in S.A. Venkataraman V/s Union of India, A.I.R. 1954 SC 375 (A).
Their Lordships held that the purpose of such an inquiry is merely to hold the Govt.
to come to a definite conclusion regarding the conduct of a Government servant and to
decide what penalty, if any, should be imposed upon him. There is no other purpose
which is served y this inquiry. The Inquiry Officer is appointed merely to find facts and it
is clear from the Rules that it is not the Inquiry officer’s concern whether the facts
established disclosed the commission of a criminal offence punishable under the Indian
Penal Code or any other law, or they disclose liability to imposition of penalties like
censure or reduction in rank, or dismissal.
He merely sends his report to the proper authority who may or may not accept his
conclusions on facts found by him on the evidence produced before him. In these
circumstances it is impossible to hold that proceedings before the Inquiry Officer are of
criminal or quasi-criminal nature. Obviously such proceedings cannot be said to be
criminal proceedings governed by the terms and provisions of the Criminal Procedure
Code. The Inquiry Officer is not a Court within the Criminal Procedure Code, nor is the
Govt. servant accused of any offence, nor is he liable to be sentenced for the
commission of an offence under any penal law.
These proceedings cannot be said to be of quasi-criminal in nature because the
ultimate effect of these proceedings at the most is dismissal of the Government servant
from service and the imposition of this penalty cannot be held to be of criminal nature.
There is no provision in these rules which makes it incumbent on the Inquiry Officer to
hold enquiry in accordance with the procedure laid down in the Criminal Procedure Code
or to observe the provisions of S. 173(4) of that Code.
In this view of the matter it cannot possibly be held that the Inquiry officer is bound
to see that the provisions of Section 173(4) are observed before he proceeds to record
evidence in the inquiry. If an Inquiry Officer refuses to comply with the provisions of
Section 173(4), then it cannot be held that it is liable to be set aside by this Court in the
exercise of jurisdiction conferred upon it under Article 226 of the Constitution.
A.I.R. 1958, Allahabad

311

<!-- page 50 -->

As a broad proposition of law that in a disciplinary enquiry the rules of procedure for
a Court need not be observed and the rules of evidence need not be strictly followed
cannot be disputed, but all the facts of the case will have to be examined. The breach of
the rules of evidence which may be nothing but rules of natural justice may be relevant
in connection with the question as to whether sufficient opportunity was or was not given
to a petitioner in a particular case to show-cause against the charges.
A.I.R. 1958, Calcutta 470
It is true that so far as departmental proceedings are concerned, they are not
governed by the Indian Evidence Act, in other words, the strict provisions laid down in
the Indian Evidence Act are not applicable to departmental proceedings. Nevertheless,
the proceedings are subject to rules of natural justice. The question, therefore, is as to
what principle of natural justice is involved in such a case. The rules of natural justice
are not codified and cannot be stated with exactitude. In departmental proceeding, it is
unnecessary to import the strict procedure applicable to judicial trials. But where the
departmental enquiry consists of the trial, which the punishing authority either by himself
or through his delegate has a statutory duty to hear the delinquent or his witnesses, the
procedure adopted is to a certain extent like a judicial trial and it is an open question as
to whether such proceedings are purely administrative or are to be considered as
quasi—judicial. Be that as it may, if the enquiring authority has the duty to come to a
conclusion as to the guilt of the delinquent upon an evaluation or assessment of the
evidence, then it is entirely necessary that he should be the person who should hear the
evidence of the witnesses. It is impossible to evaluate the evidence of a witness taken
on proxy because one of the salient features in such a proceeding is to observe the
demeanor of the witness. As it has been said, even the devil doth not know the mind of
man, and, therefore, to arrive at the truth, it is necessary not only to read the evidence
but to see the demeanor of the person giving evidence, and where necessary to elicit
answer to doubtful points. To any one conversant with such trials, it is but an elementary
proposition that the demeanor of a witness is the most important element is assessing
the value of his evidence. The evidence of a witness, which might sound all right on
paper, may be rendered useless by observing his demeanor.
SUPREME COURT OF INDIA
Before:— C.A. Vaidialingam, P. Jaganmohan Reddy and K.K. Mathew, JJ.
Civil Appeal No. 1758 of 1970
Decided on 28.10.1971.
Union of India…….(Appellant)
Versus
Sardar Bahadur…..(Respondent)
JUDGEMENT
MATHEW J.— This is an appeal by Special leave filed by the Union of India from
the Judgement in appeal clause 10 of Letters Patent of the Delhi High Court confirming
the decision of a learned Single Judge allowing Civil Writ No. 716—D of 1964 filed by
the Respondent by quashing the order made by the President on 23rd April, 1963
compulsorily retiring the Respondent from service.

312

<!-- page 51 -->

2. The Respondent, Shri Sardar Bahadur, was employed as a Section Officer in the
Ministry of Commerce and Industry in the Steel and Cement Section (B) which along
with other Sections like Industries Act and Industrial Polices etc. was under the control of
Shri P.S. Sundaram, Deputy Secretary in that Ministry at that time.
3. In April, 1956, the Ministry invited applications for grant of licenses to set up steel
re-rolling mills.
4. On June 14, 1956, one Shri Nand Kumar representing Messrs. Ram Sarup Mam
Chand and M/s. Mam Chand and Company of Calcutta applied for five licenses to set up
steel re-rolling Mills. He also handed over on June 23, 1956 to the respondent a cheque
for Rs.2,500/- drawn on the Punjab Co-operative Bank Limited in favour of Shri P.S.
Sundaram. The cheque was certified by the Bank as good for payment up to September
24, 1956. At the back of the cheque, there was a signature which purported to be that of
Shri P.S. Sundaram. It may be noted at this stage that Shri P.S. Sundaram, the Deputy
Secretary had denied the signature to be his. Above the signature the respondent wrote
the words:—
“Please pay to Shri Sardar Bahadur”.
Lower down the respondent wrote the following words:—
“Please collect and credit the amount into my account. First payee’s endorsement
may kindly be guaranteed on my behalf and risk”.
This cheque was duly sent to the account of the respondent and the amount of
Rs.2,500 was credited to his account in the State Bank of India, New Delhi.
5. The respondent was prosecuted by the Special Police Establishment on the
allegations that the amount covered by the cheque was taken by him as illegal
gratification for using his official position illegally and in a corruption manner in order to
procedure licenses for Messrs. Ram Sarup Mam Chand of Calcutta who had filed
applications in that behalf and that the signature of Shri P. S. Sundaram had been
forged by him. The respondent was charged with offences punishable under Section
5(2) read with Section 5(1)(d) of the Prevention of Corruption Act, 1947 and Sections
161, 467 and 471 of the Indian Penal Code. The respondent was acquitted of all the
charges on June 20, 1960. Therefore, it was proposed to hold an inquiry against him
under Rule 15 of the Central Civil Services (Classification, Control and Appeal) Rules,
1957 on the basis of the following charges:—
1. “That he failed to in form Shri P.S. Sundaram, Deputy Secretary, Ministry of
Commerce and Industry, New Delhi, that a cheque for Rs.2,500 in the name of
Shri Sundaram had been issued by Shri and Kumar of Messrs. Ram Sarup
Mam Chand and Messrs. Mam Chand & Company of Calcutta, whose
applications for grant of licenses for establishing steel re-rolling mills were
pending in the Ministry of Commerce and Industry. As security
in connection with the said applications when he knew that no such deposit
was to be made;
2. That he failed to inform Shri P.S. Sundaram that the said Shri Nand Kumar had
given him a cheque bearing Shri Sundaram’s signature and had asked him to
deposit it in his account which he had done after asking the bank (instead of
showing the cheque first to Shri Sundaram himself) to guarantee the said
signature of Shri Sundaram; and

313

<!-- page 52 -->

3. That he borrowed a sum of Rs.2,500 (the amount covered by the cheque
referred to above) from the said Shri Nand Kumar, without obtaining previous
sanction of the Government and placed himself under pecuniary obligations to
the extent of Rs.2,500 and thereby also contravened rule 13(5) of the Civil
Services (Conduct) Rues, 1955”.
6. The enquiry was held and the Inquiring Officer found that the first two charges
were not proved as the identity of P.S. Sundaram, the payee of the cheque, had not
been established with Shri P.S. Sundaram, Deputy Secretary. But the Inquiring Officer
found that the third charge has been proved.
7. The findings of the Inquiring Officer on the first two charges were not agreed to
by the Deputy Secretary, Ministry of External Affairs, exercising the powers of the
President. He found that all the charges had been proved. The President after
consultation with the Union Public Service Commission passed an order on April 22,
1968 holding that the charge of gross mis-conduct and failure to maintain absolute
integrity and devotion to duty as a Government servant had been substantially proved
against the respondent and imposed the penalty of compulsory retirement on him. The
respondent was directed to be retired from service with immediate effect.
8. It was this order, which was quashed by the Single Judge in the write petition
filed by the respondent. The Letters Patent Appeal against the order filed by the Union
of India before the Division Bench was dismissed.
9. It was contended on behalf of the appellant that the Inquiring Officer went wrong
in finding that charges Nos. 1 and 2 had not been proved and that the President was
right in holding that these charges had been proved and therefore, the High Court should
have found that charges Nos. 1 and 2 were proved, as there was evidence to support
the charges. It was contended that the Inquiring Officer wrongly rejected the copies of
the statements of the witnesses examined in the criminal trial, which statements if
admitted would have fully established the first two charges against the respondent.
Counsel for the appellant argued that the provisions of the Evidence Act are not
applicable to disciplinary proceedings and therefore the statements of the witnesses in
the criminal trial ought to have been admitted and relied on for establishing the guilt of
the respondent on the first two charges. Counsel relied on the following observations of
Venkatrama Iyer, J. in Union of India V. Verma(1).
“Now it is no doubt true that the evidence of the Respondent and his witnesses was
not taken in the mode prescribed in the Evidence Act; but that Act has no application to
enquiries conducted by tribunals even though they may be judicial in character. The law
requires that such Tribunals should observe rules of natural justice in the conduct of the
Inquiry and if they do so, their decision is not liable to be impeached on the ground that
the procedure followed was not in accordance with that which obtains in Court
of Law”.
In M/s. Bareilly Electricity Supply Co. Ltd. V. The Workmen and others (2), the
scope of the above, observation was considered and this is what Jaganmohan Reddy, J.
said:
“But the application of principle of natural justice does not imply that what is not
evidence can be acted upon. On the other than what it means is that no materials can
be relied upon to establish a contested fact which are not spoken to by persons who are
competent to speak about them and are subjected to cross-examination by the party
against whom they are sought to be used. When a document is proceeded in a Court or

314

<!-- page 53 -->

a Tribunal the questions that naturally arise is, is it a genuine document, what are its
contents and are the statements contained therein true”.
10. We do not think that the statements should have been received in evidence as
the appellant had taken no step to produce the persons who made the statements for
cross-examination of the respondent. It was the duty of the appellant to have produced
these persons whose statements were sought to be proved for the cross-examination of
the respondent. In State of Mysore V. S.S. Makasur (3), this Court said that the purpose
of an examination in the presence of a party against whom an enquiry is made, is
sufficient is recalled, that statement is put to him, and made known to the opposite party,
and the witness is tendered for cross-examination by that party. As the persons whose
statements were sought to be relied on were in Delhi and as they were not produced and
tendered for cross-examination by the respondent, we think that the Inquiry Officer was
right in refusing to act upon the statements relied on by the appellant. As there was no
material before the Inquiry Officer to show that P.S. Sundaram, mentioned in that
cheque is P.S. Sundaram, the Deputy Secretary, we think the High Court was justified in
holding that these charges had not been proved.
11. Coming to charge No. 3 the Single Judge as well as the Division Bench said
that although there was great deal of suspicion on the bona fides of the transaction in
the respondent borrowing money from Nand Kumar, suspicion cannot take the place of
proof. They, therefore, held that the charge has not been proved. The third charge, as
already stated, was that the respondent borrowed Rs. 2,500 from Nand Kumar without
obtaining the previous permission of the Government and placed himself under a
pecuniary obligation to the extent of the amount and thus contravened the provisions of
rule 13(5) of the Central Civil Services (Conduct) Rules, 1955 which reads:—
“(5) No Government servant shall, save in the ordinary course of business with a
Bank or a firm of standing borrow money form or otherwise place himself
under pecuniary obligation to any person within the local limits of his
authority, or any other persons with whom he is likely to have official
dealings, nor shall he permit any member of his family, except with the
previous sanction of the Government, to enter into any such transactions.
Provided that a Government servant may accept a purely temporary loan of
small amount, free of interest from a personal friend or a relative or operate
a credit account with a bona fide tradesman”.
12. The Inquiring Officer found that the respondent had borrowed Rs.2,500 from
Nand Kumar without obtaining the previous permission as required by Rule 13(5) and
thereby contravened the provisions of the sub-rule. The learned Single Judge held that
although it was proved that the money was borrowed and the respondent placed himself
under pecuniary obligation to Nand Kumar, there was no evidence nor had it been found
either by the Inquiry Officer or by the President that Nand Kumar was a person with
whom the respondent was likely to have official dealings. He further said that the
evidence of Shri P.S.Sundaraman was quite clear that the application for licence of M/s.
Ram Sarup Mam Chand was received in the Industries Act Section which are called I.A.
(I) Section whereas the petitioner was working in the Steel & Cement Section where the
copies of these applications started coming only in July, 1956 and so in June 1956 when
the cheque was issued it was not possible to see how in the absence of any other
evidence the petitioner could be regarded as being in a position where Nand Kumar was
likely to have official dealing with him in the matter of the grant of the licenses. The
Division Bench accepted this finding.

315

<!-- page 54 -->

13. It may be noted that the first part of sub-rule 13(5) of the Central Civil Services
(Conduct) Rules, 1955 says that no Government servant shall borrow money from or
otherwise place himself under pecuniary obligation to any person within the local limits of
his authority, save in the ordinary course of business with a Bank or a firm of standing.
The second part of the sub-rule forbids him from borrowing money from any other
person with whom he is likely to have official dealings. The appellant at no time had a
case that the respondent contravened the first part of the sub-rule in borrowing the
amount from Nand Kumar. So neither the learned Single Judge nor the Division Bench
had occasion to consider the application of the first part of the sub-rule to the facts of the
case. Even in the Special Leave Petition the appellant did not rely on the first part of the
sub-rule. We do not, therefore, think it necessary to consider the scope of the first part
of the sub rule or its application to the case here.
14. A finding cannot be characterized as perverse or unsupported by any relevant
materials if it is reasonable inference from proved facts. Now what are the proved facts:
Nand Kumar as representative of M/s Ram Sarup Mam Chand and M/s. Mam Chand
and Company of Calcutta filed five applications for licenses to set up steel re-rolling mills
on 14.6.1956, a cheque drawn in favour of P.S. Sundaram was given to the respondent
by Nand Kumar for Rs.2,500 the cheque was endorsed and the amount credited in the
account of the respondent. When the respondent borrowed the amount in question from
Nand Kumar, he was not working in the Industries Act Section. Nand Kumar knew that
the respondent was working in the Steel & Cement Section of the Ministry and
applications for the grant of licenses for setting up the steel re-rolling mills would go to
the Section. Even if the applications were to be dealt with at the initial stage by the
Industries Act Section the respondent at least was expected to know that in due course
the Section in which he was working had to deal with the same. This is borne out by the
fact that in July, 1956 copies of the applications were actually sent to the Steel &
Cement Section where the respondent was working. If he, therefore, borrowed money
from Nand Kumar a few days earlier it seems rather clear that he placed himself under
pecuniary obligation to a person who was likely to have “official dealings”, take within the
ambit the possibility of further dealings between the officer concerned and the person
from whom he borrowed money. A disciplinary proceedings is not a criminal trial. The
standard of proof required is that of preponderance of probability and not proof beyond
reasonable doubt. If the inference that Nand Kumar was a person likely to have official
dealing with the respondent was one which a reasonable person would draw from the
proved facts of the case, the High Court cannot sit as a court of appeal over a decision
based on it. Where there are some relevant materials which the authority has accepted
and which material may reasonably support the conclusion that the officer is guilty, it is
not the function of the High Court exercising its jurisdiction under Article 226 to review
the materials and to arrive at an independent finding on the materials if the enquiry has
been properly held. The question of adequacy or reliability of the evidence cannot be
canvassed before the High Court [see State of Andhra Pradesh Vs. Sree Rama Rao (4)].
No doubt there was no separate finding on the question whether Nand Kumar was a
person likely to have official dealings with the respondent by the Inquiring Officer or the
President. But we think that such a finding was implied when they said that Charge No.
3 has been proved. The only question was whether the proved facts of the case would
warrant such an inference. Tested in the light of the standard of proof necessary to
enter a finding of this nature, we are satisfied that on the material facts proved, the
inference and the implied finding that Nand Kumar was a person likely to have official
dealings with the respondent were reasonable.

316

<!-- page 55 -->

15. The Division Bench said that the conclusion of the Single Judge that there was
no evidence before the Inquiring Officer that Nand Kumar was likely to have officials
dealings with the respondent was not wholly unwarranted, and as there are limits to the
power exercised by a Single Judge, under Article 226 of the Constitution, there are limits
to the powers of a Division Bench while sitting in appeal over the judgement of a Single
Judge. If the inference that Nand Kumar was a person likely to have officials dealings
with the respondent was in the circumstances of the proved facts in the case a
reasonable one, we do not think there was anything which prevented the Division Bench
from interfering with the order of the Single Judge. In Jugal Kishore Bhadani Vs. Union
of India (5), the Court observed:—
“It is well established principle of law that, unless the statute otherwise provides, an
appellate Court has the same power of dealing with all questions, either of fact or of law,
arising in the appeal before it, as that of the Court whose Judgement is the subject of
scrutiny in the appeal”.
16. The respondent contended that he did not borrow Rs.2,500/- from Nand Kumar.
His case was that Nand Kumar owned him Rs.500/- and that when he gave the cheque
to the respondent it was on the undertaking that Rs.2,000/- would be repaid to him and
that was done immediately. The respondent produced a receipt executed from Nand
Kumar for having received Rs.2,000/- but Nand Kumar was not examined to prove the
genuineness of the receipt. The Inquiry Officer has considered the question at length in
his report and he came to the conclusion that the case of respondent that he did not
borrow the amount of Rs.2,500/- from Nand Kumar cannot be accepted. The learned
Single Judge found that the petitioner had borrowed the amount of Rs.2,500/- from Nand
Kumar. That finding was endorsed by the Division Bench. As it was a reasonable
inference from materials before the Inquiring Officer that Nand Kumar was a person
likely to have official dealings with the respondent and since the respondent borrowed
money from such a person without the permission of Government, the finding of the
Inquiring Officer and the President that the respondent had contravened Rule 13(5) of
the Central Civil Services (Conduct) Rules, 1955 should not have been interfered with by
the High Court.
17. It may be recalled that the punishment of compulsory retirement was imposed
upon the respondent on the basis that all the three charges had been proved against
him. Now, it is found that only the third charge has been proved. The question then is
whether the punishment of compulsory retirement imposed by the President can be
sustained even though the first two charges have not been proved.
18. Now it is settled by the decision of this Court in State of Orissa Vs.
Vidyabhushan Mahapatra (6) that if the order of punishing authority can be supported on
any finding as to substantial misdemeanour for which the punishment can be imposed, it
is not for the Court to consider whether the charge proved alone would have weighed
with the authority in imposing the punishment. The Court is not concerned to decide
whether the punishment imposed is justified by the rules, is appropriate having regard to
the misdemeanour established.
19. We reverse the judgement under appeal and hold that the order of the
President imposing the punishment of compulsory retirement was not liable to be
quashed.
20. In the result, the appeal is allowed, but in the circumstances, there will be no
order as to costs.

317

<!-- page 56 -->

Appeal allowed.
GOVERNMENT OF INDIA’S ORDERS UNDER RULE 3
1. In the event of suspension of a moS, Government of India may be
communicated telephonically immediately and the facts communicated within 15
days: - As soon as a member of the Service is placed under suspension or is deemed to
have been placed under suspension, the fact may be communicated to this Department
telegraphically and a detailed report of the case may be furnished within 15 days of the
date of suspension, as provided for in the rules.
[D.P. & A.R. letter No. 11018/1/76—AIS (III), dated 11-2-1976.]
2. Appeal/memorial submitted by a suspended moS should be forwarded to the
Central Government within one week of receipt by the State Governments: Whenever, a member of an All India Service who is placed under suspension, submits
an appeal or memorial against the order of the State Government placing him under
suspension, the same should be forwarded to the Central Government by the State
Government together with their comments within one week of its receipt. If the original
appeal or memorial along with the comments of the State Government is not received by
the Central Government within that period, the Central Government would take a
decision on the advance copy of the appeal or memorial received by them.
2. The original appeal or memorial submitted by a member of the Service referred to
above and the report about the orders issued by the State Government placing a
member of the Service under suspension, as envisaged in this Department’s letter of
even number dated the 11th February, 1976, may be forwarded to this Department in
the case of members of the Indian Administrative Service, to the Ministry of Home Affairs
in the case of the Indian Police Service and to the 69Ministry of Agriculture and Irrigation
(Department of Agriculture) in the case of the Indian Forest Service.
[D.P. & A.R. letter No. 11018/1/76—AIS (III), dated 30-4-1976.]
3. Further inquiry should not be ordered in cases where the order of dismissal,
removal or compulsory retirement from Service is set aside by a court of law
except where it is set aside on technical ground by the court:- The scope of the
action that can be taken against a member of the Service whose dismissal, removal or
compulsory retirement from Service has been set aside or declared or rendered void in
consequence of or by a decision of a court of law under sub-rule (6) of Rule 3 and the
circumstances which a disciplinary authority should take into account while taking
recourse to this rule have been examined and it is clarified for the information of State
Governments that further inquiry contemplated in sub-rule (6) of rule 3 of the All India
Services (Discipline and Appeal) Rules, 1969 should not be ordered except in case
when the penalty of dismissal removal or compulsory retirement has been set aside by a
Court of Law on technical grounds without going into the merits of the case or when
fresh material has come to light which was not before the Court. A further inquiry into the
charges which have not been examined by the Court, can however, be ordered by the
inquiring authorities under sub-rule (6) of rule 3 ibid depending on the facts and
circumstances of each case.
[D.P. & A.R. letter No. 11018/8/78—AIS (III), dated 19-5-1978.]

69

May be read as Ministry of Environment & Forests in the present context.

318

<!-- page 57 -->

4. Doubts on interpretation of any provision of these rules shall be referred to the
Central Government: - Where a doubts arised as to the interpretation of any of the
provisions of these rules, the matter shall be referred to the Central Government for its
decision.
[No. 7/15/63 dt. 20/3/69 GSR No. 926 dt. 12/4/69]
GOVERNMENT OF INDIA’S ORDERS UNDER RULE 4
1. The amount of subsistence allowance should be varied by the suspending
authority after recording the reasons in writing: -The Government of India have
decided that:
(i) the amount of subsistence allowance once granted should be varied by the
suspending authority under the first proviso to this rule only after recording
in writing the reasons for increasing or decreasing the amount;
(ii) a member shall not be entitled to compensatory allowance of which he was
in receipt prior to suspension unless the suspending authority is satisfied
that he continues to meet the expenditure for which they were granted.
[G.I., M.H.A. Letter No. 13/7/58—AIS (III), dated 18th October, 1958, read with No.
7/20/59—AIS (II), dated the 17th November, 1959.]
2. Deductions from the subsistence allowance: - Government of India have decided
that the following deductions should be enforced from subsistence allowance:—
(i) Income tax and super tax (provided the member’s annual income calculated
with reference to subsistence allowance is taxable).
(ii) House rent and allied charges i.e. electricity, water furniture etc.
(iii) Repayment of loans and advances taken from Government at such rates as
the competent authority deems it right to fix.
2. The following deductions should not be made except with a member’s written consent
letter—
(a) Premium due on Postal Life Assurance Policies.
(b) Amounts due to Co-operative Stores and Co-operative Credit Societies.
(c) Refund of Advances taken from General Provident Fund.
3. The following deductions should not be made from subsistence allowances:—
(i) Subscription to the All India Services Provident Fund.
(ii) Amounts due on Court attachments.
(iii) Recovery of loss to Government for which a member is responsible.
4. There is no bar to the recovery of overpayments from subsistence allowance but the
competent authority will exercise discretion in deciding whether recovery should be held
wholly in abeyance during the period of suspension or it should be effected at full or
reduced rate depending on the circumstances of each case.
[G.I., M.H.A. letter No. 7/18/59—AIS (II), dated 21st October, 1959]
GOVERNMENT OF INDIA’S ORDERS UNDER RULE 6

319

<!-- page 58 -->

1. Formal inquiry is not necessary in case of termination of probation, but if it is
under rule 11(2), an opportunity should be given to the probationer: - Termination
of employment of a probationer during or at the end of the period of probation in
accordance with the relevant provisions of the Indian Administrative Service/Indian
Police Service (Probation) Rules, 1954, does not amount to removal or dismissal within
the meaning of these rules and hence a formal inquiry in accordance with the procedure
laid down in rule 5 is not necessary in such cases. If, however, a probationer is removed
or dismissed on disciplinary grounds mentioned in rule 11(2) of Probation Rules he
should be given an opportunity to show cause against the action proposed to be taken
against him.
(G.I., MHA letter No. 414/4/58—Estt.(A), dt. 14.10.58)
2. IPS officers appointed against promotion quota may be reduced to a
supernumerary direct recruitment post in the Junior Scale: - A question arose
whether a member, who was appointed substantively to the Indian Police Service in the
senior scale against the promotion quota, could be reduced to the rank of Astt.
Superintendent of police (a rank which he never held in his service) or whether it was
necessary to reduce to the rank of Deputy Superintendent of Police (State Police
Service) which he held before appointment to the Indian Police Service. Reduction in
rank includes reduction to a lower post or to a lower time-scale. A member appointed to
the Indian Police Service against the promotion quota could, therefore, be reduced to the
Junior Scale of the Indian Police service. On reduction to the Junior Scale, he would be
shown against a supernumerary direct recruitment post in the Junior Scale like a State
Police Officer appointed to the Junior Scale under the Special Recruitment Scheme. His
pay and seniority, on reversion, would be regulated in accordance with the principles
applicable to a State Police Service Officer appointed in the Junior Scale under the
Special Recruitment Scheme.
(G.I. MHA letter No./ 9/7/58—AIS(II), dated 30.10.58)
3. Copy of the warning/displeasure/reprimand referred to in the Confidential
Report should be placed in the ACR dossier as an annexure to the Confidential
Report for the relevant period: - The instructions contained in the Ministry of Home
Affairs letter No. 7/4/59—AIS(II) dated the 20th March, 1959 and letter No.7/5/60—
AIS(II), dated the 4th May, 1960 have been reviewed and the following clarifications are
given:—
(i) It has been stated in the MHA Letter No.4/7/60—AIS(II), dated 4th May,
1960 that if it is decided, on the conclusion of disciplinary proceedings not to
impose any of the prescribed punishments but to administer a warning or
reprimands, mention of it should be made in the CR. The Delhi High Court
in the case of Sh. Nadhan Singh Vs. the Union of India expressed the view
that warning kept in the CR dossier has all the attributes of ‘Censure’ which
is a formal punishment and which can only be awarded by the competent
authority after following the procedure prescribed in the relevant disciplinary
Rules. It has, therefore, been decided that where it is considered, after the
conclusion of the disciplinary proceedings, that some blame attaches to the
officer concerned which necessitates cognizance of such fact, the
disciplinary authority should award one of the recognized statutory
penalties. If the intention of the disciplinary authority is not to award the
penalty of censure, then no recordable warning or reprimand should be
awarded.

320

<!-- page 59 -->

(ii) In the Ministry of Home Affairs letter No/ 7/4/59—AIS(II) of the 20th March,
1959, it is stated that there may be occasions when a superior officer may
find it necessary to criticise adversely the work of an officer working under
him, and he may feel that while the matter is not serious enough to justify
the imposition of a formal punishment, it calls for some informal action such
as communication of a written warning, admonition or reprimand. It has now
been decided that where such a warning/displeasure/reprimand is issued, it
should be placed in the personal file of the officer concerned. At the end of
the year (or period of report), the reporting authority while writing the
confidential report of the officer, may decide not make a reference in the
confidential report to the warning/displeasure/reprimand, if in the opinion of
that authority, the performance of the officer reported upon after the issue of
the warning or displeasure or reprimand, as the case may be, has improved
and has been found satisfactory. If, however, the reporting authority comes
to the conclusion that despite the warning/displeasure/reprimand the officer
has not improved, it may make appropriate mention
of such
warning/displeasure/reprimand, as the case may be, in the relevant column
in Part II of the ACR form prescribed under the All India Services
(Confidential Rolls) Rules, and in that case a copy of the
warning/displeasure/reprimand referred to in the Confidential Report should
be placed in the ACR dossier as an annexure to the Confidential Report for
the relevant period. The adverse remarks should also be conveyed to the
officer and his representation, if any, against the same disposed of in
accordance with the procedure laid down in the rules.
(DP&AR letter No. 11018/5/79—AIS(III) dt. 3.4.1981)
GOVERNMENT OF INDIA’S ORDERS UNDER RULE 8
1. Whenever a member desires to be heard in person, a Board of Inquiry or an
Inquiry Officer will have to be appointed: - The hearing in person, referred to in subrule (3), is really in the course of the inquiry to follow. Member of the Service has the
option to say that the inquiry may proceed on the strength of the written statement filed
by him and he does not wish to participate in person in the inquiry.
2. It is not necessary to hear the member concerned in person before the inquiry starts.
It is sufficient if an opportunity of personal hearing is given to him in the course of the
inquiry. If, however, the Government propose to inquire into the charges in such manner
as they deem fit (and not by a Board of an Inquiry or Inquiry Officer) and the member
desires to be heard in person, Government will have to appoint an inquiring authority as
required by sub-rule (6). In other words, whenever a member desires to be heard in
person, a Board of Inquiry or an Inquiry Officer will have to be appointed. Government
can inquire into charges in such manner as they deem fit, only in cases where the
member does not wish to be heard in person.
[G.I., M.H.A. letter No. 7/7/59—AIS (III), dated 11-5-1959]
2. The mention of more than one punishment in the show cause notice, does not
violate the provisions of article 311(2) of the Constitution: - The Supreme Court has
held in an appeal filed before them that the mention of more than one punishment in the
show cause notice, does not violate the provisions of article 311(2) of the Constitution.
On the contrary, it gives the Government servant a better opportunity to show cause
against each of the punishments, proposed to be inflicted on him, which he would not

321

<!-- page 60 -->

have had, if only the severest punishment had been mentioned and a lesser
punishment, not mentioned in the notice, had been inflicted on him.
[Hukum Chand Malhotra Vs. Un of India—G.I., M.H.A. F.No.7/6/59—AIS(I)]
(3) [Deleted vide letter No. 11018/4/79—AIS(III), dated 26—6—79]
3. Powers to drop the charges after the consideration of the written statement of
defence by the accused member of the Service lies with the disciplinary authority.
However, consultation with CBI, CVC. State Vigilance Commission, Anti
Corruption Department etc should be made if the case in initiated at their
insistence: - A question has been under consideration of this Department whether rule
8(6)(a) of the All India Services (Discipline & Appeal) Rules 1969, which is analogous to
Rule 14(5)(a) of the Central Services (CCA) Rules, 1965, permits the dropping of
charges by the disciplinary authority after considering the written statement of defence
submitted by the accused member of an All India Service under the aforesaid rules. The
question has been considered in consultation with the Ministry of Law and the position in
respect of the AIS (Discipline & Appeal) Rules, 1969 is clarified as under:—
(a)

The disciplinary authority has the inherent power to review and modify articles
of charge or drop some of the charges or all the charges after the receipt and
examination of the written statement of defence submitted by the accused
member of an All India Service under Rule 8(6) of the AIS (Discipline & Appeal)
Rules, 1969;

(b)

The disciplinary authority is not bound to appoint an Enquiry Officer for
conducting an enquiry into the charges which are not admitted by the accused
member of the Service but about which the disciplinary authority is satisfied on
the basis of the written statement of defence that there is no further cause to
proceed with.

2. It may, however be noted that the exercise of the powers to drop the charges after the
consideration of the written statement of defence by the accused member of the Service
will be subject to the following conditions:
(a)

In cases arising out of the investigation by the Central Bureau of Investigation,
the CBI should be consulted before a decision is taken to drop any of, or all,
the charges on the basis of the written statement of defence submitted by the
accused member of the Service. The reasons recorded by the disciplinary
authority for dropping the charges should also be intimated to the Central
Bureau of Investigation.

(b)

The Central Vigilance Commission/State Vigilance Commission/ Anti
Corruption Deptt., as the case may be, should be consulted where the
disciplinary proceedings were initiated on the advice of any of these bodies and
the intention is to drop the proceedings altogether, as distinct from dropping or
reviewing or modifying some charges.
[D P. & A R, letter No.11018/8/81—AIS(III), dated the 25.11.1981.]

GOVERNMENT OF INDIA’S ORDERS UNDER RULE 9
1. If any act of omission renders a moS liable of any penalty except dismissal,
removal and compulsory retirement, the State Government can directly make a
reference to UPSC for the quantum of penalty, which in turn, communicate the

322

<!-- page 61 -->

same directly under intimation to the respective Cadre Controlling Authorities of
the Central Government: - When a member is adjudged guilty of committing any act or
omission which renders him liable to any of the penalties specified in rule 3 other than
dismissal, removal or compulsory retirement, the State Government under whom he was
serving at the time of such act or omission, shall make a reference direct to the Union
Public Service Commission for their advice as to the quantum of penalty to be imposed
on him. The Commission would communicate their advice direct to the State
Government concerned under intimation to the 70Department of Personnel and A R in
the case of the IAS, Ministry of Home Affairs in the case of IPS and the 71Department of
Agriculture in the case of IFS. The State Government should endorse copies of their final
orders to the Commission and the 72Ministry of Home Affairs. If, however, the State
Government does not accept the advice of the Commission in any case, they will have to
make a reference to the Government of India in accordance with the proviso to rule 6.
2. Cases referred to the Commission and the Government of India should be complete in
all respects. All the documents in connection with the case should invariably forwarded
be in original.
[G.I., M.H.A. letter No. 7/1/59—AIS(II), dated 9th June, 1959 read with letter No.
73/60—AIS(II), dated 17th March, 1960.]
GOVERNMENT OF INDIA’S ORDERS UNDER RULE 16
1. IPS Officers on deputation to the Government of India or their Heads of
Departments, should not enter into direct correspondence with the State
Government or the Inspector General of Police concerned on matters relating to
service conditions: - IPS Officers serving with the Government of India on deputation
or their Heads of Departments, should not enter into direct correspondence with the
State Government or the Inspector General of Police concerned on matters relating to
service conditions. The correspondence in this regard should invariably be between the
borrowing and the lending Government. Representations from such officer are,
therefore, to be routed through the Ministry of Home Affairs and not sent to the State
Government or the Inspector General of Police of the State.
[G.I MHA letter No. 13/4/61—P(V) dated 5th May,1961.]

70
71
72

To be read as Department of Personnel & Training in the present context.
To be read as Ministry of Environment & Forests in the present context.
To be read as DP&T in the present context

323

<!-- page 62 -->

3. Procedure for intimation of disciplinary proceedings against the officers of All
India Services under the Government of India and organizations under the
Government of India
GOI, DoPT O.M. No.11018/3/94-AIS.III dated 9th June, 1995
Rule 7 of the AIS (Discipline & Appeal) Rules, 1969 stipulate the authority
competent to institute proceedings and to impose penalty on members of the All India
Services. The said rule vests this authority either with the State Government or with the
Central Government depending upon the circumstances explained therein. Powers of
the Central Government in respect of members of the Indian Administrative Service
while they are on deputation with the Central Government are exercised by the
Department of Personnel & Training. In respect of Indian Police Service and Indian
Forest Service these powers are exercised by the Ministry of Home Affairs and Ministry
of Environment & Forests respectively.
2. With a view to avoiding delay in the processing of cases in respect of members of All
India Service pertaining to the period of their central deputation the following procedure
may be followed while forwarding such cases to the cadre controlling authority, namely
Department of Personnel & Training / MHA/ Ministry of Environment & Forests, as the
case may be:i)

Any proposal to place an officer under suspension should be sent to the cadre
controlling Department only with the approval of the Minister in charge of the
Department/ Ministry administratively concerned.

ii) Any proposal to initiate disciplinary proceedings should be forwarded only after a
decision has been taken at the level of the Minister-in-Charge of the Department/
Ministry after obtaining the preliminary explanation of the officer and after
considering the same. In cases having a vigilance angle, the administrative
Ministries/ Departments are also required to consult the Central Vigilance
Commission and obtain its first stage advice before submitting the papers to the
Minister.
iii) If an officer is transferred to another Ministry/ Department, the Ministry concerned
where the alleged misconduct was committed by the officer will have to take a
view on the case in the light of the facts of the case and the explanations of the
concerned officer at the level of the Minister before forwarding the case records
for further necessary action. They must also give intimation in this regard to the
Ministry where the officer may be working for the time being.
iv) Where it is proposed to initiate disciplinary proceedings the proposal shall always
be accompanied by a draft charge sheet along with imputations of misconduct
and two sets of certified list of documents.
v) In cases where it is decided not to formally proceed against an officer but only to
convey a caution/ warning/ displeasure of the Government, this will be
communicated to the officer by the Ministry/ Department concerned, through the
administrative Ministry where he may be working at that time and two copies of
the same shall be endorsed to the respective controlling Department for record.
vi) In a case where there is no full fledged investigation by the CBI and where formal
action for major penalty is instituted by the concerned cadre controlling Ministry

324

<!-- page 63 -->

after due consideration of a proposal received from the administrative Ministry or
otherwise, the administrative Ministry shall also nominate an officer who is well
versed with the facts of the case for being appointed as the Presenting Officer.
vii) All communications meant for the officers proceeded against would be served
through the Ministry/ Department where the officer is working for the time being.
3.
It may be ensured that the above procedure is followed while referring cases of
members of the All India Services to the cadre controlling Ministries, namely,
Department of Personnel & Training, Ministry of Home Affairs and Ministry of
Environment and Forests, for initiation of Disciplinary proceedings under the AIS (D&A)
Rules.

325
