---
doc_id: "dca6eefad607911e"
source_url: "https://forest.wb.gov.in/upload/draft/senchal.pdf"
ministry: "Forest Department, West Bengal"
title: "366.S.O. 3575(E) [10.11.2017] Draft Notification declaring Eco Sensitive Zone around Senchal Wildlife Sanctuary, West Bengal."
date: ""
pages: 26
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "7043cee7b5469489"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (ii)
PART II—Section 3—Sub-section (ii)
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 3134]

ubZ fnYyh] 'kqØokj] uoEcj 10] 2017@dk£rd 19] 1939

No. 3134]

NEW DELHI, FRIDAY, NOVEMBER 10, 2017/KARTIKA 19, 1939

पयावरण, वन और जलवायु परवतन मं ालय
अिधसूचना
नई दली, 9 नव बर, 2017

. . 3575(अ).—अिधसूचना का िनिलिखत ाप, िजसे केीय सरकार, पयावरण (संरण)

का आ

अिधिनयम, 1986 (1986 का 29) क

धारा 3 क

उपधारा (2) के खंड (v) और खंड (xiv) तथा उपधारा (3) के

साथ प"ठत उपधारा (1) $ारा द% शि'य( का योग करते +ए, जारी करने का -ताव करती है, पयावरण
(संरण) अिधिनयम, 1986 के िनयम 5 के उपिनयम (3) क

अपेानुसार, जनसाधारण क

जानकारी के िलए,

कािशत कया जाता है; िजनके उससे भािवत होने क संभावना है, और यह सूिचत कया जाता है क उ' ा2प
अिधसूचना पर, उस तारीख से, िजसको इस अिधसूचना को अंत3व4ट करने वाले भारत के राजप7 क
जनसाधारण को उपल8ध करा दी जाती ह;, साठ दन क

अविध क

ितयां

समाि= पर या उसके प>चात् िवचार कया

जाएगा ;

ऐसा कोई @ि', जो ा2प अिधसूचना मA अंत3वB -ताव( के संब ंध मA कोई आपि% या सुझाव देने का

इEछुक है, वह इस कार िविनGदB अविध के भीतर, केीय सरकार $ारा िवचार कए जाने के िलए, अपनी
आपि% या सुझाव सिचव, पयावरण, वन और जलवायु प"रवतन मं7ालय, इं दरा पयावरण भवन, जोर बाग रोड,
अलीगंज, नई दली-110003 को या ई-मेल esz-mef@nic.in पर िलिखत 2प मA भेज सकेगा ।

ाप अिधसूचना
सAचल वयजीव अभयारIय क -थापना 1915 मA +ई थी और यह देश मA इस तरह के अभयारIय( मA सबसे
पुराना है और पिKम बंगाल राLय का एकमा7 पहाड़ी अभयारIय है। यह अभयारIय 38.88 वग कलोमीटर मA

6650 GI/2017

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

फैला +आ है। इस अभयारIय क

[PART II—SEC. 3(ii)]

मुSय िवशेषता यह है क यह पूरी तरह से यह दा3जUलंग शहर के पहाड़ी े7 के

बीच और उसके उपनगर( के िनकट होने के अित"र', दा3जUलंग शहर के िलए एक

पा"रि-थितक य मWान और जल भंडार है। एक घनी जनसंSया वाले े7 के पास ि-थत होने, अनेक अEछी सड़क(
से प+ंचने क

सुगमता के कारण इस अभयारIय के जैव े7 मA मानव ह-तेप ब+त अिधक है। सAचल वयजीव

अभयारIय के वन( मA अनेक दलच-प और महXवपूण वन-पितय( और जीव-जतुZ का वास है। इस अभयारIय के
मुSय वन कार( मA फर हेमलोक-ओक िमि[त वन, ओक वन और बड़ी पि%य( वाले सदाबहार वन ह;। यहाँ लगभग
380-400 फूलदार पौधे और रोडोडAaन क

कई जाितयां ह;। इस अभयारIय मA महXवपूण वयजीव सेरो, गोरल,

तAद ुआ, िहमालयी 8लैक भालू, लेजर िबली, येलो bोटेड माटन, िगलहरी (िवशाल और cलाइं ग), बाdकeग िडयर,
जंगली सूअर, 8लैक बैfड खलीज तीतर आद पाए जाते ह;
और, यह े7 न केवल -थानीय वन-पितय( और जीवजतुZ के जीन पूल के अंितम अवशेष( पर शोध काय
और उनके संरण के पा"रि-थितक और वैgािनक कारण( वरन -थानीय िनवािसय( के जीवन मA महXवपूण भूिमका

िनभाने क दृिB से तथा सAचल वयजीव अभयारIय क जैव िविवधता क वन-पित और जीवजतुZ क सुरा और
भावी संरण क

दृिB से भी महXवपूण है। िविभi कार के जनजातीय दबाव( को िविनयिमत कया जाना

चािहए fय(क इस नाजुक पा"रि-थितक णाली के एकदम आस-पास का े7 पा"रि-थितक
नाजुक है, जो इस संरित े7 को काफ

क

दृिB से ब+त ही

भािवत करता है।

अतः अब पा"रि-थितक , पयावरण, वान-पितक, जीव जतु, भौगोिलक या ािण संबंkता या इनसे
संब ंिधत महXव के कारण तथा इस अभयारIय और इसके प"रसर मA वयजीव( के संरण, उहे बढ़ावा देने या उनका
िवकास करने के उmे>य से, के सरकार

पयावरण (संरण) अिधिनयम, 1986 (1986 का 29) क

धारा 3 क

उप-धारा (2) के खंड (v) और खंड (xiv) के साथ प"ठत उप-धारा (1) के तहत द% शि'य( का योग करते +ए
और पयाव रण (संरण) िनयम, 1986 के िनयम 5 के उप-िनयम (3) के अनुसार, पिKम बंगाल राLय के सAचल

वयजीव अभयारIय के े7 और सीमा को पा"रि-थितक

संवेदी जोन (िजसे इसमA इसके प>चात् पा"रि-थितक

संव ेदी जोन कहा गया है) के 2प मA अिधसूिचत करती है, िजसका िववरण िनानुसार है, अथात् :--

1.

पारिथितक संवेेेदी जोन का िवतार और सीमा.(क) पा"रि-थितक

संवेदी जोन का े7फल 40.08 वग कलोमीटर है और पा"रि-थितक

संवेदी जोन क

सीमा पिKम बंगाल राLय के दा3जUलंग िजले मA सAचल वयजीव अभयारIय क सीमा से 01 कलोमीटर
तक है और सAचल वयजीव अभयारIय के पा"रि-थितक

संवेदी जोन का मानिच7, सीमा वणन,

िनदrशांक उपाबंध I के 2प मA उपाबk ह;।
(ख) पा"रि-थितक

2.

संवेदी जोन के sाम( क

सूची उपाबंध II के प मA उपाबk है |

पारिथितक संवेेदे ी जोन केेे िलए आंचिलक महायोजना.–
(1) राLय सरकार, पा"रि-थितक
तारीख से दो वष क

संव ेदी जोन के योजन के िलए राजप7 मA अंितम अिधसूचना के काशन क

अविध के भीतर, -थानीय @ि'य( के परामश से और इस अिधसूच ना मA दए गए

अनुबंध( का पालन करते +ए आंचिलक महायोजना तैयार करे गी।
(2) पा"रि-थितक

संवेदी जोन के िलए आचंिलक महायोजना इस अिधसूचना मA िविनGद4ट रीित से राLय

सरकार $ारा ासंिगक कAीय और राLय िविधय( तथा कAीय सरकार $ारा जारी मागिनदrश(, यद कोई ह(, के

अनु2प तैयार क जाएगी ।

<!-- page 3 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

(3) आंचिलक महायोजना, पा"रि-थितक

3

और पयावरणीय संबंधी सरोकार( को उ' योजना मA समाकिलत

करने के िलए राLय सरकार के िनिलिखत िवभाग( के परामश से तैयार क जायेगी,:--

(i)
(ii)

पयावरण;

(iii)

कृिष और बागवानी ;

(iv)
(v)

राज-व;

(vi)

पा"र-पयटन सिहत पयटन;

(vii)

sामीण िवकास;

(viii)

Uसंचाई और बाढ़ िनयं7ण;

(ix)

नगरीय और sामीण िवकास;

(x)

पंचायती राज;

(xi)

लोक िनमाण िवभाग।

वन और वयजीव;

शहरी िवकास;

(4) जब तक इस अिधसूचना मA िविनGदB न हो, आंचिलक महायोजना मA वतमान मA अनुमोदत भू-उपयोग,

अवसंरचना और vयाकलाप( पर कोई ितबंध नहw लगाया जाएगा तथा आचंिलक महायोजना मA सभी
अवसंरचनाZ और vयाकलाप( को अिधक द और पयावरण अनुकूल बनाने क

@व-था क जाएगी।

(5) आंचिलक महायोजना मA अनाEछादत और अवvिमत े7( के जीणxkार, िवWमान जल िनकाय( के

संरण, आवाह े7( के बंधन, जल-संभर( के बंधन, भू-जल के बंधन, मृदा और नमी के संरण, -थानीय
जनता क
है, क

आव>यकताZ तथा पा"रि-थितक एवं पयावरण के ऐसे अय पहलुZ, िजन पर yयान देना आव>यक

@व-था क जाएगी ।

(6) आंचिलक महायोजना मA सभी िवWमान पूज ा -थल(, sामीण और शहरी बि-तय(, वन( क

[ेिणय( और

क-म(, कृिष े7(, ऊपजाऊ भूिम, उWान( एवं उWान( क तरह के ह"रत े7(, बागवानी े7(, बगीच(, झील(
और अय जल िनकाय( क

सीमा का सहायक मानिच7( के साथ िनधारण कया जाएगा। इस योजना से

संब ंिधत सहायक मानिच7 मA िवWमान और -तािवत भूिम के उपयोग क

िवशेषताZ का 8यौरा दया

जाएगा।

(7) आंचिलक महायोजना मA पा"रि-थितक

संवेदी जोन मA िवकास को िविनयिमत कया जाएगा तथा इस

अिधसूचना मA िविनGदBानुसार िनिषk कए गए, िविनयिमत कए और बढ़ावा दए गए vयाकलाप( का
पालन कया जाएगा तथा -थानीय जनता क

आजीिवका क

सुरा के कए पा"रि-थितक -अनुकूल िवकास

सुिनिKत तथा संव3धत कया जायेगा ।
(8) आंचिलक महायोजना े7ीय िवकास योजना क

सह-कािलक होगी ।

(9) आंचिलक महायोजना, िनगरानी सिमित के िलए एक संदभ द-तावेज होगी िजसमA इस अिधसूचना के

उपबंध( से स बिधत उसके कत@( के िनवहन का िववरण होगा ।

<!-- page 4 -->

4
3.

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

राय सरकार ारा कए जाने वाले उपाय-- राLय सरकार इस अिधसूचना के उपबंध( को भावी बनाने के िलए

िनिलिखत उपाय करे गी, अथात् :-(1) भू-उपयोग.-

(क) पा"रि-थितक

संव ेदी जोन मA वन(, बागवानी े7(, कृिष े7(, उWान( तथा आमोद-मोद के योजन के

िलए िचिहत कए गए खुले -थान( का बड़े वािणिLयक और आवासीय प"रसर( संबंधी औWोिगक vयाकलाप(
के िलए उपयोग या संप"रवतन नहw कया जाएगा:
परं तु पा"रि-थितक

संव ेदी जोन मA कृिष भूिम एवं अय भूिम का संप"रवतन, िनगरानी सिमित क

िसफा"रश

पर और े7ीय नगर योजना अिधिनयम के अधीन, सम ािधकारी के पूव अनुमोदन से तथा यथा लागू

केीय/राLय सरकार के ासंिगक िनयम( और इस अिधसूचना के उपबंध( $ारा -थानीय िनवािसय( क
िनिलिखत आवासीय ज2रत( को पूरा करने के िलए अनुgात होगा :
(i) िवWमान सड़क( को चौड़ा करना और उहA सुद ृढ करना तथा नई सड़क( का िनमाण;

(ii) बुिनयादी ढांच( और नाग"रक सुिवधाZ का िनमाण और नवीकरण;
(iii) दूषण उXपi न करने वाले लघु उWोग;
(iv) sामीण उWोग( सिहत कुटीर उWोग; सुिवधा भIडार और गृह वास सिहत -थानीय सुिवधाएं जो पा"रि-थितक

पयटन मA सहायक ह;
(v) बढ़ावा दए गए और पैरा-4 मA व3णत vयाकलाप :
परं तु यह भी क राLय सरकार के ासंिगक िनयम( के अधीन सम ािधकारी के पूव अनुमोदन के िबना
तथा तथा संिवधान के अनुEछे द 244 के उपबंध( अथवा तXसमय वृ% िविध, िजसके अंतगत अनुसूिचत जनजाित
और अय परं परागत वन िनवासी (वन अिधकार( क

मायता) अिधिनयम, 2006 (2007 का 2) भी है, के

अनुपालन के िबना वािणिLयक या उWोग िवकास vयाकलाप( के िलए जनजातीय भूिम का योग अनुgात नहw
होगा:
परं तु यह भी क पा"रि-थितक

संवेदी जोन के भीतर क

भूिम के अिभलेख( मA उXपi कसी 7ु"ट क ,

िनगरानी सिमित के िवचार ा= करने के पKात्, राLय सरकार $ारा Xयेक मामले मA एक बार शुिk क
और उ' 7ु"ट के शुिkकरण क

जाएगी

सूचना कAीय सरकार के पयावरण, वन और जलवायु प"रवतन मं7 ालय को दी

जाएगी ।
परं तु यह भी क उपयु' 7ु"ट के शुिkकरण मA, इस उप-पैरा मA यथा उपबंिधत के िसवाय, कसी भी दशा मA
भू-उपयोग का प"रवतन सि मिलत नहw होगा ।
(ख) अनुयुfत या अनुXपादक कृिष े7( मA पुन: वनीकरण तथा पयावास एवं जैव-िविवधता बहाली vयाकलाप

करने के यास कए जाएंगे ।
(2)

ाकृ ितक जल ोत -- सभी ाकृितक जल }ोत(, नदय(, जलमाग~ के आवाह े7( क पहचान क जाएगी और

आचंिलक महायोजना मA उनके संरण और बहाली क
(3)

योजना सि मिलत क जाएगी ।

पयटन/पारिथितक पयटन–(क) पा"रि-थितक

संवेदी

जोन

के भीतर सभी नए

पा"रि-थितक

पयटन

vयाकलाप या िवWमान पयटन vयाकलाप( का िव-तार पा"रि-थितक संवेदी जोन संबंधी पयटन महायोजना के
अनुसार होगा ।

<!-- page 5 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

5

(ख) पा"रि-थितक पयटन महायोजना पयटन िवभाग, $ारा राLय सरकार के पयावरण और वन िवभाग के परामश
से तैयार होगी ।

(ग) पयटन महायोजना आंचिलक महायोजना का एक घटक होगी ।
(घ) पा"रि-थितक पयटन संबंधी vयाकलाप िनानुसार िविनयिमत ह(गे,:(i) वयजीव अभयारIय क

सीमा से एक कलोमीटर के भीतर या पा"रि-थितक

संवेदी जोन क

सीमा

तक, इसमA जो भी िनकट हो, कसी होटल या "रसोट का नया संिiमाण अनुgात नहw कया जाएगा ।
तथािप, वयजीव अभयारIय क

सीमा से एक कलोमीटर क

सीमा तक नए होटल( और "रसोट~ क

दूरी से परे पा"रि-थितक

संवेदी जोन क

-थापना पयटन महायोजना के अनुसार पा"रि-थितक

पयटन

सुिवधाZ के िलए पूव सीमांकत और पदािभिहत े7( मA अनुgात क जाएगी।
(ii) पा"रि-थितक

संवेदी जोन के अदर सभी नए पयटन vया-कलाप या िवWमान पयटन vयाकलाप(

का िव-तार केीय सरकार, पयावरण, वन और जलवायु प"रवतन मं7ालय $ारा जारी मागदश िसkांत(

तथा पा"रि-थितक

पयटन पर बल देते +ए राीय बाघ संरण ािधकरण $ारा जारी पा"रि-थितक

पयटन मागदश िसkांत( के अनुसार होगा ।
(iii)

आंचिलक

महायोजना

का

अनुमोदन

कए जाने तक, पयटन के िवकास तथा िवWमान पयटन

vयाकलाप( के िव-तार को वा-तिवक -थल िविनGदB संवीा तथा िनगरानी सिमित क

िसफा"रश के

आधार पर संबंिधत िविनयामक ािधकरण( $ारा अनुgात कया जाएगा और पा"रि-थितक

संवेदी जोन के

भीतर कसी नये होटल/"रसाट या वािणिLयक ितान का संिiमाण अनुgात नहw होगा ।
(4)

ाकृ ितक िवरासत – पा"रि-थितक संवेदी जोन मA ब+मूय ाकृितक िवरासत के सभी -थल( जैसे क सभी

जीन पूल "रजव े7, शैल संरचना, जल पात, झरने, दरr , उपवन, गुफाएं, -थल, वनपथ, रोहण माग, उXपात

आद क

पहचान क

जाएगी तथा उनक

सुरा एवं संरण के िलए िवरासत संरण योजना बनायी जाएगी जो

आंचिलक महायोजना का भाग होगी ।

(5)

मानव िन!मत िवरासत थल - पा"रि-थितक संवेदी जोन मA भवन(, संरचनाZ, कृि7म े7(, ऐितहािसक,

कलाXमक और सां-कृितक महXव के े7( क

पहचान क

जाएगी और उनके

संरण के िलए िवरासत संरण

योजना बनायी जाएगी जो आंचिलक महायोजना का भाग होगी।
(6)

#विन दूषण -- पा"रि-थितक संवेदी जोन मA yविन दूषण का िनवारण और िनयं7ण पयावरण (संरण)

अिधिनयम, 1986 के अधीन बनाए गए yविन दूषण (िविनयमन और िनयं7ण) िनयम, 2000 के अनुसार कया
जाएगा ।
(7) वायु

दूषण - पा"रि-थितक संवेदी जोन मA, वायु दूषण का िनवारण एवं िनयं7ण वायु (दूषण िनवारण और

िनयं7ण) अिधिनयम, 1981 (1981 का 14) के उपबंधो और उसके अधीन बनाए गए िनयम( के अनुसार कया
जाएगा ।

(8)

बिहाव का िनसारण - पा"रि-थितक संवेदी जोन मA उपचा"रत बिह}ाव( का िन-सारण पयावरण (संरण)

अिधिनयम, 1986 और उसके अधीन बनाए गए िनयम( के अतगत शािमल कए गए पयाव रणीय दूषण के

िन-सारण संबंधी साधारण मानक( या राLय सरकार $ारा िनयत मानक( के अनुसार कया जाएगा।
(9) ठोस

अपिश+ - ठोस अपिशB( का िनपटान और बंधन िनिलिखत 2प मA होगा -

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

(क) पा"रि-थितक

[PART II—SEC. 3(ii)]

संवेदी जोन मA ठोस अपिशB का िनपटान, भारत सरकार के पयावरण, वन और जलवायु

प"रवतन मं7ालय क

अिधसूचना सं. का.आ. 1357(अ), दनांक 8 अैल, 2016 के तहत कािशत ठोस अपिशB

बंधन िनयम, 2016 के उपबंध( के अनुसार कया जाएगा। गैर-जैिवक पदाथx का िनपटान पा"रि-थितक

संवेदी

जोन से बाहर िचिहत कए गए -थान पर पयावरण-अनुकूल रीित से कया जाएगा;

(ख) पा"रि-थितक

संव दी जोन के भीतर माय ौWोिगकय( का योग करते +ए िवWमान िनयम( और िविनयम(

के अनु2प ठोस अपिशB का सुरित और पयाव रण अनुकूल ंबंधन अनुgात कया जायेगा।

(10)

जैव िचक.सा अपिश/ट- (क) जैव िचकXसा अपिशB का िनपटान िन कार से कया जाएगा :-

(क)

पा"रि-थितक

संव ेदी जोन मA जैव िचकXसा अपिशB का िनपटान भारत सरकार के पयावरण, वन और

जलवायु प"रवतन मं7ालय क

समय –समय पर यथा संशोिधत अिधसूचना सं.सा.का.िन 343 (अ), तारीख 28

माच, 2016 के तहत कािशत जैव िचकXसा अपिशB बंधन िनयम, 2016 के उपबंध( के अनुसार कया जाएगा ।
(ख) पा"रि-थितक

संव दी जोन के भीतर माय ौWोिगकय( का योग करते +ए िवWमान िनयम( और िविनयम(

के अनु2प जैव-िचकXसा अपिशB का सुरित और पयावरण अनुकूल ठोस ंबंधन अनुgात कया जायेगा।
(11)

0लािटक अपिश+ बंधन: - पा"रि-थितक संवेदी जोन मA लाि-टक अपिशB का बंधन, भारत सरकार के

पयावरण, वन और जलवायु प"रवतन मं7ालय क
तहत कािशत

(12)

अिधसूचना सं.सा.का.िन 340(अ), तारीख 18 माच, 2016

के

लाि-टक अपिशB बंधन िनयम, 2016 के उपबंधो के अनुसार कया जाएगा।

िनमाण और िव#वंस अपिश+ बंधन: - पा"रि-थितक संवेदी जोन मA िनमाण और िवyवंस अपिशB का

बंधन, भारत सरकार के पयावरण, वन और जलवायु प"रवतन मं7ालय क

अिधसूचना सं.सा.का.िन 317(अ),

तारीख 29 माच, 2016 के तहत कािशत संिनमाण और िवyवंस अपिशB बंधन िनयम, 2016 के उपबंध( के
अनुसार कया जाएगा।

अपिश+:- पा"रि-थितक

(13) ई–

संवेदी जोन मA ई–अपिशB का बंधन, भारत सरकार पयावरण, वन और

जलवायु प"रवतन मं7ालय $ारा कािशत ई–अपिशB बंधन िनयम, 2016 के उपबंध( के अनुसार कया जाएगा।
(14) वाहन-यातायात: - वाहन-यातायत का संचलन आवास-अनुकूल तरीके से िविनयिमत कया जाएगा और इस

संब ंध मA आंचिलक महायोजना मA िवशेष उपबंध शािमल कए जाएंगे तथा आंचिलक महायोजना के तैयार होने और
राLय सरकार के सम ािधकारी $ारा अनुमोदत कए जाने तक, िनगरानी सिमित ासंिगक अिधिनयम( और
उनके तहत बनाए गए िनयम( एवं िविनयम( के अनुसार वाहन( क

(15)

आवाजाही के अनुपालन क

िनगरानी करे गी।

वाहन दूषण:- वाहन दूषण क रोकथाम और िनयं7ण लागू िविधय( के अनुसार कया जाएगा। -वEछतर

धन जैसे क सीएनजी, एलपीजी आद के योग के यास कए जाएंगे ।
(16)

औ4ोिगक ईकाइयां: - (i) सरकारी राजप7 मA इस अिधसूचना के काशन क तारीख को या उसके बाद

पा"रि-थितक संवेदी जोन के भीतर कसी भी नए दूषणकारी उWोग क -थापना अनुgात नहw क जायेगी।
(ii)

जब तक इस अिधसूचना मA िविनGदB न हो, पा"रि-थितक

संवेदी जोन मA कAीय दूषण िनयं7ण बोड $ारा

फरवरी, 2016 मA जारी दशािनदrश( मA कए गए उWोग( के वगकरण के अनुसार केवल गैर दूषणकारी उWोग(

क -थापना अनुgात क जायेगी। इसके अित"र', गैर-दूषणकारी कुटीर उWोग( को बढ़ावा दया जायेगा।

<!-- page 7 -->

¹Hkkx IIµ[k.M 3(ii)º
(17) पहाड़ी

Hkkjr dk jkti=k % vlk/kj.k

7

ढलान9 का संर:ण: - पहाड़ी ढलान( का संरण िनानुसार कया जायेगा:

(क) आंचिलक महायोजना मA पहाड़ी ढलान( के उन े7( को दशाया जाएगा िजनमA कसी भी संिनमाण क अनुमित
नहw होगी ।
(ख) िजन िवWमान खड़ी पहाड़ी ढलान( या ढलान( मA अXयिधक भू-रण होता है, उनमA कोई भी

संिनमाण

अनुgात नहw कया जायेग ा ।
(18) के सरकार और राLय सरकार, यद आव>यक समझA तो, इस अिधसूचना के उपबंध( को भावी बनाने के
िलए अय उपाय िविनGदB करA गी।

4.

पारिथितक संवेेेदी जोन म; ितिष< या िविनयिमत कए जाने वाले >याकलाप9 क सूची - पा"रि-थितक

संव ेदी जोन मA सभी vयाकलाप पयाव रण (संरण) अिधिनयम, 1986 (1986 का 29) के उपबंध( और उसके

तहत बनाए गए िनयम( तथा तटीय िविनयमन जोन, 2011 और पयाव रणीय भाव आकलन अिधसूचना, 2006
और वन (संरण) अिधिनयम, 1980 (1980 का 69), भारतीय वन अिधिनयम, 1927 (1927 का 16), वयजीव
(संरण) अिधिनयम, 1972 (1972 का 53) के उपबंध( तथा उनमA कए गए संशोधन( के अनुसार शािसत ह(गे
और नीचे दी गई सारणी मA िविनGदB रीित से िविनयिमत ह(गे, अथात् :--

सारणी

>म सं.

>याकलाप

(1)

िववरण

(2)

(3)

क.ितिष< >याकलाप
1.

वािणिLयक खनन ।

(क) -थानीय िनवािसय( क

वा-तिवक घरे लू आव>यकताZ,

िजनमA घर के िनमाण या मर मत के िलए जमीन क
मकान बनाने

खुदाई और

एवं अय vयाकलाप( के िलए देशी टाइलA या ईटA

बनाना शािमल है, को छोडकर सभी नई और वतमान (लघु एवं
वृहद खिनज) पXथर खोदने एवं तोडने वाली ईकाइयां तXकाल

भाव से िनिषk क जाती है ;
(ख)

खनन vयाकलाप, टी.एन. गोदावमन िथ2मलपाद बनाम

भारत संघ के मामले मA वष 1995 क

"रट यािचका (सी) सं

202 मA दनांक 4 अग-त, 2006 तथा गोवा फाउं डेशन बनाम
भारत संघ के मामले मA वष 2012 क

"रट यािचका(सी) सं.

435 मA दनांक 21 अैल, 2014 के माननीय उतम यायालय
के आदेश के अनुसरण मA कए जाएंगे।

2.

उWोग( क
(जल,

-थापना िजसके

वायु,

मृदा,

yविन

अंतगत
आद)

दुषण का"रत करने वाले नए तेल
और गैस खोज उWोग भी ह;।

पा"रि-थितक

संवेदी जोन मA नए उWोग लगाने और वतमान

दूषणकारी उWोग( का िव-तार करने क अनुgा नहw होगी।
जब तक क इस कार अिधसूचना मA िविनGदB न हो, फरवरी,
2016 मA कAीय दूषण िनयं7ण बोड $ारा जारी दशािनदrश( मA
कए गए उWोग( के वगकरण के अनुसार पा"रि-थितक
जोन के भीतर केवल गैर- दूषणकारी उWोग( क

संवेदी

अनुgा दी

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

जाएगी। इसके अित"र' गैर-दूषणकारी कुटीर उWोग( को
ोXसाहन दया जाएगा।

3.
4.
5.

नई बृहत जल िवWुत प"रयोजना और

लागू

Uसंचाई प"रयोजना क -थापना ।

िसवाय) ह(गे ।

कसी प"रसंकटमय पदाथ का योग

लागू

या उXपादन या -संकरण ।

िसवाय) ।

ाकृितक जल िनकाय( या भूिम े7
मA

अनुपचा"रत

बिह}ाव(

का

लागू

िविधय(

िविधय(

िविधय(

के

अनुसार

ितिषk

(अयथा

उपबंिधत

के

के

अनुसार

ितिषk

(अयथा

उपबंिधत

के

के

अनुसार

ितिषk

(अयथा

उपबंिधत

के

िसवाय) ।

िन-सारण ।

6.

नई आरा िमल( क

-थापना।

पा"रि-थतक
करना और

संवेदी जोन के भीतर नई

आरा िमल -थािपत

िवWमान आरा िमल( का िव-तार अनुgात नहw

होगा ।

7.

ट भ( क -थापना ।

लागू िविधय( के अनुसार ितिषk (अयथा उपबंिधत के
िसवाय) ।

8.

जलावन

लकड़ी

का

वािणिLयक

उपयोग।

9.

लागू िविधय( के अनुसार ितिषk (अयथा उपबंिधत के
िसवाय) ।

पोिलथीन बैग( का उपयोग ।

लागू िविधय( के अनुसार ितिषk (अयथा उपबंिधत के
िसवाय) ।

ख.िविनयिमत >याकलाप
10.

होटल( और "रजॉटx क

वािणिLयक

-थापना ।

पा"रि-थितक

पयटन vयाकलाप( हेतु लघु अ-थायी संरचनाZ

के िनमाण के िसवाय संरित े7 क
के

भीतर या

पा"रि-थितक

सीमा से एक कलोमीटर

संवेदी जोन क

सीमा तक, इनमA

जो भी अिधक िनकट हो, नए वािणिLयक होटल और "रसोट

अनुgात नही ह(गे।

परं तु, संरित े7 क

सीमा से 1 कलोमीटर के

पा"रि-थितक

संवेदी जोन क

िनकट

सभी

हो,

vयाकलाप(

का

नए

सीमा तक, इनमA जो भी

पयटन

िव-तार

बाहर या

पयटन

vयाकलाप

या

महायोजना

अिधक

िवWमान
और

लागू

दशािनदrश( के अनु2प होगा।

11.

फम~, कॉपxरे ट, कंपिनय( $ारा बड़े

लागू िविधय( के अधीन िविनयिमत होगा ।

पैमाने पर वािणिLयक पशुधन संपदा
और कुfकुट फाम~ क -थापना ।

12.

संिनमाण vयाकलाप ।

(क) संरित े7 क
पा"रि-थितक

सीमा से एक कलोमीटर के भीतर या

संवेदी जोन क

सीमा तक, इनमA जो भी

िनकट हो, कसी भी कार का
अनुgात नहw कया जाएगा:

अिधक

नया वािणिLयक संिनमाण

<!-- page 9 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

9

परं तु -थानीय िनवािसय( क

आवास स बधी िनिलिखत

आव>यकताZ को पूरा करने के िलए -थानीय लोग( को, पैरा 3
के उप पैरा (1) मA सूचीबk vयाकलाप( सिहत अपने योग के
िलए, अपनी भूिम मA भवन उप-िविधय( के अनुसार संिनमाण

करने क अनुमित दी जाएगी :(i)

िवWमान सड़क( को चौड़ा करना और उहA सुद ृढ करना और
नई सड़क( का संिनमाण;

(ii) बुिनयादी ढांच( और नाग"रक सुख-सुिवधाZ का संिनमाण
और नवीकरण;
(iii) फरवरी, 2016 मA कAीय दूषण िनयं7ण बोड $ारा कए

गए वगकरण के अनुसार गैर- दूषणकारी लघु उWोग;
(iv) कुटीर उWोग, िजनके अंतगत sामीण उWोग ह; सुिवधा

भIडार और पा"रि-थितक

पयटन मA सहायक -थानीय

सुख सुिवधाएं िजनमA अंतगत sह वास भी ह; और
(v)

इस

अिधसूचना

मA

सूचीबk

ोXसाहन

दए

गए

vयाकलाप ।
परतु लागू िनयम( और िविनयम(, यद कोई ह(,
सम ािधकारी क

के अनुसार

पूव अनुमित से ऐसे लघु उWोग(, जो

दूषण उXपi नहw करते ह;, से संबंिधत संिनमाण vयाकलाप
िविनयिमत कए जाएंगे और वे यूनतम ह(गे ।
(ख)

एक

कलोमीटर

से आगे

ये

आंचिलक

महायोजना

के

अनुसार िविनयिमत ह(गे ।

13.

गैर दूषणकारी लघु उWोग ।

फरवरी, 2016 मA केीय दूषण िनयं7ण बोड $ारा जारी
उWोग( के वगकरण के अनुसार गैर-दूषणकारी उWोग तथा
अप"रसंकटमय

लघु

और

सेवा

उWोग,

कृिष,

पु4प

कृिष,

बागबानी या कृिष आधा"रत उWोग, जो पा"रि-थितक

संवेदी

जोन से देशी सामिsय( से उXपाद बनाते ह;, सम ािधकारी

$ारा अनुgात ह(गे।

14.

वृ( क कटाई ।

(क) राLय सरकार के सम ािधकारी क

पूव अनुमित के िबना

वन या सरकारी या राज-व या िनजी भूिम पर वृ( क

कटाई

नहw होगी ।
(ख) वृ( क
उसके

अधीन

कटाई कAीय या संब ंिधत राLय के अिधिनयम या
बनाए

िविनयिमत होगी ।

गए

िनयम(

के

उपबंध(

के

अनुसार

<!-- page 10 -->

10
15.

THE GAZETTE OF INDIA : EXTRAORDINARY
वन

उXपाद(

और

का

गैर

वन

[PART II—SEC. 3(ii)]

लागू िविधय( के अधीन िविनयिमत होगा ।

उXपाद( (एनटीएफपी) का संsहण ।

16.

िवWुत और संचार टॉवर लगाना और

लागू िविधय( के अधीन िविनयिमत होगा । भूिमगत केबल

तार-िबछाने एवं अय बुिनयादी ढांचे

िबछाने को बढ़ावा दया जाएगा।

क @व-था ।

17.

नाग"रक सुिवधाZ सिहत बुिनयादी
ढांचा।

18.

लागू िविधय(, िनयम( और िविनयम( तथा मौजूदा दशािनदrश(
के अनुसार उपशमन उपाय( के साथ कया जायेगा।

िवWमान सड़क( को चौड़ा करना,

लागू िविधय(, िनयम( और िविनयम( तथा मौजूदा दशािनदrश(

उहA सुद ृढ

के अनुसार उपशमन उपाय( के साथ कया जायेगा।

बनाना और नई सड़क(

का िनमाण ।

19.

पयटन से संबंिधत अय vयाकलाप
जैसे

क पा"रि-थितक

लागू िविधय( के अधीन िविनयिमत होगा ।

संवेदी जोन

े7 के ऊपर से गम वायु के गु8बारे ,
हेलीका टर,
आद

को

aोन,

माइvोलाइस
जैसे

उड़ाने

vयाकलाप

करना।

20.

पवतीय

ढ़लान( और नदी तट( का

लागू िविधय( के अधीन िविनयिमत होगा ।

मA

लागू िविधय( के अधीन वािणिLयक योजन के िलए िविनयिमत

संरण ।

21.

राि7

वाहन

यातायात

का

संचलन ।

22.

-थानीय
रही

होगा ।
जनता $ारा अपनायी जा

वतमान

थाZ

के

उXपादन,

कृिष
साथ

जल

और

बागवानी

डेय"रयां,

कृिष

और

-थानीय जनता के योग के िलए लागू िविधय( के अधीन
अनुgात होगा ।

दुध
मX-य

पालन।

23.

ाकृितक जल िनकाय( या भू े7 मA

जल िनकाय( मA उपचा"रत अपिशB जल/बिह}ाव के िन-सारण

उपचा"रत/अपिशB जल/बिह}ाव का

से

िन-सारण ।

पुन:उपयोग के यास कए जाएंगे। अयथा उपचा"रत अपिशB

बचा

जल/

जाएगा।

बिह}ाव

उपचा"रत अपिशB जल के पुनचvण और

का

िन-सारण

लागू

िविधय(

के

अनुसार

िविनयिमत कया जाएगा।

24.

सतही

और

भूजल

का

वािणिLयक

लागू िविधय( के अधीन िविनयिमत होगा ।

िन4कषण ।

25.
26.

कृिष या अय उपयोग के िलए खुले

समुिचत

कुएं/ बोर कुएं आद का िनमाण ।

vयाकलाप क िनगरानी क जाएगी।

ठोस

अपिश4ट

बंधन/

जैव

ािधकारी

$ारा

िविनयिमत

लागू िविधय( के अधीन िविनयिमत होगा ।

िचकXसीय अपिश4ट बंधन।

27.

िवदेशी जाितय( को लाना ।

लागू िविधय( के अधीन िविनयिमत होगा ।

28.

पा"रि-थितक पयटन।

लागू िविधय( के अधीन िविनयिमत होगा ।

29.

वािणिLयक संकेत बोड और होडeग ।

लागू िविधय( के अधीन िविनयिमत होगा ।

कया

जाएगा

तथा

<!-- page 11 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

11

ग. संव!धत >याकलाप
30.

वषा जल संचयन ।

सvय 2प से बढ़ावा दया जाएगा ।

31.

जैिवक खेती।

सvय 2प से बढ़ावा दया जाएगा ।

32.

सभी

गितिविधय(

ह"रत

सvय 2प से बढ़ावा दया जाएगा ।

33.

sामीण कारीगरी सिहत कुटीर उWोग।

सvय 2प से बढ़ावा दया जाएगा ।

34.

नवीकरणीय

के

िलए

ौWोिगक का अंगीकरण ।

ऊजा

और

धन

का

बायोगैस, सौर काश इXयाद को सvय प से बढ़ावा दया

योग ।

जाएगा।

35.

कृिष वािनक ।

सvय 2प से बढ़ावा दया जाएगा ।

36.

पा"रि-थितक

अनुकूल यातायात का

सvय 2प से बढ़ावा दया जाएगा ।

योग ।

37.

कौशल िवकास ।

38.

अवvिमत भूिम/वन(

सvय 2प से बढ़ावा दया जाएगा ।
या वास--थल(

सvय 2प से बढ़ावा दया जाएगा ।

क बहाली ।

39.

पयावरणीय जागकता ।

सvय 2प से बढ़ावा दया जाएगा ।

5. िनगरानी सिमित.-

कAीय सरकार, पयावरण (संरण) अिधिनयम, 1986 (1986 का 29) क
शि'य( का योग करते +ए , पा"रि-थितक संवेदी जोन क

धारा 3 क

उपधारा (3) $ारा द%

भावी िनगरानी के िलए एक िनगरानी सिमित ग"ठत

करती है, जो िनिलिखत से िमलकर बनेगी:--

(i)

िजला मिज-ेट, दा3जUलंग िजला

-अyय;

(ii)

राLय दूषण िनयं7ण बोड का ितिनिध

–सद-य;

(iii)

पयाव रण (िजसके अंतगत िवरासत संरण भी है) के े7 मA काय करने

–सद-य;

वाले गैर सरकारी संगठन( का एक ितिनिध िजसे पिKम बंगाल सरकार

$ारा तीन वष के िलए नािमत कया जायेगा

(iv)

sामीण बंधन िवभाग, पिKम बंगाल सरकार का ितिनिध

–सद-य;

(v)

कृिष िवभाग, पिKम बंगाल सरकार के ितिनिध

–सद-य;

(vi)

पा"रि-थितक और पयाव रण के े7 का एक िवशेषg िजसे पिKम बंगाल

–सद-य;

सरकार $ारा तीन वष क अविध के िलए नािमत कया जायेगा

(vii)

राLय सरकार $ारा नािमत जैविविवधता िवशेषg

–सद-य;

(viii)

संरित े7 का भारी

–सद-य
सिचव।

6. िवचाराथ िवषय :(1) िनगरानी सिमित का कायकाल तीन वष या राLय सरकार $ारा नई सिमित का पुन: गठन कए जाने
तक होगा और बाद मA िनगरानी सिमित राLय सरकार $ारा ग"ठत क
(2) िनगरानी सिमित इस अिधसूचना के उपबंध( के अनुपालन क

जाएगी।

िनगरानी करे गी ।

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(3) िनगरानी सिमित वा-तिवक िविशB दशाZ के आधार पर उन vयाकलाप( क

संवीा करे गी जो

भारत सरकार के तXकालीन पयावरण एवं वन मं7ालय क अिधसूचना संSया का. आ. 1533 (अ), तारीख
14 िसत बर, 2006 क

अनुसूची और पा"रि-थितक संवेदी जोन के अतगत आते ह;। इनमA वे vयाकलाप

शािमल नहw ह; जो इस अिधसूचना के पैरा 4 मA दी गई सारणी मA यथा िविनGदB ह; तथा िजहे के सरकार
के पयावरण, वन और जलवायु प"रवतन मं7ालय को उ' अिधसूच ना के उपबंध( के अधीन पूण पयावरण
-वीकृित के िलए भेजा गया है।
(4) वे vयाकलाप, जो भारत सरकार के तXकालीन पयावरण एवं वन मं7 ालय क
का.आ.

1533(अ),

पा"रि-थितक

तारीख

14

िसतंबर,

2006

क

अिधसूचना संSया

अनुसूची के अंतगत नहw आते

ह;,

परतु

जो

संवेदी जोन के अंतगत आते ह;, उनक , इस अिधसूचना के पैरा-4 मA दी गई सारणी मA यथा

िविनGदB ितिषk vयाकलाप( के िसवाय, वा-तिवक -थल िविशB दशाZ के आधार पर, िनगरानी
सिमित $ारा संवीा क जायेगी और उहA संबंिधत िविनयामक ािधकरण( को भेजा जायेगा।
(5) िनगरानी सिमित का सद-य-सिचव या संबंिधत कलेfटर या संबंिधत काय भारी इस अिधसूचना के

उपबंध( का उलंघन करने वाले कसी @ि' के िवk पयावरण (संरण) अिधिनयम, 1986 क

धारा

19 के अंतगत िशकायत दज करने के िलए सम होगा ।

(6) िनगरानी सिमित Xयेक मामले मA आव>यकताZ के आधार पर संबंिधत िवभाग( के ितिनिधय( या

िवशेषg(, औWोिगक संघ( के ितिनिधय( या संब ंिधत प( को अपने िवचार-िवमश मA सहायता के िलए
आमंि7त कर सकेगी ।
(7) िनगरानी सिमित Xयेक वष 31 माच क

ि-थित के अनुसार अपनी वा3षक कार वाई "रपोट राLय के

पयावरण, वन और जलवायु प"रवतन मं7ालय मA मुSय वयजीव वाडन को, उपाबंध IV मA दए गए प7
के अनुसार, उस वष क

30 जून तक -तुत करे गी ।

(8) केीय सरकार का पयावरण, वन और जलवायु प"रवतन मं7ालय िनगरानी सिमित को उसके कृXय( के

भावी िनवहन के िलए ऐसे िनदेश दे सकेगा जो वह उिचत समझे ।
7.

इस अिधसूचना के उपबंध( को भावी बनाने के िलए कAीय सरकार और राLय सरकार, अित"रfत उपाय,

यद कोई ह(, िविनGद4ट कर सकAगी ।
8.

इस अिधसूचना के उपबंध भारत के माननीय उतम यायालय या उ यायालय या रा4ीय ह"रत

अिधकरण $ारा पा"रत कए गए या पा"रत कए जाने वाले आदेश, यद कोई हो, के अyयधीन ह(गे ।

. .

[फा सं 25/49/2016-ईएसजेड-आरई]

लिलत कपूर, वैgािनक ‘जी’

<!-- page 13 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

13
उपाबंध I

अ:ांश और देशांतर केेे साथ स;चल वBयजीव अभयारEय के पारिथितक संवेेेदी जोन का मानिच

स;चल वBयजीव अभयारEय के चार9 ओर पारिथितक संवेेेदी जोन का सीमा वणन
इस कार है:उ%र

--

चाय राLय

दिण

--

छोटा शहर

पूव

--

रे लवे -टेशन

पिKम

--

रे लवे -टेशन

वBयजीव अभयारEय केेे िनदGशांक :v.सं.

अांश

देशांतर

1

27000’33.2’’

88015’38’’

2

26059’30.1’’

88014’30.3’’

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

3

26059’34.3’’

88015’31.7’’

4

26057’12.4’’

88017’30.5’’

5

26057’56.1’’

88018’37.8’’

6

26058’33.2’’

88020’32.1’’

7

26058’47.5’’

88018’49.3’’

8

27001’40.15’’

88019’18.9’’

9

27002’8.5’’

88017’23.1

10

27000’49.4’’

88016’56.9’’

पारिथितक संवेेेदी जोन क सीमा के िनदGशांक:>.सं.

देशांतर

अ:ांश

1.

88°14’43.0’’पू

27°00'24.03"उ

2.

88°13’37.6’’पू

26°59'20.6"उ

3.

88°14’21.4’’पू

26°58'35.5"उ

4.

88°16’5.6’’पू

26°58'9.1"उ

5.

88°17’5.7’’पू

26°56'48.9"उ

6.

88°19’27.9’’पू

26°57'4.8"उ

7.

88°21’4.4’’पू

26°58'38.6"उ

8.

88°19’34.1’’पू

26°59'30.1"उ

9.

88°18’36.2’’पू

27°01'59.7"उ

10.

88°16’31.8’’पू

27°01'14.7"उ

उपाबंध-II

स;चल वBयजीव अभयारEय क सीमा केेे 0.5 कलोमीटर केेे अंतगत आने वाले Hाम9 क सूची
>.
सं.

Hाम का नाम

1

जे.एल सं.

:े हेIटेयर

पुिलस

म;

टेशन

>याकलाप

िनदGशांक

जोरे बंगलो

टी जी मA

27°01'22.97"उ

मजदूर

88°20'26.59"पू

@वसाय /

27°00'27.7"उ

मजदूर

88°15'33.7"पू

टी जी मA

26°59'31.7"उ

जनसंJया

16

रागी2म टी ई

245

1352
जोरे बंगलो

2

13
जोरे बंगलो

290

1363
जोरे बंगलो

3

12

पा-सीब(ग

75

2509

मजदूर

88°13'5.06"पू

<!-- page 15 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

15
टी जी मA

जोरे बंगलो
4

23
धोतेरीय

440

4724

टी जी मA

जोरे बंगलो
5

21
कलेज घाटी

6

293

मजदूर

2428

मजदूर

26°59'28.7"उ
88°15'33.2"पू
26°58'39.5"उ
88°15'12.07"पू

@वसाय /

26°57’'39.2"उ

मजदूर /कृिष

88°16'30.3"पू

मजदूर और

26°57'41.3"उ

कृिष

88°20'8.4"पू

20
सोनादा

400

सोनोदा

9030

रं गली7

28
लबदह

757.37

2ंगलीहाट

1359

चwचोना

रं गली
8

29
मुंगपो चwचोना

11555.7

12742

बागवानी

26°59'18.5"उ

मजदूर

88°20'33.3"पू
27°01'22.6"उ

रं गली
9

21

पुब(ग

632.03

10

दा3जUलंग

20
दवाईपानी

1606

424.57

सदर

5370

कृिष

88°17'45.6"पू

कृिष/चाय/

27°01'47.3"उ

मजदूर

88°18'30.7"पू

उपाबंध III

पारिथितक संवेेेदी जोन क िनगरानी सिमित - क गई कारवाई क रपोट का प
1.

बैठक( क संSया और तारीख ।

2.

बैठक( का कायवृत : कृपया मुSय उलेखनीय Uबंद ुZ का वणन करA । बैठक के कायव ृत को एक पृथक
उपाबंध मA -तुत करA ।

3.

पयटन महायोजना सिहत आंचिलक महायोजना क तैयारी क ि-थित ।

4.

भू-अिभलेख( क

-पB 7ु"टय( के सुधार के िलए िनबटाए गए मामल( का सार। िववरण उपाबंध के प

मA संल करA ।
5.

पयाव रण भाव मूयांकन अिधसूचना, 2006 के अधीन आने वाली गितिविधय( से संबंिधत संवीा
कए गए मामल( का सार । िववरण एक पृथक उपाबंध के 2प मA संल करA ।

6.

पयाव रण भाव मूयांकन अिधसूचना, 2006 के अधीन न आने वाली गितिविधय( से संबंिधत
संव ीा कए गए मामल( का सार । िववरण एक पृथक उपाबंध के 2प मA संल करA ।

7.

पयाव रण ( संरण ) अिधिनयम, 1986 क धारा 19 के अधीन दज क गई िशकायत( का सार ।

8.

कोई अय महXवपूण मामला ।

<!-- page 16 -->

16

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE
NOTIFICATION
New Delhi, 9th November, 2017
S.O. 3575(E).—The following draft of the notification, which the Central Government proposes to issue in
exercise of the powers conferred by sub-section (1), read with clause (v) and clause (xiv) of sub-section (2) and subsection (3) of section 3 of the Environment (Protection) Act, 1986 (29 of 1986) is hereby published, as required under
sub-rule (3) of rule 5 of the Environment (Protection) Rules, 1986, for the information of the public likely to be affected
thereby; and notice is hereby given that the said draft notification shall be taken into consideration on or after the expiry
of a period of sixty days from the date on which copies of the Gazette containing this notification are made available to
the public;
Any person interested in making any objections or suggestions on the proposals contained in the draft
notification may forward the same in writing, for consideration of the Central Government within the period so specified
to the Secretary, Ministry of Environment, Forest and Climate Change, Indira Paryavaran Bhawan, Jorbagh Road,
Aliganj, New Delhi-110003, or send it to the e-mail address of the Ministry at: - esz-mef@nic.in
Draft Notification
AND WHEREAS, the Senchal Wildlife Sanctuary was established way back in 1915 and is the oldest of such
Sanctuaries in the country and the only hill Sanctuary in the State of West Bengal and the Sanctuary spreads over an area
of 38.88 sq. km. The main characteristics of the sanctuary apart from its being entirely hilly is the region lies very closed
to Darjeeling town and its suburbs and it is an ecological oasis and water bank for Darjeeling town. Because of its close
proximity to a densely populated area coupled with its easy accessibility via a number of good roads, human interference
with the biotope of the sanctuary is high and variety of interesting and important flora and fauna exists amidst the forest
of Senchal Wildlife Sanctuary and the main forest types in the Sanctuary are Fir- Hemlock-Oak mixed forest, Oak forest
and broad leaved evergreen forest and there are approximately 380-400 flowering plants, various species of
Rhododendron and the important wildlife in the Sanctuary are Serrow, Goral, Leopard, Himalayan Black Bear, Lesser
Cats, Yellow throated Marten, Squirrels (Giant & Flying), Barking Deer, Wild Boar, Black backed Khaleej Pheasant etc;
AND WHEREAS, the area is important not only for ecological and scientific reason of research and
preservation of the last remnants of gene pool of indigenous flora and fauna but its importance also lies in respect of the
role it plays in the life of local inhabitants and for effective conservation and protection of these floral and faunal
Biodiversity of Senchal Wildlife Sanctuary the extent of different anthropogenic pressures has to be regulated as the
immediate area adjoining this fragile ecosystem is much ecologically sensitive having great impact on this Protected
Area.
NOW THEREFORE, by reason of ecological, environmental, faunal, floral, geographical or zoological
association or importance, for the purpose of protecting, propagating or developing wildlife therein or its environment,
the Central Government, in exercise of the powers conferred under by sub-section (1) read with clause (v) and clause
(xiv) of sub-section (2) of section 3 of the Environment (Protection) Act, 1986 (29 of 1986) and as per sub-rule (3) of
rule 5 of the Environment (Protection) Rules, 1986, hereby notifies the area and boundary of the Senchal Wildlife
Sanctuary in the State of West Bengal as the Senchal Wildlife Sanctuary Eco-sensitive Zone (hereinafter referred to as
the Eco Sensitive Zone), details of which are as under, namely:1. Extent and Boundaries of Eco-sensitive Zone.(a) The area of Eco-sensitive Zone is 40.08 square kilometers and the uniform extent of Eco-sensitive Zone is
one km. from the boundary of the Senchal Wildlife Sanctuary in the Darjeeling District the State of West
Bengal and the map, boundary description, co-ordinates of Sanchal Wildlife Sanctuary Eco-sensitive Zone
is appended at Annexure- I.
(b) The list of Villages of the Eco-sensitive Zone are appended at Annexure- II.
2.

Zonal Master Plan for the Eco-sensitive Zone.(1) The State Government shall, for the purpose of the Eco-sensitive Zone prepare, a Zonal Master Plan, within
a period of two years from the date of publication of final notification in the Official Gazette, in consultation
with local people and adhering to the stipulations given in this notification for approval of Competent Authority
in the State Government.
(2) The Zonal Master Plan for the Eco-sensitive Zone shall be prepared by the State Government in such manner
as is specified in this notification and also in consonance with the relevant Central and State laws and the
guidelines issued by the Central Government, if any.
(3) The Zonal Master Plan shall be prepared in consultation with the following State Departments, for
integrating the ecological and environmental considerations into the said plan:(i)
Environment;

<!-- page 17 -->

¹Hkkx IIµ[k.M 3(ii)º
(ii)
(iii)
(iv)
(v)
(vi)
(vii)
(viii)
(ix)
(x)
(xi)

Hkkjr dk jkti=k % vlk/kj.k

17

Forest and Wildlife;
Agriculture & Horticulture;
Revenue;
Urban Development;
Tourism including eco-tourism;
Rural Development;
Irrigation and Flood Control;
Municipal and urban development;
Panchayati Raj;
Public Works Department.

(4) The Zonal Master Plan shall not impose any restriction on the approved existing land use, infrastructure and
activities, unless so specified in this notification and the Zonal Master Plan shall factor in improvement of all
infrastructure and activities to be more efficient and eco-friendly.
(5) The Zonal Master Plan shall provide for restoration of denuded and degraded areas, conservation of existing
water bodies, management of catchment areas, watershed management, groundwater management, soil and
moisture conservation, needs of local community and such other aspects of the ecology and environment that
need attention.
(6) The Zonal Master Plan shall demarcate all the existing worshipping places, villages and urban settlements,
types and kinds of forests, agricultural areas, fertile lands, green area, such as, parks and like places,
horticultural areas, orchards, lakes and other water bodies and also with supporting maps and the Plan shall be
supported by Maps giving details of existing and proposed land use features.
(7) The Zonal Master Plan shall regulate development in Eco-sensitive Zone and adhere to prohibited, regulated
activities listed in Table and also ensure and promote eco-friendly development for livelihood security of local
communities.
(8) The Zonal Master Plan shall be co-terminus with the Regional Development Plan.
(9) The Zonal Master Plan so approved shall be the reference document for the Monitoring Committee for
carrying out its functions of monitoring in accordance with the provisions of this notification.
3.
Measures to be taken by State Government.The State Government shall take the following measures for giving effect to the provisions of this notification, namely:(1) Landuse.(a) Forests, horticulture areas, agricultural areas, parks and open spaces earmarked for recreational purposes in the Ecosensitive Zone shall not be used or converted into areas for major commercial or major residential complex or
industrial activities.
Provided that the conversion of agricultural and other lands, for the purpose other than that specified within the
Eco-sensitive Zone may be permitted on the recommendation of the Monitoring Committee, and with the prior
approval of the competent authority under under the relevant laws of the Central/State Government as applicable and
vide provisions of this notification, to meet the residential needs of the local residents such as.(i) widening and strengthening of existing roads and construction of new roads;
(ii) construction and renovation of infrastructure and civic amenities;
(iii) small scale industries not causing pollution;
(iv) cottage industries including village industries; convenience stores and local amenities supporting eco-tourism
including home stay; and
(v) promoted activities and given under para 4:
Provided further that no use of tribal land shall be permitted for commercial and industrial development activities
without the prior approval of the competent authority under the relevant laws of State Government and without
compliance of the provisions of article 244 of the Constitution or the law for the time being in force, including the
Scheduled Tribes and other Traditional Forest Dwellers (Recognition of Forest Rights) Act, 2006 (2 of 2007):
Provided also that any error appearing in the land records within the Eco-sensitive Zone shall be corrected by
the State Government, after obtaining the views of Monitoring Committee, once in each case and the correction of
said error shall be intimated to the Central Government in the Ministry of Environment, Forest and Climate Change:
Provided also that the above correction of error shall not include change of land use in any case except as
provided under this sub-paragraph.
(b) Efforts shall be made to reforest the unused or unproductive agricultural areas with afforestation and habitat and
biodiversity restoration activities.

<!-- page 18 -->

18

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(2) Natural water bodies.- The catchment areas of all natural springs, rivers, channels shall be identified and plans for
their conservation and rejuvenation shall be incorporated in the Zonal Master Plan.

(3) Tourism/ Eco-tourism.(a) All new Eco-tourism activities or expansion of existing tourism activities within the Eco-sensitive Zone shall be as
per the Tourism Master Plan for the Eco-sensitive Zone.
(b) The Eco-tourism Master Plan shall be prepared by Department of Tourism in consultation with State Departments of
Environment and Forests.
(c) The Tourism Master Plan shall form a component of the Zonal Master Plan.
(d) The activities of Eco-tourism shall be regulated as under, namely:(i) No new construction of hotels and resorts shall be allowed within 1 km. from the boundary of the Wildlife Sanctuary
or upto the extent of the Eco-sensitive Zone whichever is nearer and beyond the distance of 1 km. from the boundary
of the Wildlife Sanctuary till the extent of the Eco-sensitive Zone, the establishment of new hotels and resorts shall
be allowed only in pre-defined and designated areas for Eco-tourism facilities as per Tourism Master Plan.
(ii) All new tourism activities or expansion of existing tourism activities within the Eco-sensitive Zone shall be in
accordance with the guidelines issued by the Central Government in the Ministry of Environment, Forest and
Climate Change and the Eco-tourism guidelines issued by the National Tiger Conservation Authority with emphasis
on Eco-tourism;
(iii) Until the Zonal Master Plan is approved, development for tourism and expansion of existing tourism activities shall
be permitted by the concerned regulatory authorities based on the actual site specific scrutiny and recommendation
of the Monitoring Committee and no new hotel /resort or commercial establishment construction is permitted within
Eco-sensitive Zone area.
(4) Natural Heritage.- All sites of valuable natural heritage in the Eco-sensitive Zone, such as the gene pool reserve
areas, rock formations, waterfalls, springs, gorges, groves, caves, points, walks, rides, cliffs, etc. shall be identified and a
heritage conservation plan shall be drawn up for their preservation and conservation as a part of the Zonal Master Plan.
(5) Man-made heritage sites.- Buildings, structures, artefacts, areas and precincts of historical, architectural, aesthetic,
and cultural significance shall be indentified in the Eco-sensitive Zone and heritage conservation plan for their
conservation shall be prepared as part Zonal Master Plan.
(6) Noise pollution.- Prevention and Control of noise pollution in the Eco-sensitive Zone shall be complied with in
accordance with the Noise Pollution (Regulation And Control) Rules, 2000 under the Environment (Protection) Act,
1986.
(7) Air pollution.- Prevention and control of air pollution in the Eco-sensitive Zone shall be complied with in accordance
with the provisions of the Air (Prevention and Control of Pollution) Act, 1981 (14 of 1981) and rules made thereunder.
(8) Discharge of effluents.- Discharge of treated effluent in the Eco-sensitive Zone shall be in accordance with the
provisions of the General Standards for Discharge of Environmental Pollutants covered under the Environmental
(Protection) Act, 1986 and rules made thereunder or standards stipulated by State Government.
(9) Solid wastes.- Disposal and Management of solid wastes shall be as under:(a) the solid waste disposal and management in the Eco-sensitive Zone shall be carried out in accordance with the Solid
Waste Management Rules, 2016 and published by the Government of India in the Ministry of Environment, Forest and
Climate Change vide notification number S.O. 1357 (E), dated the 8th April, 2016 and the inorganic material may be
disposed in an environmental acceptable manner at site identified outside the Eco-sensitive Zone;
(b) Safe and Environmentally Sound Management of Solid wastes in conformity with the existing rules and regulations
using identified technologies may be allowed within the Eco-Sensitive Zone.
(10) Bio-medical waste.- Bio medical waste management shall be as under:(a) The bio-medical waste disposal in the Eco-sensitive Zone shall be carried out in accordance with the Bio-Medical
Waste Management Rules, 2016 published by the Government of India in the Ministry of Environment, Forest and
Climate Change vide notification number GSR 343 (E), dated the 28th March, 2016.
(b) Safe and Environmentally Sound Management of Bio-medical wastes in conformity with the existing rules and
regulations using identified technologies may be allowed within the Eco-sensitive Zone.

<!-- page 19 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

19

(11) Plastic Waste Management.- The Plastic Waste Management in the Eco-sensitive Zone shall be carried out as per
the provisions of the Plastic Waste Management Rules, 2016 published by the Government of India in the Ministry of
Environment, Forest and Climate Change vide notification number G.S.R. 340(E), dated the 18th March, 2016.
(12) Construction and Demolition Waste Management.- The Construction and Demolition Waste Management in the
Eco-sensitive Zone shall be carried out as per the provisions of the Construction and Demolition Waste Management
Rules, 2016 published by the Government of India in the Ministry of Environment, Forest and Climate Change vide
notification number G.S.R. 317(E), dated the 29th March, 2016.
(13) E-waste.- The E- waste Management in the Eco-sensitive Zone shall be carried out as per the provisions of the EWaste Management Rules, 2016 published by the Government of India in the Ministry of Environment, Forest and
Climate Change.
(14) Vehicular traffic.- The vehicular movement of traffic shall be regulated in a habitat friendly manner and specific
provisions in this regard shall be incorporated in the Zonal Master Plan and till such time as the Zonal Master plan is
prepared and approved by the Competent Authority in the State Government, the Monitoring Committee shall monitor
compliance of vehicular movement under the relevant Acts and the rules and regulations made thereunder.
(15) Vehicular Pollution.- Prevention and control of Vehicular Pollution shall be complied with in accordance with
applicable laws and efforts shall be made for use of cleaner fuel for example CNG, LPG, etc.
(16) Industrial Units.- (i) On or after the publication of this notification in the Official Gazette, no new polluting
industries shall be allowed to be set up within the Eco-sensitive Zone.
(ii) Only non-polluting industries shall be allowed within Eco-sensitive Zone as per classification of Industries in the
Guidelines issued by the Central Pollution Control Board in February 2016, unless so specified in this notification and in
addition, non-polluting cottage industries shall be promoted.
(17) Protection of Hill Slopes.- The protection of hill slopes shall be as under:
(a)
The Zonal Master Plan shall indicate areas on hill slopes where no construction shall be permitted.
(b)
No construction on existing steep hill slopes or slopes with a high degree of erosion shall be permitted.
(18) The Central Government and the State Government shall specify other additional measures, if it considers necessary,
in giving effect to the provisions of this notification.
4.
List of activities prohibited or to be regulated within the Eco-sensitive Zone.All activities in the Eco-sensitive Zone shall be governed by the provisions of the Environment (Protection) Act,
1986 (29 of 1986) and the rules made there under including the Coastal Regulation Zone notification, 2011 and the
Environmental Impact Assessment Notification, 2006 and other applicable laws including the Forest (Conservation) Act,
1980 (69 of 1980), the Indian Forest Act, 1927 (16 of 1927), the Wildlife (Protection) Act 1972 (53 of 1972), and
amendments made thereto and be regulated in the manner specified in the Table below, namely:TABLE

S No

Activity

Description

(1)

(2)

(3)
A. Prohibited Activities

1.

Commercial Mining.

2.

Setting of industries including
new oil and gas exploration

(a) All new and existing (minor and major minerals), stone quarrying and
crushing units are prohibited with immediate effect except for meeting
the domestic needs of bona fide local residents including digging of earth
for construction or repair of houses and for manufacture of country tiles
or bricks for housing and for other activities.
(b) The mining operations shall be carried out in accordance with the
order of the Hon’ble Supreme Court dated 04th August, 2006 in the matter
of T.N. Godavarman Thirumulpad Vs. UOI in W.P.(C) No.202 of 1995
and dated 21st April, 2014 in the matter of Goa Foundation Vs. UOI in
W.P.(C) No.435 of 2012.
No new industries and expansion of existing polluting industries in the
Eco-sensitive zone shall be permitted.

<!-- page 20 -->

20

THE GAZETTE OF INDIA : EXTRAORDINARY
causing pollution (Water, Air,
Soil, Noise, etc.).

[PART II—SEC. 3(ii)]

Only non-polluting industries shall be allowed within Eco-sensitive Zone
as per classification of Industries in the Guidelines issued by the Central
Pollution Control Board in February 2016, unless so specified in this
notification. In addition, non-polluting cottage industries shall be
promoted.
Prohibited (except as otherwise provided) as per applicable laws.

6.

Establishment of major thermal
and major hydroelectric project.
Use or production or processing
of any hazardous substances.
Discharge of untreated effluents
in natural water bodies or land
area.
Setting of new saw mills.

7.

Setting up of brick kilns.

No new or expansion of existing saw mills shall be permitted within the
Eco-sensitive Zone.
Prohibited (except as otherwise provided) as per applicable laws.

8.

Commercial use of fire wood.

Prohibited (except as otherwise provided) as per applicable laws.

9.

Use of plastic bags.

Prohibited (except as otherwise provided) as per applicable laws.

10.

Commercial establishment of hotels
and resorts.

11.

Establishment of large-scale
commercial livestock and poultry
farms by firms, corporate,
companies.
Construction activities.

3.
4.
5.

12.

Prohibited (except as otherwise provided) as per applicable laws.
Prohibited (except as otherwise provided) as per applicable laws.

B. Regulated Activities
No new commercial hotels and resorts shall be permitted within one
kilometre of the boundary of the Protected Area or upto the extent of
Eco-sensitive Zone, whichever is nearer, except for small temporary
structures for Eco-tourism activities:
Provided that, beyond one kilometre from the boundary of the
Protected Area or upto the extent of Eco-sensitive Zone whichever is
nearer, all new tourist activities or expansion of existing activities
shall be in conformity with the Tourism Master Plan and guidelines as
applicable.
Regulated under applicable laws.

(a) No new commercial construction of any kind shall be permitted
within one Kilometre from the boundary of the Protected Area or upto
extent of the Eco-sensitive Zone whichever is nearer:
Provided that, local people shall be permitted to undertake
construction in their land for their use including the activities
listed in sub- paragraph (1) of paragraph 3 as per building
byelaws to meet the residential needs of the local residents such
as:(i) widening and strengthening of existing roads and
construction of new roads;
(ii) construction and renovation of infrastructure and civic
amenities;
(iii) small scale industries not causing pollution termed as per
Classification done by Central Pollution Control Board of
February 2016;
(iv) cottage industries including village industries; convenience
stores and local amenities supporting eco-tourism including
home stays; and
(v) promoted activities listed in this Notification:
Provided further that the construction activity related to small scale
industries not causing pollution shall be regulated and kept at the
minimum, with the prior permission from the competent authority as
per applicable rules and regulations, if any.
(b) Beyond one kilometre it shall be regulated as per the Zonal
Master Plan.

<!-- page 21 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

13.

Small scale non polluting industries.

14.

Felling of Trees.

15.

Collection of Forest produce or NonTimber Forest Produce (NTFP).

16.

Erection
of
electrical
and
communication towers and laying of
cables and other infrastructures.
Infrastructure
including
civic
amenities.

17.
18.

19.

20.

Widening and strengthening of
existing roads and construction of
new roads.
Under taking other activities related
to tourism like over flying the Ecosensitive Zone area by
hot air
balloon,
helicopter,
drones,
Microlites, etc.
Protection of Hill Slopes and river
banks.

Non polluting industries as per classification of industries issued by
the Central Pollution Control Board in February 2016 and nonhazardous, small-scale and service industry, agriculture, floriculture,
horticulture or agro-based industry producing products from
indigenous materials from the Eco-sensitive Zone shall be permitted
by the competent Authority.
(a) There shall be no felling of trees on the forest or Government or
revenue or private lands without prior permission of the competent
authority in the State Government.
(b) The felling of trees shall be regulated in accordance with the
provisions of the concerned Central or State Act and the rules made
thereunder.
Regulated under applicable laws.
Regulated under applicable law. Underground cabling may be
promoted.
Shall be done with mitigation measures, as per applicable laws, rules
and regulation and available guidelines.
Shall be done with mitigation measures, as per applicable laws, rules
and regulation and available guidelines.
Regulated under applicable law.

Regulated under applicable laws.

21.

Movement of vehicular traffic at
night.

Regulated for commercial purpose under applicable laws.

22.

Ongoing agriculture and horticulture
practices by local communities along
with
dairies,
dairy
farming,
aquaculture and fisheries.
Discharge
of
treated
waste
water/effluents in natural water
bodies or land area.

Permitted under applicable laws for use of locals.

23.

24.
25.

Commercial extraction of surface
and ground water.
Open Well, Bore Well etc. for
agriculture or other usage.

The discharge of treated waste water/effluents shall be avoided to
enter into the water bodies. Efforts to be made for recycle and reuse
of treated waste water. Otherwise the discharge of treated waste
water/effluent shall be regulated as per applicable laws.
Regulated under applicable law.
Regulated and the activity shall be strictly monitored by the
appropriate authority.

26.

Solid
Waste
Management/Biomedical Waste Management.

Regulated under applicable laws.

27.

Introduction of Exotic species.

Regulated under applicable laws.

28.

Eco-tourism.

Regulated under applicable laws.

29.

Commercial
hoardings.

Sign

boards

and

21

Regulated under applicable laws.

<!-- page 22 -->

22

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

C. Promoted Activities
Shall be actively promoted.

30.

Rain water harvesting.

31.

Organic farming.

Shall be actively promoted.

32.

Adoption of green technology for all
activities.

Shall be actively promoted.

33.

Cottage industries including village
artisans, etc.

Shall be actively promoted.

34.

Use of renewable energy and fuels.

Bio gas, solar light etc. to be actively promoted

35.

Agro-Forestry.

Shall be actively promoted.

36.

Use of eco-friendly transport.

Shall be actively promoted.

37.

Skill Development.

Shall be actively promoted.

38.

Restoration of Degraded Land/ Forests/
Habitat.

Shall be actively promoted.

39.

Environmental Awareness.

Shall be actively promoted.

5. Monitoring Committee:
In exercise of the powers conferred by sub-section (3) of section 3 of the Environment (Protection) Act, 1986
(29 of 1986), the Central Government hereby constitutes a Monitoring Committee for effective monitoring of the Ecosensitive Zone, which shall comprise of namely:(i) District Magistrate, Darjeeling District

– Chairman;

(ii) Representative of State Pollution Control Board

– Member;

(iii) One representative of Non-governmental Organisations

– Member;

working in the field of environment (including heritage conservation)
to be nominated by the Government of West Bengal for a period
of three years
(iv) Representative of Rural Management Department,

– Member;
– Member;

Government of West Bengal
(v) Representative of Agriculture Department,

– Member;

Government of West Bengal
(vi) One expert in the area of ecology and environment to be nominated
by the Government of West Bengal for a period of three years

6.

– Member;

(vii) Expert in Biodiversity nominated by State Govt.

– Member;

(viii) Expert In charge Protected area

– Member –Secretary.

Terms of Reference.(1) The tenure of the Monitoring committee shall be for three years or till the re-constitution of the new Committee
by the State Government and subsequently the Monitoring Committee would be constituted by the State
Government.
(2) The Monitoring Committee shall monitor the compliance of the provisions of this notification.

<!-- page 23 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

23

(3) The activities that are covered in the Schedule to the notification of the Government of India in the erstwhile
Ministry of Environment and Forests vide number S.O. 1533 (E), dated the 14th September, 2006, and are falling
in the Eco-sensitive Zone, except for the prohibited activities as specified in the Table under paragraph 4
thereof, shall be scrutinised by the Monitoring Committee based on the actual site-specific conditions and
referred to the Central Government in the Ministry of Environment, Forest and Climate Change for prior
environmental clearances under the provisions of the said notification.
(4) The activities that are not covered in the Schedule to the notification of the Government of India in the erstwhile
Ministry of Environment and Forests vide number S.O. 1533 (E), dated the 14th September, 2006 and are falling
in the Eco-sensitive Zone, except for the prohibited activities as specified in the Table under paragraph 4
thereof, shall be scrutinised by the Monitoring Committee based on the actual site-specific conditions and
referred to the concerned regulatory authorities.
(5) The Member Secretary of the Monitoring Committee or the concerned Deputy Commissioner shall be
competent to file complaints under section 19 of the Environment (Protection) Act, 1986 against any person
who contravenes the provisions of this notification.
(6) The Monitoring Committee may invite representatives or experts from concerned Departments, representatives
from Industry Associations or concerned stakeholders to assist in its deliberations depending on the
requirements on issue to issue basis.
(7) The Monitoring Committee shall submit the annual action taken report of its activities as on 31st March of every
year by 30th June of that year to the Chief Wildlife Warden in the state as per pro- forma given at Annexure III.
(8) The Central Government in the Ministry of Environment, Forest and Climate Change may give such directions,
as it deems fit, to the Monitoring Committee for effective discharge of its functions.
7.

The Central Government and State Government may specify additional measures, if any, for giving effect to
provisions of this notification.

8.

The provisions of this notification shall be subject to the orders, if any, passed, or to be passed, by the Hon’ble
Supreme Court of India or the High Court or National Green Tribunal.
[F. No. 25/49/2016-ESZ-RE]
Lalit Kapur, Scientist’G’

<!-- page 24 -->

24

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

ANNEXURE-I
MAP OF ECO-SENSITIVE ZONE OF SENCHAL WILDLIFE SANCTUARY WITH LATITUDES AND
LONGITUDES

O
BOUNDARY DESCRIPTION OF THE ECO-SENSITIVE ZONE AROUND Senchal Wildlife Sanctuary are as
follows:North
-Tea State
South
-Small Town
East
-Railway Station
West
-Railway Station

Sl No
1
2
3
4

Latitude
27000’33.2’’
26059’30.1’’
26059’34.3’’
26057’12.4’’

Co-ordinates of Wildlife Santuary:Longitude
88015’38’’
88014’30.3’’
88015’31.7’’
88017’30.5’’

<!-- page 25 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k
26057’56.1’’
26058’33.2’’
26058’47.5’’
27001’40.15’’
27002’8.5’’
27000’49.4’’

5
6
7
8
9
10

25
88018’37.8’’
88020’32.1’’
88018’49.3’’
88019’18.9’’
88017’23.1’’
88016’56.9’’

Co-ordinates of Eco-sensitive Zone boundary:Longitude
88°14’43.0’’E

SL NO.
1.

Latitude
27°00'24.03"N

2.

88°13’37.6’’E

26°59'20.6"N

3.
4.
5.
6.
7.
8.
9.

88°14’21.4’’E
88°16’5.6’’E
88°17’5.7’’E
88°19’27.9’’E
88°21’4.4’’E
88°19’34.1’’E
88°18’36.2’’E

26°58'35.5"N
26°58'9.1"N
26°56'48.9"N
26°57'4.8"N
26°58'38.6"N
26°59'30.1"N
27°01'59.7"N

10.

88°16’31.8’’E

27°01'14.7"N

ANNEXURE-II
List of Village within the 0.5 Km of the Boundary of Senchal Wildlife Sanctuary
SLNo

Village Name

1

JL
No

3
4
5
6
7
8
9
10

Police
Station

Population

Activity

16
RagiroomTE

2

Area in
Hec.

Jorebunglow
Passibong
Dhoteria
Kalej Valley
Sonada
Labdah
Mungpoo
Cinchona
Pubong
Dawaipani

13
12
23
21
20
28
29
21
20

245

Jorbunglow

1352

Labour in TG

290

Jorbunglow

1363

Business/Labour

75

Jorbunglow

2509

Labour in TG

440

Jorbunglow

4724

Labour in TG

293

Jorbunglow

2428

Labour in TG

400

Sonoda
RangliRunglihat
RangliRanglihat
Rungli –
Rnaglihat
Darjeeling
Sadar

9030

Business/labour/Agriulture

1359
12742

Labour and Agriculture
Cinchona Planbtaion
Labour

1606

Agriculture

5370

Agriculture/Tea/ labour

757.37
11555.7
632.03
424.57

Coordinates
27°01'22.97"N
88°20'26.59"E
27°00'27.7"N
88°15'33.7"E
26°59'31.7"N
88°13'5.06"E
26°59'28.7"N
88°15'33.2"E
26°58'39.5"N
88°15'12.07"E
26°57’'39.2"N
88°16'30.3"E
26°57'41.3"N
88°20'8.4"E
26°59'18.5"N
88°20'33.3"E
27°01'22.6"N
88°17'45.6"E
27°01'47.3"N
88°18'30.7"E

<!-- page 26 -->

26

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]
ANNEXURE-III

Performa of Action Taken Report: - Eco-sensitive Zone Monitoring Committee.1.

Number and date of Meetings:

2.

Minutes of the meetings: Mention main noteworthy points. Attach Minutes of the meeting as separate Annexure.

3.

Status of preparation of Zonal master Plan including Tourism master Plan:

4.

Summary of cases dealt for rectification of error apparent on face of land record: Details may be attached as
Annexure.

5.

Summary of cases scrutinized for activities covered under the Environment Impact Assessment Notification,
2006: Details may be attached as separate Annexure.

6.

Summary of cases scrutinized for activities not covered under the Environment Impact Assessment Notification,
2006: Details may be attached as separate Annexure.

7.

Summary of complaints ledged under Section 19 of the Environment (Protection) Act, 1986:

8.

Any other matter of importance:

RAKESH
SUKUL
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

Digitally signed by RAKESH
SUKUL
Date: 2017.11.13 20:15:21
+05'30'
