---
doc_id: "0cdef0af08ca2ad5"
source_url: "https://home.wb.gov.in/public/assets/frontend/pdf/ais_performance_appraisal_report_rules.pdf"
ministry: "Home and Hill Affairs Department, West Bengal"
title: "0 7  AIS PERFORMANCE APPRAISAL REPORT RULES"
date: ""
pages: 162
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8a1bb93017ac2ed3"
---

<!-- page 1 -->

17.1THE ALL INDIA SERVICES (PERFORMANCE
APPRAISAL REPORT) RULES, 2007
In exercise of the powers conferred by sub-section (1) of section 3 of the All India
Services Act, 1951, (61 of 1951), and in supersession of the All India Services
(Confidential Rolls) Rules, 1970, except as respect things done or omitted to be done
before such supersession, the Central Government, after consultation with the
Governments of the States concerned, hereby makes the following rules, namely: 1. Short title, commencement and application.- (1) These rules may be called the All
India Services (Performance Appraisal Report) Rules, 2007.
(2)
Gazette.

They shall come into force on the date of their publication in the Official

2. Definitions. - In these rules, unless the context otherwise requires;(a)
“accepting authority” means the authority which supervises the
performance of the reviewing authority as may be specifically empowered in this behalf
by the Government;
(b)
“benchmark score” shall mean the minimum numerical weighted mean
score arrived at for overall grading above which an officer shall be regarded as fit for
promotion or empanelment, as the case may be, to the next higher grade;
(c)
“empanelment” means the process of assessing the suitability for
appointment at the level of Joint Secretary and above as well as equivalent posts in the
Government of India;
(d)

“Government” means, –
(i)

In the case of a member of the Service serving in connection with the
affairs of a State, or who is deputed for service in any company,
association or body of individuals whether incorporated or not, which is
wholly or substantially owned or controlled by the Government of a
State, or in a local authority set up by an Act of the Legislature of a
State, the Government of that State;

(ii)

in any other case, the Central Government;

(e)
“member of the Service” means a member of an All India Service as
defined in section 2 of the All India Services Act, 1951 (61 of 1951);
(f)
“performance appraisal report” means the performance appraisal report
referred to in rules 4 and 5;

1

Published vide Notification No.11059/18/2002-AIS-III dated 14.03.2007 vide GSR No.197(E) dated 14.03.2007 in
supersession of All India Service (Confidential Roll) Rules, 1970

557

<!-- page 2 -->

(g)
“performance appraisal dossier” means the compilation of the
performance appraisal reports written on a member of the Service, referred to in rule 3,
and includes such other documents as may be specified by the Central Government, by
general or special order, in this behalf;
(h)
“promotion” means appointment of a member of the Service to the next
higher grade over the one in which he is serving at the relevant time;
(i)
“referral board” means a board consisting of officers of the Service
designated by the Central Government for cases relating to all officers of the Service on
Central deputation, or for officers of State cadres serving in the State, specified in
Schedule 3;
(j)
reporting authority” means such authority or authorities supervising the
performance of the member of the Service reported upon as may be specifically
empowered in this behalf by the Government;
(k)
“reviewing authority” means such authority or authorities supervising the
performance of the reporting authority as may be specifically empowered in this behalf
by the Government;
(l)

“Schedule” means the Schedule annexed to these rules;

(m)
“State” means a State specified in the First Schedule to the Constitution and
includes a Union Territory;
(n)
“State Government” means the Government of the State on whose cadre
the member of the Service is borne and in relation to a member of the Service borne on
a Joint Cadre, the Joint Cadre Authority.
3. Maintenance and custody of performance appraisal dossier. - A comprehensive
performance appraisal dossier shall be maintained for each member of the Service by
the State Government and the Central Government in the manner specified under these
rules and the performance appraisal dossier shall consist of the documents specified in
Schedule 1.
4. Form of the performance appraisal report. - The reporting authority shall write the
performance appraisal report in such form as may be specified by the Central
Government in Schedule 2 and the officer reported upon and the reporting, reviewing
and accepting authority shall ensure that the portions of the forms which are to be filled
in by them are completed by them within the time limit specified in this behalf by the
Central Government:
Provided that the Central Government may make such additions in the form or the
cut-off dates so specified as may be considered necessary or desirable.
Provided further that the performance appraisal report shall also be written in such
form as may be specified in this behalf by the Central Government for the members of
the Service on deputation and be treated as mandatory input for empanelment and
promotion and placed in the performance appraisal dossier:

558

<!-- page 3 -->

Provided also that the performance appraisal report shall also be written for
members of Service who are on training or study leave in such form as may be specified
in this behalf by the Central Government.
5. Performance appraisal reports.- (1) A performance appraisal report assessing the
performance, character, conduct and qualities of every member of the Service shall be
written for each financial year or as may be specified by the Government in the Schedule
2:
Provided that a performance appraisal report may not be written in such cases as
may be specified by the Central Government, by general or special order:
Provided further that if a performance appraisal report for a financial year is not
recorded by 31st of December of the year in which the financial year ended, no remarks
may be recorded thereafter and the officer may be assessed on the basis of the overall
record and self assessment for the year, if he has submitted his self-assessment on
time.
(2)
Subject to the provisions of sub-rule (4), a performance appraisal report shall
also be written when either the reporting or reviewing authority or the member of the
Service reported upon relinquishes charge of the post, and, in such a case, it shall be
written at the time of the relinquishment or ordinarily within one month of such
relinquishment.
(3)
Where more than one performance appraisal reports are written on a
member of the Service during the course of a financial year each such report shall
indicate the period to which it pertains:
Provided that only one report shall be written on a member of the Service for a
particular period during the course of the financial year and there shall be a single
reporting, reviewing and accepting authority at each level of assessment which shall be
specified in the channel for writing performance appraisal reports by the concerned
Ministries and State Governments and in no circumstances more than one person shall
write the performance appraisal reports in the capacity of reporting, reviewing or
accepting authority for a given period of time:
Provided further that if more than one person of the same superior level supervises
the performance of the member of Service, the Government shall identify the person to
report or review well in advance of the relevant assessment year.
(4)
Where the reporting authority has not seen, but the reviewing authority has
seen the performance of a member of the Service for at least three months during the
period for which the performance appraisal report is to be written the reviewing authority
shall write the performance appraisal report of any such member for any such period.
(5)
Where, both the reporting authority and the reviewing authority have not seen
and the accepting authority has seen, as referred to in sub-rule (4), the performance of
any such member, the accepting authority shall write the performance appraisal of any
such member during such period.

559

<!-- page 4 -->

(6)
Where the reporting authority, the reviewing authority and the accepting
authority have not seen the performance of a member of the Service for at least three
months during the period for which the report is to be written, the Government shall
make an entry to that effect in the performance appraisal report for any such period.
(7)
Notwithstanding anything contained in sub-rules (1), (2), (4) and (5), it shall
not be competent for the reporting authority, the reviewing authority or the accepting
authority to write a performance appraisal report after he demits office where the
authority writing the performance appraisal report is not a Government servant.
Explanation. - For the purposes of this rule, “a Minister” shall not be construed as
having demitted the office if he continues to be a Minister in the Council of Ministers with
a different portfolio or in the Council of Ministers immediately reconstituted after the
previous Council of Ministers of which he was a Minister with the same or a different
portfolio provided the Prime Minister or the Chief Minister, as the case may be,
continues in office.
6. Review of the performance appraisal report. - (1) The reviewing authority shall
record his remarks on the performance appraisal report, within the timeframe specified in
the Schedule 2.
(2)
Where the report is written by the reviewing authority under sub-rule (4) of
rule 5, or where the reviewing authority has not seen, and the accepting authority has
seen, the performance of a member of the Service for at least three months during the
period for which the performance appraisal report is written, the accepting authority shall
review the performance appraisal report of any such member for any such period within
the timeframe specified in the Schedule 2.
(3)
It shall not be competent for the reviewing authority, or the accepting
authority, to review any such performance appraisal report unless it has seen the
performance of the member of the Service for at least three months during the period for
which the report has been written, and in every such case an entry to that effect shall be
made in the performance appraisal report.
(4)
Notwithstanding anything contained in sub-rules (1) and (2), it shall not be
competent for the reviewing authority or the accepting authority to review any such
performance appraisal report(a) Where the authority reviewing the performance appraisal report is a Government
servant, after one month of his retirement from service, and
(b) In other cases, after one month of the date on which he demits office.
Explanation. - For the purposes of this rule, “a Minister” shall not be construed as
having demitted the office if he continues to be a Minister in the Council of Ministers with
a different portfolio or in the Council of Ministers immediately reconstituted after the
previous Council of Ministers of which he was Minister with the same or a different
portfolio provided the Prime Minister or the Chief Minister, as the case may be,
continues in office.

560

<!-- page 5 -->

7. Acceptance of the Performance Appraisal Report. - (1) The accepting authority
shall within the timeframe specified in Schedule 2, record his remarks on the
performance appraisal report and may accept it, with such modifications as may be
considered necessary, and countersign the report:
Provided that where the accepting authority has not seen the performance of any
member of the Service for at least three months during the period for which the
performance appraisal report has been written, it shall not be necessary for the
accepting authority to accept any such report and an entry to this effect shall be made in
the performance appraisal report.
(2)
Notwithstanding anything contained in sub-rule (1), it shall not be competent
for the accepting authority to accept and countersign any such performance report(a)

where the accepting authority is a Government servant, after one month
of his retirement from service, and

(b)

in other cases, one month after the date on which he demits the office.

(3)
When the performance appraisal report be not written or revised.Notwithstanding anything contained in rule 5 or rule 6, where the accepting authority
writes or reviews the performance appraisal report of any member of the Service, it shall
not be necessary to review or accept any such report.
8. Communication of the performance appraisal report to the Central Government
and the State Government. - A certified true copy of the performance appraisal report
shall be sent to the Central Government or the State Government or both to the Central
Government and the State Government, according as the member of the Service is
serving in connection with the affairs of the State, on whose cadre he is borne, or the
Union, or a State to which he has been deputed under sub-rule (1) of rule 6 of the
respective All India Services Cadre Rules:
Provided that if the performance appraisal report is written in a language other than
Hindi or English, it shall be accompanied by an authentic certified translation in Hindi or
English.
9. Disclosure of performance appraisal report to the officer reported upon and
procedure for representation to the Referral Board. - (1) The full annual performance
appraisal report, including the overall grade and assessment of integrity, shall be
disclosed to the officer reported upon after finalisation by the accepting authority to
enable the officer reported upon to represent his case.
(2)
The officer reported upon may have the option to give his comments on the
performance appraisal report in writing to the accepting authority within fifteen days of
the receipt of the Performance Appraisal Report.
(3)
The comments shall be restricted to the specific factual observations
contained in the Performance Appraisal Report leading to the assessment of the officer
in terms of attributes, work output and competency.

561

<!-- page 6 -->

(4)
The accepting authority shall within fifteen days of receipt of comments from
the officer reported upon forward the same to the reviewing and the reporting authority
and call for their views on the comments.
(5)
The reporting authority shall, within fifteen days of receipt of comments from
the officer reported upon forward his own views on the comments to the reviewing
authority failing which it shall be presumed that he has no views thereon.
(6)
The reviewing authority shall forward the comments of the officer reported
upon along with the views of the reporting authority and his own views to the accepting
authority within fifteen days of receipt of the views of the reporting authority.
(7)
The accepting authority shall consider the comments of the officer reported
upon, the views of the reporting authority and the reviewing authority and after due
consideration may accept them and modify the performance appraisal report accordingly
and the decision and final grading shall be communicated to the officer reported upon
within fifteen days of receipt of the views of the reviewing authority.
(8)(a) In case the officer reported upon chooses to represent against the final
assessment conveyed to him according to this procedure, he may represent his case
through the accepting authority for a decision by the Referral Board, as specified in the
Schedule 3, within one month, provided that such representation shall be confined to
errors of facts.
(b) The representation of the officer reported upon along with the views of the
reporting authority, the reviewing authority and the accepting authority shall be
forwarded to the Referral Board on the request of the officer reported upon within a
period of fifteen days of receipt of communication.
(9)(a) The Referral Board shall consider the representation of the officer reported
upon in the light of the comments of the reporting authority, the reviewing authority and
the accepting authority and confirm or modify the performance appraisal report, including
the overall grade and the decision of the Referral Board shall be confined only to errors
of facts and the decision of the Referral Board shall be final.
(b) In case an entry or assessment is upgraded or down graded, reasons for the
same shall be recorded in the performance appraisal report.
(10) The entire performance appraisal report, including the overall grade, shall
thereafter be communicated to the officer reported upon which shall conclude the
process of assessment and no further representation of any kind shall be entertained
thereafter.
10. Memorial against assessment. - Nothing in these rules shall be deemed to
preclude an officer from making a memorial to the President on the Performance
Appraisal Report, as provided under rule 25 of the All India Services (Discipline and
Appeal) Rules, 1969.
11. General. - The Central Government may issue instructions, not inconsistent with the
provisions of these rules, or as it may consider necessary, with regard to the writing of

562

<!-- page 7 -->

the performance appraisal reports, the maintenance of the performance appraisal
dossier and the effect of the performance appraisal reports on the conditions of service
of a member of the Service.
SCHEDULE 1
[See rule 3]
Documents to be maintained in the Performance Appraisal Dossier
(i) A Curriculum Vitae to be updated annually on the basis of the performance appraisal
reports and a five-yearly Curriculum Vitae update submitted by the officer reported upon
(ii) The performance appraisal reports earned throughout the career.
(iii) Certificates of training, academic courses attended after joining service, study leave
(iv) Details of books, articles and other publications.
(v) Appreciation letters from Government or Secretary or Head of Department or special
bodies or Commissions.
(vi) Reports of medical check-ups.
(vii) Copy of order imposing any of the penalties specified in the All India Services
(Discipline and Appeal) Rules, 1969 and final result of inquiry into allegations and
charges against a member of the Service.
(viii) Warnings or displeasure or reprimands of the Government
2

SCHEDULE 2
[See rule 4]

List of Appendices containing Forms for Performance Appraisal Report
Appendix I – Performance Appraisal Report Forms and summary of medical report
for the Indian Administrative Service

2

•

Form I and general guidelines for filling up the Performance Appraisal Report
form for the Indian Administrative Service officers except the level of Secretary or
Additional Secretary or equivalent to Government of India.

•

Form II and general guidelines for filling up the Performance Appraisal Report
form for the Indian Administrative Service officers of the level of Secretary or
Additional Secretary or equivalent to Government of India.

•

Form III for the Indian Administrative Service officers who are on deputation
under clauses (i) and (ii) of sub-rule (2) of rule 6 of the Indian Administrative
Service (Cadre) Rules, 1954.

•

Form IIIA Performance Report on study leave or leave for study for Indian
Administrative Service officers.

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

563

<!-- page 8 -->

•

Form IIIB Performance report on training (applicable for the Indian Administrative
Service officers).

Appendix II – Performance Appraisal Report Forms and summary of medical
report for the Indian Police Service officers
•

Form I and general guidelines for filling up the Performance Appraisal Report
form for the Indian Police Service officers except the level of Additional Director
General of Police or Director General of Police or equivalent.

•

Form II and general guidelines for filling up the Performance Appraisal Report
form for the Indian Police Service officers of the level of Additional Director
General of Police or Director General of Police or equivalent.

•

Form III for the Indian Police Service officers who are on deputation under
clauses (i) and (ii) of sub-rule 2 of rule 6 of the Indian Police Service (Cadre)
Rules, 1954.

•

Form IIIA Performance Report on study leave or leave for study for Indian Police
Service officers.

•

Form IIIB Performance report on training (applicable for the Indian Police Service
officers).

Appendix III – Performance Appraisal Report Forms and summary of medical
report for the Indian Forest Service officers
•

Form I and general guidelines for filling up the Performance Appraisal Report
form for the Indian Forest Service officers except the level of Principal Chief
Conservator of Forests or Additional Principal Chief Conservator of Forests.

•

Form II and general guidelines for filling up the Performance Appraisal Report
form for the Indian Forest Service officers of the level of Principal Chief
Conservator of Forests or Additional Principal Chief Conservator of Forests.

•

Form III for the Indian Forest Service officers who are on deputation under
clauses (i) and (ii) of sub-rule 2 of rule 6 of the Indian Forest Service (Cadre)
Rules, 1966.

•

Form IIIA Performance Report on study leave or leave for study for Indian Forest
Service officers.

•

Form IIIB Performance report on training (applicable for the Indian Forest Service
officers).”.
3

SCHEDULE 3

[See rule 2 (i)]
Composition of the Referral Board
For Indian Administrative Service
(a) In respect of officers working in the States -

3

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

564

<!-- page 9 -->

(i)

Chief Secretary of the State

Chairperson

(ii)

Senior most Secretary in the State

Member

(iii)

Secretary (Appointments)

Convener

(b) In respect of officers working in the Centre (i)

Cabinet Secretary

Chairperson

(ii)

Secretary (Personnel)

Member

(iii)

Establishment Officer

Convener

For Indian Police Service
(a)In respect of officers working in the States –
(i)

Chief Secretary of the State

Chairperson

(ii)

Director General of Police

Member

(iii)

Secretary (Appointments)

Member

(iv)

Principal Secretary/Secretary, Home Department

Convener

(b)In respect of officers working in the Centre –
(i)

Cabinet Secretary

Chairperson

(ii)

Secretary (Home)

Member

(iii)

Establishment Officer, Department of Personnel and
Training

Member

(iv)

Joint Secretary (Police)

Convener

Provided that when the officer being appraised is of the level of Joint Secretary or
above, the Joint Secretary (Police) may be replaced by an officer of the level of
Secretary to be nominated by the Cabinet Secretary.”.
For Indian Forest Service
(a) In respect of officers working in the States (i)

Chief Secretary of the State

Chairperson

(ii)

Principal Chief Conservator of Forests in the State

Member

(iii)

Secretary (Appointments)

Member

(iv)

Principal Secretary (Environment and Forests)/ Convener
Secretary (Environment and Forests)

(b) In respect of officers working in the Centre –
(i)

Cabinet Secretary

Chairperson

(ii)

Secretary (Environment and Forests)

Member

(iii)

Establishment Officer, Department of Personnel and
Training

Member

(v)

Joint Secretary (CCI)

Convener

565

<!-- page 10 -->

Provided that when the officer being appraised is of the level of Joint Secretary or
above, the Joint Secretary (CCI) may be replaced by an officer of the level of
Secretary to be nominated by the Cabinet Secretary.

566

<!-- page 11 -->

4

Appendix I
Form I

[See rule 4]
The All India Services (Performance Appraisal Report) Rules, 2007
(Applicable for All IAS officers except the level of Secretary or Additional Secretary or
equivalent to Government of India)
Performance Appraisal Report for the period from _________ to __________
Section I – Basic Information
(To be filled in by the Administration Division/Personnel Department)
1.Name of the officer reported upon:

2.Service:

3.Cadre:

6.Present Grade:

4.Year of allotment:

5.Date of Birth:

7.Present post:

8.Date of appointment to present post:
9.Reporting, Reviewing and Accepting Authorities
Name & Designation
Reporting Authority
Reviewing Authority
Accepting Authority
10.Period of absence on leave, etc.
Period
On Leave (specify type)
Others (specify)

Type

11.Training Programs attended
Date from
Date to
Institute

4

Period worked

Remarks

Subject

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

567

<!-- page 12 -->

12. Awards/Honours

13. Details of PARs of AIS officers not written by the officer as reporting/reviewing
authority for the previous year

14. Date of filing the property return for year ending December

15. 5Date of last prescribed medical examination (for officers over 40
years of age). Attach copy of the summary of the medical report

Date:

Signature on behalf of______________________
Admn/Personnel Dept

Section II – Self Appraisal
1.Brief description of duties:
(Objectives of the position you hold and the tasks you are required to perform, in about
100 words)

5

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

568

<!-- page 13 -->

2.Annual work plan and achievement:
Tasks to be performed

Deliverables6[1]
Initial8[3]

Actual
Achievement 7[2]

Mid year9[4]

3.During the period under report, do you believe that you have made any
exceptional contribution, e.g. successful completion of an extraordinarily
challenging task or major systemic improvement (resulting in significant benefits
to the public and/or reduction in time and costs)? If so, please give a verbal
description (within 100 words):

6[1]

Deliverables refer to quantitative or financial targets or verbal description of expected outputs.
Actual achievement refers to achievement against the specified deliverables in respect of each task (as updated at
mid-year). No explanations for divergences are to be given in this table.
8[3]
Initial listing of deliverables are to be finalized within 1 month of the start of the period under report.
9[4]
Mid year listing of deliverables are to be finalized within 6 months of the start of the period under report.
7[2]

569

<!-- page 14 -->

4.What are the factors that hindered your performance?

5. Please indicate specific areas in which you feel the need to upgrade your skills
through training programs:
For the current assignment:

For your future career

Please Note: You should send an updated CV, including additional qualifications
acquired/ training programs attended/ publications/ special assignments
undertaken, in a prescribed proforma, to the cadre controlling authority, once in
5 years, so that the records available with the cadre controlling authority remain
updated.
6. Declaration
Have you filed your immovable property return, as due. If
yes, please mention date.
Have you undergone the prescribed medical check up?
Have you set the annual work plan for all officers for the
current year, in respect of whom you are the reporting
authority?

Yes/No

Date

Yes/No
Yes/No

Signature of officer reported upon _______________
Date:

570

<!-- page 15 -->

Section III

Appraisal

1.Please state whether you agree with the responses relating to the accomplishments of
the work plan and unforeseen tasks as filled out in Section II. If not, please furnish
factual details.

2.Please comment on the claim (if made) of exceptional contribution by the officer
reported upon.

3. Has the officer reported upon met with any significant failures in respect of his work? If
yes, please furnish factual details.

4.Do you agree with the skill up-gradation needs as identified by the officer?

571

<!-- page 16 -->

5. Assessment of work output (This assessment should rate the officer vis-à-vis his peers
and not the general population. Grades should be assigned on a scale of 1-10, in whole
numbers, with 1 referring to the lowest grade and 10 to the best grade. Weightage to this
Section will be 40%).
Reporting Reviewing Initial of
Authority Authority
Reviewing
Authority
i.
Accomplishment of planned work
ii
Quality of output
iii.
Accomplishment of exceptional work /
unforeseen tasks performed
Overall Grading on ‘Work Output’
6. Assessment of Personal Attributes (on a scale of 1-10. Weightage to this Section
will be 30%).
Reporting Review
Initials of
Authority Authority Reviewing
Authority
i.
Attitude to work
Ii
Sense of responsibility
Iii
Overall bearing and personality
Iv
Emotional stability
V
Communication skills
vi
Moral courage and willingness to take a
professional stand
vii. Leadership qualities
viii. Capacity to work in time limit
Overall Grading on Personal Attributes
7. Assessment of Functional Competency (on a scale of 1-10. Weightage to this
Section will be 30%).
Reporting Review
Initials of
Authority Authority Reviewing
Authority
i.
Knowledge of laws/rules/procedures/ IT skills
and awareness of the local norms in the
relevant area
ii.
Strategic planning ability
iii.
Decision making ability
iv.
Initiative
v.
Coordination ability
vi.
Ability to motivate and develop subordinates /
work in a team.
Overall Grading on ‘Functional competency’

572

<!-- page 17 -->

8.Integrity
Please comment on the integrity of the officer:

9. Pen picture by Reporting Officer. Please comment ( in about 100 words) on the
overall qualities of the officer including areas of strengths and lesser strengths
and his attitude towards weaker sections.

573

<!-- page 18 -->

10. Recommendation relating to domain assignment (Please tick mark any four)
Agriculture and Rural Development

Public Finance & Financial
Management
Industry and Trade
Internal Affairs and Defence
Housing & Urban Affairs
Personnel & General Administration,
Governance
Reform,
Regulatory
Systems
Science & Technology

Social Development
Culture and Information
Natural Resource Management
Energy and Environment

Communication Systems and
Connectivity Infrastructure
11. Overall grade (on a score of 1-10)

Signature of Reporting Authority ___________
Date:
Section IV

–

Review

1. Do you agree with the assessment made by the reporting officer with respect to the
work output and the various attributes in section III? Do you agree with the assessment
of the reporting officer in respect of extraordinary achievements and/or significant
failures of the moS / officer reported upon?
(In case you do not agree with any of the numerical assessments of attributes please
record your assessment in the column provided for you in that section and initial your
entries).
Yes

No

2. In case of difference of opinion details and reasons for the same may be given.

574

<!-- page 19 -->

3. 10Comments, if any, on the pen picture written by the Reporting Authority.

4. Recommendation relating to domain assignment (Please tick mark any four)
Agriculture and Rural Development
Public Finance & Financial
Management
Social Development
Industry and Trade
Culture and Information
Internal Affairs and Defence
Natural Resource Management
Housing & Urban Affairs
Energy and Environment
Personnel & General Administration,
Governance Reform, Regulatory
Systems
Communication Systems and
Science & Technology
Connectivity Infrastructure
5.Overall grade on a scale of 1-10

Signature of Reviewing Authority ____________________
Date:
Section V

Acceptance

1. Do you agree with the remarks of the reporting / reviewing authorities?
Yes

No

2. In case of difference of opinion details and reasons for the same may be given.

3. Overall grade (on a score of 1-10)

Date

10

Signature of Accepting Authority_______________

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

575

<!-- page 20 -->

General guidelines for filling up the PAR form for IAS officers except the level of
Secretary or Additional Secretary or equivalent to the Government of India.
1.
Introduction
1.1.
The Performance Appraisal Report is an important document. It provides the
basic and vital inputs for further development of an officer. The officer reported upon, the
Reporting Authority, Reviewing Authority and the Accepting Authority should therefore,
undertake the duty of filling up the form with a high sense of responsibility.
1.2
Performance appraisal should be used as a tool for career planning and training,
rather than a mere judgmental exercise. Reporting Authorities should realize that the
objective is to develop an officer so that he/she realizes his/her true potential. It is not
meant to be a faultfinding process but a developmental tool. The Reporting Authority,
the Reviewing Authority and the Accepting Authority should not shy away from reporting
shortcomings in performance, attitudes or overall personality of the officer reported
upon.
1.3
The columns should be filled with due care and attention and after devoting
adequate time. Any attempt to fill the report in a casual or superficial manner will be
easily discernible to the higher authorities.
1.4
Although the actual documentation of performance appraisal is a year-end
exercise, in order that it may be a tool for human resource development, career planning
and training, rather than a mere judgmental exercise, the Reporting Authority and the
officer reported upon should meet during the course of the year at regular intervals to
review the performance and to take necessary corrective steps.
2.
Section-I
2.1
This Section should be filled up in the Administration Division/Personnel Deptt.
Period of report could either be the entire reporting year, namely, from 1st of April to 31st
March or a part of the year (exceeding 3 months). In case the period of report is a full
year, it should be indicated accordingly; for example, 2007-2008. In case the period of
report is less than the entire year, specific start and end dates should be indicated, for
example, 10th September 2007 – 31st March 2008.
2.2
Information on the present grade (pay-scale) as well as present post (actual
designation and organization) and the date from which he/she has been on his/her
present post needs to be mentioned.
2.3
In the table relating to reporting, reviewing and accepting authorities the name
and designation of the reporting and reviewing authorities should be mentioned so that
the officer reported upon is clear about whom he/she is required to send the report.
2.4
The period of absence from duty, on leave, training, or for other reasons, should
also be mentioned in this section in the table provided for the purpose. Details of the
training attended, date of filing of property returns and whether the officer reported upon
has reported/reviewed and the annual performance report of all his/her subordinate
officers for the previous year should be mentioned in the table for the purpose.

576

<!-- page 21 -->

11
2.5
This Section provides for regular annual medical examination. The health check
is mandatory for all officers above the age of 40 and may be totally dispensed with for
officers below the age of 40, except in case of medical incident. A copy of the summary
of the medical report is to be attached to the PAR Form by the Admin./Personnel
Department. The format of the health check up and the summary of medical report will
be as circulated by the Cadre Controlling Authority, after consultation with the Ministry of
Health and Family Welfare.

3.
Section-II
3.1
The officer reported upon is first required to give brief description of his/her duties
and responsibilities, which would normally not exceed about 100 words. Ideally, this
should be in bullet form.
3.2
All officers are required to develop a work plan for the year and agree upon the
same with the reporting officer. The work plan should incorporate the relative annual
work rhythm and budgetary cycle. This exercise is to be carried out at the beginning of
the year and finalized by 30th April, positively. In case of a change of the reporting officer
during the year, the work plan agreed with the previous reporting officer would continue
to apply. The work plan agreed upon at the beginning of the year has to be reviewed
again during the month of September/October as a mid-year exercise and finalized by
31st October. Based on this review the work plan may undergo some changes from that
originally prepared.
3.3
After the work plan is prepared, it is possible that the officer reported upon is
transferred out. There need not be more than one work plan for one post each year. The
period spent by the officer during the year and his contribution could be considered for
evaluating his performance against the work plan. In the case of mid-term transfers,
continuity and assessment of work and the lower performance profile in the first quarter
should be taken into consideration.
3.4
The work plans, duly signed by the officer reported upon and the reporting
authority has to be submitted to the reviewing authority for his/her perusal and custody.
The performance appraisal form provides for an assessment of the accomplishments
vis-à-vis the work plan agreed at the commencement of the year and reviewed midyear. The officer reported upon is required to fill up the table provided for the purpose in
Section-II.
3.5
It is not necessary that the work plan should be entirely quantitative in nature.
While for field level posts, the work plan would consist essentially of quantifiable targets,
for secretarial level posts it would consist of policy objectives to be achieved etc.
3.6
Section II also provides an opportunity for the officer to reflect upon his/her
performance during the year and indicate one item which he/she thought was a
significant contributions made by him/her during the year. It is always possible for any
officer to make significant contribution even in activities otherwise regarded as routine in
nature. Examples of such contribution may be the successful organization of a major
event like the Kumbh Mela or successful conclusion of an activity that has been going on
for a long time, or even successful dealing of an emergency (e.g. major earth
quake/flood) would certainly be an exceptional contribution.
11

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

577

<!-- page 22 -->

3.7
The officer reported upon is required to indicate specific areas in which he/she
feels the need to upgrade skills and attend training programs. He/she should also
mention the specific steps that he/she has taken or proposes to take to upgrade his/her
skills in the identified area.
3.8
There is an increased emphasis on competency building in the new performance
appraisal and career progression system. There would be a premium on competency
and skill upgradation. Hence, all officers are advised, through a note in Section II, to
keep the cadre controlling authority informed, at least once in five years, of all
educational and training programs attended, including the details of marks/grades
secured in such programs, details of professional papers published. These would be
taken into account in the future career progression.
3.9
This Section also requires the officer reported upon to record certain certificates
about submission of property returns, annual medical check up and setting up of annual
work plan for whom he/she would be the reporting authority.
4.
Section-III
4.1
Section III requires the reporting authority to comment on Section II as filled out
by the officer reported upon, and specifically state whether he/she agrees with the
responses relating to the accomplishments. In case of disagreement the reporting
authority should highlight the specific portions with which he/she is unable to agree and
the reasons for such disagreement.
4.2
This Section then requires the reporting authority to comment on the skill
upgradation needs as identified by the officer.
4.3
Thereafter, this Section requires the reporting authority to record a numerical
grade in respect of the workout put of the officer reported upon both in respect of the
planned work as well as the unforeseen tasks. A numerical grade is also required in
respect of the “quality” of the output. In doing so, the reporting authority should take into
account the costs incurred (whether the officer reported upon has been cost conscious),
the time taken and whether the laid down rules/procedures have been adhered to in
accomplishing the tasks.
4.4
The reporting authority is also required to record a numerical grade in respect of
work output, personal attributes and functional competencies.
4.5
Section III requires the reporting authority to comment on the integrity of the
officer reported upon. In recording remarks with regard to integrity, he/she need not limit
him/herself only to matters relating to financial integrity but could also take into account
the moral and intellectual integrity of the officer reported upon. The following procedure
should be followed in filling up the column relating to integrity:
(i) If the Officer’s integrity is beyond doubt, it may be stated.
(ii) If there is any doubt or suspicion, the column should be left blank and action taken
as under:
(a) A separate secret note should be recorded and followed up. A copy of the
note should also be sent together with the Performance Appraisal Report to the

578

<!-- page 23 -->

next superior officer who will ensure that the follow up action is taken
expeditiously. Where it is not possible either to certify the integrity or to record
the secret note, the Reporting Officer should state either that he/she had not
watched the officer’s work for sufficient time to form a definite judgement or that
he/she has heard nothing against the officer, as the case may be.
(b) If, as a result of the follow up action, the doubts or suspicions are cleared, the
officer’s integrity should be certified and an entry made accordingly in the
Performance Appraisal Report.
(c) If the doubts or suspicions are confirmed, this fact should also be recorded
and duly communicated to the officer concerned.
(d) If as a result of the follow up action, the doubts or suspicions are neither
cleared nor confirmed, the officers conduct should be watched for a further period
and thereafter action taken as indicated at (b) and (c) above.
4.6
The reporting authority is also required to record a descriptive pen-picture on the
overall qualities of the officer reported upon and his/her performance including his
attitude towards weaker sections. This need not exceed about 100 words and should try
to cover overall qualities of the officer including areas of strengths and lesser strengths.
The pen-picture is also meant to be a qualitative supplement to the quantitative
assessments made earlier part of this section.
4.7
Reporting authority is then required to make recommendations relating to domain
assignment. The list of domains is at para 10.
4.8
Finally, the reporting authority is required to record an overall grade. This should
also be done on a scale of 1-10, with 1 referring to the lowest grade and 10 to the
highest.
5.
Section-IV
12
5.1
This Section is to be filled up by the reviewing authority. He/she is required to
indicate if he/she agrees with the assessments made by the reporting officer. In case of
disagreement, he/she may record his/her own assessment against the work output or
any of the attributes in the column specifically provided for the purpose. In case of
agreement, he/she need not fill in the column meant for him/her in the attributes/work
output tables. Finally, the reviewing authority is required to record an overall grade in the
scale of 1-10.
6.
Section-V
6.1
This Section is to be filled by the accepting authority. He/she is required to
indicate if he/she agrees with the assessments made by the reporting
authority/reviewing authorities. In case of difference of opinion, he/she is required to give
details and reasons for the same in the column specifically provided for the purpose in
the table in Section V.

12

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

579

<!-- page 24 -->

7.
Numerical Grades
7.1
At several places, numerical grades are to be awarded by reporting and review
authorities. These should be on a scale of 1-10, where 1 refers to the lowest grade and
10 to the highest. It is expected that any grading of 1 or 2 (against work output or
attributes or overall grade) would be adequately justified in the pen-picture by way of
specific failures and similarly, any grade of 9 or 10 would be justified with respect to
specific accomplishments. Grades of 1-2 or 9-10 are expected to be rare occurrences
and hence the need to justify them. In awarding a numerical grade the reporting,
reviewing and accepting authorities should rate the officer against a larger population of
his/her peers that may be currently working under them or would have worked under
them in the past.
7.2

Weightage & Mean
Weights have been assigned to work output, personal attributes and functional
competency. The overall grade will be based on the addition of the mean value of each
group of indicators in proportion to weightage assigned.
8.
Disclosure
8.1
There should be more openness in the system of appraisal. The annual PAR,
including the overall grade and integrity, should be communicated to the officer reported
upon after it has been finalized by the accepting authority.
8.2.

Representation
The officer reported upon may have the option to give his comments on the PAR.
Such comments may be restricted to the specific factual observations contained in the
Performance Appraisal Report leading to the assessment of the officer in terms of
attributes,
competency
and
output.
If
comments
are
submitted,
the
Reporting/Reviewing/Accepting Authority would have the option to accept them and
modify the PAR accordingly. If the comments are not accepted, the views of the
Reporting/Reviewing/Accepting Authority would be communicated with reasons to the
officer reported upon. Thereafter, only if the officer reported upon so desires, he may
request for the matter to be forwarded to the Referral Board. The representation shall be
confined to errors of facts and nothing else. The Referral Board shall give clear findings
on the representation and take a final decision on the assessment, including the overall
grading in regard to the parameters affected thereby. The decision along with details in
case an entry is upgraded or down graded with, reasons for same may be recorded in
the PAR and the same communicated to the officer reported upon. The decision of the
Referral Board shall be final.
9.

Schedule for completion of PARs of IAS Officers

9.1

The following schedule should be strictly followed: Reporting Year – Financial Year

Cut-off dates
Below Super Time Super Time
Scale
Scale
st
Blank PAR form to be given to the officer reported
1 April
1st May
upon by the Administration Division/Personnel

Activity

580

<!-- page 25 -->

Department, specifying the reporting officer and
reviewing authority
Self appraisal for current year
Appraisal by reporting authority
Appraisal by reviewing authority
Appraisal by accepting authority
Disclosure to the officer reported upon
Comments of the officer reported upon, if any (if
none, transmission of the PAR to the DOPT)
Forwarding of comments of the officer reported
upon to the reviewing and the reporting authority by
the accepting authority, in case the officer reported
upon makes comments
Comments of reporting authority
Comments of reviewing authority
Comments of accepting authority/PAR to be
finalized and disclosed to the officer reported upon.
Representation to the Referral Board by the officer
reported upon
Forwarding of representation to the Referral Board
along
with
the
comments
of
reporting
authority/reviewing authority and accepting authority
Finalization by Referral Board if the officer reported
upon represents against the decision of the
Accepting Authority.
Disclosure to the officer reported upon
End of entire PAR Process

30th April
31st May
30th June
31st July
15th August
31st August

31st May
30th June
31st July
31st August
15th September
30th September

15th September

15th October

30th September
15th October
31st October

31st October
15th November
30th November

30th November

31st December

15th December

15th January

15th January

15th February

31st January
31st March

28th February
31st March

9.2
The completed PAR should reach the Cadre Controlling Authorities by 31st March
the following year. The Cadre Controlling Authority will prepare a list of PARs not
received and follow up with the Secretaries of the concerned Ministries and Chief
Secretaries of the respective States.
9.3
Secretary (Personnel) in the State and the Establishment Officer in the Centre
shall be the Nodal officers to ensure that the PARs of the members of Service, duly
completed, are sent to the Cadre Controlling Authority by 31st March of the following
year. They shall send a list each of the members of Service whose PARs are to be
written and reviewed to the concerned Reporting/Reviewing/Accepting Authorities by
15th April every year to enable them to ensure completion of PARs within the timeschedule.
9.4.
If a PAR relating to a financial year is not recorded by the 31st of December of the
year in which the financial year ended, no remarks shall be recorded thereafter. The
member of Service will be assessed based on the overall record and self-assessment of
the year concerned, if he had given his self-assessment in time and the Reporting
Authority, Reviewing Authority and the Accepting Authority have not completed the PAR
according to the time schedule given in para 9.1.

581

<!-- page 26 -->

9.5.
The member of Service reported upon shall, while forwarding his self-appraisal to
the Reporting Authority, endorse a copy of the self-appraisal, to the nodal officer and
keep a record of the same as evidence that he had submitted the same in time.
9.6.
The Reporting Authority shall record his comments in the PAR of the officer
reported upon within the stipulated time and send it to the Reviewing Authority along
with a copy thereof to the nodal Authority.
9.7.
In case the Reporting Authority fails to submit the PAR to the Reviewing
Authority within the stipulated period under intimation to the nodal officer, the nodal
officer shall send a copy of self-appraisal directly to the Reviewing Authority and
authorize him to initiate the PAR. The nodal officer shall also keep a note of the failure
of the Reporting Authority to submit the PAR of his subordinate in time for an appropriate
entry in the PAR of such Reporting Authorities.
9.8.
The nodal officer shall evolve a suitable mechanism to ensure that the remarks of
the Reporting, the Reviewing and the Accepting Authorities are recorded without fail by
the dates given in the schedule below Para 9.1.
10.
Mapping of Departments to Domains
I.
Agriculture and Rural Development
1) Department of Agriculture & 2) Department of Agricultural Research
Cooperation
& Education
3) Department of Animal Husbandry, 4) Ministry of Agro & Rural Industries
Dairying & Fisheries
5) Department of Rural Development
6) Ministry of Panchayati Raj
7) Department of Land Resources
8) Department of Drinking Water Supply
9) Department of Food & Public 10) Department of Consumer Affairs
Distribution
11) Ministry of Food Processing
Industries
II.
Social Development
1) Department of Health
2) Department of Family Welfare
3) Department of Ayurveda, Yoga & 4) Department of Secondary & Higher
Naturopathy, Unani, Siddha and
Education
Homeopathy (AYUSH)
5) Department
of
elementary 6) Department of Women & Child
education & Literacy
Development
7) Ministry of Social Justice & 8) Department of Urban Employment &
Empowerment
Poverty Alleviation
9) Ministry of Overseas Indian Affairs
III.
Culture and Information
1) Ministry
of
Information
& 2) Ministry of Culture
Broadcasting
3) Ministry of Tourism
4) Ministry of Tribal Affairs
5) Ministry of Youth Affairs & Sports
IV. Natural Resource Management
1) Ministry of Environment & Forests
2) Ministry of Water Resources
3) Department of Ocean Development
4) Ministry of Mines
V. Energy and Environment

582

<!-- page 27 -->

1) Department of Atomic energy

2) Ministry of Non-Conventional Energy
Sources
4) Ministry of Petroleum & Natural Gas

3) Ministry of Coal
5) Ministry of Power
VI.
Communication Systems and Connectivity Infrastructure
1)
Ministry of Civil Aviation
2) Department of Information Technology
3)
Department
of 4) Department of Posts
Telecommunication
5)
Department of Road Transport 6) Department of Shipping
& Highways
VII.
Public Finance & Financial Management
1) Department of Disinvestment
2) Department of Expenditure
3) Department of Economic Affairs
4) Department of Revenue
5) Ministry of Company Affairs
6) Planning Com mission
7) Ministry of Statistics & Programme
Implementation
VIII. Industry and Trade
1) Department of Industrial Policy & 2)
Department
of
Chemicals
&
Promotion
Petrochemicals
3) Department of Commerce
4) Department of Heavy Industries
5) Department of Fertilizers
6) Ministry of Textiles
7) Department of Public Enterprises
8) Ministry of Small Sale Industries
IX.
Internal Affairs and Defence
1) Department of Defence
2) Department of Defence Production
3) Department of Defence Research & 4) Department
of
Ex-Servicemen
Development
Welfare
5) Department of Internal Security
6) Department of States
7) Department of Official Language
8) Department of Home
9) Department of Jammu & Kashmir 10) Department of Border Management
Affair
11)
Ministry of Development of North
Eastern Region
X.
Housing & Urban Affairs
1) Ministry of Urban Development
XI.
Personnel & General Administration, Governance Reform, Regulatory
Systems
1) Department of Personnel & Training
2) Department of Administrative Reforms
& Public Grievances
3) Department of Pensions & 4) Department of Legal Affairs
Pensioners Welfare
5) Legislative Department
6) Department of Justice
7) Cabinet Secretariat
8) Ministry of Labour & Employment
9) President’s Secretariat
10) Ministry of Parliamentary Affairs
11) Prime Minister’s Office
12) UPSC
13) Election Commission
XII.
Science & Technology
1) Department of Science & Technology 2)Department of Scientific & Industrial
Research
3) Department of Bio-Technology
4) Department of Space

583

<!-- page 28 -->

Form II
[See rule 4]
The All India Services (Performance Appraisal Report) Rules, 2007
(Applicable for IAS officers of the level of Secretary or Additional Secretary or
equivalent to Government of India)
Performance Appraisal Report for the period from _________ to __________
Section I – Basic Information
(To be filled in by the Administration Division/Personnel Department)
1.Name of the officer reported upon:
2.Service:

3.Cadre:

4.Year of allotment:

5.Date of Birth:
6.Present Grade:
7.Present post:
8.Date of appointment to present post:
9.Reporting, Reviewing and Accepting Authorities
Name & Designation

Period worked

Reporting Authority
Reviewing Authority
Accepting Authority
10.Period of absence on leave, etc.
Period
On Leave (specify type)
Others (specify)

Type

11.Training Programs attended
Date from

Date to

Institute

Subject

584

Remarks

<!-- page 29 -->

12. Awards/Honours

13. Details of PARs of AIS officers not written by the officer as reporting/
reviewing authority for the previous year

14. Date of filing the property return for year ending December
15. 13 Date of last prescribed medical examination (for officers over 40
years of age). Attach copy of the summary of the medical report

Date:

Signature on behalf of_________________
Admn/Personnel Dept

Section II
1. Declaration
Have you filed your immovable property return, as due. If
yes, please mention date
Have you undergone the prescribed medical check up?
Have you set the annual work plan for all officers for the
current year, in respect of whom you are the reporting
authority?
Have you prepared the work plan for yourself?
Have you enclosed a note on important achievements
during the period?

Yes/No

Date

Yes/No
Yes/No

Yes/No
Yes/No

Signature____________
Officer reported upon
Date:

13

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

585

<!-- page 30 -->

Section III

Appraisal

1. Assessment of Attributes (This assessment should rate the officer vis-à-vis his peers
and not the general population. Grades should be assigned on a scale of 1-10, in whole
numbers, with 1 referring to the lowest grade and 10 to the best grade. 70% weightage
will be assigned to this item).
Reporting
officer

Reviewing
officer

Initial
Reviewing
Officer

of

i) Attitude to work
ii) Decision making ability
iii) Initiative
iv) Ability to inspire and motivate
v) Strategic Planning
ability/innovativeness
vi) Coordination ability
Overall grading on attributes
2. Assessment of work output (This assessment should rate the officer vis-à-vis his
peers and not the general population. Grades should be assigned on a scale of 1-10, in
whole numbers, with 1 referring to the lowest grade and 10 to the best grade. 30%
weightage will be assigned to this item.)
Reporting
officer

Review
officer

Initial of
Reviewing
Officer

i) Accomplishment of Planned Work
ii) Quality of Output
iii) Accomplishment of exceptional work/
unforeseen tasks during the period
Overall Grading on ‘Work Output’
3. Integrity
Please comment on the integrity of the officer, keeping in mind both his financial integrity
and his moral integrity.

586

<!-- page 31 -->

4. Pen picture by the Reporting Authority.
Please comment (in about 100 words) on the overall qualities of the officer including
areas of strengths and lesser strengths and his attitude towards weaker sections.

5. Recommendation relating to domain assignment (Please tick mark any four).
Agriculture and Rural
Development
Social Development
Culture and Information
Natural Resource Management
Energy and Environment

Public Finance & Financial
Management
Industry and Trade
Internal Affairs and Defence
Housing & Urban Affairs
Personnel & General Administration,
Governance
Reform,
Regulatory
Systems
Science & Technology

Communication Systems and
Connectivity Infrastructure
6. Overall Grade on a scale of 1-10

Signature of Reporting Authority___________
Date:

587

<!-- page 32 -->

Section IV

– Review

1. Do you agree with the assessment made by the reporting officer with respect to the
work output and the various attributes in section III? Do you agree with the assessment
of the reporting officer in respect of extraordinary achievements and/or significant
failures of the moS / officer reported upon?
(In case you do not agree with any of the numerical assessments of attributes
please record your assessment in the column provided for you in that section and
initial your entries)
Yes

No

2. In case of difference of opinion details and reasons for the same may be given.

3. Please comment (in about 100 words) on the overall qualities of the officer
including areas of strengths and lesser strengths and his attitude towards weaker
sections.

14

3A. Comments, if any, on the pen picture written by the Reporting Authority

14

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

588

<!-- page 33 -->

4. Recommendation relating to domain assignment (Please tick mark any four)
Agriculture and Rural Development

Public Finance & Financial
Management
Industry and Trade
Internal Affairs and Defence
Housing & Urban Affairs
Personnel & General Administration,
Governance Reform, Regulatory
Systems
Science & Technology

Social Development
Culture and Information
Natural Resource Management
Energy and Environment

Communication Systems and
Connectivity Infrastructure
5. Overall Grade on a scale of 1-10.

Signature of Reviewing Authority___________
Date:
Section V – Acceptance

1. Do you agree with the remarks of the reporting/reviewing authorities?
Yes

No

2. In case of difference of opinion details and reasons for the same may be given.

3. Overall Grade on a scale of 1-10.

Date

Signature of Accepting Authority________

589

<!-- page 34 -->

General guidelines for filling up the PAR form for IAS officers of the level of
Secretary or Additional Secretary or equivalent to the Government of India.
1.
Introduction
1.1.
The Performance Appraisal Report is an important document. It provides the
basic and vital inputs for further development of an officer. The officer reported upon, the
Reporting Authority, the Reviewing Authority and the Accepting Authority should,
therefore, undertake the duty of filling up the form with a high sense of responsibility.
1.2
Performance appraisal should be used as a tool for career planning and training,
rather than a mere judgmental exercise. Reporting Authorities should realize that the
objective is to develop an officer so that he/she realizes his/her true potential. It is not
meant to be a faultfinding process but a developmental tool. The Reporting Authority,
the Reviewing Authority and the Accepting Authority should not shy away from reporting
shortcomings in performance, attitudes or overall personality of the officer reported
upon.
1.3
The columns should be filled with due care and attention and after devoting
adequate time. Any attempt to fill the report in a casual or superficial manner will be
easily discernible to the higher authorities.
1.4
Although the actual documentation of performance appraisal is a year-end
exercise, in order that it may be a tool for human resource development, career planning
and training, rather than a mere judgmental exercise, the Reporting Authority and the
officer reported upon should meet during the course of the year at regular intervals to
review the performance and to take necessary corrective steps.
2.
Section-I
2.1
This Section should be filled up in the Administration Division/Personnel Deptt.
Period of report could either be the entire reporting year, namely, from 1st of April to 31st
March or a part of the year (exceeding 3 months). In case the period of report is a full
year, it should be indicated accordingly; for example, 2007-2008. In case the period of
report is less than the entire year, specific start and end dates should be indicated, for
example, 10th September 2007 – 31st March 2008.
2.2
Information on the present grade (pay-scale) as well as present post (actual
designation and organization) and the date from which he/she has been on his/her
present post needs to be mentioned.
2.3
In the table relating to reporting, reviewing and accepting authorities the name
and designation of the reporting, reviewing and accepting authorities should be
mentioned so that the officer reported upon is clear about whom he/she is required to
send the report to.
2.4
The period of absence from duty, on leave, training, or for other reasons, should
also be mentioned in this section in the table provided for the purpose. Details of the
training attended date of filing of property returns and whether the officer reported upon
has reported/reviewed should be mentioned in the table for the purpose and annual
performance report of all his/her subordinate officers for the previous year.

590

<!-- page 35 -->

15
2.5
This Section provides for regular annual medical examination. The health check
is mandatory for all officers above the age of 40 and may be totally dispensed with for
officers below the age of 40, except in case of medical incident. A copy of the summary
of the medical report is to be attached to the PAR Form by the Admin./Personnel
Department. The format of the health check up and the summary of medical report will
be as circulated by the Cadre Controlling Authority, after consultation with the Ministry of
Health and Family Welfare.

Section-II
This Section requires the officer reported upon to record certain certificates about
submission of property returns, annual medical check up, setting up of annual
work plan for whom he/she would be the reporting authority as well as for himself.
The officer has to report on the preparation of the work plan for himself and has
the option to enclose a note on the important achievements during the period.
4.
Section-III
4.1
The reporting authority is required to record a numerical grade in respect of
certain attributes and work output.
4.2
This Section requires the reporting authority to record a numerical grade in
respect of the work output of the officer reported upon both in respect of the planned
work as well as the unforeseen tasks. A numerical grade is also required in respect of
the “quality” of the output. In doing so, the reporting authority should take into account
the costs incurred (whether the officer reported upon has been cost conscious), the time
taken and whether the laid down rules/procedures have been adhered to in
accomplishing the tasks.
4.3
Section III requires the reporting authority to comment on the integrity of the
officer reported upon. In recording remarks with regard to integrity, he/she need not limit
him/herself only to matters relating to financial integrity but could also take into account
the moral and intellectual integrity of the officer reported upon. The following procedure
should be followed in filling up the column relating to integrity:
(i) If the Officer’s integrity is beyond doubt, it may be stated.
(ii) If there is any doubt or suspicion, the column should be left blank and action taken
as under:
(a) A separate secret note should be recorded and followed up. A copy of the
note should also be sent together with the Performance Appraisal Report to the
next superior officer who will ensure that the follow up action is taken
expeditiously. Where it is not possible either to certify the integrity or to record
the secret note, the Reporting Officer should state either that he/she had not
watched the officer’s work for sufficient time to form a definite judgement or that
he/she has heard nothing against the officer, as the case may be.
(b) If, as a result of the follow up action, the doubts or suspicions are cleared, the
officer’s integrity should be certified and an entry made accordingly in the
Performance Appraisal Report.
15

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

591

<!-- page 36 -->

(c) If the doubts or suspicions are confirmed, this fact should also be recorded
and duly communicated to the officer concerned.
(d) If as a result of the follow up action, the doubts or suspicions are neither
cleared nor confirmed, the officers conduct should be watched for a further period
and thereafter action taken as indicated at (b) and (c) above.
4.4
The reporting authority is also required to record a descriptive pen-picture on the
overall qualities of the officer reported upon and his/her performance including his
attitude towards weaker sections. This need not exceed about 100 words and should try
to cover overall qualities of the officer including areas of strengths and lesser strengths.
The pen-picture is also meant to be a qualitative supplement to the quantitative
assessments made earlier part of this section.
4.5
The reporting authority is then required to make recommendations relating to
domain assignment. The list of domains is at para 10.
4.6
Finally, the reporting authority is required to record an overall grade. This should
also be done on a scale of 1-10, with 1 referring to the lowest grade and 10 to the
highest.
5.
Section-IV
16
5.1
This Section is to be filled up by the reviewing authority. He/she is required to
indicate if he/she agrees with the assessments made by the reporting officer. In case of
disagreement, he/she may record his/her own assessment against the work output or
any of the attributes in the column specifically provided for the purpose. In case of
agreement, he/she need not fill in the column meant for him/her in the attributes/work
output tables. Finally, the reviewing authority is required to record an overall grade in the
scale of 1-10.
6.
Section-V
6.1
This Section is to be filled by the accepting authority. He/she is required to
indicate if he/she agrees with the assessments made by the reporting
authority/reviewing authorities. In case of difference of opinion, he/she is required to give
details and reasons for the same in the column specifically provided for the purpose in
the table in Section V.
7.
Numerical Grades
7.1
At several places, numerical grades are to be awarded by reporting and review
authorities. These should be on a scale of 1-10, where 1 refers to the lowest grade and
10 to the highest. It is expected that any grading of 1 or 2 (against work output or
attributes or overall grade) would be adequately justified in the pen-picture by way of
specific failures and similarly, any grade of 9 or 10 would be justified with respect to
specific accomplishments. Grades of 1-2 or 9-10 are expected to be rare occurrences
and hence the need to justify them. In awarding a numerical grade the reporting and
reviewing authorities should rate the officer against a larger population of his/her peers
that may be currently working under them or would have worked under them in the past.

16

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

592

<!-- page 37 -->

7.2

Weightage & Mean
Weights have been assigned to attributes and work output. The overall grade
will be based on the addition of the mean value of each group of indicators/descriptive
picture in proportion to weightage assigned. The overall grade will be the average mean
of all the numerical indicators assigned by the authority.
8.
Disclosure
8.1
There should be more openness in the system of appraisal. The annual PAR,
including the overall grade and integrity, should be communicated to the officer reported
upon after it has been finalized by the accepting authority.
8.2

Representation
The officer reported upon may have the option to give his comments on the PAR.
Such comments may be restricted to the specific factual observations contained in the
Performance Appraisal Report leading to the assessment of the officer in terms of
attributes and output. If comments are submitted, the Reporting/Reviewing/Accepting
Authority would have the option to accept them and modify the PAR accordingly. If the
comments are not accepted, the views of the Reporting/Reviewing/Accepting Authority
would be communicated with reasons to the officer reported upon. Thereafter, only if the
officer reported upon so desires, he may request for the matter to be forwarded to the
Referral Board. The representation shall be confined to errors of facts and nothing else.
The Referral Board shall give clear findings on the representation and take a final
decision on the assessment, including the overall grading in regard to the parameters
affected thereby. In case of an adverse entry, the entry and the overall grading may be
communicated. In case an entry is upgraded or down graded, reasons for same may be
recorded in the PAR.
9.

Schedule for completion of PARs of IAS Officers

9.1

The following schedule should be strictly followed: Reporting Year – Financial Year

Activity
Blank PAR form to be given to the officer reported upon by the
Administration Division/Personnel Department, specifying the reporting
officer and reviewing authority
Filling in Section II by the officer reported upon
Appraisal by reporting authority
Appraisal by reviewing authority
Appraisal by accepting authority
Disclosure to the officer reported upon
Comments of the officer reported upon, if any (if none, transmission of
the PAR to the DOPT)
Forwarding of comments of the officer reported upon to the reviewing
and the reporting authority by the accepting authority, in case the
officer reported upon makes comments
Comments of reporting authority
Comments of reviewing authority
Comments of accepting authority/PAR to be finalized and disclosed to

593

Cut-off dates
1 June
st

15th June*
15th July
15th August
15th September
30th September
15th October
31st October
15th November
30th November
15th December

<!-- page 38 -->

him
Representation to the Referral Board by the officer reported upon
Forwarding of representation to the Referral Board along with the
comments of reporting authority/reviewing authority and accepting
authority
Finalization by Referral Board if the officer reported upon represents
against the decision of the Accepting Authority.
Disclosure to the officer reported upon
End of entire PAR Process
*They are required to fill in only Section II - Declaration

31st December
31st January
28th February
15th March
31st March

9.2
The completed PAR should reach the Cadre Controlling Authorities by 31st March
the following year. The Cadre Controlling Authority will prepare a list of PARs not
received and follow up with the Secretaries of the concerned Ministries and Chief
Secretaries of the respective States.
9.3
Secretary (Personnel) in the State and Establishment Officer in the Centre shall
be the Nodal officers to ensure that the PARs of the members of Service, duly
completed, are sent to the Cadre Controlling Authority by 31st March of the following
year. They shall send a list each of the members of Service whose PARs are to be
written and reviewed to the concerned Reporting/Reviewing/Accepting Authorities by
15th April every year to enable them to ensure completion of PARs within the timeschedule.
9.4.
If a PAR relating to a financial year is not recorded by the 31st of December of the
year in which the financial year ended, no remarks shall be recorded thereafter.
9.5.
The Reporting Authority shall record his comments in the PAR of the officer
reported upon within the stipulated time and send it to the Reviewing Authority along
with a copy thereof to the nodal Authority.
9.6.
The nodal officer shall evolve a suitable mechanism to ensure that the remarks of
the Reporting, the Reviewing and the Accepting Authorities are recorded without fail by
the dates given in the schedule below Para 9.1.
10.

Mapping of Departments to Domains

I.
Agriculture and Rural Development
1) Department of Agriculture & 2) Department of Agricultural Research &
Cooperation
Education
3) Department of Animal Husbandry, 4) Ministry of Agro & Rural Industries
Dairying & Fisheries
5) Department of Rural Development
6) Ministry of Panchayati Raj
7) Department of Land Resources
8) Department of Drinking Water Supply
9) Department of Food & Public 10) Department of Consumer Affairs
Distribution
11) Ministry of Food Processing
Industries
II.
Social Development
1) Department of Health
2) Department of Family Welfare

594

<!-- page 39 -->

3) Department of Ayurveda, Yoga &
Naturopathy, Unani, Siddha and
Homeopathy (AYUSH)
5) Department
of
elementary
education & Literacy
7) Ministry of Social Justice &
Empowerment
9) Ministry of Overseas Indian Affairs
III.
Culture and Information
1) Ministry
of
Information
&
Broadcasting
3) Ministry of Tourism
5) Ministry of Youth Affairs & Sports
IV.
Natural Resource Management
1) Ministry of Environment & Forests
3)
Department of Ocean
Development
V.
Energy and Environment
1) Department of Atomic energy

4) Department of Secondary & Higher
Education
6) Department of Women & Child
Development
8) Department of Urban Employment &
Poverty Alleviation

2) Ministry of Culture
4) Ministry of Tribal Affairs

2) Ministry of Water Resources
4) Ministry of Mines

2) Ministry of Non-Conventional Energy
Sources
4) Ministry of Petroleum & Natural Gas

3) Ministry of Coal
5) Ministry of Power
VI.
Communication Systems and Connectivity Infrastructure
1) Ministry of Civil Aviation
2) Department of Information Technology
3) Department
of 4) Department of Posts
Telecommunication
5) Department of Road Transport & 6) Department of Shipping
Highways
VII.
Public Finance & Financial Management
1) Department of Disinvestment
2) Department of Expenditure
3) Department of Economic Affairs
4) Department of Revenue
5) Ministry of Company Affairs
6) Planning Commission
7)
Ministry
of
Statistics
&
Programme Implementation
VIII. Industry and Trade
1) Department of Industrial Policy
2) Department of Chemicals &
& Promotion
Petrochemicals
3) Department of Commerce
4) Department of Heavy Industries
5) Department of Fertilizers
6) Ministry of Textiles
7) Department
of
Public
8) Ministry of Small Sale Industries
Enterprises
IX.
Internal Affairs and Defence
1) Department of Defence
2) Department of Defence Production
3) Department
of
Defence
4) Department
of Ex-Servicemen
Research & Development
Welfare
5) Department of Internal Security
6) Department of States
7) Department of Official Language
8) Department of Home
9) Department
of
Jammu
&
10) Department of Border Management
Kashmir Affair

595

<!-- page 40 -->

11) Ministry of Development of North
Eastern Region
X.
Housing & Urban Affairs
1) Ministry of Urban Development
XI.
Personnel & General Administration, Governance Reform, Regulatory
Systems
1) Department of Personnel &
2) Department of Administrative
Training
Reforms & Public Grievances
3) Department of Pensions &
4) Department of Legal Affairs
Pensioners Welfare
5) Legislative Department
6) Department of Justice
7) Cabinet Secretariat
8) Ministry of Labour & Employment
9) President’s Secretariat
10) Ministry of Parliamentary Affairs
11)Prime Minister’s Office
12) UPSC
13)Election Commission
XII.
Science & Technology
1)
Department of Science &
2)Department of Scientific & Industrial
Technology
Research
3) Department of Bio-Technology
4) Department of Space

596

<!-- page 41 -->

Form III
[See rule 4]
The All India Services (Performance Appraisal Report) Rules, 2007
[17Applicable for Indian Administrative Service officers who are on deputation under
clauses (i) and (ii) of sub-rule (2) of rule 6 of the Indian Administrative Service
(Cadre) Rules, 1954]
Performance Appraisal Report for the period from _________ to __________
Section I – Basic Information
(To be filled in by the Administration Division/Personnel Department)
1.Name of the officer reported upon:
2.Service:

3.Cadre:

4.Year of allotment:

5.Date of Birth:
6.Present Grade:
7.Present post:
8.Date of appointment to present post:
9.Reporting, Reviewing and Accepting Authorities
Name & Designation
Reporting Authority
Reviewing
Authority
Accepting Authority
10.Period of absence on leave, etc.
Period
On Leave (specify type)
Others (specify)
11.Training Programs attended
Date from

17

Date to

Period worked

Type

Institute

Remarks

Subject

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

597

<!-- page 42 -->

12. Awards/Honours

13. Details of PARs of AIS officers not written by the officer as reporting/
reviewing authority for the previous year

14. Date of filing the property return for year ending December
15. 18Date of last prescribed medical examination (for officers over 40
years of age). Attach copy of the summary of the medical report

Date:

Signature on behalf of______________________
Admn/Personnel Dept

Section II – Self Appraisal
1.Brief description of duties:
(Objectives of the position you hold and the tasks you are required to perform, in about
100 words)

2.Annual work plan and achievement:
18

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

598

<!-- page 43 -->

Tasks to be performed

Deliverables19[1]
Initial21[3]

Actual
Achievement 20[2]

Mid year22[4]

3.During the period under report, do you believe that you have made any
exceptional contribution? If so, please give a verbal description (within 100
words):

4. Declaration
19[1]

Deliverables refer to quantitative or financial targets or verbal description of expected outputs.
Actual achievement refers to achievement against the specified deliverables in respect of each task (as updated at
mid-year). No explanations for divergences are to be given in this table.
21[3]
Initial listing of deliverables are to be finalized within 1 month of the start of the period under report.
22[4]
Mid year listing of deliverables are to be finalized within 6 months of the start of the period under report.
20[2]

599

<!-- page 44 -->

Have you filed your immovable property return, as due. If
yes, please mention date.
Have you undergone the prescribed medical check up?
Have you set the annual work plan for all officers for the
current year, in respect of whom you are the reporting
authority?

Yes/No

Date

Yes/No
Yes/No

Signature of officer reported upon _______________
Date:
Section III

Appraisal

1. Assessment of Attributes (This assessment should rate the officer vis-à-vis his peers
and not the general population. Grades should be assigned on a scale of 1-10, in whole
numbers, with 1 referring to the lowest grade and 10 to the best grade). 70% weightage
will be assigned to this item.
Reporting
officer

Reviewing
officer

Initial of Reviewing
Officer

i) Attitude to work
ii) Decision making ability
iii) Initiative
ivi) Ability to inspire and motivate
v) Strategic Planning
ability/innovativeness
vi) Coordination ability
Overall grading on attributes
2. Assessment of work output (This assessment should rate the officer vis-à-vis his
peers and not the general population. Grades should be assigned on a scale of 1-10, in
whole numbers, with 1 referring to the lowest grade and 10 to the best grade. 30%
weightage will be assigned to this item.)
Reporting
officer
i. Accomplishment of Planned Work
Ii Quality of Output
iii. Accomplishment of unforeseen tasks/
exceptional work during the period
Overall Grading on ‘Work Output’

3. Integrity

600

Review
officer

Initial of
Reviewing
Officer

<!-- page 45 -->

Please comment on the integrity of the officer, keeping in mind both his financial
integrity and his moral integrity.

4. Pen picture by the Reporting Authority. Please comment (in about 100 words)
on the overall qualities of the officer including areas of strengths and lesser
strengths.

5. Recommendation relating to domain assignment (Please tick mark any four).
Agriculture and Rural Development
Social Development
Culture and Information
Natural Resource Management
Energy and Environment

Public Finance & Financial Management
Industry and Trade
Internal Affairs and Defence
Housing & Urban Affairs
Personnel & General Administration,
Governance Reform, Regulatory Systems
Science & Technology

Communication Systems and
Connectivity Infrastructure
6. Overall Grade on a scale of 1-10

Signature of Reporting Authority___________
Date:

601

<!-- page 46 -->

Section IV

– Review

1. Do you agree with the assessment made by the reporting officer with respect to the
work output and the various attributes in section III? Do you agree with the assessment
of the reporting officer in respect of extraordinary achievements and/or significant
failures of the moS / officer reported upon?
(In case you do not agree with any of the numerical assessments of attributes
please record your assessment in the column provided for you in that section and
initial your entries)
Yes

No

2. In case of difference of opinion details and reasons for the same may be given.

3. 23Comments, if any, on the pen picture written by the Reporting Authority.

23

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

602

<!-- page 47 -->

4. Recommendation relating to domain assignment (Please tick mark any four)
Agriculture and Rural Development

Public Finance & Financial
Management
Industry and Trade
Internal Affairs and Defence
Housing & Urban Affairs
Personnel & General Administration,
Governance Reform, Regulatory
Systems
Science & Technology

Social Development
Culture and Information
Natural Resource Management
Energy and Environment

Communication Systems and
Connectivity Infrastructure
5. Overall Grade on a scale of 1-10.

Signature of Reviewing Authority__________________
Date:
Section V – Acceptance
1. Do you agree with the remarks of the reporting/reviewing authorities?
Yes

No

2. In case of difference of opinion details and reasons for the same may be given.

3. Overall Grade on a scale of 1-10.

Date

Signature of Accepting Authority________________

603

<!-- page 48 -->

24

General guidelines for filling up the Performance Appraisal Report form for the
Indian Administrative Service officers who are on deputation under clause (i) and
(ii) of sub-rule (2) of rule 6 of the Indian Administrative Service (Cadre) Rules, 1954
1.
Introduction
1.1.
The Performance Appraisal Report is an important document. It provides the
basic and vital inputs for further development of an officer. The officer reported upon, the
Reporting Authority, the Reviewing Authority and the Accepting Authority should,
therefore, undertake the duty of filling up the form with a high sense of responsibility.
1.2
Performance appraisal should be used as a tool for career planning and training,
rather than a mere judgmental exercise. Reporting Authorities should realize that the
objective is to develop an officer so that he/she realizes his/her true potential. It is not
meant to be a faultfinding process but a developmental tool. The Reporting Authority,
the Reviewing Authority and the Accepting Authority should not shy away from reporting
shortcomings in performance, attitudes or overall personality of the officer reported
upon.
1.3
The columns should be filled with due care and attention and after devoting
adequate time. Any attempt to fill the report in a casual or superficial manner will be
easily discernible to the higher authorities.
1.4
Although the actual documentation of performance appraisal is a year-end
exercise, in order that it may be a tool for human resource development, career planning
and training, rather than a mere judgmental exercise, the Reporting Authority and the
officer reported upon should meet during the course of the year at regular intervals to
review the performance and to take necessary corrective steps.
2.
Section-I
2.1
This Section should be filled up in the Administration Division/Personnel Deptt.
Period of report could either be the entire reporting year, namely, from 1st of April to 31st
March or a part of the year (exceeding 3 months). In case the period of report is a full
year, it should be indicated accordingly; for example, 2007-2008. In case the period of
report is less than the entire year, specific start and end dates should be indicated, for
example, 10th September 2007 – 31st March 2008.
2.2
Information on the present grade (pay-scale) as well as present post (actual
designation and organization) and the date from which he/she has been on his/her
present post needs to be mentioned.
2.3
In the table relating to reporting, reviewing and accepting authorities the name
and designation of the reporting, reviewing and accepting authorities should be
mentioned so that the officer reported upon is clear about whom he/she is required to
send the report to.
2.4
The period of absence from duty, on leave, training, or for other reasons, should
also be mentioned in this section in the table provided for the purpose. Details of the
training attended date of filing of property returns and whether the officer reported upon

24

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

604

<!-- page 49 -->

has reported/reviewed should be mentioned in the table for the purpose and annual
performance report of all his/her subordinate officers for the previous year.
25
2.5
This Section provides for regular annual medical examination. The health check
is mandatory for all officers above the age of 40 and may be totally dispensed for with
officers below the age of 40, except in case of medical incident. A copy of the summary
of the medical report is to be attached to the PAR Form by the Admin./Personnel
Department. The format of the health check up and the summary of medical report will
be as circulated by the Cadre Controlling Authority, after consultation with the Ministry of
Health and Family Welfare.

3.
Section-II
3.1
The officer reported upon is first required to give brief description of his/her duties
and responsibilities, which would normally not exceed about 100 words. Ideally, this
should be in bullet form.
3.2
All officers are required to develop a work plan for the year and agree upon the
same with the reporting officer. The work plan should incorporate the relative annual
work rhythm and budgetary cycle. This exercise is to be carried out at the beginning of
the year and finalized by 30th April, positively. In case of a change of the reporting officer
during the year, the work plan agreed with the previous reporting officer would continue
to apply. The work plan agreed upon at the beginning of the year has to be reviewed
again during the month of September/October as a mid-year exercise and finalized by
31st October. Based on this review the work plan may undergo some changes from that
originally prepared.
3.3
After the work plan is prepared, it is possible that the officer reported upon is
transferred out. There need not be more than one work plan for one post each year. The
period spent by the officer during the year and his contribution could be considered for
evaluating his performance against the work plan. In the case of mid-term transfers,
continuity and assessment of work and the lower performance profile in the first quarter
should be taken into consideration.
3.4
The work plans, duly signed by the officer reported upon and the reporting
authority has to be submitted to the reviewing authority for his/her perusal and custody.
The performance appraisal form provides for an assessment of the accomplishments
vis-à-vis the work plan agreed at the commencement of the year and reviewed midyear. The officer reported upon is required to fill up the table provided for the purpose in
Section-II.
3.5
It is not necessary that the work plan should be entirely quantitative in nature.
While for field level posts, the work plan would consist essentially of quantifiable targets,
for secretarial level posts it would consist of policy objectives to be achieved etc.
4.
Section-III
4.1
The reporting authority is required to record a numerical grade in respect of
certain attributes and work output.

25

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

605

<!-- page 50 -->

4.2
This Section requires the reporting authority to record a numerical grade in
respect of the work output of the officer reported upon both in respect of the planned
work as well as the unforeseen tasks. A numerical grade is also required in respect of
the “quality” of the output. In doing so, the reporting authority should take into account
the costs incurred (whether the officer reported upon has been cost conscious), the time
taken and whether the laid down rules/procedures have been adhered to in
accomplishing the tasks.
4.3
Section III requires the reporting authority to comment on the integrity of the
officer reported upon. In recording remarks with regard to integrity, he/she need not limit
him/herself only to matters relating to financial integrity but could also take into account
the moral and intellectual integrity of the officer reported upon. The following procedure
should be followed in filling up the column relating to integrity:
(i) If the Officer’s integrity is beyond doubt, it may be stated.
(ii) If there is any doubt or suspicion, the column should be left blank and action taken
as under:
(a) A separate secret note should be recorded and followed up. A copy of the
note should also be sent together with the Performance Appraisal Report to the
next superior officer who will ensure that the follow up action is taken
expeditiously. Where it is not possible either to certify the integrity or to record
the secret note, the Reporting Officer should state either that he/she had not
watched the officer’s work for sufficient time to form a definite judgement or that
he/she has heard nothing against the officer, as the case may be.
(b) If, as a result of the follow up action, the doubts or suspicions are cleared, the
officer’s integrity should be certified and an entry made accordingly in the
Performance Appraisal Report.
(c) If the doubts or suspicions are confirmed, this fact should also be recorded
and duly communicated to the officer concerned.
(d) If as a result of the follow up action, the doubts or suspicions are neither
cleared nor confirmed, the officers conduct should be watched for a further period
and thereafter action taken as indicated at (b) and (c) above.
4.4
The reporting authority is also required to record a descriptive pen-picture on the
overall qualities of the officer reported upon and his/her performance including areas of
strengths and lesser strengths. This need not exceed about 100 words and should try to
cover overall qualities of the officer including areas of strengths and lesser strengths.
The pen-picture is also meant to be a qualitative supplement to the quantitative
assessments made earlier part of this section.
4.5
The reporting authority is then required to make recommendations relating to
domain assignment. The list of domains is at para 9.
4.6
Finally, the reporting authority is required to record an overall grade. This should
also be done on a scale of 1-10, with 1 referring to the lowest grade and 10 to the
highest.

606

<!-- page 51 -->

5.
Section-IV
26
5.1
This Section is to be filled up by the reviewing authority. He/she is required to
indicate if he/she agrees with the assessments made by the reporting officer. In case of
disagreement, he/she may record his/her own assessment against the work output or
any of the attributes in the column specifically provided for the purpose. In case of
agreement, he/she need not fill in the column meant for him/her in the attributes/work
output tables. Finally, the reviewing authority is required to record an overall grade in the
scale of 1-10.
6.
Section-V
6.1
This Section is to be filled by the accepting authority. He/she is required to
indicate if he/she agrees with the assessments made by the reporting
authority/reviewing authorities. In case of difference of opinion, he/she is required to give
details and reasons for the same in the column specifically provided for the purpose in
the table in Section V.
7.
Numerical Grades
7.1
At several places, numerical grades are to be awarded by reporting and review
authorities. These should be on a scale of 1-10, where 1 refers to the lowest grade and
10 to the highest. It is expected that any grading of 1 or 2 (against work output or
attributes or overall grade) would be adequately justified in the pen-picture by way of
specific failures and similarly, any grade of 9 or 10 would be justified with respect to
specific accomplishments. Grades of 1-2 or 9-10 are expected to be rare occurrences
and hence the need to justify them. In awarding a numerical grade the reporting and
reviewing authorities should rate the officer against a larger population of his/her peers
that may be currently working under them or would have worked under them in the past.
7.2

Weightage & Mean
Weights have been assigned to attributes and work output. The overall grade
will be based on the addition of the mean value of each group of indicators/descriptive
picture in proportion to weightage assigned.
8.

Schedule for completion of PARs of IAS Officers

The completed PAR should reach the Cadre Controlling Authorities by 31st March
the following year. The Cadre Controlling Authority will prepare a list of PARs not
received and follow up with the concerned organisations.
9.

Mapping of Departments to Domains
I.
Agriculture and Rural Development
1) Department of Agriculture & 2) Department of Agricultural Research
Cooperation
& Education
3) Department of Animal Husbandry, 4) Ministry of Agro & Rural Industries
Dairying & Fisheries
5) Department of Rural Development
6) Ministry of Panchayati Raj
7) Department of Land Resources
8) Department of Drinking Water Supply
9) Department of Food & Public 10) Department of Consumer Affairs

26

Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E) dt.31.03.2008

607

<!-- page 52 -->

Distribution
11) Ministry of Food Processing
Industries
II.
Social Development
1) Department of Health
3) Department of Ayurveda, Yoga &
Naturopathy, Unani, Siddha and
Homeopathy (AYUSH)
5) Department
of
elementary
education & Literacy
7) Ministry of Social Justice &
Empowerment
9) Ministry of Overseas Indian Affairs
III.
Culture and Information
1) Ministry
of
Information
&
Broadcasting
3) Ministry of Tourism
5) Ministry of Youth Affairs & Sports
IV.
Natural Resource Management
1) Ministry of Environment & Forests
3) Department of Ocean Development
V. Energy and Environment
1) Department of Atomic energy

2) Department of Family Welfare
4) Department of Secondary & Higher
Education
6) Department of Women & Child
Development
8) Department of Urban Employment &
Poverty Alleviation

2) Ministry of Culture
4) Ministry of Tribal Affairs

2) Ministry of Water Resources
4) Ministry of Mines
2) Ministry of Non-Conventional Energy
Sources
4) Ministry of Petroleum & Natural Gas

3) Ministry of Coal
5) Ministry of Power
VI. Communication Systems and Connectivity Infrastructure
1) Ministry of Civil Aviation
2) Department of Information Technology
3)
Department of Telecommunication 4) Department of Posts
5) Department of Road Transport & 6) Department of Shipping
Highways
VII. Public Finance & Financial Management
1) Department of Disinvestment
2) Department of Expenditure
3) Department of Economic Affairs
4) Department of Revenue
5) Ministry of Company Affairs
6) Planning Com mission
7) Ministry of Statistics & Programme
Implementation
VIII. Industry and Trade
1) Department of Industrial Policy & 2)
Department of Chemicals &
Promotion
Petrochemicals
3) Department of Commerce
4) Department of Heavy Industries
5) Department of Fertilizers
6) Ministry of Textiles
7) Department of Public Enterprises
8) Ministry of Small Sale Industries
IX. Internal Affairs and Defence
1) Department of Defence
2) Department of Defence Production
3) Department of Defence Research & 4) Department
of
Ex-Servicemen
Development
Welfare
5) Department of Internal Security
6) Department of States
7) Department of Official Language
8) Department of Home

608

<!-- page 53 -->

9) Department of Jammu & Kashmir 10) Department of Border Management
Affair
11) Ministry of Development of North
Eastern Region
X. Housing & Urban Affairs
1) Ministry of Urban Development
XI. Personnel & General Administration, Governance Reform, Regulatory
Systems
1)
Department of Personnel & 2) Department of Administrative Reforms
Training
& Public Grievances
3) Department of Pensions & 4) Department of Legal Affairs
Pensioners Welfare
5) Legislative Department
6) Department of Justice
7) Cabinet Secretariat
8) Ministry of Labour & Employment
9) President’s Secretariat
10) Ministry of Parliamentary Affairs
11)Prime Minister’s Office
12) UPSC
13)Election Commission
XII.
Science & Technology
1)
Department of Science
Technology
3) Department of Bio-Technology

&

609

2)Department of Scientific & Industrial
Research
4) Department of Space

<!-- page 54 -->

Form IIIA
[See rule 4]
The All India Services (Performance Appraisal Report) Rules, 2007
PERFORMANCE REPORT ON STUDY LEAVE/LEAVE FOR STUDY
(Applicable for IAS Officers)
(For the year/period ending_______________________)
A.

PERSONAL DATA
1.
2.
3.
4.
5.

Name of the Officer
Cadre/year of allotment
Date of Birth
Present Grade
Study Leave/ Leave Details
a)
Course
b)
Institution
c)
Duration
6. Period of Sanctioned Leave
7. Details of Degree/Certificate/Diploma
and Evaluation obtained during the
period (copies to be enclosed)
8. Date of Filing Annual Property Returns

B.

Date

SELF ASSESSMENT: -

Officer’s Signature __________________
Date:_________________________
To be filled in duplicate and submitted to Cadre Controlling Authorities in the State and
the Central Government.

610

<!-- page 55 -->

Form III B
[See rule 4]
The All India Services (Performance Appraisal Report) Rules, 2007
PERFORMANCE REPORT ON TRAINING
(Applicable for IAS Officers)
(For the year/period ending_______________________)
A.

PERSONAL DATA

1.
2.
3.
4.
5.

Name of the Officer
Service/Cadre/year of allotment
Date of Birth
Present Grade
Training Details
a) Course
b) Institution
c) Duration
6. Details of Degree/Certificate/Diploma
and Evaluation obtained during the
period (copies to be enclosed)
7. Date of Filing Annual Property Returns

B.

Date

SELF ASSESSMENT: -

Officer’s Signature __________________
Date:_________________________
To be filled in duplicate and submitted to Cadre Controlling Authorities in the State and
the Central Government.

611

<!-- page 56 -->

27

Appendix II
Form I

[See rule 4]
The All India Services (Performance Appraisal Report) Rules, 2007
(Applicable for all Indian Police Service officers up to the level of Inspector
General of Police)
Performance Appraisal Report for the period from _________ to __________
Section I – Basic Information
(To be filled in by the Administration Division/Home Department)
1.Name of the officer reported upon:

2.Service:

3.Cadre:

4.Year of allotment:

6.Present Grade:

5.Date of Birth:

7.Present post:

8.Date of appointment to present post:
9.Reporting, Reviewing and Accepting Authorities
Name & Designation
Reporting Authority
Reviewing Authority
Accepting Authority
10.Period of absence on leave, etc.
Period
On Leave (specify type)
Others (specify)

Period worked

Type

11.Training Programs attended
Date from
Date to
Institute

Remarks

Subject

27

Amended vide notification No.11059/18/2002-AIS-III dated 16.04.2007 vide GSR No.296(E) dated 16.04.2007 and
again modified vide Substituted vide Notification No.11059/09/2006-AIS-III dated 31.03.2008 published in GSR No.256(E)
dt.31.03.2008

612

<!-- page 57 -->

12. Awards/Honours

13. Details of PARs of officers not written by the officer as reporting/reviewing
authority for the previous year

14. Date of filing the property return for the year ending December

15. Date of last prescribed medical examination (Mandatory for all
Indian Police Service officers)Attach summary of the medical report

Date:

Signature on behalf of_________________________
Admn/Home Dept

Section II – Self Appraisal
1.Brief description of duties:
(Objectives of the position you hold and the tasks you are required to perform, in about
100 words)

613

<!-- page 58 -->

2.Annual work plan and achievement:
Tasks to be performed
Deliverables28[1]
Initial30[3]

Actual
Achievement 29[2]

Mid year31[4]

3.During the period under report, do you believe that you have made any
exceptional contribution, e.g. successful completion of an extraordinarily
challenging task or major systemic improvement? If so, please give a verbal
description (within 100 words):

4.What are the factors that hindered your performance?

28[1]

Deliverables refer to quantitative or financial targets or verbal description of expected outputs.
Actual achievement refers to achievement against the specified deliverables in respect of each task (as updated at
mid-year). No explanations for divergences are to be given in this table.
30[3]
Initial listing of deliverables are to be finalized within 1 month of the start of the period under report.
31[4]
Mid year listing of deliverables are to be finalized within 6 months of the start of the period under report.
29[2]

614

<!-- page 59 -->

5. Please indicate specific areas in which you feel the need to upgrade your skills
through training programs:
For the current assignment:

For your future career

Please Note: You should send an updated CV, including additional qualifications
acquired/ training programs attended/ publications/ special assignments
undertaken, in a prescribed proforma, to the cadre controlling authority, once in
5 years, so that the records available with the cadre controlling authority remain
updated.
6. Declaration
Have you filed your immovable property return, as due. If
yes, please mention date.
Have you undergone the prescribed medical check up?
Have you set the annual work plan for all officers for the
current year, in respect of whom you are the reporting
authority?

Yes/No

Date

Yes/No
Yes/No

Signature of officer reported upon ______________
Date:
Section III

Appraisal

1.Please state whether you agree with the responses relating to the
accomplishments of the work plan and unforeseen tasks as filled out in Section II.
If not, please furnish factual details.

615

<!-- page 60 -->

2.Please comment on the claim (if made) of exceptional contribution by the officer
reported upon.

3. Has the officer reported upon met with any significant failures in respect of his
work? If yes, please furnish factual details.

4.Do you agree with the skill up-gradation needs as identified by the officer?

5. Assessment of work output (This assessment should rate the officer vis-à-vis his
peers and not the general population. Grades should be assigned on a scale of 1-10, in
whole numbers, with 1 referring to the lowest grade and 10 to the best grade. Weightage
to this Section will be 40%).
Reporting Reviewing Initial of
Authority Authority
Reviewing
Authority
i. Accomplishment of planned work including
training courses for various ranks
Ii Quality of output and effectiveness in areas like
supervising, investigation
iii. Accomplishment of exceptional work /
unforeseen tasks performed
Overall Grading on ‘Work Output’

616

<!-- page 61 -->

6. Assessment of Personal Attributes (on a scale of 1-10. Weightage to this Section
will be 30%).
Reporting Review
Initials of
Authority Authority Reviewing
Authority
i.
Attitude to work
ii
Sense of responsibility
iii
Overall bearing and personality
Iv
Emotional stability
v
Communication skills
vi
Moral courage and willingness to take a
professional stand
vii.
Leadership qualities
viii.
Capacity to work in time limit
Overall Grading on Personal Attributes
7. Assessment of Functional Competency (on a scale of 1-10. Weightage to this
Section will be 30%).
Reporting Review
Initials of
Authority Authority Reviewing
Authority
i.
Knowledge
of
laws/Police
rules/procedures/Knowledge of area and
terrain/IT skills and awareness of the local
norms in the relevant area
ii.
Strategic planning ability
iii.
Decision making ability
iv.
Initiative
v.
Interest in welfare of Policemen and their
families and appraising ability
vi.
Ability to motivate and develop subordinates /
work in a team.
Overall Grading on ‘Functional competency’
8.Integrity
Please comment on the integrity of the officer:

617

<!-- page 62 -->

9. Pen picture by Reporting Officer. Please comment (in about 100 words) on the
overall qualities of the officer including areas of strengths and lesser strengths
and his attitude towards weaker sections.

10. Recommendation relating to domain assignment (Please tick mark any four)
Anti-corruption & Vigilance
Police Research & Development
Criminal Investigation (CBI, CID)
Security Related Communication
Network/IT
Paramilitary forces
Intelligence
Railways
Counter-insurgency
Economic Offences
Security (VIP & Industrial)
Traffic
Armed Police Bn.
Law & Order
Metropolitan & Urban Policing
Police Training
Anti Terrorism
Personnel Administration
Cyber Crimes
Border Management
Others
Forest & Wild life related crimes
11. Overall grade (on a score of 1-10)

Signature of Reporting Authority ___________
Date:
Section IV

–

Review

1. Do you agree with the assessment made by the reporting officer with respect to the
work output and the various attributes in section III? Do you agree with the assessment
of the reporting officer in respect of extraordinary achievements and/or significant
failures of the moS / officer reported upon?
(In case you do not agree with any of the numerical assessments of attributes please
record your assessment in the column provided for you in that section and initial your
entries).
Yes No

618

<!-- page 63 -->

2. In case of difference of opinion details and reasons for the same may be
given.

3.Comments, if any, on the pen picture written by the Reporting Authority.

4.Recommendation relating to domain assignment (Please tick mark any four)
Anti-corruption & Vigilance
Police Research & Development
Criminal Investigation (CBI, CID)
Security Related Communication
Network/IT
Paramilitary forces
Intelligence
Railways
Counter-insurgency
Economic Offences
Security (VIP & Industrial)
Traffic
Armed Police Bn.
Law & Order
Metropolitan & Urban Policing
Police Training
Anti Terrorism
Personnel Administration
Cyber Crimes
Border Management
Others
Forest & Wild life related crimes
5.Overall grade on a scale of 1-10
Signature of Reviewing Authority ____________________
Date:

619

<!-- page 64 -->

Section V

Acceptance

1. Do you agree with the remarks of the reporting / reviewing authorities?
Yes

No

2. In case of difference of opinion details and reasons for the same may be given.

3. Overall grade (on a score of 1-10)

Date

Signature of Accepting Authority_______________

General guidelines for filling up the PAR form for Indian Police Service up to the
level of Inspector General of Police
1.
Introduction
1.1.
The Performance Appraisal Report is an important document. It provides the
basic and vital inputs for further development of an officer. The officer reported upon, the
Reporting Authority, Reviewing Authority and the Accepting Authority should, therefore,
undertake the duty of filling up the form with a high sense of responsibility.
1.2
Performance appraisal should be used as a tool for career planning and training,
rather than a mere judgmental exercise. Reporting Authorities should realize that the
objective is to develop an officer so that he/she realizes his/her true potential. It is not
meant to be a faultfinding process but a developmental tool. The Reporting Authority,
the Reviewing Authority and the Accepting Authority should not shy away from reporting
shortcomings in performance, attitudes or overall personality of the officer reported
upon.
1.3
The columns should be filled with due care and attention and after devoting
adequate time. Any attempt to fill the report in a casual or superficial manner will be
easily discernible to the higher authorities.
1.4
Although the actual documentation of performance appraisal is a year-end
exercise, in order that it may be a tool for human resource development, career planning
and training, rather than a mere judgmental exercise, the Reporting Authority and the
officer reported upon should meet during the course of the year at regular intervals to
review the performance and to take necessary corrective steps.

620

<!-- page 65 -->

Instructions on filling up the different sections
2.
Section-I
2.1
This Section should be filled up in the Administration Division/Home Deptt.
Period of report could either be the entire reporting year, namely, from 1st of April to 31st
March or a part of the year (exceeding 3 months). In case the period of report is a full
year, it should be indicated accordingly; for example, 2007-2008. In case the period of
report is less than the entire year, specific start and end dates should be indicated, for
example, 10th September 2007 – 31st March 2008.
2.2
Information on the present grade (pay-scale) as well as present post (actual
designation and organization) and the date from which he/she has been on his/her
present post needs to be mentioned.
2.3
In the table relating to reporting, reviewing and accepting authorities the name
and designation of the reporting and reviewing authorities should be mentioned so that
the officer reported upon is clear about whom he/she is required to send the report.
2.4
The period of absence from duty, on leave, training, or for other reasons, should
also be mentioned in this section in the table provided for the purpose. Details of the
training attended, date of filing of property returns and whether the officer reported upon
has reported/reviewed and the annual performance report of all his/her subordinate
officers for the previous year should be mentioned in the table for the purpose.
2.5
This Section provides for regular annual medical examination. The health check
is mandatory for all Indian Police Service officers. A copy of the summary of medical
report is to be attached to the PAR Form by the Admin./Home Department. The format
for health check up and the summary of medical report will be as circulated by the Cadre
Controlling Authority, after consultation with the Ministry of Health and Family Welfare.
3.
Section-II
3.1
The officer reported upon is first required to give brief description of his/her duties
and responsibilities, which would normally not exceed about 100 words. Ideally, this
should be in bullet form.
3.2
All officers are required to develop a work plan for the year and agree upon the
same with the reporting officer. The work plan should incorporate the relative annual
work rhythm and budgetary cycle. This exercise is to be carried out at the beginning of
the year and finalized by 30th April, positively. In case of a change of the reporting officer
during the year, the work plan agreed with the previous reporting officer would continue
to apply. The work plan agreed upon at the beginning of the year has to be reviewed
again during the month of September/October as a mid-year exercise and finalized by
31st October. Based on this review the work plan may undergo some changes from that
originally prepared.
3.3
After the work plan is prepared, it is possible that the officer reported upon is
transferred out. There need not be more than one work plan for one post each year. The
period spent by the officer during the year and his contribution could be considered for
evaluating his performance against the work plan. In the case of mid-term transfers,

621

<!-- page 66 -->

continuity and assessment of work and the lower performance profile in the first quarter
should be taken into consideration.
3.4
The work plans, duly signed by the officer reported upon and the reporting
authority has to be submitted to the reviewing authority for his/her perusal and custody.
The performance appraisal form provides for an assessment of the accomplishments
vis-à-vis the work plan agreed at the commencement of the year and reviewed midyear. The officer reported upon is required to fill up the table provided for the purpose in
Section-II.
3.5
It is not necessary that the work plan should be entirely quantitative in nature.
While for field level posts, the work plan would consist essentially of quantifiable targets,
for secretarial level posts it would consist of policy objectives to be achieved etc.
3.6
Section II also provides an opportunity for the officer to reflect upon his/her
performance during the year and indicate one item which he/she thought was a
significant contributions made by him/her during the year. It is always possible for any
officer to make significant contribution even in activities otherwise regarded as routine in
nature. Examples of such contribution may be the successful organization of a major
event like the Kumbh Mela or successful conclusion of an activity that has been going on
for a long time, or even successful dealing of an emergency (e.g. major earth
quake/flood) would certainly be an exceptional contribution.
3.7
The officer reported upon is required to indicate specific areas in which he/she
feels the need to upgrade skills and attend training programs. He/she should also
mention the specific steps that he/she has taken or proposes to take to upgrade his/her
skills in the identified area.
3.8
There is an increased emphasis on competency building in the new performance
appraisal and career progression system. There would be a premium on competency
and skill upgradation. Hence, all officers are advised, through a note in Section II, to
keep the cadre controlling authority informed, at least once in five years, of all
educational and training programs attended, including the details of marks/grades
secured in such programs, details of professional papers published. These would be
taken into account in the future career progression.
3.9
This Section also requires the officer reported upon to record certain certificates
about submission of property returns, annual medical check up and setting up of annual
work plan for whom he/she would be the reporting authority.
4.
Section-III
4.1
Section III requires the reporting authority to comment on Section II as filled out
by the officer reported upon, and specifically state whether he/she agrees with the
responses relating to the accomplishments. In case of disagreement the reporting
authority should highlight the specific portions with which he/she is unable to agree and
the reasons for such disagreement.
4.2
This Section then requires the reporting authority to comment on the skill
upgradation needs as identified by the officer.

622

<!-- page 67 -->

4.3
Thereafter, this Section requires the reporting authority to record a numerical
grade in respect of the workout put of the officer reported upon both in respect of the
planned work as well as the unforeseen tasks. A numerical grade is also required in
respect of the “quality” of the output. In doing so, the reporting authority should take into
account the costs incurred (whether the officer reported upon has been cost conscious),
the time taken and whether the laid down rules/procedures have been adhered to in
accomplishing the tasks.
4.4
The reporting authority is also required to record a numerical grade in respect of
work output, personal attributes and functional competencies.
4.5
Section III requires the reporting authority to comment on the integrity of the
officer reported upon. In recording remarks with regard to integrity, he/she need not limit
him/herself only to matters relating to financial integrity but could also take into account
the moral and intellectual integrity of the officer reported upon. The following procedure
should be followed in filling up the column relating to integrity:
(i) If the Officer’s integrity is beyond doubt, it may be stated.
(ii) If there is any doubt or suspicion, the column should be left blank and action taken
as under:
(a) A separate secret note should be recorded and followed up. A copy of the
note should also be sent together with the Performance Appraisal Report to the
next superior officer who will ensure that the follow up action is taken
expeditiously. Where it is not possible either to certify the integrity or to record
the secret note, the Reporting Officer should state either that he/she had not
watched the officer’s work for sufficient time to form a definite judgement or that
he/she has heard nothing against the officer, as the case may be.
(b) If, as a result of the follow up action, the doubts or suspicions are cleared, the
officer’s integrity should be certified and an entry made accordingly in the
Performance Appraisal Report.
(c) If the doubts or suspicions are confirmed, this fact should also be recorded
and duly communicated to the officer concerned.
(d) If as a result of the follow up action, the doubts or suspicions are neither
cleared nor confirmed, the officers conduct should be watched for a further period
and thereafter action taken as indicated at (b) and (c) above.
4.6
The reporting authority is also required to record a descriptive pen-picture on the
overall qualities of the officer reported upon and his/her performance including his
attitude towards weaker sections. This need not exceed about 100 words and should try
to cover overall qualities of the officer including areas of strengths and lesser strengths.
The pen-picture is also meant to be a qualitative supplement to the quantitative
assessments made earlier part of this section.
4.7

Reporting authority is then required to make recommendations relating to domain
assignment.

623

<!-- page 68 -->

4.8.
Finally, the reporting authority is required to record an overall grade. This should
also be done on a scale of 1-10, with 1 referring to the lowest grade and 10 to the
highest.
5.
Section-IV
5.1
This Section is to be filled up by the reviewing authority. He/she is required to
indicate if he/she agrees with the assessments made by the reporting officer. In case of
disagreement, he/she may record his/her own assessment against the work output or
any of the attributes in the column specifically provided for the purpose. In case of
agreement, he/she need not fill in the column meant for him/her in the attributes/work
output tables. Finally he/she is required to record an overall grade in the scale of 1-10.
6.
Section-V
6.1
This Section is to be filled by the accepting authority. He/she is required to
indicate if he/she agrees with the assessments made by the reporting
authority/reviewing authorities. In case of difference of opinion, he/she is required to give
details and reasons for the same in the column specifically provided for the purpose in
the table in Section V.
7.
Numerical Grades
7.1
At several places, numerical grades are to be awarded by reporting and review
authorities. These should be on a scale of 1-10, where 1 refers to the lowest grade and
10 to the highest. It is expected that any grading of 1 or 2 (against work output or
attributes or overall grade) would be adequately justified in the pen-picture by way of
specific failures and similarly, any grade of 9 or 10 would be justified with respect to
specific accomplishments. Grades of 1-2 or 9-10 are expected to be rare occurrences
and hence the need to justify them. In awarding a numerical grade the reporting,
reviewing and accepting authorities should rate the officer against a larger population of
his/her peers that may be currently working under them or would have worked under
them in the past.
7.2

Weightage & Mean
Weights have been assigned to work output, personal attributes and functional
competency. The overall grade will be based on the addition of the mean value of each
group of indicators in proportion to weightage assigned.
8.
Disclosure
8.1
There should be more openness in the system of appraisal. The annual PAR,
including the overall grade and integrity, should be communicated to the officer reported
upon after it has been finalized by the accepting authority.
8.2.

Representation
The officer reported upon may have the option to give his comments on the PAR.
Such comments may be restricted to the specific factual observations contained in the
Performance Appraisal Report leading to the assessment of the officer in terms of
attributes,
competency
and
output.
If
comments
are
submitted,
the
Reporting/Reviewing/Accepting Authority would have the option to accept them and
modify the PAR accordingly. If the comments are not accepted, the views of the
Reporting/Reviewing/Accepting Authority would be communicated with reasons to the
officer reported upon. Thereafter, only if the officer reported upon so desires, he may
request for the matter to be forwarded to the Referral Board. The representation shall be

624

<!-- page 69 -->

confined to errors of facts and nothing else. The Referral Board shall give clear findings
on the representation and take a final decision on the assessment, including the overall
grading in regard to the parameters affected thereby. The decision along with details in
case an entry is upgraded or down graded with, reasons for same may be recorded in
the PAR and the same communicated to the officer reported upon. The decision of the
Referral Board shall be final.
9.

Schedule for completion of PARs of Indian Police Service Officers

9.1

The following schedule should be strictly followed: -

Reporting Year – Financial Year
Cut-off dates
Below Super TimeSuper Time
Scale
Scale
Blank PAR form to be given to the officer reported 1st April
1st May
upon
by
the
Administration
Division/Home
Department, specifying the reporting officer and
reviewing authority
Self appraisal for current year
30th April
31st May
Appraisal by reporting authority
31st May
30th June
th
Appraisal by reviewing authority
30 June
31st July
st
Appraisal by accepting authority
31 July
31st August
Disclosure to the officer reported upon
15th August
15th September
st
Comments of the officer reported upon, if any (if none, 31 August
30th September
transmission of the PAR to the MHA)
Forwarding of comments of the officer reported upon 15th September 15th October
to the reviewing and the reporting authority by the
accepting authority, in case the officer reported upon
makes comments
Comments of reporting authority
30th September 31st October
Comments of reviewing authority
15th October
15th November
Comments of accepting authority/PAR to be finalized 31st October
30th November
and disclosed to the officer reported upon.
Representation to the Referral Board by the officer 30th November
31st December
reported upon
Forwarding of representation to the Referral Board 15th December
15th January
along
with
the
comments
of
reporting
authority/reviewing authority and accepting authority
Finalization by Referral Board if the officer reported 15th January
15th February
upon represents against the decision of the Accepting
Authority.
Disclosure to the officer reported upon
31st January
28th February
st
End of entire PAR Process
31 March
31st March
Activity

9.2
The completed PAR should reach the Cadre Controlling Authorities by 31st March
the following year. The Cadre Controlling Authority will prepare a list of PARs not
received and follow up with the Secretaries of the concerned Ministries and Chief
Secretaries of the respective States.

625

<!-- page 70 -->

9.3
Secretary (Home) in the State and the Joint Secretary (Police) in the Centre shall
be the Nodal officers to ensure that the PARs of the members of Service, duly
completed, are sent to the Cadre Controlling Authority by 31st March of the following
year. They shall send a list each of the members of Service whose PARs are to be
written and reviewed to the concerned Reporting/Reviewing/Accepting Authorities by
15th April every year to enable them to ensure completion of PARs within the timeschedule.
9.4.
If a PAR relating to a financial year is not recorded by the 31st of December of the
year in which the financial year ended, no remarks shall be recorded thereafter. The
member of Service will be assessed based on the overall record and self-assessment of
the year concerned, if he had given his self-assessment in time and the Reporting
Authority, Reviewing Authority and the Accepting Authority have not completed the PAR
according to the time schedule given in para 9.1.
9.5.
The member of Service reported upon shall, while forwarding his self-appraisal to
the Reporting Authority, endorse a copy of the self-appraisal, to the nodal officer and
keep a record of the same as evidence that he had submitted the same in time.
9.6.
The Reporting Authority shall record his comments in the PAR of the officer
reported upon within the stipulated time and send it to the Reviewing Authority along
with a copy thereof to the nodal Authority.
9.7.
In case the Reporting Authority fails to submit the PAR to the Reviewing
Authority within the stipulated period under intimation to the nodal officer, the nodal
officer shall send a copy of self-appraisal directly to the Reviewing Authority and
authorize him to initiate the PAR. The nodal officer shall also keep a note of the failure
of the Reporting Authority to submit the PAR of his subordinate in time for an appropriate
entry in the PAR of such Reporting Authorities.
9.8.
The nodal officer shall evolve a suitable mechanism to ensure that the remarks of
the Reporting, the Reviewing and the Accepting Authorities are recorded without fail by
the dates given in the schedule below Para 9.1.

626

<!-- page 71 -->

Form II
[See rule 4]
The All India Services (Performance Appraisal Report) Rules, 2007
[Applicable for Indian Police Service officers of the level of Additional Director
General of Police or Director General of Police or equivalent]
Performance Appraisal Report for the period from _________ to __________
Section I – Basic Information
(To be filled in by the Administration Division/Home Department)
1.Name of the officer reported upon:
2.Service:

3.Cadre:

4.Year of allotment:

5.Date of Birth:
6.Present Grade:
7.Present post:
8.Date of appointment to present post:
9.Reporting, Reviewing and Accepting Authorities
Name & Designation
Reporting Authority
Reviewing Authority
Accepting Authority
10.Period of absence on leave, etc.
Period
On Leave (specify type)
Others (specify)

Period worked

Type

11.Training Programs attended
Date from
Date to Institute

Subject

12. Awards/Honours

627

Remarks

<!-- page 72 -->

13. Details of PARs of officers not written by the officer as reporting/reviewing
authority for the previous year

14. Date of filing the property return for year ending December

15.Date of last prescribed medical examination (Mandatory for all
Indian Police Service officers) Attach summary of the medical report

Signature on behalf of__________________
Admn/Home Dep

Date:
Section II

1. Declaration
Have you filed your immovable property return, as due. If
yes, please mention date
Have you undergone the prescribed medical check up?
Have you set the annual work plan for all officers for the
current year, in respect of whom you are the reporting
authority?
Have you prepared the work plan for yourself?
Have you enclosed a note on important achievements
during the period?

Date:
Section III

Yes/No

Date

Yes/No
Yes/No

Yes/No
Yes/No

Signature of officer reported upon ___________________
Appraisal

1. Assessment of Attributes (This assessment should rate the officer vis-à-vis his peers
and not the general population. Grades should be assigned on a scale of 1-10, in whole
numbers, with 1 referring to the lowest grade and 10 to the best grade. 70% weightage
will be assigned to this item).
Reporting
officer
i) Attitude to work
ii) Decision making ability
iii) Initiative
iv) Ability to inspire and motivate
v) Strategic Planning
ability/innovativeness
vi) Coordination ability
Overall grading on attributes

628

Reviewing officer

Initial of
Reviewing
Officer

<!-- page 73 -->

2. Assessment of work output (This assessment should rate the officer vis-à-vis his
peers and not the general population. Grades should be assigned on a scale of 1-10, in
whole numbers, with 1 referring to the lowest grade and 10 to the best grade. 30%
weightage will be assigned to this item.)
Reporting
Review
Initial of
officer
officer
Reviewing
Officer
i) Accomplishment of Planned Work
ii) Quality of Output
iii) Accomplishment of exceptional work/
unforeseen tasks during the period
Overall Grading on ‘Work Output’
3. Integrity
Please comment on the integrity of the officer, keeping in mind both his financial integrity
and his moral integrity.

4. Pen picture by the Reporting Authority.
Please comment (in about 100 words) on the overall qualities of the officer including
areas of strengths and lesser strengths and his attitude towards weaker sections.

5. Recommendation relating to domain assignment (Please tick mark any four).
Anti-corruption & Vigilance
Police Research & Development
Criminal Investigation (CBI, CID)
Security Related Communication
Network/IT
Paramilitary forces
Intelligence
Railways
Counter-insurgency
Economic Offences
Security (VIP & Industrial)
Traffic
Armed Police Bn.
Law & Order
Metropolitan & Urban Policing
Police Training
Anti Terrorism
Personnel Administration
Cyber Crimes
Border Management
Others
Forest & Wild life related crimes
6. Overall Grade on a scale of 1-10

Signature of Reporting Authority___________
Date:

629

<!-- page 74 -->

Section IV

– Review

1. Do you agree with the assessment made by the reporting officer with respect to the
work output and the various attributes in section III? Do you agree with the assessment
of the reporting officer in respect of extraordinary achievements and/or significant
failures of the moS / officer reported upon?
(In case you do not agree with any of the numerical assessments of attributes
please record your assessment in the column provided for you in that section and
initial your entries)
Yes No
2. In case of difference of opinion details and reasons for the same may be given.

3. Comments, if any, on the pen picture written by the Reporting Authority.

4. Recommendation relating to domain assignment (Please tick mark any four)
Anti-corruption & Vigilance
Criminal Investigation (CBI, CID)
Paramilitary forces
Railways
Economic Offences
Traffic
Law & Order
Police Training
Personnel Administration
Border Management
Forest & Wild life related crimes

Police Research & Development
Security Related Communication
Network/IT
Intelligence
Counter-insurgency
Security (VIP & Industrial)
Armed Police Bn.
Metropolitan & Urban Policing
Anti Terrorism
Cyber Crimes
Others

5. Overall Grade on a scale of 1-10.

Signature of Reviewing Authority___________
Date:

630

<!-- page 75 -->

Section V – Acceptance
1. Do you agree with the remarks of the reporting/reviewing authorities?
Yes

No

2. In case of difference of opinion details and reasons for the same may be given.

3. Overall Grade on a scale of 1-10.

Date

Signature of Accepting Authority________________

General guidelines for filling up the PAR form for Indian Police Service officers of
the level of Additional Director General of Police or Director General of Police or
equivalent.
1.
Introduction
1.1.
The Performance Appraisal Report is an important document. It provides the
basic and vital inputs for further development of an officer. The officer reported upon, the
Reporting Authority, the Reviewing Authority and the Accepting Authority should,
therefore, undertake the duty of filling up the form with a high sense of responsibility.
1.2
Performance appraisal should be used as a tool for career planning and training,
rather than a mere judgmental exercise. Reporting Authorities should realize that the
objective is to develop an officer so that he/she realizes his/her true potential. It is not
meant to be a faultfinding process but a developmental tool. The Reporting Authority,
the Reviewing Authority and the Accepting Authority should not shy away from reporting
shortcomings in performance, attitudes or overall personality of the officer reported
upon.
1.3
The columns should be filled with due care and attention and after devoting
adequate time. Any attempt to fill the report in a casual or superficial manner will be
easily discernible to the higher authorities.
1.4
Although the actual documentation of performance appraisal is a year-end
exercise, in order that it may be a tool for human resource development, career planning
and training, rather than a mere judgmental exercise, the Reporting Authority and the

631

<!-- page 76 -->

officer reported upon should meet during the course of the year at regular intervals to
review the performance and to take necessary corrective steps.
Instructions on filling up the different sections
2.
Section-I
2.1
This Section should be filled up in the Administration Division/Home Deptt.
Period of report could either be the entire reporting year, namely, from 1st of April to 31st
March or a part of the year (exceeding 3 months). In case the period of report is a full
year, it should be indicated accordingly; for example, 2007-2008. In case the period of
report is less than the entire year, specific start and end dates should be indicated, for
example, 10th September 2007 – 31st March 2008.
2.2
Information on the present grade (pay-scale) as well as present post (actual
designation and organization) and the date from which he/she has been on his/her
present post needs to be mentioned.
2.3
In the table relating to reporting, reviewing and accepting authorities the name
and designation of the reporting, reviewing and accepting authorities should be
mentioned so that the officer reported upon is clear about whom he/she is required to
send the report to.
2.4
The period of absence from duty, on leave, training, or for other reasons, should
also be mentioned in this section in the table provided for the purpose. Details of the
training attended date of filing of property returns and whether the officer reported upon
has reported/reviewed should be mentioned in the table for the purpose and annual
performance report of all his/her subordinate officers for the previous year.
2.5
This Section provides for regular annual medical examination. The health check
is mandatory for all Indian Police Service officers. A copy of the summary of medical
report is to be attached to the PAR Form by the Admin./Home Department. The format
for health check up and the summary of medical report will be as circulated by the Cadre
Controlling Authority, after consultation with the Ministry of Health and Family Welfare.
3.
Section-II
3.1
This Section requires the officer reported upon to record certain certificates about
submission of property returns, annual medical check up, setting up of annual work plan
for whom he/she would be the reporting authority as well as for himself. The officer has
to report on the preparation of the work plan for himself and has the option to enclose a
note on the important achievements during the period. No target should be fixed or
considered which may encourage the officer to minimise or avoid registration of crime.
4.
Section-III
4.1
The reporting authority is required to record a numerical grade in respect of
certain attributes and work output.
4.2
This Section requires the reporting authority to record a numerical grade in
respect of the work output of the officer reported upon both in respect of the planned
work as well as the unforeseen tasks. A numerical grade is also required in respect of
the “quality” of the output. In doing so, the reporting authority should take into account
the costs incurred (whether the officer reported upon has been cost conscious), the time

632

<!-- page 77 -->

taken and whether the laid down rules/procedures have been adhered to in
accomplishing the tasks.
4.3
Section III requires the reporting authority to comment on the integrity of the
officer reported upon. In recording remarks with regard to integrity, he/she need not limit
him/herself only to matters relating to financial integrity but could also take into account
the moral and intellectual integrity of the officer reported upon. The following procedure
should be followed in filling up the column relating to integrity:
(i) If the Officer’s integrity is beyond doubt, it may be stated.
(ii) If there is any doubt or suspicion, the column should be left blank and action taken
as under:
(a) A separate secret note should be recorded and followed up. A copy of the
note should also be sent together with the Performance Appraisal Report to the
next superior officer who will ensure that the follow up action is taken
expeditiously. Where it is not possible either to certify the integrity or to record
the secret note, the Reporting Officer should state either that he/she had not
watched the officer’s work for sufficient time to form a definite judgement or that
he/she has heard nothing against the officer, as the case may be.
(b) If, as a result of the follow up action, the doubts or suspicions are cleared, the
officer’s integrity should be certified and an entry made accordingly in the
Performance Appraisal Report.
(c) If the doubts or suspicions are confirmed, this fact should also be recorded
and duly communicated to the officer concerned.
(d) If as a result of the follow up action, the doubts or suspicions are neither
cleared nor confirmed, the officers conduct should be watched for a further period
and thereafter action taken as indicated at (b) and (c) above.
4.4
The reporting authority is also required to record a descriptive pen-picture on the
overall qualities of the officer reported upon and his/her performance including his
attitude towards weaker sections. This need not exceed about 100 words and should try
to cover overall qualities of the officer including areas of strengths and lesser strengths.
The pen-picture is also meant to be a qualitative supplement to the quantitative
assessments made earlier part of this section.
4.5
The reporting authority is then required to make recommendations relating to
domain assignment.
4.6
Finally, the reporting authority is required to record an overall grade. This should
also be done on a scale of 1-10, with 1 referring to the lowest grade and 10 to the
highest.
5.
Section-IV
5.1.
This Section is to be filled up by the reviewing authority. He/she is required to
indicate if he/she agrees with the assessments made by the reporting officer. In case of
disagreement, he/she may record his/her own assessment against the work output or

633

<!-- page 78 -->

any of the attributes in the column specifically provided for the purpose. In case of
agreement, he/she need not fill in the column meant for him/her in the attributes/work
output tables. Finally, the reviewing authority is required to record an overall grade in the
scale of 1-10.
6.
Section-V
6.1
This Section is to be filled by the accepting authority. He/she is required to
indicate if he/she agrees with the assessments made by the reporting
authority/reviewing authorities. In case of difference of opinion, he/she is required to give
details and reasons for the same in the column specifically provided for the purpose in
the table in Section V.
7.
Numerical Grades
7.1
At several places, numerical grades are to be awarded by reporting and review
authorities. These should be on a scale of 1-10, where 1 refers to the lowest grade and
10 to the highest. It is expected that any grading of 1 or 2 (against work output or
attributes or overall grade) would be adequately justified in the pen-picture by way of
specific failures and similarly, any grade of 9 or 10 would be justified with respect to
specific accomplishments. Grades of 1-2 or 9-10 are expected to be rare occurrences
and hence the need to justify them. In awarding a numerical grade the reporting and
reviewing authorities should rate the officer against a larger population of his/her peers
that may be currently working under them or would have worked under them in the past.
7.2

Weightage & Mean
Weights have been assigned to attributes and work output. The overall grade
will be based on the addition of the mean value of each group of indicators/descriptive
picture in proportion to weightage assigned. The overall grade will be the average mean
of all the numerical indicators assigned by the authority.
8.
Disclosure
8.1
There should be more openness in the system of appraisal. The annual PAR,
including the overall grade and integrity, should be communicated to the officer reported
upon after it has been finalized by the accepting authority.
8.2

Representation
The officer reported upon may have the option to give his comments on the PAR.
Such comments may be restricted to the specific factual observations contained in the
Performance Appraisal Report leading to the assessment of the officer in terms of
attributes and output. If comments are submitted, the Reporting/Reviewing/Accepting
Authority would have the option to accept them and modify the PAR accordingly. If the
comments are not accepted, the views of the Reporting/Reviewing/Accepting Authority
would be communicated with reasons to the officer reported upon. Thereafter, only if the
officer reported upon so desires, he may request for the matter to be forwarded to the
Referral Board. The representation shall be confined to errors of facts and nothing else.
The Referral Board shall give clear findings on the representation and take a final
decision on the assessment, including the overall grading in regard to the parameters
affected thereby. In case of an adverse entry, the entry and the overall grading may be
communicated. In case an entry is upgraded or down graded, reasons for the same may
be recorded in the PAR.

634

<!-- page 79 -->

9.

Schedule for completion of PARs of Indian Police Service Officers

9.1

The following schedule should be strictly followed: -

Reporting Year – Financial Year
Activity
Blank PAR form to be given to the officer reported upon by the
Administration Division/Home Department, specifying the reporting
officer and reviewing authority
Filling in Section II by the officer reported upon
Appraisal by reporting authority
Appraisal by reviewing authority
Appraisal by accepting authority
Disclosure to the officer reported upon
Comments of the officer reported upon, if any (if none, transmission
of the PAR to the MHA)
Forwarding of comments of the officer reported upon to the reviewing
and the reporting authority by the accepting authority, in case the
officer reported upon makes comments
Comments of reporting authority
Comments of reviewing authority
Comments of accepting authority/PAR to be finalized and disclosed
to him
Representation to the Referral Board by the officer reported upon
Forwarding of representation to the Referral Board along with the
comments of reporting authority/reviewing authority and accepting
authority
Finalization by Referral Board if the officer reported upon represents
against the decision of the Accepting Authority.
Disclosure to the officer reported upon
End of entire PAR Process
*They are required to fill in only Section II - Declaration

Cut-off dates
1st June
15th June*
15th July
15th August
15th September
30th September
15th October
31st October
15th November
30th November
15th December
31st December
31st January
28th February
15th March
31st March

9.2
The completed PAR should reach the Cadre Controlling Authorities by 31st March
the following year. The Cadre Controlling Authority will prepare a list of PARs not
received and follow up with the Secretaries of the concerned Ministries and Chief
Secretaries of the respective States.
9.3
Secretary (Home) in the State and Joint Secretary (Police) in the Centre shall be
the Nodal officers to ensure that the PARs of the members of Service, duly completed,
are sent to the Cadre Controlling Authority by 31st March of the following year. They shall
send a list each of the members of Service whose PARs are to be written and reviewed
to the concerned Reporting/Reviewing/Accepting Authorities by 15th April every year to
enable them to ensure completion of PARs within the time-schedule.
9.4.
If a PAR relating to a financial year is not recorded by the 31st of December of the
year in which the financial year ended, no remarks shall be recorded thereafter.

635

<!-- page 80 -->

9.5.
The Reporting Authority shall record his comments in the PAR of the officer
reported upon within the stipulated time and send it to the Reviewing Authority along
with a copy thereof to the nodal Authority.
9.6.
The nodal officer shall evolve a suitable mechanism to ensure that the remarks of
the Reporting, the Reviewing and the Accepting Authorities are recorded without fail by
the dates given in the schedule below Para 9.1.

636
