---
doc_id: "2ee0ff877f9fdde1"
source_url: "http://csp.res.in//docs/notices/ten/Tender_ICSP-CVL-2017-18-01.pdf"
ministry: "Indian Centre for Space Physics, Kolkata"
title: "Download/view"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1e549bc9aa280456"
---

<!-- page 1 -->

ICSP/CVL/2017-18/01

Indian Centre for Space Physics
[Autonomous Institute registered under Section 25, The Company Act 1956]
43, Chalantika, Garia Station Road, Kolkata – 700 084, West Bengal
Phone: +91-(0) 33 2462 2153, 2436 6003, Fax: 91 33 2436 6003, Ext. 28

Webpage - http://csp.res.in, Email – root@csp.res.in

NOTICE INVITING TENDER

Tender for Preparation of Building
Architectural Plan, Structural Design and
Arranging Plan Sanction Certificate from
Kolkata Municipal Corporation (KMC).

Tender Reference No.: ICSP/CVL/2017-18/01

Bid Submission Start Date

05/07/2017 from 20:00 Hours

Bid Submission End Date

11/07/2017 up to 18:00 Hours

Bid Opening Date

12/07/2017

Page 1 of 10

<!-- page 2 -->

ICSP/CVL/2017-18/01

1. Introduction
Indian Centre for Space Physics (ICSP) is a non-profit, Govt. Aided Autonomous
Research Institute and a Sister Institute of University of Calcutta. ICSP is setting up a
new Research Facility at Singhabari, Kolkata. The details of the site, scope of works
and terms and conditions are given below. Interested bidders are suggested to
carefully go through the end of the document before submitting their bids.
2. Site Location
The site location of the said project is at Singhabari, Kolkata. The detailed address is
Premises No. 466 Barakhola, J.L. No. 21, P.S. Purba Jadavpur, Dist. South 24
Parganas. The site area is about 17933 Sq Ft. The site is adjacent to Metro Cash and
Carry. Nearest Railway Station is Baghajatin Railway Station (about 2 Km). Nearest
Airport is Kolkata Airport. The Site map is attached in Annexure A below.
3. Scope of Work
(a) The scope of work consists of preparation of the design/ plan of the building,
documents and drawings, structural designs and drawings in accordance with the
stipulations laid down in form of documents/ drawings etc. and additional
stipulations as may be provided by our Engineer during the course of the work.
(b) The work also includes execution of all necessary formalities to obtain the Plan
Sanction Certificate from Kolkata Municipal Corporation (KMC) at his/ her own
cost.
[Documents/ Drawings as stipulated as per our expectation are attached in
Annexure A below.]
4. Time Schedule
(a) The person/ contractor shall start the work immediately after receipt of Letter of
Intent/ Letter of Confirmation.
(b) The time for completion of all works shall be two months from the date of Issue of
Letter of Intent.
5. Prices and Payments
(a) Price quoted should be fixed and must not subject to any escalation whatsoever.
The price should include all the charges/taxes (if any).
(b) The authority would provide Cheque payment only.
6. Penalty
The bidders must realize the gravity of the project. Only capable bidders need to
apply. The authority can impose severe penalty to person/ contractor in case of giving
up the work contract without completing/ delay beyond the Time Schedule as given
under point 4 without enough valid reasons.
Page 2 of 10

<!-- page 3 -->

ICSP/CVL/2017-18/01

7. Important Timings
Bid Submission Start Date

05/07/2017 from 20:00 Hours

Bid Submission End Date

11/07/2017 up to 18:00 Hours

Bid Opening Date

12/07/2017



Any further notifications and dates will be published on the website
(http://csp.res.in/).



The bidders with lowest quoted price (i.e. L1 Bidder), with good track records
will be judged by a committee of our Institution and will be given the contract
and the result of the tender will be published on the Institute’s website
(http://csp.res.in/).
 The bidders are requested to send their quotation along with price
accompanied by their credentials and supporting documents (showing
their eligibility for the project) in a SEALED ENVELOP addressing “The
Secretary, Indian Centre for Space Physics, 43 Chalantika, Garia Station
Road, Kolkata 700 084” on or before 11/07/2017 18:00 Hours. Bids
reaching the above address beyond that time will not be considered.
 No other modes of bidding will be entertained.

[To Be Contd....]

Page 3 of 10

<!-- page 4 -->

ICSP/CVL/2017-18/01

ANNEXURE – A

List of Drawings in serial order:
(i)

Location Map

(ii)

Expected Ground Coverage Plan of the Office/Hostel Building

(iii)

Expected Ground Floor Plan of the Office/Hostel Building

(iv)

Expected First Floor Plan of the Office/Hostel Building

(v)

Expected Second Floor Plan of the Office/Hostel Building

(vi)

Expected Third & Fourth Floor Plan (Hostel Building only)

Page 4 of 10

<!-- page 5 -->

ICSP/CVL/2017-18/01

Page 5 of 10

<!-- page 6 -->

ICSP/CVL/2017-18/01

Page 6 of 10

<!-- page 7 -->

ICSP/CVL/2017-18/01

Page 7 of 10

<!-- page 8 -->

ICSP/CVL/2017-18/01

Page 8 of 10

<!-- page 9 -->

ICSP/CVL/2017-18/01

Page 9 of 10

<!-- page 10 -->

ICSP/CVL/2017-18/01

Page 10 of 10
