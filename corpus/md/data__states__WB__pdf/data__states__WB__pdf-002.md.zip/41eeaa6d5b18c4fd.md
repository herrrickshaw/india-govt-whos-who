---
doc_id: "41eeaa6d5b18c4fd"
source_url: "https://home.wb.gov.in/public/assets/frontend/pdf/common_cadre_rules.pdf"
ministry: "Home and Hill Affairs Department, West Bengal"
title: "0 9  COMMON CADRE RULES"
date: ""
pages: 9
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "4a50d079bb2c861b"
---

<!-- page 1 -->

‘yy
৪ 5 , : Me. 22711
“ Registered No. WB/SC-132 ৬. )
| Live
! ae
১715
৪7515 &
Calrutta i Gazette
৯৫) |
| { Extraordinary
{ ৬ ৩
i - Published by Authority
. CAITBA 12 ] SUNDAY, APRIL 1, 1984 [SAKA 1906
) --লল্ল্র্্লুুিুুর্টচু_ ২২২২২ +---৯লললল্্
PART ৮0:৩5 and notifications by the Governor of West Bengal, the High Court, Government
| . Treasury, etc.
| GOVERNMENT OF WEST BENGAL
. FINANCE DEPARTMENT
Audit :
¢ NOTIFICATION
, No, 3855-F.—31st March 1984.—In exercise of the Power conferred by
| the proviso to article 309 of the Constitution of India, the Governor is pleased
hereby to make the following rules :—
- ; Rules
1. Short title and commencement.—(1) These rules may be called the West
Bengal Services (Secretariat Common Cadres) Rules, 1984,
১৫) They shall come into force on the date of their Publication in the
Official Gazette.
2. Application—These rules shall apply to all Government employees
holding, in the Secretariat Departments and Offices mentioned in the Schedule
to these Rules, the Posts borne in the Secretariat Common Cadres, as formed
under rule 4.
3. Definitions.—(i) “Appointing Authority” : (a) in relation to cadres, 7
Posts or grades of Registrars, Officers on Special Duty and Special Officers
(borne in the revised scale of pay of Rs, 660—1,600) shalt be the Governor;
and (6) in relation to cadres, posts or grades of Section Officers, Head
Assistants, Upper Division Assistants, Lower Division Assistants, Typists
(Grade I) and Typists shall be the Deputy Secretary to the Government ‘in the
Home (P. & A. R.) Department which will be in charge of management and
control of the Common Cadres constituted under rule 4.
@@ “Commission” means the Public Service Commission, West Bengal.

<!-- page 2 -->

vf 904. THE CALCUTTA GAZETTE, EXTRAORDINARY , 4472811515108845 25 ‘EPage
| (ii) “Common Cadres” means a cadre of same category of posts in the
| Secretariat Department and Offices formed into a cadre under these rules.
: . (iv) “Department” and “Offices” mean a Secretariat Department and other
Offices under this Government as mentioned in the Schedule,
(v) “Government” means the Government. of West Bengal. .
. (vi) “Revised Scale” means revised scale of pay as promulgated with the
. West Bengal. Services (Revision of Pay and Allowances) Rules, 1981.
. (vii) “Schedule” means the Schedule to these rules.
. 4. Common Cadres.—(1) There shall: be constituted separate cadres for
each of the following categories of posts :—
: (i) Lower Division Assistants,
Gi) Typists, 7. |
. (ii) Upper Division Assistants, - , .
(iv) Typists Grade I, . moog
: (v) Head Assistants, 1
(vi) Section Officers, : :
7. (vii) Registrars, Officers on Special Duty and Special Officers in the 9
revised scale of pay of Rs. 660—1,600, . .
Note.—Government in the Finance Department may decide, if any other
Post|posts in the Sccretariat Departments and Offices mentioned in the Schedule, . :
will be equivalent to any of the above categories of posts for the Purpose of
inclusion in any of the common cadres herein constituted, .
- (2) Each of the Common Cadres mentioned above will be formed with all
Posts in the respective category in the Secretariat Departments and Offices
mentioned in the Schedule. a
, (3) Any one holding on the date of commencement of these tules, a post
in any of the categories as are being constituted into Common Cadres under
. this rule shall belong to the Tespective Common Cadre with éffect from the
said date and shall come under the management and control of the Home
~ (P&A.R.) Department of this Government. .
5. Management and Control of Cadres.—(1) Notwithstanding anything
contained in any other rules, the Home (P.&A.R.) Department will manage and
: control the Common Cadres constituted under rule 4,
(2) 0) All the Departments and Offices Mentioned in the Schedule shall
report vacancies in the posts borne on the respective Common Cadres arising
in such Departments and Offices to the Home (P.&A.R.) Department.

‘ ৫) The Home (P.&A.R.) Department will fill up such vacancies by making
appointments through direct Tecruitment, by promotion or otherwise in .
accordance with the rules regulating ‘such recruitments and in consultation with
the Public Service, Commission, where necessary.

(3) The services of the incumbents So appointed in respective cadres shall
then be placed at the disposal of the Tespective Departments and Offices, which .
will issue. orders Posting the concerned incumbents against the respective
vacancies under them. .

<!-- page 3 -->

Part I} THE CALCUTTA GAZETTE, EXTRAORDINARY, APRIL 1, 1984 905
(4) Notwithstanding the provisions of the West Bengal Services (Classifica-
tion, Control and Appeal) Rules, 1971,—

- (i) the competent authority of the department to which the incumbent is
posted shall have the power of the appointing authority for the
purpose of placing him under suspension and of the disciplinary
authority for the purpose of taking disciplinary proceedings against
him subject to subsequent intimation to the appointing authority
of the circumstances leading to the order of suspension or the
commencement of the disciplinary proceedings, as the case may be ;

i) the competent authority of the Department to which the incumbent is

posted may, in the light of the findings in the said disciplinary
proceedings, impose any of the penalties specified in the clauses
৫), Gi) and (ii) of rule 8 of the West Bengal Services (Classification,
Control and Appeals) Rules, 1971 on the incumbent. in consulta-
tion with the appointing authority but in the event of difference in
opinion between the departmental authority and the appointing
authority\the services of the incumbent shall be replaced at the
: disposal of\the appointing authority and the departmental authority
shall transmit to it the proceedings of inquiry and thereupon
the appointing authority may pass such orders thereon: including
an order to commence the proceeding de novo, as it deems
necessary, after complying with the provisions of rule 10 of the
West Bengal Services (Classification, Control and Appeals) Rules,
1971.
(iii) If the competent authority. of the department to which the incumbent
. is posted is of opinion that any of the penalties specified in the
clauses (iv) to (viii) of rule 8 of the West Bengal Services
(Classification, .Control and Appeals) Rules, 1971 should be
imposed on the incumbent it shall replace his services at the disposal
of the appointing authority and transmit to it the proceedings of
inquiry and thereupon the appointing authority may pass such orders
: thereon including an order to commence the proceedings de novo,
as it deems necessary, after complying with the provisions of rule 10
of the West Bengal Services (Classification, Control and Appeals)
Rules, 1971.

Explanation—The disciplinary authority may make an order under this 7
clause on the record of inquiry transmitted by the competent
authority of the department to which the incumbent is posted or after
holding such inquiry as it may deem necessary. The disciplinary
proceedings commenced~by the competent authority of the depart-
ment to which the incumbent is posted shall be taken in consultation
with the Public Service Commission, where such consultation is
necessary. .

\
6. Seniority—{i) For each of the Common Cadres constituted under rule 4
there shall be a common gradation list. :
(ii) In the common gradation list referred to in sub-rule (i), the seniority
of a person shall be determined by the provisions of the West Bengal Services ,
(Determination of Seniority) Rules, 1981.

<!-- page 4 -->

906 THE CALCUTTA GAZETTE, EXTRAORDINARY, APRIL-1, 1984 AB

7, . Recraitment.—Notwithstanding anything contained in any other rules for
the time being in force, the recruitment to posts in the Common Cadre
constituted under rule 4 shall be regulated in the following manner :—

Posts . 7 Method of Recruitment
(i) Registrars, Officers on Special By promotion from the combined panel :
Duty and Special Officers-in - of Section Officers, Head Assistants and
. the revised scale of pay of Upper Division Assistants borne in
Ra. 660—1,600. common Cudres prepared by the
Commission. Only for the purpose of
, - promotion to the posts of Registrars,
Officers on Special Duty and . Special
Officers in the scale of Ra. 660-1,600 the
Section Cfficers, Head Assistants and
Upper Division Assistants shall be
. treated as belonging to Upper Division
Assistant cadre.

(ii) Section Officers... -. By promotion of Head Assistants borne in
common cadre,

(iii) Head Assistants ৮, .. By promotion of Upper Division Assistants -
borne in common cadre.

(iv) Upper Division Assistants .. By promotion of Lower Division Assistants
borne in common cadre.

{v) Lower Division Assistants .. In_the manner laid down in Finance
Department notification No. 2083-F, dated
the 2lst July 1954, as amended from
time to time.

4vi) Typists (Grade I) .. .. By _Bromotion of Typists borne in common

: cadre, .

(vii) Typists .. তত .. Inthe manner laid down in Notification No.

645-Mis., dated the 216 May 1941, as

৯ amended, and Finance Department Noti-
fication No. 907-F, dated the 6th April
1957, as amended.

8. Interpretation.—If any question arises relating to the interpretation of
‘these rules, it shall be referred to the Government in the Finance Department, whose
-devision thereon shall be final. :

9. Repeal and savings.—Tho provisions of any other rules, notifications and
orders, in ৪০ far as they are repugnant to matters covered by these rules shall be
‘deemed to have been repealed :

Provided that— .

~ (i) such repeal shall not affect the previous operation of the said rules, notifica-
tions and orders or anything done or any action taken thereunder ;
(ii) promotion /confirmation or appointment to higher cadres, posts or grades
and any other service benefits already granted on the basis of the rules
and orders in force prior to coming into effect of these rules shall not in
any way be adversely affected.
| SCHEDULE
List of Departments and Offices
. (See Bule 4.)
DEPARTMENTS .

I. Home Department.

II. Finance Department including Accounts Branch and Financial Advisers
- offizes of R.R. und R., Food and Supplies and Development and Planning Depart-
ments.

ILIA. Legislative Department. .

IIIB. Judicial Department. "

IV. Department of Land and Land Reforma,

<!-- page 5 -->

an Past Ij THE CALOUTTA GAZETTE, EXTRAORDINARY, APRIL 1; 1984 907
— V. ‘Department of Agriculture including Juputs Branch.
. VI. Department of Anima) Husbandry and Veterinary Services.
VII. Department of Forests. to
VIII. Department of Commerce and Industries.
IX. Department of Labour.
.X. Department of Education including office of State Archives.
XI. Department of Health and Family Welfare. . .
XII. Department of Local Government and. Urban Development.
XIII. Department of Refugee Relief and Rehabilitation, Relief and Welfare, —
: Scheduled Castes and Tribes Welfare Department.
. XIV. Public Works Department including P.W. (Roads) Department and
্‌ Construction Board. .
| XV. Department of Irrigation and Waterways.
| XVI. Department of Food and ‘Supplies. '
XVII. Department of Development and Planning including State Pianning
Boad and Town and Country Planning Branch.
XVIII. Department of Fisheries. .
" Xx. Departmen! of Cottage and Small Scale Industries. .
XX. Department of Excise.
XXI. Department rf Co-operation.
: XXII. - Department of Housing.
XXHI. ment of Panchayats and Community Development including
| Panchayats মু Branches. top
XXIV. Department of Information and Cultural Affairs. .
XXV. Department of Public Undertakings. :
XXVI. Department of Power. , .
XXVII. Department of Industrial Reconstruction.
XXVIN. Department of Youth Services. . ,
-XXIX. Department of Tourism. .
‘XXX. Metropoliton Development Department.
XXXI. Department of Environment.
OFFICES
1. Board of Revenue, West Bengal.
এ. Governor’s Secretariat. :
3. Office of the Military Secretary to the Governor, West Bengal.
: By order of the Governor,
. P. K. SARKAR,
. Seoy. to the Govt. of West Bengal.
: NOTIFICATION :
No, 3856-F.—Slst March, 1984.—In exercise of the power conferred by
: the proviso to article 309 of the Constitution of India, the Governor is pleased
thereby to make the following rules:— . 7
Rules ৬
1. Short title and commencement.—(i) These rules may be called’ the
West Bengal Services (Secretariat Common Cadres of Deputy Secretaries
and Assistant Secretaries) Rules, 1984. .
" (ii) They shall come into force on the date of their publication in. the .

<!-- page 6 -->

: ১
908 THE CALCUTTA GAZETTE, EX TRAORDINARY, APRIL 1, 1984 - {Pa,
৬
2. Application—These rules shall apply to all Government employees
. holding in the Secretariat Departments and Offices mentioned in the Schedule
the posts borne in the Secretariat Common Cadres formed under rule 4.
"3. Definitions. —(i) “Appointing Authority” in relation to cadres, posts
or grades of Deputy Secretaries. and Assistant Secretaries, shall be the
Governor. . .
(ii) “Commission’’ means the Public Service Commission, West Bengal.
(ili) ‘Common Cadre” means a cadre of same category of posts in. the
Secretariat Departments. and Offices formed into a Common Cadre under
these rules. coe
(iv) 40090870087) and ‘‘Offices’’ mean a Secretariat Department and
other Offices under the Government as mentioned in the Schedule,
. (v) ‘Government’? means the Government of West Bengal.
(vi) ‘Revised Scale’? means the revised scale of pay as promulgated with.
the West Bengal Services (Revision of Pay and Allowances) Rules, 1981. |
(vii) “Schedule” means the Schedule to these rules.
4. Gommon Cadres.—(1) There shall be constituted separate cadres for.
each of the following categories of posts :— .
(i) Assistant Secretaries [other than, such posts of Assistant Secretaries
as are filled up by transfer of officers belonging to W.B.C.S. (Ex.), Bo
W.B.C.S. (Sudicial), West Bengal Health Service and West:
Bengal Engineering Services].
(ii) Deputy Secretaries [other than such posts of Deputy Secretaries.
as are filled up by transfer of officers belonging to LA.S., -
W.B.C.S. (Ex.), W.B.C.S (Judicial), West Bengal Health.
Service and West Bengal Senior Service of Engineers].
Note.—Government in the Finance. Department may decide if any other
post/posts. in the Secretariat Departments and Offices mentioned in the-
Schedule will be equivalent to any of the above categories of posts for the- .
purpose of inclusion in Common Cadres herein constituted:
(2) Each of the Common Cadres mentioned in sub-rule (1) will be formed
with all posts in the respective category in the Secretariat Departments and:
Offices mentioned in the Schedule.
~
70), Anyone holding on the date of commencement of these rules, a post
of Assistant Secretary or Deputy Secretary as are now being constituted into
Common Cadres under this rule, shall belong to the respective Common Cadre-
with effect from the said date and shal] conie: within the management and
control of the Home (৮, & A.R) Department of this Government.
: 5. Management and Control of Common Gadres—(1) Notwithstanding: '
anything contained in any other rules, the Home (P. & A.R.) Department of
: the Government will manage and control the Common Cadres constituted
under rule 4,
(2) (i) All Departments and Offices mentioned in the Schedule, shall.
report vacancies in the, pusts of Assistant Secretaries and Deputy Secretaries.
borne on respective Common Cadres, arising in such Departments and offices.
to the Home (P. & A. R.) Department. . .

<!-- page 7 -->

+ Part I] THE CALCUTTA GAZETTE, EXTRAORDINARY, APRIL 1, 1984 909
(ii) The Home (P. & A.R.) Department will fill up such vacancies by making a
appointments by promotion in accordance with the rules regulating such recruit-
ments and in consultation with the Commission, where necessary.
(3) The services of the incumbents so appointed in respective Cadres shall then:
be placed at the disposal of the respective Departments and Offices which will
issue orders ‘posting the concerned incumbents against the respective vacancies. .
under them.
6. Senlority—(i) For each of the two Common, Cadres constituted under rule .
. 4 there shall be a Common Gradation List.
{ii) In the Common Gradation List referred to in sub-rule (i), the seniority of
_ @ person shall be determined by the provisions of the West Bengal Services (Deter-
mination of Seniority) Rules, 1981. .
7. Recruitment—(1) Notwithstanding anything contained in any other rules,
of the time being in force, the recruitment to posts in the Common Cadres constituted.
under rule 4 shall be regulated in the following manner :— .
Posts Method of Recruitment
(i) Deputy Secretaries (only such By promotion of Assistant  Scoretaries
. ts as are included in the borne in the Common Cadro for Assistant
bommon Cadre herein consti- Secretaries. -
tuted).
(ii) Assistant Socrotarigs (only such By promotion from the combined panel of :
6৪ as are inclu in the (i) Registrar, 0.8.D., Spocial Officer
Sommon Cadre herein constitu- {in the Revised Scale of Rs. 660—1,600,
ted). (ii) Section Officer, (iii) Head Assistant
and (iv) U. D. Assistant—borne in the
respective Common Cadres, prepared by
the Commission, .
Only for the purpose of promotion to the
post of Assistant Secretaries, the Regis-
trars, O.8.D., Special Officer, Section
Officer, Head ‘Assistan t+ and U.D.
: Assistant shall be treated as belonging ৮০.
U. D. Assistant Cadre.
: (2) (i) 40% of the total number of posts of Deputy Secretary excluding
such posts of Deputy Secretary as are filled up by transfer of officers belonging
to LA.S., W.B.C.S. (Judicial), West Bengal Health Service, West Bengal Senior
J Services of Engineers and other Services in the Secretariat Departments and ,
offices mentioned in the Schedule shall be filled up by promotion in the manner:
laid down in sub-rule (1) above, .
২৫) 66 213% of the total number of posts of. Assistant Secretary excluding
i such posts of Assistant Secretary as are filled up by transfer of officers belonging
to.W.B.C.S.. (Judicial), West Bengal Health Service and West Bengal: Engineering.
Services and other Services in the Secretariat Departments and offices mentioned.
, in the Schedule shall be filled up by promotion in the manner laid down in:
. sub-rule (1) above. :
8. Interpretation.—If any question arises relating to the interpretation of
these rules, it shall be referred to the Government in the Finance Department;
, whose decision thereon shall be final. .
9. Repeal and savings.—The provisions of any other rules, notifications - 7
and orders, in so far as they are repugnant to matters covered by these rules,
shall be deemed to have been repealed: Provided that—
7 (i) such repeal shall not affect the previous operation of the said rules,
: notifications and orders or anything done or any action taken
te thereunder. এ) . Joe

<!-- page 8 -->

wor রে
~ 910 THE CALOUTTA GAZETTE, EXTRAORDINARY, APRIT J, 1984 - [Py .
——SS poate . এলাহি) ৫
Gi) promotion|confirmation ‘or appointment to higher cadres, posts or
grades and any other service benefits already granted on the basis
of the rules and orders in force prior to coming into effect of these
. tules, shall not in any way be adversely affected.
SCHEDULE
List of Departments’ and Offices’
(See Rule 4) .
_ DEPARTMENTS -
I. Home Department.
IL. Finance Department including Accounts Branch and Financial Advisers .
. Offices or R.R. and R., Food and Supplies and Development and Planning
Departments. : ‘
: INA. Legislative: Department. co . .
| IB, Judicial Department. ,
\ 1V. Departments of Land and Land Reforms.
i : V. Department of Agriculture including inputs Branch. :
VI. Department of Animal Husbandry and Veterinary Services.
: VIL. Department of Forests. . .
VILL. Department of Commerce and Industries.
; 1X. Department of Labour.
৪. _ X. Department of Education including office of State Archives.
4 XI. ‘Department of Health and Family Welfare.
pe XII. Department of Local Government and Urban Development.
: XII]. Department of Refugee Relief and Rehabilitation, Relief and Welfare,
: Scheduled Castes and Tribes Welfare Department. .
i XIV. Public Works Department including P.W. (Roads) Department and
XV. Department of Irrigation and Waterways.
A : ~ XVI. Department of Food and Supplies. .
k : XVII. Department of Development and Planning including State, Planning
1 Board and Town and Country Planning Branch. . :
. | XVIII. Department of Fisheries. :
i XIX.’ Department of Cottage and Small Scale Industries.
| | i , XX. Department of Excise. .
॥ XXL. Department of Co-operation. :
| 5 XXIL Department of Housing. .
i XXII. Department of Panchayats and Community Development. including
: Panchayats and C.D, Branches. |
XXIV. Department of Information and Cultural Affairs.
| _XXV. Department of Public Undertakings. .

<!-- page 9 -->

Part I] THE CALCUTTA GAZETTE, EXTRAORDINARY, APRIL 1, 1984 910(a)
XXVL., Department of Power. ‘
XXVII. Department of Industrial Reconstruction. 4
XXVIII. Department of Youth Services. -
XXIX. Department of Tourism. ,
XXX. Metropolitan Development Department. : :
XXXI. Department of Environment, . i
OFFICES ' .
1. Board of Revenue, West Bengal. \
2, Governor's Secretariat.
3. Office of the Military Secretary to the Governor, West Bengal. :
.
\ . By order of the Governor,
x, ; P. K. SARKAR,
a : - 56০0. to the Govt. of West Bengal.
___.____.___ ৫৫১6১ লা ী্টা্টাারীটাটটী
Printed and published by the Superintendent, Government Printing, West Bengal, at the West Bengal Govt. Press,
রা jepore.
