---
doc_id: "dcfae0ae97580acb"
source_url: "https://kmda.wb.gov.in/upload_file/tender/10_SE(Cons)_EAM_KMDA1.pdf"
ministry: "Kolkata Metropolitan Development Authority, West Bengal"
title: "Deployment of Private Security Personnel of 70 nos. and 06 nos. Security Supervisor at Rabindra Sarobar under KMDAfor the period of 36 months i.e. upto 31.12.2029. (715)"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8fadcf1cdb874f5b"
---

<!-- page 1 -->

OFFICE OF THE SUPERINTENDING ENGINEER
CONSTRUCTION CIRCLE, E & AM SECTOR, KMDA
UNNAYAN BHAVAN 8TH FLOOR, BLOCK-A
KOLKATA-700 091

Kolkata
Metropolitan
Development
Authority

e -QUOTATION NOTICE
TENDE ID: 2026_KMDA_1047578_1
Notice Inviting e-Quotation No: 10/SE(Cons)/E&AM/KMDA of 2026-27 Dated: 29/10/2026
Quotation Reference No.: 10/SE(Cons)/E&AM/KMDA of 2026-27
SUPERINTENDING ENGINEER, CONSTRUCTION CIRCLE, E&AM SECTOR, KMDA for and on
behalf of Kolkata Metropolitan Development Authority (KMDA) invites ON LINE e-QUOTATION in KMDA
Form No. 1 from bonafied, reliable and resourceful agency having experience of similar nature of work in any
Government/Semi Government /Undertaking/ Autonomous bodies/Local bodies.
Sl.
no.
(1)

Description of work
(2)

Unit
(3)

1

Deployment
of
Private
Security
Personnel of 70 nos. and 06 nos. Security
Supervisor at Rabindra Sarobar under
KMDA for the period of 36 months i.e.
upto 31.12.2029.

Per head
Per DAY

Rate to be quoted
(in Rs.) upto two
decimal
(4)
To be quoted in INR
(Per head Per DAY)

Earnest Money
Deposit (EMD)
(5)
Rs. 10, 00, 000/amount to be paid
Online (Net Banking
/NEFT/RTGS)

NB: Service Charge quoted by the agency (in Rs. only) shall be excluding of all statutory taxes (Taxes will
be paid as per applicable Govt. rate from time to time). Service charge should not be negative or zero. If
found negative or zero, the bid will be rejected.
SCOPE OF WORK:
The Security and Other Manpower Agencies will be required to provide trained and experienced security
guards and security supervisors in such manner as required by the KMDA from time to time for the under
mentioned activities :
i. Protection of Land, buildings, fittings and fixtures therein, plants and machineries, etc.
ii. Safety of trees and safety of the morning walkers in the parks and squares.
iii. Protection of drainage pumping stations, water treatment plants, etc.
iv. Restriction of entry of unknown persons into the Head Office and such other KMDA Offices.
v. Protection of KMDA Garages.
vi. All other work as may be assigned by concerned officers.
vii. Services at any other offices, installations, and the like, as also at Stalls, Pandals, Tents, Streets, Water
Bodies, Unauthorized Buildings, etc for the KMDA.
1. Intending bidder may download the tender documents from the website https://wbtenders.gov.in directly with
the help of Digital Signature Certificate.
2. Earnest Money deposit (EMD) is to be remitted by the Tenderer through e-filling as mentioned in the column
5 above through Net- Banking/ RTGS/NEFT in respect of the Tender ID in favour of KMDA.

<!-- page 2 -->

3. Submission of Quotation :- a) Technical Bid and Financial Bid both will have to be submitted online
concurrently duly digitally signed in the website https://wbtenders.gov.in as per time schedule stated herein
under. Time will be reckoned as per Server Clock. b) The Financial Bid of the Participant tenderers will be
opened only if the tenderer qualifies in the Technical Bid evaluation.

4. Time Schedule for Downloading, Uploading and Opening of Quotation Documents:a)

Date of uploading of Documents (online)

b)
c)

Documents download start date (Online)
Documents download end date (Online)
Last date of submission of Pre-bid queries (can be raised
through e-mail)
(e-mail ID: dilipkmda2008@gmail.com)

d)
e)

Pre-bid meeting Date & Time & Venue

f)
g)

Replies to queries of pre bid meeting to be uploaded
Online Bid Submission Start Date & Time

h)

Online Bid Submission End Date & Time

i)
j)

Date: 04.11.2026 Time: 12.00 hrs.
Date: 04.11.2026 Time: 12.30 hrs.
Date: 30.11.2026 Time: 12.00 hrs.
Date: 13.11.2026 Time: 12.30 hrs.
Date: 13.11.2026 Time: 13.30 hrs.
Chamber of the CE, E&AM Sector, 8th
Floor, Unnayan Bhawan, KMDA
Date: 13.11.2026, Time: 16.30 hrs.
Date: 04.11.2026 Time: 12.30 hrs.
Date: 30.11.2026 Time: 12.00 hrs.

Time and Date of Opening of Technical Bid ( Bid will be
Date: 03.12.2026 Time: 16.30 hrs.
opened by the Authorized Officers)
Date for opening of Financial Proposal (Online)
To be notified later on

Tenders will be opened by the Superintending Engineer, Construction Circle, E&AM SECTOR, KMDA and
authorized personnel in presence of tenderer or their authorized representatives who may like to be present.
5.

BID EVALUATION PROCESS:

Technical Proposal:
5.1 The tenderer must have at least a minimum of (a) 31 (thirty one) Security Manpower as applicable in a
singular contract deployed in a Government / Statutory organization, during the last 5 (five) years, prior to the
date of issue of tender notice OR (b) 23 (twenty three) Security Manpower as applicable of two contracts during
last five years prior to date of this tender notice in a Government / Statutory organizations in a single contact in
each organization,
5.2 List of common documents shall have to be uploaded by each tenderer at the time of submission of
Tender through online:i.

Private Security Agencies Regulation Act(PASARA), Govt. of W.B

ii. Last 3yrs Income Tax e-Return
iii. Last 3yrs. audited P/L, balance sheet as per 6(e)
iv. Pan Card.
v.

Professional Tax Enrolment certificate.

vi. Valid 15 digit Goods and Services Taxpayer Identification Number (GSTIN) under GST Act. 2017.
vii. Latest renewal Trade License.
viii. Valid Labour License.
ix. Technical Credential certificate of the work.
x.

Affidavit before Notary mentioning the (a) correctness of the documents and a declaration of penalty
debarment etc. as per prescribed format.

<!-- page 3 -->

xi. E. P.F. and ESI registration Certificate along with employer latest monthly contribution receipt.
xii. Registered deed of partnership firm/ Article of Association & Memorandum.
xiii. Power of Attorney (for Partnership Firm/ Private Limited Company) , If any

Financial Proposal:
a.

The prospective tenderer is only to quote the agency service charge (in Rs.) per individual employee
per day in the BOQ (Bill of Quantities). Service Charge quoted by the agency (in Rs. only) shall be
excluding of all statutory taxes (Taxes will be paid as per applicable rate from time to time). The
service charge should not be negative or zero. If found negative or zero, the bid will be rejected.

b.

The KMDA will select the agency/agencies with the lowest quoted rate (in Rs.) upto two decimal.

c.

In case of tie bid TIA will follow the Finance Department’s Memorandum No. 2320- F(Y) dated, 7th
June, 2022 of Principal Secretary to the Government of West Bengal.
The following procedure should be adopted when there is a tie among the Ll Bidders: Keeping the
discovered L1 rate as ceiling, sealed bids may be invited from all the L1 bidders and out of those the
lowest one may be selected.

If none of the LI bidders is ready to offer further reduced rates:
A. For items divisible in nature –
i. The work may be distributed equally among the consenting Ll bidders.
ii. If none of the L1 bidders is ready to accept reduced quantity, the bidder with higher credential based
on the following parameters, may be selected among L1 bidders in the following manner:
a. In case of supply of goods, last three years average turnover of the bidder shall be considered.
b. In case of execution of work / supply of service, value of single work/ service of similar nature
completed during last 3 years shall be considered.
c. In case of supply of man power, number of personnel supplied in a single contract during the last
3 years shall be considered.
6.

That the security personnel and supervisors will be in proper prescribed uniform (i.e. full shirt, full pant, cap
and shoe, rain coat, umbrella, torch and other accessories) & Identity card and no extra charges / payment
will be made in this account. Agency should considering all these expenses while quoting their service
charges.

7.

Earnest Money:-The tenderers shall have to mention the reference detail in support of remitted
RTGS/NEFT of requisite EMD against the tender in prescribed location failing which the tender shall be
rejected.

8.

Language of Quotation:- The tender shall be submitted in the prescribed form in English. All literatures
and correspondence in connection with the tenders shall be in English.

9.

The Quotation Notice along with other documents like Tender Form No. -1 KMDA, Technical Specification,
Special Terms and Conditions , BOQ, Addendum and corrigendum etc. whatever documents uploaded by the
department concerned thereto shall be part and parcel of the tender.

10. Influence:- Any attempt to exercise undue influence in the matter of acceptance of quotation is strictly

prohibited and any Quotationer who resorts to this will render his quotation liable to rejection. There shall be
no provision of arbitration.
11. Declaration:- Tenderer must upload and submit duly digitally signed a declaration as per prescribed format

for confirmation of his awareness of the contract.

<!-- page 4 -->

12. Payment of Wages to the personnel shall be made through Bank A/C ECS transfer only. The

respective A/c statement shall have to be produced to the authorized official of KMDA as and when
necessary.
13. Contract period upto 31/12/2029.
14. Submission of bill towards payment:

a) Agency will pay minimum wages as applicable time to time as per govt. order, along with ESI, EPF &
Bonus to the engaged security personal for 8(eight) hours shift.
b) Supporting documents in respect of sl.(a) above including service charge & GST (as applicable) and
attendance sheet is to be submitted to KMDA for payment. While raising monthly bills, the agency has to
enclose previous months ESI and EPF contribution to the workers deployed by it.
15. The Selected Security Agency(s) will have to issue monthly Salary Slip duly signed with stamp to their

respective Security employees every month positively.
16. The Selected Agency(s) will have to disburse monthly wages to the Security Personnel within 10th day of

every calendar month. In the event of failure of timely disbursement of salary maximum 3 times in every
year from contract, the agency will be debarred from participating in the next Security Tender under KMDA.
17. The TIA reserve the right to modify any terms and conditions if necessary in the interest of the Government

which must be accepted by the Agency otherwise the work order will be cancelled forthwith without
showing any reasons. The TIA also reserves the right to cancel the agreement by giving a notice of 1 (one)
month before cancellation to the agency without assigning any reason.
18. Payment from KMDA will depend on availability of fund and no claim whatsoever will be entertained for
such delay payment. Intending bidders may consider this criterion while quoting their rates.
19. To calculate the daily wages, the monthly wages (means Monthly minimum wages+EPF+ESI+Bonus) is to

be divided by 26.
20. The Quotationer own responsibility to obtain all information that may be necessary for quoting the amount.
21. Before issuance of the work order, the quotation inviting authority may verify the credential & other

documents with the original of the lowest Quotationer, if necessary. After verification, if it is found that such
documents submitted by the lowest Quotationer is either manufacture or false, in that case, L.O.A. / work
order will not be issued and Black listing/ penal action will be taken against him as decided by KMDA.
22. If any discrepancy arises between two similar clauses on different notifications, the clause as stated in later

notification will supersede former one.
23. The KMDA does not have any liability to make compensation and/or financial assistance to the agency

concerned for injury/death whatsoever of any personnel under their control.
24. The agency/agencies selected shall provide standard photo identity cards in at their own cost to the

employee. The details of the employee/s with photograph and contact details are to be provided to the
concerned EE.
25. No worker below the age of 18 (Eighteen) years and above the age of 60(Sixty) years shall be engaged in

any above mentioned job.
26. There shall be no claim of any worker at any stage for engagement through agency in KMDA in regular

manner or against a regular pay scale. An undertaking shall be obtained from each personnel by the agency
in this regard before such engagement and a duly attested and rubber stamped photocopy is to be forwarded
to the concerned EE before each such engagement.
27. There shall be no provision of arbitration.
28. KMDA has every right to deploy the security personnel anywhere under KMDA if desire.

<!-- page 5 -->

29. Medical/Physical fitness for work of a security is to be ensured by the agency on a regular basis.
30. Quotationer should comply with minimum wages as enforced time to time during tenure of contract by the

Labour Department Govt. of WB.
31. Deduction of Tax shall be made as per provision of latest Govt. order with up to date amendments.
32. Security money shall be released after successful completion of the contract.
33. The agency should submit the copy of Govt. issued photo identity cards (PAN and Aadhar) of each security

guard to the concerned EE before engagement.
34. The security guards will have to abide by the discipline, rules and regulations as laid by KMDA.
35. Suspension & debarment: Will be applied as per clause no. 547-W(C)/1M-387/15 dated 16/11/2015 and

no. 724/W(C)/1M-953/19 dated 19/12/2019.
36. Addenda / Corrigendum: If published. Contractors are to keep track of all the Addendum / Corrigendum

issued with a particular tender and upload the same digitally signed along with the NIT. Tenders submitted
without the Addendum / Corrigendum will be informal and liable to be rejected.
The tender inviting authority reserves the right to accept or reject any or all the tenders without assigning any
reason what so ever.
For detail information please visits https://wbtenders.gov.in & www. kmda.wb.gov.in.
Superintending Engineer
Construction Circle, E&AM
Sector,
KMDA.

No. 34 /1(25)/ SE(Cons)/E&AM/KMDA/NIQ/RS
Copy forwarded for information & necessary action to:

Dated: 29/10 /2026

1.
2.
3-9
10.
11.

The CEO, KMDA
The Secretary, KMDA.
The Chief Engineer, E&AM, R&B, W&S, Housing, E-M, PM&C Sector, KMDA.
The Director of Finance, KMDA.
The Sr. Dy. Secretary, P.R.O, KMDA- publication as per KMDA rule and for display this NIQ in KMDA
& Govt. of West Bengal Web site.
12.
The Deputy Secretary, HIT Wing
12-13. The Superintending Engineer, CRS Circle/Panning Circle, E&AM Sector, KMDA
14-22. The Executive Engineer-BPPD-I,II/CRS/ECPD.-I,II / CD-II/CSD/SFD/Div.-V, E&AM Sector, KMDA.
23.
The A.C.F.A, E&AM.Sector, KMDA.
24.
The Head Estimator, Construction Circle, E&AM Sector, KMDA
25.
N O T I C E B O A R D.
Superintending Engineer,
Construction Circle, E&AM Sector,
KMDA.
