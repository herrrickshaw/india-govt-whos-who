---
doc_id: "4884d4ec4ebcc8df"
source_url: "https://www.wbcsconline.in/UploadDocument/Notice/344/Notification%20ASST%20PROF.pdf"
ministry: "West Bengal College Service Commission, West Bengal"
title: "Download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "af92c2e5a009996f"
---

<!-- page 1 -->

Notification: Extension of submission of online application
(Advt. No. 1/2020)
The last date for submission of online application for the post of Assistant Professor
(Advt. No. 1/2020) has been extended upto 22nd February, 2021.

Date: 12/02/2021

By order
Controller of Examinations
