---
doc_id: "be6eaf74ac54aae4"
source_url: "https://mdmlakshadweep.utl.gov.in/Guidelines/5.DFS_MDM.pdf"
ministry: "Mid Day Meal Scheme, Lakshadweep"
title: "DFS MDM"
date: ""
pages: 1
method: "tesseract:mal+eng"
script: "LATIN"
needs_ocr: false
sha1: "5affa8ff655015ee"
---

<!-- page 1 -->

Amarjit Singh മ Pcl ക്ട
Ph No, 011-23381096 Ayn eae fora site Grater Fase
Fax: 011-28831302 pan Eh
aaah ag facet - 110115
GOVERNMENT OF INDIA
MINISTRY OF HUMAN RESOURCE DEVELOPMENT
DEPARTMENT OF SCHOOL EDUCATION & LITERACY
SHASTRI BHAVAN
NEW DELHI-110 115
D.O. No.5-5/2011-MDM-1-1 (EE.5) New Delhi, 1st July2011
Dear Colleague
As you may be aware almost 50 % of males and 70% of the females in our country suffer from
anaemia. While anaemia is responsible for 50% of all maternal deaths; malnutrition of all kinds
accounts for 54% of all deaths of children. Apart from high mortality, a child suffering from
malnutrition suffers from low level of energy; finds it difficult to concentrate and s/he is
incapable of work on a sustained basis. Such children are also prone to infections, which again
increase the overall level of malnutrition
Anaemia can be prevented and addressed by promoting consumption of iron rich foods and
iron supplements. One cost effective way of increasing the intake of iron is fortification of salt
with iron in addition to iodine. Government of India, Ministry of Health and Family Welfare has
prescribed the legal standards for double fortified salt (DFS).

2. In arecent meeting chaired by the Principal Secretary to Prime Minister to discuss promotion of
consumption of iron fortified iodised salt, it was suggested that Government should actively
promote the consumption and production of DFS through an effective communication
campaign, as well as mandating its use in Government sponsored food and nutrition
programmes like ICDS, Mid-day-Meals.

3. In this connection it is reiterated that para 4.5 of the Mid-Day-Meal Guidelines issued by this
Department stipulates that only iodised/double fortified salt should be used for cooking. The
State Government/UT Administrations are also expected to issue detailed guidelines in this
regard. During the visits made by officers Government of India to see the implementation of
Mid-Day-Meals Scheme in the States and UTs, the use of double fortified salt is also
emphasized so that the children are benefited from consumption of iodine and iron as both are
required for proper physical and mental growth.

4. We do hope that in view of the dire need as brought out in para 1 and the guidelines in this
regard only double fortified salt (DFS) is used in the MDMS. We shall appreciate if you could
confirm use of DFS in MDMS in your state/UT. All necessary action may also be taken for its
Sustained use. In addition we should use green leafy vegetables like drumsticks, radish and
cabbage leaves for MDMS.

The current position as well the action taken to promote use of DFS and green leafy vegetables
may please be intimated to us.
With regards,
[ഇ sincerely,
രേ oD» (Amarjit Singh)
1൫
Secretaries of State Governments/ പ
(As per list attached) Mid Day Meat Scheme
