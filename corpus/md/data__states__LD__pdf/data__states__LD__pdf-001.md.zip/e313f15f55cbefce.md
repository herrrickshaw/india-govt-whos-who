---
doc_id: "e313f15f55cbefce"
source_url: "https://cdn.s3waas.gov.in/s358238e9ae2dd305d79c2ebc8c1883422/uploads/2024/04/2024040139.pdf"
ministry: "Lakshadweep District"
title: "UTL- Estt- Instructions for starting all public function/ Official meeting with Panch Prans Pledge"
date: ""
pages: 2
method: "tesseract:mal+eng"
script: "LATIN"
needs_ocr: false
sha1: "bcdead0ac39aa875"
---

<!-- page 1 -->

pre
പും ae
പി . re : . 7
| “SagtOnN-PERRITORY OF LAKSHADWEEP ADMINISTRATION
\ (DEPARTMENT OF GENERAL ADMINISTRATION AND PROTOCOL)
KAVARATTI ISLAND -682 555
CIRCULAR
Sub: - UTL-Estt-Instructions for starting all public function/Official
meeting with Panch Prans Pledge-Regarding.
Ref: - F.No,LD-02001(01)/1/2024-PST-UT-LKS/143 dated
13.02.2024 ,

In order to imbibe the spirit of Panch Prans in the functioning of UT
Administration, it has been decided to start all public functions/ Official
meetings of UTL Administration with Panch Pran Pledge. 1൨ this regard all: -
the Departmental Heads, DCs, -ഠട, Administrative Officer Kochi, Head
of Office/Institutions under UTL Administration is hereby directed to start
all public functions / official meetings with Panch Pran pledge henceforth.

Copy of Panch Pran pledge is enclosed herewith.

a
പ്ര
യ്യ
ട്‌ Director
General Administration & Protocol
To
1. All Departmental Heads,
2, DC/BDOs in all Island. They are also requested to share the circular
with all Head of Offices/Institutions in'théir respective island
3. Administrative Officer, Kochi.
Copy to PA to Advisor to the Hon'ble Administrator/All
P Secretaries/Special Secretaries for information.

<!-- page 2 -->

> ച്‌
ടം f
ഗ്‌ Amrit Mahotsav
( PANCH PRAN PLEDGE
പട...
൦ നതി 2047 de arearak otk Rete Ue TAM & ATA HI VOR |
o Ted തി aad ol ആ B Sure a
o ae ware fered od Gia]
ം UR Gl Ue hl Ges HAA she Sar HI Vel HLA are ST VHA HU
[പിപി
We Pledge to:
e Make India developed and self-reliant by 2047.
൭ Remove any trace of colonial mindset.
e Celebrate our heritage.
e Strengthen unity and respect those who protect the country.
e Perform the duties of a citizen.
- Scanned with CamScanner
