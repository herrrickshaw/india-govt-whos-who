---
doc_id: "423c2edceca31de2"
source_url: "https://mdmlakshadweep.utl.gov.in/Notifications/Enhancement_order_of_MDM_State_Share_dt_4.5.2012.pdf"
ministry: "Mid Day Meal Scheme, Lakshadweep"
title: "Enhancement order of MDM State Share dt 4.5.2012"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1f2d9fb7110e44ed"
---

<!-- page 1 -->

t.-4"

X tff

aru

Union Territory of Lakshadweep
Directorate of Education
Kavaratti -682 555

F"No.65/2012001-Edn(AW)

Dated 4.5.2012

oRDEE f
Sub:- Directorate of Education - Enhancement of Mid Day Meal State
Share -regarding

The Adrninistrator, Union Territory of Lakshadweep is pleased to
enhance the existing rates of Mid Day Meal State Share per day per child as
detailed below.
Stage
l. Pre-Prim ary

Enhanced Rate
Rs.6/- (Rice 50 gm)

Existing rate

Rs.4,l- (Ric€,
Probisk
1

each/ground

nut (fried and

(2
Rs.13l- eachll Sgm
Rs .7

l-

biscuit
ground

nut(fried and husked)

husked) per

with 100m1 milkljuice

in the morning and

child per day

evening)
Rs.4lll. Primary(l-V)
lll. Upper Primary(Vl - Rs.4l-

Rs.8/Rs.9/-

lV. Upper Primary rylll
V. Secondary (!X-X)
Vl. Sr.Secon dary(fl -)clt )

Rs.11lRs.12l'-

vil)

Rs,6/Rs.6lRs.8l-

The District Panchayat will intimate the enhanced rate to the

Principals/Headmasters in al! islands and ensure the utilization of enhanced
rate from the academic year 2012-13. The enhanced rate will come to effect
trom 21.05.2012 o43ryards on school reopening.
The Chief Executive Officer, District Panchayat will ensure the following

1. 1OO% implementation of MDM in alt schoots in allworking days.

2. Supply of quality and nutritious food
3. Students attending schools are fed in allworking days.
4. Conduct of School Health Programme (SHP)
5. Monitoring mechanism of scherne in school level to be strengthened
6. MDM fund not be diverted to other purpose/programme
7. Supply chain of the items cooking quality and serving need special
attention.

8. Any chance of pilferage or diversion of items should totally be
curbed.

9. Holding of UT/DistricUlgtand level Steering cum Monitoring
Committee meeting on MDtlil.
10. Furnishing of Quarterly Progress Report on MDM

PTO

<!-- page 2 -->

'2'

A

This issue with the approval of the Administrator vides diary n{IASZ
dated 26.04.2012.

(AHam
ot Director of E

cation

To

1. The Chief Executive Officer, District Panchayat, Kavaratti
2. The Joined Director (Administration), District Panchayat, Kavaratti
copy to : 1. PA to the Administrator/Secretary (Education)/ Secretary
(Panchayat) for i nformation.
2. The Principals/HMs of Seiior Secondary/Secondary/SB/JB
schools in all islands.
3. The Editor Lakshadweep Times for publication.
