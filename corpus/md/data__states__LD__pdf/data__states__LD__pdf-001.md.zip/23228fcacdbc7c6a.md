---
doc_id: "23228fcacdbc7c6a"
source_url: "https://mdmlakshadweep.utl.gov.in/Guidelines/10.School_Health_Programme.pdf"
ministry: "Mid Day Meal Scheme, Lakshadweep"
title: "School Health Programme"
date: ""
pages: 82
method: "tesseract:mal+eng"
script: "LATIN"
needs_ocr: false
sha1: "0288cb402f4772cc"
---

<!-- page 1 -->

SCHOOL HEALTH
PROGRAMME
a ws റ 4
. Soo.
am > ®
MINISTRY OF HEALTH AND FAMILY WELFARE

<!-- page 2 -->

‘ [॥ \ Bs i
ന ട്‌
ചം റി റ്_ 4

<!-- page 3 -->

ജു School
Health
| Programme

<!-- page 4 -->

ore
zaRea va GRax wean At Ministry for Health & Family Welfare
WRa UHR Government of India
Prater aaa, ag feee-110108 Nirman Bhavan, New Dethi-110108
wert oad
St agen ഞ്ഞ
Dr. ANBUMANI RAMADOSS
MESSAGE
ന്നതു 1 Health seeking behaviour has to initiated in childhood itself, The best
Opportunity for facilitating this is found in school settings. With more and more
school enrolments taking place, schools have become the convergence centre
. for health and education programmes. The introduction of school health
services in India dates back to 1909, when school children in the city of Baroda

vd were given the first medical examination. We have come a long way since then.,

1] Keeping in view the vision of NRHM, we have taken up the challenge of
mainstreaming the school health programme at the same time as retaining the
diversities of State initiatives.

The document captures our vision of decentralizing the school health initiative through the
programme management process of different States. It brings out the spirit of innovative thinking in
the implementation of the school health programme. It is heartening to note that the
implementation experience at the state level reflects the commitment of the States in reaching outto
the young loved ones of this country. At the national level, our mandate is to provide the overall
framework for State initiatives.

!am confident that this publication will enable the State, policy managers, civil society stake
holders under NRHM toassess the initiatives so far and build on them for the future.| would alsoliketo
compliment the team involved in bringing out this publication in the shortest possible time.

(Dr. Anbumani Ramadoss)
—eSSSSSSSSSSSSSSSSSSSSSSSSSSSSssSSsSSe
National Rural Health Mission
zl Healthy Family, Healthy Village, Healthy Nation
ae wee am Set

<!-- page 5 -->

ന: എ
———————————
= wer Fat
[1 ണ്ട്‌ യ്ന്‌ യി
കു 1! FART AH
4g. Re Frater saa, ag feefl-110108
NF ne
ച MINISTER OF STATE
- FOR HEALTH AND FAMILY WELFARE
afta ബണ്ട്‌ west GOVERNMENT OF INDIA
Smt. PANABAAKA LAKSHMI NIRMAN BHAVAN, NEW DELHI-110108
MESSAGE
One of the major landmarks of National Rural Health Mission has been to
bring about convergence of related sectors like Education, Drinking
Water, Sanitation and Nutrition-linking it with health.

റ The constitution of Village Health and Sanitation Committees in every
village is a very bold and purposeful step in this direction. In this context
of convergence, the school health programme, promoting basic check
up of school children for a variety of health related problems, is a

systematic effort in raising awareness about health issues among school children and their
families but also create an enabling environment for the society to focus on health steadily and
continuously.

It has been noted that education increases children’s opportunity to keep healthy.
Acquisition of health related knowledge, attitudes, skills and practices empower children to
pursue a healthy life not only in the present but also in the future. The balance between health
and education through the school stream enables a child to develop self esteem and self reliance.
In a diverse country such as ours, a child brings a vast pool of information and skills to the family
andcommunity, ifthe school provides a healthy enabling environment.

The compilation on School Health Programme is a documentation of the good
performance by the States. | am sure, the journey of NRHM will only be strengthened by such
documentation of innovations by the states.| am of the view that this document shall enable all
the stake holders under NRHM to assess the initiatives so far under the programme.
My appreciations to the officers of the Ministry for the excellent work done in bringing out this
publication.

(Panabaka Lakshmi)
Healthy Village, Healthy Nation
AM aces BOS ee Cane ue)
use - ണ്ടി ഭി ണ്ട
Talking about AIDS is taking care of each other

<!-- page 6 -->

യാം പ്‌
ലി a, aRa aa
ie warez vd uftar seam ജ്ഞ
J t ച്ചി Is Frater waa, ag fteeht - 110011
ത്തിയ Government of india
Ministry of Health & Family Welfare
Naresh Dayal Nirman Bhavan, New Dethi-110011
Health & FW Secretary
Tel.: 23061863 Fax : 23061252
e-mail : ndayal@nic.in
FOREWORD
| Our experience has shown that schools are the hub for integrating the
value of health with the educational system. Some of the critical
opportunities for influencing the behaviour of young children and
preventing their initiation into health risks are found in school settings.
In a diverse country such as ours, the school environment provides an
extra ordinary setting to improve the health of the students and enhance
their health seeking attitudes. Schoo! Health Programme enables the
students to learn the qualities of caring for themselves and others.
The document integrates skill based health education with life skills taking into account the
experiences of States that has been marked by innovations, public private partnerships and
success stories. The State Programme Implementation Plans provide us with wealth of
experience in implementing the subject. It has been our endeavour not to endorse a
prescriptive policy for the School Health Programme. It is expected that all 26 States who
have taken up the challenge of implementing School Health would continue to do so in the
future so that we attain universal coverage through time tested innovations. This documentis
an attempt to bring about cross cultural learning between States and critical stake holders.!
am confident that this publication would enthuse all States to mainstream this programmeas
a critical outcome indicator in their Programme Implementation Plans.
| would like to compliment the team led by Shri G.C.Chaturvedi, Mission Director, NRHMand
Ms, Aradhana Johri, Joint Secretary, who were ably assisted by Ms. Sangeeta Saxena, AC (CH)
and Shri Chaitanya Prasad, Director (IEC) along with Dr.Rajesh Mehta, NPO-FCH, WHO and Dr.
Sunder Raman of NHSRC for their efforts in bringing out this excellent publication,
New Wo
(Naresh Dayal)
K wae രു vei del, vasngdt/ yea രു ഞി HIV/AIDS : Prevention is better than cure

<!-- page 7 -->

Table of Contents
അറി... ടി
ZO Polley: FraMOWOKk savvissvesicseessuie ccdarsunay senor ഘി:
ദ്വി
4.0: ന്ന:
5;0 Operational 77ഭനഡോന ........-::--: ടി
6.0... ടാ
7.0 State Programme Implementation 0905...
8.0 Components of the School Health Programme ......-:.-ccccscssssssecessceeseceeseeseeeessseessseeees 4B
8.1 Health Screening and Remedial Measures .....-....cccccccsseceseeeessecerseeesesenseeeensenseee AD
8.2 Health and Nutrition EdUCAtION ...........-cseccereccssecerreccersecenscesrsecssseeeareeeceseaecereess OD
SiS) Nite ftaconiaal ites വാര്‍
8.4 Safe and Supportive Environment in 50്ോ.......................:: OD
8.5 Capacity Building for Health 95൦8ല്‍... OF
8.6 Monitoring and Evaluation ......0ccccccsscciccccsssesccccsctsaseasssscesbecrsnssenrecesssenstsesseens OD
8.7 Implementation of School Health നെദനനട.................... 8
8,8 Inter-Sectoral Coordination...........sorrerrerrreorerccrrssonrsssencsannssgnaceseccessresenagesneysss OP
9.0 Successful State and NGO 56000006...
Annexure 1 - Rapid Assessment and Action Planning Process (RAAPP) ............... 7
Annexure 2 - Evaluations of Previous Health and Nutrition Programmes for Children..........72
Annexure 3 - Looking Ahead: Designating Child Friendly Schools .............. 7D

<!-- page 8 -->

ന
af a
g ie
യയാ Oe
the context of the Reproductive and Child
A Health (RCH) Programme.

1 .O Introduction Providing easy access to health, nutrition and
hygiene education and services to children
in schools is a simple and a cost effective

Schools lay a country’s foundation for tool which can go a long way in the
the future and have a major effect on a prevention and control of communicable
host of issues, including health. What and non communicable diseases. It also
is learnt at this impressionable stage of enables revitalization of local health
life in terms of knowledge, attitudes and traditions and the mainstreaming of
behaviours has a lasting impact on the AYUSH and promotion of healthy life
entire lifespan of the individual. Health is styles in the health curriculum programme
maintained and diseases most effectively in schools.
Sop Molle” by ന ടി Implementing a cohesive School Health
of prevention of disease and early ക
recognition of signs of sickness. Ensuring നം കി ടി neal
concerns with determinants of health,
that children have access to knowledge
ensures that they are able to use it to
mould not only their own attitude and
behaviour, but that of their families and @ National Rural Health
communities as well. This is the primary Mission (NRHM), has taken
reason for health issues occupying the cognizance of the potential
centre stage in the school curriculum. impact of the School Health
National Rural Health Mission (NRHM), Programme on the health of
has taken cognizance of the potential the students, their families
impact of the School Health Programme and the generations to come
on the health of the students, their
families and the generations to come and 8 Population stabilization,
brought this initiative to forefront within gender and demographic
balance are some of the
issues that can also be
addressed in school settings
അ The Government aims to
universalise immunisation,
management of common
childhood ailments, nutrition
t ~ é services as well as improve
. health awareness and health
sts seeking behavior through
School Health Programme
8 In keeping with the policy of
chy NRHM, flexibility is available
& 4 under the School Heath
J Programme for states to
take care of the health of its
ക ശം school going children
i
LOOKING TO THE FUTURE
Scuoor Heavru Pxooxauae SM

<!-- page 9 -->

——————————————— eee
ey (
[|
, ]
rs : ര) nn
തം. , : ‘ ആ
ന്‌ > t ല്‌ ലം
141110 : D
EDUCATION IS A TOOL TO EMPOWERMENT
such as sanitation and hygiene, nutrition Keeping this background in mind
and safe drinking water, through a Schoo! an operational framework has been
Plan for Health, Population stabilization, formulated an circulated to the States, based
gender and demographic balance are ഒറ successful models being implemented in
other issues that the country has been other States such as Tamil Nadu and Gujarat
grappling with since independence, and This operational framework is meant to serve
the tender formative years at schoo! could 85 a foundation for the States to think & plan
well be the launching pad for addressing innovatively about the needs of the children in
these concerns in the years to. come. the context of their ground situation.As NRHM
promotes flexibility in the States, under the
Under the ambit of the National Rura' School Health Programme, the States have
Health Mission and the Reproductive and been given an option to implement the
Child Heaith programme, the Government Programme comprehensively. According to
aims to universalize, immunization the needs of the children, institutional
management of common childhood ailments Capacity and available service delivery options
micronutrient supplementation and 26 States have provisioned for the Schoo’
improved health awareness and health Health programme in their programme
seeking behaviour. A variety of delivery Implementation Plans. It is expected that al
Strategies and channels are being the States that have taken up this challenge
implemented. Social mobilisation and and introduced a School Health Programme
demand generation is being ensured through from the year 2008 will continue with this
Information Education and Communication initiative, expanding it as per the need so that
(IEC), Non Government Organisations (NGOs ultimately it has a universal coverage. It is also
have been involved in facilitating counselling expected that the other States will start
services, At the same time Panchayati Raj providing school health services in the near
Institutions (PRI) have been involved for future.
mplementation at the grass roots. Schools are
an excellent catchment area forimpiementing It is envisaged that all schools, both rural and
these priorities. They are an effective channel urban, will be covered under various aspects of
for decentralised implementation and the School Health programme in all parts of
provision of quality, need based and client the country.
centered services.

<!-- page 10 -->

Rights of the Child
; ക
a ‘ 7
8.
മി ഴി
: a 4
ഴ്‌:
ts ‘|
\ -
- yy 5 [൦
‘
: \ Be
»
A\\ 5 |
8]
EVERY CHILD IS SPECIAL
—— പ പ നി ന —— Fj
In 1992, the world-wide Convention of the The right to protection |
Rights of the Child was signed by most of the It includes freedom from all forms of
countries. A commitment was given that every exploitation, abuse, inhuman or degrading
effort would he made for first resources to treatment, and neglect including the right to
be given to the development of children. special protection 1൩ situations of emergency
of prime importance: is the commitment of all and armed conficts.
efforts to the empowerment of every child s
regarding its health. The right for development
The Rights of the Child: “First calf It ae the et to see support ies
റ ” early childhood development and care, social
for children security, right to leisure, recreation and cultural
The right to survival activities.
It includes the right to life, the highest The right to participation
|
attainable standard of health, nutrition and it includes respect for the views of the child,
adequate standards of living. It also includes the freedom of expression, access. to appropriate
Fight to a name and a nationality. information, freedom of thought, conscience
and religion.
