---
doc_id: "bab756b1dcd74fdc"
source_url: "https://mdmlakshadweep.utl.gov.in/Guidelines/SNG_Guidelines.pdf"
ministry: "Mid Day Meal Scheme, Lakshadweep"
title: "School Nutrition Gardens - Guidelines"
date: ""
pages: 37
method: "tesseract:mal+eng"
script: "LATIN"
needs_ocr: false
sha1: "82534584f43e253c"
---

<!-- page 1 -->

11 [പി a a
ee areal qa
woke ord
ag യീ — 110115
R.C. MEENA GOVERNMENT OF INDIA
Joint Secretary (MDM) MINISTRY OF HUMAN RESOURCE DEVELOPMENT
Tel:- 011-23389247 DEPARTMENT OF SCHOOL EDUCATION & LITERACY
Email: r.cmeena@gov.in SHASTRA BHAVAN
NEW DELHI-110 115
D.O. No. 1-8/2019-Desk (MDM)
Dated 156 October, 2019
Dear Sir/Madam
As you are aware that setting up of School Nutrition (Kitchen) Gardens may
achieve the goal of learning a lifelong skill which is of critical importance in the arena of
rapid urbanization and environmental issues which shapes the behavioural pattern of the
students. It is just one step in right direction for school students to engage and participate
meaningfully in the activities so as to inculcate the habit of growing own vegetables and
fruits in the schools and in their homes.
2. We have already issued guidelines related to School Nutrition (Kitchen) Gardens
in month of May-June, 2019 when PAB-MDM meetings were held and copies were
distributed to all Secretaries during PAB-MDM meetings for further circulation in their
respective States/UTs.
3. These guidelines are further elaborated to aid and guide the States/UTs and the
same are being issued now (copy enclosed).
4, It is therefore, requested to kindly issue necessary instructions as per the
Guidelines on School Nutrition (Kitchen) Gardens to your State/UT for setting up of
Kitchen Gardens in all schools.
With regards,
Yours sincerely,
(R.C. MEENA)
The Special Chief Secretaries/Addl. Chief Secretaries/Principal Secretaries/ Secretaries
(Education) of all States/UTs.
<r ര
GEN i
| Male a 8 a afte mK
ടെ ര്‌
സം അയല്‍

<!-- page 2 -->

wenia oat
Government of India
Ministry of Human Resource Development omen,
Department of School Education & Literacy oe ee,
School Nutrition (Kitcher)
GUIDELINES
e e 4 !
“A ല്‍ 7 Si
fic)
J /
A
ളി a” h
‘s 4

<!-- page 3 -->

<!-- page 4 -->

അ School Nutrition (Kitchen) Garden y
S.No. Chapters Page No.
Executive Summary 2-4
1 Objectives of School Nutrition (Kitchen) Garden 5-8
2 Setting up of School Nutrition (Kitchen) Garden 9-17
and Planning and Monitoring
3 Setting up of School Nutrition (Kitchen) Garden in 18-21
the Schools which don’t have land
4 What shall we grow in the School Nutrition 22-25
(Kitchen) Garden?
5 What parts of the plant can we eat? 26-27
Newspaper Clippings 28-32
=
Vv J
mn q » ae
101]

<!-- page 5 -->

Executive Summary
ച്ച °
School Nutrition (Kitchen) Garden
“Il saw a hungry man...”
| taught him how to fish”

Most people will be familiar with these lines which highlight the critical importance of learning a

lifelong skill. Setting up a School Nutrition Garden (also called Kitchen Garden) seeks to achieve a

similar goal as itis both a place and an activity where children learn the skill of growing their own food.

The concept of a School Nutrition (Kitchen) Garden is not new, however, the unique features of the

current initiative being promoted by the MHRD are refreshingly novel, namely.

1. Teaching students that a Nutrition (Kitchen) Garden can actually be set up anywhere, even in
a School in a crowded urban area. This learning is critical because most people feel that a
Nutrition Garden requires a large plot of vacant land. However, the fact is that healthy vegetables,
fruits etc. can be grown in pots and containers on terraces, roofs or even in the entrance area of the
School. Climbing varieties such as the snake gourd can be cultivated as they will creep up the walls
and need nolandatall.

: f< ay tos Ae കം SF CEN gies
b = a. 8 rf ന we, x
eee Few pe uf
ഴി ടി റ 1 ae Sees ഴ്‌ | a ee റായ്‌
യി പ്പി i 7 h\ ക, നി Ce Re
or ടു റില്ല 1] ~ "
NG > + >
ജൂ

<!-- page 6 -->

2. Teaching students that, with a few exceptions, every part of the vegetable or fruit can be
eaten.
In many parts of the country, different parts of vegetables such as the flowers, the leaves, and the
stems, are all eaten. For example while banana flowers are considered a delicacy in some cuisines,
papaya leaves are in the limelight for their medicinal properties. Thus, instead of throwing all leaves
and stems away children should be encouraged that most parts of the vegetable and fruit can be
eaten, and to include these in their diets.
Cooking competitions should accordingly be organized to support cooks in the Mid Day Meal
programme to come up with innovative recipes using all parts of vegetables.
3. Teaching students to think out of the box and find a way. No land available in the school? Not
enough rainfall? Let these not be reasons not to start Nutrition Gardens.
Children should be encouraged to work actively in their School Eco-Clubs to identify local species
which are best suited to local conditions of topography, land and climate and also identify different
ways to provide water such as simple methods of drip irrigation. Schools can invite local experts
and farmers to share their expertise with the children. The focus should be on finding innovative
solutions.
~~. ചിക «ea i ro}
൦ എത്ത 0 പമ.
. i 2 (va 3 7 കരി
! cM eval ‘ ഭ്‌ 8
ചം ഴി രൂ )
~ +. ar a)
— Pa ! a ay } ‘ -
ടോ peg em hi ah eg | ടയ
ചം ക, ത Ny ക ര
~ ? j > > ue
‘Ve A ae atone
yy of <. a 4 1 3s
ya . Se ee 4
a tte > &

<!-- page 7 -->

൮൮. ച്‌ ലു പര്‍
പം. 8: eT ടം & 4 3 ലല
OP iF 0 ളു | ആ

4. Teaching students to follow the same learning and start a School Nutrition (Kitchen) Garden
in their own homes. The purpose of setting up such a Kitchen Garden in Schools is to give students
a lifelong skill and to encourage them to go home and start their own garden, in whatever space is
available using their knowledge learnt in School.

5. The MHRD has asked all schools both in rural and urban areas to develop and maintain a School
Nutrition (Kitchen) Garden with teachers, students, parents and even local residents being
involved. Technical assistance, training, provision of seeds, sapling, organic manure etc can be
obtained in convergence with various line departments/agencies like Krishi Vigyan Kendras,
Department of Agriculture/Horticulture, Food & Nutrition Board, State Agriculture Universities,
Forest Department etc. Moreover, activities like construction of boundary wall, levelling of land etc
can be taken up under MGNREGA.

6. Working in the open and cultivating their own food is one of the finest examples of experiential
learning for school children and the benefits of setting up these gardens in schools are manifold.
The joy of watching something they have planted is untold and students learn about
responsibilities, about learning to care for living organisms, teamwork, social skills and about
healthy food alternatives. These activities can also be used for numeracy skills including
measurement, areas and volumes, data gathering and presentation.

7. Plantation in the School Nutrition (Kitchen) Garden may be carried out under the activities of Eco-
Clubs, which is being set up in every school. An Eco-Club is a group of children and teachers in
schools who work to contribute towards improving environmental conditions. Eco-Clubs in
schools shall empower students to participate and take up meaningful environmental
conservation activities and projects.

Each child should be encouraged to plant a tree on his/her birthday. If land is not available
for plantation, they can grow plants in small containers, dibbas, broken sink etc.

<!-- page 8 -->

അ School Nutrition (Kitchen) Garden y
Chapter 1 : Objectives of School Nutrition
(Kitchen) Garden

The main objectives of School Nutrition (Kitchen) Garden are as follows:

a) To help in addressing malnutrition & micro nutrient deficiencies by consumption of freshly
grown vegetables.

b) To give children first-hand experience with nature and gardening.

൭ To enhance the knowledge of children regarding nutritional aspects of vegetables and harmful
effects of junk food.

Need and benefits of School Nutrition (Kitchen) Gardens:

School Nutrition (Kitchen) Gardens have many advantages; some of them are as under:

1. Good for learning: School Nutritional (Kitchen) Gardens are good for learning: they are
highly practical and a direct form of education, where children can learn how to grow good
food, which not only improves health, but also provides opportunities for livelihood and
increased self-sufficiency. Apart from practical skills in agriculture and horticulture, gardens are
a living laboratory for the study of environmental issues and life sciences.

S 6 cy - ~ iy ₹
ക. 7 ടു യ |

ii. Essential for children’s health: These Gardens are good for children's health and
education: A good diet is essential for cognitive abilities which help in learning. Children who
eat well are likely to learn well. School Nutrition (Kitchen) Gardens are not just for food, but for
better eating and they can make a direct and immediate improvement in children's diet. They
can provide fruit and vegetables, rich in vitamins and minerals, add nutritional value to Mid-
Day Meals, increase the variety that is so important for health and growth, and help children to
appreciate and enjoy this variety.

<!-- page 9 -->

iii. Improve environment: School Nutrition (Kitchen) Gardens improve the environment:
Respect for the immediate environment begins at home - and also at School. The school
grounds have elements of the natural environment, the built environment and the social
environment: earth, plants and trees, insects and wildlife, sun and shade; water supply and
sanitation facilities, paths and fences, buildings and shelters; places for recreation and study,
social life and contacts with the outside world. Children's awareness of these, and the way they
learn to treat them, will help them to grow into responsible adults.

iv. School Nutrition (Kitchen) Gardens are good for the earth: Organic gardening
conserves the soil, protects the environment and works with nature rather than against it. It is a
method of growing food that relies on the earth's natural resources, such as land, sun, air,
rainfall, plants, animals and people. It uses natural methods to keep the soil fertile and healthy
and to control insects, pests and diseases. Organic methods can help keep our water sources
clean and free of chemicals. It is also safer for children because there are no dangerous
chemicals.

v. Good for child's well being
Children who are close to nature relate to it as a source of wonder, joy, and awe. Wonder, rather
than books, words, or learning all the facts, provides the direction and impetus for
environmental education in early childhood. Environmental education during the early years
should be based on this sense of wonder and the joy of discovery.

vi. Increases confidence in students
It is a forum through which students can reach out to influence, engage their parents and
neighbourhood communities to promote sound environmental behavior. It will empower

on wee aes] 4 i in
= ളം > baie, ia f° ahi ച
ലം SoM " rte D ,
— a ല്‌ യേ 2) 4
fees ie ~- e
ലു ത്ത ളൂ
“bo ച ‘ ;
ളി y SPN
ts ല്‌
7 Va | ഴ്‌ ലം
) 7/4 Rae) ¢
% PR # a
Fé; 5 പി ഷി i sy 34

<!-- page 10 -->

അ School Nutrition (Kitchen) Garden y
students to explore environmental \ Pe PAN |
concepts and actions beyond the yi 7 si a 3 Sad | ഴ്‌
confines of a syllabus or curriculum. While — a ന്റ്‌ iy = ik} Ga |
everyone, everywhere, asserts the re | ee | SN
importance of ‘learning to live jaa Siow lB ത്‌ ലു €
sustainably,’ environment largely remains 4 ime Mines Vis ക മം a
a peripheral issue in the formal schooling Ant bed at ae :
system. Students of all the Schools need ല്‍ നം 3
to be encouraged to participate in the Wi Yeon.

Eco- Club as an active member. 8
Impact of Climate Change and how School Nutrition (Kitchen) Gardens will be helpful:
There is overwhelming evidence that human activities are affecting the climate and this has
implications for human health.

Role of School Nutrition (Kitchen) Gardens in reducing the negative impact of climate change:
Plants, trees, vegetable and fruits play an important role in reducing the harmful effects of
climate change. Deforestation is one of the major reasons why the quality of air has degraded to an
all-time low. The loss of trees and other vegetation can cause climate change, desertification, soil
erosion, fewer crops, flooding, increased greenhouse gases in the atmosphere etc.

According to scientists, planting of trees, vegetable and fruits is the biggest and cheapest way to tackle
the climate crisis. As trees grow, they absorb SS Ves paves

and store the carbon dioxide emissions that FS » fb ല്‍ ഷി
are driving global heating. Planting of new > ee | AL eee ¥/ 2) ss

trees can help mitigate against climate ~~~ - റ്‌ Se Be 4 ie ay
change by removing Ser from the f sa Se iy ൽ; ae
atmosphere. Combined with the sun's ഏജന്‌

energy, the captured carbon is converted 44 ees ay ©) _ റ
into trunks, branches, roots and leaves via Lcd SDSS gee | i ais നി ളി
the process af photosynthesis Itis stored in 4 ie AS y നം = "4
this "biomass" until being returned back into SE age , Sais

the atmosphere, whether through natural aa is Sie ie “>
processes or human interference, thus ക
completing the carbon cycle.

The School Nutrition (Kitchen) Garden is therefore not only good for the School but it is also good for
the environment because it reduces the carbon footprint of food by decreasing the number of miles it
takes to get vegetables, fruits, legumes and pulses from the farm to Mid Day Meal kitchen . If plants,
trees, vegetable and fruits are planted in the School Nutrition (Kitchen) Garden and at home, it
will help store carbon from the atmosphere into the soil.
