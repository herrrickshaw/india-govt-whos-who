---
doc_id: "63ff8aafc7fef3d2"
source_url: "https://igprgvs.rajasthan.gov.in/writereaddata/Tenders/2025011512025192503231BPDPDPDP.pdf"
ministry: "Indira Gandhi Panchayati Raj and Gramin Vikas sansthan, Rajasthan"
title: "1.1 BPDP & DPDP.pdft"
date: ""
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "23713664407c2c71"
---

<!-- page 1 -->

Understanding Planning at the Intermediate
Panchayat Level in the Context of
Participatory Decentralized Planning
DR.M.N.ROY,
EX-ADDITIONAL CHIEF SECRETARY, GOVERNMENT OF WEST BENGAL

<!-- page 2 -->

Concepts of Decentralization
 Decision making closer to the people for better allocative efficiency – people
pay (& vote) for what services they want
 The principle of fiscal equivalency – if the political jurisdiction matches with the
benefit area, marginal benefit equals to the marginal cost of production (service delivery) –
helps optimal provision of public services
 The decentralized theorem – Each public service should be provided by the
jurisdiction having control over the minimum geographic area that would internalize the
benefit and cost of such provision

 The Principle of Subsidiarity –Taxing, spending, regulatory exercise should be
exercised by the lower level of government unless there is a convincing reason to assign
that work to the higher government

<!-- page 3 -->

Concept of Planning
 Planning is a process of moving from one level of development to a higher level as
decided as per some normative framework and in the local context to prioritize the same
 There are many ways to judge the progress: (i) thematic sectors on which development is
measured, (ii) across different categories of people and (iii) across different areas
 Any government normally plans for (i) what they are responsible, therefore, accountable –
that has a jurisdictional element as well as a subject/thematic area

 They can also plan for what they feel can improve the status of the people in their
jurisdiction on matters for which any other government is responsible (e.g., Centrally
Sponsored Programmes are mostly on subjects on which States are responsible but Union
Govt. allocates their resources)
 Planning involves allocating resources to improve to (i) any subject of development
(what), (ii) to be for certain group of people (for whom), (iii) for a jurisdiction (where)
and has to follow certain process (how) – by exercising discretion what to develop, for
who, where and how.

<!-- page 4 -->

Rationale for Decentralized Participatory Planning
 Planning is for progressing in multiple dimensions of development which in other words
meeting various needs of the people
 Also, the needs are to be met on a sustainable basis – which means the correct process
of development:
i) The process should be people-centric in which people are the Subject of
development and not the Object of development
ii) Such development should be facilitated and not controlled from above
iii) Development should be empowering and to reduce dependence
iv) The process should start with internalizing the problem first along with the
contextual factors, the opportunities and barriers and working on what is possible
to be done by the people/tier of Govt. themselves and then seek for support for
what the people/Govt do not have
v) Such support is fund, technology, skill, capacity etc.

<!-- page 5 -->

Rationale for Decentralized Participatory Planning
 Planning is not to start with what fund any Govt has and on what sector they should
spend the available fund
 So, problem/needs of the people are to be assessed as the starting activity – their
problems may be solved by (i) People themselves with facilitation (no/low cost activities),
(ii) GP, (iii) PS, (iv) ZP or (v) higher level govt.
 Therefore, participation of the people to assess the need, which people can viualize and
identifying the constraints at a decentralized level can provide which tier of govt. including
people’s own initiatives can address the problem faced by any locality
 In that case people become the owner of the plan and not a beneficiary
 There are macro-issues (SDGs) which people are not aware or cannot visualize/quantify
or issues which is emerging and it is difficult for the people to comprehend (climate
change) which requires inputs from higher levels to plan interventions at the lower level
 Thus, planning has to start from below but with good facilitations from above

<!-- page 6 -->

Integration and Coordination of Planning
 GPDP has taken roots and is prepared & implemented to address issues which are local
and keeping the responsibility of the GP for delivering various services
 Many of the problems identified cannot be addressed at the GP level because – (i)
externality of the interventions, (ii) inadequate resources or (iii) requires more advanced
technology beyond the capacity of the GP
 Those are to be referred to the PS to examine what can be taken care of at their level

 The PS has to plan based on (i) Problems referred to them by the GPs (based on primary
data collected using PRA tools/survey, (ii) Problems identified by their own members, (iii)
Analysis of secondary data, if possible with disaggregation up to GP level,
 Similarly, problems which cannot be addressed at the PS level has to be referred to the ZP
and, if necessary, to the state level through ZP
 What has been said is easier said than done, which requires proper coordination across
different tiers and across different departments

<!-- page 7 -->

The Challenge of Integration of Plans of Different Tiers
Village/Ward
Committee

Micro visioning & planning –
linking vision to individual/family

Gram
Panchayat

Link vision to own responsibility
, resources , decide goal & plan

Intermediate
Panchayat

Link vision to own responsibility ,
resources , decide goal & plan

Zilla Panchayat

Link vision to own responsibility
, resources , decide goal & plan

ULB Plans
District Plan

Integration & Consolidation

<!-- page 8 -->

Importance of Planning by the Intermediate Panchayats
 Legal Mandate to plan – for economic development & social justice as provided
under the Constitution

 Presence of officials of all line departments: Intermediate Panchayat (IP or PS)
being coterminous with the Block, it has presence of officials of all the critical departments
 Higher capacity can be used to improve the quality of GPDP and ensure coordination
among relevant line departments/ many GPs are too tiny to plan/projectise efficiently
 Availability of secondary data makes it easier to analyse and the problem of
mismatch between administrative jurisdiction and service areas of various facilities is
generally not there – so GPs may be sensitized with block/GP level data for planning

 Mandate to overview functioning of the GPs – PS stands at a crucial level for
overviewing planning by GPs and drawing attention of the larger issues to higher level

<!-- page 9 -->

Constraints in Planning by Intermediate Panchayats
 Lack of political & administrative will to have PS Development Plan (PSDP) as well as lack

of a framework/guidelines for PSDP
Capacity of the PS/Block has dwindled over the years and many departments view
that they should work independently – how to ensure coordination without control?
 Weak/No Standing Committees to deal with specified subjects with participation of
the officials of the line departments concerned – lack of institutional mechanism
 Lack of dedicated technical man-power to guide Planning process
 Lack of own source revenue of the PSs as well as entitled fund for planning

<!-- page 10 -->

Other Constraints of the PS
 Little formal devolution of powers/ responsibilities on the PS
 Block Officials are generally deputed to function as officials of the PS – there is little
strength of the PS to take care of its core institutional functioning
 Members of PS are not oriented on thematic subjects which are administered by officials
of line departments – so coordination becomes difficult
 Lack of guidelines / proper mindset how services of the line departments can be utilized
by the PS even if they are not administratively controlled by the PS

 Lack of data/ capacity to analyse data to plan with objectivity based on evidence with
clear deliverables

<!-- page 11 -->

Evidence Based Planning at the PS Level
 The PS needs to have capacity to compile block wise situation on different themes of
development and to guide GPs to capture primary data for GPDP as well as helping PS to
build a block database
 The state needs to support development of database and to provide a framework of data
collection and management (DISE/ HMIS/ ICDS MIS etc.)
 Spatial maps of the PS showing GPs to visualize spatial planning and to help convergence
 Building capacity of the PS to analyse the data and to compile a Development Status
Report (DSR) showing status on SDG indicators to the extent possible – that gives the
perspective to plan and measure progress
 Analyse progress across GPs to the extent possible, rank the GPs for each item of
development and invest to bring more equity and bridging the gaps which are bigger in
certain GPs – such analysis will also improve the quality of GPDP
 Building capacity is a big challenge

<!-- page 12 -->

Way Forward for PSDP
 The state government has to come out with an order based on the guidelines prepared by
the NIRDPR/MOPR to give specific mandate
 Need for a dedicated team with capability for data analysis & interpretation/ M&E/
engineering/IT/ various critical aspects of human development & livelihood

 All the line departments to compile the status of progress in respect of their
responsibilities for each block and organize training at the district level to explain the
status and their priorities
 Preparation of a DSR for each PS, whatever rudimentary that may be, as a written
document, which needs to be shared to all stakeholders
 To have development seminars on each theme with participation of lime departmental
officials/experts/ elected functionaries to understand the issues objectively
 Identify the development gaps, priorities and to also work out the resource envelop. At
the block level it will be meaningful to also workout the need for institutional finance, skill
development, IEC/SBCC and work out the interventions plans as well as monitoring

<!-- page 13 -->

THANK YOU
