---
doc_id: "a33fba8a67bb4ef1"
source_url: "https://risl.rajasthan.gov.in/uploads/orders/f12b1192-8606-40f7-a88d-02a3a2811a96.pdf"
ministry: "RajCOMP Info Services Limited, Rajasthan"
title: "Administrative Order regarding Manpower services (Tier-I & Tier-II)"
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "d994fae5017c3080"
---

<!-- no text layer: pending OCR -->
