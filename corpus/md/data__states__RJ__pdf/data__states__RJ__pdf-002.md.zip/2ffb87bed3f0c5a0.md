---
doc_id: "2ffb87bed3f0c5a0"
source_url: "https://transport.rajasthan.gov.in/content/dam/transport/metro/Citizen%20Corner/Public%20Notice/Carriage%20Ticket%20Rules%202014.pdf"
ministry: "Jaipur Metro Rail Corporation Limited (JMRC), Rajasthan"
title: "Carriage and Ticket Rules, 2014"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "20c3ee96a58e34d5"
---

<!-- page 1 -->

Lkk-dk-fu- 899 ¼v½-& dsanzh; ljdkj] esVªks jsy ¼izpkyu vkSj vuqj{k.k½ vf/kfu;e] 2002 ¼2002 dk 60½ dh
/kkjk 32 }kjk iznÙk 'kfDr;ksa dk iz;ksx djrs gq,] fuEufyf[kr fu;e cukrh gS] vFkkZr %&
1- Lkaf{kIr uke vkSj izkjaHk-& ¼1½ bu fu;eksa dk laf{kIr uke esVªks jsy ¼ogu vkSj fVdV½ fu;e] 2014 gSA
¼2½ ;s jkti= eas izdk’ku dh rkjh[k dks izo`Ùk gksxasA
2- ifjHkk"kk,a-& ¼1½ bu fu;eksa esa tc rd fd lanHkZ ls vU;Fkk visf{kr u gks] &
¼d½ **vf/kfu;e** ls esVªks jsy jsy ¼izpkyu vkSj vuqj{k.k½ vf/kfu;e] 2002 ¼2002 dk 60½ vfHkizsr gS(
¼[k½ **izkf/kd`r** ls esVªks jsy iz’kklu }kjk izkf/kd`r vfHkizsr gS(
¼x½ **;k=h** ls fof/kekU; fVdV ;k ikl ds lkFk esVªks jsy esa ;k=k dj jgk dksbZ O;fDr vfHkizsr gS(
¼2½ mu lHkh 'kCnksa vkSj inksa ds] tks bu fu;eksa esa iz;qDr gSa vkSj ifjHkkf"kr ugha gSa] fdarq vf/kfu;e
;k esVªks jsy lk/kkj.k fu;e] 2013 esa ifjHkkf"kr gSa] ogh vFkZ gksaxs] tks mDr vf/kfu;e ;k fu;eksa esa
Øe’k% muds gSaA
3- eky ;k lkeku dk ogu-& dksbZ Hkh O;fDr] esVªks jsy iz’kklu ds iwoZ vuqeksnu ds flok; esVªks jsy esa
;k=k djrs le;] viuh futh eky&vlckc okys ;k=h ls fHkUUk fdlh ,sls eky dk ogu ugha djsxk] tks
vkdkj esa 60 lsUVh ehVj X 45 lsaVh ehVj X 25 lsUVh ehVj vksj 15 fdyksxzke dqy Hkkj ls vf/kd gksA
4- [krjukd vkSj ?k`.kksRiknd lkexzh ys tkus dk izfr"ks/k-& ¼1½ dksbZ Hkh O;fDr fdlh esVªks jsy esa
fuEufyf[kr [krjukd lkefxz;ksa dks ugha ys tk,xk ;k fdlh dks ugh ys tkus nsxk] vFkkZr%&
¼d½ foLQksVd inkFkZ] ftuesa foLQksV ;k vkx yxus ;k nksuksa dk tksf[ke gS(
¼[k½ laihfM+r] nzohd`r ;k ncko ds v/khu ?kqyh gqbZ xSlsa(
¼x½ isVªksfy;e vkSj vU; Toyu’khy nzo(
¼?k½ Toyu’khy Bksl(
¼M-½ vkWDlhdj.kh; inkFkZ(
¼p½ tgjhys ¼fo"kSys½ inkFkZ(
¼N½ vEy vkSj vU; la{kkjd(
¼t½ jsfM;ks,fDVo inkFkZ(
¼>½ 'kL=] vk;q/k vkSj xksyk&ck:n(
¼¥½ dksbZ jklk;fud] TkSfod] jsfM;ksyksftdy] ukfHkdh; vkSj of/kZr ikjaifjd vk;q/k ftlls ;kf=;ksa
;k laifRRk dks [krjk gksA
¼2½ dksbZ Hkh O;fDr esVªks jsy ij fuEufyf[kr ?k`.kksRind lkexzh ugh ys tk,xk ;k fdlh dks ugha ys
tkus nsxk] vFkkZr~ %&
¼d½ ekuo ;k i’kq dk 'kqf"dr ;k Ladfnr ;k lM+k gqvk jDr(
¼[k½ 'ko(
¼x½ e`r i’kqvksa ;k e`r if{k;ksa ds 'ko(
¼?k½ gfM~M;ka] fojaftr vkSj lkQ dh xbZ gfM~M;ksa dks NksM+dj(
¼M-½ ekuo dadky(
¼p½ ekuo 'kjhj ds vax(
¼N½ oguh; jsfM;ks ;qfDr;ka] ftuls jsfM;ks lapkj usVodZ vkSj ;krk;kr fu;a=.k ladsru usVodZ
vk/kkfjr lapkj dks tksf[ke gksA

<!-- page 2 -->

<!-- page 3 -->
