---
doc_id: "acfd0f2055def93f"
source_url: "https://finance.rajasthan.gov.in/PDFDOCS/TAX/GST/15234.pdf"
ministry: "Finance Department, Rajasthan"
title: "Seeks to amend notification No.F.12(5)FD/Tax/2025-05 dated 17.09.2025 regarding retreaded tractor tyres etc"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1ed4e2568a3cc78f"
---

<!-- page 1 -->

GOVERNMENT OF RAJASTHAN
FINANCE DEPARTMENT
(TAX DIVISION)
NOTIFICATION
Jaipur, dated: October 30, 2026
In exercise of the powers conferred by sub-section (1) of section 9 and sub-section (5)
of section 15 of the Rajasthan Goods and Services Tax Act, 2017 (Act no. 9 of 2017),
the State Govenunent, on the recommendations of the COW1cil, hereby makes the
following further amendments in this department's notification no. F.12(5)FD/TaxJ2025-05,
dated the 17th September, 2025, namely: In the said notification, (a) in Schedule 1-2.5%,

I

(i)

against S.No. 237, for the entry in column (3), the following entry shall be
substituted, namely: "All goods i.e. animal or vegetable fertilisers or organic fertilisers prepackaged and labelled.
Explanation. - This entry includes, sea-weed extract based bio-stimulants,
as registered under Schedule VI to the Fertiliser (Inorganic, Organic or
Mixed) (Control) Order, 1985.";

(ii)

after S. No. 272 and the entries relating thereto, the following serial
number and entries shall be inserted, namely: -

"272A.

1

4012

1

Retreaded tractor tyres";

-----------------(b) in Schedule II - 9%, against S. No. 138, for the entry in column (3), the following
entry shall be substituted, namely:"Retreaded or used pneumatic tyres of rubber (other than retreaded tractor tyres);
solid or cushion tyres, tyre treads and tyre flaps, of rubber".

2. This notification shall come into force on the 1st day of November, 2026.
[F.l2 (4) FDlTaxJ2026- 37J
By Order of the Governor,

~Dide1)

Special Secretary to the Government

Page 1 of 2

<!-- page 2 -->

Copy forwarded to the following for infonnation and necessary action:L Superintendent, Government Central Press, Jaipur for publication of this notification in
part 4(c) oftoday's extra ordinary Gazette.
2. Additional Chief Secretary to Hon'ble Chief Minister (Taxation).
3. Secretary to the Government of India-cum-ex-officio Secretary to the GST Council,
GST Cowlcil Secretariat, New Delhi. [Ref. 02/2026-- Central Tax (Rate)]
4. Chief Commissioner, State Taxes, Rajasthan, Jaipur.
5. Accountant General, Rajasthan, Jaipur.
6. PS to Principal Secretary, Finance.
7. PS to Secretary, Finance (Revenue).
8. Director, InfoTI11ation and Public Relations, Rajasthan, Jaipur.
9. Joint Director, Finance (Computer Cell) Department for uploading this notification on
website of Finance Department.
10. Senior Deputy Secretary, Finance(Tax), Rajasthan, Jaipur
11. Guard File.
~
Special Secretary to the Government

Page 2 of 2
