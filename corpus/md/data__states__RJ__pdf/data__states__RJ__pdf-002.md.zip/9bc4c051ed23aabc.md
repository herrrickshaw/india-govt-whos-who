---
doc_id: "9bc4c051ed23aabc"
source_url: "https://cdn.jagannathuniversity.org/docs/admissions/admission-foreign-students.pdf"
ministry: "Jagannath University, Rajasthan"
title: "International Students Policy"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "228a650c478d09d5"
---

<!-- page 1 -->

Jagan Nath University, Jaipur
Office for International Affairs
International Students Policy
ADMISSION PROCEDURE FOR FOREIGN STUDENTS
As per the UGC/ MoE guidelines fifteen per cent seats shall be allowed to be filled on
supernumerary basis over and above the approved intake amongst Foreign Nationals/Persons of
Indian Origin/ Foreign students in programs of the University. Under no circumstances, a seat
remaining unfilled shall be allocated to anyone other than a Foreign Student/PIO/Foreign
National.

1. DEFINITIONS
1.1 Persons of Indian Origin (PIO): Persons who are citizens of other countries (except
Pakistan and Bangladesh) who at any time held an Indian Passport, or who or either of
his parents or any of his grandparents were a citizen of India by virtue of the provisions
of the Constitution of India or Section 2(b) of Citizenship Act, 1955 (Act No. 57 of
1955).
1.2 Foreign Nationals: Citizens of all countries other than India, who are not of Indian
Origin as defined under PIO.
1.3 Foreign Student: Foreign student in this context shall be defined as the student who
possesses a foreign passport.

2. AGE REQUIREMENT
The maximum age as on 1st August of the year i) For all Undergraduate Programs where entry
qualification is Higher Secondary: 21 Years ii) For all other Post-Graduate Programs where entry
qualification is Graduation: 35 Years.

3. ADMISSION PROCEDURE
Admission for various Under Graduate and Postgraduate Programs is done on merit basis.
3.1 The admission process for applicants under foreign category shall be commenced
simultaneously with the admission process for Indian applicants.
3.2 The candidates are required to download the Application Form available at
http://www.jagannathuniversity.org
3.3 The eligibility criteria and fee for various programmes is available on University
Website under the link of Admission, which must be checked by the applicants and
they should apply for a course after ensuring that they fulfill he eligibility conditions
for that particular course.
3.4 Candidates can apply for any of the programs offered by Jagan Nath University in any
one of the two modes: Apply online or Download and take out the print out of the
admission application form.

<!-- page 2 -->

3.5 All foreign nationals with foreign qualifications are required to submit the Equivalence
certificate from Association of Indian Universities (AIU) after admission within a
period of one month.
3.6 The last date for submission of application form is as decided by the university.
3.7 The applicants must submit scanned copies of the documents providing evidence of
their eligibility for the said course along with the application form.
3.8 The candidate must have attained the requisite qualification by the last date. The
admission shall strictly be made on merit basis and firstly be offered to the candidates
applying through ICCR fellowship/scholarship.
3.9 The remaining vacant seats shall be offered to other international candidates strictly on
merit basis.
3.10 The admission shall be made strictly on the merit of marks secured in the qualifying
examination.

4. REGISTRATION WITH FRRO
Upon arrival in India every foreign candidate must be registered with the Police FRRO within 15
days from the date of first entry into India. FRRO Address: Additional Superintendent of
Police Cid (Virus), Zone and Foreign Registration Officer Jaipur City, Jaipur 302002
(Rajasthan).

5 STUDENT VISA
Student Visa is required to join Undergraduate Programme, Post-Graduate Programme.

6. MEDICAL INSURANCE
All the Foreign Students must come with medical insurance before joining the University.

7 SUBMISSION OF APPLICATION
Application complete in all respects along with the mentioned enclosures should be sent to EBlock, Director, Office for International Affairs, Jagan Nath University, NH-12, Chaksu Bypass,
Jaipur- 303901 Rajasthan (India)”. Scanned copy of the duly filled in form along with enclosures
shall also be mailed to admissions@jagannathuniversity.org.

8 REQUIRED DOCUMENTS AT THE TIME OF ADMISSION (FOR
FOREIGN STUDENTS)
The following documents are to be submitted by the candidate at the time of admission:
•
•
•
•
•
•

Certified (English translated) copy of the marks/ grade sheet of the qualifying
examination (if available)
Certified copy of the grade equivalence to marks by the respective boards.
Proof of NRI status of the student/ parents/ sponsor (if applicable)
Copy of the passport (Personal detail pages)
Latest passport size colour photograph in addition to one affixed on the application
Migration Certificate if available at the time of application.

9 PROCEDURE OF DEPOSITING FEES
The payment through Online mode as given at the University website. Fees is to be paid in two
equal Installment on 31 July and January 31st of each year. However, students from Nepal and
Bhutan can pay fee in Indian Rupees. Students from other countries will deposit fee in equivalent

<!-- page 3 -->

to US $. The fee structure for foreign students would be as prescribed by the university for every
academic session.

10 WITHDRAWAL/ REFUND POLICY
The fees once paid are not refundable. However, in case of withdrawal of admissions the fees are
refunded as per the UGC guidelines after making necessary adjustment as required.

11 CANCELLATION OF ADMISSIONS
Jagan Nath University reserves its right to cancel the admission of admitted students under any
of the following circumstances:
•
•
•
•

If the fee is not deposited by the stipulated date.
If the candidate fails to join a particular course by the stipulated date.
If the candidate fails to produce the proof of the minimum qualification.
If the candidate is found to be involved in the malpractices or any other issues regarding
indiscipline.

12. GENERAL GUIDELINES FOR INTERNATIONAL STUDENTS
The University will follow the other general guidelines issued by the UGC and Govt. of India
from time to time regarding admission and other instructions with regarding to
Internationalization of Higher Education in India.
