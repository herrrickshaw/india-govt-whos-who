---
doc_id: "a8556fba7f5dbaff"
source_url: "https://www.rsmm.com/filesrsmm/oo-355-30102025.pdf"
ministry: "Rajasthan State Mines and Minerals Limited, Rajasthan"
title: "Office Order No. RSMM/CO/Pers./6(4)/WM/2018/355 dated 30.10.2025 Regarding AGI of Workmen."
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "181412d44266b775"
---

<!-- page 1 -->

Rajasthan State Mines & Minerals Limited
(A Government of Rajasthan Enterprise)
Corporate Office : 4, Meera Marg, Udaipur - 33 004
Registered Office : C-89-90, Lal Kothl Scheme, Jalpur, CIN-U4409R]949SGCO00505
Phone: 0294-2428763/64/65/66/67, Fax : 0294-2428770/2428739
e-mail : info.rsmml@rajasthan.gov.in, Website: www.rsmm.com
Ref: RSMM/CO/Pers,/6(4)/WM/20 8438.5 Date:--Jo-] 0-26 257
OFFICE ORDER
The Annual Grade Increment in respect of following Workmen is hereby granted
w.e.f. 0.07.2025 as shown against each :-
3a
oS
Sr.No. -_ Name Design. a 2 E Pi : 3
re i > Q a
है (8 |a&s| 28
Ramesh
ea ace
2982 | Lalit Singh Negi ae Helper 28200 29000
Z Prt el, 7 ag
gnature yatic
This bears the approval of competent authority. Digitally signed by 8 loch Singh
७0808 Desenation bike 4
22 ॥200 0 2७० ८ 7602 00०5
व Date: 2025.0. aid
meaty Reason: Approved
Copy to:-
F.A., ९.0.
DGM (F&A)(Admin) 0.0.
BGM (IT) for uploading on company’s website.
Delhi Office.
Personal file of concern employee
DGM (P&A)
RajKaj Ref No.:
48545707
889॥ .0
