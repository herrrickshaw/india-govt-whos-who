---
doc_id: "ca2ab5438db4eee9"
source_url: "https://www.vmou.ac.in/sites/default/files/2026-08-tenderqsppp/BID%2016%20%282026-27%29.pdf"
ministry: "Vardhaman Mahaveer Open University (VMOU), Kota"
title: "BID 16 (2026-27).pdf"
date: ""
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "93aeafa8610f59a7"
---

<!-- page 1 -->

VARDHMAN MAHAVEER OPEN UNIVERSITY, KOTA
Office of Comptroller Rawatbhata Road, Kota-324021 Rajasthan
(Website- vmou.ac.in)

NOTICE INVITING BID

(NIB No. 16 / 2026-27)
Vardhman Mahaveer Open University, Kota invites sealed bids from reputed and registered firms/Agencies under
RTPP Act 2012 & Rules 2013 for the “ARC for Supply of Electric Items” under single stage single part one envelope system
as given below :Name of work

Estimated
Cost Rs.

ARC for Supply of
Electric Items

1.50 Lakh

BID
Security
Rs.
3000/-

BID
Form Fee
Rs.
100/-

Date of
Downloading
BID documents
07 / 08 /2026
to
17 / 08 / 2026

Last Date of
Submission of
BID
18 / 08 / 2026
Up to 12:30 PM

Date of Opening
of BID

Contract
Period

18 / 08 / 2026

12
Months

At 02:30 PM

Instructions to Bidders:1. The detailed scope of work as well as terms and conditions for “ARC FOR SUPPLY OF ELECTRIC ITEMS”
have been given in the BID documents which may be downloaded from www.sppp.rajasthan.gov.in or University
website www.vmou.ac.in.
2. The Interested bidders may submit their bids in a sealed single envelope superscribing “ARC FOR SUPPLY OF
ELECTRIC ITEMS”along with separate Demand Drafts drawn in favour of “Vardhman Mahaveer Open
University” payable at Kota towards the cost of Bid Fee (non-refundable), Bid Security and relevant documents. The
sealed envelope may be dropped in the Tender Box in Room No. 03 or it may be sent to Comptroller, VMOU, Kota
through registered post/parcel upto last date and time as stated above.
3. In the event of the specified dates being a holiday, the activities assigned on that date may be carried out on next
working day on the same time.
4. VMOU, Kota is not bound to accept the lowest bid and may reject any bid or any part of the bid without assigning
any reason therefore.
5. Bids received after the prescribed time and date will not be considered.
6. The bidders shall have to submit GST Registration Number, PAN along with copy of the same without which
the bids will not be considered.
7. Validity: - 90 days from the date of opening of bid.
8. In case of any query, university administration may be contacted at in writing e-mail estate@vmou.ac.in
9. Corrigendum if any will be published on University website and SPPP.
10. Form A, B, C & D as prescribed in Rajasthan Transparency in Public Procurement Rules, 2013 duly signed shall be
enclosed.
11. Self declaration submit with Sign & Seal of firm for Bidder not to be black listed any where prior 3 years till Bid
submission end date.
12. Terms & Condition of Bid & Contract shall be enclosed with Sign & Seal of Bidder.

- Sd Comptroller

<!-- page 2 -->

VARDHMAN MAHAVEER OPEN UNIVERSITY, KOTA
Rawatbhata Road, Kota -3221

Estate Cell
Price Bid
1.
2.
3.
4.
5.
6.
7.
8.

S.No.

1

( “ARC for Supply of Electric Items” )
NIB No and Date
:- 16 / 2026-27 dated 05 .08.2026
Name of Bidder
:Full Address
:Contact No.
:Email Address
:GST Registration No. with copy of Registration
:PAN No. with copy of Registration
:Work Description
:-

Description of Goods & Items

LED Batten(Tube Light) 20W (Bajaj /Havells/ RR
signature)

Per
Unit

Each

2

LED Batten(Tube Light) 22W (Bajaj /Havells/ RR
signature)

Each

3

LED Batten(Tube Light) 25W (Bajaj /Havells/ RR
signature)

Each

4

LED Batten(Tube Light) 35W (Bajaj /Havells/ RR
signature)

Each

5

LED Tube Light 50W (Bajaj /Havells/ RR signature)

Each

6

LED Lamp 7 W (Bajaj /Havells/ RR signature)

Each

7

LED Lamp 9 W (Bajaj /Havells/ RR signature)

Each

8

LED Lamp 14 W (Bajaj /Havells/ RR signature)

Each

9

LED Lamp 18 W (Bajaj /Havells/ RR signature)

Each

10

Each

LED Lamp 50W (Bajaj /Havells/ RR signature)
11

Capacitor /Condensor 2.5 MFD (Havells/Epcos/Klick)

Each

12

Capacitor/Condensor 4 MFD (Havells/Epcos/Klick)

Each

13

Capacitor /Condensor 6 MFD (Havells/Epcos/Klick)

Each

14

Capacitor /Condensor 10 MFD (Havells/Epcos/Klick)

Each

Rates including
All Taxes per
Unit
( In Figures)

Rates including
All Taxes per Unit
( In Words)

<!-- page 3 -->

15

Switch 6A (One way) (Anchor/Rider/ Veto)

Each

16

Switch16A (One way) (Anchor/Rider/ Veto)

Each

17

Switch 6A (Two way) (Anchor/Rider/ Veto)

Each

18

Switch 16A (Two way) (Anchor/Rider/ Veto)

Each

19

S.S.Combined 16A (Anchor/Rider/ Veto)

Each

20

Wire 1.00 Sq mm (Copper) (Polycab/ Havells/ Vimal)

Each

21

Wire 2.5 Sq mm (Copper) (Polycab/ Havells/ Vimal)

ROLL
(90
Mtr)
ROLL
(90
Mtr)

22

Wire 4.00 Sq mm (Copper) (Polycab/ Havells/ Vimal)
23

Aluminium Cable 4.00 Sq mm(Twin core) (Polycab/
Havells/ Vimal)

ROLL
(90
Mtr)

24

Aluminium Cable 6.00 mm (Polycab/ Havells/ Vimal)
(Twin core)

ROLL
(90
Mtr)

25

Aluminium Cable 10.00 Sq mm (Polycab/ Havells/ Vimal)
(Twin core)

ROLL
(90
Mtr)

26

Socket 6A (5 pin) (Anchor/Rider/ Veto)

Each

27

Socket 16A (5 pin) (Anchor/Rider/ Veto)

Each

28

Modular Switch 6A (Anchor/Rider/ Veto)

Each

29

Modular Socket 6A (Anchor/Rider/ Veto)

Each

30

Modular Switch 16A (Anchor/Rider/ Veto)

Each

31

Modular Socket 16A (Anchor/Rider/ Veto)

Each

32

Modular Gang Box(1 Module)PVC (Anchor/Rider/ Veto)

Each

33

Modular Gang Box(3 Module)PVC (Anchor/Rider/ Veto)

Each

34

Modular Gang Box(6 Module)PVC (Anchor/Rider/ Veto)

Each

35

Modular Gang Box(9Module)PVC (Anchor/Rider/ Veto)

Each

36

Modular Gang Box(12Module)PVC (Anchor/Rider/ Veto)

Each

37

Modular Gang Box(16 Module)PVC (Anchor/Rider/ Veto)

Each

38

Sheet Board (with cutting- 4+4)

Each

39

Sheet Board (with cutting- 2+2)

Each

<!-- page 4 -->

40

41

Sheet Board (with cutting for
SS Combined 2+2)

Each

Wire (Copper) 1.5 Sq MM (Polycab/HPL/Vimal )

ROLL
(90
Mtr)

42

Lamp Holder (pendant) (Anchor/ Veto/Vinay)

Each

43

Lamp Holder (Angle/Batton) (Anchor/ Veto/Vinay)

Each

44

MCB (Single Pole) 6 A-32 A (Anchor/ Veto/Vinay)

Each

45

MCB (Single Pole) 40 A – 63 A (Anchor/ Veto/Vinay)

Each

46

PVC Tape Roll (Still Grip/ Anchor/Veto)

Each

47

LED Street Light 40W (HPL/Bajaj/Phillpis)

Each

48

PVC Gitties/Rawal plug

PKT

49

Three PIN Top 6A (Anchor/ Veto/Vinay)

Each

50

Three PIN Top 16A ) (Anchor/ Veto/Vinay)

Each

51

Ceiling Rose ) (Anchor/ Veto/Vinay)

Each

52

PVC Casing 1" (25MM) (AKG)

Each

53

Modular Sheet 6 Module (Anchor/Rider/ Veto)

Each

54

Modular Sheet 4 Module (Anchor/Rider/ Veto)

Each

55

PVC Clip 5.00 MM

PKT

56

PVC Clip 7.00 MM

PKT

57

PVC Clip 10.00 MM

PKT

58

PVC Clip 20.00 MM

PKT

59

PVC Clip 25.00 MM

PKT

60

4 Step Fan Regulator Electronic
Switch Type (Anchor/Rider/ Veto)

Each

61

Fan Regulator Socket Type (Anchor/Rider/ Veto)

Each

62

LED Lamp (Red Coloured) 0.5 W (Bajaj/ Phillpis/Surya)

Each

63

GLS Lamp (BC Clear) 200W (Bajaj/ Phillpis/Surya)

Each

64

Door Bell (Bulbul) (Anchor/Rider/ Veto)

Each

<!-- page 5 -->

65

PVC Pipe 20 MM (Modi/Crown/Poly pack)

Each

66

PVC Pipe 25 MM(Modi/Crown/Poly pack)

Each

67

PVC Band 20 MM(Modi/Crown/Poly pack)

Each

68

PVC Band 25 MM(Modi/Crown/Poly pack)

Each

69

MCB Box 4 Way (Hpl/Veto/PolycB)

Each

70

MCB Box 6 Way(Hpl/Veto/PolycB)

Each

71

MCB Box 8 Way (DILWARI)

Each

72

Modular M.S. Box (2 Module) (DILWARI)

Each

73

Modular M.S. Box (4 Module) (DILWARI)

Each

74

Modular M.S. Box (6 Module) (DILWARI)

Each

75

Modular M.S. Box (8 Module) (DILWARI)

Each

76

Modular M.S. Box (12 Module) (DILWARI)

Each

77

Module Sheet (2 Module)( (Anchor/ Veto/Gold Medal)

Each

78

Module Sheet (4 Module) ( (Anchor/ Veto/Gold Medal)

Each

79

Module Sheet ( 6 Module) )( (Anchor/ Veto/Gold Medal)

Each

80

Module Sheet (8 Module) )( (Anchor/ Veto/Gold Medal)

Each

81

Module Sheet (12 Module) )( (Anchor/ Veto/Gold
Medal)

Each

82

MCB Isolator 2 Pole 32A(Anchor/ Veto,Gold Medal)

Each

83

MCB Isolator 2 Pole 40A(Anchor/ Veto,Gold Medal)

Each

84

MCB Isolator 2 Pole 63A(Anchor/ Veto,Gold Medal)

Each

85

MCB Isolator 4 Pole 63A(Anchor/ Veto,Gold Medal)

Each

86

MCB Isolator 4 Pole 100A(Anchor/ Veto,Gold Medal)

Each

87

A.C. Box(Anchor/Hpl/Benlo)

Each

88

A.C.Top(Anchor/Hpl/Benlo)

Each

89

Woode Screw 1.5"

PKT

90

Woode Screw 2"

PKT

91

Woode Screw 2.5"

PKT

92

Steel Screw 1"

PKT

<!-- page 6 -->

93

Steel Screw 1.5"

PKT

94

Steel Screw 2"

PKT

95

Machine Screw 2"

PKT

96

Machine Screw 2.5"

PKT

97

Energy Meter Single Phase 5-30 A (HPL/ Techno/Genus)

Each

98

Energy Meter Three Phase 10-60 A A (HPL/
Techno/Genus)

Each

99

LED Stret Light 72 Watt (HPL/Bajaj/Phillips)

Each

100

LED Stret Light 90 Watt (HPL/Bajaj/Phillips)

Each

101

LED Flood Light 160 Watt (HPL/Bajaj/Phillips)

Each

102

Street light bracket made out of B-Class G.I. Pipe with
clamp, Saddles and Fasteners -25 mm dia

Each

103

Street light bracket made out of B-Class G.I. Pipe with
clamp, Saddles and Fasteners -32 mm dia

Each

104

Cordless /Remote Bell (Vinay/Paras/Anchor)

Each

105

Modular Regulator 4 Step (Switch Type) ( (Anchor/
Veto/Gold Medal)

Each

106

Modular Regulator 5 Step (Socket Type) ( (Anchor/
Veto/Gold Medal)

Each

107

Submersible Pump 18 Watt (Empire/Stella/Little)

Each

108

Submersible Pump 50 Watt (Empire/Stella/Little)

Each

Date:

Place:

Signature of the Bidder with seal

<!-- page 7 -->

o/kZeku egkohj [kqyk fo'ofo|ky;]dksVk
lEink izdks"B vuqHkkx] jkorHkkVk jksM+] dksV k & 324021
Supply of Electric Items

1 fdlh Hkh U;wure nj okyh fufonk dks Lohsd`r djus ds fy, fo’ofo|ky; ck/; ugha gSA
RTPP Rule 2012 Section 26 varxZr fufonk dks fujLr fd;s tkus dk vf/kdkj fo’ofo|ky; ds ikl
lqjf{kr jgsxkA

2 vuqeksfnr fufonknkrk dks Lohd`r dk;Z vkns’k dh 5% dk;Z fu"iknu izfrHkwfr
(Work Performance Security) jkf’k dk fMekUM Mªk¶V@cSadlZ psd@,Q0Mh0 ¼vU; :iksa
esa Lohdk;Z ugha gksxk½ tks o/kZeku egkohj [kqyk fo’fo|ky; dksVk ds uke ls ns; gksxk] vuqca/k
djus ls iwoZ tek djuk gksxkA
3 vuqeksfnr fufonknkrk@fufonknkrkvksa dks njsa Lohd`fr dh lwpuk fo’ofo|ky; ls izkIr
gksus ij vf/kdre 15 fnol esa dk;kZy; esa mifLFkr gksdj RTPP Rule 2013 (Rajasthan
Transparency in Public Procurement Rules, 2013) ds fu;e 76 ds vuqlkj #0 500@&
ds Non Judicial LVkEi ij vuqca/k lEikfnr djuk gksxkA
4 fufonknkrk QeZ dk Shop Act esa Registration gksuk vko’;d gS ftldk lR;kiu lfefr
}kjk vko’;drkuqlkj fd;k tk ldrk gSA jftLVªs’ku lafonRr vof/k rd fof/kekU; gksuk
pkfg;sA vU;Fkk ekU; ugha gksaxhA lafonk vof/k esa fof/kekU;rk lekIr gksus ls iwoZ gh iquZuohuhdj.k dj
izLrqr djuk gksxk vU;Fkk lafonk fujLr dh tk ldsxhA

5 fufonk esa QeZ }kjk vafdr dksbZ@fdlh izdkj dh 'krsZ RTPP fu;e 56 vuqlkj ekU; ugha
gksxhA l’krZ fufonk Lohdk;Z ugha gksxhA
6 QeZ dks fcy nks izfr;ksa esa e; ewy dk;kZns’k ds lkFk Hkqxrku gsrq izLrqr djuk gksxkA
7 QeZ }kjk dk;kZns’k esa vafdr vof/k ds vUnj fo’ofo|ky; ds lEink izdks"B ds Hk.Mkj x`g
dks vkiwfrZ djuh gksxh vU;Fkk fcy ls fu;ekuqlkj GF& AR (part II) fu;e 58 vuqlkj
isuYVh dkVh tk;sxhA
Delay up to one fourth period of the prescribed delivery period
Delay exceeding one fourth but not exceeding half of the prescribed period
Delay exceeding half but not exceeding three fourth of the prescribed
period
Delay exceeding three fourth of the prescribed period

2½%
5%
7½%
10%

8 ;fn QeZ }kjk dksbZ NwV iznku dh tkrh gS rks mls fufonk izi= esa Li"V :i ls vafdr
fd;k tkosA
9 fo|qr lkeku dh njsa lHkh dj lfgr e; Loading-unloading and Tranportation
vafdr dh tkosA fufonRr njksa ds brj dksbZ Hkqxrku fdlh vk/kkj ij ns; ugha gksxkA
10 fo’ofo|ky; }kjk vuqeksfnr QeZ dks vuqeksfnr njksa ij vko’;drkuqlkj vkiwfrZ vkns’k
tkjh fd;k tk ldsxkA
11 fufonk 'krksaZ ij ;fn QeZ }kjk mDr 'krksaZ ij lgefr gsrq e; eksgj ds gLrk{kj ugh fd;s
tkrs gS rks fufonk Lohdkj ugha dh tkosxhA

<!-- page 8 -->

12 vuqeksfnr njsa ,d o"kZ ds fy;k ekU; gksxh ftls RTPP Rule 2013 (Rajasthan
Transparency in Public Procurement Rules, 2013) ds fu;e 29 ds izko/kkuqlkj vkilh

lgefr ls c<+kbZ tk ldsxhA
13 RTPP Act 2012-13 ds fu;e 73 ifj.kke esa ifjorZu dk vf/kdkj ds vuqlkj%&
¼1½ ;fn mikiu laLFkk ifjfLFkfr;ksa esa ifjorZu ds dkj.k mikiu dh dksbZ fo’k;oLrq mikIr ugha
djrh gS ;k cksyh nLrkostksa esa fofufnZf’V ifjek.k ls de mikIr djrh gS rks cksyh yxkus okyk
cksyh nLrkostksa esa vU;Fkk micaf/kr ds flok;] fdlh Hkh nkos ;k izfrdj dk gdnkj ugha gksxhA
¼2½ vfrfjDr enksa ds fy, vkns”k] ;g ckyh nLrkostksa esa vuqKkr fd;k tk;s] ewy lafonk ds ewY;
ds 5 izfr”kr rd] foRr foHkkx }kjk ;Fkk fofgr “kfDr;ksa dh vuqlwph ds vuqlkj mikiu laLFkk
}kjk j[ks tk ldsxasA lafonkdkj dks mikiu laLFkk }kjk lans; ,slh vfrfjDr enksa dk mfpr
cktkj ewY;] lac f/kr iz”kklfud foHkkx }kjk fofgr ekxZn”kZd fla}krksa ds vuqlkj] mikiu laLFkk
}kjk vo/kkfjr fd;k tk;sxkA
¼3½ ;fn cksyh nLrkostksa esa vuqKkr fd;k tk; rks vfrfjDr ek=k ds fy, vkns”k] lafonk esa nh
xbZ “krksZ vkSj njksa ij fn; tk ldsxas vkSj ewy vkns”k [kqyh izfr;ksxh ckfy;ksa ds vkea=.k ds
Ik”pkr fn;s tk ldsxasA ifjnku ;k iw.kZrk dkykof/k Hkh vuqikfrd :Ik ls c<+kbZ tk ldsxhA
vfrfjDr ek=kvksa ds fy, vkns”k dh lhek fuEukuqlkj gksxh%&
¼d½ oS;fDrd enksa dh ek=k dk 50 izfr”kr vkSj ladeZ dh n”kk esa ewy lafonk ds ewY; dk 50
izfr”kr vkSj
¼[k½ ewy lafonk ds eky ;k lsokvksa ds ewY; dk 50 izfr”kr %
ijUrq vkiokfnd ifjfLFkfr;ksa esa vkSj lafonk ds v/khu ifjdfYir dk;Z ds foLrkj dks cnys fcuk]
lacf/kr iz”kklfud foHkkx ds iwoZ vuqeksnu ls dksbZ mikiu laLFkk ewy ladeZ vkns”k esa ;Fkk
micfU/kr OkS;fDrd enksa dh ek=k ds 50 izfr”kr ls vf/kd vfrfjDr ek=k dk mikiu fuEukuqlkj
dj ldsxh%&
¼i½ fd mikiu laLFkk] ys[kc} fd;s tkus okys dkj.kksa ls] iqujhf{kr vis{kkvksa ds fy, la{ke
izkf/kdkjh ls iwoZ vuqeksnu izkIr djsxhA vfrfjDr ek=kvksa dsa fy, vkns”kksa dh ek=kds dkj.k]
tgka dgh vko”;d gks] mikiu laLFkk l{ke izkf/kdkfj;ksa ls iwoZ vkSj iqujhf{kr rduhdh]
foRrh; vkSj iz”kklfud eatwjh vfHkizkIr djsxhA
¼ii½ fd bl izdkj mikIr vfrfjDr ek=k,sa fu’ikfnr fd;s tkus okys dk;Z dk Hkkx gksxhA
¼iii½ fd ewy lafonk ds ewY; ds 50 izfr”kr dh lhek fdlh Hkh n”kk esa ugha c<+kbZ tk,xhA

14 lkexzh dh vkiwfrZ dk;Z&vkns’k tkjh gksus dh fnukad ls U;wure 05 dk;Z fnol vof/k esa
fo’ofo|ky; ds eq[;ky; fLFkr lEink izdks"B Hk.Mkj ¼dejk u0 21 esa½ oe[kqfo-] jkorHkkVk&
jksM+] dksVk ij vkiwfrZ djuh gksxhA
15 fdlh izdkj dk fookn mRiUu gksus ij U;k; {ks= dksVk jgsxkA

<!-- page 9 -->

16 lkexzh dk;kZns’k ds vuqlkj vkiwfrZ dh tk,xh] VwVh&QwVh] dVh&QVh ,oa {kfrxzLr lkexzh
dks Lohdkj@izkIr ugha fd;k tk;xkA GF & AR (pt II) SR form 16 rFkk fu;e 5 vuqlkj
Defective supply vius O;; ij fofgr le; esa izfrLFkkfir djuh gksxhA ,slk uk djus
ij fo’ofo|ky; }kjk izpfyr njksa ij Ø; dh tk ldsxh ftldh olwyh lafonRr QeZ ls dh
tk;sxhA
17 (Item Wise) U;wure nj nkrk dh nj ml lkexzh ds fy, vuqeksfnr dh tk,xhA
vf/kdre items esa U;wure nj nkrk ls L2, L3 items gsrq Negotiation RTPP fu;e 69
vuqlkkj fd;k tk ldsxkA vlgefr dh fLFkfr esa ,d ls vf/kd fufonknkrkvksa ls nj vuqca/k
fd;k tk ldsxkA
18 jktdh; fu;ekuqlkj fcyks ls VSDl dVksrh dh tkosxhA
19 ;fn vuqca/k vof/k ds nkSjku vuqcaf/kr QeZ }kjk vuqeksfnr njksa ls de nj ij dgha Hkh
vkiwfrZ djuk ik;k tkrk gS rks QeZ dks de nj ds vuqlkj Hkqxrku fd;k tkosxkA
nj lafonRr vof/k esa lafonknkrk }kjk leku items de nj ij vU;= vkiwfrZ dh fLFkfr esa
de njsa Lor% gh RTPP fu;e 29 vuqlkj fo’ofo|ky; gsrq Hkh ykxw ekuh tk;sxhA bl gsrq
i`Fkd i=kpkj dh vfuok;Zrk ugha gksxhA vU;Fkk fLFkfr esa vuqeksfnr njsa gh izHkkoh jgsxhA
20 orZeku GST Rates esa dksbZ la’kks/ku ljdkj }kjk fd;k tkrk gS rks og ykxw fd;k
tkosxkA
21 GF & AR pt(II) fu;e 5 vuqlkj vko’;drk gksus ij Testing djokbZ tk ldrh gSA
22 QeZ dks jkT; ljdkj ;k jkT; ljdkj ds v/khu mikiu laLFkkvksa }kjk fufonk tek dh
vafre fnukad ls 03 o"kZ iwoZ rd vik=rk ds fy;s fooftZr (Debarred) ugha fd;s tkus dk
Lo&?kks"k.kk i= Annexure- E ij djuk gksxkA vU;Fkk dh fLFkfr esa fufonk ij fopkj ugha
fd;k tkosxkA
23 leLr 'krsaZ o izko/kku RTPP fu;e 2013 o GF & AR vuqlkj 'kkflr gksxasA
Eksjs }kjk mijksä funsZ’kksa dk v/;;u dj fy;k x;k gS vkSj eSa viuh lgefr O;ä djrk
gw¡A
gLrk{kj fufonknkrk

<!-- page 10 -->

<!-- page 11 -->

VARDHMAN MAHAVEER OPEN UNIVERSITY, KOTA
Rawathbhata Road, Kota -324021

CONDITION OF TENDER & CONTACT
Note:-Bidders should read these conditions carefully and comply strictly while submitting their tenders.
1.
Tenders by bona-fide dealers:-Tenders shall be given only by bona-fide dealers in the goods. They shall,
therefore, furnish a declaration.
2.
Any change in the constitution of the firm, etc. shall be notified forth with by the contractor in writing to the
Comptroller and such change shall not relieve any former member of the firm, etc. from any liability under the contract.
a.
No new partner/partners shall be accepted in the firm by the contractor in respect of the contract unless he/they agree
to abide by all its terms, conditions and deposit with the Registrar a written agreement to this effect. The Contractor's
receipt for acknowledgment or that of any partners subsequently accepted as above shall bind all of them and will be
sufficient discharge or any of the purpose of the contract.
3.
Rate shall be written both in words and figures. There should not be errors and/or overwriting. Corrections if any
should be made clearly and initialed with dates.
4.
All rates quoted must be FOR ( V.M.O.U., Kota)
5.
Validity: - Tender shall be valid for a period of 90 days from the date of opening of bid.
6.
The approved supplier shall be deemed to have carefully examined the conditions, specifications, size, make, and
drawings, etc. of the goods to be supplied. If he has any doubts as to the meaning of any portion of these conditions or of
the specification, drawing etc., he shall, before signing the contract, refer the same to the purchase officer and get
clarification.
7.
The Contractor shall not assign or sub-let his contract or any substantial part thereof to any other agency.

8.

Specifications:-

(i)
All article supplied shall strictly VMOU, Kota conform to the specifications, trade mark laid down in the tender
form and wherever articles have been required according to ISI specifications, those articles should conform strictly to
those specifications and should bear such marks.
(ii) The supply of articles marked with asterisk/at serial number ……….., shall in addition, conform strictly to the
approved samples and in case of other material where there are no standard or approved samples, the supplier shall be of
the very best quality and description. The decision of the purchase committee whether the articles supplied conform to the
specifications and are in accordance with the samples , if any, shall be final and binding on the bidders.
(iii) Warranty/Guarantee Clause:- The bidder would give guarantee that the goods/stores/articles would continue to
conform to the description and quality as specified for a period of one year from the date of delivery of the said
goods/stores/articles to be purchased and that not with standing the fact that the purchaser may have inspected and/or
approved the said goods/stores/articles, if during the aforesaid period of one year the said goods/stores/articles be
discovered not to confirm to the description and quality aforesaid or have determined(and the decision of the purchase
committee in that behalf will be final and conclusive), the purchaser will be entitled to reject the said goods/stores/articles
or such portion thereof as may be discovered not to conform to the said description and quality on such rejection the
goods/stores/articles will be at the sellers risk and all the provisions relating to rejection of goods, etc., shall apply. The
bidder shall if so called upon to do, replace the goods, etc. or such portion thereof as is rejection by the purchase
committee, otherwise the bidder shall pay damage as may arise by reason of the breach of the condition herein contained.
Nothing herein contained shall prejudice any other right of the purchase committee in that behalf under this contract or
otherwise.

9.

Inspection:-

(a)
The University inspection committee/UPC authorized shall have time to inspect and examine the materials and
workmanship of the goods/equipments/machineries during manufacturing process or afterwards as may be decided.
(b) The tender shall furnish complete address of the premises of his office, godwon and workshop where inspection can
be made together with name & address of the person who is to be contacted for the purpose. In case of those dealers who
have newly entered in business, a letter of introduction from their bankers will be necessary.
10. Samples:- Tenders for articles marked within the schedule shall be accompanied by two set of samples of the
articles (if required) tendered properly packed & signed. Such samples if submitted personally will be received in the
office. A receipt will be given for each sample by the officer receiving the samples. Samples if sent by train etc. should be
dispatched fright paid and the R/R or G.R. should be sent under a separate registered cover.
11. Each sample shall be marked suitably either by written on the sample or on a slip of durable paper securely fastened
to the sample, the name of the bidder and serial number of the item, of which it is a sample in the schedule.
12. Approved samples would be retained free of cost upto the period of six months after the expiry of the contract. The
VMOU, Kota shall not be responsible for any damage, wear and tear or loss during testing, examination, etc during the
period these samples are retained. The sample shall be collected by the bidder on the expiry of stipulated period. The
VMOU, Kota shall in no way make arrangements to return the samples. The samples uncollected within 9 months after
expiry of contract shall be forfeited by the VMOU, KOTA and no claim for their cost, etc., shall be entertained.

<!-- page 12 -->

13. Samples not approved, shall be collected by the unsuccessful bidder. The VMOU, KOTA will not be responsible for
any damage, wear and tear, or loss during testing, examination, etc, during the period these samples are retained. The
uncollected samples shall be forfeited and no claim for their cost, etc., shall be entertained.
14. Drawl of samples:- Incase of tests, samples shall be drawn in four sets in the presence of bidder or his authorized
representative and properly sealed in their presence. Once such set shall be given to them, one or two will be sent to the
laboratories and/or testing house and the third or fourth will be retained in the officer for reference and record.
15. Testing Charges:- Testing Charges shall be borne by the VMOU, KOTA . In case urgent testing is desired to be
arranged by the bidder the testing charges shall be payable by the bidder.

16.

Rejection:-

(i)
Articles not approved during inspection or testing shall be rejected and will have to be replaced by the bidder at his
own cost within the time fixed by the purchase committee.
(ii) If, however, due to exigencies of VMOU, KOTA, such replacement either in whole or in part, is not considered
feasible, the purchase committee after giving an opportunity to the bidder of being heard, shall for reasons to be recorded,
deduct a suitable amount from the approved rates. The deduction so made shall be final.
17. The Rejected articles shall be removed by the bidder within 15 days of intimation of rejection, after which
University shall not be responsible for any loss, shortage or damage and shall have the right to dispose of such articles as
he thinks fit, at the bidder’s risk and on his account.
18. The bidder shall be responsible for the proper packing so as to avoid damage under normal conditions of transport
by sea, rail and road pr air and delivery of the material in good condition to the consignee at destination. In the event of
loss, damage, breakage or leakage or any shortage the bidder shall be liable to make goods such loss and shortage found at
the checking/inspection of the materials by the consignee. No extra cost on such account shall be admissible.
19. The contract for the supply can be repudiated at any time by the University, if the supplies are not made to his
satisfaction after giving an opportunity to the bidder of being heard and recording of the reasons for repudiation.
20. Direct & indirect canvassing on the part of the bidder or his representative will be a disqualification.
21. (i) Delivery and Installation Period:- The bidder whose tender is accepted shall arrange supplies and
installation of items according to given Supply Work Order issued by the university from time to time under ARC.
(ii) Extent of Qty.- Repeat orders:- If the orders are placed in excess of the quantities shown in the tender notice, the
bidder shall be bound to meet the required supply. Repeat orders may also be placed on the rate and conditions given in the
tender provided that the repeat orders are up to 50% of the quantity originally purchased and the period is not more than
one month from the date of expiry of last supply. If the bidder fails to do so, the Registrar shall be free to arrange for the
balance supply by limited tender or otherwise and the extra cost incurred shall be recoverable from the bidder.
(iii) If the purchase officer does not purchase any of the tendered articles or purchase less than the quantity indicated in
the tender form, the bidder shall not be entitled to claim any compensation.

22.

Bid Security:-

(a)
The Bid Security amounting 2% of Tender Value is Rs 1.50 lakh i.e. Rs. 3000/- has been submitted vide Demand
Draft in favour of Vardhman Mahaveer Open University, Kota payable at Kota.
(b) Partial exemption from B.S.:- Firms which are registered with Director of Industries Rajasthan, shall furnish the
amount of earnest money in respect of items for which they are registered as such subject to their furnishing registration
certificate in original or Photostat copy or a copy thereof duly attested by any Gazetted Officer from the Director of
Industries Rajasthan , at the rate of 0.5% of the estimated value of the tender shown in NIT.
(c)
The Central Government and Government of Rajasthan undertakings need not furnish any amount of earnest
money/B.S..
(d)
The earnest money/security deposit lying with the Department/office in respect of other tenders awaiting approval or
rejected or on account of contracts being completed will not be adjusted towards earnest money/security money for the
fresh tenders. The earnest money may however, be taken into consideration in case tenders are re-invited.
23. Forfeiture of B.S.:- The B.S. will be forfeited in the following cases:
(a)
When bidder withdraws or modifies the offer after opening of tender but before acceptance of tender.
(b) When bidder does not execute the agreement if any, prescribed within the specified time.
(c)
When the bidder does not deposit the security money after the supply order is given.
(d)
When he fails to commence the supply of the items as per supply order within the time prescribed.

24.

Agreement and Security Deposit:-

(a)
Successful bidder will have to execute an agreement in the Form SR-17 and deposit Performance security equal to
5% of the value of the stores for which tenders are accepted within 15 days from the date of dispatch on which the
acceptance of the tender is communicated to him.
(b) No interest will be paid by the department on the Performance Security .
(c)
The form of Performance Security shall be as below:
a.
Bank Draft/Bankers Cheque.
b.
Post-office Savings Bank Pass book duly pledged.
c.
National Savings Certificate, Defence Savings Certificates, Kisan Vikas Patras, or any other script /instrument under
National Savings Scheme for promotion of small savings, if the same can be pledged. These certificates shall be accepted
at surrender value.

<!-- page 13 -->

d.
Bank guarantee issued by any of scheduled bank.
(E) The security money shall be refunded after one month of the final supply of the items as per purchase order in case
of one time purchase and two months in case deliveryis staggered, after the expiry of contract on satisfaction completion of
the same or after the expiry of the period of guarantee if any, whichever is later and after satisfied that there are no dues
outstanding against the bidder.
25. (i) Firms Registered with the Director of Industries Rajasthan in respect of stores for which they are registered, subject
to their furnishing the registration in original from the Director of Industries or a Photostat copy or a copy thereof duly
attested by any Gazetted Officer will be partially exempted from earnest money and shall pay security deposit at the rate of
1% of the estimated value of tender.
(ii) Central Government and Government of Rajasthan Undertaking will be exempted from furnishing security amount.
26. Forfeiture of Performance Security Deposit:- Security amount in full or part may be forfeited in the following
cases:
(a)
When any terms and conditions of the contract is breached.
(b)
When the bidder fails to make complete supply satisfactorily.
(c)
Notice of reasonable time will be given in case of forfeiture of security deposit. The decision of
the purchase officer in this regard shall be final.
27. The expenses of completing and stamping the agreement shall be paid by the bidder and the University shall be
furnished free of charge with one executed stamped counter part of the agreement.

28. Insurance:(i)
The goods will be delivered at the destination in perfect condition. The supplier, if he so desires, may be insured the
valuable goods against loss by theft, destruction or damage, by fire, flood, under exposure to whether or otherwise viz.
(war, rebellion, riot etc.) The insurance charges will be borne by the supplier and state will not be required to pay such
charges incurred.
(ii) The articles may also be got insured at the cost of the purchaser, if so desired by the purchaser. In such cases, the
insurance should invariably be with Life Insurance Corporation of India or its subsidiaries.

29. Payments:(i)
Unless otherwise agreed between the parties, payment for the delivery of the stores will be made on completion of
supply satisfactorily and on submission of bill in proper form by the bidder to the University in accordance with GF & AR
all remittance charges will be borne by the bidder.
(ii) In case of disputed items, 10 to 25% of the amount shall be with held and will be paid on settlement of the dispute.
(iii) Payments in case of those goods which need testing shall made only when such tests have been carried out, test
results received conforming to the prescribed specification.
30
(i) The time specified for delivery in the tender form shall be deemed to be the essence of the contract and the
successful bidder shall arrange supplies within the period on receipt of the firm order from the purchase officer.
(ii) Liquidated Damages:- In case of extension in the delivery period with liquidated damage the recovery shall be made
on the basis of following percentage of value of stores which the bidder has failed to supply:Delay up to one fourth period of the prescribed delivery period
2½%
Delay exceeding one fourth but not exceeding half of the prescribed period
5%
Delay exceeding half but not exceeding three fourth of the prescribed
7½%
period
Delay exceeding three fourth of the prescribed period
10%
30.1 Fraction of a day in reckoning period of delay in supplies shall be eliminated if it is less than half a day.
30.2 The maximum amount of liquidated damage shall be 10%
30.3 If the supplier requires an extension of time in completion of contractual supply on account of occurrence of any
hindrance , he shall apply in writing to the authority , which has placed the supply order, fro the same immediately on
occurrence of the hindrance but not after the stipulated date of completion of supply.
30.4 Delivery period may be extended with or without liquidated damages if the delay in the supply of goods is on
account of hindrances beyond the control of the bidder.

30.5 Risk & Cost clause:The competent authority of VMOU, KOTA without prejudice to his right against the approved supplies in respect of
any delay or inferior performance of otherwise or claims for delay in respect of any breaches of the contract and without
prejudice to any rights or remedies under any of the provisions of the contract or otherwise, by notice in writing absolutely
determined the contract in any of the cases.
(i)
A notice in writing to rectify, or otherwise that the work being performed is inefficient or otherwise implemented in
improper manner, shall omit to comply with the requirement of such notice within a period of 07 days or for prescribed
time, thereafter of if the supplier shall delay or suspended the execution of the work so that either in the judgment of the
competent authority, he will be unable to perform the work by the satisfaction of VMOU, KOTA or has already failed to
complete the work by the time.
(ii) If the supplier commits breach of the terms & conditions the contract.
(iii) When the supplier has made himself liable for action under any of the cases aforesaid , the competent authority,
shall exercise power:-

<!-- page 14 -->

(a)
To determine or rescind the contract, as aforesaid, upon such determination or rescission, the bid security,
performance security shall be liable to be forfeited and shall be absolutely at the disposal of VMOU, KOTA.
(b) To get the work done through other service provider and in such case any expenses which may be incurred in
excess, of the sum which would have been paid to the original SP, if the whole work had been executed by him of the
amount of which excess, the decision of the COE/VMOU, KOTA shall be final and conclusive and shall be borne and paid
by the original SP that may be deducted from any money due to him by the VMOU, KOTA or from has bid security,
performance security. However the original SP shall have no claim to compensation for any loss sustained by him or
reason for having purchased or procured any material, equipments or entered into any engagements or made advances on
account of execution/performance of contract.

31.

Recoveries: -

Recoveries of liquidated damages, short supply breakage, rejected articles shall ordinary be made from bills. Amount
may also be withheld to the extent of short supply, breakages, rejected articles and in case of failure in satisfactory
replacement by the supplier along with amount of liquidated damages shall be recovered from his dues and security deposit
available with the department. In case recovery is not possible recourse will be taken under Rajasthan PDR act or any other
law in force.
32. Bidders must make their own arrangement to obtain import licence, if necessary.
33.
If a bidder imposes conditions, which is in addition to or in confliet with the conditions mentioned herein, his tender
is liable to summary rejection. In any case none of such conditions will be deemed to have been accepted unless
specifically mentioned in the letter of acceptance of tender issued by the Dy. Registrar.
34. University reserves the right to accept any tender not necessarily the lowest, reject any tender without assigning any
reasons and accept tender for all or anyone or more of the articles for which bidder has been given or distribute items of
stores to more than one firm/supplier.
35.
The bidder shall furnish the following document at the time of execution of agreement:(a)
Attested copy of partnership deed in case of partnership firms.
(b) Registration number and year registration in case partnership firm is registered with Registrar of firms.
(c)
Address of residence and office, telephone numbers in case of sole proprietorship.
(d)
Registration issued by Registrar of Companies in case of company.
36.
All legal proceeding , if necessary arise to institute may by any of the parties (VMOU, Kota or Contractor) shall
have to be lodged in courts situated in Kota, Rajasthan and not elsewhere.
37. VMOU, Kota is a Govt. university and liable to get maximum educational discount from manufacturer, please
specifies it separately and provide attested copy of educational partner (if any).
38. Bidder should submit their Authorization letter/ Distributor certificate.
39.
The bid and contract shall be governed by the Rajasthan transparency in public procurement Act 2012 and
rules 2013.
40.
Annual Rate Contract for the subject matter of procurement shall be made for one year from the date of
issue of letter of intent; however, the contract period may be extended as Per RTPP Rule 2013.
Note: - I have read the above terms and conditions of contract carefully and I shall be abide by the same.

Date:
Place:

Signature & Seal of the bidder

<!-- page 15 -->

Annexure -A
Compliance with the code of integrity and no conflict of interest
Any person participating in a procurement process shall(a)
Not offer any bribe, reward or gift or any material benefit either directly or indirectly in exchange for an unfair
advantage in procurement process or to otherwise influence the procurement process.
(b)
Not misrepresent or omit that misleads or attempts to mislead so as to obtain a financial or other benefit or avoid an
obligation.
(c)
Not indulge in any collusion, Bid rigging or anti-competitive behavior to impair the transparency, fairness, and
progress of the procurement process.
(d)
Not misuse any information shared between the procuring entity and the Bidders with an intent to gain unfair
advantage in the procurement process.
(e)
Not indulge in any correction including impairing or threatening to do the same, directly or indirectly, to any party
or to its property to influence the procurement process.
(f)
Not obstruct any investigation or audit of a procurement process.
(g)
Disclose conflict of interest, if any, and
(h)
Disclose any previous transgressions with any entity in India or any other country during the last three years or any
debarment by any other procuring entity.
Conflict of Interest:The Bidder participating in a bidding process must have a conflict of interest.
A Conflict of interest is considered to be a situation in which a party has interests that could improperly influence that party’s
performance of official duties or responsibilities, contractual obligation, or compliance with applicable laws and regulations.
I.
A Bidder may be considered to be in conflict of interest with one or more parties in a bidding process if, including
but not limited to;
e.
Have Controlling partners/shareholders in common; or
a.
Receive or have received any direct or indirect subsidy from any of them; or
b.
Have the same legal representative fro purpose of the bid; or
c.
Have the relationship with each other, directly or through common third parties, that puts them in a position to have
access have to information about or influence on the bid of another Bidder, or influence the decision of the procuring entity
the bidding process; or
d.
The Bidder participates in more than one bid in a bidding process. Participation by a Bidder in more than one bid
will result in the disqualification of all Bids in which the Bidder is involved. However this does not limit the inclusion of the
same subcontractor , not otherwise participating as Bidder, in more than one Bid; or
e.
The Bidder or any of its affiliates participated as a consultant in the preparation of the design or technical
specification of the goods, works or service that are the subject of the Bid; or
f.
Bidder or any of its affiliates has been hired (or is proposed to be hired) by the procuring entity as engineer-incharge /consultant for the contract.

Place:
Date:

Signature of the Bidder with seal

<!-- page 16 -->

Annexure -B
Declaration by the Bidder regarding qualifications
In relation to my/our Bid submitted to Comptroller, V.M.O.U., KOTA, Kota for procurement of “ARC for Supply of Electric
Items” in response to their Notice Inviting Bid No. 16 /2026-27 Dated 05.082026. I/We hereby declare under section 7 of
Rajasthan Transparency in Public Procurement Act , 2012, that:1.
I/We possess the necessary professional, technical , financial and managerial resources and competence required by
the Biding Document issued by the Procuring Entity;
2.
I/We have fulfilled my/our obligation to pay such of the taxes payable to the union and the State Government or any
local authority as specification in the Bidding Document;
3.
I/We have are not insolvent in receivership, bankrupt or being wound up, not have my/our affairs administrated by a
court or a judicial officer , not have my/our business activities suspended and not the subject of legal proceeding for any of
the foregoing reasons;
4.
I/We do not have, and our directions and officers not have, been convicted of any criminal offence related to my/our
professional conducted or the making of false statement or misrepresentations as to my/our qualifications to enter into a
procurement contract within a period of three years preceding the commencement of this procurement process, or not have
been otherwise disqualified pursuant to debarment proceeding;
5.
I/We do not have a conflict of interest as specification in the Act, Rules and the bidding document, which material
affects fair competition;

Date:
Place:
Name:
Designation:
Address:

Signature of bidder with seal

<!-- page 17 -->

Annexure C
Grievance redressal during procurement process
The designation and the address of the first appellate authority is Hon’ble V.C. VMOU, Kota.
The designation and the address of second Appellate Authority is Secretary, Higher & Technical education, Rajasthan Govt.
(1)
Filing an appeal
If any bidder or prospective bidder is aggrieved that any decision, action or omission of the Procuring Entity is in
contravention to the provisions of the act or the rules or the Guidelines issued there under, he may file am appeal to first
Appellate Authority, as specified in the Bidding Document within a period of ten days from the date of such decision or
action, omission, as the case may be, clearly giving the specific ground or grounds on which he feels aggrieved:
Providing that after the declaration of a bidder as successful the appeal may be filled only by a bidder who has participated in
procurement proceeding:
Providing further that in case a Procuring Entity evaluates the Technical Bids before the opening of the Financial Bids, an
appeal related to the matter of Financial Bids may be filled only by a Bidder whose Technical Bid id found to be acceptable.
(2)
The officer to whom an appeal is filled under para (1) shall deal with the appeal as expeditiously as possible and
shall endeavourer to dispose it of within thirty days from the date of the appeal.
(3)
If the officer designated under para (1) fails to dispose of the appeal filed within the period specified in para (2), or if
the Bidder or prospective bidder or the Procuring Entity is aggrieved by the order passed by the Procuring Entity, as the case
may be, may file a second appeal to second Appellate Authority specified in the Bidder Document in this behalf within
fifteen days from the expiry of the period specified in para (2) or of the date of receipt of the order passed by the first
Appellate Authority, as the case may be.
(4)
Appeal not to lie in certain cases
No appeal shall lie against any decision of the Procuring Entity relating to the following matters, namely:(a)
Determination of need of Procurement
(b)
Provisions limiting participating of Bidders in the Bid process;
(c)
The decision of whether or not to enter into negotiations;
(d)
Cancellation of a procurement process ;
(e)
Applicability of the provisions of confidentiality
(5)
Form of appeal
(a)
An appeal under para (1) or (3) above shall be in the annexed form along with as many copies as there are
respondents in the appeal.
(b)
Every appeal shall be accompanied by an order appealed against, if any, affidavit verifying the facts stated in the
appeal and proof of payments of fee.
(c)
Every appeal may be presented to first Appellate Authority or Second Appellate Authority, as the case may be, in
person or through registered post or authorized representative.
(6)
Fee for Filling Appeal
(a)
Fee for first appeal shall be two thousand five hundred and for second appeal shall be rupees ten thousand, which
shall be non refundable.
(b)
The fee shall be paid in the form of bank demand draft or banker’s cheque of a Scheduled Bank in India payable in
the name of Appellate Authority concerned.
(7)
Procedure for disposal of appeal
(a)
The first Appellate Authority or Second Appellate, as the case may be upon filing of appeal, shall issued notice
accompanied ny copy of appeal, affidavit and documents, if any, to the respondents and fix date of hearing.
(b)
On the date of fix hearing, the First Appellate Authority or second Appellate Authority , as the case may be shall,(i)
Hear all the parties to appeal present before him; and
(ii)
Peruse or inspect documents , relevant records or copies thereof relating th the matter
(c)
After hearing the parties , perusal or inspection of documents and relevant records or copies thereof relating to the
matter, the Appellate Authority concerned shall pass an order in writing and provide the copy of order to the parties to appeal
free of cost.
(d)
The order passed under sub-clause (c) above shall also be placed on the State Public Procurement Portal.

Date:
Place:

Signature of the Bidder with seal

<!-- page 18 -->

Annexure-D
Additional conditions of contract
1.
Correction of arithmetical errors
Provided that a Financial Bid is substantially responsive, that Procuring Entity will correct arithmetical errors during
evaluation of Financial Bids on the following basis:
i.
If there is a discrepancy between the unit price and the total price that is obtained by multiplying the unit price and
quality , the unit price shall prevail and the total price shall be corrected, unless in the opinion in the Procuring Entity there is
an obvious misplacement of the decimal point in the unit price, in which case the total price as quoted shall govern and the
unit price shall be corrected;
ii.
If there is a error in a total corresponding to the addition or subtraction of subtotals, the subtotals shall prevail and
the total shall be corrected; and
iii.
If there is a discrepancy between words and figures, the amount in words shall prevail, unless the amount in figures
shall prevail subject to (i) and (ii) above.
If the Bidder that submitted the lowest evaluated Bid does not accepted the correction of errors, its Bid shall be disqualified
and its Bid Security shall be forfeited or its Bid Securing Deceleration shall be executed.
2.
Procuring Entity’s Right to very Quantities.
i.
At the time of award of contract, the quantity of goods, works or services originally specified in the Bidding
Document may be increased or decreased by a specified percentage, but such increase or decrease shall not exceed twenty
percent, of the quantity specified in the Bidding Document. It shall be without any change in the unit price or other terms &
conditions of the Bid and the conditions of contract.
ii.
If the Procuring Entity does not procure any subject matter of procurement or procures less than the quantity
specified in the Bidding Document due to change in circumstances, the Bidder shall not be entitled for any claim or
compensation except otherwise provided in the conditions of contract.
iii.
In case of Procurement of Goods or services, additional quantity may be procured by placing a repeat order on the
rates and conditions of the original order. However, the additional quantity shall not be more than 25% of the value of Goods
of the original contract and shall be within one month from the date of expiry of last supply. If the Service Provider fail to do
so, the Procurement Entity shall be free to arrange for the balance supply by limited Bidding or otherwise and the extra cost
incurred shall be recovered from the Service Provider.
3.
Dividing quantities among one than more Bidder at the time of award (In case of procurement of Goods)
As a general rule all the quantities of the subject matter of procurement shall be procured for the Bidder, whose Bid is
accepted. However, when it is considered that the quantity of the subject matter of procurement to be procured is very large
and it may not be in the capacity of the Bidder, whose Bid is accepted, to deliver the entire quantity or when it is considered
that the subject matter of procurement to be procured is of critical and visit nature, the quantity may be divided between the
Bidder, whose Bid is accepted and the second lowest Bidder or even more Bidders in that order, in a fair, transparent and
equitable manner at the rates of the Bidder, whose Bid is accepted.

Date:
Place:

Signature of the Bidder with seal
