---
doc_id: "cde1fe3fc3183ccb"
source_url: "https://rajfab.rajasthan.gov.in/web/Documents/Notifications/Tentative_Seniority_list_Senior_Assistant_26_04_2024.pdf"
ministry: "Factories and Boilers Inspection Department, Rajasthan"
title: ""
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "47f88ac122e5b73d"
---

<!-- page 1 -->

jktLFkku ljdkj
dkj[kkuk ,oa ck;ylZ fujh{k.k foHkkx
dk;kZy; eq[; fujh{kd dkj[kkuk ,oa ck;ylZ] jktLFkku] t;iqj&302004
dzekad%& eqfudkck@LFkk-¼29½@24@
t;iqj] fnukad%
dk;kZy; vkns'k
bl foHkkx esa fnukad 01-04-2024 dh fLFkfr esa LFkkbZ ,oa vLFkkbZ :i ls dk;Zjr
ofj"B lgk;d dh vufUre (Tentative) ofj"Brk lwph fuEu izdkj ls izdkf'kr dh tkrh gS%&
dz-la1
1234-

deZpkjh dk uke
2
Jh fodkl [k.Msyoky
Jh izrki flag
Jh vtqZu yky eh.kk
Jh xkSjo dqekj 'kekZ

fu;qfDr fnukad
3
06-05-2014
21-07-1988
24-11-1992
07-01-2016

inksUufr fnukad
4
14-06-2019¼19&20½
14-06-2019¼19&20½
14-06-2019¼19&20½
23-06-2021¼21&22½

tUe fnukad
5
22-04-1996
15-07-1965
01-06-1970
25-12-1997

567-

Jh jkepUnz xkMjh
Jh txnh’k izlkn jSxj
Jh eqds’k ckjM

25-03-1994
03-07-1995
03-02-2017

23-06-2021¼21&22½
23-06-2021¼21&22½
23-06-2021¼21&22½

07-02-1970
01-07-1965
17-11-1982

8910-

Jh vkse izdk’k dYyk
Jh yo dqekj 'kekZ
Jh ;ksxs’k dqekj 'kksHkkor

14-03-2018
14-03-2018
15-03-2018

23-06-2021¼21&22½
23-06-2021¼21&22½
23-06-2021¼21&22½

29-07-1980
04-09-1994
10-10-1994

111213141516-

Jh jktnhi cjkM
Jh egs’k dqekj ;kno
Jh nhid fla?ky
Jh v’kksd dqekj 'kekZ
Jh HkwisUnz flag
Jh jfo cqudj

14-03-2018
13-03-2018
14-03-2018
12-03-2018
15-03-2018
03-10-2017

23-06-2021¼21&22½
23-06-2021¼21&22½
23-06-2021¼21&22½
23-06-2021¼21&22½
23-06-2021¼21&22½
09-09-2022 ¼22&23½ ¼fnukad
01-04-2022 ls izHkkoh½

20-07-1987
01-07-1973
07-11-1992
10-07-1987
20-10-1994
01-09-1992

17-

Jh iqyfdr xqIrk

26-02-2018

01-12-1991

18-

Jh xkso/kZu flag pkS/kjh

16-06-1993

19-

Jh lsBkjke

21-02-2019

09-09-2022 ¼22&23½ ¼fnukad
01-04-2022 ls izHkkoh½
09-09-2022 ¼22&23½ ¼fnukad
01-04-2022 ls izHkkoh½
09-09-2022 ¼22&23½ ¼fnukad
01-05-2022 ls izHkkoh½

20-

Jh egsUnz flag 'ks[kkor

18-10-2019

21-

Jh tfru pkS/kjh

22-10-2019

09-09-2022 ¼22&23½ ¼fnukad
01-06-2022 ls izHkkoh½
09-09-2022 ¼22&23½ ¼fnukad
01-06-2022 ls izHkkoh½

fo'ks"k fooj.k
6
&
&
vuqlwfpr tutkfr
vuqdEikRed
fu;qfDr
vks-ch-lh
vuqqlqfpr tkfr
vuqdEikRed
fu;qfDr ¼vuqqtkfr½
¼vks-ch-lh½
¼vks-ch-lh½
¼vks-ch-lh½

19-11-1974

vuqdEikRed
fu;qfDr ¼vuqqtkfr½
vuqdEikRed
fu;qfDr
vks-ch-lh

07-05-1992

¼vks-ch-lh½

11-06-1998

vuqdEikRed
fu;qfDr
vuqdEikRed
fu;qfDr ¼vks-ch-lh½

07-08-1999

;fn fdlh deZpkjh dks viuh ofj"Brk ds ckjsa es dksbZ vkifRr gks rks viuk vH;kosnu e; Bksl
izek.k ds lkFk bl dk;kZy; dks mijksDr ofj"Brk lwph tkjh gksus dh frfFk ls 07 fnol ds vUnj&vUnj
vius lEcfU/kr vf/kdkjh ds ekQZr izsf"kr djsaA fu/kkZfjr vof/k i'pkr izkIr vH;kosnuksa ij dksbZ dk;Zokgh
ugha dh tkosxhA ofj"Brk lwph dh izkfIr jlhn vius vf/kdkjh ls izekf.kr djokdj fHktok;sA

Signature Not Verified
RajKaj Ref
6788128
¼gjh'k dqekj xqIrk½

Digitally signed by Harish Kumar
Gupta
Designation : Chief Inspector
Date: 2024.04.26 18:32:32 IST
Reason: Approved

<!-- page 2 -->

eq[; fujh{kd dkj[kkuk ,oa ck;ylZ]
jktLFkku] t;iqjA

Øekad% eqfudkck@LFkk-¼29½@24@
t;iqj] fnukad%
izfrfyfi fuEu dks lwpukFkZ ,oa vko’;d dk;Zokgh gsrq iszf"kr gS%&
1- mi eq[; fujh{kd@ofj"B fujh{kd@fujh{kd dkj[kkuk ,oa ckW;ylZ-----------------dks
izsf"kr dj ys[k gS fd deZpkjh ls izkfIr jlhn izkIr dj bl dk;kZy; dks
fHktok;saA
2- lacaf/kr deZpkjh Jh-----------------------------------3- IT CELL dks izsf’kr dj ys[k gS fd mDr lwph dk foHkkxh; osclkbZV ij v|
ru djsaA
4- jf{kr i=koyhA
eq[; fujh{kd dkj[kkuk ,oa ck;ylZ]
jktLFkku] t;iqjA

Signature Not Verified
RajKaj Ref
6788128

Digitally signed by Harish Kumar
Gupta
Designation : Chief Inspector
Date: 2024.04.26 18:32:32 IST
Reason: Approved
