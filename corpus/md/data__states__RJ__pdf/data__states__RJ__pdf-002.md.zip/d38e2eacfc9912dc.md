---
doc_id: "d38e2eacfc9912dc"
source_url: "https://www.ctae.ac.in/images/tenders/LB-12.pdf"
ministry: "College of Technology and Engineering, Maharana Pratap University of Agriculture and Technology Udaipur, Rajasthan"
title: "LB-12(Hostel)  New"
date: ""
pages: 3
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "f7d60fc7df18e009"
---

<!-- page 1 -->

‘
fy none: ७2०१-2१ /U8S /, UZ94-24/ LUD0 (hax), E-mail: clacacan(@gemail.com
‘ee? COLLEGE OF TECHNOLOGY AND ENGINEERING ;
Nees Maharana Pratap University of Agriculture & Technology,
“ Udaipur — 33 00] Rajasthan
No. CTAE/ Acetts /MosteV'Tender/2026). S OFS Dated: 22} 0-2026
Sealed Bids, in prescribe format, are invited on behalf of the Dean, College of ey and
Engineering, Maharana Pratap University of Agriculture and Technology, Udaipur (Rajasthan) for the
| procurement of “NOTEBOOK COMPUTER ” detailed in the Schedule of Supply (Annexure:
| from manufacturers/ distributors/ authorised dealers/ stockiest/ registered Bidders/ bona-fide, dealers Bienes
| Date and Time Specified below. The Bidders or their representative may be present in the bid opening. 7
| bidding document may also be downloaded from our websites wwi.ciae.ac. nor www.mpuatac.inor the
website of State Public Procurement Portal www.sppp-rajasthan.gov.in.
| IMPORTANTBIDDATA ——
i . |Procuring Entity's address for Bid Submissioy Dean, College of Technology and Engineering,
clarification, and Opening of Bids Administrative Block,
Udaipur - 33 00 Telephone No.: 0294-2470837;
FaxNo.:0294-247] 056,E-mail: ctaedean@gmail.com
। Deadline for Bid submission Date : 30- 0-2026 Time: 0.00PM
| Bid opening Date : 30- 0-2026 Time: 3.00 PM
| 5. |Bid Security Amount 2% DD or Banker’s Cheque in favor of Dean CTAE,
(Cheque will not be accepted)
[6. | Bid Should remain Valid Up to 30 Days from the Last date of submission of Bids
BID Ref. No. CTAE /Hostel/2026-27/LB- {2—
Brief Description of the Goods/ Services/Works: है :
(Please Refer to the Schedule of Supply of Supply (Annexure-I) for Detailed Specifications and Special Conditions, if
am
SN Name of the Goods/ Services/Works Quantity Approx. Cost*
and Unit Rs.
NOTEBOOK COMPUTER 0 Unit | 7,95,000.00*
॥॥ Processor & MS chip with a 0-core CPU, l0-
Graphics core GPU 8
2 Memory 6GB,
3. Storage Options 5l2GB SSD
4. Display 5.3-inch Liquid Retina display
(2880 x |864 native resolution,
5 Connectivity Wi-Fi 7, Bluetooth 6, two
Thunderbolt 4 (USB-C) ports, and a
3.5mm headphone jack
* Including all taxes and expenditure with installation and commissioning.
SPECIAL CONDITIONS (if any)
]. Price quoted should be FOR at CTAE, Udaipur — 3300! Raj., India, including basic
price, GST, and all other relevant services and Taxes.
2. GST: The GST is applicable as per Govt. rules.
3. Installation & Training: Onsite installation, commissioning and training included in
the bidding price.
4. Payment after successful installation and commissioning of items / Equipments.
5. The bidders should be providing all necessaries kit with equipment/Machine.
& Scanned with OKEN Scanner

<!-- page 2 -->

if sd
©. Ine vlaaer Is require
and testing of a tO supply te requirea wiring / connector etc., or instanauon 8
TERMS & CONDITIONS: .
!. Bid Preparation and Submission:
M4 ता a be submitted on oficial leter head of the bidder in the enclosed format ;
> )a a signed by the Bidder and must be properly scaled in an envelope. On the 4
envelope “Bid for the Supply of [Name of Item/Services.]”,“Due date of Opening” and Bid
Kee No, must be clearly marked. If the bid is not scaled and marked as required, the Procuring
Entity shall assume no responsibility about its consequences including misplacement and
premature opening of the Bid.
2. Validity of Quotation: i
2.] Quotation shall remain valid for acceptance for a period not less than 30 days after the deadline
date specified for submission.
3. Bid prices
3.l The rates quoted by the bidder shall be in Indian Rupees only and shall remain fixed for the
duration of the contract and shall not be subject to adjustment on any account.
3.2 All taxes like Central/ Rajasthan GST, etc. to be charged extra should be shown separately
(along with their rate) failing which the rates quoted by the bidder shall be assumed to be
inclusive of all taxes and levies.
3.3. Allrates quoted must be FOR destination and should include all incidental charges.
3.3 The goods quoted should be as per the required specifications. Any deviations should be AY
mentioned in the quotations.
3.4 Wherever applicable, the Make and Model No. of goods offered and their technical क्र
leaflet/brochure must invariably be enclosed, failing which the bid may be rejected.
4. Award of Contract/Supply Order
4.| The Purchaser will award the contract/Supply Order to the bidder whose quotation has been
determined to be substantially responsive, conform to the terms & conditions, and
specifications and who has offered the lowest evaluated quotation price.
4.2. Notwithstanding the above, the Purchaser reserves the right to accept or reject any quotations
and to cancel the bidding process and reject all quotations at any time prior to the award of
contract.
5. General
5.] Quantities given are approximate and the final order may be placed for more or less quantities.
5.2. The bids for the items, wherever indicated, will not be accepted without samples.
53. Inall future references the Bid No. must be invariably mentioned.
5.4. Normal commercial warranty/ guarantee shall be applicable to the supplied goods.
5.5 The bidder has to mention their RST/CST/GSTIN No. in their quotations otherwise their bids
are liable to be rejected.
5.6 Payment shall be made against printed, pre-receipted, and pre-stamped invoice/bill mentioning
RST/CST/GSTIN No. Chop
DEAN
Copy to: v
I. Dr. N. L. Pawar Nodal Officer(Accounts), Dr. Sachin Wandkar, Procurement Committee (with a
soft copy in pdf format) to kindly arrange to upload the Bid Document on the College website and
the State Procurement Portal today itself.
2. The 5.0. (A/C) Qh
3, The tenders Notice Board.
DEAN
oY
|
(छ8& scanned with OKEN Scanner

<!-- page 3 -->

/
Annexure-
(Tob RORMATOF QUOTATION OF QUOTATION a
० be submitted on the Letter head of the Bidd:
SN. = of the Bidder)
N Name of the Goods/ Services/ Works with T Unit | Quoted | Taxes and
pecifications(including installation requirements, if any) | | Unit Rate | their rate
| | inRs. | (ifnot
| ln Fig. and| included)
| | ७०१७ !
जड़ 2. {@)_ | (4. i (6)
NOTEBOOK COMPUTER | ol |
l Processor & © MS chip with a I0-core CPU, 0- | Unit |
Graphics core GPU | |
2 Memory 6GB, | |
3 Storage 5I2GB SSD | |
Options |
4... Display 5.3-inch Liquid Retina display | lay
(2880 x 864 native resolution, 500 | | \
nits brightness | |
5 Connectivity Wi-Fi 7, Bluetooth 6, two | |
Thunderbolt 4 (USB-C) ports, and | |
3.5mm headphone jack | |
|
***Make and Model No. of goods offered and their technical brochure must be enclosed duly signed and
stamped by bidder.
DECLARATION
(a) VWe declare that I am/ we are Manufacturers/ Whole sellers/ Sole distributor/ Authorized dealer/
bonfire dealers in the Goods and Related Services or Services/Works for which I/We have Bid.
(b)I/We agree to supply the above goods/Services in accordance with the technical specifications
within the period specified in the Bidding Documents. I/We further agree that our rates, if
approved, shall remain valid for further 3 months from the Last Date of Submission of Quotations.
(c)We also confirm that the normal commercial Warrantee/Guarantee of 2 months shall apply to the
offered goods.
(d) I/We have not been debarred by the State Government or the Procuring Entity.
(0 If this declaration is found to be incorrect or I/We fail to supply the goods/services, then without
prejudice to any other action that may be taken, the Supply Order/Bid, if any to the extent accepted,
may be cancelled and I/We may be debarred from participating in future bids as per rules.
Signature of Bidder
Name& Address of Bidder:
Contact No.
PAN No.
GST No.
& Scanned with OKEN Scanner
