---
doc_id: "f420fd6dec872ffe"
source_url: "https://igprgvs.rajasthan.gov.in/writereaddata/Tenders/2025011512060676450409BPDPDPDP.pdf"
ministry: "Indira Gandhi Panchayati Raj and Gramin Vikas sansthan, Rajasthan"
title: "1.9 BPDP & DPDP.pdf"
date: ""
pages: 40
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "600e360dadb71f9e"
---

<!-- page 1 -->

राजस्थान सरकार
Utilisation of e-Gramswaraj Portal of the MoPR
for BDP and DDP

ग्रामीण विकास एिं पंचायती राज विभाग
(पंचायती राज)

<!-- page 2 -->

eGramSwaraj Home Page

URL :- https://egramswaraj.gov.in

<!-- page 3 -->

EGRAMSWARAJ WORKFLOW
Zila Parishad
Panchayat Samiti
Profile

Planning

Progress Reporting

Accounting

जजला प्रमुख / प्रधान तथा
मुख्य काययकारी अधधकारी /
विकास अधधकारी का डाटा
इन्द्राज करना
कायय का इंराज ि कायय के
ललए फण्ड आिंटन करना

इंराज कायय के प्रतत तकनीकी
स्िीकृतत एिं प्रशासतनक
स्िीकृतत दजय करना

Online Payment करना

<!-- page 4 -->

EGRAMSWARAJ GRAM PANCHAYAT LOGIN

<!-- page 5 -->

ZP / PS /PANCHAYAT PROFILE

ZP / PS / Panchayat Profile update
करने के ललए General Profile में
Add पर जललक करें गे

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

ZP / PS / PANCHAYAT PROFILE (MANAGE GENERAL PROFILE)

<!-- page 10 -->

ZP / PS / PANCHAYAT PROFILE (UNFREEZE PROFILE)

<!-- page 11 -->

PLANNING (RESOURCE ENVELOPE)

<!-- page 12 -->

PLANNING (ACTIVITY)

Activity create करने के ललए
Add पर जललक करें गे

<!-- page 13 -->

PLANNING (ACTIVITY CREATION)

<!-- page 14 -->

PLAN PENDING IN ACTIONPLAN

<!-- page 15 -->

<!-- page 16 -->

PLAN PENDING IN ACTIONPLAN

<!-- page 17 -->

MODIFY ACTION PLAN

Activity के ललए fund allocation
के ललए यहााँ जललक करें
ग्राम सभा अनुमोदन की
Copy Upload करें

<!-- page 18 -->

PLAN SAVED FOR APPROVAL

<!-- page 19 -->

PLAN PENDING FOR APPROVAL

<!-- page 20 -->

APPROVING GRAM PANCHAYAT DEVELOPMENT
PLAN
Approval Date दजय करें

<!-- page 21 -->

PLAN APPROVED

<!-- page 22 -->

<!-- page 23 -->

<!-- page 24 -->

<!-- page 25 -->

<!-- page 26 -->

<!-- page 27 -->

<!-- page 28 -->

<!-- page 29 -->

<!-- page 30 -->

<!-- page 31 -->

<!-- page 32 -->

<!-- page 33 -->

<!-- page 34 -->

<!-- page 35 -->

<!-- page 36 -->

<!-- page 37 -->

Sr.
No

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33

District

PlanPlus (GPDP Report 2020-21) (09-02-2021)
Total PRIS

AJMER
ALWAR
BANSWARA
BARAN
BARMER
BHARATPUR
BHILWARA
BIKANER
BUNDI
CHITTORGARH
CHURU
DAUSA
DHOLPUR
DUNGARPUR
GANGANAGAR
HANUMANGARH
JAIPUR
JAISALMER
JALORE
JHALAWAR
JHUNJHUNU
JODHPUR
KARAULI
KOTA
NAGAUR
PALI
PRATAPGARH
RAJSAMAND
SAWAI MADHOPUR
SIKAR
SIROHI
TONK
UDAIPUR
Total

ZP

PS

GP

1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
33

11
16
11
8
21
12
14
9
5
11
7
11
6
10
9
7
22
7
10
8
11
21
8
5
15
10
8
8
7
12
5
7
20
352

325
580
417
235
689
405
398
367
184
299
304
287
191
353
345
269
606
206
307
254
337
629
243
158
500
341
235
214
229
375
171
236
652
11341

ZP Pending
Plan

ZP Approved
Plan

PlanPlus 2020-21
PS Pending
PS Approved
Plan
Plan
8

1

3

GP Approved
Plan

0

325

4

576

10

1

0

417

2

6

4

231

1

18

3

42

647

1

6

6

2

403

1

14

14

384

1

8

1

86

281

1

2

3

0

184

1

11

6

293

1

7

23

281

1

10

1

14

273

1

5

1

9

182

1

9

1

0

353

1

8

1

8

337

1

6

1

5

264

1

21

1

1

7

0

1

1
0

1

16

GP Pending Plan

6

4

1

6

2

1

11

1

20

1

5

0

1

2

604

45

161

21

286

0

254

24

313

1

1

628

3

8

235

0

5

0

158

1

14

1

0

500

1

9

1

0

341

1

8

37

198

1

6

2

2

212

1

4

3

1

228

1

8

4

2

373

1

5

4

167

1

7

0

236

1

8
285

2
366

10975

0

29

1

4

12
67

650

<!-- page 38 -->

Sr.
No

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33

District

PlanPlus (GPDP Report 2021-22) (09-02-2021)
Total PRIS

AJMER
ALWAR
BANSWARA
BARAN
BARMER
BHARATPUR
BHILWARA
BIKANER
BUNDI
CHITTORGARH
CHURU
DAUSA
DHOLPUR
DUNGARPUR
GANGANAGAR
HANUMANGARH
JAIPUR
JAISALMER
JALORE
JHALAWAR
JHUNJHUNU
JODHPUR
KARAULI
KOTA
NAGAUR
PALI
PRATAPGARH
RAJSAMAND
SAWAI MADHOPUR
SIKAR
SIROHI
TONK
UDAIPUR
Total

ZP

PS

GP

1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
33

11
16
11
8
21
12
14
9
5
11
7
11
6
10
9
7
22
7
10
8
11
21
8
5
15
10
8
8
7
12
5
7
20
352

325
580
417
235
689
405
398
367
184
299
304
287
191
353
345
269
606
206
307
254
337
629
243
158
500
341
235
214
229
375
171
236
652
11341

ZP Pending
Plan

ZP Approved
Plan

1

0

PlanPlus 2021-22
PS Pending
PS Approved
Plan
Plan
11

GP Pending Plan

GP Approved
Plan

0

325

0
108

1

0

16

0

472

1

0

11

0

416

1
153

1

0

8

0

82

1

0

21

0

678

11

1

0

12

0

401

4
0

1

0

14

0

398

1

0

9

0

367

0
0

1

0

5

0

184

1

0

11

0

298

1

1

0

7

0

243

61

1

0

11

0

287

0

1

0

6

0

159

32
7

1

0

10

0

346

1

0

9

0

250

95

1

0

7

0

94

175

1

0

22

0

162

444

1

0

7

0

206

0

0

307

0
0

1

0

10

1

0

8

0

254

1

0

11

0

331

6
555
36

1

0

21

0

74

1

0

8

0

207

0

122

36
366

1

0

5

1

0

15

0

134

1

0

10

0

341

0
0

1

0

8

0

235

1

0

8

0

210

4
73
40

1

0

7

0

156

1

0

12

0

335

1

0

5

0

171

0

206

30

1

0

7

0

1

0

20

0

512

140

0

8963

2378

33

0

352

<!-- page 39 -->

rduhdh lgk;rk ds fy, d`i;k foHkkxh; bZ&esy vkbZ-Mhij bZ&esy izsf"kr djkosaA
bZ&esy vkbZ-Mhrajpr.dsplan@rajasthan.gov.in
rajpr.acp@rajasthan.gov.in
rajpr.programmer@rajasthan.gov.in

<!-- page 40 -->

THANK YOU
