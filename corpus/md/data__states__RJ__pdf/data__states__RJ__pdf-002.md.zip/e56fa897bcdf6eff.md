---
doc_id: "e56fa897bcdf6eff"
source_url: "https://risl.rajasthan.gov.in/uploads/orders/fd557f43-6a71-4475-81e7-d508786aac5f.pdf"
ministry: "RajCOMP Info Services Limited, Rajasthan"
title: "Generic Technical Specifications ICT Items as on Dated 27-11-2024(Latest Version)"
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "3610fbf4d8207a57"
---

<!-- no text layer: pending OCR -->
