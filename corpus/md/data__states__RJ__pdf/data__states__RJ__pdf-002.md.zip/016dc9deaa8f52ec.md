---
doc_id: "016dc9deaa8f52ec"
source_url: "https://www.rsmm.com/filesrsmm/oo786-IPR.pdf"
ministry: "Rajasthan State Mines and Minerals Limited, Rajasthan"
title: "Office Order RSMM/CO/Pers/6(15)/2015/786 Dated 03.01.2025 Regarding Online Filling of Immovable Property Return (IPR) Through ERP by RSMML Employees"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4caa96e155d2fb97"
---

<!-- page 1 -->

~

-m.rR ~ Ji1~~ ~ fil1~Ri ~file\S
~~

~ ~ ifjf. i3tJifill)
:- 4, ifm iwf. ~ - 313 001

.

:-~-69-90, me! lli~ ~ ~. DN•Ut♦IOHlt'4tlGOJ0010S

~- ~

Phone : 0294·2428763-67, Fax : 0294-2428770/2428739
e-tMII :Iokw!a:aW'IAUAmm In Wtblttr. WWWDmNJID

sl>llfcl;:- 311i(Q'tiQ'1Q'1/°tfi31T/tm/6(15)/2015/ =,-8 6

~ : - 0 2 · 0 \ · o<D 2 5

-;tJfm:~:~li(Q'tiQ'1Q'1Qc1 ct W{ffl ~/4>4'tl1Rm &m 3J1Rf ~ ~ fcrcRur ffl

SSO-ID ~ 'c1PT ~ QR ERP ffilk~.!H 1t IPR MODULE &RT 31R-°c1$f ffl &RT ~
**~"qi
*~
~ ~
311i(Q-t1q11q11qc1 * ~ ~/cJ>4=q1RaY
sl>llfcl; "tl.13(76)~ /q,-1 /lJT."Sl./2021 /02463 ~ 30.12,2024 * 31jffi ~
cJ>T

ffl'q;R

t
t

Q1 ~ <tft ~ -q 3fCAT ~ ~ fcrcRur fR ufR cfiT WclUR f$m 7fm I
~ ~/4>4'tl1Ra1 cpl f.ls:.iifcba ~31Y ~
311i(Q'tiq11q11qc1
-q ~ ~3TT ~ ~ '<jf.i~'tlcl ffl I
~
~
fcll
~~~
~ cfli ~ ~ ~ q"{ ~ ~IWtl(?iJ(?•lqt'I cJi' Wffif
1.
~/<t>4=q1Ra1 &m cfli 2024 (01 ~ 2025 ~ ~ ) <fiT ~ ~ fcmur
Wei"@ IPR MODULE cpl
31 ~ 2025 "cl"cfi ~ ~ ~ 1ffl vfAT t_ 31 ~
~ Q R ~ \ilWTTI ~ rllG ~ ~ fcmur ~ 1ffl '1l'T ~ I
vlT ~ / ~ 3JtR ~ ~ ~ ~ ~
2. ~li((?'ti(?iJ(?iJ(?c1

t

t

t

*

~ ~ "tfilTT -q 3TR ~ ~ 1R11/~ ~ ffl, ~ ~ ~ - ~

qfror sfilTTcp q_13(1s) ~/cJi-1/lJT.~./2011 ~ 29.os.
(cf>-1/lll.~.) fcNrrr
~ ~ ~ fcnm ~
~ Fclftt<.% ~(1Q~ft -ml cft \:iITTlft ~ ffl
2021
~ ~ 19.01.2023 ~ iWlql~ ~
~ -q ~ ~
~ qG1"1R'1

*

~,

t

cf.a

*

*

.

*

Wffif ~ / 4>4il1Rlll. cfiT' SSO-ID ~ ERP
3. ~li((?ft(?iJ(?iJ(?t'I
f.ii(lcf>i(DI cf>
'tillfc~.!N a@ 3TR ~ IPR MODULE ~ "ll frl>"tfi ~ ~ ~ ~
uil-1cf>l.fl ~ ~ ~ ~ . ~ ~ (~.il.), cf>li(4)1~c cf>lllft'lll,
~ if

*

f<rn!o

~~~QR"ft'cl>cftl

*

"ft'lffif ~/ct>4iltRm· c p l ~ fcl>m \ill'clT t fit>
3lo: 311i(qqiiqiiqt'I
& ~ 3lT.fR ~ ~ SSO-ID ~ ERP ftl4'C~lli( IPR MODULE &Rf 3TR-°c1$f ffl

~ ~ -q ~ cITTI
\1'ITI ~ °'(1ef'i ~ ~ ~ qvqm \JJRt f$m '1l'T W

tI

,
siR'lfMci:I
31qc.flcJ>-11ef
1. r.ruft ~ . ~ ~ ~ ~ t

. -....-4\ rr:=fht. ~
2. ~ fll"IIScf>I( 311i((?fl(?'1(1'1(1l"I, °tfi.311. ~ I ~
~.,1'<1, ""'"'1'-,m,1
-qq
~
/
'{)l'N>C
~
/
c1l,'1"tCH
/
f~P-11,c
/
~
~
~
.
3
~ ~ ~ ~ e J . ct>~i(41~c ct,1afc1a, ~/3ITT31T ~/~/....,ct>1-t'l~cf>a=1
fit> 3JtR ~ ~/ct>4'tl1Rm cfTT
ctilllfc-tll cfTT f.14~11:Jflli( ~ -~

t

4.

f.J4ftro m sU ~ tUwfT '<jf.ltl-aa ffll
~ .ftxuf ~ . '31:l ~ (~:et). I

Signature

Digitally signed by
5. ~ ~/~~/~~~I
■ Designation xe
.
~ Date:
Reason: Appr
lil~

RIJKaj Ref No.: 12IOIS50

lid
