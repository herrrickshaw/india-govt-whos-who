---
doc_id: "abbda55b50637dfa"
source_url: "https://igprgvs.rajasthan.gov.in/writereaddata/Tenders/2025011512052372829846BPDPDPDP.pdf"
ministry: "Indira Gandhi Panchayati Raj and Gramin Vikas sansthan, Rajasthan"
title: "1.6 BPDP & DPDP.pdf"
date: ""
pages: 21
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5e345d9b45279fed"
---

<!-- page 1 -->

Data Driven Planning in the Preparation of
Block Panchayat Development Plan (BPDP)
using Secondary Data

Mr. Punit Sharma and Mr. Neeraj Jha

<!-- page 2 -->

Contents of the Presentation
 Data Driven Approach in Planning and its relevance
 Various Sources of Secondary Data available for Block Planning
 Census Data
 Socio-Economic Caste Census
 District Census Handbook
 District Hand Book of Statistics
 Mission Antyodaya
 Local Government Directory
 Spatial Planning
 GPDPs in the Preparation of BPDP
 Web-based Monitoring of data
 Data from Line Departments
 Data Consolidation

<!-- page 3 -->

Approach and Relevance of Data Driven Planning

Data Driven Approach
 To identify and address the real issues, the plan should be prepared using necessary and sufficient data

 The best available data, information and knowledge are used to make realistic decisions.
 It eliminates any biases and ensures transparency in planning

Relevance of Data Driven Planning
 Data driven approach helps in identification of specific needs of the block and address them
 Ensure proper coordination and avoid duplication of activities
 Monitor the performance of implementation

<!-- page 4 -->

Various Sources of Secondary Data available for BDPD Planning
Secondary data are quite essential while making situational analysis along with gap analysis and preparing
BPDP as a whole.
Some reliable sources of secondary data are:
 Census Data
 Socio-Economic Caste Census (SECC) Data
 District Census Handbook
 District Handbook of Statistics
 Mission Antyodaya
 Local Government Directory
 GIS Data

 eGramswaraj, Gram Manchitra, Bhuvan
 GDPDs of Panchayats in the Block
 Web based monitoring data
 Data from Line Departments
 Primary Data from GPs

<!-- page 5 -->

Census Data

 Most reliable source of secondary data
 Widely used by National and International Agencies, Scholars, business people, industrialists etc
 The data might be little outdated as it was collected in 2011 but still serve as a good reference to understand the
situation.
Types of Data Available
 Demography (Population characteristics)
 Economic Activity
 Literacy and Education
 Housing & Household Amenities
 Urbanisation
 Fertility and Mortality
 Scheduled Castes and Scheduled Tribes etc.
Using Census Data in BPDP Preparation
 Baselining of existing situation
 Situational analysis along with gap analysis
 Census Data is as good as primary data for situational assessment of Block panchayat

<!-- page 6 -->

Socio-Economic Caste Census data

 Conducted for the first time in 2011.
 Socio Economic Caste Census is a study of socio-economic status of rural and urban households
 It focused on Caste based census of socio-economic situation.
Types of Data Available
 Education profile
 Employment & Income, source of income, land ownership
 Asset Ownership, Types of Household, Housing dwelling wall type, Housing dwelling roof type
 Gender Profile
 Disability profile
 Caste Profile
 Details of highly vulnerable sections like PTG (Primitive Tribal Group), LRBL (Legally Released Bonded
Labor), MS (Manual Scavenger)
Using SECC Data in BPDP Preparation
 Baselining of existing situation especially caste-wise
 Situational analysis along with gap analysis
 Useful in identification of the status of vulnerable groups and enable welfare planning

<!-- page 7 -->

District Census Handbook
 District Census Handbook is published decennially i.e. every 10 years
 Contains both Census and non-Census data of urban and rural areas for each District
 It has two parts: Part –A and Part – B.
 Part – A contains Village and Town Directory, Block level Maps showing village boundary, Census, Non-Census
Concepts, Analytical Note on Census findings.
 Part – B contains Important Statistics of the District, Brief note of Primary Census Abstract, Appendix to District
Primary Census Abstract i.e., Urban block wise figures of Total, SC & ST Population, Rural PCA, Urban PCA,
Housing Amenities etc. Additionally, it contains, district and Sub-district (Block) maps depicting villages/towns with
population size
Types of Data Available
 Abstract of Census Demographic data
 Block Level (Sub district) Maps with village boundaries
 Details of village wise educational infrastructure (Primary, Middle and Secondary Schools)
 Details of village wise Drinking Water Sources in the district
 Details of village wise educational, medical, Water and Sanitation, Communication, Transport, Banking, Power
supply and other amenities
Using District Census Handbook in BPDP Preparation
 Data like list of villages where there are no amenities other than drinking water facility is organised at Block level.
This data will be highly useful in prioritisation of the activities.
 The data available in DCHB may be up to date but will serve as a base line in assessing the efficacy of the plan

<!-- page 8 -->

District Hand Book of Statistics
 Published by the office of Chief Planning and Statistics office at district level and Department of Planning and
Statistics in most of the States.
 Provides the factual information on the status of socio-economic indicators across various sectors in the districts.
 District Hand book of Statistics is being prepared to serve the data needs of decentralised planning needs. Hence it is
highly relevant to BPDP preparation.
Types of Data Available :
 Details of Population
 Details of Public Health Facilities
 Details of Agriculture including land utilisation, block wise land holdings etc
 Details of Livestock, Fisheries and Veterinary services
 Details of Irrigation
 Details of Forestry including MFP (Minor Forest Produce)
 Details regarding Employment, Labour and Labour welfare
 Social Welfare including Scholarships, Hostel Facilities for SC/STs etc.
 Women and Child Welfare
Using District Hand Book of Statistics in BPDP Preparation
 To access the agricultural , irrigation and public health status while making situational analysis.
 The data may be used in prioritising/finalising of activities related to social justice which is a sign of quality plan.

<!-- page 9 -->

Mission Antyodaya

 It is a convergence and accountability framework aiming to bring optimum use and management of
resources.
 It was adopted in Union Budget 2017-18
 It is envisaged as a state-led initiative with Gram Panchayats as focal points of convergence efforts

Types of Data Available
 MA Survey format covers 29 subjects with 143 parameters
 MA provides general reports, sector specific reports, GAP reports and Programme specific reports.
 Data can be accessed GP-wise, village-wise which will help in getting comprehensive picture of the
situation of the area

Using Mission Antyodaya in BPDP Preparation
 Extremely useful for conducting Situation Analysis and preparation of Development Status Report.
 To conduct GAP analysis of any sector.

<!-- page 10 -->

Local Government Directory

 Local Government Directory (LGD) is one of the applications developed as part of Panchayat Enterprise Suite (PES)
under e-Panchayat Mission Mode project (MMP).
 LGD aims to keep all information about the structure of Local Governments and revenue entities online.

Types of Data Available
 Generates unique codes for each local government body
 Local body wise wards list as well as Parliament and Assembly Constituencies and their mapping with local
governments can be maintained through LGD

Using LGD in BPDP Preparation
 Unique code for respective village
 All the GPDPs are mapped with this unique code only

<!-- page 11 -->

Spatial Planning


Spatial planning systems refer to the methods and approaches used to influence the distribution of people, connectivity
and activities in spaces of various scales.



It helps in coordinating practices and policies affecting land use, urban, regional, transport and environmental planning,
including the economic and community planning, and takes place on local, regional and national levels.



Spatial planning is an important aspect of any planned development.



The rural areas are devoid of planned spatial development.



The absence of planned spatial development in rural areas has major impact on regional development



Using spatial planning in local self-governance can ensure openness and accountability in the functioning of GPs.



Geographic information system (GIS) is used for Spatial planning

<!-- page 12 -->

Geographic information system (GIS) based Planning
 Geographic information system (GIS) based planning brings more accountability and transparency to the process of
formulation of plan.
 GIS enables the user to take better decisions based on geographical data.
 Non-availability of information in a spatial manner at the local level renders the information difficult to grasp and
understand which leads to adhocism in prioritisation of schemes / programmes, poor decision-making, slow process of
making corrections during implementation and narrow participation of people in the process.
 With the aid of GIS and satellite imagery, a detailed visual record of the projects can be maintained, which can be accessed
any time.
Benefits of GIS planning
Decision support system: Support in developmental planning and execution of planned activities.
Viewing and Analysis of Plan: Queries and analysis of the plan could be seen on thematic maps. It is useful in ensuring
convergence of various activities and in knowing all the works that are being taken up in a certain geographic area.
Performance Analysis: Performances of all GPs based on selected indicators across each district / block wise can be
visualised on thematic maps.
Management Dashboard: A GIS based management dashboard to provide senior management with the status of ongoing
plans/schemes.
Enhanced citizen engagement: Most of the two way interaction with citizens may move to mobile channels resulting in less
load on manpower intensive over-the counter service delivery.
Utilization of Resources and Infrastructure: Provide cost effective solution for utilization of resources and maximize the
benefits.

<!-- page 13 -->

Accessing Geographic information system (GIS) Data
Following are the sources for collection of GIS Data for the planning:
Gram Manchitra
MoPR has launched ‘Gram Manchitra’, a Spatial Planning Application developed by the National Informatics
Centre (NIC). It is a Geo Spatial based decision support system for the panchayats. The panchayats can utilize
this application to plan, develop and monitor developmental activities on real time basis
Bhuvan Panchayat platform
Bhuvan Panchayat Portal is developed and hosted by NRSC (ISRO). Bhuvan Panchayat platform brings spatial
planning deeply embedded in governance systems at all the three tiers of Panchayati Raj.
Type of Data on Bhuvan Panchayat Portal

Thematic data: Overlaid on the base layer, various thematic layers (such as land cover, drainage, transportation
and slope layers) are prepared at 1:10,000 scale for the entire country.
Legacy data: Soil information layer, groundwater potential, forest boundary, watershed boundary, wasteland
information and slope class layer.
Cadastral data: Prepared at 1:4000 scale for five priority States
Administrative boundaries: Village, Panchayat, Intermediate Panchayat, District, State, Parliamentary and
Assembly Constituency
Asset Data: A continuously growing national inventory of geo-tagged community assets along with their
photographs and related attributes is available on the Portal for its utilization in developmental planning.
Non-spatial data: In addition to the geospatial layers, the project database comprises village amenities,
demographic and climatic data integrated with spatial database.

<!-- page 14 -->

Using GIS Data in the Preparation of BPDP
GIS data sources can be used to


To find out the location for projects.



To find connectivity with road or all-weather road.



To locate actual length of road.



To formulate perspective plan on focus areas.



To create Online repository of spatial data for planning purpose.

Spatial consolidation of plans


Framework of spatial strategic planning should be interlinked at all the three tiers of Panchayati Raj.



Bhuvan Panchayat provides a platform for such spatial consolidation and interlinking.



Spatial planning when integrated with the sectoral planning is called as ‘spatial strategy’.



Spatial planning has the power of integration with individual sectoral plans.

<!-- page 15 -->

GPDPs in the Preparation of BPDP
An important aspect for preparing BPDP at the Block Panchayat level is to ensure that the GPDPs are consolidated at the
block level for identifying developmental needs and planning activities to address these needs
Types of Data Available
GPs Sector wise planned outlay will be available such as  Administrative &Technical Support
 Agriculture
 Animal husbandry
 Drinking water
 Fisheries and Health
Using GPDP in BPDP Preparation
 One of the important tasks of the BPCC and SWG (GPCC) member is to collect the detailed GPDPs from the
respective Gram panchayats in the block to identify the common development needs which can not be met through
GPDP.
 The BPCC would then review GPDPs for Identifying and Prioritising developmental needs of the all GPs in the
respective area .
 One of the important points to remember is members of BPCC and SWG should collect the detailed GPDPs not
abstract available in eGramSwaraj portal for ensuring quality BPDP

<!-- page 16 -->

Web-based Monitoring of data

 Represents not only a public image of a particular region, but also a reliable service platform for many users from
local citizens and beyond
 An independent server that serves as a 24/7 watch-guard to monitor the plan of Block Panchayat and District
panchayat
 GPMS (Gram Panchayat Management System) is a part of the e-Governance initiatives of the Panchayats & Rural
Development Department of the Government of West Bengal
 The prime focus of the software is to STANDARDIZE THE ACCOUNTING SYSTEM of the PRIs and to make
account keeping easy, transparent and comfortable to the users.
 Not many States/UTs are having this kind of system wherever such system is available it advised to utilise such realtime data in planning.

<!-- page 17 -->

Data from Line Departments

 Line departments are those who implement various schemes and programmes of the government at Gram Panchayat,
Block Panchayat and District Panchayat level
 Line departments should have the first hand and updated information regarding the status of development at Block level.
Types of Data Available
 Education (DISE)
 Health (HMIS)
 Agricultural Department (Agricultural Statistics at a Glance)
 Most of the departments has a publication of granular statistics which can be used for planning.
Using Line Departments Data in BPDP Preparation
 The latest line departments data is extremely useful in preparation of BPDP and members of IPPC and SWG should
strive for getting the data from line departments.
 For making situational analysis and minimising the sectoral gap.

<!-- page 18 -->

Consolidation of Data
 Data consolidation means combining the various data into a single and more effective representation which can give us a
clear picture of the developmental status of a block.
 The critical and most vital aspect before preparing the BPDP
 Secondary data sources are more in number and which one is to taken into consideration is the main issue
 For example if members of BPDP need to finalise an intervention increasing literacy rate and come across the below
sources:
Data
Source

MA (2020)

SECC
(2011)

CENSUS
(2011)

District Statistics
Hand Book (2019)

Literacy
rate

70%

65%

60%

75%

 Refer most recent data (In this case MA Data).
 Compare with any line department or official data (In this case District Statistics Hand Book).
 If there is no such discrepancy or any negligible discrepancy then consider the latest data.
 If there is a huge discrepancy, consider the line department data or other widely accepted authentic data (In this case
District Statistics Handbook, 2019)

<!-- page 19 -->

Using Multiple Data Sources for Planning

There are multiple data points and multiple data sources are available at the disposal of the members of

BPCC and SWG.
The anchor person/core group who is handling the data collection, consolidation and planning should analyse
all possible combinations and prepare a realistic plan reflecting the pressing needs of the area.
For understanding purpose, it is suggested to go through the below example:
From Census data , it is possible to get data on literacy rate, no. of school dropouts, mortality rate in a block

From Mission Antyodaya data , it is possible to get data on Employment and Income of the same block
From SECC, it is possible to get data on caste profile.

<!-- page 20 -->

Using Primary Data of GPs in BPDP
 There is no need for Intermediate Panchayats to collect Primary Data from all the GPs in the block except in few needbased scenarios like pandemic, impact analysis of any new initiative in more than one GP etc.
 Primary Data collected by GPs in preparation of GPDP can be consolidated at Block level. This type of data is rich in
terms of quality and reflects the exact scenario on the ground.

ZP
BP

GP
Ward/Neighborhood
(Primary Data collection)
Fig. Flow of Primary Data

<!-- page 21 -->

THANK YOU
