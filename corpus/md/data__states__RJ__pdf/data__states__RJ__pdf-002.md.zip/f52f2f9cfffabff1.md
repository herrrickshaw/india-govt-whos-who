---
doc_id: "f52f2f9cfffabff1"
source_url: "https://cdn.jagannathuniversity.org/docs/about/aicte-approval.pdf"
ministry: "Jagannath University, Rajasthan"
title: "View AICTE notification"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "e49e60b032471f0b"
---

<!-- page 1 -->

Set, ALL INDIA COUNCIL FOR TECHNICAL EDUCATION
० अहम (A STATUTORY BODY OF GOVERNMENT OF INDIA)
९७ A. 7" FLOOR, CHANDERLOK BUILDING, JANPATH,
*'
NEW DELHI - 440 904 Ph. : 23724454-57
Advt. No. : UB/04(03)/200
PUBLIC NOTICE

Ithas come to the notice of All India Council for Technical Education (AICTE) thata

number of the institutions are offering technical education programmes on their

campuses/rented premises in franchise mode and/or in collaboration with some
universities. in this regard following is clarified for the benefit of institutions
involved in such activities as well as the students enrolled therein

(i) Aspersection 2 (g) of AICTE Act, 987 “technical education is defined as under:-
“technical education” means programmes of education. research and |

| training in engineering, technology, architecture, town planning,

| management, pharmacy and applied arts and crafts and such other
programme or areas as the Central Government may, in consultation with
the Council, by notification in the Official Gazette, declare

(ii) As persection 2 (h) of AICTE “technical institutions” are defined as under:-
“technical institution” means an institution. not being a University which
offers courses or programmes of technical education, and shall include such
other institutions as the Central Government may, in consultation with the
Council, by notification in the Official Gazette, deciare as technical
institutions;

(ili) As per section 70 (k) of AICTE Act read with regulations framed by AICTE in
exercising its powers confined under section 23 of AICTE Act, technical
institution offering technical education programmes are required to seek
prior approval of AICTE.

(iv) The Hon'ble Supreme Court of India in case of Bharathidasan University &
Another Vs AICTE & Others has interpreted the provisions of the AICTE Act
and has held that although university do not require prior approval of AICTE
to commence a new department or course and programmes in technical
education, however, universities have obligation or duty to conform to the
standards; and norms laid down by the AICTE. For the purpose of ensuring
coordinated and integrated development of technical education and
maintenance of standards, AICTE may cause an inspection of the university,

| which has to be as per the provisions under relevant rules/regulations of the
AICTE. Further, all institutions running technical education programmes in

| collaboration with any university requires prior approval of AICTE

| v) With regard to the above, ali the institutions offering technical education

i programmes in affiliation/collaboration with or any university inanyform _
are advised to seek the prior approval/approval of AICTE, otherwise the
technical education programmes offered through such institutions shall _

| be notified as unapproved programmes.

THE PERSONS PURSUING THEIR TECHNICAL EDUCATION WITH THE

INSTITUTIONS OR ASPIRING TO TAKE ADMISSION IN INSTITUTIONS FOR

TECHNICAL EDUCATION ARE HEREBY ADVISED TO ENSURE ABOUT THE

STATUS OF APPROVAL OF THE INSTITUTION AND/OR PROGRAMME

CONCERNED.

Member Secretary
