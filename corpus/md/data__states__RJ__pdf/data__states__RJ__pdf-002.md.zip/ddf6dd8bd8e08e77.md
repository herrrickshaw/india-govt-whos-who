---
doc_id: "ddf6dd8bd8e08e77"
source_url: "https://forest.rajasthan.gov.in/content/dam/raj/forest/ForestDepartment/PDFs/Department%20Wing/CAMPA/BUDGET/Budget%20Allotment%20order%20no.%2026%20%20(23.09.2026).pdf"
ministry: "Forest Department, Rajasthan"
title: "Budget Allotment order no. 26"
date: ""
pages: 4
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "a3be943d8992abde"
---

<!-- page 1 -->

कायालय राज थान

तकरा मक वनरोपण न ध बंधन और योजना ा धकरण
राज. जयपुर

मांकः एफ.14()कै पा/अ मुवसं/लेखा/ब.आ./ 00026

दनांक: 23­09­2026

बजट आवंटन आदेश ­ 00026
वष 2026­27 क वीकृत वा षक काय योजना के मद सं या ­ 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (i)
Reforestation of Degraded Forests­II (RDF­II),14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (ii) Send
Dunes Stabilization (SDS) for IGNP Area,14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iii) a) Block
Plantation (BP) for IGNP Areas,14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iii) b) Block Plantation (BP)
for Non­IGNP Areas,14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iv) a) Canal Side Plantation
(Distributary (CSP (D) for IGNP Areas,14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iv) a) Canal Side
Plantation (Distributary) {CSP(M)} for IGNP Areas , (ii) Planting year (Ist year Maintenance), (iii) IInd year Maintenance ,
(iv) IIIrd year Maintenance , (v) IVth year Maintenance , (iii)1st year Maintenance, (iv)2nd year Maintenance, (v) IIIrd year
Maintenance, (iii) Ist year Maintenance , (iv) IInd year Maintenance , (v) IIIrd year Maintenance , (iv) IInd year Maintenance ,
(v) IIIrd year Maintenance , (ii) Planting year , (iii) Ist year Maintenance , (iv) IInd year Maintenance , (v) IIIrd year
Maintenance , (ii) Planting year , (iii) Ist year Maintenance , (iv) IIrd year Maintenance , (v) IIIrd year Maintenance आवं टत
काय को पूण कराने हेतु अ धन थ वन म डल/वन म डल को IFMS के मा यम से न नानुसार बजट मद म बजट आवंटन कया
जाकर यय करने क वीकृ त दान क जाती है : Budget Head Name ­ 2406­04­103­04­01­12
Budget Description 2406­ Forest & wildlife
04­Afforestation and Ecology Development
103­ State Compensatory Afforestation (SCA)
(04)­ Net Present value of forest land
(01)­ Compensatory Afforestation
12 ­ Grant in Aid (Other than Salary)

Budget Allocation Type ­ Normal Allocation
Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (i) Reforestation of Degraded Forests­II (RDF­II)
Activity Name : (ii) Planting year (Ist year Maintenance)
S.No.

Division Name

Budget Head Name

Physical Target (ha)

Financial Target(Lacs) (0.15906)

1

DCF JHALAWAR

2406­04­103­04­01­12

165.00000

26.24490

2

DCF JHUNJHUNU

2406­04­103­04­01­12

50.00000

7.95300

3

DCF KOTA

2406­04­103­04­01­12

100.00000

15.90600

4

DCF PRATAPGARH

2406­04­103­04­01­12

150.00000

23.85900

465.00000

73.96290

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (i) Reforestation of Degraded Forests­II (RDF­II)
Activity Name : (iii) IInd year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (ha)

Financial Target(Lacs) (0.04596)

1

DCF BARAN

2406­04­103­04­01­12

50.00000

2.29800

2

DCF JHALAWAR

2406­04­103­04­01­12

100.00000

4.59600

3

DCF JODHPUR

2406­04­103­04­01­12

50.00000

2.29800

4

DCF SIKAR

2406­04­103­04­01­12

100.00000

4.59600

300.00000

13.78800

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (i) Reforestation of Degraded Forests­II (RDF­II)
Activity Name : (iv) IIIrd year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (ha)

Financial Target(Lacs) (0.02432)

1

DCF JHUNJHUNU

2406­04­103­04­01­12

400.00000

9.72800

2

DCF NAGAUR

2406­04­103­04­01­12

200.00000

4.86400

600.00000

14.59200

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (i) Reforestation of Degraded Forests­II (RDF­II)
Activity Name : (v) IVth year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (ha)

1

DCF BHARATPUR

2406­04­103­04­01­12

100.00000

2

DCF JHALAWAR

2406­04­103­04­01­12

3

DCF JHUNJHUNU

2406­04­103­04­01­12

4

DCF NAGAUR

2406­04­103­04­01­12
Total :

Financial Target(Lacs) (0.02438)

Digitally signed2.43800
by T.J. KAVITHA
Designation: APCCF
100.00000
2.43800
Date: 2026-09-23 17:42:20 IST
400.00000
9.75200
Location: HQ Office
400.00000

9.75200

1000.00000

24.38000

v-2.1

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (ii) Send Dunes Stabilization (SDS) for IGNP Area
Activity Name : (iii)1st year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (ha)

Financial Target(Lacs) (0.36875)

<!-- page 2 -->

Total :

1000.00000

24.38000

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (ii) Send Dunes Stabilization (SDS) for IGNP Area
Activity Name : (iii)1st year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (ha)

Financial Target(Lacs) (0.36875)

1

DCF HANUMANGARH

2406­04­103­04­01­12

50.00000

18.43750

2

DCF IGNP ST II BIKANER

2406­04­103­04­01­12

25.00000

9.21875

3

DCF IGNP STAGE­I CHHATTARGARH

2406­04­103­04­01­12

100.00000

36.87500

175.00000

64.53125

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (ii) Send Dunes Stabilization (SDS) for IGNP Area
Activity Name : (iv)2nd year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (ha)

Financial Target(Lacs) (0.07808)

1

DCF IGNP STAGE­I CHHATTARGARH

2406­04­103­04­01­12

100.00000

7.80800

2

DCF SRIGANGANAGAR

2406­04­103­04­01­12

500.00000

39.04000

600.00000

46.84800

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (ii) Send Dunes Stabilization (SDS) for IGNP Area
Activity Name : (v) IIIrd year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (ha)

Financial Target(Lacs) (0.03855)

1

DCF HANUMANGARH

2406­04­103­04­01­12

100.00000

3.85500

2

DCF IGNP STAGE­I CHHATTARGARH

2406­04­103­04­01­12

400.00000

15.42000

3

DCF SRIGANGANAGAR

2406­04­103­04­01­12

500.00000

19.27500

1000.00000

38.55000

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iii) a) Block Plantation (BP) for IGNP Areas
Activity Name : (iii) Ist year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (ha)

Financial Target(Lacs) (0.38008)

1

DCF HANUMANGARH

2406­04­103­04­01­12

100.00000

38.00800

2

DCF IGNP ST II JAISALMER

2406­04­103­04­01­12

100.00000

38.00800

200.00000

76.01600

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iii) a) Block Plantation (BP) for IGNP Areas
Activity Name : (iv) IInd year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (ha)

Financial Target(Lacs) (0.29342)

1

DCF HANUMANGARH

2406­04­103­04­01­12

100.00000

29.34200

2

DCF SRIGANGANAGAR

2406­04­103­04­01­12

125.00000

36.67750

225.00000

66.01950

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iii) a) Block Plantation (BP) for IGNP Areas
Activity Name : (v) IIIrd year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (ha)

Financial Target(Lacs) (0.25794)

1

DCF HANUMANGARH

2406­04­103­04­01­12

195.00000

50.29830

2

DCF SRIGANGANAGAR

2406­04­103­04­01­12

100.00000

25.79400

295.00000

76.09230

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iii) b) Block Plantation (BP) for Non­IGNP Areas
Activity Name : (iv) IInd year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (ha)

Financial Target(Lacs) (0.11162)

1

DCF & DY. FD­I RANTHAMBHOR TP SAWAIMADHOPUR

2406­04­103­04­01­12

100.00000

11.16200

2

DCF CHURU

2406­04­103­04­01­12

50.00000

5.58100

3

DCF JAISALMER

2406­04­103­04­01­12

200.00000

22.32400

4

DCF JHALAWAR

2406­04­103­04­01­12

100.00000

11.16200

5

DCF WL CHITTORGARH

2406­04­103­04­01­12

50.00000

5.58100

500.00000

55.81000

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iii) b) Block Plantation (BP) for Non­IGNP Areas
Activity Name : (v) IIIrd year Maintenance
S.No.

Division Name

1

DCF JAISALMER

Budget Head Name

Physical Target (ha)

Financial Target(Lacs) (0.06216)

2406­04­103­04­01­12

120.00000

7.45920

Digitally signed7.45920
by T.J. KAVITHA
120.00000

Total :

S.No.

Division Name

Budget Head Name

Designation: APCCF
Date: 2026-09-23 17:42:20 IST
Location: HQ Office
Physical Target (RKM)
Financial Target(Lacs) (0.15591)

1

DCF IGNP ST II JAISALMER

2406­04­103­04­01­12

500.00000

77.95500

500.00000

77.95500

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iv) a) Canal Side Plantation (Distributary (CSP (D) for IGNP Areas
Activity Name : (ii) Planting year

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iv) a) Canal Side Plantation (Distributary (CSP (D) for IGNP Areas
Activity Name : (iii) Ist year Maintenance

v-2.1

<!-- page 3 -->

1

DCF IGNP ST II JAISALMER

2406­04­103­04­01­12
Total :

500.00000

77.95500

500.00000

77.95500

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iv) a) Canal Side Plantation (Distributary (CSP (D) for IGNP Areas
Activity Name : (iii) Ist year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (RKM)

Financial Target(Lacs) (0.10511)

1

DCF IGNP ST II JAISALMER

2406­04­103­04­01­12

50.00000

5.25550

2

DCF IGNP STAGE­I CHHATTARGARH

2406­04­103­04­01­12

100.00000

10.51100

150.00000

15.76650

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iv) a) Canal Side Plantation (Distributary (CSP (D) for IGNP Areas
Activity Name : (iv) IInd year Maintenance
S.No.

Division Name

1

DCF IGNP ST II JAISALMER

Budget Head Name

Physical Target (RKM)

Financial Target(Lacs) (0.08547)

2406­04­103­04­01­12

100.00000

8.54700

100.00000

8.54700

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iv) a) Canal Side Plantation (Distributary (CSP (D) for IGNP Areas
Activity Name : (v) IIIrd year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (RKM)

Financial Target(Lacs) (0.06325)

1

DCF SRIGANGANAGAR

2406­04­103­04­01­12

100.00000

6.32500

100.00000

6.32500

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iv) a) Canal Side Plantation (Distributary) {CSP(M)} for IGNP Areas
Activity Name : (ii) Planting year
S.No.

Division Name

1

DCF IGNP ST II JAISALMER

Budget Head Name

Physical Target (RKM)

Financial Target(Lacs) (0.16193)

2406­04­103­04­01­12

500.00000

80.96500

500.00000

80.96500

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iv) a) Canal Side Plantation (Distributary) {CSP(M)} for IGNP Areas
Activity Name : (iii) Ist year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (RKM)

Financial Target(Lacs) (0.11355)

1

DCF SRIGANGANAGAR

2406­04­103­04­01­12

30.00000

3.40650

30.00000

3.40650

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iv) a) Canal Side Plantation (Distributary) {CSP(M)} for IGNP Areas
Activity Name : (iv) IIrd year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (RKM)

Financial Target(Lacs) (0.09442)

1

DCF IGNP ST II JAISALMER

2406­04­103­04­01­12

100.00000

9.44200

100.00000

9.44200

Total :

Item Name : 14­ Artificial Regeneration (AR) {Other than ANR/NFL/DFL} : (iv) a) Canal Side Plantation (Distributary) {CSP(M)} for IGNP Areas
Activity Name : (v) IIIrd year Maintenance
S.No.

Division Name

Budget Head Name

Physical Target (RKM)

Financial Target(Lacs) (0.07254)

1

DCF SRIGANGANAGAR

2406­04­103­04­01­12

200.00000

14.50800

200.00000

14.50800

Total :

सामा य शत :1. इस कायालय े प
जाना सु नि चत हो।

मांकएफ.14( )कै पा/अ मुवसं/बजट आवंटन/2025­26/rajkaj no 15445191 दनांक 21.05.2025 म व णत शत क अन ुपालना कया

2. उप वन संर क बजट आबंटन करने से पूव व ृ रोपण क जी वत

तशतता अन ुसार ह यय होना सु न‘चत करे।

3. कै पा मद के अंतगत आवं टत काय ार भ करने से पूव संबं धत ाम सभा /VPFMC /EDC से सहम त ा त कर ह काय ार भ करवाना सु नि चत कर।
4. आवं टत बजट का यय कै पा (Guidelines o Compensatory Afforestation Fund Act and 2016 (CAF act) तथा Compensatory Afforestation Fund
Rules, 2018 ( CAF rules ) . ावधान के अंतगत कया जावे।
5. आवं टत बजट से कसी भी प रि थ त म अ धक यय नह ं कया जावे।
6. उ त आवंटन के व

ध य द कसी रा श का उपयोग संभव नह हो तो रा श शी इस कायालय को मय औ च य सम पत कर द जावे।

7. आवं टत बजट क रा श का आहरण केवल तभी कया जाये जब वीेकृत काय से स बि धत यय का भ ुगतान कया जाना हो यो क टेट के पा का अकाउ ट
याज बय रंग ह।

Digitally signed by T.J. KAVITHA
Designation:
APCCF
8. आवं टत रा श िजस उ वे य / काय के लए आवं टत क गई है उसी उ देशय / काय के लए नयमान ुसार ह
यय क जावे
तथा इसम से कसी भी तरह का
शास नक यय सि म लत नह ं कया जावे।
Date: 2026-09-23 17:42:20 IST
Location: HQ Office
9. बजट उपयोग के संबंध म समय पर इस कायालय रा य सरकार वारा सा रत सम त नदश क पालना क जावे।
10. कै पा के आवं टत बजट उ ह ं काय पर यय संपा दत कया जाव जहां अ य योजनाओं के इसी कार के काय
Overlapping से बचा जा सक ।

ता वत नह हो, िजससे योजनाओं म पर पर
v-2.1

11. काय को ार भ करने से पूव ा कलन क वीकृ त नयमान ुसार स म तर से जार क जावे। सम त काय के लेखा एव अ य रकॉड (Manual of
Guidelines and Accounting procedures relating to State CAMPA/ IFMS accounting rules) एव सामा य व ीय एव लेखा नयम के अन ु प कै पा का लेखा

<!-- page 4 -->

9. बजट उपयोग के संबंध म समय पर इस कायालय रा य सरकार वारा सा रत सम त नदश क पालना क जावे।
10. कै पा के आवं टत बजट उ ह ं काय पर यय संपा दत कया जाव जहां अ य योजनाओं के इसी कार के काय
Overlapping से बचा जा सक ।

ता वत नह हो, िजससे योजनाओं म पर पर

11. काय को ार भ करने से पूव ा कलन क वीकृ त नयमान ुसार स म तर से जार क जावे। सम त काय के लेखा एव अ य रकॉड (Manual of
Guidelines and Accounting procedures relating to State CAMPA/ IFMS accounting rules) एव सामा य व ीय एव लेखा नयम के अन ु प कै पा का लेखा
काप रेट एकाउं टंग के आधार पर सीएजी वारा े षत प म संधा रत कर। लेख के आ डट महालेखाकार वारा क जावेगी।
12. उप वन संर क यह सु नि चत करे क नधा रत मापदंड के अन ुसार जी वतता तशतता तथा िजन व ृ ारोपण म जी वत तशतता नधा रत मापद ड से कम
है उसमे धान मु य वन संर क राज थान प रप एफ 7 (24) 02 ­03 / ववर ाका / मुवसं / 10401 दनांक 31.3.2004 क पालना सु नि चत करे |
13. संबं धत मु य वन संर क उनके अधीन वन म डल से 5 तार ख तक लेखा ा त करना सु नि चत करगे एवं येक माह क 10 तार ख तक सम त वन
म डल के लेखे संक लत कर भौ तक एवं व ीय ग त तवेदन नधा रत प म अधोह ता रकता को भेजना स ु नि चत करगे तथा कै पा अंतगत कराये जा
रहे काय के रिज टर का साधारण कायालय मु य वन संर क तर पर भी कराया जावे।
14. कै पा मद म साम ी य क कायवाह राज. लोक उपापन म पारद शता अ ध नयम, 2012 एवं नयम, 2013 के ावधान के ह तहत क जावेगी तथा
गई साम ी का इ ाज वभागीय टोर पंिजका म कया जाव एवम् वभाग क च लत ध त अन ुसार लेखा­जोखा रखा जावेगा।
15. सम त उप वन संर कगण काय पण
ू होने उपरा त उपयो गता/काय पण
ू ता माण प राज थान कै पा को व ीय वष के अ त म
सु नि चत करगे।

यक

तत
ु कया जाना

16. Budget must be utilised fot the items in the financial year 2026­27.
17. सामा य व एवं लेखा नयम क SOP व समय­समय पर जार प रप
करगे |

के अन ुसार दत व ीय शि तय के अनुसार ह काय संपादन कया जाना सु नि चत

18. वीकृत APO के
या वयन से पूव संब ं धत उप वन संर क वारा रा य CAMPA को माण­प
तुत कया जाए क ता वत ग त व धयाँ ाम सभा से
समु चत परामश के उपरांत तथा वन अ धकार अ ध नयम, 2006, वीकृत काय योजना एवं संबं धत बंधन योजनाओं के अन ु प ह।
19. तपूरक वनीकरण एवं अ य थल­ व श ट काय केवल भारत सरकार वारा वन भ ू म के
भौगो लक नदशांक के अन ुसार ह कए जाएँ।

यावतन हेतु वीकृत थल पर तथा वीकृत KML/Shape File/

20. वनीकरण काय म पा रि थ तक पुन थापन को ाथ मकता देते हुए थानीय/देशज जा तय का उपयोग कया जाए तथा एकल जा त (Monoculture) एवं
गैर­देशज जा तय के रोपण से बचा जाए।
21. तपूरक वनीकरण, अ त र त व ृ ारोपण एवं ANR आ द काय क KML फाइल e­Green Watch पर अपलोड क जाएँ तथा भारतीय वन सव ण (FSI),
दे हराद ून एवं National CAMPA Digital APO Portal पर भी अपलोड क जाएँ।
22. व ृ ारोपण थल का नय मत अन ु वण एवं मू यांकन कया जाए, ता क पौध क अ धकतम उ रजी वता एवं अपे
23. CAMPA के अंतगत कए जाने वाले सभी काय /ग त व धय म मजद ूर का भुगतान केवल

य

त व ृ ध सु नि चत क जा सके।

लाभ अंतरण (DBT) के मा यम से कया जाए।

Digitally signed by T.J. KAVITHA
Designation: APCCF
Date: 2026-09-23 17:42:20 IST
Location: HQ Office
v-2.1
