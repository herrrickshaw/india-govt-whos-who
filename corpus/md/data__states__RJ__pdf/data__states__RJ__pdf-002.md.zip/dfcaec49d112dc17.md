---
doc_id: "dfcaec49d112dc17"
source_url: "https://excise.rajasthan.gov.in/Uploads/Amendment-Rajasthan%20Excise%20Subordinate%20Service.pdf"
ministry: "Excise Department, Rajasthan"
title: "Rajasthan Excise Subordinate Service (General Branch)(Amendment) Rules, 2017"
date: ""
pages: 3
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "a950288d0be1b720"
---

<!-- page 1 -->

GOVERNMENT OF RAJASTHAN :
DEPARTMENT OF PERSONNEL .
(AG. ;

No. F.2(2)DOP/A-2/93 . Jaipur, dated: 25-0} 2०07
NOTIFICATION |

In exercise of the powers conferred by the proviso to Articles 309 jof the Constitution of
India, the Governor of Rajasthan hereby makes the following rules further tp amend the Rajasthan
Excise Subordinate Service (General Branch) Rules, 974, namely:-

I. Short title and commencement.- (l) These rules may be called the Rajasthan Excise
Subordinate Service (General Branch)(Amendment) Rules, 207.

(2) They shall come into force with immediate effect.

2. Amendment of rule 6.- The existing proviso to clause (a) of sub-rule () of rule 6 of
the Rajasthan Excise Subordinate Service (General Branch) Rules, 974, hereinafter referred to as
the said rules, shall be deleted. हि

3. Amendment of १3.- In rule 3 of said rules,-

(i) the existing provision shall be numbered as sub-rule (); and
(ii) after the sub-rule (l), so numbered, the following new sub-rule (2) shall be
added, namely:- हे

"(2) Notwithstanding any thing contained in sub-rule () a candidatd for direct recruitment

to the post of Excise Guard Grade II must have the following rhinimum standards of

physical fitness, namely:- “ : :
lo

_

Chest 8icms. Not applicable 74 cm: _ Not
(Expansion minimum (Expansion mii ~~ m applicable
5 cms. cms.

Candidates belonging to the Scheduled Castes and Scheduled Trikqs whose height and
: chest measurement are less by 5 cms. shall be deemed to be physically fit in case of
requisite number of: suitable Scheduled Castes or Scheduled Tribes, as the case may
be, candidates possessing physical fitness standards as laid dawn above are not

available. | !

But in case of candidates belonging to Assamese, Bhutanese, Garhwalis, Gorkhas,

- Kumaonis, Ladkhese, Mizo, Naga, Nepalese, Sikkimese races and jthose from Arunachal

Pradesh, Lahul and Spiti, Meghalaya the following relaxed standardg shall apply:-

(yu. utd after ta appv doe : :

<!-- page 2 -->

। :
; |
ह | लक 7 7] छत 7-7!
ee |+$

Candidates failing to fulfill the above specified standards af height/chest/weight

measurements shall be rejected." :

4. Substitution of rule 9,- The existing rule 9 of the said tules, shall be substituted by
the following, namely:-

"I9. Scrutiny of Applications. The Commission/Board/A ppointin 8 Authority, as the
case may be, shall scrutinise the applications received by it and requird as many candidates
qualified for appointment under these rules as seem to it desirable to appear in written
examination:

Provided that the decision of the Commission/Board/A pointing Authority, as the case
may be, regarding the eligibility or otherwise of 4 candidate, shall be final."

5. Insertion of rule 20A.- After the existing rule 20 and before the 6; isting rule 2 of the
said rules following new rule 204 shall be inserted, namely:-

"20A. Selaction to the Post of Excise Gaurd Grade IL.- (I) Notwithstanding any
thing contained in these tules, selection to the post of Excise Gaurd Giade II shall be made
on the basis of written examination followed by physical efficiencl test as laid down
below:-

(i) Written Examination-Total marks-!00
Gi) Physical Effciency Test:
Male ~ Female Ex-Service dhariya, Schedpled area
P | (ISP), Scheduled Castes

: “rsonne: nd Schduled Ttibes

न ime] test [Time | “Test tine} hear

0 Km 60 ‘3 Km 35 5Kmr |< 30 कि a 30

runnin; minutes | running | minutes Tunning | minutes oning | minutes

ii) Physical Effciency Test shall be of qualifying nature.

(iv) Candidates upto three times (Category wise) of the total advertised vacancies will
be called for physical efficiency test on the basis of marks btained in written
examination.

“A

(v) Merit list shall be finally prepared, amongst the candidates who|had qualilified the
physical efficiency test, on the basis of total marks obtained bythemin written
examination."

5. Amendment of Schedule. In Schedule appended to the said mules, the
existing serial number 4 and entries thereto shall be substituted by the following,
namely:- |
rues, guard atter law approveldoc —-Lo-

L

<!-- page 3 -->

: i Excise 00% by Excise Guard | 5 years’ experience

Guard promotion Gr. on the post

Grade I mentioned in

column no. 5
5. | Excise 00% by | Secondary from
Guard direct 8. recognized
Grrade II | recruitment Board था. its
equivalent
. qualification
ci
By Order and in =e 8 of the Governor,
Lyfe
(Sunil Sharma)
Joint Secretary tg the Government
0 6 40)7
. ~3— .
ra ga er lw appretao:
| :
