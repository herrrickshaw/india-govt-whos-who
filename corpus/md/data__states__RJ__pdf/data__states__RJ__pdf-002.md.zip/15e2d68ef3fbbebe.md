---
doc_id: "15e2d68ef3fbbebe"
source_url: "https://www.vmou.ac.in/sites/default/files/2026-06-tenderqsppp/Tender%20Document%20of%20ARC%20for%20onsite%20ICT%20support.pdf"
ministry: "Vardhaman Mahaveer Open University (VMOU), Kota"
title: "Tender Document of ARC for onsite ICT support.pdf"
date: ""
pages: 20
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f48d09ea707d01d4"
---

<!-- page 1 -->

VARDHMAN MAHAVEER OPEN UNIVERSITY, KOTA
Office of Comptroller Rawatbhata Road, Kota-324021 Rajasthan
(Website- vmou.ac.in)
No/VMOU/S&P/2026-27/11
Date: 11.06.2026
"BID INVITING NOTICE”
Vardhman Mahaveer Open University, Kota invites Sealed Bids under Rajasthan Transparency in Public
Procurement Act, 2012 & Rules, 2013 for “ARC on Job Basis for Providing onsite ICT support Technical
Services” from registered bidders under appropriate category fulfilling eligibility criteria prescribed in Eligibility
bid/Technical bid under single stage two part bidding system as described in the bid documents as appended below
:Name of Work/
Scope of
Estimated
Bid
Bid
Date of
Last Date
Date of
Validity
services
Security
Downloading
of
Opening of
work
cost
fee
Period
Rs.
BID
Submission
BID
documents
of BID
ARC on Job Basis
for Providing onsite
ICT support
Technical Services
(Job Basis)

As per
Annexure - I

Rs. 3.90
lakh

Rs. 7800/-

500/-

16.06.2026

24.06.2026
Till 3:30 PM

25.06.2026
At 2:00 PM

90 days

Instructions to Bidders:1. The Detail Scope of Work as well as terms and conditions for ARC on Job Basis for Providing onsite
ICT support Technical Services have been given in the BID document which may be downloaded from
www.sppp.raj.gov.in the university website www.vmou.ac.in .
2. The Interested bidders may submit their bids at office of comptroller VMOU Kota, Room No.114 in a
sealed envelop containing separate envelopes of Eligibility criteria performa (Envelop –I) which contain
along with separate Demand Drafts drawn in favour of “Vardhman Mahaveer Open University” payable at
Kota towards the cost of Bid Fee Rs. 500/- (non-refundable) and bidder submit bid security amount Rs.
7800/-(refundable/adjustable) and price bid (Envelope –II) therein superscribing on the big envelop “ARC
on Job Basis for Providing onsite ICT support Technical Services”.
3. In the event of the specified dates being a holiday, the activities assigned on that date may be carried out on
next working day on the same time.
4. Vardhman Mahaveer Open University, Kota is not bound to accept the lowest Bid and may reject any Bid
or any part of the Bid without assigning any reason therefore.
5. The Bidders shall be enclosed copy of GST Registration And PAN with the BID.
6. Period of Annual Rate Contract is one year from the date of issuing of work order. However, ARC contract
period may be extended for further 3 months with mutual consent on same rates and terms/conditions as per
rules 29 of RTPP-2013 which can be seen on website www.financerajasthan.gov.in.
7. In case of corrigendum is issued, the same shall be published on the above said websites and as per Rules.
8. Conditional Tender will not be accepted as per RTPP 2013 Rule 56.
9. Bids received after the prescribed time and date will not be considered.
10. Bidder or their Authorized representative may attend the opening of the tender.
11. Technical requirement – As per Annexure-I.
12. The Bidder must submit terms & condition as well as annexure A,B,C and D (duly signed) with the BID.
13. The Price bid shall contain Rates quoted by the bidder in prescribed format as enclosed herewith.

-

Sd

-

OIC (P&S)

Page 1 of 20

<!-- page 2 -->

Envelope - I
VARDHMAN MAHAVEER OPEN UNIVERSITY, KOTA
Rawathbhata Road, Kota -324021

Ikk=rk ekun.M gsrq okafNr lwpuk@izi=
(ARC on Job Bais for Providing onsite ICT support Technical Services)

NIB No. 11/2026-27
fuEu nLrkostksa ds vHkko esa fufonk fopkj ;ksX; ugha ekuh tk;sxh %&
1.

2.

3.

4.
5.
6.
7.
8.
9.

Name and address of the bidder

……………………………………………………….
……………………………………………………….
………………………………………………………..
Email ID……………………Mobile No……...……..
The Bid fee amounting to Rs 500/- has been submitted vide Demand Draft
Number…………………. Dated…………in favour of Vardhman Mahaveer Open University,
Kota payable at Kota.
The Bid Security amounting 2% of Tender Value is Rs 7800/- has been submitted vide Demand
Draft Number…………………. Dated…………in favour of Vardhman Mahaveer Open
University, Kota payable at Kota.

QeZ ds ysVj isM ij fufonk nkrk dks fdlh Hkh jktdh;@v/kZ”kkldh;@Lok;Ùk”kklh laLFkk }kjk CySd fYkLV
ugha fd;s tkus dk LogLrk{kfjr ?kks’k.kki=A (as per annexure-II) (Page No. 13)
oLrq ,oa lsok dj ¼ th-,l-Vh ½ ds iathdj.k dh izfr
vk; dj ¼iSu uEcj½ dh izfr
Annexure A, B, C & D as prescribed in Rajasthan Transparency in Public Procurement Rules,
2013 duly signed is also enclosed. (Page No. 14 to 18)
Terms and conditions duly signed by the bidder. (Page No. 7 to 12)

IT Support Engineer क शै िणक यो यता: Technical requirement
i.
ii.

B.Tech/BE/MCA/MSc (IT/CS) with specialization in Computers/IT with 5 Years’ Experience in IT
Support & Troubleshooting
PGDCA/ BCA/B.Sc. (CS)/ (IT) preferably with 1 year working experience.

10.

काय क कृ ित के अनु सार फम ारा लेटर हेड पर फम के तकनीक कािमको का नाम मय शै िणक यो यता क सू ची सं ल न करनी
होगी A

11.
12.

Technical requirement – As per Annexure-I duly signed by the bidder. (Page No. 3 to 5)
Price Charging Certificate (Page No. 20)

All above required documents are attached herewith duly signed by me and are true.

Date:……….
Place:……….

Signature of the bidder with
Seal

Page 2 of 20

<!-- page 3 -->

Annexure-I

University IT Infrastructure and Manpower Requirement
Vardhman Mahaveer Open University (VMOU), Kota, operates through its various departments
and schools, as detailed on the official website www.vmou.ac.in The University serves lakhs of
students primarily through online mode, ensuring smooth functioning of its ERP system and
internet-based services.
To support these operations, the University maintains essential IT infrastructure, including the
below approximate quantity of the equipment’s:


Computers: 150



Laptops: 50



Printers: 120



Scanners: 40



Network Switches: 30



Networking Facilities: LAN, OFC, Wi-Fi



Other Peripherals: As required for academic and administrative function and smooth
working of the ERP software in various departments of the University.

Scope of Work
For the uninterrupted functioning of the above infrastructure, dedicated manpower is required to
perform the following tasks:


Online meetings creation and management.



Computer hardware assembly, installation, and troubleshooting



Diagnosis and resolution of equipment malfunctions (computers, laptops, printers,
scanners, switches, etc.)



Operating system installation, configuration, and timely troubleshooting



Application software installation, diagnosis, and resolution of errors in a time-bound
manner



Network management, including LAN, OFC, and Wi-Fi troubleshooting and maintenance

Page 3 of 20

<!-- page 4 -->

Essential Tools and Equipment
The deployed manpower will require access to essential tools and equipment, including but not
limited to:


LAN testers



Laptops for troubleshooting and configuration tasks



Standard diagnostic and repair toolkits

1. Computer Assembling, Troubleshooting of Hardware Failure, Diagnose
and Installation
1.
2.
3.
4.
5.
6.
7.

Processor
RAM
Motherboard
Hard disk /SSD
Power Supply (SMPS)
Onboard Motherboard Connection and Supplies
Any Others

2. Computer Peripheral Device Troubleshooting, Diagnosis and Installation
1.
2.
3.
4.
5.
6.

Printer
Scanner
Keyboard
Mouse
DVD RW
Others

3. Computer Software Troubleshooting, Diagnosis and Installation
1.
2.
3.
4.
5.
6.
7.
8.
9.

Windows
Software
Printer Driver
Scanner Driver
Motherboard driver
Graphics Driver
USB Driver
Sound Driver
Others

Page 4 of 20

<!-- page 5 -->

4. Computer Networking & Trouble Shooting & Diagnosis
1. Network Setup and Management
2. Network Troubleshooting (OFC, LAN, WiFi) Diagnosis, Configuration and
Installation
3. Network Switches Malfunction troubleshooting, Diagnosis, Configuration and
Installation
4. RJ 45 Connector Crimping and Punching, Patch Cord Creation
5. IP Address Management
6. Network Printer Management
7. Network Speed related troubleshooting and diagnosis

Hardware Support Engineer क शै िणक यो यता: Technical requirement 1. B.Tech/BE/MCA/MSc (IT/CS) with specialization in Computers/IT with 5
Years’ Experience in IT Support & Troubleshooting
2. PGDCA/ BCA/B.Sc. (CS)/ (IT) preferably with 1 year working experience.

नोट :- िव िव ालय ारा सं बं िधत सेवा दाता फम से सेवाय/Services Hire के म म सं िवदा/Contract करने
हेतु िनिवदा जारी क गई है । उपरो काया तगत अनु बं िधत सेवा दाता ारा उपल ध कराये गये Technical
Persons हेतु िव.िव. का िकसी भी कार से कोई राजक य दिय वाधीन नह होगा अथात िव.िव. काय के म म
सम त ि याि वित सेवा दाता फम से तथा भु गतान, सम त प यवहार व सम त Terms & Conditions हेतु
सेवा दाता फम प कार होगी । यह Job Basis पर िनिवदा है तथा Technical Persons Job िववरण, िविहत
अहता यु सेवा दाता ारा उपल ध कराये जायगे ।

Signature of the bidder with Seal

Page 5 of 20

<!-- page 6 -->

Envelope – II
VARDHMAN MAHAVEER OPEN UNIVERSITY, KOTA
Office of Comptroller Rawatbhata Road, Kota-324021 Rajasthan
(Website- vmou.ac.in)
Price Bid
(ARC on Job Basis for Providing onsite ICT support Technical Services)
1. NIB No:- 11/2026-27 Date:- 11.06.2026
2. Name of Bidder and Address: - ……………………………………………..…………….
…………………………………………………………………..…………………………
Description of Work
(Broad Scope of work)

Rate Per Month Deployed Resources by Contractor
Basic Rate

Agency Charges/Service
Charges

GST

Total Rate Per Month

As per Annexure-I

Note:1. Contractor must have to deploy/make available minimum 2 persons for onsite ICT
support Technical Services having minimum qualification as per Technical bid (Page
no. 2) point no. 9 & Annexure-I for which university has no obligation regarding person
deployed. University shall have agreement with contractor and contractor has to provide
services as per tender terms & conditions.
2. Contract Period:- One year from the date of issue of work order which may be further
extendable as per RTPP Rules 2013 with mutual consent on the same rates as well as
terms and conditions of contract agreement.
Date:…………
Place:……….

Signature of the bidder with Seal

Page 6 of 20

<!-- page 7 -->

VARDHMAN MAHAVEER OPEN UNIVERSITY,
Rawatbhata Road, Kota -324021

Special Terms and conditions:1. The sealed envelope should be addressed to Office of the Comptroller, Vardhman Mahaveer
Open University, Kota.

2. The tender should be sent in a big envelope titled “ARC for Providing of onsite ICT
support technical services”.

3. The duty timings will be as per office timings.
4. The university will pay the successful bidder/firm on the basis of monthly fixed amount
charged one time in a month . No extra amount will be paid by the university.
5. If the support services are not provided by the service provider than Rs. 500/- per day will be
deducted from the bill of the firm.
6. The firm/bidder has to provide the services on holidays also and even before and after the
office time as and when required. No extra payment will be given for that.
7. Please peruse the working conditions and work place before quoting the rates. Rates one
quoted will not be allowed to change thereafter.
8. The technician provided for the service must have Experience and capability as
mentioned in the price bid.
9. The work is to be executed as per instructions /under supervision of Director/OIC,IT &
EMPC and the monthly bill will be verified by Director/OIC,IT & EMPC only.
10. During the services, the university will not be liable for any incident/ damage/accident of the
technician/attendant.
11. The contract will be cancelled if not found work satisfactory without any prior notice and
necessary action will be taken against the service provider /contractor as per terms and
conditions of the bid and contract.
12. The required tools/equipment’s etc. will be provided by the contractor himself.

DECLARATION
I/ We hereby declare that, I/We have read all the general and special
terms and conditions quoted above and agree to be abiding by them.

Date
Place

Signature of bidder with name and seal

Page 7 of 20

<!-- page 8 -->

VARDHMAN MAHAVEER OPEN UNIVERSITY, KOTA
Rawathbhata Road, Kota -324021

बोलीदाताओ के िलये आव यक िविनदश व शत
“ARC on Job Basis for Providing onsite ICT support Technical Services”
जीएसटी म पं जीकृ त बोलीदाताओं से पू व काय हेतु वािषक दर संिवदा के आधार पर सेवाओं के उपापन
हेतु सीलबं द िनिवदाऐं आमं ि त क जाती है। बोलीदाता िनिवदा सूचना म िनयत समय एवं अं ितम ितिथ तक अपने
ताव पा ता मानद ड एवं िवतीय िनिवदा पृथक पृथक िलफाफ म सीलबं द कर एक बडे िलफाफे म मोहर बं द करते
हये अपनी िनिवदाऐं िव िव ालय को बोली शु क सिहत तु त कर सकते है । सं बं िधत िलफाफ पर उ ानुसार
वां िछत शीषक का उ लेख करना होगा ।
1. बोली शु क रािश हेतु पये 500/- एवं बोली ितभूित रािश हेतु पये 7800/- का िडमा ड ा ट
वधमान महावीर खुला िव िव ालय कोटा के नाम से कोटा मे देय होगा । उ िडमा ड ा ट जमा
कराये जाने पर ही िनिवदा/बोली मा य होगी ।
2. वािषक दर सं िवदा अविध:- उ काय वािषक दर सं िवदा के आधार पर कराया जायेगा । दर सं िवदा
अविध करार स पादन ितिथ से 1 वष होगी िजसे RTPP िनयम 2013 िनयम 29 म उ लेिखत
ावधान के अनुसार आपसी सहमित से इ ही शत एवं दर के अनु सार 3 माह हेतु बढ़ाया जा
सके गा ।
3. पा ता मानद ड मे यो य पाये जाने पर ही सं बं िधत फम क िव ीय िनिवदा खोली जावेगी । िव ीय
िनिवदा खोलने क ितिथ पृथक से संवेदक ारा पा ता मानद ड म िदये गये ईमेल पर दी जावेगी ।
तकनीक रपोट SPPP पर अपलोड क जायेगी ।
4. कायस पादन ितभूित:- सफल बोलीदाता को िनिवदा वीकृ ित सू चना प के जारी होने के
अिधकतम 15 िदवस के भीतर कायादेिशत मू य के 5 ितशत क दर से काय स पादन ितभू ित
क िनयमानुसार रािश का िडमा ड ा ट/FD वधमान महावीर खुला िव िव ालय कोटा के नाम से
कोटा म देय एवं . 500/- के नॉन यू िडिशयल टा प पेपर पर िनधा रत ा प (एस आर 17) म
अनु ब ध िकये जाने के उपरा त कायादेश जारी िकया जा सके गा । अनु बं ध नह िकये जाने क ि थित
म RTPP-2013 िनयम 76 अं तगत िनधा रत अविध प ात् दूसरे यू नतम बोली दाता को मौका
िदया जाऐगा ।
5. सफल बोलीदाता को ितिदन कायालय समय अथवा कायालय समय के बाद एवं अवकाश के
िदन म भी आव यकता अनु सार अपनी सेवाय जारी रखनी होगी ।
6. भुगतान ि या:- सं वेदक ारा ितमाह िबल, भारी IT & EMPC को तु त करना होगा, भारी
IT & EMPC ारा सं तोष द प से काय संप न िकये जाने के स यापन उपरा त िबल का भु गतान
िव.िव. ारा िकया जावेगा । तथा वसूिलयां यिद कोई हो तो उ ह भा रत िकया जावेगा । संवेदक
को िबल माह समाि पर अगले माह के पहले स ाह म िवभाग म तु त करना होगा ।
7. टी.डी.एस. िनयमानुसार ितमाह के िबल से काटा जावेगा । जी. एस. टी. एवं अ य कोई कर क
सं िवदा अविध म प रवितत दर मा य होगी ।
8. िकसी भी िनिवदा को पू ण एवं आं िशक प से वीकार/अ वीकार करने का अिधकार िव िव ालय
के पास होगा ।
Page 8 of 20

<!-- page 9 -->

9. यिद इस िनिवदा म िकसी भी कार का संशोधन िकया जाता है तो वह वेबसाइट
www.vmou.ac.in पर कािशत िकया जावेगा ।
10. कािमक के काय स पादन अविध के दौरान काय के सं बं ध/संदभ म िकसी भी कार क दुघटना होने
पर ितपू ित या मु आवजा देने/ई.एस.आई. करवाने/सामू िहक दुघटना बीमा कराने इ यािद क
िज मेदारी एंव दािय व सं वेदक का होगा । इसके िलये िव िव ालय क कोई िज मेदारी नही होगी ।
11. अ य शत राज थान लोक उपापन म पारदिशता अिधिनयम 2012 एवं िनयम 2013 के अनु सार
मा य ह गी ।
12. फम को वः ह ता रत इस आशय का घोषणा प सं ल न करना आव यक होगा िक िकसी भी
राजक य/अ शासक य/ वाय शाषी सं था ारा उसे लेक िल ट नह िकया गया है ।
13. सम त िववाद का याियक े कोटा होगा ।
नोट :(i)
(ii)
(iii)

फम को म कानू न का पालन िकया जाना अिनवाय होगा ।
काय गु णव ापू ण न िकये जाने पर िशकायत क ि थित म यू नतम 3 िलिखत िशकायत ा होने पर
नोिटस िदया जाकर युि यु
यु र न होने क ि थित म सं िवदा िनर त क जा सके गी ।
सम त ावधान RTPP-2013 से शािसत ह गे िज ह िव िवभाग क वेबसाइट
www.financerajasthan.gov.in पर देखा जा सकता है ।

मेरे ारा उपरो िनदश एवं शत का अ ययन कर िलया गया है और ह ता र कर म अपनी सहमित दान
करता हॅ ू ।

सं वेदक के ह ता र मय सील
नाम :थान :िदनांक :-

Page 9 of 20

<!-- page 10 -->

VARDHMAN MAHAVEER OPEN UNIVERSITY, KOTA
Rawathbhata Road, Kota -324021

Condition of Bid & contact
Note:-Bidders should read these conditions carefully and comply strictly while submitting their tenders.
1. Tenders by bona-fide dealers:-Tenders shall be given only by bona-fide Firm/Agency. They
shall, therefore, furnish a declaration.
2. Any change in the constitution of the firm, etc. shall be notified forth with by the contractor in
writing to the Registrar and such change shall not relieve any former member of the firm, etc.
from any liability under the contract.
a. No new partner/partners shall be accepted in the firm by the contractor in respect of the contract
unless he/they agree to abide by all its terms, conditions and deposit with the Registrar a written
agreement to this effect. The Contractor's receipt for acknowledgment or that of any partners
subsequently accepted as above shall bind all of them and will be sufficient discharge or any of
the purpose of the contract.
3. Rate shall be written both in words and figures . There should not be errors and/or overwriting.
Corrections if any should be made clearly and initialed with dates.
4. Validity: - Tender shall be valid for a period of three months from the date of opening bid.
5. The Contractor shall not assign or sub-let his contract or any substantial part thereof to any other
agency.
6. (i) Contract Period:- One year from the date of issue of work order which may be further
extendable as per RTPP Rule 2013 with mutual consent on the same rates as well as terms and
conditions of contract agreement.
(ii) Bid Security:- The Bid Security amounting 2% of Tender Value is Rs 7800/- has been
submitted vide Demand Draft in favour of Vardhman Mahaveer Open University, Kota payable at
Kota.
7. Agreement and Performance Security:a. Successful bidder will have to execute an agreement in the Form SR-17 and deposit Performance
security equal to 5% of the value of the Bids for which tenders are accepted within 15 days from
the date of dispatch on which the acceptance of the tender is communicated to him.
b. No interest will be paid by the University on the Security money.
c. The form of Security Money shall be as below:
(a) Cash/Bank Draft/Bankers Cheque.
(b) Post-office Savings Bank Pass book duly pledged.
(c) National Savings Certificate, Defence Savings Certificates, Kisan Vikas Patras, or any other
script /instrument under National Savings Scheme for promotion of small savings, if the same can
be pledged. These certificates shall be accepted at surrender value.
(d) Bank guarantee issued by any of scheduled bank.
d. The security money shall be refunded after the final supply of the man power services .
8. (i) Firms Registered with the Director of Industries Rajasthan in respect of stores for which they
are registered, subject to their furnishing the registration in original from the Director of
Industries or a Photostat copy or a copy thereof duly attested by any Gazetted Officer will be
partially exempted from earnest money and shall pay security deposit at the rate of 1% of the
estimated value of tender.
(ii) Central Government and Government of Rajasthan Undertaking will be exempted from
furnishing security amount.
9. Forfeiture of Security Deposit:- Security amount in full or part may be forfeited in the
following cases .

Page 10 of 20

<!-- page 11 -->

a. When any terms and conditions of the contract is breached.
b. When the bidder fails to make complete man power services satisfactorily.
c. Notice of reasonable time will be given in case of forfeiture of security deposit. The decision of
the University in this regard shall be final.
10. The expenses of completing and stamping the agreement shall be paid by the bidder and the
University shall be furnished free of charge with one executed stamped counter part of the
agreement.
11. Insurance:a. The contractor shall arrange for insurance for the damage /loss regarding services to be provided
to the university in the contract period if required. The university will not be liable for any
payment towards insurance or damage/loss caused during the contract period.
12. Payments:- Unless otherwise agreed between the parties, payment for the Services will be made
on montly basis on verification of the bills of the contractor by the Incharge EMPC.
13. Liquidated Damages:- If the support services are not provided by the service provider than Rs.
500/- per day will be deducted from the bill of the firm.
14. Risk & Cost clause:The competent authority of VMOU, KOTA without prejudice to his right against the approved
supplies in respect of any delay or inferior performance of otherwise or claims for delay in
respect of any breaches of the contract and without prejudice to any rights or remedies under any
of the provisions of the contract or otherwise, by notice in writing absolutely determined the
contract in any of the cases.
i.
A notice in writing to rectify, or otherwise that the work being performed is inefficient or
otherwise implemented in improper manner, shall omit to comply with the requirement of
such notice within a period of 07 days or for prescribed time, thereafter of if the supplier
shall delay or suspended the execution of the work so that either in the judgment of the
competent authority, he will be unable to perform the work by the satisfaction of VMOU,
KOTA or has already failed to complete the work by the time.
ii.
If the supplier commits breach of the terms & conditions the contract.
iii.
When the supplier has made himself liable for action under any of the cases aforesaid ,
the competent authority, shall exercise power:a. To determine or rescind the contract, as aforesaid, upon such determination or rescission, the
bid security, performance security shall be liable to be forfeited and shall be absolutely at the
disposal of VMOU, KOTA.
b. To get the work done through other service provider and in such case any expenses which
may be incurred in excess, of the sum which would have been paid to the original SP, if the
whole work had been executed by him of the amount of which excess, the decision of the
COE/VMOU, KOTA shall be final and conclusive and shall be borne and paid by the original
SP that may be deducted from any money due to him by the VMOU, KOTA or from has bid
security, performance security. However the original SP shall have no claim to compensation
for any loss sustained by him or reason for having purchased or procured any material,
equipments or entered into any engagements or made advances on account of
execution/performance of contract.
15. Recoveries: - will be made against LD from the montly bills produced by the contractor. In case
recovery is not possible recourse will be taken under Rajasthan PDR act or any other law in force.
16. If a bidder imposes conditions, which is in addition to or in confliet with the conditions
mentioned herein, his tender is liable to summary rejection. In any case none of such conditions
will be deemed to have been accepted unless specifically mentioned in the letter of acceptance of
tender issued by the Comptroller .
17. The University reserves the right to accept any tender not necessarily the lowest, reject any tender
without assigning any reasons .
18. The bidder shall furnish the following document at the time of execution of agreement:(a) Attested copy of partnership deed in case of partnership firms.
(b) Registration number and year registration in case partnership firm is registered with Registrar of
firms.
(c) Address of residence and office, telephone numbers in case of sole proprietorship.
(d) Registration issued by Registrar of Companies in case of company.

Page 11 of 20

<!-- page 12 -->

19. All legal proceeding , if necessary arise to institute may by any of the parties (VMOU, Kota or
Contractor) shall have to be lodged in courts situated in Kota, Rajasthan and not elsewhere.
20. All other/remaining general terms & conditions shall be applicable as laid down in
Rajasthan transparency in public procurement Act 2012 and rules 2013.
Note: - I have read the above terms and conditions of contract carefully and I shall be abide by the same
in the event of successful bidder.

Date:
Place:

Signature & Seal of the bidder

Page 12 of 20

<!-- page 13 -->

Annexure II

?kks"k.kk&i=
fufonk dh leLr tkudkjh@”krksZ dk eSaus@geusa vPNh rjg v/;;u dj fy;k gSA eSa@ge ;g Hkh
izekf.kr djrs gSa fd eSa@ge mDr dk;Z gsrq jftLVMZ gS okLro esa pkgk x;k O;olk; fd;k tkrk gS
rFkk okafNr e”khu@midj.k@ izf”kf{kr dkfeZd miyC/k gS rFkk ^^vf/kfu;e^^ dh /kkjk 46 ,oa
^^fu;e^^ 39 ds vuqlkj jkT; ljdkj ;k bl mikiu laLFkk ls fufonk tek dh vafre fnukad ds 3
o’kZ iwoZ rd vik=rk ds fy;s fooftZr ¼Debarred½ ugha gSaA
;fn ;g ?kks’k.kk vlR; ik;h tk, rks fu;ekuqlkj dk;Zokgh dh tk ldrh gS] esjh@gekjh cksyh
izfrHkwfr@,oa dk;Z fu’iknu izfrHkwfr dks iw.kZ :i ls leiâr dj fy;k tk ldsxk rFkk [kqyh cksyh
dks] ftl lhek rd mls Lohdkj fd;k x;k gS] jn~n fd;k tk ldsxkA
cksyhnkrk ds gLrk{kj uke e; lhy

Page 13 of 20

<!-- page 14 -->

Annexure –A
Compliance with the code of integrity and no conflict of interest
Any person participating in a procurement process shall(a) Not offer any bribe, reward or gift or any material benefit either directly or indirectly in exchange
for an unfair advantage in procurement process or to otherwise influence the procurement
process.
(b) Not misrepresent or omit that misleads or attempts to mislead so as to obtain a financial or other
benefit or avoid an obligation.
(c) Not indulge in any collusion, Bid rigging or anti-competitive behavior to impair the transparency,
fairness, and progress of the procurement process.
(d) Not misuse any information shared between the procuring entity and the Bidders with an intent to
gain unfair advantage in the procurement process.
(e) Not indulge in any correction including impairing or threatening to do the same, directly or
indirectly, to any party or to its property to influence the procurement process.
(f) Not obstruct any investigation or audit of a procurement process.
(g) Disclose conflict of interest, if any, and
(h) Disclose any previous transgressions with any entity in India or any other country during the last
three years or any debarment by any other procuring entity.
Conflict of Interest:The Bidder participating in a bidding process must have a conflict of interest.
A Conflict of interest is considered to be a situation in which a party has interests that could
improperly influence that party’s performance of official duties or responsibilities, contractual
obligation, or compliance with applicable laws and regulations.
a. A Bidder may be considered to be in conflict of interest with one or more parties in a bidding
process if, including but not limited to;
b. Have Controlling partners/shareholders in common; or
c. Receive or have received any direct or indirect subsidy from any of them; or
d. Have the same legal representative fro purpose of the bid; or
e. Have the relationship with each other, directly or through common third parties, that puts
them in a position to have access have to information about or influence on the bid of another
Bidder, or influence the decision of the procuring entity the bidding process; or
f. The Bidder participates in more than one bid in a bidding process. Participation by a Bidder
in more than one bid will result in the disqualification of all Bids in which the Bidder is
involved. However this does not limit the inclusion of the same subcontractor , not otherwise
participating as Bidder, in more than one Bid; or
g. The Bidder or any of its affiliates participated as a consultant in the preparation of the design
or technical specification of the goods, works or service that are the subject of the Bid; or
h. Bidder or any of its affiliates has been hired (or is proposed to be hired) by the procuring
entity as engineer-in-charge /consultant for the contract.

Place:
Date:

Signature of the Bidder with seal

Page 14 of 20

<!-- page 15 -->

Annexure –B
Declaration by the Bidder regarding qualifications
In relation to my/our Bid submitted to Comptroller VMOU, KOTA, Kota for
procurement of “ARC on Job Basis for Providing onsite ICT support Technical Services” in
response to their Notice Inviting Bid No. 11/2026-27 Dated 11.06.2026 . I/We hereby declare
under section 7 of Rajasthan Transparency in Public Procurement Act , 2012, that:
1. I/We possess the necessary professional, technical , financial and managerial resources
and competence required by the Biding Document issued by the Procuring Entity;
2. I/We have fulfilled my/our obligation to pay such of the taxes payable to the union and
the State Government or any local authority as specification in the Bidding Document;
3. I/We have are not insolvent in receivership, bankrupt or being wound up, not have
my/our affairs administrated by a court or a judicial officer , not have my/our business
activities suspended and not the subject of legal proceeding for any of the foregoing
reasons;
4. I/We do not have, and our directions and officers not have, been convicted of any
criminal offence related to my/our professional conducted or the making of false
statement or misrepresentations as to my/our qualifications to enter into a procurement
contract within a period of three years preceding the commencement of this procurement
process, or not have been otherwise disqualified pursuant to debarment proceeding;
5. I/We do not have a conflict of interest as specification in the Act, Rules and the bidding
document, which material affects fair competition;

Date:
Place:

Signature of bidder with seal
Name:
Designation:
Address:

Page 15 of 20

<!-- page 16 -->

Annexure C
Grievance redressal during procurement process
The designation and the address of the first appellate authority is Hon’ble V.C. VMOU, Kota.
The designation and the address of second Appellate Authority is Secretary, Higher & Technical
education, Rajasthan Govt.
(1) Filing an appeal
If any bidder or prospective bidder is aggrieved that any decision, action or omission of the
Procuring Entity is in contravention to the provisions of the act or the rules or the Guidelines
issued there under, he may file am appeal to first Appellate Authority, as specified in the Bidding
Document within a period of ten days from the date of such decision or action, omission, as the
case may be, clearly giving the specific ground or grounds on which he feels aggrieved:
Providing that after the declaration of a bidder as successful the appeal may be filled only by a
bidder who has participated in procurement proceeding:
Providing further that in case a Procuring Entity evaluates the Technical Bids before the opening
of the Financial Bids, an appeal related to the matter of Financial Bids may be filled only by a
Bidder whose Technical Bid id found to be acceptable.
(2) The officer to whom an appeal is filled under para (1) shall deal with the appeal as expeditiously
as possible and shall endeavourer to dispose it of within thirty days from the date of the appeal.
(3) If the officer designated under para (1) fails to dispose of the appeal filed within the period
specified in para (2), or if the Bidder or prospective bidder or the Procuring Entity is aggrieved by
the order passed by the Procuring Entity, as the case may be, may file a second appeal to second
Appellate Authority specified in the Bidder Document in this behalf within fifteen days from the
expiry of the period specified in para (2) or of the date of receipt of the order passed by the first
Appellate Authority, as the case may be.
(4) Appeal not to lie in certain cases
No appeal shall lie against any decision of the Procuring Entity relating to the following matters,
namely:(a) Determination of need of Procurement
(b) Provisions limiting participating of Bidders in the Bid process;
(c) The decision of whether or not to enter into negotiations;
(d) Cancellation of a procurement process ;
(e) Applicability of the provisions of confidentiality
(5) Form of appeal
(a) An appeal under para (1) or (3) above shall be in the annexed form along with as many copies
as there are respondents in the appeal.
(b) Every appeal shall be accompanied by an order appealed against, if any, affidavit verifying
the facts stated in the appeal and proof of payments of fee.
(c) Every appeal may be presented to first Appellate Authority or Second Appellate Authority, as
the case may be, in person or through registered post or authorized representative.
(6) Fee for Filling Appeal
(a) Fee for first appeal shall be two thousand five hundred and for second appeal shall be rupees
ten thousand, which shall be non refundable.
(b) The fee shall be paid in the form of bank demand draft or banker’s cheque of a Scheduled
Bank in India payable in the name of Appellate Authority concerned.
(7) Procedure for disposal of appeal
(a) The first Appellate Authority or Second Appellate, as the case may be upon filing of appeal,
shall issued notice accompanied ny copy of appeal, affidavit and documents, if any, to the
respondents and fix date of hearing.
(b) On the date of fix hearing, the First Appellate Authority or second Appellate Authority , as
the case may be shall,Page 16 of 20

<!-- page 17 -->

i. Hear all the parties to appeal present before him; and
ii. Peruse or inspect documents , relevant records or copies thereof relating th the matter.
(c) After hearing the parties , perusal or inspection of documents and relevant records or copies
thereof relating to the matter, the Appellate Authority concerned shall pass an order in writing
and provide the copy of order to the parties to appeal free of cost.
(d) The order passed under sub-clause (c) above shall also be placed on the State Public
Procurement Portal.

Date:
Place:

Signature of the Bidder with seal

Page 17 of 20

<!-- page 18 -->

Annexure-D
Additional conditions of contract

1. Correction of arithmetical errors
Provided that a Financial Bid is substantially responsive, that Procuring Entity will correct
arithmetical errors during evaluation of Financial Bids on the following basis:
a. If there is a discrepancy between the unit price and the total price that is obtained by
multiplying the unit price and quality , the unit price shall prevail and the total price
shall be corrected, unless in the opinion in the Procuring Entity there is an obvious
misplacement of the decimal point in the unit price, in which case the total price as
quoted shall govern and the unit price shall be corrected;
b. If there is a error in a total corresponding to the addition or subtraction of subtotals,
the subtotals shall prevail and the total shall be corrected; and
c. If there is a discrepancy between words and figures, the amount in words shall
prevail, unless the amount in figures shall prevail subject to a and b above.
If the Bidder that submitted the lowest evaluated Bid does not accepted the correction of errors,
its Bid shall be disqualified and its Bid Security shall be forfeited or its Bid Securing Deceleration
shall be executed.
2. Procuring Entity’s Right to very Quantities.
(i) At the time of award of contract, the quantity of goods, works or services originally specified in
the Bidding Document may be increased or decreased by a specified percentage, but such
increase or decrease shall not exceed twenty percent, of the quantity specified in the Bidding
Document. It shall be without any change in the unit price or other terms & conditions of the Bid
and the conditions of contract.
(ii) If the Procuring Entity does not procure any subject matter of procurement or procures less than
the quantity specified in the Bidding Document due to change in circumstances, the Bidder shall
not be entitled for any claim or compensation except otherwise provided in the conditions of
contract.
(iii) In case of Procurement of Goods or services, additional quantity may be procured by placing a
repeat order on the rates and conditions of the original order. However, the additional quantity
shall not be more than 25% of the value of Goods of the original contract and shall be within one
month from the date of expiry of last supply. If the Service Provider fail to do so, the
Procurement Entity shall be free to arrange for the balance supply by limited Bidding or
otherwise and the extra cost incurred shall be recovered from the Service Provider.
3. Dividing quantities among one than more Bidder at the time of award (In case of
procurement of Goods)
As a general rule all the quantities of the subject matter of procurement shall be procured for the
Bidder, whose Bid is accepted. However, when it is considered that the quantity of the subject
matter of procurement to be procured is very large and it may not be in the capacity of the Bidder,
whose Bid is accepted, to deliver the entire quantity or when it is considered that the subject
matter of procurement to be procured is of critical and visit nature, the quantity may be divided
between the Bidder, whose Bid is accepted and the second lowest Bidder or even more Bidders in
that order, in a fair, transparent and equitable manner at the rates of the Bidder, whose Bid is
accepted.

Date:
Place:

Signature of the Bidder with seal

Page 18 of 20

<!-- page 19 -->

Form No. 1
[See Rule 83]
Memorandum of Appeal under the Rajasthan Transparency in Public Procurement Act,
2012
Appeal No. ………… of ……………………………………………..……
Before the ………………………………………………… (First / Second Appellate Authority)
1.

Particulars of appellant:
i. Name of the appellant:
ii. Official address, if any:
iii. Residential address:

2.

Name and address of the respondent(s):
i.
ii.
iii.

3.

Number and date of the order appealed against and name and designation of the officer /
authority who passed the order (enclose copy), or a statement of a decision, action or
omission of the procuring entity in contravention to the provision of the Act by which the
appellant is aggrieved:

4.

If the Appellant proposes to be represented by a representative, the name and postal
address of the representative:

5.

Number of affidavits and documents enclosed with the appeal:

6.

Grounds of appeal:
………………………………………………………………………………..……………
…………………………………… (Supported by an affidavit)

7.

Prayer:
……………………………………………………………………………………………

Place …………………..
Date ……………………
Appellant’s Signature

Page 19 of 20

<!-- page 20 -->

fufonknkrk }kjk viuh laLFkk ds ysVj gsM ij izLrqr fd;k tk;s

PRICE CHARGING CERTIFICATE

I/We hereby certify that the rate offered in Financial bid are reasonable and
justified and we are not marking lower rates to other department on condition of
the tender and contract.

Signature of the Bidder
With seal and designation

Page 20 of 20
