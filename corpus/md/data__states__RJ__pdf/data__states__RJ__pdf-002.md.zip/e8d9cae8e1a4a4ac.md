---
doc_id: "e8d9cae8e1a4a4ac"
source_url: "https://cgstjaipur.gov.in/Attachments/669b2f00-cc05-416c-ab69-52d51e0de3a2.pdf"
ministry: "Central Goods & Services Tax, Jaipur Zone, Rajasthan"
title: "Cadre Control Unit Establishment Order"
date: ""
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "8a9b488aa52d67b9"
---

<!-- page 1 -->

ET-I/39/15/1/2022-ESTT-O/o Pr COMMR-CGST-JAIPUR

I/4983589/2026

कार्यालय मुख्य आयुक्त

Office of the Chief Commissioner
सीजीएसटी एवं केन्द्रीय उत्पाद शुल्क (जयपुर परिक्षेत्र), जयपुर
CGST & Central Excise (Jaipur Zone), Jaipur
(कैडर कन्ट्र ोल यू निट)

स्थापना आदे श संख्या : सी.सी.यू .- CCU - 70/2026
कर्मचारी चयन आयोग, संयुक्त स्नातक स्तरीय परीक्षा, 2025 के माध्यम से आयकर विभाग, राजस्थान में
कार्यालय -अधीक्षक के पद पर चयन के परिणामस्वरुप, श्री अमित कुमार राव , कर सहायक (समूह ‘सी’), सीमा
शुल्क आयुक्तालय, जोधपुर (मु. जयपुर) द्वारा दिनां क 21.09.2026 एवं 29.09.2026 को दिया गया तकनीकी
त्यागपत्र को दिनां क 08.10.2026 से स्वीकार किया जाता है ।

Consequent upon selection to the post of Office Superintendent in
Income Tax Department, Rajasthan through SSC CGL Examination-2025, the
Technical Resignation dated 21.09.2026 & 29.09.2026 tendered by Shri
Amit Kumar Rav, Tax Assistant (Group ‘C’), Customs (Prev.) Commissionerate,
Jodhpur (Hqrs. Jaipur) is hereby accepted w.e.f. 08.10.2026.
चूंकि अधिकारी इस विभाग में कर सहायक के पद पर स्थायी नही ं हुए हैं , इसलिए कर सहायक ग्रेड में
विभाग में उनका कोई ग्रहणाधिकार नही ं रहेगा।

As the officer has not been confirmed in this department on the post of
Tax Assistant, therefore, he will not retain any lien in the department in grade
of Tax Assistant.
यह आदे श नियुक्ति प्राधिकारी की संस्वीकृति से जारी किया जा रहा है ।

This order issues with the approval of the Appointing Authority.

(अजय गुप्ता)
सहायक आयुक्त
प्रतिलिपि निम्न को सूचना एवं आवश्यक कार्यवाही हे तु प्रस्तुत है 1.

निजी प्रति– श्री अमित कुमार राव , कर सहायक, सीमा शुल्क आयुक्तालय, जोधपुर (मु. जयपुर) |

2.

अपर / संयुक्त आयुक्त (का. एवं सत.), सीमा शुल्क आयुक्तालय, जोधपुर (मु. जयपुर) को उनके कार्यालय के
पत्र सं. F. No. II (39)/OTH/324/2020-Admn/Estt. दिनां क 28.09.2026 एवं पत्र सम सं .
I/4734158/2026 दिनां क 05.10.2026 के संदर्भ मे प्रेषित कर लेख है कि श्री अमित कुमार राव, कर
New Central Revenue Building, Statue Circle, C-Scheme, Jaipur – 302005 (Raj.)
Phone: 0141-2385155; Fax: 0141-2385130, E-Mail: ccu-cexjpr@nic.in,

Website: www.cgstjaipur.gov.in, Twitter Handle : @CGSTJAIPURZONE

<!-- page 2 -->

ET-I/39/15/1/2022-ESTT-O/o Pr COMMR-CGST-JAIPUR

I/4983589/2026

सहायक को कार्यभार मुक्त करने से पूर्व यह सुनिश्चित करें कि उनके विरूद्व कोई सरकारी / विभागीय दे यता
एवं सतर्क ता / असतर्क ता सम्बन्धी प्रकरण इत्यादि लम्बित नही है । तत्पश्चात श्री अमित कुमार राव, कर
सहायक को कार्यभार मुक्त कर इस कार्यालय को कार्यभारमुक्ति आदे श की प्रति प्रेषित करें ।
3.

प्रधान आयुक्त/ आयुक्त, सी.जी.एस.टी. एवं केन्द्रीय उत्पाद शुल्क आयुक्तालय, जयपुर/अलवर /उदयपुर/
जोधपुर/ अंकेक्षण जयपुर /अंकेक्षण जोधपुर/ अपील्स, जयपुर/अपील्स, जोधपुर/सीमा शुल्क आयुक्तालय,
मुख्या.-जयपुर।

4.

वेतन एवं लेखाधिकारी, अप्रत्यक्ष कर एवं सीमा शुल्क, जयपुर।

5.

अधीक्षक (प्रशा./सत.), मुख्य आयुक्त कार्यालय, सी.जी.एस.टी. एवं केन्द्रीय उत्पाद शुल्क जोन, जयपुर।

6.

वेबमास्टर, सी.जी.एस.टी. एवं केन्द्रीय उत्पाद शुल्क, जयपुर को विभागीय वेबसाईट पर अपलोड करने हे तु।

7.

गार्ड फाईल/ निजी पत्रावली/ सेवा पुस्तिका/ संबंधित एसोसियेशन/ सूचना पट्ट।
