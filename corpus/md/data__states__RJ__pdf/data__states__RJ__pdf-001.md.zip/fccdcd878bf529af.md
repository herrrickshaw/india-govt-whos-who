---
doc_id: "fccdcd878bf529af"
source_url: "https://excise.rajasthan.gov.in/Downloads/RSED/PDF/Amendment_Act_6June_Eng.pdf"
ministry: "Excise Department, Rajasthan"
title: "The Rajasthan Excise (Amendment) Act, 2007 (Act No. 6 of 2007)"
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3cb1462aa4bb1377"
---

<!-- page 1 -->

LAW (LEGISLATIVE DRAFTING) DEPARTMENT
(Group-II)
NOTIFICATION
Jaipur, June 6, 2007
No. F.2(27)Vidhi/2/2006. The following Act of the Rajasthan State Legislature
received the assent of the President on the 19th day of May, 2007 is hereby published for
general information:THE RAJASTHAN EXCISE (AMENDMENT) ACT, 2007
(Act No. 6 of 2007)
(Received the assent of the President on the 19th day of May, 2007)
An
Act
further to amend the Rajasthan Excise Act, 1950.
Be it enacted by the Rajasthan State Legislature in the Fifty-eighth Year of the
Republic of India, as follows:1.

Short title and commencement.- (1) This Act may be called the Rajasthan
Excise (Amendment) Act, 2007.
(2) It shall come into force at once.
2. Amendment of section 3, Rajasthan Act No. II of 1950- In clause (19) of
section 3 of the Rajasthan Excise Act, 1950 (Act No. II of 1950), hereinafter in
this Act referred to as the principal Act, after the existing expression "boat, raft"
and before the existing expression "and enclosure", the expression, "vehicle" shall
be inserted.
3. Amendment of section 9, Rajasthan Act No. II of 1950.- For the existing subsection (1A) of section 9 of the principal Act, the following shall be substituted,
namely:"(1A) The State Government may also appoint such and so many other persons as it
thinks fit and necessary to be:(i)
(ii)
(iii)
(iv)

Director Enforcement, Special Director Enforcement, Additional Director
Enforcement, Joint Director Enforcement, Zonal Director Enforcement,
Deputy Director Enforcement and Assistant Director Enforcement;
Deputy Excise Commissioners;
District Excise Officers; and
Other inferior Officers."

<!-- page 2 -->

4.
(i)

(ii)
(iii)

Amendment of section 9A, Rajasthan Act No. II of 1950.- In section 9A
of the principal Act,- In section 9A of the principal Act,in clause (b) of sub-section (1), for the existing expression "to the Division
Bench of the Board of Revenue established under the provisions of
Rajasthan Land Revenue Act, 1956 (Act No. 15 of 1956)," the expression
"to the Division Bench of the Rajasthan Tax Board constituted under
section 88 of the Rajasthan Value Added Tax Act, 2003 (Act No. 4 of
2003), " shall be substituted;
in sub-section (3), for the existing expression "Board of Revenue", the
expression "Rajasthan Tax Board" shall be substituted; and
in sub-section (4), for the existing expression "Board of Revenue", the
expression "Rajasthan Tax Board" shall be substituted.

5. Insertion of section 10A, Rajasthan Act No. II of 1950.- After the existing
section 10 of the principal Act, the following new section shall be inserted,
namely:-:"10A. Establishment of check-post and inspection of goods while in
movement.- (1) The Excise Commissioner may, with a view to prevent or check
evasion of excise duty, by notification in the Official Gazette, direct the setting up
of check-posts at such places and for such period as may be specified in the
notification. Every officer or official, who exercises his powers and discharges his
duties at such check-posts by way of inspection of documents produced and goods
being moved, shall be its Incharge.
(2) Notwithstanding anything contained in sub-section (1), the Excise
Commissioner may, by notification in the Official Gazette, declare any existing
check-post established by any other department of the State Government to be the
check-post for the purposes of this section and may appoint any officer or official
to act as the Incharge of the check-post for the purposes of this section.
(3) The driver or person Incharge of a vehicle or carrier carrying excisable articles
shall(a) carry with him the permit, pass, bill and bilty;
(b) stop the vehicle or carrier at such check-post;
(c) produce all documents for inspection of the Incharge of the check-post;
and
(d) allow the inspection of goods/excisable article.
Explanation.- For the purpose of this section "vehicle or carrier" shall
include any means of transportation including an animal to carry goods from one
point to another."
6. Amendment of section 48, Rajasthan Act No. II of 1950.- In proviso to section
48 of the principal Act, after the existing clause (iii), the following clause shall be
added, namely:-

<!-- page 3 -->

"(iv) the provisions of section 162 of the Code of Criminal Procedure,
1973 (Central Act No. 2 of 1974) shall not apply to the investigations
made under this Act.".
7. Amendment of section 49, Rajasthan Act No. II of 1950.- For the existing
section 49 of the principal Act, the following shall be substituted, namely:"49. Modified application of certain provisions of the Code.- (1) Section 167
of the Code shall apply to a case involving an offence punishable under the
proviso to section 54, or under sections 54B, 54D or 56 of this Act subject to the
modification that in sub-section (2) thereof the reference to "sixty days" and
"ninety days", wherever they occur, shall be construed as reference to "one
hundred twenty days" and "one hundred eighty days" respectively.
(2) Nothing in section 438 of the Code shall apply in relation to any case
involving the arrest of any person on an accusation of having committed an
offence punishable under the proviso to section 54, or under sections 54B, 54D or
56 of this Act.
(3) Notwithstanding anything contained in the Code, no person accused of an
offence punishable under the proviso to section 54, or under sections 54B, 54D or
56 of this Act shall, if in custody, be released on bail or on his own bond, unless(a) the Public Prosecutor has been given an opportunity to oppose the
application of such release; and
(b) where the Public Prosecutor opposes the application, the court is satisfied
that there are reasonable grounds for believing that he is not guilty of such
offence and that he is not likely to commit any such offence while on bail.
(4) The limitations on grant of bail specified in sub-section (3) are in addition to
the limitations under the Code or any other law for the time being in force on the
grant of bail.
Explanation.- In this section, the expression "the Code" means the Code of
Criminal Procedure, 1973 (Central Act No. 2 of 1974).
8. Amendment of section 54, Rajasthan Act No. II of 1950.- In section 54 of the
principal Act,(i)

(ii)
(iii)

for the existing expression "be punishable with imprisonment for a
term which may extend to three years and with fine which may extend
to twenty thousand rupees", the expression "be punishable with
imprisonment for a term which shall not be less than six months but
which may extend to three years and with fine of twenty thousand
rupees or five times of the loss of excise duty, whichever is higher"
shall be substituted;
the existing first proviso shall be deleted; and
for the existing second proviso, the following shall be substituted,
namely;-

<!-- page 4 -->

"Provided that if the quantity of liquor found at the time or in the
course of detection of the offence under clause (a) of this section
exceeds fifty bulk liters, the person guilty for such offence shall be
punishable with imprisonment for a term which shall not be less than
three years but which may extend to five years and with fine of twenty
thousand rupees or ten times of the loss of excise duty, whichever is
higher."
9. Insertion of new sections 54B, 54C and 54D, Rajasthan Act No. II of 1950.After the existing section 54A and before the existing section 55 of the principal
Act, the following new sections shall be inserted, namely:"54B. Penalty for adulteration resulting in death etc..- (1) Whoever mixes or
permits to be mixed with any liquor or intoxicating drug any noxious substance or
any substance, which is likely to cause disability or grievous hurt or death to
human beings, shall, on conviction, be punishable,(i)

if, as a result of such an act, death is caused to any person, with
imprisonment for a term which shall not be less than two years but
which may be for life, and with fine which shall not be less than one
lakh rupees but which may extend to ten lakh rupees;
(ii)
if, as a result of such an act, disability or grievous hurt is caused to any
person, with imprisonment for a term which shall not be less than two
years but which may be for life, and with fine which shall not be less
than fifty thousand rupees but which may extend to five lakh rupees;
and
(iii) in any other case, with imprisonment for a term which shall not be less
than one year but which may extend to ten years, and with fine which
shall not be less than fifty thousand rupees but which may extend to
two lakh and fifty thousand rupees.
(2)
Whoever omits to take reasonable precautions to prevent the mixing of
any noxious substance or any substance which is likely to cause disability
or grievous hurt or death to human beings, with any liquor or intoxicating
drug shall, on conviction, be punishable,(i)
(ii)

(iii)

if, as a result of such omission, death is caused to any person, with
imprisonment for a term which may extend to ten lakh rupees;
if, as a result of such omission, disability or grievous hurt is caused
to any person, with imprisonment for a term which shall not be less
than two years but which may be for life, and with fine which shall
not be less than fifty thousand rupees but which may extend to five
lakh rupees; and
in any other case, with imprisonment for a term which shall not be
less than one year but which may extend to ten years, and with fine
which shall not be less than fifty thousand rupees but which may
extend to two lakh and fifty thousand rupees.

<!-- page 5 -->

(3)

Whoever possesses any liquor or intoxicating drug in which any liquor or
intoxicating drug in which any substance referred to in sub-section (1) is
mixed, knowing that such substance is mixed with such liquor or
intoxicating drug shall, on conviction, be punishable with imprisonment
for a term which shall not be less than one year but which may extend to
ten years, and with fine which may extend to one lakh rupees.

Explanation.- For the purposes of this section and section 54C the expression
"grievous hurt" shall have the same meaning as is in section 320 of the Indian
Penal Code, 1860 (Central Act No. 45 of 1860).
54C Order to pay compensation- (1) Notwithstanding anything
contained in the Code of Criminal Procedure, 1973 (Central Act No. 2 of 1974)
the court when passing the judgment in a case falling under section 54B may, if it
is satisfied that death or grievous hurt or disability or other injury has been caused
to any person or persons by consumption of liquor or intoxicating drug sold in any
place, order the person who sold the liquor or intoxicating drug, whether or not he
is convicted of an offence under section 54B, to pay, by way of compensation,
such amount as it thinks just to the legal representatives of the deceased or to the
person or persons to whom grievous hurt or disability has been caused :
Provided that the amount of compensation ordered to be paid under this section
shall not be less than three lakh rupees in case of death, two lakh rupees in case or
grievous hurt or disability and twenty thousand rupees in other cases :
Provided further that, where the liquor or intoxicating drug is sold in a licensed
shop, the liability to pay the compensation under this section shall be on the licensee.
(2)
Any person aggrieved by an order under sub-section (1) may, within thirty
days from the date of the order, prefer an appeal to the High Court :
Provided that no such appeal shall lie unless the amount ordered to be paid under
sub-section(1) is deposited in the court which passed such order :
Provided further that the High Court may entertain the appeal after the expiry of
the said period of thirty days if it is satisfied that the appellant was prevented by
sufficient cause from preferring the appeal in time.
54D. Penalty for criminal conspiracy :- Whoever is a party to a criminal
conspiracy to commit an offence punishable under this Act shall be punished in the same
manner as if he had committed such offence.
Explanation :- For the purposes of this section the expression "criminal
conspiracy" shall have the same meaning as is in section 120-A of the Indian Penal Code,
1860 (Central Act No. 45 of 1860)."
10. Amendment of section 56, Rajasthan Act No. II of 1950. - In section 56 of
the principal Act,-

<!-- page 6 -->

(i)

for the expression "which shall not be less than six months and may
extend to three years and also with fine which shall not be less than rupees
two hundred and may extend to one thousand rupees", the expression
"which shall not be less than two years but which may extend to five years
and with fine of two lakh rupees or five thousand rupees per bulk liter of
denatured spirit or denatured spirituous preparation involved, whichever is
higher." shall be substituted; and

(ii)

after section 56, so amended, following explanation shall be added,
namely :"Explanation.- For the purposes of this section it shall be presumed,
unless and until the contrary is proved, that any spirit, which is proved on
chemical analysis to contain any quantity of any of the prescribed
denaturants, is or contains or has been derived from denatured spirit."

11.
Amendment of Section 58, Rajasthan Act No. II of 1950.- In section 58
of the principal Act, for the expression "which may extend to five hundred rupees", the
expression" of five thousand rupees" shall be substituted.
12.
Insertion of section 58A, Rajasthan Act No. II of 1950.- After the
existing section 58 of the principal Act, the following new section shall be inserted,
namely :"58A. Penalty for adulteration, etc., by licensed vendor or manufacturer.Whoever being the holder of a license for the sale or manufacturer of any intoxicant
under this Act, or a person in the employment of such holder:(a)

mixes or permits to be mixed with intoxicant sold or manufactured by him
any noxious drug or any foreign ingredient likely to add to its actual or
apparent intoxicating quality, or any article prohibited by any rule made
under this Act where such admixture does not amount to the offence of the
adulteration under section 272 of the Indian Penal Code, 1860 (Central
Act No. 45 of 1860); or

(b)

sell or keeps or exposes for sale as foreign liquor, liquor which he knows
or has reason to believe to be Indian made foreign liquor; or

(c)

marks any bottle or the cork of any bottle, case, packing or other
receptacle containing Indian made foreign liquor, or uses any bottle, case,
package or other receptacle, with any mark thereon or on the cork thereof,
to contain Indian made foreign liquor with the intention for causing it to
be believed that such bottle, case, package or other receptacle contains
foreign liquor, when such act shall not amount to be offence of using a
false property mark with intention to deceive or injure any person under
section 482 of the Indian Penal Code, 1860 (Central Act No. 45 of 1860);
or

<!-- page 7 -->

(d)

sells or keeps or exposes for sale any Indian made foreign liquor in a
bottle; case, package or other receptacle with any mark thereon or on the
cork thereof with the intention of causing it to be believed that such bottle,
case, package or other receptacle contains foreign liquor, when such act
shall into amount to be offence of selling goods marked with a counterfeit
property mark under section 486 of the Indian Penal Code, 1860 (Central
Act No. 45 of 1860); or

(e)

makes any block for the purpose of counterfeiting excise adhesive labels
or holograms or prepares copies by any means of such labels or holograms
for the purpose of counterfeiting such labels or holograms or counterfeits
excise adhesive labels or holograms or makes any block for the purpose of
counterfeiting corks or capsules to be used on bottles, cases, packing or
other receptacles containing Indian made foreign liquor or foreign liquor
or counterfeits such corks or capsules or is in possession of counterfeit
excise adhesive labels, holograms, corks, capsules or blocks or any other
material to be used for counterfeiting such labels, holograms, corks,
capsules,

Shall, on conviction, be punished with imprisonment, (i)

in case of first offence, for a term which shall not be less than one year but
which may extend to three years and with fine which shall not be less than
ten thousand rupees but which may extend to three lakh rupees;

(ii)

in case of a second or subsequent offence, for a term which shall not be
less than two years but which may extend to five years and with fine
which shall not be less than fifty thousand rupees but which may extend to
five lakh rupees.

Explanation. - For the purposes of this section, the expression
"counterfeit" shall have same meaning as is in section 28 of the Indian Penal
Code,1860 (Central Act No. 45 of 1860)
13.
Insertion of section 61A, Rajasthan Act No. II of 1950.- After the
existing section 61 and before section 62, the following new section shall be inserted,
namely:" 61A Penalty for certain acts and omissions by Excise Officers.- If any
Excise Officer unlawfully releases or abets the escape of any person arrested under this
Act or acts in any manner inconsistent with his duty for the purpose of enabling any
person to do anything whereby any of the provisions of this Act may be evaded or
contravened or the excise revenue may be defrauded, he shall be punished with
imprisonment for a term, which shall not be less than three months but which may extend
to one year :

<!-- page 8 -->

Provided that no court shall take cognizance against any officer under this section
without prior permission of the State Government".
14.

Amendment of section 66, Rajasthan Act No. II of 1950.-

(i)

for the existing expression " If any person" the expression "Except as
provided in section 58A, if any person" shall be substituted ;

(ii)

the existing first proviso shall be deleted;

(iii)

in second proviso, for the existing expression "the offences referred to in
proviso to section 54", the expression "any offence under this Act" shall
besubstituted.

15.
Amendment of section 67, Rajasthan Act No II of 1950:- In section 67
of the principal Act,(i)

in the marginal head of the section, for the existing expression .
"Cognizance of offences and credit of fines to Excise Department " and
credit of fines to Excise Department" shall be substituted.
ii) in sub-section (1),-

(iii)
" (3)

16.

(a)

inc clause (a), for the existing expression "Section 54", the
expression "section 54 or section 54B or section 58A or section
54D" shall be substituted ; and

(b)

in clause (b), for the existing expression "or section 58 the
expression "or section 58A" shall be substituted; and

after the existing sub-section(2), the following new subs-section
shall be inserted, namely:-

Notwithstanding anything in any other law for the time being in force in
the State, all sums realized on account of fines imposed by a Magistrate on
conviction of a person for any offence this Act, shall, on such realization,
be credited to the head of account to which the receipts of the Excise
Department are credited, after deduction the expenses incurred in
connection with such realization."-

Amendment of section 69, Rajasthan Act.II of 1950,- (1) In section 69 of the
principal Act,(i) in the proviso to sub-section (2), for the existing punctuation mark"." ,
appearing at the end, the punctuation mark ":" shall be substituted and after
the existing proviso, so amended, the following new proviso shall be added,
namely:-

<!-- page 9 -->

" Provided further that, if the excisable articles seized in connection with an offence
under this Act are such as cannot be legally sold in Rajasthan in the form they were
seized, such excisable articles may be ordered to the confiscated by the District
Excise Officer concerned, whether or not the offence is compounded."; and
(ii) after the existing sub-section (2) and before the existing sub-section (3)
the following new sub-sections (3) the following new sub-sections shall be
inserted, namely :"(2A) Where the District Excise Officer, after passing an order of confiscation under
sub-section (2) is of the opinion that it is expedient in the public interest to do
so, order the confiscated excisable articles or any part thereof to be sold by
public auction or to be destroyed or disposed of departmentally in accordance
with the rules made by the State Government in this behalf.
(2B) Whenever any excisable article is seized under sub-section. (1), the District
Excise Officer shall have, and, notwithstanding anything contained in any
other law for the time being in force, any court, tribunal or other authority
shall not have, jurisdiction to make order with regard to the possession,
delivery, disposal and release of such property."

Sd/(Mahesh Bhagwati)
Secretary to the Government
