---
doc_id: "4c82acc5cfcb8b05"
source_url: "https://www.vmou.ac.in/sites/default/files/2026-10-tenderqsppp/bid%20document.pdf"
ministry: "Vardhaman Mahaveer Open University (VMOU), Kota"
title: "bid document.pdf"
date: ""
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "17188e924c397b1c"
---

<!-- page 1 -->

VARDHMAN MAHAVEER OPEN UNIVERSITY, KOTA
Rawathbhata Road, Kota -324021
NIB NO. 18/2026-27

Date: 30.09.2026
NOTICE INVITING BID

On behalf of the Hon’ble Governor of Rajasthan, Bids are invited for “ARC for Supply of Envelopes” under
single stage two envelope system under the RTPP Rules, 2013 as given belowName of work

1

Estimated
Cost Rs.

BID
Security
Rs.

ARC for Supply

of Envelopes

3.80 Lakh

Rs7600/-

BID
Form
Fee
Rs.

Date of
Availability of
BID

Last date of
submission
of BID

Date of
opening of

validity
Period

BID

30/09/2026
(2:00PM) To
12/10 /2026 upto 13/10/2026 14/10/2026
5:00pm
500.00
upto 5.00 PM at 11.00 AM 90 days

Instructions to Bidders:1.
The detailed scope of work as well as terms and conditions for “ARC for Supply of Envelopes” have been
given in the BID documents which may be downloaded from www.sppp.rajasthan.gov.in or University
website www.vmou.ac.in.
2.
The Interested bidders may submit their bids in a big sealed single envelope superscribing “ARC for Supplyof
Envelopes” containing two separate envelopes marked as “Technical Bid” and “Price Bid”. The sealed
envelope shall be reached at the office of Director , MP & D, VMOU, Kota, through registered post/parcel/
by hand upto last date and time as stated above.
3.
The Technical Bid shall contain the following:a.
Enclosed Original DD of Rs. 500 for Tender fee (Non – Refundable) &Rs. 7600 /- for bid security in favor of
Vardhaman Mahaveer Open University, Kota payable at Kota with the Technical Bid without which bid shall
not be considered.
b.
Copy of GST Registration and PAN shall be enclosed with the BID.
c.
Sample of Envelopes in 2 sets of all sizes & as per required specifications shall be attached with the
Technical Bid with seal & signature of Bidder.
d.
The bidder must submit terms and conditions as well as annexure I,II,III and IV (duly signed) with the BID.
4.
The Price bid shall contain Rates quoted by the bidder in prescribed format as enclosed here with. The
Price Bid will be opened only of the responsive bidders found qualified/ eligible in Technical Bid.
5.
In the event of the specified dates being a holiday, the activities assigned on that date may be carried out on
next working day on the same time.
6.
VMOU, Kota is not bound to accept the lowest bid and may reject any bid or any part of the bid without
assigning any reason therefore.
7.
Bids received after the prescribed time and date will not be considered.
8.
Validity: - 90 days from the opening of Technical Bid.
9.
In case of any query, the undersigned (Procurement Entity) may be contacted e-mail at mpd@vmou.ac.in
10. Corrigendum if any will be published on above website only.
11. Conditional tender will not be accepted.
12. The bidder must not be black listed anywhere and self-declaration has to be submit with bid documents.
13. Bidder or their Authorized representative may attend at the time of opening of the tender.
14. The price Bid shall contain Rates quoted by the bidder in prescribed form as enclosed herewith.

Director (M.P.& D.)

<!-- page 2 -->

VARDHMAN MAHAVEER OPEN UNIVERSITY, KOTA
Rawathbhata Road, Kota -324021
Technical Bid
(ARC for Supply of Envelopes)

1. NIB No and Date

:------------/2026-2027 Date : ……………..

2. Name of Bidder

:-

3. Full Address

:-

4. Contact No.

:-

5. Email Address

:-

6. Eligibility criteria
:-Bidder attached the following documents with the technical
Bid other wise tender will not be accepted and treated as rejected.

a. Original DD of Rs. 500 for Tender fee (Non – Refundable) &Rs. 7600/- for bid security in
favor of VardhamanMahaveer Open University, Kota payable at Kota

b. The bidder must submit terms and conditions as well as annexure I, II, III and IV (duly

signed) with the BID.
c. Sample of Envelopes in 2 sets of all sizes & as per required specifications shall be attached
with the Technical Bid with seal & signature of Bidder. The samples will be examined and
inspected by the procuring committee at the time of opening the technical bid. Price
Bid will be opened of those bidder whose samples are found suitable
d. Copy of GST Registration No. shall be enclosed.
e. Copy of PAN No. shall be enclosed.
f. Bidder self-declaration for not black listed anywhere enclosed.
g. Bidder shall enclose turn over certificate duly attested by the C.A. of last three F.Y.i.e.
2023-24, 2024-25, 2025-26 separately which should be not less than 08.00 lakhs each
year.
h. Experience certificate – Bidder shall enclose the single or multiple work/supply order of
same work of total Rs. 6.00 lakh or more in last three financial year i.e. 2023-24, 202425, 2025-26 issued by any Institutions.
In absence of above documents with technical bid, the financial bid will not be open.
Note: - I have read the tender terms and conditions of contract carefully and I shall be
abide by the same.
Date:
Place:

Signature & Seal of the bidder

2

<!-- page 3 -->

VARDHMAN MAHAVEER OPEN UNIVERSITY, KOTA
Rawathbhata Road, Kota -324021

Price Bid
(ARC for Supply of Envelopes)
NIB No and Date
Name of Bidder
Full Address
Contact No.
Email Address
GST Registration No.
PAN No.
Work Description

:::::::-

S.No.

Rate per
Thousand
(Without
GST)
3

Description
1
1.

2

GST
Amount

Total Amount
for per Thousand
(3+4)

4

5

Thread kraft envelops with one side Printing.
(140Gsm Kraft paper with 44 Thread per square inch )
(A) - Size 12" x 9" x 3" (Box Type) without flep
(B) - Size 12" x 9" x 4" (Box Type) without flep
(C) - Size 12" x 9" x 5" (Box Type) without flep
(D) - Size 12" x 9" x 8" (Box Type) without flep

Note –
1. Packing ,Forwarding, Transportation ,Loading and Unloading etc. Charges shall be
included in the above quoted rates.
2. F.O.R. at M.P. & D Division , V.M.O.U., KOTA.
3. Items must have these mentioned specifications.
Date:…………
Place:……….

Signature of the bidder with Seal

3

<!-- page 4 -->

VARDHMAN MAHAVEER OPEN UNIVERSITY, KOTA
Rawathbhata Road, Kota -324021

CONDITION OF BID & CONTRACT
Note:-Bidders should read these conditions carefully and comply strictly while submitting their
tenders.
1. Tenders by bona-fide dealers:-Tenders shall be given only by reputed & registered / firm/ agencies
2.

a.

3.
4.
5.
6.

7.

dealers /manufactures of the goods. They shall,therefore, furnish a declaration.
Any change in the constitution of the firm, etc. shall be notified forth with by the contractor in writing to the
Registrar and such change shall not relieve any former member of the firm, etc. from any liability under the
contract.

No new partner/partners shall be accepted in the firm by the contractor in respect of the contract unless
he/they agree to abide by all its terms, conditions and deposit with the Registrar a written agreement to
this effect. The Contractor's receipt for acknowledgment or that of any partners subsequently accepted as
above shall bind all of them and will be sufficient discharge or any of the purpose of the contract.
Rate shall be written both in words and figures. There should not be errors and/or overwriting.
Corrections if any should be made clearly and initialed with dates.
All rates quoted must be FOR at MP&D VMOU Kota Raj.Including Goods and Service Tax as GST as
applicable shall be borne by the university.
Validity: - Tender shall be valid for a period of three months from the date of opening of technical bid.
The approved supplier shall be deemed to have carefully examined the conditions, specifications, size,
make, and drawings, etc. of the goods to be supplied. If he has any doubts as to the meaning of any
portion of these conditions or of the specification, drawing etc., he shall, before signing the contract,
refer the same to the purchase officer and get clarification.
The Contractor shall not assign or sub-let his contract or any substantial part thereof to any other agency.

8. Specifications:(i)

All article supplied shall strictly VMOU, Kota conform to the specifications, trade mark laid down in the
tender form and wherever articles have been required according to ISI specifications, those articles
should conform strictly to those specifications and should bear such marks.
The decision of the purchase committee whether the articles supplied conform to the specifications and are in
accordance with the samples , if any, shall be final and binding on the bidders.
Warranty/Guarantee Clause:- The bidder would give guarantee that the goods/stores/articles would
continue to conform to the description and quality as specified for a period of one year from the date of
delivery of the said goods/stores/articles to be purchased and that not with standing the fact that the
purchaser may have inspected and/or approved the said goods/stores/articles, if during the aforesaid
period of one year the said goods/stores/articles be discovered not to confirm to the description and
quality aforesaid or have determined(and the decision of the purchase committee in that behalf will be
final and conclusive), the purchaser will be entitled to reject the said goods/stores/articles or such portion
thereof as may be discovered not to conform to the said description and quality on such rejection the
goods/stores/articles will be at the sellers risk and all the provisions relating to rejection of goods, etc.,
shall apply. The bidder shall if so called upon to do, replace the goods, etc. or such portion thereof as is
rejection by the purchase committee, otherwise the bidder shall pay damage as may arise by reason of
the breach of the condition herein contained. Nothing herein contained shall prejudice any other right of
the purchase committee in that behalf under this contract or otherwise.

(ii)

(iii)

9. Inspection:(a)

The University inspection committee/UPC authorized shall have time to inspect and examine the materials
and workmanship of the goods/equipments/machineries during manufacturing process or afterwards as may
be decided.

(b)

The tender shall furnish complete address of the premises of his office, godown and workshop where
inspection can be made together with name & address of the person who is to be contacted for the
purpose. In case of those dealers who have newly entered in business , a letter of introduction from their
bankers will be necessary.
Samples:-Tenders for articles marked within the schedule shall be accompanied by samples of the
articlestendered properly packed & signed . Such samples if submitted personally will be received in the
office.A receipt will be given for each sample by the officer receiving the samples. Samples if sent by train
etc. should be dispatched fright paid and the R/R or G.R. should be sent under a separate registered cover.
Each sample shall be marked suitably either by written on the sample or on a slip of durable paper securely
fastened to the sample, the name of the bidder and serial number of the item, of which it is a sample in the
schedule.





4

<!-- page 5 -->



Approved samples would be retained free of cost upto the period of six months after the expiry of the
contract. The VMOU, Kota shall not be responsible for any damage, wear and tear or loss during testing,
examination, etc during the period these samples are retained. The sample shall be collected by the bidder on
the expiry of stipulated period. The VMOU, Kota shall in no way make arrangements to return the samples.
The samples uncollected within 9 months after expiry of contract shall be forfeited by the VMOU, KOTA and
no claim for their cost, etc., shall be entertained.



Samples not approved, shall be collected by the unsuccessful bidder. The VMOU, KOTA will not be
responsible for any damage, wear and tear, or loss during testing, examination, etc, during the period
these samples are retained. The uncollected samples shall be forfeited and no claim for their cost, etc.,
shall be entertained.
Supplies when received shall be subject to inspection to ensure whether they conform to the
specifications or with the approved samples. Where necessary or prescribed or practical , tests shall be
carried out by VMOU, KOTA through Govt. Laboratory. If GSM and Thread per square inchcomes
below the standard then deduction of amount will be done in proportionate from the total cost of
particular envelopes as follows :(i) For less value of GSM in percentage from specified value the deduction will be done from 35% value
of particular size of envelope in proportionately.
(ii) For less value of TPI in percentage from specified value the deduction will be done from 35% value
of particular size of envelope in proportionately
(iii) For Other defects such as pasting & size, penalty will be deducted from 30% value of particular size
of envelope.

10

11 Testing Charges:-Testing Charges shall be borne by the VMOU, KOTA . In case urgent testing is desired
to bearranged by the bidder or in case of test result showing that supplies are not up to the prescribed
standards or specifications , the testing charges shall be payable by the bidder.

(i)

12 Rejection:-

Articles not approved during inspection or testing shall be rejected and will have to be replaced by the
bidder at his own cost within the time fixed by the purchase committee.
(ii)
If, however, due to exigencies of VMOU, KOTA, such replacement either in whole or in part, is not
considered feasible, the purchase committee after giving an opportunity to the bidder of being heard,
shall for reasons to be recorded, deduct a suitable amount from the approved rates. The deduction so
made shall be final.
13. The Rejected articles shall be removed by the bidder within 15 days of intimation of rejection, after
which Director, MP&D, shall not be responsible for any loss, shortage or damage and shall have the
right to dispose of such articles as he thinks fit, at the bidder’s risk and on his account.
14. The bidder shall be responsible for the proper packing so as to avoid damage under normal conditions of
transport by sea, rail and road pr air and delivery of the material in good condition to the consignee at
destination. In the event of loss, damage, breakage or leakage or any shortage the bidder shall be liable to
make goods such loss and shortage found at the checking/inspection of the materials by the consignee. No
extra cost on such account shall be admissible.
15. The contract for the supply can be repudiated at any time by the Director, MP & D. if the supplies are
not made to his satisfaction after giving an opportunity to the bidder of being heard and recording of the
reasons for repudiation.
16. Direct & indirect canvassing on the part of the bidder or his representative will be a disqualification.
17. (i) Delivery Period:-The bidder whose tender is accepted shall arrange supplies of items withina period of
60 daysfrom the date of supply order issued by the university. However, the approved rates shall

bevalid for One year from the date of award of contract. The period of contract shall be further
extendedas per RTPP Rule.
(ii) Extent of Qty.-Repeat orders:- If the orders are placed in excess of the quantities shown in the tender
notice,the bidder shall be bound to meet the required supply. Repeat orders may also be placed on the rate and
conditions given in the tender provided that the repeat orders are up to 50% of the quantity originally
purchased and the period is not more than one month from the date of expiry of last supply. If the bidder fails
to do so, the Registrar shall be free to arrange for the balance supply by limited tender or otherwise and the
extra cost incurred shall be recoverable from the bidder.

(iii)

If the Director M.P.D. does not purchase any of the tendered articles or purchase less than the quantity
indicated in the tender form, the bidder shall not be entitled to claim any compensation.

18.

Bid Security:-

(a)

Tender shall be accompanied by an B.S. of Rs. @ 2% of estimated cost of the item without which
tenders will not be considered. The amount should be deposited in either of the following forms in

5

<!-- page 6 -->

favour of VardhmanMahaveer Open University, KOTA. (i) Bank Drafts/Bankers Cheque of the
scheduled Bank.
(b)
Refund of B.S.: The B.S. of unsuccessful bidder shall be refunded soon after final acceptance of tender.
(c)
Partial exemption from B.S.:- Firms which are registered with Director of Industries Rajasthan, shall
furnish the amount of earnest money in respect of items for which they are registered as such subject to
their furnishing registration certificate in original or Photostat copy or a copy thereof duly attested by
any Gazetted Officer from the Director of Industries Rajasthan , at the rate of 0.5% of the estimated
value of the tender shown in NIT.
(d)
The Central Government and Government of Rajasthan undertakings need not furnish any amount of
earnest money/B.S..
(e)
The earnest money/security deposit lying with the Department/office in respect of other tenders awaiting
approval or rejected or on account of contracts being completed will not be adjusted towards earnest
money/security money for the fresh tenders. The earnest money may however, be taken into
consideration in case tenders are re-invited.
19. Forfeiture of B.S.:- The B.S. will be forfeited in the following cases:
(a)
When bidder withdraws or modifies the offer after opening of tender but before acceptance of tender.
(b)
When bidder does not execute the agreement if any, prescribed within the specified time.
(c)
When the bidder does not deposit the security money after the supply order is given.
(d)
When he fails to commence the supply of the items as per supply order within the time prescribed.

20. Agreement and Security Deposit:(a)

Successful bidder will have to execute an agreement in the Form SR-17 and deposit security equal to 5%
of the value of the stores for which tenders are accepted within 07 days from the date of dispatch on
which the acceptance of the tender is communicated to him.
(b)
The BID security deposited at the time of tender will be adjusted towards security amount. The Security
amount shall in no case be less than BID security.
(c)
No interest will be paid by the department on the Security money.
(d)
The form of Security Money shall be as below:
a. Bank Draft/Bankers Cheque.
b. Post-office Savings Bank Pass book duly pledged.
c. National Savings Certificate, Defence Savings Certificates, KisanVikasPatras, or any other script
/instrument under National Savings Scheme for promotion of small savings, if the same can be pledged.
These certificates shall be accepted at surrender value.
d. Bank guarantee issued by any of scheduled bank.
(E) The security money shall be refunded after one month of the final supply of the items as per purchase order in
case of one time purchase and two months in case deliveryis staggered, after the expiry of contract on
satisfaction completion of the same or after the expiry of the period of guarantee if any, whichever is later and
after satisfied that there are nodues outstanding against the bidder.
21.
(i) Firms Registered with the Director of Industries Rajasthan in respect of stores for which they are
registered, subject to their furnishing the registration in original from the Director of Industries or a
Photostat copy or a copy
thereof duly attested by any Gazetted Officer will be partially exempted from
earnest money and shall pay security
deposit at the rate of 1% of the estimated value of tender.
(ii) Central Government and Government of Rajasthan Undertaking will be exempted from furnishing
security amount.
22.
Forfeiture of Security Deposit:- Security amount in full or part may be forfeited in the following cases:
a. When any terms and conditions of the contract is breached.
b. When the bidder fails to make complete supply satisfactorily.
c. Notice of reasonable time will be given in case of forfeiture of security deposit.

23.
24.
(i)

(ii)

The decision of the purchase officer in this regard shall be final. The expenses of completing and
stamping the agreement shall be paid by the bidder and the University shall be furnished free of
charge with one executed stamped counter part of the agreement.
Insurance:The goods will be delivered at the destination in perfect condition. The supplier, if he so desires, may be
insured the valuable goods against loss by theft, destruction or damage, by fire, flood, under exposure to
whether or otherwise viz. (war, rebellion, riot etc.) The insurance charges will be borne by the supplier
and state will not be required to pay such charges incurred.
The articles may also be got insured at the cost of the purchaser, if so desired by the purchaser. In such
cases, the insurance should invariably be with Life Insurance Corporation of India or its subsidiaries.

25.

Payments:-

(i)

Unless otherwise agreed between the parties, payment for the delivery of the stores will be made on
completion of supply satisfactorily and on submission of bill in proper form by the bidder to the Director
M.P.D. in accordance with GF & AR all remittance charges will be borne by the bidder.

6

<!-- page 7 -->

(ii)
(iii)

26

In case of disputed items, 30% of the amount shall be with held and will be paid on settlement of the
dispute.
Payments in case of those goods which need testing shall made only when such tests have been carried
out, test results received conforming to the prescribed specification. If tests results found less than the
prescribed parameters ,the amount will be deducted in the ratio of test results and parameters separately.
(i) The time specified for delivery in the tender form shall be deemed to be the essence of the contract
and the successful bidder shall arrange supplies within the period on receipt of the firm order from the
purchase officer.
a. Liquidated Damages:- In case of extension in the delivery period with liquidated damage the
recovery shall be made on the basis of following percentage of value of stores which the bidder
has failed to supply:Delay up to one fourth period of the prescribed delivery period
2½%
Delay exceeding on front but not exceeding half of the prescribed period
5%
Delay exceeding half but not exceeding three fourth of the prescribed period
7½%
Delay exceeding three fourth of the prescribed period
10%
(i)
Fraction of a day in reckoning period of delay in supplies shall be eliminated if it is less
than half a day.
The maximum amount of liquidated damage shall be 10%
(ii)
If the supplier requires an extension of time in completion of contractual supply on
account of
occurrence of any hindrance , he shall apply in writing to the
authority , which has placed the supply
order, fro the same immediately on
occurrence of the hindrance but not after the stipulated date of completion of supply.
(iii)
Delivery period may be extended with or without liquidated damages if the delay in
the supply of goods is on account of hindrances beyond the control of the bidder.

Risk & Cost clause:-

The competent authority of VMOU, KOTA without prejudice to his right against the approved
supplies in respect of any delay or inferior performance of otherwise or claims for delay in
respect of any breaches of the contract and without prejudice to any rights or remedies under
any of the provisions of the contract or otherwise, by notice in writing absolutely determined
the contract in any of the cases.
(i)
A notice in writing to rectify, or otherwise that the work being performed is inefficient or otherwise
implemented in improper manner, shall omit to comply with the requirement of such notice within
a period of 07 days or for prescribed time, thereafter of if the supplier shall delay or suspended the
execution of the work so that either in the judgment of the competent authority, he will be unable to
perform the work by the satisfaction of VMOU, KOTA or has already failed to complete the work
by the time.
(ii)
If the supplier commits breach of the terms & conditions the contract.
(iii)
When the supplier has made himself liable for action under any of the cases aforesaid , the
competent authority, shall exercise power:(a) To determine or rescind the contract, as aforesaid, upon such determination or rescission, the
bid security, performance security shall be liable to be forfeited and shall be absolutely at the
disposal of VMOU, KOTA.
(b) To get the work done through other service provider and in such case any expenses which may
be incurred in excess, of the sum which would have been paid to the original SP, if the whole
work had been executed by him of the amount of which excess, the decision of the Incharge,
MP & D, VMOU, KOTA shall be final and conclusive and shall be borne and paid by the
original SP that may be deducted from any money due to him by the VMOU, KOTA or from
has bid security, performance security. However the original SP shall have no claim to
compensation for any loss sustained by him or reason for having purchased or procured any
material, equipments or entered into any engagements or made advances on account of
execution/performance of contract.

27.

Recoveries: -

Recoveries of liquidated damages, short supply breakage, rejected articles shall ordinary be
made from bills. Amount may also be withheld to the extent of short supply, breakages,
rejected articles and in case of failure in satisfactory replacement by the supplier along with
amount of liquidated damages shall be recovered from his dues and security deposit
available with the department.
28. If a bidder imposes conditions, which is in addition to or in confliet with the conditions
mentioned
herein, his tender is liable to summary rejection. In any case none of such
conditions will be deemed to have been accepted unless specifically mentioned in
the letter of acceptance of tender issued by the Controller of Examinations.
29. The university reserves the right to accept any tender not necessarily the lowest, reject any
tender without assigning any reasons and accept tender for all or anyone or more of the

7

<!-- page 8 -->

articles for which bidder has been given or distribute items of stores to more than one
firm/supplier.
30. The bidder shall furnish the following document at the time of execution of agreement:a. Attested copy of partnership deed in case of partnership firms.
b. Registration number and year registration in case partnership firm is registered with Registrar of
firms.
c. Address of residence and office, telephone numbers in case of sole proprietorship.
d. Registration issued by Registrar of Companies in case of company.
31.
If any dispute, arise out of the contract with regard to the interpretation meaning and branch of the
terms of the contract, the matter shall be referred to by the parties to the Head of the
University (HVC) who willappoints his senior most officer as the sole Arbitrator of the
dispute who will not be related to his contract and whose decision shall be final.
32.
All legal proceeding, if necessary arise to institute may by any of the parties (VMOU, Kota or
Contractor) shall have to be lodged in courts situated in Kota, Rajasthan and not elsewhere.
33.
VMOU, Kota is a Govt. university and liable to get maximum educational discount from
manufacturer,
please specifies it separately and provide attested copy of educational partner
(if any).
34.
Bidder should submit their Authorization letter/ Distributor certificate.
35.
The bid and contract shall be governed by the Rajasthan transparency in public
procurement Act2012 and rules 2013.
36.
In the event of inconsistency found between these terms and conditions and provisions as laid
down inRTPP Rules, 2013, the later shall be meant to final.
37.
In case, documents/undertaking submitted by the bidder is found false later on, the
concerned biddershall be wholly responsible for all the consequences arising out of them.
38.
If Bid submitted with any terms and conditions other than mentioned in the tender document
shall be rejected.
39.
Decision of L – 1 bidder will be decided on the basis of item wise (i.e. size of envelopes)
40.
Income Tax & other Taxes if any will be deducted from the bills as per Govt. Rules.
Note: - I have read the above terms and conditions of contract carefully and I shall be abide by the same.

Date:
Place:

Signature & Seal of the bidder

8

<!-- page 9 -->

Annexure -I
Compliance with the code of integrity and no conflict of interest
a)
b)
c)
d)
e)
f)
g)
h)

1.

Any person participating in a procurement process shallNot offer any bribe, reward or gift or any material benefit either directly or indirectly in exchange for
an unfair advantage in procurement process or to otherwise influence the procurement process.
Not misrepresent or omit that misleads or attempts to mislead so as to obtain a financial or other
benefit or avoid an obligation.
Not indulge in any collusion, Bid rigging or anti-competitive behavior to impair the transparency,
fairness, and progress of the procurement process.
Not misuse any information shared between the procuring entity and the Bidders with an intent to gain
unfair advantage in the procurement process.
Not indulge in any correction including impairing or threatening to do the same, directly or indirectly,
to any party or to its property to influence the procurement process.
Not obstruct any investigation or audit of a procurement process.
Disclose conflict of interest, if any, and
Disclose any previous transgressions with any entity in India or any other country during the last three
years or any debarment by any other procuring entity.

Conflict of Interest:-

2.

The Bidder participating in a bidding process must have a conflict of interest.
A Conflict of interest is considered to be a situation in which a party has interests that could improperly
influence that party’s performance of official duties or responsibilities, contractual obligation, or
compliance with applicable laws and regulations.
A Bidder may be considered to be in conflict of interest with one or more parties in a bidding process if,
including but not limited to;
a. Have Controlling partners/shareholders in common; or
b. Receive or have received any direct or indirect subsidy from any of them; or
c. Have the same legal representative for purpose of the bid; or
d. Have the relationship with each other, directly or through common third parties, that puts
them in a position to have access have to information about or influence on the bid of another
Bidder, or influence the decision of the procuring entity the bidding process; or
e. The Bidder participates in more than one bid in a bidding process. Participation by a Bidder in
more than one bid will result in the disqualification of all Bids in which the Bidder is involved.
However this does not limit the inclusion of the same subcontractor , not otherwise
participating as Bidder, in more than one Bid; or
f. The Bidder or any of its affiliates participated as a consultant in the preparation of the design
or technical specification of the goods, works or service that are the subject of the Bid; or
g. Bidder or any of its affiliates has been hired (or is proposed to be hired) by the procuring
entity as engineer-in-charge /consultant for the contract.

Place:
Date:

Signature of the Bidder with seal

9

<!-- page 10 -->

Annexure -II
Declaration by the Bidder regarding qualifications
In relation to my/our Bid submitted to Director M.P.D., VMOU, KOTA, Kota for procurement of
“ARCfor Supply of Envelopes” in response to their Notice Inviting Bid No. ---/2026-2027 Dated ------------------ I/We hereby declare under section 7 of Rajasthan Transparency in Public
Procurement Act , 2012, that:
1. I/We possess the necessary professional, technical , financial and managerial resources and
competence required by the Biding Document issued by the Procuring Entity;
2. I/We have fulfilled my/our obligation to pay such of the taxes payable to the union and the State
Government or any local authority as specification in the Bidding Document;
3. I/We have are not insolvent in receivership, bankrupt or being wound up, not have my/our affairs
administrated by a court or a judicial officer , not have my/our business activities suspended and
not the subject of legal proceeding for any of the foregoing reasons;
4. I/We do not have, and our directions and officers not have, been convicted of any criminal offence
related to my/our professional conducted or the making of false statement or misrepresentations
as to my/our qualifications to enter into a procurement contract within a period of three years
preceding the commencement of this procurement process, or not have been otherwise
disqualified pursuant to debarment proceeding;
5. I/We do not have a conflict of interest as specification in the Act, Rules and the bidding document,
which material affects fair competition;

Date:
Place:

Signature of bidder with seal
Name:
Designation:
Address:

10

<!-- page 11 -->

Annexure III
Grievance redressal during procurement process
The designation and the address of the first appellate authority is Hon’ble V.C. VMOU, Kota.
The designation and the address of second Appellate Authority is Additional Chief Secretary (Higher
Education Govt. Rajasthan)

(1) Filing an appeal
If any bidder or prospective bidder is aggrieved that any decision, action or omission of the Procuring
Entity is in contravention to the provisions of the act or the rules or the Guidelines issued there under,
he may file am appeal to first Appellate Authority, as specified in the Bidding Document within a period
of ten days from the date of such decision or action, omission, as the case may be, clearly giving the
specific ground or grounds on which he feels aggrieved:
Providing that after the declaration of a bidder as successful the appeal may be filled only by a bidder
who has participated in procurement proceeding:
Providing further that in case a Procuring Entity evaluates the Technical Bids before the opening of the
Financial Bids, an appeal related to the matter of Financial Bids may be filled only by a Bidder whose
Technical Bid id found to be acceptable.
(2) The officer to whom an appeal is filled under para (1) shall deal with the appeal as expeditiously as
possible and shall endeavored to dispose it of within thirty days from the date of the appeal.
(3) If the officer designated under para (1) fails to dispose of the appeal filed within the period specified in para
(2), or if the Bidder or prospective bidder or the Procuring Entity is aggrieved by the order passed by the
Procuring Entity, as the case may be, may file a second appeal to second Appellate Authority specified in the
Bidder Document in this behalf within fifteen days from the expiry of the period specified in para (2) or of
the date of receipt of the order passed by the first Appellate Authority, as the case may be.

(4) Appeal not to lie in certain cases
No appeal shall lie against any decision of the Procuring Entity relating to the following matters, namely:-

(a) Determination of need of Procurement
(b) Provisions limiting participating of Bidders in the Bid process;
(c) The decision of whether or not to enter into negotiations;
(d) Cancellation of a procurement process ;
(e) Applicability of the provisions of confidentiality

(5) Form of appeal
(a) An appeal under para (1) or (3) above shall be in the annexed form along with as many copies as there
are respondents in the appeal.
(b) Every appeal shall be accompanied by an order appealed against, if any, affidavit verifying the facts
stated in the appeal and proof of payments of fee.
(c) Every appeal may be presented to first Appellate Authority or Second Appellate Authority, as the case
may be, in person or through registered post or authorized representative.

(6) Fee for Filling Appeal
(a) Fee for first appeal shall be two thousand five hundred and for second appeal shall be rupees ten
thousand, which shall be nonrefundable.
(b) The fee shall be paid in the form of bank demand draft or banker’s cheque of a Scheduled Bank in India
payable in the name of Appellate Authority concerned.

11

<!-- page 12 -->

(7) Procedure for disposal of appeal
(a) The first Appellate Authority or Second Appellate, as the case may be upon filing of appeal, shall issued
notice accompanied ny copy of appeal, affidavit and documents, if any, to the respondents and fix date
of hearing.
(b) On the date of fix hearing, the First Appellate Authority or second Appellate Authority , as the case may
be shall,(i) Hear all the parties to appeal present before him; and
(ii) Peruse or inspect documents , relevant records or copies thereof relating th the matter
(c) After hearing the parties , perusal or inspection of documents and relevant records or copies thereof
relating to the matter, the Appellate Authority concerned shall pass an order in writing and provide the
copy of order to the parties to appeal free of cost.
(d) The order passed under sub-clause (c) above shall also be placed on the State Public Procurement Portal.

Date:
Place:

Signature of the Bidder with seal

12

<!-- page 13 -->

1.
i.

ii.
iii.

Annexure-IV
Additional conditions of contract
Correction of arithmetical errors

Provided that a Financial Bid is substantially responsive, that Procuring Entity will correct arithmetical
errors during evaluation of Financial Bids on the following basis:
If there is a discrepancy between the unit price and the total price that is obtained by multiplying the unit
price and quality , the unit price shall prevail and the total price shall be corrected, unless in the opinion in
the Procuring Entity there is an obvious misplacement of the decimal point in the unit price, in which case
the total price as quoted shall govern and the unit price shall be corrected;
If there is a error in a total corresponding to the addition or subtraction of subtotals, the subtotals shall
prevail and the total shall be corrected; and
If there is a discrepancy between words and figures, the amount in words shall prevail, unless the amount
in figures shall prevail subject to (i) and (ii) above.
If the Bidder that submitted the lowest evaluated Bid does not accepted the correction of errors, its Bid
shall be disqualified and its Bid Security shall be forfeited or its Bid Securing Deceleration shall be
executed.

2.

Procuring Entity’s Right to very Quantities.

i.

At the time of award of contract, the quantity of goods, works or services originally specified in the Bidding
Document may be increased or decreased by a specified percentage, but such increase or decrease shall not
exceed twenty percent, of the quantity specified in the Bidding Document. It shall be without any change in the
unit price or other terms & conditions of the Bid and the conditions of contract.

ii.

If the Procuring Entity does not procure any subject matter of procurement or procures less than the
quantity specified in the Bidding Document due to change in circumstances, the Bidder shall not be
entitled for any claim or compensation except otherwise provided in the conditions of contract.
In case of Procurement of Goods or services, additional quantity may be procured by placing a repeat
order on the rates and conditions of the original order. However, the additional quantity shall not be more
than 25% of the value of Goods of the original contract and shall be within one month from the date of
expiry of last supply. If the Service Provider fail to do so, the Procurement Entity shall be free to arrange
for the balance supply by limited Bidding or otherwise and the extra cost incurred shall be recovered from
the Service Provider.

iii.

3.

Dividing quantities among one than more Bidder at the time of award (In case of procurement of
Goods)

As a general rule all the quantities of the subject matter of procurement shall be procured for the Bidder,
whose Bid is accepted. However, when it is considered that the quantity of the subject matter of
procurement to be procured is very large and it may not be in the capacity of the Bidder, whose Bid is
accepted, to deliver the entire quantity or when it is considered that the subject matter of procurement to
be procured is of critical and visit nature, the quantity may be divided between the Bidder, whose Bid is
accepted and the second lowest Bidder or even more Bidders in that order, in a fair, transparent and
equitable manner at the rates of the Bidder, whose Bid is accepted.

Date:
Place:

Signature of the Bidder with seal

13
