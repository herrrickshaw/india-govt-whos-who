---
doc_id: "badebc03abf42ae0"
source_url: "https://rajfab.rajasthan.gov.in/web/Documents/Notifications/Notification_20260701125120.pdf"
ministry: "Factories and Boilers Inspection Department, Rajasthan"
title: "Rajasthan Occupational Sefety Health Working Condition Rules ,2026"
date: ""
pages: 213
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fcc35b28a388499f"
---

<!-- page 1 -->

राजस्‍
थान‍राजपत्र
विशेषाांक
साविकार प्रकावशत

RAJASTHAN GAZETTE
Extraordinary

Published by Authority

आषाढ़ 09, मंगलवार, शाके 1948- जनू 30, 2026
Asadha 09, Tuesday, Saka 1948- June 30, 2026
भाग‍4 (ग)
उप-खण्ड‍(II)
राज्‍
य‍सरकार‍तथा‍अन्‍
य‍राज्‍
य‍प्राधिकाररयों‍द्वारा‍जारी‍ककये‍गये‍कानूनी‍आदे श‍‍
तथा‍अधिसूचनाएं।
Labour and Factories & Boilers Department
NOTIFICATION
Jaipur, june 30, 2026
S.O.23 .- Whereas, the draft of the Rajasthan Occupational Safety, Health and
Working Conditions Rules, 2026 was published as required by sub-section (1) of section 133,
sub-section (1) of section 135 and section 137 of the Occupational Safety, Health and
Working Conditions Code, 2020 (Central Act No. 37 of 2020) in the Rajasthan Gazette
Extraordinary Part 4 (ga) up-khand (II) dated 03.02.2026 inviting objections and suggestions
from all persons likely to be effected thereby, before expiry of forty five days from the date
on which copies of the Official Gazette containing the said draft rules were made available to
the public;
And whereas, copies of the Official Gazette in which the said draft rules were
published and made available to the public on 03.02. 2026;
And whereas, objections and suggestions received from the public on the said draft
rules were considered by the State Government;
Now, therefore in exercise of the powers conferred by section 133 and 135 of the
Occupational Safety, Health and Working Conditions Code, 2020 (Central Act No. 37 of
2020), the State Government hereby makes the following rules, namely:CHAPTER-I
Preliminary
1. Short title, extent and commencement.- (1) These rules may be called the
Rajasthan Occupational Safety, Health and Working Conditions Rules, 2026.
(2) They extend to the whole of the State of Rajasthan.
(3) They shall come into force from the date of their publication in the Official Gazette.
2. Definitions.- (1) In these rules, unless the subject or context otherwise requires,(a) “appendix” means appendix appended to the Schedule;

<!-- page 2 -->

444 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
(b) “authority" or "licensing authority” means the Chief Inspector-cum-Facilitator
or any officer appointed by the State Government for the purpose of these
rules;
(c) “Board” means Rajasthan State Occupational Safety and Health Advisory
Board constituted under these rules;
(d) “Chief Inspector-cum-Facilitator” means Chief Inspector-cum-Facilitator
appointed as such by the State Government under section 34;
(e) “code” means the Occupational Safety, Health and Working Conditions Code,
2020 (Central Act No. 37 of 2020);
(f) "confined space" means any space by reason of its construction as well as in
relation to the nature of the work carried therein and where hazards to the
persons entering into or working inside exist or are likely to develop during
working;
(g) "department" means Factories and Boilers Inspection Department, Government
of Rajasthan in relation to factories and Labour department, Government of
Rajasthan in relation to establishments other than factories;
(h) "District Magistrate", in relation to any establishment, means the District
Magistrate who is vested with the executive powers of maintaining law and
order in the revenue district in which the establishment is situated:
Provided that in case of an establishment, which is situated partly in one
district and partly in another, the District Magistrate for the purpose shall be
the District Magistrate authorised in this behalf by the State Government;
(i) “Factory Medical Officer” means a qualified medical practitioner appointed by
occupier of factory;
(j) “form” means a form appended to these rules;
(k) “Government” or “State Government” means Government of Rajasthan;
(l) “Inspector-cum-Facilitator (Medical)” means a qualified medical practitioner
appointed as Medical Officer by the State Government, in the department;
(m) "Labour Commissioner" means an officer as such or in the capacity of
Additional Labour Commissioner appointed by the State Government;
(n) "Lokseva Guarantee Adhinium" means the Rajasthan Guaranteed Delivery of
Public Services Act, 2011;
(o) “Major Accident Hazards (MAH) installations” has the same meaning as
defined in the clause (ja) of rule 2 of the Manufacture, Storage and Import of
Hazardous Chemicals Rules, 1989;
(p) "Maintained" means maintained in an efficient state, in efficient working order
and in good repair;
(q) "Manager" means the responsible person declared by the occupier or employer
for the working of the factory or establishment for the purposes of the Code;
(r) “Non-hazardous process" means a process which is not covered under clause
(za) of sub-section (1) of section 2 or under section 82 of the Code or under
the Manufacture, Storage and import of Hazardous Chemical Rules, 1989;
(s) "Qualified Nurse" means a person who possesses a qualification in nursing
recognized under the Indian Nursing Council Code, 1947, and who is
registered with the Rajasthan Nursing Council;

<!-- page 3 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍445

(t) “Official Portal” means the LDMS web application of the Labour Department
and the RajFAB web application of the Factories and Boilers Inspection
Department or any other official website of the State Government, called by
any other name, to provide a gateway for the purposes of the Code and these
rules;
(u) "Personal protective equipment" means items of personal protective equipment
conforming to the relevant National Standards specifications;
(v) “Registering Officer” means the Chief Inspector-cum-Facilitator or any other
officer appointed by the State Government for the purpose of these rules;
(w) "Schedule" means a schedule of these rules;
(x) “Section” means the section of the Code;
(y) "workplace" means all places where,(i) building workers or employees are required to be present or to go for
work and which are under the control of an employer or
(ii) workers or employees are required to be present or to go for work and
which are under the control of an occupier.
(2) Words and expressions not defined under these rules but defined or used under the Code
shall have the same meaning as assigned to them in the Code.
3. Income from the sources.- For the purpose of Explanation to clause (x) of subsection (1) of section 2, income and sources of income shall be such as specified by the State
Government, from time to time.
4. Hazardous substance.- Hazardous substance or quantity of substance under
clause (zb) of sub-section (1) of section 2 shall be the substances as specified in clause (e) of
rule 2 of the Manufacture, Storage and Import of Hazardous Chemicals Rules, 1989 (MSIHC
Rules) and being used in the manufacturing process except the use in the testing labs in the
premises of factory or establishment.
CHAPTER-II
Registration
General provisions for registration
5. General provisions for registration under section 3.- (1) The general provisions
for registration are as under,(a) The employer or occupier seeking registration for an establishment or factory,
not already registered shall apply electronically in Form-1 on the Official Portal
by giving details about the establishment, and uploading documents related to
Registration of the establishment or factory, proof of Identity and address of the
occupier or employer and manager specified in the Form and other documents
as specified in the Official Portal. The Form shall be signed digitally or in any
other manner as may be required in the Official Portal. The applicant shall be
responsible for veracity of all information submitted in the application.
(b) The Permanent Account Number (PAN) of the applicant or the establishment
allotted under the Income Tax Act, 1961 or any other unique number allotted to

<!-- page 4 -->

446 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
the factory or establishment under any other Act for the time being in force or
any other particular furnished in the form, may be verified online.
(c) Every application referred to in clause (a) shall be accompanied by a proof of
payment of fees, as specified in relevant rule for such establishment or factory
for the registration of the establishment or factory through Official Portal.
(d) The certificate of registration shall be issued in Form-2 electronically, if the
application received under clause (a) is complete in all respect, within such time
limit as prescribed under the Loksewa Guarntee Adhinium or rules made by the
Central Government under the Code, whichever is less, for such service, failing
which such establishment shall be deemed to have been registered and the
certificate of registration shall be auto generated:
Provided that in exceptional circumstances the State Government may, for
such period, by notification, as specified therein dispense with requirement of
electronic registration, in respect of establishment or class of establishment, for
part or whole of the State, and submission of application in the form so
provided, may be allowed.
(e) The certificate of registration shall be non-transferable and a copy of the
certificate of registration shall be displayed in the premises of the establishment
or factory at the conspicuous place(s) in hard copy or electronically.
(2) The registering officer under these rules may direct the employer or occupier, who
fails to comply with the requirements of sub-rule (1), to comply with such requirements
within the time stated therein and such occupier or employer shall thereupon comply with
the directions issued by such Officer in this behalf.
(3) The employer or the occupier in respect of an establishment or factory already
registered under any other central labour law for the time being in force shall update the
registration particulars on the Official Portal, within six months from the date on which
the Code comes into force.
(4) Any registration obtained by providing wrong information shall be liable to be
cancelled provided that establishment or factory has been given an opportunity to show
cause within a period of 30 days, electronically or by registered post or by speed post, as
to why the certificate of registration should not be cancelled.
(5) The employer or the occupier shall quote the Registration Number on all documents
prepared or completed by him in connection with the Code or the rules or the regulations
or the scheme, as the case may be, and in all correspondence with the office concerned.
(6) Any change in the ownership, management or any particular furnished for registration
in Form-1 submitted on the Official Portal, shall be updated on the portal by the employer
or occupier within thirty days of such change.
(7) The employer of an establishment to which the provisions of the Code apply and
whose business activities are in process of closure, may apply for cancellation of
registration online on the Official Portal after giving complete details of the dues payable
under the Code and rules made thereunder:
Provided that no such application for cancellation of registration shall be entertained
unless the employer has furnished all statutory returns, paid all statutory dues payable
under the Code and rules made thereunder and submitted a self-certification to that effect
along with the application.

<!-- page 5 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍447

(8) The registering officer shall maintain a register of establishment electronically in
Form-3 showing the particulars of establishment in relation to which certificates of
registration have been issued by him.
(9) The employer shall, within thirty days of the commencement and completion or
cessation of any work, intimate to the Inspector-cum-Facilitator having jurisdiction in the
area where the proposed establishment is situated or as the case may be, the work is to be
executed, intimating the actual date of the commencement and, completion of work or
cessation of work, as the case may be, in Form-4 electronically and the same shall be
auto-shared to Employees' Provident Fund Organization (EPFO) and Employees' State
Insurance Corporation (ESIC).
(10) All fees payable under this rule shall be credited into the Government treasury under
the head of the account notified in this regard.
(11) Every fee for an application under these rules shall be paid online on Official Portal.
(12) If an application for the grant of registration, renewal or amendment of a registration
or licence is rejected, the fees paid shall not be refunded to the applicant.
(13) Where such application is granted, any amount paid by the applicant in excess of the
prescribed fee shall be refundable only after the expiry of one year from the date of such
grant or the same may be adjusted against payment of any fees due for the next
succeeding year.
Provided that an establishment shall be deemed to have registered under the
Rajasthan Shop and Commercial Establishment Act, 1958 if the establishment is
registered under the Code.

Factories
6. Information, Registration and Licence of factories.- (1) The occupier of every
factory coming within the scope of the Code, after its commencement, shall apply
electronically to the Registering Officer or Authority, as the case may be, by giving details
about the factory and uploading documents related to Registration of the factory and
application in Form-1 and related to license of factory in Form-5 or submit an application as
per the provisions of the Rajasthan Enterprises Single Window Enabling and Clearance Act,
2011, for the registration of the factory and grant of a single or common licence therefore for
a period not exceeding 10 years for factories. The Form-1 and Form-5 shall be signed
digitally or in any other manner as may be required on the Official Portal. The applicant shall
be responsible for veracity of all information submitted in the application. Every application
submitted under this sub-rule shall be accompanied with proof of payment of fee specified in
sub-rule (2).
(2) Every such application shall be accompanied by online payment of the fee as specified in
Fees Table-A or Fees Table-B, as the case may be, given below:- .

<!-- page 6 -->

448 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
Fees Table-A
Scale of Fees payable per year for Registration, Licence and Renewal of Licence for the
Factories other than Electricity Generating, Transforming or Transmitting Factories
Quantity Fees in rupees and Maximum number of persons to be employed on any day during
Of H.P.
the year
Installed (max.) Up to 09

10 to 20

21 to 50 51 to 100

up to

101 to

251 to

501 to

751 to

1001 to

1501 to

2001 to

250

500

750

1000

1500

2000

3000

Above 3000

Nil

400

800

1600

3400

4800

8200

12400

18200

20600

24800

33000

41400

10

800

1600

3400

5400

8200

12400

16400

24800

30200

34200

44000

55200

50

1600

3400

5400

8200

12400

16400

24800

33000

41400

52400

57800

69000

100

3400

5400

8200

12400

16400

24800

33000

41400

52400

57800

69000

82800

250

4800

8200

12400

16400

24800

33000

41400

52400

57800

69000

82800

103400

500

8200

12400

16400

24800

33000

44000

57800

69000

82800

103400 124200

138000

1000

12400

16400

24800

33000

44000

57800

69000

82800

103400 124200 138000

151800

2000

16400

20600

30200

44000

57800

69000

82800

103400 124200 138000 151800

165600

5000

20600

24800

33000

52400

69000

82800

103400

124200 138000 151800 165600

172400

10000

24800

30200

44000

60600

82800

103400

110400

129600 151800 165600 172200

184800

15000

33000

37200

55200

74400

99200

118600

138000

157200 184800 193200 206600

220800

20000

41400

49600

71600

99200

132400

160000

165600

215200 248400 257600 276000

303600

Above 20000

92000

111200 144400 167400 187600

211600

233600

248400 257600 276000 303600

322000

In addition to fees payable per year, at the time of registration of a Factory 50% of the fees
payable for a year above shall also be payable.
Fees Table-B
Scale of Fees Payable per year for Registration, Licence & Renewal of Licence by all
Electricity Generating and Transforming Factories
(a) Generating and transforming (including converting) Stations (Factories):Fees payable in Rupees
Total
Installed
Generating
Capacity In
K.W.

Generating
stations

Transforming
(including
converting)
stations

Not exceeding

50

600

300

Not exceeding

100

1100

600

Not exceeding

150

1300

900

Not exceeding

300

1800

1100

Not exceeding

500

2300

1300

Not exceeding

750

3200

1800

Not exceeding

1000

3600

2300

Not exceeding

2500

6900

5100

Not exceeding

5000

10350

6900

Not exceeding

10000

12000

8550

<!-- page 7 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍
Not exceeding

25000

13800

10350

Not exceeding

50000

20700

13800

Not exceeding

75000

27600

17250

Not exceeding

100000

34500

22200

Not exceeding

150000

55600

36800

Not exceeding

200000

64400

46000

Not exceeding

1000000

73600

59800

Over

1000000

138000

110400

‍‍

‍449

(b) Transmitting factories: - All transmitting Stations Rs. 6900/-.
(c) In addition to fees payable per year, at the time of registration of a Factory 50% of
the fees payable for a year above shall also be payable.
EXPLANATION:
1. Where an electricity generating factory includes a transmitting or converting
station or plant meant for receiving, transforming, converting or transmitting or
electric power supplied from a source outside the generating station and which
is not meant for transforming, converting or transmitting of power generated in
the generating station itself, the fees payable shall be the sum of fees payable by
the generating, transforming (including converting) and transmitting stations
respectively calculated separately as if they were separate factories.
2. If any generating, transforming, converting or transmitting station is situated in
a factory for which licence fees has been prescribed in Fees Table-B and if it is
meant for supplying power only to the said factory exclusively and is a part of
the said factory the fees will be payable in accordance with Fees Table-A and
not Fees Table-B and on the basis of the total rated horse power installed in the
factory.
7. Late fees.- The late fee under the proviso to sub-section (1) of section 3 shall be 25
percent of the of fees payable for the licence as provided in Fees Table-A or Table-B, as the
case may be, mentioned above.
8. Submission and approval of plans.- (1) No site shall be used for the location of a
factory or no building in a factory be constructed, extended or taken into use as a factory or
part of a factory unless previous permission in writing is obtained from the Chief Inspectorcum-Facilitator:
Provided that the occupier of a factory belonging to such class as may be specified by
the State Government may submit plans certified by a third party having such qualification
and experience, in such manner and recognition as may be notified by the State Government,
and such plans shall be accepted by the Chief Inspector-cum-Facilitator.

<!-- page 8 -->

450 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
Provided further that the Chief Inspector-cum-Facilitator may require amendments, if
any, to such third-party-certified plans, for reasons to be recorded in writing, for the
compliance with the provisions of the Code, rules, and regulations.
(2) Application for such permission shall be made in Form-6 on the Official Portal to the
Chief Inspector-cum-Facilitator or in such manner as prescribed under the Rajasthan
Enterprises Single Window Enabling and Clearance Act, 2011 (Act No. 7 of 2011).
(3) The occupier of a factory shall submit plans along with documents including
specifications and nature as may be specified in the Official Portal.
(4) The occupier of a factory employing upto 50 workers and are involving non-hazardous
process shall also submit an application in Form-7 along with Form-6 on the Official Portal.
(5) If Chief Inspector-cum-Facilitator is satisfied that the plans are in consonance with the
requirements of the Code and rules and regulations made thereunder, he shall, subject to such
conditions as he may specify, approve them electronically, or he may call for such other
particulars as he may require to enable such approval to be given.
9. Certificate of Stability.- No manufacturing process shall be carried on in any
building of a factory constructed, reconstructed or extended, or in any building which has
been taken into use as a factory or part of a factory until a certificate of stability by a
competent person in respect of each building or block of building in the Form-8 has been sent
by the occupier or manager of the factory to the Chief Inspector-cum-Facilitator or any other
officer authorized by him in this behalf under sub-section (6) of section 34 and accepted by
him.
10. Prohibition of use of premises as factory without licence.- An occupier shall
not use any premises as a factory or carry on any manufacturing process in a factory unless a
licence has been issued in respect of such premises and is in force for the time being:
Provided that if a valid application for grant of licence has been submitted and the
required fee has been paid on the Official Portal, the premises shall be deemed to be duly
licenced until such date as the Chief Inspector-cum-Facilitator grants or renews the licence
or refuses in writing to grant or renew the licence.
11. Grant of Licence.- (1) The Registering Officer or Authority, as the case may be,
may, on application being made to him under sub-rule (1) of rule 6 and on payment of fees
prescribed in Fees Table-A or Fees Table-B, as applicable, and on being satisfied that there is
no objection to the grant of licence, shall issue electronically a single licence in Form-9 or
common licence in Form-10 for a period not exceeding 10 years at a time and subject to
compliance with such conditions as are specified in the licence:
Provided that, subject to the third proviso to sub–section (4) of section 119 of the Code,
the Registering Officer or Authority may reject to register the factory or grant of a licence, if
he is satisfied,–
(i)

that the plans of the site and building and machinery layout have not been
duly approved by the Registering Officer or Authority, as the case may be,

<!-- page 9 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍451

except in the case of factory involving non-hazardous process and employing
upto 50 workers;
(ii)
that the factory has not been constructed in accordance with the plans
approved by the Registering Officer or Authority as the case may be, or in
non-compliance with the conditions subject to which the plans are approved;
(iii) that material requirements of the relevant provisions specified in the rule 100
or rules or regulations made under the Code or the Manufacture, Storage and
Import of Hazardous Chemicals Rules, 1989 in relation to the factory
concerned have not been complied with;
(iv) that there is imminent danger to human life in the factory due to explosive
material or inflammable or toxic dust, gas or fumes, and effective measures,
in his opinion, have not been taken to remove the danger; or
(v)
that any outcome against the safety, health and working conditions of
workers if any inquiry is made under sub-section (3) of section 119.
(2) Subject to the provisions hereinafter contained with respect to cancellation and unless
earlier renewed, every such licence shall remain in force until the 31st day of March next
following and shall then expire.
12. Auto Renewal of Licence.- (1) An application in Form-5 for the renewal of
licence for a period not exceeding 10 years for factories and payment of the fees specified in
the Fees Table-A or Fees Table-B, as applicable, shall be made on the Official Portal not later
than 31st January of the year in which the licence is due to expire:
Provided that where a factory commences work on or after the 1st day of February in
any year, application for renewal of licence shall be made on or before the 1 st day of April
next following.
Provided further that, the period for which the licence is applied for is one year or
more but does not exceed 10 years, the fees payable per year shall be at the rates specified in
Fees Table-A or Fees Table-B.
(2) On receipt of the complete application and payment of due fees, the renewed licence shall
be auto generated online on the Official Portal:
Provided that where the application for the renewal of the licence is made after the
expiry of the due date specified in sub-rule (1) it shall be renewed on payment of an
additional fee of 25 percent of the fee per year payable for the renewal of the licence.
(3) Every licence renewed under this rule shall remain in force upto 31st March of the year for
which the licence is renewed.
13. Amendment of registration or licence.- (1) A registration or licence granted may
be amended by the Authority.
(2) A licensee shall be required to have the licence amended if there is change in the name of
the factory or Occupier or expansion of production or facility or if the factory, for which the
licence was granted, alters the limits specified in the licence in regard to power or the number

<!-- page 10 -->

452 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
of persons employed, or any change or addition or deletion in manufacturing process which
differs from the original licence.
(3) A licensee who desires to have his licence amended shall submit application in the Form5 on the Official Portal stating the nature of the amendment and reasons therefore.
(4) The fees for the amendment of a licence shall be one hundred rupees plus the amount, if
any, by which the fee that would have been payable if the licence had originally been issued
in the amended form exceeds the fee originally paid for the licence. The fees shall be paid
through the Official Portal.
(5) The registration of factory is required to be amended if there is change in the name of the
factory or Occupier or the number of persons employed differs from the original registration
certificate and fees for the amendment shall be one hundred rupees.
(6) In case of any administrative or processing error on the part of Registering Officer or
Authority as the case may be, no amendment fees shall be levied.
14. Change of manager.- The occupier shall submit information of change of
manager electronically in Form-11 on Official Portal.
15. Revocation of licence.- The Chief Inspector-cum-Facilitator, at any time before
the expiry of the period for which the license has been granted or renewed, revoke the
license on any of the following grounds:(i) the licensee has obtained a license by fraud or mis-representation; or
(ii) that there is a imminent danger to the life in the factory due to explosive or
inflammable dust, gas or fumes, and effective measures in the opinion of the Chief
Inspector-cum-Facilitator have not been taken to remove the danger:
Provided that, before revoking any license, the licensee shall be given an opportunity
of being heard.
16. Transfer of licence.- (1) The licensee may at any time before the expiry of the
licence, apply for permission to transfer his licence to another person.
(2) Such application shall be made in Form-5 on the Official Portal to the Registering Officer
or the Authority, as the case may be, who shall if approves of the transfer, issue such licence
in Form-9.
(3) A fee of one hundred rupees plus the amount, if any, by which the fee that would have
been payable if the licence had originally been issued in the amended form exceeds the fee
originally paid for the licence shall be charged on each such application.
(4) If a licensee dies or becomes insolvent, the person carrying on the business of such
licensee shall not be liable to any penalty under the Code for exercising the powers granted to
the licensee by the licence during such time as may reasonably be required to allow him to
make an application for the amendment of the licence in his own name for the unexpired
portion of the original licence.

<!-- page 11 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍453

17. Closing of factory.- (1) If the occupier of a factory notifies his intention to close
the operation of the factory from a specific date and submit it on Official Portal to the
Registering Officer or Authority as the case may be, that the premises in respect of which
licence is issued shall not be used for the working of the factory, the Registering Officer or
Authority as the case may be, may suspend, if closed temporarily or cancel, if closed
permanently, the licence in respect of such a factory.
(2) A licence suspended under sub-rule (1) may be renewed on receipt of an application in
Form-5 on Official Portal on payment of surcharge of 10 percent of license fees, in addition
to the fees specified in these rules.
18. Notice of commencement or cessation of operation under section 5.- The
occupier of a factory or employer of an establishment relating to contract labour or building
or other construction works shall within thirty days of the commencement or cessation of
operation of the establishment, submit to the Registering Officer notice of commencement
and cessation of operation in Form-4, electronically and the notice of cessation of operation
shall be enclosed with a certificate that the payment of all dues to the workers employed in
the factory or establishment have been made and the premises are kept free from storage of
hazardous chemicals and substances.
Registration fees for Building and Other Construction Works
19. Fees and mode of payment of fees.- The fees to be paid for grant of a certificate
of registration of Building and Other Construction Works establishment, other than a factory
under rule 5 or for seeking any amendment in the certificate of registration, as the case may
be, shall be as specified in table given below and paid through the Official Portal, namely:Table
Sr.
No.
(1)

Number of workers proposed to be
employed as building workers
(2)

Fees

1.
2.

Up to 100
Exceeds 100 but does not exceed 500

Rs. 200
Rs. 1000

3.

Exceeds 500

Rs. 2000

(3)

Registration fees for Beedi and Cigar
20. Fees and mode of payment of fees.- The fees to be paid for grant of a certificate
of registration of Beedi and Cigar establishment, other than a factory, or for seeking any
amendment in the certificate of registration, as the case may be, shall be as specified in table
given below and paid through the Official Portal, namely:-

<!-- page 12 -->

454 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
Table

‍‍‍‍‍

Sr. No.

Number of workers proposed to
be employed

Fees (Rs.)

(1)

(2)

(3)

1.

ten but less than twenty

250

2.

twenty but less than fifty

500

3.

fifty but less than hundred

1000

4.

hundred but less than two
hundred fifty
two hundred fifty but less than
five hundred
more than five hundred

2000

5.
6.

‍भाग‍4(ग)

4000
5000

Registration fees for Contract work
21. Fees and mode of payment of fees.- The fees to be paid for grant of a certificate
of registration of Contract work establishment, other than a factory, or for seeking any
amendment in the certificate of registration, as the case may be, shall be as specified in table
given below and paid through the Official Portal, namely:Table
Sr. No.
(1)

No. of workers
(2)

Fees Rs.
(3)

1.

10 but does not exceed 49

100

2.

50 but does not exceed 100

200

3.

101 but does not exceed 200

300

4.

201 but does not exceed 400

500

5.

More than 400

1000

Registration fees for Motor Transport undertaking
22. Fees and mode of payment of fees.- The fees to be paid for grant of a certificate
of registration of Motor Transport undertaking establishment, other than a factory, or for
seeking any amendment in the certificate of registration, as the case may be, shall be as
specified in table given below and paid through the Official Portal, namely:Table
Sr. No.

Number of Motor Transport
Workers to be employed

Fees (Rs.)

(1)

(2)

(3)

1.

10-24

400

2.

25-49

1000

<!-- page 13 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍
3.

50-99

2000

4.

100-249

4000

5.

250-499

10000

6.

500-999

20000

7.

1000 and above

30000

‍‍

‍455

Registration fees for News Paper Establishments
23. Fees and mode of payment of fees.- The fees to be paid for grant of a certificate
of registration for News Paper establishment, other than a factory, or for seeking any
amendment in the certificate of registration, as the case may be, shall be as specified in table
given below and paid through the Official Portal, namely:Table
Sr. No.

Number of employees/working
journalist to be employed

Fees (Rs.)

(1)

(2)

(3)

1.

10-24

400

2.

25-49

1000

3.

50-99

2000

4.

100-249

4000

5.

250-499

10000

6.

500-999

20000

7.

1000 and above

30000

Registration fees for Audio-Visual Workers
24. Fees and mode of payment of fees.- The fees to be paid for grant of a certificate
of registration of Audio-Visual Workers establishment, other than a factory, or for seeking
any amendment in the certificate of registration, as the case may be, shall be as specified in
table given below and paid through the Official Portal, namely:Table
Sr. No.

Maximum number of AudioVisual Workers to be employed

Fees Rs.

(1)

(2)

(3)

1.

10-24

400

<!-- page 14 -->

456 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍

‍‍‍‍‍

2.

25-49

1000

3.

50-99

2000

4.

100-249

4000

5.

250-499

10000

6.

500-999

20000

7.

1000 and above

30000

‍भाग‍4(ग)

Registration fees for other establishments
25. Fees and mode of payment of fees for other establishment, other than
factory, not covered in above.- The fees to be paid for grant of a certificate of registration
of any other establishment not covered under rule 19 to 24, other than a factory, or for
seeking any amendment in the certificate of registration, as the case may be, shall be as
specified in table given below and paid through the Official Portal, namely:Table
Sr. No.

Fees Rs.

(1)

Maximum number of workers to
be employed
(2)

1.

10-24

400

2.

25-49

1000

3.

50-99

2000

4.

100-249

4000

5.

250-499

10000

6.

500-999

20000

7.

1000 and above

30000

(3)

Late fees for establishments other than factories
26. Late fees.- In case application for registration of establishment other than
factories is not made within the time specified under sub-section (1) of section 3 of the Code,
the late fee shall be twenty five percent of the fees payable for grant of certificate of
registration specified under rule 19 to 25 as the case may be.
Appeal
27. Manner of appeal under section 4.- (1) The occupier or the employer aggrieved
by the order of Registering Officer, may appeal against such order before the appellate officer
notified by the State Government for such purpose within thirty days from the date of receipt
by him of such order, electronically.
(2) Where the memorandum of appeal is in order, the appellate officer shall admit the appeal,
acknowledge it and intimate admission of such appeal, and shall register the appeal in
electronic form as specified by the State Government by general or special order.

<!-- page 15 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍457

(3) When the appeal has been admitted, the appellate officer shall send the notice of the
appeal to the registering officer, against whose order the appeal has been preferred and the
registering officer shall thereupon send the records of the case to the appellate officer online
electronically or by registered post or speed post.
(4) On receipt of the appeal, the appellate officer shall send a notice to the appellant to appear
before him on such date and time as may be specified in the notice for the hearing of the
appeal electronically or by registered post or speed post. If the appellant is present when the
appeal is called on for the hearing, the Appellate Officer shall proceed to hear the appellant or
his authorised agent and any other person summoned by him for this purpose, and pronounce
judgment on the appeal confirming, reversing or varying the order appealed against the
appeal is preferred.
(5) If on the date fixed for hearing, the appellant does not appear, the appellate officer may
dismiss the appeal for default of appearance of the appellants by sending the copy of the
order of dismissal to the appellant electronically or by registered post or speed post.
(6) Where an appeal has been dismissed, the appellant may apply electronically to the
appellate officer for the restoration of the appeal within thirty days from the date of receipt of
the order of dismissal under sub-rule (5) and if the appellate officer is satisfied that the
appellant was prevented by sufficient cause from appearing, the appellate officer shall restore
the appeal.
(7) The order of the appellate officer shall be communicated electronically or by registered
post or speed post to the appellant and copy thereof shall be sent to the Registering Officer
against whose order the appeal has been preferred and shall be disposed off within a period of
thirty days from the date of receipt of appeal.
CHAPTER–III
Duties of Employer and Employees
28. Annual Health Examination of employees under clause (c) of sub-section (1)
of section 6.- Every employer of factory or beedi and cigar works or building & other
construction work shall arrange to conduct free of cost, medical examination for every
employee annually i.e. within 120 days from the commencement of the calendar year who
has completed 40 years of age. The medical examination shall be conducted by a qualified
medical practitioner as per proforma in the Form-12. The Medical Certificate shall be
submitted by the qualified medical practitioner to the concerned employer or occupier, as the
case may be, and employee.
Provided that an employer may avail facility for medical examination of the
employee(s) under relevant provisions of the rules made by the Central Government under
the Code on Social Security, 2020 through Employees' State Insurance Corporation (ESIC).
29. Letter of appointment to employee under clause (f) of sub-section (1) of
section 6.- No employee shall be employed in any establishment or factory unless he has
been issued a letter of appointment in the format given below:
Provided that, an employee who has not been issued an appointment letter containing
the required particulars, shall be issued an appointment letter within three months of coming
into force of this rule.

<!-- page 16 -->

458 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
Format
(i) Name of employee:
(ii) Date of birth:
(iii) Father’s/Mother’s name:
(iv) Aadhar number:
(v) Labour Identification Number (LIN) of the establishment:
(vi) Universal Account Number (UAN) or Insurance Number (ESIC) (if
available):
(vii) Designation:
(viii) Category of skill:
(ix) Date of joining:
(x) Wages/Basic/Pay and Dearness Allowance:
(xi) Other allowance including accommodation whichever is/are applicable:
(xii) Avenue for achieving higher wages or higher position:
(xiii) Applicability of social security Employees' Provident Fund Organisation
(EPFO) and Employees' State Insurance Corporation (ESIC) benefits:
(xiv) Broad Nature of duties to be performed:
(xv) Any other information:
Signature
Occupier or employer or owner or agent or manager
30. Notice of accidents and dangerous occurrences under sub-section (1) section
10 and section 11.- (1) Where at any place in an establishment which is factory, beedi and
cigar works, building or other construction work; an accident occurs which results in the
death of any person, the employer or occupier or manager of the establishment shall forthwith
send a notice thereof in Form-13 electronically or by speed post or registered post or by hand
and also inform by telephone to the Inspector-cum-Facilitator, Chief Inspector-cumFacilitator concerned, District Magistrate or Sub-Divisional Officer and the officer-in-charge
of the nearest police station and the family members or kin of the deceased person.
(2) Where at any place in an establishment which is factory, beedi and cigar works, building
or other construction work, an accident occurs which results in bodily injury by reason of
which the person injured is prevented from working for a period of forty eight hours or more
immediately following the accident, the employer or occupier or manager of the
establishment shall forthwith send a notice in Form-13 within twelve hours after the
completion of forty eight hours, electronically to the Inspector-cum-Facilitator .
(3) Where in an establishment, there is any dangerous occurrence as specified in the schedule
annexed hereto, whether causing any bodily injury or disability or not, a notice in Form-13
shall within twelve hours be sent to,(a) the Inspector-cum-Facilitator;
(b) District Magistrate or Sub-divisional Officer:
Provided that if in the case of an accident or dangerous occurrence, death occurs to
any person injured by such accident or dangerous occurrence after the notices referred to in
the foregoing sub-rules have been sent, the employer or occupier or manager of the
establishment shall forthwith send a notice thereof by telephone and electronically to the
authorities and persons mentioned in sub-rules (1) and (2) and also have this information
confirmed in writing within twelve hours of the death.

<!-- page 17 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍459

Provided further that, if the period of disability from working for 48 hours or more
referred to in sub-rule (2) does not occur immediately following the accident, or the
dangerous occurrence, but later on occurs in more than one spell, the report there of shall be
sent to the Inspector-cum-Facilitator in the Form-13 within 24 hours following the hours
when the actual total period of disability from working resulting from the accident or the
dangerous occurrence becomes 48 hours.
Schedule
The following classes of dangerous occurrences, whether or not they are attended by personal
injury or disablement, namely: (i)

bursting, of any plant or pipeline or equipment containing petroleum, steam,
compressed air or other substance at a pressure greater than the atmospheric
pressure;

(ii)

collapse or failure of a crane, derrick, winch, hoist or other appliances used in
raising or lowering persons or goods, or any part thereof, or the overturning of a
crane.

(iii)

explosion, explosion due to explosives, fire, leakage or release of harmful toxic
gases, bursting out, leakage or escape of any molten metal, or hot liquid or gas
causing bodily injury to any person or damage to any room or place in which
persons are employed;

(iv)

explosion of a receiver or container used for the storage at pressure greater than
atmospheric pressure of any gas or gases (including air) or any liquid or solid
resulting from the compression of gas.

(v)

collapse or failure of lifting appliances or hoist or conveyors or other similar
equipment for handling building or construction material or breakage or failure
of rope, chain or loose gears, overturning of cranes used in building or other
construction work, falling of objects from height;

(vi)

collapse of any wall, floor, gallery, roof bridge, tunnel, chimney, wall, building
or subsidence of soil or any other structure, platform, staging, scaffolding or any
means of access including formwork, contact work, excavation and collapse of
transmission;

(vii)

spillage or leakage of hazardous substances and damage to their container;

(viii)

collapse, capsizing, toppling or collision of transport equipment within the
establishment;

(ix)

fall from height of any excavation, loading or transport machinery;

(x)

a breakage, fracture or failure of an essential part of any machine or apparatus
whereby the safety of persons may be endangered;

(xi)

a failure of any structure or installation whereby the safety of persons may be
endangered; or spark generated due to electrical flash-over causing burn injury
to any person; or

(xii)

a major uncontrolled emission of petroleum or chemical spillage;

<!-- page 18 -->

460 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
31. Notice of disease under sub-section (1) and (2) of section 12.- (1) A notice in
the following format shall be sent forth electronically, to the Inspector-cum-Facilitator or
Chief Inspector-cum-Facilitator , by the employer or occupier or manager of an establishment
in which there occurs any disease as specified under the Third Schedule to the Code.
NOTICE OF DISEASE
(1) Name and address of the employer or Occupier or Manager
(2) Name and address of factory or establishment:
(3) Nature of establishment:
(4) Details of Patient:
(a) Name of Patient:
(b) Worker number of Patient:
(c) Address of patient:
(d) Precise occupation of patient:
(5) Nature of disease from which patient is suffering:
(6) Date of detection of disease:
(7) Details of medical practitioner:
(8) Has the case been reported to the Medical Officer:
Date:
Signature of employer or occupier or manager
(2) If any qualified medical practitioner attends the person who is or has been
employed in a factory or an establishment and who is or is believed by the qualified medical
practitioner to be suffering from any disease specified in the Third Schedule to the Code, the
qualified medical practitioner shall without delay send a report in writing to the office of the
Chief Inspector-cum-Facilitator stating,(a) the name and full postal address of the patient,
(b) the disease from which he believes the patient to be suffering, and
(c) the name and address of the factory or establishment in which the patient is or was
last employed.
32. Duties of employee under clause (d) and (g) of section 13.- (1) If a worker or
employee comes to know of any unsafe or unhealthy condition in the workplace, he shall
report the same to the occupier or employer or manager or safety officer or supervisor, as
soon as practicable, electronically or in writing or telephonically and further the safety officer
or manager or supervisor shall also report the same to the occupier or employer
electronically or in writing as soon as practicable.
(2) The worker or employee shall not refuse undergoing training as required for the purposes
of the Code and rules and regulations made thereunder.

<!-- page 19 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍461

33. Rights of Employee under sub-section (3) of section 14.- The employer or
the occupier on receipt of information from the employee or worker relating to the existence
of an imminent danger to their safety and health, the employer or the occupier shall take
immediate remedial action in this regard. The Occupier or the employer, whether satisfied or
not, shall send a report forthwith of such actions taken, to the Inspector-cum-Facilitator
electronically or by registered post or speed post.
CHAPTER–IV
Occupational Safety and Health
34. Constitution, procedure and other matters relating to Rajasthan State
Occupational Safety and Health Advisory Board.- (1) There shall be a Rajasthan State
Occupational Safety and Health Advisory Board, hereinafter referred to as State Advisory
Board, consisting of the following, namely:1.

Principal Secretary/Secretary, Labour
Department Rajasthan

Chairman ex-officio

2.

Chief Inspector-cum-Facilitator

Member Secretary

3.

Chairman, Pollution Control Board

Member ex-officio

4.

Director, Medical & Health

Member ex-officio

5.

Labour Commissioner

Member ex-officio

6.

Representative of IIT Jodhpur

Member

7.

Representative of MNIT, Jaipur

Member

8.

Representative of SMS Hospital

Member

9.

2 representatives of Employers

Member

10.

2 representatives of Workers

Member

11.

4 Experts in Safety and Health

Member

12.

Such experts from different fields as
decided by the State Advisory Board

Special Invitees

(2) Members of State Advisory Board referred to at serial number 9, 10, 11 and 12 shall be
nominated by the State Government.
(3) The State Government may, by notification, constitute technical committees or advisory
committees of the State Advisory Board including site appraisal committees, consisting of
such number of members and having such qualifications, as specified by the State
Government.
(4) The State Advisory Board may meet as often as necessary to discharge its functions but
at least once in a year.

<!-- page 20 -->

462 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
(5) The State Advisory Board may get reports from the committees made under sub-rule (3)
and advise the State Government on such matters arising out of the administration of this
Code in the State.
35. Safety committee and safety officers under section 22.- (1) Every establishment
or factory employing 500 or more workers, the establishment required by general or special
order under sub-section (1) of section 22, shall constitute a safety committee consisting of
members as specified in rule 36.
(2) The maximum tenure of the safety committee shall be for three years. The safety
committee shall meet at least once in every quarter.
(3) Safety Committee shall have the right to be adequately and suitably informed of ,–
(i) potential safety and health hazards to which the workers or employees may be
exposed at workplace; and
(ii) data on accidents as well as data resulting from surveillance of the working
environment and of the health of workers or employees, conducted at such factory
or establishments:
Provided that the Committee under takes to use the data on a confidential basis and
solely to provide guidance and advice on measures to improve the working environment and
the health and safety of the workers and employees.
36. Composition of Safety Committee.- (1) The Safety Committee shall consist of
equal number of members representing the employer and the workers, which shall not exceed
twenty.
(2) Representatives of the management in Safety Committee shall consist of,(a) a senior official, who by his position in the organisation can contribute
effectively to the functioning of the Committee, shall be the Chairman;
(b) a Safety Officer and Medical Officer wherever available and the safety
officer in such case shall be the Secretary of the Committee; and
(c) A representative each from the production, maintenance and purchase
departments.
(3) Representatives of the employer in the Safety Committee shall be nominated by the
employer and shall, as far as possible, be officials in direct touch with or associated with
the working of the establishment, preferably the heads of major departments of the
establishment.
(4) Representatives of the workers in the Safety Committee shall be chosen in the
following manner, namely: (a) where there is a sole negotiating union or negotiating union under sub-section (2) or
sub-section (3) of section 14 or a negotiating council under sub-section(4) of that
section 14 of the Industrial Relations Code, 2020 (Central Act No. 35 of 2020) or

<!-- page 21 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍463

negotiating union or under said sub-section (3) negotiating council, as the case may
be, shall nominate the worker’s representatives on the Safety Committee and in the
case of the negotiating council, the nomination shall be in the manner that every
registered Trade Union representing in negotiating council shall be represented in the
Safety Committee in proportion to the number of workers of the industrial
establishment who are members of such Trade Union;
(b) where there is no such sole negotiating union or negotiating union or negotiating
council as referred to the clause (a), the workers of the industrial establishment shall
choose amongst themselves the worker’s representatives on the Safety Committee:
Provided that, the employer may, deploy an electronic process of conducting the process
of choosing representative of workers over an information technology application, online
platform or other platform.
Provided further that there shall be adequate representation of women workers on the
Safety Committee and such representation shall not be less than the proportion of women
workers to the total number of workers employed in the industrial establishment:
Provided also that the tenure of the members of the Safety Committee shall be three
years.
Provided also that in case there is no recognized both negotiating union or negotiating
council and where any dispute arises regarding choosing of the worker’s representative to the
Safety Committee, the matter may be referred to the Concerned Joint/Deputy/Assistant
Labour Commissioner, who shall after hearing the parties decide the matter and his decision
shall be final.
(5) The minutes of the meeting of the Safety Committee referred to in sub-rule (2) of rule 35
shall be recorded.
(6) The employer, occupier or manager shall, within a period of 15 days from the date of
receipt of the recommendations of the Safety Committee shall take action to implement the
recommendations.
(7) The minutes of the meeting shall be recorded and produced to the Inspector-cumFacilitator on demand.
37. Functions of Safety Committee.- The functions of the Safety Committee in a
factory or an establishment shall include,(i) to discuss remedial measures against the unsafe conditions and practices in the
factory or establishment as pointed out in the reports of safety officer or otherwise
brought to the notice of the Committee and make appropriate recommendations;
(ii) to consider, before commencement of operations in any commissioning of new
electrical or mechanical installation or introduction of new technique for
manufacturing process, the proposed Safety and health measures including related
codes of practice and to make appropriate recommendations;

<!-- page 22 -->

464 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
(iii) to discuss the report of inquiry into accident, dangerous occurrences etc., and make
appropriate recommendations;
(iv) to formulate and implement appropriate Safety campaign based on analysis of
accidents and dangerous occurrences;
(v) to meet at least once in every quarter to consider the matter placed before it and any
other matter that may be raised by the members and make such recommendations as
it may deem fit;
(vi) to serve as a forum for communication on Safety and occupational health matters;
(vii) to discuss the standard operating procedures (SOP) prepared for different plant,
equipment, installations and methods at the factory or establishment and make
appropriate recommendations; and
(viii) Functions and duties of the Safety Committee shall also include,(a) assisting and cooperating with the management in achieving the aims and
objectives outlined in the Health and Safety Policy of the factory or
establishment;
(b) dealing with all matters concerning health, safety and environment and to
arrive at practicable solutions to problems encountered;
(c) creating safety awareness amongst all workers;
(d) undertaking educational training and promotional activities;
(e) discussing reports on safety, environmental and occupational health surveys,
safety audits, risk assessment, emergency and disaster management plans and
implementation of the recommendations made in the reports;
(f) carrying out health and safety surveys;
(g) looking into any complaint made on the likelihood of an imminent danger to
the safety and health of the workers and suggesting corrective measures;
(h) reviewing the implementation of the recommendations made by it; and
(i) suggesting ways & means to avoid recurrence of accidents.
38. Safety Officers:- (1) In an establishment or factory mentioned hereunder where
appointment of Safety Officer is mandatory, the employer/occupier shall appoint safety
officers, as per norms given below:(A) For Factories carrying on Non-Hazardous process:
S. No.

Number of workers

(1)

(2)

Number of Safety
officers
(3)

1.

500 to 1000 workers

One safety officer

2.

1001 to 2000 workers

Two safety officers

3.

2001 to 5000 workers

Three safety officers

4.

More than 5000 workers

Four safety officers

(B) For factories carrying on dangerous or Hazardous process or MAH installation:
S. No.

Number of workers

(1)

(2)

1.

250 to 500 workers

Number of Safety
officers
(3)
One safety officer

<!-- page 23 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍
2.

501 to 1000 workers

Two safety officers

3.

1001 to 2000 workers

Three safety officers

4.

2001 to 5000 workers

Four safety officers

5.

More than 5000 workers

Five safety officers

‍‍

‍465

(C) For Building or other construction work:
S. No.

Number of workers

(1)

(2)

Number of Safety
officers
(3)

1.

250 to 500 workers

One safety officer

2.

501 to 1000 workers

Two safety officers

3.

1001 to 2000 workers

Three safety officers

4.

2001 to 5000 workers

Four safety officers

5.

More than 5000 workers

Five safety officers

39. Qualifications of the Safety officer.- (1) No person shall be eligible for
appointment as a Safety Officer relating to factory or building or other construction work
unless he or she,–
(i)

possesses a recognised degree in any branch of engineering or technology
and has had practical experience of working in a factory or in a building or
other construction work in a supervisory capacity for a period of not less than
2 years; or

(ii)

possesses a recognized degree in physics or chemistry and has had practical
experience in a supervisory capacity for a period of not less than 5 years; or

(iii)

possesses a diploma from a recognised university in any branch of
engineering or technology and has had practical experience of working in a
factory or in a building or other construction work in a supervisory capacity
for a period of not less than 5 years; and

possesses a degree or diploma in industrial safety from a recognised institute.
(2) Notwithstanding anything contained in sub-rule (1), any person who, –
(iv)

(i)

possesses a degree or diploma in engineering or technology and has had
experience of not less than 5 years in a department of the Central or State
Government which deals with the administration of Factory or Building and
other Construction Works; or

(ii)

possesses a degree or diploma in engineering or technology and has had
experience of not less than 5 years, full time, on training, education,
consultancy or research in the field of accident prevention in industry or in
any institution; shall also be eligible for appointment as a Safety Officer.

40. Duties of Safety Officer.- The duties of a Safety Officer shall be to advise and
assist the management of factory or establishment in the fulfillment of its obligations,

<!-- page 24 -->

466 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
statutory or otherwise, concerning prevention of personal injuries and maintaining a safe
working environment. These duties shall include the following, namely:(i)

to advise the concerned departments in planning and organising
measures necessary for the effective control of personal injuries;

(ii)

to advise on safety aspects in all job studies, and to carry out detailed
job safety studies of selected jobs;

(iii)

to check and evaluate the effectiveness of the action taken or proposed
to be taken to prevent personal injuries;

(iv)

to advise the purchasing and stores departments in ensuring high
quality and availability of personal protective equipment;

(v)

to provide advice on matters related to carrying out plant safety
inspections:

(vi)

to carry out plant safety inspections in order to observe the physical
conditions of work and the work practices and procedures followed by
workers and to render advice on measures to be adopted for removing
the unsafe physical conditions and preventing unsafe actions by
workers;

(vii)

to render advice on matters related to reporting and investigation of
industrial accident and disease;

(viii) to investigate selected accidents;
(ix)

to investigate the cases of notifiable disease listed in the Third
Schedule of the Code and dangerous occurrences reportable under the
Code and rules;

(x)

to advise on the maintenance of such records as are necessary relating
to accidents, dangerous occurrences and notifiable diseases;

(xi)

to organise in association with the concerned department, campaigns
competitions, contests and other activities which will develop and
maintain the interest of the workers in establishing and maintaining
safe conditions of work and procedures; and

(xii)

to design and conduct either independently or in collaboration with the
training department, suitable training and educational programmes for
the prevention of personal injuries.

41. Facilities to be provided to Safety Officer.- An occupier of the factory or
employer of the establishment shall provide each Safety Officer with facilities, equipment
and information as are necessary to enable him to discharge his duties effectively.
CHAPTER–V
Hours of Work and Annual Leave with Wages
42. Daily and weekly working hours under clause (b) of sub-section (1) of section
25.- (1) No worker shall be required or allowed to work in an establishment for more than
forty eight hours in any week.
(2) The period of work in each day under sub-rule (1), with intervals and spread overs, shall
be as notified by the State Government.

<!-- page 25 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍467

43. Interruption period allowed in running time under Explanation (a) of subsection (1) of section 25.- A maximum of fifteen minutes interruption shall be allowed any
time during which the transport vehicle is interrupted.
44. Weekly holiday.- (1) For the purpose of section 26, there shall be posted up in a
conspicuous place outside the office of every establishment a notice showing the weekly
holiday. Where the weekly holiday is not the same day for all persons employed in the
establishment, the notice shall show the holiday allowed to each relay, or set of persons or
individual in Hindi, English and local language.
45. Compensatory holidays.- (1) Except in the case of workers engaged in any work
which for technical reasons, or for such reasons as may be allowed by the Chief Inspectorcum-Facilitator , must be carried on continuously throughout the day, the compensatory
holidays to be allowed under sub-section (3) of section 26 of the Code shall be so spaced that
not more than two holidays are given in one week.
(2) The employer or occupier or manager of the establishment or factory shall display, on or
before the end of the month in which holidays are lost, a notice in respect of workers allowed
compensatory holidays during the following month and of the dates thereof, at the place at
which the notice of periods of works specified under section 26 is displayed in Form-14. Any
subsequent change in the notice in respect of any compensatory holiday shall be made not
less than three days in advance of the date of that holiday, and
(3) Any compensatory holiday or holidays to which a worker is entitled shall be given to him
before he is discharged or dismissed and shall not be reckoned as part of any period of notice
required to be given before discharge or dismissal.
46. Wages for overtime under section 27.- (1) Where in an establishment, a worker
works for more than eight hours in any day as daily wager, or for more than forty-eight hours
in any week, as the case may be, he shall in respect of such overtime work be entitled to
wages at the rate of twice his rate of wages and shall be paid at the end of each wage period.
(2) In calculating overtime on any day, a fraction of an hour between 15 to 30 minutes shall
be counted as 30 minutes and in case of more than 30 minutes it shall be rounded and shall be
counted as an hour on actual basis.
(3) In calculating the wages or earnings in the case of a worker paid by the month, the daily
wages shall be 1/26th of his monthly wages and in the case of any other worker, it shall be
the daily wages or earnings as the case may be.
(4) The spread over for the workers shall exceed period of work notified under sub-rule (2) of
rule 42 in any one day under the following works and circumstances in respect of factory,
beedi and cigar works and building or other construction work, namely:(a) urgent repairs;
(b) work in the nature of preparatory or complimentary work;
(c) work which is necessarily so intermittent that the intervals during which they do
not work while on duty ordinarily amount to more than the intervals for rest;

<!-- page 26 -->

468 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍
(d) work which for technical reasons must be carried on continuously;

‍भाग‍4(ग)

(e) engaged in making or supplying articles of prime necessity which must be made
or supplied every day;
(f) engaged in a process which cannot be carried on except during fixed seasons;
(g) engaged in a process which cannot be carried on except at times dependent on the
irregular action of natural forces;
(h) engaged in engine-rooms or boiler-houses or in attending to power-plant or
transmission machinery;
(i) engaged in process on account of the break-down of machinery;
(j) engaged in the loading or unloading of railway wagons or lorries or trucks;
(k) exceptional press of work; and
(l) engaged in any work, which is notified by the Central Government in the Official
Gazette as a work of national importance:
Provided that no worker shall be allowed to work overtime exceeding one hundred
forty-four hours in any quarter of a year.
47. Circumstances for exemption from restriction on double employment in
factory under section 30.- Except in the case of workers engaged in any work which for
technical reasons, or for such reasons as may be allowed by the Chief Inspector-cumFacilitator , must be carried on continuously throughout the day, no worker shall be required
or allowed to work in any factory on any day on which he has already been working in any
other factory.
48. Notice of periods of work under sub-section (2) of section 31.- The notice
referred to in sub-section (2) of section 31 shall be displayed at conspicuous places and
maintained in Form-15 and copy of such notice shall be sent to Inspector-cum-Facilitator
electronically or by registered post or speed post.

CHAPTER–VI
Maintenance of Registers, Records and Returns
49. Maintenance and production of reports, registers and other records under
section 33.- (1) every occupier or employer of establishment shall maintain,(a) Register of workers and employees in Form-16;
(b) Register of attendance cum-muster roll in Form-17;
(c) Register of wages, overtime and deductions in Form-18;
(d) Register of leave with wages in Form-19;
(e) Registers under this chapter shall be maintained electronically or otherwise;
(f) Entries in the registers shall be made in English and Hindi or the language
understood by a majority of persons employed;

<!-- page 27 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍469

(g) The occupier or every employer shall produce records and registers, on
demand before the Inspector-cum-Facilitator or any person authorized in that
behalf of the State Government; and
(h) All the registers and other records shall be preserved in original for a period of
five calendar years from the date of last entry made therein.
(2) Every employer shall issue wage slips, electronically or manually to the employees in
Form-20 as prescribed under rule 52 of the Code on Wages (Central) Rules 2026 and subsection (3) of section 50 of the Code on Wages, 2019 before one day of payment of wages to
the employee.
(3) In respect of establishment which are required to maintain register under the rules framed
under the Code on Wages 2019, Social Security Code, 2020, the following registers and
wage slips required to be maintained by the employer of the establishment under those
Codes and rules made thereunder shall be deemed to be maintained by the employer under
these rules, namely:(a) Register of employees;
(b) Register of Attendance-cum-Muster Roll;
(c) Register of Wages, over time and deductions; and
(d) Wage slip.
(4) All registers and other records required to be maintained under the Code and rules made
thereunder shall be maintained complete and up-to-date and unless otherwise provided for,
shall be kept at an office or the nearest convenient building within the precincts of the work
place or at a place within a radius of three kilometers.
(5) Returns,(a) The occupier or employer to which the provisions of this Code applies on or before the
1st day of February in each year, upload a unified annual return in Form-22 prescribed
under the rules made in the Occupational Safety, Health and Working Conditions Code,
2020 (Central Act No.37 of 2020) online on the official web portal, giving information
as to the particulars specified in respect of the preceding year;
Provided that during inspection, the Inspector-cum-Facilitator may require the
production of accounts, books, register and other documents maintained in electronic
form or otherwise.
Explanation: For the purposes of this sub-rule, the expression “electronic form” shall
have the same meaning as assigned to it in clause (r) of section 2 of the
Information Technology Act, 2000 (Central Act No. 21 of 2000).
(b) If the occupier or employer to which the provisions of this Code applies sells, abandons
or discontinues the working of the establishment, then he shall, within one month of the
date of such sale or abandonment or four months of the date of such discontinuance as
the case may be, upload online, on the official web portal, a further unified return in
Form-22 referred to in clause (a) in respect of the period between the end of the
preceding year and the date of the sale, abandonment or discontinuance.
(c) in case of manual registers and other records, be legibly entered in ink in English and
Hindi or the language understood by a majority of the persons employed;
(d) be preserved in original for a period of five years after the date of the last report or
entry:

<!-- page 28 -->

470 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
Provided that when the original record is lost or destroyed before the expiry of five
years period, true copies thereof, if available, shall be preserved for the prescribed
period;
(e) be produced, electronically or by registered post or speed post, on demand before the
Chief Inspector-cum-Facilitator or an Inspector-cum-Facilitator or any person authorized
in that behalf of the State Government.
50. Display on notice board.- (1) Every employer or occupier shall display or
caused to be displayed at the conspicuous places of the factory or establishment under his
control, notice showing the name and address of the factory or establishment, hours of work,
wage period, date of payment of such wages, details of accident and dangerous occurrence in
the establishment for the last five years, name and address of the Inspector-cum-Facilitator
having jurisdiction to such factory or establishment and date of payment of unpaid wages to
such workers in Form-21 in English and Hindi language.
(2) In addition to the above the following information in English and Hindi language shall be
displayed at a conspicuous place in the factory:(a) Hazard identification at workplace;
(b) Do’s and don'ts in respect to hazardous substances, hazardous processes, dangerous
operations, MAH installations and workplaces;
(c) Identification of storages with name of chemicals / substances / storage capacity / hot
or cold / pressure / HAZCHEM number if applicable;
(d) Emergency contact number of factory or establishment personnel and name (at least
two);
(e) Emergency contact number of local administration; and
(f) Fire / emergency escape route chart.
Provided that the Chief Inspector-cum-Facilitator may require any other
information for safety and health at workplace and the by-laws to be displayed in English
and Hindi language.
(3) The notices required to be displayed by the Code, regulations and the rules shall be
maintained in a clear and legible condition.
51. Returns.- Every employer of an establishment shall send annually a return
relating to such establishment in Form-22 related to category of employees, health & welfare
facilities retrenchment/ layoffs, bonus, maternity benefits etc. to the Inspector-cum-Facilitator
having jurisdiction so as to reach him not later than 1st February following the end of each
calendar year with a copy to Director General Labour Bureau electronically.
52. Register of accident and dangerous occurrences.- The registers of accident and
dangerous occurrences required by sub-clause (v) of clause (a) of section 33 of the Code shall
be maintained in Form-24.
53. Register of leave with wages under clause (a) of section 33.- (1) The occupier
or employer or manager of every factory or establishment shall maintain in respect of every
employee thereof a record of leave with wages electronically or manually in Form-19.
(2) The register mentioned in sub-rule (1) shall be preserved for a period of five years after
the last entry in them has been made and shall not be destroyed even after the expiry of that
period unless it has been properly transferred to the new register.

<!-- page 29 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍471

CHAPTER–VII
Inspector-cum-Facilitator s and Other Authority
54. Qualification and experience of Chief Inspector-cum-Facilitator under subsection (5) of section 34.- The Chief Inspector-cum-Facilitator shall be, (a) in case of Factories, the Chief Inspector appointed under the Rajasthan
Service of Inspector of Factories and Boilers and Inspector of Factories
(Chemical) Rules, 1958.
(b) for establishments other than factories, the Labour Commissioner or
Additional Labour Commissioner, subject to direction and control of the
Labour Commissioner.
55. Powers and duties of Inspector-cum-Facilitator under clause (xiv) of subsection (1) of section 35.- (1) Inspector-cum-Facilitator shall, after every inspection, as may
be deemed necessary, issue notice pointing out the non-compliance of provisions of safety,
health and working conditions under the Code, and rules and regulations framed thereunder,
to the employer or occupier and manager.
(2) An Inspector-cum-Facilitator shall, at each inspection, ascertain to what extent any
shortcomings notified at a previous inspection have been rectified and the notices previously
issued have been complied with and his findings and any shortcomings which may come to
light during the inspection, together with any order passed by him under the Code, rules or
the regulations made thereunder shall be recorded and maintained.
(3) Inspector-cum-Facilitator or Chief Inspector-cum-Facilitator may exercise such other
powers as may be notified by the State Government in this behalf.
56. Power to take samples of any articles or substances under clause (x) of subsection (1) of section 35.- (1) An Inspector-cum-Facilitator may take samples or substances
in an establishment as per the inspection scheme mandated under the Official Portal after
informing the employer of the establishment, taken in the manner hereinafter provided a
sufficient sample of any substance used or intended to be used in the establishment, such use
being,–
(a) in the belief of the Inspector-cum-Facilitator in contravention of any of the
provisions of this code or the rules made thereunder; or
(b) in the opinion of the Inspector-cum-Facilitator likely to cause bodily injury to,
or injury to the health of worker and employee in the factory or establishment.
(2) Where the Inspector-cum-Facilitator takes a sample under sub-rule (1), he shall, in the
presence of the person informed under that sub-rule unless such person willfully absents
himself, divide the sample into three portions and effectively seal and suitably mark them,
and shall permit such person to add his own seal and mark thereto.
(3) The person informed as aforesaid shall, if the Inspector-cum-Facilitator so requires,
provide the appliance for dividing, sealing and marking the sample taken under this rule.

<!-- page 30 -->

472 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
(4) The Inspector-cum-Facilitator shall,-

‍‍‍‍‍

‍भाग‍4(ग)

(a) forthwith give one portion of the sample to the person informed under sub-section
(1);
(b) forthwith send the second portion to a Government Analyst or National
Accreditation Board for Testing and Calibration Laboratories (NABL) for analysis
and report thereon;
(c) retain the third portion for production to the Court before which proceedings, if
any, are instituted in respect of the substance.
(5) Any document purporting to be a report under the hand of any Government Analyst or
National Accreditation Board for Testing and Calibration Laboratories (NABL) accredited
laboratory upon any substance submitted to him for analysis and report under this rule, may
be used as evidence in any proceeding instituted in respect of the substance.
57. Third party.- The scheme for third party having specialised qualification and
experience, duties and responsibilities of experts to be empanelled under section 37 shall be
as prescribed and notified by the State Government.
58. Manner of providing Alternative Employment under section 38 (1)(A)(d).Every occupier shall provide employment to the affected worker employed by him by the
order in section 38(1)(A)(a) in the other parts of the factory:
Provided that the wages for period during which alternative employment is provided
wages for such period shall paid and shall not be reduced due to alternate employment.
Provided further that if the whole or a part of establishment working as factory or
building and other construction site is fully closed by an order, then it shall be the duty of the
employer to pay wages to the affected workers as per Code on Wages, 2019 for the number
of days for which the establishment was closed.
59. Appointment of Medical Officer under sub-section (1) of section 42.- (1) The
Medical Officer shall be a medical practitioner who possesses any recognised medical
qualification as defined in the National Medical Commission Act, 2019 (Central Act No. 30
of 2019) and who is enrolled on a Indian Medical Register or on a State Medical Register as
per the provisions of the said Act.
(2) The Medical Officer shall be trained in Occupational Health course including
International Labour Organisation (ILO) classification of chest Radiograph duly recognized
by the central government.
60. Duties of Medical Officer under sub-section (2) of section 42.- (1) On receipt of
a reference under clause (c) of sub-section (2) of section 42 of the code, the Medical Officer
shall, after giving prior notice regarding date, time and place for medical examination and
upon examining the worker, prepare the age and fitness certificate and deliver the same to the
occupier or employer or manager of the factory or establishment and the worker concerned
after retaining a copy thereof.
(2) The Medical Officer may seek opinion of specialists like radiologist, dentist and
orthopedic surgeon as the case may be, for the purpose of determination of age.
(3) Medical Officer shall carry out such examination and furnish such report as the Central
Government or State Government may direct,-

<!-- page 31 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍473

(a) for examination and certification of workers in an establishment or factory in
such dangerous occupation or processes as specified in First Schedule to the
Code;
(b) for medical supervision of any establishment or factory or class of establishment
or factory where cases of chronic occupational illness have occurred due to
arduous nature of any process carried on or hazardous condition of work;
(c) in respect of any establishment or factory or class of establishment or factory or
description of establishment or factory in which operations involve any risk of
injury to the health of any person or class of persons employed therein;
(d) to undertake occupational health survey for any or class of an establishment or
factory, where cases of illness have occurred or there is prevalence of diseases
as prescribed in Third Schedule of the code.
(e) to assess the age and issue fitness of adolescent for employment in an
establishment or class of establishment.
CHAPTER–VIII
Special Provision Relating to Employment of Women
61. Employment of Women in establishment or factory under section 43.- The
following conditions shall be met for employment of women during night or before 6.00 a.m.
and beyond 7.00 p.m. in any day, namely:(a) the consent of woman employee shall be taken in writing;
(b) no woman shall be employed against the maternity benefit provisions laid down
under the Social Security Code, 2020 (Central Act No. 36 of 2020);
(c) adequate transportation facilities shall be provided to women employee to pick-up
and drop such employee at her residence;
(d) the workplace including passage towards conveniences or facilities concerning
toilet, washrooms, drinking water, entry and exit of women employee should be
well-lit;
(e) the toilet, washroom and drinking facilities should be near the workplace where
such women employee are employed and suitable provisions of Closed-circuit
television (CCTV) Surveillance on the way to these facilities shall be provided;
(f) provide safe, secure and healthy working condition is provided so that no woman
employee is disadvantaged in connection with her employment;
(g) dedicated telephone numbers of the establishment shall be displayed at
conspicuous places both at the establishment as well as inside the vehicles, so
that any women employee can utilize them, in case of any exigency or
emergency;
(h) the provisions of the Sexual Harassment of Women at workplace (Prevention,
Prohibition and Redressal) Act, 2013 (Central Act No. 14 of 2013), as applicable
to the establishments, shall be complied with.
62. Adequate safety of employment of women in dangerous operations under
section 44.- The State Government may declare, from time to time, by notification, the class

<!-- page 32 -->

474 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
of establishments or factory and the standards for safeguarding of women in hazardous
process or in dangerous operations.
CHAPTER-IX
Contract Labour
63. Qualification and Criteria of the Contractor under sub-section (1) of section
47.- For the purposes of obtaining license, the contractor as an entity or as an individual
should not be an un-discharged insolvent or convicted any time during the last two years of
an offence which is criminal in nature involving offences which are liable for punishment for
more than three months of imprisonment.
64. Conditions of License under sub-section (3) of section 47.- (1) The contractor
shall ensure that,(a) the hours of work shall conform to the rules made under section 25 of the
Code;
(b) the wages shall be paid in accordance with the Code on Wages, 2019
(Central Act No. 29 of 2019);
(c) if the contract worker of the contractor is working at the premises of the
principal employer, then it shall be the responsibility of the principal
employer to provide the facilities or amenities such as toilet, washroom,
drinking water, bathing facilities if required, changing room, first aid box,
Canteen and Crèche;
(d) all other facilities and entitlements shall be provided by the contractor;
(e) in case the contractor fails to make payment of minimum wages to the
contract worker, then the Labour Commissioner or his representative, who
shall cause such payment to be made to the contract workers, who have not
been paid, out of the security deposit maintained under rule 70 including by
invoking the bank guarantee; and
(f) he shall intimate within fifteen days of the receipt of a contract work order
about the details the contract work order and in the manner as specified in
rule 72.
65. Form and manner of application for contractor license under sub-section (1)
of section 48.- (1) Every application by a contractor for the grant of a license shall be made
on-line electronically through Official Portal in Form-25 to the licensing authority.
(2) The application shall be accompanied, by way of uploading on the Official Portal, by the
following documents, namely:–
(a) A certificate by the principal employer in Form-26 to the effect that the applicant
has establishment and that he undertakes to be bound by all the provisions of the
Code and rules made thereunder in respect of the employment of contract labour
by the applicant,
(b) Work order given by the principal employer, for contract work, and
(c) bank guarantee for an amount calculated at the rate of rupees 1000 for each of the
worker to be employed as contract labour, in respect of which the application has
been made.

<!-- page 33 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍475

(3) Every application referred to in sub-rule (1) shall also be accompanied by copy of
treasury challan /e-challan or otherwise as proof of payment of fee prescribed in rule 68.
66. Manner of taking actions and inquiry under sub-section (3) of section 119.- In
granting or refusing to grant a licence for contract work, the licensing authority shall take the
following matters into account, namely:–
(a) Whether the applicant fulfils qualification and criteria as prescribed in rule
63;
(b) Whether a certificate of the Principal Employer in prescribed Form-26 and
copy of work order is uploaded along with application;
(c) Whether contract labour is to be employed only in the non-core activities of
the establishment; and
(d) Whether any order has been made in respect of the applicant under section
51 of the Code and if so, whether a period of three years has elapsed from
the date of that order.
67. Forms, terms and conditions of license.- (1) Every license granted shall be in
Form-27.
(2) Every license granted or renewed is subject to the following conditions, namely:(a) the license shall be non-transferable;
(b) the number of workers employed as contract labour by the contractor shall
not, on any day, exceed the maximum number specified in the license;
(c) save as provided in these rules, the fees paid for the grant, or as the case
may be, for renewal of the license shall be non-refundable; and
(d) the rates of wages payable to the workers by the contractor shall not be
less than the rates prescribed under the Code on Wages, 2019 and where
the rates have been fixed by agreement, settlement or award, not less than
the rates so fixed.
68. Procedure for issue of license under sub-section (2) of section 48.- (1) Before a
license is issued under any rule of these rules, bank guarantee for an amount calculated at the
rate of Rupees 1000/- for each of the worker to be employed as contract labour, in respect of
which the application for license has been made, shall be deposited by the contractor for
performance of the conditions of the license and compliance with the provisions of the Code
or the rules made thereunder.
(2) Wherein the issued contract license had expired, based on the request of the applicant in
Form-25, the licensing officer may adjust the security deposit in respect of his application for
new license.
(3) The fees to be paid per year, for the grant of a license shall be as specified in the Table
below, namely:-

<!-- page 34 -->

476 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
Table
S. No.

‍‍‍‍‍

‍भाग‍4(ग)

Criteria

Fees in Rupees

(1)

(2)

(3)

1.

No license is required upto 49 contract labour

Nil.

2.

50 but does not exceed 100 contract labour

1000

3.

101 but does not exceed 300 contract labour

2000

4.

301 but does not exceed 500 contract labour

3000

5.

501 but not exceeding 1000 contract labour

5000

6.

1001 but not exceeding 5000 contract labour

10000

7.

5001 but not exceeding 10000 contract labour

20000

8.

10001 but not exceeding 20000 contract labour

30000

9.

20001 and above contract labour

40000

69. Renewal of license issued under section 48.- (1) Every contractor shall apply
electronically on the Official Portal to the licensing authority for renewal of the license.
(2) Every such application shall be submitted on the said Official Portal at least 30 days prior
to expiry of license period but not before 90 days of such expiry of license.
(3) The security deposit and the fee chargeable per year for renewal of the license shall be
the same as for the grant of license under rule 68:
Provided that if the application for renewal is not received within the time specified
in sub-rule (2), an additional fee of twenty five percent, shall be payable for such renewal.
(4) It shall be the responsibility of the authority concerned to renew license within 30 days or
within such shorter period as specified by the Loksewa Guarantee Adhiniyam, for such
service.
70. Refund of security deposit.- (1) On expiry of the period of license the contractor
may, if he does not intend to have his license renewed further, make an application
electronically to the licensing authority for the refund of the security deposited by him (in
form of bank guarantee) along with copy of licence and notice of completion of work and
bank details in which amount is required to be refunded.
(2) If the Licensing authority is satisfied that there is no breach of the conditions of license or
there is no order for the forfeiture of security deposit or any portion thereof, he shall direct
the refund of the security deposit to the applicant.
(3) If there is any order directing the forfeiture of any portion of contractor‘s security
deposit, the amount to be forfeited shall be deducted from the security deposit, and balance,
if any, shall be refunded to the contractor.
(4) Any application for refund shall, as far as possible, be disposed off within 30 days of the
receipt of the application.

<!-- page 35 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍477

71. Responsibility of contractor under sub-section (4) of section 48.- (1) The rates
of wages payable to the workers by the contractor shall not be less than the rates prescribed
under the Code on Wages, 2019 (Central Act No. 29 of 2019) and where the rates have been
fixed by agreement, settlement or award, not less than the rates fixed.
(2) In case where the contract labour employed by the contractor performs the same or
similar kind of work as the worker directly employed by the principal employer of the
establishment, the holidays, hours of work and other conditions of service of the contract
labour of the contractor shall be the same as applicable to the workers directly employed
by the principal employer of the establishment on the same or similar kind of work. In case
of any dispute whether the work is of similar kind, the matter be referred to the Chief
Inspector-cum-Facilitator concerned, whose decision shall be final.
(3) In other cases, the wage rates, holidays, hours of work and conditions of service of the
workers of the contractor shall be such as specified under the Code and rules made
thereunder.
(4) All contract labour shall be made member of EPFO and ESIC subject to applicability as
under respective provisions of the Code on Social Security, 2020.
(5) The contractor shall notify any change in the number of workers or conditions of work to
the Licensing Authority, electronically.
72. Intimation of work order and time limit for intimation under section 50.- (1)
Every contractor shall within fifteen days of the receipt of a contract work order shall
intimate about the contract work order containing the details such as the name of the principal
employer, address of the premises where work is being undertaken, date of commencement
of the contract work, the number of contract labour employed under that work order, duration
of work orders.
(2) the details of work order shall be sent by the contractor or his authorized representative.
(3) The intimation shall be sent electronically on the Official Portal or e-mail of the Labour
Commissioner or his representative as may be notified on the website of Labour Department.
73. Revocation or suspension of license under section 51.- (1) If the Licensing
Authority is satisfied that the licence has been obtained by misrepresentation or suppression
of any material fact or if the contractor has failed to comply with the conditions subject to
which licence was granted or the contractor has contravened any provision of the Part-I,
Chapter-XI of the Code or rules made thereunder, the Licensing Authority shall issue a show
cause notice of 15 days to the contractor electronically. On receipt of the reply if any, from
the contractor within 15 days, the Licensing Authority shall examine the same and in case the
licensing authority feels that the continuation of contract business by the contractor is going
to lead to grave harm to the workers, he may pass a Speaking Order recording the reasons for
revocation or suspension or otherwise and communicate to the contractor electronically. A
copy of the Order shall be endorsed to the Labour Commissioner and district office of Labour
Department.

<!-- page 36 -->

478 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
(2) If the contractor has complied with the said provisions of the Code and rules made
thereunder within the stipulated time period, the Licensing Authority shall revoke the
suspension giving a Speaking Order or else the suspension may be continued.
(3) If the contractor fails to comply with the directions as in sub-rule (1), the Licensing
Authority may forthwith pass an order of revocation of license, recording the reasons thereof
and communicate to the contractor electronically. The copy of the order shall be endorsed
electronically to the Labour Commissioner and district office of Labour Department.
74. Appeal under sub-section (1) of section 52.- The appellate authority under subsection (1) of section 52 of the Code shall be as notified by the State Government for the
purpose.
75. Responsibility of Payment of wages under section 55.- (1) The contractor
shall fix the wage periods in respect of which wages shall be payable and no wage period
shall exceed one month.
(2) The wages of every person employed as contract labour in an establishment or by a
contractor shall be paid before the expiry of seventh day after the last day of the wage
period in respect of which the wages are payable.
(3) The wages shall be disbursed through bank transfer or electronic mode only.
(4) The Wages of contract labours shall be paid without any deductions of any kind, except
those specified by the Central Government by general or special order in this behalf or
permissible under the Code on Wages 2019 (Central Act No. 29 of 2019), by the
contractors to the contract labour.
(5) A notice showing wage period and date and time of disbursement of wages of contract
labour shall be displayed at the place of work and a copy sent by the contractor to the
principal employer electronically or in person under acknowledgement.
(6) Every contractor (including the contractors employing less than 50 contract labour)
shall send half-yearly return in Form-23 so as to reach the concerned licensing authority,
not later than 30 days from the close of the half year, electronically, that is to say January
to June, July to December.
(7) In case contractor fails to make payment of wages to the contract labour within 7 days
of completion of wage period, then the principal employer shall take necessary action and
make payment of wages in full or the unpaid balance dues, as the case may be, to the
concerned contract labour employed by the contractor within 15 days and recover the
amount so paid from the contractor either by deduction from any amount payable to the
contractor under any contract or as debt payable by the contractor or from the Security
deposit lying with the Principal Employer.
(8) Every principal employer of an establishment shall submit annual return in Part II of
Form-22 so as to reach the authority and Labour Commissioner, so as to reach him not
later than 1st February following the end of each Calendar year electronically, except in
cases of contract which undertakes to produce given result.
76. Making payment of wages from the security deposit amount under subsection (4) of section 55.- If the contractor or principal employer does not pay the wages to

<!-- page 37 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍479

the contract labour employed by him, the Labour Commissioner or his representative or the
competent officer, as may be notified, shall conduct or cause to conduct, an inquiry and after
giving an opportunity to be heard to the contractor shall pass an order to make payment if
any, of such wages from the amount deposited by the contractor as security deposit. The
contractor shall re-furnish the security deposit within a period of fifteen days or else his
license will be liable to be suspended.
77. Experience Certificate under section 56.- Every concerned contractor shall issue
on demand, experience certificate in Form-28 to the contract labour giving details of the
period, work performed, experience gained in various fields performed by such contract
labour.
78. Prohibition of employment of contract labour under clause (b) of sub-section
(2) of section 57.- If a question arises as to whether any activity of an establishment is a core
activity or otherwise, the aggrieved party may make an application, to the Principal
Secretary/Secretary, Labour Department, Government of Rajasthan giving reasons along with
supporting documents.
CHAPTER-X
Inter-State Migrant Worker
79. Journey allowance to Inter-State Migrant Worker under section 61.- The
employer shall pay a lump sum amount on account of fare for to and fro journey to inter-state
migrant worker by train (not less Sleeper Class) or by bus or any other mode of passenger
transport from the place of employment to the place of residence in the home state in the
event if he has worked for a period of not less than 180 days in the concerned
establishment(s) in preceding twelve months:
Provided that the journey allowance shall be given to an inter-state migrant worker
once in twelve months. In the event of change of employer by the inter-state migrant worker
during the middle of the employment period and has not availed the journey allowance from
his previous employer, then on the basis of a certificate to be given by inter-state migrant
worker, the employer where the inter-state migrant worker is now working and the such
worker has completed one hundred and eighty days in preceding twelve months including the
period spent with the previous employer, then the employer shall give journey allowance.
80. Setting up of a Toll-Free helpline number to the inter-state migrant worker
under Section 63.- The State Government may provide a Toll-Free help-line number to
address queries and grievances of the inter-state migrant workers.
81. Study of inter-state migrant workers under section 64.- The State Government
may identify the studies to be carried out to promote safety, health and welfare of inter-state
migrant workers

<!-- page 38 -->

480 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍

‍‍‍‍‍

‍भाग‍4(ग)

CHAPTER-XI
Audio -Visual Worker
82. Agreement for audio-visual worker under clause (a) of sub-section (2) of
section 66.- (1) The agreement between audio-visual workers and the producer shall be
executed in Form-29.
(2) The agreement shall be registered with the competent authority as may be notified by the
State Government.
83. Procedure for reference of disputes to a Conciliation Officer or a Tribunal
under section 66.- The procedure for reference of dispute to a conciliation officer or a
tribunal shall be in conformity with the Industrial Relation Code 2020 and State rules framed
thereunder.
CHAPTER-XII
Beedi and Cigar Workers
84. Form of application and the payment of fees under sub-section (2) of section
74.- Subject to the provision of section 119 of the Code, every application under sub-section
(2) of section 74 for a licence to use, or allow to be used, any place or premises as industrial
premises shall be made on-line electronically through Official Portal in Form-25 to the
licensing authority.
85. Manner of preparing the plan of the place or premises under sub-section (3)
of section 74.- The application shall be accompanied by the Plans showing,(i) the site of such place or premises, the areas therein to be used for manufacturing
processes and the immediate surroundings of such place or premises, including
adjacent buildings, structures, roads, drains and the like, and
(ii) the plan, elevation and necessary cross section of the details relating to natural
lighting, ventilation, means of escape in case of fire, position of the plant and
machinery, if any, used aisles and passage ways in or in relation to, the various
buildings which are intended to be used for manufacturing processes.
86. Other matters under clause (e) of sub-section (4) of section 74.- Before
granting licence, the licensing authority shall also take into consideration whether the site of
any industrial premises is proposed to be altered or whether any industrial premises has been
closed, by the applicant during the period of twelve months immediately preceding the date
of the application with a view to causing prejudice to the interests of the labour.
87. Fees under sub-section (6) of section 74.- The fees per year to be paid for the
grant or renewal of a licence under section 74 shall be as specified in the table given below:-

<!-- page 39 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍481

TABLE
S. No.

Number of employees

(1)

(2)

Fees in Rupees for
industrial premises
in which power
driven machinery is
used

Fees in Rupees for
industrial premises
in which power
driven machinery
is not used

(3)

(4)

1.

Exceeds ten but does not exceed
twenty

300

200

2.

Exceeds twenty but does not exceed
fifty

700

500

3.

Exceeds fifty but does not exceed
hundred

1500

1000

4.

Exceeds hundred but does not
exceed two hundred and fifty

3000

2500

5.

Exceeds two hundred and fifty

5500

5000

88. Renewal of license under the second proviso to sub-section (6) of section 74.(1) Every employer shall apply electronically on the portal to the licensing authority for
renewal of the license.
(2) Every such application shall be submitted on the said portal at least 30 days prior to
expiry of license period but not before 90 days of such expiry of license.
(3) The fee chargeable for renewal of the license per year shall be the same as for the grant of
license under rule 87:
Provided that if the application for renewal is not received within the time specified
in sub-rule (2), an additional fee of twenty five per cent, shall be payable for such renewal.
89. Period.- It shall be the responsibility of the authority concerned to renew or refuse
to renew license within 30 days or within such shorter period as prescribed under Loksewa
Guarantee Adhinium, for such service.
90. Form and terms and conditions of licence.- (1) A licence under section 74 shall
be issued electronically in Form-27.
(2) Every licence granted or renewed under section 74 shall be subject to the following
conditions, namely:(a) the manufacturing process shall be carried on only in that part of the industrial
premises specified for the purpose in the licence;
(b) the maximum number of employees employed in the industrial premises shall not
on any day exceed the number specified in the licence;

<!-- page 40 -->

482 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
(c) power driven machinery not specified in the licence shall not be used in the
manufacturing process in the premises;
(d) except with the prior permission in writing of the competent authority the
industrial premises shall not be extended and except with the like permission no
structural alteration shall be made in any building on such premises;
(e) the licence shall not be transferable; and
(f) except as provided in these rules the fees paid for the grant, or, as the case may
be, renewal of the licence shall be non-refundable.
91. Time of filing appeal and fees under section 75.- (1) The employer aggrieved by
the order of Licensing Officer, may appeal against such order before the appellate officer
appointed by the State Government for the purpose within thirty days from the date of receipt
by him of such order, electronically.
(2) Where the memorandum of appeal is in order, the appellate officer shall admit the appeal,
acknowledge it and intimate admission of such appeal, and shall register the appeal in
electronic form to be kept for the purpose called the register of appeals.
(3) When the appeal has been admitted, the appellate officer shall send the notice of the
appeal to the licensing officer, against whose order the appeal has been preferred and the
licensing officer shall thereupon send the records of the case to the appellate officer online
electronically.
(4) On receipt of the appeal, the appellate officer shall send a notice to the appellant to appear
before him on such date and time as may be specified in the notice for the hearing of the
appeal electronically or by registered post.
(5) If on the date fixed for hearing, the appellant does not appear, the appellate officer may
dismiss the appeal for default of appearance of the appellants by sending the copy of the
order to the applicant electronically.
(6) Where an appeal has been dismissed, the appellant may apply electronically to the
appellate officer for the restoration of the appeal within thirty days from the date of receipt of
the order and if the appellate officer is satisfied that the appellant was prevented by sufficient
cause from appearing, the appellate officer shall restore the appeal.
(7) The order of the Appellate Officer shall be communicated electronically or by registered
post to the appellant and copy thereof shall be sent to the licensing officer against whose
order the appeal has been preferred and shall be disposed of within a period of thirty days
from the date of receipt of appeal.
(8) The fees payable in respect of an appeal under this rule shall be Rs. 100/-.
92. Conditions for permission and form of maintaining record of the outside
work under sub-section (1) and (2) of section 76.- (1) Permission for wetting or cutting of
beedi or tobacco leaves by employees outside the industrial premises may be granted on such
conditions as may be specified by the State Government, from time to time.
(2) The employer shall make, through the Labour Commissioner, an application addressed to
the Principal Secretary/Secretary of the Labour department on behalf of the employees to
obtain permission for wetting or cutting of beedi or tobacco leaves by such employees. The

<!-- page 41 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍483

Labour Commissioner shall forward the application with his comments within a period of 15
days to the State Government. The State Government shall decide the application within a
period of further thirty days. The permission so granted shall be valid only for such period as
specified in the order granting permission.
(3) The employer shall maintain record of the work permitted under sub-section (1) of
section 76 to be carried out outside the industrial premises in Form-30, electronically or
otherwise.
(4) The employer shall, in respect of the employees who are permitted to work in their
houses i.e. home-workers, maintain an up-to-date register in Form-31, electronically or
otherwise.
93. Disputes relating to issue of raw materials by the employer.- (1) Any dispute
between an employer and an employee or employees in relation to,(a) the issue by the employer of raw materials to the employee;
(b) the rejection by the employer of beedi or cigar or both rejected by an
employee; or
(c) the payment of wages for the beedi or cigar or both rejected by an employer;
may be referred in writing by the employer or the employee or employees to the Inspectorcum-Facilitator who shall, after making such enquiry as he may consider necessary and after
giving the parties an opportunity to represent their respective cases decide the dispute and
record the proceedings in Form-32.
(2) Any party to the dispute aggrieved by the decision thereon under sub-rule (1) may prefer
an appeal within a period of thirty days from the date of the decision to the Licensing
Authority:
Provided that the appellate authority may admit an appeal after the said period, if
the appellant satisfies such authority that he had sufficient cause for not preferring the appeal
within that period.
94. Supervision of distribution of raw materials.- No employer shall, if he is
required to do so by an Inspector-cum-Facilitator by an order in writing, distribute except
under the supervision of the Inspector-cum-Facilitator making the order or the supervision of
another Inspector-cum-Facilitator , raw materials to such employee or employees and during
such period as may be specified in the order.
95. Limit with regard to the rejection of Beedis or Cigars.- (1) No employer or
contractor shall ordinarily reject as sub-standard or chhat or otherwise more than five per cent
of the beedis or cigars, or both, received from a worker including a home worker.
(2) Where any beedi or cigar is rejected as sub-standard or chhat or otherwise on any ground
other than the ground of wilful negligence of the worker, the worker shall be paid wages for
the beedis or cigars so rejected at one-half of the rate at which wages are payable to him for
the beedis or cigars, or both, which have not been so rejected.
96. Payment of wages to home workers.- Where raw materials are supplied to a
home worker at his home, the wages due to him shall also be paid at his home:
Provided that an Inspector-cum-Facilitator may, if he considers it expedient so to
do in the circumstances of any case, specify in respect of any home worker any other place
or places at which wages shall be paid.

<!-- page 42 -->

484 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
97. Maintenance of certain registers.- (1) Every employer shall provide free of cost
to each home worker two books in Form-33, hereinafter referred to as the Home workers logbook and the home-worker shall keep a record in the logbook of the daily work done by him,
the number of beedis or cigars supplied by him, number of standard beedis/cigars, the number
of sub-standard or chhat beedis/cigars, the wages receivable and received by him for the
standard beedis/cigars, sub-standard or chhat beedis/cigars. The book shall be made of good
quality paper duly bound and will contain sufficient number of pages to last one year. The
supply of books shall be so arranged that one book remains with the home worker at all times
during the period between the two successive supplies or raw materials by the employer.
(2) Every employer shall maintain a home workers' employment register in Form-33.
electronically or otherwise containing the names and particulars of all the home workers
employed under him and the entries in the register shall be made and kept up-to-date on the
basis of the entries in the home-workers' log books.
CHAPTER-XIII
Factories
98. Mode of submission of application under sub-section (1) and (2) of section
79.- The provisions of rule 5 to 18 shall mutatis mutandis apply to the application submitted
under sub-section (1) and (2) of section 79.
99. Common facilities and services for joint liability of owner of premises and
occupiers under section 80.- Where any premises or separate buildings are leased to
different occupiers for use as separate factories, the owner of the premises and occupiers of
the factories utilising such common facilities which include fire prevention and protection,
access, hygiene, health, ventilation, temperature, emergency preparedness and response,
canteens, shelter, rest rooms and crèches shall jointly and severally be responsible for
provision and maintenance of such common facilities and services as prescribed below:(i)

Where in any premises separate buildings are leased to different occupiers for use
as separate factories, the owner of the premises and occupiers of the factories shall
jointly and severally be responsible for the provision and maintenance of common
facilities and services, such as approach roads, drainage, water supply, lighting and
sanitation.

(ii)

Where in any premises, independent or self-contained, floor or flats are leased to
different occupiers for use as separate factories, the owner of the premises and
occupiers of the factories shall jointly and severally be liable as if he were the
occupier or manager of a factory, for any contravention of the provisions of the
Code, rules and regulations made thereunder in respect of:(a) latrines, urinals and washing facilities in so far as the maintenance of the
common supply of water for these purposes is concerned;
(b) fencing of machinery and plant belonging to the owner and not specifically
entrusted to the custody or use of an occupier;
(c) safe means of access to the floors or flats or building or premises and
maintenance and cleanliness of staircases and common passages;

<!-- page 43 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍485

(d) precaution in case of fire at common place;
(e) maintenance of hoists and lifts at common place; and
(f) maintenance of any other common facilities provided in the premises.
(iii)

In respect of clause (i) and (ii), while computing for the purposes of any of the
provisions of this Code the total number of workers employed, the whole of the
premises shall be deemed to be a single factory.

(iv)

The Chief Inspector-cum-Facilitator shall have power to issue orders to the owner
of the premises in respect of the carrying out of the provisions of this rule.

100. Dangerous manufacturing process or operation under section 82.- (1) The
following manufacturing process or operation when carried on in any factory are declared to
be dangerous manufacturing process or operation under clause (a) of section 82:1. Manufacture of aerated water and processes incidental thereto.
2. Electrolytic plating or oxidation of metal articles by use of an electrolyte
containing chromic acid or other chromium compounds.
3. Manufacture and repair of electric accumulators.
4. Glass manufacture.
5. Grinding or glazing of metals.
6. Manufacture and treatment of lead and certain compounds of lead.
7. Generation of gas from dangerous petroleum, as defined in the Petroleum Act,
1934 (Central Act No. 30 of 1934).
8. Cleaning or smoothing, roughening etc., of articles by a jet of sand metal short or
grit or other abrasive propelled by a blast of compressed air or steam.
9. Lining and tanning of raw hides and skins and processes incidental thereto.
10. Manufacture of chemical and processes incidental thereto.
11. Manufacture of pottery and processes incidental thereto.
12. Printing presses and type foundries-certain lead processes carried therein.
13. Manufacture of bangles and other articles from cinematograph film and toxic and
inflammable solvents.
14. Compression of oxygen and hydrogen produced by the Electrolysis of water.
15. Handling and processing of Asbestos, manufacture of any article of Asbestos and
any other process of manufacture or otherwise in which Asbestos is used in any
form.
16. Manipulation of stone or any other material containing free silica.
17. Handling and Manipulation of corrosive (liquids and substances).
18. Manufacture or Manipulation of Carcinogenic Dye Intermediates.
19. Process of extracting vegetable oils from oil cakes in Solvent Extraction Plant.
20. Manufacture or Manipulation of manganese and its compounds.

<!-- page 44 -->

486 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
21. Manufacture, handling and use of Benzene.

‍‍‍‍‍

‍भाग‍4(ग)

22. Carbon Disulphide Plants.
23. Manufacture and Manipulation of Dangerous Pesticides.
24. Operations involving high Noise levels.
25. Manufacture of Rayon by Viscose Process.
26. Highly Flammable Liquid and Flammable Compressed Gases.
27. Operation in Foundries.
28. Fireworks Manufacturing and Match Factories.
(2) The provisions specified under clause (b), (c) and (d) of section 82 and in the Schedules
annexed hereto shall apply to any class or description of factories wherein
dangerous manufacturing process or operation specified in each Schedule are carried out.
(3) Notwithstanding the provision specified in the schedules appended to this rule, the
Inspector-cum-Facilitator may, by issue of orders in writing to the manager or occupier or
both, direct them to carry out such measures, and within such time, as may be specified in
such order with a view to removing conditions dangerous to the health of the workers, or to
suspend any process, where such process constitutes, in the opinion of the Inspector-cumFacilitator , imminent danger of poisoning or toxicity.
(4) Any register or record of medical examination and tests connection therewith required to
be carried out under any of the schedules annexed hereto in respect of any workers shall be
kept readily available to the Inspector-cum-Facilitator and shall be preserved till the expiry of
one year after the workers ceases to be in employment of the factory or for the time period
specifically prescribed in any of the Schedule below, whichever is higher.
(5) No pregnant woman shall be employed in any part of a factory wherein or near thereby a
dangerous manufacturing process or operation is carried out. However, before employing
any woman other than pregnant women in a factory wherein dangerous manufacturing
process or operation is carried out, the occupier shall ensure that engineering control is
installed, safety training, prescribed medical examination, specialised Personal Protective
Equipment, as may be notified by the State Government, are provided.
(6) The Permit to work system shall inter alia include the observance of the following
precautions while carrying out any specified work to be subjected to the permit to work
system;(a) all work subject to the permit to work system shall be carried out under the
supervision of a knowledgeable and responsible person;
(b) all parts of plant or machinery or equipment on which permit to work system is
carried out, shall remain isolated from other parts throughout the period of permit
to work and the place of work including the parts of plant, machinery shall be
rendered safe by cleaning, purging washing etc.;
(c) all work subject to the permit to work system shall have predetermined work
procedures which integrate safety with the work. Such procedures shall be

<!-- page 45 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍487

reviewed whenever any change occurs in material or equipment so that continued
safety is ensured;
(d) persons who are assigned to carry out the permit to work system shall be
physically fit in all respects taking into consideration the demands and nature of
the work before entering into the confined space. Such persons shall be adequately
informed about the correct work procedures as well as the precautions to be
observed while carrying out the permit to work system;
(e) adequate rescue arrangements wherever considered necessary and adequate first
aid, rescue and resurrection arrangements shall be available in good working
condition near the place of work while carrying out the permit to work system for
use in emergency;
(f) adequate rescue arrangements wherever considered equipment shall be used while
carrying out the 'permit to work system';
(g) after completion of work subject to the 'permit to work system’, the person
responsible shall remove all the equipment and tools and restore to the original
condition so as to prevent any danger while carrying out a regular process; and
(h) Alternate power supply arrangements shall be made and interlocked with the
normal power supply system so as to ensure constant supply of power to the
facilities and equipment meant for compliance with requirements of the schedules
made under this rule.
(7) There shall be provided and maintained in a cleanly state and in good repair for the use of
all persons employed in dangerous operation process,(a) a wash place under cover with either,(i) a trough with a smooth impervious surface fitted with a waste pipe, without
plug and of sufficient length to allow of at least 60 cms. for every ten such
persons employed at any one time and having a constant supply of water taps
of jets above the trough at intervals of not more than 60 cms.; or
(ii) at least one wash basin for every ten such persons employed at any one time,
fitted with a waste pipe and plug and having a constant supply of clean water:
(iii) a sufficient supply of clean towels made of suitable materials renewed daily;
and
(iv) a sufficient supply of soap or other suitable cleansing materials.
(b) there shall in addition be provided means of washing facilities if required by
notice in writing from the Chief Inspector-cum-Facilitator .
(8) Before each meal and before the end of the day's work, at least ten minutes, in addition to
the regular meal times, shall be allowed for washing to each worker or employee:
Provided that if there be one basin or 60 cms. of trough for each such person this subrule shall not apply.

<!-- page 46 -->

488 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
(9) Sufficient bath accommodation to the satisfaction of the Chief Inspector-cum-Facilitator
shall be provided along with sufficient supply of soap and clean towels.
(10) No food, drink, Paan and supari or tobacco shall be consumed or brought by any worker
into any work-room in which any dangerous operation process is carried on.
(11) The occupier of all the factories carrying out processes covered under section 82, shall
provide,(a) for all the workers working in a shift, mess room facility, which are well
ventilated and provided with sitting facilities along with the provision of drinking
water; and
(b) such facilities shall include suitable arrangements for cleaning and washing and
shall be maintained in clean and hygienic conditions.
(12) The occupier of every factory carrying out any process covered under section 82 shall
provide,(a) for all the workers employed in the process, cloak room facilities with lockers.
Each worker shall be provided with locker; and
(b) the cloak room facilities shall be located as far as possible near to the facilities
provided for washing. If it is not possible to locate the washing facilities the cloak
room facilities shall have adequate and suitable arrangements for cleaning &
washing.
(13) The occupier of every factory having licence of more than 100 workers and to which this
rule applies, shall,(a) employ a qualified medical practitioner having qualification, training and experience
in conducting a thorough Medical check-up against the hazards likely to creep in such
type of process; and
(b) provide to the said medical practitioner the necessary facilities for the purpose
referred to in clause (a);
(14) The record of medical examination and appropriate tests carried out by the said medical
practitioner shall be maintained in a Health Register, which shall be kept readily available for
Inspection by the Inspector-cum-Facilitator.
(15) Workers employed in processes covered under this rule shall be medically examined by
a Medical Practitioner or Medical Officer in the following manner:(a) Once before employment, to ascertain physical suitability of the person to do the
particular Job;
(b) Once in a period of 12 months or less as defined in the schedule, to ascertain the
health status of the workers;
(c) The details of pre-employment and periodical medical examinations carried out as
aforesaid shall be recorded in Health Register and maintained;

<!-- page 47 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍489

(d) Any finding of the Medical Practitioner revealing any abnormality or unsuitability
of any person employed in the process shall immediately be reported to the
occupier. If the Factory Medical Practitioner is of the opinion that the worker so
examined is required to be suspended from the process for health protection, he
will advise the occupier accordingly, who shall not employ the said worker in the
same process. However, the worker so suspended from the process shall be
provided with alternate placement facilities unless he is fully in capacitated in the
opinion of the Medical Practitioner, in which case the person affected shall be
suitably rehabilitated:
Provided that the Medical Officer on his own may examine any other
workers whom he feels necessary to be examined for ascertaining the suitability of
his employment in the processes covered under this rule or for ascertaining the
health status of any other worker and his opinion shall be final.
(e) No person shall be newly appointed without the Certificate of Fitness granted by
the Medical Practitioner. If the Medical Practitioner declares a person unfit for
being appointed to work in the process covered in sub-rule (1) then such person
shall have a right to appeal to the Medical Officer, whose opinion shall be final in
this regard;
(f) The worker suspended from the process owing to the circumstances covered in
sub-para (d) shall be employed again in the same process only after obtaining the
Fitness Certificate from the Medical Officer and after making entries to that effect
in the health register.
(16) In every factory carrying out dangerous operations,(a) Every worker employed in any of these processes to which this rule applies shall
be examined by a Medical Officer within 15 days of his first employment. Such
examination shall include such medical tests as mentioned in the Schedule related
to the processes. No worker shall be allowed to work after 15 days of his first
employment in the factory unless certified fit for such employment by the Medical
Officer.
(b) Every worker employed in the said processes shall be re-examined by a Medical
Officer at least once in every twelve months. Such re-examination shall, wherever
the Medical Officer considers appropriate include tests as specified in Schedules
appended to this rule.
(c) The Medical Officer after examining a worker, shall issue a Certificate of Fitness.
The record of examination and re-examinations carried out shall be entered in the
Certificate and the Certificate shall be kept in the custody of the manager of the
factory. The record of each examination carried out under clause (a) and (b)
above, including the nature and results of the tests, shall also be entered by the
Medical Officer in a health register.
(d) The Certificate of fitness and the health register shall be kept readily available for
Inspection by the Inspector-cum-Facilitator .

<!-- page 48 -->

490 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
(e) If at any time the Medical Officer is of the opinion that a worker is no longer fit
for employment in the said processes on the ground that continuance therein
would involve special danger to the health of the worker, he shall make a record
of his findings in the said certificate and the health register. The entry of his
findings in those documents should also include the period for which he considers
that the said person is unfit for work in the said processes.
(f) No person who has been found unfit to work as said in clause (e) above shall be reemployed or permitted to work in the said processes unless the Medical Officer,
after further examination again, certifies him fit for employment in those
processes.
(17) In all the factories carrying out dangerous operation there shall be provided and
maintained in good order an Occupational Health Centre with facilities as per scale laid down
hereunder:
(a) For factories having licence upto 50 workers,(i) The services of a qualified medical practitioner, hereinafter known as
Factory Medical Practitioner, available on a retainership basis, in his
notified clinic near to the factory for seeking medical help during
emergency. He will also carry out the pre-employment and periodical
medical examinations.
(ii) A minimum of five persons trained in first aid procedures, amongst whom
at least one shall always be available during the working period:
(iii) A fully equipped first aid box.
(iv) List of hazardous substance, chemicals and dangerous operations along
with Material Safety Data Sheets.
(b) For factories employing 51 to 200 workers,(i) The occupational health centre shall have a room having a minimum floor
area of 15 sq.m. with floor and walls made of smooth hard and impervious
surface and shall be adequately illuminated, ventilated and equipped:
(ii) A part time Factory Medical Practitioner will be in overall charge of the
Centre who shall visit the factory minimum twice in a week and whose
services shall be readily available during emergencies.
(iii) There shall be one qualified and trained dresser-cum-compounder on duty
throughout the working period.
(iv) A fully equipped first aid box.
(v) List of hazardous substance, chemicals and dangerous operations along with
Material
Safety Data Sheets.
(c) For factories employing above 200 workers,-

<!-- page 49 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍491

(i) There shall be one full time Factory Medical Practitioner for factories
employing up to 500 workers and one more Medical Practitioner for every
1000 workers or part thereof.
(ii) The occupational health centre in this case shall have a minimum of 2
rooms each having a minimum floor area of 15 sq. m. each with floors and
walls made of smooth, hard and impervious surface and shall be adequately
illuminated, ventilated and equipped.
(iii) There shall be one trained nurse, one dresser-cum-compounder and
sweeper-cum-ward boy throughout the working period.
(iv) The occupational Health Centre in this case shall be suitably equipped to
manage medical emergencies.
(v) List of hazardous substance, chemicals and dangerous operations along with
Material Safety Data Sheets.
(18) In every factory having licence for more than 500 workers and carrying out dangerous
operation, there shall be provided and maintained in good condition a fully equipped
ambulance van as may be prescribed and manned by a full time driver-cum-mechanic and a
helper, trained in first aid for the purposes of transportation of serious cases of accidents or
sickness. The ambulance van shall not be used for any purpose other than the purpose
stipulated herein and will always be available near the Occupational Health Centre.

SCHEDULE I
Manufacture of Aerated Waters and processes incidental thereto.
1. Fencing of machines.- All machines for filling bottles or siphons shall be so constructed,
placed or fenced, as to prevent, as far as may be practicable, a fragment of a bursting bottle or
siphons from striking any person employed in the factory,
2. Face guards and gauntlets.- (1) The occupier shall provide and maintain in good
condition for the use of all persons engaged in filling bottles or siphons(a) suitable face-guards to protect the face, neck and throat; and
(b) suitable gauntlets for both arms to protect the whole hand and arms:
Provided that,(i) provision of this clause shall not apply where bottles are filled by means of an
automatic machine so constructed that no fragment of a bursting bottle can
escape; and
(ii) where a machine is so constructed that only one arm of the bottle at work
upon it is exposed to danger, a gauntlet need not be provided for the arm
which is not exposed to danger.
(2) The occupier shall provide and maintain in good condition for the use of all persons
engaged in corking, crowning, screwing, wiring, foiling, capsuling, sighting or levelling
bottles of siphons—

<!-- page 50 -->

492 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
(a) suitable face-guards to protect the face, neck and throat; and

‍‍‍‍‍

‍भाग‍4(ग)

(b) suitable gauntlets for both arms to protect the arm and at least half of the palm and
the space between the thumb and forefinger.
3. Wearing of face-guards and gauntlets.- All persons engaged in any of the processes
specified in clause 2 shall, while at work in such processes, wear the face guards and
gauntlets provided under the provisions of the said clause.
SCHEDULE II
Electrolytic plating or Oxidation of Metal articles by use of an Electrolytes containing
chromic acid or other chromium compounds
1. Definitions.- For the purposes of this Schedule,(a) "Electrolytic chromium process" means the electrolytic plating or oxidation of
metal articles by the use of an electrolyte containing chromic acid or other
chromium compounds.
(b) "Bath" means any vessel used for an electrolytic chromium process or for any
subsequent process.
2. Exhaust draught.- An efficient exhaust draught shall be applied to every vessel in which
an electrolytic chromium process is carried on. Such draught shall be provided by mechanical
means and shall operate on the vapour or spray given off in the process, as near as may be, at
the point of origin. The exhaust draught appliance shall be so constructed, arranged and
maintained as to prevent the vapour or spray entering into any room or place in which work is
carried on.
3. Floor of work-rooms.- The floor of every room containing a bath shall be impervious to
water. The floor shall be maintained in good and level condition and shall be washed down at
least once a day.
4. Protective clothing.- (1) The occupier of the factory shall provide and maintain in good
and clean condition, the following articles of protective clothing for the use of all persons
employed on any process at which they are liable to come in contact with liquid from a bath
and such clothing shall be worn by the persons concerned—
(a) water-proof aprons and bibs; and
(b) for persons actually working at a bath loose-fitting rubber gloves and rubber boots
or other water-proof footwear.
(2) the occupier shall provide and maintain for the use of all persons employed suitable
accommodation for the storage and adequate arrangements for the drying of the protective
clothing.
5. Medical examination.- Every worker employed in the electrolytic chrome process shall
be examined within 15 days of his first employment. Such examinations shall include tests
for Chromium in urine and nasal septum perforation.
6. Cautionary placard.- A cautionary placard in the language of the majority of the workers
employed shall be affixed in a prominent place in the factory where it can be easily and
conveniently read by the workers.

<!-- page 51 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍493

SCHEDULE III
Manufacture and Repair of Electric Accumulators
1. Savings.- This Schedule shall not apply to the manufacture or repair of electric
accumulators or parts thereof not containing lead or any compound of leads or to the repair
on the premises, of any accumulator forming part of a stationery battery.
2. Definitions.- For the purposes of this Schedule,(a) "Lead process" means the melting of lead or any material containing lead, casting,
pasting, lead burning, or any other work, including trimming, or any other
abrading or cutting of pasted plates involving the use, movement or manipulation
of, or contact with, any oxide of lead.
(b) "Manipulation of raw oxide of lead" means any lead process involving any
manipulation or movement of raw oxides of lead other than its conveyance in a
receptacle or by means of an implement from one operation to another.
3. Separation of certain processes.- Each of the following processes shall be carried on in
such a manner and under such conditions, as to secure effectual separation from one another,
and from any other process(a) Manipulation of raw oxide of lead;
(b) Pasting;
(c) Drying of pasted plates;
(d) Formation with lead burning ("tacking") necessarily carried on in connection
therewith; and
(e) Melting down of pasted plates.
4. Air space.- In every room in which a lead process is carried on, there shall be at least 14
cubic metres of air space, for each person employed therein, and in computing this air space,
no height over 3.5 metres shall be taken into account.
5. Ventilation.- Every work-room shall be provided with inlets and outlets of adequate size
as to secure and maintain efficient ventilation in all parts of the room.
6. Distance between workers in pasting room.- In every pasting room, the distance between
the center of the working position of any paster and that of the paster working nearest to him,
shall not be less than 1.5 metres.
7. Floor of work-rooms.- (1) The floor of every room in which a lead process is carried on
shall be,(a) of cement or similar material so as to be smooth and impervious to water:
(b) maintained in sound condition; and
(c) kept free from materials, plant, or other obstruction not required for, or produced
in, the process carried on in the room.
(2) In all such rooms other than grid casting shops, the floor shall be cleaned daily after being
thoroughly sprayed with water at a time when no other work is being carried on in the room.

<!-- page 52 -->

494 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
(3) In grid casting shops, the floor shall be cleaned daily.

‍‍‍‍‍

‍भाग‍4(ग)

(4) Without prejudice to the requirements of sub-clause (1), (2) and (3) where manipulation
of raw oxide of lead or pasting is carried on, the floor shall also be,(a) kept constantly moist while work is being done;
(b) provided with suitable and adequate arrangements for drainage; and
(c) thoroughly washed daily by means of a hose pipe.
8. Work-benches. - The work-benches at which any lead process is carried on shall,(a) have a smooth surface and be maintained in sound condition:
(b) be kept free from all materials or plant not required for, or produced in, the
process carried on there at;
(c) all such work-benches other than those in grid casting shops shall be cleansed
daily either after being thoroughly damped or by means of a suction cleaning
apparatus at a time when no other work is being carried on there at;
(d) all such work-benches in grid ousting shops, shall be cleansed daily; and
(e) every work-bench used for pasting shall,(i) be covered throughout with sheet lead or other impervious material;
(ii) be provided with raised edges; and
(iii) be kept constantly moist while pasting is being carried on.
9. Exhaust draught.- The following processes shall not be carried on without the use of
an efficient exhaust draught,(a) Melting of lead or materials containing lead;
(b) Manipulation of raw oxide of lead, unless done in an enclosed apparatus so as to
prevent the escape of dust into the work-room;
(c) Pasting;
(d) Trimming, brushing, filing or any other abrading or cutting of pasted plates giving
rise to dust;
(e) Lead burning, other than,(i) 'tacking' in the formation room;
(ii) chemical burning for the making of lead lining for cell cases necessarily carried
on in such a manner that the application of efficient exhaust is impracticable.
Such exhaust draught shall be effected by mechanical means and shall operate on the dust or
fume given off as nearly as may be at its point of origin, so as to prevent it entering the air of
any room in which persons work.
10. Fumes and gases from melting pots.- The products of combustion produce in the
heating of any melting pot shall not be allowed to escape into a room in which persons work.
11. Container for dross.- A suitable receptacle with tightly fitting cover shall be provided
and used for dross as it is removed from every melting pot. Such receptacle shall be kept
covered while in the work-room, except when dross is being deposited therein.
12. Container for lead waste.- A suitable receptacle shall be provided in every work-room
in which old plates and waste material which may give rise to dust shall be deposited.
13. Racks and Shelves in drying room.- The racks or shelves provided in any drying room
shall not be more than 240 cms. from the floor not more than 60 cms in width. Provided that

<!-- page 53 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍495

as regards racks or shelves set or drawn from both sides the total width shall not exceed 120
cms. Such racks or shelves shall be cleaned only after being thoroughly damped unless an
efficient suction cleaning apparatus is used for this purpose.
14. Medical examination by Medical Officer.- Every worker employed in lead processes
shall be examined within 15 days of his first employment. Such examination shall include
tests for lead in urine and blood, ALA in urine, hemoglobin content, stippling of cells and
steadiness test.
15. Protective clothing.- Protective clothing shall be provided and maintained in good repair
for all persons employed in,(a) manipulation of raw oxide of lead;
(b) pasting; or
(c) the formation room;
and such clothing shall be worn by the persons concerned. The protective clothing shall
consist of a water-proof apron and water-proof footwear, and, also, as regards persons
employed in the manipulation of raw oxide of lead or in pasting, head coverings. The head
coverings shall be washed daily.
SCHEDULE IV
Glass Manufacture
1. Exemption.- If the Chief Inspector-cum-Facilitator is satisfied in respect of any factory or
any class of process that, owing to the special methods of work or the special conditions in a
factory or otherwise, any of the requirements of this Schedule can be suspended or relaxed
without danger to the persons employed therein, or that the application of this Schedule or
any part thereof is for any reason impracticable, he may by certificate in writing authorise
such suspension or relaxation as may be indicated in the certificate for such period and on
such conditions as he may think fit.
2. Definitions.- For the purposes of this Schedule,(a) "Efficient exhaust draught" means localised ventilation effected by mechanical
means for the removal of gas, vapour, dust or fume so as to prevent them (as far as
practicable under the atmospheric conditions usually prevailing) from escaping
into the air of any place in which work is carried on. No draught shall be deemed
efficient which fails to remove smoke generated at the point where such gas,
vapour, fume or dust originate.
(b) "Lead compound" means any compound of lead other than galena which when
treated in the manner described below, yields to an aqueous solution of
hydrochloric acid a quantity of soluble lead compound exceeding, when
calculated as lead monoxide, five per cent, of the dry weight of the portion taken
for analysis.
Explanation: The method of treatment shall be as follows:-

<!-- page 54 -->

496 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
A weight quantity of the material which has been dried at 100 degree
Centigrade, and thoroughly mixed shall be continuously shaken for one
hour, at the common temperature with 1,000 times its weight of an
aqueous solution of hydrochloric acid containing 0.25 percent, by
weight of hydrogen chloride. This solution shall thereafter be allowed
to stand for one hour and then filtered. The lead salt contained in the
clear filtrate shall then be precipitated as lead sulphide and weighted as
lead sulphate.
3. Exhaust draught.- The following process shall not be carried on except under an efficient
exhausted draught or under such other conditions as may be approved by the Chief Inspectorcum-Facilitator, (a) The mixing of raw materials to form a "batch".
(b) The dry grinding, glazing and polishing of glass or any article of glass.
(c) All processes in which hydrofluoric acid fumes or ammoniacal vapours are given
off.
(d) All processes in the making of furnace moulds or 'pots' including the grinding or
crushing of used 'pots’.
(e) All processes involving the use of a dry lead compound.
4. Floors and work-benches.- The floor and work-benches of every room in which a dry
compound of lead is manipulated or in which any process is carried on giving off silica dust
shall be kept moist and shall comply with the following requirements,The floors shall be,(a) of cement or similar material so as to be smooth and impervious to water;
(b) maintained in sound condition; and
(c) cleansed daily after being thoroughly spread with water at a time when no other
work is being carried on in the room.
The work-benches shall,(a) have a smooth surface and be maintained in sound condition, and
(b) be cleansed daily either after being thoroughly damped or by means of a suction
cleaning apparatus at a time when no other work is being carried on there at.
5. Use of Hydrofluoric Acid.- The following provisions shall apply to rooms in which glass
is treated with hydrofluoric acid,(a) there shall be inlets and outlets of adequate size so as to secure and maintain
efficient ventilation in all parts of the room;
(b) the floor shall be covered with gutta-percha and be tight and shall slope gently
down to a covered drain;
(c) the work places shall be so enclosed in projecting hoods that openings required for
bringing in the objects to be treated shall be as small as practicable; and
(d) the efficient exhaust draught shall be so contrived that the gases are exhausted
downwards.
6. Storage and transport of Hydrofluoric Acid.- Hydrofluoric acid shall not be stored or
transported except in cylinders or receptacles made of lead or rubber.

<!-- page 55 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍497

7. Blow-pipes.- Every glass blower shall be provided with a separate blow-pipe bearing the
distinguishing mark of the person to whom it is issued and suitable facilities shall be readily
available to every glass blower for sterilizing his blow-pipe.
8. Protective clothing.- The occupier shall provide, maintain in good repair and keep in
clean condition for the use of all persons employed in the process specified in clause 3
suitable protective clothing footwear and goggles according to the nature of the work and
such clothing footwear, etc. shall be worn by the persons concerned.
9. Medical examination.- Every worker employed in processes specified in clause 2 shall be
examined within 15 days of his first employment. Such examination shall include pulmonary
function test and in suspected cases chest X-rays as well as test for lead in urine.
SCHEDULE V
Grinding or Glazing of Metals and Processes Incidental thereto
1. Definitions.- For the purposes of this Schedule,(a) "Grindstone" means a grindstone composed of natural or manufactured sandstone
but does not include a metal wheel or cylinder into which block of natural or
manufactured sandstone are fitted;
(b) "Abrasive wheel" means a wheel manufactured of bonded emery or similar
abrasive;
(c) "Grinding" means the abrasion, by aid of mechanical power, of metal, by means of
grindstone or abrasive wheel;
(d) "Glazing" means the abrading, polishing or finishing, by aid of mechanical power,
of metal, by means of any wheel, buff, mop or similar appliance to which any
abrading or polishing substance is attached or applied;
(e) "Racing" means the turning up, cutting or dressing of a revolving grindstone
before it is brought into use for the first time;
(f) "Hacking" means the chipping of the surface of a grindstone by a hack or similar
tool; and
(g) "Rodding" means the dressing of the surface of a revolving grindstone by the
application of a rod, bar or strip of metal to such surface.
2. Exceptions.- (1) Nothing in this Schedule shall apply to any factory in which only repairs
are carried on except any part thereof in which one or more persons are wholly or mainly
employed in the grinding or glazing of metals.
(2) Nothing in this Schedule except clause 4 shall apply to any grinding or glazing of metals
carried on intermittently and at which no person is employed for more than 12 hours in any
week.
(3) The Chief Inspector-cum-Facilitator may by certificate in writing, subject to such
conditions as he may specify therein, relax or suspend any of the provisions of this Schedule

<!-- page 56 -->

498 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
in respect of any factory if owing to the special methods of work or otherwise such relaxation
or suspension is practicable without danger to the health or safety of the persons employed.
3. Equipment for removal of dust.- No racing, dry grinding or glazing shall be performed
without,(a) a hood or other appliance so constructed, arranged, placed and maintained as
substantially to intercept the dust thrown off;
(b) a duct of adequate size, air tight and so arranged as to be capable of carrying away
the dust, which duct shall be kept free from obstruction and shall be provided with
proper means of access for inspection and cleaning, and where practicable, with a
connection at the end remote from the fan to enable the Inspector-cum-Facilitator
to attach thereto any instrument necessary for ascertaining the pressure of air in
the said duct; and
(c) a fan or other efficient means of producing a draught sufficient to extract the dust:
Provided that the Chief Inspector-cum-Facilitator , may accept any other appliance
that is, in his opinion, as effectual for the interception, removal and disposal of dust thrown
off as a hood, duct and fan would be.
4. Restriction on employment on grinding operations.- Not more than one person shall at
any time perform the actual processes of grinding or glazing upon a grindstone, abrasive
wheel or glazing appliance:
Provided that this clause shall not prohibit the employment of persons to assist in the
manipulation of heavy or bulky articles at any such grindstone, abrasive wheel or glazing
appliance.
5. Glazing.- Glazing or other processes, except processes incidental to wet grinding upon a
grindstone shall not be carried on in any room in which wet grinding upon a grindstone is
done.
6. Hacking and rodding.- hacking or rodding shall not be done unless during the process
either,(a) an adequate supply of water is laid on at the upper surface of the grindstone; or
(b) adequate appliances for the interception of dust are provided in accordance with
the requirements of clause 3.
7. Examination of dust equipment.- (a) All equipment for the extraction or suppression of
dust shall at least once in every six months be examined and tested by a competent person,
and any defect disclosed by such examination and test shall be rectified as soon as
practicable.
(b) A register containing particulars of such examination and test shall be kept in a form
approved by the Chief Inspector-cum-Facilitator.
8. Medical Examination.- Every worker employed in grinding or glazing of metal processes
incidental thereto shall be examined within 15 days of his first employment. Such
examination shall include pulmonary function test and in suspected cases chest X-rays.

<!-- page 57 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍499

SCHEDULE VI
Manufacture and treatment of lead and certain compounds of lead
1. Exemptions.- Where the Chief Inspector-cum-Facilitator is satisfied that all or any of the
provisions of this Schedule are not necessary for the protection of the persons employed, he
may by certificate in writing exempt any factory from all or any of such provisions, subject to
such conditions as he may specify therein.
2. Definitions.- For the purposes of this Schedule,(a) "Lead Compound" means any compound of lead other than galena which, when
treated in the manner described below, yields to an aqueous solution of
hydrochloric acid, a quantity of soluble lead compound exceeding, when
calculated as lead monoxide, five percent of the dry weight of the portion taken
for analysis. In the case of paints and similar products and other mixtures
containing oil or fat the "dry weight" means the dry weight of the material
remaining after the substance has been thoroughly mixed and treated with suitable
solvents to remove oil, fats, varnish or other media.
Explanation: The method of treatment shall be as follows:A weighted quantity of the material which has been dried at 100 degree
C and thoroughly mixed shall be continuously shaken for one hour, at
the common temperature with 1,000 times its weight of an aqueous
solution of hydrochloric acid containing 0.25 per cent by weight of
hydrogen chloride. This solution shall thereafter be allowed to stand
for one hour and then filtered. The lead salt contained in the clear
filtrate shall then be precipitated as lead sulphide and weighed as lead
sulphate.
(b) "Efficient exhaust draught" means localized ventilation affected by heat or
mechanical means, for the removal of gas, vapour, dust or fumes so as to prevent
them (as far as practicable under the atmospheric conditions usually prevailing)
from escaping into the air of any place in which work is carried on. No draught
shall be deemed efficient which fails to remove smoke generated at the point
where such gas, vapour, fumes or dust originate.
3. Application.- This Schedule shall apply to all factories or parts of factories in which any
of the following operations are carried on:(a) Work at a furnace where the reduction or treatment of zinc or lead ores is carried
on.
(b) The manipulation, treatment or reduction of ashes containing lead, the dissolve
rising of lead or the melting of scrap, lead or zinc.
(c) The manufacture of solder or alloys containing more than ten percent of lead.
(d) The manufacture of any oxide, carbonate, sulphate, chromate, acetate, nitrate or
silicate of lead.
(e) Handling or mixing of lead tetra-ethyl.

<!-- page 58 -->

500 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
(f) Any other operation involving the use of a lead compound.

‍‍‍‍‍

‍भाग‍4(ग)

(g) The cleaning of work-rooms where any of the operations aforesaid are carried on.
4. Requirements to be observed.- No person shall be employed or permitted to work in any
process involving the use of lead compounds if the process is such that dust or fume from a
lead compound is produced therein, or the persons employed therein are liable to be splashed
with any lead compound in the course of their employment unless the provisions of clause 5
to 9 are complied with.
5. Exhaust draught.- Where dust, fume, gas or vapour is produced in the process, provision
shall be made for removing them by means of an efficient exhaust draught so contrived as to
operate on the dust, fume, gas or vapour as closely as possible to the point of origin.
6. Certificate of fitness. - A person medically examined under clause 7 and found fit for
employment shall be granted by a Medical Officer a certificate of fitness and such certificate
shall be in the custody of the Manager of the factory. The certificate shall be kept readily
available for inspection by any Inspector-cum-Facilitator and the person granted such a
certificate shall carry with him, while at work, a token giving reference to such certificate.
7. Medical Examination. - (1) The person so employed shall be medically examined by a
Medical Officer within 15 days of his first employment in such process and thereafter shall
be examined by the Medical Officer at intervals of not more than three months, and a record
of such examinations shall be entered by the Medical Officer in the special certificate of
fitness granted under clause 6.
(2) If at any time the Medical Officer is of opinion that any person is no longer fit for
employment on the grounds that continuance therein would involve special danger to health,
he shall cancel the special certificate of fitness of that person.
(3) No person whose special certificate of fitness has been cancelled shall be employed unless
the Medical Officer, after re-examination, again certifies him to be fit for employment.
8. Protective clothing.- Suitable protective overalls and head coverings shall be provided,
maintained and kept clean by the factory occupier and such overalls and head coverings shall
be worn by the person employed.
9. Cleanliness of work-rooms, tools etc.- The rooms in which the persons are employed and
all tools and apparatus used by them shall be kept in a clean state.
SCHEDULE VII
Generation of gas from dangerous petroleum as defined in the Petroleum Act, 1934
1. Flame traps.- The plant for generation of gas from dangerous petroleum as defined in the
Petroleum Act, 1934 and associated piping and fittings shall be fitted with at least two
efficient flame traps so designed and maintained as to prevent a flash back from any burner to
the plant. One of these traps shall be fitted as close to the plant as possible. The plant and all
pipes and valves shall be installed and maintained free from leaks.
2. Generating building or room.- All plants for generation of gas from dangerous petroleum
as defined in the Petroleum Act, 1934 erected after the coming into force of the provisions
specified in this Schedule, shall be erected outside the factory building proper in a separate

<!-- page 59 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍501

well-ventilated building (hereinafter referred to as the "generating building"). In the case of
such plant erected before the coming into force of the provisions specified in this Schedule
there shall be no direct communication between the room where such plants are erected,
(hereinafter referred to as "the generating room") and the remainder of the factory building.
So far as practicable, all such generating rooms shall be constructed of fire-resisting
materials.
3. Fire extinguishers.- An efficient means of extinguishing petrol fires shall be maintained in
an easily accessible position near the plant for generation of gas from dangerous petroleum as
defined in the Petroleum Act, 1934.
4. Plant to be approved by Chief Inspector-cum-Facilitator.- Petrol gas shall not be
manufactured except in a plant for generating petrol gas the design and construction of which
has been approved by the Chief Inspector-cum-Facilitator .
5. Escape of petrol.- Effective steps shall be taken to prevent petrol from escaping into any
drain or sewer.
6. Prohibition relating to smoking.- No person shall smoke or carry matches, fire or naked
light or other means of producing a naked light or spark in the generating room or building or
in the vicinity thereof and a warning notice in the language understood by the majority of the
workers shall be posted in the factory prohibiting smoking and the carrying of matches, fire
or naked light or other means of producing a naked light or spark into such room or building.
7. Access to petrol or container.- No unauthorised persons shall have access to any petrol or
to a vessel containing or having actually contained petrol.
8. Electric fittings.- all electric fittings shall be of flame- proof construction and all electric
conductors shall either be enclosed in metal conducts or be lead-sheathed.
9. Construction of doors.- All doors in the generating room or building shall be constructed
to open outwards or to slide and no door shall be locked or obstructed or fastened in such a
manner that it cannot be easily and immediately opened from the inside while gas is being
generated and any person is working in the generating room or building.
10. Repair of containers.- No vessel that has contained petrol shall be repaired in a
generating room or building and no repairs to any such vessel shall be undertaken unless live
stream has been blown into the vessel and until the interior is thoroughly steamed out or other
equally effective steps have been taken to ensure that it has been rendered free from petrol or
inflammable vapour.
SCHEDULE VIII
Cleaning or smoothing, roughening etc. of articles by a jet of sand, metal shot or grit or
other abrasive propelled by a blast of compressed air or steam
1. Definitions.- For the purposes of this Schedule,(i) "Blasting" means cleaning, smoothing, roughening, or removing of any part of the
surface of any article by the use as an abrasive of a jet of sand, metal shot, or grit
or other material, propelled by a blast of compressed air or steam;

<!-- page 60 -->

502 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
(ii) "Blast enclosure" means a chamber, barrel, cabinet or any other enclosure
designed for the performance of blasting therein;
(iii) "Blasting chamber" means a blasting enclosure in which any person may enter at
any time in connection with any work or other-wise; and
(iv) "Cleaning of castings" where done as an incidental or supplemental process in
connection with the making of metal castings, means the freeing of the casting
from adherent sand or other substance and includes the removal of cores and the
general smoothing of a casting, but does not include the free treatment.
2. Prohibition of Sand Blasting.- Sand or any other substance containing free silica shall not
be introduced as an abrasive in to any blasting apparatus and shall not be used for blasting.
3. Precautions in connection with Blasting Operations.(1) Blasting to be done in blasting enclosure.- Blasting shall not be done except in a
blasting enclosure and no work, other than blasting and any work immediately incidental
thereto and clearing and repairing of the enclosure including the plant and appliances situated
therein, shall be performed in a blasting enclosure. Every door, aperture and joint of blasting
enclosure shall be kept closed and air-tight while blasting is being done therein.
(2) Maintenance of blasting enclosure.- Blasting enclosure shall always to be maintained in
good condition and effective measures shall be taken to prevent dust escaping from such
enclosures, and from apparatus connected therewith, into the air of any room.
(3) Provisions of separating apparatus.- There shall be provided and maintained for and in
connection with every blasting enclosure, efficient apparatus for separating so far as
practicable. Abrasive which has been used for blasting and which is to be used again as an
abrasive, from dust or particles of other materials arising from blasting and no such abrasive
shall be introduced into any blasting apparatus and used for blasting until it has been so
separated.
(4) Provision of ventilating plant.- (a) There shall be provided and maintained in connection
with every blasting enclosure efficient ventilating plant to extract, by exhaust draught
effected by mechanical means, dust produced in the enclosure. The dust extracted and
removed shall be disposed of by such method and in such a manner that it shall not escape
into the air of any room; and
(b) every other filtering or settling device situated in a room in which persons are employed,
other than persons attending to such bag or other filtering or settling device, shall be
completely separated from the general air of that room in an enclosure ventilated to the open
air.
(5) Operation of ventilating plant- The ventilating plant provided for the purpose of clause
(4) shall be kept in continuous operation whenever the blasting enclosure is in use whether or
not blasting is a actually taking place therein and in the case of blasting chamber, it shall be
in operation even when any person is inside the chamber for the purpose of cleaning or any
repair work.
4. Inspection and Examination.- (1) Every blasting enclosure shall be specially inspected by
a technical person, employed in the factory, at least once every week in which it is used for
blasting. Every blasting enclosure, the apparatus connected therewith and the ventilating

<!-- page 61 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍503

plant, shall be thoroughly examined and in the case of a ventilating plant tested by a
competent person at least once in six months.
(2) Particulars of the result of every such inspection, examination and test shall forthwith be
entered in a register which shall be kept in a register and shall be available for inspection by
any workman employed in or in connection with blasting in the factory. Any defect found on
any such inspection, examination or test shall be immediately reported by the person carrying
out the inspection, examination or test to the occupier, manager or, other appropriate person
and without prejudice to the foregoing requirements of this Schedule, shall be removed
without available delay.
5. Provisions of protective helmets, gauntlets and overalls.- (1) There shall be provided
and maintained for the use of all persons who are employed in a blasting chamber, whether in
blasting or any work connected therewith or in cleaning such a chamber, protective helmets
of National or International Standard and every such person shall wear the helmet provided
for his use whilst he is in the chamber and shall not remove it until he is outside the chamber.
(2) Each protective helmet shall carry a distinguishing mark indicating the person by whom it
is intended to be used and no person shall be allowed or required to wear a helmet not
carrying his mark or a helmet which has been worn by another person and has not since been
thoroughly disinfected.
(3) Each protective helmet when in use shall be supplied with clean and not unreasonably
cold air at a rate or not less than 0.17 cubic metres per minute.
(4) Suitable gauntlets and overalls shall be provided for the use of all persons while
performing blasting or assisting at blasting, and every such person shall while so engaged
wear the gauntlet and overall provided.
6. Precautions in connection with cleaning and other work.- (1) Where any person is
engaged upon cleaning of any blasting apparatus or blasting enclosure or of any apparatus of
ventilating plant connected therewith or the surroundings thereof or upon any other work in
connection with any blasting apparatus or blasting enclosure or with any apparatus or
ventilating plant connected therewith so that he is exposed to the risk of inhaling dust which
has arisen from blasting.
(2) In connection with any cleaning operation referred to in clause (5), and with the removal
of dust from filtering or setting devices all practicable measures shall be taken to dispose of
the dust in such a manner that it does not enter the air of any room. Vacuum cleaners shall be
provided and used wherever practicable for such cleaning operations.
7. Medical examination.- Every worker employed in the processes referred to in clause 1
shall be examined within 15 days of this employment. Such examination shall include tests
for lead in blood and urine, 'ALA' in urine, haemoglobin content, stippling of cells and
steadiness test.
8. Maintenance of vacuum cleaning plant.- Vacuum cleaning plant used for the purpose of
this Schedule shall be properly maintained.
9. Power to exempt or relax.- If the Chief Inspector-cum-Facilitator is satisfied that if any
factory or any class of factory, the use of sand or other substance containing free silica as an

<!-- page 62 -->

504 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
abrasive in blasting is necessary for a particular manufacture or process (other than the
process incidental or supplemental to making of metal castings) and that the manufacture or
process cannot be carried on without the use of such abrasive or that owing to the special
conditions or special method of work or otherwise any requirement of this Schedule can be
suspended either temporarily or permanently, or can be relaxed without endangering the
health of the person employed or that application of any of such requirements is for any
reason impracticable or inappropriate, he may, with the previous sanction of the State
Government, by an order in writing exempt the said factory or class of factory from such
provisions of this Schedule, to such an extent and subject to such conditions and for such
period as may be specified in the said order.

SCHEDULE IX
Liming and tanning of raw hides and skins and processes incidental thereto
1. Cautionary notices.- (1) Cautionary notices as to anthrax shall be affixed in prominent
positions in the factory where they may be easily and conveniently read by the persons
employed.
(2) A copy of a warning notice as to anthrax shall be given to each person employed when he
is engaged, and subsequently, if still employed, every year.
(3) Cautionary notices as to the effects of chrome on the skin shall be affixed in prominent
positions in every factory in which chrome solutions are used and such notices shall be so
placed as to be easily and conveniently read by the persons employed.
(4) Notices shall be affixed in prominent places in the factory stating the position of the
"First-Aid" box or cupboard and the name of the person in-charge of such box or cupboard.
(5) If any person employed in the factory is illiterate, effective steps shall be taken to explain
carefully to such illiterate person the content of the notice specified in sub- clause (1), (2), (3)
and (4) and if chrome solutions are used in the factory.
2. Protective clothing.- The occupier shall provide and maintain in good condition the
following articles of protective clothing:
(a) water-proof footwear, leg covering, aprons and gloves for persons employed in
processes involving contact with chrome solutions, including the preparation of
such solutions:
(b) gloves and boots for persons employed in lime yard; and
(c) protective footwear, aprons and gloves for persons employed in processes,
involving the handling of hides or skins, other than in processes specified in subclauses (a) and (b):
Provided that the gloves, aprons, leg coverings or boots of National or
International Standards.
3. Medical examination.- Every worker employed in any of these processes to which the
schedule applies shall be examined within 15 days of his first employment. Such examination

<!-- page 63 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍505

shall include skin test and dermatosis and detection of anthrax bacillus from local lesion by
gram stain.

SCHEDULE X
Chemical Works
Preliminary
PART-I
1. Application.- This schedule shall apply to all manufacture and processes incidental thereto
carried on in chemical works.
2. Definitions.- For the purpose of this schedule,(a) "Chemical Works" means any factory or such parts of any factory as are listed in
Appendix 'A' to this schedule;
(b) "efficient exhaust draught" means localised ventilation effected by mechanical or
other means for the removal of gas, vapour, fume or dust to prevent it from
escaping into the air of any place in which work is carried on;
(c) "bleaching powder" means the bleaching powder commonly called chloride of
lime;
(d) "Chlorate" means chlorate or perchlorate;
(e) "caustic" means hydroxide of potassium or sodium;
(f) "Chrome process" means the manufacture of chromate or bichromate of potassium
or sodium or the manipulation, movement or other treatment of these substances;
(g) "nitro or amino process" means the manufacture of nitro or amino derivatives of
phenol and of benzene or its homologues, and the making of explosives with the
use of any of these substances;
(h) "toxic substances" means all those substances which when they enter into the
human body, through inhalation or ingestion or absorption through skin, in
sufficient quantities cause fatality or exert serious affliction of health or chronic
harmful effects on the health of persons exposed to it due to its inherent chemical
or biological effects. In respect of substances whose TLV as specified in rules,
exceeding the concentration specified therein would make the substance toxic;
(i) "emergency" means a situation or condition leading to a circumstance or set of
circumstances in which there is danger to the life or health of persons or which
could result in big fire or explosion or pollution to the work and outside
environment, affecting the workers or neighbourhood in a serious manner.
demanding immediate action;
(j) "dangerous chemical reactions" means high speed reactions, run away reactions:
delayed reactions, etc. and are characterised by evolution of large quantities of

<!-- page 64 -->

506 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
heat, intense release of toxic or flammable gases or vapours; sudden pressure
build-up etc.; and
(k) "manipulation" means mixing, blending, filling, emptying, grinding, sieving,
drying, packing, sweeping, handling, using etc. of substance given in appendix A;
PART-II
General requirements
Applying to all the works in Appendix ‘A’
1. House-keeping.- (1) Any spillage of materials shall be cleaned up before further
processing.
(2) Floors, platforms, stairways, passages and gangways shall be kept free of any
obstructions.
(3) There shall be provided easy means of access to all parts of the plant to facilitate cleaning.
2. Improper use of chemicals.- No Chemicals or solvents or empty containers containing
chemicals or solvents shall be permitted to be used by workers for any purposes other than in
the processes for which they are supplied.
3. Cautionary notices and instructions.- (1) Cautionary notices in a language understood by
the majority of workers shall be prominently displayed in all hazardous areas drawing the
attention of all workers about the hazards to health, hazards- involving fire and explosion and
any other hazard such as consequences of testing of material or substances used in the
process or using any contaminated container for drinking or eating, to which the workers
attention should be drawn for ensuring their safety and health.
(2) In addition to the above cautionary notice, arrangement shall be made to instruct and
educate all the workers including illiterate workers about the hazards in the process including
the specific hazards to which they may be exposed to, in the normal course of their work.
Such instructions and education should also deal with the hazards involved in unauthorised
and unsafe practices including the properties of substances used in the process under normal
conditions as well as abnormal conditions and the precautions to be observed against each
and every hazard, Further, an undertaking from the workers shall be obtained within 1 month
of their employment and for old workers employed, within one month of coming into
operation of the rules, to the effect that they have read the contents of the cautionary notices
and instructions, understood them and would abide by them. The training and instructions to
all workers and all supervisory personnel shall include the significance of different types of
symbols and colours used on the labels stuck or painted on the various types of containers
and pipelines.
4. Evaluation and provision of safe guards before the commencement of process.- (1)
Before commencing any process or any experimental work, or any new manufacture covered
under appendix 'A' the occupier shall take all possible steps to ascertain definitely all the
hazards involved both from the actual operations and the chemical reactions including the
dangerous chemical reactions. The properties of the raw materials used, the final product to
be made, and any by-products derived during manufacture, shall be carefully studied and

<!-- page 65 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍507

provisions shall be made for dealing with any hazards including effects on workers, which
may occur during manufacture.
(2) Information in writing giving details of the process, its hazards and the steps taken or
proposed to be taken from the design stage to disposal stage for ensuring the safety as in subpara (1) above should be sent to the Chief Inspector-cum-Facilitator at the earliest but in no
within 60 days of commencing manufacture, handling, or storage of any of items covered
under Appendix 'A' whether on experimental basis, or as pilot plant or as trial production, or
as large scale manufacture.
(3) The design, construction, installation, operation maintenance and disposal of the
buildings, plant and facilities shall be taken into consideration effective safe-guards against
all the safety and health hazards so evaluated.
(4) The requirements under the sub-clause (1) to (3) shall not act in lieu of or in derogation
to, any, other provisions contained in any act governing the work.
5. Authorised entry.- Authorised persons, only shall be permitted to enter any section of the
factory or plant where any dangerous operations or processes are being carried on or where
dangerous chemical, reactions are taking place or where hazardous chemicals are stored.
6. Examination of instruments and safety devices.- (1) All instruments and safety devices
used in the process shall be tested before taking into use and after carrying out any repair to
them and examined once in a month, by a competent employee of the factory, Records of
such tests and examinations shall be maintained in a register.
(2) All instruments and safety devices used in the process shall be operated daily or as often
as it is necessary, to ensure its effective and efficient working at all times.
7. Electrical installations.- All electrical installations used in the process covered in
Appendix 'A' shall be of an appropriate type to ensure safety against the hazard prevalent in
that area such as suitability against dust, dampness, corrosion, flammability and explosivity
etc. and shall conform to the relevant ISI specifications governing their construction and use
for that area.
8. Handling and storage of chemicals.- (1) The containers for handling and storage of
chemicals shall be of adequate strength taking into consideration the hazardous nature of the
contents. They shall also be provided with adequate labelling and colour coding arrangements
to enable identification of the containers and their contents indicating the hazards and safe
handling methods and shall conform to the respective ISI standards. The instructions given in
the label shall be strictly adhered to. Damaged containers shall be handled only under
supervision of a knowledgeable and responsible person and spillage shall be rendered
innocuous in a safe manner using appropriate means.
(2) The arrangements for the storage of chemicals including charging of chemicals in reaction
vessels and containers shall be such as to prevent any risk of fire or explosion or formation of
toxic concentration of substances above the limits specified in rules.
(3) Without prejudice to the generally of the requirements in sub-clause (2), above, the
arrangements shall have suitable ventilation facilities and shall enable the maintenance of
safe levels in vessels and containers. Such arrangements shall also take into consideration, the

<!-- page 66 -->

508 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
type of flooring and the capacity of flooring and the compatibility requirements of substances
with other chemicals stores nearby.
(4)

(a) Storage of chemicals and intermediate products, which are highly unstable or
reactive or explosive shall be limited to the quantities required for two months
use.
(b) Whenever the quantities laid down in the above item (a) are to be exceeded, the
permission of the Chief Inspector-cum-Facilitator shall be obtained.
(c) Notwithstanding anything contained in item (a) and (b) above, the Chief Inspectorcum-Facilitator may direct any factory carrying out processes covered in
Appendix 'A' to further limit the storage of hazardous substances to quantities less
than two months on considerations of safety.

(5) Standby arrangements equal to the biggest container shall always be available to transfer
the toxic substance quickly into the stand by storage facility if any defect develops in any of
the containers resulting in the release of toxic substances.
(6) Any storage facility constructed using non-metallic material such as fiber glass
Reinforced plastics (FRP), all glass vessels etc., shall have adequate strength to withstand the
stress, if any, exerted by the contents and shall be properly anchored, working platforms,
access ladders, pipelines etc. used in such storage facility shall not have any support on the
structure of the storage facility and shall be independently supported.
9. Facility for isolation.- The plant and equipment shall be so constructed and maintained as
to enable quick isolation of plant or part of plant or equipment, with appropriate indication.
One copy of the layout plan indicating the isolation facilities shall always be available with
the security personnel's, the maintenance and the health and safety personnel and these
isolation facilities shall be checked for its effectiveness once in a month.
10. Personal protective equipment.- (1) All workers exposed to the hazards in the processes
covered by this schedule shall be provided with appropriate and approved type of personal
protective equipment. Such equipment shall be in a clean sterile and hygienic condition
before issue.
(2) The occupier shall arrange to inform, educate and supervise all the workers in the use of
personal protective equipment while carrying out the job.
(3) As regards any doubt regarding the appropriateness of any personal protective equipment
the decision of the Chief Inspector-cum-Facilitator will be final.
11. Alarm systems.- (1) Suitable and effective alarm systems giving audible and visible
indications shall be installed at the control room as well as in all strategic locations where
process control arrangements are available so as to enable corrective action to be taken before
the operational parameters exceed the predetermined safe levels or lead to conditions
conducive for an outbreak of fire or explosion to occur. Such alarm systems shall be checked
daily and tested every month at least once to ensure its performance efficiency at all times.
(2) The Chief Inspector-cum-Facilitator may direct such systems to be installed in case
of plants or processes where toxic materials are being used and spillage or leakage of which
may cause wide spread poisoning in or around the plant.

<!-- page 67 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍509

12. Control of escape of substances into the work atmosphere.- (1) Effective arrangements
such as, enclosure or by pass, or efficient exhaust draught, maintenance of negative pressure
etc., shall be provided in all plants, containers, vessels, sewers drains, flues, ducts, and
culverts, and burned pipes and equipment, to control the escape and spread of substances
which are likely to give rise to fire or explosion or toxic hazards during normal working and
in the event of accident or emergency.
(2) In the event of the failure of the arrangements for control resulting in the escape of
substances in the work atmosphere immediate steps shall be taken into control the process in
such a manner, that further escape is brought down to the safe level.
(3) The substances that would have escaped into the work atmosphere before taking
immediate steps as required in sub-para (2), shall be rendered innocuous by diluting with air
or water or any other suitable agent or by suitably treating the substances.
13. Control of dangerous chemical reactions.- Suitable provision, such as automatic and or
remote-control arrangements shall be made for controlling the effects of "dangerous chemical
reactions." In the event of failure of control arrangements automatic flooding or blanketing or
other effective arrangements shall come into operation.
14. Testing, examination and repair of plant & equipment.- (1) All parts of plant,
equipment and machinery used in the process which in the likely event of their failure may
give rise to an emergent situation shall be tested by a competent person before commencing
process and retested at an interval of two years or after carrying out repairs to it. The
competent person shall identify the parts of the plant, equipment and machinery required to
be tested as aforesaid and evolve a suitable testing procedure. In carrying out the test as
mentioned above in respect of pressure vessels or reaction vessels the following precautions
shall be observed, namely:(a) before the test is carried out, each vessel shall be thoroughly cleaned and
examined externally and as far as practicable, internally also for surface defects,
corrosion and foreign matter. During the process of cleaning and removal of
sludge, if any, all due precautions shall be taken against fire or explosion, if such
sludge is of pyrophoric nature or contains spontaneously combustible chemicals:
(b) as soon as the test is completed, the vessel shall be thoroughly dried internally and
shall be clearly stamped with the marks and figures indicating the person by
whom testing has been done, and the date of test: and
(c) any vessel which fails to pass the test or which for any other reason is found to be
unsafe for use shall be destroyed or rendered unusable under intimation to the
Chief Inspector-cum-Facilitator :
(2) Specific parts of plant, equipment, machinery which in the likely event of failure may
give rise to an emergent situation identified by occupier or manager shall be examined once
in six months by the competent person,
(3) Records of testing an examination referred to in clause (1) and (2) shall be maintained as
long as that part of the plant, equipment and machinery are in use,

<!-- page 68 -->

510 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
(4) All repair work including alteration, modification and addition to be carried out to the
plant, equipment and machinery shall be done under the supervision of a responsible person
who shall evolve a procedure to ensure safety and health of persons doing the work. When
repairs or modification is done on pipelines, and joints are required to be welded, but welding
of joints shall be preferred, wherever necessary, the responsible person shall regulate the
aforesaid work through a 'permit to work system'.
15. Staging.- (1) All staging that is erected for the purpose of maintenance work or repair
work or for work connected with entry into confined spaces and used in the processes
included in Appendix 'A', shall be stable, rigid and constructed out of substantial material of
adequate strength. Such staging shall conform to the respective Indian standard
specifications,
(2) Staging shall not be erected over any closed or open vessel unless the vessel is so
constructed and ventilated to prevent exposure of persons working on the stages.
(3) All the staging constructed for the purpose of this para shall have appropriate access
which are safe and shall be fitted with proper hand rails to a height of one meter and toe
board.
16. Seating arrangements.- The seating arrangements provided for the operating personnel
working in processes covered in Appendix 'A' shall be located in a safe manner as to prevent
the risk of exposure to toxic, flammable and explosive substances evolved in the work
environment in the course of manufacture or repair or maintenance, either due to failure of
plant and equipment or due to the substances which are under pressure, escaping into the
atmosphere.
17. Entry into or work in confined spaces.- (1) The occupier of every factory to which the
provisions of this schedule apply, shall ensure the observance of the following precautions
before permitting any person to enter or work inside the confined spaces—
(a) identify all confined spaces and the nature of hazards that are encountered in such
spaces. normally or abnormally, and arrange to develop the most appropriate
safeguards for ensuring the safety and health of persons entering into or working
inside, the confined spaces;
(b) regulate the entry or work inside the confined spaces through a 'permit to work
system' which should include the safeguards so developed as required under sub
clause (a) above:
(c) before testing the confined space for entry into or work, the place shall be rendered
safe by washing or cleaning with neutralizing agents or purging with steam or
inert gases and making adequate forced ventilation arrangements or such measure
which will render the confined space safe:
(d) shall arrange to carry out such test as are necessary for the purpose by a competent
person and ensure that the confined space is safe for the persons to enter or work.
Such testing shall be carried out as often as is necessary during the course of work
to ensure its continued safety:
(e) shall arrange to educate and train the personnel who would be required to work in
confined spaces about the hazard involved in the work. He shall also keep in
readiness the appropriate and approved personal protective equipment including

<!-- page 69 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍511

arrangements for rescue, resurrection and first aid, and shall arrange supervision
of the work at all times by a responsible and knowledgeable person,
(2) The manager shall maintain a log book of all entry into or work in, confined space and
such record shall contain the details of persons assigned for the work, the location of the
work and such other details that would have a bearing on the safety and health of the persons
assigned for this work. The log book so maintained shall be retained as long as the concerned
workers are in service and produced to the Inspector-cum-Facilitator when demanded.
18. Maintenance work etc.- (1) All the work connected with the maintenance of plants and
equipment including cleaning of empty containers which have held hazardous substances
used in the processes covered in this schedule, shall be carried out under 'permit to work
system' employing trained personnel and under the supervision of responsible person, having
knowledge of the hazards and precautions required to deal with them.
(2) Maintenance work shall be carried out in such a manner that there is no risk to persons in
the vicinity or to persons who pass by. If necessary, the place of such work shall be cordoned
off or the presence of unconnected persons effectively controlled,
19. Safety sampling personnel.- The occupier shall ensure the safety of persons assigned for
collecting samples by instructing them on the safe procedures, such personnel shall be
provided with proper and approved personal protective equipment, if required.
20. Ventilation.- Adequate ventilation arrangements shall be provided and maintained at all
times in the process area where dangerous or toxic or flammable or explosive substances
could be evolved. These arrangements shall ensure that concentration, which are either
harmful or could result in explosion, are not permitted to be built up in the work environment.
21. Procedures for meeting emergencies.- (1) The occupier of every factory carrying out
the works covered in Appendix 'A', shall arrange to identify all types of possible emergencies
that could occur in the processes during the course of work or while carrying out maintenance
work or repair work. The emergencies so identified shall be reviewed every year.
(2) The occupier shall formulate a detailed plan to meet all such identified emergencies
including arrangements for summoning out-side help for rescue and firefighting and
arrangements for making available urgent medical facilities.
(3) The occupier shall send the list of emergencies and the details of procedures and plans
formulated to meet the emergencies, to the Chief Inspector-cum-Facilitator .
(4) The occupier shall arrange to install distinctive and recognisable warning arrangements to
caution all persons inside the plant as well as the neighbouring community, if necessary, to
enable evacuation of persons and to enable the observance of emergency procedures by the
persons who are assigned emergency duties. All concerned must be well informed about the
warning arrangements and their meaning. The arrangements must be checked for its
effectiveness every month.
(5) The occupier shall arrange to suspend the further process work in a place where
emergency is established and shall forthwith evacuate all persons in that area except workers
who have been assigned emergency duties.

<!-- page 70 -->

512 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
(6) All the employees of the factory shall be trained about the action to be taken by them
including evacuation procedures during emergencies.
(7) All emergency procedures must be rehearsed every three months and deficiencies, if any,
in the achievements of the objectives shall suitably be corrected.
(8) The occupier shall arrange to have ten percent of the workers trained in the use of first aid
firefighting appliances and in the rendering of specific first aid measures taking into
consideration the special hazards of the particular process.
(9) The occupier shall furnish immediately on request the specific chemical identity of the
hazardous substance to the treating physician when the information is needed to administer
proper emergency or first aid treatment to exposed persons.
22. Danger due to effluents.- (1) Adequate precautions shall be taken to prevent the mixing
of effluents from different processes and operations which may cause dangerous or poisonous
gases to be evolved.
(2) Effluents which contain or give rise in the presence of other effluents to poisonous gases
shall be provided with independent drainage systems to ensure that they may be trapped and
rendered safe.
PART-III
Fire and explosions risks
1. Sources of ignition including lighting installation.- (1) No internal combustion engine
and no electric motor or other electrical equipment, and fittings and fixtures capable of
generating sparks or otherwise causing combustion or any other source of ignition or any
naked light shall be installed or permitted to be used in the process area where there could be
fire and explosion hazards.
(2) All hot exhaust pipes shall be installed outside a building and other hot pipes or hot
surface or surfaces likely to become hot shall be suitable protected.
(3) The classification of work areas in terms of its hazard potential and the selection of
electrical equipment or other equipment that could constitute a source of ignition shall be in
accordance with the respective Indian Standard.
(4) Where a flammable atmosphere may be prevalent or could occur, the soles of footwear
worn by workers shall have not metal on them, and the wheels of trucks or conveyors shall be
conductive types.
(5) All tools and appliances used for work in this area shall be of non-sparking type.
(6) Smoking in process areas where there are risks of fire and explosion shall be prohibited,
and warning notices in the language understood by majority of workers shall be posted in the
factory prohibiting smoking into specified areas.
2. Static electricity.- (1) All machinery and plant particularly, pipelines and belt drives, on
which static charge is likely to accumulate, shall be effectively earthed. Receptacles for
flammable liquids shall have metallic connections to the earthed supply tanks to prevent
static sparking, where necessary, humidity shall be regulated.

<!-- page 71 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍513

(2) Mobile tanker wagons shall be earthed during filling and discharge, and precautions shall
be taken to ensure that earthing is effective before such filling or discharge takes place.
3. Lighting Protection.- Lighting protection arrangements shall be fitted where necessary
and shall be maintained.
4. Process heating.- The method of providing heat for a process likely to result in fire and
explosion shall be as safe as possible and where the use of naked flame is necessary, the plant
shall be so constructed as to prevent any escaping flammable gas, vapour, or dust coming into
contact with the flame, or exhaust gases, or other sources likely to cause ignition. Wherever
possible, the heating arrangements shall be automatically controlled at a predetermined
temperature below the danger temperature.
5. Leakage of flammable liquids.- (1) Provision shall be made to confine by means of bund
walls, dikes sumps etc. possible leakages from storage vessels containing flammable liquid.
(2) Waste material in contact with flammable substances shall be disposed of suitably under
the supervision of knowledgeable and responsible person.
(3) Adequate and suitable firefighting appliances shall be installed in the vicinity of such
vessels.
6. Safety valves.- Every still and every closed vessel in which gas is evolved or into which
gas is passed, and in which the pressure is liable to rise above the atmospheric pressure, shall
have attached to it a pressure gauge, and a proper safety valve or other equally efficient
means to release the pressure. These appliances shall be maintained in good condition.
7. Installation of pipeline etc.- All pipelines carrying flammable or explosive substances
shall be protected from mechanical damage shall be examined by a responsible person once
in a week to detect any deterioration or defects. or accumulation of flammable or explosive
substances, and record kept of any defect found and repairs made.
8. Firefighting systems.- (1) Every factory having licence for more than 100 workers and
carrying out processes listed in Appendix 'A' shall provide,(a) Trained and responsible firefighting squad so as to effectively handle the
firefighting and lifesaving equipment in the event of fire or other emergency.
Number of persons in this squad will necessarily depend upon the size of risk
involved, but in no case shall there be less than 8 such trained persons to be
available at any time. The squad shall consist of watch and ward personnel fire
pump man and departmental supervisors and operators trained in the operation of
fire & emergency services.
(b) Squad leaders shall be trained from a recognised institution.
(c) Squad personnel shall be provided with clothing and equipment including helmets,
boots and belts.
(2) Every factory having licence up to 100 workers and carrying out processes listed in
Appendix 'A' shall provide(a) Trained and responsible firefighting squad so as to effectively handle the
firefighting and lifesaving equipment in the event of fire or other emergency.

<!-- page 72 -->

514 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
Number of persons in this squad will necessarily depend upon the size of risk
involved, but in no case shall there be less than 2 such trained persons to be
available at any time.
(b) Squad personnel shall be provided with clothing and equipment including helmets,
boots and belts.
(3) A muster roll showing the duties allocated to each member of the squad shall be prepared
and maintained.
(4) The pump man shall be thoroughly conversant with the location of all appliances. He shall
be responsible for maintaining all firefighting equipment in proper working order. Any defect
coming to his notice shall be immediately be brought to the notice of squad leader.
(5) As far as practicable, the fire pump room and the main gate(s) of the factory be connected
to all manufacturing or storing areas through telephone interlinked and placed in a convenient
location near such areas.
PART-IV
Risks of toxic substances
1. Leakage.- (1) All plants shall be so designed and constructed to prevent the escape of toxic
substance. Where necessary, separate buildings, rooms, or protective structures shall be used
for the dangerous stages of the process and the buildings shall be so designed as to localise
any escape of toxic substances.
(2) Catch pits, and blind walls, dikes, or other suitable safeguards shall be provided to restrict
the serious effects of such leakages. Catch pits shall be placed below joints in pipelines where
there is danger involved to maintenance and other workers from such leakage.
2. Drainage.- Adequate drainage shall be provided and shall lead to cool action taken
specifically provided for this purpose wherein deleterious material shall be neutralised,
treated or otherwise rendered safe before it is discharged into public drains or sewers.
3. Covering of vessels.- (1) Every fixed vessels of structure containing any toxic substances
and not so covered as to eliminate all reasonable risk of accidental contact or any portion of
the body of a worker, shall be so constructed as to avoid physical contact.
(2) Such vessels shall unless its edge is at least 90 centimeters above the adjoining ground or
platform, be securely fenced to a height of at least 90 centimeters above such adjoining
ground platform.
(3) Where such vessels adjoin and the space between them clear of any surrounding bricks or
other work is either less than 45 centimeters in width but is not securely fenced on both sides
to a height of at least 90 centimeters, secure barriers shall be so placed as to prevent passage
between them:
Provided that sub-clause (2) of this clause shall not apply to,(a) Saturators used in the manufacture of sulphate of ammonia; and
(b) that part of the sides of brine evaporating pans which require raking, drawing or
filling.

<!-- page 73 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍515

4. Continuous exhaust arrangement.- (1) Any process evolving toxic vapour, gas, fume and
substance shall have, efficient continuous exhaust draught, such arrangement shall be
interlocked in the process control wherever possible.
(2) In the event of failure of continuous exhaust arrangement means shall be provided to
automatically stop the process.
5. Work Bench.- All the work benches used in processes involving the manipulation of toxic
substances, shall be graded properly and shall be made of smooth impervious surface which
shall be washed daily after the completion of work.
6. Waste disposal.- (1) There shall be provided a suitable receptacle made of non-absorbable
material with a tightly fitting cover for depositing waste material soiled with toxic substances
and the contents of such receptacle shall be destroyed by burning or using other suitable
methods under the supervision of a responsible person.
(2) During the course of manufacture, whenever any batch or intermediate products having
toxicity is rejected on considerations of quality, sufficient precautions shall be taken to render
them in nouns or otherwise treat them or inactive them before disposal.
(3) The empty containers of toxic substances shall be cleaned thoroughly before disposal
under the supervision of a responsible person.
PART-V
Special Provisions
1. Special precautions for nitro or amino processes.- (1) Unless the crystallised nitro or
amino substances or any of its liquor is broken or agitated in a completely enclosed process
so as not to give rise to dust or fume, such process shall be carried on under an efficient
exhaust draught or by adopting any other suitable means in such a manner as to prevent the
escape of dust or fume in the working atmosphere.
(2) No part of the plant or equipment or implements which was in contact with nitro or amino
compounds shall be repaired, or handled unless they have been emptied and thoroughly
cleaned and decontaminated.
(3) Filling of containers with nitro or amino compounds shall be done only by using a
suitable scoop to avoid physical contact and the drawing of the containers in the stove shall
be done in such a manner that the hot and contaminated air from the stove is not drawn into
the work room.
(4) Processes involving the steaming into or around any vessel containing nitro or amino
compounds or its raw materials shall be carried out in such a manner that the steam or vapour
is effectively prevented to be blown back into the working atmosphere.
(5) Suitable antidotes such as methylene blue injections shall always be available at
designated placed of work for use during emergency involving the poisoning with nitro or
amino compounds.
2. Special precautions for chrome processes.- (1) Grinding and sieving of raw materials in
chrome processes shall be carried on in such a manner and under such condition as the secure
effective separation from any other processes and under an efficient exhaust draught.

<!-- page 74 -->

516 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
(2) There shall be washing facilities located very near to places where wet chrome process
such as leaching, acidification, sulphate settling, evaporation, crystallisation, centrifugation or
packing are carried out, to enable quick washing of affected parts of body with running water.
(3) Weekly inspection of hand and feet of all persons employed in chrome process shall be
done by a qualified nurse and record of such inspections shall be maintained.
(4) There shall be always available at designated places of work suitable ointment such as
glycerine, Vaseline, etc. and water- proof plaster in a separate box readily accessible to the
workers so as to protect against per-formation of nasal septum.
3. Special precautions for processes carried out in all glass vessels.- (1) Processes and
chemical reactions such as manufacture of vinyl chloride, benzyl chloride etc. which are
required to be carried out in all glass vessels shall have suitable means like substantial wire
mesh covering to protect persons working nearby in the event of breakage of glass vessels.
(2) Any spillage of emission of vapour from the all glass vessel due to breakage, shall be
immediately inactivated or rendered innocuous by suitable means such as dilution with water
or suitable solvents so as to avoid the risks of fire or explosion or health hazards.
4. Special precautions for processes involving chlorate manufacture.- (1) Crystallisation,
grinding or packing of chlorate shall not be done in a place used for any other purpose and
such places shall have hard, smooth and impervious surfaces made of non-combustible
material. The place shall be thoroughly cleaned daily.
(2) The personal protective equipment like overall etc. provided for the chlorate workers shall
not be taken from the place of work and they shall be thoroughly cleaned daily.
(3) Adequate quantity of water shall be available near the place of chlorate process for use
during fire emergency.
(4) Wooden vessels shall not be used for the crystallisation of chlorate or to contain
crystallised ground chlorate.
5. Special precaution in the use of plants and equipment made from reinforced plastics.(1) All Plant and equipment shall conform to appropriate Indian Standard.
(2) Care shall be taken during storage, transport, handling and installation of plant and
equipment to avoid accidental damage:
(3) All plants and equipment shall be installed in such a way as to ensure that loads are
distributed as intended in design or as per the recommendations of the manufacturers.
(4) All pipe works shall be supported so that total loads local to the branches on the vessel or
tank do not exceed their design values.
(5) After erection all plants and equipment shall be subjected to a pressure test followed by a
thorough examination by competent person. The test and examination shall be as per relevant
standard. A Certificate of test and examination by competent person shall be obtained and
kept available at site.
(6) All plant and equipment shall be subjected to periodical test and examination and record
maintained as per clause 14 in part II of this schedule:
(7) Plants and equipment during their use shall not be subjected to over filling or over
loading beyond rated capacity.

<!-- page 75 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍517

PART-VI
Medical requirements
1. Decontamination facilities.- In all places where toxic substances are used in processes
listed in Appendix 'A' the following provisions shall be made to meet an emergency,(a) Fully equipped first aid box;
(b) Readily accessible means of drenching with water, parts of body of persons, and
clothing of persons who have been contaminated with such toxic and corrosive
substances, and such means shall be as shown in the table below:No. of persons employed at any time
Up to Between

No. of drenching showers

50 persons

2

51 to 100

3

101 to 200

3 + 1 for every 50 persons
thereafter

201 to 400

5 + 1 for every 100 persons
thereafter

401 and
above

7 + 1 for every 200 persons
thereafter

(c) A sufficient number of eye wash bottles filled with distilled water or suitable
liquid, kept in boxes or cupboards conveniently situated and clearly indicated by a
distinctive sign which shall be visible at all times.
PART-VII
Additional Welfare Amenities
1. Special bathing facilities.- (1) The occupier of any factory carrying out the process
covered under appendix shall provide special bathing facilities for all the workers employed
and such facilities shall be provided at the rate of 1 for 25 workers and part thereof. and shall
be maintained in the clean and hygienic condition.
(2) The occupier shall insist all the workers employed in the process covered in Appendix 'B'
to take bath after the completion of the days or shift work using the bathing facilities so
provided and shall also effectively prevent such workers taking bath in any place other than
the bathing facilities.
(3) Not-withstanding anything contained in sub-para (1) above the Chief Inspector-cumFacilitator may require in writing the occupier of any factory carrying out any other process
for which in his opinion bathing facilities are essential from the health point of view, to
provide special bathing facilities.

<!-- page 76 -->

518 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
Part-VIII
Exemptions
1. Power of exemption.- The State Government or subject to the control of the State
Government, the Chief Inspector-cum-Facilitator -cum Facilitator may exempt from the
compliance with any of the requirements of this schedule partly or fully, any factory carrying
out processes covered in appendix 'A', if it is clearly and satisfactorily established by the
occupier that the compliance with any of the requirement is not necessary to ensure the safety
and health of persons employed suitable and effective alternate arrangements are available to
any of the requirements covered in this schedule.
Appendix 'A'
Any works or that part of works in which:(a) the manufacture, manipulation or recovery of any of the following is carried on:(i) Sodium, potassium, iron, aluminium, cobalt; nickel. copper, arsenic, antimony,
chromium, zinc, selenium, magnesium, cadmium, mercury, beryllium and
their organic and inorganic salts, alloys, oxides and any hydroxides;
(ii) ammonia, ammonium hydroxide and salts of ammonium;
(iii) the organic or inorganic compounds of sulphurous, sulphuric. nitric, nitrous
hydrochloric, hydrofluoric, hydroiodic, hydro sulphuric, hydrobromic, boric;
(iv) Cyanogen compounds, cyanide compounds, cyanate compounds:
(v) Phosphorus and its compounds other than organophosphorus insecticides;
(vi) Chlorine.
(b) hydrogen sulphide is evolved by the decomposition of metallic sulphides, or
hydrogen sulphide is used in the production of such sulphides;
(c) bleaching powder is manufactured or chlorine gas is produced in chloralkali
plants:
(d) (i) gas tar or coal tar or bitumen or shale oil asphalt or any residue of such tar is
distilled or is used in any process of chemicals manufacture:
(ii) tar based synthetic colouring matters or their intermediates are produced:
(e) nitric acid is used in the manufacture of nitro compounds;
(f) explosives are produced with the use of nitro compounds;
(g) aliphatic or aromatic compounds or their metallic and non-metallic derivatives or
substituted derivatives, such as chloroform, ethylene glycol, formaldehyde, benzyl
chloride, phenol, methyl ethyl ketone peroxide, cobalt carbonyl tungsten carbide
etc. are manufactured or recovered.

<!-- page 77 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍519

Appendix B
Concerning special bathing accommodation in pursuance of clause 4 of Part-IV
1. Nitro or amino processes.
2. All chrome processes.
3. Process of distilling gas or coal tar or processes of chemical manufacture in which tar is
used.
4. Processes involving manufacturing, manipulation, handling or recovery of cyanogen
compound, cyanide compound, cyanate compounds.
5. Processes involving manufacture of bleaching powder or production of chlorine gas in
chloralkali plants.
6. Manufacture, manipulation or recovery of nickel and its compounds.
7. All processes involving the manufacture, manipulation or recovery of aliphatic or
aromatic compounds or their derivatives or substituted derivatives.
Schedule XI
Manufacture of Pottery and Process Incidental Thereto
1. Definitions.- For the purposes of this schedule,(a) "Pottery" includes earthenware, stoneware, porcelain, china tile and any other
article made from clay or from a mixture containing clay and other materials such
as quartz, flint, feldspar and gypsum;
(b) "efficient exhaust draught" means localised ventilation affected by mechanical or
other means for removal of dust or fume so as to prevent it from escaping into the
air of any place in which work is carried on. No draughts, shall be deemed
efficient which fails to remove effectively dust or fume generated at the point
where dust or fume originates;
(c) "fettling" includes scalloping, towing, sand papering, sand sticking, brushing or
any other process of cleaning of pottery ware in which dust is given off;
(d) "Lead less glaze" means a glaze which does not contain more than 1% of dry
weight of a lead compound calculated as lead monoxide;
(e) "Low solubility glaze" means a glaze which does not yield to dilute hydrochloric
acid more than five per cent of its dry weight of a soluble lead compound
calculated as lead monoxide when determined in the manner described below:A weighted quantity of the material which has been dried at 100 degree C and
thoroughly mixed shall be continuously shaken for one hour, at the common
temperature with 1,000 times its weight of an aqueous solution of hydrochloric
acid containing 0.25 per cent by weight of hydrogen chloride. This solution shall
thereafter be allowed to stand for one hour and then filtered. The lead salt
contained in the clear filtrate shall then be precipitated as lead sulphide and
weighed as lead sulphide;

<!-- page 78 -->

520 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
(f) "ground or powdered flint or quartz" does not include natural sands; and
(g) "potters’ shop" includes all places where pottery is formed by pressing or by any
other process and all places where shaping, fettling or other treatment of pottery
articles prior to placing for the biscuit, fire is carried on.
2. Efficient exhaust draught.- The following process shall not be carried on without the use
of an efficient exhaust draught:(a) All processes involving the manipulation or use of a dry and unfretted lead
compound;
(b) The fettling operations of any kind, whether on greenware or biscuit; provided that
this shall not apply to the wet fettling, and the occasional finishing of pottery
articles without the aid of mechanical power;
(c) The shifting of clay dust or any other material for making or other articles by
pressure, except where,(i) this is done in a machine so enclosed as to effectually prevent the escape of
dust, or
(ii) the material to be shifted so damp that no dust can be given off;
(d) The processing of tiles from clay dust, an exhaust opening being connected with
each press. This sub-clause shall also apply to the pressing from clay dust of
articles other than tiles, unless the material is so damp that no dust is given off;
(e) The fettling of tiles made from clay dust by pressure, except where the fettling is
done wholly on, or with, damp material. This sub-clause shall also apply to the
fettling of other articles made from clay dust, unless the material is so damp that
no dust is given off;
(f) The process of loading and unloading of saggars where handling and manipulation
of ground and powdered flint, quartz, alumina or other materials are involved.
(g) The brushing of earthenware biscuit, unless the process is carried on in a room
provided with efficient general mechanical ventilation or other ventilation which
is certified by the Inspector-cum-Facilitator of Factories as adequate, having
regard to all the circumstances of the case;
(h) Fettling of biscuit ware which has been fired empowered flint or quartz except
where this is done in machines so enclosed as to effectually prevent the escape of
dust.
(i) Ware cleaning after the application of glaze by dipping or other process;
(j) Crushing and dry grinding of materials for pottery bodies and saggars, unless
carried on in machines so enclosed as to effectively prevent the escape of dust or
is so damp that no dust can be given off;
(k) Sieving or manipulation of powdered flint, quartz, clay grog or mixture of these
materials, unless it is so damp that no dust can be given off;
(l) Grinding of tiles on a power-driven wheel, unless an efficient water spray is used
on the wheel;

<!-- page 79 -->

भाग‍4(ग) ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍
थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍‍‍‍

‍‍

‍521

(m) Lifting and conveying of materials by elevators and conveyors unless they are
effectively enclosed and so arranged as to prevent escape of dust into the air in or
near any place at which persons are employed;
(n) The preparation or weighing out of flow material, lawning or dry colours,
colouring, dusting and colour blowing;
(o) Mould making, unless the bins or similar receptacles used for holding plaster of
Paris are provided with suitable covers; and
(p) The manipulation of calcined material, unless the material has been made and
remains so wet that no dust is given off.
3. Carrying of processes.- Each of the following processes shall be carried on in such a
manner and under such conditions so as to secure effectual separation from one another and
from other wet processes,(a) Crushing and dry grinding or sieving of materials fettling, pressing of tiles, drying
of clay and green ware. loading and unloading saggars; or
(b) All processes involving the use of dry lead compound.
4. Use of glaze.- No glaze which is not a lead less glaze or a low solubility glaze, shall be
used in a factory on which pottery is manufactured.
5. Potter's Wheel.- The potter's wheel (jolly and jigger shall be provided with screens or so
constructed, as to prevent clay scrapings being thrown off beyond the wheel).
6. Measures to be taken to prevent dust flowing.- (1) All practical measures shall be taken
by damping or otherwise to prevent dust arising during cleaning of floors.
(2) Damp saw dust or other suitable material shall be used to render the moist method
effective in preventing dust rising into the air during the cleaning process which shall be
carried out after work has ceased.
7. Cleaning of floors.- The floors of potter's shops, slip houses, dipping, houses and ware
cleaning rooms shall be hard, smooth and impervious and shall be thoroughly cleaned daily
by a moist method.
8. Medical examination by the Medical Officer- (1) Every worker employed in any
process mentioned under clause 3, shall be examined by a Medical Officer within 15 days of
his first employment. Such examination shall include tests for lead in urine and blood, ALA
in urine, haemoglobin content stippling of cells and pulmonary functions tests and chest Xrays for workers engaged in processes mentioned in clauses (i) and (xiv) of clause 2 and
pulmonary function tests and chest X-rays for the others. No worker shall be allowed to work
after 15 days of his first employment in the factory unless certified fit for such employment
by the Medical Officer.
9. Protective equipment.- (1) The occupier shall provide and maintain suitable overalls and
head coverings for all persons employed in the processes mentioned in clause (2).
(2) The occupier shall provide and maintain suitable aprons of water proof of similar material
which can be sponged daily for the use of the dippers, dippers' assistants, throwers, jolly
workers, casters, mould makers and filter press and pug mill workers.

<!-- page 80 -->

522 ‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍‍राजस्‍थान‍राज-पत्र,‍जून‍30,‍2026‍‍‍‍‍
‍‍‍‍‍ ‍भाग‍4(ग)
(3) Aprons provided in pursuance of sub-clause (2). shall be thoroughly cleaned daily by the
wearer by sponging or other wet process. All overalls and head coverings shall be washed,
cleaned and mended at least once a week and this washing, cleaning or mending shall be
provided by the occupier.
(4) No person shall be allowed to work in emptying sacks of dusty materials, weighing out
and mixing of dusty materials and charging of ball mills and blunger's without wearing a
suitable and efficient dust respirator.
10. Application.- The provisions contained in this Schedule shall not apply to a factory in
which any of the following articles, but no other pottery is made: (a) unglazed or salt glazed bricks and tiles: and
(b) architectural terra-cotta made from plastic clay and either unglazed or glazed with
a lead less glaze only.
11. Exemptions.- If in respect of any factory, the Chief Inspector-cum-Facilitator is satisfied
that all or any of the provisions of this Schedule are not necessary for, the protection of the
persons employed in such factory, he may by a certificate in writing, exempt such factory,
from all or any of such provisions, subject to such conditions, as he may specify therein. Such
facilities may at any time be revoked by the Chief Inspector-cum-Facilitator without
assigning any reasons.
Schedule XII
Printing Presses and type foundries-certain lead processes carried therein
1. Exemptions.- Where the Chief Inspector-cum-Facilitator is satisfied that all or any of the
provisions of this schedule are not necessary for the protection of persons employed, he may
by certificate in writing exempt any factory from all or any of such provisions subject to such
conditions as he may specify therein. Such certificate may at any time be revoked by the
Chief Inspector-cum-Facilitator.
2. Definitions.- For the purposes of this Schedule,(1) "Lead material" means material containing not less than five percent of lead.
(2) "Lead process" means(a) the melting of lead or any lead material for casting and mechanical composing:
(b) the re-charging of machines with used lead material;
(c) any other work including removal of dress from melting pots, cleaning of
plungers, and
(d) manipulation, movement or other treatment of lead material.
(3) "Efficient exhaust draught" means localised ventilation effected by heat or mechanical
means, for the removal of gas, vapour, dust or fumes so as to prevent them escaping into the
air of any place in which work is carried on. No draught shall be deemed efficient which fails
to remove gas, vapour, fume or dust at the point where they originate.
3. Exhaust draught.- None of the following processes shall be carried on except with an
efficient exhaust draught,(a) melting lead material or slugs; and
(b) heating lead material so that vapour containing lead is given off;
