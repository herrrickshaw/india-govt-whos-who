---
doc_id: "eb4ced9414b1fac4"
source_url: "https://cdn.jagannathuniversity.org/docs/student-zone/Wellbeing-Wellness-Committee-Office-Order.pdf"
ministry: "Jagannath University, Rajasthan"
title: "Office Order"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "9133515d48138303"
---

<!-- page 1 -->

a ।
a | Jagannath |
७ | University
Ref. No : JU/Regr./2025-26/ 95 (iii) July 2I, 2025
OFFICE - ORDER
In continuation to the office order No. JNU/Regr./2023-24/6820(i) dated 9"" July, 2023, the
Well-Being / Wellness Committee is hereby re-constituted with immediate effect for a period
of 2 years as follows :
l. Prof.(Dr.) Manju Gupta, Professor Convener
2. Prof.(Dr.) Ranjeeta Soni, Professor Nodal Officer
3. Dr. Ankush Sharma, Professor Counselor
@ 4. Dr. Pankhuri Saxena, Associate Professor Counselor
5. Dr. Kavita Sharma, Assistant Professor Counselor
6. Mr. Nikhil, Assistant Professor Counselor
7. Mr. Kartikeya, Assistant Professor Counselor
Objectives of the Well-Being / Wellness Committee are as follows:
a) To ensure equitable access to quality mental health services to all the students.
b) To promote physical fitness and sports activities for students.
०) To create safeguards against academic pressure, peer pressure, behavioral issues,
stress, career concerns, depression and other issues on the mental health of students.
d) To teach positive thinking and emotions in the student community.
e) To promote a positive and supportive network for students.
¢€ Sd/-
President
Ref, No : JU/Regr./2025-26/ 9.5U! Gti) July 2), 2025
Copy for information and necessary action to:
. P.S. to the Chairperson
2. PS. to the President
4, Director, IQAC
5. The Registrar a a
6. Person Concerned ॥ । i
irculation through e-mail
7, All Staff Members by ci (Ss. pcistrar
: NH-42, Chaksu Bypass, Tonk Road, Jaipur-30390! (Rajasthan)
Chaksu Campus : NH-4 al हो ye volagannathuniversiy.oa Website : wow jagannathuniversity.ora
Ph, : 04-3020500, 3020555, Fax : 04 44-3020538 Email : info@jagannathuniversity. ee
sitapura Campus : IP-283, Phase-IV, Sitapura Ind. Area, Jaipur-302022 Ph.:044%-40755%~
Scanned with CamScanner
