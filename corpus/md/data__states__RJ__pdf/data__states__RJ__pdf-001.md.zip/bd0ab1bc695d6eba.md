---
doc_id: "bd0ab1bc695d6eba"
source_url: "https://petroleum.rajasthan.gov.in/writereaddata/Images/actrulesreg.pdf"
ministry: "Directorate of Petroleum, Rajasthan"
title: "Act, Rules & Regulations"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9b335843bb9caa3f"
---

<!-- page 1 -->

Exploration & Production

Act, Rules & Regulations
Although mineral Petroleum lies in the State vested land, but the subject of regulation of mines &
mineral development covered by entry 54 of the Union List under seventh schedule of the
Constitution of India. By virtue of this Central Government through the Parliament has exclusive
power to make laws with respect to regulation of mines and oil fields and mineral development.
Hence, mineral right is vested with Central Govt. For its exploration, production and marketing.


The Oil Fields (Regulation & Development Act, 1948) (53 of 1948) (hereinafter referred as “the
Act”) and the Petroleum and Natural Gas Rules, 1959, made there under (hereinafter referred to as
“the Rules)”make provision inter-alia for the regulation of Petroleum Operation and the grant of
licenses and lease for exploration and development of Petroleum in India.



Refining sector comes under the Essential Commodity Act, 1955(10 of 1955) of Government of
India. As per the resolution of the Government of India dated 21st November 1997 companies owing
and operating refineries with an investment of at least Rs. 2000 Crore or Oil exploration and
production companies producing at least 3 Million Ton of crude oil annually, are entitled for
marketing rights for transportation fuels.



Following rules & regulations are applicable: Oil Field(Regulation & Development) Act, 1948 (Act no 53 of 1948)
 Petroleum & Natural Gas Rules, 1959 (As amended from time to time)
 Land Acquisition Act, 1894
 Essential Commodities Act, 1955
 The Petroleum and Mineral Pipelines (Acquisition of Right to user Inland) Act, 1962 (Act no, 50
of 1962)
 Labour Laws
 The Companies Act, 1956
 Petroleum Tax Guide, 1999 for Upstream Sector: This compiles the specific provisions of the
laws relating to Income Tax, Custom Duty, Central Excise, Cess, Royalties & License/Lease fees
as applicable to activities connected with the prospecting for or extraction or production of
petroleum in the upstream sector. The fiscal provisions are those in force under the enactments &
rules mentioned below:
 The Territorial Waters, Continental Shelf, Exclusive Economic Zones & other Maritime Zones
Act (Act no 80 of 1976)

<!-- page 2 -->

 The Income Tax Act (Act no 43 of 1961)
 The Income Tax 1962)
 The Central Excise Act, 1944 (Act no 01 of 1944)
 The Central Excise Tariff Act, 1985 (Act no 05 of 1986)
 The Oil Industry (Development) Act, 1974 (Act no 47 of 1974)
 The Customs Act, 1962 (Act no 52 of 1962)
 The Customs Tariff Act, 1975 (Act no 51 of 1975)
 The Oil Fields (Regulation & Development) Act, 1948 (Act no 53 of 1948);
 The Petroleum & Natural Gas, 1959
 Regulatory Board Bill, 2005 for Distribution Sector: Recently, the Parliament has enacted
Petroleum & Natural Gas Regulatory Board Bill, 2005 which provides for establishment of a
regulator for refining, processing, storage, transportation, distribution, marketing and sale of
Petroleum, petroleum products and natural gas (excluding production of crude oil & natural gas).
 The Petroleum & Natural Gas Regulatory Board Act, 2006
 The said act received assent of president on India. Section 15 of the said Act provides that any
entity desirous of (a) marketing any notified petroleum or petroleum products or natural gas or (b)
establishing or operating a liquefied natural gas terminal: or (c)establishing storage facilities for
petroleum, petroleum products or natural gas exceeding such capacity as may be specified by
regulations is required to make an application to the petroleum & natural gas regulator for
registration under the Act,
 Section 16 of the said act provides that no entity shall (a) Lay, build, carrier (b) lay, build, operate
or expand any city or local natural gas distribution network, without obtaining authorization
under this act.
