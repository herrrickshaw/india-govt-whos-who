---
doc_id: "a2c67afeb9fc630a"
source_url: "http://rmsc.health.rajasthan.gov.in/content/dam/doitassets/Medical-and-Health-Portal/rajasthan-medical-corporation/pdf/EQUIPMENT_TENDERS/NIB_144_28_01_2016.pdf"
ministry: "Rajasthan Medical Services Corporation Limited, Rajasthan"
title: "NIB_144_28_01_2016.pdf"
date: ""
pages: 92
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "f4a4189e0eb0da0b"
---

<!-- page 1 -->

| Rajasthan Medical Services Corporation Limited, Jaipur
| D-Block, Swasthya Bhawan, C-Scheme, Jaipur - 302005 (<>
हब न गण राणा 024-2228065 E-Mail -edepmemse-ri@nicin
No. F-8( ) RMSC/EPM/M-3/5-I6/NIB-I44/ <2 22 Dated: 24 ]7 |
: BIDDING DOCUMENT
cP BEING Y
| RES
leet सच्तु निशमया:॥॥
NIB NO. 44
(YEAR 205-6)
. DATED &7-!-/6
॥ THE RATE CONTRACT FOR
! EQUIPMENT GEYSER (50 Ltr.)

<!-- page 2 -->

| BIDDING DOCUMENT FOR RATE CONTRACT हे
i [Procurement of Goods: Single Stage“Two Envelopes (Two Part) Bid]
Table of Contents
: — ee -
| S.No. | Section Description :
NIL] Bid Submission Letter
2. NIL | Abridged form of NIB for publication in the
newspapers :

3, NIL | Notice Inviting Bid (NIB) for uploading on
| websites. |

I Instructions to Bidders (ITB) | | ;
। वर FY Bia Data Sheet DS) | '
' 6. | गए. | Evaluation and Qualification Criteria P|
| 8. Schedule of Supply
' | | General Conditions of Rate Contract (GCC)
i 0. | VIB |Special Conditions of Rate Contract (SCC) |
| ti. | शेट | Contract Forms (CF) |
|
I
4 2

<!-- page 3 -->

, :
i (To be submitted on letter head of the Firm/Company)
BID SUBMISSION LETTER
(Declaration Form cum Check List)
: To, :
EI Managing Director, :
+ Rajasthan Medical Services Corporation Ltd.,
i D-Block, Swasthya Bhawan, C-Scheme, Jaipur
Rajasthan
Subject:- Regarding Bid submission for NIB-44
॥छ&...................०००००.. (Name, Designation and Address of Bidet). having our office
ऑऑ.......० हनन लनिनान__+ (Addr695 Of FITM) cesses GO declare that I/We have read carefully all
the terms & conditions of the bid document for the Rate Contract Cum Supply of..........(Name of :
Instruments/ equipments)... and agree to abide by all the Terms & Conditions set forth therein.
: U/We declare that we are participating in this bid in the capacity of .............(Manufacturer /Direct
Amporter).......0-. We enclose valid Manufacturing license/acknowledgement/Memorandum/JEM/ |
Registration of SSI Unit/Import license/IEC Code along with authorization by Foreign Principal (as
the case may be).
I/We further declare that the rates offered by us shall remain valid for the entire period of the rate i
contract and shall reduce the rates, if the rates are reduced by us for any other buyer during this period. |
I/We enclose the requisite documents as per details given below:- \
s. है Ttem Particular
No ee
|. | Bid security GCC 2.6 @) and 3 (i) (Through Challan/DD)-(BF :
Technical Bid Submission Sheet (BF-0) Page no ..... |
3. Acknowledgement of EM-II for SSI Units of Rajasthan from Industries | Page no ..... i
. Deptt. Con. No. 2.6(ii) & GCC 300) (BE-X) |
: 4. | Self attested Photocopy of Acknowledgement of EM-II SST unit for cach’| Page no ..... .
quoted Product and a certificate from NSIC/MSME/Industries Deptt. for the :
i production capacity & the quality control measures properly installed at the
| roduction unit, GCC 2.6 (ii) (BF X) _ . _
| 5. Self attested Photocopy of IEC Certificate and Permission/Authorisation for | Page no ..... |
i sale from the foreign principal manufacturer (Authorization Letter of |
Principal Company GCC 2.6 (iv) i
ee re i
|] (| Copy Of Central Excise Registration GCC 2.6 (iii), if applicable. Page n0 ..... |
i 7, | Format of the Affidavit on non judicial stamp paper of Rs. [7 (GCC 2.6 | Page no... |
ई Gi) (छाए 5) |
it te ———_——- !
8. BIS License with schedule for IST Marked Products Quoted GCC 2.6 (vi) Page no ..... |
| Self attested photocopy of ISO & CH/BIS/USEDA certificate for quoted | Page no... है a |
| Items as mentioned in bid GCC 2.6 (vii) |
! i0, | Average Annual turnover statement for past 3 financial years certified by | Page no ..... हु i
i C.A. GCC 2.6 (viii) (BE-VI हि _ ce |
: Il. | Latest Sales Tax Clearance Certificate/Affidavit (up to dated 3,03.205). | Page no..... H
(0002. 6 ७: ee _ |
i
}
i
|
हैं !

<!-- page 4 -->

4
i
| Specify point of supply with full Address. GCC 2.6 (xi) Full Address.
{3. | Statement of Installed Manufacturing Capacity, Certificate regarding quoted | Page no .....
model is latest technology, Certificate regarding rate reasonability, |
Undertaking for availability of Spare Parts & Consumables, Undertaking for
: acceptance of Comprehensive Guarantee, Undertaking of Non- Debarring E
q GCC 2.6 (xii) (BF-¥) (on NJ stamp paper of Rs. 200/-) i
| ‘Statement of Plant & Machinery etc. [छाशा) GCC 2.6 (xiv) Page no ..... i
i5, | Original bid GCC & SCC (Section VI A & VIB) or BF-IV uploaded on e- | Page no ..... :
procurement portal.
I6. | Statement of Past Supplies and Performance under इटेंट (BE-VII)
| Rate contract completion report, 0225 (BF-XT) है
]
! CMC on Rs. 00-/ Non Judiciat Stamp (BF-XIH) |
20. | CMC/Rates in BOQ (BF-IV) are electronically uploaded on website Don't write rates in format :
https://eproc.rajasthan.gov.in.
: Declaration regarding acceptance of bid terms and conditions. (BF-XTV) Page 0 ..... i
|
22, | Memorandum of Appeal Under the Rajasthan Transparency in Public | Page no..... !
Procurement Act, 20।2 (BF-X¥) _ |
23. | Declaration by the Bidder Regarding Qualifications (BF-XVD) Page no .....
Uploaded on website https://eproc.rajasthan.gov.in. :
: 24, | Declaration of Manufacturer/Direct Importer (BF-XVII) Page no .....
25, | Authorisation from foreign principal manufacturer (BF-XVIID. Page no .....
___| (Applicable in case of direct importer only)
26, | Authorisation of the Bidder by the Firm (हाफ)
: Corrigendum/modification/clatification uploaded with bid document Page n0 .....
Financial Bid Submission Sheet (BE-IID) to be submitted physically. Page now...
i 29. | Name, photograph & specimen. signature of the Bidder or designated officer! | Namie ......sssssssececsessssnsseeeees
i person who is authorized by the Firm to bid and make correspondence with
है the RMSCL. 460 attach photo ID, Signatre...ccssenssesesscesenssetene
i
i
: Beall address ; sssecessnssenssenceesnee
i
| Date Name and Signature of Bidder with seal
Note: Please mention page number and sign before submitting the bid.
: 4

<!-- page 5 -->

‘ ; |
+ 2 * के डे थे Stee ills ae )
: Rajasthan Medical Services Corporation Limited, Jaipur re
/ D-Block, Swasthya Bhawan, C-Scheme, Jaipur - 302005 xy i
Ph. No, 044-2223887, Fax No. 0444-2228065 E-Mail -edepmrmse-ri@nic.in
‘ No, F-8( ) RMSC/EPM/M.-3/!5-6/NIB-444/ 32 g Dated: 29 J~/~ /6
: NOTICE INVITING BID (NIB-i44)
: Bids are invited by .00 P.M. on dated 9.3.20I6 for procurement of equipments GEYSER (50 Ltr.) :
on rate contract basis for |8 Months. The details are available in the Bidding Document which can be
availed from the office of the M.D, RMSCL or can be accessed or downloaded from State Public
; Procurement Portal website "sppp.raj.nic.in" or "www.dipronline.Org" or
| “https://eproc.rajasthan.gov.in" or website "www.rmsc.nic.in". The bidding document, after filling
up properly, can be uploaded on website "https://eproc.rajasthan.gov.in" along with payment of Bid i
form fee of Rs. 2000/- (Rs. 000.00 for SSI Unit of Rajasthan) through challan /banker’s cheque/demand :
draft in favour of MD., RMSCL, payable at Jaipur.
|
Managing Director
Rajasthan Medical Services Corporation
Rajasthan, Jaipur.
} i
|] |
|
i i
i |
; |
|
|
|

<!-- page 6 -->

' Rajasthan Medical Services Corporation Limited, Jaipur ;
: D-Block, Swasthya Bhawan, C-Scheme, Jaipur - 302005 (es) है
! Ph. No. 04-2223887, Fax No. 04I-2228065 E-Mail -edepmrmse-ri@nic.in —- ie
| No. F-8¢ ) RMSC/EPM/M-3/5-6/NIB-44/ 32 a Dated: QJ-)-/) 6 :
t :
i NOTICE INVITING BID (NIB-344) 4
j l, Single stage, two-envelopes bids for a rate contract are invited from manufacturers/direct i
i importers for the procurement of equipment & instruments as listed below : :
: S. | Name of article Specifications Quantity | Amount | Validity Place of j
No. (with reference to BIS and of period of | delivery :
code, patent, ISO, required Bid bids and मु
i Agmark, part No. etc.) | minimum | security delivery
; turnover | (Rupees period :
] As per table-L As per Clause - 3 of Asper | As per bid | As per bid | As per bid :
Section V, schedule of ।20 condition | condition | condition
supply or as per |
table-I !
2. Detailed particulars of the list of equipment required, specifications of items/equipments & bid |
: documents are available on the website-"www.dipronline.org” or www.rmscnic.in or |
| https://eproc.rajasthan.gov.in or sppp.raj.nic.in or may be seen in the office of the E.D. (EPM),
| RMSCL, D-Block, Swasthya Bhawan, C-scheme, Jaipur.
: 3. E-Bids are invited as per following schedule:-
a= of bid forms Date of Last date & time | Last date & time | Date & time of
from date and time pre-bid for sale of bid of receipt of bid opening of
as under meeting form form. technica! bid
i to 3 4 5
i 4i:00 AM 3:09 PM 4:00 AM 4:00 PM 3:00 PM
| 28..20I6 9.2.206 9,3.2026 9,3,206 9.3.2046
|
: 4. A pre-bid meeting will be held as per above schedule i.e., on dated 9.2.206 at 3:00 PM in the
Conference Hall of Rajasthan Medical Services Corporation, D-Block, Swasthya bhawan, Jaipur,
| to clarify and answer the queries on any other matter related to this bid. After pre-bid meeting,
i necessary changes in bid conditions/ catalogue, if considered appropriate, will be made.
i 5. If any amendment/clarification is carried out in the technical specifications and bid terms &
i conditions following pre-bid meeting or any other information, the same will also be uploaded on
i the Corporation website www.mmse-nic.in, sppp.taj.nic.in and https://eproc.rajasthan.gov.in and
: will not be published in any news papers. It will not be intimated to individual bidder. In case, any
i inconvenience is felt, please contact over telephone number i.e. 04-2223887 or queries may be
+ e-mailed on "edepmrmse-sj@nic.in".
i 6. The bid should be submitted through e-portal, after pre-bid meeting, including all the
i clarifications/modifications/amendments agreed & issued by the corporation. The bid shall only be
submitted through e-procurement portal https://eproc.rajasthan.gov.in. of Govt. of Rajasthan.
| Bids shall not be accepted in physical form in any condition.

<!-- page 7 -->

k
! 7. Bids received after the specified time and date shall not be accepted/opened.
! 8. The corrigendum/addendum issued by the corporation shall be the integral part of terms &
conditions of the bid and should be duly signed and attached with the bid document by the bidder.
i 9, Price preference and / or purchase preference as per extant rules and guidelines in this regard shall i
i be considered in evaluation of the bid and award of contract. !
0. The Bid form fee Rs, 2000.00 (Rs. 000.00 for SSI Units of Rajasthan) downloaded from the :
: website, Bid Security as applicable in bid condition or mentioned in table-l and R.LS.L.
processing fee of Rs.l000.00 shall be deposited through three separate prescribed challans
(formats enclosed in BF-l) in any branch of the Punjab National Bank Account no.
22460020002444 anywhere in the country/or through D.D./B.C. The bidder shall submit/upload
scanned copy of all the challans in Technical Bid (Cover-A),or The Bid form fee Rs. 2000.00
{Rs. l000.00 for SSI Units of Rajasthan) downloaded from the website shall be submitted in the
form of D.D./Banker cheque in favour of M.D., RMSCL payable at Jaipur. The bidders are also |
| required to deposit R.IS.L. processing fee of Rs. 000,00 in the form of D.D./Banker cheque in
: favour of M.D., RISL payable at Jaipur. The bid document fee, R.LS.L. processing fee and bid
security shall be deposited physically along with technical bid submissions sheet in the office of
M.D., RMSCL, and Jaipur before the last date and time of bid submission.
: lI. The technical bids shall be opened at 3:00 PM on dated 9.3.20i6 or as amended in the presence of
the bidders or their representatives, who wish to be present. :
2. The RMSCL is not bound to accept the lowest bid and may reject any or all bids without assigning ;
है any reason thereof, i
3. The bidders shall have to submit a valid 'VAT' clearance certificate/affidavit from the concerned :
: Commercial Taxes Officer and the ‘PAN’ issued by Income Tax Department.
: /4. It is clarified that the information required in bidding document should be submitted only in '
enclosed format Bidding Form (BF-I to BF-XX) without any change or modification in its formats. :
Bids submitted with changed or modified annexure/ formats may be rejected. |
I5. Information of award of contract shall be communicated to all participating bidders on the website i
i www.rmsc.nic.in and sppp.raj.nic.in, Please note that individual bidder will not be intimated, :
i ॥
| 6. The bidding process shall be subject to the provisions of the Rajasthan Transparency in Public I
Procurement Act and Rules made there under. !
i Managing Director :
Rajasthan Medical Services Corporation |
: Rajasthan, Jaipur. |
I
|
॒ i
F I
; |
|
}

<!-- page 8 -->

ः a f
Rajasthan Medical Services Corporation Limited, Jaipur Ee i
| D-Block, Swasthya Bhawan, C-Scheme, Jaipur - 302005 (=) ः
| Ph. No, 04-2223887, Fax No, 04-2228065 E-Mail-edepmrmsei@nicin Stes :
| No. 7-8९ ) RMSC/EPM/M-3/I5-6/NIB-44/ 32 g Dated: 22 )-)-/ 6 :
i पु
पु5छा ॥-] L
|
]क्‍ List of Equipment & Instruments (NIB No. 44)
: Minimum Minimum Bid Security (B.S) है
average average gross (Rs.)
gross annual turnover
Equi icati annual for last three
ड़. Name of Equipment & Indicative turnover | finaneial years
N. Instruments Quantity | for last (in Rs.)
(inno) three | for (SSI Units
financial | of Rajasthan)
year’s (In
Rs. पु
Geyser (50 Lir.) 5 50.00 25.00 Lakh | 09) Rs. 24,000.00 |
i Lakh (ii) For SSI Units of
जज Rajasthan Rs. 6000.,00
Note:- है !
. The above estimated quantities are only indicative and may vary substantially the above
| estimated quantities are only indicative for executing rate contract for a specified period. If i
: the procuring entity does not procure any subject matter of procurement or procures less :
than the quantity indicated in the bidding documents the bidder shall not be entitled for any :
claim or compensation. No minimum quantity is guaranteed. Quantity/Capacity
commitment of the firm in BF-V and clause-2.6 (xii) shall be considered for placement of :
supply orders. |
2. Firms which are registered as micro or SSI Unit of Rajasthan with Commissioner of |
प्र Jndustries shall furnish the amount of bid security at the rate 0.50% of likely value of the
: indicative quantity or Rs.6000/- (Rs. Six Thousand), whichever is less, for whole bid
catalogue/each item (as per above Table-l). In respect of items for which they are
| registered to manufacture, shall submit an attested copy of acknowledgment of EM-II
! issued by DIC, with an affidavit on non-judicial stamp paper worth Rs. 0/- as per BF-X.
i)
:
|
i
i

<!-- page 9 -->

4 |
bo -
। DISCLAIMER /
है The information contained in this bid document for proposed procurement or subsequently
Q provided to the Bidder(s), in documentary or any other form by or on behalf of the MD, RMSCL :
i (Procuring Entity) or any of its employees or advisors, is provided to Bidder(s) on the terms and ;
| conditions set out in this bid and such other terms and conditions subject to which such information is 5
i provided to the Bidder. :
| Whilst the information in this bid has been prepared in good faith and contains general .
; information in respect of the proposed procurement, the bid is not and does not purport to contain all
the information which the Bidder may require.
Neither the MD RMSCL, nor any of its officers or employees, nor any of their advisers nor
. consultants accept any liability or responsibility for the accuracy, reasonableness or completeness of,
or for any errors, omissions or misstatements, negligent or otherwise, relating to the proposed
procurement, or makes any representation or warranty, express or implied, with respect to the
information contained in this bid or on which this bid is based or with respect to any written or oral
\ information made or to be made available to any of the recipients or their professional advisers and
liability therefore is hereby expressly disclaimed.
This document is not an agreement and is not an offer or invitation by the Managing Director,
Rajasthan Medical Services Corporation Limited., Jaipur, Rajasthan. (hereinafter referred to as
“Procuring Entity”) or its representatives to the prospective Bidders or any other person, The purpose '
i of this bid document is to provide interested parties with information to assist the formulation of their i
Proposal/offer. The information contained in this bid document is selective and is subject to updating, :
expansion, revision, and amendment. Each recipient must conduct its own analysis of the information. :
contained in this bid document or to connect any inaccuracies therein that may be in this bid document |
and is advised to carry out its own investigation into the proposed procurement, the legislative and :
regulatory regime which applies thereto and by and all matters pertinent to the proposed. procurement :
| and to seek its own professional advice on the legal, financial, regulatory and taxation consequences of |
ः entering into any agreement or arrangement relating to the proposed procurement. /
i This bid document includes certain statements, estimates and targets with respect to the |
; procurement. Such statements, estimates and targets reflect various assumptions made by the '
: management, officers, and employees of the procuring entity, (and the base information on which they i
are made) which may or may not prove to be correct. No representation or warranty is given as to the t
i reasonableness of forecasts or the assumptions on which they may be based and nothing in this bid |
i document is, or should be relied on as, a promise, representation, or warranty. Bid document and the :
: information contained therein is meant only for those applying for this procurement, it may not be |
। copied or distributed by the recipient to third parties, or used as information source by the Bidder or
any other in any context, other than applying for this proposed procurement. ;
The Procuring Entity is, its employees and advisors make no representation or warranty and |
: shall have no liability to any person, including any Bidder under any law, statute, rules or regulations {
or tort, principles of restitution or unjust enrichment or otherwise for any loss, damages, cost or :
J expense which may arise from or be incurred or suffered on account of anything contained in this bid |
ः document or otherwise, including the accuracy, adequacy, correctness, completeness or reliability of
: :
i
;

<!-- page 10 -->

55 i
' the bid document and any assessment, assumption, statement or information contained therein or
: deemed to form part of this bid document or arising in any way for participation in this Bidding ;
process. हि
The Procuring Entity also accepts no liability of any nature whether resulting from negligence i
or otherwise howsoever caused arising from reliance of any Bidder upon the statements contained in धर
r this bid document. न
i The Procuring Entity may in its absolute discretion, but without being under any obligation to
do so, update, amend or supplement the information, assessment or assumptions contained in this bid
document.
The issue of this bid document does not imply that the Procuring Entity is bound to select a
bidder or to appoint the Selected Bidder or Bidder, as the case may be, for the procurement and the
Procuring Entity reserves the right to reject all or any of the Bidders or Bids at any point of time
4 without assigning any reason whatsoever. ः
: The Bidder shall bear all its costs associated with or relating to the preparation and submission
i of its Bid including but not limited to preparation, copying, postage, delivery fees, expenses associated i
with any demonstrations or presentations which may be required by the Procuring Entity or any other ह
costs incurred in connection with or relating to its Bid. All such costs and expenses will remain with
the Bidder and the Procuring Entity shall not be liable in any manner whatsoever for the same or for
any other costs or other expenses incurred by a Bidder in preparation or submission of the Bid,
: regardless of the conduct or outcome of the Bidding process. !
Any information/documents including information/ documents pertaining to this bid or
subsequently provided to Bidder and/or Selected Bidder AND information/documents relating to the
Bidding process; the disclosure of which is prejudicial and/or detrimental to, or endangers, the
implementation of the procurement is not subject to disclosure as public information/documents.
4 ln r,
Rajasthan Medical Services Corporation Limited.,
i D-Block Swasthya Bhavan,, C-Scheme, Jaipur.
i
|
| l0
