---
doc_id: "0f9ceb0d0b3ed5a7"
source_url: "https://risl.rajasthan.gov.in/uploads/orders/93104cac-6dba-4926-9106-ec87f3078565.pdf"
ministry: "RajCOMP Info Services Limited, Rajasthan"
title: "Notice for Empanelment of Advocates."
date: ""
pages: 5
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "6a5a414a208913f9"
---

<!-- page 1 -->

=
CN अआाणएछछचचा॑ााणणाछण॑ाौाणणा
; RajCOMIP Info Services Ltd. दि
we (A Government of Rajasthan undertaking) website: www.risl.rajasthan,gov.in
2 NS CIN : U72200RJ20208GC03385,
F ,9(478)/RISL/Mise/2026- 6|O4- Date: 29-0/~262G
Notice for Empanelment of Advocates
RajCOMP Info Services Limited (RISL) invites applications from cligible
Advocates / Law Firms for empanclment to represent the Company before
various courts, tribunals, and other judicial / quasi-judicial forums.
I. Nature of Legal Work and Scope of Em panelment
‘The legal matters of RISL broadly include, but are not limited to:
+ Litigation before the Hon’ble Rajasthan | ligh Court (Principal Scat and
Bench at Jaipur). which constitutes the majority of cases
+ Public Interest Litigations (PIs) related to governance, policy, I
, systems, and public service delivery
+ ‘Tender-related and contractual commercial disputes including challenges
to RFPs, bids, technical evaluations, and work orders
» Arbitration matters. including proceed ings under the Arbitration and
Conciliation Act. 996
* Service matters. including disciplinary proceedings, service benefits.
appointments, and employment-related disputes
«Labour Court and Industrial Tribunal matters
+ Income Tax matters before appellate authorities and tribunals
+ GST matters before appellate authorities, tribunals. and courts
+ Matters before the Hon*ble Supreme Court of India
* Representation before other courts, tribunals, statutory authorities,
commissions, and quasi-judicial forums
Empancelled advocate may also be required to draft pleadings, affidavits, replies,
rejoinders, written submissions, applications, legal notices, and render legal
opinions and advisory services.
2. Eligibility Criteria
Applicants should fulfill the following conditions
+ Must be enrolled with the Bar Council of India / concerned State Bar
Council
(| © Block, Ist Floor, Yojana Bhawan Tilak Marg, C Scheme, Jaipur-302005 wm Tel. 444-5703902, 2226304. 2720087 Fax: 444
| 2228704

<!-- page 2 -->

=
" RajCOMP Info Services Ltd. GRR REREI Ten cena
42% (A Government of Rajasthan undertaking) website: www.rislrajasthan.gov.in
res CIN : U72200RJ2030SGC03385
NISI
+ For District & Subordinate Courts, ‘lribunals, Labour Courts, and other
authoritics:
> Applications shall be considered purely on merit, professional
competence, and suitability
« Vor High Court matters:
e Minimum 5 years” standing at the Bar as on the cut-off date
¢ For Supreme Court matters:
Minimum 0 years” standing at the Bar as on the cut-off date
+ Must not have been blacklisted, debarred, or declared incligible by any
Government Department, PSU, Autonomous Body, or statutory authority
+ Must not have any conflict of interest with राह,
3. Documents to be Submitted
I. Duly filled Application Form (Annexure-A)
2. Detailed Bio-data / Professional Profile
3. Sclf-attested copy of Bar Council Enrolment Certificate
4. Statement of professional experience, including important cases handled
5. Self-declaration regarding non-blacklisting and absence of conflict of
: interest
4. Terms & Conditions of Empanelment
+ Empanelment shall be valid for 3 (three) years, unless terminated carlicr
+ Fees shall be payable as per Government of Rajasthan / RISI. norms.
+ Empanelment does not confer any vested or exclusive right to claim work
from RISL
+ Allocation of cases shall be at the discretion of RISL.. based on nature,
urgency, and suitability
+ Notwithstanding cmpanelment, RISL may engage any advocate(s),
including those not cmpanelled, for any specific matter, depending on the
nature, gravity, urgency, or importance of the case. Further, Managing
Director may relax the experience requirement among the empanelled
advocates for dealing a category of case.
+ [mpanelled advocates shall maintain strict. con fidentiality of RISL
information and records
+ Any negligence, misconduct, breach of confidential ity, or non-
compliance with instructions shall render the advocate liable for removal
from the panel
U C-Block, Ist Floor, Yojana Bhawan, Tilak Marg, C-Scheme, Jaipur-302005 wm Tel. 4-503902, 2279394, 2220097 Fax: 444
222870

<!-- page 3 -->

=
My, RajCOMP Info Services Ltd. nissan sn
०९ (A Government of Rajasthan undertaking) website: www.rislrajasthan.gov.in
2 CIN : U72200RJ200SGC03385.
RIS]
5. Submission of Application
+ Applications must be submitted within ।5 (fifteen) days from the date of
publication of this Notice
+ By post / courier / email / online mode (as applicable)
Address / Email:
The Director (lechnical)/ GM (Administration)
RajCOMP Info Services Limited,
C-Block, First Floor. Yojana Bhawan, ‘Tilak Marg. C- Scheme, Jaipur-302004.
Email: |info.risl!@rajasthan.gov.in|
Incomplete or late applications shall not be considered.
6. General Conditions
J. Empanelment is not a guarantee of engagement or minimum work
2. RISL may verify credentials and antecedents of applicants
3. RISL may limit the number of advocates to be empanelled under cach
= category or court
4. Any canvassing or attempt to influence the empanelment process shall
result in disqualification
5, RISL reserves the right to amend, modify, or cancel this notice at any
stage
6. Decisions of RISL regarding empanelment shall be final and binding
7. हा, reserves the right to accept or reject any or all applications without
assigning any reason
8. The date of publication of this Notice on the RISI, website shall be
treated as the date of issuance
For Raj MV P Info Services Limited
(Anil Kutngr Singh)
Director (Technical)
C-Block, Ist Floor, Yojana Bhawan, Tilak Marg, C-Scheme, Jaipur-302005 wi Tel.: 44-5403802, 2229364, 2220097 Fas. +43
2228704

<!-- page 4 -->

a

Pe, RajCOMP Info Services Ltd. mall info.rel@ralasthangovin

(x (A Government of Rajasthan undertaking) website: www.risl.rajasthan.gov.in

2 . CIN : U72200RJ200SGC03385,
Annexure-A

Application Form for Empanelment of Advocates

No Particulars | Details to be Filled by Applicant |

“Hl ॥

॥| Name of Advocate / Law Firm | |

| |

Vather’s / Spouse’s Name (for | |

\individual advocate) | |

2. Date of establishment of firm |

| with constitution | |

(Prio/Partnership/LLP/Pvt Ltd) |

ib Date of Birth (for individual

i)

ladvocate)

4 {Bar Council Enrolment Number | |

(& Date | |

5 Name of Bar Council | |

6 | Total Standing at the Bar (years) | i

| [छा Supreme Court of India |
O Rajasthan High Court

7 ‘Courts / Forums for which (C0 District & Subordinate Courts

empanelment is sought O Tribunals / Labour Courts

| | ‘Tax Authorities / Tribunals i|

|| 0 Arbitrator courts |

i

] (Pender matters /PILs/Commercial |

: : 0 \disputes / Arbitration / Service matters / |

है. |Areas of Experience / Practice ‘ : ST

| Labour laws / Income Tax / GSI

| ( )॥0०४) |

Bricf Details of Important Cases | |

oH | |

|Handled |

! ;

| | |

|

!0 |Whether previously empanelled | |

ees 7 / ५ |

jwith any Government / PSU / | |

/Statutory Body (If'yes. provide | }

|details) | |

| i ]

| | |

C-Block, Ist Floor, Yojana Bhawan, Tilak Marg, C-Schome, Jaipur-302005 m Tel. 444-6403902, 2229394, 2220097 Fax: 444
2228704

<!-- page 5 -->

=| Ne
"ei , RajCOMP Info Services Ltd. Shall nes वि
yes (A Government of Rajasthan undertaking) website: www.risl.rajasthan.gov.in
2 CIN : U72200RJ200SGC03385
NO Particulars | Details to be Filled by Applicant \
I |Office Address ॥ I
। | i
[2 |Contact Number | |
| !
| : |
3. | mail ID | |
| i}
॥ hereby declare that the information
\ furnished above is true and correct to
| ithe best of my knowledge. I further)
4 Declaration declare that I have not been blacklisted]
\| or debarred by any Government)
(Department, PSU, or statutory authority {
and that no conflict of interest exists}
jwith RISL |
- Place: Date:
Signature of Advocate / Authorized. Signatory:
Name:
C-Block, Ist Floor, Yojana Bhawan, Tilak Marg, C-Scheme, Jaipur-302005. m Tel.: 4-503902, 2229394, 2220087 Fax: 444
2228704
