---
doc_id: "b79ffb17bc6e4bab"
source_url: "https://transport.rajasthan.gov.in/content/dam/transport/metro/Business%20with%20Us/Tenders%20Archive/Tender%202019/Nov%202019/10th%20Annual%20General%20Meeting%20Notice_06.11.2019.pdf"
ministry: "Jaipur Metro Rail Corporation Limited (JMRC), Rajasthan"
title: "10 th  Annual General Meeting Notice dated 06.11.2019"
date: ""
pages: 4
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "d8e3206cfa575631"
---

<!-- page 1 -->

Jaipur Metro Rail Corporation Ltd. |
: (A Government of Rajasthan Undertaking) |
Registered Office: Admin Building, Metro Depot, Bhrigu Path, Mansarovar, Jaipur-302024 [8 | a @| ]
CIN: U6022RJ200SGC030630 lee
Tel.: 04-282220; Fax: 044- 28222 —
JAIPUR METRO Website: a aaa ora नम 3000 ॑॑----- email: df@jaipurmetrorail.in
F.2(8)(4)/JMRC/DF/CS/AGM 6फ November, 209
407 Annual General Meeting Notice General Meeting Notice
Notice is hereby given that the tenth annual general meeting of the members of
Jaipur Metro Rail Corporation Limited is scheduled to be held on Thursday, 28”
November, 2049, at 4.00 pm in Chintan Conference Hall, ॥ Floor, Admin Building,
Metro Depot, Bhrigu Path, Mansarovar, Jaipur, to transact the following business:
ORDINARY BUSINESS:
4, To receive, consider and adopt the financial statements of the Company for the
year 208-9 together with the Reports of Directors and Auditors thereon.
2. To confirm and approve the appointment of the Statutory Auditors of the
Company for the financial year 209-20.
SPECIAL BUSINESS:
3. To consider and, if thought fit, to pass, with or without modification, the
; following Resolution as a Special Resolution:
“RESOLVED THAT in accordance with the provisions of section 49, 52 and 6
read with Schedule IV and all other applicable provisions, of the Companies Act,
203 (“Act”), the Companies (Appointment and Qualification of Directors) Rules
2044, [including any statutory modifications (s) or re-enactment thereof, for the
time being in force], and other applicable provisions, Ms. Gayatri 8, Rathore, IAS
who was appointed as Additional Director (Independent) on the Board of the
Company w.e.f. 22 May, 2049 and who holds office up to the date of this
Annual General Meeting, be and is hereby appointed as Independent Director of
the Company for a term of 5 years from the date of initial appointment, i.e, 2207
May, 2029.
|
|

<!-- page 2 -->

RESOLVED FURTHER THAT the Managing Director and the Company Secretary of
the Company, be and are hereby authorized, severally and jointly, to sign and file
and do any and all necessary filing(s), compliances and acts and to take all such
steps as may be necessary, proper and expedient to give effect to this
resolution.”
By order of the Board
For JAIPUR METRO RAIL CORPORATION LTD
Regd. Office
Admin Building, Metro Depot Sern
Bhrigu Path, Mansarovar, Jaipur (MUKESH KUMA\ AL)
Ae November, 20i9 Managing Director
Note:
l. A member entitled to attend and vote at the meeting is entitled to appoint a
proxy to attend and vote instead of himself and the proxy need not be a member.
In case a proxy is appointed, the following form of proxy should be returned to
the Company, duly completed, no later than forty eight hours before the
commencement of the meeting.
2. Explanatory statement pursuant to Section 402 of the Companies Act, 203 is
enclosed herewith.
wert ice ‘ लग का
कह अटल ag emesis 279०8:
Pa G3 peace: et i,
=m x Sapa acyl =) 24३० Cepitel PAO Swasthyald
‘ears seek 208७ Paty Bag JOA Part
Foy Seca eae eee ० ४ ees
7 SA oe ee ae
ees gute on EO
Ome yey ; Saleh
SBIOA PUBLIC ‘Mansarovar Park Mama's Patanth g ft # एन

<!-- page 3 -->

|
|
Jaipur Metro Rail Corporation Ltd. |
(A Government of Rajasthan Undertaking)
(७9 Registered Office: Admin Building, Metro Depot, Bhrigu Path, Mansarovar, dalpur-302025- 7
CIN: U6022RJ20I0SGC030630 | fe) J
Tel,: 042-2822220; Fax: 04- 282227 rere
JAIPUR METRO Website: EE eiburmetroralin; email: df@jaipurmetrorailin email: ea iaurmetroralins emall:df@jaipurmetroraivin
ee
EXPLANATORY STATEMENTS FOR ITEM SOS ATE MENTS FOR ITEM NUMBER 3, PURSUANT TO SEC 02 OF THE 3, PURSUANT TO SEC 02 OF THE
COMPANIES ACT, 203:
Item Number 3:
The UDH, GoR had issued order no. F.0(24)UDH/3/02 Pt.-l dated 22% May, 2029
appointing Ms. Gayatri A. Rathore, IAS, presently the Secretary, Aayurved & Indian
Medicine Department, 608, Jaipur as Independent Director on the Board of JMRC.
Accordingly, Ms. Gayatri A. Rathore, IAS, Additional Director (Independent) was
appointed as such w.e.f. 22™ May, 209 as per the provisions of Section 49, 52
and l6 of the Companies Act, 20l3 read with Schedule IV and all other applicable
provision, of the Companies Act, 203 (“Act”), the Companies (Appointment and
Qualification of Directors) Rules 2024, [including any statutory modifications (s) or
* re-enactment thereof, for the time being in force], and other applicable provisions.
Now, as per the provisions of Section 64() of the Companies Act, 2023, she holds
office as Director only till the date of the forthcoming Annual General Meeting, but is
eligible for appointment as Director of the Company subject to the approval of
shareholders at this Annual General Meeting.
Hence, the agenda for confirming the appointment of Ms. Gayatri A. Rathore, IAS as
Director of the Company and designated as Independent Director of the Company
has been placed at item number 3.
|
|

<!-- page 4 -->

|
Jaipur Metro Rail Corporation Ltd. |
(8 Government of Rajasthan Undertaking)
Registered Office: Admin Building, Metro Depot, Bhrigu Path, Mansarovar, ee aed
CIN: U60224RJ200SGC030630 | se =|
Tel.: 04-282220; Fax: 04- 282222 —
JAIPUR METRO Website: a >> नकल of@jaipurmetrorailin email: ee ie ecovalL ins email: f@jalpurmetrorailin
Form No. MGT I2
PROXY FORM
[Pursuant to section 405/6) of the Companies Act, 203 and rule 2 93) of Companies (Management and
Administration) Rules, 2074]
Name of the member (s) |
Registered Address
Folio No / Client ID no*
*Applicable for investors holding shares in Electronic form.
॥/ we being a/ the member/ members of. shares of Jaipur Metro Rail Corporation
Limited hereby appoint:
3). RUPE अजब आयइ ४१2 7 के Haig आओ ict ८८०८०८००००८००-७-४ का falling him
2). #/०......................०००० HAVING Email id seesseeretesssneesnestieeeseascsreeress OF falling him
3). ४८२८० १0252 PAVING कल कि or ee
and whose signature are appended below as my/ our Proxy to attend vote (for me/ us and on my/
our behalf at the ........... Annual General Meeting/ Extraordinary general meeting of the Company to
be held on ...... day ०0 ................., Jah Soe DEANE ०२ ००७०५०३००००००००२३२० ४ gees
(place) and at any adjournment thereof in respect of such resolutions as are indicated below;
Resolution (s) no and particulars eer ocr Special
tS
>
Signed this day of eee: Affix
z One Rupees
Signature of Shareholders Ravan
Stamp
Signature of Proxy holder(s)
Notes:
4)This form of proxy in order to be effective should be duly completed and deposited at the
Registered Office of the Company, not less than the 48 hours before the commencement of the
meeting.
2)A Proxy need not be a member of the Company.
3)In case of joint holders, the signature of any holder will be sufficient, but name of all the joint
holders should be stated.
4)The submission by a member of this form of proxy will not preclude such member from attending
in person and voting at the meeting.
