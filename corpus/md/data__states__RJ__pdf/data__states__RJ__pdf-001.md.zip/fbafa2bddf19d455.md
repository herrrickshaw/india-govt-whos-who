---
doc_id: "fbafa2bddf19d455"
source_url: "https://transport.rajasthan.gov.in/content/dam/transport/metro/Citizen%20Corner/Public%20Notice/Notification_Revised%20Policy%20for%20Granting%20Short%20Term%20License%20of%20JMRC%27s%20Assets_10411_08.07.2020.pdf"
ministry: "Jaipur Metro Rail Corporation Limited (JMRC), Rajasthan"
title: "Policy for granting short term licence of JMRC's Assets"
date: ""
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cd72d591cff28947"
---

<!-- page 1 -->

<!-- page 2 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS
1.

Introduction :
Jaipur Metro Rail Corporation (JMRC) is an undertaking of Government of Rajasthan.
Jaipur Metro Rail is a world class state of art Metro System. Presently, a route of 9.6
Km is operational between Mansarovar and Chandpole under Phase 1A. This route
consists of 9 Metro Stations, including one underground metro station at
Chandpole. This existing route is being extended from Chandpole to Bari Chauper
with about 2.1 Km underground route under Phase 1B in the walled city of Jaipur.
JMRC intends to give its assets / premises such as the space(s) at Metro Stations
(inside and outside), metro train and space inside its depot at Mansarovar on short
term license basis for the purpose of shooting of films/ documentaries/ TV
commercials/ photography, Exhibitions, Sales & Promotion activities, to organize
group / promotional events and short term advertisements.

2.

Objectives:

2.1

To promote Jaipur Metro as an attractive, accessible and affordable for shooting
/Retail/exhibition/other promotional event/advertisement venue and to create its
brand image as the most preferred transport system.

2.2

To showcase Jaipur as one of the best destinations in terms of modern
infrastructure, heritage connect and demographic canvas in the national and
international market.

2.3

To generate non-fare revenue through short term licensing Jaipur Metro premises/
assets.

2.4

To provide opportunity to exhibitions, event organizers, film or TV commercial
production companies, advertisement agencies, and other commercial entities to
use Jaipur Metro trains & other centrally located metro premises for organizing
various events including film shooting.

3.

Application Process:

3.1

Any reputed production house, event management company, retailer, show
organizer, exhibitioner, film producer & exhibitor, advertiser and branding company
or non-commercial organizations such as educational institutions, NGOs, charitybased organizations, etc., or any interested individual may make a request on the
letter head of the company/organization or on a plain paper, as the case may be, in
the format as per Annexure-A.

3.2

The Application Form should be submitted to Executive Director (Corporate Affairs),
JMRC, in advance, preferably 10 working days prior to the event, for proper scrutiny
and approval.
Any clarification sought with regard to the policy shall also be addressed to
Executive Director (Corporate Affairs), JMRC.

3.3

A synopsis of the event plan, is to be submitted along with the application.
Requirement of temporary electricity connection/Parking, if any, may also be
mentioned in the application. Fulfillment of such requirement of electricity
Page 1 of 15

<!-- page 3 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS
connection/parking shall be decided by JMRC subject to availability and technical
feasibility.
3.4

The application will be registered in the order of their receipt in JMRC along with
application fee and confirmation will be done in the order of registration, i.e., on
first come first serve basis. The order of priority will be maintained in JMRC to
record the time and date of registration of request only for duly filled applications
received with application fee and synopsis.

3.5

The application shall be examined by JMRC and if found suitable, the application
shall be technically approved by JMRC within next 5 working days.

3.6

On technical approval of the application for the event, a Demand Note shall be raised
by JMRC to the applicant organization for deposition of the refundable security
deposit & advance fees in prescribed format.

3.7

All fees including all applicable taxes are to be submitted in the form of Demand
Draft/ Bankers Cheque at least 03 (three) working days (excluding the day of the
event) before the day of the scheduled event failing which the applicant may lose
it’s priority.

3.8

Applicant will also submit an Indemnity Bond in the format at Annexure-‘B’ for
indemnifying JMRC completely against any loss, injury, damage caused to metro
commuters, JMRC’s personnel/ material/ property/ passengers, Police Security
and also to applicant’s own men & property during the period of license and
undertake to bear all costs incurred as a result of such incident.

3.9

On deposition of required Security amount/ license fees and submission of
Indemnity Bond, a Notice to Proceed (NTP) shall be issued by JMRC to permit the
applicant to organize the event indicating the duration with date & schedule, and
other guidelines.

3.10

In case of a temporary electric connection is required, the same will be applied
immediately after issuance of the NTP along with required amount and at least two
working days in advance to ED (Traction/E&M), O&S Directorate, JMRC in the
format at Annexure-C. The temporary electricity connection shall be issued if found
feasible by JMRC. The Applicant will follow all the terms & conditions of electricity
provisioning as prescribed in Annexure-D.

3.11

The event shall be conducted in the presence of designated officers/officials of
JMRC following all the guidelines of license/permission and under the supervision
of the designated representative of applicant/Licensee. The event may be inspected
by JMRC team/officials from time to time for compliance of the license and
security/safety aspect of JMRC.

4.

Fees for Grant of License & Security Deposit:

Page 2 of 15

<!-- page 4 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS
4.1

Fees & Security deposit for the grant of the license shall be as under:
S.
No.

Area of booking & Purpose

Fees for Hour /
day/ Week
(in Rs.)

Fees for subsequent
hours/days/Week
(in Rs.)

Amount of
Security
Deposit
(in Rs.)

a.

Train for shooting & other events

1.

Inside a Coach of running regular Metro
train for shooting, photography & any
other feasible event.

5,000 per
Coach for 04
hour

1,000 per
Coach per
hour

5,000

2.

Inside an exclusive dedicated 04 Coach
Running train during Non-Revenue
hours

20,000 per
train set per
4 hour

5,000 per
train set per
hour

10,000

b.

Inside Metro station
advertisements, etc.

1.

Inside Station (Per Station)

c.

Space for shooting/exhibition/events/short terms parking (Minimum chargeable
area 100 Sqm)

1.

Space on vacant land outside Metro
Stations (parking area) and any other
Land parcel outside Metro Corridor,
subject to availability and technical
feasibility.

d.

Space at Metro Station/Depot (including bare space for canopy, etc) (Minimum
chargeable area 10 Sqm)

1.

At concourse level of metro station
(above ground land or below ground
level as the case may be)

15 per sqm
per day

10 per sqm
per day

2.

At ground floor of metro station inside
shutter or at ground floor inside metro
depot (covered area)

15 per sqm
per day

10 per sqm
per day

3.

At ground floor Metro Station with open
access from road

15 per sqm
per day

10 per sqm
per day

4.

Open space inside metro depot/station

15 per sqm
per day

10 per sqm
per day

e.

Display of Advertisement for short term (Minimum size 18 Sqft & minimum
duration 1 week)

1.

One Sided Standee (6’ x 3’)

100 per day

100 per day

2.

Two Sided Standee (6’ x 3’)

150 per day

150 per day

3.

Banners (6’ x 3’)

100 per day

100 per day

for

shooting/photography
8,000 per
station per 4
hour

5 per sqm
per day

of

film/

commercial/

2,000 per
station per
hour

5,000

5 per sqm
per day

10,000

2,000

2,000

Note:
1)

Per day means a period of 24 hours

2)

Taxes (GST) shall be extra as per applicable rates.

Page 3 of 15

<!-- page 5 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS

4.2

3)

Unit charges shall be as applicable for one hour or one day; as the case may be. The
duration of shooting/ event beyond this period, shall be in the span of 20
minutes/1 day and the charges shall be applicable on pro-rata basis.

4)

One train set comprises of 4 Coaches.

5)

The maximum duration of short term licensing under this policy for any event shall
not be more than 30 days.

6)

In case of Standees / Banner of bigger size than 18 Sqft, the additional charges shall
be payable proportionately.

7)

Minimum total billing amount at a time to one agency shall be Rs. 2000/(excluding GST).

Scope of short terms licenses shall be as under:
a) Inside Train: The activity inside the train shall include shooting of
boarding/deboarding at platforms. JMRC may also arrange a dedicated train as
required during commercial/non-commercial running hours depending upon
feasibility. In case of commercial running train, one of Coach may be booked for
photography, videography & other feasible events. In such case, the booked
Coach shall be isolated from the committee of other Coaches.
b) Inside Station: The activity inside Station area shall include such as circulating
area, entrance, unpaid & paid areas, platforms. The shooting of regular revenue
train from the platform without any actor/actress/crew member inside the
train or boarding/deboarding the train will be permitted as part of shooting of
the station.
c) Vacant land space outside Metro Station: The exhibition/event etc. will be
permitted for short term (maximum for one month in single stretch) in t h e
parking area adjacent to Metro Stations subject to technical feasibility. Such
events can be organized at parking areas adjacent to some of the metro Stations,
i.e., Mansarover (north side), New Aatish Market (North or south side), Vivek
Vihar (North side), Ram Nagar (North or south side), subject to feasibility. Also,
similar license may be granted for the Land Parcels at Dev Nagar, Lal Kothi,
Phoos Ka Bangla, etc., for short term (maximum for one month in single stretch)
events subject to technical feasibility & following all statutory guidelines.
d) Retail Spaces/other spaces inside metro stations/Depot: The space can be
given for maximum 1 month in one stretch. The Licensee will be permitted to
install only temporary structures, and all safety guidelines are to be followed.
The retail spaces inside shutter will be accessible to public only during
commercial hours of Jaipur Metro.
e) Display Advertisement for short term: Advertisement through Standees/Flex
Banners inside/outside metro stations or inside metro depot, in case JMRC has
not licensed exclusive rights to other agency.

4.3

The License fees shall be paid, in advance, in the form of Demand Draft / Banker’s
Cheque drawn in favour of “Jaipur Metro Rail Corporation” payable at Jaipur or
through Electronic Payment Transfer (NEFT/RTGS/IMPS).

Page 4 of 15

<!-- page 6 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS

4.4

Besides applicable license fees, the applicant shall be required to submit interest
free Security Deposit in the form of Demand Draft / Banker’s Cheque as mentioned
in table at 4.1 above. The amount of the Security is required to be deposited on
confirmation of booking (at least 3 days in advance of scheduled date of event). In
case of any loss and/or damage caused to JMRC’s property, the applicable amount
will be deducted from the security deposit and it will be charged additionally in case
it exceeds the security amount.
This security deposit shall be refunded after completion of event deducting dues of
JMRC, if there is any.

4.5

For the events organized on hourly or such basis, the agency will be given maximum
60 minutes free time to set up the instruments/ camera, etc. and maximum 60
minutes free time to dismantle the shooting/ event setup and to wrap up the event.
In case of events booked for days, the above time limit shall be half day (12 hours)
for setting up and half day (12 hours) for wrapping up.
In case of any dispute regarding time of start/wrap up of activity or free time
allowed, the decision of JMRC would be final and binding.

4.6

In case the event goes beyond permitted time, then additional charges on pro rata
basis shall have to be paid by the applicant. The additional time to be rounded off to
next 15 minutes as illustrated below.
Illustration: If the film shooting is scheduled from 10 PM to 11 PM and the shooting
continues till 11:10 PM, the booking fee will be charged upto 11:15 PM i.e. for 1¼ hrs.
The booking fee for remaining 15 minutes (¼ hour) would be paid by the agency on
pro- rata basis as per clause 4.1.
In case of events organized on daily basis; the additional time shall be counted for
day basis (in the multiples of additional days), and any additional time shall be
rounded off to next one day
Such extension will not be permitted more than 50% of additional time/days from
the original permitted time schedule, depending upon availability, feasibility,
amount of advance rent and security deposit. Any additional charges beyond the
security deposit; will have to be paid before leaving the venue.

4.7

Once the permission/license is granted, change in category from station to train
and vice versa shall only be allowed if it is generating more revenue than already
agreed and if feasible. If it is found leading to lowering of revenue then it will not be
agreed.

5.

Indemnity Bond:
The applicant shall submit an Indemnity bond (Annexure – B) on a stamp paper of
requisite value under the Law, duly notarized, indemnifying JMRC completely
against any loss, injury, damage caused to metro commuters, JMRC men, material &
property and to their own men & material during the license period and undertake
to bear all cost incurred as a result of such incidence, before the start of event.

Page 5 of 15

<!-- page 7 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS

6.

Cancellation and Refund Rules:

6.1

The booking may be cancelled during JMRC office hours, i.e., from 9:30 AM to 6:00
PM (from Monday to Friday) on the request of the applicant, upon submission of an
application duly signed on the letter head by the same person who made the
application; or upon receiving of an email from the official email id shared by the
applicant at the time of applying for booking, i.e. under Annexure A. The refund of
the booking amount shall be as under:
Time of making request for cancellation

% Refundable booking amount

7 or more days prior to the event

90%

5 to 6 days prior to the event

75%

3 to 4 days prior to the event

50%

2 or lesser days prior to the event

25%

Illustration: If booking has been made for Sept 15, 2018
Time of making request for cancellation

% Refundable booking amount

Before or on Sept 8, 2018

90%

After Sept 8 but before or on Sept 10, 2018

75%

After Sept 10 but before or on Sept 12, 2018

50%

After Sept 12, 2018

25%

6.2

The Security Deposit will be refunded in full on cancellation of the booking.

6.3

JMRC, at its sole discretion, may permit full refund in case of force majeure or special
condition.

6.4

JMRC shall, at all times, reserve the right to halt any activity that is deemed to
adversely impact the safety and security of metro operations, personnel and
property; or is prima facie deemed against law of the land, or is apprehended to
disturb law & order situation. Decision of JMRC in this case shall be final and binding
on the Licensee. In such cases the booking fees will be refunded on pro-rata basis,
i.e., the period of shooting will be counted up to the next 15th minute (for the events
organized on two hourly or such basis), or upto the remaining part of that day (for
the events organized on days basis) and the booking fee will be charged upto the
period of shooting/ filming/ activity.
Illustration: if the film shooting is scheduled from 10 AM to 12 AM and the shooting
has be cancelled at 11:10 AM by JMRC on account of any of the above reason, the
booking fee will be charged upto 11:15 AM, i.e., for 01 hour and 15 minutes only on
proportionate basis. The booking fee for remaining 45 minutes would be refunded.

6.5

In case of acceptance of cancellation request, JMRC reserve the right to allocate it to
the next applicant in the order of priority.

Page 6 of 15

<!-- page 8 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS
7.

Prohibited items & activities:

7.1

Activities prohibited under any law including but not limited to the Metro Railways
(Operation & Maintenance) Act, 2002 and Rules made there under will not be
allowed.

7.2

Use of fire, crackers, gunfire, arms, explosives, alcohol, narcotic substance,
contraband goods, radioactive substances, hazardous chemical/ material,
petrol/diesel and other inflammable chemicals, narcotic drugs and psychotropic
substances, any product/service as notified by JMRC in the public interest or due to
safety/security reasons, or any other items prohibited under any law are not
permitted inside JMRC stations / trains/ premises during the event.

7.3

Animals will generally not be permitted on JMRC property. If it is required, JMRCs
prior permission will be a pre-requisite. If consent is granted, animal(s) must be kept
under control at all times by qualified personnel. Prior to seeking such permission
from JMRC, the applicant shall seek permission from concerned authorities related
to animal welfare, environment protection and others as applicable; and shall comply
with their directions at all times during the currency of license.

7.4

Filming of Photo or Video must not display any offensive or obscene material or any
material with political, religious or racial overtones.

7.5

Any other activity which affect the other existing license/contract of JMRC.

8.

Provision of Temporary electricity supply:

8.1

In case of power requirement during the event at the station/depot, the temporary
power supply will be provided by JMRC on chargeable basis subject to technical
feasibility. In case of non-feasibility, or otherwise, the licesee will be allowed to
obtain direct temporary electrical connection from other power companies.

8.2

Applicant can also use light weight UPS/ battery back-ups for supply of power as
required which can be installed at suitable place within licensed area at their cost &
under the supervision of JMRC team. DG set will not be allowed inside station
building. However, the same can be installed within the licensed area outside station.

8.3

A separate application in the format as provided in Annexure ‘C’ is to be submitted
to Executive Director (Traction/E&M), JMRC for this purpose well in time (i.e.
immediately after issue of NTP and at least two working days in advance).

8.4

The temporary power supply at other land parcels (non metro corridor) shall be
arranged by the licensee directly.

8.5

Temporary connections shall be released by JMRC from nearest source point with
sub-metering arrangements.

8.6

Licensee shall ensure that all electrical wiring, power outlets and gadgets are used
and maintained properly, for guarding against short circuits/fires. The Lessee

Page 7 of 15

<!-- page 9 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS
should also ensure that all notified statutory provisions and standards are observed
in this regard.
8.7

All electrical works for temporary connection beyond this source/ supply point
(JMRC sub meter) shall be undertaken by the Lessee, confirming to specifications
for electrical works as per Annexure D.

8.8

Initially, temporary connection shall be given up to 30 days. During these 30 days,
Rs.100 per week per KW or part thereof shall be charged (temporary connection
charges) over and above applicable tariff (Rate of electricity shall be charged from
Lessee at JVVNL tariff applicable for the purpose to JMRC) to take care of
expenditure done by JMRC for release of electric connection.

8.9

In case of extension of the temporary connection beyond 30 days, temporary
connection charges shall be doubled for the extended period.

8.10

Electrical Security Deposit for tentative consumption of electricity for one month @
Rs. 6000 per KW (i.e. Rs. 200/KW/day) shall have to be deposited by lessee before
release of temporary connection. Billing shall be done as per applicable tariff at the
end of month/ period of temporary connection, whichever is earlier and lessee shall
have to deposit the bill amount within seven days of issue of bill, failing which, the
electric connection shall be disconnected without any prior notice. The
reconnection of electricity shall be done after depositing the due bill amount along
with a token penalty of Rs. 2000/- in each case.

8.11

The electrical security deposit shall be adjusted/ refunded at the end of the period
of temporary connection to lessee.

8.12

Specifications of such electricity works which may include ISI marked approved
makes, cables with secified conductors (copper/aluminium), proper guarding
against short circuit/fires, prohibition of PVCs in underground station areas, nonflammability of plastic accessories used in luminaries etc.; and other such safety
related aspects shall be complied by the Licensee under instructions of ED
(Traction/E&M), JMRC.

9.

Other Terms and Conditions:

9.1

Schedule of the event agreed in advance in writing between JMRC and the licensee
and must be strictly adhered to.

9.2

The applicant shall be responsible to obtain any/ all permissions from all concerned
agencies of local/State/Central Government, wherever required. The applicant
shall ensure that no such act /omission is done on their part which may affect the
law & order situation in JMRC.

9.3

JMRC reserves the right to interrupt or halt any event considering the safety &
security of Metro operations, personnel and property, before or during the course
of event, without any advance notice and no claim or compensation in this regard
will be entertained.
Page 8 of 15

<!-- page 10 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS

9.4

It shall be the sole responsibility of the applicant to clean up debris or any garbage
material or any housekeeping activity, created and / or brought in by the applicant
and to conduct cleaning at the end of license period. Any costs incurred by JMRC
due to the negligence or failure of the applicant in this regard shall be deducted from
the security deposit of the applicant or charged additionally in case it exceeds the
security amount.

9.5

The company/production house may use film, video and photographs shot at JMRC
only for the purpose stated in the application form. The images/ footage should not
be used for any other purpose without written permission from JMRC.

9.6

JMRC reserves the right to restrict the number of persons and the number/type of
equipment/vehicle entering the metro station/train /other spaces for this activity.

9.7

JMRC shall not be held responsible for any liabilities, bodily injuries, deaths, losses,
lawsuits, claims, demands, fines, damages, costs and expenses (including all costs for
investigation and defence and expenses including legal fees thereof) which are
caused by the actions of the applicant and/ or by any participant in the event.

9.8

There should not be any inconvenience to the daily commuters at the time of the
event.

9.9

Temporary display of advertisement during the event within the licensed area will
be permitted without any conflict of interest with the JMRC’s licensee’s for
outdoor/indoor advertisements.

9.10

The proposed activities shall not tamper the operational activities or cause any
inconvenience to the passengers.

9.11

No negative projection of the State or JMRC in the Film/ Documentary/Event is
permitted. There should not be any direct/indirect reference to terrorism in the
script which contains shots of the metro.

9.12

In case of any loss and / or damage caused to JMRC’s property, the appropriate
amount will be deducted from the security deposit or charged additionally in case it
exceeds the security amount.

9.13

All people of the applicant’s team shall carry entry badges at the time of event. The
entry fees for the crew members and staff of applicant for paid areas is included in
the Licence fees.

9.14

In case of any exhibition/Mela etc., at JMRC land parcels, all statutory permission,
including fire NOC, security clearance, Traffic clearance, etc., shall be obtained by
the licensee from concerned authorities.

9.15

The Licensee is not allowed to make any changes in respect of the names of the
locations, stations, train etc. without prior specific permission of JMRC.

Page 9 of 15

<!-- page 11 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS

9.16

JMRC staff/contractual staff and its contractors will not be involved in the event
without the prior written permission of JMRC.

9.17

JMRC reserves the right to restrict the number of persons and the type of equipment
entering the metro station/depot/train/other land parcels, for this activity.

9.18

The 3rd party insurance shall be mandatory only for such events as may be
prescribed by JMRC and shall not be applicable in case of small events like canopy
installation, display advertisement etc. covered under 4.1(d) & (e) of policy.

9.19

JMRC has also empanelled event management agencies to get & organise such
events. In case of event proposal received through such empanelled event
management agencies, concession/discount shall be applicable to such agencies as
per terms & conditions of empanelment.

9.20

The concession in license fees shall be @20% for the event organized by the
employees for themselves or their dependants & there will not be any security
deposit in such cases. Also, no concession/ discount shall be payable to event
management agencies in such cases.

9.21

The entry limit of visitor/guest for each event shall be as under for which no Metro
Tickets will be required :
Per coach of train
Per Train
Per Station

50 Pax.
200 Pax.
200 Pax.

9.22

Hours/Days shall be counted consecutively, any gap of duration shall be considered
as separate application.

10.

Exemption / Relaxations:
(i)
(ii)

(iii)
(iv)
(v)

Any exemption / relaxation in the policy may be permitted with the approval
of MD, JMRC.
In specific cases, JMRC may offer license to any govt. organisation on free of
charge except the electricity bill or on special rates at the discretion of MD,
JRMC.
Also, JMRC may relax the Security Deposit for any organisation partially or
fully, with the approval of MD, JMRC.
No Security Deposit and no application fee will be applicable in case of events
organized through empanelled event management agencies.
In case of any event not covered under this policy, MD, JMRC may approve
rates/fees for short terms license on case to case basis.

Encl.: Annexure A, B, C & D

Page 10 of 15

<!-- page 12 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS
Annexure-A
APPLICATION FORM FOR GRANT OF SHORT TERM LICENSE
(To be submitted at least 10 working days in advance from the proposed date of event / License
commencement)
Date of Application: _________________

Applicant Type: Company/ Production House/ Organisation/Individual/……… (any other)
1. Name

: _______________________________________________________

2. Address :

__________________________________________________

3. Contact Person & : __________________________________________________
Contact details

Mobile No: ……………………………… E-mail: ……………………………………..

4. Event/License Type

: ________________________________________

5. Proposed Location(s)

: _______________________________________

6. Proposed Date(s) and Time(s) of the event/license (including break up of time for site preparation,
shooting and wrap up):
______________________________________________________

7. Synopsis / detailed description/outline pertaining to the event/license at JMRC premises
(attach additional sheet(s), if necessary)

______________________________________________________
______________________________________________________

8. Total Number of People (as applicable) :________________________________
(Including crew, cast, etc.)

9.

List & type of Equipments

: ___________________________________

10. Charges payable to JMRC as per policy: _______________________________
11. Security Deposit applicable as per JMRC policy: __________________________
I/we hereby undertake as per following:
UNDERTAKING
I/we certify that the details of this application accurately reflect the event as proposed, and
that I have fully read and understood the terms and condition mentioned in the Policy Circular
of JMRC. If the event is approved, my company and I agree to abide by the guidelines and terms
& conditions established in the policy circular. A signed copy of JMRC’s policy circular accepting
the terms & conditions is enclosed herewith.
Encl : as above.
Place: __________

Date: ____________
(Signature of Authorised Signatory &
Company Seal)
Name & Designation:
Page 11 of 15

<!-- page 13 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS
Annexure-B
INDEMNITY BOND
[ON STAMP PAPER OF REQUISITE VALUE AND DULY NOTARISED]

(To be submitted at least 10 working days before the date of scheduled event/License
commencement)

I [Name of the official],[Designation], [organization] having Registered Office at
_____________________________ and [having been duly authorized by the said
organization (strike out if executing in individual or sole proprietorship capacity) have been
permitted by Jaipur Metro Rail Corporation Ltd. to carry out ________________ [event]
for a period of ______days from ______ to ________ , and from …………(time) to ………..
(time) for my visit to ___________________.
I hereby indemnify Jaipur Metro Rail Corporation, its Representative and Officials completely
against any loss, injury, damage caused to metro commuters, JMRC's men, material & property
and to our men & material & property, or any third party as well due to any act or omission
attributable to us during the said license period and undertake to bear all costs incurred as a
result of such incident.
I hereby further state that no claims/damages whatsoever shall be made by myself or my
representative or those whom I represent against JMRC on the aforesaid context before any
court/ statutory authorities.

Signed___________________________

witnessed by_________________

Name of Indemnifier__________________

(1)________________________

_______________________________

_________________________

Designation:_______________________

(2)________________________

Address__________________________

__________________________

_______________________________

__________________________

Page 12 of 15

<!-- page 14 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS
ANNEXURE C
FORMAT OF APPLICATION FOR TEMPORARY POWER SUPPLY

To,
Executive Director (Traction/E&M),
O&S Directorate, Jaipur Metro Rail Corporation
Dear Sir,
Kindly provide electricity connection for ………….. purpose at ……….. Jaipur Metro Rail Station,
as per following details:
S
N
1.

Item

2.
3.
4.
5.
6.

Station
Location
Reference to allotment letter (Copy to be attached)
Load Requirement (KW)
Details of submission of Electrical Security
Deposited as per load demand
Details of submission of one time lump-sum amount
as per load demand
Details of Cable installed/ to be installed along with
earthing (Make, rating and specification)
Details of MCCB/MCB installed/ to be installed
(make, rating and specification)
Details of ELCB installed/ to be installed (make,
rating and specification)
Attach cable layout plan of leased space
Attach electrical installation test reports (L Form)
signed from electrical contractor holding valid
license/ qualified diploma/ degree Electrical
Engineer. (In case of Permanent Connection)

7.
8.
9.
10.
11.
12.

Details

Name of the Applicant

All details furnished in the application are true to the Applicant’s knowledge. If any information is found
incorrect at a later date, JMRC will have the right to withhold/disconnect supply, as the case may be,
and forfeit the Electrical Security deposit. We further agree to abide by all the Rules & Guidelines of JMRC
for release, upkeep & maintenance of electrical power.

Signature of Applicant
Encl: Copy of Notice to proceed.
Note: After receiving application along with all relevant papers/submission of all required amount from
lessee, the Traction/ E&M Department of JMRC shall release temporary electrical connection after
verification and inspection of site.

Page 13 of 15

<!-- page 15 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS
ANNEXURE D
SPECIFICATIONS FOR ELECTRICAL WORKS
i.

All the electrical work done within the Applicant’s spaces including wiring, power outlets and
gadgets are to be used and maintained properly for guarding against short circuits/fires and
are as per the Indian Electricity Rule, 1956 and other applicable laws, statutory provisions and
standards in force at the time, and indemnify JMRC against any loss accrued to the Applicant
on this account.

ii.

Only FRLS cable of required size shall be used for tapping off supply from JMRC fixed supply to
Applicant spaces in rigid GI Conduit pipe. However for underground station FRLSZH cable shall
be used. Use of PVCs is strictly prohibited in underground station area. The wiring scheme, the
type of wiring, size of wires, various loads, plug point, light fan etc. shall be as per JMRC’s
approval.

iii.

Cables upto 6 Sq.mm will be of copper conductor and above 6 Sq.mm Aluminium conductors
may be used. However in case of underground station, use of Aluminium conductor cable is
not allowed. Cables for single phase shall be three core, with one core as earth. For three phase
load, four core cables along with separate 2 nos. of 8 SWG GI wires shall be used for earthing.
For underground stations, 2 separate earth wire of 8 SWG copper conductors shall be used.

iv.

For elevated stations, all wires shall be FRLS. Cables shall be armoured, XLPE, FRLS. In case of
Underground stations, all wires and cables shall be armoured, XLPE FRLSZH and conform to
NFPA-70, BS-6724 and BS6724

v.

Applicant will provide a separate protection for their electric requirement with proper
discrimination with upstream breaker.

vi.

All materials specification must follow standards, codes and specification as used by JMRC in
the E&M works. Applicant shall use reputed Brand/make Electrical wiring and switch gear
items. List of approved makes by JMRC is given below:
List of Approved Makes:
SN
1.
2.

Item
GI Conduit Pipes
GI Conduit Accessories

Approved Makes
ISI Marked
Confirming to BIS/ISI as per approved samples

3.

Copper Conductor FRLS, PVC insulated
wires (ISI mark)

National, Ecko, Finolex, Havells, Grandly, NICCO,
Asian, Poly Cab

4.

Copper Conductor FRLSZH , PVC insulated
wires (ISI mark) use for underground
station

Polycab, Ducab Dubai, Cords Cables, KEI.

5.

FRLS Cables Al (ISI mark)

Fort Gloster, NICCO, Finolex, Asian/RPG, KEI,
Havells, Polycab, CCI, Universal

6.

FRLS Cables Al (ISI mark)

Fort Gloster, NICCO, Finolex, Asian/RPG, KEI,
Havells, Polycab, CCI, Universal

7.

FRLSZH , PVC Cables Al (ISI mark) use for
underground station

Polycab, Ducab Dubai, Cords Cables, KEI,
RashiCables.

8.

Switches & Socket outlets(ISI mark)

Crabtree, Anchor, MDS, LK (Schneider), RK,
Legrand

9.

MCB, RCCB (ELCB)

L&T Hager, MDS, Siemens, GE, Merlin-Gerin,
ABB, Schnieder, Standard, Indo-Asian, Havells

10.

Distribution Boards

L&T Hager, MDS, Siemens, ABB, Indo-Asian,
Havells, GE, Schnieder, Standard

11.

Luminaries

Philips / Schrader / Osram / Bajaj / Thorn /
Crompton

Page 14 of 15

<!-- page 16 -->

POLICY FOR GRANTING SHORT TERM LICENSE OF JMRC’S ASSETS
12.

Air Conditioner
(Minimum three star rating)

Hitachi, Blue Star, O- General, Daikin, Voltas, LG,
Samsung,

In case electrical items of any other make, the same needs to be approved from JMRC before
installation.
vii.

Only Galvanized Cable tray, Conduit, Cable Ladder shall be allowed.

viii.

Internal wiring of luminaries (Light Fittings) and Signages in signage’s panel shall also be
FRLSZH in case of UG stations.

ix.

All Plastic accessories used in luminaries shall be non-flammable material, meeting all the NFPA
requirements, preferable by UV and shall be suitable for application at UG station conforming
to UL – 94 standards on flammability of material.

Page 15 of 15
