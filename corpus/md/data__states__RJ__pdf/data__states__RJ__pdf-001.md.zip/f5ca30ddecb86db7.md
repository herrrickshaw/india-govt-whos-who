---
doc_id: "f5ca30ddecb86db7"
source_url: "https://excise.rajasthan.gov.in/Downloads/RSBCL/Policy_2005_06%20to%202009_10.pdf"
ministry: "Excise Department, Rajasthan"
title: "2005-2006 To 2009-2010"
date: ""
pages: 68
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "eff3d371c0bd5ab1"
---

<!-- page 1 -->

_-ri--- --\_--/

rfu{q
-.

"'1,

ytl+(85]lE\V3tltI/03

q{ zoo+-zoos

Bg

s8

2oo4-zoo5
er qrq-#t

<!-- page 2 -->

(q),ironoaoqo^
, uq,or_*_; #;_l#
Tflgr+ qflh1 ro yM
trr,

(v)

m,"H

r

Jk

2003-zw4
qnmq(t sre.rrtu
+ffi zo._

ffiiffii%*tsryryhftqE

=ffiq'###w***

-r,

m

ffi'ffi
mnn*i* *T sqnrsdzoo3_zoo4-

4
ffiRt*iF#*sw_{ffi*.#
c
- , , . f l . 2 9 q 1 2 c c 4 f r qG
w iA i
z:r?Frml-Eiqnh*R
rrftiqfrqW ,

''':''

^"nrdHP

ffiJ,,oo*
"i"-S#.XE#Ymg#

fltrwffiffisi*mra*x

effiSHRH'm'H"s
-2-

<!-- page 3 -->

7,
(3) \il ora*rurqni r: -s-

-1,+.
l2

^

_$. TD'* sc q
/ ffi'"TX;H#SJt#ffi%_#,i
wr +-qelh}"ffi#'*5}.*

-s
**
#
S ;d*..TI
ftS'"S_tXi
ft-Hk,wH-ffi"ffiffi.T#

,'ffi*{,TH#
ffiffif,***m*w*
S,*###T d **.-o"C#Hr *" nqr

% i;''#ffiNffiRhms**w
(t) sofzoo.r-zoos
I >*-l-.

(qoR#"ffi+ ;*#' L*"" ^t q{ffi1+}i'r
T
qh{r
qf{r +} vqe Aa*
Htrqq+r
&n aqr
i"rT?si
?e1t
vq*-#};'jpqtuT
qr "#l! Wrdqrch'i'r

qrql

.,.TIrFrerTrt
"r) dl q+en +l

.1

-}

r"

$3)**F*kH,'d*t*q^ft-"t q t \mEsdrr
c{Fc}zoo
#"*"' -I'1-TSJ#S,**,*
(+)
?eft'.{Fir+ ftqftT+ F

ffirustL,ffik_ffi,H
fr .q o-A rhft r orqtrft qp_l
*
T_-tooo-or
-3-

***.a

<!-- page 4 -->

hfttn-rT"TffiH.)"ff"y"vthr
rrir
.i oqvnntl
Eaqt
u-o'+
nm
Fdfti-ft*t-ft
m'
l{'#W
"$' BId ci Riz (qrnl no,
qrrrn|

i
i
. 1I .

W 3rgilrs' ?U ?q wo * . z,b. =+ e._
Rfu +) ft-rrrsm {sitDfl
Grmr

t :_

II

fuqT
lat

rnlj

clz

EHqr{

TqT
2'
3

.

ii##H
=___l

irtrrEf,_--

.flI(1

vt lr

qE-qe.

17.00
14.50

20.00

r 1.50

13.00

r6.00

f^*rry,-',ooj3*a*ffi
d*;
1g;gt5g3.n-,^*
rffi'#-H
ft#,tu+".d;;
cnsr
Sft W T
i#
fc srd eRsTd
Rile(rnn) Rqr qltal

iffiT

I

Fffi#ffiffi*
+G,"rn..tu."+;;f il lTJ'uffi
'?+
ry*FS
qra

d
r
r:. {6p,-a *

' / - \ r o :

q{ qR fr} qr+sr n-{qm
:
-+d zoo:_zoo+
} €tz
','ri" ETr+ frc

* *.t *uyrt.a *
5l11R+ {dr rtaaqq
q+cc

d, ;

T-53i

kaH'';"H

Tdd^.rnr^,18-{

rq} E}

2004-2005
- t ,r*'-";

{';;l'H

d,=.J ,.

ffit.tffi*#*.}H Rsti Rla"- gt" R*";
t-'

I
i

,:,4

<!-- page 5 -->

(2)"stdm+ Mla FTftqt$ q;6,
ftn
fr 3rTqR

c-{fuqr'qt{T :-

TFer{;e fi

l.

qfms ;qfiq

lqehq

qns+fl-w+ffi g l l
sqt ro.oo
€f=e ,ererTq$6
*In r

2.

3.

sr ;t-{-d-qSeq-daoos.f stc d_fl ._

}}i_*

1g.y6 l
f u . \
q
ti(lt

q6EI

A

..rlll,.!-_.
!a

(Tumover)

I

ctt sq t o,{ qoqhilfr + A"i-*l

Cs qffi

Er I

t. ftt,
,\,\ irqra
vlgr\, .r
.,fqrdrq+1 ghqr

5,

o.

r.

fi{fi rrd w< + €tte

(nr vqqil qnsu* +:t

d F .* -3="* dT- fri qFJif
\ffi
f$^Al
r.qt
iFG
gf{Rhq
+ frq-rrrq sd" d*
q1
HFFqI yr* t ffuiwr furr qrirrn r
"fr.

^_:
\a>

i3)_ttdl=e sT(+ frc ar5nzBgftq-r$rnErffi gw

ftsRd hqT nfldr? ,-

i

6qt dTril
s'q v(aII

R1FT

I trRnlzld 3r;GIr Vf€S

I

BIII|I
-

I^/^

Y1

i

.

<!-- page 6 -->

I

l*

SLYy
rdfi I-(

sn5 \* qr+ETffdq{,q<n
cs td} e l3o
ftq qTs_q,_l
d

* {i's'f,rnat r*t *ito
3rginsffi
d ftlTwlm.,
54iln

'4S$-EI

i qry

E(I Efcm/ffid

#i*ffi**'|.

arr *

:

{Jffi t *frq-{ , q{ zoo+-zoos
gs h1 rrtu il fr"F-{rJsi(

e01"

sq'{qf d"t

tldqn

6ct drd n

^ BrS-rnS

us +Tq<
I

F.,

,2

?f4

2(s=)
3
3{q

3(s)
4

zooa-ioos

F %-n Urs

frr{

cTsftlTrt1rffi

qTTRtRTEE-

fr{ ffi--ffi
eFqtf

tRlo gs" *

il<iE a-s 4-?ltlv 6'* 61-

q'q *ac fq, onq

n ofu'63iTqrfiqt

?50

5.00

5.50
5.50
5.50

4.00
3.00

7.50
z.z)

t.x5

5.00
1.50
0.75

2.25

L50

1.00

o.'7
5

0.50

0-40
0.30

2.50

o"R, qs"dil q 3nS
Yq(l

4(q)

'5(q)

15.

sdr qrit
qsfuR A'.d

w

*'rq qqgt {

ffiqr sq gffr T(

0.50

qqRr e-F'Rn en asmnRdl dr eTr;ftqsnsrqffi
fr crs
sqi|Qr
ni
enqe
vdl t mq +Tir 3lrqiqs d,n *S
^qli{

3qflsrftmuXru (on<+rtr
,, nm"
To' qfrr) t 3{fu+.,aq

fi![{ frf-( qrt 3l1ilutftit ft] EFq fi v+rr. Es sitsFr*,1
crsqH 3rf,frtqa sr,ff.i e-r laqrert r

3,-.

-6-

<!-- page 7 -->

t.
t-

,

tU qrrf,hfih ffhR
"e

U

,

ffik$;d#ryftry*Tk.*
Gor25,/r *'lir)l""R
*
H#.TB*S

s

ffitr#kffiq.ffifli
ffitrg*"';rffi

\a

ftF*-ffi#{,rT1#.,q#

ffip,ffiiR*
d ff

",i'*a"ffi'u"*F*ffS**lt*

,ll#

_l#,*irum
fttffiffi+\E
. ,{

q{q-sq'
q.e,rd
{L.S-H'TrTLs-t'-.
xfrq6 *. U='
"I__.* * ern c(
"#T

"o+-r)_

c+r+tff!)slhsTr
gL+_*q.
"-(q)
:o+ *t c-*mRq)
r.oosft qrs * * *Ttl qq d-er* em w sql
(z) qnaftFh fr*ft
1s g drr *, turfor+1e-q+.)

;mm$*S"y"oq-r $ fro.J;-'$
**
ffiSffiT

wrefnnt
T*-r*in"ot** .-

zooqsor'i,o
#-,#JT ffi*y

?r---

".'
-7 -

*

Gq+

<!-- page 8 -->

I
)j

hft^qfril + fulq T{ ft-fr

* a + M,rBil dRT
nft
s'm
trli e iM# riq-r#'H#
AJo
s'''".df i l t i lE
h il
a r rR
n nqft
-A- n
^
ftfth
ain
60Arr00
gng
d_o.#.( +1s_it ._hH4#
(q EFIII

(t) 3qir- cz. Bisfu* st{T dR 3t_{f,rqrt qq
qn
dt
q-STqifrd t.ci.n,6€il.n0T
se. ;fl *.#";J
qri :cr Fcitr
g'Tdrrftt :_\
"
E-ffnRrrst sTqft a * o#
(to} srft, sE tS s Hs' fr-s-(+ dfuf,.
fsrrnr i. qr*rq-a

jry
s.rt'-s.oo
vns+ RrTr'*''A"
tt''r.io=**
mI
""Rt^
ilaina
t r e]'-sg

-vffi
F{ 3}Rfr_{+
#o
q*ra $i ftc
rrftrsql z.oomrisftqhd *f srft a', +

z"E fl\lg
JU{S13
E grilqtJAds qru-sfrq
qr$-r Gqi rc,w/_

LT.

e)-rsr{ 3hfttu"{
c-{q-dqn

sq} so,ooo.z_
sR. srrs.d Fq"l*qT
qrm
ftqr
B r

qh-3tgrfrK :

+srmKg+r"+r
+,qdmr<
I J::r111*
r Rxofi q {qi,,.
qT
fr-wTr
s$"q-{Gqrs vTei
S,n

* .S zoo+-os
Fg qi,T+sr qR g+r++_re_'ar*
Igr
grqnft s-aqm qrt I
(zJ' wr +o iR 5-fin d ed zool-o+
*t crq rRr t ro
sd zoo+_os
fr.3{ifhd rtRr ftqRo +}
ry lry Cr'"$+.(
it
yqt sq-2003-o+ffi q{tt EBEIq31
qR atr ,4rs.
t
?i c-{ Rq-At
{'ni fr frR Erkhr nRr cr sq zoor_o+
6r

Tiqld-{€3lTvR srd sd z00e-0ad flR rtRr qr.ir qtfl
r
q
E6t
qsa
rai q{ sq rrqD
^2003-04 e-d Iq.T +- ftq vK

s ro5ss zool-o+
il =n-1.0r
rS crwrrRrw qqfu+ R\

qEqRm\q t
q-Fi r 3rTEfifruilqffid -nrr}sT AR
1r+
+1_g+m^ruqRftn rFr SF qT6 t
Wt uW t e{irRRd
qFW
qror
fii + RC
r- r
e-qr

t-.-

-8-

. ;!:

<!-- page 9 -->

.8ffi--]"T*1#H,,T,
iii"'a:,aii
ffi
f#
jL{*
nSI"R,+r
,o nnr.*
* ** *_Ug
*riti +sr qR. B-dTr.q,

(3)

6T s Fqf, ocfr &ft r

(4) ftttlr dT-iT
+1wir wXffi+€ qt
q-qer e-drTm
T31$TT.Rq}
t o*
sqsnrqm

* _o_*.*r,* d iir+
q,-sq<rt.
sqrwF-{I
y,i; ffii[_,*nr *
I_q} I a*;#;

#*$.*##,*- *

#*"s-*
*
q-'r
3"tn
fr er=mta
qHHH
+
f*
Y S
TGq
*,
f,J.%*
,*
\"bd"hi:,
"y**#
stsr
clw + .* t ckE{ .R tq
"*\:i-\b/
.
frm. S|q 6-fi
eR ftdmrq* qamr.ol iz ;t"fr#
! ,
(z) - +sr nRi'+ Efun

ftqT"naT

nr-q'+
*o"w sot; #H"R ffir$*- tqi t.oo
ara3Tsrq
+rrtmriir nq Fril

$3 *RrRT-urRdt

r q6;.6q
scbrz)_,efr.#HrH"ffi.*rJ ytrR;.o)
rB.

rr;q +TIft_-ft-a-.
q=m{
s.r
rirnrrr @

strtTT

wvrn elat hil ,rtin

R?$
=+#
t r\, g?r'1t +I
R=UqFIa-irr+l m*JTj
s*ii';'nu#''#
.
f.FMmir( gndt -*
i *O,m
t
st
qEen
s-++rr
lfltRq
-fi-qT+
r,,
eul zw+_uJ
zoo+_os
q<+a.qrft
i{ .ff
€ft

p'

19.

..

r

sl.alfu€
0)

TFII

+

lTzrrre

3leFR

Frd] t
T$
eFaertr*qt/fi-iftrr d; +1\q
q(
tr;tsri
ern
sL)qtr E-cti
qt sT folq ftqlrqr€
r

u,'

- 9-

. ',,4
'tf{

<!-- page 10 -->

{

-

r19
\l
/-':,

"

qrfrsrmdvlq -Ji a

'ffr
dt
st
EIqT
FdEftl ''J
'\
\'| t ^
$s-rsFrR
*t-Tt,,\ro-*
,*,r
rt
Tld}
/.,\
,.{
(3) qTffi
'i 3rr-il"#'; ; "tttt tQ It
qTvtrsmal
y^+ t uS*J'--*H$.'i*-200r
ss + ftc qrsd fr
-"
+
Ql

hc ,i-Jilqrft; ;'F#1:
'}Esq-s + Wf
*'{rrtEFfi|
zo. {q.ft--q.s\,q..T{

(r)

"nt

"'o
H H

Rqq , _

ffi,"**Bt

rTi*

T'

frqv,E-ilr,rj
-q ft.m fturrru6i7

Y4]t Y-ff' Tor wqrr-r*, rrdrcqri,

"od S* FH
**, \-q* i*{s,
e'n'.#)l+
#i*.**

e-+*or
n-qq
tg ffi

**'r#.,9n

d.
l"

ft.mz

mnt r
s) qlstrf,
*
; # ;"r'r Y.:
"'q^"nrr s.-,io)
Hrtlf{olil laFi

(3)

s-{i or #a' ft* #,'

u * +++1.aqqi a*ggdr

ffi*R#*},*u

(4) qtrc qs qrq

sTad*d'#\Ttr.*

3r-j\i-td*s##,*

+} *,-*noo
*t
{d'r
nvF.nnqfi

erc.qn)
+

(5) te qd t ffi qTg-o+
"+t s.d

sT srdqfud
srs-qrr,** t tr;._#
.11
"a.
F 3t*<n
T*
!6)
"de'uir)o"+ #,:"Ro
*.ar *In$
qri
tffg,*o Erhq!-{s
iuo
e'
,
d>!
sh*-qd
";#"8##
zt

l
!

i

iils-flt

T"Tq +l oeq. qd -}[":_2004_05i ftiq
'.lc qq} ,..r.
ItstttofuqrrRTA. q+1
t:z:.oo+tts
fuo.d.t
Yl
wR
3lltr
il-ii
36qr{fi } r

Y,--

' /.':

- t0 -

:
1i

!

j

<!-- page 11 -->

.,. \,"rq !.r 1q ytqqtll gffqlleq?rRll
-

3rgsqqxrq-d
rEI r

Fd' flfr

fr

Es {fr d mq +-c} i ftq q111zfiq,itzqiqit,qrq
t trr

*X-gr:l$rtrs
M
+i xq Et r

a -ri'.R.ffi.#)#"i'"+ o*o

orqffi qoAeRr
frrio. zs s-r{ft, 2004no

rrnTv.sr fr i&a fr qrt r

ryf +n qaal

.t

:refu,
,<:j1\'>o..9---/L4: a.?4--

$i.qtr.qq-srs)
w slRrl sfuE.:.
trf (sircsrfr)Ffilrr

-

.t.

-::t

dI^

-11-

<!-- page 12 -->

Cv)
\-J-l

iiijii?i11l (1iii{

r1)11-fl.r
1

[]rofi'rrr,;

bl-

'irmtril:u.rrrrur\
'.'',-t",/
\"

:

:, ..t.4(11)futit
/ 1!fl / 01

'rRrr{!.-.-}i.1' tt1 : l2.t)2.2005

: .:rl:oo:-zcoo
rrd rlti Tirm. f ieri r norrr '. ^o\
ig +rrrrorQ
.
,llir ri;rhtrlwr r
'

-,
:!
r4.,t1r ,,,i ,j ,r .' ,l , t, ,i ( r . l, . ' l. t\ r- { ' u i i i f f l ; i

\_-__'rvr

!\l

rvv/

;ji{l

I| i\rrrrr |J,rr,/ ' 6 , \ , , . . , , . ,- ^ ^ \ -rnl rr \l r ln " , ' ^

l ; l i l l l - i i;TT , {

\runlpctrUtCCj

-.)
qtr?ft
lqr.i} : ltvtr tR,-r,tv r)'ll) ,rltrr g,6p) ii;r rrq)-,Rir
r.r.:qurR,fl
ii) ritlll q.i .'rr.nllf4o fd,l'tt'tltti / ..flrn
D.irrrli)
-"

;'

i'r,r'ri

i;.
?.

r'

:rL

r{ (

::

I

j i t ) l / t t ' i , l J ( j'Dlr
r)t
.l,(!t'r (, .
^rrJ*ri
r':,< -dlilitcfirl
,r
1 . . f l .rr'.)rr

( 'i:.
i)t,lr ." I

i l i n i i i : . j r J , r r ,:1rlr i r i i ; r l i i , l i i r r i ta ' t - i t q l i li l r ' ) , l l l r r , r , .l i r q r l ) z l t f ;

''.**,
irlt r),f}t w,a li)l,iilr:;1,,r,
{li.ri,r; r.rzoor r't 1r.3.2007)
. .

:|

,
':

i : l

';'
.j::

;

l',.'

o yliri. r r) 'rJrorg-."rri .n. ,Ie r"f.e
tfl .,qqTtlrR. n qr
',1'tjir'
i11t)rr1,,1.,,,
hf,ltrfirilrfl,rftir/rfhrr
r,rti.r)'on
"r1,
grl,t

"1,i iii it,rriQr,n ri.y,f|1f]'t1,rd ii' 'iry.rr.rrar drtr hrriRo
.Lt.ti--.r.''l|iil,;;.,u17,,1t1ili'.rf}irtrrnt'itt
"'
. "rr" I
,/

<!-- page 13 -->

r.

m)inr lllrn;1t1i qRrrd &i,1,jrn,r)l,riil
Frfthrg
on,illir
4;i it?liltfi.tltlifn liirf] rrf,llr/ ifir.r(nil ?h'3qiFr;t
,ld1r

'*

rrt rijJi[:rI zl;l [i]r] ;;1) ;p1[.jo!21
lirrit rnrr i] | qft lll;rfi .rrrir
1.li,i(ri)illii til;.,lt ?itrrJqa;n.f1 qir l'] rrfiI,Fqrrl (El
/
rf
!l!"{r
,i;il .) r;) jq1;,;-1 ig liua etr;l.inmt nrt., ..ii<0
rrf,,rrri) [];zr
irrrl , " fl rll yfurrr 4,' ar) ,i ja1.r;t) L,rr,r p1;1 .1n
1;,1
tr,rn i) ?tl,iliit rs.-t m-s-ft.nn;nz)I
' t i . l U | , 1 1: t , I r r t r D r . F- r1 , t i / . t i, \ , ) . l ; . , , 6 1
o . r r i r L 15
11 . 6 6 9
'F}ljrl
, r: ,::r ri{ r,r.,irl.,Ftr
, p.' qJ .l,fi .A r,prt -.j,l,r-i)
,.i .:1)1
.; I Ir,";'i:iiii,i;i1 ijli {trJllr;\ il:;li +1i171
d ut.Hnr ;i;)

r|':1; .'1i;;11

#r*

d'l$!,S{kf
u...u,:g!ot'f;Ji$:i$&&fiffi;d$B$t

: '..r'.r i l.i:
, . . , ) n i . ] : L . r rl r r r , , ., , . , r[ 1 , , ;i n r r ), , J
j,c_i;si,riieijffi,dr.U;A#li
"
:m&uisi
l : f l r , : ' l; t i r , ' iril
, /11;.rr
r'Ji;tilri)-FFi\
llrKf
rql I.rllLr
g,nri
rr Q
l,i T6
r r l o l T d l i , ,;t rtt
$llr f tr r
Drlvl] ,rfitr rsi il)rR ii) q:fr -,;rri) ?tTt1i.rc'tqlri;1irs 3llif),r
l;r il"rrr;irr) |

i:ll',,?v
.i
, brE

'l"Igi ,t;i
i-'rii ':i,l1i a;:i:) rril ricrir: i:il r1fi111
i ir,ar zs t)'ft
;;uti.); ,;t'r;rrfrJ*ti

5.

ffit

') r

i"it trlirt i;'; ilfirr; r;;1 onF ftc,)

i1,),l.j irr [ivl-rrftrir rnft t i .
1,,.;11;rlllrij
- . . - - - .
,ty1;rrf],1,i11]
E WR) {il ?} 6: nrii
3rptlattrllr,: q,i zooa-2cot;
tj i)rlr ,rfitsri,.6r)4l) qr6 llr v,i E-t {i,rd dlrr 31pi1tpj) ,l:1)
,;1',;;ir) orirli.{'11'1)gt1 ?llt ;iltri {t,lri} ttl .ilil'rirl
, . , i r i . t i t i i , t | ) , i l r , r r , , : l l il t trrl t f l t l l ' 1 : i ; 1 a - t r ) I v l ; r i
:1q1.11'; ;)'l 'rllrli ,f ;'s 1yl;ri ,t1 zi1;1 ':rlr)t,lr-tlir $qll 53c.a)o
.;i;
,11,',,s

'r;.,,; r,:r.j ii,; ft,,!21ftrr{r ij i .rnr:i
ijlliri

d'.t a'$i rrt .ttl'tt i ,ri

;r irJrl ,ilr.r'R r-fn fttl trlit (rli 'tl'lrt ilrll n[ {til ii. ;;1't

.rrjiir:t,tltlii :.ri,.t,il) Ilta,t"f ,t? lto li:j,'r' tle t)
I
"ils fl "tt;l
.,liiilF1 r) 'rr) .rirq-ql$
''i
::'l;. ,,i,ltt qt
fil
ii,^t iFI Fiit)Ci itiii;;tt
t

)

<!-- page 14 -->

L l l !I I

':ril

, . i..,I : ..

f'

' r ' , iil..i:Rli
ir:etr.rir.,ii\

.",

\ . , ' ,l , , n - 1
rr,t

t

- - I
U, 'l:

[,Fi)

2 /'.'.=r41),t ;
./

Yc!r**{,

-.ti.) ,;,'

F]ofr1I'ilril ryql

l

tlfl 'rfllr gor.r'ia5)ii@r: lrvrrri.ribri:){rgr.,\ i)-rf}'rfirr $nrii
iil) {ir ilt,9oco ,,-ti.) i61 fyvi'1 .ftp11L}t ,r,i,rFtri rii;zt a} ;nvttfu A-'t 7 r o

ii ,r,rlrl rlf'i.:i1,66i1r;!)lrriuri.E,)..rzr,r,r
100-tli-ini \p-1r
r)rl
',;!rl:!it;::l:r,iFl'{r{r'Fj

,rfl:'r iii;;r;iir.r.'
ii
\ ai1'rr,, DulRtt i),ii
iigr;i .,, ri:lrr:irji .lii; t:Fr);1r.'tq,r l"iohrFnn rrqt * t
,]qt rri:]1 w rr{f\z r6}s : -}i} Ift{ q{ qd'if't 'J nl',}z tffri

-ts

r';. B/-

,,11,;
irFF il41 ,iii ;1.{1 Rlil il.TrO e ftn ti izifi .rc

oigjff

Lllit rtllJc (,'tttrRDerr,""rfo) qft.rrr al qr') qn'liqlt{r

;t!) 'iEI'.rri) |;r.r-l ,ii i:)) r1Nr;q .{}q1fi}criil-,1i
;',-n1r);nf 4;1ftufr;

k+s,

ii:rr;t{ur i}i
:1f; rtiii 'r i15)? ir\

1).

--.,-..
. lr.i il tliill E;i 3iiilrtatri {l!,

ggr llriF.r ilrri lr'.,n t irl] r;f,fq1 6) , J

c!-,

r.rir,rr }-trq:jji$,llsr
lF
' ' l ( 1 1 , r ; ' ( r .c , r q l

4t ,flr1.:i,.j 4,.t|nlrrl i;,'i i.i-) ' r F {

Jldxtt I

'lrcrioi

ii) ri..'f ii
r1]r, q{h( 'fl|lt E dtr
il,tl rjfi-i
ii ..,r.1r..lttr[irr'l
',ipirr,!);1i {i4'T ,l tFruit ii I ./no.r.20!5 i\ :-l; I .tl
I
"ttd

G#fil*

11.

ir)")z.r.r llrilF.a ii 4Tl ii 3fat,I t r ];ir lli;?fli,lii,tt I
''11i!1
'ivjr rif,.it iilt (rr,r;,illitL]qtiit,l,lr
261r1r;;1r':1
{IBm]ffi
rp11Jir';,11I fi: t'i) ;ii'd +i D;::ii
irrziR;rr) ') irrrar ii'li I qt) .

'llliTn i.JIl '116o,' ltw dFl
.tllrlrfqn ,rli ai 3i?tl

:1!]1;r;f,i,';riiill []r1i ;111Pj)r11
1 2 ?rfl rrl:,., r;'j :tnijif , l:'l ,l1l{r.rr-l:rtrQ.,n, ";i'1ftftrl

'

ti),.rlr ,:i flnri?{raF}*;*^rrir,is.-.ia1ilffirari;mi

lRv iil 1t 'rr''

ir I l siD rri(i{.rt,'l

<!-- page 15 -->

+jhl+-l+Qr-,-nl

ft'rhl;ti r) rlirrqrri;i;t;l) .ri,flr Crfrirllrr
al :l,IRi
ri) +ii .ri;,liI
",-i
/ : :

f

l

r

,1' ,:" ,?yQe;r.,c.=ft
7ll 7_rpa.
i i*,li;11 .
?-i" ,

''rrrr f:liia,f"'irt.'rRv

w jr.''n ftta siFr-i?i) ris,n : q{

,t lnro ftDin iiftd) ,rlrq1qj ;flrn
2oo4-zaas
al

..

pltlrrli irt q'{qrkzooa'lhllni.
** *:flrT#
$8' : ;.rft)Q,r,r
'r',r)Dc

f 1
L:

.

ili 'r?zjr,r?50otiit,r.')
.

,

p) 'l) - \ r , , ,
qrqr
<
e{(liFlfl
y,,
.64{?q
,,)1 . t
,r!\ ']. i t {
d l;ll
|rgfl
fipfit
jid

lllrl) 'rkli (o qj)
m o5)garl al rqi.'r tf,i cr:.)rn Fpfrrlirqr
, 'tfl dr itr !^+Rrrrii ftfifu ii-.*<ft,rRrr
g+ dl"rn+:)
Sani an .

5o maK!-r-G]dtL;
$i;
o., ' , n
F:

* : r .l. i n ' n , n,rnfiqIEEFi. ]rrslz eng,droit .r erciif yr6{

1 :
r
-

,

4 voorlln DsriRirril. ai..fl 'rrro F+FJo
fi,h,ft qf*n ,r.{lrn
szfr ai).tirqnsji ,o oi^,,\,,iro trit gori *f irg'lh n..t,or.i
1' ilj,l r I.,rrnlrrn ri Rn .n +ya tz

.$I,Ft o1vr

.
:tj

.,

,t.q

1; " ,"

I:

..,- -i:

Gt;
I

.
' I

' ','
'

!*

5a,-r),) r) :r )lna-n,Irai)uiJ) g.lFr=ri
.r,)o)v)

.-.,
j:

^
F*

,l

.g a.
i
l^Foql*qr .
{al

wrll) I F{}n-c,n
d.ffi

tq.q_,i)
ilft ,n

r),0 ;i't fooditcnx / bcvcragcs
,[r l]n;qqmf]r] ,rin-r,r'q,fd
fu.m{ illf,i,F6i3,far a1,r-rPr
tr. 10ijr{r ro r} r wu rrr.rw q& ,

,ni ir) ,tldat,] $rt rori ?ii'l:F,rr]o1orJ,rl?r i---o
#nri
"r,rr
. . - ,r.l {, , . - ) . i
t:(1

: iFr'lI

'rs ,rr,:ir
q,i llri Tnr-t)-i1 ,,]{ Tro,r qsr,Fr
lll;firliir[ ,rrQrr
,,,

,

G,

(..

,\\..c!

..^,

..

;n(tninimumguarantceqiJantity)rdt.dr,f}t

.t

<!-- page 16 -->

l(

r w

liFFtr iF-3n?F
Srnri ?jl iili,\r.l

ftrfl -r'nqftr.t;l3tQ]ci
;rrri Fr,n rllqr (qagr,ailb5qzbmt il rre

'?..ft
rltqr srcrr.'i qfod o1 w rf} t ) ,r')- z.s ' :
F.FFr),ltda'?b1n ;F:
-"
\"

.-' ll
',,.r41q
i),r ':i rr,tdgor=rsrdl?rr.r'r)dt
i n] vrn] .pi1'1q1'qr6.n,

' + :

7 ,rr- fitl

ph r) riFr.l ,)ir cr-Etn'ri-D tr'1 i;r' z1 q,rFl
t iT

{dF

:

hFi,r fit.)vli'ltiv qr rl)2.'r) r"..fg_$:{lit
X,r,"ffer d iiffi
vn;n flrlhl ;r.r qlft,r ii-ln{ 'ran m srnnfld
i

-

'"

'

"'-rl'J.

rifrR qq enr.rTfl IJ.o- : ?ft{i lri &.mffigrlpJgl9$t..

€Alf;tltrsl}.{dFk,:tffiil.4r

ftufq ffdn rTqr|1

<!-- page 17 -->

20.)nr,rDiilt FI.i|{)
rnv n.,ft.-.,r, .r.,1}J
r', r,t

'

[.4jtrd.i

z,

illr

\

a-l*un-'T'
'ii,- ..:, "
nff.'-ar'!
rB"u,1Lq.T 7;'d],.,#
l-1'"rr e'rrrqrl rrY'FI rilarr3iFtsr
F) qIl;Uur}t6kqn*J)_--f2
i
;
.:;i
'--.
*'.:'w'
fticrl'iRrr
o1*t;;;;
i+.drrrr
,,,"*"6,$;:i'
T
:T
3rf'r|ll'ri
i'
td
'at t'f+.,r
tq'b1tal
"'1'''
4;7 rr,r -d(1

rf'li-i
t''
) t ?iD
?r),T'
",,
rrfSrFLrq,-r
rfll'r'
ci'ifi
o-r *vro.rr ,,
1;,:
|k:: lt.
:..'ir..vir}tr;ll'r,,Iql.}lr-rqIdt'.j).t,;r1wtll}u);il.rc<rr.nr,|{..
'lil .t.l r[ !)zr,.i
d erilln ,i,r ,r,r{,, a f}d.llru;.,r,,r,t
.{rs

3jJn.:r'iri ro\r r qr.n Dffa nrhn qRrr
;''.1na,"*i of_

srrt rtin 4)q :Lqlrdq
3,:rl {sf:I

rrl? f,$rftfufti r) sq?r!-d,ficani qlm .r.6* *Uf**
yr,i zfl rli d ai D'r,, eJ?r
rrrd ftf4?rnirfl.#" \" f,*
ria; ,,1;r'rilt-ra fiF-ttqt lri,l

t

"" .

.

,
i.

<!-- page 18 -->

P,w vhir

200F2006

'I
zoo+-zooi
3tr-tslluilF
0.40
0.30
ii ..,
il: ir'

<!-- page 19 -->

/ 6i;4 ,--

",

ra ---\-/

" "'t iTitttE F17
*n, an
,

<!-- page 20 -->

drvr
XT{d q-qtr{d R}a ei+ cr35nwQ
r6qil
/
'

;Inl it1 iFii) I

:
'11,1{
4t zn.F3il:;nurRq)
tr Ti}d

Tft4,6I
I

,/

x

ftr -"/
\

-

<!-- page 21 -->

YFnA*r (,,/ ,/.J_i,q :

vzrtll rr+rn ,t,1cTd.Tr
trci r) orr.mltcm)r
e. qftFi $ h-t qT7s{'fu-d} ,n)
crcff.1flq4 'r1f+irir)ir-r
EK€2r zB ftiC AFt-dTt6i. o i]akr
ftFrl

lPrDiri fuqr wi I
natl i

vhl rn.r Fl

/

rrff:rn

,, arngt

"nl

Tl
|r1 dQ Jl
qqrfiTTii{
_: , 'fri;]
cFjr.rr
j\5r,r qqrfiT
r|r.q {F
,t,,1lt
Tia{I rlT.q
C.i. ar,Jni ?i 1r* ti
c.i.
{tr rr''_\
'rirrr
.
i] .Jr'1rlwl) lin)
"rr G t r
J ^ | 9 ' . | | / .

rb fti\ 611y7 Fr{r,i;
i,,f'n i;;| q;pir;;1.'1
,
il,,:

: i , '-) {yftl'i

f}rs ;1i11 eltRril si u,irii Rrq

ta

<!-- page 22 -->

' (?tu
\=-.'

' 3ntt'ar0tir).rr,rqmi

YIRFI TIfFq

fdnt (wna) f?'rni

\.]
:

1 l

: ^:.

!

<!-- page 23 -->

G o ! c r n , 1 1 11no f I { r j : l s t f i a n
.-.
l ' l n l t ) c c ( l l c Y c Jut c ) D c p l r l n r e n
t

.r{

Jaipur,Darcd:.25.2.2005

ft

i,'

t r l t l c n n r l r c t a i l - o f fl i c c r r s c s
:

.i

, I : r n r d i r c c l c rtlo s : ] yl h i r ti i ) r I l ) i c j s cs c l t l r n ) c nf to l . t h cy c a t . 2 0 0 5 - 0j l6
h a s l.J . e pdns. c i d c (tlo g i v c r c l a i l , o f l . ' l i c j c n s c s
f o r s a J co f I M F L a r r cB
l ccr.ol
s l t q g , b i s i sl .t l n s r l r o b c ^ r r J c c i , l c:Jb ; i ! c . l i c c n s e
f o v h o l cs a i co f I N t F t
'
l
l
i
c
an{31}ecr.
f i r s r N t T .n. r. .r ,v b c . s s r r c ri.nl t l r i s r c g a i d b y
Ercisc
-i,
L o r n n l s s l o i t (iTl t J c ; u tl 0 t h y s b c l o r ct h c r l a t c
f i x g d i r r r h e n o l i c ef o r t h c
rcciipt oflcndcrslbr rctajlanclrvholcsalcjjcensc
of IM.[L/Becr.
l r s l r l c r u n t a p p l l c l l l o r ) : l fl cl o l r c c c i y c dw i t h i n t h i sp c r i o < J
t h c l l[ , r c r s c

Lrit Irfuil

+,+
;.1'

;

Sccrctrry,
Finlncc(llcvcnLrc)

<!-- page 24 -->

tMlQtl Trinrn
[i;rr i]r,r
(.rJr,r(jt
{r 3r'fi).t
,Tr.,rJ04(li

i r i; ,
fild,i,-:

l,.,\,/

eu\

/

4w.l

Oq?.ffind:zs.z.zdos

:

-$. f+trn

fdw : q,{ 2es5-e6aj} 3{rc,a0

tq ri? rirrq {ld

.1 r
'rq.t {i'i6J
!,<', .,ri.r
trfi
,,,,a1'l.-.{F?t
+-'..f."ririii, q \ . .
;rrr-,
r
j, 1 ( ) n
{aJ_,Ti
ariiftn
{ a J T(17
( t ? rft-{a

Tli nnr ar 10
'i;'i"*
riitrc,4o;4
itxir r,o !rf,r:r.r is ,TRil) +' gflfim
.
C.rrFtrI
Fltqlji)inri
Flilslft,fir'
rr,
;n
vfu.
zo qfrlstii o_*r
arfTrilr,)=rfi
.,*, .,fo# *r ;]i I
"Or.

$fwi qr
*Tl5'-:^lltT,'ryr
'riircor toJ*'o'u'e'-i'
:i

j?ffii,. ?h)at-.izn a"- .,"-- -

,'iqei-s
.'
rr{ 'I?Rsrcr+l
!!a'r\r{,n
<r|a
=r.ncTfs6r
tus1
v+ri
r'Td}/'rni
r,rd),,rr.r.i
.: Tlf't't*

fuhn qRn ^cojry* a'girt

* S'T-Y;X,]*:-Ys-:g "ui';"#"4';i"t"k1;'l

I v'r.re'\' q'r rq<rr\4r'rJrr
I
"' TI'rq
F fu +,n 'rR-<r.4 ftfr)r,) w,rFrtI iltr']
ffieffidEfu@q-fl")*ilf.)
i:ErrJ,_,,;-- ^-.

1.[ *rfl 'if]n d rr1arur{ivit cnhr (arvaxl)t } ra' an .,n,., fiifu foiilt
'trfe?r/
,n a1pr-ii -i r.n.ror ftolqar.\ .,rq,;
nn n,, .,,inlh':#"
,
,l
+l
i:rrr hDe;-m:r ri r4i .1er.,r
q.s r) rlli)r; rp5) ,F ft(
:rfr,1 Frtr<rir,rr
rrDiira Al);:r fioilt bj(t)w.3azOor {riF,firrcfd
ff f+aia,,.._,rt,nr
gn ,-t
3llriiti ,,-l,I{ rlrl r;) l}( \.r ftf.t1
"n,i
bid
fi-rr
g.cu,1,,.;
rrrrrltiPlc
^r
t rrori ;r.
^(oll:
r\imL{d lrfi)rlirr
rnfil,.ti,ro- ftrc if,riftd
rm8n.rrf}r.,i
"-E*'o.*a ,n* n<
3irrtl:rmrfii.rillr ,rr 61i .,a n,r,,, ,.

:y|n,l)fft
1l 3rirr6Er)

r nlr or)ft^vrro
r!,nor.r,rv.r,F+r"h
Tl nl,+.*
(;r
ol q0 ii-n

f^r,Fl
rg$sslEatR-ailsiy'r,Lr
ir

$aRara
t Wa${l]eqmftFYmfuf,lfrcr

a;:jr)r; ,;iii; a;i

<!-- page 25 -->

',::'1,;iiH
.,,,,- ;r;.i',,,
,.q1
s1,f
;m$,';l;:(;l,ll,,;,,
ft/* nwi'))

oul ti :)00

got B 15oo

_#,##--

250
280
350
s00

rir

l.r f.)izn qpn

<!-- page 26 -->

TuqrouYo.ri

tOm'fun'r

(omor0
er?n'r)

uRItft ra-\.r/(r,:26.22005

--!

qLr 2005_06 -\q)

' tntr't, q;.)r+

'

F.fatftrun<)ft)'n'r

<!-- page 27 -->

t

.

i,
,i

It0'tI Ls.! Itt:sl,\ull.1NIltiq
Stnrllotcls(Rt.in l,llc)
.(Al5 Srdr

5,00
.t,00
i.00

5 00 h.r
1 . 0 0h c s
1.00 lics

l,t0

l l i t l / l l c c . R c l i i l t " i ! c D s cf c c

iln,l0.7J
hc

n -,'Jri",gc
.0 r'

2.J0

(lts. ,i'l-i(,)

lj|iulfi-in

llvnrsctl,,ta'0ts.i" t.,,.1

Ri'.-'i,rl t"

,Crr D

"r

rlk r li,rhcrli\g;Iotclt

5.{J0
t.50
0.75

R i . 0 . 7 5l i c
l l \ 0 . 5 0l a c

licrior
on lNll'L
Surchsrg'r
on uccr
Surchnrgc

CSD
'.'
....
{Sc
.

iccs
-,

---

L;c,Fca

i 0 j i , o f r l l J n u l p f i s co a h o l c l ' ) f t . <

t$%,rEt)

iolt ot 'n",uplcc.r

l r , ' tr d l l L r l L h i n 2 5 1 " ( , i E D

l)olcl/IcstrrrrinU
Pubbut nol
ofeD
?5%
thrr
l$e

I

i

-\vholirlc

?i% ol LD

:

.^

;;::"^

|

.]!

I

t,."
iv.s.*:o.oo.*.r',iu.
; .,
o ol5,,,.ir

i.:

O,hrlrs
( 1 ' o r \ I L : c s .c
-l'c,n'iLi-.c

I

.)'f ir;(.

i

i: ,
il,;'lli

I

. : ; ! t u | :g: .

ii lf,lil,
](u1\1
l)c.r

,,,, ii
'-_

I
'

. 1i .

j( -l'ti - l l v r J r)
llil l,,t Llcrr

I

i":"\ , , . . , 1f".. l J .

-

,,,.idli;,..,

i

-

I

x..:s.oltr_

.i

:r..,r,,a
-4",
.,

:is.).)s/l,t
t',.::.

I
|
]

I's.i.0.1.

:'''

irr-5o/Lrl.
(=17'5nlL).
l!'rnil E I)'

i

i . . , , : i , : l ; ; : ,ri , , , r _ _i _ - r * - r i . ; r t I -

<!-- page 28 -->

&n.lir"
1.0/BL

Rr.

?.0/BL
--_. --_!'.ls4r.

r.rer,.

.Rr.
(r.
J004.D;i
J:9:

. /ir. J.o/t_rL

t i,l

*:\i.!0.4]t-

I r.i

.t.,

0

.3 t-- - _.!

<!-- page 29 -->

-,T;;i';;
I

'i dinl

I

n'.s.ornr.
Rl t.0

rlirionCl.rocs

R5.1.0/Dt. -

1.0/Dt{.5/0L

i:':t:
: :

:i

',.':

<!-- page 30 -->

;s{+--

T;lir-{Fl Tfrchl{

ft,sl fi',Tr'i

rqtl't)
(lrr,r,r,r0
i;I'0rll firo: q-3-zool
,;'1tiifum/artt./zaot

t , - +f :cos-oo arr++;l'lG qa ttrq 'lii?

i i , i , l - {{

fdrlrt s} .rr R-irc n.2.2005,252.2casfq 262 2005i
j _ - (Nt . n t

.-;

-' ,r r t

iq
rt-1i'i;rgnnfrfu{Rfif,1,re] ,i ;aq l- s,l 2005*06
'
,ftftlii l.r ' rilirt't fiEr),t;) ?:1'q ?t' firt) ir{-ir.ti ,ttlt zo tltg 91}q'l i qarlrr rz
)<l ';t .
l
'.qll"i;th.r q a',r 11,i t
';i\ arJr)-<r rlt€ ro
qlilrt] 1] Ter'6?
ft*&a&r : Rt.lir$q
"lrtr+.

'nn B:F+olnrn r) Ffiq'r
g+rr<-ieFfO
r cr,nltd
15:6lti
6rl
100.lref ' C,?.tfr
1ooairtr ulr ?- g.i 1soGrc'I

il.'ro.cftls'i I i,'r

r ; o a m d t . K q : \ ]i l ' l { d

crfto

3 . r. sqt

,l) 'li

e"i,1i
?l)

<!-- page 31 -->

.'rlflR d;n'r;l) ,,,,-ii:

.,ffi

(fit:rn l:lrir,n{ .,rJl).rnn.lt
.i,i}.1i,m,r
;r)"rr
"a )g

ti.,.rr

Ih:lue3l,l i,jlfOitit

tntr.l1ryr_g'l-{itnq,,

cr*vr)
ri] inr

16){gon. rvrir<R-a o1 cirdl
^ir;nrl
d
-.11r.
r111y
: y,{f6j,[fI

str{en ,fi erpi

*l

!l 1

ou

l-.m&r)

rfi zi arl i...,n F)r'r

t;1P5.1 1'16il Ti I 0 qhlrrd l-,ltil i2lt 1o

ar.tI
q,',ti
mr lrtcri+l) q f 1 0 r1?rrir

9ftrro ;il rrr.-i-ri)
rrr ro cRprar
ern)i.t
l
il,I

it)

nTrr i,

atiE
20.3.2005rTiF llr,i
6
..:

rl) riRtq irdftl zoz.zoor
..a \ ' , .,i ' r - , r ,
{TGJ'-rrri.;irJ
\ , \ ' , , 1 | :.r
nl

<!-- page 32 -->

{lvi{ql ' {li'bi{
/.,-,-, , (, ^,-..., ,i

pll';al1l
ri'irll'lJ
qo-l(tz)[ d . u
7 u r a7 : o a a

"fqg-{. ft'ri.6 : 25 2.2005

'fuirr

fdw : ir,l zgo5-oed qrrnOfiEi ru rirlr {lt

E.fl r{nr

S qf, 'FrIitF qoa(l7)fuftT
/ 3tt4/zoo't ktta

tri 'r.r ii.,"r +fu d i( D3 l\"ryrn

p2.zms

t '-

d

-

-

m'r ;i a,l

trf) 'rlin.,i vd (reoC'r\'6),sd F75 ({(ii) .ren-4lip (750Vrq.r) w crli}ir-o,r
cf<rt.lai ;F,pr:Foftfl,1-. 60fry-lF ir $o6oo.t- yfl .fi ri' t irfi 'rllirr -ai)

iFl,rrt 't fr" 1 ,r.nG::T,E
qR;r.ir .r,-l f,I;qlnnln r
ir.6?ft,1J

?:1) 'rfil.r rt',\tJ,1,'un-Ji''i a.i-ffi nrE1ln(rr lrftvra *r,t np1rqr i0 q6lv?T.rfr,<
?rqj ro r['i-.ri] io ' 'rJi) d :rfttn;n (ififl l?']qtf.'f,r,Tt,Rr.or 20 yh:in l-e
npl/ r ir..{'}-rl :,ra'r -r} cnil ifl niii r
'3.

Xd,a ,i l?1 irc.qr: (r-;i,ria rh;-or)') edlu qr l*' r1h ;rriqrnci-6t
c,r:fi7a;a'1
:J !rG.
'rei
qrrr.;t
r rR "TT{icqT
s0.0oo.tir
hl+d
t.
fuhfl'lFin c?i,fiq{o1 q"ir
-5TEli o)
ili iFr r2r'r ;rllon w {r'fe d *l qR-,ird 3rfirrr o} ftqt qRIrTr
I
.{-{I:t{ trft ,rft-rr;rl fifnir.') rn itro rm,} fl'rq tEfiftqrffdERbitrS6-ri}"d.i-t

al D;r,:q ,rhl 'rrn ar t

p

3r.l ('tt) rif).4 * :r1.:r'rr,1)ri .rn|.1 ( v;rr,t) t-) ;A rnc .mii f:if'td D;i?f)
4l-,t../il\,n ;115,ra.iia\ tcn-rol Flolqrr,,r.),\ ro ff,'r ir,r .lrr,r ltqr ;ni,n I
tll'll 'ril,r .r; DJ)<tinrr r;r,r hn.:l !,.r:t), \4rrJtefflq.it {l .3rli,rjrr'1s).n l,lf
rtDtftia ftii).:l 0oi,)r tr;(i) nri31a?
"rr rr,li,fi JcrLt J'Jl AniiF:ltj.nr*-i'}. (-,r r)
',-fiirr
otli;r;
irTri ,r] li'r\j r..r fiFIa (onc bic.lfor rnrrtrrplc1{Iorrr)\)I {r$it i
ftroi {ri rrl,irftr,rtpft l,n'i,} fnq'ft'rltlir 3rRlh-d.irflr
,ri
t.nl rt
"rj-einr'v*tq}
3irr'l)q{ilji,t {lll ,r '.rrriii.an rr:r,i)il I

rnrd hliicr fi){rfi 'r[,hr nsu ilh'{ ./;} qu) i:i! f,);vrtfl ri),n ,u .r'nqrflor :)r (r;t)'
.ll crlir.fi E'r)* r, fir'fr ,1) ,1{lrra ilr,ilinr,ri (Elifrglff.-qgffiHi'?Fl

sEi.lkg@f ntl?airditr'r'rr i r

.: r. }fL

<!-- page 33 -->

Tmt r-ll'l.r I'r.)t)iriir,ri :;rrr;rfilri.r; i.0// - it'j,l il cr,0/ - .r, .} cL)
F.r,l i.,;

rt.r[l;ii l i:riri;tr,tLr
wi qi ilr,t:[i{ 6trtl

l:lrrldt t'r{]
n $T{d
E)lq-d q.{

nFq

(r{i} .}v)
401 {t 600

210

oori soo

2s0

sort rsoo

280

1 5 0 1 3CCC

350
500

illzn q-r'r.t{Fg2lz*piil a;r .ftet aj,'r.r r} rri,}ltaor}< diii sqio o} orin

..e.

,

Td ii la:t=e ,m ,i ftr a.1;o,r z,l ulqr ro ars sw) sfrto rel ,Rll ?.r I En
I
ro rFtrs nrF) ) t in .rr),qit silTr's
?
t;.rr) Ff,qr.,Tqr?rTI q6 s,fi n6n ii
hzlfti ffia.l $;) ;n{ r}n.f},n vn iFfi"irur
i
i -.rrqr "fl aFt *'n r qR fi;1[tqp ,p)
I '. , q{r2ool=d5cfarfiio R-'rrrqr t 3itl imrFr ca q}q e{ ri",n s ars .lrr} l{) B di
{r$Tn .r*?9g*o€*ddrt@h@il1l
{
6qfl 4R ?; l.rq nprrJll -rgdr 6rn) dl rirlr zo a? rrir npr6i ,i! fiq q*n
1,,
,
o-,,R]qi) rr.cir:rsrw,lt'r{ t i rt- qatcn rr'f} r}cd d jirq ar'1 r.!,ftai* l=i
ft,i n

i

il ar..i+ir
mnit#,r nr'd i

Q.

'rrd l:'Fhr f-.)r)
rfl qfqn 1-,iA{r +1
EFn) ,r,-:rrip c? 3rpi.}d .FTArprq li6r.i .
rFRqii:r4t r):,- 'rFr --Irl) t
*ll sRFl?-'rrit< :ir,1 aen *{lil)ir il ,iml flFs,a i^=:...;
rrlir -q,i iiln ,rl) qnr ,-pa;p)o1 arf,lirr qtri ri,jpftq
Xrar;rr) w dl --ri er-,.lnilr

I t

: i

onfltr{ {ffi r,iF
!-d,fi\'.r

glii

n

.',

hnt il?r),))

r 00. ?i-at

:oort) r;F

F
:.;

-

.

ffii'r.'
13.

.a;j il

tlarta :ryrrrrQrr)o;) ,l g+^q,ld-rn+ ,3r) ir,l d ft( r.i}fiT,?"r
\
'rur,ll.hnrq p1.6p1 j,),rr1

,--nulfu'rraf
.

qq1

.li

lrinn 3:r.1

i

:.{
rrirr-<)<r
qFr-c)sr
,ih,.r
,ih,r
1a.
14.
'ii
,r! t tr yz- '
i Bn
Frq&fi
J,r)r,rf *fl"i#
*p"ftifirotr
ai6m.nr{
\r/
$
"l
W':i)lit rr) ,,lrt ,r.r.);rj lirq crrfr,/ Dr,i,lt,/3|t,).-ii
prrft ,i ;il r,r,)rn hr,u orr-n
"-6)
'.,nri'prnmit
q.ri}
f.':rq
llfi)?lir.lilr),/-,n'1i)
ayiri.r
# a,r',rrlr
ilff|nr,r

+.,j
i

I

smr,ttfi q ,i-,ar,tii,ri'l 26 r 2s,65,1o .14 -r;ir iIiFJI 1.rJ tr{n,l{ ;rj} ij.,-,1.r,} qrr)
t

ll

Or .."
\

-'sr

/,,'.

.,-'

\ifc+la-1us(thR]"i) .

rln rr lfil-q

h,rt (-.r.nrr)F,l.rrr
I

I

<!-- page 34 -->

iMiEr.I TIrfIi
clif, T,llipl

'

(3na-or0
eq',n'r)

i
u,'|.1, o4\17)ltiit/ ltn / 2oo4
'1;

nrE-{, ft,IiF , 26.2.2995

3mIn.
3rr,.fftfl ft'InlT
(]nReiH
v.iTg?:,

ftqq : q4 zooroo ,fi3rlGrm'Flg_qiljmqje

rnrr.rrrftm
F}nr(tr,;n-<)
FFn'r

''.

<!-- page 35 -->

/;v
\:4,-./

' r\ '; l.j-"--:?
| )raYj jil;;
._ . .2,:.<!i!',.:

iilliiilitli;" t"r
(^)'sru
(ut)-.rsru
lLr.J rLu
!91'l 1",,-.-,.
Itotclt

I
I|

iDiorhcr

r

tlll":
.1,00lrcs
;; i;._

1.oo I
199 I
1.00
I

t,sc

""iili
2.50
5.00
t.50
0.1t

.Cal. A
-C!r D
.Crl C

-

.!r-.

rLc
| ,...; r,r.....
a.,,irr-i(cisc
ltjlirlllr'crRcL"r.r'r

I orrr"r'!eirr'o'rr''{

Ji..:.:iiiT"

-uu

'l*'gc ur

r ! h r l i , r l ) c r i h g cl r o l c r t

ii;i*66;fi;*ir.-'t"o-o-'"'t'

orit'. oi"'';o""tt1"
i'ii'i,'rs
rcr
' r '"1'"",:"
Ilarn,l Ah!

l'vrt in'l l "

Cl!!s I'ccs

S-chtrgt on Ii\11'l'
.urcb:rrgcon Llccr

2.1

' -

R\ 0.7:,lrc

--ii:ir''d.-,

0.n0

25%ol El)
J0%of UD

iui, ifrrinJ'pricc of hor:l
t,,rt|('t ltsr r)*r41lijj!-fi"i-u*'. priccor
llol
[orrl/r€lilxrrtlny'PUbbll
l$s rl,i l5% ofEI)

CSD (Stn:i($
L;c.Fcc

i

O r h c tl : f c s
(, Oi wholcsrr'

ii5.0.25/llL
.
'.,':)
l
i,.s. .t0/lll.-

(l) (), ll'rrrrl

.:.(i'Ul-

l ( U i \ 1 . !I ' " l i l ,

:j,_0/lli-

R( 2J-0/llL
ll i. J.O/llli

i0il-lt.

N;.Jo/Lft.
(=l7.5nlL)

(=.r7.i/l)1.)

D.D.
N,',rnal

,1.
t l

-

<!-- page 36 -->

t.iljcl

ta..i

I

i
.3.6

--=-=,

liorrt;,,:;
fc;m1

*r

-Ori1

trlo,a'rci.---Ari'rgins-;n
J:cc

i

;:1

?.o/Bt.
3.olBt.
__.-i

!
t

t

RVENA._
-0.inr;rs.i,

:

-Trrn<tr rcc

i:cc

4.i/ lll
2.0/DL

I
L_

n\111,

l.o/tll

!!tl!,,':::9 jlrrr Dir f(.c

'r

J.l
J,2

,i,

:- rr #r.

s

fT

.r,j
t-6...

-Scndi'1;-d,'
Fcc

.

?

-t.J
.t.6

!' , , , 5
LiE

: r

i.7

-!:dTEl-

0.?J
Q.60Nr

----:l;i-l--

i.0
0.i0

l'.

R5.I 00/0L
_-:::

llj,p'-

-

1

O:J

[6il*;----='---..-.-.--"_-Lrwt

II
bbcl
-nrgisl,

0..|l

-llcncrvr
Sortliog

0.0J
0.01

:.0
0.2Sll)c

,,IITL

4',$;rRJ.?.0/01

-(:t.
'

'J.
i6

Ri.J.o/rlL

RS,tiN/\

B'i,igirs

Rr 2.04tL

:t:=

Rs,1.0/BtRr,4 04lL

'.:l]1's:9!tfL.
!!rit]!!_.

0_Jo,rti
t--:---

ni;,

0rv;^" ry
F',
ltrffiH r :

;
l
','''n
'r tc

F
1_

]<cr

-i.0
-t.0

I",

I'l'!l ! r < , o n( 1 , r , . (
I li.rc

,II]-

'r,

0t'

) :

(t

t t-

Ir. <^^,

o.1s-/BL

I

t,,'lnrrr,,*T
Supcrv

rl

;

I

3.{!*9.-r!gourrrs_

J.l
_l.l
-5,1

-.{

,ts r.o/iJL

l

1.50/BL
7 irtlL

A(cr

$$,'

: Ar. J_0/tJL

_____&.r.0/llt-

-

ch;rc

Ar'l

Rstr/errl

?.0
;OIvl t

-.-_

(j. J004r,j,,)jr

,r.0

r.anc[rrc,jrc

,

^5.r.oall

I

-l

.t.j

1 .r,i
TF

'.

-

Rs.2.0/BL

i

,*:t:al,,i

0\,1.,t,n"

l--| 1.8
I .

0 _t-i ,ac
0 . 2 Jl i c

- --

\vs
IVS
i09aof \irs

lz {^

,1,

'

<!-- page 37 -->

Urirtging.in
fcc
vil]c
li\ll:t-,
nLr.
CSrULic. ];cc
Sup<rvision
C!argcs
0o{linc l'cc

n.

i-;
|

's 0/nr.

Rr.i 0/llI

t.0
0.43
r.0/0L

Rs.1.0

Rs.l.o/Br-

3.otDL
{.t3L

J.OIDL
3.o/Bt,

Rr.i.0/lll.

<!-- page 38 -->

G9
ll.ticlFl

TRefl{

1;16lir.nl'
rqn,t)
(ertc.m0
(q;,i ( r,rli)(fl/31K./ 200,1

\]Iqsi.F{to: q-3-2oos

-. \rirgq(t.

,,, eir.Iorol.r tnt.
T,v-T.

.

,"i,

i

i.;,e-

'

:r I
't
. * r '

:'':t

r" .t 1, i. !'
€

lfir&' i

= ,

-{i ?i

{

f.

- tit
- ,T'J:cos. co sr...,l;,} T{ tm {ffq -.\f\

ti,i

. g f i I , F n , rE ) q - l I ' l l l + 1 2 . 2 . 2 0 025
5 ,.2.2AC5\ii 26.2.200s

tjrrrn:-rtrfct
{RFfrr rji ,} O,l ') Al 2965*e636,56,fir5..itt-O
lrrrj
riq'r ,l.)fuii i, r ri:iitFr fibr),t4 i,1.1 .il llir) i rr{'ir'tr qjl'lr 20 als t{fr'qdi qcrim r:
r.
)qfl.;t
o-r,,pi.'to4'i;) .:j I t

furfa{I;r : F t.qi:lhl

z.

-a{}c ti 5 \ t 1 l ratg 30 qn{ qftra,ft} rrr.r,l

fiEl rot{
Uqrq'i tPtCrq, rfi-o
'
gd. qk
1l o4
1oofir€l
g4 150-drcl
roo dRir .lr
"I.

3.'l . i,?fl-rit"i) ltrrtrtt

'

-r+n)qnl ,f).\'r'r.

3.2 .lt;{ a,' gRt'l-o gr,ri'1,.
:
s'1t) <;li ill.\rr., ; r i t " , i {

qilr q) qtr.rl tJ,)r

f:p1lll1'airr{ rn)
nr'+r'i u,t,nrfl li.T; a'l 25 9[ilr'

ttd{ iltt 30 !l}lm i\li);-'l 3ir'FFrQ
.1,ff flrtiil,r 1.1,u',121t
rtt)

\

ll:<',,i'
.t

-

ii

i:

<!-- page 39 -->

aDrl{l

iiEir(rR
ott,1i,)1;"1r)1
a

4r-dl g.,ni) IR

or fl"Ir wl Ir
Iftn E ;flqr ,i'

qi wdLe
{€rrrlTrRd

Senn olzia .fi W,i

{lill.,' I

XTR I ',Fcftlrfl 'lR1r

' 0 ' r h i , r-s-'!

l?tlqr 4){rJa

si) slldYrj;tjiU ;ftl) Viirf) t

fu) er..l'l
/

+
"nril DFi,r 1.rt;t ,ifQvr

,r 'l il)') {rfi d
qil) r'g
td),etr
31ji,t:l (fi

?r
z

) ufl riltlTl

dul

:l

r

7.1

i; qldrRr T,rlT qi io qft)rratiilni daT,10

ls rl')rrr ,rit*i-rJirrr rn irt}ltir

J4,..:
7.2
..'

efl ri arl ,i rrE

-.(
3l2ifit 20 7y ,, (4r .{ .t C
,l/t {ll, riFlli

{ i:r;l:(fi ?lr ro cFdviircrfii : ir

tztr.I
rTr\'oO

ill) ,tittr ai) grn-r)at),rit:r

;hlt rrR-qr

,y2!!3

rfiDro
wfi arri)
r

t?fl ,rii +0Ftrivr r;j)q ;Jr1y;;

1o.3.2oos
it;Firi)
"rnftil t

4-,if,t?,t f.Ftr,E -zo
;,r..r
' - .r- rnn<
"' ' ' ' ,,,,i
I

.rl)rr.$n
.Jr{lozo.z.zoos
.o. ii'dw.vpz1,L' ;1;)

<!-- page 40 -->

Covcrrrlcnt of lll j;rslhan
l ; i n ;nr c c ( l l c v c r r r r c )D t ' p . . t r t n rtc n

Nol'F4(
I 7)IjDiExcisc/04-Pt.

Jaipur,
Datcd:.25.2.2005

Commissioncr,
Ixc,i$c,
Dcprrtnlcnt,
Rajasthan,
Udlipur.
- P r o r . i s i of o
n r G r e t r lo f l " h o l c s l l lcr r d c r n r l r c l r i l - o f f l i c e n s c s
f o r s ; r l co f l l I . l ; l - l l l c c r .

.

I a D r< l i r c c t ctrul s i r _tyh u tf o r E x c i s cs c l l l c n ) c fnot l t h c y c r u2 0 0 5 - 0 6i t
I t : t sb c c r rd c c i d c rtlo g i v c r c l a i l o [ f i i c c n s c sl o r s a l eo l - i r V I l ; Ll r t ! B c c r o l

sholi basis.Ii has;rlio bccnrlccidccilo givc liccnselor rvhoJcsalc of Ml
'jhc
and.tllecr.
first NIT ntay bc issLrcdin this rcgard by Exosc
Cotnnrissit-rrcr ilt lca.rtl0 rlays bcforc thc tlatc fixed it) thc noticc for thc
rccciplof lcndr:rslbr rctailand rvholcsalcliccnseof IMFL/Becr.

lIsufficjcntaprpiication
arcr]otrcccivcd
withinthispcriodthcnExcisc
is. A gcn-di6lili66ffCiff Fr3S ucd
b y E x c i s cC o i r m i s s i < ; rlrbcrrl h i sp u r p o s c .
5

l ni t l rf ul l

(llcvtnuc)
l;ccrct:rry,
Fin:r:rcc

<!-- page 41 -->

Yh'fteI|;I S*F-R

&'RffrtilrT
(orrot$ ergNrm)
oqio : q.a(qa)frd /ofiq / 2oos

R{if

: 27.1.21106

3 9ffi,

3ns6rafd{rr,
trd{srl=I,!-{qgr

s

frqq : srrcdr0d-+ffi sq zooo-ozd #r {l
{€I{q.

ft{€rrgqn dq t 1} s{r+fift d+{R q{ zooo-ozd r{dq t rr-q
sizFTtEr{rEq ftulq ftrn .lrdd 1.

erqfu : 3TF[S 3nq6Tt d+{tr

3.

s'r.z.zoot)
efr+ff I
d+{w sqr$ : qp6 ftffi6 frffi qR-ir/ ffq{ d 3ffiHr *fi qfi{r
d id fr {tr q{ q onn R} .rd fi-cw eiXwngerdr.
yrr6 g6rc /
g-dr+d sT6 eg fid qri qtrFruiqfuqr rmrtl
ti+{€ cb-sr : ffi qfu{ g-drq/ 5-dT-qf
d sW tg 3Tri{r 3nqfifd
6r c?j hr{ft q6rr 7 {6rfl d qTr d f&c cd d sfio $-&q=ti
o1 Rerfrtt .ffi av qrn-deTri-{66r a{rq W{ rorq fuqr qdrn lb
\o qfu o) go rl erFo gon 7 gnr=ild vXs enotr-oq dr.rFn
fiffid f4ffi qfu{r // ffqr R}d 3fiF an q.rftq #ii n qt zoooqori

ai 3rdD g6 sf (ft-qio 1.4.2006q

<!-- page 42 -->

(3refEordfu-c g6rii oi El'-sd{) zoos*oo
d rfr'qd ol .r{ .ft, sc

grrd d 3rysrqTfui
o) q{ zooo-oegortflqr
ft'-cs R-qrqr*nr

ry!. or

Alft cR{r
4.
ffi cRaI gfin / gon w1tlf grcSr : ?{{ zoos-ooil XO ffi
qk{r C6t=iio1 dqr zoooftqfR-c .r{ eft t s{ zooo-ozd ri<'{ {
yfw.rsiiFR i q€ ffq frqr t f6
eHf { qrq riqrqdden r.,frq
etjt i +.n qrfudTqr€ ol {6Tg

ssif {dq'rc ii *iEft'd d TS.
T+'r' / goTii of qrq riqr+aqn Z qrrqqrfuorsrgdR ffi qRtr
'gorii or eir*arrrnorqrorqritq{ zooo-ozd qrqoTt qd-ffi n q{

zfi ga+ n trt nRn d
zoos-oo

q'1{iqr n 6}SCR r€f qn

qr$ t
5.

ffitrp*

s{ffft dr q 4X qF<-tr
or f+aq w q d w + o r f r e i : i f i r S
qR-*ror .idrqw{rw d tq d7 d
flq qqrrffirt 7 *rwrftrot
qrfqn d{qrqr qt t qroft fa
fr.Rtgfurfr 7 eroe+orn
o)
tufr i rrst Ccq{wft fq i qrss 1=1qft-<rat eqtq.ffgi oo,{ff
Ad o1 qft-{rnq lr6i +1srjqfr
I

*fr qfuirg-o.riT
01 srft+,trRr,

ifr{ris sts s qr+orfrg@'o,r

ffi1o1 ;

(r) s{ zoos-ooit trao 6 lqt

gotit dg qrw \rffd fdelq1fuFri
trFr ss w sd { nRfiqtr{r ol
fimB r qr crw di trd
qrqor€l go +t ga er:qf,+oqA . oaoo*s tt s ffiera o1 gtr
oq srq of qq*a tet cRir g-6rd tg E-d Ertr-6trRt rs. ozzo.l-e

ftqfR-d6{i or F"fu fuqrrqr i I

<!-- page 43 -->

(r) s.REqTi furfRd di qrd qrffi6 iTRrnfr6 ddrtq qtq IFi ijfr
qfuT gon 7 gsrr sTd tg fufRd +i qrfr qrdc triqrTdqtaTq{
Aq qiq.orfig"o d w d aq+ +q'd,ff

r

(s)s{ zoos-oo
fr vw't *i ad tvftqfu{rd dlnftasarqs ,F+s
qo frcr d s cfrcrd aff gtr eq crct di srff sE e.4oo$s d@.
frar srq d ga ffi qfuir gmTirfu =f-{dqseril- qrrr *rft |
3Tm6rfr
filrn i qu w.roTdfusq (S fr tr-q +1 sr*d cFir gor;ii
ol M ,/ qsrq d srio.-g\'fiBd iird e) r f?,$ ffi 'iftw gonr 7
fl?T qkn qfi M[ ,/
S6rn d s{6 ig srtr-6vrRrqd q{dc rrcqFnil
sarq d srgcrdt fufRd o1 qri I qfu vrq { raqddi qTd ffi
qR-iTo1 3TMRInr*r +oqfi M qR-nof +fr *. siir:qrin fcqnnr
qr*r q1 ffqfqsr40qff qR-qrd €q.f q or ftrqrqr}t

n**

(+)Iiffi uRrr g6rl // g6rt qT6 d tfu6 dd€q stq 6] qvnr Eq
gon fu fuftro g+*t qRrFIdqr+tq{ s. .tocfr {@ nfi-erat et
t o1 drdfrl
(s)irt tRr w sil{or€rg@ o1 <r w. zoqfr q@ fr* (aoqfi iffi
o1 qkiT iq) eIfr t eirqorQEo o1 w q* rs. 116.67
cfr {s drc{
dfft r
ifuo dr*€s qts q tq sfifo nPr d T{dr : Rrff gofi / gzrn
E{d d ftc furtRdifuo/ddrtq qn'flo1 {fr vRr gort €-4rm{Q Td
3lri{q q? d ftS fi*rtRderalit 3ifu-dftl* ao qqr tntrft c}ff r ftffi
gorr // gorq s{d d fi{ fiqfRd q.rffio'slfrr n e'nR.r6ddrfu qts
a,t rrRr q.r+ d q{Erdds {S {rRr 12 crtlfi qrko fueat i wt$
8.

*q *,ftl
siqiri 1ii qfil'ifr iTRr: ffi qfr{r g6rd d risr{ q q1qio{ qQr,rrs
gorn /. gofi r{T6 o1 qrffi6 qFr d s cFdcrd .qqrqs
dfi r .rr

<!-- page 44 -->

Fsifi

{rRr qrrd Brfiffo-df qfi Eri}6{trRr n sqlq}b_d

6{ d i,rr$Ift

I sFiT 3Tlfffo.-df
o) nRo dTfSHet{ d q_irrivfu T$dr sler
d
sq ii crq o-rqrffd-,ft an ciRq qTfu.6
ffii ft qrTdfu.ddt GT

Fd,ffl
arrier gffi : F. io.ooerq a-o +1 qrffio.
{rtrr +1 gom ,/ gor* d
€XE eg 3tri{{ T@. s. 1uoor_ Tq
,€-S 3rh6 qrFfd {rfu an gon}

9.

tg 3tTnfigco F. 3oo0l- Mfto fuqr qnr *r
10.

11.

orD6-dq\kt qa.dq qq-iTff..6-q
{@ or ftqfuq : q{ zoos_ood ffi
qFn or e{B'6-drqwr 1}a+
ae frqfnd ftt qri or qrqqn ftF_qr
rRlr efi | E-SqerEd rod gq qRiT
oT qrtrq fuou Xer q ft?rfftd

fr;d rn voi or crqqfi-o-rior fufq frqr rrqrtt
ffiqR-iTol3ili(tr,%g

gsd lrrp-l

6 ddqn t+c*n $ qd qMq ffi 61 fipfq lilqr.rqr
B fb zs sft.srd
eIrStrq) {r'q +1 ffi i}ie-d0-q EM +1 qrfi
t, o} trqem grw
.rtnr.rq g.pgfte, d qnqq t era*rurRifi
+t rrqoel ortnqr qrtrn t

C-q6d tg vrq{ern tt"q .irn rw grp lttr

#nS^

tuIfRd<<qtofrsntq d"nr

ft. 6} yfq s{iF|g EM

qrraftfilc fti:ft cFn ,/ ftrr
12. rnra ftFlo ftffi

qR-n ,/ fr+q gorii o1 qqr : qf
zoos_ood FK
fiqfRd {ufioqlr (exclusive)qrrd frffid fr.M qRtr
/ fi{i go.fit !ff
{it*r 2e6sosn qrfi"r H S ffi qRiT o1 2500g6Fit
o} ocifud
g_drrfd sc if rsgd o-{r so-i 6r slqqFrqerrd
{qi or 1i.fu fffin
.
.rqr i I wrd e,rfdftmtrqern {fdr grf{
R-d{ Id o) riqrrhq ircqracii

<!-- page 45 -->

q{ WfEnET(exclusive)ift}q

d-s{ d g_6ri #

o1 GEqft fi

IFft I

13. q{ zoos-oo
(exclusive)
t rrq i frq mjomftq}
o} zooo
Wfsqor
qrEdfiffid fuffi qfuiT / frqi g6r'il d ergomaSed frd r"r e)
s€ srci ergwvae{ zooooz d fuc cfr'4-€i irn rrri or futq
frqr qri | 3rEsrqrrg-g=d{srtg frtn qri srd 3nn{q or q@

ffi-

14.

aaoma fu Tfr-{ erricq d fac fqifR-d.T@ @r so vfrvro +lfq
ilffio etflEo' or o.soqfrcrdf+ffrd ftFsrrrrort r c6 iiR-{d firfu
a-od sr5aurft3{Fnffs{ d ft\ +q ddrts qts o1 srRrqqr tn{6{
eilicc [qd.qg o-€ t. iS g_6r+d lic r] ict t 3ilnct ofl-il]d
oq s* zoos-ooi clqqrg'Ti q+er d erJsc afrJflqakd qd ol
orffi of qdl
ffgd iiffia iaffi qRrr 7 ftqs R}d gorn d eroror*iqr'ftqTqrcqi,
cfsre 3rq dsd+r q ercFR:rd{ q \'fi ftqtRd rbr no t6 g-oFit
01 3r5qfrfr * .T{ S ftrc w d-{d ff-c qrg-qSqr a t-g1e. fi5o
qtr{r o1 S M d}ft t r t-S eiTgnaRqr
d ,.n q{ zooe-ozd f}g
sgsrrt rfi-ffd{ur or frerq f{fl qd defi sr$ rfi rfffiotot

eil}{i

d ftc lirrtRdg.o or 50qfrerofuqriild r
ig rfir 3rTaet
rrrrofrfitd frirft qkir 7 fiqt w encorftS@ qi st qerr+d
{d "rd
oTfrolqfuqr.rqrt I
qi{d fiffid idffi qR:{r7 ffw on efo erg*urRdto} er1fdig rrw
d trqcernrrq iqtdq fi+rnft. or.rec fu-qrmtr qltsTerW ftrq
gm €:) fr ftfa e6*urM of 3il{tr 6{ sri opngsd sd*nrq
ffi qffit o) qrro fqFlaftffi qRtr 7 fior v)a:rgarv.af+i uri
o1 q+en ol sqrq 6G rnrIiltq fuqr.mr Btgs rwrft-dcMq d
qst+sq adqrqt eno era*rurM ol eq qErcFds|dqrffi{ o1 r'ae q

<!-- page 46 -->

qiq qFd{roerftR-fi BnqorQg@ dTrt qri or Fr"fq fuqr.r+t

tl

3lfrR-ff 3tT{.Flftgco Ex-distilleryprice, CST andExport Fee,Excise

DutydeT
Actual
CostReimbursod
d Ea cRT
c{ fuqtw+qTt
_-qfu- *sr fr€

\ , / -

"r-i;

/

srnkd {rRTor frqfror : qiiT - clETqrsd.g-6rn al q{ zoos-ooot

crwrrRri r*r cft{rd ol gk or q{ zooo-oz
d fuq orrfr-dttRr gs
{rd d f+fRd iff qrn fu fars '.fisW o1q{ zooo-oz
d ern|Fo-nRr
s{r q{F aff q{ zoos-oo1 srnfudqRr d rzs cfrvrde erfusrS
dfir
18. 1TTEi
dl \r|ql s fi-{w qff cfu-ql: q;q of qrq q dsr +R gqrr+
ot q{ zoos-oen d-<t{wss vgdi d EsTretrdsnfdi t rz vadi ;i
d-sr +€ d td anfl rff sFqfud a) qt $r)
!Fr:f6ni d EM
"Tqtc
drcoor r4rsq ord e)r q{ zooo-ozd ft{ ftq cMc oqi or fi"fq

fuqr.rqri :qrq d erfiq ssr+c e}r E fura d'€r fw d rz ei6 emflrqt
sTd*Td tg red arq n oi$ ftfr'sr 3Tr.iB-d
r€l afi qrtfi r
(i)

Iffi-

(it trq d Qqfui n erufqwi Wo oq € dsr *w ot sqo
*fr t v+ frroi d ftC dst qtfi ui,rvXod si fi swd fifrqr<rdr
6ln sqd quxSsr dw s-srcc e}ad tz HXEifrt ffi
gs ron +1
qr+'fi fu d€r fw iqqf, d fr d faffi ',fi eqa ftft-<r<rcrd der
+w Bcrfi *a { W * 3rFfi lr{d or Brjgrc*r€f fur
(iii) gfl ron rz sq+fq eXet nv i2 FsTq=riqd or vom fuqr
er$.nr $q 15 gqfrq eXa Ii;S ff ser<c qTd e.s}sT qi-w r*{k
Tr?il I

<!-- page 47 -->

7

1e. 3rqlq +t dfr 6{i qrd orraonf of dn{rfud 6{i ng dsi d-s o1
6r{d-sTiit sft{ ig a.q {d d cdqrc d rz EsA q.fr fard t. 6}
qadr 15ssd cfa fard)fuqr qror t r
ei-q fifq

rtr

20. *eq Z i-dte ert : d-d qrg .{6t-s d tg .na-coos q6-i ,{rd
dedl d ffu oqst +1 qq-f,q*iwi wgr ig drfl cq er"qen-if iE
q<e fuffta d 'r{ *r{s cndiiqd W ? qoi of crfrirqiTdqHd
t|wrrsiiFN it j}trd t I sFrz163rRoR3T|f,orfr
3rqfr d oFserf,r
i
..rfudiflEfr @ifed qd
or Fplq fuqI.rfi t q{g 116Efttrq-df"Fqr
qd fu crd wq si ffii of S gs non .fi ge 4 uri r
21. tft-q EHt d ftc fiqtR-dqR 3rgslg@n fte ergwnqRa& q;ei
Or ffq fufi rrqrt :6t\cw

Etcct

qrl

Tdqrq q fE$tld dF{ft

(arq s. d)

wrt

glflrCd qrf$r

(ars s. {

q

5.00

fi

'1.50

5.00
1.00

0.75

0.50

fr

{e]FIT{Nul IR qq T€;

22.

t6tr

$is

g6rq

t<'t\

BqfRf,drftis +ts +t zs qFd?ro
d {rR .} +qr<r{*, o) rerot +$
gon of dT{$i{ hts d ro cfrprdd csr+{fti Gili or ffq ftrqr

Ft',fr

r|ql BI
23.
1.

2.

gw ff+w \ti qs - r4qq :
s{ zoos-oo o1 .{ifd q{ zooo-oz ii gw fut
+1 dql a (rr"tli{
R=dtr.R.iTf,r fuqq, TdTfi-iqrifi gq qersr qftff itr{iff) t},ft I

qreo qEredal g{r{di d ct-sqr Hrelwrol qn enofilooG or
rrmr fuqr iilri I

<!-- page 48 -->

qk{ nnTqratlii d E-di q .iE di d qqq o1 o-dro1 t cffi*
?F{t4|frqrdt
4.

5.

qR-{rca 3rq qreo q{rri d B!+r o} ffid.6ri
srd f}arqdi i3TrR
d ft'6d c-dfudFr{ft qEqT+d ergsuaffi
o1 urir
re q{ fr oq qrg 6 {d d ftT qfuir of sffid 6{i ri.irft qFrqn
o1 qrccr sd * oEqrSqii r

qF{r d Ei qrl q{ fu6 qd sr8 nnrerfrqk{ e-fi wreq d fr(
eftorro i'or sdq fuqrorqrqfrtrdf,fuqr qrdr
fr

3rr"roffiri+srtr A q,q*rn:iq crqlTfc/ ufdql 7 q-asr Xf d u,lpo
qerrad-€,iI trrg qs qts qii sTfq d cTit 3rd.rd 3{r*qriilrfr ffi qr
€
+Q I,

E{ frffi o} ar.1oti d lil or*c / ffi
/ 3nQri srjf* ii q}
$yiuq fu-qrqrcr 3rqltrdd s{d ftf qgq-firui 7 eniwl d crsq rftq
or arqoir
srrqdr'fid+qw qQrm+a
fi{i6 zo qrd, zooail6 Wt 6n qaqr {.'s
s{dFRo} iR-aoi r
1iffi

#

Td+q,

a"S-->oq"t
(dfi. T"dI)

vrmcirfua,

ft-d (rrTq)frqFT

<!-- page 49 -->

vqtEri t;t6ry

@

sn@_wr

'=nla: u.+(r)Ritr
/ew/zooa

filqiqri f r"E.euoz

efrgqit
qiffirft ffqFr,

YMis{|{, gqqgY

ftry ,qTriq* C-dq\fr
gd.oor_* $ q{s t
..
f
TIdTflT,
qrqo'r{tqts-{fl qd
fu qro-a;rt
^ Fl^ftrtJtli titE tv p
zooz-i; d W { ooq
fiq A"ftr"fur)'il
$r$'" dri,r
r. srE& ; srFn4 orTq-drfl
' deiv,
-"'"fil at offi qq r{ (ft-q1q
noi qfr etftr
,.n..oort
o} ,r.r..oou

'IffiH
t{ft *lfen

ftT,ffi'*,q$hffi;rTffiimg
/ stuq
1.1" ugrnv {qi:lil ?

ftffi"ffit#Tff;:H%Hs,ffi
e
f
f
i
#mg%ffiH;R_1#_*ffi
ffi#W$xffi##ffT
Cq) F+rd fi fuT : ari*"r,ie.,
:. *-_

^ -

ffi#'ffiffiffif$#wfr*
li

"=''

W,*.,*E ffiHfl*"*T**i#;kHft"

#ffi#

t

/

HbH

<!-- page 50 -->

1.:

3Try$i#;ffi'$ffii
'*"o rc€d{lut

o} *'fr rrs-,='
o
^qrq
.H*'Hgg*i,t*"
m.ri
ruWffiT"fg
a"qo
d$H$iflm"b.#+J#fig
5av*
F*
ffi.q$
il
ffiffiHf,#R$H,flLWS-#*1
g
ffi*HH*#Ss-g*5ff,Rffi'
m a*f,'"rn'i
of or{.rfh
,l't *n',Si;H'J

p€K*s.F6F@l
I

/n\ *._

Tfr:q{ zooo_oz
o1qrfrirfi qpo,*
#];ly:gfltrt
..'.,yor nqRqcfr
::"
frsr

"ffi
p.].
#,
!ffi
Siil
H
{,J,#,plfl
,ui
ryffi
';
dT
rr
"
oo"xtn"ffi*;ffiBrIf,rffi
zooa-ot
doqvr*
s *6;;

g_tmv e*q[:,eu-,r_U

-Fffi ''S,$,
ffiT,,HR

qrnqrtuor/,ir.rsn
r:i+*,r
d
H$tr-T

P{#-'iH
ffi#THWffiJ #ffi'ighry rr,)
qrFro
200a-07

!ilq $, ')

addkrFtn'

^ ETlio'Rtft,U+sStr

,ffi,*sH## H?}ry*Si*ffi6r,0
*'". 'ro}rru##'##,**
(c) rd+{d. Ftsrfl; s{

zooo_ozd

p"T_. ri-qrmq
L31 ftfi" fri){frqft{ a ftot f161
ot rd cnsrrrrfti
Jlui o1wrt ,n qdzooz-oi
"6,n
tU n
j,
-, :lt ftiff flwTftolZoil
n

ffiJT#;i,**ffiH,;)il

,
' #,,ffiHfl"H* *er.o
J
H;i*qg;5i#H#*"#
ffi

Erqycrkrr/.ril{

d ftl
otr-aqq
"
EG t. d
X_.H -"q_*A
_f

I'ltirtd ?ISI{W
sfr,lr em

R#
#+"#ffi#^'--y
zooo-oz
tr-cg-sT+l
fu
+ro,qsffi"#.1i#,*

To$
otera,srrq, qti
.iteqr S r1rwftror
3TD-+;
gqrd *g rnqr.rl

iiH*$,il.i#8ffi'*

,2. a J-)

<!-- page 51 -->

W
(E)$q offd qt fl uri qrd.qRrr
w

,lvflfttrilfrhft;rs:,*^tr
Fcrr'c

rrXqffi Gni ffi.q1,irrui,,11
,,,

lo'ft,* i#o w ftqrrrr\q..
sft c<q #er ftd ori gr FIop1
z
" +l
ffrfl "rqr
qtf.r- afsr+tr
i r
(s) !n'r _ drs, fu d
.rWrnirnqf
a) scifi rrtf{rcrlr,irrrlir
t:oou:9l
^*
ff
-ramovw
os.
eooz--oa
tsg
*g-*lz
5
oi fuqrs ce i

enq
wi o'turq
d_,tur a q,.d*;ffi

ftsfnns( t i-erfiqrraw srnron
jfrffi# ilT
wd
_ffi",l;;,
ti,ra.,H
Bn)ffi q{,ooutor',i.#"i'r+''|fr*
,gv.rho
qf$r*..{e,rq.T

ffiffiff

s. gw'ftav Vrfqq isqq,

s{.aooz-oo
S d* ftud.A *
q{dr q

4
r6rflr,1rfi 6,qq *d"n,@ ftra Rrs. R-trJ-dr
ffiqr. 161{11
'
st gYr{q}al 3hr wr r,rei*q $qrc
+T
an-"fifoovi qr ,-qni ffi#,*
. qfrrr tqrc rard,ld qlri
_ rqiq Elid mfl at o-*rart gl_drrqo-rqrd._
",qt s ofarqrqo.
. qfr\r

*

p*":J,rr.r
mv*m.dqflmfrorrq,p
oryff
.l,rt_*pq
srffi
a
o6ov
aruc#
req{ Ttu"
unH,","
r- .ro
S
uirc
eI
+ c-a} *o qftuo) sft-{Dr
qrnserftllsq6di
Rdi,;"#ffi;Ti*
Ttrcr

,4irroo d
ffi#* H"H#t.'q3.-**
$R#"fil #rt'ql Y-$q fttt
.r,i
-,*i o,,vrqo* o u**

.,*"s
fr#* "#'e:ffi1.ffi##WkH*H
str?n* srFq6'|t{E}qra ur

nrorvof iR" _r+;;

.lErslis

ftTrFzo.n4zooz
@

tuf owqpcrvlis

<!-- page 52 -->

i.l

{4#'
Govcrnmontof .Rajasthnn
Flnnncc(Excise)Deparlment

No.F4(I)FD/Excise/2007

Dotedi 21,;).:Lt}'/
Jaipur,
;

ll r

I

Tho ExciseCommissioner,
Govtrof Rajasthan,
IJDAIPUR.

j

Kindly refet to your letterof 24th February,2006 seekinAccrtain

clarifications regarding Exoisc scttl'ne'i

clarification
is herebyissued:l' *
p#

polioy 2007-og, Tho lill,,rving

Thd rota!numberof 1800excrusive
IMFL/Beershopsallocatecr
tbr
zOoT-08
do not includethe 1l shopsof Bhiwadi.

.|

3"
4.

I!ij, -9. licpnce fees for o;her hotel bars and reslqurant,barsfor
2007-Og
will remainthesameasthisyear.
Yourssincergly,

4I

' (Sanjay
galhotra)
SpecialSecr,ritary
Finance
l

<!-- page 53 -->

r--.\

+*-z

{fGRelJ:I {.r{tr;l?

ft-s frar;

(nrcorfforlqrr)
.?)iJ..-, rl j i , lF4ailz' :.,t:4., 1!t3

1;1-,
ii,1; . 21.12oos

:ilrj.j.,

.rii';;l.i', J.rr;.;

1&

J,ii fr.,i.l. \{c ri.Jq
\-

1.,iqii .qin-4i];lii.itq k{ q,l zooa-os d {rqq d.t

;iY!:i-':i

l.iiri;.j,ri'r ,.'tinii i;t 3ni-qtrftEd:1r1l;nj zcoa-og oi tt+f g -ar*
ri.:l!,. ,;li
1

. t r . Jj i i r ' ; ! . . ; ; . 1r 1 r )! :

3i-{fr : stirtaii .t]13+i{lsdrnird.fi Jlill} \..}, .r,i ffartdr r.+.:zOOa
d
'{1.3.?i,,:, ,1;.
1
rt)rlt I

d'

*k"r: sori.ft..+*.Hrqfqrl r;rr .trefl tiffu fii-+fr 'rfttr opn iflw d
ffi'Rffi*&9*
oi qq :oo8-og d frg c.agpa
Wrrm
.1,1T
r-+l-.')=:^F.rq
H<ai 61 flalq ta qr ;l ur) oift-o {ril cir<rr
i'r{J i1;4;", ; id'il.h-rvl ii c}q i'6+ ard} q+;rd ol q{ eOoz.-oa
d
:lli:.?'i 3rirl?1';iil4i?d i5{ npfr \.orru-*ir'gaer -uf'aE)i 41 ftlfft S
Allr-: z.,c)+tqer e;urerord qfao o'ftfrl t rna effi ftiFraoy

€q;;1 ot,.aer6q;i -cqii forn iflru4f t

isl

J.1

/

g+1,1\+YFi 61 4,t zooe-osg gq-aJ

AV 56-ln ,.' {.hl;t {qre #l q{ zooz*rle
ot

.a1y& ar EFfRd
\-rflr{ o cl-dFkr

&.2

'aJir {i{rqlsr fkat-- d r:*nqn qw rrnfrR

di sir + ffi

.rff{. t.r;i-,i ?d 6o-c

or €

.FI .,9FS nd qur4-+a:r-,rol a-o-s gsn fu;

<!-- page 54 -->

P .I

**
*
f,X'
:f1:::,i-,"fl T:f sg'yT;
f,"%:+f
rt

q5d,$"ll'K:t#;tt#
o,q*,
{@^
irdr;llr,{ll
33
15oo,/- --.' f r. :ri; rfi €.
".;
3flfdrl
:'
,..'
,
arl:ittF*ol
lI rJ .Jr .
. ; ..r4( .. JJ , ,
"j
ft.ir rirm

;, rq 4 *q dl

r

wr*r
r] 'ffsffc
';iii;; ,tr..'ifi a'r
l'.;"i.
;i
fi -'rraa i,[ir'"i"'uo'-''n
+ ,..,
lit;

'-;'*.' l".ri

i+i

i-''j'

.

"

"ll'l\:

_i

+

An,

i:il ?

f<rd
"yn*
-t
I "il;;,lw
;r"ilwil
?o'9t
9L{
*#t*3
a'tt*
r",mu
"l

I
l-t .
-,,
--+-_js._
:'e
j.; i=*,,
.-r - -';
.]ts___+ _--1""1:;r1=_,.
. .+,qo
- ' -rs'
::- ttrtrrrr,1r,r5{{rd1.-I
:;;:
,, i:ioP_#,g -i i ='#
t.ao
i- -r.q
f .

i:"4 'i'n

,t,
4?

ii;it.t;r:'t$Tnqnn@ d ftq

,{*r.l'#*+

t) a* zocra'ogd fdq:TTT"

iiFnl
#*on dri dl c'n'"ft{rdttft tq

r*r' r.ti e.1.3l.lt'rq ii?Fld

's

s fufq
fil"|{d d t{qd 4 $q wqon

3,iqai,r*'",<rifnri fu-aqrli t
ii"rli:,i

d *iql 4
R-+atc gw
ia**,n E{ zooa-og
-'izrdt
q6iql TIEII

"t:rtir:tifrt
#;';Ji'aff

'grdd di glq qr {rltlr{q6I unc arrcfld

r|614l
lnur.i'i l-!sl', rao*ct REs,

?

\'E

oa.t zfl IrqR{ futn qfd t

A g*f cu qq afi d lr'rq a1oitr{drt

"fr"-i";'i-d
rflrlril
]-(-iiffr UIn)|
,;f# c" H

ft#i'atrft

qqr.tT.it trrqltr 61 Md

ori qr$

ftw{'rqfdd 6ry$ eBirr+d +1tnvmrffi
d "t.F

iE ,.riqt
rr q,{ r} .a,r,rlq d q-.r}d fdryqPvr c,r qffiJ ca.i qi?ti
rr.irir{ di sni-aivqfl ii o-tar$ .irt r
rrf?v :F rr qr.aw l?rd dri qdl qor.rff 'qRn €-ac €FRs
a) fi,r adiona; *" or rfi-"i<cfuql qrlt

<!-- page 55 -->

z.

.r+f{d d dqtT it Yrs grquli ': 1rl: '
.lrra-orQ
s q!r6q r6rll I

-;i:' ' lj

sc fffuf ai dlti (r..{'1d fAC nid'I /' F '';t'

'i'lrrr ,:;l:

-d#{'frql
ffisfi

iT:?-r'': .-:': ri

qm sdm d a-rd ft( erfuguai+

qtl {q fttl

'cqt"T{dq?tFf'I4 ficiff zo r"rij ?'-:orr";' ;;''i
s{Ff4 qrs-drff
qFT {t i{ w*tt li nft.r oT+ i61ep ar-lt

't

qc'.tlq,

pl,
,.,i.

,--

ttc.*'tds fta)
srRr'rvF.)s.
f.tftroa
!.,lclielultul A tt t

.-* +:-.*+i!
Cf

t

<!-- page 56 -->

6\t6 : qt2(41)fu/tr{/ 06

(4)

rrereFrs{€rr
@ \ r - - -

Rtiln , t6.62.296g

3n9ffi,

slrq-orfil+'Trrr,
{rs*erFl,s{rrg{
It{q :-. qiq . e}er iw gq"tq}6r q{ :ooe-os qqhw
&

W?; l M n & c t t u -

j

T6kq,

1.

s{ zoor-ogd *{d {rq 41 .ri.r \,?t+srdtw F6rd df GT{rrsdi{ (.}Tditrd
qIIsDd qrErry€ e6.46-{is Vq} or {rqR riTtrd
E}nor orSrn i t
ef. zoos-os.+sFtrR s-sreo el-rd 3rs1qFflr{d) t eir6 erJstqrfuiit
eI{r
fui Tti ud ml ig qron Fs tarr_'
50l- qo cft f6-iimrq'trqi# isqr
qarEl

S
Ilq "Xf*^{

Rr} qi,T-s}srtrn. g-6T,it
d q-q}+wd ris{ i Rrqrrt6.Ri

lqofq Frq B :-

s.r

qi{ gfld or cd+w

G)
(iD
(iit

*€ - I* 3flq aRr rRrfrd 2s s{6t E.rirgdr{q ft-qr qrdr t I
yr{€" 6y (rfirthd irRr) : qirr g6Fil d s{ zooz_oao1 crq nl?r
(\5.r6.a6-ii€) S q{ zooa-os+1 drETfqctq (aflrhrd{rRr)+,ft I

lfuw: vi.r.v5i or cdq*aEm 3Trifuos 6csr;-qrn r

*eI qtg B;rit 6'r qqt{F
a.z.r wqalor .rcr
(t

(ii)
(ii0

*sr +R qsrfi fr { W d{ffi d q6i fi-c qr vs$
rtr-d t Grffq orss +1 srtqfr A .r{ t qfr dEd- ; eTfuo
;;
ergarq*.ffqIRn ftqr qrdr t r c{qn { +sr dw w*iqe e,l
q 23 qf6
-erg$rc' € densTrCFnI gqdar Orqri rrt fr-+*q
ergvx r+d *h*r zod qrlrft |
slsi ir*fl qco 6 Ajt .t thl-o se +o' gfi.it 6r y?r-d_Br<D

e=ql{R EqiTrq[qri I
+.sr- +F d qdqTr { :oa (crfrfua 12 T6rdl qFdJ T6r.i
riqrFddd Tdi B r e+o ,ff yero'- yeffi qd;ifr 6isd qi ;

a6fu cfrs(qnfruqrRr)
(r) '+sr ri66 g66n e)* d zo *qiit ol
Ea ardrrwuftw(anftr
trRr)E0 is.o66-rI€ d,fr t *r.5std w {s6r fuTrqi'aTs}r
onia+nJ+1dqr d er5vrcn or ftqr qri r

<!-- page 57 -->

(it

dsr dno etm d #a $ sa
(3rmeftT?n{r) 60 6.41

.qgpt.^d'qiT
o-t ("mrar
-d
rrnl tirsr
F*
"*m
+ff^qnFtdi BdRdolJ d irgqrdi rnft'r r+ m.i't,5*
+i tr*ft.,dlrf
11!. dF^"W* di w.s-+d-+a.r*t*

(iii)

wrqqqq * fuirfttd 6rff vd I
d*
gr
qrliD
ed d|t€q sts (qr"fs}d
-\60se.ss4its
{ ze+qe<r gord^o1
Bstftd +1 qrff i i 5.6dt d qta 3{|t|Fd{IRr
sisr +R qsffi ,i t+ilRd olJ d "erSvrcd Fdil#-;
fi
qr$
|

s.z.s {<)qF sbin : idrsr *K +t q,rw
Saril
'"na ig RqtRd drt+ts SfrT

GTDcrrRr)w eni-<cariB-dl?td
r fr,e q"- as 1'6 q
qF6 oTra{rcrwdi q{ sq-d0Tr}+6
- ,* uti-.Soa.*"+ iiqr

qrsrn I
erqftg:
4.1

d-.si iin 6i qft'fdq fu'oaae lln ro.n cr.n_
no 187/ - Cfd liF.Tr.
.\rd FIrfI 6-{

Fo 226
/ - cft fu.Tr.
W FITR 61

Fo 621/ - Cfldfu.Tr.
g{ gqsl 4T

q{- zooe-osd +{rt qi.T qs +c iq *.n
G ie o1 qs tz.s qfrcla

4.3
4.4

elff r
slsr clw cr i'e.d e* qerrdd
rz.sqfrsnrl,ff t

.Tr-rV4 slsr d-{d g-6rd d ft( snd.fi g@ drf,$.fl
fffl (crRhd{rfr)
g€

or
4.5

cfrcn frulffi fu-qrqrdri I

q ffie
Ti
ql(lsrd

EFITI

hr.*t'

4.6

fcFT'itAg 3r+eqff ar*S..€ffq (orRFdsrft) +1 1D

T+{€ qfuqrd *irfq{ e}syEqrqT{ q-<)qRd ergw €i

r

s$q{ qttrfl:
s.l

sq 200s-09Bg .Ti.r.W *sr qfw tg iz ol ccqq rhqqr
(pomposition-scheme)
rff vrft +f qrn'ft iqs d-srcr6.r ff6q A+r
sTit srgsrqrftqloi B=r+1qrffi-6dr{+q #s +1 tzs qfr{ro {rRi dr

rz.scfr{K rrft ei-{r6-f,fie}lff r

1q-{fiq,

M,

{nsq gfus.
ft-d (yr$s) fuTFr

<!-- page 58 -->

@/)
YMrv1110***

ho (cmmrfl
) fi,ipr

o9o-v r(r)ftho,u ,/ ?oo;
"n4

l'1.tt.I.,tBo:rzooa

grn-or{}3irgfr.
Wf{crT{, g-<qrfi j

nvT'_

rndala qdhm q{zooa

Wat-

Jnq6T qd frsi6;
qs2(fr)ft1sn4rz
,*
416:q1)tc)t/,t"*

os /

qr)cq.

t?. q, s.s.oat

nqqia.fu Jfirrd q-{cnq,lr
,
') ucc)[i-rr
t f,sf),rfn'rr.q'r q s]el
drroa,r"q-sd g"#;
;#.Ti'.t3200s
il
EE l'1r{r-t{fl{ ,prri.rrbl+ {,1 ,nj
"S
l.ld,j.i d .

'o

.rrlit\,r
r,)r)i,n.)
(rerfi,ir){Frd
# ffi;r,ffi TH"TS:1,.
.E
+; qtirr4 '-r;)
')

"**
2

A

"tri}

qrrt- rrso ?iFr
{rTe)

a.} q

vrttrcr hlasrq*",a- a lffl
:.

dr.r)

H;-i;;t"t

'r tiriiliir

{) .tql&l* .r1$ +n

";lvk),r{flr ,6}oo ,rt}n.r

*sr qtw* qsii *er ,}ta ;

j,] 'll',]1:l'il'T r't'?r
vxr d rird;; rft*J';'.*t;1Jt
nr.rirerr
F,l,rr)
',rlr+
'
'D
tr'df4r
rrrr
qttnq
s
rr
rraffD+qfir
j;
dl rfta,ri il;i'";,

or

v.fi)qtr ordc|d) rflE +,v e.._)inIl _rdl-rtt,r
d)
flerli v) lfhT.ill.]rkl iurr.)
I

<!-- page 59 -->

qrrFlrq 1!r{dY

wfiz
'A9

fru(orrvr0)
hvrr

q4(1)tud
/.1r4/os
,f*
-'l\dnrorff orrgw.

wgr. ftn<nao.or.zoo

Y|rrfqtq. F{4gY

frqq:cnwr0 fqlnir qf aooo_os
ewrrfqmfir c?rqFfrftr
q. sz (fr) (lwlydtoallr

fii'IqFte,ss.os

ird)cq

omd rninra v-a$ rnai fu{sn-5qrs
fr}er t fu fgd .M qRtr.qf,
_
q e,lsrF"rqtffl.
qlrd5.d'+ + q-{,14 ft.n-gvn
tn,rffi 6-r+rn,r;tq a.t_
r.
ttff qftw:

(3')

tu t]3 q-{rnn^*qqqspr qqqr
irqnftfrq
rsorq
*ylmgll+/*g
qrd-fi
wq n orv
z o.di u'K qRl
u{d faq qnfrn
- ^ r cT

vrfrr+1 er
ti
#
q
;#;'t".#t""#
ri
ff:t:'ry:g
RM..-"
vrd s*';,;t{;#'ffi.1$
KT:gg".: ts :*t #;';,;l;;"il T.ffi",i*J#
*:_:n:tgg,',"i
ur.:,* r,F,

Fo-ffrs
Es frrnsrq cyr#fo ar qa .r*mnrra ;';;-;#;'*;

Jl

(s)

o*dB+*"s
mT*JHg3*ry{.€
F
ry
oS^r.,fi
il#
Rg"fyx3=ry
xoS,'$tffi
qRftn
crftr* sog.ft{rf,ql fi srFfBdhri qdd
r

fs)

nqr Eor:f qa o{,"frd
affr 4t 6sqfr{'d?rftr* s q "fr crtrft
*#"#"'rir$",
a
o*
q+rqr d fi"d r
"rrnqw gtr{ Rac d alaq C 6rsri d"rrd

(c)

iv* crqiq imfu srRrS Eld^qrff

ofl

qi

d q,rrsM qRrl nft { ftq@ o.qifuc
FO *rqqgr
.r.n S rre{ t rrq ,wr* qr dTgqn Vfrqr!fi vrd ffi
6, sldr
ffi" hqr vnt

Td

I

2'

4*

lfiqd qr,I qFf
qRl

8g si+1 p errft-aflftr d oo rftvo nft qq ftft-qrr$r{Bd
!ff

* ? *u d*
s[*;}w;1!$_$;!)T
e{*.ozo-rrq.nri
orlqcr/
ltnlq cTk| qFt
aogur,
F3r ffi
*n

*""

d:era vwr^erer+r-ffia
wur q qi{

di';ff1l";n[,?;*'k
oo
vrRr qr gtmq
T q 1ffi
€trcBdsq ftrd qrn
qri^arr-sq
"r^-ft;
a{i sq c-idid
e-*drd
i TO
ii .mrad
{rqftecrrtu *+ **r"
*i.' -"i=- * *
oil'"i'#
.:.;-::-i:-Y:'

r

.,i

T?LAft-d

.:_::;"

a

rirY

ffi

,''-

qff

*^_ft.,lRr
-\{

FH

"n

'.

qfrvrr

* n

_rl

.r,

..:.,

/F:...

"q.,
c{)lnefJsfscrikd) d JnqRsi rt\fiiri df4rR 6{ ft{ qra
.,r1,#
c.Plfifu w *,
llr'rinfhoftRr d os cfA.srd€ irq q elr
"o

"=n{,r."s*.,.,.:

/-ficfiy.
\d*9,."

(lv.vtr.vwrnr;
vq fiwi qfuf
Dlworl MrdUtilo!{.2o.Otttri1lrtrr

<!-- page 60 -->

e9
Ecl". IA 2z@ Wi

H : DSEXCISE

' ' i

:

YFstlpTr:IS$flq

is''ffr
ft-d (ors-o-rfr)
sag{. ft{ro

fo qqq{, oe

telro
I

eTr+dr$strg*
TvNe]FT'rt<sg{

-'-.

r*

.frqq: ?si cFn iFI sflr<n

q6l{q.

crserr{ {rq atr'r4rq{[r{
fu
t
{itr<q
fi{qrC$N
F{fiR-.fd
q irt qf{q s-srfi eg qqtq qrer i ercrq
+
qisq
ireqrEoJ
frff 6i
qfdgl d efl riFr qfo
n
irft
q
feftf
+1
Eti
m*'s strdq
snqrRd,
qurfre vifus cfse $
daNq'otqrRd
fg
d
n-4,
{ffi
$-%.50Y.
st

sqqlr qfi sqqft S srd'l BI
qRRrffiq
-'
sqd.{ q €rqr ifrG sml.{frF-fl srss
qrq-{Edf
S ergw *tr aftnt

g qqftra

<!-- page 61 -->

{|ul{slFl T|*FI{

fftr frqFT
(orr{oTfr
cr:qFT)
oqto ' q.q(t)fu-c
//qR //os

ftiro : zs.or.zoog

3tTgK,
cnqft.tofr?il?T,
YfdRTt{, s{qg{

fdqq : Glcmrfrq+-{K sS 2ooe-10d *ftirTit I

qdow sf zoos-rod rieg q o*
F*rqsT{ d-q i fu
"n"rp d ,qroiq Afrrftq ffq ftri.rd
afiD : e{Frr+ ercor0 c<lcqo d 3ffiD' T6 s{ (Fritr
1.4.200e
fr 31.s.2010
d6) Elfr |

1.

{+{€ si cqr* : tcft -rfor d td qmr-+tffiqrD-qn
wn-d oenqss ftffis frffi qR-irq fi+q d id ftftro

dr{-S-s''fiq'rRq+qn eryr*en
d,rgw S ft-Sqii or fuiq

fuer.rqT
tt
tlfi qFcI:
3.1 5-onT01 ww1; q'{ 2008-0e
fu vrw n ffi qfui Sofii
oT ri@T 6660 fitfRd
qerrqf,{*.ft t

3.2

@1rg rft "fr q{ zoog-ro i-rt

gffit qT .roq : ltJ rifq w tpft qfuiT g_mTr)
d odqrc
qTE) d salrcrovur 'qd r qR e6 qlqdi il cMc
srfq{{f, Td{s +dr t d} fic(l ftqp1 6 ergqft t trn

fu-qrw qdrnr

{<}qtr cb-qr fqP4d qord ffivrD-on vrRr (crxflA'o
q1?Dqq rd lit €' en}qq 3Trrifud6{ irqwkr ttrlcnin
t eiErq;eife-i qtw di-i s-i a3
sri r fun qx.d
"rg {o

<!-- page 62 -->

/ rF'.

(bu)
Xda*el 3r56qfudT Fd{e{ of oft{erdrq .rBd Hf+fr

qrqx qwd s{ri{o tnl 4{q fiFqr
d qqet ffi
ffi
\frI{mlI
3.4 sr{kd {rPr : q$ zoos-ogii riqrtdd d {S {oT-it d rrd
q+-{K (fdffiq q{ zooo-oz 3tatqr 2ooz-0"8d dqrq

oi:qrdTd q<tqw, ffi'fr

Re{frd) it crw eildi

ot

Ti{qT d 3 EIr{ tf{ q{ zoos-og qff clo' {rRr $ FETTffiT

gtr os q{ 200e-10
A ftr enrft-d{rRTffqfR-do1sit,qTwsTr+{det risr

ek or cfrcrd

25 d6
26-50

5.00

51 qt 3Tfr]fi

10.00

3.5 orict ga. : icft qfugtqTd tg erffEqg@ ft'il5{iTi
FtrfR-dfrqr qror t ,M

Ttqrc
g@

'1. r0 FIIEI f,-6 01 1500 /

orif*d {rRTqrd srs

2. 10 dr€r A orHo sooo
/-

qrc|FdsrA s{d
E+va

rrwrR-d
Yri4.
-::-^^,
5UUU / -

3.6 tsfr qfu{ ftqfur d rgw di -ilFfl qrtrs : s|\'|{g{FI{\irr

q{ q tcfr qtr{Tffq
rFTFrf(glit fuffi d fuq orTrnfr
qms of qw lo cfrcm w sr"ttq
*q +dTfus eiluTrRd

errtrRf, cmq o1 qrer oo qtderd f+rfR-d of qrfr ilr

{fq{qFl {f.'q rir[-{rf{ eFR ft-*s dfrl orrqtd frd qd qrd

furfufl enqrRdclss q{ qqra YI@.o1 s{ sr} r.oo

qft {tr d-eq*frr
3.r t ,z -om q}aor, "tcil qf+'.re'slq,fti{ fe .z TdI{I

e)ild 61 3rgsfdso:50vut w.i t
3.s ddffi , $q q idi qri qr"fl qiq 866'fuffi elbn
qs ffiqrq FI,n+ qd o1 ar+*enqd zoos-ooi anr eft

I

<!-- page 63 -->

.r{ fr t q{ zoos-rofr {€ trfr qfu{Tq}iidt w rfr erfi
qd of olffi

qi qdr

3.e frfr fr-d 6r frqfsr, q-ff frfr lfra or sqdq ins 3{dq
rq d tqft qfuiT d Mrr -.{Ffld fuoq ot ++?.rq id
a1.'rsq;Iq|crrrirtrrR SrR ft-tr fl{r gii orqfr frfr rN
dqR qr-{i ig {irie d.n$ qfi qrTftofq ftrqr .rqr t t

a.ro ?ct qFcsror ffq {s : ar( a{ d t?ft qtrtl a1 ftqf"r
qnfi, frdqd{ aqs, d {@ it,Tft gR g$ tr c$qr-rit
ao Xff ffi qR{r d qei d go ortc oT ft-6-qnw s.
zgsl- fuiiR-o B m q-drqx6. 32o/- fr-i qri oT
fuq ftqt rrqr dt er;qfr-s at ffi qfuiToelrffii q
Grqtd @r& ig fr ft.fq tfl ti {S awv gk ot qtr
s.rr *t qtrgl sn ;Ftr sf,rrE: gvfuo gi oq qrrro ol i*
qr?qrsqd-dT6-id d ftq {Frcerq ErGqrFrm{Re]3t{

ryrtl

ft-w gm so q$ iS stro co ;rqr BoIr<crft fr;qr

ql{rirl

s.rz qrrtgt - Eivsrsrffii { tff qktr el fuo-{r: {q ftrdi
ii i:ft qft-d'fA€-q
of o+*el ntg qc*endq{tsftt
s,ra tyfr qfusror ftqfq : o{ 2oos-lon ffi ctrtT 3nsffiii

g|.,Itqrq yF iI rirrFlrru slq{ Fl@ ot eiForq Fcgt so
cfrpTf, st'rT r cdie Fgdrq
Fi qmiq wTrd @-rtcr:

+oqfrird e ro cfrcrf,war .fr ertfffiotit qFsr ertlG r

Y

d ftS Zq Cs S eTFo fticr dsn erqff oo{ot
ffifq ql.g S qa dtlt

4.

qrd j

qno ftffio ffiefr rrFsl:

tg qro frff-d fitcft cftFr
4.1 q<tffi qfu-{n: q{ 200e-10
7 fiu< ft|a gfq g-rrri & -rd frt € 3ir*{r qpiTq znq
E<)-qw o-rqrqr "ifd 1 \'6tho eTii{q qrq eti qt teft

qfu{ d fti ewrfr'dq+el d u-gw effi vfu-w6sy

sryo erd<o 6'r aqrl fu-qrqr+rnI

4.2 qar;ff ftt {isr : ;rrrftq et4}d ftc qrEafiffi-o fu}ifr

insr ,z ffqi ftld 3fq g-oFitof €iqT raood qdfsx
joooo*i q;r trq fAqr.rq| tt efiq-dBryrE-sfury 6
q{csf * oen eTFrrfrn-$ n ftt$ .T] B-ds d eryt;q

<!-- page 64 -->

lo

rd-m {rEsd ftd frqfRergsrq} 01 tiw t6i *.i*
fuq.rdt

qr$-dlrqts : TrEdRFfd ftffi qtr{ ,/ ft'{i o1 fiR{
3fis g6r+ of frft-q Aftdi ig g6rcl +t *iwr q qiNqt
dd-S'sqi-s ft-e ergrwfurfR-do1 'rS t '@ arq s. {)

gorrt6)

40ll

sq 2oog-io

Tfinq

qq 2009-10

{dqn
ridr

ig Ea-rdol

1.

qq5{ q qqg{
sF6{

453

250

3.80

7.50

2.

3rdl
rrrlFns
5qrfrq, q$u-d

293

160

3.15

6.O0

397

240

2.50

4.00

457

350

1.85

;|IffiFi.

€eEqr

arfds ig dd$'s'
frs
+s

eTrqqffir
3.

Tsltrdq
4.

4.4

4-5

STAI

q.Rqfu

fttqft qR'ir w fu sniqq : friqfr qF{t. qso ftftra
fuffi cfu{rq ftqs rK zoqft€rdfu d.Id qd or ft,fq
fuqr.rqrit

a1 drf,$s d-t{ : frF-;ir a}offot
ft'|d sfiT ot-g-dlu=it
drcfr. tdt-cq q Eadi d qR gt€-'+stg dT{*tq atiJ t
liqTgsri gR ffi qfi ot ftofq ftr+r wt B :Ffu aror. {)
4.lI
1.

X"/

{dcFI arflts

s{ 2ooFlo dg

Sfl

frqfR-dargitq
sts

cis ft-dmr+sd

5.00

sri fufl-ir Ei-sa

4.00

-'o*:-:--_
flli
l$cll{

e1.\tt\t Q-l

Elcql

ifrio q 4"ft

4.00
4.00
5.00

15.00
10.00
8.00
8.00
8.00

<!-- page 65 -->

(,-6fi t

--\-,2--

o_

dR&frG-

7.
8.

Bltlq fr d"ft
0.60
wg1 gqrffi qi6r 3.00

9.

10.

1.20

3rq *iqFftq gwreq. 2.50
qTg"e3rr{.\'s Mt
crq frrfl sql€q
2.O0

11"

erq r.rtqrfuf,r(

12.

3r{I {erq

13.

FR"e
qFrg{
ttdtrc

-.
-

5.00
4.00

1.50
0.75

q-qgy.2.oo

2.50
1.50

i

4.oo

sFq 1 . 6 7

3.25

15.

l€It-c - erq fuen 1 . 3 4

2.50

to.

Scq|d-q
€-iu-c

2.00

14.

qqFnq
gqrcrq,
qrs"d 3r{.q ffiq
-

qrpq1fr_orq ffi

3ral '1.00

17.

t{Aftu-c - cf,;q {q;6

18.

ft|E - iil-qgq

'19.

ffiq - 3rq wtrq

4.6 €tle

*ffr

o.

2.00
1.00
6.00

0.50
0.75
0.50

1.00
1.50
1.00

err, €to-e ar it qnr ff{i Aqn at fi GEqfi)

qirr : qi.r gdnt d 2e qTF qqn+aqd qroq
r+o1 erf
2008-oeafr ffq {rRTq5}fr q{ zoog-roof enshd gtftr
furfR-dat cnfr t I fur' sao or qf zooe-ogd dsFr
sil-rlFdirRr +t ro qftcrf,qRr qq.fr {<)-dw rS d qrqrsrr
B-^fl+ls{ 2oos-10ig orTifuf,vtfu s{ 2008-0eo1 envhar
{rRr d} z.so cfrcrd fr€fRf, q.',tqrfr d t qiT {omt 6t
{+flf, 'ra q{ d srgsc fta<N srmhoo< o-cqrqiqrir
€Isr qhf, : st-srdw d s<* q {fsq rr{co.rq
ETnfrq fufu
.r$
'*
fu$
d

<!-- page 66 -->

---

(1) olqiq ffi-d-fld

6) c)sT-qiw oT qlaq

Gb

\:7-

ftff-q ,Fq

sqd roon6 fu-eitq dqit
(z) Gi-srftr or arD-f,dq
q.{iT{@.ss} sooqft fiffi
ErrrTI

(e) +€T-qlw qsFrq) aT qrR,.o@tcrTd sv t fuliRa I
oter eiersro fd;dlilq. d '{t @qd. s$.nI
I
-.fl
,rraqr *g qghf, eTrift'dttRT ftqlRd
(+) s?rTffi

o-sfft iliT {q}rw did o1*rd*S ufr
"ri'
7. strqo.frTqalq d ncilErc,
7.'t fuqo srsq d fuo qs fu qts s. s.oocR d-es t
qeror s. z.ooqfr der fufR-d o1 qrfr i r
7.2 silfr-dsrsq / fiqg d qrqrq w i-q qts s. e.oorrft
qo'fies Q qeax r. z.ooqft qo fieq ftqfRf, o1
qrff Bl
7.s 3rtdfiqfftof T.g qq orJf,rut srfu{itd ill esqtdtrd
o-{i d frc qts, ro erq sct n-o qfr olr$*iq+ts Z
gor+1ffiox
yfu eg F. s,ooo,/-gs gq-$aTD-6
d
ftq s. ro,oool- ftqfRd of 'rrfr t t
qqftg:
8.
8.1 orrqofftqs t qtq {rw€ di c6 qftctd ilRT.rQqt d
ftri g.F"dfdrq. qqd de Eefqtrdci{rq qrd sd dHi d

i

qmrf*-o \tt enFfo gnqtq d R\ sd o1 w*frt
s.2 Tiitr iiqrqa tt qrffi+o qqrT qd,cd av qr} d Ewno
aarTfi-trqEsqs}'.rd {iqtTt qrnr d otFlrdfuqr qr}rrt

8.3 rmq d rS $ ffi gq-o dnt + ft( nerrgfuRrffif or
qr+mc nr s{6$ rierrct d q6qhr t qtqo K{ w
fu-qvrdrnr

s.4 ra s{ * 6q gsr q.f of ipm q-flpr}o1 fud c d, sm

fAcr il otq s{Rf, rqnr li;$ wit
8.5 gomt w a-f,drtrfftor clq, cdrYq rrr*<q s[qDd etflsr
o{q frrS q-mnd rEeh o1 effi +€l e}.ftt
8:6 i{-s{or{ *irarn dennaq d otrqifuit gxr qqnftqFTr
oen eiderersrc+1 +o.Ttq iq fati .d $qrf,ffq 6rd o)
{t-zt {f,{ w qqrfto

ftqr qr?}TrI

<!-- page 67 -->

I.i

8.7
8.8

irq-t Iirfu-eor
d weTqfuiTgrd ffido rS e}fir
iirrr$d s@)-rdd fr}cd r-o)Ed e 3i-<ia #'.i==n

o t.rq GrrqFrE-{ri d ftd EerrSd\*@n-d-d
i rq q +r
qd
m
6r yrqqrqftqT qfi-nl

ory 3rqcr3rq iF"e}o1qfrql,tdr
$or1TS
ry
"d"
\ilrq q{ sTffli{r
ftft-o-{q d 11pr-vpr 3rg5rq-{

ftsffiqx.i
sfr qcrffi oiffi er*orft ftqirTErqrgdeq-o #'.flr$i'
ii futr ft',il'r d or-f,+dO-s.r-fi*rrq
8 . 1 0 {n'q HRdtIq
,q}*

xa€ffG'

oTrffiTfr
cE-srrne-d€ re{rfud
6j
P.{ * rtilr
;
FIufrI i?rqT
BI
",i
a.rr snqor0fuTq qfi fuqnftearo) srk qqrft {rri d feq
r.dP ftrd d go rqr qro=r
dericngF-osqtr r*A *Ui
q
o{ri or ffq fu+.rqr tr

a.rz onqf,rft fr'qp1,ql)uo qFTdsfl gfufl amr, 3TAq{Titq q}

fr$q Hqtrqdeifuqnqrft Ti.ttr"
s.rs qyi qr.'q)S srdwtTcE)-drgB-CsT-fiqR-{To1 enq6,Fi
qr{o q{ fuRrfr erdi d iac cqlfi ra
Aom_oAqr
qf{.n I
gw ft-+wS{ qs - sqq:
e.1 Tdqrqd^fiqtRir sR gq fu+e _ ,rqrn ft-q-e,wr*+n
q{d} s'11610{
s{S _ d erarflq_er_er.nfi
Eqq. 1pI
qr*e o) ff gv' fuqq fiqfRd.tu*;;
S yqnfu 30
6l

|f-

9.2

9.3

y3T rT.gT+ d gari (*ro:10{d) s q< di * nqq{rfid
(qrir 8 ew, dl o-dl{f,re qr"rfl o-.qrfr qri I

l.
qrGF
3rar
w
T{FrT
sqq},T
d
o}
miqrfrd
o€ ski
$v

frqq qiR d ft-f€ u-4tun
6T-{ff**i

+ *:dj

orffi o1 qiir
s.4 qtr{,d F{.qrd q{ frr6 qd sld *il.q-ff ,qfusr+s=r
yrceq d ftq Frft-flr-oB'or sod-s ft-qTqrrT gfrft"-;
frqr qrdr
10. srna;lfr{+flT d wcerd ts qlqqrr / .cfuqT qq"s.rr
/
Tdffider5sv€.ft,

<!-- page 68 -->

---+A
l ' " . /

o} -.f o-*i d ftr} inrp ,/ fui Z enqqr}
d
.{q.ftft
cil TrcnEFr
ltb-flqrqrqSftrf,d s{-d frs'
efi-s=d{Bi}
.a
"- /,/ eildcil

d qrgq {frg ft-qzrdor +rqoil t

oTrrnfran-i-rffrcdcw qeTmlrq.
ftqio zo qrd, zooge-o {of
w {ocr {fselv{mn s} ifi-d 6{i oT ETq6{'l

ft"""+d-f$:

t

dF.
