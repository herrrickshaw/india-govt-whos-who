---
doc_id: "0af34d1aae58c5af"
source_url: "https://forest.rajasthan.gov.in/content/dam/raj/forest/ForestDepartment/PDFs/Department%20Wing/CAMPA/BUDGET/Budget%20Allotment%20order%20no.%2043%20%20%20(25.09.2026).pdf"
ministry: "Forest Department, Rajasthan"
title: "Budget Allotment order no. 43"
date: ""
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "bd2d961f806a6611"
---

<!-- page 1 -->

कायालय राज थान

तकरा मक वनरोपण न ध बंधन और योजना ा धकरण
राज. जयपुर

मांकः एफ.14()कै पा/अ मुवसं/लेखा/ब.आ./ 00043

दनांक: 25­09­2026

बजट आवंटन आदेश ­ 00043
वष 2026­27 क वीकृत वा षक काय योजना के मद सं या ­ 44 : Construction, up­gradation and maintenance of inspection paths,
forest roads in forest area, watch towers, check posts and timber depots for protection of forest and wildlife , a) Watch
Towers, b) Check Posts, c) Forest Roads/Inspection Paths in forest area आवं टत काय को पूण कराने हेतु अ धन थ वन म डल/
वन म डल को IFMS के मा यम से न नानुसार बजट मद म बजट आवंटन कया जाकर यय करने क वीकृ त दान क जाती है : Budget Head Name ­ 2406­04­103­05­01­12
Budget Description 2406­ Forest & wildlife
04­Afforestation and Ecology Development
103­ State Compensatory Afforestation (SCA)
(05) Interest
(01)­ Compensatory Afforestation
12 ­ Grant in Aid (Other than Salary)

Budget Allocation Type ­ Normal Allocation
Item Name : 44 : Construction, up­gradation and maintenance of inspection paths, forest roads in forest area, watch towers, check posts and timber depots for protection of forest and
wildlife
Activity Name : a) Watch Towers
S.No.

Division Name

Budget Head Name

Physical Target (Nos.)

Financial Target(Lacs) (5.00000)

1

DCF JHALAWAR

2406­04­103­05­01­12

1.00000

5.00000

2

DCF & Dy. FD SARISKA TP­1 ALWAR

2406­04­103­05­01­12

1.00000

5.00000

3

DCF DHOLPUR

2406­04­103­05­01­12

3.00000

15.00000

4

DCF WL CHITTORGARH

2406­04­103­05­01­12

1.00000

5.00000

5

DCF & DY FD­II RANTHAMBHOR TP KARAULI

2406­04­103­05­01­12

1.00000

5.00000

6

DCF SIROHI

2406­04­103­05­01­12

1.00000

5.00000

7

DCF WL KOTA

2406­04­103­05­01­12

1.00000

5.00000

9.00000

45.00000

Total :

Item Name : 44 : Construction, up­gradation and maintenance of inspection paths, forest roads in forest area, watch towers, check posts and timber depots for protection of forest and
wildlife
Activity Name : b) Check Posts
S.No.

Division Name

Budget Head Name

Physical Target (Nos.)

Financial Target(Lacs) (5.00000)

1

DCF JHALAWAR

2406­04­103­05­01­12

1.00000

5.00000

2

DCF SIROHI

2406­04­103­05­01­12

1.00000

5.00000

3

DCF WL UDAIPUR

2406­04­103­05­01­12

1.00000

5.00000

4

DCF BIKANER

2406­04­103­05­01­12

1.00000

5.00000

5

DCF WL RAJSAMAND

2406­04­103­05­01­12

1.00000

5.00000

5.00000

25.00000

Total :

Item Name : 44 : Construction, up­gradation and maintenance of inspection paths, forest roads in forest area, watch towers, check posts and timber depots for protection of forest and
wildlife
Activity Name : c) Forest Roads/Inspection Paths in forest area
S.No.

Division Name

Budget Head Name

Physical Target (RKM)

Financial Target(Lacs) (10.00000)

1

DCF WL MUKANDRA NATIONAL PARK­1,KOTA

2406­04­103­05­01­12

3.00000

30.00000

2

DCF SIKAR

2406­04­103­05­01­12

2.00000

20.00000

3

DCF WL CHITTORGARH

2406­04­103­05­01­12

3.00000

30.00000

4

DCF WL JODHPUR

2406­04­103­05­01­12

3.00000

30.00000

5

DCF & DY FD­II RANTHAMBHOR TP KARAULI

2406­04­103­05­01­12

6.00000

60.00000

6

DCF RVTR BUNDI

2406­04­103­05­01­12

3.00000

30.00000

7

DCF & DY. FD­I RANTHAMBHOR TP SAWAIMADHOPUR

2406­04­103­05­01­12

3.00000

30.00000

8

DCF WL UDAIPUR

2406­04­103­05­01­12

1.00000

10.00000

9

DCF WL RAJSAMAND

2406­04­103­05­01­12

2.00000

10

DCF WL BHARATPUR

2406­04­103­05­01­12
Total :

सामा य शत :1. इस कायालय े प
जाना सु नि चत हो।

Digitally signed by T.J. KAVITHA
20.00000
Designation: APCCF
2.00000
20.00000
Date: 2026-09-25
12:11:06 IST
28.00000
280.00000
Location: HQ Office
v-2.1

मांकएफ.14( )कै पा/अ मुवसं/बजट आवंटन/2025­26/rajkaj no 15445191 दनांक 21.05.2025 म व णत शत क अन ुपालना कया

<!-- page 2 -->

सामा य शत :1. इस कायालय े प
जाना सु नि चत हो।

मांकएफ.14( )कै पा/अ मुवसं/बजट आवंटन/2025­26/rajkaj no 15445191 दनांक 21.05.2025 म व णत शत क अन ुपालना कया

2. उप वन संर क बजट आबंटन करने से पूव व ृ रोपण क जी वत

तशतता अन ुसार ह यय होना सु न‘चत करे।

3. कै पा मद के अंतगत आवं टत काय ार भ करने से पूव संबं धत ाम सभा /VPFMC /EDC से सहम त ा त कर ह काय ार भ करवाना सु नि चत कर।
4. आवं टत बजट का यय कै पा (Guidelines o Compensatory Afforestation Fund Act and 2016 (CAF act) तथा Compensatory Afforestation Fund
Rules, 2018 ( CAF rules ) . ावधान के अंतगत कया जावे।
5. आवं टत बजट से कसी भी प रि थ त म अ धक यय नह ं कया जावे।
6. उ त आवंटन के व

ध य द कसी रा श का उपयोग संभव नह हो तो रा श शी इस कायालय को मय औ च य सम पत कर द जावे।

7. आवं टत बजट क रा श का आहरण केवल तभी कया जाये जब वीेकृत काय से स बि धत यय का भग
ु तान कया जाना हो यो क टेट के पा का अकाउ ट
याज बय रंग ह।
8. आवं टत रा श िजस उ वे य / काय के लए आवं टत क गई है उसी उ देशय / काय के लए नयमान ुसार ह
शास नक यय सि म लत नह ं कया जावे।

यय क जावे तथा इसम से कसी भी तरह का

9. बजट उपयोग के संबंध म समय पर इस कायालय रा य सरकार वारा सा रत सम त नदश क पालना क जावे।
10. कै पा के आवं टत बजट उ ह ं काय पर यय संपा दत कया जाव जहां अ य योजनाओं के इसी कार के काय
Overlapping से बचा जा सक ।

ता वत नह हो, िजससे योजनाओं म पर पर

11. काय को ार भ करने से पूव ा कलन क वीकृ त नयमान ुसार स म तर से जार क जावे। सम त काय के लेखा एव अ य रकॉड (Manual of
Guidelines and Accounting procedures relating to State CAMPA/ IFMS accounting rules) एव सामा य व ीय एव लेखा नयम के अन ु प कै पा का लेखा
काप रेट एकाउं टंग के आधार पर सीएजी वारा े षत प म संधा रत कर। लेख के आ डट महालेखाकार वारा क जावेगी।
12. उप वन संर क यह सु नि चत करे क नधा रत मापदंड के अन ुसार जी वतता तशतता तथा िजन व ृ ारोपण म जी वत तशतता नधा रत मापद ड से कम
है उसमे धान मु य वन संर क राज थान प रप एफ 7 (24) 02 ­03 / ववर ाका / मुवसं / 10401 दनांक 31.3.2004 क पालना सु नि चत करे |
13. संबं धत मु य वन संर क उनके अधीन वन म डल से 5 तार ख तक लेखा ा त करना सु नि चत करगे एवं येक माह क 10 तार ख तक सम त वन
म डल के लेखे संक लत कर भौ तक एवं व ीय ग त तवेदन नधा रत प म अधोह ता रकता को भेजना स ु नि चत करगे तथा कै पा अंतगत कराये जा
रहे काय के रिज टर का साधारण कायालय मु य वन संर क तर पर भी कराया जावे।
14. कै पा मद म साम ी य क कायवाह राज. लोक उपापन म पारद शता अ ध नयम, 2012 एवं नयम, 2013 के ावधान के ह तहत क जावेगी तथा
गई साम ी का इ ाज वभागीय टोर पंिजका म कया जाव एवम् वभाग क च लत ध त अन ुसार लेखा­जोखा रखा जावेगा।
15. सम त उप वन संर कगण काय पूण होने उपरा त उपयो गता/काय पूणता माण प राज थान कै पा को व ीय वष के अ त म
सु नि चत करगे।

यक

त ुत कया जाना

16. Budget must be utilised fot the items in the financial year 2026­27.
17. सामा य व एवं लेखा नयम क SOP व समय­समय पर जार प रप
करगे |

के अन ुसार दत व ीय शि तय के अनुसार ह काय संपादन कया जाना सु नि चत

18. वीकृत APO के
या वयन से पूव संब ं धत उप वन संर क वारा रा य CAMPA को माण­प
तुत कया जाए क ता वत ग त व धयाँ ाम सभा से
समु चत परामश के उपरांत तथा वन अ धकार अ ध नयम, 2006, वीकृत काय योजना एवं संबं धत बंधन योजनाओं के अन ु प ह।
19. तपरू क वनीकरण एवं अ य थल­ व श ट काय केवल भारत सरकार वारा वन भ ू म के
भौगो लक नदशांक के अन ुसार ह कए जाएँ।

यावतन हेतु वीकृत थल पर तथा वीकृत KML/Shape File/

20. वनीकरण काय म पा रि थ तक पुन थापन को ाथ मकता देते हुए थानीय/देशज जा तय का उपयोग कया जाए तथा एकल जा त (Monoculture) एवं
गैर­देशज जा तय के रोपण से बचा जाए।
21. तपूरक वनीकरण, अ त र त व ृ ारोपण एवं ANR आ द काय क KML फाइल e­Green Watch पर अपलोड क जाएँ तथा भारतीय वन सव ण (FSI),
दे हरादन
ू एवं National CAMPA Digital APO Portal पर भी अपलोड क जाएँ।
22. व ृ ारोपण थल का नय मत अन ु वण एवं मू यांकन कया जाए, ता क पौध क अ धकतम उ रजी वता एवं अपे
23. CAMPA के अंतगत कए जाने वाले सभी काय /ग त व धय म मजद ूर का भुगतान केवल

य

त व ृ ध सु नि चत क जा सके।

लाभ अंतरण (DBT) के मा यम से कया जाए।

Digitally signed by T.J. KAVITHA
Designation: APCCF
Date: 2026-09-25 12:11:06 IST
Location: HQ Office
v-2.1
