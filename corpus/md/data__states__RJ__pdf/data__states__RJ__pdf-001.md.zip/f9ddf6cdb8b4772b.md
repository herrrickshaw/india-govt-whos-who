---
doc_id: "f9ddf6cdb8b4772b"
source_url: "http://finance.rajasthan.gov.in/docs/rules/hra.pdf"
ministry: "Department of Treasuries & Accounts (DTA), Rajasthan"
title: "HRA Rules"
date: ""
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "273138f71ab56194"
---

<!-- page 1 -->

GOVERNMENT OF RAJASTHAN
FINANCE (RULES) DEPARTMENT

House Rent Allowance Rules
(Compiled upto 01-07-2026)

¼bl ladyu dks rS;kj djus esa iw.kZ lko/kkuh j[kh x;h gSA ;fn fu;eksa esa vutkus esa
dksbZ xyrh ;k deh jg xbZ gks vkSj og /;ku esa vk,] rks d`i;k foRr ¼fu;e½ foHkkx
dks lwfpr djsaA fdlh Hkh folaxfr dh fLFkfr esa] tkjh fd;s x;s ewy fu;e] vf/klwpuk]
vkns'k] ifji= bR;kfn gh ekU; gksaxsA½

1

<!-- page 2 -->

INDEX
Rule
No.

Particular

Page
No.

1

Applicability

1

2

Definitions

1

3

When not Admissible

1-2

4

When Admissible

2-3

5

Rate of House Rent Allowance and classification of
Cities/Towns

4-5

6

Regulation of House Rent Allowance in different
circumstances

6-9

7

Regulation of House Rent Allowance in case of
Government servants posted outside the State

10

8

Certificate

10

IMPORTANT ORDERS

14

2

<!-- page 3 -->

House Rent Allowance Rules
1

[In exercise of the powers vested in them under Rule 42 of the Rajasthan Service
Rules, the Governor hereby makes the following rules for the grant of House Rent Allowance
to Government servants :
1. Applicability: (1) These rules shall apply to all Government servants.
(2)

(3)

These rules shall not apply to :
(i)

staff employed on daily wages or work-charged employees.

(ii)

officers employed on contract unless specific term in regard to
admissibility of House Rent Allowance has been provided in the terms of
contract.

These rules shall come into force with immediate effect.

2. Definitions: For the purpose of these rules :
2

[(l) 'Basic Pay' means total of pay in Running Pay Band and Grade Pay admissible
under the Rajasthan Civil Services (Revised Pay) Rules, 2008.
Note : In the case of employees who are drawing pay in the scales of pay which
prevailed prior to 01.09.2006. The basic pay in the pre-revised pay scale will include amount
of Dearness Pay appropriate to that basic pay.
Clarification: During the period from 1.9.2006 to 31.8.2008, House Rent Allowance
is admissible at the rates in force prior to 1.9.2006 on the pay in the existing pay scale. In
other words, for the aforesaid period no arrear on account of House Rent Allowance is
payable.]
(2) 'Family' means a Government servant's wife/husband, child and other persons
residing with and wholly dependent upon him/her. A husband/ wife/child/parent having
independent source of income is not treated as dependent upon him except when he is in
receipt of a pension including pension equivalent to death-cum-retirement gratuity or other
retirement benefit not exceeding 3[Rs.9000/-] per month.
(3) 'Government' means Government of Rajasthan.
3. When not Admissible: The House Rent Allowance shall not be admissible to a
Government servant:

__________________
1.

Promulgated vide FD Notification No. F. 12(2) FD (Gr.2)/89, dated 3.10.1989.

2.

Substituted vide FD Order No. F. 12 (2)FD(Rules)/89, dated 08.03.1998 w.e.f. 01.01.1998 for “(1) 'Pay' means pay as defined in Rule 7(24)(i) of the Rajasthan Service Rules i.e. basic pay only. Note : In
the case of employees who continues to draw pay in the scales of pay which prevailed prior to 01.09.1986, the pay will
include, in addition to pay in the Pre-revised Scale, Dearness Allowance and Adhoc Dearness Allowance appropriate to
that Pay at the rates in force as on 1.1.1986.”
Again substituted vide FD Order No. F. 6 (4)FD(Rules)/07, dated 6.2.2009 w.e.f. 1.9.2008 for ''(1) 'Basic Pay' means pay as defined in Rule 7(24)(i) of the Rajasthan Service Rules.
Note : In the case of employees who are drawing pay in the scales of pay which prevailed prior to 1.9.1996,
the basic pay in the Pre-revised Pay Scale will include amount of Dearness Allowance at the rates in force on 1.1.1996,
amount of first and second instalments of Interim Relief appropriate to that basic pay.''

3.

The existing word and figure Rs. 500/- substituted vide order No.F.6(4)FD/Rules/2017 dated 17.5.2023 with immediate
effect.

1

<!-- page 4 -->

(1) (a) Who is occupying Government owned or leased or requisitioned
accommodation or accommodation on subsidised rates in Government building i.e. Circuit
Houses, Dak-bungalows, Hostels owned by Government etc.
(b) who is occupying accommodation belonging to Devasthan Department or any
other Government Department.
(c) who is occupying accommodation belonging to U.I.T. / Municipality/Local Fund
Bodies or any other Autonomous body.
(2) Who accepts allotment of Government accommodation from the date of
occupation, or from eighth day after the date of allotment of Government accommodation,
whichever is earlier.
(3) (a) Who shares Government accommodation, allotted rent free to another
Government servant or who resides in accommodation allotted to his wife/her husband or
to his/her parents/son/daughter by the Government or autonomous public undertakings or
bodies or Corporation or semi-Government Organisations such as Municipalities etc.
(b) If his wife/her husband has been allotted family accommodation at the same
station by the Central Government, State Government or Autonomous Public undertakings
or Body or Corporation or semi- Government Organisation such as Municipalities etc.

[jkT; deZpkfj;ksa ds fy;s edku fdjk;k HkRrk fu;e] 1989 ds fu;e 3 ds izko/kku vuqlkj
jktdh; vkokl vkoaVu dh n'kk esa edku fdjk;k HkRrk ns; ugha gSA
;g tkudkjh esa vk;k gS fd dqN vf/kdkfj;ksa@deZpkfj;ksa }kjk edku fdjk;k HkRrk fu;e]
1989 ds fu;e 3 ds izko/kku vuqlkj jktdh; vkokl vkoaVu gksus ds mijkar Hkh edku fdjk;k HkRrk
izkIr fd;k x;k gS@fd;k tk jgk gSA bl lanHkZ esa lacaf/kr dk;kZy; dks tkudkjh gksuk visf{kr gS
fd fdu fdu deZpkfj;ksa }kjk mijksDr lanfHkZr fu;e ds vuqlkj vkokl vkoaVu gksus ij Hkh edku
fdjk;k HkRrk izkIr fd;k tk jgk gSA
dqN dk;kZy;ksa }kjk jktdh; vkokl vkoafVr gksus ds mijkar Hkh edku fdjk;k HkRrk izkIr
djus ij edku fdjk;k HkRrs dh olwyh ds lkFk lkFk C;kt dh olwyh Hkh izLrkfor dh tk jgh gS
ftldks ekQ djus (waive off) ds izLrko foRr foHkkx dks iszsf"kr fd;s tk jgs gSaA
bl laca/k esa lkekU; foRRkh; ,oa ys[kk fu;e Hkkx&1 ds fu;e 124 ds vuqlkj vf/kd Hkqxrku
dh olwyh ds izko/kku gSa fdUrq mDr vf/kd Hkqxrku dh olwyh ij C;kt dk mYys[k ugha gS ijUrq ;g
Li"V gS fd jktdh; vkokl vkoaVu ds mijkar Hkh lacaf/kr vf/kdkjh@deZpkjh }kjk edku fdjk;s
HkRrs dh jkf'k dk vkgj.k fd;k tkuk vkpj.k fu;eksa ds vuq:i ugha gSA
vr% ,sls izdj.kksa esa tgka mijksDr lanfHkZr fu;e ds vuqlkj jktdh; vkokl vkoafVr gksus ds
mijkar Hkh jktdh; deZpkjh }kjk edku fdjk;k HkRrk izkIr fd;k x;k gS@tk jgk gS] ds Øe esa
funsZf'kr fd;k tkrk gS fd dk;kZy;k/;{k Lrj ij tkap dh tkdj ,sls vkgfjr fd;s x;s edku fdjk;k
HkRrs dh ,d eq'r olwyh ds lkFk edku fdjk;s HkRrs dh jkf'k ij lkekU; izko/kk;h fuf/k ij izHkkoh
C;kt nj ds vuq:i C;kt dh olwyh fd;k tkuk lqfuf'pr fd;k tkosA]
@

4. When Admissible : (1) (i) A Government servant who is living in a rented
accommodation shall be entitled to house rent allowance at the rates mentioned in Rule 5
of these rules.
(ii) House Rent Allowance as per clause (i) will however be admissible on furnishing
a certificate to the effect that he is incurring some expenditure on rent/contributing towards
rent. In case, the accommodation hired is sub-let to one or more persons, whether
Government servant(s) or not, and the actual rent charged by the Government servant is
equal to or exceeds the amount of rent being paid to the land lord, it would be deemed that
the Government servant is incurring no expenditure on rent nor contributing towards rent.

____________________
@ Order No.F.6(4)FD/Rules/2017 dated 30.7.2021.

2

<!-- page 5 -->

(2) A Government servant living in a house owned by him/her, his wife/her
husband, children, father or mother or in a house owned by a Hindu Undivided Family in
which he is a coparcener shall be entitled, to house rent allowance at the rates mentioned
in Rule 5 of these rules, subject to his furnishing certificate that he is paying/contributing
towards house or property tax or maintenance of the house.
Clarification : A Government servant living in a house purchased on hire
purchase basis from the Rajasthan Housing Board shall be deemed to be owning a
house for the purpose of these rules.
(3) In case where husband and wife both are in service of Government at same
station and are living together in the rented/owned accommodation, both of them shall be
entitled to House Rent Allowance at the rates mentioned in Rule 5 of these rules, subject
to fulfillment of other conditions for drawal of the allowance i.e. furnishing of certificate as
required in clause (ii) of sub-rule (1) or sub-rule (2) as the case may be and making of an
application as required in sub-rule (4).
1[(4) The allowance shall be granted to a Government servant from the date of

occupation of the rented/owned accommodation, on submitting a certificate in the form
given in Annexure "A" within the same financial year, however, if a Government servant
is transferred in the month of March then he will be allowed to submit Annexure 'A' within
a month. HRA claims shall not be considered for previous postings.
Provided that in matters of successful completion of probation trainee period or
drawal of pay in regular pay scale in case of Probationer Trainees, House Rent Allowance
shall be admissible only after drawal of pay in regular pay scale.
Note : An IT system shall be developed to send one time SMS reminder to
employees about HRA availment option after each transfer.]
%

[Sub:- Clarification Under Rule 4(4) of House Rent Allowance Rules, 1989
regarding admissibility of House Rent Allowance in matters of successful
completion of probation trainee period or drawal of pay in regular pay scale in case
of Probationer Trainees.
House Rent Allowance shall be admissible to those employees who apply within
one month of successful completion of their probationer trainee period or within one month
of drawal of pay in regular pay scale, as per the provisions laid down in Rule 4(4) of HRA
Rules, 1989.]
(5) In case of a Government servant who owns a house at a place of duty but
resides in a rented house instead, house rent allowance shall be paid in respect of the
rented house.

_________
1.

Existing sub-rule (4) of Rule 4 substituted vide Order No.F.6(4)FD/Rules/2017 dated 17.5.2023 with immediate effect for ''(4) The allowance shall be granted to a Government servant from the date of occupation of the rented/owned
accommodation, on making an application in accordance with the procedure prescribed under these rules; provided that if
the said application is not made within one month of the date of occupation of the accommodation or admissibility, the
allowance shall be admissible from the date of application.''

%Clarification No. F.6(4)FD/Rules/2017 dated 29-01-2020.

3

<!-- page 6 -->

2

[5. Rate of House Rent Allowance and classification of Cities/Towns:
(1) The House Rent Allowance to a Government servant if admissible under these
rules shall be granted within the corporation / municipal/urban agglomeration limits of places
mentioned in sub-rule (2) and at unclassified places at the rates indicated below:
Classification of Cities / Towns
Y
(Population criteria 5 Lac and above)
Z
(Population criteria below 5 Lac)

Rates of House Rent Allowance (per month)
1

[20%] of the Basic Pay i.e. the pay drawn in the
prescribed Levels in the Pay Matrix.
1

[10%] of the Basic Pay i.e. the pay drawn in the
prescribed Levels in the Pay Matrix.

(2) The classification of cities/towns for the purpose of grant of House Rent Allowance
under sub-rule (1) shall be as under :Cities Classified as 'Y'
1.
Bikaner (M.Corpn.),
2.
Jaipur (M.Corpn.),
3.
Jodhpur (UA),
4.
Kota (M.Corpn.),
5.
Ajmer (UA)]

Cities Classified as 'Z'
Remaining Cities / Towns and other places.]

______________
1. The existing rates of HRA revised from 16% and 8% to 18% and 9% for 'Y' and 'Z' class citiies respectively w.e.f. 1.7.2021
vide Order No.F.6(4)FD(Rules)/2017 dated 22.7.2021 and again revised from 18% and 9% to 20% and 10% respectively
vide Order No.F.6(4)FD(Rules)/2017 dated 30.10.2024 w.e.f. 01.11.2024.
2. Substituted vide FD Order No.F.6(4)FD(Rules)/2017 dated 30.10.2017 w.e.f. 1.10.2017 for %

[5. Rate of House Rent Allowance and classification of Cities/Towns:
(1) The House Rent Allowance to a Government servant if admissible under these rules shall be granted within the
corporation / municipal/urban agglomeration limits of places mentioned in sub-rule (2) and at unclassified places at the rates
indicated below:
Classification of Cities / Towns
Rates of House Rent Allowance (per month)
Y
(Population criteria 50-5 Lakhs)
20% of the Basic Pay i.e. total of pay in running pay band and grade
(Earlier classified as 'A', 'B-1' and 'B-2')
pay
Z
(Population criteria below 5 Lakhs)
10% of the Basic Pay i.e. total of pay in running pay band and grade
(Earlier classified as 'C' and unclassified)
pay
(2) The classification of cities/towns for the purpose of grant of House Rent Allowance under sub-rule (1) shall be as
under :Cities Classified as 'Y'
Cities Classified as 'Z'
Remaining Cities / Towns and other places.
1.
Bikaner,
2.
Jaipur,
3.
Jodhpur (UA),
4.
Kota (UA)
*[5.
Ajmer (UA)]
%
Substituted vide FD Order No. F.6(4) FD(Rules)/07, dated 12.9.2008 w.e.f. 1.9.2008.
*Inserted vide Order No.F.6(4)FD(Rules)/2007 dated 06.02.2009.
&

[5. Rate of House Rent Allowance and classification of Cities/Towns:

(1) The House Rent Allowance to a Government servant if admissible under these rules shall be granted within the
corporation / municipal/urban agglomeration limits of places mentioned in sub-rule (2) and at unclassified places at the rates
indicated below:
Classification of Cities / Towns
Rates of House Rent Allowance (per month)
A, B-1 and B-2
15% of actual Basic Pay plus Dearness Pay drawn
C
7.5% of actual Basic Pay plus Dearness Pay drawn
Unclassified
5% of actual Basic Pay plus Dearness Pay drawn
(2) The classification of cities/towns for the purpose of grant of House Rent Allowance under sub-rule (1) shall be as
under :&

Substituted vide FD Order No. F.7(2) FD(Rules)/98, dated 19.12.2004 w.e.f. 1.1.2005.

4

<!-- page 7 -->

1[Exception : Due to shifting of offices of employees outside Corporations/

Municipal/Urban Agglomeration Limits, the emoluments of such employees have been
reduced by revision of House Rent Allowance at lower rate. In such cases House Rent
Allowance at existing rates shall be continued to such employees and also to those
newly posted in the offices located within the aforesaid limits.]
2[Note : This provision shall automatically apply/cease to apply to areas which

may be included within/excluded from the limits of the named corporation/
municipal/urban agglomeration limits by the State Government, from the date of such
inclusion/exclusion.]
_____________________
1. Inserted vide Order No.F.6(4)FD/Rules/2007 dated 26.6.2018 w.e.f. 1.6.2018.
2. Inserted vide Order No.F.6(4)FD(Rules)/2017 dated 14.08.2025 with immediate effect.

__________________________________________________________________________________________________
'A' Class Cities
*1. Jaipur (UA)

'B-1' Class Cities
-----

'B-2' Class Cities
*1. Ajmer (UA)
2. Bikaner
3. Jodhpur
4. Kota (UA)

'C' Class Cities/Towns
1. Alwar (UA)
2. Bharatpur (UA)
3. Banswara (UA)
4. Beawar (UA)
5. Bundi
6. Barmer
7. Bhilwara
8. Baran
9. Badi (Bari)
10. Balotra
11. Churu (UA)
12. Chittorgarh
13. Chomu
14. Dholpur (UA)
15. Dausa
16. Fatehpur
17. Gangapur City (UA)
18. Ganganagar (UA)
19. Hanumangarh
20. Hindaun
21. Jhunjhunu
22. Jaisalmer
23. Kishangarh
24. Karauli
25. Kuchaman City
26. Ladnu
27. Makrana (UA)
*28. Mount Abu
29. Nagaur (UA)
30. Nawalgarh
31. Nimbahera
32. Pali
33. Ratangarh
34. Rajsamand
35. Sawaimadhopur (UA)
36. Sikar (UA)
37. Sardarsahar
38. Sujangarh
39. Suratgarh
*40. Tonk (UA)
41. Udaipur
*The existing classification has been retained for the purpose of payment of House Rent Allowance till further orders.

5

<!-- page 8 -->

6. Regulation of House Rent Allowance in different circumstances : The
drawal of House Rent Allowance shall be regulated as follows in the following cases :
1[(a) During Leave or Temporary Transfer: (1) A Government servant shall

be entitled to draw house Rent Allowance during. leave or temporary transfer at the
same rate at which he was drawing before proceeding on leave.
(2) 'Leave' means total leave of all kinds not exceeding 120 days and the first
120 days of the leave if the actual duration of the leave exceeds that period and in the
case of leave preparatory to retirement, privilege leave not exceeding 120 days taken
as leave preparatory to retirement, but does not include extra-ordinary leave, study
leave and refused leave/termin al leave whether running concurrently with notice
period or not. When vacation or holidays are combined with leave, the entire period of
vacation or holidays and leave should be taken as one spell of leave. The limit of 120
days shall be extended to 180 days' for the purpose of grant of this allowance in case
of grant of maternity leave in continuation of other leave.
_______________
1. Substituted vide Order No.F.6(4)FD/Rules/2017 dated 12.9.2024 with immediate effect for ''(a) During Leave or Temporary Transfer: A Government servant shall be entitled to draw House Rent Allowance during leave or
temporary transfer at the same rate at which he was drawing before proceeding on leave.
Note : 1. 'Leave' means total leave of all kinds not exceeding 120 days and the first 120 days of the leave if the actual duration of the
leave exceeds that period and in the case of leave preparatory to retirement, privilege leave not exceeding 120 days taken as leave preparatory to
retirement, but does not include extra-ordinary leave, study leave and refused leave/terminal leave whether running concurrently with notice period
or not. When vacation or holidays are combined with leave, the entire period of vacation or holidays and leave should be taken as one spell of
leave.
2. The limit of 120 days referred to in 'Note 1' shall be extended to 240 days for the purpose of grant of this allowance in case of a
Government servant suffering from T.B., Cancer, Leprosy or a Mental disease during the period of his leave taken on medical certificate from a
Senior or Junior Specialist or an officer of the Rajasthan Medical Service (Collegiate Branch), specialty in the disease, irrespective of the fact
whether the leave is on medical certificate from the very commencement or in continuation of other leave as defined in Note 1.
*
[3. The limit of 120 days referred a Note(1) shall be extended to 180 days for the purpose of grant of this allowance in case of grant of
maternity leave in continuation of other leave as defined in Note(1)]
*[4. 'Temporary transfer' means a transfer to duty in another station which is expressed to be for a period not exceeding four months. For
purposes of this rule it includes deputation. Subject to the limit of four months, the total house rent allowance, if the temporary duty is subsequently
extended beyond four months in all, will remain intact upto the date of the order of extension.''
*Inserted and renumbered vide order No. F6(4) FD (Rules)/07 dated 22.7.2010. This order shall come into force with immediate effect and
it shall also be applicable to those Government Servant who are already availing Maternity leave on the date of issue of this order.

___________________________________________________________________
&[5. Rate of House Rent Allowance and classification of Cities/Towns:

(1) The House Rent Allowance to a Government servant if admissible under these rules shall be granted within the corporation /
municipal/urban agglomeration limits of places mentioned in sub-rule (2) and at unclassified places at the rates indicated below:
Classification of Cities / Towns
Rates of House Rent Allowance (per month)
B-1 and B-2
15% of actual Basic Pay
C
7.5% of actual Basic Pay
Unclassified
5% of actual Basic Pay
(2) The classification of cities/towns for the purpose of grant of House Rent Allowance under sub-rule (1) shall be as under :'B-1' Class Cities
'B-2' Class Cities
'C' Class Cities/Towns
1. Jaipur (UA)
*1. Ajmer
1. Alwar (UA)
*2. Bikaner
2. Bharatpur (UA)
3. Jodhpur
3. Banswara (UA)
4. Kota
4. Beawar (UA)
5. Bundi
6. Barmer
7. Bhilwara
&
Substituted vide FD Order No. F.12(2) FD(Rules)/89, dated 08.03.1998 w.e.f. 1.1.1998.

Order No. F. l6(l)FD(Rules)/98

Dated: 17.2.1998

Consequent upon revision of Pay Scale of State employees w.e.f. 1.9.1996, the Governor has been pleased to order that
the Government servants shall continue to draw the following allowances and avail themselves of facilities etc. as per the
existing order on the basis of notional pay in the pre-revised scale till further orders :1. House Rent allowance, 2. Compensatory (City) Allowance, 3. Travelling Allowance, 4. Project Allowance and Desert
Allowance, 5. Medical facility, 6. Beas Project Allowance, 7. Deputation Allowance, 8. Dual Charge Allowance, 9. Honorarium,
10. House Building Advance, 11. Conveyance Advance.

6

<!-- page 9 -->

(3) The limit of 120 days and 180 days referred to in Clause (2) shall be
extended to 240 days for the purpose of grant of this allowance in case of a
Government servant suffering from T.B., Cancer, Leprosy or a Mental disease during
the period of his leave taken on medical certificate from a Senior or Junior Specialist
or an officer of the Rajasthan Medical Service (Collegiate Branch), speciality in the
disease, irrespective of the fact whether the leave is on medical certificate from the
very commencement or in continuation of other leave as defined in Clause (2).
(4) 'Temporary transfer' means a transfer to duty in another station, which is
expressed to be for a period not exceeding four months. For purposes of this rule it
includes deputation. Subject to the limit of four months, the total house rent allowance,
if the temporary duty is subsequently extended beyond four months in all, will remain
intact upto the date of the order of extension.
(5) Drawal of HRA during the period of leave in excess of first 120 days and
180 days availed of on grounds other than medical grounds mentioned in Clause (3)
above shall be subject to furnishing of the certificate prescribed in Annexure-B.]
(b) During Joining Time : (i) A Government servant shall be entitled to draw
house rent allowance during joining time at the same rates at which he was drawing
at the station from which he was transferred. Where, however, joining time is affixed
to leave, joining time shall be added to the period of four months/120 days referred to
in Note 1 below clause (a) above unless in any case it is otherwise expressly provided.

__________________________________________________________________________________________________
8. Baran
9. Churu (UA)
10. Chittorgarh
11. Dholpur
12. Fatehpur
13. Gangapur City (UA)
14. Ganganagar
15. Hanumangarh
16. Hindaun
17. Jhunjhunu
18. Kishangarh
19. Makrana (UA)
*20. Mount Abu
21. Nagaur
22. Nawalgarh
23. Pali
24. Ratangarh
25. Sawaimadhopur (UA)
26. Sikar
27. Sardarsahar
28. Sujangarh
29. Tonk (UA)
30. Udaipur
39. Suratgarh
29. Tonk (UA)
30. Udaipur
*The existing classification has been retained for the purpose of payment of House Rent Allowance till further orders.

7

<!-- page 10 -->

(ii) A Government servant who was in receipt of house rent allowance at his old
station and who, on transfer leaves his family behind at the old station because he
has not occupied a rented/own house or had not been allotted Government
accommodation at the new station, will be eligible for house rent allowance at the rate
at which it was drawn by him at the old station for a period of 6 months from the date
of his assumption of charge at the new station (irrespective whether the rate of house
rent allowance at the new station is lower than the rate at the old station) or till he
occupies a rented/own house or allotted Government accommodation at the new
station, whichever is the earliest.
1[(c) During Awaiting Posting Orders: A Government servant shall be entitled to

draw house rent allowance during the period of awaiting posting orders treated as duty
at the rate at which he was drawing immediately before relinquishing charge in the old
post.
Provided that if his salary is drawn from the same place on the place where he is
kept under Awaiting Posting Order then House Rent Allowance shall be allowed for
the same place as per terms and conditions of House Rent Allowance Rules, 1989.]
(d) During Training within India : A Government servant who is sent on training
in India and whose period of training is treated as duty under rule 7(8)(b)(i) of
Rajasthan Service Rules shall be entitled to draw house rent allowance during the
entire period of such training at the same rates at which he was drawing at the station
from which he proceeded on training subject to the conditions that (i) he continues to
keep his family at the place from which he proceeded on training (ii) if he does not
keep his family at the place from which he proceeded on training, but has not been
provided accommodation by the Training Institution either free or at the subsidised
rates.
__________________
1. The existing clause (c) of Rule 6 substituted vide Order No.F.6(4)FD/Rules/2017 dated 7.2.2024 with immediate effect for ''(c) During Awaiting Posting Orders : A Government servant shall be entitled to draw house rent allowance during the period
of awaiting posting orders treated as duty.''

___________________________________________________________________
1

[5. Rate of House Rent Allowance and classification of Cities/Towns:

(1) The House Rent Allowance to a Government servant is admissible under these rules within the corporation / municipal
limits/urban agglomeration limits at places mentioned in sub-rule (2), shall be granted at the rates indicated below:
Pay Range
(Basic Pay)

'B-1' and 'B-2'
Class cities
2
150/250/450/600/800/1000/-

1
(1) Below Rs. 950/(2) Rs. 950/- and above but below Rs. 1500/(3) Rs. 1500/- and above but below Rs. 2800/(4) Rs. 2800/- and above but below Rs. 3600/(5) Rs. 3600/- and above but below Rs. 4500/(6) Rs. 4500/- and above.

Rate per month in rupees
'C' Class cities
Other places
3
70/120/220/300/400/500/-

4
30/50/100/150/200/300/-

1. Substituted vide FD Order No. F.12(2) FD(Rules)/89, dated 12.08.1993 w.e.f. 1.6.1993.%
% Inserted vide FD Order No.F.12(2)FD(Gr.2)/89 dated 16.9.1993 - ''In partial modification of this department orders of even number dated
18.6.1991 and 12.8.1993, the Governor has been pleased to order that both the aforesaid orders shall be deemed to have come into force
with effect from 1.3.1991 instead of 1.6.1991 and 1.6.1993 respectively.
The arrears accrued as a result of issue of this order shall be credited to the General Provident Fund Account of the respective employees.''

8

<!-- page 11 -->

(e) During Training Abroad : A Government servant who is deputed for training
abroad by the State Government under various training schemes of Government or
operated through non-official channels as a Government sponsored candidate, the
house rent allowance shall be admissible during the entire period of training at the
same rates at which he would have drawn at the station from which he was deputed
for training abroad but for his deputation abroad in accordance with Government of
Rajasthan Decision No. 1 below Rule 51 of Rajasthan Service Rules.
3(f) (Deleted)
(g) During Suspension : A Government servant shall be entitled to draw house
rent allowance at the rates at which it was paid to him on the date of suspension
subject to fulfillment of conditions laid down in rule 53 (b) of Rajasthan Service Rules.
Note : 1. If the Headquarters of the Government servant under suspension are
changed in the public interest by orders of the competent authority, he shall be entitled
to get house rent allowance as admissible at the new station irrespective of the fact
whether he was getting house rent allowance on the date of suspension or not. The
house rent allowance shall be calculated with reference to pay he was drawing on the
date of suspension.
2. A Government servant under suspension who was in receipt of house rent
allowance and those headquarters are changed at his own request shall be entitled to
house rent allowance at the new station at the rates at which he was drawing house
rent allowance at the old station or as admissible at the new station, whichever is less.
__________________________
3. The existing clause (f) of Rule 6 deleted vide Order No.F.6(4)FD/Rules/2007 dated 22.9.2014 for ''(f)

During Re-employment : The drawal of house rent allowance shall be regulated as indicated below : (i) if the pay plus pension exceeds the maximum
pay of the post in which re-employed, the allowance shall be calculated on that maximum.
(ii) if the pay on re-employment is fixed without taking into account the entire amount of pension or part thereof the amount of pension so ignored
shall not be taken into account for the purpose of grant of house rent allowance.
(iii) in all other cases the allowance shall be calculated on pay plus pension.
Note : For the purpose of clause (f) 'pension' means gross pension including other retirement benefits, if any.''

__________________________________________________________________
(2) The classification of cities/towns for the purpose of grant of House Rent Allowance under sub-rule (1) shall be as under :'B-1' and 'b-2' class cities
1. Jaipur (UA)
2. Ajmer
3. Bikaner
4. Jodhpur
5. Kota (UA)

'C' class cities
1. Alwar (UA)
2. Bharatpur (UA)
3. Sawaimadhopur (UA)
4. Tonk (UA)
5. Banswara (UA)
6. Churu (UA)
7. Gangapur City (UA)
8. Makrana (UA)
9. Beawar (UA)
10. Ganganagar
11. Bundi
12. Jhunjhunu
13. Dholpur
14. Sikar
15. Nagaur
16. Pali
17. Barmer
18. Bhilwara
19.Udaipur
20. Chittorgarh
21. Baran
22. Hanumangarh
23. Sardarsahar
24. Ratangarh
25. Sujangarh
26. Nawalgarh
27. Hindaun
28. Fatehpur
29. Kishangarh
30. Mount Abu

9

Other places
Those not covered under column 1 & 2.

<!-- page 12 -->

7. Regulation of House Rent Allowance in case of Government servants
posted outside the State : The Government servants posted outside the State shall
be entitled to House Rent Allowance as follows :
(1) In cases where a Government servant posted outside the State is provided
with residential accommodation by the Government in a building taken by the
Government on hire or lease basis, he shall be required to pay rent at the rates laid
down under Rajasthan Civil Services (Determination and Recovery of Rent of
Residential Accommodation) Rules, 1958.
(2) Where the accommodation is not provided by the Government for residential
purpose, a Government servant shall be entitled to house rent allowance in
accordance with house rent allowance rules applicable to Central Government
servants or according to the house rent allowance rules of the State concerned,
whichever is advantageous to him.
8. Certificate : (1) Every Government servant shall furnish alongwith his first claim
for house rent allowance a certificate in the form given in 1[Annexure 'A']. If, however,
there is a change in any of the provisions of the certificate last given, resulting in
increase or decrease of the allowance payable to him, a fresh certificate should be
furnished as soon as the change occurs.
(2) The drawing and disbursing officer shall record the following certificate in
January and July on every establishment pay bill in which house rent allowance is
drawn by them :
'Certified that the Government servants for whom House Rent Allowance is drawn
in this bill have not been provided with Government accommodation.'
___________________________________________________________________
1

[5. Rate of House Rent Allowance and classification of Cities/Towns:

(1) The House Rent Allowance to a Government servant is admissible under these rules,shall be granted at the rates indicated
below:
Pay Range
(Basic Pay)

Rate per month in rupees
Within the
Within the Municipal limits of Ganganagar, Churu,
Other places not
Municipal limits alwar, Bharatpur, Sikar, Tonk, Pali, Barmer, Bhilwara,
covered under
of Jaipur
Udaipur, Kota, Bundi, Sawaimadhopur, Chittorgarh,
column 2 or 3.
including Amer &
Banswara, Jhunjhunu, Nagaur, Hanumangarh,
Sanganer, Ajmer,
Sardarshahar (Churu), Sujangarh (Churu), Fatehpur
Jodhpur &
(Sikar), Kishangarh (Ajmer), Beawar and Mount Abu.
Bikaner.
1
2
3
4
(1) Below Rs. 950/150/70/30/(2) Rs. 950/- and above but below Rs. 1500/- 250/120/50/(3) Rs. 1500/- and above but below Rs. 2800/- 450/220/100/(4) Rs. 2800/- and above but below Rs. 3600/- 600/300/150/(5) Rs. 3600/- and above but below Rs. 4500/- 800/400/200/(6) Rs. 4500/- and above.
1000/500/300/Note : (1) An existing employee who is in receipt of House Rent Allowance as on 31.12.1988 at a rate higher than the rate as above, would
continue to get House Rent Allowance at the rate applicable as on 31.12.1988 till he becomes entitled to a rate prevailing prior to
01.01.1989 or transferred to another station.
1. Substituted vide FD Order No. F.12(2) FD(Rules)/89, dated 18.06.1991 w.e.f. 1.6.1991 except Note 1.

10

<!-- page 13 -->

2[9. Procedure for grant of House Rent Allowance : (Deleted).
3

[Annexure-A (Deleted).

_____________
1. Substituted vide Order No.F.6(4)FD/Rules/2017 dated 17.5.2023 for - Annexure 'B' with immediate effect.
2. Rule 9 deleted vide Order No.F.6(4)FD/Rules/2017 dated 17.5.2023 with immediate effect ''9. Procedure for grant of House Rent Allowance : (1) Every Government servant who is eligible for grant of house rent allowance under these rules shall make an application
in the prescribed form given in Annexure 'A' to the Head of Office and if he is himself a Head of Office/Head of Department to the next higher administrative authority for sanction of House
Rent Allowance.
(2) The Head of Office/Head of Department shall invariably send a copy of the application form submitted by the Government servant to the authority competent to allot Government
accommodation so that the names of the Government servant is enlisted for the purpose of allotment of Government accommodation immediately. The house rent allowance shall be
sanctioned to the Government servant without waiting for non- availability certificate from the authority competent to allot residential accommodation.
These rules are issued in supersession of all earlier rules prevalent till date. Past cases will not be re-opened and pending cases shall be decided according to the rules prevalent at
that particular time.''

3. Annexure 'A' deleted vide Order No.F.6(4)FD/Rules/2017 dated 17.5.2023 with immediate effect ''Annexure 'A'
Application Form for Claiming House Rent Allowance in
Respect of Government Servants Living in Rented Accommodation or Own House.
1. Name
2. Designation & Department in which employed.
3. Pay : (i)
Pay as per Rule 2(1) of these rules.
(ii)
Pay plus pension (for re- employed persons only).
4.
(i)
Full address of the house.
(ii)
Whether rented or own.
5.
Details of accommodation (No. of rooms, Kitchen, W.C. and bath
Varandah etc. be shown separately).
6.
Amount of house rent allowance claimed as admissible under rules.
7.
Whether certificates required under rules are attached.
8.
Date of occupation of the accommodation.
Signature.........................
Designation.....................
Department.....................
Date
For use in the Office of Head of Office
Certified that:(1)
I have examined the claim for house rent allowance and I am satisfied that the claim is in accordance with the rules. The certificates prescribed by Government
have been obtained from the Government servant.
(2)
House Rent Allowance of Rs................. is hereby sanctioned.
Signature
(Head of office)
Date ..........................
Designation....................
No.............................
Date ...............................
Copy forwarded to XEN/Collector/Dy. Secretary, General Administrative Department, Jaipur for allotting Government accommodation, if available.
Signature .................................
Designation .............................''
_____________________________________________________________________________________________________________________________ ________
1

[5. Rate of House Rent Allowance and classification of Cities/Towns:

(1) The House Rent Allowance to a Government servant is admissible under these rules,shall be granted at the rates indicated
below:

Pay Range
(Basic Pay)

Rate per month in rupees
Within the
Within the Municipal limits of Ganganagar, Bikaner,
Municipal limits
Churu, alwar, Bharatpur, Sikar, Tonk, Pali, Barmer,
of Jaipur
Bhilwara, Udaipur, Kota, Bundi, Sawaimadhopur,
including Amer &
Chittorgarh, Banswara, Jhunjhunu, Nagaur,
Sanganer, Ajmer
Hanumangarh, Sardarshahar (Churu), Sujangarh
& Jodhpur.
(Churu), Fatehpur (Sikar), Kishangarh (Ajmer), Beawar
and Mount Abu.

1
(1) Below Rs. 950/(2) Rs. 950/- and above but below Rs. 1500/(3) Rs. 1500/- and above but below Rs. 2800/(4) Rs. 2800/- and above but below Rs. 3600/(5) Rs. 3600/- and above but below Rs. 4500/(6) Rs. 4500/- and above.

2
150/250/450/600/800/1000/-

3
70/120/220/300/400/500/-

1. Substituted vide FD Order No. F.12(2) FD(Rules)/89, dated 01.09.1990 (with immediate effect) except Note 1.

11

Other places not
covered under
column 2 or 3.

4
30/50/100/150/200/300/-

<!-- page 14 -->

*[5. Rate of House Rent Allowance and classification of Cities/Towns:
(1) The House Rent Allowance to a Government servant is admissible under these rules,shall be granted at the rates indicated
below:

Pay Range
(Basic Pay)

Rate per month in rupees
Within the
Municipal limits
of Jaipur
including Amer,
Sanganer &
Jodhpur.

1
(1) Below Rs. 950/(2) Rs. 950/- and above but below Rs. 1500/(3) Rs. 1500/- and above but below Rs. 2800/(4) Rs. 2800/- and above but below Rs. 3600/(5) Rs. 3600/- and above but below Rs. 4500/(6) Rs. 4500/- and above.

Within the Municipal limits of Ganganagar, Bikaner,
Churu, alwar, Bharatpur, Sikar, Tonk, Pali, Barmer,
Bhilwara, Udaipur, Kota, Bundi, Sawaimadhopur,
Chittorgarh, Hanumangarh, Sardarshahar (Churu),
Sujangarh (Churu), Fatehpur (Sikar), Kishangarh
(Ajmer), Beawar and Mount Abu.

2
150/250/450/600/800/1000/-

Other places not
covered under
column 2 or 3.

3
70/120/220/300/400/500/-

* FD Notification No. F. 12(2) FD (Gr.2)/89, dated 3.10.1989 with immediate effect.

12

4
30/50/100/150/200/300/-]

<!-- page 15 -->

1[Annexure 'A']

Certificates to be Furnished by a Government Servant who is
Applying for Grant of House Rent Allowance
Certified that:1. I am living in a rented house situated within municipal limits of ................................. (Name of
City/Town) and incurring some expenditure on rent/contributing towards rent.
2. The portion of accommodation in respect of which house rent allowance is claimed has not been
sub-let/has been sub-let and the monthly rent which is received is Rs......... p.m.
3. I am living in a house situated within municipal limits of................. (Name of City/Town) and owned
by me, my wife/husband/Children/ Father/Mother/Hindu undivided family in which, I am coparcener
and paying/contributing towards house or property tax or maintenance of the house.
4. I have not been provided with Government accommodation by the Central Government, State
Government or Autonomous public undertakings or Body or Corporation or Semi-Government
Organisation such as Municipalities etc.
5. I am not living in Government accommodation which has been allotted to another Government
servant.
Signature of the
Government Servant.

2[Annexure-'B'

CERTIFICATE
The Government servant concerned continued for the period for which House Rent Allowance
is claimed, to retain the house at the same station (whether within its qualifying limits or in an adjoining
area) I certify that I retained the accommodation for the period for whichHRAis being claimed at the
same station from where I was placed under suspension* or proceeded on leave/deputation
abroad/training/etc*.
Date:
Signature of the Govt.
Servant………………….
Name of the Govt.
Servant……………………..
Designation………………………………
………
*Strike out whichever is not applicable.

_______________
1. Annexure "B" named as Annexure "A" vide order No.F.6(4)FD/Rules/2017 dated 17.5.2023 with immediate effect.
2. Added vide Order No.F.6(4)FD/Rules/2017 dated 17.5.2023 with immediate effect.

13

<!-- page 16 -->

Important Orders
Order No. F.12(2)FD(Gr.2)/89

Dated: 5.11.1993

'Office Allowance' to the Patwaris of Revenue Department.
The Governor has been pleased to order that the Patwaris of Revenue Department who are eligible
for rent free 'Patwar Ghar' under proviso to sub-rule (2) of rule 12 of the Rajasthan Land Revenue (Land
Records) Rules, 1957, shall be allowed Office Allowance @ Rs. 30/- per month for hiring Patwar Ghar
in addition to the amount of House Rent Allowance admissible to them in accordance with the provisions
of House Rent Allowance Rules subject to the conditions:
(i)
(ii)

that Patwar Ghar has not been provided by the Government, and
one separate room is exclusively maintained by the respective Patwari for the purpose of official
work and keeping records. This order shall come into force with immediate effect.

Order No. F.12(2)FD(Gr.2)/89

Dated : 25.7.1998

'Office Allowance to the Patwaris of Revenue Department.
The Governor is pleased to order that existing rate of 'Office Allowance' of Rs.30/- per month
admissible to the Patwaris of Revenue Department, who are eligible for rent free Patwar Ghar under
proviso to sub-rule (2) of Rule 12 of the Rajasthan Land Revenue (Land Record) Rules, 1957, under
Finance Department Order of even number dated 5.11.1993 shall be revised to Rs. 90/- per month for
hiring Patwar Ghar in addition to the amount of House Rent Allowance admissible to them in accordance
with the provisions of House Rent Allowance Rules subject to the conditions:
(i)
(ii)

that Patwar Ghar has not been provided by the Government, and
one separate room is exclusively maintained by the respective Patwari for the purpose of official
work and keeping records.

This order shall come into force with immediate effect.

Order No. F.l.(32)FD(Rules)/78

Dated : 11.6.1998

Sub : Grant of House Rent Allowance to Government servants posted at various places outside
Rajasthan.
The State Government has revised the rates of house rent allowance payable to Government
servants from 1st January, 1998. Orders of revised rates of house rent allowance effective from 1st
January, 1998 have been issued by the State Government with respect to employees within the State.
2. With respect to Government servants posted at various places outside Rajasthan, in partial
modification to sub-rule (2) of Rule 7 of House Rent Allowance Rules, the Governor is pleased to order
that the revised rates of house rent allowance of Government of India or the concerned State
Government where the Government servant is posted, whichever is advantageous to the Government
servant, shall be admissible with effect from 1st January, 1998.

14

<!-- page 17 -->

Order No. F. 6(4)FD(Rules)/2007

Dated : 03.10.2013

Subject : - Office Allowance to the Patwaris of Revenue Department.
The Governor has been pleased to order that the existing rate of 'Office Allowance' of Rs. 90/per month admissible to the Patwari's of Revenue Department, who are eligible for rent free 'Patwar
Ghar' under proviso to sub-rule (2) of rule 12 of the Rajasthan Land Revenue (Land Records) Rules,
1957, under Finance Department order number F. 12(2)FD(Gr-2)/89 dated 25 July, 1998 shall be
revised to Rs. 1000/- per month for hiring Patwar Ghar in addition to the amount of House Rent
Allowance admissible to them in accordance with the provisions of House Rent Allowance Rules subject
to the following conditions :(i) that Patwar Ghar has not been provided by the Government and;
(ii) one separate room is exclusively maintained by respective Patwari for the purpose of Official
work ad keeping records.
This Order shall come into force with immediate effect.
Order No. F. 6(4)FD(Rules)/2007

Dated : 03.08.2023

Subject : - Office Allowance to the Patwaris of Revenue Department.
The Governor has been pleased to order that the existing rate of 'Office Allowance' of Rs. 1000/per month admissible to the Patwari's of Revenue Department, who are eligible for rent free 'Patwar
Ghar' under proviso to sub-rule (2) of rule 12 of the Rajasthan Land Revenue (Land Records) Rules,
1957, under Finance Department order number F.6(4)FD/Rules)/2007 dated 03-10-2013 is revised to
Rs. 1200/- per month for hiring Patwar Ghar in addition to the amount of House Rent Allowance
admissible to them in accordance with the provisions of House Rent Allowance Rules subject to the
following conditions :(i) that Patwar Ghar has not been provided by the Government and;
(ii) one separate room is exclusively maintained by respective Patwari for the purpose of Official
work and keeping records.
This Order shall come into force with effect from 01.07.2023.

Order No. F. 6(5)FD(Rules)/2024
Sub:

Dated : 02.12.2025

Review of payment of House Rent Allowance (HRA) and City Compensatory
Allowance (CCA) and recovery of Excess Payments.

It has come to the notice of the Finance Department during the analysis of salary payments for
the financial years 2023-2025 that several employees have been drawing payment of House' Rent
Allowance (HRA) and City Compensatory Allowance (CCA) incorrectly, in violation of the provisions
contained in the respective applicable rules.
Accordingly, the matter has been considered and the Governor is pleased to order that 1. Employees should be posted on the post for which creation has been made by the
Government and their salary including allowances should be charged against that post only.
2. If Departments have posted employees at locations where no sanctioned posts exist and the
salary has been drawn for them from elsewhere, in such cases the excess irregular payment of
allowances, if any, made to the Government servants by the Department (HOD) shall be recoverable.
3. In cases where HOD consider it necessary in public interest that employee of particular post
should be posted elsewhere, in that case the approval for the creation of posts should be taken in
advance with the concurrence of Finance Department for that iocation, where employee has to be
posted and the existing post outside that place should be got abolished.
__________

15
