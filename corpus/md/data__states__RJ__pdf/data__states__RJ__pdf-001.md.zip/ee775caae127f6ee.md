---
doc_id: "ee775caae127f6ee"
source_url: "https://forest.rajasthan.gov.in/content/dam/raj/forest/ForestDepartment/PDFs/Department%20Wing/CAMPA/Notifications/Notification%20of%20CAMPA%20dt%2014.09.2018.pdf"
ministry: "Forest Department, Rajasthan"
title: "Notification of CAF Rules 2018"
date: ""
pages: 4
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "8ba1a132e56da25c"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (ii)
PART II—Section 3—Sub-section (ii)
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 3692]

ubZ fnYyh] 'kqØokj] flrEcj 14] 2018@Hkkæ 23] 1940

No. 3692]

NEW DELHI, FRIDAY, SEPTEMBER 14, 2018/BHADRA 23, 1940

पयावरण, वन और जलवायु परवतन मं ालय
अिधसूचना

नई दली, 14 िसत बर, 2018
के ीय सरकार, ितकरामक वनरोपण िनिध अिधिनयम, 2016 (2018 का 38) क धारा 8 क उप-

का.आ. 4855(अ).—
धारा (1)

ारा दत शिय का योग करते ए, 30 िसत बर, 2018 को ‘‘रा!"ीय ितकरामक वनरोपण िनिध बंधन और योजना

ािधकरण’’ नाम से &ात रा!"ीय ािधकरण के गठन क तारीख के 'प म) िनयत करती है।
[फा.सं. 11-100/2015-एफसी (खंड III)]
दीपक कुमार

िसहा, वन महािनरी+क

MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE
NOTIFICATION
New Delhi, the 14th September, 2018
S.O. 4855(E).—In exercise of the powers conferred by sub-section (1) of section 8 of the Compensatory
Afforestation Fund Act, 2016 (38 of 2018), the Central Government hereby appoints the 30thday of September, 2018, as
the date of constitution of a National Authority to becalled the “National Compensatory Afforestation Fund Management
and Planning Authority”.
[F. No. 11-100/2015-FC (Vol. III)]
DEEPAK KUMAR SINHA, Inspector General of Forest

5464 GI/2018

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अिधसूचना
नई

दली, 14 िसतंबर, 2018

के ीय सरकार, ितकरामक वनरोपण िनिध अिधिनयम, 2016 (2018 का 38) क धारा 10 क
उप-धारा (1) ारा दत शिय का योग करते ए, 30 िसत बर, 2018 को ‘‘रा,य ितकरामक वनरोपण िनिध बंधन और योजना
ािधकरण’’ नाम से &ात रा,य ािधकरण के गठन क तारीख के 'प म) िन निलिखत रा,य और संघ रा,य +े- म) िनयत करती है।
का.आ. 4856 (अ).—

.सं.

राय ािधकरण का नाम

राय/संघ राय े

(1)

(2)

(3)

1.

आ/ देश ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

2.

अ'णाचल देश ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

3.

असम

ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

असम

4.

िबहार

ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

िबहार

5.

छतीसगढ ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

छतीसगढ़

6.

गोवा

ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

गोवा

7.

गुजरात

8.

ह3रयाणा ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

9.

िहमाचल

10.

झारखंड

ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

झारखंड

11.

कना4टक ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

कना4टक

12.

केरल

ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

केरल

13.

म6य देश ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

म6य देश

14.

महारा!" ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

महारा!"

15.

मिणपुर

ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

मिणपुर

16.

मेघालय

ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

मेघालय

17.

िमजोरम

ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

िमजोरम

18.

ओिडशा

ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

ओिडशा

19.

पंजाब

20.

राज8थान ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

राज8थान

21.

िस:म ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

िस:म

22.

तिमलनाडु

23.

तेलंगाना

24.

ि-पुरा ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

25.

उतर देश ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

उतर देश

26.

उतराखंड ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

उतराखंड

27.

पि=म बंगाल ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

पि=म बंगाल

ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण
देश ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण

आ/ देश
अ'णाचल देश

गुजरात

ह3रयाणा
िहमाचल

देश

पंजाब

तिमलनाडु

तेलंगाना

ि-पुरा

<!-- page 3 -->

¹Hkkx IIµ[k.M 3(ii)º
28.

29.
30.

31.

Hkkjr dk jkti=k % vlk/kj.k

3

ीप समूह ितकरामक वनरोपण िनिध बंधन और योजना
ािधकरण
चंडीगढ़ ितकरामक वनरोपण िनिध बंधन और योजना ािधकरण
अंडमान एवं िनकोबार

रा!"ीय राजधानी +े- दली ितकरामक वनरोपण िनिध बंधन और योजना
ािधकरण
दादरा नगर हवेली ितकरामक वनरोपण िनिध बंधन औरयोजना ािधकरण

अंडमान एवं िनकोबार

ीप समूह

चंडीगढ़

रा!"ीय राजधानी +े- दली
दादरा नगर हवेली

[फा.सं. 11-100/2015-एफसी (खंड III)]
दीपक कुमार

िसहा, वन महािनरी+क

NOTIFICATION
New Delhi, the 14th September, 2018
S.O. 4856(E).—In exercise of the powers conferred by sub-section (1) of section 10 of the Compensatory
Afforestation Fund Act, 2016 (38 of 2018), the Central Government hereby appoints the 30th day of September, 2018, as
the date of constitution of State Authorities, to be called the “State Compensatory Afforestation Fund Management and
Planning Authority”in the following States and Union territories :—
S.N.
(1)

Name of State Authorities
(2)

States /Union territories
(3)

1

The Andhra Pradesh Compensatory Afforestation Fund
Management and Planning Authority

Andhra Pradesh

2

The Arunachal Pradesh Compensatory Afforestation Fund
Management and Planning Authority

Arunachal Pradesh

3

The Assam Compensatory Afforestation Fund Management and
Planning Authority

Assam

4

The Bihar Compensatory Afforestation Fund Management and
Planning Authority

Bihar

5

The Chhattisgarh Compensatory Afforestation Fund Management
and Planning Authority

Chhattisgarh

6

The Goa Compensatory Afforestation Fund Management and
Planning Authority

Goa

7

The Gujarat Compensatory Afforestation Fund Management and
Planning Authority

Gujarat

8

The Haryana Compensatory Afforestation Fund Management and
Planning Authority

Haryana

9

The Himachal PradeshCompensatory Afforestation Fund
Management and Planning Authority

10

The Jharkhand Compensatory Afforestation Fund Management and
Planning Authority

Jharkhand

11

The Karnataka Compensatory Afforestation Fund Management and
Planning Authority

Karnataka

12

The Kerala Compensatory Afforestation Fund Management and
Planning Authority -Kerala

Kerala

13

The Madhya Pradesh Compensatory Afforestation Fund
Management and Planning Authority

14

The Maharashtra Compensatory Afforestation Fund Management
and Planning Authority

Maharashtra

15

The Manipur Compensatory Afforestation Fund Management and
Planning Authority

Manipur

Himachal Pradesh

Madhya Pradesh

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

16

The Meghalaya Compensatory Afforestation Fund Management
and Planning Authority

Meghalaya

17

The Mizoram Compensatory Afforestation Fund Management and
Planning Authority

Mizoram

18

The Odisha Compensatory Afforestation Fund Management and
Planning Authority

Odisha

19

The Punjab Compensatory Afforestation Fund Management and
Planning Authority

Punjab

20

The Rajasthan Compensatory Afforestation Fund Management and
Planning Authority

Rajasthan

21

The Sikkim Compensatory Afforestation Fund Management and
Planning Authority

Sikkim

22

The Tamil Nadu Compensatory Afforestation Fund Management
and Planning Authority

Tamil Nadu

23

The Telangana Compensatory Afforestation Fund Management and
Planning Authority

Telangana

24

The Tripura Compensatory Afforestation Fund Management and
Planning Authority

Tripura

25

The Uttar Pradesh Compensatory Afforestation Fund Management
and Planning Authority

Uttar Pradesh

26

The Uttarakhand Compensatory Afforestation Fund Management
and Planning Authority

Uttarakhand

27

The West Bengal Compensatory Afforestation Fund Management
and Planning Authority

West Bengal

28

The Andaman and Nicobar Islands Compensatory Afforestation
Fund Management and Planning Authority

Andaman and Nicobar Islands

29

The Chandigarh Compensatory Afforestation Fund Management
and Planning Authority

Chandigarh

30

The National Capital Territory Delhi Compensatory Afforestation
Fund Management and Planning Authority

National Capital Territory Delhi

31

The Dadra Nagar Haveli Compensatory Afforestation Fund
Management and Planning Authority

Dadra Nagar Haveli
[F. No. 11-100/2015-FC (Vol. III)]

DEEPAK KUMAR SINHA, Inspector General of Forest

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
Digitally signed
by ALOK KUMAR
Date: 2018.09.20
14:48:08 +05'30'

ALOK
KUMAR
