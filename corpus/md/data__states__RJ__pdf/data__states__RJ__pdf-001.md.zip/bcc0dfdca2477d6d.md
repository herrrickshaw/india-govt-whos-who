---
doc_id: "bcc0dfdca2477d6d"
source_url: "https://www.rsmm.com/filesrsmm/oo-122-22052026.pdf"
ministry: "Rajasthan State Mines and Minerals Limited, Rajasthan"
title: "Office Order No. RSMM/CO/Pers/2(72)/2025-26 -122 dated 22.05.2026 Regarding Final list of eligible applicants for the promotion of workmen from category IX/IX-S to E-1 category of executive posts."
date: ""
pages: 10
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "6d3334a779ba9fcb"
---

<!-- page 1 -->

fa
Rajasthan State Mines & Minerals Limited
(A Government of Rajasthan Enterprise)
Corporate Office : 4, Meera Marg, Udaipur - 33 004
Registered Office : C-89-90, Lal Kothi Scheme, Jaipur, CIN-U409RJ949SGC000505,
Phone : 0294-2428763/64/65/66/67, Fax : 0294-2428770/2428739
e-mail : info.rsmml@rajasthan.gov.in, Website: www.rsmm.com
Ref;- RSMM/CO/Pers/2(72)/2025-26- /.22. Datew2.05.2026
NOTICE
Vide our earlier Notice no. RSMM/CO/Pers/2(72)/2025-26-08 dated 6.05.2025,
applications were invited from the interested workmen working in category [X/IX-S
possessing requisite qualification and experience as per RSMML (Recruitment &
Promotion of workmen from category IX/IX-S to E-l category of executive posts) rules,
202.
The final list of eligible applicants with discipline wise syllabus for written exam is hereby
published for information to all. The date of written exam will be informed separately.
This bears approval of competent authority.
Encl: - As above
(Kirti Rathore) RAS
Executive Director (Admin)
Copy to;
l. PS to MD, for kind information. Signed by: Kirti
2. F.A, CO. Rathore, Executive
3. All SBU Heads Director
4. Notice Board, SBU (RP/Gyp/LS/Lig./CO) Date: 2026-05-22
5. DGM(LT,).CO for website. SE aloe a
6. Delhi office/ R.O., Jaipur
7. Concern file/Master file.
Executive Director (Admin)
RajKaj Ref No.:
22088428

<!-- page 2 -->

Eligibilty List as per Notice No. RSMM/CO/Pers./2(72)/2025-26 - 408 dated 6.05.2025
applied for |Category IX/IX-S
ia Ped
Ramesh Kamra
हि 950. Bansilal Kalasua S/o Sh. P| Sr. Analyst w-9 [08.04.207 B.Sc. with Chemistry
Ramji
Sh. Zakir Hussain S/o Sh. Fazal | IT cocp [Sr. COCP ७.95 42.0.3995 Corporate Office 8.5०.
Hussain Diploma in System Analysis and Data
processing
"A’ level Diploma from DOEACC

<!-- page 3 -->

रू SYLLABUS FOR PERSONNEL & STLEABUS FOR PERSONNEL & ADMINISTRATION- > 7 | &
See PVN PEROUNNEL & ADMINISTRATION- .
(From workmen Category to E-4 cadre) ,
4. Industrial Dispute Act, 947: हु
i. Machineries of settlement of industrial Dispute.
ii, Notice of Change.
ili, Strike, Lock-out, Lay-off, Retrenchment.
; iv. Unfair Labour Practices.
v. Condition of Service etc. to remain unchanged under certain circumstances
during pendency of proceedings.
vi. Works Committee.
oO:
2. Mines Act, 4952:
i. Appointment of L.W.O. Health & Sanitation, First Aid, Welfare amenities, Safety
measures under the provisions of Mines Act. ;
ii. Administrative machinery for implementation of the Mines Act.
ili, Statutory Registers required to be maintained under Mines Act, Leave with
wages. है
3. Workmen's Compensation Act, 923:

८3, i. Employees liability for compensation, amount of compensation, method of
calculating compensation, distribution of compensation, procedure to notify fatal
accidents, and compensation payable including eligible death cases.

4. Industrial Employment (Standing Order) Act, 7946:
i. Objects and scope of standing orders in the industrial units, Applicability of
Standing Orders in RSMM.
5. Shops & Establishment Act:
i. Registration under the Act.
: il. uy Maintenance of Statutory Registers and Returns.
छा

<!-- page 4 -->

_ 9. Payment of Wages Act: f
है i. Definitions ((3)
ii. Authorised and unauthorised deduction, Maintenance of Registers and Records
under the Act.
7, Contract Labour (Regulation & Abolition) Act, 4970
8. Trade Union Act, 4926
9. General Knowledge:
i, Origin and growth of RSMML with special reference to its various expansion
o) ) programmes and activities.
ii. Type of leave applicable to employees (executive and non-executives) of RSMML
and the rules. Complete procedure of leave encashment as per rules of RSMML.
iil, Disciplinary proceedings right from the issue of charge sheet to award of
punishment as per Rules Provisions of suspension, and its regulation relating to
payment of subsistence allowance and Disciplinary Proceedings.
{0. Administration:
|. Broad scope of functions and responsibilities in the General Administration
Department, including office Administration, employee welfare etc.
©: ii, Items required for establishing office, purchase, distribution of items, keeping
record, stock verification.
ii, Entitlement of uniforms, shoes, safety items, and the system of its distribution.
iv. Classification of quarters in the township, and the method of allotment of
quarters.
v. Authority and procedure involved in registration of vehicles.
vi. System of maintaining Log-books of vehicles, and its purpose.
vi. Different communication systems and its utility.
vil. Maintenance of records for assets & their physical verification.
ix. Security-cum-vigilance in RSMM. rs
॥ , Anda noe
at. ॥ ve
ae (

<!-- page 5 -->

44. Medical Rules & T.A. Rules: Preparation of T.A. Bills, different modes of travel and ra
‘entitlement, exceptions, admissibility and reimbursement of taxi charges, mode of
calculation of daily allowance, entitlement on transfers, rules regarding conveyance of
personal effects, admissibility of T.A., 0.8, on superannuation/ retirement, working ,
knowledge of Medical Rules & their applicability,
(2. Office Procedures: है
i. Classification of documents
ii, Receipt, registration and distribution of classified documents.
iil, Filing system.
iv. Duties of aP.A. -
fo) ) v. Movement of files, priority marking, linking of files, change of files, part files.
vi. Filing of official, demi-official and unofficial communications.
vi. Different forms of communications,
43, RSMML Rules: (General Knowledge) .
(a) EPF/PF Rules, Gratuity Rules, Social security Scheme, HBL, Conveyance Loan,
Voluntary Retirement Scheme, Medical Attendance Rules.
(0) Standing Orders/Service Rules
(c) Mis-conduct under standing orders/ Service Rules
(d) Procedure of Domestic Enquiry.
oF
4g 7 ( “46, 330. ७9००-
PR qngep 3८8 (FR) BGM LP FH)
“ml ty)

<!-- page 6 -->

हे SYLLABUS ee B/
FINANCE & ACCOUNTS DEPARTMENT an
4. Arithmetic (Practical):
Unit system, Percentage, Profit & Loss, Time & Distance, Time & Work, Interest.
2. Store Accounting: Different proformas of Stores, Stores Accounting, Inventory,
Pricing & Issue System- their types and method followed in the Company,
Valuation of closing stock.
3. Depreciation: Its methods and applications.
4. P.F. Act, Family Pension Act, Group Insurance & Gr. Gratuity, P.F. loan system
prevailing in the Company.
'¢ 5. Imprest System of Cash Book - its advantages and disadvantages with practical
कक applications.
6. All types of Company's Rules such as Employees Advance, Festival Advance,
Building Loan Advance, Conveyance Advance, Social Security, Travelling
Allowance, Medical rules, Leave etc.- with their practical applications,
7. Cash Book, Journal, General Ledger, Subsidiary Ledgers with practical
applications, rectification of errors.
8. Preparation of Bank Reconciliation statements.
9. Definitions:
८ Bank Reconciliation Statement, Double Entry & Single Entry System, Inventory,
७) Bin Card, Job Card, FIFO, LIFO, Weighted Average method of pricing; Golden
System of Accounting, Contra Entry, Cut off date, indent, Quotation, Purchase
Order, Letter of Credit, Cash Discount, Trade Discount, Rebate, B.S.R., SRV,
S.D.R., Letter of Enquiry, Equity share Capital, Joint Costs, Provisions, Reserves,
Bills of Exchange, Bills of Lading, Bills of Material,
40. Tax Calculations for the salaried personnel (Practical Applications)
4. Commercial Correspondence a
2. Preparation of Account Current with practical applications,
43. Bonus Act and apptication to the employees of the Company.
44, Knowledge regarding production incentive scheme applicable to in RSMM,
Welfare measures for the employees and various loans and advances from the
Company. Quy ३०२७ Le [908 (९. ((०

<!-- page 7 -->

४ 45. Provisions and present scheme applicable in RSMML for P.F, Gratuity, Group (99%
Insurance, and Social Security Scheme. €
6. Theory of Accounting, single and double entry system, ledger trial balance,
manufacturing trading, Profit & Loss Account, Profit and Loss Appropriation Account,
Distribution between capital and revenue expenditures, Depreciation Reserves and
Provision Balance Sheet.
॥7. General Knowledge regarding Accounting, Costing, Auditing of the organisation.
8. Execution of tender, Examination of various purchase/ repair proposals.
i9. Central Goods & Service tax (CGST) Act, 2047 and Integrated Goods and
Service Tax (IGST) Act, 207.
20. Medical Rules of Company.
7 24, Royalty, DMF, NMET applicable on various products,
eo) 22.RSMML Rules: (Gemsral knowlege )
(a) EPF/PF Rules, Gratuity Rules, Social Security Scheme, HBL, Conveyance
Loan, Voluntary Retirement Scheme, Medical Attendance Rules.
(b) Standing Orders/Service Rules .
(c) Mis-conduct under standing orders/ Service Rules
(d) Procedure of Domestic Enquiry.
Mone ( one. ee
मी Galas शशि कद notte)
Bam (4) 4 (६4४ ७८७० ९ #>८)

<!-- page 8 -->

4 SYLLABUS FOR LABORATORY DISCIPLINE oe
(From workmen Category to E-i cadre)
|. Basic knowledge of Analytical Chemistry mainly in reference to the theoretical basis of
quantitative inorganic analysis.
2. Volumetric analysis- Aqueous acid-base titration, oxidation-reduction titrations
including iodimetry and iodimetry titrations, complexeometry (Largely EDTA) titrations,
Numerical questions based on the volumetric analysis.
3. Gravimetric analysis including the related numerical problems.
4, Classical and instrumental methodology, based problems including numerical
( questions in the analysis of following, and reporting of analysis results as per
(@) हु requirement:
(a) Rock Phosphate
(b) Lime Stone
(c) Dolomite :
(d) Magnesite
(e) Gypsum : हु
(f) Lime
(g) Alum है
(h) Phosphoric Acid
(i) Sulphuric Acid
(j) Sodium Oleate
(3 (k) Water (Chemical & Bacteriological examination)
८53 ) (I) Cast iron & steel for carbon, silicon, sulphur, manganese, phosphorus, arsenic,
chromium, tungsten, vanadium, molybdenum
(m) Bleaching Powers and ;
(n) Chlorine demand for Water है
(0) Lignite है हे
5. Principle, washing and use of following laboratory equipments:
(a) Spectrophotometer
(b) Flame Photometer
(c) pH meter
(d) Conductivity Meter
(e) Alomic absorption spectrophotometer
(f) Water-De-mineralize Plant. .
a 2029 ( Wes, 220

<!-- page 9 -->

‘ 6. RSMML Rules: (General Knowledge) es
: (a) EPF/PF Rules, Gratuity Rules, Social security Scheme, HBL, Conveyance Loan,
Voluntary Retirement Scheme, Medical Attendance Rules.
(b) Standing Orders/Service Rules
(०) Mis-conduct under standing orders/ Service Rules
(d) Procedure of Domestic Enquiry.
al, Nos.
He के fe “a Las 2 NZ \2020
27 ~
spt) [R.Gclis) Laa-sstaxya)
aus Passer DOM (8१) D&M ३०)
an ( toy)
Py
०

<!-- page 10 -->

SYLLABUS FOR SYSTEM ENGINEERING DISCIPLINE E-7 CADRE &
है i‘ ¢
(From workmen Category to ६£- cadre)

4. Reasoning Test & Numerical Analysis & General Knowledge
Problem solving, Data Interpretation, Data Sufficiency, Logical Reasoning, Mental
Ability and Analytical Reasoning. General Knowledge and Current Affairs relating & ॥४७४०७०४
ja.India and Rajasthan. Major Development in the field of Information
Technology.

2. Overview of the Computer System : input-output devices, pointing devices, and
scanner.
Word Processing(MS-Word), Spread Sheet Software( MS-Excel), Presentation
Software(MS Power Point), DBMS Software , FoxPro, MS-Access ,ORACLE. ©

B)
० ! 3. Number System: Representation of Data (Digital Versus Analog, Number

System — Decimal, Binary).

4. Computer Networking & Security: Introduction to Internet and email , LAN, MAN,

; WAN, Search Engines. :

Network Topologies: Bus, Star, Ring, Mesh, Tree, Hybrid Topology.
Introduction and basics of TCP/IP Networks , DNS, DHCP, DMZ and Firewalls.

5. Data Base Management Systems: Basic database concepts, Entity Relationship
modeling(ER-Modeling). ;
Database design: Database, Tables, procedures, triggers.

fe) ’ Structured Query Language (SQL) DDL, DML, DCL statements.

6. Programming Concepts Introduction:
Algorithms for Problem Solving, Introduction to Principles and Programming
Techniques: Variables and assignments, Input and Output, Data Types and

Expressions, Flow of control, Local variables.
Introduction of Object Oriented Programming (OOPs) concepts. : Classes
Classes, Objects, Encapsulation, Information hiding, Method, and Instances,
Polymorphism, Inheritance, Exceptions and Exception Handling.

7. Web Technology: Introduction to HTML, Tag and Attributes, Text Styles and Text
Arrangements, Color and Background of Web Pages, List and their Types,
Attributes of Image Tag. Hypertext, Hyperlink and Hypermedia, Links, Anchors
and URLs Creating table, Frame, Form and Style Sheet. Basics of FTP, HTTP,
HTTP he

alte UME wore (
aw
