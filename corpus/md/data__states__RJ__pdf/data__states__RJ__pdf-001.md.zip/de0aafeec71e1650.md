---
doc_id: "de0aafeec71e1650"
source_url: "https://petroleum.rajasthan.gov.in/writereaddata/images/RajasthanCGDPolicy2025.pdf"
ministry: "Directorate of Petroleum, Rajasthan"
title: "Rajasthan CGD Policy 2025"
date: ""
pages: 40
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f2172e47e8c06998"
---

<!-- page 1 -->

Sp4Hjc5: 4.10(6)A1H/y4-1/2013 YI¢ 1

Ggr f0E:1 6 JUL Z025

HHuS 3HI^II Sh4H|c5: S. 52/HH./2025 f

15.07.2025 >

<!-- page 2 -->

<!-- page 3 -->

Government of Rajasthan

RAJASTHAN
CITY GAS DISTRIBUTION
POLICY 2025

<!-- page 4 -->

I am pleased to present the Rajasthan City Gas Distribution
(CGD) Policy 2025, a progressive and future-ready initiative
designed to promote the widespread adoption of clean,
efﬁcient, and environmentally sustainable energy across our
State. This policy aligns with India's COP-26 commitments
and reinforces our collective vision for inclusive and
sustainable development.
Natural gas, as a clean and efﬁcient energy source, holds
tremendous potential to reduce emissions, improve public
health outcomes, and enhance the competitiveness of our
industries. Through a structured and time-bound framework,
this policy aims to accelerate the development of CGD
infrastructure across Rajasthan, facilitating faster statutory
approvals and ensuring reliable access to Piped Natural Gas
(PNG) and Compressed Natural Gas (CNG) for households,
businesses, and the transport sector.
The policy has been shaped by valuable feedback and
suggestions received from investors and stakeholders.
Notably, during the Rising Rajasthan Global Summit 2024,
eight MoUs worth Rs. 8,740 crore were signed between the
Government of Rajasthan and various investors for the
expansion of the CGD network.
As we advance towards a resilient and inclusive energy future,
this policy reﬂects our unwavering commitment to building a
dynamic, sustainable, and prosperous Rajasthan. It
represents a crucial step in realizing our vision of a ‘Viksit
Rajasthan’, in alignment with the national aspiration of ‘Viksit
Bharat by 2047’.

BHAJAN LAL SHARMA
Chief Minister, Rajasthan

<!-- page 5 -->

INDEX
1. Introduction

5

2. Vision

5

3. Objectives

5

4. Targets

6

5. Policy Features

6

5.1 Duration

6

5.2 Applicability

6

5.3 Permissions/Clearances from Local Bodies

7

5.4 Adoption of CNG

17

5.5 Safety Measures for CNG Vehicles

18

5.6 Use of Natural Gas in Industries and Commercial Segments to
Control Pollution

18

5.7 Allotment of Land for Development of Compressed
Biogas Plants

19

5.8 Inclusion of PNG Pipelines/Networks at Time of Approval
of Building Plan

20

5.9 Organisational Set up

20

5.10 Obligations of the CGD Entities

24

6. Implementation and Review

27

Annexure

28

A. City Gas Distribution Network

28

B. Technical Requirements for the Development of the CGD

28

C. Flow Chart of Approvals

32

D. District Magistrate (DM) NOC for CNG Stations

33

E. Timeline of Permissions for Pipe Laying

33

F. Deﬁnitions

35

G. List of Applicable Fees, Charges, and Rates

37

H. List of CGD Entities

38

<!-- page 6 -->

1 INTRODUCTION
The Petroleum and Natural Gas Regulatory Board (PNGRB), Government of
India, has launched the City Gas Distribution (CGD) initiative to promote the
use of natural gas and increase its share in the country’s energy mix from 6.7%
in 2023 to 15% by 2030, thereby enhancing efﬁciency and reducing emissions.
The Rajasthan City Gas Distribution Policy 2025 aims to strengthen gas pipeline
infrastructure to address the growing energy needs in line with the
commitments made at COP-26.

2 VISION
The Rajasthan CGD Policy 2025 aims to establish a robust CGD network,
ensuring reliable and safe access to clean energy for households, industries,
and transportation in the State.

3 OBJECTIVES
1. Facilitate the rapid development of CGD infrastructure, expand access to
Piped Natural Gas (PNG) and Compressed Natural Gas (CNG) across
sectors, and encourage the adoption of natural gas as a clean and green
energy source.
2. Establish a standardised, uniform, and time-bound framework for
permissions, clearances, and charges to streamline operations and attract
investments.
3. Encourage CGD entities to collaborate with local bodies in developing
Compressed Biogas (CBG) plants and supporting initiatives under Swachh
Bharat Abhiyan.

Rajasthan CGD Policy 2025

05

<!-- page 7 -->

4. Expand access to PNG for domestic, industrial, and commercial sectors and
CNG for transport, focusing on non-attainment cities, smart cities and the
National Capital Region in Rajasthan.

4 TARGETS
Rajasthan is divided into 17 Geographical Areas (GAs) authorised to 13 entities
with deﬁned Minimum Work Programme (MWP) for CGD network. The targets
upto 31 March 2029 are deﬁned below.
1. ~79.71 lakh Domestic Piped Natural Gas (DPNG) connections.
2. Development of ~1019 CNG stations, ensuring accessibility to the transport
sector.
3. Laying of ~34,877 inch-kilometre steel pipeline infrastructure.

Piped Cooking Gas
Connections: 79.71 Lac

CNG Stations:
1019

Steel Pipeline:
34,877 in-km

5 POLICY FEATURES
5.1 Duration
The Rajasthan CGD Policy will take effect from its ofﬁcial publication and
remain in force till 31 March 2029, or until a new policy is introduced.

5.2 Applicability
This Policy applies to all land-and road-owning agencies, including, but
06

Rajasthan CGD Policy 2025

<!-- page 8 -->

not limited to, Municipal Corporations, Municipal Councils, Municipal
Boards in a municipal area, RIICO and other industrial bodies, the
Rajasthan Housing Board, Development Authority, or Urban
Improvement Trust in an urban area declared under relevant law and
Gram Panchayat for rural areas PWD, and all statutory authorities such as
the Transport Department, Department of Industries, and Rajasthan State
Pollution Control Board.

5.3 Permissions/Clearances from Local Bodies
Natural Gas is acknowledged as an essential utility by the Central
Government, alongside water and electricity. The Rajasthan CGD Policy
2025 establishes a framework aimed at increasing CGD network coverage
and streamlining local permission processes.
DEVELOPMENT OF CGD PORTAL
1.

The CGD Portal will be developed to enable online submission of
applications, processing, and approval of permissions.

2.

Rajasthan State Gas Limited (RSGL) will serve as the nodal agency
for coordination with the Department of Information Technology
and Communications (DoIT&C) in Rajasthan to develop and
maintain the Portal.

3.

The cost of CGD Portal development and annual maintenance will
be evenly distributed among 17 geographic areas.

4.

The CGD Portal will be linked to single window clearance system in
due course.

5.3.1 Application Process for Laying Underground Gas Pipeline
1. The CGD Entity will obtain necessary permissions from the
concerned authorities to lay underground gas pipelines for all
types of roads, including those within the defect liability period.
Online application will be submitted in the proposed CGD Portal.
2. A nodal ofﬁcer will be appointed at each relevant land-or road-

Rajasthan CGD Policy 2025

07

<!-- page 9 -->

owning authority as the single point of contact for CGD-related
tasks from that speciﬁc authority.
3. The CGD entity will submit a phasing plan for the total work to the
concerned authority, with a copy to the District Nodal Ofﬁcer.
A. APPLICATION SUBMISSION
The CGD Entity will submit the application through the
designated CGD portal to the appropriate authority according to
jurisdiction, along with the following documents:
a. A copy of the authorisation letter issued by PNGRB.
b. Location map showing the proposed underground gas
pipeline and planned route.
c. Soft copy of all the forms, statements and documents.
d. A non-refundable fee, as speciﬁed in Annexure G, will be
payable to the concerned local authority.
B. APPLICATION REVIEW AND BANK GUARANTEE (BG)
SUBMISSION
1. The concerned authority will review the application and
notify the entity within 10 working days to submit the
required BG.
2. The CGD entity must submit the BG, valid for one year, to the
concerned authority within 10 working days. The BG must be
extended until the completion of work and NOC issuance.
3. The BG amount will be 20% of the total restoration cost,
calculated as per the rates provided in Annexure G.
C. GRANT OF PERMISSION
1. Permission will be granted only under the ‘Dig and Restore’
method, subject to submission of a security deposit in the
form of a Bank Guarantee (BG).
2. Upon submission of BG, the concerned authority must grant
08

Rajasthan CGD Policy 2025

<!-- page 10 -->

permission within 10 working days.
3. If the permission is not granted within 30 days from the date
submission of application, the CGD entity may escalate the
issue to the District Nodal Ofﬁcer, who will ensure resolution
within 10 days.
4. If no decision is made within 45 days from the date
submission of application, the CGD entity may proceed with
pipeline laying under deemed approval, after informing the
District Nodal Ofﬁcer and submitting the BG to the concerned
authority.
5. Permission will cover the entire proposed pipeline length,
but excavation must be restricted to 20% of the permitted
length or 5 km, whichever is less at any given time.
6. After satisfactory completion of the permitted length, the
entity will be allowed to dig for next phase same as above.
D. WORK EXECUTION GUIDELINES FOR LAYING NATURAL GAS
PIPELINE
1. The CGD entity must notify the concerned authority about
the proposed excavation before digging. The "Call Before u
Dig" (CBuD) application should be utilised.
2. Before excavation, the CGD entity should collect route maps
and details of underground utilities such as water, sewer,
electrical, and OFC lines, along with site supervision. They
will also notify the relevant utility operator for on-site
supervision.
3. Open trench and trenchless methods are allowed for laying
underground gas pipelines. However, Horizontal Directional
Drilling (HDD)/manual moling should be used to minimise
road excavation/damage.
4. During monsoon season, only trenchless methods will be
Rajasthan CGD Policy 2025

09

<!-- page 11 -->

allowed provided safety, security, and restoration measures
are in place.
5. The CGD entity must take utmost care to avoid damage to
underground utilities. Any damage must be rectiﬁed by the
entity at its own cost.
6. The cost of shifting existing underground utilities or gas
pipelines, if required, will be borne by the requesting
agency/authority.

10

Rajasthan CGD Policy 2025

<!-- page 12 -->

E. Inspection of Restoration and NOC for release of Bank Guarantee
(BG)
1. The concerned local authority will specify the name and
designation of the ofﬁcer in the permission granted for
inspection of the restoration and granting the NOC for
satisfactory restoration.
2. The CGD entity must repair any road damage and restore
excavated pits during the underground gas pipeline
installation within the speciﬁed timeframe.
3. Upon completion of the pipeline laying and restoration work,
the CGD entity will submit a formal request to the designated
ofﬁcer to inspect the restoration and issue the completion
certiﬁcate and/or No-objection Certiﬁcate (NOC).
4. The designated ofﬁcer will inspect the restoration work
within 10 days of receiving the request and advise on any
necessary rectiﬁcations, if required.
5. The CGD entity must complete the rectiﬁcation according to
the ofﬁcer’s directions or comments and notify the
designated ofﬁcer within 10 days.
6. The designated ofﬁcer will conduct a reinspection and issue
the NOC within 10 days.
7. If the NOC is not granted after re-inspection and no
comments are provided within 10 days, the CGD entity may
escalate the matter to the district nodal ofﬁcer, who will
ensure a resolution within 10 days.
8. After completing each permitted phase satisfactorily, the
next excavation phase will be approved following the same
process.

Rajasthan CGD Policy 2025

11

<!-- page 13 -->

9. Once the NOC is issued for the entire jurisdiction, the
concerned authority will either return the BG or allow it to be
used for subsequent permissions upon the entity’s request.

5.3.2 Permission for installation of CGD equipment
1. The CGD entity must submit an application to the relevant local
authority for the installation of including but not limited to
Pressure Regulating Stations (PRS), Field Regulating Stations
(FRS), District Regulating Stations (DRS), Metering and
Regulating Stations (MRS), and Supervisory Control and Data
Acquisition (SCADA) systems along with a copy to the district
nodal ofﬁcer.
12

Rajasthan CGD Policy 2025

<!-- page 14 -->

2. Permission for the above installation covering an area of
approximately 45 to 60 square metres will be granted at various
locations such as roadsides, public parks, utility areas, and
Government premises to expedite the implementation of the
CGD project.
3. CGD Entities install CNG Decompression Units (DCU) to reduce
pressure from 250 bar (g) to 4 bar (g) for the MDPE pipeline
network when not connected to the main pipeline. The authority
will provide land plots of at least 300 square metres for DCU
stations on an annual rental basis.
4. The annual rent for designated land installations will be
determined based on the applicable rates outlined in Annexure
G.
5. The relevant local authority, after conducting a joint survey, will
determine the annual rent and notify the entity regarding the
payment of rent for an initial period of three years and
subsequent three-year increments thereafter.
6. The CGD entity will deposit the rent to the concerned local
authority with intimation to the district nodal ofﬁcer.
7. The concerned local authority will ensure that permission is
granted for the above installations within seven days of the date
of the rent deposit.
8. If permission is not granted within 45 days of the application’s
submission date, the CGD entity may raise the issue with the
district nodal ofﬁcer. The district nodal ofﬁcer will dispose of the
application and direct the concerned local authority to grant the
necessary permission within 10 days.

Rajasthan CGD Policy 2025

13

<!-- page 15 -->

5.3.3 Allotment of land for City Gate Station (CGS) / CNG Station
1. The CGD entities need land for CGS, facilitating the transfer of
natural gas from pipelines to the CGD network for public
consumption.
2. The CGD entities must establish a ﬁxed number of CNG retail
outlets in their respective geographic areas as part of their
Minimum Work Programme (MWP) commitment to PNGRB.
3. The CGD Networks, CGS, and CNG Stations will be classiﬁed as
public facilities, and the relevant local authority will allocate
land designated for public use in development plans for their
establishment.
4. Plots needed to meet MWP targets along city corridors, National
and State highways, and major roads will be allocated based on
availability.
14

Rajasthan CGD Policy 2025

<!-- page 16 -->

5. The State Government shall facilitate allocation of Government
designated land for CGD infrastructure.
6. Government-owned land or plots will be leased to CGD entities
for 30 years, either free of charge or at a nominal rental fee.
7. The concerned authorities will assist CGD entities with land
acquisition and land-use conversion processes.
A. No-Objection Certiﬁcate (NOC) Process for CNG Station
1. The CGD Entity must submit the application to the District
Magistrate (DM) through the designated CGD portal with the
following documents:
a. A copy of the authorisation letter issued by PNGRB
b. Land ownership / registered lease documents
c. Layout diagram as per PESO guidelines
d. Location map showing the proposed CNG station
2. The DM views and forwards the application to the concerned
departments, including but not limited to the Fire department,
Pollution Control Board, Police, Local Bodies (LSG) / Municipal
Corporation, national /state highway authorities, Food and Civil
Supplies, PWD and Forest.
3. The concerned departments review the application and issue
the necessary No Objection Certiﬁcates (NOCs).
4. The DM reviews and consolidates all departmental NOCs and
grants ﬁnal approval to the CGD entity.

Rajasthan CGD Policy 2025

15

<!-- page 17 -->

5.3.4 Safety of Gas Pipeline Network
1. Any other utilities that are laid on any roadside where the gas
pipeline network has been established, will lay the same at safe
distance from the gas pipeline with necessary safeguards as per
the norms. In case the other utilities are already present before
the gas pipelines are laid, then the CGD entity will lay the gas
pipeline with adequate safety precautions with necessary
safeguards as per the norms.
2. If any unauthorized person/entity damages the gas pipeline
/installations, then based on the CGD entity’s written
complaint’s the Police will immediately ﬁle the case as
mandated under the relevant Acts related to gas pipelines and
their safety.
3. The Emergency Response Vehicles used by the CGD entities for
responding to the gas pipeline leakage/damage, etc. will be
given the status of ‘Emergency Vehicle’.
4. District Authorities must conduct ‘Mock Drills’ in coordination
with CGD entities in their respective GA, to ensure preparedness
for gas pipeline leakage or damage scenarios as part of the
Emergency Response and Disaster Management Plans (ERDMP).

<!-- page 18 -->

5.4 Adoption of CNG
The Rajasthan Transport Department will issue directives to:
1.

Approve CNG vehicles and kits certiﬁed by Automotive Research
Association of India (ARAI) / International Centre for Automotive
Technology (ICAT) within 15 days of receiving applications, with
validity checks every three years.

2.

Ensure endorsement of CNG conversions on Registration
Certiﬁcates (RCs) by RTO/DTO ofﬁces within 10 working days.

3.

Grant approvals of CNG Retro-ﬁtment Centres (RFCs) within 15 days
of application submission by RTO/DTO ofﬁces.

4.

Exemption on Road Tax/Registration charges for registered vehicles
on CNG fuel.

5.

Encourage educational institutions and private transport buses in
cities with populations over 5 lakhs to transition to CNG within two
years, and in other cities, within four years.

6.

Provide the option of CNG in the Rajasthan State Road Transport
Corporation/City Transport Companies tenders to hire intercity/
intra-state buses.

<!-- page 19 -->

5.5 Safety Measures for CNG Vehicles
1.

RTO/DTO will ensure establishment of vehicle inspection and
periodic check-ups/testing and certiﬁcation centres for retroﬁtted
CNG vehicles.

2.

A list of approved CNG Testing stations would be made available at
the Department of Road Transport portal to ensure information to
the vehicle owners.

5.6 Use of Natural Gas in Industries and Commercial
Segments to Control Pollution
Rajasthan State Pollution Control Board will issue directives to:

18

1.

Encourage conversion of diesel generator (DG) sets to gas-based or
dual-fuel systems in areas with established natural gas
infrastructure.

2.

Encourage telecom towers, apartments, and commercial buildings,
especially in urban areas, to replace diesel-based power backup
systems with cleaner, cost-effective natural gas alternatives.

3.

Introduce a provision to mandate phasing out of polluting fuels,
including diesel, in industrial areas with developed gas pipeline
connectivity to reduce emissions and align with clean air goals.

4.

Introduce provisions for the integration of cleaner fuel usage
requirements into the CTE/CTO approval processes for industrial
and commercial operations.

Rajasthan CGD Policy 2025

<!-- page 20 -->

5.7 Allotment of land for development of Compressed
Biogas Plants
1.

Allocate land for setting up Compressed Biogas (CBG) plants in
collaboration with Municipal and Local Bodies, to support
mandatory CBG blending in CNG (Transport) and PNG (Domestic)
segments from FY 2025-26.

2.

Municipal/ Local Bodies will provide segregated waste and other
resources required for establishing local Compressed Biogas (CBG)
plants by CGD entities.

Rajasthan CGD Policy 2025

19

<!-- page 21 -->

5.8 Inclusion of PNG pipelines/networks at time of approval
of building plan
1.

Urban Development and Housing Department (UDH) will make
necessary amendments in the by-laws to mandate gas pipeline
infrastructure in residential and commercial building plans during
approval.

2.

Provisions for PNG connectivity in all Government quarters, guest
houses, and ofﬁce buildings to support the expansion of the CGD
network.

5.9 Organisational Set up
5.9.1 State-Level Committee on CGD Development
A. Committee under the Chairmanship of the Chief Secretary will
guide and monitor the progress of CGD infrastructure
development to ensure that these align with the State’s
objectives.
B. Composition of a State-Level Committee for CGD development:
Ÿ Chief Secretary to the Government - Chairman, Ex-Ofﬁcio
Ÿ Addl. Chief Secretary/Principal Secretary/Secretary to

Government-Finance Department, Ex- Ofﬁcio
Ÿ Addl. Chief Secretary/Principal Secretary/Secretary to

Government-Revenue Department, Ex-Ofﬁcio
Ÿ Addl. Chief Secretary/Principal Secretary/Secretary to

Government -Transport Department, Ex- Ofﬁcio
Ÿ Addl. Chief Secretary/Principal Secretary/Secretary to

Government-Public Works Department, Ex-Ofﬁcio
Ÿ Addl. Chief Secretary/Principal Secretary/Secretary to

Government-Urban Development and Housing (UDH), ExOfﬁcio
Ÿ Addl. Chief Secretary/Principal Secretary/Secretary to

20

Rajasthan CGD Policy 2025

<!-- page 22 -->

Government–Mines and Petroleum, Ex-Ofﬁcio
Ÿ Addl. Chief Secretary/Principal Secretary/Secretary to

Government–Local Bodies, Ex-Ofﬁcio
Ÿ Addl. Chief Secretary/Principal Secretary/Secretary to

Government–Food and Civil Supplies and Consumer Affairs,
Ex-Ofﬁcio
Ÿ Addl. Chief Secretary/Principal Secretary/Secretary to

Government–Disaster Management, Relief and Civil Defence,
Ex-Ofﬁcio
Ÿ Member Secretary–Rajasthan State Pollution Control Board,

Ex-Ofﬁcio
Ÿ Managing Director, RIICO, Ex-Ofﬁcio
Ÿ Representatives of auto industry body (SIAM)
Ÿ Director, Petroleum, Rajasthan Government, will be the

convener of the committee
Ÿ Managing Director, RSGL, Ex- Ofﬁcio as Representatives of

authorised CGD entities
C. Periodicity of Meetings:
The State-level Committee will meet at least once in three
months for expeditious development of CGD networks and
otherwise as needed.

Rajasthan CGD Policy 2025

21

<!-- page 23 -->

5.9.2 Monitoring Committee
There will be District City Gas Committee (DCGC) in each district. The
DCGC will comprise members as mentioned below. The Chairman of
DCGC is authorised to co-opt any expert as necessitated:
I

District Collector

Chairman

ii

Superintendent of Police

Member

iii

Chief Municipal ofﬁcers of ULBs in the District

Member

iv

Secretary of Development Authority/UIT

Member

v

Chief Executive Ofﬁcer, Zila Parishad

Member

vi

Representative of the Pollution Control Board

Member

vii

Chief Medical and Health Ofﬁcer

Member

viii

Superintending Engineer, PWD

Member

ix

Superintending Engineer, Vidyut Vitaran Nigam Ltd.

Member

x

Superintending Engineer, PHED

Member

xi

Representative of the Authorized Entity

Member

xii

District Supply Ofﬁcer

Member

xii

Regional Transport Ofﬁcer/District Transport Ofﬁcer

Member

xiii

Mines Engineer/Assistant Mines Engineer

Member
Secretary

The District City Gas Committee (DCGC) will review the CGD project progress in
the monthly meetings. Further, if there is any requirement, ofﬁcials of other
departments may be invited to the monthly meetings to resolve any issue
related to CGD in the district.

22

Rajasthan CGD Policy 2025

<!-- page 24 -->

5.9.3 Nodal Ofﬁcers
1. The Director, Local Bodies will be the nodal ofﬁcer at the State
level, Joint Secretary, UDH department and Additional Director,
Local Bodies will be additional Nodal ofﬁcers at the State level
for matters related to permissions/land allotment by Local
Bodies. In case of any delay in permission, approvals beyond the
timeline prescribed in this order, the entity may escalate the
same to State Nodal Ofﬁcer. The Director Petroleum will be the
additional nodal ofﬁcer at the State level for co-ordinating with
the CGD Entities.
2. The District Magistrate will be the Nodal Ofﬁcer at District level,
the District Nodal Ofﬁcer will discharge the duties ensuring swift
and timely approvals.
3. The Commissioner or Executive Ofﬁcer, as the case may be, will
be the nodal ofﬁcer of a Municipality within the territorial limits
of that Municipality, except for the properties belonging to any
department, co-operative body, autonomous body or a PSU of
the State Government.
4. The Secretary of an Urban Improvement Trust or a Development
Authority, as the case may be, will be the nodal ofﬁcer in the
urban area under the jurisdiction of that Trust or Authority
(excluding the Municipal area), except for the properties
belonging to any Department, co-operative body, autonomous
body or a PSU of the State Government.
5. Sub-Divisional Magistrate in Rural area (excluding the area
within the jurisdiction of an Urban Improvement Trust or a
Development Authority), as the case may be, will be the nodal
ofﬁcer except for the properties belonging to any Department,
co-operative body, autonomous body or a PSU of the State
Government.

Rajasthan CGD Policy 2025

23

<!-- page 25 -->

6. The seniormost ofﬁcer of the concerned Department, the nodal
ofﬁcer co-operative body, autonomous body or a PSU of the
State Government posted in the district for the properties
belonging to that Department or PSU or Cooperative body or an
Autonomous body, as the case may be.
5.10 Obligations of the CGD Entities
1. Develop the CGD network in their respective geographical areas
in time bound manner as per the terms of the authorisation.
2. The CGD infrastructure and CNG retail outlets will be developed
adhering to the relevant statutory standards and guidelines.
This includes compliance with Technical Standards for Safety
(T4S) Petroleum and Explosives Safety Organisation (PESO)
Central and State Pollution Control Boards, District
Administrative Authorities/Municipal Corporations/
Development Authorities.
3. CGD entities shall ensure compliance with PNGRB technical
standards, integrity management systems and emergency
response and disaster management plans.
4. Put up gas pipeline markers as per the Government safety
regulations/norms all along the gas pipeline routes the same will
be maintained annually by them.
5. Regularly carry out publicity campaigns through media for
generating awareness in the public about the beneﬁts of PNG
and CNG.
6. Carry out regular periodic safety awareness camp/campaigns
with all local authorities and utility providers to sensitise about
safety aspects related with gas pipeline networks.
Familiarisation/awareness sessions will be organised to
promote understanding of PNG/CNG, the CGD network and
regarding gas pipeline safety. The CGD entities will approach
24

Rajasthan CGD Policy 2025

<!-- page 26 -->

District authorities for carrying out annual ERDMP drill and
conducting awareness campaigns on a regular basis.
7. Sign MoU with the District Fire Department for their respective
GA for mutual aid and coordination for dealing emergencies.
8. Develop Compressed Biogas (CBG) Plants along with the local
bodies in their respective Geographical Areas to promote
Government initiatives under Swachh Bharat Abhiyan.
9. Submit monthly progress report of their respective
Geographical Areas to the District Collector by the 5th of every
month. Further, the entities will comply with all Government
directions /guidelines issued to them in public interest.
10. Take all precautionary measures for safety of the gas pipelines
along the roads during the operation period or during
maintenance. Similarly, they should take all precautionary
measures for safety of the structure / crossing of river or canal.
11. Create awareness among CNG customers at their CNG ﬁlling
stations that they should use only the standard CNG kits in their
vehicles ﬁtted through Government authorized retro ﬁtment
centres only. Further, they should also inform customer to
undertake cylinder testing certiﬁcates as per Government
norms.
12. Annually train youths under Apprentice Training Program as
suggested by the State Government.
13. All the beneﬁts extended by the State Government for the CGD
entities through Policy are subject to the condition that CGD
entities should carry out the committed Minimum Work
Programme (MWP) as per the schedule.
14. Pass on the beneﬁt of reduction in the gas pipeline laying
permission charges to the public, w.r.t. PNG and CNG price, in
their respective Geographical Area.
Rajasthan CGD Policy 2025

25

<!-- page 27 -->

26

Rajasthan CGD Policy 2025

<!-- page 28 -->

6 IMPLEMENTATION AND REVIEW
The State is committed to successful and time-bound implementation of this
Policy. To ensure that all key aspects are successfully implemented, the State
level committee and the District level committee will carry-out regular
engagement and consultation with stakeholders’ and conduct quarterly
reviews and take necessary actions towards interdepartmental coordination,
legislative changes, and any other course corrections.
In the event of any ambiguity or dispute arising from the interpretation of any
provision of this Policy, the Government of Rajasthan will have the ﬁnal and
binding authority.
The Policy will be subject to amendments as deemed necessary in response to
developments within the CGD sector.
The applicable rate/charges, as speciﬁed in Annexure G, may be amended or
revised periodically by the State Government based on the recommendation of
the State Level Committee.

Rajasthan CGD Policy 2025

27

<!-- page 29 -->

Annexure
A. City Gas Distribution Network
Transmission Gas Pipeline
(Pressure< 92 Bar)

City Gate
Station

Steel Pipe Network
(Pressure~19 Bar)

District
Regulating
Station (DRS)

CNG Station
(Dispensing Pressure
200 Bar)

MDPE
(Pressure 4 Bar)

Commercial Customer
Meter
Regulator

Industrial Customer
Domestic Customer

The City Gas Distribution (CGD) project primarily means taking Natural Gas to
the households for cooking, lighting, space heating and water heating. The
project comes under utility infrastructure which is further augmented by
supplying fuel to other business segments viz. commercial, industrial and CNG.
Natural gas as a fuel is extremely efﬁcient.
CGD network is developed to cater the following segments of customers:
(a)

Piped Natural Gas (PNG): Supply gas to Domestic, Commercial and
Industrial consumers

(b)

Compressed Natural Gas (CNG): Supply gas to Transport sector for
refuelling vehicles

B. Technical Requirements for the Development of the CGD
The basic technical requirements for the successful implementation of
the City Gas Distribution (CGD) network in any Geographical Area (GA) are
as follows:

28

(a)

CGD entity requires connectivity with the National Gas Grid.

(b)

CGD entity needs to have a City Gate Station (CGS) at the GA as
Rajasthan CGD Policy 2025

<!-- page 30 -->

receiving terminal
©

CGD needs to lay Steel and Medium Density Poly Ethylene (MDPE)
gas pipeline infrastructure up to the burner of the domestic
households and in case of industries/commercial establishments,
up to their premises. The grant of permission by any Authority/
Agency/Board, etc. to lay gas pipeline network should be timebound

(d)

In case of MDPE network, the CGD entity must put up District
Regulating Station (DRS) at regular intervals because it has limited
radius of operation

(e)

The CGD entity needs to have land for setting up of CNG stations at
various prominent places along the road for making the fuel
available to the public. They need to acquire land for the CGS and
CNG station and acquisition timeline should be maximum 6 months

(f)

All upcoming City/Town planning should invariably include the City
Gas Distribution network and should have provision of CNG stations

(g)

The Town Planning Departments/Municipalities/Corporations/City
and Town Development Authorities/Panchayats, etc., should
invariably include PNG infrastructure also while giving building plan
approvals

<!-- page 31 -->

Classiﬁcation of PNG network:
(a) Primary Network: Operates at pressures between 7 bar(g) and 49 bar(g),
consisting of steel pipelines, primarily downstream of City Gate Stations
(CGS)
(b) Secondary Network: Operates at pressures between 0.1 bar(g) and 6
bar(g), consisting of Medium-Density Polyethylene (MDPE) pipelines and
ﬁttings
(c) Tertiary Network: Operates below 0.1 bar(g), consisting of GI pipes, copper
pipes, and Suraksha hoses to ensure uninterrupted gas supply at the
service level

Types of CNG Stations:
(a) CNG Mother Stations: Connected to the CNG pipeline network, equipped
with stationary cascades for vehicle refuelling and mobile cascades for
supplying Daughter Booster Stations
(b) CNG On-line Stations: Equipped with compressors to compress pipeline
gas to 220-250 bar(g) for vehicle refuelling but lack mobile cascade
facilities
(c) CNG Daughter Booster Stations: Located in areas without pipeline
connectivity, supplied by cascades to ensure network penetration and
service expansion

Advantages of Natural Gas in CGD:
(a) Natural gas as a transport fuel is more economical than traditional fuels
(b) Produces signiﬁcantly lower emissions, making it a cleaner fuel
(C ) CNG has a considerably higher-octane no. which makes it more energy
efﬁcient

30

Rajasthan CGD Policy 2025

<!-- page 32 -->

Rajasthan CGD Policy 2025

31

<!-- page 33 -->

C. Flow Chart for Pipeline Laying Permissions
Start

Application for Land Allotment/ Pipeline
Laying/Road Cutting / Others

Pay Now

Successful

No

Application Partially
Submitted

Senior most ofﬁcer
(Concerned Authority)

Application
complies terms and
conditions

Submit Report

Objection

for any
clariﬁcations
objection
clariﬁed

if objection is not clariﬁed
or no response
Reject

In principle approval
of application by
approving authority

for any
clariﬁcations
objection
clariﬁed

Objection

if objection is not clariﬁed
or no response
Reject

Accounts

Demand Notice

End

32

Rajasthan CGD Policy 2025

<!-- page 34 -->

D. District Magistrate (DM) NOC for CNG Stations
Information ﬂow of system
CGD Entities
submits
application

Application
sent for correction

Generate NOC

Sends Dept. NOC

District
Collector

Government
Department

Receive Application

Application
Resubmission

Sends for review

E. Timeline of Permissions for Pipe laying
Application Submission
SN.

Activity

Timeline
(Working Days)

1

Application submission for laying underground gas
pipeline along with required documents and a nonrefundable fee, as speciﬁed in Annexure G to
concerned local authority by CGD entity.

0

2

The concerned authority will review the application
and intimate the applicant for submission of
required BG, within the speciﬁed time.

10

3

The applicant will submit the necessary BG to the
concerned local authority, within the speciﬁed time.

10
(Total 20 days)

4

The concerned local authority will ensure grant of
permission for pipeline laying, within the speciﬁed
time frame from the date of submission of BG.

10
(Total 30 days)

Rajasthan CGD Policy 2025

33

<!-- page 35 -->

SN.

Activity

Timeline
(Working Days)

5

If the permission is not granted within 30 days from
the date submission of application, the CGD entity
may raise the issue with District Nodal Ofﬁcer, who
will ensure resolution with the speciﬁed time.

10
(Total 40 days)

6

If a decision on CGD entities application is not made
within overall time period of 45 (Forty-five) days from
the initial date of submission of application, the CGD
entity will be at liberty to start the pipeline laying
activities under deemed approval, with the
intimation to the District Nodal Ofﬁcer and will
submit the BG to local authority with copy of the
same to the District Nodal Ofﬁcer.

Total 45 days

No Objection Certiﬁcate (NOC)
SN.

Activity

Timeline
(Working Days)

1

The concerned local authority will specify the Name
and Designation of the Ofﬁcer in the permission
granted for inspection of the restoration and granting
the NOC for satisfactory restoration.

0

2

The entity, after laying of pipeline and restoration
thereon for the part of pipeline laid will intimate in
writing to the designated ofﬁcer for inspection of
restoration and issue of the completion certiﬁcate
and/or NOC.

0

3

The designated ofﬁcer will inspect the restoration
work following written intimation from the entity and
provide feedback or advice for rectiﬁcation, if
required, within the speciﬁed time.

10

34

Rajasthan CGD Policy 2025

<!-- page 36 -->

SN.

Activity

Timeline
(Working Days)

4

The CGD entity will rectify the restoration as per the
direction or the comments and intimate to the
designated ofﬁcer, within the speciﬁed time.

10
(Total 20 days)

5

The designated ofﬁcer will inspect the work again
and issue NOC for restoration, within the speciﬁed
time.

10
(Total 30 days)

6

If the NOC is not granted after re-inspection and no
comments are provided within 10 days, the CGD
entity may escalate the matter to the district nodal
ofﬁcer, who will ensure a resolution within the
speciﬁed time.

10
(Total 40 days)

7

After issuance of NOC for the complete area under
the jurisdiction of an authority, concerned authority
will return the BG or can be treated as BG deposit for
the subsequent permission with the request of
entity.

F. Deﬁnitions
In this Policy, unless the context otherwise requires, (a) “Act” means the Petroleum and Natural Gas Regulatory Board Act, 2006;
(b) “Petroleum and Natural Gas Regulatory Board (PNGRB)” means the Board
established under Petroleum and Natural Gas Regulatory Board Act, 2006.
(c) “Regulations” means regulations made by the PNGRB under PNGRB Act,
2006.
(d) “Authorised Area” means the speciﬁed geographical area for a city or local
natural gas distribution network (CGD network) authorised by PNGRB.
Rajasthan CGD Policy 2025

35

<!-- page 37 -->

(e) “Natural Gas” means gas obtained from bore-holes and consisting
primarily of hydrocarbons and includes: (i) gas in liquid state, namely,
liqueﬁed natural gas and degasiﬁed liqueﬁed natural gas, (ii) compressed
natural gas, (iii) gas imported through transnational pipe 1ines, including
CNG or liqueﬁed natural gas, (iv) gas recovered from gas hydrates as
natural gas, (v) methane obtained from coal seams, namely, coal bed
methane, but does not include helium occurring in association with such
hydrocarbons.
(f)

“City or Local Gas Distribution Network (CGD Network)” means an
interconnected network of gas pipelines and the associated equipment
used for transporting natural gas from bulk supply high-pressure
transmission main to the medium-pressure distribution grid and
subsequently to the service pipes supplying natural gas to domestic,
industrial or commercial premises and CNG stations situated in a
speciﬁed Geographical Area.

(g) “Development of CGD network” means laying, building, operating or
expanding a city or local natural gas distribution network;
(h) “Piped Natural Gas or PNG” means natural gas transported through
pipelines or cascades or any other permitted mode in a CGD network for
consumption by any customer in domestic, commercial or industrial
segments and includes natural gas supplied to an online CNG station
before its compression.
(I)

"Compressed Natural Gas or CNG” means natural gas used as fuel for
vehicles, typically compressed to the pressure ranging from 200 to 250
bars in the gaseous state;

(j)

“City Gate Station or CGS” means the point where custody transfer of
natural gas from a natural gas pipeline to the city or local natural gas
distribution network takes place;

(k) “CNG station” means ﬁlling station where one or more dispensing units
are provided for sale of compressed natural gas, including mother station
facility for ﬁlling of cascades.
36

Rajasthan CGD Policy 2025

<!-- page 38 -->

(l)

"CGD Entity" means a person, association of persons, ﬁrm, company or
cooperative society by whatsoever name called or referred to, other than
a dealer or distributor, authorized by PNGRB for laying building operating
or expanding city or local, natural gas, distribution network.

(m) “Local Body” means a Municipal Corporation, Municipal Council or
Municipal Board in a Municipal area, a Development Authority or Urban
Improvement Trust in an urban area declared under the relevant law and
Gram Panchayat for Rural areas.
(n) “Minimum Work programme” means number of domestic, PNG
connections, number of CNG stations and inch-kilometre of steel pipeline
networks as mentioned in the authorisation letter issued by PNGRB;
G.

List of Applicable Fees, Charges, and Rates
1.

The non-refundable application submission fee for pipeline laying
permission will be 1,000 per kilometre, payable to the designated
local authority.

2.

The BG amount for pipeline laying permission will be 20% of the
total restoration cost, calculated at a ﬂat rate of 1,200 per square
metre (covering the average for bitumen, cement concrete, and
WBM surfaces).

3.

The annual rent for the land designated for CGD equipment
installations will be 5% of the residential reserve price or residential
DLC rate applicable to the area where the land is located.

Rajasthan CGD Policy 2025

37

<!-- page 39 -->

H. List of CGD Entities
SN.

Name of Entity

Name of Districts

1

AGP CGD India Pvt. Ltd.

Barmer, Jaisalmer & Jodhpur

2

Adani Gas Limited

Bhilwara & Bundi
Chittorgarh (other than
Rawatbhata), Pratapgarh &
Udaipur

3

Bharat Petroleum Corporation Ltd. Hanumangarh & Sri Ganganagar

4

Gasonet Services (RJ) Ltd.

Bikaner & Churu

5

GAIL Gas Ltd.

Bharatpur

6

Gujarat Gas Limited

Banswara & Dungarpur
Jalore & Sirohi

Haryana City Gas Distribution
(Bhiwadi) Ltd.

Bhiwadi

8

Hindustan Petroleum Corporation
Ltd.

Dausa, Karoli, Sawai Madhopur &
Tonk

9

Indraprastha Gas Ltd.

Ajmer, Pali & Rajsamand

10

Indian Oil Corporation Ltd.

Jhunjhunu, Nagaur & Sikar

11

Megha City Gas Distribution Pvt Ltd Jhalawar

12

Rajasthan State Gas Ltd.

Kota City

13

Torrent Gas Private Ltd.

Alwar (other than Bhiwadi) &
Jaipur

7

Baran, Chittorgarh (Only
Rawatbhata) & Kota (EAAA)
Dholpur

38

Rajasthan CGD Policy 2025

<!-- page 40 -->
