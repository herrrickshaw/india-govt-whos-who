---
doc_id: "5ee0ebabb43748aa"
source_url: "https://metrology.mizoram.gov.in/uploads/attachments/2026/09/7c4b25c6fe37e6c50a91ee43d273e313/pages-84-lm-rules-2026-siamthat-final.pdf"
ministry: "Legal Metrology, Mizoram"
title: "LM RULES 2026 siamthat final"
date: ""
pages: 47
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "19761c84e85d2703"
---

<!-- page 1 -->

No. A.12018/1/2026-FCS&CA(LM)
GOVERNMENT OF MIZORAM
FOOD, CIVIL SUPPLIES & CONSUMER AFFAIRS DEPARTMENT
***********************
Dated Aizawl, the 27th August, 2026
NOTIFICATION
In exercise of the powers conferred by section 53 of the Legal Metrology Act, 2009 (Act No. 1
of 2010) and in supersession of the Mizoram Legal Metrology (Enforcement) Rules, 2010, the
Government of Mizoram hereby makes the following rules, namely: 1. Short title and commencement –
(1)
(2)
(3)

These rules may be called the Mizoram Legal Metrology (Enforcement) Rules, 2026.
They extend to the whole of Mizoram.
They shall come into force on the date of their publication in the Official Gazette.

2. Definitions –
In these rules, unless the context otherwise requires –
(a)

“Act” means the Legal Metrology Act, 2009.

(b)

"Reference Standards Laboratory" means a laboratory set up by the Central Government
under the Act, where Reference Standards, Secondary Standards and Working Standards
are maintained.

(c)

“Schedule” means a schedule appended to these rules.

(d)

Words and expressions used in these rules and not defined, but defined in the Act, shall
have the meanings respectively assigned to them in the Act.

3. Reference Standards –
The Reference Standards shall be kept at such place, in such manner and in such custody
as prescribed under the Legal Metrology (National Standards) Rules, 2011.
4. Secondary Standards –
(1)

Every Secondary Standard shall be verified at any of the Reference Standards Laboratories,
in such manner and at such periodic intervals as may be prescribed under the Legal
Metrology (National Standards) Rules, 2011 and shall, if found on such verification to
conform to the standards established by or under that Act, be stamped by Reference
Standards Laboratory or a certificate of verification shall be issued by that laboratory.

(2)

The Secondary Standards shall be kept at such place and in such custody as the Controller
may direct.
1

<!-- page 2 -->

5. Working Standards –
(1)

Every Working Standard shall be verified either at any of the Reference Standards
Laboratories or at any of the Secondary Standards Laboratories maintained by the State
Government, in such manner and at such periodic intervals as may be prescribed under the
Legal Metrology (National Standards) Rules, 2011 and shall, if found on such verification to
conform to the standards established by or under the Act, be stamped or certificate of
verification shall be issued by that laboratory as the case may be.

(2)

The Working Standards shall be kept in the custody of Legal Metrology Officer.

6. Secondary Standard Balances –
(1)

A set of Secondary Standard Balances shall be maintained at every place where Secondary
Standard Weights are kept.

(2)

The number, types and specifications of such balances shall be as prescribed under the
Legal Metrology (General) Rules, 2011.

(3)

Every Secondary Standard Balance shall be verified at least once within a period of twelve
months and shall be adjusted, if necessary, to ensure that it conforms to the limits of
sensitivity and other metrological qualities prescribed under the Act, by the Reference
Standards Laboratory or by the Controller or such other officer as may be authorized by the
Controller in this behalf.

7. Working Standard Balances –
(1)

A set of Working Standard Balances shall be maintained at every place where Working
Standard Weights are kept.

(2)

The number, types and specifications of such balances shall be as prescribed under the
Legal Metrology (General) Rules, 2011.

(3)

Every Working Standard Balance shall be verified at least once within a period of twelve
months and shall be adjusted, if necessary, to ensure that it conforms to the limits of
sensitivity and other metrological qualities prescribed under the Legal Metrology (General)
Rules, 2011, by the Reference Standard Laboratory or at any of the place where Secondary
Standards are maintained by the State Government.

8. Physical characteristics, configuration, constructional details of Weights and Measures –
Every Weight or Measure used or intended to be used in any transaction or for protection
shall conform, as regards physical characteristics, configuration, constructional details, materials,
performance, tolerances and such other details, to the specifications prescribed under the Act or
the Legal Metrology (General) Rules, 2011.

2

<!-- page 3 -->

9. Use of Bullion Weights, Carat Weights, etc. –
(1)

No weight other than a bullion weight as specified in the Legal Metrology (General) Rules,
2011 shall be used in any transaction or protection in bullion including precious metals,
pearls, ornaments or other articles made of gold or silver.

(2) No weight other than a carat weight as specified in the Legal Metrology (General) Rules,
2011 shall be used in any transaction in precious stones.
(3) Only beam scale of Class A or Class B category or a non-automatic weighing instrument of
high accuracy class (Class II) or special accuracy class (Class I) shall be used in any
transaction or protection referred to in sub - rules (1) and (2).
(4) In the sale or purchase of gold, silver, platinum, or any other precious metal, or ornaments
and articles made of such metals, only Class I or Class II non-automatic weighing
instruments having a verification scale division not exceeding one milligram (0.001 gram)
shall be used.
10. Use of weights only or measures only or number only in certain cases –
Except in the cases of commodities specified in SCHEDULE - I, the declaration of quantity in
every transaction, dealing or contract, or for protection shall be in terms of the unit of –
(a) weight, if the commodity is solid, semi - solid, viscous or a mixture of solid and liquid;
(b) length, if the commodity is sold by linear measure;
(c) area, if the commodity is sold by area measure;
(d) volume, if the commodity is liquid or is sold by cubic measure; or
(e) number, if the commodity is sold by number.
11. Registration of Manufacturer, Repairer and Dealer of Weights and Measures –
(1) Every manufacturer, repairer or dealer of weights and measures shall make an application to
the Controller or any officer authorized by him in this behalf for registration through the
designated online portal as may be notified by the State Government in the Official Gazette.
(2) The online application forms for registration as manufacturer, repairer or dealer shall be in
Form - RM - 1, Form - RR - 1 and Form - RD - 1, respectively, as specified in SCHEDULE II.
(3) Every registration granted to a manufacturer, repairer or dealer shall be in Form - RM - 3,
Form - RR - 3 and Form - RD - 3, respectively, as specified in SCHEDULE - III.
(4) The fees for registration as specified in SCHEDULE - IV shall be paid online through the
designated portal.
3

<!-- page 4 -->

(5)

The Controller or any officer authorized by him in this behalf shall maintain a record of
registered manufacturers, repairers and dealers in the form specified in SCHEDULE - V.

(6)

Every registration under the Act shall be displayed in a conspicuous place at the premises
where the registration holder carries on business.

(7)

Registration under the Act shall be based on self-declaration and shall remain valid in
perpetuity unless suspended or cancelled under the provisions of the Act or these rules. No
prior inspection shall be required for grant of such registration, and the registration shall not
be transferable.

(8)

On submission of the required documents and payment of the prescribed fee, the registration
certificate shall be granted within 14 working days from the date of submission of the
application, failing which the registration shall be deemed to have been granted.

12. Suspension and Cancellation of Registration granted –
(1)

The Controller or any officer authorized by him in this behalf may, if he has reasonable cause
to believe that the holder of any registration under the Act has made any statement in, or in
relation to, any application for the continuance of registration which is incorrect or false in any
material particular, or has contravened any provision of the Act or any rule or order made
thereunder, suspend such registration pending completion of the inquiry in respect of such
registration:
Provided that no such registration shall be suspended unless the registrant thereof has been
given a reasonable opportunity of showing cause against the proposed action.
Provided further that where the inquiry referred to in this sub-rule is not completed within a
period of three months from the date of suspension of a registration, such suspension shall,
on expiry of the said period, stand vacated.

(2)

The Controller or such other officer authorized by him in this behalf may, if he is satisfied,
after making such enquiry as he may think fit, that the registrant has made a false or
incorrect statement of the nature referred to in sub-rule (1), or has contravened any law or
order referred to in that sub-rule, cancel such registration:
Provided that no such registration shall be cancelled unless the holder thereof has been
given a reasonable opportunity of showing cause against the proposed action.

(3)

Every person whose registration has been suspended shall, immediately after such
suspension, cease to function as such registrant and shall not resume business as such
registrant until the order of such suspension has been, or stands, vacated.

(4)

Every person whose registration has been suspended or cancelled shall, after such
suspension or cancellation, as the case may be, surrender such registration to the Controller.

(5)

Every person whose registration has been cancelled shall, within a period of thirty days from
the date of such cancellation, or within such further period, not exceeding three months from
such date, as the Controller or such other officer authorized by him in this behalf may, on
sufficient cause being shown, allow, dispose of the weights or measures which were in his
possession, custody or control on the date of such cancellation; and, in the event of his
4

<!-- page 5 -->

failure to do so, the Controller or any other officer authorized by him in writing in this behalf
may seize and dispose of the same and distribute the proceeds thereof in such manner as
may be prescribed.
13. Records to be maintained by manufacturers, etc. –
Every manufacturer, repairer or dealer in weights or measures registered under the Act and
these rules shall maintain records and registers in the appropriate form set out in SCHEDULE - VI
and shall also submit such periodic reports/returns as may be specified.
14. Periodicity of Verification of Weights and Measures –
The periodic verification of Weights or Measures shall be carried out at such intervals as
specified in the Legal Metrology (General) Rules, 2011.
15. Verification and Inspection of Weights and Measures –
(1) Every person seeking verification and stamping of weights and measures used for
commercial purposes shall make an application online through the designated portal as may
be notified by the State Government in the Official Gazette.
(2) Verification and stamping of low-risk weights and measures as specified in SCHEDULE - 1A
shall be made on the basis of self-certification submitted by the applicant in FORM - A
annexed to SCHEDULE - 1A.
(3) Verification and stamping of all other categories of weights and measures as specified in
SCHEDULE - 1A shall be made on the basis of third-party certification, subject to the
availability of such certification or verification by the State Government, as specified in FORM
- B annexed to SCHEDULE - 1A.
Explanation – For the purposes of this rule, “third-party” means a registered repairer holding
a valid registration granted by the Controller.
(4) Fees for verification and stamping of weights and measures as specified in rule 17 shall also
be paid by the applicants.
(5) Every weight or measure shall be verified in a clean condition and, if necessary, the Legal
Metrology Officer shall require the owner or user to make the necessary arrangements for
the purpose.
(6) A Legal Metrology Officer may visit, as frequently as possible during the period specified in
rule 14, every premise within the local limits of his jurisdiction to inspect and test any weight
or measure which is being or is intended to be used in any transaction or for protection.
(7) The Legal Metrology Officer shall obliterate the stamp on any weight or measure if it is found
during inspection that –
(a) any weight or measure which, being due for re-verification, has not been submitted for
such re-verification; or

5

<!-- page 6 -->

(b) any weight or measure which does not conform to the standards established by or under
the Act:

Provided that where the Legal Metrology Officer is of the opinion that the defect or error in
such weight or measure is not such as to require immediate obliteration of the stamp, he
shall inform the user of the defect or error found in the weight or measure and shall call upon
user to remove the defect or error within such time, not exceeding eight days, and shall –
(i) if user fails to remove the defect or error within that period, obliterate the stamp; or
(ii) if the defect or error is so removed as to make the weight or measure conform to the
standards established by or under the Act, verify and stamp such weight or measure.

Explanation – The obliteration of the stamp on any weight or measure shall not take away or
abridge the power of the Legal Metrology Officer to seize such weight or measure in
accordance with the provisions of the Act.
16. Stamping of Weights or Measures –
(1) The Legal Metrology Officer shall stamp every weight or measure if, after testing and
verification, he is satisfied that such weight or measure conforms to the standards
established by under the Act, with a stamp of uniform design issued by the Controller, which
shall indicate the number allotted for administrative purposes to the Legal Metrology Officer
by whom it is stamped.
Provided that if, by reason of the size or nature of any weight or measure, it is not desirable
or practicable to put a stamp thereon, the Legal Metrology Officer shall take such action as
may be directed by the Controller by a general or special order in writing.
(2) The Legal Metrology Officer shall also mark the year and the quarter of stamping on every
verified weight or measure, except when the size or nature of such weight or measure makes
it impracticable.
Explanation – A year shall be deemed to consist of four quarters, of which the first quarter
shall comprise the months of January, February and March, which shall be marked as A; the
second quarter shall comprise the months of April, May and June, which shall be marked as
B; the third quarter shall comprise the months of July, August and September, which shall be
marked as C; and the fourth quarter shall comprise the months of October, November and
December, which shall be marked as D.
(3) On completion of verification and stamping, the Legal Metrology Officer shall issue a
certificate of verification in the form set out in SCHEDULE - VII.
(4) Where a certificate of verification is lost or destroyed, the holder of the certificate of
verification shall forthwith apply to the Legal Metrology Officer for a duplicate certificate of
verification. Every such application for a duplicate certificate shall be accompanied by the
prescribed fee as notified by the State Government from time to time.
(5) On receipt of an application under sub - rule (4), the Legal Metrology Officer shall issue to
the applicant a duplicate copy of the certificate of verification marked “DUPLICATE”.

6

<!-- page 7 -->

17. Fee for verification –
(1) Fees payable for verification and stamping of weights or measures at the office or camp
office of the Legal Metrology Officer shall be as specified in SCHEDULE - IX.
(2) If, at the request of the user of a weight or measure, verification is carried out at any
premises other than the office or camp office of the Legal Metrology Officer, an additional fee
shall be charged at half the rate specified in the SCHEDULE - IX, and the user of the weight
or measure shall pay the expenses incurred by the Legal Metrology Officer for visiting the
premises, including the cost of transporting and handling the Working Standard and other
equipment, subject to a minimum of rupees one hundred:
Provided that no additional fee shall be charged for verification and stamping of weights and
measures in situ of –
(3) Vehicle tanks for petroleum products and other liquids; meters for liquids other than water
(fuel dispenser, Liquid Petroleum Gas dispensers, milk dispensers); Compressed Natural
Gas dispensers; non - automatic weighing instruments such as weighbridges, platform
machines and crane scales; automatic gravimetric filling instruments; automatic rail
weighbridges; discontinuous totalizing automatic weighing instruments; and such other
weights or measures which cannot, and should not, be moved from their location.
(4) Weights or measures in the premises of the manufacturer or dealer of such weights or
measures.
(5) If a weight or measure is presented to the Legal Metrology Officer for re-verification after
expiry of the validity of the stamp, an additional fee at half the rates specified in SCHEDULE
- IX shall be payable for every quarter of the year or part thereof.
(6) Full fee shall be payable for re-stamping any weight or measure held in stock by a
manufacturer or dealer within the period specified in rule 14 from the date on which it was
last stamped, provided that the original stamp has not been obliterated.
(7) A weight or measure which, on verification or inspection, is found to be incorrect shall be
returned to the person concerned for adjustment, and the Legal Metrology Officer shall
inform him, in a proforma specified by the Controller, of the defects found in the weight or
measure and call upon him to remove the defects within a period not exceeding seven days.
When the necessary adjustment has been carried out, such weight or measure shall be
verified on payment of the fees specified in SCHEDULE - IX and, if found correct, shall be
stamped.
18. Collection of fees and deposit into the Treasury –
(1) Before commencing the work of verification, the Legal Metrology Officer shall inform the
person concerned of the fees payable by him and shall receive the same in the manner
authorized by the Controller and issue a receipt in the form approved by the Controller, one
copy of such receipt being kept on record.
Provided that fees payable by a department of the Central or State Government under these
rules may be realized in such manner as may be directed by the Controller.

7

<!-- page 8 -->

(2) The Legal Metrology Officer shall maintain a register, in the form approved by the Controller,
which shall be written up from day to day and shall show the amount of fees and other
charges collected during the day.
(3) All payment received by the Legal Metrology Officer during the month shall be paid into the
Government Treasury under the appropriate "Head of Account" on such dates or days as
may be specified by the Controller from time to time, and a receipt thereof be obtained and
an intimation to that effect be sent to the Controller or other officer authorized by him in this
behalf.
(4) Fees for verification and stamping of weights and measures shall be paid through offline or
online modes as may be notified by the State Government in the Official Gazette.
19. Disposal of seized articles, goods or items –
(1) Any un-verified weight or measure shall be returned to the person from whom such weight or
measure was seized if that person gets the same verified and stamped within fifteen days of
the date of seizure, on payment of the prescribed fee, including the additional fee payable for
undertaking re-verification after the expiry of the validity of the stamp.
(2) Any weight or measure, document, thing or goods seized and detained under section 15 of
the Act which is to be the subject of proceedings in a court shall be produced by the Legal
Metrology Officer before the court and, after the conclusion of the proceedings, shall be
taken into possession by the Legal Metrology Officer and dealt with in accordance with the
orders of the court:
Provided that, in the absence of any order from the court, the weight or measure, document,
thing or goods shall be dealt with as the Controller may, by special order, direct, and the
material thereof shall be sold and the proceeds credited to the Government.
(3) If any goods seized under section 15 of the Act are subject to speedy or natural decay, the
Legal Metrology Officer shall have the goods weighed or measured on a verified weighting or
measuring instrument available with him or nearest to the place of the offence and enter the
actual weight or measure of the goods in a form specified by the Controller for this purpose,
and shall obtain the signature of the trader, his agent or such other person who has
committed the offence. The goods in question shall be returned to the trader or the
purchaser, as the case may be:
Provided that, if the trader, his agent or such other person who has committed the offence
refuses to sign the form, the Legal Metrology Officer shall obtain the signatures of not less
than two persons present at the time of such refusal by the trader, his agent or other person.
In the case of goods returned to the trader, he shall give an undertaking that he shall not sell
the defective goods without rectifying the defects therein.
(4) Where the goods seized under sub-section (1) of section 15 of the Act are contained in a
package and the package is false or does not conform to the provisions of the Act or any
rules made thereunder, and the goods in such package are subject to speedy or natural
decay, the Legal Metrology Officer, so far as may be, may dispose of the goods in such
package in accordance with the provisions of sub - rule (3):
8

<!-- page 9 -->

Provided that the Controller shall be the final authority to decide whether the goods seized
and detained are subject to speedy or natural decay.
(5) Where the goods seized under sub-section (1) of section 15 of the Act are not subject to
speedy or natural decay, the Legal Metrology Officer may retain the package for the purpose
of prosecution under the Act after giving the trader, his agent or such other person who has
committed the offence a notice of such seizure.
(6) The goods referred to in sub-rule (4) and (5), which are not to be the subject of proceedings
in a court, shall, after the expiry of sixty days from the date of seizure, in cases where no
legal proceedings arise, be dealt with in such manner as the Controller may, by special order,
direct.
20. Validity of Weights or Measures duly stamped –
(1) A weight or measure which is, or is deemed to be, duly verified and stamped under this rule
shall be deemed to conform to the standards established by or under the Act at every place
within the State where it is stamped, unless it is found on inspection or verification that such
weight or measure has ceased to conform to the standards established by or under the Act.
(2) No weight or measure which is, or is deemed to be, duly verified and stamped under this Act
shall require to be re-stamped merely by reason of the fact that it is being used at any place
within the State other than the place at which it was originally verified and stamped:
Provided that, where a verified weight or measure installed at one place is dismantled and
re-installed at a different place, such weight or measure shall not be put into use unless it
has been duly re-verified and stamped, notwithstanding that periodic re-verification of such
weight or measure has not become due.
(3) Where a verified weight or measure has been repaired, whether by a registered repairer or
by the person owning and possessing the same, such weight or measure shall not be put
into use unless it has been duly re-verified and stamped, notwithstanding that periodic reverification of such weight or measure has not become due.
21. Provision of supply of Working Secondary Standards, equipment, etc., to the Legal
Metrology Officer –
(1) Every Legal Metrology Officer shall be provided with Working/Secondary Standards weights,
Working/Secondary Standard balances, and such other weighing and measuring devices as
may be approved by the Controller from time to time.
(2) Every Legal Metrology Officer shall be provided with such dies, punches, paper
seals/stickers and such other equipment as may be necessary for affixing the verification
stamp, the design and number of which shall be approved by the Controller.
(3) Every Legal Metrology Officer shall be provided with punches of suitable sizes of eightpointed star for obliterating.

9

<!-- page 10 -->

22. Provisions relating to use of weights, measure, etc. –
(1) Every person using a beam scale in any transaction at his premises shall suspend the same
by a hook from a stand or chain:
Provided that this sub-rule shall not apply to itinerant vendors.
(2) Every weight or measure shall be used in clean condition and under proper lighting
conditions.
(3) Any weight or measure which has been verified and stamped in situ shall not be dismantled
or removed from its original site without prior intimation to the Controller or any other person
authorized by him in this behalf.
(4) To ensure a proper check of the accuracy of a weighing instrument, the user shall keep at the
site of each weighing instrument duly verified and stamped weights equal to one-tenth of the
capacity of the instrument or a maximum of one tonne, whichever is less, so that consumers
can also check the accuracy of the weighing instrument:
Provided that the Controller may specify the total number of verified and stamped weights to
be maintained at trade premises where more than one weighing instrument is installed.
(5) To ensure proper delivery of the petrol/diesel pumps, the retail dealer of the pump shall keep
a verified 5-litre or 10-litre capacity measure at his premises and check the output from the
pump every day to ensure correct delivery. In case of any short delivery, the dealer shall
immediately stop delivery through the pump and inform the concerned Legal Metrology
Officer for re-calibration the pump.
23. Certificate of Verification to be exhibited –
The person to whom a certificate of verification is provided shall exhibit the same in a
conspicuous place at the premises where the weights, measures or weighing or measuring
instruments to which the certificate relates are used.
Provided that, in the case of an itinerant vendor, the certificate shall be kept with the person.
Provided further that, in the case of a vehicle tank, the certificate of verification shall be kept with
the vehicle.
24. Penalty for contravention of rules –
Whoever contravenes any provision of these rules, for the contravention of which no
punishment has been separately provided in the Act, shall be punished with a fine which may
extend to five thousand rupees.
Where any provision of these rules is inconsistent with the provisions of the Act, the
provisions of the Act shall prevail.

10

<!-- page 11 -->

25. Form of Appeal –
(1) Every appeal under the Act and these rules shall be preferred in the form set out in
SCHEDULE - IX and shall be accompanied by a copy of the order appealed against.
(2) An appeal to State Government shall be accompanied by fee of ₹500, and an appeal to the
Controller shall be accompanied by fee of ₹200, paid either in cash or by affixing a court-fee
stamp, as the case may be.
26. Fee for Compounding of Offences –
The fee for compounding offences committed under the Act shall be as prescribed in SCHEDULE
- X.

Sd/-T.L. GUITE
Secretary to the Government of Mizoram
Food, Civil Supplies & Consumer Affairs Department
Memo No.A.12018/1/2026-FCS&CA(LM)
:
Aizawl, the 27th August, 2026
Copy to:1. Secretary to Governor, Mizoram.
2. P.S. to Chief Minister, Mizoram.
3. P.S. to Speaker/Deputy Speaker.
4. All Ministers/Leader of Opposition, Mizoram.
5. All members of Mizoram Legislative Assembly/CEM,MADC/LADC/CADC.
6. Sr. P.P.S. to Chief Secretary, Government of Mizoram.
7. Director (Legal Metrology), Government of India, Department of Consumer Affairs, Ministry of
Consumer Affairs, Food & Public Distribution, Krishi Bhawan, New Delhi – 110001.
8. Commissioner & Secretary, Mizoram Legislative Assembly Secretariat.
9. All Administrative Department, Govt. of Mizoram.
10. All Heads of Department, Govt. of Mizoram.
11. Controller, Legal Metrology, Aizawl, Mizoram.
12. Controller, Printing and Stationery with a soft copy (via email) for publication in the Mizoram
Gazette.
13. Guard File.

(T.C.LALKHUMA)
Joint Secretary to the Government of Mizoram
Food, Civil Supplies & Consumer Affairs Department

11

<!-- page 12 -->

SCHEDULE - I
[See rule 10]
Exceptions referred to in Rule 10
The following commodities may be sold by weight, measure or number as shown against the commodity
Sl.
No.

Commodity

(1)

(2)

Whether declaration to be expressed in
terms of weight, measure or number or two
or more of them.
(3)

1.

Aerosol products

Weight

2.

Acids in liquid form

Weight or Volume

3.

Compressed or liquefied gas
(but not liquefied petroleum gas)

Weight and equivalent volume at stated
temperature and pressure

4.

Butter (including peanut butter),
cheese, curd, ghee

Weight

5.

Electric cables

Length or weight

6.

Electric wire

Length or weight

7.

Fencing wire

Length or weight

8.

Hair oil, unperfumed

Weight or volume

9.

Fruits and vegetables

Number or weight

10.

Furnace oil

Weight or volume

11.

Linseed oil and other vegetable oils

Weight or volume

12.

Heavy residual fuel oil

Weight

13.

Industrial diesel fuel

Volume

14.

Honey, malt extract, golden syrup treacle

Weight

15.

Ice cream and other similar frozen products

Weight or volume

16.

Liquid chemicals

Weight or volume

17.

Liquid petroleum gas

Weight

18.

Nails, wood screws

Weight

19.

Paint (other than paste paints or solid paint),
varnish and varnish stairs, enamels

Number or weight or volume

20.

Papad

Number and weight

21.

Paste paint, solid paint

Weight

22.

Rosogulla, Gulab Jamun and other sweet
preparations

Weight

23.

Ready-made garments

Number and size

24.

Sauce, all kinds

Weight

25.

Tyres and tubes

Number

26.

Yarn

Weight or length of yarn
12

<!-- page 13 -->

SCHEDULE - 1A
[See rule 15 (2)]
Sl.
No.

Classification
of Risk

1.

High Risk

2.

Medium Risk

3.

Low Risk

Weights and Measures Articles
1. Weighing instruments of high accuracy and special
accuracy classes, both mechanical and electronic,
Classes I & II
2. Automatic Weighing Machine
3. Totalizing Machine
4. Volumetric measuring Instruments
5. Flow/Bulk Meters
6. Automatic Rail Weighbridge
7. Automatic Gravimetric Filling Instruments
(including filling in millilitre or litre and their multiples)
8. Discontinuous Totalizing Automatic Weighing
Instruments (Totalizing Hopper Weights)
9. Compressed Natural Gas
10. Auto LPG
11. Automatic In-motion Road Weighbridge
12. Liquid Measuring Systems other than Water
13. Tank Trucks
14. All Manufacturer/Repairer/Dealer Registrations
1. Weights
2. Capacity Measures
3. Tape Measures
4. Fuel Dispensers (Petrol and Diesel)
5. Length Measures
6. Beam Scales Class A & B
7. Beam Scales Class C& D
8. Counter Machines
9. Tubular Balance
10. Person Weighing Machine excluding Bathroom Scales
11. Peg or Liquor Measure
12. Non-automatic Weighing Instruments, mechanical
(analogue indication) or digital, belonging to ordinary
and medium accuracy Classes III & IV
1. Clinical Thermometer
2. Storage Tank
3. Blood Pressure Measuring Instrument
4. Water Meter
5. Electricity Meter
6. Linear Measuring Instruments
7. Continuous Totalizing Automatic Weighing Instruments
(Belt Weights)
8. Kitchen Scale
9. Bathroom Scales
10. Baby or Child Weighing Scales
11. Weights for High Capacity Weighing Machines
12. Check Weighing and Weight Grading Machines
13. Tapes for use in measurement of oil quantities
13

Frequency
of Inspection

Every year

Once in two
years

Once in five
years

<!-- page 14 -->

FORM - A
Self-Certification Declaration for Low-Risk Category of Weights and Measures
[Under the Legal Metrology Act, 2009 read with the relevant Rules and Ease of Doing
Business (EODB) Reforms]
I. Particulars of the users / establishment
(i) Name of the user/establishment
(ii) Address of the establishment
(iii) Nature of business
(iv) Contact details
(a) Mobile No.
(b) Email Id
(v) Registration / Registration No. / Verification Certificate No (if any)
II. Details of Weights & Measures (Low-risk category)
Sl. No.

Description of
Weights & Measures

Capacity

Quantity

Make/Model

Place of Use

III. Self-Certification Declaration
I/ We hereby declare that –
(i)
(ii)
(iii)
(iv)
(v)
(vi)

the above-mentioned weights and measures fall under the low-risk category specified by
the State Government;
the weights and measures conform to the standards established under the Legal
Metrology Act, 2009 and the rules made thereunder;
the instruments are accurate, correct and properly maintained and are being used only for
lawful commercial transactions;
no unauthorized alteration, tampering or unauthorized stamping has been made to any
weight or measure;
I/We undertake to produce weights or measures for inspection by the Legal Metrology
Officer whenever required;
I/We understand the submission of false or misleading information shall render me/us
liable for action under the provisions of the Legal Metrology Act, 2009 and the rules made
thereunder.

Place __________
Date __________
Signature of User / Authorized Signatory

14

<!-- page 15 -->

FORM - B
Third-Party/State Government Certification of Weights or Measures
(Issued by Registered Repairer under section 23 of the Legal Metrology Act, 2009)
I. Particulars of Repairer:
1. Name of registered repairer:
2. Registration No.:
3. Validity of Registration:
4. Address of workshop:
5. Contact No.:
6. Email:
II. Particulars of user/owner:
1. Name of establishment/user:
2. Address of premises where instruments are installed/used:
3. Contact No.
4. Email:
III. Details of Weight or Measure:
Sl.
No.

Type of
Weight or
Measure

Make

Model

Capacity/
Range

Serial No. of
Weight or
Measure

Class/
Accuracy

Year of
Manufacture

IV. Certification of Accuracy:
I hereby certify that –
(i) the above weight or measure conforms to the prescribed Maximum Permissible Error
(MPE), as applicable;
(ii) the weight or measure is fit for use for commercial transactions.
V. Declaration:
I hereby declare that the information furnished above is true and correct and that any false
certification shall render me liable for action under the Legal Metrology Act, 2009 and the rules
made thereunder.
Date ________
Place ________

Signature of Repairer
Name with seal

15

<!-- page 16 -->

SCHEDULE - II
[See rule 11 (2)]
Form - RM - 1
Application Form for Registration as a Manufacturer of Weights and Measures under
the Legal Metrology Act, 2009
1. Name of the manufacturing concern
for which registration is sought
___________________________________________
2. Complete address of the concern
___________________________________________
3. Mobile No.
___________________________________________
4. Email ID
___________________________________________
5. Name(s) and address(es), along with
the name of father/husband, of the
proprietor(s) and/or partner(s), and
Managing Director(s) in the case
of a limited company
__________________________________________
6. The type of weights and measures
proposed to be manufactured, namely:
(a)
Weights
__________________________________________
(b)
Measures
__________________________________________
(c)
Weighing Instruments
__________________________________________
(d)
Measuring Instruments
with details in each case
__________________________________________
7. Monogram or trademark intended
to be imprinted on the weights and
measures proposed to be manufactured __________________________________________
8. Model Approval No. (if any)
__________________________________________
9. Have you applied previously for a
manufacturer’s registration? If so, when
and with what results?
__________________________________________

To be certified by the Applicant(s)
Certified that I/We have read the provisions of the Legal Metrology Act, 2009 and the rules made
thereunder and agree to abide by the same and by such administrative orders and instructions as may
be provided thereunder from time to time.
I/We agree to deposit the scheduled registration fee with the specified Government Head.
All the information furnished above is true and correct to the best of my/our knowledge and belief.
If any information furnished by me/us is found to be false, I/We shall be liable for appropriate action,
including cancellation of registration.
Place : _______________
Date : _______________

Signature and Designation of the Applicant(s)

16

<!-- page 17 -->

SCHEDULE - II
[See rule 11 (2)]
Form - RR - 1
Application Form for Registration as a Repairer of Weights and Measures under
the Legal Metrology Act, 2009
1. Name of the concern for which
registration is sought
___________________________________________
2. Complete address of the concern
___________________________________________
3. Mobile No.
___________________________________________
4. Email ID
___________________________________________
5. Name(s) and address(es), along with
the name of father/husband, of the
proprietor(s) and/or partner(s), and
Managing Director(s) in the case
of a limited company
___________________________________________
6. The type of weights and measures
proposed to be repaired
___________________________________________
7. Area in which you want to operate
___________________________________________
8. Previous experience in the line
__________________________________________
9. Have you applied previously for a
repairer’s registration? If so, when
and with what results?
__________________________________________

To be certified by the Applicant(s)
Certified that I/We have read the provisions of the Legal Metrology Act, 2009 and the rules made
thereunder and agree to abide by the same and by such administrative orders and instructions as may
be provided thereunder from time to time.
I/We agree to deposit the scheduled registration fee with the specified Government Head.
All the information furnished above is true and correct to the best of my/our knowledge and belief.
If any information furnished by me/us is found to be false, I/We shall be liable for appropriate action,
including cancellation of registration.

Place : _______________
Date : _______________
Signature and Designation of the Applicant(s)

17

<!-- page 18 -->

SCHEDULE - II
[See rule 11 (2)]
Form - RD - 1
Application Form for Registration as a Dealer in Weights and Measures under
the Legal Metrology Act, 2009
1. Name of the establishment/shop/person
seeking the registration
___________________________________________
2. Complete address of the concern
___________________________________________
3. Mobile No.
___________________________________________
4. Email ID
___________________________________________
5. Name(s) and address(es), along with
the name of father/husband, of the
proprietor(s) and/or partner(s), and
Managing Director(s) in the case
of a limited company
___________________________________________
6. The type of weights and measures
sold/proposed to be sold
___________________________________________
7. Have you applied previously for a
dealer’s registration? If so, when and
with what results?
___________________________________________

To be certified by the Applicant(s)
Certified that I/We have read the provisions of the Legal Metrology Act, 2009 and the rules made
thereunder and agree to abide by the same and by such administrative orders and instructions as may
be issued thereunder from time to time.
I/We agree to deposit the scheduled registration fee with the specified Government Head.
All the information furnished above is true and correct to the best of my/our knowledge and belief. If
any information furnished by me/us is found to be false, I/We shall be liable for appropriate action, including
cancellation of registration.

Place : _______________
Date : _______________
Signature and Designation of the Applicant(s)

18

<!-- page 19 -->

SCHEDULE - III
[See rule 11(3)]
Registration Forms
FORM - RM - 3
GOVERNMENT OF MIZORAM
DEPARTMENT OF FOOD, CIVIL SUPPLIES AND CONSUMER AFFAIRS
OFFICE OF THE CONTROLLER OF LEGAL METROLOGY

Registration of Manufacturer of Weights and Measures, Weighing or Measuring Instruments
under Rule 11(3) of the Mizoram Legal Metrology (Enforcement) Rules, 2010
Registration No. _____________
Year : ___________________
1. The Controller of Legal Metrology hereby registers _____________________________
(Name and address of Party/Parties) to manufacture the following: _____________________________________________________________________________________
______ (include details of the weights, measures, weighing instruments or measuring instruments that are
registered to be manufactured by the party/parties)
2. The registration is valid for the party named above in respect of his workshop located at
_______________________________
3. The trademark/Monogram being used by the manufacturer is as below
_______________________________
4. Failure to comply with any of the terms and conditions mentioned below may result in cancellation of this
registration.
Date ____________
Place ____________
(Signature)
Controller of Legal Metrology
Government of Mizoram
(Seal)
TERMS AND CONDITIONS
1. The person in whose favour this registration is issued shall: -

a) comply with all the relevant provisions of the Legal Metrology Act, 2009 and the Rules for the time
being in force;
b) not encourage or countenance any infringement of the provisions of the Act or the Rules
amended from time to time;
c) exhibit this registration in some conspicuous part of the premises to which it relates;
d) comply with any general or special directions issued by the Controller of Legal Metrology;
e) surrender the registration in the event of closure of business and /or cancellation of registration;
f) present the weights, measures, weighing or measuring instruments, as the case may be,
manufactured and meant for use within the State, to the Legal Metrology Officer for verification and
stamping before sale;
2. Every condition prescribed after this registration shall, if notified in the Official Gazette, be binding on
the person(s) to whom the registration has been granted.
19

<!-- page 20 -->

SCHEDULE - III
[See rule 11(3)]
Registration Forms
FORM - RR - 3
GOVERNMENT OF MIZORAM
DEPARTMENT OF FOOD, CIVIL SUPPLIES AND CONSUMER AFFAIRS
OFFICE OF THE CONTROLLER OF LEGAL METROLOGY

Registration of Repairer of Weights and Measures, Weighing or Measuring Instruments
under Rule 11(3) of the Mizoram Legal Metrology (Enforcement) Rules, 2010
Registration No. _____________
Year
___________________
1. The Controller of Legal Metrology hereby registers _____________________________
(Name and address of Party/Parties) to repair the following: ___________________________________________________________________________________________
_____________________________________________ (include details of the weights, measures, weighing
instruments or measuring instruments that are registered to be repaired by the party/parties)
2. The registration is valid for the party named above in respect of his workshop located at
_______________________________
3. The party/parties is registered to repair weights, measures, weighing and measuring instruments in the areas
mentioned below
_______________________________
4. Failure to comply with any of the terms and conditions mentioned below may result in cancellation of this
registration.
Date ____________
Place ____________
(Signature)
Controller of Legal Metrology
Government of Mizoram
(Seal)
TERMS AND CONDITIONS
1. The person in whose favour this registration is issued shall: a) comply with all the relevant provisions of the Legal Metrology Act, 2009 and the Rules for the time being in force;
b) not encourage or countenance any infringement of the provisions of the Act or the Rules amended from time to
time;
c) exhibit this registration in some conspicuous part of the premises to which it relates;
d) comply with any general or special directions issued by the Controller of Legal Metrology;
e) surrender the registration in the event of closure of business and /or cancellation of registration;
f) (i) present the weights, measures, weighing or measuring instruments, as the case may be, duly repaired, to the
Legal Metrology Officer for verification and stamping as specified under rule 15(1), before delivery to the user;
(ii) in the case of weights, measures, weighing or measuring instruments which are serviced or repaired before the
date on which the verification falls due and where, in the process, the verification stamp of the Legal Metrology officer
is defaced, removed or broken, such weights, measures, weighing or measuring instruments shall be presented, duly
repaired, to the Legal Metrology Officer for re-verification and stamping before delivery to the user.
2. Every condition prescribed after the issue of this registration shall, if notified in the Official Gazette, be binding on
the person(s) to whom the registration has been granted.

20

<!-- page 21 -->

SCHEDULE - III
[See rule 11(3)]
Registration Forms
FORM - RD - 3
GOVERNMENT OF MIZORAM
DEPARTMENT OF FOOD, CIVIL SUPPLIES AND CONSUMER AFFAIRS
OFFICE OF THE CONTROLLER OF LEGAL METROLOGY

Registration of Dealer in Weights and Measures, Weighing or Measuring Instruments
under Rule 11(3) of the Mizoram Legal Metrology (Enforcement) Rules, 2010
Registration No. _____________
Year
___________________
1. The Controller of Legal Metrology hereby registers _____________________________
(Name and address of Party/Parties) to deal in the following: __________________________________________________________________________________
(include details of the weights, measures, weighing instruments or measuring instruments that are
registered to be dealt with by the party/parties)
2. The registration is valid for the party named above in respect of his premises located at _______________
3. Failure to comply with any of the terms and conditions mentioned below may result in cancellation of this
registration.

Date ____________
Place ____________
(Signature)
Controller of Legal Metrology
Government of Mizoram
(Seal)
TERMS AND CONDITIONS
1.

2.

The person in whose favour this registration is issued shall: a) comply with all the relevant provisions of the Legal Metrology Act, 2009 and the Rules for the time being
in force;
b) not encourage or countenance any infringement of the provisions of the Act or the Rules
amended from time to time;
c) exhibit this registration in some conspicuous part of the premises to which it relates;
d) comply with any general or special directions issued by the Controller of Legal Metrology;
e) surrender the registration in the event of closure of business and /or cancellation of registration;
f) Not sale or offer, expose or possess for sale any non-standard weight or measure.
Every condition prescribed after the issue of this registration shall, if notified in the Official Gazette,
be binding on the person(s) to whom the registration has been granted.

21

<!-- page 22 -->

SCHEDULE - IV
[See rule 11 (4)]
Government of Mizoram
Office of the Controller of Legal Metrology
Registration Fees for Manufacturers, Repairers, and Dealers of Weights & Measures

Sl. No.

Issue of Registration Certificate

Fee

(i)
(ii)
(iii)

Manufacturer
Repairer
Dealer

₹25,000/₹10,000/₹5,000/-

SCHEDULE - V
[See rule 11 (5)]
Government of Mizoram
Office of the Controller of Legal Metrology
Register of Registered Manufacturers / Repairers / Dealers of Weights, Measures,
Weighing and Measuring Instruments
Office of ________________________________________________________________

Registrati
on
Number

(1)

Name and
complete
address of
the
manufacture
r/
repairer/deal
er
(2)

Place
where
worksho
p/
factory
is
situated

Articles to
be
manufactur
ed/repaired
/sold

Trademar
k
/Monogra
m being
used

Orders
regarding
cancellatio
n of
registration

Result
of
appeal

Signature
of
competen
t authority

Remar
ks

(3)

(4)

(5)

(6)

(7)

(8)

(9)

Note: Column (3) does not apply to dealers, column (5) does not apply to repairers and dealers.

22

<!-- page 23 -->

SCHEDULE - VI
[See rule 13]
Form - RM - 4
Register to be maintained by the Manufacturers of Weights and Measures
1. Name and address of the manufacturer ___________________________________________
2. Description of the weight or measure ___________________________________________
3. (i) No. of the manufacturing registration _________________________________________
(ii) Date on which the registration was issued ______________________________________
(iii) Period of validity of the registration __________________________________________
3. Particulars of order, if any, suspending or revoking the registration _____________________

Sl. No.

Month

Unsold stock
from previous
month

(1)

(2)

(3)

Sold within the State
Dispatch
No. of
voucher
items
No. and
sold
date
(6)
(7)

Quantity

Total (3+4)
manufactured
during the month

(4)

(5)

Sold outside the State
No. of
items
sold

Dispatch
voucher No.
and date

Name
of the
State

Total sold
(6+8)

Balance
(5 - 11)

Remarks

(8)

(9)

(10)

(11)

(12)

(13)

23

<!-- page 24 -->

SCHEDULE - VI
[See rule 13]
Form - RR - 4
Register to be maintained by the Repairer in respect of Weights and Measures
Name and address of the repairer __________________
Registration No. _______________________________
Date of Registration ____________________________

Sl. No.

Date

Name of the user
from whom received

Items and their Nos.
booked for repair

Receipt No. and
date of
issue to the user

(1)

(2)

(3)

(4)

(5)

Amount of
repair charges

Amount of
verification fee

Total amount
charged

Date of return
to the user

Remarks

(6)

(7)

(8)

(9)

(10)

24

<!-- page 25 -->

SCHEDULE - VI
[See rule 13]
Form - RD - 4
Register to be maintained by Dealer in Weights and Measures
1.
2.
3.

Name and address of the dealer ___________________________________________
Description of the weight or measure _______________________________________
(i) Dealer Registration No. _______________________________________________
(ii) Date on which the registration was issued ________________________________
(iii) Period of validity of registration _______________________________________
4. Particulars of order, if any, suspending or revoking the registration ________________
5. Category of weight or measure ____________________________________________
(Category A or B)

Sl. No.

Month

Unsold stock
from the previous
month

(1)

(2)

(3)

Sold within the State
No. of
items sold
(7)

Dispatch
voucher
No. and
date
(8)

Brought from
within the State
during the month

Brought from
outside the State
during the month

Total
(3+4+5)

(4)

(5)

(6)

Sold outside the State
No. of
items
sold

Dispatch
voucher No.
and date

Name
of the
State

Total sold
(7+9)

Balance
(6 - 12)

Remarks

(9)

(10)

(11)

(12)

(13)

(14)

25

<!-- page 26 -->

SCHEDULE - VII
[See rule 16 (3)]
Government of Mizoram
Office of the Controller of Legal Metrology
Certification of Verification
Name of Legal Metrology Officer _______________________________________
No. ________________________________
I hereby certify that I have verified and stamped / rejected the undermentioned weights,
measures, weighing instruments and measuring instruments.
Belonging to ________________________________ Locality ___________________________
Denomination

Weighing Instruments

Quantit
y

Weights

Measure
s

Capacity

Class

Manufacture
r

Type

(1)

(2)

(3)

(4)

(5)

(6)

(7)

Verifi
Measuring
catio
Instrument
n Fee
s
(in ₹)
(8)

(9)

Carriage,
Conveyanc
e,
Adjusting
Charges,
etc.
(10)

Total (in ₹) ............... deposited vide T. Receipt / Money Receipt. No. ............... dated ................

Repaired by / Used by

........................................
(Signature)
Next verification due on ....................................

Legal Metrology Officer

Note: - In the case of rejected weights, measures, weighing instruments or measuring
instruments, the Legal Metrology Officer shall issue a separate certificate of rejection, specifying
the reasons for rejection against each item.

26

<!-- page 27 -->

SCHEDULE - VIII
[See rule 17 (5)]
Fee payable for Verification and Stamping of Weights & Measures,
Weighing and Measuring Instruments
1. A) Bullion Weights:
Denomination
(1)
10 kg
5 kg
2 kg
1 kg
500g
200 g
100 g
50 g
20 g
10 g
5g
2g
1g

Fee (in ₹)
(2)
60.00
40.00
40.00
40.00
30.00
30.00
30.00
30.00
30.00
30.00
30.00
30.00
30.00

Denomination
(1)
100 g (500 c)
40 g (200 c)
20g (100 c)
10g (50 c)
4 g (20 c)
2 g (10 c)
1 g (5 c)
400g (2 c)
200mg (1 c)
100mg (0.5 c)
40mg (0.02 c)
20mg (0.01 c)
10mg (0.05 c)
4mg (0.02c)
2mg (0.01 c)
1mg (0.005c)

Fee (in ₹)
(2)
40.00
40.00
40.00
40.00
40.00
40.00
40.00
40.00
40.00
40.00
40.00
40.00
40.00
40.00
40.00
40.00

C) Cylindrical Knob Type Weights:
Denomination
(1)
10 kg
5 kg
2 kg
1 kg
500 g
200 g
100 g
50 g
20 g
10 g
5g
2g
1g

Fee (in ₹)
(2)
30.00
30.00
30.00
30.00
30.00
30.00
30.00
30.00
30.00
30.00
30.00
30.00
30.00

B) Carat Weights:

27

<!-- page 28 -->

D) Sheet Metal Weight (other than Bullion):
Fee (in ₹)
(2)
10.00
10.00
10.00
10.00
10.00
10.00
10.00
10.00
10.00

Denomination
(1)
500 mg
200 mg
100 mg
50 mg
20 mg
10 mg
5 mg
2 mg
1 mg
E) Iron Hexagonal, Knob Type Weights and Parallelepiped Weights:
Denomination
(1)
50 kg
20 kg
10 kg
5 kg
2 kg
1 kg
500 g
200 g
100 g
50 g
20g
10g
5g
2g
1g

Fee (in ₹)
(2)
50.00
40.00
40.00
40.00
30.00
20.00
10.00
10.00
10.00
10.00
10.00
10.00
10.00
10.00
10.00

F) Standard Weights for testing High Capacity Weighing Machines:

Denomination
(1)
100 kg
200 kg
500 kg
1000 kg
2000 kg
5000 kg

Fee corresponding to Maximum
Permissible Relative Error 0.5/10000
(in ₹)
(2)
150.00
250.00
500.00
1000.00
2000.00
4000.00

28

Fee corresponding to Maximum
Permissible Relative Error 3.3/10000,
1.7/10000 and 1.0/10000 (in ₹)
(3)
100.00
200.00
400.00
1000.00
2000.00
4000.00

<!-- page 29 -->

2. Capacity Measures:

50 L
20 L
10 L
5L
2L
1L
500 mL
200 mL
100 mL
50 mL
20 mL
10 mL
5 mL
2 mL
1 mL

Fee per piece (in ₹)
(2)
₹100.00 for the 1st 100 litres plus ₹50.00 for every additional
100 litres or part thereof subject to maximum of ₹5000.00
100.00
40.00
40.00
20.00
20.00
20.00
20.00
20.00
20.00
20.00
20.00
20.00
20.00
20.00
20.00

Denomination
(1)
2m
1m
0.5 m
1 m graduated (at every cm)
0.5 m graduated (at every cm)

Fee per piece (in ₹)
(2)
20.00
20.00
40.00
40.00
40.00

Denomination
(1)
100 litres and above

3. Length Measures:
A) Non-Flexible

B) Fabric Plastic / Woven / Steel Tapes
Accuracy Class
(1)
Class-I
Class-II
Class-III
C) Folding Scales
Denomination
(1)
1m
0.5 m

Fee per meter (in ₹)
(2)
5.00
5.00
5.00
Fee per piece (in₹)
(2)
20.00
20.00

D) Surveying Chain

4.

Denomination
(1)
30 m
20 m

Fee per piece (in ₹)
(2)
200.00
200.00

Beam Scales Class A & B:
Denomination
(1)
200 kg
100 kg
50 kg
20 kg
10 kg
5 kg
2 kg
1 kg
500 g and below

Fee per piece (in ₹)
(2)
500.00
400.00
200.00
200.00
200.00
200.00
200.00
200.00
100.00

29

<!-- page 30 -->

5.

Beam Scales Class C & D:
Denomination
(1)
1000 kg
500 kg
300 kg
200 kg
100 kg
50 kg
20 kg
10 kg
5 kg
2 kg
1 kg
500 g and below

Fee per piece (in ₹)
(2)
400.00
400.00
400.00
200.00
200.00
50.00
50.00
50.00
30.00
30.00
30.00
20.00

6. Non-Automatic Weighing Instruments - Mechanical (Analogue) Class III & IV:
Denomination
(1)
400 t
300 t
200 t
150 t
100 t
80 t
60 t
50 t
40 t
30 t
25 t
20 t
15 t
10 t
5t
3t
2t
1500 kg
1000 kg
500 kg
300 kg
250 kg
200 kg
150 kg
100 kg
50 kg
30 kg
25 kg
20 kg
15 kg
10 kg
5 kg
3 kg
2 kg
1 kg
500 g and below

30

Fee per piece (in ₹)
(2)
5000.00
4000.00
4000.00
3000.00
3000.00
3000.00
3000.00
3000.00
3000.00
3000.00
3000.00
3000.00
3000.00
2000.00
2000.00
800.00
800.00
450.00
450.00
450.00
450.00
400.00
200.00
200.00
200.00
200.00
200.00
150.00
150.00
100.00
50.00
50.00
50.00
50.00
50.00
50.00

<!-- page 31 -->

7. Non-Automatic Weighing Instruments - Electronic Class III & IV:
Denomination
(1)
400 t
300 t
200 t
150 t
100 t
80 t
60 t
50 t
40 t
30 t
25 t
20 t
15 t
10 t
5t
3t
2t
1500 kg
1000 kg
500 kg
300 kg
250 kg
200 kg
150 kg
100 kg
50 kg
30 kg
25 kg
20 kg
15 kg
10 kg
5 kg
3 kg
2 kg
1 kg
500 g and below

Fee per piece (in ₹)
(2)
4500.00
3500.00
3500.00
2500.00
2500.00
2500.00
2500.00
2500.00
2500.00
2500.00
2500.00
2500.00
2500.00
1500.00
1500.00
1000.00
1000.00
500.00
500.00
500.00
500.00
500.00
500.00
400.00
400.00
400.00
400.00
400.00
200.00
200.00
200.00
200.00
200.00
200.00
200.00
200.00

8. A) Non-Automatic Weighing Instruments Both Mechanical and Electronics Class I & II
Capacity
Fee per piece (in ₹)
(1)
(2)
Exceeding 50 t
4000.00
Not exceeding 50 t but exceeding 10 t
3000.00
Not exceeding 10 t but exceeding 1 t
2000.00
Not exceeding 1 t but exceeding 50 kg
1000.00
Not exceeding 50 kg but exceeding 10 kg
500.00
Not exceeding 10 kg
500.00
B) Automatic Weighing Instruments
Capacity
(1)
Exceeding 100 t
Not exceeding 100 t but exceeding 50 t
Not exceeding 50 t but exceeding 10 t
Not exceeding 10 t but exceeding 1 t
Not exceeding 1 t but exceeding 50 kg
Not exceeding 50 kg but exceeding 10 kg
Not exceeding 10 kg

Fee per piece (in ₹)
(2)
5000.00
4000.00
3000.00
2000.00
1000.00
500.00
500.00

31

<!-- page 32 -->

9.
A)
B)

Volumetric Measuring Instruments
Dispensing Pump
Totalizing Counter

Fee (in ₹)
₹6,000.00 per Nozzle
₹2,000.00 per unit

C) Other Instruments
Fee (in ₹)
(2)
₹1000.00 for the 1st 100 litres plus ₹500.00 for every
additional 100 litres or part thereof.
₹1,000.00
₹500.00
₹400.00

Capacity
(1)
Exceeding 100 litres
Not exceeding 100 litres but exceeding 50 litres
Not exceeding 50 litres but exceeding 20 litres
Not exceeding 20 litres
10.

Flow Metres
Flow Rate up to 100 litres / minute
Above 100 litres / minute upto 500 litres / minute
Above 500 litres / minute

Fee (in ₹)
₹3,000.00
₹4,000.00
₹6,000.00

11.

Linear Measuring Instruments
Taxi, Auto-Rickshaw Meters

Fee (in ₹)
₹200.00
₹100.00 for the 1st 1000 metres or part
thereof plus ₹10.00 for every additional
100 metres or part thereof.

Other Metres

12.
13.

Clinical Thermometer
(i) Water Meter (up to 20 mm)
(ii) Water Meter
(exceeding 25 mm but not exceeding 40 mm)
(iii)Water Meter
(exceeding 45 mm but not exceeding 75 mm)
(iv) Water Meter
(exceeding 80 mm but not exceeding 120 mm)
(v) Water Meter (125 mm and above)

Fee (in ₹)
₹10.00 per unit
₹50.00 per unit
₹100.00 per unit
₹150.00 per unit
₹200.00 per unit
₹250.00 per unit

14. Peg Measure
Capacity
(1)
30 mL
60 mL
100 mL

Fee (in ₹)
(2)
₹100.00
₹100.00
₹100.00

15.
16.

CNG Dispensers
LPG Dispensers

Fee (in ₹)
₹2,000.00 per unit
₹2,000.00 per unit

17.
(i)
(ii)

Counter Machine up to 10 kg capacity
Counter Machine above 10 kg capacity

Fee (in ₹)
₹50.00
₹100.00

32

<!-- page 33 -->

SCHEDULE - IX
[See rule 25 (1)]

Form of appeal against an order of a Legal Metrology Officer / Controller Legal Metrology
1. Name and address of the appellant
2. No. and date of order of Legal Metrology Officer / Controller of Legal Metrology against which
appeal is preferred
3. Whether the appellant desires to be heard in person or through an authorized representative
4. Grounds of appeal

33

<!-- page 34 -->

SCHEDULE - X
[See rule 26]
Compounding fees for various offences
Sl.
No.

1.

Nature of offence under the
Legal Metrology Act, 2009

Penalty for use of non-standard
weight or measure.

Penal
Section

Provision

25

Whoever uses or keeps
for use any weight or
measure or makes use
of any numeration
otherwise than in
accordance with the
standards of weight or
measure or the
standard of numeration,
as the case may be,
specified by or under
the Legal Metrology
Act, 2009, shall be
punished with fine
which may extend to
one lakh rupees and for
second offence with
fine which may extend
to two lakh rupees and
for the third and
subsequent offence,
with fine which may
extend to five lakh
rupees.

Compounding sum which may extend up to
1st Offence

2nd Offence

3rd and Subsequent Offence

For hawkers / non-permanent
establishment

₹500

₹1,000

₹5,000

Retailers

₹5,000

₹10,000

₹20,000

Wholesale Dealer

₹10,000

₹25,000

₹50,000

Manufacturer / Packer /
Importer

₹25,000

₹50,000

₹1,00,000

Petroleum Industry
(Retail Outlets / Tank Lorries /
Storage Depots, etc.)

₹50,000

₹1,00,000

₹2,00,000

Others
(Government Organizations /
PSUs / Cooperative Societies
/ Banks, etc.)

₹25,000

₹50,000

₹1,00,000

34

<!-- page 35 -->

Sl.
No.

Nature of offence under the
Legal Metrology Act, 2009

Penal
Section

Provision

Compounding sum which may extend up to
1st Offence

2nd Offence

3rd and Subsequent Offence

Dealer / Seller

₹50,000

₹1,00,000

₹2,00,000

Manufacturer

₹1,00,000

₹2,00,000

₹4,00,000

Every person who manufactures
or causes to be manufactured or
sells or offers, exposes or
possesses for sale, any weight
or measure which –
(a) does not conform to the
standards of weight or measure
specified by or under the Legal
Metrology Act, 2009; or

2.

Penalty for manufacture or sale
of non-standard weight or
measure.

27

(b) which bears thereon any
inscription of weight, measure or
number which does not conform
to the standards of weight,
measure or numeration
specified by or under the Legal
Metrology Act, 2009, except
where he is permitted to do so
under the Legal Metrology Act,
2009, shall be punished with
fine which may extend to one
lakh rupees and for the second
offence with fine which may
extend to two lakh rupees and
for the third and subsequent
offence, with fine which may
extend to four lakh rupees.

35

<!-- page 36 -->

Sl.
No.

3.

Nature of offence under the
Legal Metrology Act, 2009

Penalty for making any
transaction, deal or contract in
contravention of the prescribed
Standards.

Penal
Section

28

Provision

Compounding sum which may extend up to
1st Offence

2nd Offence

3rd and Subsequent Offence

For hawkers /
non-permanent
establishment

₹500

₹1,000

₹5,000

Retailers

₹5,000

₹10,000

₹20,000

₹10,000

₹25,000

₹50,000

₹25,000

₹50,000

₹1,00,000

₹50,000

₹1,00,000

₹1,50,000

₹25,000

₹50,000

₹1,00,000

Whoever
makes
any
transaction, deal or contract
in contravention of the
Wholesale Dealer
standards of weights and
measures specified under
section 10 shall be punished
with fine which may extend
to fifty thousand rupees and Manufacturer / Packer /
for the second offence with
Importer
fine which may extend to
one lakh rupees and for the
third
and
subsequent
offence, with fine which may Petroleum Industry (Retail
Outlets / Tank Lorries /
extend to two lakh rupees.
Storage Depots, etc.)
Others
(Government
Organizations / PSUs /
Cooperative Societies /
Banks, etc.)
36

<!-- page 37 -->

Sl.
No.

4.

Nature of offence under the
Legal Metrology Act, 2009

Penalty for quoting or
publishing, etc., of non-standard
units.

Penal
Section

29

Provision

Compounding sum which may extend up to
1st Offence

2nd Offence

3rd and Subsequent Offence

For hawkers /
non-permanent establishment

₹500

₹1,000

₹5,000

Retailers

₹5,000

₹10,000

₹20,000

₹10,000

₹25,000

₹50,000

₹25,000

₹50,000

₹1,00,000

₹50,000

₹1,00,000

₹2,00,000

₹25,000

₹50,000

₹1,00,000

Whoever violates section 11
Wholesale Dealer
shall be punished with fine
which may extend to fifty
thousand rupees and for the
second offence with fine
which may extend to one Manufacturer / Packer / Importer
lakh rupees and for the third
and subsequent offence,
with a fine which may extend
to two lakh rupees.
Petroleum Industry
.
(Retail Outlets / Tank Lorries /
Storage Depots, etc.)

Others
(Government Organizations /
PSUs / Cooperative Societies /
Banks, etc.)

37

<!-- page 38 -->

Sl.
No.

Nature of offence under the
Legal Metrology Act, 2009

Penal
Section

Provision

Compounding sum which may extend up to

(a) Selling any article or thing by
weight, measure or number,
delivers or causes or to be
delivered to the purchaser any
quantity or number of that article or
thing less than the quantity or
number contracted for or paid for;
or

5.

Penalty for transaction in
contravention of standard
weight or measure.

30

(b) rendering any service by
weight, measure or number,
renders that service less than the
service contracted for or paid for;
or

₹10,000

(c) buying any article or thing by
weight, measure or number,
fraudulently receives, or causes to
be received any quantity or number
of that article or thing more than
the quantity or number contracted
for or paid for; or
(d) obtaining any service by weight,
measure or number, obtains that
service more than the service
contracted for or paid for.

38

<!-- page 39 -->

Sl.
No.

6.

Nature of offence under the
Legal Metrology Act, 2009

Penalty for non-production of
documents, etc.

Penal
Section

31

Provision

Whoever, being required by or
under the Legal Metrology Act,
2009, or the Rules made
thereunder to submit returns,
maintain any record or
register, or being required by
the Director or the Controller
or any Legal Metrology Officer
to produce before him for
inspection any weight or
measure or any document,
register or other record relating
thereto, omits or fails without
any reasonable excuse, so to
do, shall be punished with fine
which may extend to twenty
five thousand rupees and for
the second offence with fine
which may extend to fifty
thousand rupees and for third
and subsequent offence, with
fine which may extend to one
lakh rupees.

Compounding sum which may extend up to
1st Offence

2nd Offence

3rd and Subsequent Offence

For hawkers /
non-permanent establishment

₹500

₹1,000

₹5,000

Retailers

₹5,000

₹10,000

₹20,000

Wholesale Dealer

₹10,000

₹25,000

₹50,000

Manufacturer / Packer / Importer

₹25,000

₹50,000

₹1,00,000

Petroleum Industry
(Retail Outlets / Tank Lorries /
Storage Depots, etc.)

₹50,000

₹75,000

₹1,00,000

Others
(Government Organizations /
PSUs / Cooperative Societies /
Banks, etc.)

₹25,000

₹50,000

₹1,00,000

39

<!-- page 40 -->

Sl.
No.

Nature of offence under the
Legal Metrology Act, 2009

Penal
Section

Provision

Compounding sum which may extend up to

7.

Penalty for failure to get model
approved.

32

Whoever fails or omits to submit model of any weight or
measure for approval.

₹20,000

8.

Penalty for selling, distribution,
and use of unverified weight or
measure.

33

Whoever sells, distributes, delivers or otherwise transfers
or uses any unverified weight or measure.

₹10,000

40

<!-- page 41 -->

Sl.
No.

9.

Nature of offence under the
Legal Metrology Act, 2009

Penalty for sale or delivery of
commodities, etc., by
non-standard weight or
measure.

Penal
Section

34

Provision

Whoever sells, or
causes to be sold,
delivers, or causes to
be delivered, any
commodity, article or
thing by any means
other
than
the
standard weight or
measure or number,
shall be punished with
fine which may extend
to twenty five thousand
rupees and for the
second offence with
fine which may extend
to
fifty
thousand
rupees and for the
third and subsequent
offence, with fine
which may extend to
one lakh rupees.

Compounding sum which may extend up to
1st Offence

2nd Offence

3rd and Subsequent Offence

For hawkers / non-permanent
establishment

₹500

₹1,000

₹5,000

Retailers

₹5,000

₹10,000

₹20,000

Wholesale Dealer

₹10,000

₹25,000

₹50,000

Manufacturer / Packer / Importer

₹25,000

₹50,000

₹1,00,000

Petroleum Industry
(Retail Outlets / Tank Lorries / Storage
Depots, etc.)

₹50,000

₹75,000

₹1,00,000

Others
(Government Organizations / PSUs /
Cooperative Societies / Banks, etc.)

₹25,000

₹50,000

₹1,00,000

41

<!-- page 42 -->

Sl.
No.

10.

Nature of offence under the
Legal Metrology Act, 2009

Penalty for rendering services
by non-standard weight,
measure or number.

Penal
Section

35

Provision

Whoever renders or
cause to be rendered,
any service through
means other than the
weight or measure or
numeration or in terms
of any weight, measure
or number other than
the standard weight or
measure, shall be
punished with fine
which may extend to
twenty five thousand
rupees and for the
second offence with fine
which may extend to
fifty thousand rupees
and for the third and
subsequent
offence,
with fine which may
extend to one lakh
rupees.

Compounding sum which may extend up to
1st Offence

2nd Offence

3rd and Subsequent Offence

For hawkers / non-permanent
establishment

₹500

₹1,000

₹5,000

Retailers

₹5,000

₹10,000

₹20,000

Wholesale Dealer

₹10,000

₹25,000

₹50,000

Manufacturer / Packer / Importer

₹25,000

₹50,000

₹1,00,000

Petroleum Industry
(Retail Outlets / Tank Lorries / Storage
Depots, etc.)

₹50,000

₹75,000

₹1,00,000

Others
(Government Organizations / PSUs /
Cooperative Societies / Banks, etc.)

₹25,000

₹50,000

₹1,00,000

42

<!-- page 43 -->

Sl.
No.

11.

Sl.
No.

12.

Nature of offence under the
Legal Metrology Act, 2009

Penal
Section

Provision

Compounding sum which may extend up to

Whoever manufactures, packs, imports, sells, distributes,
delivers or otherwise transfers, offers, exposes or possesses
for sale, or causes to be sold, distributed, delivered or
otherwise transferred, offered, exposed for sale any prepackaged commodity which does not conform to the
declarations on the package as provided in the Legal Metrology
Act, 2009.

Penalty for non-compliance of
declaration on
pre-packaged commodities by
manufacturer, packer, importer,
seller or distributor.

36 (1)

Nature of offence under the
Legal Metrology Act, 2009

Penal
Section

Provision

36 (2)

Whoever manufactures or packs or imports or causes to be
manufactured or packed or imported, any pre-packaged
commodity, with error in pet quantity as may be prescribed.

Penalty for error in net quantity
on pre-packaged commodity by
manufacturer, packer or
importer.

1st Offence

2nd Offence

₹25,000

₹50,000

Compounding sum which may extend up to

43

₹50,000

<!-- page 44 -->

Sl.
No.

Nature of offence under the
Legal Metrology Act, 2009

Penal
Section

Provision

13.

Penalty for non-registration by
importer of weight or measure.

38

Whoever imports any weight or measure without being
registered under the Legal Metrology Act, 2009.

₹10,000

14.

Penalty for import of
non-standard weight or
measure.

39

Whoever imports any non-standard weight or measure.

₹10,000

Compounding sum which may extend up to

44

<!-- page 45 -->

Sl.
No.

Nature of offence under the
Legal Metrology Act, 2009

15.

Penalty for giving false
information.

16.

Penalty for giving false return or
maintaining false register.

Penal
Section

Provision

Compounding sum which may extend up to

41 (1)

Whoever for giving false information to the Director, the
Controller or any Legal Metrology Officers in the course of their
duty.

₹5,000

41 (2)

Whoever, being required by or under the Legal Metrology Act,
2009 so to do, submits a return or maintains any record or
register which is false in material particulars.

₹5,000

45

<!-- page 46 -->

Sl.
No.

Nature of offence under the
Legal Metrology Act, 2009

17.

Penalty for manufacture of
weight or measure without
registration.

18.

Penalty for repair or sale of
weight and measure without
registration.

Penal
Section

Provision

Compounding sum which may extend up to

45

Whoever, being required to obtain a registration under the Legal
Metrology Act, 2009 or the rules made thereunder, manufactures,
without being in possession of a valid registration, any weight or
measure.

₹25,000

46

Whoever, being required to obtain registration under the Legal
Metrology Act, 2009 or the rules made thereunder repairs or sells
or offers, exposes or possesses for repair or sale, any weight or
measure, without being in possession of a valid registration.

₹5,000

46

<!-- page 47 -->

Sl.
No.

Nature of offence under
the Legal Metrology Act, 2009

Penal
Section

Provision

Compounding sum which may extend up to

₹20,000

₹5,000

19.

Penalty for tampering with registration.

47

Whoever alters or otherwise tampers, with any registration
issued under the Legal Metrology Act, 2009 or rules made
thereunder, otherwise in accordance with any authorization
made by the Controller in this behalf.

20.

Violation of any Rule made by the State
Government under the Legal Metrology Act,
2009.

53 (3)

Contravention of any rule made by the State Government under
the Legal Metrology Act, 2009.

47
