---
doc_id: "f8c3e12c4bcc16dd"
source_url: "https://forensic.mizoram.gov.in/storage/images/a80da47d-72fb-4e0f-b45b-5869a1c373e8.pdf"
ministry: "Forensic Science Laboratory, Mizoram"
title: "Recruitment Rules of  Director"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9832f5715b93d9d2"
---

<!-- page 1 -->

The Mizoram Gazette
EXTRA ORDINARY

Published by Authority
RNI No. 27009/1973
VOL - XLIV Aizawl,

Tuesday 9.6.2015

Postal Regn. No. NE-313(MZ) 2006-2008
Jyaistha 19,
S.E. 1937, Issue No. 261

NOT IFICAT ION
No. A.12018/81/2011-P&AR(GSW), the 5 th June, 2015. In exercise of the powers conferred by
the proviso to Article 309 of the Constitution of India, the Governor of Mizoram is pleased to make the
following Rules regulating the method of recruitment to the post of Director, Forensic Science
Laboratory under Home Department, Government of Mizoram, namely:
1.

Short title and
Commencement

(1)
(2)

These Rules may be called the Mizoram Home (Forensic Science
Laboratory) Department (Group ‘A’ post) Recruitment Rules, 2015.
These Rules shall come into force from the date of their publication
in the Official Gazette.

2.

Application

These Rules shall apply to the posts specified in Column I of the Annexure-I
hereto annexed.

3.

Number of posts,
Classification and
scale of pay/Pay Band
and Grade Pay

The number of the said post (s), its classification and the scale of pay
attached thereto shall be as specified in Column 2 to 4 of the aforesaid
Annexure – I.

4.

Method of recruitment,
age limit and other
qualifications

The method of recruitment to the said post, age limit, qualification and
other matters relating to the said post shall be as specified in Columns 5 to
14 of the Annexure – I.
Provided that the upper age limit prescribed for direct recruitment
may be relaxed in the case of candidates belonging to the Scheduled Castes/
Scheduled Tribes and other special categories of persons in accordance
with the orders issued by the Central Government or Government of
Mizoram from time to time.

5.

Disqualification

No person –
(a) Who has entered into or contracted a marriage with a person having
a spouse living; or

<!-- page 2 -->

Ex-261/2015

-2(b)

Who, having a spouse living, has entered into or contracted a marriage
with any person shall be eligible for appointment to the said post (s);

Provided that the Governor may, if satisfied that such marriage is
permissible under the personal law applicable to such person and to the
other party to the marriage and that there are other valid grounds for doing
so, exempt any such person from the operation of these Rules.
6.

Training and
Departmental
Examination

Every Government servant recruited under these Rules shall undergo such
training or pass such Departmental Examination as may be prescribed from
time to time.

7.

Power to transfer

Notwithstanding anything contained in these Rules, the Governor of
Mizoram, in public interest, shall have the right and power to transfer any
officers, so recruited under these Rules to any other post or position which
is equivalent in rank or grade.

8.

Power to relax

Where the Governor is of the opinion that it is necessary or expedient so to
do, he may, by order and for reasons to be recorded in writing, in consultation
with the Mizoram Public Service Commission through the Department of
Personnel & Administrative Reforms, relax any of the provisions of these
Rules with respect of any class or category of persons.

9.

Reservations and
other consessions

Nothing in these Rules shall affect any reservation, relaxation of age limit
or other concessions required to be provided for the Scheduled Castes/
Scheduled Tribes and other categories of persons in accordance with the
orders issued by the Central Government or Government of Mizoram from
time to time in this regard.

By orders, etc.
R. Malsawma,
Joint Secretary to the Govt. of Mizoram,
Deptt. of Personnel & Adve. Reforms.

<!-- page 3 -->

-3-

Ex-261/2015

ANN EXUR E-I
(See Rules 2, 3 and 4)
RECRUITMENT RULES FOR GROUP “A” POSTS IN HOME (FORENSIC SCIENCE
LABORATORY) DEPART MENT
Name of posts

No. of posts

Classification

1
Director, Forensic
Science Laboratory

2
1 (one) or as may be
sanctioned from
time to time

3
General State Service
(Group ‘A’ Gazetted)
(Non-Ministerial)

Whether benefit of added
years of service admissible
under Rule 30 of the CCS
(Pension) Rules, 1972

Age limit for
direct recruitment

6
N.A

7
N.A

Method of recruitment whether by
direct recruitment or by promotion
or by deputation/transfer and
percentage of the vacancies to be
filled by various methods
11
Promotion/Deputation

Scale of Pay/Pay Band Whether Selection or
& Grade Pay
Non-selection post
4
5
PB-4 ^ 37,400Selection
67,100 +
^ 8,700 GP

Whether the age and educa- Period of
Educational and other
qualification required for tional qualification pres- probation,
if any
cribed for direct recruitment
direct recruitment
will apply in the case of
promotion
8
N.A

9
N.A

In case of recruitment by pro- If a DPC exists, what
motion or deputation/transfer is its composition ?
grade from which promotion/
deputation/transfer to be made

10
N.A

Circumstances in which
MPSC is to be consulted
in making recruitment.

12

13

14

PROMOTION : From Joint
Director, Mizoram Forensic
Science Laboratory with not
less than 5 (five) years regular
service in the grade

Mizoram Public
Service Commission

As per MPSC
(Limitation of
Functions) Regulation
1994 as amended from
time to time.

DEPUTATION : From Officers
holding analogous post(s)
under Central/State Government (Period of deputation
shall ordinarily not exceed 3
years)

Published and Issued by Controller, Printing & Stationery Department, Government of Mizoram
Printed at the Mizoram Government Press, Aizawl. C/100
