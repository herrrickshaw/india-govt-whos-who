---
doc_id: "cefb46cbf3e2ba27"
source_url: "https://landrevenue.mizoram.gov.in/uploads/attachments/2024/01/e7e3fbbcecc2a693a2fceecc4b0ea289/office-order-10th-jan-24.pdf"
ministry: "Land Revenue and Settlement Department, Mizoram"
title: "Click to view order"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "ac938ace991b1938"
---

<!-- page 1 -->

. Xe
ee Vas GOVERNMENT OF MIZORAM
BENG secay DIRECTORATE OF LAND REVENUE & SETTLEMENT
Email: Irsmizoram@gmail.com Khatla, Aizawl - 796001
Website: https://landrevenue.mizoram.gov.in Phone: (0389) - 2322469
Dated Aizawl, the 10 January, 2024
OFFICE ORDER
In supersession of this Office Order of even No. dt. 12.10.2023, Pu
Lalhmansanga, Joint Director (Admn.), Directorate of Land Revenue & Settlement is hereby
appointed as Vigilance Officer in respect of Group ‘C’ & ‘D’ of Land Revenue & Settlement
Department to examine Property Returns, issue of vigilance status and monitoring of all
Disciplinary proceedings instituted in the Department. His details are:
Name 2 Pu Lalhmansanga
Designation - Joint Director (Admn.)
Mobile No. - 9612131887
Email Address - lhsangal980@gmail.com
Sd/-K. VANLALTHIANA
Director
Land Revenue & Settlement Department,
Mizoram : Aizawl.
Memo No.C.29013/2/2017--DTE(REV)EST Dated Aizawl,the 10% January, 2024
Copy to:
1. The Under Secretary, Vigilance Department for information.
2. All Officers under DLR&S for information.
3. Officer concerned.
4, Guard File.
Director vi 2h
Land Revenue & Settlement Depar' nt,
Mizoram : Aizawl.
