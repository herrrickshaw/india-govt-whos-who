---
doc_id: "df001a4ab940cbdb"
source_url: "https://dhte.mizoram.gov.in/uploads/attachments/2026/08/3875a7243cfea010437ea8fdafeb8aba/posts-627-release-order-5.pdf"
ministry: "Higher and Technical Education Department, Mizoram"
title: "Release Order 5"
date: ""
pages: 5
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "f0fcdc8c0bebfff5"
---

<!-- page 1 -->

BANA KAIH No.A-38012/15/2025-H&TE
FS MIZORAM GOVERNMENT OF MIZORAM
tamer’ HIGHER & TECHNICAL EDUCATION DEPARTMENT
NOTIFICATION
: Aizawl, the 20*" August, 2026
: On attaining the superannuation age of 62 (sixty two) years
as provided under Government Notification No.G.26021/1/2010-FIN(PRU)
dt.12.09.2018, the Governor of Mizoram is pleased to release Prof. C.
Vanlalhruaia, Department of Mizo, Govt. Aizawl College from
Government service w.e.f. the afternoon of 31.10.2026.
His date of birth as per his service record is 27.10.1964.
Sd/-Dr. LALROZAMA
Commr. & Secretary to the Govt. of Mizoram
Memo No.A-38012/15/2025-H&TE : Aizawl, the 20¢ August,
2026
Copy to :-
1. P.S to Minister, Higher & Technical Education Department,Mizoram.
2. Chief Controller of Accounts (Accounts & Treasuries).
3. Director, Higher & Technical Education Department.
4. Controller, Printing & Stationeries with 2 (two) spare copies for
favour of publication in the Gazette.
5. Principal, Govt. Aizawl College
6. Treasury Officer, Aizawl North.
Y Website Manager, Higher & Technical Education.
8. Officer concerned.
9. Personal File concerned. :
10. Guard File. peeling”
Date: 20-08-2026
13:18:32
( ZAHMINGTHANGA)
Under Secretary to the Govt. of Mizoram

<!-- page 2 -->

BANA KAIH No.A-38012/15/2025-H&TE
“ SSMIZORAM GOVERNMENT OF MIZORAM
wmeumesert HIGHER & TECHNICAL EDUCATION DEPARTMENT
NOTIFICATION
; ’ Aizawl, the 20t" August, 2026
On attaining the superannuation age of 62 (sixty two) years
as provided under Government Notification No.G.26021/1/2010-FIN(PRU)
dt.12.09.2018, the Governor of Mizoram is pleased to
release Lalthlengliana Hrahsel, Associate Professor, Department
of Political Sclence, Govt. Hrangbana College from Government
service w.e.f. the afternoon of 30.11.2026.
His date of birth as per his service record is 24.11.1964.
Sd/-Dr. LALROZAMA
Commr. & Secretary to the Govt. of Mizoram
: Memo No.A-38012/15/2025-H&TE : Aizawl, the 2oth August.,
2026
: Copy to :-
1. P.S to Minister, Higher & Technical Education
Department, Mizoram.
2. Chief Controller of Accounts (Accounts & Treasuries).
3. Director, Higher & Technical Education Department.
4. Controller, Printing & Stationeries with 2 (two) spare copies for
favour of publication in the Gazette.
5. Principal, Govt. Hrangbana College :
6. Treasury Officer, Aizawl North.
% Website Manager, Higher & Technical Education.
8. Officer concerned.
9. Personal File concerned.
10. Guard File. Dia sane by
Date: 20-08-2026
13:08:54
( ZAHMINGTHANGA)
Under Secretary to the Govt. of Mizoram

<!-- page 3 -->

BANA KAIH No.A-38012/15/2025-H&TE
= SMIZORAM GOVERNMENT OF MIZORAM
womeeer” HIGHER & TECHNICAL EDUCATION DEPARTMENT
NOTIFICATION
Aizawl, the 20t" August, 2026
: On attaining the superannuation age of 62 (sixty two) years
as provided under Government Notification No.G.26021/1/2010-FIN(PRU)
dt.12.09.2018, the Governor of Mizoram is pleased to
release Lalhmangaihzuali, Librarian, Mizoram Polytechnic,
Lungleifrom Government  servicew.e.f. the afternoon of
30.11.2026. :
Her date of birth as per her service record is 15.11.1964.
Sd/-Dr. LALROZAMA
Commr. & Secretary to the Govt. of Mizoram
‘ Memo No.A-38012/15/2025-H&TE : Aizawl, the 20t aug., 2026
Copy to :-
1. P.S to Minister, Higher & Technical Education Department, Mizoram.
2. Chief Controller of Accounts (Accounts & Treasuries)
3. Director, Higher & Technical Education Department.
4. Controller, Printing & Stationeries with 2 (two) spare copies for
favour of publication in the Gazette.
5. Principal, Mizoram Polytechnic, Lunglei
6. Treasury Officer, Lunglei.
W Website Manager, Higher & Technical Education.
8. Officer concerned. a
. ally I
9. Personal File concerned. Zanintinga
10. Guard File. Date: 20-08-2026
13:11:02
( ZAHMINGTHANGA) :
Under Secretary to the Govt. of Mizoram

<!-- page 4 -->

al
3h
al
al
BANA KAIN No.A-38012/15/2025-H&TE al
< SMIZORAM GOVERNMENT OF MIZORAM i
HIGHER & TECHNICAL EDUCATION DEPARTMENT L
: Aizawl, the 20*" August, 2026
On attaining the superannuation age of 62 (sixty two) years
as provided under Government Notification No.G.26021/1/2010-FIN(PRU) j
dt.12.09.2018, the Governor of Mizoram is pleased to release P, John ;
Tualzamang, Associate Professor, Department of History, Govt. ;
Saitual College from Government service w.e.f. the afternoon of i
31.08.2026.
|
His date of birth as per his service record is 29.08.1964.
Sd/-Dr. LALROZAMA
Commr. & Secretary to the Govt. of Mizoram
. Memo No.A-38012/15/2025-H&TE : Aizawl, the 20th August, 2026
Copy to :-
1. P.S to Minister, Higher & Technical Education Department,
Mizoram.
2. Chief Controller of Accounts (Accounts & Treasuries).
3. Director, Higher & Technical Education Department.
4. Controller, Printing & Stationeries with 2 (two) spare copies for
favour of publication in the Gazette.
5. Principal, Govt. Saitual College
6. Treasury Officer, Saitual.
VA Website Manager, Higher & Technical Education.
8. Officer concerned.
9. Personal File concerned. pen
. igitally signed by
10. Guard File. Zahmingthanga
Date: 20-08-2026
13:13:29
( ZAHMINGTHANGA)
Under Secretary to the Govt. of Mizoram

<!-- page 5 -->

BANA KAIH No.A-38012/15/2025-H&TE
: SMIZORAM GOVERNMENT OF MIZORAM
dummies HIGHER & TECHNICAL EDUCATION DEPARTMENT
NOTIFICATION
Aizawl, the 20th august, 2026
; On attaining the superannuation age of 62 (sixty two) years
as provided under Government Notification No.G.26021/1/2010-FIN(PRU)
dt.12.09.2018, the Governor of Mizoram is pleased to release
Vanlalsawma, Associate Professor, Department of Education,
Govt. Alzawl West College from Government service w.e.f. the
afternoon of 30.09.2026.
His date of birth as per his service record is 26.09.1964.
Sd/-Dr. LALROZAMA
Commr. & Secretary to the Govt. of Mizoram
: Memo No.A-38012/15/2025-H&TE : Aizawl, the 20'" August, 2026
Copy to :-
1. P.S to Minister, Higher & Technical Education
Department, Mizoram.
2. Chief Controller of Accounts (Accounts & Treasuries).
3. Director, Higher & Technical Education Department.
4. Controller, Printing & Stationeries with 2 (two) spare copies for
favour of publication in the Gazette.
5. Principal, Govt. Aizawl West College
6. Treasury Officer, Aizawl North.
NA Website Manager, Higher & Technical Education.
8. Officer concerned.
9. Personal File concerned. oe i
. Zahmingthanga
10. Guard File. Date: 20-08-2026
13:07:46
( ZAHMINGTHANGA)
Under Secretary to the Govt. of Mizoram
