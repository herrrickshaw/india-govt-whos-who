---
doc_id: "c5dbb2db6296f9fe"
source_url: "http://www.cercind.gov.in/2015/regulation/Noti78.pdf"
ministry: "State Load Despatch Centre (SLDC), Mizoram"
title: "CERC(IEGC) (III Amendment) Regulation 2015"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7f704e7ba78a27d8"
---

<!-- page 1 -->

Central Electricity Regulatory Commission
Notification
New Delhi, the 7th August, 2015
No. 1/14/2015-Reg.Aff.(FSDS)(i)/CERC - In exercise of powers conferred
under clause (h) of sub-section (1) of Section 79 read with clause (g) of subsection (2) of Section 178 of the Electricity Act, 2003 (36 of 2003), and all
other powers enabling it in this behalf, the Central Electricity Regulatory
Commission hereby makes the following regulations to amend the Central
Electricity Regulatory Commission (Indian Electricity Grid Code) Regulations,
2010 including the first and second amendments thereof (hereinafter referred to
as “the Principal Regulations”), namely:1. Short title and commencement - (1) These regulations shall be called the
Central Electricity Regulatory Commission (Indian Electricity Grid Code)
(Third Amendment) Regulations, 2015,
(2) These regulations shall come into force with effect from 1st November,
2015
2. Amendment of Regulation 1 of Part 1 of Principal Regulations: SubRegulation (v) under Regulation 1.4 of the Principal Regulations, shall be
substituted as under:“Part 6: Scheduling and Despatch Code: This section deals with the
procedure to be adopted for scheduling and despatch of generation of the
Inter-State Generating Stations (ISGS) and scheduling for other transactions
through long-term access, medium-term and short-term open access
including complementary commercial mechanisms, on a day-ahead and
intra-day basis with the process of the flow of information between the
ISGS, National Load Despatch Centre (NLDC), Regional Load Despatch
Centre (RLDC), Power Exchanges and the State Load Despatch Centres
(SLDCs), and other concerned persons.
Most of the wind and solar energy generators are presently connected to
intra-State network and in future are likely to be connected to the inter-state
transmission system (ISTS) as well. Keeping in view the variable nature of
generation from such sources and the effect such variability has on the interstate grid, and in view of the large-scale integration of such sources into the
grid envisaged in view of the Government of India’s thrust on renewable
sources of energy, scheduling of wind and solar generators which are
regional entities, has been incorporated in this code.”
3. Amendment of Regulation 2 (Definitions) of Principal Regulations:
(i)

Sub-Regulation (eee) of Regulation 2 of the Principal Regulations,
shall be substituted as under:-

<!-- page 2 -->

(eee) “Pool Account” means regional account for (i) payments regarding
Deviation Charges (Deviation Charge Account) or (ii) reactive energy
exchanges (Reactive Energy Account) (iii) Congestion Charge, as the case
may be;
4. Amendment of Regulation 2 of Part 2 of Principal Regulations:
Regulation 2.4.5 of the Principal Regulations, shall be substituted as under
“2.4.5 RPC Secretariat or any other person as notified by the Commission
from time to time, shall prepare monthly Regional Energy Account (REA),
weekly deviation charge account, reactive energy account, and congestion
charge account, based on data provided by RLDC, and deviation charge
account for wind and solar generators which are regional entities, based on
data provided by SLDC/RLDC of the State/Region in which such generators
are located and any other charges specified by the Commission for the
purpose of billing and payments of various charges.”
5. Amendment of Regulation 5.5 of Part 5 of Principal Regulations:
Regulation 5.5.1 (b) of the Principal Regulations, shall be substituted as
under :“A daily report covering the performance of the regional grid shall be
prepared by each RLDC based on the inputs received from SLDCs / Users
and shall be put on its website. This report shall also cover the wind and
solar power generation and injection into the grid.”
6. Amendment of Regulation 6.2 of Part 6 of Principal Regulations: In
Regulation 6.2 of the Principal Regulations, the sentences “This code also
provides the methodology for re-scheduling of wind and solar energy on
three (3) hourly basis and the methodology of compensating the wind and
solar energy rich State for dealing with the variable generation through a
Renewable Regulatory charge. For this, appropriate meters and Data
Acquisition System facility shall be provided for accounting of UI charges
and transfer of information to concerned SLDC and RLDC.” shall be
substituted by the sentences “This code also provides the methodology for
re-scheduling of wind and solar energy generators which are regional
entities, on one and half hourly basis and the methodology of handling
deviations of such wind and solar energy generators. Appropriate meters
shall be provided for accounting of charges for deviation under DSM
Regulations. Telemetry/communication system & Data Acquisition System
shall also be provided for transfer of information to the concerned SLDC
and RLDC.”
7. Amendment of Regulation 6.4(2) of Part 6 of Principal Regulations:
Regulation 6.4(2)(b) of the Principal Regulations shall be substituted as
under:“(b) Ultra Mega Power Projects including projects based on wind and solar
resources and having capacity of 500 MW and above”

<!-- page 3 -->

8. Amendment of Regulation 6.5 of Part 6 of Principal Regulations:
Regulation 6.5 (23) of the Principal Regulations, shall be substituted as
under :“(i) Wind and Solar generators shall mandatorily provide to the concerned
RLDC, in a format as prescribed by RLDC, the technical specifications at
the beginning and whenever there is any change. The data relating to power
system parameters and weather related data as applicable shall also be
mandatorily provided by such generators to concerned RLDC in real time.
The frequency and other details in this regard shall be provided in the
Detailed Procedure to be prepared by NLDC and approved by the
Commission.
(ii) Forecasting shall be done by wind and solar generators which are
regional entities as well as the concerned RLDC. The concerned RLDC
may engage forecasting agency(ies) and prepare a schedule for such
generating stations. The forecast by the concerned RLDC shall be with the
objective of ensuring secure grid operation. The forecast by the wind and
solar generator shall be generator centric. The wind and solar generators
which are regional entities will have the option of accepting the concerned
RLDC’s forecast for preparing its schedule or provide the concerned RLDC
with a schedule based on its own forecast. Any commercial impact on
account of deviation from schedule based on the forecast chosen by the
wind and solar generator shall be borne by it.
(iii) The schedule by wind and solar generators which are regional entities
(excluding collective transactions) may be revised by giving advance notice
to the concerned RLDC, as the case may be. Such revisions shall be
effective from 4th time block, the first being the time-block in which notice
was given. There may be one revision for each time slot of one and half
hours starting from 00:00 hours of a particular day subject to maximum of
16 revisions during the day.
(iv) The schedule of solar generators which are regional entities shall be
given by the generator based on availability of the generator, weather
forecasting, solar insolation/irradiance, season and normal solar generation
curve.”
9. Amendment of Annexure-1 of Principal Regulations: Regulation 4 of the
Annexure-1 of the Principal Regulations, shall be substituted as under :“The wind and solar generators which are regional entities shall forecast
renewable energy generation at the following time intervals:
(i) Day ahead forecast: Wind and solar energy generation forecast with an
interval of 15 minutes for the next 24 hours for the aggregate generation
capacity of 50 MW and above.
(ii) The schedule by such wind and solar generators which are regional
entities, supplying inter-state power under long-term access or mediumterm open access or short-term open access may be revised by giving

<!-- page 4 -->

advance notice to RLDC. Such revisions shall be effective from 4 th timeblock, the first being the time-block in which notice was given. There may
be one revision for each time slot of one and half hours starting from 00:00
hours of a particular day subject to maximum of 16 revisions during the
day.”
10.Amendment of Annexure-1 of Principal Regulations: Para 5 of the
Annexure-1 of the Principal Regulations, shall be substituted as under :“The charges payable for deviation from schedule by the wind and solar
generators which are regional entities, shall be delinked from frequency and
shall be accounted for and settled in accordance with the provisions of the
Central Electricity Regulatory Commission (Deviation Settlement
Mechanism and related matters) Regulations, 2014 as amended from time to
time.”
11.Amendment of Annexure-1 of Principal Regulations: Paras 6, 7 and 9 of
the Annexure-1 of the Principal Regulations, shall be deleted.

(Shubha Sarma)
Secretary

Note: Principal Regulations were published in Gazette of India, Extraordinary,
Part-III, Section 4 at Serial No. 115 on 28.4.2010, the first amendment to
the Principal Regulations were published in the Gazette of India,
Extraordinary, Part-III, Section 4 at Serial No. 60 on 6th March, 2012 and
the second amendment to the Principal Regulations were published in the
Gazette of India, Extraordinary, Part-III, Section 4 at Serial No. 08 on 6th
January, 2014.
