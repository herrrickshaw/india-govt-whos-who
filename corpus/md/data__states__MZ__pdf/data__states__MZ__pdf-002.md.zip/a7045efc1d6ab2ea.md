---
doc_id: "a7045efc1d6ab2ea"
source_url: "https://ifsl.mizoram.gov.in/uploads/attachments/898f225150ef0e50cc73e949e2a8e50b/directions-under-section-10-of-the-lotteries-regulation-act-1998.pdf"
ministry: "Institutional Finance and State Lottery, Mizoram"
title: "Directions under Section 10 of the Lotteries (Regulation) Act, 1998"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ba984ae7f2e1d2ea"
---

<!-- page 1 -->

F. No. 17013/2/2011CSR-I

GOVERNMENT OF INDIA/BHARAT SARKAR
MINISTRY OF HOME AFFAIRS/GRIH MANTRALAYA
CS DIVISION/NORTH BLOCK NEW DELHI
North Block, New Delhi
Dated 2nd August, 2011
To,
The Principal Secretary (Finance)/Secretary (Home)
All State Governments
Subject
1.

:

Directions under Section 10 of the Lotteries (Regulation) Act, 1998

Introduction :

Entry 40 of the Union List of the seventh schedule to the Constitution, mentions
“Lotteries organized by the Government of India or the Government of a State”. Hence,
Government of India has enacted the Lotteries (Regulation) Act, 1998 and has notified the
Lotteries (Regulation) Rules, 2010 (w.e.f. 1.4.2010) for regulation of lotteries in India. In
addition, lotteries being organized by the State Governments are also regulated by the
Judgments passed by the Hon’ble Supreme Court and various other Courts from time to time.
2.

Policy of Government of India

The Policy of the Central Government has been against holding or authorization of
lotteries or extending official support to lotteries in any form and for any purpose, howsoever
laudable, on the ground that they encourage the gambling spirit and disturb the normal
economic equilibrium. Accordingly, the Government of India does not organize any lottery
of its own. All the Union Territories have also been advised not to permit any lottery.
3.

Inter-State Disputes

3.1 It has come to notice that some of the States who are organizing lotteries are not
following the provisions of the Lotteries (Regulation) Act, 1998 and Lotteries (Regulation)
Rules, 2010 scrupulously and are violating certain provisions of the Act/Rules. This not only
defeats the very purpose of formulating the Act/Rules but also causes problems and loss of
revenue to the other States where these are sold, ultimately resulting in inter-state disputes
often leading to court cases.
3.2 It has also come to the notice of this Ministry that many of these violations are often
inadvertent and result from improper understanding of the Act and the Rules. While this
Ministry appreciates the fact that the Rules came into force only w.e.f. 1st April, 2010 and it
likes some time in dissemination of the rules to all authorities & stakeholders and in
understanding the import of each provision, it is the responsibility of the Organising State
Governments to understand and implement the provisions of the Act/Rules in their true letter
and spirit.

<!-- page 2 -->

4.

Responsibility of the State Governments

4.1 This Ministry therefore, reiterates that it is the responsibility of the State Governments
to ensure compliance with the provisions of the Lotteries (Regulation) Act, 1998 and the
Lotteries (Regulation) Rules, 2010 in letter and spirit.
4.2 Based on a review of the implementation of these laws, the State Governments of the
organizing States, are requested :(i)

to ensure that paper lotteries when sold, bear the imprint and logo of the State
in such manner that the authenticity of the lottery ticket is established;

(ii)

to ensure that the entire proceeds of the sale of lottery tickets, as received from
the distributors or selling agents are first credited into the Treasury/Public
Ledger Account/Consolidated Fund of the Organising State without any
deductions etc. Payments of commission to distributors/sole selling agents
etc. and other sundry payables should be made after the entire proceeds are
deposited in the Government Account.

(iii)

to ensure that the lottery tickets are printed only at the Government Press or
any other high security press included in the panel of the Reserve Bank of
India or the Indian Banks Association, Mumbai, as per the provisions of the
Rules and by exercising due diligence. To this end, it is advisable that the
Organizing States themselves monitor the printing and inventory management
of the paper lottery tickets. The distributors, marketing agents etc. should not
be entrusted with the task of receiving and dispatching the lottery tickets from
the Government press/security press.

(iv)

to keep the State Government, in whose territory the tickets are being sold,
duly informed of marketing arrangements established by the Organizing State
and
give
them
all
details
of
persons/firms
involved
in
selling/distribution/printing of lotteries.

(v)

to ensure that the persons/firms involved in selling/distribution/ printing of
lotteries do not violate any provision of the Act/Rules, as the Organizing State
shall be liable for any lapse/violation on their part.

(vi)

to provide such other information to the State Government, in whose territory
the tickets are being sold, as required under the Act/Rules.

(vii)

to conduct an annual financial and systems audit of the various lottery
schemes organized by it to ensure that the provisions of the Act/Rules are not
violated in any manner whatsoever. Concurrent monitoring/auditing would
also go a long way in ensuring compliance of the provisions of the Act/Rules.

(viii)

to keep in direct touch with the officers of the State Government, in whose
territory the tickets are being sold. It is advisable that officers of both
Governments should meet every few months so that issues are mutually
resolved. It is also expected of a State Government, who is aggrieved with
any other State Government, to first raise the issues directly with the State
concerned as per the provisions of Rule-5 of the Lotteries (Regulation) Rules,
2010.

<!-- page 3 -->

(ix)

to ensure that the Agreement entered into by the Organising State with their
distributor/sole selling agent conform to the provisions of the Act/Rules.

(x)

to ensure that only 4 digit lotteries are organized. Single, double and triple
digit lotteries are not permissible under the Act/Rules. Moreover, in any draw
of 4 digits a complete number should be drawn and nothing should be prefixed
or suffixed to a single/double/triple digit number so drawn. In case any such
lotteries are still being organized, these may be withdrawn forthwith.

(xi)

to ensure that draws are conducted only by draw machines or any other
mechanical method based on random technology, which is visibly transparent
to the viewers.

Receipt of this letter may please be acknowledged.

(K.K.Pathak)
Ministry of Home Affairs
Tel No.23092630
