---
doc_id: "f43b44c6ddebc8bc"
source_url: "https://sirdpr.mizoram.gov.in/uploads/attachments/93450ca55ec8c90d8baca2ec4b58511d/national-training-policy-2013.PDF"
ministry: "State Institute of Rural Development & Panchayati Raj (SIRD & PR), Mizoram"
title: "National Training Policy 2013.PDF"
date: ""
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "47aea2a49d6e138b"
---

<!-- page 1 -->

<!-- page 2 -->

National Training Policy 2012
1. Background
1.1 The National Training Policy was issued in April 1996 through a set of Operational Guidelines for the
development of the human resources of the Government. This followed the process of liberalization of the
economy through de‐licensing and deregulation begun in 1991 and the 73rd and 74th Amendments to the
Constitution, which took effect in 1993 thereby creating the third tier of Government at the Panchayat and
Municipal levels.
1.2 These, along with other changes since then, such as rapid economic growth, devolution of funds,
functions and functionaries to the Panchayats and Municipalities, enhanced transparency through the
right to information, globalization, climate change and extremism have created a complex and challenging
environment in which the civil service has to function at a time when there are increasing expectations of
its performance and ability to respond more efficiently and effectively to the needs of the citizens.
1.3 Over this period, the Human Resource Management function has also undergone a significant change.
Organisations are attaching tremendous importance to the management and development of their
people. There is increasing recognition that the individual in an organisation is a key resource and should
not be simply looked upon as a cost.
1.4 Government systems of personnel administration continue to focus largely on the rules and
procedures governing the recruitment, retention and career development of the civil service. Systematic
training of civil servants has continued to be mainly for the higher civil services with a large number of
Group B and C employees receiving sporadic training, if any at all. With the creation of the third tier of
Government, the training of functionaries in the Panchayat and Municipal bodies has become a critical
concern.
1.5 For transforming the civil service, it is imperative to move to a strategic human resource management
system, which would look at the individual as a vital resource to be valued, motivated, developed and
enabled to achieve the Ministry/Department/Organisation’s mission and objectives. Within this
transformational process, it is essential to match individuals’ competencies with the jobs they have to do
and bridge competency gaps for current and future roles through training.

1

<!-- page 3 -->

2. Competency Framework
2.1 Competencies encompass knowledge, skills and behaviour, which are required in an individual for
effectively performing the functions of a post. Competencies may be broadly divided into those that are
core skills which civil servants would need to possess with different levels of proficiency for different
functions or levels. Some of these competencies pertain to leadership, financial management, people
management, information technology, project management and communication. The other set of
competencies relate to the professional or specialized skills, which are relevant for specialized functions
such as building roads, irrigation projects, taking flood control measures, civil aviation, medical care, etc.
2.2 A fundamental principle of the competency framework is that each job should be performed by a
person who has the required competencies for that job.
2.3 Training has usually been based on the duties that are to be performed in a particular post. There has
been no comprehensive review or classification of all posts in accordance with functions that are to be
performed and the competencies required thereto. Thus, the issue of whether an individual has the
necessary competencies to be able to perform the functions of a post has not been addressed. For moving
to a competency‐based approach, it would be necessary to classify the distinct types of posts and to
indicate the competencies required for performing work in such posts. Once the competencies are laid
down, an individual’s development can be more objectively linked to the competencies needed for the
current or future jobs. Career progression and placement need to be based on matching the individual’s
competencies to those required for a post. The training plan of each Ministry/Department/Organisation
needs to address the gap between the existing and the required competencies and provide opportunities
to the employees to develop their competencies.
3. Training Objectives
3.1 The objective of training will be to develop a professional, impartial and efficient civil service that is
responsive to the needs of the citizens. In doing so, care will be taken to emphasize the development of
proper ethics, commitment to work and empathy for the vulnerable sections such as differently abled,
senior citizens, SCs, STs etc.. The competency framework will be used to ensure that civil servants have the
requisite knowledge, skills and attitude to effectively perform the functions they are entrusted with. The
success of training will lie in actual improvement in the performance of civil servants.

2

<!-- page 4 -->

4. Training Target
4.1 All civil servants will be provided with training to equip them with the competencies for their current or
future jobs. Such training will be imparted:
(a) At the time of their entry into service, and
(b) At appropriate intervals in the course of their careers.
4.2 Such training will be made available for all civil servants from the lowest level functionaries to the
highest levels.
4.3 The opportunities for training will not be restricted only at mandated points in a career but will be
available to meet needs as they arise through a mix of conventional courses, distance and e‐learning.
4.4 Priority will be given to the training of front‐line staff, including training on soft skills, so as to improve
customer orientation as well as quality of service delivery to the citizens.
5. Role of Ministries/Departments
5.1 Each Ministry/Department shall adopt a Systematic Approach to Training and shall:
i.

Appoint a Training Manager who will be the Nodal Person for implementation of the training
function in that Ministry /Department;

ii. Create a Training Cell with HR and Capacity Building Professionals to assist the Training Manager;
iii. Classify all posts with a clear job description and competencies required;
iv. Develop Cadre Training Plans (CTPs), based on the competencies required and training needs, for
ensuring that all cadres under the Ministry/Department or its attached/sub‐ordinate offices have a
clearly articulated scheme for the development of their competencies while also indicating the
programmes that are mandatory;
v. Link the training and development of competencies of individuals to their career progression and
ensure this by suitably amending service rules/issuing administrative instructions;
vi. Ensure that any non‐training interventions that need to accompany training interventions are also
taken up suitably;
vii. Make the immediate supervisor responsible and accountable for the training of the staff working
under him;

3

<!-- page 5 -->

viii. Incorporate an appropriate provision in any new scheme to ensure that suitable training is
imparted for its proper implementation and sustainability;
ix. Where feasible, use the services of the Training Institutions in developing the cadre training plans,
outsourcing training, and/or providing advisory or consultancy services to the Ministry;
x. Prepare an annual training plan for all the cadres under its control;
xi. Implement the Annual Training Plan (ATP), by using the institutions under it or outside, so that the
limitations on internal training capacity do not constrain the implementation of the training plan;
xii. Allocate appropriate funds to enable the training to be carried out by institutions under its control
or outside;
xiii. Incorporate a separate section in the Ministry’s annual report on training and capacity building
activities undertaken during the year;
xiv. Provide induction training to new entrants and prepare and upload the induction material on the
website of the Ministry/Department for easy accessibility;
xv. Organize ‘On the Job’ and ‘In‐house’ training as may be required.
6. Role of Training Institutions
6.1 Government training institutions lie at the heart of the training system. They are the repositories of the
expertise distilled from the real world. The quality and manner of their functioning has a direct impact on
what their trainees imbue and take with them. They will continue to be the mainstay for training of civil
servants. Given their role, it becomes imperative for them to become leaders in the process of enabling
learning and change. They should:
i. Have the requisite staff, infrastructure and finances to perform their functions;
ii. Move to becoming models of excellence in the quality of the training they impart and as learning
organisations through a process of self‐assessment and bench‐marking;
iii. Provide technical assistance and advice in preparation of annual training plans for the
Ministry/Department and in outsourcing training (if so required);
iv. Play a key role in assisting the Ministries/Departments in the process of shifting to a competency
based‐framework for training (as applicable);

4

<!-- page 6 -->

v. Assimilate technologies with a view to enabling learning anywhere, anytime for their clients;
vi. Supplement their current programmes with distance and e‐Learning courses;
vii. Conduct field studies and research as part of the process of becoming repositories of knowledge in
the areas of their sectoral or functional specialization (as applicable);
viii. Provide advisory and/or consultancy services (as applicable);
ix. Network with other institutions to share learning resources, experience and expertise;
x. Facilitate the development of domain specific trainers and provide stability of tenure and
opportunities for faculty development;
xi. Ensure that all trainers who join the institute are deputed at the earliest possible opportunity to
undergo programmes for ‘Training of Trainers’;
xii. Maintain database of trained manpower for future reference;
xiii. Give special focus on behavioural/attitudinal training.
7. Trainer Development
7.1 The Trainer Development Programme (TDP) has been one of the most successful instances of transfer
of learning under a donor project resulting in the development of a cadre of trainers. The concept of
“once a trainer, always a trainer” that was enunciated in the National Training Policy, 1996 has aided its
success. The Trainer Development Programme is, however, based on curricula and content developed over
the last three decades. While the core principles of learning have not changed, there are new
developments in the field of training techniques and particularly in the use of technology in enabling and
facilitating training for large numbers of people. There is an urgent need to identify the current
international best practices in training skills and techniques and develop a cadre of trainers in such
skills/techniques. There is also a need for setting up a Learning Resources Centre (LRC), preferably on a
suitable public private partnership mode so that sustainable indigenous capacity is built in this area.
7.2 Certification of trainers under the Trainer Development Programme has to be on a renewable basis
related to their actually conducting a required number of training programmes and also attending courses
meant for upgrading their skills.

5

<!-- page 7 -->

7.3 While the Trainer Development Programme on training techniques and skills has evolved over the
years, the development of domain specific trainers has largely been ignored. Given the plethora of training
institutions in the diverse areas of Government functioning, it is desirable to develop cadres of trainers in
different sectoral and functional specializations. Different Ministries/Departments would need to take the
initiative to develop such trainers in the areas of their responsibility.
7.4 The Sixth Central Pay Commission has proposed major incentives such as 30 percent Training
Allowance, rent‐free accommodation etc. for Central Training Institutions for Group A officers, in
recognition of the importance of this function and to attract a wider range of officers to this function. It is
recommended that State Governments provide similar incentives to the faculty of the State Training
Institutions.
8. Foreign Training
8.1 Foreign training fills a crucial gap in the training system. It provides opportunities for officers to gain
exposure to the latest thinking on different subjects in some of the leading institutions of the world. It
exposes them to experiences and best practices of different countries with differing models of
development and governance. Since 2001, the scheme of Domestic Funding for Foreign Training (DFFT)
has become the main source under which officers are now sent for foreign training.
8.2 There is a need to continue and strengthen the DFFT scheme as well as other similar schemes of
various cadre controlling authorities so that officers have the opportunity to attend both long‐term and
short‐term programmes to develop in‐depth competencies in a range of subjects/areas or specific
specialized subjects. This is particularly important for officers who are likely to hold positions at the senior
most levels of Government where they need to be aware of, and take into account, the broader global
context in policy formulation as well as international best practices.
9. Funding
9.1 Each Ministry/Department/Organization shall provide adequate funding to meet the training
requirement.
9.2 The National Training Policy of 1996 had recommended that 1.5 percent of the salary budget be set
aside by each Department to be used solely for the purpose of training. Given the likely increase in the
need for training by moving to a competency‐based system, it is recommended that each
Ministry/Department/Organization set aside at least 2.5 percent of its salary budget for training.

6

<!-- page 8 -->

10. Training for Urban and Rural Development
10.1 The 73rd and 74th Amendments of the Constitution resulted in a radical change in the status of the
Panchayati Raj Institutions and Urban Local Bodies by prescribing constitutionally mandated devolution of
powers and resources to them as the third tier of Government. These institutions are critical for the
development of the rural and urban areas as well as delivery of many essential services to the citizen. The
national level flagship programmes for rural and urban development have highlighted the need for
capacity development in the rural and urban level institutions for effectively implementing the
programmes.
10.2 Rural and urban local bodies’ functionaries need to have the competencies to be able to perform their
work efficiently and their training is, therefore, of paramount importance. As the officers of the IAS and
State Civil Services play an important role in the administrative set up at all levels, they need to be
familiarised with grassroots institutions of rural and urban governance. As in case of attachment with
other Departments, the IAS Probationers/Officer Trainees may be given ‘hands on experience’ of grassroot level administration in Panchayati Raj Institutions and Urban Local Bodies by placing them as
Executive Officers of Gram Panchayats/Municipalities for a suitable duration. This arrangement may be
made within the overall framework of the recommendations of the ‘Syllabus Review Committee’ for the
induction training. Similar attachments could also be considered by the State Government for inclusion in
the training schedule of probationers of the State Civil Services.
10.3 Suggested areas for capacity building in rural and urban development:

i.

Rural development : Rural Sociology, Rural Development/Welfare Programmes, Rural Planning,
Agricultural Marketing and Agricultural Finance, Rural Industries, role of Non‐Government
Organizations in rural development, Rural Co‐Operatives, Conflict Management in Rural Areas;

ii. Urban Development : Decentralization and Urban Governance, Urban land issues, urban
environment, urban transport, Urban planning and Infrastructure development, Urban Poverty
and Social Development, Municipal Accounts and Finance , e–Governance for urban development.

7

<!-- page 9 -->

11. Implementation and Coordination
11.1 A National Training Council, chaired by the Minister, Ministry of Personnel, Public Grievances and
Pensions, shall be constituted for giving overall direction for the implementation of this Policy.
11.2 For monitoring the implementation of the National Training Policy and taking appropriate steps to facilitate
such implementation, there shall be a Committee chaired by the Secretary, Ministry of Personnel, Public
Grievances and Pensions and consisting of the Secretaries of the Departments of Urban Development and Rural
Development, Administrative Reforms & Public Grievances, the Director of the LBSNAA and three
Representatives each of the State and Central Training Institutions (on a 2 year rotational basis) with Joint
Secretary (Training) as the Member Secretary. This Committee will meet bi‐annually.
11.3 The Training Division of DoPT shall be the nodal agency for the implementation of this policy and shall
issue appropriate guidelines to amplify and facilitate its implementation.
11.4 Development of Competency Framework: With the shift to development of a competency based
framework for the management of the Human Resources including training, the Training Division would
need to enhance its own capacity (in terms of staff and their competencies) to be able to provide the
leadership in detailing the manner in which the work is to be done, providing guidance and handholding
support to the Ministries and Departments and monitoring the progress so that the standards of quality in
developing the competencies are adhered to and the task is completed in a reasonable period in a mission
mode.
11.5 Capacity Building for National Flagship Programmes: Ministries are scaling up their training activity
and National Flagship Programmes such as the Jawaharlal Nehru National Urban Renewal Mission
(JNNURM), Mahatma Gandhi National Rural Employment Guarantee Programme (MGNREGP), National
Rural Health Mission (NRHM), and Sarva Shiksha Abhiyan (SSA) are allocating large amounts for capacity
building. In this scenario, it becomes even more important to ensure that such training/capacity building
programmes are properly conceived, structured, implemented and their impact assessed so that the
expenditure achieves the purpose it was meant to. The Training Division would need to take the lead in
developing the competencies of the Training Managers in the Ministries so that they are better able to
provide support and guidance to their Ministries in the design and implementation of capacity building
schemes.

8

<!-- page 10 -->

11.6 The Training Division needs to provide technical support to the Ministries concerned and the States in
the development of need based training schemes through creation/augmentation of training
infrastructure, faculty development and out‐sourcing of training. Many states already have excellent
infrastructure in the apex training institutes as well as SIRDs and SIUDs. With proper co‐ordination, synergy
can be created with the state ATIs so that capacities, which already exist, can be optimally utilised.
11.7 Distance and E‐Learning: Distance and e‐learning provide unparalleled opportunities for meeting the
training needs of large number of civil servants dispersed across the country in different cities, towns and
villages. The Training Division has taken a major step in this direction by tying up with IGNOU to facilitate
distance learning in a wide range of subjects and courses. Technology provides the means to make
available a vast resource of learning material and courses online providing individuals with enormous
choice and flexibility in learning. The Training Division needs to take the lead to ensure that institutions
make available training courses/material through an E‐Learning Portal as well as through the more
conventional modes of distance learning. The portal would be a platform to bring together the numerous
Government and other training institutions for providing a single point of access to the repository of
training resources. The Training Division should also build up databases of the training resources available
such as calendars of training programmes of different institutions, faculty in different subjects, etc.
11.8 Capacity Building in States:
(i) State Training Policies: It is recommended that each State formulate/adopt a training policy based on
and similar to the new National Training Policy so that there is a formal, articulated framework within
which training is conducted at the state level. This would enable States to develop an action plan including
identification of institutions, training programmes, trainers etc. for training of State civil servants. In order
to facilitate the process of formulation of training policies by the States, a model State Training Policy may
be prepared by the Training Division.
(ii) Role of State Administrative Institutes (ATIs): It is recommended that the State Governments designate
the State Administrative Training Institutes as Apex Training Institutions of the State and empower them to
play a lead role in co‐ordinating training across sectors and departments. Further, the ATIs need to be
strengthened with adequate funds, infrastructure, manpower and decision making powers.
(iii) Support from Training Division: The Training Division continues to have an extremely important role in
supporting the development of Training Capacity in the States. It needs to be provided with adequate
funds for supporting need based training schemes as may be proposed by the States. It should focus, in
particular, on the following:

9

<!-- page 11 -->

a) Supporting the creation of decentralised training infrastructure (at the divisional, district or subdistrict levels) concomitant with the development of trainers at those levels;
b) Strengthening and empowering State training institutions (including improving the quality of
selection of faculty and their development); and
c) Specifically supporting training of civil servants at the grassroots level, including Panchayat
functionaries, to improve delivery of services by upgrading their skills and knowledge and
improving their responsiveness in meeting citizens’ needs.
12.

Monitoring and Evaluation

12.1

Monitoring and Evaluation (M&E) is a powerful tool to improve the way governments and

organizations achieve results. Research studies indicate that effectiveness of training and development is
significantly increased if the monitoring and evaluation of training programmes is systematically
undertaken. In the era of globalisation and competition, training cannot remain an act of faith. It needs to
demonstrate the returns on investment.
12.2

Evaluating the effectiveness of training is a very important but difficult aspect of training

administration. Often, the evaluation in training institutions is limited to post‐course questionnaires
inviting trainees to comment on the course, trainer and training material. This cannot give a fair measure
of whether investment in training is justified. Consequently, there is a need to embed comprehensive
impact evaluation in the training eco‐system where evaluation is not confined to the quality of training
programmes or the learning derived by the participants but also evaluates changes in the job behaviour
that resulted from the programme and its impact on organizational effectiveness and improvement in the
satisfaction level of clients/citizens.
12.3

Role of Training Division

(I)

Monitoring the implementation of National Training Policy

(II)

Maintain a database of training and development activities undertaken by various
Ministries/Departments

(III) Issue advisories from time to time so that training programmes are conducted based on
‘Systematic Approach to Training’ and build capacity of the Ministries/Departments and training
institutions in the area

10

<!-- page 12 -->

(IV) Ensure

that

Training

Managers

are

appointed

in

all

Central

Government

Ministries/Departments, build their capacity and work in close coordination with them
12.4
(I)

Role of Ministry/Department
Develop a Training Management Information System (TMIS) to facilitate training and
development activities of the Ministry/Department.

(II)

Undertake benchmarking/evaluation study of training institutions under the control of
Ministry/Department to mould them as Centres of Excellence

(III) Commission surveys/studies to measure the clients’/customers’ satisfaction level on the services
delivered by the Ministry/Department
(IV) Review the implementation of the Annual Training Plan, Cadre Training Plan and the functioning
of Training Institution(s) under the Ministry/Department (including attached/subordinate
offices) and in particular to look at the:
a) Utilisation of training capacity;
b) Quality of training conducted;
c) Adequacy of the physical and training infrastructure, faculty, finances and delegation of
powers for carrying out the institutes’ mandate;
d) Training of the Group B and C staff, particularly those at the cutting‐edge level (as may be
applicable); and
e) Proper selection and development of faculty, incentives for them and stability of their tenure.
The conduct and character of the selected faculty should be demonstrative of the ethics and
values taught in the classroom.

12.5
(I)

Role of Training Institution
Keep track of latest and international trends in training and development and replicate/assimilate
them in Indian context

(II)

Constantly hone and upgrade the skills of trainers/faculty members in the new and emerging
training techniques and methodologies and assess/review their performance as trainers/faculty.

(III) Constantly review and modify curricula, content and training methodologies to take account of
training feedback and the needs of clients;

11

<!-- page 13 -->

(IV) Put in place a rigorous system of evaluation of training programmes and assessment of their
impact on individual’s performance over time; and
(V)

Conduct evaluation studies to assess the impact of training programmes conducted by it on
organizational performance.

12
