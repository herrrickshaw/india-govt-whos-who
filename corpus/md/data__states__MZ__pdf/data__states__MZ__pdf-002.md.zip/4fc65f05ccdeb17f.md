---
doc_id: "4fc65f05ccdeb17f"
source_url: "https://excise.mizoram.gov.in/uploads/attachments/2023/02/797a79fbe4d32739c4f931d9801c0676/posts-324-promotion-order-of-driver-rc-tlangthangmawia-and-driver-vanlalnghaka-to-driver-special-grade.pdf"
ministry: "Excise and Narcotic Department, Mizoram"
title: "Promotion order of Driver RC Tlangthangmawia and Driver Vanlalnghaka to Driver Special Grade"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "250962e524c25def"
---

<!-- page 1 -->

NO.A.32012/1/2020-COMEX
GOVERNMENT OF MIZORAM

COMMISSIONERATE OF EXCISE NARCOTICS
COMMISSIONERATE OF EXCISE NARCOTICS BUILDING

OproslTE AI]AL CLUB, KHATLA; AlzAWL-796Ooi, MlzoRAM

Dated Aizawl, the 7th December,2022.

OFFICE ORDER

On the recommendation of Mizoram Subordinate Service Selection Board
(MSSSB) and in the interest of Public Service, the following Driver Grade - I are hereby
upgraded to Driver Special Grade at Level-07 in the pay Matrix (Rs. 39,100-Rs. 86,800)

p.in. plus usual allowance as admissible under rules with eifect from the date as shown
against each of their names:
Sllno

Name

Place of Posting

Effective date ofpromotion

1.

R.C. Tlangthanmawia

17.12.2022

2.

Vanlalnghaka

Office of the Assistant Commissionerate
of Excise & Narcotics, Mamit
Commissionerate of Excise & Narcotics,

17.12.2022

Prosecution Branch Aizawl

The expenditure on pay and allowances is debitable to the head of account:
Major Head
Sub-Major Head
Minor Head
Sub-Head
Detail Head
Object Head

2039 -State Excise
00
001 -Direction & Administration
01
-Direction
00
(01) -Salaries during 2022-2023.

This issues with the approval of the Govt. conveyed vide. No.A.32015/2/2022-EXC
dt.06.12.2022

The initial pay in Driver Special Grade should be fixed under FR 22 read with
clarification there under Mizoram (Revision of Pay) Rules, 2010.

Sd/-NGURCHUNGNUNGA SAIL0

Commissioner of Excise & Narcotics
Mizoram: Aizawl

Memo No.A.32015/1/2022-COMEX : Dated Aizawl, the 7t`h December,2022.
Copy to:Secretary-cum-Controller of Examination Mizoram Subordinate Service Selection
Board for information.
Under Secretary to the Govt. of Mizoram, Excise & Narcotics for information. .
All Assistant Commissioners of Excise & Narcotics for information.
Treasury Officer, Aizawl South/Mamit for information.

Person concerned.
Personnel file concerned.
Computer Operator for uploading in Dept. website.

.-

Guard File.

Commission

Excise & N

toMizoram:--A-iz-a-w-I
