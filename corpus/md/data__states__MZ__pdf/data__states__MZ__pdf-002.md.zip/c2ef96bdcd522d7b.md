---
doc_id: "c2ef96bdcd522d7b"
source_url: "https://sirdpr.mizoram.gov.in/uploads/attachments/2022/10/10aa744784319338998c7e09f33cf202/notification-2.pdf"
ministry: "State Institute of Rural Development & Panchayati Raj (SIRD & PR), Mizoram"
title: "View"
date: ""
pages: 2
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "3fc223c141c91221"
---

<!-- page 1 -->

: No.B.13015/57/2022-LAD
os. GOVERNMENT OF MIZORAM
: ; LOCAL ADMISTRATION DEPARTMENT
REE EERE
Dated Aizawl, the 1st September, 2022.
NOTIFICATION
In pursuance of the minutes of the meeting held on 11% August, 2022 under the
chairmanship of Secretary, Local Administration Department and in the interest of public
service, the Governor of Mizoram is pleased to constitute the State Level Nodal Officers
Monitoring Committee for Rashtriya Gram Swaraj Abhiyan (RGSA) National Panchayat
Awards with the following members with immediate effect and until further orders.
. Chairman : Secretary, Local Administration Department.
Members:
1. Pu Zoremthara Ralte, Deputy Secretary, Rural Development Department
(Poverty Free and Enhanced Livelihoods Panchayat).
s Ph - 9612617440.
2, Dr.Vanlalsawma, Joint Director(FW), Health & Family Welfare
f Department(Healthy Panchayat).
Ph - 9612163120
3. Pi Ng.Fanchun, Deputy Director, School Education Department (Child-Friendly
Panchayat).
Ph - 9862463708.
4, Pi Vanlalhruaii, Deputy Director, Dte, of Woman & Child Development (Women
Friendly Panchayat.
4 ; Ph- 9436146477. ay
. Mi - 5. Pu H.Lalnuntluanga, E.E., 0/o E-in-C, PHED (Water Sufficient Panchayal)
Ph - 9862844693.
wr 6. Pu K.Zohmingliana, Programme Manager (PMU), PHED(Clean and Green
Panchayat)
Ph - 8731914282/7005467177.
7. Pu Lalchawimawia, Joint Director(P), LAD (Self-Sufficient Infrastructure in
Panchayat & Socially Secured Panchayat).
Ph ~ 9436143225.
8. Pu K.David Lalthanmawia, Faculty (Planning)( Panchayat/Village Council with
Goed Governance)
ges yg t, Ph - 9774403012.
Sm uttsod | Sd/-DAVID LALTHANTLUANGA
JE f . 32)9 [22 i Secretary to the Govt. of Mizoram
! 4 Local Administration De partment.

<!-- page 2 -->

: Memo No.B.13015/57/2018-LAD f Dated Aizawl, the 1st September, 2022.
oo
: Copy to:
5 1. P.S to Minister, Local Administration Department.
2. Secretary to Governor, Mizoram.
3. Principal Secretary to Chief Minister, Mizoram.
4, PS to Deputy Chief Mizoram, Mizoram.
5. PS to Speaker/Deputy/ Minister/ Vice-Chairman, State Planning Board,
Mizoram/Govt. Deputy Chief Whip, Mizoram.
6. Sr. PPS to Chief Secretary, Govt. of Mizoram
7. Joint Secretary, Ministry of Panchayati Raj, Govt. of India, 11* Floor, Jeevan
Prakash Building, K.G Marg, New Delhi -110001.
8. All Administrative Heads of Departments, Govt. of Mizoram.
9. All Heads of Departments, Govt. of Mizoram.
jo Director, State Institute of Rural Development & Panchayati Raj.
11. Members concerned.
12. Guard File.
: ce
een YR-ifipe -
n [
- 7 ; ( cat TyeIPunt J
’ é Under Secretary to the Govt. of Mizoram
i , fiuocal Administration Department.
&
eee WEAR MASK, MAINTAIN PHYSICAL DISTANCING OF 6 FEET, OBSERVE HAND HYGIENE. a
