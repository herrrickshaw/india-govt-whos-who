---
doc_id: "4dcfc4665afb9bda"
source_url: "https://dcma.mizoram.gov.in/uploads/attachments/2024/08/9a9043c0d306126e010fdc779b405aca/ladc-publication-board-rules-2010.pdf"
ministry: "District Council Affairs Department, Mizoram"
title: "The LADC (Publication Board) Rules, 2010"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b154962cf9dc5374"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

-3

Ex-78/2010

CHAPTER - II
5.

CONSTITUTION OF THE BOARD:
There shall be a committee body as under:

Vice Chairman

ex-Officio
The Executive Menber i/c Art& Culture Department shall be an
Chairman of the Board.
Members
Mennber of the Board slhallbe elected as Vice Chairman by

Secretary

of the Boad Meeting.
Secretary
The Officer incharge Art &Culture shall directly be appointed to

Chairnan

Term of Ofice
6.

Any

as ex-officio Secretary cum-Treasurer.
The term of ofice of the Committee shall be two (2) years.

FUNCTION OF THE B0ARD:
of the Board if and when
The Chairman shall direct the Secretary to callfor a meeting
(1)

(2)

necessary.
the Chairman,
Quorum of the Board Meeting shall be four (4) Members. In urgent matters,
report such
shall
and
cases
certain
in
decisions
Vice-Chairman and Secretary shall make

decision to the first meeting of the Board.

7.

PLAN & BUDGET OF THE BOARD:
Autonomous District
TheSecretary shall prepare Plan & Budget to be included in the Lai
(1)

(2)
8

District
CouncilAnnual Plan &Budget through Planning Committee of the Lai Autonomous
Council.
from the Budget
Payment of sitting allowances to the members of the Board shall be met

@ Rs. 125/- per day.

SELECTION FOR PRINTING & PUBLICATION OF BOOKS:

The Board have a meeting to select written materials received for printing and publishing in the
following manner/criteria;
Materials selected for printing or publication shall be of treasure for the people of the
(a)
District.

(b)
(c)
(d)
(e)

()
(g)
9.

Preference shall be given to written materials relating to the culture and tradition of the

people of the District.
ofthe District.
Any kind of prose and poetry that can increase the knowledge of the peopleEnglish.
and
Hindi
Mizo;
Lai;
be
The language accepted for the publication shall characteristics of the Lai tribe and can be
Any kind of prose and poetry that can reveal the
read outside the District by other Tribes/Caste. Material written in other Language, i.e.
English and Hindi can also be considered.
Translation of Books from other Language that can benefit the People of the District may
also be selected.

Published Books, which are again neded for re-publication that can benefit the People,

can also be re-published.

EXPERT:

(1)

Written materials which are desired for printing and publishing under the Board, shall be

submitted to the Secretary in double space typing.

(2)

The Board shallappoint experts who shall preview the written materials as per criteria
under Rule 8. The expert shallsubmit his reports to the Board and selection made by the

(3)

The expert shall be paid Honorarium and the Board shall determine the amount.

Board shall be final.

<!-- page 4 -->

-4

Ex-78/2010

CHAPTER- IV
10.

FINANCE

(1)
(2)
(3)

The Board shall finance the writer of the selccted written
incurred for publication into the Book.

inaterials 75% of expenditure

2000 copies.
Book shallbe printed in not less than 250copies and not more than
rates.
the
The Board and the printer of the Books shallnegotiale

11.

MODE OF PRINTING:
shallbear forwarding and
Books that are published or.printed and financed by the Board
(1)
acknowledgment written by the Board.
bear the title verse Financed
Books which are printed under the finance of the Board shall
(2)
Board.
by the Lai Autononmous District Publication
printed.
Payment may be made after submission of one copy of the book
(3)

12.

DISTRBUTION OF BOOKS :

()
(2)
13.

publishcd and financed by
The Board shall fix the selling price for the books, which are
LaiAutonomous District Publication Board.
shall benefit 10% in
The writer of the book shall have 90% of sales-proceedand the Board

cash or kind.

AMENDMENT:

The above rules may be amended from time to time as the Board may think

necessary.

LAIAUTONOMOUS DISTRICTPUBLICATION BOARD
APPLICATION FORM OF GRANT-IN-AID.

1)
2)
3)

S/o

Name
Address

Name of the Book

Number ofpages
Ifyes, year of printing.
4)
S)

Year of writing

Ifalready printed or not

No. ofcopies.

Language in which it is written
Books relating to ?

6)

In what way it will be the benefits to Lairam and its tribe ?

7)

Why Grant-in-aid is asked ?

Signature

Dated

(SI. No. 6&7 may be answered in a separate sheet and
enclosed if space are limited in the Form)

<!-- page 5 -->

<!-- page 6 -->
