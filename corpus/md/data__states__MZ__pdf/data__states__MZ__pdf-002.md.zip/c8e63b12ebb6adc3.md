---
doc_id: "c8e63b12ebb6adc3"
source_url: "https://cdn.s3waas.gov.in/s3185e65bc40581880c4f2c82958de8cfe/uploads/2026/07/17840278373196.pdf"
ministry: "Mamit"
title: "Corrigendum (457 KB)"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "230dd870b6a74540"
---

<!-- page 1 -->

| ~
No. A.12011/36/2026-DC(M)
: OFFICE OF THE DEPUTY COMMISSIONER
MAMIT DISTRICT: MIZORAM
: Mamit, the 22nd June, 2026
CORRIGENDUM

He Office lehkha number A.12011/36/2026-DC(M) hmanga ni 11 June,
2026 a LDC (PE) hna lakna tura Advertisement lo tihchhuah tawh chu a hnuai ami

ang hian siamthat/tihdanglam a ni.

1. Hlawh bi - Rs. 18,700.00+10% DA tih chu, “Hlawh bi - Rs. 16,920.00.” tiin
siamthat/tihdanglam a ni.

2. Thiamna ngaite - Diploma in Computer Application/Certificate in Computer
Application from institutions recognized by Mizoram State Council of Technical
Education (MSCTE) tih chu, “Diploma in Computer Application Semester-I/
Certificate Course on Computer Application or above from institutions

: recognized by All India Council of Technical Education (AICTE), or any
institution recognized by the Central or the State Governments/UT

Administration under the Union of India.” tiin siamthat/tihdanglam a ni.

Sd/- q
(SUVIGYA S. CHANDRA) IAS
Deputy Commissioner
Mamit District, Mizoram
Memo No. A.12011/36/2026-DC(M) y Mamit, the 22nd June, 2026.
Copy to:

1) Sr. PPS to Commissioner & Secretary, GAD for kind information.

2) The Under Secretary to the Govt. of Mizoram, DP&AR (GSW) for kind information.

3) Chairman, Mizoram Public Service Commission for kind information.

4) District Information & Public Relations Officer, Mamit District for information with a
request to have it published in 1(One) State newspaper (Vanglaini) and 1 (One) local
newspaper (Mamit Times) for 2 (Two) consecutive days (bill may be sent to this
Office for payment)/ All India Radio/ Doordarshan/ Departmental websites, etc.

5) Sub-Divisional Officer (C), Kawrthah/ W.Phaileng for kind information with a
request to widely circulate this Corrigendum.

4) District Informatics Officer, NIC, Mamit for uploading this Corrigendum with other 5
related documents in the Office website.

7) District Facilitator, LESDE for kind information and necessary action.

8) Office Notice Board.

‘
o' =
Mamit District, Mizoram
RR a LT EE TE TT STO ELL ELE LTE LE LO EL LT CTE LOTTE TT La OL ETT TET, .
Telephone No. : 0389-2565220 website: https://mamit.nic e-mail: demamit1998@gmail.com
Mobile No. _: 84148 33798 Pin.: 796441 , de.mamit-mz@nic.in
