---
doc_id: "17f568f0cedadd7b"
source_url: "https://cdn.s3waas.gov.in/s35e9f92a01c986bafcabbafd145520b13/uploads/2026/06/17827365056433.pdf"
ministry: "Champhai"
title: "TENDER APP NIT CPI"
date: ""
pages: 6
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "d6c265f4efb81082"
---

<!-- page 1 -->

No.B. 52011/2/2025-DC(CPI)
OFFICE OF THE DEPUTY COMMISSIONER
CHAMPHAI, CHAMPHAI DISTRICT
Dated Champhai the 23'4 June,2026
NOTICE INVITING TENDER
The Office of the Deputy Commissioner, Champhai District, Mizoram, invites bids
from eligible IT firms/bidders/developers for the development of a mobile application
to serve as a "Grievance Redressal Application" for Champhai district under the
Mizoram District Transformation Programme, with the following deadlines.
Deadline in respect of NIT
e Starting date of Tender: - 25t* June, 2026 10:00 AM
© Closing date of Tender. :- 9'" July, 2026 2:00 PM
Bidders/developers are advised to refer the terms and conditions explained at
Annexure-A, Technical Specification mentioned at Annexure-B and Proposed Content of
Mobile Application mentioned in Annexure-C, along with tender documents for
submission of quotations/bids against this NIT within the time period mentioned above.
For further details, The Tender documents may be downloaded from district
website https://champhai-nic.in// or may be collected from ' the Office of the Deputy
Commissioner, Champhai District, Mizoram, from 25th June, 2026 10:00 AM onward.
Bid/Quotation shall be submitted in sealed envelope to the Deputy
Commissioner's Office, Champhai District, latest by 9t July, 2026, 2:00 PM. Any
Bid/Quotation submitted after the expiry of above-mentioned last date shall not be
accepted.
Enclosed: -
Annexure-A (Terms and Conditions)
Annexure- B (Mobile App Technical Specifications)
(MOHAMMAJ AAQUIB) IAS,
ypepuy Commissioner
Champhai District.
Memo No.B. 52011/2/2025-DC(CPI) Dated Champhai, the 23"4 June, 2026.
Copy to:
DIO, for info and uploading on website
: dda
,/Champhai District.
(@ 3 Scanned with OKEN Scanner

<!-- page 2 -->

(ANNEXURE-A)
TERMS &CONDITIONS
With reference to the Notice Inviting Tender NO. B. 52011/2/2025-DC(CPI) dt. 234
June, 2026 issued by this office, following terms and conditions shall be applicable: -
1) Bidders/developers are invited for submission of bids/quotations against each
item ina sealed envelope with clear mention of details of bidder.

2) Bid from eligible bidders should be complete in all respect

3) Bids complete in all respects should reach to the Office of the Deputy
Commissioner,

Champhai, on or before gth July, 2026. Late bids because of any reason
whatsoever shall not be accepted in any case.

4) Prices shall be quoted component wise. Escalation of price(s) on any
component(s) will not be entertained under any circumstances after submission
of bid.

5) This office reserves all rights to make any changes in terms and conditions of the
tender and also reject any or all bids without assigning any reason thereof.

6) Training for the successful running and maintenance of MOBILE APP shall be the
responsibility of the developer/vendor concerned.

7) The work order will be issued in favour of the qualified bidder and payment shall
be released in phased manner as per availability of fund.
Mle LL, Ad
(M' QUIB) IAS,
Deputy Conimissioner
Champhai District.
Dated Champhai, the 234 June, 2026.
CG scanned with OKEN Scanner

<!-- page 3 -->

(ANNEXURE-B)
TECHNICAL REQUIREMENTS FOR MOBILE APPLICATION
Sl.
No PROJECT REQUIREMENTS
COMPONENT
* — Clean, intuitive, and responsive design for APP
1. MOBILE APP * Develop native applications (Android &iOS) with core
DESIGN AND * — functionalities of the website
DEVELOPMENT * Performance optimization for various screen sizes and
* — devices and smooth interaction on smaller screens
* Provide seamless integration with various government
* mobile services
* Responsive, user-friendly UI/UX designs
* Design patterns to organize code for maintainability,
* Payment Gateways integration
* Social Media Integration
* Image Optimization
* Multithreading Continuous Integration/Delivery
* Design patterns to organize code for maintainability.
* User Interface (UI) and User Experience (UX)
2. TECHNICAL + Authentication and Authorization
FEATURE * Push Notifications
* Offline Functionality
* Geolocation and Mapping
* Data Storage and Cloud Integration
* Ability to sync data across multiple devices Analytics
*  Multi-platform Support
* Platform Compatibility with native apps
* Running multiple services or tasks in the background
* Integrating analytics to track app usage
* Integration with Google Services
* Prompts for accessing phone features
* Operating System Compatibility
3. TECHNICAL * Multiple Device Compatibility
COMPATIBILITY * Design patterns to organize code for maintainability,
* Hardware Compatibility, Sensors and Devices
* Cross-Platform Compatibility, App Caching
* Network Compatibility; Wi-Fi, Cellular/Offline Capabilities
+ API and Backend Compatibility
* Third-Party Integration Compatibility
* Compliance with Platform Guidelines
* Social Media Integration
* + Cloud and Device Storage Compatibility
* App Architecture and Compatibility with Future -Updates
* API Security - Oauth 2.0 / OpenID Connect. 1
SECURITY AND * Logging & Monitoring:
CERTIFICATION > Audit Log.
> Security Event Monitoring.
> Incident Response Procedures.
* DPDP Act, 2023 (Digital Personal Data Protection Act, 2023).
* AES-256 for sensitive data encryption
(@ 3 Scanned with OKEN Scanner

<!-- page 4 -->

* SSL/TLS Data projection encryption to protect user data and
prevent
* unauthorized access. :
* Compliance with ISO/IEC 27001 (Information Security
* Management System).
* Integrate multi-factor authentication (MIA) for
* enhanced login security.
* Conduct regular security audits and implement
* — intrusion detection systems (IDS/IPS).
* Protect against SQL injection, cross-site scripting
*  (XSS), and other OWASP vulnerabilities
* Compliance with GDPR and government data
* protection laws.
* Unit Testing and UI Testing
+ Extensive testing for functionality/Security certificate
* verification
* Automated Testing/Efficient Resource Usage
* Software and Plugin Updates
SUPPORT AND * Bug Fixes and Error Handling
MAINTENANCE * Performance Monitoring and Optimization
FOR 10YEARS * SSL Certificate Renewal
* Security and Privacy Updates
* App Store Optimization (ASO)
* Firewall Protection
* Test Updates on Staging Site
* Version Control and Release Management
* Legal and Compliance Updates
* Progressive Web App (PWA) Maintenance
* Cloud Infrastructure and Backend Maintenance
* User Retention and Lifecycle Management
* Hands on training
TRAINING * Administrative and Staff Training
AND * User Training (Citizens and General Users)
CAPACITY * Technical Team Training (Developers and IT Support)
* Stakeholder Awareness and Capacity Building
¢ Regular guidance for and skill upgradation
* Training on new features and integration.
M4 ray
.
(MOHA QUIB) IAS,
Deputy Comniissioner
Champhai District.
Dated Champhai, the 23 June, 2026.
CG scanned with OKEN Scanner

<!-- page 5 -->

(ANNEXURE-C)
PROPOSED CONTENT OF MOBILE APPLICATION
1. Grievance Section
Proposed Service Concerned Department
no
; fuera
Burning of Waste/ Irregular Disposal of Waste UD&PA
2
Unauthorised Connection of Pipeline, Water Leakage,
Water Quality, Pipe Dislocation etc
3.
| Electric Connection & Line Issued
4.
| Food & Civil Supplies Department, Consumer Related DCSO
Gas, PoL, Ration etc
5.
Traffic Related Complaints ( No Helmet, Underage SP Office (Traffic Cell)
Driving, Violation of No Parking Zone, No Entry, One-
way, Obstruction of Roads etc
S| Violation / Non-compliance of Orders issued by the DC Office
District Magistrate
7.
[7 | All Disaster Related Cases DC Office (Disaster Branch
[| Sabotage of Public Properties SP Office
Problem Created by Animals (incl. Man-Wildlife Conflict) | EF&CC, All Agri & Allied
Departments
11.
Infection/ algae infection/ agri & allied related diseases Department of Agriculture/
Horticulture/ Fisheries/
Sericulture
12;
Others. (Description Box to be provided) All Departments. Complaints
shall first be examined by the
DC Office and then forwarded
to the concerned department.
CG scanned with OKEN Scanner

<!-- page 6 -->

2. Information Section

a) Department Information: To provide details of all departments and offices within
Champhai District, including office address, contact details, office timings,

jurisdiction, and list of officers/staff, including nodal officers for grievance redressal.

b) Citizen Services Information: To provide department-wise information on services
available to citizens, required documents, application procedures, fees/charges, and
timelines for disposal.

c) Schemes & Welfare Information: To provide simple write-ups, eligibility details,
and step-by-step guidance on government schemes, welfare programmes, and citizen
entitlements relevant to the public.

d) Guidance & Awareness Material: To include FAQs, instructional write-ups, and
video links explaining grievance filing, public services, schemes, and other citizen
welfare-related matters in an easy-to-understand manner.

e) Public Notices & Alerts: To provide important public notices, District Magistrate
orders, advisories, and other district-level announcements for public information.

f) Emergency & Utility Contacts: To include emergency contact numbers and
essential public service contacts such as police, hospital, fire services, disaster
management, electricity, water supply, and other key departments.

g) Forms & Downloads: To provide downloadable forms, checklists, templates, and
other documents required for availing departmental services or submitting
applications/complaints.

3. Other Services Section:

a) Push Notifications: To provide push notification facility for district-wide
announcements as well as department-specific updates, advisories, alerts, and public
information.

b) Call Booking Facility: To provide an option for citizens to book a call with
concerned offices/departments, particularly Agriculture and allied sectors, for
guidance, consultation, or grievance-related follow-up.

(MOHAMMAD 3, IAS,
Deputy Comnilissioner
Champhai District.
(@ 3 Scanned with OKEN Scanner
