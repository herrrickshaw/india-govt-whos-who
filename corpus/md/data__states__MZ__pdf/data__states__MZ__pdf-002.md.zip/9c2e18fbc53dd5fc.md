---
doc_id: "9c2e18fbc53dd5fc"
source_url: "https://ahvety.mizoram.gov.in/uploads/attachments/2023/05/c21c581b96d95eb3a9cd3b8ff4cd11d5/open-tender-bss-hnahthial.pdf"
ministry: "Animal Husbandry and Veterinary Department, Mizoram"
title: "Open Tender BSS Hnahthial"
date: ""
pages: 21
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f370447e8bdd4223"
---

<!-- page 1 -->

Tender No. 4/2023-24/AH&V

NOTICE INVITING
OPEN TENDER (TURNKEY) FOR
ESTABLISHMENT
OF
BOAR SEMEN STATION
at
Hnahthial, Hnahthial District

A. Design and construction of boar pen, biosecurity changing
room cum bathroom, feed godown, semen collection room,
laboratory, biosecurity fencing etc.
B. Supply, installation and commissioning of laboratory, scienti c
machinery and equipments, consumable items etc.

Department of Animal Husbandry & Veterinary
Government of Mizoram

fi

Page 1 of 21

<!-- page 2 -->

TABLE OF CONTENT
Sl. No.

Title

Page No.

A

LETTER OF INVITATION

3

B

INSTRUCTION TO BIDDERS

4-5

C

TERMS OF REFERENCE

6-8

1 Aims and Objectives

6

2 Eligibility & Pre-Quali cation Criteria

7

3 Tender Amount

7

4 Web-page of Tender

7

5 Project Location

7

6 Publication of Tender

7

3 Scope of Works

8

4 Schedule for Completion of Works

8

5 Support or Inputs to be provided to the Bidders by the
Department

8

6 Final Output Required of the Contractor

8

D

BID EVALUATION CRITERIA

9 - 12

1 Opening and Evaluation of Technical Bids

9

2 Opening and Evaluation of Financial Bids

9 - 10

3 Selection

10

4 Bid Currency

11

5 Bid Security

11

6 Forfeiture of BID Security

11 - 12

7 Award of Contract

12

8 Termination of Contract

12

9 Force Majeure

12

Table 1

Technical Evaluation Criteria

13

Form A

Quali cation Information

Form B

Form of Technical Bid

17

Form C

Form of Financial Bid

18

Form E

A davit

19

Annexure - I

Design & Construction of Civil Works, Furnitures & Fixtures

20

Annexure - II

Supply, installation and commissioning of laboratory,
scienti c machinery and equipments, consumable items etc.

21

14 - 16

fi

fi

fi

ffi

Page 2 of 21

<!-- page 3 -->

C. LETTER OF INVITATION
The Director, Animal Husbandry & Veterinary Department, Mizoram, Aizawl on behalf of the Governor of Mizoram
invites OPEN TENDER (TURNKEY) [Tender No.1/2023-24/AH&V] in a two bid system [Technical bid & Financial bid in two
separate sealed envelopes kept together in one large sealed envelope] for the project en tled “Establishment of Boar Semen
Sta on at Hnahthial, Hnahthial District” on turnkey basis.
The Tender documents containing the details of informa on to bidders, terms of reference, bid evalua on criteria,
formats for technical and nancial proposals etc will be available for purchase on Dt. 23rd May, 2023 (Tuesday) from Planning &
Monitoring Sec on, Directorate of AH&Vety Department, Khatla, Aizawl during O ce working hours. The Cost of Tender
No.1/2023-24/AH&V document is Rs. 1,500/Bid documents maybe submi ed to sealed tender box at the o ce chamber of the Director, Animal Husbandry &
Veterinary, Khatla, Aizawl by Dt.26th June, 2023 (Monday), 12:00 noon in sealed envelope in prescribed format containing
earnest money (refundable) i.e., 2% of the es mated cost in a technical bid envelope only by way of Demand Dra /Bankers
Cheque in favour of Director, Animal Husbandry & Veterinary Department, Govt. of Mizoram, payable at Aizawl. All the cri cal
dates are men oned below. Queries if any, may be referred in wri ng to the below men oned address or telephone number
9436151944 or Email: drdingtea@gmail.com.
You are also informed to a end the Pre-bid Conference on 30th May, 2023 (Tuesday) at 11:00 AM in the Directorate
Conference Hall, Directorate of Animal Husbandry &Veterinary Department, Khatla, Aizawl without fail.

Critical Dates
Tender publishing date

23.5.2023

Pre-bid conference date

30.5.2023

Last date of Bid submission

26.6.2023

Technical Bid opening date

26.6.2023

Financial Bid opening date

28.6.2023

(Dr. LALRINPUII SAILO)
Director
Animal Husbandry & Veterinary Department
Government of Mizoram

ti

ft

ti

ti

ti

ffi

ti

ffi

ti

ti

tt

tt

fi

ti

ti

ti

Page 3 of 21

<!-- page 4 -->

B. INSTRUCTION TO BIDDERS
1. Abbreviation used in this documents are:
• AHVD = Animal Husbandry & Veterinary Department
• EMD = Earnest Money Deposit

2. Bidders are advised to study this Tender document carefully before
participating. It shall be deemed that submission of bid by the Bidder
has been done after their careful study and examination of the Tender
documents with full understanding to its implications. Any lack of
information shall not in any way relieve the bidders of his responsibility
to fulfil his obligations under the Bid.
3. Bidder shall bear all costs associated with the preparation and
submission of the Bid including surveys (if required), and AHVD will
in no case be responsible or liable for those costs, regardless of the
conduct or outcome of the bidding process.
4. Bidder is expected to examine all instructions, forms, terms,
specifications, and other information in the Tender document. Failure to
furnish all information required by the Tender document or to submit a
Bid not substantially responsive to the Tender document in every
respect will be at Bidder’s risk and may result in the rejection of its Bid.
5. The bid prepared by the bidder, as well as all correspondence and
documents relating to the Bid exchanged between the bidder and the
AHVD, shall be in English. Supporting documents and printed
literature furnished by the bidder may be in another language provided
they are accompanied by an accurate translation by AHVD certified /
approved translator of the relevant pages in English. For the purposes of
interpretation of the bid, the translation shall govern. Information
supplied in another language without proper translation shall be
rejected.
6. The bidder should submit a design, drawing and estimate of a the civil
works involved along with their technical bid.
7. The bidders should submit bid documents in a sealed tender box kept at
the office chamber of Director, Animal Husbandry & Veterinary,
Khatla, Mizoram.
Page 4 of 21

<!-- page 5 -->

8. The Technical Bid Envelope shall be superscripted as “Establishment of
Boar Semen Station at Hnahthial, Hnahthial District – Technical Bid”
Envelope No. 1 along with Name and Address of the bidder at the bottom
right corner. Failure to do so shall be subjected to rejection of the bid.

9. The Technical Bid should be accompanied by Bid security/gzEMD i.e.,
2% of the estimated value only by way of Demand Draft/Bankers
Cheque in favour of Director, Animal Husbandry & Veterinary
Department, Govt. of Mizoram, payable at Aizawl.
10. The financial bid envelope i.e., Envelope No. 2 which shall be
superscripted as “Establishment of Boar Semen Station at
Hnahthial, Hnahthial District – Financial Bid” along with Name and
Address of the bidder at the bottom right corner. Failure to do so shall
be subjected to rejection of the bid.
11. At any time prior to the deadline (or as extended by AHVD) for
submission of bids, AHVD, for any reason, whether at its own initiative
or in response to clarifications requested by prospective bidder may
modify the Tender document by issuing amendment(s).
12. All bidders will be notified of the amendment(s) by publishing on the
websites, and these will be binding on them.
13. In order to allow bidders a reasonable time to take the amendment(s)
into account in preparing their bids, AHVD, at its discretion, may
extend the deadline for the submission of bids.
14. The bid shall remain valid for 180 days from the date of Technical Bid
Opening being specified. Bidder should ensure that in all
circumstances, its Bid fulfils the validity condition. Any bid valid for a
shorter period shall be rejected as non-responsive.
15. In exceptional circumstances, AHVD may solicit bidder’s consent to an
extension of the period of validity. The request and the responses
thereto shall be made in writing or by Fax. Bid Security shall also be
suitably extended. A bidder granting the request is neither required nor
permitted to modify the bid.
16. Late bids i.e. bids received after the specified date and time of receipt
should not be considered.

Page 5 of 21

<!-- page 6 -->

C. TERMS OF REFERENCE
In most of the villages of Mizoram and surrounding areas, there are one or two
Breeding boars which services the entire sow population of the area. As a result of this the
same boar is often used to service their own off-springs resulting in inbreeding. The
inbreeding effects like atresia-ani, stunted growth, genital defects are often seen in villages
where there is a single breeding boar which are often kept for 5-6 years. To induce hybrid
vigor and to prevent the unwanted traits of inbreeding, Artificial insemination should be
introduced where high genetic germplasm can be introduced in the pig population of the
area.
Mizoram is having a well established Regional Boar Semen Collection Centre and
Satellite Boar Semen Collection Stations in various districts. Artificial insemination of pigs
have been practiced successfully in the areas where these stations can cover. However, since
the Boar semen cannot be stored for longer period of time as Frozen semen technology is
not yet successful like ruminants, Satellite Boar semen station is proposed to be established
in some remote Blocks of the state so that high performing germplasm can be introduced in
pig population of remote areas of the state which will in the mean time reduce the chances
of inbreeding and the spread of sexually transmissible diseases.
For this purpose the Large White Yorkshire is a breed of choice which has been
proven for its adaptability and high performance in Mizoram.

1. Aims & Objectives:
(i) Increase of per animal productivity through propagation of high
genetic merit male germplasm (boar semen) through artificial
insemination.
(ii) Reduction of inbreeding
(iii)Reduction of ingress of sexually transmitted diseases

Page 6 of 21

<!-- page 7 -->

2. Eligibility & Pre-Qualification Criteria
(i) The bidder may be an individual/firm/society/proprietor/supplier/
contractor etc. of Indian citizen/having office within India.
(ii) The bidder should have GST Registration, PAN Card, Voter’s ID/
AADHAR Card. In case of company/firm a Registration certificate is
required.
(iii) The bidder having past experience of undertaking the similar works
may be preferred.
(iv) The applicant should not have incurred loss in any of the last three
financial years
(v) The bidder should not have been blacklisted by any Central / State
Government PSU or any other Govt. bodies.

3. Tender Amount: Rs. 95.63 Lakh (Rupees Ninety Five Lakh Sixty
Three Thousand) only

4. Web-page of Tender : www.ahvety.mizoram.gov.in

5. Project Location : Hnahthial, Hnahthial District

6. Publication of Tender : Through Information & Public Relation
Department, Govt. of Mizoram, www.ahvety.mizoram.gov.in and
Notice Board of Directorate, AH&Vety.

Page 7 of 21

<!-- page 8 -->

7. Scope of Works (Refer Annexure I & II):
(i)

Design and construction of boar pen, biosecurity changing room cum
bathroom, feed godown, semen collection room, laboratory,
biosecurity fencing etc.

(ii) Supply, installation and commissioning of laboratory, scientific
machinery and equipments, consumable items etc.

8. Schedule for Completion of works:
(i)

The Contractor will start the works within 15 Days from the date of
signing an agreement, failing which the contract is liable to be
cancelled by the Employer.

(ii) The works should be completed in 6 Months from the date of
signing the Agreement. In exceptional circumstances, the time
period stated in this clause may be extended in written by mutual
consent of both the Employer and the Contractor.
(iii) If any damage shall happen to the work while in progress from any
cause or if any defect shrinkage or other faults appear in the work
within 3 months after completion, the contractor shall make the
same good at his own expense or forfeit the Performance Security
deposit of 5% deducted at the time of billing. The Performance
Security deposited will be released after 90 days after payment of
bill.
(iv) No Subletting of work shall be permitted without prior information
to the Authorities.

9. Final outputs required of the contractor:
(i)

The project activities and the expenditure thereon will be at the
responsibility of the contractor. The contractor will arrange and pay
for machineries, equipment, manpower, slips, etc. and submit
periodical reports on Plan of action to the Department.

(ii) The contractor should enclose a certificate of group insurance
scheme or equivalent to a minimum of ten (10) employees
(labourers) within 15 days after issue of work orders without fail.

Page 8 of 21

<!-- page 9 -->

D. BID EVALUATION CRITERIA
The Departmental Bid Evaluation Committee will open and evaluate the Technical bid and
the Financial Bid at the place and time mentioned at important information sheet. During
the Bid opening, the interested bidders (one representative) are allowed to participate.
1. Opening and Evaluation of Technical Bids
The Bid Evaluation Committee would evaluate the technical bids.
BIDDERs should be ready to reply to all the queries raised by the
technical evaluation committee. The primary function of clarifications
in the evaluation process is to clarify ambiguities and uncertainties
arising out of the evaluation of the bid documents. To facilitate the
Technical Bid evaluation, the technical criteria laid down along with
the assigned weights have been presented in Table 1.
Bidders securing a minimum of 50% marks in the technical evaluation
will only be considered for further financial bid evaluation. Bids which
don’t secure the minimum specified technical score will be considered
technically non-responsive and hence debarred from being considered
from financial evaluation. Scores of technically qualified Bidders
shall be weighed on a scale of 80% and shall be carried forward for
evaluation together with the scores of financial evaluation which shall
be weighing 20%.

2. Opening and Evaluation of Financial Bids
The Financial Bids of technically qualified bidders (i.e. above 50
marks) will be opened on the prescribed date in the presence of bidder
representatives.
The financial scores will be calculated as
Fn = Fmin / Fb * 100
where,
Fn = Normalized financial score of the bidder under consideration
Fb = Evaluated cost for the bidder under consideration
Fmin = Minimum evaluated cost by any bidder
Page 9 of 21

<!-- page 10 -->

• The bid price should not be lower than 5% of the Departmental
reserved price (Table 2).
• Any conditional bid would be rejected.
• Errors & Rectification: Arithmetical errors will be rectified on the
following basis: “If there is a discrepancy between the unit price
and the total price that is obtained by multiplying the unit price and
quantity, the unit price shall prevail and the total price shall be
corrected. If there is a discrepancy between words and figures, the
amount in words will prevail”.
• If there is no price quoted for certain material or service, the bid
shall be declared as disqualified.
• In the event that there are 2 or more bidders having the same value
in the financial bid, the bidder securing the highest technical score
will be adjudicated as the “Best responsive bid” for award of the
contract.

3. Selection
Quality and Cost Based Selection (QCBS) will be used for final
evaluation of the overall score as follows:Bn=0.80 * Tn + 0.20 * Fn
where,
Bn = Overall score of bidder under consideration
Tn = Technical score for the bidder under consideration
Fn = Normalized financial score of the bidder under consideration

AHVD reserves the right to negotiate with the Bidder whose proposal
has been ranked first on the basis of best value.

Page 10 of 21

<!-- page 11 -->

4. Bid Currency
Prices for services offered shall be quoted in Indian National Rupees (INR)
only.
5. Bid Security
1. All BIDDER’s shall deposit, as part of its Bid, an Earnest Money
amounting as mentioned earlier (refer to page 5).
2. The Bid Security shall be in Indian Rupees and shall be in the
form of Demand Draft/Bankers Cheque in favour of Director,
Animal Husbandry & Veterinary Department, Govt. of Mizoram,
payable at Aizawl, and shall be valid for at least 180 days.
3. Unsuccessful bidder’s Bid security will be discharged or returned
within sixty (60) days after the expiration of the period of Bid validity
prescribed.

6. Forfeiture of BID Security
The Bid security may be forfeited either in full or in part, at the discretion
of AHVD, on account of one or more of the following reasons:
1. If the bidder withdraws his Bid during the period of Bid validity
specified by him on theBid Letter Form;
2. If the bidder fails to co-operate in the Bid evaluation process
3. If the bid or its submission is not in conformity with the instruction
mentioned herein
4. If the bidder violates any of the provisions of the terms and conditions of
the tender
5. In case, a successful bidder fails to (a) accept award of work, (b)
sign the ContractAgreement with AHVD, within the stipulated time
after acceptance of communication on placement of award, (c)
furnish performance security, (d) fails to sign the Contract
Agreement in time, (e) or the bidder violates any of such important
conditions of this tender document or indulges in any such
Page 11 of 21

<!-- page 12 -->

activities as would jeopardize the interest of AHVD in timely
finalization of this tender. The decision of AHVD regarding
forfeiture of bid security shall be final and shall not be called upon
question under any circumstances. A default of such type or nature
may involve black-listing of the bidder by AHVD/Govt. of
Mizoram.

7. Award of Contract:
Based on the Evaluation, The Departmental Purchase Advisory Board
will select the successful bidder. Then, the AHVD will award the
contract to successful BIDDER whose bid has been determined to be
responsive and has been determined to be most competitive and thus
selected.

8. Termination of Contract:
Upon finding the performance of the contractor unsatisfactory, the
AHVD shall have the right to terminate the work order and the
contract agreement at any point of time.
9. Force Majeure
Any circumstances beyond the control of the selected firms/ agency/
partner or Government Department as the case may be which cannot
be foreseen and which substantially affect the performance shall be
dealt with conducive atmosphere.
Any legal dispute litigation arising out of the terms, the Court of Law
at Aizawl shall have the Jurisdiction to adjucate the same.

Page 12 of 21

<!-- page 13 -->

Table 1. Technical Evaluation Criteria
Sl
No

Criteria

Requirements

Max
Mark

COMPANY PROFILE and EXPERIENCE
1

Year of Experience should not be less
than 5 years

≥ 5 years = 5 marks
<5 years = 0 mark

5

2

Number of experience in works of
similar nature of work performed as
prime contractor. Work performed in
the past as a nominated sub-contractor
will also be considered provided the
Sub-Contract involved execution of all
main items described in the Bid
Document.

≥ 4 works done = 40
3 works done = 30
2 works done = 20
1 work done = 10

40

3

Design, drawing and estimate of a the
civil works

Excellent = 25
Very good = 20
Good = 10
Fair = 5

25

4

Schedule of work plan

Yes = 10
No = 0

10

5

The Bidder should have average
annual turnover of not less than INR
50 Lakhs during three financial years
( F. Y. 2 0 1 9 - 2 0 , 2 0 2 0 - 2 1 a n d
2021-2022) respectively.

Yes = 10
No = 0

10

6

Avg. Net Proft figure for last three years

50 lakh and above = 10 marks
≥35 lakh and <50 lakh = 8 marks
≥20 lakh and <35 lakh= 5 marks.

10

TOTAL MARKS =

100

Page 13 of 21

<!-- page 14 -->

Form-A QUALIFICATION INFORMATION
(See Rule 37(1)(c))
This Section contains all the criteria that the Employer shall use to evaluate Bids and qualify
Bidders.
The information to be lled in by the Bidder in the following pages will be used for purposes of
Quali cation. This information will not be incorporated in the contract.
1. Quali cation Information of the Bidder:
d)
Constitution or Legal status of Bidder
e) Place of Registration
f)
Principal place of business

: [Attach copy]
:
:

1.2 Total value of Works performed in the last five year (immediately preceding the financial
year in which bids are received):
Year

Description of work

20

to 20__

20

to 20__

20

to 20__

20

to 20__

20

to 20__

Nodal Officer

Value (Rs. in lakh)

1.3 Experience in works of similar nature of Work performed as prime contractor:, work
performed in the past as a nominated sub-contractor will also be considered provided the SubContract involved execution of all main items of work described in the Bid Document, provided
further that all other quali cation criteria are satis ed (in the same name) on works of similar
nature over the last ve years (immediately preceding the nancial year in which Bids are
received).
Project Name of
name
Employer*

Description of Contract Value of
No
work
Contract

Date of issue Stipulated
of work order period of
completion

(Rs in
Lakh)

Actual date of
completion*

Remarks
explaining
reasons for
delay & work
completed

* Attach certi cates from the Engineer-in-Charge

fi

fi

fi

fi

fi

fi

fi

fi

Page 14 of 21

<!-- page 15 -->

1.4. Financial reports for the last ve years: balance sheets, pro t and loss statements,
auditors Reports, etc. List them below and attach copies
Financial
Information

Historical information for the last 5 years from to
Yrl

Yr2

Yr3

Yr4

Yr5

Avg

Avg.ratio

Information from Balance sheet
Total assets
Total liabilities
Net worth
Current asset
Current liabilities
Information from income statement
Total revenue
Profit before taxes

1.5
Name, address and telephone, telex and fax numbers of the Bidders’ bankers who may
references if contacted by the Employer.
SI. No

Address

Contact Phones/
Telex/fax

Remarks

Information on litigation history in which the Bidder is involved
Employer

Cause of dispute

Amount
involved

Remarks (present
status)

Page 15 of 21

fi

Other Parties

fi

1.6

Name of Bank

<!-- page 16 -->

1.7

Statement of compliance to be undertaken.

(Name of Consultant engaged for Project preparation is

)

I, the undersigned, do hereby certify and declare that our Firm,
or any of our employees is neither associated, nor has been associated, directly or indirectly, with
the Consultant or any other entity that has prepared the design, speci cations, and other
documents for the Project or being proposed al Project Manager for the Contract.
(Signature of authorised Signatory of the Firm)

_ Name of the signatory _

Title of the signatory

Date

1.8
Proposed work method and schedule. The Bidder should attach descriptions, drawings
and charts as necessary to comply with the requirements of Bidding Documents.
i.
Site Organisation
ii.

Method Statement

iii. Mobilisation Schedule
iv.

Construction Schedule

v.

Contractor’s Equipment

vi.

Personnel

vii. Others

fi

Page 16 of 21

<!-- page 17 -->

Form-B
FORM OF TECHNICAL BID
Name of Work:

_

Bid No:

To
[Employer]
[Address]
We, the undersigned, declare that:
1.

We have examined and have no reservations to the Bidding Document, including
Addenda.

2.

We offer to execute the Works described above and remedy any defects therein in
conformity with the Conditions of Contract including Special Conditions,
Speci cations, Drawings, Bill of Quantities.

3.

We undertake, if our Bid is accepted, to commence the work as stipulated in this
Contract, and to complete the whole work comprised in the Contract within the time
stated in the Contract Document.

4.

We agree to abide by this Bid for the period of days from the date xed for
receiving the same, and it shall remain binding upon us and may be accepted at any
time before the expiration of that period;
We undertake that unless and until a formal Agreement is prepared and executed,
this Bid, together with your written noti cation of Letter of Acceptance shall
constitute a binding contract between us.

5.

6.

We understand that you are not bound to accept the lowest or any tender you may
receive.

7.

I/We do hereby submit our Technical Bid, complete with all the required information
as stipulated in your Bidding Documents.

Signature of authorized signatory....................................
Name.......... .............. . .........................................
Title .................................................
Date ..................................................

fi

fi

fi

Page 17 of 21

<!-- page 18 -->

Form-C
FORM OF FINANCIAL BID
Name of Work:
Bid No:
To
[Employer]
[Address]
Sir,
We, the undersigned, declare that:
1. We have examined and have no reservations to the Bidding Document
including Addenda.
2. We offer to execute the Works described above and remedy any defects therein
in conformity with the Conditions of Contract including Additional Conditions
and Special Conditions, Speci cations, Drawings, Bill of Quantities
accompanying this Bid for a sum of Rs. ___ (Rupees
) only.
3. We undertake to abide by the Final Sum coming out of the correction of
arithmetical errors as indicated in the General Conditions of Contract.
4. We also undertake, if our Bid is accepted, to commence the work within the
period as indicated in the Contract Document and to complete the whole work
comprised in the Contract within the time stated in the Contract Document.
5. We agree to abide by this Bid for the period of
days from the date xed
for receiving the same, and it shall remain binding upon us and may be
accepted at any time before the expiration of that period;
6. We undertake that unless and until a formal Agreement is prepared and
executed, this Bid, together with your written noti cation of Letter of
Acceptance shall constitute a binding contract between us.
7. We understand that you are not bound to accept the lowest or any tender you
may receive.
8. I/We do hereby submit our Financial Bid, complete with all the required
information as stipulated in your Bidding Documents.
Signature of authorized signatory...........................................
Name..........................................................................
Title..................................................................
Date……………………………………………….

fi

fi

fi

Page 18 of 21

<!-- page 19 -->

Form – E
AFFIDAVIT

1. I, the undersigned, do hereby certify that all the statements made in the
required attachments are true and correct.
2. The undersigned also hereby certify that neither our
rm M/
S
_has abandoned any works in India nor any contract
awarded to us have been rescinded during the last ve years prior to the date of
this Bid.
3. The undersigned hereby authorize and request any Bank, person, rm or
corporation to furnish pertinent information deemed necessary and required by
the Department to verify this statement or regarding my (our) competence and
general reputation.
4. The undersigned understand and agree that further information may be
requested and agrees to furnish any such information at the request of the
Department

(Signature of Authorised Signatory of the Firm)
Name of the signatory

.

Title of the signatory

.

Date

.

fi

fi

fi

Page 19 of 21

<!-- page 20 -->

Annexure-I

Design & Build of Civil Construction, Furnitures & Fixtures
Sl.
No.

Particulars

1

Construction of boar pen @80 sqft/boar

2

Construction of Laboratory

Total Unit
4

a) Semen collection room @100sqft area

1

b) Construction of semen processing laboratory @225 sqft area (15’x15’)

1

c) Furnitures and Shelves

1

3

Construction of Biosecurity changing room cum Bathroom @80 sqft (10’x8’)

1

4

Construction of Feed godown @144 sqft (12’x12’)

1

5

Biosecurity fencing

1

Page 20 of 21

<!-- page 21 -->

Annexure-II

Supply, installation and commissioning of laboratory, scienti c machinery and
equipments, consumable items etc.
Sl. No.

Particulars

Total Unit

1

Semen Collection
(Semen Collection dummy boars) : 11” Height adjustable dummy with gas pressure spring
for easy adjustment of height. Heavy steel body coated with robust and removable PUR
plastic cover to provide hygienic surface.

1 pc each

2

Anti Skid Rubber Mat for dummy boars

1 pcs each

3

Thermos Flask for Boar Semen Collection White / Semen collection cup, insulated. volume:
1 litre Wide opening, for manual semen collection.

5 pcs each

4

Semen collection glove, size L, non-spermicidal, latex, powder free. (1 x50)

10 pkt each

5

Hygienic pre-collection glove.(1 x 100 )

10 pkt each

6

Phase contrast microscope MBL./ VISION 2000- microscope for semen analysis with
objectives 10x, 40x, 100x,heating system with temperature control unit HT 50 with digital
temperature display for individual temperature adjustment

7

Microscope slide, 76 X 26 mm ( 1 x 50 )

10 pkt each

8

Cover glass, 18 X 18 mm (1 x 100)

10 pc each

9

ACUACELL / ACCUREAD PORCINE PHOTOMETER (SDM 1)
Calibrated for Porcine and for measuring sperm concentration. Adapter and
between 100 – 240 V.

10

Micro cuvette for Photometer SDM 1

500 pc each

11

Tube magazine: stainless steel for 6 boar semen tubes, 95ml

1 pc each

12

Mixing and dispensing bath for boar semen 3.5litre

5 pc each

13

3-Tube manual sealer

1 pc each

14

BTS QSF (100ml for 1 LITER )1 liter with Gentamicin (100ml for 1 Liter)

50 pc each

15

EU Cocktail QSF for Swine Media ( 1 liter) Medium and standard term extenders: M III
with antioxidant and antibiotic

50 pc each

16

Quick Tip Flexi tube or equivalent for Boar semen, transparent, 95 ml

2000 pc each

17
18

batteries

Cool and Warm box for boar semen, 30 L, 12 V,portable, temperature: +17 C
Capacity : 85 tubes or bottles
Converter 12 V/AC 100-240 V, For thaw units, portable incubators, portable semen storage
units and warming plates

1 set

1 pc each

2 pc each
2 pc each

19

Boar Scent: Pheromone Spray for Sows, 35 ml approx

10 pc each

20

Heating cabinet, ( Incubator) +37°C. 230 V: Heating cabinet with preset temperature 37°C,

1 Unit each

21

Double Distilling Apparatus

1 Unit each

22

Hot Water Bath

2 Unit each

23

Portable Ultrasound scanner for veterinary pregnancy diagnosis with 2 nos of probe for small
and large Animal

1 Unit each

24

Ice Lined Refrigerator (ILR) with specialized Thermo regulator 275ltr capacity

1 Unit each

25

IMV make Cochette or equivalent

3000 pc each

26

IMV Semen Filter 230 mm: For Cochette or equivalent(1x200 pcs)

10 pkt each

27

IMV Golden Gilt Catheter: IMV make or equivalent

1000 pc each

28

IMV Golden PIG Catheter: IMV make or equivalent

1000 pc each

fi

Page 21 of 21
