---
doc_id: "18c9dff4cac4e32f"
source_url: "https://landj.mizoram.gov.in/uploads/attachments/2e8b141e72eb16da5a4fad66c35a1fff/notification_5_57fb66c0cf3cf.pdf"
ministry: "Law and Judicial Department, Mizoram"
title: "notification_5_57fb66c0cf3cf.pdf"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c7e95c153f64c155"
---

<!-- page 1 -->

GOVERNMENT OF MIZORAM
LAW AND JUDICIAL DEPARTMENT
…………….
NOTIFICATION
Dated Aizawl, the 6th Oct., 2016
No. A. 45012/32/2015-LJE

:

The Uniform terms & conditions for

engagement of Govt. Advocates in the Govt. of Mizoram, 2016 as notified vide
No. A-45012/32/2015-LJE Dt. 28.9.2016 shall be deemed to come into effect
from the date of the Notification.

Sd/- MARLI VANKUNG
Secretary to the Govt. of Mizoram
Law & Judicial Department
……………….
Memo No. A. 45012/32/2015-LJE
Copy to: -

:

Dated Aizawl, the 6th Oct., 2016

1. Secretary to Governor, Mizoram.
2. P.S to Chief Minister, Mizoram.
3. All P.S to Ministers/Ministers of State, Mizoram.
4. Sr. PPS to Chief Secretary, Govt. of Mizoram.
5. Registrar, Gauhati High Court (AB).
6. All Administrative Department.
7. All Head of Department.
8. Controller, Printing & Stationery with 6(six) spare copies for
publication in the Mizoram Gazette.
9. All Government Advocate -cum- Public Prosecutors
10. Guard File.

(VINCENT LALROKIMA)
Deputy Secretary to the Govt. of Mizoram
Law & Judicial Department
……………...
FD

<!-- page 2 -->

UNIFORM TERMS & CONDITIONS FOR ENGAGEMENT OF GOVERNMENT
ADVOCATES IN THE GOVERNMENT OF MIZORAM,2016
1.

Definition:
(1)
‘Advocate’ means an Advocate as defined in the Advocates Act, 1961 (Central
Act No. 25 of 1961).
(2)
‘Government’ means the Government of Mizoram.
(3)
‘Appointing Authority’ means any Secretary to the Government of Mizoram, of
the Departments listed under the Mizoram (Allocation of Business) Rules, 2014.
(4)
‘Government Advocate’ means an Advocate engaged or empanelled as such
by the Government to enter appearance in any Court of Law including Tribunal,
Quasi Judicial Fora on its behalf and it shall include:(a) Additional Advocate General/Public Prosecutor in the Gauhati High Court.
(b) Government Advocate/Additional Public Prosecutor in the Gauhati High
Court.
(c) Government Advocate/Public Prosecutor in the District Courts in Mizoram.
(d) Additional Government Advocate/Additional Public Prosecutor in the
District Courts in Mizoram.
(e) Assistant Government Advocate/Assistant Public Prosecutor in the District
Courts in Mizoram.
(f) Standing Counsel and Assistant Standing Counsel engaged by concerned
departments.

2.

Qualification for engagement:
(1)
No person shall be eligible for engagement as a Government Advocate unless
he holds a degree in law from a recognized university and who is a registered
Advocate under the Bar Council and has been in continuous practice for a
period of not less than (a) 10 years for Additional Advocate General/Public Prosecutor of the High
Court [1(4)(a) above] and Government Advocate/Public Prosecutor of the
District Courts [1(4)(c) above].
(b) 7 years for Government Advocate/Additional Public Prosecutor of the High
Court [1(4)(b) above].
(c) 7 years for Additional Government Advocate/Additional Public Prosecutor
of the District Court [1(4)(d) above].
(d) 3 years for Assistant Government Advocate/Assistant Public Prosecutor of
the District Court [1(4)(e) above].
(e) Standing Counsel shall fulfill the eligibility at ‘a’ above and Assistant
Standing Counsel shall fulfill the eligibility at ‘b’ and shall be entitled to the
remunerations accordingly.
(2)

All engagements of Government Advocates are to be co-terminus with the term
of the Ministry or its pleasure thereof subject to approval for re-engagement.

3.

Advocate on Panel:
The Government may engage panel of Advocates to conduct any of the duties
assigned to the Government Advocate and they shall be entitle fees at Annexure - II.

4.

Special Public Prosecutor:
The Government may engage a Special Public Prosecutor in respect of certain
Acts or Court cases which requires the engagement of such Public Prosecutors from
amongst the Government Advocates and shall be entitled to Fees at Annexure-II.

5.

Duties:
Duties of the Government Advocate under these rules shall be as specified in
Annexure – I.

<!-- page 3 -->

6.

Restriction on taking cases:
No Government Advocate engaged under this terms and conditions shall do
any act/omission in contravention of the legal ethics prescribed under the Advocates
Act, 1961.

7.

Matters relating to contempt cases:
(1) A Government Advocate shall appear on behalf of a Government Servant against
whom a contempt case under Contempt of Courts Act, 1971 is filed for his/her
alleged act/omission in the discharge of his/her duties as a public servant.
Provided that such Government Servant may, if he so desires, engage an
Advocate of his choice to represent him/her in contempt cases.
(2) The Department which has to substantially defend the case shall be liable to pay
the fee of the Advocates for their appearances in Contempt Cases even for all the
other alleged contempners in the concerned case.
(3) That an uniform lump sum rate of ` 20,000/- for each case shall be paid to those
Advocates (Govt. Advocates or Private Advocates) appearing in Contempt Case
irrespective of the number of officials involved/represented in the concerned case
by said Advocate. If, however the amount is found unacceptable by private
Advocates, the quantum may be increased in consultation with the Law & Judicial
Department as may be necessary on a case by case basis.
(4) That if a Govt. Servant who is bound to comply with the Order of the Court by
virtue of the office that he hold but is unable to comply with such order due to
circumstances beyond his control or has complied with the order of the court to the
best of his capabilities but nonetheless is still found liable for Contempt of Court by
the court of original jurisdiction before which Contempt Case is filed against him,
will, with prior approval of the Minister, Law & Judicial Department, be allowed to
plead his case in the higher courts and the cost incurred for such a process
including Advocate’s fees shall be borne by the department which has to
substantially defend the case.

8.

Rates of fees:
Government Advocate shall be entitled to rates of fees specified in
Annexure – II.
Provided that the Government may, at anytime, revise the rates of fees as it
deems necessary.

9.

Restriction on consultation fees:
No Government Advocate shall be entitled to any fees for consultation with the
officers of the Government in Government cases.

10.

Restriction on other paid employments:
No Government Advocate shall take up any other paid employments of any
kind during the office hours on working days.

11.

Notice of resignation:
Government Advocate shall be under obligation to serve one month notice of
resignation.

12.

Removal of Government Advocate:
In an event of failure of a Government Advocate to perform his/her duties
specified in Annexure – I or any shortcoming in their performance as assessed by the
concerned Departments, his/her service may be terminated giving one month notice or
on payment of one month professional fee.

<!-- page 4 -->

13.

Limitation of the Office:
Every Government Advocate shall be debarred from –
(1)
(2)
(3)
(4)

14.

Advising or holding briefs against the State.
Advising private parties in cases in which they are likely to be called to advise
the Government;
Using their office accommodations provided by the Government for their private
briefs/consultation/advice/counseling;
Accepting any engagement as Legal Adviser or consultant or in similar capacity
in any form or organization without prior sanction from the Government, which
may adversely affect the interest of the Government.

Interpretation of Uniform Terms and Conditions:
In the event of any difficulties arising in the interpretation of the above terms
and conditions, the decision of the Law & Judicial Department shall be binding.
All rules and notifications relating to the engagement and terms or conditions of
engagement and fees for engagement of such Government Advocates, published or
notified by this Department shall stand superseded with immediate effect.

<!-- page 5 -->

ANNEXURE – I
1.

To represent the Government at all stages in cases before the High Court, District
Courts, Tribunals and Quasi Judicial Fora as may be assigned.

2.

To appear as a Junior to the Advocate General or any other designated Senior
Advocate as may be determine by the Government.

3.

To prepare briefs, paper books, synopsis of arguments and obtain copies of order
sheet in all cases in which he has been briefed to appear.

4.

To inform the department concerned of the date fixed in all cases in which he has been
briefed with intimation to the Law & Judicial Department.

5.

To prepare plaint, written statement, counter affidavit, rejoinder and drafting of all kind.
If deemed necessary to get such draft settled by the senior council as the case may be.

6.

To hold conference with the officers of the Department involved in litigation well in
advance of the date or dates of hearing fixed and to get the briefing.

7.

To tender advise to Government departments wherever required.

8.

To carefully examine every judgment, order etc. of the cases handled and to see
whether it is a fit case for appeal and to make any other appropriate recommendation
or suggestions to the Government.

9.

To maintain records of cases handled by him/her for ready reference.

10.

To hold regular review meeting with the Departments concern.

11.

To abide by the legal ethics governing the Advocates under the Advocates Act, 1961.

12.

To perform such other duties or responsibilities as may be assign to him by the
Government.

<!-- page 6 -->

ANNEXURE - II
TABLE OF RATES OF FEES PAYABLE TO THE GOVERNMENT ADVOCATES :
A. Fees payable to Government Advocates in the District Court:
Sl. No.

Designation

Lumpsum Amount

1.

Sr. Govt. Advocate /Public Prosecutor

` 70,000/-

2.

Govt. Advocate /Public Prosecutor

` 64,000/-

3.

Addl. Govt. Advocate/Addl. Public Prosecutor

` 59,000/-

4.

Addl. Govt. Advocate /Asst. Public Prosecutor

` 47,000/-

B. Fees payable to Government Advocates in the High Court:
Sl.
No.

Note:

Designation

Lumpsum Amount

1.

Addl. Advocate General

` 64,000/-

2.

Govt. Advocate

` 59,000/-

1) The Senior Government Advocate -cum- Public Prosecutor is supernumerary in
function and shall ceased to exist soon after the incumbent retire or has
become incapable of performing his duties.
2) Designation as PP/Addl. PP of the High Court shall give entitlement to an
additional 20% of the normal fee, as the case may be.

C. Fees payable to Special Public Prosecutor:
The Special Public Prosecutor shall be entitled to an additional 20% of their
existing fees.
D. Fees payable to Advocate on Panel:
An advocate on Panel if engaged in any case shall be entitled to the following
fees:
(a)

For appearance
(i)
If having practice for
more than 20 yrs.

-

` 800/- per day
(irrespective of the no. of cases).

(ii)

If having practice for
more than 10 yrs, but
less than 20 yrs.

-

` 700/- per day
(irrespective of the no. of cases).

(iii)

If having practice for
more than 5 yrs, but
less than 10 yrs

-

` 400/- per day
(irrespective of the no. of cases).

(iv)

If having practice for
less than 5 yrs.

-

` 300/- per day
(irrespective of the no. of cases).
