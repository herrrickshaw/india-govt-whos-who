---
doc_id: "af68147faa0bd8cd"
source_url: "https://gad.mizoram.gov.in/uploads/attachments/2026/10/24087709a5ec54df7f16d9d388238e9e/posts-666-om-on-observance-of-rti-week-2026-attendance-at-the-state-level-function-regd.pdf"
ministry: "General Administration Department, Mizoram"
title: "OM on Observance of RTI Week, 2026-Attendance at the State Level function-regd."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "782f2b1a65613cc9"
---

<!-- page 1 -->

F-12013/65/2025-ESTT-GAD

I/88568/2026

No. F-12013/65/2025-ESTT-GAD
GENERAL ADMINISTRATION DEPARTMENT
MIZORAM SECRETARIAT, MINECO, AIZAWL-796001
Dated Aizawl, the 7th October, 2026

OFFICE MEMORANDUM
Subject:

Observance of RTI Week, 2026-Attendance at the State Level functionregarding

The Government of Mizoram is observing RTI Week, 2026 with the objective of
promoting awareness and understanding of the provisions of the Right to Information Act,
2005, and to further strengthen transparency and accountability in public administration.
In this connection, a function in observance of RTI Week, 2026 will be held on, 8th
October, 2026 (Thursday) at 2:00PM at the Conference Hall, Mizoram Legislative
Assembly Secretariat, Aizawl. The function will be graced by General (Dr.) Vijay Kumar
Singh, PVSM, AVSM, YSM (Retd.) Governor of Mizoram.
All First Appellate Authorities (FAAs) and State Public Information Officers (SPIOs)
under the Government of Mizoram within Aizawl are requested to attend the function
positively.
The concerned Heads of Departments/Offices are requested to kindly ensure the
attendance of the respective FAAs and SPIOs at the said function.

Sd/-SUDHIR KUMAR
Principal Secretary to the Govt. of Mizoram
General Administration Department
Memo No. F-12013/65/2025-ESTT-GAD :
Dated Aizawl, the 7th October, 2026
Copy to:
1. Secretary to the Governor of Mizoram
2. All Members of Legislative Assembly, Mizoram
3. All Administrative Departments, Govt. of Mizoram.
4. All Heads of Departments, Govt. of Mizoram.
5. Website Manager, GAD for uploading on the website.
6. Guard File.

(CHRISTINA LALMUANZUALI)
Under Secretary to the Govt. of Mizoram
General Administration Department
