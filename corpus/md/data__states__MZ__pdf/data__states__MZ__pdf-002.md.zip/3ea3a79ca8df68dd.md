---
doc_id: "3ea3a79ca8df68dd"
source_url: "https://sportscouncil.mizoram.gov.in/uploads/attachments/2022/09/3cf1fa1ed8a353f3f77ebda69773c48c/mssc-local-purchase-advisory-board.pdf"
ministry: "Mizoram State Sports Council"
title: "MSSC Local Purchase Advisory Board"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "a7dfd8d86cc73170"
---

<!-- page 1 -->

! —
we (#)
Government of Mizoram -
~ss m
> MIZORAM STATE SPORTS COUNCIL
D-24, M.G Road, Upper Khatla, Aizawl-796001 som
a FI B q B
f (tif
a
_Website : www.sportscounciLmizoram.gov.in Email : mssc1976@gmail.com Phone : 0389 - 2322846 Fax: 0389 - 2319381
Dated Aizawl, the 27 November, 2020
OFFICE ORDER
No. E-150/MSSC/2020/35: In pursuance of resolution No. 6 (I) of the Executive
Committee Meeting of the Mizoram State Sports Council held on the 16 November,
2020, and in accordance with Rule - 2 of the Mizoram Public Procurement Rules, 2020,
| Local Purchase Advisory Board of the Mizoram State Sports Council is hereby
constituted consisting of the following members:
Chairman - Secretary, MSSC.
Members - i) Administrative Officer, MSSC
| ii) Accounts Officer, MSSC.
| The Board will be responsible for purchase of goods costing upto Rs.
2,50,000 (Rupees Two Lakh Fifty Thousand) on each occasion with an annual ceiling of
Rs. 7,50,000 (Rupees Seven Lakh Fifty Thousand).
This issues with the approval of the President, Mizoram State Sports
| Council. .
|
ant
N TANPUIA)
Secretary,
Mizoram State Sports Council
Aizawl, Mizoram.
\ Memo No. E-150/MSSC/2020/35 : Dated Aizawl, the 23™ November, 2020
| Copy to:
1. The Private Secretary to the Minister, Sports & Youth Services Department
for information of Minister.
| 2. All members of the Executive Committee, Mizoram State Sports Council for
| information.
3. The Commissioner and Secretary to the Government of Mizoram, Finance
| Department for kind information and necessary action.
4. All Officers of this office for information.
| | 5. Office Guard file. VA it
| | Secretary .
| Mizoram State Sports Council,
| Aizawl, Mizoram
