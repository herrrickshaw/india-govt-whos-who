---
doc_id: "d5428bbcdbe569bc"
source_url: "https://cdn.s3waas.gov.in/s30ff39bbbf981ac0151d340c9aa40e63e/uploads/2019/08/2019080289.pdf"
ministry: "Siaha"
title: "Revised Guidelines on BADP 2014"
date: ""
pages: 29
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "553030dc2ba6ba4f"
---

<!-- page 1 -->

. Ministry of Home Affairs
Department of Border Management
Border Area Development Programme (BADP): Revised Guidelines
(February. 2014)

1. Objective:

The main objective of the BADP is to meet the special developmental
needs of the people living in remote and inaccessible areas situated near the
international border and to saturate the border areas with the entire essential
infrastructure through convergence of Central/State/ BADP/Local schemes and
participatory approach.
2. Coverage:
2.1. The BADP will continue to be a 100% centrally funded programme. The
BADP would cover 362 border blocks, which are located along the international
border and come under 96 border districts of 17 States viz Arunachal Pradesh,
Assam, Bihar, Gujarat, Himachal Pradesh, Jammu & Kashmir, Manipur,
Meghalaya, Mizoram, Nagaland, Punjab, Rajasthan, Sikkim, Tripura, Uttar
Pradesh, Uttarakhand and West Bengal. Funds will be allocated to the States on
the basis of (i) length of international border (ii) population of border blocks and
(iii) area of border blocks with these criteria having equal weightage. Besides,
15% weightage will be given to hilly, desert and Rann of Kutchh areas on
account of difficult terrain, scarcity of resources, higher cost of construction ete.
2.2 The border block will be the spatial unit within which the State
Government shall arrange to utilize the BADP funds only in those villages of
the blocks, which are located ‘within 0-10 km’ from the international border.
Those villages, which are located nearer to the international border will get first
priority. After saturating these villages with basic infrastructure, the next set of
villages located within 0-15 km and 0-20 km need to be taken up. If the first
village in a block is located at a far away location from the international border,
the first village/hamlet in the block may be taken as “0” km distance village for
drawing the priority list.
2.3 District Administration, first of all, will find out the resources and do the |
spatial mapping of the border block(s) covered under the BADP by taking into |
account the following and prepare block-wise plan accordingly: |

Page 1 of 29

<!-- page 2 -->

. G) The BADP funds will be utilized for undertaking developmental
scheme in villages close to the ‘Zero’ line on the border on first
priority.

(ii) Border Guarding Forces shall draw a list of strategically prioritized
villages in their respective areas and forward the same to the District
Authorities, State Government and Ministry of Home Affairs. The
Strategically border villages, as drawn by BGFs and endorsed by
MHA, would be saturated first with respect to developmental
activities such as road connectivity, electricity, drinking water
supply, sanitation, health, agriculture & allied sectors, etc.

(iii) After saturating the strategically prioritized villages other village
will be taken up for development.

3. Guiding principles:
3.1 BADP funds shall ordinarily be used for meeting the critical gaps and to
meet the immediate needs of the border population. Planning and
implementation of BADP schemes should be on participatory and decentralized
basis thorough the Panchayati Raj Institutions/Autonomous Councils/Other
Local Bodies/Councils.
3.2 The State Governments may consider creating/nominating a Nodal
Department/Cell within the existing administrative arrangement for
implementation of the Border Area Development Programme (BADP). The
Nodal Department dealing with the BADP in the State shall hold individual
meetings with line departments of the States such as Power, Rural Development,
Electricity, Roads & Buildings, Water Supply, Social Welfare, Public
Distribution, Civil Supplies etc. in order to ensure the implementation of the
respective State/Central schemes in the identified border blocks. Utilization of
funds under the Centrally Sponsored Schemes/Flagship Schemes of Govt. of
India and the State plan schemes to the maximum possible extent in the border
blocks should be ensured. To avail funds under the various Centrally Sponsored
Scheme/flagship programmes of Government of India and for relaxation in
guidelines, if any, the State Departments concerned may forward suitable
proposals to the Ministries/ Departments of Government of India concerned
with a copy thereof to the Department of Border Management, MHA for
information.
3.3 A baseline survey shall be carried out in border villages in order to assess
the gaps in basic physical and social infrastructure. Preparation of a village-wise
plan shall be ensured duly indicating the projects/funding through State Plan
Schemes/the Centrally Sponsored Schemes (CSS)/Flagship Schemes of
Government of India and the BADP. Such a plan shall also ensure the
Page 2 of 29

<!-- page 3 -->

. convergence of various Central/State schemes with the Border Area
Development Programme (BADP).
4. — Selection of schemes:
4.1 An illustrative list of schemes, which can be taken up under BADP, is at
Annexure-I, A List of schemes not permissible under BADP is at Annexure-II.
Schemes can also be suggested by Border Guarding Forces (BGFs) concerned
and expenditure on the same shal] not exceed 10% of the annual allocation
made to the State. A list of permissible and non-permissible security related
schemes is at Annexure-Hl..
4.2 State Governments, may keep a provision not exceeding 15% of the
allocation made to the State for the maintenance of assets created under the
BADP subject to the condition that such expenditure can be made only after
three (3) years from the date of issue of completion certificate in respect of the
asset. The State Governments can reserve 1.5% (one and half percent) of the
allocation made to the State subject to a maximum of Rs. 40 lakh for the
purpose of monitoring, training of staff at block level and for the evaluation of
the BADP, administrative expenditure for preparing the perspective plans, if
any, survey, logistic support (excluding purchase of vehicles), media publicity
etc. The process of completion of formalities, if any, such as forest,
environment and other local clearances, availability of land ete. should be
planned in advance, while recommending various projects under the BADP
43. There shall be a Committee headed by DM and comprised of District
Forest Officer, District Planning Officer, Superintendent of Police of concerned
District and Commandant or Deputy Commandant of the Border Guarding
Force (BGFs) present in the area, which would be responsible for planning and
implementation of the BADP in the border block covered under the BADP
guidelines;
4.4 The District Level Committee shall prepare village-wise plans through a
Base Line Survey of the villages in the block. It will assess the gaps in the
existing physical and social infrastructure sectors and work out the over arching
sectoral priorities, within which the various department schemes will be selected
in a systematic manner. E.g. if it is the school infrastructure in a particular
village then the construction of the school building / additional class rooms,
laboratories, toilets, school boundary wall, —_library/reading room,
playground/sports infrastructure, computer room etc. should be included
according to the need/gap.

Page 3 of 29

<!-- page 4 -->

: 4.5 District Level Committee shall ensure that there is no overlapping of the
schemes taken up under BADP with that of other ongoing schemes of Central
Government/State Plan and give certificate to the effect while submitting the
Annual Action Plan to the State Government for onward transmission to
Ministry of Home Affairs.

4.6 District Level Committee shall look into the convergence with on-going
development programmes and schemes of different Ministries/Departments of
Central/State Government and funds coming through various channels e.g.
PMGSY, MNREGA, SSA, Water Supply Schemes, Health Schemes, Social
Development Schemes, Rural Development Schemes, Panchayati Raj Schemes,
skill development, and other schemes for the well being of the people.

4,7 District Level Committee shall have consultation with the local Member
of Parliament, MLA, Members of PRIs, Autonomous Councils, community
leaders and development agencies to know the felt-needs of the people and take
final decisions keeping in view the people’s priorities, and its own assessment
for bridging the gaps in public infrastructure and services for selection of works
within the overall sectoral priorities.

48 District Level Committee shall ensure that no schemes below the
estimated cost of 5 lakh is included in the Annual Action Plan of the BADP.

5. Empowered Committee:

The policy matters such as the guidelines of BADP, the geographical
areas within which the BADP is implemented; allocation of funds, modalities of
execution of schemes etc. will be laid down by an Empowered Committee
constituted under the Chairmanship of the Secretary (Border Management) in
the Ministry of Home Affairs. The Composition and functions of the
Empowered Committee is at Annexure-IV (a).

6. State Level Screening Committee:

6.1 Subject to such general/special directions as may be given by the
Empowered Committee, schemes for each State will be approved by a State
Level Screening Committee chaired by the Chief Secretary of the State. The
Composition and functions of the State level Screening Committee (SLSC) is at
Annexure-IV(b). The respective Border Guarding Force (BGF) shall nominate
State-wise nodal officers for co-ordination with the States and such nodal
officers shall be invited for the State Level Screening Committee meetings. The
State Government will furnish the Annual Action Plan of BADP as approved by

Page 4 of 29

<!-- page 5 -->

- the State Level Screening Committee (SLSC) to the Ministry of Home Affairs,
Department of Border Management, Government of India, latest by the month
of May every year as in the proforma given at Annexure-V, Annexure-V (a) and

| Annexure-V (b).

| 7. Flexibility in execution of programme:
7.1 To provide flexibility, schemes under the BADP can be executed by any
of the following agencies:

(i) State Government agencies such as PWD, PHE, Rural Development
agencies, other line department agencies;

(ii) Central Government agencies such as CPWD, Border Guarding
Forces located in the border areas;

Gii) Panchayati Raj Institutions/ Autonomous District
Councils/Traditional Councils, other Local Bodies & Village
Authorites/Councils

Due emphasis should be given to effective involvement of local

population, voluntary agencies comprising of local NGOs/ Self Help Groups
which are not receiving foreign aid/assistance may be engaged for executing
schemes in order to inspire mutual trust and confidence between the
Government and the border population.
8. Funds flow:
8.1 Before the commencement of the financial year, the Department of
Border Management in the Ministry of Home Affairs would convey the
quantum of funds allocated to the States during the next year under the BADP.
The Annual Action Plan consisting of schemes, duly approved by State Level
Screening Committee (SLSC) have to be forwarded to the Department of
Border Management, Ministry of Home Affairs as in the proforma at Annexure-
V for release of funds.
8.2 Funds will be released to States in two installments. Funding for the
subsequent year will be based on confirmation of expenditure and receipt of
approved list of schemes. The 1° installment of 90% of the allocation of the
State, will be released to the State only after the receipt of Utilization
Certificates (UCs) for the amount released in the previous years except the
preceding year; If there is any shortfall in furnishing the UCs for the amount
released during the previous years, except the preceding year, the same would
be deducted at the time of release of the |" installment. The 2" installment of
the remaining 10% of the allocation of the State will be released to the State
Page 5 of 29

<!-- page 6 -->

| : only after furnishing of UCs to the extent of not less than 50% of the amount
released during the month of preceding year, and furnishing of Quarterly
Progress Reports (Physical & Financial) up to the quarter ending September.
(i.e. 2" quarter of the financial year).
8.3. To the extent of submission of pending UCs pertaining to the previous
years, deduction, if any, made in the release of 1 installment for non-
submission of UCs will be made good at the time of release of 2™ installment.
State Governments are required to have a separate budget head for the BADP.
Funds should be released by the State Governments to the implementing
agencies immediately upon receipt of the same from Government of India and
as per the directions of Government of India, Ministry of Finance; parking of
funds at any level is strictly prohibited.
9. Monitoring and review:
9.1 State Governments shall develop an institutional system for inspection
of the BADP schemes/projects and submit reports to the Department of Border
Management, Ministry of Home Affairs. Each border block should be assigned
to a high-ranking State Government Nodal Officer who should regularly visit
the block and take responsibility for BADP schemes. A quarterly report should
be sent to the Ministry of Home Affairs indicating the number of inspections
conducted and highlighting the important achievements/lacunae pointed out in
the reports of the inspecting officers. Third party inspection also needs to be
commissioned by the States for an independent feedback on the quality of work
and other relevant issues. An appropriate ‘Social Audit System’ should also be
put in place by the State Governments.
9.2 District Level Committee shall take responsibility of monitoring of
implementation of works under BADP as well as quality of works and submit a
report on quarterly basis to State Government for onward transmission to
Ministry of Home Affairs along with the photos of the works/schemes.
9.3 Quarterly progress reports should be submitted scheme-wise to the
Department of Border Management latest by 15" day of closure of the quarter
as in the Proforma at Annexure-VI. The year-wise consolidated utilization
certificates should be sent in the prescribed proforma (GFR-19A) of the General
Financial Rules within one month of the closure of the financial year as given at
Annexure-VII. A display board may be kept at project sites indicating that the
work is being done/has been completed under the BADP of Government of
India.

Page 6 of 29

<!-- page 7 -->

: 9.4 State Governments shall develop an inventory of assets created under the
BADP in border villages/hamlets, for analytical purposes etc.. Such details may
be communicated to the Department of Border Management, Ministry of Home
Affairs with a write-up on important schemes/projects (with photographs)
implemented by the States. An appropriate “Management Information System
(MIS)” will be developed in the Ministry of Home Affairs by treating villages
as the basic unit. The MIS will be web enabled for regular up-date by the
States.
10. Utilization of Interest Earned on Deposits: - Interest accrued on deposits
on BADP funds at any level shall be treated as additional resources under the
BADP and would be utilized on the works/projects drawn by the District Level
Committee for the areas covered under the guidelines of the BADP in priority
villages.
11. C & AG audit: State Government shall have the regular audit of works
taken up under BADP carried out by C & AG and furnish the observations of C
& AG on expenditure under the head BADP after completion of C & AG Audit
to Ministry of Home Affairs.
tek tek
i
|
Page 7 of 29

<!-- page 8 -->

a Annexure-T
~ Lllustrative List of Schemes/Projects permissible under the Border _Area_ Development
: Programme.

The BADP funds shall ordinarily be used for meeting the critical gaps after utilizing funds
under the various Central/State schemes and to meet the immediate needs of border population. A
base line survey shall be carried out in border villages in order to assess the gap in basic physical
and social infrastructure and convergence of various Central/State schemes with the BADP should
be ensured.

Various schemes/projects that can be taken up under BADP sectors are as illustrated below:

1) Education:

(i) Primary/Middle/Secondary/Higher secondary school _ buildings (including additional

rooms)

(ji) Development of play fields

(iii) Construction of hostels/dormitories

(iv) Public libraries and reading rooms
2) Health

(i) Building infrastructure (PHC/CHC/SHC)

(ii) Provision of medical equipments of basic/clementary Type. X-Ray, ECG machines,

equipment for dental clinic, pathological labs. etc. can also be purchased.

(iii) Setting up of mobile dispensaries/ambulances in rural areas by Govt./ Panchayati Raj

Institutions including Tele medicine.
3) Agriculture and allied sectors

(i) Animal Husbandry & Dairying

(ii) Pisciculture

ii) — Sericulture

(iv) Poultry farming/Fishery/Pig/Goat/Sheep farming.

(vy) Farm forestry, horticulture/floriculture.

(vi) Public drainage facilities.

(vii) Construction of irrigation embankments, or lift irrigation or water _ table recharging
facilities(including minor irrigation works).

(viii) Water conservation programmes

(ix) Soil conservation- protection of erosion-flood protection.

(x) Social Forestry, JFM, parks, gardens in government and community lands or other
surrendered lands including pasturing yards.

(xi) Use of improved seeds, fertilizers and improved technology

(xii) Veterinary aid Centres, artificial insemination Centres and breeding Centres.

(xiii) Area specific approach keeping in view the economy of Scale — Backward-Forward
integration.

4) Infrastructure

qi) Construction and strengthening of approach roads, link roads (including culverts &
bridges)

(ii) Industries - Small Seale with local inputs viz handloom, handicraft, furniture making,
tiny units, black smith works etc. and food processing industry

8

<!-- page 9 -->

te (iii) Provisions of civic amenities like electricity, water, pathways, ropeways, foot bridges,
hanging bridges, public toilets in slum areas and in SC/ST habitations and at tourist
~ centers, bus stands etc.
: (iv) Development of infrastructure for weekly haats/bazaars and also for cultural activities
etc. in border areas.

(v) Construction of buildings for recognized District or State Sports Associations and for
Cultural and Sport Activities or for hospitals (provision of multi-gym facilities in
gymnastic centers, sports association, physical education training institutions, etc.)

(vi) Construction of houses for officials engaged in education sector and health sector in
remote border areas.

(vii) Tourism/Sports/Adventure Sports Scheme — creation of world class infrastructure for
tourism and sports in border block where ever feasible- like rock climbing,
mountaineering, river rafting, forest trekking, skiing and safaris (car/bike race, camel
safaris, yak riding, boating in Rann of Kutchh.

(viii) Creation of new tourist centers.

(ix) Construction of mini open stadium/ indoor stadium /auditoriums.

(xiv) New & Renewable clectricity- Bio gas/Biomass gasification, Solar & Wind energy and
Mini Hydel Projects - systems/devices for community use and related activities.

(xv) Drains/Gutters etc.

5. Social Sector

wa Construction of community centers

(ii) Construction of Anganwadis.

(ii) Rural Sanitation blocks.

(iv) Cultural Centres /Community Halls

(vy) Construction of common shelters for the old or Handicapped

(vi) Capacity building programme by way of vocational studies &training for youth for self-
employment and skill up gradation of artisans and weavers.

6. Miscellaneous:

i) Development of Model villages in border areas.

ii) E-chaupals/ agrishops/ mobile media vans/ market yards.
iii) Cluster approach wherever feasible.
Page 9 of 29

<!-- page 10 -->

ne . Annexure-II
~ List of the works which are not permissible under the Border Area Development Programme:
Creation of tangible assets should be given priority under the BADP. The smaller
schemes, which are of direct benefit in nature to specific villages/individuals, need to be addressed
by the State Governments under their own development initiatives.
The following schemes/projects/works are not permissible under the BADP.
1, Education:
i) Buying of school dresses/ books.
i) Adult Education.
iii) Books/Journals
iv) TV/Dish antennas
2, Health:
i) Health Awareness Programme.
ii) Eye Camps.
iii) RCH Programme
iv) Blood banks
v) Control of Malaria, Filaria, Leprosy, AIDS etc.
vi) Fist aid kit for midwives.
3. Agriculture and allied sectors.:
i) Desilting of ponds in villages, towns and cities.
4. Infrastructure:
i) Any schemes of individual benefit (such as roads to dera’s and dhanies etc.)
ii) Boundary walls and construction of cremation sheds in graveyards/samsan ghats.
iii) Cleaning of cools/nalas/khalas.
iv) Boundary/retaining walls of ponds.
vy) Construction of building for Offices of local bodies, patwarkhana,
panchayatghar, BDOs, DCs, and residences for officials (except the official
engaged in education and health sector) etc.
vi) Any type of earth work which can be undertaken under the Mahatama
Gandhi National Rural Employment Guarantee Scheme (MNREGA).
10
