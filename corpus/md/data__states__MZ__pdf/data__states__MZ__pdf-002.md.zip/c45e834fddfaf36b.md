---
doc_id: "c45e834fddfaf36b"
source_url: "https://mifco.mizoram.gov.in/uploads/attachments/f22eabbd8a83e3d4f890ab7721564fc4/cancellation-order.pdf"
ministry: "Mizoram Food And Allied Industries Corporation Limited (MIFCO), Mizoram"
title: "cancellation-order.pdf"
date: ""
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "09532ae8850a9787"
---

<!-- page 1 -->

No.B.14029/7/04-RCOOP(Lq)/140
GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE SOCIETIES
MIZORAM : AIZAWL.
CANCELLATION ORDER
:

Dated Aizawl, the

February, 2011

Ramhlun South Women (Widow) Multipurpose Coop. Society Ltd.
bearing Registration No.AW-80/94-95 of Dt. 26.6.1995 was placed under Liquidation
proceeding Vide No.B.14029/7/04-RCOOP(Lq)/130 of dt. 26.5.2008. The
undersigned is in receipt of reports from the Liquidator appointed for the purpose
regarding cancellation of the Registration of the Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the Registration of
the Society.

Sd/- LALPEKLIANA
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14029/7/04-RCOOP(Lq)/140 : Dated Aizawl, the
February, 2011.
Copy to :1. The Assistant Registrar, Cooperative Societies, Aizawl East Dist. for
information and necessary action.
2. The Liquidator, Aizawl East Dist. For information and necessary action
as per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for kind
publication in the next issue of the Mizoram Gazette ( six spare copies has
been enclosed ).
4. D.A i/c Soc. for information and record.
5. D.A. i/c Stats. for information and record.
6. Notice Board.
7. Guard File.

Registrar,
Cooperative Societies,
Mizoram, Aizawl.

<!-- page 2 -->

No.B.14030/3/04-RCOOP(Lq)/170
GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE SOCIETIES
MIZORAM : AIZAWL.
CANCELLATION ORDER
:

Dated Aizawl, the

February, 2011

Zoram Pheikhawk Siam Industrial Coop. Society Ltd. bearing
Registration No.AW-180/91-92 of Dt. 3.4.1992 was placed under Liquidation
proceeding Vide No.B.14030/3/04-RCOOP(Lq)/165 of dt. 26.10.2009. The
undersigned is in receipt of reports from the Liquidator appointed for the purpose
regarding cancellation of the Registration of the Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the Registration of
the Society.

Sd/- LALPEKLIANA
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14030/3/04-RCOOP(Lq)/170 : Dated Aizawl, the
February, 2011.
Copy to :8. The Assistant Registrar, Cooperative Societies, Aizawl East Dist. for
information and necessary action.
9. The Liquidator, Aizawl East Dist. For information and necessary action
as per Rules 111 of the MCS. Rules 1996
10. The Controller, Printing & Stationaries, Govt. of Mizoram for kind
publication in the next issue of the Mizoram Gazette ( six spare copies has
been enclosed ).
11. D.A i/c Soc. for information and record.
12. D.A. i/c Stats. for information and record.
13. Notice Board.
14. Guard File.

Registrar,
Cooperative Societies,
Mizoram, Aizawl.

<!-- page 3 -->

No.B.14029/22/04-RCOOP(Lq)/137
GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE SOCIETIES
MIZORAM : AIZAWL.
CANCELLATION ORDER
:

Dated Aizawl, the

February, 2011

Sihphir Vengthar Women (Widow) Multipurpose Coop. Society Ltd.
bearing Registration No.AW-9/95-96 of Dt. 25.7.1995 was placed under Liquidation
proceeding Vide No.B.14029/22/04-RCOOP(Lq)/132 of dt. 21.7.2010. The
undersigned is in receipt of reports from the Liquidator appointed for the purpose
regarding cancellation of the Registration of the Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the Registration of
the Society.

Sd/- LALPEKLIANA
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14029/22/04-RCOOP(Lq)/137 : Dated Aizawl, the
February, 2011.
Copy to :15. The Assistant Registrar, Cooperative Societies, Aizawl East Dist.
for information and necessary action.
2. The Liquidator, Aizawl East Dist. For information and necessary
action as per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for
kind publication in the next issue of the Mizoram Gazette ( six
spare copies has been enclosed ).
4. D.A i/c Soc. for information and record.
5. D.A. i/c Stats. for information and record.
6. Notice Board.
7. Guard File.

Registrar,

<!-- page 4 -->

Cooperative Societies,
Mizoram, Aizawl.

No.B.14030/7/04-RCOOP(Lq)/101
GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE SOCIETIES
MIZORAM : AIZAWL.

CANCELLATION ORDER
:

Dated Aizawl, the

February, 2011

Aizawl Brick Making Industrial Coop. Society Ltd. bearing Registration
No.AE-261/98-99 of Dt. 28.9.1998 was placed under Liquidation proceeding Vide
No.B.14030/7/04-RCOOP/96 of dt. 28.6.2009. The undersigned is in receipt of reports from
the Liquidator appointed for the purpose regarding cancellation of the Registration of the
Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the Registration of the
Society.

Sd/- LALPEKLIANA
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14030/7/04-RCOOP(Lq)/101 : Dated Aizawl, the
February, 2011.
Copy to :16. The Assistant Registrar, Cooperative Societies, Aizawl East Dist. for
information and necessary action.
2. The Liquidator, Aizawl East Dist. For information and necessary action as
per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for
kind publication in the next issue of the Mizoram Gazette ( six
spare copies has been enclosed ).
8. D.A i/c Soc. for information and record.
9. D.A. i/c Stats. for information and record.
10. Notice Board.
11. Guard File.

<!-- page 5 -->

Registrar,
Cooperative Societies,
Mizoram, Aizawl.

No.B.14031/48/04-RCOOP(Lq)
GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE SOCIETIES
MIZORAM : AIZAWL.

CANCELLATION ORDER
:

Dated Aizawl, the

February, 2011

Zemabawk Weaving Coop. Society Ltd. bearing Registration No.AW-16/9596 of Dt. 14.9.95 was placed under Liquidation proceeding Vide No.B.14031/48/04RCOOP/163 of dt. 18.11.2009. The undersigned is in receipt of reports from the Liquidator
appointed for the purpose regarding cancellation of the Registration of the Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the Registration of the
Society.

Sd/- LALPEKLIANA
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14031/48/04-RCOOP(Lq) : Dated Aizawl, the
February, 2011.
Copy to :17. The Assistant Registrar, Cooperative Societies, Aizawl East Dist. for
information and necessary action.
2. The Liquidator, Aizawl East Dist. For information and necessary action as
per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for
kind publication in the next issue of the Mizoram Gazette ( six
spare copies has been enclosed ).
12. D.A i/c Soc. for information and record.
13. D.A. i/c Stats. for information and record.
14. Notice Board.
15. Guard File.

<!-- page 6 -->

Registrar,
Cooperative Societies,
Mizoram, Aizawl.

No.B.14029/42/04-RCOOP(Lq)/119
GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE SOCIETIES
MIZORAM : AIZAWL.

CANCELLATION ORDER
:

Dated Aizawl, the

February, 2011

Bawngkawn Women (Widow) Multipurpose Coop. Society Ltd. bearing
Registration No.AE-6/95-96 of Dt. 25.7.95 was placed under Liquidation proceeding Vide
No.B.14029/42/04-RCOOP/114 of dt. 22.6.2010. The undersigned is in receipt of reports
from the Liquidator appointed for the purpose regarding cancellation of the Registration of
the Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the Registration of the
Society.

Sd/- LALPEKLIANA
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14029/42/04-RCOOP(Lq)/119 : Dated Aizawl, the
February, 2011.
Copy to :18. The Assistant Registrar, Cooperative Societies, Aizawl East Dist. for
information and necessary action.
2. The Liquidator, Aizawl East Dist. For information and necessary action as
per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for
kind publication in the next issue of the Mizoram Gazette ( six
spare copies has been enclosed ).
16. D.A i/c Soc. for information and record.
17. D.A. i/c Stats. for information and record.
18. Notice Board.
19. Guard File.

<!-- page 7 -->

Registrar,
Cooperative Societies,
Mizoram, Aizawl.

No.B.14034/53/04-RCOOP(Lq)/116
GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE SOCIETIES
MIZORAM : AIZAWL.

CANCELLATION ORDER
:

Dated Aizawl, the

February, 2011

Aizawl West Fisheries & Marketing Coop. Society Ltd. bearing Registration
No.AW-26/98-99 of Dt. 22.7.98 was placed under Liquidation proceeding Vide
No.B.14034/53/04-RCOOP/112 of dt. 24.7.2009. The undersigned is in receipt of reports
from the Liquidator appointed for the purpose regarding cancellation of the Registration of
the Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the Registration of the
Society.

Sd/- LALPEKLIANA
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14034/53/04-RCOOP(Lq)/116 : Dated Aizawl, the
February, 2011.
Copy to :19. The Assistant Registrar, Cooperative Societies, Aizawl East Dist. for
information and necessary action.
2. The Liquidator, Aizawl East Dist. For information and necessary action as
per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for
kind publication in the next issue of the Mizoram Gazette ( six
spare copies has been enclosed ).
20. D.A i/c Soc. for information and record.
21. D.A. i/c Stats. for information and record.
22. Notice Board.
23. Guard File.

<!-- page 8 -->

Registrar,
Cooperative Societies,
Mizoram, Aizawl.

No.B.14023/2/2004-RCOOP/108
GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE SOCIETIES MIZORAM :
AIZAWL.

:

Dated Aizawl, the

November, 2009

CANCELLATION ORDER
Aizawl Central Housing Coop. Society Ltd. bearing Registration No.AW111/91-92 of Dt. 30.10.1991 was placed under Liquidation proceeding Vide
No.B.14023/2/04-RCOOP/102 of dt. 8.7.2008. The undersigned is in receipt of reports from
the Liquidator appointed for the purpose regarding cancellation of the Registration of the
Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the Registration of the
Society.

Sd/- LALPEKLIANA
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14023/2/2004-RCOOP/108 : Dated Aizawl, the
2009.

November,

<!-- page 9 -->

Copy to :20. The Assistant Registrar, Cooperative Societies, Aizawl East
Dist. for information and necessary action.
2. The Liquidator, Aizawl East Dist. For information and
necessary action as per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for
kind publication in the next issue of the Mizoram Gazette ( six
spare copies has been enclosed ).
24. D.A i/c Soc. for information and record.
25. D.A. i/c Stats. for information and record.
26. Notice Board.
27. Guard File.

Registrar,
Cooperative Societies,
Mizoram, Aizawl.

No.B.14030/11/04-RCOOP/192
GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE SOCIETIES
MIZORAM : AIZAWL.
:

Dated Aizawl, the

November, 2009

CANCELLATION ORDER
Edenthar Cottage Industrial Coop. Society Ltd. bearing
Registration No.A-104/80-81 of Dt. 7.2.1981 was placed under Liquidation
proceeding Vide No.B.14030/11/04-RCOOP/181 of dt. 6.11.2008. The
undersigned is in receipt of reports from the Liquidator appointed for the
purpose regarding cancellation of the Registration of the Society.

<!-- page 10 -->

The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the
Registration of the Society.

Sd/- LALPEKLIANA
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14030/11/04-RCOOP/192 : Dated Aizawl, the
2009.

November,

Copy to :21. The Assistant Registrar, Cooperative Societies, Aizawl East
Dist. for information and necessary action.
2. The Liquidator, Aizawl East Dist. For information and
necessary action as per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for
kind publication in the next issue of the Mizoram Gazette ( six
spare copies has been enclosed ).
28. D.A i/c Soc. for information and record.
29. D.A. i/c Stats. for information and record.
30. Notice Board.
31. Guard File.

Registrar,
Cooperative Societies,
Mizoram, Aizawl.

No.B.14029/25/04-RCOOP/233
GOVENMENT OF MIZORAM

<!-- page 11 -->

OFFICE OF THE REGISTRAR OOF COOPERATIVE SOCIETIES
MIZORAM : AIZAWL.
:

Dated Aizawl, the

November, 2009

CANCELLATION ORDER
Ramhlun ‘N’ Women Multipurpose Coop. Society Ltd. bearing
Registration No.A-12/88-89 of Dt. 24.10.88 was placed under Liquidation
proceeding Vide No.B.14029/25/04-RCOOP/211 of dt. 12.3.2008. The
undersigned is in receipt of reports from the Liquidator appointed for the
purpose regarding cancellation of the Registration of the Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the
Registration of the Society.

Sd/- LALPEKLIANA
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14029/25/04-RCOOP/233 : Dated Aizawl, the
2009.

November,

Copy to :22. The Assistant Registrar, Cooperative Societies, Aizawl East
Dist. for information and necessary action.
2. The Liquidator, Aizawl East Dist. For information and
necessary action as per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for
kind publication in the next issue of the Mizoram Gazette ( six
spare copies has been enclosed ).
32. D.A i/c Soc. for information and record.
33. D.A. i/c Stats. for information and record.
34. Notice Board.
35. Guard File.

<!-- page 12 -->

Registrar,
Cooperative Societies,
Mizoram, Aizawl.

No.B.14029/50/04-RCOOP/72
GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE SOCIETIES
MIZORAM : AIZAWL.
:

Dated Aizawl, the

November, 2009

CANCELLATION ORDER
Sesawng Multipurpose Coop. Society Ltd. bearing Registration
No.AE-315/04-05 of Dt. 11.8.2004 was placed under Liquidation proceeding
Vide No.B.14029/50/04-RCOOP/61 of dt. 27.10.2008. The undersigned is in
receipt of reports from the Liquidator appointed for the purpose regarding
cancellation of the Registration of the Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the
Registration of the Society.

Sd/- LALPEKLIANA
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14029/50/04-RCOOP/72 : Dated Aizawl, the
2009.
Copy to :-

November,

<!-- page 13 -->

23. The Assistant Registrar, Cooperative Societies, Aizawl East
Dist. for information and necessary action.
2. The Liquidator, Aizawl East Dist. For information and
necessary action as per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for
kind publication in the next issue of the Mizoram Gazette ( six
spare copies has been enclosed ).
36. D.A i/c Soc. for information and record.
37. D.A. i/c Stats. for information and record.
38. Notice Board.
39. Guard File.

Registrar,
Cooperative Societies,
Mizoram, Aizawl.

GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE SOCIETIES
MIZORAM : AIZAWL.

No.B.14031/60/04-RCOOP/37

:

Dated Aizawl, the

November, 2009

CANCELLATION ORDER
Zuangtui Muanna Veng Handloom & Handicraft Coop. Society
Ltd. bearing Registration No.AE-326/04-05 of Dt. 29.3.2005 was placed under
Liquidation proceeding Vide No.B.14031/60/2004-RCOOP/26 of dt. 5.8.2008.
The undersigned is in receipt of reports from the Liquidator appointed for the
purpose regarding cancellation of the Registration of the Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the
Registration of the Society.

<!-- page 14 -->

Sd/- LALPEKLIANA
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14031/60/04-RCOOP/37 : Dated Aizawl, the
2009.

November,

Copy to :24. The Assistant Registrar, Cooperative Societies, Aizawl East
Dist. for information and necessary action.
2. The Liquidator, Aizawl East Dist. For information and
necessary action as per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for
kind publication in the next issue of the Mizoram Gazette ( six
spare copies has been enclosed ).
40. D.A i/c Soc. for information and record.
41. D.A. i/c Stats. for information and record.
42. Notice Board.
43. Guard File.

Registrar,
Cooperative Societies,
Mizoram, Aizawl.

GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE SOCIETIES
MIZORAM : AIZAWL.

No.B.14034/8/04-RCOOP/77

:

Dated Aizawl, the

October, 2009

<!-- page 15 -->

CANCELLATION ORDER
Sesawng Fishery Coop. Society Ltd. bearing Registration No.AE266/99-00 of Dt. 15.4.1999 was placed under Liquidation proceeding Vide
No.B.14034/8/04-RCOOP/66 of dt. 2.7.2008. The undersigned is in receipt of
reports from the Liquidator appointed for the purpose regarding cancellation of
the Registration of the Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the
Registration of the Society.

Sd/- LALPEKLIANA
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14034/8/04-RCOOP/77 : Dated Aizawl, the

October, 2009.

Copy to :25. The Assistant Registrar, Cooperative Societies, Aizawl East
Dist. for information and necessary action.
2. The Liquidator, Aizawl East Dist. For information and
necessary action as per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for
kind publication in the next issue of the Mizoram Gazette ( six
spare copies has been enclosed ).
44. D.A i/c Soc. for information and record.
45. D.A. i/c Stats. for information and record.
46. Notice Board.
47. Guard File.

Registrar,
Cooperative Societies,
Mizoram, Aizawl.

<!-- page 16 -->

GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE
SOCIETIES;MIZORAM,AIZAWL.

No.B.14031/26/04-RCOOP/193
2009

:

Dated Aizawl, the

September,

CANCELLATION ORDER
Hebron Veng Handloom Coop. Society Ltd. bearing Registration
No.AW-78/91-92 of Dt. 25.9.1991 was placed under Liquidation proceeding
Vide No.B.14031/26/04-RCOOP/187 of dt. 27.10.2008. The undersigned is in
receipt of reports from the Liquidator appointed for the purpose regarding
cancellation of the Registration of the Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative Societies Act 2006 hereby orders the Cancellation of the
Registration of the Society.

Sd/- H.P. SAHU
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No.B.14031/26/04-RCOOP/193 : Dated Aizawl, the
September,
2009.
Copy to :26. The Assistant Registrar, Cooperative Societies, Aizawl East
Dist. for information and necessary action.
2. The Liquidator, Aizawl East Dist. For information and
necessary action as per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for
kind publication in the next issue of the Mizoram Gazette ( six
spare copies has been enclosed ).
48. D.A i/c Soc. for information and record.
49. D.A. i/c Stats. for information and record.
50. Notice Board.

<!-- page 17 -->

51. Guard File.

Registrar,
Cooperative Societies,
Mizoram, Aizawl.

GOVENMENT OF MIZORAM
OFFICE OF THE REGISTRAR OOF COOPERATIVE
SOCIETIES;MIZORAM,AIZAWL.

No.B14032/9/05-RCOOP/33

:

Dated Aizawl, the

September, 2009

CANCELLATION ORDER
Seling Edenthar Livestock Coop. Society Ltd. bearing Registration No.AE350/05-06 of Dt. 2.3.2006 was placed under Liquidation proceeding Vide
No.B.14032/9/05-RCOOP/27 of dt. 21.7.2008. The undersigned is in receipt of reports
from the Liquidator appointed for the purpose regarding cancellation of the Registration of
the Society.
The undersigned, therefore, Under Section 116 (1) of the Mizoram
Cooperative
Societies Act 2006 hereby orders the Cancellation of the Registration of the Society.

Sd/- H.P. SAHU
Registrar,
Cooperative Societies,
Mizoram, Aizawl.
Memo No B.14032/9/05-RCOOP/33
:
Dated Aizawl, the
September, 2009.
Copy to :1. The Assistant Registrar, Cooperative Societies, Aizawl East Dist. for
information and necessary action.

<!-- page 18 -->

2. The Liquidator, Aizawl East Dist. For information and necessary
action as per Rules 111 of the MCS. Rules 1996
3. The Controller, Printing & Stationaries, Govt. of Mizoram for kind
publication in the next issue of the Mizoram Gazette ( six spare copies
has been enclosed ).
4. D.A i/c Soc. for information and record.
5. D.A. i/c Stats. for information and record.
6. Notice Board.
7. Guard File.

Registrar,
Cooperative Societies,
Mizoram, Aizawl.
