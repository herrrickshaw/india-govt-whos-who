---
doc_id: "feea5b573a4f4ec7"
source_url: "https://dcma.mizoram.gov.in/uploads/attachments/2024/08/a0c21b0517ac62fd5ea8aa3e4d7950af/lai-autonumoua-district-revenue-assessment-second-amendment-regulation-2006.pdf"
ministry: "District Council Affairs Department, Mizoram"
title: "The LADC (Revenue Assessment) (Second Amendment) Regulation, 2006"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e10e8f92ea25bdd3"
---

<!-- page 1 -->

The Mizoram Gazette
EXTRA ORDINARY
Dublished
by
uthorits
Regn. No. NE-313(MZ)
Rs.

2/- per issue

VOL. - XXXVI Aizawl,

Wedncsday

22.8.2007

Sravana 31,

S.E. 1929,

Issue No. 213

NOTIFIGATION
No. C.11020/1/2006-DCA/L, the 17th August, 2007. In pursuance of paragraph 11 of the
Sixth Schedule to the Constitution of ndia, the following Regulation of the Lai

Autonomous

DistrictCouncil, which received approval of the Governor of Mizoram is hereby published for
general information, namely i
THE LAI AUTONOMOUS DISTRICT COUNCIL (Revenue Assessment)(Second
Amendment)
Regulation, 2006 (which receivedassent of the Governor of Mizoram on the 13.8.2007).

Sd/

P. Chakraborty.
Secretary to the Govt.of Mizoram,
District CouncilAffairs Department.

<!-- page 2 -->

Ex-213/2007

- 2 -

COUNCIL
LAL AUTONOMOUS DISTRICT
THE
(REVENUE ASSESSMENT))(SECOND AMENDMENT) REGULATION,2007

REGULATION

to amend the Lai Autonomous District Council(Revenue Assessment)
(hereinafter referred to as the Principal Regulation)

Regulation, 2000

Be it enacted by the Lai Autonomous District Council in the Fifty - Eight year

India as follows:
1.

of

Republico,

Short Title, Extent and Commencement

(1) This Regulation may be called the Lai Autonomous District
(2)
(3)
2.

Assessment) (Second Amendment) Regulation, 2007.

Council(Revenue

It shall have the like extent as the Principal Regulation.
It shall comeinto force on and fromthe date of Publication in the

Amendment of Section 5:

Mizoram Gazelte.

For Section 5 of the Principal Regulation, the
following slall besubslituted namely:
"5.(1) Mutation and transfer fee:
The followingfees shall be levied as mutation and transfer
fee:
(a) For Agriculture Land Rs. 100/- per Hectare.
(b) For Non-Agriculture Land Re. 1.00/- per
sqm.
Provided that mutation and transfer fee in the case of
from Paternal or
Maternal property on productionof heirship certificate or valid inheritance
will or gift between Members
of family which consist of husband, wife, son,
daughter, grandson, grand daughter and grand
parents, shall be levied Rs. 100/- as its
fee.

3

Amendment of Section 6:
In the Principal Regulation for Section 6, the following shallbe
(1) In Sub-section (1)of Section 6,the word "floor" shallbe substituted, namey
substituted by he
(2)

"apartment".
In Sub-Section (2) of Section 6,the word "floor", shall be substituted bythewod

"apartment".
substituted
(3) in Sub-Section (3) of Section 6,the
be
shall
words, "Kutcha House",
by the words, "Ordinary House".

<!-- page 3 -->

lix 213/2007

(2) Mortgage Registrationfee:
Every mortgage of land to any financial Institution by the land owrner shall be
registered in the office of the LaiAutonomous District Council on paymont of Re. 0.50% from
the value of the mortgaged amount as its Registration fee".
STATEMENT OF OBJECTAND REASON

It is felt necessary to make this amendment to provide levying power on certain fees, to

collect more revenue for the Council fund.
Hence the Bill

Sd/

Lalthlamuana,

Executive Member (Rev),

Lai Autonomous District Council,

Lawngtlai.
CERTIFICATE OFAUTHENTICATION

Certified that the bill was passed by the Lai Autonomous District Council on 29th
November, 2006.

And in Authentication whereof Iput my signature in this Second day of July Two
Thousand Seven Anno Domini.

Sd/

Iassent to this Regulation
Sd/
M.M. Lakhera,

ManghmungaChinzah,

Chairman,
LaiAutonomous District Council,
Lawngtlai.

Governo.

13th August, 2007

Published and Issued by Controller, Printing &Stationery Department, Government of Mizoram
Printed at the Mizoram Government Press, Aizawl. CI720
