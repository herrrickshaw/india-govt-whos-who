---
doc_id: "8d994bfbacdf147b"
source_url: "https://fcsca.mizoram.gov.in/uploads/attachments/2024/06/8e48ad6af30a0c70af4391a69ff7f235/posts-699-07-ex-492-mizoram-consumer-protection-salary-etc-amendment-rules-2021.pdf"
ministry: "Food, Civil Supplies and Consumer Affairs Department, Mizoram"
title: "07 Ex-492-Mizoram Consumer Protection (Salary etc) Amendment Rules 2021"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a3dda1b3052fddbe"
---

<!-- page 1 -->

The Mizoram Gazette
EXTRA ORDINARY

Published by Authority
RNI No. 27009/1973
VOL - L Aizawl,

Wednesday 3.11.2021

Postal Regn. No. NE-313(MZ) 2006-2008
Kartika 12, S.E. 1943, Issue No. 492

NOTIFICATION
No. F. 20016/24/08-FCS&CA, the 3rd November, 2021.
In exercise of the powers conferred by
section 30 and section 44 read with clauses (h) and (m) of sub-section (2) of section 102 of the Consumer
Protection Act, 2019 (35 of 2019), the Governor of Mizoram is pleased to make the following rules to
amend the Mizoram Consumer Protection (Salary, allowances and conditions of service of President
and Members of the State Commission and District Commission) Rules, 2021 (hereinafter referred to
as the principal rules) notified vide No.F.20016/24/08-FCS&CA dated 25.08.2021 and published in the
Mizoram Gazette Extraordinary Issue Vol. L No. 359 dated 25.08.2021, namely:
Short title and
commencement.-

1.

(1)

(2)
Amendment
of Rule 3

2.

These rules may be called the ‘Mizoram Consumer Protection
(Salary, allowances and conditions of service of President and
Members of the State Commission and District Commission)
(Amendment) Rules, 2021'.
They shall come into force on the date of publication in the Official
Gazette.

In the principal rules, after sub-rule (4) of rule 3, the following provisos
shall be inserted, namely :“Provided that the State Government may appoint the President on ‘parttime’ basis on payment of sitting allowance of Rs. 5000/- per day of sitting.
Provided further that the State Government may appoint members of the
District Commissions on ‘part-time’ basis on payment of sitting allowance
of Rs. 3500/- (Rupees Three Thousand Five Hundred) only per day of
sitting along with ‘Conveyance Allowance’ of Rs. 500/- (Rupees Five
Hundred) only per day of sitting for the same station.
Provided also that if the place of sitting is outside the headquarters of the
President or Member of the District Commission, they shall be entitled
to ‘Travelling Allowance’ and ‘Daily Allowance’ as per Rule 8 of the
principal rules.”

<!-- page 2 -->

Ex-492/2021
Amendment
of Rule 4

-23.

In the principal rules, after sub-rule (4) of rule 4,the following provisos
shall be inserted, namely :“Provided that the State Government may appoint the President on ‘parttime’ basis on payment of lumpsum remuneration of Rs. 1,39,500/(Rupees One Lakh Thirty Nine Thousand Five Hundred) only per month
along with a Consolidated Honorarium of Rs. 700/- (Rupees Seven
Hundred) only per day of sitting.
Provided further that the President, State Commission shall be provided
with 1 (one) Domestic Attendant at the rate of ‘Unskilled Provisional
Employee’ from the date of joining his/her duty up to the date of
relinquishment of the post of the President of the State Commission.
Provided further also that the State Government may appoint a member
of the State Commission on ‘part-time’ basis on payment of sitting
allowance of Rs. 3500/- (Rupees Three Thousand Five Hundred) only
per sitting per day along with ‘Conveyance Allowance’ of Rs. 500/(Rupees Five Hundred) only per day of sitting for the same station.
Provided further also that if the place of sitting is outside the headquarter
of the Member of the State Commission, he/she shall be entitled to
‘Travelling Allowance’ and ‘Daily Allowance’ as per rule 8 of the
principal rules.”

By Order, etc.

Zothanmawia,
Secretary to the Government of Mizoram,
Food, Civil Supplies & Consumer Affairs Department.

Published and Issued by Controller, Printing & Stationery Department, Government of Mizoram
Printed at the Mizoram Government Press, Aizawl. C/50
