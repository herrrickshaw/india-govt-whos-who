---
doc_id: "c4c8af91c7eb0e2f"
source_url: "https://forensic.mizoram.gov.in/storage/images/1b14c3d8-cb8d-4852-9ce9-f2b47509a506.pdf"
ministry: "Forensic Science Laboratory, Mizoram"
title: "Recruitment Rules of  Junior Scientific Officer"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "290dc6de01499692"
---

<!-- page 1 -->

-1-

Ex-159/2026

The Mizoram Gazette
EXTRAORDINARY

Published by Authority

RNI No. 27009/1973
VOL - LV Aizawl, Thursday 26.2.2026, Phalguna 7, S.E. 1947, Issue No. 159

NOTIFICATION
No. A.12018/15(4)/2016-P&AR(GSW), Aizawl, the 23rd February, 2026:
In exercise of the
powers conferred by the proviso to article 309 of the Constitution and in supersession of the Mizoram
Police Department (Group ‘B’ posts) Recruitment Rules, 2004 as amended notified in the Mizoram Gazette
extraordinary issue number 36 dated 1.3.2005, except as respects things done or omitted to be done
before such supersession, the Governor of Mizoram hereby makes the following rules regulating the
method of recruitment to the post of Junior Scientific Officer under Home (Forensic Science Laboratory)
Department, Government of Mizoram namely :1. Short title and		 (1) These rules may be called the Mizoram Home (Forensic Science
commencement.-
Laboratory) Department (Group ‘B’ post) Recruitment Rules, 2026.
					 (2) They shall come into force from the date of their publication in the Official
						Gazette
2. Application.- 		 These rules shall apply to the post specified in Column I of the Schedule
					 annexed to these rules.

3. Number of posts,		 The number of the said post, classification and level in pay matrix or pay
classification and		 scale attached thereto shall be as specified in Column 2 to 4 of the
level in the pay		 said Schedule.
matrix or pay
scale.4. Method of
recruitment, age
limit and other
qualifications.-

The method of recruitment, age limit, qualifications and other matters relating
to the said post shall be as specified in Column 5 to 13 of the said Schedule.

5. Disqualification.-

No person -

					 (a) who has entered into or contracted a marriage with a person having a
						 spouse living; or
					 (b) who, having a spouse living, has entered into or contracted a marriage
						 with any person,
					 shall be eligible for appointment to the said post;

<!-- page 2 -->

Ex-159/2026

-2-

						 Provided that the State Government may, if satisfied that such marriage
					 is permissible under the personal law applicable to such person and to the other
					 party to the marriage and that there are other valid grounds for doing so, exempt
					 any such person from the operation of this rule.
6. Training and		 Every officials recruited under these rules shall undergo such training or
Departmental		 pass such Departmental Examination as may be prescribed from time to time.
Examination.7. Power to transfer.-

Notwithstanding anything contained in these rules, the State Government,
in public interest, shall have the right and power to transfer any officials, so
recruited under these rules to any other post or position which is equivalent
in rank or grade.

8. Power to relax.-		 Where the State Government is of the opinion that it is necessary or expedient
					 so to do, it may, by order and for reasons to be recorded in writing, in
					 consultation with the Mizoram Public Service Commission through the
					 Department of Personnel & Administrative Reforms, relax any of the provisions
					 of these rules with respect to any class or category of persons.
9. Saving.-			 Nothing in these rules shall affect reservation, relaxation of age limit and other
					 concessions required to be provided for the Scheduled Castes, the Scheduled
					 Tribes, the Ex-servicemen and other special categories of persons in accordance
					 with the order issued by Government of Mizoram from time to time in this
					regard.

K. Lalthawmmawia
Commissioner & Secretary to the Government of Mizoram,
Deptt. of Personnel & Administrative Reforms.

<!-- page 3 -->

-3-

Ex-159/2026

SCHEDULE
(See rule 2, 3 & 4)
RECRUITMENT RULES FOR GROUP ‘B’ POST IN THE DEPARTMENT OF HOME
(FORENSIC SCIENCE LABORATORY)
Whether
Level in the Selection
Age limit for
Number of
Name of Post
Classification Pay Matrix/ or Nondirect
Post
Pay Scale
Selection
recruitment
posts?
1
2
3
4
5
6
1* (2009)
Junior Scientific
*or as
1.
Officer
determined by
(Toxicology)
the Govt. from
time to time
1* (2004)
Junior Scientific
*or as
2.
Officer
determined by
(Chemistry)
the Govt. from
time to time
Between 18
1* (2009)
years
and 35
Junior Scientific
*or
as
years
Officer
3.
determined by
(Questioned
the Govt. from
General State
Level 07 in
Note: The
Document)
time to time
Service,
the Pay
crucial date for
Not
Group ‘B’,
Matrix
determining the
1* (2009)
applicable
Junior Scientific
Non-Gazetted,
(` 39100 –
age limit of
*or as
Officer
NonMinisterial
`
86800)
candidates
4.
determined by
(Ballistics &
shall be as
the Govt. from
Tool Marks)
determined by
time to time
the Govt. from
1* (2004)
time to time.
3* (2025)
Junior Scientific
*or as
5.
Officer
determined
by
(Fingerprint)
the Govt. from
time to time
1* (2009)
Junior Scientific
*or as
6.
Officer
determined by
(Photography) the Govt. from
time to time

<!-- page 4 -->

Ex-159/2026

-41* (2018)
3* (2025)

7.

8.

Junior Scientific
Officer (DNA)

*or as
determined by
the Govt. from
time to time
1* (2009)

Junior Scientific
*or as
Officer
determined by
(Cyber Forensic) the Govt. from
time to time

Educational qualification and other
qualification required for direct
recruitment

7

Whether the
age and
educational
qualifications
Period of
prescribed
probation,
for direct
if any
recruitments
will apply in
the case of
promotion?
8
9

Method of recruitment
whether by direct
recruitment or by
promotion or by
deputation/ absorption
and percentage of the
vacancies to be filled by
various methods
10

JSO (Toxicology)
1. M.Sc. in Forensic Science or M.Sc.
Chemistry or M.Sc. Pharmacology
or M.Sc. Biochemistry or M. Pharm
or M.Sc. Microbiology from a
recognized University or Institute.
Desirable: Working experience in
a recognized forensic science
1.
laboratory.
2. Basic computer knowledge as
prescribed by the government from
Not applicable
time to time.
3. A candidate must achieve a
minimum score in the qualifying
test of Mizo Language Proficiency as
prescribed by the government from
time to time.
JSO (Chemistry)
1. M.Sc. in Forensic Science or M.Sc.
Chemistry or M.Sc. Biochemistry
from a recognized University or
Institute.

100% by direct recruitment

2 years

For recruitment to the
post of Junior Scientific
Officer, the Government
shall send requisition to the
Commission separately for
each Division indicating
(i) number of vacancies and
(ii) the
required
line/
discipline of Forensic
Science.
Number of vacancies to
be filled for each required
line/discipline of Forensic
Science shall be decided
by the Government in the
Department concerned.

<!-- page 5 -->

-5Desirable: Working experience
in a recognized forensic science
laboratory.
2. Basic computer knowledge as
prescribed by the government from
2.
time to time.
3. A candidate must achieve a
minimum score in the qualifying
test of Mizo Language Proficiency as
prescribed by the government from
time to time.
JSO (Questioned Document)
1.

M.Sc. Forensic Science from a
recognized University or Institute.
Desirable: Working experience in a
recognized
forensic
science
laboratory.
3. 2. Basic computer knowledge as
prescribed by the government from
time to time.
3. A candidate must achieve a
minimum score in the qualifying
test of Mizo Language Proficiency as
prescribed by the government from
time to time.
JSO (Ballistics & Tool marks)
1.

M.Sc. Forensic Science or M.Sc.
Physics or M.Sc. Mathematics or
Applied Mathematics or B.E. (Civil/
Mechanical) from a recognized
University or Institute.
Desirable: Working experience in
a recognized forensic science
4.
laboratory.
2. Basic computer knowledge as
prescribed by the government from
time to time.
3. A candidate must achieve a
minimum score in the qualifying
test of Mizo Language Proficiency as
prescribed by the government from
time to time.
JSO (Fingerprint)
5. 1. M.Sc. Forensic Science from a
recognized University or Institute.

Ex-159/2026

<!-- page 6 -->

Ex-159/2026
Desirable: Working experience in
a recognized forensic science
laboratory.
2. Basic computer knowledge as
prescribed by the government from
time to time.
3. A candidate must achieve a
minimum score in the qualifying
test of Mizo Language Proficiency as
prescribed by the government from
time to time.
JSO (Photography)
1. M.Sc.
Forensic
Science
(specialization in Digital or
Multimedia Forensics) OR B.E. or
B.Tech or above in Computer
Science or Electronics from a
recognized University or Institute.
Desirable: Working experience in
a recognized forensic science
6.
laboratory.
2. Basic computer knowledge as
prescribed by the government from
time to time.
3. A candidate must achieve a
minimum score in the qualifying
test of Mizo Language Proficiency as
prescribed by the government from
time to time.
JSO (DNA)
1. M.Sc.
Forensic
Science
or
M.Sc. Human genetics or M.Sc.
Biotechnology
or
M.Sc.
Biochemistry or M.Sc. Microbiology
or M.Sc. Genetics or Molecular
biology from a recognized University
7.
or Institute.
Desirable: Working Experience in
a recognized forensic science
laboratory
2. Basic computer knowledge as
prescribed by the government from
time to time.

-6-

<!-- page 7 -->

-7-

Ex-159/2026

3. A candidate must achieve a
minimum score in the qualifying
test of Mizo Language Proficiency as
prescribed by the government from
time to time.
JSO (Cyber Forensic)
1. M.Sc. (Cyber/Digital Forensics)
or
M.Sc.
Forensic
Science
(specialization in Digital or Cyber/
Multimedia Forensics) or B.Tech or
above in (Cyber or Digital Forensics)
or Master in Computer Applications
(MCA)/M.Sc IT or B.E. and above
in Computer Science from a
recognized University or Institute.
8.
Desirable: Working experience in
a recognized forensic science
laboratory.
2. Basic computer knowledge as
prescribed by the government from
time to time.
3. A candidate must achieve a
minimum score in the qualifying
test of Mizo Language Proficiency as
prescribed by the government from
time to time.
In case of recruitment
by promotion/deputation/
absorption, grade
from which promotion/
deputation/absorption
to be made
11
1.
2.
3.
4.
5.
6.
7.
8.

Not applicable

If Departmental
Promotion Committee exists,
what is its composition?

Circumstances in which
Mizoram Public Service
Commission is to be consulted
in making recruitment

12

13

As per Mizoram Public Service
Commission (Limitation of
Functions) Regulations, 1994 as
amended from time to time

As per Mizoram Public Service
Commission (Limitation of
Functions) Regulations, 1994 as
amended from time to time

Published and Issued by Controller, Printing & Stationery Department, Government of Mizoram
Printed at the Mizoram Government Press, Aizawl. C/60
