---
doc_id: "b12d2afb4f7abcb7"
source_url: "https://forest.mizoram.gov.in/uploads/attachments/2022/01/7be3562352aa9615c7aa692f735fcb84/pages-255-tender-for-pressure-cooker.pdf"
ministry: "Environment, Forests & Climate Change Department, Mizoram"
title: "Click here for attachment."
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "42887d88d7a8b7d4"
---

<!-- page 1 -->

GOVERNMENT OF MIZORAM
DEPARTMENT OF ENVIRONMENT, FORESTS & CLIMATE CHANGE
TUIKHUAHTLANG, MIZORAM : AIZAWL - 796001
No.B.20018/37/2020-CAMPA/PCCF
Dated Aizawl, the 8th January, 2022
SHORT QUOTATION NOTICE
Quotations of minimum price per unit of each item are hereby invited from interested
Companies/Firms/Dealers/Suppliers in prescribed form for supply of various office items under EF&CC
Department as per Annexure appended with items and specifications. The Quotations will be received at
PCCF Office, Tuikhuahtlang, Aizawl upto 2:00 pm of 27th January, 2022 and will be opened on the same
date immediately after closure of tender box. The quotationers or their representatives may be present at the
time of opening of the tender, if they so desire.
TERMS & CONDITIONS OF TENDER FOR SUPPLY OF PRESSURE COOKER
1. Tender should be submitted in Two Bid Envelope system mentioning Bidder‘s Name &
Address on both envelopes. The two envelopes should be superscripted “ Technical Bid” and
“Financial Bid” as the case may be. Both the envelopes are to be put in a separate large sealed envelope
superscripted as: “Supply of Pressure Cooker under CAMPA 2020-2021”
2. The Sealed Tender should be addressed to The Principal Chief Conservator of Forest,
Department of Environment, Forests & Climate Change, Govt. of Mizoram
3. Bids are invited for supply of Pressure Cooker of 3 litre & 5 litre capacities alongwith all the
accessories as per “Detailed Technical Specifications given in the Tender Form-I (attached as
enclosure)”
4. The Firm should be Authorized Dealer for sale of pressure cooker (supporting documents duly
attested by Gazetted officer to be attached).
5. Firms should have Minimum Experience of at least last 3 years of dealing with pressure cooker
(Attach proof of documents duly attested)
6. Firms should have Minimum Average Annual Sale of pressure cooker for reasonable amount during the
past 3 years (Attach proof of documents duly attested).
7. Firms should have Dealer Network capable of supplying the materials as a dealer & providing after
sales service & availability of spare parts in Mizoram.
8. Pressure cooker should be BIS Approved and has to be certified product under IS : 2347 of BIS
(Attach proof of BIS license duly attested). The pressure cooker should be made of stainless
steel.
9. Firms should submit Tax Clearance Certificate or Tax Return Submission
Year (2020-2021) (Attach proof of documents duly attested)

for the last Financial

10. Firms should submit GST Registration Certificate & Pan Card (Attach proof of documents duly
attested)
11. The “Technical Bid’ should be accompanied by Earnest Money / Bid Security (refundable) of
Rs.4,00,000/-(Fixed) in Form of Demand Draft or Fixed deposit in favour of Principal Chief
Conservator of Forests, Govt. of Mizoram

<!-- page 2 -->

12. Audited Financial Statements for the Year 2019-2020 & 2020-2021 to be submitted.
of documents duly attested)

(Attach

proof

13. Proposal must be accompanied by manufacturing company’s catalogue of Pressure Cooker of
& 5 litre with specification.

3 litre

14. Rates for each item should be quoted separately inclusive of all taxes and charges both in figure and in
words. Any bid with overwriting shall summarily be rejected.
15. The “Technical Bid” should be accompanied by samples of 4 (four) nos. each of 3 litre & 5 litre Pressure
Cookers. Submitted samples will be returned to the tenderers after completing the selection
formalities.
16. The selected tenderer(s) shall supply the item (s) at all the locations specified in the technical bid as per
the quantity quoted for.
17. Tenderers who do not qualify the technical bid and do not submit all the necessary documents shall not
be accepted for financial evaluation (Financial bid shall not be opened). Decision taken by Technical &
Financial evaluation committee in this regard shall be fixed and binding.
18. The Financial bid shall be evaluated based on the minimum total cost as per the financial bid by the
approved technical bidder.
19. Payment shall be made based on the verification of the quality and quantity as per the sample by the
respective Field Director/ DFOs/ DCFs where the supply has been made.
20. Information regarding litigation, exertions and blacklisting, if any shall be submitted with details by the
tenderer to be evaluated by the selection Committee.
21. In the event that any dispute or differences arise between two or more firms or agencies, the
Department will have no involvement whatsoever. However, in case of differences or dispute by a firm
or firms against the Department, the matter may be settled through mutual and amicable discussions.
Only if such differences cannot be resolved through dialogue, the matter may then be resolved through
the court of Law within the State of Mizoram only.
22. The undersigned reserves the right to accept or reject or cancel the tender fully or partly including
the lowest one without assigning any reason and also reserves t he right to
distribute the works to more than one supplier, if considered necessary. The department does not
bestow upon the successful tender the right for supply of any item(s).
23. Last date of submission of tender is fixed on or before the 27th January 2022 (Thursday) up to 2:00 PM
and will beopened on the same day immediately after 2:00 PM at PCCF’s Conference Hall.
24. The Tenderer or his representative may be present at the time of opening the tender if he/she desires.

Sd/- JITENDRA KUMAR
Principal Chief Conservator of Forests (HoD)
Environment, Forests & Climate Change Department
Mizoram : Aizawl

<!-- page 3 -->

2

Memo: No.B.2001 8t37 1il}2}-CAMPA/PCCF 13 s z- a sg
Copy to:-

Dated Aizawl,rfr. *gflanuary, 2022.

1. P.S. to Hon'ble Minister, Environment, Forests & Climate Change for kind information.

2. Director, I&PR for favour of information and necessary action. She is requested to publish the
enclosed form of Quotation Notice in 2 (two) local daily Newspapers of Aizawl for one day.

3. All DDOs under Environment, Forests & Climate Change Department, Goyt. of Mizoram for
wide circulation.

4. Notice Board of PCCF's Office.
5. Web Manager, EF & CC Depa(ment to upload the quotation notice on the website.
6. State Informatic Officer for favour of information and necessary action. He/She is requested to

publish the enclosed form of quotation on their website.
7. Guard File No.5-A

'74tlz
( PC LALTANP
)
Deputy Conservator of Forests (Hqrs)
Environment, Forests & Climate Change Department

Mizoram, Aizawl
0389-2323420

<!-- page 4 -->

To,
The Principal Chief Conservator of Forests,
Environment, Forests & Climate Change Department,
Government of Mizoram.

Subj: Quotation for ‘Open Competitive Bidding’ for supply of Pressure Cooker & Accessories under
CAMPA 2020-2021 vide No.B.20018/37/2020-CAMPA/PCCF Dt.12th January, 2022.
Sir/Madam,
I/We have carefully examined & read the ‘Open Competitive Bidding’ for supply of Pressure Cooker
and Accessories under CAMPA 2020-2021 & all other documents attached vide No.
B.20018/37/2020-CAMPA/PCCF, dated 12.1.2022. I/We hereby submit our application/proposal for
Submission for Supply of Pressure Cooker & Accessories under CAMPA 2020-2021/according to the
terms & conditions mentioned therein.
I/We certify that I/we have carefully read each and every terms and conditions and technical
specification,composition etc., given in this Tender Documents and understood the same and we
confirm our acceptance of the same.
I/We further certify that we have suppressed no facts in the application/proposal which could
debar me to participate into the Open Tender. If it is revealed after opening of the
application/proposal that any fact is suppressed by me, Tender authority shall have the right to
reject my application/proposal.
I/We hereby also declare that we are not blacklisted by any Department/Agency of Central or
State regarding quality compromise or any other reason connection with similar work & there is
no ongoing litigation with any Department/Agency of Central/State Government as on closing
date of Tender. If subsequently revealed the same after opening of Tender, concerned
application/proposal will be cancelled & other penalty to be decided by the Tendering Authority
will be imposed.

Yours faithfully,

Dated: ..................................

Signature…………………………………………..

Place: ............................

Name in Full………………………………….
Name of Firm…………………………………….
Address…………………………………………….

<!-- page 5 -->

TENDER FORM - I
"TECHNICAL BID"
SUBMISSION FOR SUPPLY OF PRESSURE COOKER & ACCESSORIES UNDER CAMPA 2020-2021
1. Name & Address of Manufacturer

:

2. Name & Address of Dealer

:

3. Contact No. & Email ID of Dealer

:

4. Experience Certificate of 5 years

:

5. Average Annual Sale of 3 years
6. Registration Certificate of Manufacturer

:

7. Tax Clearance Certificate/Tax Return SubMission (GSTR 3b Form) 2018-19 or later

:

8. GST Provisional ID of Manufacturer and Dealer :
9. Pan Card Copy (Both sides)

:

10. Earnest Money Deposit

:

11. Audited Financial Statement for last 2 yrs

:

12. Manufacturing Co. product brochure

:

13. BIS/ISO Certificate

:

14. Manufacturing Company's License

:

15. BIS License

:

16. Amount of Earnest Money (EMD)

:

17. Experience Enclosed

:

18. Three Years Financial Statement

:

19. Whether Samples submitted

:

20. Bank details of tenderer

:

Dated: ...........................

Signature........................................
Name in full...................................
Company Seal................................

<!-- page 6 -->

TENDER FORM - II
"FINANCIAL BID"
SUBMISSION FOR SUPPLY OF PRESSURE COOKER & ACCESSORIES UNDER CAMPA 2020-2021
i)

Name of Firm/Dealer

: ………………………………………….

ii)

Address

: ………………………………………….

iii)

Name of Manufacturer

: ………………………………………….

iv)

Manufacturer’s Address

: ………………………………………….

1. PRESSURE COOKER 3 Litre CAPACITY
Quoted Rates Inclusive
Sl.

Specification of 3 Litre

Destination alongwith

of all Taxes & Other

No.

Pressure Cooker

quantity to be supplied

Charges (such as
transportation etc.)

a) Aizawl (1650 nos.)
b) Khawzawl (630 nos.)
1

c) Lawngtlai (1200 nos.)
d) W. Phaileng (750 nos.)

2. PRESSURE COOKER 5 Litre CAPACITY
Quoted Rates Inclusive
Sl.

Specification of 3 Litre

Destination alongwith

of all Taxes & Other

No.

Pressure Cooker

quantity to be supplied

Charges (such as
transportation etc.)

a) Aizawl (1650 nos.)
b) Khawzawl (630 nos.)
1

c) Lawngtlai (1200 nos.)
d) W. Phaileng (750 nos.)
