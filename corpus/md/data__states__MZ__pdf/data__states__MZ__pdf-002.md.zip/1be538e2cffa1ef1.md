---
doc_id: "1be538e2cffa1ef1"
source_url: "https://excise.mizoram.gov.in/uploads/attachments/2023/03/9984752e9eeefbdb0fd9e625b01d852b/posts-328-transfer-order-annual-transfer-posting-dt-15th-march-2023.pdf"
ministry: "Excise and Narcotic Department, Mizoram"
title: "Transfer Order - Annual Transfer & Posting dt 15th March 2023"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0d0bb95dd46b5569"
---

<!-- page 1 -->

No. A.22015/1/2021-COMEX
GOVERNMENT OF MIZORAM
COMMISSIONERATE OF EXCISE & NARCOTICS
COMMISSIONERATE OF EXCISE & NARCOTICS BUILDING
OPPOSITE AIJAL CLUB, KHATLA, AIZAWL-796001, MIZORAM
...
Dated, Aizawl, the 15th March,2023.
OFFICE ORDER
In the interest of public service and on request the following Excise &
Narcotics personnel are hereby transferred and posted to the office as shown against
each of their names with immediate effect and until further order. No TA/DA and
Joining time shall be admissible in respect to transfer made on own request.
They should be released by their respective Controlling Officer within
10(ten) days from the date of issue of this order.
Sl.
No

Name & Designation

1.

Lallawmthanga, SIE&N

2.

Lallianzuala, SIE&N

3.

Jason Lalrinchhana, SIE&N

4.

C.Vanlalruati, SIE&N

5.

Zohmingliana Special Grade

6.

H.Roliana, Driver G-I

7.

H/C 153 M.Lalhuta

8.

C/402 Rosie Lalramtiami

9.

C/486 C.Lalngaihawma

10.

C/487 Laltluanchhuaki

11.

C/527 Lalthasangi

12.

C/582 T.C Lalremruati

Present place of
posting
Office of the Asst.
Commissioner of Excise &
Narcotics, Aizawl
Office of the Asst.
Commissioner of Excise &
Narcotics, Mamit
Office of the Asst.
Commissioner of Excise &
Narcotics, Mamit
Office of the Asst.
Commissioner of Excise &
Narcotics, Aizawl
Office of the Asst.
Commissioner of Excise &
Narcotics, Lunglei
Commissionerate of Excise
& Narcotics Anti Narcotics Squad
Office of the Asst.
Commissioner of Excise &
Narcotics, Lunglei
Office of the Asst.
Commissioner of Excise &
Narcotics, Lunglei
Office of the Asst.
Commissioner of Excise &
Narcotics, Siaha
Office of the Asst.
Commissioner of Excise &
Narcotics, Aizawl
Office of the Asst.
Commissioner of Excise &
Narcotics, Aizawl
Commissionerate of Excise
& Narcotics Anti Narcotics Squad

New Place of posting

Remark

Office of the Asst.
Commissioner of Excise
& Narcotics, Mamit
Office of the Asst.
Commissioner of Excise
& Narcotics, Aizawl
Commissionerate of
Excise & Narcotics Anti Narcotics Squad
Office of the Asst.
Commissioner of Excise
& Narcotics, Mamit
Prosecution Branch
Aizawl

Public
Interest

Office of the Asst.
Commissioner of Excise
& Narcotics, Lunglei
Commissionerate of
Excise & Narcotics Anti Narcotics Squad
Office of the Asst.
Commissioner of Excise
& Narcotics, Aizawl
Office of the Asst.
Commissioner of Excise
& Narcotics, Aizawl
Office of the Asst.
Commissioner of Excise
& Narcotics, Mamit
Office of the Asst.
Commissioner of Excise
& Narcotics, Mamit
Office of the Asst.
Commissioner of Excise
& Narcotics, Aizawl

Public
Interest

On
request
On
request
Public
Interest
On
request

Public
Interest
On
request
On
request
Public
Interest
Public
Interest
Public
Interest

<!-- page 2 -->

13.
14.

C/597 Christy Lalhmingmawii Office of the Asst.
C/609 Angeline Lalbiakdiki

Commissioner of Excise &
Narcotics, Mamit
Office of the Asst.
Commissioner of Excise &
Narcotics, Champhai

Commissionerate of
Excise & Narcotics Anti Narcotics Squad
Commissionerate of
Excise & Narcotics Anti Narcotics Squad

On
request
On
request

In respect of C/582 T.C Lalremruati she must join her new place of posting with
immediate effect.

Sd/-NGURCHUNGNUNGA SAILO
Commissioner of Excise & Narcotics
Mizoram: Aizawl
Memo No.A.22015/1/2021-COMEX:
Dated Aizawl, the 15 t h March,2023.
Copy to:1.
All Assistant Commissioners of Excise & Narcotics for information and
necessary action.
2.
All Personnel concerned.
3.
Personnel Service Book concerned.
4.
Computer Operator for uploading in departmental website.
5.
Guard File.

Commissioner of Excise & Narcotics
Mizoram : Aizawl
