---
doc_id: "5722ea0e4ee3badc"
source_url: "https://ahvety.mizoram.gov.in/uploads/attachments/2022/09/03a221e1e9cfb52ba61e865960013e61/open-tender.pdf"
ministry: "Animal Husbandry and Veterinary Department, Mizoram"
title: "Re-Tender No. 5 (ZDPS, Tanhril)"
date: ""
pages: 2
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "316710b400d74c3b"
---

<!-- page 1 -->

j Re-tender No. * 3 of AH&VETY (ZPDS TANHRIL)
i Date : 2nd September, 2022
NOTICE INVITING OPEN RE-TENDER
The Animal Husbandry and Veterinary Department, Government of Mizoram, invites
Open Re-tender in a Two Bid System (TECHNICAL & FINANCIAL BID IN TWO ENVELOPES)
from eligible and qualified Manufacturers or Authorized Distributors/Dealers for Supply,
Installation, Commissioning and to Provide Training at site for Egg Setters, Hatchers,
Hatchery accessories, R.O Water Filtration, Solar Power System and Trainings under the
Augmentation & Upgradation of INDBRO Hatchery farm, ZPDS Tanhril.
The Details are summarized as bellow-
a) Re-Tender No. : 5 of AH&VETY (ZPDS TANHRIL)
b) Tender Amount : Rs. 378.00 lakhs (Rs. 308.00 lakh + Rs. 70.00 lakhs)
(Rupees three crore Seventy Eight lakh) only
c) Purchaser : AH & Veterinary Department, Government of Mizoram, Aizawl
d) Scope of Tender : Supply, Installation, Commissioning of Hatcheries etc. Building
Marketing Infrastructures and Network, Providing Extension work.
e) Technical Specification and details of Equipments : Proforma of Bids enclosed
f) Web-page of Tender : www.ahvety.mizoram.gov.in
g) Location of Supplies : INDBRO HATCHERY FARM, ZPDS TANHRIL, AIZAWL MIZORAM
h) E.M.D : Demand Draft drawn in favour of Director, AH & Veterinary, Mizoram Aizawl,
payable at Aizawl to be placed in the Financial Bid envelope amounting to 2% of the
Total Bid Cost.
There cannot be any exemption of EMD to whoever or Parties taking part in the
Tender. ao oN
a AY | Page 2 of 11
Py f i
NS Soe /’ 4
ee

<!-- page 2 -->

" ry Pl
4 a
as
! . ol,
i) Cost of Tender : Rs. 2,500.00 (Rupees Two Thousand Five Hundred) only. at
or
1
j) Publication of Tender: Through Information & Public Relation Department, Govt. of i
Mizoram, www.ahvety.mizoram.gov.in and Notice Board of Directorate, AH&Vety.
¢
|
k) Last date of submission of Tender : To be delivered to Address below on or before
3° October 2022 upto 1:00 pm.
The Director, Animal Husbandry & Veterinary Department, Khatla,
Below Police Headquarter, Mizoram, Aizawl, Pin-796001
1) Date of Opening of Technical Bid : 3 October 2022 upto 1:00 pm |
\
m) Date of Opening of Financial Bid : 6t October 2022; 1:00 pm
Breet"
irector
Animal Husbandry & Veterinary Department
Govt. of Mizoram
Page 3 of 11
