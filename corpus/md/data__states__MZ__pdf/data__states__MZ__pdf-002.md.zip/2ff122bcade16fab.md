---
doc_id: "2ff122bcade16fab"
source_url: "https://horticulture.mizoram.gov.in/uploads/attachments/2022/06/148d214e215943ad40887810c152cf71/deo-bamboo-20220610-0001.pdf"
ministry: "Horticulture Department, Mizoram"
title: "Office Order-Engagement of Data Entry Operator under NBM(8.June,2022)"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bba0c2688122b7e9"
---

<!-- page 1 -->

Ph : 0389 -2314370
Email: dirhod J.:nizor aru@yahoo.in
Website;
hffps :/,4rorticulture.mizoram. gov.in

i

No.A. 1 202 2 t I |202L-DTE [HORT-NB1\O/A

GOVERNMENT OF MIZORAM
DIRECTORATE OF' HORTICULTURE
MTZORAM: AIZAWL
Dated Aizawl, the 8"'Iune,2022,

oFFrcE ORDER
On the recommendation of the Selection Committee and Notification vide
No.A.l2022lll2021-DTE(HORT-NBM132-35 dt. n.A4.2022 and Govemrnent
approval vide No.A-450181412019-HORT dt. 31 .05.2022 the follor.ving candidate(s)
are hereby recommended for engagement for the post of Data Entry Operator on
contract basis for a period of 1 (one) year under National Bamboo Mission with effect
from the date of joining as shown against their names. HeiShe should signed terms of
agreement at the time of joining at the place of posting. He/She rvil1 be given a fixed
rernuneration of Rs. 15,0001- per month which rvill be met from Project Managernent
under NBM.
The engagement on contractual basis shail not bestow upon his/her the light to
claim for regular appointment and ire/sire may be terminated fiom his&er selvice at
an,v point of time andlor for unsatisfactory performance and misconduct or
telmilation of the NIBM programme even before expiry of the contract perioci.
Father/ltlother

sl.
I{o.

Name & Address

i

Emmanuel Remruatsanga,
Zemabaivk

C. Lalthanpuii

2

Railngaihzuala,
Republic Vengthlang

Lalrammawia

Name

Contact No.

8$8A1s4s3l
936643244s
9862924534

Place of Posting
Bamboo Cel1.
Directorate of
Horliculture
Block Horticulture
Officer's Office,
Rawpuichhip

The Selection Committee furlher recommended the undermentioned
candidate(s) in the Panel List for filling the present vacancies only in the event of

declination of the other appointment or resignation or death at any of the
recommended candidate(s) u,ithin one year fi'om the date of declaration of the results.
st.
No.
1

2
a

J

Name
H. Vanlalthiamuana
Laltnuaitiuanga
R. Lalhmachhuana

Father/Mother Name
H. Lalremsanga
C. Lalremruata
L.T. Huama

Address
Chanmari West
.College Veng
Ramhlun Venglai

Sd/-Dr. ELIZABETH SAIPARI
Mission Director,
State Bamboo Mission, N{izoram,
National B arnboo Mission.

<!-- page 2 -->

Memo.No. A.l2022lll202l-DTE(HoRT-NBMyA
Copy to:-

: Dated Aizawl the 8th lune, 2022

1. P.S to Secretary, Horticulture Department for favour of information.
2. Jt. Director of Horticulture (B), Directorate of Horticulture for information.
3. Dy. Director of Horticulture(Admin), Directorate of Horticulture for information.
4. Project Officer(B), Directorate of Horticulture for information and necessary
action.
r,5f Dy. Director of Horliculture(E&T), Directorate of Hofiiculture for upload in the
Department website.
6. Superintendent, Directorate of Horticulture for information and necessary action.
7. Persons concemed for information and necessary action.
8. Office Order Book.

(L. LALHMING
PACIIUATI)
Jt. Director of liorticuiiure (B)
Directorate of Horticulture
ia'
-'i Aizawl, Mizolaln
t'-
