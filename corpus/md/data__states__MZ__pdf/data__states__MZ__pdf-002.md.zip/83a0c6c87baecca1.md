---
doc_id: "83a0c6c87baecca1"
source_url: "https://forest.mizoram.gov.in/uploads/attachments/2022/10/05b701adf4d677dddc2fb7616d856cca/posts-497-tender-extension-notice-disposal-of-obsolete-or-unservicable-electronics-dt-14102022.pdf"
ministry: "Environment, Forests & Climate Change Department, Mizoram"
title: "Tender Extension Notice - Disposal of Obsolete or unservicable electronics, dt 14.10.2022"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6d6f780d4b397831"
---

<!-- page 1 -->

1

1

/lf-wF,-.
Y.:.;i#i"AZdtt! 6.,

,:\rx,It fssl-l*tSoY

GOYCRNME+i+ OF MIZORAM

DEPARTMENTOFENYIRONMENT,FORESTS&CLIMATECHANGE
TUIKHUAHTLANG, MIZORAM : AIZAWL -796001 .K
No.D.1401

Dated Aizawl, the

11412022-PCCF(Gy

ll Octoher' 2022

TENDER EXTENSION NOTICE

Bids of maximum pdce per Lrnit are hereby invited fi'om eligible ancl ar-rthorized
and eiectronics as per Ruie 9
firms/agencies/pRo,s for disposai of obsolete/unserviceable electrical
Forests & Climate
(1) of tte E-Waste (Management) Rr,rles. 2016 uniler PCCF's Office, Environrnent,
Change Depafiment:

The proposed items ior disposal is listed belorv:

Item

Sl. No
1

2.

Qntv.

Air Conditioner
TV CRT

1

Printer
CPU set
Intercom box
Monitor
Fax
Heater
Intercom 1+1
Scamer

13

5

a

J

4
5

6
7
8.
9
10
11.

1

2

t2
5
a

J
1

4
1

1:00 pm of ]"
The Bids shail be received at PCCF Oflf-rce, Tuikhuahtlang. Aizarvl r'rpto
2:00 pm. f ire goods proposed for
December ,Z0ll(Thursclay) and r,villbe openecl on the same day at
pCCF's otfi.. during otfice hour for working out the book value by
ilisposal can be seery'inspeci.a ot
the bidders.

TERNIS AND COT\DITIONS OF BID
1

2

j

Bid should be superscribed on the cover as "BID FOR DISPOSAL OF E'LECTRONICS/
ELE,CTRICAL ITEMS" and addressecl to the Principal Chief conservator of
The price of the items quoted shouid be inclusive of all taxes and should
and in words.

Forests, Mizoram.

be written in figures

the bidder. should be deposited
i 0 % of the total value of the bid, calculated at the rate quoted by
money in the fonn of
bidder to any bank recognized by the Govt. of Mizoram as earnest

by the
of Forests, Nlizoram
cllposit at call dtrly pledgecl in the name of Principal Cfuief Conservator
ani the same should be submitted along with the bid'
4

and in \vords' Corection'
Rates per unit of each item should clearly be quoted both in figures
accepted'
if any, should be duly initialed r.vith clate n.v tfre bidder. No over writing shall be

Contd/-

<!-- page 2 -->

2

5. -fhe uridersigneci does not bincl hiniself to accept the higtLest bid and ma;- reject any bid without
where

r'vith the highest bidder
assignirrg any reason thereof. However. negotiations nlay be held
negotiations does not provide the desired
a reasonable amouni can be chalked ollt. I; case such
the next highest responsive
resrilt. the reasonable or acceptable price rnay be collnter offered to
hidder.

6. The Earnest Money deposit in respect oIthe unsuccessful bidder rvill be released after selection
is finalized.

7. Authorized pRO's/firms are requested to attaoh cerlificatc supporling the authorizatron'
g. Selectecl Firm must be ready to collect the materials rvithin the time as may be specified in the
orcier of disposal, failing rvhich the Eamest lvlonel- cleposit r,vi11

be forfeited to the Government

aiong rvith canceliation of the order'

g. In case the total quantity to be disposed of cannot be taken up b.v the highest acceptable bidder,
the remai,ing quantity may be oft-erect to the next higher bidder
highest bidder.

at the price offered by the

from the bidder. In case the selected
10. The goods shall be released after tirll pal"rnent is received
be forfeited'
bidder does not show interest in 1ifting the goods, the bid security should
11. The bidder or their representatir,e ma),be present at the
desire.

time of opening of the bid, if they so

Sd/. R.K. SINGH
Principal Chief Conservator of Forests (HoFF)
Enr,ironment, Forests & Climate Change Department

Mizoram : Aizalvl

Memo : No.D.L40L ll 4 12022-PCCF(G)/
Copy to:-

.^

Dated Aizaw'l, the lf

October, 2A22.

1. All DDOs under Environment, Forests & Climate Change Department, Govt. of lvlizoram
for lvide circulation.
2. State Intbrmatics Officer for favour of information and necessary action. He/She is

requestedtokindlypublishthebidinhis/herrvebsite.

3. Notice Board of PCCF's Ofhce'

y-*:--Web Manager, EF & CC Department to upload the bid on the deparlment's
5. Guard File No.5-A

r'vebsite'

itt
( PC LAL

Deputy Conscrr alor of Forests (Hqrs)
.Environment, Forests & Climate Change DePartment
t" Nlizcrarn, Aizar,vl
Ph.,-.lo : 038c) -2323420

<!-- page 3 -->

!3

& fleR.Fili":o It $1$31{}s:\ L
gr_ai:ELEE__{Aqiu$

To
The Principal Cltief Conservator of Forests,
Gor.t. of N{izoram. Aizalvi.
Sir,

ln response to ,\.cur notice inviting Bid tbr disposai of various electrical/electronics
(e-waste) issued vide Memo No',--

I

Dated

r1o hereby sr-rbmit m1. Bid in n prescribei-l fbrrn enclosed

as Annexrtre. My parlicrilars are as given

belolv:

1" l-ull narne of Bidder(in block letter):

2. Address
3. lvlobile No

:

4. Amount of Eamest N4one1''
Nc.

vide DCR/DD

deposited Rs.
Dt.

on

Qllame of Bank)

5. List of items and rates lbr which Bid is sublnittecl is enclosed at Amexure

Place

Yours faithfullY,

Date:
(Narne & Signature of the Bidder r'vith seal)

<!-- page 4 -->

Item

Sl. No

Qnry

1

Air Conditioner

i

2

TV CRT

1

-)

Copier

5

4

Printer

5

CPU set

2

6.

Intercom box

12

1

Monitor

)

8

Fax

J

9

Heater

1

10

Intercom (1+1)

4

11

Scanner

1

Quoted rate per piece

1a

IJ

a

GRAND TOTAL

Total arilsunt

<!-- page 5 -->

No.A. 1 1 0 12 12 12019-FST/40

GOVERNMENT OF MIZORAM
ENVIRONMENT, FORESTS & CLIMATE CHANGE DEPARTMENT

NOTIFI CATION
Dated Aizawl,the 4ft Oct,2022

In the interest of public service, the Governor of Mizoram is pleased to notiff
transfer of Champhai Forest Division from Central Circle and N.Vanlaiphai Forest
Division from Southern Circle to the Eastern Circle, Environment, Forests & Climate
Change Department with immediate effect.
This is issued with the approval of General Administration Deparhent vide
. I.D.No. GAD .7 7 I 2022(EF&C C) dated 29 .09 .2022.

Sd/- NAVIN KUMAR CHOUDHARY
Principal Secretary to the Govt. of Mizoram,
Environment, Forests & Climate Change Department

FST/40

Memo No.A.l 1012/2/2019Dated Aizawl,the 4tr oct,2022
Copy to :1. Secretary to the Governor, Mizoram.
2. Secretary to the Chief Minister, Mizoram.
3. P.S to the Minister, EF&CC Department, Mizoram.

4. Sr.P.P.S to the Chief Secretary, Govt. of Mizoram.
5. All Administrative Departments, Government of Mizoram.
6. All Heads of Departments, Government of Mizoram.
7. The Principal chief conservator of Forests, Mizoram.
8. Chief Wildlife Warden, EF&CC Department.
9. All Chief Conservators of Forest/Conservators of Forest, Mizoram.
10. Controller, Printing & Stationery Mizoram with 5 spare
copies for publication
in the Mizoram Gazette.
11'A1l Divisional Forest Officers / Deputy Conservators of
Plan officers / Principal, Forest Training School, Mizoram.

Forests / Working

d.w"a Manager, EF&cc Deptt. for uploading in the Department website.
13. Guard File.

\l"}.L

t

),O?k

(H.C.ZONLTNTHARA )
flflnder Secretary to the Govt. of Mizoram,
h,nvronment, I,orests & Climate Change Department
Ph :- (0389) 233sn7(A)
