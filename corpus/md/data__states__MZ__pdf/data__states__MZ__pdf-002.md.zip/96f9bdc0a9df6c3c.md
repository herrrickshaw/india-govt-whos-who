---
doc_id: "96f9bdc0a9df6c3c"
source_url: "https://dcma.mizoram.gov.in/uploads/attachments/2024/08/8a9917c292edfa2bbb3a19e810addc5c/ladcsalaries-allowance-and-pension-of-member-rules-2003.pdf"
ministry: "District Council Affairs Department, Mizoram"
title: "The LADC (Salaries, Allowance and Pension of Member) Rules 2003"
date: ""
pages: 20
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "71b800cbdee4733b"
---

<!-- page 1 -->

The Mizoram Gazette
EXTRA ORD!NARY

Published by Authority
RBGN. No, NE. 313 (MZ)
Vol. XXXII Aizaw, Friday, 13. 6. 2003, Jyaistha 23, S.E. 1925,
Issue No.

121

NOTIFICATION
No. A.
the 9th June, 2003. In
of paragraph 11 of
the Sixth26020/1/93-DCA,
Schedule to the Constitution of India, pursuance
the following Rules of Lai
Autonomous District Council which received the approval of the Governor of
Mizoram is hereby published for General
information.
THE LA0 AUTONOMOUS DISTRICT COUNOIL.

(Salaries, Allowances and Pension of Members) Rules, 2003. (vide
Governor
of Mizoram's approval dt. 20.5.2003).
P. Chakraborty,

Secretary to the Govt. oÉ Mizoram,
Dis1rict Council Affairs Department.,
THE LAIAUTONOMOUS DISTRICT COUNCIL
ALLOWANCES
AND PENSION OF MEMBERS)(SALARIES,.
RULES. 2003
A

RULES

to provide for the salaries, allowances and pension of
mem
bers of the Lai Autonomous District Council.
Be it enacted by the Lai
District Councii in the
fifty second year the Republic ofAutonomous
India as follows -

Short title 1. (1) These Rules may be called the Lai
Autonomnous District
aad commen
Council (Salaries, Allowances and pension
of Members)
cement
Rules, 2003.

<!-- page 2 -->

121/2003

2

(2)

It shall be deemcd to huve come into force with effect from
the 23rd May, 2001.

Definitions. 2.

In these Rules, unless thc context otherwise require
(a)

Comnittee" means a committee of the District Council;

(b) "day" means a period of twenty four hours beginning at

midnight;

(c) "District Council means District Council of the
mous District Council:

Lai Autono

(d) "amily" in rclation to a member mcans the wife or Husband
residing with him or

her as the case may be, and children

(including the legall yadopted children and step-children)
wholly dependent on such Member;
(c)

Torm neADS u form appended to the seCond schedule:
A

(t) "he" and its grammatical variation stand for both man and
WOman;

(g) "Member"
means a member of the Lai Autonomous District
Council and it does not include the. Chief Executive Member
Chairman, Excutive Memberzand Deputy Chairman, but in

cludes, for the purpose of pension including faily pension
only under Rules 12 and 14:;

(h) "period of residence on duty" means the period during a
member resides at place where a session of the District C:»un

cil or a sitting of a COmmittee is held or where any other
busincSs connccted with his duties ls such member transacted
Or for the purpose of attending such other business and

resides
includes, except in the case of member who ordinarily
Council or sit

at the place where a session of the District
ting of the committee is held or where.any other business
connected with his duties as such member is transacted;
pilo. of
(} n the # tase oi a sessiul o! th: District Council, a
immediatlv
such residence. not exceeding two daysperiod of such prcceding
residence
the commencement ot a session and a

succeediog the date on
not cxCecdng iWo dayS iinuedialeiy adjourned
sine die:

P

business,
(ii) In the case of a sitting of a committee or any other
im1mediately
a period of such residençe not Cxceeding one day
preceding the Ccommencement of the business of the committee
and other business and 'a period of such residence notthe exoee
husi
ding one day inmediately succeeding the conclusion of

A

which the District Council session is

ness of the comittee or other business;

<!-- page 3 -->

3

Ex--121/2003

(i) "Schedule'" means a schedule appended to this Rules;
()

"term of office" in relation to a member means the eriod be

ginning with the date when such mem ber takes his seat in the
District Council and ending with the date on which his seat

becomes Vacant;
(k) "usual place of residence in relation to a member means thG
place wbere the nember perSOnally resides within the Lài Au
ionomJus District.
Salaries of

3

Members

A member shall be pald a salary of ten thousand
mense mduring the whole of his term of office.

rupess per

A member shall be entitled to receive Daily Allowances of w)

Daiiy

allowances

hundred rupees for cach day of the journey perfurmed for atten

ding a session of the District Council or for meeting of a com
miltee and also for each day of Lhe priod of residence on duty.

Constituency 5. A mémber shall be paid a constituency allowances of Rs.2500,
per mensem, Family allowances of Rs. 3500/- per mensem and
Far1ly AI
entertainment allowances of Rs. 2000- per inensem.

Allowances,

lowances and

entertainment

allowances.

Residence,

6. A nenber shall be ontitled
and

etc.

without 4ly pay ncll lo lhc usc
maintenance of a furnished residence throughout his tern1

of office as a meniber and for a period of 15 days immediately

thereafer, and so long as such residence is not provided for,

he shall be entitled tO a residence which rental charges
shal!
be not more than Rs. 2500/- per nmensem: EXPLANATION:
For the purpose of these Rules "Maintenance" in relation tO a

residence includes

() Provision of tree suppy of electricity and Water;
(2) Provision o Telephone calls upio 2000 calls per month.
Furnishing of 7. A member who occupies own House shall be cntitled lo receivc

residence

a sum of

Rs.20,000/- in the first year

for furnishing and Rs.

3000/- annually for the subsequent vear of the term.
Personal
attendant

8

A member shall be entitled to the service of the one Grade-I V
staff as personal attendant of a fix pay of R. 3000/- per men
sem throughout his term of ofice, on co-terminus

Travelling
A liowance

9. (1)

basis.

There shall be paid (ravelling Allowance to each member in
respect of every journey performed by him th: purpJs? of
attending a session of the District Gouncil or a siuing to a
comnittee or for the purpose of any attending to any othet
business cOnnccted with. his duties as a member from his

<!-- page 4 -->

Ex

121;2003

usual place of residence to tho place where the seSsion

Or.

1he siting is to be held or the other business is to be tran
sacted and for the rciur:a jvurney from such place to his usue!

place of residence at the rate of two hundred rupees per diem.

(2) Where no Government nccommondation is available outside
the District, a imember on oftiial duty shall be entitled to re
embursement of accommoda tion charge of a single room in
a three star Hotel in addition to the daily Allowances sub
jcct to production of actual payment receipt.
(3) Nowithstanding anything contained in sub rule( 1) a mennber

who performs a journey on offiial dúty by road or by rail
way or by streaner or by air outside Mizoram shall bo
entitled to reinburse the actua fare of journey and daily

Allowance of Rs. 250/- per day.
Provided that a member shall be entitled to an
advançe of Travelling and daily allowance in respect of the

tour undertaken by him on oficial duties.

Special

10.

In tbe special circu:nstances specified in the first schedule, the

provisions of this rules shall apply subject to the provision of

p:ovision

the that schedule.

The

Procedure l1.

sic

f the ser: td schct': sha! pply in' respect of

Trav
air

Med
trea!

all claims for salaries and allowances.
Pension

12. (1) There shall be paid a pensin to any person who has served

for a period vf 'ive years or for any period shorter than five

years as a member of the Pawi/Lai Autonor,ous District Council.

() The amount of pension payable shall be as fcllows :

With efiect trom the date of commenceinent of this Ruies and
Subjec! to otier provisions of the Rulcs, ther: shall be

paid a

Gra

life-long pension of Rs. 4,000-(Rupees four thousand) per month

with an alnuual increment of Rs. 200/-(Rupees two hundred)
upto a maximum amouat of Rs. 6,600/KRupecs six thoutand
Six bundred) to every member for any period, wbether for five
years or less or

Death

gratuty

Family

more.

13. If a member dies during his/her teru of Ofice his, het spouse
living, his/her legal heir shall be paid a death gratuty 1 sum
of one Lakh rupees.

J4.

(1) When a sitting or former member dies his spoue or if he
had no surviving spouse a? the time of his death. tis other

family of the first preference, if any, shall be pad a family
the
pension of two thousand five hundred rupees subje to
Jimitation in sub-section (2).

bui

<!-- page 5 -->

Tx- 121I/2003

(2) The period for which such fanily pension shall be pyable
to the wid ow or widower,son or daughter
shall be as follows:

of a

member

(a) In the case of a widow or widower upto date of death
O1 re-nmarriage, which-eVer is carlier:

(b) In the cuse of a son, until he attains the age of 25
years.

(c) In the case of an unmarricd daughter until she attains
the age of

is earlier:

5 ycars or until she getS married, which ever

Provided that the family of such menber shall not be

entitlcd to any pension under this Act, if they are entitled

10 the similar benefit under any other Act or rules.

15. A member is entitled to travel by air on tour performing oficial

Travel by

duties within lndia.

air

Medical

16. A member apd tne members of his family shall be entitled free

of charge to accomodatinn in Hospital recognised by the Dis

treatment

trict Council and also to Medical Attendance Rules as amended

from time to time, applicable to first grade Officer of the Go
vernment of

Mizoram.

EXPLANATION- if a member has more than one wife resi

dipg with him, the benefit conferred by these Rules shall be
available only to such wife as may be nominated in this behalf
by the Member.
Grant of
loans for

17. (1) Subject
to such conditions and limitation as may be prescri
bed by Rules th ere may be paid to a Member

cOnsti uction or

purchase of

building and
advance for

purchase of a

notor vehicle

(a) a repayable loan for a sum of money not excecding
three lakhs rupees for construction of abuilding or purcha
Sing a House, and

(b) a repayable advance for a sum of money not exceediog
be

three lakhs rupees of the anticipated price,
less for purchase of a motor vehicle.

whichever

(2) on the applicaion for a building loan nember shail cacule
a deed in the form prescribed by Rules, undertaking to use
the loan for the purpose for which it is sanctioned, rende
ring himself/herself and such properiy as may be specified

in the deeds as security including the house purchased

built with the aid of the loan with interest due there on.

or

<!-- page 6 -->

Ex-121/2003

Provided that no loan for buildiog of the

shall
be sanctioned unless the plot of land on whichHouse
the house

to be built is exclusively owned and possessed by the mem
bers applying thereof and is frce fiom all encumbrances.

(3) On the application for advance for the purchase of a motor
vehicle, a nember shall execute a deed in a prescribed forn1
undertaking to use the advance for the purpose for which
it is sanctioncd rendering himself/her self and the motor ve
hicle to be purchased liable for the re-payment of the ad
vance with intercst due thereon

(4) (D

No transfer assignment or charge made or created after

execution of the deed under sub-Rule (2) or (93) under this
Rule in relation to the property specified therein or tho

house purchased or built with the aid of loan or advance
as the case may be, shall be valid against the Government/
Dist1ict Council unless it has been made or created with the
previous consent

of the

Government/District

Council

in

writing.
(2)

Where a member having obtaincd a loan or advancc

under clause (a) or (b) of Sub-rule () of this Rule, dies

while holding office as such, the anount of the loan or any
part thereof wich would have occured on the date of his/

ber death in accordance with the terms and conditions of
the grant of the loan or the advance alongwith interest
thereon shal! be written off with the sanction of the autho

rity as may be prescribed by the Govt/District Council

from time to time.

Repeal and 18. (). The Pawi Autonomous District (Salaries and Allowances'of
Saving
Members) Act, 1993 and all subsequent anendments thereof
are hereby repealcd.

(2) Notwithstanding such repeal, anything done or any action

taken under the Act so repealed shall, in so far as it is
not inconsistent with the provisio: of tie Rule, be le::ed
to have hen or taken !9der this Rule.

FIRST SCHEDULE

(See Rule-9)

Regulation 1. (1) Notwithstanding that a member has not taken his seat in
of payment of
the District Council to which he is elected or nominated,

Daily and

Travelling

115wances

he shall be entitled to receive travelling allowances for the
purpose of taking his scat in the District Counil.

<!-- page 7 -->

Ex--121/2003

(2) For abscnce or a period of two days or more durg a
session ot the district council or a sitting or uCommnitteo
for visiting uny lace in the afterno0n, his travelling or daily
allowances will be admissible.
EXPLANATION

Il a member comes buck on the second

day, whether ia the lorenoon or

in the afternoon his ab

sence shall be lrea'ed us being less thnn two days.

(3) The term "during a Session or a sittiug of a Commiltee
occuring in sub-para (2) of the First Schclule does not

include the porivd of two days immediately pcceding the

commucenent ol the bustaess aud one day immediately
succeeding the conclusion of business of the Conmitce.

(4) Travcllmg Allowances for return journey to the usual place
of residence shall be admissible to a member wio lves
the place of the session of the Disuict Council or a situng

of a Commitee during the continuance of such session or
siting within wo days afler the conclusion of business ol
the session or the sitting us the case nnay be, before finally
returning to his usual place of residence.

(5)

All cuse iegrding the admissibility of travelling allowances

to i mmber who arrives at the

placc where a session of

the District Council or a sitting of a committoe is held
without the knowledge of tihe postp :ement of the sesion
or sitting including case of such members who rrives atter

the session or sitting is adjourned suddenly, shall be deter

mined by the Chairman of the District Cöunci! having re
In case the mem:
ber has performed such jouraey at his own expenses, he

gard to the circunnstances of each case.
shall have to satisfy

Tor Lhe same as follows

"Certiticl

that I have not perlormed any part of the jouracy by

conveyance provided at the expenses of the DistrictCouncil."
(6) Where a m:mber is provided with free boarding and lod
ging at the expense of aay District Council, he shal! be
entit led to receive only one half of the daily allowances

admissible to him under Rule 4. If only boarding or lod

ging is provided he shalI be entitled to receive three-fourlh
of the daily all:wances admissible to him under that Rule.
SECOND SCHEDULE
(See Rule-1)

Procedural (1) Every Member shall, as soon as possible atter he is elected

Provision

declare in form 'A' appended to Second Schedule his usual
place of residence to the Secretary to the District Council
and any subsequent change in the usual place of residence
so
declared shall be ntilied n, he sad im tQ, he Se
relery fo the DistYit CouhÁ.

<!-- page 8 -->

EX-121/2003

(2)

1 Afembr who clins any travclling or
allowances
under this Rule shall s1pport his clain other
by a Certificate
in the following form namely :
"Certified that oTravelling Allowances in respect of thc
JOuney or lhe daily allowances
for the period
in this bill ihas bcn or
will be claimed from nentioned
any other
official source."

(3)

Wherc no pa1l of the journey is performed by a
convey
ance provided at the expense of the
District Council the
following Certificates shalI be furnished nam.ely
Certified that I bave not performed
any part of
jour
ney by conveyance provided at the expense of the
the Dig
trici CoWncil."

(4) Ordinarily, any non-Government dues out-standing
a
Member shall not be recovered from his salaris and agains!
Allowan
ces but
where such dues are not account of certain service
rendered to him in the course of his duties as a Member.
such as when he is on tour with a Cormmittee. and the
rrange ment for such Service h¡ve been made by or at the
instance of Semi-Government institution of private parttes
at the requ:si of Officer o! ihe District Coancil, and where
Such
member, in spite of repeated request had failed lo
make paynent of such 'ues. recovery thereof may be cffected
Iron the salarics or daily ailovances bills of such member

FORM A

My usual place of residence is
I have changed my usual place of residence from
due to

(here state the reason})

I may hencc-forward be allowed travelling allowances from

Signature

Constituency
Date

<!-- page 9 -->

Ex--121/2003

DEPARTURE AND RETURN JOURNEY CERTIFICATE

Theter
ifi_a mayt
Autonomous District Counil,
retuin journey

ed signed nd retutntd te the' fSeariaoy) Lai

Sood'As"pössiblb;'éuthelicóthlet(65 6f the

() Certified that I have not perlormed the journey under rule 9 of Lai Auto

nomous District (Salaries Allowances and Pension of Members) Rules, 2000,lea ving
(Plice on the
-Date) arrive al

-(Place) oa the
-Date)

(2) Certified that I have not performed any part of jouraey other thau the

jeurney by a cnveyance provided at the expense of the District Council.

Certified th¡t. t.49tyjly travelled by air from
by

--(Place)

uuo9iHituontontsttT

P.yment of the supplenentary bills is required at

-Place)
-day/night service

Station
DATE THE

(Strike ou if not applicable)
MEMBER

Lai Autonumous DËjtfit'Council,
Constituency
STATEMENT OF OBJECTS AND REASONS

The Salaries and Allowances of Me mbers under the provisiou of the La:

Autonomous District ( Salaries and Allowaazes of Members) Act, 1993 are con
sidered in-adequate to meet the present demand in view of the rapid increase of
the
price index. It is, therefore, felt necessary to increase the salaries, allowan
ces and other facilities and privileges of the Members of the District Counc1l.
This bill seeks to repeal the aforesaid Act.
Hence this Bill

Maneh nunga Chinzah,
Chief Exccutive M: mber,
"Lai Autonomous:D%rnc: Council,

<!-- page 10 -->

Ex-12i/2003
CERTIFICATE OF AUTHENTICATION

Certified that, this B|l ws passed by the Lai Autonomous District Council

on 7.8.2001 And in authentication whereof I pit my signature on this 22nd
Day of April, 2002 Anno Domini.

T. Ngùnsanga,
Deputy Chairman,
Lai Autonomous District Counoil,
Lawngtlai.
A_sented the Rules on this

3rd day of May, 2001.

(A.R. KOHLI)

Governor
Mizoran

Mizoram
Published and Issued by the Controller, Printing & Stationery,
C-700
Printed at tho Mizoram Government Press, Aizawl

<!-- page 11 -->

TheMizoram
Gazeite
EXTRA ORDiNARY
Dublisled by huthorits
Rs. 2/- per issUe

Regn No NE-313(MZ) 2006-2008
Thursdav 29.1.2009

Magha 9.

S.E. 1930.

Issue No. 28

NOTIFICATION

No, A. 26920/1/93-DCA, the Ist December, 2008. In pursuance of paragraph ll of the Sixth
hedukc io thc (onstitio of lndia. thc following Amiendmcnt Rules made by LaiAuionomOI:s

D:iric:

uncii ard as approved bv the Governor of

Mizoran is hereby published fur genera!

intormaticn. nan:el::

The Lai Auinonous Disrict Council (Salaries. Allowances and Pension of Members)
(Anendnent) Pu! s. 3006. |vide Governor of Mizoram's approva! dt l0.9.2008

C. Chalsawithanga,
Under Secretary to the Govt. of Mizoram.

District Council.A ffairs Department.

<!-- page 12 -->

:-28/2009

THE LAIAUTONOMOUS DISTRICTOUNCIL

(SALARIES. ALLOWANCES AND PENSION OF MEMBERS)
(AMENDMEN) RULES, 2006

lo further ånend the Lai.\utunomous District Council (Sal ies. Allowances and Pen ion

,inhers Rules. 2003 herei:attci called the Principal Kuie" io provide for the Salaris,
wances nd Pensionof Me nners of the L.ai Autonomou, Distr ct Council in Mizoram

li roreby enacted by the LaiAutonomo:s Disrict Council in the fifty seven yers of the

Republic

Indiaas follows :

Shori ule and

1.

()

These rules nav be called the LLai Autonomous Distric1 Council

(Salaries. Allowances and Pension of Members)(Amendm:n)
Ruies. 2006.

(2) They shal! be deemed 1o have cone into force with retiospectiv:

effect from |" April, 2005.
!n the Principa! rules. for sub rule (2) ofRule !2. the fol!owing

shallbe substituted. namely

The anount of pension payable shail be as follows :
thousand five
(a There shali be paid ks. 4.500/- (Rupees four
hundred) only per month toa Member who had been elecied
nominated once for 5 (five) years or for any period shorter than
(|)

3(five) vears.

(b)

(c)

(2).
(a)
(b)

There shall he paid Rs. 6.000- (Rupces Six thousand) onlv per

month 10 a Member who had been clected thrce terms or morc

bcfore he connmencement of these rules.
commencemeni
Whereany personhas been re-elected after the

the
of these rules for another term, whether he has completed
one
of
pension
term or not, he shall be entitled to an additional
thousand fivc hundred rupees.

annually ai
The pension shall oe increased by i (live) perccnt
Simple rate.
exXcecd len
In no case shal! the pension paanle to

Member

thousand rups
3.
(a)

(2) of Ruke 12:
Where any person entitled t» pension under sub rule Presiden! of
Iselected to the Office of the President or Vice
Indiaor is appointed to the Office of the Govcrior

or the Administrator of any Territory:
Or.

cf:ny State

<!-- page 13 -->

-3

Ex-28/2009

(b)

Becomes a Member of an AukoonoUs District Council:

(c)

is cmploved on a salary under lhe: cntal Government or any
Stute Government or anv Cporat oh owned or controlled ny
the Central Government or y Sta' Government ofary Local
Authoritv or becomes othei wisc eititled 10 any rcmuneraio:
tiom such Governnent. copoaln o Local authority

Such person shai! not be entitled to pension un.ler

sub-Rule (2) of rule 12 for the pcriod during which he coiiES
to holdsuch officc or as such Meniber, or is so cmployed. or
continues to be to holdsuch office or as such Meniber. or is so

employed. or continucs to be cntitled to such remuneration.
Provided tha: wiere the selary payable to such erson
for holding such office or being such member or so employed.

or where the remunerativn referrcd lo the clause (c) payable
o such person is. in cithe: case. is lcss than the person payable
to him under sub ruie (2) ofruie i2. sacih person shall be eniitled

only toreceive the balance as peSion under that sub rule.
(4)

Where any person cntiled to pension under sub rule (2) of rule
12 is also entitled to any other pension. such person shall be

entitled to receive pension under sub rule (2) of rule 12 in addition
tosuch pension.

Provided that if any doubt arises as to the interprctation

of ay of the provision of these Rules, the decision of the
Autonomous District Council Chairman shall be final.

CERTIFICATEOF AUTHENTICITY

Certified that the Bill was passed by the Lai Autononous
District Council in its Session and in authentication thereof, i

put my signature on this seventh day of November 2008. Anno
Domini.

Manghmunga Chinzah,
Chaiman.

Lai Autonomous District Council.

Lawngtlai, Mizoram.
Published and issued by Controller, Printing &Stationery Department, Government of Mizoram

Printed at the Mizoram Government Press, Aizawl. CI700

<!-- page 14 -->

EXECUTIVE

Department. of
Mizoram,

&

of

ALLOWANCES
OF

OF

ORDINARY
EXTRA

Published
Authority
by
Friday

Mizoram
GazetteThe
Aizawl,

XLII

27009/1973RNINo.
VOL-

Sixth

21.3.2014 Lai of
Autonomous
paragraph

the
published on

by

of In
passed
Mizoram
pursuance
is
hereby

Rules

dt.
Governor
28.7.2014
2014.

423

2006-2008
No.

Issue

S.E. No.
NE-313(MZ)
1936,

31,Regn.

Sravana
Postal

22.8.2014
NOTIFICATION
the

August,
Amendment

FIN(E) His of
ExcellencyIndia, the
313/2014
the 4

I.D.
No.

the
vide
Constitution
approval

for
and
general
vetted
CHAIRMAN,
District 11
TO
MEMBER)
information, by of
the
CHIEF
Council
Finance

PENSION

AND

COUNCIL

MEMBER/ADVISER
CHAIRMAN/VICE
(SALARIES

Council
Singthanga,
to P.
the
AffairsGovt.

District
Secretary

LEADER/MEMBER

DISTRICT

MEMBER/EXECUTIVE

MEMBER/CHAIRMAN/DEPUTY

AUTONOMOUS

LAI

received
EXECUTIVE
CHIEF"THE 26020/1/2009-DCA,
(PLANNING)/OPPOSITION
(AMENDMENT)
RULES,
2012".
to

namely
: which
ScheduleNo.A.
Department

<!-- page 15 -->

3.-

2.

4.

3.

S.

4

daily

of
Rules

Rule

(2)

further
Rules,

THE

SALARIES, (

SECOND ( LAI
to ALLOWANCES
as AUTONOMOUS
the
District
Principal AMENDMENT

Lai
Autonomous

()1.

the
by Lai
tAutonomous
hereferred

:

enacted

as
follows Be 2003 to
it amend
(hereinafter

Amendment Commencement. Short
title
and India

of

of

Amendment

of
1#

of

be
five shall In area
Councilfigure
allowancessubstituted.
It
2012.
? InApril,
2012. shallRules,
In "Salary
(Salaries,These
Rule
10,000/Rule
Rule
hundred)per be
per
"daily
S
be Rules District
paid
area,
4
of 3 deemed to
Council RULES
of day"
of
of
Allowances
(Ten
* the
of
allowances
athe shall
t
h
e
A AND
may
and
40,000/-principal
Rules).
Constituency
Principal
thousand)
Council
Principal
200/DISTRICT
mensem,
family substituted.be
(Salaries,
be
750/-(
PENSION
have
andcalled
)
(two
(Forty
RULES,
of
Rules,
Rules,
in
rupees
Rules,
come pension
sevenhundred)
the
the
allowances
Allowances
S00/thousand)
for
Sixty
COUNCIL
Lai
into
per for
hundred
f
o
r
of
(
2012 OF
t
h
e
allowances
the
five
Autonomous
Third
forceMembers
for the mensem,"words
words
MEMBER
of
hundred)day,"
rupees
and
words
each
t
e
fifty)
with
year
and
Pension
)
2500 and
(Second
t
h
e
of
per figure,
effect
of
figure" a outsidewithin and
District
words
)
the
3,500/- (two
figure, mensem'"
of
from
Republic Members)
the thewordsand
thousand
and " Amendment)
Salary
member District
Council
District
" shallfigure
(three
the

Rule

Amendment
Ex-423/2014

4

<!-- page 16 -->

(c)

(b)

(2)

of

(1)8.

9.

Rule

Amendment

Rule

Amendment

7.

8.

of
Rule

Amendment

6.

7.

of

(2)

(1) 5.

6.

of
Rule

Amendment

a

follows as
. Inarea"
Districtthe
"(a)
*750/figure, In
Intime" rate pay In
timecalls
to
receive and a Intime,"
"and
The
(two In
64,000/-(four
per
Entertainment
furnishing
thousand),
memberthousand
of
sum Rule Provision
subsub-rule Rupees," Rule
Rule
fixed
Rul
e
mensem"
shall
of
interest
simple
rate."
The hashethe
shall
Where term perThere formonthThere
shall (2)whole thousand
2,000/additional
3,000/rule (seven *
of 7
9
a
8
shall
commencement mensem 5(five)
250/6
shall five
the of 3,000/pension
be
or
be
be by of and sum20,000/of
of
(3)Council
(
2
)
word
shall
shall
of
to
t
h
e
t
h
e
t
h
e
completed
a
fixed
more
be
substituted.
(two
wordssubstituted. the of?30,000/-(three the
shall Family hundred)
be
free
allowances
a
ofhundred (two of Principal
15,C00/Principal
five
Principal
years
substituted
pension person
Principal
State
(three
thousand)
member be
Rule
be
appearing
paid
shall
by
Rulel2
before to
area" and
Supply
be thousand)
(twenty
hundred)
paid
thousand)
paid
hundred
a or
the
allowances a
under
substituted.
9 figure Government
fifty)
thousand), (fifteen
Constituency
per
beofthe of mernber
of
f
o
r
Chaiman
of
shall
Rules,
Rules
Ruies,
the
Rules,
who
? the
of
increased termnthese 22,000/of
t
h
e
by
thousand)
any20,000/mensem
EXPLANATION
per
clause
(thirty
"*
per
perfifry)
3,000/{
commencement
Water the
thousand)
per
be
annually,"
Principal
Principa!
had
f
o
r
(1
1,500
or
for
who period
the
mensem,"
day substituted. 500 ),
mensem"
rules
of
following
"
per
mensem," the
in
as
not,
t
h
e
for
t
h
e
(b)
been
thousaad)
and
words
by
(Fve
(three
allowances and
outside
the
(twenty (twenty
had
in
words
(one3,000
shorter
day,"
maywordswords
che
annually'
"
hefor has
t
h
e
Rules
Electricity,
Ru
form
elected/nominated
Entertainment
t
h
e
shall
been
5%
another
Hundred
be
words,
thousand).shall been
and
the
thousand
first
les,
and
t
h
e
t
h
e
words,
t
h
e
of two than
words
(three
revised
of
and
thousand)
be
shall
with
in figure,
words
elected
Onof
five) ( re-elected
year
Ofice
be these
words for
words
District
figure,
shall
substituted.
t
h
e
thousand)
figure,
term,
5{
namely:
entitled
the Rupees) Iivc
thousand),
*3,000/be
its
free
skilled
first and for
five
be
andEx-423/2014
from
annually
five) substituted
rules.
Order
Clauses
words
and
f
o
r
substituted.
and
figure
allowances
to
Telephone
whether
furnishing
only
Hundred
Counci!
hundred)
figure
timelabour a" year receive
to after three onByyears. once
2,500/
within
figure
figure
fixed
(three
and
from
per
"
at an
for to
and
(1)
to

(d)

9.

of

12.-

Rule

Amendment

<!-- page 17 -->

Mizoram

C150
Govemment

Aizd.

of

Department,

Press,

Stuonery

Government

Printng

Mzoram

&

by

Controller,
utthe

Printed

and
lssued

Published

(2)

of

10.

13.-

Rule

be
lakh
as five for
atsubstituted.
t
h
e
hundredy
follkows
a
Rupees"
simple
words

In the and In the In
subsubRule
wordsfigure, words
rule
rule
13
a
n
d
" of
"a
(1)
pens
family (1) Five the
figure{10,000/of
ofPrincipal
the
ion
Lakhs
t
h
e
shall Rule pension Rule
Rupees"
be 14
of 14 Rules,
increased new a
of
2,500/(ten the shall for
clause
thousand'"Principal
bethe
(two
by
words,
shall
substituted.
thousand
59%
be
Rules,
"One
(five) added shall

annually."
interest The
Family

"(3)

11.
(1)

14.-

Rule

of

Amendment Amendment
Ex423/2014

-6

<!-- page 18 -->

The Mizoram Gazette
EXTRAORDINARY

Published by Authority
RNINo. 27009/1973
VOL- LIII

25.
Aizawl, Wednesday 14.2.2024 Magha

S.E. 1945,

Issue No. 97

NOTIFICATION
11 of the Sixth
13th February, 2024. In pursuance of paragraphDistrict
Council
No, A. 26020/1/2006-DC&MA(L), the following
Rules passed by the Lai Autonomous
Schedule to the Constitution of India, the
to take effect from 1" April, 2023 is hereby
which received approval of the Governor of Mizoram
published for general information, namely :
COUNCIL (SALARIES, ALLOWANCES
«THE LAI AUTONOMOUS DISTRICT
AMENDMENT) RULES, 2023."
AND PENSION OF MEMBERS) (THIRD

Dr. H. Lalthlangliana,
Secretary to the Govt. of Mizoram,

District Council & Minority Affairs Dept.
THE LAI AUTONOMOUS DISTRICT COUNCIL
(SALARIES, ALLOWANCES AND PENSION OF MEMBER)

(THIRD AMENDMENT) RULES, 2023

Further to amend the Lai Autonomous District Council (Salaries, Allowances and

Pension of Member)

Rules,2003 (hereinafter referred to as the Principal Rules).

Be it enacted by the Lai Autonomous District Council in the Seventy First year of the Republic of India
as follows:
1.

Short title and Commencement

These Rules may be called the Lai Autonomous District Council (Salaries, Allowances and

(1)
2.

Pension of Member (Third Amendment) Rules, 2023.

It shall be deemed to have comne into force with effect from the 1s day of April, 2023.

Amendment of Rule 2

In sub-rule (g) of Rule2 of the Principal Rules, after the words, "Executive Member" the words
"Leader of the Opposition" shall be inserted.

<!-- page 19 -->

-2 -

Ex-97/2024

Rs. 40,000 (Forty
figure, Salary of
and
words
the
for
n
Rules,
Principal
In Rule 3 of the
Rs. 80,000 (Eighty Thousand)
of
"Salary
figure
and
word
Thousand) per mensem" the
mensem, "shall be substituted.
Amendment of Rule 3

3.

Allowances of Rs. 500 (Five
Daily
figure,
and
words
the
for
outside the Districs
In Rule 4 of the Principal Rules,
Rs. 750(Seven Hundred Fifty)
and
Area
Council
District
the
Hundred) within
Allowances of Rs. 1,000(One Thousand)
"Daily
figure,
and
words
the
be substituted
Council Area per day,"
Thousand) outside Mizoram per day, " shall
(Two
2,000
Rs.
and
Mizoram
within
Amendment of Rule 4

4.

5.

6.

Amendment of Rule 5

substituted as follows, namely:
Rule 5 of the Principal Rules shall beAllowances and Contingency Allowances: "Constituency Allowances, Family
mensem
Allowances of Rs. 20,000 (Twenty Thousand) per
"Amember shallbe paid a Constituency Thousand) per mensem and Contingency Allowances of
Family Allowances of Rs. 7,000 (Seven
Rs. 13,000 (Thirteen Thousand) per mensem.
Amendment of Rule 6
(a)

and figures, "Rs. 4,000 (Four Thousand) per
words
the
for
Rules,
Principal
the
of
6
Rule
In
Thousand) per mensem" shallbe substituted.

mensem" the words and figures, Rs. 8,000 (Eight

Amendment of Rule 7

7.

figure, "to receive a sum of Rs. 30,000 (Thirty
and
words
the
for
Rules,
Principal
the
of
7
Rule
In
15,000 (Fifteen Thousand) annually" the word
Thousand) in the First year for furnishing and Rs.
(One Lakh) in the first year for furnishing and
and figure, "to receive a sum of Rs. 1,00,000
substituted.
Rs. 40,000 (Forty Thousand) annually, " shall be

8.

Amendment of Rule 9

(a)
(b)

9.

500 (Five
1,000
"Rs.
and figure,
Hundred). within the District Council Area," the words, brackets
(One Thousand) within Mizoram," shall be substituted.
words, brackets and figure," Rs.
In sub - rule (3) of Rule 9 of the Principal Rules, for the
Area," the words, brackets and
750 (Seven Hundred Fifty) outside the District Council
figure,"Rs. 2,000(Two Thousand) outside Mizoram," shall be substituted.
In sub-rule (1)of Rule 9 of the Principal Rules,

for the words and figure, Rs.

Amendment of Rule 12

(1)

Sub-rule (2) of Rule 12 of the Principal Rules shall be substituted as follows:
member who had
(a) "There shall be paid Rs. 40,000 (Forty thousand) only per month to a

been elected/ nominated once for 5 (five) years or for any period shorter than 5(ive)

years.

(b)

If a member had been elected/nominated two terms or more. a sum of Rs. b,000

(Five Thousand) per term shall be added to the initial pension of Rs. 40,000 irrespective
of the number of terms a member is elected/nominated.

(c)
(d)

The maximum amountof Pension shall not exceed Rs. 70,000 (Seventy Thousand).

The pension shall increase by 5%-five) annually at simple interest rate.

<!-- page 20 -->

-3

(e)

(

10.

Ex-97/2024

mensem
There shall bepaid amedical assistance of Rs. 2,000(Two Thousand) only per
to cach former

member"

Rules, the following clause shal
Afer clause (b) of sub-rule (3) of Rule 12 of the Principal
be inserted, namely: Assembly or a Member of Parliament.
"c) Becomes a member of the Legislative

Amendment of Rule 14
I.

Rule shall be substituted as:
Sub-rule (1) of Rule 14 of the Principal
spouse or if he/she had no surviving
uWhen a sitting or former member dies, his/her
(1)
of the first preference, if any shall be
spouse at the time of hisdeath, his otherfamily
pension received by the Ex-MDC or if a
naid a Family Pension of 50% of the last
have been received by him/her
sitting MDCdies, 50% of the pension

II.

that would

Rule 14 of the Principal Rules, the
For clause (c) of sub-rule 2 of

following clause shall be

substituted, namely: gets married
widowed or divorced daughter, until she
or
unmarried
an
of
case
the
(c) In
death, whichever is earlier.
of remarried or until her
clause shall be
the Principal Rules, a new
of
14
Rule
of
2
sub-rule
IIL. After clause (c) of
disabilityof
inserted, namely:
suffering from any disorder or
is
who
daughter
or
son
disabled so as to
(d) Inthe case of a
or is physically crippled or
retarded
mentally
the
including
mind
living, until his/her death."
render him/her unable to earn a

Published and Issued by Controller, Printing &Stationery Department, Government of Mizoram
Printed at the Mizoram Government Press, Aizawl. C/130
