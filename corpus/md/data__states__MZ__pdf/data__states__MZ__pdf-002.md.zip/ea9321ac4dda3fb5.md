---
doc_id: "ea9321ac4dda3fb5"
source_url: "https://dmr.mizoram.gov.in/uploads/attachments/097ce888dcf8911303c5e3717ec722a0/17052020-lockdown-order-40-english.PDF"
ministry: "Disaster management and Rehabilitation Department, Mizoram"
title: "Lockdown Order 4.0 (English)"
date: ""
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5b96a8c2b7e456a0"
---

<!-- page 1 -->

No.B. L3O2U 1O1 l2O2O-DMR/Pt-UI
GOVERNMENT OF MIZORAM
DISASTER MANAGEMENT & REHABILITATION DEPARTMENT

***

Aizaurl, the lTth of May, 2O2O

ORDER
Whereas, a nationwide restriction on movement and activities
was implemented from 00:00 hrs of 25.03.2020, in pursuance of the
Order of the National Executive Committee conveyed vide Ministry of
Home Affairs, Govt. of India Order No.4O-3 l2O2O-DM-I(A) dt.
24.03.2020;
And whereas, the Ministry of Home Affairs, under directions of
the National Disaster Management Authority, has extended the
lockdown till 03.05.2020 to contain the spread of COVID-I9 vide
Order No.40-3 I 2O20-DM-I(A) dt. 14.O4.2O2O;

And whereas, the Ministry of Home Affairs, under further
directions of the National Disaster Management Authority, has further
extended the nationwide lockdown for a period of two weeks tilI
17.05.2O2O, to contain the spread of COVID-19 based on classification
of districts into different zones vide Order No.4O-3 l2O2O-DM-I(A) dt.
01.05 .2020;
And whereas, in view of the trajectory of the outbreak in other
parts of the country and the return of stranded residents of Mtzorarn
from containment zones of other States, it is felt necessary to extend
the lockdown till 31.05 .2O2O in order to prevent the spread of the
disease in Mtzoram;

Now therefore, the undersigned, in his capacity as the

Chairman, State Executive Committee, and in exercise of the power
conferred by section 22(2)(h) & 24(Il of the Disaster Management Act,
2005 hereby orders that the lockdown will continue to be imposed till
31.05.2020, and measures for implementation of lockdown appended
hereto shall be in force from 18.05.2o2o till 31.05.2o2O.

sd/- LALNUNMAWTA CHUAUNGO
Chief Secretffiy, Mtzorarn & Chairman,
State Executive Committee
State Disaster Management Authority, Mizorarrr

<!-- page 2 -->

Memo No.B.L3O?L| LOL|2O2O-DMR/Pt-II : Aizawl, the LZth of Mayr 2O2O
Copy to:
1. Secretary to the Governor, Mizorarn.
2. P.S. to Chief Minister, Mizoram for information.
3. P.S. to Deputy Chief Minister, Mizoram
4. P.S. to Speaker, Mizoram

5. P.S. to all Ministers/ Ministers of State/Deputy Speaker/

vice-chairman/Deputy Govt. chief whip, Mizoram.
6. Home Secretry, Government of India, North Block, New
Delhi- 1 10001.
sr. P.P.s to chief secretar5r, Govt. of Mizorarn.

.
B. P.S. to AddI. Chief Secretffiy to Chief Minister, Govt. of
7

MLzotarrL.
9

. All Principal Secretaries/ Commissioner/ Secretaries/ Special

Secretaries, Govt. of Mizorarn.
1 0. Director General of Polic e, Mtzorarn.
1 1 . Commissioner & Secret W, Mtzorarn Legislative Assembly.

L2. All Administrative Heads of Departments, Government of
Mizoram.
13. Secretary of all Constitutional & Statutory Bodies , Mizoram.
L4. A11 Head of Departments, Government of Mizorarn.
15. All Deputy Commissioners, Mizorarn.
L6. A11 Superintendent of Police, Mtzoram.
17 , Superintendent of Police, Traffic , AizawI.
18. Director, I&PR for wide publicity.
19. Controller, Printing & Stationery with S(five) spare copies for
publication in the Mizoram Gazette.
20. Guard File.

Under Secret ary to the Govt. of Mizorarn
Disaster Management & Rehabilitation Department.

<!-- page 3 -->

ENGLISH VERSION

No.B. 13O21 I O1 ^n?O-DMR pt-III
LOCKDOWN MEASURES TO BE ADOPTED IN MIZORAM FROM
1Q.O5.2O2O to 31.O5.2O2O

The lockdown guidelines given below shall supersede the previous
lockdown measures lssued vide order No. B.13o2l l].olt2o2o-DMR/pt-

III dated o2.o5.2o2o and shall be effective from t8.os.2o2o tilt
31.O5.2020.

A. Inter-State and International Borders
1.The International borders shall remain closed.
2.All Inter-State borders which have been closed shall remain closed.

3'Entry points at Bairabi, Vairengte and Kanhmun shal be open for
movement of vehicles carrying essential commodities and nonessential commodities permitted by Home Department. However,
plying of commercial or private passenger vehicles which have not
been issued necessary permits by Home Department is strictly

prohibited.
4.International and Inter-state borders shall remain stricfly guarded.

B. Quarantine And Screening of persons entering Mizoram

LEntry into Mizoram without prior permission of the Government is

strictly prohibited.
2. All persons permitted to enter the State shall continue to be
ttroroughly screened at the screening points. Such person(s) shall be
quarantined for a period of 14 days or for a period prescribed by the
Government. The procedure for return and quarantine of residents of
Mizoram stranded outside the State shall be done as per the
"standard Procedure for Return of permanent Residents of Mizoram
stranded outside the State due to Covid-19 Lockdown,,.
3.All persons quarantined shall be registered on the mcovid,-L9 and"
Aarogga Setu mobile application.
4. Drivers and handymen of transport vehicles based in Mizoratn
engaged in procuring goods from outside the State shall operate only
from designated Quarantine facilities. They shall be allowed to leave
such quarantine facilities only after completion of 14 (fourteen) days
quarantine counting from the date of their last trip outside the state.
During their time in Quarantine they shall not meet familv members
nor mingle with the public.

<!-- page 4 -->

ENGLISH VERSION

5. Drivers and handymen engaged

in transportation of goods who are

based outside the state shall continue the practice of cooking their

food on the road side in the outskirts of towns. They shall not be
allowed to mingle with the general population and shall depart as soon
as unloading of goods is completed.
6. Drivers and Handyrnen of oil tankers owned by Mizoram petroleum
Dealer Association (AMPEDA) and Mizoram Tanker Association
(MTDA) who are residents of Mizoram shall operate from designated
locations at Vairengte. They shall return to such designated locations
immediately after they complete the delivery to tl.e filling stations.
7.Such drivers and handymen mentioned above may call the State
control Room (Toll free 1070, landline 0389-233s842/233s832 and
mobile 9366331931) in case they require assistance.
C. Movement of Commodities

1.No permits shall be required for the movement of essential

commodities. Permits shall also not be required for movement of nonessential commodities specifically notified by Home Department.

2.Declaration shall be made either through mpcss on nCOWD-I9
mobile application, or in writing at the entry point, in all instances of
transportation of goods to the State.
3. However, for transportation of all other non-essential commodities
which have not been specifically notified by Home Department,
permits shall be obtained from Home Department through mpcss on
nCOWD- 7 9 mobile application.
4.No permits shall be required for movement of commodities within
Mizoram.
D. Shops and Establishments

l.Shops, business and other establishments are to operate by strictly
adhering to the 'Standard Operating procedure (SOp) for Sociat
Distancing' which is appended as Attolchment- I.

2'In busy commercial areas within Nzawl Municipality and District
Headquarters, shops and shops in shopping complexes/malls shall be
opened in a staggered manner such that adjacent shops within such
Iocations are not open on the same day. No shop should remain open
for consecutive days. This shall not apply to stores selling school
books, drug stores, Health and Veterinary Clinics or Veterinaqr shops.
The Deputy commissioner of each District shall make the necessary
arrangements for implementation of these measures.

<!-- page 5 -->

ENGLISH VERSION

3.In all other towns and villages, shops shall be opened without
restrictions. However, the Deputy Commissioner concerned may issue
guidelines or impose restrictions if deemed necessary.
4.To facilitate easy access to fruit, vegetable and meat, concerned
LLTF/VLTF shall make necessary arrangement within their respective
areas.
5. Home delivery

of fruits, vegetables and other produce shall be

permitted.
6. Public parks, picnic spots, movie theatres, grffiS, spas, beauty

parlours, community halls, market places and other public places of
entertainment will remain closed.
7. Street vending is strictly prohibited.
B.All shops with the exception of pharmaceutical shops shall be closed
by 5:00 PM.
9. Stranded travellers

in Mizoram may stay at hotels, and the

restaurants of such hotels shall be permitted to serve their in-house
guest. However, neither the hotel nor restaurant shall be open to the
public.
10. Restaurants, shall remain closed. However, home delivery and take
away services are permitted.
E. Educational, Religious Institutions and pubtic places
1. Educational & religious institutions and training institutes will remain
closed during this period. However, their administrative offices may be
opened.
2. All public gatherings including wedding receptions, functions for

celebration anniversaries and birthdoys, laying of memorial stone
(Iungphun), games & sports, book release functions, political and
social gatherings, any entertainment programmes are prohibited.
3. Not more than 20 persons shall be allowed to gather in a funeral
procession or a wedding prograrnme.
F. Restrictions on Travel & Movement of people
I . Commercial passenger vehicles plying within the State and town/ city
buses, taxis, auto rickshaws and two-wheeler are allowed to operate.
However, the seating capacity as recorded in their registration
certificate shall not be exceeded. All drivers and passengers shall wear
face masks and hand sanitizers shall be placed in all public
transportation for the use of passengers. The Standard Operatitr.g
Procedure to be followed by drivers and passengers of commercial
vehicles is appended as Attachment-2,

<!-- page 6 -->

ENGLISH VERSION

2.Intra-state movement of vehicles carrying goods is permitted.
3.within the Aizawl Municipal Area, vehicles will ply on .odd-even'basis
such that only vehicles bearing bdd'registration numbers shall ply on
Mondays, wednesdays and Fridays. Alternately, vehicles bearing ,even'
registration numbers shall ply on T\resdays, Thursdays and
Saturdays. No vehicle shall ply on sundays. This restriction shall also
apply to any other vehicle which enters Aizawl Municipal Area from
elsewhere. The 'odd-even' based restriction and the restriction of
vehicular movement on sundays shall not apply to vehicles used by
Government employees on covlD-19 related duties, ambulances and
vehicles used for medical/veterinary emergencies, vehicles of
employees of Government and private hospitals, vehicles of electronic
and print media persons, vehicles registered in the name of churches,
vehicles used for collection/distribution of milk, garbage trucks and
vehicles used by LLTF on duty.
4.sP (Traffic) may give exemptions from the 'odd-even, rule for vehicles
plying within, to and from Aizawl in emergency/urgent cases.
5. Quarantine of persons travelling within the state is not necessary
unless they display covlD-lg symptoms or have contact history with
a COVID-19 patient.
G. Measures for the General public
1. During the period of lockdown gatherings of more than 5 (five) persons

is prohibited. This shall not include gatherings at funeral proceedings
and wedding programmes mentioned in Clause E (3).
2.No person shall leave the house and compound except on essential
errands.
3.Movement of individual shal be strictly prohibited between z:00 pM
and 4:00 AM. This shalr not apply to persons on coVID-19 rerated
duties. All Deputy commissioners shall issue prohibitory orders under
Section 144 of CrPC in this regard.
4. Persons who are 65 years of age, those having co-morbidities,
pregnant women and children under 10 year of age will remain
indoors unless the it is unavoidable.
S'wearing a face mask or similar devices outside (public places/public
gatherings) and in hospitals shall be mandatory.
6.social distancing is to be maintained in public places by maintaining
at least 2 (two) metre distance between individuals.
T.Entertaining of guests from outside Mizoram is strictly prohibited.
Exemption may be grven by Home Department or Deputy
Commissioners in exceptional cases.

<!-- page 7 -->

ENGLISH VERSION

H. Government of M.izoram Offices
1. Medical personnel

of Health Department, police, home guards, civil
defence, fire & emergency services, disaster management, civil

aviation, prisons, excise & narcotics, municipal services, forest field
works, technical staff of PHE & P&E and all offices outsid e Atzawl city
shall function without any restrictions.
2. Other Government offices - Secretariat, Directorates, District
Administration and field Offices shall be open. All Group A & B officers
are to function with IOO% attendance and Group C & D staff are to
attend in staggered batches of 50% of their strength. However,
attendance of more than 50% of the staff may be enforced by the
SecretTY, Head of Department or Head of Office based on exigencies
of work. Constitutional bodies and boards, corporations and statutory
bodies under Government of Mizorarn shall also function as aforesaid.
3. Head of Office may grant commuted leave without the production of
medical certificate to Government employees with co-morbidities and

pregnant women.
4.The Heads of Offices will ensure that the SOP on Social Distancing is
strictly followed.
5. Visitors are

not allowed in Government offices unless they have

obtained prior permission of the officer whom they want to meet.
6. Unnecessary official meetings should be avoided. As far as possible,
consultation may be held through IT media. District officials are not to
be summoned to the state capital for meetings.
7 .Correspondences with other Departments and Offices should be done
via email and other electronic media as far as possible.
8.A11 Departments should explore the use of electronic media and IT
tools in providing services to the public. ICT Department shall take the
initiative to develop the necess ary platform.
r. Other Offices within Mizoram
Offices of the Central Government, Central PSUs, RBI, banks, financial

institutions, constitutional/ statutory bodies within Mizoram shall

function as per the guidelines issued by their headquarters.

J. Other activities
Developmental works and activities including individual livelihood
activities are allowed without restriction. However, labourers within the
state shall be engaged. Standard Operating Procedure for social
distancing at Annexure-2 should be strictlv followed.

<!-- page 8 -->

ENGLISH VERSION

K. Penal provision

Any person violating these lockdown measures will be liable to be
proceeded against as per the provisions of Section 51 to 60 of
the
Disaster Management Act, 2005, The Mizoram (Containment &
Prevention of COVID- 19) Ordinance, 2O2O besides legal action under
Sec. 188 of the IPC and other legal provisions as applicable.

The Government may revise and modify these provisions if necessary.

(LALNUNMAWTA CHUAUNGO)
Chief Secret af,y & Chairman
State Executive Committee

<!-- page 9 -->

Attachment-7

STANDARD OPERATING PROCEDURE FOR SOCIAL DISTANCING

The main aim of Social Distancing is the maintenance of ample
physical distance from other people whether at the work place, in public
places or while moving from place to place. Avoiding physical contact is
essential since close proximity with others increases the chances of
contracting COVID-l9 from droplets spread through sneezing, cough and
saliva. Hence, maintaining at least 2 metre distance from other people is an
important measure to stop the spread of the disease and for the sake of
abundant caution, social distancing has to be strictly enforced even after
relaxation of lockdown measures.
The following procedure for maintaining sociar distancing shall be strictly
followed in all government offices, NGos and ottrer private establishments,
commercial establishments and market places.

1. GOVERNMENT AND OTHER OFFICE ESTABLISHMENTS:
a) It shall be the duty of all Heads of Departments/Heads of offices to
strictly enforce social distancing norms. All workers are to wear
masks/face cover while performing business with others.
b) Heads of Departments/ Head of offices shall be responsible for the
general hygiene, cleanliness and sanitation of their office. They

shall ensure availability of hand washing facilities for staff,
including soap/handwash and sanitizer in their respective offices.

Further provision for hand washing or hand sanitizing should be
made at the entrance of offices for visitors/ outsiders.

c) No visitors shall be allowed to enter any office without the prior

permission of the concerned authorities.
d) Heads of departments/heads of offices shall explore the feasibility
of disinfecting vehicles and machineries entering office premises
from outside, as per the resources available to them.
e) The following will be regularly disinfected by using suitable low cost
disinfectants:
i. Office buildings, main entrance/exit, office premises.
ii. Office canteens.
iii. Meeting rooms, conference halls, verandas, etc.
iv. Bathrooms and toilets.
v. Walls, railings, stairs and staircase.

<!-- page 10 -->

Attochment-7

f) Government vehicles including buses arranged for transportation of
staff shall ply with the seating capacity as recorded in registration.
Drivers and passengers shall wear masks and maintain physical

distancing.
g) Office staff having underlying heatth problems and pregnant women
may be granted commuted leave.
h) Meetings should not be convened unless essential. If a wider
consultation or discussion is necess ffiy, video conferencing and
other online mode of communication may be utilised.
i) e-mail and other electronic interfaces may be used for
communicating with other Departments.
j) Arrangements for social distancing shall be made where collection
of electricity bills, water bills, phone bills, etc. are done. Online
payment of bills should be promoted.
k) For the convenience of the public in accessing government services,
all departments shall endeavour to develop online system for
delivery of public service. The ICT Department shall provide
technical support and take initiative to develop such platforms for
government departments.
l) Staggered lunch time may be devised to avoid overcrowding at office
canteens.

2. MARKETS, SHOPS AND OTHER BUSINESS ESTABLISHMENTS:
a) Wearing of mask/face cover in shops, markets and at all other
outdoor spaces is mandatory.
b) only 3 (three) persons shall be allowed to man a shop.
c) Shop employees should mandatorily wear masks lface cover. They
should follow strict hygiene and sanitation norms.
d) It shall be the duty and responsibility of the shopk eeper f owner to
facilitate social distancing for the customers. A minimum of two
metres distance should be maintained within and around the shop.
e) Vegetable vendors shall keep their items neat and clean. Wearing of
masks lface cover is also mandatory for all vend.ors.
0 In places arranged by Ll-fF IVLTF for sale of vegetable, fruits and
meat, queues shall be marked to facilitate social distancing. Apart
from regular market places, school compound, playground and
other suitable places may also be identified for selling vegetables,
fruits and meat.

<!-- page 11 -->

Attachment-7

3. OTHER WORK PLACES (CONSTRUCTION, MANUFACTURING,
SERVTCES & LOGTSTTCI
a) General cleanliness & sanitation measures shall be maintained. It
shall be the duty and responsibility of the employer/ owner to
provide cleaning/washing and toilet facilities to the employers.

b) Older people, persons having underlyitrg health problems and
pregnant women are not to be engaged.
c) Not more than 5 (five) persons are to be engaged at one time. In the
event that more than 5 (five) persons are engaged due to exigency of
work, proper distance should be maintained among them.
d) Farmers, farm workers and attendants shall avoid working in close
proximity with others in their respective work places.
e) Not more than 5 (five person) are allowed inside hair saloons,
tailoring shops, etc. The owner shall be responsible for compliance.
0 While loading and unloadittg cargo from trucks, the drivers and
handymen shall not come into direct contact with other workers or
labourers neither shall they assist them in unloading the cargo.

<!-- page 12 -->

Attdchnent - 2
MIZORAM CHHUNGA COMMERCIAL PASSENGER PHUR MOTOR TEN AN
ZAW]0fi TUR STANDARD OPERATING PROCEDURE

COVID-19 hrileng avangin ram chhung ah harsatna kan tawk mek a.
Central Sorkar atangin Lockdown chhungin Commercial Passenger phur motor a
chuan dan tur a ruahman a, chu chu tun ah hian a theih ang ang in zawm mek a
ni a. Central leh State Sorkar in Lockdown hi a pawtsei leh dawn in a lang a.
Lirthei neitute leh vah velna atante mipui harsatna te sutkian a nih theih nan, a
hnuai ami ang hian ruahmanna siam a ni.

1. TWO.WHEELER TA>(I
a) Two wheeler Taxi khalhtuten an passenger-te an chhuk veleh midang
an chuan leh hmain, uluk takin an lirtheite an sanitize zialr lntr a ni.
b) Two wheeler Taxi khalhtu leh Passengerten Mask an vuah ngei ngei
tur a ni.

2. TAXI/ AUTO.RICKSHAW

a) Taxi/ Auto-Rickshaw-ah te hian registration certificate a tarlan
seating capacity aia tam chuan phal a ni lo.
b) Driver leh Passenger ten Mask an vuah ngei tur a ni.
c) Sanitizer hman tur Taxi/Auto-Rickshaw chhungah a awm ngei tur a
ni.

d) Driver-in a zing thei ang berin motor chhung leh vawnbante uluk
takin a sanitize thin tur a ni.

3. MAXI CAB lState chhuns leh pawn service)
a) Registration certificate-a tarlan, seating capacity bak passenger phurh
phal a ni lo.
b) Driver leh Passenger ten zin kawngah Mask an vuah ngei tur a ni.
c) Driver-in a zing thei ang berin motor chhung leh vawnbante uluk
takin a sanitize thin tur a ni.
d) Sanitizer hman tur motor ah a awm ngei tur a ni.

4. CITY BUS/TOWN BUS/INSTITUTION BUS/SCHOOL BUS/BAZAR
BUS/LINE BUS
a) Registration certificate-a tarlan, seating capacity bak passenger phurh
phal a ni 1o.
b) Driver/ Conductor-te leh Bus-a chuang ten Mask an vuah ngei tur a
ni.
c) Sanitizer hman tur Bus-ah a awm ngei tur a ni.
d) City Bus ten turning point an thlen hunah Bus chhung leh vawn
bante Sanitizer hmangin uluk takin an tifai thin tur a ni.
Mask vuah leh motor sanitized chungchangah motor enkawltu ten mawh an
phur ang.

Heng a chunga mahmanna siam hi theih tawpa kan zawm tlan chuan
COVID-l9 hrileng leh darh zau zel tur lakah Zoram mipuite kan him thei dawn a
ni. Chuvangin passanger phur chi lirthei enkawltuten theihtawp chhuaha zawm
tur leh a tul anga passenger-te ziritr turin kan inngen bawk a ni.
***
