---
doc_id: "d3cd48c8dd3dfc9d"
source_url: "https://ifsl.mizoram.gov.in/uploads/attachments/2e89bd7e2233455c2b1deb9713d0bd12/clarification-amendment-on-bid-document-for-appointment-of-selling-agent-of-mizoram-state-lottery-25062019.pdf"
ministry: "Institutional Finance and State Lottery, Mizoram"
title: "Clarification-Amendment on Bid Document for appointment of Selling Agent of Mizoram State Lottery dated 25.06.2019"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "c3acaa556ffaedfc"
---

<!-- page 1 -->

ANG. Noe UV EN MOVES — BEBE
GOVERNMENT OF MIZORAM
FINANCE DEPARTMENT
Aizawl, the 25" June, 2019.
To

The Director,

Institutional Finance & State Lottery,

Mizoram, Aizawl.

Subj: Clarification/amendment on Bid document for appointment of Sclling

Agent of Mizoram State Lottery.

Madam,

In continuation to this Department's letter of even no. dt, 18.6.2019 regarding
the clarification/amendment on Bid Document for appointment of Selling Agent of Mizoram
State Lottery, additional clarification is hereby issued for general information. This may be
published in the website as well as conveyed to all the prospective bidders,

1. As per Clause 2(b){(vii), copy of the Agreement executed with respective
State Governments, if any, for marketing and conduct of lotteries is required to be submitted.
Hence, experience is not to be taken as a necessary condition. However, the State
Government is at liberty to give preference to the experienced valid bidder(s) with sound
financial standing as mentioned at Section C(v)(a) (Technical Bid) in the event of equal
financial bids.

2. If the Government has not received the bids for all 6 (six) sets, fresh tender
will be called for the remaining sets for which no bid is received. However, the Government
reserves the night to cancel all the bids and scck for fresh tender provided there is sufficient
reasons to do so,

3. In respect of Paper Lottery, all the unsold tickets shall be returned to the
Government of Mizoram through the Dircetor, Institutional Finance & State Lottery, as
instructed by the Government from time to time.

Further, since there will be no claimant from the unsold tickets when there is
prize winning number from unsold tickets, the prize money will not be required to be
deposited to the Government.

Yours faithfully,
7
KOA
(F. LALRINAWMA)
Joint Secretary to the Govt. of Mizoram,
% Finance Department (E),
