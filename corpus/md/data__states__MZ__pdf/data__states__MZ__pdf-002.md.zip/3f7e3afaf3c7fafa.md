---
doc_id: "3f7e3afaf3c7fafa"
source_url: "https://excise.mizoram.gov.in/uploads/attachments/2022/12/fe9f1c726fd88e9700e4a72ae9c53bde/posts-316-changed-of-posting-of-lalhmingtani-fr-lunglei-to-ans-dt-15th-december-2022.pdf"
ministry: "Excise and Narcotic Department, Mizoram"
title: "changed of posting of Lalhmingtani fr Lunglei to ANS dt 15th December 2022"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6f39c14e3786da6c"
---

<!-- page 1 -->

No. A.12015/1/2019-COM`EX
GOVERNMENT OF MIZORAM
COMMISSIONERATE OF EXCISE & NARCOTICS
COMMISSIONERATE OF EXCISE & NARCOTICS BUILDING
OPPOSITE AIJAL CLUB, KHATLA, AIZAWL-796001; MIZORAM

Dated Aizawl, the 15th December,2022.

OFFICE ORDER
In supersession of this office order No. A.12015/1/2019-COMEX

dt.13.12.2022, C/669 Lalhmingtani, posting to office of the Assistant
Commissioner of Excise & Narcotics Lunglei District, Lunglei is cancelled and

she is posted at Commjssionerate of Excise & Narcotics (Anti-Narcotics

Squad).Transfer is cancelled due to her performance at compulsory Basic

Training course at Cll Sesawng.

Sd/-NGURCHUNGNUNGA SAILO

Commissioner of Excise & Narcotics,
Mizoram: Aizawl

Memo No: A. 12015/1/2019-COMEX: Dated Aizawl, the 15th December,2022
Copy to:
1. .All Assistant Commissioners Of Excise & Narcotics for information.

2. Accountant, Commissionerate of Excise & Narcotics for information
and further necessary action.
3. Personal file concerned.

4. Service Book of personnel concerned.
5. Guard File.

6. Computer Operator for uploading in dept. website.
