---
doc_id: "4ff7bfb32feb9cfc"
source_url: "https://dmr.mizoram.gov.in/uploads/attachments/793d5e2dd2808cb53d87aa89d4518a4e/27052020-circular-sop-for-community-qf.PDF"
ministry: "Disaster management and Rehabilitation Department, Mizoram"
title: "Circular - SOP for Community QF"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5a66fd50c1309567"
---

<!-- page 1 -->

No.B. L3O2L I LO9IZO2O-DMR/Pt.[V
GOVERNMENT OF MIZORAM
DISASTER MANAGEMENT & REHABILITATION DEPARTMENT
**?t?k

Aizawl, the 2Vh of Mag, 2OZO

CIRCULAR
Mizoram mi leh S&, India rarn hmun danga tangkhang lo haw te dah
hranna tur atana ruahman, Community Quarantine Facility (CeF) te chu
awmze nei leh mumal taka enkawl a nih theih nan 63Stand.ard. Operating
Procedure (SOP) For Communitg Quarantine Facilitg (Communitg
Quarantine Facititg Kalpui Dan T\tr Kolihhntaina)r, thiltel ang hian
Community Quarantine Facility enkawltu zawlrrg zawngle zawm atan
tihchhuah a ni e.

sd/- LALBTAKSANGT
Secretary to the Government of Mizoram
Disaster Management & Rehabilitation Department
Memo No.8.13O27/LO9|2O2O-DMR/Pt.[V : Aizawl, the zVh of tWag,2O2O
Copy to:
1. P.s. to chief Minister, Mrzorarn for information.
2. P.S. to Deputy Chief Minister, Mizoram
3. P.S. to Speaker, Mrzoram
4. P.S. to Ministers/Ministers of State/Deputy Speaker/Deputy Govt.
Chief Whip, Mtzoram.
5. sr. P.P.s to chief secretary, Government of Mizoram.
6. P.P.s. to Addl. chief secretary, Government of Mizorarn.
7. A11 Commissioners/ Secretaries/ Spl Secretaries, Govt of
Mtzorarn.
8. Director General of police, Mizoram.
9. A1l Administrative Heads of Department, Government of
Mizorarn.
10. All Heads of Department, Government of Mizoram.
11. Secretar5r of all Constitutional & Statutory Bodies
, Mizoram.
12. Chairpersons of the Task Groups on Medicine & Medical Equipments/
Quarantine Facilities/Commodities & Transp ortlMigrant Workers &
stranded Travellers/ Media & publ icity lDocumentation.
13. A11 Deputy Commissioners, Mizoram.
L4. All Superintendents of polic e, Mrzoram.
15. Director, I&PR for wide publicity.
76. Guard File.
nl

llltl
, -vl'

I

J--=,-/-:J)-ry rlTT.0

(Dr MALSAWMTLU^A,NGA FANCHUNI
under Secretary to the Government of Mizoram
Disaster Management & Rehabilitation Department

<!-- page 2 -->

STANDARD OPERATING qRqCEDURE FQF
coMMU N ITY QUARANTIN,E,TA.CI Llry
qUARANTTNE
(coMMUNtTy
FACTLTTY KALPUI DAN TUR KAIHHRUAINAI
Mizoram mi leh s?, ram pawna tangkhang mek lo haw tur thahnem tak an awm

avang leh Sawrkar quarantine facility te'n a dawl zo dawn lova a lan avangin,
Mizoram Sawrkar, Disaster Management & Rehabilitation Department chuan Order
No.B. 13021110912020-DMR/Pt.lll dated 25.05.2020 hmangin-1-ocal Council leh

Village Council zawng zawng te hnenah an veng/khua-a Community Quarantine
Facitity tur pakhat tal lo ruahman ve turin a hriattir a. Chutiang chuan Kohhran hall
remchang angte, veng chhung sikul leh YMA hall te chu Community Quarantine
Facility (COF) atan ruahman mek an ni.

Heng Community Quarantine Facility (COF) te enkawl dan tur tlangpui chu a
hnuaia inkaihhruaina ang hi ani ang:
1.

District tina Deputy Commissioner te remruatpuina hnuaiah Local Level Task
ForceA/illage Level Task Force te'n an vengchhunga CQF-te an enkawl ang.

2.

Faina leh thianghlimna kenkawh chungchangah a enkawltu LLTFA/LTF ten
ruahmanna fel tak an siam ang.

3. Dahhran turte lo thlen hmain fai taka buatsaih phawt tur a ni ang a, 'social

distancing' a awm theih nan an mut dan tur ruahmanna fel tak siam tur a ni
ang. Mutna tur teh inthiarna (toilet) awm dan azirin awm thei tur zat (capacity)
ruahman tur a ni.

4. LLTFA/LTF-Ie ruahmanna hnuaiah CQF-a awm turte mutbu leh mamawh dang
chu an chhungte'n an lo dah lawk vek ang.
5

Ni 14 dahhran an nih chhungin midang awm ve te nen room khata an awmho
a nih loh chuan inlenpawh loh tur a ni a, room khata awmho te pawn uluk takin
'social distancing' an zawm tlat tur a ni.

6. CQF-a awm te chu an chhungte emaw pawn lam mi te tlawh khap tlat a ni a,

mamawh tul zual inpek a ngai a nih pawhin LLTFA/LTF duty-te kaltlang
chauha in pek tur a ni. Tin, dahhrante chu pawn chhua,h phal an ni lovang.
Page I of 2

<!-- page 3 -->

7.

CeF ah lut (admit) leh chhuak (discharge) te chhinchhiahna register fel tak
vawn tur a ni. LLTFA/LTF ten an bialtu tncident Commander/ Zonal Officer te
hnenah a tul angin nitin report an pe thin ang.

B.

CeF-a dahhran zawng zawngte hian an mobile phone-ah 'Aarogya Setu' leh
mCOVID-19 mobile application install-in an in-register vek tur ani.

g. LLTFA/LTF duty-te pawh fimkhur takin mask vuah chungin social distancing
protocol an vawng tlat tur a ni
10.

CeF-a ei leh in hi kohhran emaw khawtlang emaw chhungkua emaw mimal
feh lawmngai pawl ten an tumsak a nih chuan thil lawmawm tak ani ang a.
Amaherawhchu, LLTFA/LTF-te kaltlanga ruahmanna siam tur a ni ang. Ei leh
in tum sak tu nei remchang lo an awm a nih chuan LLTFA/LTF ten an bialtu
lncident Commander/ Zonal officer hnenah hriattir tur a ni ang.

11. CeF-a awmte hrilsetna enzui dan chungchangah bialtu Chief Medical Officer

te'n ruahmanna an siam ang.
12.

Dahhrante'n an quarantine hunchhung an zawh a, an chhuah fel hnuin CQF
chu 1% sodium hypochtorite hmanga then thianghlim tur a ni. Chumi hma chu
midang dah luh loh tur a ni ang.

13.

CeF-a bawlhhlawh sawngbawl chungchangah chu,an municipal area-ah
Aizawl Municipal corporation in ruahmanna a siam ang a, census town-ah
chuan District Urban Development Officer (DUDO) emaw DPO-in ruahmanna
an siam ang. Hmun dang zawngah chuan Village Health & Sanitation
Committee-in ruahmanna an siam ang.

14. CeF-a awmte zingah damlo an awm chuan rang takin medical duty te emaw

medical helpline (1 021231 8336/2323336) ah hriattir tur a ni.
15. Veng/khaw inthenawm te'n CQF te a hlawk thei ang bera (optimum capacity

utilization) an hman theih nan inremsiamna an nei thei ang. Hetiang tur hian
VLTF/LLTF tin te inring tura beisei an ni. Chutiang chu a tul anih chuan Deputy
Commissioner/Executive Magistrate te'n ruahmanna an siam ang.

Page 2 of 2
