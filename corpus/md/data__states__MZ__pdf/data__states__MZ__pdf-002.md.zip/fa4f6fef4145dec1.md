---
doc_id: "fa4f6fef4145dec1"
source_url: "https://sec.mizoram.gov.in/uploads/attachments/afa7beed73ec48e8b65e2db27c8f597d/13-madc-election-to-village-councils-rules-2014.pdf"
ministry: "District Council Affairs Department, Mizoram"
title: "THE MARA AUTONOMOUS DISTRICT COUNCIL (ELECTION TO VILLAGE COUNCILS) RULES, 2014"
date: ""
pages: 88
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "83d0d0f20bdf85aa"
---

<!-- page 1 -->

THE MARA AUTONOMOUS DISTRICT COUNCIL
(ELECTION TO VILLAGE COUNCILS) RULES, 2014

<!-- page 2 -->

<!-- page 3 -->

The Mizoram Gazette
EXTRA ORDINARY

Published by Authority
RNI No. 27009/1973
VOL - XLIV

Postal Regn. No. NE-313(MZ) 2006-2008

Aizawl, Wednesday 14.1.2015

Pausa 24,

S.E. 1936,

Issue

No. 10

NOTIFICATION

No.C.31012/4/2011-DCA(M), the 18th December, 2014.
In pursuance of paragraph 11 of the Sixth
Schedule to the Constitution of India, the following Rules made by the Mara Autonomous District Council
which received approval of His Excellency the Governor of Mizoram on 8.12.2014 is hereby published for
general information, namely :-

“THE MARA AUTONOMOUS DISTRICT COUNCIL
(ELECTION TO VILLAGE COUNCILS) RULES, 2014”

P. Singthanga,
Secretary to the Government of Mizoram,
District Council Affairs Department.

<!-- page 4 -->

Ex-10/2015

2
MARA AUTONOMOUS DISTRICT COUNCIL
(ELECTION TO VILLAGE COUNCILS) RULES, 2014

In exercise of the power conferred by section 29 of the Mara Autonomous District (Village Councils)
Act, 1974, read with sub–section (3) of section 3 thereof, the Executive Committee of the Mara Autonomous
District Council, with the previous approval of the Governor of Mizoram, is pleased to make the following
Rules for conducting Village Council election.
MARA AUTONOMOUS DISTRICT COUNCIL
(ELECTION TO VILLAGE COUNCILS) RULES, 2014
Chapter – I
PRELIMINARY

Short title, extent
and commencement.

Definitions.

1.

2.

(1)

These Rules may be called Mara Autonomous
District Council (Election to Village Councils)
Rules, 2014.

(2)

They shall have the like extent as the Act.

(3)

They shall come into force from the date of their publication
in the Official Gazette.

(1)

In these Rules, except where it is expressly provided
otherwise or the context otherwise requires–
(a)

“Act” means the Mara Autonomous District
(Village Councils) Act, 1974 as amended from
time to time.

(b)

“Ballot box” means any box, bag or other
receptacle used for the insertion of ballot papers
by voters;

(c)

“Contesting candidate” means a candidate whose
nomination has been duly accepted under Rule
43 and who has not withdrawn his candidature;

(d)

“Constituency” means a Village Council
constituency;
“Corrupt practices” means the corrupt practice
as defined in section 123 of the Representation
of the People Act, 1951 (43 of 1951) in so far as
they are relevant to the system of Village Council
election under these Rules;

(e)

(f)

“Deputy Commissioner” means the Deputy
Commissioner of Saiha District;

<!-- page 5 -->

3

Ex-10/2015

(g)

“District” means the Mara Autonomous District
as prescribed in Part–III of the Table appended
to Para 20 of the Sixth Schedule to the
Constitution of India;

(h)

“District Council” means the Mara Autonomous
District Council.

(i)

“District Election Officer” means the District
Election Officer appointed or designated under
Rule 5;

(j)

“Election” means an election to fill vacancy or
vacancies in a Village Council;

(k)

“Election Officer” means the Election Officer of
Saiha District;

(l)

“Election Tribunal” means an election tribunal
constituted under Rule 86 and 87;

(m)

“Elector” means a person whose name is for the
time being entered in the electoral roll;

(n)

“Electoral Registration Officer” means the
Officer appointed or designated as such under
Rule 6 in connection with preparation and revision
of electoral rolls;

(o)

“Electoral Roll” means a list of persons whose
names are registered and who are entitled to vote
in an election under these Rules;

(p)

“Executive Committee” means the Executive
Committee of the Mara Autonomous District
Council;

(q)

“Form” means a form appended to these
Rules.

(r)

“Governor” means the Governor of Mizoram
appointed by the President of India under Article
155 of the Constitution of India;

(s)

“Multiple election” means an election to fill two
or more vacancies at one time where each elector
is entitled to give as many votes as there are
vacancies to be filled;

<!-- page 6 -->

Ex-10/2015

4

(2)

(2)

(t)

“Presiding Officer” means an Officer appointed
under Rule 11 to conduct election in a polling station
under these Rules;

(u)

“Polling Officer” means and officer appointed to
assist the Presiding Officer to conduct election in
a polling station;

(v)

“Qualifying Date” means the first day of January
of the year in which the Electoral Roll is prepared ;

(w)

“Qualifying Period” means the year which
immediately precedes the year in which the
Electoral Roll is prepared;

(x)

“Returning Officer” means an Officer appointed
or designated as such under Rule 8 who shall be
responsible for the proper conduct of election in
one or more constituencies and he may be assisted
by Assistant Returning Officer;

(y)

“Roll” means Electoral Roll;

(z)

“State Election Commission” means the State
Election Commission constituted by the State
Government.

Words and expressions which are not defined in these
Rules but defined in the Act shall have the same
meanings as assigned to them in the Act.

Chapter – II
STATE ELECTION COMMISSION AND APPOINTMENT OF OFFICERS
State Election Commission

3.

(1)

The State Election Commission duly constituted by the
State Government, consisting of a State Election
Commissioner appointed by the Governor under
clause(1) of Article 243K of the Constitution of India
read with sub–section(1) of section 345 of the Mizoram
Municipalities Act, 2007 as amended, shall be vested
with the superintendence, direction and control of the
preparation, revision and correction of electoralrolls for,
and conduct of, all elections to the Village Councils under
these Rules.

(2)

The State Election Commission shall co-ordinate and
supervise the works of District Election Officer in the
District in the discharge of his functions and duties under
these Rules.

<!-- page 7 -->

5
Observers.

District Election
Officer.

Electoral Registration
Officer.

4.

5.

6.

Ex-10/2015

(1)

The State Election Commission may appoint a Roll Observer
who shall be an officer of the Central or State Government or
Pubic Undertakings to review, supervise and monitor the
preparation, or revision of electoral roll and to perform such
other functions as may be entrusted to him by the State Election
Commission;

(2)

The State Election Commission may also appoint an Election
Observer, who shall be an officer of the Central or State
Government or Public Undertakings to watch the conduct of
election or elections in a Constituency or a group of
Constituencies and to perform such other function as may be
entrusted to him by the State Election Commission. The
Election observer so appointed or nominated shall report to
the State Election Commission and function under the direction
and control of the Commission.

(1)

The State Election Commission shall appoint the Deputy
Commissioner as District Election Officer for the preparation
of Electoral Rolls and the conduct of elections under these
Rules.

(2)

The State Election Commission may appoint the Election
Officer or such other Officer of the State Government as
may be necessary as Assistant District Election Officer to
assist the District Election Officer and perform such duties
under his direction.

(3)

The District Election Officer shall also perform such other
functions and duties as may be directed by the State Election
Commission from time to time.

(1)

The State Election Commission shall appoint or designate
any officer of the State Government as Electoral Registration
Officer to perform all necessary functions for the preparation
and revision of electoral rolls for all Village Council
constituencies in the District.

(2)

The State Election Commission may, in consultation with the
State Government, designate one or more officers as Assistant
Electoral Registration Officer to assist the Electoral
Registration Officer and perform duties under his direction.

(3)

The Electoral Registration Officer shall also perform such
other functions as may be directed by the State Election
Commission.

(4)

An Electoral Registration Officer may, subject to any
prescribed restrictions, employ such persons as he thinks fit
for the preparation and revision of the electoral roll for the
constituency.

<!-- page 8 -->

Ex-10/2015

6

One Officer may be
appointed or designated as both District
Election Officer and
Electoral Registration
Officer.
Returning Officer.

8.

7.

Nothing in these Rules shall prevent the State Election Commis
sion from appointing or designating one and same Officer to
be both the District Election Officer and the Electoral Registration Officer for the district.

(1)

For every election to fill a seat or seats of a Village Council in
any constituency, the State Election Commission shall, in
consultation with the District Election Officer, appoint any
officer/ employees of the State Government /Mara
Autonomous District Council to be the Returning Officer to
conduct the election in that constituency. There shall be a
separate Returning Officer for each of the Village Council
constituency.
If the District Election Officer is satisfied that the functions
of the Returning Officer in any constituency cannot be
performed satisfactorily by one officer, he may, submit proposal
to the State Election Commission, for appointment of any
officer/employees of the State Government/ Mara
Autonomous District Council to be Assistant Returning Officer
to assist the Returning Officer in the conduct of election in
that constituency.

(2)

(3)

Every Assistant Returning Officer shall, subject to the control
of the Returning Officer, be competent to perform all or any
of the functions of the Returning Officer.

Returning Officer
to include Assistant
Returning Officers
performing the
functions of the
Returning Officer.

9.

All references in these Rules to the Returning Officer shall,
unless the context otherwise requires, be deemed to include
an Assistant Returning Officer performing any function which
he is authorized to perform under Rule 8.

General duty of the
Returning Officer.

10.

It shall be the general duty of the Returning Officer at any
election to do all such acts and things as may be necessary
for effectually conducting the election in the manner provided
by these Rules or orders made thereunder.

Presiding Officer
and Polling Officers
for Polling Stations.

11.

(1)

The District Election Officer shall, in consultation with the
State Election Commission, appoint a Presiding Officer for
each Polling Station and such Polling Officers as may be
required from amongst the employees of the State Government
Mara Autonomous District Council to conduct the election in
the manner provided by these Rules or orders made thereunder.

(2)

If the Presiding Officer, owing to illness or other unavoidable
cause, is unable to perform his functions, the Polling Officer

<!-- page 9 -->

7

Ex-10/2015

whose name stands at serial number one of the list of Polling
Officers, shall perform the functions of the Presiding Officer.
(3)

Duties of Presiding
Officer:.

12.

References in this Rule to the Presiding Officer shall, be the
deemed to include the Polling Officer, who performs functions
of the Presiding Officer under sub–rule (2) of this Rule.
The Presiding Officer shall–
(a) keep order at the Polling Station;
(b) ensure that the poll is taken fairly and strictly in accordance
with the provisions of these Rules;
(c) regulate the number of voters to be admitted at any one
time inside the Polling Station and exclude there from all
other persons except–
(i) the Polling Officers and other staff engaged on polling
duty;
(ii) the Candidates, Election Agents and the Polling Agents;
(iii) public Servants including Police personnel on duty;
(iv) a child in arm accompanying a voter;
(v) a companion of illiterate or blind or infirm elector;
(vi) observers appointed by the State Election Commission;
(vii) persons authorized by the State Election Commission
such as media persons.

Duties of Polling
Officers and other
Staff.

13.

(1)

It shall be the duty of the Polling Officers at a Polling
Station to issue Ballot Papers to electors according to the
provisions of Rule 57 and to mark on the electors to whom
ballot papers are issued, and to assist the Presiding Officer as
may be required by him.

(2)

For the purpose of sub-rule (1), the Polling Officers shall be
provided with(a) sufficient number of Ballot Papers;
(b) the Electoral Roll of the constituency;
(c) a stamp pad as may be required for taking thumb
impression of illiterate elector under sub–rule (2) of Rule
57 and;
(d) other articles or form which may be required.

<!-- page 10 -->

Ex-10/2015

8

Functions of the
14.
Returning Officer
and the Presiding Officer.

Observer, District
Election Officer,
Electoral Registration
Officer, Returning
Officer etc. deemed
to be on deputation
to the State Election
Commission.

15.

(3)

The other Staff appointed, if any, in a Polling Station shall
perform such functions and duties as may be assigned to them
by the Presiding Officer.

(1)

The Returning Officer shall function under the control and
supervision of the District Election Officer and shall perform
such functions and duties as may be directed by the State
Election Commission or the District Election Officer.

(2)

The Presiding Officer shall function under the control and
supervision of the Returning Officer and shall perform such
functions and duties as may be directed by the District Election
Officer or the Returning Officer, as the case may be.

The Observer, District Election Officer, Electoral Registration Officer,
Returning Officer, etc referred to in Chapter–II, and any other
officers or staff employed in connection with the preparation, revision and correction of electoral rolls for, and the conduct of, all
elections shall be deemed to be on deputation to the State Election
Commission for the period during which they are so employed and
such officers and staff shall, during that period, be subject to the
control, superintendence and discipline of the State Election
Commission.
Chapter – III
ELECTORAL ROLL

Electoral Roll for every
Constituency
and adoption of
electoral roll of the
Assembly Constituency.

16.

(1)

For every Village Council Constituency, there shall
be an electoral roll prepared in accordance with the provisions
of these Rules.

(2)

Notwithstanding anything contained in these Rules, the State
Election Commission may prepare the electoral rolls of Village
Councils without conducting an enumeration by adopting the
last published electoral rolls of the Assembly Constituencies
prepared for the purpose of election to the State Legislative
Assembly under the provisions of the Representation of the
People Act, 1950 (Act 43 of 1950) as draft roll or mother roll.

(3)

The electoral roll of Assembly Constituency as adopted under
sub–rule (2) shall be divided into separate parts for each Village
Council Constituency and all electors included in the electoral
roll for the Assembly Constituency relating thereto shall be
incorporated in the electoral roll of the Village Council
Constituencies concerned.

<!-- page 11 -->

9
Preparation and
Revision of
Electoral Roll.

Disqualifications for
registration in an
Electoral Roll

17.

18.

Ex-10/2015

(1)

Notwithstanding anything contained in Rule 16, the roll shall
be revised either intensively or summarily or partly intensively
and partly summarily as the State Election Commission may
direct.

(2)

The Electoral Roll for every constituency shall be prepared
by reference to the qualifying date before each general
election or mid-term or by-election to the Village Councils.
The Electoral Roll so prepared and published in accordance
with the provisions of these Rules may be referred to as the
mother roll of the constituency.

(3)

The Electoral Rolls under these Rules need not be revised
annually or summarily as a matter of course. However, if in
the opinion of the State Election Commission there is sufficient
reason so to do, it may, by a notification, order that the Electoral
Roll or rolls of particular constituency or constituencies shall
be revised summarily at any time of the year other than the
year before or during which the Election to Village Councils
was conducted.

(4)

For the purpose of sub-rule (3), re-election of a dissolved
Village Council to restore the Village Council for remaining
period of the general term, or by-election to fill casual vacancy
in a Village Council at any time, shall not normally be counted
as a sufficient reason for ordering summary revision.

(5)

Summary revision under sub-rule (3) shall be done in such a
way that the Electoral Registration Officer shall, by reference
to the mother roll, invite claims and objections and dispose
them of in the manners as provided under the following Rules,
and shall publish a list of amendments containing additions or
deletions or corrections or all showing the year of such revision,
and shall append the lists to the mother roll. The mother roll
together with such lists of additions or deletions or corrections
or all appended to it, shall become the Electoral Roll of the
constituency.

(1)

A person shall be disqualified for registration in an Electoral
Roll if he (a) is not a Citizen of India; or
(b) is not a member of a Scheduled Tribe; or
(c) is of unsound mind standing so declared by a competent
court; or
(d) is for the time being disqualified from voting under the
provisions of any law relating to corrupt practices and
other offences in connection with elections.

<!-- page 12 -->

Ex-10/2015

10
(2)

The name of any person who becomes so disqualified after
having been registered in an Electoral Roll shall forthwith be
struck off from the Electoral Roll in which it is registered.

No person to be
registered in more
than one constituency.

19.

No person shall be entitled to be registered in the Electoral Roll for
more than one constituency at a time.

No person to be
registered more
than once in any
constituency.

20.

No person shall be entitled to be registered in the Electoral Roll for
any constituency more than once.

Conditions of
Registration.

21.

(1)

Subject to the provisions of foregoing Rules in this
chapter, every person who–

(a)

is not less than eighteen years of age on the qualifying date,
and

(b)

is ordinarily resident in a constituency for one hundred eighty
days as on the qualifying date, shall be entitled to be registered
in the Electoral Roll for that Constituency.

(2)

For the purpose of clause (b) of sub–rule (1), the expression
“Ordinarily Resident” shall have the same meaning as
assigned to it by section 20 of The Representation of the People
Act, 1950 (43 of 1950).

Making false
declaration.

Order of Names.

Electoral Roll not
be divided in parts.

22.

23.

24.

If any person makes any false declaration in connection with:–
(a)

the preparation, revision or correction of an electoral roll, or

(b)

the inclusion or exclusion of any entry in or from an electoral
roll, a statement or declaration in writing which is false and
which he either knows or believes to be false or does not
believe to be true, he shall be punishable with imprisonment
for a term which may extend to one year, or with fine, or with
both.

(1)

The name of Elector in each roll shall be arranged so far as
practicable according to house number of the mother roll.

(2)

The names of electors in each part of the roll shall be
numbered, so far as practicable, consecutively with a separate
series of numbers beginning with the number one.

(1)

The Electoral Roll of a Village Council constituency shall not
be divided in parts but shall be numbered consecutively
beginning from the number one.

<!-- page 13 -->

11

Information to be
supplied by occupants.

25.

Ex-10/2015

(2)

Where there are different localities in a constituency, the
Electoral Registration Officer may direct to enter the names
of the electors in the locality wise by dividing into sections.
This, however, shall not be compulsory but shall be left at the
free discretion of the Electoral Registration Officer. In any
case, the serial numbers of the electors shall be consecutive
all through.

(1)

The Electoral Registration Officer may, for the purpose of
preparing electoral roll, send letter of request in Form 1 to the
occupants of any dwelling house in a constituency, if no person
is available to give the required information on particulars of
the occupants at the time of visit during Intensive Revision of
Electoral Roll, and every person receiving any such letter shall
furnish the information called for therein to the best of his
ability.

(2)

In case any question arises as to whether a person is ordinarily
resident at a place at a relevant time, the instructions prescribed
in Form 1 may also be considered by the State Election
Commission for the determination of a person’s ordinary
residence.

Access to certain
registers.

26.

For the purpose of preparing electoral roll or deciding any claim or
objection to electoral roll, the Electoral Registration Officer and any
person employed by him for the purpose shall have access to any
register of births and deaths and to the admission register of any
educational institution, and it shall be the duty of every person in
charge of any such register to give to the said officer or person such
information and such extracts from the said register as he may
require.

Publication of
Electoral Roll in
draft.

27.

As soon as the Electoral Roll for a constituency is ready, the
Electoral Registration Officer shall publish it in draft, by making a
copy thereof available for inspection and displaying a notice in Form 2–

Further publicity to
the draft roll and
notice.

28.

(a)

at his Office, and

(b)

at such place in the constituency as may be specified by him
for the purpose.

The Electoral Registration Officer shall also–
(a)

(b)

make a copy of each draft roll with a copy of the notice in
Form 2 available for inspection at a specified place accessible
to the public and in or near the constituency to which the draft
roll relates;
give such further publicity to the notice in Form 2 as he may
consider necessary; and

<!-- page 14 -->

Ex-10/2015

12
(c)

Period for lodging
claims and objections.

29.

supply free of cost two copies of each draft roll to every Political
Party registered by the Election Commission of India.

Every claim for the inclusion of a name in the roll and every
objection to an entry therein shall be lodged within a period of fifteen
days from the date of publication of the roll in draft under Rule 27:
Provided that the State Election Commission may by a
notification extend the period not exceeding 15 days in respect of a
district as a whole or in respect of any constituency.

Form for claims
and objections.

Manner of lodging
claims and objections.

Disposal of claims
and objections.

30.

31.

32.

(1)

Every claim shall be in Form 3 and signed by the person desiring
his name to be included in the roll.

(2)

Every objection to the inclusion of a name in the roll shall be in
Form 4 and preferred only by a person whose name is already
included in the roll in which the name objected to appears.

(3)

Every objection to a particular or particulars in an entry in the
roll shall be in Form 5 and preferred only by the person to
whom that entry relates.

Every claim and objection shall–
(a)

either be presented to the Electoral Registration Officer or to
any person employed by him in this behalf who shall forward
it with such remarks as he considers proper to the Electoral
Registration Officer; or

(b)

be sent by post to the Electoral Registration Officer.

The Electoral Registration Officer shall–
(a)

ensure that all claims and objections received after draft
publication within the prescribed time period are duly disposed
of in accordance with law and directions or instructions of the
State Election Commission;

(b)

reject any claim or objection that is not lodged within the period
or in the Form and manner specified under Rule 31;

(c)

hold a summary enquiry into every claim or objection in respect
of which a notice has been given and shall record his decision
thereon. At the hearing, claimant, or as the case may be,
objector and the person objected to and any other person,
who, in his opinion, is likely to be assistance to him, shall be
entitled to appear and to be heard;

<!-- page 15 -->

13

Final publication
of roll.

Appeals from orders
deciding claims and
objections.

33.

34.

Ex-10/2015

(d)

record not only his decision in each case but also brief reasons
for the decision;

(e)

dispose of all the claims and objections within thirty days from
the last date of the period for lodging such claims and objections
under Rule 29;

(f)

communicate his decision to every applicant within 24 hours
from the date of order made by him to enable the applicants
whose applications are rejected to file their appeals within the
stipulated period of fifteen days.

(1)

The Electoral Registration Officer shall thereafter–

(a)

prepare a list of amendments to carry out his decisions under
Rule 32 and to correct any clerical or printing errors or other
inaccuracies subsequently discovered in the roll;

(b)

publish the roll, together with the list of amendments by making
a complete copy thereof available for inspection and dis-playing
a notice in Form 6 at his office; and

(c)

subject to such general or special directions as may be given
by the State Election Commission, supply free of cost, two
copies of the roll, as finally published, with the list of amendments, if any, to every political party for which a symbol has
been exclusively reserved by the Election Commission of India.

(2)

On such publication, the roll together with the list of
amendments shall be the electoral roll of the constituency.

(3)

Where the roll, together with the list of amendments, becomes
the electoral roll for a constituency under sub–rule (2) the
Electoral Registration Officer may, for the convenience of all
concerned, integrate, subject to any general or special
directions issued by the State Election Commission in this
behalf, the list in to the basic roll by incorporating inclusion of
names, amendments, deletion of entries in the relevant parts
of the basic roll itself, so however that no change shall be
made in the process of such integration in the name of any
elector or in any particulars relating to any elector, as given in
the list of amendments.

(1)

An appeal shall lie from any decision of the Electoral Registration Officer under Rule 32 to such officer of Government
as the State Election Commission may designate in this behalf
(hereinafter referred to as the appellate officer):

<!-- page 16 -->

Ex-10/2015

14
Provided that an appeal shall not lie where the person
desiring to appeal has not availed himself of his right to be
heard by, or to make representations to the Electoral
Registration Officer on the matter which is the subject of
appeal.
(2)

Every appeal under sub–rule (1) shall be–

(a)

in the form of a memorandum signed by the appellant and
accompanied by a copy of the order appealed against and a
fee of Rs.10 (Rupees ten) to be paid–
(i) by means of non–judicial stamps, or
(ii) in such other manner as may be directed by the State
Election Commission, and

Breach of official
duty in connection
with the preparation
etc. of electoral rolls.

35.

(b)

presented to the appellate officer within a period of fifteen
days from the date of announcement of the decision of the
Electoral Registration Officer or sent to that officer by
registered post so as to reach him within that period.

(3)

The presentation of an appeal under this Rule shall not have
the effect of staying or postponing any action to be taken by
the Electoral Registration Officer under Rule 33.

(4)

Every decision of the appellate officer shall be final; but in so
far as it reverses or modifies a decision of the Electoral
Registration Officer, shall take effect only from the date of
the decision in appeal.

(5)

The Electoral Registration Officer shall cause such amendments to be made in the roll as may be necessary to give
effect to the decisions of the appellate officer under this Rule.

(1)

If any Electoral Registration Officer, Asst. Electoral Registration Officer or other person required by or under this Rule to
perform any official duty in connection with the preparation,
revision or correction of an electoral roll or inclusion or
exclusion of any entry in or from such electoral roll is, without
reasonable cause, guilty of any act or commission in breach
of such official duty, he shall be punishable with fine which
may extend to five hundred rupees;
(2) No suit or other legal proceeding shall lie against any such
officer or other person for damages in respect of any such
act or omission as aforesaid;

<!-- page 17 -->

15

Ex-10/2015

(3) No court shall take cognizance of any offence punishable
under this Rule unless there is a complaint made by an
order of, or under the authority from the State Election
Commission or the District Election Officer concerned.
CHAPTER IV
NUMBER OF VACANCIES, ELECTION NOTICE, NOMINATIONS,
SCRUTINY AND SYMBOLS
Publication of
Village numbers
and vacancies.

36.

As soon as may be after the publication of final electoral rolls under
Rule 33 or 34 as the case may be, the State Election Commission, in
consultation with the District Election Officer, shall publish a list of
Village Councils for which election is to be held, giving each village
a distinctive village number and showing number of vacancies to be
filled in each by such election.

Notification for
General Election
to Village Councils.

37.

(1)

A general election to Village Councils shall be held on or before
the expiration of the duration of the existing Village Councils
or on their dissolution, if any, and the State Election
Commission shall call upon every constituency to elect
members of the Village Council in accordance with this Rule
within such time as may be specified in such notification.

(2)

For the purpose of holding elections to fill ordinary or casual
vacancies, the State Election Commission shall by a notification
in the Official Gazette, appoint–

(a)

the last date for making nominations which shall be the seventh
day after the date of publication of the first mentioned
notification or, if that is a public holiday, the next succeeding
day which is not a public holiday;

(b)

the date for the scrutiny of nominations which shall be the day
immediately following the last date for making nominations or,
if that day is a public holiday, the next succeeding day which
is not a public holiday;

(c)

the last date for the withdrawal of candidature, which shall be
the second day after the date for the scrutiny of nominations
or, if that day is a public holiday, the next succeeding day
which is not a public holiday;

(d)

the date or dates on which a poll shall, if necessary, be taken
which or the first of which shall be a date not earlier than the
fourteenth day after the last date for the withdrawal of
candidatures; and

(e)

the date before which the election shall be completed.

<!-- page 18 -->

Ex-10/2015

16
(3)

(a) Where general election is to be held otherwise on the
dissolution of the existing Village Council, no such
notification shall be issued earlier than 6 months prior
to the date on which the duration of the Village Council
would expire.
(b) When a Village Council is dissolved, election to constitute
the Village Council for the remaining period of the fixed
tenure, shall be completed before the expiry of 6 months
from the date of its dissolution:
Provided that where the period for which such dissolved
Village Council would have continued is less than six months,
it shall not be necessary to hold any election to constitute the
Village Council for the remaining period.

Timeline for issue
of notification.

38.

(1)

The period between announcement of schedule of elections
to the Village Councils by the State Election Commission and
issue of notification for the elections to the Village Councils
by the State Election Commission shall not exceed fourteen
days.

(2)

The notification for election to Village Councils shall be issued
on a date, giving time not less than seven days ahead of the
date appointed for the last date of filing of nominations.

(3)

The date or dates of poll shall be fixed, leaving at least twenty
one days between the date fixed for withdrawal of candidature
and actual date of poll, for preparation of ballot boxes, ballot
papers and other election materials.

Public notice
of intended
election and time
of nominations.

39.

On the issue of a notification by the State Election Commission under
Rule 37, the Returning Officer shall, in Form 7, give public notice of
the intended election in such form and manner, as may be prescribed,
inviting nominations of candidates for such election and specifying
the place at which the nomination papers are to be delivered.

Qualifications of
candidates.

40.

Every person whose name is registered in the electoral roll of the
Village Council concerned under Rule 17 of these Rules and who is
not disqualified to be a member of Village Council under section 4 of
the Mara Autonomous District (Village Councils) Act, 1974 as
amended from time to time shall be qualified to be a candidate for
election.

Filing of
nomination.

41.

Any person who is qualified to be a candidate under Rule 40 may
offer himself as a candidate and file his own nomination duly
countersigned by an witness, who is an elector of the constituency,
in Form 8 and deliver it in person or by his representative at the
appointed place and within the appointed date under Rules 37 and
39, between the hours of eleven O’clock in the forenoon and three
O’clock in the afternoon:

<!-- page 19 -->

17

Ex-10/2015

Provided that no nomination paper shall be delivered to
the Returning Officer on a day which is a public holiday.
Security deposit,
refund or forfeiture

42.

(1)

A candidate shall deposit a security deposit of rupees five
hundred along with his nomination paper which shall be
refunded to him at once in the case of his withdrawing the
candidature, or as early as possible after the conclusion of the
election unless he forfeits the deposit.

(2)

The Returning Officer shall issue to the candidate a receipt in
Form 9 which shall be taken back from him in the case of
refund of the deposit.

(3)

The security deposit of a candidate shall be forfeited to the
District Council if–
(a) at an election to fill one vacancy the candidate is not
elected and the number of valid votes polled by him is less
than one-sixth of the total number of valid votes polled by all
candidates; or
(b) at an election to fill two or more vacancies the candidate
is not elected and the total valid votes polled by him is less
than one- sixth of the total votes polled by all the candidates
divided by the number of vacancies.

Scrutiny of
nominations.

43.

(1)

On the date appointed for the scrutiny of nominations under
Rules 37 and 39, the candidates and one person duly
authorized in writing by each candidate, but no other person,
may attend at such place and time as the Returning Officer
may appoint for such scrutiny. The Returning Officer shall
give them all reasonable facilities for examining the nomination
papers of all candidates which have been delivered in time.

(2)

The Returning Officer shall then examine the nomination
papers and shall decide all objections which may be made to
any nomination and may, either on such objection or on his
own motion after such summary inquiry, if any, as he thinks
necessary, reject any nomination on any of the following
grounds:
(a) that the candidate is either not qualified or disqualified for
being elected as a member of Village Council under the
provisions of the Act or of these Rules; or
(b) that there has been a failure to comply with the provisions
of Rule 41 or Rule 42; or
(c) that the signature of the candidate/thumb impression on
the nomination paper is not genuine:

<!-- page 20 -->

Ex-10/2015

18
Provided that the nomination of a candidate shall not be
rejected merely on the ground of any incorrect description of
his name or of any other particulars relating to the candidate
as entered in the electoral roll, if the identity of the candidate,
as the case may be, is otherwise established beyond
reasonable doubt.
(3)

The Returning Officer shall endorse on each nomination paper,
his decision, accepting or rejecting the same and, if the
nomination paper is rejected, he shall record in writing a brief
statement of his reasons for such rejection. The scrutiny shall
be completed on the date appointed in this behalf and no
adjournment of the proceedings shall be allowed except where
such proceedings are interrupted or obstructed by riot or open
violence or for causes beyond the control of the Returning
Officer:
Provided that in case an objection is made, the candidate
concerned may be allowed time to rebut the same not later
than the next day and the Returning Officer shall record his
decision on the date to which the proceedings are adjourned.

(4)

Immediately after all the nomination papers have been
scrutinized and decisions accepting or rejecting the same have
been recorded, the Returning Officers shall prepare a list of
validly nominated candidates, that is to say, candidates whose
nominations have been found valid, and affix it to his notice
board. Form 10 “List of validly nominated candidates” shall
be arranged under three categories–
(a) Candidates of recognized National and State political
parties:
(b) Candidates of registered political parties other than those
recognised National and State political parties:
(c) Other (Independent) candidates.

Withdrawal of
candidature.

44.

(1)

Any candidate may withdraw his candidature by a written
notice in Form 11 and subscribed by him and delivered before
three O’clock in the afternoon on the last date fixed under
Rule 39 for such withdrawal, to the Returning Officer either
by such candidate or any person authorized by him in writing
in that behalf. The Returning Officer shall normally accept
such withdrawal and refund the security deposit to the
withdrawing candidate.

(2)

No person who has given a notice of withdrawal of candidature
under sub–rule(1) shall be allowed to cancel the notice.

<!-- page 21 -->

19
Election without
contest.

45.

Allotment of symbols
and publication of list
of contesting candidates.

46.

Ex-10/2015

If, after the scrutiny of nominations or expiry of the period
within which candida t ur es may be wit hdr awn, the
number of valid candidates is either less than or equal to the
number of vacancies to be filled, the Returning Officer shall
forthwith declare all the validly nominated candidates elected
without contest.
(1)

In every contested election under these Rules, a symbol shall
be allotted to all contesting candidates.

(2)

If, immediately after the expiry of the period within which
candidatures may be withdrawn under sub–rule (1) of Rule
44, the no. of validly nominated candidates is more than the
no. of vacancies to be filled for a Village Council, the Returning
Officer shall forthwith consider the allotment of symbols to
those contesting candidates who have not withdrawn their
candidatures.

(3)

For the purpose of these Rules, symbols are either “reserved”
or “free” as shown in Table–I and Table–II respectively in
the Appendix. A reserved symbol is a symbol which is reserved
for recognized political party for exclusive allotment to a
contesting candidate or candidates set up by that party. A free
symbol is a symbol other than a reserved symbol.

(4)

For the purposes of these Rules, a recognized political party
means a political party as may be recognized by the Election
Commission of India as a National Party or a State Party of
Mizoram as on the date of notification under Rule 37.

(5)

Subject to the provisions of sub–rule (3), a candidate set up
by a recognized political party shall choose, and be allotted,
the symbol reserved for that party and no other symbol.

(6)

Subject to the provisions of sub–rule (3), a candidate set up
by a registered but unrecognized political party shall be given
a preference of choosing any symbol out of the symbols
specified as “Free symbols”.

(7)

Any candidate other than a candidate of a recognized or a
registered but unrecognized political party shall choose and
be allotted one of the symbols specified as “free symbols”. If
the choices come into conflict, the Returning Officer shall
allot symbols in conformity, as far as possible, with the wishes
of the candidate and, if necessary, by lot and his decision shall
be final.

<!-- page 22 -->

Ex-10/2015

20
(8)

Each candidate or his election agent shall forthwith be shall
informed of the symbol allotted to the candidate and be given
a specimen thereof.

(9)

A candidate shall be deemed to be set up by a recognized
political party if–
(a)

the candidate has made a declaration to that effect in
his nomination paper;

(b)

a notice in writing in Form 12 to that effect has, not
later than 3:00 p.m. on the last date of withdrawal of
candidatures, been delivered to the Returning Officer;
and

(c)

the said notice is signed by the District President of the
recognized political party or any of his colleagues
authorised by him.

(10) A candidate shall be deemed to be set up by a registered but
unrecognized political party if–

(11)

(a)

the candidate has made a declaration to that effect in
his nomination paper,

(b)

a notice in writing in Form 12 to that effect has, not
later than 3:00 p.m. on the last date of withdrawal of
candidatures, been delivered to the Returning Officer,

(c)

the said notice is signed by the District President of the
registered but unrecognized political party or any of his
colleagues authorised by him, and

(d)

a copy of the letter registering the said political party
by the Election Commission of India is enclosed.

The Returning Officer shall then prepare a list in Form 13 of
all contesting candidates with their distinctive symbols and
display it on the wall of Polling Station and also in two or more
conspicuous places in the constituency.

(12) The list shall contain the names of contesting candidates as
prescribed in their nomination papers in alphabetical order and
in the same order as specified below:–
(a) candidates of recognized political parties;
(b) candidates of registered political parties with a reserved
symbol;
(c) candidates of registered political parties without a reserved
symbol;
(d) independent candidates.

<!-- page 23 -->

21

Ex-10/2015

Chapter – V
CONDUCT OF ELECTION
Polling Station.

47.

(1)

One or more Polling Station shall be set up for each
constituency depending upon the number of electors in the
Electoral Roll of the constituency. At each Polling Station,
there shall be set up one or more voting compartments in which
electors can record their votes free from observation.

(2)

The District Election Officer shall provide at each polling
station–
(a) a ballot box or boxes as may be necessary with reference
to the number of electors assigned to it;
(b) marked copies of the Electoral Roll of the constituency;
(c) ballot papers;
(d) materials for making voting compartments;
(e) arrow cross mark rubber stamp to mark ballot papers;
(f) distinguishing mark rubber stamp;
(g) seal of Presiding Officer;
(h) indelible ink;
(i) statutory and non–statutory forms, other papers and
stationery.

(3)

Outside each Polling Station, there shall be displayed
prominently–
(a) a copy of the list of contesting candidates and their
distinctive symbols in Form 13.
(b) a notice specifying the Polling area; and
(c) a notice showing the hours of poll.

Appointment of
Election Agent and
Polling Agent.

48.

(1)

Election Agent:
(a) A candidate at an election may appoint, in the prescribed
manner any one person other than himself to be his Election
Agent and when any such appointment is made, notice of
the appointment shall be given in the prescribed manner,
to the Returning Officer.

<!-- page 24 -->

Ex-10/2015

22
(b) Any person, who is, for the time being disqualified under
these Rules for being a member of a Village Council, shall
be disqualified for being an Election Agent at any election.
(c) The notice for appointment of an Election Agent shall be
in Form 14 and such notice with 2 copies shall be forwarded
to the Returning Officer and subject to the conditions of
clauses (a) & (b), the Returning Officer shall return one
copy thereof to the Election Agent after affixing thereon
his seal and signature as a token of his authority.
(d) An Election Agent may perform such functions in
connection with the election as are authorized by or under
these Rules to be performed by an Election Agent.
(e) Any revocation of the appointment of an Election Agent
in Form 15, shall be signed by the candidate, and shall
operate from the date on which it is lodged with the
Returning Officer.
(2)

Polling Agent:
(a) The number of Polling Agents that may be appointed by a
Contesting Candidate or his Election Agent, shall, in respect
of each Polling Station, be one agent and a relief agent.
(b) Every such appointment of Polling Agent shall be made in
Form 16 and the Polling Agent shall deliver it to the
Presiding Officer.
(c) No Polling Agents shall be admitted to the Polling Station
unless he has delivered to the Presiding Officer the
instrument of his appointment under sub–rule (2)(b) after
duly completing and signing before the Presiding Officer
the declaration contained therein.
(d) Any revocation of the appointment of a Polling Agent in
Form 17 shall be signed by the Candidate or his Election
Agent and shall operate from the date on which it is lodged
with such officer as may be prescribed, and in the event
of such a revocation or of the death of a Polling Agent
before the close of the poll, the Candidate or his Election
Agent may appoint in the prescribed manner another
Polling Agents at any time before the poll is closed and
shall forthwith give notice of such appointment in the
prescribed manner to such officer as may be prescribed;
(e) A Polling Agent may perform such functions in connection
with the poll as are authorised by or under these Rules, to
be performed by a Polling Agent.

<!-- page 25 -->

23
(3)

Ex-10/2015

Attendance of a Contesting Candidate or his Election Agent
at Polling Stations, and performance by him of the functions
of a Polling Agent:
(a) At every election where a poll is taken, each Contesting
Candidate at such election and his Election Agent shall
have a right to be present at any polling station provided
under Rule 48 for the taking of the poll.
(b) A Contesting Candidate or his Election Agent may himself
do any act or thing which any Polling Agent of such
Contesting Candidate, if appointed, would have been
authorised by or under these Rules to do, or may assist
any Polling Agent of such Contesting Candidate in doing
any such act or thing.
(c) The notice for appointment of an Election Agent shall be
in Form 14 and such notice with 2 copies shall be
forwarded to the Returning Officer and subject to the
conditions of clause (a) & (b), the Returning Officer shall
return one copy thereof to the Election Agent after affixing
thereon his seal and signature as a token of his authority.

(4)

Fixing the time
of Poll.

49.

Non–attendance of Polling Agent: Where any act or thing is
required or authorised by or under these Rules to be done in
the presence of the Polling Agents, the non–attendance of
any such agent or agents at the time and place appointed for
the purpose shall not, if the act or thing is otherwise duly done,
invalidate the act or thing done.

The State Election Commission shall fix the hours during which the
poll will be taken and the hours so fixed shall be published by notification
in the Official Gazette:
Provided that the total period allotted on any one day for polling
shall not be less than eight hours in between 7:00 A.M to 5:00 P.M.

Method of Voting.

Ballot Box.

50.

51.

(1)

At every election where a poll is taken under these Rules,
votes shall be given by ballot and no votes shall be received
by proxy:

(2)

Save as otherwise provided, all electors voting at an election
shall exercise their franchise in person at the Polling Station
provided under Rule 47.

(1)

There shall be a single ballot box for all contesting candidates
at each polling station. A ballot box shall be made of strong
materials such as plastic, wood, iron and shall be constructed
in such a way that ballot papers can be inserted therein but
cannot be withdrawn there-from without the box being
unlocked.

<!-- page 26 -->

Ex-10/2015

Ballot Papers.

Procedure for
voting by a voter
on election duty.

24

52.

53.

(2)

Every ballot box used at a Polling Station shall bear label outside
and marked with the number & name of the Constituency,
and the serial number of the Polling Station if more than one
Polling Station are set up for one Village Council.

(3)

Immediately before the commencement of the poll, the
Presiding Officer shall demonstrate to the contesting
candidates, polling agents and other persons who are present
that the ballot box is empty and bears the labels referred to in
sub–rule (2).

(4)

The ballot box shall then be closed, sealed and secured and
placed in full view of the Presiding Officer and the Polling
Agents.

(1)

Every ballot paper shall be in Form 20 with a counterfoil portion
shall be provided a space for signature or thumb impression
of elector just above the words “Signature or Thumb
Impression” on the right hand side.

(2)

On each ballot paper the names of all contesting candidates
shall be printed with their respective symbols in the order in
which their names are published under sub–rule (12) of Rule
46 in Form 13.

(3)

The ballot papers shall be serially numbered and shall be
stamped on their reverse by such distinguishing marks, so that
the determination of a ballot paper as the original part of a
counter–foil can be determined or in such a manner as the
State Election Commission may direct from time to time.

(1)

A voter on election duty, who wishes to vote, shall, at least
five days before the date of poll, approach the District Election
Officer concerned and make an application in Form 21 for
the issuance of the ballot paper in order to enable him to cast
his vote as may be prescribed by the State Election
Commission.

(2)

The District Election Officer shall, on being satisfied as to the
identity of such voter on production of the letter of appointment
in connection with the election–
(a) have the person’s name marked in the electoral roll; and
(b) issue to such voter a ballot paper and permit him to vote
on the spot with instrument provided for the purpose.

(3)

After recording his vote, such voter shall make over the ballot
paper to the District Election Officer in a sealed cover for
onward dispatch to the Returning Officer concerned.

<!-- page 27 -->

25

Ex-10/2015

(4) The District Election Officer shall keep the counterfoil of
such ballot paper in a separate sealed cover and keep the
cover containing the ballot paper in his safe custody.
Challenging of
identity.

54.

(1) Any Polling agent may challenge the identity of a person
claiming to be a particular elector by first depositing a
sum of rupees ten in cash with the Presiding Officer for
each such challenge.
(2) In the case of challenge made under sub-rule (1) the
Presiding Officer shall–
(a)

warn the person challenged of the penalty for
personation;

(b)

read the relevant entry in the electoral roll in full
and ask him whether he is the person referred to
in that entry;

(c)

enter his name and address in the list of challenged
votes in Form 22; and

(d)

require him to affix his signature in the said list.

(3) The Presiding Officer shall thereafter hold a summary
inquiry into the challenge and may for that purpose,–
(a)

require the challenger to adduce evidence in proof
of the challenge and the person challenged to
adduce evidence in proof of his identity;

(b)

put to the person challenged any questions
necessary for the purpose of establishing his
identity require him to answer them on oath; and

(c)

administer an oath to the person challenged and
any other person offering to give evidence.

(4) If, after the inquiry, the Presiding Officer considers that
the challenge has not been established he shall allow the
person challenged to vote; and if he considers that the
challenge has been established, he shall debar the person
challenged from voting.
(5) If the Presiding Officer is of the opinion that the challenge
is frivolous or has not been made in good faith, he shall
direct that the deposit made under sub–rule (1) be forfeited
to District Council, and in any other case, he shall return
to the challenger at the conclusion of the inquiry.

<!-- page 28 -->

Ex-10/2015
Safeguards against
personation.

Identification
of electors.

Issue of ballot papers.

26
55.

56.

57.

(1)

Every elector about whose identity the Presiding Officer or
the Polling Officer, as the case may be, is satisfied, shall allow
his left forefinger to be inspected by the Presiding Officer or
Polling Officer and indelible ink mark to be put on it.

(2)

If any elector refuses to allow his left forefinger to be inspected
or marked, in accordance with sub–rule (1) or has already
such a mark on his left forefinger or does any act with a view
to removing the ink mark, he shall not be supplied with any
ballot paper or allowed to vote.

(3)

Any reference in this Rule to the left forefinger of an elector
shall, in the case where the elector has his left forefinger
missing, be construed as a reference to any other finger of his
left hand, and shall, in the case where all the fingers of his left
hand are missing, be construed as a reference to the forefinger
or any other finger of his right hand, and shall, in the case
where all his fingers of both the hands are missing, be construed
as a reference to such extremity of his left or right arm as he
possesses.

(1)

As each elector enters the polling station, the Presiding
Officer or the Polling Officer authorised by him in this behalf
shall check the elector’s name and other particulars with the
relevant entry in the electoral roll and then call out the serial
number, name and other particulars of the elector.

(2)

Every elector shall produce identity card issued to him under
the provisions of the Registration of Electors Rules, 1960 made
under the Representation of the People Act, 1950 or any such
documents as may be specified, by order, by the State Election
Commission before the Presiding Officer or the Polling Officer
authorized by him in this behalf, in order to establish his identity
at the polling station.

(3)

In deciding the right of a person to cast his vote, the Presiding
Officer or the Polling Officer, as the case may be, shall over
look the clerical or printing errors in an entry in the electoral
roll if he is satisfied that such person is identical with the elector
to whom such entry relates.

(1)

Before any ballot paper is delivered to an elector, the Presiding
Officer shall sign his name in full on the back of the ballot
paper.

(2)

At the time of issuing a ballot paper to the elector, the signature
or thumb impression of the elector shall be taken on the
counterfoil of the ballot paper. No ballot paper shall be delivered
to the elector unless he puts his signature or thumb impression
on the counterfoil of the ballot paper.

<!-- page 29 -->

27

Voting procedure.

58.

Ex-10/2015

(3)

After the elector put his signature or thumb impression as at
sub–rule (2), the Polling Officer shall record on the counterfoil, the serial number of the elector as at the electoral roll and
then deliver the ballot paper to the elector.

(4)

The Polling Officer in–charge of the marked copy of the
electoral roll shall mark the name of the elector in the marked
copy by underlining the entry, and if elector is a female, put a
tick mark also on the left hand side of the name of the elector.

(5)

No person in the polling station shall be allowed to note down
the serial number of ballot paper issued to a particular elector.

(6)

Each elector shall be given only one ballot paper for each
election. Every elector to whom a ballot paper has been issued
shall maintain secrecy of voting and for that purpose observes
the voting procedure hereinafter laid down.

(1)

On receiving the ballot paper, the elector shall–
(a) forthwith proceed to the voting compartment and there,
with the aid of the instruments supplied for the purpose,
mark the ballot paper on or near the symbol of the
candidate in case of an election for one seat, or on or
near the symbols of the candidates in case of multiple
election for more than one seats, for whom he intends to
vote; and
(b) fold the ballot paper first vertically and then horizontally
so as to conceal his vote and put it into the ballot box kept
for the purpose.

(2)

Every elector shall vote without any undue delay and shall
quit the Polling Station as soon as he has voted.

(3)

No elector shall be allowed to enter a voting compartment
when another elector is inside it.

(4)

If an elector to whom a ballot paper has been issued, refuses
after warning given by the Presiding Officer to observe the
procedure laid down in sub–rule (1), the ballot paper issued to
him shall, whether he has recorded his vote therein or not, be
taken back from him by the Presiding Officer or Polling Officer
under the direction of the Presiding Officer.

(5)

After the ballot paper has been taken back, the Presiding
Officer shall record on its back the words “Cancelled–Voting
procedure violated” and put his signature below these words.

<!-- page 30 -->

Ex-10/2015

Marking of ballot
paper in excess
or deficit.

Recording of votes
of illiterate or blind
or infirm electors.

28

59.

60.

(6)

All the ballot papers on which the words “Cancelled–Voting
procedure violated” are recorded shall be kept in the cover
for unused ballot papers, and shall in no way be counted as
votes.

(1)

If any elector gives votes on ballot paper in favour of more
candidates than the vacancy or vacancies for filling which the
election is held, then at the counting of votes, his vote shall be
invalid and rejected as void.

(2)

If any elector gives on the ballot paper in favour of less
candidates than the vacancies for filling which the multiple
election is held, his vote shall be valid and counted at the
counting of votes.

(1)

If the Presiding Officer is satisfied that owing to old age or
blindness or other physical infirmity or illiteracy, an elector is
unable to recognize the names of the contesting candidates
and their symbols on the ballot paper or to make a mark thereon,
the Presiding Officer shall permit the elector to take with him
a companion of not less than eighteen years of age to the
voting compartment for recording the vote on the ballot paper
on his behalf and in accordance with his wishes, and, if
necessary, for folding the ballot paper so as to conceal the
vote and inserting it into the ballot box:
Provided that no person shall be permitted to act as the
companion of more than one elector at any Polling Station on
the same day;
Provided further that before any person is permitted to
act as the companion of an elector under this Rule, the person
shall be required to declare in Form 23 that he will keep secret
the vote recorded by him on behalf of the elector and that he
has not already acted as the companion of any other elector
at any Polling Station on that day.

Spoilt and returned
ballot papers.

61.

(2)

The Presiding Officer shall keep a record in Form 24 of all
such cases under this Rule.

(1)

An elector who has inadvertently dealt with his ballot paper
in such manner that it cannot be conveniently used as ballot
paper may on returning it to the Presiding Officer or Polling
Officer and on satisfying him of the inadvertence, be given
another ballot paper and the ballot paper so returned shall be
marked “Spoilt–cancelled” by Presiding Officer.

(2)

If an elector after obtaining a ballot paper desires not to use it
he shall return it to the Presiding Officer or Polling Officer
and the ballot paper so refused shall be marked “Refused–
cancelled” by the Presiding Officer.

<!-- page 31 -->

29

Adjournment of poll
in emergencies.

Fresh poll in the
case of destruction
etc. of ballot boxes.

62.

63.

Ex-10/2015

(3)

All ballot papers cancelled under sub–rule (1) or (2) shall be
kept in the cover for unused ballot papers.

(1)

If at an election the proceedings at any polling station are
interrupted or obstructed by any riot or open violence, or if at
an election, it is not possible to take the poll at any polling
station or such place on account of any natural calamity, or
any other sufficient cause, the Presiding Officer for such polling
station or the Returning Officer presiding over such place, as
the case may be, shall announce an adjournment of the poll to
a date to be notified later, and where the poll is so adjourned
by a Presiding Officer, he shall forthwith inform the District
Election Officer and the Returning Officer concerned.

(2)

Whenever a poll is adjourned under sub–rule (1), the Returning
Officer shall immediately report the circumstances to the
appropriate authority and the State Election Commission, and
shall, as soon as may be, with the previous approval of the
State Election Commission, appoint the day on which the poll
shall recommence, and fix the polling station or place at which
and the hours during which the poll will be taken and shall not
count the votes cast at such election until such adjourned poll
shall have been completed.

(3)

In every such case as aforesaid; the Returning Officer shall
notify in such manner as the State Election Commission may
direct the date, place and hours of polling fixed under sub–
rule (2).

(1)

If at any election–

(2)

(a)

any ballot box used at Polling Station is unlawfully
taken out of the custody of the Presiding Officer
or is accidentally or intentionally destroyed or lost,
or is damaged or tampered with to such an extent
that the result of the poll at that Poling Station
cannot be ascertained; or

(b)

any such error or irregularity in procedure, as is
likely to vitiate the poll, is committed at a Polling
Station, the Presiding Officer shall forthwith report
the matter to the Returning Officer and the District
Election Officer.

There–upon the State Election Commission shall, after
taking all material circumstances into account, either–
(a)

declare the poll at that Polling Station to be void;
appoint a day and fix the hours, for taking a fresh
poll at that Polling Station, and notify the day so
appointed and the hours so fixed in such manner
as he may deem fit; or

<!-- page 32 -->

Ex-10/2015

30
(b)

Tendered votes.

64.

issue such directions to the Returning Officer as
it may deem proper for the further conduct and
completion of the election, provided the Commission is satisfied that the result of a fresh poll at
that polling station or place will not, in any way,
affect the result of the election or that the error
or irregularity in procedure is not material.

(3)

The provisions of these Rules shall apply to every such fresh
poll as they apply to the original poll.

(1)

If a person representing himself to be a particular elector
applies for a ballot paper after another person has already
voted as such elector, he shall on satisfactorily answering such
questions relating to his identity as the Presiding Officer may
ask, be entitled, subject to the following provisions of this Rule,
to mark a ballot paper (hereinafter in these Rules referred to
as a ‘Tendered Ballot Paper’) in the same manner as any
other elector.

(2)

Every such person shall, before being supplied with tendered
ballot paper, sign his name against the entry relating to him in
a list in Form 25.

(3)

A tendered ballot paper shall be the same as the other ballot
papers used at the Polling Station except that it shall be–
(a) serially the last in the bundle of ballot papers issued for
use at the Polling Station; and
(b) endorsed on the back with the words, “Tendered Ballot
Paper” by the Presiding Officer in his own hand and signed
by him.

(4)

The elector, after marking a tendered ballot paper in the voting
compartment and folding it, shall instead of putting it into ballot
box, give it to the Presiding Officer, who shall place it in a
cover specially kept for the purpose:
Provided that if there is reasonable ground for believing
that the person, by applying for tendered ballot paper, has
committed the offence of personating, the Presiding Officer
shall immediately direct the Police to arrest him.

Sealing of ballot
boxes after poll.

65.

(5)

All ballot papers cancelled under sub–rule (1) or sub–rule (2)
shall be kept in a separate packet.

(1)

As soon as practicable after the closing of the poll, the
Presiding Officer shall close the ballot box, and seal up the
box and also allow any polling agent present to affix his seal.

<!-- page 33 -->

31

Ex-10/2015

(2)

The ballot box shall thereafter be sealed and secured.

(3)

Where it becomes necessary to use a second ballot box by
reason of the first ballot box getting full, the first box shall be
closed, sealed and secured as provided in sub–rule (1) and (2)
before another ballot box is put into use.

Ballot paper account
of Presiding Officer.

66.

The Presiding Officer shall at the close of the poll prepare a ballot
paper account in Form 26 and enclose it in a separate cover with the
words “Ballot paper account of Presiding Officer” superscribe thereon
showing the number & name of the Village Council and the date of
election on the cover.

Sealing of other
packets.

67.

(1)

The Presiding Officer shall then make into separate packets–
(a) the marked copy of the electoral roll;
(b) the unused ballot paper;
(c) the cancelled ballot papers;
(d) the cover containing the tendered ballot papers and Form
25.
(e) declaration of companion of illiterate or blind or infirm
elector in Form 23 with the record in Form 24; and
(f) any other papers directed by District Election Officer to
be kept in a sealed packet.

(2)

Each such packet shall be sealed with the seals of the
Presiding Officer and of those polling agents who may desire
to affix their seals thereon.

Chapter – VI
COUNTING OF VOTES, APPOINTMENT OF COUNTING AGENT
AND SEALING OF ELECTION PAPERS

Appointment of place
and time for counting
of votes, Appointment
of Counting Agent,
Admission to the
place of counting
of votes, etc.

68.

(1)

Appointment of place and time for counting of votes:
Counting of votes shall be taken up as soon as possible after
the close of the poll and the Returning Officer shall appoint
the place and time of counting of votes and inform the
candidates or their Election Agents. The Returning Officer
may appoint any public servant or servants available as may
be necessary to assist him in the counting of votes.

<!-- page 34 -->

Ex-10/2015

32
(2)

Appointment of Counting Agent:
(a) A Contesting Candidate or his Election Agent may appoint
in the prescribed manner one or more persons, but not
exceeding such number as may be prescribed by the State
Election Commission, to be present as his Counting Agent
or Agents at the counting of votes, and when any such
appointment is made notice of the appointment in Form
18 shall be given, in the prescribed manner, to the Returning
Officer.
(b) Any revocation of the appointment of a Counting Agent
shall be signed by the Candidate or his Election Agent in
Form 19 and shall operate from the date on which it is
lodged with the Returning Officer, and in the event of
such revocation or of the death of a Counting Agent
before the commence-ment of the counting of votes, the
Candidate or his Election Agent may appoint in the
prescribed manner another Counting Agent at any time
before the counting of votes is commenced and shall
forthwith give notice of such appointment in the prescribed
manner to the Returning Officer.

Admission to the
place of counting
of votes, etc.

69.

(3)

Non–attendance of Counting Agent: Where any act or
thing is required or authorised by or under these Rules to be
done in the presence of the Counting Agents, the nonattendance of any such agent or agents at the time and place
appointed for the purpose shall not, if the act or thing is
otherwise duly done, invalidate the act or thing done.

(1)

The Returning Officer shall exclude from the place fixed for
counting of votes all person except–
(a) such person to be known as counting supervisors and
counting assistants as he may appoint to assist him in the
counting;
(b) the candidate/election agent and his counting agents duly
authorized in writing by candidate;
(c) persons authorized by the State Election Commission, if
any; and
(d) public servants on duty in connection with the election.

(2)

Any person who during the counting of votes misconducts
himself or fails to obey the directions of the Returning Officer
may be removed from the place by any Police Officer on
duty or by any other person authorized in this behalf by the
Returning Officer.

<!-- page 35 -->

33
(3)

Ex-10/2015

The Returning Officer shall, before the commencement of
the counting, briefly explain the counting procedure to all those
allowed admission in the counting place under sub-rule (1)
and caution them as to the maintenance of secrecy, the violation
of which shall be an electoral offence under Rule 91.

Scrutiny and
opening of
ballot boxes.

70.

The Returning Officer shall satisfy himself that the ballot box is intact,
and also allow the candidates present to inspect the seals on the
ballot box to satisfy themselves that it is intact, and thereafter open
the ballot box.

Scrutiny and
rejection of
ballot papers.

71.

(1)

The ballot papers taken out of the ballot box shall be arranged
in convenient bundles and scrutinized.

(2)

It shall be noted clearly and carried out severally that in a
multiple election, a single ballot paper consist of as many votes
as there are vacancies to be filled. There–upon, a particular
vote or votes found to be invalid on a ballot paper do not
invalidate the whole ballot paper while certain votes recorded
thereon may be clear and valid.

(3)

The Returning Officer shall reject any ballot paper in whole
only if–
(a) it is a spurious ballot paper; or
(b) it bears any mark or writing by which the elector can be
identified; or
(c) no vote is recorded thereon; or
(d) votes are recorded on it in favour of more candidates than
there are vacancies to be filled; or
(e) it is so damaged or mutilated that its identity as a genuine
ballot paper cannot be established; or
(f) it bears a serial number, or a design different from the
serial number or design of the ballot papers authorized for
use at the particular polling station; or
(g) it does not bear the mark which it would have borne under
the provisions of sub-rule (2) of Rule 52.
Provided that where the Returning Officer is satisfied that
any such defect as is mentioned in clause (f) or clause (g) has
been caused by any mistake or failure on the part of a Presiding
Officer or Polling Officer, the ballot paper shall not be rejected
merely on the ground of such defect.

<!-- page 36 -->

Ex-10/2015

34

Rejection of
particular vote
recorded on a
ballot paper.

(4)

Before rejecting any ballot paper under sub–rule (3), the
Returning Officer shall allow each candidate present a
reasonable opportunity to inspect the ballot paper but shall not
allow him to handle it or any other ballot paper.

(5)

The Returning Officer shall record on every ballot paper which
he rejects the letter ‘R’ and the grounds of rejection in
abbreviated form either in his own hand or by means of a
rubber stamp.

(6)

All ballot papers rejected under this Rule shall be bundled
together.

72.

The Returning Officer shall reject a particular vote as invalid
vote if the mark indicating the vote on a ballot paper is placed
in such a manner so as to make it doubtful to which candidate the vote has been given:
Provided that a vote shall not be rejected as invalid merely
on the ground that the mark indicating the vote is indistinct or
made more than once, if the intention that the vote shall be for
a particular candidate clearly appears from the way the paper
is marked.

Counting of votes.

73.

(1)

Each valid vote recorded on ballot paper which is not rejected,
shall be counted as one valid vote:
Provided that no cover containing tendered ballot papers
shall be opened and no such paper shall be counted.

Re-count of votes.

74.

(2)

The Returning Officer shall count all valid votes in all valid
ballot papers and also the total number of valid votes polled by
each candidate. Round–wise counting sheet, counting table–
wise results tabulation sheet and round–wise tabulation sheet
shall be in Form 27, 28 and 29 respectively.

(3)

The candidate or his counting agent shall be allowed full view
of the counting process and sufficient proximity so as to enable
him to discern the votes cast on each ballot paper and also on
the record of votes for tabulation. Under no circum-stances
shall physical contact with the ballot paper for him or his
counting agent be allowed.

(1)

After the completion of the counting of votes under Rule 73,
the Returning Officer shall record in the result sheet in Form
30 the total number of votes recorded in favour of each
candidate and announce the particulars.

<!-- page 37 -->

35

Ex-10/2015

(2)

After the announcement of particulars so made, a candidate
or, in his absence his election agent may apply in writing to the
Returning Officer to recount the ballot papers either wholly
or in part stating the grounds on which he demands such re–
count.

(3)

On such an application being made the Returning Officer shall
decide the matter and may allow the application in whole or in
part or may reject it, in toto if it appears to him to be frivolous
or unreasonable.

(4)

Every decision of the Returning Officer under sub–rule (3)
shall be in writing and shall contain the reasons thereof.

(5)

If the Returning Officer decides under sub–rule (3) to allow
an application either wholly or in part, he shall,–
(a) re–count the ballot papers in accordance with Rules 71,
72 and 73;
(b) amend the result sheet in Form 30 to the extent necessary
after such re–count; and
(c) announce the particulars of amendments so made by him.

(6)

After the total number of votes polled by each candidate has
been announced under sub–rule (5), the Returning Officer
shall complete and sign the result sheet in Form 30 and no
application for a re–count shall be entertained thereafter:
Provided that no step under this sub–rule shall be taken
on the completion of the counting of votes until the candidates
and election agents present at the completion thereof have
been given a reasonable opportunity to exercise the right
conferred by sub–rule (3) of Rule 73.

Declaration of
result of election.

75.

On completion of procedures under Rule 73 the Returning
Officer shall forthwith, subject to the provisions of Rule 74
declare as elected–
(a) in the case of multiple election, as many candidates
standing at the top of the poll in descending order as there
are vacancies to be filled; or
(b) in the case of an election to fill one vacancy, the candidate
who obtains the largest number of valid votes.

Equality of votes.

76.

If, after the counting of the votes is completed, an equality of
votes is found to exist between any candidates and the addition
of one vote will lead to any of those candidates being declared
elected, the Returning Officer shall forthwith decide between
those candidates by lot, and proceed as if the candidate on
whom the lot falls had received the additional vote.

<!-- page 38 -->

Ex-10/2015
Publication of
election results.

36
77.

(1)

The Returning Officer shall prepare the election results in
Form 30 and send the results to the State Election Commission
and also to the District Election Officer.

(2)

The Returning Officer shall also display the election result in
Form 30, in the Notice Board of the constituency.

(3)

On receipt of all the results from the District Election Officer
or the Returning Officer, the State Election Commission shall
publish the election results in the Official Gazette.

Grant of certificate
of election to
returned candidate.

78.

As soon as may be after the declaration of the election result, the
Returning Officer shall grant to each returned candidate a certificate
of election in Form 31.

Ballot Paper account
of Returning Officer.

79.

(1)

The Returning Officer shall prepare a ballot paper account in
Form 32 which shall consist of–
(a) total number of ballot papers found in the ballot box or
boxes;
(b) total number of rejected ballot papers under sub–rule (3)
of Rule 71;
(c) total number of valid ballot papers i.e. ballot papers which
are not rejected;
(d) total number of votes contained by the total number of
valid ballot papers i.e. total number of valid ballot papers
multiplied by total number of vacancies to be filled;
(e) total number of invalid votes on all valid ballot papers;
(f) total number of valid votes on all valid ballot papers i.e.
(d) minus (e).

Packet of election
papers and sealing.

80.

(2)

The Returning Officer shall enclose the ballot paper account
in a separate cover with the words “Ballot paper account of
Returning Officer” subscribed thereon and showing the name
of the Village Council and the date of counting of votes, and
submit the cover to the District Election Officer along with
the election result.

(1)

The Returning Officer shall make a packet of election papers
consisting of–
(a) a bundle of all valid ballot papers;
(b) a bundle of rejected ballot papers under sub–rule (3) of
Rule 71;

<!-- page 39 -->

37

Ex-10/2015

(c) a copy of ballot paper account of Returning Officer under
sub–rule (1) of Rule 79; and
(d) a copy of election result under Rule 77.
(2)

The packet shall be sealed with the seal of Returning Officer
and of those candidates who may desire to affix their seals
thereon.

(3)

The Returning Officer shall submit to the District Election
Officer–
(a) the packet under this Rule;
(b) the cover containing the ballot paper account of Presiding
Officer under Rule 66; and
(c) all other packets under Rule 67.

Safe keeping of the
packet containing
election papers.

81.

Custody of ballot
boxes and papers
relating to election.

82.

While in the custody of the District Election Officer, the packets
and cover under sub–rule (3) of Rule 80, shall not be inspected
by, or produced before, any person or authority except under
order of an Election Tribunal appointed under Rule 86.
(1)

All ballot boxes used at an election shall be kept in such
custody as the State Election Commission may direct.

(2)

The District Election Officer shall keep in safe custody–
(a) the packets of unused ballot papers with counterfoils
attached thereto;
(b) the packets of used ballot papers whether valid, tendered
or rejected;
(c) the packets of counterfoil of used ballot papers ;
(d) the packets of marked copy of the electoral roll;
(e) the packets of the declaration by electors:
(f) all other paper relating to election and they shall not be
opened except under the order of a competent authority.

Disposal of
Election Papers.

83.

Subject to any direction given by the State Election Commission
or by a competent court or Tribunal–

<!-- page 40 -->

Ex-10/2015

38
(a) the packets of unused ballot papers shall be retained for a
period of forty five days and shall thereafter be destroyed
in such manner as the State Election Commission may
direct ;
(b) the other packets referred to in sub–rule (2) of Rule 82
shall be retained for a period of one year and shall
thereafter be destroyed:
Provided that packets containing the counterfoil of used
ballot paper shall not be destroyed except with the approval
of the State Election Commission;
(c) all other papers relating to the election shall be retained
for such period as the State Election Commission may
direct.

Chapter – VII
DISPUTES REGARDING ELECTION
Election petition.

84.

(1)

An election petition challenging the validity of election of any
returned candidate may be presented by a contesting candidate
of such election on one or more grounds specified in Rule 88.

(2)

No election petition shall be presented on a mere ground–
(a) that the name of any person qualified to vote has been
omitted from the electoral roll; or
(b) that the name of any person not qualified to vote has been
included in the electoral roll.

(3)

A petitioner shall join as respondents to his petition any or all
contesting candidates at the election.

(4)

A petitioner may in addition to challenging the validity of any
returned candidate, make further claim that himself shall be
declared duly elected.

(5)

An election petition shall–
(a) contain a concise statement of the material facts on which
the petitioner relies;
(b) set forth with sufficient particulars the ground or grounds
on which the validity of an election is challenged;
(c) in the case of sub–rule (4), set forth the ground or grounds
on which he claims himself to be declared as elected; and

<!-- page 41 -->

39

Ex-10/2015

(d) be companied by a deposit of Rupees three hundred as
the petition fee which is not refundable.
(6)

Action to be taken
by State Election
Commission.

85.

An election petition may be submitted to the State Election
Commission within twenty–one days from the date of
publication of the election result.
As soon as may be after the receipt of an election petition the
State Election Commission shall–
(a) inform the District Election Officer to retain packets and
other papers referred to in Rule 81 of the concerned
Village Council in respect of which the election petition
has been presented; and
(b) as soon as possible after the constitution of Election
Tribunal under Rule 86, send the election petition to the
Election Tribunal for its disposal.

Election Tribunal.

86.

Powers of Election
Tribunal.

87.

The State Election Commission may, by a notification published
in the Official Gazette, constitute an Election Tribunal
consisting of a Chairman and two Members to hear, examine
and dispose of all election petitions under these Rules.
It shall be open to the Election Tribunal to–
(a) direct the petitioner, all or any of the respondents and any
other persons to appear in person whenever it considers
necessary;
(b) enforce the attendance of witnesses;
(c) compel the production and examination of the packets and
other papers referred to in Rule 81; and
(d) examine the witnesses on oath.

Grounds for
declaring to be void.

88.

(1)

Subject to the provisions of section 4 of the Act, if the
Election Tribunal is of the opinion–
(a) that on the date of his election a returned candidate was
not qualified or was disqualified, to be chosen as a member
under these Rules; or
(b) that any corrupt practice has been committed by a returned
candidate or his agent or by any other person with the
consent of a returned candidate or his agent; or
(c) that any nomination paper has been improperly rejected;
or

<!-- page 42 -->

Ex-10/2015

40
(d) that the result of the election, in so far as it concerns a
returned candidate, has been materially affected–
(i) by improper acceptance of any nomination; or
(ii) by any corrupt practice committed in the interest of the
returned candidate by a person other than that candidate
or his agent or a person acting with the consent of such
candidate or agent; or
(iii) by improper acceptance or refusal of any vote or reception
of any vote which is void; or
(iv) by non–compliance with the provisions of the Act or these
Rules or orders made there-under, the Election Tribunal
shall declare the election of the returned candidate to be
void.
(2)

If in the opinion of the Election Tribunal a returned candidate
has been guilty by an agent, of any corrupt practice, but the
Tribunal is satisfied–
(a) that no such corrupt practice was committed at the election
by the candidate, and every such corrupt practice was
committed contrary to the orders, and without the consent
of the candidate;
(b) that the candidate took all reasonable means for preventing
the commission of corrupt practices at the election; and
(c) that in all other respects the election was free from any
corrupt practice on the part of the candidate or any of his
agents, then the Election Tribunal may decide that the
Election of the returned candidate is not void.

Decision of the
Election Tribunal.

89.

(1)

It shall be the duty of the Election Tribunal to dispose of any
election petition within one hundred twenty days from the date
on which the election petition was sent to them under clause
(b) of Rule 85.

(2)

At the conclusion of the trial of an election petition, the Election
Tribunal shall make order–
(a) dismissing the election petition; or
(b) declaring the election of the returned candidate to be void.

(3)

If the petitioner has, in addition to challenging the validity of
the election of any returned candidate, claimed declaration

<!-- page 43 -->

41

Ex-10/2015

that he himself has been duly elected, and the Election Tribunal
is of opinion that the claim of the petitioner is correct, the
Election Tribunal shall, after declaring the election of the
returned candidate to be void, declare the petitioner to have
been duly elected.
(4)

The Election Tribunal shall report its findings and decisions to
the State Election Commission where–upon the State Election
Commission shall notify the decision of the Tribunal and a
copy of the same shall be sent to the petitioner, the concerned
candidate whose election was challenged, the Executive
Committee and the District Election Officer.

(5)

The decision of the Election Tribunal under this Rule shall be
final and binding.

Chapter – VIII
ELECTORAL OFFENCES
Prohibition of
public meeting on
the date of poll.

Maintenance of
Secrecy of voting.

Officer, etc., at
elections not to act
for candidates or to
influence voting.

90.

91.

92.

(1)

No person shall convene, hold or attend any public meeting
within any polling area on the date or dates on which a poll is
taken for an election in that polling area.

(2)

Any person who contravenes the provisions of sub–rule (1)
shall be punishable with fine which may extend to Rupees
two hundred.

(1)

Every officer, clerk, agent or other person who performs any
duty in connection with the recording or counting of votes at
an election shall maintain, and aid in maintaining, the secrecy
of the voting and shall not communicate to any person any
information calculated to violate such secrecy.

(2)

Any person who contravenes the provisions of sub–rule (1)
shall be punishable with imprisonment for a term which may
extend to six months or with fine or with both.

(1)

No person who is a Magistrate or a Presiding Officer or Polling
Officer at an election shall in the conduct of or the management of the election do any act (other than the giving of vote)
for the furtherance of the prospects of the election of a
candidate.

(2)

No such person as aforesaid, and no member of a Police force,
shall endeavour–
(a) to persuade any person to give his vote at an election; or
(b) to dissuade any person from giving his vote at an election;
or

<!-- page 44 -->

Ex-10/2015

42
(c) to influence the voting of any person at an election in any
manner.
(d) any person who contravenes the provisions of sub–rule
(1) or sub–rule(2) shall be punishable with imprisonment
which may extend to three years or with fine or with both.

Prohibition of
canvassing in or
near polling stations.

93.

(1)

No person shall, on the date or dates on which a poll is taken
at any polling station, commit any of the following acts within
the polling station or in any public or private place within a
distance of one hundred metres of the polling station, namely:
(a) canvassing for votes; or
(b) soliciting the vote of any elector; or
(c) persuading any elector not to vote for any particular
candidates; or
(d) persuading any elector not to vote at the election; or
(e) exhibiting any notice or sign (other than an official notice)
relating to the election.

Penalty for
disorderly conduct
in or near polling
stations.

94.

(2)

Any person who contravenes the provisions of sub–rule (1)
shall be punishable with imprisonment for a term which may
extend to three months or with fine which may extend to
rupees one thousand.

(3)

An offence punishable under this Rule shall be cognizable.

(1)

No person shall, on the date or dates which a poll is taken at
any polling station–
(a) use or operate within or at the entrance of the polling
station or in any public or private place in the neighbourhood thereof, any apparatus for amplifying or reproducing the human voice, such as a megaphone or a loud
speaker;
or
(b) shout or otherwise act in a disorderly manner so as to
cause annoyance to any person visiting the polling station
for the poll, or so as to interfere with the work of the
officers and other persons on duty at the polling station.

(2)

Any persons who contravenes, or willfully aids or abets the
contravention of, the provisions of sub–rule (1) shall be
punishable with the imprisonment which may extend to three
months or with fine or with both.

<!-- page 45 -->

43

Penalty for
misconduct at the
polling station.

Removal of ballot
papers from polling
station to be an
offence.

95.

96.

Ex-10/2015

(3)

If the Presiding Officer of a polling station has reason to
believe that any person is committing or has committed an
offence punishable under these Rules, he may direct any Police
Officer to arrest such person, and thereupon the Police Officer
shall arrest him.

(4)

Any Police Officer may take such steps, and use such force,
as may be reasonably necessary for preventing any
contravention of the provisions of sub–rule (1), and may seize
any apparatus used for such contravention.

(1)

Any person who during the hours fixed for the poll at any
polling station misconducts himself or fails to obey the lawful
directions of the Presiding Officer may be removed from the
polling stations by the Presiding Officer or by any Police Officer
on duty or by any person authorized in this behalf by such
Presiding Officer.

(2)

The powers conferred by sub–rule (1) shall not be exercised
so as to prevent any elector who is otherwise entitled to vote
at a polling station from having an opportunity of voting at that
station.

(3)

If any person who has been so removed from a polling station
re-enters the polling station without the permission of the
Presiding Officer shall be punishable with imprisonment for a
term which may extend to three years or with fine which may
extend to rupees one thousand or with both.

(4)

An offence punishable under sub–rule (3) shall be cognizable.

(1)

Any person who at any election fraudulently takes, or attempts
to take, a ballot paper out of a polling station, or willfully aids
or abets the doing on any such act, shall be punishable with
imprisonment for a term which may extend to one year or
with fine which may extend to Rupees five hundred or with
both.

(2)

If the Presiding Officer of a Polling station has reason to
believe that any person is committing or has committed an
offence punishable under sub–rule (1), such officer may, before
such person leaves the polling station, arrest or direct a Police
Officer to arrest such person and may search such person or
cause him to be searched by a Police Officer:
Provided that when it is necessary to cause a woman to
be searched, the search shall be made by another woman
with strict regard to decency.

<!-- page 46 -->

Ex-10/2015

Other offences and
penalties thereof.

44

97.

(3)

Any ballot paper found upon the person arrested on search
shall be made over for safe custody to a Police Officer by the
Presiding Officer, or when the search is made by a Police
Officer, shall be kept by such officer in safe custody.

(4)

An offence punishable under sub–rule (1) shall be cognizable.

(1)

A person shall be guilty of an electoral offence if at any
election he–
(a) fraudulently defaces or fraudulently destroys any
nomination paper; or
(b) fraudulently defaces, destroys or removes any list, notice
or other documents affixed by or under the authority of a
Magistrate or the Returning Officer or the Presiding
Officer; or
(c) fraudulently defaces or fraudulently destroys any ballot
paper or the official mark on any ballot paper or any
declaration of identity or official envelope used in
connection with voting; or
(d) without due authority supplies any ballot paper to any
person or receives any ballot from any person or is in
possession of any ballot paper; or
(e) fraudulently puts into any ballot box anything other than
the ballot paper which he is authorized by law to put in; or
(f) without due authority destroys, takes, opens or otherwise
interferes with any ballot box or ballot papers then in use
for the purposes of the election; or
(g) fraudulently or without due authority, as the case may be,
attempts to do any of the foregoing acts or willfully aids
or abets the doing of any such acts.

(2)

Any person guilty of an electoral offence under this Rule shall
be punishable with imprisonment which may extend to six
months or with fine or with both.

(3)

For the purpose of this Rule, a person shall be deemed to be
on official duty if his duty is to take part in the conduct of an
election or part of an election including the counting of votes
or to be responsible after an election for the used ballot papers
and other documents in connection with such election.

(4)

An offences punishable under sub–rule (2) shall be cognizable.

<!-- page 47 -->

45

Ex-10/2015

Penalty for
corrupt practice.

98.

Whoever commits a corrupt practice at an election shall be punishable
with a fine not exceeding five hundred rupees.

Breaches of official
duty in connection
with elections.

99.

(1)

If any person, to whom these Rules apply, is without reasonable
cause guilty of any act oromission in breach of his official
duty, he shall be punishable with fine which may extend to
five hundred rupees.

(2)

No suit or other legal proceedings shall lie against any such
person for damages in respect of any such act or omission as
aforesaid.

(3)

The persons, to whom these Rules apply, are the District
Election Officer, Returning Officers, Assistant Returning
Officers, Presiding Officers, Polling Officers and any other
person appointed to perform any duty in connection with the
receipt of nominations or withdrawal of candidatures, or the
recording or counting of votes at an election.

(4)

No court shall take cognizance of any offence punishable under
these Rules unless there is a complaint made by an order of,
or under the authority from the State Election Commission or
the District Election Officer.

Chapter – IX
MISCELLANEOUS PROVISIONS

Civil court not to
have jurisdiction.

100.

No Civil Court have jurisdiction to question the legality of:–
(a) any action taken by the Returning Officer in the discharge
of his duties under these Rules; or
(b) any action taken by the Presiding Officer and the Polling
Officer in the discharge of their duties under these Rules; or
(c) any decision taken by the Election Tribunal in the discharge
of their duties under these Rules.

Requisitioning of
premises etc., for
election purposes.

101.

(1)

If it appears to the State Election Commission or the District
Election Officer that in connection with an election to a Village
Council–
(a) any premises are needed or are likely to be needed for
the purpose of being used as a polling station or for the
storage of ballot boxes after a poll has been taken, or
(b) any vehicle or vessel is needed or is likely to be needed
for the purpose of transport of ballot boxes to or from any

<!-- page 48 -->

Ex-10/2015

46
polling station, or transport of members of the police force
for maintaining order during the conduct of such election,
or transport of any officer or other person for the
performance of any duties in connection with such election,
the State Election Commission or as the case may be, the
District Election Officer may by order in writing, requisition
such premises or such vehicle or vessel, as the case may
be and may make such further orders as may appear to
him to be necessary or expedient in connection with the
requisitioning in respect of matters including reasonable
remuneration to be given thereof:
Provided that no vehicle or vessel which is being lawfully
used by candidate or his agent for any purpose connected
with the election of such candidate shall be requisitioned under
these Rules until the completion of the poll at such election.
(2)

The requisition shall be effected by an order in writing
addressed to the person deemed by the State Election
Commission or, as the case may be, the District Election
Officer to be the owner or person in possession of the property.

(3)

Whenever any property is requisitioned under sub–rule (1)
the period of such requisition shall not extend beyond the period
for which such property is required for any of the purposes
mentioned in that sub–rule.

(4)

If any person contravenes any order made under this Rule, he
shall be punishable with imprisonment for a term which may
extend to three months or with fine or with both.

(5)

In this Rule–
(a) “premises” means any land, building or part of a building
and includes a hut, shed or other structure or any part
thereof;
(b) “vehicle” means any vehicle used or capable of being used
for the purpose of road transport, whether propelled by
mechanical power or otherwise;
(c) “vessel” means any vessel used or capable of being used
for the purpose of water transport, whether propelled by
mechanical power or otherwise.

Staff of every local
authority to be
made available.

102.

Every department of the Central or State Government or other
authorities and every educational institution ncluding an aided school
or private affiliated college in the State shall when so requested by
the State Election Commission or the District Election Officer make
available–

<!-- page 49 -->

47

Ex-10/2015

(a) to the Electoral Registration Officer, such staff as may
be necessary for the performance of any duties in
connection with the preparation and revision of electoral
rolls; or
(b) to the District Election Officer and any Returning Officer
such staff as may be necessary for the performance of
any duties in connection with an election.
Expenses in
connection
with elections.

103.

Funds to meet all expenses in connection with the elections to the
Village Councils including those in relation to the preparation of
electoral rolls thereof, shall be provided by the State Government.

Grant of Paid
Holiday to Employees
on the day of Poll.

104.

(1)

Every person engaged in work in any trade establishment or
commercial establishment or industrial establishment or in any
other establishment in the private sector who is eligible to vote
in the Election to Village Councils shall be granted leave on
the day of poll.

(2)

The wages of any such person shall not be reduced or
disallowed on account of the leave granted under sub–rule
(1) even though such person is appointed on the basis that,
wages will not ordinarily be paid for such date, he shall be
paid the wages that would have been received by him on such
date, had he not been granted leave for that day.

Power to make
Forms.

105.

Repeal and Savings.

106.

The State Election Commission may prescribe such other forms
as may be necessary for revision of electoral rolls and conduct
of elections from time to time.
(1)

On and from the commencement of these Rules, the Mara
Autonomous District (Election to Village Councils) Rules, 1991
and all the subsequent amendments shall stand repealed.

(2)

Inspite of such repeal, anything done or any action purported
to have been done or taken under the Rules so repealed, shall
be deemed to have been so done or taken or purported to
have been done or taken under these Rules.

<!-- page 50 -->

Ex-10/2015

48
FORM 1
[See Rule 25]
LETTER OF REQUEST

Election to the Village Council of ………………………………… (No. & Name) 20……
Place.....................................
Date......................................
To,
The occupant of House No................................................................
The preparation of the electoral roll for the Village Council Constituency in which you are
residing has been taken into consideration. It will greatly facilitate my work if you will kindly complete the
statement below after reading the attached instruction and hand it over to my assistant who will call for it.
Electoral Registration Officer
STATEMENT
Name and Particulars of adult citizens residing in the above premises.
S/N
1
1
2.
3.
4
5

Name of citizen
2

Name of relation
3

Relation
4

Age
5

Signature ...............................
Date ……..................................
INSTRUCTIONS
1.
2.
3.
4.

5.
6.
7.
8.
9.

Enter the names of all persons who have completed 18 years of age on or before the 1st day of
January of the year in which the Electoral Roll is so prepared or revised or published and who are
ordinarily residing in the premises.
Only the names of those who are citizens of India and members of Scheduled Tribe should be
entered.
Enter against Serial No. 2 in the second column, the names of the head or other senior member of the
family, provided he or she has the qualifications mentioned in paragraphs 1 and 2 above.
“Ordinarily resident” does not mean that the person should be actually in the house when you are
filling in the form. The persons who normally live in the house should be included even though they
may be temporarily absent, e.g. on a journey or on business or in hospital. On the other hand, a guest
or visitor, who normally lives elsewhere but happen to be in the house at the time should not be
included.
All ordinarily residents of the house should be included. But do not enter the name of any person who
is a member of the Armed Forces of India or is employed under the Government of India in a post
outside India or the name of such person’s wife if she ordinarily resides with him.
For every male citizen, enter the name of his father in the 3rd column ‘F’ in the 4th column.
For every female citizeni) enter the name of her father in the 3rd column and ‘F’ in the 4th column
ii) if married, enter the name of her husband in the 3rd column and ‘H’ in the 4th column.
For any citizen to which ‘6’ & ‘7’ cannot apply, enter the name of the relation and ‘O’ in the 4th
column.
In the 5th column, enter the age of the citizen as accurately as possible, giving only the number of
complete years and ignoring the months as on the qualifying date for the purpose of revision.

<!-- page 51 -->

49

Ex-10/2015

FORM – 2
[See Rule 27]
NOTICE OF PUBLICATION OF ELECTORAL ROLL IN DRAFT

Election to the Village Council of ………………………………….. (No. & Name) 20…….

To,

The Electors of the .........................................................................Village Council
Constituency.
Notice is hereby given that the electoral roll has been prepared in accordance with the
Mara Autonomous District Council (Election to Village Councils) Rules, 2014 and a copy thereof is available
for inspection at my office, and at ........................................................................ during office hours.
If there be any claim for the inclusion of a name in the roll or any objection to the inclu-sion
of a name or any objection to particulars in any entry, it should be lodged on or before the
............................................................. in form 3, 4 or 5 as may be appropriate.
Every such claim or objection should either be presented in my office or to ............................
or sent by post to the address given below so as to reach me not later than the aforesaid date.

Date............................................

Electoral Registration Officer
Address: ………………........................

Place ………..…………………..

<!-- page 52 -->

Ex-10/2015

50
FORM – 3
[See Rule 30(1)]
APPLICATION FOR INCLUSION OF NAME

To,
The Electoral Registration Officer,
....................................................Village Council Constituency.
………………………………… Autonomous District Council
Sir,
I request that my name be included in the electoral roll for the Village Council Constituency
of..........................................................................
My name (in full)..........................................................................................................
My Father’s/ Mother’s/ Husband’s Name.........................................................
Particulars of my place of residence are:House No. ..................................................................
Street...........................................................................
Village..........................................................................
Post Office..................................................................
Police Station............................................................
District ……….............................................................
I hereby declare that to the best of my knowledge and belief:(i)
I am a citizen of India;
(ii)
My age on the first day of January ………………… was ……....................years
and ....................................... months ;
(iii)
I am ordinarily resident at the address given below:…………………………………………………………………………………………..
(iv)
I have not applied for the inclusion of my name in the electoral roll for any other
Village Council Constituency:
(v)
My name has not been included in the electoral roll for this or any other Village
Council Constituency.
or
My name may have been included in the electoral roll of ……............................
Village Council in which I was ordinarily resident earlier at the address mentioned
below and, if so, 1 request that the same may be excluded from that electoral roll.
Full Address of earlier place of ordinary residence:……………………………………………………….
……………………………………………………….
Date ...........................................

................................

Place .........................................

Signature or thumb impression
of the Applicant
Record of action taken

The application in Form–3 of Mr./Mrs./Miss.......................................of................................has been–
(a)
accepted and his/her name is included in the electoral roll of.......................................
…………………………..................Village Council Constituency, or
(b)
rejected
for
the
reason…………………………………………………………………………………………
…………………………………………………………………………………………………………………………..
Date ...................................
Place ……………………..

Electoral Registration Officer
(Seal)

<!-- page 53 -->

51

Ex-10/2015

FORM 4
[See Rule 30(2)]
APPLICATION FOR OBJECTING INCLUSION OR SEEKING DELETION
To,
The Electoral Registration Officer,
..................................................... Village Council Constituency
..................................................... Autonomous District Council.
Sir,
I object to the inclusion of the name of ………….................................................................... at
Serial No. ….......................................... of the electoral roll of.................................................Village
Council Constituency for the following reason (s):……………………………………………………………
……………………………………………………………
……………………………………………………………
I hereby declare that the facts mentioned above are true to the best of my knowledge and
belief. My name has been included in the electoral roll for this constituency as follows:Name in full...........................................................................................
Father’s/Mother’s/Husband’s Name.........................................
Serial No.................................................................................................
Part No....................................................................................................
…………………………………..
Signature or thumb impression of the objector
(Full postal address)......................................
NOTE: Any person who makes a statement or declaration which is false and which he either knows or
believes to be false or does not believe to be true is punishable under Rule 22 of the Mara Autonomous
District Council (Election to Village Councils) Rules, 2014 and provisions under the appropriate law including
Indian Penal Code.
Record of action taken
The objection in Form–4 lodged by Mr./Mrs./Miss ……......................................................
of ........................................................has been–
(a)
accepted and the entry of the name of ........................................... Serial No.
........................... of the electoral roll of ......................................Village Council
shall be deleted; or
(b)
rejected for the r eason ………………..........................................
………………………………………………………………………………………………………………………….
Date ...................................
Place ……………………..

Electoral Registration Officer,
(Seal)

<!-- page 54 -->

Ex-10/2015

52
FORM 5
[See Rule 30(3)]
OBJECTIONS TO PARTICULARS IN ANY ENTRY

To,
The Electoral Registration Officer,
……………………………………Village Council Constituency,
…………………………………… Autonomous District Council.
Sir,
I submit that the entry relating to myself which appears at Serial No. ...................... of the
electoral roll of ........................................................................ is not correct. It should be corrected to
read as follows:
“…………………………………………………………………………………………………
...……………………………………………………………………………………………….”
Place .........................................
Date ..........................................
…..……………......……………
Signature or thumb impression
of the elector.
NOTE: Any person who makes a statement or declaration which is false and which he either knows or
believes to be false or does not believe to be true is punishable under Rule 22 of the Mara Autonomous
District Council (Election to Village Councils) Rules, 2014 and provisions under the appropriate law including
Indian Penal Code.
Record of action taken
The objection in Form–5 lodged by Mr./Mrs./Miss ……………………………..............
…….……………………….......... of ……...………...........................................................................
....................................................... has been –
(a)

accepted and the relevant entry has been corrected to read as follows:…………………………………………………………………………..........................................................
…………………………………………………………………………..........................................................

(b)

rejected for the reason ....................................................................................

Date.......................................
Place ……………………….

Electoral Registration Officer
(Seal)

<!-- page 55 -->

53

Ex-10/2015

FORM 6
[See Rule 33]

NOTICE OF FINAL PUBLICATION OF ELECTORAL ROLL

It is hereby notified for public information that the list of amendments to the draft electoral
roll for the.................................................................................. (No. & Name) Village Council
Constituency of ………………………….. District has been prepa red with reference
to.......................................................as the qualifying date and in accordance with the Mara Autonomous
District Council (Election to Village Councils) Rules, 2014. A copy of the said roll together with the said list
of amendments has been published and will be available for inspection at my office.

Date............................................
Place...........................................
Electoral Registration Officer,
Address: …………………………….
………………………………………………

<!-- page 56 -->

Ex-10/2015

54
FORM 7
[See Rule 39]
NOTICE OF ELECTION

Notice is hereby given that:(1)
(2)

(3)
(4)
(5)

(6)
(7)
(8)

an election is to be held of a member to the Village Council in the ………………….. (No.
& Name) Village Council Constituency;
nomination papers may be delivered by a candidate to the Returning Officer/Asst. Returning
Officer at …………………………………….. between 11:00 A.M and 3:00 P.M on any
day (other than public holiday) not later than the ………………………………… (date) ;
forms of nomination paper may be obtained at the place and time aforesaid;
the nomination papers will be taken up for scrutiny at ………………………………………
(place) on……………………… (date) at……………………………….. (hour);
notice of withdrawal of candidature may be delivered either by a candidate or by his
election agent who has been authorized in writing by the candidate to deliver it to either of
the officers specified in paragraph (2) above at his office before 3 P.M. on
the……………………………(date) ;
a candidate shall deposit rupees five hundred along with his nomination paper;
in the event of the election being contested, the poll will be taken on ………………….
between the hours of……………………. and ………………………. ;
the counting of votes will commence on ………………… (date) at ……………………….
(place) at ……………………… (hour) or immediately after the poll is over.

Date…………………

Returning Officer

Place …………………………….

No. & Name of V/C Constituency ……………….…...
FORM 8
[See Rule 41]
NOMINATION PAPER
Part – I

Election to the Village Council of ___________________________ (No & Name)
20………….……
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.

Name
Father’s/Mother’s/Husband’s Name
Age & Date of Birth
Sex
Educational Qualifications
Address
No. & Name of Constituency
Sl. No. in the Electoral Roll
Date & Time of filing Nomination
Citizenship
Religion
Place of birth
Occupation

:
:
:
:
:
:
:
:
:
:
:
:
:

<!-- page 57 -->

55

Ex-10/2015

Part – II
(CANDIDATE’S DECLARATION)
I, ___________ the candidate mentioned in Part-I assent to this nomination and hereby declare:1)
that I have completed _________ years of age;
2)
that I am not a member of any other Village Council;
3)
that I am a voter of______________ Village Council Constituency;
4)
that I am set up at this election by the ______________________ party;
5)
that symbols I have chosen are, in order of preference
i) ____________________ii)_____________________iii)_________________
6)
that I am not disqualified for being elected to fill the said seat in the Village Council as
required under Section 4(f) of the Mara Autonomous District (Village Councils) Act, 1974
as amended;
7)
that I am not an unsound mind and stands so declared by a competent Court of Authority;
8)
that my Name and Father’s/Mother’s/Husband’s Name have been correctly spelt out above
in__________________ (name of language);
9)
that the Code of Conduct prescribed by the State Election Commission has been read by
me/read over to me and I will abide by it;
10)
that I have deposited a security deposit of Rs. 500/- as prescribed under Rule 42(1).
11)
that I am not holding any office of profit under the Central Government or the State
Government.
12)
that to the best of my knowledge and belief, I am qualified and not disqualified for being
elected to fill the seat of the said Village Council;

Witness:

Witness:

(………………………….)
Signature

(………………………….)
Signature

(………………………….)
Signature

(…………………………….)
Name (Capital Letter)

(…………………..………….) (………………………….)
Name (Capital Letter)
Name (Capital Letter)

Sl. No. in the E/Roll…………..

Sl. No. in the E/Roll…………..

Date……………………..

Date……………………

Date……………………

Place……………………

Place………………….

Place………………….

<!-- page 58 -->

Ex-10/2015

56
Part – III
(To be filled by the Returning Officer)

Serial No. of Nomination Paper …………………………………………..
This nomination paper was delivered to me at my office at ……………….(hour) on ……………
(date) by the candidate.

Signature of the Returning Officer or
other authorised person

Part – IV
(Decision of Returning Officer accepting or rejecting the nomination paper)
I have examined this nomination in accordance with Rule ______________ and decided as follows:

Date: _____________________

Accepted/Rejected

Place:_____________________

Returning Officer

_________________________________ (Perforation) _________________________________
Part – V
RECEIPT FOR NOMINATION PAPER AND NOTICE FOR SCRUTINY
(To be handed over to the Candidate while filing the nomination paper)

Serial No. of Nomination Paper ……………………………………………
The Nomination Paper of …………………………., a candidate for election to Village Council of
…………………………………(No. & Name), was delivered to me at ………………….(hour) on
……………….. (date) by the Candidate.
All Nomination Papers will be taken up for scrutiny at ……… (hour) …………. on ……………….
(date) at …………………….. (place).

Date: ……………………….
Place: ……………………..

Returning Officer

<!-- page 59 -->

57

Ex-10/2015

FORM 9
[See Rule 42]
RECEIPT OF SECURITY DEPOSIT
Part ‘A’
No……………………
Date ………………..
Received a sum of Rs. 500/- (Rupees
five hundred) only from Puhpa/Pino …………
………………………………………....…of
………………………................ on account
of security deposit for his nomination for V/C
election.

Part ‘A’
No……………………
Date ………………..
Received a sum of Rs. 500/- (Rupees
five hundred) only from Puhpa/Pino …………
………………………………………....…of
………………………................ on account
of security deposit for his nomination for V/C
election.

Returning Officer,
No. Name of V/C Constituency

Returning Officer,
No. Name of V/C Constituency

Part ‘B’

Part ‘B’

HOW DISPOSED OF

HOW DISPOSED OF

Date ………………..
Refunded/forfeited

Signature
of Candidate

Date ………………..
Refunded/forfeited

Returning Officer

No. Name of V/C Constituency
.......................................................

Signature
of Candidate

Returning Officer

No. Name of V/C Constituency
..........................................................

<!-- page 60 -->

Ex-10/2015

58
FORM 10
[See Rule 43(4)]

LIST OF VALIDLY NOMINATED CANDIDATES

Election to Village Council of …………………………….. (No & Name) 20……

S.No.

Name of the Candidate

(1)
1.
2.
3.
4.

(2)

Place:
Date:

Name of
Father/Mother/Husband
(3)

Address of
Candidate
(4)

Party affiliation,
if any
(5)

Returning Officer

<!-- page 61 -->

59

Ex-10/2015

FORM 11
[See Rule 44]
NOTICE OF WITHDRAWAL OF CANDIDATURE
Election to the Village Council of ………………………………….. (No. & Name) 20…….
To,
The Returning Officer,
………………………………….
I, …………………………………………………. a candidate nominated at the above election
do hereby give notice that I withdraw my candidature.
Place …………………
Date ………………….
Signature of nominated candidate
This notice was delivered to me at my office at ……….……………. (hour ) on
……….………..……….. (date) by ………………………. (name), the ** …………………
……..……………
Returning
Officer
Place …………………….
Date……………………..
.............................................................................(Perforation) ........................................................
Receipt for Notice of Withdrawal
(To be handed over to the person delivering the notice)
The notice of withdrawal of candidature by ………………………….. a nominated candidate at
the election to Village Council of …………………………. (No. & Name) was delivered to me by the **
………………………… at my office at ……………………… (hour) on ……………………. (date).
……..……………
Returning
Officer
** Here insert one of the following alternatives as may be appropriate:(1) Candidate
(2) Candidate’s Election Agent who has been authorized in writing by the candidate to deliver
it.
(3) A person authorized in writing by the candidate to deliver it.

<!-- page 62 -->

Ex-10/2015

60
Form 12
[See Rule 46(9) & (10)]
NOTICE AS TO NAMES OF CANDIDATES SET UP BY
THE RECOGNISED/REGISTERED POLITICAL PARTY

Election to the Village Council of ………………………………….. (No. & Name) 20…….

To,
The Returning Officer,
…………………………………………………………

Subject:
Notice regarding setting up of candidates in the Election to Village Council from
……………………………….. (No. & Name) Constituency.

Sir/Madam,
I hereby give notice that the following persons have been set u p by
……………………………………..…...…. Party as its candidate(s) at the Election to be held on the
……………………………………………… for election of Members from the Village Council
Constituency of …………………………… (No. & Name) as shown against each of the candidates.
S/N
1.
2.
3.
4.
5.
6.
7.

Name of Sponsored Candidates

Father’s/Mother/’s/Husband’s Name

Address

Yours faithfully,

Signature _________

Name of District President

(

)

(Seal)

<!-- page 63 -->

61

Ex-10/2015

FORM 13
[See Rule 46(12)]

LIST OF CONTESTING CANDIDATES

Election to the Village Council of ………………………………… (No. & Name) 20……

S.No. Name of the Candidate

Father’s/Mother/’s/
Husband’s Name

Party affiliation

Symbol allotted

The poll will be taken on ……..………………………..(date) at …….…………………….. (place)
between the hours of …………….. A.M. to ………….. P.M.

Date...................................................
Returning Officer
Place : ………………………………

No. & Name of Village Council ……...................

<!-- page 64 -->

Ex-10/2015

62
FORM 14
[See Rule 48(1)(c)]

APPOINTMENT OF ELECTION AGENT

Election to the Village Council of ………………………………… (No. & Name) 20……

To,
The Returning Officer,
………………………………………………

I,
………………………………………………..
(name)
of
……………………………………….. (address), a candidate at the above election, do hereby appoint
………………………………………….…………………… of ………………………………………
(address) as my Election Agent from this day at the above election.

Place ………………………..
Date ………………………..
………………………
Signature of Candidate

I accept the above appointment

Place ………………………..
Date ………………………..
…………………….……………
Signature of Election Agent

Approved
Signature and seal of the Returning Officer

<!-- page 65 -->

63

Ex-10/2015

FORM 15
[See Rule 48(1)(e)]

REVOCATION OF APPOINTMENT OF ELECTION AGENT

Election to the Village Council of ………………………………… (No. & Name) 20……

To,

The Returning Officer,
………………………….…………………

I, ..………………………………………………….., a candidate at the above election,
hereby revoke the appointment of Puhpa/Pino ………………………………………………… as my
Election Agent.

Place ………………………..
Date …………………………

……………………………
Signature of Candidate

<!-- page 66 -->

Ex-10/2015

64
FORM 16
[See Rule 48(2)(b)]
APPOINTMENT OF POLLING AGENT

Election to the Village Council of ………………………………… (No. & Name) 20……
To,
The Presiding Officer,
………………………………………….…
I, ……………………………… a Candidate/Election Agent* of Puhpa/ Pino
……………………........... .....................................………. who is a candidate at the above said election
do hereby appoint Puhpa/Pino ……………………………………………………. as a Polling Agent at
Polling Station of ……..…………… (No.& Name) Village Council Constituency.

Place:
Date:

Signature of Candidate/Election Agent

I agree to act as Polling Agent
Place:
Date:

Signature of Polling Agent

DECLARATION TO BE SIGNED BY THE POLLING AGENT BEFORE THE PRESIDING
OFFICER
I,
………………………………
Polling
Agent
of
Puhpa/ Pino
……………………………….. do hereby declare that at the Election to the Village Council Constituency
of …………………………………. (No. & Name) I will not do anything that may violate the secrecy of
the election or any provision of the Act or Rule 91 of the Mara Autonomous District Council (Election to
Village Councils) Rules, 2014 in connection with this election.
Signature of Polling Agent (date)

Signed before me and accepted

Presiding Officer
Place:
Date
*Strike off whichever is not applicable.

<!-- page 67 -->

65

Ex-10/2015

FORM 17
[See Rule 48(2)(d)]

REVOCATION OF APPOINTMENT OF POLLING AGENT
Election to the Village Council of ………………………………… (No. & Name) 20……

To,

The Presiding Officer,
……………………………………………

I, ……………………………………. * the Election Agent of Puhpa/ Pino
……………..…………………………, a candidate at the above election, hereby revoke the appointment
of Puhpa/Pino …………………………………. as my/his Polling Agent.

Place:

Signature ………………………....…..

Date:
Name…………………………………..
Candidate /Election Agent

_________________________________________________________________________________________________________________________
*Strike out the word(s) not applicable

<!-- page 68 -->

Ex-10/2015

66
FORM 18
[See Rule 68(2) (a)]
APPOINTMENT OF COUNTING AGENT

Election to the Village Council of ………………………………… (No. & Name) 20……
To,
The Returning Officer,
……………………………………
I, ........................, * a candidate/the election agent of......................................who is a
candidate at the above election, do hereby appoint the following persons as my counting agents to attend the
counting of votes at.................................................... (place).
Name of the Counting Agents
1. ……………………………
2. ……………………………
3. ……………………………

Address of the counting agent
……………………………….
……………………………….
……………...…..…………...
Signature of Candidate/Election Agent.

We agree to act as such Counting Agents
1. ……………………………….
2. ……………………………….
3. ……………………………….
Signature of Counting Agents
Place..................................
Date..................................
Declaration of Counting Agents
(To be signed before the Returning Officer)
We hereby declare that at the above election we will not do anything forbidden by Rule 91 of the
Mara Autonomous District Council (Election to Village Councils) Rules, 2014, which we have read/has
been read over to us.
1.
2.
3.
etc.
Date...................................

Signature of counting agents
Signed before me.

Date..................................

Returning Officer

<!-- page 69 -->

67

Ex-10/2015

FORM 19
[See Rule 68(2)(b)]

REVOCATION OF APPOINTMENT OF COUNTING AGENT
Election to the Village Council of ………………………………… (No. & Name) 20……

To,

The Returning Officer,
……………………………………………

I, ..........................., [the election agent of..........................] a candidate at the above
election hereby revoke the appointment of...................... my/his counting agent.

Date...............................
Place..............................

Signature of person revoking.

<!-- page 70 -->

Ex-10/2015

68
FORM 20
[See Rule 52]
BALLOT PAPER COUNTERFOIL

Election to the Village Council of ………………………………… (No. & Name) 20……
Serial No. of Ballot Paper ...............................
Elector’s Serial number in the Electoral Roll………………………………..………..
Signature or thumb impression of the elector
...............................................................(Perforation) ......................................................................
......................................................................................................

BALLOT PAPER
Serial No. of Ballot Paper..............................................................................
No & Name of Village Council Constituency...........................................

<!-- page 71 -->

69

Ex-10/2015

<!-- page 72 -->

Ex-10/2015

70
FORM 21
[See Rule 53]

APPLICATION FOR CASTING OF VOTE BY A VOTER ON ELECTION DUTY
Election to the Village Council of ………………………………… (No. & Name) 20……

To,
The District Election Officer,
________________________ District.

Sir,

I intend to cast my vote in the ensuing Election to the Village Councils from
___________________________ (No. & Name) Village Council Constituency by means of Ballot Paper
for Electors on Election Duty.
My name is entered at Sl. No. _______ in Part No. ________ of the Electoral Roll of
______________________________ (No. & Name) Village Council Constituency.
I have been appointed/deployed to perform election duty and copy of my appointment/
deployment letter is attached herewith.
I request that a ballot paper be issued to enable me to cast my vote as per procedures
prescribed by the State Election Commission,

Enclo: As stated above.
Yours faithfully,

Signature: _________________________
Name: ___________________________
Designation: _______________________
Contact No.:_______________________

<!-- page 73 -->

71

Ex-10/2015

FORM 22
[See Rule 54(2) (c)]
LIST OF CHALLENGED VOTES
Election to the Village Council of ………………………………… (No. & Name) 20……
Sl/No.
Signature Address of Name of Name of Order of
Serial No. Name of
the person identifier, challenger Presiding
of entry elector of Elector’s or thumb
name in impression challenged
if any
Officer
the E/Roll
of the
person
challenged

1

2

3

4

5

6

7

8

Signature of
challenger
on receiving
refund of
deposit

9

Date: …………………..

Signature of Presiding Officer

<!-- page 74 -->

Ex-10/2015

72
FORM 23
[See Rule 60(1)]

DECLARATION BY THE COMPANION OF BLIND OR ILLITERATE OR INFIRM
VOTERS

Election to the Village Council of ………………………………… (No. & Name) 20……

I, ………………................................................................................................................. do hereby
certify that .......................................................................... is personally known to me. I am satisfied
that he/she is blind or illiterate or physically infirm and is unable to make a mark on the ballot paper. He/she
requested me to mark the ballot paper on his/her behalf. I hereby declare that I have not accepted as
companion of any other elector at any polling station today, and that I will keep secret the vote recorded by
me on his/her behalf.

Date: …………………….…..

Signature of Companion

Place: ………………………..

Signed before me and permitted

Signature of the Presiding Officer

<!-- page 75 -->

73

Ex-10/2015

FORM 24
[See Rule 60(2)]

RECORD OF VOTES OF BLIND OR ILLITERATE OR INFIRM ELECTORS

Election to the Village Council of ………………………………… (No. & Name) 20……

Sl/No. Name of Elector Elector’s Sl/No. Name of
in the E/Roll
Companion

Companion’s
Sl/No. in the
E/Roll

Signature of
Companion

Date : ...........................................
Place : ……………………………...

Signature of the Presiding Officer

<!-- page 76 -->

Ex-10/2015

74
FORM 25
[See Rule 64(2)]
LIST OF TENDERED VOTES

Election to the Village Council of ………………………………… (No. & Name) 20……

Sl/No. Name of the Sl/No. of
Elector
elector in
the E/Roll

Date: ..................................
Place: ..................................

Address of
the elector

Serial
number of
electors in
electoral roll

Serial
number of
tendered ballot
paper

Serial number Signature
of tendered
or thumb
ballot paper
impression
issued to the
of person
person who
tendering
has already
vote
voted

Signature of the Presiding Officer

<!-- page 77 -->

75

Ex-10/2015

FORM 26
[See Rule 66]

BALLOT PAPER ACCOUNT OF PRESIDING OFFICER

Election to the Village Council of ………………………………… (No. & Name) 20……
Sl/No.
1.
2.
3.
4.
5.
6.
7.

Particulars
No. of Ballot Papers received by the Presiding Officer
No. of Ballot Papers issued to electors
No. of Ballot Papers cancelled for violating voting procedure
No. of Ballot Papers spoilt and returned under Rule 61 (1)
No. of Ballot Papers refused by the elector and cancelled under Rule 61 (2)
No. of Ballot Papers to be found in the ballot box
No. of unused Ballot Papers returned

Quantity

Date: ……………...........................
Signature of the Presiding Officer
Place: ……………….………………

<!-- page 78 -->

Ex-10/2015

76
FORM 27
[See Rule 73(3)]

ROUND-WISE COUNTING SHEET

Election to the Village Council of ………………………………… (No. & Name) 20……

(a) Counting Table No: __________

(b) Round No: ___________________

(c) No. of Ballot Papers: __________

(d) Total Votes cast: ____________

(e) Valid Votes: _________________

(f) Invalid Votes: ________________

Sl/No. Name of Candidates

Votes poled
5

5

5

5

5

5

5

Total
5

5

5

Name & Signature of Counting Supervisor
Date ............................................
Place ............................................
Name & Signature of Returning Officer

<!-- page 79 -->

77

Ex-10/2015

FORM 28
[See Rule 73(3)]
COUNTING TABLE-WISE RESULTS TABULATION SHEET
Election to the Village Council of ………………………………… (No. & Name) 20……
ROUND No. .........
Sl/No.

Name of Candidates

Valid Votes Polled
Counting
Table
No. ____

Counting
Table
No. ____

Counting
Table
No. ____

G. Total

Counting Counting
Table
Table
No. ____ No. ____

Date ………………………
Place ……………………..
Name & Signature of Returning Officer

<!-- page 80 -->

Ex-10/2015

78
FORM 29
[See Rule73(3)]
ROUND-WISE TABULATION SHEET

Election to the Village Council of ………………………………… (No. & Name) 20……
Sl/No.

Name of Candidates

Valid Votes Polled
Round
No. ____

Round
No. ____

Round
No. ____

G. Total

Round
Round
No. ____ No. ____

Name & Signature of Returning Officer
