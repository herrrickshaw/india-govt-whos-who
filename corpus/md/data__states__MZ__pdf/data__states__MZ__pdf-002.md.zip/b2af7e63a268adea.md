---
doc_id: "b2af7e63a268adea"
source_url: "https://forensic.mizoram.gov.in/storage/IGHR1IoxGf3ZI6gJd3gkH0KPpGGMXFT0ZgV98lbS.pdf"
ministry: "Forensic Science Laboratory, Mizoram"
title: "SEALED TENDER NOTICE .pdf"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3c5579061b87bd6c"
---

<!-- page 1 -->

GOVERNMENT OF MIZORAM
DIRECTORATE OF FORENSIC SCIENCE LABORATORY
MIZORAM:AIZAWL
……
No. D.21020/1/2020-FSL

:

Dated Aizawl, the 19th March, 2025

NOTICE INVITING BID

Sealed Tenders in plain papers are hereby invited by the undersigned
from reputed and bonafied Manufacturers or their only authorized Dealers for supply &
installation of laboratory equipments for Forensic Science Laboratory, which will be received by
the Director, Forensic Science Laboratory, Mizoram, Aizawl on or before 11.04.2025 (Friday).
Quotations are to be opened by the Director, Forensic Science Laboratory or his authorized
representative(s) at 01:00 PM on the same day. The Tenderers or their respective
representative(s) may also be present at the time of opening of the quotations, if so desired.
Details can be obtained from the Office of Director, Forensic Science
Laboratory, MINECO, Khatla, Aizawl on all working days within Office hours or @
https://forensic.mizoram.gov.in/.

Digitally signed by T. Lalropuia
Date: 2025.03.19 15:25:01
+05'30'

(T. LALROPUIA)
Director,
Forensic Science Laboratory,
Mizoram, Aizawl
