---
doc_id: "9b2cffcd64cf361b"
source_url: "http://www.cercind.gov.in/2014/regulation/noti18.pdf"
ministry: "State Load Despatch Centre (SLDC), Mizoram"
title: "CERC(IEGC) (II Amendment) Regulation 2014"
date: ""
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "95ad1a008edbd387"
---

<!-- page 1 -->

CENTRAL ELECTRICITY REGULATORY COMMISSION
NEW DELHI
6thJanuary, 2014
NOTIFICATION

No.L-1/18/2010-CERC:In exercise of powers conferred under clause (h) of subsection (1) of Section 79 read with clause (g) of sub-section (2) of Section 178 of the
Electricity Act, 2003 (36 of 2003), and all other powers enabling it in this behalf, the
Central Electricity Regulatory Commission hereby makes the following regulations to
amend the Central Electricity Regulatory Commission (Indian Electricity Grid Code)
Regulations, 2010 including the first amendment thereof (hereinafter referred to as
“the Principal Regulations”).

1. Short title and commencement
(1) These Regulations may be called the Central Electricity Regulatory
Commission (Indian Electricity Grid Code) (Second Amendment) Regulations,
2014.
(2) These Regulations shall come into force with effect from 17.2.2014.

2. Amendment in Regulation 2 of Principal Regulations.-Following new clauses
shall be added after clause (gggg) of sub-Regulation (1) of Regulation 2 of
Principal Regulations as under, namely:
“(hhhh) Deviation Settlement Mechanism Regulations meansCentral
Electricity Regulatory Commission (Deviation Settlement Mechanism and
related matters) Regulations, 2014 including any subsequent amendments
thereof;
(iiii) Pooling Station means the sub-station where pooling of generation of
individual wind generators or solar generators is done for interfacing with the
next higher voltage level:
Provided that where there is no separate pooling station for a wind / solar
generator and the generating station is connected through common feeder
and terminated at a sub-station of distribution company/STU/ CTU, the sub-

Page 1 of 7

<!-- page 2 -->

station of distribution company/STU/CTU shall be considered as the pooling
station for such wind/solar generator, as the case may be.

3. Amendment in Regulation 5 of the Principal Regulations:
(1) Sub-regulation (f) (ii)(a) of Regulation 5.2 of the Principal Regulations shall
stand modified as under:
“There should not be any reduction in generation in case of improvement in
grid frequency below 50.05 Hz (for example, if grid frequency changes from
49.9 to 49.95 Hz, there shall not be any reduction in generation). For any fall
in grid frequency, generation from the unit should increase by 5% limited to
105 % of the MCR of the unit subject to machine capability.”
(2) In sub-regulation (i) of Regulation 5.2 of the Principal Regulations, the
following sentence shall stand deleted:
"However, if frequency falls below 49.8 Hz, all partly loaded generating
shall pick up additional load at a faster rate, according to their
capability".
(3) In sub-regulation (j) of Regulation 5.2 of the Principal Regulations, the words
"particularly when frequency is falling or is below 49.7 Hz" shall stand
deleted.
(4) In sub-regulation (m) of Regulation 5.2 of the Principal Regulations, the
words and figures "49.7-50.2 Hz" shall be substituted with the words and
figures "49.90-50.05 Hz".
(5) In sub-regulation (a) of Regulation 5.4.2 of the Principal Regulations, the
following phrase "whenever the system frequency falls to 49.8 Hz" shall stand
deleted.
(6) In sub-regulation (b) of Regulation 5.4.2 of the Principal Regulations, the
following phrase "when frequency is 49.7 Hz or below" shall stand deleted.

(7) Sub-regulation (g) of Regulation 5.4.2 of the Principal Regulations shall be
substituted with the following:
"(g) RLDCs shall devise standard instantaneous message formats in order to
give directions in case of contingencies and/or threat to the system security to
reduce deviation from schedule by the bulk consumer, SLDC/StateUtility/
ISGS/Regional Entity/Injecting Utility at different overdrawal/underdrawal/over-injection/under-injectionconditions depending upon the severity.
The concerned SLDC/other regional entity shall ensure immediate compliance
with these directions of RLDC and send a compliance report to the concerned
Page 2 of 7

<!-- page 3 -->

RLDC."

4.

Amendment in Regulation 6 of the Principal Regulations:

(1) Regulation 6.4.6 of Principal Regulations shall be substituted with the
following:
"The system of each regional entity shall be treated and operated as notional
control area. The algebraic summation of scheduled drawal from ISGS and
from contracts through long–term access, medium-term and short–term open
access arrangements shall provide the drawal schedule of each regional
entity, and this shall be determined in advance on day-ahead basis.
Theregional entities shall regulate their generation and/or consumers’ load so
as to maintain their actual drawal from the regional grid close to the
aboveschedule. Maximum inadvertent deviation allowed during a time block
shall not exceed the limits specified in the Deviation Settlement Mechanism
Regulations.Such deviations should not cause system parameters to
deteriorate beyond permissible limits and should not lead to unacceptable line
loadings. Inadvertent deviations, if any, from net drawal schedule shall be
priced through theDeviation Settlement mechanism as specified by the
Central Commission from time to time. Every regional entity shall ensure
reversal of sign of deviation from schedule at least once after everytwelvetime
blocks."
(2) Regulation 6.4.7 of Principal Regulations shall be substituted with the
following:
"7. The SLDC, SEB / distribution licensee shall always restrict the net drawal
of the state from the grid within the drawal scheduleskeepingthe deviations
from the schedule within the limits specified in the Deviation Settlement
Mechanism Regulations. The concerned SEB/distribution licensee/User,
SLDC shall ensure that their automatic demand management scheme
mentioned in clause 5.4.2 acts to ensure that there is no over-drawal. If the
automatic demand management scheme has not yet been commissioned,
then action shall be taken as per manual demand management scheme to
restrict the net drawal from grid to within schedulesand all actions for early
commissioning of Automatic Demand Management Scheme (ADMS)shall be
initiated

(3) Regulation 6.4.10 of Principal Regulations shall be substituted with the
following:
"10. The ISGS is normally expected to generate power according to the daily
schedules advised to them barring any inadvertent deviations. Maximum
deviation allowed during a time block shall not exceed the limits specified in
Page 3 of 7

<!-- page 4 -->

the Deviation Settlement Mechanism Regulations. Such deviations should not
cause system parameters to deteriorate beyond permissible limits and should
not lead tounacceptable line loadings. Inadvertent deviations, if any, from the
ex-power plant generation schedules shall be appropriately priced in
accordance with Deviation Settlement Mechanism Regulations. In addition,
deviations from schedules causing congestion, shall also be priced in
accordance with the Central Electricity Regulatory Commission (Measure to
relieve congestion in real time operation) Regulations, 2009."
(4) Regulation 6.4.11 of Principal Regulations shall stand deleted.
(5) Regulation 6.4.12 of Principal Regulations shall be substituted with the
following:
"12. Notwithstanding the above,the RLDC may direct the SLDCs/ISGS/
other regional entities to increase/decrease their drawal/generation in case of
contingencies e.g. overloading of lines/transformers, abnormal voltages,
threat to system security. Such directions shall immediately be acted upon. In
case the situation does not call for very urgent action, and RLDC has some
time for analysis, it shall be checked whether the situation has arisen due to
deviations from schedules. These shall be got terminated first, through
appropriate measure like opening of feeders , if considered necessary by
SLDC/RLDC, before an action, which would affect the scheduled supplies to
the long term, medium term customers or short term customers is initiated in
accordance with Central Electricity Regulatory Commission (Grant of
Connectivity, Long-term Access and Medium-term Open Access in InterState
Transmission and Related matters) Regulations, 2009 and Central Electricity
Regulatory Commission (Open Access in Inter-State Transmission)
Regulations, 2008.
In case Short Term/Medium Term Open Access or Long Term Access are
curtailed, RLDC(s) shall submit a report regarding the reasons due to which it
was not able to curtail deviations from Schedule and agencies which had not
taken necessary actions."
(6) Regulation 6.4.15 of the Principal Regulations shall stand deleted.

(7) Regulation 6.4.24 of Principal Regulations shall be substituted with the following:
"24.Hydro generating stations are expected to respond to grid frequency
changes and inflow fluctuations. Maximum deviation allowed during a time block
shall be as per the CERC Deviation Settlement Mechanism Regulations."
(8)Regulation 6.5.9 of Principal Regulations shall stand deleted.

Page 4 of 7

<!-- page 5 -->

(9)
Regulation 6.5.13 of the Principal Regulations shall be substituted with the
following:
"13.The schedule finalized by the concerned load despatchcentre for hydro
generating station, shall normally be such that the scheduled energy for a day
equals the total energy (ex-bus) expected to be available on that day, as
declared by the generating station, based on foreseen/planned water
availability/release. It is also expected that the total net energy actually supplied
by the generating station on that day would equal the declared total energy, in
order that the water release requirement is met."
(10) Regulation 6.5.17 of Principal Regulations shall be substituted with the
following:
“17.In case of any grid disturbance, scheduled generation of all the ISGSs
supplying power under long term / medium term/short term shall be deemed to
have been revised to be equal to their actual generation and the scheduled
drawals of the beneficiaries/buyers shall be deemed to have been revised
accordingly for all the time blocks affected by the grid disturbance. Certification
of grid disturbance and its duration shall be done by the RLDC.

The declaration of disturbance shall be done by the concerned RLDC at the
earliest. A notice to this effect shall be posted at its website by the RLDC of the
region in which the disturbance occurred. Issue of the notice at RLDC web site
shall be considered as declaration of the disturbance by RLDC. All regional
entities shall take note of the disturbance and take appropriate action their end.
For Bilateral short term and collective transactions, the methodology of
settlement of accounts for the period of Grid Disturbance shall be formulated by
National Power Committee(NPC) and same shall be put up to the Commission
for approval. The methodology shall cover all possible scenarios with illustrative
examples to cover the instances where the Grid disturbance is either partial or it
affects only one region.
(11) The Regulation 6.5.18 of the Principal Regulations shall be substituted with the
following:
“18. Revision of declared capability by the ISGS(s) having two part tariff with
capacity charge and energy charge (except hydro stations) and requisition by
beneficiary(ies) for the remaining period of the day shall also be permitted
with advance notice. Revised schedules/declared capability in such cases
shall become effective from the 4th time block, counting the time block in
which the request for revision has been received in the RLDC to be the first
one.”
(12) Regulation 6.5.23 of the Principal Regulations shall be substituted as under:

Page 5 of 7

<!-- page 6 -->

“23.With effect from 15.7.2013, Scheduling of wind power generation plants
would have to be done where the sum of generation capacity of such plants
connected at the connection points (called Pooling stations) to the transmission
or distribution system is 10 MW and above and connection point is 33 kV and
above, for pooling stations commissioned after 3.05.2010. For capacity and
voltage level below this, as well as for old wind farms (A wind farm is collection
of wind turbine generators that are connected to a common connection point), it
could be mutually decided between the Wind Generator and the transmission or
distribution utility, as the case may be, if there is no existing contractual
agreement to the contrary. The schedule by wind power generating stations
(excluding collective transactions) may be revised by giving advance notice to
SLDC/RLDC, as the case may be. Such revisions by wind power generating
stations shall be effective from 6th time block, the first being the time-block in
which notice was given. There may be one revision for each time slot of 3 hours
starting from 00:00 hours of a particular day subject to maximum of 8 revisions
during the day.

(13)Regulation 6.5.34 of the Principal Regulations shall be substituted as under:
"34. While availability declaration by ISGS shall have a resolution of one decimal
(0.1) MWand one decimal (0.1) MWh, all entitlements, requisitions and
schedules shall be rounded off to the nearest two decimals at each control area
boundary for each of the transaction, and shall have a resolution of 0.01 MW.”

(14) Para 5 of Annexure-1 to the Grid Code (Complimentary Commercial
Mechanism) shall be substituted as under:
“5. The wind generators shall be responsible for forecasting their generation upto
an accuracy of 70%. Therefore, if the actual generation is beyond +/- 30% of the
schedule, wind generator would have to bear the UI charges. For actual
generation within +/- 30% of the schedule, no deviation would be
payable/receivable by Generator, The host state , shall bear the deviation
charges for this variation, i.e within +/- 30%. However, the deviationcharges
borne by the host State due to the wind generation, shall be shared among all
the States of the country in the ratio of their peak demands in the previous month
based on the data published by CEA, in the form of a regulatory charge known
as the Renewable Regulatory Charge operated through the Renewable
Regulatory Fund (RRF). This provision shall be applicable with effect from such
date as may be notified by the Commission.

(A.K.Saxena)
Chief (Engg.)
Page 6 of 7

<!-- page 7 -->

Note: Principal Regulations were published in Gazette of India, Extraordinary, PartIII, Section 4 at Serial No. 115 on 28.4.2010 and the first amendment to the Principal
Regulations were published in the Gazette of India, Extraordinary, Part-III, Section 4
at Serial No. 60 on 6th March, 2012.

Page 7 of 7

<!-- page 8 -->

dsUnzh; fo|qr fofu;ked vk;ksx
ubZ fnYyh

6 tuojh] 2014
vf/klwpuk
la-,y&1@18@2010&dsfofovk % dsUnzh; fo|qr fofu;ked vk;ksx] fo|qr vf/kfu;e]
2003 ¼2003 dk 36½ dh /kkjk 178 dh mi/kkjk ¼2½ ds [kaM ¼N½ ds lkFk ifBr
/kkjk 79 dh mi/kkjk ¼1½ ds [kaM ¼t½ ds varxZr iznÙk 'kfDr;ksa rFkk bl fufer
lkeF;Zdkjh lHkh 'kfDr;ksa dk iz;ksx djrs gq, dsUnzh; fo|qr fofu;ked vk;ksx
¼Hkkjrh; fo|qr fxzM lafgrk½ fofu;e] 2010] ftlesa mldk igyk la'kks/ku Hkh gS
¼ftls blds i'pkr~ ^ewy fofu;e* dgk x;k gS½ dk la'kks/ku djus ds fy,
fuEufyf[kr fofu;e cukrk gS] vFkkZr~ %
1-

lf{kIr uke rFkk izkjaHk %
¼1½

bu fofu;eksa dk laf{kIr uke dsUnzh; fo|qr fofu;ked vk;ksx ¼Hkkjrh;
fo|qr fxzM lafgrk½ ¼f}Ùkh; la'kks/ku½ fofu;e] 2014 gSA

¼2½

;s fofu;e jkti= 17-2-2014 ls izo`r gksaxsA

2ewy fofu;e ds fofu;e 2 esa la'kks/ku % ewy fofu;e ds fofu;e 2 ds
mi&fofu;e ¼1½ ds [kaM ¼NNNN½ ds i'pkr~ fuEufyf[kr ,d u;k [kaM tksM+k
tk,xk] vFkkZr~%
ß¼tttt½ ^fopyu O;oLFkkiu ra= fofu;e* ls dsUnzh; fo|qr fofu;ked
vk;ksx ¼fopyu O;oLFkkiu ra= fofu;e vkSj lac) ekeys½ fofu;e] 2014
ftlesa mlds dksbZ i'pkr~orhZ la'kks/ku Hkh gS] vfHkizsr gS(
¼>>>>½ ^iwfyax dsUnz* ls ,slk mi&dsUnz vfHkizsr gS tgka oS;fDrd iou
mRikndksa ;k lkSj mRikndksa ds mRiknu dh iwfyax vxys mPp oksYVkWt Lrj ls
baVjQsflax djus ds fy, dh tkrh gS %
ijarq ;g fd tgka iou@lkSj mRiknd ds fy, dksbZ vyx iwfyax dsUnz ugha gS
vkSj mRiknu dsUnz lkekU; QhMj ds ek/;e ls tksM+k x;k gS vkSj forj.k
daiuh@,lVh;w@lhVh;w ds mi dsanz ij i;Zoflr fd;k x;k gS] ogka forj.k
daiuh@,lVh;w@lhVh;w ds mi&dsUnz dks] ;FkkfLFkfr] ,slss iou ;k lkSj mRiknd ds
fy, iwfyax dsUnz ds :i esa le>k tk,xkAÞ
3-

ewy fofu;e ds fofu;e 5 esa la'kks/ku %
¼1½ ewy fofu;e ds fofu;e 5-2 ds mifu;e ¼p½ ¼ii½¼d½ dks fuEukuqlkj
la'kksf/kr fd;k tk,xk %
ß50-5 ,ptSM ls uhps fxzM fÝDosalh esa lq/kkj ds ekeys esa mRiknu esa
dksbZ deh ugha gksuh pkfg, ¼mnkgj.k ds fy, ;fn fxzM fÝDoaslh 49-9 ls
49-95 ,ptSM esa ifjofrZr gksrh gS rks mRiknu esa dksbZ deh ugha gksxh½A
fxzM fÝDosalh esa fdlh fxjkokV ds fy, bdkbZ ls mRiknu e'khu {kerk
ds v/khu jgrs gq, bdkbZ ds ,elhvkj ds 105% ds fy, lhfer 5%
dh o`f) gksuh pkfg,AÞ

1

5

<!-- page 9 -->

¼2½ ewy fofu;e ds fofu;e 5-2 ds mifofu;e ¼i½ esa fuEufyf[kr okD; dks
gVk fn;k tk,xk %
ßrFkkfi ;fn fÝDosalh 49-8 ,ptSM ls de gksrh gS] lHkh vkaf'kd :i ls
Hkkfjr mRiknu ;wfuVsa viuh {kerk ds vuqlkj rhoz nj ij vfrfjDr Hkkj
dks mBk,axhAÞ
¼3½ ewy fofu;e ds fofu;e 5-2 ds mifofu;e ¼´½ esa] fo'ks"kdj tc
ßfÝDosalh de gks jgh gks ;k 49-7 ,ptSM ls de gksrh gSÞ 'kCnksa dks gVk
fn;k tk,xkA
¼4½ ewy fofu;e ds fofu;e 5-2 ds mifofu;e ¼M½ esa ß49-7&50-2
,ptSMÞ 'kCnksa rFkk vadksa ds LFkku ij] ß49-90&50-05 ,ptSMÞ 'kCn rFkk
vad j[ks tk,axsA
¼5½ ewy fofu;e ds fofu;e 5-4-2 ds mifofu;e ¼d½ esa] ßtc dHkh iz.kkyh
dh fÝDosalh 49-8 ,ptSM ls de gksÞ okD; dks gVk fn;k tk,xkA
¼6½ ewy fofu;e ds fofu;e 5-4-2 ds mifofu;e ¼[k½ esa] ßtc dHkh
fÝDosalh 49-7 ,ptSM ;k fuEu gksÞ OkkD; dks gVk fn;k tk,xkA
¼7½ ewy fofu;e ds fofu;e
fuEufyf[kr j[kk tk,xk %

5-4-2

ds

mifofu;e

¼N½

ds

LFkku

ij

ß¼N½ vkj,yMhlh ekud rkRdkfyd eSlst QkesZV rS;kj djsxk rkfd
ifj'kq)rk ij fuHkZj djrs gq, fofHkUu vf/kd fudklh@de fudklh@vf/kd
var%{ksi.k@de var%{ksi.k ifjfLFkfr;ksa ij Fkksd miHkksDrk ,l,yMhlh@jkT;
mi;ksfxrk@vkbZ,lth,l@{ks=h; bdkbZ@ var%{ksi.k mi;ksfxrk] }kjk vuqlwph
ls fopyu dks de djus ds fy, lqj{kk iz.kkyh dks [krjs vkSj@;k
vkdfLedrkvksa dh n'kk esa funsZ'k fn, tk ldsA lacaf/kr ,l,yMhlh@vU;
{ks=h; bdkbZ vkj,yMhlh ds bu funsZ'kksa dk rRdky vuqikyu lqfuf'pr
djasxs vkSj lacaf/kr vkj,yMhlh dks vuqikyu fjiksVZ HkstsaxsAÞ
4-

ewy fofu;e ds fofu;e 6 esa la'kks/ku %
¼1½
ewy fofu;eksa ds fofu;e 6-4-6 ds LFkku ij] fuEufyf[kr j[kk
tk,xk %
ßizR;sd {ks=h; bdkbZ dh iz.kkyh dks oSpkfjd fu;a=.k {ks= ds :i esa
le>k rFkk izpkfyr fd;k tk,xkA vkbZ,lth,l ls vkSj nh?kZ&dkfyd
igqap] e/;dkfyd vkSj vYidkfyd fuckZ/k igaqp O;oLFkkvksa ds ek/;e ls
dkUVªsDV ls vuqlwfpr fudklh dk cht xf.krh; tksM+ izR;sd {ks=h; bdkbZ
dh fudklh vuqlwph miyC/k djok,xk vkSj bls vkxkeh fnol ds vk/kkj
ij vfxze esa vo/kkfjr fd;k tk,xkA {ks=h; bdkbZ;ka vius mRiknu
vkSj@;k miHkksDrkvksa ds Hkkj dks fofu;fer djsaxh rkfd mDr vuqlwph ds
fudV {ks=h; fxzM ls mudh okLrfod fudklh dks cuk, j[kk tk ldsA
le;CykWd ds nkSjku vuqKkr vf/kdre vufHkizsr fopyu O;oLFkkiu ra=
fofu;eksa esa fofufnZ"V lhekvksa ls vf/kd ugha gksxkA bl rjg ds fopyu
}kjk iz.kkyh ds iSjkehVj vuqeksfnr lhek ds vkxs foÑr ugha gksus pkfg,
rFkk ;g ikjs"k.k ykbuksa ij vLohdk;Z Hkkj dk dkj.k ugha cuus pkfg,A
rFkkfi] dqy fudklh vuqlwph ls bu fopyuksa dh dher] le;&le; ij
dsUnzh; vk;ksx }kjk fofufnZ"V fopyu O;oLFkkiu ra= ds fofu;eksa }kjk
fu/kkZfjr dh tk,xhA izR;sd {ks=h; bdkbZ izR;sd 12 le;CykWdksa ds ckn
de ls de ,d ckj vuqlwph ls fopyu ds y{k.k ds izR;korZu dks
lqfuf'pr djsxhAÞ

2

5

<!-- page 10 -->

¼2½

ewy fofu;e ds fofu;e 6-4-7 ds LFkku ij] fuEufyf[kr j[kk tk,xk %
ß7-,l,yMhlh],lbZch@forj.k vuqKfIr/kkjh fopyu O;LFkkiu ra= fofu;eksa
esa fofufnZ"V lhekvksa ds vanj vuqlwph ls fopyuksa dks /;ku esa j[krs
gq,] fudklh vuqlwfp;ksa ds Hkhrj fxzM ls jkT; dh dqy fudklh dks
ges'kk fu;af=r djasxsA lacaf/kr ,lbZch@forj.k vuqKfIr/kkjh@iz;ksDrk]
,l,yMhlh ;g lqfuf'pr djsaxs fd [kaM 5-4-2 esa mfYyf[kr Lopkfyr
ekax izca/ku Ldhe ;g lqfuf'pr djus ds fy, dk;Z djs fd ;gka dksbZ
vf/kd fudklh ugha gqbZ gSA ;fn Lopkfyr ekax izca/ku Ldhe vHkh vkjaHk
ugha dh xbZ gS rks vuqlwfp;ksa ds varxZr fxzM ls dqy fudklh dks
fu;af=r djus ds fy, eSuqvy ekax izca/ku ;kstuk ds vuqlkj dkjZokbZ
dh tk,xh vkSj Lopkfyr ekax izca/ku ;kstuk¼,Mh,e,l½ ds 'kh?kz vkajHk
gksus ds fy, lHkh dkjZokb;ka vkjaHk dh tk,axhA

¼3½
ewy fofu;e
j[kk tk,xk %

ds

fofu;e

6-4-10

ds

LFkku

ij]

fuEufyf[kr

ß10 vkbZ,lth,l ls] fdlh vufHkizsr fopyuksa dks NksM+dj] mudks
funsZf'kr nSfud vuqlwfp;ksa ds vuqlkj fo|qr mRiknu djus dh lkekU;r%]
vis{kk dh tkrh gSA le;CykWd ds nkSjku vuqKs; vf/kdre fopyu dks
fopyu O;oLFkkiu ra= fofu;eksa esa fofufnZ"V lhekvksa ls vf/kd dh
vuqefr ugha gksxhA ,sls fopyuksa dks vuqKs; lhekvksa ds vkxs gkzl ds
fy, iz.kkyh iSjkehVj ugha gksuk pkfg, vkSj blls vLohdk;Z ykbZu yksfMax
ugha gksuh pkfg,A iwoZ fo|qr la;= mRiknu vuqlwfp;ksa ls vufHkizsr
fopyuksa dks] ;fn dksbZ gS] fopyu O;oLFkkiu ra= fofu;eksa ds vuqlkj
leqfpr :i ls r; fd;k tk,xkA blds vykok] ladqpu dk dkj.k cuus
okys fopyuksa dks dsUnzh; fo|qr fofu;ked vk;ksx ¼okLrfod le;
izpkyu esa ladqyu voeqfDr ds mik;½ fofu;e] 2009 ds vuqlkj r;
fd;k tk,xkAÞ
¼4½

ewy fofu;e ds fofu;e 6-4-11 dks gVk fn;k tk,xkA

¼5½ ewy fofu;e ds fofu;e 6-4-12 ds LFkku ij fuEufyf[kr j[kk tk,xk %
ß12- mijksDr esa fdlh ckr ds gksrs gq, Hkh] lacaf/kr vkj,yMhlh
vkdfLedrkvksa] vFkkZr~ ykbZuksa@VªkalQkjejksa dh vf/kd yksfMax] vlkekU;
oksYVrk] iz.kkyh lqj{kk dks [krjs dh n'kk esa mudh fudklh@mRiknu dks
c<+kus@de djus ds fy, ,l,yMhlh@vkbZ,lth,l@vU; {ks=h; bdkbZ;ksa
dks funsZ'k ns ldsxhA ,sls funsZ'kksa ij rRdky dkjZokbZ dh tk,xhA ;fn
bl fLFkfr ij rRdky dkjZokbZ fd, tkus dh vko';drk ugha gS vkSj
vkj,yMhlh ds ikl fo'ys"k.k djus dk dqN le; gS rks og bl ckr dh
tkap djsxk fd D;k ;g fLFkfr vuqlwfp;ksa ls fopyu ds dkj.k mRiUu
gqbZ gS vkSj bUgsa QhMjksa dks [kksyus tSls leqfpr mik; ds ek/;e ls
dkjZokbZ djus ls iwoZ ;fn ,l,yMhlh@vkj,yMhlh }kjk vko';d le>k
tk,] lekIr fd;k tk,xk] ftlls dsUnzh; fo|qr fofu;ked vk;ksx
¼varj&jkfT;d ikjs"k.k esa la;kstdrk] nh?kZdkfyd igaqp vkSj e/;dkfyd
fuckZ/k igaqp iznku djuk rFkk lac) ekeys½ fofu;e] 2009 rFkk
dsUnzh; fo|qr fofu;ked vk;ksx ¼varj&jkfT;d ikjs"k.k esa fuckZ/k igaqp½
fofu;e] 2008 ds vuqlkj vkjaHk dh xbZ nh?kZdkfyd] e/;dkfyd
xzkgdksa ;k e/;dkfyd xzkgdksa dh vuqlwfpr vkiwfrZ izHkkfor gksxhA
;fn vYidkfyd@e/;dkfyd fuckZ/k igaqp ;k nh?kZdkfyd igaqp dks de
fd;k tkrk gS rks vkj,yMhlh mu dkj.kksa ds laca/k esa fjiksVZ izLrqr djsxk
ftlds dkj.k cgqr lh vuqlwfp;ksa ,oa ,tsafl;ksa ls fopyuksa dks de djus
esa leFkZ ugha Fkk ftlls vko';d dkjZokbZ ugha dh tk ldhAÞ

3

5

<!-- page 11 -->

¼6½

ewy fofu;e ds fofu;e 6-4-15 dks gVk fn;k tk,xkA

¼7½
ewy fofu;e
j[kk tk,xk %

ds

fofu;e

6-4-24

ds

LFkku

ij]

fuEufyf[kr

ß24- gkbMªks mRiknu dsUnzksa ls ;g vk'kk dh tkrh gS fd os fxzM fÝDosalh
ifjorZuksa vkSj varizokZg mrkj&p<+ko dk izR;qÙkj nsaA le;&CykWd ds nkSjku
vuqKs; vf/kdre fopyu dsfofovk fopyu O;oLFkkiu ra= fofu;eksa ds
vuqlkj gksaxsAÞ
¼8½

ewy fofu;e ds fofu;e 6-5-9 gVk fn;k tk,xkA

¼9½ ewy fofu;e
j[kk tk,xk %

ds

fofu;e

6-5-13

ds

LFkku

ij]

fuEufyf[kr

ß13 gkbMªks mRiknu dsUnz ds fy, lacaf/kr Hkkj izs"k.k dsUnz }kjk vafre
:i ls nh xbZ vuqlwph lkekU;r% ,slh gksxh fd fdlh fnu esa vuqlwfpr
ÅtkZ iwokZuqekfur@fu;ksftr ty miyC/krk@fudklh ij vk/kkfjr mRiknu
dsUnz }kjk ;Fkk?kksf"kr ml fnu dks miyC/k gksus ds fy, izR;kf'kr dqy
ÅtkZ ¼,Dl cl½ ds lerqY; gksxhA ;g Hkh vk'kk dh tk,xh fd ml
fnu mRiknu dsUnz }kjk okLrfod :i ls vkiwfrZ dh xbZ dqy ÅtkZ bl
mís'; ls ?kksf"kr dqy ÅtkZ ds cjkcj gksxh fd ty fudklh dh vis{kk
dh iwfrZ dj yh xbZ gSAÞ
¼10½
ewy fofu;e ds fofu;e 6-5-17 ds LFkku ij] fuEufyf[kr j[kk
tk,xk %
ß17- fdlh fxzM ck/kk dh fLFkfr esa] nh?kZdkfyd@e/;dkfyd@vYidkfyd
ds varxZr fo|qr dh vkiwfrZ djus okys lHkh vkbZ,lth,l ds vuqlwfpr
mRiknu dks muds okLrfod mRiknu ds lerqY; djus ds fy, la'kksf/kr
ekuk tk,xk vkSj fgrkf/kdkfj;ksa@Øsrkvksa dh vuqlwfpr fudkfl;ksa dks fxzM
ck/kkvksa }kjk izHkkfor lHkh le;CykWdksa ds fy, la'kksf/kr ekuk tk,xkA
fxzM ck/kkvksa vkSj bldh vof/k dk izek.ku vkj,yMhlh }kjk fd;k
tk,xkA
lacaf/kr vkj,yMhlh }kjk ck/kkvksa dh ?kks"k.kk ;Fkk'kh?kz dh tk,xhA bl
vk'k; dh lwpuk ml {ks= ds vkj,yMhlh }kjk mudh osclkbV ij Mkyh
tk,xh ftlesa ;g ck/kk ?kfVr gqbZ gSA osclkbV ij lwpuk dks fn;k tkuk
vkj,yMhlh }kjk ck/kk dh ?kks"k.kk ds :i esa le>k tk,xkA lHkh {ks=h;
bdkbZ;ka ck/kk ij /;ku nsaxh vkSj vius Lrj ij leqfpr dkjZokbZ djsaxhA
f}i{kh; vYidkfyd vkSj lkewfgd laO;ogkjksa ds fy,] fxzM ck/kkvksa dh
vof/k ds fy, ys[kksa ds O;oLFkkiu dh iz.kkyh jk"Vªh; fo|qr lfefr }kjk
rS;kj dh tk,xh vkSj mls vuqeksnu ds fy, vk;ksx dks izLrqr fd;k
tk,xkA bl iz.kkyh esa mu n`"Vkarksa dks lfEefyr djus ds fy, n`"Vkar
mnkgj.kkas lfgr lHkh laHko ifjn`';ksa dks lfEefyr fd;k tk,xk tgka fxzM
ck/kk ;k rks vkaf'kd gS ;k blls dsoy ,d {ks= izHkkfor gqvk gSAÞ
¼11½ ewy fofu;e 6-5-18 ds LFkku ij] fuEufyf[kr j[kk tk,xk %
ß18- {kerk izHkkj vkSj ÅtkZ izHkkj lfgr nksrjQk VSfjQ ¼gkbMªks dsUnzksa
dks NksM+dj½ okys vkbZ,lth,l }kjk ?kksf"kr {kerk dk iqujh{k.k vkSj fnu
dh 'ks"k vof/k ds fy, fgrkf/kdkjh ¼fgrkf/kdkfj;ksa½ }kjk ekax ds vfxze
uksfVl lfgr vuqefr nh tk,xhA
,sls ekeyksa esa la'kksf/kr
vuqlwfp;ksa@?kksf"kr {kerk le;CykWd dh lax.kuk djrs gq, pkSFks le;CykWd
ls izHkkoh gks tk,xh ftlesa iqujhf{kr ds fy, vuqjks/k izFke gksus okys
vkj,yMhlh esa izkIr fd;k x;k gksAÞ
4

5

<!-- page 12 -->

¼12½ ewy fofu;e esa 6-5-23 ds LFkku ij] fuEufyf[kr j[kk tk,xk %
ß23- 15-7-2013 ls iou ÅtkZ mRiknu la;a=ksa dh vuqlwph dh tk,xh
tgka ikjs"k.k ;k forj.k iz.kkyh ds fy, duSD'ku IokbaV ¼ftls iwfyax dsUnz
dgk tkrk gS½ ls lac) bl izdkj ds la;a=ksa dh dqy mRiknu {kerk 10
eSxkokV vkSj mlls vf/kd gS vkSj duSD'ku IokbaV 3-5-2010 ds ckn
vkjaHk fd, x, iwfyax dsUnzksa ds fy, 33 dsoh vkSj mlls vf/kd gSA
blls de Lrj dh {kerk vkSj oksYVrk Lrj ds fy, rFkk iqjkus iou
QkeksZa ds fy, ¼,d iou QkeZ iou VckZbu mRikndkas dk laxzg.k gS tks
lkekU; duSD'ku IokbaV ls lac) gS½] ;FkkfLFkfr] iou mRiknd rFkk
ikjs"k.k ;k forj.k bdkbZ ds chp ikjLifjd :i ls fofuf'pr fd;k tk
lds] ;fn blds izfrdwy lafonkRed djkj fo|eku ugha gSA iou ÅtkZ
mRiknu dsUnzksa }kjk vuqlwph ¼lkewfgd laO;ogkjksa dks NksM+dj½ dks
;FkkfLFkfr] ,l,yMhlh@vkj,yMhlh dks] vfxze uksfVl nsrs gq, la'kksf/kr
fd;k tk ldsxkA iou ÅtkZ mRiknu dsUnzksa }kjk ,slk la'kks/ku igys
le;CykWd ls 'kq# gksdj ml NBs CykWd ls izHkkoh gksxk ftlesa uksfVl
fn;k x;k FkkA fnu ds nkSjku vf/kdre 8 iqujh{k.kksa ds v/khu jgrs gq,]
fo'ks"k fnu ds 00-00 ?kaVs ls vkjaHk gksus okys 3 ?kaVksa ds izR;sd
le;CykWd ds fy, ,d iqujh{k.k fd;k tk ldsxkA
¼13½ ewy fofu;e ds fofu;e 6-5-34 ds LFkku ij] fuEufyf[kr j[kk
tk,xk %
ß34- vkbZ,lth,l }kjk miyC/krk ?kks"k.kk djrs le;] 1 Mslhey ¼0-1½
esxkokV dk izLrko fd;k tk,xk rFkk 1 Mslhey ¼0-1½ esxkokV ?kaVs lHkh
gdnkfj;ksa] v/;is{kkvksa ,oa vuqlwfp;ksa dks 0-01 esxkokV ds izLrko gsrq
gj ,d laO;ogkj ds fy, izR;sd fu;a=.k {ks= lhek ij fudVre 2
Mslheyks ij iw.kkZfdar fd;k tk,xkAÞ
¼14½ fxzM lafgrk ¼izfriwjd okf.kfT;d ra=½ ds vuqca/k&1 ds iSjk 5 ds LFkku
ij fuEufyf[kr j[kk tk,xk %
ß5- iou mRiknd 70% dh ifj'kq)rk rd vius mRiknu ds iwokZuqeku
yxkus ds fy, mÙkjnk;h gksaxsA bl izdkj] ;fn okLrfod mRiknu vuqlwph
ds $@&30% ls vf/kd gS rks iou mRiknd dks fopyu izHkkjksa dk ogu
djuk gksxkA vuqlwph ds $@&30% ds Hkhrj okLrfod mRiknu ds fy,
mRiknd }kjk dksbZ ;wvkbZ lans;@izkI; ugha gksxkA estcku jkT; bl
fofHkUurk] vFkkZr~ $@&30% ds vanj ds fy, fopyu izHkkjksa dk ogu
djsxkA rFkkfi] iou mRiknd ds dkj.k estcku jkT; }kjk ogu fd, x,
fopyu izHkkjksa dks uohdj.kh; fofu;ked fuf/k ds ek/;e ls izpkfyr
uohdj.kh; fofue; izHkkj ds :i esa vfHkKkr fofu;ked izHkkj ds :i
esa lhbZ, }kjk izdkf'kr MkVk ij vk/kkfjr iwoZorhZ ekg esa O;Lrre ekaxksa
ds vuqikr esa ns'k ds lHkh jkT;ksa esa foHkkftr fd;k tk,xkA ;g mica/k
,slh rkjh[k ls ykxw gksxk tks vk;ksx }kjk vf/klwfpr fd;k tk,AÞ

¼vt; dqekj lDlsuk½
çeq[k ¼bathfu;fjax½
fVIi.k % ewy fofu;e] Hkkjr ds jkti=] vlk/kkj.k Hkkx 3] [kaM 4] Øe
la[;k 115 rkjh[k 28-4-2010 dks izdkf'kr fd, x, Fks] rFkk ewy fofu;eksa ds
izFke la'kks/ku dks Hkkjr ds jkti=] vlk/kkj.k] Hkkx 3] [kaM 4 Øe la[;k 60]
rkjh[k 6 ekpZ] 2012 dks izdkf'kr fd;k x;k FkkA
5

5
