---
doc_id: "450b49ffaead94bd"
source_url: "https://dgmr.mizoram.gov.in/uploads/attachments/2025/10/85a619d5b68bd2c985cc835ac962d864/ex-523-policy-mizoram-state-minor-mineral-policy-2025.pdf"
ministry: "Directorate Of Geology & Mining, Mizoram"
title: "Ex-523 - Policy - Mizoram State Minor Mineral Policy, 2025.pdf"
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0c6698550800aa03"
---

<!-- page 1 -->

-1-

Ex-523/2025

The Mizoram Gazette
EXTRAORDINARY

Published by Authority

RNI No. 27009/1973
VOL - LIV Aizawl, Wednesday 30.07.2025 Shravana 8, S.E. 1947, Issue No. 523

NOTIFICATION
No.J-30012/10/2025-C&I, the 29th July, 2025:
In the interest of public services and as approved
by the Council of Ministers conveyed vide. No.J.11011/2/2025-POL/ii dt 29.07.2025 the Governor of
Mizoram is pleased to notify ‘Mizoram State Minor Mineral Policy, 2025’ with immediate effect as follows: 1.

VISION
Minor Minerals are a valuable finite and non-renewable natural resource being the vital raw material
for the infrastructure development such as construction of road, bridges, highways, buildings, dams,
airport etc. Exploration, extraction and management of minor minerals have to be guided by State
goals and perspectives, to be integrated into the overall strategy of the State’s economic development.
Scientific mining has to go hand-in-hand with sustainable management practices for the long-term
economic development of the State. The Govt. of Mizoram knowing the importance of development of
minerals found it necessary to outline policy relating to the development of mineral resources of the
State.
Natural resources, including minor mineral minerals, are a shared inheritance where the State is a
trustee on behalf of the people and therefore it is imperative that allocation of mineral resources is
done in a fair and transparent manner to ensure equitable distribution of mineral wealth to sub-serve
the common good. Mining needs to be carried out in an environmentally sustainable manner keeping
stakeholders’ participation, and devolution of benefits to the mining affected persons with the overall
objective of maintaining high level of trust between all stakeholders.
It shall also be ensured that the regulatory environment is conducive to ease of doing business with
simpler, transparent and time-bound procedures for obtaining clearances. Since mining contributes
significantly to state revenues, there is a need for an efficient regulatory mechanism with high
penetration of e-governance systems to prevent illegal mining and pilferages of minerals as well as
State’s wealth. Mining contributes significantly to employment generation, thus, there shall be a keen
focus on gender sensitivity in the mining sector at all levels. Endeavour shall be made to set up a
unified authority at State level for mineral development and co-ordination to fulfill objectives of this
policy.

2. REGULATION OF MINOR MINERALS
2.1 Management of mineral resources is the responsibility of both the Central and State Governments in

<!-- page 2 -->

Ex-523/2025

-2-

terms of entry 54 of the Union List (List I) and entry 23 of the State List (List II) of the Seventh Schedule
of the Constitution of India. Entry 54 of List-I reads “Regulation of mines and minerals development
to the extent to which such regulation and development under the Control of the Union is declared by
Parliament by Law to be expedient in the public interest”. Also, that Entry 23 of List-II reads “Regulation
of mines and minerals development, subject to the provisions of List-I with respect to regulation and
development under the Control of the Union”. Such a law was passed by Parliament in 1957 – The Mines
and Minerals (Regulation and Development) Act, 1957 (Act 67 of 1957) which covers all minerals
including minor minerals. As per the provision of this Act, the present rule in force for minor mineral
applicable to the whole State is The Mizoram Minor Minerals (Concession and Prevention of Illegal
Mining) Rules, 2023.
2.2 In order to make the regulatory environment conducive to ease of doing business, the procedures for
grant of mineral concessions shall be transparent and seamless with an assured security of tenure along
with transferability of concessions playing a key role in minor mineral sector development.
2.3 To ensure the preparation and enforcement of mining plans, mine closure plans, scheme of mining etc.
for minor minerals, the State Directorate of Mining & Geology (DGM) has to be strengthened with
adequate man power especially mining engineers and skill sets upgraded to state-of-the-art levels by
means of capacity building and practical training conducted by both State Directorate of Mining &
Geology and Indian Bureau of Mines.
2.4 There will be an emphasis on strengthening the regulatory mechanism by incorporating E-Governance,
including satellite and remote sensing applications. Provisions shall be made for end-to-end accounting
of minor minerals in the supply chain with use of IT enabled systems in monitoring the minor mineral
exploitations, transportation and storage. Efforts shall also be made to devise appropriate mechanism(s)
for awareness and information campaigns and also for involvement of local populations to supplement
the law enforcement capabilities in preventing illegal mining by making whistle blower reward rules or
incorporation of whistle blower reward in the Illegal mining rules to be constituted in accordance with
the Mines and Minerals (Development and Regulation) Amendment Act, 2015.
2.5 To formulate the minor minerals concession rules applicable for the whole State of Mizoram which
includes Star Rating of Mines provisions in accordance with the Mines and Minerals (Development
and Regulation) Amendment Act, 2015. The star rating of mines for minor minerals should also be
guided by the provisions embedded in the Mineral Conservation and Development Rules, 2017.
2.6 To formulate the District Mineral Foundation (DMF) Rules in accordance with the Pradhan Mantri
Khanij Kshetra Kalyan Yojana (PMKKKY) guidelines and also a State Mineral Exploration Trust
(SMET) for minor minerals guided by the National Mineral Exploration Trust (NMET) set up by
Government of India.
3. ROLE OF STATE IN MINOR MINERAL DEVELOPMENT
3.1 The core functions of state in mining of minor minerals will be facilitation and regulation of exploration
and mining activities, making provision for development of infrastructure and non-tax revenue
collection with safety going in tandem. An Annual Working Plan/Road map for the development of
minor mineral sector shall be brought out by the nodal Department viz. Directorate of Geology &
Mining. Grant of clearances for commencement of mining operations shall be streamlined with simpler
and time bound procedures facilitated through an on-line public portal with provision for generating
triggers at higher level in the event of delay. As part of Initiative for ease of doing business the States
shall make an endeavour to auction mineral blocks with pre-embedded statutory clearances. Mineral
bearing area/zone shall be earmarked as Mining Land in the land record by the States. Endeavour
shall be made to rationalize those areas that were reserved but remained unused by PSUs, for speedy
development.

<!-- page 3 -->

-3-

Ex-523/2025

3.2 Trust is vital to the ability of the State to achieve sustained growth in mining sector. State will endeavor
continuously to increase trust level between government, miners, local communities and other
stakeholders through openness, fairness, better regulation, responsiveness, inclusive policy making.
All the legislations for minor minerals shall ensure judicious exploitation being finite resources and
export to neighbouring States/ countries is not encouraged.
4 SURVEYING AND EXPLORATION
4.1 The State is blessed with minor minerals such as sandstone, shale, river/ pit sand and gravel in
abundance. Brick earth and clay are found in sporadic nature at the present scenario of mining of
minor minerals and has the geological environment for occurrence of other minor minerals which
waits prospecting and exploration. To explore the State’s entire geological potential, it shall be ensured
that regional and detailed exploration is carried out systematically, scientifically and intensively over
the entire geologically conducive mineral bearing area of the State, using correct mining methods and
state-of-the-art technologies in a time bound manner in accordance with a globally accepted public
reporting standard for ensuring reliability of reporting and acceptability to financial institutions such
as UNFC Codification as far as practicable.
4.2 While the Government agencies will continue to perform the tasks assigned to them for survey and
exploration, the private sector would be encouraged to take up exploration activities. Government
agencies will expend public funds particularly in areas where private sector investments are not
forthcoming due to reasons such as high uncertainties. States may be mandated to create dedicated
funding for boosting exploration activities to be supported by State Mineral Exploration Trust and
National Mineral Exploration Trust funds.
4.3 Exploration may be incentivized to attract private investments as well as state-of-the-art technology,
within the ambit of auction regime, through Right of First Refusal (ROFR) at the time of auction in
virgin areas on revenue sharing basis or any other appropriate incentive.
4.4 In case of the sites where minor mineral deposits are found at the outcrop, Pre-Feasibility Survey (PFS)
have to be conducted by mining engineers/ geologists prior to grant of short-term mining permits and
by mining engineers in the case of mining leases.
5 MINING AND MINERAL DEVELOPMENT
5.1 General Strategy
Minor minerals are important resource for the construction sectors. There is a huge demand for minor
minerals in view of the rapid urbanization and the projected growth in the manufacturing sector.
Extraction and management of minerals has to be guided by long-term and sustainable mining
development. Mining technology will be upgraded to ensure extraction and utilization of the entire
Run-of-Mines (RoM) to be zero-waste mining.
A thrust will be given to extraction of minor mineral resources in which the State is well endowed so
that the needs of domestic industry are fully met keeping in mind both present and future needs.
5.2 Conservation and Mineral Development
Conservation of minerals shall be construed not in the restrictive sense of abstinence from consumption
or preservation for use in the distant future but as a positive concept leading to augmentation of reserve/
resource base. There shall be an adequate and effective legal and institutional framework promoting
zero-waste mining as the ultimate goal and a commitment to prevent sub-optimal and unscientific
mining. The research-based utilization of rejected stone dust finer than 75μm may be mixed with
cement at varying proportions to manufacture solid block which can be the substitute for bricks, ACC
block or even dimensional stones should be encouraged.

<!-- page 4 -->

Ex-523/2025

-4-

5.3 Scientific Methods of Mining
Mine development and mineral conservation of minor minerals as governed by the rules and regulations
will be on sound scientific basis, with the regulatory agencies, viz. the State Directorate of Geology &
Mining must have sufficient qualified mining engineers to ensure preparation of optimal Mining plan,
Mine Closure plans (PMCP and FMCP) and Scheme of Mining (SoM) for all mining leases and mining
permits.
Besides these, all mines/quarries of short-term mining permits requiring explosives and blasting must
have Blast Design with Safety guidelines prepared by mining engineers so as to use explosives safely
and judiciously and to obtain Explosive Licence from concerned District Magistrates or Petroleum and
Explosives Safety Organization (PESO), Govt. of India. Conditions of mining leases regarding extent of
area/size, shape, disposition with reference to geological boundaries and other mining conditions shall
be such as to favourably predispose the leased areas to systematic, scientific, optimum, and complete
extraction of minerals. The regulatory agencies will be suitably strengthened through capacity building
measures in terms of adequate man-powers such as mining engineers, technology, equipment and
skill-set.
5.4 Mining Machinery and Mineral Beneficiation Equipment
Use of equipment and machinery which will improve the efficiency, productivity and economics of
mining operations as well as mineral beneficiation process, safety and health of persons working in the
mines/beneficiation plant and surrounding areas shall be encouraged. Availability of such equipment
and machinery shall be incentivized and freely allowed.
5.5 Human Resource Development
Development of human resources shall be the mainstay to improve the competitive edge of the State
mining industry with a focus on improving gender balance in mining industry. Emphasis shall be
laid on mechanization, computerization, automation and adoption of state-of-the-art technology
of the existing and new mining units. The human resource development strategy shall be suitably
reoriented for the purpose. Facilities for basic and specialized training shall be constantly reviewed
and upgraded from time to time, to ensure that adequately trained manpower at all levels is available
for the development of mines and minerals. As the mining sector takes off, the country will need
more and more mining engineers, Environment engineers, geo-scientists and IT professionals. The
functionaries of the State Governments shall be trained to strengthen the mining sector regulation as
per national standards. Besides these, the mining engineers of Directorate of Geology & Mining shall
conduct routine capacity building/training to the mine/quarry owners and operators at least once in a
year and for this fund shall be allocated by the State Government.
5.6 Infrastructure Development
Mining infrastructure requires a special thrust as the economic efficiency of transportation of minor
minerals from pit mouth to user point is closely linked to the end use value of the mineral and of
the viability of the industry producing and using the minor mineral. An enabling environment will
be created to allow mining companies to undertake construction of such infrastructure including
construction of conventional transportation networks like rail and road for their own usage in
coordination of State/Central agencies. The contribution of mineral development to regional and more
specifically peripheral development, commensurate with the huge investment in large mining projects is
substantial. An integrated approach shall be encouraged encompassing mineral development, regional
development and the social and economic well-being of the local, and particularly, tribal population of
the State.

<!-- page 5 -->

-5-

Ex-523/2025

5.7 Financial Support for Mining
Mining is an eligible activity for obtaining financial support from financial institutions. However,
at present only those mining projects which have a substantial component of mining machinery,
equipment and buildings are being financed. Steps shall be taken to facilitate financing of prospecting,
surveying, exploration and mine development. Efforts shall be made to grant mining the status of
industry. The state Government shall try to make arrangement of mechanical equipment for drilling
of shot-holes to petty quarry owners in the cluster areas to enhance production and revenue collection
and ultimately for to uplift the economic condition of the miners.
5.8 Small Minor Mineral Deposits
Small and isolated deposits of minor minerals are scattered at various places in the State. These often
lend themselves to economic extraction through small scale mining. With modest demand on capital
expenditure and short lead-time, they provide employment opportunities for the local population.
However, due to lack of economies of scale they can also lead to sub-optimal mining and ecological
disturbance. Efforts will be made for promotion of small mineral deposits in a scientific and efficient
manner while safeguarding vital environmental and ecological imperatives.
Where small deposits of minor minerals are not susceptible to viable mining, a cluster approach will be
adopted by granting the deposits together as a single lease within a geographically defined boundary as
suggested by National Mineral Policy 2019.
In grant of mineral concessions for small deposits in Scheduled Areas, endeavour will be made to
accommodate Scheduled Tribes while extending enabling environment to carry-out mining operations
in a systematic and efficient manner.
5.9 River Sand Minerals
Efforts will be made to encourage extraction of the replenishable deposits of river sand minerals
for improved economic growth by ensuring coordination between the different agencies viz., State
Governments, Directorate of Geology & Mining and Environment, Forests & Climate Change (EF&CC)
Department, so that regulation of mining of river sand minerals is in conformity with the mining and
other environmental laws. Efforts will also be made to ensure preparation of District Survey Report
(DSR) for mining districts for sand mining are undertaken for obtaining environmental clearances.
5.10 Protection of Environment
Extraction of minerals impacts other natural resources like land, water, air and forest. It is necessary
to take a comprehensive view to facilitate the choice or order of land use keeping in view the needs
of development as well as needs of protecting the forests, environment and ecology and to conserve
biodiversity of areas to be mined.
Prevention and mitigation of adverse environmental effects due to mining in accordance with the
latest scientific norms and modern afforestation practices shall form integral part of mine development
strategy in every instance. All mining shall be undertaken within the parameters of a comprehensive
Sustainable Development Framework which will ensure that environmental, economic and social
considerations are integrated effectively in all decisions on mines and minerals issues. The guiding
principle shall be that a miner shall leave the mining area in an ecological shape which is as good as it
was before the commencement of mining or better with least impact on flora and fauna of the area.
Mining operations shall not ordinarily be taken up in identified ecologically fragile and biologically
rich areas. The State Government shall identify such areas that are critically fragile in terms of ecology

<!-- page 6 -->

Ex-523/2025

-6-

and declare as ‘in-violate areas’ or ‘no-go areas’ out of bounds for mining. In order to achieve a better
semblance between mineral based development and environment, there shall be an endeavour to
create Exclusive Mining Zone (EMZ) with prior in-principle statutory clearances demarcated for the
mineralized belt/zone to avoid conflict of interest and to curtail delay in commencement of mining
operation.
With a view to reduce pollution, carbon footprint and operational costs, use of renewable sources of
energy at mining sites will be encouraged through appropriate incentives. Appropriate sensitization
training about environmental issues will be provided to all workers involved in mining operations.
5.11 Sustainable Development in Mining
Environmental, economic and social considerations must be taken into account as early as possible in
the decision-making process, to ensure sustainable development in the mining sector which envisions
mining as financially viable; socially responsible; environmentally, technically and scientifically sound;
with a long-term view of development; uses mineral resources optimally; and, ensures sustainable
post-closure land uses.
The State Government shall set a benchmark against which all mining operations may be evaluated
in terms of their comparative performance on sustainable development framework and enforce
commitment on part of the mining companies to adopt sustainable development practices for achieving
environmental and social goals. Sustainable development parameters shall be incorporated in the Star
rating of mines of minor minerals.
5.12 Welfare of Project Affected Persons
5.12 (a) Relief & Rehabilitation of Displaced and Affected Persons
Mining operations can involve acquisition of land held by individuals including those belonging
to the tribals and weaker sections. In all such cases a careful assessment of the economic, cultural,
environmental, and social impact on the affected persons needs to be undertaken to ensure that
suitable, appropriate, relief and rehabilitation packages are evolved.
In areas in which minor minerals occur and which are inhabited by tribal communities and
weaker sections, it is imperative to recognize resettlement and rehabilitation issues as intrinsic to
the development process of the affected zone. A mechanism will be evolved which would actually
improve the living standards of the affected population and ensure them a sustainable income. For this
purpose, all the provisions of rehabilitation and resettlement given in the Right to Fair Compensation
and Transparency in Land Acquisition, Rehabilitation and Resettlement (RFCTLARR) Act, 2013 as
amended from time to time will be followed.
5.12 (b) Devolution of Mining Benefits to Project Affected Persons
The mining legislation has been amended to provide for the establishment of District Mineral
Foundation (“DMF”) with the objective of working for the interest and benefit of persons, and areas,
affected by mining related operations. The objectives for devolution of mining benefits under DMF
for inclusive and equitable development of project affected persons and areas are to be guided by the
provisions of the Pradhan Mantri Khanij Kshetra Kalyan Yojana (“PMKKKY”).
It shall be the endeavour of the State Government to monitor and review the implementation of
schemes under DMF for giving effect to PMKKKY for a State web portal may be developed with free
access to the public. In order to effectively implement the PMKKKY Scheme the State shall recruit
at least one technical man-power ie. mining engineer with supporting staff to oversee all activities

<!-- page 7 -->

-7-

Ex-523/2025

including preparation of Statements for audit of all Governing Council of DMF for the entire Districts
of the State.
5.12 (c) Welfare of Tribal Communities
Existence of minor minerals in tribal areas with rich biodiversity requires a comprehensive assessment.
Land acquisition and displacement of tribal communities due to mining projects may lead to distress
in tribal communities living in Scheduled Areas.
Grant of mineral concessions (viz. mining leases/ mining permits) in Scheduled Areas shall be guided
by the provisions contained in article 244 read with Fifth and Sixth Schedules to the Constitution
relating to administration of the Scheduled Areas and Tribal Areas and the provisions of the Panchayats
(Extension to the Scheduled Areas) Act, 1996 and the Scheduled Tribes and Other Traditional Forest
Dwellers (Recognition of Forest Rights) Act, 2006 or any other relevant statutory acts protecting the
interests of tribals. All Relevant Acts/Rules related to rehabilitation and resettlement like The Right
to Fair Compensation and Transparency in Land Acquisition, Rehabilitation and Resettlement
(RFCTLARR) Act, 2013, subsequent amendments or any other relevant acts/rules shall be strictly
implemented.
5.13 Mine Closures
Proper and systematic mine closure is the key component in mining project to be sustainable and
environmentally friendly mining. At the initial phase while preparing mining plan, the mining plan
shall include Progressive Mine Closure Plan (PMCP) to be implemented while depleting the minor
mineral resources. Once the reserves in mine are completely exhausted there is need for scientific mine
closure guided by Final Mine Closure Plan (FMCP) which will not only restore ecology and regenerate
bio diversity but also take into account the socio-economic aspects of such closure. Where mining
activities have been spread over a few decades, mining communities get established and closure of the
mine means not only loss of jobs for them but also disruption of community life. Mine closure should
be done in an orderly and systematic manner.
State Government has a role in ensuring that post-production mine decommissioning and land
reclamation are an integral part of the mine development process; that financial provisions for the costs
incurred in mine closure are accorded a high level of priority by the industry; and those consistent
approaches are adopted for efficient and effective mine reclamation and rehabilitation.
5.14 Safety of mines and mine-workers
Mining operations at times are hazardous in nature. Accidents happen and often result in occupational
health problems, serious bodily injury or even loss of life. Efforts must be directed towards the
development and adoption of mining methods which would increase the safety of workers and reduce
accidents. Towards this end, participation and cooperation of mine workers shall be secured. Steps will
also be taken to minimize the adverse impact of mining on the health and safety of workers and the
surrounding population. Directorate of Geology & Mining (DGM) should be further strengthened
through adequate manpower viz. mining engineers, equipments, and skill sets in order to carry out the
regulatory role for ensuring miners’ health and mine safety effectively as mandated by the Mines Act
1952 and guidelines of Directorate General of Mines Safety (DGMS), Govt. of India.
5.15 Minor Mineral Security
Minor mineral resources security is an important issue with strategic as well as economic significance.
Securing access to sufficient, reliable, affordable, and sustainable supplies of minor minerals is
increasingly becoming an important factor for functioning of downstream industries and the overall

<!-- page 8 -->

Ex-523/2025

-8-

economy. Hence, ensuring long-term mineral security for the State shall be taken up with utmost
priority. In order to conserve State’s finite mineral resources, exporting the minor minerals to the
neighbouring States and countries is not encouraged.
6. RESEARCH AND DEVELOPMENT
6.1 Research in Mining Methods
Mining methods determine the safety, economy, speed and the percentage of extraction of the ore
reserves from a mine. Research and development thrust shall be directed specially in the areas of
rock mechanics, ground control, mine planning and design engineering, equipment deployment
and maintenance, energy conservation, environmental protection, safety of operations and human
engineering. Also, the DGM shall send its mining engineers for training and workshop conducted by
Indian Bureau of Mines, Directorate General of Mines Safety and Central Institute of Mining and Fuel
Research (CIMFR) to grab technological advances of the country.
6.2. Development in Mining Technology and Capacity building for Mining Engineers
Mining Plans, Mine Closure Plans, Scheme of Mining (SoM) and Blast Design shall be developed
and improved based on the latest technology and innovations guided by the Ministry of Mines and
Directorate General of Mines Safety (DGMS), Govt. of India from time to time. The Directorate
of Geology & Mining (DGM) shall conduct annual training programmes for mining engineers for
imparting knowledge in latest technological advances, mining reforms and amendments of mining
laws that governs mineral administrations.
6.3 Capacity building for State Geologists
The Directorate of Geology & Mining (DGM) shall conduct annual training programmes for newly
recruited geologists for amalgamating theoretical knowledge to practical use in the State. For this,
mining geology in line with State geological setup and mineralogy shall be given priority. The DGM
shall also send its geologist to the training centre of Geological Survey of India (GSI) on the subject
which shall be beneficial for mineral exploration in the State.
7.

ROYALTY SHARING MECHANISM
Management of mineral resources is the responsibility of both the Central and State Governments in
terms of entry 54 of the Union List (List I) and entry 23 of the State List (List II) of the Seventh Schedule
of the Constitution of India. Such a law was passed by Parliament in 1957 – The Mines and Minerals
(Regulation and Development) Act, 1957 (Act 67 of 1957) which covers all minerals including minor
minerals. As per the provision of this central act, the present rule in force for minor mineral applicable
to the whole State is The Mizoram Minor Minerals (Concession and Prevention of Illegal Mining)
Rules, 2023. As there is royalty sharing provision in the Constitution of India by the State with the
Autonomous District Councils the State shall device such sharing mechanism as per the provisions of
Sixth Schedule to the Constitution of India.

8.

INTER GENERATIONAL EQUITY
There is a need to understand that natural resources, including minerals, are a shared inheritance where
the state is the trustee on behalf of the people to ensure that future generations receive the benefit of
inheritance. State Governments will endeavour to ensure that the full value of the extracted minerals is
received by the State. Inter generational equity emphasizes that the current generation should manage
resources and make decisions in a way that does not compromise the ability of future generations to
meet their own needs. It calls for responsible use and conservation of natural resources, including both
renewable and non-renewable resources.

<!-- page 9 -->

-99.

Ex-523/2025

OUTCOMES AND CONCLUSION
Minor mineral wealth is finite and non renewable. It is a major resource for development. The
management of this precious resource and its optimal and economical use are matters of both national
and regional importance. Under the ‘Make in India’ initiative, the Government of India aims to increase
the share of the manufacturing sector in the economy. This national initiative needs to be adopted in
the State level requiring a holistic development of the mineral sector on a sustainable basis in order to
fulfill the demand of downstream industries dependent on minor mineral supply.
The outcomes expected from these policy proposals are, an increase in the production of minor
minerals in sustainable manner without compromising with safety and conservation of environment
without compromising the ability of future generations to meet their own needs. The success of the
State Minor Mineral Policy will depend largely on commitment of all concerned to fulfill its underlying
principles and objectives.
Dr. Lalzirmawia Chhangte,
Commissioner & Secretary to the Govt. of Mizoram,
Commerce & Industries Department

Published and Issued by Controller, Printing & Stationery Department, Government of Mizoram
Printed at the Mizoram Government Press, Aizawl. C/30
