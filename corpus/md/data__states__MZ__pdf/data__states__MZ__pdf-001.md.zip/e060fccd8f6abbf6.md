---
doc_id: "e060fccd8f6abbf6"
source_url: "https://dmr.mizoram.gov.in/uploads/attachments/2024/09/23e0bfdf5f463e5a0af09f8d6dbcde7d/posts-327-sealed-tender-notice.pdf"
ministry: "Disaster management and Rehabilitation Department, Mizoram"
title: "Sealed Tender Notice"
date: ""
pages: 9
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "66683891d08b55b0"
---

<!-- page 1 -->

GOVERNMENT OF MIZORAM .
DIRECTORATE OF DISASTER MANAGEMENT & REHABILITATION
MIZORAM :: AIZAWL
SRR a RR
Dated Aizawl the 234 September, 2024
SEALED TENDER NOTICE
No.B.13016/39/2023-DTE(DMR) : Sealed Tender in plain paper is invited for supply of
the following Search and Rescue equipment for implementation of Up-Scaling of Aapda
Mitra Scheme which will be received by the undersigned on or before 24t October, 2024,
12:00noon and will be opened on the same date at 2:00PM in the Directorate of Disaster
Management & Rehabilitation, Chawnpui, Aizawl, Mizoram. Bids may be submitted for all
or any of the items.
[SLNo. [List of Search and reseue equipment | Quantity]
foam with reflective tape, light and whistle
[6 | Paddles Plastic 43 inches (50x20em balde size) | 20”
[8 | ABC Fire Extinguisher 4kgs——SSSSSSSSSSS tO]
|_9 [Emergency Spotlight 12hoursruntime—=—S—S~Ss Si
10 [Toolkit C™~—“—™tCSYYSCiC*‘*‘C
[Wirecuter SSS
Pies tO
[Screwdriver SC™~—sSC i
[15 [traficcone SSS tC

<!-- page 2 -->

28 [Alpinerescue equipment SSS
[Haness OO CidSC SY
Jumma

: Tender documents containing detailed terms and conditions can be
obtained from Directorate of Disaster Management & Rehabilitation, Chawnpui, Aizawl,
: Mizoram during office hours or from the department's website : dmr.mizoram.gov.in.
Sd/- R. VANRENGPUIA
Director,
Disaster Management and Rehabilitation,
Mizoram, Aizawl.
Memo No.B.13016/39/2023-DTE(DMR) : Dated Aizawl the 23" September, 2024
Copy to:
1. P.S. to Hon’ble Minister, Disaster Management & Rehabilitation Department,
Government of Mizoram.

2. P.S. to Secretary, Disaster Management & Rehabilitation Department, Government

of Mizoram.

3. Director, Information & Public Relations Department for information with a

request to publish the Tender Notice to 1 (one) Local newspaper and 2 (two) State
Level leading daily newspaper for two consecutive days as per short form
attached.
uence Manger, DM&R for uploading in the department’s website.
5. Guard File.
6. Notice Board. N
Director,
Disaster Management and Rehabilitation,
4 Mizoram, Aizawl.

<!-- page 3 -->

TERMS AND CONDITIONS

1. The samples or Brochures bearing all features of whole items should be submitted
along with the tender.

2, Tender should be accompanied by the under mentioned Certificate and
documents :

a. Scheduled Tribe Tenderers should submit photo copy of Tribal Certificate
and latest Profession Tax Clearance Certificate duly attested. Original copy
should be produced at the time of opening of the tenders, if demanded.

b. Photo copy of GST Registration Certificate duly attested. Original copy
should be produced at the time of opening of the tenders, if demanded.

c. Non-Tribal tenderer should affix Non-Judicial Court Fee Stamp worth at
least Rs. 7.50/-.

d. Integrity Declaration as per the form enclosed in Annexure,

3. Earnest money of 2% of the quoted price of each of the items should be deposited
in the form of Banker Cheque/ Demand Draft/ Fixed Deposit Receipt issued by
Nationalised Bank, or any Bank recognized or sponsored by Government duly
pledged in favour of the Director, DM&R Govt. of Mizoram, Aizawl & the same
should be submitted along with the Quotation.

4, Any quotations without Earnest Money will not be accepted. Earnest Money will
be liable to forfeiture in case of short supply or supply of inferior quality of the
quotation items.

5. The Tenderers should quote their rates both in figure and in words inclusive of all
taxes for each of the items and should be destined FOR Aizawl for all items.
Transportation/ Shipping or any additional charge will be borne by the successful
bidder. The Tenderers may submit tenders for any or all of the Items.

6. The cover of the Quotations should be prominently subscribed as “SEALED
TENDER FOR SUPPLY OF SEARCH & RESCUE EQUIPMENT” and should be
addressed to the Director, Disaster Management & Rehabilitation Department,
Govt. of Mizoram, Aizawl. In case, the quotation is sent by postal service, it should
be registered with acknowledgement due. The Director of Disaster Management
& Rehabilitation, Government of Mizoram will not be responsible for delay or late
receipt of the tender document.

7. The Department is not bound to accept the lowest rates, and reserves the right to
accept or reject any quotations with proper justification.

8. Successful Tenderers should be able to supply the materials within one month or
specified time by the Department or DM&R. They should supply the materials
exactly of the same make, type, quality, etc. of the sample submitted,

9. The materials supplied by the suppliers will be physically checked by appointed
officers before acceptance, Payment of bills will be made only on acceptance and
countersignature on the body of the bill by the accepting officer.

<!-- page 4 -->

10.In the event of any dispute or controversy relating to the selection of
supplier/materials supplied, the decision of the Secretary to Government of
Mizoram, Disaster Management & Rehabilitation Department shall be final and
binding.

11. Quotation submitted without following the above terms & conditions shall be
summarily rejected.

12. Separate envelope should be used for TECHNICAL BID as well as for PRICE BID.
The word “TECHNICAL BID/PRICE BID” shall be prominently marked on the top
of the envelope separately. Both these bids shall further be put in one envelope
and sealed properly before putting in the tender box duly super scribed.
Tenderer(s) shall indicate complete specifications and all features of the items.

13. The Technical Bids will be opened first on 24th October, 2024, 2:00PM and the
Price Bids will be opened only after scrutiny of technical bid and technical
evaluation of the system.

14. The tenderer can remain present himself or his authorize representative at the
time of opening of tender.

15.A copy of terms and conditions duly signed by the tenderer, as a token of
acceptance of the same should be attached alongwith the tender.

16. The tendering firm will also submit a certificate that the product offered by them
is as per technical specifications of the tender.

17. All the bidders whose technical bid is declared qualified will demonstrate their
product before the Bid Evaluation Committee at a short notice.

18. Only manufacturers, authorized distributors/authorized dealers can participate
in the tender, the firm should submit proof of their manufacturing, authorized
dealership/distributor. This is subject to verification if necessary.

19. Incomplete tender/conditional tenders will not be accepted.

20.All Small Scale Industries units registered with National Small Industries
Corporation Ltd./ Director General of Supplies & Disposals for this item as per
specification are exempted from the Earnest Money Deposit. They have to enclose
valid registration document/exemption certificate with their tender,

21. Tenderer would not be permitted to alter or modify their bids after expiry of the
deadline for receipt of Bids.

22. The quoted price must be inclusive of all taxes such as GST and other charges etc.
No claim for taxes/charges will be entertained at a later stage. Nothing over and
above the quoted price would be payable to the successful bidder. Tenderer must
quote the net price both in words as well as in figures. Any over writing/cutting
etc. render the tender invalid.

23. The firm whose rates are accepted will have to deposit 5% of the total cost of the
item as Performance Deposit in the form of Banker Cheque/ Demand Draft/ Fixed
Deposit Receipt issued by Nationalised Bank, or any Bank recognized or
sponsored by Government duly pledged in favour of the Director, DM&R Govt. of
Mizoram, Aizawl before the supply order is placed to the firm. In case the firm does
not complete the supply within the delivery period, liquidated damage charges

<!-- page 5 -->

will be charged @ 2% of total cost per month of the item and action will be taken
to blacklisting the firm and forfeiture of its Security Money. No interest will be
given on Security Money.

24. In case the firm fails to deposit the security money, the EMD of the firm will be
forfeited.

25. The rates will be valid till supply of the item is completed, in all respect.

26. In case the firm fails to supply the items within stipulated delivery period, the item
will be procured from the open market and the difference of cost, if any, will be
recovered from the Security money and pending bills of the defaulting firm, by
calling explanation after issuing notice.

27.The quantity of the items mentioned in the tender notice can be increased or
decreased at any stage till the delivery of consignment is completed.

28. The payment will be made on receipt/acceptance of store in good condition as per
prescribed specification. No advance payment will be made.

29.No claim for interest in case of delayed payment will be entertained by the
Department.

30. The Purchase Committee reserves the right to relax any terms and condition in the
public interest with the approval of competent authority.

31. The Purchase Committee reserves the right to reject any tender or all tenders with
proper justification.

32. In case of violation of any clause of contract/agreement deed, the explanation of
the firm can be called by issuing show cause notice, if the reply is not found
satisfactory. Security Money can be forfeited as well as action for blacklisting can
also be taken prior to taking any legal action.

33. The tender will be rejected straight way without assigning any reasons if the firm
involves in any criminal case, declared blacklisted by any Government/Semi-
government Department/Agencies etc.

34. In case of any differences, the firm can be called for negotiation to patch up the
differences on table prior to approaching court.

35. The bidder should carry a warranty/guarantee of subjected store for a period of
at least one year.

36. In case of any litigation, the legal jurisdiction for settlement shall be Aizawl only.

(R. VANRENGPUIA)
Director,
Disaster Management and Rehabilitation,
Mizoram, Aizawl.

<!-- page 6 -->

ANNEXURE
INTEGRITY DECLARATION
(Declaration to be made by the Bidder/Contractor)
I, (Bidder’s name) hereby declared that :

1) (name of the firm) has not been blacklisted or
debarred in the past by the Central/State Government or organization from taking part in
Government tenders in India

OR
has been debarred on by Govt. of Mizoram/Govt. of India but the debarment
has been withdrawn w.e.f and has not been debarred till date.

2) No employees of the firm have direct relationship/relative(s) with officials dealing with the file
connected with the tender being invited. (*In case, if any employees of the firm have direct
relationship/relative(s) with the officials, the same shall be disclosed by the bidder alongwith this
declaration in Form A)

3) No employees of the Firm were involved in any illegal activities.

4) | have read, understood and comply with the procurement rules, regulations and procedures.

5) | will provide accurate, complete and truthful information in my bid.

6) | will not engage in any collusive or anti competitive behaviour.

7) | will not offer or give any bribes, gifts, or other improper benefits to influence the procurement
process.

8) | will maintain the confidentiality of all procurement information.

9) | will not contact or influence any procurement officials or decision-makers improperly.

| understand that any breach of this declaration may result in disqualification from the
procurement process, and | may be subject to further action.

“Relatives for the purpose of this declaration includes father including step-father; mother including

step mother; son including step-son; daughter-in-law; daughter; son-in-law; brother including step-

brother; sister including step-sister”
. Name & Signature of Bidder with seal
FORMA
SI. No. Name of employees Name of official dealing with Relationship with the
the file official

Po Po

[| Pe

Date

. Name & Signature of Bidder with seal

<!-- page 7 -->

[SiNo, | Uist of earch & rescue equipment with specification | Quantiy
1 Personal Floatation Device 30
Material : Life Jacket made of polyurethane foam
Accessories : Retro reflective tape, light and whistle
2 Emergency light solar enabled 30
Power: 100watt
Lumen : 1000
Backup time : 12 hours run time
Battery : 11000mAH
Charging time : 5-8 hrs
Weight : Not more than 2 kgs
3 Safety gloves 30
Material : Polyamide
Coating : Palm and finger tip with nitrile coated
4 Rope 30
Dimensions : 10mm
Length : 30 mtrs
Type of material : Nylon
Color : Yellow
5 Lifebuoys 30
Material : PVC
Color : Orange
Dimensions : 70cm outer diametre
Paddles 20
Material : Plastic
Length: 43 inches
Balde Size : 50x20cm
7 Bucket 20
Material : Galvanized metal
Capacity : 10 Litres
Fire Extinguisher 10
Type : ABC
Quantity : 4 kgs
Emergency Spot light 10
Backup time: 12 hours run time
Battery : 132000mAH
Material : ABS body
Accessories : Side light, power bank for Mobile charging
SR
eoecieeesehaies a
pete es al gee ae
ESTAR RE Co
11 | Axe 10
Weight : 600g
Length : not less than or eq ual to 600gram

<!-- page 8 -->

12 Backboard Stretcher 10
Type : Spine board
Material : Fibreglass
Load Bearing : not less than or equal to 159 kgs
13 Sleeping bag 30
Occupancy : 1
Length : Upto 6.6 feet
Temperatures : 4-150C
14 Cordoning tape 5
Length : 50mtr
Material : Polyethylene
Markings : DISASTER SITE DO NOT CROSS
15 Traffic cone 10
Color : Red or Orange
Material : ABS
Height : Not less that or equal to 75cm
75 Bist Aide sutabieor 25 persons,
17 Twin Progned Graphel, 10
Type : 3 Hooks
Size : L- 8 inch W - 5 inch
18 Throw Bag with rope 10
Length : 50 ft.
Rope type : 10.5mm floatation
Color : Orange /Yellow
19 GUM Boots 30
Size : Free size
Material : Rubber
20 Safety Goggles 30
Size : Free size
Material : Polycarbonate
Glass : Transparent
21 Safety Helmet (Water rafting) 30
Weight : Not less than or equal to 330 gram
Size: 55-61cm
Material : ABS, EPP
22 Boat Navigation lights 20
Color : Red Green, white
24 Chart board 5
Size : 2x3ft
Accessories : Stand
Type : Magnetic
25 Precision Compass Military type 10
Type : Hand held, Water resistant, Shock Proof
26 Chain Saw machine 5
Guide bar length 18inch
Engine type : 2 stroke engine (petro

<!-- page 9 -->

28 [Alpinerescueequipment |
Sit Harness 15
Type: EN 12277Type C
UIAA Certified
Jummar Pair 15
For use with ropes of diameter 8 - 13 mm:

According to EN 12841 type B with a static rope 8 10 - 13 mm
According to EN 567 with a rope @ 8-13 mm

UIAA Certified

Fig-8 15
Compatibility : Rope diameters (8.5 - 13 mm)

Strength : 25kN

UIAA Certified

Carabiner oval shape 15
Strength :

Major axis - 24kN,

Minor axis 8kn,

Open strength - 8kN

UIAA Certified

29 Climbing rope 15
Size : Not less than or equal to 10.5 mm
Length : 100 metres
Type : Brided
Wight per metre : 74 grams
Yearn : Polyamide
Elngation at 1.5KN : 3.6%

Static breaking strength : 27kN
Shrinkage : 0.8%

Sheath slippage : 5mm
Proportion sheath / core : 45/55
UIAA Certified
