---
doc_id: "f1bcf8aeabffd1c5"
source_url: "https://dhte.mizoram.gov.in/uploads/attachments/2024/09/8fecc74df1f57076dd8666985be01289/ex-529-hte.pdf"
ministry: "Higher and Technical Education Department, Mizoram"
title: "The Mizoram State Higher Education Council Rules 2024"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5aa17384a5ee7fd6"
---

<!-- page 1 -->

-1-

Ex-529/2024

The Mizoram Gazette
EXTRAORDINARY

Published by Authority

RNI No. 27009/1973
VOL - LIII Aizawl, Tuesday 20.08.2024 Sravana 29, S.E. 1946, Issue No. 529

NOTIFICATION
No.B.13018/2/2019-HTE(RUSA), the 13th August, 2024:
As per approval of the Council of
Ministers meeting held on 09.08.2024 circulated vide Memo No.J.11011/1/2024-POL/Vol-I, dated
09.08.2024, and in exercise of the power conferred by section 21 of the Mizoram State Higher Education
Council Act, 2017 (Act 11 of 2017),the Government of Mizoram is pleased to make the following rules,
namely:1.

Short title, extent and commencement .(1) These rules may be called The Mizoram State Higher Education Council Rules, 2024.
(2) It shall have the like extent as the Principal Act.
(3) They shall come into force from the date of publication in the Official Gazette.

2.

Definitions.(1) In these rules, unless the subject or context otherwise requires, –

(a)
“Act” means The Mizoram State Higher Education Council Act, 2017;
(2) Words and expressions used herein but not defined shall have the same meanings assigned to

them in the Act.
3.

Council Secretariat: Staff Composition and Salary/Sumptuary Allowances .(1) The Office of the Executive Council shall be administered by the Member Secretary, assisted by
adequate number of staff whose nature of appointment will be as per sub-section (1) of section13
of the Act. The supporting officers and staff may comprise of such employees as decided by the
Executive Council to the barest minimum subject to further approval of the Government.
(2) In case the Vice Chairman and the Member-Secretary are not full-time appointees, the incumbents
shall be entitled to monthly sumptuary allowancesas decided by the Government from time to
time.

4.

Council Meetings & Allowances.(1) The Executive Council may normally convene quarterly meetings and the meetings shall be notified
by the Member Secretary on the advice of the Chairman/ Vice Chairman at least 7 days in advance.

<!-- page 2 -->

Ex-529/2024

-2-

(2) Members of the Council shall be entitled to sitting allowances at the rate prescribed by the
Government from time to time. TA/DA shall be provided to outstation members as applicable to
Group ‘A’ officers of the entry grade under the State Government .
5.

Management of funds of the Council.The funds of the Council shall be managed by observing the following principles:(1) The funds so received by the Council under sub-section (1) of section15 of the Act shall be managed
by the Executive Council by observing the extant financial rules and norms of the Government.
(2) Bank account(s) shall be operated by designated officials under joint signatures as may be decided
by the Executive Council.
(3) In order to maintain proper recording of all the financial transactions of the Council systematically
and to establish a balance between optimal expenditure and services by managing the sources of
the Council in the most efficient way, the Council shall maintain –
i)
ii)
iii)
iv)
v)
vi)
vii)

Cash Book as per G.A.R. 3.
Register of Cheques issued as G.A.R. 4.
Bill Register as per G.A.R. 9.
Bill Transit Register as per G.A.R. 10.
Acquittance Roll as per G.A.R. 11
Stock Registers of assets and property as per Form GFR 24.
Investment Register showing amount of fund being invested, name of instruments, date of
initial investment and maturity date of the investment.

(4) Any fund received from the Central or State Government or any other source(s) for a specific
purpose shall be utilized for the purpose only for which the fund was sanctioned. However, in case
of exigencies when the funds are required for other purposes, the Executive Council may pass a
resolution to that effect giving full justifications, subject to approval of the Funding Agency.
(5) The Executive Council shall prepare annual budgetary estimate(s) to be submitted to the
Government that may be reflected in the Annual Financial Statement in the form of Grants-inAids for the Council. The budgetary estimate of the Council shall consist of expenditure to meet
requirement for establishment charges and for implementing certain programmes of the Council.
The extent of grant shall be determined on the basis of staff strength of the Council, plus an actual
requirement basis. The Council shall keep the extent of requirement of grant under this head to the
barest minimum.
(6) The Council may utilize funds defrayed from the funds received and any surplus remaining,
under its discretion, for any purpose which are considered essential by the Executive Council for
implementing its programmes and for the promotion of higher education underlined in section 14
of the Act.
(7) (a) Any surplus remaining fund shall be invested by the Council as per the following broad
principles-

<!-- page 3 -->

-3i)

Ex-529/2024

Investment shall be made in instruments ensuring the safety of fund.

ii) There shall be no speculation on the yield obtaining from the investment. It shall be known
at the time of making the investment except for investment in debt mutual funds. However,
in case of investment in marketable debt-instruments, (viz., mutual fund debt instruments,
Government securities and T bills) there is a risk that final yield may differ from yield estimated
at the time of investment due to movement in prices of the security, if such debt instruments
are sold due to unforeseen circumstances before final maturity date (i.e., they are not held to
maturity). Such investment will not be treated as having speculative yield. Similarly, in case
of premature encashment of bank term deposits due to unforeseen exigencies, the difference
between fixed yield at the time of investment and actual yield at premature payment will not be
speculative yield.
iii) Since investment in debt schemes of mutual funds are subject to market risks, the track record
of the scheme shall be taken into account for taking investment decisions.
iv) The forecast of surplus availability may be worked out normally for a period of one year at any
point of time so as to deploy available funds on longer term basis at better yields. This forecasting
exercise shall ideally be done every quarter.
(b) The Council shall invest in one or more of the following instruments, subject to the broad principles
as outlined as above.
i) Treasury bills and Government of India securities.
ii) Term deposits with any scheduled commercial bank incorporated in India.
(8) Any aspect of financial management and transactions including budget and accounts matters
which are not specifically provided in these rules shall be formulated, regulated and decided by
the Executive Council subject to approval of the Government.
6.

Annual Statements of Accounts.(1) The Annual Statement of Accounts shall be prepared by the Council as per prescribed form at
Annexure (FORMATs for preparation of Annual Statement of Accounts) appended hereto in
these rules.

7.

The Rights, Privileges and Authority of Auditors.(1) The rights, privileges and authority of the auditors appointed under sub-section (3) of section 13
shall be.a) The right to access books of accounts, vouchers, and relevant documents of the Council at all
times during his term of office;
b) The right to obtain whatever information or explanation he requires in performing his duty;
c) The right to suggest suitable modifications in the method of accounting followed by the
Council;
d) The right to sign the Auditor’s Report;
e) The right to receive the remuneration fixed by the appointing authority;

<!-- page 4 -->

Ex-529/2024

-4-

(2) The Auditor(s) shall prepare Audit Notes and Receipts & Payments Accounts of the Council,
reflecting on all cash transactions exhibiting both Receipts and Payments and closing balance,
and submit to the Council for necessary action, with a copy to the Government.
8.

Annual Report.(1) The Council shall submit its Annual Report every year to the Government not later than second
quarter ending of every Financial Year. The Annual Report shall be prepared in the form of booklet
in A4 size papers, and it shall invariably containi)
ii)
iii)
iv)

Chairman’s/ Member Secretary’s report;
Mission and vision statement of the Council;
Administration of the Council;
Council’s activities/performance including Programmes and Projects implemented of the
preceding year;
v) Auditor’s report on the financial statement of the preceding year;
vi) Statement of accounts and Balance sheet of the preceding year;
vii) Notes to the financial statement of the preceding year;
viii) Other information deemed relevant to stake holders. Programmes and Projects implemented.
(2) The Annual report Booklet after approved by the Department of Higher & Technical Education
Department, Government of Mizoram shall be published either in the form of hard or soft copy
or in both.
The Mizoram State Higher Education Council Rules, 2024 was vetted by Law & Judicial Department,
Govt. of Mizoram vide I.D.No.LJD 17/2024/122, dt.15.07.2024

Madhup Vyas
Commr. & Secretary to the Govt. of Mizoram.

<!-- page 5 -->

-5-

Ex-529/2024

ANNEXURE
(FORMATs for preparation of Annual Statement of Accounts)
FORMAT-I
MAJOR HEADWISE AND OBJECT HEADWISE ALLOCATION
Actual of the
preceding
year

Head of Account

B.E
of the current
year

R.E
of the current
year

B.E
for the coming year

Major Head:
Object Head:
(31) – Grants-in-Aid General (Salary)
(32) – Grants-in-Aid General (NonSalary)
(35) – Grants for creation of Capital
Assets
(41) – Secret Service Expenditure
(54) – Investment
(55) – Loans and Advances
TOTAL

FORMAT-II

STATE/CSS

SECTOR:
MAJOR HEAD:
SUB-MAJOR HEAD: (Total Amount figures in lakh of rupees. The last figures after the decimal may be rounded off to the nearest zero

figures)

MINOR HEAD SUB-HEAD:
DETAIL HEAD:

Object Head as
per standard
object head

Actual of the
preceding
year

B.E
of the current
year

1

2

3

Revised Estimate for the current year
Anticipated
Total
Expenditure
Actuals for
Revised
for the
the first 6
Estimates
remaining 6
months of
Of the
months of
the current
current
the current
year
year
year
4
5
6

Budget
Estimate
Of the following
year
7

TOTAL
Note:

1. Inputs of all detail heads under a sub-head should be totaled invariably.
2. Estimates in respect of STATE/CSS are to be prepared in separate sets using the same Proforma.

Page 7 of 9

<!-- page 6 -->

Ex-529/2024
3.
4.

-6Actual Expenditure of Salary Head at Column 4 will include Salary for the month of March, of the current
year and the Anticipated Expenditure for Salary at Column 5 will cover up to Salary of February of the
coming year.
Salary for BE for the current FY year may be filled up based on Proforma-III.

FORMAT-III
ABSTRACT OF SALARY REQUIREMENT FOR GRANTS-IN-AID-GENERAL (SALARY) (BUDGET ESTIMATE FOR THE
COMING YEAR)
STATE/CSS
MAJOR HEAD:
SUB-MAJOR HEAD: (Total Amount figures in lakh of rupees. The last figures after the decimal may be rounded off to the nearest zero
figures)

MINOR HEAD:
SUB-HEAD:
DETAIL HEAD:
Sl.
Pay
No
Bill/
Sanction
No.
1

2

No. of
Post
in the
Pay
Bill
3

Concerned
Treasury

Total of
pay

TOTAL
of
NPA

TOTAL
Basic Pay
(5+6)

Total
Allowances
(DA+HRA+
SCA+Ors)

GRAND
TOTAL
(Col.7+8)

4

5

6

7

8

9

TOTAL
REQUIREMENT
(Vide Note)
10

TOTAL
Note: 1 . Column 10 will be [Col.9 + (Col.7 X 0.03 + Col.7 X 1.03 X 0.1 + Col.7 X 1.03 X 0.08)] X12
2. Other personal claim should not be included.

FORMAT-IV
ABSTRACT OF SALARY REQUIREMENT FOR GRANTS-IN-AID-GENERAL (SALARY) (BUDGET ESTIMATE FOR THE
COMING YEAR)
(FOR CONTRACT EMPLOYEES)
MAJOR HEAD:
SUB-MAJOR HEAD: (Total Amount figures in lakh of rupees. The last figures after the decimal may be rounded off to the nearest zero
figures)

MINOR HEAD:
SUB HEAD:
Sl.No
Name of post
1

2

No. of post

Rate of
remuneration

3

4

Total
remuneration
for one month
5

Requirement of Wages for the
coming year
6

Total

FORMAT-V
ABSTRACT OF SALARY REQUIREMENT FOR GRANTS-IN-AID-GENERAL (SALARY) (BUDGET ESTIMATE FOR THE
COMING YEAR)
(FOR PROVISIONAL EMPLOYEES/ MUSTER ROLL EMPLOYEES)
STATE/CSS
MAJOR HEAD:
SUB-MAJOR HEAD: (Total Amount figures in lakh of rupees. The last figures after the decimal may be rounded off to the nearest zero
figures)

MINOR HEAD:
SUB HEAD:
Sl.No
Category of M.R
Employees
1
2

No. of post

Rate of Wages

3

4

Total

Page 8 of 9

Total wages
(3X4)
5

Requirement of Wages for the
coming year
6

<!-- page 7 -->

-7-

Ex-529/2024

FORMAT-VI
REQUIREMENT FOR ONGOING WORKS (CSS)

Sl.
No

Name
of
Works

Head of
Account
(upto
Detailed
Head
Level)

1

2

3

Approved
Cost

Expenditure
incurred
upto date

Revised
Estimate
for the
current
year

Funding
/Sharing
pattern

4

5

6

7

Budget
Estimate
/Require
ment for
the
coming
year
8

Projected
Expenditure
For the next
two coming
years
9

Expected
Outcome/
Impact of
the project

10

11

TOTAL

Note:- In addition to the prescribed FORMATs laid down in the SHEC Rules, the Council may adopt
Note:- In addition to the prescribed FORMATs laid down in the SHEC Rules, the
relevant Proforma/Formats prescribed by the Finance Department of Mizoram for preparation of Annual
Council
may adopt
relevant
prescribed by the Finance
Statement
of Accounts
from year
to year asProforma/Formats
per convenience.
Department of Mizoram for preparation of Annual Statement of Accounts from
year to year as per convenience.

Published and Issued by Controller, Printing & Stationery Department, Government of Mizoram
Printed at the Mizoram Government Press, Aizawl. C/30

Page 9 of 9
