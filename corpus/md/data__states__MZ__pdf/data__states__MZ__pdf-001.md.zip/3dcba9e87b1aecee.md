---
doc_id: "3dcba9e87b1aecee"
source_url: "https://fisheries.mizoram.gov.in/uploads/attachments/d12fcbe0227e612c932c52d4a17087a1/fisheries-amendment-act-2016-pdf.pdf"
ministry: "Fisheries Department, Mizoram"
title: "Fisheries Act"
date: ""
pages: 11
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "09efc3298683fe61"
---

<!-- page 1 -->

ANNEXURE – II

The Mizoram Gazette
EXTRA ORDINARY

Published by Authority
RNI NO.27009/1973
VOL – XLVI Aizawl, Tuesday, 17.1.2017

Regn.No. NE-313(MZ)
Rs.2/-per Issue
Postal Regn. No. NE-313(MZ)2006-2008
Pausa 27,
S.E.
1938,
Issue No. 10

NOTIFICATION
No.H.12018/113/2002-LJD, the 12th January, 2017. The following Act is hereby published for general
information.

The Mizoram Fisheries (Amendment), Act, 2016
(Act No. 8 of 2016)
{Received the assent of the Governor of Mizoram on 7th December, 2005}

Sd/P.Chakraborty
Secretary
Govt. of Mizoram
Law & Judicial Department

<!-- page 2 -->

-1MIZORAM FISHERIES ACT, 2002
(ACT NO.12 OF 2005)
AN
ACT
And Mizoram Fisheries (Amendment) Act (No. 8 of 2016)
To Provide for the protection, conservation and development of Fisheries in the State of
Mizoram.
It is enacted by the State Legislative Assembly of Mizoram in the Fifty third year of the
Republic of India as follows.
CHAPTER – I
PRELIMINARY
Short title,
Extent and
Commencement

1.

(1) This Act may be called the Mizoram Fisheries
(Amendment) Act 2016.
(2) It shall extend to the whole of Mizoram [except the
areas falling under the Autonomous District Councils
set up under the Sixth Schedule to the Constitution of
India and subject to the provisions contained in the
Mizoram Forest Act, 1955 (Act No.4 of 1955) and
Wildlife Protection Act, 1972 (Central Act No.53 of
1972)].
(3) It shall come into force from the date of its publication
in the Official Gazette.

Definitions

2.

In this Act, unless the context otherwise requires:(a) “closed season” means such period as declared by the
Government so that breeding and spawning or
migration of fish are not hampered during that period
and the fish is allowed to breed at least once in its life
time;
(b) “economic variety fish” means fishes having good
growth, good market value and good acceptability by
the consumers both in culture and capture fisheries;
(c) “fish” includes finfish, shellfish and turtle in all stages
of its life;
(d) “Fishery Officer” means Director of Fisheries and
includes any officer or class of officers empowered by
the State Government to act as Fishery Officer;

<!-- page 3 -->

-2(e) “Fish Sanctuary” means water bodies or a portion of
the water bodies where fish congregates for certain
period of the year either for breeding, migration or any
other purposes, as may be notified by the Government;
(f) “Fishery Warden” means any person or persons
appointed by the Government to discharge duties and
exercise power as Fishery Warden for protection and
conservation of fishes from unlawful taking, catching
and destruction;
(g) “fixed engine” means any cage, net, trap or other
contrivance for taking fish, fixed in the soil or made
stationary in any other way;
(h) “Government” means
Mizoram;

the State Government of

(i) “Government Water Bodies” means rivers and its
tributaries within the State of Mizoram, including all
impoundment for the purpose of generating Hydroelectricity, Irrigation, Water Harvesting Dam or any
impoundment, ponds, tank, natural lake, fish sanctuary
and derelict impoundment which does not fall under
private waters;
(j) “Indigenous fishes” means the variety/species
naturally available in the water bodies within the State;
(k) “Official Gazette” means the Mizoram Gazette;
(l) “prescribed” means prescribed by rules made under
this Act;
(m) “Private Water” means any water(i) which is the exclusive property of any private
person, or
(ii) in which any person has, for the time being, an
exclusive right of fishery, whether as an owner,
lessee, or in any other capacity;
(iii) but does not include any river, canal, stream or
any other piece of water which has direct linkage
with any river, rivulet, canal or stream;
Explanation: Water shall not cease to be “private
water” by means only of the fact that a person other
than the owner thereof may have by custom a right of
fishery therein;
(n) “Schedule” means schedule appended to this Act.

<!-- page 4 -->

-3CHAPTER – II
PROTECTION, CONSERVTION AND DEVELOPMENT OF FISHERIES

Control over the
Fisheries

3.

The State Government shall have supreme control over the
Government water bodies as defined in this Act, both in
capture and culture sector in the State of Mizoram, to
which this Act extends for the purposes of fisheries.

Appointment of Fishery
Warden & Constitution
of Fishery Conservation
Board

4.

(1) The Government may appoint such person or persons
as it may deem fit and proper to discharge duties and to
exercise power as the Fishery Warden.
(2) The Fishery Warden shall assist the Fishery Officers in
the protection and conservation of fishes from unlawful
taking, catching or destruction.
(3) The term of appointment of the Fishery Warden shall
be as are provided in the rules made under this Act.
(4) Notwithstanding anything provided in sub-section (1),
no police officer below the rank of Sub-Inspector of
Police or the Fishery Extension Officer shall be
appointed to be a Fishery Warden or to discharge duties
and exercise powers as such under this Act.
(5) The Government may constitute Fishery Conservation
Board at the State, District and Village level.

Closed season
and fish
Sanctuary

5.

(1) The Government shall declare a certain period during
each calendar year to be a closed season for economic
variety of fishes as may be specified in the rules so as
to allow such fishes to avail safe breeding against
destruction or disturbance and during which no person
shall catch or kill such fishes.
(2) Separate closed seasons may be declared for separate
variety of fishes or for indigenous fishes.
(3) The Government shall declare certain portion of any
Government water body as fish sanctuary and no
person shall catch or kill fishes in any such fish
sanctuary at any time of the year.
(4) Any person who violates the provision in section 5 subsection (1), (2) and (3) above shall, on conviction, be
punished with imprisonment of one month which may
extend to three months or a fine not exceeding Rupees
Five thousand or both.

<!-- page 5 -->

-4-

Prohibition of
unauthorized
catching etc

6.

(1) No person shall, with intent to catch, take or dispose of
any fish in any Government water body,(a) use dynamite or other explosive substances, in
whatever form it may be;
(b) put any poison, lime, or other toxious materials;
(c) fix any fixed engines or nets or use of any electrical
mechanical devices or any kind of trap;
(d) catch, take, net, angle or, appropriate except in
accordance with the provisions of the rules made
under this Act;
(e) Any of the following acts or commission shall
constitute an offence, namely:(i) Wanton killing of fish juveniles, fish brooders
and other organisms which otherwise have
economic aesthetic significant biodiversity
effect on the fisheries is prohibited;
(ii) Making any obstruction or restriction which
prevent movement of fish in any form in any
Government water bodies shall be punishable
offence;
(iii) Making any diversion of natural waters for
killing of fishes is an offence;
(iv) Disturbing or destroying natural breeding
grounds in any Government water bodies by
any means shall be cognizable offence;
(v) Dumping of wastes or pollution from factory
effluents to any Government water bodies;
(vi) Fishing or killing or sale of fishes from
Government water bodies during closed
seasons;
(vii) Catching or sale of fishes from Government
water bodies below the permissible size and
weight;
(viii) Culture, seed production, rearing, distribution,
marketing and release to any Government water
bodies of fishes banned by either Central or
State Government.
(2) Any person who violates the provision in sub-section
(1)(a) above shall, on conviction, be punished with one
month imprisonment which may extend upto three
months or a fine not exceeding Rupees Five thousand
or both.
(3) Any person who violates the provision in sub-section
(1)(b) above shall, on conviction, be punished with six
months imprisonment which may extend upto twelve

<!-- page 6 -->

-5months or a fine of Rupees Ten thousand which may
extend upto Rupees Twenty thousand or both.
(4) Any person who violates the provisions in sub-section
(1)(c ) , (d) and (e) above shall, on conviction, be
punished with fifteen days imprisonment which may
extend upto thirty days or a fine upto Rupees Two
thousand Five hundred or both.
(5) Offences punishable under sub-section (2), (3) and (4)
shall be cognizable and bailable.
Prohibition of
sale etc of fish
unlawfully caught or
unfit for human
consumption

7.

The Government may, by notification in the Official
Gazette,(a) prohibit generally the offering or exposing for sale or
barter of any fish which has been caught or procured
unlawfully from any Government water body; or
(b) prohibit the offering or exposing for sale or barter of
any fish the taking of which has been in contravention
of sub-section(1) of section 6 of this Act in the opinion
of the Fishery Officer or Fishery Warden, and of such
other fishes whether from Government water body or
private water which are unhealthy for human
consumption.
(c) Any person who violates any prohibitory order issued
under section 7 shall, on conviction, be punished with
imprisonment for a minimum term of seven days which
may extend to thirty days or a fine of Rupees Two
thousand five hundred.
(d) Offences punishable under Section 7 shall be
cognizable and bailable.

Arrest without
warrant for
offence under
the Act

8.

(1) Any police officer not below the rank of Sub-Inspector
of Police or any Fishery Officer or Fishery Warden
may, without warrant, arrest or cause to be arrested any
person who has, in his view, committed any offence
punishable under section 5 or 6 or 7, as the case may
be, if such person declines to give his correct name and
address or if there is reason to suspect the accuracy of
the name and addresses, if given.
(2) A person arrested under section 5 or 6 or 7 may be
detained until his name and address have been
ascertained correctly or his identity have been
established satisfactorily, subject to the provisions
contained in section 56-59 in particular and other
related provisions of the Code of Criminal Procedure,
1973 (2 of 1974).

<!-- page 7 -->

-6-

Trial of cases

9.

(1) No Court inferior to that of the Magistrate of the First
Class shall try any offence under this Act.
(2) No Court shall take cognizance of any offence under
this Act, except on a complaint in writing of the facts
constituting the offence made by a Fishery Officer or a
Fishery Warden or a police officer not below the rank
of Sub-Inspector of Police.

Compounding
of offences

10.

(1) Any offence specified in the scheduled may be
compounded by such officer or authority as may be
empowered by the State Government in this behalf by
acceptance of a sum not less than Rupees One
thousand.
(2) On compounding an offence, the accused shall be
discharged and property seized from him/her shall be
destroyed or confiscated.

Development of
Fisheries

11.

(1) The Government may sanction grant-in-aid to fish
farmers as per the provisions of rules made under this
Act for development of fisheries.
(2) The Government may also set up such number of
Fishery Demonstration Farms and Fish Seed Farms as
it may deem fit for the encouragement of persons who
are interested in the farming.
(3) The Government may culture and develop in the
Fishery Demonstration Farms such economic variety
of fishes and indigenous fishes as it may deem fit and
proper, for supply to private persons interested in the
management or development of fisheries or
pisciculture.
(4) The Government may lease out its Farms to private or
Societies through proper terms and conditions for a
maximum period of five years.
(5) The Government may develop private or society lands
for a certain period of time and develop Fish Seed or
Feed Infrastructures through Public Private
Partnership (PPP) mode.
(6) The Government may approve, assist, register and
issue Certificate to Hatcheries, Nurseries and Rearing
Units, Fish Farms and Fish Feed manufacturing units.
(7) The Government shall have the right/power to check
and examine Nurseries, Rearing Units or any Fish
Farms at any time.
(8) The Government shall have the power to check,

<!-- page 8 -->

-7confiscate or destroy any consignment of fish seed and
feed which violates the provisions of this Act.
(9) The Government shall ensure hygienic handling,
transportation and storage of fish and fish products for
domestic marketing.
(10) Government shall be responsible for conservation of
fish fauna and replenishment of indigenous and
economic variety fishes in Government water bodies.
(11) Whenever major dam is constructed across any major
rivers of Mizoram, the Government shall ensure that
passage for fishes in order to access breeding grounds
and for migration is provided.

<!-- page 9 -->

-8CHAPTER – III
MISCELLANEOUS PROVISION
Officers to be
public servants

12.

All persons empowered to exercise power and discharge duties by
or under this Act shall be deemed to be public servant within the
meaning of section 21 of the Indian Penal Code, 1860 (Act No.45
of 1860).

Protection of
action taken in
good faith

13.

No suit, prosecution or other legal proceeding shall lie against any
Government official, for anything which is in good faith done or
intended to be done under this Act.

Dues under this
Act a public
demand

14.

Any amount of money due to the Government under this Act or
the rules made there under shall be recoverable as public demand
under the Mizoram Public Demands Recovery Act, 2001.

Power to make
rules

15.

(1) The Government may make rules for carrying out the
provisions of this Act.
(2) Without prejudice to the generality of the foregoing powers,
such rules may provide for all or any of the following matters,
namely:(a) term of appointment of the Fishery Warden;
(b) erection and use of fixed engines;
(c) dimension, size of mesh and kind of nets or fishing hooks
to be used and manner of using them and conditions under
which they may be used;
(d) use of more than one method of taking fish at one time;
(e) prescription of the closed season for various economic
variety of fishes and that of indigenous variety of fishes;
(f) such other matters as the Government may deem proper for
the better protection, conservation and improvement of
fisheries in the State or in any specified areas within the
State.
(3) Every rule made under this Act shall be laid, as soon as it is
made, before the Mizoram Legislative Assembly while it is in
session for a total period of seven days which may comprise
in one session or in two successive sessions and if, before the
expiry of the session it is laid, the Mizoram Legislative
Assembly agrees in making any modification in the rule or the
Legislative Assembly is of the opinion that the rule should not
be made, the rule shall thereafter have effect in such modified
form or be of no effect, as the case may be.

<!-- page 10 -->

-9Repeal and
savings

16.

On and from the commencement of this Act, the Lushai Hills
Autonomous District Fisheries Act, 1953 shall stand repealed.
Provided that notwithstanding such repeal, anything
done or any action taken under the Act so repealed shall, in so
far as it is not inconsistent with the provisions of this Act, be
deemed to have been made or taken under this Act and shall
continue to be in force until superseded by anything done or any
action taken under the provisions of this Act.

<!-- page 11 -->

- 10 -

SCHEDULE
Description of offences compoundable under section 10.
1.

Fishing with a net having a smaller mesh than that prescribed.

2.

Killing or taking or selling or attempting to kill, take, or sell any fish of a prohibited
species during a closed season.

3.

Fishing or attempting to fish with any method other than the prescribed method.

4.

Using at any one time more than one method of taking fish, when prohibited under the
rules made under this Act.

5.

Fishing or attempting to fish in prohibited waters.

6.

Offering or exposing for sale or barter of which is prohibited under section 7.

Sd/- P.Chakraborty
Secretary
Govt.of Mizoram
Law & Judicial Department
