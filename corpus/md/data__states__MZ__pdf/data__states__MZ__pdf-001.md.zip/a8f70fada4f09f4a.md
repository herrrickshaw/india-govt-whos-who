---
doc_id: "a8f70fada4f09f4a"
source_url: "https://sirdpr.mizoram.gov.in/uploads/attachments/2023/07/78539e96addd0a017f2bbd6dfc0ce1c2/order-committee-under-prevention-of-sexual-harassment-of-women-at-workplace-2013.pdf"
ministry: "State Institute of Rural Development & Panchayati Raj (SIRD & PR), Mizoram"
title: "Order Committee under Prevention of Sexual Harassment of Women at Workplace 2013.pdf"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "f186c4e0fc0ca62a"
---

<!-- page 1 -->

Aq\\\. STATE INSTITUTE OFRAF RURAL DEVELOPMENT & PANCHAYAPRAY>
“a yin MIZORAM : DURTLANG LEITAN, AIZAWL - 796015. S wr)
A ZORAM (State Level Apex Institute for Rural Development in Mizoram)
i Tel:0389-2362551Email:dirsirdmz@qmail.com::website: www.sirdprmizoram.gov.in
eee eons ———________—_____s________ EEE
No. F.20017/1/2015-SIRD & PR(MZ) Dated Aizawl, the 5h July, 2023.
ORDER
In the interest of public service, ‘Internal Committee and Local
Committee under the Sexual Harassment of Women (Prevention, Prohibition
and Redressal) at Workplace Act, 2013’ is hereby constituted with
the following composition with immediate effect and until further orders :
1. Dr. Knhawlsiamthanga Khawlhring, AP(VLP)
2. Dr. Margaret Lalbiakthangi, AP(RD), Officer Incharge.(9436372559 (M))
3. Dr. Lalhruaitiuangi Sailo, Sr. Core Faculty (AH)
4. Dr. Rosangpuia, Faculty(PR),SPRC
apa: "
(IRENE ZOHLIMPUII ean
Director
State Institute of Rural Development &
Panchayati Raj
Mizoram, Aizawl
Memo No F.20017/1/2015-SIRD & PR(MZ)Dated Aizawl, the BP awiy, 2023.
Copy to:
1. The Director, Women & Child Development, Social Welfare &
Tribal Department, Mizoram, Aizawl for kind information. '
2. Persons concerned for kind information and necessary action.
ale
Direetor o\
State Institute of Rural Development &
Panchayati Raj
Mizoram, Aizawl
ee
