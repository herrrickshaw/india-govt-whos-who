---
doc_id: "eabfed0c1bcada50"
source_url: "https://des.mizoram.gov.in/uploads/attachments/2026/07/b1aac0af8e39e99033ac7640c952e9cc/pages-1018-circular-guidelines-for-exp-for-survey.pdf"
ministry: "Economics and Statistics Department, Mizoram"
title: "Circular - Guidelines for exp for Survey"
date: ""
pages: 6
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "3f0b07c120b924f8"
---

<!-- page 1 -->

\ MICHAEL
/ NO.G.25020/1/2018-DES(A)
GOVERNMENT OF MIZORAM
DIRECTORATE OF ECONOMICS & STATISTICS
MIZORAM : AIZAWL
Dated Aizaw] the 14* July, 2026
CIRCULAR
| = ; .
| These guidelines shall govern the official procedure for preparing expenditure
estimates for Surveys, Censuses and Civil Registration System under Economics &
Statistics Department from the date of issuing this Circular.
COMMON GUIDELINES FOR PREPARING EXPENDITURE ESTIMATES FOR SURVEYS,
| CENSUSES AND CIVIL REGISTRATION SYSTEM UNDER ECONOMICS & STATISTICS
| DEPARTMENT
These Guidelines have been prepared to establish a uniform framework for the
preparation of expenditure estimates for surveys and censuses undertaken by the
Directorate of Economics & Statistics, Government of Mizoram. The objective is to
ensure that estimates are prepared in a transparent, realistic, and consistent manner,
while maintaining financial discipline and compliance with the applicable financial rules
and Government orders.
The estimates shall be based on the actual operational requirements of each survey or
census and shall take into account the approved survey methodology, field coverage,
staffing pattern, and prevailing rates prescribed by the Government. All expenditure
proposals shall be supported by detailed calculations and prepared in accordance with
the provisions of the Delegation of Financial Powers Rules, 1978; the Mizoram Re-
delegation of Financial Powers Rules, 2025; the General Financial Rules (GFR),
2017; the Mizoram Treasury Rules and Treasury Manual, 2011; the Fundamental
and Supplementary Rules (FRSR), Part II - Travelling Allowance Rules; Mizoram
Travelling Allowance Rules; the Mizoram Public Procurement Rules, 2020; other
relevant rules and Office Memoranda issued by the Finance Department; and such other
orders, instructions, and amendments as may be issued by the Government from time to
time.
The Directorate may review and revise these Guidelines from time to time in the light of
changes in Government policy, financial rules, survey methodology, or operational
requirements, and new surveys and censuses. Until such revisions are issued, these
Guidelines shall serve as the standard reference for the preparation of expenditure
estimates relating to all surveys and censuses undertaken by the Directorate.
1. Travelling Allowance/Daily Allowance (TA/DA)
All claims for Travelling Allowance (TA) and Daily Allowance (DA) shall be regulated in
accordance with the entitlement prescribed under the Travelling Allowance Rules,
Finance Department Office Memorandum dated 18 February 2019.

<!-- page 2 -->

- CO ee
‘2. Entitkement of Investigators and Supervisors*
\nvestigators and Supervisors may claim:
+ Advance and final TA/DA for the following surveys:
’ o Retail Price Survey (RPS)
o Wholesale Price Survey (WPS)
o Consumer Price Index (CPI) Survey
o Farm Harvest Price (FHP) Survey °
> Index of Industrial Production (IIP)
» Sample Surveys - National Sample Survey (NSS), Annual Survey of
Unincorporated Sector Enterprises (ASUSE), Periodic Labour Force
Survey (PLFS)
o Joint inspections, on-the-spot verification /inspections/supervision, CRS
inspection :
o Adhoc surveys and censuses
+ Hotel charges, where admissible. Daily Allowance (DA) shall not be
admissible for any day on which hotel charges are claimed.
+ TA/DA for approved training programmes.
« Mileage Allowance
(orjourmeys performed in own carfiani[Rs.24/im
rickshaw, own scooter, etc.
*Subject to Relevant Rules F
S.R. 71 Daily allowance may not be drawn for any day on which a Government servant
does not reach a point outside a radius of eight (8) kilometers from the duty point (i.e,
the place/office of employment) at his headquarters or return to it from a similar point.
NOTE:- The term “radius of eight kilometers” should be interpreted as meaning a
distance of eight kilometers by the shortest practicable route by which a traveler can
reach his destination by the ordinary modes of traveling.
(b) Regulation of T.A. : Traveling allowance for a local journey shall be admissible
if the temporary place of duty is beyond 8 km from the normal place of duty
irrespective of whether the journey is performed by the Government servant
from his residence or from the normal place duty.
2. For local journeys a Government servant will draw, for journey involved,
mileage allowance and in addition draw 50% of daily allowance calculated at the
rates laid down in Order (1) above, ie., where the absence from headquarters is for less
_ than twelve hours but exceeding six hours and exceeding twelve hours at 35% and 50%
ey ee ee reer

<!-- page 3 -->

(iii seen BO -
respectively: He will be paid daily allowance even if the conveyance is provided free of
charge for Jocal journeys.

3, Supervision
A. Field Supervision .
Each Supervisor shall conduct on-the-spot supervision supported by photographic
evidence displaying the date, time, geographical location (latitude and longitude), and
the name of the survey location, wherever feasible, at:
. atleast one urban location; and ;
+ atleast one rural location.
B. Paper Supervision
No Paper Supervision Allowance (Honorarium/Scrutiny Fee) shall be admissible.
4, Standard Survey Schedules and Standard Supervision Format
Standard survey schedules and a standard supervision format shall be developed and
adopted for all field surveys and supervisory inspections. The Directorate shall, as far as
possible, develop these formats internally. Where specialised technical expertise is
required, assistance may be sought from the Survey Design & Research Division (SDRD),
Enterprise Survey Division (EnSD), and Data Processing Division (DPD) of the National
Sample Survey Office (NSSO), Kolkata, under the Ministry of Statistics & Programme
Implementation (MoSPI), Government of India.
5. Reimbursement of Incidental Expenses
Subject to availability of funds and certification by the controlling officer, Investigators
and Supervisors may claim reimbursement of the following:
(i) Maxi Cab Charges
Maxi Cab fare at rate fixed by State Transport Authority of Mizoram.
6. Field Equipment
Each Investigator and Supervisor shall be provided with a training/fieldwork kit
containing:
« one field bag bearing the Golden Jubilee logo;
* pen, paper/notepad
« writing board
« folder (clear bag)
« weighing tools (as required)
digital equipments (tablets, mobile phones, etc.) (as required)

<!-- page 4 -->

NOTE: Weighing tools shall be provided for the Retail Price Survey (RPS), the Farm
Harvest Price (FHP) Survey and other ad hoc surveys in all concerned districts, unless
such equipment has been supplied recently and remains serviceable.
7, Publication and Printing
The provision for printing and publication shall be worked out on the basis of the actual
number of copies required in accordance with the revised mailing list, including
Ministries of the Government of India, Ministers of the Government of Mizoram,
Members of Mizoram Legislative Assembly, Administrative Heads of the State
Government, Heads of Departments, and other recipients as may be approved.
Printing of survey schedules, supervision formats, reports, bulletins, and other official =
publications shall ordinarily be entrusted to the Printing & Stationery Department,
Government of Mizoram. Where printing cannot be undertaken by the Printing &
Stationery Department due to capacity constraints, urgency, oF other valid reasons,
printing may be arranged through other agencies in accordance with the applicable
procurement rules and with the approval of the competent authority.
8. Training
A detailed estimate of the fund requirement for training programmes shall be prepared,
indicating the expenditure per participant or the applicable official rates under each
cost component.
9. Civil Registration System
The rates and entitlements for expenditure incurred under the Civil Registration System
(CRS) shall be regulated in accordance with the applicable financial rules and the
decisions of the Inter-Departmental Coordination Committee as recorded in its Minutes
of Meeting.
Summary of Rates 7
Item Rate (%) Basis
TA/DA |As per entitlement [Finance Department 0.M. dated
18.02.2019
« For journeys performed in|
. own car/taxi - %24/km i
Mileage + For journeys performed b Finance Department 0.M. dated
Allowance . ¥!48.02.2019
auto rickshaw, own scooter| ~~
etc. - = 12/km .
Maxi Cab Maxi Cab Rate fixed by State
3.5 per km Transport Authori i ‘
Charges port Authority of Mizoram via
order dated 12.03.2024 .
L

<!-- page 5 -->

References:
Fundamental and Supplementary Rules (FRSR), Part I - Travelling Allowance
Rules
§.R. 71 Daily allowance may not be drawn for any day on which a Government servant
does not reach a point outside a radius of eight (8) kilometers from the duty point (i.e,
the place/office of employment) at his headquarters or return to it froma similar point.
NOTE:- The term “radius of eight kilometers” should be interpreted as meaning a
distance of eight kilometers by the shortest practicable route by which a traveler can
reach his destination by the ordinary modes of traveling. L
(1) Regulation of Daily Allowance - Daily allowance for the entire absence, from
headquarters, i.e, starting with departure from headquarters and ending with arrival at
headquarters, will be regulated as follows. Full daily allowance may be granted for each
completed calendar day of absence reckoned from midnight to midnight. For absence
from headquarters for less than twenty four hours, the daily allowance will be
admissible at the following rates.
For absence not exceeding six hours: Nil
For absence exceeding six hours but Not exceeding twelve hours: 70%
For absence exceeding twelve hours: Full
2. In case the period of absence from headquarters falls on two days, it is reckoned as
two days and daily allowance is calculated for each as above. The concept of twenty four
hours is no longer operative. Similarly, daily allowance for days of departure from the
arrival at headquarters, will also be regulated accordingly.
3, Where the second tour commences on the same day on which a Government servant
returns from the first tour, each tour may be treated separately and daily allowance may
also be calculated separately subject, of course, to the condition that daily allowance
calculated separately for each tour on any calendar day shall not exceed one daily
allowance(half daily allowance for local journeys).
(2) ‘Local Journey’ - (a) Definition : The phrase ‘Local Journey’ shall be constructed to
mean a journey within the municipal limits or city in which the duty point is located. It
shall include journeys performed within the limits of suburban or other Municipalities,
Notified Areas or Cantonments contiguous to the Municipality /Corporation of the town
or city in which the duty point is located. Journeys within the limits of an urban
agglomeration within which a Government Servant’s headquarters are located will also
be treated as ‘local journey’.
(b) Regulation of T.A. : Traveling allowance for alocal journey shall be admissible
if the temporary place of duty is beyond 8 km from the normal place of duty
irrespective of whether the journey is performed by the Government servant
from his residence or from the normal place duty.
2. For local journeys a Government servant will draw, for journey involved,
mileage allowance and in addition draw 50% of daily allowance calculated at the
Bc

<!-- page 6 -->

rates laid down in Order (11) above, i.e., where the absence from headquarters is for less
than twelve hours but exceeding six hours and exceeding twelve hours at 35% and 50%
respectively. He will be paid daily allowance even if the conveyance is provided free of
charge for local journeys:
(c) Option to claim either normal T.A. or conveyance hire charges for local journey
beyond 8 km but within municipal limits - For local journey performed by a
Government servant is public interest within municipal limits but exceeding 8 km,
option may be made for the Government servant either to claim reimbursement of
conveyance hire charges under the DFPRs or to claim traveling allowance under the |
normal T.A. Rules. .
Sd/- B. LALRINHLUA
Director
Economics & Statistics
Mizoram, Aizawl
Memo No.G.25020/1/2018-DES(A) Dated Aizawl the 14* July, 2026
Copy to:-
1) Sr. PA to Director, Economics & Statistics for information.
2) PA to Joint Director, Economics & Statistics for information.
3) All officers under this Directorate.
. 4M Website Manager, for uploading in the Deptt. Website.
5) Guard File.
Al
‘Al INCHHUNGI)
Joint Director
Economics & Statistics
Mizoram, Aizawl
