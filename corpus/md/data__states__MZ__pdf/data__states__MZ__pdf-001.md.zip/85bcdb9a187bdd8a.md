---
doc_id: "85bcdb9a187bdd8a"
source_url: "https://irrigation.mizoram.gov.in/uploads/attachments/2023/02/5b77c9decb0968d8a24ed33e273d93ef/state-wter-policy-2020.pdf"
ministry: "Irrigation & Water Resources Department, Mizoram"
title: "Water Policy 2020"
date: ""
pages: 22
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "ddaa8f3c912a2c7b"
---

<!-- page 1 -->

The Mizoram Gazette -’
EXTRA ORDINARY
Published by Authority
RNI No. 27009/1973 Postal Regn. No. NE-313(MZ) 2006-2008
VOL -XLIX Aizawl, Monday 12.10.2020 Asvina 20, S.E. 1942, Issue No. 637
EN OP
NOTIFICATION
No. B.18016/1/2018-I&WR/188, the 12" October, 2020: As per approval of the Council of
Ministers in it’s mecting held on 1.10.2020 conveyed vide No. J.11011/1/2020-Pol/Vol-VI dt.5.10.2020
and in the interest of public service, the Governor of Mizoram is pleased to notify the Mizoram State Water
| Policy 2020 with immediate effect.
Sangchhin Chinzah, :
Secretary to the Govt. of Mizoram,
Irrigation & Water Resources Department.
4

<!-- page 2 -->

Ex-637/2020 =~
Mizoram State Water Policy 2020
Background
Water is the most crucial element for sustaining life. The source of water in Mizoram is rain
that varies with season and flows into its springs, rivers, lakes, ponds, reservoirs and into the
ground. Topography, changing population, changing land use, and variations in rainfall across
years are impacting availability of water in the state. A sustainable management of this system
is therefore essential and has to be guided by developmental aspirations of the state which |
would inter-alia account for geographical conditions, hydrological status (surface and ground
water), water allocation priorities and other specific needs.
The state of Mizoram, with an area of 21,081 km? is located in the north-eastern part of the
country. The state is landlocked and shares an international border with Bangladesh on the
west and Myanmar on the east. The GSDP of Mizoram has grown at a CAGR of 11.04%
between 2005-06 and 2015-16; and the per capita GSDP in 2015-16 was USD 1,734, which
was 12% higher than the national average.’
Water is the most crucial element for sustaining life and is required for all aspects of life. The
principal source of water in Mizoram is precipitation that varies both spatially and temporally, §
and flows into springs, rivers, lakes, ponds, reservoirs and as ground water. The hilly \
topography along with the increasing population, changing land-use, and variations in rainfall
across years impacts the availability of water in the state.
A sustainable management of water as a resource is, therefore, essential would inter-alia
account for geographical conditions, hydrological status (surface and ground water), water
demand and allocation priorities, and other specific needs.
Current Supply and Demand Side Scenario of Water Resources in
Mizoram ie
The water consumption scenario in a particular region can be unraveled through an
understanding of the demand-supply landscape. This entails an analysis of the precipitation
pattern, population growth, agriculture and livestock pattern (including Jhum), industrial
landscape and energy production scenario is required. Figure 1 provides an analytical
framework for estimation of a water balance for the study area.
« Rainfall TR ET ART 7
* Runoff Rey pia cae ey
heyy ate nema
* Groundwater ct Re eee
© Surface Water I SAIEEMIGY
» Evapotranspiration ~ —- , Re f
Water Balance
© Residential
© Industrial SAGE ¢
¢ Agricultural Re Ate a ie “2
. © Crop => |e Cope ne 5
© Livestock Demands
© Ecological =
Figure 1: Analytical framework for estimation of water balance for a study area Supply Side Assessment
‘ ioram: Lane of Blue Mountains, IBEF (2017) Accessc< rom hos bet orto wnloadMizoram-Januan
2017.pdf on 16.11.2018 fom Dapsi’www.ibel orgidownload/Mizoram-January.

<!-- page 3 -->

sires Ex-637/2020
Ninety percent of the annual precipitation in Mizoram falls between March and September,
: and 72% of the annual rainfall in the State occurs between the months of June and
September. There is scanty rainfall in the winter months, leading to water scarcity issues in
certain pockets. Analysis of IMD regional precipitation data for a 115 year period for Nagaland,
Manipur, Mizoram and Tripura (NMM), considered as a combined region in the IMD data set,
presents a declining trend.” The decline is of the order of 3.94 mm/year at a 99% confidence
level. Figure presents the annual trends of precipitation between 1901 and 2015. The
observed decline is significantly steeper for the latest 50 years spanning the period 1965-2015
(11.32 mm/year) as compared to 63 years (8 mm/year) of observation since 1901.
4,500
4,000 |
E 3,500 |
5 3,000
' 2,000 | Ky
&
1,500 | .
1,000 |» “ - ; - sony 1
BSSRRAARER ASTER RRESE SRA RRERES
SABAARRAAAARAAAAAASARAARRAR
Figure 2: Precipitation trend in the combined NMM region between 1901 and 2015
. st In Mizoram, owing to the hilly topography and soil characteristics, the groundwater retention
. capacity is poor. Ground water potential is classified between poor to moderate in 72% of the
” area of the state (Refer to
Table 4).° Thus, the above average precipitation in the region does not correspond to a high
level of ground water availability. The state has a significantly high (4,500 MW) hydro power
potential. However, only 2% of the potential has been tapped. Consequently, water storage
(through reservoirs) capacity in the state is low. Thus, owing to inter and intra annual variation
- temporal and spatial — in precipitation (which would be exacerbated by human induced
climate change), low ground water retention and low surface water retention, it is imperative
for the state to prepare for changes in the water availability.
Table 1; Potential zone for ground water in five districts of Mizoram*
SK eDI strict Pies si essicee ie Aout Tl i DEVORE Re a AR
Potential Aizawl i Champhai ~ 4) Kolasib Mamit i Serchhip.
: 8
| Good __ | $93.65 | 754.36 07.61 [611.96 | 255.59
: . | Moderate {7,005.20 [933.53 457.26 [983.92 | 459.54 |
| Poor __| 1,808.42 4,172.33 s4.e2 [4,144.95 | 565.60 |
Demand side assessment
* IORA Analysis based on IMD Area weighted monthly, seasonal and annual rainfall (in mm) for 36 meteorological subdivisions
from 1901-2015. Accessed from https://data.aov in/resources/area-weighted-monthly-seasonal-and-annual-rainfall-mim-36-
Jreteoroloaical-subdivisions-1904 on 08.09.2018
Data provided by Water Resources Department. Data for five districts was made available. Once, data for the remaining districts
gre provided, it would be incorporated into the background note.
Data provided by Water Resources Department. Data for five districts was made available, Once, data for the remaining districts
are provided, it would be incorporated into the background note.

<!-- page 4 -->

Ex-637/2020 oA
The population of Mizoram has increased by 5.5 times between 1951 and 2011.5 There has
been significant migration from rural to urban regions, with an estimated 52% population
residing in urban regions (as per Census 2011). Per capita water demand in urban areas is
2.375 times higher than that in rural areas (135 Ipcd in urban areas).° Domestic water demand
has increased from 3.23 BCM in 1951 to 35.64 BCM in 2011 with the urban water demand
accounting for 85% of the rise.
Mizoram has mild climate which is suitable for cultivation of crops throughout the year.
However, due to scarcity of water during dry period crops cannot be grown throughout the
year. In many parts of the State, rice can be grown two times in a year but due to scarcity of
water during winter season, rice is grown only during Kharif season in many potential areas.
Similarly, terraces constructed in many places leading to permanent cultivation in jhum area,
cannot be cultivated during dry season because of limited water storage facilities.
Further it is noted that area under paddy has declined in the State by 32% from 54,541 ha to
36,858 ha between 2007-08 and 2016-17, though it remains as the major crop grown in
Mizoram. 32% of the area under agricultural/horticultural crops in 2016-17 were under
Banana, Mizo Chilli and Orange. Figure 3 provides a snapshot of area under different
crops in the state over the last decade.’ Area under Jhum cultivation has declined by 24%
over the last decade owing to numerous policies of the Government of Mizoram.
200° °2~2*~C~C~C~C~*S oo 60,000
15,000
2 40,000
= [| a a =
= 20,000 J oe < tm A MC a =
soo | Fao | SS
Pa tea ee a a
9 | beehecterest een inlasbemet esata aaa Fi
& » Co ny Rg Pa ? s s
SF FS KK MK MK KK SK
Paddy (on secondary axis) semen Maize ——— Pulses
~~ Oilseeds meme Sugarcane mmm Potato
meme Orange Banana —Grape
Cabbage —— Passion Fruit —Tomato
~~ Birdeye Chilly ~~~ Chow Chow Turmeric
Figure 3: Overview of area under various crops grown in Mizoram between 2007-08
and 2016-17
SCensus of India - 2011, Provisional Population Totals, Mizoram. Accessed from
http://censusindia.gov.in/201 1-prov-results/data_files/mizoram/Provisional_Population Mizoram.pdf on
10.09.2018 |
® Accessed from http://indiaenvironmentportal.org in/files/\WVa! w20consumption%20patterns.pdf on
16.11.2018 and
Accessed from http://megphed.gov.in/standards/quideural pdf on 16.11.2018
Statistical Abstract of Mizoram: 2017, Directc:ate of Economics and Statistics, Government of
Mizoram

<!-- page 5 -->

. -5- Ex-637/2020
9,000 “5,000
8,000 40,000
7,000 Rj 35,000
6,000 30,000 __|
3 Sy No 3
“5,000 iS Meal fa] ee 25,000
= Pass |) =
$4,000 a "Sa el 20,000 g
£3,000 | SEE ma 15,000 *
zm i in: Sess: —
1,000 I 2 S700)
0 0
S 2 ” wy ~” Ba 9 se i?
Nd 9) Ss “di “Vv OF oe a “J NV
i i 0 SO SO
Mizoram om Aizawl nee Champhai me Kolasiby — Lawngtlal
ee Lunglei <= Mamit —saiha ——Serchhip
Figure 4: District-wise area under Jhum cultivation in Mizoram
:
As reflected in figure 4, area under Jhum cultivation in the State has decreased as well due to
intensive efforts of the Government to avoid deforestation and hence drying up of water
sources. However, area under cultivation of rice in flat land (WRC) increases by 42.25% from
2010 to 2017 in the State.
The Government of Mizoram has promoted livestock in Mizoram as a measure of improving
: livelihood quality in terms of income and nutrition in rural areas. Rearing of animals provides a
substantial supplementary income to rural households. The total number of livestock in
Mizoram has increased by 20% between 1977 and 2012. Figure 5 provides an overview of
the growth of various types of livestock in the period between 1977 and 2012.
3,00,000 14,00,000
2,50,000 od aaa 12,00,000
2,00,000 [7] 10,00,000
138800 ae 8,00,000
a 6,00,000
1,00,000 a t
soscnt semen eel 4,00,000
50,000 ee] , Laisa 2,00,000
a 1977 1982 1987 1992 1997 2002 2007 2012
(Poultry (on secondary axis) mm Cattle ome Buffalo
ome Goat wom Pigs mee Horses and Ponies
som Sheep
Figure 5: Overview of number of livestock in Mizoram between 1977 and 2012
Mizoram remains a major importer of electricity with 645.73 MU imported in 2016-17. Only
7.4% of the total electricity consumed is generated within the state. Thermal and diesel power
production (which are traditionally large consumers of water) in the state has been zero since
FY 2015-16. While there are no energy intensive industries in Mizoram currently, with

<!-- page 6 -->

Ex-637/2020 -6-
enhanced connectivity at the domestic and international front (owing to its unique location with
an international boundary with two countries), there is a scope for expansion in this front. |
Need for State Water Policy
The above section highlights the changes in various competing water consumption sectors in
the state. With the ever growing population, greater developmental aspirations and enhanced
connectivity the growth of these sectors can be exponential in the future. Owing to the same, it
is imperative for the Government of Mizoram to put in place a well-defined State Water Policy
that encompasses various issues related to the management of water resources. The water
policy must be in-line with the National Water Policy, 2012. The policy must be under the
aegis of the concept of integrated water resource development. This would ensure an
egalitarian approach towards management and distribution of water resources. Further, there
is a need to prioritize the distribution of water to various competing uses in time of water
scarcity. THe state water policy must also outline the need for capacity development of all j
stakeholders for awareness, understanding and management of issues related to water
management. Finally, it should lay the basis for providing a sound institutional framework for
proper implementation of the policy.

<!-- page 7 -->

-7- Ex-637/2020

1. Preamble

1.1. Water is fundamental to life, livelihood, food security and sustainable development. India
has more than 18 % of the world’s population, but has only 4% of world’s renewable water
resources and 2.4% of world’s land area. There are further limits on utilizable quantities of
water owing to uneven distribution over time and space. In addition, there are challenges of
frequent floods and droughts in one or the other part of the country. With a growing
population and rising needs of a fast developing nation as well as the given indications of
the impact of climate change, availability of utilizable water will be under further strain in
future with the possibility of deepening water conflicts among different user groups. Low
consciousness about the scarcity of water and its life sustaining and economic value results
in its mismanagement, wastage, and inefficient use, as also pollution and reduction of flows
below minimum ecological needs. In addition, there are inequities in distribution and lack of
a unified perspective in planning, management and use of water resources.

1.2 The state of Mizoram covers an area of 21,081 sq. km, which is 0.68% of the total area of
the country. The state is covered by two river basins (as per CWC river basin
classification), namely the Barak and others (39% of the state) and the minor rivers flowing 4
into Myanmar and Bangladesh (61% of the state).'The highly variable inter annual rainfall ‘
leads to droughts and floods in the State frequently. Floods greatly impact the low lying flat
lands leading to continuous submergence of areas under rice, washing away wet rice
cultivated (WRC) lands, and damaging irrigation canals amongst others. In 2017, rainfall of
the order of 2803.7 mm, much higher than average annual rainfall destroyed many parts of

. the wet rice cultivation area in the State.

1.3. The objective of the Mizoram State Water Policy, 2020 is to take cognizance of the existing
situation in Mizoram, to propose a framework for creation of a system of laws and
institutions and for a plan of action with a unified perspective.

2. Overview of Water Resources of the State

2.1 Rainfall
Mizoram receives high rainfall with the average rainfall being above 2,000 mm."Majority of

» the precipitation occurs between the months of May and September. The heavy rains
during the monsoons, coupled with the hilly topography of the state leads to high surface
runoff. There is a high inter-annual variability in the precipitation, and the precipitation
presents a declining trend."

2.2 Surface Water
The predominant sources of water in Mizoram are surface water in rivers, streams, ponds
and natural springs and sub-surface water occurring as ground water. Mizoram has two
main river basins within its administrative boundary, namely, Barak and others and minor
rivers flowing into Bangladesh and Myanmar.”

The catchment area of Barak and other Basin in the state is 8,866 sq. km, which is 39% of
the total geographical area of the state. The minor rivers flowing into Bangladesh and
Myanmar covers the remaining 61% of the state."

There are two major types of rivers in Mizoram according to their direction of flow; rivers
which flow in North direction namely, Langkaih, Teirei, Tut, Tlawng, Lau, Meidum,
Tuichhuahen, Chemlui,Serlui, Turial, Tuirini, Tuivawl, Tuivai and Tuisa; and rivers flowing in
Southern direction namely, Khawthlangtuipui, Tuichawng, Mar, De, Kau, Phairuang,
Chhimtuipui, Ngengpui, Palak, Mat, Ngengrual, Vanva, Tuichang, Tuipui and Tiau.

<!-- page 8 -->

Ex-637/2020 -8-

2.3 Ground water
Geologically the State is covered by rocks of semi-consolidated lower tertiary formations
ranging in age from Oligocene to Miocene age. Being a majorly hilly state, the ground water
potential in more than half the area within the districts are classified as poor to
moderate.’The ground water infrastructure development in the state is still at a nascent
stage.”

3. Principles of the Water Policy

3.1 The ownership of water resides with the State as publicly owned resource with entitlement
for individuals, communities and service providers to use water without owning it.

3.2 As water is a common heritage, having economic value, the responsibility for its regulated
use and conservation is vested with the State.

3.3 Public policies on water resources need to be governed by certain basic principles, so that
there is some commonality in approaches in dealing with planning, development and
management of water resources.

3.4 The basic principles for the Mizoram State Water Policy, 2020 is to plan, develop and
manage water resources keeping in view the need to be governed by a common integrated
perspective considering local, regional, State and national context.

3.5 The planning and management of the resource is to be done on an environmentally sound

% basis whereby the human, social and economic needs are met as well.

3.6 Principle of equity and social justice must inform use and allocation of water.

3.7 Governance of the resources to be done through transparent informed decision making
meeting the objectives of equity, social justice and sustainability. Meaningful intensive
participation, transparency and accountability should guide decision making and regulation
of water resources,

3.8 The basic units of planning for conservation and management of water are micro
watersheds of the larger river basins in the State, ensuring a resource based approach.

3.9 Water needs to be managed efficiently as a common pool community resource held, by the
state, under public trust doctrine to achieve food security, support livelihood, and ensure
equitable and sustainable development for all.

3.10 Water is essential for sustenance of eco-system, and therefore, minimum ecological needs
(Ecological Flows) should be given due consideration.

3.11 Safe Water for drinking and sanitation needs to be considered a pre-emptive need,
followed by high priority allocation for other basic domestic needs (including needs of
animals), achieving food security, supporting sustenance agriculture and minimum eco-
system needs. Water available after meeting the above needs should be conserved.

3.12 All the elements of the water cycle, i.e., evapotranspiration, precipitation, runoff, river,
lakes, soil moisture, and ground water, sea, etc., are interdependent and the basic
hydrological unit is the river basin, which should be considered as the basic hydrological *
unit for planning.

3.13 Water quality and quantity are interlinked and need to be managed in an integrated
manner, consistent with broader environmental management approaches inter-alia
including the use of economic incentives and penalties to reduce pollution and wastage.

<!-- page 9 -->

-9- Ex-637/2020
. 4 Uses of Water

4.1 Water is required for a number of functions such as domestic, agricultural, hydro-power,
industry, thermal power, navigation and recreation among others. Utilization of all these
diverse uses of water is competitive in nature and need to be prioritized and optimized.

4.2 The Government of Mizoram and the local bodies (governance institutions) must ensure
access to a minimum quantity of potable water for essential health and hygiene to all its
citizens, available within easy reach of their households.

4.3. Ecological needs of the river should be determined, through scientific study, and should
accommodate developmental needs. A portion of river flows should be kept aside to meet
ecological needs ensuring that the low and high flow releases are proportional to the
natural flow regime, including base flow contribution in the low flow season through
regulated ground water use.

4.4 Community should be sensitized and encouraged to adapt first to utilization of water as per
local availability of waters, before providing water through long distance transfer,
Community based water management should be institutionalized and strengthened.

4.5 Inthe planning and operation of systems, priorities of water allocation need to be decided.
It should be broadly be as follows —

4.5.1 Drinking Water & Sanitation
4.5.2 Minimum Environmental and Ecologicalneeds ~
4.5.3 Agriculture & Allied purposes
4.5.4 Industries & Commercial
. 4.5.5 Hydropower

5 Adaptation to Climate Change

5.1 Climate Change impacts coupled with developmental pressure has its negative effect on
the fragile Mountain Ecosystem of Mizoram.

5.2 Rainfall in Mizoram indicates a declining trend.“\Climate change is likely to increase the
variability of water resources further affecting human health and livelihoods. Therefore,
special impetus should be given towards mitigation at micro level by enhancing the
capabilities of community to adopt climate resilient technological options.

5.3 Given the limits on enhancing the availability of utilizable water resources and increased
variability in supplies due to climate change, meeting the future needs will depend more on
demand management, and hence, this needs to be given priority. Efficient use of water in
agriculture system and other uses and avoiding wastages should be the core principles
guiding management of the scarce resource.

5.4 The anticipated variability in availability of water because of climate change should be dealt

: with by incorporating appropriate water storage in various forms, namely, soil moisture,
ponds, ground water, small and large reservoirs and their combination. The state should be
incentivized to increase water storage capacity, which inter-alia should include revival of
traditional water harvesting structures and water bodies.

5.5 The trends in water availability due to various factors including climate change must be
assessed and accounted for during water resources planning.

5.6 The adaptation strategies could also include better demand management, particularly,
through adoption of compatible agricultural strategies and cropping patterns and improved
water application methods, such as land leveling and/or drip/sprinkler irrigation as they
enhance the water use efficiency.

<!-- page 10 -->

Ex-637/2020 -10-

5.7. All programmes dealing with water augmentation need to integrate climate change
adaptation needs.

5.8 Planning and management of water resources structures, such as, dams, flood
embankments, afforestation, etc., should incorporate appropriate infrastructure designs to
accommodate the anticipated changes in climate. The acceptability criteria in regard to new
water resources projects needs to be re-worked in view of the likely climate changes.

6 Enhancing Water Available for Use (Supply-side Enhancement)

6.1 The availability of water resources and its use by various sectors in the river basins within
the State need to be assessed scientifically, reviewed at 5 year intervals. The review
process should be fully participatory involving local communities.

6.2 While the availability of water is limited, the demand of water is ever-increasing rapidly due
to growing population. Further, urbanization, industrialization and increased economic
development in the coming years would further lead to increased water demand. Therefore,
availability of water for utilization needs to be augmented to meet increasing demands of . .
water.

6.3 Conservation of forests to ensure perennial water availability needs to be mainstreamed.
There is a need to map the spring sheds within the forest areas in the State and maintain
the same.

6.4 Aquifers need to be mapped to know the quantum and quality of replenishable as well as
non-replenishable ground water resource in the state. It should be ensured that only
replenishable water is extracted from ground water.

6.5 Integrated Watershed development activities with water conservation perspectives need to
be taken in a comprehensive manner to increase soil moisture, reduce sediment yield and
increase overall land and water productivity. To the extent possible, existing programs like
MGNREGA may be used by farmers to harvest water.

6.6 Declining ground water levels need to be arrested by introducing improved technologies of
water use, incentivizing efficient water use and encouraging community based
management of aquifers. The suitable and appropriate technologies on artificial recharging
projects should be undertaken so that extraction is less than the recharge. This would allow
the aquifers to provide base flows to the surface system, and maintain ecology.

6.7 Inter-basin water transfers, if feasible, may be considered after evaluating the
environmental, economic and social impacts of such transfers. If feasible, it will not only
help in increasing production but also for meeting basic human needs and achieving equity
and social justice. Inter-basin transfers of water should be considered on the basis of merits
of each case

6.8 To avoid wastage of water, enhance conservation, and ensure availability, water should
increasingly be subjected to allocation and pricing on economic principles across its various
users.

6.9 A Water Regulatory Authority (WRA) should be established in Mizoram. The authority,
inter-alia, will fix and regulate the water tariff system and charges, in general, according to
the principles stated in this Policy in an autonomous manner. Such tariff will be periodically
reviewed.

6.10 In order to meet equity, efficiency and economic principles, the water charges should

. preferably as a rule be determined on volumetric basis.

6.11 Recycle and reuse of water, after treatmert to specified standards, should also be

incentivized through a properly plann<d tariff system. Water Users Associations
