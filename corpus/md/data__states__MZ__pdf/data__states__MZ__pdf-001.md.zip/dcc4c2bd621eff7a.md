---
doc_id: "dcc4c2bd621eff7a"
source_url: "https://ahvety.mizoram.gov.in/uploads/attachments/8a579a858782f1d3027a07629b43a9c6/the-gazette-of-india-prevention-and-control-2009.pdf"
ministry: "Animal Husbandry and Veterinary Department, Mizoram"
title: "The Gazette of India (Prevention and Control, 2009)"
date: ""
pages: 15
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "f680f1a7093f0544"
---

<!-- page 1 -->

aE He Be WET) 04/0007/2003—09 REGISTERED NO. DL~-(N)04/0007/2003—09 “
a
ia 7 TSA
- FATT
EXTRAORDINARY
wT T— ae 1
PART II — Section 1
irae 8 wettira
PUBLISHED BY AUTHORITY
We 29] , ag feet, amar, arf 20, 2009 129 HAP, 1930
No. 29] NEW DELHI, FRIDAY, MARCH 20, 2009 / 29 Phalguna, 1930
FT eR Ts ter a ett fred fee ae stem Hee SBT aT TT TS |
Separate paging is given to this Part in order that it may be filed as a separate compilation.
MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Dethi, the 20th March, 2009/Phalguna 29, 1930 (Saka)

The following Act of Parliament received the assent of the President on the

20th March, 2009, and is hereby published for general information:—
THE PREVENTION AND CONTROL OF INFECTIOUS AND
CONTAGIOUS DISEASES IN ANIMALS ACT, 2009
No. 27 oF 2009

° [20th March, 2009]
AnActto provide for the prevention, control and eradication of infectious and
contagious diseases affecting animals, for prevention of outbreak or spreading
of such diseases from one State to another, and to meet the international
obligations of India for facilitating import and export of animals and animal

products and for matters connected therewith or incidental thereto.

Wuereas economic losses due to infectious and contagious diseases of animals are
enormous in the country with some of these diseases constituting a serious threat to the public;

AND WHEREAS many of such animal diseases can be largely prevented by judicious
implementation of vaccination programmes or by taking other appropriate and timely measures
on scientific lines;

AND WHEREAS such measures are necessary to facilitate the import and export of
animals and animal products and to keep in tune with international practices;

AND WHEREAS it has been realised that the prevention, control and eradication of
infectious and contagious diseases of animals from India has to be tackled on a national
basis so as to avoid adverse impact of such diseases on the economy of the country and for
this purpose harmonise the control procedures and to prevent inter-State transmission of
animal diseases;

Ann wursas the national level handling has to be done with the active involvement
of the State Governments, particularly in regard to the precautionary measures required to

3
3
2

<!-- page 2 -->

2 THE GAZEITE OF INDIA EXTRAORDINARY [Part II—
eel
be takem within their jurisdiction in respect of certain infectious and contagious diseases
and the regulation of movement of animals outside their respective areas by timely adoption
of appropriate measures;
Apo wHEREAS India is a Member Country of the Office International Des Epizooties,
Paris and it is necessary to implement the general obligations, decisions and
recommendations of the said Organisation and abide by the International Animal Health
Code stipulated by the said Organisation;
Be it enacted by Parliament in the Sixtieth Year of the Republic of India as follows: — -
CHAPTER I
PRELIMINARY
Short title, 1..(/) This Act may be called the Prevention and Control of Infectious and Contagious °
extent and Diseases in Animals Bill, 2009.
mene (2) It shall come into force on such date as the Central Govemment may, by notification,
: appoint; and different dates may be appointed for different States or for different areas
therein ds well as for different provisions of this Act, and any reference in any such provision
of this Act to the commencement of this Act shall be construed in relation to any State or
area Or provision as a reference to the coming into force of this Act or, as the case may be, of
that provision, in such State or area.
Definitions. 2.. In this Act, unless the context otherwise requires, —~
(a) “animal” means.—
(i) cattle, buffalo, sheep, goat, yak, mithun;
i (ii) dog, cat, pig, horse, camel, ass, mule, poultry, bees; and
. (iii) any other animal or bird as the Central Government may, by
notification, specify;
(8) “Check Post” means any piace established as such by the Director to carry
out checking of animals for the purpose of this Act;
(c) “Competent Officer” means any person or officer of the Government notified
asa Competent Officer under section 17;
(& “compulsory vaccination” means vaccination of any animal against any
scheduled disease in respect of which vaccination is made mandatory under the
provisions of this Act;
(e) “controlled area” means any local area which has been declared as such by :
thé State Government under sub-section (/) of section 6;
(f) “defective vaccine” means any vaccine which is expired, breach in seal,
contaminated, improperly stored, unlabelled or with mutilated label;
(g) “Director”, in relation to a State, means any officer in charge of the Department
of Animal Husbandry or Veterinary Services, or both, notified by the State Government
as:such for the purpose of this Act;
(A) “free area” means any controlled area which has been declared as such
under sub-section (5) of section 6:
(8 “infected animal” means an animal which is infected with any scheduled disease;
() “infected area” means an area declared as such under section 20;
(4) “notification” means notification published in the Official Gazette; ”
() “prescribed” means prescribed by rules made under this Act,
(m) “publication” includes propagation of information through the media or
newspaper or any other mass media and the means of focal communication such as ~
detlaration in loud voice and by beating drums in the area;
(x) “Quarantine Camp” means any place declared to carry out quarantine of
an{mals and birds for the purpose of this Act;
(0) “scheduled disease” means any disease included in the Schedule;
(p) “Veterinarian” means a person having a recognised veterinary qualification
who, under the law for the time being in force, is allowed to treat animal diseases:
(q) “Veterinary Officer” means any officer, appointed as such by the State
Government under clause (4) of section 3;
(r) “Village Officer”, in relation to a village, means any person who is authorised
or designated as such in accordance with the qualifications prescribed by the State
Gavemment,
ss

<!-- page 3 -->

Sec. 1] THE GAZETTE OF INDIA EXTRAORDINARY 3
CHAPTER II
CONTROL OF SCHEDULED DISEASES
3. The State Government may, by notification, appoint Appointment
(a) such number of persons, as it deems proper, to be Veterinarians to undertake of Veterinary
inspection and specifying the local limits of their respective jurisdiction; and Officers
(8) such number of Veterinarians, as it deems proper, to be Veterinary Officers,

who shall exercise their powers and discharge their duties within the local limits of their

jurisdiction as may be specified in the said notification.

4, (1) Every owner, or any other person, non-governmental organisation, public bodies Reporting
or the village panchayat, in charge of any animal which he or it has reason to believe to be — scheduled
infective of a scheduled disease shall report the fact to the Village Officer or village panchayat diseases
in-charge, who may report the same in writing to the nearest available Veterinarian. obligatory.

(2) The Village Officer shall visit the area falling within his jurisdiction for reporting any
outbreak of the disease.

(3) Every Veterinarian shall, on receipt of a report under sub-section (/), or otherwise,
if he has reason to believe that any animal is infected with a scheduled disease, report the
Matter to the Veterinary Officer.

(4) Where in any State there is any occurrence of scheduled disease in relation to any
animal, the Director shall send an intimation to the Directors of the States which are in the

. immediate neighbourhood of the place where there is such occurrence, for taking appropriate
preventive measures against the spread of the disease.

§, (/) Every owner or person in charge of an animal, which he has reason to believe is Duty to
infective of a scheduled disease, shall segregate such animal and have it kept ina place away segregate
from all other animals which are healthy, and take all possible steps to prevent the infected infected
animal from coming in contact with any other animal. animals.

(2) The owner or other person in charge of, or having control over, the animal referred
to in sub-section (/) shall confine that animal and prevent it from grazing in a common place
or to drink water from any common source including a vessel, pond, lake or river.

(3) All other infected animals shall be segregated by the Municipality, Panchayat or
other local administration.

6. (/) The State Government may, with the object of preventing, controlling or Notification

~ eradicating any scheduled disease, by notification, declare any area tobe acontrolled area in of controlled
respect of any scheduled disease affecting any species of animal and any other species that reas and free
may be susceptible to the disease specified in the said notification. areas.

(2) The State Government shall also cause the substance of the notification issued
under sub-section (7) to be published in a local newspaper in the vernacular language and
by declaration in loud voice and by beating drums in the area.

(3) Where a notification has been issued under sub-section (/), all animals of the
species in the controlled area shall be subjected to compulsory vaccination against that
disease, and be subjected to such other measures against the disease, in such manner and
within such time as the State Government, may, by public notice, direct.

(4) The State Government shall make available necessary vaccine and it shall be
obligatory on the part of every owner, or the person in charge of an animal which is required
to be vaccinated under sub-section (3), to get the animal compulsorily vaccinated.

(5) Where the State Government is satisfied, on a report received from the Director or
otherwise, that, in any controlled area, any of the scheduled diseases affecting any species
of animal is no longer prevalent, it may, by notification, declare the area to be a free area in

7 respect of that disease in relation to the particular species of animal.

(6) Where a notification has been issued under sub-section (5), no animal of the species
orofany other susceptible species with regard to which it isa free area shall be allowed to enter
the free area unless duly immunized by vaccination against that particular disease.

7.(/) Where a notification has been issued under sub-section (/) of section 6 declaring Prohibition of
any area as a controlled area in relation to any disease affecting any species of animals, no movement of
animal belonging to that species shall be moved from the place where it is kept. animals from

(2) The Director may, for the purpose of control, prevention or eradication of any nea °
scheduled disease, in respect of any area, by order published in the Official Gazette, prohibit
the movement of all animals belonging to any species specified therein, from the place where
it is kept, to any other place.

<!-- page 4 -->

4 THE GAZETTE OF INDIA EXTRAORDINARY [Paat Il—

(3) Nothing contained in sub-sections (/) and (2) shall be deemed to prohibit—

(a) the movement of any animal referred to therein, from the place where it is kept,
to the nearest place where it can be got vaccinated, so long as the animal is being
imoved for the purpose of its immunization by vaccination; or
: (6) the movement of any such animal, so long as it is accompanied by a valid
jcertificate of vaccination to indicate that the animal is duly immunized against the
iparticular disease and it bears proper mark of such vaccination. .

Vaccination, '8. (7) The vaccine to an animal may be administered by any person competent under the
marking and jaw fof the time being in force to administer it, and issue acertificate of administration of vaccination. ~
issue of :
vaccination (2) Where any animal has been vaccinated for any scheduled disease in compliance
certificate, with the provisions of sub-section (/), the person vaccinating the animal shall cause to put
amark by branding, tattooing or ear tagging, or in such other manner as the Director may, by
general or special order, direct and the same shall, unless otherwise specified by the Director,
shall hot be removed.

(3) The authority issuing a certificate of vaccination shall specify the date of vaccination,
dates of manufacture and expiry of the vaccine and the date up to which the vaccination of
the animal with the particular vaccine shall be valid.

Contents of 9, Every vaccination certificate issued under this Act shall be in such form and shall

vaccination —_ ontain such particulars as may be prescribed by the Central Government.

certificate.

Entry and :10, (7) Where any area has been declared as a controlled area under sub-section (/) of

exit of section 6 in respect of any disease affecting any species of animals, no animal belonging to

animals into that species shall be taken out of, or brought into that area save as provided in section 16.

area and free (2) The Director may, by notice duly published in the Official Gazette and at least in one

area daily local newspaper in vernacular language, extend the prohibition contained in sub-section
(2) to.any other species of animals, if animals belonging to that species are also likely to be
infected with that disease.

(3) No carrier of goods or animal shall carry any animal from or out of a controlled area,
free atea or infected area by land, sea or air unless he complies with the provisions of section 16.

(4) Nothing contained in sub-sections (/) to (3) shall apply to the carriage by railway
of any animal referred to in those sub-sections through any area which, for the time being, is
declared as a controlled area or infected area so long as the animal is not unloaded (for
whatspever purpose or duration) in any place within that area:

Provided that the State Government may, by notification, declare that any species of
animal so carried through any lccal area within the State shall be duly immunized against
such $cheduled disease, in such manner and within such time as may be specified in that
notifi¢ation and a certificate of vaccination shall be a pre-requisite for the transportation of
the arlimals by the railways through that area: .

Provided further that, where any notification as referred to in the first proviso has been
issued, it shall be incumbent on the State Government to intimate that fact to the concerned -
railw4y authorities so as to enable them to satisfy themselves about the immunization of the
animal before transporting it through the local area of the State.

Precautionary ‘Tk. No person shall take out of the controlled area—

measures in

relation to (a) any animal, alive or dead, which is infected with, or reasonably suspected to

coutrolled have been infected with, any scheduled disease notified under sub-section (/) of section 6,

areas.

seas (6) any kind of fodder, bedding or other material which has come into contact

with any animal infected with such disease or could, in any manner, carry the infection
of the notified disease, or

(c) the carcass, skin or any other part or product of such animal.

<!-- page 5 -->

'
Sec. 1] THE GAZETTE OF INDIA EXTRAORDINARY 5

12. No person, organisation or institution shall hold any animal market, animal fair, Prohibition
animal exhibition and carry on any other activity which involves grouping or gathering of of markets,
any species of animals within a controlled area: exhibition,

Provided that the Competent Officer may, so motu or on application made to him in eee oe
this behalf, relax the prohibition in relation to any species of animals, in acase where animals areas.
belonging to that species are not susceptible to the scheduled disease and are incapable of
carrying it, ifhe is satisfied that in the public interest it is necessary to accord such relaxation.

13. No person shall bring or attempt to bring into market, fair, exhibition or other Prohibition
congregation of animals or to any public place, any animal which is known to be infected of brnging of

- . : infect
with a scheduled disease. animals into
market and
other places.

14. () The Director may establish as many Quarantine Camps and Check Posts within Check Posts

the State as may be required and Quaran-
: tine Camps.
(a) for the detention of animals suffering from any scheduled disease or of
animals which have come into contact with or have been kept in the proximity of any
such infected animal;
(5) for ensuring the prevention of entry into or exit from any controlled area or

infected area or free area, of any animal belonging to the species of animals in respect

of which a notification, issued under sub-section (/) of section 6, or an order issued

under sub-section (2) of section 7, is in force.

(2) Any animal which is required to be detained, inspected, vaccinated, or marked, may
be kept in the Quarantine Camp for such period as the Competent Officer may direct.

(3) Every animal detained at a Quarantine Camp shall be under the custody of the
person in charge of the camp, and shall be vaccinated and marked.

. (4) The officer in charge of the Quarantine Camp shall, at the time of release of an
animal from the station, grant a permit, in such form as may be prescribed by the State
Government, to the person taking charge of the animal, and every such person shall be
bound to produce the permit whenever required to do so by any Competent Officer.

15. (7) Every person in charge of any Check Post or Quarantine Camp shall inspect any inspection
animal stopped at the Check Post, or detained therein or at the Quarantine Camp. we stention

0

(2) The manner of inspection and the period of detention of the animal at the Check — Check Posts
Post or at the Quarantine Camp for the purpose of inspection or for the administration of and oa
compulsory vaccination, the marking of animals and the form and manner in which permit for
entry in respect of any animal may be issued, shall be such as may be prescribed by the State
Govemment.

16, Notwithstanding anything contained in section 10, an animal belonging to the Entry and
species of animals in respect of which an area has been declared as a controlled or free area ext te ed
in relation to any scheduled disease, which has been duly vaccinated against that disease, animals into
shall be allowed to enter into or be taken out of the controlled area or free area, orto be taken controlled and
out of any other place on the production ofa certificate to the effect that vaccine against that free areas.
disease has been administered and a period of not less than twenty-one days has elapsed
thereafter.

17. The State Government may, for the proper implementation of the provisions of this Appointment

. Act, by notification, authorise any person to exercise any power or discharge any duty as a oe eomee
Pa Competent Officer, under this Act, who shall exercise such powers and such duties within :
3 the local limits of his jurisdiction as may be specifted in the notification.

<!-- page 6 -->

6 THE GAZETTE OF INDIA EXTRAORDINARY {Part II—

ne eee sw eam ae

Nd
Cleaning and J8. (/) Every common carrier whether a vessel or vehicle shall be cleaned and disinfected
disinfection immedlately before and after the transportation of any animal in that vessel or vehicle, and so
of cartier, also any other place where the animal has been kept in transit.

(2) Where any area has been declared as a controlled area or free area in respect of any
scheduled disease affecting any species of animal, the Director may, by an order duly published
in the Official Gazette and in a local newspaper in the vernacular language, direct the owner
of every vehicle in Which any animal belonging to that species is carried, to have the vehicle
properly cleaned and disinfected.

Powers of 19. Any Veterinary Officer or other Competent Officer may enter upon and inspect any
entry and land or! building or place, vessel or vehicle, for the purpose of ensuring compliance of the -
inspection. provisions of this Act or the rules or orders made thereunder, by the persons responsible for
such campliance.
CHAPTER fl
: INFECTED AREAS
Declaration of 20. ifthe Veterinary Officer, upon receipt ofa report from a Veterinarian or otherwise, is
infected areas. satisfiel that, in any place or premises falling within his jurisdiction, an animal has been
infected with any scheduled disease, or that an animal, which he has reason to believe has
been solinfected, is kept, may, by notification and publication in at least one local newspaper
in the vernacular language and by declaration in loud voice and by beating drums, declare
such ara as he may deem fit (including the place or premises aforesaid) to be an infected
area.
Effect of 24, (7) Where an area has been declared as an infected area under section 20, all
declaration of provisions of this Act which are applicable in relation to a controlled area shall musatis
infected areas. paandis apply thereto as if for the words “controlled area”, the words “infected area” have
been substituted.

(2) Without prejudice to the generality of the provisions contained in sub-section (1),
the following further provisions shall apply in relation to an infected area, namely:—

(a) in respect of every animal in that area which is infected or reasonably believed
td be infected, with any scheduled disease, the owner or other person in charge of the
ahimal, shall forthwith get it treated by a Veterinarian;

(4) all articles, which are likely to have come into contact with any animal referred
ta in clause (a), shall be treated or disposed off in such a manner as the Veterinarian
may direct;

(c) every Veterinarian shall, for the purpose of inspection, have the power to
enter any place or premises where any animal is kept or is likely to be kept:

(d) the owner or any other person in charge of the animal referred to in clause
(a) shall keep the animal in isolation forthwith, and also take such other measures as
may be necessary for the prevention, treatment and control of the disease as the
Veterinarian may direct,

Denotification 2}. Ifthe Veterinary Officer, after such enquiry as he may deem fit, is satisfied that there .
of infected isno longer the threat ar danger of any animal being infected with the scheduled disease in
area. any infected area, by notification and publication in a locai newspaper in vernacular language,

declare that the area is no longer an infected area as aforesaid, whereupon all the restrictions >

referred to in section 21 shall cease to apply.

‘ CHAPTERIV
INFECTED ANIMALS

Segregation, 23. (1) Where the Veterinarian has, on receipt of a report or otherwise, reason to
examination believe that any animal is infected with a scheduled disease, he may, by order in writing,
and wreatrent direct the owner or any other person in charge of such animal—
animals. (a) to keep it segregated from other apparently healthy animals: or

(4) to subject it to such treatment as may be required under the circumstances.

eh  waettecee bobo. ve mm cS

<!-- page 7 -->

Sec. }] JHE GAZETTE OF {NDIA EXTRAORDINARY 7

(2) Where any action has been taken in pursuance of sub-section (/), the Veterinarian
shall forthwith give a detailed report of the incidence of the disease to the Veterinary Officer.

(3) On receipt of a report from the Veterinarian, the Veterinary Officer shall, as soon as
possible, examine that animal as well as any other animal which could have come in contact
with it, and for that purpose, submit the animal to such test and medical examination as may
be required under the circumstances.

(4) lf, after such test and examination, the Veterinary Officer is of the opinion that an
animal is not infected with any of the scheduled diseases, he shall issue a certificate in
writing that the animal is not infected with any such disease.

24, (1) Where the Veterinary Officer considers it necessary for the purpose of Drawing
ascertaining whether the animal which is suspected to have been infected with any scheduled #mples from
disease or susceptible to such infection is actually infected, or for the purpose of ascertaining animals. :
the nature of the scheduled disease with which an animal is infected, he may draw such
samples, as may be required, from the animal for the purpose of carrying out such
investigations as he may deem necessary under the circumstances.

(2) The Veterinary Officer or any other Competent Officer shall draw samples from any .
animal for the purposes of ascertaining whether the animal has been vaccinated against any
disease, or whether the vaccination of the animal has been effective in conferring it immunity
and have the samples examined, in such manner as he may deem necessary.

25. If the Veterinary Officer deems it necessary that an animal, which is infected with Resort to
a scheduled disease, euthanasia has to be resorted to, for preventing the spread of the cuthanasia
disease to other animals in the area ot to protect public health if the disease is of zoonotic £2" infected
, i + was . animals.
importance, he may, notwithstanding anything contained in any other law for the time being
in force, by an order in writing, direct euthanasia of the animal and the carcass disposed of
immediately to his satisfaction.

26. Every person in possession of carcass (or any part thereof) of any animal, which, Disposal of
at the time of its death, was infected with any scheduled disease or was suspected to have — #"04SS.

a been infected, shall dispose it of in such manner as may be prescribed.

27, (1) Where the Veterinary Officer or any Veterinarian has reason to believe thatthe — Powers of
death of an animal has been caused by an infection of any scheduled disease, he may make one
or cause to be made a post-mortem examination of the animal and for that purpose he may Gaecrinarian
cause the carcass of any such animal to be exhumed where required followed by proper 19 hold posi-
disposal after necessary examination and post-mortem. mortem

examination

(2) Every examination and post-mortem referred to in sub-section (7) shall be conducted
in such manner, and the report of post-mortem shall be in such form, as may be prescribed.

28. Where any animal which is infected or suspected to have been infected is found Seizure and
without any person claiming to be its owner, or where a valid order or direction given in removal of
relation to any such animal is not promptly complied with by the owner or other person in seimals.
control of the animal, it shal! be open to the Veterinary Officer or any other Competent Officer,
to seize the animal and remove it to a place of isolation or segregation, as he may deem
proper.

CHAPTER V
ENFORCEMENT AND PENALTIES
29. (1) Where by any rule, notification, notice, requisition, order or direction made — Enforcement .
under this Act, any person is required to take any measure or to do anything— towers and
r
(a) in respect of any animal, carcass of any animal or other thing in his custody — expenses.
or charge, the same shal! be promptly complied with by that person;
(6) in case of any stray or ownerless animal, carcass of such animal or parts
thereof, the same shal] be promptly complied with by the municipality or Panchayat, as
the case may be, at its cost.

<!-- page 8 -->

8 THE GAZETTE OF INDIA EXTRAORDINARY [Part II—
i
(2) If the mzasures as referred to in sub-section (/) are not taken within such time as
may We allowed for the purpose, the authority issuing the notice, requisition, order or direction,
may ¢ause the measures to be taken at the cost of the person or municipality or Panchayat, .
as thd case may be, who or which was required to take the measures.
(3) The costs of any measures taken under sub-section (2), shal! be recoverable from
the person or the municipality or Panchayat, as the case may be, concerned in the manner
proviled by the Code of Criminal Procedure, 1973, for the recovery of fines imposed by a2 of 1974. .
Court, as if such costs were a fine imposed by a Court.
Village 30. Al! Municipal, Panchayat or Village Officers and all officers of the rural and dairy
Officers, etc. development, revenue, agriculture, animal husbandry and veterinary departments of the .
to assist.
State Government, shall be bound—
! (a) to give immediate information to the Veterinary Officer and to the Veterinarian
‘having jurisdiction in the area regarding the prevalence of a scheduled disease amongst
‘any animal or species of animals, in the area;
(4) to take all necessary measures to prevent the outbreak or spread of any
scheduled disease; and
: (c) to assist the Veterinary Officer and the Veterinarian in the discharge of their
‘duties or in the exercise of their powers under this Act.
Penaity for 31. If any person issues a vaccination certificate
issuing '
vaccination (a) without authority or competence in that behalf, or
tificat . wpe ar
without, . : (6) after administering the vaccine which is known to be defective in any
authority or ‘manner,
administerin; i . . , .
defective She shall be guilty of an offence punishable with a fine of five thousand rupees or in case of
vaccine. non-gdayment of fine with imprisonment which may extend to one month, and in the case of
any sibsequent offence, with fine of ten thousand rupees or with imprisonment which may
extend to three months.
Penalties. 32, Any person who contravenes the provisions of this Act or obstructs the Competent °
Officer in performing his duties shall be guilty of an offence punishable with fine which may
exten to one thousand rupees, and in case of failure to pay the penalty with imprisonment
for aiterm which may extend to one month; and in the case of any subsequent offence
(whether under the same provision or any other provision of this Act except in case of
sectigns 3] and 33) with a fine of two thousand rupees, or with imprisonment for a term
which may extend to two months in case of non-payment of the penalty.
Fenalty for ‘33. Whoever places or causes or permits to be placed in any river, lake, canal or any
rateored otherjwater body, the carcass or any part of the carcass of any animal which at the time of its
animal or death) was known to be infected, shall be guilty of an offence and, on conviction, be punished,
carcass in in thd case of a first offence with fine of two thousand rupees or with imprisonment of one
river, etc. : : gs . .
month in case of non-payment of fine and in the case of subsequent conviction witha fine of
five thousand rupees or imprisonment for a term which may extend to three months or with
both. .
Offences by 34, (/) Where an offence under this Act has been committed by a company, every
panies. person who at the time the offence was committed was in charge of, and was responsible to,
the company for the conduct of the business of the company, as well as the company, shall
be ddemed to be guilty of the offence and shall be liable to be proceeded and punished
accordingly:
Provided that nothing contained in this sub-section shall render such person tiable to
any punishment provided in this Act, if he proves that the offence was committed without
his knowledge or that he had exercised all due diligence to prevent the commission of such
offence.
“ye PMU BR Foca OBE ORO cated amy ss cagggemgmgmmgy agin ty souk) e csth ausmmme te pene ve

<!-- page 9 -->

Sec. 1] THE GAZETTE OF INDIA EXTRAORDINARY 9

(2) Notwithstanding anything contained in sub-section (7), where an offence under
this Act has been committed by a company and it is proved that the offence has been
committed with the consent or connivance of, or is attributable to any neglect on the part of,
any director, manager, secretary or other officer of the company, such director, manager,
secretary or other officer shall also be deemed to be guilty of that offence and shall be liable
to be proceeded against and punished accordingly.

Explanation—For the purposes of this section—

(a) “company” means any body corporate and includes a co-operative society
registered or deemed to be registered under any law for the time being in force, a firm
or other association of individuals; and

(6) “director”, in relation to a firm, means a partner in the firm.

CHAPTER VI
PRECAUTIONARY MEASURES ON CAUSATIVE ORGANISM, ETC.

35. (/) In every institution, laboratory or clinic, engaged in the manufacture, testing or Prevention
research, related to vaccines; sera, diagnostics or chemotherapeutic drugs and aimed at the of escape of
Prevention or treatment of any scheduled disease, adequate precautionary measures shall °¥Sative
be taken— organism.

(a) to ensure that the causative organism of any scheduled disease does not
escape or otherwise get released; .

(6) to guard against any such escape or release: and

(c) to warn and to protect everyone concerned in the event of any escape.

(2) Notwithstanding anything contained in any other law for the time being in force,
every animal—

(a) used for the manufacture, testing or research as referred to sub-section (7), or

(4) which is likely to carry or transmit any scheduled disease,

shall be promptly administered euthanasia and disposed of by the person in charge of or
os having contro! of the institution, laboratory or clinic, as the case may be, referred to in that
sub-section. .

(3) Every person who is in charge of or having control of an institution, laboratory or
clinic referred to in sub-section (7) comply with the provisions of sub-section (/) and sub-
section (2); and in the event of non-compliance he shall be guilty of an offence punishable
with fine which may extend to twenty thousand rupees or imprisonment for a term which may
extend to six months or with both, and in case the establishment is in commercial manufacturing
of vaccines or medicine, a temporary suspension of licence up to a period of one year may
also be imposed.

CHAPTER VIL
MISCELLANEOUS

36. The State Government may, by notification, delegate to any officer or authority Power to
subordinate to it, all or any of the powers conferred on it by or under this Act, except the ‘legate.
powers to make rules under sub-section (2) of section 42.

37. All officers and authorities under this Act shall exercise their powers and discharge Officers and
their duties conferred or imposed on them by or under this Act, in accordance with such authorities fo
orders, not inconsistent with the provisions of this Act, as the Centrat Government or the subject to
State Government may, from time to time, make. Government

control

38. (/) The Central Government may, by notification, add to, or omit from the Schedule Power 10
any animal disease and the said disease shall, as from the date of the notification, be deemed amend ihe
to have been added to, or omitted from, the Schedule.

(2) Every notification issued under sub-section (/) shall, as soon as may be after it is
issued, be laid before each House of Parliament.

<!-- page 10 -->

10 THE GAZETTE OF INDIA EXTRAORDINARY {Parr —
Power to issue 39. The Central Government may, with the object of prevention, control and eradication
directions. of any infectious or contagious disease of animals, issue such directions to the State
Government or other authorities under this Act, from time to time, including directions for
furnishing such returns and statistics on scheduled diseases, and vaccination, as it may
deein fit and every such direction shall be complied with.
Certain _ 40. Every Competent Officer, Director and Veterinary Officer, while exercising any
persons to be ~— power or performing any duty under this Act, shall be deemed to be a public servant within .
public the meaning of section 21 of the Indian Penal Code. 45 of 1860.
servants.
Power to 41. (/) If any difficulty arises in giving effect to the provisions of this Act, the Central
diffoutt Government may, by order published in the Official Gazette, make such provisions, not .
neues incdnsistent with the provisions of this Act, as appear to it to be necessary or expedient for
rembving the difficulty:
Provided that ne such order shall be made after the expiry ofa period of two years from
the date of commencement of this Act.
i (2) Every order made under this section shall, as soon as may be after it is made, be laid
befdre each House of Parliament
Power of 42. (1) The Central Government may, subject to the condition of previous publication,
Central by notification, make rules for carrying out the provisions of this Act.
Government i
to make ales (2) In particular and without prejudice to the generality of the foregoing power, such :
tuleg may provide for all or any of the following matters, namely:—
{a) the form of vaccination certificate and the particulars which such certificate
: shall contain, under section 9;
(8) the manner of disposal of carcass, under section 26;
(c) the manner of conducting examination and post-mortem under sub-section
(7) and the form of report of post-mortem under sub-section (2) of section 27;
(@) any other matter which may be prescribed or in respect of which rules are
required to be made by the Central Government.
Power of 43. (1) The State Government may, by notification and with the prior approval of the
State Central Government, make rules for carrying out the purposes of this Act.
Government
to make ' (2) In particular and without prejudice to the generality of the foregoing power, such
rules, rules may provide for all or any of the following matters, namely:—
(a) the form of permit to be granted by the officer in charge of a Quarantine
Camp, under sub-section (4) of section 14;
{&) the manner of inspection and the period of detention ofan animal at a Check
Post or at a Quarantine Camp for the administration of compulsory vaccination and
marking of animals and the form and manner of issue of entry permit, under sub-
section (2) of section 15;
(c) any other matter in respect of which rule is to be or may be made by the State .
Government.
Laying of 44. (/) Every rule made by the Central Government under this Act shall be laid, as soon .
rules, as niay be after it is made, before each House of Parliament, while it is in session, for a total
peribd of thirty days which may be comprised in one session or in two or more successive
sessions, and if, before the expiry of the session immediately following the session or the
sucdessive sessions aforesaid, both Houses agree in making any modification in the rule or
both Houses agree that the rule should not be made, the rule shall thereafter have effect only
in such modified form or be of no effect, as the case may be; so, however, that any such
modification or annulment shall be without prejudice to the validity of anything previously
done under that rule.
(2) Every rule made by the State Government under this Act shall be laid, as soon as
may be after it is made, before the State Legislature.
ch howmonte mes bbe pm Se
