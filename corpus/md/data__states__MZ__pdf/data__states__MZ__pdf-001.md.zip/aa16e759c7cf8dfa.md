---
doc_id: "aa16e759c7cf8dfa"
source_url: "https://excise.mizoram.gov.in/uploads/attachments/2026/06/049587459d2ef4185e2b2ffb039e10c0/posts-783-promotion-order-of-lalremsiama-ien-and-pu-lalrinnunga-ien-to-asst-commissioner.pdf"
ministry: "Excise and Narcotic Department, Mizoram"
title: "Promotion order of Lalremsiama IEN and Pu Lalrinnunga IEN to Asst Commissioner"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1f5407b55f94aabc"
---

<!-- page 1 -->

GOVERNMENT OF M]ZORAM

EXCISE & NARCOTICS DEPAR"ENT
MIZORAM SECRETARIAT, MINEC0 BUILDING-2, BASEMENT-II

N a I IF I C A T I 0 N
Aizawl, the 2Irh May, 2026.

NOA-32013/110/2025-E&N-Part(1):

On the recommendation of the Mizoram

Public
Service
Commission
vide
their
letter
No.A.32013/29/2024-MPSC[P)
dt.22.05.2026 and in the interest of public service, the Governor of Mizoram is pleased

to promote the following Inspector of Excise & Narcotics to the post of Assistant
Commissioner of Excise & Narcotics in Level 10 of the Pay Matrix plus all other
allowances as admissible from time to time:
Sl.

New place of posting on
promotion

Remarks

0/o Asst. Commissioner of

With immediate
effect

Name`&Presentplaceofposting

No.

1.

C. Lalremsiama,
0/o Asst. Commissioner of

E&N, Kolasib District.

E&N, Aizawl District.

Lalrimunga,
2.

Commissionerate of E&N

Commissionerate of E&N

rAnti -Narcotic Squad|

(Anti -Narcotic Squad)

W.e.f.
01.06.2026

Consequent upon the above promotion and in the interest of public
service, the Governor of Mizoram is further pleased to order transfer and posting of the
following Assistant Commissioner of Excise & Narcotics with immediate effect and until
further orders:

•.,;:`r!

Sl.No.

1.

Name & Present place of posting

T.C. Lalropuia,
0/a Asst. Commissioner of E&N, Siaha
District.

Lalrengpuia,
2.

3.

Commissionerate of E&N
rAnti -Narcotic Sciuad|
R.V. Bohia,
O/o Asst. Commissioner of E&N,
Lawngtlai District.

/ f' I i
..a . (.: , --1 d
Comni.;s`\
!.,

,iJlul

I,-

Newplaceofposting
0/o Asst. Commissioner ofE&N,
Serchhip District.
O/o Asst. Commissioner of E&N,
Lawngtlai District.

O/o Asst. Commissioner of E&N,
Siaha District.

Sd/- C. IALRUAIA
Secretary to the Govt. of Mizoram,
Excise & Narcotics Department.

<!-- page 2 -->

Memo NOA-32013/110/2025-E&N-Part(1)

:

Aizawl, the 29th May, 2026

Copy to
1. P.S. to Minister, Excise & Narcotics Department.
2. Sr. P.P.S. to chiefsecretary, Government of Mizoram.
3. All Administrative Heads, Go\.ernment of Mizoram.
4. All Heads of Department, Government ofMizoram.
5. Chief controller of Accounts, Accounts & Treasuries, Mizoram.
6r' Commissioner
of Excise
Narcotics,Department
Mizoram. with 6(six) spare copies for
' 7.
Controller, Printing
&&
Stationery

publicatio`n in the Mizoram Gazette.
8. Treasury officer, Aizawl/Kolasib/Serchhip/Lawngtlai/Siaha.
9. Personal files of the officer concerned.
10. Officers concerned.
11. Guard File.
Dig.itally signed by

Zohmingthangi Fanai

Date: 29-05-2026
17:36:40.

(ZOHMINGTHANGI FANAD
Under Secretary to the Govt. of Mizoram
Excise & Narcotics Department
