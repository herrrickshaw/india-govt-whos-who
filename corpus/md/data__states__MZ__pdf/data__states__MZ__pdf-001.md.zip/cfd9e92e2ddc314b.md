---
doc_id: "cfd9e92e2ddc314b"
source_url: "https://landj.mizoram.gov.in/uploads/attachments/f85b64611c95edd8d980ce4172c7dca7/notification_5_599a76d734f21.pdf"
ministry: "Law and Judicial Department, Mizoram"
title: "notification_5_599a76d734f21.pdf"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9c0902d97f3f91ae"
---

<!-- page 1 -->

GOVERNMENT OF MIZORAM
I,AW AND JIIDICIAL DEPARTMENT

NOTIFICATION
Dated Aizawlrthe 18th Augustr 2017

z

No. A. 450lll1l20l5-LJCll46
In exercise of the power conferred under Section 84
of the Rights of Persons With Disabilities Act,2016 (No. 49 of 2016), and with approval of
Hon'ble the Chief Justice of Gauhati High Court vide NolP.l70l3ll0l20l7-Hc (ABy9 dt.
7.8.2017, the Governor of Mizoram is pleased to designate the following Courts as Special
Co urts to try offences
ollences under the said
sard Act with
wrth rmmedrate
immediate effect
ettect as shown below:
sl.
NAME OF COURT
TERRITORIAL JURISDICTION
No.
2no Court of Addl. District & Sessions Judge,
Whole of Aizawl, Serchhip and Mamit
I
Aizawl
Admin istrative Districts
')
Addl. District & Sessions Judge, Lunglei
Whole of Lunglei Administrative District
J

Addl. District & Sessions Judge, Champhai

Whole of Champhai Administrative District

4

Fast Track Court, Saiha

Whole of Siaha and Lawngtlai
Administrative Districts

5

Fast Track Court, Kolasib

Whole of Kolasib Administrative District

Sd/- MARLI VANKUNG
Secretary to the Govt. of Mizoram
Law & Judicial Department
Memo No. A. 450lll1l20l5-LJcll46 z
Dated Aizawl, the 18th August,2017
Copy to: Secretary to the Governor of Mizoram.
2. P.S. to SpeakerlDeputy Speaker, Mizoram.
3. P.S. to Ministers/Ministers of State/Parliamentary Secretaries, Mizoram.
4. P.P.S. to Chief Secretary, Govt. of Mizoram.
5. All Administrative Departments/All Head of Departments, Govt. of Mizoram.
6. Registrar General, Gauhati High Court, Guwahati.
7. Registrar, Gauhati High Court, Aizawl Bench with reference to his letter No.
P. 1 701 3/l 0 12017 -HC (ABy9 dt. 7 .8.2017 .
8. District & Sessions Judge, Aizawlllunglei.
9. Judge, Fast Track Court, Kolasib/Siaha.
10. Addl. District & Sessions Judge, Champhai.
11. Controller, Printing & Stationery with 6 (six) spare copies for publication in the
Mizoram Gazette with a request to send 5 (five) gazette copy to this
Department.
12. Web Manager, Law & Judicial Deptt. for uploading in the Department's
website.
13. Guard File.

l.

(R. LALMUANKIMI)
Govt' of Mizoram

u*3ff::Y

::.'n'
