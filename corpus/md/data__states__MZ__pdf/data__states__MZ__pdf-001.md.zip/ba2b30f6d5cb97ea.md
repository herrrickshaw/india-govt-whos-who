---
doc_id: "ba2b30f6d5cb97ea"
source_url: "https://ganc.mizoram.gov.in/uploads/attachments/b101f8245feb0e296af6fe7754b22b8f/online-fee-payment-instructions-ganc.pdf"
ministry: "Government Aizawl North College, Mizoram"
title: "Online Fee Payment Instruction and Direct Link"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ba35901152d81ecb"
---

<!-- page 1 -->

GOVT. AIZAWL NORTH COLLEGE
ONLINE EXAMINATION FEE PEK DAN
INSTRUCTIONS

Date : 3rd May, 2021

Hrileng vangin Even Semester 2021 Exam Fee chu Online-a pek a ngai ta a, a hnuaia tarlan te hi uluk
takin chhiar la Fee hi 8th May, 2021 ral hma ngeiin i pe dawn nia. Online-a fee pe tur hian internet banking
nei bank account emaw UPI (Gpay, BHIM, Paytm etc) a\angin a pek theih ang. Hetiang hi tihdan tur a ni :
1.

State Bank Collect tih website ah luh tur
OR he link hi click rawh : https://www.onlinesbi.com/sbicollect/icollecthome.htm

2.

He phek hnuaia lama - ‘I have read and accepted the terms and conditions stated above’
tih inziaka Box hi click la, Proceed tih click leh rawh.

3.

State of Corporate / Institution ----Select State---...tih ah hian scroll thla la Mizoram tih thlang rawh
Type of Corporate / Institution ----Select Type--tih ah hian Educational Institutions tih thlang la, Go tih click rawh

4.

Educational Institution Name
----Select Educational Institutions--- tihah khan a hmasa bera awm AIZAWL NORTH COLLEGE tih
click la, Submit tih click rawh.

<!-- page 2 -->

5.

Select Category click la, ONLINE FEE tih click leh rawh..

6.

Enter full University Roll number tihah hian I roll number pumpui kha fimkhur takin type lut la, Submit
tih click leh rawh. Eg. 2005BA987, 1905BA874, 1805BA784

7.

Submit i click veleh hengte hi a lo lang ang :
I full Roll number, Name, Registration number, Father’s name, Gender, Date of birth,
Subject Combination & Fee i pek tur zat
A chunga lang hi a dik vek chuan Remarks Box ah hian engmah type a ngai lovang
A chunga lang zingah hian diklo palh a awm chuan a hnuaia Remarks box chhungah hian
a dik zawk uluk takin i type dawn nia.

8.

Heng a hnuaia mite hi pawisa pekna receipt dawn letna atan fill up tur a ni :
Name
I hming pum
Date of birth
Piani/thla/kum (Calendar lem a\angin thlan tur, kum thlang hmasa ang che)
Mobile number
Nangma phone number
Email id
Email nei tan...neih loh chuan fill-up loh mai tur
Enter Text as shown in the image - Box chhunga inziak ang chiaha chhut luh a Submit hmeh tur

9.

A chunga i thil chhut luh te ennawna nemnghet (confirm) turin a rawn ti che ang a, a dik thlap chuan
Confirm tih click la, Online payment tihna tur option hrang hrang a rawn lang nghal ang, chung zinga
hman lar leh awlsam deuhte chu hengte hi an ni :

<!-- page 3 -->

i)

Net Banking : State Bank of India a internet banking nei tan heta \ang hian payment a tih theih

ii)

State Bank ATM - cum Debit card : ATM card hmangin a pek theih a, RuPay card (MRB leh
bank dang) hmangin a pek theih bawk.

iii)

UPI (Gpay, BHIM, Paytm etc) a pekna : A hnuaia mi ang hi i click chuan Gpay, BHIM, Paytm
etc in payment a tih theih...

I click zawhah hei hi a lo lang ang a, VPA tih hi thlang la Virtual Payment Address ah hian Gpay
etc i address kha hetiang hian type lut rawh

I submit zawh hian Gpay etc ah lut la, notification (minute 5 chhung awh) a lo awm ang a, payment
a tih nghal theih ang.
Note :
Multi Option Payment system tih hnuaia Other Banks Internet Banking tiha Bank dang account
a\angin a pek theih bawk.
A chunga tarlan Online Banking account nei lo chuan chhungte/\hiante/\henawm etc SBI bank account
hmang pawhin a pek theih a, a pawisa lo inrulh mai tur a ni.
Fee i pek hi college-in a dawn leh dawn a hriat zung zung theih loh a, i pekna account-ah a in cut
leh cut loh a petu lamin lo infiah mai tur a ni e.
Remember :
Last date of payment of fees : 8th May, 2021
