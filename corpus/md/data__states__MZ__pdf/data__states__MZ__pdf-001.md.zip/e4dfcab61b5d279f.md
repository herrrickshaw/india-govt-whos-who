---
doc_id: "e4dfcab61b5d279f"
source_url: "https://forest.mizoram.gov.in/uploads/attachments/2024/02/1c4e24f41aae65bd499e227da263bf49/the-forest-conservation-amendment-act-2023.pdf"
ministry: "Environment, Forests & Climate Change Department, Mizoram"
title: "The Forest (Conservation) Amendment Act 2023"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "64a382d9cbce3a18"
---

<!-- page 1 -->

jftLVªh lañ Mhñ ,yñ—(,u)04@0007@2003—23

REGISTERED NO. DL—(N)04/0007/2003—23

सी.जी.-डी.एल.-अ.-05082023-247866
xxxGIDHxxx
CG-DL-E-05082023-247866

xxxGIDExxx
vlk/kkj.k

EXTRAORDINARY
Hkkx II — [k.M 1
PART II — Section 1

izkf/kdkj ls izdkf'kr
PUBLISHED BY AUTHORITY
lañ 18]

ubZ fnYyh] 'kqØ okj] vxLr 4] 2023@ Jko.k 13] 1945 ¼'kd½

No. 18]

NEW DELHI, FRIDAY, AUGUST 4, 2023/SRAVANA 13, 1945 (SAKA)

bl Hkkx esa fHkUu i`"B la[;k nh tkrh gS ftlls fd ;g vyx ladyu ds :i esa j[kk tk ldsA
Separate paging is given to this Part in order that it may be filed as a separate compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 4th August, 2023/Sravana 13, 1945 (Saka)
The following Act of Parliament received the assent of the President on the
4th August, 2023 and is hereby published for general information:—

THE FOREST (CONSERVATION) AMENDMENT ACT, 2023
(NO. 15 OF 2023)
[4th August, 2023]

An Act further to amend the Forest (Conservation) Act, 1980.
BE it enacted by Parliament in the Seventy-fourth Year of the Republic of India as
follows:—
1. (1) This Act may be called the Forest (Conservation) Amendment Act, 2023.

Short title and
commencement.

(2) It shall come into force on such date as the Central Government may, by notification
in the Official Gazette, appoint.
69 of 1980.

2. In the Forest (Conservation) Act, 1980 (hereinafter referred to as the principal Act),
after the long title and before the enacting formula, the following preamble shall be inserted,
namely:—
"WHEREAS, the importance of forests is to be realised to enable achievement of
national targets of Net Zero Emission by 2070 and maintain or enhance the forest
carbon stocks through ecologically balanced sustainable development;

Insertion of
preamble.

<!-- page 2 -->

2

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

AND WHEREAS, Nationality Determined Contribution targets of the country
envisage creating carbon sink of additional 2.5 to 3.0 billion tons of CO2 equivalent
by 2030;
AND WHEREAS, the country envisages an increase in the forest and tree cover to
one-third of its land area, which is to be given impetus with an enhanced growth
trajectory;
AND WHEREAS, India has a rich tradition of preserving forests and their
bio-diversity, and, therefore, enhancing forest based economic, social and
environmental benefits, including improvement of livelihoods for forest dependent
communities is envisaged;
AND WHEREAS, it is necessary to provide for provisions relating to conservation
management and restoration of forests, maintaining ecological security, sustaining
cultural and traditional values of forests and facilitating economic needs and carbon
neutrality.".
Amendment
of section 1.

3. In section 1 of the principal Act, in sub-section (1), for the words and brackets
"Forest (Conservation) Act", the words and brackets "Van (Sanrakshan Evam Samvardhan)
Adhiniyam" shall be substituted.

Insertion of
new section 1A.

4. After section 1 of the principal Act, the following section shall be inserted,
namely:—

Act to cover
certain land.

‘1A. (1) The following land shall be covered under the provisions of this Act,
namely:—
(a) the land that has been declared or notified as a forest in accordance
with the provisions of the Indian Forest Act, 1927 or under any other law for the
time being in force;
(b) the land that is not covered under clause (a), but has been recorded in
Government record as forest, as on or after the 25th October, 1980:
Provided that the provisions of this clause shall not apply to such land, which
has been changed from forest use to use for non-forest purpose on or before the
12th December, 1996 in pursuance of an order, issued by any authority authorised by
a State Government or an Union territory Administration in that behalf.
Explanation.—For the purposes of this sub-section, the expression
"Government record" means record held by Revenue Department or Forest Department
of the State Government or Union territory Administration, or any authority, local
body, community or council recognised by the State Government or Union territory
Administration.
(2) The following categories of land shall not be covered under the provisions
of this Act, namely:—
(a) such forest land situated alongside a rail line or a public road maintained
by the Government, which provides access to a habitation, or to a rail, and
roadside amenity up to a maximum size of 0.10 hectare in each case;
(b) such tree, tree plantation or reafforestation raised on lands that are
not specified in clause (a) or clause (b) of sub-section (1); and
(c) such forest land,—
(i) as is situated within a distance of one hundred kilometres along
international borders or Line of Control or Line of Actual Control, as the

16 of 1927.

<!-- page 3 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

3

case may be, proposed to be used for construction of strategic linear
project of national importance and concerning national security; or
(ii) up to ten hectares, proposed to be used for construction of
security related infrastructure; or
(iii) as is proposed to be used for construction of defence related
project or a camp for paramilitary forces or public utility projects, as may
be specified by the Central Government, the extent of which does not
exceed five hectares in a Left Wing Extremism affected area as may be
notified by the Central Government.
(3) The exemption provided under sub-section (2) shall be subject to such
terms and conditions, including the conditions of planting trees to compensate felling
of trees undertaken on the lands, as the Central Government may, by guidelines,
specify.’.
5. In the principal Act, section 2 shall be renumbered as sub-section (1) thereof
and—
(a) in sub-section (1) as so renumbered,—
(I) in clause (iii), for the words "not owned, managed or controlled by
Government", the words ", subject to such terms and conditions, as the Central
Government may, by order, specify" shall be substituted;
(II) in the Explanation, for the long line occurring after clause (b), the
following shall be substituted, namely:—
"but does not include any work relating to or ancillary to
conservation, development and management of forests and wildlife, such
as—
(i) silvicultural operations including regeneration operations;
(ii) establishment of check-posts and infrastructure for the
front line forest staff;
(iii) establishment and maintenance of fire lines;
(iv) wireless communications;
(v) construction of fencing, boundary marks or pillars, bridges
and culverts, check dams, waterholes, trenches and pipelines;
53 of 1972.

(vi) establishment of zoo and safaris referred to in the Wild
Life (Protection) Act, 1972, owned by the Government or any
authority, in forest areas other than protected areas;
(vii) eco-tourism facilities included in the Forest Working
Plan or Wildlife Management Plan or Tiger Conservation Plan or
Working Scheme of that area; and
(viii) any other like purposes, which the Central Government
may, by order, specify.";
(b) after sub-section (1) as so renumbered, the following sub-section shall be
inserted, namely:—
"(2) The Central Government may, by order, specify the terms and
conditions subject to which any survey, such as, reconnaissance, prospecting,
investigation or exploration including seismic survey, shall not be treated as
non-forest purpose.".

Amendment
of section 2.

<!-- page 4 -->

4

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II — SEC. 1]

6. In the principal Act, after section 3B, the following section shall be inserted,
Insertion of
new section 3C. namely:—
Power of
Central
Government
to issue
directions.

"3C. The Central Government may, from time to time, issue such directions, to
any authority under the Central Government, State Government or Union territory
Administration, or to any organisation, entity or body recognised by the Central
Government, State Government or Union territory Administration, as may be necessary
for the implementation of this Act.".

————

DR. REETA VASISHTA,
Secretary to the Govt. of India.

UPLOADED BY THE MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI–110002
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI–110054.
MGIPMRND—236GI(S3)—04-08-2023.

Kshitiz
Mohan

Digitally signed by
Kshitiz Mohan
Date: 2023.08.05
02:45:20 +05'30'
