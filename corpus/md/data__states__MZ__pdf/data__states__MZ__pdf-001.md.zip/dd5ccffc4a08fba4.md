---
doc_id: "dd5ccffc4a08fba4"
source_url: "https://health.mizoram.gov.in/uploads/attachments/2022/01/c90b5d6f8dc02440c9a9a48a60c58b64/mizoram-drugs-policy.pdf"
ministry: "Health and Family Welfare Department, Mizoram"
title: "Mizoram Drugs Policy"
date: ""
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a7604932d546b05f"
---

<!-- page 1 -->

Mizoram State Essential Generic Drug Policy

INTRODUCTION:
Health is a constitutional right of every citizen of India. It is the basic need of individuals irrespective of caste or creed, rich or poor. Health is in the concurrent list and is the
purview of the centre and the state. The Government of Mizoram, through the Department
of Health and Family Welfare takes several initiatives to improve the health of its people by
implementing various central schemes like National Health Mission (NHM), Revised National Tuberculosis Control Programme (RNTCP), Integrated Diseases Surveillance
Programme (IDSP), National Vector Borne Diseases Control Programme (NVBDCP), National
Iodine Deficiency Control Programme (NIDDCP), National Leprosy Eradication Programme
(NLEP), National Programme for Control of Blindness (NPCB), School Health Programme,
etc.
However, the success of all the above programmes whether it is a Central Scheme or
a State Programme fully depends on the availability of safe, efficacious and quality drugs at
an affordable price with strict adherence to Rational use of medicines and rational
approach to therapeutics.
Realizing the importance of health care, the State Government has been providing
the necessary policy frame work, institutions and resources in the shape of finances, personnel, drugs and equipment for the delivery of public health care services in the State.
Over the years, there has been a remarkable expansion of health institutions in the Government sector. A large number of personnels have been and are being recruited. Priority
has been given to development of health infrastructure. Considerable volume of equipment is being procured annually. Free medicines are being provided as per availability of
the budget. There has been a considerable expansion of the referral transport system. At
present, there is availability of a variety of specialized and super specialty services in various disciplines within the State. The result of this has been that the health indicators in the
State have improved.
The single most vital component of health care is drugs as they account for substantial
part of household expenditure on health. The market for drugs has been growing rapidly in
terms of production, trade, investment, employment and consumption. However, the industry is characterized by various features like growth of irrational drug combinations and highly
priced branded drugs which wastes a lot of patients' money. The capacity of the Health Services to procure good quality drugs and ensure timely supply also has scope for improvement.
Irrational use of drugs leads to serious problems through adverse drug reactions,
drug resistance, increased morbidity and high cost. The Food & Drug Administration also
has constraints of capacity in ensuring the required quality standards of the drugs under
–1–

<!-- page 2 -->

Mizoram State Essential Generic Drug Policy

the provisions of law.
Although the intention of the Government is to promote equitable, affordable and
quality health care, there is a need to provide a clear guide for action. Keeping in view the
importance of drugs in the healthcare services, a specific state essential generic drug policy
in the State of Mizoram is required not only to reiterate the commitment of the Government to the goal of improved health care services but also to provide clear priorities and
strategies. The essential generic drug policy is envisaged to prioritize and express the goals
and identify the main strategies for achieving them.
OBJECTIVES:
The Government of Mizoram is committed to promote access to affordable essential medicines of high standard quality to the people of the State. This, in the broadest
sense, is the main objective of the essential generic drug policy. In more specific terms, the
policy objectives are the following:(i)

To promote accessibility of medicines. This would mean equitable availability and
affordability of essential medicines including traditional medicines.

(ii)

To ensure safety, quality and efficacy of medicines.

(iii)

To promote prescription of drugs in generic name at public and private sector.

(iv)

To promote good prescribing practices , dispensing practices and rational use of drugs
in the public and private sectors.

(v)

To provide cost effective, efficient procurement and supply management system for
drugs.

(vi)

Strengthening of Health programme to provide research on all aspects of drug use.

STRATEGIES:
Achieving the objectives of the essential generic drug policy requires adoption of
various strategies and policy measures which are explained in the following paragraphs:-

–2–

<!-- page 3 -->

Mizoram State Essential Generic Drug Policy

1.

SELECTION OF ESSENTIAL MEDICINES:
1.1

Importance of the concept:

The State Government in order to attain rational use of safe and efficacious drugs,
convened a meeting of several Stakeholders including Doctor, Specialists from in and outside the state to formulate the Mizoram State Essential Medicine List and the list presents
a list of minimum medicines needed for our state's basic health care systems listing the
most efficacious, safe and cost-effective medicines for priority conditions. They are selected
on the basis of current and estimated future public health relevance and potential safe and
cost effective treatment.
1.2

Selection process:

1.2.1 Selection of drugs is a crucial step in ensuring access to essential drugs and in
promoting rational use of drugs. Drug selection would be based on the well
accepted concepts and principles of essential drugs which have also been recommended by the World Health Organization. The Department of Health &
Family Welfare shall appoint an Expert Committee known as the State Drug
Consultative Committee which will comprise of the following members:1.
2.
3.
4.
5.
6.
7.
8.
9.
10.

Secretary, Health & Family Welfare
Principal Director, Health & Family Welfare
Director, Health Services
Director, Hospital & Medical Education
Head of Drug Control Administration
Joint Director (P), DHS
Joint Director (P), DHME
Medical Superintendent, Civil Hospital, Aizawl
HOD of every clinical discipline, Civil Hospital, Aizawl
HOD, Deptt of Pharmacy, RIPANS

-

Chairman
Co-Chairman
Vice Chairman
Vice Chairman
Member Secy.
Member
Member
Member
Member
Member

The Committee would be responsible for initially preparing and subsequent updation
of the essential drug list every two years for the public sector. A separate Drug Consultative
Committee with appropriate composition would be constituted in respect of drugs pertaining to Indian Systems of Medicine.
–3–

<!-- page 4 -->

Mizoram State Essential Generic Drug Policy

1.2.2 The selection of essential drugs will be based on the following criteria:
a)
b)
c)
d)
e)
f)
g)
h)
i)

Therapeutic need
Relevance to State morbidity and Mortality pattern
Safety, quality and efficacy
Cost effectiveness
Ease & safety in administration and dispensing
Usefulness in more than one condition
Likelihood of patient compliance
Training and experience of the prescribers
Treatment facilities in the State

1.2.3. The State Drug Consultative Committee would be guided by the following
principles while preparing the essential drug list:(i)

Only medicines with sound and adequate evidence of efficacy and safety in a
variety of settings should be selected.

(ii)

Relative cost effectiveness would be a major consideration for choosing medicines within the same therapeutic category. While comparing between medicines, not only the unit cost of medicines but the total cost of treatment
must also be kept in mind along with its efficacy.

(iii)

The drugs selected shall be identified and listed by their generic name or
International Non-proprietary Name (INN) only.

(iv)

In some cases the choice may be influenced by other factors such as pharmacokinetic properties or by local considerations such as the availability of facilities for storage, effects of local diseases , food habits on drug effectiveness
(e.g. malnutrition, liver diseases etc.), local differences in sensitivity and resistance of micro-organisms and differences in climate, topography and other

–4–

<!-- page 5 -->

Mizoram State Essential Generic Drug Policy

environmental factors.
(v)

Medicines selected must be available in a dosage form in which adequate
quality including bioavailability can be ensured. Its stability under the anticipated conditions of storage and use must be determined.

(vi)

Attempts shall be made to procure medicines in a single compound. Fixed
rational combinations shall be acceptable if one or more of the following criteria, supported by evidence ,are met:•

The clinical condition justifies the use of more than one drug;

•

The therapeutic effects of the combination are greater than the sum
of effects of each drug, i.e. the combination must be synergistic and
not simply additive;

•

The cost of combination product is less than the total cost of the individual products;

1.2.4 The State Essential Drug List will be subsequently categorized according to
the levels of health care facilities like primary, secondary and tertiary.
1.2.5 The State Essential Drug List will be revised after every three years so as to
reflect therapeutic advances and changes in cost, resistance pattern and public health relevance.
1.2.6 The Government recognizes that there are some drugs which though not listed
in the Essential Drug List are required for specific diseases/exceptional cases.
Keeping this in view, a supplementary drug list shall be drawn by the State
Drug Consultative Committee and procurement of drugs shall be earmarked
for purchase of the drugs in the supplementary drug list.

–5–

<!-- page 6 -->

Mizoram State Essential Generic Drug Policy

2.

QUANTIFICATION OF DRUGS:

Quantification of drugs shall be done cautiously with sense of responsibility and accountability based on reliable quantification methods taking into consideration consumption and morbidity pattern for different levels of facilities (Primary, Secondary and Tertiary
levels). The quantification shall be done taking into consideration the following parameters:
2.1 Parameters such as demand, lead time, transportation constraints and emergency needs. There should be a provision for buffer stock keeping in view the State specific
constraints particularly the accessibility to remote areas.
2.2 Appropriate inventory management software shall be developed, used and
revised whenever necessary to ensure accurate quantification.
3.

PROCUREMENT OF ESSENTIAL DRUGS:
3.1

All drugs shall be purchased by the Department of Health & Family Welfare
by consulting Principal Director and both Director of Health Services and Director of Hospital & Medical Education. However the distribution shall be
done by the Dy. Director, Central Medical Store, Zemabawk to different Hospital stores (warehouses) of the districts.

3.2

All the items shall be purchased by open tender through National Competitive Bidding.

3.3

Open tenders should be called only of drugs listed in Mizoram Essential Drugs
List.

3.4

After finalization of the tenders, an "Approved List" shall be drawn up containing
the names of the drugs, the names of the supplier and the cost of the drugs.

3.5

All drugs and medical consumables shall be purchased in generic names.

–6–

<!-- page 7 -->

Mizoram State Essential Generic Drug Policy

4.

3.6

All drugs and medical consumables and surgical and sutures items will be
purchased directly from the manufacturers or authorized distributors.

3.7

Essential drugs shall be procured to ensure cost effectiveness and
sustainability while conforming to the principles of transparency, accountability and efficiency.

3.8

Only drugs listed in the Essential Drug List shall be procured centrally. The
drugs included in the supplementary drug list would be procured out of the
earmarked provision in the budget not exceeding 10% of the allocated budget for drugs at the level of the respective Institutions or districts (in case of
PHCs and lower institutions).

3.9

The existing procurement mechanisms of drugs and supplies shall be improved
with a view to ensuring timely availability of quality drugs. Efforts shall be
made to make the detection of pilferages / wastages / expired stocks easier.
For this purpose, an appropriate Management Information System shall be
evolved and a web based e-procurement model be developed.

3.10 The objective is to put in place an effective system of procurement of essential drugs by generic names to ensure timely availability, good quality and
reasonable cost. The focus would be to minimize stock outs and expired stocks,
and ensure availability of essential drugs as per the actual requirement of the
health institutions.
INVENTORY AND DISTRIBUTION:
4.1
The stores shall be managed by appropriate skilled and qualified personnel
i,e. Pharmacist.
4.2
Management Information System for essential drugs will be put in place in
the Health Institutions in a phased manner to monitor the availability of
drugs.
4.3 In the management of warehouses/stores, the following principles shall
apply:a) The drugs procured shall be stored in appropriate storage conditions as recommended by the manufacturer since improper storage may
result in deterioration of drugs.

–7–

<!-- page 8 -->

Mizoram State Essential Generic Drug Policy

b)

There shall be a proper Inventory Control System to prevent excessive
stocking of individual items and also prevent stock outs. Loses due to
spoilage or expiry shall be minimized.

c)

Appropriate system for accounting shall be developed to attain the
objectives of controlling stocks and generate information on expenditure relating to consumption of drugs and medical supplies. This would
generate data to facilitate forecasting the quantification of drugs required in the future.

d)

Physical verification of stocks shall be undertaken regularly so as to
rotate stocks as also to weed out in time expired drugs. Such verification will minimize diversion of stocks and reduce theft and fraud.

e)

Uniform system and procedures for stock management would be laid
down in the public health facilities. Manuals and guidelines, specific to
the needs of the health institutions will be developed to enforce the
laid down system. Such manuals and guidelines shall be developed,
keeping in mind the capacity of user.

f)

The supply of drugs and equipment received under central
programmes in kind shall also be monitored centrally and streamlined.

4.4

Drugs shall be distributed under proper transportation conditions ensuring
safety and proper delivery. Distribution will be done in an appropriate and
timely manner to maintain availability throughout the State.

4.5

Steps shall be taken to ensure that the drugs by generic name are available to
the public.

4.6

Proper recall and disposal procedures shall be followed as per standard
guidelines.

–8–

<!-- page 9 -->

Mizoram State Essential Generic Drug Policy

5.

6.

FINANCING:
5.1

The Government will make appropriate allocations for procurement and
supply of drugs for all types of health institutions - Primary, Secondary &
Tertiary in Govt. Sector.

5.2

The Government will also explore alternate financing sources and develop
innovative means and mechanisms for the purpose of availability of drugs
listed in the essential drug list.

QUALITY ASSURANCE AND REGULATION:
6.1

The Food & Drugs Administration Wing, Department of Health & Family
Welfare, Mizoram will be responsible for implementing the legislation and
regulations on pharmaceuticals to ensure quality, safety, efficacy of drugs
and accuracy of product information. The said organization needs to be
strengthened through a capacity building process by augmenting infrastructure, manpower and financial resources. This would include upgrading the
competence of the human resources working in the organization through
training.

6.2

The Drug Testing Laboratory is very much needed for maintaining quality of
the drugs. Efforts should be made to have the Drug Testing Laboratory as per
national standard at the earliest.

6.3

Appropriate financial provision would be made available to cover cost of
quality assurance and drug testing.

6.4

Surveillance on the quality of drugs available in the market shall be kept by
collecting samples and taking further action according to law.

6.5

Appropriate drug information shall be provided and made available to the
health professionals as well as public/patients.

–9–

<!-- page 10 -->

Mizoram State Essential Generic Drug Policy

6.6

Steps shall be taken to ensure proper implementation of drug regulations
especially with regard to offences related to adulterated or spurious drugs.

6.7

The rules relating to cosmetics shall be enforced and laboratories notified for
testing purposes.

6.8

Sale, Storage, use of drugs and record keeping specified under Schedule X of
the Drugs and Cosmetics Act, 1940 shall be supervised and monitored effectively by the inspectorate working under Food & Drugs Administration Wing,
Mizoram. Special checking squads under the leadership of State Drug Controller will be constituted to undertake periodic inspections in this regard;

6.9

Schedule-H & H1 drugs shall be strictly dispensed on the prescription of
Registered Medical Practitioners.

6.10 The office of Drug Controller, Food & Drugs Administration, Mizoram shall be
computerized to provide better data base system. The computerization will
facilitate access of information to the public.
6.11 An Intelligence-cum-Legal Cell shall be established in the office of The Food
& Drugs Administration Wing, Mizoram to facilitate busting of spurious drug
rackets and their prompt prosecution.
6.12 Efforts shall be made to provide incentives to informers giving information
about spurious drugs.
6.13 Efforts shall be made to rationalize number of Drug licenses.

– 10 –

<!-- page 11 -->

Mizoram State Essential Generic Drug Policy

7.

DRUG ADVERTISEMENT AND PROMOTION:

In order to prevent risks of misuse and marketing of drugs by quacks, wherever required, laws would be made and strengthened. This would also help in regulating commercial advertisement and marketing of drugs. Any advertisement and promotion of drugs will
be required to provide complete drug information.
8.

RATIONAL USE OF DRUGS:
8.1

The Government shall promote rational use of drugs in the State so that
patients receive medicines appropriate for their clinical needs, in doses that
meet the individual requirements for an adequate period of time and at the
lowest cost.

8.2

In order to minimize wastage and ensure effective treatment, rational prescribing, dispensing and use of drugs by health professionals/health workers,
following strategies would be adopted:a)

In all the Hospitals of the State, Drugs and Therapeutic Committee
shall be established and made effectively functional. These Committee will be responsible for reviewing drug utilization and promoting
rational use of drugs. A State and District Level Drugs and Therapeutic
Advisory Committee shall also be constituted to monitor the
activities of the drugs and Therapeutic Committees of the hospital
which shall comprise of the following members:

– 11 –

<!-- page 12 -->

Mizoram State Essential Generic Drug Policy

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
1.
2.
3.
4.
5.
6.

State Level Drugs & Therapeutic Advisory Committee
Secretary to the Govt of Mizoram
Health & Family Welfare
- Chairman
Principal Director, Health & Family Welfare
- Sr. Vice Chairman
Joint. Secy/Deputy Secy to the Govt of Mizoram
Health & Family Welfare
- Member
Director, Health Services
- Vice Chairman
Director, Hospital & Medical Education
- Vice Chairman
Head of Drug Control Administration
- Member Secy.
Med. Supdt, Civil Hospital, Aizawl
- Member
HOD, Medicine, Civil Hospital, Aizawl
- Member
HOD, Surgery, Civil Hospital, Aizawl
- Member
HOD, Obstetrics & Gynaecology
Civil Hospital, Aizawl
- Member
HOD, Paediatrics, Civil Hospital,Aizawl
- Member
Joint Director, DHS (P)
- Member
Joint Director, DHME (P)
- Member
HOD, Dept of Pharmacy, RIPANS
- Member
District Level Drugs & Therapeutic Advisory Committee
Chief Medical Officer
- Chairman
District Medical Superintendent
- Vice Chairman
Drug Controlling Officer
- Member Secy.
Senior Medical Officer
- Member
Dy. Medical Supdt.
- Member
4 Specialist of any discipline
- Member
b)

The concepts of essential drugs, rational drug use and generic prescribing shall be an integral part of basic and in service training of health
professionals. As such, these shall be incorporated in the curricula of
health training institutions.

c)

All drugs shall be prescribed and dispensed only by their generic name
or International Non-Proprietary Name (INN) in the public sector. Regular Prescription Audits shall be commissioned in public hospitals to
measure the compliance in this regard.

– 12 –

<!-- page 13 -->

Mizoram State Essential Generic Drug Policy

9.

10.

d)

The present Drug Information Centre should be better equipped.

e)

The State would endeavour to conduct training of drug sellers, continuing education of health care providers and consumer education.

f)

The State would endeavour to provide financial incentives to promote
rational use of drugs apart from regulatory and managerial strategies.

PHARMACOVIGILANCE:
9.1

Although medicines are useful to alleviate human illness, all medicines are
not completely safe. Therefore, pharmacovigilance is necessary to safeguard
the public from the possible adverse drug reactions and prevent the cause
of false public alarm and misinterpretation. Pharmacovigilance activities will
be funded through the State drug budget.

9.2

Pharmacovigilance centres shall be established to monitor and document adverse drug reactions and events. These centres shall collect data on adverse
reactions and events and other drug related problems like substandard drugs,
counterfeit drugs, inappropriate use, medication errors etc. from various
health professionals/workers.

9.3

All adverse drug reaction reports and other drug related problems shall be
properly documented and follow up action including preventive measures
shall be taken.

EMERGING DISEASES AND PHARMACEUTICALS:
10.1 New diseases are emerging while existing diseases may pose new challenges.
Such diseases usually become issues of concern when treatment is very expensive and out of reach of most of the people or the treatment or control is
simply difficult or not available at all. In order to address such challenges,

– 13 –

<!-- page 14 -->

Mizoram State Essential Generic Drug Policy

appropriate measures need to be conceived and put in place.
10.2 Efforts will be made to establish a system where both public and private sectors shall be involved to provide drugs needed to adequately treat and control emerging diseases.
11.

HUMAN RESOURCES DEVELOPMENT:
11.1 To support the successful implementation of the policy and to promote the
concepts of essential drugs and rational use of drugs while ensuring proper
management of the limited resources to promote long term sustainability, it
is necessary to develop expertise and human resources in the pharmaceutical field.
11.2 Drug management system at all levels shall be managed by appropriately
trained and skilled personnel. Necessary steps will be taken, in due course of
time, for training of adequate number of pharmacy professionals in the State
so as to manage the hospital pharmacies and drug supply system.
11.3 Appropriate in-service training programmes shall be designed and implemented at different levels to enhance the skills and meet the emerging challenges.
11.4 Clinical pharmacy services shall be introduced in all major Hospitals for the
benefits of the patients;

12.

POLICY IMPLEMENTATION:

The Department of Health & Family Welfare shall take a lead role in implementing
this policy. Mechanism for coordination and collaboration shall be developed to facilitate
implementation of the policy. The Department shall be the Nodal Agency for promotion of
inter and intra-sectoral collaboration and co-operation. The Department shall regularly

– 14 –

<!-- page 15 -->

Mizoram State Essential Generic Drug Policy

review to verify conformity to this policy.

13.

DISPOSAL OF EXPIRED DRUGS AND/OR DRUGS NOT OF STANDARD QUALITY:

There shall be a committee on disposal of 'Expired Drug' and drugs declared 'Not of
Standard Quality' at the state Capital and District Headquarters comprising of the following
members:
Central Drugs Disposal Committee
1.
2.
3.
4.
5.

Dy. Director, Central Medical Store
- Chairman
Superintending Pharmacist, Central Medical Store
- Member Secy
Representative of Director of Health Services
- Member
Representative of Director of Hospital and Med. Education - Member
Representative of State Drug Controller
- Member

District Drug Disposal Committee
1.
2.
3.

Chief Medical Officer
District Asst. Director (F&D)
Representative of District Medical Superintendent

- Chairman
- Member Secy
- Member

The Committee shall, after due verification of the stock and purchase details
pertaining to the 'Expired Drugs' and/or drugs declared 'Not of Standard Quality' shall
supervise the destruction of the above drugs and make a list of such drugs along with Name
of the Drug with strength, Batch No., Expiry Date, Name and Address of the Manufacturer,
Name of the supplier with the total cost in Rupees. The members shall put their signature
on the list of the drugs destroyed which shall be deleted from the stock register.
Destruction of the drugs shall be carried out as per the existing procedure for

– 15 –

<!-- page 16 -->

Mizoram State Essential Generic Drug Policy

destruction of drugs laid down by the State Pollution Control Board in order to avoid
pollution of the environment.
14.

MONITORING AND EVALUATION:

Monitoring and evaluation is an essential component of the State Essential Generic
Drug Policy. Monitoring and evaluation shall take place at regular intervals and complete
external evaluation will be conducted after every five years. Monitoring system for private
sector shall also be developed and implemented by the department. A mechanism for
redressal of public grievances shall also be developed and made effective.
15.

AMENDMENTS:

This policy document shall be reviewed and revised at appropriate intervals based
on the need but at least once every five years.

----------------------------

– 16 –
