---
doc_id: "911a2c3fecafa39c"
source_url: "https://home.mizoram.gov.in/uploads/attachments/2022/11/ba70b3ead20d8695cf1f721364a864b5/notification-mps-junior-grade-posting.pdf"
ministry: "Home Department, Mizoram"
title: "Notification (MPS Junior Grade Posting)..pdf"
date: ""
pages: 2
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "8b2a86b4e221f33b"
---

<!-- page 1 -->

2 No. A-12024/1/2022-HMP/40-41
: GOVERNMENT OF MIZORAM
~ HOME DEPARTMENT
Dated Aizawl, the 27 October, 2022
NOTIFICATION
oy In the interest of public service and on the recommendation of the Mizoram
Pa Public Service Commission vide their letter No.A.12026/5(2)/202 1-MPSC(DR) dt. 06.10.2022
5 and on their acceptance of the offer of appointment, the Governor of Mizoram is pleased to
= appoint the following 8 (eight) persons to the post of Mizoram Police Service (Junior Grade)
in a temporary capacity in the Level 10 in the pay matrix plus other allowances as admissible
. from time to time under the rule in force in the following order of merits with effect from the
f date of joining in the Police Headquarters and posted as shown against each.
, SL.
s ; PLACE OF
V-121 (A), Arakan Street,
: 1.|Malsawmkima | Lallianngura soe veng, Near Vehicle | 4 1p, MAP
te ervicing, Aizawl, Mizoram-
Be 796001
ie Jessica C-27, Zarkawt —-Valley,
‘a 2. Lallawmzuali B. Thangchuanga | Zarkawt, Near Hotel Ahimsa, | A/C,3"Bn. MAP
ke Aizawl, Mizoram - 796007
£ D-2, Main Road, Zarkawt,
® 3. | R. Lalnunpuia R. Laldingliana Opposite Traffic Point, | A/C,2" Bn. MAP
| Aizawl, Mizoram - 796001
' HNo. 95, Kawrtethawveng —
ms Stephan Il, Tuikhuahveng, Near od
® 4. Lalremthara Tlangthanzama Darnam, Kawrtethawveng, AIC, 2" Bn. MAP
: Mizoram - 796441
i Jeremia : JF-100, Near Presbyterian 7
: 5. Vanlalhmachhuana Chhingthankhuma | Church, Zemabawk Vengthar, | A/C,3"IRBn.
t Aizawl, Mizoram - 796017
k N-54,  Alabasta Building,
r Lalmawizuala C. Zahnuna Salem Veng, Near Primary AC,3"IRBn.
b . School — II, Aizawl, Mzioram °
: - 796005
ij C-73, Damveng, Near SBI
f 7. | Lalnunhlua Lalhriatpuia Bank, Sihphir, Mizoram - | A/C,4"IRBn.
; 796036
f Ch-110, Chawngbawla
a R.Lalthankima | Lalthuamliana | Settion, Harm Veng. Near) ic. dh Bn
f ilver Mount, Lunglei,
e Mizoram ~ 796701
t
be

<!-- page 2 -->

ke They shall be on probation for a period of 2 (two) years as per Rule 11 of the
7 Mizoram Police Service Rules, 2008 from the date of joining which can be extended by the
p Governor in accordance with the instructions issued by the Government from time to time.
‘ During the period of probation, they will draw their Pay and Allowances from
a the Police Headquarters against their respective place of posting mentioned against each.
Sd/- LALHRIATPUIA
‘ Additional Secretary to the Government of Mizoram
® Home Department
Memo No. A-12024/1/2022-HMP /40-41 : Dated Aizawl, the 27" October, 2022
Copy to:
1. Secretary to Governor, Mizoram.
2. Secretary to Chief Minister, Mizoram.
3. P.S. to Speaker/Deputy Speaker/Ministers/Ministers of State/Parliamentary
. Secretaries, Mizoram.
4. P.P.S. to Chief Secretary, Government of Mizoram.
5. All Secretaries, Government of Mizoram.
6. All Administrative Departments, Government of Mizoram.
7. Director General of Police, Mizoram. He is requested to kindly arrange
necessary training during the period of probation.
£ 8. Secretary, Mizoram Public Service Commission, Mizoram.
; 9. All Heads of Department, Government of Mizoram.
10. Director, Accounts & Treasuries, Government of Mizoram.
11. Controller, Printing & Stationery with 5 (five) spare copies for publication in
the Mizoram Gazette.
12. All Superintendents of Police/Commandants, Mizoram.
13. Treasury Officers, Aizawl South/ North/ Lunglei/Mamit Mizoram.
14. All persons concerned. They are requested to report themselves to the DGP,
- Mizoram for further instruction.
15. Personal File.
16. Guard File.
wed ee
Under Secretary to the Go’ ment of Mizoram
G fi Home Department
