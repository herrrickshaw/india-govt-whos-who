---
doc_id: "afff14b2e3b0ba2e"
source_url: "https://mizoculture.mizoram.gov.in/uploads/attachments/1fce644d1e54311601bf822f1482badc/pages-38-issue-no-328-the-mizoram-ancient-monuments-and-archaeological-sites-and-remains-rules-2003.pdf"
ministry: "Art and Culture Department, Mizoram"
title: "Issue No 328 The Mizoram Ancient Monuments and Archaeological Sites and Remains Rules 2003"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e9c8152eec7a54dd"
---

<!-- page 1 -->

The Mizoram Gazette
EXTRAORDINARY
Published by Authority
Regn No. NE – 313(MZ)

Rs. 2/- per issue

__________________________________________________________________________________________________________________________________________________________________________________________________________________

VOL – XXXIV Aizawl, Thursday

24.11.2005

Agahayana

3. S.E. 1927. Issue No. 328

NOTIFICATION

The Mizoram Ancient
No. H. 12018/97/05 – LJD/9, the 22nd November, 2005.
Monuments and Archaeological Sites and Remains Rules 2003 is hereby published for
general information.

Sd/CHAWNGTINTHANGA
Deputy Secretary to the Govt. of Mizoram

Ex – 328/2005

Ex – 328/2005

Ex – 328/2005

Ex – 328/2005

Ex – 328/2005

Ex – 328/2005

Ex – 328/2005

Ex – 328/2005

Ex – 328/2005

Ex – 328/2005

Ex – 328/2005

Ex – 328/2005

<!-- page 2 -->

THE MIZORAM ANCIENT MONUMENTS AND ARCHAEOLOGICAL
SITES AND REMAINS RULES 2003
In exercise of the powers under section - 31 of the Mizoram ancient
Monuments and Archaeological sites and remains Act., 2001, the Governor of
Mizoram is pleased to make the following rules.
CHAPTER - I

1.

2.

PRELIMINARY
Short title, extent and commencement.
1) These Rules may be called “The Mizoram Ancient Monuments and
Archaeological Sites and Remains Rules, 2003”.
2)
They shall extend to the whole of the State of Mizoram.
3) They shall come into force with effect from the date of publication in the
Mizoram Gazette.

Definitions.
In these Rules, unless the context otherwise requires (a) “Act” means the “Mizoram Ancient Monuments and Archaeological Sites
and Remains Act, 2001” (Mizoram ActNo.2 of 2001 )
(b) “ancient monument” means any structure, erection or monument, or any
tumulus or place of interment, or any cave, rock, sculpture, inscription or
monolith, which is of historical, archaeological or artistic interest and
which has been in existence for not less than seventy five years, and
includes:i)
the remains of an ancient Monument;
ii)
the site of an ancient monument;
iii) such portion of land adjoining the site of an ancient monument as
may require for fencing or covering in or otherwise preserving
such monument; and
iv)
the means of access toand convenient inspection of an ancient
monument;
(c)
“antiquity” includes (i)
any coin, sculpture, manuscript, epigraph, or other works of art
orcraftmanship;
(ii) any article, object or thing illustrative or science art crafts,
literature, religion, customs, morals or politics in by-gone ages;
(iii) any article, object or thing detached from a building or cave;

<!-- page 3 -->

(iv)
(v)

any article, object or thing of historical interest, and
any article, object or thing declared by the State Government, by
notification in the official gazette to be an antiquity for the
purposes of this Act, which has been in existence for not less than
seventy five years;
(d) “Archaeological Officer” means an officer of the Department of Art &
Culture of the Government of Mizoram, not lower in rank than an
Assistant Director;
(e) “Archaeological Site and Remains” means any area which contains or is
reasonably believed to contain ruins or relics of historical or
archaeological importance which have been in existence for not less than
seventy five years, and includes :(i)
such portion of land adjoining the area as may be required for
fencing or covering in or otherwise preserving it, and
(ii) the means of access to, and convenient inspection of, the area;
(f)
“construction” means the construction of any structure; including
addition to or alterations of an existing building;
(g) "copying" means the preparation of copies by drawing or by
photography or mound or by squeezing including the preparation of a
cinematographic film with the aid of hand camera which is capable of
taking not more than eight millimeters and which does not require the
use of a stand or involve any special previous arrangement.
(h) "Deputy Commissioner" means Deputy Commissioner in all Districts
within Mizoram:
(i)
Director" means the Director of Art & Culture Department of the
Government of Mizoram;
(J)
“maintain’’ with its grammatical variations and cognate expressions,
including the fencing, covering in, repairing, restoring and cleansing of a
protected monument, and the doing of any act which may be necessary
for the purpose of preserving a protected monument or securing
convenient access there to ;
(k) “owner” includesi)
a joint owner invested with powers of management on behalf of
himself and other joint owners and the successor-in title of any
such owner;and
ii)
any manager or trustee exercising powers of management and the
successor-in -office of any such manager of trustee ;
(l)
“prescribed” means prescribed by rules made under this Act;
(m) “protected area” means any Archaeological Site and Remains which is
declared to be of national importance by or under the Act;

<!-- page 4 -->

(n)

(o)
(p)

“protected monument” means any ancient monument which is declared
to be of natural importance by or under the Act;
“section” means a section of the Act;
“State Government” means the State Government of Mizoram.
CHAPTER - II
DECLARATION OF PROTECTED MONUMENTS

3.

Manner of enquiry' before an Ancient Monument may be declared to be
protected
1)
The Director shall, before a notification under section 3 issue, cause a
thorough enquiry as to the antiquity of the monument to be protected,
and shall determine as accurately as possible the age of the monument
on such evidences as may be available to him.
2)

3)

4.

5.

On obtaining evidences which the Director considers sufficient for
protection of a monument, he shall submit necessary proposals to the
State Government for protection of the same under intimation to the
Deputy Commissioner concerned.

In submitting a proposal to the State Government, the Director shall
specify the exact area of the land that is required for the purpose of
preserving the monument in proper manner with facilities for approach
road, erection of any structures and for laying out of gardens.

Recommendation of the Deputy Commissioner :The Deputy Commissioner
shall within one month from the date of the receipt of the report from the
Director, submit to the State Government his objection if any against the
proposal of the Director together with alternative suggestion. The State
Government may issue a notification under section 3. notwithstanding the fact
that no report has been received from the Deputy Commissioner in this behalf.

Demarcation of Site. As soon as a notification has been confirmed under subsection (3) of section 3, the Director shall cause necessary pillars and fencing to
be fixed demarcating the area appearing in the notification and required for
preservation of the protected monument.

<!-- page 5 -->

6.

Restriction of Public entry into a monument under repair.
1) The Director may by an order to be fixed up in a conspicuous place near the
monument, prevent entry into the site of the protected monument of any
person not specifically authorized by him to do so, during such period of
time when the monument is under repair or when an excavation is carried
on in the site or when entry of un-authorized persons is deemed by the
Director to be detrimental in the interest of work of preservation.
2)

In the case of a protected monument which or part of which is used for
religious worship of observances by any community, the person or persons
whose entry to the monument is required for the purpose of religious
observances, shall be deemed to be persons authorized by the Director for
such entry under sub-rule (1).
CHAPTER - III

GUARDIANSHIP OVER MONUMENTS. AND THEIR MAINTENANCE
7.

Determination of the Owner.
1) As soon as the antiquity of the monument has been established by the
Director, he shall report the matter to the Deputy Commissioner for
determining the ownership of the monument.

2)

3)

4)

The Deputy Commissioner, immediately on receipt of the report from the
Director shall cause an enquiry regarding the ownership of the monument;
and failing to ascertain any owner readily, he shall notify the matter in such
manner as may be deemed fit calling for petitions regarding ownership of
the monument to be filed within a period of one month.

On receipt of the petitions, as under sub-rule (2), the Deputy Commissioner
shall fix the ownership of the monument and report the name of the owner
to the Director and to the State Government with intimation to the owner
so fixed.
In the event of there being no claim regarding ownership of the
monuments within the specified time, the monument shall be deemed to
have no owner; and the Director shall assume the guardianship of the
monument under sub-section(2) of section 4.

<!-- page 6 -->

8.

Appeal.
1) Any person or persons aggrieved by the decision regarding the ownership
of the monument as under sub-rule (3) or (4) of rule 7 may prefer an
appeal to the State Government within thirty days from the date of
notification or of communication of the decision of the Deputy
Commissioner.
2)

9.

The decision of the State Government in respect of the ownership shall be
final and binding on all concerned.

Terms of Agreement.
(1) As soon as it is proposed that a monument is to be protected under
agreement with the owner, the Director shall draw up a list of items in
respect of which the agreement has to be executed in the interest of the
proper maintenance of the monument.
(2) The Director shall draw up a draft agreement on the basis of the items of
agreement, and shall work out the financial estimates involved on both the
parties on maintenance of the monument. The draft agreement and the
financial estimates so worked out shall be forwarded by him to the State
Government.

(3) The State Government shall after such modification of the terms of
agreement as may be found necessary, forward the approved agreement to
the Deputy Commissioner with necessary intimation to the Director.
(4) The Deputy Commissioner shall not direct any owner to enter into an
agreement with the State Government unless the agreement is approved by
the State Government.

10. Appeal.
(1) Any person aggrieved by an order of the Director made under section 9,
may prefer an appeal to the State Government within a period of thirty
days from the date of receipt of the order of the Director.
(2)
(3)

An appeal made under sub-rule (1) shall be submitted through the Deputy
Commissioner of the district in which the protected monument is
situated.

The State Government shall, before giving decision, take into
consideration all aspects of the matter and the recommendation made by
the Deputy Commissioner.

<!-- page 7 -->

(4)

Notwithstanding an appeal made by an owner under sub-rule (1) an
order of the Director passed under section 9, shall be valid and effective
during the time from the date on which the order passed till the date on
which it is revoked tor modified by the State Government on
consideration of the appeal.
CHAPTER – IV

ACCESS TO, AND CONSTRUCTION AND OTHER OPERATION, ON THE SITE OF
THE MONUMENT
11. Rights of public access to monument.
1)
Access to protected monument in respect of which an agreement has been
entered into between the owner and the State Government under section
5, shall be governed by the terms of the agreement.
3)
3)
12.

14.

Four copies of the relevant provisions of the agreement or a copy of the
order of the Director shall be exhibited in a conspicuous part of the
monument.

Monument when kept open.
1)
The Director, by order may direct, subject to the provisions of section 16,
that any specified part of a protected monument shall not be
opened,permanently or for any specified period to any person other
than an Archaeological Officer, his agents, subordinates and workman
and any other Government servant on duty at such part.

2)
13.

Right of public access to monuments other than those mentioned in subrule(1), shall be as laid down by an order of the Director from time to
time.

The Director may, by order, specify the hours during which a protected
monument shall remain open to public and a copy of such order shall be
exhibited in a conspicuous place of the monument.

Entrance Fee- Public entry into a monument shall ordinarily be free.

Holding of meetings, etc. in monuments.
1)
No protected monument shall be used for the purpose of holding any
meeting, reception party, conference or entertainment except under and
in accordance with a permission in writing granted by the State

<!-- page 8 -->

2)
15.

16.

Nothing in sub-rule(1) shall apply to any meeting, reception
partyconference orentertainment which is held in pursuance of a
recognized religious or custom.

Provision of Certain Acts within Monuments.
No person shall within a protected monument a)
do any act which causes or is likely to cause any damage or injury to any
part of the monument, or
b)
discharge any fire arms ; or
c)
cook or consume food except in areas, if any permitted to be used for
that purpose, or
d)
hawk or sell any goods or wares or canvass any custom for such goods of
wares or display any advertisement in any form or show a visitor round
for monetary consideration, except under the authority of the Director
or his agent, or
e)
beg for alms ; or
f)
violate any practice, usage or custom applicable to be observed in the
monument; or
g)
bring, for any purpose other than the maintenance of the monument;
(i)
any animal, or
(ii) any vehicle except in areas reserved for the parking there of.

Excavation.
1)
Subject to the provisions of the Ancient Monuments and Archaeological
Sites and remains Act, 1958 (24 of 1958) and the rules made there under
the Director may, with the previous approval of the State Government,
undertake excavations for maintenance purposes in the site of an
Ancient Monument.
2)

17.

Government or any authority empowered by it.

No person other than the Director or any agent authorized by him, and
the workmen appointed or employed by him shall undertake any such
excavation in the sites of an ancient monument.

Result of Excavation.
Where a result of such excavation made by the Director in any site of a
monument, any antiquities are discovered, the Director shall as soon as
practicable, submit a report to the State Government on the antiquities
recovered during the excavation.

<!-- page 9 -->

18.

19.

Removal of antiquities.
If the State Government considered that any sculptures, carving, images,
inscriptions or other like objects ought not be removed from the place where
they are, ii may, by notification, direct that any such class of objects shall not be
removed without written permission of the Director.

Removal of antiquities by the Director.
1)
The State Government may, by an orderdirect that the Director may
remove any of the objects mentioned in rule 18, if in the opinion of the
State Government such removal of the object has become necessary for
the purpose of better maintenance of the objects.

2)
20.

21.

22.

23.

Whenever such direction issued by State Government for removal of an
object of antiquity, it shall specify the place where such antiquities are to
be preserved.

Duties of the owner of antiquities.
As soon as the Director is authorized by the State Government under orders, to
remove any object of antiquity under rule 19, it shall be the duty of the owner
if any, of the objects to hand over the objects to the Director when approached
for the purpose.

Permission for removal.
Any person may apply to the Director for permission to remove any of the
objects mentioned in rule 18, specifying the object or objects which he
proposes to move.
Appeal.
If the Director refuses to grant such permission, the applicant may appeal to
the State Government whose decision shall be final.

Compensation.
If any person, aggrieved by any action taken under rules 18,19,20,21, and 22
proves to the satisfaction of the State Government that he has suffered some
loss or damage by reason of the above actions, the State Government may
consider payment of such compensation to the persons to such an extent as
may be found reasonable.

<!-- page 10 -->

CHAPTER - IV
MISCELLANEOUS

24.

25.

Copying of certain Monuments.
The Director may, by order, direct that no person other than an Archaeological
Officer shall copy any specified monument or part thereof except under a
permission in writing granted by the Director or an Archaeological Officer.

Condition of Copying.
Nothing in rule 24, shall be construed as authorizing any person other than an
Archaeological Officer while copying any such monuments to bring into use
such materials or equipment or artificial light except flash lights for exposure
of a camera, or to erect such a scaffolding or to apply any such extraneous
matter on the monuments, as in the opinion ofthe Director or any
Archaeological Officer granting the permission, are detrimental to the
archaeological interests.

__________________________________________________________________________________________________
Published and Issued by Controller, Printing & Stationery Department. Government of Mizoram
Printed at the Mizoram Government Press, Aizawl. C/850
