---
doc_id: "2f68dc535facaef9"
source_url: "https://home.mizoram.gov.in/uploads/attachments/51d58c81ea25b49968482ee37e73f7f3/order-on-resumption-of-flight.pdf"
ministry: "Home Department, Mizoram"
title: "Order on resumption of flight.pdf"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "142f8ab507c4893e"
---

<!-- page 1 -->

No.F.22ot2 I 2 I 202O-H]M I COVID- I 9
(X)VERNMENT OF MIZORAM
HOME DEPARTMENT
*****

Atzaw\ 22"4 otMag,2O2O

ORDER
Consequent upon the announcement of resumption of domestic flights
w.e.f 25s May,2O2O by the Ministry of Civil Aviation, Government of India, and
in view of the current CoVid-l9 pandemic situation, it is necessary to lay down
certain guidelines and procedure to be followed by persons entering the State of
Mizoram by flight through Lengpui Airport. Therefore, in the interest of public
service, it is hereby ordered that all permanent residents of Mizoram and all
Government servants stranded outside the State due to CoViD- 19 lockdown
who intend to enter Mizoram by flight through Lengpui Airport shall abide by
the following rules and procedure with immediate effect and until further
orders:

1) A11 such persons shall intimate their flight & ticket details to the resident
representaLive of the Government of Mizoram (Resident Commissioner, New
Delhi/Jt. Resident Commissioner, Kolkata/Dy Resident Commissioner,
Guwahati/ Shillong/ Silchar) located in the station where they aie currently
stranded. In States/cities where a resident representative (Mizoram House)
is not located, such details may be reported ttrrough the nearest Mizo
Welfare Associations. Such persons shall give their full particulars as per
the proforma attached in Annexure l. Any person furnishing false
information or found to conceal information shall be liable to be penalised.

2) No person shall board any flight bound for Lengpui Airport without
obtaining prior permission from Home Department, Government of Mizoram,
and any person arriving at l,engpui Airport without movement permit shall
not be allowed to leave the airport.

3) The list of passengers shall be sent to the Chairman, Task Group on Migrant
Workers & Stranded Travellers who shall submit a compiled list for every
flight, destination-district-wise, to Home Department by 2:OO P.M of the
day prior to the date of departure of the flight, for approval.

4) All persons arriving at Lengpui Airport shall undergo mandatory screening
for CoVid-l9 symptoms and Rapid Antibody Test, or as prescribed by the
State Government from time to time.

5) All persons arriving at Lengpui Airport from areas declared as Red Zones by
the Ministry of Health & Family Welfare, Government of India shall undergo
RT-PCR test after arrival at their respective quarantine locations, in addition
to the Rapid Antibody Test done at Lengpui Airport.

Page I of2

<!-- page 2 -->

6) All persons shall undergo mandatory quarantine for 14 days as assigned by
the respective Deputy Commissioners.

7) All persons arriving by flight at Lengpui Airport shall proceed to their
respective quarantine facilities via their designated arrival/ transit points as
applicable, only by means of transportation arranged by the Deputy
Commissioners concerned. No other pick-up arrangement shall be allowed
unless permitted by the same authorit5r.

8) Until further orders, persons other than those mentioned in the first
paragraph, shall obtain prior permission of Home Department, Government
of Mizoram before booking their flight tickets for Lengpui airport.

9) In addition to the procedure aforementioned, all persons arriving at Lengpui
Airport shall abide by the SOPs prescribed by the Government of Mizoram,
as well as the guidelines issued by the Ministry of Civil Aviation,
Government of India vide Order No.AY.29017 /5l2O2O-DT dated 2L.O5.2O2O
which is available in the Ministry's website at www.civilaviation.qov.in. As
per tJre pre-departure guidelines issued by the MoCA, all passengers shall
certiff the status of their health through the Aarogra Setu mobile app, or
through a self-declaration form as given in Annexure 2.

Sd,/. LALNUNMAWIA CHUAUT{GO
Chief Secretary to the Govt. of Mizoram
Memo 1,b.F.22O12/2/2O2O-HWCOWI>79 : Atzawl, 22"d of Mag, 2O2O
CopA to:

I Secretary to Governor, Mizoram.
2
3
4
5.
6.

8.
9.
10.
11.

t2.
13.

14.
15.
16.

PS to Chief Minister. Mizoram.
PS to Deputy Chief Minister, Mizoram

PS to Speaker/Ministers/Dy Speaker/Ministers of State/Govt. Dy Chief
Whip/Vice-Chairman, State Planning Board, Mizoram.
Sr PPS to Chief Secretary, Govt. of Mizoram.
PS to Addl Chief Secretary, Govt. of Mizoram.
Joint Secretar5r (NE), Ministry of Home Affairs, Govt of India, New Delhi.
All Administrative Heads of Department, Government of Mizoram.
AII Heads of Department, Government of Mizoram.
A11 Task Groups on CoVid- 19 constituted by DM&R Department, Mizoram.
Nodal Offrcer for Coordination with Ministry of Railways & Other States,
Mizoram.
Principal Consultant, Civil Aviation Wing, GAD, Govt. of Mizoram.
A11 Deputy Commissioners, M2oram.
All Mizoram Houses.
All Chairman/Coordinator, Mizo Welfare Associations.
Guard hle.

Additional Secretary to the Govt. of Mizoram
Home Departaent
Page 2 of 2

<!-- page 3 -->

Annexure I

DETAILS OF STRANDED RESIDENTS OF MIZORAM ARRIVING BY FLIGHT FROM

DATE & TIME OF

st.
No

NAME, AGE & GENDER

CONTACT NO

FUtt POSTAT ADDRESS

EPtcl

FUtT POSTAT ADDRESS IN

FLIGHT NO/

ARRIVAT AT

IN MIZORAM

AADHAR NO

PRESENT I.OCATION

AIRTINE

TENGPUI

AIRPORT

1

2
3

4
5

6
7

8
9
10

* Compilation to be done district-wise.

CATEGORY OF

covlD-19
ZONE OF
PRESENT

tocATloN

<!-- page 4 -->

Annexure 2

SEL['DECLARATION FORM FOR AIR PASSENGERS

I

llwe an/are not residing in any containment zone.

ll.

Il we arnlarc not suffering from any fever/cough,/any respiratory distress.

llt.

llwe un/are not under quarantine.

lv,

If Uwe develop any of the above-mentioned symptoms I/we shall contact
the concemed health authorities concemed immediately.

I/we have not tested CoVid-19 positive in last two months.
v1

Uwe am/are eligible to travel as per the extant norms.

vll.

I/we shall make mylour mobile number / contact details available to the
airlines whenever required by them.

viii. I/we understand that if Vwe undertake the air journey without meeting
the eligibility criteria Uwe would be liable to penal action.

lx.

Vwe undertake to adhere to the health protocol prescribed by the
destination State / UT

Name of Passenger

Signature

Note: In case a single PNR is issued for more than one passenger, the declaration would be
deemed to cover all the passengers mentioned in the PNR.
i.e. One form may be used for passengers having the same PNR.
