---
doc_id: "db4cf287e69badf7"
source_url: "https://fcsca.mizoram.gov.in/uploads/attachments/2022/09/947c27356ea25bc27c9746d6a0549824/posts-475-storekeeper-avertisement-application-form-guidelines.pdf"
ministry: "Food, Civil Supplies and Consumer Affairs Department, Mizoram"
title: "Storekeeper Avertisement, application form & guidelines"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b95e43c9a3c83b4f"
---

<!-- page 1 -->

<!-- page 2 -->

COMMON APPLICATION FORM FOR RECRUITMENT TO THE POST OF
STORE KEEPER UNDER FOOD, CIVIL SUPPLIES & CONSUMER AFFAIRS
DEPARTMENT GOVERNMENT OF MIZORAM

Application No ………………………..

Passport size photo
to be affixed

1) Name of Post

:

____________________________________

2) Name of Department

:

____________________________________

3) Name of candidate
(In capital letters only)

:

____________________________________

4) Father’s/Mother’s name

:

____________________________________

5) Permanent address

:

____________________________________
____________________________________
____________________________________

6) (a) Address for correspondence:

____________________________________
____________________________________
____________________________________

(b) Phone number
7) Date of birth (attach
attested photocopy of Birth
Certificate or HSLC or
Aadhaar)
8) Sex (Male or Female)
9) Community i.e. SC/ST/OBC
(Attach self attested photocopy
of the supporting document)

:

____________________________________

:

____________________________________

:

____________________________________

<!-- page 3 -->

10) Educational and other qualifications:
As prescribed in the advertisement
(Attach attested photocopy of
the supporting document)

1. _________________________________
2. _________________________________
3. _________________________________
4. _________________________________
5. _________________________________

11) Experience, if any
(Attach attested photocopy of the
supporting document)

: _________________________________

12) Whether the candidate possessed
working knowledge of Mizo
language at least Middle School
standard?

: YES/NO

13) Indicate the list of attested
documents enclosed with the
application(i.e. Educational
Certificate, ST Certificate,
Birth Certificate, etc.)

: 1. _________________________________
2. _________________________________
3. _________________________________
4. _________________________________
5. _________________________________

___________________________________

DECLARATION
I hereby declare that the information given above and in the enclosed documents is
true to the best of my knowledge and belief and nothing has been concealed therein. I
understand that if the information given by me is proved false/not true, I will have to face the
punishment as per the law. Also, all the benefits availed by me shall be summarily
withdrawn.

Place:
Date:

(Signature of the candidate)
CERTIFICATE BY HEAD OF DEPARTMENT
(For use of Government Servants only)

Certified that Mr/Mrs/Miss ______________________________________ holds a
temporary/permanent post under the Central/State Government. His character so far as known
to me is good and I am not aware of any circumstances which show that he would be
unsuitable for any appointment to any post if successful in the examination

Date:

Signature: _______________________
Designation: _______________________
(Office Seal)

<!-- page 4 -->

Guidelines for recruitment to the post of Storekeeper under Food, Civil Supplies
& Consumer Affairs (FCS&CA) Department
These guidelines may be referred to while applying for the post of Storekeeper advertised
by Food, Civil Supplies & Consumer Affairs (FCS&CA) Department.
I.

II.

Application Forms and Fees:
(1)

Application Forms for the posts advertised will be available in the
Directorate as well as at the offices of District Civil Supply Officer (DCSO)
in all Districts during office working hours with effect from the date of
publication of the advertisement.

(2)

The Application Forms for examinations conducted under these Guidelines
will be provided by the Department to the candidates seeking such forms free
of cost. It will also be available in the department website
(fcsca.mizoram.gov.in ) for easy access.

(3)

The Application Fee for examination will be ₹ 150/- (Rupees one hundred
and fifty) only for Scheduled Tribe/Scheduled Caste/Other Backward Class
candidates and ₹ 200/- (Rupees two hundred) only for General category
candidates.

(4)

The duly filled in Application Forms can be submitted during 26.09.2022 to
26.10.2022 at the Establishment Branch in the office of the Directorate of
Food, Civil Supplies & Consumer Affairs (FCS&CA) Department and in the
office of DCSO of each District during office hour.

Acceptance of self attested/self certified documents:
(1)

Candidates applying for the posts shall submit self attested/self certified
copies of documents at the time of submission of application forms in
response to the advertisement for recruitment to the posts.

(2)

Candidates who are selected for personal interview on the basis of the
written examination shall bring original certificate of ST/SC/OBC
Certificate, educational certificate, birth certificate and any other relevant
document issued by the competent authority at the time of the personal
interview.

(3)

Candidates who have been declared successful in the examination on the
basis of forged documents/ fake documents shall be summarily disqualified
and his/her name shall be deleted from the list of successful candidates and
the first name on the reserved panel, if any, shall be declared as the
successful candidate.

<!-- page 5 -->

III.

Document for ascertaining the date of birth:
The date of birth as recorded in confirmatory documentary evidences such as
High School Leaving Certificate or Birth Certificate or any other document as
specified by the Government in DP&AR from time to time shall be used as
proof for determining the age of the candidate.

IV.

Eligibility:
In order to be eligible to compete in the examination for recruitment to the post
of Storekeeper, a candidate must be a citizen of India and must satisfy all the
eligibility conditions as prescribed in the respective Recruitment
Rules/Examination Regulations/Guidelines, etc.
The decision of the Department as to the eligibility or otherwise of
the candidates for examination shall be final and no candidate to whom an
Admit Card has not been issued by the Department shall be admitted to the
examination.

V.

Syllabus
Paper

Subject
General Knowledge (50 questions)

General English (25 questions)
Paper-I

Essay Writing
English Comprehension

Total
Simple Arithmetic (50 questions)

Paper-II

Marks
100
50
30
20
200
100

Basic Computer Knowledge (50
questions)

100

Total

200

Duration
3 hours with additional
time
of 40 minutes
for Visually
handicapped/ Cerebral
palsy candidates
3 hours with additional
time
of 40 minutes
for Visually
handicapped/ Cerebral
palsy candidates

Notes:
(i)

Questions shall be set in Objective Type Multiple Choice pattern only with all
questions carrying equal marks and answers for each of the questions shall be
marked using blue or black ball point pen. In other words, there shall be
multiple probable answers (at least four) wherein the candidate has to choose
the correct answer for every objective type question.

(ii)

Questions will be set in tune with the level of educational qualifications
prescribed in the corresponding Recruitment Rules for the post.

(iii)

A brief description of the syllabus for recruitment to the post of Storekeeper is
as follows:

<!-- page 6 -->

Paper-I
General Knowledge: Questions will be designed to test the candidate’s
knowledge of current events and of such matters of everyday observation and
experience as may be expected of an educated person. The test will also include
questions relating to Indian history and culture, Indian polity including the
Constitution of India, geography, economy and general science. Questions on
Mizo history and culture will also form part of the syllabus.
General English: Questions will be designed to test the candidates
understanding and knowledge of English language, vocabulary, spelling,
grammar, sentence structure, synonyms, antonyms, sentence completion,
phrases and idiomatic use of words etc. There will be questions on
comprehension of a passage also.
Essay Writing: Question on essay writing will be designed to test the
candidate’s grasp of his material, its relevance to the subject chosen, and to his
ability to think constructively and to present his ideas logically, constructively
and concisely.
English Comprehension: There will be questions on comprehension of
passages also to test the vocabulary, grammar, logical thought ability and
overall grasp of the candidates over English language.
Paper-II
Simple Arithmetic: Number system, simplification, roots, averages, discounts,
percentages, profit & loss, ratio and proportion, partnership, chain rule, time &
work, time & distance, simple & compound interest, mensuration, permutations
& combinations, heights & distances, line graphs, bar graphs, pie charts and
tabulation.
Basic Computer knowledge: Introduction to Computers, introduction to
Graphical user interface based Operating System, elements of Word Processing,
Spreadsheets, Power point presentations, Computer communication and
internet, world wide web and web browser, communication and collaboration.
Holding of written examination:

VI.
(1)

Written examination for recruitment to the posts will be conducted by the
Department in the manner as per prescribed under the Mizoram Direct
Recruitment (Conduct of Examination) Guidelines 2018.

(2)

The date on which and the venue at which the written examination shall be
held will be fixed by the Department and it will be communicated to the
applicants via post and website.

<!-- page 7 -->

VII.

Admit Card

(1)

An Admit Card in respect of the candidates for whom their candidature has
been accepted by the department will be prepared and shall be collected by
the candidate on intimation.

(2)

If a candidate loses his Admit Card, he should inform the Director,
FCS&CA Department immediately stating clearly the reason for the loss and
if the Director is satisfied of the genuineness of the loss, a duplicate Admit
Card will be issued on payment of ₹ 50/-.

VIII. Admission of candidates to Examination Hall/Room
(1)

(2)
(3)
(4)
(5)

IX.

The Examination Hall/Room will be opened half an hour before the
commencement of the examination and candidates will be allowed entry in
the Examination Hall/Room 20 minutes before the commencement of the
examination in each session.
A candidate will not ordinarily be admitted to the Examination Hall/Room
after the lapse of 10 minutes from the commencement of examination in
each session.
A candidate, once given an Answer paper should, in no case be allowed to
leave the Examination Hall/Room without submitting the same.
Candidates shall be permitted to take a seat only at the Venue and in the
Centre where he/she has been allotted.
Candidates shall be duly subjected to frisking before entry into the
Examination Hall/Room.
Personal Interview

(1)

Personal Interview will be conducted by the Departmental Promotion
Committee duly constituted by the Government and the date will be
communicated to the applicants based on their performance in the written
examination.

(2)

The number of candidates to be called for Personal Interview will be called
as per NOTIFICATION No. A.12026/1/2017-P&AR(GSW) dt. 09.02.2018.

(3)

The marks allotted for Personal Interview shall be fixed at 50 marks.

(4)

In cases where the number of applicants for the posts is less than the number
of candidates to be called for interview as per the norms set out at sub-clause
(2) above, recruitment would be done by means of Personal Interview only
and, it will carry a maximum mark of 100.

<!-- page 8 -->

REQUISITE COMPUTER PROFICIENCIES FOR THE POST OF
STOREKEEPER AS PRESCRIBED BY DP&AR(GSW)
1. Basic knowledge of Computer application equivalent to Course on Computer
Concepts (CCC) of National Institute of Electronics and Information Technology
(NIELIT) or Diploma in Computer Application / Certificate in Computer
Application from institutions recognised by Mizoram State Council of Technical
Education (MSCTE) as a minimum computer proficiency qualification for direct
recruitment to all Group ‘A’, B’ and ‘C’ posts under the Government of Mizoram
vide No. A. 11013/1/2013- P&AR(GSW) dated 29.09.2016.
2. 1) Course on Computer Concepts Plus (CCC+) or Expert Computer Course
(ECC) under NIELIT, or
2) ‘O’ Level, ‘A’ Level, ‘B’ Level and ‘C’ Level Courses under NIELIT, or
3) Diploma
in
Computer
Science/Computer
Application/Information
Technology/Electronics from Polytechnic Institutions or Institutions
recognized under Government of Mizoram or Government of India, or
4) Bachelor’s degree in Computer Science/Computer Application/Information
Technology/ Electronics from recognized University or Institutions
recognized under Government of Mizoram or Government of India, or
5) Post Graduate Diploma or Master’s degree in Computer Science/ Computer
Application/Information Technology/Electronics from recognized University
or Institutions recognized under Government of Mizoram or Government of
India. vide No.A.11013/1/2013-P&AR(GSW) dated 16.12.2016
3. 1) Bachelor’s degree or above from a recognized University with Computer
proficiency related courses as one of the subject; or
2) Post Graduate Diploma in any course of study from a recognized University
with Computer proficiency related courses as one of the subject; or
3) Diploma in various Branches of Engineering or other allied streams (such as
Modern Office Practice, etc) from Polytechnic Institutions or Institutions
recognized under All India Council for Technical Education or Mizoram
State Council for Technical Education with Computer proficiency related
courses as one of the subject; or
4) Higher Secondary School Leaving Certificate with Computer proficiency
related courses as one of the subject under Central or State Board of School
Education; or
5) National Trade Certificate from Institutions recognized under National Council
for Vocational Training OR State Trade Certificate from Institutions
recognized under Mizoram State Council for Vocational Training with
Computer proficiency related courses as one of the subject; or
6) Certificate in Computer Application or Diploma in Computer Application or
such other Computer proficiency courses from Institutions duly recognized
by the Government of Mizoram at that point of time before recognition to
Computer proficiency courses is granted by the Mizoram State Council of
Technical Education (MSCTE) with effect from 01.11.2013. vide
No.A.12034/1/2015-P&AR(GSW) dated 4.12.2017.
