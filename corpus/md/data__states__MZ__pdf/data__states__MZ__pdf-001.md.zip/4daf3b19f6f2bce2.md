---
doc_id: "4daf3b19f6f2bce2"
source_url: "https://lad.mizoram.gov.in/uploads/attachments/2025/12/29cf07c3ab66f41f395154e764f0b5f8/posts-96-office-order-of-recruitment-of-sprc-rgsa-staff.pdf"
ministry: "Local Administration Department, Mizoram"
title: "office order of recruitment of SPRC, RGSA Staff"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "049c96a2378093aa"
---

<!-- page 1 -->

GOVERNMENT OF MIZORAM
DIRECTORATE OF LOCAL ADMINISTRATION DEPARTMENT
~~
MIZORAM : AIZAWL
' ·
\.JV
MINECO, KHATLA
email ID- dirprl admz @gma il.com
Dated Aizawl the 15th Decem ber, 2025
No.G. 25018 /47 /2025- DTE(L AD)/P MU

OFFICE ORDER

As per the decisio n convey ed by the Gover nment vide
and
No.P.1 1063/6 /2025- RD&A D(RGS A) dt.11.1 2.2025 , Group Discus sion
post
one
for
Person al Intervi ew for the recrui tment of contra ctual emplo yees
ayat
each of Traini ng Assist ant and Multi- Taskin g Staff under thState Panch
2026
ry,
Janua
13
on
held
be
to
Resou rce Center (SPRC), RGSA is schedu led
ary, Rural
at 10:00 AM in the Office Chamb er of Comm issione r & Secret
Main
ariat,
Develo pment and Admin istratio n Depar tment, Mizoram Secret
Buildin g, 1st Floor, Room No. 114.
All eligible candid ates are hereby inform ed to report to the said
sion and
Office by 9:30 AM on the aforem ention ed date for the Group Discus
Person al Interview.

Sd/-K . LALROHLUA
Direct or
Direct orate of Local Admin istratio n
Rural Develo pment & Admin istratio n Depar tment
Mizoram: Aizawl
th
2025.
Memo No.G. 25018 /47 /2025-DTE(LAD)/PMU Dated Aizawl, the 15 Dec.,
Copy to:
kind
1. The Under Secret ary to. the Gover nment of Mizoram, RD&AD for
inform ation.
the
2. Websi te Manag er, LAD for inform ation and with instruc tion to upload
same on the LAD's Website.
3. All candid ates for inform ation and necess ary action .

Joint rector (A) & SNO, RGs f} L ~
Direct orate of Local Admin istratio n
Rural Develo pment & Admin istratio n Depar tment
ft,Mizoram: Aizawl
