---
doc_id: "36b4b4c4dfdce26b"
source_url: "https://lesde.mizoram.gov.in/uploads/attachments/2023/11/45e37076fc54f9b7e141ecb835da94a8/posts-123-office-order-regarding-officers-under-lesde-new-designation-reg.pdf"
ministry: "Labour, Employment, Skill Development and Entrepreneurship Department, Mizoram"
title: "office order regarding officers under LESDE new designation-reg"
date: ""
pages: 2
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "2fa3ece466703270"
---

<!-- page 1 -->

GOVERNMENT OF MIZORAM —
DIRECTORATE OF LABOUR, EMPLOYMENT, SKILL DEV.
& ENTREPRENEURSHIP DEPARTMENT
MIZORAM : AIZAWL
Dated Aizawl, the 3" November, 2023.
OFFICE ORDER
In pursuance of the Govt. Notification Memo No,A.11016/1/2021-LESDE
Dt.10" July, 2023, the following Officers under Labour, Employment, Skill
Development & Entrepreneurship Department are hereby re-designated as follows:-
S| Name of Post No.of New Designation
No. Post |
1 District Labour 3 Deputy Director, Level-11
Employment Officer, .
Aizawl, Lunglei, Siaha 5
2 Labour Officer 1 Labour, Employment, Skill Development
& Entrepreneurship Officer (LESO)
Level-10
3 Inspector of Factories 1 Labour, Employment, Skill Development
& Entrepreneurship Officer (LESO)
Level-10
4 Employment Officer 8 Assistant Labour, Employment, Skill
Development & Entrepreneurship Officer
(Assistant LESO) Level-8
S Assistant Labour 1 Assistant Labour, Employment, Skill
Officer Development & Entrepreneurship Officer
(Assistant LESO) Level-8

<!-- page 2 -->

This issues with the approval of DP & AR (ARW) vide their ID No.
ARW/LESDE-103/2023-2024/B-28 Dated 20.04.2023 and concurrence of Finance
Deptt. vide their ID No.FIN(E)68/2023 dated 09.06.2023.
(ANGELA ZOTHANPUID)
Director,
Labour,Employment, Skill Development
& Entrepreneurship.
Mizoram : Aizawl
A.11019/1/2022-DTE(LESDE) ? Dated Aizawl, the 3°? November 2023
Copy to 1. U/S LESD & ED, for information .
2. District Employment Exchange, Aizawl/Lunglei/Siaha/Champhai under LESDE
Deptt. for information & necessary action. i
3. Principal Govt. ITI ,Aizawl/Lunglei/Siaha under LESDE Deptt. for information.

4. All Officers under LESDE Deptt. for information.

5. Office File.
| ,

Direttof, \ |
| Labour,Employment,Skill Development
& Entrepreneurship.
Mizoram : Aizawl
a
