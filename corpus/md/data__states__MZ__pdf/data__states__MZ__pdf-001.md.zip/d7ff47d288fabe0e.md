---
doc_id: "d7ff47d288fabe0e"
source_url: "https://excise.mizoram.gov.in/uploads/attachments/2026/10/9e0acd85e54d842db35d5431c5a4651c/posts-865-promotion-order-of-si-clinton-vanzarzoliana-chhakchhuan-to-inspector-of-excise-narcotics.pdf"
ministry: "Excise and Narcotic Department, Mizoram"
title: "Promotion Order of SI Clinton Vanzarzoliana Chhakchhuan to Inspector of Excise & Narcotics"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "37b5809f21fb82d8"
---

<!-- page 1 -->

A-32013/106/2026-E&N

I/93319/2026

GOVERNMENT OF MIZORAM
EXCISE & NARCOTICS DEPARTMENT
MIZORAM SECRETARIAT, MINECO BUILDING-2, BASEMENT-II
….
NOTIFICATION
Aizawl, the 26th October, 2026.
No.A-32013/106/2026-E&N:
On the recommendation of the Mizoram Public
Service Commission vide their letter No.A.7/A/2023-MPSC(P) dt.21.10.2026 and in the
interest of public service, the Governor of Mizoram is pleased to promote Pu Clinton
Vanzarzoliana Chhakchhuak, Sub-Inspector of Excise & Narcotics to the post of
Inspector of Excise & Narcotics at Level 8 of the Pay Matrix plus all other allowances
as admissible from time to time with effect from 01.11.2026.
On his promotion, the Governor of Mizoram is further pleased to post
Pu Clinton Vanzarzoliana Chhakchhuak as Inspector of Excise & Narcotics, Office
of the Assistant Commissioner of Excise & Narcotics, Khawzawl District,
Khawzawl.

Sd/- C. LALRUAIA
Secretary to the Govt. of Mizoram,
Excise & Narcotics Department.
: Aizawl, the 26th October, 2026

Memo No.A-32013/106/2026-E&N
Copy to
1. P.S. to Minister, Excise & Narcotics Department.
2. Sr. P.P.S. to Chief Secretary, Government of Mizoram.
3. All Administrative Heads, Government of Mizoram.
4. All Heads of Department, Government of Mizoram.
5. Chief Controller of Accounts, Accounts & Treasuries, Mizoram.
6. Commissioner of Excise & Narcotics, Mizoram.
7. Controller, Printing & Stationery Department with 6(six) spare copies for
publication in the Mizoram Gazette.
8. Treasury Officer, Khawzawl District.
9. Officer concerned.
10. Guard File.

(ZOHMINGTHANGI FANAI)
Under Secretary to the Govt. of Mizoram
Excise & Narcotics Department
