---
doc_id: "f8f7f4b4f8d6adb5"
source_url: "https://dpar.mizoram.gov.in/uploads/attachments/826b94485559a46f061998539e643921/pages-123-ex-the-mizoram-vigilance-anti-corruption-bureau-department-group-b-post-recruitment-by-deputation-rules-2013-inspector-of-police-executive-and-ministerial.pdf"
ministry: "Anti Corruption Bureau, Mizoram"
title: "Inpsector of Police (Executive& Ministerial)"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "72ff2b93667cd12a"
---

<!-- page 1 -->

The Mizoram Gazette
EXTRA ORDINARY

Published by Authority
RNI No. 27009/1973 Postal Regn. No. NE-313(MZ) 2006-2008
VOL - XLIII Aizawl, Friday 28.3.2014 Chaitra 7, S.E. 1936,

Re. 1/- per page
Issue No. 116

NOT IFICAT ION
No. A.12018/83/2012-P&AR(GSW), the 13 th March, 2014.
In exercise of the powers conferred
by the proviso to Article 309 of the Constitution of India, the Governor of Mizoram is pleased to make the
following rules regulating the method of recruitment by deputation to the post(s) of the Inspector of Police
(Executive and Ministerial) under Vigilance Department (ACB), Government of Mizoram, namely :1.

Short title and
Commencement

(1)

These Rules may be called the Mizoram Vigilance (Anti Corruption
Bureau) Department (Group ‘B’ post) Recruitment (by deputation)
Rules, 2013.

(2)

They shall come into force from the date of their publication in the
Official Gazette.

2.

Application

These rules shall apply to the posts specified in Column 1 of the
Annexure-I annexed to these rules.

3.

Number of posts,
classification, pay band
and grade pay/pay scale

The number of the said post(s), their classification, Pay Band and Grade
Pay/pay scale attached thereto shall be as specified in columns 2 to
4 of the Annexure-I as aforesaid.

4.

Method of recruitment,
age limit,
qualifications, etc.

The method of recruitment to the said posts, age limit, qualification
and other matters relating thereto shall be as specified in columns 5
to 14 of the said Annexure-I aforesaid.
Provided that the upper age limit prescribed for direct recruitment
may be relaxed in the case of candidates belonging to the Scheduled
Castes/the Scheduled Tribes and other special categories of persons
in accordance with the orders issued by the Central Government or
the Government of Mizoram, as the case may be, from time to time.

5.

Disqualification

No person(a) who, has entered into or contracted a marriage with a person
having a spouse living; or

<!-- page 2 -->

Ex-116/2014

-2(b) who, having a spouse living, has entered into or contracted a
marriage with any other person, shall be eligible for appointment
to the said post(s);
Provided that the Governor may, if satisfied that such
marriage is permissible under the personal law applicable to
such person and to the other party to the marriage and that
there are other grounds for doing so, exempt any such person
from the operation of this rule.

6.

Training and Departmental
Examination.

Every Government servant recruited under these rules shall undergo
such training or pass such Departmental Examination(s) as may
be prescribed from time to time.

7.

Powers to transfer

Notwithstanding anything contained in these rules, the Governor of
Mizoram, in public interest, shall have power to transfer any officer(s)
so recruited under these rules to any other post or position which is
equivalent in rank or grade.

8.

Power to relax

Where the Governor is of the opinion that it is necessary or expedient
so to do, he may, by order and for reasons to be recorded in writing
and in consultation with the Mizoram Department of Personnel
& Administrative Reforms, relax any of the provisions of these rules
with respect to any class or category of persons.

9.

Reservation and other
concessions

Nothing in these rules shall affect any reservation relaxation of age
limit and other concessions required to be provided for the Scheduled
Castes/the Scheduled Tribes and other categories of persons in
accordance with the orders issued by the Central Government or
the Government of Mizoram from time to time in this regard.

By orders, etc.
Lalsangpuii,
Additional Secretary to the Govt.of Mizoram,
Department of Personnel & Administrative Reforms.

<!-- page 3 -->

-3-

Ex-116/2014

ANNEXURE - I
(See Rule 2, 3 & 4)
RECRUITMENT RULES FOR THE POST OF GROUP ‘B’ IN THE DEPARTMENT OF
VIGILANCE (ACB), GOVT. OF MIZORAM
Name of post

No. of post

Classification

1
Inspector of Police

2
8(eight) posts or as
sanctioned by
Government from
time to time
1(one) posts or as
sanctioned by
Government from
time to time

3
Mizoram Police
Personnel Group ‘B’
Executive (Gazetted)

Inspector
(Ministerial)

Pay Band and
Whether Selection post
Grade Pay/Pay Scale or Non-selection post
4
5
PB-2 ^ 9300-34800/Selection
+ Grade P ay
^ 4600/-

PB-2 ^ 9300-34800/Mizoram Police
+ Grade P ay
Personnel Group ‘B’
^ 4600/Executive (Gazetted &
Ministerial)

Whether age and educational Period of
qualifications prescribed for probation,
if any
direct recruits will apply in
the case of promotees

Whether benefit of added
years of service admissible
under Rule 30 of the CCS
(Pension) Rules, 1972
6

Age limit for
direct recruits

9

10

Not admissible

Not applicable

Not applicable

Not applicable

Not
applicable

Not admissible

Not applicable

Not applicable

Not applicable

Not
applicable

7

Educational and other
qualifications required
for direct recruits

Selection

8

Method of recruitment, whether by
direct recruitment or by promotion
or by deputation/transfer and
percentage of Post to be filled by
various methods
11
100% by deputation

In case of recruitment by
promotion/transfer/deputation,
grades from which promotion/
deputation/transfer to be made

If a DPC exist, what is its Circumstances in
which MPSC is to be
composition ?
consulted in making
recruitment.

12
Deputation from M izoram
Police personnel holding
analogous post in the State
Government with minimum
educational qualification of
HSSLC/Graduate. The period
of deputation shall n ot
ordinarily exceed 3 years initially

13
14
The Selection Committee Exempted from the
will consist of :purview of MPSC
1. Chairman-Director, ACB
2. Member Secretary - SP, ACB
3. Member - Representative
of Vigilance Department
4. Member - Representative
of DP&AR

100% by deputation

Deputation from officers of
Mizoram Police (Ministerial)
holding analogous post in the
State Government. The period
of deputation shall n ot
ordinarily exceed 3 years initially

The Selection Committee Exempted from the
will consist of :purview of MPSC
1. Chairman-Director, ACB
2. Member Secretary - SP, ACB
3. Member - Representative
of Vigilance Department
4. Member - Representative
of DP&AR

Published and Issued by Controller, Printing & Stationery Department, Government of Mizoram
Printed at the Mizoram Government Press, Aizawl. C/500
