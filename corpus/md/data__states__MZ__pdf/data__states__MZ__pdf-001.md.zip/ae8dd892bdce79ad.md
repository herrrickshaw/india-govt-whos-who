---
doc_id: "ae8dd892bdce79ad"
source_url: "https://ganc.mizoram.gov.in/uploads/attachments/2024/01/c3820feac46ddd717df2194a9a491905/publication-grants-notification-2023.pdf"
ministry: "Government Aizawl North College, Mizoram"
title: "Publication Grants Notification 2023"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7295f136eac7b0f4"
---

<!-- page 1 -->

Govt. Aizawl North College

ANLNORT

AZAWL MIZORAM

GANG

Ramhlun North

Azacil a

Aizaw1:Mizoram

AInrEMahotSaV

DAVELOPNENT NACUGH EDNCANON)

Website:http://www.ganc.mizoram.gov.in E-mail:govtanc@yahoo.com Phone:0389-2344069

No.A.60014/2/08 - GANC/ CIR/

Dated Aizawl, the 2nd February, 2023.

NOTIFICATIO N

Consequent upon Resolution of the Staff meeting held on 31s January,
2023, this is to notify that publication grants has been approved to all the Staffs with

the following conditions for implementation withimmediate effect
(a)

Upto Rs.10000/- or the actual publication fee (which ever is less) for
publishing Research Paper in UGC Core listed or Scopus Journals or WoS
Index Journals.

(b)

Upto Rs. 5000/- or actual publication fee (which ever is less) for publishing
Research Paper in Peer Review Journals.

(c)

Upto Rs. 2500/- or half of the publication fee (which ever is less) for Joint
papers, involving author(s) from other institution provided the first author in
the paper is from this Institution.

(d)

Seminar/ Conference/Workshop proceedings or published in Edited Volume
shall not be supported.

Sd/
(Prof. S. HAUKHANLIAN MATE)

Principal
Govt. Aizawl North College
Aizawl : Mizoram
Memo : No.A.60014/2/08 - GANC/CIR/ Dated Aizawl, the 2nd February, 2023.
Copy to :

1. Vice Principal for information.

2. Coordinator,IQACfor information.
3. All Staff for information.
4. Guard file.

Principal
Govt. Aizawl North College
Aizawl: Mizoram
