---
doc_id: "8056d9ab7a8ebdfb"
source_url: "https://fisheries.mizoram.gov.in/uploads/attachments/2024/07/10af158f52c605f86eb514cd76b8b340/eoi-instruction-to-applicants-fisheries.pdf"
ministry: "Fisheries Department, Mizoram"
title: "Click here to download"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4c9265e019e2f2cd"
---

<!-- page 1 -->

EXPRESSION OF INTEREST (EOI) for INSTALLATION OF COLD STORAGE
IN FISHERIES DEPARTMENT BUILDING AT NGAIZEL AIZAWL UNDER
SASCE 2020-2021
A. INSTRUCTION TO APPLICANTS
1. The Cold Storage units is to be installed at the Fisheries Department,
Government of Mizoram, building at Ngaizel, Aizawl. The total amount
sanctioned for the project is Rs.34.922 lakhs wherein Rs. 33.18 lakhs is
earmarked for 2 ( two) Units of Cold Storage.
2. Interested firms are advised to inspect and examine the sites and its surroundings
and satisfy themselves before submitting their E.O.I, the accommodation they
may require and in general shall themselves obtain all necessary information as
to risks, contingencies and other circumstances which may influence or effect
their applications. Applicants shall be deemed to have full knowledge of the sites
whether he/she inspects it or not and no extra charge consequent on any
misunderstanding or otherwise shall be allowed.
3. Specific location of the sites may be obtained from the Director of Fisheries,
Mizoram, Aizawl. Applicant(s) may visit the sites at their own expense.
Interested firms/ companies after fully having acquainted themselves with the
sites will prepare and submit a detailed project report for the establishment of the
Cold Storage unit in line with requirements and general specifications of the
Department for a total estimated amount not exceeding Rs. 33.18 lakhs.
Drawing of proposed designs and specifications are to be included in the project
report.
4. Firms submitting E.O.I. must include in their estimate the cost for initial
operation and maintenance for a period of not less than 1(one) year for the Cold
storage which should include cost of installation of the unit, transportation,
handling or any other charges etc.
5. The Expression of Interest (E.O.I) is to be prepared and submitted in English
language only. E.O.I submitted in any other language other than English will be
out-rightly rejected.
6. No telephone/telefax/telegram/e-mail of the techno-commercial will be
accepted. The Authority will not be responsible for postal/ courier delays. The
Parties must ensure receipt of applicants well in time.
7. If the date of submission and opening of application happens to be unforeseen
holiday, the same will be postponed to the next working day without any further
intimation.

<!-- page 2 -->

8. Canvassing whether directly or indirectly, in connection with applicant(s) is
strictly prohibited and the application(s) submitted by the firms/contractors who
resort to canvassing will be summarily rejected.
9. The application documents, Terms and Conditions of the Expression of Interest
(EOI) may be obtained from the Directorate of Fisheries, Government of
Mizoram, MINECO, Aizawl on all working days during Office hours and the
same
may
be
downloaded
from
the
Department
website
www.fisheries.mizoram.gov.in.
10. Interest firms/companies desiring to have detailed discussion about the design
and requirements of the project may do so at the time of collecting the application
documents/firms or earlier as per their convenience but well before opening of
E.O.I during office hours. Enquiry over the phone and through e-mail will not be
entertained.
11. Interested Firms. /Company/ Agency must submit Form-I and Form-II in
separate envelope and the two envelopes containing Form I and II respectively
must be placed in one large sealed envelope superscribed as “Expression of
Interest for Installation of Cold Storage in Fisheries Department Building at
Ngaizel, Aizawl” addressed to the Director, Fisheries Department, Government
of Mizoram MINECO, Aizawl.
Whereas form-I (EOI) includes Technical Specifications, DPR, GST
provisional ID, Acceptance letter of terms and conditions. Company/ Firms
registration details. Form -II includes Bill of quantities, annual maintenance cost
along with Earnest money deposit in the form of Bank Draft/ Banker’s Cheque.
B. GENERAL TERMS AND CONDITIONS OF THE EXPRESSION OF
INTEREST
1. The competent authority on behalf of the Department of Fisheries reserves to
himself the right of accepting or modifying the whole or any part of the
application proposals from any of the applicants.
2. The Expression of Interests (EOI) submitted by different firms will be
scrutinized for eligibility based on design and technical aspects of the proposal
after such firms have cleared the eligibility / qualification criteria laid down by
the Department.
3. The authorized person representing the applicant/firm who would sign on the
E.O.I documents and also participate in the opening of the E.O.I shall attach a
copy of the authorization letter along with the E.O.I schedule from the
appropriate authority of the firm as per By-Laws of the firm/company.

<!-- page 3 -->

4. Firms/companies will not be entitled to claim any compensation, charges and
expenses for the preparation of the project proposal or any other expenditure
incurred through or in connection with the submission of the E.O\. E.O.I
schedule shall be rejected if at any stage of the process it comes to the notice of
the Department that any applicant is involved in any fraudulent practice or
misinterpretation of the facts or tries to influence the selection process or indulge
in any corrupt activities with other firms. EMD will also be forfeited for such
defaulting firms.
5. In the event that any dispute or differences arises between two or more bidding
firms, the Department will have no involvement whatsoever. However, in case
of differences or dispute by a firm or firms against the Department, the matter
maybe settled through mutual and amicable discussions. Only if such differences
cannot be resolved through dialogue, the matter may then be resolved through
the court of law of the State of Mizoram jurisdiction only.
6. Interested firms/companies/Agency should have cleared all taxes and this must
be supported by GST Provisional ID.
7. From among the EOIs received, selection will be made by the Government
taking into account all their suitability, bid amount, expertise, experience, etc.
The representatives from the qualified firms will be invited to deliver powerpoint
presentations (not more than 10 mins.) on their respective project proposal.
8. Based on the combined assessment of the project proposal of the qualified firms
and the PowerPoint presentations, the Government/Board reserves exclusive
right and authority to finalize and select the successful firm to take up the project.
9. Firms/Companies must submit “Acceptance Letter of the Terms and Condition”
at the time of submission of Expression of Interest.
10. Any overwriting in the submitted documents should be initialled clearly by the
applicants.
C. ELIGIBILITY / QUALIFICATION CRITERIA
1. Firms having experience in installation and operation of Cold Storage for of cold
storage units in Mizoram or other North Eastern States will be given priority.
2. Firms offering warranty on machinery and maintenance services of more than 1
(one) year will be given preference which however must be clearly mentioned in
their documents.

<!-- page 4 -->

3. Firms fulfilling all the above criteria and with sound project proposal for design
and successful operation of the Cold Storage that meets the expectations of the
Department of Fisheries, Mizoram may be invited for power-point presentation
of the proposed project.
D. EARNEST MONEY DEPOSIT
1. An Earnest Money Deposit (EMD) of 2.5% out of the total project cost i.e
Rs.82,950.00 must be submitted along with the E.O.I documents in the form of
Bank Draft/ Banker’s Cheque drawn in favour of the Director of Fisheries,
Government of Mizoram from a scheduled bank only. Personal cheque will be
outrightly rejected.
2. E.O.I documents not accompanied by the Earnest Money Deposit (EMD) on the
day of opening of the EOI will not be considered.
3. EMD of the non-qualified firms/contractors will be released upon receipt of
application addressed to the Director of Fisheries, Mizoram once eligible firms
are finalized.

<!-- page 5 -->

E. REQUIREMENT AND MINIMUM TECHNICAL SPECIFICATIONS
The cold storage is to be installed in a Fisheries Departmental Building constructed for
the purpose at Ngaizel, Aizawl with the following specifications:
Sl
No
1

Particulars

Minimum Technical Specifications

Cold Storage chamber
Two separate chambers of Cold Storage
(2 separate chamber with should be constructed with separate
separate controlling units
controlling system with external dimension
(L x W x H) feet : 10’ L x10 ‘B x 9’H with
Overall Internal Volume of Cold Storage,
Cubic Feet: 900 (approx)

2

Ante Room

A common Anteroom to avoid direct
infiltration of warm ambient air with
dimension, :
(L x W x H) feet 8’Lx8’Bx9’H

3

Insulation material

PUF Thickness in Wall, Floor & Ceiling,
mm: 120mm (approx) for cold storage
chamber and 60mm (approx. for Anti room)

4

Door Opening Size

(L X W), mm: 1830 x 915 (approx.)

5
6

Storage Temperature Range, ºC:
+4 to -18 ºC (approx.)
Safety Certification
Various fire detection and prevention
systems and devices are commercially
available and must be included in the project
proposal. They include detectors for heat
and smoke; fixed water-sprinkling system,
inert gas snuffing system, smoke release
valves, flameproof barriers, fire brakes
formed by the separation of chambers, fire
extinguishers etc. All devices used shall
have been tested at low temperatures and
shown to be satisfactory. Similarly, safety
for workers against suffocation must be
ensured.
Certification from following Certification
Authority is necessary.
1. Factory Inspector.
2. Fire Fighting Inspector.
3. Electrical safety Inspector.
