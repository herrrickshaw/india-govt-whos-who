---
doc_id: "fcd99fb2823dffbd"
source_url: "https://dmr.mizoram.gov.in/uploads/attachments/2022/09/7bb09a2273e9de59b84abfd3a4c50cf9/order-revoke-of-covid-19-guidelines.PDF"
ministry: "Disaster management and Rehabilitation Department, Mizoram"
title: "https://dmr.mizoram.gov.in/uploads/attachments/2022/09/7bb09a2273e9de59b84abfd3a4c50cf9/order-revoke-of-covid-19-guidelines.PDF"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e637d16ba7d1c29f"
---

<!-- page 1 -->

No.B. L3,O2l I LOL l2O2O-DMR/VoI-VII
GOVERNMENT OF MIZORAM
DISASTER MANAGEMENT & REHABILITATION DEPARTMENT

***

Aizqwl, the 2Vh of Septem.ber, 2022

ORDER
Whereas, COVID-l9 situation in Mizoram has been reviewed by the
State Disaster Management 'Authority from time to time, and it has been
observed that COVID-19 cases have been declining over the last few months;

And whereas, NDMA has taken a decision that there may not be any
further need to invoke the provisions of the DM Act for COVID containment
measures after taking into consideration the overall improvement in the
situation and preparedness of the Government to deal with the pandemic,
vide their D.O. No. 40-3 l2O2O-DM-I (A) dated 22"a March, 2022; and hence
no further orders were issued after the expiry of the MHA Order No. 403l2O2O-DM-I (A) dated 25th February,2022.
Accordingly, it is felt necessary that the restrictions to contain the
spread of COVID-l9 may be re-visited in view of the declining trend of
COVID-l9 in the country and in order to further minimize the adverse
effects on lives and the economy;
Now therefore, the undersigned in her capacity as Chairman, State
Bxecutive Committee, and in exercise of the powers conferred under Section
22 (2) (h) & 24 (1) of the Disaster Management Act hereby revokes all orders

issued in respect of COVID-l9 guidelines with immediate effect and until
further orders. However, Health & Family Welfare Department's advisories
on COVID containment measures, including on the use of face mask and
hand hygiene, will continue to guide the overall State response to the

pandemic.

This issues with the approval of Chairman, State Disaster

Management Authority (SDMA)

.

Sd/- Dr. Renu Sharma
Chief Secretary, Mizoram & Chairman,
State Executive Committee,
State Disaster Management Authoriqr, Mizoram

WEAR MASK, MAINTAIN PHYSICAL DISTANCING OF 6 FEET, OBSERVE HAND HYGIENE.

<!-- page 2 -->

Memo No.B.tW2LllOll2g2GDMR/Vol-VII : Aizawl, the27u of September, 2922
Copy to :
1. Secretary to the Governor, Mizorarrr,
2. Secretary to the Chief Minister, Mizoram for information.

3. P.S. to Deputy Chief Minister/Speaker lMinisters/Ministers of

State/Deputy Speaker lYice-Chairman, SPB/Deputy Govt. Chief
Whip, Mizoram.
4. Home Secretary, Government of India, North Block, New Delhi110001.
5. sr. P.P.s. to chief secretary, Government of Mizoram.
6. All Administrative fleads of departments, Government of Mizoram.
7. Secretary, H&FW Department with a request to continue close
monitoring of COVID- 19 situation in Mizoram and to issue
instructionlguidelines as and when necessary.
8. Director General of Police, Mizoram.
9. Commissioner & Secretary, Mizoram Legislative Assembly.
10. Secretary of all Constitutional & Statutory Bodies, Mizoram.
1 1. All Deputy Commissioners, Mizoram.
12. A11 Superintendentspf Police, Mizoram.
13. Director, I&PR for wide publicity.
L4. A11 Chairpersons, LLTFi VLTF.
15. Controller, printing & Stationery with 5 (five) spare copies for
publication in the Mizoram Gazette.

(DANTEL SArLO)

Under Secretary to the Government of Mizoram
Disaster Management & Rehabilitation Department

WEAR MASK, MAINTAIN PHYSICAL DISTANCING OF 6 FEET, OBS.ERYE HAND HYGIENE.
