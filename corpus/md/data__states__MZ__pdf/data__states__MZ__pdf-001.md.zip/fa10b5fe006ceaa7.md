---
doc_id: "fa10b5fe006ceaa7"
source_url: "https://horticulture.mizoram.gov.in/uploads/attachments/2024/01/17905454d7c4e8c156f42698126d443b/tender-notice-for-supply-installation-of-green-house-green-house-spare-parts-accessories-under-midh-2023-2024.pdf"
ministry: "Horticulture Department, Mizoram"
title: "Click Here (hetah hian hmeh tur)"
date: ""
pages: 17
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "65d59eecd0a30379"
---

<!-- page 1 -->

GOVERNMENT OF MIZORAM
HORTICULTURE DEPARTMENT
MIZORAM: AIZAWL
No. B. 13014/1/2021-DTE(HORT-FRT)/39 ss: Dt. 10" January, 2024
; TENDER NOTICE
Horticulture Department, Govt. of Mizoram under the CSS Mission for
Integrated Development of Horticulture (MIDH) invites Open Tender proposals from
Manufacturer or its authorized dealer or agents for Supply and installation of Green
House and Green House Spare Parts/ Accessories under MIDH 2023-2024 and 2022-
2023 respectively for the State of Mizoram. No e-mail will be entertained for
submission of proposals in this regard. Last date for receipt of Application is 9"
February, 2024 upto 1:00 PM and the same will be opened on the same day at 1:30
PM at Committee Room, Directorate of Horticulture, Aizawl. The details and
application form is available at the website horticulture.mizoram.gov.in and can be
obtained from Fruit Section, Directorate of Horticulture, Aizawl during office hour on
all working days.
Sd/-C.H. LALMUANPUIA
Director of Horticulture
Mizoram, Aizawl
Memo No. B. 13014/1/2021-DTE(HORT-FRT)/39 —: Dt. 10" January, 2024
Copy to:-
1) P.S to Hon’ble Minister, Horticulture Department for information.
2) Senior PA to the Commissioner & Secretary to the Govt. of Mizoram,
Horticulture Department for information.
3) Director, I & PR, Mizoram, Aizawl for information with a request to
publish the Notice in 3 (three) local daily Newspaper namely — Vanglaini,
Aizawl Post, Zozam Times for 3 (three) consecutive days. 3 (three) spare
copies is hereby attached. He is requested to refer the bill to the Director of
Horticulture for payment after duly certified.
4) Project Officer (MIDH), Directorate of Horticulture with a request to
publish in Department Website.
5) Notice Board.
6) Guard File.
Gy ud] oif'24
(C,H. LALMUANPUIA)
Director of Horticulture
A-Mizoram, Aizawl

<!-- page 2 -->

TERMS AND CONDITIONS FOR SUPPLY AND INSTALLATION OF

GREEN HOUSE & SPARE PARTS ACCESSORIES UNDER MIDH

1. Tender should be submitted in two bid envelope system mentioning Bidder’s Name
and Address on the envelopes. The envelopes should be superscripted “Technical
Bid-I (A)” or “Technical Bid-I (B)” and “Financial Bid — I (A)” or “Financial Bid
— I (B)” as the case may be. The envelopes are to be put in a separate large sealed
envelope superscripted as below:

“Supply and Installation of Green House & Green house Spare Parts / Accessories
under MIDH”

2. The Sealed Quotation should be addressed to:

Director of Horticulture,
Mizoram, Aizawl

3. Bids are invited for Supply and Installation of Green House & Green house Spare
Parts/ Accessories, detailed Technical Specifications of which can be seen in
ANNEXURE -I for Supply and Installation of Green House and ANNEXURE-II
for Green house Spare Parts / Accessories ete.

4. For Green house spare parts/ accessories, the tendering firm/dealer/ agent etc. should
have well established local outlet in Aizawl open to public on all working days and
detail of which must be clearly indicated.

5. Total amount of fund earmarked for procurement of Green House and Green house
spare parts accessories is Rs. 67.99 lakh approximately i.e.,

i. Supply and Installation of Green House - Rs. 52.46 lakhs approx.
ii. Green House Spare Parts /Accessories — Rs. 15.53 lakhs approx.

This may vary depending on availability of fund under various schemes
implemented by Horticulture Department.

6. The agency/firm should preferably have atleast 3 (three) years experience in
manufacturing, supply and installation of Green Houses and its spare parts and
accessories.

7. The firms should be authorized distributor/dealer/agent of the manufacturing
company and this should be supported by photocopy of certificates duly attested.

8. The manufacturing company of the firm (s) should have valid BIS license and this
must be supported by relevant documents duly attested.

9. Authorized distributor/dealer/agent must have valid GST provisional ID which must
be supported by relevant document(s) and duly attested.

10. Proposal must be accompanied by manufacturing company brochure and drawing of
Green Houses and its specification.

<!-- page 3 -->

11. The “Technical Bid’ should be accompanied by Earnest Money / Bid Security of
2.5% of the tender amount and should be submitted by Bank Draft/Bankers Cheque
in favour of Director of Horticulture, Government of Mizoram, Aizawl failing which
the tender will not be entertained. The amount of the Earnest Money / Bid Security to
be submitted separately along with tender Form —I (A) and or tender Form —I (B) is
as-

Earnest Money / Bid Securi
1. Supply and Installation of Green House 1,31,150 .00
2. Supply of Green House Spare Parts / Accessories etc. 38,825.00
Release of the same may be done by the Department as per rule.

12. Successful tenderer if awarded contract/supply order should deposit performance
security of five per cent of the contract/supply order amount, exact amount of which
shall be mentioned in the contract/supply/work order. The performance security will
be liable to be forfeited if the successful tenderer withdraws/ deviate from the tender
in any respect.

13. The “Technical Bid’ should be accompanied by samples. Any Sample, Brochure,
drawing (s) submitted by the Tenderer cannot be claimed back even if not selected.
Sample (s) should bear the Name of Firm / Dealer/ Agent and Contact No. of the
Tenderer.

14. Only the “Financial Bid” of tenderer who are technically qualified will be opened.

15. Once the rate is fixed by the Government, application for revision of rate on account
of price escalation vice versa shall not be entertained as long as Govt. approved rate
remains valid.

16. Submission of proposal of Tender through e-mail/telefax will not be accepted. The
Authority will not be responsible for postal/courier delays. The parties must ensure
receipt of application well in time.

17. Rates of each item should be quoted separately inclusive of all taxes and charges both
in figure and in words. Any overwriting should be clearly initialed by the quotationer
(s) with date.

18. From among the Tender received, selection will be made by the Government or
competent Authority taking into account all their suitability, brand, specification,
experience etc. depending on the item, price, expertise, experience etc.

19. No advance payment will be made for the supply and installation of Green house etc.

<!-- page 4 -->

20. The application documents, Terms and Conditions of the Tender may be obtained
from Fruit Section, qn Floor, Directorate of Horticulture, Aizawl on all working days
during office hours.

21. Firms having past experience in working with Horticulture or Agriculture Department
of any State/Union should attach proof of documents duly attested.

22. Non compliances of any of the Tender Terms and Conditions will summarily results
in rejection of the application/ proposal.

23. Information regarding litigation, exertions and blacklisting, if any, shall be submitted
with details to enable evaluation by the Committee.

24. In the event that any dispute or differences arises between two or more firms or
agency, the Department will have no involvement whatsoever. However, in case of
differences or dispute by a firm or firms against the Department, the matter may be
settled through mutual and amicable discussions. Only if such differences cannot be
resolved through dialogue, the matter may then be resolved through the court of law
of the State of Mizoram jurisdiction only.

25. The undersigned reserves the right to accept or reject or cancel the tender fully or
partly including the lowest one without assigning any reason and also reserves the
right to distribute the works to more than one supplier, if considered necessary. The
Department does not bestow upon the successful Tender the right for supply of any
item (s).

26. Last date of submission of Tender is fixed on or before 9" February, 2024 Upto 1:00
pm and open on the same day at 1:30 Pm at the Committee Room, Directorate of
Horticulture.

27. The Tenderer(s) or his/her representative may be present at the time of opening of the
tender if he/she desires.

Gy Me rk
(C.H LALMUANPUIA)
Director of Horticulture
Mizoram, Aizawl

<!-- page 5 -->

Proforma for Submission for Supply and Installation of Green House and Green House
Spare Parts/Accessories under MIDH
To,
The Director of Horticulture
a &

Mission Director, MIDH

Mizoram, Aizawl
Subject:- Submission of proposal/application against Open Tender Notice for Supply

and installation of Green House and Green House Spare Parts/ Accessories

under MIDH_ vide No. B. 13014/1/2021-DTE(HORT-FRT)/39 Dt. 10"

January, 2024.

Sir/Madam,

I/We have carefully examined and read the Open Tender Notice for supply and
installation of green house and green house spare parts/ accessories etc. under MIDH 2023-
2024 and 2022-2023 respectively and all other documents attached regarding Open Tender
Notice vide No. B. 13014/1/2021-DTE(HORT-FRT)/39 Dt. 10" January, 2024. I/We
hereby submit our application/proposal for Supply and Installation of Green House and
Green House Spare Parts/Accessories under MIDH according to the terms and conditions
mentioned therein.

I/We certify that I/We have carefully read each and every terms and conditions
and Technical specification, composition etc. given in this Tender Documents and understood
the same, and I/We confirm our acceptance of the same.

I/We further certify that I/We have suppressed no fact in the
application/proposal which could debar me to participate into the Open Tender. If it is
revealed after opening of the application/proposal that any fact is suppressed by me, Tender
authority shall have the right to reject my application/ proposal.

I/We also hereby declare that I am not blacklisted by any Department/ Agency
of Central or State regarding quality compromise or any other reason connection with similar
work and there is no ongoing litigation with any Department/ Agency of Central/ State
Government as on closing date of Tender. If subsequently it is revealed after opening of
Tender concerned application/ proposal will be cancelled and other penalty to be decided by
the Tendering authority will be imposed.

Dated 3 cccsasecnnssemnemrers Yours faithfully,

PLACE: & nad csszeaenwawess aeons .
Sighatlte ....25sssccsess ssnwenedssseexeneowensrscminne
Name in full.........c.cceeeeeseeeeeeeeeeeeneeeene eens
Name Of Firm ..........ccseeceseeeeeeeeneeeeeeeeenees
AreSS ......cceeeeeeeeceseaeeeeeeeeeeeeeeeaneeeeeeeee

<!-- page 6 -->

“Technical Bid — I (A)”
FOR SUPPLY AND INSTALLATION OF GREEN HOUSE UNDER
MIDH 2023-2024
(Attested copies to be submitted wherever relevant)

1. Name of Applicant 2
2. Address of Applicant :
3. Contact No. i
4. Name of Firm/Agency :
5. Address of Firm/Agency 3
6. Name of Manufacturer ‘i :
7. Detail address of Manufacturer q
8. Website of Manufacturer 2
9. e-mail ID :
10. Local Agent/Office at Mizoram :

(for applicant from outside Mizoram)
11. Authorization/Dealership Certificate : Yes/No

From Manufacturing Company

(copy enclosed)
12. Valid BIS License No. : i) Yes/No

of Manufacturing Company (Enclosed) Hi) ID NOs wissccsssssmamnnsces canes
13. GST Provisional ID : i) Yes/No

(Enclosed) Li) TDN: sosesenssevceomaencnsweseer ernesuses
14. Manufacturing Company product: Yes/No

Brochure enclosed
15. Earnest Money Deposit in the form : Yes /No

of Demand Draft / Bankers’ cheque
16. Amount of Earnest Money Deposit (EMD) ERG. 0. semmennnoe ste sasiieaicas
17. Agree to supply all the required materials as per : Yes /No

<!-- page 7 -->

Technical Specifications issued by the Department
of Horticulture and enclosed in Annexure-I
18. Experience enclosed z Yes/No
19. Drawing of Green House and : Yes/No
Specification enclosed
20. Whether sample submitted $ Yes /No
(Sample checklist in Annexure-I)
Dated ssmsasevssssammsenasssene0 Sighatte ic: scccscccessancnnassssssaweencnts
Namie i fill sass cis csesvscssczsscawencsncas
Seal. sssnvescomsvmnennsssemmases seeaenememmanaven

<!-- page 8 -->

“Technical Bid- I (B)”
FOR GREEN HOUSE SPARE PARTS/ ACCESSORIES Etc. UNDER MIDH 2022-2023
(Attested copies to be submitted wherever relevant)
1. Name of Applicant :
2. Address of, Applicant :
3. Contact No. :
4. Name of Firm/Agency 3
5. Address of Firm/Agency :
6. Name of Manufacturer :
7. Detail address of Manufacturer :
8. Website of Manufacturer 3
9. e-mail ID ?
10. Location of Local Outlet :
(Detail address)
11. Authorization/Dealership Certificate : Yes/No
From Manufacturing Company
(copy enclosed)
12. GST Provisional ID ; i) Yes/No
(Enclosed) Ti) ID NO. woeee cece cece eeeseeeeeeeeeeeeeeeeee
13. Manufacturing Company product: Yes/No
Brochure enclosed
14. Earnest Money Deposit in the form : Yes /No
of Demand Draft / Bankers’ cheque
15. Amount of Earnest Money Deposit (EMD) SRS ce ceanemige ass sxnoeaties
16. Agree to supply all the required materials as per : Yes /No
Technical Specifications issued by the Department
of Horticulture and enclosed in Annexure-IT
17. Whether sample submitted : Yes /No
(Sample checklist in Annexure-I])
Dated i .sisscensascssscanames sis Signature .........cceccecceeeeeeeceeeeeeneeee
Noite itt fll cscssssusnsvrsnennmememessssaeenn
Seal «0s ssessnosssavmrtsssscainansvsaaasszaesace

<!-- page 9 -->

Annexure-I
PRODUCT SPECIFICATION DETAILS AND SUBMITTED SAMPLE
CHECKLIST FOR SUPPLY AND INSTALLATION OF GREEN HOUSE
UNDER MIDH 2023-2024
IL SUPPLY AND INSTALLATION OF GREEN HOUSE
No. : requirement ( or X)
[1 [Product [Natal Vonited Grenhouss |
2 [Se ftom 2imxsm
3 [Ridgebeake [800m
[4 [Gaterieghe [25m fomiooraee
Power ena
foundation work/ structure
ci eee
perimeter of 500 mm or more preferably of
single length without joint.
7 Structural design | The structural design need to be sound
enough to withstand wind speed minimum
150 Km/ hr and minimum load of 25 Kg/m’.
Structure Complete structure made of galvanized steel
tubular pipes or equivalent — section
conforming Indian standards having wall
thickness 2mm, structural member should be
joined with fasteners properly.
[eas 482 mm 0, 2mm
[Frases [Boom & top con 2mm OD, mm |
el a
& purlin
=
others
Foundations Insert GI pipes of minimum 42 mm OD or
more to have foundation depth of 48 cm or
more depending upon soil type and
prevailing wind condition, grouted with
cement concrete mixture of 1:2:4 using
telescopic insertion of column.
to |
strength and galvanized.
Two hinge doors of size 2 m width & 2.5 m
height double leaf made in plastic/ FRP
sheets mounted in suitable strong frame.
Cladding material | UV stabilized 200 micron transparent
plastics films conforming Indian Standards
IS 15827: 2009 multilayered and drip anti
fog, anti sulphur diffused clear and having

<!-- page 10 -->

|_|
minimum 85% level of light transmitted
11 | Fixing and | All end joints of plastic film need to be
cladding materials | fixed with two aluminum profiles with
suitable locking arrangement along with
curtain top. Wooden batons pr PVC
i grippers need not be used.
12 | Spring Insert Zigzag high carbon steel with spring action
. wire of 2-3 mm diameter must be inserted
to fix cladding materials into Aluminum
profile.
insect screen nylon, 2 m width along the sides.
Curtain wall/| 1m width of UV stabilized 200 micron
Apron transparent plastic films conforming Indian
standard (IS 15827 : 2009) multilayered,
anti-drip, anti-fog, anti-sulphur, diffused,
clear and having minimum 85% level of
light transmittance.
Testing All plastic materials used in the greenhouse
should be tested by the CIPET for quality
assurance and this should be supported by
relevant document.
[Afiersales services Tefirm shuld provide) |
Guarani date of installation
Dated ........ccceceeeeeeeeeee
SiGhalUIRe sccnsscassnsmacaetsansowest sesaumamnaaceasss
NAM ssneswsessnnenons eorommnmenan es oxsiemsinnees ensenes
SEAL. vemaesecoasmnmmas ed esinnsieineds 93500558835 5SRSANS
