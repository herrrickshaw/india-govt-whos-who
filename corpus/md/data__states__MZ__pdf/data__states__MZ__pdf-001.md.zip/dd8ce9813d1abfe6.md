---
doc_id: "dd8ce9813d1abfe6"
source_url: "https://gad.mizoram.gov.in/uploads/attachments/2026/09/812c0623a931fb9b07a92b349ca62a67/posts-648-office-order-on-designation-of-pi-lalrinchhani-ralte-deputy-secretary-gad-as-the-nodal-officer-for-administrative-data-harmonisation-in-respect-of-gad.pdf"
ministry: "General Administration Department, Mizoram"
title: "Office Order on designation of Pi Lalrinchhani Ralte, Deputy Secretary, GAD as the Nodal Officer for Administrative Data Harmonisation in respect of GAD"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e166a145ae05758d"
---

<!-- page 1 -->

M/95/2026-ESTT-GAD

I/78607/2026

No-M/95/2026-ESTT-GAD
GOVERNMENT OF MIZORAM
GENERAL ADMINISTRATION DEPARTMENT

Dated Aizawl, the 1st September, 2026

OFFICE ORDER
In pursuance of the Directorate, Economics & Statistics letter No.
B.14015/1(SLCC)/2025-DES(T) dt 12.08.2026, Pi Lalrinchhani Ralte, Deputy Secretary,
General Administration Department is hereby designated as the Nodal Officer for
Administrative Data Harmonisation in respect of General Administration Department with
immediate effect and until further orders.

Name
Lalrinchhani Ralte

Details of the officer is as under:
Designation
Phone Number & Email Address
Deputy Secretary,
GAD

9856861252
amtei.ralte18@gmail.com

Sd/-SUDHIR KUMAR
Principal Secretary to the Govt. of Mizoram
General Administration Department
Memo No. M/95/2026-ESTT-GAD
:
Copy to:
1. PPS to Principal Secretary, GAD.
2. Director, Economics & Statistics
3. Officer concerned.
4. Website Manager, GAD
5. Guard File.

Aizawl, the 1st September, 2026

(LALDINFELI)
Under Secretary to the Govt. of Mizoram
General Administration Department
