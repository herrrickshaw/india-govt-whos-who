---
doc_id: "9c01bdc15dd8fe1c"
source_url: "https://finance.mizoram.gov.in/uploads/attachments/2026/10/14e6ba8c8fbeebd48c95d364fa2b2c3c/posts-423-notification-designated-as-spio-dt-29102026.PDF"
ministry: "Finance Department, Mizoram"
title: "Notification - Designated as SPIO dt. 29.10.2026"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2c3265bd7b1b9b4c"
---

<!-- page 1 -->

F -23014

l/94427 /2026

/ 32 / ?O25-ESr A8-FD

-23 O LAI 321 2025- E STA B - F D
=

GOVERNMENT OF MIZORAM
FINANCE DEPARTMENT

Aizawl. the 29th october, 2026
NOTIFICATION

.

ln exercise of the power confened under Section 5(1) & (2) and
Section 19(1) of the Right to Information Act, 2005, the covernor of Mizoram is
please to designate the following officer under Finance Department (Economic
Affairs/ Debt Management Unit) as shown against her name to receive applications
and to provide information to persons requesting for information or appeals under
the said Act with immediate effect and until further orderst.
No
1.

Name of officer

Christina Lalmuanzuali

Designation

Designated as

Under Secretary

SPIO

Sd/. RAMCHUANA
Secretary to the Govt. of Mizoram,
Govt. of Mizoram
Memo F-23014I32/2025-ESTAB-FD
2026
Copy to:-

:

Aizawl, the 29th October.

1. Commissioner & Secretary to the Governor, Mizoram_

2. P.S. to the Chief Minister, Mizoram
3. P.S. to Speaker/ all Ministers/ Dy- Speaker/ Ministers of state

/Leader of
Opposition/ Dy. covt Chief Whip/ Advisers to Chief
Minister, Mizoram.
4. Sr. P.P.S. to the Chief Secretary, Government of Mizoram.
5. Chief Information Commissioner, Mizoram.
6. All Administrative Heads/ Heads of Departments, Government
of Mizoram.
7. Chief Controller of Accounts, Accounts & Treasuries.
8. Controller, printing & Stationeries, covt. of Mizoram wtth
2 (two) spare
copies for publication in the lvlizoram cazette.
9. Web Manager, Finance Department for uploading in tne website.
10. The Officer concerned.
Ll-. cuard File.

Digitaily signed by
Laldinfeli

Date: 29-i0-2026

12:iB:39
( LALDTNFELT )
Under Secretary to the covi. of Mizoram,
Finance Departn!ent (E)
