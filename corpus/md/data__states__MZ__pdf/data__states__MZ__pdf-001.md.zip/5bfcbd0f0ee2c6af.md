---
doc_id: "5bfcbd0f0ee2c6af"
source_url: "https://lesde.mizoram.gov.in/uploads/attachments/2023/02/084634af418643ccfeb1b5fe5c9d011b/posts-66-office-order-regarding-constitution-of-lesde-enforcement-squad-for-elimination-of-sups.pdf"
ministry: "Labour, Employment, Skill Development and Entrepreneurship Department, Mizoram"
title: "office order regarding constitution of LESDE Enforcement Squad for Elimination of SUPs"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "517625e424dcb618"
---

<!-- page 1 -->

oy as my, ,
Vise G2@
Amrit Mahotsav aga ayer
NO. F.13013/1/2023-DTE(LESDE)
GOVERNMENT OF MIZORAM
DIRECTORATE OF LABOUR, EMPLOYMENT, SKILL
DEVELOPMENT & ENTREPRENEURSHIP
AIZAWL: MIZORAM
Dated Aizawl the 28" February, 2023.
OFFICE ORDER

In pursuance of the GAD, Government of Mizoram Notification No.F.13013/1/2021-
GAD Dated 8.4.2022, the undersigned hereby declares Office of Directorate of Labour,
Employment, Skill Development & Entrepreneurship Department as Single Use Plastic
(SUPs) free premises.

No officers and staff or customer are allowed to bring in the banned SUP items as listed
below:
e Ear buds, balloons, candy and ice-cream.
© Plates, cups, glasses, forks, spoons, trays, knives, straw.
e Sweet boxes, invitation cards, cigarette packets. :
Plastic flags, PVC Banner less than 100 microns, Polystyrene for decoration.
e Plastics carry bags (excluding compostable plastic bearing valid CPCB’s
certification) less than 75 microns till December 2022 & 120 microns from January
2023.

The Enforcement Squad so constituted vide letter No.F.13013/1/2023-DTE(LESDE)
dated 28" February 2023 shall oversee the compliance in the Office premises to look after
the issue. :

YY
(ANGELA ZOTHANPUN)
rector,
Labour, Employment, Skill Development &
Entrepreneurship Department,
C+Aizawl, Mizoram
*
No. F.13013/1/2023-DTE(LESDE) Dated Aizawl the 28" February, 2023.
Copy to:-
1. Enforcement Squad for information and necessary action.
2. P.A of Director, LESDE department for information. ee
lel
irector,
Labour, Employment, Skill Development &
Entrepreneurship Department,
cAizawl, Mizoram
