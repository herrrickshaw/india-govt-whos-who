---
doc_id: "1ff11dff5ce80d7f"
source_url: "https://irrigation.mizoram.gov.in/uploads/attachments/2025/11/54d1fc238066ef314871ad3b0cee3983/appointment-order-of-5-udcs-under-iwrd.pdf"
ministry: "Irrigation & Water Resources Department, Mizoram"
title: "Appointment Order of 5 UDCs under I&WRD.pdf"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f07dfd755a90a19c"
---

<!-- page 1 -->

GOVERNMENT OF MIZORAM
IRRIGATION & WATER RESOURCES DEPARTMENT
Mizoram Secretariat, MINECO, Building No. 2, Basement – II, Room No. 806

No.A-12031/11/2025-IWRD

Dated Aizawl, the 11th November, 2025

OFFICE ORDER
In the interest of public service and on the recommendation of the
Mizoram Public Service Commission vide their letter No. Non-Technical/1/2025MPSC(PE)/7 dated 08.10.2025, the following 5 (five) persons are hereby appointed to
the post of Upper Division Clerk (UDC) under Irrigation & Water Resources
Department at Level-6 (₹ 35,400 - ₹ 78,800/-) of the Pay Matrix plus all other
allowances as admissible and sanctioned by the Government from time to time.
They are posted to the offices as shown against their names with effect from the date of
joining their respective place of posting as shown below :
Sl No

Name

Address
C-82, Holy Trinity
School, Republic
Vengthlang, Aizawl

Place of Posting
Khawzawl Sub – Division

Aizawl Division

1

Lalbiakdika
S/o R Israela

2

Chawngthu Lalrinhlua
S/o C Lalrintluanga

A-13, Saron Veng,
Aizawl

3

Randy Zonunsanga
S/o R Lalrengchhawni

B-4, Venglai, Lunglei Lunglei Division

4

V Lalchhanhima
S/o V Lalhlupuia

A-79, Electric Veng,
Aizawl

Aizawl Sub – Division

5

Lalrinmawia Hnialum
S/o H Lalfakzuala

New Siaha, Siaha

Champhai Division

They shall be on probation for a period of 2 (two) years from the date of
appointment which may be extended for good and sufficient reasons. They should join
their places of posting within 15 (fifteen) days from the date of issuance of this order.

Sd/- Er. LALROTHANGA
Secretary to the Govt. of Mizoram|
Irrigation & Water Resources Department

<!-- page 2 -->

Memo No. A-12031/11/2025-IWRD
Copy to :

:

Dated Aizawl, the 11th November, 2025

1. P.S to Hon’ble Minister, Irrigation & Water Resources Department.
2. P.S to Secretary, Irrigation & Water Resources Department.
3. Chief Controller of Accounts, Accounts & Treasuries, Aizawl, Mizoram.
4. Chief Engineer, Irrigation & Water Resources Department, for information.
5. Executive Engineer, Aizawl/Lunglei/Champhai Division, Irrigation & Water
Resources Department, for information and necessary action.
6. Sub – Divisional Officer, Aizawl/Khawzawl Sub – Division, Irrigation & Water
Resources Department, for information and necessary action.
7. Treasury Officer, Aizawl South/Lunglei/Champhai/Khawzawl, for information.
8. Persons concerned.
9. Guard File.

(VANLALZUALA CHHANGTE)
Under Secretary to the Govt. of Mizoram
Irrigation & Water Resources Department

Email : iwrd.sectt@gmail.com

Landline No. 0389-2334588

Website : irrigation.mizoram.gov.in
