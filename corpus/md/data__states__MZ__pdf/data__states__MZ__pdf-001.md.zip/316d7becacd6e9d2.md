---
doc_id: "316d7becacd6e9d2"
source_url: "https://home.mizoram.gov.in/uploads/attachments/3c3f35ea1c3af9c72f3bcc7b7e7e29ae/order-2842021-mpass-cum-temporary-ilp.pdf"
ministry: "Home Department, Mizoram"
title: "Order 28.4.2021 - mPASS-cum-Temporary ILP.pdf"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c80b3740a0e712a2"
---

<!-- page 1 -->

No. F.220 t2 198 12020-HM/COVID- I 9 (C)
GOVERNMENT OF MIZORAM

HOME DEPARTMENT
Aizawl, the 28th April, 2021

ORDER
In partial modification of this Department's order of even number date 10.03 .2021,
the undersigned is directed to state that in order to streamline the arrival of passengers at
Lengpui Airport, mPASS Flight and Temporary ILPs are hereby incorporated into a single
format with immediate effect and until further orders. Therefore, the following procedure
shall be followed for entry of persons by flight with immediate effect:

1. For indigenous persons of the State: They shall register themselves through mPASS
Flight on the mobile application mCOVID-19 or www.mcovidl9.mizoram.gov.in and
select the option, 'Yes' in the field, 'Indigenous person of Mizoram'. They shall be
allowed to proceed after receiving confirmation SMS and having a valid mPASS
Flight ID.

2. For ILP exempted categories of non indigenous persons of the State: They shall
register themselves through mPASS Flight on the mobile application mCOVID-I9 or
www.mcovidl9.mizoram.gov.in and select the option, 'No' in the field, 'Indigenous
person of Mizoram'. They shall further select the option, 'Yes' in the field, 'whether
ILP exempted or not'. The appropriate exemption category shall then be selected by
the applicants. They shall be allowed to proceed after receiving conf,rrmation SMS and
having a valid mPASS Flight ID.

3. For all other non indigenoas persons of the State: They shall register themselves
through mPASS Flight on the mobile application mCOVID-I9 or
www.mcovidl9.mizoram.gov.in and select the option, 'No' in the field, 'Indigenous
person or Mizoram'. They shall further select the option, 'No' in the field, 'whether
ILP exempted or not'. The sponsor's details and purpose of sponsorship shall then be
entered. Approval of Home Department shall be awaited after submission of the
registration. On receiving approved registrations, the incoming passengers are then
required to pay the specified ILP fees at the designated counter at Lengpui Airport.
They shall be allowed to proceed after payment of the specified ILP fees.
This is a temporary arrangement due to the COVID-I9 pandemic and the Deputy
Superintendent of Police, Security, Lengpui Airport is still authorized to issue Temporary
ILPs through the offline mode in order to avoid unnecessary inconvenience to the incoming
passengers.

It shall be ensured by the Police personnel on duty at Lengpui Airport that all persons
entering the State are having valid mPASS Flight IDs and that all non indigenous non ILP
exempted passengers obtain Temporary ILP either through mPASS Flight cum Temporary
Page 1 of 2

t

<!-- page 2 -->

ILP or through offline mode. It shall be further ensured that only mPASS Flights with
'Temporary ILP' marked in red are accepted as mPASS Flight cum Temporary ILP.
The validity of the Temporary ILPs shall be 7 days from the date of discharge from
Quarantine or 7 days from the discharge from Covid Care Centre in case of incoming
passengers who are tested COVID positive. In the case of incoming passengers on short term
stay not undergoing quarantine, the Temporary ILPs shall be valid from the date of arrival in
Mizoram.

All regular ILP issuing authorities are authorized to issue regular ILP against valid
mPASS Flight-cum-Temporary ILP.

All the questionnaire required by Health & Family Welfare Department from the
incoming passengers have been incorporated in the mPASS Flight. Hence, all necessary fileds
in the mPASS Flight have to be filled by each passenger.

Sd/- LALBIAKSANGI
Secretary to the Govt. of Mizoram.
Home Department

(C) :

Memo No. F.2201219812020-HM/COVID-19
Aizawl, the 28th April,zL2l.
Copy to:
Secretary to the Governor, Mizoram.
2. PS to Chief Minister, Mizoram.
3. PS to Deputy Chief Minister, Mizoram.
4. PS to Speaker / Ministers / Dy Speaker / Ministers of State / Gorrt. Dy. Chief Whip /
Vice-Chaiffnan, State Planning Board, Mizoram.
5. Sr. PPS to Chief Secretary, Government of Mizoram.
6. PS to Addl. Chief Secretary, Government of Mizoram.
7. All Administrative Heads of Department, Government of Mizoram.
8. Special Secretary, Health & Family Welfare Department for necessary in regard
to utilization of mPASS flight for collecting passenger information.
9. All Heads of Department, Government of Mizoram.
l0.Principal Consultant, Civil Aviation Wing, GAD, Government of Mizoram.
I 1. All Deputy Commissioners, Mizoram.
12.All District Superintendents of Police.
13.Director, Information and Publicity Department, Government of Mizoram for wide
publicity.
14.Chief Informatics Officer, Information and Communication Technology Department
for information and necessary action.
15.Deputy Superintendent of Police, Security, Lengpui Airport.
16. Guard file.

l.

GA)
Under Secretary to the Govt. of Mizoram,
Xt*lome Department
Page2 of 2
