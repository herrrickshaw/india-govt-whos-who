---
doc_id: "0c7f5bc874a2eadd"
source_url: "https://ghbc.edu.in/uploads/attachments/2023/10/9880ec74bed870c9a691a8b610921259/mzu-nep-2020-guidelines.pdf"
ministry: "Govt. Hrangbana College, Mizoram"
title: "Guidelines for Implementation of NEP 2020"
date: ""
pages: 30
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3ab37cf2b30282ba"
---

<!-- page 1 -->

Mizoram University
Aizawl 796 004
Mizoram, India

Guidelines for Implementation of NEP 2020:
Multiple Entry and Exit in Academic Programmes
offered in Mizoram University

Task Force Committee for Implementation of
National Education Policy 2020
in Mizoram University
November 2021

<!-- page 2 -->

Contents
Page
1 Introduction

1

2 Initiative for Implementation of NEP 2020

1

3 Academic Programmes

2

3.1 Undergraduate Programme

2

3.2 Master’s Programme

2

3.3 Ph.D Programme

3

4 Programme Structure

3

4.1 Course Categorization and Credit Distribution
4.1.1 Course
Categorization and
UG/Bachelor’s Programme

Credit

Distribution

3
for

4.1.2 Course Categorization and Credit Distribution for PG/Master’s
Programme

4

4.2 Ph.D. Programme

5

4.3 Description of Course

6

4.3.1 Disciplinary/Inter-disciplinary Major

6

4.3.2 Disciplinary/Inter-disciplinary Minor

7

4.3.3 Vocational Studies

8

4.3.4 Field Projects/Internship/Apprenticeship

8

4.3.5 Language Skill and Communication

8

4.3.6 Environmental Studies

8

4.3.7 Value-Based Course

8

4.3.8 Global Citizenship Education

9

4.3.9 Research Project

9

5 Multiple Entry and Exit Options

9

5.1 Certification of Qualification and Credit Requirement

9

5.2 Course and Credit Distribution for UG Programmes with
Multiple Entry and Exit Options

10

5.3 Course and Credit Distribution for PG Programmes with
Multiple Entry and Exit Options

16

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Option

<!-- page 3 -->

Page
6 Open Online Courses

18

7 Course Options

18

8 Departmental Coordinators

19

9 Evaluation Committee for Multiple Entry and Exit

19

Appendices
Appendix - I Guidelines for Vocational Studies under Multiple Entry
and Exit in Mizoram University

20

Appendix – II Provisions for Multiple Entry and Exit in Academic
Programmes offered in Mizoram University

22

Appendix – III Example of Syllabus Structure

24

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Option

<!-- page 4 -->

Mizoram University

Guidelines for Implementation of NEP 2020:
Multiple Entry and Exit in Academic Programmes
offered in Mizoram University
1

Introduction

The National Education Policy (NEP) 2020 seeks to reform the Higher
Education system by providing flexibility to students in terms of choice of subjects to
study and academic pathways.
The policy envisages broad based, multidisciplinary, holistic academic programmes. One very important recommendation of
the NEP 2020 is a creative combination of disciplines for study with multiple entry
and exit points. Thus, the curriculum will become flexible by allowing combinations
of subjects (for example Maths with Music, History with Painting etc.) and vocational
education will be integrated with mainstream education.
The NEP 2020 also states that there will be multiple entry and exit points in
the academic programmes offered at Higher Education Institutions (HEIs) with the
aim of removing rigid boundaries and create new possibilities for students to choose
and learn the subject(s) of their choice. This will also pave the way for students to
have seamless mobility within or across the HEIs through formal system of credit
recognition and transfer.

2

Initiative for Implementation of NEP 2020

In pursuant of the resolution of the 57th Meeting of Executive Council held on
9th July, 2021 and the resolution of 40th Meeting of the Academic Council of Mizoram
University held on 26th June, 2021, the Committee for Implementation of New
Education Policy 2020 was constituted (vide No. 16-4/MZU(ACAD/14 dated 6th
August, 2021). This Committee which met on 20th September, 2021 further resolved
to constitute the Task Force Committee for Implementation of NEP 2020 which will
focus on Implementation of Multiple Entry and Exit Guidelines in Post Graduate
(PG), Undergraduate (UG) and Professional Courses/Vocational Courses/Skill based
Education and Liberal Arts Education. The following are members of the Task Force
Committee:
Chairman:

Prof. Lalhmasai Chuaungo, Dept. of Education

Members:

Prof. Sarangadhar Baral, Dean, SEH
Prof. R.K. Ngurtinkhuma, Dean SEMIS
Prof. Lalrintluanga, Dean, SSS
Prof. U.K. Sahoo, Dean, SES&NRM
Prof. Senthil Kumar, Dean, SLS
Prof. Diwakar Tiwar, Dean, SPS
Prof. L. Lolit Kumar Singh, Dean, SET
Prof. Zaithanzauva Pachuau, Dean, SFAAFT
Dr. B. Lalremruata, Gen. Secretary, MIZUTA

Co-opted Members: Prof. Lalnundanga, Registrar
Prof. Vanlalchhawna, Finance Officer
Prof. Lalnuntluanga, Controller of Examinations
Member Secretary: Prof. Lalnilawma, Dept. of Extn Edn & Rural Dev’t.
Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

1

<!-- page 5 -->

Mizoram University

In consultation with the policy document on NEP 2020 (Ministry of Education)
and Guidelines for Multiple Entry and Exit in Academic Programmes offered in HEIs
(UGC), the Task Force Committee came up with this Guidelines for Implementation
of NEP 2020 in Mizoram University and the same is presented below:
3

Academic Programmes

In line with the NEP 2020, Mizoram University is committed to offer
programmes that envisage broad based, multi-disciplinary and holistic education at
various levels of UG and PG Programmes.
3.1

Undergraduate Programmes

The UG Programme will be of Three-Year (Bachelor’s Degree) or Four-Year
(Honours/Research) duration and the curriculum will be flexible by allowing creative
combinations of subjects where vocational education will be an integral part. The
students will have opportunity for multiple entry and exit with appropriate certification
viz. Undergraduate Certificate after one year (two semesters), Undergraduate
Diploma after two years (four semesters), Bachelor’s Degree after three years (six
semesters) and Bachelor’s Degree with Honours/Research after 4 years (eight
semesters) (Fig. 1). This will allow them to continue or leave a course as per their
convenience/passion.
Figure 1: Multiple Exit Options

1-Year
Undergraduate
Certificate

3.2

2-Year
Undergraduate
Diploma

3-Year
Bachelor's
Degree

4-Year
Bachelor's Degree
(Honours/Reserach)

Master’s Programmes

There will be flexibility in the Master’s Programme offered by Mizoram
University viz. a Two-Year Master’s Degree after Three-Year Bachelor’s Degree with
2nd Year devoted to research and a One-Year Master’s Degree after Four-Year
Bachelor’s with Honours/Research. There will also be provisions for Integrated FiveYear Bachelor’s/Master’s Programme depending on the capability of Academic
Department(s) (Fig. 2).
Figure 2: Master's Programme

2 Years
• 2 Year Master's
Degree with 2nd
Year devoted to
Research after 3
Year Bachelor's
Degree

1 Year

Integrated 5 Years

• 1 Year Master's
Degree after 4 Years
Bachelor's Programme
(Honours/Reseach)

• Integrated 5 Year
Bachelor's/Master's
Degree

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

2

<!-- page 6 -->

Mizoram University

There will be only one exit point for those who join the Two-Year Master’s
Programme. The students who exit after the first year will be awarded PostGraduate Diploma.
3.3

Ph.D Programme

Knowledge creation and research are critical in growing and sustaining a
large and vibrant economy, uplifting society, and continuously inspiring a nation to
achieve even greater height. To achieve a greater height in various fields of
research, Mizoram University will continue to offer Ph.D Programme where more of
quality Inter-disciplinary Research will be encouraged.
4

Programme Structure

The educational approaches that integrate the humanities and arts with
Science, Technology, Engineering and Mathematics (STEM) have consistently
showed positive learning outcomes, including increased creativity and
innovation, critical thinking and higher-order thinking capacities, problem-solving
abilities, teamwork, communication skills, more in-depth learning and mastery of
curricula across fields, increases in social and moral awareness, etc., besides
general engagement and enjoyment of learning.
4.1

Course Categorization and Credit Distribution

In ensuring a holistic and multi-disciplinary education, the UG and PG
Programme structure of Mizoram University will be imaginative and flexible in nature
with creative combinations of credit-based courses categorized as follows.
4.1.1 Course Categorization and Credit Distribution for UG/Bachelor’s
Programme
The different category of courses to be offered in the UG/Bachelor’s
Programme of Mizoram University shall comprise of the following:
Disciplinary
Inter-disciplinary
Major

Disciplinary
Inter-disciplinary
Minor

Vocational
Studies

Field Projects
Internship
Apprenticeship

Language Skill and
Communication

Environmental
Studies

Value-Based
Course

Global Citizenship
Education

Research
Project

These courses will be offered across the semesters with total of 20 credits in
each semester. Details of credit distribution across different category of courses for
UG/Bachelor’s Progamme are shown in Tables 1.
Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

3

<!-- page 7 -->

Mizoram University

Table 1: Course Categorization and Credit Distribution for UG/Bachelor's
Programme
Sl No
1
2
3
4
5
6
7
8
9

Course Category
Disciplinary/Inter-disciplinary Major (DMj/IMj)
Disciplinary/Inter-disciplinary Minor (DMn/IMn)
Vocational Studies (VS)
Field Projects (in areas of community
engagement and service)/ Internship/
Apprenticeship (FP/Ints/Apts)
Language Skill and Communication (LSC)
Environmental Studies (EVS)
Value-Based Course
Global Citizenship Education (GCE)
Research Project (RP)
Total

4.1.2 Course Categorization
Programme

and

Credit

Credit Distribution
UGC
Proposed for
Guidelines
MZU
40-56
56
20-28
24
12 - 18
18
24-32

28
4
3
6
3
18
160

Distribution

for

PG/Master’s

In line with the NEP 2020, Mizoram University shall offer two types of Mater’s
Programmes – A Two-Year Master’s Programme for students joining with ThreeYear Bachelor’s Degree and a One-Year Master’s Programme for those who
completed Four -Year Bachelor’s Degree with Honours/Research.
The Two-Year Master’s Programme shall have four categories of courses
which include the following:

Disciplinary
Inter-disciplinary
Major

Disciplinary
Inter-disciplinary
Minor

Field Projects

Dissertation

These courses will be offered across four semesters. Each semester shall be
of 20 credits with a total of 80 credits. Details of credit distribution across different
category of courses for Two-Year Master’s Programme are presented in Table 2.

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

4

<!-- page 8 -->

Mizoram University

Table 2: Course Category and Credit Distribution for 2-Year PG/ Master's
Programme
Sl.
No.
1
3

Course Category
Disciplinary/Inter-disciplinary Major (DMj/IMj)
Disciplinary/Inter-disciplinary Minor (DMn/IMn)

5

Field Projects (in areas of community engagement and
service)/ Internship/Apprenticeship (FP/Ints/Apts)

6

Dissertation

Credit
Distribution
34
12
16
18
80

Total

The One-Year PG/Master’s Programme on the other hand shall have three
categories of courses as below:

Disciplinary
Inter-disciplinary
Major

Disciplinary
Inter-disciplinary
Minor

Dissertation

These courses shall be distributed across two semesters with 20 credits each
and the requirement for a One-Year PG/Master’s Degree shall be of 40 credits.
Credit distribution of each category of courses under a One-Year PG/Master’s
Programme may be seen in Table 3.
Table 3: Course Category and Credit Distribution for 1-Year
PG/Master's Programme
Sl.
No.
1
2
3
3

4.2

Course Category
Disciplinary/Interdisciplinary Major (DMj/IMj)
Disciplinary Minor (DMn)
Field Project/Internship/Apprenticeship
Dissertation
Total

Credit
Distribution
12
4
6
18
40

Ph.D Programme

Entry into Ph.D Programme under Mizoram University shall be opened to
candidates with:
i) A Two-Year Master’s Degree obtained after completing a Three-Year
Bachelor’s Programme
ii) A One-Year Master’s Degree obtained after completing a Four-Year
Bachelor’s Programme with Research
Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

5

<!-- page 9 -->

Mizoram University

iii) A Four-Year Bachelor’s Degree (Honours/Research)
iv) An Integrated Five-Year Bachelor’s/Master’s Degree
Candidates with the above minimum qualifications meeting entrance
requirements stipulated by Mizoram University shall be selected for admission into
the Ph.D Programme on merit basis.
In line with the proposal of NEP 2020 (15.9), the following shall be
incorporated in the Ph.D Programme:
i) All fresh Ph.D. entrants, irrespective of discipline, will be required to take
credit-based courses in teaching/education/pedagogy/writing related to
their chosen Ph.D subject during their doctoral training period.
ii) Some academic departments (for e.g., Education, English) in the
University may be entrusted to develop credit-based courses in
teaching/education/pedagogy/writing for Ph.D. course work. Concerned
departments may offer the course/s in a blended mode in which theory
part may be imparted in an online mode whereas practical part may be
done in an offline mode. Ph.D. students may also offer Massive Open
Online Courses (MOOCs) or other recognized distance or online courses
related to teaching/education/pedagogy/writing.
iii) Exposure to pedagogical practices, designing curriculum, credible
evaluation systems, communication, and so on will be ensured since many
research scholars will go on to become faculty or public
representatives/communicators of their chosen disciplines.
iv) Ph.D students will also have a minimum number of hours of actual
teaching experience gathered through teaching assistantships and other
means.
v) Ph.D. programmes at Mizoram University will be re-oriented for this
purpose.
4.3

Description of Courses

In order to have better understanding of different category of courses offered
by Mizoram University under the NEP 2020, description of courses are presented
below:
4.3.1 Disciplinary/Inter-disciplinary Major
Disciplinary Major (DMj) are the core courses which require in-depth
knowledge in the subject and these are offered/floated by the parent department for
a particular degree.
Examples:
Suppose the Major in Graduate Program is Physics, the DMj courses will be
Basic Physics, Electricity and Magnetism, Statistical Mechanics etc.

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

6

<!-- page 10 -->

Mizoram University

Suppose the Major in Graduate Program is Chemistry, the DMj courses will
be Physical Chemistry, Inorganic Chemistry, Analytical Chemistry etc.
Inter-disciplinary Major (IMj) course on the other hand are courses which
provide greater and required knowledge to complement the major chosen for a
degree. The IMj courses are offered/floated by other relevant departments. The
relevant courses of other departments will be identified by concerned Board of
Studies (BoS) with more flexibility and options for students to fulfil the requirements
of the programme.
Examples:
Suppose the Major in Graduation Program is Physics, the IMj courses will be
Physical Chemistry, Inorganic Chemistry, Mathematics etc.
Suppose the Major in Graduation Program is Chemistry, the IMj courses will
be Electricity and Magnetism, Statistical Mechanics, Mathematics, Zoology, Botany
etc.
A total of 56 credits shall be allotted to the DMj/IMj courses and spread across
the different semesters. Each Major course shall be of 3 credits. Details of course
and credit distribution may be seen in Table 5.
4.3.2 Disciplinary/Inter-disciplinary Minor
A minor course provides additional breadth and depth to the main program. It
is secondary academic discipline which supplements and complements the major of
the program. It may be taken within the same department or from other
departments. The interdisciplinary minors may be of the choice of students which
may be opted from other departments of their interest. The departments may
offer/float the Minor courses available for the students of main discipline as well as
students of other disciplines. Each minor is to be intact and provide a flavour of that
course.
Example:
For Physics Department, Students may select Minor courses within or other
departments of their choice.
Minor Courses of Disciplinary
Physics Department may offer/float the minor courses such as Essence of
Astrophysics, Basic of Radiation Physics, Computational Physics etc.
Minor Courses for Interdisciplinary
Chemistry: Applications of Atomic Spectroscopy; Forensic Science; Food
Chemistry etc.
Mathematics: Matlab: Uses and Applications; C Programming for Beginners,
Applied Calculus etc.

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

7

<!-- page 11 -->

Mizoram University

The total credits allotted for DMn/IMn shall be 24 credits. Each DMn/IMn
course will be of 2 credits. Details of course and credit distribution may be seen
Table 5.
4.3.3 Vocational Studies
Vocational Studies (VS) shall form an integral part of the academic
programmes of Mizoram University. A total of 18 credits is allotted to VS and shall
spread across the second, third, fifth, sixth and eighth semesters (see Table 5).
Guidelines for implementation of VS in Mizoram University is presented in Annexure
- I.
4.3.4 Field Projects/Internship/Apprenticeship
The students, as a part of their course, will be given opportunities to enroll for
Field Project(s) in the areas of community engagement and service, Internship, and
Apprenticeship (FP/Ints/Apts). This component of the programmes is allotted 28
credits and the courses will spread across all the semesters (see Table 5).
4.3.5 Language Skill and Communication
Courses on Language Skill and Communication (LSC) also forms a part of the
academic programmes. Under this category, English Communication and MIL
Communication papers shall be offered. These papers shall focus on development
and enhancement of soft skills such as communication, discussion and debate
emphasized by NEP 2020 (11.1). A total of 4 credits shall be allotted to LSC and a
paper of 2 credits each shall be offered in the second and third semesters (see Table
5).
4.3.6 Environmental Studies
Course on Environmental Studies (EVS) carrying 3 credits shall also be
offered. This paper will include areas such as climate change, pollution, waste
management, sanitation, conservation of biological diversity, management of
biological resources and biodiversity, forest and wildlife conservation, and
sustainable development and living as suggested by NEP 2020 (11.8). The EVS
paper of 3 credits shall be offered in first semester (see Table 5).
4.3.7 Value-Based Course
Value-Based Course (VBC) shall also be included in the academic
programmes with a total of 6 credits. VBC of 3 credits each shall be offered in the
fourth and sixth semesters (see Table 5).
These courses will aim at the development of humanistic, ethical,
Constitutional, and universal human values of truth (satya), righteous conduct
(dharma), peace (shanti), love (prem), nonviolence (ahimsa), scientific temper,
citizenship values, and also life-skills as suggested by NEP 2020 (11.8).
A pool of courses shall be prepared by the University which may include
courses like Ethics and Culture/ Ethics and Self Awareness; Co-curricular;
Sports/NCC/NSS; Health and Wellness; Social and Emotional Learning; Innovation
and Entrepreneurship; IT Skills, Data Analysis and Mathematics; Science and
Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

8

<!-- page 12 -->

Mizoram University

Society, etc., out of which three courses could be selected which shall be on offer to
the students.
4.3.8 Global Citizenship Education
As the world is becoming increasingly interconnected, Global Citizenship Education
(GCED), a response to contemporary global challenges, will also be provided to
empower learners to become aware of and understand global issues and to become
active promoters of more peaceful, tolerant, inclusive, secure, and sustainable
societies (NEP, 2020, 11.8). To fulfill this vision of NEP 2020, Mizoram University
shall offer a 3 credits GCE course in the fifth semester (see Table 5).
4.3.9 Research Project
Research Project (RP) is earmarked for students taking a 4-Year Bachelor’s
degree with Honours/Research. A total of 18 credits shall be allotted for RP. The
students are expected to complete 8 credits of the RP works in the seventh semester
- writing of project/research proposal, review of related literature or studies and
collection of the required data. The remaining 10 credits of RP works is earmarked
for eighth semester where the students shall complete writing the research project
report and submit the final copy to the concerned authority at least one week before
commencement of end semester examination (see Table 5).
5

Multiple Entry and Exit Options

UGC Guidelines for Multiple Entry and Exit (MEE) in Academic Programmes
offered in HEIs (July, 2021) clearly stipulates series of academic levels with options
for multiple entry and exits options. Detailed provisions for MEE in Mizoram
University may be seen in Annexure – II.
5.1

Certification of Qualification and Credit Requirement

Certification of academic qualifications will be categorized in terms of
certificate, diploma and degree which are organized in a series of academic levels in
ascending order from level 5 to level 10. Each level of academic qualification has
certain credit requirement and these are presented below (Table 4):
Table 4: Certification of Qualification and Credit Requirement
Levels

Qualification

Level 5
Level 6
Level 7

Undergraduate Certificate (1 Year or 2 Semesters)
Undergraduate Diploma (2 Years or 4 Semesters)
Bachelor’s Degree (3 Years or 6 Semesters)
Bachelor’s Degree with Honours/Research
(4 Years or 8 Semesters)
Post-Graduate Diploma (For those who exit after
completion of 1 Year or 2 Semesters of 2-Year Master’s
degree programme)
Master’s Degree (2 Years or 4 Semesters after a 3-Year
Bachelor’s degree)
Master’s Degree (1 Year or 2 Semesters after a 4-Year
Bachelor’s Degree with Honours/Research)

Level 8
Level 8
Level 9
Level 9
Level 10

Doctoral Degree

Credit
Requirement
36 – 40
72 – 80
108 – 120
144 – 160
36 – 40
72 – 80
36 – 40
Minimum prescribed
credits for course

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

9

<!-- page 13 -->

Mizoram University

work and a thesis
with published work
Source: UGC Guidelines for Multiple Entry and Exit in Academic Programmes offered in Higher
Education Institutions (July, 2021)

5.2

Course and Credit Distribution for UG Programmes with Multiple Entry
and Exit Options

Course and credit distribution for UG/Bachelor’s Degree Programme of
Mizoram University with Multiple Entry and Exit options is presented in Table 5.

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

10

<!-- page 14 -->

11

Mizoram University

Table 5: Course and Credit Distribution for UG/Bachelor's Degree Programme with Multiple Entry and Exit Options
Disciplinary/
Inter-disciplinary
Major

Semester
DMj

IMj

Disciplinary/
Inter-disciplinary
Minor
DMn

Vocational
Studies

FP/Ints/
Apts

LSC/EVS/
VBC/CGE

RP

Total
Credit

-

FP/Ints/
Apts (4)

EVS (3)

-

20

FP/Ints/
Apts (3)

LSC (2)

-

20

IMn

IMj - 1 (3)

I

DMj - 1 (3)

Choose one from pool of
DMj Courses of other
Disciplines

IMj - 2 (3)

IMn - 1 (2)
DMn -1 (2)

Choose one from pool of
DMj Courses of other
Disciplines

Choose one from pool
of DMn Courses of
other Disciplines

IMj - 3 (3)

II

DMj - 2 (3)

Choose one from pool of
DMj Courses of other
Disciplines

IMj - 4 (3)
Choose one from pool of
DMj Courses of other
Disciplines

DMj
DMn
VS
LSC
VBC
RP

VS - 1 (4)
DMn -2 (2)

-

Choose from a
pool of VS
Courses

Exit option with Undergraduate Certificate after the first year or two semesters with the completion of courses equivalent to 40 credits
along with entry option to third semester after exit
=
Disciplinary Major
IMj
=
Inter-disciplinary Major
=
Disciplinary Minor
IMn
=
Inter-disciplinary Minor
=
Vocational Studies
FP/Ints/Apts =
Field Project/Internship/Apprenticeship
=
Language Skill and Communication EVS
=
Environmental Studies
=
Value-Based Course
GCE
=
Global Citizenship Education
=
Research Project
st

nd

Note: DMj – 1 (3) means the 1 Disciplinary Major course with 3 credit while DMj – 2 (3) means 2 Disciplinary Major course with 3 credits and so on.

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

<!-- page 15 -->

12

Mizoram University

Table 5: Course and Credit Distribution for UG/Bachelor's Degree Programme with Multiple Entry and Exit Options (Contd…)
Disciplinary/
Inter-disciplinary
Major

Semester
DMj

IMj

Disciplinary/
Inter-disciplinary
Minor
DMn

Vocational
Studies

FP/Ints/
Apts

LSC/EVS/
VBC/CGE

RP

Total
Credit

FP/Ints/
Apts (3)

LSC (2)

-

20

FP/Ints/Apts
(4)

VBC (3)

-

20

IMn

IMj - 5 (3)

III

DMj - 3 (3)

Choose one from pool of
DMj Courses of other
Disciplines

IMj - 6 (3)

VS - 2 (4)
DMn -3 (2)

-

Choose one from pool of
DMj Courses of other
Disciplines

Choose from a
pool of VS
Courses

IMj - 7 (3)

IV

DMj - 4 (3)

Choose one from pool of
DMj Courses of other
Disciplines

IMj - 8 (3)
Choose one from pool of
DMj Courses of other
Disciplines

DMj
DMn
VS
LSC
VBC
RP

=
=
=
=
=
=

IMn - 2 (2)
DMn -4 (2)

Choose one from pool
of DMn Courses of
other Disciplines

-

Exit option with Undergraduate Diploma after two years or four semesters with the completion of courses equivalent to 80 credits
along with entry option to fifth semester after exit
Disciplinary Major
IMj
=
Inter-disciplinary Major
Disciplinary Minor
IMn
=
Inter-disciplinary Minor
Vocational Studies
FP/Ints/Apts =
Field Project/Internship/Apprenticeship
Language Skill and Communication EVS
=
Environmental Studies
Value-Based Course
GCE
=
Global Citizenship Education
Research Project

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

<!-- page 16 -->

13

Mizoram University

Table 5: Course and Credit Distribution for UG/Bachelor's Degree Programme with Multiple Entry and Exit Options (Contd…)

Semester

Disciplinary/
Inter-disciplinary
Major
DMj
DMj - 5 (3)

V

Disciplinary/
Inter-disciplinary
Minor

IMj
-

DMn
DMn -5 (2)

DMj - 6 (3)
DMj - 7 (3)
VI

DMj - 8 (3)

DMn -6 (2)

Vocational
Studies

FP/Ints/
Apts

LSC/EVS/
VBC/GCE

RP

Total
Credit

FP/Ints/
Apts (3)

GCE (3)

-

20

FP/Ints/
Apts (4)

VBC (3)

-

20

IMn
IMn - 3 (2)

VS - 3 (4)

Choose one from pool
of DMn Courses of
other Disciplines

Choose from a
pool of VS
Courses

IMn - 4 (2)

VS - 4 (3)

Choose one from pool
of DMn Courses of
other Disciplines

Choose from a
pool of VS
Courses

Exit option with Bachelor’s Degree (Bachelor of Arts/Science/Commerce etc.) after three years or six semesters with the completion
of courses equivalent to 120 credits. Entry option to the fourth year or seventh semester for those students meeting
a minimum CGPA of 7.5 in Bachelor’s Degree examination
DMj
DMn
VS
LSC
VBC
RP

=
=
=
=
=
=

Disciplinary Major
IMj
=
Disciplinary Minor
IMn
=
Vocational Studies
FP/Ints/Apts =
Language Skill and Communication EVS
=
Value-Based Course
GCE
=
Research Project

Inter-disciplinary Major
Inter-disciplinary Minor
Field Project/Internship/Apprenticeship
Environmental Studies
Global Citizenship Education

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

<!-- page 17 -->

14

Mizoram University

Table 5: Course and Credit Distribution for UG/Bachelor's Degree Programme with Multiple Entry and Exit Options (Contd…)
Disciplinary/
Inter-disciplinary
Major

Semester
DMj

Disciplinary/
Inter-disciplinary
Minor

IMj

DMn

Vocational
Studies

FP/Ints/
Apts

LSC/EVS/
VBC/CGE

RP

Total
Credit

-

FP/Ints/
Apts (4)

-

8

20

FP/Ints/
Apts (3)

-

10

20

18

160

IMn
IMn - 5 (2)

VII

DMj - 9 (4)

-

DMn -7 (2)

Choose one from pool
of DMn Courses of
other Disciplines

VS - 5 (3)
VIII

DMj – 10 (4)

-

-

-

Choose from a
pool of VS
Courses

Award of Bachelor’s Degree (Honours/Research) or Bachelor of Arts/Science/Commerce (Hons) in Discipline with Research
after four years or eight semesters with the completion of courses equivalent to 160 credits
Total
DMj =
DMn =
VS
=
LSC =
VBC =
RP
=

56
24
Disciplinary Major
IMj
=
Disciplinary Minor
IMn
=
Vocational Studies
FP/Ints/Apts =
Language Skill and Communication EVS
=
Value-Based Course
GCE
=
Research Project

18
28
Inter-disciplinary Major
Inter-disciplinary Minor
Field Project/Internship/Apprenticeship
Environmental Studies
Global Citizenship Education

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

16

<!-- page 18 -->

Mizoram University

Explanation
1) Disciplinary/Inter-disciplinary Major:
DMj/IMj are pool of major courses to be chosen by students of the discipline
of study as well as students of other disciplines. One mandatory DMj course
shall be floated every semester by the disciplines of study for their own
students as well as students of other disciplines. The DMj courses offered by
a particular discipline shall be credited as DMj for students of same discipline
and at the same time it will be credited as IMj for students of other disciplines.
For example, if students of B.Sc. (Chemistry) take the DMj course offered by
Chemistry, it will be credited as DMj for Chemistry. If students of other
disciplines, say Environmental Science take the same DMj course of
Chemistry, it will be credited as IMj for Environmental Science.
All disciplinary/inter-disciplinary major and minor courses are of theory
papers.
2) Disciplinary/Inter-disciplinary Minor:
DMn/IMn are pool of minor courses to be chosen by students. The minor
courses to be offered in a particular semester will be floated by various
disciplines of study based on the departmental strength. Students from same
discipline of study or from other disciplines may choose any of the DMn/IMn
course(s) as per credit requirements.
For example, DMn course offered by a particular discipline of study say
Education, will be credited as DMn for students of Education while the same
DMn course will be credited as IMn if students from other discipline, say
Political Science take it.
3) Vocational Studies (VS):
There shall be pool of Vocational Studies which are multi-disciplinary in
nature. Students, regardless of their discipline of study, may take any VS
course of their choice from the pool of VS courses available as per credit
requirement.
4) Field Project/Internship/Apprenticeship:
This component of the programme is flexible in nature. The students may
choose activities either in the form of Field Project, Internship or
Apprenticeship as per requirement of concerned discipline of study.
For example, in semesters where 4 credits are allocated, it may be of
programmes or activities related to the discipline of study while it can be more
general in semesters where 3 credits are assigned.
For those disciplines having laboratory/practical/project may utilize this
component for the same. Each discipline of study shall have freedom to
utilize this component of FP/Ints/Apts as per requirement.

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

15

<!-- page 19 -->

Mizoram University

5) Global Citizenship Education (GCE):
It is desirable that students take the GCE course. However, in case where
such GCE courses are not available, students may opt for any other course of
their choice having 3 credits.
6) Choice of Disciplinary Major:
Major courses in the 3rd Year (V & VI Semester) shall be of the discipline
specific of study. While the requirements for each of V & VI Semester are of
two DMj courses, the concerned discipline based on Faculty strength may
float more DMj courses for students so that they can select the courses of
their choice.
7) Course in Research:
As per provision of NEP 2020, the 4th Year (VII & VIII Semester) of
UG/Bachelor’s Programme is dedicated for research.
It is therefore
suggested that the DMj course in the VII Semester is research related course,
so the students are equipped with required research skills.
Examples of syllabus structure are attached in Appendix – III.
5.3

Course and Credit Distribution for PG Programmes with Multiple Entry
and Exit Options

There will be only one exit option in 2-Year PG/Master’s Degree Programme
with Post-Graduate Diploma after completion of One Year or Two Semesters. The
course and credit distribution for the Two-Year PG/Master’s Degree Programme with
exit option is presented in Tables 6.
Table 6: Course and Credit Distribution for Two-Year PG/Master's Degree Programme with
Exit Option

Semester

Disciplinary/
Inter-disciplinary
Major
DMj-1 (3)

I

DMj-2 (3)
DMj-3 (3)
DMj-4 (3)

II

DMj-5 (3)
DMj-6 (3)

Disciplinary/
Inter-disciplinary
Minor

IMj - 1 (3)

IMn - 1 (2)

Choose one
from pool of
DMj courses
of other
disciplines

Choose one
from pool of
DMn courses
of other
disciplines

DMn-1 (2)

IMj - 2 (3)

IMn - 2 (2)

Choose one
from pool of
DMj courses
of other
disciplines

Choose one
from pool of
DMn courses
of other
disciplines

DMn-2 (2)

FP/Ints/
Dissertation
Apts

Total
Credit

4

-

20

4

-

20

Exit option with Post-Graduate Diploma after the first year or two semesters with
the completion of courses equivalent to 40 credits.

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

16

<!-- page 20 -->

Mizoram University

III

IV

DMj-7 (3)
DMj-8 (3)
DMj-9 (4)
Choose from
pool of DMj
courses

Total
DMj
=
DMn
=
FP/Ints/Apts =

-

DMn-3 (2)

IMn-1 (2)

4

6

20

-

-

-

4

12

20

34
12
Disciplinary Major
IMj
=
Disciplinary Minor
IMn
=
Field Project/Internship/Apprenticeship

16
18
80
Inter-disciplinary Major
Inter-disciplinary Minor

Note: DMj – 1 (3) means the 1st Disciplinary Major course with 3 credit while DMj – 2 (3) means 2nd
Disciplinary Major course with 3 credits and so on.

Explanation
1) Disciplinary/Inter-disciplinary Major:
The DMj are major courses offered by the discipline of study. For students of
the discipline offering the course, it will be credited as DMj while for students
of other discipline, it will be credited as IMj.
Students will have to take the DMj courses of other discipline as IMj course.
For this, each discipline of study will have to offer at least 1 DMj course for
students of other disciplines.
For example, there are 3 DMj courses in 1st and 2nd Semesters meant for the
students of same discipline. At the same time, there is a need for floating
additional DMj course(s) for students of other disciplines to meet the
requirement of IMj. For this, one of the DMj courses offered for own students
or a separate DMj course(s) may be floated for IMj of students from other
disciplines.
Further, it is desirable that the DMj courses in the 3rd Semester are of
research related courses. Based on Faculty strength, there shall also be two
or more DMj courses floated in the IV Semester so that the students will have
options to select the DMj of their choice.
2) Disciplinary/Inter-disciplinary Minor:
DMn are courses offered by the discipline of study. Similar to that of DMj/IMj
courses, various disciplines of study will have to make arrangements for
DMn/IMn.
3) Field Project/Internship/Apprenticeship:
The concerned discipline of study may prepare discipline-related
activities/progammes
to
be
taken
up
under
FP/Ints/Apts.
Laboratory/practical/projects may also be taken up under this.

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

17

<!-- page 21 -->

Mizoram University

Table 7: Course and Credit Distribution for One-Year PG/Master's Degree Programme
Disciplinary/
Inter-disciplinary
Major

Semester

DMj-1 (3)
DMj-2 (3)
DMj-3 (3)

I

II

Disciplinary
Minor

FP/Ints/
Apts

Dissertation

Total
Credit

IMj-1 (3)

DMn-1 (2)

3

6

20

-

DMn-1 (2)

3

12

20

Choose one from
pool of DMj
courses

Total
DMj
=
DMn
=
FP/Ints/Apts =

12
4
6
18
Disciplinary Major
IMj
=
Inter-disciplinary Major
Disciplinary Minor
Field Project/Internship/Apprenticeship

40

Explanation
1) The nature of DMj, IMj, DMn and FP/Ints/Apts for One-Year PG/Master’s
Programme is similar to that of Two-Yar PG Programme. It may only be
suggested that one of the DMj courses in the 1st Semester may be of
Advanced Course related to research.
2) The concerned discipline of study based on its Faculty strength may float two
or more DMj and DMn courses in the 2nd Semester so that students may have
options for the course of their choice.
6

Open Online Courses

To achieve the three cardinal principles of India’s Education Policy: Access,
Equity and Quality and for the benefit of students, options will be given for students
to earn credit by completing quality-assured online programmes offered on the Study
Webs of Active Learning for Young Aspiring Minds (SWAYAM: www.swayam.gov.in)
or other online educational platform approved by regulatory body from time to time.
Students may opt to earn credits from such courses upto 40 per cent of the total
courses offered in a particular programme.
7

Course Options

Towards attainment of holistic and multidisciplinary education, list of creditbased courses will be prepared such as disciplinary major and minor, interdisciplinary major and minor, vocational/skill courses, project in areas of community
engagement and service, environmental education, and value-based education etc.
To allow the students to take the courses of their choice, the courses to be offered
by departments in a particular semester will be floated before the commencement of
every semester.
The students will then select the courses of their choice from the list being
floated keeping in view of the requirements as per curriculum of the degree they are
pursuing.
Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

18

<!-- page 22 -->

Mizoram University

8

Departmental Coordinators

The students will require proper guidance in selecting the courses of their
choice in line with the curriculum of the department. Departmental Coordinator(s)
will be appointed to guide the students in selecting the courses to ensure that they
complete each level of courses in time.
9

Evaluation Committee for Multiple Entry and Exit

With the provision of multiple entry and exit, students from other HEIs will be
allowed entry to appropriate Level. Evaluation Committee will be set up to see the
eligibility of such students who desire to join the University from other HEIs with a
lateral entry.

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

19

<!-- page 23 -->

Mizoram University

Appendix - I
GUIDELINES FOR VOCATIONAL STUDIES UNDER
MULTIPLE ENTRY AND EXIT IN MIZORAM UNIVERSITY
Introduction
The operational details as per multiple entry and exit guidelines suggested 12-18
credits vocational studies for a four-year-undergraduate degree courses. The
guidelines further suggested
1. Skill component will be generally assessed by respective Sector Skill Council
(SSC);
2. In case, there is no SSC for specific trade, assessment may be done by an
allied SC or the Industry partner or a recognized Skill University;
3. If SSC has no approved Qualification Pack/set of competencies/or SSC could
not conduct skill assessment, the institution may conduct the skill assessment
through a Skill Assessment Board by Certified Assessors as per the provision
enumerated by MoE for Skill Assessment Matrix for Vocational Advancement
of Youth (SAMVAY).
4. Skill Assessment Board may be constituted under the chairmanship of VC
with nodal officer/coordinator of the programme/centre
Recommendations
In order to start vocational studies under NEP 2020 as per the Guidelines issued by
the UGC, the following suggestions have been proposed for smooth transition to the
new framework.
1. Memorandum of Understanding with Sector Skill Councils
Under National Skill Development Council (NSDC), there were 36 approved
Sector Skill Councils which designed relevant skill development courses as
per the provisions of National Skill Qualification Framework (NSQF). In the
light of Mizoram’s Skill Gap Analysis done by NSDC in 2012, the following
Sector Skill Councils may be invited initially to immediately work out the
syllabus for vocational studies in their respective fields:
i. Agriculture Sector Skill Council (e.g., Organic Farming,
Protected Cultivation, Production of Horticulture Crops such as
Orange and Banana, Floriculture, Piggery etc;
ii. Beauty and Wellness Sector Skill Council
iii. Banking, Financial Services and Insurance (BFSI) Sector Skill
Council
iv. Construction Sector Skill Council
v. Domestic Workers
vi. HealthCare
vii. Food Industry Capacity & Skill Initiative
viii. IT-ITeS
ix. Management & Entrepreneurship and Professional
Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

20

<!-- page 24 -->

Mizoram University

x. Media & Entertainment
xi. Paints & Coatings
xii. Tourism and Hospitality
2. Creation of Separate
Development

School

of

Vocational

Studies

and

Skill

As NEP 2020 puts/gives priority on introduction of vocational education in the
higher educational institution and vocational education being integrated in the
HEI system, it is suggested to create immediately a separate School of
Vocational Studies and Skill Development to work out courses and coordinate
functioning of the programmes under PG and UG courses of MZU. In the
meantime, a small committee may be set up to work out the immediate needs
of the University.
3. Creation of MZU Skill Assessment Board
The Guidelines suggested that if SSC has no approved Qualification Pack/set
of competencies/or SSC could not conduct skill assessment, the institution
may conduct the skill assessment through a Skill Assessment Board by
Certified Assessors as per the provision enumerated by MoE for Skill
Assessment Matrix for Vocational Advancement of Youth (SAMVAY).
Mizoram University Skill Assessment Board may be constituted under the
chairmanship of VC in order to conduct skill assessment as per SAMVAY.
4. All School of Studies may be instructed to immediately prepare at least two
vocational subjects for immediate approval by MZU Skill Assessment Board
for introduction in 2022 or until SSC-approved courses are available in the
university. They may refer to NSQF, NSDC guidelines and existing courses.
Examples- (i) SEMIS may work out on Tourism, Entrepreneurship, Banking,
etc); (ii) SLS on Beekeeping, Piggeries, Poultry Development etc.

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

21

<!-- page 25 -->

Mizoram University

Annexure - II

Provisions for Multiple Entry and Exit
in Academic Progammes offered in Mizoram University
Keeping in mind the flexibility of learning under the NEP 2020, provisions are
made for multiple entry and exit for students so they will have options. The entry or
re-entry of students from the University or other HEIs is allowed at the odd semester
and the exit will be allowed after the even semester. The requirements for entry and
exit are as follows:
Bachelor’s Programme 1st Year (Level 5)
Entry: Entry requirements for 1st Year (Level 5) are Secondary School Leaving
Certificate (Grade 12) and meeting other entrance requirements stipulated by
Mizoram University.
Exit: A student after having completed one year or two semesters of
Undergraduate/Bachelor’s Programme (Level 5) equivalent to 40 credits shall
be allowed to exit the programme with Undergraduate Certificate.
2nd Year (Level 6)
Entry: An Undergraduate Certificate holder meeting entrance requirements
stipulated by Mizoram University shall be allowed entry to level 6.
Exit: A
student after completing
two
years
(four semesters)
of
Undergraduate/Bachelor’s Programme (Level 6) equivalent to 80 credits shall
be allowed to exit the programme with Undergraduate Diploma.
3rd Year (Level 7)
Entry: An Undergraduate Diploma holder meeting entrance requirements stipulated
by Mizoram University shall be allowed entry to Level 7.
Exit: A student after completing three years
(six semesters) of
Undergraduate/Bachelor’s Programme (Level 7) equivalent to 120 credits
shall be allowed to exit the programme with Bachelor’s Degree.
4th Year (Level 8)
Entry: A three-year Bachelor’s Degree holder meeting a minimum CGPA of 7.5 shall
be allowed to continue studies in the fourth year Bachelor’s Programme with
Research (Level 8).
Exit: A student on completion of the fourth year (8 semesters) of Bachelor’s
Programme (Level 8) equivalent to 160 credits shall be awarded a Bachelor’s
Degree (Honours/Research) (Level 8).
Master’s Degree Programme (Level 9)
There shall be two main types of Master’s Degree Programmes (Level 9)
under Mizoram University such as:

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

22

<!-- page 26 -->

Mizoram University

i)
ii)

A two-year (four semester) Master’s Degree Programme and
A one-year (two semester) Master’s Degree Programme
Besides these, there may be an integrated five-year Bachelor’s/Master’s
Programme.

A Two-Year (Four-Semester) Master’s Degree Programme (Level 9)
Entry: On completion of a three-year Bachelor’s Programme (Level 7), a student
shall be eligible for entry into a Two-Year (Four-Semester) Master’s Degree
Programme (Level 9) with the second year devoted entirely to research.
Exit: A student who desires to exit after successful completion of one year (2
semesters) of Master’s Degree Programme equivalent to 40 credits shall be
awarded Post-Graduate Diploma (Level 8). A student who successfully
completes the two-year Master’s Degree Programme equivalent to 80 credits
shall be awarded Master’s Degree (Level 9).
A One-Year (Two-Semester) Master’s Degree Programme (Level 9)
Entry: Entry into a One-Year (Two-Semester) Master’s Degree Programme (Level 9)
shall be for those students who obtained a Bachelor’s Degree
(Honours/Research) that is, Level 8).
Exit: A student, on completion of the One-Year (Two-Semester) Master’s Degree
Programme (level 9) equivalent to 40 credits shall be awarded a Master’s
Degree.
Doctoral Degree (Level 10)
Undertaking a Doctoral shall require either a Master’s Degree or a Four-Year
Bachelor’s Degree with Research.

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

23

<!-- page 27 -->

Mizoram University

Annexure - III

Semester

Example of Syllabus Structure and Paper Distribution for UG–Bachelor's Degree
Programme

I

II

III

IV

V

Course Name

Disciplinary Major
Interdisciplinary Major [from DMj of another subject]
Interdisciplinary Major [from DMj of another subject]
Disciplinary Minor
Interdisciplinary Minor [from DMn of another subject]
Field Project/Internship/Apprenticeship
Environmental Studies
Total
Disciplinary Major
Interdisciplinary Major [from DMj of another subject]
Interdisciplinary Major [from DMj of another subject]
Disciplinary Minor
Vocational Studies
Field Project/Internship/Apprenticeship
Language Skill and Communication
Total
Disciplinary Major
Interdisciplinary Major [from DMj of another subject]
Interdisciplinary Major [from DMj of another subject]
Disciplinary Minor
Vocational Studies
Field Project/Internship/Apprenticeship
Language Skill and Communication
Total
Disciplinary Major
Interdisciplinary Major [from DMj of another subject]
Interdisciplinary Major [from DMj of another subject]
Disciplinary Minor
Interdisciplinary Minor [from DMn of another subject]
Field Project/Internship/Apprenticeship
Value-based Course
Total
Disciplinary Major
Disciplinary Major
Disciplinary Minor
Interdisciplinary Minor [from DMn of another subject]
Vocational Studies
Field Project/Internship/Apprenticeship
Global Citizenship Education
Total

Code

Credits

DMj–01
IMj–01
IMj–02
DMn–01
IMn–01
FIA–01
EVS–01

3
3
3
2
2
4
3
20
3
3
3
2
4
3
2
20
3
3
3
2
4
3
2
20
3
3
3
2
2
4
3
20
3
3
2
2
4
3
3
20

DMj–02
IMj–03
IMj–04
DMn–02
VS–01
FIA–02
LSC–01
DMj–03
IMj–05
IMj–06
DMn–03
VS–02
FIA–03
LSC–01
DMj–02
IMj–07
IMj–08
DMn–04
IMn–02
FIA–04
VBC–01
DMj–05
DMj–06
DMn–05
IMn–03
VS–03
FIA–04
GCE-01

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

24

<!-- page 28 -->

Mizoram University

Semester

Example of Syllabus Structure and Paper Distribution for UG–Bachelor's Degree
Programme (Contd…)

Course Name

Disciplinary Major
Disciplinary Major
Disciplinary Minor
Interdisciplinary Minor [from DMn of another subject]
VI
Vocational Studies
Field Project/Internship/Apprenticeship
Value-based Course
Total
Disciplinary Major
Disciplinary Minor
Interdisciplinary Minor [from DMn of another subject]
VII
Field Project/Internship/Apprenticeship
Research Project
Total
Disciplinary Major
Vocational Studies
VIII Field Project/Internship/Apprenticeship
Research Project

Code

Credits

DMj–07
DMj–08
DMn–06
IMn–04
VS–03
FIA–04
VBC–02

3
3
2
2
3
4
3
20
4
2
2
4
8
20
4
3
3
10

DMj–09
DMn–07
IMn–05
FIA–05
RP–01
DMj–10
VS–03
FIA–06
RP–02

Total

20

Grand Total

160

NB.
1.

2.
3.
4.
5.
6.

Unit allocation:
a)
Each DMj/IMj/EVS paper will be of four units.
b) Each DMn/IMn paper will be of three units.
All DMj and DMn papers will bear in the course code a prefix of the subject; e.g., for English, ENG–
DMj–01, ENG–DMn–01, and so on.
1 credit = 1 hour of theory or 2 hours of laboratory/practical/project work per week.
Disciplinary Major and Disciplinary Minor are compulsory as the core subject.
Interdisciplinary Major and Interdisciplinary Minor are to be opted from the Interdisciplinary Major
and Interdisciplinary Minor of different subjects.
Subjects offering laboratory/practical component under Fp/Ints/Apts course should clearly specify
the course contents (topics); e.g.,
a)
Experiments (exact number to be mentioned)
b) Spotting or identification of samples
c)
Laboratory record
d) Viva voce

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

25

<!-- page 29 -->

Mizoram University

Semester

Example of Syllabus Structure for B.Sc. Zoology

Course Name

Physiology
Interdisciplinary Major [from DMj of another subject]
Interdisciplinary Major [from DMj of another subject]
Non-chordate Biology
I
Interdisciplinary Minor [from DMn of another subject]
Field Project/Internship/Apprenticeship
Environmental Studies
Total
Cell Biology
Interdisciplinary Major [from DMj of another subject]
Interdisciplinary Major [from DMj of another subject]
Chordate Biology
II
Vocational Studies
Field Project/Internship/Apprenticeship
Language Skill and Communication
Total
III Evolution and Ethology
Interdisciplinary Major [from DMj of another subject]
Interdisciplinary Major [from DMj of another subject]
Biosystematics and Anatomy
Vocational Studies
Field Project/Internship/Apprenticeship
Language Skill and Communication
Total
Endocrinology and Reproduction Biology
Interdisciplinary Major [from DMj of another subject]
Interdisciplinary Major [from DMj of another subject]
Helminthology
IV
Interdisciplinary Minor [from DMn of another subject]
Field Project/Internship/Apprenticeship
Value-based Course
Total
Developmental Biology
Hematology and Immunology
Protozoology
Interdisciplinary Minor [from DMn of another subject]
V
Vocational Studies
Field Project/Internship/Apprenticeship
Global Citizenship Education
Total
Molecular Biology and Genetics
Biochemistry
Entomology
Interdisciplinary Minor [from DMn of another subject]
VI
Vocational Studies
Field Project/Internship/Apprenticeship
Value-based Course
Total
VII Applied Zoology

Code

Credits

ZOO–DMj–01
IMj–01
IMj–02
ZOO–DMn–01
IMn–01
FIA–01
EVS–01

3
3
3
2
2
4
3
20
3
3
3
2
4
3
2
20
3
3
3
2
4
3
2
20
3
3
3
2
2
4
3
20
3
3
2
2
4
3
3
20
3
3
2
2
3
4
3
20
4

ZOO–DMj–02
IMj–03
IMj–04
ZOO–DMn–02
VS–01
FIA–02
LSC–01
ZOO–DMj–03
IMj–05
IMj–06
ZOO–DMn–03
VS–02
FIA–03
LSC–01
ZOO–DMj–02
IMj–07
IMj–08
ZOO–DMn–04
IMn–02
FIA–04
VBC–01
ZOO–DMj–05
ZOO–DMj–06
ZOO–DMn–05
IMn–03
VS–03
FIA–04
GCE-01
ZOO–DMj–07
ZOO–DMj–08
ZOO–DMn–06
IMn–04
VS–03
FIA–04
VBC–02
ZOO–DMj–09

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

26

<!-- page 30 -->

Mizoram University

Ecology and Wildlife
Interdisciplinary Minor [from DMn of another subject]
Field Project/Internship/Apprenticeship
Research Project
Total
Biotechnology and Bioinformatics
Vocational Studies
VIII Field Project/Internship/Apprenticeship
Research Project
Total
Grand Total

ZOO–DMn–07
IMn–05
FIA–05
RP–01
ZOO–DMj–10
VS–03
FIA–06
RP–02

Guidelines for Implementation of NEP 2020 with Multiple Entry and Exit Options

2
2
4
8
20
4
3
3
10
20
160

27
