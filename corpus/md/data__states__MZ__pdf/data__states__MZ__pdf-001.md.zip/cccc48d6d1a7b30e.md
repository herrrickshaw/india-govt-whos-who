---
doc_id: "cccc48d6d1a7b30e"
source_url: "https://mizoculture.mizoram.gov.in/uploads/attachments/861326d261d3a60220580810024cb6d5/pages-36-issue-no-521-constitute-archival-advisory.pdf"
ministry: "Art and Culture Department, Mizoram"
title: "Issue No 521 Constitute Archival Advisory"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "20dd17a3911144b5"
---

<!-- page 1 -->

The Mizoram Gazette
EXTRA ORDINARY

Published by Authority
RNI No. 27009/1973
VOL - XLV Aizawl,

Friday 9.12.2016

Postal Regn. No. NE-313(MZ) 2006-2008
Agrahayana 18, S.E. 1938, Issue No. 521

NOT IFICAT ION
No.A. 42011/3/90-AC, the 24 th November, 2016. In the interest of public service, the Governor of
Mizoram is pleased to Constitute Archival Advisory Board with the following members for a period of three
years with immediate effect :Chairman
Member Secretary
Member

- Secretary, Art & Culture Department, Ex-officio
- Archivist, Mizoram State Archives, Ex-officio
- 1) Director, Art & Culture Department, Ex-officio
2) Head of Department, History, Government Aizawl College
3) Head of Department, History, Mizoram University
4) Head of Department, History, Pachhunga University College
5) Deputy Director, Art & Culture Department
6) Joint Secretary, Home Department, Ex-officio
7) Joint Secretary, DP&AR, Ex-officio
8) Joint Secretary, Finance Department, Ex-officio
9) Joint Secretary, Law & Judicial Department, Ex-officio

The Archival Advisory Board shall perform the following functions as stated under section 14 of
the Mizoram Public Records Act No. 15, namely
a)
b)
c)

advice the Government on matters concerning administration, management, conservation
and use of Public Records.
give directions for acquisition of records from private custody;
deal with such other matters as may be prescribed.
Thanhliri Pachuau,
Secretary to the Govt. of Mizoram,
Art & Culture Department.
Published and Issued by Controller, Printing & Stationery Department, Government of Mizoram
Printed at the Mizoram Government Press, Aizawl. C/50
