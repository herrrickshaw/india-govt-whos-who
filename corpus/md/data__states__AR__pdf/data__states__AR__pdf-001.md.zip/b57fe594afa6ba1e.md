---
doc_id: "b57fe594afa6ba1e"
source_url: "https://cdn.s3waas.gov.in/s3819f46e52c25763a55cc642422644317/uploads/2026/04/17756485943785.pdf"
ministry: "Lower Dibang Valley"
title: "Order"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "fbb9261aff78792b"
---

<!-- page 1 -->

r
ty-So,
oP ON
‘ aS ss GOVERNMENT OF ARUNACHAL PRADESH
8 bss IA io OFFICE OF THE DEPUTY COMMISSIONER DC :
* Ks LOWER DIBANG VALLEY DISTRICT::ROING
eagh sty
Co ”
ng VaN\e
SeEDR/TUD-01/2026/2.9 6 - 23£ Dated Roing, the 6"April’2026.
ORDER
WHEREAS, it is known that with the onset of monsoon, April to September is the fish breeding
season. And it has been noticed that the fish stock of our natural open waters has dwindled at an alarming rate.
Hence, it is imperative to observe a closed season by imposing ban on all sorts of fishing activities in open
waters throughout the district.
AND WHEREAS, it is also established and known that implementation of closed season and banning
of fishery activities will help in replenishing the depleted stock in our open water system.
AND WHEREAS, vide order memo No.LDV/DM/MP/23-24/119-140 dated 31° March’2026, it has
been directed to prohibit all kinds of fishing activities during monsoon season.
Now therefore, keeping in view the importance of replenishing the fish stock in the district, I Lui
Shiba, i/c Deputy Commissioner, Lower Dibang Valley District, Roing do hereby ban all sort of fishing
activities including traditional fishing in the District under the Section 6 Clause(1) Sub-Clause(G) of the
Arunachal Pradesh, Fisheries Act 2006 from April to September 2026.
Violation of this order shall be viewed seriously as per relevant provisions ~~
a.
(Lui Shiba) ADC
i/e Deputy Commissioner
Lower Dibang Valley District, Roing
Memo No.LDR/JUD-01/2026/ 2 96 — 336 Date RE pbRy ClatiiARESioner
Copy to; Lower Dibang Valley District
ROING (AP)
1. The Commissioner, Fisheries, Govt. of A.P, Itanagar for information please.
2. The Director of Fisheries, Govt. of A.P, Itanagar for information please.
3. The SP, Roing, Lower Dibang Valley District for information and necessary action please.
4. The ZPC, Lower Dibang Valley District for information and necessary action please.
5. The Addl. Deputy Commissioner, Dambuk for information and necessary action please.
6. The SDO, Hunli/Parbuk/Paglam, CO, Desali and Koronu for information and necessary action please.
7. The Executive/Town Magistrate, Lower Dibang Valley District for information and necessary action
please.
8. The DFDO, Roing for information and necessary action please.
9. The DFO(T) and DFO(W/L), Roing for information and necessary action please.
10. The DIPRO, Roing for information and wide circulation of the above order.
11. The DIO, NIC, Roing for updation in the official website.
12. The President, ABK and IMCLS, Lower Dibang District for information and necessary action please.
13. All GBs and Bango Secretaries, Lower Dibang Valley District for information and wide circulation
amongst the villagers.
14. Notice board/Office copy. Lh
(Lui Ship ADC
i/c Deputy Commissioner
Lower Dibang Marae DisttiggiBnes
Addl. Dept rn .
Lower Shang Valley District
ROING (AP)
