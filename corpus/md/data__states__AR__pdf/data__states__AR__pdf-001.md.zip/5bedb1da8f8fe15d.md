---
doc_id: "5bedb1da8f8fe15d"
source_url: "https://meen.arunachal.gov.in/uploads/guidelines/080225/DAJGUAguidelines-30102024.pdf"
ministry: "Fisheries Department, Arunachal Pradesh"
title: "DAJGUA Guideline"
date: ""
pages: 73
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2ca7eb7a2cad2acc"
---

<!-- page 1 -->

Guidelines

Dharti Aaba Janjatiya Gram Utkarsh Abhiyan

Ministry of Tribal Affairs

<!-- page 2 -->

Content
1

Background……………………………………………………………...

5

2

Vision……………………………………………………………………

5

3

Objectives………………………………………………………………..

6

4

Scope…………………………………………………………………….

8

5

Key Activities……………………………………………………………

9

6

Foundational Feautures………………………………………………….

10

7

Coverage………………………………………………………………...

10

8

Interventions…………………………………………………………….

13

9

Implementation Plan…………………………………………………….

19

10 Coverage with Central Sector Schemes………………………………….

26

11 Monitoring & Evaluation Framework…………………………………...

31

12 Budget Provision & Funding Pattern…………………………………….

34

13 Annexures……………………………………………………………….

35

2

<!-- page 3 -->

Acronyms
AM
AWC
AYUSH
BLIT
CEO
CFR
CPWD
DAPST
DLC
DoAFW
DoE
DoSEL
DoT-MoC
DPR
EFC
FHTC
FRA
GER
GoI
HH
IEC
IMR
ITDP
J&K
JJM
JSS
KPI
MADA
MGNREGA
MMR
MMU
MoAFW
MoFAHD
MoHFW
MoPNG
MoRD
MoTA
MoWCD

Antyodaya Mission
Anganwadi Centre
Ayurveda, Yoga & Naturopathy, Unani, Siddha, Sowa Rigpa and
Homeopathy
Block Level Implementation Team
Chief Executive Officer
Community Forest Rights
Central Public Works Department
Development Action Plan for Schedule Tribes
District Level Committee
Department of Agriculture & Farmers’ Welfare
Department of Expenditures
Department of School Education & Literacy
Department of Telecommunications, Ministry of Communications and
Information Technology
Detailed Project Report
Expenditure Finance Committee
Functional Household Tap Connection
Forest Rights Act
Gross Enrolment Ratio
Government of India
Household
Information Education Communication
Infant Mortality rate
Integrated Tribal Development Project
Jammu & Kashmir
Jal Jeevan Mission
Jan Shikshan Sansthan
Key Performance Indicators
Modified Area Development Approach
Mahatma Gandhi National Rural Employment Guarantee Act
Maternal Mortality Rate
Mobile Medical Units
Ministry of Farmers’ Welfare
Ministry of Fisheries Animal Husbandry and Dairying
Ministry of Health and Family Welfare
Ministry of Petroleum and Natural Gas
Ministry of Rural Development
Ministry of Tribal Affairs
Ministry of Women & Child Development

3

<!-- page 4 -->

MSDE
NE
NGO
NHM
NITI
NLM
NRLM
PFMS
PMAAGY
PMABHIM
PMAY
PMGSY
PMJANMAN
PMJAY
PMMSY
PMU
PMUY
POSHAN
PVTG
RDSS
RGSA
SC
SCA
SCD
SLAC
SPMU
SSA
SSOR
STC-MIS
TMMC
TSP
UIDAI
UT
VDVK

Ministry of Skill Development and Entrepreneurship
Northeast
Non-Governmental Organization
National Health Mission
National Institution for Transforming India
National Livestock Mission
National Rural Livelihood Mission
Public Financial Management System
Pradhan Mantri Adi Adarsha Gram Yojana
Pradhan Mantri Ayushman Bharat Health Infrastructure Mission
Pradhan Mantri Awaas Yojana
Pradhan Mantri Gram Sadak Yojana
Pradhan Mantri Janjatiya Adivasi Nyay Maha Abhiyan
Pradhan Mantri Jan Arogya Yojana
Pradhan Mantri Matsya Sampada Yojana
Project Monitoring Unit
Pradhan Mantri Ujjwala Yojana
Prime Minister’s Overarching Scheme for Holistic Nourishment
Particularly Vulnerable Tribal Group
Revamped Distribution Sector Scheme
Rashtriya Gram Swaraj Abhiyan
Scheduled Caste
Special Central Assistance
Sickle Cell Disease
State Level Apex Committee
State Project Management Unit
Samagra Shiksha Abhiyan
State Schedule of Rates
Schedule Tribe Component- Management Information System
Tribal Multipurpose Marketing Centre
Tribal Sub Plan
Unique Identification Authority of India
Union Territory
Van Dhan Vikas Kendra

4

<!-- page 5 -->

1.Background
According to the 2011 Census, India has a Scheduled Tribe (ST) population of 10.45 crore,
comprising 5.25 crore males and 5.20 crore females. This group represents 8.6% of the total
population and 11.3% of the rural population. Over 705 tribal communities live across remote and
difficult-to-access areas, each with unique cultural and linguistic traits. Despite India’s significant
growth and advancements in socio- economic and human development, tribal populations still face
challenges in education, healthcare infrastructure, and related socio- economic indicators.
Since Independence, various models for tribal development have been implemented, with the
Tribal Sub-Plan (TSP) established in 1974-75 evolving into the Schedule Tribe Component (STC)
and Development Action Plan for Scheduled Tribes (DAPST). Despite these changes, the core
philosophy remains that all Government of India Ministries and Departments must collaborate to
create schemes for the welfare of Scheduled Tribes. In the past decade, the budget allocation for
DAPST has increased significantly, from Rs. 25,000 crores annually to Rs. 1,200,000 crores in
2023-24, involving 41 Ministries, including MoTA. Although these efforts have improved
literacy, health, and livelihood, significant gaps remain in infrastructure and human development
indices compared to other social groups. Data from the Antyodaya Mission (AM) in 2019 and
2022 reveal that major socio-economic challenges stem from substantial service and infrastructure
deficits in tribal villages, a finding supported by various studies and reports.
As India celebrate Azadi Ka Amrit Mahotsav, it is vital to comprehensively address the critical
needs of our communities in a definitive and time-bound manner. In this background, in the
Budget 2024-25, the Government of India announced the Pradhan Mantri Janjatiya Unnat Gram
Abhiyan (PM JUGA). Its name was later changed into “Dharti Aaba Janjatiya Gram Utkarsh
Abhiyan”. It aims at improving the socio-economic conditions of tribal communities by saturating
tribal households and tribal majority villages including villages in aspirational blocks having
significant tribal population with basic facilities, covering around 63,843 villages and benefiting
more than 5 crore tribal people in a set time frame.

2. Vision
The Dharti Aaba Janjatiya Gram Utkarsh Abhiyan envisions the comprehensive development of
tribal areas and communities by addressing critical gaps in infrastructure, healthcare, education, and
livelihoods. Through a coordinated approach and convergence of various Government of India
schemes, the mission aims to ensure holistic, sustainable, and inclusive growth, empowering tribal
communities to thrive and flourish in a SATURATION Mode.

5

<!-- page 6 -->

3. Objectives
The mission seeks to develop enabling infrastructure and enhance socio-economic conditions in
selected tribal-majority villages (with a population of 500 or more, and at least 50% tribal residents
as well as villages in Aspirational Districts with a tribal population of 50 or more). By adopting a
whole-of-government approach, the mission aims to improve access to education, healthcare, and
skills, driving progress toward the specific goals outlined below.

6

<!-- page 7 -->

Goal 1: Develop Enabling Infrastructure (SDG 9)
Pucca house for eligible Households with other entitlements: Eligible ST households shall have
access to pucca housing under the PMAY (Gramin) with the availability of tapped water (Jal
Jeevan Mission) and electricity supply (RDSS). Eligible ST households shall have access to gas
connections through Ujjwala Yojana (MoP&NG) and Ayushman Bharat Card (PMJAY).
Improving Village infrastructure: Ensuring all-weather road connectivity to ST majority villages
(PMGSY), providing access to mobile and internet (USoF), and improving infrastructure for
improving Health (MMU), Nutrition (Saksham Anganwadi), and Education (Hostels).

Goal 2: Promotion of Economic Empowerment (SDG 8)
Skill Development Entrepreneurship promotion and enhanced livelihood(self-employment):
Ensuring that ST boys and girls gain access to long-term skill development and entrepreneurship
promotion and professional courses after 10th and 12th grade annually, through initiatives like
the Skill India Mission.
Additionally, the mission facilitates Livelihood & marketing through Tribal Multipurpose
Marketing Centres (TMMC), promote Tourist Home Stays, and strengthens Agricultural,
Animal Husbandry, and Pisciculture for FRA Patta holders, fostering sustainable livelihoods
and self-reliance.

Goal 3: Universalization of Access to Good Education (SDG 4)
To boost the Gross Enrolment Ratio (GER) to national levels and ensure quality education for
Scheduled Tribe (ST) students, the Samagra Shiksha Abhiyan focuses on enhancing
infrastructure, providing financial support, and increasing digital access. The initiative also
promotes culturally relevant education and community engagement, making education both
affordable and accessible for ST students from school to higher education. The Abhiyan provides
Hostels to ensure access to quality education.

Goal 4: Healthy Life and Dignified Ageing (SDG 3)
To improve access to quality healthcare for Scheduled Tribe (ST) households and achieve
national standards in Infant Mortality Rate (IMR), Maternal Mortality Rate (MMR), and
immunization coverage, the PM Ayushman Bharat Health Infrastructure Mission (PM ABHIM)
focuses on strengthening healthcare infrastructure and expanding essential services in tribal
regions by including MMUs, intervention on SCD and Centre of Competency on Sickle Cell.

7

<!-- page 8 -->

4. Scope
The “Dharti Aaba Janjatiya Gram Utkarsh Abhiyan” aims for the holistic development of tribal
communities and villages, focusing on those in Aspirational blocks with ST populations of 50 or
more, and villages with at least 500 people and 50% ST population—covering around 63,643
villages. Over five years (2024-25 to 2028-29), the program will reach 549 districts and 2,911
blocks across tribal-dominated areas in 26 States and 4 UTs, ensuring comprehensive
development for these underserved regions. (Annexure-I).

26 States
&
4 UTs

63,843
Villages

Scope

549
Districts

2911
Blocks

8

<!-- page 9 -->

5. Key Activities

Central

Policy Development: Formulate national policies and
guidelines and SoPs for program implementation.
Funding Allocation: Allocate and manage financial
resources for the mission.
Inter-Ministerial Coordination: Coordinate among
different ministries for integrated and cohesive execution
Monitoring and Evaluation: Oversee the overall
progress and impact of the scheme

State

Customization of Programs: Adapt central guidelines
to align with state-specific contexts and requirements.
Resource Distribution: Manage the distribution of
funds and resources to districts and blocks.
Training and Capacity Building: Conduct training
programs for local officials and stakeholders.
Coordination & Implementation: Coordinate
activities among various state departments and central
agencies. Monitor and review the progress of
implementation.

District

Data Check & Monitoring:
Monitor progress at the district level and report to
state and central authorities.
Stakeholder Engagement: Engage with local
communities, NGOs, and other stakeholders for
effective implementation.
Field-level implementation Review and Reporting

Block

Village Camps, IEC, Saturation Drives
Ground-Level Execution: Implement the schemes at
the grassroots level, ensuring reach to the target
communities.
Beneficiary Identification and Support: Identify
beneficiaries and ensure they receive the intended
benefits.
Village Planning, CBO involvement, and Community
mobilization.

9

<!-- page 10 -->

6. Foundational Features

Foundational
Features

7. Coverage
The Abhiyan will target specific tribal-majority villages with populations of 500 or more,
where at least 50% are tribal, and villages, in Aspirational districts, with at least 50 tribal
population. Following the approved schematic norms, this will include eligible areas across all
states and UTs. The State/UT-wise coverage of districts, blocks, and villages, along with the
population and ST population, is as follows:

10

<!-- page 11 -->

SR.
No
1

Name of the State

No. of
District
18

No. of
Block
107

No. of
Villages
878

Total
Population
1113652

ST
Population
655450

% ST

23

84

329

272750

230896

84.65

32

147

3161

2779667

2124774

76.44

3

ANDHRA
PRADESH
ARUNACHAL
PRADESH
ASSAM

4

BIHAR

24

74

771

1783928

407136

22.82

5

CHHATTISGARH

32

138

6691

6967289

4909442

70.46

6

GOA

2

9

25

47144

34105

72.34

7

GUJARAT

21

102

4265

7675215

6605912

86.07

8

10

26

270

170351

117040

68.71

20

112

393

792087

502935

63.49

10

HIMACHAL
PRADESH
JAMMU AND
KASHMIR
JHARKHAND

24

231

7139

7044011

4976859

70.65

11

KARNATAKA

28

129

1089

1975186

805566

40.78

12

KERALA

4

9

89

1322280

219524

16.60

13

LADAKH

2

30

143

163981

155238

94.67

14

LAKSHADWEEP

1

2

2

9868

9322

94.47

15

51

267

11377

13186399

9323125

70.70

16

MADHYA
PRADESH
MAHARASHTRA

32

214

4975

6347798

4694682

73.96

17

MANIPUR

13

57

516

666137

629332

94.47

18

MEGHALAYA

12

53

1437

1183736

1135901

95.96

19

MIZORAM

11

26

383

414444

400652

96.67

20

NAGALAND

16

74

608

956721

915742

95.72

21

ODISHA

27

234

7667

7042261

4815670

68.38

22

RAJASTHAN

30

208

6019

7655043

5537444

72.34

23

SIKKIM

6

26

119

123635

72682

58.79

24

TAMIL NADU

16

36

248

489153

303711

62.09

25

TELANGANA

30

230

924

1691305

1150538

68.03

26

D&D and DNH

2

2

76

203454

147290

72.39

27

TRIPURA

8

52

392

988452

828393

83.81

28

26

47

517

1183202

311488

26.33

29

UTTAR
PRADESH
UTTARAKHAND

7

15

128

209384

88723

42.37

30

WEST BENGAL

21

170

3212

3974631

1707342

42.96

Grand Total

549

2911

63843

78433164

53816914

68.61

2

9

58.86

*Census-2011 (Village with 500 Population & ≥ 50% ST Population-(i.e. 48606) and villages Aspirational
block with ≥ 50 ST population-(i.e.15235)

11

<!-- page 12 -->

Inter-Ministerial Convergence
A key feature of the mission is its inter-ministerial convergence, where 17 Ministries of the
Government of India will unite for the welfare of tribal communities through 25 focus
interventions. The Ministry of Tribal Affairs will serve as the nodal agency, coordinating
with Central Ministries for planning, implementation, and monitoring. However, each Ministry
will retain responsibility for implementing its specific schemes. Similarly, at the state level, the
Tribal Welfare Department will act as the nodal body, ensuring effective coordination across
departments for the streamlined execution of tribal welfare programs.

Alignment of Schemes/Programs
To address the unique needs of these villages, the existing norms of relevant schemes across
Ministries have been appropriately modified through a unified EFC and a cabinet note prepared
by the Ministry of Tribal Affairs (MoTA). This ensures alignment with the objectives of the
Abhiyan. Ministries and Departments no longer need separate EFC approvals to amend their
guidelines, except for schemes where it has been also indicated in the Cabinet Note. Each
Ministry will issue revised guidelines to ensure the successful implementation and fulfilment of
the mission's objectives.

Provision of Funds
The funding for various interventions will come from the existing Development Action Plan
for Scheduled Tribes (DAPST) grants allocated to Central Ministries and Departments under
Central Sector and Centrally Sponsored Schemes. If there is a shortfall in funds for a specific
scheme within a Ministry or Department, it will be covered by reallocating from the Ministry's
total DAPST allocation. Any additional funding needs for the Abhiyan will be addressed by
utilizing savings from DAPST, following the new framework proposed by NITI Aayog,
similar to the PM JANMAN model. NITI Aayog’s guidelines require a mandatory percentage of
total scheme allocations rather than individual scheme allocations. Each Ministry will ensure that
funds for interventions are effectively allocated to the respective states.

Period
The Mission will span a period of 5 years, from 2024-25 to 2028-29. The first 2 years falling
under the current Finance cycle. The interventions proposed under the Abhiyan will continue till
2029. These interventions will utilize DAPST funds from the respective Ministries and
Departments and will run from 2024-25 to 2028-29. These components of schemes of the
Departmental will continue for the entire 5-year period of the Mission as per the targets and fund
allocation approved – (Annexure I) subject to Cabinet approval for the Continuation of Schemes
in the next financial cycle. Schemes like PMAY-G, which are already approved beyond March
31, 2026, or any other similar schemes, which have got stand-alone approval, automatically will
continue beyond the current finance cycle. The Ministries may take stock at the end of the current
Financial Cycle.

Implementation and Monitoring Mechanism
12

<!-- page 13 -->

Tribal households and villages covered under the Abhiyan will be mapped on the PM
GatiShakti Portal, with gaps identified by the Antyodaya Mission (2022-23) validated by the
respective departments based on scheme-specific requirements. Line Ministries can leverage
their existing portals, incorporating relevant parameters to invite proposals from the states. Each
Ministry will also be responsible for linking its Monitoring and Evaluation (M&E) system to
the Dharti Aaba Janjatiya Gram Utkarsh Abhiyan portal on the PM GatiShakti platform,
where both physical and financial progress will be regularly updated and tracked. This is
compulsory for drawing money under the program.

Recognition Mechanism
Each district's performance will be monitored through a ranking system, based on monthly
incremental (delta) changes in key performance indicators. This ranking aims to foster
healthy competition among district teams, motivating them to improve outcomes. The top
performing districts will receive awards. Likewise, the performance of Ministries will also be
tracked and recognized for their contributions to the mission’s success and tribal development.

8. Interventions
The mission will cover 25 interventions of 17 Ministries as shown below.

Sno.

Ministry

Interventions/ (Scheme)

Beneficiary/ Intervention
figure

Pucca houses- (PMAY)20 lakhs houses
Gramin
Connecting Road – (PMGSY) 25000 km road
(i). Water Supply-Jal Jeevan
(i). Every HH as per the
Ministry of Jal Shakti Mission (JJM)-FHTC
norms of JJM.
(ii). Community water tap
(ii). Hamlets ≤ 20HH
House ElectrificationEvery unelectrified HH and
Ministry of Power
(Revamped Distribution
unconnected public
Sector Scheme (RDSS))
institutions (~ 2.35 lakh)
(i). Every unelectrified HH and
Ministry of New and
New Solar Power Scheme
public institutions not covered
Renewable Energy
(Off-grid Solar)
through grid.
Up to 1000 MMU for
providing health facilities in
Mobile Medical Unitsvillages where health facility is
(National Health Mission)
Ministry of Health and
available beyond 5 km in Hilly
family Welfare
areas and 10 km in plain areas
Ayushman Card - Pradhan
Every eligible HH covered
Mantri Jan Arogya Yojana
under the Abhiyan
(PMJAY)-NHA

Ministry of Rural
1
Development (MoRD)
2
3
4

5

13

<!-- page 14 -->

Ministry of Petroleum LPG Connections-(PM
6
& Natural Gas
Ujjwala Yojana)
7

Ministry of Women
and Child
Development

Establishment of Anganwadi
Centres- Poshan Abhiyan

Construction of Hostels8 Ministry of Education Samagra Shiksha Abhiyan
(SSA)
Poshan Vatikas- National
9 Ministry of AYUSH
AYUSH Mission
Universal Service Obligation
10 Department of Telecom
Fund/Bharat Net (DoT-MoC)
Ministry of Skill
11
Skill India Mission (Existing
Development and
Schemes)/propose
Entrepreneurship
12
13

14

15

Ministry of Electronics
& Information
Digital Initiatives
Technology
Promotion of sustainable
Ministry of
agriculture - Multiple
Agriculture & Farmer
Schemes of DoAFW
welfare
Fish culture support-Pradhan
Department of
Mantri Matsya Sampada
Fisheries
Yojana (PMMSY)
Department of Animal Livestock rearing- National
Livestock Mission
Husbandry &
Dairying
Capacity building-Rashtriya
Ministry of Panchayati
Gram Swaraj Abhiyan
Raj
(RGSA)

16 Ministry of Tourism

17

Ministry of Tribal
Affairs

Tribal Home Stays-Swadesh
Darshan

PMAAGY

25 Lakhs HH
(subject to approval of targets
and funds)
8000 (2000 New Saksham
AWC) & 6000 upgradation to
Saksham AWC)
1000 hostels
700 Poshan Vatikas
5000 Villages
Skilling Centre in tribal
districts
1000 VDVKs, Tribal Groups etc
As applicable
FRA Patta holders
(~2 lakhs beneficiaries)
10,000 community and 1,00,000
individual beneficiaries
8500 Individual /Group
beneficiaries
All Gram Sabhas and
concerned officers at
Subdivision, District and
State level dealing with FRA
1000 Tribal Home Stays with
support of upto Rs 5 lakh per
unit (for new construction),
upto Rs 3 lakhs (renovation)
and Rs 5 lakh for village
community
requirement.
Enhancing the scope of SCA to
Tribal Development /
PMAAGY by including other
interventions#
14

14

<!-- page 15 -->

#100Tribal Multi-purpose Marketing Centres, improving infrastructure of Ashram Schools,
Hostels, Govt./State Tribal Residential schools, Centre of Competencies for Sickle Cell Disease
(SCD) and counselling support, Support for FRA & CFR Management interventions, setting up
of FRA Cells, and project management funds with incentives for top performing tribal districts.
The modified norms of different schemes implemented under the mission by the sectoral
ministries is given as under.

Revised Norms:

Existing norms of the scheme
1. Housing - PMAY - G (MoRD)
a) ₹1.2 lakhs (plain); ₹1.3 lakhs (hilly/PVTG)
(excl. ₹0.39 lakhs)
b) 60:40; 90:10 (in NE & Himalayan); 100 in
UTs
2. Road connectivity – PMGSY(MoRD)
a) 60:40; 90:10 (in NE & Himalayan); 100 in
UTs
b) Detailed estimates will be based on the State
Schedule of Rates (SSR)
3. Water Supply - JJM (MoJal Shakti)
a) 50:50; 90:10 (in NE & Himalayan/UTs with
legislature); 100 in UTs without legislature

Norms of the scheme as per Mission
a) As per the existing norms PMAY-G
b) Implementation guidelines as adopted for
PMJANMAN may be followed subject to
necessary approvals.
a) Average cost of ₹1 cr/km will be
commensurate with cost norms of PMGSY
scheme as approved by Cabinet
b) Provision of funds under DAPST for
PMGSY

a) Saturation coverage of all villages by
FHTCs and Provision of community tap for
habitations, with less than 20 HHs as per
norms of JJM subject to continuation of the
scheme by the Cabinet.
4. House Energization – RDSS (Ministry of Power)
Provision of access to electricity of remaining
a) Provision of electricity for every
un-electrified households identified up to
unelectrified HH and unconnected public
31.03.2019
institutions as per norms of RDSS
5. Energization through Solar Power -– New Solar Power Scheme (MNRE)
a) Subsidy of 60% of the solar unit cost for
a) Provision for every unelectrified HH and
public institutions not covered through grid
systems up to 2 kW capacity and 40 percent
under New solar Power Scheme.
of additional system cost for systems
between 2 to 3 kW capacity.
b) Schematic Guidelines to be framed
b) The Scheme is only for residential houses
and Coo-operative Housing Societies
6. MMU & Ayushman Card – NHM & PM JAY (MoHFW)
a) 5 MMUs / district
a) Coverage of habitations where nearest
Health centre is more than 10 km (in plain
b) 60:40 (States / UTs with legislature); 90:10
(in NE & Himalayan)
area) and 5 km (in hilly area) through
provision of MMU (as per norms of NHM).
b) All uncovered eligible Households to be
covered under Ayushman Bharat for the
Abhiyan

15
15

<!-- page 16 -->

c)

7. LPG for tribal households –‘PM Ujjwala Yojana' (PMUY) (MoPNG)
Central sector schemes, 100% central grant
All uncovered eligible Households (as per
PMUY) subject to new targets and fund
allocation upon continuation of original
scheme
8. Saksham Anganwadi Centre – POSHAN 2.0 (MoWCD)
a) 60:40; 90:10 (in NE & Himalayan); 100 in
a) Provision of funds of ₹12 lakh each for
UT’s without legislature.
2000 new Anganwadis to be sanctioned
through DAPST funds with MoWCD. (100
b) ₹12.00 lakh per AWC out of which ₹8.00
% Central share)
lakh from MGNREGS, ₹2.00 lakh under
15th FC funds, and ₹2.00 lakh by MWCD
b) Provision of ₹1 lakh for up-gradation of
per AWC to be shared between Centre and
existing AWC to Saksham AWC for 6000
States/Uts in the prescribed cost sharing
existing mini AWCs as per existing norms.
ratio.
9. Construction of Hostels – Samagra Shiksha Abhiyaan (DoSEL)
As per specified standards and State Schedule a) Construction of hostel along with provision
of Rates (SSOR) or CPWD Rates, whichever is
of recurring grants as per the norms of
lower.
Samagra Shiksha Abhiyaan (SSA) for such
hostels.
10. POSHAN Vatikas in EMRS – (Ministry of AYUSH)
No extant norms
Setting up of Poshan Vatikas in EMRSs from
allocated DAPST funds
11. Telecom connectivity – Universal Service Obligation/Bharat Net (DoT)
Coverage of unconnected villages
a) Saturation coverage of all uncovered tribal
villages with 4G connectivity
12. Skill development in Tribal Areas – Skill India Mission (Existing Schemes) (MSDE)
100% Grant-in-Aid to NGOs/ Institutions on
a) Setting up of Skilling center in tribal
annual basis and onetime non-recurring cost
districts under the scheme subject to
approval of the original scheme of Skill
India Programme by the Cabinet.
b) Capacity building and business
development of VDVKs, Tribal groups etc
subject to approval of the original scheme
of Skill India Programme by the Cabinet
13. Digital Initiatives- Digital India Programme –MEITY
100% Central Funding (Central sector Scheme) Provision of funds ₹50 Cr every year
(average) for digital initiative from available
DAPST funds

16

<!-- page 17 -->

Existing norms of the scheme
Norms of the scheme as per Mission
14. Sustainable Agriculture for FRA beneficiaries (various schemes)- MoAFW
a) Northeast & Himalayan States: 90% Central a) Allocation of funds ₹500 Cr per year
and 10% State Share
(average) for five years with the total of ₹
b) All other states: 60% Central and 40% State
2500 Cr from DAPST funds of DoAFW for
Share
providing sustainable agriculture support to
UTs: 100% Central Share
FRA patta holders
b) Upto 10 % beneficiary contribution
c) Schematic Guidelines to be framed
15. Aquaculture for tribal fisherman / CFR holders -Pradhan Mantri Matsya Sampada
Yojana (PMMSY) – Department of Fisheries (MoFAHD)
i) 60% of the project/unit cost for
a) Allocation of existing DAPST funds (₹375
SC/ST/Women.
Cr) to support tribal fishermen and CFR
holders for the promotion of aquaculture
ii) Sharing ratio:
under the Abhiyan
(a) The NE& the Himalayan States: 90:10
(b) Other States: 60: 40
b) Upto 10 % beneficiary contribution.
I UT: 100%
c) Schematic Guidelines to be framed
16. Animal Husbandry support to FRA beneficiaries – National Livestock Mission (NLM)
– Department of Animal Husbandry & Dairying
The NLM scheme has Centrally Sponsored and a) Allocation of DAPST funds ₹75 Cr to
Central sector component with 50% subsidy for
support FRA beneficiaries for 5 years
b) Upto 10 % beneficiary contribution
the entrepreneurs.
c) Schematic Guidelines to be framed
17. Capacity building focused on FRA –Rashtriya Gram Swaraj Abhiyan (RGSA) –MoPR
Sharing Ratio of 60:40 Central: State, except
Allocation of DAPST funds of ₹30 crore for
NE Hilly States and UT of J & K Share ratio 90: Capacity Building and Training of Gram
10
Sabhas, SDLC, DLC and State level officers
on FRA
18. Responsible Tourism – Swadesh Darshan Scheme-Tribal Life tourism (Ministry of
Tourism)
Central Sector Scheme
a) Responsible Tourism scheme with Home
Stays for tribal areas under the scheme of
Swadesh Darshan.
b) 100% cost to be borne by Ministry of
Tourism (Central Sector Scheme)
c) Provision of funds for the scheme out of
allocated DAPST funds
d) Provision of upto ₹5 lakh (for new
construction) / upto ₹3 lakhs (for
renovation) / home stay to 1000 Tribal
Homestays, and ₹5 lakh for related village
community requirements.
e) Schematic Guidelines to be framed
Existing norms of the scheme

Norms of the scheme as per Mission
17

<!-- page 18 -->

19. Multi sectoral Interventions –Expansion of SCA to Tribal Development – PMAAGY
(MoTA)
₹20.39 lakhs for integrated development of village-Enhancing the scope of PMAAGY by
inclusion of other interventions:
a) Provision for 100 Tribal Multipurpose Marketing Centres
b) Improving infrastructure of Ashram Schools, Hostels, Govt./State Tribal Residential schools
c) Setting up of Centre of Competence, and counselling support/awareness for Sickle Cell
Disease (SCD)
d) Digitization and support to FRA claim process, setting up of FRA Cells including
formulation &implementation of CFR Management Plans
e) Annual incentives totaling ₹20 Cr for best performing Tribal districts.
f) Inter-se allocation among various components to be decided based on actual requirements.
g) Project management cost, IEC etc.
h) An allocation of ₹5013 Cr for the period 2026-27 to 2028-29 and amount of ₹4000 cr for the
period FY 2024-25 to 2025-26 (Finance cycle 2021-26).
Sanction of 01 additional post of Joint Secretary

18

<!-- page 19 -->

9. Implementation Plan
Phase 1 Comprehensive Baseline Assessment and Beneficiary Identification
Objective- Establish a detailed understanding of existing conditions in target villages to inform precise planning and
implementation.

Data Mapping:
Utilize the PM GatiShakti
Portal to map all 63,843
target villages, ensuring
accurate geospatial
representation.

Data validation &
Needs Assessment Workshops:
Updation of data:
• Organize community meetings involving Gram Sabhas,
• Cross-reference
local tribal Pradhans /leaders, and NGOs.
data from the
• Document unique cultural, linguistic, and socioAntyodaya
economic traits of the STs to tailor interventions
Mission (AM) to
accordingly.
identify
infrastructure and
service gaps.
• Validate and
update data with
on-ground surveys.

Expected Outcomes
•

•

•

A comprehensive
database of target
villages and
beneficiaries.
Clear identification
of critical gaps in
infrastructure,
education,
healthcare, and
livelihoods.
Enhanced
community
engagement and
ownership from the
outset.

19

<!-- page 20 -->

Phase 2 Establishment of Inter-Ministerial Coordination and Convergence Mechanisms

Objective- Create a robust framework for seamless collaboration among the 17 participating ministries and
departments
• Create a robust framework for seamless collaboration among the participating ministries and departments at
all levels- the central, state and district levels based on a Cabinet approval facilitated by MoTA.
• Formation of the mission convergence committee, mission steering committee, mission support cell etc.
• Constitution of nodal officers of state level apex committee, state level PMUs, District Dharti Aaba units and
block level implementation teams.
• Scheduling Regular Coordination and inter- ministerial Meetings to review progress and address challenges
in the initiation of the mission.
• Leverage the use of social media and conduct IEC activities to disseminate information about the Abhiyan.

Expected Outcomes
•
•

•

Streamlined decisionmaking and resource
allocation.
Elimination
of
redundant efforts and
duplication
across
ministries.
Enhanced synergy and
unified
approach
towards
tribal
development.

20

<!-- page 21 -->

Phase 3 - Resource Mobilization and Customized Scheme Alignment

Expected Outcomes

Objective Ensure adequate funding and tailor existing schemes to meet the specific
needs of tribal communities under the mission.
Based on learnings from PM JANMAN, Recognize the Under allocation, Underutilization and Notional
expenditure of fund available under DAPST (>1.2 lakh crore/year) and State Tribal Sub Plan.
Targets for each Ministry to be planned with assured budgetary allocation
Secure Funding Sources
o Utilize DAPST grants from various ministries and departments to fund interventions.
o Cover any funding shortfalls under specific schemes using the ministry's total DAPST allocation.
o Address further shortfalls by reallocating savings from DAPST according to the new framework
proposed by NITI Aayog, either to the concerned sectoral ministry or the Ministry of Tribal Affairs.
Establish Separate Budget Lines
o Ministries and Departments implementing activities under the Mission should open separate budget
lines within the respective schemes covered by DAPST funds.
o Name these budget lines Dharti Aaba Janjatiya Gram Utkarsh Abhiyan to earmark funds
specifically for the Abhiyan. This will ensure tracking of physical and financial progress.

•
•

•

Adequate and timely
funding for all
interventions.
Schemes customized
to address unique
challenges of tribal
areas.
Transparent financial
management and
accountability.

Include in Expenditure Profile
o The Budget Division, DEA, will create a facility in the UBIS system.
o Concerned Ministries and Departments should input the necessary information, including fund
allocations for this scheme.

21

<!-- page 22 -->

Allocate and Disburse Funds
o Follow the scheme guidelines for allocating and disbursing funds to State Nodal Departments and
implementing agencies.
o Adhere to instructions issued by the Ministry of Finance as they are updated.
Manage Operation and Maintenance
o Sectoral ministries are responsible for the ownership, operation, and maintenance of assets as per their
scheme guidelines.
o Adequately project budget provisions at the Revised Estimate (RE) stage and throughout the Abhiyan
to ensure timely release of funds.

22

<!-- page 23 -->

Phase 4 Decentralized Implementation at State, District, and Block Levels

Expected Outcomes

Objective Execute interventions efficiently on the ground through robust state, district, and
block-level mechanisms.
State-Level Execution:
• Chief Secretaries to lead mission implementation; Principal Secretaries of Tribal Welfare as conveners.
• Establish State-Level Apex Committees (SLAC) for oversight.
• Form State PMUs within Tribal Welfare Departments for coordination.
District-Level Operations:
• District Collectors to act as Nodal Officers leading District Dharti Aaba Units.
• Set up District-Level Committees for multi-departmental collaboration.
• Implement village camps, IEC activities, and saturation drives.
Block-Level Implementation:
• Form Block-Level Implementation Teams (BLIT) with officers from various departments.
• Assign specific habitations to officers for focused attention.
• Facilitate beneficiary applications and oversee construction projects.

•

•

Efficient on-ground
execution with active
local participation.
Enhanced
accountability through
decentralized
responsibility.
Saturation of services
and facilities in all
target villages.

Community Engagement and Mobilization:
• Involve local Tribal leaders, research institutes, ITDAs and NGOs in planning and execution.

23

<!-- page 24 -->

Phase 5 Scaling & Monitoring
Objectives- Establish a comprehensive system to monitor progress, evaluate impact, and incentivize performance.

Integrated Monitoring Systems:
• Link all sectoral ministry portals with the PM GatiShakti Portal for real-time data.
• Develop a Dharti Aaba Janjatiya Gram Utkarsh Abhiyan Mission Dashboard for consolidated monitoring at all
levels.
Key Performance Indicators (KPIs):
• Define specific KPIs for each intervention and set timeline-based targets with monthly, quarterly, and annual
milestones.
Regular Reviews and Audits:
• Conduct monthly district-level reviews chaired by District Collectors.
• Organize bi-weekly block-level meetings to address challenges.
• Implement third-party evaluations and social audits.
Performance Ranking and Recognition:
• Establish a ranking system for districts based on KPI progress.
• Recognize and reward top-performing districts and ministries.
• Share best practices to encourage replication.
Feedback and Grievance Redressal Mechanisms:
• Set up helplines and online portals for beneficiary feedback.
• Ensure timely grievance resolution through dedicated teams.

24

<!-- page 25 -->

Phases of Implementation- Dharti Aaba Janjatiya Gram Utkarsh

Phase 2

Phase 3

Phase 4

25

<!-- page 26 -->

10. Convergence with central sector schemes
The Dharti Aaba Janjatiya Gram Utkarsh Abhiyan employs a convergence-based, "whole-ofgovernment" approach, ensuring that multiple ministries collaborate synergistically to deliver
impactful, cost-effective, and sustainable outcomes for tribal communities. This integrated
framework is designed for the following key reasons:

Rationale of Convergence
Architecture
The rationale for proposing the placement of
Sub-Missions
within
the
relevant
administrative ministries/departments, rather
than implementing the entire mission solely
through the Ministry of Tribal Affairs, is based
on the following factors:
a. Domain Expertise: Ministries that have
been implementing specific schemes in
areas such as rural housing, drinking water,
sanitation, health, and nutrition possess the
necessary domain expertise. This ensures
the achievement of the most cost-effective
and impactful outcomes.
b. Inclusive
Development:
Tribal
communities constitute nearly one-tenth of
the country’s population. It is, therefore,
imperative for each participating ministry
to integrate these communities into their
development
processes,
thereby
maximizing the social and economic
benefits. The administrative machineries
of these ministries are better positioned to
facilitate this integration.
c. Ongoing
Monitoring:
Continuous
monitoring is essential to prevent
marginalized groups from falling back into
poverty and vulnerability. Effective
monitoring and evaluation can only be
achieved through the direct involvement of
the
administrative
ministries
and
departments.

Mission Governance and Structure
for Convergence
The Dharti Aaba Janjatiya Gram Utkarsh
Abhiyan will be housed under the Ministry of
Tribal Affairs and led by a Mission Director.
The program will be supported by a dedicated
team comprising administrative, technical,
and financial personnel to ensure smooth and
effective implementation.
a. Mission Nodal Offices, headed by
Additional/Joint Secretary-level officers,
will be established within the respective
administrative ministries.
b. These offices will function under at least
Joint Secretary-level officers. A Directorlevel officer from the Department of
Expenditure and NITI Aayog will also be
part of the Mission.
c. The Mission Headquarters within the
Ministry of Tribal Affairs will maintain
regular coordination with the Directors of
the Missions to ensure the formulation of
action plans, smooth implementation, and
monitoring of both financial and physical
progress.
Similarly, the above administrative structures
will be followed at the State & District-level.

26

<!-- page 27 -->

At the state level, the Chief Secretaries of the
respective states will lead the mission, with the
Principal Secretary of Tribal Welfare serving
as the convener. Senior officers from sectoral
departments will act as Nodal Officers,
responsible for supervising,
ensuring
convergence,
and
monitoring
the
implementation of the mission. At the district
level, District Collectors will be designated as
Nodal Officers, tasked with overseeing,
coordinating, and monitoring mission
execution. At the block level, the Block
Development Officer, or a similarly designated
official (such as ITDP/MADA), will assume
the role of Nodal Officer, ensuring the
effective implementation of the mission’s
objectives within specific blocks or regions.
A Project Management Unit (PMU) will be
established within the Department of Tribal
Welfare of the State Government to facilitate
coordination and monitoring between
Government of India (GOI) departments, statelevel departments, and across various
ministries and states.

High Powered Committee (HPC)
A High-Powered Committee will be
established under the chairpersonship of the
Hon'ble Minister of Tribal Affairs. The
committee will convene twice during each
financial year, preferably once in each half.
However, special meetings may be called by
the Chairperson as needed.

Mission Convergence Committee
A committee will be constituted under the
chairpersonship of the CEO, NITI Aayog,
with the following members: Secretaries of
the sectoral ministries, Additional/Joint
Secretary of the Aspirational District/Block
Program, Advisor DAPST, CEO of the
National Health Authority, CEO of UIDAI,
Joint Secretary of the Department of Financial
Services
(PM
Jan
Dhan
Yojana),
Additional/Joint Secretary of Agriculture (PM
Kisan Samman Nidhi), Additional/Joint
Secretary of Food and Public Distribution
(PM Garib Kalyan Yojana), and Convenor
Joint Secretary of the Ministry of Tribal
Affairs (Mission Director).

Mission Steering Committee
The Mission Steering Committee will be
formed under the co-chairmanship of the
Secretary of Tribal Affairs, along with the
Secretaries responsible for the interventions of
their respective schemes. The committee will
convene as needed for the mission, and once
the mission is stabilized, the meeting
frequency will be formally defined. Functions
of the Mission Steering Committee:

27

<!-- page 28 -->

To monitor and guide the concerned Ministries/Departments in the implementation of
activities under the Mission.
ii. To oversee the progress of sanctioning and construction of infrastructure related to the
Mission.
iii. To review the implementation progress of the Mission and, where necessary, recommend
modifications.
i.

Mission Support Cell
To effectively support the Ministry of Tribal Affairs (MoTA) in achieving project outcomes and
addressing specific project management requirements at the Ministry level, a Dharti Aaba
Janjatiya Gram Utkarsh Abhiyan Mission Support Cell will be established. This cell will include
strategy, program, and technical support from domain experts and other resource persons. It will
be responsible for evidence-based strategic planning and impact monitoring, ensuring
convergence of programs and schemes across sectors, and developing digital frameworks, among
other tasks.

Mission Apex and Implementation Committee
Each state will have both a state-level and a district- level committee, supported by
corresponding state- level and district-level Project Management Units (PMUs).

(District Dharti Aaba Unit)

28

<!-- page 29 -->

State Level Apex Committee (SLAC)
The State-Level Apex Committee (SLAC) will be established under the chairmanship of the Chief
Secretary, with the Secretary of the Tribal Welfare Department serving as the convener and nodal
department. The committee will also include other Secretaries from key departments as members.
Other Secretaries associated with the implementation of allied schemes, as detailed in paragraph
5.2 above, will also be co-opted into the committee. The committee will oversee the work of
DMs and also recognize the best performance. The committee will conduct monthly, quarterly
reviews to assess progress, address challenges, and provide support for convergence and advisory
assistance.
State Level PMU
At the State/UT level, the Tribal Welfare/Development Department will establish a State Project
Management Unit (SPMU). The SPMU will assist the Tribal Welfare Department with overall
coordination and communication with Mission stakeholders. Additionally, it will be responsible
for reviewing the deliverables outlined in the action plans of relevant line departments under PM
Janjatiya Unnat Gram Abhiyan. The Principal Secretary should put in place a PMU within the
first month of the Mission.
District Level Committee
A District-Level Committee (District Dharti Aaba Unit), chaired by the District Collector, will be
responsible for planning, executing, and monitoring 25 critical interventions related to the
mission. Representatives from line ministries at the district level will oversee the implementation
of activities specific to their respective ministries or departments.
The District Dharti Aaba Unit will be responsible for the following.
Registration and Application: Register and process applications for eligible
beneficiaries under each scheme covered by the mission.
ii. Project Planning and Execution: Prepare Detailed Project Reports (DPRs), submit and
seek approval for projects, ensure timely utilization of funds as per the guidelines of
respective Ministries, and maintain construction quality and material standards in
accordance with each scheme's guidelines.
iii. Land Allocation: Provide suitable land for the construction of roads, Anganwadi centers,
hostels, and multipurpose centers.
iv. Data Management: Update data on the Dharti Aaba Janjatiya Gram Utkarsh Abhiyan
platform and report progress on the award portal.
v. Field Visits and Coordination: Conduct field visits, address issues related to scheme
implementation, and manage capacity building, training, and related activities.
vi. Coverage and Saturation: Ensure that all households and habitations are covered by
the 25 specified interventions.
vii. Funds Management: Ensure the timely release of funds to implementing schemes and
comply with Public Financial Management System (PFMS) requirements.
i.

29

<!-- page 30 -->

Block Level Implementation Team (BLIT)
At the block level, officers such as the Welfare Officer, Block Education Officer, Block
Programme Manager (NRLM), and Child Development Project Officer will each be designated
as nodal officers for 4-5 habitations by the District Collector. They will be supported by 2-3
additional officers from relevant line departments. This team will be responsible for the
comprehensive implementation of various interventions designed for households and the
community.
For each habitation, the dedicated team will:
i. Identify beneficiary families who have not received their entitlements.
ii. Facilitate the application process for relevant schemes.
iii. Assist in securing land and overseeing the construction and maintenance of Multipurpose
Centers (MPCs), Anganwadi centers, and hostels.
iv. Ensure that Pattas are issued to Forest Rights Act (FRA) beneficiaries.
v. Help beneficiaries obtain other essential documents and benefits, such as Aadhar cards,
Ayushman Bharat cards, MNREGS cards, and Kisan Samman Nidhi.
vi. These officers will coordinate with sectoral ministries and departments to ensure effective
implementation of the plan in their respective habitations. Additionally, they will facilitate
awareness generation among Scheduled Tribe (ST) beneficiaries, conduct community-level
meetings with local headmen, and support capacity-building programs.

30

<!-- page 31 -->

11. Monitoring & Evaluation Framework
Physical and Financial Progress Tracking
Real-Time Monitoring via Gati-Shakti Portal: Each line Ministry/Department will be
responsible for updating the progress of their respective schemes on both the PM GatiShakti portal
and the Public Financial Management System (PFMS). This will be done through the Scheduled
Tribe Component Management Information System (STC-MIS), managed by the Ministry of
Tribal Affairs (MoTA), ensuring streamlined tracking and accountability.
Dynamic Habitation-Level Data: The portals of the sectoral Ministries will be integrated PM
Gatishakti Portal ensuring that the data reflects the real time data of interventions (through API)
across tribal habitations.
Village-wise data will be regularly updated at key stages, including:
1. Sanctions (approvals and budget allocations),
2. Instalments (fund disbursements),
3. Physical Completion (project implementation and delivery).
The portals of sectoral Ministries will be integrated with the PM GatiShakti Portal, ensuring realtime data updates on interventions through API. This seamless integration will provide up- to-date
tracking of progress across tribal habitations, enhancing transparency and coordination across
Ministries.

Inter-Ministerial Reviews and Coordination Meetings
National-Level Reviews: Regular high-level meetings, chaired by the Ministry of Tribal Affairs
and involving secretaries from participating ministries, will be conducted to assess progress, tackle
challenges, and adjust action plans as needed to ensure smooth implementation.
State-Level Coordination: The Ministry/ Department of Tribal Affairs will regularly chair highlevel meetings with secretaries from participating ministries to review progress, address
challenges, and refine action plans. These meetings will ensure effective coordination and smooth
implementation of the mission.
District and Block-Level Reviews: District-Level Committees (DLCs), led by the District
Collector, will meet monthly to monitor progress, address bottlenecks, and ensure timely delivery
of interventions. At the grassroots level, Block-Level Implementation Teams (BLITs) will hold biweekly meetings to coordinate and streamline local implementation efforts.

Training and Capacity Building
Regular Training Sessions: Regular capacity-building programs will be organized for local
authorities, implementing officers, and community stakeholders to enhance their effectiveness.
The responsible ministry or department will track and report the number of training sessions held,
along with attendance records, to ensure continuous skill development and readiness at all levels
of implementation.
31

<!-- page 32 -->

Performance Monitoring: The Ministry of Tribal Affairs will collaborate with state-level Project
Management Units (PMUs) to oversee and periodically review training sessions. This
collaboration will help identify any skill or capacity gaps that need to be addressed, ensuring that
all individuals involved in implementation are adequately equipped and capable.
Training Feedback Mechanism: A feedback system will be implemented to allow participants
to assess the quality and effectiveness of the training. This feedback will be used to enhance future
capacity-building initiatives.
Training

Capacity Building

Community Outreach

The respective Line
Ministries/Departments, in
collaboration with State
Governments and Nodal
Departments, conduct training
for all functionaries/personnel
involved in the implementation
of Unnat Gram Abhiyan.

The respective Line Ministries,
State Government departments
and non-governmental
organisations working with
STs for Capacity Building,
situational Analysis, impact
assessment, and IEC
awareness for their
interventions

The ministry concerned with
coordination and the line
departments of the State
Government will prepare and
execute the strategy for the IEC
campaign.

Impact Assessment
Third-Party Evaluations: The Ministry of Tribal Affairs (MoTA) will engage a third-party
agency to conduct regular mid-term and end-term evaluations of the mission, specifically
assessing its socio-economic impact on the targeted tribal villages.
Collaboration with NITI Aayog: To enhance the quality of evaluations, NITI Aayog could
partner with MoTA for in-depth assessments of key sectors like education, healthcare, and
livelihoods. This collaboration will ensure comprehensive and impactful evaluations.
Social Audits: Regular social audits will be carried out to verify that services and benefits under
the mission effectively reach the intended beneficiaries. These audits will enhance transparency
and accountability, offering a clear measure of the mission’s success on the ground.
Impact KPIs: Key Performance Indicators (KPIs) for impact evaluation will encompass
improvements in living standards, reduced poverty rates, better access to healthcare and education,
and sustainable livelihood enhancements.

32

<!-- page 33 -->

Outcome Monitoring through KPIs on PM GatiShakti Portal
KPI Tracking: The mission will establish precise Key Performance Indicators (KPIs) for each
intervention, such as the number of completed pucca houses, villages with full telecom
connectivity, and increases in educational enrolment. These KPIs will be monitored and updated
on the PM GatiShakti Portal to ensure transparent and effective tracking of progress.
Timeline-Based Targets: Each intervention will be tracked against specific timeline targets, such
as 1-month, 2-month, 3-month, and 6-month milestones. This approach will enable early detection
of delays or underperformance and facilitate timely corrective actions.
Data-Driven Decision Making: KPI data collected through the portal will be analysed to guide
decisions on resource reallocation, implement corrective measures, and refine existing strategies
for better outcomes.

Digital Tools and Integration – Dharti Aaba Janjatiya Gram Utkarsh Abhiyan
Dashboard
Function: A real-time monitoring tool, specifically developed for Dharti Aaba Janjatiya Gram
Utkarsh Abhiyan, will track progress across all interventions and key performance indicators
(KPIs) at the national, state, and district levels, ensuring comprehensive oversight and timely
adjustments.
Features: The integration with PM GatiShakti will leverage geospatial data, financial tracking
through PFMS, and KPI monitoring to ensure transparent and efficient service delivery. A publicfacing version of the dashboard will be accessible to citizens and stakeholders, allowing them to
view real-time progress and engage with the mission’s outcomes.

Stakeholder Engagement and Long-Term Sustainability Plan
Stakeholder Consultations: All implementing ministries and departments will regularly consult
with key stakeholders—such as local governments, tribal communities, NGOs, and civil society—
to ensure that interventions are effectively aligned with local needs and priorities.
Asset Sustainability Planning: Each ministry or department will create a long-term sustainability
plan to guarantee the ongoing use, maintenance, and upkeep of assets like roads, schools, and
healthcare facilities developed under the mission. This plan will be crafted in collaboration with
community leaders, local governments, and relevant stakeholders to foster shared responsibility
and ensure community ownership.
Asset Management Systems: A community-based Asset Management System through Common
Property Resource will be established to ensure effective infrastructure maintenance. This
system will include training for local communities on asset upkeep and provide mechanisms for
reporting and addressing any issues that arise
33

<!-- page 34 -->

12. Budget provision and Funding Pattern
The Ministry of Tribal Affairs along with relevant sectoral ministries, will coordinate the budgetary
requirements for the Dharti Aaba Janjatiya Gram Utkarsh Abhiyan with the Ministry of Finance.
They will manage the administration and finalize budget allocations for specific schemes within the
mission.
The Mission will be for a period of 5 years i.e. 2024-25 to 2028-29, covering first 2 years under the
ongoing Finance commission cycle ending in March 2026. The interventions proposed under the
Abhiyan are either continuing schemes as a whole or a part of the continuing scheme. Schemes/
components that receive an approval or continuation over the 16th Finance cycle shall continue being
implemented by the Department/Ministry concerned.
Funding Pattern: The Mission will be implemented through a combination of Centrally Sponsored
Schemes in collaboration with State Governments and UT Administrations, along with Central
Sector Schemes implemented by line Ministries and Departments. Funding for various interventions
will be sourced from the DAPST grants of different ministries and departments. If there is a funding
shortfall under a specific scheme of a ministry, it will be covered by that ministry's total DAPST
allocation. Any further shortfall for the mission will be addressed by reallocating savings from
DAPST in accordance with the new framework proposed by NITI Aayog, either to the concerned
sectoral ministry or to the Ministry of Tribal Affairs.
Separate Budget Line: The respective ministries/Departments implementing activities under the
Mission will open separate budget lines under the respective scheme covered under DAPST funds
allocation with the name of Dharti Aaba Janjatiya Gram Utkarsh Abhiyan for earmarking funds
under the Abhiyan. This shall ensure physical and financial progress of the Abhiyan.
With regard to inclusion of a separate statement on Dharti Aaba Janjatiya Gram Utkarsh Abhiyan in
the Expenditure profile, Budget Division, DEA will create a facility in the UBIS to enable concerned
Ministries/Department to fill up requisite information including fund allocation for this scheme.
Utilization and Disbursement: The allocation and disbursement of funds to State Nodal
Departments and implementing agencies will follow the scheme guidelines and adhere to the
instructions issued by the Ministry of Finance from time to time.
Operation & Maintenance: The respective sectoral ministries will be responsible for the
ownership, operation, and maintenance of assets in accordance with the guidelines of the respective
schemes. They shall also adequately project Budget provisions at RE stage and during the period of
the Abhiyan to ensure timely release of funds for the Abhiyan.

34

<!-- page 35 -->

ANNEXURES

<!-- page 36 -->

35

<!-- page 37 -->

36

<!-- page 38 -->

3

37

<!-- page 39 -->

38

<!-- page 40 -->

39

<!-- page 41 -->

40

40

<!-- page 42 -->

41

<!-- page 43 -->

KPI - MEASURING OUTPUTS AND OUTCOMES

Annexure-2

Interventions wise Key Performance Indicators (I-KPIs)
Outcome 1: Ensuring that the ST community has access to Pucca housing along with Toilets.
Outcome Indicator: Number of Pucca Houses Constructed for the Tribal Households.
Output

Indicator (s)

Means of Verification

20 Lakhs Pucca Houses

No. of Houses sanctioned to

PMAY-G MIS (AWAS Portal),

provided to ST households

ST households

Gatishakti Portal, Location

by 2029.

No. of FTO Generated for ST

tagging, completion certificates,

HHs.

and photographs of the

No. of ST HHs received 1st

constructed Pucca houses. Site

and 2nd Tranche Fund.

visits and inspections by Nodal

No. of ST HHs received final

Officers etc.

trench fund.
No. of ST HHs received
completion certificate.
Outcome 2: Tribal Villages/habitations has access to all whether connectivity roads.
Outcome Indicator: Number of Targeted ST Villages to access to all whether road.
Output

Indicator (s)

Means of Verification

25000 KM all wheather

No. of Villages/habitations

REAT Reports/MIS, Gio SADAK

Roads constructed linking to

identified for Road

portal, completion certificates,

approximately 21500 Target

connectivity.

Field surveys and inspections by

ST villages.

No. of Kilometre of Road

authorities to verify the existence

sanctioned for ST

and quality of the constructed

habitations/Villages

roads on the selected ST villages.

No. of Kilometre Road
construction completed.
Outcome 3: ST Villages/habitations has access to drinking water and pipe water connectivity.
Outcome Indicator: Number of ST habitations/Villages to access pipe water connectivity/
Functional Household Tap Connection for Drinking water.
Output

Indicator (s)

Means of Verification

Every eligible ST HHs in

Number of FHTCs provided

E-jalshakti IMIS Reports, JJM

42

<!-- page 44 -->

63,843 villages

to ST households

Reports on Village Wise PWS

Number of FHTCs in ST

Report, Gatishakti Portal, On-site

Households delivering water

assessments conducted by Nodal

in adequate quantity.

officer, reports of DLCC and State

5000 habitations/villages ≤

Number of ST

Govt.

20 ST HHs have been

habitations/Villages ≤ 20 ST

equipped with pipe water

HHs connected through PWS.

connectivity and Functional
Household Tap Connection.
Outcome 4: STs have enhanced access to healthcare services directly within their localities and
all eligible ST households covered through Ayushman Card.
Outcome Indicator: Number of ST habitations/Villages covered with Mobile Medical Units
(MMU) and Number of ST HHs covered under Ayushman Card.
Output

Indicator (s)

Means of Verification

1000 MMUs operating in ST

No. of MMUs sanctioned for

HMIS reports, MoH&FW reports

Habitation/Villages to cater

ST Villages.

including RHS surveys, updations

healthcare need of STs.

No. of MMUs Operational

in Gatisakti portals, GPS tagging

and giving services.

of MMUs, Reports of MMUs

No. of villages/habitation

uploaded by districts, Monitoring

covered by MMUs.

visit by Nodal officers etc.

No. of people screened/OPD
and referrals.
ST HHs covered under

No. of ST HHs covered under Ayushman Bharat portal, HMIS

Ayushman Card

Ayushman Card

Outcome 5: The quality of school education for ST students is elevated through upgradation of
existing Ashram/ Govt schools and dedicated residential facilities in schools.
Outcome Indicator: Number of Ashram/ Govt schools upgraded and number of hostels
constructed in ST villages and number of ST students using these facilities.
Output

Indicator (s)

Means of Verification

1000 residential hostels to be

No. of location/school

Prabandh portal of samagra

constructed in exiting

identified

shiksha, UDISE+ reports,

schools in tribal areas for

No. of residential hostels

GatiShakti portal, Monitoring visit

43

<!-- page 45 -->

elevated school education for

sanctioned

ST students.

No. of residential hostels

by Nodal officers etc.

construction completed
No. of ST students
accommodated in these
hostels.
Up-gradation of existing

No. of proposal sanctioned

State Proposals, UCs, Progress

Ashram Schools/ Govt.

for upgradation of schools.

report, Field visit by State TWD

schools in tribal areas

Number of

and MoTA officials.

Ashram/Government schools
upgraded successfully.
Outcome 6: Strengthen nutritional content, delivery, outreach in Tribal habitations/Villages.
Outcome Indicator: Number of AWC constructed in Tribal villages and number of tribal
children 0-6 years registered and no. of pregnant and lactating tribal women access the ICDS
services.
Output

Indicator (s)

Means of Verification

2000 new Saksham AWC

No. of tribal habitations/

Online ICDS MIS, WCD

constructed and upgradation Villages identified for AWC

dashboard, report form State

6000 existing AWCs to

intervention

Govt./ DLCC, Gatishakti portal,

Saksham AWCs in targeted

No. of AWCs sanctioned for

Monitoring visit by Nodal officers

tribal villages to strengthen

Tribal habitations/Villages

etc.

nutritional content, delivery,

No. of AWC sanctioned for

and outreach.

upgradation into Saksham
AWCs
No. of AWC construction &
Upgradation completed
No. of Saksham AWC
operational and providing
ICDS services to tribal
communities.

Outcome 7: 700 Poshan Vatikas (Nutri-Gardens) in EMRS schools contribute to a diversified
diet by supplying fresh vegetables and fruits, thereby improving the overall health and nutrition
of the students and tribal students gain hands-on knowledge about farming, sustainable

44

<!-- page 46 -->

agriculture, and nutrition.
Outcome Indicator: An increase in the variety of food groups consumed by students (fruits,
vegetables, legumes, etc.) and increase in the no. of tribal students who demonstrate knowledge
of sustainable agriculture, gardening practices, and nutrition after being involved in the NutriGarden initiative.
Output

Indicator (s)

Means of Verification

700 Poshan Vatikas (Nutri- No. of Poshan Vatikas (Nutri- MIS report from MoAYUSH,
Gardens) functional in EMRS Gardens) sanctioned for EMRS data uploaded in Gatishakti
schools

schools

portal,

Monitoring

visit

by

No. of Poshan Vatikas (Nutri- Nodal officers etc.
Gardens) established in EMRS
schools
Outcome 8: 25 Lakhs Tribal Household using clean energy (LPG) for cooking
Outcome Indicator: No. of LPG connections distributed and no. of tribal HHs use LPG as
primary source of cooking.
Output

Indicator (s)

Means of Verification

25 Lakhs LPG connection

Number of LPG connections

MIS Pradhan Mantri Ujjwala

distributed to eligible ST

sanctioned.

Yojana, report of State

HHs in targeted villages

Number of LPG connections

implementing agencies, data

distributed to tribal households.

uploaded in Gatishakti portal etc.

Outcome 9: Connectivity and communication infrastructure in tribal villages is significantly
improved through the installation of mobile towers, fostering enhanced connectivity and
communication.
Outcome Indicator: Number of Tribal villages having mobile connectivity
Output

Indicator (s)

Means of Verification

5000 unconnected tribal

No. of Mobile Service

USOF Dashboard, GatiShakti

village connected through

Village/Habitation Sites

Platform, Monthly progress

4G mobile technology

identified

reports and Quarterly review

fostering enhanced

No. of Mobile towers

reports submitted by the Universal

connectivity and

sanctioned in tribal Villages

Service Provider, Monitoring visit

communication.

No. of Mobile tower installed

by Nodal officers etc.

45

<!-- page 47 -->

in tribal Villages
No. of tribal villages covered
with mobile connectivity
Outcome 10: Improved access to electricity is achieved for unelectrified tribal households and
public institutions not covered through grid.
Outcome Indicator: Number of tribal HHs and public institutions access to electricity
Output

Indicator (s)

Means of Verification

Electricity is achieved for

No. of ST HHs and public

National Portal for Roof Top

unelectrified tribal

institutions registered

Solar, DISCOM portal, GatiShakti

households and public

No. of ST HHs and public

portal, MPR submitted by

institutions not covered

institutions sanctioned roof-

MNERE etc.

through grid.

top solar solutions through
scheme
No. of tribal HHs & public
institutions access to
improved electrification.

Outcome 11: Identification and electrification of missed-out houses, leading to the reissuance
of certificates for 100% coverage
Outcome Indicator: Number of tribal Village/Habitations with access to grid electrification.
All left-out tribal villages

No. of tribal

MoP MIS, RDSS MIS,

(feasible) covered under grid

habitations/Villages

GatiShakti portal, MPR

electrification.

identified for electrification

submitted by MoP, Monitoring

No. of feasibility

visit by Nodal officers etc.

assessment study done
No. of tribal
habitations/villages
connected through Grid
power
Outcome 12: Tribal youth, SHGs, and VDVKs acquire skills in traditional and modern
vocations, unlocking market potential for sustainable employment and self-reliance.
Outcome Indicator: Number of Tribals youths/ SHGs/VDVKs covered under skill centers,
RSETIs, DICs etc.
Output

Indicator (s)

Means of Verification

46

<!-- page 48 -->

Tribal youths/ SHGs/

No. of tribal

VDVKs acquired skills in

youth/SHGs/VDVKs enrolled MPR submitted by MSDE,

various traditional/modern

in skill development

Monitoring visit by Nodal officers

vocations through skilling

programs (through Skill

etc.

center in tribal districts.

centers, RSETIs, DICs, etc.).

MSDE MIS, GatiShakti portal,

No. of tribal
youth/SHGs/VDVKs
supported in accessing
financial services
(microcredit, loans, etc.) for
starting their own ventures.
No. of tribal
youth/SHGs/VDVKs placed
in jobs or self-employed in
vocations after completing
training programs.
Outcome 13: Approximately 200,000 FRA patta holders have improved their livelihoods by
practicing sustainable agriculture and adopting natural farming methods.
Outcome Indicator: 2 lakhs FRA patta holders practicing sustainable agriculture through
adopting natural farming methods.
Output

Indicator (s)

Means of Verification

Around 2 lakhs FRA patta

No. of FRA patta holders’

MoAFW MIS reports,

holders adopting sustainable

beneficiaries included in

Agricultural census, MPRs from

agricultural practices

various MoAFW schemes

state nodal departments, data

through multiple schemes of

Increase in average income of uploaded in Gatishakti Portal etc.

MoAFW

FRA patta holders from
sustainable agriculture
(percentage or absolute
value).

Outcome 14: Tribal beneficiaries, including FRA patta holders, have improved their socioeconomic conditions by engaging in pisciculture and livestock activities.
Outcome Indicator: No of tribal beneficiaries adopting pisciculture and livestock activities.
Output

Indicator (s)

Means of Verification

47

<!-- page 49 -->

10,000 CBOs/SHGs and 1

No. tribal beneficiaries

lakhs tribal individual

(including FRA patta holders) nodal departments, data uploaded

engaged in pisciculture

enrolled in pisciculture and

activities.

livestock activities.

And 8,500 tribal SHGs/

No. of tribal households

individuals engaged in

reporting improved food

livestock activities.

security or nutrition due to

MIS reports, MPRs from state
in Gati-shakti Portal etc.

pisciculture and livestock
activities.
Outcome 15: Tribal households engaged in homestay tourism are gaining economic benefits
while also promoting local art, traditions, culture, architecture, and food practices.
Outcome Indicator: No. of Tribal HHS engaged in homestay tourism activities.
Output

Indicator (s)

Means of Verification

1000 tribal homestay

No. of tribal households

MIS reports of Mo Tourism,

tourism operational in

participating in homestay

MPRs from state nodal

targeted ST villages.

tourism.

departments, data uploaded in

No. of tourist footfall to tribal

Gati-shakti Portal etc.

homestays.
No. of tribal HHs engaging in
cultural activities pertaining
to tourism.(e.g., local art,
traditional performances,
food experiences).
Outcome 16: State, district, and block officials, as well as PRI members, have increased
awareness and enhanced capacity regarding FRA/CFR/habitat rights and their implementation
processes.
Outcome Indicator: Number of State, district, and block officials participated in trainings and
enhanced capacity regarding FRA/CFR/habitat rights.
Output

Indicator (s)

Means of Verification

All Gram Sabhas and State,

No. of training sessions

MIS reports of MoPR, MPRs from

district, and block officials

conducted for officials and

state nodal departments, data

trained on FRA/CFR act.

PRI members.

uploaded in Gati-shakti Portal etc.

No. of participants reporting

48

<!-- page 50 -->

improved understanding and
capacity in implementing
FRA/CFR/habitat rights.
Feedback from participants
on the effectiveness and
relevance of the training
programs.
Outcome 17: Establishment and operationalization of Tribal Multi-purpose Marketing
Centers (TMMCs) to enhance market access for tribal entrepreneurs and products.
Outcome Indicator: Number of tribal entrepreneurs gaining market access through TMMCs.
Output

Indicator (s)

Means of Verification

100 TMMC functional in

No. of TMMCs sanctioned

State nodal dept. reports, MoTA

tribal blocks/districts.

No. of TMMCs established

dashboard, Gatishakti portal, Geo-

and operational.

tagging on Gatishakti portal,
Monitoring visit by Nodal officers
etc.

49

<!-- page 51 -->

3.States/UTs and District wise Coverage of Villages under the Abhiyan
1. ANDHRA PRADESH
S.No Name of District No. of
Blocks
ALLURI
SITHARAMA
RAJU
2
ANAKAPALLI
3
ANANTAPUR
4
ANNAMAYYA
5
CHITTOOR
6
ELURU
7
KAKINADA
8
KURNOOL
9
NANDYAL
10
NTR
11
PALNADU
PARVATHIPUR
12
AM MANYAM
13
PRAKASAM
SRI SATHYA
14
SAI
15
SRIKAKULAM
16
TIRUPATI
VIZIANAGARA
17
M
18
Y.S.R.
Grand Total
1

No. of
Villages

No. of
Household
(Census-2011)

Total
Population

Total ST
Household

Total ST
Population

22

521

100040

409413

86334

356292

6
3
4
1
9
3
3
2
5
5

10
3
17
1
46
6
7
3
17
7

4346
1429
34690
194
18821
1442
10154
624
18326
4529

17002
6452
142380
659
68689
4964
49966
2678
66548
18465

3458
1045
2431
110
12979
1141
549
413
2520
2741

13435
4722
9924
375
47437
3952
2890
1762
9514
11195

12

165

43154

190404

30087

134020

3

16

12591

55570

2286

10424

3

3

874

3226

461

1707

13
3

34
3

10353
588

45491
2176

8046
446

35646
1675

7

9

2143

8959

1766

7307

3
107

10
878

5379
269677

20610
1113652

825
157638

3173
655450

No. of Household
(Census-2011)

Total
Population

Total ST
Household

Total ST
Population

1789

9663

1473

7941

1463

7921

1410

7646

5679
468
1690

31729
2437
10266

4823
431
1650

27199
2251
10104

553

2932

522

2758

480
1097
6923

2634
5488
44510

385
733
6728

2143
3645
43578

1027

4902

691

3500

2. ARUNACHAL PRADESH
Name of
No. of
No. of
District
Blocks Villages
CHANGLAN
1
6
13
G
EAST
2
5
11
KAMENG
3
EAST SIANG
3
31
4
KAMLE
1
2
5
KRA DAADI
5
26
KURUNG
6
3
3
KUMEY
7
LEPARADA
2
3
8
LOHIT
1
6
9
LONGDING
5
43
LOWER
10 DIBANG
3
6
VALLEY

S.N
o

50

<!-- page 52 -->

2. ARUNACHAL PRADESH
Name of
No. of
No. of
District
Blocks Villages
LOWER
11
2
6
SIANG
LOWER
12
3
19
SUBANSIRI
13 NAMSAI
3
37
PAKKE
14
2
4
KESSANG
PAPUM
15
4
14
PARE
16 SHI YOMI
2
3
17 SIANG
6
13
18 TAWANG
5
15
19 TIRAP
6
24
UPPER
20
4
15
SIANG
UPPER
21
3
3
SUBANSIRI
WEST
22
5
16
KAMENG
WEST
23
5
16
SIANG
Grand Total
84
329

S.N
o

3. ASSAM
S.No Name of
District
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18

BAJALI
BAKSA
BARPETA
BISWANATH
BONGAIGAO
N
CACHAR
CHARAIDEO
CHIRANG
DARRANG
DHEMAJI
DIBRUGARH
DIMA HASAO
GOALPARA
GOLAGHAT
HOJAI
JORHAT
KAMRUP
KAMRUP
METRO

No. of Household
(Census-2011)

Total
Population

Total ST
Household

Total ST
Population

893

5326

662

4009

2912

16773

2600

15318

5281

26590

2895

15457

650

3358

464

2507

2510

13498

1695

9266

478
1995
2369
3708

3334
11621
12006
19322

360
1795
1717
3523

2499
10437
8757
18448

1686

9295

1562

8788

979

5186

843

4501

2680

12125

2087

9531

2108

11834

1876

10613

49418

272750

40925

230896

Total
Population

Total ST
Household

Total ST
Population

2813
226516
2326
69697

415
33193
174
9980

1942
166480
844
58504

No. of
Blocks

No. of
Villages

2
6
2
7

4
168
2
66

No. of
Household
(Census-2011)
610
45455
487
12200

1
4
2
3
2
5
7
5
6
5
4
5
9

2
13
4
110
9
441
63
271
198
49
9
31
128

249
2752
722
26910
5185
49881
10928
18313
36803
11126
3659
6240
25643

1156
14117
3901
134598
25895
283099
55735
97346
186684
61245
17817
35475
121949

199
851
531
21388
381
39925
8389
15533
30473
8851
2225
4831
20856

930
4255
2894
107288
1931
230669
43130
83855
156123
48999
10864
28240
100017

2

9

1845

8642

1261

5924
51

<!-- page 53 -->

3. ASSAM
S.No Name of
District
KARBI
19
ANGLONG
20
KOKRAJHAR
21
LAKHIMPUR
22
MAJULI
23
MARIGAON
24
NAGAON
25
NALBARI
26
SIVASAGAR
27
SONITPUR
SOUTH
SALMARA
28
MANCACHAR
29
TAMULPUR
30
TINSUKIA
31
UDALGURI
WEST KARBI
32
ANGLONG
Grand Total
4. BIHAR
S.
Name of
No.
District
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16

ARARIA
AURANGAB
AD
BANKA
BHAGALPUR
BHOJPUR
BUXAR
GAYA
GOPALGANJ
JAMUI
KAIMUR
(BHABUA)
KATIHAR
KISHANGAN
J
LAKHISARAI
MADHEPUR
A
MUNGER
MUZAFFARP
UR

No. of
Blocks

No. of
Villages

No. of
Household
(Census-2011)

Total
Population

Total ST
Household

Total ST
Population

7
7
9
2
5
8
2
4
6

346
175
180
53
67
36
3
20
40

24903
37057
30992
11783
16165
8008
615
3579
17412

135627
185210
186838
67344
82651
39195
3120
20649
85177

20575
28953
27439
10106
12886
5181
375
3157
13685

113955
145009
167518
58672
66063
25499
1922
18416
67304

1
2
5
8

2
106
43
253

333
30926
7590
54511

1394
156308
42822
268080

188
12571
6189
35104

792
63683
35362
173485

4
147

260
3161

27298
530180

156241
2779667

23134
398999

134205
2124774

No.
of
Bloc
ks
1

No. of
Villages

No. of Household
(Census-2011)

Total
Population

Total ST
Household

Total ST
Population

10

5059

24052

151

729

1
6
3
2
2
2
1
6

1
138
62
34
19
4
19
91

505
24924
44825
17527
15963
2305
9536
28701

3244
133324
239646
120818
111964
14239
64067
159518

9
9780
8450
670
583
51
380
6813

61
51502
44668
4810
4069
320
2628
37453

6
13

62
82

14916
52459

94545
254927

2456
11100

14915
53114

1
2

5
10

876
3871

3866
21859

720
1182

3155
6493

1
3

1
20

4580
2724

24620
12662

10
1673

56
7818

1

1

3296

17690

10

59

52

<!-- page 54 -->

4. BIHAR
S.
Name of
No.
District
17

NAWADA
PASHCHIM
18
CHAMPARA
N
PURBI
19
CHAMPARA
N
20
PURNIA
21
ROHTAS
22
SIWAN
23
SUPAUL
24
VAISHALI
Grand Total

No.
of
Bloc
ks
1

No. of
Villages

No. of Household
(Census-2011)

Total
Population

Total ST
Household

Total ST
Population

1

144

875

11

67

5

127

34812

197123

25196

143176

2
7
5
1
1
1
74

4
27
19
31
2
1
771

7107
20321
9761
11952
1660
661
318485

39532
100560
58186
74075
8930
3606
1783928

127
2235
2589
818
45
11
75070

731
11188
14587
5238
234
65
407136

Total
Population

Total ST
Household

Total ST
Population

192602

27932

133454

5. CHHATTISGARH
S.No Name of District No. of
Blocks
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20

BALOD
BALODA
BAZAR
BALRAMPUR
BASTAR
BEMETARA
BIJAPUR
BILASPUR
DANTEWADA
DHAMTARI
DURG
GARIYABAND
GAURELLA
PENDRA
MARWAHI
JANJGIRCHAMPA
JASHPUR
KABIRDHAM
KANKER
KHAIRGARH
CHHUIKHADA
N GANDAI
KONDAGAON
KORBA
KOREA

No. of
Villages

5

186

No. of
Household
(Census-2011)
40528

4
6
7
3
4
4
4
4
2
5

46
421
377
4
187
102
156
108
4
334

8986
109882
121936
603
29475
25874
41090
24301
504
64877

42175
502231
533805
2836
140802
108372
182220
106691
2265
255573

5577
80936
91017
315
25182
18004
35782
17282
282
36889

26411
371022
401306
1494
120162
75464
158945
76560
1275
147672

3

169

60095

230838

42355

163235

4
8
4
7

21
417
275
552

5709
124504
41421
84444

23607
553000
181678
399602

3733
88682
22738
60259

15510
396629
101923
289018

2
5
5
3

16
352
479
154

2427
89478
124146
39033

10879
432087
522785
162939

1721
68571
85333
21174

7758
333330
360400
89768

53

<!-- page 55 -->

5. CHHATTISGARH
S.No Name of District No. of
Blocks
MAHASAMUN
D
MANENDRAG
ARH
22
CHIRIMIRI
BHARATPUR
MOHLA
MANPUR
23
AMBAGARH
CHOUKI
24
MUNGELI
25
NARAYANPUR
26
RAIGARH
RAJNANDGAO
27
N
28
SAKTI
SARANGARH
29
BILAIGARH
30
SUKMA
31
SURAJPUR
32
SURGUJA
Grand Total
21

6. GOA
Name of
District
NORTH
1
GOA
SOUTH
2
GOA
Grand Total

S.
No

S.
No
1
2
3
4
5
6
7
8

7. GUJARAT
Name of
District
AHMADABA
D
ARVALLI
BANAS
KANTHA
BHARUCH
CHHOTAUD
EPUR
DANG
DEVBHUMI
DWARKA
DOHAD

No. of
Villages

No. of
Household
(Census-2011)

Total
Population

Total ST
Household

Total ST
Population

5

308

65221

266185

28452

116940

3

151

35285

150226

26555

113878

3
3
2
7

245
35
138
316

39951
6368
14716
88907

191123
26716
76668
373756

24864
4604
12206
62746

120204
19362
63913
264733

4
4

105
39

19307
8789

96883
35534

12748
5460

64276
22161

3
3
6
7
138

17
277
284
416
6691

3910
47853
82572
129240
1581432

16748
215147
367903
563413
6967289

2405
42606
56457
90537
1103404

10480
191609
253025
397525
4909442

No. of
Blocks

No. of
Villages

No. of Household
(Census-2011)

Total
Population

Total ST
Household

Total ST
Population

2

3

1138

4859

658

2821

7

22

8992

42285

6569

31284

9

25

10130

47144

7227

34105

No. of
Blocks

No. of
Villages

No. of Household
(Census-2011)

Total
Population

Total ST
Household

Total ST
Population

2

3

2521

14008

1680

9357

4

127

37384

196490

32265

170527

5

167

46442

290266

29891

191896

9

240

65092

301166

51394

238792

6

681

152024

839897

138315

772655

3

222

33962

174301

33430

171956

1

2

596

3769

456

2889

9

512

234663

1546386

218189

1443900

54

<!-- page 56 -->

7. GUJARAT
Name of
District
JUNAGADH
KACHCHH
MAHISAGA
11
R
12 NARMADA
13 NAVSARI
PANCH
14
MAHALS
15 PATAN
SABAR
16
KANTHA
17 SURAT
SURENDRA
18
NAGAR
19 TAPI
20 VADODARA
21 VALSAD
Grand Total
S.
No
9
10

S.
No

No. of
Blocks
1
2

No. of
Villages
3
3

No. of Household
(Census-2011)
660
4725

Total
Population
4157
23684

Total ST
Household
424
88

Total ST
Population
2630
436

4

189

60822

339028

53277

298465

5
6

387
238

93345
130405

455072
601739

84125
106017

413334
493461

7

163

62973

385082

35972

225301

1

7

4506

22099

232

1178

6

164

51274

303852

48693

290676

9

398

139794

634295

112588

512457

1

2

3130

16533

2219

11725

7
8
6
102

369
55
333
4265

147372
14479
155056
1441225

670227
66352
786812
7675215

136069
8541
135105
1228970

618842
39388
696047
6605912

No. of Household
(Census-2011)

Total ST
Household

Total ST
Population

55
12120
52
2119
7111
15

302
61811
271
9852
29959
64

8. HIMACHAL PRADESH
Name of
No. of
No. of
District
Blocks
Villages

1
2
3
4
5
6

BILASPUR
CHAMBA
HAMIRPUR
KANGRA
KINNAUR
KULLU
LAHUL
7
AND SPITI
8 SIRMAUR
9 SOLAN
10 UNA
Grand Total

1
7
1
6
3
1

1
156
1
19
69
1

98
17578
103
3175
10354
214

Total
Populatio
n
531
89759
533
14654
43578
877

2

9

1635

7046

1258

5576

2
2
1
26

3
10
1
270

503
1421
566
35647

3030
7367
2976
170351

393
936
364
24423

2368
4920
1917
117040

Total ST
Household

Total ST
Population

4770
5900
1361
575

27754
39420
8170
4492

S.No

Name of
District

No. of
Blocks

1
2
3
4

ANANTNAG
BANDIPORA
BARAMULLA
BUDGAM

7
6
6
3

9. JAMMU & KASHMIR
No. of
No. of
Total
Villages
Household
Population
(Census2011)
16
6402
37062
31
7507
50408
8
1653
9775
5
844
6658

55

<!-- page 57 -->

S.No

Name of
District

No. of
Blocks

5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20

DODA
GANDERBAL
JAMMU
KATHUA
KISHTWAR
KULGAM
KUPWARA
POONCH
PULWAMA
RAJOURI
RAMBAN
REASI
SAMBA
SHOPIAN
SRINAGAR
UDHAMPUR
Grand Total

5
2
6
4
7
3
11
10
2
14
7
9
2
1
1
6
112

9. JAMMU & KASHMIR
No. of
No. of
Total
Villages
Household
Population
(Census2011)
15
4106
22375
12
5577
37038
16
3180
17438
7
1980
11210
19
4931
26156
12
5797
31103
14
3326
23769
58
30107
160371
8
3903
23113
104
41112
204567
11
6922
36297
44
12918
74471
2
591
3349
2
795
4505
1
309
1900
8
1850
10522
393
143810
792087

No. of
Blocks

No. of
Villages

9
5
10
9
10
11
15
9
9
12
14
6
6
2
10
7
6
13
5
18

10. JHARKHAND
S.No
Name of
District
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20

BOKARO
CHATRA
DEOGHAR
DHANBAD
DUMKA
EAST
SINGHBUM
GARHWA
GIRIDIH
GODDA
GUMLA
HAZARIBAGH
JAMTARA
KHUNTI
KODERMA
LATEHAR
LOHARDAGA
PAKUR
PALAMU
RAMGARH
RANCHI

Total ST
Household

Total ST
Population

2702
3570
1975
1357
2860
1819
2067
19610
1906
28296
1887
7946
457
613
298
1103
91072

14999
23699
10842
7676
15364
9690
14490
104758
10854
140965
9655
45841
2606
3476
1837
6347
502935

Total
Population

Total ST
Household

Total ST
Population

125
18
267
196
689

No. of
Household
(Census-2011)
31924
3499
33613
39467
89591

165090
20637
190059
215738
425523

16321
2080
16799
17184
61635

83115
12450
93591
94074
292273

399
113
143
244
616
76
285
403
12
269
205
400
91
92
545

76563
30444
19914
37593
131915
15147
43182
66509
3182
51691
49234
61271
18244
24204
141391

367568
158800
113181
177701
724812
84156
220274
345642
20488
284639
258563
296199
98135
128247
738477

58401
18522
14568
28112
101752
7194
27460
52732
330
37683
35291
50010
12264
13051
99782

282927
96724
82601
132595
565099
39813
140381
276310
2206
208889
186701
241379
66249
69026
522607

56

<!-- page 58 -->

10. JHARKHAND
S.No
Name of
District

No. of
Blocks

No. of
Villages

Total
Population

Total ST
Household

Total ST
Population

236

No. of
Household
(Census-2011)
43555

8

206205

30519

143378

9
10

496
292

82176
87984

400623
447619

45631
68357

228580
349860

18
231

927
7139

189843
1372136

955635
7044011

151435
967113

766031
4976859

11. KARNATAKA
S.No
Name of
No. of
District
Blocks

No. of
Villages

No. of
Household
(Census-2011)

Total
Population

Total ST
Household

Total ST
Population

5

7

2801

14933

1581

8548

5
8

59
51

29675
19074

158053
96432

11279
13998

62949
71248

3

14

2143

10029

1493

7024

2

2

443

2038

394

1823

7

196

85904

464017

16601

89476

4

11

5426

21704

3594

14299

6

31

5397

24186

3494

15829

3

3

442

2032

262

1208

6

87

29755

152972

20765

107935

6

44

8723

43137

6253

31202

4
4
6

4
6
11

533
1012
2217

2494
4709
10672

386
709
1445

1823
3248
6984

6
1
5
7
1
7
7

31
1
12
40
2
62
243

16445
630
2049
7535
402
24943
70705

90249
2223
9243
43004
1849
107784
388973

1276
329
1520
4771
250
17124
27485

7052
1163
6876
27506
1163
74589
156234

2

2

238

1031

196

861

1

2

661

3076

359

1673

21

SAHEBGANJ
SARAIKELA
22
KHARSAWAN
23
SIMDEGA
WEST
24
SINGHBHUM
Grand Total

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23

BAGALKOT
E
BALLARI
BELAGAVI
BENGALUR
U RURAL
BENGALUR
U URBAN
BIDAR
CHAMARAJ
ANAGARA
CHIKKABAL
LAPURA
CHIKKAMA
GALURU
CHITRADUR
GA
DAVANGER
E
GADAG
HASSAN
HAVERI
KALABURA
GI
KODAGU
KOLAR
KOPPAL
MANDYA
MYSURU
RAICHUR
RAMANAGA
RA
SHIVAMOG
GA

57

<!-- page 59 -->

11. KARNATAKA
S.No
Name of
No. of
District
Blocks
24

No. of
Villages

7

29

No. of
Household
(Census-2011)
6355

4

31

14430

69220

1496

7221

5

25

11110

59663

7437

40051

2
5
129

19
64
1089

9335
19375
377758

48233
115902
1975186

671
6023
155318

3590
36158
805566

No. of
Household
(Census-2011)
71161
43767
36806
166484
318218

Total
Total ST
Population Household

TUMAKURU
UTTARA
25
KANNADA
VIJAYANAG
26
AR
VIJAYAPUR
27
A
28
YADGIR
Grand Total
12. KERALA
S.No
Name of
District

No. of
Blocks

No. of
Villages

1
IDUKKI
2
KASARAGOD
3
PALAKKAD
4
WAYANAD
Grand Total

2
1
2
4
9

19
14
11
45
89

13. LADAKH
S.No Name of
No. of
District
Blocks

No. of
Villages

No. of Household
(Census-2011)

14

89

16
30

54
143

1 KARGIL
LEH
2 LADAKH
Grand Total

LAKSHADWEE
P DISTRICT
Grand Total

ALIRAJPUR
ANUPPUR
ASHOKNAGAR
BALAGHAT

Total ST
Population

27328

4127

17833

Total ST
Household

Total ST
Population

14001

Total
Populatio
n
103300

13366

98516

11103
25104

60681
163981

10450
23816

56722
155238

No. of
Villages

No. of
Household
(Census-2011)

Total
Population

Total ST
Household

Total ST
Populatio
n

2

2

1837

9868

1733

9322

2

2

1837

9868

1733

9322

No. of
Villages

No. of
Total
Total ST
Total ST
Household
Population Household Population
(Census2011)
110807
658536
103225
616413
78867
340091
58768
255734
5397
24984
3695
17154
40969
180547
30886
137303

6
4
4
8

490
371
24
200

278147
179923
149677
714533
1322280

Total ST
Population
18126
28641
33331
139426
219524

15. MADHYA PRADESH
S.N Name of District
No. of
o
Blocks
1
2
3
4

Total ST
Household

4745
6958
8790
32539
53032

14. LAKSHADWEEP
S.N Name of District
No. of
o
Blocks
1

Total
Population

58

<!-- page 60 -->

15. MADHYA PRADESH
S.N Name of District
No. of
o
Blocks
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45

BARWANI
BETUL
BHIND
BHOPAL
BURHANPUR
CHHATARPUR
CHHINDWARA
DAMOH
DATIA
DEWAS
DHAR
DINDORI
EAST NIMAR
GUNA
GWALIOR
HARDA
INDORE
JABALPUR
JHABUA
KATNI
KHARGONE
MANDLA
MANDSAUR
MORENA
NARMADAPURA
M
NARSINGHPUR
NEEMUCH
NIWARI
PANNA
RAISEN
RAJGARH
RATLAM
REWA
SAGAR
SATNA
SEHORE
SEONI
SHAHDOL
SHAJAPUR
SHEOPUR
SHIVPURI

No. of
Villages

7
10
1
1
2
5
11
7
1
3
13
7
7
5
3
3
2
7
6
6
9
9
3
3

529
554
5
1
116
66
591
171
1
135
802
563
305
229
10
103
56
171
651
199
424
716
4
18

6
6
3
1
5
7
5
4
8
10
8
5
8
5
1
3
7

83
73
17
42
108
92
18
339
424
73
321
80
397
402
1
254
234

No. of
Total
Total ST
Total ST
Household
Population Household Population
(Census2011)
162129
963719
141871
849786
120534
605386
96086
486200
2065
10621
139
728
387
2120
218
1196
38344
212979
32487
182102
12557
56269
3994
19178
106714
524903
83420
414456
36732
155367
15465
67105
127
547
65
284
31990
164645
24752
128924
202336
1070877
175228
935363
112698
473415
83581
354213
93165
466532
58541
300215
39340
202255
21152
109931
2804
13840
1702
8358
17063
95023
13739
77659
10124
53122
8187
43090
28670
127078
22824
101887
161881
863639
152419
816818
46887
207143
21316
95076
119944
659034
98650
547993
141896
597786
108636
460708
621
3147
416
2109
4035
18480
1619
7476
16927
12279
2964
14483
26600
16069
7124
65981
131383
11917
83357
15726
71131
105163
104
79905
60578

85398
53338
12937
67632
121985
82947
31577
314593
573567
51605
385187
92093
311970
433256
568
371857
279046

12234
8642
2378
1924
13101
12493
1870
59364
29586
8752
24379
12442
53476
70666
52
32800
22510

62687
37874
10403
8846
61182
65046
8396
283529
132293
38098
113870
73821
235627
292811
286
155036
103420

<!-- page 61 -->

15. MADHYA PRADESH
S.N Name of District
No. of
o
Blocks
46
47
48
49
50
51

SIDHI
SINGRAULI
TIKAMGARH
UJJAIN
UMARIA
VIDISHA
Grand Total

5
3
3
4
3
4
267

16. MAHARASTRA
S.No Name of District No. of
Blocks
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29

AHMEDNAGAR
AKOLA
AMRAVATI
AURANGABAD
BEED
BHANDARA
BULDHANA
CHANDRAPUR
DHULE
GADCHIROLI
GONDIA
HINGOLI
JALGAON
JALNA
KOLHAPUR
LATUR
NAGPUR
NANDED
NANDURBAR
NASHIK
OSMANABAD
PALGHAR
PARBHANI
PUNE
RAIGAD
RATNAGIRI
SATARA
SOLAPUR
THANE

No. of
Villages

4
7
9
4
1
6
8
15
4
12
8
5
12
4
1
2
11
9
6
15
2
8
2
6
14
1
2
3
5

134
290
62
8
334
86
11377

No. of
Villages
118
43
321
11
2
14
43
167
213
411
104
81
112
25
1
2
58
169
717
767
4
654
5
99
113
1
4
61
146

No. of
Total
Total ST
Total ST
Household
Population Household Population
(Census2011)
37851
174506
26172
120831
90893
435559
50134
245116
23404
106458
2692
12563
1322
5906
894
3989
80514
353790
45421
201704
18483
88539
3732
18238
2703241 13186399
1858795
9323125

No. of
Household
(Census2011)
28218
8920
58758
3498
1408
2616
10477
36301
69032
69929
21853
23954
32087
11044
245
474
10581
44820
204755
174737
1459
211556
995
21450
26730
302
755
35064
36650

Total
Population

Total ST
Household

Total ST
Population

144501
40272
300494
16816
6629
12025
54817
151358
361205
317527
101101
123958
158166
55716
1088
2391
49100
215017
1027852
935236
6613
1049094
4944
104671
129104
1395
3569
181945
182262

22993
6790
47112
2123
58
1668
8661
20663
61464
42341
14779
11013
23416
799
184
301
7055
20466
182924
155229
231
181552
760
17420
19477
172
511
1794
27771

117593
30896
243744
10365
280
7695
46073
86112
321369
200848
69130
58258
117106
3967
821
1512
33199
100717
920553
828239
1096
910904
3729
85304
94600
795
2417
9595
139039

59

60

<!-- page 62 -->

16. MAHARASTRA
S.No Name of District No. of
Blocks
30
31
32

WARDHA
WASHIM
YAVATMAL
Grand Total

8
4
16
214

17. MANIPUR
S.No Name of District

1
2
3
4
5
6
7
8
9
10
11
12
13

1
2
3
4
5
6
7
8

EAST GARO
HILLS
EAST JAINTIA
HILLS
EAST KHASI
HILLS
EASTERN
WEST KHASI
HILLS
NORTH GARO
HILLS
RI BHOI
SOUTH GARO
HILLS
SOUTH WEST
GARO HILLS

72
71
366
4975

No. of
Blocks

BISHNUPUR
CHANDEL
CHURACHANDPUR
IMPHAL EAST
JIRIBAM
KAMJONG
KANGPOKPI
NONEY
PHERZAWL
SENAPATI
TAMENGLONG
TENGNOUPAL
UKHRUL
Grand Total

18. MEGAHLAYA
S.No
Name of
District

No. of
Villages

1
4
12
2
2
4
9
4
3
6
3
3
4
57

No. of
Household
(Census2011)
15145
26753
97136
1287702

No. of
No. of
Villages Household
(Census2011)
1
122
91
8496
89
16627
2
374
3
651
27
4629
59
10250
27
6144
22
4723
94
40007
38
6942
11
1905
52
16355
516
117225

Total
Population

Total ST
Household

Total ST
Population

63532
123426
421974
6347798

4848
7382
45436
937393

20536
33447
194743
4694682

Total
Total ST
Total ST
Population Household Population
655
43181
94840
1936
3678
24403
55867
34402
27967
244112
40828
10498
83770
666137

66
8181
15758
271
375
4385
9371
5656
4559
37795
6710
1744
15659
110530

355
41393
90097
1399
2133
23049
51355
31510
27103
231651
39574
9421
80292
629332

No. of
Blocks

No. of
Villages

No. of
Household
(Census-2011)

Total
Population

Total ST
Household

Total ST
Population

3

43

4978

28552

4804

27689

3

73

15770

95272

15242

92500

11

274

55440

297142

53521

288285

2

75

11189

66275

11041

65623

4
4

175
279

12635
29148

69073
162897

12220
26717

67177
150844

4

25

3126

18436

2812

16686

3

64

8105

44092

7517

41166

61

<!-- page 63 -->

18. MEGAHLAYA
S.No
Name of
District

No. of
Blocks

No. of
Villages

No. of
Household
(Census-2011)

Total
Population

Total ST
Household

Total ST
Population

2

53

7872

47151

7645

46009

8

130

17618

93585

16748

89384

4

188

35899

218681

34190

208684

5
53

58
1437

7014
208794

42580
1183736

6867
199324

41854
1135901

No. of
Blocks

No. of
Villages

No. of
Household
(Census2011)
11170
7015
3760
3550
5948
13498
8006
12213
4808
7441
5701
83110

SOUTH WEST
9
KHASI HILLS
WEST GARO
10 HILLS
WEST
JAINTIA
11 HILLS
WEST KHASI
12 HILLS
Grand Total
19. MIZORAM
S.No Name of
District
1
AIZAWL
2
CHAMPHAI
3
HNAHTHIAL
4
KHAWZAWL
5
KOLASIB
6
LAWNGTLAI
7
LUNGLEI
8
MAMIT
9
SAIHA
10
SAITUAL
11
SERCHHIP
Grand Total
20. NAGALAND
S.No Name of District

1
2
3
4
5
6
7
8
9
10
11

CHUMOUKEDIM
A
DIMAPUR
KIPHIRE
KOHIMA
LONGLENG
MOKOKCHUNG
MON
NIULAND
NOKLAK
PEREN
PHEK

Total
Total ST
Total ST
Population Household Population

4
2
1
1
2
4
3
3
2
2
2
26

42
30
15
17
19
73
48
57
27
32
23
383

54558
35159
18532
18158
29415
69270
38620
60132
23424
37505
29671
414444

10817
6880
3706
3489
5155
13088
7833
11572
4719
7266
5623
80148

52917
34566
18305
17892
25496
67383
37913
57075
23041
36754
29310
400652

No. of
Blocks

No. of
Villages

No. of
Household
(Census-2011)

4

46

13774

70557

11008

56629

4
5
5
3
9
8
1
3
4
8

16
40
27
20
48
76
4
26
38
55

4124
7523
12585
6409
22414
25661
528
7204
9621
22269

20318
36394
65478
28021
105046
158558
2473
39275
51453
99017

3221
7375
12022
6321
21333
24979
367
6985
8793
22017

15797
35763
62833
27693
100423
155011
1735
38311
47224
98019

Total
Total ST
Total ST
Population Household Population

62

<!-- page 64 -->

20. NAGALAND
S.No Name of District
12
13
14
15
16

SHAMATOR
TSEMINYU
TUENSANG
WOKHA
ZUNHEBOTO
Grand Total

21. ORISSA
S.No Name of District
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27

ANUGUL
BALANGIR
BALESHWAR
BARGARH
BOUDH
CUTTACK
DEOGARH
DHENKANAL
GAJAPATI
GANJAM
JAJAPUR
JHARSUGUDA
KALAHANDI
KANDHAMAL
KENDRAPARA
KENDUJHAR
KHORDHA
KORAPUT
MALKANGIRI
MAYURBHANJ
NABARANGPUR
NAYAGARH
NUAPADA
RAYAGADA
SAMBALPUR
SONEPUR
SUNDARGARH
Grand Total

No. of
Blocks

No. of
Villages

2
2
5
7
8
74

16
22
36
53
85
608

No. of
Blocks

No. of
Villages

7
14
10
12
3
4
3
6
7
8
5
5
13
12
1
13
6
14
7
26
10
3
5
11
9
3
17
234

59
258
80
157
7
21
52
128
345
17
67
78
424
381
1
807
16
572
425
1363
536
113
260
420
265
3
812
7667

No. of
Household
(Census-2011)
4350
7823
9310
17072
14351
185018

Total
Total ST
Total ST
Population Household Population

No. of
Household
(Census-2011)
9423
54057
26787
38217
1315
5588
10193
25425
39226
2604
18358
22453
70881
49995
164
158834
3234
138815
70996
270584
178194
10002
65191
71198
55661
526
213071
1610992

Total
Total ST
Total ST
Population Household Population

21280
44208
52257
91555
70831
956721

44169
215803
118401
154883
5456
27312
43729
115626
186060
12539
89397
92942
281653
220770
824
725809
15222
572038
316903
1197432
807714
41038
261310
315286
233504
2494
943947
7042261

4325
7724
9220
16545
14184
176419

6297
24013
19490
16944
768
3723
6784
11841
31337
1972
12581
14226
40042
31533
93
113201
2335
93894
52206
207932
119803
4386
33066
46704
33360
338
156792
1085661

21194
43747
51851
89270
70242
915742

29876
96074
86492
69005
3201
18346
29202
55949
149522
9578
61725
59120
161659
141880
469
524208
10866
389573
233317
929350
548253
18448
133647
210721
141450
1632
702107
4815670

63

<!-- page 65 -->

22. RAJASTHAN
S.No Name of District
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25

AJMER
ALWAR
BANSWARA
BARAN
BARMER
BHARATPUR
BHILWARA
BIKANER
BUNDI
CHITTORGARH
CHURU
DAUSA
DHOLPUR
DUNGARPUR
JAIPUR
JAISALMER
JALORE
JHALAWAR
JODHPUR
KARAULI
KOTA
NAGAUR
PALI
PRATAPGARH
RAJSAMAND
SAWAI
26 MADHOPUR
27 SIKAR
28 SIROHI
29 TONK
30 UDAIPUR
Grand Total
23. SIKKIM
S.No Name of
District
1
2
3
4
5
6

GANGTOK
GYALSHING
MANGAN
NAMCHI
PAKYONG
SORENG

No. of
Blocks

Total
Total ST
Total ST
Population Household Population

2
9
11
8
16
5
7
2
5
7
1
11
3
10
11
3
6
7
9
8
5
1
7
8
5

No. of
No. of
Villages Household
(Census-2011)
12
2509
155
33825
1030
265215
277
53933
71
10987
32
8236
141
35287
4
1006
265
50554
158
36709
19
7635
321
69143
44
8969
638
185753
186
35407
28
5559
91
35230
207
35148
54
14360
200
55621
63
9454
2
2080
67
24632
386
93462
73
19318

11182
193601
1309024
269766
63285
48099
165491
6004
249029
173827
40839
394898
52782
934304
218579
32499
175806
179691
83580
307980
48294
12709
122150
454673
90250

1728
20274
237481
29165
5052
2986
13900
92
26797
12345
421
46279
6349
163201
26833
1102
6611
18323
2703
35099
6097
34
11866
85169
7944

7717
117395
1175820
146064
29360
17678
62867
577
131671
58121
2281
265002
37669
824989
166482
6465
33803
92270
15814
194361
31236
212
62452
415483
36963

7
3
5
6
20
208

188
4
131
135
1037
6019

323180
6221
244417
157634
1285249
7655043

35359
849
35171
15690
221270
1076190

185233
4652
194589
79363
1140855
5537444

No. of
Blocks

No. of
Villages

2
5
4
6
4
5

6
23
30
37
5
18

61388
1141
44957
30738
250880
1489136

No. of
Total
Total ST
Total ST
Household Population Household Population
(Census2011)
1655
7970
955
4616
5318
27280
3200
16540
5694
27524
4248
20760
6558
31026
2778
13291
1113
5315
704
3365
5261
24520
3016
14110

64

<!-- page 66 -->

23. SIKKIM
S.No Name of
District

No. of
Blocks

No. of
Villages

Grand Total

26

119

24. TAMIL NADU
S.No Name of
District

No. of
Total
Total ST
Total ST
Household Population Household Population
(Census2011)
25599
123635
14901
72682

ARIYALUR
DHARMAPURI
KALLAKURICHI
KANNIYAKUMARI
NAMAKKAL
PERAMBALUR
RAMANATHAPURA
7
M
8
RANIPET
9
SALEM
10 THE NILGIRIS
11 TIRUCHIRAPPALLI
12 TIRUNELVELI
13 TIRUPATHUR
14 TIRUVANNAMALAI
15 VELLORE
16 VILLUPURAM
Grand Total

1
5
3
1
2
1

11
19
49
1
22
2

No. of
Household
(Census2011)
9891
7208
11218
470
12614
2022

1
2
7
1
2
1
3
3
2
1
36

1
9
56
12
7
1
6
42
8
2
248

556
3325
20592
15357
7230
1135
6642
15535
7122
1984
122901

25. TELANGANA
S.No
Name of
No. of
District
Blocks

No. of
Villages

1
2
3
4
5
6

1 ADILABAD
BHADRADRI
KOTHAGUDE
2 M
3 JAGITIAL
4 JANGOAN
JAYASHANKA
R
BHUPALAPAL
5 LY
JOGULAMBA
6 GADWAL
7 KAMAREDDY
8 KHAMMAM

No. of
Block
s

No. of
Village
s

Total
Total ST
Total ST
Population Household Population
38426
29545
50549
1663
46561
7482

572
6424
9961
446
11714
38

2268
26595
45151
1579
43325
149

2456
13129
81228
52876
27315
4325
30638
64353
29275
9332
489153

32
305
18479
1733
2690
14
5773
13296
2570
32
74079

145
1237
73352
6043
10933
54
26875
55131
10720
154
303711

16

150

No. of
Household
(Census-2011)
36536

Total
Total ST
Population Household

Total ST
Population

175732

27536

132867

19

130

82641

321784

59853

235011

1
6

2
9

638
5752

2463
24665

348
4022

1350
17311

4

31

7802

30643

3072

12308

1

2

2169

11704

187

1000

7
9

14
35

6316
32627

29608
123918

4321
21779

20408
82942

<!-- page 67 -->

25. TELANGANA
S.No
Name of
No. of
District
Blocks
KUMURAM
BHEEM
9 ASIFABAD
MAHABUBAB
10 AD
MAHABUBNA
11 GAR
12 MANCHERIAL
13 MEDAK
MEDCHAL
14 MALKAJGIRI
15 MULUGU
NAGARKURN
16 OOL
17 NALGONDA
18 NARAYANPET
19 NIRMAL
20 NIZAMABAD
21 PEDDAPALLI
RAJANNA
22 SIRCILLA
RANGA
23 REDDY
SANGAREDD
24 Y
25 SIDDIPET
26 SURYAPET
27 VIKARABAD
WANAPARTH
28 Y
29 WARANGAL
YADADRI
BHUVANAGIR
30 I
Grand Total

No. of
Villages

No. of
Household
(Census-2011)

12

102

23292

103764

17891

80603

15

92

52783

209715

34726

137675

10

26

8613

42454

5516

27158

7
9

11
15

2783
4388

10799
21629

1808
2642

7071
13052

2

2

632

2818

404

1825

8

49

13265

49917

8066

30404

9

20

10007

44510

6503

29079

14
3
9
9
1

52
6
32
19
1

36692
1538
8237
4770
152

155246
8510
37836
22564
529

24637
414
5848
3744
78

104672
2404
27573
17956
274

2

3

2302

10260

1386

6180

12

20

8505

38272

5312

23887

7

16

5060

25994

3373

17500

2
6
13

2
17
31

947
15019
7921

4029
59373
42002

607
9163
5397

2602
36429
28629

4

7

2702

13772

1606

8197

8

15

10104

39580

6613

25945

5

13

6233

27215

4177

18226

230

924

400426

1691305

271029

1150538

Total
Populati
on

Total ST
Household

Total ST
Population

26. THE DADRA AND NAGAR HAVELI
S.No Name of
No. of
No. of
No. of Household
District
Blocks Villages (Census-2011)
DADRA
AND
NAGAR
1 HAVELI
2 DAMAN
Grand Total

Total
Total ST
Population Household

Total ST
Population

1

61

33864

171141

26557

139675

1
2

15
76

7413
41277

32313
203454

1595
28152

7615
147290

<!-- page 68 -->

27. TRIPURA
S.No Name of
District
1 DHALAI
2 GOMATI
3 KHOWAI
NORTH
4 TRIPURA
5 SEPAHIJALA
SOUTH
6 TRIPURA
7 UNAKOTI
WEST
8 TRIPURA
Grand Total

No. of
Blocks

No. of
Villages

8
7
6

93
72
37

6
6

37
38

25020
22118

121724
98326

19374
18991

95540
84652

7
4

59
21

29376
9604

130277
45223

23077
7410

103018
35090

8
52

35
392

27465
217267

118893
988452

24294
181487

105196
828393

28. UTTAR PRADESH
S.No Name of District No. of
Blocks

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24

AMBEDKAR
NAGAR
BAHRAICH
BALLIA
BALRAMPUR
BARABANKI
BASTI
BHADOHI
BIJNOR
CHANDAULI
DEORIA
GHAZIPUR
GORAKHPUR
JAUNPUR
KHERI
KUSHI NAGAR
LALITPUR
MAHARAJGANJ
MAHOBA
MIRZAPUR
PILIBHIT
PRAYAGRAJ
SANT KABEER
NAGAR
SHRAVASTI
SIDDHARTH

No. of
Total
Total ST
Total ST
Household Population Household Population
(Census2011)
41887
194992
34561
161458
37594
171796
32856
150575
24203
107221
20924
92864

No. of
No. of
Total
Total ST
Total ST
Villages Household Population Household Population
(Census2011)

1

1

470

2777

8

51

2
2
2
1
1
1
2
2
1
2
4
1
3
1
2
1
1
2
1
1

3
61
16
2
3
2
5
17
34
26
18
1
34
34
36
2
1
20
7
7

1044
24685
2736
1400
661
774
1671
5273
15119
11692
7172
230
7587
17046
10488
945
2326
9016
10204
3110

6763
162436
20094
9034
4337
6031
9452
36600
98763
76882
46878
1664
55901
107804
58101
5848
13903
54618
57000
18720

798
1290
2313
42
65
15
453
318
616
341
339
33
5239
751
1917
22
18
705
229
138

5249
8662
17108
279
443
128
2551
2113
4199
2368
2299
241
42256
4829
10541
144
111
4447
1352
862

1
1
1

1
2
7

140
734
1112

1035
5157
7508

12
623
109

93
4395
743

<!-- page 69 -->

28. UTTAR PRADESH
S.No Name of District No. of
Blocks
NAGAR
25 SITAPUR
26 SONBHADRA
Grand Total

1
9
47

29. UTTARAKHAND
S.N Name of District No. of
o
Blocks
1
2
3
4
5
6
7

BAGESHWAR
CHAMOLI
DEHRADUN
HARIDWAR
PITHORAGAR
H
UDAM SINGH
NAGAR
UTTAR KASHI
Grand Total

No. of
No. of
Total
Total ST
Total ST
Villages Household Population Household Population
(Census2011)

1
1
4
1

1
176
517

554
55694
191883

No. of
No. of
Villages Household
(Census-2011)
8
945
1
558
41
6032
5
6651

2965
312931
1183202

22
34700
51116

120
195904
311488

Total
Total ST
Total ST
Population Household Population
4405
1214
41228
37465

149
393
3744
667

721
857
25651
3709

2

3

534

2065

391

1496

4
2
15

68
2
128

22291
619
37630

120428
2579
209384

9854
383
15581

54702
1587
88723

30. WEST BENGAL
S.No
Name of
No. of
District
Block
s
1
24
6
PARAGANAS
NORTH
2
24
2
PARAGANAS
SOUTH
3
ALIPURDUA
6
R
4
BANKURA
17
5
BIRBHUM
16
6
COOCHBEHA
1
R
7
DARJEELING
9
8
DINAJPUR
8
DAKSHIN
9
DINAJPUR
9
UTTAR
10 HOOGHLY
5
11 JALPAIGURI
7
12 JHARGRAM
8

No. of
Village
s
11

No. of Household
(Census-2011)

Total
Total ST
Population Household

Total ST
Population

7119

32245

4752

21609

2

372

1690

304

1375

80

62425

289783

43430

202195

365
150
1

71395
58422
200

338939
254604
915

28738
17198
118

135765
78349
540

87
214

29145
49327

139757
205043

19747
18957

95018
80122

305

140162

703591

18709

93012

9
71
680

2411
64102
89556

10109
301216
401294

1361
44511
40672

5712
209691
184191

67

<!-- page 70 -->

30. WEST BENGAL
S.No
Name of
No. of
District
Block
s
13 KALIMPONG
4
14 MALDAH
10
15 MEDINIPUR
1
EAST
16 MEDINIPUR
16
WEST
17 MURSHIDAB
6
AD
18 NADIA
5
19 PASCHIM
5
BARDHAMA
N
20 PURBA
10
BARDHAMA
N
21 PURULIA
19
Grand Total
170

No. of
Village
s
12
271
1

No. of Household
(Census-2011)

Total
Total ST
Population Household

Total ST
Population

4257
69789
173

22535
320969
664

2496
27255
93

13186
121947
360

386

71255

316311

31362

139476

17

5155

22832

2925

13100

9
15

2153
3135

9352
15129

1317
2026

5731
9984

25

6559

28251

3836

16648

501
3212

110426
847538

559402
3974631

54866
364673

279331
1707342

<!-- page 71 -->

Break Up of Physical Targets under Dharti Aaba Janjatiya Gram Utkarsh
Abhiyan
Achievement
Activity

Year 1

Year2

Year3

Year 4

Year 5

Total

1 lakh

5 lakh

6 lakh

5 lakh

3 lakh

20 lakh houses

1250
villages

6250
villages

7500
villages

6250
villages

3750
villages

25000
villages

250
villages

1250
villages

1500
villages

1250
villages

750
villages

5000
villages

11,750
HHs
elect
rified
50
MMU
Sanction
ed

58,750
HHs
electri
fied

70,500
HHs
electrifi
ed

58,750
HHs
electrifi
ed

35,250
HHs
electrifie
d

235000
HHs
electrified

250
MMU
sanction
ed

300
MMU
sanction
ed

250
MMU
sanction
ed

150
MMU
sanctione
d

1000 MM
U sanctioned

1.25 lakh
s HHs

6.25
lakh
s HHs

7.5 lakhs
HHs

6.25
lakhs
HHs

3.75
lakhs
HHs

25 lakhs
HHs

100
AWC
Sanction
ed
300
AWC
upgrade
d

500
AWC
Sanctio
ned
1500
AWC
upgrade
d

2000 AWC
Sanctioned

250
hostels
Sanctio
ned
175
Poshan
Vatikas
sanctio
ned

500
AWC
Sanction
ed
1500
AW
C
upgrade
d
250
hostels
Sanction
ed
175
Poshan
Vatikas
sanction
ed

300
AWC
Sanction
ed
900
AWC
upgrade
d

Strengthening Ed 50
ucation
hostels
Infrastruct ure
Sanction
ed
Better access to
35
A
Poshan
YUSH services
Vatikas
by tribals and
sanctio
preserving
ned
traditio nal
medicinal plan ts
through Poshan

600
AWC
Sanctio
ned
1800
AW
C
upgrade
d
300
hostels
Sanction
ed
210
Poshan
Vatikas
sanctio
ned

150
hostels
Sanction
ed
105 Posh
An
Vatikas
sanctione
d

1000 hostels
Sanctioned

Provision of Pucc
a House for tribal
HHs
Road
connectivity
to Tribal
unconnec ted
villages
Provision of
FHTC
to tribal HH
Electrification of
u
nelectrified
tribal HHs
Strengthening
hea
lthcare
infrastructu re
and services to
remote tribal
villag es
Clean energy to
tri
bal HHs- LPG Co
nnection
Improving
the
nutr
itional & health
sta tus of Tribal
childr en

houses

houses

houses

houses

houses

69

6000 AWC
upgraded

700 Poshan
Vatikas
sanctioned

70

<!-- page 72 -->

Vatikas

Tele-connectivity
t
o
unconnected
tribal villages
Promotion of
Gree
n Energy &
solariz ing
institutions in
tribal areas with
ro oftop solar
installa tions
Responsible
tourism: To
provid
e both
community
and touristoriente d
facilities.
Skill building:
uplift
ST population
eco nomically by
impa rting
essential skills
training
Training of
VDVK
s

250
villages

1250
villages

1500
Villages

1250
Villages

750
villages

5000 villages

100
Institutio
ns

500
Instituti
ons

600
Institutio
ns

500
Institutio
ns

300
Institutio
ns

2000
Institutions

50
homesta
y
s
sanctione
d

250
homesta
ys
sanction
ed

300
homesta
y
s sanctio
ned

250
homestay
s sanction
ed

150
home
stays
sanction
ed

1000 home
stays
sanctioned

2 TJSS s 7 TJSS s
anctioned anctione
d

9 TJSS s
anctione
d

7 TJSS s
anctioned

5 TJSS
sa
nctioned

30 TJSS
sanctioned

50
VDVK
s trained

25
TMMCs
sanctione
d

150
VDV
Ks
trained
15
TMMCs
sanction
ed

1000 VDVKs
trained

5
TMMCs
sanctione
d

300
VDV
Ks traine
d
30
TMMC
s
sanctione
d

250 VDV
Ks
trained

Improve Market
lin
kage: to facilitate
t he flow of
produce between
the differ ent
levels of the m
arketing system
in tribal areas.
Setting up of
CoC

250
VDV
Ks traine
d
25TMM
Cs
sanction
ed

8 COCs
sanctione
d
10000
beneficia
rie s

8 COCs
sanction
ed
50000
beneficia
ries

-

-

-

16 COCs
sanctioned

60000
beneficia
ries

50000
beneficiar
ies

30000
beneficia
ries

200000
beneficiaries

Sustainable
Agriculture
schem e
(PM Jivika) for
FRA Patta

100 TMMCs
sanctioned

71

<!-- page 73 -->

Holder s
Support to the
trib
al
fishermen and
CF R
holders for
promotion of
pisciculture
Support to for
FR
A
Patta Holders for
Animal
Husbandry &
Dairying throug
h
(PMJivika)
Ayushman Card
Pradhan
Mantri Jan
Arogya Yojna
(PMJAYMoH&F W)
Improving
infrastructure of
Ashram Schools

500
beneficia
ries

2500
3000
beneficia beneficia
ries
ries

2500
beneficiar
ies

1500
beneficia
ries

10000
beneficiaries

425
beneficia
ries

2125
2550
beneficia beneficia
ries
ries

2125
beneficiar
i es

1275
beneficia
ries

8500
beneficiaries

All eligible ST beneficiaries

As applicable

72
