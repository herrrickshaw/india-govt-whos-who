---
doc_id: "603e77b6cdaec9fb"
source_url: "https://apeda.nic.in/docs/tenders/biddoc_solarpowerpacks.pdf"
ministry: "Arunachal Pradesh Energy Development Agency (APEDA)"
title: "Open"
date: ""
pages: 85
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c0dfe15fa5b681d6"
---

<!-- page 1 -->

e-TENDER NO: APEDA/DDUGJY/2015-16/01

e-TENDER DOCUMENT
FOR
RURAL ELECTRIFICATION OF 1058 NOS. OF OFF-GRID
VILLAGES IN ARUNACHAL PRADESH BY INSTALLING
300Wp SOLAR POWER PACK UNDER DEENDAYAL
UPADHYAYA GRAM JYOTI YOJANA (DDUGJY)

Estimated Cost

: Rs. 127.00 Crores

Tender Document
Fee
Earnest Money

: Rs. 10,000/-

Performance
Guarantee

: Rs.20.00 lakhs in the form of
Demand Draft and Rs. 100.00 lakhs
in the form of Bank Guarantee.
: 10% of the Value of Award.

Prepared by:

ARUNACHAL PRADESH ENERGY DEVELOPMENT AGENCY
( A STATE GOVERNMENT ADENCY )
URJA BHAWAN, TADER TANG MARG
ITANAGAR – 791111
PHONE NO: 0360-2211160

E-MAIL: apeda79@gmail.com

<!-- page 2 -->

1

TABLE OF CONTENTS
TOPIC

PAGE-NO.
PART –A (Technical)

PART-1
e-tender Notice
Covering Letter
Checklist of Annexure
Particulars of e-tender
General Particulars of Bidder
Declaration by Bidder
PART-2
Instructions to Bidders
Section –1 The e-tender document
Section -2 Eligibility condition
Section-3 Preparation of e-tender
Section-4 UPLOADING of e-tender
Section –5 e-tender opening and evaluation
Section -6: Procedure for Finalisation of
BID
PART-3
General conditions of contract
PART-4
Scope of work & Technical specification
PART-5
Warranty And Maintenance
PART-6
Technical Bid
PART-7
Additional conditions and information to
bidder.
PART-B (Financial)
Financial Bid
Annexure-I: Handing over /JCR / Warrantee
Certificate for Solar Power Pack.
Annexure-II: Handing over /JCR /
Warrantee Certificate for Solar Street Light
List of villages with Census code and
Manual Cartage Distance

2-3
4
5-6
7
8
9
10
10
10-11
12-13
14-15
16
17
18-19
20-26
27-40
41
42-43

44-46
47-49
50

51
52-84

<!-- page 3 -->

2

PART-1
1.

e-TENDER NOTICE
ARUNACHAL PRADESH ENERGY DEVELOPMENT AGENCY
URJA BHAWAN, TADAR TANG MARG, ITANAGAR – 791 111
DISTRICT PAPUMPARE, ARUNACHAL PRADESH.
PHONE NO: 0360-2211160, FAX NO: 0360-2214426
E-MAIL: apeda79@gmail.com

No. APEDA/W- 225 /DDUGJY/2015-16

Date: 06/04/2016
e-Tender Notice

Arunachal Pradesh Energy Development Agency invites online Bids from prospective Bidders through etendering for the design, supply, installation, testing and commissioning with 5 years comprehensive warranty and
maintenance of 300Wp Solar Power Packs for Rural Electrification of 1058 Nos. of off-grid villages in Arunachal Pradesh as
per the terms and conditions given in e -tender document.
The tender document is available at website http://www.arunachaltenders.gov.in and
www.apeda.org.in. Interested bidders may view and download the e-Bid document, seek clarification and submit their e-Bid
online up to the date and time mentioned in the table below:
(a)

Availability of tender document on website

From 06/04/2016 to 28/04/2016

(b) Pre-Bid meeting

On 18/04/2016 at 11.00 AM
at Urja Bhawan, T.T. Marg, Itanagar, Arunachal Pradesh

(c)

e-Bid submission end Date & Time

On 28/04/2016 at 3.00 PM

(d)

Online technical e-Bid opening Date & Time

On 29/04/2016 at 11.00 AM

(e)

Online financial e-Bid opening Date & Time (Only
Will be intimated on the date of technical e-Bid evaluation.
for technically qualified bidders)

(f)

Venue of opening of technical & financial e-Bids

Urja Bhawan, T.T. Marg, Itanagar, Arunachal Pradesh.

Sd/(Director)
APEDA, Itangar
Memo No. APEDA/W- 225 /DDUGJY/2015-16

Date: 06/04/2016

Copy to:
1. The Director, IPR, Govt. of AP, Naharlagun with the request to publish above e-Tender Notice
immediately in the national and local dailies.
2. The Chairman, APEDA, Itanagar for information.
3. The Commissioner (Power & NRE), Govt. of AP, Itangar for information.
4. The Executive Director (DDUGJY), REC ltd., Core- 4, Scope Complex, 7 Lodhi Road, New Delhi –
110003, for information.
5. The GM, REC Ltd., Core- 4, Scope Complex, 7 Lodhi Road, New Delhi – 110003, for information.
6. The CPM, REC, ltd., Sraddha, M.B. Road, G.S. Road Crossing, SOHUM/HDFC Points, Christian Basti,
Guwahati – 781005 for information.

<!-- page 4 -->

3

7. The P.P.S to HCM, Govt. of AP for information.
8. The PS to CS, Govt. of AP, Itanagar for information.
9. The PS to HM (Power & NRE), Govt. of AP, Itanagar for information.
10. The CEO, APDA, Department of Power, Govt. of AP, Itanagar for information.
11. The CE (P), CEZ cum Member Secretary, (EC) , APDA, Itanagar for information.
12. The CE (P), WEZ, Department of Power, Govt. of AP, Itanagar for information.
13. The CE (P), EEZ, Department of Power, Govt. of AP, Itanagar for information.
14. The CE (P), CEZ, Department of Power, Govt. of AP, Itanagar for information.
15. The CE , EZ, Department of Hydro Power Development, Govt. of AP, Itanagar for information.
16. The CE, WZ, Department of Hydro Power Development, Govt. of AP, Itanagar for information.
17. The DD, APEDA, Tezu/ Aalo/ Bomdila/ Yachuli for information.
18. Notice Board.
19. Office Copy

(Director)
APEDA, Itangar

<!-- page 5 -->

4

2. COVERING LETTER
FROM:(Full name and address of the Bidder)
…………………………………………………………………………………...
……………………………………………………………………………………..
To:
The Director,
Arunachal Pradesh Energy Development Agency,
Urja Bhawan, T.T. Marg, Itangar -791111
District Papum Pare, Arunachal Pradesh.
Subject: -Offer in response to e-Tender No: APEDA/DDUGJY/2015-16/01

Sir,
We hereby submit our offer in full compliance with terms & conditions of the above e-Tender. A blank
copy of the e -Tender, duly signed on each page is also submitted as a proof of our acceptance of all
specifications as well as Terms/ Conditions.
We confirm that, we have the capability to design, manufacture, supply, install and commission and then
carryout 5 years comprehensive warranty maintenance of Solar PV Power Pack with all its components as
required.
We also understand that the e-Tender is to be uploaded in two separate files named Part-A for
Technical Bid & Part-B for Financial Bid only.

(Signature of Bidder)
With Seal

<!-- page 6 -->

5
1.

CHECK LIST OF ANNEXURES

(The following information/documents are to be annexed and flagged by the Bidders along with the BID)
Sl. No.

Annexure No.
Annexure -I (a)

1
Annexure -I (b)

2

Annexure -II

Particulars
Details of Tender document fees ( Demand Draft No, Date, amount and
Bank Name)
Details of Earnest money (DD No. & Date) /Bank Guarantee No. and
Date, (valid for six months)
The bidder is a Manufacturing Company/Proprietorship Firm/
Corporation registered in India of SPV Cells / Modules / Battery / PV
System/ Electronics/LED lights/ (conforming to
relevant National / International Standards) empanelled in MNRE till
latest edition (Proof of being a manufacturer and empanelment of
Channel Partner to be enclosed)
OR
A PV System Integrator empanelled in MNRE as Channel Partner and
should have installed Solar Photovoltaic Lighting Systems sufficiently
and copies of Orders and certificates indicating its successful execution
to be enclosed along with empanelment certificate.
OR
The Bidder Should have Credit Rating (from MNRE
Accredited Rating Agency) of “SP 3B” and above as
on the date of bidding.

Annexure-III

3

Annex -III(a)
Annex-III(b)
Annex-III(c)
Annex-III(d)
Annex-III(e)
Annex-III(f)

4

Annex-IV

5

Annex -V

6

Annexure - VI

7

Annexure - VII

8

Annexure -VIII

9

Annexure -IX

10

Annexure-X

11

Annexure-XI

Test Certificates for following items be enclosed.
i. SPV Modules
a) IEC 61215 edition II/ IS 14286 for Crystalline Modules
b) IEC 61730 Part 1 & 2
c) STC Performance Report –I V curve
ii. Batteries –CECRI or MNRE authorized test centre report if battery
make is other than specified in this document.
iii. Balance of System
a) LED – LM-80-08 , L70 , LED luminaire- LM-79-08
b) Luminaries - IP 40 and charge controller housing- IP 21
Test Certificate for the complete tendered Solar PV power pack from a
MNRE authorized testing center along with entire test data be enclosed.
A copy of valid CST /State VAT/ TIN registration certificate
Overall Average Annual Turnover of the Company/Firm/Corporation
in the latest last three financial years ( A summarized sheet of turnover
of last three Financial Year certified by registered CA) with and latest
balance sheet
MNRE accredited off- Grid Channel Partner/ Programme Administrator
OR
Credit Rating (from MNRE Accredited Rating Agency ) of
“SP 3B” and above
A summarized sheet of cumulative experience in PV
systems/power plants certified by registered CA
Bidder’s cumulative experience * in last 10 years in supply and
installation/commissioning of total number of Solar PV Lighting
Systems. Cumulative nos.:
Value of a “Single Order” of PV Systems / Power Plants executed by
the Bidder (A copy of the order indicating its value and certificate
indicating its successful execution) Valued more than Rs. 50 Lacs upto
Rs. 2.00 Crore ;Valued more than Rs. 2.0 Crores
Bidder has Test Certificate for Solar Lanterns, Solar Home lighting
System, Solar Street Lighting System, Solar Water Pumping System or
SPV Modules, battery, Electronics, LED lighting unit etc from a MNRE

Yes/No/ Detail/Flag No.

<!-- page 7 -->

6

authorized testing center.(Test Certificate should have be latest after
2011) Number of Certificates issued:

12

Annexure- XII

Cumulative Experience* of the Bidder in executing Contracts related
to Solar Photovoltaic Systems/ Power Plants (Installed &
Commissioned)

50KWp-500KWp
>500KWp
13

Annexure-XIII

The bidder has ISO 9001 certification

14

Annexure-XIV

The bidder has ISO 14001 certification

15

Annexure-XV

The bidder has ISO 18001 certification

16

Annexure-XVI

Authorization letter of the Bidder, for the person representing his firm,
that he is authorized to discuss with specific mention of this e-tender.

17

Annexure-XVII

Cumulative Experience* of the Bidder in executing contracts
(Installed & commissioned) of Stand Alone Solar P V Systems/ Power
Plants:

18

Annexure-XVIII

The bidder is a SPV Modules Manufacturing Company, Registered in
India ,with a min. Capacity of (mention Capacity in MW per
annum)

19

Annexure- XIX

The bidder is a SPV cells Manufacturing Company, Registered in India,
with a min. Capacity of (mention Capacity in MW per annum)

20

Annexure- XX

Others
XX(i). An undertaking that the service centers will be
opened in allotted district and list will be submitted before
supply and installation for verification.
XX(ii). An undertaking that they will employ local youths having ITI/
diploma certificate holders in the execution of the project including
installation and maintenance as per as possible.
XX(iii). An undertaking that they will cooperate with the Gram Vidyut
Abhiynatas engaged by REC Ltd.

21

Annexure- XXI

Duly filled technical bid Part-6

Please flag the annexure and write flag number in the box.
*Bidder’s experience should be in supply, installation/commissioning (contracts executed, completed and handed over) of Solar
Photovoltaic Systems/ Power Plants for : MNRE supported Schemes / Programmes, (including Projects executed by channel partners
availing MNRE support) OR Any Government Organization/ Agency/ SNA/PSU OR private Agency/firm.
Note:
Bids received without supporting documents for the various requirements mentioned in the tender document may be rejected.
No extra paper should be submitted in e-tender as well as with hard copy.
If any paper certificate/document is not clear in scan and uploaded, the tender document may be rejected (scanning of paper are
not less than 150 dpi in black & white).
Hard copy of tender document should be in proper spiral binding and all annexures and their flags should be in proper order and
also uploaded in relevant files of e-tender.

(Signature of Bidder with Seal)

<!-- page 8 -->

7

2. PARTICULARS OF e-TENDER
1.
2.

3.
4.
5.
6.
7.

e-tender no.
Particulars of the work

Period of work
Last date and time of uploading of e-tender on
website
Period of validity of rates for acceptance
Date and Time of opening of e-tender (Technical
bid.)
Date and Time of opening of e-tender (Financial
bid.)

APEDA/DDUGJY/2015-16/01
Design, manufacture, supply, installation,
testing and commissioning of Solar PV
power pack as specified in the tender
documents with 05 years warrantee
comprehensive maintenance in the villages
indicated for Rural Electrification of 1058
Nos. of off-grid villages in Arunachal
Pradesh
6 months from the date of award.

28/04/2016 : 3.00 PM
3 months from opening date of financial bid
29/04/2016 at 11.00 AM
Will be intimated to technically qualified
bidders on the date of technical evaluation.

8.

Place of opening of e-tender

1.

Bidders are advised to study the tender Document carefully. Submission of e-Bid against this tender shall
be deemed to have been done after careful study and examination of the procedures, terms and
conditions of the tender Document with full understanding of its implications.
The e-Bid prepared in accordance with the procedures enumerated in ITB Clause 15 of Section-I should
be submitted through e-Procurement website http://www.arunachaltenders.gov.in
The e-Bids will be electronically opened in the presence of bidder’s representatives, who choose to
attend at the venue, date and time mentioned in the above table. An authority letter from the bidding
company/ firm/ corporation etc will be required for their representative to be present during opening of
the bids.
In the event of date specified for e-Bids opening being declared a holiday then the due date for opening
of e-Bids shall be the following working day at the appointed time and place. However, Director,
APEDA reserves the right to extend the date of opening of Financial Bid in unavoidable circumstances.
All the required documents including Price Schedule/BOQ should be uploaded by the e-Bidder
electronically in the PDF/XLS format. The required electronic documents for each document label of
Technical (Fee details, Qualification details, e-Bid Form and Technical Specification details)
schedules/packets can be clubbed together to make single different files for each label. All the enclosures
should be scanned and uploaded with the bid.

2.
3.

4.

5.

Urja Bhawan, T.T. Marg, Itanagar.

(Signature of Bidder with Seal)

<!-- page 9 -->

8

5. GENERAL PARTICULARS OF BIDDER
1

Name of Bidder

2

Postal Address

3

Mobile no.

4

Telephone, Telex, Fax No

5

E-mail

6

Web site

7

Name, designation and Mobile Phone No. of the
representative of the Bidder to whom all
references shall be made

8

Name and address of the Indian/foreign
Collaboration if any

9

Have anything/extra other than price of items (as
mentioned in price Schedule) been written in the
price schedule.

10

Have the Bidder to pay arrears of income tax?
If yes up to what amount?

11

Have the Bidder ever been debarred by any Govt.
Deptt. / Undertaking for undertaking any work?

12

Monthly supply capacity ( attach supporting
document)

13

Details of offer (please mention number of pages
and number of Drawings in the hard copy)

14

Reference of any other information attached by
the tenderer (please Mention no. of pages & no. of
drawings)

( Signature of Bidder with Seal)

<!-- page 10 -->

9

6. DECLARATION BY THE BIDDER
(REGARDING e-tender NO. APEDA/DDUGJY/2015-16/01)
I/We______________________________________________________ (hereinafter referred to as the Bidder)
being desirous of e-tendering for the work under the above mentioned e-tender and having fully understood the
nature of the work and having carefully noted all the terms and conditions, specifications etc. as mentioned in the
e-tender document,
DO HEREBY DECLARE THAT
1.

The Bidder is fully aware of all the requirements of the e-tender document and agrees with all provisions
of the e-tender document.

2.

The Bidder is capable of executing and completing the work as required in the e-tender.

3.

The Bidder accepts all risks and responsibilities directly or indirectly connected with the performance of
the e-tender.

4.

The Bidder has no collusion with other Bidders, any employee of APEDA or with any other person or
firm in the preparation of the bid.

5.

The Bidder has not been influenced by any statement or promises of APEDA or any of its employees,
but only by the e-tender document.

6.

The Bidder is financially solvent and sound to execute the work.

7.

The Bidder is sufficiently experienced and competent to perform the contract to the satisfaction of
APEDA.

8.

The information and the statements submitted with the e-tender are true.

9.

The Bidder is familiar with all general and special laws, acts, ordinances, rules and regulations of the
Municipal, District, State and Central Government that may affect the work, its performance or
personnel employed therein.

10.

The Bidder has not been debarred from similar type of work by APEDA and or by any Government
undertaking/ Department/ Ministry.

11.

This offer shall remain valid for acceptance for 3 Months from the date of opening of financial bid of etender.

12.

The Bidder gives the assurance to execute the e-tendered work as per specifications, terms and
conditions.

13.

The Bidder confirms the capability to design, manufacture, supply, install and commission and then to
carryout 5 years comprehensive warranty maintenance of Solar PV Power Packs which will be installed
under this e-Tender.

(Signature of Bidder with seal)

<!-- page 11 -->

10

PART-2: INSTRUCTION TO BIDDERS
SECTION 1: THE TENDER DOCUMENT
1.1 CONTENT OF e-tender DOCUMENT
1.1.1 The e-tender procedure and contract terms are prescribed in the e-tender Documents. In addition to the etender Notice the Bidding documents include.
PART-A (Techno-Commercial Bid)
Part -1
1 e-tender Notice
2 Covering Letter
3 Checklist of Annexures
4 Particulars of e-tender
5 General Particulars of Bidder
6 Declaration by Bidder
Part – 2: Instruction to Bidders
Section -1 Contents of e-tender document
Section -2 Eligibility condition
Section-3 Preparation of e-tender
Section-4 Submission of e-tender
Section -5 e-tender opening and evaluation
Section-6 Procedure for Finalization of Bid
Part – 3: General Conditions of Contract
Part – 4: Scope of Work & Technical specifications
Part – 5: Details of Warranty
Part – 6: Technical Bid
Part – B: Financial Bid
The Bidder is expected to examine all instructions, forms, terms and specifications as mentioned in the etender document. Failure to furnish all information required by the e-tender documents or submission of a bid not
substantially responsive to the Bid Document in every respect will be at the Bidder's risk and is likely to result in
out-right rejection of the e-tender

<!-- page 12 -->

11

1.2

LOCAL CONDITIONS

It shall be imperative on each bidder to fully inform him of all local conditions and factors, which may
have any effect on the execution of the works covered under these documents and specifications. APEDA shall
not entertain any request for clarifications from the Bidder, regarding such local conditions
1.3

CLARIFICATION AND PRE BID CONFERENCE:
A prospective Bidder requiring any clarification of the e-tender Documents may contact APEDA in
writing or by Fax at the APEDA's mailing address indicated in the Invitation for e-tender. The Bidder(s)
or their authorized representative(s) is / are invited to attend pre-bid meeting(s). APEDA will make all
efforts to respond to the queries during the Pre Bid Meeting to be held on 18/04/2016 at 11.00 AM in
APEDA Directorate Office at Urja Bhawan, TT Marg, Itanagar. The purpose of the pre-bid meeting
will be to clarify any issues regarding the Bid. A compiled list of questionnaire and APEDA’s response
will be uploaded on the website for information of all concerned in http://www.arunachaltenders.gov.in
and in http://www.apeda.org.in . All are requested to remain updated with the website. No separate reply/
intimation will be given elsewhere. Verbal clarifications and information given by the APEDA or its
employees or its representatives shall not be in any way entertained.

Enquiries/clarifications may be sought by the Bidder from:
Director,
Arunachal Pradesh Energy Development Agency,
Urja Bhawan, T.T. Mag, Itanagar -791111,
Phone: 0360-2211160
Fax: 0360-2214426
Email: apeda79@gmail.com
Website: http://www.apeda.org.in
1.4 AMENDMENT OF e-tender DOCUMENTS
At any time prior to the submission of the e-tender the APEDA may for any reason, whether at its own
initiative or in response to a clarification requested by the Bidder, modify the e-tender documents by
amendments. Such document shall be made available on websites: http://www.arunachaltenders.gov.in and
in http://www.apeda.org.in . All are requested to remain updated with the website. No separate reply/
intimation
will
be
given
elsewhere.

<!-- page 13 -->

12

SECTION 2: ELIGIBILITY CONDITIONS
Eligibility Conditions for Bidders
1.

Minimum Eligibility Conditions:
The Bidders should be
A Registered Manufacturing Company/Firm/ Corporation in India of SPV Cells / Modules Or
Battery Or PV System Electronics or LED Lights (Conforming to relevant National / International
Standards)
OR
A PV System Integrator empanelled as channel partner accredited by the MNRE for off grid
and decentralized solar application under JNNSM with MNRE.
(Should have the experience in supply, installation and commissioning of SPV Power
Plants and Systems)
OR
Should have Credit Rating (from MNRE Accredited Rating Agency ) of “SP 3B” and above
as on the date of bidding.
Bidder should have the Test Certificate(s) for the components of the Solar PV Power Pack they will
supply under this e-Tender(Test Certificate should have been issued on or after 2011 by any of the
MNRE approved Test Centers)
The bidder should have experience in at least any one of the last three years(i.e. FY 2012-13, 2013-14,
2014-15) in executing contract of Solar Photovoltaic Systems/Power Plants (Installed and
commissioned).
The Bidder should have valid CST /State VAT/ TIN/Service Tax registration certificate. A copy of
which should be enclosed.
The Average Annual Turnover of the Company/ Firm/ Corporation in the last four financial years (FY2011-12, 2012-13, 2013-14, 2014-15) should be at least Rs. 10.00 crores (rupees ten crores). This
must be the individual Company’s turnover and not that of any group of Companies. A summarized
sheet of average turnover certified by registered CA should be compulsorily enclosed along with
corresponding balance sheets.

<!-- page 14 -->

13

2. Other Eligibility Conditions
The “Financial bids” of only those bidders shall be opened, who qualify in “Minimum Eligibility Conditions” as above
and score at least 50 Points in “technical evaluation”. The “Points” for the “technical evaluation” shall be assigned as
under:
Sl. No.
1

2

3

4

5

6

7

8

9
10
11
12

Criteria
MNRE accredited off- Grid Channel Partner/ Programme Administrator
OR
Credit Rating (from MNRE Accredited Rating Agency ) of “SP 3B” and
above
Cumulative Experience* of the Bidder in executing contracts of Solar
Photovoltaic Systems/ Power Plants (Installation & Commissioning of
PV Systems/ Power Plants)
50KWp-500KWp
>500KWp
Bidder’s cumulative experience in last 10 years in supply and
installation/commissioning of total number of Solar PV Lighting
Systems. Cumulative nos.:
> 10,000 nos.
> 20,000 nos
Value of a “Single Order ” * of PV Systems / Power Plants executed by the
Bidder :
Valued more than Rs. 50 Lac upto Rs. 2.0 Crores
Valued more than Rs. 2.0 Crores
Cumulative Experience* of the Bidder in executing contracts (Installed
& commissioned) of Stand Alone Solar P V Systems /Power Plants:
At least 50% of the tendered value
At least 75% of the tendered value
Bidder has Test Certificate for Solar Lanterns, Solar Home lighting
System, Solar Street Lighting System, Solar Water Pumping System or
SPV Modules, battery, Electronics etc from a MNRE authorized testing
center. (Test Certificate should have been issued on or after 2011.)
Certificate for any two of the above
Certificate for more than two of the above

The bidder is a SPV Modules Manufacturing Company, Registered
in India ,with a min. Capacity of
--- 25MWp per annum
--- 50 MWp per annum
The bidder is a SPV cells Manufacturing Company, Registered in
India, with a min. Capacity of
--- 5 MWp per annum
--- 10 MWp per annum
The bidder has ISO 9001 certification
The bidder has ISO 14001 certification
The bidder has ISO 18001 certification
The bidder should have class A electrical license

Max. Point
20

5
10

5
10

5
10

5
10

5
10

5
10

5
10
3
3
3
5

*Bidder’s experience should be in supply, installation/commissioning (contracts executed, completed and
handed over) of Solar Photovoltaic Systems/ Power Plants for:
MNRE supported Schemes / Programmes, (including Projects executed by channel partners availing MNRE
support) OR Any Government Organisation/Agency/ SNA/PSU OR Private Agency/Firm.

<!-- page 15 -->

14

SECTION 3: PREPARATION OF e-Tender
3.1 LANGUAGE OF BID AND MEASURE
3.1.1The e-tender prepared by the Bidder and all correspondence and documents relating to the bid
exchanged by the Bidder and APEDA shall be written in the English provided that any printed
literature furnished by the Bidder may be written in another language so long as accompanied by an
English translation of its pertinent passages in which case, for purpose of interpretation units of
measurement shall be MKS system.
3.2 DOCUMENTS COMPRISING THE BID
3.2.1
(a)

The e-tender prepared by the Bidder shall comprise the following components
Covering letter as provided in e-tender document.

(b)
(c)

General particulars of bidder, as provided in e-tender document.
Declaration by the Bidder, as provided in e-tender document.

(d)

Documentary evidence establishing that the bidder is eligible to Tender and is qualified to
perform the contract if its tender is accepted. Check list of Annexure as provided in e-tender
document.

(e)

A blank copy of the e-tender document signed on each page, as a confirmation by the Bidder to
accept all technical specifications/ commercial conditions along with all necessary
enclosures/annexures.

(f)
(g)
3.3

Authorization letter of the Bidder, for the person representing his Company/Firm/ Corporation,
that he is authorized to discuss and with specific mention of this e-tender.
Duly filled technical bid format Part-6.
BID PRICE

3.3.1

The Bidder shall indicate prices on the appropriate financial bid schedule.

3.3.2

DUTIES AND TAXES
The price quoted should include all taxes and duties, custom duty, excise duty, service tax, sales
tax, C.S.T., local taxes, Trade Tax/VAT, Income Tax, Surcharge on income tax etc. if any. A
Bidder shall be entirely responsible for all taxes, duties, license fees, etc. All taxes payable as per
Government income tax & service tax norms will be payable by the Bidder. TDS will be
deducted from the payment of the Bidder as per the prevalent laws and rules of Government of
India and Government of Arunachal Pradesh in this regard.

3.4

BID CURRENCIES

3.4.1

Prices shall be quoted in Indian Rupees (INR) only

3.5

SECURITY DEPOSIT/ PERFORMANCE GUARANTEE:

3.5.1

The successful Bidders, who execute the agreement with APEDA for the work, shall have to
furnish a contract security amount equivalent to 10% of total value of the contract in the form of
Bank Guarantee valid for a period of 18 months from the date of execution of agreement. The
bank guarantee may be issued by a nationalized bank or State Bank of India or its subsidiary
bank. Bank Guarantee shall be in favour of "Director, APEDA". The aforesaid Bank Guarantee
shall be furnished prior to the execution of agreement within 7 days from the date of LoI/ Award
Letter.

<!-- page 16 -->

15

3.6

PERIOD OF VALIDITY OF e-tender

3.6.1

Validity of the offer should be 3 months from the date of opening of the Financial Bid of
the e-tenders. Without this validity the e-tenders will be rejected.

3.6.2

In exceptional circumstances; the APEDA will solicit the Bidder’s consent to an extension of
the period of validity. The request and the response there of, shall be made in writing. The
contract performance security provided under clause 3.5.1 above shall also be suitably
extended.

3.7

BID SECURITY (Earnest Money)

3.7.1

The bidder shall furnish, as part of its bid, bid security of Rs. 20.00 lakhs (rupees twenty Lakhs)
in the form of Demand Draft in favour of “Director, APEDA” payable at SBI, Itanagar and a
Bank Guarantee of Rs.100.00 lakhs (rupees one lakhs) only issued by a nationalized bank, or
State Bank of India and its subsidiary banks. The bank guarantee shall be valid for a period of 6
months from the opening of Financial Bid.

3.7.2

Any bid not secured with the Tender Fee and Earnest Money will be rejected by the APEDA as
non-responsive.

3.7.3

No Interest shall be payable on the amount of Earnest Money and the same will be released after
the e-tenders have been decided, to those Bidders who fail to get the contract.

3.7.4

The e-tender security (earnest money) may be forfeited:

a)

If a Tenderer withdraws its e-Tender during the period of e-Tender validity.

b)

If the successful Bidder fails to sign the contract within stipulated period.

3.7.5

EMD of successful bidder shall only be released after signing of agreement and submission of
10% Contract Security Bank Guarantee.

3.8

FORMAT AND SIGNING OF e-Tender

3.8.1

The bid must contain the name, residence and places of business of the persons making the eTender and must be signed and sealed by the Bidder with his usual signature. The name and
designations of all persons signing should be typed or printed below the signatures.

3.8.2

e-Tender by corporation/ company must be signed with the legal name of the corporation/
company/firm by the ‘President’, ‘Managing Director’ or by the ‘Secretary’ or other designation
or a person duly authorized

3.8.3

The original copy of the e-Tender shall be typed or written in indelible ink and shall be signed by
the Bidder or a person duly authorized to bid for the bidder to the contract. The letter of
authorization shall be submitted along with power-of-attorney. All the pages of the bid shall be
initialed by the person or persons signing the e-Tender.

3.8.4 The bid shall contain no interlineations, erasures or overwriting except as necessary to correct
errors made by the Bidder in which case such corrections shall be initialed by the person or
persons signing the e-tender.

(Signature of Bidder with seal)

<!-- page 17 -->

16

SECTION: 4: UPLOADING OF e-Tender

4.1

Uploading of e-Tender: The bid shall be uploaded online.

4.1.1

The tender must be completed in all technical and commercial respect and should contain requisite
certificates, drawings, informative literatures etc. as required in the specification.

4.1.2

First part (Part-A) should contain technical specification, brochure literature etc. All parts of tender
documents except Financial Bid should be uploaded as per e-procurement mode in due date and time.
Scanned copy of Requisite Earnest Money in the form of Demand Draft and Bank Guarantee should be
enclosed/ uploaded. Duly filled Technical Bid Part-6 must be uploaded.

4.1.3

The Bidder should submit Price Bid in Second Part. Second Part (Part-B) should contain Financial Bid
only and it should be uploaded as per e-procurement mode in due date and time.
Anything in regard to financial condition, payment terms, rebate etc. mentioned in Financial Bid may
make the tender invalid. Therefore, it is in the interest of the Bidder not to write anything extra in Part-B
except price.

4.1.4

The following document in hard copy must reach the office of APEDA at Urja Bhawan, T.T. Marg,
Itanagar, before opening date and time of Technical e-Bid failing which, tender shall not be considered.

4.1.4(a) Original Demand Draft towards the Tender Document Fee.
4.1.4(b) Original Demand Draft and Bank Guarantee towards Earnest Money
4.1.4( c) The hard copy of the blank e-Tender Document along with annexure duly signed ( every pages) by
bidders.
4.2

EXPENSES OF AGREEMENT: A formal agreement shall be entered into between APEDA and the
successful contractor/ bidder for proper fulfillment of the contract. The expenses of completing and
stamping of the agreement shall be paid by the successful bidder.

4.3

DEADLINE FOR SUBMISSION OF BIDS: Bids must be uploaded by the tenderer in the date, time and
address specified in the e-Tender Notice/ Tender Documents.

(Signature of Bidder with seal)

<!-- page 18 -->

17

SECTION 5: e-Tender OPENING AND EVALUATION

5.1

OPENING OF e-Tender
The procedure of opening of the e-Tender shall be as under:

5.1.1

First Part (part-A) uploaded having e-Tender Technical and commercial aspects super-scribed as
“Technical Bid” shall be opened at the time and date mentioned in the e-Tender Notice by APEDA’s
representatives in the presence of Bidders, who choose to be present.

5.1.2

Second Part (Part-B) containing Financial Bid shall be opened (after obtaining clarifications and
establishing technical suitability of the offer) as per schedule. Second Part of only those Bidders shall be
opened whose First Part (Part-A) shall be found commercially clear and technically suitable.

CLARIFICATION OF e-Tender
5.2.1
5.3

To assist in the examination, evaluation and comparison of bids the APEDA may at its discretion ask the
bidder for a clarification of its bid. The request for clarification and the response shall be in Writing.
APEDA reserves the right to interpret the Bid submitted by the Bidder in accordance with the provisions
of this document and make its own judgment regarding the interpretation of the same. In this regard
APEDA shall have no liability towards any Bidder and no Bidder shall have any recourse to APEDA
with respect to the selection process. APEDA shall evaluate the Bids using the evaluation process
specified in this document or as amended, at its sole discretion. APEDA’s decision in this regard shall be
final and binding on the Bidders.

(Signature of Bidder with seal)

<!-- page 19 -->

18

SECTION-6: Procedure for Finalization of BID
6.0

The Procedure for Finalization of BID would be as follows:

6.1

Finalization of BID:
First the Technical Bids shall be opened and evaluated.
Then the Price Bid of technically qualified bidders shall be opened.
The Party offering the lowest rate(s) (L1) will be the successful bidder. However, work may be
awarded to more than one party at the accepted lowest rate(s) if APEDA desires so in order to
achieve completion of work in time. The rate(s) will be quoted by the bidders districtwise and L1 will
also be decided districtwise.

6.2

Finalization of Empanelment:
First the Technical Bids shall be opened and evaluated.
Then the Price Bids of technically qualified parties shall be opened.

The lowest rate (i.e. L-1) will be given the preference, but it will not be binding on
APEDA to award the work to L-1. The approved rate may be decided based on a
justification made by APEDA on the offers received as too low a rate may affect quality
and progress of work.
L-1 i.e. lowest rate bidder or the party whose rate is accepted may not be awarded the
entire work. It may be distributed to other participating technically qualified parties also
in order to maintain quality of equipment/ work and also for timely completion of the
work which is time bound.
Approved justified/ lowest rate would be offered to other technically qualified bidders
(i.e. L-2, L-3 and so on) having price not more than 25% above the lowest / approved
rates (L-1) will be awarded the remaining quantity/ work (by district wise distribution)
which is left not awarded to the L-1. In other words a short list will be prepared amongst
the bidders on the line mentioned herein above.
APEDA will assign districts to the short listed contractor/ bidders /suppliers at its
wisdom and justification. Different districts have different numbers of beneficiaries and
distribution of districts will be done according to the number of beneficiaries in a district.
It will be ensured that one district will have only one service station set up by the
concerned contractor. APEDA will place the orders/ award the work to the contractor/
bidder on this line.

<!-- page 20 -->

19

Training of the users / beneficiaries will be arranged by the contractor/ bidder in each of
the village at the time of installation.
After award of work, it should be executed and completed within the time schedule
stipulated in the Tender Document, which is 6 months from the date of award. In case of
delay (for any reason other than Force Majeure conditions or any extension thereof
granted to him by APEDA), a penalty equal to 1.0% of the value of the unperformed
services for each week (For the purposes of calculation of delay, part of week shall be
treated as week) of delay until actual performance up to a maximum deduction of 10% of
the delayed services.
6.2

If required APEDA reserves the right to negotiate with (lowest) L-1 bidder before finalization of the
tender.

6.3

APEDA reserves the right at the time of awarding the contract to increase or decrease the quantity of
goods and locations of supply without any change in price or other terms and conditions.

6.4

APEDA reserves the right to accept or reject any or all the bids without assigning any reason.

6.5

NOTIFICATION OF AWARD:
Notification of awarding the contract and list of successful Bidder(s) for contract shall be displayed on
APEDA's website and shall be intimated in writing to the contractor.

6.7

CONTRACT AGREEMENT:
Before execution of the work, a contract agreement for execution of the work shall be signed by the
Bidder with APEDA within 15 days of communication from APEDA. In case agreement is not executed
within the stipulated time, Earnest Money of the bidder will be forfeited.

(Signature of Bidder with seal)

<!-- page 21 -->

20

PART 3: GENERAL CONDITIONS OF CONTRACT
1.0

In the Deed of Contract Agreement, unless the context otherwise requires:DEFINITIONS:

1.2.

“APEDA” shall mean “The Director of APEDA” and/ or his representative(s) and shall also include its
successors and assignees in interest. The “Contractor(s)” shall mean (successful bidder/ bidders) i.e. the
person/ firm/ company/ corporation/ organization, whose e-Tender(s) has/ have been accepted by
APEDA and shall include his/their/ its legal representatives and successors in interest.

1.3

The agreement shall be on turn-key basis. The work shall be completed within 6 months from the date of
award. However “APEDA” may in case of urgency, ask the bidder to complete the work earlier, with the
mutual consent of the contractor/ bidder and APEDA. In case the contractor/ bidder fails to execute the
said work within stipulated time, “APEDA” will be at liberty to get the work executed from the open
market without calling any tender/ e-tender and without any notice to the contractor/ bidder, at the risk
and cost of the contractor/ bidder. Any additional cost incurred by “APEDA” shall be recovered from the
contractor/ bidder. If the cost of executing the work as aforesaid shall exceed the balance due to the
contractor/ bidder, and the contractor/ bidder fails to make good the additional cost, “APEDA” may
recover it from the contractor/ bidders’ pending claims against any work in “APEDA” or in any lawful
manner.

1.4

That on the request of the contractor/ bidder and also in the interest of the organization the
“APEDA” is authorized to extend the validity of the agreement, subject to that the request of the
contractor/ bidder is received before the expiry of the agreement period, or any extended period granted
to the contractor/ bidder. Maximum period of extension shall be 2 months on the same terms and
conditions as contained in this agreement.

1.5

The agreement shall be deemed to be extended till the date of completion of last part of work as per award
subject to the completion period as provided in the clause 1.3.

1.6

It will be the sole responsibility of the contractor, to execute the work placed as per time schedule, and to
ensure quality parameters, specifications and other requirements provided in the e-Tender document and as
per agreement.

1.7

In the interest of the work, agreement executed between the contractor/ bidder and the “APEDA” may be
extended to a mutually agreed period, if the need so arises, but it will done under compelling situation/
condition only. It shall be the sole responsibility of the contractor/ bidder to get verified the quality &
quantity of the supplied material at the site of delivery and get the work completed as per award and
agreement.

<!-- page 22 -->

21

2

LIQUIDATED DAMAGES

2.1

If the contractor/ bidder fails to perform the services within the time periods specified in the contract,
then “APEDA” shall without prejudice to its other remedies under the contract deduct from the contract
price as liquidated damage, a sum equivalent to 1.0% of the price of the unperformed services for each
week (For the purposes of calculation of delay, part of week shall be treated as week) of delay until
actual performance up to a maximum deduction of 10% of the delayed services.
Once the maximum is reached, the “APEDA” may consider termination of the contract. In the case of
violation of contract, APEDA may confiscate pending payments/ dues of the contractor/ bidder assigning
specific reasons and shall also have the power to debar/ blacklist the contractor/ bidder in similar
circumstances. APEDA may also invoke performance security bank guarantee of 10%.

3

The contractor/ bidder shall have to comply with all the rules, regulations, laws and by-laws for the time
being in force and the instructions if any, of the organization, in whose premises the work has to be done.
“APEDA” shall have no liability in this regard.

4

FORCE MAJEURE

4.1

Notwithstanding the provisions of clauses contained in this deed; the contractor/ bidder shall not be
liable for forfeiture of its performance security, liquidated damages, termination for default, if he is
unable to fulfill his obligation under this deed due to event of force majeure circumstances.

4.2

For purpose of this clause, "Force majeure" means an event beyond the control of the contractor/ bidder
and not involving the contractor/ bidder's fault or negligence and not foreseeable. Such events may
include, but are not restricted to, acts of Government either in its sovereign or contractual capacity, wars
or revolutions, fires, floods, epidemics, quarantine restrictions and fright embargoes

4.3

However, If a force majeure situation arises, the contractor/ bidder shall immediately notify the
“APEDA” in writing. The decision of the competent authority of APEDA in above conditions shall be
final.

5

The High Court of Judicature at Guwahati and Courts subordinate thereto, at Itanagar, shall alone have
jurisdictions to the exclusion of all other courts.

6

The contractor/ bidder shall not, without the consent in writing of “APEDA”, transfer, assign or sublet
the work under the contract or any substantial part thereof to any other party

7

“APEDA” shall have at all reasonable time access to the works being carried out by the contractor/
bidder under the contract. All the work shall be carried out by the contractor/ bidder to the satisfaction of
“APEDA”.
If any question, dispute or difference what so ever shall arise between “APEDA” and the contractor/
bidder, in connection with the agreement except as to matters, the decisions for which have been
specifically provided, either party may forthwith give to the other notice in writing of exercise of such
question, dispute or difference and the same shall be referred to the sole arbitrator to be appointed on
mutual consent of both the parties. This reference shall be governed by the Indian Arbitration and
Conciliation Act, 1996, and the rules made there under. The arbitration proceedings shall be conducted
within the jurisdiction of Itanagar. The award in such arbitration shall be final and binding on both the
parties. Work under the agreement shall be continuing during the arbitration proceedings unless the
“APEDA” or the arbitrator directs otherwise.

8

<!-- page 23 -->

22

9

“APEDA” may at any time by notice in writing to the contractor/ bidder either stops the work all together
or reduce or cut it down. If the work is stopped all together, the contractor/ bidder will only be paid for
work done and expenses distinctly incurred by him as on preparation or the execution of the work up to
the date on which such notice is received by him. Such expenses shall be assessed by “APEDA”, whose
decision shall be final and bidding on the contractor/ bidder. If the work is cut down the contractor/
bidder will not be paid any compensation what so ever for the loss or profit which he might have made if
he had been allowed to complete all the work included in the contract.

10

INSPECTION AND TESTS

10.1

The following inspection procedures and tests are required by the “APEDA” in the presence of
“APEDA”’s representative if so desired by “APEDA”.

10.2

The “APEDA” or its representative shall have the right to inspect and / or to test the goods to confirm
their conformity to the contract. The special conditions of contract and/ or the Technical specifications
shall specify what inspections and test the “APEDA” required

10.3

INSPECTION AT WORKS.

10.3.1 The “APEDA”, through its duly authorized representative shall have at all reasonable times access to the
contractor/ bidders premises or works and shall have the power at all reasonable time to inspect and
examine the materials and workmanship of the works during its manufacture, supply, installation etc.
10.3.2 The contractor/ bidder shall give the “APEDA” , 15 day's written notice of any material being ready for
testing as and when it is required so. It shall be mandatory that such notice should reach “APEDA”
within 30 days of placement of award or signing of the agreement. Such tests shall be on the contractor/
bidder's accounts/ expenses except for the expenses of the inspector. “APEDA” reserves the full rights,
to waive off inspection of material
10.3.3 The contractor/ bidder are required to get the entire lot of the ordered material inspected at one time,
before the supply of the materials. In case the contractor/ bidder fails to get the entire lot inspected at one
time, the total expenses of the further inspection will be borne by the supplier/contractor/ bidder.

10.3.4

APEDA will bear the inspector’s cost at only one manufacturing plant. If a component is produced in
more than one location, then the cost of positioning the inspection in the second and subsequent plants
would be borne by the successful Bidder at their cost.

<!-- page 24 -->

23

10.3.5 The inspection by “APEDA” and issue of dispatch instruction there of shall in no way limit the liabilities
and responsibilities of the contractor/ bidder in respect of the agreed quality assurance forming a part of
the contract.
11.

WARRANTY

11.1

The contractor/ bidder shall warrant as per standards for quality that anything to be furnished shall be
new, free from all defects and faults in material, workmanship and manufacture, shall be of the highest
grade and consistent with established and generally accepted standards for material of the type ordered,
shall be in full conformity with the specifications, drawing or samples, if any and shall if operable,
operate properly.
Nothing in clause 10 above shall in any way release the contractor/ bidder from any guarantee or other
obligations under this contract.

11.2

Performance of Equipment: In addition to the warranty as already provided, the contractor/ bidder shall
guarantee satisfactory performance of the equipment and shall be responsible for the period or up to the
date specified in clause 11.3 hereof after the equipment has been accepted by the “APEDA” to the
extent for any defects that may develop such defects shall be removed at his own cost when called upon
to do so by the “APEDA”

11.3

The Warranty period shall be 25 Years for the PV modules and 5 years for complete system including
battery from the date of commissioning and handing over of the system. The contractor/ bidder shall
rectify defects developed in the system within Warranty period promptly. In case the defects are not
rectified within a week of the receipt of the complaint by the contractor/ bidder “APEDA” shall have full
liberty to restore the system in working condition. The expenditure so incurred by “APEDA” shall be
deducted from the contractor/ bidder pending claims, security/ performance guarantee deposit or in other
law full manner.

11.4

Since the maintenance of the system may also be taken up by the contractor/ bidder after expiry of 05
years of warranty period if the end user/”APEDA” so desires, the contractor/ bidder shall take up annual
maintenance of the installed systems.

11.5

The contractor/ bidder shall maintain the system under annual maintenance contract with the end user.

12.

Notice statement and other communication sent by “APEDA” through registered post or telegram or fax
or Email to the contractor/ bidder at his specified addresses shall be deemed to have been delivered to the
contractor/ bidder.

13.

Any work which is not covered under this contract but is essential and required for the completion of job
(to the satisfaction of APEDA) shall be carried out by the contractor as extra item for which payment
shall be made separately at the rates decided by APEDA

14.

The work shall be carried out by the contractor/ bidder as per design and drawings approved by
“APEDA”, wherever necessary, the contractor/ bidder shall submit relevant designs and drawings for
approval of “APEDA”, well in advance. Work carried out without APEDA’s approval shall not be
accepted and the “APEDA” shall have the right to get it removed and to recover the cost so incurred
from the contractor/ bidder.

<!-- page 25 -->

24

15.

The contractor/ bidder shall provide a manual/ booklet containing instruction manual/ routine
maintenance manual and maintenance record of the systems with each unit supplied or installed. This
shall be both in English and Hindi language
The following minimum details must be provided with the manual:
(a)
(b)
(c)
(d)
(e)

About the complete photovoltaic system including PV modules, battery and electronics
Do’s and Don’ts
Clear instructions on regular maintenance and trouble shooting of the system
Name & address of the contact person in case of non-functioning of the system.
About LED lighting

16.

The contractor/ bidder shall not display the photographs of the work and not take advantage through
publicity of the work without written permission of “APEDA”. The contractor shall distribute and fix a
calander at site, showing instructions, Do's, Don'ts with each unit. (The format of calander should be
approved by APEDA).

17.

PATENT RIGHT AND ROYALITIES.
The Contractor/ bidder shall indemnify the “APEDA” against all third party claims of
Infringement of patent, royalty's trademark or industrial design rights arising from use to the goods or
any part thereof.

18.

PACKING AAND FORWARDING

18.1

Contractor/ bidders, wherever applicable, shall after proper painting, pack and crate all the equipment in
such manner as to protect them from deterioration and damage during rail and road transportation to the
site and storage at the site till time of installation. Contractor/ bidder shall be held responsible for all
damage due to improper packing.

18.2

The contractor/ bidder shall inform the “APEDA” of the date of each shipment from his works, and the
expected date of arrival at the site for the information of the “APEDA” project offices at least 7 days in
advance.

19.

DEMURRAGE WHARFAGE, ETC
All demurrage, wharage and other expenses incurred due to delayed clearance of the material or any
other reason shall be to the account of the contractor/ bidder.

20.

INSURANCE
The goods supplied under the contract shall be fully insured against loss or damage incidental to
manufacture or acquisition, transportation, storage during transportation shall be included in the bid
price.

20.

TRANSPORTATION
The contractor/ bidder is required under the contract to deliver the goods to the site.

<!-- page 26 -->

25

21.

TERMINATION FOR INSOLVENCY
“APEDA” may at any time terminate the contract by giving written notice to the contractor/ bidder
without compensation to the contractor/ bidder, if it becomes bankrupt or otherwise insolvent, provided
that such termination will not prejudice or affect any right of action or remedy, which has accrued or will
accrue thereafter to the “APEDA”.

22.

TERMINATION FOR CONVENIENCE
The “APEDA”, may by written notice sent to the contractor/ bidder, terminate the contract, in whole or
in part at any time for its convenience. The notice of termination shall specify that termination is for the
purchaser’s convenience in the interest of “APEDA”.

23.

APPLICABLE LAW
The contractor/ bidder shall be interpreted in accordance with the laws of the purchaser’s country i.e.
India. The station of “APEDA” Headquarter shall have exclusive jurisdiction in all matters arising under
this contract.

25.
25.1

NOTICE
Any notice given by one party to the other pursuant to the contract shall be sent in writing or by Email
and confirmed in writing to the address specified for that purpose in the special condition of contract.

25.2

A notice shall be effective when delivered or on the notice’s effective date, whichever is later.

26.

TAXES, DUTIES AND INSURANCE:
The price quoted should include all taxes, duties and Insurance expenditure, custom duty, excise duty,
service tax, sales tax, C.S.T., local taxes, Trade Tax/VAT, Income Tax, Surcharge on income tax etc. if
any. A supplier/ contractor/ bidder shall be entirely responsible for all taxes, duties, license fees, etc. All
taxes payable as per Government income tax & service tax norms will be payable by the contractor/
bidder. If any new tax/duty is levied during the contract period the same will be borne by the contractor
exclusively. TDS will be deducted from the payment of the contractor/ bidder as per the prevalent laws
and rules of Government of India and Government of the Arunachal Pradesh in this regard.

27.

OTHERS:

27.1

I-V curve of the each module technical details such as Voc, Isc, , FF, cell efficiency and Pmax etc shall
be supplied along-with each consignment and copy should be sent to APEDA’s HQ for records.

27.2.

The Contractor/ bidder in consultation with concerned Project Officer of “APEDA” will conduct training
programme for users, focusing on main features, operation and maintenance of the systems.

27.3.

The Contractor/ bidder shall continue to provide spare parts after the expiry of warranty period at the
users cost. If the contractor/ bidder fail to continue to supply spare parts and services to users
“APEDA” shall take appropriate action against the Contractor/ bidder.
After successful supply/commissioning of the systems and training, the system will be handed over to
the concerned beneficiary.
It shall be the sole responsibility of the contractor/ bidder to get verified the quality & quantity of the
supplied material at the site of delivery.

27.4.
27.5.

<!-- page 27 -->

26

28.

PAYMENTS:
The payments shall be made as per the following terms and conditions:
i) Bill/ Invoice will be raised by the contractor after completion of installation and commissioning of the
systems in each village against which 80% of the value of work done shall be paid after it is duly
certified by the concerned district officers of APEDA as per the technical specification and terms and
conditions specified in the contract and after handing over the systems to the beneficiary (ies) and
certified by them
ii. 10% of the work done will be paid after establishing of service center(s) at the places wherever it is
required.
iii) The balance 10% payment will be released @2% at the end of each year for 5 years, on satisfactory
performance and timely submission of quarterly performance report. However, this can be released
immediately after installation and commissioning of the system against bank guarantee of 2 % each
valid respectively for 1,2,3,4 & 5 years.
iv) All the payment shall be released from APEDA head office, Itanagar on submission of bill, JCR duly
verified by the concerned district officer of APEDA and certified by the beneficiaries/ users.

29.

In case of any ambiguity in interpretation of any of the provisions of the tender, the decision of
“APEDA” shall be final and binding.

(Signature of Bidder with seal)

<!-- page 28 -->

27

Part -4
SCOPE OF WORK AND TECHNICAL SPECIFICATIONS
SCOPE OF WORK:
The scope of work includes the following:
A. Design, manufacture, supply, installation, testing and commissioning of Solar Power Packs including
05 years comprehensive warranty maintenance in various districts of Arunachal Pradesh as directed/
ordered by APEDA on contract basis as per the following specifications, terms and conditions to
electrify 1058 number of off-grid villages in Arunachal Pradesh (the number of villages may vary at
the time of execution).
B. Design, manufacture, supply, installation, testing and commissioning of Solar Street Lighting Systems
including 05 years comprehensive warranty maintenance and civil foundation work in 1;2;4 CC in
various districts of Arunachal Pradesh as directed/ ordered by APEDA on contract basis as per the
following specifications, terms and conditions (4923 numbers, which may vary at the time of
execution).
GENERAL TECHNICAL SPECIFICATIONS FOR SOLAR POWER PACK:
A Solar Power Pack under this contract will consist of 3 (there) Nos. of white LED luminary of 3Watt, 2 Nos.
of white LED luminary of 6Watt, mobile charging plug point, solar PV modules of 300Wp (2x150Wp) and
battery of 2x75AH capacity, necessary control electronics/ Charge Controller, inter connecting wires / cables,
module mounting structures etc. to operate the load for minimum 6 to 8 hrs daily. The broad performance
specifications of solar power pack systems are given below:-

BROAD PERFORMANCE PARAMETERS
Only indigenous modules shall be used in the project.
PV Module
SPV module 2x150 Wp at STC. Each Module Voc minimum of 21V.
Low Maintenance flooded electrolyte Tubular positive plate Lead Acid
Battery

batteries of capacity 12 V, 75 AH, C/10 (2 Nos.)

Light Source

White Light Emitting Diode (W-LED) batten type 6 Watt (2Nos.) and 3 watt
(3Nos.) Using LEDs which emits ultraviolet light will not be permitted.

Light Out put
Fan

White colour (colour temperature Typical 6000K with 510 K variation). The
illumination should be uniform without dark bands or abrupt variations and
soothing to the eyes.
24 Volt operated DC ceiling/ Table fan of maximum power consumption 20 watt
(Optional)

<!-- page 29 -->

28

Inverter

Charge Controller

(i) 24V, 100VA, pure sine wave inbuilt in charge Controller if supplied as per
Option-I given below.
(ii) 24V,300VA, pure sine wage if is supplied separately as per Option-II given
below.
24V,15A with MPPT

CHARGE CONTROLLER AND INVERTER OPTIONS:
Option-I:
There may an option for having an inbuilt inverter of 24V/100VA in the Charge controller and have a
3pin 5A AC outlet for operating TV/ Laptop/Mobile Charger. At the same time the charge controller has
also DC output ports for DC lighting load with a DC USB for Charging mobile and using radio etc. This
arrangement will minimize power loss. This will also increase reliability as separate circuits will be there
for DC and AC circuits.
Option-II:
As per MNRE specification, an inverter of 24V/300VA with AC output can be provided and the entire load
will operate on AC only.
The bidder will have to clearly work out the feasibility in the above two options and bring out clearly
what is preferable in terms of user friendliness and give their suggestion and quote for the arrangement
of Charge Controller and Solar Inverter.
INDICATIVE LOAD:
(i)

3 Nos. of White Light Emitting Diode (W-LED) Luminaire (max. 3.0 Watts each )

ii)

2 Nos. of White Light Emitting Diode (W-LED) Luminaire (max. 6.0 Watts each )

iii)

1 No. TV set or Laptop or Mobile Charger at a time (AC).

iv)

DC USB port for operating radio and mobile charging.

v)

DC outlet socket for operating DC fan (optional).

MINIMUM TECHNICAL REQUIREMENTS / STANDARDS FOR SOLAR POWER PACK:
1. DUTY CYCLE
The Solar Power Pack system consist of three nos. white LED luminary of 3Watt and two
numbers of 6 Watt, a mobile charging plug point should be designed to operate for minimum6
to 8 hrs daily.

<!-- page 30 -->

29

2. SPV MODULES:
i.

Only indigenous modules of reputed brand such as Tata BP Solar, BHEL, BEL, CEL, REIL,
Moserbaer, or equivalent ( IEC Tested) shall only be used in the project. Crystalline high power/
efficiency cells shall be used in the Solar Photovoltaic module. The power output of the module shall
not be less than 150 Wp at load voltage* 16.4 +- 0.2 Volt under standard test conditions (STC). * not
applicable in case of MPPT charge controller. A copy of test report at STC with I-V curve of solar
module used in test certificate issued by MNRE approved or authorized lab should be enclosed.

ii.

The open circuit voltage of the PV modules under STC should be at least 21.0 Volts.

iii.

PV module must be warranted for output wattage, which should not be less than 90% at the end of 10
years and 80% at the end of 25 years.

iv.

The terminal box on the module shall be designed for long life out door operation in harsh
environment should have a provision for opening for replacing the cable, if required.

v.

The offered module shall be in accordance with the requirements of MNRE.

vi.

Latest edition of IEC 61215 edition II / IS 14286 for Crystalline and shall be certified by MNRE
authorized test centre. The bidder shall submit appropriate certificates.

vii.

PV modules must quality to IEC 61730 Part 1- requirements for construction & Part 2 – requirements
for testing, for safety qualification.

viii.

Protective devices against surges at the PV module shall be provided. Low voltage drop bypass diodes
shall be provided and if required, blocking diode(s) may also be provided.

ix.

Identification And Traceability:
Each PV module must use a RF identification tag (RFID), which must contain the following
information:
(i)
(ii)
(iii)
(iv)
(v)
(vi)
(vii)
(viii)
(ix)
(x)

3.

Name of the manufacturer of PV Module
Name of the Manufacturer of Solar cells
Month and year of the manufacture (separately for solar cells and module)
Country of origin (separately for solar cells and module)
I-V curve for the module
Peak Wattage, Im, Vm and FF for the module
Unique Serial No. and Model No. of the module
Date and year of obtaining IEC PV module qualification
certificate
Name of the test lab issuing IEC certificate
Other relevant information on traceability of solar cells and module as per ISO 9000 series.
The RFID should be inside the module laminate.

BATTERY
Battery shall be flooded electrolyte Tubular Lead Acid, Low Maintenance type with low antimony lead
alloy plates and ceramic vent plugs. The positive plate should contain low antimony casted at high
pressure to ensure the void free and consistence grain orientation to protect plate support from anodic

<!-- page 31 -->

30

corrosion. The container of battery should be of minimum 400 mm high made of PPCP of high tensile
and acid resistance polyester gauntlets. The batteries should conform to IS 1651 / IS 13369. A copy of
the relevant test certificate for the battery should be furnished. The battery of reputed Indian make Exide,
Amco, HBL, Luminious, Amar raja, Tata power or equivalent (Tested by Central Electro-chemical
research laboratory, CECRI, Tamilnadu or authorized test centre of MNRE for relevant IS 1651/IS
13369/IEC 61427 standard) shall only be used and the copy of detail test report should be enclosed as per
standard parameters.
i.
ii.
iii.

iv.
v.
vi.
vii.
viii.
ix.
x.
4.

Capacity of the battery shall not be less than 24V, 150 Ah at C10 rate (2X75AH).
DOD shall be 75% i.e., at least 75 % of the rated capacity of the battery should be between
fully charged & load cut off conditions.
Battery shall have a design life expectancy of minimum 1500 cycle at 80% DOD at 25°C
with C10 discharge. Life cycle details received from original manufacturer should be
attached.
Battery terminal shall be provided with covers.
Suitable carrying handle shall be provided.
Bidder shall mention the design cycle life of batteries at 75%, 50% and 25% depth of
discharge at ambient temperature up to 45 degree C.
The batteries shall be designed for operating in ambient temperature of site upto 50 degree
C.
The self discharge of batteries shall be less than 3-4 % per month of rated capacity at 27
degree C.
Batteries shall be provided with micro porous vent plugs & acid level indicator.
Batteries shall be provided with physical parameters along with detail of length, width,
height and weight with and without acid.

LIGHT SOURCE:
i.

The light source will be of white LED type Mid Flux LEDs .The color temperature of white LEDs
used in the system should be in the range of 6000°k with standard tolerance of 510°k. Use of LEDs
which emits ultraviolet light will not be permitted. The quality of light should be soft soothing to the
eye .It must be free from the glare.

ii. The illumination should be uniform without dark bands or abrupt variations, and soothing to the eye.
Higher light output will be preferred. The light output from the white LED light source should be
almost constant.
iii. The lamps should be housed in an assembly suitable for indoor use and shall comply to IP40/ or as
per MNRE specification. The temperature of heat sink should not increase more than 30 degree C
above ambient temperature even after 48 hrs of continuous operation. Heat Sink Material used in
the LED batten should be of Extruded Aluminum as body and good heat sink in order to have good
heat dissipation and thermal management for ensuring the better life of the luminaries with high
quality of Polycarbonate diffuser for achieving soft and glare free light.
iv.

Mid power LED of CREE/NICHIA/OSRAM/SEOUL SEMICONDUCTOR/PHILIPS /
LUMILEDS /LEDNIUM/LG Make or equivalent (Having LM79 and LM 80 test report) shall only
be used.

v.

The lumens output of luminaire should be typical 480 lumens for 6watt and typical 210 lumens
for 3 watt lamp with permissible standard tolerance. The uniformity of light should be more than
o.6 and Emin/Emax ratio should be more than 0.4.

vi.

The LEDs luminaire should have life time about 50,000 hrs as per L70.

<!-- page 32 -->

31

vii.

The lumen depreciation of LED luminaire shall not be more than 30% at 50,000 burning hours
as per L70.

viii.

Power consumption of the LED Luminaire / Lighting unit shall be Nominal 6 Watt and Nominal 3
watt (including LED Driver power loss) with permissible standard tolerance.

ix.

The luminaire should be wall mounted and placed at the centre of the wall and 2.5 m above the
ground.

x.

Other Parameters

:

LED DC current regulation – better than 3 % Input – 24 V DC
Driver Type- DC-DC (as per IEC 62384)
CRI - Typical 75 % and not less than 70
Lighting quality- Free from glare,flickering and UV
Ambient temp– upto 50 deg
Total electronics efficiency > =90 %

xi.

Driver Characteristics - reverse polarity protection and suitable to operate between 20V to 28V

xii.
xiii.
xiv.
xv.

Auto resettable reverse polarity protection shall be provided
LED lighting unit shall comply to L70, L79-08 and L80-08 or as per MNRE specification.
Standards and copy of test certificate should be submitted.
The make, model number, country of origin and technical characteristics of white LEDs used in
the lighting system must be furnished.
xvi. The beam angle of luminaire shall be min 100 deg and the distribution shall be symmetrical on
either side of axis.
xvii. The luminaires have to be mounted on the wall only and the light must be distributed.
xviii. Luminaries should have embossing of manufacturer and be manufactured in India.
5.

ELECTRONICS
i.
MPPT to maximize energy drawn from the Solar PV array. The MPPT charger shall be
microcontroller based. The details of working mechanism of MPPT shall be mentioned.
PV charging efficiency shall not be less than 90% and shall be suitably designed to meet
array capacity. MPPT must conform to IEC 62093, IEC 60068 as per specifications. At
least compliance test report of MPPT as per EN50530 should be submitted.
ii.

The charge controller shall have
(i) Appropriate battery charging algorithms with temperature compensated set points for
charging/ discharging
(ii) PV array disconnect/reconnect and load disconnect/reconnect points.
(iii) Charger rating 24V 15A
(iv) Protection against polarity reversal of PV array and battery, Over Current, Short
Circuit, Deep Discharge, Blocking diode protection against battery Night time
leakage through PV Module

iii.

Electronics should operate at 24 V and the efficiency of DC-DC converter should be at least
90 %.

<!-- page 33 -->

32

iv.

The system should have protection against battery overcharge and deep discharge conditions.
The numerical values of the cut off limits of lower voltage should not be less than 11.1 Volt.

v.

Fuses should be provided to protect against short circuit conditions.

vi.

A blocking diode should be provided as part of the electronics, to prevent reverse flow of
current through the PV module, in case such a diode it not provided with the PV module.

vii.

Full protection against open circuit, accidental short circuit and reverse polarity should be
provided

viii.

The self consumption of the charge controller shall not be more than 20 mA at rated voltage
and rated current.
Adequate protection shall also be incorporated under no-load conditions (i.e. when the
system is ON & the load is removed.

ix.
x.

The system should be provided with 3 LED indicators: a green light to indicate charging in
progress, DARK GREEN LIGHT indicating battery full charged and a red LED to indicate
deep discharge condition of the battery. The green LED should glow only when the battery
is actually being charged.

xi.
xii.
xiii.
xiv.

All capacitors ceramics based shall be rated for max. temp of 105° C..
Resistances shall preferably be made of metal film of adequate rating.
Fibre glass epoxy of grade FR 4 or superior shall be used for PCB boards.
The voltage drop from module terminals to the battery terminals should not exceed 0.6
volts including the drop across the diode and the cable when measured at maximum
charging current.

xv.

xvi.

The charge controller should have output port for each light, fan and mobile charging with
maximum output power 45 watt. Overload and short circuit protection should be
incorporated.
Charge controller should be used indoor & housed in a suitable casing as per IP21.

xvii.

The charge controller should be mounted on wall above 6 feet from ground.

<!-- page 34 -->

33

Technical Requirement/Standards
Item / System

Applicable BIS /Equivalent IEC Standard Or MNRE Specifications
Standard Description

Solar PV Systems

Standard Number

Crystalline Silicon Terrestrial PV
Modules
IEC 61215 / IS14286
Test Certificates / Reports from
IECQ / NABL accredited laboratory
for relevant IEC / equivalent BIS
standard. If IEC
certificates are not available for 120
Wp capacity, qualification
certificate from IEC / NABL
accredited laboratory as per relevant
standard for any of the higher
wattage regular module shall be
furnished. Further, the manufacturer
should certify that the supplied
module is also manufactured using
same material design and process
similar to that of certified PV
module

Charge Controller/MPPT Units and
Protections

IEC IEC 62093 Equivalent BIS Std. or
as pe MNRE specification.

Storage Batteries

General Requirements & Methods
of Testing Tubular Lead Acid
/Capacity Test Charge/Discharge
Efficiency Self-Discharge

IS 1651/ IS 13369

Cables

General Test and Measuring Method

IEC 60189

PVC insulated cables for working
voltage up to and including 1100 V
UV resistant for outdoor installation

IS 694/ IS 1554

General Requirements

IEC 62208 IP21

Junction Boxes /Enclosures for Charge
Controllers/

Luminaries
LED

IS/IEC 69947

IP 40
Lamps
Luminary
Cycle life
Driver performance

LM -80-08
LM 79-08
LM 70
IEC 62384
Or as per MNRE specification.

<!-- page 35 -->

34

6.

MECHANICAL HARDWARE

(i)
A metallic frame structure (hot dip galvanized with 35*35*3 mm angle) to be fixed on the roof. The
frame
structure should be fixed at 30 degree from horizontal facing true south.
(ii)

Battery Box :
A vented metallic box of 18 SWG thick made of pre coated galvanized (60 micron thickness) ms
sheet for housing the storage battery indoors should be provided with proper lock and key. The
boxes should be inscribed with APEDA written on at least two faces. The size of box should be as
per battery size (including vent plug/level indicator) providing minimum clearance of 25 mm on
all sides. Louvers for proper ventilation should be provided on one side and back of the battery
box. No vent shall be providing on top of battery box. Box should be provided with proper
locking arrangement. The edges of box should be turned properly to give smooth edge and good
strength. Two wooden battens should be fixed inside the battery box to avoid the electrical
contract between battery and box. Danger logo as approved by APEDA shall be screen printed on
the box. Since the battery box will be sited on ground surface, it should be kept on
plastic/rubber/jute mat minimum 10 mm thick to avoid the direct contact on ground.

(iii)

Electric Cable:
The electric cable used shall be twin core PVC insulated water and UV resistance copper cable of
minimum size 1.5mm. Cable shall meet IS 1554 / 694 Part 1:1988 & shall be of 650V/1.1 kV.

7.

OTHER FEATURES:
The contractor / bidder will have service center(s) established at least one in each district of their
operation and keep a technician and necessary spare parts readily available so that the
beneficiaries can get their system rectified/ repaired when fault occurs. The technician(s) of the
contractor will go to the villages from time to time and check the systems in a routine way.

8.

INSTALLATION OF SYSTEM:
The system should be properly installed at each of the household of the beneficiaries in different
villages. The SPV module mounting structure along with suitable mounting legs should be properly
grouted depending upon the location and requirement of the site. The grouting should be such that
it should withstand the maximum wind speed /storm. The frame should be fixed with nuts and
bolts. Appropriately sized cables should be used to keep electrical losses to a bare minimum. All
wiring should be in a proper conduit or capping case. Wire should not be hanging loose. Any minor
items which are not specifically included in the scope of supply but required for proper installation
and efficient operation of the SPV systems, is to be provided by the manufacturer as per standards.
Wiring should be joint less and switches should be of appropriate value and suitable for DC
operation.

<!-- page 36 -->

35

9.

AUTHORIZED TESTING LABORATORIES/ CENTERS
Test certificates / reports for the BOS items including LED lights / components can be from any of the
NABL/ IEC Accredited Testing Laboratories or MNRE approved test centers.

20.

WARRANTY
The mechanical structures, electrical works including power conditioners/inverters/charge controllers/
maximum power point tracker units/distribution boards/digital meters/ switchgear/ storage batteries, etc.
and overall workmanship of the Solar power packs/ systems must be warranted against any
manufacturing/ design/ installation defects for a minimum period of 5 years.
Traceability of the product to be supplied
In order to prevent the misuse of the product such as unauthorized sale or diversion to the open market,
the following incorporation shall be made in the product.
Engraving (or) Screen printing of APEDA at a suitable place on the main components viz., SPV Panel,
Battery, LED Lighting Units to be used in the installation of the solar power packs.

GENERAL TECHNICAL SPECIFICATION OF WHITE LED SOLAR STREET LIGHTING SYSTEM:
DEFINITION:
Light Emitting Diode (LED) is a p-n junction device which emits light when forward electric
current passes through it. A LED based solar street lighting system aims at providing solar electricity for
operating LED lights for specified hours of operation per day. The broad performance specifications of a White
Light Emitting Diode (W-LED) light source based solar street lighting system are given below:
BROAD PERFORMANCE PARAMETERS:
Light Source White Light Emitting Diode (W-LED) Light output White colour (colour temperature 55000 65000 K) minimum 25 LUX for the first 6 hours of operation then minimum 12 lux for the balance operating
hours. When measured at the periphery of 4 meter diameter from a height of 4 meter. The illumination should be
uniform without dark bands or abrupt variations, and soothing to the eye. Higher light output will be preferred.
Mounting of light Minimum 4 metre pole Mounted PV Module 75 Wp under STC, measured at 16.4 Volt load.
Module Voc minimum of 21V. Battery Tubular Positive plate Lead acid or gel type VRLA , 12 V- 75 AH @
C/10, Max DoD 80%, Electronics Min 90% total efficiency, Average duty cycle - Dusk to dawn, Autonomy - 3
days (Minimum 42 operating hours per permissible discharge)
DUTY CYCLE:
The LED solar street lighting system should be designed to operate from dust to dawn, under average daily
insolation of 5.5 kWh /sq.m. on a horizontal surface.
LIGHT SOURCE:
1. The light source will be of white LED type. Single lamp or multiple lamps can be used; Wider

<!-- page 37 -->

36

view angles of a minimum of 120o or more. The luminous performance of individual LED used
should not be less than 90 lumen/watt when measured luminaire as whole. The colour
temperature of white LEDs used in the system should be in the range of 55000 K – 65000 K. Use of
LEDs which emits ultraviolet light will not be permitted.
2. The light output from the white LED light source should be constant throughout the duty cycle.
3. The lamps should be housed in an assembly suitable for outdoor use. The temperature of LED should increase
not more than 150 above ambient temperature. This condition should be compiled even after two hours of
operation at its maximum operation voltage ( ie. Just before over voltage cut off) The white LED should be of
high quality and should stands for minimum 50000 hours. If the luminary fails/ need repair in LED/ electronics
the whole should be replaced with the new one within the gurrantee period.
4. The make, model number, country of origin and technical characteristics of white LEDs used in
the lighting system must be furnished.
PV MODULE:
1. The PV module (s) shall contain mono/ multi crystalline silicon solar cells with IEC
61215(revised) certification or equivalent National or International Standards. The
manufacturer should have the required certification for at least one of their regular modules.
Further, the manufacturer should certify that the submitted module is also manufactured
using same design and process
2. The power output of the PV module must be reported under standard test conditions (STC) at 16.4 Volt
loading voltage. I_V curve of the each module should be submitted at the time of installation.
3. The open circuit voltage of the PV modules under STC should be at least 21.0 Volts.
4. The terminal box on the module should have a provision for opening for replacing the cable, if required.
5. A strip containing the following details should be laminated inside the module so as to be clearly
Visible from the front side:
a) Name of the Manufacturer or distinctive Logo
b) Model or Type No.
c) Serial No.
d) Year of make
BATTERY:
(i) Tubular positive plate Lead acid or gel type VRLA battery should conform to latest BIS standards. A copy of
the test certificate for the battery (including its make, country of origin and model number) used in the system
should be provided.
(ii) At least 80 % of the rated capacity of the battery should be between fully charged & load cut off conditions.
ELECTRONICS:
(i) The total electronic efficiency of DC-DC converter should be at least 90 %.
(ii) Electronics should operate at 12 V and should have temperature compensation for proper
charging of the battery throughout the year.
(iii) The light output should remain constant with variations in the battery voltages.

<!-- page 38 -->

37

(iv) LED luminaire should be 12watt with a timer circucuit inbuilt which can automatically on after 6 hours
of operation and reduce the luminaire wattage 50% of actual load.
ELECTRONIC PROTECTIONS:
1. The system should have protection against battery overcharge and deep discharge conditions. The
numerical values of the cut off limits must be specified, while submitting the samples for the testing
purposes.
2.

Fuses should be provided to protect against short circuit conditions.

3. A blocking diode should be provided as part of the electronics, to prevent reverse flow of current through
the PV module(s), in case such a diode is not provided with the PV module.
4. Full protection against open circuit, accidental short circuit and reverse polarity should be
provided.
5. Adequate protection is to be incorporated under no load conditions, e.g. when the lamps are removed and
the system is switched ON.
6.

Electronics should operate at 12 V and should have temperature compensation for proper
charging of the battery throughout the year.

7.

The W-LED driver circuit should be based on constant voltage, constant current, high
frequency technology. The component used in LED driver circuitry should be highly reliable of reputed
make and efficient. Efficiency : The total electronic efficiency should be at least 90%. W-LED Life :
Lumen output of W- LED should remain same though out the warranty period. CHARGE
CONTROLLER: The unit should have the following feature:
i)
ii)
iii)
iv)

v)
vi)

vii)
viii)
ix)
x)
xi)

This unit should be designed for charge regulation of storage battery and safe guard the battery
against over charge & deep discharging.
The voltage cut-off should be set in such a way to utilize the 80% of the fully charged battery
capacity.
The lower limit of cut off voltage should not be less than 11.4 volts.
The charge controller should reconnect the load when battery gets fully charged. The difference
in these two voltage set point should be neither too small nor too large to avoid the relay
chattering.
A reverse blocking diode should be provided to prevent discharge of
battery in rainy season and in night.
The various functions should be displayed through LED indicator indicating the operations being
carried out by the controller such as, load current off (red) battery charging (green) The light
indicator of lower voltage should be lower at 11.6 volts. However the unit with red and Green
shall also be accepted.
The indicator should be fixed on front side of the battery box/ Luminary.
A switch & fuse should be provided with the controller.
The unit should have protection against short circuit, lightening, reverse polarity surge etc.
The PCB’s of controller should be glass epoxy.
All the connector indication should be covered with transparent hard plastic sheet screened
properly.

<!-- page 39 -->

38

MECHANICAL COMPONENTS:
(i)

Metallic frame structure (with corrosion resistance paint) to be fixed on the roof of the house to
hold the SPV module. The frame structure should have provision to adjust its angle of
inclination to the horizontal between 0 and 45, so that it can be installed at the specified tilt
angle.

(ii)

It should be possible to mount the light source on a metallic arm attached to the pole.The
metallic arm for holding the light assembly should be extended at least 0.5 metres from the pole
and set at a suitable angle to maximize uniform illumination of desired level over the specified
area.

(iii)

A vented metallic / polimer box with acid proof corrosion resistance paint (in case of metallic)
for housing the storage battery outdoors should be provided. The quality should be of high
standards to withstand the life period. If defect arrises in the gurrantee period, same is to be
(mandatory) replaced.

(iv)

The SPV module should be fixed on a rigid pole. The pole should be of minimum 65 NB GI
pipe (B Class) of at least 03 mm thickness.

(v)

The pole should be made of GI steel pipe with a height of 4 metersabove the ground level after
grouting and final installation. The pole should have the provision to hold the weather proof
lamp housing. The pole along with base plate should have suitable cement concrete foundation
to assisted local worst climate conditions. The base plate shall be connected with the foundation
with holding down bolted.

(vi)

SPV panel shall be mounted on pole. The mounting structure shall be fixed in the center of pole
made flat at fixing end, square angle adjusting plate of 115 mm size 3 mm thick shall be
provided. So that SPV panel can be fixed at inclination of 15 or 30 degree from horizontal.

BATTERY BOX:
The battery box should be made of suitable polymer or 20 SWG, MS sheet. The battery box shall be painted with
acid proof corrosion resistant paint ( in case of metal) with APEDA written on at least two faces. The box shall
be properly painted after chemical cleaning & primer coating. The size of box should be as per battery size
providing sufficient clearance on all sides. Lovers for proper ventilation should be provided on each side and
back of the battery box. No vent shall be providing on top of battery box.
Box should be provided with proper locking arrangement. The edges of box should be turned properly to give
smooth edge and good strength. Two wooden battens should be fixed inside the battery box to avoid the
electrical contract between battery and box. However, polymer material can be used for battery box.
Serial No.: Each system should have a serial number starting with APEDA (Seriol No.) to be mentioned on a
name plate with manufacture's name on the battery box.
ELECTRIC CABLE:
The electric cable used shall be twin core PVC insulated copper cable of size 24/0.20. The size of wire between
luminary and battery should not be less than 32/0.20 copper. The battery lead should be provided with the
suitable battery clip.
(i)

Components and parts used in the solar street lighting system should conform to the latest BIS
specifications, wherever such specifications are available and applicable.

<!-- page 40 -->

39

(ii)

Other hardware such as clamp, nut bolt etc should be as per requirement of system. The material should
be of good quality.

OTHER FEATURES:
(i)

The system should be provided with 2 LED indicators: a green light to indicate charging in progress and
a red LED to indicate deep discharge condition of the battery. The green LED should glow only when
the battery is actually being charged.

(ii)

There will be a Name Plate on the system body, which will give:
(a) Name of the Manufacturer or Distinctive Logo.
(b) Model Number
(c) Serial Number
(d) Year of manufacture

(iii)

Necessary lengths of wires / cables, switches suitable for DC use and fuses should be
provided.

QUALITY AND WARRANTY:
(i)

Components and parts used in White LED solar street lighting systems should conform to the
latest BIS / international specifications, wherever such specifications are available and
applicable. A copy of the test report / certificate stating conformity of BIS /international
standards must be submitted.

(ii)

The PV module will be warranted for a minimum period of 25 years from the date of supply and
the complete White LED solar street lighting system including the battery) will be warranted for
a period of at least 5 years from the date of supply.

DOCUMENTATION:
(i)

An Operation, Instruction and Maintenance Manual, in English language, should be provided
with the solar street lighting system.

(ii)

The following minimum details must be provided in the Manual:
(a) About Photovoltaics
(b) About White LED solar street lighting system - its components and expected
Performance.
(c) About PV module. In case of imported modules it is mandatory to provide a copy of the
international product qualification certificate.
(d) About White LED Lights. The make, model number, country of origin and technical
characteristics of LEDs should be stated in the product data sheet and furnished to APEDA.
(e) About battery and electronics used
(f) Clear instructions about mounting of PV module.
(g) About charging and significance of indicators.
(h) DO's and DONT's,
(i) Clear instructions on regular maintenance and trouble shooting of solar street lighting system.
(j) Name and address of the person or service center to be contacted in case of failure or
complaint.

<!-- page 41 -->

40

INSTALLATION OF SYSTEM:
The system should be properly installed at site. The SPV module mounting structure along with pole should be
properly grouted depending upon the location and requirement of the site. The grouting should be such that it
should withstand the maximum wind speed /storm. The pole should be grouted with CC mixture of 1:2:4 of
radius of 300 mm having depth of 900mm.adequate space should be provided behind the PV module/array for
allowing un obstructed air flow for passive cooling. Cables of appropriate size should be used to keep electrical
losses to a bare minimum. Care should be taken to ensure that the battery is placed with appropriate leveling on a
structurally sound surface. The control electronics should not be installed directly above the battery. All wiring
should be in a proper conduit or capping case. Wire should not be hanging loose. Any minor item, which is not
specifically included in the scope of supply but required for proper installation and efficient operation of the SPV
systems, is to be provided by the manufacturer/ supplier.

<!-- page 42 -->

41

PART -5
WARRANTY AND MAINTENANCE
The PV modules will be warranted for a minimum period of 25 years from the date of supply. (Output
wattage should not be less than 90% at the end of 10 years and 80% at the end of 25 years). The
mechanical structures, electrical components including battery and overall workmanship of the Solar
power pack Systems must be warranted for a minimum of 5 years from the date of commissioning and
handing over of the system. The Comprehensive Maintenance (within warranty period) shall be executed
by the firm themselves or through the authorized dealer/ service center of the firm in the concerned
district. It is mandatory for the contractor/ bidder to open an authorized service center in the concerned
district before the supply/installation of the system. Necessary maintenance spares for five years trouble
free operation shall also be supplied with the system. The contractor/ bidder shall be responsible to
replace free of cost (including transportation and insurance expenses) to the purchaser whole or any part
of supply which under normal and proper use become dysfunctional within one month of issue of any
such complaint by the purchaser.

The service personnel of the Successful Bidder will make routine quarterly maintenance visits. The
maintenance shall include thorough testing & replacement of any damaged parts Apart from this any
complaint registered/ service calls received / faults notified in the report generated by the IVRS should
be attended to and the system should be repaired/ restored/ replaced within 4 days. A separate Service &
Maintenance manual shall be maintained with each system as per the format provided by APEDA. The
deputed personnel shall be in a position to check and test all the components regularly, so that preventive
actions, if any, could be taken well in advance to save any equipment from damage. Any abnormal
behavior of any component shall be brought to the notice of APEDA to appropriate action. Normal and
preventive maintenance of the SPV home lighting systems such as cleaning of module surface, topping
up of batteries, tightening of all electrical connections, cleaning & greasing of battery terminals, also
the duties of the deputed personnel during quarterly maintenance visits. During operation and
maintenance period of the Solar power pack systems, if there is any loss or damage of any component
due to miss management/miss handling or due to any other reasons pertaining to the deputed personnel,
what-so-ever, the supplier shall be responsible for immediate replacement/rectification. The damaged
component may be repaired or replaced by new component. Contractor/bidder shall submit quarterly
maintenance report regularly to concern project office with intimation to APEDA head quarter within
15days. Failing which payment for such period will not be released or recommended.

<!-- page 43 -->

42

PART-6
TECHNICAL BID
e-Tender NO. APEDA/ DDUGJY/2015-16/01
Technical Bid (Part-A)
Description

A.

B.

C.

Solar PV Module
1. Type of Module
2. Make
3. Availability of RFID tag
4. Max power at STC Pmax (W)
5. Max power voltage Vmp(V)
6. Max power current Imp(A)
7. Open circuit voltage Voc (V)
8. Short circuit current Isc (A)
9. Load current at 16.4 Volt Iload
10. Conversion Efficiency
11. No of cells per module
12. bypass diodes
13. Solar module frame material
14. Module Dimension
15. Module Weight
16. Fill factor
Battery
1. Make
2. Type
3. Capacity of Battery
4. Self Discharge
5. DOD
6. Design Cycle Life of battery
7. Charge efficiency
8. Size & Weight of Battery
Electronics
1. Make
2. Charger Type
3. PV Charging Efficiency
4. Idle current consumption
5. Operating voltage
6. Temperature compensated set points
7. Details of Indicators provided
8. Details of Protections provided

To be furnished by the Tenderer
Solar Power Pack Solar Street Light

<!-- page 44 -->

43

D.

i.
Battery Over charge set value
ii. Deep discharge set value
iii. Short Circuit
vi. Open Circuit
v.
Reverse polarity
vi. Blocking Diode
vii. Others
LED Lighting Unit
1. Make and material of housing
2. Power consumption of LED lighting unit.
3. No of LEDs
4. Wattage of each LED
5. Driver Consumption
6. Make and origin of LED
7. Lumens output
8. LED DC Current Regulation
9. Input Voltage
10. Beam Angle
11.

E.

F

G.

CRI

12. LED Efficacy
13. Luminaire Efficiency
14. Automatic ON/OFF Timings
15. Other features ( IP --- )
Module Mounting frame
1.
Material used
2.
Whether Protection against corrosion
3.
Angle of inclination to horizontal
Battery housing
1.
Material
2.
Dimension
3.
Whether Protection against corrosion
provided
4.
Air vent and locking arrangement
Connecting cables / wire
1.
Material and size
2.
Details of Switches (Nos.)

(Signature of Bidder with seal)

<!-- page 45 -->

44

PART-7
ADDITIONAL CONDITIONS AND INFORMATION TO BIDDER:
1. Funding Pattern: The funding of the scheme will be done by the Govt. of India and Govt. of
Arunachal Pradesh in the ratio of 85:15.
2. VAT: The State VAT / Entry Tax will be 4% and the Govt. of India will not do funding for the
same. However, the bidder will quote the amount of VAT in their Bid. If the State Govt. does
not exempt it during the course of the execution, the same will be paid by successful bidder at
the Entry Gate and include the same in their bill. Otherwise, it will be deducted by APEDA at
the time of release of payment and deposited to the Department of Tax and Excise, Govt. of AP,
3. The Arunachal Pradesh Energy Development Agency (APEDA) may also be called as the
Employer and its correspondence address is:
The Arunachal Pradesh Energy Development Agency (APEDA)
Urja Bhawan, T.T. Marg, VIP Road, Near I.G. Park,
PO & PS: Itanagar, District: Papum Pare,
Arunachal Pradesh, PIN: 791 111.
Phone: 0360-2211160
Fax: 0360-2214426
Email: apeda79@gmail.com
apeda79@yahoo.com
(It is a State Govt. Agency of Govt. of Arunachal Pradesh and is represented by its Director)
For the purpose of execution of the contract, the contractual activities shall be performed by the
Employer “for and on behalf of the Owner” except in cases where the Owner itself is statutorily
required to do so.
4. The Owner is:
The Government of Arunachal Pradesh, represented by the Commissioner/ Secretary (Power &
NRE).
5. Time for Completion:
The Time for Completion of the contract is 6 (six) months from the date of award or issuance of
Letter of Intent (LoI).
6. The Contracts to be entered into with the successful Bidder shall be as under :
i)
The Contract shall be for complete turnkey execution for supply of materials/ goods
from Ex-Works on FOR site basis including providing of all the services required i.e.
inland transportation for delivery at site, insurance, loading, unloading, storage, handling
at site, installation, testing and commissioning including performance testing in respect
of all the equipment supplied with 5 years warrantee and annual maintenance of systems
supplied and installed for 5 years with service centers set up strategic locations in each
District and any other services specified in the Contract Documents.

<!-- page 46 -->

45

ii)

The Contract will be signed in two originals and the Contractor shall be provided with
one signed original and the second will be retained by the APEDA/ Employer.

iii)

The Contractor shall provide free of cost to the Employer all the engineering data,
drawing and descriptive materials submitted with the bid, in at least two (2) copies to
form a part of the Contract immediately after Notification of Award.

7. Bid Security or Earnest Money: An amount of Rs.20.00 lakhs will be deposited by the bidder in
the form of a Demand Draft in the favour of the “Director, APEDA, Itanagar” payable at SBI,
Itanagar along with a Bank Guarantee (BG) for a value of Rs.100.00 lakhs valid for 6 months as
Bid Security or Earnest Money. Scanned copy of the demand draft and BG will be uploaded in
the web portal along with the bids. The original Demand Draft and BG shall be submitted to the
Employer on and before the day of the opening of the bids. This amount will be adjusted in the
value of Contract Performance Security of the successful bidders and those of the unsuccessful
bidders will be returned back to them after finalization of the tenders/ bids. The demand draft
shall have a validity of 6 months.

8. Contract Performance Security: Contract Performance Security in the form of Bank Guarantee
(BG) will be submitted by the successful bidder within 7 days of award of work for a value
equivalent to 10% of the contract amount valid beyond 6 months from the specified date of
commissioning/ completion of work.
9. Tender Document Fee: An amount of Rs.10,000/- will also be deposited by the bidder in the
form of a Demand Draft as Tender Document Fee. Scanned copy of the same will be uploaded in
the tender web portal.
10. Warrantee and Annual Comprehensive Maintenance Contract (AMC): Entering into the
agreement for performance of the contract will be binding on the contractor(s) to give warrantee
of their products against any manufacturing defect for 5 years and will bind the contractor to
perform annual maintenance of the systems supplied and installed by them for complete 5 years
from the date of installation of the systems in the village(s).
11. Service Centers: Each eligible contractor will have to set up at least one service centre in each
district of their operation, where a skilled technician and readily available spare parts will be
made available during the entire period of AMC.
12. It will not be binding on the Employer to award the work to the Lowest Bidder. Price acceptance
will depend on the justified rate in comparison to the market rate.
13. Work may be distributed to more than one party district wise at the accepted rate(s) for speedy
and better execution and completion of the work in time.
14. Sample of Product/ System: The bidders shall have to produce one set of working sample of
their product in complete shape to the Employer on or before the final bidding day. Work will be
awarded to the Parties/ Bidders whose samples are accepted.
15. Gram Vidyut Abhiyantas (GVAs): REC limited has appointed Gram Vidyut Abhiyantas for
monitoring of the work in all the distrcts where the work will be executed. These Abhiyantas

<!-- page 47 -->

46

should be given all necessary cooperation by the Contractor and the Project Managers (DD, PO,
JE), of the Employer in discharging their duties.
16. The terms and conditions of the sanctioning authority (ies) of the Project(s) i.e. the Govt. of
India and REC including supplemental and modification etc thereof will form part of the
agreement/ contract.
17. The number of villages to be taken up for electrification may vary at the time of execution as per
site requirement and condition and therefore, the quantum of work and amount of contract may
be varied accordingly and the contractor shall have to comply with any instruction given to them
by the Employer for such variation.
18. Suryamitra: There is a Programme under MNRE to provide training to ITI Certificate and
Diploma holders on operation and maintenance of SPV devices and systems and it is called
“Suryamitra Skill Development Programme”. There are 28 numbers of such trained suryamitras
in Arunachal Pradesh who have been recently trained by NBIRT, Silchar and they are available
for providing their service. The successful contractor(s) will have to engage them in the district
of their origin in their service centers. They will be engaged by the contractor to provide
necessary repairs and maintenance service including installation of the systems during the time
of execution.

<!-- page 48 -->

47

PART-B: FINANCIAL BID
e-Tender NO. APEDA/ DDUGJY/2015-16/01
Name of the Firm: ------------------------------------------------------------------------------

WORK PART –I :
Design, Manufacturing, Supply, Installation, Testing and Commissioning including loading,
unloading, safe storage, transportation upto site of installation of Solar PV Power Pack of 300Wp
capacity comprising of the following integral components with 5 years Warrantee and 5 years
Comprehensive Maintenance from the date of installation;
(i) SPV Module of 300Wp (2x150W)
(ii) Mounting Structure for module made of galvanized iron angles of assorted size (1set).
(iii) Charge Controller:
Option-I: Charge controller of 24V, 15A with MPPT system and inbuilt inverter of capacity 150
VA to deliver both DC output for DC load (lighting, fan & USB), and also AC output for running TV
and Mobile Charger, OR
Option-II:
Charge Controller of 24V, 15A with MPPT system along with a separate inverter of 24V, 300VA.
(iv) Battery of 12V, 75 AH, C-10, LM flooded type. Lead acid (2 Nos.)
(v) Copper Cables of 32/0.20 multi-strand 2.0 m in length with Copper battery Terminals, nuts and bolts
etc as required (1set).
(vi) White LED luminaire of 3Watt (3 Nos.)
(vii)
White LED luminaire of 6 Watt (2 Nos)

TOTAL APPROXIMATE QUANTITY FOR ALL DISTRICTS = 15401 SYSTMS (DISTRIBUTED
DISTRICTWISE AS BELOW)
Sl.
No.

Description of Items

Quantity

1

Anjaw

192

2

Changlang

1043

3

Dibang Valley

156

4

East Kameng

2379

5

East Siang

43

6

Kurung Kumey

5505

Unit

Estimated
Rate

Rate
Quoted
by Bidder
including
4% VAT

Amount

Remarks

<!-- page 49 -->

48

7

Lohit

33

8

Lower Dibang Valley

393

9

Lower Subansiri

1936

10

Papum Pare

342

11

Tawang

170

12

Upper Siang

137

13

Upper Suansiri

1959

14

West Kameng

327

15

West Siang

786

TOTAL

15401

WORK PART – II:
Design, Manufacturing, Supply, Installation, Testing and Commissioning including loading,
unloading, safe storage, transportation up-to site of work of Solar PV Street Lighting System with
white LED luminaire of 12 watt with auto dimmer, battery of lead acid positive plate, 12V, 75AH,
C-10, GEL, VRLA type and complete with mounting pole with bracket made of galvanized steel of
80mm dia of at least 5m length including erection work in 1:2:4 CC foundation of 900m depth and
300mm dia with 5 years Warrantee and 5 years Comprehensive Maintenance from the date of
installation.
TOTAL QUANTITY FOR ALL THE DISTICTS = 4923 Nos
Sl.
No.

Description of Items

Quantity

1

Anjaw

68

2

Changlang

303

3

Dibang Valley

52

4

East Kameng

735

5

East Siang

13

Unit

Estimated
Rate

Rate
Quoted
by Bidder
including
4% VAT

Amount

Remarks

<!-- page 50 -->

49

6

Kurung Kumey

1760

7

Lohit

10

8

Lower Dibang Valley

121

9

Lower Subansiri

662

10

Papum Pare

97

11

Tawang

58

12

Upper Siang

44

13

Upper Suansiri

652

14

West Kameng

95

15

West Siang

253

TOTAL

4923

NOTES:
1.
2.

Certified that rates quoted above are as per the requirement, specification terms &
condition mentioned in the e-tender document.
The rates quoted are inclusive of all taxes & duties, storage, transportation up to site,
insurance, installation, testing, commissioning, handling charges etc and 5 year
comprehensive warrantee and annual maintenance charges and any other job required to
properly execute the work.

(Signature of Bidder With seal)

<!-- page 51 -->

50

ANNEXURE- I
JOINT COMMISSIONING & HANDING OVER CERTIFICATE & WARRANTY CARD
Solar Power Pack:
It is hereby certified that following system with following details has been supplied, installed and
commissioned.
Sl. No. Items
Name of system
1
Agreement number Date
2
Any other specific important written order
3
UID number (14 dight)
4
5

Name of Beneficiary (with mobile number)

6
7
8
9
10
11

District
Block
Gram Panchayat

12

13

14

Details

Exact location on installation (land mark)
Date of installation
Warrantee expire on
Name & Address of the Manufacturer / supplier of the
system.
SPV Modules installed
Sr. No.
Make
Model
Battery
Sr. No.
Make
Model

15

Training for operation & maintenance of the system

Provided/not provided

Technical literature, operation & maintenance manual in
Provided/not provided
English/ Hindi
(In case of complaint dial toll free number …………………………. for complaint lodging)
16

(Signature)
Authorised signatory of
Contractor (with seal)
(Signature)
Project Officer/ In-charge
APEDA (with seal)

(Signature)
Name of beneficiary

(Signature)
DD, APEDA
With Seal

(Project Officer will obtain 03 copies of joint commissioning report and two copies to be sent to H.Q.)

<!-- page 52 -->

51

ANNEXURE-II
JOINT COMMISSIONING & HANDING OVER CERTIFICATE & WARRANTY CARD
Solar Street Light:
It is hereby certified that following system with following details has been supplied, installed and
commissioned.
Sl.
Items
Details
No.
Name of system
1
Agreement number Date
2
Any other specific important written order
3
UID number (14 dight)
4
Name of Village with name of Head of village and his mobile
5
number if any.
District
6
Block
7
Gram Panchayat
8
9
10
11

Exact location on installation (land mark)
Date of installation
Warrantee expire on

12

Name & Address of the Manufacturer / supplier of the system.

13

14

SPV Modules installed
Sr. No.
Make
Model
Battery
Sr. No.
Make
Model

15

Training for operation & maintenance of the system

Provided/not provided

Technical literature, operation & maintenance manual in
Provided/not provided
English/ Hindi
(In case of complaint dial toll free number …………………………. for complaint lodging)
16

(Signature)
Authorised signatory of
Contractor (with seal)
(Signature)
Project Officer/ In-charge
APEDA (with seal)

(Signature)
Name of beneficiary

(Signature)
DD, APEDA
With Seal.

(Project Officer will obtain 03 copies of joint commissioning report and two copies to be sent to H.Q.)

<!-- page 53 -->

52

List of villages with Census code and Manual Cartage Distance
1. District : Anjaw
Sl.No.

Village name

Block Name

No.
of
H.H.

4

No. of System
Proposed

Manual
cartage
distance

Power
Pack

Solar
Street
Light

5

6

7

8

1

2

1

Kanguliang

HAYULIANG

266812

12

13

4

12 Km

2

Dong

Walong

266880

4

4

1

14 Km

3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21

Maha
Khowegko
Payaparap
Long Jam
Eliang
Pirah
Chutong
Doringko
Chipuiliang
Tabretong
Payagam
Pailiang
Gomin
Chirang
Glotong
Qunboo
Ekailiang
Chowailing
Chowagong

Hayuliang
Chaglagam
Chaglagam
Manchal
Manchal
Manchal
Manchal
Chaglagam
Chaglagam
Chaglagam
Chaglagam
Chaglagam
Chaglagam
HAYULIANG
HAYULIANG
Manchal
Manchal
Manchal
Walong

266702
266843
266847
266744
266746
266747
266758
266848
266841
266845
266854
266844
266850
266789
266788
266757
266760
266745
266915

3
5
4
3
3
4
4
9
10
10
11
13
14
10
11
10
11
12
7

3
5
4
3
3
4
4
9
12
12
13
15
16
12
13
12
13
15
7

1
1
1
1
1
1
1
2
5
5
5
5
6
5
5
5
5
6
2

12
11
16
14
12
18
19
17
8
12
1
20
5
35
45
8
9
15
11

170

192

68

Total :

3

Village
Census
Code

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 54 -->

53

2. District : Changlang
Sl.No.

1

Village name

2

Block Name

3

Village
Census
Code

No.
of
H.H.

4

No. of System
Proposed
Power
Pack

Solar
Street
Light

5

6

7

Manual
cartage
distance

8

1
2
3
4
5

Phangseng
Relangkan
Jotin Juda
Gandhigram Bl.I & II
4 K.M. PWD Camp
Jungmungsung

Changlang
Changlang
Changlang
Changlang
Changlang

264137
264146
264159
264244
264079

19
33
33
342
5

20
35
35
347
5

6
10
10
91
1

14
14
16
50
2

6

9 K.M. PWD Camp (Jongkey)

Changlang

264110

3

3

1

2 Km

7
8

Industrial Estate
3 K.M. Forest Camp
(Namdang-II)

CHANGLANG
CHANGLANG

264086
264143

13
13

15
15

5
5

2 Km
4 Km

9

17 Mile M.V. Road (Sher)
(17 Mile Village)

KHAGAM-MIAO

264287

12

14

5

2 Km

10
11
12
13
14
15
16
17
18
19
20
21
22

Daragaon
Dawodi
Phaparbari
Gaherigaon
Hazolo
Ramnagar
Chidudi
Mazgaon
Twohut
Topihill
Buddhamandir
Sidikuh
7 K.M. Yungchik PWD
(Yungchik)

KHAGAM-MIAO
KHAGAM-MIAO
KHAGAM-MIAO
KHAGAM-MIAO
KHAGAM-MIAO
KHAGAM-MIAO
KHAGAM-MIAO
KHAGAM-MIAO
KHAGAM-MIAO
KHAGAM-MIAO
KHAGAM-MIAO
KHAGAM-MIAO
Manmao

264238
264239
264240
264241
264242
264243
264245
264246
264247
264248
264249
264250
264089

47
37
47
11
32
21
30
42
44
39
25
39
20

49
39
50
13
35
24
32
45
47
41
27
41
22

14
11
15
5
11
8
10
14
14
12
8
12
7

23

11 K.M. PWD Camp
(Maithingro Kaan - II)

Manmao

264166

26

28

9

Km

24
25

Sasum II
24 K.M. PWD Camp

Manmao
Manmao

264175
264168

27
30

29
32

9
10

Km
Km

990

1043

303

Total :

105
102
98
100
95
90
110
115
118
110
120
80

Km
Km
Km
Km
Km

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 55 -->

54

3. District : Dibang Valley
Sl.No.

1

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27

Village name

2

Block Name

3

Village
Census
Code

No.
of
H.H.

4

No. of System
Proposed
Power
Pack

Solar
Street
Light

5

6

7

4
2
1
2
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
5
2
2
5
6
1
6

52

Aoli
Tyee Model Village
Awoka
Cheppe
Akhuli
Ambolin

ANELIH-ARJU
ANELIH-ARJU
ANELIH-ARJU
ANELIH-ARJU
ETALIN-MALINEY
ETALIN-MALINEY

266024
266013
266014
266017
265968
265969

13
8
4
6
2
4

Akaya
Ethore
Idipo
Ithun Camp
Adali
Jingupu
Ediya
Kamuyi
New Achuli
Achengo
Maley
Apunli
Aningo
Chanli
Wanli
Ahungo
Eyongo
Ebamee
Agagu
Alney (Aloney )
New Arope(Hipui)

Anelih-Arju
Anelih-Arju
Anelih-Arju
Anelih-Arju
Anini-Mipi
Anini-Mipi
Anini-Mipi
Anini-Mipi
Anini-Mipi
Anini-Mipi
Anini-Mipi
Etalin-Maliney
Etalin-Maliney
Etalin-Maliney
ANELIH-ARJU
ANINI-MIPI
ANINI-MIPI
ANINI-MIPI
ANINI-MIPI
ETALIN-MALINEY
ETALIN-MALINEY

266021
266033
266037
266038
265908
265911
265915
265918
265927
265937
265938
265978
265980
265985
266019
265913
265953
265939
265925
265981
265998

3
3
2
1
4
5
3
4
4
2
1
2
1
4
11
7
8
10
15
4
16

14
8
4
6
2
4
3
3
2
1
4
5
3
4
4
2
1
2
1
4
13
7
8
12
17
4
18

147

156

Total :

Manual
cartage
distance

8

60
25
35
45
15
25
6
5
5
5
12
3
1
13
2
2
3
30
25
25
10
17
5
2
2
5
8

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 56 -->

55

4. District : East Kameng
Sl.
No.

1

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33

Village name

2

Welling Tawe
Prait
Mara Tassar Sullung
Kowa Sullung
Diya Sullung
Mebuwa - I
Ladu Sullung
Dabiwa Cheda
Longik Sullung
Moku Sullong
Sangripu (Tara Sullung)
Debiwa Sollung
Sagya Sullung
Anuk Sollung
A - 1 Block
Dirring
Japu
Babey Camp
Pipiang
Laja Sullung
Dongkha
Nissangjang
Kampa - N.V.
Gikung
Wabalang
Pia
Wakke
Granjang
Satuk (Ramda)
Rojo
Tamne
Lelung
Kajung

Block Name

3

Bameng
Bameng
Chyang-Tajo
Chyang-Tajo
Chyang-Tajo
Seppa
Pipu
Pipu
Pipu
Pipu
Pipu
Pipu
Pipu
Pipu
Seijosa
Seijosa
Khenewa
BAMENG
BAMENG
BAMENG
BAMENG
BAMENG
BAMENG
BAMENG
BAMENG
BAMENG
BAMENG
BAMENG
BAMENG
BAMENG
Bana
Bana
Bana

Village
Census
Code

No. of
H.H.

4

262074
262081
262242
262254
262266
262046
262138
262153
262156
262157
262159
262162
262166
262176
261901
261911
262197
262126
262070
262115
262075
262071
262077
262079
262084
262078
262087
262086
262080
262090
262004
262013
261988

No. of System
Porposed
Power
Pack

Solar
Street
Light

5

6

7

3
5
3
3
4
2
4
3
4
2
3
3
2
1
5
1
5
6
7
7
8
9
9
9
9
13
13
10
11
15
10
13
14

3
5
3
3
4
2
4
3
4
2
3
3
2
1
5
1
5
6
7
7
8
9
9
9
9
15
15
12
13
17
12
15
16

1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
2
2
2
2
2
2
2
2
5
5
5
5
6
5
5
6

Manual
cartage
distance

9

10
12
11
15
16
11
14
12
15
14
10
11
9
7
12
18
12
6
8
12
11
14
9
6
13
10
6
9
8
10
12
15
9

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 57 -->

56

34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51

Hojopu
Warriam Sullung
Parte
Mechi
Weigung Sullung
Dao
Dara Yangfo
Mechar
Tassar Sullung
Sario
Venia
Wagyung
Sefew
Yacho
Kapa
Chaling
Kawarang
Kampu Seba

52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73

Pania Sullung
Meomey Sollung
Longo Gollo
Hisa Plangta
Papiwa Sullung
Lanka
Dissing Passo HQ
New Dissing
Sangdu
Lasum Pathe
New Lasum Pathe
Kampu
Mebuwa - II
Dari
Mebuwa - III
Gidi Sullung
Taffo
Lengdi/Liang
Nabalang
Emboriang
Sallang
Kojo

Bana
CHAYANGTAJO
CHAYANGTAJO
CHAYANGTAJO
CHAYANGTAJO
CHAYANGTAJO
CHAYANGTAJO
CHAYANGTAJO
CHAYANGTAJO
CHAYANGTAJO
CHAYANGTAJO
Khenewa
Khenewa
Khenewa
Khenewa
Khenewa
Khenewa
PAKKE
KESSANG
Pipu
Pipu
Pipu
Pipu
Pipu
Seijosa
Seijosa
Seijosa
Seijosa
Seijosa
Seijosa
SEPPA
SEPPA
SEPPA
SEPPA
Bameng
Bameng
Bameng
Bameng
Bameng
Bameng
Bameng

261994
262270
262267
262260
262249
262251
262258
262259
262241
262269
262276
262187
262201
262186
262206
262205
262208
261981

14
7
8
10
11
12
12
13
14
15
15
6
9
10
10
11
12
13

16
7
8
12
13
14
14
15
16
17
17
6
9
12
12
13
14
15

6
2
2
5
5
5
5
5
6
6
6
2
2
5
5
5
5
5

8
14
16
12
14
5
40
50
35
30
45
10
8
10
15
12
14
10

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

262140
262177
262178
262183
262184
261896
261928
261919
261925
261926
261927
262065
262047
262029
262048
262114
262123
262116
262085
262112
262083
262089

6
8
8
8
9
7
8
11
12
12
12
7
8
9
11
16
17
18
19
19
20
20

6
8
8
8
9
7
8
13
14
14
14
7
8
9
13
18
19
20
21
22
22
22

2
2
2
2
2
2
2
5
5
5
5
2
2
2
5
6
6
7
7
8
7
7

50
70
25
35
55
30
31
32
10
2
5
5
6
4
8

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 58 -->

57

74
75
76
77
78
79
80
81
82
83
84
85
86
87
88
89
90
91
92
93
94
95
96
97
98
99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114

Bisai
Sachung
Upper Liyak Doncha
Drakshi
Upper Liyak Donia
Poube Sullung
Effa
Rapung
Lada H.Q.
Tawe
Lower Liyak
Afaksung
New Longte Poube
Kadeya Kitchang
Byale Sullung
Langchu Sullung
Nampe Bagang
Loto Yangfo
Yakli Sullung
Saliwa Yangfo
Nampe
Saria Takhang
Veo
Lamnio
Langri I.A.Y.Village
Latum I.A.Y.Village (Sangbia)
Pajewa
Laluwapa
Balipota
Talomlati
Lasak Cheda
Tadowapa
Miri Sollung
Lochung
Gyawe Purang Hq.
Dokre Gyadi
Tabri
Flago
Richi Lamgu
Tagang Warang
Doka

Bameng
Bameng
Bameng
Bameng
Bameng
Bameng
Bameng
Bameng
Bameng
Bameng
Bameng
Bana
Bana
Bana
Chayangtajo
Chayangtajo
Chayangtajo
Chayangtajo
Chayangtajo
Chayangtajo
Chayangtajo
Chayangtajo
Chayangtajo
Chayangtajo
Khenewa
Khenewa
Pakke Kessang
Pakke Kessang
Pakke Kessang
Pipu
Pipu
Pipu
Pipu
Pipu
Pipu
Pipu
Pipu
Pipu
Pipu
Pipu
Pipu

262069
262072
262125
262088
262124
262127
262113
262093
262082
262073
262094
261997
262014
261991
262248
262252
262273
262255
262277
262217
262265
262271
262275
262257
262196
262189
261968
261967
261970
262180
262158
262146
262175
262143
262181
262174
262144
262139
262182
262179
262137

21
21
22
30
30
33
34
39
48
60
63
19
20
34
19
19
22
26
26
31
31
36
40
69
16
52
16
20
35
20
23
24
24
25
27
31
40
52
56
61
73

23
24
24
32
33
36
37
41
51
62
66
21
22
37
21
21
24
28
28
33
33
38
42
72
18
54
18
22
37
22
26
26
26
27
29
33
42
54
58
64
75

7
8
8
10
11
11
12
12
15
17
19
7
7
12
7
7
8
9
9
10
10
11
12
20
6
15
6
7
11
7
9
8
8
8
9
10
12
15
16
18
20

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 59 -->

58

115
116

Bokar
Hamba – Pinda

Pipu
SEPPA

262142
262039

78
64

80
67

22
19

2213

2379

735

Village
Census
Code

No.
of
H.H.

No. of System
Porposed

4

263785
263827
263828
263786

Total :

Km
Km

5. District : East Siang
Sl.No.

Village name

1

1
2
3
4

Block Name

2

Lissing
Sipo(Hipo)
Jate
Messing

3

Pangin
RAMLE BANGO
RAMLE BANGO
Pangin

Total :

Manual
cartage
distance

Power
Pack

Solar
Street
Light

5

6

7

8

13
4
7
16

14
4
7
18

4
1
2
6

13 Km
18 Km
15 Km
Km

40

43

13

6. District : Kurung Kumey
Sl.
No.

1

1

Village name

2

Baggam (Baojam)

Block Name

3

Pipsorang

Village
Census
Code

No. of
H.H.

4

265842

No. of System
Proposed

Manual
cartage
distance

Pow
er
Pack

Solar
Street
Light

5

6

7

8

31

33

10

50 Km

<!-- page 60 -->

59

2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43

Biya
Chome
Gatam
Gyapin
Ha
Habak
Haimachi
Haina
Hapuk (L)
Kaba
Keyang
Kokso
Nabiya
Nayeng
Neorum
New Zara
Nikbia
Nyache
Pija
Pilua
Raha
Richik
Samba Karsang
Sangia
Tami
Zara
Giba
Guchi
Hokpu
Panio
Sojam
Nyoya
Hatey
Korayer-I
Korayer-II
Bongkung
Pitak
Sonia
Boring
Lomak Hapa
Dayam Hapa
Banga Kotho

Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
TALI
TALI
TALI
TALI
TALI
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang

265856
265861
265857
265840
265846
265858
265839
265847
265855
265849
265863
265862
265843
265845
265836
265864
265859
265853
265854
265850
265860
265851
265832
265852
265848
265844
265903
265880
265879
265875
265881
265525
265526
265528
265529
265547
265548
265558
265572
265575
265585
265589

28
10
5
80
58
7
17
30
11
38
28
7
71
42
11
34
20
48
16
37
34
6
38
45
34
40
35
63
24
32
19
3
4
1
1
5
5
2
5
5
5
3

30
12
6
82
61
8
19
33
13
40
30
8
73
44
13
36
22
50
18
39
36
7
40
47
36
43
37
67
26
34
21
3
4
1
1
5
5
2
5
5
5
3

9
5
2
22
18
3
6
11
5
12
9
3
20
13
5
11
7
14
6
11
11
3
12
13
11
13
11
20
8
10
7
1
1
1
1
1
1
1
1
1
1
1

38
56
35
54
42
40
59
40
40
39
50
42
34
47
56
38
70
37
35
42
52
32
54
33
39
40
41
39
37
54
35
27
15
12
12
15
13
32
27
38
28
24

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 61 -->

60

44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73
74
75
76
77
78
79
80
81
82
83
84
85

Genchi
Hepu-Hapa
Kott-Ratt
Namniar
Manghe II
Deyang
Buhan
Tamia
Chimpu
Torme Yarda
Lower Guha
Lower Lorio
Humga Jariang
Suriu
Guha
Pinchung
Youndo
Saleriang(Sulung)
Sikey
Bumpey
Serak
Jejer
Demepup
Miba
Sonyokoto
Bodepu
Sangha
Lungchi
Tapaha
Raibalo II
Yangte II
Mebia
Mipum-Namching
Tapa-Poring
Gangte (Gente)
Charbia
Takeng
Piriayer
Nama
Tatung-Koter
Tarha
Hidung Songo

Chambang
Chambang
Chambang
Damin
Koloriag
Koloriag
Koloriag
Koloriag
Koloriag
Nyapin
Nyapin
Nyapin
Nyapin
Nyapin
Nyapin
Nyapin
Nyapin
Nyapin
Nyapin
Palin
Palin
Palin
Sangram
Sangram
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG

265598
265641
265672
265813
265436
265466
265467
265475
265478
265356
265367
265369
265380
265386
265394
265399
265406
265411
265419
265188
265224
265263
265294
265347
265502
265514
265519
265546
265556
265578
265624
265625
265629
265633
265648
265649
265531
265552
265640
265561
265563
265564

2
4
3
5
4
5
3
4
4
4
1
2
1
4
3
3
3
5
4
5
4
5
5
5
6
6
6
10
6
6
6
6
6
6
6
6
7
7
7
8
8
8

2
4
3
5
4
5
3
4
4
4
1
2
1
4
3
3
3
5
4
5
4
5
5
5
6
6
6
12
6
6
6
6
6
6
7
6
7
7
7
8
8
8

1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
2
2
2
5
2
2
2
2
2
2
3
2
2
2
2
2
2
2

26
30
48
55
21
12
12
17
24
15
5
8
21
12
8
10
16
13
17
7
9
7
13
12
12
14
18
32
25
42
32
23
24
36
41
32
23
16
28
23
19
21

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 62 -->

61

86
87
88
89
90
91
92
93
94
95
96
97
98
99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127

Tabum
Pakung
Tabyer
Chimpigi
Tapaha
Ballo I
Tamak poring
Tumhaming
Raiga II
Mencha
Gongbing
Gai IV
Taliyer
Phoi
Harak
Lolcee
Raseng Hapa
Sanglo Putung
Payer
Kamrung-III
Lungchi
Taya Rimpa
Sango II
Bump-Hapa
Sangching Nyoriang
Kamrung II
Yeripu
Poksa
Haming
Pikte
Delinge
Delling
Harak II
Higio II
Rai II
Tagiaraha
Lengdi I
Tudh-Bath III
Tangtanpuring
Tungte
Pukpe
Boa II

CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG

265567
265593
265621
265628
265542
265580
265591
265594
265597
265600
265601
265617
265618
265622
265632
265646
265503
265511
265533
265574
265595
265599
265607
265631
265532
265538
265540
265557
265559
265634
265638
265517
265545
265569
265603
265612
265619
265509
265516
265565
265583
265609

8
8
8
8
9
9
9
9
9
9
9
9
9
9
9
9
10
10
10
10
10
10
10
10
11
11
11
11
11
11
11
12
12
12
12
12
12
13
13
13
13
13

8
8
8
8
9
9
9
9
9
9
9
9
9
9
9
9
12
12
12
13
12
12
12
13
13
14
13
13
13
13
13
14
14
14
14
14
14
15
15
15
15
15

2
2
2
2
2
2
2
2
2
2
2
2
2
2
2
2
5
5
5
6
5
5
5
6
5
6
5
5
5
5
5
5
5
5
5
5
5
5
5
5
5
5

25
15
7
27
12
38
14
12
22
18
23
32
34
9
32
12
17
12
26
32
9
12
26
28
24
22
27
26
32
38
26
12
28
34
32
20
32
14
17
26
36
39

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 63 -->

62

128
129
130
131
132
133
134
135
136
137
138
139
140
141
142
143
144
145
146
147
148
149
150
151
152
153
154
155
156
157
158
159
160
161
162
163
164
165
166
167
168
169

Bindo
Nyomi
Gangte II
Amprakpak
Phacha
Taniyatab
Padap
Dorduk (T-Tab )
Restaring
Gachi
Kish
Taya
Langria
Rayer Solung
Rluguha
Pinchi Solung
Langdo
Yorung
Pach
Sangripo
Ralung
Kaberiang
Taris
Tapone
Puriok
Kiodhriang
Nyobia
Degging II
Chinkongne Village
Ratell
Sulungyar
Pinging
Johat
Radang
Jiri
Kokpu Nyoyer
Naji Bibok
Tate
Barta Camp
Tagia
Pajja
Hinggo Happa

CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
CHAMBANG
NYAPIN
NYAPIN
NYAPIN
NYAPIN
NYAPIN
NYAPIN
NYAPIN
NYAPIN
NYAPIN
NYAPIN
NYAPIN
NYAPIN
NYAPIN
KOLORIANG
KOLORIANG
KOLORIANG
KOLORIANG
KOLORIANG
KOLORIANG
KOLORIANG
KOLORIANG
KOLORIANG
KOLORIANG
KOLORIANG
KOLORIANG
KOLORIANG
KOLORIANG
KOLORIANG
PALIN
PALIN
PALIN
PALIN

265620
265523
265587
265605
265610
265635
265513
265636
265650
265652
265368
265393
265400
265424
265407
265422
265359
265415
265361
265398
265425
265358
265417
265455
265497
265473
265465
265483
265454
265487
265456
265461
265468
265460
265493
265471
265472
265488
265270
265279
265204
265221

13
14
14
14
14
14
15
15
15
15
6
6
6
6
7
7
8
8
9
9
11
14
14
6
6
7
8
8
9
9
11
11
11
12
12
13
14
15
6
6
7
8

15
16
17
16
16
16
18
17
17
17
6
6
6
6
7
7
8
8
9
9
13
16
16
6
6
7
9
8
9
9
13
13
13
15
14
15
16
17
6
6
7
8

5
6
7
6
6
6
7
6
6
6
2
2
2
2
2
2
2
2
2
2
5
6
6
2
2
2
3
2
2
2
5
5
5
6
5
5
6
6
2
2
2
2

42
35
34
35
37
39
7
28
20
12
1
8
11
8
2
5
2
9
8
12
4
10
12
10
2
30
35
10
10
10
26
6
30
8
6
36
30
3
12
12
8
5

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 64 -->

63

170
171
172
173
174
175
176
177
178
179
180
181
182
183
184
185
186
187
188
189
190
191
192
193
194
195
196
197
198
199
200
201
202
203
204
205
206
207
208
209
210
211

Nidey Happa
Rukso
Kayekh
Karko
Koyer- Kamcho
Geyo
Hina
Gyate
Tamak
Gopo
Pungmi
Bugdu
Yerlo
Tegdo
Dumbu
Gyachi
Nisuk
Nayopuk
Yaso
Katuk
Chera
Sibia
Tikla
Pipa
Boruk
Chedam
Hirik
Hume
Kelong
Ruba
Terik
Subuk
Sara
Kampong
Tagum
Kamha Hapa
Rallang
Kaglang
Pirsepa
Ningpopu
Paching
Nyori

PALIN
PALIN
PALIN
PALIN
PALIN
PALIN
PALIN
PALIN
PALIN
PALIN
PALIN
PALIN
PALIN
PALIN
PALIN
PALIN
DAMIN
DAMIN
DAMIN
DAMIN
DAMIN
DAMIN
DAMIN
DAMIN
DAMIN
DAMIN
DAMIN
DAMIN
DAMIN
DAMIN
DAMIN
DAMIN
Sangram
Sangram
Sangram
Sangram
Sangram
Sangram
Sangram
Sangram
Sangram
Sangram

265273
265186
265173
265179
265213
265214
265253
265196
265209
265215
265226
265193
265219
265222
265187
265260
265820
265810
265784
265805
265812
265795
265797
265801
265781
265829
265821
265828
265824
265807
265803
265822
265295
265332
265308
265322
265317
265283
265309
265325
265326
265327

8
9
10
10
10
10
10
11
11
11
12
13
13
13
14
15
6
7
8
8
9
10
10
10
12
13
12
10
23
45
12
12
8
8
9
10
13
14
14
15
15
15

8
9
12
12
12
12
12
13
13
13
14
16
15
15
16
18
6
7
8
8
9
12
12
12
14
15
14
12
25
47
14
14
8
8
9
12
15
16
16
17
17
17

2
2
5
5
5
5
5
5
5
5
5
6
5
5
6
7
2
2
2
2
2
5
5
5
5
5
5
5
8
13
5
5
2
2
2
5
5
6
6
6
6
6

11
14
15
16
6
5
10
6
14
3
7
16
4
7
8
17
80
65
65
80
50
50
50
40
50
85
90
55
75
60
70
58
10
5
3
4
10
12
9
8
10
10

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 65 -->

64

212
213
214
215
216
217
218
219
220
221
222
223
224
225
226
227
228
229
230
231
232
233
234
235
236
237
238
239
240
241
242
243
244
245
246
247
248
249
250
251
252
253

Tahuk
Bigo
Barbia
Passik
Solung
Lamia
Marmia
Nyokuriang
Raba Karsang
Tedung
Sepaha
Korapu
Koleng
Longding Koling HQ
New Sarli
Kaney
Lentso
Bala
Techipu Koto
Raibalo III
Pha
Mugli
Tayo
Korapu
Kembing
Paha
Gad
Ballo II
Pitak
Boje
Kote
Bungkung
Puch-Pute
Rembing
Cvuth
Tokriang
Galan
Putong
Omla
Dania
Peni
Dogwa

Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
Pipsorang
SARLI
SARLI
SARLI
SARLI
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Chambang
Damin
Damin
Damin
Damin
Damin
Damin
Damin

265775
265725
265744
265753
265729
265770
265736
265743
265833
265831
265834
265837
265835
265830
265681
265694
265692
265704
265570
265579
265584
265604
265642
265669
265630
265520
265576
265581
265614
265655
265553
265615
265653
265627
265644
265778
265817
265779
265789
265827
265791
265819

9
13
13
14
15
13
13
32
19
39
56
62
65
157
7
10
4
3
16
16
16
16
16
16
17
18
18
18
19
19
20
21
21
22
23
20
22
23
24
24
28
31

9
15
15
16
17
17
17
36
21
43
60
66
69
161
7
14
6
5
19
19
18
18
18
18
19
20
20
20
21
21
22
23
23
24
25
22
24
25
26
26
30
33

2
5
5
6
6
7
7
12
7
14
18
20
20
43
2
7
3
3
7
7
6
6
6
6
6
7
7
7
7
7
7
7
7
8
8
7
8
8
8
8
9
10

5
5
10
6
40
30
20
18
50
45
48
42
38
80
2
20
15
20

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 66 -->

65

254
255
256
257
258
259
260
261
262
263
264
265
266
267
268
269
270
271
272
273
274
275
276
277
278
279
280
281
282
283
284
285
286
287
288
289
290
291
292
293
294
295

Sejik
Furek
Jugriang
Raris
Gufa
Hill Top
Mingpa
Dilanggang
Pate
Diba Koyar
Kudung
Jiirilangney
Kusuk
Malaring
Papey
Tapey
Kikum
Sanglum Langi
Yapap Bogu
Khawong
Tabu
Hujuriang
Langtey
Pijo
Robo
Dokio Pep
Riope-Riome
Cheba
Rashik I
Kelin
Bampung Hema
Mangdo-I
Tasum
Lumdang
Made
Joku
Pachik
Renchiporiang -I
Yarba-I
Pado I
Pilop
Pape

Damin
Koloriang
Nyapin
Nyapin
Nyapin
Nyapin
Nyapin
Nyapin
Nyapin
Nyapin
Palin
Palin
Palin
Palin
Palin
Palin
Palin
Palin
Palin
Palin
Palin
Palin
Palin
Palin
Palin
Palin
Palin
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo

265799
265495
265410
265413
265416
265354
265357
265373
265421
265423
265176
265189
265203
265272
265178
265192
265249
265255
265238
265200
265240
265244
265231
265241
265194
265250
265197
265748
265742
265757
265722
265715
265713
265734
265749
265759
265772
265720
265731
265733
265751
265765

36
16
19
20
20
21
21
21
21
21
16
16
16
16
17
17
17
18
19
20
20
22
23
23
26
29
31
16
17
19
20
22
23
23
23
23
23
24
24
24
24
24

38
18
21
23
22
23
23
23
23
23
18
18
18
18
19
19
19
20
21
22
22
24
25
25
28
31
33
18
19
21
22
24
25
25
25
25
25
26
26
26
26
26

11
6
7
8
7
7
7
7
7
7
6
6
6
6
6
6
6
7
7
7
7
8
8
8
9
9
10
6
6
7
7
8
8
8
8
8
8
8
8
8
8
8

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 67 -->

66

296
297
298
299
300
301
302
303
304
305
306
307
308
309
310
311
312
313

Topuriang
Yerba
Pachang
Geyang
Mala
Libia
Molo
Dangu
Regba
Niayahutung
Haggar
Sangmey
Kerium Hapa
Reyup
Biyar
Cholo
Jhapuk
Hokpuk

Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Parsi Parlo
Sangram
Sangram
Sangram
Sangram
Sangram
Sangram
Sangram
Tali
Tali
Tali
Tali

265767
265730
265762
265774
265771
265717
265724
265287
265333
265310
265285
265297
265320
265282
265885
265886
265892
265883

Total :

24
29
31
31
33
48
48
16
18
19
20
25
29
32
16
19
19
51

26
31
33
33
35
50
50
18
20
21
22
27
31
34
18
21
21
53

8
9
10
10
10
14
14
6
7
7
7
8
9
10
6
7
7
15

5049

5505

1760

No. of System
Proposed
Power
Solar
Pack
Street
Light

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

7. District : Lohit
Sl.No.

Village name

Block Name

Village
Census
Code

No.
of
H.H.

1

2

3

4

5

6

7

8

266406
266408

8
23

8
25

2
8

8 Km
Km

31

33

10

1
2

Labeliang
Chiblaliang

TEZU
Tezu

Total :

Manual
cartage
distance

8. District : Lower Dibang Valley
Sl.
No.

Village name

Block Name

Village
Census
Code

No.
of
H.H.

1

2

3

4

5

6

7

8

266075
266065

3
14

3
15

1
5

13 Km
10 Km

1
2

Chepahu (52 K.M. Point)
Epanli

Hunli-Kronli
Hunli-Kronli

No. of System
Proposed
Power Solar
Pack
Street
Light

Manual
cartage
distance

<!-- page 68 -->

67

3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44

Karo
Rango
Gimbo (28 K.M. Point)
Elope
Asongo
Aphungu
Akuli
Chelaka (82 K.M.)
Akanda
Bititi
Chumduku
Chruango
Pi-Kha
Necha
Arini
Theyapra
Pika
Mariso
Mariso
Lupong
Natipi
Chela
Akela
Ithini
Cheyada
Ashini
Maruni
Enjani
Yuma (7 KM)
Arondo
Anoro
Amonggo
Gango
Mihundo
New Pika
Androni (73 K.M.)
Michido
Pengo
Yanli
Chuyuni Model village
Boongo (65 KM)
Kapali

Hunli-Kronli
Hunli-Kronli
Roing
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Roing
Roing
Roing
Roing
Roing
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Hunli-Kronli
Roing

266117
266055
266142
266054
266057
266066
266070
266072
266092
266104
266105
266110
266116
266120
266121
266128
266129
266132
266133
266168
266270
266271
266272
266348
266097
266108
266109
266111
266052
266058
266064
266102
266107
266130
266139
266073
266119
266124
266089
266115
266074
266346

5
2
20
2
3
3
5
4
4
5
3
3
2
3
5
2
2
5
5
4
5
5
3
1
6
7
7
7
8
8
8
8
8
8
8
9
9
9
11
12
27
8

5
2
22
2
3
3
5
4
4
5
3
3
2
3
5
2
2
5
5
4
5
5
3
1
6
7
7
7
8
8
8
8
8
9
8
9
9
9
13
14
29
8

1
1
7
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
2
2
2
2
2
2
2
2
2
3
2
2
2
2
5
5
9
2

16
13
20
9
15
7
9
1
26
15
31
12
24
43
25
16
18
25
3
2
3
4
5
2
5
7
1
3
1
2
2
5
1
1
2
0.20
1
2
0.50
0.50
0.50
0.50

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 69 -->

68

45
46
47
48
49
50

Thuango
Lemo
Ithun
Alambro
Elopa
Miuliati

Roing
Roing
Roing
Roing
Roing
Roing

266347
266282
266286
266172
266267
266279

1.00
1.00
1.00
0.50
0.50
0.50

12
14
14
15
15
15

14
16
16
17
17
17

5
6
6
6
6
6

371

393

121

Village
Census
Code

No. of
H.H.

No. of System
Proposed

4

Total :

Km
Km
Km
Km
Km
Km

9. District : Lower Subansiri
Sl.
No.

Village name

1

2

Block Name

3

Power
Pack

Solar
Street
Light

5

6

7

Manual
cartage
distance

8

1 Biku

Tamen-Raga

265118

16

17

5

6 Km

2 Bini

Tamen-Raga

265119

24

26

8

8 Km

3 Bokbarijop (Kina)

Tamen-Raga

265117

11

12

4

5 Km

4 Chirdi

Tamen-Raga

265116

20

22

7

6 Km

5 Dokne Puri

Tamen-Raga

265145

7

7

2

8 Km

6 Gote

Tamen-Raga

265122

5

5

1

21 Km

7 Jal

Tamen-Raga

265155

15

16

5

25 Km

8 Karba Godak

Tamen-Raga

265148

10

11

4

1 Km

9 Lelin

Tamen-Raga

265121

12

13

4

40 Km

10 Luduk Godak

Tamen-Raga

265150

25

27

8

1 Km

11 Moinpu

Tamen-Raga

265165

13

14

4

13 Km

12 Pega

Tamen-Raga

265157

9

10

3

23 Km

13 Rilki

Tamen-Raga

265123

4

4

1

38 Km

14 Rottom

Tamen-Raga

265120

50

52

15

7 Km

15 Tass

Tamen-Raga

265166

8

8

2

13 Km

16 Tepko

Tamen-Raga

265156

11

12

4

24 Km

17 Teririjo

Tamen-Raga

265115

41

43

12

4 Km

18 Yare Shok

Tamen-Raga

265143

6

6

2

1 Km

19 Yemin Deru

Tamen-Raga

265142

11

12

4

6 Km

<!-- page 70 -->

69

20 Digen

ZIRO - I

264651

2

2

1

12 Km

21 Kiidi

ZIRO - I

264705

5

5

1

28 Km

22 Layo

ZIRO - I

264622

4

4

1

15 Km

23 Pakhang Toku

ZIRO - I

264735

1

1

1

20 Km

24 Pobii

ZIRO - I

264704

2

2

1

12 Km

25 Pusa Yoda

ZIRO - I

264657

1

1

1

18 Km

26 Talle Valley

ZIRO - I

264642

2

2

1

30 Km

27 Taro More

ZIRO - I

264643

1

1

1

28 Km

28 Zamra

ZIRO - I

264645

1

1

1

58 Km

29 Amperi

Tamen-Raga

265033

4

4

1

10

Km

30 Subnar

Tamen-Raga

265035

2

2

1

1

Km

31 Bugi

Tamen-Raga

265039

4

4

1

1

Km

32 Bomri Hapa

Tamen-Raga

265040

5

5

1

5

Km

33 Katri

Tamen-Raga

265044

3

3

1

2

Km

34 Dirgo

Tamen-Raga

265046

4

4

1

2

Km

35 Ayi Poot Rejo

Tamen-Raga

265048

2

2

1

5

Km

36 Dabi Hapa

Tamen-Raga

265053

3

3

1

4

Km

37 Langding

Tamen-Raga

265072

3

3

1

5

Km

38 Hatak Putu

Tamen-Raga

265074

4

4

1

6

Km

39 Dansok

Tamen-Raga

265086

2

2

1

5

Km

40 Tache Tale

Tamen-Raga

265092

5

5

1

2

Km

41 Ajo Phab

Tamen-Raga

265102

3

3

1

6

Km

42 Laa II

Tamen-Raga

265106

1

1

1

20

Km

43 Kemyir

Tamen-Raga

265139

4

4

1

2

Km

44 Heba Kabak

Tamen-Raga

265163

5

5

1

11

Km

45 Tiiba

Ziro-I

264594

5

6

2

1

Km

46 Tarin Agya

Ziro-I

264595

5

5

1

1

Km

47 Bamin Michi Tawitbe

Ziro-I

264596

1

1

1

2

Km

48 Taring (Hong)

Ziro-I

264599

1

1

1

1

Km

49 Haley

Ziro-I

264602

2

2

1

1

Km

50 Lodderkonti

Ziro-I

264603

1

1

1

1

Km

51 Gyahi

Ziro-I

264604

3

3

1

2

Km

52 Lower Dilo

Ziro-I

264607

5

5

1

1

Km

53 Siting Boh

Ziro-I

264608

1

1

1

2

Km

54 Sichobo

Ziro-I

264609

2

2

1

2

Km

<!-- page 71 -->

70

55 Belongbo

Ziro-I

264612

1

1

1

2

Km

56 Cholo Agya

Ziro-I

264613

2

2

1

3

Km

57 Taru

Ziro-I

264620

3

3

1

1

Km

58 Bhu

Ziro-I

264621

1

1

1

1

Km

59 Rabii

Ziro-I

264626

1

1

1

5

Km

60 Saliyoga

Ziro-I

264628

3

3

1

1

Km

61 Dilo Yao

Ziro-I

264630

2

2

1

2

Km

62 Paking Pabu

Ziro-I

264631

1

1

1

2

Km

63 Boi

Ziro-I

264632

1

1

1

2.00

Km

64 Tukung

Ziro-I

264633

2

2

1

1.00

Km

65 Lodder

Ziro-I

264634

1

1

1

1.00

Km

66 Tadu

Ziro-I

264635

1

1

1

1.00

Km

67 Lodder I

Ziro-I

264636

2

2

1

1.00

Km

68 Yo Daboi

Ziro-I

264637

1

1

1

1.50

Km

69 Sugyu Pabu

Ziro-I

264641

2

2

1

1.00

Km

70 Dolu Poba

Ziro-I

264647

2

2

1

1.50

Km

71 Lentha Pabu

Ziro-I

264648

3

3

1

1.50

Km

72 Khemeliyang

Ziro-I

264650

2

2

1

2.00

Km

73 Tayuko

Ziro-I

264652

3

3

1

3.00

Km

74 Hakap

Ziro-I

264653

5

5

1

3.00

Km

75 Sangepo

Ziro-I

264656

4

4

1

1.00

Km

76 Namiligo

Ziro-I

264659

2

2

1

1.00

Km

77 Ukobije

Ziro-I

264660

1

1

1

1.00

Km

78 Rantii

Ziro-I

264661

2

2

1

1.00

Km

79 Pokheakamg

Ziro-I

264666

3

3

1

3.00

Km

80 Yolyo

Ziro-I

264667

1

1

1

1.00

Km

81 Tero Ago

Ziro-I

264669

2

3

2

1.00

Km

82 Siri Dipii

Ziro-I

264670

1

1

1

1.00

Km

83 Taru Kelyang

Ziro-I

264671

1

1

1

1.50

Km

84 Rubu

Ziro-I

264672

5

5

1

1.50

Km

85 Poralya

Ziro-I

264673

3

3

1

1.00

Km

86 Ukopo

Ziro-I

264675

5

5

1

1.00

Km

87 Pepungko

Ziro-I

264678

1

1

1

2.00

Km

88 Nanu

Ziro-I

264681

3

3

1

2.50

Km

89 Pai Achang

Ziro-I

264685

3

4

2

2.00

Km

<!-- page 72 -->

71

90 Gano

Ziro-I

264689

5

5

1

1.00

Km

91 Miding Passu

Ziro-I

264691

2

2

1

1.00

Km

92 Bokan II

Ziro-I

264692

1

1

1

1.00

Km

93 Tiibeko

Ziro-I

264701

3

3

1

3.00

Km

94 Tariko

Ziro-I

264703

1

1

1

4.00

Km

95 Akhoebyo

Ziro-I

264715

5

5

1

1.00

Km

96 Yadi

Ziro-I

264721

1

1

1

1.00

Km

97 Siringpakho

Ziro-I

264722

1

1

1

1.00

Km

98 Amung

Ziro-I

264725

4

4

1

1.00

Km

99 Myoliku

Ziro-I

264729

3

3

1

2.00

Km

100 Kalo

Ziro-I

264730

1

1

1

1.00

Km

101 Nyibo

Ziro-I

264731

2

2

1

2.00

Km

102 To Myobia

Ziro-I

264732

1

1

1

3.00

Km

103 Byore

Ziro-I

264733

1

1

1

1.00

Km

104 Gyabu

Ziro-I

264734

5

5

1

2.00

Km

105 Lenting Layu

Ziro-I

264737

1

1

1

1.00

Km

106 Shi

Ziro-I

264741

1

1

1

1.00

Km

107 Kululemp

Ziro-I

264742

4

4

1

1.50

Km

108 Yashibo

Ziro-I

264751

3

4

2

1.00

Km

109 Siya Piro

Ziro-I

264757

1

1

1

1.00

Km

110 Bubu

Ziro-I

264758

5

5

1

1.00

Km

111 Saro

Ziro-I

264759

2

2

1

1.00

Km

112 Kato

Ziro-I

264760

4

5

2

2.00

Km

113 Riku Lanche

Ziro-I

264761

3

3

1

1.50

Km

114 Tadubho

Ziro-I

264772

5

5

1

1.00

Km

115 Kiile Pakho

Ziro-I

264787

1

1

1

1.00

Km

116 Saro

Ziro-I

264803

5

5

1

1.00

Km

117 Myochi

Ziro-I

264804

5

5

1

2.00

Km

118 Lengo

Ziro-I

264813

5

5

1

1.00

Km

119 Tanyo

Ziro-I

264817

5

5

1

1.00

Km

120 Polu Happa

Ziro-II

264883

1

1

1

2.00

Km

121 Kotu Nampam

Ziro-II

264889

3

3

1

2.00

Km

122 Dee Happa

Ziro-II

264890

5

5

1

1.00

Km

123 Dekh

Ziro-II

264903

5

5

1

1.00

Km

124 Howu Happa

Ziro-II

264905

1

1

1

1.00

Km

<!-- page 73 -->

72

125 Paa Yorda

Ziro-II

264907

3

3

1

1.50

Km

126 Moob Happa

Ziro-II

264923

2

2

1

1.00

Km

127 Dora

Ziro-II

265004

4

4

1

1.00

Km

128 Nill Poto

Tamen-Raga

265019

6

6

2

8

Km

129 Tokuso Rijo

Tamen-Raga

265020

6

6

2

3

Km

130 Kunde

Tamen-Raga

265068

6

6

2

2

Km

131 Byan Byap

Tamen-Raga

265078

6

6

2

42

Km

132 Pet-Milli

Tamen-Raga

265128

6

6

2

2

Km

133 Ampar Rakhe

Tamen-Raga

265055

7

7

2

3

Km

134 Jop Hapa

Tamen-Raga

265075

7

7

2

2

Km

135 Mengi Kabak II

Tamen-Raga

265077

7

7

2

5

Km

136 Mid Putu

Tamen-Raga

265081

7

7

2

3

Km

137 Letkamt

Tamen-Raga

265168

7

7

2

2

Km

138 Leya

Tamen-Raga

265028

8

9

3

3

Km

139 Harakso

Tamen-Raga

265050

8

8

2

1

Km

140 Putu

Tamen-Raga

265052

8

8

2

8

Km

141 Gep Yom

Tamen-Raga

265058

8

8

2

1

Km

142 Pompulend

Tamen-Raga

265084

8

8

2

10

Km

143 Boa Model

Tamen-Raga

265103

8

8

2

1

Km

144 Pakh Rijo

Tamen-Raga

265021

9

9

2

4

Km

145 Takek Pada

Tamen-Raga

265065

9

10

3

1

Km

146 Rugya Hapa

Tamen-Raga

265087

9

9

2

3

Km

147 Chudi Yom

Tamen-Raga

265056

10

12

5

3

Km

148 Teblisi

Tamen-Raga

265091

10

13

6

2

Km

149 Paga Hapa

Tamen-Raga

265067

11

13

5

1

Km

150 Palap

Tamen-Raga

265098

11

13

5

2

Km

151 Gumtu

Tamen-Raga

265167

11

13

5

3.50

Km

152 Setha Pury

Tamen-Raga

265064

12

14

5

1

Km

153 Posa

Tamen-Raga

265029

13

15

5

2

Km

154 Daa Hill Top

Tamen-Raga

265063

13

16

6

1

Km

155 Bomtee

Tamen-Raga

265085

13

15

5

3

Km

156 Sey Godak

Tamen-Raga

265149

13

16

6

1

Km

157 Onga

Tamen-Raga

265107

14

16

6

1

Km

158 Loktap

Tamen-Raga

265041

15

17

6

2

Km

159 Pelmilli

Tamen-Raga

265129

15

17

6

1

Km

<!-- page 74 -->

73

160 Sihing

ZIRO - I

264658

6

6

2

1.50

Km

161 Tabung Byarang

ZIRO - I

264702

6

6

2

1.50

Km

162 Sisang

ZIRO - I

264727

6

6

2

1.50

Km

163 Yanjo

ZIRO - I

264788

6

6

2

1.50

Km

164 Tiba

ZIRO - I

264624

7

7

2

1

Km

165 Tayuga

ZIRO - I

264627

7

7

2

1

Km

166 Makung

ZIRO - I

264654

7

7

2

1

Km

167 Khahu

ZIRO - I

264663

7

7

2

1

Km

168 Katapu

ZIRO - I

264679

7

7

2

1.50

Km

169 Khogyo

ZIRO - I

264693

7

7

2

1.50

Km

170 Byoni

ZIRO - I

264708

7

7

2

1.50

Km

171 Puduwan

ZIRO - I

264743

7

7

2

1.50

Km

172 Gandi Ali

ZIRO - I

264752

7

7

2

1.50

Km

173 Diley

ZIRO - I

264805

7

7

2

1.50

Km

174 Dusa

ZIRO - I

264606

8

8

2

1

Km

175 Kontii

ZIRO - I

264610

8

8

2

1

Km

176 Sarang

ZIRO - I

264738

8

8

2

1

Km

177 Myolyang

ZIRO - I

264747

8

8

2

1

Km

178 Myobya Hagya

ZIRO - I

264768

8

8

2

1

Km

179 Siro Ago

ZIRO - I

264617

9

10

3

1

Km

180 Liagi Tage

ZIRO - I

264698

9

9

2

1

Km

181 Kaliang Siigang

ZIRO - I

264711

9

9

2

1

Km

182 Moko

ZIRO - I

264728

9

9

2

1

Km

183 Gyachi

ZIRO - I

264766

9

9

2

1

Km

184 Lalye

ZIRO - I

264786

9

9

2

1

Km

185 Bamin Michitarin

ZIRO - I

264598

10

12

5

1

Km

186 Tarutahe

ZIRO - I

264615

10

12

5

1

Km

187 Nara Pabu

ZIRO - I

264649

10

12

5

1

Km

188 Taho

ZIRO - I

264668

10

12

5

1

Km

189 Parpii

ZIRO - I

264677

10

12

5

1

Km

190 Paro Lyapo

ZIRO - I

264697

10

12

5

1.50

Km

191 Dapopigyang

ZIRO - I

264712

10

12

5

1.50

Km

192 Shibu

ZIRO - I

264800

10

12

5

1.50

Km

193 Lyako

ZIRO - I

264811

10

12

5

1.50

Km

194 Myoli

ZIRO - I

264816

10

12

5

1.50

Km

<!-- page 75 -->

74

195 Hula Puta

ZIRO - I

264605

11

13

5

1.50

Km

196 Khachi

ZIRO - I

264683

11

13

5

1.50

Km

197 Katunyatu

ZIRO - I

264694

11

13

5

1.50

Km

198 Sirii Pabu

ZIRO - I

264706

11

13

5

1

Km

199 Byachi

ZIRO - I

264719

11

13

5

1

Km

200 Salang

ZIRO - I

264723

11

13

5

1

Km

201 Yashibo

ZIRO - I

264767

11

13

5

1

Km

202 Myodipu

ZIRO - I

264815

12

14

5

1

Km

203 Kochipakre

ZIRO - I

264710

13

15

5

1

Km

204 Byabia

ZIRO - I

264778

13

15

5

1

Km

205 Pokhe Ayo

ZIRO - I

264680

14

16

6

1

Km

206 Takhu Sidhi

ZIRO - I

264773

14

16

6

1

Km

207 Kardo

ZIRO - I

264802

14

16

6

1

Km

208 Khangalya

ZIRO - I

264809

14

16

6

1

Km

209 Bakhani

ZIRO - I

264662

15

17

6

1

Km

210 Siikhebu

ZIRO - I

264664

15

17

6

1

Km

211 Biiree (Hong)

ZIRO - I

264686

15

17

6

1

Km

212 Lajibogya

ZIRO - I

264762

15

17

6

1

Km

213 Dilang

ZIRO - I

264794

15

17

6

1

Km

214 Pyuchi

ZIRO - I

264822

15

17

6

1

Km

215 Kasing-Puttung

ZIRO - II

264866

6

6

2

1.50

Km

216 Yebin

ZIRO - II

264952

6

6

2

2

Km

217 Ruech Geka

ZIRO - II

264955

6

6

2

3

Km

218 Thowu

ZIRO - II

264913

7

7

2

2.50

Km

219 Yebin Lebir

ZIRO - II

264956

7

7

2

4

Km

220 Mompotu

ZIRO - II

264868

8

8

2

1

Km

221 Khompu

ZIRO - II

264949

8

8

2

3

Km

222 Mego

ZIRO - II

264950

8

8

2

2

Km

223 Taki Ko Happa

ZIRO - II

264874

9

9

2

1

Km

224 Jabli (Verma Point)

ZIRO - II

264880

9

9

2

1

Km

225 Tepin Happa

ZIRO - II

264884

9

10

3

5

Km

226 Peji Tabi

ZIRO - II

264946

9

9

2

2.50

Km

227 Nyllo

ZIRO - II

264893

10

12

5

3

Km

228 Komru

ZIRO - II

264895

11

13

5

1.50

Km

229 Phop

ZIRO - II

264921

11

13

5

1.50

Km

<!-- page 76 -->

75

230 Trattabi

ZIRO - II

264945

11

13

5

1

Km

231 Oram Geko

ZIRO - II

264973

11

13

5

1

Km

232 Tapa Happa

ZIRO - II

265006

11

13

5

1

Km

233 Proibrin Happa

ZIRO - II

264876

12

14

5

1.50

Km

234 Machin

ZIRO - II

264894

12

14

5

1

Km

235 Rewa Deli

ZIRO - II

264947

12

14

5

1

Km

236 Polin

ZIRO - II

264845

13

15

5

1

Km

237 Nima Happa

ZIRO - II

264856

13

15

5

1

Km

238 Pekir Passa

ZIRO - II

264892

13

15

5

2

Km

239 Tadosilly

ZIRO - II

264933

13

15

5

1.50

Km

240 Seer

ZIRO - II

264902

14

16

6

3

Km

241 Pakhi

ZIRO - II

264934

14

16

6

2

Km

242 Hitu

ZIRO - II

264958

14

16

6

1

Km

243 Sarak

ZIRO - II

264977

14

16

6

4

Km

244 Chun

ZIRO - II

264839

15

17

6

1.50

Km

245 Pogi Happa

ZIRO - II

264906

15

17

6

1

Km

246 Lichi Ochi

ZIRO - II

264916

15

17

6

2

Km

1779

1936

662

Village
Census
Code

No.
of
H.H.

No. of System
Porposed

4

262420

Total :

10. District : Papum Pare
Sl.
No.

Village name

1

1

Block Name

2

Dwr Rabg

3

Balijan

Manual
cartage
distance

Power
Pack

Solar
Street
Light

5

6

7

8

3

3

1

17 Km

<!-- page 77 -->

76

2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43

Sichir
Bomch-Bomte
Taram
Rumi
Habia
Pachin
Taipu
Langke
Upper Rupung
Talikso
Lengke
Lengso
Boginadi Forest Beat
5 Mile Village
Duda Namchang
Hara Hapa
10 Mile Camp
Gungi
Ngudang - I
47 K.M. Camp
Hoj -II
Deb -II
Muglang
Sharik
Bodak
Rach - II
Pare-Hapa
Alw Tuda
Cherso
Nyoriso
Tar
Ligamtung
Sindhu Patta
New Bam
Nyoing
Kampung Reng
Yadang - II
Palap
Ragia
Diderso
Bukka - II
Borsetum

Doimukh
Kimin
Doimukh
Sagalee
Sagalee
Sagalee
Sagalee
Sagalee
Sagalee
Sagalee
Balijan
Balijan
Kimin
Doimukh
Doimukh
Doimukh
Doimukh
SAGALEE
SAGALEE
SAGALEE
SAGALEE
SAGALEE
SAGALEE
SAGALEE
SAGALEE
SAGALEE
SAGALEE
SAGALEE
SAGALEE
SAGALEE
SAGALEE
Balijan
Balijan
Balijan
Balijan
Balijan
Balijan
Balijan
Balijan
Balijan
Kimin
Kimin

262462
262745
262317
262525
262529
262583
262640
262655
262656
262672
262406
262430
262759
262513
262347
262488
262514
262573
262602
262551
262559
262571
262585
262681
262584
262591
262682
262683
262569
262625
262626
262395
262305
262391
262400
262422
262383
262397
262403
262417
262729
262756

36
1
2
5
3
4
3
5
3
4
5
5
2
6
7
14
8
6
6
7
7
7
7
7
8
8
8
8
9
9
9
6
7
7
7
7
8
8
8
8
8
8

38
1
2
5
3
4
3
5
3
4
5
5
2
6
7
16
8
6
6
7
7
7
7
7
8
8
8
8
9
9
9
6
7
7
7
7
8
9
8
8
8
9

11
1
1
1
1
1
1
1
1
1
1
1
1
2
2
6
2
2
2
2
2
2
2
2
2
2
2
2
2
2
2
2
2
2
2
2
2
3
2
2
2
3

13.7
16
5
6
15
12
5
8
5
5
5
5
5
1
2
2
1
10
12
2
4
5
9
8
7
8
4
6
10
12
10
8
6
10
10
12
8
10
18
16
5
4

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

<!-- page 78 -->

77

44
45

Pacho
Poteh

Mengio
Sagalee

262710
262638

9
21

9
23

2
7

334

342

97

Village
Census
Code

No.
of
H.H.

No. of System
Proposed

4

Total :

12 Km
Km

11. District : Tawang
Sl.
No.

Village name

Block Name

3

Power
Pack

Solar
Street
Light

5

6

7

Manual
cartage
distance

1

2

1
2
3
4
5
6
7
8

Luguthang
Thangphe Gonpa
Bemathang Gonpa
Chala Gonpa
Yuesa Gonpa
Brakhar Gompa
Sarong
Tebo

Jang-Thingbu
TAWANG
Tawang
Tawang
Tawang
Jang-Thingbu
Jang-Thingbu
Zemithang-Dudunagar

261611
261496
261474
261475
261491
261572
261606
261389

11
5
3
3
2
2
2
4

12
5
3
3
2
2
2
4

4
1
1
1
1
1
1
1

25
15
2
3
5
3
2
4

9

Hanggang

Zemithang-Dudunagar

261390

2

2

1

6 Km

10
11
12
13
14
15
16
17
18

Kheleteng
Grakhang
Gorman Gompa
Changteng
Thespa Gonpa
Gyamo
Bompa
Rigiba
Rishorekharchen

Zemithang-Dudunagar
Jang-Thingbu
TAWANG
TAWANG
TAWANG
Zemithang-Dudunagar
Mukto-Bongkhar
Mukto-Bongkhar
Mukto-Bongkhar

261436
261566
261520
261511
261508
261431
261598
261596
261594

2
12
8
13
15
12
30
14
15

2
14
8
15
17
14
32
16
17

1
5
2
5
6
5
10
6
6

2
12
6
8
5
8
5
8
14

155

170

58

Total :

8

Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km
Km

12. District : Upper Siang
Sl.No.

1

Village name

2

Block Name

3

Village
Census
Code

No.
of
H.H.

4

5

No. of System
Proposed
Power
Pack

Solar
Street
Light

6

7

Manual
cartage
distance

9

<!-- page 79 -->

78

1
2
3
4
5
6
7

Pongging
Peki-Modi
Amging
Monge
Monge
Gome
Palling H.Q.

Geku
MARIYANG
Tuting
TUTING
TUTING
TUTING
Tuting

264034
264023
263953
263930
263954
263941
263957

Total :

50
13
5
7
7
14
30

53
15
5
7
7
16
34

16
5
1
2
2
6
12

126

137

44

No.
of
H.H.

No. of System
Proposed

12
30
10
18
18
15

Km
Km
Km
Km
Km
Km
Km

13. District : Upper Subansiri
Sl.
No.

Village name

1

Block Name

2

3

Village
Census
Code

Power
Pack

Solar
Street
Light

4

5

6

7

Manual
cartage
distance

8

1

Bhur

Daporijo

263100

5

5

1

12

Km

2

Cheha-Rijo

Daporijo

263109

3

3

1

14

Km

3

Nirpelibe

Dumporijo

263197

5

5

1

11

Km

4

Dogi Rosarijo

Dumporijo

263269

5

5

1

10

Km

5

Molo

Giba

263062

1

1

1

8

Km

6

Dape

Nacho

262804

5

5

1

9

Km

7

Taro

Nacho

262806

5

5

1

10

Km

8

Kojup

Nacho

262847

4

4

1

14

Km

9

Gich Putu

Puchi-Geko

263149

2

2

1

8

Km

10

Dadu

Limeking

262764

5

5

1

55

Km

11

Bodok

Limeking

262784

4

4

1

6

Km

12

Nyare

Limeking

262786

1

1

1

9

Km

13

Mepu

Limeking

262788

2

2

1

12

Km

14

Orak Camp

Limeking

262793

1

1

1

1

Km

15

Makodo

Limeking

262797

1

1

1

16

Km

16

Cheging

GIBA

263066

7

7

2

12

Km

17

Jumbu Rage

GIBA

263076

7

7

2

14

Km

18

Roji

GIBA

263008

8

8

2

6

Km

<!-- page 80 -->

79

19

Hamriga

GIBA

263080

8

8

2

10

Km

20

Machi- Rijo

GIBA

263051

14

16

6

10

Km

21

Makba

GIBA

263018

10

12

5

22

Km

22

Piya

GIBA

263023

10

12

5

35

Km

23

Hina

GIBA

263037

18

20

7

9

Km

24

Lokarijo

GIBA

263082

10

12

5

11

Km

25

Sarne-Yorlo

GIBA

263013

12

14

5

12

Km

26

Lingcha

GIBA

263069

12

14

5

13

Km

27

Dayam

GIBA

263079

12

14

5

14

Km

28

Dadi

GIBA

263081

12

14

5

20

Km

29

Puda

GIBA

263010

13

15

5

12

Km

30

Kikik

GIBA

263064

13

15

5

14

Km

31

Rapi

GIBA

263070

13

15

5

10

Km

32

Lokar Rijo

GIBA

263085

13

15

5

13

Km

33

Rago

GIBA

263019

14

16

6

30

Km

34

Rava

GIBA

263020

14

16

6

6

Km

35

Moya

GIBA

263043

14

16

6

12

Km

36

Lingking

GIBA

263067

14

16

6

9

Km

37

Semma

GIBA

263097

14

16

6

12

Km

38

Thungba(Tungba)

Limeking

262769

6

6

2

15

Km

39

Yaja

Limeking

262767

7

7

2

73

Km

40

Taying

Limeking

262771

7

7

2

72

Km

41

Redding Camp

Limeking

262792

7

7

2

26

Km

42

Redding

Limeking

262766

12

14

5

74

Km

43

Orak III

Limeking

262795

12

14

5

2

Km

44

Reddy

Limeking

262765

13

15

5

72

Km

45

Orak II

Limeking

262794

13

15

5

2

Km

46

Ishneya (Isnia) II

Limeking

262774

17

19

6

80

Km

47

Kache

Limeking

262768

20

22

7

76

Km

48

Ishneya (Isnia) I

Limeking

262773

20

24

9

80

Km

49

Gumsing

Limeking

262772

21

23

7

70

Km

50

Ojugu

Limeking

262775

21

23

7

71

Km

51

Dojubung

Limeking

262763

2

57

18

82

Km

52

Dolering

Limeking

262782

15

2

1

50

Km

53

Lingbing

Limeking

262770

19

17

6

5

Km

54

Gelinceniak Camp

Limeking

262790

1

21

7

25

Km
