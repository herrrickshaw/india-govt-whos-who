---
doc_id: "7161f33ccef6eecc"
source_url: "https://www.arunachalplan.gov.in/wp-content/uploads/2026/03/ATI-Order-for-Additional-Allocation-of-Rs.-728.74-Lakh-during-CFY-2025-26.pdf"
ministry: "Finance-Planning & Investment Department, Arunachal Pradesh"
title: "ADDENDUM 1"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7abdb8576da84243"
---

<!-- page 1 -->

c

'!

l

L!
V

ol

No. PLNG-1 1 01 4/1 12025-Ol o, DIR-SP-FPID-Part(39)

lvua

(Comp. No. 291359)
GOVERNMENT OF ARUNACHAL PRADESH
FINANCE, PLANNING & INVESTMENT DEPARTMENT
(PLANNTNG & INVESTMENT DIVISION)
A.P. CIVIL SECRETARIAT:: ITANAGAR
Dated, the 6th March 2026
ORDER

Approval is hereby accorded for an additional allocation of Rs. 728.74 lakh (Rupees seven
crore twenty-eight lakh seventy-four thousand only) to the Directorate of Administrative Training

lnstitute for 'lnterior furnishing, Audio video & automation work at Administrative and
Academic Block at ATI Naharlagun 'during the current flnancial Year 2025-26. The same will be
regularized at the time of finalization of RE 2025-26.
2

Utilization of fund is subject to adherence to the following:

a) This allocation is purely indicative in nature and this shall be utilized by the departments

only after verifying the actual requirement and observance of guidelines and all the
financial rules, regulations, provisions, prescribed in GFR, DFPR, etc. &

guidetines/circulars/ OM's/ directives issued by the CVC, MoF, MHA, Gol, Administrative
Ministries of Gol & GoAP from time to time in this regard in letter & spirit without fail
b) The department shall incur expenditure only after the necessary allocation of fund and
budgeting in consultation with the Finance, Planning & lnvestment Department of the
Budgel Divrsion which will be regularised at the time of finalization of RE 2025-26.
c) The nodal department and the executing agency (wherever applicable) shall maintain
proper coordination and ensure that works are executed as per prescribed norms/
specifications.
d) The scheme should be completed as per the timeline so that there is no cost or time
overrun.

e) Fund should be utilized during current financial year for the purpose for which it is
allocated and cannot be diverted for any other purpose.

f) No revised estimate/ cost escalation and change of schemewill be allowed.

g) Department should ensure that there is no duplicity of the works with any other

schemes/ projects proposed/sanctioned by the State Govt./ Govt. of lndia. lf any
discrepancies is detected, the concerned department should immediately bring it to the
notice of Planning & lnvestment Department before commencement of execution of the
work. Diversion of fund to other works in such cases will not be permitted.
h) Concerned Commissioner/Secretary will monitor and review the progress of
implementation of the scheme/ project at regular intervals and shall ensure tlmely
submission of quarterly progress report, utilization certificate, photographs and
completion certificate etc. as applicable only after necessary review/ veriflcation at their
level.

i) violation of above instruction/guidelines will be the sole responsibility of the officers

concerned. Further, the amount only as actually required should be used and the
balance amount if any, should be surrendered.

3.

This is issued with the approval of the Competent Authority
(R.K. Sharma) IAS
Commissioner (Planning & lnvestment)

Page 1of 2

<!-- page 2 -->

0e
.!
o-

5

File No. PLNG- l 1 O'1 411 12O25-Olo, DIR-SP-FPID'Part(39)
1 1O1 4 I 1 12025-C lo, DIR-SP-FPl D-Part(39)

lvrrl

Dated, the 6th March 2026

Copy for information to:-

1) The PPS to Hon'ble Chief Minister, GoAP, ltanagar.
2) The PS to Hon'ble Deputy Chief Minister, GoAP, ltanagar.
3) The US to the Chief Secretary, GoAP, ltanagar.
4) The SPA to Commissioner (Finance), GoAP, ltanagar.
5) The PAto Secretary (Personnel), GoAP, ltanagar
6) The Director (ATl), GoAP, Naharlagun.
7) The Under Secretary (BudgeVFinance- D), GoAP, ltanagar
8) The SRA (Budget), GoAP, ltanagar.
9) Office copy.
(R.K. Sharma) IAS
Commissioner (Planning & lnvestment)

Page 2 ol 2
