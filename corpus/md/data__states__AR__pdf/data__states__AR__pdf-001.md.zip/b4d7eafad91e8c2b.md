---
doc_id: "b4d7eafad91e8c2b"
source_url: "https://arunachalipr.gov.in/uploads/2025/04/Circular.pdf"
ministry: "Information and Public Relations Department, Arunachal Pradesh"
title: "Download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9dfadf70c002f44e"
---

<!-- page 1 -->

DIRECTORATE OF HIGHER AND TECHNICAL EDUCATION
GOVT. OF ARUNACHAL PRADESH
ITANAGAR
Date: 5th April’ 2025

No. HTE-17/6/2024 (Part-I)

CIRCULAR
This is for general informa on to all concerned that with reference to Public No ce
vide No. HTE-17/6/2024 (Part-I), Dated- 10-03-2025 and subsequent Order vide No. HTE17/6/2024 (Part-I), Dated- 27-03-2025, in connec on with the conduct of Wri en Test Exam
for selec on of Govt. Sponsored Free UPSC Coaching at Samkalp, New Delhi; the ﬁnal list of
Eligible candidates are published in the oﬃcial website of www.apdhte.nic.in.
Further, candidates who have been found not eligible on the grounds of the
minimum qualifying marks in Class XII, Gradua on, age or any other ground may contact
this Directorate either in person or through email at dhearunachal@gmail.com. Any claim
and objec on may be done on or before 8th April’ 2025 within 4:00 PM.
No further claim shall be entertained a er 8th April 2025 (04:00PM) under any
circumstances.
The Admit Card of the said examina on for the eligible candidates shall be sent
through the respec ve email provided in the applica on OR the same may be collected in
person from this Directorate showing a valid Iden ty Card on 11th and 12th April’ 2025.
The tenta ve date of examina on is scheduled on 15th April’ 2025 at Dera Natung
Govt. College, Itanagar.

(Sd/- Dr. Milorai Modi)
Director
