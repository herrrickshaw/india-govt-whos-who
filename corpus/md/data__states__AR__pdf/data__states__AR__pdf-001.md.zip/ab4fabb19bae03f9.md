---
doc_id: "ab4fabb19bae03f9"
source_url: "https://eodb.arunachal.gov.in/uploads/notifications_and_orders_documents/9b0aa05af8a605c1a321bca3559dbefd.pdf"
ministry: "Arunachal Pradesh Investment Portal"
title: "Industry Policy     -->"
date: ""
pages: 19
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5cb7a67bce204408"
---

<!-- page 1 -->

The Arunachal Pradesh Gazette
EXTRAORDINARY

PUBLISHED BY AUTHORITY
No. 118, Vol. XXXII, Naharlagun, Wednesday, April 9, 2025, Chaitra 19, 1947 (Saka)
GOVERNMENT OF ARUNACHAL PRADESH
DEPARTMENT OF INDUSTRIES
ITANAGAR
————
NOTIFICATION
The 2nd April, 2025
No. DOI-13/5/2024.—The Governor of Arunachal Pradesh is pleased to notify the “Arunachal Pradesh
Industrial Development and Investment Policy, 2025”. The policy shall come into effect from 1st April, 2025
and shall remain in force until further orders.
Consequently the Arunachal Pradesh State Industrial and Investment Policy 2020 stands repealed.
Commissioner (Industries),
Government of Arunachal Pradesh,
Itanagar.
ARUNACHAL PRADESH INDUSTRIAL DEVELOPMENT AND INVESTMENT POLICY, 2025
Chapter - 1
Vision
“To usher in growth and economic development by fostering entrepreneurship, promoting selfemployment and creating employment opportunities by way of industrialization, while ensuring
ecological sustainability and heritage of the State”.
Objectives
The proposed objectives of the Arunachal Pradesh Industrial Development and Investment Policy, 2025 are:
1. To create a congenial investment climate for existing business enterprises to grow as well as
encouraging new investment in the State and to ensure overall development of Industries in the
manufacturing and service sector.
2. To promote entrepreneurs from within the State while promoting local products manufactured from
produce of the state. Support local textile, food processing and tourism sector to achieve deeper
penetration.
3. Promote integrated growth of the region, while preserving the region's ecology.
4. Realizing the potential of local entrepreneurship development and employment generation, through
skill development of the youth and stakeholders.
5. Encourage exports from the region to global markets. Create market linkages and investment
opportunities to nurture businesses in Arunachal Pradesh.
6. Specifically address issues impeding industrial growth and ensure simplification of procedures, develop
key industrial and social infrastructure, focus on human resource development, access to credit and
market.
7. Support One District One Product (ODOP) program and GI Products from the State.
8. Support underprivileged sections of society.
Chapter - 2
Introduction:
Arunachal Pradesh, the “Land of Dawn-Lit Mountains”, is the largest northeastern State which spans
across a massive 83,743 sq. km, with vast untapped economic potential. It has a forest cover of 79.33%,
making it one of the world’s 12 mega biodiversity hotspots. The state shares borders with Myanmar (520 km),
and Bhutan (217 km) and comprises 28 districts, reflecting its cultural diversity.
Arunachal Pradesh boasts of immense hydropower potential, estimated at 58,000 MW, positioning it as
a strategic player in India’s energy sector. The state's installed hydropower stands at 1,270 MW, with several
key milestone projects nearing completion, which will allow substantial achievement of its potential capacity.
In addition to this, the State offers attractive energy tariffs, fostering investment in sectors such as
manufacturing, textiles, steel and sustainable farming. Industrial tariffs range from 3.35 to 4.30 per unit,
while agricultural/BPL household tariffs are as low as 2.65 per unit, promoting Agri-Tech initiatives. Competitive
bulk tariffs of 3.25- 3.75 per unit present lucrative opportunities for power-intensive industries.
2.

<!-- page 2 -->

2

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025

Arunachal Pradesh is a youth dominated state and has a literacy rate of 66.95%, allowing the creation
of a skilled and employable work pool. Resulting in the proactive initiatives of the Government of Arunachal
Pradesh has been implementing key initiatives for the up-skilling and employability of its eligible workforce.
The State currently has a network of Polytechnics, nursing institutes, ITIs, along with State and private
Universities and one NIT operational in the State. These institutions offer trainings in over 23 different trades/
vocations, with a total yearly intake capacity around 2500 candidates.
Infrastructure development has been pivotal to Arunachal Pradesh's growth, with major focus being directed
towards connectivity of the established industrial estates/ areas in the State. The Nechiphu and Sela Tunnels
have significantly improved connectivity of West Kameng and Tawang to-and-from mainland Assam.
The Donyi Polo Airport in Itanagar, inaugurated in 2022 has opened opportunities through air connectivity in
the State. The Niglok Industrial Estate, being a major industrial establishment for the State is well connected
with Assam, located near to the Dibrugarh International Airport, which is a major connectivity hub. In addition,
the operational airport in Tezu and Pasighat is posed to enhance last mile connectivity even further. Road
connectivity in and around the State has also advanced, with a 9-fold increase in construction speed, a 64%
rise in road length and a 143% expansion in the National Highway network. The State has 9 identified and
operational industrial areas and another 9 industrial estates facilitating establishment of industrial infrastructure
in the State.
Arunachal Pradesh's proactive policies, abundant natural resources and strategic initiatives make it a
hub for sustainable development and investment. By leveraging its biodiversity, hydropower capacity and
infrastructure progress, the state is emerging as a key destination for economic growth and opportunity.
Chapter - 3
3. Enabling Ecosystem:
Infrastructure plays a pivotal role in driving industrial development within the state. The availability of
quality infrastructure enables industries to establish operations with lower capital investment and function
efficiently without disruptions.
Beyond facilitating economic expansion, robust industrial infrastructure contributes to social development,
employment generation and increased investment inflow. Recognizing its significance, Arunachal Pradesh is
on its way to strengthen its industrial infrastructure and facilitate smooth industry sustenance of industrial
infrastructure. The Government of Arunachal Pradesh aims to prioritize the development of essential infrastructure
to create a favourable investment climate.
3.1 Land:
Arunachal Pradesh has 17 industrial estates (Annexure-I). The Department of Industries is taking steps
to develop these and provide basic infrastructure for the ease of industries.
Land can also be leased in private lands for industrial purpose on the terms specified in Chapter 5.
3.2

Railways:

Arunachal Pradesh is expanding its railway network to enhance logistics and last-mile connectivity.
With 26 km of railway tracks and five rail goods sheds, key projects such as Murkongselek-Pasighat (26 km),
Pasighat-Tezu-Rupai (218 km), Silapathar-Bame-Along (96 km), and Misamari-Tawang (201 km) will improve
access to industrial clusters. A 6,000 sqm world-class station at Pasighat will strengthen rail-road connectivity.
The Murkongselek-Pasighat broad gauge (BG) route, particularly the 8-km stretch from Ruksin (NH 515) to
Niglok (first phase), will enhance access to the Niglok Industrial Zone in East Siang.
3.3

Power:

The Arunachal Pradesh offers power to the industries at the most competitive rates in the region. For
present Power tariff rates, refer to the notification issued from the Arunachal Pradesh State Electricity Regulatory
Commission. The state is striving to further improve quality of power by prioritizing dedicated feeder and power
lines upto 132 kV in the industrial estate.
3.4 Airways:
Arunachal Pradesh currently has four operational airports located in Hollongi, Tezu, Pasighat and Ziro,
facilitating air connectivity in the region. Additionally, the State is equipped with seven Advanced Landing
Grounds (ALGs) that serve as strategic assets for logistical movement to border areas. Furthermore, there
are 25 existing helipads across the State, enhancing aerial accessibility. To further strengthen its aviation
infrastructure, Arunachal Pradesh has proposed the development of two new airports at Richi Village in Upper
Subansiri and Termoba in West Siang. Moreover, the ALGs at Walong, Tuting, Mechuka and Vijoynagar have
been proposed for civilian operations, contributing to improved connectivity and regional development.
Chapter - 4
4. Definitions:
1. “Government” or “State Government” refers to the Government of Arunachal Pradesh”.
2.

“State” refers to the State of Arunachal Pradesh.

3.

“Industrial Policy” refers to the “Arunachal Pradesh Industrial Development and Investment
Policy, 2025 (APIDIP 2025)”.

4.

“Turnover” means the total monetary value realized from the sale of manufactured goods or services
by an Industrial Unit or Enterprise during a financial year. Income from non-operating sources, such
as interest, grants, subsidies, trading activities, or resale of goods, is excluded from turnover.

<!-- page 3 -->

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025

3

5.

“Investment” refers to the capital expenditure made on plant, machinery, buildings and other
long-term physical assets. Investments in land may also be included, subject to approval by the
competent authority.

6.

“Manufacturing Unit” refers to a unit involved in the processing of raw materials or inputs that
results in the creation of a finished good, distinct in name, character and use.

7.

“Services Unit” refers to businesses in sectors such as Hotels and Hospitality, Tourism (including
Homestays, Adventure, Health Tourism, Eco-Tourism and MICE), Education (Vocational and Digital/
e-learning), Skilling, Music, Films and Entertainment, Sports, Biotech, Fin-tech and Financial
Services, Healthcare (Secondary and Tertiary), IT-ITeS, BPO, EV Charging Stations and
Tech-oriented startups offering services in areas like education, primary healthcare, agriculture
and green innovations.

8.

“Commencement of Commercial Production (Manufacturing Sector)” means the initiation of
the production of finished goods on a commercial scale, following trial production and the full
installation of plant and machinery, with all required raw materials and consumables available for
manufacturing.

9.

“Commencement of Commercial Operation (Service Sector)” means the start of operations
or delivery of services on a commercial basis.

10.

“Building and Other Durable Physical Assets” in the service sector includes new buildings
and long-term physical assets purchased at arm's length pricing for the service unit. Further
details of durable assets will be provided in guidance.

11.

“Industrial Park” refers to a private industrial estate/industrial park/industrial growth center/food
processing park/ pharma park, or export promotion industrial park notified/ earmarked by the
Government of Arunachal Pradesh for the purpose of setting up of Industrial Units in the State.

12.

“Plant and Machinery” in the case of Manufacturing units shall cover industrial plant and machinery
as erected at the site, which is newly purchased from the open market. It excludes relocated/
recycled/refurbished plants and machinery.

13.

“Raw material” means materials or substances used by any unit to produce or manufacture the
finished goods.

14.

“Finished Good” refers to products that have undergone the full manufacturing process by
processing of raw materials and are ready for sale or distribution. In the service sector, finished
goods will be the final sellable product/service that is put out on sale by the enterprise. These
goods are produced and supplied by an industrial unit registered in the state of Arunachal Pradesh.

15.

Substantial Expansion means an additional investment of minimum twenty five percent of the
total amount of investment already made in the existing unit in plant and machinery (for manufacturing
sector) or construction of building and other durable physical assets (for service sector) for the
purpose of enhancement of capacity, modernization, diversification or additional line of activity.

16. “Consultant” means any consultancy organization registered/empanelled with the State or Central
Government or agency thereof or registered as management consultant under MSME NIC
Code-70200 for the purposes of preparation of feasibility reports and DPRs. Scientific and
Educational Organisations with domain expertise in providing consultancy/professional/expert
services for the above purposes will also come under the ambit.
17. AI - Artificial Intelligence: Technology that enables machines to mimic human intelligence,
including learning, problem-solving and decision-making.
18.

EODB - Ease of Doing Business: A measure of how conducive the regulatory environment is for
starting and operating a business.

19.

GST - Goods and Services Tax: A unified indirect tax that replaces various central and state taxes,
aimed at simplifying the tax structure in India.

20.

GI - Geographical Indication: A label used on products that have a specific geographical origin and
possess qualities or a reputation due to that origin.

21.

MSME - Micro, Small and Medium Enterprises: Enterprises classified based on their investment
in plant and machinery or equipment, crucial for economic growth, employment and innovation.

22.

ODOP - One District One Product: An initiative to promote local products, fostering economic
development by identifying and branding one product per district.

23.

R and D - Research and Development: The activities undertaken by businesses or institutions to
innovate, improve products or develop new technologies.

24.

SEZ - Special Economic Zone: A designated area in a country where business and trade laws are
different from the rest of the country, aimed at attracting foreign investment.

25.

SWS - Single Window System: A system that provides a single point for all approvals and permits
required by businesses, reducing time and complexity in setting up operations.

26.

SME - Small and Medium Enterprises: Businesses that are independently owned and operated,
with a small to medium scale of operation and employee size.

27.

NOC - No Objection Certificate: A legal document issued by an organization or Government that
states that they do not object to the activities being undertaken.

28.

Interpretation- The decision of the Industries Department, Government of Arunachal Pradesh
with regards to Interpretation of any clause of the policy shall be final and binding.

<!-- page 4 -->

4

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025
29. “Rights of the State Government”(a)

Department of Industries, Government of Arunachal Pradesh reserves the right to amend any
provision(s) including amendment or withdraw any of the incentive/subsidy as and when
necessary for development of industries and in the interest of the people of the State from time
to time.

(b)

Department of Industries, Government of Arunachal Pradesh reserves the right to review the
matter regarding sanction/ disbursement of subsidies/ incentives to the eligible industrial unit(s)
and the decision of the State Government shall be final and binding.

(c)

Department of Industries, Government of Arunachal Pradesh reserves the right to modify the
eligible/ non-eligible list of the industries, include or delete activities under thrust sectors and
when required in the interest of the State and preservation of environment and ecology.

(d) Department of Industries, Government of Arunachal Pradesh reserves the right to make/ amend
the necessary rules for implementation of this policy as and when required.
Chapter - 5
5.1. Eligible Units:
Industrial units eligible under Manufacturing and Service sector for incentive(s) under this scheme are as
defined below:
(a)

New Industrial Units engaged in manufacturing except manufacturing units engaged in activities
specified in the “Negative List” in Annexure IV;

(b) New Industrial Units under service sector engaged in “Positive List for Service Sector” in Annexure- III;
(c) Existing Industrial Units of manufacturing sector undertaking Substantial Expansion except industrial
activities as specified in the Negative List;
(d)

Existing Industrial Units of service sector engaged in Positive List for Service Sector undertaking
Substantial Expansion;

(e)

Existing Industrial Units in the manufacturing or service sector irrespective of undertaking substantial
expansion for specified incentives.

2.

These units will be eligible for incentives, subsidies and facilities announced under this policy subject to
fulfilment of the eligibility criteria and /or conditions as specified for each of the incentives in the rules/
guidelines.

3.

Incentives provided under this policy will be claimed by the Unit after the date of commencement of
commercial production/operation or the any appointed date whichever is later, unless otherwise mentioned
in the incentive specifically in the policy document OR the procedural guidelines for implementation of
the policy.

4.

Units availing incentives under other schemes of the Government of India or the State Government will not
be eligible for similar incentives under this policy. Such units can avail other incentive(s) under this Policy
as per eligibility.

5.

Period for availing incentive(s): Eligible units can avail specified incentives under this policy upto a period
as specified under the respective incentives.

5.2. Registration of Units:
1.

New industrial units intending to avail incentives under this policy will have to Register with the
Industries Department through a notified mechanism for the purpose.

2.

The Date of commencement of Operation shall be authenticated by the designated authorities
notified by the Industries Department.

5.3. De-registration of Units:
(a)

Director, Department of Industries will de-register any unit from the scheme based on a request
from any unit after undertaking due process as will be notified in the operational guidelines.

(b)

De-registration of any unit from the policy due to acts of omission and commission may be done by
the directorate with due approval from the Commissioner Industries.

5.4. Obligations:
1.

All industrial units shall comply with the applicable State and Central laws, including but not
limited to:
 The Factories Act, 1948.
 The Environmental Protection Act, 1986.
 The Industries (Development and Regulation) Act, 1951.
 The Minimum Wages Act, 1948.
 The Arunachal Pradesh Labour Laws.
 The Employees State Insurance Act, 1948.
 The Employees State Insurance General Regulations.

·

 The Employees State Insurance Central Rules.

<!-- page 5 -->

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025

5

2.

All Industrial Units must adhere to the norms specified by the State Pollution Control Board for
setting up of industry including Air, Water, Noise.

3.

A unit shall meet the requirement of employing minimum of 20% of APST in the Managerial Cadre
and minimum of 30% APST in the Non-Managerial cadre within 3 years from the date of commencement
of commercial production/operation. Employment Certificate shall be obtained from the competent
authority at the same time. The unit should follow the existing Labour Laws as regards to the
employment and wages in the unit.

4.

Industrial land allocated by the Department of Industries shall be utilized solely for the purpose for
which it will be allotted unless the approved line of activity is changed following due procedures.

5.5.

Discontinuation of Arunachal Pradesh Industrial and Investment Policy, 2020.

With effect from the date of notification of the Arunachal Pradesh Industrial Development and Investment
Policy, 2025, the existing Arunachal Pradesh Industrial and Investment Policy, 2020 shall be discontinued.
However, industrial units currently availing benefits under the existing policy shall continue to receive incentives
until the completion of their respective entitlement period.
Furthermore, industrial units registered under the existing policy and continuing to receive benefits
thereunder shall not be eligible for incentives or benefits under the Arunachal Pradesh Industrial Development
and Investment Policy, 2025.
5.6. Policy Duration:
The Arunachal Pradesh Industrial Development and Investment Policy, 2025 shall have a registration
period of three (03) years from the date of its notification, subject to the specific incentive periods prescribed
under Chapter-6 of the policy, unless the Government of Arunachal Pradesh extends the registration period.
5.7. Operational Guidelines:
The Operational Guidelines for the Arunachal Pradesh Industrial Development and Investment Policy, 2025
shall be notified separately by the Industries Department. These guidelines shall provide detailed procedures,
approval frameworks and regulatory provisions including checklists necessary for the effective execution of
the policy.
Chapter - 6
6.1. Lease Rent and Leasing Period:
The following lease rentals shall be applicable for Industrial Sheds and open spaces within Industrial
Estates, IGC and IIDC henceforth:
Sl. No.

Particulars

1.

Industrial shed

2.

Industrial Plots
(Open Space)

3.

Leasing Period

Rent
3.00 sq. feet per month. The maintenance of the shed will be borne
by the entrepreneur at their own cost / resources.
1.00 sq. meter per month.
Entrepreneurs/Investors shall be allowed to hold the land on lease
for a period of 33 years extendable by another 33 years as per
provisions of the Arunachal Pradesh (Land Settlement and
Records) Act, 2000(APLSR), read with relevant amendments from
time to time.
The State Cabinet vide its meeting held on 19th February, 2025 has
approved for bringing an amendment in the Arunachal Pradesh (Land
Settlement and Records) Act, 2000 (APLSR) where in the initial lease
period for setting up of industries in Government Industrial Land/
Growth Centres/ Estates/Parks shall be allowed for 50 years,
extendable by another 49 years.

4.

Leasing from private
landowners

Such lease will be governed under the provisions of Arunachal Pradesh
(Land Settlement and Records) Act, 2000 (APSLR) read with relevant
amendments from time to time.

6.1.1. Cancellation:
The Department of Industry reserves the right to cancel the allotted industrial land if the allottee does
not take necessary effective steps within the fixed period as per project milestones to establish the Industry
or all dues, rent, charges of the Authority have not been paid within time or unregistered product is manufactured
or any construction contrary to the approved plan or an activity injurious to industries has been engaged into
or if the unit remains non-functional for an extended period of time; the designated official with the approval of
Head of the Department of Industries (Pr. Secretary/ Commissioner/ Secretary) shall in such condition cancel
the allotted plot/shed and also forfeit the amount deposited in this connection.
The detailed provisions shall be provided in notified Operational Guidelines of the policy.
6.2.

Approval from Pollution Control Board:

The Annexures-V, VI, VII, and VIII categorize industries into White, Green, Orange and Red based on
pollution load, as per Government of India guidelines. White category industries are exempted from obtaining
an NOC from the Pollution Control Board before establishment; however, they must notify the Board prior to

<!-- page 6 -->

6

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025

commencing operations. Orange category industries (Annexure-VII) will be granted consent for 10 years. For
industries covered under the Environmental Impact Assessment (EIA) Notification dated 14th September 2006,
the prescribed time limits and conditions shall apply.
The validity of consent orders shall remain effective unless there is a change in the process, addition, or
removal of machinery, with the following validity periods:

6.3.

(a) Green Category of Industries

: 15 years (Annexure-VI)

(b) Orange Category of Industries

: 10 years (Annexure-VII)

(c) Red Category of Industries

: 5 years (Annexure-VIII)

(d) Management of Hazardous waste

: 5 years

Single Window System:

The implementation of the policy at the district level will be managed by the District Industries Centre,
with industry facilitators (Udyam Mitras) providing dedicated support in every district. An online Single Window
System will streamline the process of availing benefits under the State Industrial Policy, covering all stages
from registration to the disbursal of subsidies.
Chapter - 7
7.

Incentives package:

7.1

Stamp duty and Registration fee:

7.2.

1.

All Eligible New industrial units will be reimbursed 100% of the amount paid towards Stamp Duty
and Registration fees charged on the instrument of conveyance deed or lease deed. This
reimbursement will be admissible only after the date of commencement of commercial production/
operation. The subsidy will be applicable only to units that are allotted land in the Industrial Estates/
Parks/Growth Centres of Government of Arunachal Pradesh.

2.

The required land area for the unit must be clearly specified in the detailed project report (DPR) and/
or the bank appraisal report prepared by the bank or financial institution providing the term loan to
the unit.

Capital Investment Incentive:
1.

New units and those undertaking substantial expansion are eligible for this incentive. New Units with
investment between 5 lakh and 25 lakh in Plant and Machinery (for manufacturing sector) or
building/shed and all other durable physical assets (for service sector) will be provided Capital
Investment Incentive @ 50% of the cost of Plant and Machinery (for manufacturing sector) or for
construction of building/shed and installation of other durable physical assets (for service sector)
with a maximum limit of 15 lakh.
(a)

An additional 10% over the incentive value as deduced based on clause 1 will be provided to
units covered under the Priority Sectors, however, within the maximum limit under this category.
(Illustration: If the eligible investment amount is 25 lakh, the subsidy at 50% would amount
to 12.5 lakh. Additionally, if the unit falls under the priority sector, an extra 10% incentive on
the deduced subsidy, i.e., 1.25 lakh, will be provided. This results in a total incentive of
13.75 lakh).

(b)

An additional 10% over the incentive value as deduced based on clause 1 will be provided to
units employing at - least 50% (or 5 employees) of their skilled workforce from amongst APST/
permanent residents of Arunachal Pradesh, however within the maximum limit under this
category.
(Illustration: If the eligible investment amount is 25 lakh, the subsidy at 50% would amount
to 12.5 lakh. Additionally, if the unit employing at - least 50% (or 5 employees) of their skilled
workforce from amongst APST/ permanent residents of Arunachal Pradesh, an extra 10%
incentive on the deduced subsidy, i.e., 1.25 lakh, will be provided, bringing the total incentive
to 13.75 lakh. Furthermore, if the unit complies with both Clause (a) and Clause (b), the total
subsidy will be 15 lakh)

2.

New units and those undertaking substantial expansion are eligible for this incentive. New Units
with investment above 25 lakh and up to 50 lakh in Plant and Machinery (for manufacturing
sector) or building and all other durable physical assets (for service sector) will be provided Capital
Investment Incentive @ 50% of the cost of Plant and Machinery (for manufacturing sector) or for
construction of Building/shed and installation of other durable physical assets (for service sector)
with a maximum limit of 30 lakh.
(a)

An additional 10% over the incentive value as deduced based on clause 2 will be provided to
units covered under the Priority Sectors, however within the maximum limit under this category.
(Illustration: If the eligible investment amount is 50 lakh, the subsidy at 50% would amount
to 25 lakh. Additionally, if the unit falls under the priority sector, an extra 10% incentive
on the deduced subsidy, i.e., 2.5 lakh, will be provided. This results in a total incentive of
27.5 lakh)

<!-- page 7 -->

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025
(b)

7

An additional 10% over the incentive value as deduced based on clause 2 will be provided to
units employing at-least 50% (or 10 employees) of their skilled workforce from amongst APST/
permanent residents of Arunachal Pradesh, however within the maximum limit under this
category.
(Illustration: If the eligible investment amount is 50 lakh, the subsidy at 50% would amount
to
25 lakh. Additionally, if the unit employing at - least 50% (or 10 employees) of their
skilled workforce from amongst APST/ permanent residents of Arunachal Pradesh, an extra
10% incentive on the deduced subsidy, i.e., 2.5 lakh, will be provided, bringing the total
incentive to 27.5 lakh. Furthermore, if the unit complies with both Clause (a) and Clause (b),
the total subsidy will be 30 lakh).

3.

Subject to the definition of a New Unit under this policy a unit will be eligible for this incentive only if
it installs new plant and machinery (for manufacturing sector) or constructs new building/ shed and
installs other durable physical assets (for service sector) where purchases have been made based
on Arm's Length Pricing.

4.

An existing unit can avail this benefit for substantial expansion only once during the validity period
of the scheme.

5.

A new unit registered under the scheme will not be eligible to avail the benefits under substantial
expansion.

6.

Physical verification of the units is mandatory before availing this incentive.

7.3. Capital Interest Subvention:
1.

New Units will be eligible for the incentives, on the loan availed (from scheduled commercial banks
or financial institutions registered by Reserve Bank of India) on investment made in Plant and
Machinery (for manufacturing sector), or construction of building/shed and other durable physical
asset (for service sector). Existing units undertaking substantial expansion will also be eligible for
the incentive.

2.

All eligible units with investment between 5 lakh and 25 lakh in Plant and Machinery (for
manufacturing sector) or Building/ shed and all other durable physical assets (for service sector)
can avail Capital Interest Subvention (CIS) at the annual rate of interest of 6% for a maximum of five
(05) consecutive years from any date after the date of application for registration under this scheme
up-to a maximum limit of 10 lakh over the period of five (05) years. Units falling under the priority
sector within this category can avail this incentive at an annual rate of interest of 8% with a maximum
limit of 15 lakh with rest of the conditions remaining the same. However, disbursement of eligible
amounts under this incentive shall begin only after commencement of commercial production/
operation.

3.

All eligible units with investment above 25 lakh in Plant and Machinery (for manufacturing sector)
or building/ shed and all other durable physical assets (for service sector) can avail Capital Interest
Subvention (CIS) at the annual rate of interest of 5% for a maximum of five (05) consecutive years
from any date after the date of application for registration under this scheme up-to a maximum limit
of 20 lakh over the period of five (05) years. Units falling under the priority sector within this
category can avail this incentive at an annual rate of interest of 6% with a maximum limit of 25 lakh
with rest of the conditions remaining the same. However, disbursement of eligible amounts under
this incentive shall begin only after commencement of commercial production.
(a) With a view to availing incentive under the Capital Interest Subvention an eligible unit will be
liable to pay a minimum amount of interest at the annual rate of interest of 2%. The subvention
shall be adjusted accordingly from time to time. (Illustration: in case the annual lending rate by
a bank for an eligible unit falls to 5% the amount of interest subvention shall be limited to 3%
and the unit will bear 2% interest burden).
(b) The Capital Interest Subvention would be eligible on the amount disbursed and not on the
principal amount sanctioned for the term loan.

7.4.

(c)

A unit will be eligible for this incentive only if it installs new plant and machinery (for manufacturing
sector) or constructs new building or installs other new durable physical assets (for service
sector) where purchase has been made based on Arm’s Length Pricing.

(d)

A service sector unit with an investment of not less than 5 lakh in new building/shed and other
new durable physical assets will be eligible for this incentive.

Working Capital Interest Subvention:
1.

All existing and new eligible units in Arunachal Pradesh registered under GST will be eligible for this
incentive. Such units can avail interest subvention @ 5% on working capital loan (from scheduled
commercial banks or financial institutions registered by Reserve Bank of India) for a maximum of
five (05) consecutive years from the date of grant of registration under this scheme. Existing eligible
units availing benefits under this component will be eligible for a five (05) year’s period, even when
they are undertaking substantial expansion.
(a)

For availing incentive under the Capital Interest Subvention an eligible unit will be liable to pay
a minimum amount of interest at the annual rate of interest of 1%. The subvention shall be
adjusted accordingly from time to time. (Illustration: in case the annual lending rate by a bank
for an eligible unit falls to 5% the amount of interest subvention shall be limited to 4% and the
unit will bear 1% interest burden).

<!-- page 8 -->

8

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025
(b)

The maximum benefit under this component for manufacturing as well as service sector units
will be 50 lakh in five years and not exceeding 100% of investment in plant and machinery
(for manufacturing sector), or construction of building/shed and other durable physical assets
(for service sector).

(c) Incentive will be disbursed annually as a reimbursement upon submission of the annual interest
payment certificate from the bank.
7.5.

Green Incentives:

7.5.1. Incentive on Green Energy Generation
1.

Industrial units (New units and existing units irrespective of substantial expansion) willing to install green
and environmentally friendly technologies based on renewable energy sources such as solar/ wind/
water/ biomass/ hybrid solar-wind systems/ any other green energy source of 10KW to 2000 KW
capacity will be reimbursed @ 50% of cost on purchase and installation of green and environmentally
friendly technology, subject to a maximum amount of 25 Lakh. Existing units will be allowed to avail
the subsidy only in cases of replacement of DG Set for powering the industrial unit.

2.

The Subsidy amount will be provided in three instalments and shall be released after verification of
installation of green technology by joint team of officials designated by the Industries Department
and Power Department:
- 40% of subsidy amount shall be released after six months of installation
and operation.
- 40% shall be released after one year of installation and operation.
- 20% shall be released after two years of installation and operation of the technology in the
industrial unit.

7.5.2. Incentive on cost incurred on installation of Wastewater Recycling facility in the Industrial Unit:
Industrial units (New units and existing units irrespective of substantial expansion) willing to develop
infrastructure and facilities for wastewater recycling and waste management will be reimbursed @ 50% of
total expenditure incurred towards the procurement of technology, machinery and equipment subject to a
maximum amount of 2 lakh. The subsidy will not include expenditure on construction or civil works.
7.5.3. Incentive on Pollution Control devices:
Industrial units (only Existing units irrespective of substantial expansion) willing to install latest,
online monitoring and/or high-quality Pollution Control Device (PCD) in the manufacturing unit, will be reimbursed
@ 50% subsidy on the cost of purchase of equipment, subject to a maximum 10 lakh. The subsidy shall be
released only after a satisfactory commissioning report of the installed equipment from the Arunachal Pradesh
State Pollution Control Board.
7.5.4. Incentive on Procurement of Electric E-load Carriers:
The State shall provide financial assistance for the procurement of e-loadcarriers (excluding e-rickshaw)
to a maximum 100 units during the policy period. The selection of the beneficiaries shall be on a first come
first serve basis. This incentive will be available only to New Units. Financial assistance of upto 10% of
the ex-showroom price of the vehicle capped at 50,000, for procurement of e-loadcarriers having minimum
carrying capacity of 785 kg will be provided. The maximum No. of such carriers for which the incentive can be
claimed is one (1) per unit.
7.6. Power Subsidy:
1.

Manufacturing Units (Micro, Small, Medium Enterprises) will be eligible for Power Subsidy @ 2.00
per unit consumed from the date of Commercial Production subject to a maximum of 75 lakh Per
Annum for a period of five years and not exceeding 100% of the cost of total investment made in
Plant and Machinery whichever is less. This shall be available only to the Units having electricity
connections from 11 kV/33 kV transmission lines with the Department of Power, Government of
Arunachal Pradesh.

2.

Manufacturing units/Industries (Large scale Factories/ Bulk Electricity consumers) will be eligible
for Power Subsidy @ 1.00 per unit consumed from the date of commencement of commercial
production, for a period of 5 years and not exceeding 100% of total investment in plant and Machinery
whichever is less. This shall be available only to the Units having electricity connections from
132 kV or above transmission lines with the Department of Power, Government of Arunachal Pradesh
only.

3.

The Power subsidy will be in the form of remission/ front ended thereby meaning that the Power bills
raised against the Unit/Industry will be generated after deducting the Power Subsidy per unit. The
record of annual subsidy given against each Unit/ Industry shall be kept by the Power Department
and will be shared with the Department of Industries, Government of Arunachal Pradesh and
reconcile quarterly.

4.

Power subsidy shall be calculated on total unit consumed during the period at applicable rate per
unit and will be exclusive of all other charges, viz. Load security, interest, taxes, etc.

5.

Regular and timely payment to the Department of Power, Arunachal Pradesh is a prerequisite for
availing the subsidy under this policy.

6.

This subsidy will be available to New units or units undertaking substantial expansion.

<!-- page 9 -->

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025

9

7.7. SGST Reimbursement:
1.

The eligible units will be reimbursed 100% Net SGST (i.e. Gross SGST paid less Input Tax Credit)
for a period of 7 (seven) years from the date of commencement of commercial production.
Reimbursement of 100% Net SGST as per the following scale will be given:
Category

Limit of Tax Reimbursement

Micro Enterprises

7 (seven) years subject to maximum of 250% of the eligible amount of investment.

Small Enterprises

7 (seven) years subject to maximum of 200% of the eligible amount of investment.

Medium and Large
Enterprises

7 (seven) years subject to maximum of 180% of the eligible amount of investment.

2.

The benefit of tax reimbursement under the policy shall be subject to the condition that the unit after
having availed of the benefit shall continue its production or operation at least for the next five years
not below 70% of the average production for the preceding five years and, that no similar benefit
has been availed under any other scheme. In case the unit violates this condition, it shall be liable
to make, the full amount of tax availed of by it during the period of eligibility, as if no tax reimbursement
was ever available to it:
(a) Provided that the provision of this clause shall not come into play if the loss in production is
explained to the satisfaction of the authority concerned as being due to the reasons beyond
the control of the unit:
(b)

3.

Provided, further that a unit shall not be called upon to pay any sum under this clause without
having been given a reasonable opportunity of being heard.

This will be available to New Units or units undertaking substantial expansion.

7.8. VAT Exemption:
State Government shall provide 99% Sales Tax (VAT) exemption to eligible industrial units for a period of
7 years from the date of commencement of commercial production. This will be available to New Units or
units undertaking substantial expansion.
7.9. Reimbursement for using Common Facilitation Centres:
Industrial units (new units and all existing units irrespective of substantial expansion) and registered
cooperatives and FPOs will be incentivized with reimbursement @ 50% of cost incurred on utilizing any
recognized Common Facility Centre (Research Centre/Testing Lab facilities for R and D purposes/Packaging
etc.), subject to a maximum of one (1) lakh per unit per year for a maximum period of three years. Industrial
units and registered cooperatives and FPOs from the Handicraft, Handloom, Agro and Food processing and
Aromatic/ Medicinal plant sectors will be allowed to avail this incentive.
7.10. Assistance for access to Competitive, Innovation and Quality Control:
As product quality has a significant role in national and international markets, promoting world class
quality standards is one of the key objectives of this policy. Industrial units (New units and Existing units
irrespective of substantial expansion) willing to install in-house testing facilities and equipment and obtaining
quality certifications will be reimbursed at 35% on cost of such equipment or certification, subject to a
maximum amount of 5 lakh. The incentive shall be sanctioned only after a unit desiring to avail the same,
obtains a National/International quality mark certificate on the lines of GMP, ISO, SI, BIS, FPO, BEE, AGMARK,
ECOMARK, ZED Rating, GHP, GRIHA, LEED etc. The subsidy is not applicable for machinery or equipment
used directly in the manufacturing process or rendering of services.
7.11. Incentives to underprivileged sections of the society:
The Government of Arunachal Pradesh acknowledges its role of uplifting underprivileged sections of
societies by providing additional incentives over and above as provided to MSMEs:
 Reimbursement @ 95% consulting fee for preparation of DPR by ‘Consultants’ (as mentioned in
Chapter-4 - Definitions) upto maximum amount of one (1) lakh
 10% allotment of plots for the underprivileged sections in the Industrial Estates
 Applicability for these incentives will be limited to the following persons:
- Women Category: Single mothers and Widows
- Specially-abled category: 40% physical disability of vision, hearing or locomotive skills
7.12. Transport Subsidy (Air Freight):
Eligible industrial units (New units and Existing units irrespective of substantial expansion) will be
incentivized to compensate for the high cost of air-transportation of finished goods out of Arunachal Pradesh.
Air freight will be reimbursed @ 50% of freight amount for transportation of finished goods out of Arunachal
Pradesh to any destination within the country, subject to a maximum amount of 5 Lakh per year per unit for
a maximum period of five years. The subsidy will be claimable on an annual basis. Units will be allowed to
avail only one incentive out of the two subsidies - Transport Subsidy OR Export Subsidy (Incentive 7.13)
provided under this policy. However, for the transport of such finished goods, which may have a perpetual cost
disadvantage in markets out of Arunachal Pradesh due to factors such as perishability (by other modes of
transport) may be provided the subsidy till such limitations exist. The applicability of this subsidy beyond five
years will be considered for extension in the next policy period.

<!-- page 10 -->

10

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025

7.13. Incentive for Exports:
(a)

Industrial units (New units and Existing units irrespective of substantial expansion) will be
incentivized for export of finished goods from Arunachal Pradesh to a destination anywhere outside
of India, by reimbursement 60% of transportation cost upto the international port (air or sea) within
the country, subject to a maximum amount of 5 Lakh per year per unit for a maximum period of
five years. This incentive will be admissible only for units registered as export units. Units will be
allowed to avail only one incentive out of the two subsidies - Transport Subsidy (Incentive 7.12) OR
Export Subsidy provided under this policy.

(b)

Reimbursement of cost incurred for shipment of export samples to an overseas buyer (outside of
India), subject to a maximum amount of 50,000 per enterprise per year for two years. This
incentive will be admissible only for units registered as export units.
Annexure-I
EXISTING INDUSTRIAL ESTATES/ GROWTH CENTRES/ AREAS
The details of existing industrial infrastructure in the state are shown below: -

Sl.
No.

Name of
District
/DIC

Name of
available Industrial
Infrastructure

Total Area of
Industrial
Estate (in acre)

No. of
sheds

No. of
Plots

No. of
Vacant
Sheds
available

Vacant
open space
(in acre)

1

2

3

4

5

6

7

8

1.

Tawang

Tawang Industrial
Estate

7.08

2

151

NIL

0.49

2.

West
Kameng

(Tippi/ Bhalukpong)
Industrial Estate

26

3

26

NIL

NIL

Dirang Industrial Area

2

NIL

NIL

NIL

1.85

Dirang
(Near Powerhouse)

3

NIL

4

NIL

0.25

Wanghoo Industrial
Area

5.96

2

NIL

1

4.7

Pasighat Industrial
Estate

19

1

26

NIL

1

Industrial Growth
Centre,

354

6

143

3

206

Chandranagar
Industrial Estate

4

11

03

NIL

NIL

Naharlagun Industrial
Estate

8

19

11

NIL

NIL

Changlang Industrial
Estate

2.81

4

NIL

NIL

1.68

(Khachang (Miao)
Industrial Estate

5

2

0

2

4.96

Balinong Industrial
Estate (SEZ)

79.5

-

-

-

-

Namsai Industrial
Estate

1.59

2

0

NIL

0.902

10

3

5

1

0

3.916

NIL

26

NIL

NIL

6

5

1

2

4 Acre

2

1

NIL

0.4.

2

4

30 Acre

3.

East Siang

Niglok Ngorlung
4.

5.

Papum Pare

Changlang

6.

Namsai

7.

Lower
Roing Industrial Estate
Dibang Valley

8.

Lohit

Tezu Industrial Estate

9.

Tirap

Deomali Industrial
Estate
Charju Industrial Estate

0.4

(Damaged)

10.

Lepa Rada

IIDC, Bame

50

6

<!-- page 11 -->

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025

11
Annexure-II

INDUSTRIES AT A GLANCE
Sl. No.

Type of Industries

Nos. (Registered)

1

Large Scale industries

5

2

Medium Scale Industries (Manufacturing Enterprise)

16

3

Medium Scale Industries (Service Enterprise)

19

4

Micro and Small Enterprise

18,125

Total

18,165

*Source: Udyam Portal
INDUSTRIAL PROFILE (PRESENT)
Sl. No.

Industry Sector

Sl. No.

Industry Sector

1.

Weaving, Knitting & Tailoring

14.

Coke manufacturing

2.

Handicraft items including Carpet making,
Wood carving, Cane and Bamboo Furniture

15.
16.

Motor garage
Tourism Industry

3.

Wooden furniture

17.

IT enables services

4.

Bakery items

18.

Cyber cafe

5.

Rice milling

19.

Sawmill/ Saw-cum Veneer Mills

6.

Wheat grinding

20.

Plywood

7.

Fruit processing

21.

Wineries

8.

Food processing/Pickle making etc

22.

Steel Rolling Mill

9.

Steel furniture

23.

Ferro Silicon

10.

Steel Fabrication

24.

Dehydration ginger/cardamom

11.

Mineral water

25.

Printing Press

12.

Brick kiln

26.

Textile Industries

13.

Citronella Oil Distillation

27.

Agri/Horti and allied Industries
Annexure-III

Priority Sectors
 Food processing
 Industries based on non-timber forest produce e.g. bamboo, cane, medicinal plants / herbs, aromatic
grass, tea, coffee.
 Textiles, Arunachal Handlooms and Handicraft
 Tourism (tourism infrastructure including resorts, hotels, home stay, activities under adventure tourism)
 Coaching/Training and Skill development services under educational/employment/sports domain
 Industries in ODOP sector
 Industries in Geographical Indicators
 Commercial charging infrastructure for EVs


Pharmaceutical Industry

 Industries involved in Waste-to-Wealth activities
(The Priority Sectors mentioned above may be reviewed periodically to include other sectors of industrial
activities from time to time).
Positive List for Service Sector
The following industries will be applicable for incentives under this Policy:
(i)

IT and Electronics industry, Online Services, Film/Video Production and Music Studio based industry

(ii)

Commercial Green House for Floriculture/Agriculture/Horticulture

(iii)

Cold Storage/Controlled Atmosphere

(iv)

Hospitals/Medical Diagnostic Centre

(v )

Eco-Tourism Infrastructure/Activity (Trekking/Camping/Hiking etc.)

(vi)

Cable Car, Amusement/ Theme/ Leisure Park, Adventure Camps/Parks

<!-- page 12 -->

12

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025
(vii)

Hotel, Guest House and Resorts (New units shall be eligible only if they install solar panels for
water heating).

(viii)

Restoration of Heritage Property for commercial purposes

(ix)

Coaching/Training and Skill development services under educational/employment/sports domain

(x)

Maintenance and Repair Services (adhering to pollution control norms)

(xi)

Testing, R and D, Analysis and Certification Services

(xii)

Printing Services (Digital/Flex/Textiles etc.)

(xiii)

Replacement of fossil fuel-based car/taxi by EVs/Carbon neutral transportation aggregator with a
fleet size of minimum 10 e-vehicles.

(xiv)

Commercial charging infrastructure for EVs.

(xv)

All service sector industries covered under the Priority Sector under this policy.

(xvi)

Any other industry/activity notified by the Government of Arunachal Pradesh. It will be effective from
the date of such notification.
ANNEXURE-IV
Negative List

The following industries will not be eligible for benefits under Arunachal Pradesh Industrial Development
and Investment Policy, 2025
1.

All goods falling under Chapter 24 of the First Schedule to the Central Excise Tariff Act, 1985 (5 of 1986)
which pertains to tobacco and manufactured tobacco substitutes.

2.

Plastic carry bags of less than 20 micron as specified by Ministry of Environment and Forests Notification
No. S.O. 705 (E) dated 02.09.1999 and S.O. 698 (E) dated 17.6.2003.

3.

Goods falling under Chapter 27 of the First Schedule to the Central Excise Tariff Act, 1985 (5 of 1986)
produced by Petroleum or Gas refineries.

4.

Plantation, Refineries and Power generating Units (that are fossil-fuel based).

5.

Coke (including Calcined Petroleum Coke), Fly Ash.

6.

Units not complying with environment standards or not having applicable Environmental Clearance from
M/o Environment and Forests and Climate Change or State Environmental Impact Assessments Authority
(SEIAA) or not having requisite consent to establish and operate from the concerned Central Pollution
Control Board/State Pollution Control Board will not be eligible for incentive under the scheme.

7.

Low-value addition activities like preservation during storage, cleaning, operations, packing, repacking or
re-labelling, sorting, alteration of retail sale price etc. take place excluding high value packaging and
processing.

8.

Any other industry/activity placed in negative list through a separate notification as and when considered
necessary by the Government. It will be effective from the date of such notification.

9.

Gold and gold ore.

10. Molasses
ANNEXURE-V
List of White Category of Industries
Sl. No.

Industry Sector

1

2

1.

Assembly of air coolers/conditioners, repairing and servicing

2.

Assembly of bicycles, baby carriages and other small non motorizing vehicles

3.

Bailing (hydraulic press) of waste papers

4.

Bio fertilizers and bio-pesticides without using inorganic chemicals

5.

Biscuits trays etc from rolled PVC sheet (using automatic vacuum forming machines)

6.

Blending and packing of tea

7.

Block making of printing without foundry (excluding wooden block making)

8.

Chalk making from plaster of Paris (only casting without boilers etc. (sun drying/electrical oven)

9.

Compressed oxygen gas from crude liquid oxygen (without use of any solvents and by
maintaining pressure and temperature only for separation of other gases)

10.

Cotton and woolen hosiers making (Dry process only without any dying/washing operation)

<!-- page 13 -->

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025
1

13

2

11.

Diesel pump repairing and servicing (complete mechanical dry process)

12.

Electric lamp (bulb) and CFL manufacturing by assembling only

13.

Electrical and electronic item assembling (complete dry process)

14.

Engineering and fabrication units (dry process without any heat treatment/ metal surface
finishing operations/painting)

15.

Flavoured betel nuts production/grinding (completely dry mechanical operations)

16.

Fly ash bricks/block manufacturing

17.

Fountain pen manufacturing by assembling only

18.

Glass ampules and vials making from glass tubes

19.

Glass putty and sealant (by mixing with machine only)

20.

Ground nut decorticating

21.

Handloom/carpet weaving (without dying and bleaching

22.

Leather cutting and stitching (more than 10 machine and using motor)

23.

Manufacturing of coir items form coconut husks

24.

Manufacturing of metal caps containers etc

25.

Manufacturing of shoe brush and wire brush

26.

Medical oxygen

27.

Organic and inorganic nutrients (by physical mixing)

28.

Organic manure (manual mixing)

29.

Packing of powdered milk

30.

Paper pins and u Clips

31.

Repairing of electric motors and generations (dry mechanical process)

32.

Rope (plastic and cotton)

33.

Scientific and mathematical instrument manufacturing

34.

Solar module non-conventional energy apparatus manufacturing unit

35.

Solar power generation through solar photovoltaic cell, wind power and mini hydel
(less than 25 MW)

36.

Surgical and medical products assembling only (not involving effluent/emission generating
processes)
ANNEXURE-VI
List of Green Category of Industries

Sl. No.

Industry Sector

1

2

1.

Aluminum utensils from aluminum circles by pressing only (dry mechanical operation)

2.

Ayurvedic and homeopathic medicines (without boiler)

3.

Bakery /confectionery DG set of capacity 15 KVA to 1 MVA veneer/sweets products
(with production capacity <1tpd (with gas or electrical oven)

4.

Bi-axially oriented PP film along with metalizing operations

5.

Biomass briquettes (sun drying) without using toxic hazardous wastes

6.

Blending of melamine resins and different powder, additives by physical mixing

7.

Brass and bell metal utensils manufacturing from circles (dry mechanical operation without
re-rolling facility)

8.

Candy

<!-- page 14 -->

14

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025
1

2

9.

Cardboard or corrugated box/sheet and paper products (excluding paper or pulp manufacturing
and without using boilers)

10.

Carpentry and wooden furniture manufacturing (excluding sawmill) with the help of electrical
(motorized) machines such as electrical wood planner, steel saw cutting circular blade, etc.

11.

Cement products (without using asbestos/ boiler / steam curing) like pipe, pillar, Jafri, well ring,
block/tiles etc. (should be done in closed covered shed to control fugitive emissions)

12.

Ceramic color manufacturing by mixing and blending only (not using boiler and wastewater
recycling process)

13.

Chilling plant, cold storage and ice making

14.

Coke briquetting (sun drying)

15.

Cotton spinning and weaving (small scale)

16.

Dal Mills

17.

Decoration of ceramic cups and plates by electric fur

18.

Digital printing on PVC clothes

19.

Facility of handling, storage and transportation of food grains in bulk

20.

Flour mills (dry process)

21.

Glass, ceramic, earthen potteries, tile and tile manufacturing using electrical kiln or not
involving fossil fuel kiln

22.

Glue from starch (physical mixing) with gas/ electrically operated oven /boiler.

23.

Gold and silver smithy (purification with acid smelting operation and sulphuric acid polishing
operation) (using less or equal to 1 litre of sulphuric acid/ nitric acid per month)

24.

Heat treatment with any of the new technology like ultrasound probe, induction hardening,
Ionization beam, gas carburizing etc.

25.

Insulation and other coated papers (excluding paper or pipe manufacturing)

26.

Leather footwear and leather products (excluding tanning and hide processing except
cottage scale)

27.

Lubricating oil, greases or petroleum-based products (only blending at normal temperature)

28.

Manufacturing of pasted venners using gas fired boiler or thermic fluid heater and by sun
drying

29.

Oil mill Ghani and extraction (no hydrogenation/refining)

30.

Packing materials manufacturing from non-asbestos fibre, vegetable fibre yarn

31.

Phenyl/toilet cleaner formulation and bottling

32.

Polythene and plastic processed products manufacturing (virgin plastic)

33.

Poultry, Hatchery and Piggery

34.

Power looms (without dye and bleaching)

35.

Puffed rice (muri) (using gas or electrical heating system)

36.

Pulverization of bamboo and scrap wood

37.

Batching Plant/Ready mix cement concrete

38.

Reprocessing of waste cotton

39.

Rice mill (Rice hullers only

40.

Rolling mill (gas fired) and cold rolling mill

41.

Rubber goods Industry (with gas operated baby boiler)

42.

Sawmills

43.

Soap manufacturing (hand made without steam boiling/boiler)

44.

Spice grinding (upto-20 HP motor)

45.

Steel furniture without spray painting

<!-- page 15 -->

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025
1

15

2

46.

Sleeping and processing of grains

47.

Tyres and tube retreating (without boilers)

48.

Chilling plant and ice making without using ammonia

49.

CO2 recovery

50.

Distilled water (without boiler) with electricity as source of heat

51.

Restaurants and Hotels (upto 20 rooms and without boilers)

52.

Manufacturing of optical lenses (using electrical furnace)

53.

Mineralized/Packing drinking water

54.

Tamarind powder manufacturing

55.

Cutting, sizing and polishing of marble stone

56.

Emery powder (fine dust of sand) manufacturing

57.

Fly ash export, transport and disposal facilities

58.

Mineral stack yard/ Railway sidings

59.

Oil and gas transportation and disposal facilities

60.

Seasoning of wood in steam heated chamber

61.

Synthetic detergent formulation

62.

Tea Processing (without boiler)

63.

Automobile fuel outlet (Only dispensing)

64.

DG set of capacity 15 KVA to 1 MVA
ANNEXURE-VII
List of Orange Category of Industries

Sl. No.

Industry Sector

1

2

1.

Dismantling of rolling stocks (wagons/ coaches)

2.

Bakery and confectionery, units with production capacity> 1 TPD. (With ovens/ furnaces)

3.

Chanachur and laddoo from puffed and beaten rice (muri and shira) using husk fired oven

4.

Coated electrode manufacturing

5.

Compact disc computer floppy and cassette manufacturing / Reel manufacturing

6.

Flakes from rejected PET bottle

7.

Food and food processing including fruits and vegetable processing

8.

Jute processing without dyeing

9.

Manufacturing of silica gel

10.

Manufacturing of tooth powder, toothpaste, talcum powder and other cosmetic items

11.

Printing or etching of glass sheet using hydrofluoric acid

12.

Silk screen printing, sari printing by wooden blocks

13.

Synthetic detergents and soaps (excluding formulation)

14.

Thermometer manufacturing

15.

Cotton spinning weaving (medium and large scale)

16.

Almirah, Grill Manufacturing (Dry Mechanical Process)

17.

Aluminium and cooper extraction from scrap using oil fired furnace (dry process only)

18.

Automobile servicing, repairing and painting (excluding only fuel dispensing)

19.

Ayurvedic and homeopathic medicine

<!-- page 16 -->

16

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025
1

2

20.

Brickfields (excluding fly ask brick manufacturing using lime process)

21.

Building and construction project more than 20,000 sq. m built up area

22.

Ceramics and Refractories

23.

Coal washeries

24.

Dairy and dairy product (small scale)

25.

DG set of capacity>1MVA but < 5MVA

26.

Dry coal processing, mineral processing, industries involving ore sintering, pelletisating, grinding
and pulverization

27.

Fermentation industry including manufacture of yeast, beer, distillation of alcohol (Extra Neutral
Alcohol)

28.

Ferrous and Non-ferrous metal extraction involving different furnaces through melting, refining,
re-processing, casting and alloy making

29.

Fertilizer (granulation/formulation/blending only)

30.

Fish feed, poultry feed and cattle feed

31.

Fish processing and packing (excluding chilling of fishes)

32.

Forging of ferrous and non-ferrous metals (using oil and gas fired furnaces)

33.

Formulation/palletization of camphor tablets, naphthalene balls from camphor/naphthalene
powders

34.

Glass ceramics, earthen potteries and tile manufacturing using oil and gas fired kiln, coating
on glasses using cerium fluorides and magnesium fluoride etc.

35.

Gravure printing, digital printing on flex, vinyl

36.

Heat treatment using oil fired furnace (without cyaniding)

37.

Hot mix plants

38.

Hotels (21 - 99 rooms)

39.

Ice cream

40.

Industries engaged in recycling/reprocessing/recovery/reuse of Hazardous Waste under schedule-iv
of HW (M, H & TBM) rules, 2008 - Items namely- Paint and ink sludge/residues

41.

Industries engaged in recycling/ reprocessing/ recovery/reuse of Hazardous Waste under
schedule iv of HW( M, H and TBM) rules, 2008 - Items namely- Brass Dross, Copper Dross,
Copper Oxide Mill Scale, Copper Reverts, Cake and Residues, Waste Copper and copper
alloys in dispersible form, Slags from copper processing for further processing or refining,
Insulated Copper Wire, Scrap/copper with PVC sheathing including ISRl-code material namely
"Druid", Jelly filled Copper cables, Zinc Dross-Hot dip Galvanizers SLAB, Zinc Dross-Bottom
Dross, Zinc ash/Skimming arising from galvanizing and die casting operations, Zinc ash/
Skimming/other zinc bearing wastes arising from smelting and refining, Zinc ash and residues
including zinc alloy residues in dispersible from,

42.

Industry or processes involving foundry operations

43.

Lime manufacturing (using lime kiln)

44.

Liquid floor cleaner, blakhk phenyl, liquid soap, glycerol mono-stearate manufacturing

45.

Manufacturing of glass

46.

Manufacturing of iodized salt from crude/ raw salt

47.

Manufacturing of mirror from sheet glass

48.

Manufacturing of mosquito repellent coil

49.

Manufacturing of Starch/Sago

50.

Mechanized laundry using oil fired boiler

51.

Modular wooden furniture from particle board, MDF< swan timber etc. Ceiling tiles/ partition
board from saw dust, wood chips etc., and other agricultural waste using synthetic adhesive
resin, wooden box making (With boiler)

<!-- page 17 -->

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025
1

17

2

52.

New highway construction project

53.

Non-alcoholic beverages (soft drink) and bottling of alcohol/non-alcoholic products

54.

Paint blending and mixing (Ball mill)

55.

Paints and varnishes (mixed and blending)

56.

Ply-board manufacturing (including Venner and laminate) with oil fired boiler/thermic fluid
heater (without resin plant)

57.

Potable alcohol (IMFL) by blending bottling of alcohol products

58.

Printing ink manufacturing

59.

Printing press

60.

Reprocessing of waste plastic including PVC

61.

Rolling mill (oil or coal fired) and cold rolling mill

62.

Spray painting, paint baking, paint shipping

63.

Steel and steel products using various furnaces like blast furnace/open heart furnace/induction
furnace/arc furnace/submerged arc furnace/basic oxygen furnace/ hot rolling reheated furnace

64.

Stone crushers

65.

Surgical and medical products including prophylakhtics and latex

66.

Teflon based products

67.

Thermocol manufacturing (with boiler)

68.

Tobacco products including cigarettes and tobacco/opium processes

69.

Transformer repairing/ manufacturing (dry process only)

70.

Tyres and tubes vulcanization/ hot retreating

71.

Vegetable oil manufacturing including solvent extraction and refinery /hydrogenated oils

72.

Wire drawing and wire netting

73.

Dry cell battery (excluding manufacturing of electrodes) and assembling and charging of acid
lead battery on micro scale

74.

Pharmaceutical formulation and for R and D purpose (For sustained release/ extended release
of drugs only and not for commercial purpose)

75.

Synthetic resins

76.

Synthetic rubber excluding molding

77.

Cashew nut processing

78.

Coffee seed processing

79.

Parboiled

80.

Foam manufacturing

81.

Industries engaged in recycling/ reprocessing/ recovery/reuse of Hazardous Waste under
schedule iv of HW(MH&TBM) rules, 2008 - Items namely- Used Oil (As per specifications
prescribed time to time).

82.

Industries engaged in recycling/ reprocessing/ recovery/reuse of Hazardous Waste under
schedule iv of HW(MH&TBM) rules, 2008 - Items namely- Waste Oil (As per specifications
prescribed time to time).

83.

Producer gas plant using conventional up drift coal gasification (linked to rolling mills glass
and ceramic industry refectories for dedicated fuel supply)

84.

Tea processing (With Boiler)

85.

Katha manufacturing (with Boiler)

86.

Spice grinding (>20 HP motor)

<!-- page 18 -->

18

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025
ANNEXURE-VIII
List of Red Category of Industries

Sl. No.

Industry Sector

1

2

1.

Isolated storage of hazardous chemicals (as per schedule of manufacturing, storage of hazardous
chemicals rules, 1989 as amended)

2.

Automobile Manufacturing (integrated facilities)

3.

Bamboo ply manufacturing (with Boiler)

4.

Industries engaged in recycling/reprocessing/recovery/reuse of Hazardous Waste under
schedule-iv of HW (M, H and TBM) rules, 2008 - Items namely - Spent cleared metal catalyst
containing copper, Spent cleared metal catalyst containing zinc

5.

Manufacturing of lubricating oils, grease, and petroleum-based products

6.

DG Set of capacity > 5 MVA

7.

Industrial carbon including electrodes and graphite blocks, activated carbon, carbon blakhk

8.

Lead acid battery manufacturing (excluding assembling and charging of lead acid battery in
micro scale)

9.

Phosphate rock processing plants

10.

Power generation plant [except Wind and Solar renewable power plants of all capacities and
Mini Hydel power plant of capacity <25MW]

11.

Industries engaged in recycling/reprocessing/recovery/reuse of Hazardous Waste under schedule-iv
of HW (M, H & TBM) rules, 2008 - Items namely Spent catalyst containing nickel, cadmium,
zinc, copper, arsenic, vanadium, and cobalt

12.

Processes involving chlorinated hydrocarbons

13.

Sugar (excluding Khandsari)

14.

Fibre glass production and processing (excluding moulding)

15.

Firecrackers manufacturing and bulk storage facilities

16.

Industries engaged in recycling/reprocessing/recovery/reuse of Hazardous Waste under
schedule-iv of HW (M, H & TBM) rules, 2008 - Items namely - Dismantlers Recycling Plants Components of waste electrical and electronic assembles comprising accumulators and other
batteries included on list A, mercury-switches, activated glass cullets from cathode-ray tubes
and other activated glass and PCB-capacitors, or any other component contaminated with
Schedule-2 constituents (e.g. cadmium, mercury, lead, polychlorinated biphenyl) to an extent
that they exhibit hazard characteristics indicated in part C of this Schedule

17.

Milk processes and dairy products (integrated project)

18.

Phosphorous and its compounds

19.

Pulp and Paper (waste paper based without bleaching process to manufacture Kraft paper)

20.

Coke making, liquefaction, coal tar distillation or fuel gas making

21.

Manufacturing of explosives, detonators, fuses including management and handling activities

22.

Manufacturing of paints varnishes, pigments and intermediate (excluding blending/mixing)

23.

Organic Chemicals manufacturing

24.

Airports and Commercial Air Strips

25.

Asbestos and asbestos based industries

26.

Basic chemicals and electro chemicals and its derivatives including manufacturing of acid

27.

Cement

28.

Chlorates, per-chlorates and peroxides

29.

Chlorine, fluorine, bromine, iodine and their compound

30.

Dyes and Dye-Intermediates

31.

Health care establishment (as defined in BMW Rules)

32.

Hotels (Star Category or >100 rooms)

<!-- page 19 -->

The Arunachal Pradesh Extraordinary Gazette, April 9, 2025
1

19

2

33.

Industries engaged in recycling/reprocessing/recovery/reuse of Hazardous Waste under schedule-iv
of HW (M, H and TBM) rules, 2008 - Items namely - Lead acid battery plates and other lead
scrap/ashes/residues not covered under Batteries (Management and Handling) Rules, 2001.
(Battery scrap, namely: Lead battery plates covered by ISRI, Code word “Rais” Battery lugs
covered by ISRI, Code word “Rakes”. Scrap drained/dry while intact, lead batteries covered by
ISRI Code word “Rains”)

34.

Industries engaged in recycling/reprocessing/recovery/reuse of Hazardous Waste under schedule-iv
of HW (M, H & TBM) rules, 2008 - Items namely - Integrated Recycling Plants - Components
of waste electrical and electronic assembles comprising accumulators and other batteries
included on list A, mercury switches, activated glass cullets from cathode-ray tubes and other
activated glass and PCB-capacitors, or any other component contaminated with Schedule 2
constituents (e.g. cadmium, mercury, lead, polychlorinated biphenyl) to an extent that they
exhibit hazard characteristics indicated in part C of this Schedule

35.

Manufacturing of glue and gelatine

36.

Mining and ore beneficiation

37.

Nuclear power plant

38.

Pesticides (technical) (excluding formulation)

39.

Photographic film and its chemicals

40.

Railway locomotive workshop/Integrated road transport workshop/Authorized service centers

41.

Yarn / Textile processing involving any effluent/emission generating processes including
bleaching, dyeing, printing, and colouring

42.

Chlor Alkali

43.

Ship Breaking Industries

44.

Oil and gas extraction including CBM (offshore and on-shore extraction through drilling wells)

45.

Industry or process involving metal surface treatment or process such as pickling/electroplating/
paint stripping/heat treatment using cyanide bath/phosphating or finishing and anodizing/
enamellings/galvanizing

46.

Tanneries

47.

Ports and harbour, jetties and dredging operations

48.

Synthetic fibres including rayon, tyre cord, polyester filament yarn

49.

Thermal Power Plants

50.

Slaughter house (as per notification S.O.270(E) dated 26.03.2001) and meat processing
industries, bone mill, processing of animal horn, hoofs, and other body parts

51.

Aluminium Smelter

52.

Copper Smelter

53.

Fertilizer (basic) excluding formulation

54.

Iron and Steel (involving processing from ore/integrated steel plants) and or Sponge Iron units

55.

Pulp and Paper (waste paper based units with bleaching process to manufacture writing and
printing paper)

56.

Oil Refinery (mineral Oil or Petro Refineries), Petrochemicals Manufacturing (including processing
of Emulsions of oil and water)

58.

Pharmaceuticals

59.

Pulp and paper (Large-Agro+wood), Small Pulp and Paper (Agro based-wheat straw/rice husk)

60.

Zinc Smelter

61.

Distillery (molasses/grain/yeast based)

62.

Common treatment and disposal facilities (CETP, TSDF, E-Waste Recycling, CBMWTF, effluent
conveyance project, incinerator, solvent/acid recovery plant, MSW sanitary landfill sites, STP)

Saugat Biswas, IAS
Commissioner (Industries),
Government of Arunachal Pradesh,
Itanagar.

———
Published and printed by Directorate of Printing and Stationery, Naharlagun—211/2025-DoP-250+US (Industries)-30-4-2025.
