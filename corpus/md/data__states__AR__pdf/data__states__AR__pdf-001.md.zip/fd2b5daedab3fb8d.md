---
doc_id: "fd2b5daedab3fb8d"
source_url: "https://indarun.gov.in/htm/policies/IndPolicy_2020_notification.pdf"
ministry: "Industries Department, Arunachal Pradesh"
title: "(Gazette Notification 2020 copy)"
date: ""
pages: 19
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "4e0bb0f21fb39547"
---

<!-- page 1 -->

sa
Ge
a,
(3239
ahs
The Arunachal Pradesh Gazette
EXTRAORDINARY
PUBLISHED BY AUTHORITY
No. 51, Vol. XXVII, Naharlagun, Tuesday, February 11, 2020, Magha 22, 1941 (Saka)
GOVERNMENT OF ARUNACHAL PRADESH
DEPARTMENT OF INDUSTRIES
ITANAGAR
NOTIFICATION |
The 11th February, 2020
No. SIND-220/2019-20.— In exercise of the powers conferred under Clause (3) of the Article 246,
entry No. 24 in Seventh Schedule List - II, state List of the Constitution of India, the Governor of Arunachal
3 Pradesh is pleased to notify the “Arunachal Pradesh State Industrial and Investment Policy, 2020” in
the state as follows :
¢ PRELIMINARY
1. This shall come into force from 1st April, 2020.
2. TheArunachal Pradesh State Industrial and investment Policy, 2020 shall supersede all other Industrial
Policy published by the State Government in the past.
ARUNACHAL PRADESH STATE INDUSTRIAL AND INVESTMENT POLICY, 2020
CHAPTER-1
INTRODUCTION
1(1). NATIONAL CONTEXT :

Arunachal Pradesh, the largest Northeastern State of India, is endowed with plenty of natural resources,
which need to be harnessed for the development of the State. At present, the industrial growth in the State
is ata nascent stage despite enormous potential for industrial growth. Recently the Union Government has
given decisive push to manufacturing through a series of policy initiatives such as Make in India, Digital
India , Stand-up India, Start-up India and Skill India. The underlying thought of these initiatives is to
simplify the business environment, thereby paving way for attracting greater private investment flows from
both domestic and foreign investors to make India a leading manufacturing hub. In this context various
State Governments have spelt out their respective industrial / manufacturing/ investment policies in recent
times to give a boost to investment flow across their States. Accordingly, after due deliberations and taking
into consideration all issues relating to investments, enterprise development and industrial growth in the
State, the Arunachal Pradesh State Industrial and Investment Policy, 2020 has been formulated.

: 4 (2). OVERVIEW :

* Arunachal Pradesh - the "Land of the dawn-lit mountains", has a population of 13.84 lakh as per 2011
Census spread over an area of 83,743 sq. km., with a very low population density of 17 per sq km, much
lower than national average of 382 per sq km. Bordered by Bhutan to the West, Assam in the South, China
to the North and North-East and Myanmar to the East, the State is one of the most splendid and variegated
tribal areas of the country. The total length of international border is about 1628 km. It has inter-State
borders with Nagaland in East and South-East and Assam in the South. Literacy rate in Arunachal Pradesh
has seen an upward trend and is 65.38 percent as per 2011 population census. As vibrant is the land, so
are the people living in it. Arunachal population speaks above 50 dialects in total owing to the cultural
diversity, yet the official language is English. Hindi is a common binding force for the people of the state.
The State capital is Itanagar. Numerous tribes reside in the State, each following their own cultures and
traditions. Owing to difference in topographic and altitudinal aspect, the climatic conditions are different for
different regions. Three major climatic zones is recognized on the basis of broad generalization, viz., the
hot and humid sub-tropical area of foot-hills, the cooler and micro-thermal region of lesser Himalayas and
the cold climate in the upper region of the State.

<!-- page 2 -->

2 The Arunachal Pradesh Extraordinary Gazette, February 11, 2020
1(3). EXISTING INDUSTRIAL ESTATES/GROWTH CENTRES /AREAS :
The details of existing industrial infrastructure in the state are shown below:-
District /DIC Industrial Infrastructure of Industrial sheds sheds space
Estate (in acre)} avaible
[1] ettaele Sy Sanh lt 4imels bole A hei“?
eee eee are ey Te
industrial Estate
[ome mawriaen [7 |e | |
Niglok Ngorlung
ks gsc i
East
mm [gers ep |
Estate
eras | alae |
Industria Estate
ee: ies ee ee
Dibang Valley
a
tt 50.00 4 4 20
1(4). INDUSTRIES ATAGLANCE :
[S.No | TWpeotindustes ——SCSCSC~C~C~C~S*~*zN RNG —*d
A |
[2 [Meda Seale nasties Manaduingenemise) |__|
[8 [Medium Seaieinausties GovieoEnipre) [7d |
1(5). INDUSTRIAL PROFILE (PRESENT):
| wseroceetsmecrome [roe
Wood carving, Cane & Bamboo Furniture
[a:[ wendentmre ———*d I miee —
[5 Reemiing | 18. Sawn Sawaum Veneer is
fe Whestgindng |. Pwo |
[| Food processingPickiemakngets + 22 SteelRolingMl!
fe] Sects 8. Peron

<!-- page 3 -->

The Arunachal Pradesh Extraordinary Gazette, February 11, 2020 3
1 (6). The status of online filling of Udyog Aadhaar Memorandum (UAM) in respect of Arunachal
Pradesh as on 31st May 2019 is shown below.
UsoghedhaarRoge [Visto [Smal Wedhm
CHAPTER-2
VISION, OBJECTIVE AND STRATEGY OF THE POLICY
2(1) Vision and Objective of the Policy :

The State Government of Arunachal Pradesh has accorded top priority to industrial growth as a
means to mitigate poverty and unemployment. Arunachal Pradesh Industrial and Investment Policy aims to
establish state-of-the-art infrastructure, promote manufacturing and service sector, enhance inclusivity,
foster innovation and create employment opportunities across sectors. The state intends to be the most
preferred destination for investors by providing favourable business climate, excellent infrastructure, good
lawand order and peaceful industrial relations. The new industrial and investment policy focuses on creating
aconducive eco-system and paving way for sustainable industrial development.

The objectives of the Arunachal Pradesh State Industrial and Investment Policy, 2019 are as:~

(i) To work out new parameters especially for the development of MSME sector in the state based on
available local resources for the benefit of local rural youth.

(ii) To increase Gross State Domestic Product by way of facilitating growth of various economic

2 activities including Manufacturing and Service sectors.
. (ili) To create income & employment especially in the rural areas.

(iv) To encourage sustainable investment environment in the MSME sector in the State.

(V) To establish Arunachal Pradesh as a competitive investment destination, leveraging the potential
of the vast available area, picturesque & exotic locations and abundance of natural resources in
the state.

(vi) To increase the standard of living and prosperity among the people of Arunachal Pradesh by giving
them the opportunity for skilled and unskilled employment and to give special thrust on economic
activities based on local resources with an objective to create market for the local farmers.

(vii) To provide quality infrastructure for environmentally friendly industries. Create an integrated eco
system which nurtures skill development, entrepreneurship and private investment flows for job
creation.

(viii) To harness those sectors of economy where the state has a comparative advantage.

(ix) To create institutional mechanisms which are conducive for 'Ease of Doing Business' to create
business friendly environment.

(x) To create employment opportunities for both skilled and unskilled workforce.

(xi). To promote the:spirit of innovation and incentivize entrepreneurship among youth by providing

Z specific sector skills and needed capital.
2 (2) Strategy to achieve the vision and objective :
a |
The State Government will follow the following roadmap in achieving the mission :-
z * Create robust infrastructure- Upgrading the existing infrastructure, identifying infrastructural gaps
and developing new infrastructure.
* — Focus on key sectors: identify the key sectors/thrust area where Arunachal Pradesh has relative
strengths/advantages over others and build upon them.
* Ease of doing business: Bring reform measures and changes in laws/rules, single point clearance
system for industries.
* — Skilled manpower: Impart requisite skills to local youths and entrepreneurs and link them with the
industrial units.
* Promote Micro, Small and Medium Enterprises.
* Marketing 'Brand Arunachal Pradesh’ as a preferred investment destination.

<!-- page 4 -->

4 The Arunachal Pradesh Extraordinary Gazette, February 11, 2020
2(3) Thrust Areas :

Arunachal Pradesh has natural advantage in some sectors like Tourism, Hydro Power, Agriculture-
Horticulture Processing Sector, Textiles and Handicrafts, etc. It is true that the natural advantage being
possessed by the State has not been fully exploited for employment generation and improving the living
standard of the people. The following areas have been identified as key thrust areas which have huge
potential for growth in the state:-

* Food processing and Agro based industries
* Bio-Technology sector
¢ Agriculture-Horticulture Processing Sector
¢ Industries based on non-timber forest produce e.g. bamboo, cane, medicinal plants / herbs, aromatic
grass, tea, coffee, etc.
* Textiles (handlooms and power looms), Handicrafts and Sericulture.
* Tourism (tourism infrastructure including resorts, hotels, restaurants, etc.).
* Adventure tourism infrastructure.
* Forest based tourism ventures.
* Creative and Entertainment industry.
(The thrust areas mentioned above will be reviewed periodically to include other sectors of industrial
activities from time to time)
CHAPTER-3 z
DEVELOPING ENABLING INFRASTRUCTURE AND CREATING CONDUCIVE BUSINESS
ENVIRONMENT -

Infrastructure facilities are absolutely essential for industrial development of the State. As a result of
availability of quality infrastructure, industries get established with less capital investment and can function
without impediments. These infrastructure facilities assist in growth of business and industry along with
promoting fair competition. In addition to social development and generation of new employment opportunities,
it helps in attracting investment. Development of Industrial infrastructure has been identified as one of the
strategies to attract industries and investments in the State.

3(1). Enabling infrastructure: Upgrading the existing infrastructure, identifying infrastructural gaps
and developing new infrastructure :

One of the most important factors for industrial growth is robust enabling infrastructure. Without
robust infrastructure in the State, industries will find it difficult to operate. The focus of the Government will
be to create enabling infrastructure so that investors find it suitable to invest in the state. The following are
the key areas where the Government of Arunachal Pradesh will focus upon:-

3(1)(a) Land:

Availability of land is primary requisite for sustainable industrial development. Arunachal Pradesh has
avast area of 83,743 square kilometers which is highest in the North-East India. The following interventions
are proposed (envisaged) in the policy:

>  LeaseofLand: Private Individuals/Joint Ventures/Companies (investors from outside the state)

shall be allowed to enter into agreement with private owners/community owners for leasing of land
for a period of 99 (ninety nine) years to be renewed in every 33 years for commercial purposes.

> Ownership Rights : The Land Settlement and Records Act, 2002 of Arunachal Pradesh will be .

followed to pave way for ownership rights to legal occupants of land.

> — Identification of Land Banks in foothills : A Committee under each Deputy Commissioner of .

the district will be formed to:-

> Identify and acquire the vacant infrastructure (both of private individual or State Government) in

the district which will be made available to all potential investors by leasing out for 99 years
renewable every 33 years.

> — Identification of suitable land in foothill areas (private individual/ governmentowned) having good

road connectivity, water supply, electricity supply which will be acquired by the State Government
as per rates notified by the Land Management Department of the State Government.

> Deputy Commissioners will be empowered to convert up to 5 hectares of land into industrial area

in their respective districts.

> State Government will provide security to the industrial estates from its own cost.

|

<!-- page 5 -->

The Arunachal Pradesh Extraordinary Gazette, February 11, 2020 5
3(1)(b). Creation/Establishment of Industrial Estates in foothill areas :

Industrial Estates provide integrated facilities to the industries viz. power, water, sewerage, security,
etc. Suitable land for the establishment of Industrial Estates in foothill areas will be identified. Land will be
acquired by the Deputy Commissioner either through Land Acquisition process as per Jnum Land Regulation
1947/ Land Acquisition and Rehabilitation and Resettlement Act, 2013. Due care will be taken to identify
the patch of land which has approach road, proximity to water supply source and electricity for development.
3(1)(c). Connectivity:

To ensure access to markets and resources, there is a need of having good connectivity in the State.
There is a need to prioritize on important zones which have the potential to become industrial estates.
Priority will be accorded to the foothill districts of the state.

3(1)(d). Roadways:

Further with the development of road along Dibrugarh-Pasighat-Roing-Lohit-Namsai-Tezu under
Trans -Arunachal Highway, the entire foothill area will serve as a major hub for promoting industrial activities.
The entire stretch will be re-designated as Trans Arunachal Industrial Corridor and focus will be on development
of Mega Industrial Zones alongside the corridor.

3(1)(e). Railways :

Indian Railways is planning to heavily invest in Arunachal Pradesh covering the hilly areas with the
mainstream. Dedicated Industrial Corridor will be established alongside the Railway corridors for leveraging
the potential of rail connectivity as well as to increase industrial activities.

3(1)(f). Inland Waterway :
Inland Water Authority of India is doing a survey to identify the suitable routes on Dibang river, Siang
i s river and Subansiri river for starting Inland Waterways in the State. This will provide a cheap way of
transportation of goods from the State to outside.
e 3(1)(g). Power:

One of the most important factor for growth of Industries is the availability of quality uninterrupted
power supply. Separate feeders and lines will be provided to the Industrial Estates by the State Government.
Priority will be given in installing feeders for Industrial Estates.

3(1)(h). Water :

Water will be made available to the industrial areas on priority basis. Further, Industrial estates will be
allowed to use ground water subject to the rules prescribed. Rainwater harvesting will be promoted by the
State Government.

3(1)(i). Lease Rent & Leasing Period :

The following lease rentals shall henceforth be applicable for Industrial Sheds and open space within
Industrial Estate/IGC/IDC:-

SA

1. | Industrial shed % 3.00/sq. feet per month. The maintenance of the shed will

be borne by the entrepreneur himself at their own cost/esources.
Industrial Plots (Open % 1.00/sq. meter per month.
Space)
Leasing Period Entrepreneurs/Investors shall be allowed esources. to hold the
land on lease for a period of 50 years renewable every 10 years.
Leasing from private Private Land owners, with valid owner-ship documents shall be
fandowners free to enter into longterm lease agreements duly registered with
- the Deputy Commissioner for industrial application. Such lease
shall be in the name of a duly registered company and holding
. valid GST registration documents. The land owner in such cases
can secure a Trade license on the basis of such alease agreement,
clearly stipulating the nature of industrial activity proposed.
3(2). Creating Conducive Business Environment :

Government of Arunachal Pradesh has accorded highest priority for improving business eco-system
in the state, itis imperative to create an environment which is conducive for entrepreneurship development.
Industry consultation, timely clearances, responsive administration and transparent government have been
identified as the cornerstone for improving business environment and boosting investor's confidence. The
following steps have been/shall be taken by the Government of Arunachal Pradesh.

3(2)(a) Ease of Doing Business (EoDB)- Single Window System :

The need to launch an industrial policy has been necessitated to overcome the hurdles being faced by
the industries at present and to supplement and augment the existing growth pattern through sustainable
policy measures.

<!-- page 6 -->

6 The Arunachal Pradesh Extraordinary Gazette, February 11, 2020

in this backdrop, a single window system for clearances / approval / license / permission / industrial
services will be set up in the Department of Industries. The following will be the features of Single Window
Clearance Station / Cell:

> The investor shall be facilitated to file all applications related to project at one point.

>»  ASingle Window Clearance Portal will be created which will act as an interface between industries
and all the departments.

> Details of procedures and formats for various approvals will be placed on the portal for easy reference
of investor. Single Desk Portal to help industries to obtain as many regulatory clearances required
to set-up and operate business in the State.

> The cell will also become a repository of information regarding the State infrastructure, information
about investment application processes and issues being raised across the industry.

> Additionally, this cell will also feed into a platform for information dissemination and will provide
additional information related to orders, rules & regulations.

>» Coordination with the relevant departments and required updates will be provided to the investors
through this System.

>  ADistrict Level Committee will be constituted under the Chairmanship of Deputy Commissioner
which will periodically review the status of pending applications with single window system with
the concerned departments.

3(2)(b) Investment Advisory Council :

The Government of Arunachal Pradesh will constitute an Investment Advisory Council by engaging _
professionals from across the country to advise the Government in leveraging investment in the State. The
Investment Advisory Council will serve as an Advisory Body of the Government of Arunachal Pradesh for
identifying private investment in sectors of strategic growth and preparing a framework for consultation in
relation to skill development, infrastructure development and entrepreneurship development in the State. It
will advise the Government of Arunachal Pradesh on issues of the industrial development policy, regulatory
issues and help to develop a strategy for attracting investment including national and international road
shows. The Composition of the Investment Advisory Council will be as follows:-

[Sino [7 Pariairs Siero
Hon'ble Chief Minister of Arunachal Pradesh
Hon'ble Minister of Industries
|_3 [cies Secretary
Commissioner/Secretary (Finance) | Member
5 | Principle Secretary (Environment and Forests) [ Member
|_6 _[Commissioner/Secretary Power)
Commissioner/Secretary (Textile and Handicraft [Member |
| a | Commissioner/Secretary (Skill Development)
|_9 | CommissioneriSecretary (Tourism)
| 10 | Commissioner/Secretary (Agriculture & Horticulture)
Commissioner/Secretary (Tax & Excise)
Commissioner/Secretary (Labour and Employment)
Commissioner/Secretary (Planning and Investment) | Member
Member Secretary (Pollution Control Board) =
Commissioner/Secretary (Industries) Member Secretary
Director of Industries

17 Expert / Eminent persons to be engaged by Member

the Government of Arunachal Pradesh

3(2)(c) Investment Facilitation Committee :

The State Government shall constitute an investment Facilitation Committee under the Chairmanship
of Chief Secretary for taking concrete measures for creating conducive environment for investment in the
State which would help in enhancing Ease of Doing Business (EoDB). The mandate and terms of reference
of this Committee will be to act as a single window clearance mechanism for all regulatory approvals
including labour, pollution, forest, power, land, etc. All investment proposals above @ 5 (five) Crore capital
investment will be brought before this committee for clearance within 30 (thirty) days.

<!-- page 7 -->

The Arunachal Pradesh Extraordinary Gazette, February 11, 2020 7
|__1 | chief Secreta
|__2 | Development Commissioner (FPal
Principie Secretary (Forest and Environment)
| 6 | Commissioner/Secretary (Land Record & Management)
Commissioner Secretary (Health)
|__8 | CommissionerSecretary (Tourism)
| 9 | Commissioner/Secretary (Geology and Mining
Commissioner/Secretary (Agriculture & Horticulture)
Commissioner/Secretary (Tax & Excise) | Member
Member Secretary (Pollution Control Board)
Commissioner/Secretary (Tax & Excise) [Member
Commissioner/Secretary (Industries) Member-Secretary
Director of Industries | Member

Expert / Eminent persons to be engaged by Member
the Government of Arunachal Pradesh
c 3(3) Approval from Pollution Control Board :

The Annexure at II, lll, IV and V provide the list of various industries categorized as White, Green,
Orange and Red (Re-categorization of industries based on their pollution load by the GOI). The prospective
investors in the category of White and Green category need not go through the process of obtaining NOC
from the Pollution Control Board before the industry is set up however they shall notify of their activity to the
Pollution Control Board before setting up the industry.

The Orange category of industries specified in Annexure-IV will be granted consent for a period of 10
(ten) years.

In case of industries covered by the Environment Impact Authority Notification dated 14th September
2006, the time limit and other conditions specified therein will be followed.

The validity of the consent orders as long as there is no change in the process and addition/deletion
of machinery will be as follows :-

(a) White Category Industries : 15 years (Annexure-ll)
(b) Green Category of Industries : 15years (Annexure-lil)
(c) Orange Category of Industries : 10 years (Annexure-lV)
(d) Red Category of Industries : 5years (Annexure-V)
(e) Management of Hazardous waste : 5 years
CHAPTER-4
| INCENTIVES
E Under this policy the State Government of Arunachal Pradesh will provide following incentives/subsidies
in addition to incentives provided by Government of India:
- 4(1) State Capital Investment Subsidy :

All eligible new industrial units in the manufacturing and service sector located anywhere in Arunachal
Pradesh will be provided State Capital Investment Subsidy @ 30% on the cost of the investment in plant
and machinery with an upper limit of ¥ 50 Lakhs. The incentive/subsidy shall be claimed within 5 years from
the date of commercial production.

4(1.a) Special Provision to Promote Women Entrepreneurship :

In order to encourage women entrepreneurs in the State, State Capital Investment Subsidy @ 50% on
the cost of the investment in plant and machinery with an upper limit of € 75 Lakhs will be provided. The
incentive/subsidy shall be claimed within 5 (five) years from the date of commercial production/operation.
4(2) State Interest Subsidy :

All eligible new industrial units located anywhere in Arunachal Pradesh shall be given an interest
subsidy on term loan taken from the bank for plants and machinery.The incentive/subsidy shall be given to
an eligible enterprise for 5 (five) years from the date of commercial production, provided term loan is repaid
as per terms and conditions of taking such financial assistance from the banks:

<!-- page 8 -->

8 The Arunachal Pradesh Extraordinary Gazette, February 11, 2020
[unit Interest subsidy
Micro Enterprises reimbursement of interest of up to 80 % of annual interest on the loan
taken, subject to a maximum ceiling of 7 5 lakhs per annum.
Small enterprises reimbursement of interest of up to 50% of annual interest on the loan taken,
subject to a maximum ceiling of = 15 lakhs per annum.
Medium enterprises reimbursement of interest of up to 50% of annual interest on the loan taken,
subject to a maximum ceiling of = 20 lakhs per annum.
Non MSME sector unit reimbursement of interest of up to 50% of annual interest on the loan taken,
subject to a maximum ceiling of = 25 lakhs per annum.
4(2.a) Interest Subsidy on Working Capital Loan:

All eligible new industrial units located anywhere in Arunachal Pradesh shail be given an interest
subsidy @ three percent ( 3% ) on the outstanding working capital loan for five years subject to a ceiling of
1 Crore and not exceeding 100% of investment in plant and machinery. Interest subsidy shall be available
only on outstanding working capital loan availed from Bank/Financial Institution.

4(3) Power subsidy :

State Government will arrange power supply to all Industries, Industrial Parks, etc adequately as per
their requirement and assured quality power to the industries. State Government will also encourage
investment in generation of power in both conventional and non-conventional and provide all necessary
assistance to the investors in power sector.

(i) Manufacturing Units (Small, Medium Enterprises) will be eligible for Power Subsidy @% 2.00 per

‘i unit consumed from the date of Commercial Production subject to a maximum of & 75 lakhs Per
Annum for a period of five years and not exceeding 100% of total investment made in Plant &
Machinery, whichever is less. This shall be available only to the Units having electricity connections "
from 11 kV/ 33 kV transmission lines with the Department of Power, Government of Arunachal
Pradesh only.

(ii) Manufacturing Units/ Industries (Large Scale Factories/ Bulk Electricity Consumers) will be eligible
for Power Subsidy @1.00 per unit consumed from the date of Commercial Production subject to
a maximum of % 2 Crore Per Annum for a period of five years and not exceeding 100% of total
investment in Plant & Machinery, whichever is less. This shall be available only to the Units
having electricity connections from 132 kV or above transmission lines with the Department of
Power, Government of Arunachal Pradesh only.

(iii) ~The Power subsidy will be in the form of remission/ front ended thereby meaning that the Power
bills raised against the Unit/ Industry will be generated after deducting the Power Subsidy per
unit. The record of annual subsidy given against each Unit/ Industry shall be kept by the Power
Department and will be shared with the Department of Industries, Government of Arunachal Pradesh
and reconcile quarterly.

(iv) Power subsidy shall be calculated on total unit consumed during the period at applicable rate per
unit and will be exclusive of all other charges, viz. Load security, interest, taxes, etc.

(v) Regular and timely payment to Department of Power, Arunachal Pradesh is a pre-requisite for |
availing the subsidy under this policy.

4(4) Stamp duty and Registration fee :

All eligible new industrial units shall be reimbursed or exempted from payment of Stamp Duty up to
50% of the subject to a monetary ceiling of = 25 lakh. The Stamp Duty reimbursement or exemption shall
not be available for agricultural land. It shall be available only for such parcel of land which is exclusively
used for setting up of manufacturing facilities. In case of units run by women entrepreneur, 100 % exemption
for payment of stamp duty will be provided. *
4(5) Quality Certification subsidy :

The fee payable for obtaining BIS/ISO/FSSAI/AGMARK/HALLMARK/SILK MARK/ZED Certification etc.
by eligible unit, will be provided subsidy up to the extent of 100% subject to a ceiling of ¥ 20 lakhs per unit.
4(6) SGST exemption :

The eligible units will be exempted 100% SGST for a period of 15 (fifteen) years from the date of
commencement of commercial production. Reimbursement of 100% SGST as per the following scale will
be given:

Category Limit of Tax Reimbursement
15 (fifteen) years subject to maximum of 250% of Fixed Capital Investment.
Small Enterprises 15 (fifteen) years subject to maximum of 200% of Fixed Capital Investment.
Medium and Large 15 (fifteen) years subject to maximum of 180% of Fixed Capital Investment.
Enterprises

<!-- page 9 -->

The Arunachal Pradesh Extraordinary Gazette, February 11, 2020 9

The benefit of tax reimbursement under the policy shall be subject to the condition that the unit after
having availed of the benefit shall continue its production or operation at least for the next five years not
below 70% of the average production for the preceding five years. In case the unit violates this condition, it
shall be liable to make, the full amount of tax availed of by it during the period of eligibility, as if no tax
reimbursement was ever available to it:

Provided that the provision of this clause shall not come into play if the loss in production is explained
to the satisfaction of the authority concerned as being due to the reasons beyond the control of the unit:

Provided, further that a unit shall not be called upon to pay any sum under this clause without having
been given reasonable opportunity of being heard.

4(7) Public Procurement/Purchase Preferences :

In order to promote ‘Make in Arunachal’, the State Government and other State controlled Bodies
and Organizations will give preference to the registered Units/ Enterprises of the State while purchasing the
manufactured products.

4(8) Strengthening of District Industries Centres (DICs) :

The State Government will strengthen and modernize the DICs. The DIC will be armed with Udyog
Sahayak Cell to guide the entrepreneurs and helping them in selection of product, preparation of project
report and obtaining credit for the project. A data bank covering all aspects of information sought by investors
will also be maintained in DiCs.

CHAPTER-5
DEFINITIONS
5(1) Scheme title :

The scheme may be called "Arunachal Pradesh State Industrial and Investment Policy, 2020"

¥ 5(2) Coverage :

The scheme will cover State of Arunachal Pradesh.

5(3) Commencement and duration :

The policy/scheme will come into effect from the 01/04/2020 and shall remain in force up to 31/03/
2025 or till such time as the Government may deem fit and proper. The State Government reserves the right
to make any amendments to the Scheme. All eligible new units which commence commercial production

| within the period of validity will be eligible for the incentives from the date of commencement of commercial
production for the period applicable for each incentive.
5(4) Definitions :

(i) New unit/New Industrial Unit means any industrial undertaking or eligible service sector unit,
other than that run departmentally by Government, which is a registered business enterprise under
Goods & Services Tax, which has commenced commercial production/operation in the State of
Arunachal Pradesh during the validity period of Arunachal Pradesh Industrial & Investment Policy,
2020.

{ii) Micro, Small and Medium units mean investment in Plant and Machinery upto % 25 lakhs,
above f 25 lakhs below 5 crores & above % 5 crores and below 710 crores respectively.

(iii) Large unit means investment in plant and machinery above Z 10 crores.

(iv) Local tribal means local populace recognized by the Government of Arunachal Pradesh.

(v) Women Entrepreneur / Women run enterprises means units where major shareholder is a
woman (more than 50% of the share of the company/firm/LLP).

(vi) Manufacturing Activity means "an activity which brings about a change in non-living physical

. object or article or thing (i) resulting in transformation of the object or article or thing into a new and
distinct object or article or thing having a different name, character and use; or (ii) bringing into

i existence of a new and distinct object, article or thing with a different chemical composition or
integral structure".

(vii) Eligible Service Sector Unit is an enterprise in the services sector that requires significant
capital expenditure and has significant employment generation potential.

(viii) Physical Working Capital is defined to include all physical inventories owned, held or controlled
by the factory as on the closing day of the accounting year such as the materials, fuels & lubricants,
stores etc., that enter into products manufactured by the factory itself or supplied by the factory to
other for processing. Physical working capital also includes the stock of materials, fuels & stores
etc., purchased expressly for re-sale, semi-finished goods and work in progress on account of
others and goods made by the factory which are ready for sale at the end of the accounting year.
However, it does not include the stock of the materials, fuels, stores etc. supplied by others to the
factory for processing. Finished goods processed by others from raw materials supplied by the
factory and held by them are included and finished goods processed by the factory from raw
materials supplied by others are excluded.

<!-- page 10 -->

10 The Arunachal Pradesh Extraordinary Gazette, February 11, 2020

(ix) Raw Material means any raw material actually required and used by an industrial unit in
manufacturing of the finished goods for which it is requested.

(x) Working Capital is the sum total of the physical working capital and the cash deposits in hand
and at bank and the net balance of amounts receivable over amounts payable at the end of the
accounting year. Working capital, however, excludes unused overdraft facility, fixed deposits
irrespective of duration, advances for acquisition of fixed assets, loans and advances by proprietors
and partners irrespective of their purpose and duration, long term loans including interest thereon
and investments. ,

(xi) Fixed Capital Investment means an investment made in building, plant and machinery as well as
productive assets of permanent nature such as tools, jigs, fixtures, dyes, crane, electrification, etc.

(xii) "Plant and Machinery’ shall cover the cost of newly purchased industrial plant and machinery
as erected at site. Relocated / Recycled / Refurbished plant and machinery is not eligible for
assistance under the Scheme. Components to be included / excluded for the purpose of scheme
and for a manufacturing unit are at Annexure ll. The purchase of machinery should be from open
market at normal market price.

(xji)(a) ‘Plant and Machinery’ in respect of Tourism Sectors (Hotels/SPA unit/Tourism Project!
Amusement Park) and Entertainment Sector (Film Studio/Film City/Acoustic Auditorium):
The cost of construction of building (excluding land) and all the items/components/equipments
except consumables and disposables which are basic to the running of the tourism projects will
be taken in to account for computing the value of Plant & Machinery. Hired/rented Building will
not be taken into account.

(xdi)(b) Definition of ‘Plant and Machinery’ in respect of Health sectors (Nursing Home and
Super-speciality Health Care) : The cost of construction of building (excluding land) and all |
the items/components/equipments relating to emergency services, general surgery, maternity : |
facilities, pathology, radiology, E.C.G., except consumables, disposables and ambulances which |
are basic to the running of the Health unit will be taken in to account for computing the value of .
Plant & Machinery. Hired/rented Building will not be taken into account.

(xii)(c). ‘Plant and Machinery’ in respect of Educational sectors (Vocational Training Centre/
Schools/Colleges) and IT & IT related service industries (Call centre) : The cost of
construction of building (excluding land) only necessary for running of the unit will be taken in to
account for computing the value of Plant & Machinery. Hired/rented Building will not be taken into
account.

(xii)(d). "Plant and Machinery’ in respect of Power Generating Plant :

In calculating the value of Generating Plant and Machinery of a Power Station, the cost of Plant

and Machinery as erected at site and required for plan operation will be taken in to account
which will include the cost of main plant, any building associated systems, auxiliary equipment
and tools but excluding the cost of land. The amount invested in dam & reservoir regulating
system (hoists and gates etc.) head and tail water conductor system or EOT crane or other
appurtenant equipment if any, will be taken into account where electricity is generated by using
water power in a power generating unit. Working capital including cost of raw material/fuel and
other consumables will be excluded for computing the value of Plant & Machinery.

(xiii) Eligibility Criteria :

(a) All New Units/New Industrial units except those in Annexure-1 shall be eligible under
the Arunachal Pradesh State Industrial & Investment Policy, 2020.

(b) Aunit shall have employment of minimum of 20% people of Arunachal Pradesh in the
Managerial cadre and minimum of 30 % people of Arunachal Pradesh in the Non-Managerial
cadre. Employment certificate shall be obtained from the competent authority at the same
time the unit should follow the existing Labour Laws as regards to the employment and ‘
wages in the unit.

(c) Incentives/ Subsidies/ Concessions/ Financial support under this policy shall be applicable -
to units in the Private Sector, Joint Sector, Co-operatives, Partnership firm, Proprietorship
Self-help Group (SHG), Trust and Non-Government Organization (NGO). The unit set up by
State Government and Central Public Sector undertakings shall not be eligible for any
incentives under the Policy.

(d) The units which are functional at the time of disbursement of subsidy will be eligible for
subsidy/incentive.

(e) Noright or claim for any incentive under the policy shall be deemed to have been conferred
by the policy merely by virtue of the fact that the unit has fulfilled on its part the conditions
of the policy and the incentives/subsidies cannot be claimed as a matter of right.

(f) Any payments made in cash for any transaction shail be treated as ineligible amount for
investment.
