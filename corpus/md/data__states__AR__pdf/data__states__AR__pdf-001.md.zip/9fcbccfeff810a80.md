---
doc_id: "9fcbccfeff810a80"
source_url: "https://cdn.s3waas.gov.in/s3076a0c97d09cf1a0ec3e19c7f2529f2b/uploads/2025/11/17637217385523.pdf"
ministry: "Anjaw"
title: "MCC ORDER"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "02f5e2b14bddf29d"
---

<!-- page 1 -->

— GOVERNMENT OF ARUNACHAL PRADESH
OFFICE OF THE DISTRICT ELECTION OFFICER (PR)
ANJAW-DISTRICT :: HAWAI
No. ANJ/PR/ELN-09/2025 Dated Hawai the 21%* November’2025
ORDER

In pursuance to the notification of State Election Commission, Arunachal
Pradesh vide No. AP/SEC-662/2024/9594 dated 17/11/2025, to the Panchayati Raj
Election’2025 in all the constituencies of 01-Hayuliang Goiliang/ 02- Chaglagam/ 03-
Manchal/04-Hawai North and 05-Hawai South ZP and Gram Panchayat of Anjaw
District, the Model Code of Conduct has come into force with immediate effect from
the date of declaration of election.

All the political parties/Government servants/Contesting candidates/Govt.
agencies and Public Sector undertakings are directed to strictly adhere to the Model
Code of Conduct issued by the State Election Commission.

No payment or holding of any kind of tender by Central or State Govt. or any
public undertakings shall be allowed till the completion of election process.

Any violation of Model Code of Conduct will attract punishment under relevant
section of Law. Mgr.

(millo Kahl, orfices PP
District Electidir Officer(PR)
Memo. No. ANJ/PR/ELN-09/2025 Dated Hawai the 21% November’2025
Copy to:- hans. 38

1. The State Election Commission, Itanagar, Arunachal Pradesh for kind |

information please.

2. The Secretary to SEC, Govt. of Arunachal Pradesh, Itanagar for kind

information please.

3. The Secretary (Law), Govt of Arunachal Pradesh, Itanagar for kind

information please.

4. The Superintendent of Police, Anjaw District , Hawai for information and

necessary action.
5. The ADC, Hayuliang for information and necessary action.
6. The Circle Officer, Hayuliang/ Goiliang/ Mateliang/ Chaglongam/ Manchal/
Hawai/ Walong/ Kibithoo for information and necessary action.

7. The R.O/ARO 01-Hayuliang Goiliang/ 02- Chaglagam/ 03-Manchal/04-Hawai
North and 05-Hawai South ZP Constituency for information and necessary
action .

8. All Sector Magistrates/Sector Officers, Anjaw District for information.

9. All HoDs, Anjaw District for information.

10. All Political Parties for compliance.

11. The DIPRO, Anjaw District for information and wide publicity.

12.The DIO, Anjaw District for information and directed to upload the order

copy in official web portal of Anjaw District.

13. The Branch Manager, SBI, Hawai/ Hayuliang for information.

14. Notice Board, DC’s /DPDO Office Hawai. Aber.

(millo <M Yoefon Diticer (PA)
District Election Qfficer(PiR}. Hawai
Anjaw-District ahaveatial Pradesh
C scanned with OKEN Scanner
