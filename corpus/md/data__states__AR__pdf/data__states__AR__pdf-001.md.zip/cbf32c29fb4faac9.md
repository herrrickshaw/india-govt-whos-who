---
doc_id: "cbf32c29fb4faac9"
source_url: "https://cdn.s3waas.gov.in/s39b70e8fe62e40c570a322f1b0b659098/uploads/2025/04/2025042324.pdf"
ministry: "Tawang"
title: "NOTIFICATION. INDIAN AIR FORCE AGNIVEERVAYU"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "41db69d4e3ae5ead"
---

<!-- page 1 -->

l

cJTY ~ INDIAN AIR FORCE
JOIN INDIAN AIR FORCE AS AN AGNIVEERV AYU
INDIAN AIR FORCE INVITES UNMARRIED INDIAN MALE AND FEMALE CANDIDATES TO APPEAR IN
PRE-REGISTERED RECRUITMENT RALLY FROM 10 JUN 2025 TO 18 JUN 2025 AT 2 ASC C/O RACE
COURSE CAMP, AIR FORCE STATION, NEW DELHI AND 7 ASC, NO. 1 CUBBON ROAD, BENGALURU
KARNATAKA TO JOIN THE IAF AS AGNIVEERVAYU (MUSICIAN INTAKE 01/2026
1. Venue I Location 2 ASC C/O Race Course Camp, Air Force Station New Delhi (New Delhi) and
7 ASC, No. 1 Cubbon Road, Ben aluru (Karnataka
2. Marital
Status Candidate should be unmarried and born between 01 January 2005 and 01 July
and Date of Birth 2008 (both dates inclusive).
Block
3. (a) Educational
Passed Matriculation/10th or equivalent with minimum pass marks from any Govt.
Qualification
recognised School/ Board.
(b) Music Ability

(i)
Candidates must have proficiency in music with accuracy in tempo, pitch
and singing one complete song. They should be able to perform one preparatory
tune and any of the notations ie, Staff notation/ Tablature/ Tonic Solfa/ Hindustani/
Carnatic etc. Candidates must be able to tune individual instruments (in case of
instruments that require tuning) and match unknown notes on vocal or
instruments.
(ii)
Candidates must have proficiency in playing any one instrument from
List A or B.
List-A

List - B

(aa)
(ab)

Concert Flute/ Piccolo.
Oboe.

(ac)
(ad)

Clarinet in Eb/ Bb.
Saxophone in Eb/ Bb.

(ae)

French Horn in F / Bb.

(aa)
Keyboard I Organ I Piano.
(ab)
Guitar (Acoustic/ Lead I
Bass).
(ac)
Violin, Viola, String Bass.
(ad)
Percussion/ Drums
(Acoustic/ Electronic).
(ae)
All Indian Classical
Instruments.

(af)
(ag)
(ah)
(aj)
(ak)

Trumpet in Eb/ C / Bb.
Trombone in Bb / G.
Baritone.
Euphonium.
Bass/ Tuba in Eb/ Bb.

(iii)
It is desirable that the candidates have proficiency to play two instruments
(one each from List A and B above).
(c) Musical
Experience
Certificate

4.

Time and Date
of Rally

Candidates should have any one of the following experience certificate:(i)
Grade 5th or equivalent or above in one instrument from a
recognised music institute such as TCL or RSM, KM Music Conservatory,
Bangalore School of Music, TSM, GMI, Berklee School of Music etc.
OR
(ii)
Diploma or equivalent in the field of music for candidates
performing Hindustani or Carnatic Classical Music from any recognised
University.
OR
(iii)
Certificate of participation/ awards presented at various events.
For such candidates, performance/ playing of blowing instruments with
staff notation as mentioned in Educational QRs.
Registration for the rally will start at 1100 Hr on 21 April 2025 and will close at
2300 Hr on 11 May 2025 on webportal https://agnipathvayu.cdac.in. Only
registered candidates issued with Provisional Admit Card are allowed to appear
_.___in_th_e_R_e_c_ru_itment Rall as per the date, time and venue mentioned in the

. _ _ . _ _ _ J _ __ _ _ _ _ _

I_J

<!-- page 2 -->

5.

State I Districts
Covered

Provisional Admit Card. Registration fee of ~ 100/-plus GST is to be paid by the
candidate.
All the districts of all States and all Union Territories of India.

FOR DETAILED ADVERTISEMENT LOG ON TO WEB PORTAL https://agnipathvayu.cda
c.in

Scan QR code for detailed information

I

I

II

i
I
I

I
I
I
I
