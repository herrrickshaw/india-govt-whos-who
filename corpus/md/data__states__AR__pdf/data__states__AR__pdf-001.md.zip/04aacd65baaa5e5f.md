---
doc_id: "04aacd65baaa5e5f"
source_url: "https://arunfcs.gov.in/noti_cir/3_order.pdf"
ministry: "Food and Civil Supplies Department, Arunachal Pradesh"
title: "Arunachal Pradesh Kerosene (Licensing & Distribution) Control order 2005"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0e39269ff3d22bb0"
---

<!-- page 1 -->

GOVERNMENT OF ARUNACHAL PRADESH
DEPARTMENT OF CIVIL SUPPLIES
ITANAGAR.
Dated Itanagar, the 1st April 2005

NO. DCS/MON/92(A)98(Vol-I)

N O T I F I C A T I O N S.
In exercise of the powers conferred by section 3 of the Essential Commodities Act,
1955, (10 of 1955) read with the Govt. of India in the Minister of Civil Supplies, (Department of
Civil Supplies & cooperation) Order No. 681 (E) dated 30th November, the Governor of
Arunachal Pradesh makes the following Order, namely: -

1.

Short title, extent and commencement:
1. This Order may be called the Arunachal Pradesh Kerosene (Licensing and
Distribution) control Order, 2005.
2. It shall extent to the whole of the State of Arunachal Pradesh
3. It shall come into force on the date of its publication in the Gazette.

2.

Definition:

In this order unless the context otherwise requires: -

(a) “Dealer” means a person engaged in the business of purchase, sale or storage for
sale of kerosene oil whether whole sale or retail and includes a hawker and an
agent of an OIL COMPANY who has entered into an agreement with the Oil
Company to distribute kerosene as whole-sale or retail dealer as the case may be
but does not include an Oil Company.
(b) “Form” means a ‘Form’ appended in the schedule to this order.
(c) “Hawker” means a person who carries kerosene from place to place for sale in
retail not exceeding 5 litres per person at any one time.
(d) “Kerosene” shall have the meaning assigned to it in item No.7 of the first
schedule to the Central Excise and salt Act, 1944 (1 of 1944) and shall not include
Aviation Turbine Fuel.
(e) “Licensing Authority” means the Director of Civil Supplies, Govt. of Arunachal
Pradesh.
(f) “State Government” means the Government of Arunachal Pradesh.
(g) “Director” means the Director of Civil Supplies, Government of Arunachal
Pradesh and includes any other officer of the said department not below rank of
the Superintendent of Supplies of Civil Supplies Department authorized by the
Government in this behalf to perform all or any of the functions of the Director
under this order.
(h) “Deputy Commissioner” means the Deputy Commissioner within their
jurisdiction over the respective areas where the dealer carries on his business.

32

<!-- page 2 -->

(i) “Whole sale dealer” means a dealer who sells kerosene to any other person for
retailing or otherwise at whole sale rates in quantities of 20 litres or more at any
one time.
(j) “Retail dealer” means a person who sells kerosene in small quantities not
exceeding 20 litres per person at any one time fixed by Government.

3.

Prohibition against carrying on business as a dealer without a license: Every person
carrying on business as a dealer shall possess a license under this order and abide by the
terms and conditions of the license granted in this behalf by the licensing authority.

4.

Application for license: A person desires to obtain a license under this order shall make
an application to the licensing authority in form ‘A’ through the concerned Deputy
Commissioner and the licensing authority if he is satisfied may grant his license in form
‘B’.

5.

Form of license: Licenses shall be issued to the whole sale dealer and the retailer under this
order in form ‘B’ –(I) respectively and license issued to the Hawker be in Form ‘B’ –(III).

6.

Security Deposit: Every person applying for license under this order, shall before the
license is issued to him, deposit with the licensing authority, a security as specified here
under for the performance of the conditions subject to which the license, is granted to him.

7.

(a)

In case of Whole sale dealer

:-

Rs. 10000/-

(b)

In case of retail dealer

:-

Rs. 1000/-

(c)

In case of Hawker

:-

Rs.

500/-

Period of license and its renewal: Every license granted under this order shall valid for a
period ending 31st day of March in the year in which it is issued and may be renewed for a
period of one year with time.

7.

Renewal of license: Every license shall deposit their license for renewal within 30th day of
April of the year following with a renewal fee of Rs. 100/- along with an application to the
licensing authority.
However, fine or late renewal of license is livable at the rate of Rs. 25/- per
calendar month or fraction thereof, if the license is not renewed within due date.

9.

Fee for license:
1.

The fee payable for issue of a license or a duplicate copy of license in case
of defaced, lost or destroyed or otherwise shall be Rs. 2000/- for Whole
seller, Rs. 250/- for Retailers and for renewal Rs. 500/- for whole seller,
Rs. 100/- for retailer and Rs. 50/- for Hawker.

33

<!-- page 3 -->

2.

The fee payable shall have to be deposited in the form of Treasury Challan
under the relevant head of Account.

10.

Power to refuse license: The licensing Authority after giving the dealer concerned an
opportunity of stating his case in writing and for reason be to recorded in writing refuse to
grant or renew a license.

11.

Provision for cancellation or suspension of license: If a dealer either by himself or by his
agent, or his servant on his behalf contravened any of the provisions of this order or any of
the conditions of the license, than without prejudice to any other action, that may be taken
against him, the licensing authority may after giving him an opportunity for making his
representation, by order suspend or cancel the license.

12.

Forfeiture of security deposit:
(i)

Without prejudice to the provisions of clause.

(ii)

If the licensing authority is satisfied that the dealer has contravened any of the
conditions of the license and forfeiture of the security is called for, he may after
giving the dealer a reasonable opportunity of being heard, by order forfeit the whole
or any part of the security deposited by him and communicate a copy of the order to
the dealer

(iii)

If the amount of security at any time fall short of the amount specified in clause 6,
the dealer forthwith shall deposit further security to make up the amount on being
required by the licensing authority to do so.

(iv)

Upon due compliance by the dealer with all the conditions of the license, the
amount of security or such part thereof which is not forfeited as aforesaid, shall be
returned to the dealer after the termination of the license.

13.

Maintenance of accounts: Every license shall maintain correct and true accounts in respect
of his business in such form and manner as the direction may specify.

14.

Complying with orders and directions: Every licensee to whom any order or direction is
issued under any powers conferred by or under this order shall comply with such orders or
directions.

15.

Requisitions for sale of kerosene:
(i)

No. dealer shall sell kerosene at a price higher than the price fixed by the
licensing authority.

(ii)

A dealer shall prominently display a stock-cum-price list at his business
premises or near the entrance to the place of sales depot showing the
opening balance of kerosene of the day and the selling price per liter.

(iii)

A dealer shall obtain an explosive license for storage of kerosene, if
necessary, from the appropriate authority.
34

<!-- page 4 -->

(iv)

A dealer shall display the working hours at a conspicuous place of the
business premises. No dealer shall keep his sale depot/sub-depot closed
during the working hours on any day without prior permission of the
licensing authority.

(v)

A dealer shall take all steps to ensure that he has adequate stock of
kerosene at his depot/sub-depot at all times.

(vi)

A dealer shall maintain a true and correct accounts of purchase and sale of
kerosene.

(vii)

A dealer shall comply with the directions that may be given by the
licensing authority Deputy Commissioner or any other officer of the
Department not below the rank of Superintendent of Supplies in regard to
purchase, transport, sale or storage of kerosene, hours of sale or any other
matter relating to kerosene which they may think fit to regulate the sale.

(viii) No dealer shall act in a manner prejudicial to the maintenance of supplies
of kerosene in the state.
(ix)

The licensee shall give all facilities at all reasonable times to the licensing
authority or any other officers of the Civil Supplies Department not below
the rank of Sub-Inspector of Supplies, or any other officers or any person
or a class of persons authorized by the licensing authority for inspection of
the stock and accounts of kerosene and produce the license for inspection
on demand.

16.

Returns by licensee: Every licensee shall submit a monthly return of kerosene to the
Licensing Authority as per prescribed form ‘C’ to reach the licensing authority on 1st day of
every following month.

13.

Power of entry, search, seizure etc:
(i)

The Director, Deputy Commissioner or any officer of Civil Supplies of the
state not below the rank of sub-Inspector of Supplies or any officer authorized
in this behalf by the State Government may with a view to secure compliance
with the provision of this order, inspect any place, boons of accounts or other
documents and where he has reason to believe that any of the provision of this
order contravened or about to contravene, break open or seal any place,
premises, vehicle, or vessel and search, seize or remove any quantity of
kerosene, books of accounts, vehicle, vessel or any other conveyance used for
carrying kerosene and may authorize the taking of all measures for their safe
custody.

(ii)

The provision of section 100 of the code of Criminal Procedure, 1973 92 of
1974) shall apply to search and seizure under this clause.

14.

Power to grant exemption in special case: If the state Government considers it necessary or
expedient in public interest so to do by order exempt any person or class of persons from
35

<!-- page 5 -->

the operation of all or any of the provisions of this order for such period and subject to such
conditions (if any) as may be specified and may at any time suspend or cancel such
exemption.

15.

Appeal: An appeal against any order of the licensing authority shall lie to the State
Government within 30 days of the order appealed against.

16.

Penalty: Any person contravening any of the provisions of this order be liable to be
punished under section7 of the Essential Commodities Act, 1955.

17.

Regulation for storage and sale: The licensee shall maintain a reserve stock not exceeding
4000 litres of SKO at all times for distribution on the basis of permits to be issued by the
licensing authority/Deputy Commissioner or any other officer of Civil Supplies
Department not below the rank of Superintendent of Supplies to meet emergency
requirements during any natural calamity, law and order problem, general election and any
other emergent circumstances to such consumers as may be indicated in the permit.

Sd/- J. P. Rai
Secretary (CS)
Govt. of Arunachal Pradesh,
Itanagar.
Dated Itanagar, the 1st April 2005.

Memo No. DCS/MON/92(A)98(Vol.I)
Copy to : -

1. The Under Secretary to Government of India, Ministry of Consumer Affairs, and Food
and Public Distribution, Krishi Bhawan, New Delhi with reference to his letter No. 11/2001-BP-III dated 7/1/2001.
2. The Secretary to the Governor of Arunachal Pradesh, Itanagar for information of the
Governor.
3. The private Secretary to the Chief Secretary, Arunachal Pradesh, Itanagar for information
of the Chief Secretary.
4. The Director of Information and Public Relation & Printing, Naharlagun with a request to
get the notification published in the next Arunachal Pradesh gazetted (2 copies).
5. The Inspector general of Police, Arunachal Pradesh, Itanagar.
6. The Director of Civil Supplies, Arunachal Pradesh Naharlagun.
7. All Deputy Commissioner, Arunachal Pradesh.
8. The Director of Supply & Transport, Arunachal Pradesh, Naharlagun.
9. The Register of Cooperative Society, Arunachal Pradesh, Naharlagun.
10. The Controller Legal Metrology, Arunachal Pradesh, Naharlagun.

(K.P.Balachandran)
Under Secretary (CS)
Govt. of Arunachal Pradesh,
Itanagar.

36

<!-- page 6 -->

FORM – A
(See clause –4)
FORM OF APPLICATION FOR LICENSE FOR PURCHASE, SALE AND STORAGE FOR
SALE OF KEROSENE.
PART –I
1) Applicant’s full name and
permanent residential address.
2) Present address of the applicant.
3) Whether wholesale dealer,
retail dealer or Hawker.
4) Whether applicant is an Agent or
Sub-agent of any Oil Company
and if so, which?
5) Age of the applicant.
6) How long has the applicant
been trading in kerosene?
7) Quantities of kerosene likely to be
handled by the applicant monthly,
during the current year.
8) Average quantity of kerosene likely
to handled by the applicant monthly,
during the current year.
9) Whether the applicant has been convicted
in a court of law or found guilty in any
Department inquiry regarding any Breach
of this order or any other control orders
if so, give details.
10) Whether the applicant has trading
license from concerned Municipality or
District Council as the case may be.
11) Particulars of Agreement made with the
Oil Company for supply of SKO.
I have not previous applied for such license.
I have applied for such license on …………
and was not granted a license on …………
I have carefully read the conditions of the license in Form II/III in the schedule to the Arunachal
Pradesh kerosene (Licensing and Distribution) control order, 2005.
I declare that the information furnished above is correct.
Date ………………..
Strike out the clause which is not applicable.
Signature of applicant.
Signature of the
Deputy Commissioner.

37

<!-- page 7 -->

FORM –B (I)
(See Clause – 5)
LICENSE FOR PURCHASE SALE AND STORAGE OF KEROSENE FOR WHOLESALE
DEALER.
License No……………..
1. Subject to the provisions of the Arunachal Pradesh kerosene (Licensing and Distribution)
control

order,

2005

and

to

the

terms

and

conditions

of

this

license

………………….……………… is/are hereby authorized to purchase sell and store for
sale kerosene.
2. The

license

shall

carry

on

the

aforesaid

business

within

the

area

of

……………………..……………
3. No dealer shall sell kerosene at a price higher than the price fixed by the licensing
Authority.
4. A dealer shall prominently display a stock-cum-price list at his business premises or near
the entrance to the place of sales depot showing the opening balance of kerosene of the
day and the selling price per litre.
5. A dealer shall obtain an explosive license for storage of kerosene, if necessary, from the
appropriate authority.
6. A dealer shall display the working hours at a conspicuous place of the business premises.
No dealer shall keep his sales/sub-depot closed during the working hours on any day
without prior permission of the Licensing Authority.
7. A dealer shall take all steps to ensure that he has adequate stock of kerosene at his
depot/sub-depot at all times.
8. A dealer shall maintain and correct accounts of purchase and sale of kerosene.
9. A dealer shall comply with the directions that may be given by the licensing
authority/Deputy Commissioners or any other officer of the department not below than
the rank of Superintendent of Supplies in regard to purchase, transport sale or storage of
kerosene which they may think fit to regulate the sale.
10. No dealer shall act in a manner prejudicial to be maintenance of supplies of kerosene in
the state.
11. The license shall give all facilities at all, reasonable times to be licensing authority or any
other officer of the Civil Supplies, department not below the rank of Sub-Inspector of
Supplies, or any other officers or any person or a class of persons authorized by the
licensing authority/Deputy Commissioners for inspection of the stock and accounts of
kerosene and produce the license for inspection of demand.
12. The license shall be valid upto ………………………………..… and shall be renewed
before 31st March of the year following.

Place ……………………

Licensing Authority

Date ………………. Day of ……………..

……………………… area
38

<!-- page 8 -->

FORM –B (II)
(See Clause –5)
LICENSE FOR PURCHASE SALE AND STORAGE OF KEROSENE BY RETAIL DEALER
OTHER THAN HAWKER.
LICENSE NO……………………………………………………………
1. Subject of the provisions of the Arunachal Pradesh Kerosene (Licensing and
Distribution) Control order, 2005 and to the terms and conditions of this license
………………………….……………………… is/are hereby authorized to purchase, sell
and storage kerosene.
2. The

license

shall

carry

on

the

aforesaid

business

within

the

area

of

……………………………..
3. No dealer shall sell kerosene at a price higher than the price fixed by the Licensing
Authority.
4. A dealer shall prominently display a stock-cum-price list at his business premises or near
the entrance to the place of sales depot showing the opening balance per litre.
5. A dealer shall obtain an Explosive license for storage of kerosene if necessary, from the
appropriate authority.
6. A dealer shall display the working hours at a conspicuous place of the business premises.
No dealer shall keep his sales depot/sub-depot closed during the working hours on any
day without prior permission of the Licensing Authority.
7. A dealer shall take all steps to ensure that he has adequate stock of kerosene at his
depot/sub-depot at all times.
8. A dealer shall maintain a true and correct accounts of purchase and sale of kerosene.
9. A dealer shall comply with the directions that may given by the Licensing
Authority/Deputy Commissioners or any other officer of the Department not below the
rank of Superintendent of Supplies in regard purchase, transport, sale or any other matter
relating to kerosene which they may think fit to regulate the sale.
10. No. dealer shall act in a manner prejudicial to the maintenance of Supplies of kerosene in
the state.
11. The licensee shall give all facilities at all reasonable times to the Licensing Authority or
any other officer of the Civil Supplies, Department not below the rank of Sub-Inspector
of Supplies, or any other officers or any person or a class of persons authorized by the
Licensing Authority/Deputy Commissioners for the inspection of the stock and accounts
of kerosene and produce the license for inspection on demand.
12. This license shall be valid upto …………………….. and shall be renewed before 31st
March of the year following.
Place ………………………………………..
Date ……………………………. Day of ……………………………………

Licensing Authority
……………… Area.
39

<!-- page 9 -->

FORM –B (III)
(See Clause – 5)
HAWKER’S LICENSE FOR SALE OF KEROSENE
(FREE OF ALL FEES EXCEPT LICENSE FEE)
License No………………………………..
1. Subject to the provisions of the Arunachal Pradesh kerosene (Licensing and Distribution)
control order ………………………….. 2005 and to the terms and conditions of this
license …………………………….. is/are hereby authorized to sell kerosene as Hawker.
2. No, Hawker shall sell kerosene at a price higher than the price fixed by the Licensing
Authority.
3. A Hawker shall prominently display a stock-cum-price list at his business premises.
4.

A Hawker shall obtain an explosive license for storage of kerosene if necessary from the
appropriate authority.

5. A Hawker shall maintain a true and correct accounts of purchase and sale of kerosene.
6. A Hawker shall comply with the directions that may be given by the Licensing
Authority/Deputy Commissioner or any other officer of the department not below the
rank of Superintendent of Supplies in regard to purchase, transport, sale or storage of
kerosene which they may think fit to regulate the sale.
7. No Hawker shall act in a manner prejudicial to the maintenance of supplies of kerosene
in the state.
8. The Licensing Authority or any other officer of the civil supplies Department not below
the rank of Sub-Inspector of Supplies, or any other officers or any person or a class of
persons authorized by the Licensing Authority/Deputy Commissioner for inspection of
the stock and accounts of kerosene and produce the license for inspection on demand.
9. This license shall be valid upto ……………………. And shall be renewed before 31st
March of the following.

Place ………………………………………..
Date ……………………………. Day of ………………

Licensing Authority
……………… Area.

40

<!-- page 10 -->

FORM –C
(See Clause –16)
Form for submission of monthly kerosene Oil Stock by the dealer.

1. Name and address of the dealer: 2. Name of the Oil Company
Supplying kerosene: 3. Monthly return for the
month of submitted as under: -

Monthly
allocation

Opening
stock

Station

:-

Date

:-

Receipt
Total
Sale/issued Closing
Selling Rate
during the stock
during the balance at
month
available month
the end of Whole Retail
Sale
the month sale

Remarks

Submitted to …………………………..
(Licensing Authority)

Signature of the dealer.

41
