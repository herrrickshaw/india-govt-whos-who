---
doc_id: "09cb5e9aafbc8d28"
source_url: "https://power.arunachal.gov.in/uploads/orders/258661a0558879c9dd428459aade59c2.pdf"
ministry: "Power Department, Arunachal Pradesh"
title: "View"
date: ""
pages: 28
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9d2829c6874704e6"
---

<!-- page 1 -->

GOVERNMENT OF ARUNACHAL PRADESH
D
OFPOWER
Oflice of the Chief Engineer (Commercial)
cum Chief Electrical Inspector,
Vidyut Bhawan, Itanagar -791111
(Arunachal Pradesh)
com
nail: ceco
Dated Itanagar, the l8)zYne2026
No. CE(CoM)/AIJDIT /3 s I 2026-27 t I I

a\' *+

To,

The Chief Program Manager,
ttEC Limited, Regional Office.
SRADDHA Building,
MG Road & GS Road Crossing.
SOHIIN{/SBI Point, Christian Basti,
Guwahati-781005

Sub: Submission of Audited Annual Accounts for the FY 2025'26.
Sir.
Enclosed please find herewith the Audited Annual Accounts for the FY 2025-26, as per

the format prescribed by the Ministry of Power, Gort. of India for the Departrnent of Power,
Arunachal Pradesh.
This is for your information and necessary action at your end please.
Enclosure: As stated above.

Yours

Chief En

eer

cum CEI

ent o f Power,

Itanagar

No. CE(COM)/AUD|T|35|2026-27/

Dated Itanagar,

the

Jute2026

Copy to :

1. The Commissioner (Power), Government of Arunachal Pradesh, Block No. 2, 2nd Floor,
Room No. 206, AP Civil Secretariat, Itanagar along with a copy of the Audited Annual
Accounts for for FY 2025-26 for kind information please.

2. The State Nodal Olficer RDSS, Deptt. of Power., Vidyut Bhawan, Itnagat- 79llll,
Arunachal Pradesh along with a copy ofthe Audited Annual Accounts for for FY 2025-26

for inforrnation.

Page I of2

<!-- page 2 -->

3. The Chief Engineer (Power) , TPMZ, Deptt. of Power, Itanagar for information along with
a copy of the Audited Annual Accounts for FY 2025-26. He is requested to upload the
Restated Audited Annual Accounts for FY 2025-26 in the web portal of the Department of
Power on priority.

Chief Engineer (Com) cum CEI
Department of Power,
Itanagar

Page 2 of 2

<!-- page 3 -->

Head Of ice:

Gadly Shaw & Associates
Chartered Accountants

148A, Salkia School Road,
Maansarovar Apartment
(Ground Floor)
Kolkata (Howrah): 711101
Email: gadlyshaw@gmail.com
Ph: 033 2676 8122

CERTIFICATION
This is to certify the Report on the Statement as per Annexure 1, as approved by
Ministry of Power, GOI of the Chief Engineer Commercial Zone Cum Electrical Inspector,
Department of Power, Arunachal Pradesh.
We have verified the accompanying statements of Commercial Zone, Department of Power,
Arunachal Pradesh ("State Power Department"), which comprise Annexure - 1 along with the Notes
(1 to 5) for Annual (FY 2025-26).
In our opinion and to the best of our information and according to the explanations given to
us, we have verified the accompanied Statement and notes to the statement from the Cash Book,
Sample Monthly Accounts, LOC, Agreements, sample sales/ purchase invoices and, however, the
aforesaid Annexure - 1 statements give a true and fair view and following points observed during
our verification:
1.

With reference to point number A1: Revenue from Sale of Power (amounted Rs.452.35
crores) and A4: Revenue from Inter State Sale and Trading (amounted Rs.85.08 crores) of
Table 1: Revenue details, we have been provided statement of Energy Sold within and outside
the state as referred in the Statement of annexure as Note 1 (i) & Note 1 (ii) respectively. We
have found that the statement as stated is noted as billed to customer basis and verified from
Capital Division & Naharlagun Division Monthly Accounts.

2.

As per the discussion with the Management no revenue occurred with reference to the point
number A2: Fixed Charges/ Recovery from theft etc. of Table: 1 Revenue Details, so the
column has been kept blank.

3.

As per the discussion with the Management no revenue occurred with reference to the point
number A3: Revenue from Distribution franchisee of Table 1: Revenue Details, so the column
has been kept blank.

4.

As per the discussion with the Management no revenue occurred with reference to point
number A5: Revenue from Open access and wheeling of Table 1: Revenue Details, so the
column has been kept blank.

5.

As per the discussion with the Management no revenue occurred with reference to point
number A6: Any other operating Revenue of Table 1: Revenue Details, so the column has
been kept blank.

Of ices at:
Patna – Diphu – Chennai –New DelhiMumbai
www.gadlyshaw.com

<!-- page 4 -->

Head Of ice:

Gadly Shaw & Associates
Chartered Accountants

148A, Salkia School Road,
Maansarovar Apartment
(Ground Floor)
Kolkata (Howrah): 711101
Email: gadlyshaw@gmail.com
Ph: 033 2676 8122

6.

As per the discussion with the Management no revenue occurred with reference to point
number B1: Tariff Subsidy Booked of Table 1: Revenue Details, so the column has been kept
blank.

7.

As per the discussion with the Management no revenue occurred with reference to point
number B2: Revenue Grant under UDAY of Table 1: Revenue Details, so the column has
been kept blank.

8.

Dept of power receive all their expenses from Govt. Of Arunachal Pradesh, so we have
shown the balance amount (differences of Revenue & Expenditure amount) in point
number B3: Other Subsidies and Grants of Table 1.

9.

As per the discussion with the Management no revenue occurred with reference to point
number C1: Income booked against deferred revenue of Table: 1 Revenue Details, so the
column has been kept blank.

10.

As per the discussion with the Management no revenue occurred with reference to point
number C2: Misc non-tariff income from consumers (including DPS) of Table: 1
Revenue Details, so the column has been kept blank.

11.

As per the discussion with the Management no revenue occurred with reference to point
number C3: Other Non-Operating income of Table: 1 Revenue Details, so the column
has been kept blank.

12.

We have received a statement for Purchase of power and Transmission charges for a total
expenditure of Rs. 623.59 Crores under Table 2: Expenditure Details, mentioning LC
Bill, Supplementary & Other Bill and POSOCO and verified the same from sample bills
provided to us and details of the statement are provided in Note 2. As per discussion with
the management PGCIL & CTUIL are transmission units and all the bills they raised are
related to transmission expenses.

13.

We have verified point H1: Repairs & Maintenance under Table 2: Expenditure details,
we checked the LC statement and the statement as provided by the management,
Quarterly report have been prepared as per the LC basis however final report is prepared
as per actual expense basis and as per data provided by Management, Repair &
Maintenance exp amounted to Rs 66.29 crores for the FY 2025-26.

14.

We have verified point H2: Employee Cost under Table 2: Expenditure details Salary and
wages of employees as provided by Capital and Naharlagun Division.

Of ices at:
Patna – Diphu – Chennai –New DelhiMumbai
www.gadlyshaw.com

<!-- page 5 -->

Head Of ice:

Gadly Shaw & Associates
Chartered Accountants

148A, Salkia School Road,
Maansarovar Apartment
(Ground Floor)
Kolkata (Howrah): 711101
Email: gadlyshaw@gmail.com
Ph: 033 2676 8122

15.

We have verified Point number H3: Admin & General Expenses under Table 2:
Expenditure details, amounted to Rs. 36.46 Crore for the FY 2023-24 as per data
provided.

16.

As per the discussion with the Management no expenditure occurred with reference to
point number H4: Depreciation of Table: 2 Expenditure Details, so the column has been
kept blank.

17.

As per the discussion with the Management no expenditure occurred with reference to
point number H5: Total Interest Cost of Table: 2 Expenditure Details, so the column has
been kept blank.

18.

As per the discussion with the Management no expenditure occurred with reference to
point number H6: Other Expenses of Table: 2 Expenditure Details, so the column has
been kept blank.

19.

As per the discussion with the Management no expenditure occurred with reference to
point number H7: Exceptional Items of Table: 2 Expenditure Details, so the column has
been kept blank.

20.

As per the discussion with the Management no expenditure occurred with reference to
point number K1: Income tax of Table: 2 Expenditure Details, so the column has been
kept blank.

21.

As per the discussion with the Management no expenditure occurred with reference to
point number K2: Deferred Tax of Table: 2 Expenditure Details, so the column has been
kept blank.

22.

As per the discussion with the Management with reference to point number M1: Net
Tangible Assets & CWIP of Table:3 – Total Assets, is not applicable so the column has
been kept blank.

23.

As per the discussion with the Management with reference to point number M2: Other
Non-current Assets of Table:3 – Total Assets, is not applicable so the column has been
kept blank.

24.

For verification of Point number M3a: Gross Trade Receivables Govt. Dept. under
Table:3 of – Total Assets, we have received the statement as per Note 4(i).

25.

For verification of Point number M3b: Gross Trade Receivables other than Govt. Dept.
under
Table:3 of – Total Assets, we have received the statement as per Note 4.

Of ices at:
Patna – Diphu – Chennai –New DelhiMumbai
www.gadlyshaw.com

<!-- page 6 -->

Head Of ice:

Gadly Shaw & Associates
Chartered Accountants

148A, Salkia School Road,
Maansarovar Apartment
(Ground Floor)
Kolkata (Howrah): 711101
Email: gadlyshaw@gmail.com
Ph: 033 2676 8122

26.

As per the discussion with the Management with reference to point number M3c:
Provision for Bad Debts of Table:3 of – Total Assets, is not applicable so the column has
been kept blank.

27.

As per the discussion with the Management with reference to point number M4: Subsidy
Receivable of Table: 3 of – Total Asset, is not applicable so the column has been kept
blank.

28.

As per the discussion with the Management with reference to point number M5: Other
Current Assets of Table: 3 of – Total Assets, is not applicable so the column has been
kept blank.

29.

As per the discussion with the Management with reference to point number N1: Share
Capital & General Reserve of Table: 4 of – Total Equity & Liabilities, is not applicable
so the column has been kept blank.

30.

As per the discussion with the Management with reference to the point number N2:
Accumulated Surplus/(Deficit) as per BS of Table: 4 of – Total Equity & Liabilities, is
not applicable so the column has been kept as blank.

31.

As per the discussion with the Management with reference to point N3: Govt. Grants for
Capital Assets of Table: 4 of – Total Equity & Liabilities, is not applicable so the column
has been kept blank.

32.

As per the discussion with the Management with reference to point number N4: Noncurrent Liabilities of Table: 4 of – Total Equity & Liabilities, is not applicable so the
column has been kept blank.

33.

As per the discussion with the Management with reference to point number N5: Capex
Borrowings of Table: 4 of Key – Total Equity & Liabilities Details, is not applicable so
the column has been kept blank.

34.

As per the discussion with the Management with reference to point number N6a: Long
Term Loans – State Govt. under Capex Borrowings of Table: 4 of Key – Total Equity &
Liabilities Details, is not applicable so the column has been kept blank.

35.

As per the discussion with the Management with reference to point number N6b: Long
Term Loans – Banks & FIs under Capex Borrowings of Table: 4 of Key – Total Equity
& Liabilities Details, is not applicable so the column has been kept blank.

Of ices at:
Patna – Diphu – Chennai –New DelhiMumbai
www.gadlyshaw.com

<!-- page 7 -->

Head Of ice:

Gadly Shaw & Associates
Chartered Accountants

148A, Salkia School Road,
Maansarovar Apartment
(Ground Floor)
Kolkata (Howrah): 711101
Email: gadlyshaw@gmail.com
Ph: 033 2676 8122

36.

As per the discussion with the Management with reference to the point number N6c:
Short Term / Medium Term Loans – State Govt. under Capex Borrowings of Table: 4 of
Key – Total Equity & Liabilities Details, is not applicable so the column has been kept
as blank.

37.

As per the discussion with the Management with reference to the point number N6d:
Short Term / Medium Term Loans – Banks & FIs under Capex Borrowings of Table: 4
of Key – Total Equity & Liabilities Details, is not applicable so the column has been kept
as blank.

38.

As per the discussion with the Management with reference to point number N6: Noncapex Borrowings of Table: 4 of Key – Total Equity & Liabilities, is not applicable so
the column has been kept blank.

39.

As per the discussion with the Management with reference to the point number N7a:
Short Term Borrowings form Banks/Fis under Non-capex Borrowings of Table: 4 of Key
– Total Equity & Liabilities, is not applicable so the column has been kept as blank.

40.

As per the discussion with the Management with reference to point number N7b: Cash
Credit/OD from Banks/Fis under Non-capex Borrowings of Table: 4 of Key – Total
Equity & Liabilities, is not applicable so the column has been kept blank.

41.

As per the discussion with the Management with reference to point number N8: Payables
for Purchase of Power of Table: 4 of – Total Equity & Liabilities, is not applicable so the
column has been kept blank.

42.

As per the discussion with the Management with reference to the point number N9: Other
Current Liabilities of Table: 4 of – Total Equity & Liabilities, is not applicable, however
balancing figure of Total Assets have been taken as Other Current Liabilities.

43.

Table 5 & Table 6 of Annexure 1 is related to the energy account and the details have
been filled in only based on the management certified energy account submitted to us.
However, Trade Receivable details mentioned in O11 & O12 column are as per Note-4
which is provided by management.

44.

Details as stated in Table 7 & Table 8 are only as per the data provided by the
management.

Of ices at:
Patna – Diphu – Chennai –New DelhiMumbai
www.gadlyshaw.com

<!-- page 8 -->

Head Of ice:

Gadly Shaw & Associates
Chartered Accountants

148A, Salkia School Road,
Maansarovar Apartment
(Ground Floor)
Kolkata (Howrah): 711101
Email: gadlyshaw@gmail.com
Ph: 033 2676 8122

45.

We have verified the TDS and GST during our audit period from Capital Division and
Naharlagun Division on sample basis.

46.

All the operational costs of the Department of Power are being borne by the Govt. of
Arunachal Pradesh through approved annual budgetary allocation.

47.

O&M Expenditure is exclusive of Transmission Planning & Monitoring Zone.

48.

Trade Receivables as stated in Annexure -1 have been adjusted, after the incorporation
of the Declaration dated 17.06.2025 of the Govt. of Arunachal Pradesh and at point no.
O12: Adjusted Gross Closing Trade Receivables in Q4 in Table 6 have been modified
accordingly. Trade Receivables of Rs.1,54,28,82,558.40 have been adjusted against the
overall grant released to the Department to maintain the operation efficiency of the
Department.

Of ices at:
Patna – Diphu – Chennai –New DelhiMumbai
www.gadlyshaw.com

<!-- page 9 -->

Head Of ice:

Gadly Shaw & Associates
Chartered Accountants

148A, Salkia School Road,
Maansarovar Apartment
(Ground Floor)
Kolkata (Howrah): 711101
Email: gadlyshaw@gmail.com
Ph: 033 2676 8122

Responsibility of Management for the Report on the Statement as per Annexure - 1.
The management are responsible for the matters stated in Annexure - 1 along with the Notes
(1 to 5) with respect to the preparation of these statements that give a true and fair view of
state of affairs.
This responsibility also includes maintenance of adequate accounting records in accordance
with the provisions of the Act and for preventing and detecting frauds and other
irregularities; selection and application of appropriate accounting policies; and design,
implementation and maintenance of adequate internal financial controls, that were operating
effectively for ensuring the accuracy and completeness of the accounting records, relevant
to the preparation and presentation of the Report on Statement of Annexure - 1 along with
the Notes (1 to 5) that give a true and fair view and are free from material misstatement,
whether due to fraud or error.

For Gadly Shaw & Associates
Chartered Accountants
FRN: 327846E

CA Sumit Agarwal
Partner
M No.: 302683
UDIN: 26302683ZXLMAB1757
Date: 17.06.2026
Place: Howrah

Of ices at:
Patna – Diphu – Chennai –New DelhiMumbai
www.gadlyshaw.com

<!-- page 10 -->

,q

ao
(D

't
r)
.I oI
.D

3s EI

-.E,

3F cn

3

o5

o
0

q

S

2

0)

0,

x

x
o
/

a

5

I :t

I

:

3i

8

I

R

.8

-t

II

I

3

-8

.d

a

.T

3
3

E

9

IHHHH

H HHH

I E ts

a

!
8

B E

B

.3

s
gc

:

E E E E B 8

-3

c

a E

I8B !

E

?

a

d

;

g

i

a

H

8

s

H

E

a

t'<

=

E

i

Il

a

E

s

!I

!

F

i

! F

3 !

I

a

l' 3f
I

qa

i

3

-3

ts

-t

A

.t

3

B

IIIHI

F

6

H

a

.8

!

.:

E

qd

a

6

3

a

E a

3

IH IIIHI

8

a

!

I

EIH

,

H

8

il

8

E

E

E

E

ir

t

IH

3

t
i

E

t

I

3

:t
3

s

g

att

I

.!

I

R

i

I

t;
t:

t.,

I aa

i

8

3 !

s

8

a

s

x

E

l

E a IE

!' 3

a

!
i

s
!

E

!

-

€

{

f

E

a

=

I7

a

x

5

$
5

E

a

H

.8

3

I

I

-g

s

i

;
I

s

e

3

i

$,'

$u

$i,

Ee

E

E

HHun

s

s

.3

I

.t

B

:l

E

t

3 EI

I=q

3

R a

i!

4

d

IHIIHH=E

I

s

x e

3

a !

E 3

I x

B

: tl

i

I

:

II
ii

*

5

I

<!-- page 11 -->

E
a

rd,

,

tr €
(D

a) o

,o q
=E

aa

c, 9
t,

K*\

\(D

6

o
ti
q)

x

A

\

€

)

a

E

t

B

E

I

t

t

E

-8

5

-F

.8

I

3

I c

I s

a

i

I

I

3

6

a

E

tI

E

I

t-

3

i
i

B

-6

a

!

a

I

I

r

I

.t

6

:

g

E

8

i

:g !

d

z

I ! !

IE

l,

a a

ls d

I

Ia I I

i

la
l=

6"

:
t I6

E

q

I

8

I

tr ? l

5

d

n

I

s i 3

i

q

i

6

n

i

i'

9

t

3

s

I

3

q 5

I

z a

II I

f

6

3

T

I

;
t
B

l

a

E

I

!

l

t+

8

;

-.

t;

l :.
e

f,

a

{

s

f:

1

3

=

I

a

I
I a

{a t ; ;

a

E

2

i

a

a

=

3

-t

c

li

l;

li

lt

1T t;

tllls

I
I

3

I

E

s

I ! l l
a.
5
I
l I * : I
* ai aa
t
*
*

t

cI
i

3 I

I

!

E

\
d

c

l;

a

q

a

0

e

i

E

6"

14

P

rl
9

I

ts

E

i

:

li

l'E

ti

t_

E

-B

t8

a

.8

E

l-i i-

l!

lt:

IE 3

t-

5

3 5
I

3 3

B

i

e g

F

a

J I

F

n

I

tt

I

q

:t

<,

!6

9-

EE

9

e

<!-- page 12 -->

i7 3I

*

0)
a

6

8

I

t

i

E

I I

E

I

s

3

I

8

i

.3

c

6

I

?

c

I

I

ts

;

i<

3
3

E

a

:' 9

q3

6

5

t, I

q

33

1r

I

s

s

I

B

I

I

E

I

I

a

I

a

C

$
8

a

3

$

I
: a3 8

t tI t

3

I{

E

B

5

;

3 .l 3

I

=

i

3

a_

:

5

a

I

3

!

5',

3

=

3

3

:a

*l

4

I

s

E

a

3

{

i

II

t

i I
ii

€
g

-9

l

;

E

s-

;

$

.D

t

g

T

!

I
t
I

*

I tI

j

a
E

a

I

c

t

$

!

a
T

i
t
Ia

I

E

T

q

t
t!

I

E

Ia

I
I

I

r

5

I

3

m 4.

B

t8

t+

le

li
li

ti

le

IE

e

I

l:

lr

;

t!

R.

3

3

z

N

q

,

:

E

I

;

l

a g

!
s

!

E c) ol

Eg- 3 d

rct

IE

o 3r m

ot

(t

!-

q,

ts
/e/ r

i

g

!

i

I

B

t

x
o

GI/)

t
II

i !3
I

a<

a

I

r

:!

I

g

1

e

I

3

=

I

3

t: I

I

:

E
6

!

+

I

I

e

.2

T

&

s

ts

I

{

t,

t

6'

=

s s

e.

{{€a

I : 8 8

?

B

3

:

<!-- page 13 -->

Note-1 (i)

Month-wise / Division-wise Revenue Billed (in Rs.) within State for the year 2025-26
Sl.No. Division
WEZ
1
Naharlagun
2
Capital
3
Sagalee
4
Tawang
5
Bomdila
6 Seppa
7
RpED (Rupa)
8
YuED (Yupia)
9
PkED (Pakke Kessang)
Total of WEZ =

April

May

June

July

August

September

October

November

December

January

February

March

(In Rupees)
Total

4,06,86,867
3,88,02,774
21,02,121
1,65,30,270
1,33,79,332
55,66,294
5,13,59,619
3,03,75,742
10,20,489
19,98,23,507

5,89,43,859
4,21,36,345
21,08,999
1,70,38,906
1,20,99,116
53,66,533
5,41,95,172
3,17,45,934
10,27,188
22,46,62,051

6,01,82,446
4,62,24,541
27,17,021
2,02,53,755
1,17,14,724
57,70,112
5,65,75,252
3,06,89,399
10,39,975
23,51,67,225

6,33,22,451
5,06,39,609
27,13,696
1,65,90,848
1,70,17,812
58,06,967
5,55,31,708
3,49,15,350
10,95,904
24,76,34,345

6,66,54,159
4,92,89,995
24,55,598
1,52,96,267
1,11,18,897
58,89,133
5,60,30,170
4,08,61,578
11,10,756
24,87,06,552

6,08,47,109
4,70,57,666
22,72,497
1,31,10,750
1,11,13,908
59,42,955
5,37,71,068
3,47,87,412
11,21,040
23,00,24,404

6,44,61,046
4,30,97,887
22,49,286
1,38,45,468
1,03,83,923
56,22,870
5,66,22,262
3,41,12,431
11,17,242
23,15,12,416

6,14,67,621
4,09,03,810
23,01,870
1,40,67,850
1,17,20,854
58,08,190
4,99,90,807
3,03,32,258
11,24,859
21,77,18,121

6,01,73,887
4,43,02,570
22,46,121
1,60,86,881
1,36,16,478
57,50,445
5,33,56,315
3,68,81,748
11,28,775
23,35,43,221

5,86,78,472
4,45,95,625
22,91,606
1,56,46,507
1,62,37,896
58,66,587
5,58,22,060
3,16,02,286
11,35,630
23,18,76,669

5,50,52,965
4,13,37,803
22,83,917
1,54,15,909
1,69,35,761
56,91,532
5,08,77,914
3,22,63,803
11,43,671
22,10,03,276

5,68,94,940
4,34,00,189
22,18,462
1,51,70,610
1,57,24,840
57,08,511
5,76,06,693
3,60,92,738
11,36,570
23,39,53,554

70,73,65,822
53,17,88,813
2,79,61,194
18,90,54,021
16,10,63,541
6,87,90,130
65,17,39,039
40,46,60,679
1,32,02,099
2,75,56,25,339

10
11
12
13
14
15
16
17
18
19
20
21
22

CWZ
Ziro
Kurung Kumey
Daporijo
Yingkiong
Pasighat
Aalo
Rumgong
Basar
PaED (Pania)
RaED (Raga)
LiKED (Likabali)
MeED (Mechuka)
YzED (Yazali)
Total of CEZ =

55,91,897
37,63,438
51,22,279
18,69,523
4,75,43,807
68,24,032
18,50,329
21,73,767
7,24,484
22,94,039
21,62,381
2,60,426
29,69,840
8,31,50,242

53,51,200
35,38,949
58,12,749
19,93,979
4,59,46,428
64,13,923
18,10,407
22,91,161
6,99,860
22,88,969
21,03,320
2,95,094
31,98,163
8,17,44,203

56,74,926
36,17,128
54,36,885
19,36,647
3,39,59,410
62,11,717
19,38,413
23,03,816
6,94,240
22,67,767
21,13,742
2,65,446
32,30,819
6,96,50,956

57,96,943
36,05,855
55,77,016
21,89,282
4,93,27,269
74,43,661
20,39,170
26,09,504
7,35,448
21,99,588
21,12,252
2,51,729
32,63,165
8,71,50,882

57,04,903
36,61,074
55,87,490
22,01,192
6,22,05,520
74,50,808
20,10,943
26,82,180
7,34,544
22,64,928
26,13,129
2,37,719
32,59,827
10,06,14,257

51,43,657
37,22,311
56,95,233
25,16,328
2,75,68,717
59,15,688
18,51,095
19,82,579
7,46,228
23,18,019
30,10,215
2,75,340
32,94,741
6,40,40,152

71,75,783
37,77,271
56,14,665
23,68,772
1,64,41,266
59,90,227
19,40,811
24,03,057
7,44,339
23,41,354
27,82,676
6,49,143
33,32,324
5,55,61,686

54,57,326
38,66,962
59,05,799
22,39,356
1,47,18,317
59,22,057
23,74,805
22,45,095
7,81,639
23,44,064
26,84,741
3,35,945
33,50,484
5,22,26,590

91,74,628
38,09,395
55,77,561
21,46,706
1,47,49,099
93,88,022
20,69,069
26,40,479
7,85,282
23,94,997
26,10,976
2,52,187
33,74,502
5,89,72,903

62,54,563
38,65,620
66,77,495
20,46,424
1,39,16,100
82,88,631
24,28,695
31,53,513
7,87,659
24,68,626
25,65,308
2,13,433
34,30,218
5,60,96,285

61,87,605
38,91,192
59,31,661
20,99,294
2,73,33,338
80,29,189
21,00,487
28,80,775
7,97,913
24,44,270
26,32,145
2,92,072
34,60,184
6,80,80,126

62,43,235
38,63,385
57,15,130
21,05,333
1,32,53,189
74,32,010
19,56,384
28,70,272
7,77,113
23,69,659
25,33,966
56,685
34,81,831
5,26,58,194

7,37,56,665
4,49,82,581
6,86,53,963
2,57,12,836
36,69,62,460
8,53,09,965
2,43,70,608
3,02,36,198
90,08,748
2,79,96,281
2,99,24,852
33,85,219
3,96,46,099
82,99,46,474

23
24
25
26
27
28
29
30
31

EEZ
Roing
Deomali
Miao
Hayuliang
Namsai
Anini
Longding
YaED (Yatdam)
Tezu
TOTAL of EEZ =

75,93,289
90,79,338
1,02,92,508
12,80,234
2,61,15,098
10,00,974
42,14,406
18,32,201
45,08,142
6,59,16,190

78,40,138
93,31,454
58,68,689
19,00,128
2,62,97,174
9,71,022
45,15,696
27,20,131
40,81,267
6,35,25,698

95,97,981
90,25,733
63,00,700
20,23,122
2,86,54,438
10,14,696
46,27,160
18,86,730
77,78,087
7,09,08,648

82,79,337
91,57,607
1,74,98,859
20,03,999
2,92,75,073
10,01,478
48,68,330
19,11,322
72,23,309
8,12,19,313

1,01,86,937
90,83,078
1,99,59,304
20,69,610
3,14,53,301
10,68,036
45,82,856
19,10,465
48,57,730
8,51,71,318

83,31,859
93,20,263
2,99,49,696
20,97,748
3,00,70,374
10,45,564
49,11,174
19,16,610
81,80,624
9,58,23,911

83,35,761
92,43,891
1,60,04,595
20,83,842
3,03,95,957
9,95,964
46,90,530
20,49,218
86,86,575
8,24,86,333

1,01,40,022
95,07,991
1,51,10,306
21,72,232
3,32,17,154
10,65,301
49,41,580
19,47,268
1,07,45,702
8,88,47,556

82,45,921
90,77,592
1,34,52,319
20,02,456
2,95,16,218
9,83,129
48,68,510
20,71,991
75,58,309
7,77,76,445

81,06,569
95,67,183
1,42,71,482
20,60,432
2,85,69,915
10,90,193
49,54,646
20,38,200
61,38,790
7,67,97,410

86,34,573
94,12,943
1,39,41,995
20,28,232
2,73,49,864
10,82,889
49,43,078
20,93,295
61,47,559
7,56,34,428

82,30,178
95,69,092
1,30,00,694
19,89,278
2,66,49,898
10,08,935
50,14,910
19,29,248
64,87,666
7,38,79,899

10,35,22,565
11,13,76,165
17,56,51,147
2,37,11,311
34,75,64,465
1,23,28,181
5,71,32,877
2,43,06,679
8,23,93,761
93,79,87,150

34,88,89,939

36,99,31,952

37,57,26,829

41,60,04,539

43,44,92,127

38,98,88,467

36,95,60,435

35,87,92,267

37,02,92,569

36,47,70,364

36,47,17,830

36,04,91,646

4,52,35,58,964

Q1

1,09,45,48,720

Q2

1,24,03,85,133

Q3

1,09,86,45,271

Q4

1,08,99,79,840

Grand Total

Page 1 of 1 of Note-1(i)

4,52,35,58,964

<!-- page 14 -->

Note-1 (ii)

Statement showing Inter-State Sale for FY 2025-26
Sl. No. Name of Project/Station
1
Energy Sale (IEX) APPCPL
2 Energy Sale (IEX) NPTPL
2 Banking Export
4 Bilateral Sale
5 Bilateral Sale NPTPL
4 RE Sale
5 Deviation Export
B Total Energy Export Out Side
Quarterly

Unit
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH

Apr-25
4,375

May-25
20,525

Jun-25
24,884

Jul-25
20,805

Aug-25
30,520

Sep-25
23,077

Oct-25
32,619

3,750

3,875

5,040
12,000

14,792
2,160

28,320
-

26,736
-

-

765
8,890

2,403
26,802
Q1

41,924
77,616

1,491
39,248

2,483
61,323
Q2

2,187
52,000
1,52,571

3,549
36,168

(In MWH)
Dec-25
7,351
1,318
145
175
856
19,236
8,989
Q3
64,393

Nov-25
18,380

Statement showing Inter-State Sale for FY 2025-26
Sr.No.
1
2
3
4
5
6
7
8
9
10
11
12

Months/Periods
Apr-25
May-25
Jun-25
Qtr-1
Jul-25
Aug-25
Sep-25
Qtr-2
Oct-25
Nov-25
Dec-25
Qtr-3
Jan-26
Feb-26
Mar-26
Qtr-4
Grand Total

APPCPL
3,29,56,807.00
2,86,06,816.00
6,02,57,400.00
12,18,21,023.00
20,98,94,910.00
10,91,13,005.00
8,40,65,486.00
40,30,73,401.00
9,30,00,277.00
6,67,63,870.00
2,49,11,191.00
18,46,75,338.00
1,27,97,132.00
1,01,22,584.00
1,13,27,138.00
3,42,46,854.00
74,38,16,616.00

NER DSM
70,58,572.00
31,56,672.00
38,21,581.00
1,40,36,825.00
1,437.00
8,77,896.00
51,23,625.00
60,02,958.00
1,01,77,295.00
49,43,638.00
4,27,737.00
1,55,48,670.00
53,244.00
15,045.00
20,221.00
88,510.00
3,56,76,963.00

NPTPL

NTPC

IEX
58,880.00

-

-

-

-

73,87,632.00
73,87,632.00
2,18,74,255.00
1,39,04,893.00
2,58,91,079.00
6,16,70,227.00
6,90,57,859.00

-

-

58,880.00

-

17,960.00
17,960.00
76,840.00

GCIL
-

-

Reactive
24,623.00

POSCO

LC Interest

(In Rupees)
Others

-

11,866.00
11,866.00

-

23,143.00
23,143.00

-

7,684.00
7,684.00
7,532.00
7,532.00
50,225.00

-

-

-

-

13,629.00
30,195.00

-

-

-

20,73,482.00
26,928.00
21,00,410.00
2,104.00
2,104.00
21,57,332.00

-

-

-

-

Feb-26
2,171
2,015
1,400
1,230
140
6,955
Q4

NERLDC

24,623.00
16,566.00

Page 1 of 1 of Note-1(ii)

Jan-26
3,733
3,008
1,240
863
7
8,850

Total
4,00,98,882.00
3,17,63,488.00
6,40,90,847.00
13,59,53,217.00
20,99,12,913.00
10,99,90,901.00
8,92,25,883.00
40,91,29,697.00
10,31,77,572.00
7,37,80,990.00
3,27,61,172.00
20,97,19,734.00
3,47,24,631.00
2,40,62,586.00
3,72,45,970.00
9,60,33,187.00
85,08,35,835.00

Mar-26
8,563
9,012
530
520
3,968
22,594
38,399

TOTAL
1,97,003
74,888
25,100
17,849
3,32,980
3,32,980

<!-- page 15 -->

Note-1 (iii)

Month-wise / Division-wise "0801" Revenue Receipt for the year 2025-26
Sl.No.
1
2
3
4
5
6
7
8
9

1
2
3
4
5
6
7
8
9
10
11
12
13

1
2
3
4
5
6
7
8
9

Division
CE(P) office WEZ
Naharlagun
yupia
Capital
Tawang
Bomdilla
Seppa
Sagalee
Rupa
Pakke Kessang
Total of WEZ =
CE(P) office CEZ
Ziro
Kurung Kumey
YAZALI
Daporijo
Aalo
Yingkiong
Pasighat
Rumgong
Basar
Pania
Raga
Likabali
Mechuka
Total of CEZ =
CE(P) office EEZ
Roing
Deomali
Miao
Hayuliang
Namsai
Anini
Longding
Yatdam
Tezu
TOTAL of EEZ =
G/Total =
Qtly

Apr

May

Jun

Aug

Sept

5,29,53,227
2,22,63,994
5,45,96,693
75,59,802
62,95,454
14,10,246
2,69,269
7,37,20,381
1,65,244
21,92,34,310

Jul
139375891
5,98,73,430
2,60,39,606
2,54,79,119
41,70,345
15,69,860
15,69,860
86,253
4,53,45,222
16,95,115
30,52,04,701

4,61,71,695
1,90,48,565
3,92,15,253
35,18,340
76,23,725
11,72,628
1,86,877
1,41,54,436
25,788
13,11,17,307

4,57,16,623
1,16,60,953
6,72,17,793
30,71,037
51,37,626
15,58,649
62,634
2,39,38,788
2,32,190
15,85,96,293

3,70,61,946
1,69,87,694
2,55,16,078
42,86,571
77,02,196
50,62,017
6,21,992
2,42,99,725
3,65,110
12,19,03,329

7,80,57,976
2,17,07,218
2,44,76,020
36,73,343
49,98,248
15,01,881
80,000
2,61,26,782
2,73,670
16,08,95,138

16,04,730
2,68,945
7,30,254
15,08,120
18,74,505
12,08,787
2,97,78,250
4,30,810
10,67,788
1,68,225
3,04,694
13,70,381
0
4,03,15,489

13,89,872
3,45,930
6,52,240
8,20,534
26,06,336
10,82,467
3,13,02,242
3,30,072
10,92,000
2,85,996
1,03,400
19,78,921
2,14,714
4,22,04,724

8,61,433
2,86,044
8,21,152
8,80,362
26,90,079
15,60,232
4,00,06,747
9,42,484
5,43,734
2,11,359
16,98,608
16,77,571
4,47,108
5,26,26,913

16,95,115
3,35,897
7,00,115
12,99,473
21,30,954
11,74,575
2,47,56,320
7,88,947
9,18,026
2,19,079
10,99,991
17,16,494
2,59,928
3,70,94,914

9,43,665
3,39,989
6,99,075
15,24,892
35,35,536
15,25,994
3,86,45,605
8,78,519
8,67,216
2,22,868
8,78,403
24,24,326
0
5,24,86,088

9,83,482
9,07,478
9,83,482
13,45,201
36,53,596
15,66,839
3,92,45,616
1,10,808
9,85,976
4,69,942
3,10,000
17,77,729
36,53,596
5,59,93,745

29,39,238
9,88,268
32,32,767
2,56,968
48,96,510
6,96,549
6,63,556
3,01,696
4,24,910
1,44,00,462
18,58,33,258
Q1

28,60,805
11,40,402
25,07,911
9,15,223
56,35,135
6,15,539
6,77,292
3,55,711
6,17,262
1,53,25,280
21,61,26,297

40,89,294
11,91,489
3,94,624
8,83,873
61,97,824
5,81,508
10,03,961
3,35,737
5,80,449
1,52,58,759
28,71,19,982
68,90,79,537

88,09,983
5,95,223
11,38,405
34,09,422
66,08,886
14,24,996
10,65,365
3,66,017
13,67,510
2,47,85,807
36,70,85,422
Q2

48,90,856
6,78,508
34,69,933
8,60,022
74,61,287
5,35,346
8,73,027
7,39,245
6,70,628
2,01,78,852
19,45,68,269

33,53,644
14,35,289
38,80,695
78,446
1,06,09,791
6,65,997
8,36,517
8,81,032
14,79,355
2,32,20,766
24,01,09,649
80,17,63,340

Oct
0
5,20,98,877
39,20,691
2,18,14,432
37,46,339
48,02,497
9,65,404
5,19,688
8,61,81,570
2,01,017
17,42,50,515

Nov

Dec

5,08,42,666
1,91,65,334
2,11,84,887
41,62,821
26,15,601
2502433
2,15,000
4,63,96,763
3,91,438
14,74,76,943

4,78,46,070
1,44,30,209
1,86,10,856
37,33,486
95,64,531
12,39,884
9,45,777
3,41,67,448
40,793
13,05,79,054

10,76,085
1,83,018
6,67,871
14,65,270
26,88,750
12,74,989
1,08,17,846
9,47,700
9,03,162
1,84,890
3,09,331
21,45,896

14,23,416
3,17,583
15,33,962
2036382
25,63,665
15,66,628
1,27,17,136
9,47,700
16,71,180
6,02,041
6,25,294
31,04,128

13,42,602
3,17,583
9,22,169
12,95,743
18,80,852
18,51,509
96,30,172
1,20,283
19,09,553
15,33,962
5,78,937
16,59,417

2,26,64,808

2,91,09,115

2,30,42,782

30,35,370
6,69,144
44,20,994
7,12,325
59,56,794
8,22,157
5,95,775
8,22,157
20,50,421
1,90,85,137
21,60,00,460
Q3

36,83,499
34,78,059
47,07,138
12,56,732
1,22,75,292
6,15,657
57,22,595
9,93,643
15,80,327
3,43,12,942
21,08,99,000

34,83,751
19,30,323
35,04,067
9,69,987
82,59,817
5,56,114
6,67,820
9,31,594
11,72,806
2,14,76,279
17,50,98,115
60,19,97,575

Page 1 of 1 Note-1(iii)

Jan
0
5,78,51,850
1,54,86,717
1,58,33,238
88,24,443
2,36,80,617
13,39,668
67,685
4,47,59,624
4,20,260
16,82,64,102

Feb
2,11,30,813
1,58,50,939
2,90,79,049
91,22,126
85,26,242
1527118
4,98,404
59,54,001
38,591
9,17,27,283

Mar
11,00,64,682
6,63,17,615
2,50,72,347
2,33,48,649
60,10,496
81,95,624
25,52,317
0
4,46,82,024
5,01,296
28,67,45,050

TOTAL
24,94,40,573
61,59,22,788
21,16,34,267
36,63,72,067
6,18,79,149
9,07,12,221
2,24,02,105
35,53,579
46,97,26,764
43,50,512
1,84,65,53,452

12,84,687
5,03,012
8,96,334
15,42,715
28,52,977
11,08,360
1,58,74,930
1,98,446
20,59,305
1,76,038
2,95,282
22,79,514
9,83,703
3,00,55,303

16,75,449
3,70,653
8,48,859
1177810
31,62,875
11,69,718
1,07,43,463
3,85,935
26,81,120
11,88,579
3,00,000
30,86,933
2,79,761
2,70,71,155

10,91,253
7,60,315
5,29,367
13,70,339
26,83,232
16,92,647
88,01,936
0
2,16,915
2,37,167
4,00,000
20,89,863
68,517
1,99,41,551

1,53,71,789
49,36,447
99,84,880
1,62,66,841
3,23,23,357
1,67,82,745
27,23,20,263
60,81,704
1,49,15,975
55,00,146
69,03,940
2,53,11,173
59,07,327
43,26,06,587

30,03,537
5,71,461
27,23,399
8,37,360
51,10,462
5,11,417
8,21,845
8,56,722
8,44,430
1,52,80,633
21,36,00,038

37,59,434
1,14,661
37,11,270
6,38,149
58,61,022
5,16,710
9,31,977
7,75,072
12,60,468
1,75,68,763
13,63,67,201

51,37,968
10,28,791
29,22,051
23,03,962
37,41,243
4,79,818
7,41,803
8,21,308
30,50,334
2,02,27,278
32,69,13,879
67,68,81,118

4,90,47,379
1,38,21,618
3,66,13,254
1,31,22,469
8,26,14,063
80,21,808
1,46,01,533
81,79,934
1,50,98,900
24,11,20,958
2,76,97,21,570
2,76,97,21,570

Q4

<!-- page 16 -->

Note-1 (iv)
Summary of Sales (KWH) for the FY 2025-26
Particular
Agriculture Consumers
Bulk Mixed Consumers
Commercial Consumer (Non-Industrial)
Industrial Consumers
Non-Commercial Consumer (Domestic)
Public Lighting & Water Supply
Temporary Consumer
Grand Total

Apr
6,728.00
37,54,106.11
88,87,918.81
2,81,22,445.20
2,33,71,525.73
10,79,858.32
70,712.00
6,52,93,294.17

Q1
May
7,994.00
34,64,705.60
94,11,205.35
3,27,67,977.44
2,20,35,410.16
10,03,068.65
56,190.00
6,87,46,551.20

Jun
5,795.00
35,68,633.68
1,01,45,576.78
2,92,26,805.20
2,40,67,233.31
10,29,882.75
65,668.00
6,81,09,594.72

Apr
1,36,367.77
1,74,11,797.68
61963937.49
11,85,11,151.45
14,33,31,978.26
66,99,170.14
835536.68
34,88,89,939.47

Q1
May
1,40,620.55
1,75,05,810.32
67531761.17
13,78,20,058.32
13,97,80,854.12
63,88,929.03
763918.34
36,99,31,951.85

Jun
1,34,369.24
1,88,05,765.19
7,23,83,966.84
12,65,05,212.34
15,02,51,648.39
67,38,026.23
907840.94
37,57,26,829.17

Summary of Sales (Rs.) for the FY 2025-26
Particular
Agriculture Consumers
Bulk Mixed Consumers
Commercial Consumer (Non-Industrial)
Industrial Consumers
Non-Commercial Consumer (Domestic)
Public Lighting & Water Supply
Temporary Consumer
Grand Total

Qtr-1
20,517
1,07,87,445
2,84,44,701
9,01,17,228
6,94,74,169
31,12,810
1,92,570
20,21,49,440

Qtr-1
4,11,358
5,37,23,373
20,18,79,666
38,28,36,422
43,33,64,481
1,98,26,125
25,07,296
1,09,45,48,720

Jul

Q2
Aug

Sep

9,120
39,94,618
1,19,56,948
3,48,72,818
2,53,52,341.04
12,40,704
79,960
7,75,06,509

3,941
41,49,529
1,12,12,111
3,67,65,585
2,70,61,487.81
11,74,708
10,64,292
8,14,31,654

4,747
37,66,772
1,32,11,127
2,32,04,646
2,74,12,423.92
11,15,308
76,615
6,87,91,639

Jul
1,44,793.77
1,98,85,220.14
82754422.77
14,85,65,456.94
15,56,09,894
80,36,295.32
1008456.75
41,60,04,539

Q2
Aug
1,27,262.58
2,06,16,495.30
78176051.01
15,69,26,018.95
16,12,60,212
74,89,959.92
9896127.62
43,44,92,127

Sep
1,28,957.61
1,91,76,836.55
9,00,47,460.90
10,38,15,798.13
16,83,49,554
71,69,722.23
1200137.18
38,98,88,467

Qtr-2
17,808
1,19,10,919
3,63,80,186
9,48,43,050
7,98,26,253
35,30,720
12,20,867
22,77,29,803

Qtr-2
4,01,014
5,96,78,552
25,09,77,935
40,93,07,274
48,52,19,659
2,26,95,977
1,21,04,722
1,24,03,85,133

Page 1 of 1 of Note-1(iv)

Oct
3,631.00
35,28,901.15
1,06,05,872.85
2,45,15,772.81
2,54,57,564.10
10,55,525.40
75,136.80
6,52,42,404

Q3
Nov
3,300.00
33,20,786.21
1,13,02,958.57
2,24,42,242.52
2,41,39,440.93
11,43,134.71
73,534.77
6,24,25,398

Dec
8,388.00
40,63,152.95
1,11,57,816.45
2,34,73,618.34
2,47,64,934.72
11,02,648.13
1,82,068.00
6,47,52,627

Oct
1,27,545.32
1,83,89,082.05
76699829.11
10,76,24,440.10
15,85,89,171.03
69,34,099.07
1196268.45
36,95,60,435

Q3
Nov
1,26,198.02
1,74,17,664.47
80915320.53
9,82,94,570.91
15,33,80,562.28
74,67,684.87
1190265.19
35,87,92,266

Dec
1,41,804.06
2,03,22,153.98
8,06,04,237.67
10,29,84,887.37
15,67,64,392.13
73,12,524.04
2162569.66
37,02,92,569

Qtr-3
15,319
1,09,12,840
3,30,66,648
7,04,31,634
7,43,61,940
33,01,308
3,30,740
19,24,20,428

Qtr-3
3,95,547
5,61,28,901
23,82,19,387
30,89,03,898
46,87,34,125
2,17,14,308
45,49,103
1,09,86,45,270

Jan
10,640.00
43,54,189.68
96,19,352.90
2,35,84,685.80
2,51,50,826
11,36,730.75
1,51,349.00
6,40,07,774

Q4
Feb
7,343.00
45,63,827.20
93,12,422.53
2,37,63,242.56
2,46,99,053
11,41,642.95
54,455.00
6,35,41,986

Mar
5,476.00
44,27,196.40
93,56,102.77
2,37,14,973.36
2,32,44,447
10,60,810.85
57,263.00
6,18,66,269

Jan
1,46,827.08
2,15,61,365.90
72396496.53
10,26,55,893.21
15,85,03,723.54
75,86,509.14
1919547.86
36,47,70,363

Q4
Feb
1,36,207.83
2,23,82,600.70
71193053.6
10,44,09,833.37
15,78,45,126.15
76,80,698.39
1070310.68
36,47,17,831

Mar
1,29,558.35
2,19,41,537.89
7,20,71,016.52
10,57,68,410.75
15,21,56,651.45
73,24,453.62
1100017.38
36,04,91,646

Qtr-4
23,459
1,33,45,213
2,82,87,878
7,10,62,902
7,30,94,326
33,39,185
2,63,067
18,94,16,030

Grand Total
77,103
4,69,56,418
12,61,79,413
32,64,54,813
29,67,56,688
1,32,84,023
20,07,244
81,17,15,701

Qtr-4

Grand Total

4,12,593
6,58,85,504
21,56,60,567
31,28,34,137
46,85,05,501
2,25,91,661
40,89,876
1,08,99,79,840

16,20,512
23,54,16,330
90,67,37,554
1,41,38,81,732
1,85,58,23,767
8,68,28,072
2,32,50,997
4,52,35,58,964

<!-- page 17 -->

Note-2

Details of Expenditure under Power Purchase head during the Financial Year 2025-26
(Amount in Lakh)
LC BILL

MONTH
NEEPCO

CTUIL

1,141.53

517.03

PGCIL

SUPPLEMENTARY OTHER BILL

NTPC

NHPC

OTPC

TOTAL

1,322.94

48.67

344.54

3,374.71

CTUIL NEEPCO
3.81

PGCIL NTPC NHPC OTPC

DEVI

KHPPL

12.55

246.43

286.79

POSCO

APPCPL APDCL HPDCAPL

TOTAL
549.58

MISC. EXP. TOTAL EXP

DEVIATION REACTIVE NERLDC
73.30

10.48

TOTAL
1.00

4,009.07

NERPC Board Fund
25-26

5.00

5.00

APSERC Annual
License Fee 2025-26

83.78

Apr-25

1,202.69

676.93

1,464.09

37.29

332.60

May-25
Jun-25
Jul-25

3,713.60

273.29

12.55

222.41

563.20

-

1,525.53

474.04

1,629.55

61.56

351.18

1,804.07

736.55

1,515.09

112.12

336.05

4,041.86
4,503.88

2,241.21

761.97

1,487.46

114.41

255.92

4,860.97

9.43

12.63

516.96

209.46

44.38

12.55

472.42

187.38

36.52

12.79

605.73

181.52

103.09

1,071.45

140.02

-

-

10.55

748.48
716.73

374.76
309.10

0.05

939.65

134.45

0.09

150.57

-

-

3.00

10.36

385.12
319.51

-

10.36

144.90

1.00

10.36

1.02
Sep-25

Oct-25

117.00
2,388.43
2,182.91
1,920.81

563.66
692.94
562.11

1,563.26
1,532.98
1,408.57

109.75
110.06
114.54

320.90
351.13
344.82

Nov-25

Dec-25

18.58
9.43
70.27

1,588.41

595.06

1,432.57

101.31

310.85

4,028.20
-

9.46

834.05
806.33
546.35

143.40
77.22
149.21

50.71

12.38

422.04

162.98

1,410.09

646.98

1,465.14

59.68

339.32

9.34

597.20
1,103.08

702.36
1,292.37

1,558.61
1,252.26

58.50
44.98

345.85
405.35

3,262.52
4,098.04

35.48

19,105.96

8,222.00

-

17,632.52

972.87

4,038.51

49,971.86

10.03
10.36
10.36

28.71
28.14
149.33

-

-

-

-

-

-

32.50

32.50

606.86
-

134.54

10.39

144.93
-

-

10.25

0
287.19 0

4,779.99
4,803.42

317.52

113.75

141.62

5.15

262.58

81.64

237.73

587.10

581.16

0.03

10.25

591.44 0.60

1,179.14

216.32

59.18

207.88
-

547.34
-

100.30

0.36

10.25

110.91 0.00
-

3,920.77
4,098.04

28.48

159.83

-

-

-

5,246.73

1,874.94

1,304.23

Details of Power Purchase & Transmission Charges
Particular
Power Purchase Epense:
Transmission Charge:
PGCL
CTUIL
Dikshi (Devi)
Grand Total

IT Divn for
117.00 enhancement of LC
amount of NTPC
6,034.24
5,803.52
5,278.80

0.07
0.07
0.05

-

519.99

Bureau of Energy
5,946.52 Efficiency (Notional
Penalty)
1.02 Court fee at APTEL

18.61
17.71
138.92

276.94

Q1
1,21,62,17,000.00

Q2
1,51,89,67,333.60

Q3
1,37,46,90,000.00

Q4
1,17,48,99,000.00

Cumulative
5,28,47,73,333.60

37,73,000.00
16,68,00,000.00
2,60,25,000.00
1,41,28,15,000.00

38,13,000.00
20,62,18,000.00
3,48,91,666.40
1,76,38,90,000.00

37,55,000.00
18,50,11,000.00
2,60,25,000.00
1,58,94,81,000.00

46,42,000.00
26,41,71,000.00
2,60,25,000.00
1,46,97,37,000.00

1,59,83,000.00
82,22,00,000.00
11,29,66,666.40
6,23,59,23,000.00

Page 1 of 3 of Note-2

-

-

9,105.72

-

2,299.81

0.72

124.00

2,424.53

696.00

857.12

APSERC Petition
Fee

5,175.46
5,540.12

12.79

-

-

3.00

595.02

Grand
Total

4,935.62

1,059.53
905.36
778.62

0.00
3,921.21
-

Mar-26

12.79
12.38
12.79

-

Jan-26
Feb-26

4,946.00
4,870.02
4,350.85

REMARKS

696.00

62,359.23

Petition fees of
APSERC

Legal fee of
Universal Legal

IT Division for
revalidation of LCs &
opening of new LC of
NHPC

<!-- page 18 -->

Details of Bills against Dikshi Hydro Electricty Project (Devi) for FY 2025-26
Month
Apr-25
Less: 10% of Free Power as per MOA
Energy for payment
May-25
Less: 10% of Free Power as per MOA
Energy for payment
Jun-25
Less: 10% of Free Power as per MOA
Energy for payment
Jul-25
Less: 10% of Free Power as per MOA
Energy for payment
Aug-25
Less: 10% of Free Power as per MOA
Energy for payment
Sep-25
Less: 10% of Free Power as per MOA
Energy for payment
Oct-25
Less: 10% of Free Power as per MOA
Energy for payment
Nov-25
Less: 10% of Free Power as per MOA
Energy for payment
Dec-25
Less: 10% of Free Power as per MOA
Energy for payment
Jan-26
Less: 10% of Free Power as per MOA
Energy for payment
Feb-26
Less: 10% of Free Power as per MOA
Energy for payment
Mar-26
Less: 10% of Free Power as per MOA
Energy for payment
Grand Total

Generation (KWH)
2805048
-280504.8
2524543.2
5402304
-540230.4
4862073.6
8631504
-863150.4
7768353.6
8631504
-863150.4
7768353.6
11452752
-1145275.2
10307476.8
14161608
-1416160.8
12745447.2
9726936
-972693.6
8754242.4
7096152
-709615.2
6386536.8
4884024
-488402.4
4395621.6
3721368
-372136.8
3349231.2
2742264
-274226.4
2468037.6
3539304
-353930.4
3185373.6

Rate
(Rs.)

Amount
(Rs.)

Transmission Charge
Total Bill Amount (Rs.)
(Rs.)

5.25

1,32,53,851.80

86,75,000.00

1,97,12,185.13

22,16,666.67

5.25

2,55,25,886.40

86,75,000.00

3,19,84,219.73

22,16,666.67

5.25

4,07,83,856.40

86,75,000.00

4,72,42,189.73

22,16,666.67

5.25

4,07,83,856.40

86,75,000.00

4,72,42,189.80

22,16,666.60

5.25

5,41,14,253.20

86,75,000.00

6,05,72,586.60

22,16,666.60

5.25

6,69,13,597.80

1,75,41,666.40

8,34,05,264.20

10,50,000.00

5.25

4,59,59,772.60

86,75,000.00

5,46,34,772.60

-

5.25

3,35,29,318.20

86,75,000.00

4,22,04,318.20

-

5.25

2,30,77,013.40

86,75,000.00

3,17,52,013.40

-

5.25

1,75,83,463.80

86,75,000.00

2,62,58,463.80

-

5.25

1,29,57,197.40

86,75,000.00

2,16,32,197.40

-

5.25

1,67,23,211.40
39,12,05,278.80

86,75,000.00
11,29,66,666.40

2,53,98,211.40
49,20,38,611.99

Deduction (Rs.)

1,21,33,333.21

Page 2 of 3 of Note-2

<!-- page 19 -->

Period/Month
Apr-25
May-25
Jun-25
Jul-25
Aug-25
Sep-25
Oct-25
Nov-25
Dec-25
Jan-26
Feb-26
Mar-26
Grand Total

Details of Bills against Khantang Small Hydro Power Project for FY 2025-26
Other
Generation
Amount
Charges Total Bill Amount (Rs.)
(KWH)
(Rs.)
Rate (Rs.)
(Rs.)
5208755.251
4.27
22241384.92
0.00
22241384.92
4905361.01
4.27
20945891.51
0.00
20945891.51
4388253.853
4.27
18737843.95
0.00
18737843.95
4388253.853
4.27
18737843.95
0.00
18737843.95
4250989.137
4.27
18151723.61
0.00
18151723.61
3358324.917
4.27
14340047.40
0.00
14340047.40
3494351.286
4.27
14920879.99
0.00
14920879.99
3816824.995
4.27
16297842.73
0.00
16297842.73
2663924.322
4.27
11374956.85
0.00
11374956.85
1912052.98
4.27
8164466.22
0.00
8164466.22
1386015.148
4.27
5918284.68
0.00
5918284.68
2060791.192
4.27
8799578.39
0.00
8799578.39
4,18,33,897.94
17,86,30,744.22
17,86,30,744.22

Details of Bills against Sumbachu Small Hydro Power Project for FY 2025-26
Other
Generation
Amount
Period/Month
Charges Total Bill Amount (Rs.)
(KWH)
(Rs.)
Rate (Rs.)
(Rs.)
Apr-25
5208755.251
4.27
22241384.92
0.00
22241384.92
May-25
4905361.01
4.27
20945891.51
0.00
20945891.51
Jun-25
4388253.853
4.27
18737843.95
0.00
18737843.95
Jul-25
4388253.853
4.27
18737843.95
0.00
18737843.95
Aug-25
4250989.137
4.27
18151723.61
0.00
18151723.61
Sep-25
3358324.917
4.27
14340047.40
0.00
14340047.40
Oct-25
3494351.286
4.27
14920879.99
0.00
14920879.99
Nov-25
3816824.995
4.27
16297842.73
0.00
16297842.73
Dec-25
2663924.322
4.27
11374956.85
0.00
11374956.85
Jan-26
1912052.98
4.27
8164466.22
0.00
8164466.22
Feb-26
1386015.148
4.27
5918284.68
0.00
5918284.68
Mar-26
2060791.192
4.27
8799578.39
0.00
8799578.39
Grand Total
4,18,33,897.94
17,86,30,744.22
17,86,30,744.22

Remarks

Remarks

Page 3 of 3 of Note-2

<!-- page 20 -->

Note - 3
Operation and Maintenance Expenses 2025-26
Sl. No

Description

(A)

Administrative and General Expenses
1. Office Expenses(OE)
2. Vehicle Fuel (OE-POL Vehicle)
3. Other Charges (OC)
4.ORE
5. Digital Equipment
6. Advtisement & Publicity

Grand Total
(B)

Repairing and Maintenance Expense :1. 4801 MoA
2. 2801- MoA i/c POL DG Set
3. Repair & Maintenance

Grand Total
.(C)

Employee Expenses :1. Salary
2. Wages
3. LTC
4. DTE/TA
5. Medical

Grand Total

Apr-25

May-25

Jun-25

-

-

-

-

-

-

3,638.25
1,493.16
5,131.41

Jul-25

Aug-25

Sep-25

1,397.07
20.16

4.01
19.26

11.66
30.35

10.25
26.24

11.23
39.49

5.11
-

11.79
48.45

-

1,417.23

23.27

42.01

36.49

50.72

1.38
6.49

-

-

-

1.80
1.80

5.83
5.83

7.50
7.50

1.00
1.00

2,127.97
1,534.14
3,662.11

2,153.43
1,523.44
3,676.87

2,067.06
1,428.49
3,495.55

2,039.88
1,414.66
3.14
3,457.68

2,021.09
1,441.54
3,462.63

2,855.68
1,479.99
1.93
4,337.60

2,247.69
1,443.87
2.87
3,694.43

Page 1 of 1 of Note-3

Oct-25

Nov-25

Dec-25

Jan-26

Feb-26

Mar-26

Total

59.18
56.07

1,359.76
205.11

10.77
71.01

31.95
147.20

239.92
39.52
7.46
1,851.77

2,870.06
445.13
284.02
39.52
7.46
3,646.19

1.00
1.00

11.72
11.72

14.47
14.47

3,950.00
2,500.00
136.20
6,586.20

3,950.00
2,500.00
179.52
6,629.52

2,203.50
1,460.51
3,664.01

2,284.30
1,404.45
7.00
16.86
3,712.60

2,290.30
1,343.74
16.78
26.60
3,677.42

1,987.30
1,210.59
41.22
119.24
3,358.34

27,916.45
17,178.57
65.00
170.63
45,330.65

<!-- page 21 -->

Note - 4

Month-wise / Division-wise Cumulative Outstanding for the year 2025-26
Division

April

May

Naharlagun
Capital
Sagalee
Tawang
Bomdila
Seppa
RpED (Rupa)
YuED (Yupia)
PkED (Pakke Kessang)

29,58,21,810
87,22,76,450
10,70,48,760
21,17,32,259
14,58,49,101
16,82,14,608
49,67,89,148
34,02,57,215
3,27,67,522

Total of WEZ =
CWZ

10
11
12
13
14
15
16
17
18
19
20
21
22

23
24
25
26
27
28
29
30
31

January

February

354057589
1007724062
119885643.4
265648494.6
166868717.5
195217585.3
551149472.1
409979352.3
38286255.01

367151938
1055928627
122753669.2
276733690.9
174458646.9
204255065.5
581430774.3
448800946.9
40131935.47

401060796.4
1070524397
124583743.1
278425891
178760292.4
208419479
628386092.2
464335436.4
41012548.81

(IN Rs.)
March
Qtr-4
39,09,17,346
1,06,36,40,619
12,63,94,407
28,17,72,920
18,01,81,532
21,05,07,093
64,05,40,338
46,92,77,830
4,15,14,377

3046133107

3108817171

3197964575

3271645294

3395508677

3,40,47,46,461

11,84,84,656
18,90,48,453
14,26,51,324
2,18,24,347
18,47,90,049
6,41,81,111
4,73,20,610
52,40,489
2,10,93,942
10,70,58,625
1,41,22,932
5,19,907
11,09,56,283

122603047.3
192473993.5
145899559.4
22765875.58
193866601
64633473.58
48797128.16
6027200.95
21641450.27
109106939
14658515.77
973290.04
113620735.7

124301471.2
195675423.7
148976615.6
23516654.73
89490897.39
66053431.64
49162231.3
7121046.24
21836508.23
111089247.9
13992915.96
895340.84
115437257.6

12,98,32,528
19,90,56,640
15,22,34,285
2,40,91,598
9,63,53,141
7,11,24,739
5,01,22,161
79,57,161
2,22,75,388
11,27,54,081
1,50,80,811
7,80,170
11,79,00,491

132704133.3
202383021.5
156532483.7
24919055.51
101909655.1
73023212.03
51386465.32
9110556.94
22886329.48
114302419.6
15270512.13
825187.8
120434374.4

134890663.8
205481896.3
159351653.8
25729834.6
118514532.4
74566934.35
51914837.96
9314377.61
22491043.19
116392090.7
14781832.44
827331.09
123045699.9

13,78,44,674
20,52,55,684
16,15,66,882
2,60,56,718
12,29,65,787
7,62,69,534
5,11,05,791
1,01,99,154
2,30,30,019
11,83,01,038
1,51,24,971
8,15,499
12,50,70,911

1,02,32,58,444

1,02,72,92,727

1057067810

967549042.5

999563195.7

1025687407

1057302728

1,07,36,06,661

12,86,66,466
68,10,56,757
28,45,31,135
3,93,21,275
96,18,18,744
83,92,592
17,81,54,079
4,27,38,261
9,95,91,746
2,42,42,71,054

13,39,62,546
68,85,99,513
29,93,62,852
4,05,30,863
97,79,53,584
89,25,282
18,18,63,909
4,39,26,067
10,29,63,132
2,47,80,87,749

13,89,44,322
69,52,76,521
32,03,71,544
4,18,41,165
99,86,38,961
93,04,849
18,59,39,316
4,49,61,795
10,80,12,931
2,54,32,91,404

144244711.4
702414070.4
330024161.4
43212681.36
1020370320
9843886.39
190033621.6
46188855.56
112605821.4
2598938129

150709370.9
705762238.3
336640832
44128180.94
1036605430
10293230.61
189252606.6
47142480.92
120274523
2640808893

15,54,75,759
71,18,64,161
34,41,57,632
4,51,60,650
1,05,50,39,579
1,07,19,795
19,34,53,296
4,82,86,877
12,45,41,095
2688698845

160584991.8
719780716.8
353633591.9
46383722.22
1073807897
11300825.01
197586096.6
49465090.81
128249618.3
2740792550

165466343
726562894.8
361477876.5
47773805.69
1094457826
11865954.4
201597197.7
50783313.41
129856666.4
2789841878

16,85,64,166
73,00,57,772
36,62,86,951
4,59,93,452
1,11,46,97,408
1,23,94,322
20,45,63,520
5,19,52,987
12,69,54,533
2,82,14,65,111

6,17,05,71,313

6,25,36,42,238

6,46,68,48,239

6,60,33,50,066

6702139046

6717175107

6886226616

7038125251

7242653283

7,29,98,18,233

3974292194
2196279119
6170571313

3983380632
2270261606
6253642238

4117393670
2349454569
6466848239

4171867486
2431482580
6603350066

4186194677
2515944369
6702139046

4123568653
2593606453
6717175107

4207808038
2678418578
6886226616

4273089077
2765036173
7038125251

4390886907
2851766375
7242653283

4360962981
2938855252
7299818233

October

November

34,83,71,467
94,02,50,918
11,48,64,521
24,41,40,921
15,79,33,699
18,28,13,288
54,82,36,146
39,26,72,017
3,62,19,068

September
Qtr-2
33,11,30,555
96,27,58,987
11,67,88,402
25,12,36,748
16,16,41,984
18,72,54,362
57,58,64,011
40,94,64,490
3,66,26,397

30,90,17,701
89,66,02,004
10,90,28,114
22,23,90,483
15,03,91,563
17,20,22,492
52,70,45,531
36,09,52,759
3,36,21,486

31,88,09,299
91,53,84,274
11,28,07,165
23,52,66,133
15,79,53,978
17,83,68,825
51,65,05,701
37,20,87,712
3,52,77,585

343462678.7
985557055.9
118554655.3
258491086.7
164614205.1
191911828.7
547569922.6
398418839.8
37552833.97

2,67,07,56,873

2,78,10,72,134

2,81,55,76,482

2,84,24,60,673

2,96,55,02,047

3,03,27,65,935

Ziro
Kurung Kumey
Daporijo
Yingkiong
Pasighat
Aalo
Rumgong
Basar
PaED (Pania)
RaED (Raga)
LiKED (Likabali)
MeED (Mechuka)
YzED (Yazali)

11,96,33,422
17,57,21,865
12,72,42,940
1,87,26,852
13,51,39,746
6,21,92,009
4,30,57,785
44,71,432
1,88,70,711
10,00,70,082
1,31,24,136
5,28,450
9,93,75,076

12,16,64,632
17,89,32,392
13,12,95,838
1,96,08,016
15,41,79,543
6,47,02,126
4,42,73,995
44,46,112
1,92,81,915
10,20,08,436
1,32,07,253
5,24,003
10,19,20,999

12,44,86,586
17,94,48,082
13,52,11,277
1,91,30,300
14,83,34,813
6,58,76,034
4,49,24,507
51,39,657
1,97,75,628
10,28,85,955
1,35,31,829
4,79,737
10,34,38,926

11,61,94,107
18,26,26,923
13,67,90,008
2,01,56,781
17,29,05,761
6,40,94,699
4,53,63,708
52,07,372
2,02,92,078
10,41,92,284
1,26,13,274
4,71,538
10,60,01,977

11,61,17,880
18,57,97,977
13,96,73,532
2,08,34,985
19,64,66,948
6,49,46,783
4,61,63,332
52,46,324
2,08,11,405
10,50,80,010
1,30,62,184
4,88,055
10,85,69,029

Total of CEZ =
EEZ

91,81,54,506

95,60,45,261

96,26,63,332

98,69,10,510

Roing
Deomali
Miao
Hayuliang
Namsai
Anini
Longding
YaED (Yatdam)
Tezu
TOTAL of EEZ =

11,86,63,447
66,45,88,172
26,85,93,495
3,86,02,545
90,97,31,491
80,27,939
16,84,31,646
3,98,21,721
9,50,15,296
2,31,14,75,751

12,36,55,247
67,22,24,967
27,11,49,885
3,95,87,450
93,03,93,532
83,83,322
17,22,70,050
4,19,32,994
9,76,01,247
2,35,71,98,693

12,91,86,046
67,34,52,636
27,55,58,636
3,80,37,263
94,66,22,572
88,16,411
17,58,93,249
4,17,98,674
10,29,66,012
2,39,23,31,499

Grand Total

5,90,03,87,130

6,09,43,16,088

Principal

3856672110
2043715020
5900387130

3973192532
2121123556
6094316088

WEZ

1
2
3
4
5
6
7
8
9

December
Qtr-3
36,63,55,361
1,03,15,94,863
12,10,52,472
27,45,52,768
17,03,65,354
19,97,28,147
57,03,38,339
42,47,81,538
3,91,95,735

June
Qtr-1
31,62,16,375
91,81,18,490
11,06,91,843
22,92,81,718
15,32,19,218
17,41,31,718
50,98,82,402
36,95,71,668
3,44,63,051

Sl.No.

Late Payment Surcharge

Total

July

August

Page 1 of 2 of Note-4

<!-- page 22 -->

Statement Showing Adjusted Trade Receivable :
Opening Trade Receivables (Adjusted)

Q1
3,17,19,03,397

Q2
6,17,05,71,313

Q3
6,60,33,50,066

Q4
3,17,19,03,397

Closing Trade Receivables

6,17,05,71,313

6,60,33,50,066

6,88,62,26,616

7,29,98,18,233

6,17,05,71,313

6,60,33,50,066

3,71,43,23,219
3,17,19,03,397

4,12,79,14,836
3,17,19,03,397

Revenue Grant For Closing Trade Receivable*
Adjusted Closing Trade eceivable

* Note: As per Order issued by Govt Of Arunachal Pradesh, adjusted Rs. 1542882558.40 /- (Rs. ₹ 2,58,50,32,278 in Previous years) as grant against closing Trade Receivables,
to maintain the operational efficency, the Grant is included under overall allocation of fund released to the Dept. of Power.

Page 2 of 2 of Note-4

<!-- page 23 -->

Note - 4(i)
State Government Department's Outstanding Electricity Dues, Revenue Billed and Revenue Realsied during FY 2025-26

Month

A

Apr-24
May-24
Jun-24
Jul-24
Aug-24
Sep-24
Oct-24
Nov-24
Dec-24
Jan-25
Feb-25
Mar-25

Outstanding up to the
end of previous month

Revenue Billed during
the month

Total amount due up to
the current month

Revenue realised during
the month

Revenue Direct debited
by Govt. of Arunachal
Pradesh

Total Revenue realised
during the month

Outstanding Amount
up the month under
the report

(in ₹)

(in ₹)

(in ₹)

(in ₹)

(in ₹)

(in ₹)

(in ₹)

B

C

D=B+C

E

F

G=E+F

H=D-G

-1428719.15

21271933.94

19843214.79

18150547.01

20264813.56

38415360.57

366584.53

4160

370744.53

38044616.04

38044616.04

31547321.78

69591937.82

1245397.73

115192933.3

116438331

-46846393.19

-46846493.19

17027634.52

-29818858.67

349110.66

14432581.64

14781692.3

-44600550.97

-44600550.97

19249324.35

-25351226.62

169333.39

3256037.55

3425370.94

-28776597.56

-28776597.56

16494439.06

-12282158.5

548116.96

6503916.25

7052033.21

-19334191.71

-19334191.71

20045303.09

711111.38

288539

0

288539

422572.38

422572.38

25802113.75

26224686.13

1966114.37

0

1966114.37

24258571.76

24258571.76

20937713.39

45196285.15

796061.65

0

796061.65

44400223.5

44400223.5

17732543.3

62132766.8

390718.14

0

390718.14

61742048.66

61742048.66

16193361.4

77935410.06

1173476.21

0

1173476.21

76761933.85

76761933.85

27242757.49

104004691.3

1786457.44

110064679.7

111851137.2

-7846445.83

Page 1 of 1 of Note-4(i)

1685643.78

7024

1692667.78

18150547.01

<!-- page 24 -->

Note-5
Sl. No. Name of Project/Station
1 KOPILI-I (NEEPCO)
2 KOPILI-II (NEEPCO)
3 KHANDONG (NEEPCO)
4 RHEP (NEEPCO)
Free Energy (Received)
5 DOYANG (NEEPCO)
6 LOKTAK (NHPC)
7 SUBANSIRI LOWER (NHPC)
8 PARE (NEEPCO)
Free Energy (Received)
9 KAMENG (NEEPCO)
Free Energy (Received)
10 AGBPP (NEEPCO)
11 AGTCCPP (NEEPCO)
12 BgTPP (NTPC)
13 ONGC TPCL (Palatana)
14 FARAKKA (NTPC) Seller Per.
15 KAHALGAON (NTPC) Seller Per.
16 TALCHAR (NTPC) Seller Per.
17 Banking Receipet
18 Energy Import (IEX)
19 Deviation Import
A Total Energy Import i/c Free

1
2
3
4
5
6
7
B

Energy Export Outside the State
Energy Sale (IEX) APPCPL

Energy Sale (IEX) NPTPL
Banking Export
Bilateral Sale

Bilateral Sale NPTPL

RE Sale
Deviation Export
Total Energy Export Out Side
Qtrly
C=A-B Energy Injectected in State

Transmission Loss (Inter state)
Transmission Loss (Inter state)
Transmission Loss (Intra State)
Transmission Loss (Intrastate)
D

Transmission Loss on C
Qtrly
E=C-D Net Energy Injected in State

STATION WISE DETAILS OF ENERGY DRAWL AND EXPORT DURING 2025-26
May-25
Jun-25
Jul-25
Aug-25
Sep-25
Oct-25
2,228
4,723
5,615
6,426
7,134
7,324
967
1,011
1,057
1,083
989
743
336
685
1,277
1,229
6,438
9,762
8,654
10,898
9,925
5,500
11,957
18,128
16,070
20,238
18,431
10,215
236
1,366
2,051
3,264
3,513
2,272
1,041
3,654
3,758
3,519
3,603
3,765

Unit
MWH
MWH
MWH
MWH
MWH
MWH
MWH

Apr-25
1,537
691
3,343
6,210
108
407

MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH

1,416
1,982
4,785
13,730
7,891
2,943
19,870
9,786
1,610
1,004
1,215
19,154
1,733
99,414

2,706
3,786
9,176
26,065
7,706
3,173
24,297
10,169
1,997
1,059
1,365
6,580
6,179
1,27,127

4,547
6,359
11,216
32,321
7,883
3,014
21,643
9,624
1,979
1,002
1,284
2,115
4,515
1,46,146

3,935
5,505
15,638
44,848
8,228
5,676
22,676
7,215
1,965
1,041
1,245
672
1,342
1,57,528

4,843
6,775
16,704
47,919
8,305
4,568
25,668
8,869
1,990
1,034
1,312
658
1,74,759

4,388
6,138
13,746
39,426
7,450
3,765
24,665
9,702
1,886
767
1,178
1,625
1,434
1,61,041

2,842
3,976
11,560
33,080
7,686
3,832
22,001
9,701
2,001
941
1,363
637
289
1,30,954

1,733
2,425
9,029
22,192
8,014
4,939
23,836
8,644
1,410
1,050
1,189
3,342
3,311
1,08,327

MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH

4,375

20,525

24,884

20,805

30,520

23,077

32,619

18,380

3,750

3,875

5,040
12,000

14,792
2,160

28,320
-

26,736
-

-

-

2,403
26,802

1,491
39,248
Q2
1,18,280

1,13,436

2,187
52,000
1,52,571
1,09,042

3,549
36,168
Q3
94,786

856
19,236

1,00,325

41,924
77,616
1,04,221

2,483
61,323

MWH

765
8,890
Q1
90,524

%
MWH
%
MWH

3.80
3435.39
3.25
2942.04

3.53
3541.46
3.25
3260.55

3.37
3514.34
3.25
3387.19

3.83
4530.12
3.25
3844.10

3.71
4208.46
3.25
3686.65

3.43
3740.13
3.25
3543.86

3.75
3554.47
3.39
3213.25

MWH

6,377
Q1
84,147

6,802

6,902
20,081
97,320

8,374
Q2
1,09,906

7,895

7,284
23,553
1,01,758

6,768
Q3
88,018

MWH

93,523

1,05,540

Page 1 of 5 of Note-5

Nov-25
2,328
121
223
3,618
6,720
546
3,657

Jan-26

Feb-26

Mar-26

2105.52
61.44

1903.49
0.00

2260.21
1748.61

234
1,905
3,538
421
1,324
2,438
882
1,233
5,139
12,780
8,772
4,171
25,205
10,167
2,122
1,076
684
20,797
8,324
2,863
1,16,242

206
1,451
2,694
312
1,023
1,919
695
973
4,032
9,925
7,978
3,597
16,812
10,032
1,808
850
1,040
26,007
7,162
1,026
1,01,446

348
4,019
7,463
514
1,116
3,995
1,749
2,446
5,356
13,825
8,094
2,635
20,562
8,786
1,951
793
1,285
29,730
7,057
1,25,731

Total
45,115.82
8,629.01
4,910.87
67,893.43
1,26,086.60
15,137.28
28,283.10
9,119.47
30,870.24
43,185.61
1,12,471.07
3,11,438.05
96,921.39
46,267.70
2,70,182.98
1,12,269.25
22,385.17
11,663.77
14,149.16
89,696.21
66,208.22
26,703.48
15,59,587.87

3,733
3007.75
1,240
863
7
8,850
Q4
1,07,392

2,171
2,015
1,400
1,230
140
6,955

89,090

7,351
1,318
145
175
8,989
64,393
1,01,885

94,491

8,563
9,012
530
520
3,968
22,594
38,399
1,03,138

1,97,003
15,352
74,888
25,100
2,788
17,849
3,32,980
3,32,980
12,26,608

3.90
3474.52
3.39
3020.16

4.22
4299.55
3.39
3453.90

4.73
5079.63
3.39
3640.58

4.00
3779.62
3.39
3203.23

4.27
4403.97
3.39
3496.36

3.88
47561.67
3.32
40691.86

6,495

7,753
21,016
94,132

8,720
Q4
98,671

6,983

7,900
23,603
95,237

88,254
88,254
11,38,355

82,596

Dec-25
1,532
158
373
2,381
4,422
535
1,414
767
1,135
1,588
6,089
15,328
8,914
3,955
22,948
9,574
1,668
1,046
989
13,162
8,883
4,013
1,10,874

87,508

<!-- page 25 -->

2,81,416
State Own Generation
1 Sumbachu (HPDCL)
2 DHPD Generation
3 DIKSHI HEP
Free Energy (Received)
4 Khantang HEP
5 Solar Generation
6 Diesel Generation
F Total State Own Generation
G=E+F Net Input Energy

MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH

Total Power Purchase (MU)
Qrtr
C

Energy Sold in State
Qtr

MWH
Q1

305
3,957
2,525
281
5,209
93
39
12,407
96,554

442
4,463
4,862
540
4,905
87
31
15,331
1,08,853

401
4,438
7,768
863
4,388
79
30
17,968
1,15,288

496
4,459
10,307
1,145
4,251
66
35
20,759
1,30,664

517
4,264
12,745
1,416
3,358
49
41
22,391
1,27,931

469
3,754
13,706
1,523
1,808
60
68
21,389
1,23,146

32
3,732
8,754
973
3,494
59
29
17,073
1,05,091

288
4,432
6,387
710
3,817
59
27
15,719
98,315

281
5,267
4,396
488
2,664
57
21
13,174
1,07,305

214
4,229
3,349
372
1,912
31
25
10,131
1,08,803

107
3,566
2,468
274
1,386
24
20
7,845
95,352

228
4,787
3,185
354
2,061
19
16
10,650
1,05,887

3,779
51,346
80,453
8,939
39,254
683
381
1,84,836
13,23,191

1,11,821
Q1

1,42,457

1,64,114
4,18,392

1,78,287
Q2

1,97,150

1,82,430
5,57,867

1,48,027
Q3

1,24,046

1,24,047
3,96,120

1,26,373
Q4

1,09,290

1,36,381
3,72,045

17,44,424

65,293

68,747

68,110
2,02,149 Q2

77,507

81,432

68,792
65,242
2,27,730 Q3

62,425

64,753
64,008
1,92,420 Q4

63,542

61,866
1,89,416

8,11,716
8,11,716

Page 2 of 5 of Note-5

<!-- page 26 -->

Power Purchase Details
Sl. No. Name of Project/Station
Long Term PPA
1 KOPILI-I (NEEPCO)
2 KOPILI-II (NEEPCO)
3 KHANDONG (NEEPCO)
4 RHEP (NEEPCO)
Free Energy (Received)
5 DOYANG (NEEPCO)
6 LOKTAK (NHPC)
7 SUBANSIRI LOWER (NHPC)
8 PARE (NEEPCO)
Free Energy (Received)
9 KAMENG (NEEPCO)
Free Energy (Received)
10 AGBPP (NEEPCO)
11 AGTCCPP (NEEPCO)
12 BgTPP (NTPC)
13 ONGC TPCL (Palatana)
14 FARAKKA (NTPC) Seller Per.
15 KAHALGAON (NTPC) Seller Per.
16 TALCHAR (NTPC) Seller Per.
Total
Qtrly
16
17
19

1
2
3
4
5
6

Short Term
Banking Receipet
Energy Import (IEX)
Deviation Import
Total
Qtrly
Own Generation
Sumbachu (HPDCL)
DHPD Generation
DIKSHI HEP
Free Energy (Received)
Khantang HEP
Solar Generation
Diesel Generation
Total
Qtrly
Qtrly - Grand Total

Unit

Apr-25

MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH
MWH

May-25

Q1

Aug-25

Sep-25

Oct-25
7,324
743
1,229
5,500
10,215
2,272
3,765

2,328
121
223
3,618
6,720
546
3,657

4,388
2,842
6,138
3,976
13,746
11,560
39,426
33,080
7,450
7,686
3,765
3,832
24,665
22,001
9,702
9,701
1,886
2,001
767
941
1,178
1,363
1,57,983
1,30,028
4,87,597 Q3

1,733
2,425
9,029
22,192
8,014
4,939
23,836
8,644
1,410
1,050
1,189
1,01,673

Dec-25

Jan-26

Feb-26

Mar-26

Total

1,532
2,106
158
61
373
234
2,381
1,905
4,422
3,538
535
421
1,414
1,324
767
2,438
1,135
882
1,588
1,233
6,089
5,139
15,328
12,780
8,914
8,772
3,955
4,171
22,948
25,205
9,574
10,167
1,668
2,122
1,046
1,076
989
684
84,816
84,259
3,16,517 Q4

1,903
206
1,451
2,694
312
1,023
1,919
695
973
4,032
9,925
7,978
3,597
16,812
10,032
1,808
850
1,040
67,251

2,260
1,749
348
4,019
7,463
514
1,116
3,995
1,749
2,446
5,356
13,825
8,094
2,635
20,562
8,786
1,951
793
1,285
88,945
2,40,454

45,116
8,629
4,911
67,893
1,26,087
15,137
28,283
9,119
30,870
43,186
1,12,471
3,11,438
96,921
46,268
2,70,183
1,12,269
22,385
11,664
14,149
13,76,980
13,76,980

4,723
1,011
9,762
18,128
1,366
3,654

5,615
1,057
336
8,654
16,070
2,051
3,758

6,426
1,083
685
10,898
20,238
3,264
3,519

1,416
1,982
4,785
13,730
7,891
2,943
19,870
9,786
1,610
1,004
1,215
78,527

2,706
3,786
9,176
26,065
7,706
3,173
24,297
10,169
1,997
1,059
1,365
1,14,368

4,547
6,359
11,216
32,321
7,883
3,014
21,643
9,624
1,979
1,002
1,284
1,39,516
3,32,411 Q2

3,935
5,505
15,638
44,848
8,228
5,676
22,676
7,215
1,965
1,041
1,245
1,55,514

4,843
6,775
16,704
47,919
8,305
4,568
25,668
8,869
1,990
1,034
1,312
1,74,100

19,154
1,733
20,886

6,580
6,179
12,759

2,115
4,515
6,629
40,275 Q2

672
1,342
2,014

658
658

1,625
1,434
3,058
5,731 Q3

637
289
926

3,342
3,311
6,653

13,162
20,797
8,883
8,324
4,013
2,863
26,058
31,983
33,637 Q4

26,007
7,162
1,026
34,195

29,730
7,057
36,787
1,02,965

89,696
66,208
26,703
1,82,608
1,82,608

305
3,957
2,525
281
5,209
93
39
12,407

442
4,463
4,862
540
4,905
87
31
15,331

401
4,438
7,768
863
4,388
79
30
17,968
45,706 Q2

496
4,459
10,307
1,145
4,251
66
35
20,759

517
4,264
12,745
1,416
3,358
49
41
22,391

469
3,754
13,706
1,523
1,808
60
68
21,389
64,538 Q3

32
3,732
8,754
973
3,494
59
29
17,073

288
4,432
6,387
710
3,817
59
27
15,719

281
214
5,267
4,229
4,396
3,349
488
372
2,664
1,912
57
31
21
25
13,174
10,131
45,966 Q4

107
3,566
2,468
274
1,386
24
20
7,845

228
4,787
3,185
354
2,061
19
16
10,650
28,626

3,779
51,346
80,453
8,939
39,254
683
381
1,84,836
1,84,836

3,72,045

17,44,424

4,18,392

7,134
989
1,277
9,925
18,431
3,513
3,603

Nov-25

2,228
967
6,438
11,957
236
1,041

Q1
MWH
MWH
MWH
MWH
MWH
MWH
MWH

Jul-25

1,537
691
3,343
6,210
108
407

Q1
MWH
MWH
MWH

Jun-25

5,57,867

Page 3 of 5 of Note-5

3,96,120

<!-- page 27 -->

Statement Showing Transmission Loss Rate in %
Sl No
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37

Period
31-03-2025 to 06-04-2025
07-04-2025 to 13-04-2025
14-04-2025 to 20-04-2025
21-04-2025 to 27-04-2025
28-04-2025 to 04-05-2025
05-05-2025 to 11-05-2025
12-05-2025 to 18-05-2025
19-05-2025 to 25-05-2025
26-05-2025 to 01-06-2025
02-06-2025 to 08-06-2025
09-06-2025 to 15-06-2025
16-06-2025 to 22-06-2025
23-06-2025 to 29-06-2025
30-06-2025 to 06-07-2025
07-07-2025 to 13-07-2025
14-07-2025 to 20-07-2025
21-07-2025 to 27-07-2025
28-07-2025 to 03-08-2025
04-08-2025 to 10-08-2025
11-08-2025 to 17-08-2025
18-08-2025 to 24-08-2025
25-08-2025 to 31-08-2025
01-09-2025 to 07-09-2025
08-09-2025 to 14-09-2025
15-09-2025 to 21-09-2025
22-09-2025 to 28-09-2025
29-09-2025 to 05-10-2025
06-10-2025 to 12-10-2025
13-10-2025 to 19-10-2025
20-10-2025 to 26-10-2025
27-10-2025 to 02-11-2025
03-11-2025to09-11-2025
10-11-2025 to 16-11-2025
17-11-2025 to 23-11-2025
24-11-2025to30-11-2025
01-12-2025 to 07-12-2025
08-12-2025 to 14-12-2025

Arunachal Pradesh
3.81
3.75
3.77
3.85
3.67
3.47
3.70
3.40
3.39
3.48
3.37
3.26
3.36
3.75
3.82
3.86
3.89
3.62
4.02
3.65
3.47
3.79
3.63
3.27
3.50
3.33
3.43
3.58
3.96
3.56
4.20
3.50
4.19
3.90
4.01
4.19
3.97

Remarks

Month

20253103-0604.pdf
Apr-25
20250704-1304.pdf
20251404-2004.pdf
20252104-2704.pdf
20252804-0405_288.pdf
May-25
20250505-1105_519.pdf
20251205-1805_930.pdf
20251905-2505_725.pdf
20252605-0106_312.pdf
20250206-0806 (3)_330.pdf
Jun-25
20250906-1506_430.pdf
20251606-2206_159.pdf
20252306-2906 (3)_354.pdf
20253006-0607_165.pdf
Jul-25
20250707-1307_264.pdf
20251407-2007_688.pdf
20252107-2707_148.pdf
20252807-0308_729.pdf
20250408-1008_948.pdf
Aug-25
20251108-1708_958.pdf
20251808-2408_611.pdf
20252508-3108_802.pdf
20250109-0709_126.pdf
Sep-25
20250809-1409_752.pdf
20251509-2109 (1)_381.pdf
20252209-2809_663.pdf
20252909-0510 (1)_736.pdf
Oct-25
20250610-1210_958.pdf
20251310-1910_489.pdf
20252010-2610_654.pdf
20252710-0211_562.pdf
20250311-0911_373.pdf
Nov-25
20251011-1611_135.pdf
20251711-2311_919.pdf
20251124-1130_309.pdf
20250112-0712_372.pdf
Dec-25
Microsoft Word - 20250812-1412

Monthly
Average Loss
3.80

3.53

3.37

3.83

3.71

3.43

3.75

3.9

4.22

Page 4 of 5 of Note-5

<!-- page 28 -->

Sl No
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53

Period
15-12-2025 to 21-12-2025
22-12-2025 to 28-12-2025
29-12-2025 to 04-01-2026
05-01-2026 to 11-01-2026
12-01-2026 to 18-01-2026
19-01-2026 to 25-01-2026
26-01-2026 to 01-02-2026
02-02-2026 to 08-02-2026
09-02-2026 to 15-02-2026
16-02-2026 to 22-02-2026
23-02-2026 to 01-03-2026
02-03-2026 to 08-03-2026
09-03-2026 to 15-03-2026
16-03-2026 to 22-03-2026
23-03-2026 to 29-03-2026
30-03-2026 to 05-04-2026

Arunachal Pradesh
4.02
3.98
4.93
5.10
4.81
4.57
4.44
4.26
4.02
3.83
3.88
4.07
4.12
4.48
4.27
4.43

Remarks

20251512-2112_854.pdf
20252212-2812_752.pdf
20252912-0401_139.pdf
20261101-0501_547.pdf
20261201-1801_601.pdf
20261901-2501_230.pdf
20262601-0102 (1)_736.pdf
20260202-0802_871.pdf
20260902-1502_267.pdf
20261602-2202 (1)_788.pdf
20262302-2902_931.pdf
20260203-0803_537.pdf
20260903-1503_557.pdf
20261603-2203_334.pdf
20262303-2903_641.pdf

Month

Monthly
Average Loss

Jan-26

4.73

Feb-26

4.00

Mar-26

4.27

20263003-0504_116.pdf

Page 5 of 5 of Note-5
