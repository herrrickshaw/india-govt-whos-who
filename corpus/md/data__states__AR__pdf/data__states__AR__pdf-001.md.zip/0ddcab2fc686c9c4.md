---
doc_id: "0ddcab2fc686c9c4"
source_url: "https://cdn.s3waas.gov.in/s36c29793a140a811d0c45ce03c1c93a28/uploads/2021/04/2021040930.pdf"
ministry: "Changlang"
title: "Gazetted, Restricted and Local Holidays 2021"
date: ""
pages: 4
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "3d3e5d2a759e23e1"
---

<!-- page 1 -->

] GOVERNMENT OF ARUNACHAL PRADESH
i GENERAL ADMINISTRATION DEPARTMENT
AP:: CIVIL SECRETARIAT::ITANAGAR.
BLOC K NO:04::15T FLOOR
No. GA-10/2015 Dated, Itanagar the 7" October’2020.
NOTIFICATION.

The Governor of Arunachal Pradesh is pleased to declare that the holidays as
specified in the Annexure-I will be observed in all the offices and Institutions under Government of
Arunachal Pradesh during the year 2021.

2. The Deputy Commissioners in respect of their respective district except Deputy
Commissioner, Capital Complex, Itanagew are authorized to declare 2 (Two) days as Iccal holidays
out of the festivals enlisted in Annexur-lll. As regards Capital Complex, local holiday will be
observed on 26/02/2021 on account of Ny‘okum festival.

3. The Local administrative officers, in charge of the offices of Govt. of Arunachal
Pradesh located in New Delhi, Assam, Meghalaya, Maharashtra and West Benga! may declare 2
(Two) holidays observed from their respective state during the year 2021.

: 4. Further, Govt. of Arunachai' Pradesh is pleased to allow the employees of the
State Government to avail any 2(two) holidays as restricted holiday out of the list of restricted
holiday, 2021 as enlisted in Annexure-Il.

5, The above mentioned holidays are not applicable to Banks and other financial
institutions located in Arunachal Pradesh. A separate notification for declaration of holidays in
respect of Banks and other financial institution locatea! in Arunachal Pradesh during the year 2021
will be issued separately as per instructions of the Govt. of India.

, Sd/-

(Sadhana Deori)
Secretary (GA)
Govt. of Arunachal Pradesh,
Itanagar.
Memo No. GA-10/2015 Dated Itanagar, the 16” October ‘2020.
Copy to.-

4. The Commissioner to the Governor, Govt. of Arunachal Pradesh, Itanagar.

2. The PPS to Hon’ble Chief Minister, Arunachal Pradesh, Itanagar.

3. The PPS to Hon ble Dy. Chief Minister, Arunachal Pradesh, Itanagar.

4, PS to Speaker/ Py. Speaker, Govt. of Arunachal Pradesh, Itanagar.

5. PS to all Ministers, Govt. of Arunachal Pradesh, Itanagar.

6. US to Chief Secretary, Govt. of Arunachal Pradesh Itanagar.

7. All Principal Secretaries/Commissioners/Secretaries, Govt. of Arunachal Pradesh, Itanagar.

8. Allthe Chief Secretaries of the States and Union Territories, Govt. of India. ;

9. All Addl. Secys/Spl. Secys/Joint Secretaries/Deputy Secretaries/Under Secretaries, Govt.

of Arunachal Pradesh, Itanagar.

10. The Deputy Secrtary to the Govt. of India, Ministry of Home Affairs, Department of P&AR,

New Delhi.
Contd to...P/2

<!-- page 2 -->

ANNEXURE-!I
/. : LIST OF RESTRICTED HOLIDAYS FOR THE YEAR, 2021

[Sie agro ATES MONTH |. _OAY "RESTRICTED HOLIDAY
+ | a> January 2021 | __| Thursday | Pongal Scar erence

Le nt February’2024 "Tuesday | Ali-ayeligang.ststiCS~S
ST et epee nga ey Alicayerligang
ae Tuesday + bacon Panchami/ Sri Panchami,

E ——+ 12 tebtuary 2024 — Friday | Shivaji Jayanti _ te ie =
[3.__, 26% February 2021 __ Friday | Hazarat Ali's Birthday
P27 February 2027 | Saturday __| Guru Ravidas’s Birthday __
-—— 8 March 2021 | Monday ___| Swami Dayananda Saraswati Jayanti_
[8__141%March'2021__ | Thursday | Maha Shivaratri
j2___| 28" March’2021* Sunday | Holika Dahan / Dolyatra,
10" 4 Aprit’2021 | Sunday = [Easter Sundays
{11.  § 13 April'2621 “| Tuesday Chaitra Sukladi / Gudi Padava/ Ugadi /
mp He |_| Chet Chand Vaisakhi Vishu
12,14 April’2021 __|Wedtesday | MesadiTamilNew YearsDay
13. | 15" April’2024 [Thursday __| Vaisakhadi (Bengal) eee

14; 218 April "2021 | Wednesday | Ram Navami Bee
15. | 25t April'2027 *° ;Sunday __| Mahavir Jayanti. eae
16. | 7 May'2021 1S eee
(i7 V9 May'2021 | Sunday | Guru Rabindranath’ birthday

| 18. | 12th July'2021 Monday | Rath Yatra eet
19 215 July 2021 Wednesday {d-ul-Zuha(Bakrid)
20. 16 August’2021_ | Monday __—| Parsi New Year's day/Nauraj
2149 August'2021 | Thursday | Muharram
22. 21" August’2021" Saturday _| Onam or Thiru Onam Day
23.224 August'2021____ SE ait oo
24. | 30th August’2021 |Monday _| Janmashtami(Smarta)
25.10 September'2021 {Friday ___| Vinayaka ChaturthilGanesh Chaturthi —_
: 26. | 19th October'2021 Tuesday Milad-un-Nabi or Id-e-Milad (Birthday of
{ 13 | ProphetMohammad)
iF ar October 2071 “Wednesday | Maharishi Valmiki's Birthday ae
| 28, | 24 October 2027 Sunday _ Karaka Chaturthi(Karva Chouth) :
| 29. 31 November 2021 Wednesday | Naraka Chaturdasi. ats
30 | 5t November 2021 | Friday | Govardhan Puja ae
| 31. 6th November 2021 {Saturday | BhaiDuj owes
1.32. 40 November 2021 ' Wednesday Pratihar Sashthi or Surya Sashthi
| pes 2 LChhat Puja) ee
_33._, 24" November’ 2021 Wednesday | Guru Teg Bahadur s Martyrdom Dey =
(34.1 24" December 2021 [Friday | ChristmasEve

; 6 nf APS
(Okang Perme)
‘ Under Secretary (GA)
; Govt. of Arunachal Pradesh :
* itanagar

<!-- page 3 -->

jf, LIST OF LOCAL HOLIDAY, 2021 aaaiats
[SLNo. | DATE& MONTH J
ee ee uONTE | Day | NAME: OF FESTIVAL | NAME OF TRIBE
Fa TH joer —|Wednesslay | Si-Donyi __| Tagin

L£___| 11" January'2024 Monday | Sarok | Aka ;
3__| 1 February'2021 "| Monday | Reh | Idu-Mishmi
|-¢_| 24 February'2021 | Tuesday | Donggin ages

. S| 6th February 2621 | Saturday | Boorio0t Yutlo | Nyishi :

8. | ‘4th February’2021 / Sunday “)Shapwang Yaung | Singpho
en

7, 15 February'2021 | Monday Tam Ladu Digaru/Tarun-
fee eee eer EE | sete te ep eee eee tere | Mishimi

| 8:__| 16" February’2021__[Tuesday “| Oriah «| Wancho
—2.___ 26" February'2021 | Friday Nyokum — Nyishi
1 ener - Sunday ___| Unying-Aran —{ Adi ee

11. | 5th Aprif2021— | Monday |Mopin—~—~Ss«|Galo.

12. 14*Aprif' 2024 [Sunday | Pongtu _Ttutsa
18. | 44 Aprif'2024 Wednesday |Sangken =| Khamti/Singpho
4 18 Apia hursdoy—Tongte Ns

S25 Aprif2021 | Sunday | MoheMoi | Tangsa
76. | 25% Apri 2024 Sunday | Guméum-Gumpa | Puroik

i715 July'2021 Monday |Dree | Apatan’

18. is September'2021__| Wednesday | Solung Adi eee
_ 19 140% September'2021 | Friday (| Pham-Kho- Sowai__| Khowa(Bugun)
20. | 24% September'2021 | Friday | Ke-Meh-Ha | Idu Mishmi
» 24. , 15% October'2021 | Friday _ | Chincang Deities titties

22,__| 15% November'2021 | Monday __| Nyethri-Dow | Aka (Hrusso)
_ 23. | 25! November'2021 | Thursday | Chalo-Loku =| Nocte
24. Sh December'2021 | Sunday | Podi-Barbi == Adi
25. | Lot Khikshaba Sherdukpen
26} Datetobefixedby | + [bna-Chut it Meyor
pie aiconeened DG 8 es ee Losal | eg Monpa
(2% T PoiePee Mau | Tai Khampti

: ; i do 20
| adel
(Okang Perme)
Under Secretary (GA)
Govt. of Arunachal Pradesh
Itanagar

<!-- page 4 -->

ANNEXURE-|
LIST OF GAZETTED HOLIDAYS FOR THE YEAR, 2021

SI.No. DATE & MONTH LAY GAZETTED HOLIDAY

1. ast January’ 2027 Frida New Year's Day _ a)

2.1 44” January’ 2021 Thursday | Makar Sankranti
3. 26 January 2021 Tuesda RepublicDay
[4 20! February’ 2024 Saturda Statehood Da |
6. | 2r4 April’ 2021 Good Friday sige
[745% April 2021 Thursday BohagBihu@ |
| 8. | 14% May” 2021 Frida Id-ul-Fitr |
9. | 26" May’ 2021 Wednesday BuddhaPurnima
10. | 15 August’ 2021 Sunda Independenceday ss!
pls | 2d October’ 2021 Saturda Mahatma Gandhi's Birthday |
12. | 14 October'2021 Dussehra (Mahanavmi)
113. [15 October'2024 eeee Dussehra _ i
'44, | 4 November °2021 Thursda Diwali ( Deepavali ) '
145, | 19 November’ 2021 | Friday Guru Nanak’s Birthday !
16. | 1st December'2021 Wednesda’ Indigenous Faith day oy
i147. | 25! December’ 2021 Saturda Christmas day ise

fe pl?
(0K erme)
Under Secretary (GA)
4 Govt, of Arunachal Pradesh
ltanagar :
