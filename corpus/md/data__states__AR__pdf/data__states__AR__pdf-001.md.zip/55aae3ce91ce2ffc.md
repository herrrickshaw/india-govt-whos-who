---
doc_id: "55aae3ce91ce2ffc"
source_url: "https://ditc.arunachal.gov.in/pdf/notice/SDC-Corrigendumprebid-reply.pdf"
ministry: "Information Technology & Communication Department, Arunachal Pradesh"
title: "View"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bc374d4adef0d233"
---

<!-- page 1 -->

GOVERNMENT OF ARUNACHAL PRADESH
STATE COUNCIL FOR IT & E-GOVERNANCE
DEPARTMENT OF IT & COMMUNICATION
ROOM NO 107, DIGITAL CELL
BLOCK NO 1, 1ST FLOOR : AP CIVIL SECRETARIAT
No. DIT/291t2020t04

Dated ltanagar, the Sth March,2O21

Corriqendum

with reference to our earlier Nlr floated vide No Dlr/29
ll2o2olol dated
25t^ January'2o21 for 'selection of Data center
operator for Design, supply,
lnstallation, configuration, operation & Maintenance
of physical and lr
lnfrastructure for Arunachal Pradesh state Data
centre,, in eTender portal
(https//arunachaltenders gov in) and
state Portal (arunachalpradesh.gov in), this to

inform all that the bid documents Volume-l &

Volume-tt has been amended based on
the pre-bid conference held on Sth February,2O21.

Therefore, the bidders are requested to go through
documents carefuily prior to submission of bid

the amended bid

response.

sd/(Neelam yapin Tana)
Di rector/Member Secretary
State Council for lT & E-Governance

No. DIT/291t202OtO4

Dated ltanagar, the Sth March'2021

Copy to:
PS to Hon'bre Minister, rr&c, Govt.of Arunachar pradesh.
2 PS to Hon'ble Chairman, State Council for lT & E-Governance,
ltanagar.
'
3.PS to secretary, rr&c, Govt.of Arunachar pradesh,
rtanagar.
4.PS to Director, rr&c, Govt.of Arunachar pradesh,
rtanaga"r.
5.content ManageriNodar officer, website for pubrication
ine N[T in
www. arunachalpradesh. qov. in
6 Office copy
1.

,",^TM,[,,

State Council for lT & E-Governin."
