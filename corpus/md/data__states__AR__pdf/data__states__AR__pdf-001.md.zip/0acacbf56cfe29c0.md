---
doc_id: "0acacbf56cfe29c0"
source_url: "https://power.arunachal.gov.in/uploads/orders/Submission%20of%20Audited%20Quarterly%20Accounts%20for%204th%20Quarter%20%28JAN%202026-%20MAR%202026%29%20for%20the%20FY%202025-26.pdf"
ministry: "Power Department, Arunachal Pradesh"
title: "View"
date: ""
pages: 27
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d9715f3613079531"
---

<!-- page 1 -->

GOVERNMENT OF ARUNACHAL PRADESH
DEPARTMENTOFPO~R

email: cecomita@gmailcom
No. CE(COM)/AUDIT/35/2025-26/

~~'7"_~

;"6S-

6<;$

Office of the Chief Engineer (Commercial)
cum Chief Electrical Inspector,
Vidyut Bhawan, Itanagar -791111
____:(A_ru_n_a_c_ha_I_P--;r;:::;:ad:-e7ts;;:orh.:_
_
Dated Itanagar, the 1"'3 iV'May 2026

To,

The Chief Program Manager,
REC Limited, Regional Office,
SRADDHA Building,
MG Road & GS Road Crossing,
SOHUM/SBI Point, Christian Basti,
Guwahati-781005 (Assam).

Sub: Submission of Audited Quarterly Accounts for 4th Quarter (JAN 2026- MAR
2026) for the FY 2025-26.
Sir,
Enclosed please find herewith the Audited Quarterly Accounts for the 4th Quarter
(January 2026 to March 2026) of the FY 2025-26 as per the format prescribed by the Ministry
of Power, Govt. of India for the Department of Power, Arunachal Pradesh.
This is for your information and necessary action at your end please.
Enclosure: As stated above.

Chief En . 'eel"

c;1c
No. CE(COM)/AUDIT/35/2025-26/5"6§"'-

b~

) cum CEI

Department of Power,
Itanagar

Dated Itanagar, the J'5~ay

2026

Copy to :

1. The Comissioner (Power), Government of Arunachal Pradesh, 2nd Floor, Block No.2,
A.P. Civil Secretariate, Itanagar -791111, Arunachal Pradesh along with a copy of the
Audited Quarterly Accounts for the 4th Quarter of the FY 2025-26 for kind information
please.
2. The State Nodal Officer RDSS, Deptt. of Power., Vidyut Bhawan, Itnagar- 791111,
Arunachal Pradesh along with a copy of the the Audited Quarterly Accounts for the 4th
Quarter of the FY 2025-26 for information.

Page 1 of2

<!-- page 2 -->

3. The Chief Engineer (power), TPMZ, Deptt. of Power, Itanagar for information along
with a copy of the Audited Quarterly Accounts for the 4th Quarter of the FY 2025-26.
He is requested to upload Audited Quarterly Accounts for 4th Quarter - e FY 202526 in the web portal of the Department of Power on priority.

Page 2 of2

<!-- page 3 -->

CA
IN DJA

Gadly Shaw & Associates
Chartered Accountants

Head Office:
148A, Salkia School
Road, Maansarovar
Apartment (Ground
Floor)
Kolkata (Howrah): 711101
Email:

CERTIFICATION

This is to certify the Report on the Statement as per Annexure 1 as approved by Ministry
of Power, GOI for the DISCOM utility of Department of Power, Arunachal Pradesh.
We have verified the accompanying statements of Commercial Zone, Department of Power,
Arunachal Pradesh ("State Power Department"), which comprise Annexure - 1 along with
the Notes (1 to 8) for Quarter-4 of FY 2025-26.

In our opinion and to the best of our information and according to the explanations given to
us, we have verified the accompanied Statement and notes to the statement from the Cash
Book, Sample Monthly Accounts, LOC, Agreements, sample salesl purchase invoices and
the aforesaid Annexure - 1 statements give a true and fair view and following points
observed during our verification:

1.

With reference to point number A 1: Revenue from Sale of Power (amounted RS.109
crores) and A4: Revenue from Inter State Sale and Trading (amounted Rs 9.60
crores) of Table 1: Revenue details, we have been provided statement of Energy
Sold within and outside the state as referred in the Statement of annexure as Note 1
(i) & Note 1 (ii) respectively. We have found that the statement as stated is noted as
billed to customer basis and verified from Capital & Naharlagun Division Monthly
Accounts and Sample Sales Invoices.

2.

As per the discussion with the Management no revenue occurred with reference to
the point number A2: Fixed Chargesl Recovery from theft etc. of Table: 1 Revenue
Details, so the column has been kept blank.

3.

As per the discussion with the Management no revenue occurred with reference to
the point number A3: Revenue from Distribution franchisee of Table 1: Revenue
Details, so the column has been kept blank.

4.

As per the discussion with the Management no revenue occurred with reference to
point number A5: Revenue from Open access and wheeling of Table 1: Revenue
Details, so the column has been kept blank.

5.

As per the discussion with the Management no revenue occurred with reference to
point number A6: Any other operating Revenue of Table 1: Revenue Details, so the
column has been kept blank.
.

6.

As per the discussion with the Management no revenue occurred with reference to

Page 1 of 6

<!-- page 4 -->

CAt
IN D liA

Gadly Shaw & Associates
Chartered Accountants

Head Office:
148A, Salkia School
Road, Maansarovar
Apartment (Ground
Floor)
Kolkata (Howrah): 711101
Email:

point number B1: Tariff Subsidy Booked of Table 1: Revenue Details, so the column
has been kept blank.

7.

As per the discussion with the Management no revenue occurred with reference to
point number B2: Revenue Grant under UDAY of Table 1: Revenue Details, so the
column has been kept blank

8.

Dept of power receive all their expenses from Govt. Of Arunachal Pradesh, so we
have shown the balance amount (differences of Revenue & Expenditure amount) in
point number B3: Other Subsidies and Grants of Table 1.

9.

As per the discussion with the Management no revenue occurred with reference to
point number C1: Income booked against deferred revenue of Table: 1 Revenue
Details, so the column has been kept blank.

10.

As per the discussion with the Management no revenue occurred with reference to
point number C2: Misc non-tariff income from consumers (including DPS) of Table:
1 Revenue Details, so the column has been kept blank.

11 .

As per the discussion with the Management no revenue occurred with reference to
point number C3: Other Non-Operating income of Table: 1 Revenue Details, so the
column has been kept blank.

12.

We have received a statement for Purchase of power and Transmission charges for
a total expenditure of Rs 146.97 Crores under Table 2: Expenditure Details,
mentioning LC Bill, Supplementary & Other Bill and POSOCO and verified the same
from sample bills provided to us and details of the statement are provided in Note 2.
As per discussion with the management PGCIL & CTUIL are transmission units and
all the bills they raised are related to transmission expenses.

13.

We have verified point H1: Repairs & Maintenance under Table 2: Expenditure
details. We checked the LC statement and the statement provided by the
management. As mentioned in Note 3, and based on the data provided by the
Management, Rs 1.44 Crores expenses were incurred under Repairs & Maintenance
for 04.

14.

We have verified point H2: Employee Cost under Table 2: Expenditure details Salary
and wages of employees as provided by Commercial Zone.

15.

We have verified Point H3: Admin & General Expenses under Table 2: Expenditure
details. As per the data provided by the Commercial Zone, Rs 35.89 Crore were
incurred under Admin & General Expenses for 04.

16.

As per the discussion with the Management no expenditure occurred with reference
to point number H4: Depreciation of Table: 2 Expenditure Details, so the column has

Page 2 of6

<!-- page 5 -->

01(
IN 0 IA

Gadly Shaw & Associates
Chartered Accountants

Head Office:
148A, Salkia School
Road,Maansarovar
Apartment (Ground
Floor)
Kolkata (Howrah): 711101
Email:

been kept blank.
17.

As per the discussion with the Management no expenditure occurred with reference
to point number H5: Total Interest Cost of Table: 2 Expenditure Details, so the
column has been kept blank.

18.

As per the discussion with the Management no expenditure occurred with reference
to point number H6: Other Expenses of Table: 2 Expenditure Details, so the column
has been kept blank.

19.

As per the discussion with the Management no expenditure occurred with reference
to point number H7: Exceptional Items of Table: 2 Expenditure Details, so the
column has been kept blank.

20.

As per the discussion with the Management no expenditure occurred with reference
to point number K1: Income tax of Table: 2 Expenditure Details, so the column has
been kept blank.

21.

As per the discussion with the Management no expenditure occurred with reference
to point number K2: Deferred Tax of Table: 2 Expenditure Details, so the column has
been kept blank.

22.

As per the discussion with the Management with reference to point number M1: Net
Tangible Assets & CWIP of Table:3 - Total Assets, is not applicable so the column
has been kept blank.

23.

As per the discussion with the Management with reference to point number M2:
Other Non-current Assets of Table:3 - Total Assets, is not applicable so the column
has been kept blank.

24.

For verification of Point number M3a: Gross Trade Receivables Govt. Dept. under
Table:3 of - Total Assets, we have received the statement as per Note 6(i) but the
third-party verification of the same is not provided to us.

25.

For verification of Point number M3b: Gross Trade Receivables other than Govt.
Dept. under Table:3 of - Total Assets, we have received the statement as per Note
6 but the third-party verification of the same is not provided to us.

26.

As per the discussion with the Management with reference to point number M3c:
Provision for Bad Debts of Table:3 of - Total Assets, is not applicable so the column
has been kept blank.

27.

As per the discussion with the Management with reference to point number M4:
Subsidy Receivable of Table: 3 of - Total Asset, is not applicable so the column has
been kept blank.

------------------------------------------------------------------~~
,

Page 3 of6

,J

<!-- page 6 -->

0\
1 NOlA

28.

Gadly Shaw & Associates
Chartered Accountants

Head Office:
148A, Salkia School
Road, Maansarovar
Apartment (Ground
Floor)
Kolkata (Howrah): 711101
Email:

As per the discussion with the Management with reference to point number M5:
Other Current Assets of Table: 3 of _ Total Assets, is not applicable so the column
has been kept blank.

29.

As per the discussion with the Management with reference to point number N1:
Share Capital & General Reserve of Table: 4 of _ Total Equity & Liabilities, is not
applicable so the column has been kept blank.

30.

As per the discussion with the Management with reference to the point number N2:
Accumulated Surplus/(Deficit) as per BS of Table: 4 of _ Total Equity & Liabilities, is
not applicable so the column has been kept as blank.

31.

As per the discussion with the Management with reference to point N3: Govt. Grants
for Capital Assets of Table: 4 of _ Total Equity & Liabilities, is not applicable so the
column has been kept blank.

32.

As per the discussion with the Management with reference to point number N4: Noncurrent Liabilities of Table: 4 of _ Total Equity & Liabilities, is not applicable so the
column has been kept blank.

33.

As per the discussion with the Management with reference to point number N5:
Capex Borrowings of Table: 4 of Key _ Total Equity & Liabilities Details, is not
applicable so the column has been kept blank.

34.

As per the discussion with the Management with reference to point number N6a:
Long Term Loans _ State Govt. under Capex Borrowings of Table: 4 of Key _ Total
Equity & Liabilities Details, is not applicable so the column has been kept blank.

35.

As per the discussion with the Management with reference to point number N6b:
Long Term Loans'- Banks & Fls under Capex Borrowings of Table: 4 of Key _ Total
Equity & Liabilities Details, is not applicable so the column has been kept blank.

36.

As per the discussion with the Management with reference to the point number N6c:
Short Term / Medium Term Loans _ State Govt. under Capex Borrowings of Table:
4 of Key _ Total Equity & Liabilities Details, is not applicable so the column has been
kept as blank.

37.

As per the discussion with the Management with reference to the point number N6d:
Short Term / Medium Term Loans _ Banks & Fls under Capex Borrowings of Table:
4 of Key _ Total Equity & Liabilities Details, is not applicable so the column has been
kept as blank.

38.

As per the discussion with the Management with reference to point number N6: Noncapex Borrowings of Table: 4 of Key _ Total Equity & Liabilities, is not applicable so
the column has been kept blank.

Page 4 of 6

<!-- page 7 -->

CA
INDIA

Gadly Shaw & Associates
Chartered Accountants

Head Office:
148A, Salkia School
Road, Maansarovar
Apartment (Ground
Floor)
Kolkata (Howrah): 711101
Email:

39.

As per the discussion with the Management with reference to the point number N7a:
Short Term Borrowings form Banks/Fis under Non-capex Borrowings of Table: 4 of
Key - Total Equity & Liabilities, is not applicable so the column has been kept as
blank.

40.

As per the discussion with the Management with reference to point number N7b:
Cash Credit/aD from Banks/Fis under Non-capex Borrowings of Table: 4 of Key Total Equity & Liabilities, is not applicable so the column has been kept blank.

41.

As per the discussion with the Management with reference to point number N8:
Payables for Purchase of Power of Table: 4 of - Total Equity & Liabilities, is not
applicable so the column has been kept blank.

42.

As per the discussion with the Management with reference to the point number N9:
Other Current Liabilities of Table: 4 of - Total Equity & Liabilities, is not applicable,
however balancing figure of Total Assets have been taken as Other Current
Liabilities.

43.

Table 5 & Table 6 of Annexure 1 is related to the energy account and the details
have been filled in only based on the management certified energy account
submitted to us. However, Trade Receivable details mentioned in 011 & 012 column
are as per Note-6 which is provided by management.

44.

Details as stated in Table 7 & Table 8 are only as per the data provided by the
management.

45.

All the operational costs of the Department of Power are being borne by the Govt. of
Arunachal Pradesh through approved annual budgetary allocation.

46.

In the Audited Accounts (Quarterly), TP&M (Transmission, Planning & Monitoring)
Zone expenses are shown separately in Note 4(i) for information purpose only.

Page 50f6

<!-- page 8 -->

Gadly Shaw & Associates
~

Chartered Accountants

f N 0 fA

Responsibility

Head Office:
148A, Salkia School
Road, Maansarovar
Apartment (Ground
Floor)
Kolkata (Howrah): 711101
Email:

of Management for the Report on the Statement as per Annexure - ~.

The management are responsible for the matters stated in Annexure - 1 along with the
Notes (1 to 8) with respect to the preparation of these statements that give a true and
fair view of state of affairs.

This responsibility also includes maintenance of adequate accounting records in
accordance with the provisions of the Act and for preventing and detecting frauds and
other irregularities; selection and application of appropriate accounting policies; and
design, implementation and maintenance of adequate internal financial controls, that
were operating effectively for ensuring the accuracy and completeness of the
accounting records, relevant to the preparation and presentation of the Report on
Statement of Annexure - 1 along with the Notes (1 to 8) that give a true and fair view
and are free from material misstatement, whether due to fraud or error.

For Gadly Shaw & Associates
Chartered Accountants
FRN:327846E

,f~&

~"O~,,~
CA Sumit Agarwal
Partner
M No.: 302683
lnOUN:26302683~'fPA7354
Date: 15.05.2026
Place: Howrah

Page 6 of6

<!-- page 9 -->

OJ

"

en

o

-

.....

ID

011

.....
"T1
-<

::::I

~

iil

ID

::r-

ID
~
0'
~
.....

a.

o

~

or

~

"'C
ID

III

OJ

n

:::0

m

V'l

~

c:

ID

0'
~
.....
::r-

-e

s;

II

III

<!-- page 10 -->

<!-- page 11 -->

III

"'0

(J)

o

!.AI

-

(1)

aq

<!-- page 12 -->

....

!:!1~(1)

~nd'

~3-

!l ~g

!ot-1
c! -e,

-F'CI>

0°
Cl)3
_"'0 :I

n

~

....

II
"V

~....

.::

~

<,

III

::G

:s

III

-..

o
~
~
...

C

c..

III
:::I

II)

3

o

n

:::I

<

o

c
iii"

.....

CIQ

II)

::G

:::I
CIQ

~

2"

n

II)
)(

c..

II)

c:-

II)

::G
II)
n

a:
<

III

c-

:::I
VI
C

o

III
"0

en

en

N

N

0

VI

011 VI

N i.u i:n N

en

I.!)
I.!)

VI

U)

N

io

~

en

II)

0

...

z

0

..!..J

II)

...

z

-.,

~

N
00

II)

""

W
N,

~

1I1

VI

;:c

VI

N

.... !-' ""~j... rN

II)

N
N

;-J

I.!)

W

io i:n 0'1

W

""
""

....
O'IU)I.!)

.... ....

N

:;.. Go

OONNenO'l
I.!) ....
N

.... N

:xJ

~
N
0 N en ~
1.11 W .... N
~ .J::>

0'1

I.!)

'in
"" ....
....
w
....
loCI ""
P
Y'
.:""
.... ""
"" .... !o'I 011 b .... .... !=l
VI

.J::>

1.11

'"_;,. loCI
~
....
1.11

,1.11

....
~.... ,0'1 '"_;,.

en
VI

VI

,

Ss:c

~

III

o 0
ii ~
I'D

.'

<!-- page 13 -->

"0
III

C'I

a

U1

m

IJQ

o

,~

<!-- page 14 -->

<!-- page 15 -->

I-'

o

I-'

-

m

OQ

Ql

i:I

.... 3:
III
III

.., ... 8~:::r

:s:

P

0"1 0"1

)10

'"

c.

D

a-

i
0

0

f',t'"'

0 0
0 0

0 0

0
0

Vl

,

0

0
0

.:::i

W

0

0

;

,

Z

.!"~

0"""

....

-a-- ...... r1

~-

III

111

0
:::r

.....

....

III

....111;...
111

h

111

:2.

n

III

111

;II

C'I

n
i=

><

iii

0

o

~~
00"-'

0

0

00

Vl

0

-

a- !!!..
.....0 ?'~
0 o 0

wVl

..I»

O.!"

0"1 .......

..

,

,

,

.

0

0

;.c '::'" .!"UJ

, ,

0

0 0

'" !'-' ,

e:

Vl

....... :>J

0

0

~
0
~0 , ~

!"

0

0

~0

.:::i

0
0

Vl

ih
a, ?

0
0

0

0

IV

Vl

00 IV
_00 ,0

.... 'VI m
:;I:J
l:A' c
'0
~'" III
0 ~~
I.f1 ~ :s:

0

0 o 0

c;.. 00 '-0 ex, Z
"0 '-.J ~
::...
!' ~0 """ ~
....., ~
.... ......
r~ '-0 ~ I.f1

.!"
!" .!"
Vl ~

0
0

(7\

III

Z

0

.

ID

....

:E
:r::

3:

III

a:

III

0
c·

0

~

m

;:J.

('T'I

VI
III

"0
tl
"0

"0

LA

Ql

VI

I

r

r

"0

w

Vl

~... ~
........
~

~
.,.

0\
00

ih

....... w

:::::0

~..... .,.
....

II

"0

('T'I

"0

r

tl
"0

-I "0

r r

Vl

0
0

0

Vl~

,

::::I
i+

::I

0'

lit
....,

......
0

Vl

~

'1

...

III

s:

CJ\

IV

"' ......

51 0"1

,~

{J:

0

!
~
j:n

P.

~

~

W

....

:::s
~
r-

-I

~ 90 CJ\
51

;:;'
f1'

CJ\

,:..

::I

III

...

r- '"

~
PI

w

, ~ ::i:-

t

....
~ ,

0

IV
.j>.

~~

'Vl

. "'

r

0 ......

~00

I

....

~

I

~ ~

I

I

nI

~ ro!!!.. ro -a'
a
ro ro rg b
f::::- ~"""
~
z »
;:J.
"0
~ 2> &,
"0 :l>
~
"0 tl "0 ~ » 'Vi

LA
III

s: c:
- ~ ~ ~:s: s ~:s:
~~
~

I

;;!

--.,.

::.:

0
::J

('T'I

3.'

('T'I

~
.... ~
Z~~

m
iii"
< VI~
,..,. ::J ro ro
iii' III ro ...,
m

('T'I

!!! Ol
;;!
Ql

IV

"
m a: ro
"'
::I
!!L !!!.. ~. ~ ~ 0

[
0 :OOl

...... a- Vl ~ W

J pJ,-2 rg

g

I

r:~ ~ OOw r- ~

!" rP
...... ~
B ih ~~
~ ......'" Vi:;.J

)f'

.,. .... ....51 .....,....

!!!..~

::I .!!t
.... ";' ~
.:. .:. ~

o

III

::'"
IW'" .... Z

.!3.

Ql

r+

m
V,

::J
.....

rp

c

::J

<
m

m

:0

.!::.

I

o
....
m

z

<!-- page 16 -->

I 0\78'6£'66'80't

t6l'gS'9'Z'-S
~fg'~g'v£
5gg'95
gg6'£P5l
6Sg'69'fc:
£n'Ll'L
c:Lc:'oL'gc:
vg£'gS'6l
o~o'C:£'vL
6g~'£S'c:£'~
£££'So'~c:
Of~'Sl'L5
SgPfg'gf
Sfc:'£v'c:g

t09'{IoP99'b
££l'c:L'£o'~
l6~'lg'5
6~v'~£'LL
9SS'lg'c:L
5g9'C:9'£C:
6SS'vo'6g
LgS'Sg'vg
0£g'6v'LPc:
LC:9'C:o'Sv'S
lSO'~S'c:g
Sgc:'vc:'£g'~
g6l'0c:'g~'~
£ov'Sg'gg'~

66g'6£'gP£
999'lg'v9
gv,'6e:'6~
m6'v~'oS
Sf6'go'm
g6g'6v'99(l
gL,'6g'6~
v6g'00'of'~
l60'6g'56
gLl'OPlg

l£l'u'£9''ZZ
S~o'tl'lg'~
fvL'og'og
ff9'n'6v'~
glO',g'lf
Ll9'69'5l'g
lv6'LL'09
~L~'v~'n'v
g~e:'6v'Sg'e:
ll£'~L'6v'l

o{log'6l'66'go'~

0\78'6£'66'80't

S9'Z'96'09'S
g~l'of'vf
£tV'£~'l
gOP5g'Sl
gc:g'gg'vc:
65g'Lg'L
t~S'£S'~f
S6g'gc:'vc:
lfg'gg'c:g
00~'gl'6P~
vc:v'9v'0C:
S6v'LL'gg
oc:g'Sg'gF
£gS'vS'c:g

9n'og'o9'9
vg~'09'vf
,LO'lO'l
SVl'lf'gl
olc:'vv'vc:
f~6'L6'L
SLL'og'gc:
Lgv'oo'~c:
6g~'6c:'og
gf£'£f'£L'c:
v6c:'66'oc:
~gg'~f'6S
c:6~'~6'g£
Sog'Lg'~g

olt'£6'l9'£
06L'gf'~9
ooe:'gf'oc:
9'179''175'6'17
f6~'06'0~
S~6'69'Sg'l
c:H'09'Ol
e:gv'~l'c:v'~
fg~'Lg'56
6g5'go'~g

6'Zt'tE'9S'£
6SSiLv'~9
S6,'f6'0c:
gLo'£v'6v
6gg'c:g'0~
t9g'6v'fL'l
lfc:'gl'Ol
S66'~V'6f'~
fv6'n'v6
£LS'V£'9g

E9E'ol'l{lo'9£

9{109'l6'{Ioo'9£ ~£g'b'lt'9£

Il!lO.1pUI!J!)

=

Z33:J0 '''.10.1
nzal
~f
of
(uiepiex) 03eA
~U!P~UOl 6l
!U!UV' ge:
Ll
!esweN
$'fuellnAeH
9'
Sl
oe!w
Vl
lIewoao
$'fU!0l:f £,

zn
= Z3,):f.0 Il!lO.1
H
(!lezeA) 03zA
II
(e}jn4Jaw) 03aw
Ol
(lIeqe}j!l) oaxn
6~
(e~el:f) 03el:f
g~
(e!ued) 03ed
Jeses
L~
g~
~uo~wnl:f
oleV' Sl
:j.e4p!Sed v~
~UO!}j~U!A £~
o!podeO
n
Aawn)t ~unJn)t
~~
OJ!Z

or

ZNO

{IoSS'£S'6£'£z 9L'Z'£o'o~'ll
g6{1o'££'99'99
699'9£'gl'£z
= Z3M:f.0 Il!lOl
6
~L~tS-~'vf
oLS'gPn
lLg'fv'n
0£g'5f'n
(~uessa)t a>t>ted)03>td
gc:g'gS'66'6
gfL'e:6'09'f
fog'f9'H'£
9gl'lO'9~'£
(e!dnA) 03nA
s
L
h6'LL'go'S
(ednl:f) 03dl:f
090'rr'gS'S
L99'90'£v'9~
£69'90'9L'S
I!ddas
nS'go'LS
0£9'99',L'~
r£S'~6'9S
LgS'99'gS
9
5
L6v'g6'gg'v
ellpwos
ovg'vr'LS'~
~9L'5f'69'~
96g'LPr9'l
pueMel
V
LoS'gv'gS'~
g"lD'ff'l9'v
Olg'OL'~S'l
606'S~'vS'l
f
aale~es
Ll6'£g'c:c:
Sg6'£6'L9
909'l6'c:c:
'9v'gl'rr
z
lel!de)
9~9'f£,f6'n
6g~'00'vf'v
fog'Lf'f~'v
Sl9'S6'Sv'v
unpepe4eN
l
gLf'gl'go'Ll
Sg6'rS'oS'S
,Lv'gL'9g'S
ov6'v6'g9'S
Z3M
AJenJqa:l
AJenuer
11!:j.0.1 4:JJell\l
UO!S!A!O·ON"IS
(saadnl:! Ul)
9'Z-§'ZO'ZJe;;,,<;;'4l JOl;;'ll!lS U!4l!M (·SH U!) p;;,ms ;;,nU;;'J\;;'H;;'S!M-UO!S!J\!O';;'S!M-4:a.uoW
{!')T-all>1I

<!-- page 17 -->

~6S'gf
~00'VS'6S
"l7ov'g6'v
gn'Lz'S~
c.:VZ'9z'S9
gn',,'~6
6vo'6L'06'z
6£6'oS'8S'l
£~8'O£'n'Z

g6c.:'lO'S
vc.:o'z9'9V'V

£bb"bt:"9l'Of

£S'Z'l'Z'Ll'b

oSo'St7'l9'S'Z

foL'f8'6
vlS'6L'zz
zgz'S6'z
9£O'9L'l
So£,6S'oz
gvv'86'~
0£6'vl'gS'~
ogP80'~l
LL6'-cS'8Z
S~L'c.:v'S~
vfPg6'S
no'£o'S
Lgg'vg'n

~gL'6l'z
f£6'98'0£
000'00'£
6LS'gg'n
on'~8'9z
S£6'S8'£
fgv'fv'Lo'~
glL'6g'll
SLg'zg'~f
olg'LL'n
6S8'gv'8
fS9'oL'£
6vv'SL'g~

g£6'w'gg
Lvg'z6'gl
z£z'£g'gc.:
6££'oL'£~
19P6c.:'S
S~£'09'L
£Sc.:'l6'm

£o£'SS'oo'£

!iSl'll'ol''Z

l5S'lt>'66'l

of '17''17'17'8
HL'gS'8
SV8'lc.:'8
LlV'n'S
c.:gv'Ol'lS
og£,L£'g
66£,fz'Lz
19v'lL'S
LfS'fo'of

89v'og'n
"l..Lo'SL'L
LL6'lf'6
O~L'gl'S
uo'l9'8S
6vl'gPg
oLc.:'n'Lf
199'vl'l
vfv'6S'Lf

8 £'rc.:'8
£08'lV'L
8lg'6l'v
£vc.:'lv'Lf
c.:g6'£0'fc.:
~So'n:'6z
l6L'gz'Ol
gg6'Lf'~S

j££90S''ZS'l

lO'Z'L9'E9'£l
f9l'S9'Sl'l

6oo'lS''Z9'lS
blS'~l'b9'-'Z£
SL'Z'L'Z'Zo''Z

vfPoS'of

°

le~o.L t>b
6'Zb'Sl'&'Z'5~

= le~o.lJ!)
= Z33 10lV.LO.L
nzal
wl!p~eA

6
S

S

!I!SWI!N

9

!U!uy

l

SU!pSUOl

l

SU!o'tJ

'Z

o

£'

OI!!W

t>

~UI!!lnAI!H

lIewoa
Z3~-a-'TJfo~n

LlS'89
£gg'6g'oz
000'00''17
Lgl'LPz
S~6'gl'Z

-

= Z3) 10 le~o.L
'Zl

lIeqe}j!l

£l

e}jn4:><lW

6

Jeses

Ol

e!uEd

H

ESE'tJ

9

SUO!}jSU!A

l

~e4S!Sed

S

SuoSwn'tJ

l

OJ!Z

'Z

haWn)! SunJn)!

£

IlYZYA

t>

O!pOdEO

S

°ley

zrra~~

Ll£'ZS'SZ
VZ9'S6'l8
g6v'm'og
6vg'gv'££'z
Lv["L'oS'z
Slg'Ll'fgr9
c.:99'v9'oo'n
4lJeW

AJenJqa::J

ogz'oz'v
vZ9'6S'Lv'V
S99'L9
999'6Pf~
L~g'oS'g£'z
£'I7v'v,'gg
gfz'f£'gS'l
bL'gg'vS'l
oSg'~S'gL'S
l6g'SL'£6'fl
AJenuer

gr-SlOneCJA:-aI:J~
JOJld!a~-a.lf'mUi1I\'aBHloBo"

S

edn'tJ

6

- Z3M 10 le~o.L
Suess<I)! <I}j}jed

S

ell!pwos

9

Eddas

l

<I<IIESES

£

le~!dE)

t>

SueMel,

l

unSepe4eN

'Z

e!dnA

-a.l!HU \d}.:IJ

'ON'IS

UO!S!A!C

-

aSJNRlD!5'f1\!Crt
<JS!M~lUOW
(m)T-iJ1ON

<!-- page 18 -->

i:

.~

Z

0

p 0 0
o 0 b
o 0 0

~b

g

~o

.,,~
[ig

'"a

or

II

I

I

0

o g

~

~

~

3

i!'

..:..,~

!!.
j~

<}

I

~
~

!I-

0

!

.....I:ii
~

i

ill

~Slii
!»!
s aF i

~i~~
b~

g

~

N

~ 'Ii 'i
S b,.., foil',

iI

~,

g

00

o~ ".
~~
go ~o~

...
'"i

i,~'" '" s!l-

-<

h ~.., ~ i~
0,

i

~
~

~"

"2 :

... t.

Q~

.~

"ll

\i:~

!;\

'i

~.~

l~

~"~

.~
'1l "g:

;~r.:'~

ii:;E
..~

~ ~~

j

2" ...

. .".

;:'

~ ~

;:

i~ ~ g"
J:Jl,

;J
]I:

'"iii

z;

~'~
F

~

~
r-

I
0

i

<!-- page 19 -->

0

(7\

"'"

OQ
(I)

.......

o
.....

VI

:J

0

AI

00.,

:J

0

c:

.....

VI

:J

'-J

'<

~

""0

c:

lI'I

(I)

"-l

'-'

\J1

.....

........

....

c: 3
VI
(I)
cj 11\
iii" ;::;"

c... 0

,.....
I.
:J 0

..,

3
I'J)

Z
0

VI

(I)

".....,.,

.., .., c:

.....
....
11\

(I)

n
0

l'!'

0

V1

AI

...
.... !!' 1.J ..... ~ ~ 1:0 '-

11\

.., ..,

c:

~

n

e

VI

:J

0'1

\fI'

00

0\

.!'I
,....

00 \cD0

"-l

..f>.

,....

.....
~

0

-....J

'-J

>.0

0\

V1

.....
'TI

N ~
a ..f>.
o,[)'
0'\ \..IJ
0 :.. VI .:n
i.J
.... 00
~ \J.I ..f:>

>.0
UI

""I

iii

c

....
n·

""0
DI

""I

.....
VI

"'-J

......,

-t: .0 ..... UJ N ~

...

0
-1>0

\0
'-I VJ

VJ

-::

'~

'"

'"

.p. -.....J
0

"

~

-.....J

g

0-. 0\ \JI

,.... ..f>.
.....
C1' \J.I
~
....
J-J tn 8'
ID .J::> i:n i;J
00
N
<.D 0 Oa
00
:::n
00 '"00 w
~ ~
0
ID >.0' In
N ~
0
Co 00 i:n ~ tn'
tn ~

...
b

oA

.....
b '0

s-

~

....

-f
0

1

....

.J:)

S
..... I.D ~ .,....
11.1
1..1 0 ~
0\
\J'I ..,
..f>.
~
~ .00 ':?
0 V1
r-:"
VI
\b
~
b
..._ o UJ
0\
..... V1
VI Ion
~ -.....J ;-J ,0 00 UJ 0'1 .....
.p. (.u 00 '-.J 0J (!r" VI .,j,.
,.... N V1
Q\
00 I.D \Jl Vl

I.U
(7\

...

\..IJ

~ I'J)
..... .CI"I
.J::>
(7\ ..... 1:0,
CI'"
0 ,.... 0 \:oJ 00 '::l JIl ""I J:)
l. "-J
1:0 ~CI"I' 0 .... ..f>. C oA
0,[)
0
(r,
,....
~ \.Jj
0-. \J.I ~
00
'-J ..... 0 \.AI 0 \Q
0 ,....
0 0 \J.I -.....J 00 VI 0'\ ~
CtJ
"-J (u 00 UJ
:..
~ 0\ 0 ....... I.JJ I.D '-!J IJ1
W

\lo

""0
AI

.......

VI

:J

0

(I)

0

r» :J!:t" n ....

""0

3 c: S20 VI
c:
(I)
3
3
3 ~ 3
....
(I)
(I)

VI

:J

0

rv rv

s:

OJ

0'1
::s
~ 00 \J.I ""0 e
::;.. I.D
.... ~0\
\Q
..... IJ1
"-l
~O\
~
:::n
0'1
::.... ~ UI 00 00 i:n
'" '-J

0'1

\I,j

'6

--i

rv z
:J
r:o
c: 0 0
c... p§:
~ 3 c:
....
';<;"
2:
c: ,,"
3 :J
::s
VI
0. ""0
A
no c: rv
3
0
....
r- (I)
.., 03
iiJ (I)x" iii" ;:::t:'
c:
n
::r iii" 3
lit -2 o, n (I)..... 03:

0'1

V1

'"
,:,

o

'"

~

tD

:r

r+

0..,

..(1

'-"

if

-

11'1
AI

"""

~
o

DI

3

3

c

VI

c:

OJ

III

c:

:J

""0

c:

0

:J

Z
0

VI

:J

0

c:

11\

:J

0

VI

:J

0

rv

(I)

~"

no

0

III

.J::>
VJ

11\

IV

Vl

(I)

0

c:

..,

(I)

3

:J ,......._
.!...
:J 0

Z
0

11\

11\

;::;"

iii"

'"

,....

IV '-"

(I)

.., ,...,.

c:
11\
,...,.

3

-< c... 0

"'C

"'0

lI'I

.., c:
.., ,......._

:J

n
0

iii·

..,
n n

:J
c: c: 3 c S20 11\
c:
(I)
3 3
(I)
.., (I).., ..,11\ 3(I) ~no 3(I)

:J

0

n n

(I)

(7\

-1>0

V1

\JJ

a..

V1

VJ

'"

W
~

IV

0

"-l

0

0

0

-1>0
-1>0

0

IV

O"t

0 tv V1

0

0
0

IV

..f>.

IV

V1

IV

w

!'J UJ
V1 IV
UJ W

V1 -.....J

VI

\0

IV

...

"

'

ra.
-1>0 b~
-1>0

0

s:
...

~
.....
..... \0 S" (1)
~..... ID C" .0
~ J-J ID s::: ~

V1

0

0

00

IV

0

V1

0

00

.!'I

-.....J

-.....J

0

W
w
w .!'I 0
\JJ
.0
00 \0
\0 0\ ~ 0\ \JJIV W -.....J
-1>0
~..... ~0 V1 .!'I ~ ':?
..... 00 w
CJ\ 0\ ~ \0 VI
00 -.....J ,....
VJ g '-P ..f>. 00 V1
b ......
0 tv '-.J 0 \J'I tv ..:0
I.U

w
00 .!'I

.....

..... ......,
-.....

0\

....

~

1
'6
....

.J:)

..... 0,[)
W
IV
_0
SI'
~
..... V1 iv ~.....
DI
O"t Ion ~
00 -.....J
-1>0
$)
!'> If!
n
~ \0
~ iv 0,[)
.J::>
~
:r
~
CJ\ 0\
-.....J -.....J ~ 0 ..f>.
j., YJ ~ VJ 0\ 0 ,.... 0\
CJ\ 0 -1>0 W 0 Co '-.J '-.J
\D
0

0\

00

1..1 W
lo. ~IJ1 00
IV -1>0 -1>0
V1 '-J
\b
!'J '-!J

-

VI

v"

.J::>

00

a. s '"

""I

c
iii

""I

""0
DI

....
n·

W
.....
..... \0 tn
.....
(7\
~ ;:" ~oe ..... ..... ;. tn AI
::I
lo. V1
W ....
c
\0 ~o
0 ..... !'> ~
.....
0\ ~ W
00
b W
,....
00
..f>.
-1>0
00
~
VJ IJ1
-.....J
ID \0 V1 = 0 ,.... 0\
::...
...... 0 0\ 00 0 '-.J \0 0
-'loo

~

I'J)

(I)

no
.., c:;:::t:' r- 3.., A
.., s:
0
11.1 x" ~ c:
'6
t"I 3
.... -2 o, n .., 03:
':T iii" 3

-I

I'J)

0. ""0
0

""I

"::s 3 ~ c... ~..,;::;" 2:;::;" n3
AI

z

"""
III

.....

CI'\

,:,

0
N
VI

N

~

tD

""I

....
:::r

0

~
~

",......

iii

11'1
11.1

0

~

11.1

-s

§f

C

11'1

<!-- page 20 -->

....
o
.........

~

Dol

"'0

<!-- page 21 -->

<!-- page 22 -->

""0

1

o

z

s,

N

!l.

N

.;

,

!l.

..

~.

l

.
!!i

~g

g

~

~

, . , ~

~E':ig

"Fl .
::

g

<!-- page 23 -->

I

S'68S'E

le:j.o! t'O

-

-

EE'n

vL"91:

VZ'Z1S'1:

9£

ES

Z'09t'E

9£

ES

Z'09t'E

huaw:j.Snfpy

AI:j.'O
Ja:yy) :j.aN
le:j.o!
3HO

-

-

-

[(!)v-a:j.ON] (~as 90) 10d-30-vZ

SV'SV

tvzz

1:1:'SOZ

[(!)v-a:j.0N] (:j.ua~!:j.uo:> Ja4:j.0) :>0

LS

S1:'6

v1:'9SE'1:

S1:'6

v1:"9SE'1:

ZZ'V1:

[(!)v-a:j.0N] (4al\) 10d-30-n
(dX3 a3!:U0) 30 :j.aN
8u!pUels:j.no

4:>JeW

ZZ'V1:

,uel1Jqa.:l

as!M '~dao :ssa1

[(!)v-a:j.0N] (dX3 a3!:U0) 30

.taenuer

9Z-SZ0Z A:I J:j.'OlI:lt JO,JsasuadX]

Jeln3!:j.Jed
leJauag

18 U!Wpy :JU!M045 luawalelS
s-aloN

le:j.o! t'O

U6'6

AII'O

9S1:'Z

1:SZ'Z

589

9SV'1:

ESv'1:

SZL'1:

OZ

6Z1

,-

-

-

-

-

-

-

-

6i9'E

\78£'E

8ES'Z

6i9'E

t8£'E

8ES'Z

(:j.uaw:j.snfpy

Ja:yy) :j.aN
lelO!

[(!)v-a:j.0N] aa:l '!OJd
[(!)v-a:j.0N] (le3!pall\l) 111\1
[(!)v-a:j.0N] (al\ea1) :>11

t:

[(!)v-a:j.0N] ('111dW3) 310

,(ael1Jqa.:l

4:>Jew

[(!)v-a~oN]
[(!lv-a:j.0N]

.taenuer

sa8eM
tl.Jeles

Jeln3!:j.Jed

9Z-SZ0Z A:I J:j.'O'tIt JO,J1503 saaAOldw3

3ll!Mo1,fS luawale:j.S
t-a:j.°N

<!-- page 24 -->

So~'£9'££'0('£
9vofo06f6<:
9Sot9fv9fv

-

£gI'£S'gI'tI' c
~£f99L~~g<:
L0699g06~v

-

9-alON JO t JO t a8ed

g'Z£''Zo'£L'So'~

I£S'~S'~L'Lo'~

g·v6g<:9~9<:L
£V£99VS9~

£·99~V9S99~

S"9LgLLh9£

glg'~t'gG'Sl'I
V·9999Sg6n
~v·£~~£gLoS

iu 'S9't~ 'IS'I
9·<:£StS69n
~<:·Lg6<:S6~S
9·6~Sf9Sto<:
gg·~<:£t6£n
govL69tn~
fh:Sv£66Sv
~·~S699<:99r

£gI'£S'9I'tI'

SO~'£9'££'o£'£

I

t;)

~
~
a.
""
~?,)'St( ~~~
~
ilu!pue~s~no le~ol
~~Je4:lJns ~u~w,{ed ~~el~A!~elnwn')
~u!pue~s~no ledpu!Jd ~A!~elnwn')
lelO.LpueJ!)

~SI'SI'~S'£O'[.

= Z33 10,,, .LO.L
nzal
~~
o£
(wepleA) a3eA
:aUlP$'fuol 6<:
lUlU\' g<:
!eSWeN L<:
~uellnAeH 9<:
oelVII S<:
'17<:
lIewoaa
~UlOH £<:

oSS'IG'lo'tl'I
£·9~96v<:gn
~g·060S9t6t
9·96099SL6~
~o·S<:goo~~~

L·L6~L6Sw<:

v;vS6~99 u
9<:gLSvv60~
69·Sog£LLLv

s«

1(;'~-eJ:g0)l ; II
~SI'SI'~S'£o'l
fb9foS9L<:
LL06go£L<:v

v·VLH£von
g·Lg~~<:g
fn~SoL<:S~

6·669Svofn
60·~££L<:g
vv·zfg~gLv~

6·~LLLSoo£L

[.

-

9·6~vw£vn

L·06oz6£9n

n60LoSn
~f·66vS~g
6~·oL6vn~~
z·g£ow£gn
6r6~00fo£z
~S·£~~66~0~
vg·o6L~on~
f~·vfS69<:9L
9·99LS96zn

L6gLog£Lo~

<:<:·<:<:L£9£9t
6·~6~££9£~£
9·9~LogL6~L

g·~66vg~09~

m

I

6~·£vo~6vz<:
~9·LL£v~£6

= Z3) 1 lelO.L

£ov'Lg'9S'IO'~

~g·gvSno~v
V·9fvSf£V9V
r<:6099£9z9

t6I'5t'g~'

££g'so'55'6£,£

~9t'9t' £17'017'£

f·££~voLz£~

96·L£gv~6~S
Sf·vf699SVL
Iv·<:£ShSgn
9·Hg6zLSz
.g·fS9~S£6S~
£·96g~gvSo<:
9·£9906gv£~

z·<:9999S~9~
~·SSSvoggo<:
9·fL9VVgLf~

~6·L~L9~09z

0

<:<:
(lIezeA) a3ZA
(e>tn4::>aw)G3aVII ~z
0<:
(lIeqe>t!l) caxn
6~
(e~eH) a3eH
g~
(elued) a3ed
Jeses
L~
:puo:PwnH.
9~
S~
ole\,
h
le4j'jlsed
:PUOl>t:PUlA f~
o!podea
n
AaWn)l :aunJn)l
u
o~

gv·6<:£999<:<:
v6·9SSon6
z£·~9V99£~~
fo·n<:fwfL
~·SS9606~0~
~S·SS06~6vz
L·fgv<:fS9S~
S·~wfgfw<:

6Lv6~vgo<:

9·<:60Lo~0~<:

9·9Lfv~S~v
S-·6zgLL<:69V
.~·g££ovSoV9

OJlZ

'lND

~6gS<:vgLz
~·fvLfgSvn
L6fvzSoLo~

6·6~6lLL~g<:

v·<:6W9LgL~

g·~fS~g~og~
6·90vv6£9n
6~90V9f90~
S·9vfL~606f
t-J:j.b

i

V·96L090~ov

= Z3MlO lelO.L

LI'E

(~uessa>l a>j>jed) a3>td
(e!dnA) a3nA
(ednH) a3dH
eddas
ellpwos
j'jueMel
aale:Pes
lellde)
unj'jepe4eN

Lv·~£6~f~ov
6·9V600ggvv
f·vLLo£hgSS·S90SS<:VO<:
6·9V99SvvL~
6·069ffL9L<:
z·699fSLzn
L<:99<:6SSo~
gf6~S~L9f

6
9
L

9
S
V

f

z
~

Z3M
,uenuer

,(JenJq~.:I

4:lJeW

UO!S!A!O

"ON"IS

(saadnij Ul)

gt-SlOt Jea,{ a4l JOl ~UlPu2lslno

aAll2lnwn) aSlM-uolslAlO I aSlM-4lUOW
~fI

<!-- page 25 -->

~

I

ID

o
....

Z

o

....

~

o

....

"iJl
~
~

~
~ 0
0
0
~
00

I\.)

I\.)
I\.)

t

ID

to)
Co)

C1I

Co)
I\.)

::I

~

-

<

0

c
"0

g

=

CD
!)tCl.
::I

o

3 ~

CD CD

~c

::I
IQ CD
-::I

C ::a
::!.1It

11.

;

o "0c:::
_
--

~

~ ..~ "0... IQ::I

0)

a.

-

::I
IQ

::!.~

::I
C

C1.::a
c CD

iil

.. 11.
::I C
-lit

~C::l

0

"

"'1'1

-

!II

3"

-

:t2.

C

li)5!
o iil

c:r CD
'<

11.::1
C

S'CD

-<

!
i.

~

i

g

~

:x:

::I

CD
(11

(11

a.
a. i:»
W
CD

CD

...

o c

I::::
"0

c

0

~a3>
g.. a

~
0
~ co
w ~
w 00

I

"

o CI.

3 ::I

iiliT
.S'

iii :::I
-'
.. :::I
:::r1Q

~

0

CD

-c::

::I
IQ

m
...., en
...., ....,
CJ)
~
en ~
m ..... I\.)

....,
..... g~

~

en !»
:""I
.....
.....
...., N
.....

~

€

iii "i} 1"
_DI
.....
~=&r
.....
Ii)
CD
III
..... .....
3" 31t::a
00 .....
~
m
...., w
co + !!! OCl.~
CJ
~
0 "'1'1
....,
aCCD
..... w
w
~
....,
~::::!_
::I
.....
w

:.... 0

co

-.J

~
en

m

0
0

.....
.....

i-::u
c:rCD

.....
...., .....
.....
m 3" !)tCD
...., w
CJ)
co
!II CD f
m w 0
3 !!.
~
~
:1.
0 iiiC1I
-.J
...., m
::I
!»
-CD
.....
:...
~C1.
~ ~ A

~

t..> 0 en

I\.)
..... ....,
..... 0
en

co

~
C1I W o
en ~

S'!!.
..... ....,
0
3_DI
0
II
...., m ID
~ 3
3" o
~
CD 0
0
co I\.)
..... + ~ ::I-nl::::
to)
0

to)

~ ~
:...
co :... t..>

(11

....,

-.J

I\.)

~ .....
-.J
co

I\.)

- a--

::I
CI.DI

..~o
....
CD I::::
CD III

~

::I

0

3:

-=3
::I 0 o

...., ..... .....
3"
I\.)
en ...., n

(11

CAl
a. eni:» en

to)
Co)

m
....,
en
.....
co

~ ~

-.J

~

I::::
III

n

I::::
III

.. .. ,.

;:;' ~
~
c:r AI
::I
AI

<!-- page 26 -->

SlS'E6
Sl>81l

I UoLoo'vg

ELov

00°'17
z£S'z6
556'9
ov~

zt>~'66
t65'u
gg6'E

z£°1>96'1>

98'ZOl'£

£E-H:z't>

6EoE

6EoE

LJog,£ 1,'£

t:6' 0 9£'£

l~

~

01:£'58

8trS'~6

IlL!'fi'l:

86~'zo'~
OS9'O~
og°!:i~
vf06~
oLoogo'e:
EooESE
LEoSg~'E
SboggL'v
oLoLll

9EE'zo'£
9z9'8z
~g
vL
oSI,'S
000'~
1:00'0
19~'n
gv~

iz-oz
ggoEl
mogg£'~
£rvLl
I vooggv'l
googgS'E
oSogo~

£9S'90'~
~E~'o~
vLove:
llooE
~00n6(~

I

t>nlE
tl'6'17£'E
vgogll'v
OooHe:

HMWI
HMW
HMW
HMW
HMW
HMW
HMW
HMW
HMW
HMW
I

i~
LSO'tlL
~06IZ~

aoV
89996'-z
66£'8£

swl7

-

nt>'96
'~

flo6-l55"E

.

'_

r-

-

-

-

£z5'66
glO'L

-

9££'~z'~

95'990'5£'£
8SS'£

S~O'l
~ae:

nO'6
£9S'S

t>£O'V~
Lgv v~

-

-

-

OlS
oES

. E~9'l
oL~'E

-

LSD L
ol::.L'be:
Sgl'L
f6L
~~6'L
gSl'S
19S'Ol
SEg'e:
voo S
SlS'B
9SE'S
gvv z
bvL'L
gLL'~
VL5
E9v'L
6W'v
svE
6H'L
09l'l
9Z-JEW
..

-_

,{)fJau] ~ndul ~aN ,;I+]-!)
UO!~EJaUa!)UMO a~E~SIE~O~ ,;I
UO!:j.e.J3U3~
13S3!O 9
UO!:j.e.J3U3~
JelOS
S
v
d3H puelue4}1
(P3.1\!3J3l:1)AP:J3U333J.:IIHS}lIO
I:
e:

~

Imm1

a~EIS U! p3:j.ja!ul.Gf;RIu;J:J,iIN 0-)=]

HMW

•

1

•

(3:j.e:j.SeJlUI) 5501 UO!SS!WSUEJ1.
(3le:j.SJ3lUI) 5501 uojssnusuarj

%

(i)JElS Jil'lUI) 5501 U,O!ssjw5ueJ1

HMW

a1E~SU! papapa!ul ,{)fJau] B-"=)
ap!s 1nO :a.aodx] ,{)fJau] lelo~
B
lJOdX3 UO!le!A30
L
31eS3l:1
ldl.dN 31eSleJ3lellB
ldJdd'v'- 31eSleJ3lel!B,
ldJdd'v'-lJOdX3 pU!}jUeB
ld1.dN (X31) 31eSAP:J3U3
ldJdd'v'(X31) 31eSAPJ3U3
alEJS aln ap!51no :a.aOdX]A2JJau]
aaJ;j ,/! :a.aOdwlAjUaU] IEI01
lJOdWI UO!le!A30
PO puz (\:fN9.J,.) :uodWI f\pJ8U3
(X3I) :poau}] A)'fJ3U3
l3a!3:>3kl ilU!}jueB
'J3d J3n3SLJdlN)l:I'v'HJW1.
oJ3d J3n3S (Jd.lN) NQ'v'91'v'HV}]
°J3d J3n3S (Jd1.N) 'v'}I}lV"tI'v'.:I
teue:j.eled) lJd1. J9NO
(Jd1.N) dd1.pB
(OJd33N)ddJJ1.~'v'
toJd33N) ddB9'V'
(P3A!3:>3kl)APJ3U333J.:I9N3WV'}I
(OJd33N) 9N3WV'}I
(pa.l\la'~'d) NlJ3U3 33J.:I3l:1'v'd
(OJd:i3N) 3l:1'v'd.
(JdHN)}I'v'1.}lOl i
(OJd33N) ~N'v'AOO
(p3A!3:>3l:1)APJ3U333J.:Id3Hl:I,

HMW
HMW
HMW
HMW
HMW
HMW
HMW
HMW
HMW
HMW
HMW
I HMW
HMW
HMW
HMW
HMW
HMW
HMW
HMW
HMW
HMW
HMW
HMW
I!Un

9
S
t>
£

z
~

v
6L
SL
L~
9L
5~
VL
£L

l~
~L
OL
0
S
L
9
S

17
(OJd33N:) d3Hl:I
E
(OJd13NJ !)NboN'v'H}I
z
(OJd33N)
L
lOJd33N) i-ruao»
UO!~EIs/:pa!OJd 10 aWEN 'ON°IS
, .
~....'-.

uruao»

~'

L

d3H IHS}lIO
UO!:j.e.J3U3~
OdHO
(lJOdH) rupequmg
UO!lEJaUa!) UMO a~E~S

[!J
°1U
(a:j.E:jiSe~lUI) 5501 UO!ss!w:sl.re:J~,

%

-

tsc»:

OVO'L
oSg
SOS'~
lEo'OL
ns'g~
LoS £"
gLo'L

ses-e

-

HMW
HMW
HMW
HMW
HMW
HMW
HMW
HMW
HMW

SOO'£
. £ECE

t>08'£~'~
EgS'l

vSg
gLO'L
In'l
Lg~ OL
50l'Sl
LLL'"17
' e:LL'g
ogCn
oB'S
E£t'L
e:SS
Vlf'L
Ltv
S£S'£
S06'L
vEe:
L9
gOL'l
9l:-UEr

fo6'L
9l:-qa;j

zso v
Et6
S09
Ee:O'L
lLI::.
v6g'l
LSV'L
goe:

~-

HMW

6EoE

v56't>o'~
058'8
L
E9g
OVl'~

OH'l
OOV'~

ve:E'S

e:g~'L
loolgl

e:VS'll
vl::.S'gL
000'1::.

ozz'z
LgS'S
Sg6'ge:
oLS'lg
EOv OL
vvS vl
ofs'g£
Le:S'VL
lS9'v
Sll::.°l::.
Egv'E
ZVl'L
g69'H
SLE'L
LSL
OLS'~
o9l'9
IEI01.

(J\f ASJU3) L-alON

<!-- page 27 -->

!'oJ
!'oJ
0

....
, , ,

I

!'oJ
0
!'oJ

!'oJ

I

!'oJ
0
!'oJ

0
W
I
!'oJ
0
!'oJ

0
U1 00
0 0

!'oJ
0
!'oJ

!'oJ
0
!'oJ

....

!'oJ N
0 0
!'oJ N
0'1 0'1
0
0'1 \.0
0 0

W 'U"I
W VI
J::.

....~

en

W
..... .....

U"I

W

0
00
0

W

,

0
!'oJ
0

!'oJ
0
!'oJ

-. ....

0
!'oJ
I
!'oJ
0
!'oJ

,

0
!'oJ
!'oJ
0
!'oJ

I

0

,

0
!'oJ
0
!'oJ
!'oJ
0
!'oJ

....en, ~ ,

0\

!'oJ
!'oJ
I
0
!'oJ
I
!'oJ
0
!'oJ

0
U1 00
I
0 0
!'oJ !'oJ
I
I
!'oJ !'oJ
0 0
!'oJ !'oJ

.... ,

N

N

N

!'oJ
0

!'oJ
0
!'oJ

0
!'oJ
!'oJ

O'l

0
!'oJ

0
!'oJ

.... 0\D 0!'oJ

00
0
!'oJ

.... ....

'"

I

I

!'oJ
0
!'oJ

!'oJ
0
!'oJ

I

0
U1
I
0

!'oJ
0
!'oJ

I

!'oJ
0
!'oJ

I

!'oJ
0
!'oJ

0

en

\D
0
I-'

I-'

....

I

IJ1

,
N

,

N

aI

~
0

aI

3
DI
..,~

III
III

0

'fit

s:

III

::r

III

ID

~
N
~

III

-.

):0

iii'<

3 2:

.. s:....

-I
DI 0
:::I ::::I

::r

0
:::I

.....
loll

III

ID

o
<
:::I ID
r- ...
DI
~ o
IIIOQ

aI

::::II

ICT

DI
N

0

III

::::I
iiJC. r-

... ....
DI
';'

...,

O'l

.... ....
tg_ ....

U1

0

tg_ tg_ ~a.

N

00
0

.... .... ....

O'l
r-- w ....
0 ~
.....
0
.....
w

~

N

a 0

......

I

0

,_. 0....

N

...... ....

N

0 0
!'oJ !'oJ
0'1 en

N

.... 0
6 N
IJ1

,'_'

0

en

Iv

O'l

0

0
!'oJ

N

N

N

.... ....

::::I

III

::r 3

n

::::I
DI

.,c -I
iii
):0

~ ~ ~
~ U1 00 !J1 !!!.. iii·
~ .....
-a ci"

en en en en

0
!'oJ
I
!'oJ
0
!'oJ

!'oJ
U1 00
0 0

...., , ,
.... ...., ....,
0

-a

ID

0

Z

..,
.... o·
.... ....
c.

en en en en
r+
r+
r+
r+
a a a a

!'oJ
0
!'oJ

0
I

!'oJ
0
!'oJ

0

I

!'oJ
0

.... ....
,
.... .... .... ....
en ~,

!'oJ

"'"

IJJ

....

"'1'1
ID

...,

~c. 00 ~a. ~a.
~a.

....

N

0
!'oJ

00
O'l
..... .....
....
.....
00

~

0
!'oJ

w
,_. f:-

\D

0
!'oJ

, ,_.,
N
6
\D N U1

W
0
!'oJ

N

en en en en

!'oJ
0

!'oJ
0

w w ~ ~
00 00 0 !'oJ
00 W !'oJ en

en en en en

!'oJ
0
!'oJ

,

0
W

0

....,

en en en en
r+
r+
r+
r+
a a a a

!'oJ
W
I
0
!'oJ
I
!'oJ
0
!'oJ

1.0

00 ......

s::

tg_
c.
..., 12c. tg_ ~...,

O'l

w w w

0

0

U1

I'"'
IV

!'oJ
0

~

I

I

I

....

w w w

!'oJ
W
0

en

N

!'oJ
0

..... 00 !'oJ

~ ~ ~ ~
!'oJ ~ .... 0
.....

en en en en

I

I

w w w w

0

~,

en en en en
r+
r+
r+
r+
a a a a

0
W
I
!'oJ
0
!'oJ

I

.... 0 0!'oJ

0
W
I
!'oJ
0
!'oJ

0
W
I
!'oJ
0
!'oJ

w
, en
, ~,

!'oJ

IV

.... ........
~ ~

!!!.

....
DI

-

::::I

ID

3

ID

....

1/1

~

III

a

r-

1/1

-=i
3

00

a
r+
m,

Z
