---
doc_id: "f1ab2bad84fafc78"
source_url: "https://ulb.arunachal.gov.in/pdf/orders/minimizing-degradation.pdf"
ministry: "Directorate of Urban Local Bodies, Arunachal Pradesh"
title: "Order w.r.t Minimizing Environmental Degradation - (430 KB)  13-09-2023 ."
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "85506681655bae1e"
---

<!-- page 1 -->

owen )
File No.: DULB-12023/2/2023 /“0 ¥/— YS
DIRECTORATE OF URBAN LOCAL BODIES / SeeUMaAHTa eRe
GOVT. OF ARUNACHAL PRADESH / SVHRSSoTaATAGT
ZOO ROAD, ITANAGAR / ats OTERR Ss, $e TR
Dated: Itanagar the 13 September’ 2023
ORDER
As part of our commitment to environmental sustainability, we are taking significant measures to reduce
our carbon footprint and minimize environmental degradation. Hence, to reduce our plastic waste, the use of
single-use plastic water bottles will no longer be endorsed within the premises of the office. To aid in this
transition, the Directorate of Urban Local Bodies will be providing each employee with a stainless-steel water
bottle. It is robust, reusable, and most importantly, environmentally friendly. Further to ensure the health and
safety of all employees, we have installed a RO Water filter system in the office. All employees are advised to
fill their water bottles from this RO filter.
| trust that each one of you will understand the significance of this directive and adhere to it diligently.
Let's make our office a beacon of environmental responsibility and sustainability.
Sdl-
(Hano Takka)
Director, Urban Local Bodies
Govt. of Arunachal Pradesh
Itanagar.
Memo No. DULLBVEst-16/2022.23/4 oy -G3 Dated Itanagar, the 13 September’ 2023.
Copy to:- :
1. PA to Director, Urban Local Bodies, Govt. of AP for information please.
2. Joint Director to strictly monitor the attendance.
3. All concerned for compliance.
4. Office copy. _
\ons_—gh and
Director, Urban Local Bodies
Govt. of Arunachal Pradesh
Itanagar
