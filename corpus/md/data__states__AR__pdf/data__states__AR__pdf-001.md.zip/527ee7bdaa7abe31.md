---
doc_id: "527ee7bdaa7abe31"
source_url: "https://eodb.arunachal.gov.in/uploads/notifications_and_orders_documents/3a7ce0f6dcfbb9081eabe1911340956c.pdf"
ministry: "Arunachal Pradesh Investment Portal"
title: "Fee Structure for Registration/Renewal of Shops and Establishments Act, 1966     -->"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "674a563e1a218d08"
---

<!-- page 1 -->

1. Fee Structure for Registration/Renewal of Shops and
Establishments Act, 1966
Application Fees is to be paid online using any of the available payment options like Net Banking,
Credit Card, Debit Card, etc. The Application Fees is as per following criteria
Ss. F
N Category peer
2 annum
Hotel (A&E). Nursing Homes. Cinema Halls. Privately managed Educational Institutions (+ 2
level and above). Privately managed Professional Colleges and Institutions, Petrol Pumps.
1 Insurance Companies excluding Life Insurance Corporation. Financial Institutions, Banks Rs.2000
excluding Reserve Bank of India and State Bank of India, Chartered Accountant Chamber. and
Wine Shops. Vehicle Show Rooms. Gas Agencies. (Not covered under Factories Act).
Computer Training Centres. Jewellers. STD/ISD/PCO Centres, Health Fitness Centres, Health
7 Clinics, X-Ray / Ultra Sound / ECG Centres, Hostels (C&D Categories), Banquet Halls Rs.1000
~ (Janjgahars). Cable Operators. Medical Agencies. Agencies other than Medical Agencies. ~
Privately managed High Schools, Ice Factories (Not covered under Factories Act).
3 Privately managed Middle Schools Rs.800
4 Clinical Laboratories. Privately managed Primary Schools. Beauty Parlours. Tent & Light Rs.500
houses. Ice Candy (Not covered under Factories Act). ~
5 Shops and Commercial Establishments employing 20 or more workers. Rs.2000
6 Shops and Commercial Establishments employing 10 to 19 workers. Rs.1000
7 Shops and Commercial Establishments employing 5 to 9 workers. Rs.500
8 Shops and Commercial Establishments employing 3 to 4 workers. Rs.300
9 Shops and Establishments employing less than 3 workers. Rs.150
10 Shops and Commercial Establishments run by the Owners without any employees. Rs.50
