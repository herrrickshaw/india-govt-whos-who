---
doc_id: "afd2afa7984fac91"
source_url: "https://apssb.nic.in/upload/files/RECINS001/Tender_notice_for_paper_20250522_145024.pdf"
ministry: "Arunachal Pradesh Staff Selection Board"
title: "Download"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "9063ce063d8a1db6"
---

<!-- page 1 -->

SE Star

Ky, Sa No

(8/  eay Ve

rst arg GOVERNMENT OF ARUNACHAL PRADESH

\5\ oe [e} ARUNACHAL PRADESH STAFF SELECTION BOARD

Oey ITANAGAR
anaga A
No. APSSB-11/1/2021 Dated Itanagar, the 22"4 May 2025
Notice Inviting e-Tenders
The Secretary, Arunachal Pradesh Staff Selection Board, invites on behalf of Governor of
Arunachal Pradesh online bid for the following work(s):

1. NIT no. APSSB-11/1/2021, Name of Work “Empanelment of agencies for the work related
to capturing OMR image, scanning of answer sheets readable on OMR system, result
Preparation for examinations & other activities related to processing of results of
competitive examinations”, Earnest Money Rs.1,00,000.00 Period of Contract — Two
years; Last time and date of submission of bid 12/06/2025 12:00pm.

The bid form and other details can be obtained from the website
http://www.arunachaltenders.gov.in
pate) 6
Krishna Kumar Singh, IAS
Secretary, APSSB
etary
stat selection Board
ir
oils of AP itanagar
