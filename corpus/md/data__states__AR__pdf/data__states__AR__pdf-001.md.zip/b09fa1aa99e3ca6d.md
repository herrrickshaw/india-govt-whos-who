---
doc_id: "b09fa1aa99e3ca6d"
source_url: "https://www.arunachaluniversity.ac.in/admin/uploads/news/Revised-Circular_-_Durga_Puja_Celebrations-2026.pdf"
ministry: "Arunachal University of Studies (AUS), Arunachal Pradesh"
title: "Read more  about annoucement"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b80a54ae4d36e4ce"
---

<!-- page 1 -->

NH-15, Knowledge City, District Namsai, Arunachal Pradesh-792103
Ref: F.17.2/AUS/Circular/Oct 2026

Date: October 12, 2026

CIRCULAR
In supersession of the Circular vide Ref: F.17.2/AUS/Circular/Oct 2026 dated October 07,
2026 We are pleased to inform you that the University will observe holidays on account
of Durga Puja and Dussehra from October 19, 2026 to October 21, 2026.
On behalf of the University, we extend our warmest wishes to all students, faculty, and
staff on the auspicious occasion of Durga Puja and Dussehra.
May these festive occasions bring happiness, peace, prosperity, and success to you and
your families.
With best wishes,
Sd/(Divyanshu Goel)
Registrar
Copy to:1. PS to Pro-Chancellor
2. PS to Vice-Chancellor
3. PS to Rector
4. Finance Officer
5. Controller of Examinations
6. All Deans/Director/ Principals
7. IQAC Cell
8. Joint Registrar
9. All teaching & non-teaching staff
10. Department of HR
11. Department of Accounts
12. Department of IT
13. Notice Board
14. Guard file
Sd/(Divyanshu Goel)
Registrar
