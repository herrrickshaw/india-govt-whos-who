---
doc_id: "2ecbf4eed6eef7f8"
source_url: "https://apeda.nic.in/docs/tenders/NIQ_Hospitals.pdf"
ministry: "Arunachal Pradesh Energy Development Agency (APEDA)"
title: "Open"
date: ""
pages: 31
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "222150f60c28babf"
---

<!-- page 1 -->

SHORT NOTICE INVITING QUOTATION
DOCUMENT
|
| Name of Work: Designing, Manufacturing, Supply, Testing of LED Street Lights of
75W, 5OW & 20W for Model Energy Efficient Village Campaign &
Implementation of Energy Efficiency Measures in Govt. Hospitals as
per the standards & specifications of BEE, Govt of India.
1. ESTIMATED COST : Rs. 10, 02,000/-
2. COST OF TENDER DOCUMENT : Rs. 1000/-
3. EARNEST MONEY DEPOSIT (EMD) : Rs.10, 020/-(APST)
Rs. 20,040/-(General)
4. LAST DATE OF SUBMISSION OF NIQ : 10" Oct. till 12:00pm |
5. DATE OF OPENING OF NIQ : 10" Oct at 4:00pm |
My. |
APEDA
Arunachal Pradesh Energy Development Agency (APEDA) |
Urja Bhawan, Post Box-124, Itanagar-791111
Papum Pare District: ARUNACHAL PRADESH Jed poset
/ : or alll t.
E-Mail: apeda79@gmail.com f ano e
| pEPUTY DIRECTO 3
Tel.No. 0360-2211160 % a PED.A.! ANAGAF
—— Sa —— ae i Ee j
wae creado fe

<!-- page 2 -->

INDEX
[i fecmamwomie
Fe [acridine
fe famiaiewornae
fe fimsimwawes
[2 [eoenicationeeacene |
Page 0
My

<!-- page 3 -->

/ OFFICE OF THE DIRECTOR Ph. : 0360 — 2211160 (O)
f E ARUNACHAL PRADESH ENERGY DEVELOPMENT AGENCY 0360 — 2215963 (R)
(ASTATE GOVERNMENT AGENCY) ae 79@e
Cee se URJA BHAWAN, TADAR TANG MARG Se cael ence clematcon
No. APEDA/W (E)-411/MEEVC-BEE/2019-20 Dated, Itanagar the 25" Sept., 2019
NOTICE INVITING QUOTATION

Sealed Quotations are invited by Arunachal Pradesh Energy Development Agency (APEDA),
Itanagar from the reputed manufacturers/Dealers/Retailers of BEE Star Labelled Electrical Appliances
for Designing, Manufacturing, Supply & Testing of LED Street Lights of 75W, 50W & 20W for Model
Energy Efficient Village Campaign & Implementation of Energy Efficiency Measures In Govt.
Hospitals.

The Tender documents can either be downloaded from APEDA website www.apeda.nic.in Or
purchased from APEDA Office, Urja Bhawan, Itanagar w.e.f. 27” September 2019 to 10” October
2019 during office hours by paying Rs. 1000/- Demand Draft (Non-Refundable). Sealed quotations
may be submitted up to 10" October. 2019 till 1200 Hrs and same shall be opened on 10" October.
2019 at 1600 Hrs in Urja Bhavan, Itanagar.

Sd/-
Director
APEDA, Itanagar.
AG
No. APEDA/W (E)-41 /MEEVC-BEE/2019-20// Loz ee ~Pated, Itanagar th Sept., 2019
Copy to: (0
1. The Chairman, APEDA, Itanagar for information.
2. The Commissioner, Power &NRE, Govt.of A.P, Itanagar for information.
3. The Director, Information & Public Relation, Govt. of A.P, Naharlagun with the request to
publish the above NIT in two Local Dailies. i P
4. The Accounts Officer, APEDA, Itanagar for information \ :
5. Office Copy. Upbe—7
Dirbetor
APEDA, Itanagar
; Page it

<!-- page 4 -->

2: CHECK LIST OF ANNEXURES
(The following information/documents are to be annexed and flagged by the bidders along with
their Technical Bid)
SL. Particulars Submitted / | Page/Flag
No Not No.
Submitted
1 | Annexure- I (Format of Covering Letter) to be in front page of ee
bids
2 Annexure —II (Details of Earnest Money & NIQ Document
fee
Annexure-III (Details of Work experience) a
Annexure-IV (Format for Authorisation Letter) ES al
Annexure —V (Format for Submission of Annual Turnover.
5 | Proof /Certificate to that effect should be produced duly
certified by a CA )
Annexure —VI (GST Registration Certificate should be beret
produced)
7 Annexure —VII (PAN Registration Certificate/Card should be
Submitted
Annexure —VIII (Solvency Certificate from a nationalized bank ee ee
for at least 6 Lakhs should be submitted)
Note:
¢ Bids received without supporting documents for the various requirements mentioned in
the NIQ document will be rejected.
e Hard copy of NIQ document should be in proper spiral binding and all annexure and
their flag should be in proper order.
(Signature of Bidder)
With SEAL
Page | 2

<!-- page 5 -->

3: PARTICULARS OF NIOQ

1 NIQNo. & Date: No. APEDA/W(E)-411/MEEVC-BEE/2019-20/ Dated,
Itanagar 16 Sept.,2019

2 Estimated Cost : Rs.10,02,000/-

3 Name of Work 9 Designing, Manufacturing, Supply, & Testing of LED
Street Lights of 75W, SOW & 20W for Model Energy
Efficient Village Campaign & Implementation of
Energy Efficiency Measures In Govt. Hospitals

4 Period for work g 1 month from the date of signing of the agreement and
completion from the date of issue of Award letter/Lol whichever is

earlier.

5 Amount of 2 (Rs. 10,020/-(For-APST Enterprises)

Eamest money (ii)Rs. 20,040/-(For General Enterprises)
(Refundable)

6 Documentsareto  : Part-I (Technical & Commercial Bid) and Part-II
be submitted in (Price Bid). In Part-I (Technical & Commercial Bid), all
two parts the qualifying documents like , Test Certificates of the

equipments, Experience Certificate with Lol/Award
Letter/Completion Certificates, Make of the equipments,
Credentials of the firm, Company’s profile, Design

aspects, Standards & specifications etc. including earnest

money should be submitted. In Part-II (Financial Bid), '
only the Price bid and amount should be submitted.

8 Last dateandtime : 10" Oct. 2019 till 1200 Hrs
of submission

9 Date andtimeof : 10" Oct. 2019 till 1600 Hrs
opening of
Technical Bid

10 DateandTimeof : : Within one week of opening of Part-I (Technical Bid)
opening of /same day of opening of T. Bid after evaluation of
financial Bid technical bids.

11 Placeofopening : Urja Bhawan, T.T. Marg, Itanagar -791111

of NIQ
(Signature of Bidder)
With SEAL
Mt Page | 3

<!-- page 6 -->

4: GENERAL PARTICULARS OF BIDDER
1 Name of firm 8
2 Postal Address g
3. Telegraphic address E

4 Telephone & Fax 8

5 E-mail :

6 Web site 5

7 Name, Designation and contact no., landline and mobile

No. of the CEO/Director/MD/Head of the company.
8 Name, Designation and contact no., landline and mobile #
No. of the representative of the Bidder to whom all
references shall be made.
9 Amount of the Earnest Money Deposit :
10 Details of Eamest Money, Bank Draft no. and date, etc.(As_:
Annexure -II)

11 Financial capability of the bidder to carry out the work (to:
be proved with a solvency certificate issued by a bank of not
less than 30% of the Tender Value)

12 Technical Soundness (balance sheet for last 2 Years as :

Proof to be enclosed)

13 PAN No., Service Tax Registration No., GST/TIN/ H
GRN No., CST No., Required BEE test certificates (if any)
etc. (evidences/documents are to be attached

14 Name and address of the Indian/ foreign collaboration :
if any

15 Have the Tenderer to pay arrears of income Tax? Hae
yes, up to what amount.

16 Has the Tenderer been ever debarred by any Govt. Deptt. / :
Undertaking from undertaking any work
17 Monthly supply capacity of the items
ees
Page 4

<!-- page 7 -->

18 Details of offer (please mention number of pages and :

number of Drawings, copy attached).
19 Reference of any other information attached by the :

Tenderer (please mention no. of pages & no. of drawings,

copies attached)
20 Has the Tenderer any relative working in APEDA (If yes, :

state the name and designation)

(Signature of Bidder)
With SEAL
Page 5

<!-- page 8 -->

5: DETAILS OF WORK EXPERIENCE/WORK EXECUTED
Please fill in information about similar projects undertaken (as Annexure-III)
Name of organizations, which awarded the works |
2 Name of the location of the work (Please enclose
copy of Work orders / Lol/Award letter)
te oe |
Year of award and year of Completion ee. |
5 | Details of involvement in work as an individual or as a
company
Was the work satisfactorily completed within stipulated
period? Certificates from Clients to be attached.
(Please attach copies of the related documents, Award Letter/Completion Certificate/Lol etc.)
(Signature of Bidder) '
With SEAL
Page 6

<!-- page 9 -->

6: DECLARATION BY THE BIDDER
I/We (herein after
Re ee ee ee
referred to as the Bidder) being desirous of biddering for the work under the above
mentioned NIQ and having fully understood the nature of the work and having
carefully noted all the terms and conditions, specifications etc. as mentioned in the NIQ
document, DO HEREBY DECLARE THAT-

1. The Bidder is fully aware of all the requirements of the NIQ document and agrees with all
provisions of the NIQ document.

2. The Bidder is capable (technically & financially) of executing and completing the work as
required in the NIQ.

3. The Bidder accepts all risks and responsibilities directly or indirectly connected with
the NIQ process and performance of the systems and works they would be supplying/
executing.

4. The Bidder has no collusion with other Bidder, any employee of APEDA or with any other
person or firm in the preparation of the bid.

5. The Bidder has not been influenced by any statement or promises of APEDA or any of its
employees, but only by the NIQ document.

6. The Bidder is financially solvent and sound to execute the work.

7. The Bidder is sufficiently experienced and competent to perform the contract to the
satisfaction of APEDA. ;

; 8. The information and the statements submitted with the tender are true.

9. The Bidder is familiar with all general and special laws, acts, ordinances, rules and
regulations of the Municipal, District, State and Central Government that may affect the
work, its performance or personnel employed therein.

10. The Bidder has not been debarred from similar type of work by APEDA or any
Government undertaking/Department.

11. This offer shall remain valid for acceptance for 2 (Two) months from the date of opening of
the NIQ.

12. The Bidder has attached herewith the earnest money as required in the NIQ document.

13. The Bidder accepts that the earnest money be absolutely forfeited by APEDA, if the
tenderer fails to undertake the work or sign the contract within the stipulated period.

14. The Bidder gives the assurance to execute the tendered work as per specifications terms and
conditions as laid down in the NIQ document.

(Signature of Bidder)
With SEAL
Page |7

<!-- page 10 -->

7: MAJOR ELIGIBLITY CONDITIONS

1. The tenderer should be a Registered Manufacturing Company/Dealer/Retailer (Conforming to

; relevant National / International Standards) or experienced BEE approved manufacturers of BEE
Star Labelled LED Street Lights, who have already supplied similar type of appliances in last 3
years. The experience certificate, related registration/empanelment certificates under the BEE, Gol
should be substantiated. The capacities of Street Lights are 75W, 50W & 20W.

2. Technical Performance of BEE Star Labelled LED Street Lights of 75W, 50W & 20W should be
duly supported by valid test certificates issued by the BIS/ BEE approved test centres as per the
guidelines of BEE.

3. The Tenderer shall submit the latest test certificate of all the Energy Efficient Appliances being
quoted (Details to be enclosed as per Technical Specification).

4. The tenderer should have valid PAN Card/CST / GST registration certificate and a copy of
same should be enclosed. Tenderer should also have Company’s registration certificate and BEE
approval documents.

5. Power of Attorney holder and Joint Venture are not allowed to participate in this tender. :

6. The Tenderer should have supplied Street Lights of 75W, 50W & 20W LED Bulbs and LED
Tubes in last three years. It should be substantiated by the documentary evidence like Supply
Order/ Award Letter/Work Order/Lol/Agreement/Completion Report clearly indicating the Details
of work, Standard & Specification, Project Cost etc (See also Annexure-III).

7. The bidder should be financially sound/solvent to execute the work. A Solvency Certificate of Bid
amount is submitted along with the quotation.

8. The bidders are required to visit the site and do the proper assessment and then submit the bids with
a proper design and drawing of the project. The bids without the proper design and drawing will not
be accepted.

9. The bidders are required to submit the cost of tender document (Rs.1,000/-), Rupees One Thousand
in form of Demand Draft in favour of Director, APEDA, Itanagar payable at Vijaya Bank, Itanagar
along with EMD of Rs. 10,020/- (For APST Enterprise) and Rs. 20,040/-(For Non-APST
Enterprise) only in form of Demand Draft in favour of Director, APEDA Itanagar. Bids without the
tender document fee & EMD will be rejected.

10. The bidder should come with the original/hard copies of the bids at the time of opening for
verification.

11. The tender document issued by APEDA will be the guiding reference. Nothing should be written on
it but it should be submitted along with the bid by the tenderer duly signed and sealed on all pages.
12. The bidder is required to read the tender documents thoroughly before filling the bids to avoid
rejection.
13. Those bidders may only participate who are not holding more than 2 nos. of works in their firms
/ name as on the date of applying this NIQ.
Il Page | 8
°
