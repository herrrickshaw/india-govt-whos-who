---
doc_id: "ad275fbcdf605bcb"
source_url: "https://arunfcs.gov.in/noti_cir/N060206.pdf"
ministry: "Food and Civil Supplies Department, Arunachal Pradesh"
title: "Guidelines for appointment of PDS carriage contractor-cum- PDS wholesale nominee for drawal and transportation of PDS items"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "14b25834fb022c84"
---

<!-- page 1 -->

GOVERNMENT OF ARUNACHAL PRADESH
DEPARTMENT OF CIVIL SUPPLIES:: ITANAGAR.
NO. SCS/7/2005

Dated Itanagar, the 06/02/2006.

NOTIFICATION
Sub: - GUIDELINES FOR APPOINTMENT OF PDS CARRIAGE CONTRACTOR-CUM- PDS WHOLESALE NOMINEE
FOR DRAWAL AND TRANSPORTATION OF PDS ITEMS.
In supersession of all earlier guidelines as issued by the Government of Arunachal Pradesh on the
subject from time to time, the Governor of Arunachal Pradesh is pleased to make the following guidelines to regulate and
streamline the appointment of PDS carriage contractors and PDS wholesale nominees in Arunachal Pradesh which shall
come into force with immediate effect.
I.

Appointment of PDS Carriage Contractor:
(i)

Henceforth all appointments of PDS carriage contractors and PDS wholesale nominee shall be made
invariably through open tender only on district wise basis for which combined tender shall be floated.

(ii)

The Director of Civil Supplies will issue/ public Notice Inviting Tender for appointment of PDS Carriage –
cum- Wholesale Nominee in local newspaper with due consultation with the concerned Deputy
Commissioner. Circulation/ wide publicity of the NIT within the concerned district and constitution of
Board etc shall be the responsibility of the Deputy Commissioner. Intending tenderers shall collect the
tender documents from the concerned Deputy Commissioners.

(iii)

Only persons/ firms/ registered Co-op societies belonging to a particular district will be eligible for
participating in the tendering process for appointment as PDS carriage contractor/ wholesale nominee
for that particular district.

(iv)

The person / firm who is appointed as carriage contractor through open tender will be awarded the
wholesale nomineeship for the entire district, subject to fulfillment of other terms and conditions as laid
down in this guideline.

(v)

In the event of more than one carriage contractor being appointed due to any technical reasons like
rates of two different firms being accepted in respect of vehicular transport and head load carriage, such
appointed carriage contractors will be awarded the PDS wholesale nomineeship in respect of their
respective area of operation.

(vi)

No person or Firm or registered Co-operative Society, granted license as wholesale nominee and
Carriage Contractor for PDS items, shall sub-let the license or engage any other party to carry on the
business of drawal of PDS items and their transportation.

<!-- page 2 -->

(vii)

After floating the tender, the concerned Deputy Commissioner will forward his specific recommendations
with full justifications and all relevant papers, terms and conditions, Comparative Statement duly signed
by the Board members, suggestions and recommendations of the Board, copy of the local newspaper
wherein the tender notice was published etc. to the Director of Civil Supplies for scrutiny and obtaining
Government approval.

(viii)

The Constitution of Board for opening of tenders shall be as follows:ADC

-

Chairman

DSO (Sup)

-

Member

Two Officers from
Other departments to
be nominated by the
Concerned DC.

-

Member

In the absence of ADC the
Senior most EAC may be
the Chairman of the Board.

(ix)

The tendering process shall be completed by January and the specific recommendations of the
concerned Deputy Commissioner should reach the Directorate of Civil Supplies by the first week of
February.

(x)

The carriage rates shall be obtained on a per qtl per km basis in respect of vehicular transport / head
load and there should be no separate rate for summer / winter and hills area / plain area. The
recommendation of the Board and the Deputy Commissioner should be specific and with full
justification. Mere forwarding of the tender papers without any specific recommendations from the
Deputy Commissioner will not be accepted.

(xi)

It should be clearly indicated in the terms and conditions of the NIT that the rates quoted should be
inclusive of all un-foreseen / incidental charges including those arising out of natural calamities etc. The
rates approved through open tender will remain valid for the contract period and no claim for
enhancement of rates will be entertained under any circumstances during the contract period.

(xii)

To avoid quoting of un- reasonably low rates, a bare minimum workable rate shall be worked out by the
Govt. through an expert committee periodically, preferably once in two years, and shall be
communicated to the concerned Deputy Commissioners well in advance of publications of NIT. This rate
should be clearly indicated in the terms and conditions of the tender by the concerned Deputy
Commissioners for information of tenderers. Rates quoted below the bare minimum workable rate shall
not be accepted. In the event of more than one qualifying tenderers quoting the same lowest rate, the
award of contract shall be finalized by drawing of lots.

(xiii)

Rejection of any tenderers shall be justified with specified reasons and should be recorded.

(xiv)

Every tenderer shall submit along with tender papers, a rate analysis, showing in details the basis on
which the tenderer has quote the rate.

(xv)

If there are less than three valid tenders, the concerned Deputy Commissioner shall issue NIT for retender.

<!-- page 3 -->

(xvi)

In case of drawal of PDS items from any other FCI depot, other than the designated depot,
transportation charges will be admissible, between the base depot and the drawal depot, at the rate of
Road Transport Charges approved / paid by the FCI authorities.

(xvii)

The appointed carriage contractor shall deposit a sum equivalent to 25% of the contract value, to be
worked out by the concerned Deputy Commissioner, in the form of DCR/ FDR in favour of the
concerned Deputy Commissioner drawn on a recognized bank situated at the concerned district HQ as
security deposit within one week from the date of issue of acceptance letter. Thereafter, the appointed
carriage contractor shall execute a Deed of Agreement with the concerned Deputy Commissioner and
obtain a license which will be valid for a period of two years from 1st of April to 31st March of the year, by
depositing an amount of Rs. 50,000/- (rupees fifty thousand ) only as license fee. The first year will be
on a provisional basis. On satisfactory performance of the Carriage Contractor in the first year, the
contract for the second year will be renewed after deposit of Rs. 50,000/- towards license fee for the
second year. The license fee should be deposited by the concerned Deputy Commissioner into treasury
under HoA -1456- Civil Supplies. There will be no award / extension of carriage contract without open
tender beyond this two year period.

PDS Wholesale Nominee:-

II.

(xviii)

The carriage contractor whose rates are accepted through open tender for appointment as carriage
contractor shall apply to the concerned Deputy Commissioner for award of PDS wholesale nomineeship
as per clause – I (iv) of these guidelines. For this purpose, the appointed carriage contractor should
deposit an amount of Rs. 25,000/- (Rupees Twenty five thousand) only through treasury challan under
H/A – 1456 – Civil Supplies as license fee and an amount equivalent to 20% of the value of average
monthly quato should be deposited in the form of DCR/FDR in favour of the concerned Deputy
Commissioner as security deposit. The application should include details of owned godowns with
storage capacity and its location, details of rented godowns with copy of lease agreement if any, details
of other available infrastructure at the base area/ district HQ/ other vulnerable locations in the proposed
area of operation etc. after completion of the above formalities, PDS wholesale nominee license will be
issued by the concerned Deputy Commissioner to be valid till the 31st day of March next following the
date of appointment in accordance with the provisions of the “ Arunachal Pradesh Public Distribution of
Articles order, 2005”. However, since the carriage contract is awarded for two years and the carriage
contractor is also the PDS wholesale nominee, the PDS wholesale nominee license shall be renewed
for further period i. e. up to the validity period of the carriage contract, if the performance during the first
year is found to be satisfactory. There will be no award/ extension of wholesale nomineeship without
open tender beyond the contracted period.

(xix)

No person or firm or registered Co – operative Society, granted license as wholesale nominee and
Carriage Contractor for PDS items, shall sub- let the license or engage any other party to carry on the
business of drawal of PDS items and their transportation.

Drawal, dispatch of PDS items
(i)

The Director of Civil Supplies, Government of Arunachal Pradesh, Naharlagun shall make district wise
monthly sub allocation of PDS items based on district wise feeding strength, identified beneficiaries.
Subsequently, Deputy Commissioner of concerned district shall make monthly sub allocation and drawal
authority.

<!-- page 4 -->

(ii)

The allotted quota of PDS items shall be procured from FCI/Stockiest and transported to the Principal
Distribution Centers and its enroute
FPS locations by the first week of the month of allocation,
which should be maintained in hygienic condition and subsequently transported and delivered to the
Fair Price Shop as per sub allocation of Deputy Commissioner of concerned districts. Any problem
regarding non- availability of stock in FCI depot, poor quality, disruption of surface communication
affecting smooth flow of PDS items etc shall immediately be reported by the PDS carriage contractor
cum wholesale nominee to the concerned Deputy Commissioner for follow up action.

(iii)

Buffer stock allotted from time to time as per the policy of the Government should be drawn from FCI
base depot and stored at vulnerable locations of the district during the month of allocation as per
instructions of the concerned Deputy Commissioner of concerned district.

(iv)

The stock should be issued to different FPS on pre payment basis at the wholesale rate fixed by the
Government strictly as per item wise monthly sub allocation made by the concerned Deputy
Commissioner of district which will be on the basis of census population of the concerned location.
The profit margin to wholesalers/ retailers shall be admissible as fixed by the Ministry of Food,
Government of India and the State Government from time to time.

(v)
(vi)

Stocks released from FCI depot must be transported to the location of distribution within seven days
from the date of collection. No stock should be maintained in transit godowns located outside Arunachal
Pradesh for a period exceeding seven days. However, transit godowns may be maintained in the base
area inside Arunachal Pradesh with prior approval from the concerned Deputy Commissioner and such
approval shall not exceed 15 days.

(vii)

The godowns of the Carriage contractor cum nominee shall be open to inspection at all times by the
Secretary, Civil Supplies/ his representatives, DCS/DC/DSO or their authorized representatives.

(viii)

The nominee cum carriage contractor so appointed must have their godown and office in the district
Head quarters with working phones.

(ix)

The PDS wholesale nominee/ carriage contractor shall make available the registration number of trucks
carrying PDS items and the Deputy Commissioner will verify these with the corresponding entry made at
the check gate of the respective districts or through any other means.

(x)

The carriage contractor cum nominee shall submit weekly statement to the District Supply Officer
concerned, showing the item wise details of stock drawn from FCI and other stockiest godown during
the week with reasons for less drawal/ lapse, if any.

(xi)

The carriage contractor cum nominee shall also submit a weekly statement to the DSO of concerned
district on every Monday about item wise details of stock issued to the different FPS during the week as
per sub allocation of the concerned Deputy Commissioner.

<!-- page 5 -->

(xii)

The carriage contractor cum nominee shall also submit other reports and returns of PDS items drawn
from FCI base depots/ stockiest godown as and when called for by the authorities.

(xiii)

Trucks belonging to Civil Supplies department may be engaged by the carriage contractor cum
wholesale nominee for transportation of PDS items on payment basis, whenever trucks are available.

Submission of HTS/RTC claims:
(xiv)

On the basis of receipted challans/ coupons dully countersigned by the local Administrative Officer and
the representative of vigilance committee or as the case may be, the district authority shall prepare the
HTS/RTC bills of PDS items to be signed by the concerned District Supply Officer and counter signed
by the Deputy Commissioner. Such bills shall be submitted to the Director of Civil Supplies who will
verify such bills and forward the same to FCI authorities or as per prevailing instruction from
Government. A copy of the format for presenting HTS/RTC bill is enclosed at annexure – I.

III.

In addition to above terms and conditions, the carriage contractor cum wholesale nominee shall abide by the
provisions of the following Acts and control orders while dealing with PDS items.
(a)
Essential Commodities Act, 1955.
(b)
Arunachal Pradesh Food Grains (Licensing and Control) order, 2005.
(c)
Arunachal Pradesh Food Stuff (Hoarding and Profiteering) Control order, 2005.
(d)
Arunachal Pradesh Declaration of Stock and Prices and Monitoring of Essential
Commodities Order, 2005.
(e)
Arunachal Pradesh Public Distribution of Articles order,2005 and
(f)
Arunachal Pradesh Kerosene (Licensing and Distribution) Control order, 2005.
(g)
And any other provisions of the Law as applicable from time to time.

IV.

The Carriage Contract /Nominee ship may be terminated at any time due to failure on the part of the carriage
contractor/ nominee to full fill any of the terms and conditions laid down in the guidelines and in the Deed of
Agreement and license, by giving 15 days notice after attending personal hearing, if considered necessary.
Other work also. For example, if the nominee ship is terminated it will automatically result in termination of the
carriage contract also and vice versa.

V.

In case of termination of the Carriage Contract/ Nominee ship in the event of any court order etc., the Deputy
Commissioner should make interim arrangement for a maximum period of 3 (three) months by appointing the
second lowest tenderer, at the approved rate and shall take simultaneously action to re float tender.

VI.

If any departmental godown is used by the carriage contractor/ nominee, the standard rent shall be paid by the
carriage contractor / nominee to the concerned Deputy Commissioner who will deposit it into treasury under H/A
– 1456 Civil Supplies.

VII.

Model Deed of Agreement to be executed with the PDS wholesale Nominee and PDS carriage contractor, form
of license for functioning as PDS wholesale nominee and carriage contractor and model terms and conditions for
floating of open tender are enclosed at annexure – II, III, IV, V & VI respectively for guidance.

<!-- page 6 -->

NO. SCS/7/2005/278-312
Copy to:
1. All Deputy Commissioners, Arunachal Pradesh.
2. DCS.
3. All DSOs, Arunachal Pradesh.
4. PPS to HCM/PS to HM (CS).

Secretary Civil Supplies,
Government of Arunachal Pradesh,
Itanagar.
Dated Itanagar, the 06/02/2006.

Secretary Civil Supplies,
Government of Arunachal Pradesh,
Itanagar.
