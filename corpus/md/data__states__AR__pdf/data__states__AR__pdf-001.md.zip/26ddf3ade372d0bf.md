---
doc_id: "26ddf3ade372d0bf"
source_url: "https://apeda.nic.in/docs/tenders/E_O_I.pdf"
ministry: "Arunachal Pradesh Energy Development Agency (APEDA)"
title: "Open"
date: ""
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7cbbe556cf05322f"
---

<!-- page 1 -->

EXPRESSION OF INTEREST (EOI) DOCUMENT FOR SETTING UP OF
INFRASTRUCTURE FOR VIDEO CONFERENCING FACILITY FOR SDA, APEDA AT
THE DIRECTORATE OFFICE, ITANAGAR ARUNACHAL PRADESH.

1. COST OF DOCUMENT

: Rs. 5,000/-

2. EOI PROCESSING FEE: Rs. 25,000/3. LAST DAY OF SALE OF EOI DOCUMENT: 19th DECEMBER 2019 (UPTO 12.00 PM)
4. LAST DATE OF RECEIPT OF EOI DOCUMENT: 20th DECEMBER 2019 (TILL 12.00PM)
5. OPENING DATE OF EOI: 20th DECEMBER 2019 (AT 3.00 PM)

1

<!-- page 2 -->

INDEX
SL NO.
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.

PARTICULAR
Front Page
Index
Notice inviting expression of interest
Checklist
Information for submitting the offer
Bidder’s organization & experience
Criteria for evaluation & selection process
General information of bidder : annexure -1
Annexure –2
Annexure – 3
Annexure - 4
Annexure – 5
Annexure – 6
Annexure – 7
Annexure – 8
Annexure – 9
Technical specifications & standards
Undertaking

2

PAGE NO.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18

<!-- page 3 -->

OFFICE OF THE DIRECTOR
ARUNACHAL PRADESH ENERGY DEVELOPMENT AGENCY
( A STATE GOVERNMENT AGENCY )
URJA BHAWAN, TADAR TANG MARG
POST BOX NO. 124, ITANAGAR – 791 111

Ph. : 0360 – 2211160 (O)
0360 – 2215963 (R)
Fax : 0360 – 2214426 (O)
E-mail- apeda79@yahoo.com
apeda79@gmail.com

Dated Itanagar, 20th Nov. 2019

No.APEDA/W(E)-412/VC-BEE/ 2019-20

NOTICE INVITING EXPRESSION OF INTEREST

Arunachal Pradesh Energy Development Agency (APEDA), invites this Expression of Interest (EOI)
from reputed registered BIS/ISI certified/approved Individual Firms dealing in IT and Video Conferencing
Services having minimum five years experience of setting up of infrastructure for Video Conferencing
facility for SDA APEDA at the Directorate office, APEDA, Itanagar Arunachal Pradesh.

Interested parties are requested to submit their EOI in the prescribed format along with all
supporting documents/credentials to APEDA Directorate Office.
The EOI document can be downloaded from our website www.apeda.nic.in & www.arunachaltender.gov.in

Last date of submission of EOI: 20/12/2019 till 12.00pm

Sd/-,
Director
APEDA, Itanagar.
Copy To:
1) The Director General, Bureau of Energy Efficiency (BEE), Delhi for kind information Please.
2) www.apeda.nic.in
3) www.arunachaltenders.gov.in
4) The Commissioner Power (P & NRE), Itanagar for kind information.
5) The Deputy Directors of APEDA.
6) Office Copy.

Director
APEDA, Itanagar.
3

<!-- page 4 -->

CHECKLIST
Please note:
To help you prepare the best application possible, all items below need to be considered and ticked off.
This will also assist us for proper assessment of your application.
During EOI submission, please keep this page after the cover page.
(Put √/× in the appropriate box under remarks column)
Have you checked and enclosed:Sl.
no.
1

Description

Page
No.

Photocopies of credentials/supporting documentary evidence.

10

2

Photo-copies of GST/ST Registration Certificate

2

3

Photo-copies of Provident Fund Registration Certificate

2

4

Photo-copies of IT PAN

2

5

Photo-Copies of Service Tax Registration Certificate

2

6

Annexure-1

2

7

Annexure-2

10

8

Annexure-3

10

9

Annexure-4

10

10

Annexure-5

10

11

Annexure-6

5

12

Annexure-7

5

13

Annexure-8

5

14

Annexure-9

5

15

Final Envelope containing all the above

2

Total Marking

Marks Remarks

82

 The Firms graded with highest Marks shall be selected for RFQ (Request for Price Quotation)
 The payment to Firms after completion of the work shall be done subject to availability of fund from
BEE.
4

<!-- page 5 -->

Important Information for submitting the offer:

How to Obtain EoI
In person

O/o Director, APEDA, Urja Bhawan
T.T Marg, Itanagar-791 111
Papumpare District

Website link

www.apeda.nic.in & www.arunachaltender.gov.in

Cost of EOI document (INR) through DD in favour
of Director, APEDA, Itanagar.

Rs. 5,000/-

How to Submit EoI
Demand Draft in favour of

Director, APEDA, Urja Bhawan,T.T Marg, Itanagar

EoI Processing fees

Rs. 25,000/- per application submitted for processing /evaluation

Submission of EoI in one set of hardcopy and one
softcopy (both)

Last Date of sale of EoI application / documents: 19/12/2019

Time Up to: 12.00 PM
Opening of EoI
Last Date for EoI application receipt

20/12/2019 time Up to 12.00 PM

Opening date of EOI

20/12/2019 at 3.00 PM

Venue

Urja Bhawan, Itanagar

For any clarification contact via email only at “apeda79@gmail.com one week before opening of EOI date

5

<!-- page 6 -->

Bidder’s Organization & Experience:

The Bidders must have the following qualification criteria:
1. Credentials:
The Bidder must have inline experience in setting up of infrastructure for Video Conferencing and
operating it. The Bidder must submit documentary evidence (work order & performance certificate) in
support to the above. The bidder must be a reputed BIS registered or ISI certified Company /Firm and also
Empanelled.
2. Commercial:
Bidder must have an average annual turnover of 2 crore during last 3 years.
The Bidder must submit the following with the above maintained criteria:
a) Photo copies of GST/ST Registration Certificate, Provident Fund Registration Certificate, IT
PAN and Service Tax Registration Certificate.
b) Annual turnover and balance sheet of last 3 years.
3. Test certificates:
The Bidder must submit all the test certificates separately of the Equipments.

6

<!-- page 7 -->

CRITERIA FOR EVALUATION & SELECTION PROCESS

The interested bidders shall be called to Corporate office of APEDA at Itanagar to give their presentation on
knowhow in this field and their experience on Video Conferencing Based on the credentials and presentation,
the agencies shall be shortlisted. RFQ (Request for Price Quotation) shall be invited only from the listed
bidders.

Note:
a) EOI must contain the name of the company/firm, credentials, Completion Certificates of setting up and
operating of Video Conferencing, name of the contact person with address, contact number (Cell no.,
Fax no., E-mail ID etc.).
b) The designated representative should be well conversant in Video Conferencing.
c) APEDA reserves the right to accept/reject any Expression of Interest (EOI) from parties without
assigning any reasons whatsoever.

7

<!-- page 8 -->

Annexure-1
GENERAL INFORMATION OF THE BIDDER
Note: separate sheets may be used wherever necessary.
1. Name and Address of the Bidder:
2. Name & designation of the concerned officer to whom all references shall be made :
3. Fax nos.:
4. Phone nos./Mobile No.:
5. E-Mail Id :
6. Chief of the Organization:
E-Mail Id:
Telephone:
7. Total No. of Employees/Manpower Strength:
8. Type of the organization (Public Sector/Limited/ Private
Limited/Partnership/Company/Manufacturer/NGO):
9. No. of Offices/Centers(Enclose The List):
10. Bidder’s Proposal No. & Date:
11. Particulars of Past Experience of Similar Works Furnished :
12. Any other information that bidder may like to give in order to highlight his bid :
13. Name & address of Designated representative, if any:

Place:

Signature Of Party:

Date:

Name In Full:

Designation/status:

Company seal:

8

<!-- page 9 -->

Annexure-2
Name of the Bidder:
DETAILS OF WORK AND SERVICES OF SIMILAR NATURE DONE BY THE PARTY DURING THE LAST FIVE
YEARS(which best illustrate qualification):
Sl
no.

Name of
Company

Description of
work

Value of
work

Period
From

To

The work is done directly
or through sub contractor

Remarks

Note: Photocopy of Performance Certificate/Completion Certificate of Owner in Support of the work
mentioned above is required to be enclosed.
Note: separate sheets may be used wherever necessary.

SIGNATURE OF THE BIDDER
SEAL OF THE BIDDER

9

<!-- page 10 -->

Annexure-3
Name of the Bidder:
CONCURRENT COMMITMENT
Sl
no.

Full postal
address of
client &
name of
officer-incharge with
contact
details

Descrip
tion of
the
work
done

Value of
contract

Date of
commen
ce ment
of work

Scheduled/Revi
% age
Sed completion completion
period
as on date

Expected
date of
completion

Remar
ks

Note: separate sheet/credentials may be used/enclosed wherever necessary.

SIGNATURE OF THE BIDDER
SEAL OF THE BIDDER

10

<!-- page 11 -->

Annexure-4
Name of the Bidder:
The bidder shall indicate herein his annual turnover of proceeding 3 years based on the audited balance
sheet/profit & loss account statement.
Financial Year
Present year
Previous year
Previous to previous year

Annual Turnover (Rs.)

Net Worth(Rs.)

NOTE:
1. Copies of audited balance sheets with profit and loss account of 3 years shall be submitted
along with the Technical bid in support of above entries.
2. Bidder shall work out Net worth on the following basis:

Net worth:

reserve + capital – accumulated loss.

Note: separate sheet/credentials may be used/enclosed wherever necessary.

SIGNATURE OF THE BIDDER

SEAL OF THE BIDDER

11

<!-- page 12 -->

Annexure-5
Name of the BIDDER:
ORGANIZATION CHART SHOWING NO. OF QUALIFIED ENGINEERS & SUPERVISORY PERSONAL ETC. IN THE
EMPLOYMENT OF CONTRACTOR & TO BE DEPLOYED.
Class of manpower/engineer/supervisor

Details of personal to be
deployed on this work
Available with
To be
contractor
employed

Sl no.

No.

Note: Names and short resume of their qualification & experience may also be given for key
personnel in the prescribed format at Annexure-6
The tentative chart of your site organization as above furnished by you shall be subject to
variation to suit the construction/maintenance/operation programmed requirement and as
directed by owner/ engineer-in-charge.

Note: separate sheet/credentials may be used/enclosed wherever necessary.

SIGNATURE OF THE BIDDER
SEAL OF THE BIDDER

12

<!-- page 13 -->

Annexure-6
Name of the Bidder:
Name of the firm/Company/Agency:
Name of the Employee:
DATE OF BIRTH(DD/MM/YYY):
Year with Firm(in years):
Nationality:
Detailed Task Assigned:
Key Qualifications:
Education:
Institution:
Year:
Course:
Employment Record:
Summary Of Relevant Experience:
Language Proficiency:
Language
Speaking

Reading

Writing

Certification:
I, the undersigned, certify that these data correctly describes my qualifications, experience and
confirms my availability to the firm for the proposed work should we be awarded the tender.
[Signature of Employee]
[signature of authorized representative of the firm]
Full Name of Employee:
Full Name of Authorized Representative:

Date:
Date:

NOTE: Separates sheets may be used wherever necessary.

SIGNATURE OF THE BIDDER
SEAL OF THE BIDDER

13

<!-- page 14 -->

Annexure-7

Name of the BIDDER:
SUPPORTING/ATTACHED DOCUMENT LIST (if any):
Attachment No.

Supporting Document/Additional Sheet Document No.

Note: Separate sheet/credentials may be used/enclosed wherever necessary.

SIGNATURE OF THE BIDDER

SEAL OF THE BIDDER

14

<!-- page 15 -->

Annexure-8

Name of the BIDDER:
Details of Suggestion/Deviation, if any:
Sl no.

Page no.

Description

Remarks/Reasons/Alternatives

Note: Separate sheet/credentials may be used/enclosed wherever necessary.

SIGNATURE OF THE BIDDER
SEAL OF THE BIDDER

15

<!-- page 16 -->

Annexure-9

Name of the BIDDER:
Safety, Health & Environment Compliance & Highlights:
Sl no.

Description

Remarks

Note: Separate sheet/credentials may be used/enclosed wherever necessary.

SIGNATURE OF THE BIDDER
SEAL OF THE BIDDER

16

<!-- page 17 -->

Technical Specifications:
Parameters
Multisite communication VC unit
Band Width for communication
Camera

Codec Unit (CODER-DECODER)
LCD, HD Plasma display TV(52 inches)
Microphones & Speakers
Broadband Internet Access
Static Internet Portal

Specified Value
Capacity to add more than one site for video
conferencing
More than 6 mbps
1080P PTZ with powerful specifications, high –
definition (HD) conferencing cameras with advanced
features like remote control pan, tilt & zoom
FOR VIDEO CONFERENCING
High definition display ranging between 720P & 1080P
Digital, should be able to deliver instant connectivity &
cancel any background Echoes
With Modems/Routers
Creation of IP address for video conferencing &
enabling it as dialing number to APEDA, SDA Office

17

<!-- page 18 -->

UNDERTAKING

I have read the above terms and conditions along with technical standards and accept the same. We
hereby declare that all the information and Statements made in here are true and understand that the
above information is accepted by APEDA in good faith, and if found false will lead to our disqualification
from the EOI/LOI at any stage.

Authorized signatory:

Signature:

Official Seal

18
