---
doc_id: "91b1b70ab9ef5aff"
source_url: "https://www.arunachalplan.gov.in/wp-content/uploads/2026/03/Home-Police-Order-for-additional-allocation-of-Rs.262.20-lakh-during-CFY-2025-26.pdf"
ministry: "Finance-Planning & Investment Department, Arunachal Pradesh"
title: "ADDENDUM 1"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8fb4432a8b10e5f8"
---

<!-- page 1 -->

.l D
101 41 1 12025-O/o, DIR-SP-FPID-Part(39)

*

*

f

u*ui

r. ot

(Comp. No. 291359)
GOVERNMENT OF ARUNACHAL PRADESH
FINANCE, PLANNING & INVESTMENT DEPARTMENT
(PLANNING & INVESTMENT DIVISION)
A.P. CML SECRETARIAT:: ITANAGAR
Dated, the 6th March 2026.
ORDER

Approval is hereby accorded for an additional allocation of Rs. 262.20 Iakh (Rupees two

crore sixty-two lakh twenty thousand only) to the Home (Police) Department for the
implementation of the following schemes/projects during the current financial year 2025-26:
(Rs. in lakh)

st.

Name of Scheme

No.

District

Estimated
Cost

Fund
allocated
during
2025-26

4

5

1

2

3

1

Refurbishing of Police Station Jang, Tawang

Tawang

2

Safety and Communication related

Namsai

30.00
100.00

30.00
25.00

Tirap

131.95

50.00

Tirap

65.22

65.22

Tirap

41.98

41,98

Anjaw

100.00

50.00

469.15

262.20

installation in the new office of IGP cum SP

office (Eastern Zone) Namsai, Namsai
District.

3

establishment of the Office of lnspector
General of Police (lGP), TCL Range at
Borduria, Tirap District

1. Providing Drinking water, supply at IGP
TCL Range Offlce at CO HQ Borduria, Tirap
District

2. Re-wiring & providing stable power supply
to IGP TCL Range Camp Office Building at
Borduria

3. Provision of furniture, electrical &

4

electronics items for temporary IGP (TCL
Range), office residence and staff quarters
at CO HQ, Borduria
Furnishing of Old Structure of Police Guest
House, Hawai
Total

2.

The same will be regularized at the time of finalization of RE 2025-26

3.

Utilization of fund is subject to adherence to the following:

a) This allocation is purely indicative in nature and this shall be utilized by the departments

only after verifying the actual requirement and observance of guidelines and all the
financial rules, regulations, provisions, prescribed in GFR, DFPR, etc. &

guidelines/circulars/ OM's/ directives issued by the CVC, MoF, MHA, Gol, Administrative
Ministries of Gol & GoAP from time to time in this regard in letter & spirit without fail.
b) The department shall incur expenditure only after the necessary allocation of fund and
budgeting in consultation with the Finance, Planning & lnvestment Department of the
Budget Division which will be regularised at the time of finalization of RE 2025-26.
Page 1 of 2

<!-- page 2 -->

//

s/

{1

a

o

I

o-

3

le No. PLNG -1 1 O 1 41 1 12025-0, I o, Dl R-S P-F PID-Pa rt(39)

6;

lw{

nodal department and the executing agency (wherever applicable) shall maintain
proper coordination and ensure that works are executed as per prescribed norms/
specifications.
d) The scheme should be completed as per the timeline so that there is no cost or time
overrun.
e) Fund should be utilized during current financial year for the purpose for which it is
allocated and cannot be diverted for any other purpose.
0 No revised estimate/ cost escalation and change of scheme will be allowed.
g) Department should ensure that there is no duplicity of the works with any other
schemes/ projects proposed/sanctioned by the State Govt./ Govt. of lndia. lf any
discrepancies is detected, the concerned department should immediately bring it to the
notice of Planning & lnvestment Department before commencement of execution of the
work. Diversion of fund to other works in such cases will not be permitted.
h) Concerned Commissioner/Secretary will monitor and review the progress of
implementation of the scheme/ project at regular intervals and shall ensure timely
submission of quarterly progress report, utilization certificate, photographs and
completion certificate etc. as applicable only after necessary review/ verification at their
level.

i) Violation of above instruction/guidelines will be the sole responsibility of the officers
concerned. Further, the amount only as actually required should be used and the
balance amount if any, should be surrendered.

4.

This is issued with the approval of the Competent Authority

P,ilf

(R.K. Sharma) IAS
Commissioner (Planning & lnvestment)
Memo No. PLNG-1 101411 12025-Olo, DIR-SP-FPID-Part(39)
Copy for information to:-

Dated, the 6th March 2026.

1) The PPS to Hon'ble Chief Minister, GoAP, ltanagar.
2) The PS to Hon'ble Deputy Chief Minister, GoAP, ltanagar.
3) The US to the Chief Secretary, GoAP, ltanagar.
4) The PS to Principal Secretary (Home), GoAP, ltanagar.
5) The SPA to Commissioner (Finance), GoAP, ltanagar.
6) The IGP (Planning), PHQ, GoAP, ltanagar.
7) The Under Secretary (BudgeUFinance- D), GoAP, ltanagar
8) The SRA (Budget), GoAP, ltanagar.
9) Office copy.

Page 2 of 2
