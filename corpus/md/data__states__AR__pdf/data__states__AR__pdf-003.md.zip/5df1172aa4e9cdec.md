---
doc_id: "5df1172aa4e9cdec"
source_url: "https://ditc.arunachal.gov.in/pdf/tender/NIT-IT-skill.pdf"
ministry: "Information Technology & Communication Department, Arunachal Pradesh"
title: "View"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "b32a85c703847d9b"
---

<!-- page 1 -->

GOVERNMENT OF ARUNACHAL PRADESH
DEPARTMENT OF IT & COMMUNICATION
ROOM NO 107, DIGITAL CELL
BLOCK NO.1, 15" FLOOR: AP CIVIL SECRETARIAT
Notice Inviting Tender (NIT)
FileNo.DITC-12011/47/2021-SCITeG Dated Itanagar, the 24/01/2022
‘ J The State Council for IT and e-Governance, Itanagar, invites online bids
in two bid system (Technical & Financial bid) from the reputed firms for competitive bidding
for ‘IT Skill Development Programme to generate Employment in BPO Sector’.
The details are as under: -
Name of work: IT Skill Development Programme to generate Employment in BPO
Sector.
(A)Total estimated Cost: Rs.100 lakhs.
()Earnest Money Deposit (EMD): Rs.1,00,000.00 (APST) and Rs.2,00,000.00 (Non-
APST)
(C) Tender Fee: Rs.1,500.00 only in demand draft in favour of Director, Department of IT&
Communication, Govt. of Arunachal Pradesh Payable at Itanagar.
TIME SCHEDULE OF THE TENDER
Date of uploading in website/publishing of Website: https:/arunachaltenders.gov.in
‘ender paper 24/01/2022 at 1600hrs onwards
Start date & time for downloading 24/01/2022 at 1600hrs onwards
ender documents
IStart date & time for submission of online bids | 24/01/2022 at 1600hrs onwards
Last date & time for submission of online bids | 07/02/2022 at 1030hrs
Date & time for opening of technical bids 07/02/2022 at 1130hrs
‘ender opening venue Venue: Digital Cell, Room No 107, Digital
Cell, Block No.1, 1$'Floor, AP Civil
Secretariat, Pin-791111, Itanagar
Date & time of opening of price bids Will be intimated on Website.
Address for communication: Digital Cell, Room No 107, Digital Cell, Block
No.1, 1$'Floor, AP Civil Secretariat, Pin-
791111.
Email: banya.boje@gmail.com
A Phone:+91 9436898856
The interested bidders can download tender documents from the e-tendering website:
https://arunachaltenders.gov.in.
Note: All bids related activities(process) _ like,tender download, bid
preparation, bid submission, bid opening etc.will be governed by Time schedule
under the key dates mentioned in the above schedule.
c a
Project eae Officer
For Director
IT & Communication
Govt. of Arunachal Pradesh
er
Project Officer nance
4 counell fot IT & e-Govel
a Yanagat
