---
doc_id: "8dcef80b2b2cd6ec"
source_url: "https://www.arunachalplan.gov.in/wp-content/uploads/2026/03/Youth-Affairs-Order-for-additional-allocation-of-Rs-192.50-lakh-during-CFY-2025-26.pdf"
ministry: "Finance-Planning & Investment Department, Arunachal Pradesh"
title: "ADDENDUM 1"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "40ce5a37cd791594"
---

<!-- page 1 -->

F

ile No. PLNG -1 1 01 41 1 12025-O/o, Dl R-SP-FP D-Pa rt(39)
I

/ysn

(Comp. No.291359)

oe

OF ARUNACHAL PRADESH
PLANNING
& INVESTMENT DEPARTMENT
,
f,
NNTNG & TNVESTMENT DIVISION)
* A.P. CIVIL SECRETA RIAT:: ITANAGAR
//
Dated, the 6th March 2026
ORDER

c^s,

(!

o. \

rt'(

Approval is hereby accorded for an additional allocation of Rs. 192.50 lakh (Rupees one
crore ninety-two Iakh fifty thousand only) to the Youth Affairs Department for the implementation
of the following Schemes/ projects during the current financial year 2025-26:

(Rs. in lakh)
Name of Scheme

District

Estimated
Cost

1

2

3

4

1

Establishment and building Structures for

Namsai

SI.

No.

Adventure Activities at

Fund
allocated
during
2025-26
5

15.00

15.00

35.00

15.00

Papumpare

80.00

20.00

Lohit

70.00

20.00

150.00

50.00

97.50
25.00

400.00

192.50

Fiddlehead
Campsite, Tengpani, Near Golden Pagoda,
Tengapani, Namsai District.
2
3
4

C/o Futsal Mate at Lungsa lndoor Hall under
Phassang Circle
Drama Play Project
drug Abuse
Awareness Across Arunachal Pradesh.

on

Futsal Ground at Sunpura circle, Lohit
District.

5

6

Arunachal Winter Sports Festival
C/o Futsal ground for community at Popgop,
Audung, Tawang

Tawang

Total
2.

The same will be regularized at the time of finalization of RE 2025-26

3.

Utilization of fund is subject to adherence to the following

a) This allocation is purely indicative in nature and this shall be utilized by the departments
only after verifying the actual requirement and observance of guidelines and all the
financial rules, regulations, provisions, prescribed in GFR, DFPR, etc. &
guidelines/circulars/ OM's/ directives issued by the CVC, MoF, MHA, Gol, Administrative
Ministries of Gol & GoAP from time to time in this regard in letter & spirit without fail.
b) The department shall incur expenditure only after the necessary allocation of fund and
budgeting in consultation with the Finance, Planning & lnvestment Department of the
Budget Division which will be regularised at the time of finalization of RE 2025-26.
c) The nodal department and the executing agency (wherever applicable) shall maintain

proper coordination and ensure that works are executed as per prescribed norms/

specifications.

d) The scheme should be completed as per the timeline so that there is no cost or time
overrun.

e) Fund should be utilized during current financial year for the purpose for which it is

0

allocated and cannot be diverted for any other purpose.
No revised estimate/ cost escalation and change of scheme will be allowed.
Page L of 2

<!-- page 2 -->

File No. PLNG-I 1r14tit2O25-O/o, DIR-SP-FPID-Part(39,/Y

\'

oe

V

should ensure that there is no duplicity of the works with any other
projects
proposed/sanctioned by the State Govt./ Govt. of lndia. lf any
o.
{
is detected, the concerned department should immediately bring it to the
ning & lnvestment Department before commencement of execution of the
work. D iversion of fund to other works in such cases will not be permitted
h) Concerned Commissioner/Secretary will monitor and review the progress of
implementation of the scheme/ project at regular intervals and shall ensure timely
submission of quarterly progress report, utilization certificate, photographs and
completion certificate etc. as applicable only after necessary review/ verification at their
9)

level.

i) Violation of above instruction/guidelines will be the sole responsibility of the officers
concerned. Further, the amount only as actually required should be used and the
balance amount if any, should be surrendered.

4.

This is issued with the approval of the Competent Authority

(R.K. Sharma) IAS
Commissioner (Planning & lnvestment)
Memo No. PLNG-1 101 41 1 12025-Olo, D I R-SP-FPl D-Part(39)
Copy for information to:-

Dated, the 6th March 2026.

1) The PPS to Hon'ble Chief Minister, GoAP, ltanagar.
2) The PS to Hon'ble Deputy Chief Minister, GoAP, ltanagar.
3) The US to the Chief Secretary, GoAP, ltanagar.
4) The SPA to Commissioner (Finance), GoAP, ltanagar.
5) The PA to Secretary fiouth Affairs), GoAP, ltanagar.
6) The Director (Youth Affairs), GoAP, ltanagar.
7) The Under Secretary (BudgeVFinance- D), GoAP, ltanagar
8) The SRA (Budget), GoAP, ltanagar.
9) Office copy.

Page 2 of 2
