---
doc_id: "ebfdfb4830d4ef98"
source_url: "https://www.arunachaluniversity.ac.in/aus/Research/Circular%20for%20declaration%20of%20datesheet%20for%20Ph.D.%20and%20M.Phil%20course%20work%20examination%20_July%202020.pdf"
ministry: "Arunachal University of Studies (AUS), Arunachal Pradesh"
title: "Circular for declaration of datesheet for Ph.D. and M.Phil course work examination July 2020"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "6e3588104a75a3ce"
---

<!-- page 1 -->

Me | ar machal
ANS | university of studivs
Arunachal University of Studies
Established under section 2(f) of University Grants Commission Act, 1956
Vide Act 9 of 2012 the Arunachal University of Studies Act, 2012
NH-52, Knowledge City, District- Namsai, Arunachal Pradesh, Pin Code — 792 103
Ref No. F.1.1.2/AUS/Circular/2020/July-4 Dated: July 06, 2020
CIRCULAR
Declaration of Datesheet of Course Work Examination
Ph.D. & M.Phil. Programme
All the students are hereby informed that the Course Work examination of
Doctor of Philosophy (Ph.D.) & Master of Philosophy (M.Phil.) programme are going to be
scheduled as per the datesheet attached with this circular.
nk Oe ,
Kgters>
AAS pate
Asst. ControJlerof inbiton 2.
Ss o
8\ AE )2
Copy to: or Ss,
1. PS to Hon’ble Vice-Chancellor *F
2. Registrar
3. Joint Registrar
4. Deans & Directors
5. Director Research
6. Asst. Registrar, Research Cell
7. All Concern’s
8. Admin. Office (with a request to circular the same wherever required and paste on the University Notice Board)
9. IT Cell (with a request to publish the same on University website)
10. Research Cell
11. Examination Cell
12. Guard File.
Qa :
h
isi
AS Paidey
Asst. Controtter p£ay andigati 08s)
| Bye )e
c\ AW Je
2 Sg
& Oy
x?
