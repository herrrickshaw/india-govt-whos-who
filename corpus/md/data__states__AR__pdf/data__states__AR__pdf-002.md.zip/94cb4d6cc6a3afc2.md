---
doc_id: "94cb4d6cc6a3afc2"
source_url: "https://www.arunachaluniversity.ac.in/admin/uploads/circular_notice/cn_6a54899046d198_23601276.pdf"
ministry: "Arunachal University of Studies (AUS), Arunachal Pradesh"
title: "Office Circular- Ext. in -Re-registration of Old Students for Academic Year 2026-27"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "abfef23993ae400f"
---

<!-- page 1 -->

Ref. No.: F.L.1.2/Result/2026/O.O./13702
Date: 13/07/2026

रजिस्ट्रार कार्ाालर्
Office of The Registrar

कार्ाालर् पररपत्र
Office Circular
Subject: - Extension in the Re-registration of old students for Academic Year 2026-27.
Dear Students,
Parents and Guardians
Teaching & Non-Teaching Staff
Greetings from Arunachal University of Studies, Namsai!
With reference to the earlier circular bearing reference No. F.L.1.2/Result/2026/O.O./6701 dated
22 June 2026, the last date for re-registration of existing (old) students was notified as 15 July 2026.
In response to the requests received from students seeking additional time to complete the reregistration process, the University is pleased to extend the re-registration schedule as per the
following details:
Sr.no.
1.
2.

Time Period
From 16/07/2026 to 21/07/2026
From 22/07/2026 to 27/07/2026

3.

From 28/07/2026 to 05/08/2026

4.

From 06/08/2026 to 31/08/2026

Late Fee Amount
No Late Fee

₹. 200.00/₹. 500.00/₹. 1000.00/-

All students are advised to complete their re-registration within the above-mentioned timeline to
avoid any inconvenience. Failure to complete the re-registration process within the prescribed
period shall result in the student's enrolment being struck off from the University records, in
accordance with the applicable University rules.
The University wishes all students a successful and rewarding Academic Year 2026–27. We look
forward to your continued academic excellence and wish you every success in your future endeavours.
With best regards,
Sd/(Divyanshu Goel)
Registrar
Copy above information for records and further process to –
1. PS to Hon’ble Pro-Chancellor
2. PS to Hon’ble Vice-Chancellor
3. Office of The Rector
4. Office of The Controller of Examinations
5. Deans/ Directors/ Principals
6. IT Cell (for uploading on university website)
7. Examination Cell (for records and further process)
8. Administrative Office (for vide circulation and information as and when required)
9. University Notice Board
10. University Guard file
Campus: NH – 15, Knowledge City, Distt. – Namsai, Arunachal Pradesh, Pin – 792103.
Email: examination@arunachaluniversity.ac.in website: www.arunachaluniversity.ac.in.
