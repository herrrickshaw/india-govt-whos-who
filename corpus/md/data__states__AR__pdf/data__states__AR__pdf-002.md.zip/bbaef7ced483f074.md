---
doc_id: "bbaef7ced483f074"
source_url: "https://apeda.nic.in/docs/rpo/RPO-Notification.pdf"
ministry: "Arunachal Pradesh Energy Development Agency (APEDA)"
title: "Read More"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4a6e44e8443e2a8a"
---

<!-- page 1 -->

Th
he Arrunachal Prad
desh Gaze
ette
EXTRAO
ORDINAR
RY

PUBL
LISHED BY AUT
THORITY
Y
No. 74
7

Vol. XIX
X,

Naharla
agun,

Frida
ay,

April 13
3, 2011,

C
Chaitra
24, 19
934 (Saka)

ARUNA
ACHAL PRAD
DESH STATE ELECTRICITY
Y REGULATORY COMMISSSION
N
NOTIFICATION
012
The 11th April’20
REENEWABLE POWER
P
PURC
CHASE OBLIG
GATION AND
D ITS COMPLIANCE REGULLATION 2012
2
No. APSERC/NOTIFICATION//8/2012, Daated 11th Ap
pril’2012 : In
n exercise of the pow
wers
b‐section (1) of section 1
181 read witth sub‐sectio
on (1) of secttion 62, secttion
confeerred by sub
66, cllauses (a), (b
b) and (e) off section 86 and clause (zi) of sub‐seection (2) off section 181
1 of
the Electricity
E
Acct, 2003 (36 of 2003) an
nd all other powers enaabling it in th
his behalf, and
a
after previous publications,
the Arunachal
A
Pradesh Sttate Electriccity Regulattory
Comm
mission hereby makes the
e following reegulations:‐

1.

Short titlle and comm
mencement.‐(1) These
e regulations may be ca
alled the
Arunachal Pradesh State
S
Electrricity Regulaatory Comm
mission (Ren
newable Pow
wer
Purchase Obligation an
nd its Compliiance) Regulaations, 2012..
(2) These regulations shall come into force frrom the datee of their pu
ublication in the
Gazette Arunachal
A
Praadesh.

2.

Definition
ns: In these regulations,
r
unless the context
c
otherwise requirres,‐
(a)

“A
Act” means the Electricityy Act, 2003 (36
( of 2003);;

(b)

“C
Central Agency” means th
he agency ass may be dessignated by the
t Central
Co
ommission under clausse (1) of re
egulation 3 of the Cen
ntral Electriccity
Reegulatory Co
ommission (TTerms and Conditions
C
ffor recognition and
isssuance of Renewable
e Energy Certificate for Renewable Ene
ergy
Geeneration) Reegulations, 2010;
2

(c)

“C
Central Com
mmission” means
m
the Central Ele
ectricity Regulatory
Co
ommission reeferred to in sub‐section (1) of sectio
on 76 of the Act;
A

<!-- page 2 -->

The Arunachal Pradesh Extraordinary Gazette, April 13, 2012

3.

(d)

“Certificate” means the renewable energy certificate issued by the
Central Agency in accordance with the procedures prescribed by it and
under the provisions specified in the Central Electricity Regulatory
Commission (Terms and Conditions for recognition and issuance of
Renewable Energy Certificate for Renewable Energy Generation)
Regulations, 2010”;

(e)

“Commission” means the Arunachal Pradesh State Electricity Regulatory
Commission;

(f)

“obligated entity” means the distribution licensee, consumer owning the
captive power plants and open access consumers in the State of Arunachal
Pradesh, which is mandated to fulfill renewable purchase obligation under these
regulations;

(g)

“renewable energy sources” means non‐conventional renewable electricity
generating sources such as mini/micro/small hydro power projects upto
and including 25 MW capacity, wind, solar including its integration with
combined cycle, biomass, bio‐fuel cogeneration, urban or municipal waste
and such other sources as recognized or approved by the MNRE.

(h)

“State agency” means the agency in the State of Arunachal Pradesh as
may be designated by the Commission to act as the agency for
accreditation and recommending the renewable energy projects for
registration and to undertake such functions as may be specified under
clause (e) of sub‐section (1) of section 86 of the Act; and

(i)

the words and expressions used in these regulations and not defined herein
but defined in the Act or the regulations issued by the Central Commission
or any other regulations issued by the Commission, shall have the same
meaning assigned to them respectively in the Act or such regulations
issued by the Central Commission or such other regulations issued by the
Commission.

Applicability of Renewable Power Purchase Obligation (RPPO) .‐ These
regulations shall apply to ‐
(1)
(2)

4.

2

the distribution licensee;
any other person consuming electricity‐
(i)
generated from Captive Generating Plant having
capacity of 1 MW and above for his own use; and/or
(ii) procured from generation through open access third party
sale.

Quantum of Renewable Power Purchase Obligation (RPPO).‐ (1)(a) The
distribution licensee shall purchase electricity (in kWh) from renewable sources,
at a defined minimum percentage of the total consumption including transmission
and distribution losses, within the area of the distribution licensee, during a year.

<!-- page 3 -->

The Arunachal Pradesh Extraordinary Gazette, April 13, 2012

3

(b) The Captive and Open Access User(s)/ Consumer(s), shall purchase electricity (in
kWh) from renewable sources, at a defined minimum percentage of his total
consumption.
Explanation.‐ For the purpose of this regulation “the defined minimum
percentage” shall be as given in the table below:‐
Table‐ Defined minimum percentages
Year

Minimum Quantum of purchase
(in %) from renewable sources
(in terms of energy in kWh) of
total consumption
Total
Non‐Solar
(2)
(3)

Solar
(4)

2012‐13

4.2 %

4.1%

0.1%

2013‐14

5.6 %

5.45 %

0.15%

2014‐15

7%

6.8 %

0.2 %

(1)

Provided that the solar power purchase obligation shall be fulfilled from the
generation based on solar sources only:
Provided further that such obligation to purchase renewable energy shall be
inclusive of .‐
(i) purchases from generating stations based on renewable energy
sources,
(ii) purchases from any other distribution licensee, which would
arise from renewable sources,
(iii) the energy generated from its own renewable sources, if any, by
the obligated entity:
Provided further that the power purchases under the power purchase
agreements for the purchase of renewable energy sources already entered
into by the distribution licensees shall continue to be made till their
present validity, even if the total purchases under such agreements exceeds
the percentage as specified hereinbefore.
(2 )

Keeping in view supply constraints or other factors beyond the control of
the licensee, the Commission may, suo‐motu or at the request of a
licensee, revise the percentage targets for a year as per sub‐regulation (1) of
this regulation.

(3)

The RPPO specified for the Financial Year 2014‐15 shall be continued
beyond 2014‐15 till any revision is affected by the Commission in this
regard.

<!-- page 4 -->

The Arunachal Pradesh Extraordinary Gazette, April 13, 2012

4

5. Certificates under the regulations of the Central Commission.‐
(1)
Subject to the terms and conditions contained in these regulations the
Certificates issued under the Central Electricity Regulatory Commission (Terms
and Conditions for recognition and issuance of Renewable Energy Certificate for
Renewable Energy Generation) Regulations, 2010 shall be the valid instruments
for the discharge of the mandatory obligations set out in these regulations for the
obligated entities to purchase electricity from renewable energy sources:
Provided that in the event of the obligated entity fulfilling the renewable
purchase obligation by purchase of certificates, the obligation to purchase
electricity from generation based on solar as renewable energy source can be
fulfilled by purchase of solar certificates only and the obligation to purchase
electricity from generation based on renewable energy other than solar can be
fulfilled by purchase of non‐solar certificates.
(2)
Subject to such direction as the Commission may give, from time to time,
the obligated entity shall act consistent with the Central Electricity Regulatory
Commission (Terms and Conditions for recognition and issuance of Renewable
Energy Certificate for Renewable Energy Generation) Regulations, 2010 notified
by the Central Commission in regard to the procurement of the certificates for
fulfillment of the Renewable Power Purchase Obligation under these regulations.
(3)
The Certificates purchased by the obligated entities from the power
exchange in terms of the regulation of the Central Commission mentioned in sub‐
regulation (1) shall be deposited by the obligated entities with the Commission in
accordance with the detailed procedure issued by the Central Agency.
6.

State Agency and its Functions
(1)
The Commission designates Arunachal Pradesh Energy Development
Agency (APEDA)
as the State Agency for accreditation and recommending the
renewable energy projects for registration with Central Agency and to undertake
following functions under these regulations:
a.

Frame a procedure consistent with the procedure framed by
Central Agency to meet the requirement of these regulations.

b.

Accreditation of eligible entities at State level and recommending
them to Central Agency for registration at the central level,

c.

Maintaining and settling accounts in respect of certificates,

d.

Repository of transactions in certificates, and

e.

Such other functions incidental to the implementation of renewable
energy certificate mechanism as may be assigned by the
Commission from time to time.

<!-- page 5 -->

The Arunachal Pradesh Extraordinary Gazette, April 13, 2012

5

(2)
The State Agency shall function in accordance with the directions issued
by the Commission and shall act consistent with the procedures and rules laid by
Central Agency for discharge of its functions under the Central Electricity
Regulatory Commission (Terms and Conditions for recognition and issue of
Renewable Energy Certificate for Renewable Energy Generation) Regulations,
2010.
(3)
The State Agency shall develop the formats for
submission
of
quarterly progress report in respect of compliance of renewable purchase
obligation by the obligated entities and get them approved by the Commission
within 3 months of issuance of these Regulations. State Agency may also suggest
appropriate action to the Commission, if required, for compliance of the
renewable purchase obligation.
(4)
If the Commission is satisfied that the State Agency is not able to
discharge its functions satisfactorily, it may by general or special order, and by
recording reasons in writing, designate any other agency to function as State
Agency as it considers appropriate.
(5)
The Commission shall, either on its own motion or on request of the State
Agency, by an order as deemed appropriate, constitute a co‐ordination committee
for facilitating the implementation of these regulations:
7.

Distribution Licensee‐ (1) Each distribution licensee shall indicate, along with
sufficient proof thereof, the estimated quantum of purchase from renewable
sources for the ensuing year in tariff/annual performance review petition in
accordance with regulations notified by the Commission. The estimated quantum of
purchase shall be in accordance with sub‐ regulation (1) of regulation 4 of these
regulations. If the distribution licensee is unable to fulfil the obligation, the
shortfall of the specified quantum of that year would be added to the specified
quantum for the next year. However, credit for excess renewable power purchase
would not be adjusted in the ensuing year.
(2)
Despite availability of energy from renewable sources under the Power
Purchase Agreements or the power exchange mechanism or from its own
renewable sources or purchase of certificates, if the distribution licensee fails to fulfil
the minimum quantum of purchase from renewable sources, it shall be liable to pay
compensation as per regulation 9 of these regulations.

8.

Captive and Open Access User(s)/ Consumer(s).‐(1)The quantum of RPPO
inclusive of transmission and distribution losses mentioned in sub‐regulation (1) of
regulation 4, shall be applicable to captive and open access user(s)/
consumer(s) from the date of this notification in the Official Gazette.
(2)
Every Captive and Open access consumer(s)/ user(s) shall have to submit
necessary details regarding total consumption of electricity and power purchase
from Renewable Energy sources for fulfillment of RPPO on yearly basis on or
before the 30th April to the State Agency.

<!-- page 6 -->

The Arunachal Pradesh Extraordinary Gazette, April 13, 2012

6

(3)
Captive and Open Access Consumer(s)/ User(s) shall consume renewable
energy as stated in the Table below regulation 4. If the Captive user(s) and Open
Access consumer(s) are unable to fulfill the criteria, the shortfall of the targeted
quantum would attract payment of compensation as per regulation 9 of these
regulations.
(4)
Captive/Open Access consumer(s)/ User(s) may fulfill its RPPO through
the renewable energy certificate as provided in regulation 5 of these regulations.
9.

Consequences of default.‐(1) Where the obligated entity does not fulfil the
renewable purchase obligation as provided in these regulations during any year
and also does not purchase the certificates, the Commission may direct the
obligated entity to deposit into a separate fund, to be created and maintained by
such obligated entity, such amount as the Commission may determine on the basis
of the shortfall in units of RPPO and the forbearance price decided by the Central
Commission:
Provided that the fund so created shall be utilised, as may be directed by
the Commission partly for purchase of the certificates and partly for development of
transmission/ sub transmission infrastructure for evacuation of power from
generating stations based on renewable energy sources:
Provided further that the obligated entities shall not be authorized to use
the fund created in pursuance of regulation without prior approval of the
Commission:
Provided further that the Commission may empower an officer of the State
Agency to procure from the Power Exchange the required number of certificates
to the extent of the shortfall in the fulfillment of the obligations, out of the amount
in the fund:
Provided further that the distribution licensee shall be in breach of its
licence conditions if it fails to deposit the amount directed by the Commission
within 15 days of the communication of the direction.
(2)
Where any obligated entity fails to comply with the obligation to purchase
the required percentage of power from renewable energy sources or the renewable
energy certificates, it shall also be liable for penalty as may be imposed by the
Commission under section 142 of the Act:
Provided that in case of genuine difficulty in complying with the
renewable power purchase obligation because of non‐availability of certificates, the
obligated entity can approach the Commission to carry forward the
compliance requirement to the next year:
Provided further that where the Commission has consented to carry
forward of compliance requirement, the provision of sub‐regulation (1) or the
provision of section 142 of the Act shall not be invoked.

<!-- page 7 -->

The Arunachal Pradesh Extraordinary Gazette, April 13, 2012

7

10.

Overriding effect.‐ The provisions of these regulations shall have effect
notwithstanding anything inconsistent therewith contained in any other
regulations, framed by the Commission, relating to the determination of tariff,
and/or making provisions for open access under the Act.

11.

Power to remove difficulties. ‐ If any difficulty arises in giving effect to any of
the provisions of these regulations, the Commission may, either suomotu or on an
application made to it, by general or special order, direct the licensee/ generator or
any other person to take suitable action, not being inconsistent with the Act,
which appears to the Commission to be necessary or expedient for the purpose of
removing the difficulty.

12.

Issue of orders and directions.‐ Subject to the provisions of the Act and these
regulations, the Commission may, from time to time, issue orders and practice
directions with regard to the implementation of these regulations and procedure to
be followed for such implementation and matters incidental or ancillary thereto.

13.

Saving of Inherent Powers of the Commission: Nothing contained in these
Regulations shall limit or otherwise affect the inherent powers of the Commission
to adopt a procedure, which is at variance with any of the provisions of these
regulations, if the Commission, in view of the special circumstances of the matter or
class of matters and for reasons to be recorded in writing, deems it necessary or
expedient to depart from the procedure specified in these regulations.

14.

Interpretation.‐ All issues arising in relation to interpretation of these
regulations shall be determined by the Commission and the decision of the
Commission on such issues shall be final.

By Order of the Commission,

Secretary,
Arunachal Pradesh State Electricity
Regulatory Commission,
Itanagar
