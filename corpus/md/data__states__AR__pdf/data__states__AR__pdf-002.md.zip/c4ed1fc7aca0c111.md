---
doc_id: "c4ed1fc7aca0c111"
source_url: "https://www.arunachalplan.gov.in/wp-content/uploads/2026/03/Indigenous-Affairs-Order-for-Additional-Allocation-of-Rs.-727.50-Lakh-during-CFY-2025-26.pdf"
ministry: "Finance-Planning & Investment Department, Arunachal Pradesh"
title: "ADDENDUM 1"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7cd151b74bb6f24c"
---

<!-- page 1 -->

fin{

File No. PLNG-1 1 01 4 I 1 12025-Olo, DIR-SP-FPID-Part(39)

(Comp. No.291359)
MENT OF ARUNACHAL PRADESH
ING & INVESTMENT DEPARTMENT
NrNG & INVESTMENT DTVISION)
. CIVIL SECRETARIAT:: ITANAGAR
Dated, the 6th March 2026
ORDER
Approval is hereby accorded foran additional allocation of Rs.727.5O Iakh (Rupees seven
crore twenty-seven lakh fifty thousand only) to the lndigenous Affairs Department for the
implementation of the following projects/ works during the current financial year 2025-26:
(Rs. in lakh)

s!.

Name of Scheme

No.

District

Estimated
Cost

Fund
allocated
during
2025-26

4

5

2

3

C/o Dere of hydro power complex Gour Hill
Aalo
Clo Unit Toilet and Furnishing of
Community Centre Taksing, Upper
Subansiri District.
C/o Meditation hall at Nongtham, Kharsang
Circle, Changlang District

West Siang

20.00

10.00

Upper
Subansiri

50.00

12.50

Changlang

70.00

17.50

C/o Cultural Centre (Nyefar Namlo) at

East Kameng

150.00

37.50

C/o Donyi Polo Cultural Centre at Modirijo
Itanagar PH-ll (C/o approach road and
Completion of infrastructure and campus
development)
C/o Dere (Community Hall) at New Hiram
Riga, Siang District
C/o lnfrastructure development at YWGW
Yorlo of Atu Leyu Heritage Centre Upper
Subansiri District.
Establishment of Girl/s Yerko (GURUKUL)
at Hollongi, Papum Pare District
C/o Longte Namlo near Damin General
Gorund at Damin
Extension of community Hall (Dere) at
Yogong Village in Siang District.
Extension of Community hall (Dere) at
Yosing village in District.

Papumpare

200.00

50.00

Siang

250.00

62.50

Upper
Subansiri

300.00

100.00

Papumpare

1,000.00

100.00

Kamle

50.00

12.50

Siang

20.00

10.00

Siang

20.00

10.00

12

Clo Yansgshom Hum cum Meditation
centre (lndigenous Prayer centre) at
Liangnyan village, Lazu circle, Tirap

Tirap

50.00

10.00

13

C/o Traditional Pang (Morung Ghar) at

Tirap

25.00

10.00

West Siang

50.00

12.50

1
1

2

3

4

4

Chayang Tajo, East Kameng District
5

6
7

B

I
10
11

District.

Khetteng village.
14

Extension of Mopin Ground, Lipu Bagra
village, Aalo, WeslSiang dist. (AP).

15

Clo Beautification and Gardeninq of

Papumpare
Page 1 of 3

<!-- page 2 -->

ce

o

o-

st.
No.

LNG-1 1014/ 1t2025-oto,DlR-sP-FPID-Part(3e)

*

Name of Scheme

District

Estimated
Cost

2

3

4

1

lndigenous office complex at Chimpu
16

C/o Boundary wall at Donyi Polo Namlo,
Siga village.

17

C/o 2nos of Toilet at Donyi Polo Namlo,
Siga village.

18

I Un(

C/o lgu Museum at Ezengo Roing, Lower

Fund
allocated
during
2025-26
5

50.00
30.00

12.50
10.00

Upper
subansiri
Upper
subansiri
Lower Dibang

15.00

15.00

500.00

100.00

Leparada
Namsai

50.00
20.00

50.00
10.00

Tirap

100.00

25.00

Papumpare

200.00

50.00

3,220.00

727.50

Dibang Valley.
19

C/o Community dere at Lutak village

20

C/o Ganging(Donyi Polo mandhir) at

21

C/o Nocte lndigenous Knowledge system
and Heritage Centre in Deomali, Tirap

Namliang

District.

22

C/o Cultural Hall at Si-Donyi Jaaring
(qround), Lumro villaqe, Naharlaqun

Total
2

The same will be regularized at the time of finalization of RE 2025-26.

3

Utilization of fund is subject to adherence to the following:
a) This allocation is purely indicative in nature and this shall be utilized by the departments
only after veriffing the actual requirement and observance of guidelines and all the

financial rules, regulations, provisions, prescribed in GFR, DFPR, etc. &

guidelines/circulars/ OM's/ directives issued by the CVC, MoF, MHA, Gol, Administrative
Ministries of Gol & GoAP from time to time in this regard in letter & spirit without fail.
b) The department shall incur expenditure only after the necessary allocation of fund and
budgeting in consultation with the Finance, Planning & lnvestment Department of the
Budget Division which will be regularised at the time of finalization of RE 2025-26.
c) The nodal department and the executing agency (wherever applicable) shall maintain
proper coordination and ensure that works are executed as per prescribed norms/
specifications.
d) The scheme should be completed as per the timeline so that there is no cost or time
overrun.

e) Fund should be utilized during current financial year for the purpose for which it is
allocated and cannot be diverted for any other purpose.

0 No revised estimate/ cost escalation and change of scheme will be allowed.

g) Department should ensure that there is no duplicity of the works with any other

schemes/ projects proposed/sanctioned by the State Govt./ Govt. of lndia. lf any
discrepancies is detected, the concerned department should immediately bring it to the
notice of Planning & lnvestment Department before commencement of execution of the
work. Diversion of fund to other works in such cases will not be permitted.
h) Concerned Commissioner/Secretary will monitor and review the progress of
implementation of the scheme/ project at regular intervals and shall ensure timely
submission of quarterly progress report, utilization certificate, photographs and
completion certificate etc. as applicable only after necessary review/ verification at their
level.

i) Violation of above instruction/guidelines will be the sole responsibility of the officers
concerned. Further, the amount only as actually required should be used and the
balance amount if any, should be surrendered.
Page 2 of 3

<!-- page 3 -->

No. P LNG -1 1 01 41 1 12025-O/o, Dl R-S p-F p I D-pa rt(39)

4.

the approval of the Competent Authority

lvs,{

P,r%--

(R.K. Sharma) IAS
Commissioner (Planning & lnvestment)
Memo No. PLNG-1 101411 12025-Olo, DtR-Sp-FptD-part(39)
Copy for information to:-

Dated, the 6th March 2026

1) The PPS to Hon'ble Chief Minister, GoAp, ttanagar.
2) The PS to Hon'ble Deputy Chief Minister, GoAp, ltanagar.
3) The US to the Chief Secretary, GoAP, ltanagar.
4) The SPA to Commissioner (Finance), GoAp, ltanagar.
5) The PA to Secretary(lndigenous Affairs), GoAp, ltanagar.
6) The Director (lndigenous Affairs), GoAP, ltanagar.
7) The Under Secretary (BudgeVFinance- D), GoAp, ltanagar
8) The SRA (Budget), GoAP, ltanagar.
9) Office copy.

Page 3 of 3
