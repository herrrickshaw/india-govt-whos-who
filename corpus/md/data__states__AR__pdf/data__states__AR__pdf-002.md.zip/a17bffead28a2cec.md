---
doc_id: "a17bffead28a2cec"
source_url: "https://apdhte.nic.in/DHE/SCTE_Act_2010.pdf"
ministry: "Directorate of Higher and Technical Education, Arunachal Pradesh"
title: "Arunachal Pradesh State Council for Technical Education"
date: ""
pages: 10
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "fe5c8887e6527fe1"
---

<!-- page 1 -->

ae eae, ew age eux De a - 4 ie oR “op ee
EG RSs 2 ih a rag ee * hye Shei
Beis nT rs i Om a WO el ae
Bea ON ee ay Cae as e gl Ae ,
POM sie eNO AS al 8 pe nd Cy | Se
Rea ee eg ae to eae
a ea. #3 f see Ay fe
Bt 4 7, Py th ee ‘ fo. |
Pare. a? oe Reet zz - ie te es we
ee he A ees Cao u <d ae
a pete ic ae Peh D2 he 5 aj hase <<.) ee
ee heh fie SNM HOR ey bie aS ee
Rr ay . eo 2% + 8s A | UNAS ow ee ee the Fs
oe a 5 ee eee Do. | ae Cm ie ae
Wega ccs ad 3 ON NI Fa ax Yo
fis bs. E.G Venee x ‘ bows as
Ce fT SH fo OFS IAIN es ey (old ee
ee eee ee Be SRN ea a a
Bet erect . = Sey, ) =~ * ie as
Kee One GY mz Visi - «§ OF a eo tL La
beet ATS fos SU REI wo ina 4
Behe Be ti Re grer oi Ete a C2
EMS ws RL? (0. JZ aS j Wee ©
ee Mole 6 RRs EES eB ANE,
ee ee a SO Ses SANS ek EZ a aN ae
coe vaio ae SOs ABA ea = > c 9 tala ty
ero vate > wo So ee Ree Ast Sy 4 a aa
eee EOP ee pr seen EeP RS Le, ie. ane
i ONT at | OM re * “O70 1B $2 oye x IES + Bye ee Oe
SA see TPs ss Pre yg I ee ee as "
, Oty - i rt Noma fie ae tS eee
] peeiay 3 le a Rope a ae te ag eS ey
ees BEAN a POneh gee ae ago | Cees Bo! ‘
i eed Se NS See iees his ¢ gee Ws ee
C Eee od igs mt, ae oO a eee Et * fe ahd: = " Fat.
rae ain Oe SPCR Sy, le ery A ts eg eee ey,
whlake ee Tipe ae tte: gay, ten (FM, “SE
ee 3 acd s eee he - ve a ys Siac ‘ ara
pee ea RS OE a 23 of Wadler May ore Ee a ae
Fait ge 6 > Nad bk, eee ee aire 4 We, Apes ead

<!-- page 2 -->

|
? ses as AO ees)
ea : cs
sothinplleadeaiemccnec cious ae a eos
—- “+
en z
ow z
3 Sos 8 §
e 23 Doge Fe a
. = ao > Bee
2 Be 28 Bey S 2
Rowe ee a ee > Qs 4
<2 83% ef yar S Qs iS
ga: E a < ms
2o oS. ae Bs SG z =
as Ree Farts a <
; ae a8 6 we ESS 823% x =
Ae See Bp ob ES226 s
se Sia Se 2289 e0sings
$2256 se Pest o wooo sore
zi Re Se ee Gael = = Rae So g 2:2 4S
Be est sé $F2e2 2 SEG? ZF Reo
oo 88 PER ESS Oo S 5 25 ie
Beye 8: a8 PEEPS 32g 85255 = ia,
& oe | © & ESF F @ Say c= 2
Ee gis $ os aS2Sa2i a =" 1 o e
PF UEGe ibe gah geees 233
ee cee FE SE $58.5 : >
Ps a¢ £224 seirzig27* seb 558
zo e83 afb Sse 82 os PR EZe :
Se 855 wig ee S maz26
gE eee ere ee Qzus2 ©
goeBes See iee Ames 3 8
8238 Ba Ee8 3562 &
2 8ss5 go 388 > Oo 8 &
Pio meee Ss Se, zr er a
2¢28 Boo 8 > 5 2s
Ser BBs oe 5 c
| -E88e po gee =
| BODE B29: 3
a oe aes ee g
B Ba 2s &
& & = oz
& 8 # Soe
S Be
ree

<!-- page 3 -->

Fm.
qt
ae a :
~— —_— ~~ =
F ae
: ot S2Zeve Ag
= = SegestOr seSecsersaZzey= og
BES CBSE PeEG See e ae Se RES eSES a SATS Le
- Bs BS plo Se je ome 8 Ee Se Ss F2R8S5SSRES2 22
5 ed 5.8 oF a BES 5 F BS=-BZSOQORRBE os.
Br cceere EB Sef p so aR © 5 4 Soe be 5 s. = mo
2ous BxSaGa aS aaa RE o “ESR eo 28726 5 g >
£9 @ 7 Ogg 5 $38 88655 > er PegeGoenBeS pk
SoS wmS OR eS S8 eS s Bo &@S8"—-e S85 =O 3 G SB
SSRaePeS2S2 ~a8gas & & 3 meOSB eo Bos fag 5
SERRE GES SR 2.F825 ee ge @eecOssesgts 3s
BaESa3¢ ~s" ¢& <@ 5 2? (2°8 oe e868 mes 35 f eS
PRPRSER ARSE OR SE SE Ee give gszages $e ~
Shae Set Parsesse e <8 SlRELR a SR ESS Be IO
o 250 BOS baGooue Foe 2 < gs o meOreteBeeo Sb &
& rp YUMSSsses YB da Be BE Cee ORR SESSe ry Shee
BERES SIRS Seer ese EF Bg Se_gZQicssebos wa Fz
sgtraseny B ao 5 oo Be 3 = Se sts fe
=56 ao Sxeeok pe BE Ss Ae og SoOrehor meso ee 5. 3
a = Gee ° Lag Ee a 6 -Oac6 < = ce o ®
B 2 oF s o es aee SS Ss a SESSES rE Sp 8 aes
SS eos 2.09 § ete eS S Bg Sgnas seEEo BS
eS3c¢2 QBS EBS CRS eas 8 B35 ws € BG@esog =f ap
SES oR EE Gea assesses Z Se BR ESSSPTS REP Ss
Y €g4q ~ >8 8 = eeeoas § Be RaBo Sas eS ee
<3 2 FEnWRPERBS ESAS E © Bees & & oe Be. 9° Shae
erases 28g g 2 ae a eo a MO eas 82ae
= 27 5B oP 2a =] Bec ose &
BSP SR ess Beseeegss & ao RBESeeseage sos FE
fi gorteeas 8 f4c es 3 ¢ & S Stee et = et
Begg heh eseekSsse 2 OF SESERAZSSEES Ss
ga acer ao See eee & Re mEOg OR BOSS S38
seEPssseecisgs ze. Se. ga t@ SSR MSS a> HS
egs@orresest S38 a8 g S = © Bohs 5 & g
$5 Fae 8 S63 &Go Ss Bn meso BESeas g
Bseoe as ORS Seige Ee BES 2BESESSRS ¢
SSS aR og ase BTC SE RE E SS8SiR8 P5598 D
S422 S208 so oeoe eee F na RRB Belg 28 =
RSEQRBRRKR SB oS Seka F s Beochoecrss ss ES
SS QRSPORS eR EBS FSS | &e agBSESERSRTR Bo
FOMPARPCHTEBESSRZ85 29 Been
¥ gees
mh “Peed
gi =
Es Ses
2° 3
8
B , Ao
= =
—-_ ant
> 2 » Ss
> a a 2 : 2
7,3 3 : "
Bae SS Oe I Ok to
Se =, BSD 2:22 SSP 2RSg @eregsaes
= - ey = > 3 > ess o =. = 20 = =
PPE gRlS PERSE RETF E RSE Ecy bis BERE RS EF
. 4 a2 EE eo ‘eS. a ae Pe peo: San a See oe 2. a
B2Sn tS Fei 29-88 BSSRE ashes es 2555 52 GE S68 68
Rog eS 2REt 2, Sus SegsgekR “OOSSe Seaae SoMa F289
. gee g Basi Gg hia a8hes of -Zé Bieetieeot, te Sat = 8
S a352o° 6) acne C Boas Ss.0 8 o Sule oes Hea a a
2e5er eee s 2058 F908 & gee betes 2880 nS F
See8s oy 88355 Ghee s BSS eas Be: 28 ~
sie BES, #42 pees POSES @¢h0% Begs ea Si
eaheg 2292 22508 Regie Leese F295 See RE 8
BZSe2 2885 SELES hE EE Stee BS gag Soe ee 2
$ SOR PRR ts FEG5 2 = gfe Be ae
pease g BSR 2 o5 eaéss BOs oF Fa Faon 2 an
aba Ot eT a ee CAC 3 Q¢eg58 Som Oo U8 SS & Dy
gs8hESefee C8 SSS esos | Soo, gS SES ESR es SBE
Boose FRES Oe 2-22 28 e883 ga288 aoe Sety i ©
wAGESE SSUES SELES F2bgg BEFEe BF2 Sea g &
a ° 5 Bova Fs p oo =F ce rc ot.
age BSEBR OOGgSS 15488 Seed p one S OE vy S
SES88 5788 C8 Rea FSS a Soeceme 2 aq 2 2og s 5
See oS, 23S 6 oe o pee Sa 532 5 g = ES a 5
BEE RERSSE DSSS Bek Beeog gs Fee 2 Bs 2
a St. a sas = ae Beas. oC. =
Pegeiaege SSh8s g25a Qhear Fis 228 2 =
- Aw S os eS > S a
pases. aay Hefen gd g ed moo 6 => or g m
Seep i Geese Soe E85 F508 3 eer s SOS 2B eS
BOB eet ek ohe pee 6 = Spacer & Sree og. 2 He g
afues BBR See Be OS offs S83 apts? o £
a8 Roe s ke e SB og o8 ao ° = oo S58 < 5
Ose oee OB a = 5 cabo. ono 8g Ros Bos ae 5 =
Beg es SEL S § hes >sEa £25 $8 ege e = 3
oon 5 22 BS ZB 22 S343 Seok 2 gfs = =
BERSEo gee Gass FELE So 6s a? 2
Psa@eat 5 o
rr

<!-- page 4 -->

oon
= = = =
fs = s S
$90. 3.8.3.8. .2-Ee8
8 = Vee s 2. Lo
; i Tags 828 8
SP e232 as Sii2is¢ fsa 2
z gg > gen Sse 23's 78g Be 52 23
$Sagneea 8 ae Oe eer sz 38 saee 328 bg bE Ga
SSF FBR = ga 28 8 28 eee eres
eco kies 5 = 7 26 a Bp 4o¢ a ime se bd
i : : ; Bes Bu G
Zeb QR G¢ 08 pL EG Gee is eh aide gig. btss
BBo #28 & 5 Bao s 58 : E ge
gare aeee g as Pe eerie
og 3 = Q =o Be 50 a BFS gi 2268
ie Bae : Se 2 88 oy BS ®o 3 os 2
2Oepn = Seo = -3B 3 7 fees Fe oe a38 ee
Rage zea e 58 22 & Ba SOz, SBo fave = 3B 25
gee g S 38 Be Ses 8 & SBe ee 25 :
Pe Sg Bog Sos-Ssb 3 2 Boos g a 4 g a 8
: ee ue gee gE g Ee 8 3. a fo Gas 5 SG
s = 2 = a oe eo Ss 26 = Zz Beas & 3 e
S = Qe gs ge : in?
3 eae a = Rss uoe ‘ 2.2 Feo § :
fe SER Seon S85 Be 3 Ses: 5 4p Q PS So Ep
of 6 Soe BE Ss e = 9 2525 mos a & goa 8
23 x= = 5 3 3 = Se Sm = Ope be # o
» Bo e ° Bo fs s. & wae 8 z 8 ae
He eg § nie gS ao 26 -f-4 09 Coos Ss 5 = 3
aes Beg bok 28 Som 88 G8 ste gt ong 2b fs
$8 B e za :
Boe eka ee o § ae 5.25 fe Se Sere ge 38 BE 3
a 5 @ S#a SE Or Ss son Bea 53 ga £e 3
| 25 oe age S. So O33 @ PR GE BRO g Be 5 z
2¢6e Spun = as eo B.S So B Bo eee Bs :
fee fae © a ae 2s E mie cess B25 o88 25 s
& BE g & 25 eb es 2
mas &oe ey aS S a Zs Ea = RE i
Eeg 3 To e yy < pe Bo ao ro eo @ a
He z F # = a g
apc pnee 2B pe Gk 2 SE 2eke cei hes fi
gag 58 5 g s Phe ob Ss Bo = 2
Bs = = = aoe = 8 Sah 23 g
nai = 2 8 zo = 2
fee go oe Sy BP 8 eee :
age $23 68 ae: ; fie Mi de gE
gag BGs 2 g Ea Oa a
“Bg ge a a
g8¢ £22
a
“93 p
2s
ef
222
ae
; i
2 fee Se 4
oe a = a 2
=> S 2 Se
S S a Ss ie
é A 2 > PAs
eS zs z ee = FOTO ZO PLR TZ RRS
%. = > '
= = BEG ESO To Poem gur 953 BO eee
Oo2eg"7o0 WoO azeds Bg Bs ee ee s88 £9 EOFS
2999589 ES ao 3 Boe oe 2255 288 59 898
522 G20 Pe oes 5? S398 £3 Be 22 85 BES £6 "208
a g B 2 ss 8 g =. =. S89 2° 2 She Ps = 68. g3
£20 335 35 pages Soa gee ag 2338 sized 42!
EEE EE; =o 22e 29 588 SBS sf s8 Be Ws gS 38 sa5
eg sS¢ F5 28 8 O83 amo S28 oS aes gE 38 Z E
eee gee ge Be = 250 ee aA oe Se Pa S
See ee oe sag qe acefee 2h G4 2k es Pee ait
e253 328 Bghe Ge ack SO Sp Ss ae $580 g@<8
< BRZE EE FES GE aSs é 3388 38 Zo #8 BG
fee Poe 22828 3 ema 8aA358 a8 ee Se
ofS 833 ate. oe Up me ac S> a2. 2.8 2 2g bes
Oo. bee oS Fez ps iF Eidoig is ¢ pega EBs
eres Bg OBE 5 Boag > Oa ee BE
S22" otec seg ps tse Beste ates @ sf 83 eee
ges 3S a be SE Sa URGE 39 5 Bp Sa 3 8
e256 ea Pz 2 Se x 33m G0 <0 Oe & 28 e ase
3 B Bem o oe.
ees oF i SSF 35 Bae Bey 5 Ba 2G 8 628 g 850
ges BE 28 oa és Bees Be ge ag g Be oR
< eS 38. Se As 53a 85 2 g g 8 ae g BS
eve & BS: ae Ee S Bez 2288 ¢ q g g g ris
“3goe Bas es gO ag 6 SP 8S &e § fo & ag
s : g o 5 &
BS ip BE EOSSE ee gE ee nea $ ag g +E
Sao is Q fe es z S258 fe 3 Q 5 :
Bos ee £5 Swe ¢ ao 8 ag, Z es 2e5
2 Beg oo 2 = 96 > a ay
aS ° 2 $a 7S ve 3 a8
— 2 BS 20 5 cet BoB
sae sir Gf ae 2g dg: @ gee
: g ea 3 a g eee
23 Be So 5 ee & i
ees Bé Ey aa08 gs Boy es Pee Ee eb:
aS 26 g a - g2 82 § Pe
28 eho: = ;
au aaa ae BBGEOsS
FRERAARAY BEE eos
, eas GS es
gg Go 28
ee) See
Bh
|
(a

<!-- page 5 -->

~
= = §
> 3 s, a
ee z= eda
> =
I & ¢ 7 = 2.22 89
eee oe pao &
= e # zz SEPSTIE32 22
> fs BS SU ge Ss aesoes
3 Bo £8 Teretere “BES
= Lig & 2 ry Be 5 88 28 Zo Be aa
Poa & CU
ee s 3 JE ze
2 Cea fe Gs ee ee 8 2S
TU
to ay oe 8 st F = Bs 3 7 =
2 & 7 a8 5 Pe o-€ 2,82 $=
EEGTT (go 30 G3 > 9 ss & 2 bebe PP GE
eee a7 323 E geek BF Pg ac 38 8% peerage:
gree GR ga 259 2258 Baas 3 eggs ee 3 oe
e208 & 86 oe 8 £ Be cas Fuss ¢ & @= es
ee sé Pach bE Pe os a Book on a 8-¢ <
FERS 2s 388 Hale Es a2 989s
gB Ao Bs Ba S88 =o pS bs 82 i: 6 eas 2 38
a pa ea e_3% 8 @¢ Sep a
eB: 3 = 8 S358 & =
Pog 38 nae ie x g 2 BS #5 B5
aeas os 28 622 peda lel iees o #8 SE Fe os
gees 35 gf PG Fe Palade bles Pear ee os
eee BS £2 § oe 26 Se ag 228 an Z
2e25 3 ca bags Be S se ag "Se 38 g
Ea 5 as oe wee xO pee Bale ae 75 peg Es
Seae 2g Faun 5 Sa SE 85 3 8 3 =
SESS & BE wee ode, 28 SS25 Bao Bt
R22 SS. af 2 a8 Sa zy.e a ag 2 3 6 3 Q
igs om 33% 23 peg ot a 8 oe ae 8 = 6 g
s8e8 28 mee BS 2.5 Ee op m2 2 e > Ss 2 3
a8 a Bo the Ree SB. 5 e S a 3 8 §
gree £5 g:-8 ae mF 2 2 ge 8 cI
5 5 B < S. aY°s cc} = < ca 5 $s
° gee 5s <8 8 SS Fens Peppa ads
ee = oC oe s
REBR Se Baz eg B < 3 g a g oe 8
BRae os Bs 3s = 6 e S g i 3 8 8 2 a
BE of Be Bfeee 2 g 8 2 Bead a o£ & =
eae B23 2 §& Be sBe sa
sgee Bs a5 ¢ Ss ‘a Pp 2 e ° 3 Ss
g2ge oe BESS 3 & @ & SS
aefe 28 £2 eS 3 5 o eS =
geo eee eo 8 of & 5 ve:
3282 98 ae. = 8. s
3 R gs BS a
2S eE ge BS
S83 :
oop P ge ad
Esos PS
SPs 8
ee
g 29 zg
3 3 =
9
2 =
? 5 Ss N 3 3
GC 8 ao 245
me = = zeSs
= 2°3¢5 oe
a = DEES EES 23s
x 2 ea
A aese Be z2a5E¢ gas
oe Zz aee aoe ep UpEteg bie
Bese S ‘B. .ts fe 2. Bees =
Seseees qaeeg LUE Gae pbieres 22!
 poae BES reso #28 3: esEG2e2 05
= eS PLER eres bb% pects
pa 225 SPHERE G
TeCSETELE gEee22 es 8285 o¢ ao bee a2
Be29 2 B Ss Bon. & = 2 Ce 2
pees igis "ghacril ial ge PEaLLoiE: 28
seek aie ey ES USEED GEE 20 reehgatil iF
SEgL EL ESF ag arias ga 63 ce gealees g:
cFecGrey! pERRTEL ILE eq ceggaese! HZ
Senzgigis erelges iat pede aoe oPes &
2 2 S egaie £8 eo 23 e s 25
298 8R8 8 gE eo S28 6 55 36 9808
a 2eePas a foe os 2 fg S Ge & ge = a?
se2272 as a2 EOshs fag of B 8 face Eo
ee2 8 & 250885 g ¢ Bgbaee?s ee
Seg 8 8S ge fees be es 9 keeeee s te
S23 OB 2 ge BEERS a3 26 a Sg ESeS oe
zai g28 ee ssake 2s 2 Peeeeres £8
eek #3 8 So gE ESS Fe gr 8 3 B bane eg
52828 S2g8 8 Se ae & 8 2 gg eees nS
8 ke 2 g $2 e Ros ag
Ree +s i a ES Bg 2 Soe = ge 8 es
Baas Fees z8 ey a2 ge 28
be Bee & BSE é& Seog 28 ss
8 : = Bas > oge8 § aS 3
228 a eS Bee 3 5 2 e33. a2 p
3 gee s j 5 5 a. 53 Rs g 2 S238
ges ge Bases 5 o eoeak
as E. 88 BES Bs #8. 3 35
gig = pi bees $2 -23 & PS
Bae = ee eee hs Eg 8 OSs
eee. bag SoS ES 228
8.8 asses 3 8
a6 2 BB esha gee
og aa 888 & &
Gee aa a &
ae ESO
208 SRERBES
= st 5 So 4
oF 2 PeEeeee Ss
a OER 838308
O88 yomee 2 2
28s. eo fs
BE Ese» © £.9 —_
eereegeee
Fig Baaa og
cer
|
———

<!-- page 6 -->

=,
q
B
oo
= Bo
cS si Tesnes
® 6-6: 6 ~ ae S2EF SER TER BES
22 SZ BPTSTTE LEB P OES a
SBA ne Coo eur B8enue8egs se
s 32 Cece Cate a8 Fee SESRE Sy 3g &
Seseegs age gs Op Ce can, eEeETSR ERG EEE> ERG aES
FES OS Ss g Pam 2a 6 a4 Seaecge Se SR 8s. E SS
BAS fp 53 a separ Glo EleiSv i Gklsouy eB Eaes
Ba8 § @ 3 oat oo 55 me COENOF cue <8 oo a
Bas 23 58 g oe oe. se ae 35 = aecaeet = St By @ Bey 8° §
a 8. a0 gs os @ pb 2. og Bs — a
ORB FZ BS a2 eB 2 oie 28 5 oe P8270 2 Se— Sa 8
gee ao fe Pe g fog @ a8 "Es8285 SoBe = Sapsige
236 a58 38 58S Soben Be & eeeesse8 ag2255
5 #6 Boe, oe See) Baas as =e gaos Se e288
222 Bo $@52 o3 BE 2250 6 Ye o 8 kp St
ee Gs Re BER 2s 3 px 45 a8 e383 ec. B8@ a GB Ss
= @ 53 BS Gas Seeks Pe Q g $e 38 36
Pos 3 56 Be a2 5 cw Sxeeros eee Ee Bop o
Ss 3 SEE 8 aS2 22 Fe g BBO S228 2 O58 BES 2
SSE & 2 Se ease ai eB SEB pLO BS g
$e Re Pes SPees oaks EB gr sesves £62
eee eee gc Seh eo RFEE Poaceae @g282o3 BeESS
° = ° SS ¢ Ra Pp a = es BD Bow
eS £55 fe a os ore $2258 “ce = ot 8653e@
22es 23 > Se Poo Se 3S B- gREB oo “EES 3s 6 a
ae? -3B Ss eBs gem a7 Bspzeoe goa Se SEess
S8o Bea 2-5 23% Se oF BBE PSE $28 eeate
ey = ge 29S 8S eB Fe@., Be SPee Ss a S
i $2 S26 228 a oO cet Pssao ia oS
* BRE 8 22 ge 252 5 obe gigigge ffer52 e285 8
S Bes ea 62938 = SSa-S82 ¢ So
= a te > Ee e@ a 5 & op 2. Qa o ‘.
Bog Sos og aa% g gf Eesede Bee? ee 28223
g&S gaged ee ee aS eee Zeosee Qeeeage Bo RES
a _ a5 a * ct
mee gg 2zs2 2 2on FLeses pees re eeagk
7 Ss = a oO as o oO oo a a
Pelee a 8 Fas & 262 a6 aaa a3 & E25 &
ope 8 ° 2@n6 S. 2s OSbe rs Bune oes
qage 3 ae ae. ge 6 e: 23. = 2 Sea B< 2» £64 @SBRop
debe dae Sese 2 828 geee28 egies BEES
wees Fs A Bibs oS 2 B B8B28S o¢s
Tie oS Shs WB ee BEB S&fEe
° & 2S eee 5 o =
rng = 3 ABS a
Sas § ee sae i
= ese
OSEBES
ggaseg
SFas é
a0 & 38
re Fg
g
Pe ey & 2
a é ae 4 > ~~
a e a e Boge Skee Zes
‘ & aa “ERSS BS BS Fs $85m Fae
SRS F4S5 oS Sa Bes Beers sss
fceSg e588 gE S72 S288 Ge Fa gi 2e2 See
eee esas ae ie aE give 2eeo ga S222 shi 238
oe s Xs ->o Zn e a oe og o so eso =° ae
TE TED rep gt See eae
= Ses oO ° S$ ¢ =f eB ooo 5 AE > o
Sees sgeh2 Go Se Se BSEE 2528 = UB Oe eee 2
g e 4 Qa = B28 Oe eB > ° oe asa2f 2s =
BESS 58s 8 SQaz SR p © Oka 5, BS ss Bas $s
3 See 2 5 eg 8 p = 1B Fa SS Bose Be se
BESS gee2ge3 ga practe prek g! 2e ae ees Bo
s 5 as & 9 SE [2 Gee a Boe 5 a2 > 2
S26 se oo S eS BES RE BS Bag SES ss Sse St eo
= BS FOS Oo 5 S25 AGS Sra Pe. a = ='S,
SReB FRO os Ba & se aP eB EeSe Se Qs g 2s ae
ofS B 2 § Os 23 84 z2e¢3 BERe 28 Ha 3 Bas
5s 5 a m 2p 9 Bog ee Boks & = a a &@oe Eo
g5 aebee* sa ee 28 a & 2 ag 52s a8 seg 63
2 2 Se ase sone 6. BESS & 8 Gin 2 < BES a Ope gs 5
ee B4e78s Se RES tEeg dete af ge as eee 2
TH ee ee gp 28 Fee gs
S 2a GE = Se Os rae eS £6 a a a & 3
3G QO $ & 6 & > Oe 875 og BRO ap pogo = eieras! so
S64 2 ¢ B ase Sho se os oa See 3
@56 2 SO Be %, 2 8¢8 8 8 g8eas § & at Spe ao
© £3e 25 Been: S 4 BO Pig 6 saan Bs S BF 32.2. & 5
Sas Cee a ae st Oot, @ Seas Bo &
BEZas. Ba@na oe. 8 oS sy Cutt 3B ¢g a9 @RS ©
Be S8 aa 8 S as 2559 28 3 gS S Se
BS a gags 3S g © OR et fee es = eG) ° gf. Bs @
Bato yg See 2. - Qe o ge vette Be é& og Bp 4
Spe bs i One 8 geo
ea as a 3° o: o Os £EaQo yg nS o 442 o ga
Boos B2fs g Bees £28 #28e Bs a 28 gag 22
aR e 2 & e¢ om o Be Ss
° = Sack z a 6 p ie ae ag 5 as a
"Foe gegh 5 #82 $2.8 G20 5 P gg ss B33 #8
ess ° ags8 ic} at = Pts bseiocsus g Bete Oo F Bo
S$8o8, $eae a $ 5 See S288 a S oc ye 8 ao
Eee 88 Se. 68 oe 8 Big Seaeacs: < By ee So 4
Be°S8 38258 g B go Sesg £ 3g
| Be oe RFR O & g io 86 OR ELS
Gn A Cat ae Ss a
SEEG pone ©
| =o BOGS
| goag
} ao < o
eae Oe
a8
Pee
(it

<!-- page 7 -->

-/
S ge
gPaee
a Pee5893
S “Bee cbageke
= gees 3 Boggs
S SNe o
| ; Nye
| S Ea
=e 258ae os zEaei Se UEliee
Ss Serer a Hy
a BEE ESeR: JEU gy
Elbe eH
S aT
Se a= & Be ee a & tO) = S823 oo
He RRR
Poly BELGE Leeerir! Ey
ea 8885 5 Bs 235 ees e EPC ELTELS aeaSEe 5
228 Boo | g 2825 Bice ca! ges es Pegee’
e286 ¢ a8 ae Zan s Eigeizil at = 2 egees:
UU et pEecei ls oaueta eas saigeds
a B 3S Pees ee =e ss 32 s.s
Ha are Pag
ipeediet £eae4 gage! Ee rete ah air
eu geebeei. 2EEEgs Bere ee
a 8 52s es BF EE p ae
aa oe ow BOS Ss a. pf oe FS p bg EeE =
man! a5 os per ieee Un Hen
ele § 8 gos Bs eae ees es 2E a Pee ee 55
ee raeeesee PEG
2S Bg ze se = Bee's BEES: 28 2: a
UGH LP TESe LE: peerit PEELE Es
aase g g BORE gee o a oe B88
3%8 pees: ae tT Sets: ey
ge Ee eeelaae sia ihe eit
reg per: e eas veeeeiae BeEao8
& ae bee2a os Bes sREEEES: BES 8
2 ooh beES] 2.6 a B28 y as
eg BE Bees on. aoa & oR s a
se LET: a2 PEbsesg
eg 8 ao, a
J ) 2 aes B53 2 Se
gee eee e a et BES,
B85 BSE° RSH Bee
B46 8s Pie & = 22m oP
pap geee bs: "BE Pa
ne. or a ge m: SS
irae g as
gag ee 23 3 =
Bg > 2 =
BEG 8 :
EES Bo 8
= FOr >
BS &
2 3728
ws ss = eee
; iga8 2052
a = 22288 geek
— peep
bp S >¢s ganeeie alee
5s SP
= B2¢ 2323 rau
Bas2 2s el irigas es
8 388 e23 Bos riehpee eta
= go 7 25 ao PEP TEEEa! zz
a PE SEeS Og Fy este
eS UD ree Zee PLB FUE,
7 ae ae ae & eg $28 cap kir i: Bye
CUTTS LTEeLloi ae 5 as
288 ee aceaee g 28 BE O% 2 eg
Hs =e 5 ereei'e: 5 5
+2 ee Bee sf ig o = 5389 Beso 3a8O8 =3
seee iri! ue a Be & 5255399 Sct
Fe AC s. ee edete tt Bos BE Sis are oe Ores
= eg sg BS ab £3 2% eesncs ae 8
ee sg Eon 2 & ae Be s 839 € Eley or ones é
Ee 3258 a > Be 5 eg gee 7a Qa 2
S338 eSaER © 23 35 S eae e Be 2s op ee a)
Sees S Tete 28s BE aE Bee zee
reba gagel Ee tHE Sg 2 =. 3 28 agi 3 585
e868 33. ge 229 BS 3 a%oO8 Gah ii tiers a2
cogs ele PERE a Sa g 52 peageee g, ¢
e256 mle = 5 S e828 Sbbgsie = elg
Taina o izes} Se ES B82 ig =
Egas g Bee 88 ams °c Q aS OS 5 = £ g
ease ciise FRE 0R5 g 98 TRUE 28 &
ae omar g 85 rE REELLE? S958
BEBO coe geGias 3 2e ¥ 23 peeceie sa8
zeus 86a aa & BS o 3 e Ba Ss ge
Sone "a8 & Seeee8 5 ERO. Sipe ca
‘4 faa Bs EeaS @
oSS8 gees REg es g Be aoe ES Fe8 &
2982 BESu Be Beg 8 2.2 g ees
23 & ae & oS. P. =. 3; a E
Ph 5 = Sg e. g » 2a ° a Bs ew
Soe Spans Oa Og B BS hy a ° o
ry e2¢8 Tes z ge AOR a ES aa a eae
m os8's 28 38 Ogee 5 BE > s One as
i Be. = & 3 2 & gFos
Geis EERE p02825 € 26 dees
ges Bree geea3! g cer
252 BES Bae me 2
fie sRES SEB Fe |
8226 E558, Qea om
aC ee ae 2322 ate 3 °
8s a =e p Fogo
a88 gga 2 gOgR 3
pease g Pg ea §
228 ae ook
BB 2 n °
| @ zee8é
| = Go 5
reCo_—_—_—_—_—_—_—_—_—_—_—_————

<!-- page 8 -->

ns a BS
be 3 ~ Ea
SS Ss 2
= Se &
| => a © 2 2>
| = S eo Rae og 2
| a lee ES) : Bisa Se gO >
er & gee gees 20 Seed2 2s
oS ag PEEP GBF EEE SEC S°o2Eer 25 3
sas zZ88¢ hs ge oe & 5 ta Re aS
| go SSR SEF FEF ER EE Baseees Pigi Tei ogaee Pes
| = Be oo = $ &. = ops oa ge yaa te = a
| eggs #48 = 3 Bsgexe Fs £288 2235 2 Fe Oessz 3
| 3 , be 8323 open a ae an88 Bees 33
| Es 3 5 oo Toe eee Eee. 5 D.
Pes se 838 3 2& GP > Go so 8 coe 5853 2.3
| & 5 B 388 249 Soe 22822832 Zee s S$ 82528 @s
esp 28 288 ¢ £ O25 3 me elu See Sak oS e.
<0 BBS co sk Bi Bgpeeae 3 22-3 28 a os 8 Bg
Bao 2 8 Seeae SS $B ofS Bae Be ee Rel ae 28
| Ro @ & EES § oes 8223 28 . 222889. Be 5
Boa F Bt ak ee 2.5 BRoe us ¢ aSoegds Sees. So
gee > 58 S ES. & Baer Bs @ e BES ach
goes Fangs peatieeer ghegEE SEE = ae
Sie Ses a ° RES gaa s. § serge
Sess geo ey e 2 R&2e nee #280 S08 8S ee &3
o Bes & Boo 5 6 aes os F 2 2% 2222 moe cs
< Bs 5 5 @eo, aos ep & ZSES6 sa
PES 5 S285 £880 of $f¢ad 35 Bo
= ° Fo Greases Boys Oeeeds BS So
Baie ae ® eee CF @ @e4ac see Spr2ege2 8 af ee
a8 2 BA eae eres 14 a@ps3 288 aig ese eg8Ss8 gS
& s 2 6 3 g es &S 6 = a B25 o 6.
eiig £828 8 gate Bea 2he Ge 85 pe2e5 ae
ma 3 g gs #33 5 5 S$ 8. or ade Be. Se <BR“ ere = a 3
N 2gz a g'¢ 2 € Bi = e Base
> a Bo gag qe & Be B.S
<. ° S 7; ° Lak a os oO =
2a 3 BaBe &. = sp 19) 52s Baers Boot oS 3 5 g oS
Sas "oe an 5 Sa 8 beer es fo Ps
reek fone 2 ieece o RC l ee Bo 852 2826 Ba
eee 2 ge 3 Bes eg OB Sek. ZPE Roe F282 bg
2 = So Bo 5 ¢-
38 ¢ ofan 2 Shes gags 38 ceeds kaeh ce
o 2" Bs a Sa 3} =< e a. ot g s
8 22 8 8 s.
Bee ye 2 give Pele eo8 22 322 88 gs2g eg
a er ae Sa ae 2 Soper A ert BPesheG Sie
& e 3 Pee Ss eof a
seee 8 ee Bo ge | Re: Be &8
ook & a 65 2 a Es go seu
Sx 8S 3. jee BOR Ss
8 ag $ y & 9%
wp B25
o 2 0 eS 6
ee é e232
o>
o rae
Roos
= eS 8
a = S gg —
nd = S & = an
= & =a 2 =
= = Sg SsSzTiaz eee eg
cS [ ae Gee 2352 88228
Ss as oe ge een 2 = 5
Bred 2528 529227535 a
SQReZA FE EES 2B 86 eS¢% eaee see ee
yE5 BSLESES zs gf a2 27 2228 25 Bg *S5 32
eg 207) THEGLa ae Ee 5 329295 8¢ Re gs
28 FEOss BEeES EX GE EES abso #8abe3 S fe 42
eR EELEE ESL aE GG eg" fF yess Sore ea 3s
oe gece sgesase a8 eo6 38s 8822 22 = See Ce
28 Boos: worege. 98 as a8 F-65523 45 2 = HE De
26 aTee se e¢gf8e 28 pe ‘@ 88 ecco Bo a es & tee ae
Se 92572 4282452 25 5% 60% g228 as = SE es
ge 9 2 S28 S eaie$ee 24 2g Parise e £28 28
° So. 5 FS = Gu & SG ma =a Bm Ss aoe gh @ a2 es
Boo Regus 2e,8785 8 Boe 2S Ba ee f 3 25 FS
So BEREB See BEG >3B = 2 8B yeSe 82 a oe on
Ge & aen = Bees a8 so @B 3 & 3.28 aoe
Be ESE OURS i 7: 22 S26. Ser Sue Regs ge 5 Be 28
22 Bess e553 Be § 32 Geoe mee | o 2a eS
zo gSe8 SeF8255 “ S 22 g BE SESE : ees
5850 Bes Boo 8e es 3 22 a gs & ge ee
mic Seo, ghee BOSS R ee & ge 5g Be Seoaeo fo 5s 28 &e
Es FIRS 28 e285 Bo eoe <8 same aoe oe! eee Bao 8 8
@ 8 Sage 2g 8o eka & Be 2 s ea08 Roe 3€ 22
o as go g : Boe ae 2 5 SERS
ee SB 2eO8s Oe eae § = a = - FE SB
o @ 2 Q a3 BS s ° Sas6 = Os 6
g8 PORE g2058R8 So Oe 85> ieee Bi 2 aE Bo
=e Eooooo Ge 8 &s3 = og 5 9 of a 2 BS ee |
gs S530 9825888 ote Boo, | Se ie BG Bg Be Sie S35
ae pegs ee ge 2: 5 a5 a2 2 eee: & 2 g3 3
Pa = = se <g 3 = B
| 5B? oe =. 2.8 fe. 8 = oe B = SOR S ¢. aX @
=3 eres ss Bese crops 2a gS Seabe 2
| oo PRS2 BBB OSHS Be. Peck Be ge $3 eB 2 Gerace ‘
| e e ee e as6 Ba a go a
| ae aaa a eEaRe 3 5s e i “Se
| ge BSS8 30un5 gs a of a B
6 & ees se2ee8 5 g oe
=e oro? 2esvEeedg
Se 8825 28
Ea

<!-- page 9 -->

= o
ES 3 a a 3
ee ; S sD
be —
= és sae CrREPPR>mMZanOoEs
EP PTETTP STS SEP ESSERE RERS SEE ST ESE ee CL
io 4 BO Bo Se! OSES Cae. pee . 5 8 eS e355 S
3° 39548 nR £28¢ OQ aoe engen = 2 ons P. Beaeea §
5 a £286 Bee Fass gs 8 Bee 8&
gees BO 2e oR o so Be Sa = p Sie 2 gE8 fe
Be aeeeh2 SRES bod FE, Resear geso ge koe ee
De SokOns ®@s2- Rn 8 Bgcassseceg es ag gee 3
gk e@egchh geeg oss 2oeeRebetebeee tae &
(2 S Oe Ss os S2gak es se = ¢ S| a
eG ipgsihGesss gg Seecebsetetetig ibe §
a = > y o =. a
oS SBS SS SEES BCR ESRFeeeekseRa Te ess 8B
est E2258 e¢38 Blof SAS Bec eSeetzeieckka BS 3
a oa Os. cas =e 2. is BR oe aie
Gedb2e5e gfe PSS EREETRGASS ees ks get &
2a Ssme Bp Sig a2 eee BRaetessassg £88 s
Be Seeks REE EES Secs kek Fal ears Fie 8
= oO BOSS Sp pHs 55 ¢ @EBSEaRPESCT TS ER LDS Bo 2
oS SATA 8° Bee oks Se Fess Sas ze Sage 3a8 &
§ 8eoea 8 ee al eres ene ORAS ss Za s 5
Ss ae ey = 70g 6 Sto & 6 6 & & 6 secre Sn Ss es 2
ae os 5 S saa f BS
53 >os 88s S pees f° a 2sgeeaqoS8 3 Bo S a a
S & B33 £ £Bo Seo pees s iO pias Bo
gS as. <8 5=8 arg Soe =
Bo BER RSE See k= eer @ 8 2 SS Be 8s a es 5
iS 5 ae Oop os oO 3 5 =z
o 2 goaaoas Ciena ~ goo o Ses Bao g Bz = |
Ss) SSERS Z evpes = Bes oCEe Geeta n {22 as Es |
Biueoe sg Bas $e CEGR ES Pees SSeES 28 g
= Pep se 2 ga So aS a6 ote a 2 5
<6 CE gs <5 Soe g Széc¢ Bese § Fee 5
g5 9 a &¢ £o ge FaaGe Ses ebe8 z
SE Ge GSS ao se FR Se. ogh Se aeeeebs g8 iB
SE BeSooe see 25 eaeSRCberge2e 8 Be a
Bq Pe Gis SS Ssiougs Sek RSS es toes ke sso oF SE
a6 =S@2538 once 2a B&SS588S65 62 a5 <.
s epeeaae
: SP > QF Bs feg828
On0 5 2& ga BaGdas< |
3 B28 8 Ss. |
Qa Ba Bo S2258S |
ere Bo 8 Sak
gac Be = > eee |
& = a ama BRO
EC 0e a ? eR Aas,
aa oO
= Be ia ae ae
Pare toh @ o.0. 4 SSBVoR OFFA BAA Ses Se
ZEFSAGL EZ SSSESS OF2SFOBZZSE SE
Ce28eeeds Baa tak 2,68 68s ¥B> Bg
a2 SSCSR8252 GLE ES Peas mee eB oe
BPsoRSERE SSRSes SB ne SRE S52 SB
SSGrraseg<rs aoe BESS SE8 F958 FS
a FR oobs paspe S=-es e052 ¢€3> =
Or Se BEG a eR a2 Bea72 228 =P 5 = as
SeeprGsgs SSFeag sear F82 088 >
: BSCPIasae FE8SS F828 S82a S88 2
SERLEESES SbRea S52 SSE 588 =
SRGee esse GERSR Rags £8 = 5
oe eae 8 F oR 58s a)
eee Rea Oss eeeG28eaF bas BEB 3
Brgogee S a eee Son  G
eGeezee s3eSe EFS, 22g
BS ERog aS shee ses fe Bee:
. _ Qa “age78 369 Sagas a om ee im
g a2aPp aS 25 s 3 ege se al =
. #2825608 5 S © B Eo 2 § °
$ co e288 SB. gels =e Bs 2 2
5 seer Rees SGeeR gF5 =n 2
5 BEoRBS Ok PaRRR ube BF sf §F
Bako RESSESRe FFoes FEF pe, FR 6
Sane SR 26 OFS = Eee p= 322 Es 32 S
B>pes eageSotSse 22855 53% os See) 4B
5 opposes e O 855 os oF a2 g a.
adds E2Ss588> 328638 BOS 6 83 &
| Coa a 8 Suda: a SBE BBOZs 23 5 8 =
EGS BESS R88 eee oes ase =e gS =
“¢28 PECh EAR epee So eo el Og 2 he fe 8
ioe! g@BeeRae seSeo Fs Baa” ABho. = ie
Pe eSnmsecersy Gehan So on S 3 =: |
6 yn he w pape |
= ego a8
g 2 e.3 ene
Fi = a2s 83
iz & = 5S Bios
‘i aes co
mS aon

<!-- page 10 -->

oe
sea pina pasate
Pee Ss. oe We a ie
eS a Ne Ce ead
obi aaa ea id RS B Meee fy fe ig yi Re
las gor ies gash ge fase? RP es ee Tt tbe eee
Oh et: See Sage a : eae Y @ yo ie gee fete? i
POO aS 4 gre ‘Saale, eae oR Sal sca
; Pein og 2 9 oe hth Swag UBepe
Beet a. man a4 7 ae ioe pte he es (need melita Ne
a hi oe 7h 1: AER ea ernst OS See od
a sm ont Be: " , ms we tg eae es be ea % 3
cen Se Be: Nee + a eS Bier
etre oy bes] ow Mages) tiga s ‘wey ROS Dvd, be: gr s omer |
Pes ace ‘ey a ir. 4 eat ri" ‘tog % + cnn = inti ¢
rr ose. Base ty Ns ras aoe + aA . Dh eg ey ry oF
he oy oe gt re eas oa Pt Ng, ian fa
% Cue: re “7 ” ae be eam > = we 0%
Bes abana bie i Aa
ae BEA Leh ilatas oe ee ea
re Bara > art he we ‘ Y Lis; a on Med " AA : a
* ie ee “SAS ‘ a oO t- : 3 a
bbe kp hia —— ns f te Rio ‘Vyas MA 7.4 akc eh eas
BEN Ao pie. Aang oh MAY AEE Shag t jet hae
RRS io LR pte sata Lite 5 eee
| hy st? oo. aa >. Ba his cae oo A ans
* sda FOPer ee. ins er a She eB rsh, aro ,
Rely ANG Pay mtv a tga atet- 2. oa & gy vg! are
edhe k eo Howe) SH Sat fee ae oe Rie Baal»
eee ee vs |S ABE a A a ears Yo
| prom : a emt i eX bite > afl F es
fee acti Pee ae. ie! Bune: RSE S|
“ ma eee See ies Pay kanal
ee) seein eS js Ck
ey a Loe ay ee ees &
~F ea ite ieee tt
Fi sie
