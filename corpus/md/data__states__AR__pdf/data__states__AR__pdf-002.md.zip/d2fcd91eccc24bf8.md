---
doc_id: "d2fcd91eccc24bf8"
source_url: "https://www.arunachalplan.gov.in/wp-content/uploads/2026/03/UD-Housing-Order-for-additional-allocation-of-Rs.-6189.67-lakh-during-CFY-2025-26.pdf"
ministry: "Finance-Planning & Investment Department, Arunachal Pradesh"
title: "ADDENDUM 1"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f0fda54406e7d3a4"
---

<!-- page 1 -->

D

's
o
*

ffi

H'
d

File No. PLNG-1 101 41 1 12025-Olo, DIR-SP-FPID-Part(39)

lv ory

(Comp. No.291359)
GOVERNMENT OF ARUNACHAL PRADESH
FINANCE, PLANNING & INVESTMENT DEPARTMENT
(PLANNING & INVESTMENT DIVISION)
A.P. CML SECRETARIAT:: ITANAGAR
Dated, the 6th March 2026.

ORDER
Approval is hereby accorded for an additional allocation of Rs. 6,189.67 lakh (Rupees sixtyone crore eighty-nine Iakh sixty-seven thousand only) to the Urban Development & Housing
Department for the implementation of 173 nos. projects/ works appended as Annexure-'A'during
the current financial year 2O25-26. The same will be regularized at the time of finalization of RE
2025-26.

2.

Utilization of fund is subject to adherence to the following:

a) This allocation is purely indicative in nature and this shall be utilized by the departments
only after veriflTing the actual requirement and observance of guidelines and all the
financial rules, regulations, provisions, prescribed in GFR, DFPR, etc. &
guidelines/circulars/ OM's/ directives issued by the CVC, MoF, MHA, Gol, Administrative
Ministries of Gol & GoAP from time to time in this regard in letter & spirit without fail.
b) The department shall incur expenditure only after the necessary allocation of fund and
budgeting in consultation with the Finance, Planning & lnvestment Department of the
Budget Division which will be regularised at the time of finalization of RE 2025-26.
c) The nodal department and the executing agency (wherever applicable) shall maintain

proper coordination and ensure that works are executed as per prescribed norms/
specifications.

d) The scheme should be completed as per the timeline so that there is no cost or time
overrun.

e) Fund should be utilizgd during current financial year for the purpose for which it is
allocated and cannot be diverted for any other purpose.

f) No revised estimate/ cost escalation and change of scheme will be allowed.

g) Department should ensure that there is no duplicity of the works with any other

schemes/ projects proposed/sanctioned by the State Govt./ Govt. of lndia. lf any
discrepancies is detected, the concerned department should immediately bring it to the
notice of Planning & lnvestment Department before commencement of execution of the
work. Diversion of fund to otherworks in such cases will not be permitted.
h) Concerned Commissioner/Secretary will monitor and review the progress of
implementation of the scheme/ project at regular intervals and shall ensure timely
submission of quarterly progress report, utilization certificate, photographs and
completion certificate etc. as applicable only after necessary review/ verification at their
level.

i) Violation of above instruction/guidelines will be the sole responsibility of the officers
concerned. Further, the amount only as actually required should be used and the
balance amount if any, should be surrendered.

3.

This is issued with the approval of the Competent Authority

(R.K. Sharma) IAS
Commissioner (Planning & lnvestment)
Page 1 of 2

<!-- page 2 -->

File No. PLNG-1 10141112025-Olo, DIR-SP-FPID-Part(39)

Memo No. PLNG-1 1O1411 12025-Olo, DIR-SP-FPID-Part(39)
Copy for information to:-

lutg

Dated, the 6th March2026.

1) The PPS to Hon'ble Chief Minister, GoAP, ltanagar.
2) The PS to Hon'ble Deputy Chief Minister, GoAP, ltanagar.
3) The US to the Chief Secretary, GoAP, ltanagar.
4) The SPA to Commissioner (Urban Affairs), GoAP, ltanagar
5) The SPA to Commissioner (Finance), GoAP, ltanagar.
6) The Chief Engineer (UD & Housing), GoAP, ltanagar.
7) The Under Secretary (BudgeUFinance- D), GoAP, ltanagar
B) The SRA (Budget), GoAP, ltanagar.

9) Office copy.

(R.K. Sharma) IAS
Commissioner (Planning & lnvestment)

Page 2 of 2

<!-- page 3 -->

March 2025

File No. PLNG-110141 U2025-o/ o,

ANNEXURE.'A'

*

Department: Urban Development & Housing

*
Fund allocated

District

Estimated Cost

2

3

4

Tawang

50.00

50.00

Papumpare

50.00

12.50

East Sianq
Papumpare

50.00
s0.00

12.50
12.50

West Kameng

20.00

5.00

b

Approach Road from Air Gompa road to Safai Karam chari
Colony (SH: WBM, CC site drain, Cross drain, CC Pavement and
Protection work)
C/o retaining and protection wall at Didwer Dokum village Lekhi,
Naharlaqun
Cio aooroach road from Main road to Peiab area, Pasighat.
C/o Compound wall and Culvert at Botanical Survey of lndia
Office. ltanaoar
C/o Protection wall for staff quarter at Govt. College Bomdila
campus. District West Kamenq
C/o colony Road protection wall at Chimpu, ltanagar

Papumpare

20.00

5.00

7

C/o Protection wall at Pangia Ziro Lower Subansiri District

Lower Subansiri

20.00

5.00

8

C/o boundary wall around CO office, Namphai, Miao Sub Division

Changlang

50.00

12.50

9

C/o bridge across Chugh river to Connect Nisthang village and
Khardung Village (Span-35 mtr) Ph-ll under Dirang Circle.

West Kameng

269.32

67.33

10

C/o RCC protection wall along Meyong river at Chugh under

West Kameng

100.00

25.00

Papumpare

50.00

12 50

Papumpare

100 00

25.00

East Kamenq
East Kameng

30.00
40.00

'10 00

East Kameng

25.00

6.25

East Kameng

25.00

6.25

East Kameng

20 00

500

East Kameng

20.00

5.00

East Kameng

25.00

6.25

Changlang

50.00

12.50

Papumpare

100.00

25.00

Lower Subansiri

100 00

25.00

Shi-Yomi

50.00

12.50

Shi-Yomi
Papumpare

50.00
45.00

12.50
11.25

Papumpare

45.00

11.25

Papumpare

50 00

12 50

Paoumoare
Lower Subansiri

50 00
25 00

12.50

Papumpare

25 00

6.25

East Siang

25 00

6.25

Changlang

25.00

6.25

East Siang

46.OO'

11 .50

East Siang

1,000.00

100 00

Name of Scheme

Sl. No.
1
1

2
a

4
A

durins 2025-26
5

Dirano
11

12

13
14
15
16
17
18
19

C/o CC pavement approach from Colony road road to Niakum
Colonv at Yuoia. Paoum Pare District
C/o approach road from Bridge point Tegdo Riang Pachin to
Nvokum Ground Pachin Teodo. Paoum Pare District.
C/o Retainq wall at Wessanq, East Kamenq District.
C/o approach road from main road to Narang Yaar New Seppa,
East Kamenq District.
C/o RR wall at Doriputung near New Seppa Colony, East
Kamenq District.
C/o Drainage system at Pacha Morang Colony Seppa, East
Kamenq District.
C/o Drainage system at Ty-ll colony near Jio Office, Seppa, East
Kamenq District.
C/o Protection wall at Ashoka Colony Gayo, Seppa, East
Kamenq District
C/o drainage system at Lori Colony New Seppa, East Kameng

7.50

District.
20
21

22
23
24
25

C/o Boundary wall at Shanti Sukh Maha Vihara Cultural Centre at
Old Champu, Miao, Chanqlanq District.
C/o Protection wall at A-Sector Naharlagun, Papum Pare District
C/o approach road from main road to Pare Ami, Hapoli, Lower
Subansiri District.
Land development and protection work at Govt. Accomodation
for staffs at Tato in Shi-Yomi District.
Protection work at Kamo Tato in Shi-Yomi District.
C/o Protection wall at Kongte Chimpu ltanagar nera PMGSY
road.

zo
27
28
29
30
31

32
33
34

C/o CC pavement road and drainage work from colony road to
Konqte Chimpu, ltanaqar.
C/o protection wall at Chehaso Nallah, Balizan Circle,
PapumPare District
C/o Retaininq wall at Domi Nallah Tiqdo-l Doimukh.
C/o CC Drain at Riitubo, Ziro.
C/o of 6 Mtr Span of Culve( Near Govt. middle School Tigdo,
Doimukh
C/o Protection wall at Sibo Korong, near College Campus,
Pasiqhat, East Sianq District
C/o approach road from Setong Sena Outdoor Stadium to Govt
rHr Sec School Jairamour. Chanqtanq District.
Cio RCC Drainage, RCC retaining wall and Culvert at Upper
Colonv Aalo
C/o Parkinq Lotfor District Zonal

fu

Page 1 of 5

6.25

<!-- page 4 -->

D
File No. PLNG-11O14/7/2025-0lo, DIR-SP-FPID-Part(39)/4859 dated 6th March 2026

G
in

rund alfeca&k

Sl. No.

Name of Scheme

District

Estimated Cost

1

2

3

4

35

C/o Multipurpose Car Parking (G+3), Seppa, East Kameng
District
C/o Storm Water drainage at newly settlement Dang Namlo
Colonv Wessanq. East Kamenq District
C/o Drainage system around April Blossom foundation School at
Lekhi. Paoum Pare District
C/o lntegrated Development work at Upper Jullang-ll, ltanagar

East Kameng

1,500.00

100.00

East Kameng

35.00

8.75

Papumpare

20.00

5.00

Papumpare

100 00

25.00

Papumpare
Paoumpare
Paoumpare
Papumpare

100.00
50.00
50.00
50.00

25.00
12.50

42

C/o Protection wall & CC Drain at Lower Chimpu, ltanagar.
C/o CC Drain & RCC wall at C-Sector, ltanaqar
C/o Cascadinq and protection works at Hollongi
Cio Approach road, wall & Drainage at Nyorch, Papum Pare,

43

C/o Approach road for colony & Sand Quarry & MIB Channel at

Papumpare

50.00

12.50

Upper Subansirr

50.00

12.50

Upper Subansiri

50.00

12.50

Upper Subansiri

50.00

12.50

Upper Subansiri

50.00

12.50

Upper Subansiri

50.00

12.50

Upper Subansiri

50.00

12.50

C/o Clearance and Maintenance of drainage system at Dumporijo Upper Subansiri
Town.
C/o Retaining wall at Yomdo colony, Medical road under
Upper Subansiri
Dumooriio Township. Upper Subansiri District.
C/o Protection wall at Nehru colony under Dumporijo Township,
Upper Subansiri
Uooer Subansiri
C/o Retaininq wall and wideninq at rotte villaoe
Lower Sianq
C/o Drain at BSNL tower colonv at Miao (Lower).
Chanqlanq
C/o drain at Miao Opposite Central Water Commission
Chanqlanq
C/o Retaining wall to protect Sandal wood plantation, Miao
Chanqlanq
C/o approach road from colony road to Tonglu residential area at
Changlang
Miao Sinqpho villaqe.
C/o Gabion structure at Jairampur in Changlanq District.
Chanqlanq
C/o Retaining wall at Manmao to protect residential area in
Changlang
Chanqlanq District.
C/o internal road at Kamlao under Manmao Circle , Changlang
Changlang
District
C/O Retaining Wall at Heegang area near Medical colony,
Longding
Lonqdinq Townshio. Lonqdinq District
C/o Approach road with culvert at Residential colony at Nirjuli
Papumpare

50.00

12.50

20.00

5.00

30.00

7.50

20 00
20 00
20.00
25.00
10.00

5.00
5.00
5.00
6.25
2.50

50.00
50 00

12.50
12.50

50.00

12.50

20.00

5.00

100.00

25.00

Papumpare

150.00

37.50

Papumpare

250.00

62.50

36
37
38
39

40
41

45

Dipra. ltanaoar.
Cleaning & Maintenance work of Drainage at Daporijo, Upper
Subansiri Dist.
Procurement of Santitation ltems under Daporijo UD Division

46

C/o Drainage system at F&ES Sector, Daporijo, Upper Subansiri

44

durinq 202S40
5

12.50
12.50

District.

47
48

49
50
51

52
53
54
55
56
57
58
59
60
61

62

bJ
64

C/o Maintenance of residential building of UD Staff Quarters at
Dumooriio.
C/o Repair and renovation of Working Women's Hostel at
Dumooriio.
C/o Procurement of Sanitary items for Dumporijo Town.

C/o Approach road from Arunodaya University Tr-Junction Upper
Jullano to Domi-Dote villaoe in middle Jullano
C/o CC Pavement road cum Protection wall District Papum
Pare.

65

Repairs & Renovation of Arunachal Pradesh lndustrial
Development and Financial corporation Limited (APIDFC Ltd)

Papumpare

150.00

37.50

66

C/o RCC at below Driver Colony Niti Vihar Near lG park Nallah

Papumpare

150.00

37.50

67

C/o Extension & Maintenance of general ground at Ni-Longnu-Pa
colony, Lohqdinq Dist.
C/o Protection wall at Bebo colonv near GHS School Seppa
C/o Retaining/Protection wall at Sangrik Hapa road to Artisan
colonv under Chimpu, ltanaqar
Cio Land Protection work at Upper Dokum Colony ltanaqar
C/o Protection work at approach road to Old Forest Office
Opposite to Main Gate of A.P. Civil Secretariat
C/o RCC Protection wall near Akash Bagang Church Nallah
Abotani villaoe. Karsinosa.

Longding

50,00

12,50

East Kamenq
Papumpare

40 00
50 00

10.00
12.50

Papumpare
Papumpare

50 00
50.00

12.50

Papumpare

100 00

25.00

68
69
70
71

72

Page 2 of 5

12 50

-

)k

<!-- page 5 -->

File No. PLNG-11O74/U2O25-O/o, DIR-5P-FPID-Part(39)/4859 dated 5th March 2026

g

I

(L

l

,*
Name of Scheme

Sl. No.

District

Estimated Cost
4

Fund alldpated

durinq 2028.26
5

1

2

3

73

C/o RCC Retaining Wall at Sangri Colony Sagalee Opp. Former
CM Banqlow
CC pavement at Limmi Pakke Kessang District

Papumpare

20.00

5.00

Pakke Kessang

15.00

3.75

Papum Pare

50 00

50.00

Papum Pare

50 00

50.00

Leparada
Leparada
Leparada

30.00
40.00
30.00

30.00
40.00
30.00

Leparada
Tirap
Papum Pare

15 00

15.00

50.00
50.00

50.00
50.00

Papum Pare

50.00

50 00

Papum Pare
Papum Pare

25.00
50.00

25.00
50 00

Papum Pare
Papum Pare
Papum Pare

35.00
30.00
50.00

35.00
30.00
50.00

Papumpare

100 00

25.00

Papumpare

100.00

25.00

Papumpare
Papumpare

100.00
100.00

25.00
25.00

Papumpare
Papumpare

100.00
100.00

25.00
25.00

Chanqlanq
Chanolano
East Sianq
East Siang

200.00
200.00
50.00
50.00

50 00
50.00
1 2.50

East Siano
East Sianq
Papumpare
Papumpare
Papumpare

50 00
50.00
50.00
50.00
50.00

12.50
12.50
12.50
12.50
12.50

Paoumoare
Papumpare

35.00
35.00
20 00

8.75
8.75
5.00

Chanqlanq
East Siang

25.00
20.00

6.25
5.00

East Siang

20.00

5.00

Tirap

50.00

12 50

Tirap

10.00

250

74

86
87
88

Construction of cc footpath at cooperative colony,C Sector
Itanaoar
Construction of Retaining wall Back Side of Treasury office to
coooerative colonv C Sector ltanaqar
C/o CC Drain from PWD Garaqe to Hire at Basar
C/o Retaininq wall near fire Briqade Basar
C/o RCC protection wall near sie Bridge at the back side of TM
commercial buildinq at Basar
C/o Land protection at Soi villaqe
Special maintenance of UD Guest House at Khonsa
C/o RCC Protection Wall & Drainage at Tigdo, Naharlagun (Ht.
4m. Lenqth 80 m)
C/o, Retaining Wall (15 Mtr Length, 10 Mtr Height & 16 lnch
Width) at Niva Colonv Near Botanical Garden. ltanaoar
C/o. Retaininq with Drainaqe at Lekhi Villaoe, Tani Colonv
C/o. Retaining Wall (15 Mtr Length, 10 Mtr Height & 16 lnch
Width) at Division-lV. Near PWD Office. ltanaoar
C/o. Protection Wall atAbotani, F-Sector, ltanaqar
C/o. Anti Soil Erosion Wall at Taqo, Ganga, ltanaqar
C/o RCC retaining wall opposite Legi wine factory, Papunalah

89

C/o Anti Soil Erosion structures at injully Colony, Chimpu,

75

to
77
78
79
80
81

82
83
84
85

90
91

92
o2
94
95
96
97
98
99
100
101

102
103

104
105
106
107
108
109
110
111

Itanaoar
C/o RCC Culvert 6 Mtr. Span along with other
development activities at Chimou. ltanaqar
C/o RCC Retaininq Wall at Lower Chimpu, ltanaqar
C/o Anti Soil Erosion work at Hochang Nallah, Damsite,
Naharlaqun
C/o Protection Wall at Jullanq, ltanaqar
C/o Storm water Drain and CC Pavement at Chimpu, ltanagar
C/o Approach road from NH to Sports Academy, Miao
Master Draianqe towrads Neoton to Kailee Pathar. Miao.

C/o Parking Place and Boundary wall at UD office, Pasiqhat
C/o lnterlocking paver block road from NH 513 to
smart city road near WRD Office, Pasiqhat
C/o Link road at Gobo area Rani,Pasiqhat.
C/o Approach road culvert afSirbor area, Ruksin
Repairing of UD Quarters under Capital Comolex
C/o retaining wall near GN Colony at Chimpu, ltanagar
C/o Soil protection work near Trinity Church, Jullang, ltanagar
C/o RCC protectioqwall near A.O Apartment
C/o Protection wall at Senki View near Botanical office
Cio Retaining Wall at Government Quarter No.75, Type-ll, H
sector, ltanaqar
C/o Retaininq Wall, Opoosite Satasanq Vihar. Jairamour
C/o CC Pavement from T-Junction Near Food & Civil Supply
Godown to Smartcity Road, Pasiqhat
C/o Chain Link Net Fencing and Hut at Komlighat Cafeteria,
Pasighat East Siang District
L.P work below Kidzy School in Tirap District, Khonsa.
Land Development at Bank colony and Veterinary Office at

12.50

Khonsa.

112

Approach road at Multipurpose Hall Borduria.

Tirap

50 00

12.50

113

Tirap

10.00

10 00

114

C/o Retaining wall near School colony and Church colony at
Borduria.
C/o Playground drain at Huallam village.

Tirap

20.00

500

'115

C/o Well come gate at Kaimai in Tirap District.

Tirap

20 00

5.00

Page 3 of 5

<!-- page 6 -->

File No. PLNG-11O7a/!2O25-O/o, DIR-sP-FPID-Part(39)/4859 dated 6th March 2025

Name of Scheme

Sl. No.

District

Estimated Cost
4

Fund allotatet

durinc 2o)E/.26

,|

2

3

116

C/o Protection wall at Upper Type-V colony near PHED Godown,
Khonsa. Tirao District.
C/o Chain-link fencing of Waste Management Disposal site,
Tawanq
C/o CC Pavement and CC drain with protection wall at Wessang
near Kamenq Presidium school, Seppa
C/o CC road from Kidzee School Gate Forest Colony,
Chandranaqar to residential area (Approx. 200 mtrs)
Const. of protection wall and drainage at BPL colony, Jully,

Tirap

30.00

7.50

Tawang

25.00

6.25

East Kameng

100.00

25.00

Papumpare

100.00

25.00

Papumpare

150.00

37 50

117
118
119

120

5

Itanaoar.
121
122

C/o Retaininq wall at Abotani Colony, ltanagar,
C/o Retaining wall near NBF Barrack Khonsa, Tirap District, AP

Papumpare
Tirap

150.00
60.00

37.50
15.00

123

C/o CC road from DP School Junction to Lower Khamsu-Copfa
colonv Nisa.
C/o Earth Protection worka at BRTF road Kapkau colony
Mannoam turnino Point. Nisa
C/o Drainage from Main Tank to Achop Thamsa Nallah, Nisa
Lonqdinq
C/o Approach road at Lupong Orchard, Bomeng area under East
Sianq District. Pasiqhat.
C/o link road from main road to Govt. Middle School Colony at
Old Laptano villaqe. Tirap District
C/o Retaining wall at Borduria near Hangpan Dada Memorial,
Tirao Diskict.
C/o Protection Wall near Forest Check Gate, Bomdila
C/o Type-ll, 2 Nos. Qtr with boundary wall at New Light
Foundation Rehab Centre at Old Tupi, Tirap District.
Construction of approach road at 17th Mile Jairampur.
C/o Approach Road with Seven meter Bridge for ongoing lTl site
Basar, Leparada.
C/o Protection wall at ongoing lTl site Basar, Leparada District.

Longding

50.00

12.50

Longding

800

8.00

Longding

5.00

5.00

East Siang

100.00

2s.00

Tirap

100.00

25.00

Tirap

90.00

22 50

West Sianq

49.21

Tirap

105.56

12.30
26.39

Chanolano
Laparada

50.00
100 00

12.50
25 00

Laparada

50.00

12.50

Laparada
East Siang

50.00
30.00

12.50

East Siang

200 00

50.00

Paoumoare
Longding

200.00
100.00

200.00
25.00

C/o Storm Water Drainaqe svstem in Lonqdino Market Area
C/O Community Hall at Thow Happa in Pitapool Under Keyi
Panyor District.
Maintenance & Renovation of Drain at Kok Arik, Mongku near
Residence of Bharat Moyonq, Pasiqhat
C/o Drain near Green Park, Pasiohat Bazar area. Pasiqhat
Construction of Community hall at Tirung village, Tirap District.

Lonqdinq
Keyi Panyor

100.00
30 00

25.00
7.50

East Siang

20 00

5.00

East Siano
Tirap

20.00
50.00

s.00
12.50

C/o Approach from Daria Hill road to Tello Putunq, ltanaoar

Papaumpare
Paoaumoare
Paoaumoare
Papaumpare

50.00
50 00
50.00
50.00

12.50

C/o Storm water drain with protection work near TT Commercial
Holonoi. ltanaoar.
C/o Soil stabilization work near GN Complex, Chimpu, ltanagar

Papaumpare

50.00

12.50

Papaumpare

50.00

12.50

C/o Protection work at Amanq, Richi-Jullanq, ltanaqar.
C/o CC Drain and retaining wall at Gandhi village under Boleng
circle, Sianq Dist.
Development of lnfrastructure for Sub-Post Office at Boleng
circle, Sianq District.
C/o Approach line road from Rabung Korong to Paddy field at
Boleno. Sianq Dist.
C/o Protection wall at SSB colony Bolenq under Sianq Dist.
Renovation of Division Office, UD&H, Pasighat Under East Siang

Papaumpare
Siang

50.00
40.00

12.50
10.00

Siang

40.00

10.00

Siang

30.00

750

Sianq
East Siang

30.00
20.00

7.50
5.00

124

125
126
127

128
129
130
131
132
133

134
135
136
137
'138

139

140
141
142

143
144
145
146
147

C/o CC Drain at ongoing lTl site Basar, Leparada District
C/o CC Drain at High Region area near Hr. Sec. School
Pasiqhat.
C/o RLR with Box Culvert at Gomsi Archaeological Site at Rani
villaqe. East Sianq District.
Const. of RCC Retaininq Wall at 6th Mile. ltanaqar
Renovation & Maintenance of Shopping Complex at Longding

C/o Protection work at Nianolum. Chimou. ltanaoar.
C/o Protection work at BD-Gomi Nallah. Jullano. ltanaqar
C/o lntegrated Development work at GG Complex, Chimpu,

7.50

12 50

12.50
12.50

Itanaqar.

148
149
150
151

152
153

154
155

District.

Page 4 of 5

*

<!-- page 7 -->

File No. PLNG-1101417/2O25-O/o, DIR-SP-FPID-Part(39)/4859 dated 6th March 2026

*
Sl. No
1

156
157
158
159
160
161

Name of Scheme

District

Estimated Cost

Furtlitlo\teo
ourinl$dd-lb

2

3

4

5

30.00

7.50

35.00
20.00

8.75
s.00

280 80

140.40

50.00

25.00

50.00

25.00

PaDumoare
Papumpare

100.00
100.00

50.00
50.00

Papumpare
Papumpare

50.00
50.00

25.00
25.00

Papumpare

50.00

25.00

Papumpare

50.00

25.00

Leparada
Leparada
Lower Sianq
Lower Siang

10.00

5.00

30 00
100 00

15.00

100.00

50.00
50 00

Papumpare

250.00

125.00

2,500.00
15,203.89

2,500.00
6.189.67

East Siang
C/o Boulder Bund to protect soil erosion at Tajum Korong, 5th
Mile Pasiohat under East Sianq District.
C/o protection Wall at Gate Colony, Nafra
East Siang
Maintenance and water Connection work at Raneghat, Pasighat
East Sianq District
Multi-Storied Parking Lot Buidling at Daporijo, upper Subansiri, Upper Subansiri
Arunachal Pradesh
Papumpare
C/o Anti Soil Erosion and amelioration works near sesa river,
Hollonoi. Paoum Pare. Arunachal
Papumpare
C/o Land Protection Wall at Doni Polo Colony at ltanagar, Papum
Pare

162
163

C/o Storm Water Drainaqe at Jullanq at ltanaqar
C/o RCC Retaining Wall near Sanggey Laden ltanagar, Papum
Pare

171

Cio anti Soil erosion works near Zoo at ltanaqar
Constructio of drain, widening of Road & Protection work at Ddector. ltanaqar
Construction of RRM and storm water drain at Upper Hollongi,
Itanaqar
Construction RCC Wall along Chimpu river at Chimpu 3 opposite
SE WRD. ltanaoar
C/o protection wall at Gori-Soi Tinali , Basar
C/o CC pavement and CC drain at Dali. Dari Circle.
C/o protection wall at Liou. Lower Sianq District,
C/o protection wall near Check Post, Likabali, Lower Siang

172

Approach road land protection work and land amelioration works

164
165

't66
167
168
169

170

District.

at New Min Putung colony at Mogli, Papumpare ltanagar.
173

Maintenance of Assets in Various divison of UD department.

HQ

Total

Page 5 of 5
