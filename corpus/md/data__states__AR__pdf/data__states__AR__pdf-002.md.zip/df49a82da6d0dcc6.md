---
doc_id: "df49a82da6d0dcc6"
source_url: "https://www.arunachalplan.gov.in/wp-content/uploads/2026/03/Skill-Development-Entrepreneurship-Order-for-Additional-Allocation-of-Rs.-75.00-Lakh-during-CFY-2025-26.pdf"
ministry: "Finance-Planning & Investment Department, Arunachal Pradesh"
title: "ADDENDUM 1"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "263e6fcc35424520"
---

<!-- page 1 -->

Ygkr

File No. PLNG-1 I Ol 4 11 t2025-Olo, DIR'SP-FPID-Part(39)
(Comp. No.291359)
ENT OF ARUNACHAL PRADESH

PLANNING & INVESTMENT DEPARTMENT
(PLANN rNG & INVESTMENT DIVISION)
A.P. CIVIL SECRETARIAT: : ITANAGAR
Dated, the 6th March 2026.
ORDER

Approval is hereby accorded for an additional allocation of Rs. 75'00 Iakh (Rupees sevenfive lakh only) to the Skill Development & Entrepreneurship Department for the implementation of
the following schemes/works during the current financial year 2025-26:
(Rs. in lakh)

sl.

Name of Scheme

No.

2

3

Establishment of fullY equ ipped vocational
training centre at Yokmuzur, West Kameng
District
Total

West

1
1

District

Estimated
Cost
4
250.00

Fund
allocated
during
2025-26
5

75.00

Kameng

2.

The same will be regularized at the time of finalization of RE 2025-26.

3.

Utilization of fund is subject to adherence to the following:

250.00

75.00

by the departments
a) This allocation is purely indicative in nature and this shall be utilized
all the
guidelines_and
of
observance
and
requirement
actual
tn6
only after verifying
-regulations,
etc'
&
DFPR,
GFR,
prescribed
in
piovisions,
finjncial rules,

guidelines/circuiars/ 6U'sl directives issued by the CVC, MoF, MHA, Gol, Administrative
[/inistri"s of Gol & GoAP from time to time in this regard in letter & spirit without fail.
after the necessary allocation of fund and
b) The department shall incur expenditure only planning
& lnvestment Department of the
budgeting in consultation with the Finance,
Bud-get D-ivision which will be regularised at the time of finalization of RE 2025-26department and the executing agency (wherever applicable) shall maintain
The-nodal
c)

proper coordination and ensure that worki are executed as per prescribed norms/
specifications.
d) fhe scheme should be completed as per the timeline so that there is no cost or time
overrun.
e) Fund should be utilized during current financial year for the purpose for which it is
allocated and cannot be diverted for any other purpose'
and change of scheme will be allowed.
0 No revised estimate/ cost escalation
works with any other
Sil Department should ensure that there is no duplicity of the Govt.
of lndia. lf any
Govt./
State
the
schemes/ projects proposed/sanctioned by
bring it to the
immediately
should
department
discrepancies-is detected, the concerned
of the
execution
of
commencement
before
Department
notice of Planning & lnvestment
permitted.
not
be
will
cases
such
in
works
work. Diversion oi fund to other
h) Concerned Commissioner/Secretary will monitor. and review the progress of
implementation of the scheme/ project at regular intervals and shall ensure timely
submission of quarterly progress report, utilization certificate, photographs and
completion certificate eti. as afplicable only after necessary review/ verification at their
level.
Page 1 of 2

<!-- page 2 -->

File No. PLNG-1'l 01 4l'l t2025-Olo, DIR'SP-FPID-Part(39)
Oer

n-

/ru,

above instruction/guidelines will be the sole responsibility of the officers
Further, the amo-unt only as actually required should be used and the
unt if any, should be surrendered.

4.

This is issued with the approval of the Competent AuthoritY.
(R.K. Sharma) IAS
Commissioner(Planning & lnvestment)

Memo No. PLNG-11014/1/2025-O/o, DIR-SP-FPID-Part(39)
Copy for information to:-

Dated, the 6s March 2026.

1) The PPS to Hon'ble Chief Minister, GoAP, ltanagar'

Zi fne pS to Hon'ble Deputy Chief Minister, GoAP, ltanagar'
3) The US to the Chief Secretary, GoAP, ltanqS?r
4) The SPA to Commissioner (Finance), GoAP, ltanagarSj tfre en to Secretary (Skill Development & E), GoAP, ltanagar
6) The Director (Skill Development & E), GoAP, ltanagar'

7i The Under Secretary (BudgeUFinance- D), GoAP, ltanagar'
8) The SRA (Budget), GoAP, ltanagar.
9) Office coPy.

Page 2 oI 2
