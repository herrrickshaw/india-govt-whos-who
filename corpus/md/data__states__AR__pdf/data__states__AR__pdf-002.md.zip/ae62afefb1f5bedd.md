---
doc_id: "ae62afefb1f5bedd"
source_url: "https://apssb.nic.in/upload/files/RECINS001/ldce_2025_corrigendum_20250319_134310.pdf"
ministry: "Arunachal Pradesh Staff Selection Board"
title: "Download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0c1b77bfbe2dcc02"
---

<!-- page 1 -->

radesh

Staf &

Selc

aionBoa

GOVERNMENT OF ARUNACHAL PRADESH

ARUNACHAL PRADESH STAFF SELECTION BOARD
ITANAGAR

Dated 19-03-2025

Na.APSSB-13/4/2025//SR
Itanag
CORRIGENDUM

In continuation to our Advertisement No.01/25 dated O6/03/2 025, this
is to inform that consequent upon the receipt of intimation from Department
of Legal Metrology and Consumer Affairs vide letter No.CLMCA
12023/10/2022/741 dated 07/03/2025, stating that there was error by the
Department while submitting online requisition, the following vacancies under
Post Code 1/25 are beingwithdrawn:
Vacancies

SI.No.

Name of the Post

01.

Lower Division Clerk(LDC)

APST

UR

Total

03

01

04

Consequently, the vacancies against Lower Division Clerk(LDC) of

the department of legal Metrology &Consumer Affairs may be treated as NIL.
Sd/

(Krishna Kr. Singh), IAS

Secretary cum CoE, APSS8
Memo no.APSSB-13/4/2025
Copy to:

Dated Itanagar the19th March'2025

1. The Chairperson, APSSBfor information please.
2. The Members, APSSB for information please.
3. The Controller, Deptt.of Legal Metrology and CA for information
please.
4. Office copy.

Digitally signed by

Priscilla Tayeng
Date: 19-03-2025 13:01:25

(Priscilla Tayeng), APCS
Deputy Secretary, APSSB
