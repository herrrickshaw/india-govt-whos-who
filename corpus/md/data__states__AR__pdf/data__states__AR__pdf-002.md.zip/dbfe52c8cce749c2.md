---
doc_id: "dbfe52c8cce749c2"
source_url: "https://apeda.nic.in/docs/SPV-BENEFICIARY-LIST.pdf"
ministry: "Arunachal Pradesh Energy Development Agency (APEDA)"
title: "LIST OF VILLAGES ILLUMINATED THROUGH SPV SYSTEMS UNDER PM PACKAGE IN BORDER CIRCLES OF ARUNACHAL PRADESH"
date: ""
pages: 156
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "47012e2580684608"
---

<!-- page 1 -->

ASTRACT THE 523 VILLAGES ILLUMINATED THROUGH SOLAR
HOME LIGHT SYSTEMS UNDER PM PACKAGE IN ARUNACHAL
PRADESH
Sl.
No.

Name of District

No. of Villages
Illuminated

Population

No. of
Households

1

Tawang

4

114

38

2

West Kameng

11

650

155

3

East Kameng

77

4939

1094

4

Kurung-Kumey

78

4065

941

5

Upper Subansiri

61

3083

696

6

West Siang

29

2009

440

7

Upper Siang

9

542

112

8

Dibang Valley

52

1231

277

9

Anjaw

197

8871

1930

10

Changlang

5

694

169

Total

523

26198

5852

<!-- page 2 -->

BORDER VILLAGE ILLUMINATION PROGRAMME THROUGH SOLAR HOME LIGHT
SYSTEMS UNDER PM PACKAGE
IN ARUNACHAL PRADESH
BENEFICIARY LIST OF TAWANG DISTRICT
Name of Village: Thanglang Ami Gonpa (Total Beneficiary : 9 Nos.)
Sl.
No.

Name of the Beneficiary

Module No.

1
2
3
4
5
6
7
8

Norbu Zangmu
Changpa Drema
Tsering Chomu
Ngawang Zangmu
Dorjee Yangzom
Drema Kesang
Main Gonpa Building
Committee & Prayer
Building

9

Gonpa Kitchen Room
10643
AR 013894
Name of Village : Khirmey (Total Beneficiary : 3 Nos.)

188

10
11
12

Mrs. Gom Drema
10769
AR 014727
Mr. Karma Tenzin
11452
AR 015650
Shalapa
11448
AR 015645
Name of Village : Jermang Ami Gonpa (Total Beneficiary : 8Nos.)

184
185
186

13
14
15
16
17
18
19
20

Main Ami Gonpa
10593
AR 015593
Tsengpa Tashi
11016
AR 015807
Ami Pema Chhoten
10918
AR 015363
Ami Ngawang Chhoten
10661
BR 016058
Ami Thiley Wangmu
10547
BR 015987
Ami Dorjee Yangzem
10705
BR 015963
Ami Dorjee Lhamu
10645
AR 015756
Ami Ten Yamchin
10719
AR 015774
Name of Village : Phonghar (Total Beneficiary : 18Nos.)

176
177
178
179
180
181
182
183

21
22
23
24
25
26
27
28
29
30

Dorjee Norbu
Tharchin
Pen Norbu
Ngawang Phuntso
Tsering Norbu
Pen Dorjee
Yeshi Gonbu
Song Dorjee
Leki Dorjee
Tsedar

793
793A
793B
794
794A
794B
160
160A
160B
158

Hall

11210
11068
11405
10686
11399
11396
11084
11451

10916
10781
10881
10555
10855
11439
10546
10764
10590
11436

Battery No.

Beneficiary
Certificate Sl. No.

AR 015390
BR 016002
BR 015972
BR 016017
AR 015791
AR 015847
AR 015660
AR 013911

AR 015652
AR 015878
AR 015636
AR 015649
AR 015372
AR 015827
AR 015757
BR 016051
AR 015894
AR 015898

168
169
171
172
173
174
175
187

<!-- page 3 -->

Kesang Dawa
Charten Dorjee
Dawa Tsanu
Ngopo
Dolezom
Bremu
Kancho
Gonpa Type Community Hall

31
32
33
34
35
36
37
38

11440
11967
11215
11293
11773
11150
10582
10556

BR 015929
AR 015630
BR 015914
AR 015775
BR 015925
AR 013848
BR 015914
AR 015821

158A
158B
159
159A
159B
157
157A
157B

BENEFICIARY LIST OF BOMDILA, WEST KAMENG DISTRICT
Name of Village : SITU Circle:- Sinchung (Total Beneficiary : 12 Nos.)
Sl. No.

Name of the Beneficiary

Module No.

Battery No.

1

Beneficiary
Certificate Sl. No.

Sri Chammai Bachung

778

14221

728

2

Sri Aorju Hagam

1156

10338

729

3

Sri Ram Bachung

745

15700

730

4

Sri Shauna Bachung

941

10048

731

5

Sri Chanmi Bachung

1108

10386

732

6

Sri Adong Hagam

979

14842

733

7

Sri Pem Khandu Bachung

958

10187

734

8

Rinchin Bhagnu

1011

15722

739

9
10

Sangdema Lali
Dawa Tsering Hagam

911
1090

15705
10333

740
741

11

Sancha Lama Hagam

920

15672

742

12

Samhoo Lali

957

13926

753

Name of Village : RAMU Circle:- Sinchung (Total Beneficiary : 12 Nos.)
13

Sri Bijiman Lali

1118

10443

721

14

Sri Angura Lali

944

10068

722

15

Sri Bidu Lali

11300

10203

723

16

Smt Rina Lali

1165

10481

724

17

Sri Dongru Lali

1134

14781

725

18

Sri Jamu Lali

1170

10455

726

19
20
21

Sri Baron Lali
Sangkarboo Badum
Rinchin Drema Lali

1083
963
1043

15276
15604
15505

727
735
736

<!-- page 4 -->

22
23
24

Rakesh Lali
1014
15749
737
Tsering Narhu Lali
1886
10346
738
Sri Beena Lali
1051
13926
756
Name of Village : ATTA PAI Circle:- Dirang (Total Beneficiary : 8Nos.)

25
26
27
28
29
30
31
32

Tsering
933
10348
751
Sonam Wange
1108
18141
755
Sri Lobsang
785
15565
676
Sri Phurpa Tsering
740
10116
675
Sri Passang Tsering
1063
15728
674
Smt. Dorjee Drema
1121
15587
679
Sri Tsering Droima
743
15709
678
Smt. Bomju Drema
739
15604
677
Name of Village : DIZANGANIA Circle:- Trizino (Total Beneficiary : 3 Nos.)
Jhony Dibisow
1209
10193
746
Ajamber Sidisow
1113
10045
745
Dishib Sidisow
943
10153
744
Name of Village : TANIA Circle:- Trizino (Total Beneficiary : 16 Nos.)
Sri Rohit Chitan
1210
10269
665
Sri Bulo Rojung
921
10345
664
Sri Baji Chijang
1091
10194
663
Sri Jampu Tania
989
10340
662
Sri Libi Tania (For School)
639
10044
661
Sri Shja Rojing
674
15854
660
Sri Logio Rojung
1348
10500
659
Sri Libi Tania
1038
15510
658
Sri Lulong Rojung
1042
15393
657
Sri Khomsi Tania
912
10485
656
Sri Nagma Tania
1347
15825
655
Sri Sunil Chijang
1087
10037
654
Sri Rajen Chijang
885
15743
653
Singha Tania
1124
15555
652
Raju Chijan
853
14751
651
Jinbu Sidisow
1300
15679
689
Name of Village : NGAIRI BAKSA Circle:- Dirang (Total Beneficiary : 11 Nos.)
Kukpa
938
10153
754
Lobsang Phuntso
1004
15527
700
Sri Dorjee Phuntso
1128
10452
688
Sri Tsering Norbu
1242
10183
687
Sri Lobsang Thondok
1364
10419
686
Sri Sange Droima
912
10334
685
Sri Dorjee Lhamu
1012
15706
684
Sri Leiki Tsering
887
15723
683
Smt. Karmu
1015
10347
682
Tenzing
1044
15750
681

33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61

<!-- page 5 -->

964
15505
680
62 Sri Namge
Name of Village : RANGSHING Part-I / II / III Circle:- Dirang (Total Beneficiary : 14 Nos.)
63
64
65
66
67
68
69
70
71
72
73
74
75
76
77
78
79
80
81
82
83
84
85
86
87
88
89
90
91
92
93
94
95
96
97
98
99
100
101

Thongern Jomba
1238
10306
749
Lobsang Dharke
1098
10268
748
Lobsang Tsering Bapu
1288
10080
750
Thepu Tsering
966
10344
747
Sonam Wange
1228
15561
699
Phurpa Tsering Babu
1271
10027
698
Sri Tashi Lama
1091
15506
673
Smti Kesang Drema
1067
13625
672
Rinhin Drema
1183
10075
671
Smt Pema
1133
15688
670
Sri Sange Tsering
1171
15840
669
Mrs Yangchen
1384
15508
668
Sri Tsering Tashi
1252
15627
667
Sri Lobsang Norbu
1301
15680
666
Name of Village : LICHINI Circle:- Sinchung (Total Beneficiary : 18 Nos.)
Sri Nichew Hagam
1150
14703
642
Sri Gohai Bachung
1160
15825
641
Sri Kumar Hagam
976
10241
645
Sri Sonary Hagam
970
14779
643
Sangdema Budhan
784
15564
648
Handu Bachung
738
15603
649
Sri Jiten Bachung
1245
10037
636
Sri Ashi Hagam
1358
10320
637
Sri Sibu Bachung
1089
14814
638
Sri Mosibu Bachung
923
10060
639
Sri Niri Bachung
877
10248
640
Sri Sandhi Bachun
742
15708
650
Sri Alla Bachung
748
10466
646
Sri Runu Hachung
1018
10028
634
Sri Lobsang Hagam
1120
15586
697
Sri Bidoi Bachung
981
10283
644
Sri Rajeeb Bachung
738
10115
647
Sri Lamacho Hagam
1355
10384
635
Name of Village : SACHITA Circle:- Sinchung (Total Beneficiary : 19 Nos.)
Sounam Hagnm
1062
15727
696
Tsering Bachum
1066
13624
695
Siri Hagam
1182
10074
694
Sunil Bachun
1132
15687
693
Dorjee Soram
1170
15839
692
Wangle Suram
1383
15507
691
Tsering Hagam
1251
15726
690

<!-- page 6 -->

102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129
130
131
132
133
134
135
136
137
138
139
140
141
142
143

Sri Miring Dema
1140
15683
627
Sri Rajen Suram
1168
10064
626
Ashok Hagom
987
15697
625
Sri Jony Hagom
988
10367
624
Sri Wangdi Hagom
851
10181
631
Sri Sunil Hagam
1065
10068
630
Sri Bikai Surum
834
10288
629
Sri Lobsang Hagam
1218
10233
628
Daji Hagam
1351
10026
701
Rajanmn Surung
1261
10052
702
Sri Recheng Surum
1143
15689
633
Sri Hari Hagtom
1205
10212
632
Name of Village : NAMFRI Circle:- Sinchung (Total Beneficiary : 20 Nos.)
Sri Dawa Surung
1296
10335
614
Sri Lasibo Surung
975
10442
611
Sri Nowang Surung
879
10465
610
Amul Phung
980
10240
609
Sri Sarang Sarung
969
10282
608
Rohit Phung
1149
14778
607
Sri Mina Phung
1194
14072
606
Sri Ashoth Somu
942
14812
605
Ratan Phung
1159
15824
604
Sri Ranjan Phung
876
10247
603
Abuda
922
10059
602
Engine Sharum
1088
14813
601
Sri Sanja Phung
1139
10067
713
Sri Dachi Sorung
743
10202
714
Sri Passang Phung
1117
14780
715
Sri Thama Surung
943
10457
716
Sri Sapu Phung
1129
15275
717
Sri Ananda Budai
1133
10322
718
Sri Vijay Sikha
1169
14813
719
Smt Reshma Sikha
1082
14220
720
Name of Village : MAGOPAM Circle:- Sinchung (Total Beneficiary : 22 Nos.)
Sri Maba
1107
14841
618
Sri Gombu Sarung
978
10186
619
Sri Aching Sarung
957
10130
620
Sri Sonam Bodei
940
10385
617
Chumbang sharun
1043
10446
623
Chumbi Budai
564
10451
622
Sri Chumbu Budai
1017
10387
613
Sri Samchu Sarung
777
15780
612
Sri Sanju Dhung
1155
15699
615
Sri Machan Mai
744
10047
616

<!-- page 7 -->

144
145
146
147
148
149
150
151
152
153
154
155

Sri Dorjee Sarung
Smt. Reena Sarung
Smt. Rema Sarung
Sri Lalaje Sikha
Sri Maniram Sikha
Sri Sankgar Budai
Sri Tashi Norbu Sorung
Sri Darbu Sarung
Smt. Lela Sarung
Sri Khalibo Bachum
Sri Lobsang Sikha
Sri Narbu Sharung

842
1044
880
956
1021
988
1127
787
854
1009
994
868

16036
10292
10114
10191
10167
10287
10025
10569
10091
10534
10066
10390

703
704
705
706
707
708
709
710
711
712
752
621

BENEFICIARY LIST OF EAST KAMENG DISTRICT
District: East Kameng
Beneficiary Name
Sl.No

Circle:Bameng
Sl.No. of Module

Sl.No. of Battery

Village: Effa
Date of Installation

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15

Adap Effa
Tana Effa
Kojum Effa
Jarje Effa
Pola Effa
Ley Effa
Solung Effa
Tacho Effa
Chasap Effa
Mibi Effa
Choya Effa
Balow Effa
Maje Effa
Dongro Effa
Pochu Effa

02090456
02090459
02090498
02090052
02090357
02090463
02090359
02090460
02090368
02090257
02090225
02090495
03090043
02090457
02090253

17589
17576
17529
17373
17656
17005
17102
17198
17469
17562
17612
17396
17472
17552
17697

04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009

16
17
18
19
20
21

Keeha Effa
Tachu Effa
Taja Effa
Mocha Effa
Tasin Effa
Tania Effa

03090102
02090250
03090084
03090374
02090267
02090294

17148
17302
17131
17113
17429
17231

04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009

<!-- page 8 -->

Chara Effa
22
Hindu Effa
23
Konda Effa
24
Takia Effa
25
Tamin Effa
26
District: East Kameng

02090399
02090366
02090481
03090068
03090056
Circle:Bameng

17578
17107
17463
17421
17225

04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
Village: Gidi Sollung

Sl.No. of Module

Sl.No. of Battery

Date of Installation

Halangng Gidi
Goya Effa

03090067
02090298

17636
17593

04-01-2009
04-01-2009

Tacho Gidi
3
Agam Gidi
4
Paching Gidi
5
Tallung Gidi
6
Wai Gidi
7
Kecha Gidi
8
Chatung Gidi
9
Meba Gidi
10
Nani Gidi
11
Tarin Gidi
12
Cheba Gidi
13
Tata Gidi
14
Pachu Gidi
15
Cheto Gidi
16
District: East Kameng
Beneficiary Name
Sl.No

02090482
03090400
03090407
02090260
03090384
03090087
03090166
03090039
03090797
03090123
03090116
03090326
03090150
02090290
Circle:Bameng
Sl.No. of Module

17026
17391
17241
17634
17164
170669
17531
17616
17610
17069
17507
17580
17462
17510

04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
Village: Khora (Khyora)
Date of Installation

Jeli Khora
1
Kelay Sono
2
Karbia Khora
3
Robin Khora
4
District: East Kameng
Beneficiary Name
Sl.No

030900863
03090613
030773
03090401
Circle:Bameng
Sl.No. of Module

Sl.No. of Battery

05-01-2009
05-01-2009
05-01-2009
05-01-2009
Village: Lengdi Liyang
Date of Installation

03090359
03090053
03090047
02090497
03090144
03090046
03030109
03090111
03090794
02090381
02090450
02090228

17522
17530
17220
17146
17512
17621
17590
17226
17545
17434
17129
17119

04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009

Sl.No
1
2

1
2
3
4
5
6
7
8
9
10
11
12

Beneficiary Name

Chasap Liyang
Chapu Liyang
Hakam Liyang
Bida Liyang
Tabang Liyang
Harang Liyang
Taging Liyang
Tadung Liyang
Maniang Liyang
Maching Liyang
Maku liyang
Kapow Liyang

Sl.No. of Battery
17046
17615
17263
17910

<!-- page 9 -->

Tapeing Liyang
13
Tha Liyang
14
Malli Liyang
15
Roy Liyang
16
District: East Kameng
Beneficiary Name
Sl.No

02090241
03090329
03090173
02090275
Circle:Bameng
Sl.No. of Module

Taluk Lorah
1
Adap Lorah
2
Saja Lorah
3
Dope Lorah
4
Talo Lorah
5
Nama Lorah
6
Solung Lorah
7
Tayung Lorah
8
Racho Lorah
9
Kamta Lorah
10
Dorang Lorah
11
Walong Lorah
12
Taro Lorah
13
Nipa Lorah
14
Gumrey Lorah
15
Tedi Lorah
16
Karu Lorah
17
Pumkla Lorah
18
Kamguk Lorah
19
Tafung Lorah
20
Pimjing Lorah
21
Taro Lorah
22
Paffa Lorah
23
Takha Lorah
24
Lama Lorah
25
Lama Lorah
26
Tadu Lorah
27
Roy Lorah
28
Gungli Lorah
29
District: East Kameng
Beneficiary Name
Sl.No

02090263
02090324
02090099
02090357
02090308
02090338
02090446
02090493
02090036
02090024
03090414
02090249
02090269
02090300
02090229
02090664
03090037
02090478
03090381
0309018
03090336
03090526
03090431
03090297
03090433
03090036
03090999
03090997
03090995
Circle:Bameng
Sl.No. of Module

Sibu Pakksa
1
Gyoling Pakksa
2
Dongra Pakksa
3
Katti Pakksa
4
Taha Pakksa
5
District: East Kameng

02090492
02090455
02090489
02090459
02090279
Circle:Bameng

17517
17641
17482
17089
Sl.No. of Battery
17018
17292
17435
17463
17145
17339
17002
17601
17136
17421
17004
17009
17236
17457
17361
17200
17258
17776
177174
17011
17055
17006
17048
17356
17045
17045
17012
17574
17682
Sl.No. of Battery
17497
17009
17625
17515
17173

04-01-2009
04-01-2009
04-01-2009
04-01-2009
Village: Lorah
Date of Installation
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
Village: Pakksa
Date of Installation
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
Village: Poube Sollung

<!-- page 10 -->

Beneficiary Name

Sl.No. of Module

Sl.No. of Battery

Date of Installation

Pungni Poube
1
Nime Poube
2
Agung Poube
3
Tolang Poube
4
Nishan Poube
5
Yago Poube
6
Pani Poube
7
Passung Poube
8
Karo Poube
9
Saing Poube
10
Rajeng Poube
11
Niki Poube
12
Damko Poube
13
Roju Poube
14
District: East Kameng
Beneficiary Name
Sl.No

03090266
03090181
03090148
03090426
03090253
03090414
03090342
03090332
03090372
03090310
03090217
03090212
03090284
03090069
Circle:Bameng
Sl.No. of Module

17278
17445
17270
17611
17207
17375
17460
17630
17193
17527
17362
17626
17648
17481

04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
Village: Rassang
Date of Installation

Tagio Rassang
1
Yaja Rassang
2
Tallo Rassang
3
Sallung Rassang
4
Yaro Rassang
5
Chara Rassang
6
Sama Rassang
7
Nikam Rassang
8
Jitung Rassang
9
Kassang Rassang
10
District: East Kameng
Beneficiary Name
Sl.No

03090222
03090260
03090276
03090237
03090156
03090471
03090261
03090409
03090404
0309093
Circle:Bameng
Sl.No. of Module

Sl.No. of Battery

04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
Village: Rengtewah
Date of Installation

03090129
03090265
03090135
03090417
03090080
03090062
03090425
03090132
03090282
03090097
03090095
03090333
03090262
03090125

17356
17551
17412
17602
17380
17264
17623
17609
17557
17071
17390
17553
17491
17232

04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009

Sl.No

1
2
3
4
5
6
7
8
9
10
11
12
13
14

Meyo Rengtewah
Baingmu Rengetwah
Rangno Rengtewah
Daji Rengtewah
Meya Rengtewah
Rakesh Rengtewah
Koro Rengtewah
Madung Rengtewah
Chope Rengtewah
Changba Rengtawah
Taring Rengtawah
Meakio Rengtewah
Rangno Rengtewah
Prey Rengtewah

Sl.No. of Battery
17160
17605
17644
17415
17299
17053
17439
17617
17492
17524

<!-- page 11 -->

Charu Rengtewah
15
Jerbi Rengtewah
16
Watung Rengtwah
17
Tammer Rengtewah
18
Chakoi Rengtewah
19
District: East Kameng
Beneficiary Name
Sl.No

02090243
02090461
02090251
02090479
03090350
Circle:Bameng
Sl.No. of Module

Tha Taffo
1
Pada Taffo
2
Agamg Taffo
3
Tado Taffo
4
Tajo Taffo
5
Gienwe Taffo
6
Chin Taffo
7
Tako Taffo
8
District: East Kameng
Beneficiary Name
Sl.No

02090491
02090506
02090505
03090366
03090149
03090249
03090119
03090339
Circle:Bameng
Sl.No. of Module

Niku Liyang
1
Puru Liyang
2
Bangamg Liyang
3
Karu Liyang
4
Taso Liyang
5
Tadung Liyang
6
Saji Liyang
7
Gora Liyang
8
Mesum Liyang
9
Jamsi Liyang
10
Gamto Liyang
11
Talamg Liyang
12
Taro Liyang
13
Dongro Liyang
14
Tayang Liyang
15
Tagio Liyang
16
Mangram Liyang
17
District: East Kameng
Beneficiary Name
Sl.No

02090365
02090369
03090083
03090140
02090258
03090128
03090319
03090285
03090110
03090041
02090468
02090462
02090504
02090465
02090358
02090248
03090098
Circle:Bameng
Sl.No. of Module

Sl.No. of Battery

04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
Village: Tayung
Date of Installation

Nigma Tayung
Tachi Tayung
Tagio Tayung
Jiyo Tayung
Tage Tayung
Bongli Tayung
Pora Tayung

03090416
03090216
03090375
02090277
02090262
02090261
02090386

17294
17365
17165
17381
17478
17168
17568

04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009

1
2
3
4
5
6
7

17297
17532
17240
17535
17508
Sl.No. of Battery
17595
17662
17647
17481
17473
17627
17028
17560
Sl.No. of Battery
17151
17115
17660
17506
17301
17533
17114
17281
17260
17219
17577
17639
17230
17012
17994
17203
17542

04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
Village: Taffo
Date of Installation
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
Village: Sippi Liyang
Date of Installation

<!-- page 12 -->

Nikam Tayung
8
Kora Tayung
9
Charo Tayung
10
Saji Tayung
11
Saja Tayung
12
Khili Tayung
13
Joram Tayung
14
Nama Tayung
15
District: East Kameng
Beneficiary Name
Sl.No
Niklang Lorah
1
Tagio Lorah
2
Tagam Lorah
3
Chokom Lorah
4
Sham Lorah
5
Pakko Lorah
6
Rali Lorah
7
Tamang Lorah
8
Tachang Lorah
9
Taro Lorah
10
Rai Lorah
11
Rana Lorah
12
Lamku Lorah
13
Sisu Lorah
14
Taru Lorah
15
Singmik Lorah
16
Harang Lorah
17
Lata Lorah
18
Dili Lorah
19
Kunla Lorah
20
Kuto Lorah
21
Soyang Lorah
22
Chayo Lorah
23
Lukey Lorah
24
Tadang Lorah
25
Dai Lorah
26
District: East Kameng
Beneficiary Name
Sl.No
Hamke Byale
1
Tabin Byale
2
Nisam Byale
3
Kale Byale
4
Bangani Byale
5
Remey Byale
6

02090440
03090155
02090474
02090395
02090503
02090443
02090367
02090442
Circle:Bameng
Sl.No. of Module
03090014
03090472
032090154
02090440
03090128
03090643
03090002
03090327
03090102
02090448
03090542
02090032
03090341
03090828
03090332
03090701
03090879
02090552
03090743
03090323
03090157
03090451
03090135
03090432
03090247
03090507
Circle:SAWA
Sl.No. of Module
04090316
04090315
04090502
04090560
04090253
04090476

17166
17163
17569
17467
17209
17201
17559
17162
Sl.No. of Battery
17605
17258
17808
17794
17331
17551
17714
17313
17014
17744
17340
17117
17001
17691
17759
17074
17619
17203
17740
17284
17084
17272
17269
17405
17028
17456
Sl.No. of Battery
19921
19632
19973
19445
19439
19901

04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
04-01-2009
Village: Riga Camp
Date of Installation
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
Village: Byale Sollung
Date of Installation
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009

<!-- page 13 -->

Yamak Byale
7
Mering Byale
8
Macha Byale
9
Mujiuk Byale
10
Yanga Byale
11
Singkap Byale
12
Kallung Byale
13
Chayalug Byale
14
Nidak Byale
15
Taku Byale
16
Takey Byale
17
Takap Byale
18
Tayum Byale
19
Tabu Byale
20
Tapu Bayle
21
Tapum Bayle
22
Yaka Bayle
23
Tak Byale
24
Yaper Byale
25
Lakung Byale
26
Kyachi Byale
27
District: East Kameng
Beneficiary Name
Sl.No
Runghia Bodhi
1
Mama Bodhi
2
Tabing Bodhi
3
Karu Bodhi
4
Tachang Bodhi
5
Yage Bodhi
6
Niyachi Bodhi
7
Namu Bodhi
8
Yama Bodhi
9
Kojum Bodhi
10
Kop Bodhi
11
Kaku Bodhi
12
Lotu Bodhi
13
Tayum Bodhi
14
Takar Bodhi
15
Tajum Bodhi
16
Tagap Bodhi
17
Tale Bodhi
18
Tagu Bodhi
19
District: East Kameng
Beneficiary Name
Sl.No

04090111
04090251
04090263
04090118
04090068
04090034
04090007
03091051
04090063
04090097
04090076
04090079
04090100
04090026
04090025
04090033
04090576
04090419
04090321
04090317
04090323
Circle:SAWA
Sl.No. of Module
04090295
04090142
0301016
04090122
04090237
04090255
04090269
04090145
04090280
04090129
04090033
04090344
04090328
04090558
03090136
04090387
04090299
04091098
04090215
Circle:SAWA
Sl.No. of Module

19682
19621
19642
19864
19469
19886
19736
19541
19607
19874
19925
19526
19785
19871
19441
19743
19452
19572
19645
19543
19770
Sl.No. of Battery
19690
19840
19690
19439
19685
17772
19628
19673
19779
19644
19789
19651
19482
19443
19669
19610
19889
19612
19398
Sl.No. of Battery

27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
27-04-2009
Village: BODHI
Date of Installation
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
13-04-2009
Village: BODHI
Date of Installation

<!-- page 14 -->

Tasa Yangfo
1
Tadak Dara
2
Tacho Dara
3
Taka Dara
4
Talok Dara
5
Bada Dara
6
Koma Dara
7
District: East Kameng
Beneficiary Name
Sl.No
Kati Piya
1
Marim Piya
2
Mache Piya
3
Damsap Piya
4
Kajap Piya
5
Kiya Piya
6
Akik Piya
7
Yamak Piya
8
Yakap Piya
9
District: East Kameng
Beneficiary Name
Sl.No
Kapa Kowa
1
Adap Kowa
2
Meuy Kowa
3
Papi Kowa
4
Yamak Kowa
5
Kajak Kowa
6
District: East Kameng
Beneficiary Name
Sl.No
Nibu Lamrah
1
Sai Lamrah
2
Rajo Lamrah
3
Chasu Lamrah
4
Kamku Lamrah
5
Tatam Lamrah
6
Tasong Lamrah
7
Marbia Lamrah
8
Taro Lamrah
9
Keye Lamrah
10
Tadu Lamrah
11
Racho Lamrah
12
District: East Kameng
Beneficiary Name
Sl.No
Tarang Yangfo
1
Pacha Yanfo
2

04090319
04090262
04090301
04090924
04090438
04090435
04090279
Circle:SAWA
Sl.No. of Module
03090999
04090440
04090239
04090248
04091044
04090131
03091040
04090206
04090240
Circle:SAWA
Sl.No. of Module
04091015
04090109
04090494
04090317
04090236
0309059
Circle:SAWA
Sl.No. of Module
04090506
04090492
04090329
04090104
04090146
04090085
04090256
04090082
04091047
04090134
04090031
04090005
Circle:SAWA
Sl.No. of Module
04090327
04090559

19579
19663
19581
19599
19602
19587
19913
Sl.No. of Battery
19617
19576
19726
19792
19674
19535
19734
19599
19666
Sl.No. of Battery
19578
19603
19525
19575
19434
17551
Sl.No. of Battery
19587
19454
19775
19521
19756
19517
19811
19753
19619
16534
19680
19947
Sl.No. of Battery
19881
19489

17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
Village: Piya
Date of Installation
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
Village: Kowa Sollung
Date of Installation
15-04-2009
15-04-2009
15-04-2009
15-04-2009
15-04-2009
15-04-2009
Village:Lamrah
Date of Installation
15-04-2009
15-04-2009
15-04-2009
15-04-2009
15-04-2009
15-04-2009
15-04-2009
15-04-2009
15-04-2009
15-04-2009
15-04-2009
15-04-2009
Village:Loto Yangfo
Date of Installation
15-04-2009
15-04-2009

<!-- page 15 -->

Kardo Yangfo
3
Meko Yangfo
4
Tari Yangfo
5
Singke Yangfo
6
Somo Dara
7
Tama Yangfo
8
District: East Kameng
Beneficiary Name
Sl.No
Kamle Mangfi
1
Nisam Mangfi
2
Karling Mangfi
3
Kacha Mangfi
4
Takia Mangfi
5
Lafe Mangfi
6
Ada Mangfi
7
Plang Mangfi
8
Tapuk Mangfi
9
Dar Mangfi
10
Pacha Mangfi
11
Apik Mangfi
12
Akam Mangfi
13
Mebing Mangfi
14
Fai Mangfi
15
Kongo Mangfi
16
Singmo Mangfi
17
Nime Mangfi
18
Tayu Mangfi
19
Ajay Mangfi
20
District: East Kameng
Beneficiary Name
Sl.No
Kajap Mechar
1
Mepung Mechar
2
Sanju Mechar
3
Melay Mechar
4
Yapak Mechar
5
Kaley Mechar
6
Yape Mechar
7
Tukbing Mechar
8
Kyaping Mechar
9
Takom Mechar
10
Akik Mechar
11
Kalang Mechar
12
District: East Kameng
Beneficiary Name
Sl.No

0391036
04090385
04090493
04090298
04090303
04090275
Circle:SAWA
Sl.No. of Module
03091036
03090997
04090039
04090028
04090055
04090128
04090063
04090119
04090214
04090270
04090247
04090029
04090962
04090231
04090229
04090093
04090232
04090234
04090147
03090235
Circle:SAWA
Sl.No. of Module
04090338
04090300
04090272
04090033
04090547
04090541
03090965
04090305
0409472
04090384
04090335
04090383
Circle:SAWA
Sl.No. of Module

19569
19555
19771
19255
19436
19596
Sl.No. of Battery
19719
19527
19590
19758
19870
19845
19703
19544
19522
19546
19755
19717
19647
19824
19665
19768
19822
19805
19800
17054
Sl.No. of Battery
19720
19726
19475
19427
19618
19601
19672
19431
19460
19646
19690
19698
Sl.No. of Battery

15-04-2009
15-04-2009
15-04-2009
15-04-2009
15-04-2009
15-04-2009
Village:Mangam
Date of Installation
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
14-04-2009
Village:MECHAR
Date of Installation
17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
Village:MECHI
Date of Installation

<!-- page 16 -->

Mekhia Mechi
1
Medung Mechi
2
Karte Mechi
3
Apik Mechi
4
Meche Mechi
5
Abu Mechi
6
Kya Mechi
7
District: East Kameng
Beneficiary Name
Sl.No
Tachung Bagang
1
Niklar Bagang
2
Papi Bagang
3
Mekia Bagang
4
Tadak Bagang
5
Yaro Bagang
6
Mesing Bagang
7
Nibu Yangfo
8
Lapium Dara
9
Meen Bagang
10
Taram Dara
11
Yagiam Dara
12
Yalung Dara
13
District: East Kameng
Beneficiary Name
Sl.No
Chacho Yangfo
1
Jarang Yangfo
2
Tado Yangfo
3
Seme Yangfo
4
Taro Yangfo
5
Tabu Yangfo
6
District: East Kameng
Beneficiary Name
Sl.No
Tugdik Pao
1
Suka Pao
2
Ama Pao
3
Rumka Pao
4
Tayam Pao
5
Bangge Pao
6
Takiang Pao
7
Fipak Pao
8
Koto Pao
9
District: East Kameng
Beneficiary Name
Sl.No
Kome Parte
1

03090036
03091009
03091002
04090306
04090016
04090049
04090409
Circle:SAWA
Sl.No. of Module
03091029
04090106
04090095
04090006
04090075
04090072
04090204
04090108
04090070
04090112
04090210
04090004
04090219
Circle:SAWA
Sl.No. of Module
04090354
04090356
04090120
03091011
04090077
04090213
Circle:SAWA
Sl.No. of Module
04090505
04090305
04090514
04090053
04090127
04090410
02090409
04090039
04090344
Circle:SAWA
Sl.No. of Module
04090297

19896
19747
19466
19732
19597
19825
19677
Sl.No. of Battery
19556
19520
19449
19627
19492
19435
19584
19648
19828
19893
197012
19660
19926
Sl.No. of Battery
19804
19697
19715
19705
19641
19508
Sl.No. of Battery
19471
19530
19512
19854
19703
19593
19504
19579
19810
Sl.No. of Battery
19878

17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
17-04-2009
Village:Nampe Bagang
Date of Installation
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
Village:NAMTA
Date of Installation
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
Village:Pao
Date of Installation
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
Village: PARTE
Date of Installation
19-04-2009

<!-- page 17 -->

Senia Parte
2
Gumke Parte
3
Tapong Parte
4
Romesh Parte
5
Tuking Parte
6
District: East Kameng
Beneficiary Name
Sl.No
Tajik Raro
1
Sampa Raro
2
Dambia Raro
3
Gange Raro
4
Kare Raro
5
Logo Raro
6
Tongdung Raro
7
Chabing Raro
8
Bale Raro
9
Dha Raro
10
Lebo Raro
11
Tagung Raro
12
Koh Raro
13
Tasha Raro
14
Taruk Raro
15
Mering Raro
16
Mepung Raro
17
Tagu Raro
18
Takap Raro
19
District: East Kameng
Beneficiary Name
Sl.No
Agun Saria
1
Laxmi Saria
2
Ata Saria
3
Yachak Saria
4
Atang Saria
5
Logo Saria
6
Hano Saria
7
Picha Saria
8
Nisam Saria
9
Samerik Saria
10
Khesmik Saria
11
Meyang Saria
12
Kati Saria
13
Kale Saria
14
Tugi Saria
15
Nidak Saria
16

04090382
04090337
04090381
04060548
04090309
Circle:SAWA
Sl.No. of Module
04090333
04090546
04090224
04090027
04090023
04090077
02090364
04091040
04090131
02090109
02090310
03090331
03091015
02090117
04090554
04090087
04090028
02090258
04090235
Circle:SAWA
Sl.No. of Module
04090258
04090235
04090260
04090247
04090252
04090243
04090201
04090202
04090254
04090143
04090558
04090229
04090344
04090328
04090278
04090409

19688
19716
19650
19694
19559
Sl.No. of Battery
19605
19599
19813
19575
19894
19693
19856
19654
19984
19483
19517
19614
19616
19713
19904
19748
19812
19592
19840
Sl.No. of Battery
19577
19499
19742
19518
19750
19406
19808
19809
19569
19687
19799
19678
19461
19916
19676
19580

19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
Village: RARO SOLLUNG
Date of Installation
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
21-04-2009
Village: SARIA TAKING
Date of Installation
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009

<!-- page 18 -->

Jabring Saria
17
Yamak Saria
18
Yayak Saria
19
Tai Saria
20
Chakum Saria
21
Tak Saria
22
Tape Saria
23
Adang Saria
24
District: East Kameng
Beneficiary Name
Sl.No
Aya Tapim
1
Jarsey Tapim
2
Kamku Tapin
3
Koro Tapin
4
Yaro Tapin
5
Kurung Tapim
6
Kasmak Tapin
7
Dasang Tapim
8
Taying Tapim
9
Sung Tapim
10
Tajik Tapim
11
Tasa Tapi
12
Amjang Tapim
13
Asung Tapim
14
Yung Tapim
15
Aga Tapim
16
Kusuk Tapim
17
Amak Tapim
18
Takar Tapim
19
District: East Kameng
Beneficiary Name
Sl.No
Tajo Tongi
1
Taran Tongi
2
Lamang Tongi
3
Tasak Tongi
4
Longming Tongi
5
Nimay Tongi
6
Sama Tongi
7
Jomo Tongi
8
Tama Tongi
9
Maro Tongi
10
Mangfi Tongi
11
Mapung Tongi
12
Kamku Tongi
13

04090510
04090282
04090271
04090556
04090020
03090566
03091032
03091023
Circle:SAWA
Sl.No. of Module
03091055
030901050
03091057
04090389
04090389
04090266
04090412
04090320
04090417
04090392
04090427
04090493
04090496
04090045
04090054
04090041
04090437
04090438
04090439
Circle:SAWA
Sl.No. of Module
04090515
03090440
04090025
03090999
03091017
04090212
04090222
04090061
04090228
04090052
04090046
04090130
20901045

19570
19806
19751
19859
19774
19745
19910
19915
Sl.No. of Battery
19788
19770
19452
19637
19622
19791
19766
19485
19499
19503
19858
19540
19447
19842
19792
17910
17528
17911
17768
Sl.No. of Battery
19566
19912
19594
19718
19773
19455
19505
197010
19888
19862
19801
19830
17875

23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
23-04-2009
Village: TAPIM
Date of Installation
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
24-04-2009
Village: TONGI
Date of Installation
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009
18-04-2009

<!-- page 19 -->

Lokap Tongi
14
District: East Kameng
Beneficiary Name
Sl.No
Bangram Venia
1
Mangfa Venia
2
Pacha Venia
3
Tafa Venia
4
Tama Venia
5
Kamku Venia
6
Wecha Venia
7
Chacho Venia
8
Kajab Venia
9
Yano Venia
10
Sesam Venia
11
Gangme Venia
12
Yadang Venia
13
Dugro Venia
14
Yaram Venia
15
District: East Kameng
Beneficiary Name
Sl.No
Tania Veo
1
Senia Veo
2
Yago Veo
3
Saji Veo
4
Yamay Veo
5
Bat Veo
6
Hano Veo
7
Kamku Veo
8
Tadak Veo
9
Mangfa Veo
10
Nibu Veo
11
Logo Veo
12
Kati Veo
13
Tatang Veo
14
Tabung Veo
15
Tungkiya Veo
16
Mebing Veo
17
Seme Veo
18
Chape Veo
19
Yakio Veo
20
Nigya Veo
21
Kasung Veo
22
Menia Veo
23
Papi Veo
24

02090036
Circle:SAWA
Sl.No. of Module
04090575
04090440
04090025
03090999
03091017
04090212
04090222
04090061
04090061
04090229
04090052
04090047
04090132
04090081
04090966
Circle:SAWA
Sl.No. of Module
04090110
040900050
03090963
03090127
03091031
03091045
03090968
03091014
04090415
04090411
04090285
04090261
04090324
04090407
04090391
04090406
04090415
04090557
04090426
04090431
04090359
04090433
04090501
04090498

17547
Sl.No. of Battery
17882
17583
17586
17104
17107
17108
17243
17244
17137
17525
17641
17644
17080
17247
17528
Sl.No. of Battery
19925
19526
19785
19871
19441
19743
19542
19572
17172
17363
17173
17366
17178
17339
17174
17082
17175
17023
17176
17022
17177
17173
17377
17119

18-04-2009
Village: VENIA
Date of Installation
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
Village: VEO
Date of Installation
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009
25-04-2009

<!-- page 20 -->

District: East Kameng
Beneficiary Name
Sl.No
Seko Yakli
1
Sello Yakli
2
Tafang Yakli
3
Tajik Yakli
4
Ajik Yakli
5
Ley Yakli
6
Yama Yakli
7
Tama Yakli
8
Karap Yakli
9
Kabing Yakli
10
Chakap Yakli
11
Tungdang Yakli
12
Kallang Yakli
13
Kati Yakli
14
Wing Yakli
15
Senia Yakli
16
Nibu Yakli
17
Paso Yakli
18
Rumsa Yakli
19
Ching Yakli
20
Ray Yakli
21
Tukik Yakli
22
Lakung Yakli
23
District: East Kameng
Beneficiary Name
Sl.No
Karling Nampe
1
Sei Nampe
2
Bangram Nampe
3
Simpe Nampe
4
Sama Nampe
5
Raktum Nampe
6
Siome Nampe
7
Taluk Nampe
8
Tukpi Nampe
9
Senia Nampe
10
Tachung Nampe
11
Doni Nampe
12
Yapel Nampe
13
Ganku Nampe
14
District: East Kameng
Beneficiary Name
Sl.No
Nekhio Sario
1

Circle:SAWA
Sl.No. of Module
03091019
03090074
03090227
03090430
04090479
03090342
03090489
03090343
03090340
03090352
03090439
03090480
03090017
03090687
03091007
03090108
03090000
03091009
030901002
03090991
04090003
03090994
03091059
Circle:SAWA
Sl.No. of Module
04090056
04090080
04090967
04091019
04090240
04090206
03091044
04090236
04090063
04090234
03090429
04090494
04090136
04090113
Circle:SAWA
Sl.No. of Module
04090260

Sl.No. of Battery
17661
17110
17022
17765
17074
17429
17324
17503
17440
17443
17448
17312
17123
17210
17409
17490
17205
17025
17119
17085
17086
17841
17633
Sl.No. of Battery
19643
19772
19444
19529
19985
19805
19858
19447
19634
19842
19782
19914
19844
19664
Sl.No. of Battery
19846

Village: YAKLI
Date of Installation
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
26-04-2009
Village: NAMPE
Date of Installation
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
19-04-2009
Village: SARIO
Date of Installation
22-04-2009

<!-- page 21 -->

Aju Sario
2
Logo Sario
3
Akhio Sario
4
Yang Sario
5
Rai Sario
6
Along Sario
7
Chakop Sario
8
Tamak Sario
9
Taniang Sario
10
Ayang Sario
11
Chabing Sario
12
Abing Sario
13
Chu Sario
14
Amak Sario
15
Sangdung Sario
16
Ayam Sario
17
Lamyang Sario
18
Amo Sario
19
Agam Sario
20
Niring Sario
21
Logo Sario
22
District: East Kameng
Beneficiary Name
Sl.No
Richang Miji
1
District: East Kameng
Beneficiary Name
Sl.No
Jashi Miji
1
Nijaw Miji
2
Chungbu Miji
3
Gyapang Miji
4
Longma Miji
5
Tonglai Miji
6
Satam Miji
7
Dairu Miji
8
District: East Kameng
Beneficiary Name
Sl.No
Karu Puroik
1
Singchung Miji
2
Kalong Miji
3
Kangcha Puroik
4
Yai Puraoik
5
Yater Puroik
6
Metai Miji
7
Jarang Miji
8

04090247
04090252
04090243
04090201
04090202
04090255
04090143
04090060
04090105
04090114
04090036
04090096
04090107
04090209
04090403
04090396
04090429
04090349
04090257
04090399
03090347
Circle: LADA
Sl.No. of Module
020900501
Circle: LADA
Sl.No. of Module
03090331
03090425
03090269
03090424
03090160
03090324
03090389
020900400
Circle: LADA
Sl.No. of Module
020900415
0209000096
020906297
020900097
0209000274
020900072
0209000382
0209000360

19729
19707
19653
19909
19860
19908
19484
19554
19920
19861
17102
17418
19645
19471
19530
19512
19854
19593
19730
19600
17282
Sl.No. of Battery
17505
Sl.No. of Battery
17420
17564
17565
17566
17425
17370
17140
17029
Sl.No. of Battery
17651
17484
17663
17177
17615
17477
17047
17171

22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
22-04-2009
Village: PIPIANG
Date of Installation
15-12-2009
Village: Bisal
Date of Installation
05-11-2009
05-11-2009
05-11-2009
05-11-2009
05-11-2009
05-11-2009
05-11-2009
05-11-2009
Village: Nissangjiang
Date of Installation
05-11-2009
05-11-2009
05-11-2009
05-11-2009
05-11-2009
05-11-2009
05-11-2009
05-11-2009

<!-- page 22 -->

District: East Kameng
Beneficiary Name
Sl.No
Kami Puroik
1
Kaji Puroik
2
Serai Puroik
3
Gillong Puroik
4
Mechi Puroik
5
Buli Puroik
6
Damsap Puroik
7
Pako Puroik
8
Waimchi Puroik
9
Chabing Puroik
10
Ajim Puroik
11
Misung Puroik
12
Chime Puroik
13
Loma Puroik
14
District: East Kameng
Beneficiary Name
Sl.No
Yalung Tawe
1
Kheleng Tawe
2
Tak Tawe
3
Atul Changrang
4
Kage Tawe
5
Loga Tawe
6
Tabia Tawe
7
Kilo Tawe
8
Tah Tawe
9
Raimo Tawe
10
Bida Tawe
11
Taluk Tawe
12
Tajo Tawe
13
Tajo Tawe
14
Tado Tawe
15
Hare Tawe
16
District: East Kameng
Beneficiary Name
Sl.No
Hari Tawe
1
Kungpung Tawe
2
Gunte Tawe
3
Kioje Tawe
4
District: East Kameng
Beneficiary Name
Sl.No
Mekia Miji
1
Katang Miji
2

Circle: LADA
Sl.No. of Module
04090507
04090471
04090504
04090347
04090432
02090500
03090500
03090428
03090433
03090435
03090430
03090434
030904132
03090431
Circle: LADA
Sl.No. of Module
04090306
04090515
03090440
04090025
03090999
04090419
04090474
02090512
03090195
02090496
04090016
040900049
04090409
03090997
04090037
04090028
Circle: LADA
Sl.No. of Module
04090402
04090512
04090425
04090513
Circle: LADA
Sl.No. of Module
03090233
03090107

Sl.No. of Battery
19620
19922
19450
19918
19926
19929
19926
19576
19511
19714
19795
19458
19711
19820
Sl.No. of Battery
19732
19566
19912
19594
19718
19503
19613
19604
19791
19803
19597
19825
19677
19740
19497
19704
Sl.No. of Battery
19420
19561
19815
19776
Sl.No. of Battery
17383
17476

Village: Dangkha
Date of Installation
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
Village: Tawa
Date of Installation
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
14-05-2009
Village: Welling Tawa
Date of Installation
14-05-2009
14-05-2009
14-05-2009
14-05-2009
Village: Sallang
Date of Installation
18-05-2009
18-05-2009

<!-- page 23 -->

Nijio Miji
3
Didiram Miji
4
Longmai Miji
5
Boroi Miji
6
Rijo Miji
7
Dirang Miji
8
Apang Miji
9
Segi Miji
10
Labai Miji
11
Jambe Miji
12
Aruna Miji
13
Tachang Miji
14
Tacha Miji
15
Sartum Miji
16
Sumina Miji
17
Agumo Miji
18
District: East Kameng
Beneficiary Name
Sl.No
Mitung Miji
1
Kaming Miji
2
Karto Miji
3
Samon Miji
4
Soleng Miji
5
District: East Kameng
Beneficiary Name
Sl.No
Waigi Puroik
1
Takyung Puroik
2
Kachi Puroik
3
Jeli Puroik
4
Gyanyang Puroik
5
Tabyang Puroik
6
Agang Puroik
7
Kage Puroik
8
Katung Puroik
9
Dangra Puroik
10
Babeng Puroik
11
District: East Kameng
Beneficiary Name
Sl.No
Jha Puroik
1
Ashok Puroik
2
Damsap Puroik
3
Yatung Puroik
4
Pio Puroik
5
Mekya Puroik
6

03090418
03090778
02090307
03090201
02090484
02090485
02090230
03090143
02090288
03090200
02090462
03090371
03090381
03090346
03090340
02090451
Circle: LADA
Sl.No. of Module
03090235
03090751
03090233
03090347
03090228
Circle: LADA
Sl.No. of Module
03090394
03090603
03090402
03090414
03090305
03090300
03090308
03090099
03090292
03090296
03090278
Circle: LADA
Sl.No. of Module
02090398
02090375
02090423
03090288
02090362
02090488

17153
17454
17632
17547
17565
17558
17490
17541
17534
17140
17912
17262
17263
17528
17526
17910
Sl.No. of Battery
17054
17104
17394
17282
17397
Sl.No. of Battery
17471
17043
17480
17598
17032
17504
17084
17654
17280
17471
17277
Sl.No. of Battery
17503
17100
17169
17599
17470
17169

18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
Village: KAMPA
Date of Installation
16-05-2009
16-05-2009
16-05-2009
16-05-2009
16-05-2009
Village: PEA
Date of Installation
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
18-05-2009
Village: Prait
Date of Installation
16-05-2009
16-05-2009
16-05-2009
16-05-2009
16-05-2009
16-05-2009

<!-- page 24 -->

Kago Puroik
7
Fesam Puroik
8
District: East Kameng
Beneficiary Name
Sl.No
Singchung Miji
1
Taku Miji
2
Neraw Miji
3
Nichang Miji
4
Kepo Miji
5
Dongpang Miji
6
Ragio Miji
7
Surang Miji
8
Nijow Miji
9
Goruk Miji
10
Jambu Miji
11
Sollung Miji
12
Nissang Miji
13
District: East Kameng
Beneficiary Name
Sl.No
Kalo Miji
1
Semtung Miji
2
Mosang Miji
3
Sollung Miji
4
Amar Miji
5
Masumgai Miji
6
Sonam Miji
7
District: East Kameng
Beneficiary Name
Sl.No
Logiang Miji
1
Pangiang Miji
2
Bafai Miji
3
Jhum Miji
4
Karmo Miji
5
Niji Miji
6
Lego Miji
7
Gido Miji
8
Jamusang Miji
9
Dangruai Miji
10
Nikiong Miji
11
Logon Miji
12
District: East Kameng
Beneficiary Name
Sl.No
Surang Miji
1
Dongbu Miji
2

02090464
02090466
Circle: LADA
Sl.No. of Module
020900441
020900454
03090357
03090412
03090227
0209049
02090490
02090485
02090448
02090265
02090478
02090671
02090476
Circle: LADA
Sl.No. of Module
03090274
03090404
03090218
03090273
03090154
03090134
03090057
Circle: LADA
Sl.No. of Module
02090409
02090418
03090390
02090428
02090431
02090355
02090502
02090422
02090470
03090401
03090297
02090409
Circle: LADA
Sl.No. of Module
03090351
03090077

17170
17150
Sl.No. of Battery
17105
17502
17067
17067
17140
17224
17076
17666
17159
17064
17522
17523
17117
Sl.No. of Battery
17142
17070
17547
17268
17652
17106
17163
Sl.No. of Battery
17629
17108
17550
17101
17417
17582
17370
17376
17020
17064
17398
17668
Sl.No. of Battery
17521
17603

16-05-2009
16-05-2009
Village: Sachung
Date of Installation
13-05-2009
13-05-2009
13-05-2009
13-05-2009
13-05-2009
13-05-2009
13-05-2009
13-05-2009
13-05-2009
13-05-2009
13-05-2009
13-05-2009
13-05-2009
Village: Wabalang
Date of Installation
19-05-2009
19-05-2009
19-05-2009
19-05-2009
19-05-2009
19-05-2009
19-05-2009
Village: Nabolang
Date of Installation
19-05-2009
19-05-2009
19-05-2009
19-05-2009
19-05-2009
19-05-2009
19-05-2009
19-05-2009
19-05-2009
19-05-2009
19-05-2009
19-05-2009
Village: Wakke
Date of Installation
20-05-2009
20-05-2009

<!-- page 25 -->

Dirangtung Miji
3
Raisu Miji
4
Madhu Miji
5
Kanju Miji
6
District: East Kameng
Beneficiary Name
Sl.No
Chabu Rojo
1
Kagi Rojo
2
Atung Rojo
3
Benn Rojo
4
Kumar Rojo
5
Kandu Rojo
6
Tadung Rojo
7
Niglar Rojo
8
Praye Rojo
9
Kachi Rojo
10
Chabing Rojo
11
Passang Rojo
12
Lendu Rojo
13
Nikam Rojo
14
Gelung Rojo
15
Roman Rojo
16
Kage Rogo
17
Sarma Rojo
18
Lama Rojo
19
Tagum Rojo
20
District: East Kameng
Beneficiary Name
Sl.No
Byai Miji
1
Risu Miji
2
Nicho Miji
3
Debu Miji
4
Kagro Miji
5
Taffi Miji
6
Sanam Miji
7
Mutung Miji
8
Tonglai Miji
9
Dongio Miji
10
Banman Miji
11
Kadai Miji
12
Krishna Miji
13
Nimugai Miji
14
Abia Miji
15
Tsering Miji
16

03090203
03090466
030900097
03090489
Circle: LADA
Sl.No. of Module
03090220
03090701
03090413
03090059
02090360
02090416
02090434
03090167
03090334
03090182
03090252
03090198
02090508
03090168
03090172
03090343
02090511
03090070
02090420
03090081
Circle: LADA
Sl.No. of Module
02090292
04090474
02090264
03090391
03090239
03090254
03090364
03090380
02090378
03090250
03090372
03090330
03090346
03090180
03090183
03090370

17093
17360
17455
17614
Sl.No. of Battery
17371
17030
17664
17048
17173
17616
17141
17427
17556
17142
17118
17106
17503
17068
17223
17077
17667
17600
17065
17523
Sl.No. of Battery
17211
17613
17516
17088
17461
17583
17048
17155
17653
17471
17410
17447
17171
17393
17364
17497

20-05-2009
20-05-2009
20-05-2009
20-05-2009
Village: Rojo
Date of Installation
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
23-05-2009
Village: Drakshi
Date of Installation
21-05-2009
21-05-2009
21-05-2009
21-05-2009
21-05-2009
21-05-2009
21-05-2009
21-05-2009
21-05-2009
21-05-2009
21-05-2009
21-05-2009
21-05-2009
21-05-2009
21-05-2009
21-05-2009

<!-- page 26 -->

Hyangcham Miji
17
Chogmu Miji
18
District: East Kameng
Beneficiary Name
Sl.No
Agra Kojo
1
Chinchi Kojo
2
Jang Kojo
3
Lamo Kojo
4
Chat Kojo
5
Megung Kojo
6
Mechung Kojo
7
Wapong Kojo
8
Jab Kojo
9
Chabing Kojo
10
Dungdak Kojo
11
Tame Kojo
12
Kai Kojo
13
Senchung Kojo
14
Yangtung Kojo
15
Sengi Kojo
16
Kage Kojo
17
District: East Kameng
Beneficiary Name
Sl.No
Nok Phroik
1
Lag Phroik
2
Tangtang Kumjuju
3
Beru Kumjuju
4
Dai Kumjuju
5
Baju Kumjuju
6
Ajeai Miju
7
Sonam Phroik
8
District: East Kameng
Beneficiary Name
Sl.No
Tapung Jokhio
1
Karbia Jokhio
2
Warbing Jokhio
3
Tara Jokhio
4
Tanggso Jokhio
5
Tayam Jokhio
6
Acho Jokhio
7
Chock Jokhio
8
Changdang Jokhio
9
Low Jokhio
10
Todung Jokhio
11

03090371
02090487
Circle: LADA
Sl.No. of Module
03090267
03090283
03090287
0309092
03090208
03090228
03090182
02090202
03090325
03090365
03090159
03090662
03090184
03090254
03090355
02090377
03090290
Circle: LADA
Sl.No. of Module
04090216
04090174
04090516
04090105
04090628
04090223
04090956
04090070
Circle: Khenewa
Sl.No. of Module
02090386
02090373
02090401
03090335
03090104
02090322
02090223
02090447
02090403
02090402
02090335

17143
17400
Sl.No. of Battery
17094
17615
17603
16995
16996
17042
17192
17633
17619
17174
17452
17493
17359
17007
17006
17465
17041
Sl.No. of Battery
19722
19971
19597
19663
19656
19903
19556
19205
Sl.No. of Battery
17036
17092
17661
17074
17117
17561
17447
17487
17771
17055
17027

21-05-2009
21-05-2009
Village: Kojo
Date of Installation
22-05-2009
22-05-2009
22-05-2009
22-05-2009
22-05-2009
22-05-2009
22-05-2009
22-05-2009
22-05-2009
22-05-2009
22-05-2009
22-05-2009
22-05-2009
22-05-2009
22-05-2009
22-05-2009
22-05-2009
Village: Jarkem
Date of Installation
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
Village: Jokhio
Date of Installation
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009

<!-- page 27 -->

Sardo Jokhio
12
Sangra Jokhio
13
Kate Jokhio
14
How Jokhio
15
Deno Jokhio
16
Bida Jokhio
17
Papo Jokhio
18
Yaka Jokhio
19
Mero Jokhio
20
Tabing Jokhio
21
Yada Jokhio
22
Khelong Jokhio
23
Sana Jokhio
24
Sisu Jokhio
25
Kilo Jokhio
26
Baro Jokhio
27
Taley Jokhio
28
District: East Kameng
Beneficiary Name
Sl.No
Tachi Pardy Solluy
1
Samty Iardy Solluy
2
Mechi Pardy Solluy
3
Lama Pardy Solluy
4
Pardung Solluy
5
Karcha Solluy
6
District: East Kameng
Beneficiary Name
Sl.No
Shoh Yacho
1
Sung Yacho
2
Nisam Yacho
3
Sinkey Yacho
4
Bakha Yacho
5
Sarmo Yacho
6
Kasung Yacho
7
Tabing Yacho
8
Cho Yacho
9
Kyakung Yacho
10
Chey Yacho
11
Soy Yacho
12
District: East Kameng
Beneficiary Name
Sl.No
Parwa Sangbia
1
Marmo Sangbia
2
Mekam Sangbia
3

02090455
02090448
02090449
02090271
020990287
02090499
02090284
02090419
02090378
04090498
02090459
02090426
03090179
03090046
04090355
04090390
04090253
Circle: Khenewa
Sl.No. of Module
04090007
03090995
04090234
04090234
04090147
04090215
Circle: Khenewa
Sl.No. of Module
04090268
04090265
04090109
04090419
04090392
04090427
04090427
04090483
04090496
04090495
04090266
09090271
Circle: Khenewa
Sl.No. of Module
04090227
04090421
04090409

17725
17548
17655
17571
17584
17103
17242
17136
17524
17158
17698
17079
17246
175526
19116
17443
19217
Sl.No. of Battery
19502
19907
19656
19655
19917
19777
Sl.No. of Battery
19760
19725
19681
19781
19841
19754
19679
17459
19928
19099
19478
19568
Sl.No. of Battery
17947
19784
19437

05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
05-05-2009
Village: Pardung Solung
Date of Installation
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
Village: Yacho
Date of Installation
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
Village: Sangbia Camp
Date of Installation
05-08-2009
05-08-2009
05-08-2009

<!-- page 28 -->

Kyame Sangbia
4
Meku Sangbia
5
Jarman Sangbia
6
Jaapo Sangbia
7
Badai Sangbia
8
Dadar Sangbia
9
Raju Sangbia
10
Karu sangbia
11
Kardu Sangbia
12
Kaku Sngbia
13
Kyhyaprany Sangbia
14
Niyu Sangbia
15
Adung Sangbia
16
Appo Sangbia
17
Niklar Sangbia
18
Marku Sangbia
19
Nikam Sangbia
20
Maku Sangbia
21
Niya Sangbia
22
District: East Kameng
Beneficiary Name
Sl.No
Gyamin Pangin
1
Rasam Sefew
2
Bale Sefew
3
Sardo Dolo
4
Kongo Dolo
5
Mema Dolo
6
District: East Kameng
Beneficiary Name
Sl.No
Kyakhio Raje
1
Sedap Raje
2
Kutdo Raje
3
Pachi Raje
4
Yadang Raje
5
Babing Raje
6
Bale Raje
7
Sangke Raje
8
Damchung Raje
9
Tamro Raje
10
Nickchi Raje
11
Koming Raje
12
Kangdak Raje
13
Loma Raje
14
Yapo Raje
15

04090566
04090271
04090026
03091043
04090278
04090180
04090086
04090087
03090037
03091027
03090996
03091042
03091052
03090970
03091037
03091013
03091012
03091026
03091028
Circle: Khenewa
Sl.No. of Module
04090098
04090419
04090321
04090514
04091546
04090506
Circle: Khenewa
Sl.No. of Module
04090220
04090093
04090098
03090182
03090220
02090416
03090275
03090306
03090237
03090139
03090231
03090283
03090368
03090354
03090200

19773
19782
19706
19504
19897
19899
19855
19855
19796
19548
19442
19823
19480
19691
19570
19856
19467
19437
19727
Sl.No. of Battery
19455
19503
19696
19705
19778
19787
Sl.No. of Battery
19449
19794
19455
17508
17555
17234
17157
17061
17158
17181
17510
17250
17760
17404
17240

05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
05-08-2009
Village: Sefew
Date of Installation
05-02-2009
05-02-2009
05-02-2009
05-02-2009
05-02-2009
05-02-2009
Village: Raje
Date of Installation
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009

<!-- page 29 -->

Mema Raje
16
Fasang Raje
17
District: East Kameng
Beneficiary Name
Sl.No
Aley Wallong
1
Tungdary Wallong
2
Adang Wallong
3
Laa Wallong
4
Sungya Wallong
5
Akey Wallong
6
Lalu Wallong
7
Nisam Wallong
8
Sang Wallong
9
Babung Wallong
10
Kati wallong
11
Tesam Wallong
12
Feshi Wallong
13
Kajab Wallong
14
Pengsa Wallong
15
Kojo Wallong
16
Maden Wallong
17
Chaku Wallong
18
Adam Wallong
19
Damsay Wallong
20
Dachuy Wallong
21
Apik Wallong
22
Leme Wallong
23
Darsha Wallong
24
Tumbing Wallong
25
District: East Kameng
Beneficiary Name
Sl.No
Lantung Warrom
1
Kopung Warrom
2
Papi Warrom
3
Mepur Warrom
4
Aro Warrom
5
Aggul Warrom
6
Nido Warrom
7
District: East Kameng
Beneficiary Name
Sl.No
Reya Wagyung
1
Colung Wagyung
2
Chamgung Wagyung
3
Todung Wagyung
4

03090303
03090396
Circle: Khenewa
Sl.No. of Module
04090388
04090389
04090266
04090342
04090320
04090243
04090201
04090202
04090233
04090552
04090296
04090292
04090401
04090508
04090486
04090487
04090420
04090472
04090332
04090433
04090319
04090272
04090440
04090341
04090351
Circle: Khenewa
Sl.No. of Module
04090305
04090127
04090053
04090317
04090410
04090029
04090410
Circle: Khenewa
Sl.No. of Module
02090289
02090273
02090247
02090242

17456
17524
Sl.No. of Battery
19568
19929
19792
19924
19834
19906
19902
199552
19514
19513
19560
19558
19843
19670
19430
19878
19608
19509
19553
19911
19895
19456
19633
19885
19543
Sl.No. of Battery
19848
19545
19589
19491
19816
19722
19729
Sl.No. of Battery
17600
17109
17222
17567

30-04-2009
30-04-2009
Village: Wallong
Date of Installation
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
30-04-2009
Village: Warrom
Date of Installation
05-02-2009
05-02-2009
05-02-2009
05-02-2009
05-02-2009
05-02-2009
05-02-2009
Village: Waggyung
Date of Installation
05-01-2009
05-01-2009
05-01-2009
05-01-2009

<!-- page 30 -->

Sase Wagyung
5
Pungi Wagyung
6
Mume Wagyung
7
Atta Wagyung
8
Mebi Wagyung
9
Along Wagyung
10
Khebing Wagyung
11
Dungso Wagyung
12
KarbiaWagyung
13
Tasu Wagyung
14
District: East Kameng
Beneficiary Name
Sl.No
Sanja Halley
1
Messum Halley
2
Maro Seji
3
Danki Lega
4
Auo Seji
5
Yapia Halley
6
Yabuk Halley
7
Tambanag Lega
8
Bacho Mingte
9
Pacha Lega
10
Kacho Lega
11
Ago Lega
12
Nima Halley
13
Chukap Seji
14
Akairu Lega
15
Khichi Seji
16
Risung Kingte
17
Duba Leja
18
Acho Leja
19
District: East Kameng
Sl.No
1
2
3
4
5
6
7
8
9
10

Beneficiary Name
Tame Kesse Bagang
Hani Gagang
Sai Bagang
Tassap Bagang
Taging Bagang
Yaging Bagang
Yama Bagang
Ropo Bagang
Yalo Bagang
Chapo Bagang

03090061
03090160
03090340
03090302
03090045
03090061
03090421
03090405
03090398
02090106
Circle: Chayeng
Tajo
Sl.No. of Module
03090257
03090199
03090145
03090343
03090386
03090515
03090225
03090345
03090366
02090545
03090360
03090087
030900074
03090118
03090244
03090232
03090356
03090408
03090049
Circle: Chayeng
Tajo
Sl.No. of Module
03090058
03090064
03090055
02090570
03090090
03090165
02090405
02090435
02090280
02090282

17524
17073
17419
17142
17413
17350
17404
17213
17049
17520

05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
05-01-2009
Village: Tamak Sollung

Sl.No. of Battery
17428
16999
17607
17543
17453
17061
10986
16990

Date of Installation
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
Village: Kesse Bagang

17221
17030
17067
17205
17518
17514
17164
17182
17642
17068

Sl.No. of Battery
17417
17426
17664
16996
17014
17029
17368
17016
17468
17027

Date of Installation
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009

<!-- page 31 -->

Takia Bagang
11
Talo Bagang
12
Tatop Bagang
13
Apo Bagang
14
Takam Bagang
15
Bhage Bagang
16
Nima Bagang
17
Yalin Bagang
18
Chongchang Bagang
19
Sake Bagang
20
Damo Bagang
21
Taniang Bagang
22
Seme Bagang
23
Mulang Bagang
24
Soge Bagang
25
District: East Kameng
Beneficiary Name
Sl.No
Tapik Wanu
1
Yasha Wanu
2
Tali Wanu
3
Atti Wanu
4
Seku Wanu
5
Medak Wanu
6
Ropo Soja
7
Yudia Soja
8
Meema Biaap
9
Atta Soja
10
Samej Wanu
11
Tanam Waye
12
Niya Waye
13
Takoj Wanu
14
Nima Waye
15
Yadi Sajo
16
Tayu Wanu
17
Siyang Soja
18
Blani Waye
19
Magang Wanu
20
Siyang Binap
21
Tadang Soja
22
Sama Wanu
23
Lego Soju
24
Mekab Binap
25
District: East Kameng

03090214
03090076
02090396
02090513
03090122
020904464
02090507
03090124
03090106
03090177
02090267
02090472
04090-0017
0409-0013
03090277
Circle: Chayeng
Tajo
Sl.No. of Module
020900045
02090409
02090493
02090394
02090164
02090287
02090103
03090223
03090238
03090292
02090307
02090055
03090516
03090090
03090417
02090078
02090086
03090407
02090367
03090493
03090462
03090513
02090058
020900069
02090069
Circle: Chayeng
Tajo

17377
171315
17198
17082
17509
16888
17587
17494
17388
17022
17464
17135
17299
17428
16989

06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
Village: Jattom Sollung

Sl.No. of Battery
17666
17083
17418
17427
17665
17407
17017
17369
17028
17378
17191
16989
17873
17017
17495
17588
17389
17465
17136
17089
17167
17213
17165
17991
17402

Date of Installation
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
Village: Kamke

<!-- page 32 -->

Beneficiary Name
Sl.No
Chow Kamke
1
Yapung Kamke
2
Kanya Kamke
3
Meaming Kangfo
4
Tadang Yangfo
5
Yamo Yangfo
6
Ropo Yangfo
7
Nibu Yangfo
8
Koi Yangfo
9
Taniang Kamke
10
Sanpo Tungi
11
Mepi Tungi
12
Richi Tungi
13
Yano Yangfo
14
Maung Tayam
15
Eka Tayum
16
Afia Tayum
17
District: East Kameng
Beneficiary Name
Sl.No
Papu Tassar
1
Yaban Tassar
2
Chaling Tassar
3
Kyodoh Tassar
4
District: East Kameng
Sl.No
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17

Beneficiary Name
Taram Tajo
Boyang Tajo
Nima Tajo
Yadak Tajo
Langune Tajo
Tayang Tajo
Japo Tajo
Madung Tajo
Natung Tajo
Ntabi Tajo
Laning Tajo
Tama Tajo
Senia Tajo
Raje Tajo
Kara Tajo
Pungsi Tajo
Kati Tajo

Sl.No. of Module
02090345
02090408
02090371
02090229
02090278
03090396
02090361
02090345
02090360
02090225
02090118
02090244
02090232
02090356
02090049
02090087
02090074
Circle: Chayeng
Tajo
Sl.No. of Module
03090078
03090086
02090407
02090417
Circle: Chayeng
Tajo
Sl.No. of Module
03090289
03090327
03090327
03090322
03090169
03090191
03090207
03090255
03090236
03090419
02090406
02090291
03090120
03090313
03090085
03090131
030900073

Sl.No. of Battery
17212
17009
17024
17082
17235
17222
17607
17045
17214
17361
17024
17059
17018
17499
17368
17502
17484

Date of Installation
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
Village: Paje Tassar

Sl.No. of Battery
17586
17252
17537
17013

Date of Installation
07-04-2009
07-04-2009
07-04-2009
07-04-2009
Village: Tajo

Sl.No. of Battery
17219
17474
17276

Date of Installation
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009

17018
17244
17015
17258
17200
17139
17642
17578
17387
17191
17055
17031
17121

<!-- page 33 -->

Dolung Tajo
18
Kojam Tajo
19
Dodang Tajo
20
Tawe Tajo
21
Yamo Tajo
22
Taso
23
District: East Kameng
Beneficiary Name
Sl.No
Kaming Yangfo
1
Dolok Yangfo
2
Senia Yangfo
3
Doba Yangfo
4
Kodak Yangfo
5
Taje Yangfo
6
Kaya Yangfo
7
Takik Yangfo
8
Sapin Yangfo
9
Tasha Yangfo
10
District: East Kameng
Beneficiary Name
Sl.No
Karo Sollung
1
Meda Halle
2
Takia Sollung
3
Raye Sollung
4
Setu Sollung
5
Yachi Soja
6
Siyang Winte
7
District: East Kameng
Beneficiary Name
Sl.No
Biyami Tajo
1
District: East Kameng
Sl.No
1
2
3
4
5
6
7
8
9
10

Beneficiary Name
Meping Binop
Kakap Saji
Sangte Saji
Tacho Saji
Yangam Binop
Appa Wanu
Meta Binop
Yanu Saji
Logo Binop
Kayasi Binop

03090064
03090224
03090318
03090420
03090286
03090254
Circle: Chayeng
Tajo
Sl.No. of Module
02090199
02090145
02090349
02090386
02090375
02090248
02090082
02090246
02090323
02090257
Circle: Chayeng
Tajo
Sl.No. of Module
02090073
02090224
02090131
02090085
02090131
02090064
02090228
Circle: Chayeng
Tajo
Sl.No. of Module
02090277
Circle: Chayeng
Tajo
Sl.No. of Module
03090147
03090486
03090263
03090224
02090153
03090189
03090147
03090352
03090065
03090105

17588
17049
17620
17628
17267
17149

11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
Village: Tamsang Yangfo

Sl.No. of Battery
17011
17249
17431
17338
17526
17015
17019
17587
17253
17538

Date of Installation
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
Village: Rayak Yangfo

Sl.No. of Battery
17122
17050
17192
17056
17052
17559
17053

Date of Installation
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
10-04-2009
Village: Dambua Tajo

Sl.No. of Battery
17164

Date of Installation
11-04-2009
Village: Tagampu Sollung

Sl.No. of Battery
17475
17566
17145
17394
17384
17096
17635
16993
17092
17392

Date of Installation
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009
08-04-2009

<!-- page 34 -->

Kojap Saji
11
District: East Kameng
Beneficiary Name
Sl.No
Chachi Yangfo
1
Tajik Yangfo
2
Taka Yangfo
3
Taniang Yangfo
4
Bida Yangfo
5
Yama Yangfo
6
Challing Yangfo
7
Khanu Yangfo
8
Niya Yangfo
9
Yananh Yangfo
10
Mina Yangfo
11
Samo Yangfo
12
Takhia Yangfo
13
Yakap Yangfo
14
Tajung Yangfo
15
Yamo Yangfo
16
Yase Yangfo
17
District: East Kameng
Beneficiary Name
Sl.No
Cahbing Kapik
1
Taliak Kapik
2
Lami Kapik
3
Taja Kapik
4
Kapa Kapik
5
Lalu Kapik
6
Bini Sollung
7
Sama kapik
8
Tabia Kapik
9
Mayang Kapik
10
Takhang Soja
11
Anang Seji
12
Seko Kapik
13
Yapak Seji
14
District: East Kameng
Sl.No
1
2
3
4

Beneficiary Name
Karo Soja
Dadang Cholla
Chakap Soja
Sama Soja

03090163
Circle: Chayeng
Tajo
Sl.No. of Module
03090246
03090287
03090103
03090082
03090367
03090051
02090233
02090238
03090258
02090393
03090409
03090394
03090164
03090045
03090307
03090248
03090323
Circle: Chayeng
Tajo
Sl.No. of Module
03090371
03090229
03090139
03090280
03090176
03090338
0409-0227
03090382
03090171
03090219
03090299
03090373
03090115
02090442
Circle: Chayeng
Tajo
Sl.No. of Module
03090378
03090379
03090133
03090104

17251

08-04-2009
Village: Tarawa Yangfo

Sl.No. of Battery
17399
17248
17430
17277
17010
17339
17525
17360
17044
17044
17213
17367
17014
17023
17606
17081
17234

Date of Installation
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
09-04-2009
Village: Kapik Sollung

Sl.No. of Battery
17134
16987
17443
17800
17179
17520
19698
17361
17162
17247
17700
17618
17204
17591

Date of Installation
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
06-04-2009
Village: SangchuSollung

Sl.No. of Battery
17194
17160
17397
17056

Date of Installation
05-04-2009
05-04-2009
05-04-2009
05-04-2009

<!-- page 35 -->

Bangram Soja
5
Leko Soja
6
Daba Soja
7
Dha Soja
8
Singke Soja
9
Taram Soja
10
Yaro Soja
11
Kyachi Yakli
12
Yapak Wingte
13
Siyam Seji
14
Gam Kap Soja
15
Sisu Soja
16
Maring Soja
17
Lebe Soja
18
Talik Soja
19
Rai Soja
20
Tasuk Soja
21
Rai Soja
22
Takia Soja
23
Dambing Soja
24
Talik Soja
25
District: East Kameng
Sl.No
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19

Beneficiary Name
Damsap Tajo
Attang Tajo
Koma Tajo
Sangte Tajo
D. Tajo
Karo Tajo
Tajik Tajo
Taruk Tajo
Seme Tajo
Lata Tajo
Riman Bagang
Chungni Tajo
Rayo Bagang
Karu Tajo
Oma Tajo
Nela Tajo
Medak Tajo
Cheku Tajo
D. Tajo

03090270
03090142
03090358
03090138
02090443
02090384
02090424
02090387
02090589
02090226
02090376
02090464
02090270
03090314
03090514
03090257
03090399
02090483
02090267
03090042
03090315
Circle: Chayeng
Tajo
Sl.No. of Module
02090162
02090408
02090232
02090278
02090266
02090494
02090452
02090432
02090309
03090304
02090221
02090249
03090113
03090114
03090060
03090369
03090048
03090068
0309-0115

17436
17455
17274
17161
17540
17541
17176
17436
17433
17033
17132
17128
17382
17592
17038
17496
17889
17298
17020
17035
17442

05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
05-04-2009
Village: Langruk Tajo

Sl.No. of Battery
17157
17620
17628
17269
17149
17444
16987
17134
17642
17389
17442
17161
17596
17596
17247
17218
17218
17189
19518

Date of Installation
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009
11-04-2009

<!-- page 36 -->

BENEFICIARY LIST OF KURUNG KUMEY DISTRICT
District: Kurung Kumey
Sl.No

Beneficiary Name

Lokam Doji
1
Gara Kame
2
Gora Babey
3
Lokam Takap
4
Gora Tapa
5
District: Kurung Kumey
Sl.No

Beneficiary Name

Lokam Tacho
1
Lokam Yami
2
Lokam Takuk
3
Dare Yari
4
Lokam Yamuk
5
Damin Chetung
6
Bahi Tahar
7
Yamra Jajik
8
Yamra Kare
9
Gora Tado
10
Dare Tajong
11
District: Kurung Kumey
Sl.No
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18

Beneficiary Name
Chate Tamin
Chate Yapang
Chate Yakio
Chate Tado
Huri Bonghi
Lank Tamak
Chate Tarap
Chate Kami
Chate Tayang
Chate Tatuk
Chate Tagar
Bialuk Dana
Kodu Takap
Chate Tapum
Chate Tajik
Hiri Tato
Hiri Tamar
Chate Yajik

Circle: Damin
Sl.No. of Module

Village: Bamo
Sl.No. of Battery

Date of Installation

18632
18658
18792
18802
18576

04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
Village: Chaiya

Sl.No. of Battery

Date of Installation

16113
18436
15234
18515
18694
15793
18717
18641
18525
16157
15843

06.05.2009
26.05.2009
06.05.2009
06.05.2009
26.05.2009
26.05.2009
26.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
Village: Chate

Sl.No. of Module

Sl.No. of Battery

Date of Installation

MM09036134
MM09029142
MM09028075
MM09035128
MM09035047
MM09022036
MM09032043
MM09032051
MM09032023
MM09032014
MM09032039
MM09015035
MM09036014
MM09035150
MM09034058
MM09030901
MM09035011
MM09016071

18421
16036
16033
18384
15579
18311
18401
15783
16025
16169
15791
16182
16205
16103
18379
15159
16097
16099

30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
01.05.2009
01.05.2009
01.05.2009
01.05.2009
01.05.2009
01.05.2009

MM09034087
MM09034115
MM09035038
MM09031072
MM09031068
Circle: Damin
Sl.No. of Module
MM09031128
MM09035033
MM09035109
MM09035090
MM09035082
MM09035083
MM09028091
MM09034066
MM09030076
MM09034080
MM09031062
Circle: Damin

<!-- page 37 -->

Hari Tamang
19
District: Kurung Kumey

MM09035100
Circle: Damin

18761

01.05.2009
Village: Chulla
Date of Installation

Beneficiary Name

Sl.No. of Module

Sl.No. of Battery

Hiniyum Tadap
1
Hium Tatup
2
Himu Tado
3
Himu Tasuk
4
Himu Taha
5
Himu Takang
6
Himu Tatang
7
Himu Kami
8
Himu Roi
9
Himu Kame
10
Himu Chape
11
Himu Tamia
12
Himu Tato
13
Himu Tabin
14
Himu Yapi
15
Himu Sika
16
Himu Epa
17
Himu Rigtu
18
Himu Yara
19
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09003038
MM09006042
MM09031039
MM09030133
MM09030137
MM09030138
MM09035131
MM09002070
MM09036132
MM09032029
MM09035079
MM09035132
MM09035139
MM09035111
MM09036010
MM09024019
MM09024043
MM09021051
MM09024021
Circle: Damin
Sl.No. of Module

18708
18799
18755
18820
18561
18674
18654
18733
18748
18596
16058
18666
18698
18759
18460
18398
18041
18125
18048

Bamo Kame
1
Bagik Tagung
2
Gore Tayu
3
Damin Tochog
4
Lokam Takia
5
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09036047
MM09028101
MM09021031
MM09016015
MM09029100
Circle: Damin
Sl.No. of Module

Sl.No. of Battery

MM09023083
MM09017097
MM09020125
MM0901699
MM09020071
MM09036031
MM09036027
MM09035127
MM09035138
MM09035130
MM09031111
MM09031123

18787
18618
18768
18625
18656
18614
18713
18777
18745
15566
18670
18498

Sl.No

1
2
3
4
5
6
7
8
9
10
11
12

Lokam Chai
Lokam Yabang
Lokam Tapang
Lokam Nandu
Lokam Tachung
Lokam Taha
Lokam Tasuk
Lokam Yamak
Lokam Yania
Lokam Hinda
Lokam Yagin
Lokam Joha

Sl.No. of Battery
18716
18597
18786
18400
18767

05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
Village: Digok
Date of Installation
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
Village: Dubupa
Date of Installation
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009

<!-- page 38 -->

Lokam Takok
13
Lokam Tashi
14
Sale Yagah
15
Lokam Dava
16
Lokam Loram
17
Lokam Epo
18
Lokam Chupar
19
Lokam Yering
20
Lokam Tubing
21
Loke Yaki
22
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09031124
MM09031066
MM09022026
MM09031086
MM09034101
MM09021018
MM09031090
MM09023046
MM09019001
MM09019059
Circle: Damin
Sl.No. of Module

Bano Nyayu
1
Bamo Takam
2
Bamo Bui
3
Bamo Tasi
4
Bamo Tabin
5
Bamo Taning
6
Lore Tatak
7
Lore Talung
8
Lore Tanu
9
Bedak Tamar
10
Bedak Tato
11
Bamo Yajik
12
Bamo Yama
13
Bamo Tatuk
14
Bengia Yatong
15
Bamo Yapang
16
Lokam Tama
17
Bama Tapo
18
Bamo Jeta
19
Badak Akuy
20
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09033097
MM09030087
MM09028072
MM09027066
MM09028022
MM09028017
MM09029133
MM09024036
MM09017037
MM09027067
MM09033069
MM09028044
MM09033080
MM09033081
MM09033113
MM09022038
MM09035056
MM09031007
MM09021080
MM09034043
Circle: Damin
Sl.No. of Module

Lokam Yanang
1
Lokam Tagi
2
Lokam Tali
3
Tongyam Bonghi
4
Bamo Tagar
5
Bagik Yakiak
6
Lokam Yaju
7
Gora Tado
8
Gora Tamar
9
District: Kurung Kumey

MM09036021
MM09035101
MM09030121
MM09034099
MM09030122
MM09030119
MM09033002
MM09016043
MM09032018
Circle: Damin

18800
18709
15155
16092
18485
18065
18052
17986
17869
17989
Sl.No. of Battery
18784
18491
18648
18821
18779
18823
18797
18734
18744
18532
18631
18606
18707
18822
18659
18624
18827
16121
16185
18336
Sl.No. of Battery
18623
18516
18604
18375
18675
18788
18663
18728
18652

03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
Village: Fuba
Date of Installation
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
Village: Goa
Date of Installation
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
Village: Huri

<!-- page 39 -->

Beneficiary Name

Sl.No. of Module

Sl.No. of Battery

Date of Installation

Huri Tanak
1
Huri Yogam
2
Huri Tagar
3
Tarba Sagas
4
Huri Tasap
5
Huri Eka
6
Huri Chiydu
7
Huri sayte
8
Huri Yano
9
Huri Kapa
10
Huri Yapny
11
Huri Chygbo
12
Chaitak Atai
13
Huri Pacha
14
Huri Kachi
15
Huri Tato
16
Huri Tamde
17
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09023028
MM09027006
MM09029051
MM09029053
MM09016053
MM09021009
MM09022060
MM09029053
MM09030067
MM09021053
MM09029111
MM09016030
MM09016017
MM09027010
MM09031026
MM09033127
MM09033116
Circle: Damin
Sl.No. of Module

16071
16271
16086
18317
16090
18310
18513
18643
18268
17943
18333
18397
18440
18466
18378
18315
18370

06.05.2009
06.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
Village: Jali
Date of Installation

Loakm Yaru
1
Lokam Tahik
2
Lokam Tasuk
3
Lokam Tacho
4
Lokam Tami
5
Lokam Chapi
6
Lokam Taghik
7
Lokam Lota
8
Lokam Roi
9
Lokam Chege
10
Lokam Tara
11
Yamra Yai
12
Yumra Yamale
13
Tang Tahar
14
Ymra Yakam
15
Yumra Kiopit
16
Yumra Boughi
17
Yumra Yamang
18
Yumra Kaku
19
Yumra Yachi
20
Yumra Yapi
21
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09029071
MM09024051
MM09017027
MM09024044
MM09056152
MM09056190
MM09056160
MM09030074
MM09031020
MM09017022
MM09021060
MM09030010
MM09033058
MM09030068
MM09027019
MM09024040
MM09030060
MM09028102
MM09028099
MM09020059
MM09033147
Circle: Damin
Sl.No. of Module

Sl.No. of Battery

06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
Village: Kopila
Date of Installation

Tolum Takia

MM09034039

16198

30.04.2009

Sl.No

1

Sl.No. of Battery
18534
19850
16239
18607
18531
18542
16122
16046
15573
18478
18736
15992
18553
18481
18696
16064
18642
18668
15699
16039
16279

<!-- page 40 -->

Tolum Tala
2
Tarba Tado
3
Tarba Takap
4
Tolum Sopin
5
Tarba Libo
6
Tolum Bai
7
Tolum Tasap
8
Tolum Tana
9
Tolum Tame
10
Tolum Takap
11
Tolum Koyy
12
Tolum Rosy
13
Tolum Tasuk
14
Tarba Tatung
15
Tolum Tasar
16
Tafu Ajad
17
Tafu Effer
18
Tarpa Ehoro
19
Chilak Hinde
20
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09033021
MM09028027
MM09010042
MM09012020
MM09034084
MM09031081
MM09019006
MM09017052
MM09020108
MM09019113
MM09019011
MM09030120
MM09035102
MM09016047
MM09034045
MM09031030
MM09031002
MM09030141
MM09030142
Circle: Damin
Sl.No. of Module

Huri Kaha
1
Huri Kanya
2
Huri Tagar
3
Huri Tabin
4
Huri Tasap
5
Huri Tapang
6
Huri Logu
7
Huri Nai
8
Huri Tagik
9
Huri Yarang
10
Bangia Kame
11
Huri Tanamg
12
Huri Achung
13
Huri Chiji
14
Huri Charu
15
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09015010
MM09030125
MM09030112
MM09031019
MM09016049
MM09035012
MM09030147
MM09032001
MM09022031
MM09016082
MM09016072
MM09035084
MM09033087
MM09033100
MM09033077
Circle: Damin
Sl.No. of Module

Sl.No. of Battery

30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
Village: Machang
Date of Installation

MM09034013
MM09035099
MM09002039
MM09022033
MM09031076
MM09035067

18338
15136
18280
16147
16089
19742

01.05.2009
01.05.2009
01.05.2009
01.05.2009
01.05.2009
01.05.2009

1
2
3
4
5
6

Tofu Tageng
Kadu Chadik
Chingtak Yanurg
Kadu Chang
Kadu Tara
Chintak Tabing

15625
18449
16054
15605
16221
16128
16229
15828
16211
16202
18470
15341
16026
18410
15700
18190
17901
17857
18229
Sl.No. of Battery
15989
18507
16223
16075
18462
16216
16060
15517
15565
10104
16040
16269
18201
17867
18060

30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
01.05.2009
01.05.2009
01.05.2009
01.05.2009
Village: Loak
Date of Installation

<!-- page 41 -->

Lokam Tapo
7
Safey Tami
8
Ruba Tagar
9
Ruba Tamar
10
Tolum Tatung
11
Kadu Takit
12
Ruba Hasi
13
Sale Chape
14
Chintat Tatak
15
Sali Kaku
16
Ruba Tagung
17
Ruba Yake
18
Tolum Tatung
19
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09034038
MM09030063
MM09031102
MM09016019
MM09015042
MM09027012
MM09029037
MM09015047
MM09035136
MM09033109
MM09027084
MM09016066
MM09030134
Circle: Damin
Sl.No. of Module

Lokam Takap
1
Chakpu Tabit
2
Chakpu Roi
3
Chakpu Eha
4
Chakpu Taghik
5
Chakpu Takap
6
Chakpu Hachai
7
Chakpu Kame
8
Chakpu Tachu
9
Chakpu Epo
10
Chakpu Naui
11
Chakpu Sagme
12
Chakpu Yasam
13
Chakpu Eka
14
Chakpu Yeta
15
Lokam Keta
16
Chakpu Tikang
17
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09036064
MM09035106
MM09036061
MM09034082
MM09036129
MM09036103
MM09036078
MM09036085
MM09035145
MM09035093
MM09031069
MM09034113
MM09019003
MM09022006
MM09022005
MM09006066
MM09005048
Circle: Damin
Sl.No. of Module

Sl.No. of Battery

03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
Village: Moruk
Date of Installation

MM09035075
MM09016046
MM09014028
MM09014004
MM09013093
MM09014100
MM09031094
MM09027051
MM09033007
MM09033001

15546
16132
15182
15729
16181
16270
18449
18828
15735
18523

01.05.2009
01.05.2009
01.05.2009
01.05.2009
01.05.2009
01.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009

1
2
3
4
5
6
7
8
9
10

Lokam Mangle
Lokam Bai
Saje Tokfia
Saje Tawia
Waruk Yapang
Woruk Anak
Lokam Taha
Lokam Tamang
Lokam Tapit
Waru Yarik

18307
16005
16031
18711
18798
18682
15788
18634
18826
16146
18621
18724
18795
Sl.No. of Battery
18814
18673
18710
18651
18640
18594
18772
18635
18729
18646
18638
18602
18293
18318
18298
18369
18158

01.05.2009
01.05.2009
01.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
Village: Mariangha
Date of Installation

<!-- page 42 -->

Lokam Yabang
11
Lokam Nai
12
Lokam Yayap
13
Lokam Haji
14
Waru Bache
15
Waru Tama
16
Chantde Yapang
17
Chakpu Tamar
18
Walu Sape
19
Waru Simin
20
Loka Tagas
21
Lokam Weffe
22
Chintak Langche
23
Loka Yukan
24
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09031049
MM09030002
MM09028086
MM09007089
MM09021041
MM09028081
MM09031180
MM09036555
MM09030083
MM09030127
MM09030101
MM09030126
MM09033123
MM09033148
Circle: Damin
Sl.No. of Module

Lokam Tapok
1
Lokam Tasin
2
Lokam Potem
3
Lokam Tado
4
Lokam Tariak
5
Lokam Koyu
6
Bamang Kaha
7
Bamang Tama
8
Lokam Tatu
9
Lokam Tabong
10
Lokam Takar
11
Dake Kame
12
Lokam Takap
13
Lokam Taha
14
Lokam Talit
15
Lokam Koyu
16
Lore Kai
17
Yija Yakio
18
Chintak Tagung
19
Bamung Yakio
20
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09035118
MM09035104
MM09035119
MM09030059
MM09033084
MM09027081
MM09034074
MM09031117
MM09034020
MM09035064
MM09035061
MM09035017
MM09016050
MM09035062
MM09031099
MM09031115
MM09031055
MM09030003
MM09024015
MM09005090
Circle: Damin
Sl.No. of Module

Sl.No. of Battery

04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
Village: Piipu
Date of Installation

MM09036042
MM09015048
MM09025059
MM09024055
MM09027001
MM09029148

18319
18339
16231
18484
18773
16068

03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009

1
2
3
4
5
6

Lokam Tapit
Lokam Tagi
Chakpu Taying
Lokam Taduk
Lokam Takap
Lokam Tado

18650
18622
18811
18778
18637
18741
18718
18660
18205
17889
18212
18062
18368
17877
Sl.No. of Battery
18617
18679
18679
18725
18817
18510
18796
18626
18776
16087
18671
18791
18819
18806
18780
18570
16260
18683
16195
18627

03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
02.05.2009
02.05.2009
02.05.2009
02.05.2009
02.05.2009
02.05.2009
Village: Nampe
Date of Installation

<!-- page 43 -->

Lokam Tagy
7
Chakpu Tamuk
8
Chakpu Yapa
9
Lokam Takia
10
Lokam Yache
11
Lokam Bai
12
Lokam Tamang
13
Chakpu Talap
14
Chakpu Yaha
15
Lokam Tanak
16
Lokam Situp
17
Lokam Hai
18
Lokam Yaging
19
Lokam Yaras
20
Lokam Atip
21
Lokam Benghi
22
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09017035
MM09035110
MM09035050
MM09032004
MM09023042
MM09032038
MM09029068
MM09027049
MM09027089
MM09024052
MM09033136
MM09031005
MM09031018
MM09031032
MM09022008
MM09017087
Circle: Damin
Sl.No. of Module

Lokam Yapik
1
Lokam Tache
2
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09029134
MM09024022
Circle: Damin
Sl.No. of Module

Lebong Sagme
1
Lebong Kougha
2
Lebong Tabin
3
Langkung Taru
4
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09033133
MM09033066
MM09033039
MM09031023
Circle: Damin
Sl.No. of Module

Loak Achu
1
Loak Eseing
2
Chiantak Dapor
3
Heru Tali
4
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09021033
MM09023045
MM09019078
MM09017085
Circle: Damin
Sl.No. of Module

Sl.No. of Battery

21.04.2009
21.04.2009
21.04.2009
21.04.2009
Village: Saitam
Date of Installation

MM09019073
MM09034098
MM09034120
MM09030149
MM09036054
MM09036058
MM09036570
MM09019071
MM09030083
MM09030088

18214
18669
18686
18781
18809
18441
18794
18346
18205
18208

03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009

1
2
3
4
5
6
7
8
9
10

Lokam Lodu
Lokam Takia
Lokam Tama
Lokam Tagung
Bamo Kame
Lokam Yapa
Lokam Bughi
Loakam Chula
Lokam Tama
Lokam Epa

18818
18598
18782
15843
18740
18644
15200
18815
18789
18667
17981
17860
18290
18053
17947
18039
Sl.No. of Battery
18831
18801
Sl.No. of Battery
18825
18813
18661
16262
Sl.No. of Battery
17891
17919
18522
18025

03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
03.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
Village: Ramu
Date of Installation
04.05.2009
04.05.2009
Village: Rane
Date of Installation
04.05.2009
04.05.2009
04.05.2009
04.05.2009
Village: Rawiok
Date of Installation

<!-- page 44 -->

District: Kurung Kumey
Beneficiary Name
Sl.No

Circle: Damin
Sl.No. of Module

Lokam Tagi
1
Lokam Tapang
2
Lokam Takin
3
Lokam Tache
4
Lokam Tama
5
Lokam Tari
6
Lokam Anju
7
Lokam Taming
8
Lokam Tamin
9
Lokam Tasuk
10
Lokam Tayar
11
Lokam yasung
12
Lokam Yajit
13
Lokam Tapit
14
Lokam Kaman
15
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09010039
MM09014072
MM09014068
MM09013017
MM09028018
MM09033105
MM09034070
MM09034077
MM09033102
MM09035114
MM09056197
MM09036066
MM09036056
MM09041180
MM09023036
Circle: Damin
Sl.No. of Module

Bialuk Taye
1
Lokam Kenia
2
Lokam Tagar
3
Lokam Taluk
4
Lokam Tare
5
Lokam Talung
6
Lokam Tai
7
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09035027
MM09022034
MM09031073
MM09056171
MM09056158
MM09056157
MM09056170
Circle: Damin
Sl.No. of Module

Waru Kalar
1
Waru Nachu
2
Waru Aku
3
Waru Tachen
4
Lebong Taker
5
Lebong Takio
6
Lebong Kira
7
Huria Taming
8
Huria Tagung
9
Siji Tasuk
10
Siji Chajak
11
Siji Tagi
12
Kadu Kasuk
13
District: Kurung Kumey
Beneficiary Name
Sl.No
Waru Tapit
1

MM09036005
MM09036028
MM09036024
MM09035134
MM09024035
MM09035087
MM09016073
MM09030124
MM09016064
MM09036139
MM09036098
MM09036107
MM09036137
Circle: Damin
Sl.No. of Module
MM09032054

Sl.No. of Battery
18535
18586
16242
15795
16019
15805
16024
16257
16256
16228
15637
16034
18628
16238
18181
Sl.No. of Battery
16164
15787
16016
16267
18609
15323
15656
Sl.No. of Battery
18467
18422
16274
16210
16140
18490
15814
15824
16255
15383
16106
16225
16171
Sl.No. of Battery
18630

Village: Sarang
Date of Installation
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
Village: Sayang
Date of Installation
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
Village: Senamriang
Date of Installation
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
30.04.2009
Village: Subuk
Date of Installation
05.05.2009

<!-- page 45 -->

Waru Tatak
2
Waru Bache
3
Lokam Yarup
4
Waru Taryu
5
Waru Logi
6
Hiniym Yagit
7
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09032016
MM09002023
MM08363644
MM09005052
MM09036101
MM09036088
Circle: Damin
Sl.No. of Module

Waruk Tadap
1
Kunia Bache
2
Kunia Tachung
3
Kunia Talar
4
Kunia Tapak
5
Waru Tama
6
Waru Tabang
7
Waru Tach
8
Lebong Tasuk
9
Lebang Tadit
10
Lokam Tama
11
Waru Atoni
12
Waru Apit
13
Keria Ajins
14
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09036084
MM09031051
MM09031134
MM09035088
MM09035086
MM09036023
MM09036020
MM09036048
MM09056155
MM09056154
MM09023051
MM09031004
MM09033073
MM09027083
Circle: Damin
Sl.No. of Module

Bengia Tabin
1
Lokam Tai
2
Bidak Tado
3
Bidak Taluk
4
Lokam Tage
5
Langkung Tame
6
Belap Yakap
7
Bamo Tagar
8
Bengia Poeotup
9
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09032047
MM09034049
MM09033137
MM09032015
MM09034034
MM09034033
MM09034056
MM09034031
MM09005023
Circle: Koloriang
Sl.No. of Module

Sorw Saria
1
Sarui Tosap
2
Wabik Adai
3
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09022066
MM09015046
MM09016002
Circle: Koloriang
Sl.No. of Module

Rare Tariu
1
Yumlam yash
2
District: Kurung Kumey

MM09028108
MM09028103
Circle: Koloriang

16074
15594
15087
16177
16230
16261
Sl.No. of Battery
15591
15179
16042
18500
16065
16118
16134
16027
18556
18348
16162
17904
18016
17812
Sl.No. of Battery
18730
18685
18738
18695
18502
18595
18790
18629
18793
Sl.No. of Battery
18358
18089
17856
Sl.No. of Battery
16165
18589

05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
Village: Tarba
Date of Installation
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
05.05.2009
06.05.2009
06.05.2009
06.05.2009
Village: Tarla
Date of Installation
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
04.05.2009
Village: Kachanjane
Date of Installation
21.05.2009
22.05.2009
22.05.2009
Village: Kele
Date of Installation
19.05.2009
19.05.2009
Village: Kush (Lami)

<!-- page 46 -->

Beneficiary Name
Sl.No
pania Taneang
1
Pani Tach
2
Pani Tahi
3
Pani Taro
4
Pani Nagakam
5
Pani Yagh
6
Pani Kain
7
Pani Tabe
8
Pani Tatup
9
Rare Take
10
District: Kurung Kumey
Beneficiary Name
Sl.No

Sl.No. of Module
MM09022025
MM09029078
MM09027053
MM09029085
MM09030033
MM09030022
MM09016084
MM09023100
MM09021052
MM09030094
Circle: Koloriang
Sl.No. of Module

Sl.No. of Battery
18714
16044
15837
16003
16277
16180
18472
16276
18775
16175

Bengia Tabiuk
1
Bengia Tagak
2
Bengia Pounkey
3
Bengia Yakey
4
Bengia Bado
5
Bengia Yakrang
6
Bengia Kiakia
7
Bengia Takap
8
Bengia Talar
9
Bangia Yodok
10
Bangia Taku
11
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09024028
MM09027002
MM09015029
MM09024013
MM09033056
MM09033043
MM09033026
MM09032009
MM09036051
MM09029047
MM09016074
Circle: Koloriang
Sl.No. of Module

18301
18526
18804
15801
16285
16105
18414
16191
15624
17991
18415

Bengia Takap
1
Bengia Tami
2
Bangia Yasap
3
Bagang Roi
4
Bagang Yabiam
5
Bengia Talo
6
Bengia Powky
7
Bengia Chadap
8
Bengia Yadak
9
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09031042
MM09027013
MM09017028
MM09016088
MM09023075
MM09023021
MM09017016
MM09021073
MM09029056
Circle: Koloriang
Sl.No. of Module

Sl.No. of Battery

09.05.2009
09.05.2009
09.05.2009
09.05.2009
09.05.2009
09.05.2009
09.05.2009
09.05.2009
09.05.2009
Village: Pari
Date of Installation

Huba Tado
Huha Tagh
Bengia Tagin
Bengia Chapo
Bengia Kaha
Bengia Taga
Bengia Tai

MM09032050
MM09032044
MM09032028
MM09032030
MM09022021
MM09036016
MM09032027

016008
016043
016161
018317
015363
018684
015432

07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009

1
2
3
4
5
6
7

Sl.No. of Battery

Sl.No. of Battery
18758
16151
18314
16170
15210
16184
15571
15836
16056

Date of Installation
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
06.05.2009
11.05.2009
11.05.2009
11.05.2009
20.05.2009
Village: Mange
Date of Installation
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
08.05.2009
08.05.2009
Village: Papin
Date of Installation

<!-- page 47 -->

Bengia Tanak
8
Bengia Tajuk
9
Bengia Yaky
10
Bengia Tangha
11
Bengia Sagung
12
Bengia Niato
13
Bengia Taui
14
Bengia Talung
15
Bengia Tachung
16
Bengia Taram
17
Bengia Tagi
18
Bengia Siro
19
Bengia Tagung
20
Bengia Tasung
21
Bengia Yape
22
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09032010
MM09032035
MM09032020
MM08363021
MM09032007
MM08632032
MM09002011
MM08362061
MM08363047
MM09032046
MM09032011
MM09032008
MM09017041
MM09021079
MM09021070
Circle: Koloriang
Sl.No. of Module

Saryu Tagung
1
Wabik Tayang
2
Barco Yane
3
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09030115
MM09030117
MM09020057
Circle: Koloriang
Sl.No. of Module

Bengia Tagu
1
Bengia Yalap
2
Bengia Kaming
3
Bangia Tafar
4
Bengia Taumg
5
Bengia Koyu
6
Bengia Yayu
7
Bengia Tamang
8
Bengia Kenia
9
Bengia Yapu
10
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09033086
MM09033067
MM09033048
MM09033041
MM09035007
MM09035035
MM09035057
MM09035120
MM09035113
MM09030097
Circle: Koloriang
Sl.No. of Module

Sariu Dayang
1
Saruo Chadap
2
Sariu Tungdang
3
Sariun Yape
4
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09030005
MM09030017
MM09028097
MM09028059
Circle: Koloriang
Sl.No. of Module

Sl.No. of Battery

19.05.2009
19.05.2009
19.05.2009
19.05.2009
Village: Yarpu
Date of Installation

MM09023016
MM09016028
MM09027015

16201
18359
16010

16.05.2009
16.05.2009
16.05.2009

1
2
3

N. Potuy
Bengia Rabang
Bengia takang

016051
016806
018489
016006
016246
018699
016119
018613
018577
016143
016070
016069
015199
019684
015145
Sl.No. of Battery
15799
18732
15843
Sl.No. of Battery
16081
16055
18611
16000
16265
18756
16144
16204
16247
18355
Sl.No. of Battery
18508
16041
16127
16209

07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
07.05.2009
08.05.2009
08.05.2009
08.05.2009
Village: Sangchu
Date of Installation
18.05.2009
18.05.2009
18.05.2009
Village: Sebi
Date of Installation
13.05.2009
13.05.2009
13.05.2009
13.05.2009
13.05.2009
13.05.2009
13.05.2009
13.05.2009
13.05.2009
13.05.2009
Village: Sollung Tapin
Date of Installation

<!-- page 48 -->

Ngangram Yame
4
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09021069
Circle: Parsi Parlo
Sl.No. of Module

Keji Yakar
1
Keji Tamas
2
Tato Yaming
3
Tato Satar
4
Talo Tapit
5
Talo Yadu
6
District: Kurung Kumey
Beneficiary Name
Sl.No
Sangha Tamang
1
Sangha Santoug
2
Sangha Tala
3
Sangha Epo
4
Mangio Tagung
5
Sangha Tabin
6
Lokam Takap
7
Mangio Tara
8
Mangio Tahang
9
Geyung Taro
10
Sangha Tache
11
Sangha Tachu
12
Sangha Takia
13
Mangio Tahang
14
Mangio Tachuk
15
Mangio Nikam
16
Sangha Tasong
17
Sangha Tahik
18
District: Kurung Kumey
Beneficiary Name
Sl.No
Sangha Loram
1
Sangha Taming
2
Nagra Tapang
3
Sangh Taying
4
Sangha Tapang
5
Sangha Yatar
6
Loa Yama
7
Sangha Yapik
8
Sangha Tahar
9
Sangha Tadok
10
Mangio Tajok
11
Mangio Tajo
12
Mangio Taju
13

MM09000648
MM09003272
MM09003222
MM09003569
MM09003225
MM09003305
Circle: Parsi Parlo
Sl.No. of Module
MM09056153
MM09031131
MM09030113
MM09033004
MM09031091
MM09030073
MM09030079
MM09029092
MM09020082
MM09017092
MM09003572
MM09003525
MM09003735
MM09003590
MM09003699
MM09003746
MM09002365
MM09002376
Circle: Parsi Parlo
Sl.No. of Module
MM09030036
MM09020092
MM09034067
MM09035069
MM09035051
MM09035048
MM09035112
MM09024032
MM09027011
MM09017036
MM09002883
MM09002983
MM09002530

16049
Sl.No. of Battery
18451
18465
18407
16021
18493
18468
Sl.No. of Battery
16237
18563
15856
18543
18447
16180
16203
15794
16111
16136
16214
18474
18427
18434
16264
16293
18494
18480
Sl.No. of Battery
18527
15653
15619
15808
18569
16052
18345
16120
15256
18616
15042
16148
18404

16.05.2009
Village: Boa
Date of Installation
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
Village: Dalang
Date of Installation
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
Village: Dape
Date of Installation
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009

<!-- page 49 -->

Mangio Kiopik
14
Mangio Digyang
15
Sangha Yama
16
Sangha Kiagung
17
Sangha Yadey
18
Sangha Kiochik
19
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09002496
MM09002555
MM09002432
MM09002967
MM09003050
MM09002358
Circle: Parsi Parlo
Sl.No. of Module

Keji Ruba
1
Keji Yeter
2
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09003551
MM09036089
Circle: Parsi Parlo
Sl.No. of Module

Sangha Kiochik
1
Mangdo Potum
2
Mangdo Taruk
3
Tasi Tajit
4
Donna Tache
5
Dona Talok
6
Doma Tahik
7
Ha Tohbang
8
Mangdo Taro
9
Doma Tayum
10
Dare Taria
11
Sangha Tachuk
12
Sangha Takam
13
Sangha Tap
14
Sangha Talit
15
Sangha Yasok
16
Sangha Yai
17
Giogi Yayang
18
Giogi Tagung
19
Sangha Lilong
20
Tasi Yahio
21
Sangha Tamar
22
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09016083
MM09035148
MM09036029
MM09035146
MM09016080
MM09019005
MM09019094
MM09020073
MM09025016
MM09016067
MM09033082
MM09031016
MM09036124
MM09034073
MM09036097
MM09030050
MM09029063
MM09027018
MM09028011
MM09027063
MM09003702
MM09003537
Circle: Parsi Parlo
Sl.No. of Module

Sl.No. of Battery

17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
17.05.2009
Village: Hissang
Date of Installation

MM09002925
MM09002879
MM09002271
MM09003805
MM09003610
MM09003702
MM09003550
MM09003614

18492
18377
15208
18655
15043
18447
18703
18432

07.06.2009
07.06.2009
07.06.2009
07.06.2009
07.06.2009
07.06.2009
07.06.2009
07.06.2009

1
2
3
4
5
6
7
8

Yurum Taha
Taram Tapok
Bamang Tamang
Bamang Chagi
Bamang Tatup
Bamang Tayang
Bamang Panio
Bamang Tangum

18458
15651
18721
15681
15428
15677
Sl.No. of Battery
16189
16148
Sl.No. of Battery
18360
18757
15135
18731
18581
18557
15835
16231
18584
15987
18245
15860
18477
15995
18701
18396
18547
18830
18636
18719
18422
18488

19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
Village: Gonang
Date of Installation
19.05.2009
19.05.2009
Village: Hanglik
Date of Installation

<!-- page 50 -->

Taram Takar
9
Bamang Talok
10
Bamang Tache
11
District: Kurung Kumey
Beneficiary Name
Sl.No

MM09003607
MM09003393
MM09003840
Circle: Parsi Parlo
Sl.No. of Module

Sangha Tama
1
Waru
2
Sangha Tade
3
Sangha Tama
4
Sangha Tagtik
5
Sangha Tagung
6
Sangha Tari
7
Sangha Tabe
8
Sangha Yarap
9
Sangha Yamang
10
Dalang Tamang
11
Dalang Tayum
12
Dalang Taso
13
Dalang Talok
14
District: Kurung Kumey
Beneficiary Name
Sl.No
Bamang Nillo
1
Bamang Yache
2
Bamang Tangung
3
Taram Takar
4
Taram Hawak
5
Taram Yapang
6
Taram Yarang
7
Taram Talok
8
Kamdak Tanang
9
Kamdak Tada
10
District: Kurung Kumey
Beneficiary Name
Sl.No
Keji Powak
1
Keji Tarak
2
Bamang Topang
3
Keji Tachak
4
Keji Pacha
5
Talo Kanik
6
Talo Tajan
7
Keji Tachu
8
Talo Tadang
9
Talo Takang
10
District: Kurung Kumey

MM09002564
MM09002593
MM09002577
MM09002595
MM09002933
MM09002877
MM09002934
MM09002538
MM09002918
MM09002875
MM09002838
MM09002989
MM09002902
MM09003026
Circle: Parsi Parlo
Sl.No. of Module
MM09031010
MM09033131
MM09031008
MM09033138
MM09021048
MM09028016
MM09023003
MM09028049
MM09033003
MM09002068
Circle: Parsi Parlo
Sl.No. of Module
MM09027070
MM09028090
MM09025060
MM09030020
MM09027055
MM09033070
MM09033074
MM09036007
MM09036003
MM09036008
Circle: Parsi Parlo

18562
18323
18497
Sl.No. of Battery
18697
18722
18657
18735
18343
18572
18312
18367
18764
18483
16102
16094
18645
16077
Sl.No. of Battery
18503
18676
16286
18610
18746
18807
15851
18593
16126
16048
Sl.No. of Battery
17894
18425
16061
18737
18810
18479
18816
18461
18550
16243

07.06.2009
07.06.2009
07.06.2009
Village: Langbang
Date of Installation
05.06.2009
05.06.2009
05.06.2009
05.06.2009
05.06.2009
05.06.2009
05.06.2009
05.06.2009
05.06.2009
05.06.2009
05.06.2009
05.06.2009
05.06.2009
05.06.2009
Village: Leya
Date of Installation
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
Village: Nyokuriang
Date of Installation
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
Village: Pagam

<!-- page 51 -->

Beneficiary Name
Sl.No
Dale Mangha
1
Dale Yareing
2
Lokam Tatuk
3
Dale Rongsi
4
Lokam Tamer
5
Lokam Yakia
6
Dare Tachu
7
Mangdo Potum
8
Mangio Tapit
9
District: Kurung Kumey
Beneficiary Name
Sl.No
Tara Takar
1
Bamang Tark
2
Bamang Tach
3
District: Kurung Kumey
Beneficiary Name
Sl.No
Largda Taram
1
Largda Targom
2
Ha Talam
3
Largda Tanarg
4
Largda Tasi
5
Largda Rai
6
Largda Tariah
7
Largda Tasar
8
Darghik Tahum
9
Bake Tachak
10
Dadag Tapak
11
Dere Tarmh
12
Dadag Tahar
13
Sangha Tarang
14
Smti M Yamag
15
District: Kurung Kumey
Beneficiary Name
Sl.No
Dongda Takia
1
Dongda Tajam
2
Dongda Yamar
3
Dongda Epo
4
Dongda Tanu
5
Dongda Tamang
6
Dongda Tapak
7
Dongda Tagok
8
Gichik Tatom
9
Dongda Yamak
10

Sl.No. of Module
MM09032052
MM09032017
MM09032013
MM09032022
MM09032048
MM09030027
MM09003207
MM09030038
MM09021064
Circle: Parsi Parlo
Sl.No. of Module
MM09003821
MM09003433
MM09003522
Circle: Parsi Parlo
Sl.No. of Module
MM08363045
MM09002010
MM08363032
MM08362049
MM08362053
MM09033040
MM09028033
MM09033107
MM09028026
MM09031009
MM09002884
MM09002864
MM09002931
MM09002909
MM09003104
Circle: Parsi Parlo
Sl.No. of Module
MM09033027
MM09006043
MM09002028
MM09002095
MM09031132
MM09023010
MM09016029
MM09023011
MM09029034
MM09014099

Sl.No. of Battery
15540
18639
18426
15089
16278
15991
18539
18727
15859
Sl.No. of Battery
18321
15833
18383
Sl.No. of Battery
15533
16076
15232
18475
15157
18361
18678
18453
15049
18548
18431
16280
18752
16283
18475
Sl.No. of Battery
16253
18599
18672
16035
16137
16222
16272
18486
16166
16103

Date of Installation
22.05.2009
22.05.2009
22.05.2009
22.05.2009
22.05.2009
22.05.2009
22.05.2009
22.05.2009
22.05.2009
Village: Pariang
Date of Installation
11.06.2009
11.06.2009
11.06.2009
Village: Rashik
Date of Installation
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
Village: Segriang
Date of Installation
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009

<!-- page 52 -->

Bamang Tagin
11
Bamang Tadok
12
District: Kurung Kumey
Beneficiary Name
Sl.No
Dougche Tapeg
1
Dougche Taja
2
Bamang Taha
3
Douche Taha
4
Dougche Tadar
5
Bake Tagin
6
Bamang Tabang
7
Dougche Taming
8
Dougche Yag
9
Bake Tagio
10
Ha Yakio
11
Sangha Tasuk
12
Sangha Tangak
13
Sangha Longung
14
Sangha Tapit
15
Dare Rovuk
16
Ha Tada
17
Sangha Tali
18
District: Kurung Kumey
Beneficiary Name
Sl.No
Tapra Pare
1
Sangha Tah
2
Sagha Yadih
3
Bamang Saping
4
District: Kurung Kumey
Beneficiary Name
Sl.No
Raha Tare
1
Langda Yapit
2
Tachang Takio
3
Bake Tami
4
Kammik Talar
5
Ha Tato
6
Talo Takia
7
Giogi Yarang
8
Ha Tapok
9
Ha Charu
10
District: Kurung Kumey
Beneficiary Name
Sl.No
Ha Tatum
1
Ha Taro
2

MM09030053
MM09029116
Circle: Parsi Parlo
Sl.No. of Module
MM09028069
MM09030106
MM09031034
MM09020031
MM09024069
MM09021026
MM09017082
MM09030136
MM09029001
MM09022068
MM09033132
MM09017038
MM09028110
MM09027074
MM09030021
MM09030062
MM09016087
MM09029149
Circle: Parsi Parlo
Sl.No. of Module
MM09003398
MM09003259
MM09003595
MM09003533
Circle: Parsi Parlo
Sl.No. of Module
MM09023004
MM09056217
MM09056174
MM09032053
MM09056194
MM09022064
MM09023014
MM09023006
MM09015045
MM09030139
Circle: Parsi Parlo
Sl.No. of Module
MM09005057
MM09007059

15682
18365
Sl.No. of Battery
16193
16249
15671
16215
15121
16244
18305
16100
16174
15786
18455
18689
18390
17984
15712
15578
16251
18219
Sl.No. of Battery
18665
18487
16047
18601
Sl.No. of Battery
16282
16196
16002
16233
15994
16188
16159
16020
16236
18546
Sl.No. of Battery
15857
18677

18.05.2009
18.05.2009
Village: Sera
Date of Installation
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
Village: Sobu
Date of Installation
18.05.2009
18.05.2009
18.05.2009
18.05.2009
Village: Tarik
Date of Installation
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
18.05.2009
Village: Tawriagring
Date of Installation
19.05.2009
19.05.2009

<!-- page 53 -->

Ha Tasok
3
Ha Tache
4
Ha Take
5
Ha Talok
6
Ha Chake
7
Ha Tabuk
8
Lirgdum Tamarg
9
Ha Tame
10
District: Kurung Kumey
Beneficiary Name
Sl.No
Mangio Yana
1
Mangio Yache
2
Taram Harung
3
District: Kurung Kumey
Beneficiary Name
Sl.No
Kamdek Tatup
1
Kmadek Maya
2
Kamdek Tachuk
3
Lokyo Tamak
4
Kamck Yami
5
Kamdek Gasi
6
Kamdek Takap
7
Ha Lonia
8
Ha Tai
9
Ha Togbang
10
Ha Yachi
11
Dare Tatak
12
Lokam Tagi
13
Dongda Tagung
14
Dongda Potum
15
Dongda Tayum
16
Dongda Tapak
17
Dongda Rajesh
18
Gichek Tajak
19
Cindum Sodar
20
Lindum Rai
21
Lindum Potum
22
Ha Yarik
23
Ha Yami
24
Ha Tachy
25
Ha Yajit
26
Dongda Tahik
27
Dongda Logu
28
District: Kurung Kumey

MM09002047
MM09002007
MM09028080
MM09031059
MM09030018
MM09029102
MM09031041
MM09027072
Circle: Parsi Parlo
Sl.No. of Module
MM09002936
MM09002901
MM09002891
Circle: Parsi Parlo
Sl.No. of Module
MM09003520
MM09003470
MM09003784
MM09003123
MM09003587
MM09003563
MM09003242
MM09003254
MM09003763
MM09003628
MM09003269
MM09003427
MM09003240
MM09003511
MM09003563
MM09036097
MM09034073
MM09036124
MM09031096
MM09033083
MM09035128
MM09022036
MM09035047
MM09028075
MM09029142
MM09016047
MM09035102
MM09030120
Circle: Parsi Parlo

18482
18538
18322
18600
15993
15158
16252
18691
Sl.No. of Battery
14332
18680
18393
Sl.No. of Battery
15312
18499
15536
18326
18452
15732
16138
18471
16150
19852
18688
18524
18747
16245
16053
18391
18713
18484
18441
18307
18345
18490
18319
18449
18485
18401
18414
18326

19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
19.05.2009
18.05.2009
18.05.2009
Village: Tungbia
Date of Installation
12.06.2009
12.06.2009
12.06.2009
Village: Yaluha
Date of Installation
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
10.06.2009
Village: Yarik

<!-- page 54 -->

Beneficiary Name
Sl.No
Mangio Taming
1
Sangha Tanier
2
Sangha Taha
3
Ha Tala
4
Mangdo Toruk
5
Tasi Tajit
6
District: Kurung Kumey
Beneficiary Name
Sl.No
Chello Tami
1
Chello Chaging
2
Chello Tasuk
3
Chello Tagia
4
District: Kurung Kumey

Sl.No. of Module
MM09029005
MM09002627
MM09002885
MM09002606
MM09002947
MM09002640
Circle: Sarli
Sl.No. of Module
MM09036100
MM09036083
MM09036089
MM09031048
Circle: Sarli

Sl.No. of Battery
16248
18451
18320
18751
18639
18340

Beneficiary Name
Sl.No
Chula Achung
1
Chula Dadu
2
Chula Ating
3
Chula Apek
4
Chula Addi
5
Waru Gungya
6
Chula Fayu
7
Chula Yapu
8
Chula Pacha
9
Waru Apang
10
Waru Alang
11
Waru Taby
12
Waru Cheting
13
Waru Tayu
14
Waru Takar
15
Waru Seina
16
Waru Gungle
17
Wary Tany
18
Waru Sita
19
Waru Kapji
20
Chula Segram
21
chula Yama
22
District: Kurung Kumey
Beneficiary Name
Sl.No
Saryu Tada
1
Saru Chachu
2
Saryu Tayang
3
Wary Tasa
4
Waru Takia
5

Sl.No. of Module
MM09035089
MM09030090
MM09034001
MM09033098
MM09034018
MM09034010
MM09027079
MM09036102
MM09035078
MM09017095
MM09020040
MM09017091
MM09020030
MM09022075
MM09036079
MM09034050
MM09019018
MM09035108
MM09035014
MM09035010
MM09006039
MM09015044
Circle: Sarli
Sl.No. of Module
MM09035072
MM09034079
MM09034028
MM09030111
MM09036017

Sl.No. of Battery
15161
16096
18409
15823
16259
16153
18603
16226
15998
15807
16057
15717
15233
16149
15778
15116
16063
15519
15251
18157
17849
17842

Sl.No. of Battery
15205
18448
15115
15330

Sl.No. of Battery
16037
18403
15845
16110
16176

Date of Installation
22.05.2009
22.05.2009
22.05.2009
22.05.2009
22.05.2009
22.05.2009
Village: Chaching
Date of Installation
20.04.2009
20.04.2009
20.04.2009
20.04.2009
Village: Chulu
Date of Installation
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
Village: Haleba
Date of Installation
20.04.2009
20.04.2009
28.04.2009
28.04.2009
28.04.2009

<!-- page 55 -->

District: Kurung Kumey
Beneficiary Name
Sl.No
Kapu Agayang
1
Kapu Cheda
2
Kapu Tachok
3
Kapu Teying
4
Wadu Asap
5
Kapu Wasi
6
Kapu Chadap
7
Waru Obey
8
Waru Tajak
9
Waru Yajuk
10
Waru Yami
11
Waru Tadang
12
Wasi Tagak
13
Wasi Tasi
14
Waru Kajap
15
Kapu Abik
16
Kapu Soya
17
Kapu Togum
18
Kapu Ofiak
19
Waru Saping
20
District: Kurung Kumey
Beneficiary Name
Sl.No
Yangfu Radap
1
Yangfu Tai
2
Yangfu Yaging
3
Yangfu Tagi
4
Yangfu Sinia
5
District: Kurung Kumey
Beneficiary Name
Sl.No
Milli Takia
1
Milli Kaosong
2
Mili Mating
3
Mili Mating
4
Milli Yape
5
Milli Dolu
6
Milli Wedung
7
Milli Jaju
8
Milli Seaiong
9
Milli Taki
10
Siji Jayo
11
Milli Chachung
12
Milli Tagung
13

Circle: Sarli
Sl.No. of Module
MM09056166
MM09035105
MM09035034
MM09022029
MM09035003
MM09032002
MM09034105
MM09034083
MM09034075
MM09034109
MM09034061
MM09017011
MM09024066
MM09019112
MM09016068
MM09025024
MM09016089
MM09017025
MM09029025
MM09025011
Circle: Sarli
Sl.No. of Module
MM09033121
MM09028040
MM09034006
MM09031045
MM09031101
Circle: Sarli
Sl.No. of Module
MM09030042
MM09030048
MM09021045
MM09017023
MM09021066
MM09016022
MM09017043
MM09015033
MM09022092
MM09023020
MM09036138
MM09028030
MM09036135

Sl.No. of Battery
16029
15076
15840
18412
18335
17866
18168
18386
18115
18306
18517
18328
18409
18337
18330
18418
18309
18325
18059
18334
Sl.No. of Battery
18344
18664
15829
15164
16158
Sl.No. of Battery
16059
16007
16273
15718
16155
16098
18332
16179
15858
16156
16085
16032
16190

Village: Kapu
Date of Installation
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
Village: Kene
Date of Installation
23.04.2009
23.04.2009
23.04.2009
23.04.2009
23.04.2009
Village: Machane
Date of Installation
25.04.2009
25.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
25.04.2009

<!-- page 56 -->

Milli Dado
14
Milli Yajick
15
Milli Yoper
16
Milli Saji
17
Milli Taga
18
Milli Seter
19
District: Kurung Kumey
Beneficiary Name
Sl.No
Pisa Tajik
1
Pisa Gari
2
Yangfy Taby
3
Pisa Minju
4
Pisa Kachi
5
Tamnu Chapo
6
Tamin Ragch
7
District: Kurung Kumey
Beneficiary Name
Sl.No
Polechar Mangchik
1
Chindu Agh
2
Chindo Yapiak
3
Pisa Yayu
4
Pisa Yagar
5
Pisa Yalar
6
Chindo Sayu
7
District: Kurung Kumey
Beneficiary Name
Sl.No
Riya Kamg
1
Riya Kewyang
2
Riya Segas
3
Riya Obiak
4
Riya Kayang
5
Riya Sakta
6
Riya Ofiak
7
Riya Kali
8
Riya Ekios
9
Prfaru Katling
10
District: Kurung Kumey
Beneficiary Name
Sl.No
Bengia Tagum
1
Bengia Tyagam
2
Riyat Yato
3
Chello Yaryung
4
Yangfu Kolong
5
Yangfo Kutcho
6

MM09036096
MM09036108
MM09027019
MM09031007
MM09035015
MM09035018
Circle: Sarli
Sl.No. of Module
MM09024012
MM09034052
MM09035122
MM09035081
MM09022047
MM09029129
MM09033017
Circle: Sarli
Sl.No. of Module
MM09033038
MM09035071
MM09035076
MM09034104
MM09034095
MM09031110
MM09034114
Circle: Sarli
Sl.No. of Module
MM09056156
MM09056178
MM09029004
MM09029026
MM09029006
MM09029045
MM09034030
MM09035002
MM09031114
MM09035036
Circle: Sarli
Sl.No. of Module
MM09031087
MM09036065
MM09036059
MM09036052
MM09036046
MM09036068

16023
16014
15254
18219
18235
17950
Sl.No. of Battery
16213
18690
15719
15153
16186
15635
16200
Sl.No. of Battery
15633
16062
18376
16028
15988
15736
15123
Sl.No. of Battery
18739
15996
18504
18509
18116
18026
17817
17858
18413
18114
Sl.No. of Battery
15206
16183
18457
15098
15530
15090

25.04.2009
25.04.2009
25.04.2009
24.04.2009
24.04.2009
24.04.2009
Village: Namjo
Date of Installation
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
Village: Pale
Date of Installation
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
Village: Riya
Date of Installation
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
Village: Ruktepu
Date of Installation
20.04.2009
20.04.2009
20.04.2009
20.04.2009
20.04.2009
20.04.2009

<!-- page 57 -->

Bengia Tamu
7
Chello Tungche
8
Chello Taky
9
Chello Sagme
10
Riya Yatang
11
Bengia Tafar
12
District: Kurung Kumey
Beneficiary Name
Sl.No
Sharma Alac
1
Sharma Kajik
2
Sharma Aka
3
Sharma Tarin
4
Sharma Tosar
5
Sharma Yagar
6
Sharma Yaring
7
Sharma Aluik
8
Sharma Saing
9
Sharma Tagi
10
District: Kurung Kumey
Beneficiary Name
Sl.No
Sain Takia
1
Sipe Kati
2
Risa Talar
3
Sipe Kulai
4
Sipe Kule
5
Sipe Tajak
6
District: Kurung Kumey
Beneficiary Name
Sl.No
Sariy Ri
1
Wasi Senia
2
Sariu Chebing
3
Yangfu Tasi
4
Sarin Yafar
5
Salim Kain
6
District: Kurung Kumey
Beneficiary Name
Sl.No
Vatalin Tashi
1
Vatalin Logy
2
Vatalin Gida
3
Vatalin Taka
4
Vatalin Tama
5
Vatalin Nidak
6
Vatalin Aloe
7
Vatalin Anya
8

MM09033093
MM09033096
MM09030093
MM09033076
MM09036130
MM09036087
Circle: Sarli
Sl.No. of Module
MM09035012
MM09035098
MM09035049
MM09031089
MM09036019
MM09030032
MM09022024
MM09029121
MM09029132
MM09028012
Circle: Sarli
Sl.No. of Module
MM09032041
MM09032024
MM09032021
MM09034048
MM09035013
MM09035085
Circle: Sarli
Sl.No. of Module
MM09036092
MM09036127
MM09036136
MM09036086
MM09036002
MM09031103
Circle: Sarli
Sl.No. of Module
MM09014087
MM09030001
MM09030102
MM09031061
MM09033145
MM09034009
MM09030143
MM09031038

16220
18312
16101
16194
16167
15844
Sl.No. of Battery
16192
16207
18469
18287
17820
17837
18334
18392
17838
18501
Sl.No. of Battery
16139
15207
16227
15574
18608
16218
Sl.No. of Battery
15804
16241
15388
15576
18649
16038
Sl.No. of Battery
15802
15800
15507
15321
16017
18796
15949
15581

20.04.2009
20.04.2009
20.04.2009
20.04.2009
20.04.2009
20.04.2009
Village: Sahrma
Date of Installation
25.04.2009
25.04.2009
25.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
26.04.2009
Village: Sope
Date of Installation
22.04.2009
22.04.2009
22.04.2009
22.04.2009
23.04.2009
23.04.2009
Village: Topak
Date of Installation
20.04.2009
20.04.2009
20.04.2009
20.04.2009
28.04.2009
28.04.2009
Village: Vatalin
Date of Installation
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009

<!-- page 58 -->

Vatalin Gayang
9
Vatalin Kecha
10
Vatalin Lelang
11
Waru Katoi
12
Waru Yatai
13
Wasi Aloi
14
Wasi Satar
15
Siji Samte
16
Vatalin Aloi
17
District: Kurung Kumey
Beneficiary Name
Sl.No
Namta Taming
1
PisaLogy
2
Pisa Jaky
3
Pisa Rumi
4
Tamen Dakrieng
5
Pira Tasing
6
Riya Tafar
7
Worfu Abiang
8
Sharma Tapeng
9
Sharma Chayu
10
Warfu Tayu
11
Warfu Mapam
12
Pisa Kaha
13
Pira Nama
14
District: Kurung Kumey
Beneficiary Name
Sl.No
Walu Tami
1
Walu Takam
2
Waru Jater
3
Wesi Akling
4
Chula Takeing
5
Chula Yajer
6
Chula Saking
7
Wasi Taba
8
District: Kurung Kumey
Beneficiary Name
Sl.No
Waru Afa
1
Waru Ayang
2
Waru Kasuk
3
Waru Kolai
4
Waru Kafa
5
Waru Fayang
6
Waru Tagh
7

MM09031003
MM09056159
MM09056168
MM09023018
MM09029132
MM09022095
MM09006040
MM09016013
MM09035125
Circle: Sarli
Sl.No. of Module
MM09022057
MM09036073
MM09030104
MM09034054
MM09034037
MM09022039
MM09022032
MM09035103
MM09035121
MM09035042
MM09035043
MM09032036
MM09030085
MM09020090
Circle: Sarli
Sl.No. of Module
MM09029125
MM09029118
MM09036043
MM09036044
MM09022022
MM09030116
MM09034071
MM09014096
Circle: Sarli
Sl.No. of Module
MM09029050
MM09033126
MM09030108
MM09030105
MM09033128
MM09035117
MM09035074

16168
15853
15705
18321
18430
18506
18276
17821
18145
Sl.No. of Battery
15680
16095
16172
16132
16235
16212
16281
15855
16266
18385
16234
15511
15847
17892
Sl.No. of Battery
17990
18278
18217
18351
18249
18056
17994
18010
Sl.No. of Battery
16219
6124
16199
18693
16224
15685
16131

25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
Village: Wabia
Date of Installation
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
22.04.2009
Village: Walu
Date of Installation
27.04.2009
27.04.2009
27.04.2009
27.04.2009
27.04.2009
27.04.2009
27.04.2009
27.04.2009
Village: Waru
Date of Installation
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009

<!-- page 59 -->

8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26

Suraj
Waru Tajik
Waru Kati
Waru Logy
Waru Afasia
Waru Alley
Waru Adue
Waru Alue
Waru Logu
Waru Gagung
Waru Gira
Waru Ali
Waru Kamkieng
Waru Sinsang
Waru Tasang
Waru Kumey
Waru Penlong
Waru Timsang
Waru Kotering

MM09030188
MM09035037
MM09035022
MM09035144
MM09035060
MM09031129
MM09034116
MM09030064
MM09031080
MM09034069
MM09034102
MM09035026
MM09027021
MM09036050
MM09036076
MM09036071
MM09036053
MM09036069
MM09029017

16208
16066
15151
15486
16173
16232
16152
16268
15237
16129
18353
16197
17790
18308
18077
17329
18213
17880
18030

25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009
25.04.2009

BENEFICIARY LIST OF UPPER SUBANSIRI DISTRICT
District: Upper Subansiri
Beneficiary Name
Sl.No
Smti. Yatong Eyum
1
Smti. Yaning Eyum
2
Smti. Yagam Eyum
3
Smti. Taying Rai
4
District: Upper Subansiri
Shri Jabu Rai
1
Shri Tabu Dingsar
2
Shri Tame Kyamdo
3
District: Upper Subansiri
Shri Konia Cheke
1
Shri Taka Cheke
2
Shri Tara Cheke
3
Shri Tadam Cheke
4
Shri Tade Cheke
5
Shri Tarik Rai
6
Smti Yape Cheke
7
Shri Tachung Cheke
8
Shri Tai Cheke
9
Shri Tayor Rai
10
Smti Yanam Rai
11

Circle: Nacho
Sl.No. of Module
3469
3531
3543
3519
Circle: Nacho
2785
2887
2869
Circle: Nacho
3640
3584
3510
3276
3579
3447
3090
2772
2812
2810
2763

Village: Eyum
Sl.No. of Battery
21205
21199
21207
20614
Village: Dingsar
21415
21175
21270
Village: Cheke
21043
21021
20382
21007
21177
20622
20394
21143
21104
21110
21187

<!-- page 60 -->

Shri Tai Rai
12
Shri Tatam Cheke
13
Shri Tagug Cheke
14
District: Upper Subansiri
Shri Taga Daying
1
Shri Tachung Daying
2
Shri Tajit Daying
3
Shri Tapak Daying
4
Shri Tade Rai
5
Shri Tapar Baker
6
District: Upper Subansiri
Shri Tado Siyum
1
Shri Tassar Neing
2
Shri Tanga Siyum
3
Shri Tayum Siyum
4
Shri Tadung Siyum
5
Smti Yana Baki
6
Shri Tabu Siyum
7
Shri Tatar Siyum
8
Shri Tapung Doki
9
Shri Tanam Doki
10
Shri Tabu Baki
11
Shri Tama Doki
12
Shri Tssar Doki
13
Shri Tanam Baki
14
Shri Tadu Baki
15
Shri Tagia Baki
16
District: Upper Subansiri
Shri Talok Byaling
1
Shri Tape Byaling
2
Shri Tagi Byaling
3
Shri Takar Byaling
4
Shri Tama Byaling
5
Shri Taning Byaling
6
Shri Takak Byaling
7
District: Upper Subansiri
Shri Tadik Rava
1
Shri Tara Rava
2
Shri Tache Rava
3
Shri Tanu Rava
4
Shri Taw Rava
5
Smti Yano Rava
6
Smti Tabu Rava
7
District: Upper Subansiri

2831
2893
2891
Circle: Nacho
3311
3025
3195
3240
3440
2829
Circle: Nacho
3487
3557
3479
3489
3494
3306
3587
3340
3459
3558
3457
3470
3477
3478
3560
2868
Circle: Nacho
3562
3463
3543
3586
3546
3542
3544
Circle: Nacho
3214
3216
3168
3441
3194
3475
3423
Circle: Nacho

21376
21094
20626
Village: Daying
21183
21429
21245
21708
21290
21546
Village: Neing
27750
21248
21470
21549
21201
21560
20606
21556
21234
20649
20631
21476
20635
2108
2096
20615
Village: Meyaba
21266
21239
21385
20648
21291
21467
20605
Village: Rava
20611
20612
20637
21457
21457
21358
21258
Village: Chingring

<!-- page 61 -->

Shri Tapik Choker
1
Shri Taw Chingring
2
Smti Yamin Choker
3
Shri Tabu Chingring
4
Shri Taji Bogia
5
Shri Tagu Sobia
6
Shri Tanam Charu
7
Smti Yapong Baki
8
Smti Yado Baki
9
Shri Tado Byaling
10
Smti Yadak Byaling
11
Shri Tara Byaling
12
Smti Yade Byaling
13
Shri Tapak Sobia
14
Shri Take Dingsar
15
Shri Takap Byaling
16
District: Upper Subansiri
Shri Takar Mosing
1
Shri Tade Mosing
2
Shri Tako Bui
3
Shri Taming Bui
4
Shri Tabom Bui
5
District: Upper Subansiri
Shri Tarung Choker
1
Shri Tabu Charu
2
Shri Tabu Choker
3
Shri Tate Choker
4
Taring Choker
5
District: Upper Subansiri
Shri Tade Nalo
1
Shri Tama Nalo
2
Shri Tapu Nalo
3
Smti Yaming Nalo
4
Smti Yara Nalo
5
Smti Yake Choker
6
Shri Tado Choker
7
Shri Tania Choker
8
Shri Tape Siyum
9
Shri Pomiu Kargam
10
Shri Tamin Nalo
11
Shri Ranjit Choker
12
Smti Yama Choker
13
Smti Yayack Poba
14
District: Upper Subansiri

3160
3149
3110
3120
3049
3383
3556
3474
3085
3461
3498
3435
3442
3254
2860
3327
Circle: Nacho
2909
3042
3113
3094
2936
Circle: Nacho
3380
2994
3007
3394
2964
Circle: Nacho
2906
3055
3272
3107
3008
3391
2940
3348
3406
3960
2820
2794
1278
2863
Circle: Nacho

21536
21301
21421
21440
21184
20640
21609
21204
21597
21390
21322
21364
20653
21545
21453
21339
Village: Mosing
21173
21185
20612
21317
21379
Village: Choker
21392
21343
21601
21295
20652
Village: Poba
21420
21284
21268
21115
21192
21383
21752
21475
21650
21433
20625
21617
21321
21633
Village: Kargam

<!-- page 62 -->

Shri Tache Kargam
1
Shri Tado Rai
2
Shri Tama Rai
3
Shri Tai Kargam
4
Shri Tabu Rai
5
Shri Tabu Kargam
6
Shri Tare Rai
7
Shri Tame Kargam
8
Shri Tabu Kargam
9
Shri Tai Rai
10
Shri Tadit Kargam
11
Smti Yanga Kargam
12
Smti Yakap Singkom
13
Shri Tapia Kargam
14
Shri Tamar Kargam
15
Shri Dei Kargam
16
District: Upper Subansiri
Shri Tarik Rai
1
Shri Tani Rai
2
Shri Tapu
3
Shri Tadu Rai
4
Shri Tanik Rai
5
Shri Tabe Rai
6
Shri Tassar rai
7
Shri Takar Rai
8
Shri Tacho Rai
9
Shri Taji Rai
10
District: Upper Subansiri
Shri Tai Nalo
1
Shri Tapak Nalo
2
Shri Tara Nalo
3
Shri Nikam Nalo
4
Shri Taham Nalo
5
Shri Tanga Nalo
6
Shri Makmi Nalo
7
Smti Yaming Nalo
8
Smti Yasam Nalo
9
Shri Bapak Nalo
10
Shri Tade Nalo
11
Shri Tape Nalo
12
Shri Taring Nalo
13
Shri Tado Nalo
14
Shri Tanga Rai
15
Smti Yanong Nalo
16

2879
3019
3289
3106
3063
3430
3444
3193
3048
3400
2992
3152
3452
3146
3153
3250
Circle: Nacho
3547
3270
3596
3274
3571
3460
3569
3466
3594
3482
Circle: Nacho
3570
3589
3506
3152
3573
3563
3554
3566
3552
3554
3599
3565
3422
3468
3558
1265

20610
21585
21111
21355
21483
21725
21292
21471
21590
21678
21299
21525
21266
21190
21490
20652
Village: Medamba Rai
21514
21194
21644
21508
22203
21539
21304
21608
21552
21536
Village: Dogi Nalo
21164
21198
20632
21163
21407
21126
21117
21694
21522
21553
21463
21473
21572
21424
21664
21542

<!-- page 63 -->

Shri Talar Nalo
17
Shri Tadik Nalo
18
District: Upper Subansiri
Shri Toria Ringling
1
Shri Tayo Ringling
2
Shri Tare Ringling
3
Shri Take Ringling
4
Shri Tako Ringling
5
Shri Tanya Ringling
6
Shri Taring Ringling
7
Shri Raja Ringling
8
Smti Yangium Ringling
9
Shri Tape Nacho
10
Shri Lonia Ringling
11
District: Upper Subansiri
Shri Taw Nacho
1
Shri Taya Nacho
2
Shri Tarik Nacho
3
Shri Tabu Nacho
4
Shri Tadik Nacho
5
Shri Tamo Nacho
6
Smti Yape Nacho
7
Shri Tade Nacho
8
Shri Yani Nacho
9
Shri Taji Garam
10
Shri Tarik Garam
11
Shri Tapa Nacho
12
Shri Taring Nacho
13
Shri Tapak Nacho
14
Shri Tape Nacho
15
Shri Tade Nacho
16
Shri Tagio Ekke
17
Shri Tanio Nacho
18
District: Upper Subansiri
Shri Tayom Kyodo
1
Shri Taning Kyondo
2
Shri Taw Kyamdo
3
Shri Tadam Kyamdo
4
Shri Tatam kyamdo
5
Shri Tacho Kyamdo
6
Shri Tachok Kyamdo
7
Shri Taria Gorum
8
Shri Tawa Kyamdo
9
Shri Tabu Kyamdo
10

2724
2733
Circle: Nacho
3361
3247
3204
2920

21754
21524
Village: Ringling
20604
21192
31423
21109

2985
3053
3013
3061
2663
3040
Circle: Nacho
3412
3402
3223
3426
3221
3021
2983
2987
3015
2990
3431
3227
3306
3307
3126
2666
2716
2719
Circle: Nacho
3027
2939
3057
3051
3392
3198
3309
3128
3308
3328

21591
21171
21159
21435
21222
21246
Village: Kidulingdi
21220
21203
21057
21671
21729
21584
21329
21530
21368
21101
21505
21583
21439
21669
21568
21450
21319
21339
Village: Kyamdo
20999
21169
21131
21362
21353
21052
21352
21162
21660
21336

<!-- page 64 -->

Shri Tai Ebiua
11
Shri Taw Ebiua
12
Shri Talok Ebiua
13
Shri Tagi Kyamdo
14
Shri Tara Kyamdo
15
Shri Yatin Kyamdo
16
District: Upper Subansiri
Shri Tara Charu
1
Shri Talak Kyamdo
2
Shri Tabu Mari
3
Shri Taji Gamnu
4
Smti Yadik Charu
5
Smti Yama Gamnu
6
Shri Taram Padi
7
Shri Tadong Gamnu
8
Shri Tapor Gamnu
9
Shri Krishno Gamnu
10
Shri Tasam Kyamdo
11
Shri Tanga Gamnu
12
Smti Yana Gamnu
13
Shri Asik Gamnu
14
Smti Yapin Eru
15
Smti Yago Garam
16
Shri Tado Rava
17
Shri Takio Rava
18
Shri Taper Kyamdo
19
District: Upper Subansiri
Shri Tapen Dajam
1
Shri Tapa Dajam
2
Shri Takam Dajam
3
Shri Tasa Garam
4
Smti Yagiam Dajam
5
Shhri Taching Dajam
6
Shri Tako Dajam
7
Shri Tupor Dajam
8
Shri Paknia Diri
9
Shri Tapu Diri
10
Smti Donia Ngona
11
District: Upper Subansiri
Shri Kyaym Kyamdo
1
Shri Dopok Kyamdo
2
Shri Tama Kyamdo
3
Shri Tara Bui
4
Shri Tama Bui
5

3509
3537
3598
3471
3596
3697
Circle: Nacho
2966
3422
2965
3407
2956
2969
2889
3381
2911
2984
2718
2719
2720
2330
2133
2146
3503
3593
2872
Circle: Nacho
3459
3449
3500
3501
3502
3273
3187
3275
3264
3254
3243
Circle: Nacho
2924
2884
2903
3451
3461

21303
21551
21350
21333
21499
21430
Village: Ragmi
21147
21378
21036
21061
21447
21443
21027
21236
21404
21281
21021
22364
21064
21163
20102
21079
21300
21448
21456
Village: Chettam
31314
21668
21674
21654
21745
21488
21489
21349
21453
21421
21334
Village: Kojin
21681
21661
21405
20996
21688

<!-- page 65 -->

Shri Tabu Bhai
6
Shri Tate Bhai
7
Shri Nikam Nalo
8
Shri Jaction Nalo
9
Shri Lochung Kyamdo
10
District: Upper Subansiri
Smti Yape Gingba
1
Shri Talin Gingba
2
Shri Dai Gingba
3
Shri Tadap Gingba
4
Shri Tarak Gingba
5
Shri Taniam Gingba
6
Shri Taring Gingba
7
Shri Paw Gingba
8
Smti Yari Nalo
9
Shri Tachi Eru
10
Shri Tasing Eru
11
Shri Tasa Eru
12
Shri Tagiam Eru
13
Smti Yanam Gingba
14
Smti Yaming Gingba
15
Smti Yaming Gingba
16
Shri Tarak ai
17
Shri Tade Rai
18
Shri Tadung Garam
19
Shri Taji Morging
20
Shri Tania Morging
21
Shri Babu Gingba
22
Shri Take Gingba
23
Shri Tapa Gingba
24
Shri Taring Garam
25
Smti Yagi Kyamdo
26
Shri Tapo Diri
27
Smti Yai Diri
28
Shri Takia Garam
29
District: Upper Subansiri
Shri Tagia Nalo
1
Shri Tajak nalo
2
Shri Tade Nalo
3
Shri Tami Nalo
4
District: Upper Subansiri
Shri Tasing Dungra
1
Shri Tabu Haming
2
Shri Taji Dungra
3

3411
3409
3325
3588
2786
Circle: Nacho
3353
3326
3350
3385
3295
3295
3414
3031
3436
3434
3576
3522
3534
3458
3324
3327
3298
3572
3578
3573
3437
3496
3492
1092
1290
2877
2116
3117
2671
Circle: Nacho
3439
3209
3208
3330
Circle: Nacho
3536
3508
3510

21354
21267
21597
21341
21566
Village: Gingba
21620
21546
21312
21370
21537
21537
21707
21288
21230
21721
21382
21349
2155
21697
21680
21684
21189
21367
21364
21365
21398
21219
21431
21518
21733
21479
21330
21432
21398
Village: Yaba
21019
21634
21649
21511
Village: Tabe Namsing
21237
21700
21684

<!-- page 66 -->

Shri Tadam Dungra
4
Shri Taneng Dungra
5
Shri Tasap Nalo
6
Shri Taram Haming
7
Shri Tapa Dungra
8
Shri Tapir Dungra
9
Shri Tani Pading
10
Smti Yame Dungra
11
Smti Yami Haming
12
Shri Tachik Gyamo
13
Shri Taji Kyamdo
14
Shri Taching Baker
15
Shri Taru Haming
16
District: Upper Subansiri
Shri Tacha Singring
1
Shri Takam Singring
2
Shri Tame Singring
3
Shri Talam Singring
4
Shri Tadop Singring
5
Shri Tapo Singring
6
Shri Tasu Singring
7
Shri Tade Rai
8
Shri Tame Rai
9
Smti Yaning Rai
10
Smti Yaluk Rai
11
Shri Taluck Siyum
12
Shri Tarak Rai
13
Smti Yana Singring
14
Smti Yane Singring
15
Shri Tapu Rai
16
Shri Tasa Jibaying
17
Shri Torik Rai
18
District: Upper Subansiri
Shri Taro Kyamdo
1
Shri Tade Kyamdo
2
Shri Tare Kyamdo
3
Smti Yaming Kyamdo
4
Shri Talik Baker
5
Shri Tab Kyamdo
6
District: Upper Subansiri
Shri Talak Gyamo
1
Shri Tatam Gyamo
2
Smti Yam Gyamo
3
Shri Taro Garam
4

5577
3450
3184
3102
3232
3108
2979
2692
2670
2961
2771
2656
2695
Circle: Nacho
3267
3331
3317
3325
3265
3116
2864
3205
3429
3206
3006
6066
3362
3134
3009
3452
3319
3001
Circle: Nacho
3448
3502
3117
2737
3981
2662
Circle: Nacho
3465
3484
3485
3476

21509
21507
21327
21351
21526
21685
21528
20969
21682
21234
21223
21218
21613
Village: Rongba
21034
21180
21015
20644
205564
21127
21136
21466
21260
21060
21380
21017
21156
21119
21519
21372
21512
21612
Village: Kurungba
21165
20609
21468
21232
21157
21005
Village: Pading
21413
21203
21495
21252

<!-- page 67 -->

Smti Dode Nacho
5
Shri Noko Ebiya
6
Smti Yajik Jibaying
7
Shri Tadi Garam
8
District: Upper Subansiri
Shri Tabu Nacho
1
Shri Tade Nacho
2
Shri Taker Nacho
3
Shri Tapong Nacho
4
Shri Pomam Nacho
5
Shri Tayu Nacho
6
Smti Yama Nacho
7
Shri Babu Nacho
8
Shri Nyakam Nacho
9
Shri Tarik Nahco
10
Shri Tapok nacho
11
Shri Take Nacho
12
District: Upper Subansiri
Shri Takar Baki
1
District: Upper Subansiri
Shri Tadong Dingsan
1
Shri Tassar Dingsan
2
Shri Take Kyamdo
3
Shri Tangu Dingsan
4
Shri Tape Dingsan
5
Shri Taya Dingsan
6
Shri Tapu Dingsan
7
Smti Yasinom Dingsan
8
Smti Yaning Dingsan
9
Smti Yapik Dingsan
10
District: Upper Subansiri
Shri Shri Tabu Nacho
1
Shri Tade Nacho
2
Shri Taker Nacho
3
Shri Tapong Nacho
4
Shri Pokam nacho
5
Shri Tayu Nacho
6
Smti Yarna Nacho
7
Shri Bab Nacho
8
Shri Nyakam Nacho
9
Shri Tarik Nacho
10
Shri Tapok Nacho
11
Shri Take Nacho
12
Shri Tapu Rai
13

3481
2679
3486
3462
Circle: Nacho
3580
3513
3485
3511
3555
3180
3231
3225
3425
3427
3553
3280
Circle: Nacho
3375
Circle: Nacho
2997
3026
3046
2769
2789
3023
2915
3030
3181
3178
Circle: Nacho
3580
3513
3485
3511
3555
3180
3231
3235
3425
3427
3553
3280
3452

21337
21495
21487
21520
Village: Dingsi
21578
21705
21586
21698
21563
21095
21357
21492
21547
20967
21209
21446
Village: Modiripu
2169
Village: Paying Moring
21030
21187
20971
21018
21167
21382
21212
21255
20986
21050
Village: Duilingdi
21578
21705
21586
21698
21563
21095
21357
21492
21547
20967
21209
21446
20372

<!-- page 68 -->

Shri Tarpu Jibaying
14
Smti Dode Nacho
15
Smti Yajik Jibaying
16
Smti Yarak Jibayaing
17
District: Upper Subansiri
Shri Tanga Nacho
1
Shri Tapong Nacho
2
District: Upper Subansiri
Chuge Mra
1
Tache Mra
2
Rapong Mra
3
Tama Mra
4
Yake Mra
5
District: Upper Subansiri
Taw Mra
1
Talok Mra
2
Tania Mra
3
Tade Mra
4
Tapo Mra
5
District: Upper Subansiri
Tadik
1
District: Upper Subansiri
Yesu Mra
1
Tujak Karsing
2
District: Upper Subansiri
Tai Mra
1
District: Upper Subansiri
Tading Chader
1
Chakiap Bai
2
Tabar Tai
3
Bale Chader
4
Babe Chader
5
Kani Riya
6
Tade Chader
7
Tayu Chader
8
Yapa Chader
9
Norbu Chader
10
Taba Chader
11
Charching Meki
12
Hato Chader
13
Yaniam Chader
14
Chamu Chader
15
Yame Chader
16
Mama Tai
17

3319
3481
3486
3203
Circle: Nacho
2740
2720
Circle: Limeking
2918
2938
2910
2890
1302
Circle: Limeking
3075
3170
3297
3345
3298
Circle: Limeking
2790
Circle: Limeking
2782
2802
Circle: Limeking
2916
Circle: Taksing
3036
3183
3216
3210
3091
3224
3815
3488
3491
3523
2970
3410
3419
3392
3507
3290
3349

21512
21337
21487
21541
Village: Koba
21491
21365
Village: Sereva
20105
21129
21020
21132
21145
Village: Dolering
21326
21509
21441
21419
21502
Village: Kinekio
21302
Village: Kinekio
21504
21387
Village: Raw
21741
Village: Gumsing
21639
21479
21513
21342
21482
21347
21315
21496
21452
21383
21345
21494
21371
21624
21416
21346
21421

<!-- page 69 -->

Takfi Lakam
18
Papap Chader
19
Yaya Chader
20
Yakap Chader
21
Epo Chader
22
District: Upper Subansiri
Law Nalo
1
Jichung nalo
2
Dolo Nalo
3
Ngacha Nalo
4
Jining Nalo
5
Chade Nalo
6
Chapo Nalo
7
Pening Nalo
8
Debu Nalo
9
Pema Nalo
10
Tamar Nalo
11
District: Upper Subansiri
Robu Nalo
1
Kochung Nalo
2
Yanok Nalo
3
Tapo Nalo
4
Binpor Nalo
5
Kyokia Nalo
6
Tayi Cheke
7
Ringyo Nalo
8
District: Upper Subansiri
Yake Mosu
1
Taling Nalo
2
Taje Nalo
3
Makma Nalo
4
Rania Nalo
5
Ranu Nalo
6
Tama Nalo
7
District: Upper Subansiri
Talo Dui
1
Taram Dui
2
Pubu Duku
3
Taga Dui
4
Taru Dui
5
Tonia Duku
6
Tas Duku
7
Taneng Dui
8
Taga Nalo
9

3305
3346
3286
2766
2811
Circle: Siyum
1322
1305
2659
1090
2687
1321
1081
1086
1031
1306
2661
Circle: Siyum
2665
2736
2675
1315
1312
1319
1076
1320
Circle: Siyum
1318
1309
2673
2690
1082
1323
1079
Circle: Siyum
1303
2691
1307
2817
1317
2677
1314
1311
2813

21400
21485
21200
21293
21460
Village: Byammer
21445
21114
21174
21249
20980
21047
21226
20133
20638
21454
21134
Village: Regulington
21096
21261
21112
21150
21122
21193
20645
21442
Village: Lengi
21135
21277
21399
21009
21148
21245
20624
Village: Duku
21280
21469
2122202
21395
20608
21375
20607
21168
21461

<!-- page 70 -->

Taluk Duku
10
Chepa Duku
11
Tagiam Duku
12
Tamar Duku
13
Tade Duku
14
Jira Duku
15
Tanam Duku
16
Gokde Duku
17
Yalung Duku
18
Pongkam Duku
19
Jima Duku
20
Jipu Duku
21
Tumar Duku
22
Tabu Duku
23
District: Upper Subansiri
Makpu Singlom
1
Loning Singlom
2
Kiaminia Ekke
3
Singko Singlom
4
Porbu Singlom
5
Lomar Singlom
6
Loper Singlom
7
Ningkam Singlom
8
Kampak Singlom
9
Tade Bakar
10
Puna Ekke
11
Bania Singlom
12
Kiamlin Ekke
13
Kaw Singlom
14
Takung Singlom
15
Tama Singlom
16
Tate Singlom
17
Talo Singlom
18
Tamin Singlom
19
District: Upper Subansiri
Chikbu Singlokring
1
Ningko Singlokring
2
Kiniom Singlokring
3
Buda Singlokring
4
Dingmar Singlokring
5
Tacho Singlokring
6
Tadit Singlokring
7
Sining Singlokring
8
Kosing Singlokring
9

2672
2682
1308
3032
3035
3096
1239
3118
3225
3367
2753
3281
3358
3368
Circle: Siyum
1229
1264
1289
2941
1266
2657
2664
2762
2823
1234
1249
2432
2694
2779
3132
3294
3291
3131
3355
Circle: Siyum
1258
1232
1242
1269
2886
3320
3334
3344
3189

20984
21153
21092
21233
20969
21097
20977
21120
21113
20972
21564
20970
21363
21313
Village: Daga
21035
21186
2115
21011
21031
21000
21033
21025
21037
21195
21141
21158
21166
21262
21149
21675
21022
21657
21651
Village: Singlokring
21484
20619
21103
21138
21306
21727
21571
21582
21418

<!-- page 71 -->

Dungke Singlokring
10
Tabit Singlokring
11
Jake Singlokring
12
Denieng Singlokring
13
Takam Singlokring
14
Yama Singlokring
15
Tasing Singlokring
16
Taw Singlokring
17
District: Upper Subansiri
Pasa Siyum
1
Purke Pai
2
Sarbu Siyum
3
Papung Siyum
4
Parbu Grammu
5
Taklin Grammu
6
Lassing Siyum
7
Bama Siyum
8
Marde Siyum
9
Yepa Siyum
10
Yaning Byachin
11
Noper Siyum
12
Yanam Byaching
13
Yatung Siyum
14
Pimpa Siyum
15
Larsa Siyum
16
Muni Siyum
17
Papu Siyum
18
District: Upper Subansiri
Kesang Nyogin
1
Namche Nyogin
2
Tabu Choyam
3
District: Upper Subansiri
Tade Ering
1
Nyasar Ering
2
Nyasu Ering
3
Tara Ering
4
Tajum Ering
5
Tasu Ering
6
District: Upper Subansiri
Gidey Sarta
1
Maw Sarta
2
Dabing Sarta
3
Mapor Sarta
4
Rikkam Sarta
5

3550
2728
2725
2727
3535
2680
2734
3084
Circle: Siyum
745
984
770
744
3145
3071
3333
3162
3080
2826
2773
2086
3076
3079
3074
3154
3157
2025
Circle: Siyum
3415
3103
3123
Circle: Siyum
3373
3351
2799
2765
1241
1253
Circle: Siyum
2933
3161
3089
2993
3260

21613
21591
21409
21677
21481
21091
21549
21462
Village: Jenering
21426
21008
21527
21709
21480
21152
21503
21295
21458
21297
21311
21207
21521
21432
21308
21335
21674
21278
Village: Nyogin
21016
21059
21042
Village: Ering
21307
21425
21340
20987
21102
21456
Village: Sarta
21500
21655
21396
21515
21325

<!-- page 72 -->

Rinam Sarta
6
Pusak Sarta
7
Tagiam Sarta
8
Girak Sarta
9
Jira Sarta
10
Sopdum Sarta
11
Pakbin Sarta
12
Jikam Sarta
13
Yara Sarta
14
Nikam Sarta
15
Yaram Sarta
16
District: Upper Subansiri
Nopor Byannia
1
Tagin Byannia
2
Tade Byannia
3
Tachang Byannia
4
Yapar Byannia
5
Tasar Mosu
6
Tapu Byannia
7
Take Mosu
8
Chope Byannia
9
District: Upper Subansiri
Kandu Dingdopa
1
Tara Dingdopa
2
Tamar Dingdopa
3
Taka Dingdopa
4
Yama Dingdopa
5
District: Upper Subansiri
Tajen Talingha
1
Taming Talingha
2
District: Upper Subansiri
Tadam Kampung
1
Togiom Kampung
2
Yoga Kampung
3
Tanium Kampung
4
Taya Kampung
5
Yakia Kampung
6
Jipok Kampung
7
Yame Kampung
8
Puchung Kampung
9
Mapa Kampung
10
Tape Kampung
11
Tape Kampung
12
Chabu Kampung
13

3001
2059
2807
3002
3229
3043
3058
3363
3133
3251
3650
Circle: Siyum
2899
2688
1240
2674
1661
2872
2631
1221
2113
Circle: Siyum
1238
2731
2669
1254
1336
Circle: Siyum
2660
1284
Circle: Siyum
2871
2876
2685
2830
3143
3364
3258
3356
3369
3155
3416
3268
3162

21449
21569
21724
21348
21207
21656
21144
20979
21228
26882
24521
Village: Byannia
21123
20995
20165
21214
21107
20991
20355
20322
20112
Village: Dingdopa
21231
21244
21003
21210
25160
Village: Talingha
21050
21231
Village: Kampung
21213
21258
21023
21105
21309
21430
21579
21589
21636
21004
20983
21412
21523

<!-- page 73 -->

Tama Kampung
14
Takiok Kampung
15
Papu Kampung
16
Yoinji Esu
17
Kebu Esu
18
Raju Kampung
19
Taping Kampung
20
Tongiam Kampung
21
Jipun Kampung
22
Loga Kampung
23
District: Upper Subansiri
Soya Gyate
1
Take Gyate
2
Pew Gyate
3
Tagong Gyate
4
District: Upper Subansiri
Tatum Mosu
1
Glazu Mosu
2
Tasar Mosu
3
Tapung Choyum
4
Take Mosu
5
Tagia Mosu
6
Tada Mosu
7
Tining Mosu
8
Yama Yamnu
9
Rongchik Mosu
10
Yadam Mosu
11
Yaw Mosu
12
Tarin Baki
13
Panam Mosu
14
Taching Gasar
15
Simate Laklam
16
Yaring Laklam
17
Tama Laklam
18
deke Laklam
19
Yadi Mosu
20
Joji Laklam
21
Yarem Laklam
22
Tarak Laklam
23
Yasuk Digiam
24
District: Upper Subansiri
Ningkia Eyum
1
Gichok Eyum
2
Oning Eyum
3

3130
1282
2892
1285
3403
3041
3188
3390
3234
3418
Circle: Siyum
3115
3332
2929
2913
Circle: Siyum
1235
730
657
762
2776
2788
2822
2922
2928
2881
2867
2905
2882
2866
729
267
2681
2870
1276
2927
2693
2684
1292
1255
Circle: Siyum
2761
2796
2777

21627
21305
21410
21548
21394
21140
21438
21038
21098
21704
Village: Gyate
21714
21306
21039
21394
Village: Laklam
21141
21197
21250
20985
21052
21216
21271
20975
21116
21120
21058
21208
20978
210724
21054
20440
21118
21384
21151
21101
20997
21010
21276
21191
Village: Eyum
21107
21235
20974

<!-- page 74 -->

Gopa Eyum
4
Josa Eyum
5
Karow Eyum
6
Papor Eyum
7
Ningke Eyum
8
Geiw Eyum
9
Decha Eyum
10
Dema Eyum
11
Kioji Eyum
12
Taling Eyum
13
Jichung Eyum
14
Sabu Eyum
15
Poyor Eyum
16
Losing Eyum
17
Ningpe Eyum
18
Tarak Eyum
19
Loknia Eyum
20
Lokri Eyum
21
Take Eyum
22
Kodak Eyum
23
District: Upper Subansiri
Pakpor Nalo
1
Lodam Nalo
2
Tokde Nalo
3
Ryabu Nalo
4
Kangio Nalo
5
Tania Cheke
6
Depa Nalo
7
Ake Nalo
8
Yajum Nalo
9
Tayi Nalo
10
Nyama Nalo
11
Kamsing Nalo
12
Dungpor Nalo
13
Jagpik Nalo
14
District: Upper Subansiri
Koji Rava
1
Yasu Rava
2
Tamen Rava
3
Tabio Rava
4
Tallar Rava
5
Tagi Rava
6
Yania Rava
7
Kude Singkom
8

2824
2804
2834
3173
3186
3087
3218
3173
3082
3329
3156
3408
3078
666
3469
3045
3387
3503
3397
3199
Circle: Siyum
1313
2689
1089
1087
1084
2778
2817
1304
1083
1316
1080
1078
2908
3215
Circle: Siyum
2791
2898
2874
2797
2723
2741
2925
2917

21170
21285
21046
21517
21635
21229
21436
20966
21049
21687
21575
21401
21534
21438
21706
21428
21718
21703
21540
21595
Village: Kangring
21041
21063
21066
20621
21206
20647
21225
20998
21259
21386
21028
21444
21402
21394
Village: Rava
21273
21205
21389
21403
21178
21160
21179
21145

<!-- page 75 -->

Gingning Rava
9
Tabu Sarta
10
Kesing Rqava
11
Tasi Rava
12
Yadam Rava
13
Yaga Rava
14
Law Rava
15
Yaning Rava
16
Marning Rava
17
Saga Rava
18
Ginglo Rava
19
Lodam Rava
20
Yama Rava
21
Byaning Rava
22
Tamcha Rava
23
Jitam Rava
24
Tara Pirong
25
Taliem Pirong
26
Tama Rava
27
Tato Rava
28
Tajen Rava
29
District: Upper Subansiri
Teni Papi
1
Sapor Papi
2
Sanam Siyum
3
Namngio Siyum
4
Gumsung Siyum
5
Kepu Siyum
6
Takam Siyum
7
Teluk Siyum
8
Yapar Siyum
9
Mari Siyum
10
Manjil Siyum
11
District: Upper Subansiri
Yanu kajiring
1
Taga Ekke
2
Tado Kajiring
3
Tajung Kajiring
4
Pew Kajiring
5
Taki Kajiring
6
Tapak Kajiring
7
Raki Siyum
8
Tamum Singkam
9
Kama Bogin
10

2902
2900
2921
2775
1243
2901
2805
2894
3521
3504
3530
3568
3518
3320
3302
3237
3004
2995
1094
2770
2821
Circle: Siyum
1121
1205
2759
1009
2678
1221
1071
1084
1021
1206
2616
Circle: Siyum
1274
1301
186
1244
2790
2774
1263
2931
2880
2861

21272
21279
21181
21211
21268
21478
21253
21196
21565
21045
21298
21581
21601
21642
20993
21227
21369
21501
20633
20620
21406
Village: Papi
20445
21014
21175
21329
20980
20147
21326
20123
20438
21544
21314
Village: Kajiring
20988
21257
21238
21017
20651
2102
21005
20992
21242
21093

<!-- page 76 -->

Talo Siyum
11
Tasar Siyum
12
Takam Kajiring
13
Yaw Siyum
14
Tara Pirong
15
Yade Kajiring
16
Tai Kajiring
17
Yawa Kajiring
18
Kamchu Rama
19
Tabe Bagina
20
Raj Pirong
21
District: Upper Subansiri
Takom Taring
1
Taku Taring
2
District: Upper Subansiri
Tadom Mosu
1
Tadam Degiam
2
Tadong Degiam
3
Kerak Degiam
4
Tadik Mosu
5
Talok Degiam
6
Tasing Degiam
7

2862
1275
2907
2875
2828
2816
2979
2781
2814
2827
2784
Circle: Siyum
1274
1301
Circle: Siyum
1250
2878
2818
2888
2895
1251
2668

21182
21188
21128
21139
21154
21570
21161
21026
20627
21215
2125
Village: Taring
20988
21257
Village: Degiam
21477
21172
21146
21099
21001
20991
21222

BENEFICIARY LIST OF WEST SIANG DISTRICT
VILLAGE : Sirom
BENEFICIARY : 20 Nos.
Sl. No.

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15

Name of the Beneficiary

Shri Dadu Yabu
Shri Gobe Lipo
Shri Taso Lipo
Shmt. Meyi Pamo
Shri Mame Pame
Shri Tabin Lipo
Shri Tape Taring
Shri Ashok Yabu
Shri Tayi Tatin
Shri Koli Tatin
Shri Tamet Papin
Shri Take Tatin
Shmt Yaro Lipo
Shri Boru Hango
Shri Babe Tayi

Module No.

Battery No.

Certificate No.

11054
10770
11460
11304
10622
10765
10793
10607
10704
10554
11434
11461
11416
11431
11420

15967
15646
15601
15777
15918
15628
15641
16025
15575
16077
15418
15511
15888
15844
15504

1151
1152
1153
1154
1155
1156
1157
1158
1159
1160
1161
1162
1163
1164
1165

<!-- page 77 -->

Shri Kancha Yorchi
16
Shri Taje Yabu
17
Shri Tamon Yangyi
18
Shri Tabom Yinyo
19
Shri Tajor Yorplu
20
VILLAGE : NEW BOGNE VILLAGE

11477
11467
11492
11523
11513

15912
1166
15953
1167
15959
1168
15505
1169
15626
1170
BENEFICIARY : 15 Nos.

Name of the Beneficiary
Sl. No.
Shri Talem Tading
21
Shri Tapor Tamut
22
Shri Talong Taggu
23
Shri Taper Nyigang
24
Shri Tapang Pabin
25
Shri TApik Taga
26
Shri Taku Tali
27
Shri Tapang Pago
28
ShriTakar Pabin
29
Shri Tamar Tamut
30
Shri Mutor Tamut
31
Shri Tater Taboh
32
Shri Tabuy Taboh
33
Shri Tanying Tasing
34
Shri Tapum Taga
35
VILLAGE : TUYING VILLAGE

Module No.
Battery No.
Certificate No.
11401
15981
152
11417
15841
153
10780
15446
773
11745
15798
774
10665
15385
772
11393
15451
770
11462
15892
771
11390
15788
768
11450
15496
769
11316
16009
759
10778
15427
760
10540
15405
757
10843
15979
761
11576
15429
763
11577
16023
764
CIRCLE :TATO
BENEFICIARY: 18Nos.

Sl. No. Name of the Beneficiary
Shri Taken Pago
36
Shri Tali Pallo
37
Shri Tamang Tadi
38
ShriTabi Yamir
39
Shri Tajong Palong
40
Shri Taling Tadi
41
Shri Tarung Yaying
42
Shri Tameng Tali
43
Shri Tai Reying
44
Shri Tale Pabin
45
Shri Tape Jehang
46
Shri Tabeng Palong
47
Shri Tano Jomyang
48
Shri Tapak Pano
49
Shri Tamok Pabin
50
Shri Taling Dupu
51
Shri Tabang Dupu
52
Shri Tai Yuto
53
VILLAGE : YIO VILLAGE
Sl. No. Name of the Beneficiary

Module No.
1809
1800
1948
11479
11495
11167
11203
11109
11197
11201
11404
10557
10749
10663
10541
11568
11554
11590
Module No.

Battery No.
Certificate No.
15426
1171
15845
1172
15639
1173
16065
1174
15945
1175
15922
1176
15471
1177
15573
1178
15378
1179
15420
1180
15537
1181
15578
1182
15559
1183
15544
1184
15436
1185
15490
1186
16015
1187
15533
1188
BENEFICIARY : 26 Nos.
Battery No.
Certificate No.

<!-- page 78 -->

Shri Tarang Tabang
54
Shri Tadik Tabang
55
Takot Kamin
56
Shri Tadeng Taring
57
Shri Taba Tabang
58
Shri Tabat Tabang
59
Shri Tadut Tabang
60
Shmt Yamen Taring
61
Shri Talen Taring
62
Shri Tadik Taring
63
Shri Takong Kamin
64
Shri Tasi Tayor
65
Shri Tageng Tayor
66
Shmt Yachen kamin
67
Shri Tayor Yasing
68
Shmt Yame Tabang
69
Shri Taber Tayor
70
Shri Tabong Yasing
71
Shri Tasong Taring
72
Shri Taking Taring
73
Shri Tadik Yasing
74
Shri Tape Tayor
75
Shri tapu Tayor
76
Shri Tareng Tayor
77
Shmt Yayor Tayer
78
Shri Tadik Kamin
79
VILLAGE : ROW VILLAGE
Name of the Beneficiary
Sl. No.
Shri Takeng Yapi
80
Shri Tachuk Yamir
81
Shri Taru Lipo
82
Shri Taken Ngomdir
83
Shri Tachon Hiba
84
Shri Takir Yamir
85
Shri Purang Pame
86
Shri Tatin Yamir
87
Shri Minung Lipo
88
Shmt Yaki Yamir
89
Shri Tarong Yapi
90
Shri Tabor Yapi
91
VILLAGE : PAYUM VILLAGE
Name of the Beneficiary
Sl. No.
Shri Take Ngurak
92
Shri Tade Ngurak
93

10899
15653
1101
10905
15799
1102
10721
15409
1103
10835
15362
1104
10630
15760
1105
11495
16054
1106
11512
16024
1107
11502
16038
1108
11485
15457
1109
11503
16079
1110
11473
15615
1111
11499
15609
1112
11501
15542
1113
11500
15884
1114
11522
15852
1115
10621
15770
1116
11332
16075
1117
10796
15540
1118
10788
15549
1119
10785
15464
1120
10589
15617
1121
10565
15635
1122
10601
16040
1123
10760
15614
1124
10619
15472
1125
11413
16046
1126
CIRCLE:- PAYUM
BENEFICIARY: 12Nos.
Module No.
Battery No.
Certificate No.
11308
15434
1127
10776
15612
1128
11320
15623
1130
11338
15437
1131
10652
15785
1132
10548
15633
1133
10553
15966
1134
11435
15364
1135
11441
15975
1136
10588
15394
1137
11415
15406
1138
11410
15634
1139
CIRCLE:- PAYUM
BENEFICIARY:24Nos.
Module No.
Battery No.
Certificate No.
775
15812
501
644
15674
502

<!-- page 79 -->

Shri Tabe Ngurak
94
Shmt Yama Ngurak
95
Shri Tali Yuto
96
Shri Tanyi Yuto
97
Shri Taleok Yuto
98
Shri Toyi Yuto
99
Shri Tapor Taket
100
Shri Tabin Yuto
101
Shri Tali Yorme
102
Shri Tadik Yuto
103
Shri Tapar Yuto
104
Shri Tatin Yuto
105
Shri Tayi Yuto
106
Shri Tali Tada
107
Shmt Yagum Yuto
108
Shmt Yari Yassing
109
Shmt Yamari Yorbo
110
Shri Tachuk Ngorek
111
Shri Take Yuto
112
Shri Toje Yuto
113
Shri Tagin Ngurek
114
Shri Tachung Ngurek
115
VILLAGE : HIRGO VILLAGE
Name of the Beneficiary
Sl. No.
Shri Tatu Tangu
116
Shri Taluk Tangu
117
Shri Taluk Kiri
118
Shri Tai Hili
119
Shri Kadu Tangu
120
Shri Taduk Kiri
121
Shri Tate Kiri
122
Shmt Yapik Harso
123
Shri Tapi Kiri
124
Shri Tate Jida
125
Shri Taso Jida
126
Shmt Yapi Yorme
127
Shri Tatu Jida
128
Shri Tara Jida
129
Shri Tai Jida
130
Shri Tachuk Tanga
131
Shri Talam Kiri
132
Shmt Yago Kiri
133
Shmt Yayum Hiba
134
Shri Lipo Jida
135

545
566
640
791
616
1421
730
789
816
1376
1486
1525
1504
1488
1480
1507
1475
1811
1585
1700
1569
783
Module No.
1367
1376
578
570
560
1298
1096
1221
1484
1248
6066
558
714
576
567
672
787
694
631
702

15891
503
15998
504
15802
505
15980
506
15595
507
15856
508
15488
509
15832
510
16060
511
15986
512
15594
513
15948
514
16004
515
15991
516
15977
517
16022
518
15629
519
15662
520
15990
521
15983
522
16044
523
15903
524
BENEFICIARY: 35Nos.
Battery No.
Certificate No.
15550
525
16074
526
16013
527
15786
528
15664
529
15498
530
15778
531
16064
532
15455
533
15829
534
16056
535
15424
536
15608
537
15916
538
15964
539
15371
540
15497
541
15410
542
15468
543
15957
544

<!-- page 80 -->

Shri Tadik Jida
136
Shri Tali Jida
137
Shri jambe Jida
138
Shri Tape Jida
139
Shri Tama Jida
140
Shri Tapek Jida
141
Shri Tasar Jida
142
Shri Tanam Hili
143
Shri Tacher Hili
144
Shri Tatu Kiri
145
Shri Tanya Kiri
146
Shri Tate Hili
147
Shri Tapu Kiri
148
Shri Tape Kiri
149
Shri Tabin Kiri
150
VILLAGE : YAPU VILLAGE
Name of the Beneficiary
Sl. No.
Shri Tami Hiba
151
Shri Tapik Hiba
152
Shri Tachap Hiba
153
Shri Tayi Hiba
154
Shri Tagi Hiba
155
VILLAGE : QUYING VILLAGE
Name of the Beneficiary
Sl. No.
Shri Line Ragyor
156
Shmt Yaluk Ragyor
157
Shri Porchi Ragyor
158
Shri Tagi Padu
159
Shri Tadik Lipo
160
Shri Tayor Raksap
161
Shri Clussum Raksap
162
Shri Tori Raksap
163
Shri Tato Raksap
164
Shri Tadik upet
165
Shri Game Raksap
166
Shri Gampe Raksap
167
Shri Pordik Raksap
168
Shri Porgam Raksap
169
Shri Botu Raksap
170
Shri Lipo Raksap
171
Shmt Yacha Raksap
172
Shri Tago Raksap
173
Shmt Yanya Ragyor
174
Shri Tachu Raksap
175

794
15492
545
1374
15964
546
609
16069
547
598
15944
548
1552
15558
549
572
15809
550
614
16026
1051
662
15917
1052
612
15978
1053
610
16034
1054
1334
16050
1055
1458
15381
1056
1452
15598
1057
1333
15448
1058
1340
15811
1059
CIRCLE :- TATO
BENEFICIARY: 5Nos.
Module No.
Battery No.
Certificate No.
654
16020
1060
718
15404
1061
602
15524
1062
574
15502
1063
655
15441
1064
BENEFICIARY: 24Nos.
Module No.
Battery No.
Certificate No.
696
15993
1065
1186
15796
1066
1262
15541
1067
597
15643
1068
1496
15460
1069
1264
15789
1070
1454
15499
1071
650
15399
1072
1464
15435
1073
1388
15782
1074
4403
15481
1075
1468
15377
1076
1464
15459
1077
1426
15521
1078
1411
15950
1079
1321
15495
1080
1409
15379
1081
1481
15452
1082
1487
15345
1083
1463
15842
1084
