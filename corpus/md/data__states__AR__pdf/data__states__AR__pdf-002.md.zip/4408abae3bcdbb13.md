---
doc_id: "4408abae3bcdbb13"
source_url: "https://eodb.arunachal.gov.in/uploads/policyguideline_documents/372c85f0aed6811886a537b9d0ac2dac.pdf"
ministry: "Arunachal Pradesh Investment Portal"
title: "Land Settlement And Records Act, 2000   Planning & Investment  -->    -->"
date: ""
pages: 29
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d3a6e5d09c1eb57c"
---

<!-- page 1 -->

GOVERNMENT OF
ARUNACHAL PRADESH

The Arunachal Pradesh (Land Settlement
And Records) Act, 2000

LAND MANAGEMENT DEPARTMENT
ITANAGAR

Published in the Gazette of Arunachal Pradesh No. 80, Vol-X
dated November 17,2000

<!-- page 2 -->

(1)
CHAPTER I
PRELIMINARY
(1)This Act may be called the Arunachal Pradesh (Land Settlement and
Records) Act, 2000.

Short title

extent and
(2)It extends to the whole of the State of Arunachal Pradesh.
commence
(3)It shall come into force on such date as the Government may, by notifica ment
tion in the Official Gazette appoint, and different dates may be appointed
for different areas and for different provisions of this Act.
2.

In this Act, unless the context otherwise requires:(a)"Agriculture" includes horticulture, the raising of annual or periodical
crops or garden produce, dairy farming, poultry farming, stock breeding
and grazing pisciculture;
(b)"Commencement of this Act" in relation to any provision, means the
date specified in respect of that provision i.e. a notification issued under

sub-section (3) of section 1;
(c)"Common Land" means any land used or reserved for the common use
of a community or a village;
(d)"Community" means residents of a village as a whole and includes a
clan, sub-clan, kindred;
(e)"Competent Authority" in relation to any provision, means any officer

appointed by the Governor to be the competent authority for the purpose
of that provision;
(f)"Deputy Commissioner" means the Deputy Commissioner in charge of
a district,
(g)"Government" means the State Government of Arunachal Pradesh;
(h)

"Government land" means land acquired by the Government under Land
Acquisition Act or through donation of the public for establishment of
Administrative Headquarter, Government Institutions and facilities un
der various wings of the Government or such land as defined under Sec
tion-9.

(i)

"Improvement" in relation to any land, means any work which materi

ally adds to the value of the land and which is suitable to the land and
consistent with the character thereof, and includes:(i)

the construction of tanks, wells, water channels and other works
for the storage, supply and distribution of water for agricultural
purposes or for the use of man and cattle employed in agriculture;

(ii) the construction of works for the drainage of land or for the protec
tion of land from floods or from erosion or from other damage by
water;
(iii) the preparation of land for irrigation;
(iv) the conservation of one crop land into two-crop land;

Definitions

<!-- page 3 -->

(2)
(v)

the reclaiming, clearing, enclosing, levelling or terracing of land used for agricul
tural purpose;

(vi) the erection on land or in the immediate vicinity thereof otherwise than on the
village site, of a building or house for the occupation of the tenant, his family and
servants or a cattle shed, a store-house or other construction for agricultural pur
poses or of any building required for the convenient or profitable use or occupation

of the land; and
(vii) the renewal or reconstruction of any of the foregoing works or such alteration
therein or addition thereto as are not of the nature of ordinary repairs;
(j)

"Jhum land" means Jhum land as defined in clause (b) of section 2 of the Balipara,

Tirap, Sadiya Frontier Tracts Jhum land Regulation, 1947 (Regulation 3,4 & 5 of 1947).
(k)

"Holding" means a parcel of land separately assessed to land revenue;

(1)

"Land owner" in relation to any land means a person who acquires rights of
ownership in respect of such land by:(i)inheritance or acquisition in accordance with a local custom,

(ii)purchase, if such purchase is not contrary to local customs;

(iii)gift or donation as per local custom;
(iv)according to provisions under section 88;
(m) "Pay" "payable" and "payment**, used with reference to rent; include "deliver", "deliv
erable" and "delivery".
(n)

"Person under disability" means

(i) a widow;
(ii) a minor;
(iii) a woman who is unmarried or who, if married, is divorced or judicially separated
from her husband or whose husband is a person falling under clause (iv) or (v)
(iv) a member of the Armed Forces of the Union;
(v) a person incapable of cultivation by reason of physical or mentaldisability;
(o)

"Personal cultivation" with its grammatical variations and cognate expressions means
cultivation by a person on his own account: (i)

by his own labour, or

(ii) by the labour of any member of his family; or
(iii) by servants or by hired labour on wages payable in cash or in kind but not as a share
of produce under his personal supervision or any personal supervision of any member of

his family;

<!-- page 4 -->

(3)
(p) "Public purpose" includes a purpose connected with settlement of land
with cultivators, tenants ejected as a result of resumption, landless agri
cultural workers or co-operative farming societies;
(q) "Revenue" means any revenue assessed by the Government on an estate
and shall always be deemed to have included any tax assessed in lieu of land
revenue.
(r)

"Rent" means whatever is lawfully payable by a tenant to the Land lord
in cash or in kind or partly in cash and partly in kind, whether as a fixed
quantity of produce or as a share of produce, on account of the use or
occupation of land or on account of any right in land but shall not include
land revenue;

(s) "Resident" means an indigenous person ordinarily residing in a village
or area;
(t)

"Tenant" means a person who cultivates or holds the land of another
person under an agreement, expressed or implied, on condition of paying
rent in cash or in kind or delivering a share of the produce;

(u)

"Village" means any tract of land which before the commencement of
this Act was recognized as or was declared to be a village under any law
for the time being in force or which may after such commencement be
recognized as a Village at any settlement or which the State Government may,
by notification in the official Gazette, declare to be a village;

(v)

"Village authority" and "Village council" means a Village authority
and council as constituted in accordance with or under any statutory law
for the time being in force or under any local custom respectively;

(w) "Year** means the agricultural year commencing on such date as the
Government may, in the case of any specified area, by notification in the
Official Gazette, appoint.

CHAPTER n
REVENUE DIVISIONS, REVENUE OFFICERS AND OTHER APPOINTMENTS
3.(1)

(2)

The State Government may, by notification in the Official Gazette, di
Power to
vide the territories to which this Act extends into one or more Revenuecreate, alter
districts, and may similarly divide any Revenue district into sub-divior abolish
sions and blocks and may alter the limits of, or abolish any RevenueRevenue
district, sub-division or blocks.districts,
sub-diviThe districts, sub-divisions and block existing at the commencement ofsions etc.
this Act shall continue respectively to be districts, sub-divisions and blocks
under this Act unless otherwise provided under sub-section (1).

4.The Government or such officer as may be authorized by the Government in Appointthis behalf, may appoint the following classes of Revenue Officers, namely:- ment of
(a)Revenue Commissioner (ex-officio);Revenue
(b)Deputy Commissioner;Officers
(c)Additional Deputy Commissioner;
(d)Director of Settlement and land Management;

(e)Sub-divisional Officers/EAC;

<!-- page 5 -->

(4)
(f)Circle Officer/BDO,
(g)Deputy Director or Assistant Director, Officer Surveyor of Settlement and
Land Management,
(h) Survey and Settlement Officers;
(i) Assistant Survey and Settlement Officers, Plane- 'fablers,
(j) Supervisor Kanungos/Recorder Kanungos;

(k) Mandals; and Chairman
(1) Such other village officers as may be appointed by order made under this
Act.
Deputy5.
Commissioner
and certain
other Revenue

Officers

(1)Each districts shall be placed under the charge of a Deputy Commissioner
who shall be in charge of the revenue administration of the district and
exercise the powers and discharge the duties of the Deputy Commissioner
under this Act or any other law for the time being in force and shall exer
cise so far as is consistent therewith such other powers of superintendence
and control within the district and over the officers subordinate to him as
may from time to time be prescribed.

(2)The Additional Deputy Commissioner shall exercise all such powers and
perform all such duties of the Deputy Commissioner or other Revenue
Officer as the State Government may specify by notification in the official
Gazette.
(3)Each Sub-division shall be placed under the charge of a sub-divisional
officer/Extra Assistant Commissioner.

(4)Each circle or block shall be placed under the charge of a Circle Officer or
a Block Development Officer as the case may be.
(5)The duties and powers of the sub-divisional officers, the Circle Officers
and other Revenue Officers shall be such as may be imposed or con
ferred on them by or under this Act or any other law in force for the time
being or any general or special order of the Government published in the

official Gazette in this behalf.
Settlement
6.
The officers specified in terms iM. (b),JcHd) and ^e^>rSection 4 shall liave^
Officerspower to take cognizance of all matters connected with* the survey of land and
the settlement of the revenue-rates and the preparation and maintenance of land
records and other registers and shall exercise all such powers and perform all
such functions and perform all such duties as may be prescribed by or under this
Act or by any general or special order of the Governor published in the official
Gazette.
Combination 7.

n shall be lawful for the Government to appoint one and the same person by

of officersvirtue of office to any two or more assignments provided for in this Chapter,
and to confer on any officer of the Government all or any of the powers and
duties of any of the revenue officers including that of the Deputy Commis
sioner.
Seals8.

The Governor shall, from time to time, by notification in the official Gazette,
specify the revenue officers who shall use Seal and also the size and description
of Seal which each such officer shall use.

CHAPTER III

RIGHTS OVER LAND
Title of lands 9.

(1) All lands, public roads, lanes and paths and bridges, ditches, dikes, and fences

etc.on or beside the same, the beds of rivers, streams, nallahs, lakes and tanks, and
all canals and water courses and all standing and flowing water, and rights in or
over the same or appertaining thereto, which are not the property of any person
or community are hereby declared to be the property of the Government.

<!-- page 6 -->

(5)
(2) Unless it is otherwise expressly provided in the terras of grant made
by the Government, the right to mines, quarries, mineral products
including mineral oil, natural gas and petroleum shall vest in the Gov
ernment, and it shall have all the powers necessary for the proper
enjoyment of such rights.
10.(1)

The right to all trees, jungles or other natural products growing on land Government's
set apart for forest reserves and all trees, brush wood, jungle or other right to trees,
natural product, wherever growing, except in so far as the same may be forest etc.
the property of any person or community, vests in the Government, and
such trees, brush wood, jungle or other natural product shall be pre
served or disposed of in such manner as may be prescribed, keeping in
view the interests of the people in the area with regard to the user of the
natural products.

(2) All road side trees which have been planted and reared by or under the
orders or at the expense of the Government and all trees which have
been planted an reared at the expense of local authorities by the side of
any road belonging to the Government vest in the Government.
11.Subject to rules made in this behalf under this Act, the Deputy Commis Assignment of
sioner, may set apart land belonging to the Government for pasturage for the land for special
village cattle, for forest reserves or for any other purpose.purposes
12.(1) The Deputy Commissioner may allot land belonging to the Govern Allotment of
ment for agricultural purposes or for construction of dwelling houses, Government
in accordance with such rules as may be made in this behalf under ]an{j ^or ^gri'his Act,cultural

and

(2)The Government shall have power:-poseS'"^
(a)to allot any such land for the purpose of an industry or for any pur
pose of public utility on such conditions as may be prescribed or
(b)to entrust the management of any such land or any rights therein
to the Gram Panchayat of the village established under any law for
time being in force.
(3)The rules made under sub^ections (1) and (2) for allotment of land
shall provide for giving preference to the members of the co-operative
farming societies formed by marginal farmers, landless agricultural
labourers, in allotting land.
13.(1)

All lands, to whatever purpose applied, are liable to payment of land Liability of land
revenue to the Government.to land revenue

(2) The Government may exempt any land from the liability to such
payment by means of special grant or contract or in accordance with
the rules made under this Act.

14.All alluvial lands, newly formed islands, orabandoned river beds, which vest Alluvial land
under any law for the time being in force in any holder of land shall be sub
ject in respect of liability to land revenue to the same privileges, conditions
and restrictions as are applicable to the original holding by virtue of which
such lands, islands or river beds vests in the said holder, but no revenue shall
be leviable in respect of any such lands, islands or river beds unless the area
of the same exceeds 5 (five) acre.

<!-- page 7 -->

(6)

Land Reve ue
J5. Every Holder of land paying land revenue in respect thereof shall beenin case oftitled subject to such rules as may be made in this behalf, to a decrease of
diluvionassessment if any portion thereof, not being less than one acre in extent, is
lost by diluvion.
Assessment of
16. (1) The assessment of land revenue on any land shall be made or deemed
land to landto have been made with respect to the use of the land.
revenue
(a)for purposes of agriculture,
(b)for industrial or commercial purposes,
as sites for dwelling houses, and,
for any other purposes,
(2)

Where land assessed for use for any one purpose is diverted to any
other purpose, the land revenue payable upon such land shall, not
withstanding that the term for which the assessment may have been
fixed has not expired, be liable to be altered and assessed at a differ
ent rate in accordance with the rules made under this Act.

Diversion of17, (i) If any person holding land for any purpose wishes to divert such land
land for otheror any part thereof to any other purpose except agriculture, he shall
purposes.apply for permission to the competent authority which may, subject
to the provisions, of this section and to the rules made under this Act,
refuse permission or grant it on such conditions as it may think fit.
(2)Permission to divert, may be refused by the competent authority, only
on the ground that the diversion is likely to cause a public nuisance
or that it is not the interest of the general public or that the holder is
unable or unwilling to comply with the conditions that may be im
posed under sub-section (3).
(3)Conditions may be imposed on diversion for the following objects
and no others namely in order to secure the public health, safety and
convenience, and in the case of land which is to be used as building
sites, in order to secure, in addition, that the dimensions, arrange
ment and accessibility of the sites are adequate for the health and
convenience of occupiers or are suitable to the locality.
(4)If any land has been diverted without permission by the holder or by
any other person with or without the consequent of the holder, the
competent authority, on receiving information thereof, may impose
on the person responsible for the diversion, a penalty not exceeding
Five hundred rupees, and may proceed in accordance with the provi
sions of sub-section (1) as if an application for permission to divert
had been made.
(5)If any land has been diverted in contravention of an order passed or
of a condition imposed under any of the foregoing sub-sections, the
competent authority may serve a notice on the person responsible for
such contravention, directing him, within a reasonable period to be
stated in the notice, to use the land for its original purpose or to ob
serve the condition; and such notice may require such person to re
move any structure, to fill up any excavation, or to take such other
steps as may be required in order that the land may be used for its
original purpose, or that the condition may be satisfied, and the
competent authority may also impose on such person a penalty
not exceeding Five hundred rupees for such contravention and a
further penalty not exceeding ten rupees for each day during which
such contravention continues.
Explanation: - "Diversion" in this section means using land for the purpose
of agriculture where it is assessed with reference to any other
purpose shall not be deemed to be diversion.

<!-- page 8 -->

18.The Government may, in accordance with the rules made in this behalf
under this Act, grant a remission or suspension of land revenue in such
year or years in which crops have failed in any particular notified area.
19.(1)

Remission or suspensi^n of revenue
on failure ofcrops.

The following persons shall be primarily liable for the payment of Responsiblity
land revenue assessed on land, namely,for payment of
land revenue.
(a)the person to whom the land belongs;
(b)the tenant or any person in possession of the land, provided
that such tenant or other person shall be entitled to credit from
the owner of the land for the amount paid by him.

(2) Where there are two or more persons liable to pay revenue under
sub-section (1), all of them shall be jointly and seperately liable for
its payment.
20.Everyrevenueofficerreceivingpaymentoflandrevenueshall.atthetime Receipt for land
when such payment is received by him, give a written receipt for the same, revenue

CHAPTER IV
SORVEY AND SETTLEMENT OF LAND REVENUE
21.The operations carried out in accordance with the provisions of the chapDefinitions of
ter in order to determine or revise the land revenue payable on lands in"revenue survey"
any local area are called a "revenue survey", the results of the operations"settlement"
are called a "settlement" and the period during which such results are toan(j term of
be in force is called the "term of settlement"."settlement"
22.(1)

As soon as may be after the commencement of this Act, the Govern
ment shall take steps to institute and shall cause to be constantly
maintained, in accordance with the rules made under this Act, an
inquiry into the profits of agriculture and into the value of land used

Inquiry into
profits of
agriculture,

for agricultural and non-agricultural purposes.
(2)

For the purpose of determining the profits of agriculture, the fol
lowing matters shall be taken into account in estimating the cost of
cultivation, namely:
(a)the depreciation of stock and buildings;
(b)the money equivalent oflhc labour and supcr-ision by the cultivator and

his family;
(c)all other expenses usually incurred in the cultivation of the
land which is under inquiry; and
(d)interest on the cost of buildings and stock, on all expenditure
for seed and manure and on the cost of agricultural operations
paid for in cash.
23.Whenever the Government thinks it expedient so to do, it may by notifica
tion in the official Gazette, direct the revenue survey of any local area with
a view to the settlement of the land revenue and to the preparation of a
record of right connected therewith or the revision of any existing settle
ment or record of rights.

Revenue
Survey

<!-- page 9 -->

Power to
require assistance

from land holders

(8)

24.A survey officer deputed to conduct or take part in any revenue survey
may, by special order or by general notice to be published in the pre
scribed manner, require the attendance of holders of lands to assist in the
measurement or classification of the lands to which the revenue survey
extends and, when hired labour is employed for purposes incidental to
the revenue survey, may assess and apportion the cost thereof on the lands
surveyed, for collection as land revenue due on such lands.

Survey
numbers and

villages

25.Subject to the rules made in this behalf under this Act, the survey officer
may:-

(a)divide the land to which the revenue survey extends into villages
and the villages into plots survey numbers; and
(b)recognize the existing village and survey numbers, reconstitute
them or form new survey numbers.

Division of
survey numbers
into sub-divisions

26.The Survey Officer may sub-divide survey numbers into as many sub
divisions as may be required in the manner prescribed.

Preparation of

27. It shall be the duty of the survey officer or the settlement officer on the

settlement and
other records

occasion of making or revising a settlement of land revenue to prepare a
register to be called the "settlement register", showing the area and as
sessment of each survey number, with any other particulars that may be
prescribed, and other records in accordance with such orders as may,
from time to time, be made in this behalf by the Government.

Determination
28. (1) The Government may at any time direct the determination or the
of revenuerevision of the revenue-rates for all lands in any area of which a
ratesrevenue survey has been made.
(2) For the purpose of determining the revenue rates, the settlement
officer may divide any area into units and in forming such units, he
shall have regard to the physical features, agricultural and economic
conditions, and shall then determine the revenue-rates for different
classes of lands in each such unit in the manner prescribed and in
particular, in the case of agricultural land, to the profits of agricul
ture, to the consideration paid for leases, to the market prices of
land to the principal monies on mortgages and in the case of nona
gricultural land, to the value of the land for the purpose for which it
is held.
Publication of
29. (1) The settlement officer shall prepare a table of revenue- rates in the pre
table revenuescribed form and publish it in the prescribed manner fot theprescribed
ratesperiod
(2)Any person objecting to any entry in the table of revenue may present
petition in writing to the settlement officer within the prescribed
period and the settlement officer shall consider such objections
after giving a hearing to the objector.
(3)The Settlement officer shall submit the table of revenue-rates to the
Government together with a summary of objections, if any, his de
cisions on such objections and a statement of the grounds in sup
port of his proposals.

<!-- page 10 -->

30.(1)

(9)

The Government may confirm the table of revenue rates submittedConfirmation of the
to it by the settlement officer with such modifications, if any, astable of revenue rates
it may consider necessary.

(2)

The table of revenue-rates confirmed under sub-section (1) shall
be finally published in the official Gazette.

31.The table of revenue-rates published under section 29 shall be incor Rates of revenue to
porated in and form part of the settlement register of the village.form part of settle
ment register.
32.When the revenue-rates are determined under this chapter in respect inlrj,,^,:_ „ ,„„
fiinir^^r ii- r ainirouucuun 01 revof any area, such rates shall take effect from the beginning of the year enue ra^es
next after the date of final publication of the table of revenue rates
under section 29.
33.(1) When the table of revenue-rates for any area has been finally Duration of
published, the rates specified therein shall remain in force for a revenue rates
period of thirty years.
(2)

Notwithstanding any thing contained in sub-section (1)(a). revenue-rates may be altered or revised in any year after
the expiry of every ten years from the date on which the
table of revenue-rates was introduced, in such manner and
to such extent as may be prescribed;
(b)When the circumstances of a local area are such that a fresh
determination of the revenue-rates is in the opinion of the
Government inexpedient, it may extend the term of settle
ment by such further period as it may think necessary.

34.(1)

The settlement officer shall calculate the assessment on each hold- Assessment on
ing in accordance with the revenue-rates confirmed and finally holding
publish under section 30 and such assessment shall be the fair
assessment.

(2)The settlement officer shall have the power to make fair assess
ment on all lands whatsoever to which the revenue-survey ex
tends, whether such lands are held with liability to pay full land
revenue or land revenue at concessional rates or are held revenue
free.
(3)The fair assessment of all lands shall be calculated in accordance
with rules made in this behalf and having regard to the following
principles, namely:(a)no regard shall be had to any claim to hold land on privi
leged terms;
(b)regard shall be had in the case of agricultural land to the
profits of agriculture, to the consideration paid for leases,
to the market prices of land and to the principal monies on
mortgages, and in the case of non-agricultural land, to the
value of the land for the purpose for which it is held;
(c)where any improvement has been effected any time in any
holding held for the purpose of agriculture by or at the ex
pense of the holder thereof, the fair assessment of such
holding shall be fixed as if the improvement had not been
made.

<!-- page 11 -->

(10)

Additional as- 35.
sesstnent of water
advantages

Continuance
of Survey

36.

Notwithstanding anything contained in this Chapter, all survey operations com
menced under any law, executive or procedural instructions for the time
being in force and continuing at the commencement of this Act shall be
deemed to have been commenced and to be continuing under the provi
sions of this chapter, and all revenue-rates in force at such commencement
shall be deemed to have been determined and introduced in accordance
with the provisions of this chapter and shall remain in force until the intro
duction of revised revenue-rates and such revised revenue rates may be
introduced at any time, notwithstanding anything contained in section 32.

37.

(1)The powers and duties exercisable by the officers referred to in sec
tion 6 may also be exercised during the term of settlement, by the
Deputy Commissioner or such other revenue officer as may be speci
fied by the Government for the purpose, by notification in the official
Gazette.

operations and
rates in
force at the com
mencement of
the Act.

Power of

Notwithstanding anything contained in this chapter, the Government may
direct that any land in respect of which the rate of revenue has been de
termined shall be liable to be assessed to additional land revenue during
the term of the settlement for additional advantages accruing to it from
water received on account of irrigation works or improvements in exist
ing irrigation works completed after the table of revenue-rates came into
force and not affected by or at the expense of the holder of the land.

Deputy
Commissioner
to correct
errors etc.

(2)The Deputy Commissioner, may, at any time during the term of settle
ment, correct any error in the area or the assessment of any survey
number or sub-division due to a mistake of survey or arithmetical
miscalculation.

CHAPTER V
LAND RECORDS
Preparation of
record of

38.

rights

It shall be the duty of the survey officer to prepare a record of rights for
each village showing the area of each survey number and other particulars
and any other record or register, in accordance with the rules made under

this Act:
Provided that where for any reason a record-of rights cannot be pre
pared in respect of the entire village it shall be lawful for the survey officer
to prepare separate records-of-rights for different areas of such village and
notwithstanding anything contained in this Act or any rule made thereun
der, a record-of-rights, when finally published shall not be called in ques
tion in any court on the ground that it was not prepared in respect of the
entire village.

Publication
of the record of

rights

39.

(1)When a record of rights has been prepared, the survey officer shall
publish a draft of the record in such manner and for such period as
may be prescribed and shall receive and consider any objections which
may be made during the period of such publication, to any entry
therein or to any omission therefrom.
(2)When all objections have been considered and disposed of in accor
dance with the rules made in this behalf, the survey officer shall call
thececord to be finally published in the prescribed manner.

(3)Every entry in the record of rights as finally published shall, until the
contrary is proved, be presumed to be correct.

<!-- page 12 -->

(11)
40.The Village council and Civil courts shall have jurisdiction to decide any

Jurisdiction

dispute which is recorded in the record of rights.
41.The survey officer may, on application made to him in this behalf or on his Correction of
own motion, within one year from the date of jfinaLouhlicatioiiof th&xecord __ bonafide misof rights, correct and enter in such record which he is satisfied that it is been take in register
made owing to a bonafide mistake.
42.

(1)As soon as may be after survey and settlement, the Revenue officer
shall prepare and publish in the prescribed manner a draft field index
in respect of every plot in a village recording the status of the actual
possessor and the conditions on which he holds the land and shall fix
a date not less than fifteen days from the date of such publication,

Preparation of
field index.

for filling claims and objections.
(2)The Revenue Officer, shall after giving the persons who have filed
claims and objections and also the persons whose interests are likely
to be affected, an opportunity of being heard, prepare the field index
and publish it in the prescribed manner.
43.

Notwithstanding anything herein before contained an entry regarding the
status of the actual possessor of a plot and the conditions on which he holds
the land in the field index as finally published shall, in case of conflict with
an entry in the record-of-rights, prevail and be transferred to the record-ofrights tor correction of such record under certificate of such officer as may

Decision as to
conflict in any
case

be prescribed in this behalf.
(1)There shall be maintained for every village a register of mutations in
44.

such form as be prescribed.
(2)Any person acquiring by succession, survivorship, inheritance, parti
tion, purchase, gift, mortgage, lease or otherwise any right in land or,
where such person acquiring the right is a minor or, where such per
son acquiring the right in land or otherwise disqualified, his guardian
or other person having charge of his property, shall report his acqui
sition of such right to the Revenue officer within three months from
the date of such acquisition and the Revenue officer shall give at once
a written acknowledgement in the prescribed form for such report to
the person making it.
(3)The Revenue officer shall enter the substance of every report made to
him under sub-section (2) in the register of mutations and also make
an entry therein respecting the acquisition of any right of the kind
mentioned in sub-section (2) which he has reason to believe to have
taken place and of which a report has not been made under said sub
section and at the same time, shall make or paste up a complete copy
of the entry in a conspicuous place in the village and snail give a
written intimation to all persons appearing from the record of rights
of the register of mutations to be interested in the mutations and to
any other person whom he has reason to believe to be interested
therein.
(4)Should any objection to an entry made under sub-section (3) in the
register of mutations be made either orally or in writing to the Rev
enue Officer, he shall enter the particulars of the objection in the
prescribed form and furnish a copy of same for the objection to the
person making it.

(5)The objections made under sub-section (4) shall be decided on the
basis of possession by the competent authority and orders disposing
of objections entered in the register of disputed cases shall be re
corded in the register of mutation by the competent authority.

Register
of mutations

<!-- page 13 -->

(12)

(6) After the entries in the register of mutations have been tested and
found correct, the entries shall be transferred to the record of rights

and shall be certified by such officer as may be prescribed in this
behalf.
Pentalty for
neglect to afford
information.

45.The Deputy Commissioner may, if he is of opinion that any person has
wilfully neglected to make the report required by section 43, within the
prescribed period, impose on such person a penalty not exceeding twenty
five rupees.

Assistance in

46.Subject to rule made under this Act;-

preparation of
maps

(a)any revenue officer may, for the purpose of preparing or revising any
map or plan required for or in connection with any record or register
under this chapter, exercise any of the powers of the survey officer
under section 24 except the power of assessing the cost of hired labour;
and
(b)any revenue officer not below the rank of sub-divisional officer may
assess the cost of the preparation of revision of such maps or plans
and all expenses incidental thereto, and such costs and expenses shall
be recoverable in the same manner as an arrear of land revenue.

Certified copies.

47.

Maps and other

48.Subject to such rules and on payment of such fees, if any, as may be pre

records open to
inspection.

scribed, all maps and land records shall be open to inspection by the public
during office hours, and certified extracts there from or certified copies
thereof may be given to all persons applying for the same.

Power
to transfer duty
of maintaining
maps and records
to settlement
officer.
Determination

Certified copies of entries in the record of rights may be granted by such
officer on payment of such fees as may be prescribed.

49.When a local area is under settlement, the duty of maintaining the maps
and records may, under the orders of the Government, be transferred from
the Deputy Commissioner to the settlement officer.

CHAPTER VI

BOUNDARIES AND BOUNDARY MARKS

boundaries

50.The boundaries of villages, survey numbers sub-divisions and fields shall
be fixed and all disputes relating thereto shall be determined by survey
officers or by such other officers as may be appointed by the Government
for the purpose, in accordance with the rules made in this behalf.

Effect of

51.(1) The settlement of boundary under this Chapter shall be determina-

of village

settlement of
boundary

tive:(a)of the proper position of the boundary line or boundary marks
and

(b)of the rights of the land holders on either side of the boundary
•fixed in respect of the land adjudged to appertain, or not to ap
pertain, to their respective holdings.
(2) Where a boundary has been so fixed the Deputy Commissioner may
•at any time summarily evict any land holder who is wrongfully in
possession of any land which has been adjudged in the settlement of
a boundary not to appertain to his holding or to the holding of any
person through or under whom he claims.

<!-- page 14 -->

(13)
52.

53.

54.

55.

It shall be lawful for any survey officer authorized in this behalf to specify

Construction

or cause to be constructed, laid out, maintained or repaired, boundary marks
of villages or survey numbers of sub-divisions and to assess all charges
incurred diereby on the holders or others having an interest therein.

and repair of

The boundary marks shall be of such description and shall be constructed,
laid out, maintained or repaired in such manner and shall be of such di
mensions and materials as may, subject to rules made under this Act, be
determined by the Deputy Commissioner or other officer appointed for
the purpose.

boundary marks.

Description of
boundary marks

Every land holder shall be responsible for the maintenance and good re
pair of the boundary marks of his holding and for any charge reasonably
incurred on account of the same by the revenue officers in case of alter
ation, removal of repair. It shall be the duty of the Revenue Officers and
servants to prevent the destruction or unauthorized alteration of the village
boundary marks.

Responsibility

After the introduction of survey and settlement in a district, the charge of

Deputy Com-

for maintaining
boundary
marks.

the boundary marks shall devolve on the Deputy Commissioner and it missioner to
shall be his duty to take measures for their construction, laying out, main have charge of
tenance and repair.boundary
marks
56.

Any person willfully erasing, removing or injuring a boundary mark shall
be liable to such penalty not exceeding one thousand rupees as the compe
tent authority may impose.

Tempering of
boundary marks

CHAPTER VII
REALISATION OF LAND REVENUE AND OTHER PUBLIC DEMANDS
57.

Land Revenue assessed on any land shall be the first charge on that land on
the crops, rents and profits thereof.

Land revenue
to be first
charge

58.

59.

Land revenue shall be payable at such times, in such installments, to such
persons, and at such places, as may be prescribed.

Payment of land
revenue.

(1)Any installment if land revenue or part thereof which is not paid on Arrear of land
the due date shall become an arrear of land revenue and the person revenue
responsible for the payment shall become a defaulter.
(2)A statement of account certified by the Revenue Officer shall, for the
purpose of this chapter, by conclusive evidence of the existence of
the arrear of its amount and of the person who is the defaulter.
Provided that nothing in this sub-section shall prejudice the right of
such person to make payment under protest and to question the cor
rectness of the account in separate proceedings before the competent
authority.

60.

An area of land revenue may be recovered by any one or more of the Recovery of
following processes, namely:arrears
(a)by serving a written notice of demand on the defaulter.
(b)by distraintandsaleofthedefaulter'smovablepropertyincludingthe
•produce of the land.
(c)by attachment and sale of the defaulter's immovable property.

<!-- page 15 -->

(14)
Notice of demand

61.

The form and contents of the notice of demand and the officers by
whom such notices shall be issued shall be in such manner as may be
prescribed.

Distraint and
sale of movable

62.

(1)The distraint and sale of the moveable property of a defaulter
shall be made by such officers or class of officers, in such man

property

ner as may be prescribed.

(2)Nothing in sub-section (1) shall be deemed to authorize the dis
traint or sale of any property which, under the Code of Civil
Procedure, 1908, (5 of 1908) is exempt from attachment or sale
in execution of a decree or any articles set aside exclusively for
religious use.

Sale of
immovable
property

63.(1) When the Deputy Commissioner is of opinion that the processes
referred to in clauses (a) and (b) of Section (59 arc not sufficient for
recovery of an arrear, he may, in addition to or instead of any of
those processes, cause the land in respect of which such arrear is
due to be attached and sold in the prescribed manner.
(2) The Deputy Commissioner may also cause the right, title and inter
est of the defaulter in any other immoveable property to be simi
larly attached and sold.

Notice of Sale

64.(1)

Before effecting the sale of any land or other immovable property
under the provisions of this Chapter, the Deputy Commissioner or
other Officer empowered in this behalf shall issue such notices and
proclamations, in such from, in such manner and containing such
particulars, as may be prescribed and such notices and proclama
tions shall also be published in such manner as may be prescribed.

(2)

A copy of every notice or proclamation issued under sub-section
(1) shall be served on the defaulter.

Sale to be by
auction.

Prohibition to
bid at auction

65.

All sales of property, moveable or immovable, under this Chapter shall be
by public auction held in accordance with such rules as may be prescribed.

66.

No officer having any duty to perform in connection with any such sale
and no person employed by or subordinate to such officer shall, either
directly or indirectly bid or acquire any property except on behalf of the
Government.

Sale of
perishables

67.

Sales not to be
excessive

68. Every sale of property, movable or immovable, under the provisions of

Perishable articles shall be sold by auction with the least possible delay
and such sale shall be finally concluded by the officer conducting the sale.

this Chapter shall, as far as may be practicable, be proportionate to the
amount of the arrear of the land revenue to be recovered together with the
interest thereon and the expenses of attachment and sale.

<!-- page 16 -->

(15)
69.

In all cases of immovable property, the party who is declared to be the

Deposit by

purchaser shall be required to deposit immediately twenty five percent

{^^ovabl

of amount of his bid and the balance within fifteen days of the date of

property

sale.
70.

(1)

In default of the payment of deposit referred to in Section 69 the

Failure to

property shall be put up for re-sale and the expenses incurred in

make deposit

connection with the first sale shall be borne by the defaulting
bidder.
(2)In default of payment of balance of thej^id amount within the
period prescribed in Section 59 the deposit after defraying there j
from the expenses of the sale shall be forfeited to the Govern
ment and the property shall be re-sold.
(3)Where the proceeds of the re-sale are less than the price bid by
such defaulting purchaser, the difference shall also be recover
able from him in the same manner as an arrear of land revenue.
71.Where immoveable property has been sold under this Chapter, the de
faulter, or any person owing such property or holding an interest therein,

Setting aside
sale

may, at anytime, within thirty days of the date of sale or within such
further period not exceeding thirty days as the Deputy Commissioner
may for sufficient cause allow, apply in the prescribed manner to the
Deputy Commissioner to have the sale set aside;
(a)on the ground of some material irregularity or mistake or fraud
resulting in substantial loss or injury to him, or
(b)on his depositing in the Deputy Commissioner's office the amount
of the arrear specified in the proclamation of sale, the cost of the
sale and for payment to the purchaser, as sum equal to five per
cent, of the purchaser money.
72.If, on the expiration of thirty days from the date of sale of any immove
able property or of the further period, if any allowed under Section 71,

Confirmation
of sale

no application has been made and rejected, the Deputy Commissioner
shall make an order confirming the sale unless, for reasons to be re
corded, the Deputy Commissioner sets aside the sale notwithstanding
that no application therefore has been made.

73.(1) The Deputy Commissioner shall order the refund and payment Refunds
to the purchaser, of:(a)the amounts deposited by him under Section 69 and
(b)the sum equal to five percent of the purchase money depos
ited under clause (b) of Section 71, if the sale is not con
firmed or is set aside.

<!-- page 17 -->

(16)
(2) The Deputy Commissioner shall order the refund and payment of all
the money deposited under clause (b) of Section 71 to the person who
made the deposit, if the sale is confirmed;
Provided that the Deputy Commissioner may set of the whole or any
part of any such money against any arrear of land revenue, or any other
arrear recoverable as an arrear of land revenue, which may be outstanding
against the person who made the deposit.
Certificate of
Purchase

74.

When a sale held under this chapter is confirmed the Deputy Commissioner
shall put the person declared to be the purchaser in possession of the prop
erty and shall grant him a certificate in the prescribed form to the effect that
he has purchased the property specified therein, and such certificate shall be
deemed to be a valid transfer of such property.

Application of
proceeds of
sale

75.The proceeds of the sale of any property under this chapter shall be applied
in defraying the expenses of the sale which shall be determined in the pre
scribed manner and the balance shall be applied to the payment of the
arrears on account of which the sale was held and the surplus, if any, shall
be paid to the person whose property has been sold.

Liability of
certificate
purchaser.

76.The person who has purchased any land and to whom a certificate of pur
chase has been granted shall not be liable for the land revenue in respect of
the land for any period prior to the date of the sale.

Precautionary
measure in
certain cases

77.When the crop of any land or any portion of the same is sold, mortgaged or
otherwise disposed of, the Deputy Commissioner may, if he thinks it neces

Recovery of

78.The following money may be recovered under this Act in the same manner
as an arrear of land revenue, namely:

other public
demands

sary, prevent its being removed from the land until the demand for the cur
rent year in respect of the said land is paid, whether the date fixed for the
payment of the same has arrived or not.

(a)rent, fees and royalties due to the Government for use or occupation
of land or water or any product of land;
(b)all moneys falling due to the Government under any grant, lease or
contract which provides that they shall be recoverable as arrears of
land revenue;
(c)all sums declared by this Act or any other law for the time being in
force to be recoverable as an arrear of land revenue.

CHAPTER Vin
APPEALS AND REVISIONS
Revenue
officers to be
courts

79.(1)

A Revenue Officer, while exercising power under this Act or any other
law for the time being in force to inquire into or to decide any ques
tion arising for determination between the Government and any per
son or between parties to any proceeding, these shall be a revenue
court and when trying such disputes shall be guided by the principles
of the Civil procedure Code, 1908 in respect of summoning witnesses,
production of documents recording of evidence and other relatable
provisions.

<!-- page 18 -->

(17)

(2) Nothing in this Act shall be deemed to limit or otherwise affect the
inherent power of the revenue court to make such orders as may be
necessary for the ends of justice or to prevent the abuse of the
process of the revenue court.
80.All revenue officers and persons acting under their orders may enter „
upon and survey the land and demarcate boundaries and do all other actsTO*er t0 en[^r "P"
necessary for the purpose of discharging their duties under this Act orsurvey tne tana
any other law for the time being in force and in so doing, shall cause no
more damage than the circumstances of the case may require.
81.(1)

The Government may transfer any case or class of cases arising Power to transfer

under this Act or any other law for the time being in force from cases
any revenue officer to any other revenue officer competent to deal
with it.
(2) The Deputy Commissioner may transfer any case or class jf cases
arising under this Act or any other law for the time being in force
for inquiry or decision from his own file or from the file of any
revenue officer subordinate to him competent to deal with such
case or class of cases.
82.Where any order is passed under this Act directing any person to deliver use of force
possession of land or directing the eviction from land, such order shall
be executed by the competent authority in such manner as may be pre
scribed and it shall be lawful for such authority, in accordance with rules
to be prescribed, to take such steps and use or cause to be used such
force as may be reasonably necessary for securing compliance with the
order.

83

(1) Save as otherwise expressly provided, an appeal shall lie from Appeals
every original order passed under this Act.
(a)If such an order is passed by an Officer sub-ordinate to the
Deputy Commissioner.
(b)If such an order is passed by the Deputy Commissioner to the
Government represented by the concerned Secretary;
(c)If such an order is passed by Assistant Survey and settle
ment Of ficer, to the survey an settlement Officer or to a rev
enue officer notified by the Government in the official Ga
zette as the appellate authority; and
(d)If such an order is passed by a survey and_settlemenLofficer
to the Director of settlement and Taild management or to a revenue
officer notified by the Government in the official Gazette to be
the appellate authority.

(2)

A second appeal shall lie against any order passed in first appeal;
(a)

if such an order is passed under clause (a) of sub-section (1),
to the Government;

(b)

if such an order is passed under clause (clof sub-section.(
to the Director of settlement and land management or to a
revenue officer notified by the Government in the Gazette to
be the second appellate authority and

(c)

if such an order is passed under clause (d) of sub-section (1),
to the Secretary concerned in the Government.

<!-- page 19 -->

(18)
Limitation84,

(1)

No appear shall lie,(a)in the case of first appeal, after the expiry of thirty days from
the date of the order appealed against; and
(b)in the case of a second appeal, after the expiry of sixty days
from the date of the order appealed against.
In computing the above periods, the time required to obtain copies

of the order appealed against shall be executed.
Revision85.

The Government represented by the concerned Secretary or the Deputy
Commissioner may, at any time, either on his own motion or on the ap
plication of any party, call for the records of any proceedings before any
revenue officer subordinate to him for the purpose of satisfying himself
as to the legality or the propriety of any order passed by such revenue
officer, and may pass such order in reference thereto as he thinks fit:
Provided that he shall not vary or reverse any order affecting any
right between private persons without having given to the parties, notice
to appear and be heard.

Review of86. (1) A revenue officer may, either on his own motion or on the applica
orerstion of any party interested review any order passed by himself or
by any of his predecessors-in-office and pass such order in reference
thereto as he thinks fit.
Provided that a revenue officer subordinate to the Deputy Com
missioner shall, before reviewing an order under this section, obtain the
permission of the Deputy Commissioner and the Deputy Commissioner shall,
before reviewin^ any order passed by any of his pre-decessors-in-office
obtain the permission of the Government.
(2)No order affecting any question of right between private persons
shall be reviewed except on the application of a party to the pro
ceedings or except after notice to me other party and no applica
tion for the review of such order shall be entertained unless it is
made within ninety days from the date of the order.
(3)No order shall be reviewed except on the following grounds,
namely;
(i) discovery of new and important matter of evidence;
(ii) some mistakes or error apparent on the face of the record, or
(iii) any other sufficient reason.
(4)For the purpose of this section, the Deputy Commissioner shall be
deemed to be the successor-in-office of any revenue officer who
has left the district or who has ceased exercise powers as a revenue
officer and to whom there is no successor in the district.
(5)An order which has been dealt with in appeal or on revision shall
not be reviewed by any officer subordinate to the appellate or
revisional authority.
Stay87. (1) A revenue officer who has passed any order or his successor-inof execution ofoffice may, at any time before the expiry of the period prescribed
ordersfor Appeal, direct the stay of execution of such order for such pe
riod as he thinks fit provided that no appeal has been filed.

<!-- page 20 -->

(19)
(2)Any authority before whom a caseMs pending in appeal or revision
may direct the stay of execution of the order appealed against or
under revision for such period as it may think fit.
(3)The revenue officer or other authority directing such stay of execu
tion of any order may impose such conditions, or order such secu
rity to be furnished, as he or it may think fit.

CHAPTER IX
RIGHTS OF LAND OWNERS
88.

.

(1)

Every person, who, at the commencement of this Act, holds any
land from the Government for agricultural purposes, and his
successors-in-interest shall, subject to the provisions of sub-section(2),
became the owner thereof as and from such commencement.

Provided that all leassees of Government land on the dateof com
mencement of the Act, shall continue to hold such land on lease as per
original terms of allotment until such time as appropriate rules for allot
. ment of Government land for purposes other than agriculture are framed
under appropriate provisions of the Act with the right to transfer the al
lotted land to any member of a indigenous Arunachal Pradesh Schedule
Tribe of the State on payment of fees as may be prescribed by the Gov
ernment.
(2)No rights shall accrue under sub-section (1) in respect of lands
which:(i) are apart of the bed of a river, nallah, a stream or a public
tank, or
(ii) have been acquired by the Government for any purpose ac
cording to the provisions of any law in force for the time
being relating to acquisition of land, or
(iii) have been used at any time during the five years immediately
preceding the commencement of this Act for any public, commu
nity or village purpose, or

(iv) are declared by the Government by notification in the official
Gazettes as reserved or required
for any public, community or village purpose.
(3)Objections to accrual of rights under sub-section (1) may be filed
before the competent authority within such time and in such form
and manner as may be prescribed by any person who has interest or
claims to have an interest in the land either in his individual capac
ity or as a member of the village or community.
(4)Should any objection be made under sub-section (3), the compe
tent authority shall inquire into objection in such manner as may be
prescribed and decide the same.

(5)Subject to the provisions of this Act the decision of the competent
authority shall be final.
(6)Every person who, at the commencement of this Act, holds from
the Government for a purpose other than agriculture shall, subject
to sub-section (2), be entitled to the settlement of that land on such

Accrual of
ownership
rights on
Government
land allotted
for agricultural
purposes.

<!-- page 21 -->

(20)
terms and conditions as may be prescribed.
(7) Nothing in this section shall entitle any person to sub-soil rights
in respect of the land, of which he has become the land owner
under sub-section (1), or which has been settled with him under
sub-section(6).

Rights of land

89.

(1)

owners on Govern
ment land allotted
for agricultural

Every persons who has become a landowner under sub-section (1)
of section 88 shall:(a)have transferable rights in the land to the successor subject to
the declaration and satisfaction of the District authorities.

purposes

(b)be entitled by himself, his servant, tenants, agent or their rep
resentatives to erect farm buildings, construct wells or tanks
or make any other improvements thereon for the better culti
vation of the land or its convenient use;
(c)be entitled to plant trees on the land, to enjoy the products
thereof and to fell, utilize or dispose of the timber of any
trees on the land.

Rights to lease

90.

(2)

Nothing in sub-section (1) shall entitled a land owner to use his
land to the detriment of any adjoining land which is not his or in
contravention of the provisions of any other law for the time being
in force applicable to such land-

(1)

Subject to the provisions of this Act, a landowner may lease out his
land to another person on such rent not exceeding the maximum
rent as may be agreed upon between him and such person but shall
not exceed;
(a)where the rent is payable in kind as a share of the produce,
one-fourth of the produce of such land or its value estimated
in the prescribed manner if plough cattle for the cultivation
of such land is supplied by the landowner and one-fifth of
such produce or its value as so estimated if plough cattle is
not supplied by the landowner;
(b)in any other case, four times the land revenue payable in re
spect of the land.

(2)Every lease of land made after the commencement of this Act, shall
be for a period of five years and at the end of the said period, and
thereafter at the end of each period of five years, the tenancy shall,
subject to the provisions of sub-section (3), be deemed to be re
newed for a further period of five years on the terms and conditions
except to the extent that a modification thereof consistent with this
Act is agreed to by both parties.
(3)In respect of any lease made after the commencement of this Act,
landowner who is a member of the Armed Forces of the Union, on
his discharge from service or posting to the reserve, may by giving
the tenant three months notice in writing before the expiry of any
year, and any other landowner may by giving the tenant one year's
notice in writing before the expiry of any terms of five years termi
nate the tenancy if the land owner requires the land bonafide for
personal cultivation by him.

<!-- page 22 -->

(21)
91..

(1)

Where the Deputy Commissioner is satisfied that any land has re Land left
mained uncultivated for a period not less than two consecutive years uncultivated
otherwise than in accordance with rules made in this behalf under
this Act, and that it is necessary for the purpose of ensuring the full
and efficient use of the land for agriculture to do so, he may after
making such inquiry as may be prescribed lease out the land in
accordance with rules made under this Act.

(2) Any lease made under sub-section (1) shall be deemed to be a lease
made by the landowner under sub-section (1) of section 90.
92.(1)

Subject to any rules that be made under this Act landowner may
relinquish his rights in respect of any land in his possession in favor of the Government by giving a notice in writing to the competent authority in such form and manner as may be prescribed, not
less than three months before the close of any year and there
upon,he shall cease to be a landowner in respect of that land the
year next following the date of notice;

Relinquishment by
the land owner of
the Government
]anci

Provided that relinquishment of only a part of a holding or of a
holding which, or part of which is subject to an encumbrance or charge,
shall not be valid.
(2) If any person relinquishes his rights to a land under sub-section (1),
the way to which lies through other land retained by him, any fu
ture holder of the land relinquished shall be entitled to a right of
way through the land retained.

CHAPTER X
RIGHTS OF TENANTS
93.(1)

The interest of a tenant in any land held by him as such shall be in
accordance with such terms and conditions as agreed between the

Interest of
tenants

parties;
Provided that right to create charge over such land so transferred
on lease, right to make improvements and compensation thereof, pay
ments of rent; determination of reasonable rent by the authorities; sus
pension or revision of rent, eviction of tenant; termination of tenancy
and other related provisions shall be in such manner as may be prescribed
in the Rules made under this Act.

CHAPTER XI
GENERAL AND MISCELLANEOUS
94.Without prejudice to any other provision of this Act, any amount due to Recovery of
the Government, whether by way of costs, penalty or otherwise, and anyamount due as an
other amount which is ordered to be paid to or recoverable by the Gov-an-ear of iaIK) rev.
ernment, under this Act shall be recovered in the same manner as anenue
arrear of land revenue.
95.No suit or proceeding shall, unless otherwise expressly provided for in Jurisdiction of civil
this Act or in any other law for the time being in force, lie or be instituted Courts excluded
in any civil court with respect to any matter arising under any provision
of this Act;
Provided that if in a dispute between parties a question of title is
involved, a civil suit may be brought for the adjudication of such ques
tion;

<!-- page 23 -->

(22)
Provided further that the Civil court shall have jurisdiction to de
cide any dispute to which the Government is not a party relating to any
right or entry which is recorded in the record of rights.
Revenue96. Every plane-tabler, surveyor, supervisor kanungo, mandal, chainman and
officers to beevery other village officer appointed under this Act shall be deemed to
public servantsbe a public servant within the meaning of section 21 of the Indian Penal
Code.
General97. Whoever contravenes any provisions of this Act for which no penalty
provisions as tohas been otherwise provided for therein shall be punishable with fine
penaltieswhich may extend to one thousand rupees.
Delegations of
98. The State Government may, by notification in the official Gazette, delpowersegate to any officer or authority subordinate to it any of the powers con
ferred on it or on any officer subordinate to him by_this Act, other than
the power to make rules, to be excercised subject to such restrictions and
conditions as may be specified in the said notification.
Power to make

99.

(a)

The State Government may, by notification in the official Gazette,
make rules for carrying out the purpose of this Act.

(b)

without prejudice to the generality of the foregoing power, which
rules may be provided for all or any of the following matters :(1) the manner of appointment of revenue officers, survey offie
ers and settlement officers, and other village officers and ser
vants, their powers and duties, the official seals, if any, to be
used by them and the size and description of the seals;

(2)

the Deputy Commissioner's powers of superintendence and
control over other officers;

(3)the officers who should hear and decide disputes regarding
rights in or over many properties claimed by or against the
Government and the procedure to be followed by them;

(4)the disposal of Government lands by assignment or grant to
individuals or for public purchases and the terms and condi
dons subject to which such assignments or grants may be
made;

(5)the preservation and disposal of trees, brush wood, jungle
and other natural products on Government land and the re
covery of the values of trees or other natural product unauthorizedly appropriated by persons;

(6)

the procedure for summary eviction of trespassers on Gov
ernment land;

<!-- page 24 -->

(23)
(7)the alteration and revision of the land revenue in cases of alluvion or diluvion or of
diversion of land for purposes other than agriculture;
(8)the grant or permission to use agricultural land for non-agricultural purpose;
(9)the determination of additional rates for use of water;
(10)the circumstances in which remission or suspension of revenue may be made and
the rate of such remission or suspension;
(11)the form of receipt for payment of land revenue;
(12)the conduct of surveys and settlements ofland revenue;
(13)the manner of estimating the cost of cultivation and other expenses relating to the
inquiry into profits of agriculture;
(14)the division of survey number's into sub-divisions and the assessment of sub-divi
sions;
(15)the statistical, fiscal and other records and registers to be prepared and maintained
under this Act;
(16)the manner in which the costs and expenses incidental to revenue survey of the
construction, repair and maintenance of boundary marks shall be determined and
apportioned between persons who are liable to bear the same;
(17)the fixing, construction, laying out, maintenance and repair of boundary marks,
and the settlement of disputed relating thereto;
(18)the division of areas into units for determining the revenue-rates and the prepare *
tion of the table of revenue-rates;

(19)the preparation and the preliminary and final publication of the record of rights
and the table of revenue-rates

(20)the hearing and disposal of objections to any entry of omission in the table of
revenue-rates, the record of rights, and the register of mutations;
(21)the manner and extent of alteration or revision of revenue-rates, during the term of
settlement;
(22)the correction of bonafide etrors and mistakes in the revenue records, registers
and maps prepared under this Act;
(23)the manner in which the average yield of crops of land shall be ascertained;
(24)the manner of holding inquires by revenue officers under this Act;

<!-- page 25 -->

(24)

(25) the application of the provisions of the code of Civil Procedure, 1908, to cases and
proceeding before a revenue court;

(26) the form of summons and other processes, notices, orders and proclamations to be
issued or made by revenue officers and the manner of their services;

(27) the procedure for the attachment and sale of property and the confirmation and the
setting aside of sales of immovable property under Chapter VII;

(28) the manner of publication of notice and proclamations of attachment and sale of
property;

(29) the manner in which the cost and expenses incidental to the attachment and sale of
property shall be determined;

(30) the manner of payment of deposit and of the purchase money of property sold for
arrears of land revenue;

(31) the circumstances in which precautionary measures for securing the land revenue
under section 76 may be taken;

(32) the procedure for the transfer of cases from one revenue officer to another;

(33) the manner of preferring appeals or applications for revision or review, the docu
menus to accompany the memorandum of appeal or such application and the fee, if
any, leviable therefore;

(34) the grant of certified copies and the payment of fees for inspection
and grant of certified copies of revenue records and registers;

(35) the mode of execution of any orders directing any person to deliver possession of
land or to be evicted from land, including the use of force for securing compliance
with such order;

(36) the form of notices to be issued under this Act and the manner of their service;

(37) the manner of holding inquires under this Act;
(38) the circumstances in which and the period for which land used for agricultural
purposes may be left uncultivated;

(39) the conditions subject to which lands may be leased by the Deputy Commissioner

(40)

under Section 91;
the form of applications to be made under this Act, the authorities to whom they be
made and the procedure to be followed by such authorities in disposing of the
application.

<!-- page 26 -->

•

•(25)

(41)the determination of the value of the procedure of land, the profits of agriculture,
and the rental value of land, for the purposes of this Act;

(42)the time and manner of payment of rent by the tenant;
(43)the form of receipt for rent to be given by the land owner;
(44)the factors to be taken into account in determining reasonable rent for land and in
commuting rent in kind into money rent;

(45)the nature and the extent of relief to the tenant in cases of suspension or remission
of land revenue by the Government;

(46)the determination of compensation for improvements to tenants who are evicted

from land;
(47)the grant of permission to surrender land;

(48)the determination of the price to be paid by the tenant for land in respect of which
the first option to purchase is exercised;

(49)any other matter which is to be or may be prescribed.

Repeal and100. (1)

On and from the date on which any of the provisions of this Act are

savingsbrought into force in any area in the State of Arunachat Pradesh,
the laws/instructions or such executive directions as related to the
matters covered by the previsions so brought into force shall stand
superseded/cancelled in-such area/areas.
(2)

Such supersession or cancellation shall not effect:
(a)the previous operation of anything duly done or suffered there
under;

(b)any right, privilege, obligation or liability acquired, accrued
or incurred,
(c)any penalty, forfeiture or punishment incurred in respect of
any offence committed;
(d)Any investigation, legal proceeding or remedy in respect of

any such right, privilege, obligation, liability, penalty forfeiture or
punishment as aforesaid;

<!-- page 27 -->

(26)
and any such investigation, legal proceedings or remedy may be instituted or enforced and
any such penalty, forfeiture or punishment may be imposed as if such executive notification had not
been superseded or cancelled.

(3)

Subject to the provisions contained in sub-section (2), any appointment, rule, order,
notification or proclamation made or issued, any lease rent right or liability granted,
fixed acquired and any other thing done or action taken under any of the enactment
or parts thereof repealed under sub-section (1), shall, in so far as it is not inconsistent
with the provisions of this Act brought into force, be deemed to have been made,
issued, granted, fixed, acquired, incurred, done or taken under this Act and shall
continue to be in force until superseded by anything done or any action taken
under this Act.

<!-- page 28 -->

1

(27)

GOVERNMENT OF ARUNACHAL PRADESH
DEPARTMENT OF LAND MANAGEMENT
ITANAGAR
NOTIFICATION

Dated Itanagar, the 8* Sept'2008

No. LR-53/87 (Vol-II):: In exercise of powers conferred by Sub-Section
(3) of Section 1 of the Arunachal Pradesh (Land Settlement and Records) Act, 2000 (Act
No. 10 of 2000), the Government of Arunachal Pradesh hereby appoints 1" day of
September' 2008 as the appointed day for coming into force of all the provisions of this Act
in the entire territory of Arunachal Pradesh.

Sd/(T. Taloh)
Commissioner (Land Management)
Govt. of Arunachal Pradesh
Itanagar

Published in the Gazette of Arunachal Pradesh No. 80, Vol-XIX

dated September 30,2008

<!-- page 29 -->
