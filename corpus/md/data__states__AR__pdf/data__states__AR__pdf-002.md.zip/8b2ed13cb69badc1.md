---
doc_id: "8b2ed13cb69badc1"
source_url: "https://www.arunachalplan.gov.in/wp-content/uploads/2026/03/Law-and-Judicial-Order-for-Additional-Allocation-of-Rs.-304.55-Lakh-during-CFY-2025-26.pdf"
ministry: "Finance-Planning & Investment Department, Arunachal Pradesh"
title: "ADDENDUM 1"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "97d70ebaaecc8cb2"
---

<!-- page 1 -->

File No. PLNG-'l 1 01 41 1 12O25-Olo, DIR-SP-FPID-Part(39)
D

*

\g1l

(Comp. No. 291359)
OF ARUNACHAL PRADESH

PLANNING & INVESTMENT DEPARTMENT
(PLANNING & INVESTMENT DIVISION)
*11 A.P. clvlL SECRETARIAT:: ITANAGAR
//Q

Dated, the 6th March 2026

ORDER

Approval is hereby accorded for an additional allocation of Rs. 304.55 lakh (Rupees three
crore four lakh fifty-five thousand only) to the Law and Judicial Department for 'lnauguration

and Silver Jubilee celebration of Guwahati High court, ltanagar Permanent Bench,
Naharlagun' during the current financial Yeat 2025-26

2.

The same will be regularized at the time of finalization of RE 2025-26.
Utilization of fund is subJect to adherence to the following:
a) This allocation is purely indicative in nature and this shall be utilized by the departments

only after verirying the actual requirement and observance of guidelines and all the
financial rules, regulations, provisions, prescribed in GFR, DFPR, etc. &

guidelines/circulars/ OM's/ directives issued by the CVC, MoF, MHA, Gol, Administrative
Ministries of Gol & GoAP from time to time in this regard in letter & spirit without fail.
b) The department shall incur expenditure only afler the necessary allocation of fund-and
budgeting in consultation with the Finance, Planning & lnvestment Department of the
Budget Division which will be regularised at the time of finalization of RE 2025-26.
c) The nodal department and the executing agency (wherever applicable) shall maintain
proper coordination and ensure that works are executed as per prescribed norms/
specifications.
d) fhe scheme should be completed as per the timeline so that there is no cost or time
overrun.

e) Fund should be utilized during current financial year for the purpose for which it is
allocated and cannot be diverted for any other purpose.
No revised estimate/ cost escalation and change of scheme will be allowed

f)
g)
should ensure that there is no duplicity of the works with any other
- Department
proposed/sanctioned by the State Govt / Govt. of lndia lf any
projects
schemes/
discrepancies is detected, the concerned department should immediately bring it to the
notice of Planning & lnvestmenl Departmenl before commencement of execution of the
work. Diversion of fund to other works in such cases will not be permitted

h) Concerned Commissioner/Secretary will monitor and review the progress of
implementation of the scheme/ project at regular intervals and shall ensure timely
submission of quarterly progress report, utilization certificate, photographs and
completion certificate etc. as applicable only after necessary review/ verification at their
level.

i)

4.

Violation of above instruction/guidelines will be the sole responsibility of the officers
concerned. Further, the amount only as actually required should be used and the
balance amount if any, should be surrendered.

This is issued with the approval of the Competent Authority
(R.K. Sharma) IAS
Commissioner (Planning & lnvestment)

Page

l of 2

<!-- page 2 -->

File No. PLNG-I1014 l1t2O25-Olo, DIR'SP-FPID-earI(39)

/ \s'1

(

1014t1t2O25-O/o, DIR-SP-FPID-Part(39)

I

Dated, the 6th March 2026

to:Hon'ble Chief Minister, GoAP, ltanagar
Hon'ble Deputy Chief Minister, GoAP, ltanagar
to the Chief Secretary, GoAP, ltanagar.
3)
4) The SPA to Commissioner (Finance), GoAP, ltanagar
5) The PA to Secretary (Law), GoAP, ltanagar
6) The Under Secretary (BudgeUFinance- D), GoAP, ltanagar
7) The SRA (Budget), GoAP, ltanagar
B) Offlce copy.
(R.K. Sharma) IAS
Commissioner (Planning & Investment)

Page2 of 2
