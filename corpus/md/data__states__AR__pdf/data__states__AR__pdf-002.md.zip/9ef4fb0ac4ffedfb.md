---
doc_id: "9ef4fb0ac4ffedfb"
source_url: "https://www.arunachaluniversity.ac.in/aus/Notice/Circular%20and%20Guidelines%20for%20Examination%20Form.pdf"
ministry: "Arunachal University of Studies (AUS), Arunachal Pradesh"
title: "Circular and Guidelines for Examination Form"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f569183109047313"
---

<!-- page 1 -->

<!-- page 2 -->

Guidelines for filling the Examination Form
1. Open University official Website ” https://www.arunachaluniversity.ac.in/”

2. Click on the STUDENT CORNER Tab on the website.

<!-- page 3 -->

3. Go to Examination Section and Click on the Result of Student.

4. Click on the Examination Form.

5. Enter your Enrolment no. and Date of Birth (ddmmyyyy) and then click submit button. When
your examination form is open check all the credentials on the examination form properly.

<!-- page 4 -->

6. After checking all the details and if the details are correct and fee status is Rs.0/- then
check mark on the box “All the above information is true” and submit the form.

<!-- page 5 -->

7. And if any information need any correction then check box “Above information need
correction” and for correction kindly select from the list and enter the correct information and
submit the form.

<!-- page 6 -->

8. And, if the examination form shows any fee outstanding then you have to contact
University office or write an email to examination@arunachaluniversity.ac.in for
further processing.
