---
doc_id: "bdc0631ed1d2ccb1"
source_url: "https://eodb.arunachal.gov.in/investment/pdf/Arunachal_Pradesh_State_Industrial_InvestmentPolicy_2020.pdf"
ministry: "Arunachal Pradesh Investment Portal"
title: "Industrial & Investment Policy   Industries    2018"
date: ""
pages: 36
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e2e425a5e47a7073"
---

<!-- page 1 -->

©r t}

tsfEUTHE°iHffiLn3T[E]nL

nun "U[ST"[MT I
2020

Liia
fL;-t=

<!-- page 2 -->

zcife

•i
i

+

tl+

i

\
+

i!.

0

ti!

i\.`

i

i

€
4

i+
+

i,I

i+:

t
i+i\
+

i,i

i

.§

<

aa'.-``

5

i+

8

a

!
•

4

a

i.i

i

8

i+io

iEEE

+

Pi
¢

9,i

i

IE

i`'-```f:`ii

!

i.E€

i •!

!

i

i<

+

i

+

B

i

i

!®

i

a

i

EE

a

§

<

iri . - a
+

¢

+\-i /L ,
:"-i
+++

+

++

i
i 5a

a...,a

`

i

a

,\,7:(€

I

<!-- page 3 -->

Secretciry of Industries, Skill

Development &
Entrepreneurship, Textile &

Handicrafts, Trade &

Commerce.

qF7in rd

Govt. of Arunachal Pradesh

N.T Glow, IRS

FOREWORD

The Arunachal Pradesh State Industrial and Investment Policy

2020 was

long

due

to

establish

Arunachal

Pradesh

as

a

competitive investment destination and to create institutional
mechanisms which are conducive for `Ease of Doing Business',

which would be the guiding force for all stake holders to work in
unison to give a better business environment in the state.

The Policy has taken shape because of the constant support
and guidance from Hon'ble Chief Minister, Hon'ble Minister of

Industries and the Ld. Chief Secretary of Arunachal Pradesh, and
for the midnight lamp burned by the officers and officials of the

department.
I sincerely believe that this Policy would bring new dawn to

the business opportunities in the state. I also place on record, my
sincere thanks and gratitude to all involved in bringing out this
Policy.

ltanaoar
Dated: 12th February, 2020

-:i.::-:--;

(N.T Glow)

<!-- page 4 -->

RE
PEMA KHANDU

CHIEF MINISTER

ARUNACHAL PRADESH
MESSAGE

I am happy to learn that the Department of Industries is
bringing out the ARUNACHAL PRADESH STATE INDUSTRIAL AND

INVESTMENT POLICY 2020, which would give a thrust to the growth

and development of the state.
Industries are the backbone of the economy of the state.
Proper industrial policy would help in improving business climate

and in facilitating larger investment in the state thereby pushing

the state to a higher and sustainable growth. In line with the
•`Make in lndia'' initiative of Govt. of India, with the launching of
the Industrial Policy, investors will find it easier to do business in

Arunachal Pradesh.

I extend my heartfelt thanks and appreciation to the Minister
lndustn.es and his officer/officials for the efforts they have put in to
bring out this policy.

iiEi, ,
(Pema Khandu)

ltanagar
February 7, 2020

<!-- page 5 -->

Minister of Industries, Skill

Development&
Entrepreneurship, Textile &

Handicrafts, Trade &

Commerce.

whwh

Tumke Bagra

Govt. of Arunachal Pradesh

MESSAGE

Industries have been the key to economic development of the states
and thereby the growth and prosperity of its populace, but the industrial
growth has not been in commensurate with the potential this state is

endowed with. To bridge the gap between potential and investments in the
state, Arunachal Pradesh Industrial and Investment Promolion Policy 2020
aims to establish proper infrastructure, promote manufacturing and service
sector, enhance inclusivity, foster innovation and create employment
opportunities across all sectors in the state.
I am immensely pleased to bring out the long felt industrial policy which

will act as a catalyst to Industrial development in the state. I genuinely

believe that this industrial policy would open new economic opportunities for

local youths and help in meeting the aspirations of entrepreneurs operating in

the state.

JAI HIND!!!! JAI ARUNACHAL !!!

-i:I_,
(Tumke Bagra)

ltanagar
Dated: 12th February, 2020

<!-- page 6 -->

GOVERNMENT OF
ARUNACHAL PRADESH

NARESH KUMAR, iAs
CHIEF SECRETARY

ITANAGAR

-791111

0360 : 2212595 (Off)
0360 : 2212446 (Fax)

MESSAGE

Arunachal Pradesh the land of Dawn lit mountains has huge

untapped resources and enormous potential to be the hub of
industries in North East India. Government of Arunachal Pradesh

has accorded highest priority for improving business eco-system in

the state to create an environment which is conducive for
entrepreneurs to flourish and for the state to grow. The need to
launch an industrial policy has been long felt to boost up industrial

growth in the state through sustainable policy measures.

Launching of ARUNACHAL PRADESH STATE INDUSTRIAL AND

INVESTMENT POLICY 2020 would open up new vistas for the local

and outside investors in the field of business in Arunachal Pradesh.

I congratulate the entire team of officers and officials for all
their hard work in brihging out the Industrial Policy 2020.
ltanaoar
Dated: 12.02.2020

( Naresh Kumdr )

<!-- page 7 -->

(i)

INDEX

Sl. No.
1.

Content
Chapterl:

Introduction
1.2

National context

1.2

Overview

1.3

Existing Industrial Estates/Growth

Centres / Areas

2.

3.

1.4

Industries at a Glance

1.5

Industrial profile

Chapter2:

Vision, Objective and Strategy
2.1

Vision and objective of the policy

2.2

Strategy to achieve the vision and
objective

2.3

Th rust areas
Developing Enabling Infrastructure

Chaptei.3:

and creating conducive business
environment
3.1

Enabling infrastructure: upgrading the existing infrastructure,
identifying infrastructural gaps and
developing new infrastructure

3.1.a

Land

3.1.b

Creating / Establishment of

industrial estates in foothill areas
3.1.c

Connectivity

3.1.d

F]oadways

3.1.e

Railways

3.1.I

Inland waterway

3.1.g

Power

3.1.h

Water

3.1.i

Lease Rent and Leasing period

3.2

Creating conducive Business
Environment

3.2.a

Ease of doing business-Single
Window System

3.2. b

Investment Advisory cou nci I

3.2.c

I nvestment Faci I itation

Committee
3.3

Approval from po[lutjon control

Board
4.

Incentives

Chapter4:

4.1
4.1a

State capital Investment subsidy
Special provision to promote
Women Entrepreneurship

Page No.
1-2

<!-- page 8 -->

(ii)

State Interest Subsidy
Interest subsidy on Working
Capital Loan

4.3

Power subsidy

4.4

Stamp duty and Registration fee

4.5

Quality certification subsidy:

4.6

SGST Exemption

4.7

Public procurement/Purchase

Preference
4.8

Strengthening of District
Industries centres (DICs)

5.

Chapter5:

Definitions

6.

Chapter6:

Procedure for claiming of subsidy/
incentives under scheme

7.

Annexures

I, 11, Ill, lv, V, Vl & Vl'

14-15

<!-- page 9 -->

Department of Industries
Government Of Arunachal Pradesh

udyog Sadan, C Sector, ltanagar
CHAIFTEFZ-1

lNTl]ODUCTION
1 (1). NATIONALCONTEXT :

Arunachal Pradesh, the largest Northeastern State of India, is endowed with plenty of natural resources,
which need to be harnessed for the development of the State. At present, the industrial growth in the State
is at a nascent stage despite enormous potential for industrial growth. Plecently the Union Government has
given decisive push to manufacturing through a series of policy initiatives such as Make in India, Digital
India , Stand-up India , Start-up India and Skill India. The underlying thought of these initiatives is to
simplifythebusinessenvironment,therebypavingwayforattractinggreaterprivateinvestmentflowsfrom
both domestic and foreign investors to make India a leading manufacturing hub. In this context various
State Governments have spelt out their respective industrial / manufacturing/ investment policies in recent
timestogiveaboosttoinvestmentflowacrosstheirStates.Accordingly,afterduedeliberationsandtaking
into consideration all issues relating to investments, enterprise development and industrial growth in the
State, the Arunachal Pradesh State Industrial and Investment Policy, 2020 has been formulated.
1 (2). OVERVIEW :

Arunachal Pradesh -the "Land of the dawn-lit mountains", has a population of 13.84 lakh as per 2011
Census spread over an area of 83,743 sq. kin., with a very low population density of 17 per sq kin, much
lower than national average of 382 per sq kin. Bordered by Bhutan to the West, Assam in the South, China
to the North and North-East and Myanmar to the East, the State is one of the most splendid and variegated
tribal areas of the country. The total length of international border is about 1628 kin. It has inter-State
borders with Nagaland in East and South-East and Assam in the South. Literacy rate in Arunachal Pradesh
has seen an upward trend and is 65.38 percem as per 2011 population census. As vibrant is the land, so
are the people living in it. Arunachal population speaks above 50 dialects in total owing to the cultural
diversity, yet the official language is English. Hindi is a common binding force for the people of the state.

The State capital is ltanagar. Numerous tribes reside in the State, each following their own cultures and
traditions. Owing to difference in topographic and altitudinal aspect, the climatic conditions are different for
different regions. Three major climatic zones is recognized on the basis of broad generalization, viz., the
hot and humid sub-tropical area of foot-hills, the cooler and micro-thermal region Of lesser Himalayas and
the cold climate in the upper region of the State.
1 (3). EXISTING INDUSTRIAL ESTATES/Gl]OWTH CENTRES /AREAS :
The details Of existing industrial infrastructure in the state are shown below:Sl.

Name of

Name of Available

Total Area

No. Of

No.

District /DIG

Industrial Infrastructure

Of IndustrialEstate(inacre)

sheds

No. of Vacant
shedsavaible

Vacant open
Space

1

2

3

4

5

6

7

1.

Tawang

Tawang Industrial Estate

7.08

3

0

0

2.

West Kameng

(Tippi/ Bhalukpong)

26.00

0

0

10

7

0

6.5

1

Wanghoo Industrial Area

15

3

15

Nil

Pasighat Industrial Estate

19.78

0

6.55

7

Industrial Growth Centre,NiglokNgorlung

582

6

0

100

Monipoliyang IndustrialEstate

3.00

3

2.82

2

Industrial Estate
Dirang Industrial Area

3.

4.

East Siang

Lower Subansiri

<!-- page 10 -->

4

7

6

5

1

2

3

5

Papum Pare

Chandranagar IndustrialEstate

4.00

11

0

Nil

Naharlagun Industrial Estate

8.00

21

0

Nil

Changlang Industrial Estate

2.81

4

0

2.47

(Khachang (Miao)

5.00

2

0

4.96

Balinong Industrial Estate

79.5

0

0

79.50

6

Changlang

Industria Estate

7

Namsai

Namsai Industrial Estate

1.59

2

0

1.51

8

LowerDibang Valley

Ploing Industrial Estate

10.0

3

1

03

9

Lohit

Tezu Industrial Estate

3.5

0

0

1.29

10

Tirap

Deomali Industrial Estate

6.14

6

1

4.76

Charju Industrial Estate

1.12

2

2

1.03

50.00 -

4

4

20

llDC, Bame, West Slang

West Siang

11

1(4).

INDUSTRIESATAGLANCE :

Sl. No.

1(5).

Type of Industries

Nos. (F}egistered)

1.

Large scale industries

04

2.

Medium scale Industries (Manufacturing Enterprise)

02

3.

Medium scale Industries (Service Enterprise)

07

4.

Micro & Small Enterprise

367

INDUSTRIAL PROFILE (PRESENT) :
1.

Weaving, Knitting & Tailoring

14.

Coke manufacturing

2.

Handicraft items including Carpet

15.

Motorgarage

making, Wood carving, Cane &

16.

Tourism Industry

Bamboo Furniture
3.

Wooden furniture

17.

lT enables services

4.

Bakery items

18.

Cyber cafe

5.

Fiice milling

19.

Saw mill/ Saw-cum-Veneer Mills

6.

Wheat grinding

20.

Plywood

7.

Fruit processing

21.

Wineries

8.

Food processing/Pickle making etc

22.

Steel F}olling Mill

9.

Steel furnitui.e

23.

Ferro Silicon

10.

Steel Fabrication

24.

Dehydrationginger/cardamom

11.

Mineral water

25.

Printing Press

12.

Brick kiln

26.

Textile Industries

13.

Citronella Oil Distillation

27.

Agro/Horti & allied Industries

1 (7). The status of online filling of Udyog Aadhaar Memorandum (UAM) in respect of Arunachal
Pradesh as on 31 st May 2019 is shown below.
Sl. No.
01

Udyog Aadhaar F}egd.
1074

Micro

Small

Medium

615

431

28

<!-- page 11 -->

3
CHAPTER-2

VIsloN, OBJECT.VE AND STRATEGY 0F THE POLICY

2(1)

Vision and objective of the policy :

The State Government of Arunachal Pradesh has accorded top priority to industrial growth as a
means to mitigate poverty and unemployment. Arunachal Pradesh Industrial and Investment Policy aims to
establish state-of-the-art infrastructure, promote manufacturing and service sector, enhance inclusivity,
foster innovation and create employment opportunities across sectors. The state intends to be the most
preferred destination for investors_ by providing favourable business climate, excellent infrastructure, good
law and order and peaceful industrial relations. The new industrial and investment policy focuses on creating
a conducive eco-system and paving way for sustainable industrial development.

The objectives of the Arunachal Pradesh State Industrial and Investment Policy, 2020 are as:-

(i)

To work out new parameters especially for the development of MSME sector in the state based on
available local resources for the benefit of local rural youth.

(ii) To increase Gross State Domestic Product by way of facilitating growth of various economic
activities including Manufacturing and Service sectors.
(iii) To create income & employment especially in the rural areas.

(iv) To encourage sustainable investment environment in the MSME sector in the State.

(v)

To establish Arunachal Pradesh as a competitive investment destination, leveraging the potential
of the vast available area, picturesque & exotic locations and abundance of natural resources in
the state.

(vi)

To increase the standard of living and prosperity among the people of Arunachal Pradesh by giving
them the opportunity for skilled and unskilled employment and to give special thrust on economic
activities based on local resources with an objective to create market for the local farmers.

(vii) To provide quality infrastructure for environmentally friendly industries. Create an integrated eco
system which nurtures skill development, entrepreneurship and private investment flows forjob
creation,

(viii) To harness those sectors of economy where the state has a comparative advantage.
(ix)

To create institutional mechanisms which are conducive for 'Ease of Doing Business' to create
business friendly environment.

(x)

To create employment opportunities for both skilled and unskilled workforce.

(xi)

To promote the spirit of innovation and incentivize entrepreneurship among youth by providing
specific sector skills and needed capital.

2 (2) Strategy to achieve the vision and objective :
The State Government will follow the following roadmap in achieving the mission :-

•

Create robust infrastructure-Upgrading the existing infrastructure, identifying infrastructural gaps

and developing new i nfrastructu re.

•

Fs:rceunsg:Ts%vsaenctta°gr:;:::::'#::sk:nyds:::,:r:/::rnutshtea:ea where Aru nach al p radesh has re| at|ve

•

Ease of doing business: Bring reform measures and changes in laws/rules, single point clearance
system for industries.

•

Skilled manpower: lmpartrequisite skills to local youths and entrepreneurs and linkthem with the
industrial units,

•

Promote Micro, Small and Medium Enterprises.

•

Marketing 'BrandArunachal pradesh' as a preferred investmentdestination.

<!-- page 12 -->

2(3) Thrust Areais :
Arunachal Pradesh has natural advantage in some sectors like Tourism, Hydro Power, AgricultureHorticulture Processing Sector, Textiles and Handicrafts, etc. It is true that the natural advantage being
possessed by the State has not been fully exploited for employmem generation and improving the living
standard of the people. The following areas have been identified as key thrust areas which have huge
potential for growth in the state:-

•

Food processing andAgro based industries

•

Bio-Technology sector

•

Agricu[tJre-Horticulture processing sector

•

Industries based on non-timber forest produce e.g. bamboo, cane, medicinal plants / herbs, aromatic

grass, tea, coffee, etc.
•

Textiles (handlooms and power looms), Handicrafts and sericulture.

•

Tourism (tourism infrastructure including resorts, hotels, restaurants, etc.).

•

Adventuretourism infrastructure.

•

Forest based tourism ventures.

•

Creative and Entertainment Industry.

IThethrustareasmentionedabovewillbereviowedperiodicallytoirroludeothersectorsofindustrial
activities from time to time)

<!-- page 13 -->

5
CHAIREFzi}
DEVELOPING ENABLING INFRASTRUCTUFtEAND CFtEATING CONDUCIVE BUSINESS
ENVIRONMENT

Infrastructure facilities are absolutely essential for industrial development of the State. As a result of
availability of quality infrastructure, industries get established with less capital investment and can function
without impediments. These infrastructure facilities assist in growth of business and industry along with
promoting fair competition. I n addition to social development and generation of new employment opportu nities,
it helps in attracting investment. Development of Industrial intrastructure has been identified as one of the

strategies to attract industries and investments in the State.

3(1 ). Enabling infrastructure: Upgrading the existing infrastructure, identifying infrastructural gaps
and developing ne`A/ infrastructure :
One of the most important factors for industrial growth is robust enabling infrastructure. Without
robust infrastructure in the State, industries will find it difficult to operate. The focus of the Government will
be to create enabling infrastructure so that investors find it suitable to invest in the state. The following are
the key areas where the Government of Arunachal Pradesh will focus upon:-

3(1 )(a) Land :

Availability of land is primary requisite for sustainable industrial development, Arunachal Pradesh has
a vast area of 83,743 square kilometers which is highest in the North-East India. The following interventions
are proposed (envisaged) in the policy:

>

LeaseofLand: Private Individuals/Joint ventures/Companies (investors from outside the state)
shall be allowed to enter into agreement with private owners/community owners for leasing of land
for a period of 99 (ninety nine) years to be renewed in every 33 years tor commercial purposes.

>

OwnershipR!ghts: The Land settlement and pecordsAct, 2002 ofArunachal pradesh will be
followed to pave way for ownership rights to legal occupants of land.

>

ldentificationofLand Banksinfoothills : A Committee under each Deputy commissioner of
the district will be formed to:-

>

Identify and acquire the vacant infrastructure (both of private individual or state Government) in
the district which will be made available to all potential investors by leasing out for 99 years

renewable every 33 years.
>

>

Identification of suitable land infoothjllareas (private individual/governmentowned) havinggood
road connectivify, water supply, electricity supply which will be acquired by the State Government
as per rates notified by the Land Management Department of the State Government.

Deputy commissionerswill be empowered to convert upto 5 hectares of land into jndustrjal area
in their respective districts.

>

State Governmentwill provide securityto the industrial estates from its own cost.

3(1 )(b).Creation/Establishment of Industrial Estates in foothill areas :
Industrial Estates provide integrated facilities to the industries viz. power, water, sewerage, security,
etc. Suitable land for the establishment of Industrial Estates in foothill areas will be identified. Land will be
acquired by the Deputy commissioner either through Land Acquisitic)n process as per Jhum Land Plegulation
1947/ Land Acquisition and Plehabilitation and I]esettlement Act, 2013. Due care will be taken to identify

the patch of land which has approach road, proximity to water supply source and electricity for development.

3(1)(c). Connectivity :

To ensure access to markets and resources, there is a need of having good connectivity in the State.
There is a need to prioritize on important zones which have the potential to become industrial estates.
Priority will be accorded to the foothill districts of the state.
3(1 )(d). Ftoadways :
Further with the development of road along Dibmugarh-Pasig hat-Poi ng-Lohit-Namsai-Tezu under Trans
-Arunachal Highway, the entire foothill area will serve as a major hub for promoting industrial activities. The
entire stretch will be re-designated as Trans Arunachal Industrial Corridor and focus will be on development
of Mega Industrial Zones alongside the corridor.

<!-- page 14 -->

6
3(1 )(e). Flailways :
Indian Pailways is planning to heavily invest in Arunachal Pradesh covering the hilly areas with the
mainstream. Dedicated Industrial Corridor will be established alongside the Railway corridors for leveraging
the potential of rail connectiv.ity as well as to increase industrial activities.

3(1 )(f). Inland Waterway :
Inland WaterAuthority of India is doing a survey to identify the suitable routes on Dibang river, Siang
river and Subansiri river for starting Inland Waterways in the State. This will provide a cheap way of
transportation of goods from the State to outside.

3(1 )(g). Power :
One of the most important factor for growth of Industries is the availability of quality uninterrupted

powersupply.SeparatefeedersandlineswillbeprovidedtothelndustrialEstatesbytheStateGovernment.
Priority w.Ill be given in installing feeders for Industrial Estates.

3(1 )(h). Water :
Water will be made available to the industrial areas on priority basis. Further, Industrial estates will be
allowed to use ground water subject to the rules prescribed. Rainwater harvesting will be promoted by the
State Govern ment.

3(1)(i). Lease Rent & Leasing Period :
The following lease rentals shall henceforth be applicable for Industrial Sheds and open space within
Industrial Estate/ IGC/llDC:-

Sl. No.
1.

2.

Particulars

Rent

Industrialshed

{ 3.00/sq. feet per month. The maintenance of the shed will
be borne by the entrepreneur himself at their own cost/esources.

Industrial plots (Open

i 1.00/sq. meter per month.

Space)
3.

Leasingperiod

Entrepreneurs/lnvestors shall be allowed esources. to hold the
land on lease for a period of 50 years renewable every 10 years.

4.

Leasingfromprivate
landowners

Private Land owners, with valid owner-ship documents shall be
free to enter into long term lease agreements duly registered with
the Deputy Commissioner for industrial application. Such lease
shall be in the name of a duly registered company and holding
valid GST registration documents. The land owner in such cases

can secure a Trade license on the basis of such a lease agreement,
clearly stipulating the nature Of industrial activity proposed.

3(2).Creating Conducive Business Environment :
Government of Arunachal Pradesh has accorded highest priority for improving business eco-system
inthestate,itisimperativetocreateanenvironmentwhichisconduciveforentrepreneurshipdevelopment.
Industryconsultation,timelyclearances,responsiveadministrationandtransparentgovernmenthavebeen
identified as the cornerstone for improving business environment and boosting investor's confidence. The
following steps have been/shall be taken by the Government of Arunachal Pradesh.

3(2)(a) Ease of Doing Business (EODB)-Single Window System :
The need to launch an industrial policy has been necessitated to overcome the hurdles being faced by
the industries at present and to supplement and augment the existing growth pattern through sustainable
policy measures.

In this backdrop, a single window system for clearances / approval / license / permission / industrial
services will be set up in the Department of Industries. The following will be the features of Single Window
Clearance Station / Cell :
>

The investor shall be facilitated to file all applications related to project at one point,

>

Asingle windowclearance portal will be createdwhichwill actas an interface between industries
and all the departments.

<!-- page 15 -->

7
Detallsofproceduresandformatsforvariousapprovalswillbeplacedontheportalforeasyreference
of investor. Single Desk Portal to help industries to obtain as many regulatory clearances required

to set-up and operate business in the State.
>

The cell will also become a repository of i_nformation regarding the state infrastructure, information
about investment application processes and issues being raised across the industry.

>

Additionally, this cell will also feed into a platform for information dissemination and will provide
additional information related to orders, rules & regulations.

>

Coordination with the relevant departments and required updates will be provided to the investors
through this System.

>

A District Level committee will be constituted under the chairmanship of Deputy comm`ssioner
which will periodically review the status of pending applications with single window system with

the concerned departments.

3(2)(b) Investment Advlsory Councll :
The Government ot Arunachal Pradesh will constitute an Investment Advisory Council by engaging

professionals from aci.oss the country to advise the Government in leveraglng investment in the State. The
Investment Advisory Council will serve as an Advisory Body Of the Government of Arunachal Pradesh for
identifying private investment in sectors of strategic growth and preparing a framework for consultation in
relation to skill development, infrastructure development and entrepreneurship development in the State. It
will advise the Government of Arunachal Pradesh on issues of the industrial development policy, regulatory
issues and help to develop a strategy for attracting investment including national and international road
shows. The Composition of the Investment Advisory Council will be as follows:SI. No.

Particulars

Designation

1

Hon'ble chief Minister of Arunachal pradosh

Chairman

2

Hon.ble Minister of Industries

Vlce-Chalrman

3

Chief secretary

Member

4

Commissioner/Secretary (Finance)

Member

5

Principlesecretary (Environmentand Forests)

Member

6

Commissioner/Secretary ( Power)

Member

7

Commissioner/Secretary (Texti le and Handicraft)

Member

,

8

Com missioner/Secrctary (Ski ll Development)

Member

9

Comrriissjoner/Secretary (Tourism)

Member

10

Commissioner/Secretary (Ag ricu ltu re & Horticu lture)

Member

11

Com in issioner/Secretary (Tax & Excise)

Member

12

Com missioner/Secretary (Labour and Employment)

Member

13

Commissioner/Secretary (Planning and I nvestment)

Member

14

Member secretary (Pollution control Board)

Member

15

Comm issioner/Secretary ( Industries)

Member Secretary

16

Director of Industries

Member

17

Expert / Eminent persons to be engaged by
the Government of Arunachal Pradesh

Member

3(2)(c) lnvestmelit Facilitation Comm]ttee :
TheslatedovernmentshallconstituteanlnvestmentFacilitationcommitteeunderthechairmanship
Of Chief Secretary for taking concrete measures for creating conducive environment for investment in the
State which would help in enhancing Ease of Doing Buslness (EODB). The mandate and terms of reference
Of this Committee will be to act as a single window clearance mechanism for all regulatory approvals
including labour, pollution, forest, power, land, etc. All investment proposals above { 5 (five) Crore capital
investment will be brought bofore this committee for clearance within 30 (thirty) days.

<!-- page 16 -->

Sl. No.

Particulars

Designation

1

Ch ief secretary

Chairman

2

Development commissioner (FP&I)

Vice-Chalrman

3

Principle secretary (Forest and Environment)

Member

4

Comm issioner/Secretary ( Power)

Member

5

Comm issioner/Secretary ( Home)

Member

6
7

Commissioner/Secretary (Land pecord & Management)
Comm issioner/Secretary (Health)

Member
Member

8

Comm issioner/Secretary (Tou rism)

Member

9

Commissioner/Secretary (Geology and Mining)

Member

10
11

Commissioner/Secretary (Agricultu re & Horticulture)
Commissioner/Secretary (Tax & Excise)

Member
Member

12

Member secretary (Pollution control Board)

Member

13

Commissioner/Secretary (Tax & Excise)

Member

14

Comm issioner/Secretary ( I ndustries)

Member-Secretary

15

Director of Industries

Member

16

Expert / Eminent persons to be engaged by
the Government of Arunachal Pradesh

Member

`

3(3) Approval from P6llutlon Control Board :
The Annexure at 11,Ill, lv and V provide the list of various industries categorized as White, Green,
Orange and F3ed (Fie-categorization of industries based on their pollution load by the GOI). The prospective
investors in the category of White and Green category need not go through the process of obtaining NOC
from the Pollution Control Board before the industry is set up however they shall notify of their activity to
the Pollution Control Board before setting up the industry.

The Orange category of industrles specified in Annexure-lv will be granted consent for a period of 10
(ten) years.
IncaseofindustriescoveredbytheEnvironm6ntlmpactAuthorityNotificationdated14thSeptember
2006, the time limit and other conditions specified therein will be followed.

The validity of the consent orders as long as there is no change in the process and addition/deletion
of machinery will be as follows :-

(a)

White category Industries

:

15years (Annexure-lI)

(b)

Green categoryof Industries

:

15years (Annexure-Ill)

(c)

Orangecategoryof Industries

:

10years (Annexure-lv)

(d)

Pled categoryof Industries

:

5years (Annexure-V)

(e)

ManagementoIHazardouswaste

:

5years

'
•'

•.-- i:

.-

.i-'1

.i-.

:.

,'_i,r`.

`.a-,

T.-

r'
``,i

, `

-

<!-- page 17 -->

9
CHAPTER4

INCErmvEs
UnderthispolicytheStateGovernmeutofArunachalPradeshwillprovidefollowingincentives/subsidies
in addition to incentives provided by Government of India:

4(1 ) State Capital Investment Subsidy :
All eligible new industrial units in the manufacturing and service sector located anywhere in Arunachal
Pradesh will be provided State Capital Investment Subsidy @ 30°/a on the cost Of the investment in plant
and machinery with an upper limit Of { 50 Lakhs. The incentive/subsidy shall be claimed within 5 years from
the date of commercial production.

4 (1)(a) Special Provision to Promote Women Entrepreneurship :

'0

lnordertoencouragewomenentrepreneursintheState,StateCapitallnvestmentSubsidy@50°/oo,n
the cost Of the investment in plant and machinery with an upper limit of { 75 Lakhs will be provided.The
incentive/subsidy shall be claimed within 5 (five) years from the date of commercial production/operation.

4(2) State Interest Subsidy :
All eligible new industrial units located anywhere in Arunachal Pradesh shall be given an interest
subsidy on term loan taken from the bank for plants and machinery.The incentive/subsidy shall be given to
an eligible enterprise for 5 (five) years from the date of commercial production, provided term loan is repaid
as per terms and conditions of taking such financial assistance from the banks:

Unit

Interest subsidy

M icro Enterprises

reimbursement of interest of up to 80 a/o of annual interest on the loan
taken, subject to a maximum ceiling of { 5 lakhs per annum.

Small enterprises

reimbursement of interest of up to 50°/a Of annual interest on the loan taken,
subject to a maximum ceiling of { 15 lakhs per annum.

Mediu in enterprises

reimbursement of interest Of up to 50°/a of annual interest on the loan taken,
subject to a maximum ceiling of i 20 Iakhs per annum.

Non MSME sector unit

reimbursement of interest of up to 50°/a of annual interest on the loan taken,
subject to a maximum ceiling of { 25 Iakhs per annum.

4(2)(a) Interest Subsidy on Worklng Capital Loan :
All eligible new industrial units located anywhere in Arunachal Pradesh shall be gi.ven an interest
subsidy @ three percent ( 3°/o ) on the outstanding working capital loan for five years subject to a ceiling of
{1 Crore and not exceeding 100°/a of investment in plant and machinery. Interest subsidy shall be available
only on outstanding working capital loan availed from Bank/Financial Institution.

4(3) Power subsidy :
State Government will arrange power supply to all Industries, Industrial Parks, etc adequately as per
their requirement and assured quality power to the industries. State Government will also encourage
investment in generation of power in both conventional and non-conventional and provide all necessary
assistance to the investors in power sector.
(i)

Manufacturing units (Small, Medium Enterprises) will beeligjblefor powersubsidy@{ 2.00 per
unit consumed from the date of Commercial Production subject to a maximum Of { 75 lakhs Per
Annum for a period of five years and not exceeding 100°/a of total investment made in Plant &
Machinery, whichever is less. This shall be available only to the Units having electricity connections
from 11 kv/ 33 kv transmission lines with the Department of Power, Governmem of Arunachal
Pradesh only.

(ii)

Manufacturing units/ Industries (Large scale Factories/ Bulk Electricity consumers) will be eligible
for Power Subsidy @1.00 per unit consumed from the date of Commercial Production subject to
a maximum of { 2 Crore Per Annum for a period of five years and not exceeding 100°/a of total
investment in plant & Machinery, whichever is less. This shall be available only to the Units
having electricity connections from 132 kv or above transmission lines with the Department Of
Power, Government of Arunachal Pradesh only.

<!-- page 18 -->

10.

(iii)

The power subsidy will be in the form of remission/ front ended thereby meaning tha"he power
bills raised against the Univ Industry will be generated after deducting the Power Subsidy per
unit. The record of annual Subsidy given against each Unit/ Industry shall be kept by the Power
DeparmentandwillbesharedwiththeDepartmentoflndustries,GovemmentOfArunachalPradesh
and reconcile quarterly.

(iv)

Power subsidy shaH be calculated on total unit ct>nsumed during the period at applicable rate per
unit and will be exclusive of all other charges, viz. Load security, interest, taxes, etc.

(v)

F`egular and timely payment to Department of Power, Arunachal Pradesh is a pre-requisite for
availing the subsidy under this policy.

4(4) Stamp duty and Registration fee :
All eligible new industrial units shaH be rejmbursed'or exempted from paymem of Stamp Duty up to
50% of the subject to a monetary ceiling of { 25 lakh. The Stamp Duty reimbursement or exemption shall
not be available for agricultural land. It shall be available only for such parcel Of land which is exclusively
used for setting up of manufacturing facilities. In case of units run by women entrepreneur, loo % exemption
for payment of stamp duty will be provided.

4(5) Quality Certlfloqtlon subsidy :
The fee payable for obtain i ng B IS/lso/FSSAl/AGMAPIK/HALLMAPK/SI LK MARKZED Certification
etc. by eligible unit, Will be provided subsidy up to the extent Of 100°/a subject to a ceiling of { 20 lakhs per
unit.

4(6) SGST exemption :
The eligible units will be exempted 100°/a SGST for a period of 15 (fifteen) years from the date of
commencement of commercial production. F`eimbursement of 100% SGST as per the foHowing scale will
begiven:

Category

Limit of Tax Reimbursement

Micro Enterprises

:

15 (fifteen) years subject to maximum of 250°/o of Fixed capital Investment.

Small Enterprises

:

15 (fifteen) years subject to maximum ol 200°/a of Fixed capital Investment.

Medium and Large

:

15 (fifteen) years subjectt6 maximum of l80°/a Enterprises of Fixed capital
Investment.

The benefit of tax reimbursement under the policy: shall be subject to the condition that the unit after
having availed of the benefit shall continue its production or operation at least for the next five years not
below 70°/a of the average production for the preceding five years. In case the unit violates this condition, it
shall be liable to make, the full amount of tax availed of by it during the period Of eligibility, as if no tax
reimbursement was ever available to it:
Provided that the provision of this clause shall not apme into play if the loss in production is explained
to the satisfaction of the authority concerned as being due to the reasons beyond the control of the unit:

Provided, further that a unit shall not be called upon to pay any sum under this clause without having
been given reasonable opportunity of being heard.

4(7) Public Procurement/Purchase Preference :
ln order to promote 'Make in AI.unachal', the State Government and other State controlled Bodies
and Organizations will give preference to the registered units/ Enterprises of the State while purchasing the
manufactured products.

4(8) Strengthening Of District Industries Centres (DICs) :
The State Government will strengthen and modernize the DICs. The DIG will be armed with Udyog
Sahayak Cell to guide the entrepreneurs and helping them in selection of product, preparation of project
reportandoctainingcreditfortheproject.Adatabankcoveringallaspectsofinformationsoughtbyinvestors
will also be maintained jn DICs.

<!-- page 19 -->

iE

CHAPTERS

DEFiNmoNS
5(1) Scheme tltle :
The scheme may be called "Arunachal Pradesh State Industrial and Investment Policy, 2020".

5(2) Coverago :
The scheme will cover State of Arunachal Pradesh.

5(3) Commencement and duration :
' The policy/scheme will come into effect from the 01 /04/2020 and shall remain in force up to 31/03/

2025ortillsuchtimeastheGovernmentmaydeemfitandproper.TheStateGovemmentreservestheright
torpakeanyamendmentstotheScheme,AIIeligiblenewunjtswhichcommencecommercialproduction
withintheperiodofvalidftywillbeeligiblefortheincentivesfromthedateofcommencementofcommeroial
production for the period applicable for each incentive.
5(4) Doflnltlons :

(I)

Now unit/Now lndustrlal unit means any industrial undertaking or eligible service sector unit,
otherthanthatrundepartmentallybyGovemment,whiehisaregisteredbusinessenterpriseunder
Goods & Services Tax, which has commenced commercial production/operation in the sitate of
ArunachalPradeshduringthevalidityperiodofAmunachalPrad®shlndustrial&lnvestmentPolicy,
2020.

`(11)

Mlcro, Small and Modlum unlt§ mean investment in plant and Machinery upto { 25 lakhs,
above{25lakhsbelow{5crores&above{5croresandbelow{10croresr®spectively.

(111) Largo unlt means investment in plant and machinery above i 10 crores.
I(Iv) Local trlbal means local populace recognized by the Government ofArunachal pradesh.

(v)

Women EIltropreneur / Women run ®ntoi.prlsos means units where major shareholder is a
woman(morethan50%Oftheshareofthecompany#irm/LLP).

(vl)

Mqnufacturlng Actlvlty means "an activity which brings about a change in non-living physical
objectorarticleorthing(i)resultingintransformationoftheobjectorarticleorthingintoanewand
distinct object or article or thing having a different name, character and use; or (ii) bringing into
existence of a new and distinct object, article or thing with a different chemical composition or
integral structure''.

(vll) EI]glble Service Sector Unlt is an enterprise in the services Sector that requires significant
capitalexpenditureandhassignificantemploymentgenerationpotential.
(vlll) Physlcal Work]ng Capltal is defined to include all physical inventories owned, held or controlled
bythefactoryasontheclosingdayoftheaccountingyearsuchasthematerials,fuels&lubricants,
storesetc.,thatenterjntoproductsmanufacturedbythefactoryitselforsuppliedbythefactoryto
other for processing. Physical working capital also includes the stock of materials, fuels & stores
etc., purchased expressly for re-sale, semi-finished goods and work in progress on account of
othersandgoodsmadebythefactorywhicharereadyforsaleattheendoftheaccountingyear.
However,itdoesnotincludethestockOfthematerials,fuels,storesetc.suppliedbyotherstothe
factory for processing. Finished goods processed by others from raw materials supplied by the
factory and held by them are included and finished goods processed by the factory from raw
materials supplied by others are excluded.

(]x)

Flaw Materlal means any raw material actually required and used by an industrial unit in
manufacturing of the tinished goods for which it is requested.

(x)

Worklng Capltal is the sum total of the physical working capital and the cash deposits in hand
and at bank and the net balance of amounts receivable over amounts payable at the end of the
accounting year. Working capital, however, excludes unused overdraft facility, fixed deposits
irrespectiveofduration,advancesforacquisitionoffixedassets,loansandadvancesbyproprietors
andpartnersirrespectiveoftheirpurposeandduration,longtermloansincludinginterestthereon
and investments.

(xl)

F[xed capltal Investment means an investment made in building, plant and machinery as well as
productive assets of permanent nature such as tcols, jigs, fixtures, dyes, crane, electrification, etc.

<!-- page 20 -->

12

(xii)'PlantandMachlnery'shallcoverthecostOfnewlypurchasedindustrialplalitandmachftyas
erectedatsite.Ftelocated/Reeycled/RefurbishedplantandmachineryisnotenolLetrassistarice
under the Scheme. Components to be included / excluded for the purpose of schane and for a
manufacturingunitareatAnnexure1I.ThepurchaseofmachineryshouldbefrunofH`markctat
normal market price.

(xii)(a) 'Plant and Machinery' in respect of Tourlsm Sectors (Hotels/SPA un.rt/toilrign Prpiect/

AmusementPark)andEntertalnmentSector(FilmStudio/FilmCfty/Ac"Jsde^u~m):

The cost Of construction of building (excluding land) and all the items/componentsi'eql-punts

exceptconsumablesanddisposableswhicharebasictotherunn.rngofthetourismprtpewi[l
be taken in to account for computing the value of Plant & Machinery. Hired/rented EREng will
not be taken into account.

(xll)(b) Definition of 'Plant and Machinery' in respect Of Health sectors (NL[rsing rJ- and
Super-specialltyHealthCare):Thecostofconstructionofbuilding(excludingland)anda]the
items/components/equipments relating to emergency services, general surgffy; rnalemfty

facilities,pathology,radiology,E.C.a,exceptconsumables,disposablesandarfuJaresvrm
arebasictotherunningoftheHealthunitwillbetakenintoaccountforcompritingifevaL.eof
Plant & Machinery. Hired/rented Building will not be taken into adeount.

(xil)(c). 'Plant and Machinery' in respect Of Educational sectors (Vocational hainhg catre/
Schools/Colleges)andlT&ITrelatedserviceindListries(Cal]cende):Thea&ofctltrrfu
Of building (excluding land) only neoessary for running of the unit will be taken in to accourt for
computingthevalueofPlant&Machinery.Hired/rentedBui[dingVI/illnotbetakenintoa-tnt.

(xii)(d). 'Plant and Machinery' in respect Of Power Generating Plant :
lncalculatingthevalueOfGeneratingPlantandMachineryofaPowerStation,thecastofPlant
andMachineryaserectedatsiteandrequiredforplanoperatiopwillbetakenintoarmlntwhich
will include the cost of main plant, any building associated systems, auxmary equipmem and
toolsbutexcludingthecostofland.Theamountinvestedjndam&reservoirregulatngsystem
(hoistsandgatesetc.)headandtailwaterconductorsystemorEOTcraneorotherappurtenant
equipmentifany,willbetakenintoaccountwhereelectricityisgeneratedbyusingwaterpewer
in a power generating unit. Working capital including cost of raw material/fuel and other
consumables will be excluded for computing the value Of Plant & Machinery.
(xiii)

Eligiblllty criteria :

(a)

An New Units/New Industrial units except those in Annexure-1 sha« be eligible under the
Arunachal Pradesh State Industrial & Investment Policy, 2020.

(b)

A unit shall have employment Of minimum of 20°/a people of Arunachal Pradesh in the
Managerialcadreandminimumof30°/opeopleofArunachalPradeshintheNon-Managerial
cadre. Employment certificate shall be obtained from the competent authority at the same
time the unit should follow the existing Labour Laws as regards to the employmem and
wages in the unit.

(c)

Incentives/ Subsidies/ Concessions/ Financial support under this policy shall be applicable
to units in the Private Sector, Joint Sector, Co-operatwes, Partnership firm. Proprietorship
Self-helpGroup(SHG),TrustandNon-GovernmentOrgaLnizafron(NGO).Theunitsetupby
StateGovemmentandcentralpublicsectorundenakingsshallnctbeelisibleforanyincerfues
under the Policy.

(d)

The units which are functional at the time of disbursemem of subsidy will be eligible for
subsidyfincentive.

(e)

No right or claim for any incentive under the policy shall be deemed to have been conferred
bythepolicymerelybyvirtueofthefactthattheunithasfulfilledonitsparttheconditionsof
the poliey and the incentives/subsidies cannot be claimed as a matter Of right.

(f)

Any payments made in cash for any transaction shall be treated as inelisible amount for
investment.

(g)

Hotels / F]esorts 3 star and above category and river cruise, generaton of power through
greentechnologyshallbeeligibleforincentivesunderthepo[icy.

<!-- page 21 -->

13

(xlv) Interpretation :
The decision of the Industries Department, Government of Arunachal Pradesh with regards to
Interpretation of any clause of the policy shall be final and binding.

(xv) Rights of the State Government :
(a)

Department of Industries, Government of Arunachal Pradesh reserves the right to amend any
provision(s) including amendment or withdraw any ofthe incentive/subsidy as and when neoessary
for development of industries and in the interest of the people of the State from time to time.

(b)

Department of Industries, Government ofArunachal pradesh reserves the rightto review the matter
regarding sanction/ disbursement Of subsidies/ incentives to the eligible industrial unit(s) and the
decision ot the State Government shall be final and binding.

(c)

Department of Industries, Government ofArunachal pradesh reserves the rightto modify the eligible/
non-eligible list of the industries, include or delete activities under thrust sectors and when required
in the interest of the &ate and preservation of environment and ecology.

4d) Department of Industries, Government ofArunachal pradesh reserves the right to make/ amend
t . ` the necessary rules for implementation of this policy as and when required.

<!-- page 22 -->

14

Cl-R€
PFtocEDUF]E FOFt CLAIMING OF SUBSIDYflNCENTIVES UNDEFt

"ESCHEME
(i)

Units intending to avail the benefits underthe scheme shall apply in Form-1 marked as AnnexureVlltotheconcemedDistrictlndustriesCentre(DIG)aftercommencementofcommeroialproduclion/
operation.

(ii)

Applicati`on submitted by the unit shall be scrutinized by the DIC concerned and their official(s)
shall also carry out physical verification Of the industrial unit to ensure its physical existence as
wellasfulfillmentofeligibilitycriteriabeforeforwardingitsrecommendationtotheDirectorateof
lndustriesforturtherconsideration.

(iii)

No right or claim for any incentives under the policy shall be deemed to have been conferred by the
policymerelybyvirtueofthefactthattheunithasfulfilledonitsparttheconditionsOfthepolicy

and the incentives/subsidies cannot be claimed as a matter of right.
(iv)

The incentives underthe policy cannot be claimed unless the unit has complied with the stipulation/
conditionstothesatisfactionofthecompetentauthority.ThedecisionOftheimplementingagency,
subjectto§uchdirectionasGovernmentmayissuefromtimetotimeinthisregardshallbefinal
and binding.

(v)

Submission of clalms for subsidiesfoenefits under the Scheme by eligible units shall be in the
prescribedApplicationFormaspertheAnnexure-Vll.

(vi)

Application for benefits under the Scheme along with requisite documents shall be submitted
within one year from the date of commencement Of commercial production/operation for claim
underthisScheme.Claimssubmittedaftertheabovetimelinewillbetime-barredandsuchclalms
will not be entertained.

(vii)TheDICmustensuretheclaimapplicationforschemeiscompleteinallrespectsandaccompanied
by all requisite documents.
(viii) Incomplete application or application without the required documents shall not be considered

under any circu instances.
(ix) TheJ3Iaim documents submitted by eligible unit shall be scrutinized by District Level Committee
(DLC)andtheDistrictlndustriesCentreconcemedandtheirofficial(s)shallalsocanyoutphysical
verification Of the applicant unit to ensure its physical existence, genuineness of the claim and
fulfillment of eljgibility criteria before placing its recommendation to Directorate Of Industries for
consideration of State Level Committee (SLC).

(x)

DIC shall coordinate meetings of DLC, prepare agenda notes and minutes of such meetings.

(xi)

Directorate of Industries shall verify the claim documents and the recommendations of the DLC
prior to placing the same before SLC. They will coordinate the meetings of the SLC, prepare
agenda notes and minutes of such meetings.

(xii)Thesubsidy/benefitsundertheschemeshouldnotbedisbursediftheclaimissubjudice.
(xiii) The quantum Of subsidy payable to the unit should be worked out/calculated on the eligible
components as laid down in the Scheme. In case of any doubt in this regard, the matter may be
referredtoDepartmentOflndustriesforclarification.ThedecisionofDepartmentoflndustrieswill
be final in this regard.

(xiv) All expenses must be certified by chartered Acoountant having
units falling under the Micro Category.

valid membership except for

(xv) All mandatory "no objection certificates"/clearances etc. must be obtained by the unit from the
concerned DepartmenvAuthority before consideration of claims.
(xvi) The subsidy claim will be considered by DLC/SLC only after the unit has started commercial
productionorhasbecomeoperational/functional.
(xvii) Sanction Of Incentives/subsidies : Sanction Of eligible subsidy claims shall be approved by the
State Level Committee (SLC) for Micro/Small/Medium/Large/Mega Large/Ultra Large units (tor
both manufactu ring & service/other sectors).

<!-- page 23 -->

15

(xvil) State Level Committee (SLC) :
The State Level Committee (SLC) will be constituted with the following members:-

(i)

Chief secretary

-

Chairman

(ii)

Commissioner/Secretary Industries Department

-

Member

(iii)

Commissioner/Secretaryof Finance Department

-

Member

(IV)

Commissioner/Secretaryof planning Department

-

Member

fy)

Directorof Industries

(vi)

Other member nominated by the state Government from financial institutions.

-Member secretary

The functions of the State Level committee shall be to:(a)

Scrutinize claim applications and approve cases for sanctions as may be found ell.gible for Micro/
Small/Medium/Large/MegaLarge/UltraLargeunits(manufacturing&service/othersectors).

(b)

Monitor and reviewthe progress of implementatjon of the scheme from timetotime.

(c)

Issue instructions, if necessary, for proper implementation of the scheme.

(d)

Quorum required is 1/3 of the members.

(e)

Member secretary may co-opt any official/persons for attending any meeting when occasion arise.

(xviii) Dlstrict Level Commlttee (DLC) :
Each district of the state, will have a District Level Committee (DLC) with the following members :
(i)

Deputy commissioner

-Chairman

(ii)

District planning officer

-Member

(iii)

Finance andAccountofficerof DC's office

-Member

(iv)

Deputy/Asstt. Director (Textiles and Handicraft) -Member

(v)

Manager, SBl/anyotherBankoperating

-Member

in the District

(vi)

JoinvDeputy/Assistant Director of DIG

-Member secretary

The functions of the District Level Committee shall be to :

(a)

Scrutinize claim applications and recommend cases for sanctions as may be found eligible for
Micro/Smal"edium/Large/MegaLarge/UltraLargeunits(manufacturing&service/othersectors)
to SLC (&ate Level Committee).

(b)

Monitor and review the progress of implementation of the scheme, as and when necessary.

(c)

Examine problems that may arise for implementation of the scheme and suggest suitable remedial
measures as may deem fit.

(a)

Quorum required is 1/3 of the members.

(e)

Chairman may co-opt any official/persons for attending any meeting when occasion arise.

<!-- page 24 -->

16

ANNEXURE-I

Negative List :
ThefollowingindustrieswillnotbeeligibleforbenefitsunderArunachalPradeshlndustrialandlnvestment
Policy, 2020.

1.

2.

All goods falling under chapter 24 Of the First schedule to the central Excise Tariff Act,1985 (5
ofl986)whichpertainstotobaccoandmanufacturedtobaccosubstitutes.

Pan Masala as covered under chapter 21 of the First schedule to the central Excise Tariff Act,
1985(5 Of 1 986).

3.

Plastic carry bags Of less than 20 micron as specified by Ministry of Environment and Forests
Nctif.ication No. S.O. 705 (E) dated 02.09.1999 and S.O. 698 (E) dated 17.6.2003.

4.

Goods falling under chapter 27 Of the First schedule to the central Excise Tariff Act,1985 (5 of
1986) produced by Petroleum or Gas refineries.

5.

Plantation, Pefineries and powergenerating units above 10 MW.

6.

Coke (including calcined petroleum coke), FlyAsh, Cement, Steel Plolling Mills.

7.

Units not complying with environment standards or not having applicable Environmental clearance
fromM/oEnvironment&ForestsandClimateChangeorStateEnvironmentallmpactAssessments
Authority (SEIAA) or not having requisite consent to establish and operate from the concerned
CentralPollutionControlBoard/StatePollutionControlBoardwillnotbeeligibleforincentiveunder

the scheme.
8.

Lowvalue addition activities like preservation during storage, cleaning, operations, packing, repacking
orre-labeling,sorting,alterationOfretailsalepriceetc.takeplaceexcludinghighvaluepackaging

and processi ng.
9.
10.

Any other industry/activity placed in negative list through a separate notification as and when
considerednecessarybytheGovernment.Itwillbeeffectivefromthedateofsuchnotification.
Goldandgoldore.
ANNEXUFtE-ll

List of White category Of Industries

SI. No.

Industry sector
Air coolers /conditioners

Bicycles, baby carriages
Bailing of waste papers
Bio ferti I izer foio-pesticides

Biscuits trays

Blending / packing of tea
Block making of printing

Chalk making

Compressed oxygen gas
Cotton and woolen hosiers
Diesel pump repairing
Electric lamp ( bulb) and CFL

Electrieal and electronic item
Engineering and fabrication units

Flavoured betel nuts
Fly ash bricks/ block

Fountaln pen

<!-- page 25 -->

Sl. No.

Industry sector
Glass ampules
Glass putty and sealant
Grou nd nut decorticati ng

Handloom/capetweaving
Leather cutting and stitching

Coir items from coconut husks

Metal caps containers etc
Shoe brush and wire brush
Medical oxygen
Organic and inorganic nutrients

Organic manure
Packing of powdered milk

Paper pins and u clips

Pepairlng of electric motors /generators
Hope (plastic and cotton)
Scientific and mathematical instrument

Solar module non-conventional energy apparatus
Solar power generation through solar photovoltaic cell, wind power and mini hydel power
(less than 25 MW)

Surgical and medical products assembling

ANNEXUFtE-l[]

List of Green category of Industries

Sl. No.

Industry sector

1.

Aluminium utensils

2.

Ayu rvedjc medicines

3.

Small Bakery/confectionery

4.

PP film

5.

Biomass briquettes

6.

Melamine resins

7.

Brass and bell metal utensils

8.

Candy

9.

Cardboard / corrugated box
Carpentry & wooden furniture

Cement products
Ceramic colour by mixing
Chilling plant and ice making

Coke briquetting
Small Cotton spinning and weaving
Dal Mills

<!-- page 26 -->

18

Sl. No.

Industry sector
Decoration of ceramic cups
Digital printing on PVC clothes

Handling, storage of food grains
Flour mills

Electrical Glass , ceramic, earthen potteries
Glue from starch
Gold and silver smithy
Non-polluting Heat treatment

Insulation /coated papers

Leather footwear/products
Blending of Lubricating oil, greases

Pasted veneers
Oil mill Ghani

Packi ng materials
Phenyl/toilet cleaner

Polythene and plastic products

Poultry, Hatchery and Piggery
Power looms (without dye and bleaching)
Puffed rice (muri) (gas or electrical heating)

Beady mix cement concrete

Peprocessing of waste cotton
Bice mill (Rice hullers only)
F`olling mill ( gas fired) and cold rolling mill

Pubber goods (gas operated baby boiler)
Saw mills

Soap manufacturing
Spice Blending

Spice grinding
Steel furniture

G rai ns processi ng

Tyres /tube retreati ng
Chilling /ice plant

C02 recovery
Distil led water

Small Hotels

Optical lenses
Mineralized water

Tamarind powder

<!-- page 27 -->

Sl. No.

Industry sector

55.

Marble stone

56.

Emery powder

57.

Flyash export

58.

Mineral stack yard

59.

Oil and gas transportation pipeline

60.

Seasoning of wood

61.

Synthetic detergent

62.

Tea processi ng

63.

Pulverization of bamboo

ANNEXURE-lv

List of Orange Category of Industries

Sl: No.

Industry sector
Almirah, Grill Manufacturing

Aluminium & copper extraction from scrap
Automobile servicing, repairing

Ayurvedic and homeopathic medicine
Brickfields

Building and construction >20,000 sq. in

Cashew nut processing
Ceram ics and Refractories
Chanachur and ladoo using husk fired oven

Coal washeries

Coated electrode
Coffee seed processing
Compact disc computer floppy

Copper waste recyclers
Dairy and dairy products ( small scale)
DG set ( >1 MVA but < 5MVA)
Dismantling of rolling stocks

Dry cell battery

Dry coal / mineral processing
Fermentation (Extra Neutral Alcohol)

Ferrous and Non-ferrous metal extraction
Fertilizer (granulation / formulation / blending

Fish feed, poultry feed and cattle feed

Fish processing and packing

Flakes from rejected PET bottle

Foam manufacturing

Food and food processing

<!-- page 28 -->

Sl. No.

Industry Sector

28.

Forging of feri.ous and nan- ferrous

29.

Formulation/pelletizationofcamphortabletsetc.

30.

Glass ceramics, earthen potteries and tile

31.

Gravure printing, digital printing on flex, v

32.

Heat treatment using oil fired furnace

33.

Hot mix plants

34.

lee cream

35.

lndustryorprocessesinvolvingfoundryoperations

36.

lodized salt from crude/ raw salt

37.

Jute processing without dyeing

38.

large Bakery and confectionery

39.

Transformerrepalring/manufacturing

40.

Tyresandtubesvulcanization/hotretread

41.

Vegetable oil manufactu ri ng

42.

Wire drawing and wire netting

43.

LargeCottonspinningandweaving

44.

Lime manufacturing (using lime kiln)

45.

Liquidfloorcleaner,blackphenyl

46.

Manufacturing of glass

47.

Manufacturing of mirror from sheet glass

48.

Manufacturing of mosquito repellent coil

49.

M an ufacturi ng of Starch/Sago

50.

Mechanized laundry using oil fired boiler

51.

Medium scale Hotels

52.

Modularwoodenfurniture

53.

New highway construction project

54.

Non-alcoholicbeverages(softdrink)

55.

Paint blending and mixing (Ball mill)

56.

Paints and varnishes (mixing and blending)

57.

Parboiled Bice Mills

58.

P harmaceutical form ulation

59.

Ply-board manufactu ri ng

60.

Potable alcohol ( lMFL) by blending

61.

Printing ink manufacturing

62.

Printing or etching of glass sheet

63.

Printing press

64.

Producer gas plant

65.

Recyclers - used oils

66.

Plecyclers -waste oils

<!-- page 29 -->

SI. No.

Industry sector
Recycling - Paint and ink Sludge

Reprocessing of waste plastic /PVC
Ftolling mill (oil or coal fired)

Silica gel

Silk /saree screen printing
Spray painting

Steel and steel products with furnaces

Stone crushers
Surgical and medical products (latex)

Synthetic detergents and soaps
Synthetic resins
Synthetic rubber excluding molding

Tephlon based products
Thermocol manufacturing ( with boiler)

Thermometer
Tobacco products including cigarettes

Tooth powder, toothpaste, talcum powder

ANNEXUF]E-V

List of Red Category of Industries

Sl. No.

Industrysector

1.

Isolated storage of hazardous chemicals

2.

Automobile Man ufacturi ng (i ntegrated)

3.

Hazardous waste recycling (Spent cleared mctal catalyst)

4.

Lubricating oils and grease mfg.

5.

DG Set (> 5 MVA)

6.

Carbon black & allied

7.

Lead acid battery

8.

Phosphate rock processing

9.

Power generation plant

Hazardous Waste Becyclers (Spent catalyst)
Chlorinated hydrocarbons

Sugar
Fibre glass production

Fire crackers
E-Waste Plecycle rs
Milk and dairy products

Phosphorous
Pulp & Paper

Coke making

Explosives / detonators

<!-- page 30 -->

22
Sl. No.

Industry sector
Paints varnishes, pigments
Organic Chemicals
Airports and Commercial Air Strips

Asbestos
Basic chemicals

Cement
Chlorates, per-chlorates & peroxides
Chlorine, fluorine, bromine, iodine

Dyes and Dye-lntermediates
Health-care Establ ishment
Hotels (Big)

Lead acid battery -recyclers
Waste electrical and electronic recyclers
Glue and gelatin
Mining and ore beneficiation

Nuclear power plant
Pesticides
Photographic film /chemicals

Yarn / Textile processing
ChlorAlkali

Ship Breaking

Oil and gas extraction

Metal su rface treatment
Tanneries
Ports/harbor/jetties
Synthetic fibres

Thermal Power Plants

Slaughter house
Aluminium Smelter

Copper Smelter
Fertilizer (basic)

Integrated Iron & Steel

Pulp & Paper ( bleaching)

Zinc Smelter

oil Refinery

Petrochemicals

Pharmaceuticals
Pulp & Paper ( Large-Agro + wood),
Distillery

Plailway locomotive work shop/ service centers

<!-- page 31 -->

23
ANNEXUF]E-VI

A. Components to be included for comput]ng the value of Plant and
manufacturing sector :

Machinery in the

(i)

Cost of Industrial Plant & Machinery including taxes and duties i.e. cost of mother production
equipment used for carrying out manufacturing activities.

(ii)

Cost of productive equipment-+bjm/ such as tools, jigs, dyes and moulds, insurance premium
etc. including taxes and duties.

(iii)

Electrical components necessary for plant operation on the plant side from where meter is installed
up to the point where finished goods is to be produced/ dispatched (i.e. H.T. Motors, L.T. Motors,
Switch Boards, Panels, Capacitors, Relay, Circuit Breakers, Panel Boards, Switchgears).

(iv)

Freight charges paid for bringing plant & Machinery and equipment from the supplier's premises to
the location of the unit.

(v)

Transit Insurance premium paid.

(vi)

The amount invested in goods carriers to the extent they are actually utilized for transport of raw
materials and marketing of the finished products.

8. Components which w]ll not be considered for computing the value of Plant & Mach]nery in the
manufacturing sector :
(i)

Loading and unloading charges.

(ii)

Sheds/ buildingsfor plant & Machinery.

(iii)

Miscellaneous fixed assets such as DG sots, Excavation/ Mining equipment, handling equipment,
electrical components other than those mentioned atA (iii) above.

(iv)

Working capital including raw material and other consumable stores.

(v)

Commissioning cost.

(vi) Captive power plants.
(vii) Storage equipment.
(viii) Weigh bridge, Laboratory testing equipment.

C. Admissibility of erection and installation charges in the manutacturing sector :
Erection and installation charges will be payable on actual basis and will be restricted to the cost
indicated in the Appraisal Note of the Financial Institutions which provided loan to the industrial unit.

<!-- page 32 -->

24
ANNEXURE-VII

FOPM-1
APPLICATION FORM FOPI CLAIMING 0F
INCENTIVES UNDER THE ARUNACHAL PRADESH
INDUSTF!IAL AND INVESTMENT POLICY, 2020.

Sl.N o.
1.

2.

PARTIC U LAPS

Name Of the unit :

Factory/unit address :
Area/Locality
VillageITown/City

Post office
District

PIN Code
Email lD

Land line/Mobile No.

3.

Office address :
Area/Locality
VillageITown/City
C&PID Block

Post office
District

Email lD

Land line/Mobile No.

PIN Code
4.

Plegistered office's address :
Area/Locality
VillageITown/City
C&BD Block
Post office
District
Email ID

Land line/Mobile No.

PIN Code
5.

Category of Enterprise :
(Micro/Small/ Medium/Large)

6.

Whether the unit falls under :
manufacturing/service/other

sectors
7.

Constitution of the unit :
(a) (Proprietorial/

Partnership/ Private Limited/
Lim ited Company/Cooperative
society/LLP)

(b) Name(s). address(es),
Aadhar No., PANITAN No.
Of the proprietor/Partners/

Directors/Secretary and
Presidentof the Cooperative
Society

<!-- page 33 -->

Sl. No.

pAFmcuLARs

8.

Date of commencement of
commercial produdion/operation

9.

Fixed Capital Investment

10.

Source of finance

11.

Details of Term/Working
Loan (if any)

12.

Power :
(i)

Sanctioned load

(ii)

Connected Load

(iii) Capacity of captive power
plant (if any)
13.

Details of land and building :

Land
(a)

Own land

(i)

Landarea, Revenuevillage,
Dag No.& patta No.

(ii)

Date of purchase

(iii) Date of registration(b)Landallottedby

Govern ment/ Govt.
Agency :
(i)

Date of allotment/

agreement
(ii) Dateoftaking over

possession

(c)

Leaseholdsland :
(i) Date of lease of land
(ii) Period of lease

Building

(a) Own building/rented
building

(b) ln case Of own building,
built up area
14.

Employment generation:
(a) Managerial

(b) supewisory
(c) Skilled

(d) Semi-skilled
(e) Unskilled

(f) Others

<!-- page 34 -->

Sl. No.

PARTICULAF{S15.Itemsofproduction,raw

material & installed capacity

(a)

Raw material

(b)

Items of production &
installed capacity

I
Sl.NO.

Rawmaterial

Qty

Source

§1.No.

Item

installedCapacity

Actualproduction

I

declare and affirm that the

above, are true to my/our knowledge and belietand if any statement made

particular/statement furnished above, are true to my/our Knowieuge cH Iu ut3iici ai „ „ a ,,,... `v ...... ` . . .___

herewitliinconnectionwiththeseclaimsisdetectedas{alseormisrepresent,theamountOfincentives

grantedbytheGovernmentwillberefundedbyme/ustotheStateGovemment.

Place:

Date:

Signatureofauthorizedpersonofapplicantunit
(Full name & Designation)

<!-- page 35 -->

Directorate of Industries
Name

Mobile No.

1.

Sliri N.T. Glow, Secretary

:

9485231064

2.

Shri Habung Donyi, Director

:

9862200001

3.

Shri Koling Koyu, Jt. Director

:

9436272189

4.

Shri Mobia pugang, Jt. Director

:

9436255504

5.

Shri Lod Takkar, Under secretary :

9436250517

6.

Shri Tuli Basar, Dy. Director

:

7085674988

7.

Shn' Goli Angu, Dy. Director

:

9436229034

8.

Shri Geto Ori, Asst. Director

:

9436040432

9.

Shri D. Sengupta, EO

:

9436223962

10. Shri Upendra Prasad, EO

:

8132887861

11. Shri 8. Dutta, EO

:

9436897779

<!-- page 36 -->

PUBLISHED BY

Department of Industries
Government of Arunachal Pradesh
Udyog Sadan, C Sector,
ltanagar -791111

IMPORTANT ADDRESS f~
Chief Secretary
Government of Arunachal Pradesh
'tanagar
0360 -2212595/2211187/2212540
2215719/2212446 (Fax)
Email : cs-arunachal@nic.in

Secretary Industries
Government of Arunachal Pradesh
ltana8ar
0360 - 2218638
Email : secretaryindustriesarp@gmail.com

Director lndustr!es
Government of Arunachal Pradesh
udyog Sadan, ltanagar
0360 -2212323
:,directorindustries_arp@rediffmail.com

PrirfeddyDlrootomtoofPrindng,Govl. Of Ar`Inachal Predech, Nahahagun,94-2020-Dir.(Induetrlo8)02-100-2020.
