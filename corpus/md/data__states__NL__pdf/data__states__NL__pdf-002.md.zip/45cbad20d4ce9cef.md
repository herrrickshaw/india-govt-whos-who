---
doc_id: "45cbad20d4ce9cef"
source_url: "https://nagalandtax.nic.in/docs/GST/CBIC_circulars/2023/circular-cgst-195.pdf"
ministry: "Department of Taxes, Nagaland"
title: "Clarification on availability of ITC in respect of warranty replacement of parts and repair services during warranty period"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "06fc54b310463c6f"
---

<!-- page 1 -->

Circular No. 195/07/2023-GST
F. No. CBIC-20001/5/2023-GST
Government of India
Ministry of Finance
Department of Revenue
Central Board of Indirect Taxes and Customs
GST Policy Wing
****
New Delhi, Dated the 17th July, 2023
To,
The Principal Chief Commissioners/ Chief Commissioners/ Principal Commissioners/
Commissioners of Central Tax (All)
The Principal Directors General/ Directors General (All)
Madam/Sir,
Subject: Clarification on availability of ITC in respect of warranty replacement of parts
and repair services during warranty period.
Representations have been received from trade and industry that as a common trade
practice, the original equipment manufacturers /suppliers offer warranty for the goods / services
supplied by them. During the warranty period, replacement goods /services are supplied to
customers free of charge and as such no separate consideration is charged and received at the
time of replacement. It has been represented that suitable clarification may be issued in the
matter as unnecessary litigation is being caused due to contrary interpretations by the
investigation wings and field formations in respect of GST liability as well as liability to reverse
ITC against such supplies of replacement of parts and repair services during the warranty
period without any consideration from the customers.
2.
The matter has been examined. In order to ensure uniformity in the implementation of
the provisions of the law across the field formations, the Board, in exercise of its powers
conferred under section 168(1) of the Central Goods and Services Tax Act, 2017 (hereinafter
referred to as the CGST Act), hereby clarifies as follows:
S.
No.
1.

Issue

Clarification

There are cases where the
original
equipment
manufacturer offers warranty
for the goods supplied by him
to the customer and provides
replacement of parts and/ or
repair services to the
customer during the warranty

The value of original supply of goods (provided
along with warranty) by the manufacturer to the
customer includes the likely cost of replacement of
parts and / or repair services to be incurred during
the warranty period, on which tax would have
already been paid at the time of original supply of
goods.

Page 1 of 4

<!-- page 2 -->

period, without separately
charging any consideration at
the time of such replacement/
repair services.
Whether GST would be
payable on such replacement
of parts or supply of repair
services,
without
any
consideration
from
the
customer,
as
part
of
warranty?
2.

Whether in such cases, the
manufacturer is required to
reverse the input tax credit in
respect of such replacement
of parts or supply of repair
services as part of warranty,
in respect of which no
additional consideration is
charged from the customer?

3.

Whether GST would be
payable on replacement of
parts and/ or repair services
provided by a distributor
without any consideration
from the customer, as part of
warranty on behalf of the
manufacturer?

4.

In the above scenario where
the
distributor
provides

As such, where the manufacturer provides
replacement of parts and/ or repair services to the
customer during the warranty period, without
separately charging any consideration at the time
of such replacement/ repair services, no further
GST is chargeable on such replacement of parts
and/ or repair service during warranty period.
However, if any additional consideration is
charged by the manufacturer from the customer,
either for replacement of any part or for any
service, then GST will be payable on such supply
with respect to such additional consideration.
In such cases, the value of original supply of goods
(provided along with warranty) by the
manufacturer to the customer includes the likely
cost of replacement of parts and/ or repair services
to be incurred during the warranty period.
Therefore, these supplies cannot be considered as
exempt supply and accordingly, the manufacturer,
who provides replacement of parts and/ or repair
services to the customer during the warranty
period, is not required to reverse the input tax
credit in respect of the said replacement parts or on
the repair services provided.
There may be instances where a distributor of a
company provides replacement of parts and/ or
repair services to the customer as part of warranty
on behalf of the manufacturer and no separate
consideration is charged by such distributor in
respect of the said replacement and/ or repair
services from the customer.
In such cases, as no consideration is being charged
by the distributor from the customer, no GST
would be payable by the distributor on the said
activity of providing replacement of parts and/ or
repair services to the customer.
However, if any additional consideration is
charged by the distributor from the customer,
either for replacement of any part or for any
service, then GST will be payable on such supply
with respect to such additional consideration.
(a) There may be cases where the distributor
replaces the part(s) to the customer under warranty
Page 2 of 4

<!-- page 3 -->

replacement of parts to the
customer as part of warranty
on
behalf
of
the
manufacturer, whether any
supply is involved between
the distributor and the
manufacturer and whether the
distributor would be required
to reverse the input tax credit
in
respect
of
such
replacement of parts?

5.

Where
the
distributor
provides repair service, in
addition to replacement of
parts or otherwise, to the
customer
without
any

either by using his stock or by purchasing from a
third party and charges the consideration for the
part(s) so replaced from the manufacturer, by
issuance of a tax invoice, for the said supply made
by him to the manufacturer. In such a case, GST
would be payable by the distributor on the said
supply by him to the manufacturer and the
manufacturer would be entitled to avail the input
tax credit of the same, subject to other conditions
of CGST Act. In such case, no reversal of input tax
credit by the distributor is required in respect of the
same.
(b) There may be cases where the distributor raises
a requisition to the manufacturer for the part(s) to
be replaced by him under warranty and the
manufacturer then provides the said part(s) to the
distributor for the purpose of such replacement to
the customer as part of warranty.
In such a case, where the manufacturer is
providing such part(s) to the distributor for
replacement to the customer during the warranty
period, without separately charging any
consideration at the time of such replacement, no
GST is payable on such replacement of parts by
the manufacturer. Further, no reversal of ITC is
required to be made by the manufacturer in respect
of the parts so replaced by the distributor under
warranty.
(c) There may be cases where the distributor
replaces the part(s) to the customer under warranty
out of the supply already received by him from the
manufacturer and the manufacturer issues a credit
note in respect of the parts so replaced subject to
provisions of sub-section (2) of section 34 of the
CGST Act. Accordingly, the tax liability may be
adjusted by the manufacturer, subject to the
condition that the said distributor has reversed the
ITC availed against the parts so replaced.
In such scenario, there is a supply of service by the
distributor and the manufacturer is the recipient of
such supply of repair services in accordance with
the provisions of sub-clause (a) of clause (93) to
section 2 of the CGST Act, 2017.
Page 3 of 4

<!-- page 4 -->

6.

consideration, as part of
warranty, on behalf of the
manufacturer but charges the
manufacturer for such repair
services either by way of
issue of tax invoice or a debit
note, whether GST would be
payable on such activity by
the distributor?
Sometimes
companies
provide offers of Extended
warranty to the customers
which can be availed at the
time of original supply or just
before the expiry of the
standard warranty period.
Whether GST would be
payable in both the cases?

Hence, GST would be payable on such provision
of service by the distributor to the manufacturer
and the manufacturer would be entitled to avail the
input tax credit of the same, subject to other
conditions of CGST Act.

(a) If a customer enters in to an agreement of
extended warranty with the manufacturer at the
time of original supply, then the consideration for
such extended warranty becomes part of the value
of the composite supply, the principal supply
being the supply of goods, and GST would be
payable accordingly.
(b) However, in case where a consumer enters into
an agreement of extended warranty at any time
after the original supply, then the same is a
separate contract and GST would be payable by
the service provider, whether manufacturer or the
distributor or any third party, depending on the
nature of the contract (i.e. whether the extended
warranty is only for goods or for services or for
composite supply involving goods and services)

3.
It is requested that suitable trade notices may be issued to publicize the contents
of this Circular.
4.
Difficulty, if any, in implementation of this Circular may please be brought to
the notice of the Board. Hindi version would follow.

Sanjay Mangal
Principal Commissioner (GST)

Page 4 of 4
