---
doc_id: "b5bae4cddabd7ce6"
source_url: "https://nagalandtax.nic.in/docs/GST/Circular/CBIC_CR_98_2019_Seeks_to_clarify_the_manner_of_utilization_of_input_tax_credit.pdf"
ministry: "Department of Taxes, Nagaland"
title: "Clarifications in respect of utlisation of ITC under GST"
date: ""
pages: 4
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "faff0bb453326fc8"
---

<!-- page 1 -->

GOVERNMENT OF NAGALAND
OFFICE OF THE COMMISSIONER OF STATE TAXES
NAGALAND: DIMAPUR
Dated Dimapur, the 23" April, 2019
CIRCULAR-05/2019-GST

Subject: Clarification in respect of utilization of input tax credit under GST — Reg.

Section 49 was amended and Section 49A and Section 49B were inserted vide
Nagaland Goods and Services Tax (Amendment) Act, 2018 [hereinafter referred to as the
NGST (Amendment) Act]. The amended provisions came into effect from 1° February 2019.
2 Various representations have been received from the trade and industry regarding
challenges being faced by taxpayers due to bringing into force of section 49A of the
Nagaland Goods and Services Tax Act, 2017 (hereinafter referred to as the NGST Act). The
issue has arisen on account of order of utilization of input tax credit of integrated tax in a
particular order, resulting in accumulation of input tax credit for one kind of tax (say State
tax) in electronic credit ledger and discharge of liability for the other kind of tax (say Central
tax) through electronic cash ledger in certain scenarios. Accordingly, rule 88A was inserted
in the Nagaland Goods and Services Tax Rules, 2017 (hereinafter referred to as the NGST
Rules) in exercise of the powers under Section 49B of the NGST Act vide notification
F.NO.FIN/REV-3/GST/1/08(Pt-1) (Vol.1)/118 , dated 29" March, 2019. In order to ensure
uniformity in the implementation of the provisions of the law, the Commissioner, in exercise
of its powers conferred by section 168 of the NGST Act, hereby clarifies the issues raised as
below.
Bi The newly inserted Section 49A of the NGST Act provides that the input tax credit of
Integrated tax has to be utilized completely before input tax credit of Central tax / State tax
can be utilized for discharge of any tax liability. Further, as per the provisions of section 49
of the NGST Act, credit of Integrated tax has to be utilized first for payment of Integrated
tax, then Central tax and then State tax in that order mandatorily. This led to a situation, in
certain cases, where a taxpayer has to discharge his tax liability on account of one type of tax
(say State tax) through electronic cash ledger, while the input tax credit on account of other
type of tax (say Central tax) remains un-utilized in electronic credit ledger.

Page 1 of 4

<!-- page 2 -->

4, The newly inserted rule 88A in the NGST Rules allows utilization of input tax credit
of Integrated tax towards the payment of Central tax and State tax, or as the case may be,
Union territory tax, in any order subject to the condition that the entire input tax credit on
account of Integrated tax is completely exhausted first before the input tax credit on account
of Central tax or State / Union territory tax can be utilized. It is clarified that after the
insertion of the said rule, the order of utilization of input tax credit will be as per the order (of
numerals) given below:
(ID — In any order and in any proportion

(IID) Input tax Credit on account of Integrated tax to be completely exhausted mandatorily
State tax / Union (VID Not permitted (VD

Territory tax

Si The following illustration would further amplify the impact of newly inserted rule
88A of the NGST Rules:

Illustration:

Amount of Input tax Credit available and output liability under different tax heads
State tax / Union Territory tax
Option 1:
oot ore ee en
Input tax Credit on account of Integrated tax has been completely exhausted
Page 2 of 4

<!-- page 3 -->

a
State tax / 0 200
¢ Union
territory tax
Option 2:
:
Input tax Credit on account of Integrated tax has been completely exhausted
comre Tm
State tax / 100
Union
territory tax
6. Presently, the common portal supports the order of utilization of input tax credit in
accordance with the provisions before implementation of the provisions of the NGST
(Amendment) Act i.e. pre-insertion of Section 49A and Section 49B of the NGST Act.
Therefore, till the new order of utilization as per newly inserted Rule 88A of the NGST Rules
is implemented on the common portal, taxpayers may continue to utilize their input tax credit
as per the functionality available on the common portal.
a It is requested that suitable trade notices may be issued to publicize the contents of
this circular.
8. Difficulty, if any, in the implementation of this Circular may be brought to the notice
of the Board.
oa
( ‘YU YHOME) IAS
Commissioner of State Taxes
Nagaland: Dimapur
Page 3 of 4

<!-- page 4 -->

NO.CT/LEG/GS1 -crisit/ 1343 Dated Dimapur, the 23 April, 2019
: Copy to:-

1. The Finance Commissioner to the Government of Nagaland Finance Department
(Revenue Branch) for information.

2. All Additional Commissioner of State Taxes/ Joint Commissioner of State Taxes,
Nagaland, Dimapur for information and necessary action.

3. All Deputy Commissioner of State Taxes/ Superintendent of State Taxes/Inspectors of
State Taxes, Nagaland for information and necessary action.

4. The Editor, Nagaland Gazette, Kohima for publication in the Gazette Extraordinary.

5. The Director, Information and Public Relations, Kohima for wide publicity.

6. Guard file.

agaland: Dimapur
Page 4 of 4
