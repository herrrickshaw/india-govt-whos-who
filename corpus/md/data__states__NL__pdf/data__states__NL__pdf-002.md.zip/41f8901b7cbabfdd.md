---
doc_id: "41f8901b7cbabfdd"
source_url: "https://dte.nagaland.gov.in/wp-content/uploads/2024/06/Lateral-Entry-ITI-Notification-2024.pdf"
ministry: "Directorate of Technical Education, Nagaland"
title: "Click here to VIEW/DOWNLOAD"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "fc71cd0400c6b6d0"
---

<!-- page 1 -->

sf. % GOVERNMENT OF NAGALAND
, om ® DIRECTORATE OF TECHNICAL EDUCATION ;
Si or Sg Nagaland : Kohima - 797 004
Dated, Kohima the June, 2024
NOTIFICATION
NO.DTE/SCTE/ITI/70/2023-24: Interested ITI Pass out students who wish to pursue
Diploma Engineering courses through Lateral Entry under the State run Polytechnics are
invited to collect the Application Form from Directorate of Technical Education during office
hour’s w.e.f 14" June 2024. The form may also be downloaded from the official website
https://dte.nagaland.gov.in and printed on white paper (A4 size). The fill-up form should be
submitted by hand on or before 24" June, 2024.
(Er. VIPULHOU LHOUNGU)
Director
NO.DTE/SCTE/ITI/70/2023-24/ 5 SEF Dated, Kohima the 3" June, 2024
Copy to:
1.The Additional Secretary to the Govt. of Nagaland, Department of Higher &
Technical Education, Nagaland ,Kohima for kind information.
2. The P.A. to the Hon’ble Advisor for Transport & Technical Education, Govt. of
Nagaland, Kohima for kind information to the Hon’ ble Advisor.
3.The Director IPR, Nagaland, Kohima, with a request to publish the above
Notification as advertisement in all the local newspapers.
4.The Director, Employment, Skill Development & Entrepreneurship, Nagaland,
Kohima for information.
5. The Principal, KPA, GPK, ICIT, GPSC, GPST, GPTCP, GPAM for information &
necessary action.
6 Website in-charge, DTE for information & necessary action.
7. Office Notice board.
8. Office Copy.
t
(Er. VIP L inet
Director
=) dir.techedu-ngl@nic.in / tenagaland@gmail.com €&  0370-2270409/2271432 https://dte.nagaland.gov.in
