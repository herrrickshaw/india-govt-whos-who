---
doc_id: "529c5ff5b6edcdd1"
source_url: "https://nagalandtax.nic.in/docs/GST/CBIC_circulars/2017/9.2017%20CR%20Authorized%20officer%20for%20enrollment%20of%20Goods%20and%20Services%20Tax%20Practitioner.pdf"
ministry: "Department of Taxes, Nagaland"
title: "9.2017 CR Authorized officer for enrollment of Goods and Services Tax Practitioner"
date: ""
pages: 2
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "8173c33042ed1455"
---

<!-- page 1 -->

GOVERNMENT OF NAGALAND.
OFFICE OF THE COMMISSIONER OF STATE TAXES
NAGALAND: DIMAPUR
Dated Dimapur, the 18" October, 2017
CIRCULAR-07/9/2017-GST
Ref-CBIC Circular No.9/9/2017-GST dated 18-10-2017
Subject: Officer authorized for enrolling or rejecting application for Goods and Services
Tax Practitioner—Reg.
In pursuance of clause (91) of section 2 of the Nagaland Goods and Services Tax Act,
2017 (4 of 2017) read with section 20 of the Integrated Goods and Services Tax Act, 2017 (13 of
2017) and subject to sub-section (2) of section 5 of the Nagaland Goods and Services Tax Act,
2017, the Commissioner, hereby specifies the Superintendent of State Taxes/Deputy
Commissioner, having jurisdiction over the place declared as address in the application for
enrolment as Goods and Service Tax Practitioner in FORM GST PCT-1 submitted in terms of
sub-section (1) of section 48 of the Nagaland Goods and Services Tax Act, 2017 read with sub-
rule (2) of rule 83 of the Nagaland Goods and Service Tax Rules, 2017 as the officer authorized
to approve or reject the said application.
2 It is also clarified than the applicant shall be at liberty to choose either the Centre or the
State as the enrolling authority. The choice will have to be specified by the applicant in Item 1 of
Part B of FORM GST PCT-1.
Ki This Circular is clarificatory in nature and not meant for any interpretation of provisions
of the Act and Rules. .
4. Difficulty, if any, in implementation of the above instructions may please be brought to the
notice of the Commissioner at an early date.
Sd/-
(Y. MHATHUNG MURRY)
Commissioner of State Taxes
Nagaland: Dimapur
nocriuecicrasns67/6 0 Dated Dimapur, the 18" October, 2017
Copy to:-

<!-- page 2 -->

I. The Finance Commissioner to the Government of Nagaland Finance Department
(Revenue Branch) for information.

2. All Additional Commissioner of State Taxes/ Joint Commissioner of State Taxes,
Nagaland, Dimapur for information and necessary action.

3. All Deputy Commissioner of State Taxes/ Superintendent of State Taxes/Inspectors of
State Taxes, Nagaland for information and necessary action.

4. Programme Officer for uploading it in the Official Website for information to all
concerned.

5. Guard file.

4 4
Commissioner ote Taxes
Nagaland: Dimapur
