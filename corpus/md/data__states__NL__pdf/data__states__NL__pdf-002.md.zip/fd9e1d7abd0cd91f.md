---
doc_id: "fd9e1d7abd0cd91f"
source_url: "https://nagalandtax.nic.in/docs/GST/O.M._Applicability_of_GST_on_Extra_Neutral_Alcohol_ENA_.pdf"
ministry: "Department of Taxes, Nagaland"
title: "Applicability of GST on Extra Neutral Alcohol ENA"
date: ""
pages: 4
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "62acb6e6c1ce2be1"
---

<!-- page 1 -->

= al
~ 7
.
J
a Wy F.No.354/ 117 /2017-TRU
\y , Government of India
\ “a y 4 1% Ministry of Finance
Va “ A | Department of Revenue
» . Tax Research Unit
Q IR
“S Room No.146 G, North Block,
i New Delhi, the 16th January, 2018
i OFFICE MEMORANDUM
"Subject: Applicability of Goods and services Tax on Extra Neutral Alcohol (ENA
The undersigned is directed to refer to 20" meeting of GST Council held on
05.08.2017, wherein the matter regarding taxation of rectified spirit/ Extra Neutral Alcohol
(ENA) under GST was deliberated upon and it was agreed that legal opinion of the Attorne
Pp 8) ‘gal op: y
General of India may be sought on the matter.
2: Accordingly, the matter regarding levy of GST on supply of ENA for manufacture of
alcoholic liquor for human consumption within the prevailing constitutional provisions, was
referred to Ld. Attorney General, who has conveyed his considered opinion on the matter,
through the Ministry of Law and Justice.
; 3. In this context, find attached herewith the opinion of the Ld. Attorney General for
i circulation to concerned GST officers of state and central government in all States.
i
: Encl: As above. tor
Celt
(Mohit Tewari)
. Under Secretary (TRU- I)
The Commissioner,
_ GST Council Secretariat,
5th Floor, Tower I, Jeevan Bharti Building, Janpath Road,
Connaught Place, New Delhi-110 001.
Dated } ! } WZ.

<!-- page 2 -->

2s
197
Dy.No.772/AGU/2017
< No.AG16/2017-Adv.C
Office of the Attorney General for India
Supreme Court
The Union of India, Ministry of Finance, has sought my opinion on the
legality of the levy of Goods and Services Tax (GST) on supply of extra
neutral alcohol (ENA) for manufacture of alcoholic liquors for human
J consumption,
I must state at the outset that while there is no dispute between the
Centre and the States as to the levy of GST on industrial alcohol (i.e.
denatured ENA), there is divergence of opinion in regard to ENA that is used
| for manufacture of ‘alcoholic liquor for human consumption.’ The brief for
opinion annexes a note containing the views received from the State of West
Bengal. The State objects to the levy of GST on ENA by relying on the
Judgment of the Supreme Court of India in Bihar Distillery v. Union of India
(1997) 2 SCC 727. The State contends that no GST can be levied on ENA that
is used to manufacture alcoholic liquor for human consumption and the power
i {o regulate and impose taxes on ENA is vested exclusively in the States,
; Subsequently, on 24" October 2017, the Ministry of Finance has forwarded a
copy of the representations received from the Government of Tamil Nadu,
Rajasthan and Andhra Pradesh, These States also place reliance on the
| judgment of the Supreme Court in Bihar Distillery (supra) to contend that no
GST can be levied on ENA. Thereafter, on 18" November 2017, at the request
of the Ministry of Finance, I held a conference with the representatives of the
States of West Bengal, Karnataka, Andhra Pradesh, Tamil Nadu, Rajasthan
and Maharashtra. During the conference, these States have once again placed
reliance on the judgment of the Supreme Court in Bihar Distillery to submit
that the power to levy tax on ENA would vest exclusively with the State
Governments and therefore, no GST can be levied,

It is in this background that the Ministry of Finance has sought my
opinion. I have examined the facts in detail and I am of the view that even
though the judgment of the Supreme Court in Bihar Distillery (supra) does
hold that the States have the power to control rectified spirit removed for

7 manufacturing potable liquors, this judgment cannot be used as precedent for
the proposition that the States have absolute power to impose taxes on ENA
that is used to manufacture ‘alcoholic liquor for human consumption.’ This is
because:

I. The court in Bihar Distillery was not concerned with the power of the

State to levy Excise under Entry 51. To that extent, the court did not

deal with the meaning of the words ‘alcoholic liquor for human

consumption’ as used in Entry 51. On the other hand, the Court was
only concerned with the regulatory power of the State under Entry 8 of
List II. Entry 8 in its entirety reads -- ‘intoxicating liquors, that is to
say, the production, manufacture, possession, transport, purchase and
sale of intoxicating liquors’. Nowhere does Entry 8 use the phrase
‘alcoholic liquor for human consumption’
2. The meaning of the term ‘alcoholic liquor for human consumption’ has
' been dealt with categorically in Synthetics and Chemicals v. State of
| UP (1990) 1 SCC 109 (7 judges) and State of UP v. Modi Distillery
' (1995) 5 SCC 753 (3 judges). In Synthetics, the Court has held that the
expression ‘alcoholic liquor for human consumption’ means that liquor )
Page 1 of 3 /

<!-- page 3 -->

-lb- 26
which as it is consumable in the sense capable of being taken by human
beings as such as beverage of drinks, In Modi Distillery, the Court held

+ om that ethyl alcohol (95 per cent) was not an alcoholic liquor for human
consumption but could be used as _a raw material or input, after
processing and substantial dilution, in the production of whisky, gin,
country liquor, etc,

3. The two judge bench of the Court in Bihar Distillery (supra) has not
referred to the three judge bench decision in Modi Distillery where the
Court, dealing with the power of the State under Entry. 51 List I,

{ clearly held that “by common standards, ethyl alcohol (which had 95

Z | per cent strength) was an industrial alcohol and was not fit for human
consumption.”

4. The Supreme Court has subsequently overruled Bihar Distillery on the |
very question of imposition of excise duty by the State on rectified
spirit. In Deccan Sugar & Abkari Co. Ltd. v. Commissioner of Excise,

| AP , (1998) 3 SCC 272 the Supreme Court once again dealt with the
question of the power of the State to levy Excise duty on rectified spirit
4 and after noticing the judgment in Bihar Distillery, the Court referred
Fy the matter to a larger bench for consideration of the question whether
: any excise duty can be levied by the State on the manufactured rectified
spirit which may ultimately be used for production of potable liquor. At
i | Para 4 of the judgment, the Court held:
: ‘4. It is to be kept in view that the aforesaid
* decision rendered in Bihar Distillery case [(1997)
2 SCC 727] by a Bench of two learned Judges of
this Court was strictly concerned with the question
whether the State could cancel licences given to a
distillery manufacturing rectified spirit on the
grounds as alleged to be relevant for such
cancellation. Therefore, strictly speaking there
was no occasion for this Court in Bihar Distillery
case [(1997) 2 SCC 727] to consider the wider
question whether any excise duty can be levied by
the State on the manufactured rectified spirit
which may ultimately be used for production of
potable liquor. Even that apart the aforesaid
‘ observations made in Bihar Distillery case [(1997)
2 SCC 727] by the Division Bench of this Court
| prima facie run counter to the scheme of
é legislative competence as examined by the
+ Constitution Bench of this Court as well as in the
three-Judge Bench decision of this Court in Modi
Distillery [((1995) 5 SCC 753] . Consequently, in
our view these matters are required to be placed
for decision before a larger Bench of three learned F
Judges of this Court for reconsideration of the
judgment in Bihar Distillery case [(1997) 2 SCC !
727] . We therefore direct the Registry to place all
these appeals for disposal before a larger Bench
of three learned Judges......’

5. Thereafter, a three judge bench of this Court was constituted. This
bench considered the matter on 13" February 2002 and in a judgment

| reported in (2004) 1 SCC 243 it held that “the state can levy excise duty
only on potable liquor fit for human consumption and as rectified spirit

Page 2 of 3
° c

<!-- page 4 -->

ah
ar
| all eel
does not fall under that category the State Legislature cannot impose
any excise duty”.
| 6. Lastly, in State of Bihar v. Industrial Corporation, (2003) 11 SCC 465,
i the Supreme Court, while dealing with the question of the power of the
| State to levy a penalty for loss or wastage of molasses, rejected the
| argument of the State that molasses were diverted towards
| manufacturing liquor which is fit for human consumption and held that
‘no penal duty could have been imposed on rectified spirit’, At Para 23
j of the judgment, the Court, after referring to Bihar Distillery (supra)
has held:
| 24,How far and to what extent the said .
| observations are correct need not be considered
i | by us but suffice it to point out that this decision
; | had not noticed the earlier decision given by a
Bench of three learned Judges in Modi Distillery
i . Modi Distillery applies on all fours to the facts of
H ! the present case and we are bound thereby...
q | ENA typically contains 95% alcohol by volume and as such, is not fit
5 | for human consumption. Under Article 246A (1) read with 366(12A), GST
4 cannot be levied on the ‘supply’ of ‘alcoholic liquor for human consumption.’
| ENA that is used for the manufacture of alcoholic liquor is not supply for the
| purpose of human consumption as it is not consumed directly, but goes
through a process of manufacture.
| For the reasons mentioned above, I am of the opinion that the judgment
© 4 | — of the Court in Bihar Distillery does not denude the Centre or the States of the
°
ra ww ra power to levy GST on ENA that is used to manufacture ‘alcoholic liquor for
¢ ow’ | human consumption’,
oo ”
¥
. wy i I advise accordingly.
a ad
oF Ny Yours sincerely,
yr
(KK. Veungopa)
H Dr. R. J. R. Kasibhatla,
Deputy Legal Adviser,
‘Department of Legal Affairs,
| Ministry of Law & Justice,
i Shastri Bhawan,
| New Delhi - 110001.
| Page 3 of 3
