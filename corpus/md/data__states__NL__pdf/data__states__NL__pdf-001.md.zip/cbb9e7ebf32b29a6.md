---
doc_id: "cbb9e7ebf32b29a6"
source_url: "https://mvdnagaland.in/download/4/notifications/940/circular-for-mts-recruitment-under-motor-vehicles-department.pdf"
ministry: "Motor Vehicles Department, Nagaland"
title: "Circular for MTS recruitment under Motor Vehicles Department"
date: ""
pages: 8
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "a00e39d2b3208bad"
---

<!-- page 1 -->

GOVERNMENT OF NAGALAND
MOTOR VEHICLES DEPARTMENT
OFFICE OF THE TRANSPORT COMMISSIONER
NAGALAND: KOHIMA-797004
e-mail: commrtrans-ngl@nic.in
CIRCULAR
Date: 27'" May, 2025
NO.TC-ESTT-DRB/367/2025: In pursuance of this Department’s Advertisement of
even number dated 13.05.2025, and on scrutiny by the DRB Screening Committee, the
following applicants are shortlisted for the interview on 30" May, 2025 for filling up
the 4 (four) vacancy post of MTS (Group-D) under Motor Vehicles Department,
Nagaland.
Board Place _
Transport Commissionerate,
Motor Vehicles Department,
Nagaland, New Secretariat
Area, Opposite Phizo’s Hill,
Kohima
Shortlisted candidates are required to report for the interview 30 minutes prior
to the scheduled time, bringing the following documents in original. Failure to comply
may result in disqualification:
a) Educational qualification certificates.
b) Birth Certificate.
c) Indigenous Inhabitant and Schedule Tribe Certificate.
d) For Persons with Benchmark Disabilities (PwDs), a certificate from
competent Medical Authority.
Please find attached the list of shortlisted and rejected candidates.
Sd/-
(ELIAS T. LOTHA)
Transport Commissioner
&
Chairman, DRB
NO.TC-ESTT-DRB/367/2025/{ £& 6-60 Date: 27" May, 2025
Copy to:
1, The Commissioner & Secretary to the Government of Nagaland, Transport
Department, Nagaland, Kohima, for kind information, please.
2. The Regional Transport Officer, Mokokchung, for circulation, please.
3. The District Transport Officer, Wokha, for circulation, please.
4. The District Transport Officer, Phek, for circulation, please.
5. IT Cell, for uploading in the Department website, please.
aA Cc
WAL al
(KENE O CLARA)
Addl. Transport Commissioner
Z:ESTT/recruitment/DRB/nterviewMTS Member Secretary, DRB

<!-- page 2 -->

| espn Com GOVERNMENT OF NAGALAND

Ly Ve MOTOR VEHICLES DEPARTMENT
3 ‘ @ OFFICE OF THE TRANSPORT COMMISSIONER
(3 * “| NAGALAND: KOHIMA-797004
aXe) (5 e-mail: commrtrans-ngl@nic.in

Naan ae

RTO, Mokokechung:

SI. Code No. Name Code No.
L_1_[MkGooI MKGO34
MKG006

6 __| MKG008 | Opangnenba
Kikumsungba
[8 | MKGO010 | Wangshitu Ozukum fee Moatemsu
| 9 | MKGOI1 | Imlisunep |-38 | MKG042 | Imsulemba
Moasujung Jamir 39 | MKG043 | Imlinungchet
| 11 | MKGO013 | Temjensola Jamir
Moatemsu Kechu
Moatoshi M. Jamir

15 MKG048
| 16 | MKG019 | Lanusangba N. Tamir
Limasunep MKGO50
| 18 | MKGO021 | Akumnungsang Longkumer_[ 47 | MKGOSI_| Putilong
| 19 | MKG023 | Nungshiwapang Longkumer | 48 | MKG052 | Imolemla
Ongru Pongen
|_25__|MKG029 | Tsuknungtemsu Longkumer | 54 |TCO17 | Watisongla =
P.Nengisatsung Aier | _58_| TC030[ Temsukaba
Lanusungkum Kichu | 56_|TC036 | imtinungsang ————i
ee
a

Aas

<!-- page 3 -->

J Kees 0 Com GOVERNMENT OF NAGALAND
iS, : by MOTOR VEHICLES DEPARTMENT.
Ss as % OFFICE OF THE TRANSPORT COMMISSIONER

FA ray * NAGALAND: KOHIMA-797004
~ KS e-mail: commrtrans-ngl@nic.in

Seqziand as

= Shortlisted Candidates for Interview

DTO, Wokha:

No. | No. No.
Nzanrhoni E, Yanthan WKA041_| Thungchamo Humtsoe
Mhathung Tsenthungo S. Kikon
M. Shanbenthung Humtsoe Nchumbemo M., Ezung
WKA04 Meribemo A. Patton
Yanpenthung K. Shitiri 98 Shanthungo Murry

62 Robin Odyuo 99 | WKAOSI |RenbenJami
Chumben Ovung 100 oe Chenibemo Ngullie
N. Zulanthung Kikon
Tumchobemo Kithan
Bideno Shir
|_68 | WKAOI2 | R. Mhalo Ngullie
R. Lithungo Ngullie
Lichanbeni Patton
Mhachamo Fernando 0. Yanthan
Zuthungbemo F. Tsanglao
Y. Randanbemo Kikon | 110 | WKA063_| Ronbenthung T Patton |
Albert Odyuo WW
Lijanbeni M. Ngullie 112_| WKA066
76 | WKA020 | Bonthungo V. Murry — | 13
Ajamo T. Humtsoe 114 | WKA069
WKA023 WKA070
Yimtongthung Yanthan WKAO71
| 81 | WKA026 | Tumchobeni Murry WKA073
Martha Yanthan
Renbeni Yanthan WKAO7S[Nrokhon |
Lichanbemo A. Pation
A eee range —__} Rr a7e_{M Chandeno Ean
Chumdemo Patton
[89 | WKA034 | M Shanchothung | 126 | WKA08I | Shancho Tungoe
[90 | WKAO35 | Nehumbemo N. Tungoe | 127 | WKA082_| Rubenthang W Naullie
| 91 | WKAO36|LanthungoT. | 128 | WKA083_| M Longshithung Ezung _ |
WKAOS4
WKAO85

<!-- page 4 -->

GOVERNMENT OF NAGALAND

Ts Koss Snips MOTOR VEHICLES DEPARTMENT :
iy ‘6, OFFICE OF THE TRANSPORT COMMISSIONER
7 ‘§ | NAGALAND: KOHIMA-797004
5) By e-mail: commrtrans-ngl@nic.in
No eco,

:: Pgaland :
Shortlisted Candidates for Interview
DTO, Wokha:
Code No. Name SL Code No. Name
No. No
WKAOS86 Apenthung T Humtsoe
132_| WKA089_| T Renthunglo Odyuo
Rhonbenthung P Ngullic
Zuben M Kikon TC007 | N Ponathung Kithan
WKA092_| Thungbomo § Kikon TC008 | Aremo Humtsoe
WKA093_| Khochobeni Jami Zaremo W Lotha
WKAO94 Ebithung S Mum:
Merithung R Ezung
WKAI00_ | M Ronithung Odyuo Yanithung T Kikon
WKA101
145
|. 149 | WKA107_|WLothungbeni_ | 180 | TC023_ | TumbeniKithan
| 150 [WKA108 | MharenMMurry | 181 | TC024 | ElanthungRKithan |
Benthunglo Humtsoe
TL Abenthung Mu
WKAII1 Shanjothung E Shitiri
Tandemo Y Kithan 185
L157 [WANS |Merichan OFoka ——[ |
[138 WKATIG | Nehumbemo MHumisee [|_|]
Chulan Murr SSeS =
| 160 | TC001 Chumbeni R Jami aa [
i

<!-- page 5 -->

fs Sens GOVERNMENT OF NAGALAND
yy 6, MOTOR VEHICLES DEPARTMENT
5 84 OFFICE OF THE TRANSPORT COMMISSIONER
3 =} NAGALAND: KOHIMA-797004
es ‘Sa e-mail: commrtrans-ngl@nic.in

Maqaianete”

Sl emere a i : ie

Shortlisted Candidates for Interview

DTO, Phek:

Sl. | Code No. Name Sl. | Code No. Name
No No
PHKOOL | Menelou Akami PHKOI7
PHK002_ | Nuphi Nakro PHKOI8 | Lhitsho-U Mero
| 190 | PIIK003 | Khobuzo Venuh 205 | PHKO19 | Nukhozo Chizoh
| 191 | PHK004 | Savohu Tetseo 206 | PHKO20
PLKOOS PFEROOT_| Revo Toshi
PHK007 | Swuyevezo Chizo PHK024 | Wehicho U
PHKOO8 | Kukhavi Nusory PHKO25_ | Chepewe-U
PHK009 | Muluvoyi Chizo PHK026_ | Sarhunyi Movi
PHKO10 PHK027_ | Muchekhoto Lohe
PHKO11 | Khrukulu Rhakho PHK028 | Mesungulo Khutso

Aa

<!-- page 6 -->

GOVERNMENT OF NAGALAND
a, MOTOR VEHICLES DEPARTMENT
FAD Lng. OFFICE OF THE TRANSPORT COMMISSIONER
y : Cr NAGALAND: KOHIMA-797004
8 3 e-mail: commrtrans-ngl@nic.in
X |
*
%, oe’
“20aiand 3
ae Rejected List
RTO, Mokokchung:
Name [Remarks |
Ze MKG007 i. No name on the
application form
2 MKG022 | Wapongnungsang i. Overage as on 01.01.2025
3 MKG053 | Nungsangchuba i. Overage as on 01.01.2025
MKG054 | Bendangakum Jamir i. Certificate of Indigenous
Inhabitant not enclosed
Abs

<!-- page 7 -->

: GOVERNMENT OF NAGALAND
MOTOR VEHICLES DEPARTMENT
Peete se OFFICE OF THE TRANSPORT COMMISSIONER
PAPO Co, NAGALAND: KOHIMA-797004
SS va ¢-mail: commrtrans-ng]@nic.in
* (Fi
Serra “SY Rejected List
DTO, Wokha:
WKAO22_ | Chumbenthung Tungoe i. Overage as on 01.01.2025
WKAO037_| Tumchopemo Humtsoe i. Certificate of Indigenous
Inhabitant not enclosed.
Echanthung Ezung i. Overage as on 01.01.2025
Pees Sething Sangtam i. Indigenous Inhabitant of
Seyochung Village, Kiphire
eee reese Chumthungo N. Ngullie i Certificate of Indigenous
Inhabitant not enclosed.
10 WKA046_ | N. Thunglamo Ngullie i, Overage as on 01.01.2025
pee ii. Certificate of Indigenous
Inhabitant not enclosed.

11 WKA047_ | Tumben N. Kikon i. Certificate of Indigenous
Inhabitant not enclosed.

12 WKA049_ | Shanchothung W. Murry
Inhabitant not enclosed.
Inhabitant not enclosed.

14 WKAO064 | N. Chumbenthung Ezung i. No documents enclosed to
Birth.(wrong birth
certificate enclosed)

15 | WKA067 | ZaremoYanthan

ee documents not enclosed.

17 WKAO088 | Mhao Kikon i, Educational qualification

eee ee documents not enclosed.

18 WKAI105_| Aben V. Shito i. Certificate of Indigenous

| Inhabitant not enclosed.

TC032 | Nzanthung C. Ngullie
ee eee eee Inhabitant not enclosed.
Ask

<!-- page 8 -->

GOVERNMENT OF NAGALAND.
pero MOTOR VEHICLES DEPARTMENT
ort Co™
ge Ln, OFFICE OF THE TRANSPORT COMMISSIONER
S . v5 NAGALAND: KOHIMA-797004
3 ¢ & e-mail: commrtrans-ng]@nic.in
to) +}
A oy
1a
Rejected List
DTO, Phek: i
SL. NO.
20 PHKO012 | Tiiso Keyho i. DoB mismatch in
7 documents
21 PHK022 | Zuthosheyi Lohe i. DoB mismatch in
documents
Bis
