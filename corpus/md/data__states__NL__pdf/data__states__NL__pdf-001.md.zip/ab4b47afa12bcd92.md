---
doc_id: "ab4b47afa12bcd92"
source_url: "https://dte.nagaland.gov.in/wp-content/uploads/2026/06/Notification-under-the-purview-of-NEET-2026.pdf"
ministry: "Directorate of Technical Education, Nagaland"
title: "Click here to VIEW/DOWNLOAD"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "860e0a1b687f4697"
---

<!-- page 1 -->

y UNITY a
(cm GOVERNMENT OF NAGALAND i)
| “= Bi

4 5m) DIRECTORATE OF TECHNICAL EDUCATION
ey ox Ce Nagaland : Kohima - 797 004 Tech"Edu
Dt. Kohima, the" June, ‘2026.
NOTIFICATION

NO.DTE/ESTT-2/NEET/02/2026/ This is to notify the NEET (UG)-2026 appeared

candidates intending to avail Nagaland State Reserved seats for MBBS/BDS/BVSC&AH/

BAMS/BHMS/BASLP/BUMS/BPT/BOT under the purview of NEET (UG) 2026, that

registration forms will be available at the Directorate of Technical Education, Kohima (Below

New Secretariat Complex) on payment of Rs. 500/- only w.e.f. 22" June, 2026 during office

working hours. The form may also be downloaded from the official website of the Department

https://dte.nagaland.gov.in in which case the fee should be submitted in cash along with the

form printed in white paper (A4 size) by hand.

The last date of submission of filled form alongwith all necessary documents to
this office shall be on or before 17" July, 2026. Additionally, the Score Card must be
submitted within 7 (seven) days of the NEET (UG), 2026 result declaration. No
applications shall be entertained after these deadlines.

Note: Candidates are informed to read all necessary instructions given in the application form
carefully before the form is submitted.
(ER. VIPULHOU LHOUNGU)
Director
NO.DTE/ESTT-2/NEET/02/2026/ /75 Dt. Kohima, the/£ " June, ‘2026
Copy to:-

1. The Sr. P.A. to Hon’ble Advisor for Transport and Technical Education, Kohima

for kind information of Hon’ble Advisor.

2. The Secretary to the Govt. of Nagaland, Dept. of Higher & Technical Education for

information.

3< The Director, Department of Information & Public Relation, Nagaland, Kohima

with a request to make arrangement for publication of the above Notification in the
local Newspapers.

4. The Website incharge for necessary action.

5. Notice Board for information.

6. Office copy.

| xt Uy
. (ER. VIPULHOT QUNGU)
Directg
© i dir.techedu-ngl@nic.in /tenagaland@gmail.com €& 0370-2270409/2271432 & https://dte.nagaland.gov.in
