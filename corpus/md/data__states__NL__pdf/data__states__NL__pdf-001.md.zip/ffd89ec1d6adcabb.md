---
doc_id: "ffd89ec1d6adcabb"
source_url: "https://highereducation.nagaland.gov.in/wp-content/uploads/2017/07/guidelines.pdf"
ministry: "Higher Education Department, Nagaland"
title: "Guidelines"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9cdc2c2750767aae"
---

<!-- page 1 -->

GOVERNMENT OF NAGALAND
DIRECTORATE OF HIGHER EDUCATION
NAGALAND: KOHIMA

ANNEXURE-1
Nagaland Government Ex-Gratia Scheme for Students Studying Outside Nagaland (NGESSO)
Sponsored by the State Government of Nagaland
GUIDELINES AND MODALITIES
A. Eligibility Criteria:
The Scheme shall be eligible for:
1. Students belonging to any recognised Scheduled Tribes /Indigenous inhabitants of Nagaland State
only.
2. Students who are admitted to regular course with a minimum duration of 1 year course in any
recognised institutions outside the State of Nagaland but within India only.
3. Students pursuing studies from primary level till Post Doctoral Courses.
4. Students who are pursuing studies in Secular /Technical /Professional / Diploma/Theology/ course
etc.
5. Students who have registered their names and details under the Office of the Directorate of Higher
Education, Government of Nagaland: Kohima.
6. Students who have nominated the name and details of their nominee for claims of the Ex-Gratia
Scheme during registration.
7. Student whose death has occurred outside Nagaland.
8. Students residing in Nagaland and pursuing correspondence / distance education courses outside
the State are not eligible.
B. Coverage: Death cases only.
C. Amount: `5,00,000/-(Rupees five lakh)only.
D. Terms and conditions to claim the Nagaland Government Ex-Gratia Scheme for students
studying outside Nagaland:
1. The Nominee can claim the Ex-Gratia amount within a period of 2 (two) months after the death
of the students by furnishing the following documents :
i.

Nominee of the deceased student should submit an application to the Director, Directorate
of Higher Education, Government of Nagaland Kohima mentioning about the name of the
deceased student/date of death /cause of death/place of death.

<!-- page 2 -->

ii.

Certificate issued by Police Officer from the nearest Police Station where the student died.

iii.

Certificate issued by the principals/HOD’s of Institutions where the student was studying.

iv.

The Nominee shall furnish the Registration ID Number of the deceased student, generated
by the Directorate of Higher Education.

v.

The Nominee shall submit his/her Bank Account Number/Name and Address of the
Bank/IFSC of the bank supported by a photo copy of the front page of the bank Pass Book.

vi.

The Nominee shall sign an undertaking prepared by the Directorate of Higher Education.

E. Registration of students:
Students studying outside Nagaland will be allowed to register their names by applying through the
forms issued by the Office of the Directorate of Higher Education, Nagalanguid Kohima.
Registration
forms
can
be
downloaded
from
the
department
website
(www.highereducation.nagaland.gov.in). Registration forms are to be submitted within the
stipulated time period.
On successful verification of forms and documents, the Department shall assign Registration
number to each applicant, the list of which will be uploaded on the Department’s website.
F. Renewal of Registration:
It shall be mandatory for all the registered students to renew their registration manually every
academic year (annually).
G. Documents Required to be submitted with Registration Form:
i.

1(one) recent passport size photo of the Student.

ii.

1 (one) recent passport size photo of the Nominee.

iii.

Photo copy of Student’s Identity Card

iv.

Photo copy of Admission Receipt of the student

v.

Photo copy of ST & Indigenous Certificate of the student

vi.

Specimen signature of the Nominee

vii.

Photo copy of the Front Page of Bank Pass Book of the Nominee

Sd/Director
Directorate of Higher Education
Nagaland, Kohima
