---
doc_id: "4d744a5c4fbf0eec"
source_url: "https://highereducation.nagaland.gov.in/wp-content/uploads/2026/08/Azim-Premji-notification.pdf"
ministry: "Higher Education Department, Nagaland"
title: "Azim Premji Scholarship 2026"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "97cca1f3c98a78b4"
---

<!-- page 1 -->

GOVERNMENT OF NAGALAND
DIRECTORATE OF HIGHER EDUCATION
NAGALAND: KOHIMA.
NO.HED/SCHO/NSNC/40/2025/87
Dated Kohima, the 20th August 2026
AZIM PREMJI SCHOLARSHIP 2026
(For Girl Students only)

The Azim Premji Foundation invites applications for the Azim Premji Scholarship 2026 to
support girl students in higher education. The Scholarship provides financial support up to ₹1.5
lakhs (₹30,000 annually) till completion of undergraduate programme (2–5 years).
Eligibility:
• Passed Class 10 & 12 as a regular student from a government school/college in eligible
States/UTs.
• Admitted in first year (2026–27) of a recognized undergraduate degree/diploma course.
Further information and online application available at: https://azimpremjifoundation.org
Last date of online application (Round 1): 31st August 2026
Note: Scanned documents for the upload should be clear, coloured, unedited/unfiltered copy
of the originals.
Issued in public interest by:
Nagaland Scholarship Nodal Cell
Directorate of Higher Education,
Nagaland: Kohima
