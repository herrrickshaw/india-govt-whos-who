---
doc_id: "78efca0aa7afc377"
source_url: "https://home.nagaland.gov.in/wp-content/uploads/2025/09/Order-RIIN-1_merged.pdf"
ministry: "Home Department, Nagaland"
title: "Order-RIIN-1_merged"
date: ""
pages: 3
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "d6804e43e412850f"
---

<!-- page 1 -->

GOVERNMENT OF NAGALAND
HOME DEPARTMENT: POLITICAL BRANCH
ORDER
Dated: Kohima the 20 Sept. 2024

NO:CON/RIIN/50/2020 il Whereas in pursuance of Cabinet decision

Vide: No:CAB-1/14/2023/ Dated: 12/09/2024, with regard to eligibility criteria of being

an Indigenous Inhabitant of the State of Nagaland and issuance of Indigenous

Inhabitant Certificate, an Enumeration Exercise is to be conducted of the people and

their direct descendants from Garo, Kuki, Kachari and Mikir (Karbi) settled in the State

of Nagaland prior to 18‘ December, 1963 so as to determine their eligibility for issuance
of IIC/PRC. The enumeration of Nepali/Gorkhas who are permanently settled in

Nagaland prior to 31st December 1940 and their direct descendants will also be

conducted simultaneously.

2. The Enumeration shall be conducted by the concerned Deputy Commissioners at the
village/town level and may be done in the proforma prescribed at Annexure — |
(enclosed). The Enumeration Sheet being forwarded for draft publication must be
countersigned by the following authorities, viz:

i. Village Council Chairman/ Town Council Chairman/Municipal Council
f Chairman, as applicable. ‘
| ii. |The Concerned Village GB.
: ii. | The Area Administrative Officer (EAC/ SDO(C) / ADC)
iv. The Chairman/ President/ Representative of the Garo, Kachari, Kuki, Mikir
(Karbi), Nepali/Gorkhas as applicable.
v. The Deputy Commissioner of the District.

3. The Copies of all the Final Enumeration Sheets shall be submitted to the Home
Department through the Commissioner, Nagaland, which shall be placed before the
Cabinet for decision.

4. The modalities for the process of Enumeration may be worked out by the
Commissioner, Nagaland.

5. The Schedule for the Enumeration Exercise is listed as below:

SCHEDULE
[siNo[ _——Cctivity Date
. Supervisors & Enumerators 2024
. . 015t Nov. 2024 to 31%
2025
W.
— ————— —T — = a —_ a

<!-- page 2 -->

F, SCHEDULE
‘ | SINo | Activity Date
jth . 2025 to 21 April
6. Disposal of claims and objection ever eoeae De
2025
Final publication of the list of et” May 2025
Enumeration
Sd/-
DR. J.ALAM, IAS
Chief Secretary, Nagaland
NO: CON/RIIN/50/2020// Dated: Kohima the 20" Sept. 2024
Copy to :
1. The Commissioner & Secretary to the Hon'ble Governor of Nagaland, Raj
Bhavan, Nagaland, Kohima.
2. The Principal Secretary to the Hon’ble Chief Minister, Nagaland, Kohima.
3. The Sr.PS to the Hon’ble Deputy Chief Minister (Home & Border Affairs),
Nagaland, Kohima.
4. The Sr.PS to the Hon’ble Deputy Chief Minister (NH & Planning and
: Transformation), Nagaland, Kohima.
5. The Commissioner, Nagaland, Kohima.
* 6. The Director General of Police, Nagaland, Kohima. *
7. The Advocate General, Nagaland, Kohima.
8. The Principal Secretary, P & AR Dept. Nagaland, Kohima.
9. The Commissioner & Secretary, Law & Justice Dept. Nagaland, Kohima
10. All Deputy Commissioner, Nagaland.
11. The Commissioner of Police, Dimapur, Nagaland.
12. All Superintendents of Police, Nagaland.
43. The / President/Chairman, Garo/Kachari/Kuki Inpi/ Mikir (Karbi) and
NePali/Gorkhas, Nagaland.
14. Office Copy.
We
VYASAN R.
Home Commissioner, Nagaland

<!-- page 3 -->

ANNEXURE -1 |
‘fd ENUMERATION FORMAT
District. % Tribe/Community.
3 2 § — co] ° , oS, oS, - a BS
fe 3s N nN o 7 a
==B Electoral Roll of oO g c Q c @ c 2 c g =
52s 05/12/1963 9 on Eon 5 Sa |§ g=/§ zis |
= te) 3S 3 3 c/s ras
B25 2 |-£ |8/.£ 1/8 |.£1/8 | £18 3/8
35a & g3 = |e le |e2 le |#3/e als _
= G 59 2 So = S90 2 so|/2 4 8
obs Zz 20 S).| FO. | 5 BO |3 20 |S “lhe, ror RE 2 o
BBL 6 fey o 3 2/.,s |2 5 | 2 s|/2{/a/ée 1/8 jo | E s
58-8 2G Ds op Go |S 1% oy 1G S6o/G§ | la |e | Q)\a 3
,| 2282) 5/22 ae g 5 g/§ S/§ £/s5/2|]5 /a 1/5/35 |e ;
= 5 g 3 & £/)83 be £
2/2238 /2 | $2 x |/2e |285 |B |2e |B | 28 |B [28/8 |B le |B l2/8 12 |2
a /28a8la | 28s & |fia |28 2/28 |2 |28 (2 |S8/2/2 |S |S if }ae fe a
in aR OE 2H LS FSA ee RE CSA El ODL WAGE | 32
PTE La) [eae] ne aa fh]
Ce aN NI Fa (A ER (F(t Pea (me) TN (ae (OY 1 | A 7S
[Sn Ge ce Sa CR TR “A a Os
a ae Cl Re SC ae) SEES SON! RE ORS | EE ii ha eae
|} +_ 1+} | +} | ++ |, + + + + +H
ee a aa HAR | Nl [nae TGP NE EM (EPR AR (TNE ARAN (SA) (TN PR A
RR RR a [I (| [A Te RR FF (PS a (Da (TT
a a RA [eae A (ART RRA FRE Se SOM (A (a feed (| | | mn es
ESE EE (ca Le (Oe He (mC Wa A 7 (ene PRG EP
Fea cae am oY em [Pa a RR | ea ge IR ||
AN ie a ea NPL a ee [el Alfie JS S e  e| SE | em | [Ee Gk” |)
\ The above family list is true and correct to the best of my knowledge and belief
Head of family
NAM. cccccssesssseessseesssseeseccsseesssecsesesssescseeeasersess |
Signature: |
