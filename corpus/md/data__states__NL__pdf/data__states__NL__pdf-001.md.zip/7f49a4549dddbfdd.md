---
doc_id: "7f49a4549dddbfdd"
source_url: "https://mvdnagaland.in/download/4/notifications/924/eio-for-engagement-of-companies-or-firms-for-supply-of-smart-card-printers.pdf"
ministry: "Motor Vehicles Department, Nagaland"
title: "EIO for Engagement of Companies or Firms for Supply of Smart Card Printers"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "63b33d2c6781ed0a"
---

<!-- page 1 -->

Expression of Interest (EOI) for Empanelment of Companies/Firms for Supply
of Smart Card Printers:
Motor Vehicles Department, Government of Nagaland
The Motor Vehicles Department invites Expression of Interest (EOI) from eligible companies/firms
for the empanelment to supply smart card printers of the models Fargo HDP5000 and Fargo
DCT1000 to the department.
This empanelment aims to ensure a seamless and standardized supply of smart card printers
meeting the required technical and quality standards.
Eligibility Criteria
Interested companies/firms must meet the following criteria to participate in the empanelment
process:
1. Registration: The companies/firm should be a registered company in India under the
Companies Act, 1956/2013. A valid certificate of incorporation must be submitted.
2. Financial Documents: The companies/firm must provide:


Audited balance sheets for the last three financial years.



Income tax returns for the last three assessment years.

3. PAN and GST Registration:


The companies/firm must have a valid Permanent Account Number (PAN).



The companies/firm must have a valid Goods and Services Tax (GST) registration
number.

4. Price Quotation:


The companies/firm must provide the Maximum Retail Price (MRP) of the
hardware, specifying all applicable taxes.



The quoted prices should remain valid for at least 12 months from the date of
submission.

5. The companies/firm must provide Manufacturer’s Authorization Form (MAF) from the
manufacturer.

Scope of Work
The empanelled companies/firms will be responsible for:
1. Supplying the smart card printers "Fargo HDP5000" and "Fargo DCT1000" as per the
department’s requirement.
2. Ensuring the hardware meets all required quality and technical standards.
3. Providing warranty and after-sales support for the supplied hardware.

<!-- page 2 -->

Submission of EOI
Interested parties are requested to submit their EOI, along with all necessary supporting documents,
in a sealed envelope clearly marked as:
"Expression of Interest for Empanelment for Supply of Smart Card Printers"
The EOI should be addressed to:
Transport Commissioner,
Motor Vehicles Department,
Government of Nagaland

Documents Required
The EOI must include:
1. Company/Firm profile, including certificate of incorporation.
2. Audited balance sheets for the last three financial years.
3. Copies of income tax returns for the last three years.
4. Copies of PAN and GST registration certificates.
5. MRP quotation of the hardware, specifying all applicable taxes and validity.
6. Any other relevant documents supporting the eligibility.
7. Manufacturer’s Authorization Form (MAF)
Evaluation and Empanelment
The department will evaluate the EOIs based on the eligibility criteria and documents submitted.
Only manufacturers/firms meeting the criteria will be empanelled.
The empanelled manufacturers/firms will be notified accordingly and invited for further
communication as required.
Contact for Clarifications
For any clarifications or additional information, please contact:
Contact Person’s Name:
Designation:
Phone Number:
Email Address: commrtrans-ngl@nic.in
The Motor Vehicles Department reserves the right to accept or reject any EOI without assigning any
reason and shall not be liable for any costs incurred by the applicants during the process.

Authorized Signatory
Transport Commissioner
Department of Motor Vehicles
Government of Nagaland
Z: Acctts/Core Activities/EOI
