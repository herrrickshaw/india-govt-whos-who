---
doc_id: "36dfa8dc8efc4af7"
source_url: "https://dte.nagaland.gov.in/wp-content/uploads/2026/06/Notification-for-Medical-courses-non-NEET-2026.pdf"
ministry: "Directorate of Technical Education, Nagaland"
title: "Click here to VIEW/DOWNLOAD"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "b96d0cca0e7a1157"
---

<!-- page 1 -->

UNITY NQ ; wv
(cm) GOVERNMENT OF NAGALAND
—o \ ey
| uy i] a 5
Bel) DIRECTORATE OF TECHNICAL EDUCATION 2
, Sa” Nagaland : Kohima - 797 004 Tech Edu
. Dt. Kohima, the "June, ‘2026.
. NOTIFICATION
NO.DTE/ESTT-2/NEET/02/2026/ This is to notify the class-XII passed out candidates
intending to avail Nagaland State Reserved seats for MRIT/MLT/MLS/OOT/NUTRITION &
DIETETICS not under the purview of NEET, that registration forms will be available at the
Directorate of Technical Education, Kohima (Below New Secretariat Complex) on payment of
Rs. 500/- only w.e.f. 22"! June, 2026 during office working hours. The form may also be
downloaded from the official website of the Department https://dte.nagaland.gov.in in which
case the fee should be submitted in cash along with the form printed in white paper (A4 size)
by hand.
The last date of submission of filled form along with all necessary documents to
this office shall be on or before 17" July , 2026. No applications shall be entertained after
these deadlines.
Note: Candidates are informed to read all necessary instructions given in the application form
carefully before the form is submitted
(ER. VIPULHOU LHOUNGU)
Director
NO.DTE/ESTT-2/NEET/02/2026/ 14 € Dt. Kohima, the /é"" June, ‘2026
Copy to:-
1. The Sr. P.A. to Hon’ble Advisor for Transport and Technical Education,
Kohima for kind information of Hon’ble Advisor.
2. The Secretary to the Govt. of Nagaland, Dept. of Higher & Technical Education
for information.
3. The Director, Department of Information & Public Relation, Nagaland, Kohima
with a request to make arrangement for publication of the above Notification in
e local Newspapers.
. The Website incharge for necessary action.
5. Notice Board for information.
6. Office copy.
\
(ER. VIPGLHOU LH GU)
- -Direotor
© dir. techedu-ngl@nic.in /tenagaland@gmail.com € 0370-2270409/2271432 3 https://dte.nagaland.gov.in
