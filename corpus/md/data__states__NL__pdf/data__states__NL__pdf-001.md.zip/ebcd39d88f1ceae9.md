---
doc_id: "ebcd39d88f1ceae9"
source_url: "https://cdn.s3waas.gov.in/s37f5d04d189dfb634e6a85bb9d9adf21e/uploads/2025/07/17531657091897.pdf"
ministry: "Wokha"
title: "Revised Notice for Inviting Tender- AI Chatbot Development- DC Wokha"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "730d3ecd7bd5327d"
---

<!-- page 1 -->

GOVERNMENTO FNAGALAND
OFFICE OF THE DEPUTY COMMISSIONER
WOKHA: NAGALAND
de.wokha@gmail.com; dcwok-ngl@gov .in
Dated. Wokha the 11 th July 2025
No. DCW/DEV-225/Project Saathl/2021/0J-<Jt .-j

REVISED NOTICE INVITING TENDER

The Office of the Deputy Commissioner, Wokha, Government of Nagaland invites sealed offline
proposals from eligible and reputed agencies/firms for:
"Selection of Agency for Design, Development and Deployment of Al-Powered Virtual
Assistant Over Multiple Channels to Act as Single Point Hub for Delivery of Government
Services and Schemes at District Level (With AMC of 12 Months)"

The proposed solution is to be hosted across multiple communication platforms, including
WhatsApp, Web, Facebook, lnstagram, and SMS.
This initiative is part of the district's digital transformation agenda to create a citizen-centric, Alenabled service delivery ecosystem.
Key Dates:
Tender Publishing Date

14/07/2025

Start Date for Submission of Proposal 14/07/2025
(Offline)
Last Date for Submission of Proposal

31/07/2025

Date of Opening of Financial Proposal

To be intimated later to technically qualified
bidders

Interested agencies may refer to the complete Request for Proposal (RFP) document for
eligibility criteria, evaluation methodology, scope of work, technical specifications, deliverables,
timelines, and terms & conditions. The RFP can be downloaded from the official district website
at https://wokha.nic.in under the Tenders section.

Encl: REVISED REQUEST FOR PROPOSAL

:\'{ COM-'f1s.£

~~, -'o~

~

\0

:?:

~

~~

MAR) IAS
(VINE
Commissioner
Dep
Wokha: Nagaland
.- ~"t--~~
-~-tr;
. I.
th
No. DCW/DEV-225/Project Saathi/2023/0 iof--j ••, ..,~~-~· Dated. Wokha the 11 July 2025
Copy to: 1. The D1O, NIC, Wokha - for uploading on the official district website.
2. The DPRO, Wokha - for wide publicity through media.
3. Office copy.

, ' ,

S.

;>"

f/

<!-- page 2 -->

LJNITy

1~NTO'r

GOVERNMENTOFNAGALAND
OFFICE OF THE DEPUTY COMMISSIONER
WOKHA: NAGALAND

REVISED REQUEST FOR PROPOSAL (RFP)

For
Selection of Agency for Design, Development and Deployment of Al
Powered Virtual Assistant Over Multiple Channels to Act as Single
Point Hub for Delivery of Government Services and Schemes at
District Level
(With AMC of 12 Months)

Tender Ref. No.

No. DCW/DEV-226/PROJECT SAATHl/2023

Issued by

Office of the Deputy Commissioner, Wokha
Near India Post, Wokha, Nagaland- 797111

I Mobile: +91-8880689346
I
1

E-mail: dcwok-ngl@gov.in

I

Web: https://wokha.nic.in

July 2025

<!-- page 3 -->

REVISED REQUEST FOR PROPOSAL (RFP)
For Selection of Agency for Design, Development, and Deployment of AlPowered Virtual Assistant Over Multiple Channels
(With AMC of 12 Months)
The Office of the Deputy Commissioner, Wokha, Nagaland invites sealed offline
proposals from experienced and eligible agencies for the development and
deployment of an Al-powered virtual assistant system integrated with Generative
Al capabilities, deployed across platforms like WhatsApp, Web, Facebook,
lnstagram, and SMS. The solution will act as a single-point digital hub for
dissemination of government schemes, delivery of citizen services, and grievance
redressal.

IMPORTANT INFORMATION

i Tender Notice No. -

-

~

--

-

] No~D~W/?EV-~25/~~OJECT ~AATHl/2023

'.Organization Name

I District Administration, Wokha

! Tender Inviting Authority

I Office of the Deputy Commissioner, Wokha

_ _ _
Project Duration

Near India Post, Wokha, Nagaland- 797111
Mobile: +91-8880689346
, E-mail: dcwok-ngl@gov.in
I Web: https://wokha.nic.in _
__ __ ___ _ __
7
3
Month
Development
+
12
Month
AMC
1

'

[ Tender Type
- ___
Tender Fee

_ _

-- -

I

Schedule of Tender -

I
I
I

l

I
l Bid Validity -- - - -

1-0pen Offline
-----~o be submitted in Qerson or via courier/east) _ _ _
, NA

- -j I

Event
Tender Publishing Date
I Start Date for
Submission of Proposal
1
l (_Offline)
1
Last Date for
1
Submission of Proposal
1
1 Date for Opening of
j Financial Proposal

1

Date & Time
14/07/2025
' 14/07/2025

I

l

J

L31/07/2025
__ -·
I

To be intimated later to
, technically qualified
1
bidders
1 180 Days from the date of bid submission
I

I

, Availability
Document

of

'

Tender I The revised RFP can be downloaded from the official I
district website https://wokha.nic.in under the Tenders ,
1
•
I
section.
1

---·

.,,..

,.

le

..

~

'

'

\ '
4

.1,

'

---

- . : \'AGAl>~ 1/

....____ . ·"'

<!-- page 4 -->

TERMS & CONDITIONS

With reference to the Revised Notice Inviting Tender No. DCW/DEV-225/Project
Saathl/2023 Dated Wokha the 11 th July 2025, issued by the Office of the Deputy
Commissioner, Wokha, the following terms and conditions shall be applicable:
1. Bidders/Developers are invited for submission of bids/quotations against each
item in a sealed envelope with clear mention of bidder details.
2. Bids from eligible and technically qualified firms/agencies must be
complete in all respects.
3. Completed bids shall reach the Office of the Deputy Commissioner, Wokha,
on or before 4:00 PM on 31 st July 2025.
4. Late bids, for any reason whatsoever, shall not be accepted under any
circumstances.
5. Prices must be quoted component-wise. Any escalation in prices postsubmission of bids will not be entertained under any condition.
6. The Office of the Deputy Commissioner, Wokha, reserves the right to amend
the tender or reject any or all bids without assigning any reason thereof.
7. Training and handholding support for successful implementation, content
updating, and maintenance of the Al-powered chatbot across all platforms
(WhatsApp, Web, Facebook, lnstagram, SMS) shall be the responsibility of
the selected bidder.
8. The source code or relevant technical documentation, as applicable, must
be handed over to the district administration upon deployment.
9. The work order will be issued to the successful bidder and payment shall be
released in a phased manner, subject to the availability of funds and
successful achievement of implementation milestones.
1O. All technical infrastructure, data security compliance, and integration with
MeitY-empaneled cloud services must be ensured by the selected agency.

(VINE~,IAS
Deputy Commissioner
Wokha: Nagaland

Conlmissioner
J
oeputy
Wokha. Nc1ga\an"'

.

J

I

i

\

..

~

,_,...

'
,'

~-~: ~AGA\J-~.....-·
.. 4-il,. _ _

.....,

<!-- page 5 -->

Scope of Work
Project Title: Development and Deployment of an Al-Powered Virtual Assistant
Integrated with Generative Al for Multi-Channel Citizen Service Delivery
Objective:
To design, develop, and deploy a secure, scalable, and multilingual Al-powered Virtual
Assistant integrated with Generative Al (GenAI) capabilities across multiple platforms
including WhatsApp, Web, Facebook, lnstagram, and SMS. The solution will
function as a single-point digital hub to facilitate proactive dissemination of
government schemes, seamless citizen service delivery, and efficient grievance
redressal for the residents of Wokha District.

Key Components & Deliverables:
1. Virtual Assistant Development:
•

Design and build an Al-powered chatbot with multilingual support (English,
Hindi, and optionally local dialects like Lotha/Nagamese).

•

Leverage Natural Language Understanding (NLU) for contextual
understanding of user queries.

•

Enable two-way conversational flows with 24x7 self-service capabilities.

2. Generative Al Integration:
•

Integrate GenAI models to dynamically generate responses, summaries of
schemes, FAQs, and advisory content based on user prompts.

•

Build a smart knowledge base capable of answering complex citizen queries
in conversational format.

•

Enable continuous learning and improvement of the assistant via user
interactions.

3. Multi-Channel Deployment:
•

•

Deploy the assistant across the following platforms:
o

WhatsApp (via official API provider)

o

Dedicated District Web Portal

o

Facebook & lnstagram Messenger

o

SMS (for low-bandwidth and feature phone users)

Ensure synchronization of conversations and user history across channels
where feasible.

<!-- page 6 -->

•

4. Service Delivery & Scheme Dissemination:
•

Disseminate real-time information on centrally and state-sponsored
government schemes, welfare programs, and services.

•

Provide downloadable forms, eligibility details, timelines, department contact
details, and application guidance.

•

Enable digital submission of service requests, status checks, and follow-up
alerts.

5. Grievance Redressal Mechanism:
•

•

Implement a grievance intake module with:
o

Ticket generation

o

Department-wise routing

o

Escalation matrix

o

Real-time status tracking for citizens

Optionally integrate with any existing CMS/CRM system (e.g., a-District,
ZOHO, etc.) or provide a lightweight grievance management dashboard.

6. Admin Dashboard & Analytics:
•

Develop a secure backend dashboard for District Administration to:
o

View chat analytics, citizen interaction metrics

o

Configure workftows, departments, keywords, and responses

o

Generate automated reports

o

Monitor user sentiment and trends

7. Cloud Hosting & Security:
•

Host the platform on a MeitY-empanelled Cloud Infrastructure (e.g., AWS,
Azure, NIC Cloud).

•

Ensure data encryption, user privacy, and compliance with CERT-In and
GIGW guidelines.

•

Include uptime commitment (minimum 99.5% ), with regular security patches
and backups.

8. Training & Capacity Building:
•

Conduct training for nodal officers and department staff on:
o

Operating the chatbot dashboard

o

Updating content templates

<!-- page 7 -->

•

o

Handling live escalations and feedback

9. Maintenance & Support (AMC -12 months):
•

Provide post-deployment Annual Maintenance & Support (AMC) for one year,
including:
o

Regular system updates and enhancements

o

Bug fixes and platform stability support

o

24x7 technical helpline or ticketing support

o

Periodic content refresh and campaign configuration

Expected Impact:
•

Improved access to government information and services across digital
platforms.

•

Reduction in manual workload and footfall at government offices.

•

Inclusive access for digitally and geographically marginalized citizens.

•

Real-time grievance tracking and citizen feedback loop.
