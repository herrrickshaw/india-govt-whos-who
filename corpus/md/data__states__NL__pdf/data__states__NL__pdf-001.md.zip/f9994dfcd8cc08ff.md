---
doc_id: "f9994dfcd8cc08ff"
source_url: "https://dte.nagaland.gov.in/wp-content/uploads/2026/05/Diploma-outside-Notification-2026.pdf"
ministry: "Directorate of Technical Education, Nagaland"
title: "Click here to VIEW/DOWNLOAD"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "f8a26d8d582ba6f1"
---

<!-- page 1 -->

UNITY Ni by
vs GOVERNMENT OF NAGALAND Cy
A. © amen DIRECTORATE OF TECHNICAL EDUCATION
wens oF Soa Nagaland : Kohima - 797 004 Tech Edu
Dt.Kohima, the 29" May, 2026.
NOTIFICATION
NO.DTE/ESTT-2/3/2016-17/ : This is to inform the interested candidates to collect a prescribed
application form for Diploma Course given below outside .the State during 2026-27 session from the
directorate of Technical Education, Kohima (Below New Secretariat Complex) on payment of Rs.300/-
(Rupees three hundred only) with effect from 30-05-2026 to 06-06-2026 during office working hours. The
form may also be downloaded from the website https://dte.nagaland.gov.in in which case the fee should be
submitted in cash along with form printed in white paper (A4 size) by hand.
The last date for receiving the complete forms by hand is 6" June, 2026 after which no request will
be entertained. The Selection of candidate shall be purely on the basis of academic merit.
SI. | Name of Course Seats | Eligibility Institute
No
fl. | Printing Technology HSLC/Equivalent Passed Certificate | Regional Institute of
5 Ph h ; with Minimum 40% in Mathematics | Printing Technology,
3. | Audiography and Sound 1 10+2 Passed (Science 45%) (40% in | Dr Bhupen Hazarika
Engineering case of reserved category Regional Government
4. | Cinematography 1 10+2 Passed (Any Stream with 45%) Film and Television
(40% in case of reserved category Institute, Guwahati,
Assam
5. Film and Video Editing 1 10+2 Passed (Any Stream with 45%)
(40% in case of reserved category
Applied Acting (Film & TV) l 10+2 Passed (Any Stream with 45%)
(40% in case of reserved category
(Er. VIPULHOU LHOUNGU)
Director
NO.DTE/ESTT-2/3/2016-17/ ) 2H Dt.Kohima, the 29" May, 2026.
Copy to:
1. The Commissioner & Secretary to the Govt. of Nagaland, Department of Higher & Technical
Education for information
2. The Sr. P.S to thé Honb’le Advisor for Transport & Technical Education for kind information
3. The Director, Department of Information & Public Relation, agaland, Kohima, with a request to
make necessary arrangement for publication of the above Notification as advertisement in all local
Newspapers.
4. The Director, DDK/AIR, Kohima, Nagaland, with a request to include the above ‘Notification’ in
s bulletin and in all local dialect programmes for consecutive 2days.
< Website In-charge, uploading in DTE portal.
6. Notice Board, DTE
7. Office copy.
F ¢
(Er. VIPU LHOG#IGU)
Diregtor
® dir.techedu-ngl@nic.in / tenagaland@gmail.com §,  0370-2270409/2271432 Cs https://dte.nagaland.gov.in
