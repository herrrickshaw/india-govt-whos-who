---
doc_id: "d83eaa4fb6f6e77a"
source_url: "https://police.nagaland.gov.in/wp-content/uploads/2023/10/Narcotic-Drugs-Psychotropic-Substances_compressed.pdf"
ministry: "Police Department, Nagaland"
title: "ORDER"
date: ""
pages: 6
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "9f6eb9b7beeccaf4"
---

<!-- page 1 -->

— GOVERNMENT OF NAGALAND
OFFICE OF THE DIRECTOR GENERAL OF POLICE
NAGALAND : KOHIMA
NO.PHQ/IGP/CID/NAR-D/48/2023/8 10 Dated, Kohima the 1g " Oct. 2023
ORDER
It is noticed that generally. even in serious offences related to Narcotic Drugs and

Psychotropic Substances, Extortion, Arms Act and UAPA/NSR cases and all SR cases, the

accused persons tend to obtain bail without much difficulty. This hampers investigation

and delivery of justice and also dents the image of State Police and prosecution. and
adversely impacts the security situation in the State. Therefore. Commissioner of Police

Dimapur and all the Superintendents of Polices are hereby directed to ensure the following

steps are taken to prevent accused persons from obtaining bail easily.

1. The Commissioner of Police Dimapur and Superintendents of Polices shall request
the Courts that bail hearings in cases related to serious cases may not be posted
without giving sufficient time to prosecution and police to present their views in

2 There has to be regular communication with the Public Prosecutors/Assistant Public
Prosecutors and Prosecuting Inspectors to ensure information regarding bail
applications are received well in time. Unit commanders shall ensure that the
Prosecuting Inspectors and the Prosecutors are briefed properly. Any laxity on the
part of the Prosecuting Inspectors shall be dealt with firmly.

3. A strategy has to be devised to oppose bail in all important cases in coordination
with respective Public Prosecutors/Assistant Public Prosecutors. The respective
Investigating Officers guided by the Sub-Divisional Police Officer. the Addl.
Superintendent of Police and the Superintendent of Police shall_prepare_and
submit written submissions to the Court through the PP/APPs, In order to
ensure that the written submissions are presented well before the Hon’ble Court.
Investigating Officer of the case shall ensure his presence during bail hearing in all
important cases as mentioned above.

4, In those case where the Ilon*ble Court shows inclination of granting bail to the
accused. the 1.0./P.1. and the APP shall ensure that appropriate conditions are
imposed on the accused or any sureties (0 ensure that the accused does not tamper

1
( scanned with OKEN Scanner

<!-- page 2 -->

with evidence or influence the investigation of witnesses and remains available for
the investigation as and when the 1.0. requires his/her presence or to ensure the
compliance of bail conditions. A checklist of suggestive conditions is enclosed for
reference (Annexure-I).

Further, if the I.O. is unsure about the veracity of the sureties or their capacities
to ensure the compliance of the bail condition by the accused or the place of
residence of the accused, the I.O. shall_seck time from the Court for the
verification of the credibility/capacity of the sureties.

Se While obtaining surety in Narcotic Drugs and Psychotropic Substances cases, the
Court shall be requested to set the amount of bail bond to be sufficiently high,
say, at least half the price of the contraband seized. Besides, a checklist may be
prepared and submitted to the Courts setting out our conditions for the grant of
bail and include the same in the order granting bail. The ID shall submit a signed
checklist to Court.

6. The execution of bail conditions shall be strictly ensured and monitored at the PS

level. SDPO level and Superintendent of Police level.
As per the existing formats and a fortnightly report to be submitted to the respective
DIG — Ranges, IGP — Range & Addl. DGP - L/O. In case the bailee fails to comply
with the conditions, a notice shall be sent to the bailee, and the sureties and entries
made in the case diaries.

Be If the accused fails to abide by the conditions of bail_on two occasions,
immediate measures to get the bail cancelled need to be initiated. These may
also include attaching Cash Bonds by accused or by sureties too.

8. In order to have smooth investigation and subsequent trial, if any, and to execute any
processes viz. summons, warrants, etc., it is important that the LO. records the
correct and verified addresses of the accused and the same are entered in the
records.

Hence, the 1.0. shall insist details of Government issued ID cards, bank accounts, a
letter from the village council/ward chairman while insisting on verification of the
permanent and present addresses including those of the near relatives of the accused
persons.
A profile data record shall invariably be part of the case record, for this purpose.
The addresses given by the accused persons and the sureties shall also be
verified with the respective Police Station jurisdiction to ensure that the
accused is available for investigation and trial process.

2

@ Scanned with OKEN Scanner

<!-- page 3 -->

In the event of any change in the address by the accused, it shall be the duty of
the accused and the sureties to inform the same to the I.O. and the Hon’ble
Court.

9. For absconders, summons shall be issued at first, failing which NBWs shall be
obtained. In case NBWs are not executed, proclamation proceedings shall be
initiated followed by the proceedings for attachment of the property as per the
process laid down in the Cr.P.C.

All Superintendents of Polices are directed to ensure these points and also submit
details of accused in all cases related to Narcotic Drugs and Psychotropic Substances,
extortion, Arms and UAPA/NSR registered from 01st Jan 2023 to the undersigned as per
format given below, by 30th November 2023.

Case No. Name(s) of Whether Name(s) of Name(s) of Remarks
accused accused is accused on absconding
on bail or bail accused, if any.
not
Saxe
at
(Rupin Sharma) IPS
Director General of Police
Nagaland, Kohima.
NO.PHQ/IGP/CID/NAR-D/48/2023/ 810 Dated, Kohima the }g " Oct. 2023
Copy to:
1. The Addl. Director General of Police (Adm/L&O), Nagaland for information.
2. The Inspector General of Police (Range/CID), Nagaland for information.
3. The Dy. Inspector General of Police (Range-Kohima/Dimapw/Mokokchung),
Nagaland for information.
4. The Commissioner of Police Dimapur for information and necessary action.
3
( scanned with OKEN Scanner

<!-- page 4 -->

5. The Superintendent of Police (Kohima/Kiphire/Mokokchung/Noklak/Peren/Longleng
Tseminyu/Tuensang/Wokha/Zunheboto/Mon/Phek/Shamator), Nagaland for
information and necessary action.

6. The Superintendent of Police (SCPS/Cyber/Narcotics), Nagaland for information.

7. The Dy. Commissioner of Police (Dimapur/Chumukedima/Niuland), Nagaland for
information and necessary action.

8. Office copy. 7

\v
+
WN
Director General of Police
Nagaland, Kohima.
4
@ scanned with OKEN Scanner

<!-- page 5 -->

Annexure- A

Checklist for Bail Conditions:

LC] Accused shall produce a cash suretv/deposit of decent amount and in Narcotic
Drugs and Psychotropic Substances cases the surety amount shall not be less than half
of the market value of Narcotic Drugs and Psychotropic Substances seized from the
accused. This cash deposit would be deposited with Court with intimation to the
Police/I.O.

CJ The accused shall produce a surety who is preferably a government servant.

| In case the accused is having any property in his name. the documents of the
property shall be kept as surety.

CL) The Accused shall be requested to share his personal mobile number which must
not be changed and kept in working condition for the 10/Police to have access to him
at all times.

[__] Accused shall share the complete residential address where he is going to stay
during the bail period. In case accused changes his address. he shall inform the IO
of the case and the Court regarding the same. Change of address shall not ordinarily
be done without approval from the Police/I.O.

CJ The accused shall mandatorily visit the PS of his given residential address at least
once in _a week. In case the accused is requested to travel out of that
place/jurisdiction, he shall provide the address where he is likely to be stationed
during such absence and during this period. he shall visit the PS of that place with
information to the 10. The IO may request time to verify such addresses.

| The accused shall mandatorily send a text message from the mobile number he
shared to the IO to confirm that the mobile number he is using is still in usage. In
case if the accused uses any other number. the same shall be informed to the 1.0.

| The accused shall present himself before the IO as and when called for the
purpose of investigation.

| The accused who hails from states other than Nagaland, while entering Nagaland.
shall compulsorily inform to nearest PS after entering Nagaland.

CC] The accused shall keep himself away from any person that may likely to be
involved_in Narcotic Drugs and Psychotropic Substances, Extortion or Arms act
activities. In case, he is found to be connected to such person and his activities are
found suspicious. his bail may be cancelled.

5
G@ Scanned with OKEN Scanner

<!-- page 6 -->

| The accused shall not tamper/influence any witnesses or any other person who may be
a potential witness by either use of any force, intimidation, any contact whatsoever in
person or through messenger or through digital/electronic means.
Further, the accused person shall not make any allurements or attempt to bribe them
in any manner.

LC] The accused shall not engage in tampering of evidence if he is released on bail.

CJ The accused shall fully co-operate with investigating agencies and he shall ensure
to be present as and when required to do so.

[J The accused shall abide by all the conditions as the Hon’ble Court may deem fit in

case of grant of bail to the accused.

**

1. The above bail conditions suggestive to the 1.0.

2. For every offence as mentioned in the circular, 1.0. of the case will take up the necessary
bail conditions in written with the Prosecuting Inspector and with the PP/APP.

3. The 1.0. shall, after submitting his written bail conditions to the Prosecuting Inspector,
PP/APP will indicate the communication that he has prayed to the Court in the form of
giving a and after signing the same, submit a copy to his OC concerned.

6
CE scanned with OKEN Scanner
