---
doc_id: "cede14c29a35b7ed"
source_url: "https://police.nagaland.gov.in/wp-content/uploads/2023/10/office-memorandum_compressed.pdf"
ministry: "Police Department, Nagaland"
title: "Office Memorandum"
date: ""
pages: 8
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "53eaa4d75905197e"
---

<!-- page 1 -->

P GOVERNMENT OF NAGALAND
OFFICE OF THE DIRECTOR GENERAL OF POLICE
NAGALAND, KOHIMA
NO. PHQ(B-IN2/7/2011 / BY Dated, Kohima the fh Septerhber, 2023.»
OFFICE MEMORANDUM
¥ In supersession and consolidation of all previous Office Memorandum, the
‘ following provisions shall herein after govern the nominations to appear in the /Central
Promotion Test (CPT), the conduct of CPTs and promotion thereafter. The provisions are
being framed to provide opportunity to every eligible and willing personnel in the (
Department for promotions at any time during their service tenures.
1. The Department shall endeavour to conduct CPTs annually, every year. :
2. Before conducting CPT, the Department shall draw up an annual list of
prospective vacancies for the coming year and inform all” the Units
concerned. Since these vacancies can be calculated based on parameters like
retirement, promotions etc, tentative figures can be worked out. .
: Some allowances, about 10% can be added due to contingencies like
death or ailments or disciplinary proceedings also.
3. The above process will ensure that the CPT qualified lists and waiting lists are
not too long and for perpetuity. This will allow the willing personnel to avail
CPT opportunities in the next cycle, even if they do not succeed in the
current one.
4. The Department shall only maintain a waiting list of CPT qualified
. personnel of about 10% in excess of the available vacancies each year.
: However, PHQ may consider deviation on a year to year basis.
Condt.......2/-

<!-- page 2 -->

r
: _—s
5. The Central Promotion Test (CPT) will be conducted on the following parameters.
i ll ae
Se eee ae a a
[i Weapon natin
,
[oe [oavvie. tom toe
a ee a
* Weapon Handling shall not apply and shall be substituted by conducting test on
, Computer/ IT proficiency for Computer Operators and Mechanical/ Technical/ practical
test on motor Mechanics shall be conducted for the MT cadres. .
6. The parameters for the Central Promotion Test (CPT) in Turn out, Drill and
Weapon Handling, Written Test etc pertains to regimental and policing matters, as such only the
CPT Board members having domain knowledge shall allocate marks on them, as indicated at (5)
above.

, The Central Promotion Test (CPT) Board members of the Home Department and,
the P&AR Department shall oversee the CPT proceedings but shall not allocate marks except in
Viva/Oral test.

he The candidates appearing the CPT must secure a minimum of 50%
aggregate marks out of the total marks earmarked to qualify the CPT. Candidates who are
unable to secure a minimum of 50% aggregate marks shall not be considered for promotion,
for the cycle of the CPT for that year. However, they shall be eligible for next CPTs in 03
(three) years and shall NOT be debarred forever. ‘

This will afford opportunities for personnel to update themselves constantly and
regularly, if they want. *s

Condt....+..3/-

<!-- page 3 -->

= Bm
8. From AB to UB for DEF duties Bridge Test — 40 (forty) marks. This shall be
applicable for those Constables in the Battalions who wish to move to DEF, investigation or INT
units. :
7 Since in these units, the work primarily involves legal approach, a Bridge
_ Test to assess suitability is desirable.
The Bridge Test shall emphasis on :-
(a) Ability to read and write, ;
(b) Knowledge of Law.
(c) Ability to write reports
(d) Knowledge of computers, IT related subjects.
(e) Past performances — documented works in Crime detection, Intelligence sharing or
Investigation in Battalions.
(f) Any other exceptional performances. .
Constables qualifying the Bridge Test shall be eligible for seniority as per the year of
recruitment.
9. The CPT will be conducted for the following Ranks:-
(i) Promotion from UBSI to UBI.
. (ii) Promotion from ABSI to ABI.
(iii) Promotion from ASI to UBSI. ‘
(iv) Promotion from HAV to ABSI.
(v) Promotion from literate Constable to ASI.
(vi) Promotion from HC (INT) to ASI.
(vii) From AB to UB for DEF duties Bridge test - 50 (Fifty) marks.
10,ELIGIBILITY CRITERIA TO ATTEND CPT
: é
[ i | UBSI’s of DEF and INT On completion of 07 (seven) years in the rank of SI
| ii | ABSI’s of DEF/ NAP and IR Battalion | On completion of 07 (seven) years in the rank of ABSI
ASI’s of DEF and INT On completion of 06 (six) years in the rank of ASI
j HAV of DEF/ NAP and IR Battalion | On completion of06 (six) years in the rank of HAV
Literate Constablesof DEF/ INT/ NAP | On conipletion of 06 (six) years of service in the rank
and IR Battalion of LCs
Head Constable (HC)/(INT) On completion of 06 (six) years in the rank of HC
Condt.......4/-

<!-- page 4 -->

; w ge
a NOTE - The educational qualification for the LC’s to appear CPT will be:-
(7) General category - GRADUATE.
(ii) Backward Tribe category - HSSLC (10+2).
(iii) The reservation policy of Literate (Graduate) Constables and HC (INT)
for promotion to the rank of ASI will be followed as per the
Government Notification NO- POL-1/ESTT/99/2003 dated 03/05/2017.
(iv) The reservation policy of ASI (GD) for promotion to the rank of SI
(GD) shall be as per the norms practised by PHQ.
10. STANDING INSTRUCTIONS.
(a) The eligible candidates shall be informed about the CPT schedule and eligibility
conditions in writing by the Unit Commanders through the chain of command upto the .
: immediate supervisory Officer L/ Naik/ Naik or Havildar/ THC and their signature
obtained about the information having been shared/ communicated to them.
(b) The Unit Commanders shall ensure that before sending the personnel to attend
CPT a written undertaking is obtained from all eligible personnel that:
(0) on promotion he/she shall be willing to be posted out to any other unit; ;
(ii) he/she shall compulsorily be posted/ transferred to other unit for a
minimum 03 (three) years period.
(c) The Unit Commanders shall ensure that Personnel not willing to undergo CPT
shall submit unwillingness in writing, clearly stating reasons (sample attached).
(d) Those personnel who Submits unwillingness to appear in CPT shall be debarred
. from attending the CPT for the next 03 (three) years. ;
(e) This unwillingness shall be in triplicate, 01 (one) copy will be kept at Unit, 01 (one)
in PHQ and 01 (one) in personal file of the personnel concerned.
However, exception will be made for those under temporary medical condition
and such candidates will be considered to appear in the next CPT but for all such cases
Medical certificate is required to be produced from the District Medical Board, Distriet
Hospital and fresh willingness as per (a)( b) will be obtained for next and each
subsequent cycle separately. :
Cont......5/-
i _ _ "

<!-- page 5 -->

« Se
@ The undertaking to be obtained from the personnel will be in triplicate copies:
® OJ (one) copy to be submitted to PHQ; P
© OI (one) copy to the individual, and
* 01 (one) copy retained at unit.
i In the undertaking the individual will append his signature and witness by unit
commander and 01 (one) officer.
(g) For those personnel on attachments, the undertaking shall be obtained by the Unit
: Commander through the VIP to whom the personnel is attached, in writing.

The maintenance of written records of undertakings of willingness or refusal to appear in
CPTs is essential and the same shall be maintained in triplicate.

This is essential because some personnel who have declined promotions or appearance
in CPT often comes up with excuse that they were unaware of CPTs and have alleged either
bias or favouritism. .

(h) However, after the personnel promoted and posted has completed of 03 (three)

years, their cases for posting to parent units may be considered provided there is

. vacancy and also keeping in mind the need to maintain appropriate inter-tribal ratio in
all units.
Those personnel due to retire within 03 (Three) years from date of promotion may be
considered for retention or home posting.

(@) The Unit Commanders, while nominating/ forwarding names for CPT shall
clearly indicate those under suspension or DE proceedings being held against
them. :

Unit Commanders shall also mention rewards/ punishments while forwarding
nominations.

@ Any personnel who have qualified CPT and listed in fit list but is under
suspension or placed under suspension at time of promotion will not be  ‘
considered. Such cases will be kept under abeyance till the completion of
disciplinary proceedings. Their promotion shall be subject to the outcome of the
disciplinary proceedings.

Jf cleared, in Departmental Enquiry (DE), they shall be placed at the bottom of the

seniority list for that CPT cycle, irrespective of | inter-se-seniority or performance in the CPT.
Condt.....6/~

<!-- page 6 -->

——E——S—‘(‘i‘ _.P”-]]hh.mhmhmtmtmttttC ” "ta
y - 6-
4 (k) All promotions will be effected against existing sanctioned strength only.
j () Except for the posts filled up by direct recruitment, All promotions from the rank of 7
Naik upto Inspector will be 100% by way of CPT except in exceptional cases for Out:
of-Turn promotions (OTP).
The OTP shall normally not exceed 2% of the ranks for which OTP is being
considered. For considering cases for OTP, PHQ shall constitute a Board to éxamine the
cases individually. ‘ 3
(m) The conduct of CPT for all ranks will subject to the vacancy that arises in the
Department overall and not a particular Unit per se and shall not be determined by
, the qualifying years of service a personnel has completed. .
The Units may conduct pre-CPT test at their level to find suitability for CPT.
(a) The ratio of 1:3 will be maintained for calling of CPT for all ranks.
(0) The CPT will be called as per vacancies and not based on eligibility criteria on
. completion of years for attending CPT.
12. MANDATORY INDUCTION COURSE DURATION ON QUALIFYING CPT
(a) ASTI to UBSI- 03(Three) months.
(b) HAV to ABSI - 45(Forty five) Days.
(c) Literate Constables (DEF, NAP, IR) Head Constable’s (INT) to: ASI - 03
(three) months.
(d) UBSI to UBI--—— 45(forty five) days.
. (e) ABSI to ABI——-- 45 (forty five) days.
(g) No promotion shall be effected without completion of the required mandatory 7
induction course.
(h) The qualified candidates in the fit list shall be called for the induction course
: batch wise.
This Office Memorandum shall henceforth, be strictly followed during the conduct
of Central Promotion Test (CPT) for all ranks listed above but shall not apply to NPTO Cadre.
: Sd/-
(RUPIN SHARMA ) IPS
Director General of Police
: Nagaland, Kohima.
Condt......7/-
Le , _, lFe._ee

<!-- page 7 -->

y -
. NO. PHQ(B-ID2/7/2011 / 5ST Dated, Kohima the } th September, 2023.
Copy to:- 7
1. The Principal Secretary (Home) for information please. ‘
a 2. The Commissioner & Secretary (P&AR) for information please.
3. The Addl. Director General of Police (Admn)/ (L&O) Nagaland, Kohima. )
4, The Inspector General of Police (Admn)/ (INT) (Armed Bn.y (IR)/ (Range)/ (Trg&Bdr)/
(CID)/ (NPTO) Nagaland, Kohima.
5. The Dy. Inspector General of Police (Admn)/ (INT)/(NAP) Kma/ Dmtr/ (R/NAP) Tsg/
Mkg/ (Trg)/ (Bdr)/ (Range) Kma/ Dmr/ (IR) North/ South, Nagaland. i ,
6. The Commissioner of Police, Dimapur, for information.
7. The Asstt. Inspector General of Police (Admn)/ (Trg)/ (Ops) for information.
8. The Superintendent of Police Kma/ Mkg/ Wka/ Tsg/ Llg/ Prn/ Phk/ Kpe/ Mon(Zbto/ NIk/
Shamator/ Tseminyu for information.
9. The Dy. Commissioner of Police Chumukedima/ Nuiland for information.  «
10. The Commandant 1°/2"/3"/4"/5"/6"7"/8" NAP/ 9" (IR)/10" (IR)/11" (IR)/12" (IR)/ ;
. 13" (IR)/14" (IR)/15" (IR)/ NAPTC for information.
11, The Principal NPTS, Chumukedima, for information.
. 12. The Joint Director FSL, for information. / oc PLW CMD
13. The Office Superintendent Branch-II/ I, PHQ, for information.
14, The Asstt. Office Superintendent, (Trg) Branch, PHQ, for information.
15. Office copy/ Guard file. ‘
awe
( VIDELALIE ZASHUMO ) IPS
Dy. Inspector General of Police (Admn)
Nagaland, Kohima. . .

<!-- page 8 -->

UNDERTAKING -
AL
; ’
Lpecccsecscereecsseeceessnsecececcerererssereoerseese(Name), Regimental NO.........0.-:+s00+9 Rane. cece cnn
Unlite..cccccccccsssseeseeeeeeeey iS unwilling to undergo the Central Promotion Test (CPT) for the rank
SB Ge Ses aL POM sacs jnesveveenereonnes UUCHONPORSON); ..axvasbesiate nun uatimaciaertetadsnreen crn i
for which nomination has been called by PHQ vide NO........::::sseeeeceresseesersssssssaanereeeeeeeeeeoees
a I, hereby declare that I shall not be eligible to undergo any Central Promotion Test (CPT) for the ;
next 3 (three) years from the date of submission of this undertaking.
‘Nemeé,..... ss, caacereverrnnresrereynerwensy ronson Unit Commander
Regimental No/tank....ceccceeeeeseeeeseeeess
Signatures siccsiveserssersvevecesseuesesssoveevenwees
Dat sscnscnnnccwmnmnnsmintionnxsntenrannsesermerinens Seal and Signature
aN
Dye
