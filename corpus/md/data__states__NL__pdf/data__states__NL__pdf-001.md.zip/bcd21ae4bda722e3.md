---
doc_id: "bcd21ae4bda722e3"
source_url: "https://highereducation.nagaland.gov.in/wp-content/uploads/2025/12/Hostel-Guidelines.pdf"
ministry: "Higher Education Department, Nagaland"
title: "Hostel Guidelines"
date: ""
pages: 2
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "cf7f817c4dad4548"
---

<!-- page 1 -->

\ af
- /
Ws / GOVERNMENT OF NAGALAND Anrwee
/ DIRECTORATE OF HIGHER EDUCATION
ae oe | NAGALAND: KOHIMA,
Website: vo highered dentin i mys Email: (lir.ieiy 4 suniteos
ah,
NO.HED/HOST/3/2018/ Kohima, dated the (@ April 2025.
GUIDELINES FOR HOSTEL OWNERS/WARDENS
(Kor Hostels having Eligibility Certificate from Higher Education, Nagaland)
1. The hostel owners/wardens should ‘maintain a register with the following particulars of the
hostellers:
a) Name of the boarder. b) Date and Year of admission. c) Name of the college. d) Class and
Course. e) Father’s Name and Occupation. f) Permanent address. g) Recent passport/email/phone
Number of the boarders is to be pasted/written against the boarder’s name in the register.
NOTE: The warden must be in the position to produce the above-mentioned register as and when
| asked by the Department of Higher Education, Nagaland, Kohima.
2. Appointment and keeping of a proper warden is compulsory to look after the welfare of the
hostellers.
3. Hostels for boys and girls must be maintained in separate buildings with separate wardens.
(i.e. male warden for boys & female warden for girls).
4, Hostels should provide a healthy. diet to the hostellers and offer facilities such as proper
rooms/chairs/tables/book racks/heds/drinking water ete.
5. The location of the hoste! should be in a healthy environment free from vices and disturbances. ~
6, Raging in any form shall not be allowed. .
7. Career Guidance/Counselling/Character moulding activities like Sports, Music etc. should be
imparted and encouraged.
8. The warden must strictly enforce the daily study routine and hostel rules framed by the hostel
authority.
9. The use of a double-decker bed is not advisable for college-going hostellers.
i 10. If the hostel owner wants to close their hostel, they should surrender the original registration
| certificate issued by the Department to the undersigned authority. “
| 11. To increase the intake capacity of the hostellers, the hostel owner must get permission from the
| Department by submitting an application and surrendering the original copy of the Eligibility
| Certificate issued by the Department.
| 12. Change of hostel location and name of the hostel must be done with the knowledge of this
Department.
13. Surprise checks would be conducted by the Department at any time without prior information to
the hostel Warden/Owner.
14. The hostel form issued by the Department is meant for genuine hostellers therefore, it should nat
be misused.
15. The Hostel Eligibility Certificate issued by this Department will be treated as permanent only after
the Inspection is done. -
Scanned with CamScanner

<!-- page 2 -->

%.
| 16. The Department shall charge 21000/- for every New/Renewal Hostel Fligibility Certificate tomes se
the correspondence and verification expenses. (Revision of the rate shall take place from time to ty
time depending upon the need and requirement). : ic

(7. The Department shall charge %20/- for scholarship hostel form with effect froin the Academic
Session 2025-26. (Revision of the rate shall take place from time to time depending upon the need
and requirement). +

18. In case of any correction in the Hostel Eligibility Certificate, the proprietor may apply with a
payment of 2200/-,

19. In the event of the detection of any matpractices, the Department shall cancel the Hostel Eligibility
Certificate and necessary action will be taken against the responsible proprietors.

20. The Guidelines/Rules heing issued by the Department must be strictly followed. (Not adhering to
the guidelines is liable to cancellation of the Hostel Eligibility Certificate).

21. ‘This Hostel Eligibility Certificate is not transferable, change of ownership or selling of the Hoste!
Eligibility Certificate is not allowed,

22. The Hostel Eligibility Certificate shall be mandatory to renew once in every five years. Hostels
failing to renew within the stipulated time shall be considered null and void.

23. It is cautioned that the Department issues this Hostel Eligibility Certificate only to facilitate hostel
forms for Post Matric Students residing in the Hostels under the provision of Scholarship
guidelines, Therefore, the Department is not liable for any misuse of the Hostel Certificate.

24, In case of any differences, the decision of the Department will be final...

| \

oe
Weis
ail 4}
| . (V. LOVITOLY SEMA}, NCS ;
Ex-officio Director
Higher Education, Nagaland: Kohima
|
}
Scanned with CamScanner
