---
doc_id: "f0f9aba8c80f6db4"
source_url: "https://ipr.nagaland.gov.in/sites/default/files/2020-02/Guidelines-for-Nagaland-Journalist.pdf"
ministry: "Information and Public Relations Department, Nagaland"
title: "Guidelines for Nagaland Journalist' Welfare Scheme"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "edfde1b351c23908"
---

<!-- page 1 -->

GOVERNMENT OF NAGALAND
DEPARTMENT OF INFORMATION & PUBLIC RELATIONS
NAGALAND: KOHIMA
NOTIFICATION
Dated Kohima the 3rd Oct, 2016
NO.IPT/PUB-7/1 /89::
In the interest of public service, (lie Governor of Nagaland is pleased
to notify the Guidelines for Nagaland Journalists' Welfare Scheme.
The Scheme has provisions for one-time ex-gratia relief on urgent basis to journalists and their
families.
I. Constitution And Administration of the Scheme:
The Scheme will be constituted under the Department of Information & Public Relations
and will be administered by a Committee comprising:1. Minister/Parliamentary Secretary
Information & Public Relations Deptt
2. Secretary/Commissioner & Secretary (IPR)
3. Director H&FW
4. President, Nagaland Press Association
5. 2(two) Journalists nominated by Secretary (IPR)
6. Director IPR

- Patron
- Chairperson
- Member
- Member
- Members
- Member Secretary

II. Eligibility:
1. He/ she should be a citizen of India.
2. He/ she should ordinarily be a resident of Nagaland.
3. He /she should be accredited to the Govt, of Nagaland.
4. He/she should have a savings bank account with any scheduled commercial bank linked
with his/her Aaddhar number.
5. Journalist’ who are not presently accredited to the Government are also eligible for
relief from the Scheme if they have been journalist as defined under the Working
Journalist’ Act 1955 for a minimum period of three years.
6. Each applicant shall be required to furnish along with the application all necessary
approvals or consent forms for subscribing to the "Pradhan Mantri Jeevan Jyoti Bima
Yojana (PMJJBY) and "Pradhan Mantri Bima Suraksha Yojana (PMBSY)" Schemes as
prescribed.
I I I . Procedure:
1. The applicant for the grant of financial assistance under the scheme shall be submitted
to the Director IPR in the form prescribed in Schedule - 1. This application format
maybe amended as and when required.
2. The proposal received for assistance from the Scheme will be processed by the Director
IPR a n d will be sent to the Committee with specific recommendation and supporting
documents.
3. The recommendation will be considered and decided by the committee and assistance
will be released with the approval of Minister/Parliamentary Secretary of IPR. However,
in case of urgency, the Chairman may initiate a case for approval of
Minister/Parliamentary Secretary of IPR. Such approval will be reported in the next
meeting of the Committee.
IV. Assistance available under the Scheme:
1. Up to Rs. 2 lakhs (Rupees two lakhs) only may be provided to the family under
extreme hardship on account of death of the journalist.
2. Up to Rs- 2.00 lakh (Rupees Two lakhs) only may be provided to the journalist in the
case of permanent disability rendering (he journalist incapable of earning a livelihood.

<!-- page 2 -->

3. Up to Rs, 1.00 lakh (Rupees one lakh) only may be provided towards the cost of the
treatment of major ailments such as cancer, renal failure, heart ailments requiring bybass open heart surgery, angioplasty, brain hemorrhage and paralytic attack etc. This
would be subject to the medical expenditure not being covered under Central
Government Health Scheme (CGHS), or any other insurance/ department health
schemes, etc.
4. Up to Rs.50,000 (Rupees fifty thousand) only may be provided in case of accidents
causing serious injuries necessitating hospitalization. This would be subject to the
medical expenditure not being covered under CGHS, or any oilier insurance /
departmental health schemes, etc.
However, in case of non- accredited journalists, the quantum of assistance available for
cases (ii), (iii) and (iv) above will be limited to Rs. 50,000 (Rupees fifty thousand) only.
5. The Committee if it feels necessary in very special / exceptional cases may recommend
higher level assistance or suggest any other deviation of the guidelines for approval of
Hon'ble Minister/Parliamentary Secretary of Information & Public Relations.
V. Welfare Fund:
1. There shall be constituted a Fund called the Nagaland Journalists Welfare Fund which
shall consist of contributions made by the Government of Nagaland from time to time
towards the corpus of the Fund.
2. Financial assistance under these guidelines shall be paid out of the interest accruing to
the corpus of the Nagaland Accredited Journalists Welfare Fund and no part of the
corpus of the Fund shall lie utilized for payment of any assistance under these
guidelines. Interest accruing to the corpus shall be deposited in a Savings Bank Account
in a Nationalized Bank. The Committee constituted shall be competent to decide
whether any part of the interest remaining unutilized shall be transferred to the corpus of
the Fund.
3. Grant of financial assistance from me Scheme to any working journalist is not a matter
of right. Assistance would be extended depending on the Committee's satisfaction
regarding the eligibility / merits of the cases and the financial resources available for the
purpose. The Committee reserves the right to reject or accept any application without
assigning any reason thereof.
Sd/-Pankaj Kumar, I.A.S
Chief Secretary to the Govt, of Nagaland
Dated Kohima 3rd Oct, 2016
NO.IPT/PUB-7/1/89
Copy to:-.
1. The Commissioner & Secretary to the Governor of Nagaland, Kohima.
2. The Principal Secretary to the Chief Minister, Nagaland, Kohima.
3. The P.S. to the Speaker/ Dy. Speaker, Nagaland Legislative Assembly, Nagaland.
4. The Sr. P.S to Ministers / parliamentary Secretaries, Nagaland, Kohima.
5. The Sr. P.S to Parliamentary Secretary IPR, Kohima Nagaland for information.
6. The OSD to Chief Secretary, Nagaland Kohima, for information.
7. The Commissioner, Nagaland,, Kohima.
8. The Director, IPR, Kohima
9. All members concerned.
10. All AHODs/MODs.
11. The Publisher, Nagaland Gazette, Kohima for publication in the next issue.
12. The Cabinet Cell, Nagaland, Kohima.
13. Office Copy.

<!-- page 3 -->

Schedule —1

APPLICATION FORM FOR FINANCIAL, ASSISTANCE TO JOURNALIST
UNDER THE JOURNALISTS WELFARE SCHEME
To,
The Director,
Information & Public Relations
Nagaland, Kohima
1.

Name of the Journalist seeking financial assistance (or for
whom financial assistance is being sought)

2.

In case of demise of the Journalist: Name of the applicant in
full, along with address and relation with the deceased

3.

Age and date of birth of the Journalist

4.

Full address of Journalist ( Proof of residence be attached )

5.

Organization for which the Journalist was / is working.

6.

Nature of Employment ( full time / part- time, regular /
contractual employee, stringer, retired, contract for job
work)
Details of work experience of Journalist, along with the
duration of service in the above organization

7.

8.

Reason and purpose for financial
documentary proof as applicable)

9.

Amount of financial assistance sought

10.

Details of financial assistance received / applied for from
the other sources: (eg. PM relief fund, CM relief fund,
Journalist Associations etc)

11.

Whether accredited to the State Govt. (give details)

assistance

(attach

I hereby certify that all the above particulars furnished by me are true to the best of my knowledge
and nothing has been concealed which is relevant to this request for financial assistance.
I undertake to refund the assistance if it is found at any stage that it was obtained on basis of
information known to be false or misrepresentation of tru e facts along with the interest at the prevailing
interest rates applicable in nationalized banks.

Signature of the Applicant
Place:
Date:
Document attached:
