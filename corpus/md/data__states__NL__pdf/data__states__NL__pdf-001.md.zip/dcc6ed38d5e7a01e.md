---
doc_id: "dcc6ed38d5e7a01e"
source_url: "https://dte.nagaland.gov.in/wp-content/uploads/2026/07/Notification-for-rectification-CUET.pdf"
ministry: "Directorate of Technical Education, Nagaland"
title: "Click here to VIEW/DOWNLOAD"
date: ""
pages: 1
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "b801a2e8455f2137"
---

<!-- page 1 -->

iy : r!
f Pm GOVERNMENT OF NAGALAND ey
A am) DIRECTORATE OF TECHNICAL EDUCATION

ar axe” N : Kohima -

NO. DTE/ ESTT-2/02/2025-26/ Dt. Kohima, the 6" July, 2026.
NOTIFICATION

This is to inform the CUET-UG 2026 applied candidates, intending to avail Nagaland State
Reserved Seats for undergoing Medical Allied and Agri Allied Degree courses during the academic
session 2026-2027, that the Merit list based on CUET-UG 2026 marks and rejected list has been
uploaded in the Department website: - https://dte.nagaland.gov.in and also on the Notice Board
of the Directorate of Technical Education, Nagaland, Kohima. The candidates are therefore
informed to thoroughly cross-check their details as furnished such as; Name of the Candidate,
Fathers Name, DOB, CUET marks, Scheduled Tribe and Backward Tribe.

In case of any discrepancies detected, the candidates are informed to provide the correct
details to the office of the undersigned on or before 9" July, 2026 during Office hours. Thereafter
no correction or changes in any manner shall be entertained.

(Er. VIPULHOU LHOUNGU)
Director
NO. DTE/ ESTT-2/02/2025-26/ Dt. Kohima, the 6" July, 2026.
Copy to :-

1. The Secretary to the Govt. of Nagaland, Department of Higher & Technical Education,
Kohima, for information.

2. The Director, Information & Public Relation, Nagaland, Kohima, with a request to make
necessary arrangement for publication of the above Notification as advertisement in all
local Newspapers.

3. Notice Board, Dte. of Technical Education, Kohima.

4. Website in-charge, Dte. of Technical Education, Kohima

LW Office copy.
a
(Er. VIPUEHOU éti U)
Director
(“I dir.techedu-ngl@nic.in / tenagaland@gmail.com € 0370-2270409/2271432 ge ite nEgANE.Gow In 7
