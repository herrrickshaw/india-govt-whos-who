---
doc_id: "61f01af9aec41efc"
source_url: "https://cdn.s3waas.gov.in/s32dea61eed4bceec564a00115c4d21334/uploads/2017/05/2017112381.pdf"
ministry: "Peren"
title: "Corrigendum (16 KB)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "9473a1357ae3772d"
---

<!-- no text layer: pending OCR -->
