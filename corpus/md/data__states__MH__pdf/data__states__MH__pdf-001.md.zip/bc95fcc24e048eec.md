---
doc_id: "bc95fcc24e048eec"
source_url: "https://krishi.maharashtra.gov.in/Site/Upload/PDF/Notification_Manufacturer_Registration_2026.pdf"
ministry: "Agriculture Department, Maharashtra"
title: "Manufacturer Registration 2026"
date: ""
pages: 23
method: "tesseract:mar+hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "c7f0defdb17ee882"
---

<!-- page 1 -->

ak is
आ. ५ en nn an A,
ee Director of Horticulture, g Red
.O® Commissionerate of Agriculture, Pune 2, ऋलगी
Address : Near Bhujal Bhavan, Shivaji Nagar, Pune-411005 poe ee
5 ie Office No. : 020-29703228 / 25538095
E Mail 10 : info@mahanhm.in agridhrt@gmail.com
ll arc oe A नळ
No.CoA.Hort-3/Prot. Cult/ 544 /2026 Date (2 ७ /03/2026
To
All the Manufactures of Poly film, Tape Net,
Mono Net, Insect Net, Apron Paper, Plastic Mulching, Weedmat
Anti hail Net for Pomegranate, Plastic Cover for Grape & GI Pipe, Fruit/Bunch cover
Subject : Invitation of application for Empanelment / Renewal of Manufacturers for supply and
installation of U.V Stabilized Poly film, Tape Net, Mono Net, Insect Net, Apron Paper,
Plastic Mulching, Weedmat, Anti hail Net for Pomegranate, Plastic Cover for Grape, Fruit
ष्ट P
/ Bunch cover & GI Pipe.
Sir,

The Department of Agriculture Government of Maharashtra is promoting Protected Cultivation
Component with Financial Assistance to the farmers under different schemes. Director of Horticulture,
Commissionerate of Agriculture, Pune is inviting application for “EMPANELMENT / RENEWAL of
Manufacturers for supply & Installation of UV Stabilized Poly film, Tape Net, Mono Net, Insect Net,
Apron Paper (Laminated Woven Polyethylene Film), Plastic Mulching (Polyethylene mulch films),
Weedmat, Anti hail Net (Hail Protection nets) for Pomegranate with M.S. Angle structure, Plastic Cover
(Laminated Woven Orchard Protection Covers) for Grape, Fruit Cover/Crop cover & GI Pipe (for
Polyhouse / Shadenet House Erection) for effective implementation of aforesaid components and to ensure
beneficiary with quality supply of material and for assurance of Guarantee, warrantee and Maintenance
from the Manufacturer.

Ce ४
Bea
Pivector t rticulture
Commissionerate of Agriculiure,
Maharashtra State, Pune 5 5
Copy to : District Superintending Agriculture Officer.( All District) tor Information & Publicity.

<!-- page 2 -->

र
शी
Ay

2. Director of Horticulture, 2 be
SOO अ नि ५ ९५८
ऊण Commissionerate of Agriculture, Pune ica
Address : Near Bhujal Bhavan, Shivaji Nagar, Pune-411005
Office No. : 020-29703228 Mail 10 : info@mahanhm.in

NOTICE
Director Of Horticultyre, Commissionerate of Agriculture, Pune invites application for
“EMPANELMENT / RENEWAL of Manufactures for supply & Installation of UV Stabilized Poly
film, Tape Net, Mono Net, Insect Net, Apron Paper (Laminated Woven Polyethylene Film), Plastic
Mulching (Polyethylene mulch films), Weedmat, Anti hail Net (Hail Protection nets) for Pomegranate
with M.S. Angle structure, Plastic Cover (Laminated Woven Orchard Protection Covers) for Grape
Fruit Cover/Bunch Cover & GI Pipe (for Polyhouse / Shadenet House Erection)” for effective
implementation of aforesaid components and to ensure beneficiary with quality supply of material and for
assurance of Guarantee, Warrantee and Maintenance from the Manufacturer, Manufacturer (also
referred as ‘Applicant’) may apply for the EMPANELMENT / RENEWAL as individual applicant or
consortium with suitable partners. Only application of Manufacturers that the pre-qualification criteria
। would be considered by'the Director of Horticulture, Pune. Accepting the application by the department
| would not guarantee as the final EMPANELMENT /RENEWAL. Interested manufacturers have to
download the prescribed form the website given below. Complete filled APPLICATION form with all the
शं
annexure and details have be submitted to the office (address given below). For renewal firm may submit
application upto 150471 2026. For further details and more information please visit on website
hitps://krishi. maharashtra.gov tra.gov.in
> Document Required for Renewal
e Valid BIS
e New/Amended /Revised Bank Guarantee(as per new office account details)
e Undertaking | दया
e Stock Register (Annexure-6)
¢ Progress Report (Annexure-7)
e Agreement (Annexure-8)
e Document for Authorised Distributor
e Document for After Sale Service Centre
> Kor New Empanelment, interested manufacturers may submit _ file as per attached
Empanelment notice. vee \ peo

ठी * 0०४० शता त्ता

शू Commissioncraty of Agriculture, Pune
Address for submitting Application we
Director, Horticulture,
Near Shujal Bhavan, Shivaji Nagar, Pung-41 1005

<!-- page 3 -->

४ Level Dechnical € tee for State loved
Terms and Conditions recommended by State Leve 1 1 ती ve i हि ५ है ver
. क क्ल Tene ot, M st, sect net, Plastic

Registration of Manufacturers for supply of Polyfilm, Pape net, पात a 7 ee i " '

Mulching, Weedmat, Apron Paper, Anti hail Net for Pomegranate with M.S Angle structure

Plastic coverfor Grape, Fruit Cover/Bunch Cover & GI Pipe are as follows: te ,

1. The जिल्ला of Horticulture, Commissionerate of Agriculture, Pune on behalf of Department of
Agriculture, Government of Maharashtra is inviting Applications (Annexure-1) for State level
Registration” Empanclment/Renewal of reputed Manufacturers/Suppliers who meet the minimum
cheibility criteria as specified in Empanelment document for Supply of Polyfilm, Tape net, Mono net,
Inseet_ net, Apron Paper, Plastic Mulching, Weedmat,Anti hail Net for Pomegranate with M.S Angle
structure, Plastic cover for Grape,Fruit Cover/Bunch Cover & GI Pipe material at the farmer's fields under
MIDH, RKVY and other Schemes.

-. The complete Empanelment — document छत]. ७८ published on the website
https:/krishi. maharashtra.gov.in for the purpose of State level Registration.

5. Manufacturers Qualification/Eligibility- For Empanelment Manufacturer should submit component
specific Valid BIS Licence copy and Valid Test reports of CIPET/BTRA &TDS. The testing institute

__ should be NABL accredited for cladding material testing. __

Sr Material Applicants Eligibility Technical Entity/requiremeni 4
& ४० | Component BIS & Test report requirement कब
| For Polyfilm Manufacturer Any BI IS 15827:2019
1 | Poly film License (Operative)
| i Se rates न
| > fi Material Confirming specifications given in IS
For Polyfim Importer zs i |
__ ली 15827:2019 with valid CIPET Report =
Any BIS License (Operative) 15 16008 Part 1 :2016
2 e it firmi ifieati i in IS 1600
Tape net For Tape net Importer Material Confirming specifica ions given in ॥
वी । Part I : 2016 with valid CIPET Report |

} |_Any BIS License (Operative) 15 16008 Part 11 :2016

3 Monnet For Mono net Importer Material Confirming Specifications given in IS 16008
|__ Part I: 2016 with valid CIPET Report
Any BIS License (Operative’ IS 16513:2016
| | i A Material Confirming specifications given in 15 |
| 4 | -Ansectinet | For Insect net Importer 16513:2016 with valid CIPET Report |
| Plastic Cover for | AMY BIS License (Operative) | 15 17731-0921 |
| 5. | Grape (Laminated [pi ic Cover (Laminated Woven |
~ | Woven Orchard ० aaah Protection Covers) Material Confirming specifications given in IS}
K | Protection Covers) home N 17731:2021 with valid CIPET Report |
a i _ Importer |
Fs डं 1 है
| Anti hail net for | Any BIS License (Operative)holder 1S17730:2021(Part I tl)
6 | Pomegranate (Hail a firmi ificati कु हू
| री Material Confirming specifications given झा
Protection nets ai ion Ni
__|_ 0 2 Hall Protection Nets Importer | 1317730:2021(Part 1 ll) with valid CIPET Report
र्व . 15 17216:2019 |
___ Plastic Mulehing Any BIS License (Operative) holder i
: थि mulch | Polyethylene mulch films | Material Confirming specifications given in IS a
ला १0. 17216:2019 with valid CIPET Report |
cir Any BIS License (Operative) holder (१5 per Amendment No.2 - IS:1161 2014) Steel Tubes ।
8 +i Pipe OR Authorized Distributor of BIS For Structural Purpose |
bo | License Holder Manufacturer Baa! र 2 ल 5
| ne ae ne ee Specification as per Protected Cultivation guideline |
9 | Palyethviene BiG | CIPET/SASMIRA/BTRA test report] (UV stabilized & minimum 120 GSM should be |
yethy 1 we {

| | Weedmat-Agro | Hala tee 1

| | Textiles — Woven | 1516202: 2014 |

| | Ground i ढं F i

10 | Gann for | ४७ BIS License (Operative) holder । |

| | Horticulture | | ory |

LL Application य a pill ae |

@ (Hilts चन. ५ मी 5 कड तडतड ती मकनन : |

<!-- page 4 -->

erin | | Technical Pntity/requirement

sr Material | Applicants Eligibility | , 87% sei |
No Component | । BIS. & Test report requirement |

FruivRunech (तल |

(Paper/Non Woven | |

Cover Paper bays ete) | | 18 1671822021

की 7 mal i - Any BIS License (Operative) holder | (फल्च /sAsMIRA/BTRA test report for other than 85
" Ronde! Non-Woven ( top Material

Covers and Pruit Skirting |

Rags for Agricultural and |

* Manufacturer shall submit samples of cladding materials (size 2m x 2m) with its laboratory test
reports and proper specification marking/embossing mark on it. The concern manufacturer should
have laboratory set up and equipment. The details of technical specifications with respect to BIS
material should be submitted by Manufacturer (Annexure - 5).

5. Manufacturer having BIS certificate expiring during the registration period should be renewed an’
furnished within 45 days and submitted on time otherwise Empanelment will be deemed to be
terminated,

6. The manufactures will have to compulsorily supply with engrave/embossing BIS, Batch No.. Type,
brand. C.M.L.No. on the Polyfilm, Tape net, Mono net, Insect net, Apron Paper, Plastic
Mulching,Weedmat, Anti hail Net for Pomegranate with M.S Angle structure, Plastic cover for Grape
FruivBunch cover & GI Pipe material supplied under subsidy schemes (RKVY, MIDH & other
Subsidy Schemes). (for BIS operative licence holders) and all above details for Material Confirming
norms of BIS.

7. The supplied and installed material should confirm the following information

a) Indication of the source of manufacture

b) Type of cladding material

c) Declared length and width of sheet/ fabric द

d) Mass per square metre of the sheet/ fabric

९) Batch No and date of manufacture

8. Bank Guarantee and Empanelment Fees- Submission as per below details a

[ Empanelme Bank i

| Component ntFees Guarante

| (in Rs) e |
ie in Rs) _
UV Stabilized Poly film / Plastic Cover for Grape-(Laminated
Woven Orchard ProtectionCovers) /APRON Paper-(UV Stabilized 10,000 5,00,000
Laminated Woven Polyethylene film (Apron Paper) : |

fe et er
‘Tape net/ Monnet/ Insect net/ Anti hail net forPomegranate (Hail 10,000 5,00,000 i
Protection nets) oa ० मरळ oe |
Plastic Mulching (Polyethylene mulch films)/Weedmat/Fruit 5,000 | 1,00,000. |

{| cover/Bunch Cover ole 20205: 0:

<!-- page 5 -->

Phe concern manufacturer should submit Bank Guarantee for licence period in favour of
Assistant Director, Account -01, Commissioncrate of Agriculture, Pune. The violation of any
terms and conditions the empanetled firm may be penalised by forbidding the Bank Guarantee

9. Non-refundable Registration fee shall be paid in the form of RTGS / NES in favour of
Assistant Director, Account -01, Commissionerate of Agriculture, Pune by REGS/NEIL and
submit original receipt of Empanelment Fees/details of payment (Annexure- 4)

10, The Manufacturer Registration will remain valid for maximum ONE Year. ‘The registration renewal
should be done within 1 month from validity expiry. The empaneled manufacturer failed to submit
renewal document within one month of registration expiry, the manufacturer application will be treated as
new registration / empanelment.

11. Legal Entities - Registered Manufacturer under Udyog Aadhar/ Udyam Registration/Shop Act
Certificate with necessary documents on TIN & PAN number is eligible to participate in the
registration process and submit aforesaid documents compulsory.

12. Tax registration:- The manufacturer should have a registered number of GSTN where his/ her

(६ businessis located.

13. The applicant should have to produce their Internal Quality Assurance and Quality Control
(QAQC) plan and manual and Details of manufacturing process and manufacturing plant &
machinery details, testing procedures of inputs & manufacturing process.

14. The applicant should give details of their own laboratory equipment and machinery required for
Testing and Manufacturing of Poly film, Tape net, Mono net, Insect net, Plastic Mulching, Weedmat,
Apron Paper, Anti hail Net for Pomegranate, Plastic cover for Grape,Fruit cover/Bunch cover & Gl
Pipe.

15. Undertakings:- The applicant will have to produce the undertakings regarding Guarantee,
Warranty, After Sale Service Station and maintenance on Rs.500/- Non Judicial Stamp
paper.(Undertakings-I)

A
Beneficia
L Component Warranty
_ eriod
| Potyiim 20५& 3५ Year
| Tape net 2™& 3" Year
| Monnet 1 Year 2"& 3 Year
| Insect net 1 Year 2™& 3" Year |
py a म्या फला te? foros Grape ot if oer Capea ता EITC reece ra reg |
| Anti bail net for P egranate 3 |

<!-- page 6 -->

शकल्या | After Sale Services for material |

| suppliedunder Govt Schemes to |

है Beneficiary |

G1 Pipe ; 1 icc 2", 30 4" & 50 Years
UV Stabilized Laminated Woven Polyethylene) ea i sia sal ।
film (Apron Paper) | Year 27 & 3" Year |
Weedmat-Agro Textiles — Woven Ground | पा
Covers for Horticulture Application | Year 2" & 3" Year |
EruivBunch Cover (Paper/Non Woven | |
। Cover/Paper bags ete) "शण | Month ।
eee 1 |

16. A) Guarantee:-If material supplied to beneficiary get damaged due to quality aspects as per BIS
standard and defects or damages are due to manufacturing process within one year registered
manufacturer should replace complete or whole quantity of material free of cost from date of
installation. Guarantee does not include damages due to natural calamities OR Man made and
Animal damage.

B) Warranty :- Warranty inclusive of replacement of complete defective parts only free of cost fron.
completion of Guarantee period to next years specified in point no.15 for the components supplied to
the beneficiaries under MIDH / RKVY and other Government Schemes.

17. Replacement of extent of cladding material, plastic mulching or quantum of material depends/based
on life of material and deterioration and depreciation criteria given by BIS. The final decision for
replacement of material is with Empanelment Authority.

18. Manufacturer should give Self Declaration-about acceptance of Terms and Condition and about
Manufacturer themselves is not blacklisted anywhere by any other State Govt institution
(Undertakings-II on Non Judicial stamp paper). The registered manufacturer shall execute an
agreement with Government of Maharashtra represented by Director » Horticulture, Pune to abide
by the terms and conditions of the registration on Rs.500/- (Rupees Five hundred only) non judicia’ ,
stamp paper (Annexure 8).

19. If any manufacturer fails to provide such prescribed /mandatory services during Guarantee,
Warranty and Maintenance period appropriate action will be taken against them, including and not
limited to forfeiting of bank guarantee and blacklisting for maximum three years.

20. The Manufacturer must set up at least one After Sales Service Centre in the state for providing
technological support at the grass root level. Manufacturer should submit details of After Sales
Service Centre list with technical manpower educational documents, Shop Act Licence documents,
GSTN, contact number details for prescribed premises.

21. A service centre should posses required stock of the necessary spare parts and material required for
maintenance, besides provide technical guidance to the farmers where After Sales Service
Centre is established. Registered Manufacturer may arrange minimum one Region wise Farmers
Awareness Programme on Protected Beir Technology (all aspects).

oe

<!-- page 7 -->

22. In case of दा Pipe If Manufacturer wish to participate in Empanelment process through his
authorised distributor, concern Distributor has to submit all document specified in
Empanelment documents along with Agreement copy with Manufacturer on 500 Rs Non judicial
Stamp Paper.

23. The manufacturers should provide detailed operational and maintenance manuals in the vernacular
language at the time of supply.

24. Manufacturer should submit Application form with complete indexed, page numbers along with the
different Annexure (1, 2, 3, 4, 5, 6, 7, 8, 9) and Undertakings (I & 11) with required attested
copies by theperson authorized with their name & designation

25. The Empanelled manufacturer/supplier should supply material and commence the work immediately
after the date of issue of Presentation to Beneficiary by the concerned officer by duly deploying the
sufficient skilled man power or through Authorized Distributor and the work should be completed
within 90 days for Grape Plastic Cover, Anti hail net for Pomegranate in full shape as per
specifications, norms, criteria given in implementation guidelines of department of Agriculture,
Govt of Maharashtra and MIDH, RKVY.

26. The supply of material should be as per Protected Cultivation Guidelines, Anti hail net Cover for
Pomegranate with M.S Angle Structure Guidelines and Plastic Cover for Grape Guidelines of
Department of Agriculture, Govt of Mahrashtra Any other adminisrative, technical, financial,
implementation instructions modified/inserted by the Director Horticulture, Pune or by
State/Central Govt in due course will be applicable to registered manufacturers from time to
time.

27. It is mandatory to manufacturer who is interested for Empanelment should have to follow criteria set
by BIS while supplying and installing material. The material other than BIS standard should not be
supplied. The material supplied should confirm BIS Standard or specifications mentioned in
implementation guidelines.

28. The manufacturer themselves or through their Authorised Distributor should assist the
beneficiary in submitting bills and relevant documents etc. to the Field Authority for the
purpose of obtaining assistance under the Govt. Schemes.

29. Quality Control: Crucial aspect of supply of material is the quality of material which is delivered to
the farmer. It needs to be ensured that quality components having BIS marking (wherever applicable)
are installed in the beneficiaries field. Poor quality has an adverse impact on crop production which
may affect management practices during for horticulture crops. In fact, sub-standard material will not
only adversely impact performance, but could also reduce the durability and the life of the
components,

a) Manufacturer should clearly declare the component wise different technical parameters (Technical
Data Sheet) which will be tested in the laboratory of CIPET/BTRA or any other laboratory specified
by Central /State Government to determine the quality of the products,

| b) Manufacturers should provide a Compact १00000 containing brief video clip of

<!-- page 8 -->

Manulacturing unit showing all details regarding corporate office. infrastructure, Manufactur ing: unit/
Process, quality control lab & equipment’s etc. along with Empanelment application

©) The Director Horticulture, Pune will form Joint Inspection ‘Teams for Factory, Godown and field
Mspection Frequent surveillance by inspection teams will be a regular feature under this Scheme
They can draw random samples, Manufacturing unit (factory) or Authorised Storage Godown(for
Importer) may be inspected twice by joint inspection team in a year before/after approval or as and
when MSHMPB, Pune feels necessary to ensure the performance and quality of the product.

30. PENALTIES: For non-compliance the complaints. Any Complaint received from the farmers
will be forwarded to the manufacturer and the empanelled manufacturer should rectify the defects
within a period of 20 days from the date of receipt of complaint or otherwise the penalty may be
imposed as follows: More than 30 days after receipt of complaint- Rs. 25,000/ .
More than 45 days after receipt of complaint - Rs. 50.000/ Farmer
More than 60 days after receipt of complaint -- Show Cause notice will be given to the Empanelled
Manufacturer for final response otherwise Bank guarantee will be fortified along with black
listing Empanelied Firm without any further notice by Director Horticulture, Pune

31. If the Empanelled Manufacturer fails to address beneficiary issues/complaints regarding quality
aspects and substandard material the Bank Guarantee shall be liable to be forfeited in part or as
a whole on merits. The Empanelled Manufacturer will also be liable to be blacklisted and
they willnot be registered in future for a period of three years.

32. The violations with regard to submission of bills without supply/installation/partial installation, wrong
invoicing, variations in component specifications, submission of Wrong documents improper
installation, deviations from prescribed material specifications etc. may be dealt with by the
MSHMPB suitably apart from initiating suitable action against company / under the relevant sections
of Indian Penal Code and other relevant / appropriate statutory enactments, apart from forbidding the
bank guarantee disqualification/ suspension/ cancellation of empanelment.

33. Performance Assessment of Empanelled Manufacturer Performance Assessment will be done
after 3 years and feedback of Farmers/ Beneficiaries about material will be taken through
department of Agriculture.

34. If any information provided by the applicants is incomplete or found factually false or misleading,
such applicants / applications will be summarily rejected/removed, without any notice, at any time
during the validity of the registration and also are liable for penalties as applicable. If any
Manufacturer is black listed by any State or Agency, such Empanelled applicants are liable for
canccllation at any time during the validity period.

35. Director Horticulture, Pune Reserves the all the right to restrict / extent the period of Empanelment
with or without assigning any reason and reject/ terminate Registration of Manufacturer at any time
without assigning anyreason,

36. Any dispute between Beneficiary, Erector/Distributor ता Manufacturer will be resolved as per the
ierms and conditions of empanelinent/implementatiog’ eS of State/Central Govi, at Direetor

<!-- page 9 -->

Horticulture, Pune. The manufacturer would be responsible for any dispute arising from the supply
of their product/ component directly or through their authorized distributors. The Implementing,
Agency will to redress the disputes as per process and modus operandi decided by state government.

37. In cases where product quality related complaints from beneficiaries are received due sampling
process mentioned in the guidelines shall be followed. The Empanelment Authority will take
measures against erring companies or their authorized dealers after due hearing in order to safeguard
the interests of farmers/beneficiaries and to ensure effective utilization of public funds.

38. Arbitration: The decision made by Empanelment Authority will be compelled on both the party. If
any party is disagree with the decision made by the Empanelment authority then that party can appeal
to Arbitration Authority i.e Commissioner of a ही Commissionerate in Agriculture, Pune.

Ci
a

<!-- page 10 -->

॥॥॥ ९३ ९-1
Application to be made by ॥॥७॥॥ित0ा त णीचाीचा for State Level Umpanclment / Registration
1 Name of the Manutaeturer company
|, (७७ of “commencement” of | a |
| Manutacturing company | _ rs i
5 a)Address of the registered office
| and Contact Number -_ ee ________|
। ७) Address of the Manufacturing/ |
____|_ Factory Unit and Contact Number वि विन?) |
म . Proprietary / Partnership / Private Limited / Public Limited /
4 | Type of company |
ne ne Other |
| Names of responsible office bearers | _Name | Mobile No. | Email 10
| A.) Chairman / Chief Executive (| टझ/|
| | Officer Information about the 3 शा
| | managing director / director of the [| | लळा |
( | board of directors regarding the | [|
| 5 i private / public limited company. -—
| 1 8) Information about all the |
| | partners of the organization about a ee |
| | the partnership organization 7
। | ९) Proprietor information about the a rs _|
| g rs
| | Manufacturers Licence Date of नि हि
॥ | Registration No Licence Issuing Authority
6 । Certificate/UdyogAadhar
| । /Udyam Registration
|__| Certificate
<j आ... हहत
| 7 । Category of Company Micro/ Small/ Medium/ Large: |
| 7 “| GSTN/ DIN/DPIN Registration No. | Date |
8 | PANNO |
। | Details of Bank re Date of Name |
| | Guarantee of No | Date of Purchase Expiry of Branch |
| Manufacturer for pay | Bank __|
10 | Empanelment | | | | |
|
| Details of Registration oe |
12 | Fee Paid through online is Date Bank details Receipt Details |
GRAS/ RTGS/ NEFT aa in ्शरधर्धारशर्शशिशिरशारशिशिशशि्णिनि
system or |
| | Service Centres available | centre is Opened Name, Contact no Qualification Pow ‘i |
| 13 | inMaharashtra | and Address!) [| शशि | |
| | (List to be submitted) Contact No. का | |
lg he re ii
|
