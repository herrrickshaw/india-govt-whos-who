---
doc_id: "aa65f7b4ae34a4aa"
source_url: "https://cdnbbsr.s3waas.gov.in/s3ffedf5be3a86e2ee281d54cdc97bc1cf/uploads/2023/06/2023061592.pdf"
ministry: "Directorate of Information Technology, Maharashtra"
title: "Advisory for Website Development (English, PDF, 408KB)"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3450237f910cf674"
---

<!-- page 1 -->

Page 1 of 5

Purchase Committee and Project Implementation Committee Meeting
Date: 9th March, 2015
Venue: Room no: 514, 5th floor, Mantralaya annex building, Mumbai 400032
Minutes of Meeting
Annexure A

Website Development Guidelines & SDC Hosting Guidelines
March 2015
Website Development Guidelines
Directorate of Information Technology is receiving multiple requests from the Various Government
Departments for the Development of Websites. Hence, in view of the same, the attached document shall
be referred for the Development of Website.
Department will ensure that any work of amount greater then Rs.10 Lakhs but less than Rs.5 Crore,
approval from Project Implementation Committee (PIC) of department is obtained.
Department will ensure that for any work of amount more than Rs.5 Crore, approval from High Power
Committee (HPC) is obtained as detailed in eGovernance Policy of GoM dated 23rd September 2011.
For Small websites/applications which are having approximately value of upto Rs. 2 Lacs including 1
year maintenance/ support and static websites, small database component, mobile application, etc the
criteria must be set so as to encourage local developers, companies, and entrepreneurs to be able to
participate in the website development. Normal procurement procedure of quotations/tender (whichever
applicable) may be followed. All the small websites may be hosted in a shared hosting environment without
SAN allocation at MH-SDC. However, the tape backup for the same would be maintained at MH-SDC. In
case a separate hosting (dedicated infrastructure) environment is required by the Department, then the
same shall be chargeable as per the applicable SDC Rate Chart. Entire development checklist as mentioned
in Website Development checklist is applicable for small websites.
For Medium websites/applications which are having approximately value of Rs.2 Lacs to 10 Lacs and
medium Database connections such as publishing of official data, complex reports, field based reports,
MIS, etc the RFP criteria that may be set for eligibility of bidder can be factored as below. Normally the
expected time for the development of medium websites is to be within 3 to 6 months from the date of
issuance of Work Order. Cost of AMC should be included in the bid/proposal. SDC infrastructure required
for hosting such websites/applications will be taken as chargeable as per SDC rate chart published. The
criteria set herewith are tentative. :
Sr.
1
2

Pre-qualification Criteria
The bidder should be a Company registered in India under the Companies Act 1956 or a
partnership registered under the India Partnership Act 1932 with their registered office in India.
The bidder should be operating in the field of software development and providing software
solutions in last three years.

<!-- page 2 -->

Page 2 of 5

3
4
5
6
7

The bidder shall have minimum annual turnover of Rs. 10 Lacs in each of the last three years for
Software Development.
The bidder must have completed 3 assignments of websites/ portals/application development in a
Private / Government environment with a value of Rs. 1 Lakhs each, in previous three years.
Bidder should have min 3 Full Time Application development professionals with necessary skillset
as per the requirement of website on bidder’s own payroll.
The bidder should not currently have been blacklisted by any Government Agency or under a
declaration of ineligibility for fraudulent or corrupt practices or inefficient/ineffective performance.
The bidder should be an individual organization. Consortium shall not be allowed.

For Larger websites wherein the expected cost is Rs.10 Lacs or more, the web pages are more complex,
integration with payment gateway, sms gateway, other systems as a part of project requirements then the
relevant RFP needs to be floated as per the project requirements after approval of PIC/HPC as the case
may be. The minimum criteria such as Turnover of the Company, Assignment value, Net Profit, Manpower,
etc to be discussed in PIC/HPC meeting.
Hosting of website at MH-SDC is not mandatory; however, if Departments wishes to host the websites
outside MH-SDC, then the websites should be hosted in a Tier-3 Data Centre environment within India. If
Department wishes to host the website in MH-SDC, then the hosting shall be charged as per the SDC Rate
Chart, however, prior permission from MH-SDC team and DIT needs to be taken for hosting such websites.
The cost of hosting the website in MH-SDC should be factored in the proposal provided by bidder/developer.
Website Development Checklist
Pre-Development Phase
1. Detailed CV of the developer needs to be shared by the bidder company prior to starting the
development of the website.
2. For small and medium website, AMC for the website should be 1 or 2 year from the date of
acceptance / go-live.
3. Department will clearly define the milestone for making payments to the software developer.
4. Development environment to be provisioned by the Bidder/Developer.
5. DIT will have it’s own State Software repository of the successful projects and will ensure there is
no duplication in efforts for software development.
6. Before starting the development/coding of the website, the developers are required to complete
eGovernance 0.0 certification and the 5 Day eGovernance Standards (Localization, GIGW and
Accessibility) training to be mandated in all the website development RFPs. Awareness for the
staging environment and the APIs used as a part of SDC such as Name/Address Databases, SMS
gateway, Payment Gateway, GIS, etc shall be provided as a part of the training. The training
certificate shall be valid for 3 years. Renewal of certificate shall be made available online. Training
would be provided free of cost, however, travel/lodging expenses, etc. will be borne by the
developer/bidder.

<!-- page 3 -->

Page 3 of 5

7. GIGW training course (3 days/5 days) including Marathi Unicode & Accessibility mandatory for all
developers (at least one developer/team leader for small sites, at least two for medium sites and
three

for

large

sites).

The

training

will

be

held

in

MahaOnline

office

in

Mumbai/Pune/Nagpur/Aurangabad centers. Training to also include Level 0 check for Top-10
vulnerabilities as per OWASP. Training would be provided free of cost, however, travel/lodging
expenses, etc. will be borne by the developer/bidder.
8. Intellectual Property Rights (IPR) of the source code will vest solely with the Government of
Maharashtra. However, such a system will not be allowed to be misused by quoting same software
to other districts or departments, as DIT may provide the same free of cost to other Departments.
9. Representatives of software developers working on the project must sign the Non-Disclosure
Agreement (NDA) with project owner of concerned department.
10. Departments to adhere to the Advisory that has been provided to All Government Departments on
30th September 2013 for :
Hosting of Government Websites, use of Official Email IDs and other Cloud based services,
connecting to NIXI & Sec. 43A compliance audits, Adoption of Technical Standards for
Interoperability Framework and other standards published by GoI for various eGovernance
Projects
Use of Standard Components such as Payment Gateway, SMS Gateway, Email, etc would be
provided
As per SDC Rate Chart.
Development Phase
1. Website needs to be Bilingual i.e. Marathi and English. By default, the webpage should open in
Marathi language.
2. Website should be developed with gov.in or maharashtra.gov.in extension.
3. Website should run independent of IP Address. i.e. IP Addresses should be not be hard coded in
the source code/configuration.
4. Website should be IPv6 compliant.
5. Website should be able to open in all six ways. For example,
a.
b.
c.
d.
e.

https://www.maharashtra.gov.in
http://www.maharashtra.gov.in
www.maharashtra.gov.in
https://maharashtra.gov.in
http://maharashtra.gov.in

<!-- page 4 -->

Page 4 of 5
f. maharashtra.gov.in
6. Website should be running on SSL i.e. http request should automatically get redirected to https
7. Website should be compatible to run on multi server environment for load sharing
8. Website should be compatible for accessibility from any device, any Operating System and any
browser.
9. Platform used for Website such as OS, DB, Java, etc. software should be N-1 where N is the latest
versionprevailing.
10. CAPTCHA should be present for web pages with form field such as feedback form, registration
form etc.
11. Logging to be enabled for Web Server / DB Server.
12. Password should not be hardcoded in any website configuration files or stored in plain text.
13. Website should be in compliance with


eGovernance Standards of Government of India :
a. Technical Standards for Interoperability Framework for e-Governance (IFEG) in India
Version 1.0
b. MDDS- Demographic Standards
c. Character Encoding
d. Font Standard
e. eGov.BIDS
f. eGov.BIDS
g. eSAFE-ISF01, eSAFE Framework (and associated documents)
h. Guidelines for Usage of Digital Signatures in e-Governance
i. FMG
j. Policy on Open Standards for e-Governance
Framework for Mobile Governance







e-Governance policies of Government of Maharashtra
Guidelines of Indian Government Website (GIGW)
WCAG 2.0
W3C
Other e-Governance standards of Government of India (egovstandards.gov.in)

Post-Development Phase
1. Level 0 check to be complied by the developer for GIGW compliance and address Top-10
vulnerabilities as per OWASP.
2. Security Audit of Website/Application:
Website/Application needs to be Security Audited by the Cert-In empanelled Security Auditors. The
Security Audit clause should be part of the RFP, wherein the bidder will bear the cost of security certification.

<!-- page 5 -->

Page 5 of 5

3. Security Audit Certificate to be mandated along with Hash5 code. Source code along with Hash5
code of the website to be submitted by Developer. Documentation of Source Code along with
Administration/User Manuals needs to be submitted.
4. DIT would also facilitate the checks for GIGW compliance and Accessibility of the website.
5. The project will be treated as “complete” only if:




UAT / FAT is completed
Handover to the Department is completed
Final Source code along with Security Audit Certificate (with Hash5) of the project
along with detailed documentation and IPR is being transferred to DIT for State
Software Repository.

6. It is advisable to host the Website in the Maharashtra State Data Centre for which below
compliance needs to be adhered.








Details of the website such as Operating System, Database used, Web Servers used,
Data Storage required, architecture, functionality, framework used etc. needs to be
provided to DIT/SDC for due scrutiny.
After due scrutiny of the details provided to start the hosting process, developer
along with department nodal officer needs to visit DIT/MH-SDC for making site
available in staging area for first level security compliance check.
Chief Information Security Officer (CISO) of SDC will analyze the documents
submitted by department along with security audit certificate, he will submit
acceptance or rejection report for hosting at MH-SDC.
Department to submit hardcopy of Declaration letter, source code CD, security audit
certificate etc. to Principal Secretary IT for making website/application live from
production environment. Department/developer will copy the audited code to the

production environment. He will install SSL certificate provided by DCO on
production server. Developer will ensure port redirection from port 80 to 443.

Department will fill change request form (CRF) for opening port 80 & 443 for the
public IP already assigned to the URL. This will be taken as standard request. All email
communication will be accepted only from government email id of department nodal
officer.
DCO will test URL and if it is working successfully then generates the hash code and
make website/application available to public.
