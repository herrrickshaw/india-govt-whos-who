---
doc_id: "eddfda8d28dd62ed"
source_url: "https://www.vaidhmapan.maharashtra.gov.in/Pages/Images/PDF/Notification-RightToService.pdf"
ministry: "Vaidhmapan, Legal Metrology Department, Maharashtra"
title: "Right To Service"
date: ""
pages: 9
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "7dae7034ce118051"
---

<!-- page 1 -->

RNI No. MAHBIL /2009/37831

महाराष्ट्रõ शासन राजपत्र
असाधारण भाग चार-ब

वर्षष ११, अंंक ७]

बुुधवाार, जाानेेवाारीी १५, २०२५/पौौष २५, शकेे १९४६

[पृृष्ठेे ९, किं�ंमत : रुपयेे ९.००

असााधाारण क्रमांं�क १८

प्राधिकृत प्रकाशन
महाराष्ट्र शासनाने महाराष्ट्र अधिनियमांन््वये तयार केलेले
(भाग एक, एक-अ आणि एक-ल यांमध््यये प्रसिद्ध केलेले नियम व आदेश यांव््यतिरिक््त) नियम व आदेश.

अन्न, नाागरीी पुुरवठाा व ग्रााहक संंरक्षण वि�भााग
मंंत्राालय, माादााम काामाा माार्गग, हुुताात्माा रााजगुुरू चौौक,
मुंं�बई ४०० ०३२, दि�नांं�क १३ जाानेेवाारीी, २०२५.
अधि�सूूचनाा
महाारााष्ट्र लोोकसेेवाा हक्क अधि�नि�यम, २०१५.
क्रमांं�क संंकीीर्णण. १०१४/प्र.क्र. १७६(भााग-२)/ नाापुु-१२.–महाारााष्ट्र लोोकसेेवाा हक्क अधि�नि�यम, २०१५ (२०१५ चाा महाा.
३१) यााच्याा कलम ३ च्याा पोोट-कलम (१) द्वाारेे प्रदाान केेलेेल्याा अधि�काारांं�चाा वाापर करून, आणि� शाासकीीय अधि�सूूचनाा, अन्न, नाागरीी
पुुरवठाा व ग्रााहक संंरक्षण वि�भााग, क्रमांं�क. संंकीीर्णण १०१४/प्र.क्र. १७६ (भााग-१)/ नाापुु-१२, दि�नांं�क २४ जूून, २०२४ वि�शेेषत: नि�यंंत्रक,
वैैधमाापनशाास्त्र, अन्न, नाागरीी पुुरवठाा व ग्रााहक संंरक्षण वि�भााग यांं�च्याा द्वा रेे पुुरवि�ण्याात येेणााऱ्याा सेेवाा संंदर्भाा�तीील अधि�सूूचनेेचेे अधि�क्रमण
करून, अन्न, नाागरीी पुुरवठाा व ग्रााहक संंरक्षण वि�भााग, यााद्वा रेे, उक्त अधि�नि�यमााच्याा प्रयोोजनाार्थथ, अन्न, नाागरीी पुुरवठाा व ग्रााहक संंरक्षण
वि�भाागााखाालीील नि�यंंत्रक, वैैधमाापनशाास्त्र, वैैधमाापनशाास्त्र संंस्थाा यांं�च्याा दुुय्यम अधि�कााऱ्यांं�द्वा रेे पाात्र व्यक्तींंनाा पुुरवाावयााच्याा याासोोबत
जोोडलेेल्याा अनुुसूूचीीच्याा स्तंंभ (२) मध्येे वि�नि�र्दि�िष्ट केेलेेल्याा लोोकसेेवाा तसेेच उक्त अनुुसूूचीीच्याा अनुुक्रमेे स्तंंभ (३), (४), (५), व
(६) मध्येे वि�नि�र्दि�िष्ट केेल्यााप्रमााणेे अशाा लोोकसेेवाा पुुरवि�ण्यााचीी ठराावि�क काालमर्याा�दाा, पदनि�र्देेशि�त अधि�काारीी, प्रथम अपीील प्रा धि�काारीी व
द्वि�तीीय अपीील प्रा धि�काारीी अधि�सूूचि�त करीीत आहेे.

भााग चाार-ब-१८–१

(१)

<!-- page 2 -->

2

महाारााष्ट्र शाासन रााजपत्र असााधाारण भााग चाार-ब, ¨जाानेेवाारीी १५, २०२५/पौौष २५, शकेे १९४६

अनुुसूूचीी
अ. क्र.

लोोकसेेवेेचेे नााव

सेेवाा पुुरवि�ण्यााचीी काालमर्याा�दाा
(काामााचेे दि�वस)

ज्यााच्यााकडूून सेेवाा
पुुरवि�लीी जााईल,
तोो पदनि�र्देेशि�त
अधि�काारीी

प्रथम अपि�लीीय
प्रा धि�काारीी

द्वि�तीीय अपि�लीीय
प्रा धि�काारीी

(१)

(२)

(३)

(४)

(५)

(६)

१

वजन वाा माापेे
उत्पाादकााकरि�ताा
परवाानाा देेणेे.

३५ दि�वस

सहसचि�व/उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

वजन वाा माापेे
उत्पाादकााच्याा
परवाान्यााचेे
नूूतनीीकरण

स्वयंंचलि�त- नूूतनीीकरण

सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

वजन वाा
माापेे उत्पाादक
परवाान्याामध्येे
फेेरफाार

३५ दि�वस

सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

वजन वाा माापेे
दुुरुस्तीीकरि�ताा
परवाानाा देेणेे

३५ दि�वस

(१) सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(१) प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(२) नि�यंंत्रक,
वैैधमाापनशाास्त्र

(२) सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

वैैधमाापनशाास्त्र

(१) सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(१) प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(२) प्रा देेशि�क
सह नि�यंंत्रक,
वैैधमाापनशाास्त्र

(२) नि�यंंत्रक,
वैैधमाापनशाास्त्र

(२) सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(३) जि�ल्हाा
उप नि�यंंत्रक ,
वैैधमाापनशाास्त्र

(३) प्रा देेशि�क सह
नि�यंंत्रक,
वैैधमाापनशाास्त्र

(३) नि�यंंत्रक,

२

३

४

नि�यंंत्रक,
वैैधमाापनशाास्त्र
नि�यंंत्रक,
वैैधमाापनशाास्त्र
नि�यंंत्रक,
वैैधमाापनशाास्त्र
(१) नि�यंंत्रक,
वैैधमाापनशाास्त्र
(२) प्रा देेशि�क
सह नि�यंंत्रक,
वैैधमाापनशाास्त्र

५

वजन वाा माापेे
दुुरुस्तीी परवाानाा
नूूतनीीकरण

स्वयंंचलि�त- नूूतनीीकरण

(१) नि�यंंत्रक,

वैैधमाापनशाास्त्र

<!-- page 3 -->

3

महाारााष्ट्र शाासन रााजपत्र असााधाारण भााग चाार-ब, ¨जाानेेवाारीी १५, २०२५/पौौष २५, शकेे १९४६

अ. क्र.

लोोकसेेवेेचेे नााव

सेेवाा पुुरवि�ण्यााचीी काालमर्याा�दाा
(काामााचेे दि�वस)

ज्यााच्यााकडूून सेेवाा
पुुरवि�लीी जााईल,
तोो पदनि�र्देेशि�त
अधि�काारीी

प्रथम अपि�लीीय
प्रा धि�काारीी

द्वि�तीीय अपि�लीीय
प्रा धि�काारीी

(१)

(२)

(३)

(४)

(५)

(६)

६

वजन वाा
माापेे दुुरूस्तीी
परवाान्याामध्येे
फेेरफाार

वैैधमाापनशाास्त्र

(१) सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(१) प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(२) प्रा देेशि�क
सह नि�यंंत्रक,
वैैधमाापनशाास्त्र

(२) नि�यंंत्रक,
वैैधमाापनशाास्त्र

(२) सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(१) नि�यंंत्रक,
वैैधमाापनशाास्त्र

(१) सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(१) प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(२) प्रा देेशि�क
सह नि�यंंत्रक,
वैैधमाापनशाास्त्र

(२) नि�यंंत्रक,
वैैधमाापनशाास्त्र

(२) सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(३) जि�ल्हाा
उप नि�यंंत्रक,
वैैधमाापनशाास्त्र

(३) प्रा देेशि�क
सह नि�यंंत्रक,
वैैधमाापनशाास्त्र

(३) नि�यंंत्रक,
वैैधमाापनशाास्त्र

(१) नि�यंंत्रक,
वैैधमाापनशाास्त्र

(१) सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(१) प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(२) प्रा देेशि�क
सह नि�यंंत्रक,
वैैधमाापनशाास्त्र

(२) नि�यंंत्रक,
वैैधमाापनशाास्त्र

(२) सहसचि�व/ उप
सचि�व
अन्न, नाागरीी पुुरवठाा
व ग्रााहक संंरक्षण
वि�भााग

(३) जि�ल्हाा
उप नि�यंंत्रक,
वैैधमाापनशाास्त्र

(३) प्रा देेशि�क
सह नि�यंंत्रक,
वैैधमाापनशाास्त्र

(३) नि�यंंत्रक,
वैैधमाापनशाास्त्र

७

८

वजन वाा माापेे
वि�क्रेेताा म्हणूून
परवाानाा देेणेे

वजन वाा माापेे
वि�क्रेेताा परवाानाा
नूूतनीीकरण

भााग चाार-ब-१८–२

३५ दि�वस

३५ दि�वस

स्वयंंचलि�त- नूूतनीीकरण

(१) नि�यंंत्रक,

<!-- page 4 -->

4

महाारााष्ट्र शाासन रााजपत्र असााधाारण भााग चाार-ब, ¨जाानेेवाारीी १५, २०२५/पौौष २५, शकेे १९४६

अ. क्र.

लोोकसेेवेेचेे नााव

सेेवाा पुुरवि�ण्यााचीी काालमर्याा�दाा
(काामााचेे दि�वस)

ज्यााच्यााकडूून सेेवाा
पुुरवि�लीी जााईल,
तोो पदनि�र्देेशि�त
अधि�काारीी

प्रथम अपि�लीीय
प्रा धि�काारीी

द्वि�तीीय अपि�लीीय
प्रा धि�काारीी

(१)

(२)

(३)

(४)

(५)

(६)

वैैधमाापनशाास्त्र

(१) सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(१) प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

(२) प्रा देेशि�क
सह नि�यंंत्रक,
वैैधमाापनशाास्त्र

(२) नि�यंंत्रक,
वैैधमाापनशाास्त्र

(२) सहसचि�व/ उप
सचि�व
अन्न, नाागरीी पुुरवठाा
व ग्रााहक संंरक्षण
वि�भााग

(३) जि�ल्हाा
उप नि�यंंत्रक,
वैैधमाापनशाास्त्र

(३) प्रा देेशि�क
सह नि�यंंत्रक,
वैैधमाापनशाास्त्र

(३) नि�यंंत्रक,
वैैधमाापनशाास्त्र

९

वजन व माापेे वि�क्रेेताा ३५ दि�वस
परवाान्याामध्येे
फेेरफाार

(१) नि�यंंत्रक,

१०

वैैधमाापनशाास्त्र
(आवेेष्टि��त वस्तूू)
नि�यम, २०११
अंंतर्गगत आवेेष्टि��त
वस्तूंं�चेे उत्पाादक/
आवेेष्टक यांं�चीी
नोंंदणीी करणेे

२५ दि�वस

नि�यंंत्रक,
वैैधमाापनशाास्त्र

सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

११

वैैधमाापनशाास्त्र
(आवेेष्टि��त वस्तूू)
नि�यम, २०११
अंंतर्गगत आवेेष्टि��त
वस्तूंं�चेे उत्पाादक/
आवेेष्टक यांं�च्याा
नोंंदणीीत फेेरफाार
करणेे

२५ दि�वस

नि�यंंत्रक,
वैैधमाापनशाास्त्र

सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

१२

वैैधमाापनशाास्त्र
(आवेेष्टि��त वस्तूू)
नि�यम, २०११
अंंतर्गगत आवेेष्टि��त
वस्तूंं�चेे आयाातदाार
यांं�चीी नोंंदणीी करणेे

२५ दि�वस

नि�यंंत्रक,
वैैधमाापनशाास्त्र

सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

<!-- page 5 -->

5

महाारााष्ट्र शाासन रााजपत्र असााधाारण भााग चाार-ब, ¨जाानेेवाारीी १५, २०२५/पौौष २५, शकेे १९४६

अ. क्र.

लोोकसेेवेेचेे नााव

सेेवाा पुुरवि�ण्यााचीी काालमर्याा�दाा
(काामााचेे दि�वस)

ज्यााच्यााकडूून सेेवाा
पुुरवि�लीी जााईल,
तोो पदनि�र्देेशि�त
अधि�काारीी

प्रथम अपि�लीीय
प्रा धि�काारीी

द्वि�तीीय अपि�लीीय
प्रा धि�काारीी

(१)

(२)

(३)

(४)

(५)

(६)

१३.

वैैधमाापनशाास्त्र
(आवेेष्टि��त वस्तूू)
नि�यम, २०११
अंंतर्गगत आवेेष्टि��त
वस्तूंं�चेे आयाातदाार
यांं�च्याा नोंंदणीीत
फेेरफाार करणेे

२५ दि�वस

नि�यंंत्रक,
वैैधमाापनशाास्त्र

सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

१४.

नाामनि�र्देेशि�त
व्यक्तीीचीी नोंंदणीी
करणेे

२५ दि�वस

नि�यंंत्रक,
वैैधमाापनशाास्त्र

सहसचि�व/ उप
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

प्रधाान सचि�व/
सचि�व, अन्न, नाागरीी
पुुरवठाा व ग्रााहक
संंरक्षण वि�भााग

१५.

वैैधमाापनशाास्त्र
अधि�नि�यम,
२००९ अंंतर्गगत
वजन वाा माापेे
यांं�चीी पडतााळणीी
व मुुद्रां�कन करून
प्रमााणपत्र देेणेे.

काार्याा�लयांं�तर्गगत ५ दि�वस

सहाायक नि�यंंत्रक/
नि�रीीक्षक,
वैैधमाापनशाास्त्र

जि�ल्हाा उप नि�यंंत्रक,
वैैधमाापनशाास्त्र

प्रा देेशि�क
सह नि�यंंत्रक,
वैैधमाापनशाास्त्र

१६.

वैैधमाापनशाास्त्र
अधि�नि�यम,
२००९ अंंतर्गगत
वजन वाा माापेे
यांं�चीी पडतााळणीी
व मुुद्रां�कन करून
प्रमााणपत्र देेणेे.

काार्याा�लयााच्याा बााहेेर ३० दि�वस

सहाायक नि�यंंत्रक/
नि�रीीक्षक,
वैैधमाापनशाास्त्र

जि�ल्हाा उप नि�यंंत्रक,
वैैधमाापनशाास्त्र

प्रा देेशि�क
सह नि�यंंत्रक,
वैैधमाापनशाास्त्र

महाारााष्ट्रााचेे रााज्यपााल यांं�च्याा आदेेशाानुुसाार व नाावाानेे,
जयश्रीी भोोज,
शाासनााचेे सचि�व.

भााग चाार-ब-१८–२अ

<!-- page 6 -->

6

महाारााष्ट्र शाासन रााजपत्र असााधाारण भााग चाार-ब, ¨जाानेेवाारीी १५, २०२५/पौौष २५, शकेे १९४६
FOOD, CIVIL SUPPLIES AND CONSUMER PROTECTION DEPARTMENT
Mantralaya, Madam Cama Marg, Hutatma Rajguru Chowk,
Mumbai 400 032, dated the 13th January 2025.
NOTIFICATION

Maharashtra Right to Public Services Act, 2015.
No. Misc. 1014/C.R.-176(Part-2)/CS-12.– In exercise of the powers conferred by sub-section
(1) of section 3 of the Maharashtra Right to Public Services Act, 2015 (Mah. XXXI of 2015), and
in supersession of the Government Notification, Food, Civil Supplies and Consumer Protection
Department, No. Misc. 1014/C.R.-176(Part-1)/CS-12, dated the 24th June 2024, issued in this behalf
specifically with respect to the public services regarding Legal Metrology, the Food, Civil Supplies
and Consumer Protection Department, hereby, notifies the public services specified in column (2)
of the Schedule appended hereto, to be rendered to the eligible persons by the officers sub-ordinate
to Controller, Legal Metrology, Legal Metrology Organization under the Food, Civil Supplies and
Consumer Protection Department, alongwith the stipulated time limit for providing such public
services, the Designated Officers, First Appellate Authorities and Second Appellate Authorities, as
specified in columns (3), (4), (5) and (6), respectively, of the said Schedule, for the purposes of the
said Act.
Schedule

Sr.
No.

Name of Public
Service

Time limit
for providing
Service
(working days )

Designated Officer
by whom services
will be provided

First Appellate
Authority

Second Appellate
Authority

(1)

(2)

(3)

(4)

(5)

(6)

1

Issue
License for
Manufacturer
of Weight or
Measure

35 Days

Controller of Legal
Metrology

Joint Secretary /
Deputy Secretary
F.C.S.& C.P.D

Principal Secretary
/Secretary F.C.S.&
C.P.D

2

Renewal of
Weight or
Measure
Manufacturer
License

Auto Renewal

Controller of Legal
Metrology

Joint Secretary /
Deputy Secretary
F.C.S.& C.P.D

Principal Secretary
/Secretary F.C.S.&
C.P.D

3

Amendment
in Weight
or Measure
Manufacturer
License

35 Days

Controller of Legal
Metrology

Joint Secretary /
Deputy Secretary
F.C.S.& C.P.D

Principal Secretary
/Secretary F.C.S.&
C.P.D

4

Issue License
for Weight
or Measure
Repairing

35 Days

(1) Controller of
Legal Metrology

(1) Joint Secretary
/Deputy Secretary
F.C.S.& C.P.D

(2) Regional Joint
Controller of Legal
Metrology

(2) Controller of
Legal Metrology

(1)Principal
Secretary/Secretary
F.C.S.& C.P.D
(2) Joint Secretary /
Deputy Secretary
F.C.S.& C.P.D

<!-- page 7 -->

7

महाारााष्ट्र शाासन रााजपत्र असााधाारण भााग चाार-ब, ¨जाानेेवाारीी १५, २०२५/पौौष २५, शकेे १९४६
Sr.
No.

Name of Public
Service

Time limit
for providing
Service
(working days )

Designated Officer
by whom services
will be provided

First Appellate
Authority

Second Appellate
Authority

(1)

(2)

(3)

(4)

(5)

(6)

5

Renewal of
Weight or
Measure
Repairer
License

(1) Controller of
Legal Metrology

(1) Joint Secretary
/Deputy Secretary
F.C.S.& C.P.D

(1) Principal
Secretary/Secretary
F.C.S.& C.P.D

(2) Regional Joint
Controller of Legal
Metrology

(2) Controller of
Legal Metrology

(2) Joint Secretary /
Deputy Secretary
F.C.S.& C.P.D

(3) District Deputy
Controller of Legal
Metrology

(3) Regional Joint
Controller of Legal
Metrology

(3) Controller of
Legal Metrology

(1) Controller of
Legal Metrology

(1) Joint Secretary
/Deputy Secretary
F.C.S.& C.P.D

(1) Principal
Secretary/Secretary
F.C.S.& C.P.D

(2) Regional Joint
Controller of Legal
Metrology

(2) Controller of
Legal Metrology

(2) Joint Secretary /
Deputy Secretary
F.C.S.& C.P.D

(1) Controller of
Legal Metrology

(1)Joint Secretary / (1) Principal
Deputy Secretary
Secretary/Secretary
F.C.S.& C.P.D
F.C.S.& C.P.D

(2) Regional Joint
Controller of Legal
Metrology

(2)Controller of
Legal Metrology

(2)Joint Secretary/
Deputy Secretary
F.C.S.& C.P.D

(3) District Deputy
Controller of Legal
Metrology

(3) Regional Joint
Controller of Legal
Metrology

(3) Controller of
Legal Metrology

(1) Controller of
Legal Metrology

(1) Joint Secretary
/Deputy Secretary
F.C.S.& C.P.D

(1) Principal
Secretary/Secretary
F.C.S.& C.P.D

(2) Regional Joint
Controller of Legal
Metrology

(2) Controller of
Legal Metrology

(2) Joint Secretary/
Deputy Secretary
F.C.S.& C.P.D

(3) District Deputy
Controller of Legal
Metrology

(3) Regional Joint
Controller of Legal
Metrology

(3) Controller of
Legal Metrology

6

7

8

Auto Renewal

Amendment
in Weight
or Measure
Repairer
License

35 Days

Issue License
as Dealer of
Weight or
Measure

35 days

Renewal of
Weight or
Measure Dealer
License

Auto Renewal

<!-- page 8 -->

8

महाारााष्ट्र शाासन रााजपत्र असााधाारण भााग चाार-ब, ¨जाानेेवाारीी १५, २०२५/पौौष २५, शकेे १९४६
Sr.
No.

Name of Public
Service

Time limit
for providing
Service
(working days )

Designated Officer
by whom services
will be provided

First Appellate
Authority

Second Appellate
Authority

(1)

(2)

(3)

(4)

(5)

(6)

9

Amendment
in Weight or
Measure Dealer
License

(1) Controller of
Legal Metrology

(1) Joint Secretary
/Deputy Secretary
F.C.S.& C.P.D

(1) Principal
Secretary/Secretary
F.C.S.& C.P.D.

(2) Regional Joint
Controller of Legal
Metrology

(2) Controller of
Legal Metrology

(2) Joint Secretary/
Deputy Secretary
F.C.S.& C.P.D

(3) District Deputy
Controller of Legal
Metrology

(3) Regional Joint
Controller of Legal
Metrology

(3) Controller of
Legal Metrology

35 Days

10.

Issue
Registration as
Manufacturer/
packer of
packaged
Commodities
under Legal
Metrology
(packaged
Commodities)
Rules, 2011

25 Days

Controller of Legal
Metrology

Joint Secretary /
Deputy Secretary
F.C.S.& C.P.D

Principal Secretary
/Secretary F.C.S.&
C.P.D

11

Amendment in
Registration as
Manufacturer/
Packer of
packaged
commodities
under Legal
Metrology
(packaged
Commodities)
Rules, 2011

25 Days

Controller of Legal
Metrology

Joint Secretary /
Deputy Secretary
F.C.S.& C.P.D

Principal Secretary
/Secretary F.C.S.&
C.P.D

12

Issue
Registration
as Importer
of packaged
Commodities
under Legal
Metrology
(packaged
Commodities)
Rules, 2011

25 Days

Controller of Legal
Metrology

Joint Secretary /
Deputy Secretary
F.C.S.& C.P.D

Principal Secretary
/Secretary F.C.S.&
C.P.D

<!-- page 9 -->

9

महाारााष्ट्र शाासन रााजपत्र असााधाारण भााग चाार-ब, ¨जाानेेवाारीी १५, २०२५/पौौष २५, शकेे १९४६
Sr.
No.

Name of Public
Service

Time limit
for providing
Service
(working days )

Designated Officer
by whom services
will be provided

First Appellate
Authority

Second Appellate
Authority

(1)

(2)

(3)

(4)

(5)

(6)

13

Amendment in
Registration
as Importer
of Packaged
Commodities
under Legal
Metrology
(packaged
Commodities)
Rules, 2011

25 Days

Controller of Legal
Metrology

Joint Secretary /
Deputy Secretary
F.C.S.& C.P.D

Principal Secretary
/Secretary F.C.S.&
C.P.D

14

Registration
Certificate of
Nomination

25 Days

Controller of
Legal Metrology

Joint Secretary /
Deputy Secretary
F.C.S.& C.P.D

Principal Secretary
/Secretary F.C.S.&
C.P.D

15

Issue Certificate In the office
after verification 5 Days
and stamping
of Weight or
Measure under
Legal Metrology
Act, 2009.

Assistant Controller/ District Deputy
Inspector of Legal
Controller of Legal
Metrology
Metrology

Regional Joint
Controller of Legal
Metrology

16

Issue Certificate Outside the
after verification office 30 Days
and stamping
of Weight or
Measure under
Legal Metrology
Act, 2009.

Assistant Controller/ District Deputy
Inspector of Legal
Controller of Legal
Metrology
Metrology

Regional Joint
Controller of Legal
Metrology

By order and in the name of the Governor of Maharashtra,

JAYASHREE BHOJ,
Secretary to Government.

ON BEHALF OF GOVERNMENT PRINTING, STATIONERY AND PUBLICATION, PRINTED AND PUBLISHED BY DIRECTOR,
RUPENDRA DINESH MORE, PRINTED AT GOVERNMENT CENTRAL PRESS, 21-A, NETAJI SUBHASH ROAD, CHARNI ROAD,
MUMBAI 400 004 AND PUBLISHED AT DIRECTORATE OF GOVERNMENT PRINTING, STATIONERY AND PUBLICATIONS,
21-A, NETAJI SUBHASH ROAD, CHARNI ROAD, MUMBAI 400 004. EDITOR : DIRECTOR, RUPENDRA DINESH MORE.
