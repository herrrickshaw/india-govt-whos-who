---
doc_id: "867fc5eccff3d1ec"
source_url: "https://transport.maharashtra.gov.in/Site/Upload/GR/SchoolBusFinalRulesGazette16072026.pdf"
ministry: "Motor Vehicles Department ( R.T.O.), Maharashtra"
title: "महाराष्ट्र मोटार वाहन (स्कूल बसकरिता विनियम) (पहिली सुधारणा) नियम 2026"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "36b355aeaa6478c7"
---

<!-- page 1 -->

RNI No. MAHBIL /2009/31733

महाराष्ट्रõ शासन राजपत्र
असाधारण भाग चार-अ

वर्षष १२, अंंक ९१ (३)]

गुुरुवाार, जुुलैै १६, २०२६/आषााढ २५, शकेे १९४८

[पृृष्ठेे ४, किं�ंमत : रुपयेे १५.००

असााधाारण क्रमांं�क ३०९

प्राधिकृत प्रकाशन
महाराष्ट्र शासनाने केेंद्रीय अधिनियमांन््वये तयार केलेले
(भाग एक, एक-अ आणि एक-ल यांमध््यये प्रसिद्ध केलेले नियम व आदेश यांव््यतिरिक््त) नियम व आदेश.
HOME (TRANSPORT) DEPARTMENT
Mantralaya, Madam Cama Marg, Hutatma Rajguru Chowk
Mumbai 400 032, dated 16th July 2026.
NOTIFICATION
Motor Vehicle Act, 1988.
No. MVR-0625/C.R. 347/Tra-2.—In exercise of the powers conferred by clause (xxxiii) of subsection (2) of section 96, sections 111 and 117 read with section 67 of the Motor Vehicles Act, 1988
(59 of 1988) and of all other powers enabling it in this behalf, the Government of Maharashtra
hereby makes the following rules further to amend the Maharashtra Motor Vehicles (Regulations
for School Buses) Rules, 2011, the same having been previously published as required by sub-section
(1) of section 212 of the said Act namely :—
RULES
1. These rules may be called the Maharashtra Motor Vehicles (Regulations for School Buses)
(First Amendment) Rules, 2026.
2. In rule 5 of the Maharashtra Motor Vehicles (Regulations for School Buses) Rules, 2011,
(hereinafter referred to as “the principal Rules”), after sub-rule (2), the following sub-rule shall be
added, namely :—
“(3) The School Transport Committee shall,–
(a) verify that the fare rates for school transport vehicles are in accordance with the
fare schedule specified by the Regional Transport Authority, from time to time ;
(b) address and resolve grievances of parents relating to school transport services,
safety and the fare ;
(c) submit quarterly compliance reports relating to school transport services, safety
and fare matters to the District School Bus Safety Committee.”.
3. After rule 6 of the principal rules, the following rules shall be added, namely :—

भााग चाार-अ-३०९–१

(१)

<!-- page 2 -->

2

महाारााष्ट्र शाासन रााजपत्र असााधाारण भााग चाार-अ, जुुलैै १६, २०२६/आषााढ २५, शकेे १९४८

“6A. Regulation of Fare.–
(1) The Regional Transport Authority shall fix the base fare per kilometre per student
for school bus, education institution bus and school van after considering directions issued by
the State Government under section 67 of the Act, from time to time.
(2) The fare collected on monthly or quarterly basis shall not be less than ten per cent. or
more than ten per cent. of that of the fare fixed by the Regional Transport Authority.
6B. Appointment and records of school transport staff.–
(1) The transport operator and school management shall ensure that every driver, lady
attendant or any other person designated as transport staff is duly appointed in writing by
the owner or school authority, in case bus owned by school after due background verification
and medical fitness certification and is issued an official appointment letter.
(2) The school management and school bus operator shall maintain complete records of
all transport staff, including verification reports, appointment letters or documents, training
records, and medical fitness certificates, and such records shall be made available on demand
for inspection by the Regional Transport Officers and Police.
6C. Attendance record and supervision of students using school transport.–
(1) Every school and bus or van operator shall maintain a daily attendance record of
every student using school bus, education institution bus or school van, including the time of
boarding and de-boarding of the vehicle.
(2) For the students of Pre-primary and Primary classes (up to Standard five) additional
supervision shall be provided on every trip by a lady attendant or any other designated staff.
6D. Safety and support for children with disabilities or special needs.–
(1) The school management and the transport operator shall ensure that children with
disabilities or special needs are provided with appropriate support, including the appointment
of a trained attendant, accessibility features in school bus, education institution bus and school
van and where necessary the presence of a parent or attendant during transit. The accessibility
features shall be examined during annual vehicle fitness checks if required.
(2) The presence of a teacher, counsellor, or parent during the transit may be arranged
wherever necessary.”
4. In rule 10 of the principal rules,–
(i) in sub-rule (iii),–
(a) for the figures and words “15 years” the words “twenty years” shall be substituted;
(b) third proviso shall be deleted.
(ii) after sub-rule (xxviii), the following sub-rule shall be added, namely :–
“(xxix) For additional safety requirements all school bus, education institution bus
and all school van shall,–
(a) install a Vehicle Location Tracking Device (VLTD) with panic button, conforming
to the specifications not inferior to the Automotive Industry Standards (AIS)-140 specified
by the Central Government ;
(b) install a Fire Detection and Alarm System (FDAS) in accordance with the
Automotive Industry Standards (AIS)-135 specified by the Central Government or fireball
of minimum 1 kg of ABC class each be fixed in engine compartment and near emergency
exit ;
(c) provide seat belts to all the seats.”

<!-- page 3 -->

महाारााष्ट्र शाासन रााजपत्र असााधाारण भााग चाार-अ, जुुलैै १६, २०२६/आषााढ २५, शकेे १९४८

3

5. After rule 10 of the principal rules, the following rule shall be added, namely :–
“10A. Digital safety compliance for school transport vehicles.–
(1) Every school bus or educational institution bus or school van shall be equipped with
a Digital Safety Monitoring System for the purpose of enhancing the safety of students and
ensuring realtime traceability.
(2) The Digital Safety Monitoring System shall have the following features conforming
to the specifications not inferior to the Automotive Industry Standards (AIS)-004, (AIS)-140
specified by the Central Government and having ARAI or ICAT aproval namely :–
(a) installing a vehicle location tracking device ;
(b) integration with the State-level monitoring platform ;
(c) installing a closed-circuit television or video surveillance systems ;
(d) use of any certified mobile or web-based application providing live vehicle tracking,
digital attendance, automated alerts, and role-based access to parents, school authorities,
and enforcement agencies ;
(e) use any other advanced technology approved by the Transport Department.”.
(f) A feed of the CCTV footage should be made available to parents through mobile
app and when required to RTO officials or education department or police department:
Provided that a back up of footage of minimum of thirty days shall be kept by owner or school
authority if it’s the owner of the school bus.
6. For rule 11 of the principal rules, the following rules shall be substituted, namely :–
“11. Approval of vehicles models as educational institution bus, school bus and school van.The vehicles compliant with Automotive Industry Standards AIS-204, AIS-063, AIS-052, or their
corresponding or successor standards, as may be specified by the Central Government, from time
to time.
11A. Inspection of school transport arrangements.–
(1) Regular inspections of school transport arrangements shall be conducted jointly
by officers of the School Education Department and the Transport Department.
(2) The report of every such joint inspection shall be submitted to the District School
Bus Safety Committee and shall form part of the compliance records of the school.
11B. Compliance with additional safety instructions. - The school management shall
comply with all safety instructions issued by the Government, from time to time, which includes
instructions relating to,–
(a) requirements of regular training for drivers, attendants or any other staff ;
(b) awareness programmes for parents and students ;
(c) special care and safeguards for vulnerable students ; and
(d) any other measure considered necessary for ensuring the safety of children.
11C. Transitional provisions and retrofitting.–
(1) All educational institution buses, school buses or school vans shall comply
with Maharashtra Motor Vehicles (Regulations for School Buses) (First Amendment)
Rules, 2026 shall be brought into compliance with the provisions of these rules and the
specifications notified thereunder within a period of three months from the date of its
publication in the Official Gazette.
(2) Failure to comply within the period specified in sub-rule (1) shall render the
permit liable to suspension or cancellation, in accordance with the provisions of the Act
and rules framed thereunder.”.

<!-- page 4 -->

4

महाारााष्ट्र शाासन रााजपत्र असााधाारण भााग चाार-अ, जुुलैै १६, २०२६/आषााढ २५, शकेे १९४८

7. In the FORM P.Co.S (Rule 7 (B)) appended to the principal rules, for point at Serial No. 7
the following shall be susbstituted, namely :—
“7. I/We are enclosing a copy of common standard agreement contract with the school or
parents and list of the children proposed to be transported by the Motor Vehicle No. .................”.

By order and in the name of the Governor of Maharashtra,

CHETAN NIKAM,
Deputy Secretary to Government.

ON BEHALF OF GOVERNMENT PRINTING, STATIONERY AND PUBLICATION, PRINTED AND PUBLISHED BY DIRECTOR,
SMT. MANISHA KUMBHAR, PRINTED AT GOVERNMENT CENTRAL PRESS, 21-A, NETAJI SUBHASH ROAD, CHARNI ROAD,
MUMBAI 400 004 AND PUBLISHED AT DIRECTORATE OF GOVERNMENT PRINTING, STATIONERY AND PUBLICATIONS,
21-A, NETAJI SUBHASH ROAD, CHARNI ROAD, MUMBAI 400 004. EDITOR : DIRECTOR, SMT. MANISHA KUMBHAR.
