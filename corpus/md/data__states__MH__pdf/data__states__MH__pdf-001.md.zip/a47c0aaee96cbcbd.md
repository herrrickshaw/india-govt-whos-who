---
doc_id: "a47c0aaee96cbcbd"
source_url: "https://fssai.gov.in/upload/uploadfiles/files/Gazette_Notification_NonSpecified_Food_Ingredients_15_09_2017.pdf"
ministry: "Food and Drug Administration, Maharashtra"
title: "Food Safety and Standards (Approval for Non-Specific Food and Food Ingredients) Regulation, 2017"
date: ""
pages: 14
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "a331fd988be98bf8"
---

<!-- page 1 -->

Press Note
Food Safety and Standards (Approval of non-specified food and food
ingredients) Regulations, 2017
FSSAI has notified final regulations on Food Safety and Standards
(Approval of non-specified food and food ingredients) Regulations, 2017. This
regulation lays down the rules and procedure for grant of prior approval of nonspecified food and food ingredients.
2.

After implementation of the Act and the Regulations framed thereunder with

effect from 5th August 2011, and the fact that safety assessment and approval for the
non-standardised food was a new concept, the FSSAI introduced a product approval
system through advisories as a means to undertake safety assessment of the food
products and products containing ingredients which do not have standards.
3.

However, in view of the Hon’ble Supreme Court order vide dated

19.08.2015; it was no longer possible to continue the process of product approvals
for non-standardized food products/ingredients in the absence of legitimate
regulations.
4.

In order to address the situation arising after discontinuation of the product

approval system, FSSAI has revised the definition of proprietary foods in Food Safety and
Standards (Food Product Standards and Food Additives) Ninth Amendment Regulations,
2016. Further, FSSAI also notified the Food safety and Standards (Food or Health
supplements, Nutraceuticals, Foods for special dietary uses, Foods for medical purposes,
Functional foods and Novel foods) Regulations, 2016 and Food Safety and Standards (Food
Product Standards and Food Additives) Seventh Amendment Regulations, 2016 relating to
Harmonization of Food additives. With these developments, a larger number of products,
that would have otherwise required specific approvals from Food Authority, got covered.
5.

However, there are several food products/ingredients which are still not covered in

any of the regulations made under Food Safety and Standards Act, 2006. In order to regulate

<!-- page 2 -->

such products including novel food and provide the opportunity to Food Business Operators
to innovate food products, FSSAI came up with this regulation. The regulation covers the
following articles of food or food ingredients:
1. Novel food or novel food Ingredients or processed with the use of novel technology
2. New additives
3. New processing aids including enzymes
4. Articles of food and food ingredients consisting of or isolated from microorganisms,
bacteria, yeast, fungi or algae.

6.

These regulations have been finalised after consideration of the comments received

from the stakeholders in this respect and shall immediately come in to force on the date of
notification in the Official gazette of India.

<!-- page 3 -->

REGD. NO. D. L.-33004/99

EXTRAORDINARY
III—
PART III—Section 4
PUBLISHED BY AUTHORITY
354]
No. 354]

NEW DELHI, WEDNESDAY, SEPTEMBER 13, 2017/BHADRA 22, 1939

स्‍वास्‍्य‍एवं‍परिवाि‍कल्‍याण म‍तंराला य‍
(भाितीय‍खाद्य‍सुिक्षा‍औि‍तानक‍प्राधिकिण म)

अधिसूचना
नई‍दिल्‍ ी,‍11 धसतम्‍बि,‍2017
फा.‍ सं.‍ 12/पी.ए.‍ धवधनयत/डीआईआि(पीए)/एफ़एसएसएआई-2016.—खाद्य‍ सुिक्षा‍ औि‍ तानक‍ (गैि-धवधनर्ििष्ट‍
खाद्य‍ औि‍ खाद्य‍ संघटकों‍ के ‍ ध ए‍ अनुतोिन)‍ धवधनयत, 2017,‍ का‍ प्रारूप‍ खाद्य‍ सुिक्षा‍ औि‍ तानक‍ अधिधनयत,‍ 2006‍
(2006 का‍34)‍की‍िािा‍(1)‍की‍धपिािा‍92‍की‍अपेक्षानुसाि‍भाितीय‍खाद्य‍सुिक्षा‍औि‍तानक‍प्राधिकिण म‍की‍अधिसूचना‍
फा.‍सं.‍12/पी.ए.‍धवधनयत/डीआईआि(पीए)/एफ़एसएसएआई-2016,‍तािीख‍31‍जनविी,‍2017,‍द्वािा‍भाित‍के ‍िाजपराल‍
असािािण म, भाग‍III, खंड 4,‍तें‍ प्रकाधित‍दकया‍गया‍था‍धजसतें‍ धन‍व्यधियों‍से‍ धजनके ‍धससे‍ प्रभाधवत‍होने‍ की‍संभावना‍
थी,‍ धस‍ तािीख से धजसको‍ धि‍ अधिसूचना‍ वा े‍ िाजपराल‍ की‍ प्रधतयााँ‍ जनता‍ को‍ धप ब्ि‍ किा‍ िी‍ गयी‍ थी,‍ तीस‍ दिन‍ की‍
अवधि‍की‍सताधि‍के ‍पूवि‍आक्षेप‍औि‍सुझाव‍आतंधरालत दकए गए थे;
औि‍धि‍िाजपराल‍की‍प्रधतयााँ‍जनता‍को‍9‍फिविी,‍2017‍को‍धप ब्ि‍किा‍िी‍गई‍थीं;
औि‍भाितीय‍खाद्य‍सुिक्षा‍औि‍तानक‍प्राधिकिण म‍द्वािा‍धि‍प्रारूप‍धवधनयतों‍के ‍संबंि‍तें‍ जनता‍से‍ प्राि‍आक्षेपों‍
औि‍सुझावों‍पि‍धवचाि‍कि‍ध या‍गया‍है;‍
अतः‍अब‍धि‍अधिधनयत‍की‍िािा‍92‍की‍धप-िािा‍(2)‍के ‍खंड‍(फ)‍द्वािा‍प्रित्त िधियों का प्रयोग किते हुए,‍
भाितीय‍खाद्य सुिक्षा औि तानक‍प्राधिकिण म‍धनम्नध धखत‍धवधनयत‍बनाता‍है,‍अथाित्:—

5662 GI/2017

(1)

<!-- page 4 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC. 4]

धवधनयत‍
1.‍

संधक्षत‍नात‍औि‍प्रािं भ.—‍(1)‍इन‍धवधनयतों‍का‍संधक्षि‍नात‍‘खाद्य‍सुिक्षा‍औि‍तानक‍(गैि-धवधनर्ििष्ट‍खाद्य‍औि‍

खाद्य‍संघटकों‍के ‍ध ए‍अनुतोिन)‍धवधनयत,‍2017’‍है।‍
(2)‍
2.‍

ये‍िाजपराल‍तें‍प्रकािन‍की‍तािीख‍को‍प्रवृत्‍त‍होंगे।‍

परिभाषाएाँ.—‍(1)‍इन‍धवधनयतों‍तें‍जब‍तक‍संिभि‍तें‍अन्‍यथा‍अपेधक्षत‍न‍हो:—‍
(क)‍‍‘’अधिधनयत’’‍से‍खाद्य‍सुिक्षा‍औि‍तानक‍अधिधनयत,‍2006‍(2006‍का‍संख‍यांक‍34)‍अधभप्रेत‍है;‍
(ख)‍ ‍ ‘’अनुतोिन’’‍ से‍ अधभप्रेत‍ है‍ जो‍ तानव‍ धपभोग‍ के ‍ ध ए‍ प्रत्‍यक्ष‍ अथवा‍ अप्रत्‍यक्ष‍ रूप‍ से‍ अपेधक्षत‍ वह‍ खाद्य‍
सातग्री‍अथवा‍खाद्य‍संघटक,‍जो‍अधिधनयत‍के ‍अंतगित‍बने‍ दकसी‍अन्‍य‍धवधनयत‍के ‍अंतगित‍धवधनर्िि्‍‍ट‍न‍
हो;
(ग)‍‍‍‘’खाद्य‍प्राधिकिण म’’‍से‍ अधभप्रेत‍है‍ वह‍अधिधनयत‍की‍िािा‍4‍के ‍अंतगित‍स्‍थाधपत‍भाितीय‍खाद्य‍सुिक्षा‍औि‍‍
तानक‍प्राधिकिण म‍है;‍
(घ)‍ ‍ ‘’गैि-धवधनर्ििष्ट‍ खाद्य’’‍ से‍ अधभप्रेत‍ है‍ धजसतें‍ धनजस्वतू क‍ खाद्य‍ के ‍ अ ावा‍ वह‍ खाद्य‍ अथवा‍ खाद्य‍ संघटक‍
खाद्य‍संयोजी‍पिाथों सधहत,‍प्रसंस्‍कण म‍सहायक‍संघटक, ‍औि‍एन्‍जाइत,‍धजसके ‍ध ए‍अधिधनयत‍के ‍अंतगित‍
बने‍दकसी‍धवधनयत‍तें‍तानक‍धवधनर्िि्‍‍ट‍नहीं‍हं;
(2)‍‍‍धन‍िब्िों‍औि‍पिों‍के ‍जो‍इसतें‍प्रयुि‍हं‍औि‍परिभाधषत‍नहीं‍है‍दकन्तु‍अधिधनयत‍या‍धवधनयत‍तें‍परिभाधषत‍
हं‍अथि‍वही‍होंगे‍जो‍धन‍अधिधनयत,‍धनयत,‍धवधनयत‍तें‍सतनुिेधित‍होंगे।

3.‍

धनतािण म,‍भंडािण म,‍धबक्री,‍धवतिण म,‍आयात‍आदि‍के ‍ध ए‍पूवि‍ अनुतोिन.—‍(1)‍कोई‍व्‍यधि‍खाद्य‍प्राधिकिण म‍के ‍पूवि‍
अनुतोिन‍के ‍धसवाय‍िािा‍2‍(घ)‍तें‍ यथा‍परिभाधषत‍दकसी‍गैि-धवधनर्ििष्ट‍खाद्य‍का‍धवधनतािण म‍अथवा‍आयात‍नहीं‍
किे गा।‍
(2)‍इन‍धवधनयतों‍के ‍धपबंि‍अधिधनयत‍के ‍अिीन‍बने‍ अन्‍य‍धनयतों‍अथवा‍धवधनयतों‍के ‍अधतरि्‍‍त‍हं‍ औि‍न‍दक‍
धन्‍हें‍अल्पीकिण म‍किते‍हं।

4.‍

पूवि‍ अनुतोिन‍की‍प्रदक्रया.—‍(1)‍गैि-धवधनर्ििष्ट‍खाद्य‍का‍धवधनतािता‍अथवा‍आयातक‍खाद्य‍प्राधिकिण म‍को‍अपेधक्षत‍
िस्तावेजों‍औि‍फीस‍के ‍साथ‍इन‍धवधनयतों‍के ‍प्ररूप-1‍तें‍आवेिन‍किे गा।‍
(2)‍

खाद्य‍प्राधिकिण म‍आवेिक‍द्वािा‍दिए‍गए‍आवेिन‍औि‍सूचना‍की‍जााँच‍किे गी।‍

(3)‍

खाद्य‍प्राधिकिण म‍अधतरिि‍सतथिन‍िस्तावेज़ों,‍आंकड़े‍या‍स्पष्टीकिण म,‍यदि‍अपेधक्षत‍हो‍प्रस्तुत‍किने‍के ‍ध ए‍
आवेिक‍को‍धनिेि‍कि‍सकती‍है।‍

(4)

खाद्य‍प्राधिकिण म‍खाद्य‍वस्‍तु‍ के ‍सुिक्षात्‍तक‍धनिाि ण म‍को‍्‍‍यान‍तें‍ िखते‍ हुए‍या‍तो‍अनुतोिन‍िे‍ सकती‍है‍
अथवा‍प्ररूप-2‍तें‍धसे‍धनिस्‍त‍कि‍सकती‍है।‍

(5)

जहां‍ अनुतोिन‍ की‍ धस्थधत‍ तें‍ खाद्य‍ कािोबािी‍ खाद्य‍ प्राधिकिण म‍ को‍ धनर्तित‍ अथवा‍ आयाधतत‍ खाद्य‍ के ‍
िासायधनक,‍भौधतक,‍सूक्ष्‍त‍जैधवक‍औि‍पौषण म‍संबंिी‍तानिंडों‍के ‍धव्‍‍ ेषण म‍का‍प्रताण म-पराल‍प्रस्‍तुत‍किे गा।‍

(6)‍

खाद्य‍कािबाि‍खाद्य‍प्राधिकिण म‍के ‍अ्‍‍यक्ष‍के ‍सतक्ष‍अपने‍ आवेिन‍के ‍धनिस्‍तीकिण म‍के ‍संबंि‍तें‍ अपी ‍कि‍
सकता‍है।‍

(7)‍

खाद्य‍प्राधिकिण म‍के ‍अ्‍‍यक्ष‍के ‍धनण मिय‍से‍ व्‍यधथत‍खाद्य‍कािोबािी‍पुनिीक्षा‍याधचका‍फाइ ‍कि‍सकता‍है,‍
जो‍खाद्य‍प्राधिकिण म‍की‍बैठक‍तें‍प्रस्‍तुत‍की‍जाएगी‍औि‍धजसतें‍धस‍पि‍धवचाि‍दकया‍जाएगा।‍

(8)‍

खाद्य‍ प्राधिकिण म‍ ध धखत‍ तें‍ कािण म‍ बताकि‍ दकसी‍ खाद्य‍ कािोबािी‍ को‍ दिए‍ गए‍ दकसी‍ अनुतोिन‍ को‍
धन ंधबत‍अथवा‍िद्द‍कि‍सकती‍है।‍

<!-- page 5 -->

III

3

(9)‍

खाद्य‍प्राधिकिण म‍आवेिन‍फीस‍की‍सतय-सतय‍पि‍पुनिीक्षा‍कि‍सके गी।‍

(10)‍

यदि‍दकसी‍खाद्य‍कािोबािी‍को‍यह‍धव्‍‍वास‍किने‍ का‍कािण म‍हो‍दक‍धजस‍खाद्य‍के ‍ध ए‍अनुतोिन‍दिया‍
गया‍ है,‍ धससे‍ स्‍वास्‍्‍य‍ को‍ कोई‍ खतिा‍ है,‍ तो‍ वह‍ खाद्य‍ सुिक्षा‍ औि‍ तानक‍ (खाद्य‍ प्रत्याहवान‍ प्रदक्रया)‍
धवधनयत,‍ 2017‍ के ‍ धपबंिों‍ के ‍ अनुसाि‍ खाद्य‍ प्राधिकिण म‍ को‍ सूचना‍ िेते‍ हुए‍ धसका‍ धवधनतािण म,‍ आयात,‍
धबक्री,‍अथवा‍धवतिण म‍तुित‍प्रभाव‍से‍बंि‍कि‍िेगा‍औि‍धसे‍वापस‍तंगाने‍की‍व्‍यवस्‍था‍किे गा।‍

(11)

खाद्य‍ सुिक्षा‍ अधिकािी‍ औि‍ अधभधहत‍ अधिकािी‍ खाद्य‍ प्राधिकिण म‍ द्वािा‍ इन‍ धवधनयतों‍ के ‍ अंतगित‍
अनुतोदित‍दकसी‍धत्‍पाि‍की‍सुिक्षा‍के ‍संबंि‍तें‍प्रा‍‍त‍धिकायत‍की‍सूचना‍खाद्य‍प्राधिकिण म‍को‍तुिंत‍िेंगे।‍

(12)

खाद्य‍ कािोबािी‍ अनुतोिन‍ धत ने‍ के ‍ प्‍‍चात्‍ खाद्य‍ सुिक्षा‍ औि‍ तानक‍ (खाद्य‍ कािोबाि‍ अनुञापापन‍ औि‍
िधजस्रीकिण म)‍धवधनयत,‍2011‍तें‍धवधनर्िि्‍‍ट‍प्रदक्रया‍के ‍अनुसाि‍अनुञापापन‍के ‍ध ए‍आवेिन‍किे गा।‍
प्ररूप-1
{धवधनयत‍4‍का‍धप-धवधनयत‍(1)‍िेखें}

गैि-धवधनर्िि्‍‍ट‍खाद्य‍औि‍खाद्य‍संघटक‍के ‍अनुतोिन‍के ‍ध ए‍आवेिन‍
1.‍आवेिन‍दकसके ‍ध ए‍है‍{कृ पया‍सही‍का‍ गाएाँ }

o नव‍खाद्य‍अथवा‍नव‍खाद्य‍संघटक‍अथवा‍नव‍प्रौद्योधगकी‍से‍प्रसंस्‍कृत‍
o नए‍खाद्य‍संयोजी‍पिाथि‍
o एन्‍जाइतों‍सधहत‍नई‍प्रसंस्‍किण म‍सहायक‍सातग्री
o सूक्ष्‍त‍जीवाण मुं,‍बै्‍‍टीरिया,‍खतीि,‍कवक‍अथवा‍एल्‍गी‍से‍यु्‍‍त‍अथवा‍पृथ्‍‍कृत‍खाद्य‍वस्‍तुएाँ‍औि‍खाद्य‍संघटक‍
o अन्‍य‍कोई‍गैि-धनर्िि्‍‍ट‍खाद्य,‍कृ पया‍धवधनर्ििष्ट‍किें‍
2.‍सािािण म‍सूचना‍
‍‍(1)‍आवेिक‍का‍नात‍

(1) ‍‍प्राधिकृ त‍व्‍यधि‍का‍नात‍
(2) ‍‍तोबाइ ‍नं०/फोन‍नं०
(3) ‍‍ई-ते ‍
‍‍(सभी‍प्रकाि‍का‍पराल-व्‍यहाि‍के व ‍धपयुि्‍‍त‍ई-ते ‍अथवा‍फोन‍नंबि‍पि‍दकया‍जाएगा)‍

(4) ‍‍संगठन‍का‍नात‍
(5) ‍‍संगठन/िधजस्रीकिण म‍कायाि य‍का‍पता‍
(6) ‍‍अनुञापधि‍संख‍या,‍यदि‍कोई‍हो‍
(7) ‍‍कािबाि‍की‍प्रकृ धत
(8) ‍‍खाद्य‍ धत्‍पाि/संघटक/संयोजी‍ पिाथि/एन्‍जाइत/प्रसंस्‍किण म‍ सहायक‍ सातग्री‍ का‍ नात‍ औि‍ धन्स्वतू क‍ नात,‍ यदि‍
कोई‍हो‍

(9) ‍‍‍नात‍का‍औधचत्‍य‍
(10) ‍प्रस्‍ताधवत‍धत्‍पाि‍का‍वगि‍

<!-- page 6 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC. 4]

(11) ‍खाद्य‍संघटक(कों)‍का‍स्रोत‍(पिु,‍िसायन,‍वनस्‍पधत‍अथवा‍सूक्ष्‍त‍जीव)‍
(12) ‍स्रोत‍पिु,‍वनस्‍पधत‍अथवा‍सूक्ष्‍त‍जीव‍होने‍की‍धस्थधत‍तें‍जीवाण मु‍का‍वंि‍औि‍प्रजाधत‍बताई‍जाए‍
(13) ‍कृ धत्यक‍धपयोग‍
(14) ‍आिधयत‍धपयोग‍
(15) तृतीय‍ पक्ष‍ िा्‍‍रीय‍ प्रयोगिा ा‍ प्रत्‍यायन‍ बोडि‍ (एन.ए.बी.ए )‍ अथवा‍ इं टिनैिन ‍ ैबोिे टिीज‍ एदक्रधडटेिन‍
कोऑपिे िन‍ (आई.ए .ए.सी)‍ द्वािा‍ तान्‍य‍ प्रयोगिा ां‍ से‍ धव्‍‍ ेषण म‍ का‍ प्रताण म-पराल‍ प्रस्‍तुत‍ किना‍ होगा।‍
धव्‍‍ ेषण म‍के ‍प्रताण म-पराल‍तें‍ धत्‍पाि‍के ‍कु संगत‍भौधतक,‍िासायधनक‍औि‍जैव‍वैञापाधनक‍तानिंड‍िाधत ‍होंगे।‍साथ‍
ही‍धसतें‍तान्‍य‍पिीक्षण म‍प्धतधत‍औि‍अन्‍य‍पिीक्षण म‍प्धतधतयााँ‍संिभों‍सधहत,‍जहााँ‍कहीं‍ ागू‍हों,‍िाधत ‍होंगी।‍

(16) ‍धवधनतािण म‍प्रदक्रया,‍संधक्ष‍‍त‍तें
(17) ‍धवधनयात्‍तक‍प्राधस्थधत‍
‍‍(धन‍िेिों‍के ‍नात‍धल् ेख‍किें ,‍जहााँ‍ धत्‍पाि‍का‍खाद्य‍के ‍रूप‍तें‍ प्रत्‍यक्ष‍अथवा‍अप्रत्‍यक्ष‍रूप‍से‍ धपयोग‍अनुञापा‍है।‍
यदि‍ हााँ,‍ तो‍ धपभो्‍‍तां‍ द्वािा‍ धसके ‍ धपभोग‍ का‍ स्‍ति‍ औि‍ प्रयोजन‍ तथा‍ िस्तावेजी‍ साक्षय‍ सधहत‍ संबंधित‍
धवधनयत‍बताएाँ)‍

(18) ‍प्रस्‍ताधवत‍ धत्‍पाि‍ के ‍ खाद्य‍ कािबाि‍ तें‍ िाधत ‍ आवेिक‍ औि‍ धनतािता‍ औि‍ अन्‍य‍ पक्षों‍ अथाित्‍ धवपण मनकताि,‍
आयातक,‍पुनःपैकि‍के ‍त्‍‍य‍संबंिों‍का‍किाि।‍

(19) ‍सुिक्षा‍संबंिी‍सूचना‍(जोधखत‍धनिाि ण म‍अथवा‍आधवषा ुता‍संबंिी‍अि्‍ययन)‍
(क)

यह‍ सूचना‍ आवेिक‍ द्वािा‍ आवेिन‍ तें‍ िाधत ‍ खाद्य‍ धत्‍पाि‍ औि‍ संघटक‍ के ‍ बािे ‍ तें‍ प्रकाधित‍ अ्‍‍ययनों‍
अथवा‍धन‍पि‍दकए‍गए‍सुिक्षात्‍तक‍अ्‍‍ययनों‍के ‍सुिक्षा‍धनिाि ण म‍की‍पुनिीक्षा‍पि‍आिारित‍हो।‍

(ख)

यह‍ धस्धत‍ किने‍ के ‍ ध ए‍ साक्ष्‍य‍ प्रस्‍तुत‍ किें ‍ दक‍ प्रस्‍ताधवत‍ धत्‍पाि‍ अथवा‍ संघटक‍ से‍ दकसी‍ वगि‍ धविेष‍ के ‍
व्‍यधियों‍ यथा‍ गभिवती‍ तधह ां,‍ िूि‍ धप ाने‍ वा ी‍ तातां,‍ बा कों,‍ बूढों‍ अथवा‍ प्रभाधवत‍ हो‍ सकने‍
वा े‍अन्‍य‍दकसी‍सतूह‍को‍प्रधतकू ‍रूप‍से‍प्रभाधवत‍नहीं‍किे गा।‍

3.‍अधतरि्‍‍त‍धवधि्‍‍ट‍सूचना:—‍
(क)‍‍नव‍खाद्य‍अथवा‍नव‍खाद्य‍संघटक‍अथवा‍नव‍प्रौद्योधगकी‍के ‍धपयोग‍से‍प्रसंस्‍कृत‍खाद्य‍
(1)‍ध्‍‍त‍प्रस्‍ताधवत‍खाद्य‍के ‍ध ए‍ धक्षत‍सतूह,‍यदि‍कोई‍हो‍
(2)‍धत्‍पाि‍का‍धवस्‍तृत‍संघटन‍(धजसतें‍धत्‍पाि‍तें‍िाधत ‍संघटकों‍औि‍संयोजी‍पिाथों‍की‍ताराला‍भी‍बताई‍जाए)‍
कोई‍नया/नए‍संघटक‍(कृ पया‍बताएाँ‍दक‍्‍‍या‍धत्‍पाि‍तें‍ेसे‍एक‍या‍अधिक‍संघटक‍हं,‍जो‍वतितान‍तें‍खाद्य‍सुिक्षा‍
औि‍तानक‍धवधनयत‍तें‍िाधत ‍नहीं‍हं‍‍अथवा‍धजसका/धजनका‍धपयोग‍भाित‍तें‍पह ी‍बाि‍प्रस्‍ताधवत‍हो)‍
(3)‍‍नव‍तकनीकी‍के ‍ब्यौिे
(4)‍‍सुिक्षा‍संबंिी‍सूचना‍‍(कृ पया‍धनिाि ण म‍धनिाि ण म‍अथवा‍आधवषा ुता‍अि्‍ययनों‍संबंिी‍प्र ेख‍सं ग्‍न‍किें )‍
(क)‍तानव‍अ्‍‍ययन‍संबंिी‍सूचना,‍धजसतें‍ धपभो्‍‍ता‍पि‍आहािीय‍प्रभाव,‍पौषधण मक‍प्रभाव‍औि‍संभावी‍प्रभाव,‍
यदि‍कोई‍हों,‍िाधत ‍हों‍
(ख)‍आधवषा ुता‍संबंिी‍अ्‍‍ययन,‍धजसतें‍ म्‍यूटाजेनेधसटी‍की‍जााँच‍के ‍ध ए‍ेतीज‍पिीक्षा‍के ‍परिण मात,‍क्रोतोसोत‍
एबीिे िन‍ पिीक्षण म,‍ पुनजिनन‍ के ‍ ध ए‍ आधवषा ुता‍ अ्‍‍ययन,‍ प्रसव-पूवि‍ धवकास‍ के ‍ ध ए‍ आधवषा ुता‍
अ्‍‍ययन‍िाधत ‍हों।‍

<!-- page 7 -->

III

5

(ग)‍‍ए जीकािकता‍(ए जीकािकता‍अथवा‍तानव‍पि‍खाद्य‍धपभोग‍से‍जुड़े‍अन्‍य‍प्रधतकू ‍प्रभावों‍पि‍प्रकाधित‍
अथवा‍अप्रकाधित‍रिपोटें;‍इनतें‍ धव्‍‍व‍स्‍वास्‍्‍य‍संगठन‍अथवा‍खाद्य‍सुिक्षा‍अथवा‍जन‍स्‍वास्‍्‍य‍के ‍कायि‍ तें‍
ित‍दकसी‍अन्‍य‍िा्‍‍रीय‍अथवा‍अंतिाि्‍‍रीय‍अधभकिण मों‍द्वािा‍तैयाि‍रिपोटें‍िाधत ‍हो‍सकती‍हं)‍
(5)‍खाद्य‍धत्‍पाि/खाद्य‍संघटक‍के ‍धपभोग‍का‍इधतहास‍(सहायक‍िस्तावेजों‍को‍प्रस्‍तुत‍किें )‍
(क)‍

धपयोग‍का‍भौगोध क‍क्षेराल‍(धजसतें‍कत‍से‍कत‍िो‍िेिों‍तें‍सुिधक्षत‍धपयोग‍का‍प्रताधण मत‍इधतहास‍हो‍औि‍
जहााँ‍सुस्‍थाधपत‍धवधनयात्‍तक‍प्राधस्थधत‍हो)‍

(ख)‍

खपत‍की‍ताराला‍

(ग)

खपत‍की‍अवधि‍(वषों‍तें)‍

(ख)‍नए‍खाद्य‍संयोजी‍पिाथि:—‍
(1)‍

िासायधनक‍नात‍औि‍आई.एन.एस‍संख‍या‍

(2)

िु्धतता‍(खाद्य‍ग्रेड‍अथवा‍सतकक्ष)‍

(3)

जे.ई.सी.एफ.ए‍अथवा‍दकसी‍अन्‍य‍जोधखत‍आक न‍संस्‍था‍द्वािा‍धनर्िि्‍‍ट‍तान्‍य‍िैधनक‍धपयोग‍(ए.डी.आई)‍

(4)

खाद्य‍श्रेण मी‍तें‍धपयोग‍का‍प्रस्‍ताधवत‍स्‍ति‍

(5)‍

िं जनकतिक‍की‍धस्थधत‍तें‍(क ि‍इं डे्‍‍स‍से)‍क ि‍संख‍या‍बताएाँ,‍जहााँ‍ ागू‍हो‍

(ग)‍एन्‍जाइतों‍सधहत‍नई‍प्रसंस्‍किण म‍सहाधयकी
(1)‍

धवधनिेि‍‍

(2)

एन्‍जाइत‍दक्रयाक ाप

(3)

िु्धतता

(4)

तैयाि‍धत्‍पाि‍तें‍अवधि्‍‍ट‍सीता‍(सहाधयकी‍प्रसंस्किण म‍के ‍तात े‍तें)‍

(घ)‍

सूक्ष्‍त‍जीवाण मुं,‍बै्‍‍टीरिया,‍खतीि,‍कवक‍अथवा‍एल्‍गी‍से‍यु्‍‍त‍अथवा‍पृथ्‍‍कृत‍खाद्य‍वस्‍तुएाँ‍औि‍खाद्य‍संघटक‍

क्रत‍सं०‍
(1)

खाद्य‍(सीिे‍प्रयु्‍‍त)‍अथवा‍खाद्य‍संघटकों‍के ‍स्रोत‍के ‍रूप‍तें‍प्रयु्‍‍त‍‍सूक्ष्‍त‍जीवाण मुं‍संबंिी‍आाँकड़े‍
ताइक्रोब‍की‍प्रकृ धत‍
बै्‍‍टीरियत/खतीि/कवक/एल्‍गी‍

(2)

ताइक्रोब‍का‍नात

जाधत

प्रजाधत‍

(3)

स्रोत‍

िेिी

आयाधतत‍

(4)

स्‍थनीय‍रूप‍से‍पृथ्‍‍कृत‍होने‍पि‍

पृथ्‍‍कृत‍
िा्‍‍रीय‍कल्‍चि‍क े्‍‍िन‍सेंटि‍

हााँ

नहीं‍

संिभि‍संख‍या‍

प्राधि‍
(प्रधत)‍
प्राधि‍
(प्रधत)‍

स्‍रेन‍

{धिाहिण माथि‍ताइक्रोधबय ‍टाइप‍
कल्‍चि‍क े्‍‍िन‍एंड‍जीन‍बंक‍
(एत.टी.‍सी.सी.),‍नैिन ‍क े्‍‍िन‍
ऑफ‍डेयिी‍कल्‍चसि‍
(एन.सी.डी.सी),‍इं धडयन‍टाइप‍
कल्‍चि‍क े्‍‍िन(आई.टी.सी.सी)}‍
(5)
(6)
(7)

िा्‍‍रीय‍कल्‍चि‍क े्‍‍िन‍सेंटि‍तें‍
जता‍होने‍की‍धस्थधत‍तें
िा्‍‍रीय‍कल्‍चि‍क े्‍‍िन‍सेंटि‍से‍
ाए‍जाने‍की‍धस्थधत‍तें‍
आयाधतत‍होने‍औि‍धनजी‍स्‍ति‍पि‍
प्रथ्‍‍कृत‍होने‍की‍धस्थधत‍तें‍

कल्‍चि‍क े्‍‍िन‍सेंटि‍का‍नात‍औि‍
पता
कल्‍चि‍क े्‍‍िन‍सेंटि‍का‍नात‍औि‍
पता
तू ‍िेि
धविेिी‍संगठन/धद्योग‍का‍नात‍औि‍
पता‍

संिभि‍संख‍या‍

संिभि‍संख‍या‍

प्राधि‍
(प्रधत)‍

<!-- page 8 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

अंतिाि्‍‍रीय‍कल्‍चि‍क े्‍‍िन‍सेंटि‍

(8)

{धिाहिण माथि‍अतिीकन‍टाइप‍

[PART III—SEC. 4]

अंतिाि्‍‍रीय‍कल्‍चि‍क े्‍‍िन‍सेंटि‍
का‍नात‍औि‍पता‍

संिभि‍संख‍या‍

हााँ‍(प्रधत)‍

नहीं‍

हााँ

नहीं‍

प्राधि‍
(प्रधत)‍

कल्‍चि‍क े्‍‍िन‍सेंटि‍
(ए.टी.सी.सी),‍यूिोपीय‍टाइप‍
कल्‍चि‍क े्‍‍िन‍आगेनाइजेिंस‍
(ई.सी.सी.ओ)}‍से‍ ाए‍जाने‍की‍
(9)

(10)

धस्थधत‍तें‍
धनयाितक/धविेिी‍संस्‍था‍औि‍
भाितीय‍आयातक/‍धनतािता‍के ‍बीच‍
सातग्री‍के ‍अंतिण म‍का‍किाि‍
्‍‍या‍जीवाण मु‍के ‍जीन‍से‍कोई‍छेड़छाड़‍की‍गई‍है?

(11)
(12)
(13)

संस्‍था‍के ‍पास‍धप ब्‍ि‍जैव‍सुिक्षा‍
प्रण मा ी‍
ताइक्रोब‍की‍सुिक्षा/‍सातान्‍यत:‍
सुिधक्षत‍तान्‍य‍धस्थधत‍(ग्रास)‍
सुिक्षा‍औि‍अंत्‍य‍धपयोग‍के ‍संबंि‍तें‍ अिोहस्‍ताक्षिी‍ सत्याधपत‍ किता‍ है‍ दक‍ सभी‍ संघटक‍ धनयाितक‍ िेि‍ के ‍
धवधनतािता‍अथवा‍आयातक‍की‍
िा्‍‍रीय‍िे गु ेटि‍द्वािा‍अनुतोदित‍हं‍(िे गु ेटि/‍अधभकिण म‍का‍नात)‍अथवा‍
घोषण मा‍
वे‍सातान्‍यत:‍सुिधक्षत‍तान्‍य‍धस्थधत‍सूची‍तें‍िाधत ‍हं,‍औि‍प्रत्‍येक‍धत्‍पाि‍
तानव‍ धपभोग‍ के ‍ ध ए‍ अपेधक्षत‍ है‍ औि‍ वह‍ तू ‍ िेि‍ तें‍ धबना‍ दकसी‍
प्रधतबंि‍के ‍धबक्री‍के ‍ध ए‍धप ब्‍ि‍है।‍

रट‍‍पण म:‍‍‍‍‍(1)‍जहााँ‍आव्‍‍यक‍हो,‍‘’ ागू‍नहीं’’‍ध खें।‍
(2)‍ आवेिक‍ द्वािा‍ धप ब्‍ि‍ किाए‍ गए‍ सभी‍ आाँकड़े/प्र ेख‍ पीयि‍ पुनर्वि ोदकत‍ अंतिाि्‍‍रीय‍ जनि ों,‍ धव्‍‍व‍
स्‍वास्‍्‍य‍ संगठन‍ (डब्‍ल्‍यू.एच.ओ)‍ औि‍ खाद्य‍ औि‍ ‍ कृ धष‍ संगठन‍ (एफ.ए.ओ)‍ सधहत‍ अंतिाि्‍‍रीय‍ संस्‍थां‍ के ‍
हों।‍के व ‍संपूण मि‍अधभ ेख‍अथवा‍अ्‍‍ययन‍धप ब्‍ि‍किाया‍जाए।‍
प्ररूप-2‍
{धवधनयत‍4‍का‍धप-धवधनयत‍(4)‍िेखें}
अनुतोिन/िद्द‍
आवेिन‍संख‍या‍
आवेिन‍की‍तािीख‍‍
संगठन‍का‍नात‍
आवेिक‍का‍नात
िधजस्रीकिण म‍कायाि य‍का‍पता‍
प्राधिकृ त‍व्‍यधि‍
खाद्य‍धत्‍पाि‍का‍नात‍
धत्‍पाि‍प्रवगि
संघटन‍
संघटक

नात

खाद्य‍संयोजी‍पिाथि‍
आई.एन.एस‍सं०

सीताएाँ‍(जीएतपी)
अथवा‍धत.ग्रा/दक.ग्रा.)‍

आवेिन‍की‍प्राधस्थधत

अनुतोदित/िद्द‍

<!-- page 9 -->

III

7

1. अनुतोिन‍की‍ितें:‍
2. धनिस्‍तीकिण म‍के ‍कािण म,‍यदि‍कोई‍हो:‍

(प्राधिकृ त‍हस्‍ताक्षिकताि)‍
[धवञापापन‍III/4/असा./223/17]
पवन‍अग्रवा , तुख‍य‍कायिपा क‍अधिकािी‍

MINISTRY OF HEALTH AND FAMILY WELFARE
(Food Safety and Standards Authority of India)

NOTIFICATION
New Delhi, the 11th September, 2017
F. No. 12/PA Regulation/Dir (PA)/FSSAI-2016.—Whereas the draft of the Food Safety and
Standards (Approval for Non-Specified Food and Food Ingredients) Regulations, 2017 were published as
required under section 92 of the Food Safety and Standards Act, 2006 (34 of 2006), vide notification of the
Food Safety and Standards Authority of India number F.No. 12/PA Regulation/Dir (PA)/FSSAI-2016, dated
the 31st January, 2017, in the Gazette of India, Extraordinary, Part III, Section 4, inviting objections and
suggestions from the persons likely to be affected thereby, before the expiry of the period of thirty days from
the date on which the copies of the Gazette containing the said notification were made available to the
public;
And whereas copies of the said Gazette were made available to the public on 9th February, 2017;
And whereas objections and suggestions received from the public in respect of the said draft
regulations have been considered by the Food Safety and Standards Authority of India;
Now, therefore, in exercise of the powers conferred by clause (v) of sub- section (2) of section 92 of
the said Act, the Food Safety and Standards Authority of India hereby makes the following regulations,
namely:—
Regulations
1
Short title and commencement.― (1) These regulations may be called the ‘Food Safety and
Standards (Approval for Non-Specified Food and Food Ingredients) Regulations, 2017.’
(2) They shall come into force on the date of their publication in the Official Gazette.
2.
Definitions.―(1) In these regulations, unless the context otherwise requires: (a)

“Act” means the Food Safety and Standards Act, 2006 (34 of 2006);

(b)

“Approval” means a permission to manufacture or import any article of food or food
ingredients, intended directly or indirectly for human consumption, that has not been
specified under any other regulations made under the Act;

(c)

“Food Authority” means the Food Safety and Standards Authority of India established
under section 4 of the Act;

(d)

“Non-specified food” means any food other than proprietary food or food ingredients,
including additives, processing aids and enzymes for which standards have not been
specified in any regulation made under the Act.

(2)
The words and expressions used herein and not defined, but defined in the Act or rules or
regulations made thereunder, shall have the meaning as assigned to them in the Act, rules or
regulations.

<!-- page 10 -->

8

3.

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC. 4]

Prior approval for manufacture, storage, sale, distribution, import, etc.―(1) No person shall
manufacture or import any non-specified food or food ingredient, as the case may be, except with the
prior approval of the Food Authority.
(2) The provisions of these regulations are in addition to, and not in derogation of, any other rules or
regulations made under the Act.

4.

Procedure for grant of prior approval.―(1) The manufacturer or importer of non-specified food
shall submit an application in FORM – I of these regulations along with necessary documents and
fee to the Food Authority.
(2)

The Food Authority shall scrutinize the application and information provided by the
applicant.

(3)

The Food Authority may direct the applicant to submit additional supporting documents,
data or clarifications, if required.

(4)

The Food Authority may either grant approval or reject the application, as per FORM-II, on
the basis of the safety assessment of the article of food.

(5)

Where approval is granted, the food business operator shall submit to the Food Authority, a
certificate of analysis in respect of the chemical, physical, microbiological and nutritional
parameters of the food manufactured or imported.

(6)

The food business operator may file an appeal before the Chairperson, Food Authority
against any decision of rejection of his application.

(7)

A food business operator, who is aggrieved by the decision of the Chairperson, Food
Authority may file review petition to be placed for consideration in the meeting of the Food
Authority.

(8)

The Food Authority may, for reasons to be recorded in writing, suspend or revoke any
approval granted to any food business operator.

(9)

The Food Authority may review from time to time, the amount of fee for filing an
application.

(10)

If a food business operator has reason to believe that the food for which the approval has
been granted poses any risk to health, he shall immediately suspend the manufacture, import,
sale, or distribution of such article of food and take steps to recall the same under intimation
to Food Authority in accordance with the provisions of the Food Safety and Standards (Food
Recall) Regulations, 2017.

(11)

Food Safety Officers and Designated Officers shall immediately inform the Food Authority
of any complaint received regarding safety of any product approved by the Food Authority
under these regulations.

(12)

The food business operator shall, after grant of approval apply for license as per the
procedure specified in the Food Safety and Standards (Licensing and Registration of Food
Businesses) Regulations, 2011.
FORM – I
(See sub-regulation (1) of regulation 4)

(Application for approval of non-specified food and food ingredient)
1. Application for (Please tick √):-

o Novel food or novel food Ingredients or processed with the use of novel technology
o New additives
o New processing aids including enzymes

<!-- page 11 -->

III

9

o Articles of food and food ingredients consisting of or isolated from microorganisms,
bacteria, yeast, fungi or algae
o Any other non-specified food, please specify
2. General information:—
(1)

Name of the applicant

(2)

Name of the authorised person

(3)

Mobile No. / Phone No.

(4)

E-mail
(All communications will only be made through the above email and phone number)

(5)

Name of the organisation

(6)

Address of the organisation/registered office

(7)

Licence number, if any

(8)

Nature of business

(9)

Name of the food product/ ingredient/additive/enzyme/processing aid, and proprietary name, if any

(10)

Justification of the name

(11)

Proposed product category

(12)

Source of food ingredient(s) (animal, chemical, botanical or micro-biological)

(13)

In case of animal, botanical or micro-biological source, genus and species of the organism shall
be mentioned

(14)

Functional use

(15)

Intended use

(16)

Certificate of analysis from third party National Accredited Board of Laboratories (NABL) or
International Laboratories Accreditation Cooperation (ILAC) recognised laboratories shall be
provided. The certificate of analysis shall include physical, chemical and microbiological
parameters relevant to the product along with the validated test method and other test methods,
if any with references wherever applicable

(17)

Manufacturing process in brief

(18)

Regulatory Status
(Mention the countries where the product is permitted for direct or indirect human consumption
as food. If so, provide the level and purpose of consumption by the consumers with the relevant
regulations along with the documentary evidence.)

(19)

Copy of agreement of relationship of applicant and manufacturer and other entities involved in
the food business of the proposed product, namely, marketer, importer, re-packer

(20)

Safety Information(Documents on risk assessment or toxicity studies)
(a) The information shall be based on safety or risk assessment review from published studies
and safety studies conducted on the ingredient and food product by the applicant
(b) Provide evidence to demonstrate that the proposed product or the ingredient will not
adversely affect any specific population groups that is pregnant women, lactating mothers,
children, elderly or any other vulnerable group

3. Additional specific information:—
(a) Novel food or novel food Ingredients or food processed with the use of novel technology:(1) The target group for the said proposed food, if any

<!-- page 12 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

(2)

[PART III—SEC. 4]

Detailed composition of the product (with quantity of the ingredients and additives added in the
product)
Any new ingredient(s) (Please specify if the product has one or more new ingredients which as
on date is not listed in Food Safety and Standards Regulation, or an ingredient which has been
introduced for the first time in India)

(3)

Details of new technology

(4)

Safety Information (Documents on risk assessment or toxicity studies to be attached)
(a) Information on human studies including dietary exposure, nutritional impact and potential
impact on the consumer if any
(b) Toxicological studies including results of Ame’s tests to test mutagenecity, chromosomal
aberration tests, studies for reproductive toxicity, prenatal developmental toxicity studies
(c) Allergenicity (published or unpublished reports of allergenicity or other adverse effects in
humans associated with the food consumption; may include reports prepared by World
Health Organisation or by other national or international agencies responsible for food safety
or public health )

(5)

History of consumption of food product/food ingredient, (attach supporting documents)
(a) Geographical area of use (with established history of safe use in at least two countries, with
well-established regulatory status)
(b) Quantity of consumption
(c) Duration of consumption (in years)

(b) New additives:(1) Chemical name and INS No.
(2) Purity (food grade or equivalent)
(3) Acceptable Daily Intake (ADI) specified by JECFA or any other risk assessment body
(4) Proposed level of use in food category
(5) In case of colouring agent provide (Colour Index) colour number, where applicable
(c) New processing aids including enzymes:(1)

Specification

(2)

Enzyme activity

(3)

Purity

(4)

Residual limit in the final product (in case of processing aid)

(d) Articles of food and food ingredients consisting of or isolated from microorganisms, bacteria, yeast,
fungi or algae:S.
No.
(1)
(2)
(3)
(4)

Data required for microorganisms used as Food (Directly Fed) or used as a source of food ingredients
Nature of microbe
Name of microbe
Source
If locally isolated

Bacterium/Yeast/Fungus/Algae
Genus
Species
Indigenous
Imported
Isolated
Deposited in the national culture Yes
collection centre (eg-Microbial
Type Culture Collection and Gene
Bank,
(MTCC),
National
Collection of Dairy Cultures
(NCDC) Indian Type Culture
Collection (ITCC))

Strain

No

<!-- page 13 -->

III

(5)

(6)
(7)

(8)

(9)

(10)
(11)
(12)

(13)

11

If deposited in a national
culture
collection centre
If bought from national
culture collection centre
If imported and privately
Isolated

Name and address of Culture Reference No.
collection centre

Receipt
(Copy)

Name and address of Culture Reference No.
collection centre
Country of origin

Receipt
(Copy)

Name and address of
Reference No.
Receipt Copy
the Foreign organization/Industry
If bought from an
Name and address of
ReferenceNo.
Receipt (Copy)
international
culture International Culture Collection
collection centre (e.g. Centre
American Type Culture
Collection centre (ATCC),
European
Culture
Collections Organisation
(ECCO))
Material Transfer
Yes (Copy)
No
Agreement
between
exporter/foreign
entity
and
importer/manufacturer in
India
If the organism has been Yes
No
genetically manipulated.
Any institutional bio
safety mechanism in place
Safety
/
Generally
Recognised
as
Safe
Copy
status (GRAS) of
the microbe
Declaration
by the
The undersigned verifies that all ingredients are approved for use by the
manufacturer or importer Export Country National Regulator or appear on their Generally
regarding safety and end Recognised as Safe list (Name of the Regulatory Agency), and each
use
product is intended for human consumption and is available for sale in
the country of origin without restriction.

Note: (1) Mention “not applicable” (NA) wherever necessary.
(2) All data documentary evidence provided by the applicant shall be from international peer reviewed
journals, international bodies including World Health Organization (WHO) and Food and Agricultural
Organization (FAO). Only complete records or studies shall be provided.
FORM-II
(See sub-regulation (4) of regulation 4)
(Approval/Rejection)
Application No:
Date of application:
Name of organisation:
Name of the applicant:
Registered office address:
Authorised person:
Name of the food product:
Product category:

<!-- page 14 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

Composition:
Ingredients
Name

Application status:

Food Additives
INS No

[PART III—SEC. 4]

Limits (GMP or
mg/Kg)

Approved/Rejected

1. Conditions for approval:
2. Reasons for rejection, if any:
(Authorised Signatory)

[ADVT.-III/Exty./223/17]

PAWAN AGARWAL, Chief Executive Officer

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
Digitally signed by

ALOK
KUMAR

ALOK KUMAR
Date: 2017.09.15
12:03:06 +05'30'
