---
doc_id: "db1f80c1beb5dee8"
source_url: "https://gpmumbai.ac.in/gpmweb/wp-content/uploads/2026/04/Corrigendum-2-Even-25-26-Term-End-Examination.pdf"
ministry: "Government Polytechnic, Mumbai, Maharashtra"
title: "Corrigendum - II for Even Term Exam 25-26"
date: ""
pages: 1
method: "tesseract:mar+hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "ef6268a31aeec25c"
---

<!-- page 1 -->

@ Government Poly technic, Mumbai =
his त (9 हक्कात 10५९७४ 6 Cosemment कक ies <a
( शिरा ko
NR Rete wen epmoteincis seat शष 1001णणा ain ही
कडी हक वक Emad ण मळ 00 णा रत
Offee Emel cle maha don 0000010000 हे ळक
GPM 10.09/ Odd Sem _Exam/2025-26/Comi-W 6 7 Date: 15/04/2026
Examination Cell — E. examination Cell— EVEN Sent 2025-26 Theory Exam Sem 2025-26 Theory Exam
Corrigendum-I
Reference: - EVEN Sem 2025.26 Lnd Term Theory Exam Timetable did. 02/04/2026
As per above reference, EVEN Sem 2025-26 End Term Theory Exam Timetable is displayed on 02/04/2026 for all schemes. In this exam timetable for P-23,
P-19 & P-19R Scheme following changes must be noted by students, exam officer in-charge & all concer faculties and staff.
| Previous Exam Time Table Revised Exam Time Table
aa गा
ea 7० Session Program Course Code Course Title
Scheme |
| र Moming (10:30 am क 7 All concern students from
| 22042026 | | Electronics Sci9110/ | Engineeri Morning (10:30 :
| gineering तु कं जन
| P-19 Scheme | 10 1:00 pm) Engineering (SP) | SCI9Ri10 | Mathematics 2#052026 | ato 1:00pm) _| Eleetronics Dept. mas
~~ | Moming (10:30 am
2 [Fiesta | 10/2026 Information CO 19R204 Morning ai 10:30 | All concern students from
| P-19 Scheme | ® 1:00 pm) Technology (SP) Data Structures 2910472026 | ato 1:00 pm) | IT Dept. must be noted
| 24/4/2026 यय (10:30am [टा Engineering AME Engineering 24142026 | Afternoon (2.00 | All concern students from ।
[2-19 Scheme | १० 1:00 pm) (SP) Mechanics Pm to 4.40 pm) | Civil Dept. must be noted {
| ] Morning (10:30 am : ; Ta 30 । Allconcern students from
| 05/05/2026 | Mon Mechanical sc19110/ | Engineering Morning (10:30 :
| P-19 Scheme [P19 Scheme | © 1907 to 1:00 pm) Engineering (SP) | 5019२110_ | Mathematics ती र | ante 00a ahs Dept. must be
— 7 |
। 1 Morning (1030 am ही Industrial Hydraulies ing (1030 | All concern students from
pions, | 10 1:00 १० | ७1१७ ) कीचा spy 100000 | and Preumatics 05057026 | Morning car Mechanical Dept. must be
[P19 Scheme gineering (: 9R302 00 pi “WV "|
(rN. ३ Mhala)
Principal,
Government Polytechnic, Mumbai
