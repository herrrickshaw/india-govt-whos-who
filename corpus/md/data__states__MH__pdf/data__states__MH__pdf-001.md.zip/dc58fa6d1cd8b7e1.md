---
doc_id: "dc58fa6d1cd8b7e1"
source_url: "https://dmer.maharashtra.gov.in/english/wp-content/uploads/2025/09/13.-Scheme-for-nursing-augmenting-colocation-guidelines.pdf"
ministry: "Directorate of Medical Education & Research, Mumbai"
title: "नर्सिंग शिक्षण वृद्धीसाठी योजना – वैद्यकीय महाविद्यालयांसोबत नवीन नर्सिंग महाविद्यालयांची स्थापना"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5d2853a72134082e"
---

<!-- page 1 -->

Guidelines for Centrally Sponsored Scheme
Scheme for augmenting Nursing Education- Establishment of new Colleges of
Nursing (CoN) in co-location with Medical Colleges

Government of India
Ministry of Health & Family Welfare
Department of Health & Family Welfare
Nursing Division, Nirman Bhawan
New Delhi

1

<!-- page 2 -->

INDEX

Sr.

Content

Page No.

1

Background and objective

3

2

Selected Districts

3

3

Funding & guidelines to release funds

4-5

4

Implementation

5

5

Plan of Action

5-6

6

Composition of Empowered Committee

6

7

Branding

6

8

Annexure I (Template of Utilization Certificate)

8

9

Annexure II (List of number of nursing colleges to be

9-10

No.

established in States/UTs)

.

2

<!-- page 3 -->

1. Background and Objective
To augment the availability of qualified human resources in health, the Ministry
of Health & Family Welfare has taken up a number of initiatives including implementation
of a Centrally Sponsored Scheme “Establishment of new medical colleges attached with
existing district/referral hospitals”. Under the scheme, a total of 157 new Medical colleges
have been sanctioned in three phases. This scheme has led to a significant increase in
the number of medical graduate seats in the country.
Now, to bring similar reforms in nursing education with a vision to provide high
quality, affordable and equitable nursing education in India especially to underserved
districts and States/UTs, One hundred and fifty-seven new nursing colleges will be
established in co-location with the existing 157 medical colleges established since 2014
under the Centrally Sponsored Scheme referred to in para above. The Colleges of
Nursing will be established with in the same campus in co-location with the approved
medical college and will have the advantage of optimal utilisation of the existing
infrastructure, skill labs, clinical facilities and faculty of medical colleges. This would not
only provide better clinical exposure to the nursing students but would also result in better
care and service provision of patients in the medical colleges.

2. Selected Districts

2.1

Nursing Colleges will be established in 157 districts (List attached) as already
identified in 3 phases under the scheme “Establishment of new medical colleges attached
with existing district/referral hospitals”. If any of the States could not opt for the Nursing
College with the medical college in the specified district due to bona fide reasons, then the
nursing college may be established in any other Government Medical College of nearby
district proposed by the State government after due consideration and approval of the
Empowered Committee (EC).

2.2

i.

Additional factors to be considered:

Adoption of latest innovation and composite structures, strategies for speedy and “green”
construction with lesser carbon footprint and energy efficient buildings.

ii.

There should be a scope for vertical expansion in all new nursing colleges.
3

<!-- page 4 -->

iii.

The project is based on resource sharing between medical and nursing college, hence
expenditure may be avoided on existing infrastructure/resources available in the medical
college, which may be shared.
3. Funding & guidelines to release funds

i.

The total support for establishing Nursing colleges would be Rs. 10 crores including
Central & State share

ii.

Funds would be shared between the central government and the state governments in
the ratio as tabulated below:
(in Rs Cr)
No. of colleges

Ratio

Central Share

State

Total

Share
UTs without legislature:

100%

10x2=20

0

20

90:10

22x9=198

22x1 = 22

220

60:40

133x6= 798

133x4 =

1330

2x10 = 20
North

Eastern/

Special

Category States: 22x10 = 220
Other States: 133x10 = 1330

532
Total

iii.

1016

554

1,570

All States/UT Governments to ensure strict compliance to the instructions issued by the
Department of Expenditure vide OM No. 1(13)PFMS/ FCD/ 2020 dated 23/03/2021
regarding procedure for release of funds under the Centrally Sponsored Schemes (CSS)
and monitoring utilization of the funds released. The procedure in brief is listed out as
under:
a. Every State Government will designate a Single Nodal Agency (SNA) for-implementing
the Scheme.
b. The SNA will open a Single Nodal account for the Scheme at the State level in a
Scheduled Commercial Bank. UTs without legislature are not required to open Single
Nodal Account as they operate directly from PFMS.
c. Implementing Agencies (lAs) down the ladder should use the SNA’s account with clearly
4

<!-- page 5 -->

defined drawing limits set for that account.
d. Zero balance subsidiary accounts for the Scheme may also be opened for the IAs
preferably in the same branch.
e. All zero balance subsidiary accounts will have allocated drawing limits to be decided by
the SNA concerned from time to time and will draw on real time basis
f. State Governments have to register the SNAs and IAs on PFMS. Bank accounts of all
SNAs/IAs receiving funds have to be mapped in PFMS
g. The State Government will transfer the Central Share received in its account in the RBI
to the concerned SNA’s account within a period of 21 days of its receipt.
h. Corresponding State Share has to be released within 40 days from the release of the
Central Share.

iv)

The funding support will be provided for non-recurring infrastructure works,

furniture & equipment. All recurring expenditures including manpower and other
recurring costs, as per the extant guidelines and practice, will continue to be borne by
the States for nursing colleges.

v)

States/UTs may increase scope of work beyond the proposed and indicative

layout plan as per their requirements. The total support for establishing Nursing colleges
would remain Rs. 10 crores only including Central & State share. In case the scope of
work is modified the additional costs will be borne by the States/UTs from their own
resources.

vi)

State/UT Governments would be required to sign a Memorandum of

Understanding (MoU) covering various conditions including commitment to provide land
for establishment of nursing college, appointment of requisite faculty & staff necessary
for running nursing college, contribute state share and recurring expenditure on
faculty/staff and proper functioning/maintenance of the nursing college established
under the scheme.

4. Implementation
For grant of a Nursing College under the Scheme, the States/UT Governments shall
submit the following:
a. Detailed Project Report (DPR) of the proposed Nursing College(s) incorporating the draft
5

<!-- page 6 -->

layout plan.
b. Memorandum of Understanding (MoU)
5. Plan of action
i)

States/UTs to adhere to the plan of action as follows:-

a. States/UTs will submit their standard DPR within 02 Weeks of the communication of the
Cabinet approval.
b. Examination of the proposal by Technical Evaluation Committee (TEC), and subsequent
approval by Empowered Committee (EC), including signing of MoUs will be processed
within 02 Week of receiving Standard DPR from the States/UTs.
c. States/UTs where establishment of medical colleges is yet to complete will float tender for
nursing

colleges

within

03

Weeks

and

those

where

medical

colleges

are

completed/functional will float tender within 05 Weeks of receiving necessary approval from
the Ministry.
d. Letter of Award will be provided to the successful bidders within 45 days of opening of bids.
e. Foundation Stone will be laid within 02 Weeks of providing Letter of Award.

ii)

A Technical Evaluation Committee (TEC) of Ministry of Health & Family Welfare

will examine the DPR.

iii) Recommendations of the TEC will be placed before the Empowered Committee (EC)
headed by Secretary (Health & Family Welfare), which will finally approve the proposed
nursing colleges to be established. The composition of the EC is as under:

i.

Secretary, Ministry of Health and Family Welfare, GoI

Chairperson

ii.

Additional Secretary (Medical Education), MoHFW

Member

iii.

Additional Secretary & Financial Advisor, MoHFW

Member

iv.

DGHS, Dte.GHS

Member

v.

Joint Secretary (Medical Education), MoHFW

Member

vi.

Principal, Central government Medical college/institute

Member

vii.

Principal, Central government nursing college/institute

Member

viii.

Deputy Secretary/ Director (Nursing Division), MoHFW

MemberSecretary

6. Branding: The MoHFW shall provide standard guidelines for façade branding of these
6

<!-- page 7 -->

institutions for information of candidates availing nursing education in these institutions.
7. Review meetings with the State Governments to be held periodically by Ministry to
ensure that the constructions work and purchase of equipment is being done as per the
action plan proposed.
i.

These new Nursing Institutions will act as Mentor Institutions for the nursing colleges
in the State & the region and will act as hub for quality assurance.

8. The concerned State/UT authorities shall:

ii.

Share details of progress of the Nursing College along with photographs periodically.

iii.

Timely furnish the utilization certificate with respect to the grant-in-aid released by the
Central Government under the Scheme. (Format of Utilization Certificate is at
Annexure-II).

iv.

Admit students in the new nursing college after obtaining necessary permissions from
INC or the regulatory body in existence.

9. The State/UT Governments shall strictly adhere to the norms as prescribed by Indian
Nursing Council or regulatory body in existence and regulations thereto as notified from
time to time with regard to establishment of a new nursing college.

***

7

<!-- page 8 -->

Annexure-II
Template of Utilization Certificate to be submitted by State/UT Governments
against the Grant-in-aid released under the Scheme

8

<!-- page 9 -->

Annexure-III
State-wise list of 157 medical colleges approved & being established under the
Centrally Sponsored Scheme for ‘Establishment of new medical colleges
attached with existing district/referral hospitals’
Sr. No

Name of the State/UT

No. of nursing colleges to
be established

1.

A & N Islands

1

2.

Arunachal Pradesh

1

3.

Andhra Pradesh

3

4.

Assam

5

5.

Bihar

8

6.

Chhattisgarh

5

7.

Gujarat

5

8.

Jharkhand

5

9.

Jammu & Kashmir

7

10.

Himachal Pradesh

3

11.

Haryana

1

12.

Karnataka

4

13.

Ladakh

1

14.

Madhya Pradesh

14

15.

Maharashtra

2

16.

Manipur

1

17.

Meghalaya

1

9

<!-- page 10 -->

18.

Mizoram

1

19.

Nagaland

2

20.

Odisha

7

21.

Punjab

3

22.

Rajasthan

23

23.

Uttarakhand

4

24.

Uttar Pradesh

27

25.

Tamil Nadu

11

26.

West Bengal

11

27.

Sikkim

1

Total

157

10
