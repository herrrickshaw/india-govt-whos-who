---
doc_id: "d9af6da27bec2b99"
source_url: "https://www.dvet.gov.in/wp-content/uploads/Desk/Request-Transfer-Schedule-Round-2-1.pdf"
ministry: "Directorate of Vocational Education and Training, Maharashtra"
title: "Request Transfer 2026 Round 2 Schedule"
date: ""
pages: 2
method: "tesseract:mar+hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "ce033749cb97c64a"
---

<!-- page 1 -->

0 60:
nr महाराष्ट्र शं शासन
cy कौशल्य, रोजगार, उद्योजकता व नाविन्यता विभाग
व्यवसाय शिक्षण व प्रशिक्षण संचालनालय,महाराष्ट्र राज्य
३, महापालिका मार्ग, एल्फिन्स्टन तांत्रिक विद्यालय परिसर, टपाल पेटी क्रमांक १००३६, मुंबई ४००००१
es a area AT ae oT re [OA https//dvet.gov.in Email: director@dvet.gov.in दुरध्वनीक्र,..०२२-२२६२०६०३/०२९३
| क्रमांक - .-/आस्था-५/ बदली 7२०२६/का-४ TOR
दिनांक AolowlQ@org
प्रति,
सहसंचालक,
व्यवसाय शिक्षण व प्रशिक्षण,
प्रादेशिक कार्यालय,
मुंबई /पुणे/ नाशिक/ छत्रपती संभाजीनगर/ अमरावती/ नागपूर.
संचालक,
कौशल्य व्यवसाय शिक्षण व प्रशिक्षण मंडळ,मुंबई- ८१.
विषय - गट-क संवर्गातील विशेष विनंती बदली २०२६ Round २ च्या वेळापत्रकाबाबत.
संदर्भ :- संचालनालयाचे पत्र क्र व्यक्षिप्र/आस्था-५/विनंती बदली /२०२६/का-४ ,दि.२५/०६/२०२६
२) संचालनालयाचे पत्र क्र व्यशिप्र/आस्था-५/विनंती बदली /२०२६/का-४/५७,दि.०२/०७/२०२६
३) संचालनालयाचे पत्र क्र व्यशिप्र/आस्था-५/विनंती बदली /२०२६/का-४/६५ ,दि.१६/०७/२०२६
४) संचालनालयाचे पत्र क्र व्यशिप्र/आस्था-५/विनंती बदली /२०२६/का-४/६ ७,दि.२२/०७/२०२६
उपरोक्त विषयास अनुसरुन आपणास कळविण्यात येते की,प्रादेशिक कार्यालय यांनी सादर केलेली सुधारित
माहिती विचारात घेऊन Provisional Due List संचालनालय स्तरावर (Director Login ) अंतिम करण्यात आली आहे
तसेच Request Transfer allotment list with location Preferences ची प्रक्रिया ही पूर्ण झाली आहे असून
बेवसाईटवर प्रसिध्द करण्यात आली आहे.
तरी वरील बाबीस अनुसरुन विनंती बदल्या २०२६ चे २०५॥१-2 वेळापत्रक सोबत पुढील कार्यवाहीस्तव
देण्यात येत आहे.सदरचे वेळापत्रक Round -2 पर्यंतचे असून पुढील प्रक्रियेबाबत यथावकाश कळविण्यात येईल.
प्रत : १कार्यसन क्रमांक १६ मुख्य कार्यालय मुंबई यांना माहिती व पुढील कार्यवाहीस्तव .
२) कार्यासन अधिकारी,कार्यासन क्रमांक २ यांना माहितीकरीता व पुढील कार्यवाहीस्तव

<!-- page 2 -->

सन २०२६ च्या गट -क संवर्गातील कर्मचाऱ्यांच्या 2nd Round चे विनंती बदल्यांचे वेळापत्रक
रजि Stage
eno 7
| | 7 ROUND
1. | Fill Location Preferences by Employee 31” July 2026 &
01% August & 3 August 2026

Transfer List with Location Preferences 04" August 2026
> | C.S.B List Meeting at Regional Level

Publish Round — 2 request transfer allocation List 07" August 2026

( Generate Transfer Order for round 1 & 2)

Publish Remaining Employee List.

Publish Remaining Vacancy List.

3rd ROUND Will be declared later

| |
