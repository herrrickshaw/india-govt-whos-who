---
doc_id: "0f6edfcfa924dd45"
source_url: "https://mahadgm.gov.in/ListPageMasterFiles/2-12-2020-15-2-8-NERP%20Rule.pdf"
ministry: "Director General, Geology and Mining, Nagpur, Maharashtra"
title: "Click here for Mineral (Non-exclusive Reconnaissance Permits) Rules, 2015"
date: ""
pages: 10
method: "tesseract:mar+hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "6ddb53be3cce799c"
---

<!-- page 1 -->

रजिस्ट्री सं? डी० एल०-33004/99 REGD. NO. 0. (.-33004/99
कडे He :
Che Gazette of Gndia
असाधारण ठा
EXTRAORDINARY
भाग 1-खण्ड 3--उप-खण्ड (i) |
PART Il—Seetion 3—Sub-section (i) |
प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY |
ES
सं. 413] नई दिल्ली, सोमवार, जून 29, 2015/आषाढ़ 8, 1937
०भ गया, MONDAY, JUNE 29, 2015/5514101158,19302_________ MONDAY, JUNE 29, 2015/ASHADHA 8 , 1937
a ्््््च्च्च्च्च्च्च्त
खान मंत्रालय
| अधिसूचना }
नई दिल्ली, 29 जून, 2015
सा.का.नि. 516(अ).--केंद्रीय सरकार, खान और खनिज (विकास और विनियमन) अधिनियम, 1957 (1957 का 67) की
| धारा 10ग के साथ. पठित धारा 13 की उप-धारा (2) के खंड (थथज) द्वारा प्रदत्त शक्तियों का प्रयोग करते हुए निम्नलिखित नियम
i बनाती है, अर्थात:--
अध्याय-ा |
प्रारम्भिक
a. संक्षिप्त नाम और प्रारम्भ.- (1) इन नियमों का संक्षिप्त नाम खनिज (गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र) नियम, 2015 है। : |
ry (2) ये राजपत्र में उनके प्रकाशन की तारीख को प्रवृत्त होंगे । |
कक परिभाषा.- (1) इन नियमों, जब तक कि संदर्भ से अन्यथा अपेक्षित न हो, “अधिनियम” से खान और खनिज (विकास और
शै विनियमन) अधिनियम, 1957 (1957 का 67) अभिप्रेत है।
(2) वे शब्द और अभिव्यक्तियां जो अधिनियम में परिभाषित है और इन नियमों में उन्हें प्रयुक्त किया गया है, परंतु परिभाषित |
नहीं किया गया है, उनके वही अर्थ होंगे जो उन्हें अधिनियम में दिए गए हैं।
| 3. गैर-विशिष्ट सर्वेक्षण अनुज्ञापत्र प्रदान करना.- (1) राज्य सरकार अधिनियम की धारा 3 के खंड (5) में लघु खनिज के रूप में |
यथा परिभाषित खनिज और प्रथम अनुसूची के भाग क और भाग ख में विनिर्दिष्ट खनिजों से भिन्न अन्य खनिज के लिए इन
| नियमों में विनिर्दिष्ट निबंधनों और शर्तों के अध्ययधीन रहते हुए गैर-विशिष्ट सर्वेक्षण अनुज्ञापत्र प्रदान कर सकेगी ।
(2) राज्य सरकार गैर विशिष्ट सर्वेक्षण अनुज्ञा-पत्र के लिए आवेदनों की प्राप्ति और अनुज्ञा-पत्र प्रदान करने के लिए एक |
ऑनलाइन प्रणाली को स्थापित करेगी। |
(3) किसी ऐसे क्षेत्र के लिए गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र प्रदान करने के लिए इन नियमों से उपबंद्ध अनुसूची-। में विनिर्दिष्ट रि
रूप-विधान के अनुसार राज्य सरकार को आवेदन किया जाएगा,--
* |
2860 012015 (0) |

<!-- page 2 -->

न |
2 THE GAZETTE OF INDIA: EXTRAORDINARY [Part II—Sec. 30)] |
क्रू () जो किसी सर्वेक्षण अनुज्ञा-पत्र, पूर्वेक्षण अनुज्ञप्ति, पूर्वेक्षण अनुज्ञप्ति-सह-खनन पट्टा, खनन पट्टा के अधीन धृत नही |
न है है; या |
> |
(8) जहां राज्य सरकार ने पूर्वेक्षण अनुज्ञप्त-सह-खनन पट्टा या खनन पट्टा प्रदान करने के लिए नीलामी प्रक्रिया को |
आरंभ नहीं किया है । }
(4) राज्य सरकार किसी क्षेत्र में एक से अधिक गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र प्रदान कर सकती है । ह हा
(5) गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र प्रदान करने के लिए कोई आवेदक अधिनियम की धारा 5 में सर्वेक्षण अनुज्ञापत्र प्रदान करने न |
के लिए विनिर्दिष्ट पात्रता की शर्तों को पूरा करेगा और गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र प्रदान करने के लिए ऑन लाइन TART
को अनुसूची-। में विनिर्दिष्ट रूप विधान के अनुसार 1000 रूपए प्रति वर्ग किलोमीटर की दर से संगणित फीस को ऑनलाइन
भुगतान के साथ प्रस्तुत करेगा। |
(6) उप-नियम (5) के उपबंधों के अधीन आवेदन प्रस्तुत करने पर आवेदक को ऑनलाईन पावती देने का उपबंध किया जाएगा । हे |
(7) राज्य सरकार उप-नियम (5) के उपबंधों के अधीन सम्यक रूप से पूर्ण किए गए ऑनलाइन आवेदन का प्राप्ति की तारीख से ॥
30 दिन के भीतर निपटान करेगी और उन कारणों के लिए जो लेखबद्ध किए जाए गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र जारी कर ह ।
सकेगी या नामंजूर कर सकेगी और गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र की मंजूरी या नामंजूरी पत्र को ऑनलाइन डाला जाएगा जो |
आवेदक के द्वारा डाउनलोड के लिए उपलब्ध होगा : |
परंतु आवेदन के नामंजूर होने की दशा में, उप-नियम (5) के अधीन दी गई फीस का ऐसी फीस में दस प्रतिशत की कटौती के |
पश्चात्‌ आवेदक को प्रतिदाय होगा | ॥
(8) गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र को अनुसूची-2 में विनिर्दिष्ट रूप-विधान में और उसमें विनिर्दिष्ट निबंधनों और शर्तों के |
अध्यधीन रहते हुए जारी किया जाएगा । |
(9) गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र प्रदान करने का अधिकतम क्षेत्र उस अधिकतम क्षेत्र से अनधिक होगा जो अधिनियम की
धारा 6 में सर्वेक्षण अनुज्ञापत्र के लिए विनिर्दिष्ट है और गैर विशिष्ट सर्वेक्षण अनुज्ञा-पत्र उसी अवधि के लिए जारी होगा जो : |
अधिनियम की धारा 7 की उप-धारा(1) में सर्वेक्षण अनुज्ञापत्र हेतु विनिर्दिष्ट है।
(10) राज्य सरकार गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र प्रदान करने के ऑन लाइन प्रणाली तक भारतीय मानक ब्यूरों की पहुंच |
अनुज्ञात करेगी और उंप-धांरा (7) के अधीन गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र की मंजूरी और नामंजूरी को भारतीय मानक ब्यूरों
को भी लिखित में संसूचित करेगी। |
(11) किसी क्षेत्र में गैर विशिष्ट सर्वेक्षण अनुज्ञा पत्र प्रदान किए जाने से राज्य सरकार के लिए ऐसे क्षेत्र के सभी या उसके किसी
भाग में खनन पट्टा या पूर्वेक्षण अनुज्ञप्ति-सह-खनन पट्टा प्रदान करने के लिए अधिसूचित करने का प्रतिषेध नहीं होगा और ऐसी
अधिसूचना होने पर ऐसे अधिसूचित क्षेत्र के सभी गैर विशिष्ट सर्वेक्षण अनुज्ञापत्रों का यंत्रवत समापन हो जाएगा : |
परंतु राज्य सरकार ऐसे अधिसूचित क्षेत्र के प्रत्येक गैर विशिषूट सर्वेक्षण अनुज्ञा पत्र धारकों को ऐसे यंत्रवत समापन की लिखित |
सूचना देगी । |
4. - गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र का निष्कर्ष.- (1) किसी गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र का धारक राज्य सरकार को अपने |
निष्कर्षों को भेज सकेगा और राज्य सरकार से यह अनुरोध कर सकेगा कि राज्य सरकार ऐसे निष्कर्ष पर आधारित पूर्वेक्षण-सह क
खनन पट्टा या खनन पट्टा प्रदान करने के लिए नीलामी का प्रबंध करे | |
(2) राज्य सरकार, उप-धारा (1) के अधीन ऐसे अनुरोध के प्राप्त होने पर और जानकारी की मांग करने का अधिकार रखेगी है |
जिसके अंतर्गत ऐसे निष्कर्षों से संबंधित दस्तावेज भी हैं और राज्य सरकार ऐसे निष्कर्षों पर आधारित पूर्वक्षण-सह-खनन पट्टा |
या खनन पट्टा प्रदान करने के लिए नीलामी के प्रबंध का विनिश्चय कर सकेगी।
(3) राज्य सरकार खनिज (नीलामी) नियम, 2015 के अनुसरण में संतुष्ट होने पर निम्न करेगी,-
i (क) खनिज (खनिज तत्व साक्ष्य) नियम, 2015 में यथा विनिर्दिष्ट खनिज के अस्तित्व के साक्ष्य पर खनन पट्टा के नीलामी
का प्रबंधन कर सकेगी; या
(ख) खनिज (खनिज तत्व साक्ष्य) नियम, 2015 के नियम 7 में विनिर्दिष्ट अपेक्षानुसार पूर्वेक्षण-सह-खनन पट्टा प्रदान करने
के लिए नीलामी का प्रबंध कर सकेगी । |
|

<!-- page 3 -->

4 [भाग ॥--खण्ड 3 ()] भारत का राजपत्र : असाधारण 3
अनुसूची झा
(नियम 3 के उपनियम (3) को देखें) i
| अधिनियम की धारा 10ग के अधीन गैर-विशिष्ट सर्वेक्षण अनुशा-पत्र (एनईआरपी) आवेदन को ऑनलाइन भरने संबंधी प्रारूप डू
ग
नम aoe शा i
| च" [[[[[[[| ||| | |||||| ||| 1 |||]
| a 1111111111111111 ॥ 18 ॥ जा ॥ हज तीय
mT 1
| = COAT"
BOTT)
Doe es =
| SERRE ese) बनना eee
| ७ ee ae
| ey = | [ छकरूक | [छल |
|
| 3
a 00 0)
| ee
rh मैं
क लाक क. 0.“ in
| कि ना या OY CO विस पल ळच
11 11 आधा... ळा | (uc fered fied
प Ec हता बज हातात हाहाहा Fd
ह. ee ee 9 |
जा तडकतात el ee eee तहात हहत हाहा
1 00100 ती ee 3. |
1 ee ee ee 1...
ee eee |
[_ 5] et आवेदक वाले से ही आकेदित क्षेत्र संबंधी राज्य में किसी एनईआरपी का धारक है |: pe (|
[Radordewaa eee ______________________ |.
Le
a ee)
|... © 11
|

<!-- page 4 -->

|
| 4 THE GAZETTE OF INDIA : EXTRAORDINARY [Parr II—SEc. 30)]
ee
|... १
भुगतान ब्यौरा j
| Naat A तव माल... . आन सना हाक
| Rl a, |
| मस वह घोषणा करते है कि उपर दिए गए म्यारे सही हैं और मैंहम,आपके eer यथा अपेक्षित सटीक योजना और प्रतिभूति जमा सहित अन्य कोई ah म्यारे देने के लिए तैयार है । व
अष्दीय
| ag | elit id a शा आ का आम का था का
| "- elealaee "शा
अधिनियम की धारा 10ग के अधीन गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र (एनईआरपी) आवेदनों को भरने के लिए अनुदेश
॥ गया । —-|- | -|—~_;E प्रारूप में | अनुदेश | 2
लि . शा । 75 Tan wesw we कस फ7>ऊ ८
| 2 यदि आवेदक-(क) व्यक्ति है तो राष्ट्रीयता का प्रमाण संलग्न किया जाएगा ; (ख) कंपनी है तो कंपनी के निगमत प्रमाण पत्र
| की स्व-प्रमाणित प्रति संलग्न की जाए; तथा (ग) फर्म अथवा संगम होने पर, फर्म के सभी साझेदारों अथवा संगम के सभी F
सदस्यों की राष्ट्रीयता का सबूत संलग्न किया जाएगा ।
आवेदित क्षेत्र का भू संदर्भ निर्देशांक के साथ सम्यक रूप से सीमांकित किया हुआ मानचित्र
6और7 | गैर- विशिष्ट सर्वेक्षण TTT के लिए आवेदित क्षेत्र के साथ अधिरोपित बाह्य क्षेत्र का कैडास्ट्रल मानचित्र जिसमें |
तहसील, जिला, राज्य का नाम और भारतीय सर्वेक्षण की टोपोशीट संख्या का उल्लेख किया गया हो और यदि उपलब्ध हो |
तो प्रत्येक क्षेत्र तथा उसके भाग का वर्ग किलोमीटर में क्षेत्र । |
6और7 | बन मानचित्र के मामले में, क्षेत्र को भू संदर्भित वन मानचित्र पर दर्शाया जाए, यदि उपलब्ध हो तो रेंज और फेलिंग |
| *] सीरिज दर्शाया जाए ।
| 8औौर9 | शपथ पत्र द्वारा सम्यक रूप से समर्थित, राज्य में खनिज-वार क्षेत्र का विवरण जिसके लिए आवेदक अथवा इसमें हित लाभ
से जुड़ा कोई व्यक्ति जो,- |
(क) पहले ही सर्वेक्षण अनुज्ञा-पत्र अथवा गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र धारित है; और |
(ख) सर्वेक्षण अनुज्ञा-पत्र अथवा गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र के लिए पहले ही आवेदन आवेदन |
1__-------क्याहपरंतुअनुमतिहहीमिती| अ ़््ख़ख़़़्‌ है परंतु अनुमति नही मिली ।
टिप्पण
(1) गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र (एनईआरपी) प्राप्त करने के लिए संबंधित राज्य डीएमजी को ऑन लाइन आवेदन किया जाए केवल |
ऑनलाइन आवेदन ही स्वीकार किया जाएगा | धं
(2) ऑनलाइन आवेदन का प्रिंटआउट लेकर, आवेदन की मूल प्रति के रूप में, आवेदन करने की तारीख से 15 दिनों के भीतर संलग्न का
उपर्युक्त दस्तावेजों के साथ राज्य सरकार को प्रस्तुत किया जाए। * |
अनुसूची-ा |
(नियम 3 के उपनियम (8) को देखें)
गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र का प्रारूप
[राज्य] सरकार
[पता] |
सेवा में, |
[गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र धारक का नाम]
. पता] |
र |

<!-- page 5 -->

[भाग 11- खण्ड 3 ()] भारत का राजपत्र : असाधारण 5 }
eS |
विषय: गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र प्रदान करना - |
प्रिय श्रीमान/श्रीमती जी, a
[राज्य] सरकार, खान और खनिज (विनियमन और विकास) अधिनियम, 1957 (1957 का 67) की धारा 10ग और." |
इसके अधीन बनाये गये नियमों के अनुसरण में [गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र धारक नाम] (*एनईआरपी |
A धारक”) को निम्ननिर्दिष्ट निबंधनों और शर्तों के अधीन संतुष्ट होकर गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र प्रदान करती ॥|
हैः i
p (1) यह गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र, एनईआरपी धारक द्वारा जमा किए गए आवेदन संख्या [संख्या]. तारीख
[तारीख] के आधार पर दिया जा रहा है। यदि इस आवेदन में प्रस्तुत कोई भी जानकारी गलत, अपूर्ण या किसी भी
प्रकार से भ्रामक पाई जाती है तो, यह गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र रद्द कर दिया जाएगा | |
(2) यह गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र निम्नलिखित क्षेत्र के लिए दिया जा रहा है : |
। = चा मद विवरण ॥_.
11 । क्षेत्र का माप वर्ग किलोमीटर में
4 —_—_—__
| 2 | क्षेत्र का न्यारा | |
| नाक “|| आ | । जिला | |
कवा. आप के कक |
| Sige =
| [7_] भारतीय सर्वेक्षण की टोपोशीट संख्या Se जी जक
8 | पाए जाने वाले संभावित खनिज SS
(3) यह गैर-विशिष्ट सर्वेक्षण अनुज्ञा-पत्र [संख्या] [महीनों/वर्षों)। की अवधि के लिए विधिमान्य होगा, जब तक कि इसे
खान और खनिज (विकास और विनियमन) अधिनियम, 1957 (1957 के 67) या इसके अधीन बनाए गए नियमों
| के अनुसरण में पहले समाप्त नही किया जाता है |
ह (4) यह गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र अधिनियम और उसकी अधीन बनाए गए नियमों में पूर्वेक्षण अनुज्ञापत्र या गैर.
विशिष्ट सर्वेक्षण अनुज्ञापत्र से संबंधित सभी विनिर्दिष्ट निबंधनों और शर्तों, और निम्नलिखित साधारण निबंधनों
और शर्तों के अध्यधीन होगा;
(क). एनईआरपी धारक आवेदन में यथा उपदर्शित न्यूनतम व्यय की प्रतिबद्धता और वास्तविक लक्ष्यों का
| अनुसरण करेगा;
i (ख) गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र एनईआरपी धारक के द्वारा सर्वेक्षण और संक्रियाओं को पूरा करने के
लिए अपेक्षित सभी अनापत्तियों, अनुज्ञापत्रों और अन्य संविधिक उपबंधों के अध्यधीन होगा;
| (ग) राज्य सरकार, केंद्रीय सरकार के पूर्व अनुमोदन से, गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र में ऐसी और शर्ते
| अधिरोपित कर सकेगी ;
| (घ)  एनईआरपी धारक गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र में विनिर्दिष्ट नहीं किए गए किसी खनिज का पता
चलने पर ऐसी प्रत्येक खोज को ऐसी खोज की प्राप्ति की तारीख में 60 दिन के भौतर उसकी .प्रकृति
| और स्थिति की पूर्ण विशिष्टियों के साथ राज्य सरकार को रिपोर्ट करेगा; न
। (इ) एनईआरपी धारक गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र के आधार पर किसी संयुक्‍त अनुज्ञप्ति या खनन
पट्टा प्रदान किए जाने का दावा करने का हकदार नहीं होगा;
| $6८० ८) ।४->

<!-- page 6 -->

6 THE GAZETTE OF INDIA: EXTRAORDINARY [Part II—SEc. 30)]
"y (च) प्रत्येक एनईआरपी धारक राज्य सरकार को सर्वेक्षण संक्रियाओं की एक स्कीम भेजेगा जिसमें वह रीति
मा उपदर्शित होगी जो एनईआरपी धारक गैर विशिष्ट सर्वेक्षण अनुज्ञा पत्र में सम्मिलित क्षेत्र में सर्वेक्षण .
संक्रियाओं को चलाने के लिए प्रस्ताव करता है, जिसमें निम्नलिखित रखे जाएंगे ;
(i) हवाई विस्तार, सीमाओं के अनुसार ऐसे क्षेत्र के विवरण ; बे
(i) योजना स्केल और भू मानचित्रण क्षेत्र; और
(1) प्रयोग किए जाने वाले यंत्रों और उपस्करो के विवरण; न se
(छ) गैर विशिष्ट सर्वेक्षण अनुज्ञापत्र के चालू रहने के दौरान एनईआरपी धारक के दवारा किसी भी समय
सर्वेक्षण स्कीम को उपांतरित किया जा सकता है । ऐसी उपांतरण/उपांतरणो को सर्वेक्षण स्कीम पर
निष्पादन के लिए राज्य सरकार को सूचित किया जाएगा ; और
(ज) एनईआरपी धारक सर्वेक्षण संक्रियाओं के प्रारंभ की तारीख की सूचना देगा ।
|
[सं. 1114/2015-एम-५1] |
आर. श्रीधरन, अपर सचिव |
MINISTRY OF MINES 1
NOTIFICATION
New Delhi, the 29th June, 2015
G.S.R. 516(E).—In exercise of the powers conferred by clause (qqh) of sub-section (2) of section 13 read with
section 10C of the Mines and Minerals (Development and Regulation) Act, 1957 (67 of 1957), the Central Government
hereby makes the following rules, namely’
CHAPTER | ।
PRELIMINARY |
1 Short title and commencement—(1) These rules may be called the Mineral (Non-exclusive Reconnaissance |
Permits) Rules, 2015. |
|
(2) They shall come into force on the date of their publication in the Official Gazette. |
2. Definition.—{1) In these rules, unless the context otherwise requires, “Act” means the Mines and Minerals
(Development and Regulation) Act, 1957 (67 of 1957).
(2) Words and expressions defined in the Act and used, but not defined in these rules, shall have the same
meaning as assigned to them in the Act. डे
3. Grant of non-exclusive reconnaissance permit—(1) The State Government may grant a non-exclusive 9
reconnaissance permit in respect of any mineral other than a mineral notified as a minor mineral as defined in
clause (०) of section 3 and minerals specified in Part A and Part छे of the First Schedule to the Act, subject to
such terms and conditions specified in these rules.
(2) The State Government shall establish an online system for receipt of applications and grant of a non-
exclusive reconnaissance permit.
(3) An application may be made to a State Government in the format specified in Schedule ] annexed to these
rules for grant of a non-exclusive reconnaissance permit over any area,
(which is not held under a reconnaissance permit, prospecting licence, a prospecting licence-cum-
mining lease, amining 1685९; or
(ii) where the State Government has not initiated auction process for grant of a prospecting licence-cum-
mining lease or mining lease. |
(4) The State Government may grant more than one non-exclusive reconnaissance permit over any area, |
(5) An applicant for grant of non-exclusive reconnaissance permit shall mect the eligibility conditions specified |
in section 5 of the Act for grant of a reconnaissance permit and shall submit an online application for grant of
|
|

<!-- page 7 -->

जु [भाग 1-खण्ड 3 ()] भारत का राजपत्र : असाधारण 2
ee
non-exclusive reconnaissance permit as per the format specified in Schedule I alongwith an online payment of a
___ fee calculated at the rate of one thousand rupees per square kilometre.
(6) An online acknowledgment shall be provided to the applicant on submission of an application under the eI
provisions of sub-rule (5). री
(7) The State Government shall dispose of the application made under the proyisions of sub-rule (5) within a
a period of thirty days from the date of receipt of a duly completed online application and may, either issue a
non-exclusive reconnaissance permit or reject the application for reasons to be recorded in viting and the letter
to grant or reject the non-exclusive reconnaissance permit shall be posted online which shall be available for
download by the applicant:
Provided that in case an application is rejected, the fee made under sub-rule (5) shall be refunded to the
applicant after deduction of an amount of ten per cent. of such fee.
i 7 (8) The non-exclusive reconnaissance permit shall be issued in the format specified in Schedule 11 and shall be
subject to the terms and conditions specified therein. हा
(9) The maximum area for grant of non-exclusive reconnaissance permit shall not exceed the maximum area for
reconnaissance permit specified in section 6 of the Act and the period for grant of non-exclusive reconnaissance
permit shall be as specified in sub-section (1) of section 7 of the Act for reconnaissance permit.
(10) The State Government shall allow the Indian Bureau of Mines to access the online system for grant of a
non-exclusive reconnaissance permit and shall also communicate in writing to the Indian Bureau of Mines the
grant or rejection of the non-exclusive reconnaissance permit made under sub-rule (7).
| (11) The grant of a non-exclusive reconnaissance permit over any area shaii not prohibit the Stale Government
from notifying all or any part of such area for grant of a mining lease or a prospecting licence-cum-mining lease
and upon such notification the validity of all non-exclusive reconnaissance permits over such notified area will
stand automatically terminated:
| Provided that the State Government shall communicate in writing such automatic termination to every holder of
i non-exclusive reconnaissance permit over such notified area,

4. Findings of a non-exclusive reconnaissance permit—(1) The holder of a non-exclusive reconnaissance
permit may choose to submit its findings to the State Government and may request the State Government to
conduct auction for grant of a prospecting licence-cum-mining lease or a mining lease based on such findings
(2) Upon receipt of a request for auction under sub-rule (1), the State Government shall have the right to seek
further information including documents regarding such findings and the State Government may decide to
conduct auction for grant of a prospecting licence-cum-mining lease or a mining lease based on such findings.

| (3) The State Government upon being satisfied regarding,-
(a) _ the existence of evidence of mineral contents as specified in the Minerals (Evidence of Mineral Contents),
Rules 2015 may conduct an auction for grant of mining lease; or
(b) पार requirements specified in rule 7 of the Minerals (Evidence of Mineral Contents) Rules, 2015 may
| conduct an auction for grant of a prospecting licence-cum-mining lease,
in accordance with the Mineral (Auction) Rules 2015.
SCHEDULE I
(See sub-rule (3) of rule 3)
_ Format for online submission for Non-Exclusive Reconnaissance Permit (NERP) application under sub-section (1) of
section 10C of the Act
EP SS lel re oe ls and name of the applicant
Mir /Mirs./Ms.]MA/s :
(whichever is applicable)

J Lf Gi (at ft a nO i a Sl |

sees 9 A St al ad a a li a jon हि कम oF लि हर हि
| i i a न्य a de te Rd a i el i
| ॥॥॥॥॥77171 जा!

Code
7 ॥ il i ne ed we] nt] er] a oe a BP जाळा
Landline Numbers [FAxNumbers जन"
STD | Number aa Number
Code Code
यर र

| # 866 6Ets-3

<!-- page 8 -->

|
|
a” THE GAZETTE OF INDIA: EXTRAORDINARY [Part II—SEc. 3(i)]
मा [lf ed fd Ga bell fe ed l(t! 1-51 बा आळ Rs Fed |
४ [aT status of Appi क्र ला
| लि वा [आकर [लक] [छत [क्म क्व]
17.25. Gh for whi ra — SS ETT Te मम — i
3_| Name of Mineral (s) for which applicant intends to apply for Non-Exclusive Reconnaissance Permit (notified & non-notified separatel; ét
ee 0 ee ee | लपा आातादताआावादवधापातातद
ममा it emi eed fener eee ao pee ee | ¢. |
[*] Extent of area applied for Non-Exclysive 7 _ | Boundary of the area applied for (GPS/ DGPS Coordinates) पु ।
Reconnaissance Permit (in Sq Km) |.
मा ee
is required
6 | Degrees | Minutes | Seconds | Degrees [ Minutes | Seconds |
ey a a म्यादतिहा तत.अधहाह
el See a ELE ee अतिक! ee ee ee ee )
आह 2७1 a go बहाव |
3 ee ee eee 1
1 ! 6 a | ae 1
easel |
‘Does the applicant already possess any NERP in the sane State Where applied for |
130, give details ina separate sheet २७ | No |
‘The proposed exploratory Works to be undertaken for proving the existence of mineral along with their annual physical targets & anticipated |
minimum annual expenditure :
Nature of work Expenditure (in |
* * lakhs |
मथा. | "निधन व, वन व पतन le erase ieee ie |
Ct | i
| ae
(ii |
‘Application Fees “Amount
Payment Details Payable |
[emer आय |  sidtnmee ee |
‘Other payment details viz. DD
No
है
17५४6 do hereby declare that the particulars furnished above are correct and anvVare ready to furnish any other details including accurate plans and के
security deposit, as may be required by you. पु
Yours faithfully,
te: SS eee LL
Date: ‘Signature of the applicant क ।
"Instructions for filing Non-Exclusive Reconnaissance Permit (NERP) applications- |
under section 10C of the Act |
SI.No. in र
form a है
2 In case the applicant is, - (a) an individual, proof of the nationality shall be enclosed; (b) a company, a |
self-attested copy of the certificate of incorporation of the company shall be enclosed; and (०) Firm or
Association, proof of the nationality of all the partners of the firm or members of the association shall be
enclosed,
An applied area map duly demarcated with geo reference co-ordinates
6and7 | A cadastral Map of the area superimposed with the area applied for Non-Exclusive Reconnaissance
permit showing name of the Tehsil, District, State and Survey of India Toposheet number and area in :
Square kilometers of each field and part thereof if available.
6and7 | In the case of forest maps the area should be marked on the geo referenced forest map showing the range
and felling series if available.
|
|

<!-- page 9 -->

र [भाग 1-खण्ड 3 ()] भारत का राजपत्र : असाधारण कुही
Sand 9 | A statement duly supported by affidavit giving particulars of the area mineral-wise in the State for which .
the applicant or any person joint in interest with him,-
(a) already holds under a reconnaissance permit or non-exclusive reconnaissance permit; and F
(b) has already applied for reconnaissance permit or non-exclusive reconnaissance permit but not म
granted. ड़
> र व
Note:- |
(0). The application for grant of Non-Exclusive Reconnaissance Permit (NERP) should be made to the respective State
- DMG through on-line. Only an online application will be accepted.
(2) Printout of online application may be taken and submitted with the enclosures of above mentioned documents to
State Government within 15 days of submission as a hard copy of application.
| SCHEDULE I
| (See sub-rule (8) of rule 3)
Format of non-exclusive reconnaissance permit
| ‘THE GOVERNMENT OF [STATE]
| [address]
| ग
{name of holder of non-exclusive reconnaissance permit]
“el [address] ,
के Sub: — Grant of a non-exclusive reconnaissance permit.
| Dear Sir/Madam,
| The Government of [State] is pleased to grant a non-exclusive reconnaissance permit to [name of holder of non-
| exclusive reconnaissance permit] (“NERP Holder”), pursuant to section 10C of the Mines and Minerals (Regalation and
Development) Act, 1957 (67 of 1957) and the rules made thereunder, subject to the terms and conditions specified ग
below न
(1) This non-exclusive reconnaissance permit is being granted pursuant to the application number [number] dated
[date] submitted by the NERP Holder. If any information submitted in such application is found to be incorrect,
incomplete or misleading in any manner whatsoever, this non-exclusive reconnaissance permit shall be revoked.
(2) This non-exclusive reconnaissance permit is being granted for the following area:
: (4 [item ea
2 [1 | Size of the area in square kilometers ea नाबाद,
Details of area ——— |
District el
5 गाळ 1000111101
16]
7 | Survey of India toposheet no eel
8 | Minerals expected to be discovered ee eee eet
(3) This non-exclusive reconnaissance permit shall be valid for a period of [number] [months/years], unless .
terminated earlier pursuant to the Mines and Minerals (Regulation and Development) Act, 1957 (67 of 1957) or
4 the rules framed thereunder.
(4) This non-exclusive reconnaissance permit shall be subject to all the terms and conditions relating to
{ reconnaissance permit or non-exclusive reconnaissance permit specified in the Act and the rules made thereunder,
and the following general terms and conditions:
(a) the NERP holder shall follow the minimum expenditure commitment and physical targets as indicated in the
application;
(b) the non-exclusive reconnaissance permit is subject to all clearances, permits and any other statutory provision as
may be required for carrying out reconnaissance operations by the NERP holder;
|
|

<!-- page 10 -->

10 THE GAZETTE OF INDIA: EXTRAORDINARY [Part I—Sec. 3(i)]
——_—_—_—_—_—_—_———————— eee च |
,., (©) the State Government may, with the approval of the Central Government, impose such further conditions in the : I
a4 non-exclusive reconnaissance permit; |
q (4) the NERP holder shall report to the State Government the discovery of any mineral not specified in the non- न
exclusive reconnaissance permit along with full particulars of the nature and position of each such finding, within 5
a period of 60 days from the date of such finding;
(©) the NERP holder shall not be entitled to make any claim for the grant of any Composite Licence or Mining Lease et
on the basis of non-exclusive reconnaissance permit; = |
(0). every NERP holder shall submit to the State Government a Scheme of reconnaissance operations indicating the I
manner in which the NERP holder proposes to carry out reconnaissance operations in the area covered by the non- 4
exclusive reconnaissance permit, which shall incorporate the following: : i
(i) particulars of the area such as aerial extent, boundaries; ॥
(ii) the scale of the plan and the area of geological mapping; and हे
(iii) the particulars of the machines and instruments to be used; ही :
(g) the Scheme of reconnaissance may be modified at any time by the NERP holder during continuance of the
non-exclusive reconnaissance permit. Any such modification(s) carried out to the Scheme of reconnaissance may *
be initiated to the State Government; and हि
(h) the NERP holder shall inform the State Government the date of commencement of the reconnaissance operations.
[No. 1/14/2015-M.V1] |
R. SRIDHARAN, Addl. Secy. |
i
|
S|
|
Printed by the Manager, Government of India Press, Ring Road, Mayapuri, New Delhi-110064. SSS
and Published by the Controller of Publications, Delhi-1 10054.
|
॥
