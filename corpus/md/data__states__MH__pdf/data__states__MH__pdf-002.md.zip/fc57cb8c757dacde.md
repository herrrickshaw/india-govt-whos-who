---
doc_id: "fc57cb8c757dacde"
source_url: "https://www.madcindia.org/pdfs/tender/madc-career-42.pdf"
ministry: "Maharashtra Airport Development Company Limited (MADC), Maharashtra"
title: "Scheme Notice for RFP for allotment of about 121 acre plot outside MIHAN SEZ with Airside Taxiway Connectivity for Aerospace, Defense, Aircraft Mfg., Assembly and allied Use"
date: ""
pages: 37
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0351815c421a73aa"
---

<!-- page 1 -->

REQUEST FOR PROPOSAL (RFP)
2026

Request For Proposal for Setting up an Industrial
ecosystem
spanning
Aerospace
&
Defense
Components, Aircraft Manufacturing, Assembly and
allied manufacturing use on a plot of about 121.229
acres with Airside Taxiway Connectivity outside the
SEZ of MIHAN Notified Area

Maharashtra Airport Development Company Ltd.
(A Govt. of Maharashtra Undertaking)
CIN: U45203MH2002SGC136979
8thFloor, Centre-1, World Trade Centre,
Cuffe Parade, Mumbai- 400 005.,
Tel. No. : +91-22-49212102/22 163814 Fax: +91-22-2216 3814
Project Office
1 Floor, Central Facility Building, MIHAN,
Near Khapri Railway Station, Nagpur-441 108, Maharashtra, INDIA
Tel. No.: +91-7104-665665 Fax: +91-7104-665600
email: jmd@madcindia.org
marketing@madcindia.org
st

1

<!-- page 2 -->

Copy of the Advertisement Published in the newspapers

2

<!-- page 3 -->

Request For Proposal (RFP)
For
Setting up an Industrial ecosystem spanning Aerospace & Defense Components, Aircraft
Manufacturing, Assembly and allied manufacturing use on a plot of about 121.229 acres
with Airside Taxiway Connectivity outside the SEZ of MIHAN Notified Area
Maharashtra Airport Development Company Limited (MADC) has been appointed by the
Government of Maharashtra as the Nodal Agency and also Special Planning Authority for the
planning and development of Multi-modal International Hub Airport at Nagpur (MIHAN)
notified area to leverage on Nagpur’s unique location advantage.
The Government of India has already accorded approval and notified MIHAN-SEZ as a multiproduct SEZ. MADC has already leased out land in MIHAN-SEZ to majors IT companies like
HCL, Infosys, TCS, Tech-Mahindra and other blue-chip companies like Tata Advanced
Systems Ltd., Hexaware BPS (Caliberpoint), Lupin Ltd, Air India Inc. etc. for setting up of IT
parks, manufacturing units and MRO facilities etc. AIIMS, IIM and Govt. Engineering
Collages have also established their campus in the MIHAN area. The development of all
support infrastructures, which MADC has committed to provide, is at an advanced stage of
completion.
The MIHAN project being adjoining the Nagpur International Airport, its core objective is to
attract large-scale capital investments from global and domestic defense, aerospace, assembly
and heavy structural MRO players. To build on the presence of existing global manufacturing
and engineering anchors from these sectors, MADC invites proposals from Aerospace OEMs,
Airlines, defense consortia, and joint venture entities. The objective is to allocate industrial
land parcel of approximately 121 Acres with dedicated airside taxiway connectivity outside
the SEZ of MIHAN Notified Area. This ecosystem may host aerospace and defense aircraft
manufacturing lines, sub-assembly complexes, and heavy MRO bays.

Sr.
No.

Items

Description

1.

Scheme No.

_________________

2.

Name of the Project

Setting up an Industrial ecosystem spanning Aerospace &
Defense Components, Aircraft Manufacturing, Assembly
and allied manufacturing use on a plot of about 121.229
acres with Airside Taxiway Connectivity outside the SEZ
of MIHAN Notified Area

3.

Method of Selection

Quality Based Selection (QBS) Method

3.

Cost of
Document

including 18% GST.

4.

Scheme Rs. 59000/- (Rupees Fifty-Nine Thousand Only)

Earnest
Money Rs. Twenty-Eight Crore Only (EMD amount shall be via eDeposit (EMD)
transfer to Maharashtra Airport Development Co. Ltd.
Account)

3

<!-- page 4 -->

5.

Proposal Document 14/10/2026
Download Start /
Please
visit
the
below
mentioned
website
Expiry Date & Time https://madcindia.org => By selecting “Tenders & Notices

6.

Last date to send 17/10/2026
queries
All the queries should be submitted before the pre-Proposal
meeting, through email only with subject line as follows:
“Pre-Proposal queries - <Agency’s Name>”.
Pre-Proposal
queries
to
marketing.ngp@madcindia.org,
marketing@madcindia.org

7.

be

emailed

to

Pre-Proposal
Meeting

20/10/2026

Last
date
for
submission
of
Proposal (Proposal
Due Date)

On or before 21/10/2026 Via Speed Post or Physical
Submission in the Proposal Submission Box

Date and time
of opening of
RFP

On 22/10/2026

11.

Date and Time of
Presentation on RFP

On 23/10/2026

10

Details of Bank
Account for
payment of Scheme
Document Fee &
EMD (The details of
payment of above
amount to be
attached vide
Scheme documents)

Name: Maharashtra Airport Development Company Ltd

8.

9.

at the MADC office, 1st Floor, B Wing, North, Central
Facility Building, MIHAN SEZ, Khapri (Rly), Nagpur.
441108

at the MADC office, 1st Floor, B Wing, North, Central
Facility Building, MIHAN SEZ, Khapri (Rly), Nagpur.
441108

at the office MADC, 1st Floor, B Wing, North, Central
Facility Building, MIHAN SEZ, Khapri (Rly), Nagpur.
441108

Bank Name: Bank of Baroda
Branch Name: AIIMS Nagpur Branch
Account No.: 06950200000687
IFSC Code: BARB0VJNAAP (5th is ZERO)

4

<!-- page 5 -->

INDEX

Sr. No.

Particulars

Page No.

1

General Information

6

2

Instruction to Applicant

5-14

3

Miscellaneous Provisions

14-15

4

General terms and Conditions

15-20

5

Confidentiality

21-22

6

Checklist of Submission

22

7

Annexure I: Details of Plot

23

8

Annexure II: Master Plan

24

9

Annexure III: Location Plan

25

10

Exhibit I: Transmittal Letter

26-27

11

Exhibit II: Principles of MOU between Consortium Members

28

12

Exhibit III: Format of Power of Attorney for Signing of Proposal

29-30

13

Exhibit IV: Format of Power of Attorney for Lead Member of 31-32
Consortium

14

Exhibit V: Information about Applicant

15

Exhibit VI: Information for Evaluation of the Technical Eligibility 34-35
Criteria

16

Exhibit VII: Information for Evaluation of the Financial Eligibility 36
Criteria

17

Exhibit VIII: Financial Proposal Confirmation

5

33

37

<!-- page 6 -->

1
1.1

GENERAL INFORMATION

About MIHAN
Nagpur is one of the largest cities in central India and the third largest city in Maharashtra after
Mumbai and Pune. With a district population of over 4.6 million (as per Census 2011), it is
the 9thlargest urban agglomeration in India. Its location as the geographical centre of the
country is physically established by the Zero Mile Marker. This geographic significance of the
city endows it with huge logistics related potential.
Maharashtra Airport Development Company Limited (MADC) has been appointed by the
Government of Maharashtra as the Nodal Agency and also Special Planning Authority for the
planning and development of Multi-modal International Hub Airport at Nagpur (MIHAN)
notified area to leverage on Nagpur’s unique location advantage.
The development of MIHAN area, apart from Multi-modal International Hub Airport, will
broadly comprise of development and up gradation of airport & aircraft maintenance area,
development of multi-product Special Economic Zone, residential complex, commercial area
and development of supporting infrastructure like roads, interchange & Rail Over Bridge,
Water Supply, Sewage System, Entertainment, utilities etc.
Due to development of MIHAN project, the whole region around Nagpur is expected to
witness significant boost in economic activity. IT will also attract qualified, skilled and talent
professionals as well as investments from Maharashtra, rest of India and overseas. In the nonSEZ area, about 130-hectare land and built premises has been allotted to various companies
like Mahindra Babenco, Container Corporation of India, Future Supply Chain Solutions, TCI,
Gati, Moraj Infratech etc. for various uses. Some of the residential townships by the private
realty developers are on the verge of completion.

2
2.1

INSTRUCTION TO APPLICANT

The Project and Scope of Work

The MADC Scheme (RFP) for Setting up an Industrial ecosystem spanning Aerospace & Defense
Components, Aircraft Manufacturing, Assembly and allied manufacturing use on a plot of about
121.229 acres with Airside Taxiway Connectivity outside the SEZ of MIHAN Notified Area
(hereinafter referred to as the “Project”) as specified in Annexure-I of this document.
•
•

Minimum. Expected Investment from the Proposed Project - Rs.2000.00 Cr within 10 years
of the land allotment
Minimum Expected Employment (Direct + Indirect) to be generated in the Project: 1000.

The plot and its associated infrastructural facilities shall be developed as per the prevailing norms
for such kinds of activities.
The permitted FSI for the plot shall as per the Unified Development Control Promotion Regulations.
Plot shall be given to the successful Applicant on lease basis for the period of 66 (sixty-six) years.
2.2

Time Period for Construction

2.2.1 The Licensee within a period of 07 years from the date of Agreement, shall complete the
construction on the allotted plot as per approved plan, by consuming atleast 50% of
permissible FSI in 03 phases of which first phase of 20% within 3 years, second 30% in 5

6

<!-- page 7 -->

years & third 50% in 7 years, in accordance with the provisions of the UDCPR and shall
accordingly obtain occupancy certificate from the Town Planning Officer.
2.3

Commercial Consideration
a) The Specified rate of Lease Premium: The Specified rate of lease premium of the plot has
been fixed as mentioned in Annexure-I. Subject to conforming the eligibility criteria and
other terms and conditions of the RFP document, the plot shall be considered for allotment
to the Successful Applicant.
b) Other Terms & Conditions: - The allotment of plots will be governed by the prevailing
‘Multi-modal International Hub Airport at Nagpur (Disposal of Land) Regulations, 2018’
and various other policies framed under it.
c) Schedule of Payment: - The Lease Premium shall be paid as per schedule mentioned in
Annexure of this RFP document.
d) Lease Rent: - The Successful Applicant must pay the lease rent at the rate of Rs. 1000/- per
hectare per annum. Liability to pay such annual lease rent will commence from the date of
execution of the Agreement to Lease.
e) Performance Security: The Successful Applicant within a period of one month shall
furnish 5% of Plot Lease Premium as Bank Guarantee in favour of “Maharashtra Airport
Development Company Ltd.” from any nationalized Bank. The performance security shall
be refunded upon completion of the 1st phase of the project and obtaining Occupation
Certificate from Town Planning Authority or achieving the investment and employment
target by the company.

2.4

Terms of offer
As per the General Terms and Conditions given in Clause 4 of this offer document.

2.5

Location of the Plot
The Master plan of the MIHAN notified area is provided at Annexure – II. The location plan
is provided at Annexure –III. The area and dimensions of the Plot are indicative and may vary
on final demarcation at site.
1. The proposed land parcel consists of Zudpi Jungle measuring about 0.44 acre. Place of Zudpi
Jungle needs to be preserved as it is by establishing fencing around it & any kind of
construction/encroachment is not allowed in that area. Land of Zudpi Jungle will be in
possession of MADC & proper access for the same should be provided to MADC, as and
when required.
2. As and when Zudpi Jungle gets de-notified, MADC may allot the same to the allottee as per
prevailing Lease Premium rate and policy.
3. The proposed plot is adjoining to the proposed link Taxiway and as per final alignment of
Taxiway, there may be changes in the area, shape & location of the proposed plot.
4. A 15-metre-wide public road is planned to run parallel along the proposed taxiway,
connecting the 3-lane road at Sector 10 to Plot No. 1 at Sector 6 outside the MIHAN SEZ.
During aircraft movement to or from the facility, the allottee of the said plot shall erect
temporary barricades to restrict public access, ensuring secure and unobstructed aircraft
transit. Immediately following the completion of aircraft movement, the allottee must
remove the restrictions and reopen the 15-metre road for public use.

7

<!-- page 8 -->

2.6

Schedule of offer
As per table of Notice Inviting RFP hereinabove.

2.7

Who is eligible to participate
i) Any person, company, trust who is competent to enter into contract as per Indian Contract
Act, 1872 is eligible to participate. The foreign company/Developer may apply directly or
in association with Indian Partner, subject to the relevant Indian Laws for the time being
in force.
ii) In the event of the offer being submitted on behalf of:
a) Company: The form of offer should be signed by the Managing Director/the
Secretary/the Director or any other Principal Officer of the Company and should be
accompanied by a certified copy of the Resolution of the Board of Directors of the
Company or by a person holding the power of Attorney from the Company to do so
on behalf of the company and a copy of Memorandum and Articles of Association of
the Company should also be furnished. In case of private company, a certificate from
Chartered Accountant, indicating the names of the shareholders and share of each of
them is to be submitted along with offer.
b) A Partnership Firm: The form of offer should be signed by all the Partners in the
favour by any of them, holding power of attorney of other partners, accompanied by
a certificate of registration issued by the Registrar of Firms/application made for
registration, showing the names of all partners of the firm and a certified copy of the
partnership deed/application made.
c) A Trust: The form of offer should be signed by any Trustee or Trustees, duly
authorized by the Trust in a general or special meeting of all the Trustees. The
authorization letter must be enclosed with the offer form along with a copy of Trust
Deed of Trust Document, without which the offer shall be held invalid.
d) A Co-Operative Society: The form of offer should be signed by the Chairman or
Secretary of the Managing Committee of the proposed/registered Co-operative
Society, duly authorized by a resolution of the Society in a general or special meeting
of the society. The extract of the resolution so passed must be enclosed with the offer
form, without which the offer shall be held invalid.
e) A Proposal Consortium: A consortium of two or more (maximum 3)
person/companies eligible to Proposal may make the offer. The form of offer shall be
signed by the Managing Director/the Secretary/the Director or any other Principal
Officer of the Lead Member of the Consortium and should accompany the
Memorandum of Understanding (MoU) and Power of Attorney as per Exhibit III&IV.
Provided that the intending lessee shall not undertake or permit any change in the
equity holding of the Bidding Consortium till execution of Agreement to lease.

8

<!-- page 9 -->

2.8

Eligibility Criteria:
The Applicant can be any sole proprietorship firm, Partnership Firm, Private Limited
Company, Public Limited Company registered in India, Consortium or Joint Venture and must
be legally competent and financially sound.
Financial Eligibility Criteria
i.

The Applicant, together with its group company if any should have a minimum
consolidated average annual turnover of Rs.1.00 Lakhs Crore in the last 03 financial
years. This must be supported by a certified Chartered Accountant.

Technical (pre-qualification) Eligibility Criteria
i.

The Applicant must be actively engaged in Aerospace, Defense, OEM
Manufacturing, Component Sub-assembly, Airline Systems etc. for at least the last
Ten (10) years.

ii.

Any entity which has been barred by the Central/State Government in India, CBI,
MADC, MIL, AAI, Ministry of Defense or any entity controlled by them, from
participating in any project, and the bar subsists as on the date of Scheme, would not
be eligible to submit the Proposal.

Quality Based Selection (QBS) Evaluation Rules
Evaluation
Criteria

Description

Max Marks

Marking Scheme

Domain
Experience

Experience of Applicant or Max
its group company of past Marks
operational volume in heavy
component
production,
structural
Aerospace,
defense assembly lines,
aircraft manufacturing etc.

20 05 marks per 5 years of
eligible
experience
over
minimum of 10 years’
experience (i.e. 15 years of
relevant experience will get 15
marks)

Master
Infrastructure,
Project Plan &
Taxiway
Integration
Design

Evaluation
of
the Max
architectural
facility Marks
planning, land use layout
across the 121.229 acres,
safety
protocols,
and
structural optimization for
direct taxiway access to the
MIHAN airfield

15 10 Marks for Architectural
planning of the project,
execution plan, advanced
tooling,
manufacturing,
technology, testing and supply
to the end user
03 Marks for Taxiway
Integration of the facility
02 Marks for Safety Protocols
proposed at the facility

Capital
Investment &
Employment
Potential from
the Project

Assessment of the planned Max
capital expenditure, over a Marks
10-year phase window
alongwith
skilled
and
unskilled employment

9

15 15 marks for additional
investment of Rs.2000 Crores
+ 500 Employment (i.e. Total
Rs. 4000 Cr investment + 1500

<!-- page 10 -->

Direct + Indirect Employment
will get 15 Marks)
Financial
Strength
Evaluation
Matrix

Incremental evaluation of Max
the Applicant's balance sheet Marks
strength beyond the base
eligibility limits.

15 05 Marks for additional
consolidated average annual
turnover each Rs. 0.5 Lakhs
Crore of a company together
with group company (i.e. Rs.
1.50 Lakh Crore consolidated
turnover will get 15 marks)

Existing MOU
or Letter of
Intent
(LOI)
with Govt.

Companies who have signed Max
a valid Memorandum of Marks
Understanding (MOU) or
Letter of Intent (LOI) with
Govt. of Maharashtra / Govt.
of India

25 Full marks for one eligible
MOU or LOI with Govt.
within last 06 months prior to
the date of publishing this RFP
with Min. Investment and
Employment Criteria for
establishment of similar kinds
of projects

Presentation to A
detailed
physical Max. Marks The authority shall evaluate
about
the presentation to be given to 10
the presentation and decide
Proposal
the authorities about the
marks.
project with its technocommercial, social and
national impact.

Critical Minimum Qualification Score: Applicants must secure a minimum score of 75 marks out of
100. The Applicant securing the highest composite score will be designated as the Successful
Applicant and issued a Letter of Acceptance (LOA).
2.9

How to make an offer

The Applicants shall submit the documents as mentioned in submission checklist namely under,
"Proposal Envelope" as" (hereinafter referred to as “Proposal”). It shall be the responsibility of the
Applicant to ensure that the Proposal is submitted under proper sections. The forms shall be signed
by any board of director or the Applicant himself or through is its authorised representative duly
authorised by a Power of Attorney to be issued in the format as specified in Exhibit III hereto. The
resolution of the Board of Directors/Power of Attorney must be enclosed with the offer form along
with other documents listed in Clause 6 of this RFP document in the manner stipulated in this Clause
of the RFP document, hereinafter, without which the Proposal shall be held invalid.
2.10 Language of offer
All information in theoffer shall be in English. Information in any other language shall be
accompanied by its translation in English. Failure to comply with this shall disqualify the offer. In
the event of any discrepancy in meaning, the English Language copy of all documents shall govern
the offer.

10

<!-- page 11 -->

2.11 Earnest Money Deposit
a)

The Applicants will have to submit the EMD as mentioned in the table of Notice
inviting RFP hereinabove.

b)

After opening the RFP, the EMD amount of the Applicant(s), other than the
Successful Applicant shall be returned/ refunded at the earliest.

c)

In case, MADC decides to terminate the RFP process, EMD of all the Applicants will
be released immediately.

d)

The EMD of the Successful Applicant shall be adjusted towards the Lease Premium
for the allotted plot.

e)

The EMD shall stand forfeited to MADC in the following cases, without prejudice to
its other rights or claims against the lessee under any other section or provisions of
law:
i.

The Applicant withdraws/modifies his offer after the Due Date.

ii.

Successful Applicant fails to accept Letter of Acceptance

iii.

Successful Applicant fails to execute the Agreement to Lease/Lease Deed within
the stipulated time.

2.12 Rejection of Proposal
The Proposal is likely to be rejected if on opening it is found that:
a)

The Applicant has not submitted the required EMD amount.

b)

The Applicant has not strictly followed the procedure laid down for submission of
Proposal.

c)

The Applicant has proposed conditions which are inconsistent with or contrary to the
terms and conditions specified.

d)

The Applicant has not attached any of the documents listed as specified in the RFP
along with Proposal.

2.13 Validity of offer
The offer shall remain valid for acceptance by MADC for a period of 120 days from the date
of opening of Proposal. In case of withdrawal of offer before the expiry of offer validity period,
the EMD paid by the Applicant shall stand forfeited to MADC.
2.14 Pre-Proposal Meeting
a) MADC will hold a Pre-Proposal Meeting to clarify and discuss any provision or
requirements with respect to the offer document or any other related issues. The
Applicants should send their queries in writing at least two (2) days prior to the date of
Pre-Proposal Meeting.
b) Attendance of the Applicants at the Pre-Proposal Meeting is not mandatory. However,
subsequent to the date of the Pre-Proposal Meeting, MADC may not respond to any
questions or inquiries from any Applicant.
c) No interpretation, revision or other communication regarding this solicitation is valid
unless in writing and is signed by an officer so designated by Vice Chairman & Managing
Director. Written copies of MADC responses, including a description of the inquiry but

11

<!-- page 12 -->

without identifying its source, will be sent to all the Applicants and will qualify as a
"Corrigendum"/"Addendum" and shall form part of the offer document.
2.15 Opening of offer
The Proposal shall be opened online as per the time schedule mentioned hereinbefore. In the
event of any of the above-mentioned dates falling on a day which is not a working day or
which is a public holiday, the offer shall be opened on the next working day.
2.16 Selection of the Successful Applicant
a) The ranking of the Applicant shall be done to arrive at the Successful Applicant for project
plot.
b) The Applicant scoring the highest mark shall be declared as the successful Applicant
(hereinafter referred to as the “Successful Applicant”)
c) MADC shall issue the letter of acceptance to the successful Applicant who shall accept the
same unconditionally.
d) In case if only one Proposal is submitted in response to the RFP document, MADC at its
own discretion may decide to open and evaluate the single received Proposal for that plot
without assigning any reasons whatsoever. Further MADC at its own discretion may
decide to accept or reject such Proposal.
2.17 Special Terms and Conditions
a) The Plot is offered on “As is Where is” basis
b) The Floor Space Index (FSI) permitted on the Plot is as indicated in Annexure- I.
c) The intending lessee/successful Applicant shall provide necessary infrastructure within the
Plot, including electric sub-station for electric supply as per the requirement of Maharashtra
State Electricity Distribution Company Ltd. or any other authority supplying power in the
area, if found necessary.
2.18 Acceptance of offer
The acceptance of an offer is at the sole discretion of MADC. If the offer is accepted by
MADC, a letter communicating the acceptance of offer, in the form of ‘Letter of Acceptance’,
shall be sent to the successful Applicant, whose offer is accepted, under Registered Post A.D.
on the address given in the offer. The Letter of Acceptance shall be deemed to have been
received by the intending lessee on efflux of ten (10) days from the day of its dispatch.
2.19 Right to Accept or Reject any or all Offers and Interpretation of Documents
i) Notwithstanding anything contained in this offer document, MADC reserves the right to
modify the conditions or delete the Plot from the Project at its discretion as well as to accept
or reject any offer and to annul or suspend the bidding process and reject all offers without
assigning any reason, at any time without incurring any liability or consequences or any
obligation to inform the affected Applicants of the grounds for rejection.
ii) MADC will have the sole discretion in relation to:
a) The interpretation of offer document or its any Clauses, the offer of the Applicant and
any documentation provided in support of the offer;
b) Take decisions in relation to the evaluation of offers, whether or not to require any
clarifications or additional information from the Applicant in relation to offer and the
selection of the successful Applicant.

12

<!-- page 13 -->

c) MADC will have no obligation to explain its interpretation of this offer document, the
offers or their supporting documentation and information or to explain the evaluation
process, ranking process, or the selection of the successful Applicant.
d) To accept or reject any offer.
e) To interpret any offer is responsive or not.
2.20 Evaluation Criteria
2.20.1 Proposal Evaluation
The evaluation process comprises the following four steps:
Step I –

Responsiveness check

Step II –

Pre-qualification of Applicant as per Clause 2.7 & Annexure – I.

Step III - Evaluation of Proposal as per 2.8
Step IV – Successful Applicant (s) Selection as per clause 2.17
2.20.2 STEP I – Responsiveness check
The Proposal submitted by all the Applicants shall be scrutinized to establish responsiveness
to the requirements laid down in the offer document. Any of the following may cause the
offer to be considered “Non-responsive”, at the sole discretion of MADC:
a) Offers that are incomplete, i.e. not accompanied by the applicable format of
transmittal letter, applicable resolutions of the Board of Trustees, Power of Attorney,
necessary certifications and documentary evidence from the Competent Authority,
Auditors;
b) Offer not signed by the Applicant /Authorized Signatory;
c) Material inconsistencies in the information / documents submitted by the Applicant,
affecting the eligibility Criteria;
d) Applicant submits more than one offer;
e) Offer being conditional in nature;
f) Offer not received by the Scheme Due Date;
g) Offer having Conflict of Interest;
h) Applicant delays in submission of additional information or clarifications sought by
MADC;
i) Applicant makes any misrepresentation
Each Offer shall be checked for compliance with the submission requirements set forth in
this offer document before the evaluation of the Applicant’s fulfilment of eligibility criteria
is taken up.
2.20.3 STEP II– Pre-qualification of the Applicant
The Proposal of the Applicant will be evaluated to assess their capability on the basis of
criteria of clause 2.8.1.
2.20.4 STEP III - Evaluation of Quality and Cost Based Selection (QCBS)
The pre-qualified Applicants as per Clause 2.16 shall be eligible for QCBS. The pre-

13

<!-- page 14 -->

qualified Applicants shall be ranked as per the score achieved by them.
2.20.5 STEP IV – Successful Applicant/Applicants Selection
a) All qualified responsive Applicants shall be ranked on the score of Quality and Cost Based

Selection (QCBS) Evaluation. The Applicant, who has scored the highest marks, shall be
designated as the “Successful Applicant”. Such Successful Applicant will be issued a
‘Letter of Acceptance’. If the Applicant achieving the highest score is found not eligible
for any reason or defaults at any stage on any terms and conditions of this offer document,
after rejection of the of the Applicant achieving highest score, the next Applicant
achieving highest score may be considered at the sole discretion of MADC.
b) In the event the Successful Applicant refuses to accept the Plot or withdraws from the

above process, the Successful Applicant shall be disqualified and his EMD shall stand
forfeitedto MADC.
c) MADC shall issue the Letter of Acceptance to the Successful Applicant who shall accept

the same unconditionally.
2.21 Additional Information
For any further information please contact the following personnel:
Sr. Manager – Marketing

Manager – Marketing

MADC Ltd.
8th Floor, Centre-1, World Trade Centre,
Cuffe Parade,
Mumbai - 400 005.
Tel: No. 022-49212121/22
Fax No. 091-22-2216 3814

MADC Ltd.
1st Floor, Central Facility Building,
MIHAN SEZ, Near Khapri (Rly.), Nagpur
- 441 108
Tel: No.07122815611 / 650
Fax No. 07122815601

3
3.1

MISCELLANEOUS PROVISIONS

Site Inspection
i.

The Applicants may prior to submitting their offer, visit and examine the Plot and its
surroundings at their own expense and obtain and ascertain for themselves, at their own
responsibility, all technical site data and other information necessary for preparing their
offer. For this purpose, MADC will endorse the Applicants’request for permission for a
site visit. The Applicants shall be responsible for all arrangements and shall release and
indemnify MADC, and/or its agents from and against all liability in respect thereof, and
shall be responsible for any personal injury, loss of or damage to property or any other
loss, damage, cost or expenses, however caused, which, but for the exercise of such
permission, would not have arisen. The Applicants shall be deemed to have full
knowledge of the site, whether physically inspected or not. MADC will not accept any
responsibility or liability for any errors, omissions, inaccuracies or errors of judgment
with respect to information or materials provided by MADC, in this offer document or
otherwise, with respect to this site and their surroundings. Although such information
and materials are correct to the best of MADC's belief, however, their verification is the
sole responsibility of Applicant.

ii) While this offer document has been prepared in good faith, neither MADC nor its directors,
or employees or advisors/consultants make any representation or warranty, express or
14

<!-- page 15 -->

implied, or accept any responsibility or liability, whatsoever, in respect of any statements
or omissions herein or the accuracy, completeness or reliability of information contained
herein, and shall incur no liability under any law, statute, rules or regulations as to the
accuracy, reliability or completeness of this offer document, even if any loss or damage is
caused to the Applicantin connection with anything contained in this offer document and
the award of the Project or otherwise arising in any way from the selection process.

4
4.1

GENERALTERMSAND CONDITIONS

Application of Law
i) The lease of the Plot shall be governed by the provisions of the Multi-modal International
Hub Airport at Nagpur (Disposal of Land) Regulations 2018 published in the Maharashtra
Govt. Gazette, Extra ordinary Part 1A, Nagpur Division Supplementary dated 10th Dec
2016 from page 1 to 15 and the policies framed by MADC under it shall form part of the
agreement to lease/lease deed.
ii) The development of the Plot shall be governed by the provisions of the UDCPR, National
Building Code of India as amended from time to time, Ministry of Civil Aviation
guidelines of height restrictions, statutory requirements, and other Government
rules/regulations and the principles of Good Industry Practices as may be relevant and
applicable. The intending lessee shall take all the clearances/consents from the concerned
authorities, as may be required by any law for the time being in force, for the development
and operations of the Project on the Plot.
iii) The intending lessee shall ensure and procure that its sub-contractors comply with all
applicable laws and procure permits in the performance by them of any of the intending
lessee’s obligations under the agreement to lease/lease deed and the leave and license
agreement.

4.2

Terms of Lease

4.2.1 The term of lease of the Plot shall be for a period of 66 years from the date of execution of
Agreement to Lease. Lease may be extended for further period as per the prevailing MIHAN
(Disposal of Land) Regulation.
4.3

Schedule of Payment of agreed Lease Premium: -

4.3.1 Schedule of Payment: As specified in Annexure I.
GST, as applicable, would be charged ‘Extra’ over the Lease Premium, Lease Rent etc.
4.3.2 Grant of Extension of time for making payment of instalments:
a) The Managing Director may extend, from time to time, the foregoing periods of
payment of installments for a period not exceeding one hundred and eighty (180)
days in aggregate, on payment of delayed payment charge for such extension & as
per provisions of MIHAN LDR 2018.
b) The intending lessee shall have to apply for grant of extension in the time limit
before expiry of the due date for that installment.
4.3.3 Determination of Concluded Agreement:- On failure of the intending lessee, to pay the
lease premium within the stipulated period as aforesaid including the extended period, if any,
the concluded agreement shall stand determined and the EMD deposited by the intending
lessee shall stand forfeited; and in addition to the EMD, so forfeited, 25% of the amount of
15

<!-- page 16 -->

installment or installments of the lease premium paid by the intending lessee shall also stand
forfeited to MADC, without prejudice to the rights of MADC to recover compensation for
loss or damage, if any, suffered in consequence of such default.
4.4

Payment of License Fees or Lease Rent (whichever is applicable)
As per clause 2.3 (c).

4.5

Mode of payment
The payment of installment of the lease premium, lease rent or any other charges shall be
paid separately by Demand Draft/Pay order/NEFT/RTGS transfer in the bank details of
Maharashtra Airport Development Company Ltd.

4.6

Delay Payment Charges
The prevailing rate of Delayed Payment Charges is Average of previous financial year base
rate of SBI + 2% per annum (simple rate). This is subject to revision, from time to time as
per prevailing policy.

4.7

Grant of “No Objection Certificate” to mortgage the Plot
On request of the intending lessee, MADC may grant No Objection Certificate to enable the
intending lessee to obtain loan from the Central or any State Government, Life Insurance
Corporation, the Maharashtra State Financial Corporation, Nationalized Bank or any other
Financial Institution as may be approved by MADC for construction / development of the
Plot. No Objection Certificate will be given subject to the following conditions:
i) There should not be breach of any of the conditions of the Letter of Acceptance,
ii) The intending lessee shall apply to MADC along with a letter from Central
Government, any State Government, Life Insurance Corporation of India, the
Maharashtra State Finance Corporation, the Nationalized Bank or any other Financial
Institution, agreeing, to grant loan to the intending lessee for construction /
development of the Plot.
iii) No lien of any of the financial institutions will be created on the Plot, unless the
intending lessee pays to MADC the entire amount of lease premium and other
miscellaneous charges and also executes with the MADC the agreement to lease and
gets the same registered.
iv) In case of enforcement of the mortgage by the banks or financial institutions the transfer
of the Plot to any intending lessee will be permitted only in favour of an equally
competent transferee subject to approval from MADC.

4.8

Demarcation plan
i) On payment of the full amount of agreed lease premium and other miscellaneous charges,
the Plot will be demarcated in the presence of the intending lessee or his representative
duly authorized by him. Demarcation plan will be enclosed with the Agreement to Lease.
ii) During the course of final demarcation, if the area of the Plot is found in excess of the
area represented in the offer document then, it shall be the sole discretion of the Vice
Chairman & Managing Director of MADC, (a) to allot this excess area to the intending
lessee at the specified rate of lease premium, prevailing at the time of such allotment or
the rate at which the allotment of original plot was made to the intending lessee,
whichever is higher, or (b) to treat such excess area as a separate plot. In case this excess
area is offered to the intending lessee, he shall have to accept the same and pay the lease
premium and other charges equivalent to the excess area.

16

<!-- page 17 -->

4.9

User and Floor Space Index (FSI)
i) The use of the Plot shall be as indicated in the instruction to Applicant in the offer
document, which shall not be changed or increased respectively, irrespective of the land
uses and FSI permitted in the Unified Development Control Promotions Regulations for
the MIHAN notified area.
ii) FSI Permitted will be as per UDCPR 2020. The lessee should not use the land u/r for any
other purpose than mentioned at Annexure - I.

4.10 Payment of Service Cost/Charges
Immediately after the expiry of period for the first phase, or immediately after the grant of
occupancy certificate either in part or in full by the Town Planning Officer, whichever is
earlier, the intending lessee shall pay service cost/charges as per prevailing rate, towards
establishing and maintaining civic amenities such as roads, streetlight, water, drainage,
conservancy and other civic services, regardless of any benefit derived or not by him for
such amenities or services. The rate of service cost/charges is subject to revision by
MADC, from time to time.
4.11 Restriction against Transfer of Right under Agreement to Lease/Lease Deed
The intending lessee shall not be allowed to transfer wholly or partially the rights, benefits
and interest derived in respect of the Plot under the agreement to lease/lease deed without
the written consent of MADC.
4.12 Fencing during construction
The intending lessee shall fence the Plot within a suitable period from the date of execution
of agreement to lessee. The intending lessee shall not encroach upon any adjoining land,
road, pathway or footpath of MADC in any manner whatsoever. Any such encroachment
shall be deemed to be a breach of conditions on which the offer was accepted.
4.13 Time for Submission of Plans
The intending lessee shall submit plan of the building, structure or other work to be erected
on the Plot, to the Town Planning Officer of MADC, being the Special Planning Authority
for the MIHAN notified area, for its approval within a period of three (3) months, from the
date of execution of the agreement to lease. In case of delay in submission of plans
complete in all respect to the Town Planning Officer, the intending lessee shall pay to
MADC charges for delay at the rate of Rs. 5000/- per month or part thereof for delayed
period.
4.14 Time for Completion of Construction
The intending lessee shall have to complete construction as specified in Annexure I of this
RFP document.
4.15 Extension of Time for Completion of Construction
If the intending lessee is not able to complete the minimum construction within the
stipulated time from the date of agreement to lease, then the Vice Chairman & Managing
Director of MADC on the request of the intending lessee may grant extensions on payment
of additional premium as per the extension policy of MADC.
4.16 Time being the essence of the contract
The various time limits prescribed for making payment of the instalments of the agreed
lease premium, for submission of plans to the Town Planning Officer and completion of
construction of building, structure, other work shall be the essence of the contract.
17

<!-- page 18 -->

4.17 Infrastructure Facilities
MADC shall provide infrastructure facilities like approach roads, water supply, drainage
and sewerage laid upto the nearest feasible boundary of the Plot. All charges for water,
storm water drain, sewage/garbage disposal etc. and other services availed by the intending
lessee shall be borne by the intending lessee.
4.18 Power connection
Power (electricity supply) connection, consumption deposits and other charges will be paid
directly by the intending lessee to the Maharashtra State Electricity Distribution Company
Ltd. (MSEDCL) or any other authority supplying power in the said area, from time to time.
The intending lessee will obtain directly from the above said authority power connection
by completing the formalities as prescribed by them in this behalf.
4.19 Utility and Infrastructure
The intending lessee shall not alter the location of sewer, water, power, telecommunication
and other services installed by MADC. The intending lessee shall ensure that all existing
utilities and associated infrastructure are kept in continuous satisfactory use while carrying
out construction on site and in case of any such damage to undertake the repair and also to
pay for any losses and expenses, that is incurred by MADC or any authority or any other
person, as the case may
4.20 Excavation
The intending lessee will not make any excavation upon any part of the land agreed to be
leased or remove any stone, earth or other material except so far as may be in the opinion
of MADC be necessary for the purpose of forming the foundation of the building and
compound walls and executing the work duly authorised. The intending lessee shall ensure
that the surrounding plots and common areas possessed by MADC or persons claiming
through them are not disturbed in anyway.
4.21 Payment of Rates and Taxes
The intending lessee shall bear and duly pay and discharge all existing and future taxes,
land revenue, rates, assessment, cess, duties, impost, penalties, and outgoings of every
description from the date of handing and taking over the plot and assets built thereon in
connection with or incidental to the performance of the obligations of the intending
lessee/lessee under the agreement to lease/lease deed.
4.22 Indemnity
The intending lessee/lessee shall indemnify, defend, save and hold harmless MADC and
its officers, servants, agents and consultants against any and all suits, proceedings, actions,
demands and third party claims for any loss, damage, cost and expense of whatever kind
and nature arising out of any breach by the intending lessee of any of the terms and
conditions under the agreement to lease or lease and shall be responsible to:
a) payment of taxes required to be made by the intending lessee in respect of the income
or other taxes of the intending lessee’s contractors, suppliers and representatives; or
b) non-payment of amounts due as a result of materials or services furnished to the
intending lessee or any of its contractors which are payable by the intending lessee or
any of its subsidiaries, affiliates, contractors, servants or agents; or
c) any claim, suit, proceeding, action, and/or demand has arisen due to a negligent act or
omission, or breach of any of its obligations under any provision of the agreement to
lease and/or breach of its statutory duty on the part of the intending lessee, its
18

<!-- page 19 -->

subsidiaries, affiliates, contractors, servants or agents.
4.23 Prohibited Activities
The Plot agreed to be leased, and the constructed units thereon shall not be allowed to be
used for:
a) any activity which can cause emission, odour, liquid, effluent, dust, smoke, gas, noise,
vibration or fire hazard or declared as obnoxious by MADC or by any other statutory or
local body/authority.
b) Any activity or use of premise, which may adversely affect the airport operation or its
safety
c) Activities which are prohibited by the Maharashtra Pollution Control Board or any such
authority or involves any discharge or emission of hazardous pollutant.
d) any illegal business/activities
e) storage of any prohibited articles or commodities, which could cause damage to the units
constructed or neighbouring occupier and shall observe strictly the rules and regulations
of the Government and local authorities in that behalf.
f) erect or permit to erect on any part of the site, any stable, sheds or other structures of any
description whatsoever for keeping horses, cattle, dogs, poultry or other animals and keep
on the site or constructed units, any animals.
g) carry on or allow to be carried on, by any of its employees, agents, contractors or invitees,
any unlawful, illegal or immoral activities, which may be considered offensive or a
source of any annoyance, inconvenience or nuisance to the area surrounding the plot in
the MIHAN notified area.
4.24 Insurance
The intending lessee shall take necessary insurance of the building or structures constructed,
agreed to be leased at its costs throughout the term of the lease and keep the same valid for
the market value thereof. In the event of destruction or damage to the building or structures
on the plot agreed to leased or any property appurtenant thereto and, in case of any such
eventuality, the intending lessee shall, reconstruct or repair the building or structures either
from the insurance proceeds or otherwise.
4.25 Execution of Agreement to Lease
i)

Within the period of thirty (30) days from the date of full and final payment of agreed
amount of lease premium and other charges, to MADC, the intending lessee shall
execute with MADC the agreement to lease in terms of the offer document and the
MADC Land Disposal Regulations. However, on request of the intending lessee the
Vice Chairman &Managing Director of MADC may extend the aforesaid time
prescribed for the execution of agreement to lease, maximum by hundred and twenty
(120) days on the payment of watch & ward charges applicable, from time to time.

ii)

Under the agreement to lease, the intending lessee will get the license and authority to
enter upon the Plot to fulfil the terms and conditions of the agreement to lease.

iii) In case the agreement to lease is not executed within the specified period or extended
period as indicated above, the agreement concluded between MADC and intending lessee
shall be liable to be terminated; and in the event of termination of the concluded
agreement, the earnest money deposit, along with 25% of the amount of instalments of
the lease premium, if any, paid, shall be forfeited without prejudice to the rights of

19

<!-- page 20 -->

MADC to recover compensation for loss or damage, if any, suffered in consequence of
such default by the intending lessee.
4.26 Execution of Lease Deed
Soon after the intending lessee obtains the partial or full occupancy certificate for the
building, structure or other work, in accordance with the terms and conditions stipulated in
the agreement to lease, and if the intending lessee has observed all the stipulations and the
conditions of the agreement to lease, MADC shall grant and the intending lessee shall
accept a lease of the Plot, along with building, structure or other work erected thereon and
the period of lease shall commence from the date of agreement to lease.
4.27 Power of MADC to Terminate Agreement to Lease and revoke License granted therein,
as well as to determine the Lease deed and to resume the land
i) In case the intending lessee fails to submit plans to the Town Planning Officer of MADC,
to commence and complete the construction in accordance with approved plan and within
the period stipulated for the same, fails to proceed with the work with due diligence, fails
to observe any of the conditions of the agreement to lease, fail to commence construction
within six (6) months from the date of agreement to lease, fails to complete the
construction within the prescribed period or extended period then MADC shall terminate
the agreement to lease and shall revoke the licence granted therein, without making
refund of any lease premium, additional premium, any other charges paid by the
intending lessee to MADC and also without making any payment to the intending lessee
towards the construction, erection made and carried out by the intending lessee on the
plot. Immediately after the termination of the Agreement to Lease all erections,
construction carried out on the plot till such termination, including plants, things upon
the plot shall stand ceased.
ii) After grant of lease, if the Vice Chairman &Managing Director of MADC is satisfied
that it is beyond the capacity of the lessee to use the demised premises for the purpose
for which they are leased, the lessee fails or neglects to pay the premium or rent or
commits a breach of any of conditions of lease, if the Lessee renounces his character as
such by setting up a title in a third person or if the lessee is adjudicated as insolvent, then
MADC is entitled to determine the lease and re-enter upon the demised premises.
4.28 Payment of Stamp Duty and Registration Charges
The intending lessee shall bear and pay wholly and exclusively the stamp duty payable
under the Maharashtra Stamp Act (LX of 1958) and the registration charges payable under
the Registration Act, 1908 (XVI of 1908) on the agreement to lease/lease deed and any
other agreement required to be executed under any law for the time being in force, to be
executed between MADC and the intending lessee.
4.29 Payment of Labour Welfare Cess
The intending lessee shall bear and pay wholly the Labour Welfare Cess as per Regulation
of Employment and Conditions of Service Act, 1996 and the Building and Other
Construction Workers Welfare Cess Act, 1998 and Government of Maharashtra Circular
dated 21st April, 1998.
4.30 Interpretation of conditions
In case of any dispute as regards the interpretation of any of the conditions stipulated herein
the final decision rests with the Vice Chairman & Managing Director of MADC and will
be binding on all parties as the award of Arbitrator.

20

<!-- page 21 -->

5

CONFIDENTIALITY

The Parties undertake to hold in confidence this offer document and not to disclose the terms
and conditions of the transaction contemplated hereby to third parties, except:
a) to their professional advisors;
b) to their officers, contractors, employees, agents or representatives, financiers, who need
to have access to such information for the proper performance of their activities;
c) disclosures required under applicable Law, Without the prior written consent of the
other parties of the concerned Agreements. Provided that the successful Applicant
agrees and acknowledges that MADC may at any time, disclose the terms and
conditions of the offer document to any person, to the extent stipulated under the
applicable laws.
5.1

FRAUDULENT AND CORRUPT PRACTICES
i)

The Applicants and their respective officers, employees, agents and advisers shall observe
the highest standard of ethics during the RFP process and subsequent to the issue of the
Letter of Acceptance. Notwithstanding anything to the contrary contained herein, or in the
Letter of Acceptance, MADC shall reject an offer, withdraw the Letter of Acceptance, as
the case may be, without being liable in any manner whatsoever to the Applicant, if it
determines that the Applicant has, directly or indirectly or through an agent, engaged in
corrupt practice, fraudulent practice, coercive practice, undesirable practice or restrictive
practice in the RFP process. In such an event, the EMD shall stand forfeited to MADC,
without prejudice to any other right or remedy that may be available to MADC hereunder
or otherwise.

ii)

For the purposes of the Clauses 5(i) hereinabove, the following terms shall have the meaning
hereinafter respectively assigned to them:
“corrupt practice” means (i) the offering, giving, receiving, or soliciting, directly or
indirectly, of anything of value to influence the actions of any person connected with the
RFP process for avoidance of doubt, offering of employment to or employing or engaging
in any manner whatsoever, directly or indirectly, any official of MADC who is or has been
associated or dealt in any manner, directly or indirectly with the RFP process or the Letter
of Acceptance or has dealt with matters concerning the Agreement to Lease/Lease Deed or
arising there from, before or after the execution thereof, at any time prior to the expiry of
one(1) year from the date such official resigns or retires from or otherwise ceases to be in
the service of MADC, shall be deemed to constitute influencing the actions of a person
connected with the bid process); or (ii) engaging in any manner whatsoever, whether during
the RFP process or after the issue of the Letter of Acceptanceor after the execution of the
Agreement to Lease/Lease Deed, as the case may be, any person in respect of any matter
relating to the competition of construction or the Agreement to Lease/Lease Deed, who at
any time has been or is a legal, financial or technical adviser of MADC in relation to any
matter concerning the Project;

5.1.1“fraudulent practice” means a misrepresentation or omission of facts or suppression of facts
or disclosure of incomplete facts, in order to influence the RFP process;
5.1.2

“coercive practice” means impairing or harming, or threatening to impair or harm, directly
or indirectly, any person or property to influence any person’s participation or action in the
RFP process;

5.1.3

“undesirable practice” means (i) establishing contact with any person connected with or
employed or engaged by MADC with the objective of canvassing, lobbying or in any
21

<!-- page 22 -->

manner influencing or attempting to influence the RFP process; or (ii) having a Conflict of
Interest; and
5.1.4

“Restrictive practice” means forming a cartel or arriving at any understanding or
arrangement among the Applicants with the objective of restricting or manipulating a full
and fair competition in the RFP process.

6
6.1

CHECKLIST OF SUBMISSION

The Applicant shall ensure the submission of the following documents on the address:
Proposal Envelop:
i)

Transmittal Letter in the format as specified in Exhibit I hereto.

ii)

INFORMATION ABOUT APPLICANT as per Exhibit V along with documentary
proof.

iii)

Technical & Financial Details as per Exhibit VI & VII

iv)

Certificate of Company Incorporation/Registration Certificate issued by the Deputy or
Assistant Charity Commissioner in the Public Trust Registration Office under
Maharashtra/Any state Public Trust, 1950 and / or issued by the Registrar of Societies
under the Societies Registration Act, 1860.Registered Trust Deed

v)

Articles of Association and Memorandum of Association with all Amendments in case
of a Society registered under the Societies Registration Act, 1860.

vi)

(If applicable) Principles of Memorandum of Understanding between Consortium
Members as per Exhibit II.

vii)

Power of Attorney in the format as specified in Exhibit III hereto for signing the offer,
wherever required in favour of the person executing the offer for the delegation of power
hereunder on behalf of the Trustee/Trustees.

viii)

Resolution of the Board of Trustees authorising the Trustee/Trustees to execute the offer.

ix)

Further documents to be submitted along with the Proposal:
a) GST Registration Certificate
b) PAN Card
c) Audited balance Sheet (ITR in case of Proprietorship) for 3 preceding financial
years copy.
d) Project Report (With details as mentioned in the RFP hereinabove).

x)

A notarized declaration on Rs. 100/- Stamp Paper confirming the entity is not blacklisted
or debarred

xi)

The original RFP document, along with any addenda or corrigenda, signed and stamped
on every page

xii)

Copies of payment of Scheme Document Fee and EMD amount payment

Note: -The above check list is only illustrative and does not control in any manner whatsoever
the aforesaid substantive provision of this offer document and other relevant provision.

22

<!-- page 23 -->

Annexure I: Details of Plot
Particulars

Details

Plot Details

Plot No. 8, Sector 10 Outside SEZ of MIHAN

Approx. Area (in Sq. 490596.79 sq.mtr. (i.e.121.229 acre)
Mtr.)
Specified Rate of lease Rs. 5700/Premium (In ₹/ sq. mtr)
Use of Land

For Industrial use of an ecosystem spanning Aerospace & Defense
Components, Aircraft Manufacturing, Assembly and allied use
with Airside Taxiway Connectivity outside SEZ area of MIHAN

FSI Permitted

As per the Unified Development Control Promotions Regulations

EMD in ₹

Rs. 28.00 Crores (Rs. Twenty-Eight Crores Only)

Size of Plots

Large-Size Plot

Permissible FSI

As per UDCPR

Average
Turnover
Applicant

Annual The Applicant, together with its group company if any should have
of
the a minimum consolidated average annual turnover of Rs.1.00
Lakhs Crore in the last 03 financial years. This must be supported
by a certified Chartered Accountant.

Experience
Applicant

of

Payment
Premium

of

the The Applicant must be actively engaged in Aerospace, Defense,
OEM Manufacturing, Component Sub-assembly, Aerospace
Systems etc. for at least the last Ten (10) years.
Lease Lease premium shall be paid in 03 equal instalments, of which
the first within Thirty (30) days
the second within Ninety (90) days
the third within One Hundred Eighty (180) days from the date of
receipt of Letter of Acceptance.

23

<!-- page 24 -->

Annexure II: Master Plan
Plot location on MIHAN Master Plan

24

<!-- page 25 -->

Annexure III: Location Plan
Plot No. 8 at Sector 10 outside SEZ of MIHAN

+

25

<!-- page 26 -->

EXHIBIT I: Transmittal Letter
(The transmittal letter is to be submitted by the Applicant on its letter head, along with the
Proposal)
Date: …………
Place: …………
To:
The Vice Chairman & Managing Director,
Maharashtra Airport Development Company Ltd. (MADC)
8th Floor, Centre-1, World Trade Centre,
Cuffe Parade, Mumbai – 400 005.
Sub: Request for Proposal (RFP) for setting up an ecosystem spanning Aerospace & Defense
Components, Aircraft Manufacturing, Assembly, and MRO Facility with Airside Taxiway
Connectivity outside SEZ area of MIHAN
Sir,
MADC has invited proposal for referred subject.
1. Please find enclosed Proposal in respect of Selection of Successful Applicant for Request for
Proposal (RFP) for setting up an ecosystem spanning Aerospace & Defense Components,
Aircraft Manufacturing, Assembly, and MRO Facility with Airside Taxiway Connectivity
outside SEZ area of MIHAN, issued by Maharashtra Airport Development Company Ltd.
(“MADC”) dated _____________.
2. We hereby confirm the following:
a) The Proposal is being submitted by ___________________ (name of Applicant) in
accordance with the terms and conditions stipulated in the Offer Document.
b) As the Applicant we hereby agree and confirm to abide by the terms and conditions of the
RFP Document.
c) We have examined in detail and have understood the terms and conditions stipulated in the
Offer Document issued by MADC and in any subsequent communication sent by MADC.
We agree and undertake to abide by all these terms and conditions. Our offer is consistent
with all the requirements of submission as stated in the Offer Document or in any of the
subsequent communications from MADC.
d) I/We confirm that there are no conditions in “Financial Proposal”.
e) The information submitted in our offer is complete, is strictly as per the requirements
stipulated in the RFP Document and is correct to the best of our knowledge and
understanding. We would be solely responsible for any errors or omissions in our offer.
f) I/We confirm that I/We have received the corrigendum/addendum dated ___________
(Please write date, if issued), if any, issued by MADC and undertake to abide by the same as
if it is part of the offer document.
g) I/We confirm that I/We have studied the provisions of the relevant Indian laws and
regulations required to enable us to prepare this Proposal and as required to establish the

26

<!-- page 27 -->

project outside the SEZ of the MIHAN notified area.
h) I/We agree that this offer shall remain valid for One Hundred and Twenty (120) days from
the date of opening of the Proposal and will not revoke it before the expiry of One Hundred
and Twenty (120) days from the date of opening of the Proposal and in the event of my/our
failure to keep the offer open for One Hundred and Twenty (120) days from the date of
opening of the Proposal, the earnest money paid by me/us under this offer shall be forfeited
to MADC.
i) Pursuant to submission of our offer to MADC, we are enclosing herewith the Proposal
containing the documents/information as stated in Clause 6 of the offer document.
j) A notice or letter of communication addressed to me/us at the address given under clause
above, even by ordinary post, will be deemed as valid and proper notice of intimation to
me/us.
k) I/We agree to abide by the decision of the Vice Chairman &Managing Director, MADC
regarding allotment, which shall be final.
l) I/We declare that I/We have read and understood the entire offer document including the
General Terms & Conditions, inspected the condition of physically available infrastructures
on the site of the plot offered as well as title deed of land, plans and specification of the land,
examined the draft of Agreements to Lease/ Lease Deed to be executed and do hereby
undertake to execute them when called upon to do so, and abide by the decision of the
concerned authority of MADC.
m) I/We declare that the information stated herein above is correct and any error or otherwise
will be sufficient justification for MADC to revoke at any time acceptance of my/our offer
for allotment of the concerned plot.
n) I/We understand and accept that MADC has the right to amend, revoke or modify the scheme
at its discretion as well as to reject any or all offers received without assigning any reason.
3. Earnest Money Deposit
I/We have paid EMD & Scheme document fee of specified amount; details are as follows:

For and on behalf of the Applicant:
Signature:
(Authorized Representative and Signatory)
Name of the Person:
Designation:

27

<!-- page 28 -->

EXHIBIT II: PRINCIPLES OF MEMORANDUM OF UNDERSTANDING BETWEEN
CONSORTIUM MEMBERS
Principles of Memorandum of Understanding between Consortium Members
1. In case of a Bidding Consortium, the principles according to which the Memorandum of
Understanding (MoU) shall be executed between/among the Consortium Members are stated
below:
(a) The MoU should clearly specify the roles and responsibilities of each of the Consortium
Members, along with their proposed equity contribution.
(b) The MoU should clearly designate one of the Consortium Members as the Lead
Consortium Member.
(c) The Lead Consortium Member shall be responsible for:
(i) Tying up finances required for acquiring the plot/plots.
(ii)Ensuring the individual and collective commitment of each of the Consortium
members in honouring the Applicants’ obligations towards MADC. The Lead
Consortium Member would be responsible for the execution of agreement to lease.
(d) The MoU shall be duly signed by each of the Consortium Members.
(e) The MoU should be executed on appropriate stamp paper and should be specific to this
RFP.
(f) The MoU should be valid for a minimum period of twelve (12) months from the last date
for submission of the RFP. The validity period of the MoU should be extendible on the
original terms, if required by MADC.
(g) The Undertaking should be specific to this RFP.
(h) MoU should clearly specify that in case of selection of the Applicant for allotment of
plot/plots, each consortium member will invest at least 11% equity and Lead Consortium
member more than 50% equity. Shareholding pattern and roles of each member of the
Consortium shall be prescribed as below:
Sr. No. Name of Consortium Proposed Min. Equity holding in Proposed role in the
Member
the Project Company (%)
Project
1
2
3
2. In case of a bidding company being a partnership firm/sole proprietorship firm, or a bidding
consortium in which any of the consortium members is a partnership firm/sole proprietorship
firm, apart from above, the undertaking should clearly specify that in the event of the bidding
company being a partnership firm/sole proprietorship firm or a bidding consortium in which any
of the consortium members is a partnership firm/sole proprietorship firm being selected as the
successful Applicant, and then such Applicant/consortium member(s) shall invest not less than
11% of the entire equity and more than 50% equity in case acting as Lead Consortium Member.

28

<!-- page 29 -->

EXHIBIT III: FORMAT OF POWER OF ATTORNEY FOR SIGNING OF PROPOSAL
Know all men by these presents, We___________(name of the firm/company and address of
the registered office) do hereby irrevocably constitute, nominate, appoint and authorise Mr/
Ms (name), ____________son/daughter/wife of ___________and presently residing at
_____________, who is presently employed with us and holding the position of
_______________, as our true and lawful attorney (hereinafter referred to as the “Attorney”)
to do in our name and on our behalf, all such acts, deeds and things as are necessary or required
in connection with or incidental to submission of our bid
for
“_______________________________________(Please write details of the plot to be
Proposal)”proposed or being developed by the Maharashtra Airport Development Company
Ltd (MADC) including but not limited to signing and submission of all applications, Proposals
and other documents and writings and providing information/ responses to the Authority,
representing us in all matters before the Authority, signing and execution of all contracts
including the Agreement to Lease and undertakings consequent to acceptance of our Proposal,
and generally dealing with the Authority in all matters in connection with or relating to or
arising out of our Proposal for the said Project and/ or upon award thereof to us and/or till the
entering into of the Agreement to Lease with MADCAND we hereby agree to ratify and
confirm and do hereby ratify and confirm all acts, deeds and things lawfully done or caused to
be done by our said Attorney pursuant to and in exercise of the powers conferred by this Power
of Attorney and that all acts, deeds and things done by our said Attorney in exercise of the
powers hereby conferred shall and shall always be deemed to have been done by us.
IN WITNESS WHEREOF WE, _______________, THE ABOVE-NAMED PRINCIPAL HAVE
EXECUTED THIS POWER OF ATTORNEY ON THIS _______DAY OF _________ 2026
For
________________
(Signature, name, designation and address)
Witnesses:
1.
2.
(Notarized)
Accepted
_______________
(Signature)
(Name, Title and Address of the Attorney)

29

<!-- page 30 -->

Notes:
•

The mode of execution of the Power of Attorney should be in accordance with the procedure, if
any, laid down by the applicable law and the charter documents of the executant(s) and when it
is so required, the same should be under common seal affixed in accordance with the required
procedure.

•

Wherever required, the Applicant should submit for verification the extract of the charter
documents and documents such as a resolution/ power of attorney in favour of the person
executing this Power of Attorney for the delegation of power hereunder on behalf of the
Applicant.

•

For a Power of Attorney executed and issued overseas, the document will also have to be
legalised by the Indian Embassy and notarised in the jurisdiction where the Power of Attorney
is being issued. However, the Power of Attorney provided by Applicants from countries that have
signed the Hague Legislation Convention 1961 are not required to be legalised by the Indian
Embassy if it carries a conforming Appostille certificate.

30

<!-- page 31 -->

EXHIBIT IV: FORMAT OF POWER OF ATTORNEY FOR LEAD MEMBER OF
CONSORTIUM
(On non-judicial stamp paper of Rs 100 /- duly attested by Notary Public)
Whereas the Maharashtra Airport Development Company Ltd (MADC) has requested Proposal
(RFP) for setting up an ecosystem spanning Aerospace & Defense Components, Aircraft
Manufacturing, Assembly, and MRO Facility with Airside Taxiway Connectivity outside SEZ area
of MIHAN.
Whereas, _____________, _____________and ___________(collectively the “Consortium”)
being Members of the Consortium are interested in bidding for the for
“_______________________________________(Please write details of the plot to be Proposal)
within Non-SEZ area of MIHAN, Nagpur in accordance with the terms and conditions of the Request
for Proposal (RFP) and other connected documents in respect of the Project, and Whereas, it is
necessary for the Members of the Consortium to designate one of them as the Lead Member with all
necessary power and authority to do for and on behalf of the Consortium, all acts, deeds and things
as may be necessary in connection with the Consortium’s Proposal for the Project and its execution.
NOW THEREFORE KNOW ALL MEN BY THESE PRESENTS
We, .having our registered office at _____________, and M/s. __________ having our registered
office at _____________ (hereinafter collectively referred to as the “Principals”) do hereby
irrevocably designate, nominate, constitute, appoint and authorise M/S _______________ having
its registered office at ____________, being one of the Members of the Consortium, as the Lead
Member and true and lawful attorney of the Consortium (hereinafter referred to as the
“Attorney”).We hereby irrevocably authorise the Attorney (with power to sub-delegate) to conduct
all business for and on behalf of the Consortium and any one of us during the bidding process and,
in the event the Consortium is awarded the concession/contract, during the execution of the Project
and in this regard, to do on our behalf and on behalf of the Consortium, all or any of such acts, deeds
or things as are necessary or required or incidental to the submission of its Proposal for the Project,
including but not limited to signing and submission of all Proposals and other documents and
writings, participate in bidding process and other conferences, respond to queries, submit
information/ documents, sign and execute contracts and undertakings consequent to acceptance of
the Proposal of the Consortium and generally to represent the Consortium in all its dealings with the
Authority, and/ or any other Government Agency or any person, in all matters in connection with or
relating to or arising out of the Consortium’s Proposal for the Project and/ or upon award thereof till
the Agreement to Lease is entered into with MADC.
AND hereby agree to ratify and confirm and do hereby ratify and confirm all acts, deeds and things
lawfully done or caused to be done by our said Attorney pursuant to and in exercise of the powers
conferred by this Power of Attorney and that all acts, deeds and things done by our said Attorney in
exercise of the powers hereby conferred shall and shall always be deemed to have been done by us/
Consortium.
IN WITNESS WHEREOF WE THE PRINCIPALS ABOVE NAMED HAVE EXECUTED THIS
POWER OF ATTORNEY ON THIS _______ DAY OF ____ 2026
For ___________
(Signature)
________________
31

<!-- page 32 -->

(Name & Title)
For _____________
(Signature)
________________
(Name & Title)
Witnesses:
1.
2.
_______________________________
(Executants)
(To be executed by all the Members of the Consortium)
Notes:
•

The mode of execution of the Power of Attorney should be in accordance with the procedure, if
any, laid down by the applicable law and the charter documents of the executant(s) and when it
is so required, the same should be under common seal affixed in accordance with the required
procedure.

•

Also, wherever required, the Applicant should submit for verification the extract of the charter
documents and documents such as a resolution/ power of attorney in favour of the person
executing this Power of Attorney for the delegation of power hereunder on behalf of the
Applicant.

•

For a Power of Attorney executed and issued overseas, the document will also have to be
legalised by the Indian Embassy and notarised in the jurisdiction where the Power of Attorney
is being issued. However, the Power of Attorney provided by Applicants from countries that have
signed the Hague Legislation Convention 1961 are not required to be legalised by the Indian
Embassy if it carries a conforming Appostille certificate.

32

<!-- page 33 -->

EXHIBIT V: INFORMATION ABOUT APPLICANT
(A) The following information needs to be provided by the Applicant
1.

2.

a) Name:
b) Country of incorporation:
c) Address of the Corporate headquarters and its branch office(s), if any, in India:
d) Date of incorporation and /or commencement of business:
e)
Brief description of the Company including details of its main lines of business and
proposed role and responsibilities in this Project:

3.

Details of individual(s) who will serve as the point of contact/ communication for
MADC:
a) Name:
b) Designation:
c) Company:
d) Address:
e) Telephone Number:
f) E-Mail Address:

4.

Particulars of the Authorized Signatory of the Applicant:
a) Name:
b) Designation:
c) Address:
d) Phone Number:

(B) Provide the following information for the Authorised Signatory of the Applicant to whom
Power of Attorney has been given.
Individual’s Name
Designation
Citizenship
Address
Telephone Number
Fax Number
E-Mail Address

33

<!-- page 34 -->

EXHIBIT VI: INFORMATION FOR EVALUATION OF THE TECHNICAL
ELIGIBILITY CRITERIA
1. Experience in Similar Projects / Experience in Similar Operations
Applicants must list project experience from the last 10 years relevant to the requirements of the
Technical Matrix
Sr.
No.

Facility
Project
Type Products,
Years of Experience
Name
& (Aerospace / OEM Capacity, Annual (From the Date of
Location
Mfg / Assembly / Production etc.
Incorporation)
Defense etc.)

1
2
3

Note: Applicants must attach copies of experience certificates, regulatory compliance licenses,
and performance reviews for each listed facility
2. Annual Turnover of the Applicant
Sr.
No.

Name
of
Company

the Financial Year

1

2023-24

2

2024-25

3

2025-26

Average Annual Turnover
(in Crores)

*This data must be certified and signed by a registered Chartered Accountant (CA) with their
official seal and registration number.
Instructions:
1. Only the eligible projects that satisfy technical eligibility criteria shall be included
2. The format shall be filled up for each member of the Consortium
3. In support of the information provided following documents must be submitted failing which
the specific claim shall not be considered for evaluation.

34

<!-- page 35 -->

▪

Completion Certificates from the client for the Experience claimed (Officer with
Rank Higher than Executive Engineer (in case of Government project).

▪

This Exhibit shall be duly certified by the Chartered Accountant/Statutory Auditor
along with the Respective Client in case of a private project.

4. The information must be submitted in the given formats. Any information not furnished
strictly in accordance with the formats and requirements shall not be considered for
evaluation.

35

<!-- page 36 -->

EXHIBIT VII: INFORMATION FOR EVALUATION OF THE FINANCIAL
ELIGIBILITY CRITERIA
1. Annual Turnover
Applicant type

(1)

Annual Turnover
Year 1

Year 2

Year 3

(2)

(3)

(4)

Single
entity
Applicant/Lead
Member
Consortium
Member 1
Consortium
Member 2
Consortium
Member 3
TOTAL
Instructions:
1. The Applicant/ its constituent Consortium Members shall attach copies of the balance sheets,
financial statements and Annual Reports for 3 (three) years preceding the Proposal Due Date.
The financial statements shall:
(a) reflect the financial situation of the Applicant or Consortium Members and its/ their
Associates where the Applicant is relying on its Associate’s financials;
(b) be audited by a statutory auditor;
(c) be complete, including all notes to the financial statements; and
(d) Correspond to accounting periods already completed and audited (no statements for
partial periods shall be requested or accepted).
The liquidity balance so submitted should be required to be duly supported by certificate
from the Chartered Accountant.
2. Year 1 will be the latest completed financial year i.e. i.e. 2025- 2026, preceding the bidding.
Year 2 shall be the year immediately preceding Year 1 and so on.
3. The Applicant shall also provide the name and address of the Bankers to the Applicant.
4. The Applicant shall provide an Auditor’s Certificate specifying the Net Worth of the
Applicant and also specifying the methodology adopted for calculating such Net Worth.

36

<!-- page 37 -->

EXHIBIT VIII: Financial Proposal Confirmation
(To be duly signed and submitted on the Letterhead of the Company)
Date:
The Vice Chairman and Managing Director
Maharashtra Airport Development Company Ltd.
8th Floor, World Trade Centre, Centre 1,
Cuffe Parade, Mumbai – 400 005.
Sub: Request for Proposal (RFP) for setting up an ecosystem spanning Aerospace & Defense
Components, Aircraft Manufacturing, Assembly, and MRO Facility with Airside Taxiway
Connectivity outside SEZ area of MIHAN
Sir,
1.

/We the undersigned Applicant, submit the following as response to the RFP document (the
“RFP Document”) issued by MADC as under:

2.

We confirm that the Financial Proposal conforms to all the terms and conditions stipulated in
this RFP document and as per Specified rate of Lease Premium.

3.

We confirm that our Financial Proposal is FINAL in all respects and contains NO conditions.

4.

We confirm that we have studied the provisions of relevant Indian laws and regulations
required to enable us to prepare this Proposal and as required to construct and establish the
Project in the event that we are finally selected.

Thanking You,
Yours Sincerely,
Signature: (Authorized Representative and Signatory)
Name & Designation of the Authorised signatory
Name and seal of Applicant

37
