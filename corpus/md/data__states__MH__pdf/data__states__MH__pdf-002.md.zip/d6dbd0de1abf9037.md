---
doc_id: "d6dbd0de1abf9037"
source_url: "https://transport.maharashtra.gov.in/Site/Upload/GR/Metered_Taxi_Tariff_Card.pdf"
ministry: "Motor Vehicles Department ( R.T.O.), Maharashtra"
title: ""
date: ""
pages: 4
method: "tesseract:mar+hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "2a5d53cbe00e5786"
---

<!-- page 1 -->

* MINIMUM FARE Rs. 33.00
* for subsequent per kim. Rs, 21.90 (rounded off to nearest rupee)
* 25% additional fare for journey from 12.00 midnight to 05.00 am
* AC black and yellow taxi fare will be 10% higher than basic black and yellow tani fare,
[Norma | ४०१५१. | | mipnicHr |
OLD FARE| REVISED | OLD FARE] REVISED OLD FARE] REVISED | OLD FARE) REVISED OLD FARE 00 FARE | REVISED
(RS.) FARE (RS.)} (९) |FARE(RS.) (RS.)|FARE(RS.)} (RS.) | FARE (RS.) (RS.) (Rs.) | FARE (७.]|
- {33 | [90 s0g az | 347 |
1 हा जा || [sz | tos | सा | | 19 | छह | छछ |
[aa | | छ [9a | 1151 | कह | 385 |
| 39 |_4 | 49 | ae अका [ 19 | उक | उक्ट |
क जल कडक कडा. ळा आळ आत. | | | 75 [वक | asa |
| 1 | 44 | 9) | ७ ] | 126 | | 358 | उ& | 3७7 |
| % | ५94 | 9७7 ] [403 | व? | 129 | | 200 |
| 60 | | 109 | 124 | 762 | उ | ३ळ |
jas | so | 99 | es | | उठ | aa7_ | 434 || | 184 | 379 [205 |
50 ७ | ७] 129 | ७ | 7२७ |
52 ae | | 112 [aga | 140 | | 159 | 3169 | 799 [aaa |
| ७7 | 67 [irae [201 | aaa |
56 1 59 | 8 | a6 | 7 | 15% | [204 | 216)
98 | ह | 7 12 [207 | झक |
ळ | ७ | ७ | 79 114 120 | [209 | २३४ |
| 66 7 682 116 123 | 353 | | 180 | 29 | aa
ca | 68 | 0 | 85 118 125_|__147 | शक |
० 0 | 83 | 88 120 327 150 | 159 | | 184 | सत्र | छ6
बाधा as [90 122 129 | 15 | बह? | | 186 | 270 | 23a |
70 | 74 | ४७ | 93 | 124 3131 | 155 | 164 | 188 | उठ | 235 |
_72 | 7 | 9 ॥ 96 126 134 पक | 167, 180 by Ee
| 4 | 9 | 9 9 कं 128 | 136 | 100 | 170 182 | 20 |
ee ७ | 9७ | 1०७ 190 | 1# [| 16 | 17? 88 | ७ [230 [aaa]
ee 0 | 109 2 | 140 | 16 | गळ 180 | व [aaa [2a
01 | 85 1७ | 71७ 134 पा | 16 | 178 _188 | 19 | खत | aaa]
७ | ७ | 103 | 110 | 16 | 185 [10 [aan [190 [ 20 |
MMRTA REGION

<!-- page 2 -->

| छठ [monic] | MipnicHt | [Normat |
OLD FARE} REVISED | OLD FARE} REVISED OLD FARE| REVISED | OLD FARE] REVISED OLD FARE| REVISED | OLD FARE
(RS) [FARE(RS.)| (RS.) | FARE(RS.) (RS.) |PARE(RS.)] (७.) | FARE (RS.) (Rs.) FARE (RS.)| (७)
| 204 | 248 | २७ | | 261 | 307 | ३२७] | 30 | 338 | ऊऋ ४ [357 |
| isa | 20& | | 263 | 310 | ३329 | | 320 | आए | ३0 |
| 208 | २७ | 26 | | 26 | siz | उठ | | उठ | 38 | 4०२ |
| 79 | रा | 748 | 263 | | 252 [267 | 35 | 330 | | ३२4 | उ8 | 40 |
| २२ | 39 | २७ | | 29 | sis | उठ | | 308 | उउ6 | उ85 | 408 |
| 25 | २७9३ [268 | | 39 | | 329 |
|_34२ | | 32 | उठा | 39 | 4४३ |
| 29 | | उ25 | 34% | | 314 | 333 | 393 | 416 |
| 2०9 | है 262 | 27s | उउ8 | 348 | | 36 | उठछ5 | 395 | ३99 |
[223 | 263 | २7७ | | 359 | | बट |
| 226 | २७ | २७ | a | 283 | 333 | 353 | | 320 | 339 | ३0 | 425 |
2४४ | 269 | उछ | | 3७ _ 2७ [36 | 356] 139]
| 2३8 | रस | 287 | | 359 | | 32a [saa | ३0 | ३30 |
2221290] 12७1391301] [3४ | ७ [४७]
[236 | 7७ 112981] [29 [308 | उछ | 13७1190145
[236] [293] [7380 [ais [a8]
| 239 | 281 | 238 | | 29 | 349 | 3३7० | | 353 | 46 | aan
1301] : [298 —| [ass] ais aes]
| ख | 28 [304] | 300 | 354 | उ75 | | ३७७ |
| 2455 | | 3० | | 359 | 324 | ३७ |
a कळ] 139] 2]
२७% ४] 3७] 1350144]
[28 [ 252 [297 | a5] [309 | 36 | 386 | का आया [as]
3222232 BPS 12151]
[२७11991331 २७ ३७ 97901 [अश ७18511
जी REGION

<!-- page 3 -->

[—nowwmat —] [|
OLD FARE] REVISED | OLD FARE| REVISED OLD FARE] REVISED | OLD FARE] REVISED OLD FARE a OLD FARE | REVISED
(RS.) FARE (RS.)] (RS.) FARE (RS.)| (RS.) FARE (RS.) (RS.) | FARE (RS.)| (RS.) FARE (RS.)| {RS.) FARE (RS.)
| 00७ | ७8 (का क्छ | | 08 | ७0 | कह | ७97]
[ara] [a6 [sia] 505 —] [क 9७ छह |
| 381 | 449 | | 438 | | 95 | 58 |
[363 | [4७ ७ | 550 _| 1 0७9 | ७9 | see] ea]
[ses | के | a2] [aa [saz | 5७७7] | ७9 | 509 | ६24]
[308 | | ७७ | 58 ब्छ | [1992]
[39 _ ७७ | कक] ॥ 5998] [ &0 |
| उ02 | 462 | 49 | | 49 | 529 | 561 | | ७32 ।
[398 | 3७ | 493 | ॥ 48 | 52 sea] 1195]
13909७4911] ॥ 493] 185]
0" | 39 | | 330 | 495 | 537 | 56 | | ७2 | 60 | gat]
॥ ४७8350] है [58 | [8७]
[७७8 | #ऋ (७ ] 1४७5७95] [69 | es |
| 406 | 48 | 5७ | [462 | | 539 | 519 | ७? | 69 |
है 386 | 90 | 483 | | 5350 | 46 | 55 | 583 | | 494 | 523 | 67 | 659 |
| 515 :] a4 | 469 | 553 | 586 | | 496 | 526 | 620 | छछ |
| 39 | कह | 2 (काठ | | 50 | 55 | 5 | ७७ |
[ais | 49 | 523 | | 594 | ] 52 | ७०28 | 56 |
| 420 | 496 | 526 | | 504 | 534 | 80 | ७७ |
| 39 | ७3 | 98 [528] [३७ | 565 | 6७ | | 5७ 7
1491] | 08 7 aaa | 58 | —eaz | शा जाना जाना आशा झा
| 534 | [aga | 977 | ७0 | | 59 | 638 |
[४9 | 5७ | [aes | ७३1 6०७ | ७2 ७७७७७
“Sr.
SECRETARY

<!-- page 4 -->

[—normat || NORMAL [MIDNIGHT |]
oto FaRe| reviseo | 00 FARE] REVISED OL FARE] REVISED OLD FARE| REVISED
(७.) |FARE(RS.)] (७.) [FARE (RS.) (RS) |FARE(RS.)] (RS.) FARE (RS.)
| 503 | ७7 | 602
| 58 | | | 60 |
[sso | 648 |
| ७9 | | 609 |
| छ5छ | 653 | ७93 | [बा |
1556 | ese | छ | | छोड | ए | ग |
[sss | 6599 | ७8 |
| sea [os | | 772 _|
| 563 | 5 | sas | 620 |
| ses [666 | | 622 |
| उछा | 669 | 7०9 | | 58 [62a | रह | 780_|
| 5७ | [26 |
| 629 |
= [sos | छा | 7aa | रहा |
| 576 | | ७3 | ९७ | खप |
| 582 [723 | 590 | ७35 | कक | खथ |
| 580 | ces | 725 | | शक्र |
|_383 | [eso [754 | ७७ |
| 55 | छठ | खा | | छठ | ७7 | 8 |
555 | 587 | 692 | [esa | 750 | 80 |
[sso | हक [736 || है [coo | छह |
| 64s | | #० |
593 | >> | 690 |» | 83 |
159 | | &3 |
| 598 | [ess [772 | as |
| 600 | [ea]
secre)
MMRTA REGION
‘Fare calculation method Fare = Distance x Fare per KM and rounding of to nearest rupee. Le.upto 49 paise to be neglected and 50 palse and above to be rounded of to next Rupee e.g.for 2.50 KMs the
fare will be 21.90 x 2.50 = 54,75 i.e. Rs. 55/- and for 3.60 KMs the fare will be 21.90 x 3.60 = 78.84 1.९. Rs.79/-. Also for 4.80 KMs the fare will be 21.90 x 4.80 = 105.12 i.e. Rs.105/- and for 6.40 KMs the
fare willbe 21.90 x 6.40 = 140.16 1.2. R.140/-.
‘Note - 1) Luggage charges are payable Rs. 6/- per package of size larger than (60x40) cms other than a brief case, attache case, small bag or hand bag.
2) Waiting charges 10% ofthe basi fare per kim. for every minute.
