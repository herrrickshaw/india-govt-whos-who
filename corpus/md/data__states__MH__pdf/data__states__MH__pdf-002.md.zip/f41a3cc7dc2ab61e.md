---
doc_id: "f41a3cc7dc2ab61e"
source_url: "https://fssai.gov.in/upload/uploadfiles/files/Gazette_Notification_Safe_Food_Children_07_09_2020.pdf"
ministry: "Food and Drug Administration, Maharashtra"
title: "Food Safety and Standards (Safe food and balanced diets for children in school) Regulations, 2020"
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0cb7918f2c2809de"
---

<!-- page 1 -->

रिजी सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-04092020-221559
xxxGIDHxxx
CG-DL-E-04092020-221559
xxxGIDExxx

असाधारण

EXTRAORDINARY

—

भाग III खड 4
PART III—Section 4

ािधकार से कािशत

PUBLISHED BY AUTHORITY

सं. 355]

नई दली, शुवार, िसतबर 4, 2020/भा 13, 1942

No. 355]

NEW DELHI, FRIDAY, SEPTEMBER 4, 2020/BHADRA 13, 1942

LokLF; vkSj ifjokj dY;k.k ea=ky;
¼Hkkjrh; [kk| lqj{kk vkSj ekud izkf/kdj.k½
vf/klwpuk
ubZ fnYyh] 4 flrEcj] 2020
Qk- la- 15¼1½2016@Ldwyh cPps fofu;e@izorZu@,Q-,l-,l-,-vkbZ-—[kk| lqj{kk vkSj ekud ¼Ldwyh
cPpks a ds fy, lq j f{kr [kk| vkS j LokLF;dj vkgkj½ fofu;e] 2019] [kk| lq j {kk vkS j ekud vf/kfu;e] 2006
¼2006 dk 34½ dh /kkjk 92 dh mi&/kkjk ¼1½ dh vis { kkuq l kj Hkkjr ds jkti= vlk/kkj.k] Hkkx III ] [ka M 4 es a
vf/klw puk Qk- la - 15¼1½2016@Ldwyh cPps fofu;e@izorZu@ ,Q-,l-,l-,-vkbZ] rkjh[k 30 vDVwcj] 2019 }kjk
izdkf”kr fd;k x;k Fkk ftlesa mu O;fä;ksa ls ftuds mlls izHkkfor gksus dh laHkkouk Fkha ml rkjh[k ls ftldks mä
vf/klwpuk dks varfoZ"V djus okys jkti= dh çfr;k¡ turk dks miyC/k djk nh xbZa Fkh rhl fnu dh vof/k dh lekfIr ds
iwoZ vk{ksi vkSj lq>ko vkeaf=r fd, x, Fks;
vkSj mDr jkti= dh izfr;k¡ turk dks 04 uoacj] 2019 dks miyC/k djk nh xbZa Fkha(
vkSj mDr fofu;eksa ds izk:i ij turk ls izkIr vkifÙk;ksa vkSj lq>koksa ij Hkkjrh; [kk| lqj{kk vkSj ekud
izkf/kdj.k }kjk fopkj dj fy;k x;k gS(
vr% vc mDr vf/kfu;e dh /kkjk 92 dh mi&/kkjk ¼2½ ds [kaM ¼v½ }kjk iznÙk “kfDr;ksa dk iz;ksx djrs gq,
Hkkjrh; [kk| lqj{kk vkSj ekud izkf/kdj.k ,rn~}kjk fuEufyf[kr fofu;e cukrh gS] vFkkZr~]&
fofu;e

1-

laf{kIr uke vkSj izkjaHk & ¼1½ bu fofu;eksa dk laf{kIr uke [kk| lqj{kk vkSj ekud ¼Ldwyh cPpksa ds fy,
lqjf{kr [kk| vkSj larqfyr vkgkj½ fofu;e] 2020 gSA

4097 GI/2020

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC. 4]

¼2½
;s jkti= esa izdk”ku dh frfFk ls izo`Ùk gksaxs vkSj [kk| dkjksckjh çpkyd fofu;e 5 ds mi fofu;e ¼1½ vkSj
fofu;e 3 ds mifofu;e ¼3½ ds flok;] ftls jkti= esa vf/klwpuk }kjk [kk| çkf/kdj.k ds :i esa ml rkjh[k ls ço`r
gksxk] fu;qä fd;k tk,, bu fofu;eksa ds lHkh mica/kksa dk vuqikyu 01 tqykbZ] 2021 ls djsaxsA

2-

ifjHkk"kk,¡]& ¼1½ tc rd lanHkZ ls vU;Fkk visf{kr u gks] bu fofu;eksa esa]&
¼d½ ^^vf/kfu;e^^ ls [kk| lqj{kk vkSj ekud vf/kfu;e] 2006 vfHkizsr gS(
¼[k½ ^^Ldwyh f'k{kk foHkkx^^ ls dsanzh; vFkok jkT; vFkok la?kjkT; {ks= ç'kklu dk og lacaf/kr uksMy foHkkx
vfHkizsr gS tks vius uke dk fopkj fd, fcuk Ldwyh f”k{kk dk dk;Z ns[krk gks(
¼x½

^^[kk|dehZ^^ ls og O;fDr vfHkizsr gS tks iSdstcan vFkok fcuk iSd fd, gq, [kk|] [kk| rS;kjh ds miLdjksa
vkSj crZuksa vFkok [kk| laidZ lrgksa dks lh/ks gSaMy djrk gks(

¼?k½

^^[kk| lqj{kk^^ ls ;g vk”oklu vfHkizsr gS fd [kk| mlds vk”kf;r mi;ksx ds vuqlkj ekuo miHkksx ds fy,
Lohdj.kh; gS(

¼³½

^^[kk| lqj{kk fMLIys cksMZ^^ ls og lwpukRed cksMZ vfHkizsr gS ftlesa [kk| dkjksckjh çpkyd ds [kk|
çkf/kdj.k jftLVªhdj.k ;k vuqKfIr la[;k] ml }kjk viukbZ tkus okyh vk/kkjHkwr LoPNrk vkSj lqj{kk dh ckrksa
vkSj ml }kjk is”k fd, x, [kk| dh xq.krk vkSj lqj{kk ds ckjs esa miHkksDrk dh fVIif.k;k¡ izkIr djus dh
iz.kkyh dk mYys[k gks(

¼p½

^^[kk| lqj{kk i;Zos{kd^^ ls [kk| dkjksckjh çpkyd }kjk fu;qDr og O;fDr vfHkizsr gS ftlds ikl [kk|
izkf/kdj.k }kjk vuqeksfnr oS/k [kk| lqj{kk izek.k&i= gks(

¼N½

^^larqfyr vkgkj^^ ls og vkgkj vfHkizsr gS ftlls vfuok;Z iks’kd rRoksa lfgr lHkh iks’kd rRo visf{kr ek=k
vkSj mfpr vuqikr esa feysa(

¼t½ ^^Ldwy^^ ls izkbosV ,aVhVh] LFkkuh; fudk;ksa] ljdkj vFkok ljdkjh lgk;rk&izkIr laLFkkvksa }kjk lapkfyr lHkh
izdkj ds Ldwy vfHkizsr gSa] pkgs os iwoZ&izkFkfed] izkFkfed] izkjafHkd] ek/;fed] Ms ds;j@ØS”k ¼f”k”kqvksa@24 ekg
rd ds cPpksa ds fy, ØS”k@Ms ds;j dks NksM+dj½ gksa vFkok cksfMZax Ldwy gksa(
¼>½

^^Ldwy izkf/kdj.k^^ ls laLFkk dk izeq[k] tSls iz/kkukpk;Z] eq[;k/;kid bR;kfn] “kklh ifj’kn~] U;kl vFkok Ldwy
ds “kklu vkSj izca/ku ds fy, LFkkfir vU; dksbZ ,afVVh vfHkizsr gS(

¼¥½

^^Ldwy vgkrk^^ ls bu fofu;eksa ds iz;kstu ds fy, Ldwy ds {ks=kf/kdkj esa lfEefyr lEifÙk ds os lHkh {ks=
vfHkizsr gSa] ftuesa fo|kFkhZ Ldwy ds le; esa vkSj cksfMZax Ldwyksa@Nk=koklksa ds fuoklh tk ldsa(

¼V½

^^Ldwy vkgkj^^ ls dSaVhuksa@Ldwy ds Hkkstuky;@Nk=kokl ds fdpuksa@osafMax e”khuksa }kjk vFkok vU; fdlh
i)fr ls Ldwy vgkrk esa csps x, vFkok vkiwfrZr lHkh [kk| vkSj chojst vfHkizsr gSa vkSj buesa e/;kà Hkkstu ds
fdpuksa vkSj Ldwy }kjk fo|kfFkZ;ksa ds fy, vkiwfrZr lHkh Hkkstu “kkfey gSa(

¼2½ lHkh vU; 'kCnksa vkSj inksa ds] tks blesa ç;qä gSa vkSj ifjHkkf"kr ugha gSa fdUrq vf/kfu;e vkSj mlds v/khu cuk,
x, fu;eksa vkSj fofu;eksa esa ifjHkkf’kr gSa] ogh vFkZ gksaxs tks Øe”k% vf/kfu;e] fu;eksa vkSj fofu;eksa esa vfHkizsr gSA
3- Ldwy ifjlj esa lqjf{kr [kk| vkSj larqfyr vkgkj lqfuf’pr djkus ds fy, Ldwy izkf/kdj.k ds
mÙkjnkf;Ro]&
Ldwy vgkrk esa Ldwy vkgkj Lo;a cspus vFkok mldh vkiwfrZ djus okyh Ldwy izkf/kdj.k vf/kfu;e vkSj mlds v/khu
cuk, x, fu;eksa vkSj fofu;eksa ds mica/kksa ds v/khu [kk| dkjksckjh ds :i esa viuk jftLVªs'ku djk,xh vkSj lqfuf”pr
djsxh fd [kk| lqjf{kr vkSj larqfyr gSA
1)

Ldwy vgkrk esa Ldwyh vkgkj cspus vFkok mldh vkiwfrZ djus okys fdlh [kk| dkjksckjh çpkyd ls dksbZ
vuqca/k vFkok ysu&nsu djus okyh Ldwy izkf/kdj.k ;g lqfuf”pr djsxh fd ,sls [kk| dkjksckjh çpkyd
vf/kfu;e vkSj mlds v/khu cuk, x, fu;eksa vkSj fofu;eksa ds mica/kksa ds varxZr fof/kor~ :i ls jftLVªhd`r
gS vFkok vuqKfIr çkIr gS vkSj og lqfuf”pr djsxh fd [kk| lqjf{kr vkSj larqfyr gSA

2)

Ldwyh f”k{kk foHkkx ;g lqfuf”pr djsxk fd e/;kà Hkkstu ;kstuk ds çpkyu ds fy, ml çpkyd }kjk
vuqcaf/kr lHkh [kk| dkjksckjh vf/kfu;e vkSj mlds v/khu cuk, x, fu;eksa vkSj fofu;eksa ds mica/kksa ds
varxZr fof/kor~ :i ls jftLVªhd`r gS vFkok vuqKfIr çkIr gS vkSj og lqfuf”pr djsxh fd [kk| lqjf{kr vkSj
larqfyr gSA

3)

Ldwy vgkrk esa [kk| cspus vFkok mldh vkiwfrZ djus okys [kk| dkjksckjh [kk| lqj{kk vkSj ekud ¼[kk|
dkjksckj dk vuqKkiu vkSj jftLVªhdj.k½ fofu;e] 2011 ds v/khu ;Fkk fofufnZ"V vuqlwph 4 ds vuqlkj

<!-- page 3 -->

[भाग III—खड 4]

भारत का राजप : असाधारण

3

lkQ&lQkbZ vkSj LoPNrk jhfr;ksa] [kk| lqj{kk fMLIys cksMZ vkSj [kk| lqj{kk i;Zos{kd¼dksa½ laca/kh vis{kkvksa dk
vuqikyu lqfuf”pr djk,¡xsA
4)

Ldwy izkf/kdj.k ;g lqfuf”pr djsxh fd Ldwy ifjlj vFkok vgkrk esa dksbZ O;fDr mPp lSP;qjsfVM QSV vFkok
Vªkal QSV vFkok ;ksftr “kdZjk vFkok lksfM;e okys [kk| mRikn ugha cspsxk vFkok fcØh ds fy, is”k ugha
djsxk] ftlesa eq¶r fcØh lfEefyr gS] vFkok mudh fcØh dh vuqefr ugha nsxkA

5)

Ldwy izkf/kdj.k ;g lqfuf”pr djsxh fd Ldwy ds izos”k }kj ij ^^Ldwy ifjlj vFkok dSail esa mPp lSP;qjsfVM
QSV vFkok Vªkal&QSV vFkok ;ksftr “kdZjk vFkok lksfM;e okys [kk| mRikn u cspas] ftlesa eq¶r fcØh
lfEefyr gS] vFkok mudk foi.ku vFkok foKkiu u djsa^^ lkexzh okyk vaxzsth ;k Hkkjrh; Hkk’kk okyk cksMZ] tks
Hkh ykxw gks] n`”;eku LFkku ij yxk gksA

6)

Ldwy izkf/kdj.k ;g lqfuf”pr djsxh fd Ldwy ds daI;wVjksa ij mPp lSP;qjsfVM QSV vFkok Vªkal&QSV vFkok
;ksftr “kdZjk vFkok lksfM;e okys [kk| dk dksbZ foKkiu cSuj vFkok oky isij u gksA

4- Ldwy ifjlj esa vkSj mlds vkl&ikl lqjf{kr [kk| vkSj larqfyr vkgkj dks c<+kok
1)

[kk| izkf/kdj.k vFkok jkT; [kk| izkf/kdkjh Ldwyksa dks Ldwy ds cPpksa esa lqjf{kr [kk| vkSj larqfyr vkgkj dks
c<+kok nsus dk ,d O;kid dk;ZØe viukus rFkk Ldwy ifjlj dks ^bZV jkbV dSail^ esa cnyus ds fy, fofgr
csapekdZ izkIr djus ds fy, izksRlkfgr djsaxs] ftuesa lqjf{kr vkSj larqfyr vkgkj] LFkkuh; vkSj ekSleh [kk|
ijkslus vkSj [kk| dks cjckn u gksus nsus ij /;ku dsafnzr gksA

2)

Ldwy izkf/kdj.k jk’Vªh; iks’k.k laLFkku vkSj vU; fo”ks’kK laLFkkvksa vFkok izkf/kdj.kksa }kjk tkjh fd, x,
^^Hkkjrh;ksa ds fy, vkgkj laca/kh fn”kk&funsZ”k & eSuqvy^^ ij vk/kkfjr Ldwy dSaVhu@ Hkkstuky;@jlksbZ esa
lqjf{kr vkSj larqfyr vkgkj dks izksRlkfgr djsxh vkSj c<+kok nsxhA

3)

Ldwyh izkf/kdj.k ;g lqfuf”pr djsxh fd Ldwy ifjlj esa rS;kj Ldwy vkgkj dh vkiwfrZ djus okys [kk|
dkjksckjh ijksls@csps tkus okys [kk| dh igpku vkSj mudk p;u vuqlwph esa fn, x, O;kid fn”kk&funsZ”kksa
vkSj [kk| izkf/kdj.k vFkok jkT; ds [kk| lqj{kk vk;qDr }kjk tkjh fd, x, funsZ”kksa ds vuqlkj gksA

4)

Ldwy izkf/kdj.k vkof/kd :i ls iks’k.k foKkfu;ksa] vkgkj foKkfu;ksa] iks’k.k la?kksa dh lsok,¡ ys ldrh gS vFkok
cPpksa ds fy, esuq cukus esa muds ekrk&firk dh lgk;rk ys ldrh gSA

5)

24 ekg dh vk;q rd ds cPpksa ;k f'k'kqvksa ds fy, f'k'kq'kkyk ;k fnu ifjp;kZ esa Hkh muds }kjk lqjf{kr vkSj
larqfyr vkgkj nsuh dh vis{kk dh tkrh gSA

5- Ldwyh cPpksa esa [kk| dk foi.ku vkSj foKkiu rFkk fcØh
1)

Ldwy ifjlj vFkok vgkrk esa dksbZ O;fDr mPp lSP;qjsfVM QSV vFkok Vªkal QSV vFkok ;ksftr “kdZjk vFkok
lksfM;e okys [kk| mRikn ugha cspsxk vFkok fcØh ds fy, is”k ugha djsxk] ftlesa eq¶r fcØh lfEefyr gS] vFkok
mudh fcØh dh vuqefr ugha nsxkA

2)

Ldwy ifjlj vFkok vgkrk esa Ldwyh cPpksa esa [kk| foi.ku ds le; [kk| dkjksckjh çpkyd-

3)

d½

dsoy mu [kk|ksa] vkgkjksa ds lkFk izhfe;e vFkok izksRlkguksa] tSls f[kykSus] VªsfMax dkMZ] ifj/kku] Dyc
lnL;rk] izfr;ksfxrk,¡] U;wu&ewfY;r [kk|] vFkok dwiuksa dh is”kd”k djsxk ftuesa lSP;qjsfVM QSV vFkok
Vªkal&QSV vFkok ;ksftr “kdZjk vFkok lksfM;e vf/kd ek=k esa u gks(

[k½

dsoy ml [kk| ds fy, cPpksa ds [ksyksa] Ldwyh o vU; lekjksgksa esa izk;kstu dk mi;ksx djsxk ftuesa
lSP;qjsfVM QSV vFkok Vªkal&QSV vFkok ;ksftr “kdZjk vFkok lksfM;e vf/kd ek=k esa u gks(

[kk| dkjksckjh çpkyd Ldwyksa esa larqfyr vkgkj dks c<+kok nsaxs vkSj Ldwy vgkrk esa dgha Hkh ,sls [kk| dk
foi.ku] fcØh ugha djsaxs vFkok mldk forj.k ugha djsaxs ftlesa lSP;qjsfVM QSV vFkok Vªkal&QSV vFkok ;ksftr
“kdZjk vFkok lksfM;e mPp ek=k esa gks] ftlesa fuEufyf[kr ek/;e lfEefyr gSa %
¼d½

fcØh e”khuksa ij@esa yksxks] czkaM uke] Liksd&djSDVj] mRikn uke] vFkok mRikn foi.ku( iqLrdsa]
ikB~;Øe vFkok vU; “kS{kf.kd lkefxz;k¡( Ldwy dks vkiwfrZr lkefxz;k¡( iksLVj( ikB~; iqLrdksa ds doj(
vkSj Ldwy lEink tSls LdksjcksMZ] lkbu] [ksy ds eSnku] clsa vkSj bekjrsaA

¼[k½

[kk| lkexzh ds iqjLdkj okys “kS{kf.kd izksRlkgu dk;ZØeA

¼x½

mPp lSP;qjsfVM QSV vFkok Vªkal&QSV vFkok ;ksftr “kdZjk vFkok lksfM;e okys [kk| dh lh/kh fcØhA

¼?k½

eq¶r uewus vFkok dwiuA

¼³½

Ldwy ds fy, foÙk tqVkus dh xfrfof/k;k¡A

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC. 4]

6- ekWfuVfjax vkSj fuxjkuh
1)

Ldwy izkf/kdkjh fo|kfFkZ;ksa ds fy, lqjf{kr] larqfyr vkSj LoPN [kk| lqfuf”pr djkus ds fy, ifjlj dk
fu;fer fujh{k.k djus dh ;kstuk cuk,A Ldwy izkf/kdj.k dksbZ LokLF; vkSj ran#Lrh ,EcslMj vFok LokLF;
vkSj ran#Lrh Vhe fu;qDr dj ldrh gS tks lqjf{kr] larqfyr vkSj LoPN [kk| dh miyC/krk dks ekWfuVj djus
ds fy, uksMy O;fDr dk dke djsxk¼xh½A

2)

jkT; [kk| izkf/kdkjh vf/kfu;e vkSj mlds v/khu cuk, x, fofu;eksa dk vuqikyu lqfuf”pr djkus ds fy,
bu fofu;eksa esa doMZ [kk| dkjksckfj;ksa ij fuxjkuh j[ksxh vkSj mudk lkof/kd fujh{k.k djsxhA

3)

jkT; [kk| izkf/kdj.k ds vykok vf/klwfpr vU; dksbZ lkoZtfud izkf/kdj.k] tSls fdlh {ks= ds uxj fuxe
vFkok vU; dksbZ LFkkuh; laLFkk vFkok iapk;r] bu fofu;eksa ds mi&fofu;e 5 ¼1½ dk vuqikyu lqfuf”pr
djk,xhA

4)

Ldwy izkf/kdj.k }kjk bu fofu;eksa ds mica/kksa dk fcuk fdlh rdZlaxr vk/kkj ds vuqikyu u fd, tkus ij
dsanzh; vFkok jkT; [kk| izkf/kdj.k ml laca/k esa vko”;d dkjZokbZ djus gsrq ekeys dks lacaf/kr f”k{kk foHkkx
vkSj@vFkok izR;k;u laLFkk dks HkstsxhA

5)

[kk| lqj{kk vkSj ekud ¼[kk| dkjckj dk vuqKkiu vkSj jftLVªhdj.k½ fofu;e] 2011 ds mi&fofu;e 2-1-15
ds v/khu xfBr jkT; Lrjh; lykgdkj lfefr ¼,l-,y-,-lh½ bl fofu;e ds fØ;kUo;u dks ekWfuVj djus
vkSj Ldwyh cPpksa ds fy, lqjf{kr vkSj LokLF;dj [kk| dh miyC/krk lqfuf”pr djkus ds fy, ,d mi&lfefr
cuk,xhA

6)

mi&lfefr esa Ldwyh f”k{kk foHkkx rFkk [kk| vkSj iks’k.k ds {ks= ds tu LokLF; is”ksoj ds izfrfuf/k gksaxsA
mi&lfefr dh o’kZ esa de ls de nks cSBdsa gksaxhA

7)

mi&lfefr ml {ks= ds yksxksa ds vkgkjksa esa LFkkuh; varjksa ij vk/kkfjr rFkk bu fofu;eksa dh vuqlwph esa
fofgr O;kid fn”kk&funsZ”kksa ds vuqlkj jkT; dh Ldwy dSaVhuksa@Hkkstuky;ksa@jlksb;ksa esa ijksls@csps tkus okys
[kk| lewgksa vkSj fufeZfr;ksa dh ladsrkRed lwph dh vuq”kalk djsxhA
vuqlwph

[fofu;e 4¼3½ vkSj 6¼7½ ns[ksa]
cPpksa dks lqjf{kr [kk| vkSj larqfyr vkgkj miyC/k djkus ds lkekU; fn’kk&funsZ’k
•

cPpksa esa [kku&iku dh LokLF;dj vknrsa Mkyus ds fy, Ldwyksa esa Hkkstukodk”k vfuok;Z :i ls gksA

•

lHkh fo|kfFkZ;ksa dks lqjf{kr is; ty fu”kqYd miyC/k djk;k tk,A

•

fl)kar :i esa lIrkg esa [kk| vny&cny dj fn;k tk,A Ldwy ds esuq esa cPpksa ds fy, /kkU; vkSj izksVhu nksuksa
gksa rFkk mudk vkgkj lw{e iks’kd rRoksa ls Hkjiwj gksA

•

lkcqr vuktksa] nkyksa] feysVksa] i”kq&ewy ds [kk|ksa] tSls nw/k] vaMk bR;kfn lHkh dk mi;skx fd;k tk,A Hkkstu ds
fy, rktk] ekSleh vkSj LFkkuh; [kk| inkFkksaZ dk iz;ksx fd;k tk,A

•

[kkuk idkus ds rsy ;k ?kh dk iz;ksx fu;af=r :i esa fd;k tk,A iqu% xeZ dh xbZ olkvksa vkSj rsyksa dk iz;ksx u
fd;k tk,A

vkgkjksa dks vf/kd iks’kd cukus ds fy, [kk| lqj{kk vkSj ekud ¼[kk| lqn`<+hdj.k½ fofu;e] 2018 ds vuqlkj
ikSf’Vdhd`r xsgw¡ ds vkVs] pkoy] nw/k] [kk| rsy vkSj nqgjs ikSf’Vdhd`r ued dk iz;ksx fd;k tk ldrk gSA
[kk| inkFkksZa ds p;u laca/kh lkekU; ekxZn’kZu
Øe laesuq esa lEefyr djus gsrq
[kk| inkFkksZa vkSj chojst dh lwph*
•

1.

esuq esa lnk jgs & 75-80% rd
[kk| bl Js.kh ls gks

1. /kkU;] feysV vkSj nkysa & ;Fkk pksdj okyk xsgw¡ dk vkVk]
pkoy] feysV ¼jkxh] cktjk bR;kfn½] Qfy;k¡ ¼lHkh nkysa vkSj
chUt½
2. nw/k] nqX/k mRikn] vaMk] ekal vkSj eNyh & nw/k] ngh] ;ksxVZ]
yLlh] NkN] iuhj] vFkok nqX/k mRikn] fcuk pchZ dk ekal]
fpdu] eNyh] vaMk
3. Qy vkSj lfCt;k¡ & lfCt;k¡ ¼gjh iÙksnkj lfCt;k¡] vU;
lfCt;k¡ vkSj dan&ewy½] rktk Qy ¼LFkkuh; vkSj ekSleh½

<!-- page 5 -->

[भाग III—खड 4]

भारत का राजप : असाधारण

5

4. rsy] olk,¡] fxfj;k¡ vkSj frygu & v[kjksV] cknke] fi”rk]
ued ;k “kdZjkjfgr Hkquh fxfj;k¡] ew¡xQyh] fry
5. izlaLd`r@ids gq, [kk| & fcuk ;ksftr “kdZjk ds rktk lwi]
nfy;k] chojst] fgykdj ryh gqbZ lfCt;k¡] LuSDl & mcys] csd
fd, gq, vFkok Hkki ls idk, gq,] /kkU; vFkok nky&vk/kkfjr
phtsa] tSls bMyh] miek] iksgk] [kaMoh] <ksdyk] phyk] uedhu
nfy;k bR;kfnA
dHkh&dHkh [kkus ds fy, & FkksM+h
ek=k esa vkSj dnkpfud ¼mnkgj.kkFkZ
lIrkg esa ,d ckj½

2.

1. MstVZ&vkbl&Øhe]
feBkb;k¡@MstVZ

nw/k&vk/kkfjr

vkSj

Ms;jh&

vk/kkfjr

2. iSDM [kk| & iuhj] fMCckcan vkSj ifjjf{kr lCth] iSdstcan
ekal vFkok eNyh mRikn] Qy@lfCt;k¡@/kkU;@ nky&vk/kkfjr
LuSDl] fxfj;k¡ vkSj cht
3. csdjh mRikn & lQsn czsM] fcLdqV
4. chojst & iSdstcan lwi vkSj twl] /kkU; vFkok ekYV&vk/kkfjr
chojst] lqokflr lks;k nw/k bR;kfnA

Ldwy] Nk=kokl esa miyC/k u djk,
tk,¡

3.

mPp lSP;qjsfVM QSV vFkok Vªkal&QSV vFkok ;ksftr “kdZjk vFkok
lksfM;e okys [kk| mRikn

*mRiknksa dh ;g lwph dsoy n`’Vkar ds :i esa gS A
v#.k fla?ky, eq[; dk;Zdkjh vf/kdkjh
[foKkiu& III@4@vlk-@211@2020&21]

MINISTRY OF HEALTH AND FAMILY WELFARE
(Food Safety and Standards Authority of India)
NOTIFICATION
New Delhi, the 4th September, 2020
F. No. 15(1)2016/School Children Regulation/Enf/FSSAI.—Whereas the Food Safety and
Standards (Safe food and healthy diets for School Children) Regulations, 2019 were published as required
under sub-section (1) of section 92 of the Food Safety and Standards Act, 2006 (34 of 2006), vide
notification No. 15(1)2016/School Children Regulation/Enf/FSSAI, dated the 30th October, 2019, in the
Gazette of India, Extraordinary, Part III, Section 4, inviting objections and suggestions from the persons
likely to be affected thereby, before the expiry of the period of thirty days from the date on which the
copies of the Gazette containing the said notification were made available to the public;
And whereas copies of the said Gazette were made available to the public on the 4th November,
2019;
And whereas objections and suggestions received from the public in respect of the said draft
regulations have been considered by the Food Safety and Standards Authority of India;
Now, therefore, in exercise of the powers conferred by clause (v) of sub- section (2) of section 92
of the said Act, the Food Safety and Standards Authority of India with the previous approval of the Central
Government hereby makes the following regulations, namely:REGULATIONS
1. Short title and commencement.- (1) These regulations may be called the Food Safety and
Standards (Safe food and balanced diets for children in school) Regulations, 2020.
(2) They shall come into force on the date of their publication in the Official Gazette and food
business operator shall comply with all the provisions of these regulations with effect from
1st July, 2021, except sub-regulation (5) of regulations 3 and sub-regulation (1) of regulations 5

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC. 4]

which shall come into force only from such date as the Food Authority may, by notification in the
Official Gazette, appoint.
2. Definitions -(1) In these regulations, unless the context otherwise requires,(a)

“Act” means the Food Safety and Standards Act, 2006;

(b)

“Department of School Education” means the nodal department of concerned Central or
State or Union Territory administration that looks after the school education irrespective of
nomenclature;

(c)

“Food handler” means a person who directly handles packaged or unpackaged food, food
preparation equipment and utensils or food contact surfaces;

(d)

“food safety” means assurance that food is acceptable for human consumption according to
its intended use;

(e)

“Food Safety Display Board” means an informative board displaying the Food Authority
registration or license number of the food business operator, basic food hygiene and safety
tips to be complied by the said operator and mechanism for obtaining consumer feedback on
the quality and safety of the food offered by it;

(f)

“Food Safety Supervisor” means a person appointed by the food business operator and holds
a valid food safety certificate of training approved by the Food Authority;

(g)

balanced diet” is one which provides all the nutrients including the essential micro nutrients
in required amounts and proper proportions;

(h)

“Schools” means all types of schools whether pre-primary, primary, elementary, secondary,
day care or as the case may be, crèche (excluding crèches or day care for infants or children
up to the age of twenty-two months), or boarding run by private entities, local bodies,
government or aided by government;

(i)

“School Authority” means Head of the Institution such as Principal, Headmaster, etc.,
Governing Body, Trust or any other entity set up to govern and manage the school;

(j)

“School campus” means, for the purpose of these regulations, all areas of the property under
the jurisdiction of the school that is accessible to students during the school hours and for
residents of boarding schools or hostels;

(k)

“School meals” means all food and beverages sold or supplied in the school campus through
canteens, school mess, hostel kitchens, vending machines or any other method and include all
meals served through mid-day meal kitchens and catered for students by the school;

(2) All other words and expression used herein and not defined, but defined in the Act, rules or regulations
made thereunder, shall have the meanings assigned to them in the Act, rules or regulations, respectively.
3. Responsibilities of School Authority to ensure safe food and balanced diets on school
premises.- (1) School Authority selling or catering school meals by itself in the school campus shall get
registered as a food business operator from the concerned authority under the provisions of the Act , rules
or regulations made thereunder and ensure that the food is safe and balanced.
(2) Any School Authority entering into a contract or transaction with a food business operators (FBOs)
selling or catering school meal on school campus shall ensure that such FBOs are duly registered or
licensed under the provisions of the Act, rules or regulations made thereunder and ensure that the food is
safe and balanced.
(3) The Department of School Education shall ensure that all FBOs contracted by it for operation of the
mid-day meal scheme are registered or licensed under the provisions of the Act, rules or regulations made
thereunder and ensure that the food is safe and balanced.
(4) The FBOs selling or catering food on school campus shall ensure compliance to the requirements of
sanitary and hygienic practices provided to the food manufacturers in
Schedule 4, Food Safety Display
Board and Food Safety Supervisor(s) as specified under the Food Safety Standards (Licensing and
Registration of Food Businesses) Regulations, 2011.

<!-- page 7 -->

[भाग III—खड 4]

भारत का राजप : असाधारण

7

(5) School Authority shall ensure that no person shall sell or offer for sale including free sale, or permit
sale, of food products high in saturated fat or trans-fat or added sugar or sodium in school premises or
campus.
(6) School Authority shall ensure that the board containing warning “Do not sell including free sale or
market or advertise the food products high in saturated fat or trans-fat or added sugar or sodium within
school premises or campus” in English or one Indian language as applicable, is displayed prominently at
the entrance gate or gates of the school.
(7) School Authority shall ensure that there shall not be any advertisement banner or wallpaper of food
which is high in saturated fat or trans-fat or added sugar or sodium on school computers.
4. Promotion of safe food and balanced diet in and around school campus.- (1) The Food Authority or
the State Food Authority shall encourage schools to adopt a comprehensive program for promoting safe
food and balanced diets amongst school children and meet specified benchmarks to convert school campus
into ‘Eat Right Campus’ that focus on serving of safe food and balanced diet, local and seasonal food and
no food waste.
(2) The School Authority shall encourage and promote consumption of a safe and balanced diet in the
school canteen or mess or kitchen based on guidance from “Dietary guidelines for Indians – A Manual”
issued by the National Institute of Nutrition and other expert institutions or authorities.
(3) The School Authority shall ensure that the FBOs supplying prepared school meals in the school
premises is are identified and selected foods which can be served or sold on the basis of the broad
guidelines given in the Schedule to these regulations and as per the directions, issued by the Food Authority
or the Commissioner of Food Safety of the state.
(4) The School Authority may engage with nutritionists, dietitians, nutrition associations or seek parental
support to assist in the drafting of the menu for the children, periodically.
(5) The crèches or day cares for infants or children up to the age of twenty-four months old are also
expected to serve safe and balanced diets to them.
5. Food marketing and advertisement and selling to children in school.- (1) No person shall advertise or
market or sell or offer for sale including free sale, or permit sale of, food products high in saturated fat or
trans-fat or added sugar or sodium in school campus or to school children in an area within fifty meters
from the school gate in any direction.
(2) When marketing foods to children in school premises or campus, the FBOs shall.-

(a)

only offer premiums and incentives such as toys, trading cards, apparel, club memberships,
contests, reduced-price specials, or coupons with foods, meals, which is not high in
saturated fat or trans-fat or added sugar or sodium;

(b)

use sponsorship of sporting, school, and other events for children only with food which is
not high in saturated fat or trans-fat or added sugar or sodium.

(3) FBOs shall support balanced eating in schools and not market, sell, or give away food which is high in
saturated fat or trans-fat or added sugar or sodium anywhere on school campuses, including through,(a) logos, brand names, spokes-characters, product names, or other product marketing on or in
vending machines; books, curricula, and other educational materials; school supplies;
posters; textbook covers; and school property such as scoreboards, signs, athletic fields,
buses, and buildings;
(b) educational incentive programs that provide food as a reward;
(c) direct sale of food which is high in saturated fat or trans-fat or added sugar or sodium;
(d) free samples or coupons;
(e) school fundraising activities.
6. Monitoring and surveillance.- (1) The School Authority shall have a system of regular inspection of
premises to ensure that safe, balanced and hygienic food is served to students. The School Authority may
appoint a Health and Wellness Ambassadoror Health and Wellness team, who shall act as the nodal persons
to monitor availability of safe, balanced and hygienic food.

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC. 4]

(2) The State Food Authority shall conduct surveillance and periodic inspection of food business operators
covered under these regulations so as to ensure that compliance of the Act, rules or regulations made
thereunder are met.
(3) Any public authority like Municipal Corporation or any other local body or Panchayat in an area, as
may be notified, in addition to State Food Authority shall ensure the compliance of sub-regulation (1) of
regulation 5 of these regulations.
(4) If the School Authority, without reasonable grounds, fails to comply with the provisions under these
regulations, the Central or State Food Authority shall take up the matter with the concerned Department of
School Education or Affiliation Body, if any, to take appropriate action.
(5) The State Level Advisory committee (SLAC) constituted under sub-regulation 2.1.15 of the Food
Safety and Standards (Licensing and Registration of Food Businesses) Regulations, 2011 shall create a subcommittee to monitor the implementation of these regulations and to ensure availability of safe and
wholesome food to school children.
(6) The sub-committee shall include representatives from the Department of School Education, and public
health professionals in the field of foods and nutrition. The sub-committee shall meet at least twice in a
year.
(7) The sub-committee shall recommend indicative list of food groups and preparations which shall be
served or sold in the school canteen or mess or kitchen within the State based on local variations in the diets
of people of that area and as per the broad guidelines given in the Schedule to these regulations.
SCHEDULE
[see regulation 4 (3) and 6 (7)]
General Guidance for Providing Safe food and balanced diet to Children
•

Meal-times in schools shall be mandatory to inculcate healthy eating habits in children.

•

Safe drinking water shall be provided to all students free of cost.

•

A variety of foods to be provided across the week, as a general principle. The school menu shall be
cereal-protein combination and a micronutrient rich meal for students.

•

A combination of whole grains, pulses, millets, foods of animal origin like milk, eggs, etc., shall be
used. Fresh, seasonal and local produce shall be utilised for the preparation of the meals.

•

Cooking oil or ghee shall be used in moderation. Use of re-heated fats and oils shall be avoided.

•

In order to prepare the meals more nutritious, fortified wheat flour, rice, milk, edible oil and double
fortified salt may be used strictly adhering the standards specified in the Food Safety and Standards
(Fortification of Foods) Regulations, 2018.
General guidance for selection of Foods

S.No.

Inclusion in Menu

1.

Always a part of the menu – 7580% of the foods should belong
from this category

List of Foods and Beverages*
1. Cereals, Millets and Pulses – Such as whole wheat
grain (atta), rice, Millets (ragi, bajra, etc.), Legumes
(all dal and beans)
2. Milk, Milk products, egg, meat and fish –milk,
curd, yoghurt, lassi, butter milk,paneer, or milk
products, lean meat, chicken, fish, egg
3. Fruits and Vegetables –vegetables (including green
leafy vegetables: other vegetables and roots and
tubers) Fresh fruits (Local and seasonal produce)
4. Oils, fats, nuts and oilseeds – walnuts, almonds,
pistachios, roasted nuts without salt or sugar,
groundnuts, sesame seeds, etc.

<!-- page 9 -->

[भाग III—खड 4]

भारत का राजप : असाधारण

9

5. Processed/cooked Foods–Freshly made soup,
porridge, beverages with no added sugar, stir fried
vegetables, snacks - boiled, baked or steamed, cereal
or pulses based such as idli, upma, poha, khandvi,
dhokla, cheela, namkin daliya, etc.
2.

To be eaten occasionally – in
small portion size and reduced
frequency
(e.g., once in a week)

1. Desserts - Ice-creams, milk-based and dairy based
sweet/desserts
2. Packed foods- cheese, canned and preserved
vegetable, packaged meat or fish products,
fruits/vegetables/cereal/pulses based snacks, nuts and
seeds.
3. Bakery Products - white breads, biscuits,
4. Beverages - Packaged soups and juices cereal or
malt based beverages, flavoured soya milk, etc.

3.

Not to be made available in the
school, hostel, etc.

Food products high in saturated fat or trans-fat or
added sugar or sodium.

* These lists of products are illustrative only.
ARUN SINGHAL, Chief Executive Officer
[ADVT.-III/4/Exty./211/2020-21]

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. MANOJ
VERMA
Digitally signed by MANOJ KUMAR
VERMA
Date: 2020.09.04 19:54:19 +05'30'
