---
doc_id: "c21e300ffbb28cac"
source_url: "https://stateexcise.maharashtra.gov.in:443/Pdf/1-17-Final-2025-26.pdf"
ministry: "Maharashtra State Excise Duty, Maharashtra"
title: "माहितीचा अधिकार अधिनियम, २००५ चे कलम ४(ख) नुसार माहिती"
date: ""
pages: 85
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "72efdca5e0b521b3"
---

<!-- page 1 -->

माहहतीचा अहधकार अहधहनयम, २००५ चे कलम ४(ख) नुसार माहहती
१. राज्य उत्पादन शुल्क हिभागाची रचना, काये ि कततव्ये :
,
,

,

आयुक्त
आयुक्त

सह आयुक्त (प्र.)

उपआयुक्त (प्र.)
सहा.आयुक्त (प्र.)

सह आयुक्त म/म

उपआयुक्त
(

)

महा.राज्य
भरारी पथक

उपआयुक्त
(ननरीक्षण )
सहा.आयुक्त

सहा.आयुक्त
(औ.व सौं.प्र.)

(ननरीक्षण)

मुख्य
लेखानधकारी

लेखानधकारी

उपसंचालक
(सांख्ख्यकी व
संगणक)

संिोधन
सहाय्यक

सहा.आयुक्त
(
)

नवभागीय उप आयुक्त
कोकण नवभाग ठाणे

नवभागीय उप
आयुक्त,
छ. संभाजीनगर

नवभागीय उप

नजल्हा अधीक्षक

नजल्हा अधीक्षक
कायालये
(एकूण 4)

नजल्हा अधीक्षक
कायालये
(एकूण 3)

कायालये (एकूण 5)

सह आयुक्त
(अं. व द.)

उपआयुक्त
(औ. व सौं.प्र.)

आयुक्त,पुणे

नवभागीय उप
आयुक्त,
नागपूर

नवभागीय उप
आयुक्त,
नानिक

नवभागीय उप
आयुक्त,
कोल्हापूर

नवभागीय उप
आयुक्त नांदेड

नवभागीय उप
आयुक्त
अमरावती

नजल्हा अधीक्षक
कायालये
(एकूण 6)

नजल्हा अधीक्षक
कायालये
(एकूण 4)

नजल्हा अधीक्षक
कायालये
(एकूण 5)

नजल्हा अधीक्षक
कायालये
(एकूण 4)

नजल्हा अधीक्षक
कायालये
(एकूण 5)

1

<!-- page 2 -->

राज्य उत्पादन शुल्क हिभागाची काये :राज्य उत्पादन िुल्क नवभाग प्रामुख्याने पेय मद्य, मद्याककयुक्त /अंमली पदाथांवर उत्पादन िुल्क जमा करण्याचे काम
करतो. तसेच अिा मद्याककयुक्त पदाथांवर ननयंत्रण ठे वण्याचे कामकाज या नवभा मार्कत केले जाते. सदरचा उद्दे ि हा
मद्याककयुक्त पदाथांची ननर्म ती / वाहतुक / नवक्री / बाळगणे / आयात / ननयात इत्या साठी नवनवध अनुज्ञप्ती / परवाने
मंजुर करुन साध्य करण्यात येते. तसेच या पदाथांसंबंधी गुन्हा अन्वेषण करून सक्त अंमलबजावणी व दक्षता राखली
जाते.

आयुक्त, राज्य उत्पादन शुल्क,
महाराष्ट्र राज्य, मुंबई, कायालया

पत्ता

राज्य उत्पादन िुल्क भवन, प्लॉट क्रमांक 1450, महानगर
पानलका सभागृह मागक
मुंबई -400 001.

राज्य उत्पादन शुल्क हिभागातील कायालयाुंचे पत्ते /
अ.क्र.

-

:-

पदनाम

1.

आयुक्त

+91-22-20822477

comm.excise@maharashtra.gov.in
commissioner-excise@mah.gov.in

2.

अपर आयुक्त

+91-22-20822476

addlcom-excise@mah.gov.in

3.

सह- आयुक्त (प्रिासन)

+91-22-20822478

jcadmin-excise@mah.gov.in

4.

सह- आयुक्त (मळी व मद्याकक)

+91-22-20822481

jcam-excise@mah.gov.in

5.

सह- आयुक्त (अंमलबजावणी व दक्षता)

+91-22-20822487

directorev-excise@mah.gov.in

6.

मुख्य ले खानधकारी

+91-22-20822480

Chiefaccoff-excise@mah.gov.in

7.

उप-आयुक्त (औषधे व सौंदयक प्रसाधने )

+91-22-22660163

dycommtp-excise@mah.gov.in

8.

उप-आयुक्त (ननरीक्षण )

+91-22-20822479

dycominspe-excise@mah. gov.in

9.

उप-आयुक्त (मळी व मद्याकक)

+91-22-22665569

dycomam-excise@mah.gov.in

10.

उप-आयुक्त (प्रिासन )

+91-22-22665569

dycomadmin-excise@mah.gov.in

11.

उप-संचालक (सांख्ख्यकी व संगणक )

+91-22-22665571

dydircompstst-excise@mah.gov.in

+91-22-22665569

aoexcisecom@gmail.com

12.

2

<!-- page 3 -->

हिभागीय उप-आयुक्त, राज्य उत्पादन शुल्क, महाराष्ट्र राज्य : अ.क्र.

नवभाग

कायालयाचा पत्ता

दुरध्वनी क्रमांक

1.

ई-मेल

022-25328652

ddcthane-excise@mah.gov.in

2.

0253-2319744

ddcnashik-excise@mah.gov.in

3.

020-26688382

ddcpne@gmail.com

4.

0231-2546027

ddckolhapur-excise@mah.gov.in

0240-2332747

ddccsn-excise@mah.gov.in

0721-2993110

ddcamravati-excise@mah.gov.in

( )

12

5.
431005
6.

,
- 444606

,

7.

,

ddcnanded-excise@mah.gov.in

8.

18

0712-2778100

ddcnagpur-excise@mah.gov.in

अधीक्षक , राज्य उत्पादन शुल्क,महाराष्ट्र राज्य : अ.क्र.

नजल्हा

कायालयाचा पत्ता

1

दुरध्वनी क्रमांक

ई-मेल

,

022-22664801

supdtmcity-excise@mah.gov.in

राज्य उत्पादन िुल्क भवन,
प्लॉट क्रमांक 1450,
महानगर पानलका सभागृह मागक
मुंबई -400 001.

022-20822482

supdtmsd-excise@mah.gov.in

400001
2

3

<!-- page 4 -->

3

022-25320050

supdtthane-excise@mah.gov.in

4

02141-228001

supdtraigad-excise@mah.gov.in

5

02525-240422

supdtpalghar-excise@mah.gov.in

0253-2581033

supdtnashik-excise@mah.gov.in

02564-210024

sptnandurbar-excise@mah.gov.in

8

0256-2241884

supdtdhule-excise@mah.gov.in

9

0257-2223713

supdtjalgaon-excise@mah.gov.in

+91-2026127321

supdtpune-excise@mah.gov.in

+91-24124700860

supdtanagar-excise@mah.gov.in

+91-2172312376

supdtsolapur-excise@mah.gov.in

0231-2546025

supdtkolhapur-excise@mah.gov.in

( )

-

6

422002

7

425412

10

14411001

11
12

13

145413001

12

4

<!-- page 5 -->

14

02162-295575

supdtsatara-excise@mah.gov.in

0233-2670876

supdtsangali-excise@mah.gov.in

02352-222403

sptratnagiri-excise@mah.gov.in

02362-228839

sptsindhudurg-excise@mah.gov.in

0240-2331060

supdtcsn-excise@mah.gov.in

02482-225478

supdtjalna-excise@mah.gov.in

20

0240-2331060

supdtbeed-excise@mah.gov.in

21

0247-2203387

sptdharashiv-excise@mah.gov.in

2462-287616

supdtnanded-excise@mah.gov.in

02456-220106

supdt.exc.hin.@gmail.com

02382-245412

supdtlatur-excise@mah.gov.in

02456-220373

supdtparbhani-excise@mah.gov.in

415001
15

16

,

17

,

18
431001
19
431203

413 501

22

23

431605

431513

24

,
413512

25

431401

5

<!-- page 6 -->

26

0721-2663410

supdtamravati-excise@mah.gov.in

27

07232-244256

supdtyavatmal-excise@mah.gov.in

28

07262-242301

sptbuldhana-excise@mah.gov.in

29

0727-24350

supdtakola-excise@mah.gov.in

30

07252-233700

supdtwashim-excise@mah.gov.in

0712-7770444

supdtnagpur-excise@mah.gov.in

443001

,

444505

31

,
18

32

, 07152-240163

33

07184-252292

supdtbhandara-excise@mah.gov.in

34

07182-233459

supdtgondia-excise@mah.gov.in

35

07172-250595

sptchandrapur-excise@mah.gov.in

07152-240163

supdtgadchi-excise@mah.gov.in

36

-

supsewardha@gmail.com

,

442605

6

<!-- page 7 -->

2.
हिभागाचे अहधकारी ि कमतचारी याुंचे अहधकार ि कततव्ये :
महाराष्ट्र दारूबुं दी अहधहनयम(मुंबई १९४९ चा XXV) अुंतगतत अहधकार
अहधकारी

व्याप्ती

अहधकार

आयुक्त, राज्य उत्पादन
िुल्क

संप ूणक महाराष्ट्र राज्य

i. कलम २८, ४१, ४४(१), ४७(१) नुसार परवाने मंज ूर करणे.

सवक नजल्हानधकारी

त्यांचे ननयुक्तीचे कायकक्षेत्र

कलम २८, ३०, ३१, ३२, ३३, ३४, ३५, ३६, ३७, ३८, ४०(१), ४१,
४४(१), ४५(१), ४६(१), ४७(१), ४८, ५४(१), ६१(२), ६१(३), १०४,
१२३ आनण १३९(१)(डी १) नुसार अनधकार.

अधीक्षक, राज्य उत्पादन
िुल्क

त्यांचे ननयुक्तीचे कायकक्षेत्र

i. कलम २८ नुसार परवाने मंज ूर करणे.

वखार ननरीक्षक

त्यांचे ननयुक्तीचे कायकक्षेत्र

ii. कलम ५२, ६०(१), १०४, १२१(१) आनण १२३ नुसार अनधकार.

ii. कलम ३०, ६१(३), ७७(ए), १२०, १२१(१), १२२, १२३(१),
१२४(१), १२५, १२६, १२७, १२८ आनण १२९(१) नुसार अनधकार.
i. कलम २८ नुसार परवाने मंज ूर करणे.
ii. कलम ७७(ए), १२०, १२१(१), १२२, १२३(१), १२५, १२६, १२७,
१२८(२) आनण १२९(१) नुसार अनधकार.

सवक ननरीक्षक, राज्य उत्पादन
िुल्क

त्यांचे ननयुक्तीचे कायकक्षेत्र

i. कलम २८ नुसार परवाने मंज ूर करणे.

सवक आसवनी प्रभारी
ननरीक्षक, राज्य उत्पादन
िुल्क

त्यांचे ननयुक्तीचे कायकक्षेत्र

कलम २८ नुसार परवाने मंज ूर करणे.

सवक दुय्यम-ननरीक्षक, राज्य
उत्पादन िुल्क

त्यांचे ननयुक्तीचे कायकक्षेत्र

i. कलम २८ नुसार परवाने मंज ूर करणे

वखार ककवा आसवनीचा
प्रभारी अनधकारी

ज्या कायकक्षेत्रामध्ये मद्याचा
पुरवठा होतो

i. कलम २८ नुसार दे िी मद्य वाहतुकीचे परवाने मंज ूर करणे.

पेय मद्य ननमाणी व ब्रुअरी
वरील दुय्यम ननरीक्षक व
त्यावरील दजाचे प्रभारी
अनधकारी

त्यांचे ननयुक्तीचे कायकक्षेत्र

कलम २८ नुसार नवदे िी मद्य वाहतुक व ननयातीचे परवाने मंज ूर
करणे.

ii. कलम ६१(३), ७७(ए), १२०, १२१(१), १२२, १२३, १२५, १२६,
१२७, १२८(२) आनण १२९(१) नुसार अनधकार.

ii. कलम ७७(ए), १२०, १२१(१), १२२, १२३, १२५, १२६, १२७,
१२८(२) आनण १२९(१) नुसार अनधकार.

ii. कलम ६१(३) नुसार साखर कारखान्यापासून आसवानी पयंतचे
वाहतूक परवाने दे णे.

7

<!-- page 8 -->

सवक सहाय्यक दुय्यम
ननरीक्षक, राज्य उत्पादन
िुल्क

त्यांचे ननयुक्तीचे कायकक्षेत्र

कलम १२०, १२१(१), १२२, १२५, १२६ आनण १२८(२) नुसार
अनधकार.

सवक जवान, राज्य उत्पादन
िुल्क

त्यांचे ननयुक्तीचे कायकक्षेत्र

कलम १२५ नुसार अनधकार.

कलम १०० आहि १०१ नुसार अहधकार
अधीक्षक, राज्य उत्पादन
िुल्क

त्यांचे ननयुक्तीचे कायकक्षेत्र

गुन्यातील जप्त मुद्देमालाची अंदानजत ककमत रुपये पंचवीस
हजारांपयंत.

नवभागीय उप-आयुक्त, राज्य त्यांचे ननयुक्तीचे कायकक्षेत्र
उत्पादन िुल्क

गुन्यातील जप्त मुद्देमालाची अंदानजत ककमत रुपये पंचवीस
हजारांपेक्षा जास्त ते एक लाखांपयंत.

आयुक्त, राज्य उत्पादन
िुल्क

गुन्यातील जप्त मुद्देमालाची अंदानजत ककमत रुपये एक लाखांपेक्षा
जास्त.

महाराष्ट्रातील सवक नजल्हे

अधत न्याहयक अहधकार
.

.

.

.

8

<!-- page 9 -->

(

)

(

)

प्रशासकीय ि हित्तीय अहधकार :हनयम क्रमाुंक

शक्क्तचे िितन

प्राहधकार /आदे श क्रमाुंक

आयुक्त, राज्य उत्पादन शुल्क याुंचे कायालयातील "मुख्य लेखा अहधकारी "
महाराष्ट्र आकख्स्मक खचक
ननयंत्रण अनधकारी म्हणून
ननयम पुख्स्तका, १९६५ ननयम दे यक प्रनतस्वाक्षरी करण्याचे
क्र. १८ व २२
अनधकार.

आयुक्त, राज्य उत्पादन िुल्क यांचे आदे ि क्र.पीवायबी /१०८३/
सात(ए), नद.२८.९.१९८३

मुंबई नवत्तीय ननयम, १९५९
ननयम क्र. ३९(ब)

सहा वषापेक्षा जास्त काळ
आयुक्त, राज्य उत्पादन िुल्क यांचे आदे ि क्र.पीवायबी /१०८३/
अस्थनगत रानहले ल्या परं तु
सात(ए), नद.२८.९.१९८३
मुदती बाबतच्या
कायद्यानुसार कालबाय न
झाले ल्या अिा वेतन ककवा
भत्ते वेतनवाढी यांच्या
थकबाकीच्या मागण्यांच्या
रकमा दे ण्यासाठी मंजुरी दे णे.

महाराष्ट्र नागरी सेवा (वेतन)
ननयम, १९८१ पनरनिष्ट्ट एक
अ.क्र. १०, ननयम क्र. ३६
िेरा "बी”

आयुक्तालयाच्या
आयुक्त, राज्य उत्पादन िुल्क यांचे आदे ि क्र.वेतन/११९३/िा/
कायक क्षेतील राजपत्रीत
अ.प्र./१२/९३, नद.२०.१.१९९४
अनधकाऱयांच्या/ अराजपत्रीत
कमकचाऱयांच्या वार्मषक
वेतनवाढी मंज ूर करणे.

महाराष्ट्र अथकसंकल्प ननयम
पुख्स्तका खंड-१ पनर. १४४

ननयंत्रण अनधकाऱयाने
अनुदान वाटप करणे.

नवनत्तय अनधकार ननयम
स्टाप कार/ िासकीय
पुख्स्तका १९७८ भाग- पनहला, वाहनासाठी पेरोल, नडझे ल,
उप नवभाग दोन,
वंगण तेल/ इंनजन ऑईल

आयुक्त, राज्य उत्पादन िुल्क यांचे आदे ि क्र.पीवायबी /१०८३/
सात(ए), नद.२८.९.१९८३
आयुक्त, राज्य उत्पादन िुल्क यांचे आदे ि क्र.वेतन-१३(क),
नदनांक ९.२.१९९६

9

<!-- page 10 -->

अ.क्र.१९(अ), महाराष्ट्र
आकख्स्मक खचक ननयम,
१९६५ मधील ननयम क्र. ६९

खरे दी करण्यासाठी खचास
मंजुरी दे णे.

आयुक्त, राज्य उत्पादन शुल्क याुंचे कायालयातील "उप-आयुक्त (प्रशासन)"
नवनत्तय अनधकारांचा वापर
प्रादे निक कायालय प्रमुख
करण्यासाठी ज्या
प्रानधकाऱयांना प्रादे निक
प्रमुख म्हणून मान्यता नदलेली
आहे ते प्रानधकारी

नवनत्तय अनधकार ननयम पुख्स्तका १९७८ भाग- पनहला, सवक
नवभागांना समान असलेले अनधकार , जोडपत्र तीन, अनुक्रमांक
१७ अनुसार

आयुक्त, राज्य उत्पादन शुल्क याुंचे कायालयातील "लेखा अहधकारी "
महाराष्ट्र कोषागार
आयुक्त, राज्य उत्पादन
ननयमावली, १९६८ ननयम क्र. िुल्क यांचे कायालयािी
१५६
संबंधीत मुख्य ले खा निषक
"२०३९ राज्य उत्पादन
िुल्क" या निषाखालील सवक
प्रवास भत्ता दे यके,
आकख्स्मक खचाची दे यके,
वेतन दे यके इत्यादी संबंधात
आहरण व संनवतरण
अनधकारी म्हणून स्वाक्षरी
करणे.

आयुक्त, राज्य उत्पादन िुल्क यांचे आदे ि क्र.पीवायबी /१०८३/
सात(ए), नद.२८.९.१९८३

आयुक्त, राज्य उत्पादन शुल्क याुंचे कायालयातील "सहाय्यक आयुक्त, राज्य उत्पादन शुल्क(आस्थापना)"
महाराष्ट्र नागरी सेवा (रजा)
ननयम, १९८१ पनरनिष्ट्ट एक
अ.क्र. ५, ननयम क्र. २७
समोरील स्तंभ क्र. ६

आयुक्तालयाच्या
आयुक्त, राज्य उत्पादन िुल्क यांचे आदे ि क्र. इएसटी
अराजपत्रीत िासकीय
११९६/५५/दोन-अ, नद. १.३.१९९६
कमकचाऱयांना नविेष
नवकलांगता रजा आनण
अध्ययन रजा या व्यनतनरक्त
इतर सवक प्रकारच्या रजा मंज ूर
करणे.

10

<!-- page 11 -->

3. हनितय घे ण्याच्या प्रहक्रये त अनुसरण्यात ये िारी कायत पद्धती , तसेच पयत िेक्षि आहि उत्तरदाहयत्ि प्रिाली:
-:

:-

-

(

)

-

-: हिभागीय उप-आयुक्त, राज्य उत्पादन शुल्क याुंचे कायालय :हिभागीय उप-आयुक्त

ले खानधकारी
सहाय्

सहाय्यक आयुक्त

लेखानधकारी

कायालय अधीक्षक

ले खापाल

वनरष्ट्ठ नलनपक
नलनपक-टं कले खक

11

<!-- page 12 -->

-: अधीक्षक, राज्य उत्पादन शुल्क याुंचे कायालय :-

–

–

4.

स्ितःची काये पार पाडण्यासाठी हिभागाकडू न ठरहिण्यात आलेली मानके:

नवभागाचा सन 2024-2025 या आर्मथक वषाचा KRA (Key Result Areas) ननख्चचत करण्यात आलेला आहे .
State Excise Departnment
Government of Maharashtra
Key Result Area (KRA) 2024-25
No

Objective

Weight

Activity
Number

1

Ensuring
achievemen
t of 100%
Revenue
Target in
the State
exchequer
Sub Total

20

1

2

Developme
nt of Digital
Supply
Chain
Managemen
t

Action

Success
Indicator
Collection Of Revenue
Collection of State Collection
Of
Excise Duty
Excise Duty on
Spirits,
Beer,Wine
&
Country Liquor

Unit

INR
Cr.

in

Target

Achievement

30500

17297.49
(Tentative up
to 31
December
2024)

9

Fully
Functional
service
Modules

20
20

3

Supply Chain Management
1. Development
Implementation
and functiononing of Renewal
of Renewal
module -6
Service thrugh
Service
SCM portal
Implementation
2. Approval of
of Brand
Brand (within
Registration -3
State) Labels of
modules
12

numbers

-9

<!-- page 13 -->

Manufactories
/breweries in the
state
3. Approval of
Brand Labels of
Imported Foreign
Liquor under L
form/ K form
Sub Total

20
Improved Service Delivery

3

4

Efficent
functioning
of the
dept/better
services to
licensees
and the
consumers

10

3

10

4

Sub Total

20

Training
Department
personnel
for better
results and
revenue
enchancem

15

2

134 Service to be
notified under
RTS

Creating
defiened
timelines
for
the
Service
Dilivery

No
of
Services

Implementation
of online service
through aaple
sarkar portal

Developingand
functioning of
Online Module
for 8 services
(formCL/FL/TO
D3 Licence,
Form L
Registraction
certificate,
Shifting of CLIII Licence,
Shifting of FLIILicence,
Transfer of
Licence CL-III,
Transfer of
Licence FL-II,
Addition and
Deletion of
partner/s form
CL-III/FL-II )

Online
Module
for
service

Training
1. Traning Effective
of
new enforcement
recruit 10 and an active
clerk and 1 force
Stenograph
er (L.G)
2. Refresher
13

Number

134

All 134
services are
notified under
RTS vide
notification
dated 14th
Nov,2024

8
All 8 services
are online Now

54

Training of 54
Staff persons
will
be
completed by
31st
march
2025.

<!-- page 14 -->

ent

5

training of
promoted
33
inspector, 6
O.S Total 5
N.A

Sub Total

15

Human
resource
developme
nt policies

5

10

1

11

Human Resource Development
Restructuri Sanction of the
ng of the
rewised
Departnme structure
&
nt
Staffing pattern
of
the
department

Recruitmen
t process &
promotion

1. Recruitment
of 6 subInspector,2
Clerk & 575
Constables,73
Driver-cumconstable, 18
Steno-Typist, 5
Stenographer,
54 Peon

2. Promotion of
the 1 Joint
Commissioner,
35
Inspector,
15
SubInspector,1
Stenographer
(L.G) 6 O.S, 5
N.A,2 Clerk.
Sub Total
6

Computeris
ation

Governm
ent
resolutio
n

1

G.R for
restructuring
of the
department is
issued on 18th
june 2024

733
1.
Recurutment
of 653 posts is
completed
remaning
recruitment of
80 posts will
be completed
before 31st
march 2025.
2. Promotion
of 65 posts is
completed .
Numbers

65

15
5

1

5

1

Computerisation
Implementa Fully
tion of E- operational
office
system
systemat
commission
rate
Reciving
Making
tapal
compulsory
14

E-office
module

1

Completed
before march
2025

Order

1

Completed
before march

<!-- page 15 -->

through Eoffice Portal
Sub Total

sending e-tapal

2025

10

आयुक्त, राज्य उत्पादन शुल्क याुंचे पहरपत्रक क्रमाुंक दै नुंहदनी 1014/ 1462/14/तीन, हदनाुंक 19
,2017 नुसार हिभागातील अहधकाऱयाुंच्या कायत क्षेत्रातील अनुज्ञप्तींच्या हनरीक्षिाची िारुं िारीता खालीलप्रमािे
हनक्चचत करण्यात आलेली आहे .

1

I ,PLL, CL-I,L-I ,RS-II ,RS-VII,DS-V, DSVI (
)

2

FL-I, FL-II, FL-III, FL-IV,CL-II,CL-III,FLW-I, FL-W-II,FL/BR/II , E,E-II
-

- (

)

5

M-I,RS-VI, RS-VI-A,DSP-I,MF-I,MF-II, TD-I

3
(

-

-

-

-

-

)

-

-

-

-

-

(

)

RS-II (Educational , Medicinal and Research
Purpose)

5.

हिभागाची काये पार पाडण्यासाठी हिभागातील अहधकारी / कमत चारी याुंच्याकडू न िापरण्यात ये िारे कायदे ,
हनयम, हिहनयम ि पहरपत्रके :
नवभागासंबंनधत कायदे , ननयम, नवननयम व पनरपत्रके नवभागाच्या संकेतस्थळावर अपलोड करण्यात आले ले आहे त.

15

<!-- page 16 -->

6.

हिभागाकडे असलेल्या दस्तऐिजाुंच्या प्रि

हििरि :

As per The Bombay Excise Manual Volume II (Part IV) para 499 the preservation, sorting and destruction
of excise records should be done in accordance with the A, B, C, D lists.

Serial
NO.

Document

Remarks and
instructions.

Commissioner.

Superintendent
of Excise

Distiller-y
Officers

Inspectors
and Sub
Inspectors

Ware
house
Officers

Administration Books and Publications.
1

Indents for books &
publications

….

C

C

C

D

D

2

Memos, advising the
dispatch of Acts,
books, journals, etc.,
and all auxiliary
correspondence
intimating number
of copies , required
complaints of nonreceipts, etc

…….

D

D

D

D

D

3

Distribution memos
and receipts for
books and
publications.

…….

D

D

D

D

D

4

Circulation memos,
covering printed
papers and reports

Note fact of
circulation on
the document
itself.

D

D

D

D

D

While in use
keep in library.

C

…

C

C

C

A

..

A

A

A

Library catalogue or
list of books and
publications

When old or
disfigured,
recopy and file
old catalogue
as….

5

6

Acts, departmental

Enter in

16

<!-- page 17 -->

and other manuals,
Compilation of
Standing Orders
books, maps,
Gazetteers,
Selections, printed
Administration
Reports and the like

classified library
catalogue noting
date of receipt,
removal, etc.
When obsolete
or superseded
by new editions
they are treated
as…

D

…..

D

D

D

Dead Stock.

7

Register of Dead
articles

Keep till new
one is prepared
and afterwards.

C

….

C

C

C

8

Purchase of Dead
Stock, sanction,
allotments, bills, etc.

Enter in Register
with sufficient
particulars.

C

….

C

D

D

9

Sale, loss or writing
off Dead Stock.

Do ….

C

….

C

C

C

10

Correspondence
regarding loss and
replacement of
Dead Stock articles.

…..

D

…..

D

D

D

11

Annual reports
regarding the state
of Dead stock
articles.

….

D

…..

D

D

D

Forms and Stationery.

12

Model indents for
Stationery and
forms

Till modified and
superseded.

A

…

A

A

A

13

Indents for
Stationery, forms
and envelopes.

….

C

….

C

C

C

14

Correspondence
regarding the supply
of Typewriters.

….

C

….

C

….

….

17

<!-- page 18 -->

15

Indents for rubber
stamps and
acknowledgments
of stamps, etc.

…

C

…

C

C

C

16

Correspondence
regarding grant for
Stationary supplied
by the Stationary
Department.

C in the office to
which it relates.

C

…

C

…

…

17

Printing of forms as
standard or special
forms.

….

B

B

C

D

D

18

Letters to the
Government
Printing Press
regarding printing
and supply of forms.

….

C

C

C

…

…

19

Correspondence
regarding
modification in or
revision of license
forms.

….

C

C

C

D

D

20

Advices of dispatch
of Stationary and
forms.

….

D

…

D

D

D

21

Indent and memos
of requirements of
Stationary from
subordinate officers.

….

…

…

D

D

D

22

Insertion of
advertisements in
newspapers or
Gazette.

D

D

D

…

…

23

Accounts of
Stationary and
forms.

….

C

…

C

C

C

24

Register of
distribution of
Stationary to Office
members.

….

D

…

D

D

D

Weed out of
cases and
destroy after
insertion.

18

<!-- page 19 -->

25

Correspondence
regarding dispatch
of Stationary and
forms and
complaints about
short supply, etc.

….

…

D

D

D

D

Laws, Rules and General Correspondence

26

Government
Resolutions

All Government
Resolutions
(except those of
ephemeral
nature which
may be), should
be kept as A.

27

Circulars and
Standing Orders
issued by
Government,
Commissioner,
Collectors,
Accountant General,
Chief Account
Officer or
Superintendents.

Enter into
manuals, if any

A

A

A

A

A

28

Buildings and
decisions of
Commissioner,
Collector or
Superintendents.

…

B

B

B

B

B

29

Powers and duties
of all Officers with
regard to the Excise
Administration.

Until a manual is
issued

A

A

A

A

A

C

C

C

A

A

A

A

A

ADMINSTRATION

30

Discussions on
points of principle,
interpretation,
procedure or
Administration
which do not result
in the issue of any
orders.

If orders are
issued, the case
falls under 28 or
29

B

C

19

<!-- page 20 -->

31

Office copies of
reports on council
bills set for opinion.

Unless
reproduced in a
Government
Resolution.

B

C

C

D

D

32

Enquires from other
Provinces, Districts
or Ranges as to
practice or
procedure.

If the discussion
leads to any
orders, they will
be recorded in
due course.

D

D

D

D

D

33

Changes of limits of
Officers'
jurisdictions.

Weed out and
preserve chief
reasons.

A

A

A

C

C

34

Office copy of
Administration
Report.

…

B

B

B

B

B

34A

Appendices to
Administration
Report.

….

C

B

B

B

B

35

Subordinate
Officers' annual
reports with
appendices.

…..

C

C

C

..

..

36

Notices calling for
applications for
appointments or
tenders, etc.

….

C

C

C

C

C

37

Rules and
Regulations under
the Abkari and
Opium Acts and
correspondence
relating thereto.

…

A

A

A

A

A

38

Correspondence
regarding the Excise
and Opium
Manuals.

Keep till the
manuals are
corrected or
reprinted.

….

….

….

….

….

20

<!-- page 21 -->

Government Gazettes.

39

Bombay
Government
Gazette, Part-I

Do.
40
Part I-A

Do.
41

. Part II
(Miscellaneous
Notices).

The commissioner keeps a
complete set.
Superintendents
keep their copy
as B and
thereafter can
preserve only
those pages
which contain
Notifications
relating to Excise
matters.

A

…

B

Not
supplied

The supply to
the
superintendents
has since been
discontinued.

C

..

C

Do.

The
superintendents
can preserve
permanently
only those pages
of the old
Gazettes which
contain
important
Notifications
relating to Excise
matters, the rest
being treated as
C.

C

..

C

Do.

….

C

..

..

Do.

Until the Acts
are printed in
books.

A

..

..

Not
supplied

Do.
42

Part III (Prices,
Current Rainfall,
etc.).
Gazette of India,
Part IV

43

(India Acts).

21

<!-- page 22 -->

Gazette of India,
Part V

…

B

..

..

Do.

45

Bombay
Government
Gazette, Parts IV, IVA, B & C (Bombay
Acts, Notifications.
Etc.)

Until the Acts
are printed in
books.

A

..

..

Do.

46

Bombay
Government
Gazette, Parts V
(Bombay
Preceding.)

…

B

..

..

Do.

47

Bombay
Government
Gazette, Parts VIII
(Trade Returns.)

….

C

..

..

Do.

48

Bombay
Government
Gazette, Parts IX
(Supply and
Transport Notices,
etc.)

….

C

..

..

Do.

49

Bombay
Government
Gazette, Parts
X,XI,XII (Vernacular
Act.)

….

B

..

..

Do.

The Supply to
superintendents
has since been
discontinued.

C

..

C

Do.

Always reprinted
in the following
ordinary
Gazette.

D

..

D

Do.

44

(India Proceedings).

50

51

Bombay
Government
Gazette,
Supplements.

Bombay
Government
Gazette,
Extraordinary.

22

<!-- page 23 -->

52

Bombay
Government
Gazette, Annual
Index.

…

A

..

A

53

Excise Supplement
to the Police
Gazette.

…

B

B

B

B

B

Do.

Records.
Indexes of records
and filed papers (A
and B.)

…

A

A

A

A

A

55

List or Pherists of B
papers destroyed.

Do not prepare
them in future,
but if any do
exist they should
be treated as…

D

D

D

D

D

56

Loss or damage to
records or current
documents and
their replacement.

After
settlement, note
in Index and
then…

D

D

D

D

D

57

Applications for
copies or searches
including receipts
for comparing fees
and cost of papers
etc.

…

C

C

C

C

C

Inward and Outward
Registers

Keep for 30
years and then
destroy after the
A and B papers
are entered in
the General
Index.

B

..

B

B

B

Current Register

After the records
are sorted and
General Index
prepared.

B

B

B

B

B

Do. do.

B

B

B

B

B

54

58

59

Disposal Register
60

23

<!-- page 24 -->

61

Registers of
Periodicals

…..

D

D

D

D

D

62

General Index of A
and B papers and
Government
Resolutions.

…

A

A

A

A

A

63

Peons' Book for
hand delivery

….

D

..

D

D

D

64

Accounts or Service
Stamps and postal
despatch book.

….

C

..

C

C

C

65

Indent for and all
correspondence
about the supply of
postage stamps.

Enter order and
notes supplies
and issues to
Account Book.

D

…

D

D

D

66

Reports and Returns
as to the state of
work (unanswered
references, pending
cases, progress in
sorting records, etc.)

….

D

…

D

D

D

67

Desk Diaries and
Calendars

Calendars to be
treated as C.

D

…

D

D

D

68

Discrepancy memos,
on Inspection of
records in which no
general order are
issued.

After entry in
the register of
discrepancies
and disposal of
the same.

D

…

D

D

D

68 A

Inspection report
covering the
discrepancy memos.

…

C

..

C

C

C

69

Discrepancy memos
in which some
general orders are
issued.

Till entered in
manual...

B

..

B

B

B

70

Register of
discrepancies …

..

..

..

C

C

C

71

Register of Copying
Fees …

..

..

..

C

C

C

24

<!-- page 25 -->

Tours

72

Tour Program of
Commissioner,
Collector or other
Officers.

…

D

…

D

D

D

73

Instructions about
posts, telegrams
and general
arrangement about
window delivery,
special bags, etc.

..

C

..

C

D

D

74

Correspondence
regarding supply of
provisions, carts
collies, wagons, etc.,
and the rates.

….

D

…

D

D

D

If no important
principle is
involved

D

…

D

D

D

75

Complaints about
supply of provision,
carts, coolies, etc.,

Otherwise …

B

..

B

B

B

76

Telephone and
Postal bag bills.

…

C

..

C

..

..

77

Diaries of
subordinate
officers- Office
copies in
dispatching office
and fair copies in
receiving office.

…

C

..

C

C

C

78

Travelling Allowance
Bills with
acquittances

Travelling
allowance bills
and memos,
received from
sub-offices for
incorporation In
the general bill
should be
treated as D.

C

..

C

C

C

79

Enquiries about
distances for

..

D

D

D

D

D

25

<!-- page 26 -->

Travelling allowance
purpose.

80

Register of
Travelling Allowance
and Diaries, dairy
books and
inspection books or
the diary of Excise
Officers.

..

C

..

C

C

C

81

Purchase of tents
for Government
use.

..

B

..

B

..

..

82

Diaries of
superintendents

…

C

C

C

…

…

BUILDINGS (Bld.)
Public Works Department

1

List of Major works
submitted to
Commissioner.

The works if
approved are
entered in the
Public Works
Budget.

2

Proposals for Major
works, i.e.,
correspondence in
connection with the
calling of rough
plans and estimates,
information for rent
statement,
correspondence
regarding
accommodation
required, selection
of sites, acquisition,
of land for the
works, etc.

The Government
Resolutions
sanctioning the
plans will be
kept
permanently.

B

..

B

B

B

3

Proposals regarding
transfer of buildings
to departmental list.

These will be
entered in the
list of buildings.

C

C

D

D

D

C

..

C

C

C

26

<!-- page 27 -->

4

Correspondence
regarding transfer of
buildings from one
Department to
another.

Do…

A

B

B

B

..

5

List of minor works,
correspondence
regarding additions
and alterations
required, regarding
calling for plans and
estimates, allotment
of funds and
particulars for rent
statement, etc.

..

C

..

C

C

C

6

Correspondence
regarding
completion
certificates.

…

C

..

C

D

D

7

Correspondence
with the Public
Works Department
with regard to petty
repairs or special
repairs and weather
fencing.

…

..

..

D

D

D

Register of Buildings

Keep till new
one is received;
correction slips
to be destroyed
after correcting
the list.

…

…

..

..

..

..

C

C

C

8

Departmental

9

Proposals for
construction of new
buildings and
additions and
buildings and
additions and
alterations
(approved or
negatived ) and
correspondence

Note in the
Register of
Buildings the
Government
Notification
regarding
acquisition of
land or District
Collector's No.
regarding

C

27

<!-- page 28 -->

regarding selection
of sites, acquisition
of land and plants
and estimates.

transfer of waste
fund.

10

Contracts for the
construction of
Departmental
Buildings.

…

C

..

C

C

C

11

Correspondence in
connection with
petty repairs,
weather fences and
tile truning.

..

..

..

C

C

C

12

Agreements with
Building contractors.

..

..

..

C

C

C

13

Correspondence
regarding breach of
contracts.

..

Z

..

Z

Z

Z

14

Proposals for the
grant of house-rent
allowance.

..

B

B

B

B

Hire and less of
buildings for
Establishment and
office
accommodation.

These may be
destroyed as
soon as the
arrangement
ceases to have
effect.

B

…

B

B

B

16

Dismantling of
Departmental
buildings or strike
off the list.

Correct the list
of buildings
quoting
authority.

D

..

D

D

D

17

Register of
Departmental
buildings and lend
acquired for the.

Keep till
renewed.

..

..

..

..

..

15

28

<!-- page 29 -->

18

Rent, Rates and
Taxes Bill and
correspondence
relating thereto.

…

C

..

C

C

C

18 A

Statement showing
the Government
buildings, occupied
by Excise Officers
for residential
purposes.

…

C

C

C

C

C

ESTABLISHMENT (ESTT.)

1

Discussions and
orders about
strength of fixed
Establishment scales
of pay, fixed
travelling
allowances, status,
etc.

Weed well,
usually final
Government
Resolution
suffices.

B

..

B

C

C

2

Entertainment of
temporary clerks
and peons.

..

C

..

C

D

D

These are
entered in the
Register of
approved
candidates and
filed with the
list. The rest can
be destroyed
after disposal.

D

..

..

..

..

Applications for
executive and
clerical
appointments.
3

4

Applications for
menial
appointments.

Do…

D

..

D

D

D

5

Intimations of
appointments and
postings of Gazetted
officers.

Do not keep
after disposal

D

..

D

..

..

29

<!-- page 30 -->

6

Appointments and
transfers of nongazetted officers
and clerks and
applications for
transfer and
promotions.

….

C

…

D

D

D

7

Appointment and
transfers of menials
and applications for
transfers and
promotions.

..

..

..

C

D

D

8

Service Books and
Sheets..

Are current
records so long
as officers serve;
then return to
pensioners or
heirs.

..

..

..

..

..

9

Correspondence
regarding
transmission of
service papers and
verification of
thumb impressions
and marks of
identification.

…

D

..

D

D

D

10

Physical fitness
certificates.

Attach to first
pay bills;
correspondence
to be treated as.

D

..

D

D

D

11

Printed Directories
of the Excise
Department.

(After receipt of
fresh ones).

D

D

D

..

..

12

Particulars required
for corrections in
Directories.

..

D

..

D

D

D

13

Gradation as well as
distribution list of
menials.

Keep till
renewed

…

..

..

..

..

30

<!-- page 31 -->

14

Application for leave
of all kinds
sanctioned or
refused by the
Commissioner or
the Superintendent.

(After return
from leave and
entry in the
service papers.)

D

..

D

D

D

15

Applications for
acting and
sub,prortem.
Allowances.

…

D

..

D

D

D

16

All papers about
casual leave

After note in
Register

D

..

D

D

D

17

Charge reports and
correspondence
regarding relief and
joining of men
appointed of
transferred.

After note in the
Directory.

D

..

D

D

D

18

Annual qualification
reports and returns.

…

D

..

C

D

D

19

Alleged defalcation,
misconduct fines
and reductions.

Copies of orders
should be
attached to
service book and
the papers may
be retained int
Superintendent's
office. In the
case of fine
inflicted on
menials papers
may be closed as
D.No. Order
need be
attached to
Service sheets.

Z

..

Z

Z

Z

20

Dismissals,
invalidings,discharge
on reduction, etc.

Weed out
useless papers
which are to be
treated as D.

C

..

C

D

D

21

Charge sheets..

All fines and
particulars to be

D

..

D

D

D

31

<!-- page 32 -->

noted in service
sheets.

22

Fine and
Punishment
Returns.

..

D

..

D

D

D

23

Returns of landed
property of
Gazetted and
ministerial officers
and correspondence
relating thereto.

Note abstracts in
Service Books.

D

..

D

D

D

24

Correspondence
regarding sureties
(including enquiries
regarding solvency
grant and
cancellation of
certificates, etc.).

..

C

C

C

D

D

Omit the names
of officers
transferred,
retired ,etc and
enter new
names. Destroy
when a new
Register is made.

..

..

..

..

..

Register of names of
nearest relatives,
etc of Europeans.
25

26

Indebtedness of
Government
Servants.

…

B

..

B

C

C

27

Acceptance of
presents by
Government
employees.

…

B

..

B

..

..

28

Permission granted
to leave Headquarters on
holidays.

..

D

..

D

D

D

29

Resignations,
desertions and
deaths.

..

D

..

D

D

D

32

<!-- page 33 -->

30

Prosecution of
Government
servants by
Government or
privates parties and
grant of legal
assistance to them.

…

B

B

B

B

B

31

Registers of
approved
candidates for
executive and
clerical line.

Keep till
renewed

…

…

…

…

…

32

Register of
approved
candidates for
peon's posts.

Keep till
renewed

…

…

…

…

…

33

Casual leave
Register

..

D

..

D

D

D

34

Acquaintance or
Master Roll

..

C

..

C

C

C

35

Correspondence
regarding men sent
to Pasteur Institute
for Anti-rabbis
Treatment.

..

C

..

C

D

D

36

Correspondence
regarding
Vaccination

..

..

…

D

D

D

37

List of title-holders
and correspondence
relating thereto.

List to be kept as
C

D

..

D

D

D

38

Income-tax
declarations,
statements and
correspondence
regarding refund of
income tax etc.

Important
correspondence
to be kept as C.

D

…

D

D

D

38 A

Register of Incometax

..

..

..

C

..

..

33

<!-- page 34 -->

39

Application Register

..

C

..

C

..

..

40

Register of Warning

Keep till
renewed

…

…

…

…

…

41

Grant of medals and
badges and
correspondence
regarding thereto.

..

C

..

C

D

D

42

Indents for peon's
uniforms belts
battens etc.

..

C

..

C

C

C

43

Supply and
distribution of
uniforms, etc., and
complaints about
short supply.

…

D

…

D

D

D

44

Correspondence
repayment of bills
for uniforms, belts,
etc.

Bills to be kept
as C and the
Correspondence
as D.

C

..

C

C

C

45

Loss of damage to
uniform by theft or
fire and supply of
new one.

..

C

..

C

C

C

46

Scale of uniform

..

B

..

B

B

B

47

Dress Register

Keep till
renewed

C

..

C

C

C

48

Register of deaths
among European
officers.

Do.

C

..

C

C

C

49

Annual
Establishment
return with
accompaniment.

..

C

..

C

C

C

D

D

D

D

D

49A

Drilling of excise
menials.

Except standing
orders which
should be kept
as A.

34

<!-- page 35 -->

Departmental Examination.

50

Permission to
appear for Lower
and Higher Standard
Examinations.

..

D

..

D

D

D

51

Correspondence
with the Secretary
to the Permanent
Committee for
departmental
Examination re:
question papers,
etc.

..

D

…

..

..

..

52

Intimation to the
Civil and Military
Examination
Committee re:
Examination of
officers in
Vernacular.

..

D

..

D

D

D

53

Appointment of
Committee for
Departmental
Examination of
candidates for clerks
posts.

..

D

..

D

D

D

54

Question papers set
at the Examination.

..

D

…

D

..

..

55

Answer papers …

D

…

D

..

..

56

Intimation about
persons intending to
appear for the
Departmental
Examination.

..

D

..

D

D

D

57

Report regarding
the result of the
Department
Examination and
transmission of
certificates.

…

D

..

D

D

D

35

<!-- page 36 -->

Pay and Allowances.

58

Sanction to
advances for tent
age house building
motors horses,
cycles, conveyances,
etc., and advance on
transfer.

..

C

..

C

D

D

59

Eligibility and
condition of
subscription to
General Provident
Fund.

..

C

..

C

C

C

60

Sanction to advance
from General
Provident Fund.

..

C

..

D

D

D

61

Grain compensation
certificates,
correspondence and
office copies.

Attach
certificates to
bills which are to
be treated as C.

D

..

D

D

D

62

Plague allowance
for hutting with all
papers except
standing orders.

Bills to be
treated as
contingent bills.

C

..

C

C

C

63

Salary bills of
Gazetted officers

…

C

..

C

..

..

64

Salary bills of nongazetted officers
and clerks.

..

B

..

B

B

B

65

Salary bills of
menials

..

B

..

B

B

B

66

Correspondence re:
withheld salaries
and Last Pay
Certificates.

No office copies
of the Last Pay
Certificates need
be kept.

D

..

D

D

D

67

Notices of
attachment of salary
by civil court.

Keep current in
Superintendent's
office till
satisfied.

D

..

D

D

D

36

<!-- page 37 -->

68

Service of
summonses on
employees.

Return
summonses to
court.

D

..

D

D

D

69

Recovery from court
of Bhatta to
Government
servants.

After credit into
treasury

D

..

D

D

D

70

Distribution
statement of Extra
Work Fees, recovery
of fees, etc.

Bills to be
treated as
contingent bills
and kept as C.

D

..

D

D

D

71

Admission to Postal
Insurance Fund.

..

D

..

D

D

D

72

Admission to
Bombay
Uncovenanted
Service Family
pension fund.

..

D

..

D

D

D

73

Correspondence re:
recovery of Pension
Fund from menials.

General orders
to be retained as
A papers and the
rest as -

D

..

D

D

D

74

Payment of
allowance for work
done on behalf of
Municipalities.

Only retain the
final order.

A

A

A

A

A

Standing Orders

…

A

A

A

A

A

Bills

..

C

C

C

C

C

Correspondence

..

D

D

D

D

D

..

D

D

D

Bad climate and
compensatory
allowances74 A

Pensions.

75

Annual
Superannuation
statements and
orders passed
thereon.

When fresh
statements are
received, the old
onesare useless.

C

37

<!-- page 38 -->

76

Individual
correspondence and
applications for
extension or for
permission to retire.

..

C

..

C

D

D

77

Correspondence re:
grant or refusal of
pension and
gratuities and
verification of
services and all
other preliminary
papers including
Pension Payment
orders.

..

C

..

C

D

D

78

Correspondence re:
commutation of
pensions.

…

C

..

C

C

C

EXCISE (Ex)
Abkari Leases

1

Agreements with
Native States re:
Abkari leases and
correspondences
relating there to.

Agreements and
important
correspondence
to be kept as A,
the rest as -

C

C

C

..

..

2

Compensation bills
and correspondence
relating thereto.

Government
Resolutions to
be kept in their
file.

C

C

..

..

..

Government
Resolutions to
be filed
separately.
Papers regarding
these meetings
of these
committees may
be classed as "E"
only the minutes

C

C

C

C

..

Advisory
Committees.

3

Proceedings of the
over country and
foreign liquor and
the orders passed
thereon.

38

<!-- page 39 -->

to be kept as B".
Confiscations.

4

Correspondence re:
Seizure, disposal,
sale, etc., of
confiscated
excisable articles.

..

C

C

C

C

C

5

Registers of
confiscated articles.

….

..

..

C

C

C

C

C

..

..

C

C

C

C

Council Questions.

6

Correspondence re:

If the questions
and the
information
supplied are of
any future use,
the papers
should be
treated as B,
otherwise as-

C

Excise Arrangements

7

Correspondence re:
in British Territory
and with Native
States.

Important
correspondence
to be kept as A,
the rest as -

C

Excise Intelligence Bureau.

8

Correspondence re:
and finger prints.

Papers likely to
be of future use
to be kept as A,
the rest as-

D

..

D

D

..

8A

Register showing
particulars of Excise
convicts (finger
Prints Register.)

Keep till
renewed

A

…

..

A

..

8B

List of Excise
convicts maintained
by Inspectors,
Assistant Inspectors,

..

..

..

..

B

..

39

<!-- page 40 -->

and Sub Inspectors.

8C

Excise supplement Correspondence
regarding
publication and
supply of -

..

D

..

..

…

..

8D

Excise supplement Manuscript copies
of -

To be destroyed
at the end of the
year.

D

..

..

..

..

8E

Excise Supplement list of officers to
whom - is supplied.

When revised
list is prepared
old one to be
destroyed.

A

…

..

..

…

8F

Reports of Excise
cases received for
publication.

…

D

..

..

..

..

8G

Correspondence
regarding photos of
Excise convicts and
suspects.

…

D

..

..

D

..

8H

Excise Supplements
of other Provinces.

…

B

..

..

..

..

8I

List of Excise
Smugglers,….

When revised
copy is received
old one to be
destroyed.

B

..

B

B

..

8J

Excise exhibitsCorrespondence re:
-

..

C

..

..

..

..

8K

Correspondence
regarding
information about
Excise smugglers.

..

C

..

C

C

..

8L

Establishment of
Excise Intelligence
Bureau and Finger
Print Bureau :

important
papers to be
kept as A and
the rest as:-

C

..

..

..

..

40

<!-- page 41 -->

Correspondence re:-

8M

Finger Print Index
Register of Convicts.

…

A

..

..

A

..

8N

Finger Print Slips
and R.C. Reports of
Excise convicts.

A

..

..

..

..

8O

Court conviction
slips from
Magistrates or
Judges.

To be destroyed
after two years
of the date of
the death
reports or the
ex-convince
attaining age of
70 years

8P

Register of Finger
Print Slips received
for report.

..

C

..

…

…

…

8Q

Register of R.C.
Reports received for
record.

…

C

..

..

..

..

8R

Traced Case Register

…

C

..

…

…

…

8S

list of eliminated F.
P. Slips

…

C

..

..

…

..

8T

Register of Finger
Print Slips received
for trace.

..

..

…

…

..

….

8U

Monthly statement
of Finger Print Slips
received for trace.

..

C

..

..

..

..

…..

C

..

..

..

..

..

D

..

..

..

..

Correspondence re:
i) Finger Print Slips
and R.C. Reports
received for records.
8V
ii)F.Print Slips
receive for trace.
iii) Expert opinion or
evidence.
8W

Notifications
regarding closing of

41

<!-- page 42 -->

Courts on holidays

9

Death Reports of
convicts or exconvicts.

..

C

..

..

..

..

10

Monthly reports to
the commissioner
on the work done in
the Finger Print
Branch.

Orders or
remarks likely to
be of future use
to be kept as A,
the rest as-

D

..

..

..

..

C

C

C

..

C

C

C

..

Hours of Sale.

11

Correspondence re:
hours of sales.

Government
Resolutions and
orders to be
filled separately.

C

League of Nations

11A

Correspondence re:
question in respect
of opium and other
drugs dealt with by-

Government
orders and
correspondence
to be of any
future use to be
kept as A, the
rest as-

C

Nokarnamas

12

Correspondence re:
grant, cancellation,
etc., of - including
cancelled
Nokanamas.

Important
correspondence
to be kept B.

D

D

D

D

D

13

Nokarnama Register

..

..

..

D

D

..

13A

Nokarnama Fees
and Receipt Books.

..

…

..

D

D

..

C

C

C

..

Offences.

14

Case reports of under the Abkari
and opium acts and
the correspondence
relating thereto.

..

C

42

<!-- page 43 -->

15

Correspondence re:
compounded under
section 55-A of the
Bombay Abkari Act.

..

C

C

C

C

..

16

Monthly statements
furnished by the
Presidency
Magistrates in
Bombay showing
cases disposed of
and the excisable
articles seized
therein.

..

D

D

D

D

..

17

Confidential file of
suspected person.

..

..

..

B

B

..

18

Correspondence re:
blacklisting of
licenses and other
persons.

When the
disqualification
is temporary the
papers are to be
kept as C after
the period of
disqualification.

B

B

B

B

B

19

Black list Register

Until renewed

..

B

B

B

..

20

Prosecutions in
Abkari cases,
charge-sheets,
Magistrate's
findings, etc.

Magistrate's
findings are to
be kept as B in
Revenue Offices.

C

C

C

C

C

21

Crime Register

..

..

..

B

B

..

22

Register showing
cases compounded
under section 55-A
of the Abkari Act.

..

..

..

C

..

..

23

Law suits and
important papers in
connection
therewith.

..

B

B

B

B

..

C

C

C

..

Records.
24

Monthly statement

..

C
43

<!-- page 44 -->

and correspondence
re: grant of
Refunds and Recoveries

25

Correspondence
refund and
drawback of excise
duty.

..

C

C

C

C

…

26

Compensation,
remission and
refund bills in
respect of license
fees, etc., and
correspondence
relating thereto.

..

C

C

C

C

C

27

Correspondence re:
recoveries of
Government dues,
sales of property of
licenses, writing of
arrears,etc.

…

C

C

C

C

..

C

C

C

..

C

C

C

C

Temperance Movements.
28

Correspondence re:

…

C
Weights and Measures

29

Correspondence re:
purchase and
supply, sealing and
standardization of
Abkari measures,
instruments and
weights.

..

C

Country Liquor.

30

Important
correspondence re:
import, export,
transport, sale,
possession and still
head duty of-

Government
Resolutions and
orders are to be
filed under their
proper heads.

B

B

B

B

..

31

Routine
correspondence re:

..

D

D

D

D

..

44

<!-- page 45 -->

32

Correspondence re:
increase or decrease
in consumption of-

..

C

C

C

C

..

33

Applications for
removing -under
section 12.

..

D

D

D

D

…

34

Improvements in
the strength of-

..

B

B

B

B

..

35

Correspondence re:
recovery of
differential duty
when the rates are
increased

…

D

D

D

D

..

36

Import, export and
transport permits
and counterfoils
there of Including
special permits.

Counterfoils to
be kept as C

D

D

D

D

D

37

Correspondence re:
levy and increase or
decrease in the
rates of still head
duty.

Government
Resolutions and
orders are to be
filed under their
proper heads.

C

C

C

C

..

Country Liquor Shops.

38

Correspondence re:
disposal opening
and closing of-

important
correspondence
to be kept as B,
the rest as -

C

C

C

C

..

39

Statements showing
disposal of -

..

C

C

C

C

..

40

Correspondence re:
minimum stock in
shops, storage vats,
gauge, rods, etc., at
-

..

C

C

C

C

..

40 A

Country liquor shopDead Stock list.

..

..

..

.

C

..

45

<!-- page 46 -->

41

Petitions and
appeals and
Correspondence
there on, in respect
of grant of licenses
location and closure
of shops, rations,
refunds and
reduction in license
and Vend fees.

Important
correspondence
to be kept as B,
the rest as -

C

C

C

C

..

Excise

42

Correspondence re:
maintenance
preservation,
standardization,
supply, etc., of
testing instruments,
Hydrometers and
Thermometers.

..

C

C

C

C

..

43

Register of
standardization of
tastings instruments
of licensees.

..

..

..

C

C

…

44

Register of shop war
sales

..

..

C

C

C

…

45

Register of country
liquor licenses.

..

..

C

C

C

..

46

Register of
privileged shops

..

..

A

A

A

..

47

Register of
classification of
liquor fees, etc.

..

..

..

C

C

..

48

Register of country
liquor installments.

..

..

..

C

C

..

..

..

D

D

D

..

49

Counterpart
agreements and
expired licenses.

46

<!-- page 47 -->

Foreign Liquor.

50

Correspondence re:
import, transport,
sale, possession,
manufacture,
bottling, blending,
coloring, size of
bottles, etc., of

Important
correspondence
should be kept
as A, the rest as Government
Resolutions and
circular orders to
be filed under
their proper
heads.

C

C

C

C

..

51

Correspondence re:
increase or decrease
in the consumption
of-

..

C

C

C

C

..

52

Correspondence re:
the method of
disposal, closing and
opening of shops
and statements
showing shops
disposed of - and
other routine
correspondence re
thereto.

Important
correspondence
should be kept
as A, the rest asGovernment
Resolutions and
circular orders to
be filed under
their proper
heads.

C

C

C

C

..

53

Application for the
grant cancellation,
etc., of whole sale,
off, on, Hotel, and
other license.

..

C

C

C

C

..

53A

Import, export and
transport, permits
and counterfoils
there of.

Counterfoils as
C.

D

D

D

D

..

Correspondence re:
the rates of duty on-

Government
Resolutions and
orders to be
filed under their
proper heads.

D

D

D

D

..

54

47

<!-- page 48 -->

55

Petitions and
appeals and
correspondence
there on in
connection with
shops, etc.

..

C

C

C

C

..

56

Register of duty
received on Indian made spirit
imported.

....

..

..

B

B

..

57

Register of Foreign
liquor license.

..

..

C

C

C

..

58

Register of current
Deposit Accounts of
several impoters of
Indian made Foreign
liquor.

..

..

C

C

C

..

59

Counterpart
agreements and
expired licenses.

..

..

D

D

D

..

59A

Registers prescribed
for Foreign Liquor
Warehouses of
import and export.

..

..

C

C

C

..

60

Register prescribed
for bottling and
compounding
operations.

..

…

..

C

C

C

C

C

..

Medicinal and Toilet Preparations
(Perfumed spirits)-

61

Correspondence re:
manufacture duty,
possession, sale
import and
transport of-

Important
correspondence
to be kept as A,
the rest as Government
Resolutions and
circulars to be
filed under their
proper heads.

C

48

C

<!-- page 49 -->

Correspondence re:
analysis of -

..

C

C

..

..

..

62

Permits for
transport, import,
export, etc. of-

…

D

D

D

D

..

63

Monthly statements
of issue and use of
plain spirits at the
laboratory for the
manufacture of-

..

C

..

C

..

..

64

Registers prescribed
for laboratories.

..

..

..

…

…

..

C

C

C

..

..

Counterfoils C

D

D

D

D

D

..

D

D

D

..

D

..

..

..

C

C

C

Methylated Spirits.

65

65A

66

67

Correspondence re:
import, transport,
sale, possession,
manufacture,
bottiling,etc.

Import, export and
transport permits of
methylated and
denatured spirits
any counterfoils
there of.

Applications for
denatured spirits

Register prescribed
for methylated
spirits.

Important
correspondence
to be kept as A,
the rest as Government
Resolutions and
circulars to be
filed under their
proper heads.

49

<!-- page 50 -->

Hemp or Intoxicating Drugs.
(Ganja, Bhang, Charas, Cocaine and other allied drugs)

68

Important
correspondence re:
cultivation,
manufacture,
storage, import,
export, transport
sale, possession
duty, etc.

Government
Resolutions and
Circular orders
are to be filed
under their
proper heads.

C

C

C

C

..

69

Routine
correspondence re

..

D

D

D

D

..

70

Correspondence re:
increase or decrease
in the consumption
of -

..

C

C

C

C

..

71

Application for
cultivation,
manufacture and
removal of-

..

D

D

D

D

..

72

Import, export and
special transport
permits and
counterfoils there of
and applications
relating thereto.

Counterfoils to
be kept as C.

D

D

D

D

D

73

Register of Ganja
installments.

…

..

..

C

C

..

..

..

..

..

C

C

..

..

..

..

C

74

75

Registers prescribed
under the Hemp
Drugs warehouse
rules.

Monthly statements
of issues, receipts
and balances

Important
orders to be
treated as B, the
rest as-

50

<!-- page 51 -->

Hemp Drugs Shops and Licenses

76

Correspondence re:
disposal, opening,
closure and
location- of-

Important
orders to be
treated as B, the
rest as-

C

C

C

C

..

77

Statements showing
the shops disposed
of and routine
correspondence on
the same.

..

C

C

C

C

..

78

Application for
permits and shop
licenses.

..

D

D

D

D

..

79

Correspondence re:
location,
cancellation of
shops, refunds,
reduction in fees,
etc.

Important
orders to be
treated as B, the
rest as-

C

C

C

C

..

80

Petitions and
appeals from
licenses and
correspondence
thereon.

…

C

C

C

C

..

81

Register showing
cocaine fit for use
and reported to
Government.

…

..

..

C

C

..

82

Register showing
cocaine kept in
deposit by Medical
Practioners and
chemists.

..

..

…

C

C

..

83

Counterpart
agreements and
expired licenses.

..

…

…

D

D

..

83A

Drugs permits
surrendered by
addicts.

…

..

..

D

D

..

51

<!-- page 52 -->

(Opium including Morphia)

84

Correspondence
relating to the
amendment of the
Act, the
interpretation
thereunder and the
grant of powers
under the

Government
Resolutions and
B orders are to
be filed under
their proper
heads.

B

B

B

B

..

85

Correspondence re
supply, sale,
possession, import,
export, transport,
duty and issue rate
of-

Government
Resolution and
order are to be
filled under their
proper heads.

C

C

C

C

..

86

Routine
correspondence

….

D

D

D

D

..

87

Indents for-and
correspondence re
thereto-

…

C

C

C

C

..

87A

Opium Ledger
Accounts including
Stock registers of
opium kept by
treasury and Sub
treasury Officers.

…

..

..

..

B

..

88

Correspondence re
opium smoking and
chandulkhanas.

Government
Resolution and
order are to be
filled under their
proper heads.

C

C

C

C

..

89

Correspondence re
increase or decrease
in consumption of
opium.

…

C

C

C

C

..

90

Monthly statements
re the sale of Opium
and Balagoli

When no longer
required….

D

D

D

D

..

52

<!-- page 53 -->

91

Import, export and
transport permits
and counterfoils
thereof and
applications in
respect there of.

Counterfoils to
be kept as C.

D

D

D

D

..

92

Application for the
grant of license.

..

D

D

D

D

..

C

C

C

..

Opium Shops :

93

Correspondence re:
disposal, closure
and Opening of -

Government
Resolutions and
B orders are to
be filed under
their proper
heads.

C

Opium Shops – council

94

Statements showing
the shops disposed
of -

…

C

C

C

C

..

95

Petitions and
appeals and
correspondence re:
location and
cancellation of
shops, refund and
reduction in license
fees.

Important
orders to be
kept as B, the
rest as-

C

C

C

C

.

96

Counterpart
agreements and
expired license.

…

..

..

D

D

..

96A

Permits surrendered
by opium addicts

..

..

..

D

D

..

D

D

D

..

Morphia.

97

Correspondence re:
sale, possession,
import, export and
transport of -

Papers likely to
be of any future
use to be kept as
C and the rest as
-

D

53

<!-- page 54 -->

98

Register of Opium
and Cocaine license
granted to Doctors
and Chemists.

..

..

C

C

C

..

99

Register of Opium
installments
received from the
opium shopkeepers.

..

..

..

C

C

..

Toddy .

100

Correspondence re:
sale, purchase,
import, export,
transport and
possession of toddy.

Important
orders to be
kept as A, the
rest as-

D

D

D

D

…

101

Correspondence re:
the method of
disposal of toddy
shops, tree-foot
booths, etc.

Do. do.

C

C

C

C

..

102

Correspondence re:
grant, cancellation,
management,
supervision, etc., of
toddy shops, treefoot booths
domestic
consumption
hawking and
tapping licenses.

…

C

C

C

C

..

103

Correspondence re:
numbering and
marking of trees.

….

C

C

C

C

..

104

Bhandari Returns
and correspondence
relating thereto.

…

C

C

C

C

..

105

Correspondence re:
the levy and
increase or decrease
in the rate of treetax on tree tapped.

Important
orders to be
kept as A, the
rest as -

D

D

D

D

..

54

<!-- page 55 -->

106

Correspondence re:
the disposal of the
right of tapping of
trees standing on
Government and
Maki lands and in
the compound of
Government
buildings.

Important
orders to be,
kept as A, the
rest as.

C

C

C

C

..

107

Correspondence
regarding gul
manufacture
including grant of
licenses.

Do.

C

C

C

C

…

107A

Import, export and
transport permits
and counterfoils
there of.

Special
counterfoils to
be kept as C.

D

D

D

D

..

108

Register of tree-tax
and trees tapped.

…

..

..

C

C

…

109

Register of shopwar
sales at toddy
shops.

..

..

..

C

C

..

110

Register of toddy
shop license.

..

..

C

C

C

..

111

Register of tree-foot
booths, hawking
domestic
consumption and
other miscellaneous
licenses.

…

..

C

C

C

..

Tobacco.

112

113

Application for
country and Foreign
Tobacco Licenses
refused.

Deleted

C

C

C

C

..

Application for
Country and Foreign
Tobacco Licenses
refused.

Deleted

C

C

C

C

..

55

<!-- page 56 -->

Application for
removal of Tobacco
shops granted or
refused.

Deleted

C

C

C

C

..

Correspondence re:
cancelled and
lapsed licenses.

Deleted

C

C

C

C

..

Correspondence re:
sub-letting of
licenses.

Deleted

C

C

C

C

..

Correspondence on
the subject of issue
of Tobacco licenses.

Deleted

C

C

C

C

..

Correspondence re:
concessions granted
to transfer Bidis,
Jarda, Gudakhu and
snuff from one to
another shops.

Deleted

..

C

C

C

..

Correspondence re:
temporary closing
and opening of
shops.

Deleted

D

D

D

D

..

Correspondence re:
grant of transport
permit book.

Deleted

C

C

C

C

..

121

Annual statements

Deleted

C

C

C

C

..

122

Application for
duplicate copies of
Licenses.

Deleted

D

D

D

D

..

114

115

116

117

118

119

120

Tobacco Warehouse

123

124

Corresondence re:
granting of warehouse.

Deleted

A

A

A

A

..

Correspondence re:
granting of Hoist.

Deleted

B

B

B

B

..

56

<!-- page 57 -->

Applications for
Warehouses
refused.

Deleted

D

D

D

D

..

126

Tobacco Cash
Account Book..

Deleted

..

..

..

B

..

127

Register of Tobacco
weighed at the
scale.

Deleted

..

..

..

B

..

Country and Foreign
Tobacco Import
Registers.

Deleted

..

..

..

B

..

Country and Foreign
tobacco Export
Registers.

Deleted

…

..

..

B

..

Country and Foreign
Tobacco License
Registers.

Deleted

…

..

..

B

..

131

Warehouse Rent
Book

Deleted

..

..

..

B

..

132

Country and Foreign
Tobacco License Fee
Books.

Deleted

..

..

..

C

..

133

Miscellaneous Fee
Book

Deleted

..

..

..

C

..

134

Extra Work Fee
Register

Deleted

..

..

..

C

..

135

Monthly statement
to tobacco cash
accounts.

Deleted

..

..

..

C

..

Monthly statement
of tobacco exported
and passed into
town.

Deleted

..

..

..

C

..

137

Tobacco Transport
Permit Book.

Deleted

..

..

..

D

..

138

Import Order Book

Deleted

..

..

..

D

..

125

128

129

130

136

57

<!-- page 58 -->

139

Special Duty Receipt
Book...

Deleted

…

..

…

D

..

140

Country and Foreign
Tobacco…

Deleted

..

..

..

D

..

141

Miscellaneous
Receipt Books..

Deleted

…

..

..

D

..

142

Duty Bills

Deleted

..

..

..

D

..

143

Transfer of tobacco
from one
warehouse to
another.

Deleted

D

D

D

D

..

Export shipping bills
(Country and
Foreign tobacco.)

Deleted

..

..

..

D

..

145

Delivery orders …

Deleted

..

…

..

D

..

146

Country tobacco
shop returns…

Deleted

C

C

C

D

..

147

Import entries
(Country and
Foreign Tobacco).

Deleted

..

..

..

D

..

Application for
Transport Permits
and Import orders.

Deleted

..

..

…

D

..

Application for extra
hours fees and
statements.

Deleted

..

..

…

D

..

Memos. Of Country
and Foreign
Tobacco Licenses
granted and
removal of the
same.

Deleted

..

..

…

D

..

Application for
Transport Permit
Books.

Deleted

..

..

…

D

..

144

148

149

150

151

58

<!-- page 59 -->

152

153

Memos. Of
cancellation of
licenses.

Deleted

..

..

…

D

..

Application for the
renewal of country
and foreign tobacco
licenses.

Deleted

..

..

…

D

..

Distilleries and Warehouses.
Correspondence re:
Permits (under
Bond).

Important
orders to be
treated as B.

..

..

D

..

D

155

Correspondence re:
Declarations

Do.

..

..

D

..

D

156

Correspondence re:
Material stock
Receipts.

Do.

..

..

D

..

D

Correspondence re:
Notics

Important
orders to be
treated as B.

..

..

D

..

..

158

Correspondence re:
quota

Do..

..

..

D

..

D

159

Liquor contracts and
correspondence
relating to supply
and transport of
liquor, etc.

After the
expiration of the
contract

C

..

C

C

C

Correspondence re:
Co-opering articles.

Important
orders to be
treated as B.

..

..

D

..

D

Weekly and monthly
stock account
reports.

..

..

..

D

..

D

Analysis reports and
correspondence re:
thereto

Important
orders to be
treated as B

..

..

C

..

C

Bills for payments
and correspondence

..

..

..

C

..

C

154

157

160

161

162

163

59

<!-- page 60 -->

re: recoveries of
dues.
Correspondence re:
Bonded
Warehouses.

Important
orders to be
treated as B.

..

..

C

..

C

165

Correspondence re:
gas and coal.

..

…

..

C

..

C

166

Cost account and
monthly report
thereon.

..

..

..

C

..

..

Correspondence
relating to Diffusion
Battery.

..

..

..

C

..

..

168

Correspondence re:
Distillery effluent.

..

..

..

C

..

..

169

Correspondence
relating to Security
Press.

..

..

..

C

..

..

Correspondence
relating to Java
Molasses.

..

..

..

C

..

..

Correspondence
relating to schooling
of children of
Distillery workmen.

..

..

..

C

..

..

172

Correspondence
relating to spirit.

..

..

..

C

..

C

173

Correspondence
relating to Mowhra
Flowers.

Standing orders
to be treated as
A.

C

C

C

C

..

Commercial Journal
Vouchers

..

..

..

C

..

..

D

..

D

164

167

170

171

174

Distilleries and Warehouses- concld.

175

Correspondence re:
additions
alternations and
valuation of plant.

Important
orders to be
treated as A.

..

..
60

<!-- page 61 -->

Important
correspondence
resulting in
punishment of
officers should
be kept as B.

C

..

C

C

D

Miscellaneous
periodicals and
returns connected
with the
Departmental
management of
Distilleries and
Ware-houses.

..

C

..

D

..

D

178

Correspondence re:
estate and land.

..

A

..

A

..

A

179

Miscellaneous
correspondence

Important
orders to be
treated as B.

D

..

D

..

D

180

Correspondence re:
quarters

….

…

..

C

..

C

181

Correspondence re:
material demand
notes.

Important
orders to be
treated as B.

C

..

C

..

..

Correspondence re:
pay tickets of daily
laborers.

To be destroyed
as soon as the
accounts are
audited.

D

..

D

..

..

Railway receipts
(Inward and
Outward books).

..

..

..

D

..

D

184

Birth and Death
Registers

..

..

..

C

..

..

185

Postal
acknowledgments
of money-orders,
registers and
parcels.

To be destroyed
as soon as the
accounts are
audited.

..

..

D

..

D

176

177

182

183

Excess and loss
statement and
correspondence
relating thereto.

61

<!-- page 62 -->

Entertainment,
promotions and
discharge forms of
daily laborers.

Do

..

..

C

..

..

187

Gate passes

..

..

..

D

..

..

188

Overtime slips

..

..

..

D

..

..

Sheets of daily
attendance of
laborers.

To be destroyed
as soon as the
accounts are
audited.

..

..

D

..

D

186

189

Registers.
190

Sales Day Book

..

..

..

B

..

..

191

Purchase Leger

..

..

..

B

..

..

192

Sales Ledger

..

..

..

B

..

..

193

Purchase Day
Book...

..

..

..

B

..

..

194

General Ledger

..

..

..

B

..

..

195

Journal

..

..

..

B

..

..

196

Register of capital
expenditure

..

…

..

B

..

..

197

Consignment Day
Book

..

..

..

C

…

..

198

Stores Ledger ...

..

..

..

C

…

..

199

"A" Material Stock
Account

..

..

..

C

…

..

200

"B" survey Book

..

..

..

C

…

..

201

"C" Fermentation
and Distillation
Register.

..

..

..

C

…

..

202

"D" Vat Register

..

..

..

C

…

C

203

"E" Spirit Stock

..

..

..

C

…

C

62

<!-- page 63 -->

Account
204

"F" Register of
Issues in Bond.

..

..

..

C

…

C

205

"G" Register of
spirits issued to
shops. .

..

..

..

C

…

C

"H" Register of
Dimensions and
capacities of wash
backs, Receivers and
vats.

..

..

..

C

…

C

207

"I" Register of
capacities of casks.

..

..

..

D

…

D

208

"J" Register of Duty
Area Accounts.

..

..

..

C

..

C

209

"K" General
Register..

..

..

..

A

..

A

210

"L" Inspection
Register (Visit Book).

..

..

..

..

..

C

211

"M" Register of
Spirit Weighment.

..

..

..

C

..

C

212

"N" Register of
receipts under
Bonds.

..

..

..

..

..

C

Cash Book (showing
transactions of
departmental
management of
warehouses).

..

..

..

..

..

A

214

Registering of coopering charges.

..

..

..

C

..

C

215

Pahara Book

..

..

..

..

…

D

216

Coopering charges
Receipt Book.

..

..

..

D

..

D

217

Label Book

..

…

..

D

..

D

206

213

63

<!-- page 64 -->

218

Plant List..

Until renewed

..

..

A

..

A

219

Lock-up chit book

..

D

D

D

D

..

220

First Information
book

..

..

..

C

C

..

221

Monthly quarterly
and six monthly
accounts of country
liquor, toddy,
opium, ganja,
bhang, foreign
liquor, cocaine, etc.

..

C

C

C

C

C

Annual statements
in respect of country
liquor, toddy,
opium, ganja,
bhang, foreign
liquor, cocaine, etc.,
required in
connection with
Administration
Reports.

..

C

B

B

B

B

Security bond and
Solvency certificates
taken from Excise
licenses and expired
licenses with
counterpart
agreements except
short term licenses
which should be
classed as "D".

To be treated as
"C" after the
termination of
the license
period.

C

C

B

B

..

224

Security bond
register ..

..

C

C

C

C

..

225

Register of Excise
Permits including
special permits.

..

C

C

C

C

..

226

Shopkeeper's
monthly accounts

..

..

..

D

D

..

227

Survey Register ...

..

..

..

..

A

..

222

223

64

<!-- page 65 -->

228

Register of warnings
to Excise licensees.

Keep till
renewed

..

..

C

..

..

229

All progress reports
and Wasulbaki
Statements filled in
the Revenue Offices.

..

..

..

..

D

..

230

Confidential NoteBook

..

..

..

..

A

..

231

Correspondence
regarding ration
fixed for each shop,
including ration
registers and
statements.

..

C

C

C

C

..

MISCELLLANEOUS (MIS).
Arms and Ammunitions.
Applications for
license to possess
arms and
correspondence re:
thereto.

…

D

..

D

D

D

2

Supply of arms

…

B

..

B

C

C

3

Correspondence re:
repairs to arms.

…

D

..

D

D

D

4

Indents for
ammunition and
correspondence re:
thereto.

..

D

..

D

D

D

B

..

B

B

B

1

Register of arms and
ammunitions.

5

Keep till
renewed. This
need not be
renewed every
year. Additions
and omissions
can be made in a
permanent
Register.

65

<!-- page 66 -->

Boats.

Purchasse of boats
and toneys

Tonies and boats
given to
Inspectors are
entered in their
lists of deadstocks.

C

..

C

C

C

Correapondence re:
repairs to bots and
toneys.

…

C

..

C

C

C

8

Purchase of stores
for boats..

..

D

..

D

D

D

9

Damage to boats

..

D

..

D

D

D

6

7

Census.

10

11

Appointments of
census officers,
supply of
information and
ordinary
correspondence
with census officers.

Keep till new
census is made.
(10 years).

..

..

..

..

..

Figures of
population
communicated by
authorities.

..

B

..

B

B

B

Council Elections.

12

Correspondence
relating to the
legislative council
elections.

…

C

..

C

C

C

Medicines.

13

Correspondence re:
supply and renewal
of medicine chest,
etc., and indents for
quinine, etc.

..

C

..

66

C

C

C

<!-- page 67 -->

14

Correspondence re:
medical aid to
Establishment.

..

D

..

D

D

D

Stores

15

Annual statements
of expenditure on
European stores and
indents for stores
required from
England.

..

C

..

C

..

..

16

Correspondence re:
purchase and supply
of stores to officers
on requisitions.

..

D

..

D

D

D

17

Invoice packing
accounts and
returns relating to
stores sent by the
Accountant General
for Commissioner's
information.

..

D

..

D

..

..

Water Supply.

18

Schemes for the
supply of water
including laying of
pipe lines, etc.

Correspondence
of a permanent
nature to be kept
as A.

C

..

C

D

D

19

General
correspondence
regarding water
supply to the
Establishement.

Water supply bills
to be treated as
C.

D

..

D

D

D

20

Correspondence
regarding inspection
of poison Shops.

Except standing
orders which
should be
treated.

D

D

D

D

..

67

<!-- page 68 -->

TREASURY (TRY).
Budget

1

Budget estimates of
receipts and
expenditure and
correspondence
relating thereto.

..

C

..

C

C

..

2

Report re: unusual
item of
expenditures.

..

C

..

C

..

..

3

Explanation
furnished to the
Accountant General
or Government re:
budgetted
estimated figures of
receipt and
expenditure.

..

C

..

C

..

..

4

Re-appropriation
correspondence,
surrender of grants
as also reports for
additional grants
and orders thereon.

..

C

C

C

..

..

5

Transfer of grants
from one office to
another.

..

D

D

D

..

..

6

Memos, or
statements
communicating
grants to sub-offices.

..

C

..

C

C

C

7

Printed Budget

..

C

..

..

…

..

..

..

..

Payments and Recoveries.

8

Authorities for
payments including
powers for attorney,
life certificate, etc,

To go in original
with Voucher.

..

..

68

<!-- page 69 -->

9

Applications and
intimations re:
letters of credits.

..

D

..

D

..

D

10

Issue of cheque
books

..

C

..

C

..

C

11

Correspondence re:
Bhatta to prisoners
and feeding of
cattle.

..

…

…

D

D

…

..

D

D

D

Coins.

12

Correspondence in
connection with
defaced and
counterfeit coins
and currency notes.

…

D

General Accounts and Audits
13

Register of
payments

..

..

..

C

C

C

14

Cash Book including
Abkari and opium
"Kirds" kept by
Mamlatdars and
Mahalkaries.

..

..

..

B

B

B

15

Objection
statements from the
Accountant General
and Chief Account
Officer and replies
thereto.

..

C

..

C

C

C

16

Register of withheld
salaries

..

..

..

C

..

..

17

Register of
contingent charges

This is maintained
to watch the state
of grants.

..

..

C

..

..

69

<!-- page 70 -->

18

Register of
Permanent Advance.

..

C

C

C

C

C

19

Chalans and cash
recoveries under
Excise remittances.

..

C

C

C

C

C

20

Specimen signatures
Treasury officers.

..

D

..

D

..

..

21

General Receipt
Book

..

..

..

..

C

C

22

Office copies of
detailed or abstract
contingent bills.

..

C

..

C

C

C

23

Vouchers (if not sent
with the bill).

Must be marked
"cancelled".

C

..

C

C

C

24

Office copies and
fair copies of
memos. Or bills
submitted to
superior office for
consolidation.

..

..

..

..

D

D

25

Memos, sending bills
for
countersignature.

..

D

..

D

D

D

26

Annual
acknowledgment of
Permanent Advance
Register.

..

C

..

C

..

..

27

Correspondence re:
delay in payment of
bills.

If it results in
punishment

B

..

B

B

B

28

Memos, of bids,
deposits and refunds
thereof.

or warning
otherwise.

D

..

D

D

D

70

<!-- page 71 -->

29

Letters forwarding
bills for Accountant
General's or
Commissioner's
sanction.

..

Z

..

Z

Z

Z

28

Memos, of bids,
deposits and refunds
thereof.

..

D

..

D

D

D

30

Intimation re:
closing of account
months.

..

..

..

D

..

..

31

Order Book showing
all appointments,
transfers, etc.

..

..

..

D

..

..

28

Memos, of bids,
deposits and refunds
thereof.

To be destroyed
after 40 years.

A

..

A

A

A

General Accounts and Audits
32

Correspondence re:
Treasury holidays.

..

D

..

D

D

D

33

Intimations
regarding cash
orders.

After the cash
book is checked
by Inspecting
officers.

..

..

D

D

D

34

Register of Deposits

Keep till renewed
and afterwards.

C

C

C

C

..

..

Miscellaneous General. (Mis. Gen.)
Miscellaneous
Correspondence not
mentioned in the
above headings.

To be treated as
A,B, C or D
according to their
degree of
importance.

..

..

71

..

<!-- page 72 -->

७.

हिभागाचे धोरि तयार करण्याच्या ककिा त्याची अमुं लबजाििी करण्याच्या सुंबुंधात, लोकाुंशी

हिचारहिहनमय करण्यासाठी ककिा लोकाुंकडु न हनिेदने केली जाण्यासाठी अक्स्तत्िात असलेल्या कोित्यही व्यिस्थे चा
तपहशल :
एखाद्या ग्रामपंचायत / नगरपनरषद / महानगरपानलका वाडामधील नागनरकांना मद्यनवक्री अनुज्ञप्ती बंद करावी असे वाटत
असेल ते ननवेदन दे वून मतदानाअंती बहु मताने अथवा साध्या बहु मताने ठराव पानरत करून सदर नठकाणी दारुबंदी करू िकतात.
राज्याच्या दारूबंदी धोरणाची अंबलबजावणी करण्याच्या उद्दे िाने अवैध मद्य ननर्म ती व नवक्री बाबत नागनरकांच्या तक्रारींचे
ननराकरण करण्यासाठी आयुक्त, राज्य उत्पादन िुल्क यांच्या कायालयामध्ये 'ननयंत्रण कक्ष' स्थापन करण्यात आले ला आहे .
नागनरकांना सदर ननयंत्रण कक्षािी संपकक साधून तक्रार नोंदनवण्यासाठी खालील व्यवस्था ननमाण करण्यात आले ली आहे .





टोल फ्री दुरध्वनी क्रमांक : 1800833333
WHATSAPP NO. : 8422001133
-20822488
मोबाईल अॅप: गुगल प्ले स्टोअर वरील Exc-Complaints हे अॅप

८.
हिभागाचा एक भाग म्हिून ककिा सल्ला दे ण्याच्या प्रयोजनासाठी म्हिून घहित केलेल्या दोन ककिा अहधक
व्यक्क्तच्या हमळु न बनलेल्या मुं डळाचे , पहरषदाुंचे, सहमत्याुंचे आहि अन्य हनकायाुंचे हििरि, त्या मुं डळाुंच्या,
पहरषदाुंच्या सहमत्याुंच्या आहि अन्य हनयकाुंच्या बै ठकी लोकाुंसाठी खुल्या आहे त ककिा कसे ककिा अशा बै ठहकची
कायत ि ृत्ते जनतेला पाहाियास हमळण्याजोगी आहे त ककिा कसे या बाबतचे हििरि :

वरील बाब या नवभागािी संबंधीत नसल्याने सदर बाबतची मानहती हनरुं क आहे .

९.

हिभागातील अहधकाऱयाुंची हनदे हशका :

1
2
3
4
5
6
7

आयुक्त
अपर आयुक्त
-आयुक्त (मळी व मद्याकक)
सह-आयुक्त(प्रिासन)
सह-आयुक्त (अंमलबजावणी व दक्षता)
मुख्य ले खाअधीकारी (ले खा व कोषागरे )
उप-आयुक्त (औषधे व सौंदयक प्रसाधने)

8
9
10
11

उप-आयुक्त (नननरक्षण )
उप-आयुक्त (मळी व मद्याकक)
उप-आयुक्त (प्रिासन)
(

(

)
72

)

<!-- page 73 -->

12

सहायक आयुक्त (आस्थापना)

13
14

सहायक आयुक्त (दे िी /नवदे िी मद्य)

15

सहायक आयुक्त (मळी व मद्याकक)

16

ले खानधकारी

(

सहायक आयुक्त(औषधे व सौंदयक प्रसाधने)

)

)
(

1
2
3
4
5
6
7
8

श्री.
-

.

9
10
11
12

श्री

.

13
14
15
16

(

)

(

)

17
18

श्री.रकवद्र आवळे

19
20
21
22
23
24
25

श्री.

73

<!-- page 74 -->

26
27
28
29
30
31
32

(
)

33
34
35
36

10.
हिभागातील अहधकाऱयाुंना ि कमत चाऱयाुंना हमळिारे माहसक िेतन तसेच प्राहधकरिाच्या हिहनयमामध्ये तरतूद
केल्या प्रमािे अहधकाऱयाुंना ि कमत चाऱयाुंना नुकसान भरपाई दे ण्याची पध्दती :
नवभागातील अनधकाऱयांना व कमकचाऱयांना नमळणारे मानसक वेतन याबाबतची मानहती नवभागाच्या संकेतस्थळावर अपलोड
करण्यात आले ली आहे . या नवभागामध्ये अनधकाऱयांना व कमकचाऱयांना नुकसान भरपाई दे ण्यासंबंधी नवननयम करण्यात आले ले
नाहीत.

11.
हिभागाच्या सित योजनाुंचा तपहशल, प्रस्ताहित खचत दशत हििारा, आपल्या प्रत्ये क अहभकरिाला नेम ून
हदलेला अथत सुंकल्प आहि सुंहितहरत केलेल्या रकमाुंचा अहिाल :

--2024

(

)(

)

(3+4+5)
1

2

3

4

5
74

6

(6-8)
7

8

<!-- page 75 -->

(01)
1

140040000

0

0

140040000

123894305

16145695

116000

0

27000

143000

143000

0

1000

0

0

1000

0

1000

2000000

0

0

2000000

1972685

27315

-

1000000

2000000

3000000

1185300

1814700

6 11-

500000

0

150000

350000

155832

194168

1000

0

0

1000

0

1000

2332000

0

0

2332000

1664665

667335

1000

0

0

1000

0

1000

2

-

3
4
5

7
8

-

-

9
10

-

1000

0

0

1000

0

1000

11

-

22822000

0

0

22822000

12020712

10801288

1000

0

0

1000

0

1000

1000

22500000

0

22501000

19906000

2595000

1000

0

0

1000

0

1000

500000

0

400000

100000

0

100000

1245000

0

1550000

2795000

2779466

15534

1000

0

0

1000

0

1000

1000

1725000

0

1726000

1418916

307084

10000000

0

1200000

8800000

0

8800000

1000000

0

564000

436000

236000

200000

200000

0

737000

937000

840908

96092

2000000

0

50000000

52000000

50723822

1276178

12
13
14
15
16
17
18
19
20
21
22

–
-

75

<!-- page 76 -->

23
24

52 -

25

2000000

3600000

0

5600000

1564122

4035878

1000

0

0

1000

0

1000

1000

0

0

1000

0

1000

185766000

79825000

0

265591000

218505733

47085267

-(

-

-2024

)(

(3+4+5)

2024)
1

2

3

)

4

5
)

6
-

(6-8)
7

8

(01)

32
1
2

-

2240000000

0

0

2240000000

2021320429

218679571

772000

0

0

772000

272716

499284

908000

0

0

908000

721840

186160

8166000

0

0

8166000

7530465

635535

50000

1000000

0

1050000

0

1050000

5830000

0

2879000

2951000

1041914

1909086

1000

0

0

1000

0

1000

21459000

14300000

0

35759000

34873882

885118

14000000

7500000

3960000

25460000

25211413

248587

3

4
5
6
7

-

8

9

-

10

-

1000

0

0

1000

0

1000

11

-

1419000

0

498000

921000

565223

355777

76

<!-- page 77 -->

12

-

60000

0

0

60000

35600

24400

1000

0

0

1000

0

1000

1000

0

0

1000

0

1000

1000

0

0

1000

0

1000

9087000

2500000

0

11587000

11303621

283379

1000

0

0

1000

0

1000

400000

0

0

400000

77621

322379

1943000

0

583000

1360000

0

1360000

10000

0

0

10000

0

10000

2000000

0

0

2000000

1999173

827

100000

0

0

100000

58808533

-50708533

50000

0

0

50000

0

50000

24

50000

0

0

50000

0

50000

25

1000

0

0

1000

0

1000

2306311000

25300000

0

2331611000

2163762430

167848570

13

14
15
16

-

17
18
19

-

20

21
22
23

-

77

<!-- page 78 -->

3
-(

-

-2024

)(

)

2023-2024

31.03.2024
(3+4+5)

1

2

3

4

5

(6-7)

6

7

8

- 20390041
1

120000

0

0

120000

93106

26894

120000

0

0

120000

93106

26894

)(

)

(

--2024

-

(3 + 4 +
5)
1

2

3

4
)

1

5
(

6

31.03.2024

(6-7)

7

8

) – 20390112

1000

0

0

1000

0

1000

1000

0

0

1000

0

1000

78

<!-- page 79 -->

(

-2024

--

-

2

3

4

- 00 001

1

5

8

150000

0

0

150000

0

150000

150000

0

0

150000

0

150000

--

-2024

-

3

4

-

)(

(3 + 4 +
5)

2024

1

7

– 20390097

(

2

6

(6-7)

) (01)

(

1

)

(3 + 4
+ 5)

2024
1

)(

5

6

)

31.03.2024

7

(02) (01)

7)

8

(20390023)

1000

0

0

1000

0

1000

1000

0

0

1000

0

1000

79

<!-- page 80 -->

12.
अथत सहाय्य कायत क्रमाच्या अुंमलबजाििीची रीत तसेच िािप केलेल्या र
लाभा
तपहशल :

13.

ज्या व्य

मा आहि कायत क्रमाुंच्या

ना सिलती, परिाने ककिा प्राहधकारपत्रे हदलेली आहे त अशा व्य

चा तपहशल :

राज्यामध्ये सैन्यदलांच्या सेवेतील तसेच सेवाननवृत्त अनधकारी व कमकचाऱयांना इतर नागनरकांच्या तुलनेत
मद्यावर कमी उत्पादन िुल्क आकारून सवलतीच्या दरात केवळ त्यांच्यासाठीच प्रदान केलेल्या नकरकोळ मद्यनवक्री
अनुज्ञप्तींमधून मद्य नवक्री केली जाते. सदर अनुज्ञप्तींसाठी कोणतेही अनुज्ञप्ती िुल्क आकारले जात नाही. त्याचप्रमाणे
सेवाननवृत्त अनधकारी व कमकचाऱयांना नवनािुल्क मद्यसेवन परवाने नवतनरत करण्यात येतात.

14.

इले

हनक स्िरूपात हिभागाकडे उपलब्ध असलेल्या माहहतीच्या सुंबुंधातील तपहशल :

नवभागाकडे कोणतीही मानहती
ननरं क आहे .

उपलब्ध नसल्यामुळे सदर बाबतची मानहती

15.
माहहती हमळहिण्यासाठी नागहरकाुंना उपलब्ध असिाऱया सुहिधाुंचा तपहशल, तसेच साितजहनक
िापरासाठी चालहिण्यात ये त असलेल्या ग्रुंथालयाच्या ककिा िाचनालयाच्या कामकाजाच्या िेळाुंचा तपहशल :
नवभागाकडू न नागनरकांसाठी ग्रंथालय ककवा वाचनालय चालनवण्यात येत नाही. तथानप नवभागाच्या
http://stateexcise.maharashtra.gov.in या संकेतस्थळावर नवभागासंबं
कायदे , ननयम , आयुक्तांची पनरपत्रके,
महत्वाचे न्यायालयीन न्यायननवाडे आनण अनुज्ञप्ती प्राप्त करून घे ण्यासाठीची प्रनक्रया यासंबंधीची मानहती नागनरकांना
उपलब्ध करून दे ण्यात आले ली आहे .

16.

जन माहहती अहधकाऱयाुंची नािे, पदनामे आहि इतर तपशील :

अ आयुक्त, राज्य उत्पादन शुल्क याुंचे कायालयातील जन-माहहती अहधकारी ि प्रथम अहपलीय
अहधकारी:
80
