---
doc_id: "fa7fc8cfa2256bb7"
source_url: "https://mngl.in/storage/195644/Tendernotice_1---2026-10-23T095421.026.pdf"
ministry: "Maharashtra Natural Gas Ltd. (MNGL), Maharashtra"
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c66aaf7769368ffb"
---

<!-- page 1 -->

Notice Inviting Tender for Operation & Comprehensive
maintenance of M/s. KPCL make GED with Cummins
Engine (Model GTA855BC) CNG compressor for period
of two years installed at various CNG stations Pune GA
MAHARASHTRA NATURAL
GAS LIMITED

BID NO. MNGL/CP/2026-27/133

NOTICE INVITING TENDER (NIT)
M/s. Maharashtra Natural Gas Ltd., Pune invites online bids UNDER TWO BID SYSTEM from
eligible bidders for the item(s) in complete accordance with the Bid Documents.
Tender Document Number
ITEM(S)
TYPE OF BID
EARNEST
BIDSECURITY

MONEY/

MNGL/CP/2026-27/133 dated 22.10.2026
Tender for Operation & Comprehensive maintenance
of M/s. KPCL make GED with Cummins Engine (Model
GTA855BC) CNG compressor for period of two years
installed at various CNG stations Pune GA.
Open Domestic Competitive Bidding
Rs. 2,00,000/- (Rupees Two Lakhs Only) in the form of
Demand Draft / BG /eBG/ Online through e-portal to be in
favour of “Maharashtra Natural Gas Ltd.” payable at Pune.

BID SECURITY VALIDITY
TENDER FEE (Non-refundable)
BID VALIDITY

6 (SIX) months from the final bid due date
Not applicable
4 (FOUR) months from the final bid due date

Bid Submission at

https://etenders.gov.in

Bid submission due date and
03.11.2026 till 15:00 Hrs. IST
time
Techno-commercial
bid
04.11.2026 at 16:00 Hrs. IST
opening date and time
Monday, October 26 · 10:30 – 11:30am
Pre-bid meeting

Google Meet joining info
Video call link: https://meet.google.com/jiw-prwd-qvu

Price bid opening date and time Date and time shall be intimated later
General Manager,
Address for submission of
C&P Department,
EMD/Bid Security and venue
M/s. Maharashtra Natural Gas Ltd.,
for pre-bid meeting and
Pride Purple Coronet, 2nd Floor,
opening of bids
Baner Road, Baner, Pune – 411045
Telephone: +91 (20) 25611000 / 1156 / 1190
Contact details

Email: kavita.sadaphule@mngl.in / gasaid@mngl.in

NOTE: Bidders are advised to complete the registration with e-tender portal
(https://etenders.gov.in) at least two working days prior to the bid submission date.
(The
bids
must
be
submitted
online
in
electronic
form
at
https://etenders.gov.in/eprocure/app only. No physical bids will be accepted.)

Digitally signed by KAVITA SACHIN
SADAPHULE
Date: 2026.10.22 17:02:47 IST
Location: eProcurement System for
