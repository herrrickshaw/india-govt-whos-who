---
doc_id: "c5bfe41dca4ebdc8"
source_url: "https://fssai.gov.in/upload/uploadfiles/files/Gazette_Notification_Surplus_Food_06_08_2019.pdf"
ministry: "Food and Drug Administration, Maharashtra"
title: "Food Safety and Standards (Recovery and Distribution of Surplus food) Regulation, 2019"
date: ""
pages: 7
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "d83ad14bd78aad3b"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx III—[k.M 4
PART III—Section 4
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la-

278]
No. 278]

ubZ fnYyh] eaxyokj] tqykbZ 30] 2019@Jko.k 8] 1941
NEW DELHI, TUESDAY, JULY 30, 2019/ SHRAVANA 8, 1941

वाय और प रवार क याण मंालय
(भारतीय खा

सुर ा और मानक ािधकरण)
अिधसूचना

नई दली, 26 जुलाई , 2019

फा.सं. आरईजी/11/27/ अिधशेष खा

/एफ़एसएसएआई-2017.— खा

ाि और िवतरण) िविनयम, 2019 का ाप, खा
अपे

ाऩुस ार भारत के राजप,

असाधारण,

सुर

सुर

ा और मानक (अिधशेष खा

पुन:

ा और मानक अिधिनयम, 2006 (2006 का 34) क धारा 92 क

भाग 3, खंड 4, तारीख 11 फरवरी, 2019 म भारतीय खा

ािधकरण क अिधसूचना संयांक फा.सं आरईजी/11/27/ अिधशेष खा

सुर

ा और मानक

/एफ़एसएसएआई-2017 तारीख 4 फरवरी, 2019

!ारा कािशत कया गया था, िजसके !ारा उन $ि%य& से, िजनके उनसे भािवत होने क संभावना है, उस तारीख से,
िजसको उ% अिधसूचना वाले भारत के राजप क ितयां जनता को उपल*ध करा दी गई ह&,

समाि से पूव. आ

तीस दन क अविध क

ेप और सुझाव आमंित कए गए थे;

और राजप क ितयां जनता को तारीख 11 फरवरी, 2019 को उपल*ध करा दी गई थ2;

और भारतीय खा

सुर

ा और मानक ािधकरण !ारा उ% ाप िविनयम& के संबंध म जनता से ा आ

ेप& और

सुझाव& पर िवचार कया गया है;

अतः, अब, भारतीय खा

सुर

ा और मानक ािधकरण, उ% अिधिनयम क धारा 92 क उपधारा (2) के खंड (v)

!ारा द4 शि%य& का योग करते 7ए,

क8ीय सरकार क पूव. अनुमित से

अथा.त्:-

3901 GI/2019

(1)

िन9िलिखत िविनयम बनाता है,

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC. 4]

िविनयम

अयाय 1
साधारण
1. संि

त नाम और ारभ.-

(1) इन िविनयम& का संि

 नाम खा

सुर

ा और मानक (अिधशेष खा

पुन:

ाि और िवतरण) िविनयम, 2019 है।
(2) ये राजप म इनके काशन क तारीख को व4 ह&गे और खा

कारोबार चालक को 1 जुलाई, 2020 से इन

िविनयम& के सभी उपबंध& का अनुपालन करना होगा।
2.

प रभाषाएं – (1) इन िविनयम& म, जब तक क संदभ. से अ<यथा अपेि

(क) “अिधिनयम” से खा

(ख) “खा

सुर

त न हो,-

ा और मानक अिधिनयम, 2006 (2006 का 34) अिभेत है;

दानकता#” से कोई ऐसा =यि% या खा

कारबार संचालक अिभेत है जो अिधशेष खा

(ग) “अिधशेष खा

” से कसी सुरि

(घ) “अिधशेष खा

िवतरण संगठन” से ऐसा संगठन अिभेत है जो अिधशेष खा

त खा

दान देता है;

के ऐसे उिच?@ अयुAत भाग अिभेत हB जो Cाहक& को परोसे न गए

ह&;
एक करता है और िबना कसी

फायदे के मुDत िवतरण करता है।
(2) उन श*द& और पद& के, जो इसम यु% हB और पFरभािषत नह2 हB, क<तु अिधिनयम, उसके अधीन बने िनयम&
या िविनयम&, म पFरभािषत हB, वही अथ. ह&गे, Hमश: जो उस अिधिनयम, िनयम या िविनयम म हB।

3.

लोग& को खा

े ेे$.- ये िविनयम खा

िवतरण संगठन जो िबना कसी फायदे के मुDत जरतमंद

िवतरण कर रहे हB, क िजJमेदारी िविनKद.@ करते हB।

4. खा
अिधशेष खा

दाता तथा अिधशेष खा

कारबार संचालक क% िजमेदा रयां. – (1) कोई खा

दाता िजसके पास अिधशेष खा

है वह ऐसा खा

िवतरण संगठन& को इन िविनयम& के उपबंध& अनुसार दान करे गा।

(2) अिधशेष खा

(3) खा

, अनुसूची- I के अधीन िविनKद.@ अपे

$ापार संचालक कसी भी अिधशेष खा

(4) अिधशेष खा

, अिधशेष खा

ाM के अनुसार रखा जाएगा।

िवतरण संगठन को असुरि

त भोजन िवतFरत नह2 करे गा।

िवतरण संगठन को युि%यु% समय पर, यथा िNथित, इसक समाि या खराब

होने से पूव., दे दया जागा िजससे जरतम<द लोग& को उपभोग के िलए खा

के जीवन कल के भीतर उपल*ध कराया जा

सके।

5.

खा

अिधशेष खा

आपूPत. कर रहे हB को खा

िवतरण संगठन क% िजमेदा रयां - (1) अिधशेष खा

सुर

रिजNRीकृत कए जाएंगे और ऐसे खा

ा और मानक (खा

िवतरण संगठन जो जOरतमंद लोग& को

कारबार अनुQि और रिजNRीकरण) िविनयम, 2011 के अनुसार

उ% अिधिनयम के उपबंध& के अनुसार िविधमा<य रिजNRीकरण या अनुQि रखने

वाले िवTसनीय Uोत& से ा कए जाएंगे।
(2) अिधशेष खा

िवतरण संगठन& के पास खा

ह&गी और अनुसूची-I म िविनKद.@ अपे
(3) कोई भी अिधशेष खा

के पFरवहन, भVडारण और पुन: गम. करने के िलए उिचत सुिवधाएं

ाM का पालन कर गे।
िवतरण संगठन अिधशेष खा

क समाि या इसके जीवनकाल के पXात िवतरण नह2

करे गा।

6.

दान 'कये गये खा

करती है क Aया खा

क% लैब+लंग अपे ाएँ- (1)

दान कये गये खा

क लैबZलंग अपे

अपने मूल पैकेट म है या इसे भोजन के प म तैयार कया गया है।

ा इस बात पर िनभ.र

<!-- page 3 -->

¹Hkkx IIIµ[k.M 4º

Hkkjr dk jkti=k % vlk/kj.k

(2) पूव. पैक 7ये दान खा

3

पर उसका पूरा मूल लैबल िजसके अंतग.त वNतु का नाम, िनमा.ता क जानकारी,

सामािCय& क सूची, तथा समाि क तारीख होगी।
(3) जो तैयार खा

दान कए गए हB पर खा

तारीख के साथ लेबलीकृत कए जाएंगे और खा

का नाम, खा

का Uोत, तैयारी क तारीख और उपभोग क अंितम

शाकाहारी है या मांसाहारी यह भी िविनKद.@ कया जाएगा।

(4) लैबल पर जानकारी को कसी भी रीित से आ[छादत नह2 कया जाएगा।

अिधशेष खा

7.

म अिधशेष खा
8.

खा

का रकाड# रखना.- अिधशेष खा

िवतरण संगठन और खा

दाता अनूसूची- II म िविनKद.@ प

का Fरकाड. रखगे ।

मानीटरी सिमित.-

रा]य या संघ रा]य दोन& यथा िNथित का खा

के िलए एक मानीटरी सिमित का गठन करे गा जो

सुर

ा आयु% रा]य Nतर पर अिधशेष

रा]य वत.न अिभकरण से दो सदNय से व संब^ रा]य के उपभो%ा

काय. िवभाग का

एक ितिनिध, गैर-सरकारी संगठन (एनजीओ) से एक सदNय, अिधशेष खा

ितिनिध और उ

ोग संगम और अ<य संबंिधत पदधाFरय&, यद कोई है, से एक ितिनिध से िमलकर बनेगी।

मानीटरी सिमित केेे काय#- (1) मानीटरी सिमित अिधशेष खा

9.

िवतरण संगठन के एक

िवतरण संगठन और खा

दाताM के काम

करने के तरीक& म सुधार पर िसफाFरश और िनगरानी करे गी।

(2) मानीटरी सिमित खा

िवतरण संगठन के खा

संचालक& के िलए NवाN`य और Nव[छता िवषय पर िश

ण

काय.Hम& का संचालन कर सकेगी और इन िनयम& के उपबंध& के काया.<वयन से उaपb होने वाले मुc& पर िसफाFरश भी कर
सकेगी।

खा

10.

ािधकरण /ारा माग#दश#न और सहयोग- (1) खा

ािधकरण, दान के िलए खा

जो उनक समाि के

िनकट हB, को एक और पुन: ाि पर माग.दश.क िस^ांत जारी कर सकेगा और इन िनयम& के अधीन आने वाले खा

कारबार

संचालक& के चालन म सहयोग उपल*ध कर सकेगा ।
(2) खा

ािधकरण खा

समाि से पूव. समय िविनKद.@ कर सकेगा, िजस पर खा

को पृथक कया जाएगा।

अनूसू ूची-I

(िविनयम 4 और 5 देख)

1. खा

कारबार संचालक केेे /ारा अिधशेष खा

1) अिधशेष खा

जो खा

को बंध करना-

िवतरण संगठन को दान म दया जाना है, सुरि

त होगा और िवनTर और गैर-िवनTर

के प म पृथक कया जाएगा।

2) पृथक कया गया खा

को उिचत प से पैक कया जाएगा िजससे इसे िनयंित

और भंडारण के दौरान संद ूषण

से बचाया जा सके।

3)

िवनTर और गैर-िवनTर अिधशेष खा

उनक सुर

ा सुिनिXत करने के िलए अिधकतम तापमान पर

NवाN`यकर िNथित म रखा जाएगा ।
4) अिधशेष खा

5) खा

कसी अपिश@ पदाथ. या उaपाद& के साथ नह2 रखा जाएगा।

दाता खा

िवतरण संगठन को ऐसी अिCम सूचना, िजससे खा

समय िवतरण और उपभोग सुिनिXत करने के िलए देगा।

को उसके जीवन काल के भीतर यथा

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY
2. खा

िवतरण संगठन केेे /ारा अिधशेष खा

1) अिधशेष खा
तथा जैसे खा

खा

िनयं$ण और िवतरण करना -

कारबार संचालक से उठाया जाएगा और Nव[छ तथा ढके 7ए िड*ब& म पैक कया जाएगा

ाdत करने क तारीख तथा उपयोग करने क अि<तम तारीख व अपेि

2) अिधशेष खा

[PART III—SEC. 4]

त तारीख िचि<हत ह&गी ।

, समुिचत NवाN`यकर िNथित म िवनTर और िवनTर खा

के िलए, पृथकत; समुिचत अिधकतम

तापमान पर भंडाFरत और वािहत कया जाएगा। ऊfमा रोधी िड*बे और बफ. पैक, यद आवgयक हो, िनयंित करने और

पFरवहन के दौरान खा

तापमान बनाए रखने के िलए योग कए जा सकगे। खा

बत.न& का योग करना चािहए जो क खा

के सीधे संपक. म आने के िलए अपेि

के पFरवहन के िलए ऐसे उपNकर& एवं

त है, ऐसे बत.न गैर-िवषा%, खा

Cेड पदाथ.

से िनPम.त होने चािहए Zजंका रख-रखाव और सफाई करना आसान हो।
3) अिधशेष खा

का यथा िNथित, अिधशेष खा

क समाि से पूव. या जब तक खा

मानव उपभोग के िलए ठीक

रहता है, जरतम<द लोग& को िवतFरत कर दया जाएगा या परोस दया जाएगा।

4) खा

जो मानव उपभोग के िलए उपयु% नह2 है को कसी िड*बे म Nप@त: “िनपटान के िलए खा

5) खा

को फश. से ऊपर, दीवार& तथा गैर-खा

” अंकत कया

जाएगा ।

वNतुM से दूर भVडाFरत कया जाएगा। भVडारण

े िजसके

अंतग.त फश., पैलेट और अलमाFरय& को िनयिमत प से साफ कया जाएगा।
6) जहां अिधशेष खा

को रखने के िलए शीित का योग कया जाता है तो शीित सdताह म कम से कम एक

बार साफ कया जाएगा। शीित के अ<दर का तापमान

7) भVडारण
जाएगा और ऐसे

7oसे. से कम रखा जाएगा।

े क छत, दरवाजे, तथा िखडकय& को कट वेश करने से रोकने के िलए अ[छी तरह से सील कया

े& म कट िनयंण काय.Hम समय समय पर करवाया जाएगा।

8) िवतरण संगठन के साथ काम करने वाले सभी कम.चारी या Nवंयसेवी जो खा

के सीधे सJपक. म आते हB, नाखून&

को कटे रखगे और साफ बाi कपडे पहनगे। और काय. शुO करने से पहले और यथा आवgयक िवशेषकर खाना खाने के बाद,
खाना संभालने से पहले या साधन& आद के योग के पXात उनके हाथ धोएँगे।
9) ऐसे कसी भी

े म जहां खाना खुला 7आ हो या जहां पर बत.न& या उपकरण& क धुलाई होती हो ऐसे

े& म

खाना खाने से, पीने या तJबाकू उaपाद& का सेवन से बचा जाएगा।

10) कोई $ि%, खा

के माjयम से संचारी कसी बीमारी के दौरान, खा

घाव ढक कर रखे जाएंगे।

अनूसू ूची- II
(िविनयम 7 देख)

1. अिधशेष खा
(1) खा

का रकॉड# रखा जाएगा-

दाता संगठन का नाम और पता;

(2) अिधशेष खा

िवतरण संगठन का नाम और पता;

(3) दान क तारीख;

(4) उaपाद का नाम (वNतु);

(5) खा

उaपाद (वNतु) क बैच संया;

के संपक. म नह2 आएगा। चोट, फोड़े और

<!-- page 5 -->

¹Hkkx IIIµ[k.M 4º

Hkkjr dk jkti=k % vlk/kj.k

5

(6) िविनमा.ण क तारीख;

(7) तारीख से पूव. सवk4म या समाि तारीख;

(8) खा

दाता !ारा दान क गई माा;

(9) खा

का तापमान;

(10) अिधशेष खा

(11)

िवतरण संगठन !ारा िवतFरत माा;

े, जहां खा

िवतFरत कया गया है;

(12) िवतरण तारीख।

पवन अCवाल, मुय काय.कारी अिधकारी

[िवQापन-III/4/असा./167/19]
MINISTRY OF HEALTH AND FAMILY WELFARE
(FOOD SAFETY AND STANDARDS AUTHORITY OF INDIA)
NOTIFICATION
New Delhi, the 26th July, 2019
F. No. REG/11/27/ Surplus Food/FSSAI-2017.— Whereas the draft of the Food Safety and Standards
(Recovery and Distribution of Surplus Food) Regulations, 2019 were published as required by section 92 of the Food
Safety and Standards Act, 2006 (34 of 2006), vide notification of the Food Safety and Standards Authority of India
number No. REG/11/27/ Surplus Food/FSSAI-2017, dated 4th February, 2019, in the Gazette of India, Extraordinary,
Part III, Section 4, dated 11th February, 2019, inviting objections and suggestions from the persons likely to be affected
thereby, before the expiry of the period of thirty days from the date on which the copies of the Official Gazette
containing the said notification were made available to the public;
And Whereas, the copies of the said Gazette were made available to the public on the 11th February, 2019;
And Whereas the objections and suggestions received from the public in respect of the said draft regulations
have been considered by the Food Safety and Standards Authority of India;
Now, Therefore, in exercise of the powers conferred by clause (v) of sub-section (2) of section 92 of the said
Act and with the previous approval of the Central Government, the Food Safety and Standards Authority of India hereby
makes the following regulations, namely:REGULATIONS
CHAPTER I
GENERAL
1. Short title and commencement.- (1) These regulations may be called the Food Safety and Standards (Recovery and
Distribution of Surplus Food) Regulations, 2019.
(2) They shall come into force on the date of their publication in the Official Gazette and Food Business Operator shall
comply with all the provisions of these regulations by 1st July, 2020.
2. Definitions. – (1) In these regulations, unless the context otherwise requires,-(a) “Act” means the Food Safety and Standards Act, 2006 (34 of 2006);
(b) “food donor” means any person or food business operator who donates surplus food;
(c) “Schedule” means a schedule annexed to these regulations;
(d) “surplus food” means any leftover unused portions of safe food that have not been served to the customers;
(e) “surplus food distribution organisation” means any person or any organisation that collects surplus food from food
donor and distributes directly to any person free of cost without any profit.
(2) All other words and expressions used herein and not defined, but defined in the Act, rules or regulations made
thereunder, shall have the meanings assigned to them in the Act, rules or regulations, respectively.
3. Scope.- These regulations specify the responsibility of the food donor and surplus food distribution organisations those
who are engaged in distributing the surplus food to any person free of cost.

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC. 4]

4. Responsibilities of food business operator. – (1) Any food donor having surplus food may donate such food to any
surplus food distribution organisation in accordance with the provisions of these regulations.
(2) The surplus food shall be maintained in accordance with the requirements specified in Schedule–I.
(3) The food business operator shall not distribute unsafe food to any surplus food distribution organisation.
(4) The surplus food shall be handed over to surplus food distribution organisation at a reasonable time before it gets
spoiled or its expiry, as the case may be, so that the food is made available to needy persons for consumption within the
shelf life of the food.
5. Responsibilities of surplus food distribution organisation. - (1) Surplus food distribution organisation which is
serving food to needy person shall be regulated in accordance with the provisions of the Food Safety and Standards
(Licensing and Registration of Food Business) Regulations, 2011 and such foods shall be obtained from reliable sources
having valid registration or license in accordance with the provisions of the Act.
(2) The surplus food distribution organisation shall have proper facilities for transport, storage and reheating, and shall
comply with the requirements specified in Schedule-I.
(3) No surplus food distribution organisation shall distribute surplus food after the expiry of its shelf life.
6. Labeling requirements of donated foods.- (1) The requirements for labeling of donated food depends on whether the
food is in its original package or has been prepared as meal.
(2) Donated pre-packed food shall bear its complete original label, including name of the item or food, manufacturer
information, list of ingredients, and date of expiry.
(3) Donated prepared food shall be labeled with the name of the food, the source of the food, the date of preparation and
last date of consumption and also specify whether the food is vegetarian or non-vegetarian.
(4) The information on the label shall not be masked in any manner.
7. Maintenance of record of surplus food.- The food donor and surplus food distribution organisation shall maintain
the record of surplus food as specified in Schedule-II.
8. Monitoring Committee.- The Commissioner of Food Safety of the State or, as the case may be, the Union territory
shall constitute a monitoring committee for surplus food at State level consisting of two members from State enforcement
agency, one representative from Department of Consumer Affairs of the respective State, one member from nongovernmental organisation , one representative from surplus food distribution organisation and one representative from
industry association and other relevant stakeholders.
9. Functions of monitoring committee.- (1) The monitoring committee shall monitor and make recommendations on
the improvement of the operations by the surplus food distribution organisation and food donors.
(2) The monitoring committee may also conduct training programs in health and hygiene for the food handler of
food distribution organisation and also make recommendations on issues arising from implementation of the provisions
of these regulations.
10. Guidance and support by Food Authority.- (1) The Food Authority may issue guidelines on collection and
retrieval of food, which is near to their expiry, for donation and provide guidance to support the operations of food
business operators covered under these regulations.
(2) The Food Authority may also specify the time before the expiry, at which food shall be segregated.
Schedule-I
(see regulation 4 and 5)
1. Handling of surplus food by the food business operator. – (1) Surplus foods that are to be handed over to food
distribution organisation shall be safe and segregated in to perishable and non-perishable.
(2) The segregated food shall be packed appropriately so as to avoid contamination during handling and storage.
(3) Perishable and non-perishable surplus food shall be stored in hygienic condition at optimum temperature to ensure
their safety.
(4) Surplus food shall not be kept with any waste material or products.
(5) The food donor shall give an advance notice to the surplus food distribution organisation so as to ensure a timely
distribution and consumption of the food within its shelf life.
2. Handling and distribution of surplus food by the surplus food distribution organisation. (1) Surplus food shall be picked up from the food business operator’s facility and packed in clean and covered containers.
Such food containers shall have the required date marking such as pick-up date and the use by date of food.
(2) Surplus food shall be stored and transported in clean and sanitized vehicles in appropriate hygienic condition at
appropriate optimum temperature suitable for perishable and non-perishable food separately. Insulated containers and ice
packs, if necessary, may be used to maintain food temperature during handling and transportation. Food transport

<!-- page 7 -->

¹Hkkx IIIµ[k.M 4º

Hkkjr dk jkti=k % vlk/kj.k

7

equipment/ utensils that are intended to be in direct contact with food products should be constructed with non-toxic,
food grade materials, which shall also be easy to clean and maintain.
(3) Surplus food shall be distributed or served to the needy before the expiry of surplus food or until food is fit for human
consumption, as the case may be.
(4) Food that is not fit for human consumption shall be put in a container clearly marked as “Food for Disposal”.
(5) Food shall be stored off the floor and away from walls and non-food items. storage area, including the floor, pallets
and shelves shall be cleaned regularly.
(6) Where refrigerator is used for storage of surplus food, these shall be cleaned at least once a week to remove stains, ice
particles and food particles. The temperature in the refrigerator shall be maintained below 7oC.
(7) Doors, windows and roofs of storage area shall be well sealed to prevent pest entry and a pest control program shall
be in place for such areas.
(8) All employees or volunteers that work with distribution organisation and come in direct contact with food shall keep
their finger nails trimmed and shall wear clean outer garments and wash their hands before starting work, and as often as
necessary, especially after eating handling or using the washroom, etc.
(9) Avoid eating food, drinking beverages, or using tobacco in any form in areas where food is exposed, or in areas used
for washing equipment or utensils shall be avoided.
(10) No person shall come in contact with food during any illness that is communicable through food. Cuts, boils and
wounds shall be covered.
(11) All employees or volunteers that work with distribution organisations and come in direct contact with food shall
have training in health and personal hygiene.
Schedule-II
(See regulation 7)
Record of surplus food to be maintained.(1) Name and address of the food donor organisation;
(2) Name and address of surplus food distribution organisation;
(3) Donation date;
(4) Name of the food product (item);
(5) Batch number of food product (item)

;

(6) Date of manufacturing;
(7) Best before date or expiry date;
(8) Quantity donated by food donor;
(9) Temperature of food;
(10) Quantity distributed by surplus food distribution organisation;
(11) Area where food is distributed;
(12 ) Date of distribution.
PAWAN AGARWAL, Chief Executive Officer

[ADVT.-III/4/Exty./167/19]

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
Digitally signed by

MANOJ
MANOJ KUMAR VERMA
2019.08.01
KUMAR VERMA Date:
20:00:43 +05'30'
