---
doc_id: "4ac65e267fffbb4b"
source_url: "https://cdn.s3waas.gov.in/s3f0e52b27a7a5d6a1a87373dffa53dbe5/uploads/2021/11/2021112880.pdf"
ministry: "Akola"
title: "Government Site Approval Order for Cemetery Gullarghat"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1be5d5421b7b2d73"
---

<!-- page 1 -->

TATSR, TTav-22/TFarurz/02/2017-2018

TAT. TTTaT-22/aTcarurz/02/2017-2018
t

afas TET zta da Te ä. 247 7tta ata 0.43 . T YM 0.05 . *
FHRITAaiiaT a 0.10 . 3TT z45TTitaT Heft vgUr 0.15 8. 3TT Ta.

IT.5.1/76TeT-b/3orb fis o2.1t.2ot 9T f&in 03.1.
*****

InS1So9
5/11/17

160

TaRa Te

t6 0.05 .

3T. 4T7EA a

AN FARITTSAT{TAT T 0.10 .

HMCATHT HTIT Ba.

HT ZYHT

iAT 3RÍt vaur 0.15 s. N

JA1T

<!-- page 2 -->

247 Htta 0,43

.

.3TR 0.05 .

AN

HIs zids CN t a aTe ä. 247

eh. 0.05 .HTT. FAAITGTBAT NIAT a 0.10 .

FARITTAETTiaT a 0.10 . AN zilpiiiAT AR

Htia ta 0,43 .

ATR TlA

1971 T

AT. FHTAIT

zh7aiTNIAT FrM vaUT 0.15 . 3TT JAa,

RTErita.
HTE) f

ATT dfT. 0.05

FRi TAt=RI TL KTIECTOS.

<!-- page 3 -->

C.

3HTAngATR YIU$T (T.MT.)

1. AT. 3TgA, HARTTt faT 3TRIaTT TiT FITErKTT HIGR.
2.

5.

6. a s AF
