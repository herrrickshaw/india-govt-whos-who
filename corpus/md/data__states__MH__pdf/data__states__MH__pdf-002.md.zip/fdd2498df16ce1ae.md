---
doc_id: "fdd2498df16ce1ae"
source_url: "https://www.coeptech.ac.in/wp-content/uploads/2024/07/Facility-Management-Retender-IFMS.pdf"
ministry: "COEP Technological University, Pune, Maharashtra"
title: "Quotation for Providing Integrated Facilities Services (Housekeeping, Security and Gardening)."
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "a29bf7b913277ffa"
---

<!-- page 1 -->

सीओईपी तंत्रज्ञान विद्यापीठ
वििाजीनगर, पुणे – 411005
(महाराष्ट्र िासनाचे एकल तंत्रज्ञान विद्यापीठ)
Off.: + 91-20-25507191. Fax + 91-20-25507299. Web: www.coep.org.in
जा.क्र.: सीओईपी_विद्यापीठ/सुविधा व्यिस्थापन/फे र_वनविदा-िेबसाईट/2024/

ददनांक: 26/07/2024.

फे र वनविदा
सीओईपी तंत्रज्ञान विद्यापीठ, पुणे तफे पात्र ि अनुभिी ठे केदारांकडू न ‘एकावममक सुविधा सेिा (साफसफाई,
बागकाम ि सुरक्षा)’ प्रदान करण्यासाठीची फे र वनविदा ददनांक 02/08/2024 दुपारी 03:00 िाजेपयंत मागविण्यात
येत आहे. महाराष्ट्र िासनाच्या महा-टेंडर https://mahatenders.gov.in/ या पोटटलिर इच्छु क ठे केदारांनी आपल्या
वनविदा विवहत पद्धतीने ददलेल्या कालािधीत सादर कराव्यात. वनिेदांसंबधीत खुलासेिार मावहती खाली ददलेल्या
टेंडर आयडीचा िापर करून ठे केदारांना उपलब्ध करून ददलेली आहे.
Sr. No.
1.

Retender Title
Retender ID
Providing Integrated Facilities Services at COEP 2024_DTEDM_1041929_2
Technological University Through eProcurement system
of Government of Maharashtra.

(डॉ. द.ननं. सोनिणे)
कु लसवचि,
सीओईपी तंत्रज्ञान विद्यापीठ, पुणे.
मा. कु लगुरू यांच्या संमती ि आदेिानुसार.
