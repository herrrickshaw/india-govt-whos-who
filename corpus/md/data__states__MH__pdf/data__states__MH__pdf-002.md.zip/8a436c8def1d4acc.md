---
doc_id: "8a436c8def1d4acc"
source_url: "https://fssai.gov.in/upload/uploadfiles/files/Order%20dated%2025-07-2025%20enclosing%20Ayurveda%20Aahara.pdf"
ministry: "Food and Drug Administration, Maharashtra"
title: "Food Safety and Standards (Ayurveda Aahara) Regulations, 2022"
date: ""
pages: 172
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "1861a50c727b306b"
---

<!-- page 1 -->

SS-T0SP05(EC)/2/2022-Standard-FSSAI

I/29912/2025

भारतीय खा सुर ा एवं मानक ािधकरण
Food Safety and Standards Authority of India
( वा य एवं प रवार क याण मं ालय)
(Ministry of Health and Family Welfare)
व ान एवं मानक वभाग
Science and Standards Division
एफ ड ए भवन, कोटला रोड, नई द ली-११०००२
FDA Bhawan, Kotla Road, New Delhi - 110002
ईमेल/Email : ayurveda-aahara@fssai.gov.in
दनांक/Dated 25 जुलाई/July 2025
आदे श
Order
वषय: खा सुर ा और मानक (आयुवद आहार)
आयुवद आहार– के संबंध म

विनयम, २०२२ के अंतगत शािमल

Subject: Ayurveda Aahara covered under Food Safety and Standards
(Ayurveda Aahara) Regulations, 2022 – reg
खा

सुर ा एवं मानक (आयुवद आहार)

अंतगत ट पण १ का संदभ लेते हुए, जो यह िन द

समय पर

विनयम, २०२२ क

अनुसूची ‘ख’ के

करता है क खा

ािधकरण समय-

ेणी 'क ' म स मिलत आयुवद आहार क सूची दे सकती है ।

This is in reference to the Note (1) under Schedule B of the Food Safety and
Standards (Ayurveda Aahara) Regulations, 2022 which speciﬁes that the Food
Authority may provide a list of Ayurveda Aahara covered under category A from
time to time.
२.

इस संबंध म, आयुष मं ालय के परामश से , एफएसएसएआई, खा

मानक (आयुवद आहार)

विनयम, २०२२ के अंतगत

उ पादन एवं सु वधा हे तु

तुत कर रहा है ।

आयुवद आहार ( ित संल न) खा

सुर ा एवं

ेणी 'क' के अंतगत आने वाले

यवसाय संचालक (एफबीओ) क आयुवद आहार के

2.
In this regard, in consultation with Ministry of Ayush,FSSAI is hereby
providing Ayurveda Aahara covered under category A under the Food Safety and
Standards (Ayurveda Aahara) Regulations, 2022 (copy enclosed) for facilitating
Food Business Operators (FBOs) for manufacturing of Ayurveda Aahara.

<!-- page 2 -->

SS-T0SP05(EC)/2/2022-Standard-FSSAI

I/29912/2025

तथा, वग 'क' के अंतगत आने वाले परं तु सूची म न उ ल खत आयुवद आहार

३.
उ पाद क

थित म खा

कारोबार उ ह सूची म शािमल करने के िलए खा

को अनुसूची 'क' म स मिलत

ंथ से आिधका रक संगत पाठ

ािधकरण

तुत करते हुए अनुरोध

कर सकते है । अतः समय-समय पर होने वाले कसी भी प रवतन क सूचना अलग से
खा

ािधकरण

ारा द

जाएगी। य द कोई

/ ट पण ह , तो

उ ह ayurveda-

aahara@fssai.gov.in पर ईमेल कर।
3.
Further, in case of Ayurveda Aahara products falling under category A, but
not mentioned in the list, Food Business Operator shall request the Food Authority
for inclusion by submitting relevant literature from Authoritative text listed under
Schedule A books. Thus, any changes happening from time to time will be notiﬁed
separately. Any queries/concern may be forwarded to the email: ayurvedaaahara@fssai.gov.in.
४.

यह स म

ािधकार के अनुमोदन से िनगत है ।

4.

This issues with the approval of the Competent Authority

(डॉ. अलका राव)
(Dr. Alka Rao)
सलाहकार ( व ान एवं मानक और विनयम)
Advisor (Science & Standards & Regulation)
उपरो ानुसार संल न
Encl. as above

<!-- page 3 -->

<!-- page 4 -->

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

<!-- page 12 -->

<!-- page 13 -->

<!-- page 14 -->

<!-- page 15 -->

<!-- page 16 -->

<!-- page 17 -->

<!-- page 18 -->

<!-- page 19 -->

<!-- page 20 -->

<!-- page 21 -->

<!-- page 22 -->

<!-- page 23 -->

<!-- page 24 -->

<!-- page 25 -->

<!-- page 26 -->

<!-- page 27 -->

<!-- page 28 -->

<!-- page 29 -->

<!-- page 30 -->

<!-- page 31 -->

<!-- page 32 -->

<!-- page 33 -->

<!-- page 34 -->

<!-- page 35 -->

<!-- page 36 -->

<!-- page 37 -->

<!-- page 38 -->

<!-- page 39 -->

<!-- page 40 -->

<!-- page 41 -->

<!-- page 42 -->

<!-- page 43 -->

<!-- page 44 -->

<!-- page 45 -->

<!-- page 46 -->

<!-- page 47 -->

<!-- page 48 -->

<!-- page 49 -->

<!-- page 50 -->

<!-- page 51 -->

<!-- page 52 -->

<!-- page 53 -->

<!-- page 54 -->

<!-- page 55 -->

<!-- page 56 -->

<!-- page 57 -->

<!-- page 58 -->

<!-- page 59 -->

<!-- page 60 -->

<!-- page 61 -->

<!-- page 62 -->

<!-- page 63 -->

<!-- page 64 -->

<!-- page 65 -->

<!-- page 66 -->

<!-- page 67 -->

<!-- page 68 -->

<!-- page 69 -->

<!-- page 70 -->

<!-- page 71 -->

<!-- page 72 -->

<!-- page 73 -->

<!-- page 74 -->

<!-- page 75 -->

<!-- page 76 -->

<!-- page 77 -->

<!-- page 78 -->

<!-- page 79 -->

<!-- page 80 -->
