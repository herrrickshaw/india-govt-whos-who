---
doc_id: "cb498690afaebf4c"
source_url: "https://www.mahapolice.gov.in/uploads/jrp-2025-circular-n-letter.pdf"
ministry: "Maharashtra State Police, Maharashtra"
title: "जीवन रक्षा पदक २०२५"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0d900377bab42494"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

MOST IMMEDIATE

No.17/2/2025-Public

Government of India/ Bharat Sarkar

Ministry of Home Affairs/Grih Mantralaya
[Public Section]
North Block, New Delhi-110001

Dated the 26th March, 2025.

To
1.
2.
3.

4.

5.
6.

7.
8.
9.
10,
11,

Sub:

The Chief Secretaries of all State GovernmentsS
The Administrators of all UT Administrations

... 025

The Secretaries of all Ministries/Departments of the Govt. of India
The Member Secretary, National Disaster Management Authority
The Directors General of all Central Armed Police Forces
The Dìrector General, Railway Protection Force
The Director General, National Disaster Response Force
The Director General, Civil Defence &% Home Guards
The Director General, Fire Services
DGPs of all State Governments/UT Administration

Director General, National Investigation Agency

Recommendations for Jeevan Raksha Padak series of awards-2025.

Sir/Madam,
Jeevan Raksha Padak series of awards are given for meritorious acts of
humane nature in saving the life of a person in incidents like drowning, accidents,

fire incidents, electrocution, land slides, animal attack and rescue operation in

mines etc. As the name of the award suggests, the award is given to a rescuer

for saving someone's life. It is given in the following three categories:

i)

Sarvottam Jeevan Raksha Padak - awarded for conspicuous courage in
saving life under circumstances of very great danger to the life of the
rescuer.

ii)

iii)

Uttam Jeevan Raksha Padak - awarded for courage and promptitude in
saving life under circumstances of great danger to the life of the rescuer.

Jeevan Raksha Padak -awarded for courage and promptitude in saving
life under circumstances of grave bodily injury to the rescuer.

2. Persons in all walks of life are cligible for these awards. Members of the Armed
Forces, Police Forces and of recognized Fire Service etc. are also eligible for these
awards provided the life saving act is performed by them. As the Prime Minister's
Police Medal for Life Saving" instituted by Ministry of Home Affairs has been
subsumed in the "Jeevan Raksha Padak", the members of CAPFS/ CPOs and
Police Forces, who have shown exemplary devotion to duty in saving human
life, are also eligible for Jeevan Raksha Padak. The award is also conferred

posthumously.
...continucd/

<!-- page 4 -->

-2

Overy ycar, the Ministry of Home Affairs invites
recommendations
all
State
Governments/UT Administrations, Ministries,/ Departments from
of
the
Government of India, CAPF and other authorities for these awards. The
recomnmendations are examinecd
1ts recommendations to the Primeby a high-level Awards Committee, which makes
Ministcr and the President. After approval of
the President, the decoration of the
award. i.c.. Medal and Certificate along with
UIe monetary allowance in respect of
the awardees, are sent to the
Concerned
recommending authorities.
4. Over the last few years, it has

been observed

mdividuals during natural calamities, accidents,that various acts of life saving by
1hcidents etc. are reported in the print and extremists attack, drowning/iire

electronic media. However, such
valhant and gallant acts go unrecognized
in the absence of suitable
by the State/UT Government and
nominations
take place. You would appreciate authorities under whose jurisdiction such acts
that awards and decorations are
of recognition of the services
tangible tokens
rendered
by
an
individual.
Such
awards
and motivate others for similar
action in the hoår of need. The enc0urage
concerned
authorities are, therefore, requested to send
suitable and deserving nominations
to this Ministry for consideration.
It may be noted that the
recommendations for
this award are considered by Awards
Committee
within
a
period
of two vears from
the date of performance of the
gallant act. Therefore, for the year
2025, any
recommendation in respect of which the date of
performance
of the life
saving act falls prior to 1st October 2023
should not be forwarded to this
Ministry for consideration.
5. The recommendations for the

be sent in online mnode only

Jeevan Raksha Padak series of Awards
can
through the password protected Rashtriya

Puraskaar Portal designed by the Ministry of
Homne Affairs, (URL:
https://www.awards.gov.in ). The recommendations should contain
all relevant
details specified in the format available on the above
said portal, including a
citation in narrative form (maximum 250 words),
clearly
out the
sequence-wise details of the incident, courage and promptitudebringing
by the
rescuer and danger to life and also specific role/contributiondisplayed
of the person
(rescuer).

6. A character and antecedent verification certificate duly
signed and stamped
by the recommending authority may be scanned and uploaded on the
portal. A
Perforna of this certificate is available on website. A copy of above is enclosed with
this letter. While recommending a person online, it may be ensured that all
the
necessary details including name of the recommended person in Hindi are filled
properly.

...continued/

<!-- page 5 -->

(3

-3

7. It may be noted that the recommendations for Jeevan Raksha Padak Series
of Awards for the year 2025 are to be sent latest by 30th September 2025. For
online recommendations each recommnending authority should use the previ0us

year's Login ID and Password. If Login ID and Password is not available for any

reason then it is requested to send an email from your official Email ID to

sopub@nic.in to get your Login ID and Password through email.

Yours faithfully,
Encls. As above.

(Debobroto Basu)
Under Secretary to the Government of India
Tele: 23092421

<!-- page 6 -->

Annexure
FOR
RECOMMENDATION OFCERTIFICATES
JEEVAN RAKSHA PADAK SERIES OFAWARDS
1. lt is certified that the

character and antecedents of *
been verfied and it is confirmed that
there is nothing adverse against him/her on

2

It is certified that *

is

have

record.

a member of

(i.e
Army/Police/Fire Services etc.)
and life saving act for which this
recommendation is being forwarded was performed/not

preformed during the course

of his/her duties.

(Signature)

Name & Designation of the Recommending Authority
Date

*Name of the recommended person(s)

Applicable only to members of Uniformed Services ( i.e Army/Police/Fire Services
etc.)

<!-- page 7 -->

PROFORMA FOR RECOMMENDATION OF JEEVAN RAKSHA PADAK
SERIES OF AWARDS
|1.

FullName in Englislh (in Block letters)

2

Fullname in Hindi(Compulsory)

3

Father/Husband/Guardian's Name

4.

Date of Birth/Age

5.

Gender

6.

Complete postal address (with phone numbers etc.)

7.

Whether recommmendation is for Posthumous

Male/Female

Yes/No

award?

Name of the Next-of-kin along with relationship (in
case of Posthumous award)
Date of incident

Note: The life saving act prior to 01/10/2023 will
not be considered.

10. Number of lives saved.
11.

Whether the recommended person is a member of
the Uniformed Services (Armed Forces, Police
Forces and of recognized Fire Services etc.) ?

12.

13

If yes, whether the life saving act was performed
during the course of duty or otherwise?

Whether the life saving act was an individual effort
or a team work?

14

Whether any injury was suffered by the rescurer

during the life saving act?

Yes/No

<!-- page 8 -->

(6
15

If yes, Details of injury suffered by the

I6.

Award recommended* viz. Sarvotlam Jeevan

rescurer?

Raksha Padak (SJRP)/Uttam Jeevan Raksha Padak
(UJRP) /Jeevan Raksha Padak (JRP)
17.

Whether the candidate has been awarded or being
considered or eligible for any other avward for the
same life saving act ? Please give the details, if any.

18.

Details of Jeevan Raksha Padak Series of Award

received earlier, if any

Award :
Year

CITATION#

This should be in form of a write-up of about 200 words, giving complete details

(sequence wise) of the life saving act clearly brining out the courage and promptude
displayed by the rescurer and danger to his/her life under the circumstances. The deatils of
injury, if any, suffered by the rescurer during the act may also be given. (Separate sheet to be
attached).
The category of award recommended should invariably be mentioned.

Note: Allcolumns must be completed in all respects failing which the application is liable

to be rejected.
