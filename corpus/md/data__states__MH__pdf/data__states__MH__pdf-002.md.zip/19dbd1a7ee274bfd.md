---
doc_id: "19dbd1a7ee274bfd"
source_url: "https://cdn.s3waas.gov.in/s3f0e52b27a7a5d6a1a87373dffa53dbe5/uploads/2021/11/2021112828.pdf"
ministry: "Akola"
title: "Government land sanction order for construction of Gram Panchayat Bhavan and School Room and cremation in Samthana Bk"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "eb820b8f7f7759a9"
---

<!-- page 1 -->

ZTATT. UTTAU-22/HTASTUTT q,/04/2017-2018

(Tftr farKl99 Rotb)
qTATTUOTTAT-22/HTHOTUT q,/04/2017-2018
Ht HaT a

Àhta da Tc .

39 7tita Å7 12.61 z.3TT. ZST 0.10
.3TT. Tuia
Tdiiar, a 0.05 .3HTT FAAApt a 0.10 z. TT
z5TPiataT a JTATaYA AaT
aitraATtar 0.10 3TR 3F2ft vor 0.35 . 3ITT JAA

T.5. 1/26rd-?823/20

TT o.?8.20?6 IT TT 03.?8.2°?b
*****

S-151

TAT 3Ta.
5 / 1 / 1 7

fris 22/08/2017 tat Rdar

i. 39 Ftta a T ur

A~eTaR YTaa zaiT zrar ~uzrara

BA.

aiuatHaT 0.10 AR, ZTAYURA
H aiuIATTRIT 0.10 .3HR
FHRIAHEAT aiuaHTh{ar 0.05 . 3T 7 zha
itAT 0.10 . 3T FRi TauT 0.35 .3ITR.

<!-- page 2 -->

ATT TCA ATRA.
8.

3HTR, AYarA HaT
aiyaHT4AT

aYo7&TeiIAT 0.10 .

AT

0.10

HECTAHaa 7/12 a aaTSi FART GSTT

3.

zATR, HRITAAT

aiyarHTriaT 0.05 . R
7r vqUT 0.35
ATT. zvarH FTA ATa ¥H h d
HTE.

T

Hl

HTHT T Pta da 3TE Ä. 39 Atta ta 12.61
.3ITT. ZAT 0.10 .3HT. JAA
ITDNTT, a 0.05 .AT
FRITTAPAT a 0.10 .
ziaareitniiaT a THYTA a
TerTar 0.10 3T Fi vaqUT 0.35 . AN TAT

ABRTE Jaa AEYT 3TfrA 1966

aTE .

.

39 Httr d7 12.61 .3TT. YST 0.10 .HTT. TATT aITdTar, a 0.05 . T FARIIAAPt a 0.10

3HTT ah7}tTAT a HYATYA yaa auhTHTCNAT 0.10 TT 3RT TaUT 0.35 .

R.

aI) an 1971

agat aAtrr

TIEFI.

H* TAa,

<!-- page 3 -->

3.

HTaRY5 HTE.
8.

.

3HTdE faTTTT TUTT5 TST.

HTFATTAR TUT (4T.W.HT.)
fenftrt ratar

1.

HT.

3HTYET, HFRIAAT fGHTT HFRIAt 41T FTEriFTT HIcT.

4.
5.

6

a s AFAT
3HTfEanATÉ YIuzu (HT.W. H)
