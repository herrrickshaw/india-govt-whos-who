---
doc_id: "bcb18d26e7ff2bf7"
source_url: "https://www.mahatransco.in/uploads/news/news_1792730215.pdf"
ministry: "Maharashtra State Electricity Transmission Co. Ltd., Maharashtra"
title: "Nashik Zone : Notification for Document Verification for the post of Vidyut Sahayak ( Transmission)(Contract)- Waiting List Provisionally Selected Candidates Under Direct Recruitment"
date: ""
pages: 3
method: "tesseract:mar+hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "32a142d70f417cca"
---

<!-- page 1 -->

RY
APY

Mahwcostra Stal टिकी Tanaisson 0० Li

NOTIFICATION FOR DOCUMENTS VERIFICATION OF PROVISIONALLY
SELECTED CANDIDATES FOR THE POST OF
“Viduyat Sahayak (Contract)”
विद्युत सहाय्यक (पारेषण) (कंत्राटी )

Ref : Corporate Office Mumbai L. No. 9075 dtd. 19.10.2026.

Vide Notifications under reference provisional list of the candidates considered for selection
for the post of “Viduyat Sahayak (Contract)” विद्युत सहाय्यक (पारेषण) (कंत्राटी) has been published by
Corporate Office.

2. Now, as mentioned in the said notification, the candidates mentioned in the list Annexure ‘A’
attached to the Corporate Office Mumbai L.No.9075 dtd. 19.10.2026 who are provisionally selected
against waiting List for said posts are being called for Documents Verification as per the schedule
mentioned below—
Date & Time Post Name Candidate Sr. Venue
of No. as per
Document Nashik Zone
Verification
26.10.2026 “Viduyat Sahayak As per list Conference Hall Block No 4,
Monday (Contract)” Attached Office of the Chief Engineer
(10:00AM 10 | विद्युत सहाय्यक (पारेषण) (कंत्राटी ) EHV Project Cum O&M Zone,
06:00PM) Nashik, , “Prakashkumbha”
Administrative Building, Old
Saikheda Rd., Behind Durga Mata
Mandir, Jail Road, Nashik Road
422 101
3. Candidates have to bring one set of attested Xerox Copies of below mentioned Documents /
Certificates along with its “ORIGINAL COPY” at the time of document verification.
a) Application Form
b) Domicile Certificate
०) S.S.C. Board Certificate.
d) National Trade Certificate conferred by NCTVT (after completion of Apprentice/ ITI/CoE in
Electrician Trade)
९) School leaving certificate for Date of Birth
f) Caste Certificate (If applied against reserve category post)
g) Caste Validity (If available - If applied against reserve category post)
h) Non-Creamy Layer Certificate. {If applied against reserve category post (Except SC & ST)}
i) Economically Weaker Section Eligibility Certificate (If applied against EWS reservation)
j) Medical / Divyang Certificate (If applied against Divyang reservation)
k) Discharge Certificate (If applied against Ex-serviceman reservation)
1) Project Affected Person / Earthquake Affected Person Certificate (If applied against PAP or EAP
reservation)
m) Orphan Certificate (If applied against Orphan reservation)
n) Sports Certificate (If applied against Sports reservation)
0) Marathi Language Certificate (As mentioned in the advertisement)
p) Change of Name Certificate (If applicable)

<!-- page 2 -->

q) Certificate regarding physical limitation in an examinee to write (if availed Compensatory Time
in On-line Test)

r) Any other document (if required) as mentioned in the Recruitment Advt. No 08/2024 dated
22.06.2024

4. If candidate remains absent for the Documents Verification then he/she may be held not interested
and he/she will be held “Not Eligible” for further selection process.

5. Please take note that, calling for Documents Verification does not confer any automatic right of
possible employment with the Company.

eT G

Place: Nashik “Chief Engineer

Date: 22.10.2026 EHV PC O&M Zone Nashik

<!-- page 3 -->

No.| No No Category} Selected Selected
Category | Under/Against
a
a
डि
शि
Chief Engineer (Trans)
EHV Project Cum O&M Zone Nasik
