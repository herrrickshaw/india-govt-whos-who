---
doc_id: "fea70886fdc3ffaa"
source_url: "https://rgstc.maharashtra.gov.in/wp-content/uploads/2025/07/RGSTc_video_making_Notice.pdf"
ministry: "Rajiv Gandhi Science & Technology Commission, Maharashtra"
title: "RGSTC Project Video making Tender Notice(Marathi & English)(Size-1.4 MB)"
date: ""
pages: 4
method: "tesseract:mar+hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "7ca6484f70e5cfd4"
---

<!-- page 1 -->

राजीव गांधी विज्ञान व तंत्रज्ञान आयोग
महाराष्ट्र शासन | वि
नोटीस फाईल क्र. रागावितंआ/फा-२०२५/किडिओ/प्र.क्र.१३०/ ९ /०
सामान्य प्रशासन विभाग
अँपीजे हाउस, ३ रा मजला, _
दिनशॉ वाच्छा रोड, के.सी. कॉलेज जबळ,
मुंबई-४०० ०२०,
दूरध्वनी क्र. -०२२ - ४००६१७९३
ई-मेल- rystemaha@rediffmail.com
दिनांक: - १२ नोव्हेंबर,२०२५
प्रति,
विषय - आयोगाच्या कार्यालयासाठी निवडक तंत्रज्ञानांच्या माहितीचे छोटे व्हिडिओ क्लीप्स
| तयार करण्याकरिता दरपत्रके मागविणेबाबत.
। संदर्भ- सामान्य प्रशासन विभाग शासन निर्णय मावज-२०२३/प्र.क्र.१८७/का-३४
| दिनांक २३ नोव्हेंबर,२०२३
| राजीव गांधी विज्ञान व तंत्रज्ञान आयोग,(१0510) अपीजे हाऊस, ३रा मजला, के.सी. कॉलेज जवळ, दिनशां
| बाच्छा रोड, चर्चगेट, मुंबई या कार्यालयाच्या निवडक तंत्रज्ञानाच्या माहितीचे छोटे व्हिडिओ acter तयार करणे
करीता संदर्भिय शासन निणर्यात नमूद सेवापुरवठादारांकडून दरपत्रके मागविण्यात येत आहेत.
।
| १. स्पर्धात्मक दरपत्रके मागविण्याचा कार्यक्रम पुढीलप्रमाणे आहे -
स्पर्धात्मक दरपत्रके मागविण्याची नोटोस प्रसिध्दी दिनांव , १२-११-२०२५
स्पर्धात्मक दरपत्रके मागविण्याचा कालावष् . १२-१९-२०२५ ते १९-११-२०२५
(कार्यालयीन वेळेत सकाळी ११.०० ते
साय.५.०० पर्यंत)
तांत्रिक लिफाफा उघडण्याचा दिवस दि. २०-११-२०२५ सकाळी ११.०० वाजता
| Technical Bid (Cover = १)
सेवा पुरवठादारांनी स्वत: बनवलेल्या सॅम्पल व्हिडिओचे | दि. २०: रूरप सकाळी १२०० बाजता |
सादररीकरण (6 आयोगाचे समिती सभागृह __
तांत्रिक बाबतीत पात्र ठरलेल्या सेवा पुरवठादारांचा आर्थिक | | दि. २०-११-२०२५ दुपारी ०३.०० बाजता
लिफाफा उघडण्याचा दिवस Financial Bids (Cover — २)
दरपत्रके सादर करणेसंबंधी अटी व शर्ती खालील प्रमाण ra ण
(१) सदर दरपत्रकाचा नमुना व (नमुना त्यासंबंधित सूचना सोबत जोडल्याप्रमाणे) सेवा पुरवठादारांने त्यांच्या लेटरहेडवर सही
व शिक्कयांनिशी दि, १२-११-२०२५ ते १९-११-२०२५ पर्यंत सीलबंद लिफाफ्यातून आयोगाच्या कार्यालयात शासकीय सुट्ट्या
वगळून सकाळी ११.०० ते संध्याकाळी ५.०० वाजेपर्यंत सादर कराबेत, सदर सिलबंद लिफाफ्यावर ठळकपणे “Technical Bid

<!-- page 2 -->

- Making of Video Clips on RGSTC Work” (Cover -१) and “Financial Bid - Making of Vidco Clips on
RGSTC Work" (Cover -२) असे नमूद करून दोन वेगवेगळया सीलबंद लिफाफ्यात सादर करणे आवश्यक आहे. सदरची
| नोटीस कार्यालयाच्या Nitps://rgste.maharashtra.gov.in/tender या वेबसाईटवर सुध्दा माहितीसाठी उपलब्ध राहिल.
। (२) सदर सौलबंद लिफाफे (Technical Bid) आयोगाच्या अँपीजे हाउस, 3 रा मजला, दिनशॉ aren रोड, के.सी.
कॉलेज जवळ, मुंबई-४०० ०२० या कार्यालयात दिनांक २०-११-२०२५ रोजी सकाळी ११.०० वा. उघडण्यात येतील
| त्याचवेळी दरपत्रक सादर केलेले सेवापुरवठादार स्वत: किंवा त्यांचे प्रतिनिधी यांना (अधिकारपत्रासह (Authority
| Letter) या कार्यालयात सादरीकरणासाठी उपस्थित रहावयाचे आहे. मात्र लिफाफा उघडणे आणि त्यासाठी उपस्थित
रहाणे याबाबत कोणताही स्वतंत्र पत्रव्यवहार करण्यात येणार नाही याची दरपत्रकदारांनी नोंद घ्यावी. सेवापुरवठादार
| यांना शासकीय विभागांसाठी तयार केलेल्या छोट्या -छोटया व्हिडीओ acting सादरीकरणामार्फत दाखविता येतील
| त्यापैकी Orignal Content Generation असलेल्या गुणवत्ताधारक व्हिडीओ क्लीप्स्‌ बनविणाऱ्या सेवापुरवठादार
। यांच्या तांत्रिक पात्रता तपासणीत पात्र ठरलेल्या निविदाधारकांची Financial Bid दिनांक २०-११-२०२५ रोजी दुपारी
| ०३.०० वा. उघडण्यात येतील.
(३) सीलबंद Technical Bid लिफाफ्यामध्ये सादर केलेले कागदपत्रांसोबत शासकीय संस्था /कार्यालये यांच्यामध्ये
| व्हिडिओ क्लीप बनविण्यासंबधी काम केल्याचे संबंधित विभागाचे अनुभवाचे दाखले सोबत जोडणे आवश्यक राहिल.
(४) दरपत्रकासोबत दरपत्रकधारकांने पॅनकार्डची छायांकीत प्रत जोडणे सक्तीचे राहील.
| (५) दरपत्रकावर जीएसटी नंबर नमूद करणे सक्तीचे आहे.
। (६) पॅनकार्ड व जीएसटी क्रमांक नमूद न करता सादर केलेली दरपत्रके सरळ नामंजूर करण्यात येतील व त्याबाबत
| कोणताही पत्रव्यवहार केला जाणार नाही.
| (७) ज्या सेवापुरवठाधारकाने दरपत्रकातील लघुत्तम दर व्हिडिओ क्लीप्सू बनविणेसाठी कार्यालयाने मान्य केला
आहे, त्या सेवापुरवठादाराने देयकाप्रमाणे व्हिडिओ क्लीप्स्‌ बनविल्यानंतर त्यांचा दर्जा योग्य असल्याची खात्री
झाल्यानंतरच ब तसे प्रमाणित झाल्यानंतरच देयक अदा करण्यात येईल. कोणत्याही परिस्थितीत आगाऊ रक्‍कम अदा
केली जाणार नाही.
(८) स्पर्धात्मक दरपत्रके मागविण्याची नोटीस आणि अटी व शर्ती आयोगाच्या संकेतस्थळावर उपलब्ध आहेत.
(https://rgstc.maharashtra.gov.in/tender)
(९) या निविदेबाबत काही शंका असल्यास अथवा अधिक तपशील आवश्यक असल्यास, आयोगाच्या ईमेल
आयडी - (rgstcmaha@rediffmail.com) बर संपर्क साधावा.
QA
(डॉ. नरेंद्र शहा)
सदस्य सचिव, रागांवितंआ

<!-- page 3 -->

१ अजआजाजजजाअयजजअजाजययग््टरकळळ्गगययावबाब॒ायााबव॒नुशनववशवुवााााव्स्क्कककसमयशवशकशशााशााााााााा
5 for submission of Quotations for Making of Video Clip on RGSTC Work is as below:-
FORMAT
Subject :- Submission of Quotation for Making of Video Clips on RGSTC कणा.
ate
inclusive of
all Taxes,
Traveling
Charges if
an}
Making of The Video
Video Clips on | A. Tutorial on Submission of proposals to | clip will be
| RGSTC Work | RGSTC under following Schemes :- up to 5
हि minutes on
1. Assistance for S & T Applications each project.
II. Assistance to Collaborative Projects
between Institutions and Industries
for Technology Development
/Adoption
(Al Based Simple Animation Short Video clip
| Estimated rate *
है OR
a Simple Text based Presentation cum voiceover short
Video clip Estimated rate *)
| *Please mention separate rate for both.
| +
B) Success stories of RGSTC -
|| Key Project Areas
1. Buldhana & Chhatrapati Sambhaji nagar
District (1 project)
2. Sangli District (1 Project )
3.__Kolhapur (1 project
' Name & Signature of Bidder/-
| Stamp / Seal
Instructions :-
1. Duly Signed and Stamped/Sealed Quotations to be submitted.
2. GST Number and PAN Number details must be written on Quotation.
3. Documents Attached with Quotation - Pan card copy , GST Certificate, Experience Certificates (Refer
condition No.3 in Tender Notice)
4. Technical Bid and Financial Bid should be submitted in Two Separate Sealed Envelops clearly
mentioning “Technical Bid — Making of Video Clip on RGSTC Work” and “Financial Bid - Making of
Video Clip on RGSTC Work” with Bidder Name and Address.
5. Hard copy of Quotation should be submitted from 12-11-2025 to 19-11-2025 between 11 .00 am to 05.00
pm only.
6. Kindly refer Complete Tender Notice uploaded on RGSTC Website for detailed information about
Making of Video Clips on RGSTC Work & Terms and Conditions.
Address :-
Member Secretary,
Rajiv Gandhi Science and Technology Commission,
Apeejay House, 3rd Floor, Dinshaw Vachha Road,
Near K.C. College, Churchgate, Mumbai - 400 020,
pep a

<!-- page 4 -->

Scope of work
ऱ्या , Short Effective Video Making :
© Create upto 5 minutes videos based on relevant requirements. |
® Videos should be concise and impactful.
2. Video Concepts and Subjects: ।
© Develop video concepts based on the provided list of requirements.
e Ensure that the videos cover relevant topics effectively.
|
3. Field Job for Respective Projects: |
© Conduct fieldwork in the mentioned district for gathering necessary footage and |
information. |
4. Script and Subtitles Draft Approval and Finalization:
e Prepare scripts for narration and dialogues. |
e Create subtitles in Marathi and English languages. |
e Seek approval for scripts and subtitles drafts before finalization. |
5. Subsequent Video Editing: |
e Edit videos as per project requirements. |
e Incorporate feedback and revisions during the editing process. |
6. Finalization of Relevant Videos with Subtitles: |
e Ensure the final videos are polished and include accurate subtitles in all specified |
languages. |
7.Research Project Videos for Informative Purposes:
¢ Create videos specifically for institutional and public informative purposes. |
e Seeking no paid publicity or advertisement for videos. |
||
