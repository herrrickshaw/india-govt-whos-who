---
doc_id: "4b0a4cb8dab05cb6"
source_url: "https://fssai.gov.in/upload/uploadfiles/files/Gazette_Notification_Packaging_03_01_2019.pdf"
ministry: "Food and Drug Administration, Maharashtra"
title: "Food Safety and Standards (Packaging) Regulation, 2018"
date: ""
pages: 20
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "a439dc968cc5a70a"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx III—[k.M 4
PART III—Section 4
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la-

535]
No. 535]

ubZ fnYyh] lkseokj] fnlEcj 24] 2018@ikS"k 3] 1940
NEW DELHI, MONDAY, DECEMBER 24, 2018/PAUSHA 3, 1940

वाय एवं परवार क याण मंालय
(

भारतीय खा सुरा और मानक ािधकरण)
अिधसूचना
नई दली, 24 दसबर, 2018

मानक/पैकेे जंग/एसपी/एल एवं सी/एफएसएसएआई-2017.—कितपय िविनयम का ाप अथात्:

फा.सं. 1-95/

खा सुरा और मानक (पैके!जंग) िविनयम,

2018, भारत के राजप%, असाधारण, भाग-III, खंड 4 म& अिधसूचना सं॰

फाईल सं'या 1-95/मानक/पैके!जंग/ एसपी(एल एवं सी/ए)/एफएसएसएआई-2017 तारीख 19 माच, 2018 )ारा खा

सुरा और मानक अिधिनयम, 2006 (2006 का 34) क* धारा 92 क* उपधारा (1) के अधीन अपेानुसार कािशत कए
गए थे िजसम& उन -ि.य से िजनक* उससे भािवत होने क* संभावना है, उस तारीख से िजसको उ. अिधसूचना वाले

राजप% क* ितयाँ जनता को उपल2ध करा दी गई थ4, तीस दन क* अविध समा5 होने से पूव आेप और सुझाव आमंि%त
कए गए थे;
भारतीय खा सुरा और मानक ािधकरण ने खा सुरा और मानक (पैके!जंग और लेब!लंग) िविनयमन, 2011
बनाया, लेकन अब खा ािधकरण ने इन िविनयम को दो िविनयम म& िवभािजत करने का िनणय िलया है, -

(i) खा सुरा और मानक (पैके!जंग) िविनयम, 2018; और

(ii) खा सुरा और मानक (लेब!लंग और दशन) िविनयम, 2018,

और तदनुसार उपयु. ाप िविनयम के अनुसार कािशत कए गए;

और उ. राजप% क* ितयाँ जनता को 2 अैल, 2018 को उपल2ध करा दी गई थ4;

7544 GI/2018

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY
और उ. ाप िविनयम के

[PART III—SEC.4]

सब9ध म& जनता से ा5 आेपो और सुझाव पर भारतीय खा सुरा और मानक

ािधकरण )ारा िवचार कर िलया गया है;
खा सुरा और मानक अिधिनयम 2006 (2006 का 34) क* धारा 23 के साथ प<ठत धारा 92 क* उपधारा (2)
के खंड (ट) )ारा द> शि.य का योग करते ?ये और खा सुरा और मानक (पैके!जंग और लेब!लंग) िविनयम, 2011,

क* जहां तक वे पैके!जंग िनयम से संबंिधत हA, उन बात के िसवाए अिधBांत करते ?ए िजसे ऐसे अिधBमण से पूव कया गया
है या करने का लोप कया गया है खा सुरा और मानक ािधकरण िनCिलिखत िनयम बनाता हA , अथात्: -

िविनयम

संि5 नाम और ारभ.-(1) इन िविनयम का संि5 नाम खा सुरा और मानक (पैके!जंग) िविनयम,

1.
2018

है।

(2) ये राजप% म& इनके काशन क* तारीख को व> हगे और खा कारोबार चालक को 1 जुलाई, 2019 से इन

िविनयम के सभी उपबंध का अनुपालन करना होगा।
2.

परभाषाएं- (1) इन िविनयम म&, जब तक क संदभ से अ9यथा अपेित न हो,-

(क)

“अिधिनयम” से खा सुरा और मानक अिधिनयम, 2006 (2006 का 34) अिभेत है;

(ख)

“

खा ेणी” से उस सामDी से अिभेत है जो क उसके उपयोग के अनुसार सुरित एवं उपयुEत है िजससे

मानव FवाFथय को कोई खतरा नह4 हो और जो भोजन क* संरचना एवं ओगHनोलेिIटक िवशेषताL म& प<रवतन नह4 करती
हो।

(ग)

बपरतीय/खा पैकेे जंग संरचना से अथ उस खा पैMकंग सामDी या वFतु से अभेत है जो क दो या दो

“

से अिधक िभ9न िभ9न कार के अनुमत पैMकंग सामिDय क* परत से िमलकर बना होता है।

(घ)

संपूूण  जन सीमा" से अथ सामDी या वFतु )ारा खा उNतेजक म& छोडी जाने वाली गैर-वाOपशील

“

पदाथP क* अिधकतम अनुमत रािश से अिभेत है।
(ङ)

“पैकेे ज या

क!टेनर” से अिभेत है पहले से पैक कया ?आ िड2बा, बोतल, काFकेट, <टन, बैरल, केस, पाउच,

बEसा, बोरा, बैग, रै पर, या इस कार क* अ9य वFतुL से है िजनम& खा पैक कया जाता है।
(च)

पैकेे जंग साम$ी” से खा उNपाद के पैके!जंग के िलए उपयोग कए जाने वाले काडबोड, पेपर, कांच,

“

धातु, IलािFटक क* फम, ब?-परत पैके!जंग सामDी जैसे सामिDयां अिभेत है।

ाथिमक खा पैकेे जंग” से अिभेत उस पैMकंग सामDी से है जो क खा उNपाद के सीधे सपक म& आती

(छ)

“

(ज)

“सहायक

है।

खा पैकेे जंग” का अथ उस पैMकंग सामDी से है जो क ाथिमक खा पैके!जंग को बाहर से

ढकती है और यह खा के सीधे सपक म& नह4 आती है।

(झ)

“िवशेष

वजन सीमा” से सामDी या वFतु के )ारा भोजन या भोजन उNतेजक म& छोडी जाने वाले पदाथ

क* अिधकतम अनुमत रािश से अिभेत है।
(2) उन श2द और पद के, जो इसम& यु. हA और इन िविनयम म& प<रभािषत नह4 हA, क9तु अिधिनयम, उसके
अधीन बने िनयम या िविनयम, म& प<रभािषत हA, वही अथ हगे, Bमश: जो उस अिधिनयम, िनयम या िविनयम म& उनके हA;

<!-- page 3 -->

¹Hkkx IIIµ[k.M 4º
3.

Hkkjr dk jkti=k % vlk/kj.k

3

सामा!य आव)यकताएं-

(1) हर खा कारबार चालक यह सुिनिTत करे गा क इFतेमाल क* जाने वाली पैके!जंग सामDी इन िविनयम के
अनुसार होगी:
परं तु यद भारतीय मानक उपल2ध नह4 हA, तो ासंिगक अंतराUीय मानक का पालन कया जा सकता है।

(2) कोई भी सामDी जो भोजन के साथ सीधे संपक म& आता है या भोजन के संपक म& आने क* संभावना है िजसका
उपयोग खा को पैक करने, तैयार करने, भVडारण म&, रै !पंग, प<रवहन या िबB* या सेवा म& कया जाता है वह सामDी खा

Wेणी गुणवNता क* होनी चािहए।
(3) पैके!जंग सामDी उNपाद के कार, भंडारण के िलए दान क* गई शतP और खा को भरने, सी!लंग और

पैके!जंग के साथ-साथ प<रवहन शतP के िलए उपयु. होगी।
(4) सामा9य प<रवहन के दौरान पैके!जंग सामDी यांि%क, रासायिनक या थमल तनाव का सामना करने म& सम हो
। लचीला या अX-कठोर कंटे नर के मामले म&, एक ओवररै प पैके!जंग आवYयक हो सकता है।

(5) खा उNपाद को साफ, FवZछ और टेपूफ पैकेज/ कंटे नर म& पैक कया जाना चािहए।

(6) सी!लंग सामDी उNपाद और कंटे नर के साथ-साथ कंटे नर के िलए इFतेमाल होने वाले Eलोजर िसFटम के साथ
संगत होनी चािहए।
(7) एक बार उपयोग कये ?ए <टन कंटे नर, खा क* पैके!जंग के िलए फर से इFतेमाल नह4 कया जाना चािहए।

(8) 5 लीटर और उससे अिधक मता वाले IलािFटक कंटे नर और \लास क* बोतल&, िज9ह& भोजन के पैके!जंग के िलए
पुन: उपयोग कया जाता है, उपयु. <टकाऊ, साफ करने या साफ करने के िलए आसान होनी चािहए।

(9) खा पैकेट पर उपयोग म& ली जाने वाली Fयाही आईएस: 15495 मानक के अनुप होनी चािहए।

(10) पैके!जंग सामDी क* मु^त सतह, खा उNपाद के साथ सीधे संपक म& नह4 आनी चािहए।

(11) अखबार या कसी भी ऐसी सामDी का भंडारण और खा को लपेटन के िलए इFतेमाल नह4 कया जाना
चािहए।
(12) यद ब?परतीय पैके!जंग सामDी का उपयोग कया जा रहा है तो जो सतह खा के सीधे सपक म& आ रही है
उसको इस िविनयम क* अनुसूची I, II, और III म& व_णत आवYयक मानदVड के अनुप होना चािहए।

(13) इन िविनयम के अनुसूची I, II और III म& सूचीबX सामिDय को पैके!जंग सामDी के प म& उनके इिZछत
उपयोग के साथ संगत कया जाना चािहये ताक खा उNपाद क* गुणव>ा और सुरा म& कोई प<रवतन नह4 हो।
(14) Nयेक खा -ापार ऑपरे टर को पैके!जंग सामDी या उसक* परत िजसके भोजन के सीधे संपक म& क*
संभ ावना है के िलए इन िनयम के अनुप एन ए बी एल मा9यताा5 योगशाला )ारा जारी अनुपता का माण प% ा5
करना होगा।

4.

म4 आती ह6-

ाथिमक खा पैकेे जंग केेे िलए िविश+ आव)यकताएँ.- (1) कागज एवं बोड साम$ी जो खा उ0पाद2 केेे स3पक

(क) कागज और बोड सामDी बनावट एंव मोटाई म& एक समान होनी चािहए।

(ख) यह दाग ध2ब, तेल एवं िचकनाई के िनशान, कटे-फटे , छोटे-छोटे छेद और अ9य दोष से मुEत होने चािहए।

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

(ग) िजस कागज का उपयोग िड2बे, बडे िड2बे, Iलेट, कप, कागज के ढEकन को बनाने म& उपयोग होता है या जो
कागज खा उNपाद के सीधे सपक म& आता है वह खा Wेणी का होना चािहए और संद ूिषत पदाथ से मुEत होना चािहए।
(घ) िजन कागज एवं बोड सामिDय का उपयोग ऐसे िड2ब को बनाने म& कया जाता है िजनका उपयोग खा

उNपाद के भVडारण एवं पैक करने म& कया जाता है, उ9ह& अनुसूची-I म& दये गये िविनदHश के अनुसार ासंिगक भारतीय
मानक पर खरा उतरना चािहए।
(2) कांच केेे

क!टेनर जो 7क खा उ0पाद2 केेे सीधे स3पक म4 आते ह6 – (क) जहाँ तक संभव हो, ये फफोले, ढालने के

िनशान, पNथर और िच!पंग से मुEत होने चािहए और जहां तक संभव हो, बुलबुले, डो<रय, बीज और अ9य दखाई देने वाले

दोष से भी मु. होने चािहए।
(ख) इनक* सतह िबना दरार, छे द, नुक*ली धार से रिहत िचकनी होनी चािहए।

(ग) इनके सील करने क* सतह दरार एवं मुख सीवन जोड के िनशान से मुEत होनी चािहए।

(3) धातु और

िम धातु जो 7क खा उ0पाद2 केेे सीधे स3पक म4 आते ह6- (क) बतन या क9टेनर जो क िनन धातुL

या सामिDय से बने ह एवं िजन खा का उNपादन या भVडारण इन बतन मे कया जाता है वह मानव उपभोग के िलए

अनुपयुEत है:(i) जंग लगे ?ए बतन;

(ii) एनामलावृत बतन जो क टूटे ?ए और जंग लगे ?ए ह।

(iii) तांबे या पीतल के बतन िजन पर <टन क* परत न चढी हो।

(ख) धातु और धातु िमW धातु, जहाँ लागू हो, के उपयु. Dेड खा उNपाद के पैMकंग या भंडारण के िलए उपयोग

कए जाएंगे।
(ग) िजन धातुओ& एवं िमW धातुL का उपयोग ऐसे िड2ब को बनाने म& कया जाता है िजनका उपयोग खा उNपाद
के भVडारण एवं पैक करने म& कया जाता है, को अनुसूची - II म& दये गये िविनदHश के अनुसार ासंिगक भारतीय मानक पर
खरा उतरना चािहए।

(4)

8लाि9टक साम$ी जो खा उ0पाद2 केेे स3पक म4 आती ह6- (क) िजन IलािFटक सामिDय का उपयोग ऐसे िड2ब

को बनाने म& कया जाता है िजनका उपयोग खा उNपाद के भVडारण एवं पैक करने म& कया जाता है, को अनुसूची-III म&

दये गये िविनदHश के अनुसार ासंिगक भारतीय मानक पर खरा उतरना चािहए:
परं तु पेय जल (पैकेcड एवं खिनज जल दोन) रं गहीन, पारदशd, एवं टेपूफ बोतल या क9टेनर म& पैक कये गये ह
पोलीथीलेन

(पीई)

जो

क

आईएस:10146

या

पोलीिवनाईल

Eलोराईड

(पीवीसी)

जो

क

आईएस:

10151

या

पोलीएकेलाईन टेरेपेथलेट (पीईटी और पीबीटी) जो क आईएस :12255 या पोलीोपलेन (पीपी) जो क आईएस:10910
मानक को पूरा करते ह या खा Wेणी क* पोलीकाबeनेट आईएस:14971 पोलीFटीरे न आईए:10142 मनको को पूरा करते
हो या जीवाणु रिहत कांच क* बोतल का उपयोग पेयजल को पैक करने के िलए कया जाना चािहए।

कंटे नर क* पारद_शता

काश fांसिमटेशन म& 85 ितशत से कम नह4 होनी चािहए।
इसके अित<र. भारतीय मानक आईएस: 9833 म& िनgदh सभी वणक या रं ग को पांच लीटर और उससे ऊपर के

IलािFटक के कंटे नर म& अनुमित दी जा सकती है जो पॉली काबeनेट और पॉलीथीन टेरेफाथलेट (पीईटी) से बना है जो क
खिनज पानी के पैके!जंग और पेयजल के पैके!जंग के िलए इFतेमाल कया जाता है। इस तरह के कंटे नर क* पारद_शता काश

fांसमीटर से 85 ितशत से कम नह4 होनी चािहए।

<!-- page 5 -->

¹Hkkx IIIµ[k.M 4º

Hkkjr dk jkti=k % vlk/kj.k

5

(ख) IलािFटक से बनी सभी पैके!जंग सामिDय म& आईएस 9845 के अनुसार िनधा<रत iजन सीमा 60 िमDा/कDा
या 10 िमDा/ डीएम2 पर खरा उतरना चािहए एंव दृYयरं ग का iजन न हो।

(ग) IलािFटक सामिDय एवं वFतुएं, तािलका 1 के तहत दी गई िविनgदh iजन सीमा से अिधक मा%ा म&

िनCिलिखत पदाथ नह4 छोड़ेग4।
(घ) खा या पेयजल के सीधे सपक म& आने वाली IलािFटक म& उपयोग कया गया रं ग^- या रं गीन पदाथ को
आईएस: 9833 मानक पर खरा उतरना चािहए।

(ड़)

पुननवीनीकरण IलािFटक से बनने वाले बैग या फर से कए गए IलािFटक के बने उNपाद को पैके!जंग,

भंडारण, भोजन या खा पदाथP के िवतरण के िलए इFतेमाल नह4 कया जाएगा।

8लाि9टक साम$ी जो 7क खा उ0पाद2 केेे सीधे स3पक म4 आते ह6 केेे िलए िविन:द+  जन सीमा क;
आव)यकताएं।
<.सं त0व
अिधकतम  जन सीमा (िम$ा/7क$ा)

सारणी 1:

1.

बे<रयम

1.0

2.

कोबाट

0.05

3.

तांबा

5.0

4.

लोहा

48.0

5.

िलिथयम

0.6

6.

मAगनीज

0.6

7.

जFता

25.0

5. सांकेितक पैके!जंग सामDी क* एक सूची िजनका उपयोग खा उNपाद क* पैके!जंग म& कया जा सकता है को अनूसची-IV

म& िविनgदh कया गया है:
परं तु यह एक सूचक सूची है जो िनgदh मानक के साथ अनुपालन करने वाली कसी भी अ9य पैके !जंग सामDी के
उपयोग को ितबंिधत नह4 करती है।
अनूसू ूची – I

<.सं

कागज

और बोड साम$ी जो खा उ0पाद2 के सीधे स3पक म4 आते ह6।
मानक2 क; सूची

1.

िचकनाईरोधी कागज – आईएस 6622

2.

वनFपित चमप% या िचकनाईरोधी कागज / एयुमीिनयम फोईल लेिमनेट – आईएस 7161

3.

पैMकंग के िलए एयुमीिनयम फोईल लेिमनेट– आईएस 8970

4.

सामा9य उपयोग के िलए पैMकंग/रै !पंग कागज – आईएस 6615

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY
5.

फो!डंिग बॉEस, अनकोटे ड – आईएस 1776

6.

नालीदार फाइबर बोड बEसे - िविशhता (भाग 1) - IS 2771

[PART III—SEC.4]

नोट: कागज या बोड पर मोम क* परत चढाने के िलए पैराफन मोम जो क आईएस 4654 के कार I पर खरा उतरता हो का
उपयोग कया जाना चािहए।

अनुसू ूची – II
धातु और

िम धातु जो खा उ0पाद2 केेे सीधे स3पक म4 आते ह6।

<.सं

मानक2 क; सूची

1.

कोड <रqुFड इलेEfोलाइ<टक <टनIलेट– आईएस 1993/ आईएसओ 11949

2.

कोड <रqुFड इलेEfोलाइ<टक Bोिमयम या Bोिमयम ऑEसाइड - लेिपत Fटील - आईएस 12591 / आईएसओ
11950 है

3.

सामा9य अिभयाि9%क* के िलए गढ़ा ?आ एयूिमिनयम और िमिWत एयूिमिनयम धातु क* शीट और पuी आईएस 737

4.

खा पैके!जंग के िलए एयूिमिनयम और एयूिमिनयम िमिWत फ़ोइल – आईएस 15392

5.

Bाउन Eलोजर के िलए िविशhता - आईएस 1994

6.

खा और पेय पदाथP के िलए िविशhता घुमकर ऊपर से खुले ?ए गोल सेनेटरी कैन के िलए िविशhता – आईएस
9396 – (भाग- 1)

7.

खा और पेय पदाथP के िलए घुमकर ऊपर से खुले ?ए गोल सेनेटरी कैन के िलए िविशhता – आईएस 9396 –
(भाग- 2)

अनुसूची – III
लािटक सामी जो खाय उपाद के सीधे स पक! म" आते ह&

<.सं
1.

मानक2 क; सूची
खा पदाथP, दवाईय और पीने के पानी के सुरित उपयोग के िलए इनके

संपक म& आने वाली पॉलीथीन के

िलए िविनदHश - आईएस 10146
2.

खा पदाथP, दवाईय और पीने के पानी के सुरित उपयोग के िलए इनके संपक म& आने वाली पॉलीFटHन के िलए
िविनदHश - आईएस – 10142

3.

खा पदाथP, दवाईय और पीने के पानी के सुरित उपयोग के िलए इनके संपक म& आने वाली पोलीिवनाईल
Eलोराईड (पीवीसी) और उसके सहपॉिलमर के िलए िविनदHश - आईएस 10151

4.

खा पदाथP, दवाईय और पीने के पानी के सुरित उपयोग के िलए इनके

संपक म& आने वाली पोलीोपीलेन

और उसके सहपॉिलमर के िलए िविनदHश - आईएस 10910
5.

खा पदाथP, दवाईय और पीने के पानी के सुरित उपयोग के िलए इनके संपक म& आने वाली लोनोमर रे िज9स
के िलए िविनदHश - आईएस 11434

6.

खा पदाथP, दवाईय और पीने के पानी के सुरित उपयोग के िलए इनके

संपक म& आने वाली ऐथीलेन

<!-- page 7 -->

¹Hkkx IIIµ[k.M 4º

Hkkjr dk jkti=k % vlk/kj.k

7

एBिलक एिसड (ईएए) सहपॉिलमर के िलए िविनदHश - आईएस 11704
7.

खा पदाथP, दवाईय और पीने के पानी के सुरित उपयोग के िलए इनके

संपक म& आने वाली पोलीएकेलेन

टेरीपेथलेyस (पीईटी एवं पीबीटी) के िलए िविनदHश - आईएस 12252
8.

खा पदाथP, दवाईय और पीने के पानी के सुरित उपयोग के िलए इनके

संपक म& आने वाली नायलोन 6

पोलीमर के िलए िविनदHश - आईएस 12247
9.

खा पदाथP, दवाईय और पीने के पानी के सुरित उपयोग के िलए इनके

संपक म& आने वाली इथाइलीन

िवनाईल एसीटेट (ईवीए) सहपोलीिमस के िलए िविनदHश - आईएस 13601
10.

खा पदाथP, दवाईय और पीने के पानी के सुरित उपयोग के िलए इनके संपक म& आने वाली एथीलीन मेथा
ऐBेिलक एिसड (ईएमएए) के िलए िविनदHश - आईएस 13576

11.

खा पदाथP, दवाईय और पीने के पानी के सुरित उपयोग के िलए इनके

संपक म& आने वाली पोलीकाबeनेट

रे िज9स के िलए िविनदHश - आईएस 14971
12.

खा तेल, घी और वनFपित के पैके!जंग के िलए लचीले पैके !जंग सामDी के िलए िविनदHश 14636

13.

ढलाई और बाहर िनकालने के िलए पॉिलएEलीन टेरीफेथलेटृ स (पीईटी और पीबीटी) के िलए िविनदHश - आईएस
13193

14.

पॉलीऐथीलीन फम एंव शीट के िलए िविनदHश -आईएस 2508

15.

रै िखक कम घनNव वाली पॉलीथीन (एलएलडीपीई) फस के िलए िविनदHश– आईएस- 14500

16.

उZच घनNव वाली पॉलीएिथलीन सामDी का ढलाई और बाहर िनकालने के िलए िविनदHश– आईएस 7328

17.

खा पदाथP, दवाईय और पीने के पानी के सुरित उपयोग के िलए इनके

संपक म& आने वाली मेलामाईन-

फामलािडहाइड रे िज9स के िलए िविनदHश - आईएस 14999
18.

कम घनNव पॉलीथीन फम& - आईएस 2508 है

19.

2लो मोड पॉलीओलेफ़न कंटेनर - भाग 2: 5 लीटर से ऊपर तक और िजसमे 60 लीटर मता भी शािमल है आईएस 7408

20.

Ffेच !Eलंग फस - आईएस 14995 है

अनुसू ूची – IV
सांकेे ितक

<.सं
1.

पैकेे जंग सामि$य2 क; सूची

उ0पाद ेणी
दु\ध एवं दु\ध उNपाद

पैकेे जंग साम$ी का कार
• धातु

या

IलािFटक

पोिलोपाइलीन

(पीपी)

या

उ|

घनNव

पोलीईथाईलीन (एचडीपीई) के ढEकन के साथ कांच क* बोतल&।

• IलािFटक पोिलोपाइलीन (पीपी) या उ| घनNव पोलीईथाईलीन
(एचडीपीई) के ढEकन के साथ

पोलीईथाईलीन टेरेIथेलेट (पीईटी) से

बने ?ए कठोर IलािFटक क9 टेनर।

• IलािFटक (पोिलोपाइलीन (पीपी) या उ| घनNव पोलीईथाईलीन
(एचडीपीई) के ढEकन के साथ उ| घनNव पोलीईथाईलीन (एचडीपीई)

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY
या

पोिलोपाइलीन (पीपी) या

[PART III—SEC.4]
पोिलFटाई<रन (पीएस) से बने ?ए

कठोर IलािFटक क9टेनर।

• पॉलीएिथिलन (पीई) या

पोिलोपाइलीन (पीपी)

आधा<रत सह-

एEस}डेड ब?परतीय सामDी से बने लचीले IलािFटक थैली।

• शुद ृ और लचीली पैके!जंग सामDी (कागज बोड या एयूिमिनयम प~ी
या पॉलीिथिलन) आधा<रत ब?परतीय संरचना।

• <टन Iलेट कंटेनर।
• एयूमीिनयम फॉयल आधा<रत परतदार

संरचना से बने कागज के

िड2बे

• IलािFटक से बने पोिलोपाइलीन (पीपी) या

पोिलFटाई<रन (पीएस)

कप िजनम& ढEकन को हटाया जा सकता हो ।

• मEखन को रैप करने वाले मोम क* परत वाले कागज
• कागज और कागज बोड आधा<रत तह काटन िजसके अ9दर बटर पेपर
म& िलपटा ?आ मEखन हो।

•

कागज या छील ढन के साथ IलािFटक आधा<रत पोिलोपाइलीन
(पीपी) या

पोिलFटाई<रन (पीएस) के कप।

• IलािFटक् के ढEकन के साथ IलािFटक के पीईटी क9टेनर
• थमeफॉम के कप/fे िजनके ढEकन हटाये जा सकते ह।
• कागज एवं कागज बोड के िड2बे िजनके अ9दर IलािFटक क* फम हो
या नह4 हो-

• कागज एवं कागज बोड के िड2बे िजनके अ9दर िचकनाईरोधी पेपर
लगाया गया हो या नह4 लगाया गया हो।

• IलािFटक आधा<रत ब? परतीय लचीली परत थैिलयां िज9ह& गम करके
ब9द कया जाता है।

• िमuी के बतन
2.

वसा, तैल एवं वसा पायसन

• <टन Iलेट कंटेनर
• धातु

या

IलािFटक

पोिलोपाइलीन

(पीपी)

या

उ|

घनNव

पोलीईथाईलीन (एचडीपीई) ढEकन के साथ कांच क* बोतल&।

• उ| घनNव पोलीईथाईलीन (एचडीपीई) से बने कठोर IलािFटक के
क9टेनर (जार).

• IलािFटक के ढEकन के साथ पोलीईथाईलीन टेरेIथेलेट (पीईटी) से बने
?ई बोतल या जार।

• IलािFटक क* थैिलयां जो क ब? परतीय लैिमनशन संरचना से बनाई
गई ह।

• शुद ृ और लचीली पैके!जंग सामDी (कागज बोड / एयूिमिनयम फॅायल/
पॉलीएिथलीन) आधा<रत ब?परतीय संरचना।

• दृ-तरफ* बोड बॉEस म& IलािFटक लेिमनेटेड थैला ( िड2बा म& थैले)।
• IलािFटक के ढEकन के साथ थमeफाड आधा<रत IलािFटक जार।
• एयूमीिनयम फॉयल आधा<रत परतदार संरचना से बने िड2बे
• कागज आधा<रत रे खांकत िड2बे िजन पर

एयूिमिनमय

फायल

<!-- page 9 -->

¹Hkkx IIIµ[k.M 4º

Hkkjr dk jkti=k % vlk/kj.k

9

आधा<रत लैिमिनशन क* संरचना क* गई हो।
3.

फल और स2जी उNपाद

• धातु

या

IलािFटक

पोिलोपाइलीन

(पीपी)

या

उ|

घनNव

पोलीईथाईलीन (एचडीपीई) के ढEकन के साथ कांच क* बोतल&।

• एयूिमिनयम के केन िज9ह& आसानी से खोला जा सकता हो।
• <टन Iलेट कंटेनर
• शुद ृ और लचीली पैके!जंग सामDी (कागज बोड / एयूिमिनयम फॅायल/
पॉलीएिथलीन) आधा<रत ब?परतीय संरचना।

• कठोर

IलािFटक

कंटेनर

(जार)

िज9ह&

या

तो

उ|

घनNव

पोलीईथाईलीन (एचडीपीई) या IलािFटक पोिलोपाइलीन (पीपी)
साथ म& बाहर िनकाली ?ई संरचना का बना हो और उ| घनNव
पोलीईथाईलीन (एचडीपीई) का ढन बना हो।

• IलािFटक टटी के साथ IलािFटक आधा<रत संरचना से बने ?ए खडी
थैिलयां।

• लचीली IलािFटक थैिलयां िज9ह& या तो पीई या लेिमनेटेड संरचना से
बनाया गया हो।

• एयूमीिनयम प~ी/पीई आधा<रत ढन के साथ थमeफॉमHड IलािFटक
कंटे नर (बुलबले वाला पैक)।

• धातु के ढEकन के साथ IलािFटक जार (को-एEस}डेड)
• ओवररैप के साथ IलािFटक fे।
4.

िमठाईयां एवं क9फैEशनरी

• धातु कंटेनर के साथ IलािFटक पोिलोपाइलीन (पीपी) या धातु या
IलािFटक के ढEकन।

• IलािFटक आधा<रत ब?परतीय लेिमनेटेड गम करके ब9द क* गई
थैिलयां।

• IलािFटक / धातु के ढन के साथ कागज बोड या एयूमीिनयम प~ी
या IलािFटक आधा<रत फम से बने िमिWत कंटेनर।

• IलािFटक् आधा<रत कठोर कंटेनर।
• फॉईल रैप।
• IलािFटक
(पीईटी)

फम
या

आधा<रत

पोिलोपाइलीन

दोहरा

रै प(पोलीईथाईलीन

(पीपी)

या

पोलीवीनील

टेरेIथेलेट
Eलोराइड

(पीवीसी))

• ढEकन के साथ थमeफॉम fे
• धातु/IलािFटक के ढEकन के साथ कांच क* बोतल&।
• फम के ढEकन के साथ प्लािFटक के कप
5.

अनाज एवं अनाज उNपाद

• <टन के कंटेनर
• धातु के िड2ब म& एयूिमिनमय फॉयल आधा<रत थैिलयां।
• मोम क* परत वाले कागज से बने रैपर।
• तीन परतीय लैिमनेशन संरचना से बने रै पर।
• ब?परतीय IलािFटक आधा<रत लैिमनेटेड थैिलयां (गम करने सीलबंद
कया ?आ)।

• IलािFटक के ढEकन के साथ थमeफॉम के क9टेनर।

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

• ब? परतीय लेिमनेटेड संरचना से बने ?ए परत वाले िड2बे।
• IलािFटक आधा<रत ब?परतीय लेिमननेटेड संरचना वाले

िजपर

पाउच।

• IलािFटक के ढEकन/ओवर रैप के साथ थमeफॅाम क* fे।
• धातु के ढEकन के साथ कांच क* बोतल&।
6.

मांस और मांस उNपाद या कुEकुट

• IलािFटक

उNपादन

के

ढEकन

पोिलोपाइलीन

(पीपी)

या

उ|

घनNव

पोलीईथाईलीन (एचडीपीई) के साथ कांच के जार।

• धातु के ढन के साथ धातु कंटेनर (रोगन <टन कंटेनर)।
• कागज और कागज

बोड के िड2बे म&

IलािFटक आधा<रत लचीली

थैिलयां।

• IलािFटक आधा<रत ब?परतीय लचीली लेिमनेyस गम करके सीलबंद
क* ?ई थैिलयां।

• ओवर रै प के साथ IलािFटक fे।
• एयूिमिनमय फॉयल रै प।
7.

मछली और मछली उNपाद या समु^ी

• IलािFटक

खा

के

ढEकन

पोिलोपाइलीन

(पीपी)

या

उ|

घनNव

पोलीईथाईलीन (एचडीपीई) के साथ कांच के जार।

• धातु के ढEकन के साथ धातु के िड2बे (रोगन <टन के िड2बे)।
• IलािFटक के ढEकन के साथ पोलीईथाईलीन टेरेIथेलेट (पीईटी)
डिलया या कंटेनर।

• IलािFटक आधा<रत ब?परतीय लचीली लेिमनेट थैिलयां िज9ह& गम
करके सीलब9द कया जाता है।

• ओवर रै प के साथ IलािFटक fे।
8.

िमठास

कारक

िजसमे

शहद

भी

• धातु ढन या IलािFटक (पोिलोपाइलीन (पीपी) या उ| घनNव

शािमल है

पोलीईथाईलीन (एचडीपीई)) के साथ कांच के जार।

• IलािFटक के ढEकन के साथ कांच क* बोतल।
• फॉयल/पोलीिथलेन के ढक्कन के साथ बुल बुलेदार पैक।
• IलािFटक के ढEकन के साथ पोलीिथलेन टेरेफेथलेट (पीईटी) िड2बे।
• IलािFटक क* लेिमनेटेड निलका।
9.

नमक,

मसाले

और

अ9य

संबंिधत

• धातु ढन या IलािFटक (पोिलोपाइलीन (पीपी) या उ| घनNव

उNपाद।

पोलीईथाईलीन (एचडीपीई)) के साथ कांच के जार।

• IलािFटक

के

ढEकन

के

साथ

IलािFटक

पोलीिथलेन टेरेफेथलेट (पीईटी) और

आधा<रत

कठोर

िड2बे

उ| घनNव पोलीईथाईलीन

(एचडीपीई) कंटेनर।

•

कागज एवं कागज के बोड/ एयूमीिनयम फॉयल/

IलािFटक फम

आधा<रत िमिWत कंटे नर ।

• तह कये जा सकने वाले िड2बे िजनके अ9दर IलािFटक आधा<रत
लचीले लेिमनेटेड थैली रखी जाती हA। (िज9हे गम करके सीलब9द कया
जाता है)

• IलािFटक आधा<रत ब?परतीय लेिमनेटेड थैिलयां(िज9हे गम करके
सीलब9द कया जाता है)

<!-- page 11 -->

¹Hkkx IIIµ[k.M 4º
10.

Hkkjr dk jkti=k % vlk/kj.k

पेय पदाथ (डेयरी एवं फल एंव स2जी
आधा<रत पेय को छोडकर)।

11

• IलािFटक (पीपी) ढEकन के साथ IलािFटक क* बोतल& जो या तो पेट से
बनी ह या पॉलीकॉबeनेट (पीसी) से बनी ?ई ह।

• पोलीिथलीन (पीई) से बनी IलािFटक क* थैिलयां जो क गम करके
सीलब9द क* गई ह।

• IलािFटक/धातु के ढEकन के साथ कांच क* बोतल।
• पोलीिथलीन (पीई) से बनी IलािFटक क* थैिलयां जो

क नालीदार

फाईबर के िड2ब म& रखी जाती हA।

• ऊपर से आसानी से खुलने वाली <टन क* केन।
• <टन के िड2बे।
• लैिमनेटेड संरचाना से बनी IलािFटक् क* थैिलयां।
• शुद ृ और लचीली पैके!जंग सामDी (कागज बोड / एयूिमिनयम प~ी /
पॉलीथीन) आधा<रत ब?परतीय संरचना।

• गम करके सीलब9द क* ?ई IलािFटक आधा<रत ब? परतीय संरचना
थैिलयां।

• IलािFटक आधा<रत ब? Fतरीय संरचना वाली िजपर पाऊच थैिलयां/
खडी थैिलयां िज9ह& गम करके सीलब9द कया जाता है।

• धातु/IलािFटक के ढEकन के साथ धातु के िड2बे
• IलािFटक के ढEकन (पीपी ढEकन) के साथ कठोर IलािFटक के िड2बे।
• शराब के िलए लकडी का पीपा
पवन अDवाल, मु'य कायकारी अिधकारी

[िवापन-III/4/असा./456/18]

MINISTRY OF HEALTH AND FAMILY WELFARE
(FOOD SAFETY AND STANDARDS AUTHORITY OF INDIA)
NOTIFICATION
New Delhi, the 24th December , 2018
F.No. 1-95/Stds/Packaging/SP(L&C/A)/FSSAI-2017.—Whereas the draft of certain regulations, namely,
the Food Safety and Standards (Packaging) Regulations, 2018 vide notification number F.No. 195/Stds/Packaging/SP(L&C/A)/FSSAI-2017, dated the 19th March, 2018 was published as required under Sub-section
(1) of section 92 of Food Safety and Standards Act, 2006 (34 of 2006) in Gazette of India, Extraordinary, Part III, section
4, inviting objections and suggestions from the person likely to be affected thereby, before the expiry of a period of thirty
days from date on which the copies of Gazette containing the said notification was made available to the public;
And whereas, the Food Safety and Standards Authority of India made the Food Safety and Standards (Packaging
and Labelling) Regulations, 2011, but now the Food Authority has decided to divide these regulations into two
regulations,(i) the Food Safety and Standards (Packaging) Regulations, 2018; and
(ii) the Food Safety and Standards (Labelling and Display) Regulations, 2018,
And accordingly published the aforesaid draft regulations;
And whereas copies of the said Gazette were made available to the public on the 2nd April, 2018;
And whereas objections and suggestions received on the said draft regulations have been considered by the
Food Safety and Standards Authority of India;

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

Now, therefore, in exercise of the powers conferred by clause (k) of sub-section (2) of section 92, read with
section 23 of the Food Safety and Standards Act, 2006 (34 of 2006) and in supersession of the Food Safety and Standards
(Packaging and Labelling) Regulations, 2011, in so far as they relate to the packaging regulations, except as respects
things done or omitted to be done before such supersession, the Food Safety and Standards Authority of India hereby
makes the following regulations, namely:Regulations
1. Short Title and Commencement.- (1) These regulations may be called the Food Safety and Standards (Packaging)
Regulations, 2018.
(2) They shall come into force on the date of their publication in the Official Gazette and Food Business Operator shall
comply with all the provisions of these regulations by 1st July, 2019.
2. Definitions.- (1) In these regulations unless the context otherwise requires:(a)

“Act” means the Food Safety and Standards Act, 2006 (Act 34 of 2006);

(b)

“food grade” means material made of substances which are safe and suitable for their intended use,
and shall not endanger human health or result in unacceptable change in the composition of the food or
organoleptic characteristics;

(c)

“multilayer/composite food packaging” means a food packaging material composed of two or more
layers of same or different types of packaging materials specified under these regulations;

(d)

“overall migration limit” means the maximum permitted amount of non-volatile substances released
from a material or article into food simulants;

(e)

“package or container” means a pre-packaged box, bottle, casket, tin, barrel, case, pouch, receptacle,
sack, bag, wrapper or such other things in which an article of food is packed;

(f)

“packaging material” means materials such as cardboard, paper, glass, metal, plastic, multi-layer
packaging material used for packaging of food products;

(g)

“primary food packaging” means packaging material in direct contact with food products;

(h)

“secondary food packaging” means packaging material which encloses the primary food packaging
and does not come in direct contact with food products;

(i)

“specific migration limit” means the maximum permitted amount of a given substance released from a
material or article into food or food simulants.

(2) All other words and expressions used herein and not defined, but defined in the Act, rules or regulations
made thereunder, shall have the meanings assigned to them in the Act, rules or regulations, respectively.
3. General Requirements.- (1) Every food business operator shall ensure that the packaging material used shall be in
accordance with these regulations:
Provided where Indian Standards are not available, then relevant International Standards may be complied with.
(2) Any material which comes in direct contact with food or likely to come in contact with food used for packaging,
preparation, storing, wrapping, transportation and sale or service of food shall be of food grade quality.
(3) Packaging materials shall be suitable for the type of product, the conditions provided for storage and the equipment for
filling, sealing and packaging of food as well as transportation conditions.
(4) Packaging materials shall be able to withstand mechanical, chemical or thermal stresses encountered during normal
transportation. In case of flexible or semi-rigid containers, an overwrap packaging may be necessary.
(5) Food products shall be packed in clean, hygienic and tamper-proof package or container.

<!-- page 13 -->

¹Hkkx IIIµ[k.M 4º

Hkkjr dk jkti=k % vlk/kj.k

13

(6) The sealing material shall be compatible with the product and the containers as well as the closure systems used for
the containers.
(7) Tin containers once used, shall not be re-used for packaging of food.
(8) Plastic containers of capacity 5 litre and above and Glass bottles, which are reused for packaging of food, shall be
suitably durable, easy to clean or disinfect.
(9) Printing inks for use on food packages shall conform to IS: 15495.
(10) Printed surface of packaging material shall not come into direct contact with food products.
(11) Newspaper or any such material shall not be used for storing and wrapping of food.
(12) In case of multilayer packaging the layer which comes in direct contact with food or layers likely to come in contact
with food shall meet the requirements of packaging materials specified in Schedule I, II and III of these regulations.
(13) The materials listed in Schedule I, II and III of these regulations shall be compatible with their intended use as a
packaging material so as not to alter the quality and safety of the food product.
(14) Every food business operator shall obtain the certificate of conformity issued by NABL accredited laboratory
against these regulations for the packaging material which comes in direct contact with food or layers likely to come in
contact with food to be used.
4. Specific Requirements for Primary food packaging.- (1) Paper and board materials intended to come in contact
with food products(a) Paper and board material shall be of uniform formation, thickness and substance.
(b) It shall be free from visible specks, grease marks, cuts, pinholes and other

blemishes.

(c) The paper used for the manufacture of boxes, cartons, plates, cups and paper lids or paper which are meant to be
direct in contact with food shall be of food grade and shall be free from contaminants.
(d) Paper and board materials used for the manufacturing of containers for packing or storing the food products shall
conform to either of the Indian Standards specifications as provided in Schedule – I.

(2) Glass containers intended to come in contact with food products- (a) As far as possible, they shall be free from
blisters, mould marks, stones and chippings and as far as possible shall be free from cords, seeds and other visible
defects.
(b) They shall have a smooth surface without cracks, pinholes and sharp edges.
(c) The sealing surface shall be free from hairline cracks and prominent seam marks.
(3) Metal and Metal Alloys intended to come in contact with food products(a) A utensil or container made of the following materials or metals, when used in the preparation, packaging and storing
of food shall be deemed to render it unfit for human consumption:(i) containers which are rusty;
(ii) enamelled containers which have become chipped and rusty;

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

(iii) copper or brass containers which are not properly tinned.
(b) Appropriate grades of metal and metal alloys where applicable shall be used for packing or storing of food products.
(c) Metal and metal alloys used for the manufacturing of containers for packing or storing the food products shall conform
to either of the Indian Standards specifications as provided in Schedule – II.
(4) Plastic materials intended to come in contact with food products(a) Plastic materials used for the manufacturing of containers for packing or storing the food products shall conform to
either of the Indian Standards specifications as provided in Schedule – III:
Provided that Drinking Water (both Packaged and Mineral Water) shall be packed in colourless, transparent and
tamper-proof bottles or containers made of polyethylene (PE) conforming to IS: 10146 or polyvinyl chloride (PVC)
conforming to IS: 10151 or polyalkylene terephthalate (PET and PBT) conforming to IS: 12252 or polypropylene (PP)
conforming to IS: 10910 or food grade polycarbonate conforming to IS: 14971 or polystyrene conforming to IS: 10142 or
sterile glass bottles only. The transparency of a container shall not be less than 85 percent in light transmittance:
Provided also that all pigments or colorants as specified in Indian Standard IS: 9833 may be allowed in plastic
containers of five litre and above made of Polycarbonate and Polyethylene Terephthalate (PET) used for packaging of
mineral water and packaged drinking water. The transparency of such containers shall not be less than 85 percent in light
transmittance.
(b) All packaging materials of plastic origin shall pass the prescribed overall migration limit of 60mg/kg or 10mg/dm2
when tested as per IS 9845 with no visible colour migration.
(c) Plastic materials and articles shall not release the substances in quantities exceeding the specific migration limits listed
under Table 1.
(d) Pigments or Colorants for use in plastics in contact with food products and drinking water shall conform to IS: 9833.
(e) Products made of recycled plastics including carry bags shall not be used for packaging, storing, carrying or dispensing
articles of food.
Table 1
Requirement for specific migration limits of substances from plastic materials intended to be in contact with
articles of food
SI. No.

Substances

Maximum Migration Limit (mg/Kg)

1.

Barium

1.0

2.

Cobalt

0.05

3.

Copper

5.0

4.

Iron

48.0

<!-- page 15 -->

¹Hkkx IIIµ[k.M 4º

Hkkjr dk jkti=k % vlk/kj.k

15

5.

Lithium

0.6

6.

Manganese

0.6

7.

Zinc

25.0

5. A list of suggestive packaging materials which may be used for packaging of food products falling under the specified
categories is provided in Schedule – IV:
Provided that this is an indicative list not restricting the use of any other packaging material complying with the
specified standards.

Schedule – I
Paper and board materials intended to come in contact with food products
SI. No
1.
2.
3.
4.
5.
6.

List of Standards
Grease proof paper – IS 6622
Vegetable parchment or Grease proof paper or Aluminium Foil Laminate – IS 7161
Aluminium Foil Laminates for Packaging – IS 8970
General purpose packing or wrapping Paper – IS 6615
Folding Box Board, uncoated – IS 1776
Corrugated Fibre Board Boxes- Specification (Part 1) – IS 2771

Note: The wax used for coating the paper or board shall be paraffin wax conforming to Type I of IS 4654.

Schedule – II
Metal and Metal Alloys intended to come in contact with food products
SI. No

List of Standards

1.

Cold-reduced Electrolytic Tinplate – IS 1993/ISO 11949

2.

Cold reduced Electrolytic Chromium or Chromium Oxide – Coated Steel - IS 12591/ISO 11950

3.

Wrought Aluminium and Aluminium Alloy Sheet and Strip for General Engineering – IS 737

4.

Aluminium and Aluminium Alloy Bare Foil for Food Packaging – IS 15392

5.

Specification for Crown Closures – IS 1994

6.

Specification for Round Open Top Sanitary Cans for Foods and Drinks – IS 9396 (Part 1)

7.

Specification for Round Open Top Sanitary cans for Foods and Drinks – IS 9396 (Part 2)
Schedule – III
Plastic Materials intended to come in contact with food products

SI. No.

List of Standards

1.

Specification for Polyethylene for its safe use in contact with foodstuffs, pharmaceuticals and drinking water –
IS 10146

2.

Specification for Polystyrene for its safe use in contact with foodstuffs, pharmaceuticals and drinking water –
IS 10142

<!-- page 16 -->

16

THE GAZETTE OF INDIA : EXTRAORDINARY
3.

[PART III—SEC.4]

Specification for Polyvinyl Chloride (PVC) and its copolymers for its safe use in contact with foodstuffs,
pharmaceuticals and drinking water – IS 10151

4.

Specification for Polypropylene and its copolymers for its safe use in contact with foodstuffs, pharmaceuticals
and drinking water – IS 10910

5.

Specification for Ionomer Resins for its safe use in contact with foodstuffs, pharmaceuticals and drinking water
– IS 11434

6.

Specification for Ethylene Acrylic Acid (EAA) copolymers for their safe use in contact with foodstuffs,
pharmaceuticals and drinking water – IS 11704

7.

Specification for Polyalkylene Terephathalates (PET & PBT) for their safe use in contact with foodstuffs,
pharmaceuticals and drinking water - IS 12252

8.

Specification for Nylon 6 Polymer for its safe use in contact with foodstuffs, pharmaceuticals and drinking water
– IS 12247

9.

Specification for Ethylene Vinyl Acetate (EVA) copolymers for its safe use in contact with foodstuffs,
pharmaceuticals and drinking water – IS 13601

10.

Specification for Ethylene Metha Acrylic Acid (EMAA) copolymers and terpolymers for its safe use in contact
with foodstuffs, pharmaceuticals and drinking water – IS 13576

11.

Specification for Polycarbonate Resins for its safe use in contact with foodstuffs, pharmaceuticals and drinking
water – IS 14971

12.

Specification for Flexible Packaging Materials for packaging of Edible Oils, Ghee and Vanaspati - IS 14636

13.

Specification for Polyalkylene Terephthalates (PET & PBT) for Moulding and Extrusion – IS 13193

14.

Specification for Polyethylene Films and Sheets – IS 2508

15.

Specification for Linear Low Density Polyethylene (LLDPE) Films – IS 14500

16.

Specification for High Density Polyethylene Materials for Moulding and Extrusion – IS 7328

17.

Specification for Melamine-Formaldehyde Resins for its safe use in contact with foodstuffs,
pharmaceuticals and drinking water – IS 14999

18.

Low Density Polyethylene Films – IS 2508

19.

Blow Moulded Polyolefin Containers - Part 2 : Over 5 Litres, Up to and Including 60 Litres Capacity – IS
7408

20.

Stretch Cling Films – IS 14995

Schedule – IV
List of suggestive packaging materials

SI.No.
1.

Product Category
Milk and milk products

Types of Packaging materials
• Glass bottle with metal caps or plastic (polypropylene (PP) or Highdensity polyethylene (HDPE)) caps.
• Rigid Plastic container made of PET with plastic (polypropylene
(PP) or High-density polyethylene (HDPE)) caps.
• Rigid Plastic container made up of High density polyethylene
(HDPE) or Polypropylene (PP) or Polystyrene (PS) with Plastic (PP

<!-- page 17 -->

¹Hkkx IIIµ[k.M 4º

Hkkjr dk jkti=k % vlk/kj.k

17

or High-density polyethylene (HDPE) caps.
• Flexible plastic pouch made of polyethylene (PE) or Polypropylene
(PP) based co-extruded multilayered material.
• Aseptic and flexible packaging material (Paper board or Aluminium
foil or polyethylene) based multilayered structure.
• Tin plate container.
• Paper based lined cartons with liner made of aluminium foil based
laminated structure.
• Plastic based polypropylene (PP) or polystyrene (PS) cups with
paper or Peel-off lid.
• Wax coated paper butter wrappers.
• Paper and Paper Board based folding carton inside butter wrapped
with butter paper.
• Metal Containers with plastic polypropylene (PP) caps or metal or
plastic lid.
• Plastic pet container with plastic lid.
• Thermoform cup or tray with paper or peel-off lids.
• Paper and Paper Board setup boxes with or without lamination –
plastic film inside.
• Paper and Paper Board setup boxes with or without grease proof
paper placed inside.
• Plastic Based multi layered flexible laminated heat sealed pouch.
• Mud or clay pots.
• Thermoformed Plastic container (blister pack) with aluminium foil
or polyethylene (PE) based lid

2.

Fats, oils and fat emulsions

• Tin plate container.
• Glass bottle with metal caps or plastic polypropylene (PP) or Highdensity polyethylene (HDPE) caps.
• Plastic rigid container (jar) made of High-density polyethylene
(HDPE).
• Plastic bottle or Jar Polyethylene terephthalate (PET) with plastic
caps.
• Plastic Pouch made of Multi layered laminated or co-extruded
structure.
• Aseptic and flexible packaging material (Paper board or Aluminium
foil or polyethylene) based multilayered structure.
• Plastic laminated pouch in duplex board box (Bag in Box).

<!-- page 18 -->

18

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

• Thermoformed plastic based jar with plastic caps.
• Paper based lined cartons with liner made of aluminium foil based
laminated structure.
3.

Fruit & Vegetable products

• Glass bottle with metal caps or plastic ( polypropylene (PP) or Highdensity polyethylene (HDPE) caps.
• Aluminium can with easy open end.
• Tinplate container.
• Aseptic and flexible packaging material (Paper board or Aluminium
foil or polyethylene) based multilayered structure.
• Plastic

rigid

container

(jar)

made

of

either

High-density

polyethylene (HDPE) or Co-extruded structure with Plastic
(polypropylene (PP) or High-density polyethylene (HDPE) caps.
• Stand up Pouch made up of Plastic based structure with plastic
spout.
• Flexible Plastic pouch made of either polyethylene (PE) or
Laminated structure.
• Thermoformed Plastic container (blister Pack) with aluminium foil
or polyethylene (PE) based lid.
• Plastic jar (Co-extruded) with metal caps.
• Plastic trays with overwrap.
• Polyethylene terephthalate (PET) or polypropylene (PP) or Poly
Vinyl Chloride (PVC) Punnets
4.

Sweets and Confectionery

• Metal Containers with plastic polypropylene (PP) caps or metal or
plastic lid Plastic based multilayered laminated Heat sealed pouches.
• Composite containers made up of Paper Board or Aluminium foil or
plastic base films with plastic or metal lids.
• Plastic based rigid containers.
• Foil wrap.
• Plastic film based twist wraps ( Polyethylene terephthalate (PET) or
polypropylene (PP) or Poly Vinyl Chloride (PVC) ).
• Thermoformed tray and punnet with lid.
• Glass bottle with metal or plastic caps.
• Plastic cups with film lid.

5.

Cereals and cereal products

• Tin container.
• Aluminium Foil Based laminated pouch in metal container.
• Wrapper made of wax coated paper.
• Wrapper made of three layered laminated structure.
• Plastic based multilayered laminated pouch (heat sealed).
• Plastic based thermoform container with plastic lid.

<!-- page 19 -->

¹Hkkx IIIµ[k.M 4º

Hkkjr dk jkti=k % vlk/kj.k

19

• Lined carton with liner made of multi layered laminated structure.
• Plastic based multilayered laminated structured Zipper pouch.
• Thermoform trays with plastic lids or over wraps.
• Glass bottle with metal caps.
• Polyethylene terephthalate (PET) or Plastic based rigid containers
with metal or plastic ( polypropylene (PP) or

High-density

polyethylene (HDPE) caps
• Plastic films or co-extruded film or

polypropylene (PP) or

polyethylene (PE)
6.

Meat and Meat Products or Poultry
Products

• Glass jars with plastic ( polypropylene (PP) or

High-density

polyethylene (HDPE) caps.
• Metal Containers with metal lid (lacquered tin containers).
• Plastic based flexible pouches in paper & paper Board carton.
• Plastic based multilayered flexible laminates heat sealed pouches.
• Plastic tray with overwrap.
• Aluminium foil wrap.
• Polyethylene terephthalate (PET) punnets or containers with plastic
caps

7.

Fish and fish products or Seafood

• Glass jars with plastic (PP or High-density polyethylene (HDPE)
caps.
• Metal Containers with metal lid (lacquered tin containers).
• Polyethylene terephthalate (PET) punnets or containers with plastic
caps.
• Plastic based multilayered flexible laminates heat sealed pouches.
• Plastic tray with overwrap.

8.

Sweetening agents including Honey

• Glass bottle with Metal Caps or Plastic (polypropylene (PP) or
High-density polyethylene (HDPE) Caps.
• Plastic based Thermoformed container.
• Blister Pack with foil or polyethylene lid.
• Polyethylene Terephthalate (PET) container with Plastic Caps.
• Plastic laminated Tube.

9.

Salt,

spices,

related products

Condiments

and

• Glass bottle with metal lid or plastic (polypropylene (PP) or Highdensity polyethylene (HDPE) caps.
• Plastic based rigid container with Plastic cap ( Polyethylene
terephthalate (PET) and High-density polyethylene (HDPE)
Containers).
• Paper & Paper board or Aluminium foil or Plastic Film based
Composite Container.
• Folding cartons with Plastic based flexible laminated structure (heat

<!-- page 20 -->

20

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

sealed) pouch placed inside.
• Plastic based multilayered layered laminated pouch (heat sealed).
10.

Beverages (other than Dairy and
Fruits & vegetables based)

• Plastic bottles made of either Polyethylene terephthalate (PET) or
Polycarbonate (PC) with Plastic (Polypropylene (PP) or

High-

density polyethylene (HDPE) or Aluminium caps.
• Heat sealed Plastic pouches made of Polyethylene (PE).
• Glass bottles with metal caps or plastic caps.
• Plastic pouches made up of Polyethylene (PE) in Corrugated fibre
board Boxes.
• Aluminium can with easy open end.
• Tin plate container.
• Plastic pouch made of laminated structure.
• Aseptic and flexible packaging material (Paper board or Aluminium
foil or polyethylene) based multilayered structure.
• Plastic based multi layered structure heat sealed pouches.
• Plastic based multi layered structure heat sealed Zipper pouches or
stand up pouches.
• Metal Containers with plastic or Polypropylene (PP) caps or metal
or

plastic

lid,

Rigid

Plastic

container

with

plastic

caps

(Polypropylene (PP) Caps).
• Wooden cask (for wines).
PAWAN AGARWAL, Chief Executive Officer
[ADVT.-III/4/Exty./456/18]

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

ALOK
KUMAR

Digitally signed
by ALOK KUMAR
Date: 2019.01.01
15:43:22 +05'30'
