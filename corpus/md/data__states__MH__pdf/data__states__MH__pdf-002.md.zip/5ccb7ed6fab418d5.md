---
doc_id: "5ccb7ed6fab418d5"
source_url: "https://gpmumbai.ac.in/gpmweb/wp-content/uploads/2026/04/Corrigendum-1-EVEN-Term-25-26-Examination.pdf"
ministry: "Government Polytechnic, Mumbai, Maharashtra"
title: "Corrigendum - 1 EVEN Term 25-26 Examination"
date: ""
pages: 1
method: "tesseract:mar+hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "110dcb2049b9cca4"
---

<!-- page 1 -->

Sy, Government Polytechnic, Mumbai gin,
Go \\ (An Antonomous Inshtute of Govrtniment of Maharashtra) Gas
49, Kherwadi, AY June Marg, Banda (Fast), Mumbai. 00051 \,
९५०४ re OF
BY Website: www epmumbaracin Email epmumbai@epmumbai ३८10 2 4
सळ १ Email mncyal pramumba Qdenateukereer ==
Office Email: offce epmonib id dtemaharastera po in, peimeapmt@epmumba ac mn
GPM/10.09/ Odd Sem_Exam/2025-26/Conti-V7 755 Date: 07/07/2026 08) 04 J2O2E
Examination Cell - EVEN Sem 2025-26 Theory Exam Cell — EVEN Sem 2025-26 Theory Exam
Corrigendum-1
Reference: - EVEN Sem 2025-26 End Term Theory Exam Timetable तात. 02/04/2026
As per above reference, EVEN Sem 2025-26 End Term Theory Exam Timetable is displayed on 02/04/2026 for all schemes. In this exam timetable for P-23,
F-19 & P-I9R Scheme following changes must be noted by students, exam officer in-charge & all concern faculties and Sai
ee : Previous Exam Time Table Revised aoe Time Table
| 3 7 Session Program Course Code Course Title Date Session Remark
Scheme
21/04/2026 | Afternoon (2:00 pm | Computer ८०2310 |. oe Afternoon (2:00 | All concern students from
| P-23 Scheme to 4:30 pm) | Engineering (SP) Software Engineering | 27/04/2026 | Fo 4.30 pm) | CO Dept. must be noted |
eli ene a विदेश tdi errata
॥ | Morning (10:30 am ता 0023 107 Aft ec | 00 कण्या dents fi
2710472026 | to 1:00 em Computer ह. र fernoon (2: concern students from
poo eee ही pm) Engineering (SP) “omputer Networt 2104/2026 | जा to 4:30 pm) | CO Dept. must be noted
oe Momi 3
| वा लान त Cam | Computer CO 19 4047 | Network Management | Course Code Corrected a |
| Scheme Engineering (SP) | CO19R 404 | and Administration oes
| 05/05/2026 | Morning (10:30 am
letra 8 Computer IT 19 404/ ee
| P-19/19R to 1:00 ~ : gital Te le —e ०00 जनत
Bee 10 1:00 pm) Engineering (SP) | 11 19R 404 _ | Digital Techniques | Course Code Corrected * |
गणा N. NAThala)
Principal,
Government Polytechnic, Mumbai
