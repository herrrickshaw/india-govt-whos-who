---
doc_id: "7ca23ffebb89fe39"
source_url: "https://dhepune.gov.in/wp-content/uploads/1964/11/HTED-GR-20251006-Recruitment.pdf"
ministry: "Directorate of Higher Education, Maharashtra"
title: ""
date: ""
pages: 11
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4fcf69a7385e67dc"
---

<!-- page 1 -->

राज्यातील

सार्वजनिक

नर्द्यापीठामधील

(अकृनि) अध्यापकाांच्या भरती प्रक्रीयेमध्ये
अनधक

पारदर्वकता

आणण्यासाठी

कायवपध्दती नर्नित करण्याबाबत.
मिाराष्ट्र र्ासि
उच्च र् तांत्र नर्क्षण नर्भाग
र्ासि निणवय क्रमाांक : सांनकणव - 2025/ ई-860421/नर्नर्-1
मांत्रालय नर्स्तार भर्ि, मादाम कामा मागव,
िु तात्मा राजगुरु चौक,
मांत्रालय, मुांबई 400 032,
नदिाांक:- 6 ऑक्टोबर, 2025
र्ाचा:1. भारताचे राजपत्र: असाधारण, भाग III-नर्भाग 4, युजीसी िोनटनिकेर्ि नदिाांक 18 जुलै
2018.
2. उच्च र् तांत्र नर्क्षण नर्भाग, र्ासि निणवय, क्रमाांक सांकीणव-2018/प्र.क्र.56/18/नर्नर्-1,
नदिाांक 8 माचव 2019.
3. उच्च र् तांत्रनर्क्षण नर्भाग, र्ुद्धीपत्र क्रमाांक सांकीणव-2018/प्र.क्र.56/18/नर्नर्-1, नदिाांक 10
मे 2019.
4. उच्च आनण तांत्र नर्क्षण नर्भाग, र्ासि निणवय क्र.सांकीणव-2309/प्र.क्र.128/नर्नर्-1, नदिाांक 5
माचव, 2024.
5. मा. राज्यपाल याांचे अर्र सनचर् (नर्क्षण), राजभर्ि याांचे पत्र क्रमाांक आरबी/जीइएि2024/सीआर-928/इडीएि.5/182, नदिाांक 25 िेब्रुर्ारी,2025.
6. उच्च आनण तांत्र नर्क्षण नर्भाग, र्ासि निणवय क्र. सांकीणव 2025/प्र.क्र.ई-860421/नर्नर्-1,
नद. 28 िेब्रुर्ारी, 2025.
7. र्ासि पत्र नद. 07 जुलै, 2025 र् नद.31 जुलै,2025.
8. उप सनचर्, राजभर्ि याांचे पत्र क्र. आरबी/जीइएि-2024/सीआर 928/इडीएि-5/795,
नद.18 सप्टें बर, 2025
प्रस्तार्िा:उच्च नर्क्षण दे णाऱ्या सांस्थामधील अध्यापकाांकरीता नर्द्यापीठ अिुदाि आयोगाकडू ि र्ैक्षनणक
अिवता आनण अिुिांनगक बाबी नर्नित करण्यात येतात. नर्द्यापीठ अिुदाि आयोगाकडू ि नद. १८ जुलै,
२०१८ च्या अनधसूचिेद्वारे उच्च नर्क्षण दे णाऱ्या सांस्थाांकनरता “Minimum qualifications for
appointment of teachers and other academic staff in Universities and Colleges and

<!-- page 2 -->

Measures for the maintenance of standards in Higher Education” निनित करण्यात आली
आिेत. सदर अनधसुचिेतील तरतूदी उच्च र् तांत्र नर्क्षण नर्भागाच्या नद. ८ माचव, २०१९ च्या र्ासि
निणवयान्र्ये राज्यात लागू करण्यात आल्या आिेत. नद. 28.02.2025 च्या र्ासि निणवयान्र्ये
अध्यापकाांची निर्ड प्रनक्रया राबनर्ण्याबाबत कायवपद्धती नर्नित करण्यात आली आिे . सदर निर्ड
प्रक्रीया अनधक पारदर्वक, निष्ट्पक्ष आनण सांतुनलत व्िार्ी यासाठी मा.कुलपती तथा राज्यपाल
मिोदयाांच्या कायालयाकडू ि प्राप्त झालेले निदे र् नर्चारात घेऊि सुधारीत कायवपध्दती नर्नित
करण्याची बाब र्ासिाच्या नर्चाराधीि िोती.
र्ासि निणवय:राज्यातील सार्वजनिक नर्द्यापीठाांमधील (अकृनि) अध्यापकाांच्या निर्ड प्रक्रीयेसाठी र्ासि
निणवय नद. 28.02.2025 अन्र्ये नर्नित केलेल्या कायवपद्धतीत सुधारणा करुि सोबतच्या पनरनर्ष्ट्टअ मध्ये िमूद केलेली सुधारीत कायवपद्धती नर्नित करण्यात येत आिे .
२.

र्रील कायवपध्दतीिुसार राज्यातील सार्वजनिक नर्द्यापीठाांमधील (अकृनि) सध्या सुरू असलेली

अध्यापकाांची निर्डप्रनक्रया पूणव करण्यास याव्दारे मान्यता दे ण्यात येत आिे . तसेच भनर्ष्ट्यात िोणा-या
राज्यातील सार्वजनिक नर्द्यानपठाांमधील अध्यापकाांच्या निर्ड प्रनक्रयेकरता या कायवपध्दतीचा अर्लांब
करण्यात यार्ा.
३.

सदर र्ासि निणवय मिाराष्ट्र र्ासिाच्या www.maharashtra.gov.in या र्ेबसाईटर्र उपलब्ध

करण्यात आला असूि त्याचा सांकेताांक 202510061832268408 असा आिे . िा आदे र् नडजीटल
स्र्ाक्षरीिे साक्षाांनकत करुि काढण्यात येत आिे .
मिाराष्ट्राचे राज्यपाल याांच्या आदे र्ािुसार र् िार्ािे ,

PRATAP
PANDURANG LUBAL

Digitally signed by PRATAP PANDURANG LUBAL
DN: c=IN, o=GOVERNMENT OF MAHARASHTRA, ou=HIGHER AND
TECHNICAL EDUCATION DEPARTMENT,
2.5.4.20=b0d6763338fc6cc4f7cf07ca60db7abc1cfac99c84ab1b5bfc0
dae4609d631d0, postalCode=400032, st=Maharashtra,
serialNumber=AF6895C47A84066432F5BDD1F182B4163D880AC9B
D8D24A198FD0E7310BBEB59, cn=PRATAP PANDURANG LUBAL
Date: 2025.10.06 18:33:35 +05'30'

(प्रताप पाां. लुबाळ)
उप सनचर्, मिाराष्ट्र र्ासि
प्रनत,
1.

मा. राज्यपाल तथा कुलपती याांचे सनचर्, राजभर्ि, मलबार निल, मुांबई.

2.

मा. मुख्यमांत्री याांचे अपर मुख्य सनचर्, मांत्रालय, मुांबई.

3.

मा. उप मुख्यमांत्री (िगर नर्कास) याांचे सनचर्, मांत्रालय, मुांबई

4.

मा. उप मुख्यमांत्री (नर्त्त र् नियोजि) याांचे सनचर्, मांत्रालय, मुांबई

5.

मा. नर्रोधी पक्ष िेता, नर्धािसभा / नर्धािपनरिद.

6.

मा. मांत्री, उच्च र् तांत्रनर्क्षण याांचे खाजगी सनचर्, मांत्रालय, मुांबई.

<!-- page 3 -->

7.

मा. राज्यमांत्री, उच्च र् तांत्र नर्क्षण याांचे खाजगी सनचर्, मांत्रालय, मुांबई.

8. अपर मुख्य सनचर्, उच्च र् तांत्र नर्क्षण, मांत्रालय, मुांबई.
9.

सर्व सि सनचर् / उप सनचर्, उच्च र् तांत्र नर्क्षण नर्भाग, मांत्रालय, मुांबई.

10. सांचालक, उच्च नर्क्षण, मिाराष्ट्र राज्य, पुणे.
11. सर्व नर्भागीय सिसांचालक, उच्चनर्क्षण,
12. सर्व कुलसनचर्, सार्वजनिक नर्द्यापीठे .
13. कुलसनचर्, यर्र्ांतरार् चव्िाण मिाराष्ट्र मुक्त नर्द्यापीठ िानर्क.
14. कुलसनचर्, कनर् कुलगुरू कानलदास सांस्कृत नर्द्यापीठ, रामटे क.
15. सर्व कुलसनचर्, राज्य अनभमत नर्द्यापीठे .
16. सर्व कुलसनचर्, मिाराष्ट्र राष्ट्रीय नर्धी नर्द्यापीठे ,
17. कुलसनचर्, राज्य समुि नर्द्यापीठे .
18. निर्ड िस्ती (नर्नर्-1)

<!-- page 4 -->

पनरनर्ष्ट्ट-अ
( र्ासि निणवय क्र. सांनकणव - 2025/ ई-860421/नर्नर्-1, नद.06 ऑक्टोबर २०२५ सोबतचे सिपत्र )
Revised procedure for the Recruitment of Teachers in State Public Universities (NonAgricultural)
The following procedure is prepared to make the selection process more transparent,
objective and effective:
1. The weightage for the Academic, Teaching and Research Credentials (ATR) as 75%
Weightage and for the Interview Performance as 25% Weightage for preparing the Merit List of
Candidates.
2. The candidates scoring above 50 marks in the number ATR will be held as eligible for
interview. The universities will decide the ratio of the candidates to be called for interview per
vacant seat to be filled in for different cadres viz. Assistant Professors/ Associate Professors/
Professors.
3. Assistant Professor :Quantification of Academic, Teaching and Research Credentials of Candidates (75%
Weightage) will be as follows:A. Academic Records (Max. Marks 55)
The score and weightage for Academic Records of UG, PG, M. Phil. and Ph.D. will be
based on the type of Degree Awarding University. If the candidate has been awarded the Degree
by the Institutes of National Importance (IITs, NITs, IISER, IIM etc) or Foreign Universities
having Quacquarelli Symonds (QS)/ Times Higher Education (THE) / ARWU of the Shanghai
World University Rankings within 200, then highest marks shall be given. In case of
Central/State Public Universities (including State/ Central Deemed to be Universities) or
equivalent holding NIRF Rank within 100 or Foreign Universities having QS/ THE/ARWU of
the Shanghai World University Rankings between 200-500, the score shall be given as 90% of
the Maximum. For other Central/State Public Universities (including State/ Central Deemed to
be Universities) or equivalent, the score shall be given 80% of maximum. For rest of the UGC
approved Universities, the score to be given will be 60% of the maximum marks.
a. Score for Marks obtained at UG and PG Degree Examinations
i. Graduation (Max. Marks 11):
80% & above = 11 marks, 60% to less than 80% =09 marks, 55% to less than
60% =7 marks, 45% to less than 55%= 4 marks
ii. Post-graduation (Max. Marks 18):

<!-- page 5 -->

80% & above = 18 marks, 60% to less than 80%=16 marks, 55% (50% in case of
SC/ST/OBC- non-creamy layer)/PWD to less than 60% = 14 marks
b. Score for M.Phil. and Ph.D. (Max. Marks 20)
i. M.Phil.: 60% & above = 5 marks, 55% to less than 60% = 03 marks
ii. Ph.D.: 20 marks
M.Phil.+ Ph. D. = maximum 20 marks
c. Score for JRF/NET/SET (Max. Marks 6)
NET with JRF: 06 marks; NET: 04 marks; SET: 03 marks
JRF/NET/SET = maximum 06 marks
B. Teaching Experience (Max. Marks 5):
Scores for approved teaching experience (as approved by the University /Parent body) /
Postdoctoral experience in Institutes of National Importance or from foreign Universities within
top 500 QS/ THE/ARWU of the Shanghai World University Rankings shall be 1 mark per year.
However, if the period of teaching/Post-doctoral experience is less than one year then the marks
shall be reduced proportionately.
C. Assessment of Research Aptitude and Innovation Skills (Max. Marks 15)
a. Research Publications (Max. Marks: 6)
In case of award of Marks under Research Publications, only Indexed Journal lists
of SciFinder, Web of Science and Scopus shall be considered. Score for Research
Publications enlisted under SciFinder, Web of Science or Scopus databases shall be 1 per
Research Paper for single author Publications. In case of Multiple Authors, the principal
author (first author or author for correspondence) shall get 50% Marks and for all other
authors, rest of the 50% marks shall be distributed proportionally. No score shall be given
to other publications.
b. Books Authored/ IPR generated (Max. 6 Marks)
i. Total Number of books and chapters in edited volumes published by Reputed
(National/ International) Publisher (with ISBN):
2 marks per authored reference book. 1 Mark per Edited Book/ chapters in edited
volume/ Translated Book.
ii. IPR (Patents / Copyright/ Trademarks/ Designs etc.) granted/ awarded
2 marks per IPR granted Books Authored+ IPR generated: Max. 6 Marks
c. Awards (Max. 3 Marks):
International/National Level (Awards given by International Organizations/
Government of India/Government of India recognized National Level Bodies): 03
State Level (Awards given by State Government): 02
International/National/ State Level Awards: Max. 3 Marks
Thus the overall weightage of Academic, Teaching and Research Credentials for the
position of Assistant Professor (through 3- A to C) shall be 75%.

<!-- page 6 -->

4.

Associate Professor :Quantification of Academic, Teaching and Research Credentials of Candidates for the
position of Associate Professor (75% Weightage)
A. Academic Records (Max. Marks 45)
The Max. Score under Academic Records for UG, PG, M. Phil. and Ph.D. should be
graded as per the type of Degree Awarding University. If the candidate has been awarded the
Degree by the Institutes of National Importance (IITs, NITs, IISER, IIM etc) or Foreign
Universities having Quacquarelli Symonds (QS)/ Times Higher Education (THE) / ARWU of the
Shanghai World University Rankings within 200, then highest marks shall be given. In case of
Central/State Public Universities (including State/ Central Deemed to be Universities) or
equivalent holding NIRF Rank within 100 or Foreign Universities having QS/ THE/ARWU of
the Shanghai World University Rankings between 200-500, the score shall be given as 90% of
the Maximum. For other Central/State Public Universities (including State/ Central Deemed to
be Universities) or equivalent, the score shall be given 80% of Maximum. For rest of the UGC
approved Universities, the score shall be allotted to 60% of the highest marks.
a. Score for Marks obtained at UG and PG Degree Examinations
i. Graduation (Max. Marks 8):
80% & above = 08 marks, 60% to less than 80% =06 marks, 55% to less than
60% =05 marks, 45% to less than 55%= 03 marks
ii. Post-graduation (Max. Marks 15):
80% & above = 15 marks, 60% to less than 80%=13 marks, 55% (50% in case of
SC/ST/OBC- non-creamy layer)/PWD to less than 60% = 11 marks
b. Score for M.Phil. and Ph.D. (Max. Marks 18)
i. M.Phil.: 60% & above = 04 marks, 55% to less than 60% = 03 marks
ii. Ph.D.: 18 marks
M.Phil.+ Ph. D. = maximum 18 marks
c. Score for JRF/NET/SET (Max. Marks 4)
NET with JRF: 04 marks; NET: 03 marks; SET: 02 marks
JRF/NET/SET = maximum 04 marks
B. Teaching Experience (Max. Marks 5):
The additional experience in years over and above the minimum years of approved
experience (as approved by the University /Parent body and minimum years specified/ prescribed
for the position of Associate Professor) of teaching and / or research in an academic/ research
position equivalent to that of Assistant Professor in a University, College or Accredited Research
Institution/Industry, shall be used for the calculation of Score for the Teaching Experience. The
Score for additional approved experience shall be 1 mark per year.

<!-- page 7 -->

C. Assessment of Research Aptitude and Innovation Skills (Max. Marks 25)
a. Research Publications (Max. Marks: 6)
In case of award of Marks under Research Publications, only Indexed Journal lists of
SciFinder, Web of Science and Scopus shall be considered. Score for Research
Publications enlisted under SciFinder, Web of Science or Scopus databases shall be 1 per
Research Paper for single author Publications. In case of Multiple Authors, the principal
author (first author or author for correspondence) shall get 50% Marks and for all other
authors, rest of the 50% marks shall be distributed proportionally. No score shall be given
to other publications.
The additional number of research publications, over and above minimum research
publications specified/ prescribed for Associate Professor, shall be considered for the
calculations of Publication Score.
b. Books Authored/MOOCs developed/ IPR generated (Max. 8 Marks)
i. Total Number of books and chapters in edited volumes published by
Reputed (National/ International) Publisher (with ISBN):- 2 marks per
authored reference book 1 Mark per Edited Book/ chapters in edited volume/
Translated Book
ii. Development of MOOCs for SWAYAM, SWAYAM plus, NPTEL,
महाज्ञानदीप :-2 marks per MOOC developed
iii. IPR (Patents / Copyright/ Trademarks/ Designs etc.) granted/ awarded:-2
marks per IPR granted Books Authored+/MOOCs developed+ IPR generated:
Max. 8 Marks
c. Awards (Max. 3 Marks):
International/National Level (Awards given by International Organizations/
Government of India/Government of India recognized National Level Bodies): 03
State Level (Awards given by State Government): 02
International/National/ State Level Awards: Max. 3 Marks
d. Ph.D. Guidance (No of Ph. D.s awarded under his/ her supervision as Guide)
(Max. 3 Marks):- 1 mark per Ph.D. award
e. Cumulative Funds generated through R & D Projects sanctioned as PI by
different Government Funding Agencies and Consultancy through Industrial/
Professional Projects (Max. 5 Mark)
INR upto 2 lakh = 1/2 mark
>INR 2 lakh and <= INR 5 lakhs = 1
mark
>INR 5 lakhs and <=INR 10 lakhs = 2
mark
>INR 10 lakhs and < =INR 25 lakhs = 3 marks
>INR 25 lakhs and <=INR 50 lakhs = 4 marks
>INR 50 lakhs = 5 marks

<!-- page 8 -->

Thus the overall weightage of Academic, Teaching and Research Credentials (through 4A to C) for the position of Associate Professor shall be 75%.
5. Professor :Quantification of Academic, Teaching and Research Credentials of Candidates for the
position of Professor (75% Weightage)
A. Academic Records (Max. Marks 40)
The Max. Score under Academic Records for UG, PG, M. Phil. and Ph.D. should be
graded as per the type of Degree Awarding University. If the candidate has been awarded the
Degree by the Institutes of National Importance (IITs, NITs, IISER, IIM etc) or Foreign
Universities having Quacquarelli Symonds (QS)/ Times Higher Education (THE) / ARWU of the
Shanghai World University Rankings within 200, then highest marks shall be given. In case of
Central/State Public Universities (including State/ Central Deemed to be Universities) or
equivalent holding NIRF Rank within 100 or Foreign Universities having QS/ THE/ARWU of
the Shanghai World University Rankings between 200-500, the score shall be given as 90% of
the Maximum. For other Central/State Public Universities (including State/ Central Deemed to
be Universities) or equivalent, the score shall be given 80% of Maximum. For rest of the UGC
approved Universities, the score shall be allotted to 60% of the highest marks.
a. Score for Marks obtained at UG and PG Degree Examinations
i. Graduation (Max. Marks 7):
80% & above = 07 marks, 60% to less than 80% =05 marks, 55% to less than
60% =04 marks, 45% to less than 55%= 02 marks
ii. Post-graduation (Max. Marks 13):
80% & above = 13 marks, 60% to less than 80%=11 marks, 55% (50% in case of
SC/ST/OBC- non-creamy layer)/PWD to less than 60% = 9 marks
b. Score for M.Phil. and Ph.D. (Max. Marks 17)
i. M.Phil.: 60% & above = 04 marks, 55% to less than 60% = 03 marks
ii. Ph.D.: 17 marks
M.Phil.+ Ph. D. = maximum 17 marks
c. Score for JRF/NET/SET (Max. Marks 3)
NET with JRF: 03 marks; NET: 02 marks; SET: 01 marks
JRF/NET/SET = maximum 03 marks
B. Teaching Experience (Max. Marks 5):
The additional experience in years over and above the minimum years of approved
experience (as approved by the University /Parent body and minimum years specified/ prescribed
for the position of Professor) of teaching in university/college as Assistant Professor/Associate
Professor/Professor, and / or research experience at equivalent level at the University/National

<!-- page 9 -->

Level Institutions, shall be used for the calculation of Score for the Teaching Experience. The
Score for additional approved experience shall be 1 mark per year.
C. Assessment of Research Aptitude and Innovation Skills (Max. Marks 30)
a. Research Publications (Max. Marks: 6)
In case of award of Marks under Research Publications, only Indexed Journal lists of
SciFinder, Web of Science and Scopus shall be considered. Score for Research
Publications enlisted under SciFinder, Web of Science or Scopus databases shall be 1 per
Research Paper for single author Publications. In case of Multiple Authors, the principal
author (first author or author for correspondence) shall get 50% Marks and for all other
authors, rest of the 50% marks shall be distributed proportionally. No score shall be given
to other publications.
The additional number of research publications, over and above minimum research
publications specified/ prescribed for Professor, shall be considered for the calculations
of Publication Score.
b. Books Authored/MOOCs developed/ IPR generated (Max. 8 Marks)
i. Total Number of books and chapters in edited volumes published by
Reputed (National/ International) Publisher (with ISBN):
2 marks per authored reference book. 1 Mark per Edited Book/ chapters in
edited volume/ Translated Book
ii. Development of MOOCs for SWAYAM, SWAYAM plus, NPTEL,
MahaDNYANDEEP:2 marks per MOOC developed
iii. IPR (Patents / Copyright/ Trademarks/ Designs etc.) granted/ awarded:2 marks per IPR granted Books Authored+MOOCs developed+ IPR generated:
Max. 8 Marks
c. Awards (Max. 5 Marks):
International/National Level (Awards given by International Organizations/
Government of India/Government of India recognized National Level Bodies): 03
State Level (Awards given by State Government): 02
International/National/ State Level Awards: Max. 3 Marks
d. Ph.D. Guidance (No of Ph. D.s awarded under his/ her supervision as Guide)
(Max. 5 Marks)
1 mark per Ph.D. award

<!-- page 10 -->

e. Cumulative Funds generated through R & D Projects sanctioned as PI by
different Government Funding Agencies and Consultancy through Industrial/
Professional Projects (Max. 6 Mark)
INR upto 5 lakh = 1/2 mark
>INR 5 lakhs and <=INR 10 lakhs = 1 mark
>INR 10 lakhs and < =INR 25 lakhs = 2 marks
>INR 25 lakhs and <=INR 50 lakhs = 3 marks
>INR 50 lakhs and 75<=INR lakhs = 4 marks
> INR 75 lakhs to < =INR 1 Crore : 5
marks
> INR 1 Crore : 6 marks
Thus the overall weightage of Academic, Teaching and Research Credentials for the
position of Professor (through 5-A to C) shall be 75%.
6.

Interview:Assessment of Shortlisted Candidates through Interview (25% weightage) for Assistant
Professors/ Associate Professors/ Professors
The Marking Scheme for the distribution of Scores for different heads of Interview Performance
may be based on following parameters:i. Depth of Domain Subject knowledge and understanding of recent developments in the
field (15 marks)
ii. Language Proficiency and ICT Skills for use of modern Teaching-Learning Aids (5
marks)
iii. Logical reasoning and Future Plan (Teaching, Research and Extension) (3 marks)
iv. Assessment of Outreach/ Extension and Co-curricular Activities and Knowledge of
NEP Policy of Shortlisted Candidates (2 marks)
Assessment of first two parameters shall be based on the presentation made by the
candidate at the time of interview.
The distribution different heads of Interview Performance is illustrative and individual
University may decide the distribution of Marking as per their requirements.
The average score awarded by all selection committee members must be used to finalize
the interview scores.
Strict confidentiality of the proceedings of the Interview shall be observed. Video
Recording of the proceedings of the Selection Committee meeting shall be carried and the same
shall be sealed with the signatures of all Committee Members present immediately after the
process is complete. Such record shall be treated as confidential and shall be made available only
if required by the court of law.
7.

Preparation of the Merit List:The merit list shall be prepared based on the combined score of Academic, Teaching and
Research Credentials (75% Weightage) and Interview (25% weightage) [Thus total out of 100].

<!-- page 11 -->

The Final Results of the Entire Selection Process shall be announced within a minimum of week
after the completion of the entire Cadre-wise Interview Process for Assistant Professors/
Associate Professors/ Professors.
*********
