---
doc_id: "acb1babf5f3bbd86"
source_url: "https://mahadgm.gov.in/PDF/Mahadgmrules1/MineralConservationandDevelopmentRules2017.pdf"
ministry: "Director General, Geology and Mining, Nagpur, Maharashtra"
title: "View"
date: ""
pages: 151
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "11baef0cb308b960"
---

<!-- page 1 -->

<!-- page 2 -->

Government of India
Ministry of Mines

MINERAL CONSERVATION AND
DEVELOPMENT RULES, 2017
(Amended up to 27th March, 2018)

Issued by
CONTROLLER GENERAL
INDIAN BUREAU OF MINES
NAGPUR

January, 2019

<!-- page 3 -->

<!-- page 4 -->

CONTENTS
Rule
No.

Page

CHAPTER – I
Preliminary
1.
2.
3.

4.
5.
6.
7.
8.
9.

Short title and commencement
Application
Definitions

1
1
1

CHAPTER – II
Reconnaissance and Prospecting Operations
Scheme of reconnaissance or prospecting
Modification of scheme reconnaissance or prospecting
Reconnaissance or Prospecting operations to be carried out in
accordance with scheme of reconnaissance or prospecting
Intimation about reconnaissance and prospecting operations
Inspection
Reports to be submitted by holder of a reconnaissance permit or prospecting license or
prospecting license cum mining lease or any other authorized agency

4
4
4
4
5
5

CHAPTER – III
Mining Operations
10.
11.
12.
13.
14
15.
16
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29.
30

Competent Authority
Mining operations under mining lease
Prospecting and mining operations
Opencast working
Separate stacking of non-salable minerals
Underground mining operations
Sub-grade minerals to be brought to surface
Prohibition of reduction of blocks
Beneficiation studies to be carried out
Machinery and plant
Notice for opening of mine
Abandonment of mines
Mine Closure Plan
Submission of progressive Mine Closure Plan
Submission of final mine closure plan
The modification of mine closure plan
Responsibility of the holder of mining lease
Financial assurance
Notice of temporary discontinuance of work in mines and obligations of lease holders
Intimation of reopening of a mine
Stoping of vein, etc.

6
6
7
9
9
10
10
10
10
11
11
12
12
13
13
13
13
13
15
15
15

<!-- page 5 -->

31.
32.
33.
34.

CHAPTER – IV
Plans and Sections
General requirements about plans and sections
Types of plans and sections
Copies of plans and sections to be submitted
Preparation of plans

16
17
20
20

CHAPTER – V
Sustainable Mining
35.
36.
37.
38.
39.
40.
41.
42.
43.
44.

Sustainable mining
Removal and utilization of top soil
Storage of overburden, waste rock, etc.
Precaution against ground vibration
Control of surface subsidence
Precaution against air pollution
Discharge of toxic liquid
Precaution against noise
Permissible limits and standards
Restoration of flora

20
21
21
22
22
22
22
22
22
22

CHAPTER – VI
Notice and Returns
45.
46.
47.
48.
49.
50.
51.
52.
53.
54.

Monthly and annual returns
Notice of certain appointments
Notice of shaft sinking and bore holes
Records of shafts and boreholes
Change in the name of mine to be notified
Notice of transfer of prospecting licence cum mining lease or mining lease
Notice of amalgamation of mining lease
Transfer of records to transferees
Copies of notices or returns and reports to be submitted to the State Government
Copies of notices and returns and reports to be maintained

23
27
28
28
28
28
28
29
29
29

55.
56.
57.

CHAPTER – VII
Employment of Geologists and Mining Engineers
Employment of geologist and mining engineer
Duties of geologist
Duties of mining engineer

30
31
32

58.
59.
60.

CHAPTER – VIII
Examination of minerals and Issue of Directives
Power to issue directions
Examination of mineral deposits and taking of samples
Prohibition of deployment in certain cases

33
34
34

<!-- page 6 -->

CHAPTER – IX
Revision and Penalty
61.
62.

Revision
Penalty

34
36

CHAPTER – X
Miscellaneous
63.
64.
65.
66.
67.
68.
69.
70.
71.

Preservation of cores, etc.
Facilities of undertaking research or training
Submission of records or reports regarding research in geology and mining
Territorial jurisdiction of Controller of Mines and Regional Controller
Obligation to supply other information
Provision of these rules to be applicable to Central Government and State Government
Exercise powers
Saving of Act 33 of 1962
Review of format and manuals

36
37
37
38
38
38
38
38
38

CHAPTER – XI
Geological Reports
72.

Geological reports

39

CHAPTER-XII
Mining Regulation Portal
73.
74.
75.

Mining regulation web portal
Recording of regulatory functions
Information source

40
40
40

<!-- page 7 -->

SCHEDULE
Form-A---------------------------------------------------------------------------------------------------------- 41
Form-B------------------------------------------------------------------------------------------------------------ 43
Form-C------------------------------------------------------------------------------------------------------------ 46
Form-D------------------------------------------------------------------------------------------------------------ 48
Form-E------------------------------------------------------------------------------------------------------------ 51
Form-F----------------------------------------------------------------------------------------------------------- 53
Form-F1---------------------------------------------------------------------------------------------------------- 56
Form-F2---------------------------------------------------------------------------------------------------------- 64
Form-F3---------------------------------------------------------------------------------------------------------- 70
Form-G1---------------------------------------------------------------------------------------------------------- 75
Form-G2---------------------------------------------------------------------------------------------------------- 89
Form-G3---------------------------------------------------------------------------------------------------------- 101
Form-H------------------------------------------------------------------------------------------------------------ 111
Form-I------------------------------------------------------------------------------------------------------------- 113
Form-J------------------------------------------------------------------------------------------------------------- 115
Form-K------------------------------------------------------------------------------------------------------------ 117
Form-L------------------------------------------------------------------------------------------------------------ 126
Form-M----------------------------------------------------------------------------------------------------------- 132
Form-N------------------------------------------------------------------------------------------------------------ 141
GUIDELINES FOR SUBMISSION OF RETURNS

167

GUIDELINES UNDER MCDR FOR UNITED NATIONS
FRAMEWORK CLASSIFICATION OF MINERAL
RESERVES/RESOURCES

169

<!-- page 8 -->

GOVERNMENT OF INDIA
MINISTRY OF MINES

New Delhi, the 27th February, 2017

NOTIFICATION

G.S.R. 169(E)—In exercise of the powers conferred by section 18 of the Mines and
Minerals (Regulation and Development) Act, 1957 (67 of 1957), and in supersession of the
Mineral Conservation and Development Rules, 1988, except as respects things done or
omitted to be done before such supersession, the Central Government hereby makes the
following rules, namely:- Mineral Conservation and Development Rules, 2017.

<!-- page 9 -->

<!-- page 10 -->

CHAPTER I
Preliminary
1. Short title and commencement.-(1) These rules may be called the Mineral
Conservation and Development Rules, 2017.
(2) These rules shall come into force on the date of their publication in the Official
Gazette.
2. Applicability.- These rules shall apply to all minerals, except –
(i) petroleum and natural gas;
(ii) coal, lignite and sand for stowing; and
(iii) minor minerals:
Provided that the State Government may by notification extend the
application of any of the provisions of these rules, with such modification as may
be deemed necessary and appropriate, to minor minerals:
Provided further that the powers and responsibilities to be exercised by the
Central Government or the Indian Bureau of Mines in respect of minerals other
than minor minerals shall be exercisable by the State Government or State
Directorate of Mining and Geology (by whatever named called) or any other
authority subordinate to the State Government as may be notified by the State
Government while extending the application of these rules to minor minerals.
3. Definitions.– (1) In these rules, unless the context otherwise requires,–

(a) “abandonment of mine” means the final closure of a mine, either whole or part
thereof, when the mineral deposits within the mine or part thereof have been
fully extracted or when the mining operations thereon have become
uneconomic;
(b) “Act” means the Mines and Minerals (Development and Regulation) Act,
1957 (67 of 1957);
(c) “authorised officer” means– (i) an officer of the Indian Bureau of Mines duly
authorised in writing by the Controller General, Indian Bureau of Mines; or
(ii) an officer authorised in this behalf by the State Government to perform the
functions under these rules; or (iii) an officer of the Atomic Minerals
Directorate for Exploration and Research authorised in writing by the
Director, Atomic Minerals Directorate for Exploration and Research, to
perform the functions under these rules in respect of minerals specified in Part
B of the First Schedule to the Act where the grade of such atomic minerals is
1

<!-- page 11 -->

equal to or above the threshold value limits declared under Schedule-A of the
Atomic Minerals Concession Rules, 2016;
(d) “beneficiation” means processing of minerals or ores for the purpose of
upgrading the quality, purity or assay grade of the desired product by
removing unwanted constituents like gangue minerals or tailings;
(e) “calibrated lump ore” means the sized ore that is obtained after screening or
crushing of the run-of-mine ore;
(f) “Chief Controller of Mines” means the Chief Controller of Mines of the
Indian Bureau of Mines;
(g) “competent authority” means the competent authority referred to in rule 10;
(h) “Controller General” means the Controller General of the Indian Bureau of
Mines;
(i) “Controller of Mines” means the Controller of Mines of the Indian Bureau of
Mines;
(j) “cores” means the samples of sub-surface rocks or mineralised zone obtained
during drilling of boreholes;
(k) “development” means the driving of an opening to or in an ore-body or seam
or removing overburden or unproductive or waste materials as preparatory to
mining or stoping;
(l) “environment” and “environmental pollution” shall have the same meanings
as assigned respectively to them in the Environment (Protection) Act, 1986
(29 of 1986);
(m) “final mine closure plan” means a plan for the purpose of decommissioning,
reclamation and rehabilitation of a mine or part thereof after cessation of
mining and mineral processing operations, that has been prepared in the
manner specified in the standard format and guidelines issued by the Indian
Bureau of Mines or the Director, Atomic Minerals Directorate for Exploration
and Research in respect of minerals specified in Part B of the First Schedule to
the Act where the grade of such atomic minerals is equal to or above the
threshold value limits declared under Schedule-A of the Atomic Minerals
Concession Rules, 2016;
(n) “final mine closure” means steps taken for reclamation and rehabilitation of a
mine or part thereof commencing from cessation of mining or processing
operations in a mine or part thereof;

2

<!-- page 12 -->

(o) “financial assurance” means the security or guarantee furnished by the holder
of a mining lease in accordance with rule 27;
(p) “Form” means a Form set forth in the Schedule;
(q) “geologist” means a person appointed by the holder of a mineral concession to
perform the duties of a geologist under these rules;
(r) “mining engineer” means a person appointed by the holder of a mineral
concession to perform the duties of a mining engineer under these rules;
(s) “mineral rejects” include all the excavated materials that do not constitute
useful material, which may be rejected either on the basis of grade or size;
(t) “progressive mine closure plan” means a progressive plan for the purpose of
providing protective, reclamation and rehabilitation measures in a mine or
part thereof that has been prepared in the manner specified in the standard
format and guidelines issued by Indian Bureau of Mines or the Director,
Atomic Minerals Directorate for Exploration and Research in respect of
minerals specified in Part B of the First Schedule to the Act where the grade
of such atomic minerals is equal to or above the threshold value limits
declared under Schedule-A of the Atomic Minerals Concession Rules, 2016,
from time to time;
(u) “Regional Controller” means the Regional Controller of Mines of the Indian
Bureau of Mines;
(v) “schedule” means the schedule annexed to these rules;
(w) “section” means a section of the Act;
(x) “shaft” means a vertical or inclined way or opening leading from the surface
to workings below ground or from one part of the workings below ground to
another and includes an incline;
(y) “stoping” means making any underground excavation other than development
working made for the purpose of winning ores or minerals and includes
extraction or splitting or reduction of pillars or blocks of minerals;
(z) “temporary discontinuance” means the planned or unplanned suspension of
mining operations in a mine or part thereof and where the operations are likely
to be resumed not earlier than one hundred and twenty days; and
(za) “year” means the twelve months period beginning from the first day of April
and ending on the thirty-first day of March of the following year.
(2) Words and expressions used but not defined herein shall have the same meaning
as assigned to them in the Act or the rules made thereunder.
3

<!-- page 13 -->

CHAPTER II
Reconnaissance and Prospecting Operations

4. Scheme of reconnaissance or prospecting.–(1) Every holder of a reconnaissance
permit or prospecting licence or prospecting license-cum-mining lease, shall submit to
the Controller General and Regional Controller or the authorised officer a scheme of
reconnaissance or prospecting, as the case may, within a period of sixty days from the
date of execution of the permit or licence, indicating the manner in which he proposes
to carry out the reconnaissance or prospecting operations in the area covered under the
permit or licence.
(2)The scheme of reconnaissance or prospecting shall be prepared in the format as may
be specified by the Indian Bureau of Mines from time to time:
Provided that in respect of minerals specified in Part B of the First Schedule to the
Act where the grade of such atomic minerals is equal to or above the threshold value
limits declared under Schedule-A of the Atomic Minerals Concession Rules, 2016, the
scheme of reconnaissance or prospecting shall be prepared in the format as may be
specified by the Director, Atomic Minerals Directorate for Exploration and Research.
5. Modification of scheme of reconnaissance or prospecting.– (1) A scheme of
reconnaissance or prospecting prepared and submitted under rule 4 may be modified at
any time on geological considerations by the holder of a reconnaissance permit or
prospecting licence or prospecting license-cum-mining lease or as directed by the
Controller General and Regional Controller or the authorised officer, as the case may
be,during continuance of the reconnaissance or prospecting operations.

(2) Any modification carried out under sub-rule (1) shall be intimated to the
Controller General and Regional Controller or the authorised officer, as the case may
be,by the holder of a reconnaissance permit or prospecting licence or prospecting
license-cum-mining lease within a period of thirty days of carrying out such
modification.
6. Reconnaissance or prospecting operations to be carried out in accordance
with scheme of reconnaissance or prospecting.– Every holder of a reconnaissance
permit or prospecting licence or prospecting license-cum - mining lease shall carry out
the reconnaissance or prospecting operations in accordance with the scheme submitted
under rule 4 or with such modifications, if any, as provided under rule 5 or as directed
by the the Controller General and Regional Controller or the authorised officer.
7. Intimation about reconnaissance and prospecting operations. – Every holder
of a reconnaissance permit or prospecting licence or prospecting license-cum-mining
lease shall send to the Regional Controller or authorised officer and the State
Government, an intimation in Form A of the Schedule about the commencement of
4

<!-- page 14 -->

reconnaissance or prospecting operations, as the case may be, so as to reach them
within a period of fifteen days of such commencement.
8. Inspection.–(1) The holder of a prospecting license or prospecting license-cummining lease shall allow any authorised officer to examine at any time, the accounts
maintained by him and shall furnish to the authorised officer, such information and
returns as the authorised officer may require.
(2) The holder of a prospecting license or prospecting license-cum-mining lease shall
also allow any authorised officer to inspect any prospecting operations carried on by
him including the core logs and samples generated during the prospecting operations.
9. Reports to be submitted by holder of a reconnaissance permit or prospecting
license or prospecting license cum mining lease or any other authorised agency.–
(1) Every holder of a reconnaissance permit or prospecting licence or prospecting
license-cum-mining lease shall submit to the Regional Controller or the authorised
officer, as the case may be, and to the State Government, a yearly report along with
Form B of the Schedule so as to reach him within forty-five days after the expiry of
twelve months from the date of execution of the relevant prospecting licence deed or
the expiry of the prospecting licence or prospecting license-cum-mining lease,
whichever is earlier.
(2) The format of the reporting under sub-rule (1) shall be specified by the Indian
Bureau of Mines:
Provided that in respect of minerals specified in Part B of the First Schedule to the
Act where the grade of such atomic minerals is equal to or above the threshold value
limits declared under Schedule-A of the Atomic Minerals Concession Rules, 2016, the
format of reporting shall be specified by the Director, Atomic Minerals Directorate for
Exploration and Research.
(3) Every agency authorised under the second proviso to sub-section (1) of section 4
shall submit to the State Government and the authorised officer, as the case may be, a
yearly report in Form B of the Schedule so as to reach him within forty-five days after
the expiry of twelve months from the date of commencement of prospecting operations
by such agency.
(4) In case the prospecting operations are abandoned, the report along with Form B of
the Schedule shall be submitted within a period of thirty days from the date of such
abandonment.
(5). The authorised officer, upon receipt of a request made by the holder of a
prospecting licence or prospecting licence-cum-mining lease in this regard, shall keep
the specified portions of the geological report or data confidential for a period of two
years from the date of expiry of the mineral concession, or abandonment of operations
or termination of the mineral concession, whichever is earlier.

5

<!-- page 15 -->

CHAPTER III
Mining Operations
10. Competent Authority.– (1) The Controller General or an officer of Indian Bureau
of Mines authorised in writing by the Controller General shall be the competent
authority to take decisions with respect to a mining plan approved by any officer of the
Indian Bureau of Mines, pursuant to clause (b) of sub-section (2) of section 5.
(2) The State Government shall be the competent authority to approve a mining plan
required for grant of a mining lease, prepared and certified in accordance with the
system established by the State Government pursuant to the proviso to clause (b) of
sub-section (2) of section 5 and approved by the Central Government:
Provided that the Controller General or an officer of Indian Bureau of Mines
authorised in writing by the Controller General shall be the competent authority to take
decisions with respect to monitoring and implementation of such mining plans
approved by the State Government.
(3) The Director, Atomic Minerals Directorate for Exploration and Research or an
officer of the Atomic Minerals Directorate for Exploration and Research authorised in
writing by the Director, Atomic Minerals Directorate for Exploration and Research
shall be the competent authority to take decisions with respect to a mining plan
pursuant to clause (b) of sub-section (2) of section 5, in respect of minerals specified in
Part B of the First Schedule to the Act, where the grade of such atomic minerals is
equal to or above the threshold value limits declared under Schedule-A of the Atomic
Minerals Concession Rules, 2016.
11. Mining operations under mining lease.– (1) No holder of a mining lease shall
commence or carry out mining operations in any area except in accordance with the
mining plan approved, modified or reviewed by the Indian Bureau of Mines or
prepared and certified in accordance with the system established by the State
Government pursuant to the proviso to clause (b) of sub-section (2) of section 5 or
approved by the competent authority of the Atomic Minerals Directorate for
Exploration and Research, in respect of minerals specified in Part B of the First
Schedule to the Act where the grade of such atomic minerals is equal to or above the
threshold value limits declared under Schedule-A of the Atomic Minerals Concession
Rules, 2016.
(2) If the mining operations are not carried out in accordance with the approved or
certified mining plan or any information contained in the mining plan is found to be
incorrect, misleading or non-compliant with applicable laws including these rules, the
competent authority may by order, suspend all or any of the mining operations and
permit continuance of only such operations as are required to restore the conditions in
the mine as envisaged under the approved or certified mining plan or modified mining
plan, for the purpose of restoration to the extent possible:
Provided that the lessee shall be informed in writing about the violation and if the
violation is not rectified within a period of forty-five days, a show cause notice shall be
6

<!-- page 16 -->

issued asking reasons why the mining operations should not be suspended and, further,
if no satisfactory reply is received within a period of thirty days, the mining operations
shall be suspended:
Provided further that the competent authority may revoke the suspension after
compliance by rectifying the violation pointed out in this regard.
(3) Every approved mining plan shall be subjected to review and updation in every
five years as per provision of sub-rule (1) of rule 17 of the Minerals (Other than
Atomic and Hydro Carbon Energy Minerals) Concession Rules, 2016:
Provided that the review and updation of the approved mining plan every five
years shall be as per the norms as specified by the Atomic Minerals Directorate for
Exploration and Research, in respect of minerals specified in Part B of the First
Schedule to the Act, where the grade of such atomic minerals is below the threshold
value limits declared under Schedule-A of the Atomic Minerals Concession Rules,
2016.
(4) The holder of a mining lease shall submit the mining plan to the competent
authority for review at least one hundred and eighty days before the expiry of five
years period for which it was approved on the last occasion, for mining operations for
a period of five subsequent years.

12. Prospecting and mining operations.–(1) The prospecting and mining operations
shall be carried out in such a manner so as to ensure systematic development of
mineral deposits, conservation of minerals and protection of the environment.
(2) The prospecting licence or prospecting licence-cum-mining lease holder shall carry
out exploration as per the norms provided in the Minerals (Evidence of Mineral
Contents) Rules, 2015:
Provided that the exploration norms shall be specified by the Atomic Minerals
Directorate for Exploration and Research, in respect of minerals specified in Part B of
the First Schedule to the Act.
(3)The holder of a mining lease shall carry out detailed exploration (G1 level) over the
entire potentially mineralised area under the mining lease, within a period of five years
from the date of opening of the mine after execution of such mining lease.
(4) In the case of existing mining leases detailed exploration (G1 level) over the entire
potentially mineralised area under the mining lease shall be carried out within a period
of five years from the date of commencement of these rules.
1

[(4A) In case of mining leases covered under sub-section (6) of section 8A of the Act
where the date of expiry of the period of such lease is on 31st March, 2020, the holders
1 Inserted by G.S.R.289(E) dated 27th March, 2018

7

<!-- page 17 -->

of such mining lease shall carry out General Exploration (G2) over the entire
mineralised area under the mining lease before the 1st day of April, 2019 and for this
purpose,–
(a) submit to State Government and the Indian Bureau of Mines, within forty five days
of issue of this notification, a modified mining plan in accordance with the provisions
of the Minerals (Other than Atomic and Hydro Carbons Energy Minerals) Concession
Rules, 2016 for completion of General Exploration (G2) over the entire mineralised
area under the mining lease as required under clause (a) of rule 5 of the Minerals
(Evidence of Mineral Contents) Rules, 2015, in such manner that the plan for
exploration is completed before 1st April, 2019, and such plan shall be approved by the
Indian Bureau of Mines within thirty days of its submission, with or without any
modification;
(b) prepare and submit to the State Government and the Indian Bureau of Mines, a
Geological Study Report as required under clause (b) of rule 5 of the Minerals
(Evidence of Mineral Contents) Rules, 2015, within one month after completion of
exploration work:
Provided that the depth of exploration to be proposed in the modified mining
plan for open cast mining shall be up to 300 meters or up to discontinuance of ore
body, whichever is earlier, and in case of underground mines, the depth of exploration
shall be decided by the Indian Bureau of Mines on case to case basis at the time of
approval of such plan, depending upon the geological set up of the area:
Provided further that the State government shall conduct periodical technical audit
of approved modified plan either by itself or through an agency nominated by it and in
case lease holder fails to perform his duties as so specified, the State Government may,
after giving the lease holder an opportunity of being heard, take such action for
enforcing compliance, as it deems fit.]
(5) The sampling of drill cores or chips, pit samples and trench samples shall be done
for the entire mineralised portion at regular intervals, preferably meter wise or less, and
chemical analysis for the major radical shall be done for all the samples.
(6) Mineral resources shall be estimated periodically based on exploration carried out
and the resources shall be estimated up to the threshold value of the mineral, as may be
notified by Indian Bureau of Mines, from time to time and the updated resources shall
be furnished in the Review of the Mining Plan at the interval of five years.
(7) Indian Bureau of Mines shall review the threshold values of minerals periodically
in consultation with the stake holders.

8

<!-- page 18 -->

13. Open cast working. – (1) In open cast workings, the benches formed shall be so
arranged that the benches in ore or mineral and overburden are separate so as to avoid
mixing of waste with the ore or minerals.
(2) The benches in overburden shall be kept sufficiently in advance so that their
workings do not interfere with the working of ore or minerals.
(3) Orientation of the workings and sequence of mining operations shall be such that
different grades of ore or minerals can be obtained simultaneously for blending with a
view to achieve optimum recovery of ore or minerals from the deposit.

14. Separate stacking of non-saleable minerals.– (1) All the non-saleable or unusable minerals or ores above the threshold value of the mineral, as may be notified by
Indian Bureau of Mines from time to time, or otherwise shall be stacked separately on
the ground earmarked for the purpose:
Provided that in case of beach sand mineral deposits comprising of Ilmenite,
Rutile, Zircon, Monazite, Sillimanite, Garnet, Leucoxene, etc., sufficient precautions
shall be taken to separate and stack the waste sand or tailings from the associated
minerals in order to avoid mixing of waste sand with the associated minerals.
(2) The mineral or ore stock above the limit specified in the threshold values of
minerals or otherwise, shall be properly maintained indicating the quantity and quality
of all such material stacked, and the month-wise inventory of such materials shall be
updated:
Provided that in respect of minerals specified in Part B of the First Schedule to the
Act, the mineral or ore stock, irrespective of the grade of such atomic minerals whether
it is above or below the threshold value limits declared under Schedule-A of the
Atomic Minerals Concession Rules, 2016 shall be properly maintained indicating the
quantity and grade of all such material stacked, and the month-wise inventory of such
materials shall be updated and sent to the Atomic Minerals Directorate for Exploration
and Research and the Indian Bureau of Mines and the concerned State Government.
Provided further that the lessee shall be required to maintain a month-wise
inventory of the accurate material quantity of monazite and other prescribed substances
extracted, starting from run of mine to stock yard, which shall be furnished to the
Atomic Minerals Directorate for Exploration and Research and the Indian Bureau of
Mines and the State Government on a monthly basis.
(3) The overburden and waste material obtained during mining operations shall not be
allowed to be mixed with the materials as specified in sub-rule (1).
(4) The ground selected for dumping of overburden, waste material, the sub-grade or
non-saleable ores or minerals shall be proved for absence or presence of underlying
mineral deposits before it is brought into use for dumping.
9

<!-- page 19 -->

15. Underground mining operations.–(1) Underground mining operations shall be
carried out in such a way so as to achieve optimum ore or mineral recovery.
(2) The method of underground development of the deposit shall be planned in
accordance with the method of stoping, which shall be selected with due consideration
of the geology of the deposit and geo-technical properties of the ore and the adjoining
rocks.
(3) The size of development openings, size of blocks and pillars shall be such that the
workings remain stable during the development and stoping stages and between such
stages.
(4) The stoping practices shall be such as to cause minimum disturbance to the
surface.
(5) In case of a doubt as to the optimum ore or mineral recovery under sub-rule (1) or
the method of underground development under sub-rule (2), or size of openings,
blocks or pillars under sub-rule (3) or the stoping practices under sub-rule (4), it shall
be referred to the Chief Controller of Mines for decision.
(6) The Chief Controller of Mines may order such investigations and tests to be
carried out as are considered necessary before arriving at a decision on any matter
referred to him under sub-rule (5).
(7) As far as practicable the complete width of the ore or mineral body shall be
worked:
Provided that the Chief Controller of Mines may permit in writing, leaving of
certain portions in underground if it is necessary for support or protection to the mine
workings.
16. Sub-grade minerals to be brought to surface.-(1) All the sub-grade ore or
minerals wherever obtained from underground workings shall be brought to the surface
instead of leaving or packing them underground, which shall be stacked separately at
the earmarked place.
17. Prohibition of reduction of blocks.-All the blocks formed in underground
workings shall be regular in size and shape and once a block is formed, it shall not be
split or reduced in size until the stage of commencement of stoping:
Provided that the Chief Controller of Mines may permit reduction in the size of
blocks on an application in writing made by the holder of the mining lease giving
reasons for doing the same.
18. Beneficiation studies to be carried out.-(1) If the Controller General or an
authorised officer of the Atomic Minerals Directorate for Exploration and Research, as
the case may be, having due regard to the nature of mining operations and grade of ore
10

<!-- page 20 -->

or mineral is of the view that the sub-grade ore or mineral contains certain recoverable
product, he may direct the holder of the mining lease to get the beneficiation
investigations carried out from a laboratory accredited by National Accreditation
Board for Testing and Calibration or an International Organization for Standardization
laboratory approved by the Indian Bureau of Mines or the Atomic Minerals Directorate
for Exploration and Research.
(2) The report of the beneficiation investigations so carried out under sub-rule (1)
shall be submitted to the Controller General or an authorised officer of the Atomic
Minerals Directorate for Exploration and Research, as the case may be, immediately
after the investigation is over.
(3) In a mine having a beneficiation plant, feed products and tailings shall be regularly
sampled and analysed at suitable intervals and records of the same maintained:
Provided that the Controller General or an authorised officer of the Atomic
Minerals Directorate for Exploration and Research, as the case may be, may require
the sampling and analysis to be done at any other interval than in practice from a
laboratory accredited by National Accreditation Board for Testing and Calibration or
an International Organization for Standardization laboratory approved by the Indian
Bureau of Mines or the Atomic Minerals Directorate for Exploration and Research:
(4) The Controller General or an authorised officer of the Atomic Minerals Directorate
for Exploration and Research, as the case may be, may carryout periodic process audit
of the beneficiation plants to assess the possibility of further improvements in the
beneficiation process.
19. Machinery and plant.-(1) Where heavy earth moving machinery is used in
mines, the holder of a mining lease shall maintain log books duly authenticated by the
manager or mining engineer of such mines in respect of each machine showing datewise account of hours worked, hours not worked, reasons for non-working,
consumption of fuel or energy and lubricants and output of the machine during the
corresponding working hours.
(2) The summary of operation of each machine shall be recorded in the log book at the
end of each month bringing out the percentage availability and percentage utilisation
of the machine, average hourly performance and average fuel or energy consumption
per hour.
(3) The log books may be maintained in electronic form or in hard copy and shall be
made available to the authorised officer on demand.
20. Notice for opening of mine.- (1) The holder of a mining lease shall send to the
authorised officer, as the case may be, an intimation in Form C of the Schedule of the
opening of a mine so as to reach them within fifteen days of such opening, which shall
be accompanied with a copy of the approved mining plan, in case the mine is being
opened after a lapse of five years period from the date of approval of the mining plan.
11

<!-- page 21 -->

21. Abandonment of mines.-(1) The holder of a mining lease shall not abandon a
mine during the subsistence of the lease except with the prior permission in writing of
the authorised officer, as the case may be.
(2) The holder of a mining lease shall send to the authorised officer, as the case may
be, a notice in Form D of the Schedule of his intention to abandon a mine so as to
reach them at least ninety days before the intended date of such abandonment, which
shall be accompanied by plans and sections on a scale as specified in rule 31 setting
forth accurately the work done in the mine up to the time of submission of the notice
including the measures envisaged for the protection of the abandoned mine or part
thereof, the approaches thereto and the environment:
Provided that the authorised officer, as the case may be, may require the plans and
sections to be prepared on any other suitable scale.
(3) The authorised officer, as the case may be, may by an order in writing made
before the proposed date of abandonment, prohibit abandonment or allow it to be done
with such conditions as he may specify in the order.
(4) The holder of a mining lease shall not abandon a mine unless a final mine closure
plan duly approved by the competent authority, is implemented, and for this purpose,
the lessee shall be required to obtain a certificate from the authorised officer, as the
case may be, to the effect that protective, reclamation and rehabilitation work in
accordance with the final mine closure plan or with such modifications as approved by
the competent authority have been carried out before abandonment of mine.
(5) The holder of a mining lease shall continue to be liable to provide the financial
assurance and pay for any expenditure over and above the performance security
incurred by the State Government towards protective reclamation and rehabilitation
measures in the leased area of the mining lease.

22. Mine Closure Plan.- (1) Every mine shall have mine closure plans, which shall be
of two types; namely:–
(i) a progressive mine closure plan; and
(ii) a final mine closure plan.
(2) Every holder of a mining lease shall take steps to prepare mine closure plans as
per the guidelines and format given by the Indian Bureau of Mines from time to time:
Provided that where the State Government has set up a system for preparation,
certification and monitoring of mining plan pursuant to the proviso to clause (b) of
sub-section (2) of section 5, such guidelines and formats shall be prescribed by the
State Government:
Provided further that in respect of minerals specified in Part B of the First
Schedule to the Act, where the grade of such atomic minerals is equal to or above the
threshold value limits declared under Schedule-A of the Atomic Minerals Concession
Rules, 2016, such guidelines and formats shall be prepared in the format as may be
12

<!-- page 22 -->

specified by the Director, Atomic Minerals Directorate for Exploration and Research.

23. Submission of progressive mine closure plan.-The holder of a mining lease shall
submit to the competent authority a progressive mine closure plan as a component of
the mining plan, at the time of submission, modification and review of the mining plan.
24. Submission of final mine closure plan.-(1) The holder of a mining lease shall
submit a final mine closure plan to the competent authority for approval two years
prior to the proposed closure of the mine.
(2) The competent authority shall convey his approval or refusal of the final mine
closure plan within ninety days of the date of its receipt to the holder of the mining
lease.
25. The modification of mine closure plan.–(1) The holder of a mining lease
desirous of seeking modifications in the approved mine closure plan, shall submit to
the competent authority for approval setting forth the intended modifications and
explaining the reasons for such modifications.
(2) The competent authority may approve the modifications as submitted under clause
(1), or approve with such alterations as he may consider expedient.

26. Responsibility of holder of a mining lease.- (1) The holder of a mining lease
shall have the responsibility to ensure that the protective measures including
reclamation and rehabilitation works have been carried out in accordance with the
approved mine closure plan or with such modifications as approved by the competent
authority.
(2) The holder of mining lease shall submit to the competent authority a yearly report
as per the format specified by the Indian Bureau of Mines, before 1 stday of July every
year setting forth the extent of protective and rehabilitative works carried out as
envisaged in the approved mine closure plan, and if there is any deviation, reasons
thereof:
Provided that where the State Government has set up a system for preparation,
certification and monitoring of mining plan pursuant to the proviso to clause (b) of
sub-section (2) of section 5, such format shall be prescribed by the State Government:
Provided further that in respect of minerals specified in Part B of the First
Schedule to the Act where the grade of such atomic minerals is equal to or above the
threshold value limits declared under Schedule-A of the Atomic Minerals Concession
Rules, 2016, such format shall be prescribed by the Director, Atomic Minerals
Directorate for Exploration and Research.
27. Financial assurance.–(1) A financial assurance shall be furnished by the holder of
the mining lease, for due and proper implementation of the progressive mine closure
13

<!-- page 23 -->

plan contained in the mining plan or the final mine closure plan, as the case may be,
which shall be an amount of three lakh rupees for Category ‘A’ mines and two lakh
rupees for Category ‘B’ mines, per hectare of the mining lease area put to use for
mining and allied activities:
Provided that the minimum amount of financial assurance to be furnished under
sub-rule (1), shall be ten lakh rupees for Category ‘A’ mines and five lakh rupees for
Category ‘B’ mines:
Provided further that the provisions of sub-rule (1) shall not be applicable for a
mining lease granted through the auction or the mining lease granted under the
provisions of clause (b) or clause (c) of sub-section (2) of section 10A, wherein the
Mine Development and Production Agreement has been signed between the lessee and
the State Government.
(2) Where financial assurance is required to be furnished by the holder of the mining
lease under sub-rule (1), such amount of financial assurance shall be submitted to the
authorised officer, as the case may be, in the form of a bank guarantee in the format
specified by the Indian Bureau of Mines:
Provided that where financial assurance has already been furnished before the
commencement of these rules, an amount equal to the difference between the financial
assurance due as on the date of notification of these rules and the financial assurance
already furnished, shall be furnished to the authorised officer, as the case may be,
within a period of ninety days from the date of notification of these rules:
Provided further that the holder of a mining lease shall be required to enhance the
amount of financial assurance with the increase in the area of mining and allied
activities:
Provided also that where a leaseholder undertakes reclamation and rehabilitation
measures as part of the progressive closure of mine, the amount so spent shall be
reckoned as sum of the financial assurance already spent by the leaseholder and the
total amount of financial assurance, to be furnished by the lessee, shall be reduced to
that extent.
(3) Release of financial assurance shall be effective upon the notice given by the lessee
for the satisfactory compliance of the provisions contained in the final mine closure
plan and certified by the authorised officer, as the case may be.
(4) If the authorised officer, as the case may be, has reasonable grounds for believing
that the protective, reclamation and rehabilitation measures as envisaged in the
progressive mine closure plan contained in the approved mining plan or the final mine
closure plan, in respect of which financial assurance was furnished, has not been or
will not be carried out in accordance with the mining plan or the final mine closure
plan, either fully or partially, the authorised officer, as the case may be, shall give the
lessee a written notice of his intention to issue the orders for forfeiting the sum assured
atleast thirty days prior to the date of the order to be issued.

14

<!-- page 24 -->

(5) Within thirty days of the receipt of notice referred to in sub-rule (4), if no
satisfactory reply has been received in writing from the lessee, the authorised officer,
as the case may be, shall pass an order for forfeiting the surety amount and a copy of
such order shall be endorsed to the concerned State Government.
(6) Upon the issuance of order by the authorised officer, as the case may be, the
concerned State Government may realize the bank guarantee provided or obtained as
financial assurance for the purpose of performance of protective, reclamation,
rehabilitation measures and shall carry out those measures, or appoint an agent to do
so.
28. Notice of temporary discontinuance of work in mines and obligations of lease
holders.–(1) Subject to the provisions of section 4A, the holder of a mining lease shall
send to the authorised officer, as the case may be, and the State Government a notice in
Form E when the mining or mineral processing operations in the mine or part thereof
are discontinued for a period exceeding ninety days so as to reach them within one
hundred and twenty days from the date of such temporary discontinuance.
(2) Where the discontinuance takes place as a result of the occurrence of a natural
calamity beyond the control of the holder of a mining lease or in compliance with any
order or directions issued by any statutory authority established under any law in force
or any tribunal or a court, a notice shall be submitted to the authorised officer, as the
case may be,within a period of fifteen days of such discontinuance in Form-E.
(3) During the temporary discontinuation of a mine or part thereof, it shall be the
responsibility of the holder of a mining lease to–
(a) comply with the reasonable prohibitive measures to restrict access for
unauthorised entry;
(b) provide protective measures to potentially danger sources of electrical and
mechanical installations, and the mine openings or workings and all other
structures;
(c) ensure that all contaminated effluents are controlled and all physical, chemical,
biological monitoring programmes are continued;
(d) ensure that all rock piles, over burden piles and stock piles and tailings, and
other water impoundment structure are maintained in stable and safe conditions.
29. Intimation of reopening of a mine.–The holder of a mining lease shall send to
the authorised officer, as the case may be, and the State Government an intimation in
Form C of the Schedule of reopening of a mine after temporary discontinuance, so as
to reach them within fifteen days from the date of such reopening.
30. Stoping of vein, etc.– (1) No stoping shall be commenced, conducted or carried
out except with prior permission in writing of the competent authority.
(2) The holder of a mining lease shall send to the authorised officer, as the case may
be, and the State Government a notice in Form F of the Schedule intimating his
intention to commence the stoping of any vein, lode, reef or mineral deposit, so as to
reach them at least sixty days before the date of commencement of such operations.
15

<!-- page 25 -->

(3) Such notice shall be accompanied by plans and sections on a scale of not less than
1 cm = 10 meters showing the details of the block proposed to be stoped, the manner
of stoping and the mineralised and barren zones indicating estimated percentages
recovery from stopes:
Provided that the authorised officer, as the case may be, by an order in writing and
subject to such conditions as he may specify therein, permit or require the plans and
sections to be prepared on any other suitable scale.
(4) The authorised officer, as the case may be, may by an order made before the
proposed date of commencement of stoping operations, prohibit the stoping or allow it
to be done under such conditions as may be specified in such order.
CHAPTER IV
Plans and Sections
31. General requirements about plans and sections.- (1) Every plan or section
prepared or submitted in accordance with the provisions of these rules shall(a) show the name of the mine and of the holder of the mining lease and the purpose
for which the plan or section is prepared;
(b) show the true north or the magnetic meridian and the date of the letter;
(c) show a scale of the plan at least twenty-five centimeters long and suitably subdivided;
(d) unless otherwise provided, be on a scale having a representative factor of –
(i) 1:500 in case of mines having small-scale workings;
(ii) 1:2000 in case of mines having large open cast working and also in case
of surface plans of large leasehold areas; and
(iii) 1:1000 in other cases:
Provided that the competent authority may, by an order in writing and
subject to such conditions as he may specify therein, permit or require the plans to
be prepared on any other suitable scale;
(e) be digitally prepared in the format as may be specified by the Indian Bureau of
Mines.
(2) The conventions provided under the Metalliferous Mines Regulations, 1961, shall
be used in preparing all plans and sections required under these rules.
(3) The plans and sections shall be accurate within such limits of error as the
Controller General may specify by a general or special order.
16

<!-- page 26 -->

(4) The plans and sections required under these rules shall be maintained up to date
within three months in case of category ‘A’ mines as referred to in clause (a) of subrule (2) of rule 55, and within twelve months in the case of any other mine.
32. Types of plans and sections.- (1) The holder of a mining lease shall keep the
following digitally prepared plans and sections, namely:–
(a) a surface plan showing location and number of the boundary pillars along with its
latitude and longitude values, every surface feature within the mining lease
boundaries, such as building, telephone, power transmission line, water pipeline,
tramline, railway, road, river, water-course, reservoir, tank, bore-hole, shaft and
incline opening, opencast working, dumps and dumping ground, the waste land,
forest, sanctuaries, agricultural land and grazing land and subsidence on the
surface beneficiation plants, tailing ponds and other workings within the lease;
(b) a surface geological plan of the area of leasehold showing-

(i) all the lithological units exposed in the area, in the pits, trenches and in any
other openings made for prospecting and mining operations showing contact
between lithological units;
(ii) structural details like strike, dip, fold, fault, plunge of ore body;
(iii) location of prospecting pits, trenches, boreholes and any other openings made
for prospecting or mining operations;
(iv) existing mine workings, dumps, stacks of ore;
(v) section lines at regular intervals from one boundary to the other of the lease;
(vi) contour at not more than ten metres interval;
(vii) exploration limits such as G1, G2, G3 and G4 as per the United Nations
Framework Classification;
(c) a transverse section or sections of the workings through the shaft or shafts and
main adits indicating clearly the strike and dip of the vein, lode, reef, mineral bed
or deposit at different points, and such sections of the strata sunk or driven through
in the mine or proved by boreholes, as may be available;
(d) a longitudinal mine section or sections showing a vertical projection of the mine
workings including outlines of all stoped out areas, where a reef, vein, lode or
mineral bed or deposit or part thereof has dip exceeding thirty degrees from the
horizontal plane:
Provided that, with the permission in writing of the competent authority and
17

<!-- page 27 -->

subject to such conditions as he may specify therein, such sections may be prepared in
relation to any other suitable plane;
(e) an underground plan, applicable for underground mines, showing (i) the position of the workings of the mine below ground;
(ii) every borehole and shaft (with depth), drive, cross-cut, winze, raise,
excavation (stoped ground) and every tunnel and air passage connected
therewith;
(iii) every pillar or block of mineral left for the support of any structure on the
surface; and underground magazines, if any;
(iv) the general strike of the veins, lodes, reefs and mineral beds or deposits;
(v) the position of every dyke, fault and other geological disturbance with the
amount and direction of throw.
(2) Whenever the underground plan referred to in clause (e) of sub-rule (1) is brought
up-to-date, the then position of the workings shall be shown by a dotted line drawn
through the ends of the workings, and such dotted line shall be marked with the date of
the last survey:
Provided that the competent authority may, by an order in writing and subject to
such conditions as he may specify therein, approve any other method of showing the
up-to-date position of the workings of the mine.
(3) Where different reefs, lodes, veins or mineral beds or deposits overlie or run
parallel to one another, the workings of each reef, lode, vein or mineral bed or deposit
shall be shown on separate plan or longitudinal section or sections:
Provided that if two reefs, lodes, veins or mineral beds or deposits are so situated
in relation to each other that the parting between workings made therein is less than ten
meters at any place, such workings shall also be shown on a combined plan or
longitudinal section, as the case may be, in different colours.
(4) The plans kept under clauses (a) and (e) of sub-rule (1) shall also show the settled
boundary of the mining lease, or where the boundary is in dispute, the boundaries
claimed by the holder of the mining lease and by the holders of the mining lease
adjacent to the disputed boundary:
Provided that where it is not possible to show the complete boundary of leasehold
on the same plan an additional key plan on any other suitable scale showing such
boundaries and the outline of the workings shall also be maintained.
(5) The holder of a mining lease shall keep the following, namely:–

18

<!-- page 28 -->

(a) a key plan on a scale of 1: 50,000 incorporating the following:
i. an administrative surface map showing the boundary of the mining lease,
and the adjoining area lying preferably within five kilometres thereof;
ii. contours at not more than twenty meters intervals;
iii. natural drainage system such as rivers, streams, nalahs, water reservoirs,
ponds, lakes, irrigation dams and canals;
iv. roadways and railways;
v. places of historical and archaeological importance, monuments, places of
worship, pilgrimage and of tourist interest;
vi. forests with tree density, sanctuaries, wastelands, agricultural lands,
grazing lands;
vii. boundaries of all villages and towns with their population;
viii. predominant wind direction;
ix. any other relevant features:
Provided that where topographical map is classified as restricted, the
particulars referred to in items (i) to (ix) shall be incorporated in the key plan to
the extent available in the administrative surface maps;
(b) an environment plan of the area of mining lease inclusive of the adjoining area
within five hundred meters of the boundary of a lease area on 1: 5000 scale
incorporating the following:
(i) an administrative surface map showing the boundary of the mining lease;
(ii)contour lines at five meters intervals;
(iii) all features indicated in sub-clauses (iii) to (viii) of clause (a) above;
(iv) area occupied by mine workings, area deforested, area covered by dump
with the height of the dump, processing plant, surface building,
workshop, mining township;
(v) area reclaimed and area afforested, location of protective barriers, check
dams erected to contain solid and liquid effluents generated by
prospecting, mining, beneficiation or metallurgical operations carried out
in the mine;
(vi) all pumping stations and the courses of discharge of mine water;
19

<!-- page 29 -->

(vii) any other relevant features:
Provided that the particulars with regard to items (ii), (iv) and (v) shall be
applicable only up to sixty meters beyond the boundary of lease area.
(6) The competent authority may, by an order in writing, require such additional
details to be shown on the plans and sections required to be kept under these rules
or the preparation and maintenance of such plans and sections showing such details
and on such scale and within such time as he may specify in the order.
(7) The competent authority may, by an order in writing, require the holder of a mining
lease to provide him within such time, such plans and sections, or tracings thereof,
as he may specify in the order.
33. Copies of plans and sections to be submitted.–The holder of a mining lease
shall, on or before the 30th day of June every year submit to the authorised officer, as
the case may be, and the State Government, a digital copy along with a print copy of
the surface geological plans and sections maintained under rule 32.
34. Preparation of plans.–(1) All digitally prepared plans, sections and print copies
thereof kept at the mine shall be suitably indexed.
(2) Every plan, section or part thereof prepared under these rules shall carry thereon a
certificate for its correctness and shall be signed by the mining engineer with date:
Provided that the geological plans and sections shall be certified and signed by the
geologist employed under rule 55.
(3) Every copy of a plan and section or part thereof submitted or maintained under
these rules shall bear a reference to the original plan or section from which it was
copied and shall be certified thereon by the holder of the mining lease to be a true copy
of the original plan or section.

CHAPTER V
Sustainable Mining
35. Sustainable mining. – (1) Every holder of a mining lease shall take all possible
precautions for undertaking sustainable mining while conducting prospecting, mining,
beneficiation or metallurgical operations in the area.
(2) Every holder of a mining lease shall monitor his mining and allied activities as per
the notified template of star rating in the format prescribed in this behalf by the Indian
Bureau of Mines from time to time, and shall submit online its self-assessment report
before the 1st day of July every year for the previous financial year, alongwith the soft
copy (in the standard format), of high resolution satellite images obtained from
20

<!-- page 30 -->

CARTOSAT-2 satellite LISS-IV sensor on the scale of cadastral map, as on the 31st
day of March for that financial year, covering the mining lease and an area of two
kilometres. from the lease boundary, to the Regional Controller or the authorised
officer of the Indian Bureau of Mines.
(3) The confirmation of the star rating may be done by the authorised officer of the
Indian Bureau of Mines through inspection.
(4) The Regional Controller or the authorised officer of the Indian Bureau of Mines
may suspend the mining operations in those mines where at least four star rating has
not been achieved within a period of two years from the date of notification of these
rules or two years from the date of commencement of mining operations, as the case
may be, after giving a show cause notice of forty-five days, to qualify for star rating.
(5) The suspension shall be revoked only after verification through inspection of
compliance of the star rating requirement specified in sub-rule (4) that the mine
qualifies for four star rating:
Provided that in respect of minerals specified in Part B of the First Schedule to the
Act, where the grade of such atomic minerals is equal to or above the threshold value
limits declared under Schedule-A of the Atomic Minerals Concession Rules, 2016, the
action for confirmation and compliance of star rating as provided in sub-rules (3), (4)
and (5) shall be takenby the authorised officer of the Atomic Minerals Directorate for
Exploration and Research.

36. Removal and utilisation of top soil.–(1) Every holder of a prospecting licence,
prospecting license-cum-mining lease or a mining lease shall, wherever top soil exists
and is to be excavated for prospecting or mining operations, remove it separately.
(2) The top soil so removed shall be utilised for restoration or rehabilitation of the
land which is no longer required for prospecting or mining operations or for stabilising
or landscaping the external dumps.
(3) Whenever the top soil is unable to be utilised concurrently, it shall be stored
separately for future use.
37. Storage of overburden, waste rock, etc.- (1) Every holder of a prospecting
licence, prospecting license cum mining lease or a mining lease shall take steps so that
the overburden, waste rock, rejects and fines generated during prospecting and mining
operations or tailings, slimes and fines produced during sizing, sorting and
beneficiation or metallurgical operations shall be stored in separate dumps.
(2) The dumps shall be properly secured to prevent escape of material therefrom in
harmful quantities which may cause degradation of environment and to prevent
causation of floods.
(3) The site for dumps, tailings or slimes shall be selected as far as possible on
21

<!-- page 31 -->

impervious ground to ensure minimum leaching effects due to precipitations.
(4) Wherever possible, materials such as waste rock and overburden shall be backfilled into the mine excavations with a view to restoring the land to its original use as
far as possible.
(5) Wherever back-filling of waste rock in the area excavated during mining
operations is not feasible, the waste dumps shall be suitably terraced and stabilized
through vegetation or otherwise.
(6) The fines, rejects or tailings from mine, beneficiation or metallurgical plants shall
be deposited and disposed in a specially prepared tailings disposal area such that they
are not allowed to flow away and cause land degradation or damage to agricultural
field, pollution of surface water bodies and ground water or cause floods.
38. Precaution against ground vibrations.–Whenever any damage to public
buildings or monuments is apprehended due to their proximity to the mining lease
area, the holder of the mining lease shall carry out scientific investigations so as to
keep the ground vibrations caused by blasting operations within safe limit.
39. Control of surface subsidence. – Stoping in underground mines shall be so
carried out as to keep surface subsidence under control.
40. Precaution against air pollution.–Every holder of prospecting licence or a
mining lease shall take all possible measure to keep air pollution due to fines, dust,
smoke or gaseous emissions during prospecting, mining, beneficiation or metallurgical
operations and related activities within permissible limits.
41. Discharge of toxic liquid.–(1)Every holder of prospecting licence, prospecting
licence cum mining lease or a mining lease shall take all possible precautions to
prevent or reduce the discharge of toxic and objectionable liquid effluents from mine,
workshop, beneficiation or metallurgical plants, tailing ponds, into surface water
bodies, ground water aquifer and useable lands, to a minimum.
(2) The effluents referred to in sub-rule (1) shall be suitably treated, if required, to
conform to the standards laid down in this regard.
42. Precaution against noise.–The holder of prospecting licence, prospecting license
cum mining lease or a mining lease shall take all possible measure to control or abate
noise arising out of prospecting, mining, beneficiation or metallurgical operations at
the source so as to keep it within the permissible limits.
43. Permissible limits and standards.–The standards and permissible limits of all
pollutants, toxins and noise referred to in rules 40, 41 and 42 shall be such as may be
notified by the concerned authorities under the provisions of the relevant laws for the
time being in force.
44. Restoration of flora.– Every holder of prospecting licence, prospecting license
22

<!-- page 32 -->

cum mining lease or a mining lease shall carry out prospecting or mining operations, as
the case may be, in accordance with applicable laws and in such a manner so as to
cause least damage to the flora of the area held under prospecting licence, prospecting
license cum mining lease or mining lease and the nearby areas.

CHAPTER VI
Notices and Returns
45. Monthly and annual returns. – (1) The holder of a mining lease, or any person
or company engaged in trading or storage or end-use or export of minerals mined in
the country, shall cause himself to be registered online with the Indian Bureau of
Mines as per application specified in Form K of the Schedule and the registration
number so allotted by the Indian Bureau of Mines shall be used for all purposes of
online reporting and correspondence connected therewith.
(2) For the purpose of registration under sub-rule (1), the holder of a mining lease, or
any person or company engaged in trading or storage or end-use or export of minerals,
shall apply for registration in electronic form, within one month from the date of
registration of the lease deed or before the commencement of trading operation or
storage or end-use or export of minerals, as the case may be.
(3) The Indian Bureau of Mines shall allot and record the registration number in the
register referred to in sub-rule (4).
(4) The Indian Bureau of Mines shall maintain an online register giving details of the
holder of a mining lease, or any person or company engaged in trading or storage or
end-use or export of minerals, as the case may be, as registered under the provisions of
these rules, which shall be made available to the general public for inspection on
demand, and also posted on the website of the Indian Bureau of Mines.

(5) The holder of a mining lease shall submit online returns in respect of each mine to
the Regional Controller or any other authorised official of the Indian Bureau of Mines
in the following manner, namely:(a) a daily return which shall be submitted through in electronic form through the
application developed by the Indian Bureau of Mines, by 1800 hours of the third
day following the day of reporting, which may be edited before the time deadline
provided in this regard;
(b) a monthly return which shall be submitted before the tenth day of every month in
respect of the preceding month in electronic form along with a signed print copy of
the same if it is not digitally signed, in the respective form as indicated below:(i) for all minerals except copper, gold, lead, pyrite, tin, tungsten, zinc,
23

<!-- page 33 -->

precious and semi-precious stones, in Form F1 of the Schedule;
(ii) for copper, gold, lead, pyrite, tin, tungsten and zinc, in Form F2 of the
Schedule; and
(iii) for precious and semi-precious stones, in Form F3 of the Schedule;
(c) an annual return which shall be submitted before the 1st day of July each year for
the preceding financial year in electronic form, along with a signed print copy of
the same if it is not digitally signed, in the respective Form as indicated below:(i) for all minerals except copper, gold, lead, pyrite, tin, tungsten, zinc, precious
and semi-precious stones, in Form G1of the Schedule;
(ii) for copper, gold, lead, pyrite, tin, tungsten and zinc, in Form G2 of the
Schedule;
(iii) for precious and semi-precious stones, in Form G3 of the Schedule:
Provided that in the case of abandonment of a mine, the annual return shall be
submitted within one hundred and fifty days from the date of abandonment.
(6) Any person or company engaged in trading or storage or end-use or export of
minerals, shall submit online to the Indian Bureau of Mines and concerned State
Government, where the said person or company is sourcing the minerals, the
returns in electronic form, along with a print copy of the same if it is not digitally
signed, in the following manner, namely:(a) a monthly return which shall be submitted before the tenth day of every month
in respect of the preceding month in Form L of the Schedule;
(b) an annual return which shall be submitted before the first day of July of each
year for the preceding financial year in Form M of the Schedule.
(7) If it is found that the holder of a mining lease or the person or company engaged in
trading or storage or end-use or export of minerals, as the case may be, has submitted
incomplete or wrong or false information in daily or monthly or annual returns or fails
to submit a return within the date specified; then,–
(a) in the case of mining of minerals by the holder of a mining lease, the Regional
Controller of Mines may advise the State Government to,(i) order suspension of all mining operations in the mine and to revoke the
order of suspension only after ensuring proper compliance;
24

<!-- page 34 -->

(ii) take action to initiate prosecution under these rules;
(iii) recommend termination of the mining lease, in case such suppression or
misrepresentation of information indicates abetment or connivance of
illegal mining;
(b) in the case of trading or storage or end-use of minerals, the State Government,
where the person or company engaged in trading or storage or end-use of minerals
is sourcing the minerals, shall order suspension of–
(i) trading licence (by whatever name it is called);
(ii) all transportation permits issued to such person or company for mineral
transportation (by whatever name it is called);
(iii) storage licence for stocking minerals (by whatever name it is called);
(iv) permits for end-use industry of minerals (by whatever name it is called);
as the case may be, of such person or company engaged in trading or storage or
end-use of minerals, and may revoke the order of suspension only after ensuring
proper compliance;
(c) in the case of export of minerals, the Directorate General of Foreign Trade shall
order suspension of permits for carrying out such exports of minerals of such
person or company engaged in export of minerals, and may revoke the order of
suspension only after ensuring proper compliance:
Provided that the holder of a mining lease or the person of company
engaged in trading of storage or end user or export of minerals, as the case may be,
referred to in clause (a), (b) and (c) above, shall be informed in writing about the
violation and if the violation is not rectified within a period of forty-five days, a
show cause notice shall be given asking reasons why the mining operations should
not be suspended and, further, if no satisfactory reply is received within a period
of thirty days, the mining operations may be suspended.
(8) In case of mining of minerals by the holder of a mining lease, the–
(a) sale value is the gross amount payable by the purchaser as indicated in the sale
invoice, where the sale transaction is on an arms’ length basis and the price is
the sole consideration for the sale, excluding taxes, if any.
Explanation.– For the purpose of computing sale value, no deduction from the
gross amount shall be made in respect of royalty, payments to the District
25

<!-- page 35 -->

Mineral Foundation and payments to the National Mineral Exploration Trust;
(b) ex-mine price of mineral grade or concentrate shall be,–
(I)

where export has occurred, the total of, sale value on free-on-board (F.O.B)
basis, less the actual expenditure incurred beyond the mining lease area
towards –
(i) transportation charges by road;
(ii) loading and unloading charges;
(iii) railway freight (if applicable);
(iv) port handling charges or export duty;
(v) charges for sampling and analysis;
(vi) rent for the plot at the stocking yard;
(vii) handling charges in port;
(viii) charges for stevedoring and trimming;
(ix) any other incidental charges incurred outside the mining lease area as
notified by the Indian Bureau of Mines from time-to-time, divided by
the total quantity exported;

(II)

where domestic sale of mineral has occurred, the total of sale value of the
mineral, less the actual expenditure incurred towards loading, unloading,
transportation, rent for the plot at the stocking yard, charges for sampling and
analysis and any other charges beyond mining lease area as notified by the
Indian Bureau of Mines from time-to-time, divided by the total quantity sold;

(III)

where sale has occurred, between related parties and is not on arms’ length
basis, then such sale shall not be recognised as a sale for the purposes of this
rule and in such case, sub-clause (IV) shall be applicable;

(IV)

where the sale has not occurred, the average sale price published monthly by
the Indian Bureau of Mines for that mineral grade or concentrate for a
particular State:

Provided that if for a particular mineral grade or concentrate, the
information for a State for a particular month is not published by the Indian
Bureau of Mines, the last available information published for that mineral
grade or concentrate for that particular State by the Indian Bureau of Mines in
the last six months previous to the reporting month shall be referred, failing
which the latest information for all India for the mineral grade or concentrate,
shall be referred;

(V)

the per unit cost of production in case of captive mines.

26

<!-- page 36 -->

(9) In case of trading or storage or end-use or export of minerals, for purpose of filing
of returns, the value of the mineral grade or concentrate shall be,–
(a) where sale of the mineral grade or concentrate has occurred and the sale
transaction is on an arms’ length basis and the price is the sole consideration for
the sale, the sale value of the mineral grade or concentrate recorded in the invoice;
(b) where sale has not occurred, the product of average sale price published monthly
by the Indian Bureau of Mines for a particular mineral grade or concentrate for a
particular State and the quantity dispatched or procured:
Provided that if for a particular mineral grade or concentrate, the
information for a State for a particular month is not published by the Indian
Bureau of Mines, the last available information published for that mineral grade or
concentrate for that particular State by the Indian Bureau of Mines in the last six
months previous to the reporting month shall be referred, failing which the latest
information for all India for the mineral grade or concentrate, shall be referred.
(10) If more than one mineral is produced from the same mine, return shall be
submitted along with the relevant parts of the specified forms for each mineral
separately.
(11) In case of temporary discontinuance of mining or suspension of mining, or
temporary discontinuance or suspension of trading or storage or end-use or export of
minerals, the holder of a mining lease, or the person or company engaged in trading or
storage or end-use or export of minerals, as the case may be, shall submit return in the
specified form for the mineral for which return had been submitted earlier and furnish
relevant particulars, inclusive of “Nil” information, if any.
(12) In case ownership of the mine or the trading or storage or end-use or export
company changes during the reference period, separate returns shall be filed by each
owner for the respective periods of ownership.
(13) For the purpose of regulation of transportation of minerals, all persons and
companies owning trucks or any other motorised vehicle used for transportation of
mineral byroad or through water way shall be required to be registered with the
Directorate of Mining and Geology or the Department handling mining matters in the
State Government, and the lessee shall maintain trip-sheets (either in the form of
written record or on computers) of the vehicles, the nature and weight of mineral and
the approximate time of the trip and its destination.

46. Notice of certain appointments.–The holder of the prospecting licence or
prospecting license cum mining lease or the mining lease shall,–
(a) when any new appointment of an agent, mining engineer, geologist or any
person is made under sub-rule (1) of rule 55; or
27

<!-- page 37 -->

(b) when the employment of any such person is terminated or any such person
leaves the said employment; or
(c) when any change occurs in the address of any such person, within fifteen days
from the date of such appointment, termination, leaving or change in address,
give a notice in Form H of the Schedule to the authorised officer, as the case
may be.
47. Notice of shaft sinking and boreholes.–The holder of a mining lease or the
holder of a prospecting licence or prospecting license cum mining lease shall send an
intimation in Form I of the Schedule to the authorised officer, as the case may be,
within fifteen days after the commencement of any of the following operations,
namely:–
(a) the sinking of trial shaft or borehole to a depth exceeding ten meters from the
surface; or
(b) the extension of an existing shaft or borehole to a depth exceeding ten meters; or
(c) the sinking of a new shaft or boreholes commencing from underground workings:
Provided that the authorised officer, as the case may be, may permit such
intimationto be given collectively within such extended period as may be specified by
him.
48. Records of shafts and boreholes.–(1) The holder of a mining lease or the holder
of a prospecting licence or prospecting license-cum-mining lease shall keep a record in
Form-J of all shafts or boreholes and shall retain such records and preserve the samples
of the strata passed through for a period of not less than twelve months after the
completion of the work or abandonment thereof:
Provided that the records of boreholes and shafts exceeding one hundred metres
length shall not be destroyed except with the prior approval of theauthorised officer, as
the case may be.

49. Change in name of mine to be notified. – The holder of a mining lease shall send
a notice in Form C of the Schedule to the State Government and the authorised officer,
as the case may be, of any change in the name of the mine within thirty days of such
change.
50. Notice of transfer of prospecting licence-cum-mining lease or mining lease.–
Every holder of a prospecting licence-cum-mining lease or a mining lease who
transfers the mineral concession or any right, title or interest thereof, in accordance
with the provisions of the Act or the rules made thereunder, to any other person, shall,
within thirty days of the date of such transfer, send an intimation thereof in Form N of
the Schedule to the Controller General and the authorised officer, as the case may be.

51. Notice of amalgamation of mining lease.– Without prejudice to the provisions of
the Act or any rules made thereunder or the terms and conditions of a mining lease,
28

<!-- page 38 -->

every holder of a mining lease shall, within thirty days of the date of amalgamation of
mining leases carried out under rule 56 of the Minerals (Other than Atomic and Hydro
Carbons Energy Minerals) Concession Rules, 2016 or in accordance with rule 33 of
the Atomic Minerals Concession Rules, 2016, as the case may be, send an intimation
thereof to the Regional Controller and the State Government and the authorised officer,
as the case may be.
52. Transfer of records to transferees.- When the ownership of a prospecting
license-cum - mining lease or a mining lease is transferred as per provisions of Act or
any rules made thereunder, the previous owner or his agent shall make over to the new
owner or his agent within a period of seven days of the transfer of the ownership,
borehole cores along with records and samples preserved, if any, all plans, sections,
reports, registers and other records maintained in pursuance of the Act, rules or orders
made thereunder, and all correspondence relevant thereto relating to the prospecting
license cum mining lease or mining lease; and when the requirements of these rules
have been duly complied with, both previous and the new owners or their respective
agents shall forthwith send to the State Government and the authorised officer, as the
case may be, a detailed list of borehole cores, plans, sections, reports, registers and
other records that have been transferred.
53. Copies of notices or returns and reports to be submitted to State
Government.–The holder of a mining lease or a holder of a prospecting licence or
prospecting license cum mining lease shall simultaneously submit a copy each of the
notice or return or report required to be submitted under these rules to the State
Government concerned in whose territory the mine or the prospecting area is situated,
or to such authority as that Government may specify in this behalf.
54. Copies of notices and returns and reports to be maintained.-The holder of a
mining lease or a holder of a prospecting licence or prospecting license-cum-mining
lease shall maintain the labour attendance register, production and dispatch register,
royalty assessment register,–
(a) details of contribution made to District Mineral Foundation and National
Mineral Exploration Trust;
(b) details of payments made to the State Government in terms of percentage of
value of minerals dispatched as quoted in the bidding;
(c) details of expenditure incurred towards the mine closure activities, explosives
consumption register, bore hole logs along with the chemical analysis reports,
mineral analysis reports, sub-grade or mineral reject stack register along with
the grade; and
(d) details of mining machinery and copies of all notices and returns, plans,
sections and schemes submitted to the authorised officer or the State
Government or the Regional Controller under these rules,
at an office established in the area where mining or prospecting operations are carried
on, and these shall be made available at all reasonable times to the authorised officer,
as the case may be, for inspection.

29

<!-- page 39 -->

CHAPTER VII
Employment of Geologists and Mining Engineers
55. Employment of geologists and mining engineers.-(1) For the purpose of
carrying out reconnaissance, prospecting or mining operations in accordance with
these rules,–
(a)

every holder of reconnaissance permit shall employ a whole-time geologist;

(b)

every holder of prospecting licence or a prospecting license-cum-mining
lease shall employ a whole-time geologist and a part-time mining engineer;

(c)

every holder of a mining lease shall employ, in case of–
(i)

category 'A' mines, a whole-time mining engineer and a geologist;

(ii)

category 'B' mines, a part-time mining engineer and a part-time
geologist:

Provided that in the case of fully mechanised category 'A' mines, the mining
engineers and geologists shall have minimum five years of professional experience of
working in a supervisory capacity in the field of mining:
Provided further that in case of category 'B' mines, a person employed in terms of
the provisions of sub-rule (1) may be permitted to be employed in lieu of part-time
mining engineer.

(2) For the purpose of these rules,–
(a) category 'A' mines means–
(i) such fully mechanised mines where the work is being carried out by
deployment of heavy mining machinery for deep hole drilling, excavation,
loading and transport; or
(ii) such mines where the number of average employment exceeds one hundred
and fifty in all or seventy-five workings below ground, or mines where any
of the mining operations like deep hole drilling, excavation, loading and
transport is carried out with the help of heavy machinery;
(b) category 'B' mines means mines other than category 'A' mines:
30

<!-- page 40 -->

Provided that if any doubt arises as to whether any mine is a category 'A' mine, it
shall be referred to the Controller General for decision.
Explanation.– For the purpose of this rule, the expression “average employment”
means the average per day of the total employment of the mine during the
preceding quarter (obtained by dividing the number of man days worked by the
number of working days).

(3) The part-time mining engineer and geologist can be employed up to a maximum
of six prospects or mines, provided that all such prospects or mines are located within
a radius of fifty kilometres.
(4) If the holder of a reconnaissance permit, prospecting licence or a prospecting
license-cum-mining lease or a mining lease is a geologist or mining engineer, he may
appoint himself as the geologist or mining engineer for the purpose of sub-rule (1).
(5) If the manager of a mine is a mining engineer or a geologist he may appoint
himself as a mining engineer or geologist for the purpose of sub-rule (1).
(6) A mining engineer or geologist employed by the holder of a prospecting licence or
prospecting license-cum-mining lease or mining lease shall possess the qualifications
specified below, namely:–
Geologist:

A postgraduate degree in Geological Science or Geology or Applied
Geology or Geo-exploration or Mineral Exploration granted by a
University established or incorporated by or under a Central Act, or
a State Act, in India or educational Institution established by an Act
of Parliament or declared to be deemed university under the
University Grants Commission established under section 4 of the
University Grants Commission Act, 1956 (3 of 1956) or any
equivalent qualification.

Mining Engineer : A degree in Mining Engineering granted by a University established
or incorporated by or under a Central Act, a Provincial Act or a
State Act, including any institution recognised by the University
Grants Commission established under section 4 of the University
Grants Commission Act, 1956 (3 of 1956) or any equivalent
qualification.
56. Duties of geologist. – (1) It shall be the duty of the geologist to conduct
prospecting operations in accordance with the provisions of these rules.
(2)The geologist referred to in rule 55 shall –

31

<!-- page 41 -->

(a) be responsible for periodic updating of minerals resources, maintenance of bore
cores or samples and bore hole logs;
(b) plan for conservation of mineral resources and optimal utilisation of the minerals
and ores in the mining leases;
(c) prepare a scheme of prospecting and carry out the investigation operation as per
the scheme;
(d) prepare the necessary geological maps, plans and sections which are required to
delineate the ore body;
(e) carry out petrological and mineralogical studies of host rock and mineralised
zones;
(f) calculate ore reserves and its grade;
(g) be responsible for providing all the necessary information required for controlling
the quality or grade of the minerals produced;
(h) maintain proper records of the prospecting operations and records of sinking of
shafts and boreholes as provided under these rules;
(i) work out the appropriate method of sampling and ensure preparation of samples
accordingly;
(j) maintain an assay plan in cases of underground workings;
(k) maintain all technical data for determining the shape and size of each stope block;
(l) update the reserve figures, grade-wise and category-wise at the end of every year
in case of a working mine;
(m) identify the associated rocks and minerals and maintain proper records of the
stacks of non-salable or sub-grade ores and minerals produced;
(n) carry out all such orders and directions as may be given in writing under these
rules by the Controller General or the authorised officer of the State Government
and shall forward a copy of all such orders or directions to the holder of the
prospecting licence or prospecting license-cum-mining lease or mining lease, as
the case may be.
57. Duties of mining engineer. – (1) It shall be the duty of the mining engineer to
take all necessary steps to plan and conduct mining operations so as to ensure
conservation of minerals, systematic development of the mineral deposits and
protection of environment in and around the mining lease area in accordance with
these rules.

32

<!-- page 42 -->

(2) The mining engineer shall be responsible for the preparation and maintenance of
plans, sections, reports and schemes in accordance with these rules.
(3) The mining engineer shall be responsible for carrying out the study of the
associated rocks and minerals, identifying them and stacking the various minerals
produced separately.
(4) The mining engineer shall also carry out all such orders and directions as may be
given in writing under these rules by the State Government or the Controller General
or the authorised officer and shall forward a copy of such orders or directions to the
holder of prospecting licence or prospecting license-cum-mining lease or the mining
lease, as the case may be.
(5) The mining engineer shall ensure that there is sufficient provision of proper
materials, appliances and facilities at all times at the mine for the purpose of carrying
out the provisions of these rules and orders issued thereunder and where he is not the
holder of the mining lease, he shall make requisition in writing to the holder of the
mining lease for anything required for the aforesaid purpose.
(6) A copy of every requisition referred to in sub-rule (5) shall be recorded in a bound
paged book kept for the purpose, and on receipt of such a requisition, the holder of the
mining lease shall provide as soon as possible the materials and facilities requisitioned
by the mining engineer.

CHAPTER VIII
Examination of Minerals and Issue of Directives
58. Power to issue directions.-(1) The holder of a mineral concession shall comply
with such directions providing for systematic development of mineral deposits,
conservation of minerals and for sustainable mining as the Controller General or the
Director, Atomic Minerals Directorate for Exploration and Research, as the case may
be, may issue from time to time.
(2) A copy of the proposed directions to be issued to any particular mine shall be sent
by the Controller General or the Director, Atomic Minerals Directorate for
Exploration and Research, as the case may be, to the holder of a mineral concession,
and to the State Government concerned, and any comments received from the holder
of a mineral concession and the State Government within thirty days of the date of
service of the notice, shall be duly considered by him before issuing any such
directions.
(3) General directions applicable to a class of mines shall be issued by the Regional
Controller or the Director, Atomic Minerals Directorate for Exploration and Research,
as the case may be, with the previous approval of the Central Government in
consultation with the State Government concerned.
33

<!-- page 43 -->

(4) An order made under sub-rule (1) shall–
(a) in the case of an order of a general nature or affecting a class of persons, be
notified in Official Gazette; and
(b) in the case of an order directed to a specified individual, be served on such
individual by delivering or tendering it to that individual, or if it is not
possible to be so delivered or tendered, by affixing it on the outer door or
some other conspicuous part of the premises in which that individual lives,
and a written report thereof shall be prepared and witnessed by two persons
living in the neighborhood.
59. Examination of mineral deposits and taking of samples.–The authorised
officer, as the case may be, may examine any mineral deposit in any area under
prospecting licence or prospecting license-cum-mining lease or mining lease and take
samples there from at any time for the purposes of these rules.
60. Prohibition of deployment in certain cases.- If any mine or part thereof, which
in the opinion of the Chief Controller of Mines or the Controller of Mines or the
Regional Controller of Mines poses a grave and immediate threat to the conservation
of minerals or to environment or to the sustainable development of the mine, he may,
by an order in writing to the holder of a mining lease, require him to take such
measures as may be specified in the order and may prohibit, until the requirements as
specified in the order are complied with to his satisfaction, the deployment of any
person other than those required for compliance with the requirement of the order:
Provided that in respect of minerals specified in Part B of the First Schedule to the
Act, where the grade of such atomic minerals is equal to or above the threshold value
limits declared under Schedule-A of the Atomic Minerals Concession Rules, 2016, the
Director, Atomic Minerals Directorate for Exploration and Research shall issue orders
in this regard.

CHAPTER IX
Revision and Penalty
61. Revision.- (1) Any person aggrieved by any order made or direction issued under
these rules by any authorised officer excepting the State Government, as the case may
be, may within thirty days of the communication of such order or direction, apply to
the Controller General or the Director, Atomic Minerals Directorate for Exploration
and Research, as the case may be, for a revision of the order or direction:
Provided that any such application may be entertained after the said period of
thirty days if the applicant satisfies the Controller General or the Director, Atomic
Minerals Directorate for Exploration and Research, as the case may be, that he had
sufficient cause for not making the application within time:
Provided further that if any order made or direction issued by an officer
34

<!-- page 44 -->

subordinate to the Chief Controller of Mines, the application shall be made to the Chief
Controller of Mines who shall deal with the application in the manner provided
hereunder.
(2) Every order against which a revision application is preferred under sub-rule (1)
shall be complied with pending receipt of the decision of the Controller General or the
Director, Atomic Minerals Directorate for Exploration and Research or the Chief
Controller of Mines, as the case may be:
Provided that the Controller General or the Director, Atomic Minerals Directorate
for Exploration and Research or the Chief Controller of Mines, as the case may be,
may suspend the operation of the order against which the revision has been preferred,
pending disposal of the revision application.
(3) On receipt of an application for revision under sub-rule (1), the Controller General
or the Director, Atomic Minerals Directorate for Exploration and Research or the Chief
Controller of Mines, as the case may be, after giving a reasonable opportunity of being
heard to the aggrieved person, may confirm, modify or set aside the impugned order.
(4) Any person aggrieved by any order made or direction issued by the Chief
Controller of Mines may within thirty days of the communication of such order or
direction, prefer an appeal to the Controller General as against the said order or
direction:
Provided that any such appeal may be entertained after the said period of thirty
days, if the applicant satisfies the Controller General that he had sufficient cause for
not making the application within time.
(5) On receipt of any such appeal under sub-rule (4), the Controller General may
confirm, modify or set aside the order or direction made or issued by the Chief
Controller of Mines or may pass such orders in relation to the applicant, as it may
deem fit and such decision shall be final.
(6) Every order against which appeal is preferred under sub-rule (4), shall be
complied with pending receipt of the decision of the Controller General:
Provided that the Controller General may, on an application made by the
applicant, suspend operation of the order or direction appealed against pending
disposal of the appeal.
(7) Every application submitted under the provisions of this rule shall be accompanied
by a bank draft for ten thousand rupees as application fee drawn on a scheduled bank
in the name of ‘Pay and Accounts Officer, Indian Bureau of Mines’ payable at Nagpur
or by way of a bank transfer to the designated bank account of the Indian Bureau of
Mines:
Provided that in case the application under sub-rule (1) is made to the Director,
Atomic Minerals Directorate for Exploration and Research, the amount of ten thousand
35

<!-- page 45 -->

rupees shall be remitted as per the details specified by the Director, Atomic Minerals
Directorate for Exploration and Research in this regard.

62. Penalty.– Whoever contravenes any of the provisions of these rules shall be
punishable with imprisonment for a term which may extend to two years or with fine
which may extend to five lakh rupees, or with both, and in the case of a continuing
contravention, with additional fine which may extend to fifty thousand rupees for
every day during which such contravention continues after conviction for the first such
contravention:
Provided that any offence punishable under these rules may either before or after
the institution of the prosecution, be compounded by the person authorised under
section 22 of the Act to make a complaint to the court with respect to that offence, on
payment to that person, for credit to the Government, of such sum specified in this
regard by the Controller General or the Director, Atomic Minerals Directorate for
Exploration and Research, in respect of minerals specified in Part B of the First
Schedule to the Act where the grade of such atomic minerals is equal to or above the
threshold value limits declared under Schedule-A of the Atomic Minerals Concession
Rules, 2016, as the case may be:
Provided further that in case of an offence punishable with fine only, such sum
shall not exceed the maximum amount of fine which may be imposed for that offence:
Provided also that where an offence is compounded under these rules, no
proceeding or further proceeding, as the case may be, shall be taken against the
offender in respect of the offence so compounded, and the offender, if in custody, shall
be released forthwith.

CHAPTER X
Miscellaneous
63. Preservation of cores, etc.-(1)Every holder of a mineral concession and every
agency authorised under the second proviso to sub-section (1) of section 4 shall
preserve intact, until submission of the final geological report, all cores and specimens
of different types of rocks and minerals obtained during drilling or sinking operations
and shall arrange for them to be laid out in a serial order with identification marks,
showing the progressive depth at which they are obtained.
(2) The State Government or the authorised officer, as the case may be, may, by an
order in writing, require the holder of the mineral concession or the agency authorised
under the second proviso to sub-section (1) of section 4 to preserve the cores or
specimens of rocks and minerals obtained from specific boreholes or shafts in a
specific manner or for any specific period or relax the provisions of this rule to such an
extent as they may deem fit.

36

<!-- page 46 -->

(3) No cores or samples generated and preserved as per sub-rule (1) and (2) above
shall be destroyed without the prior permission in writing from the Chief Controller of
Mines or the State Government or the Director, Atomic Minerals Directorate for
Exploration and Research, as the case may be.
(4) The Geological Survey of India shall be the nodal agency for archiving drill cores
at the National Core Repository and at the Regional Drill Core Repositories with
suitable indexing and cataloguing.
(5) The Regional Drill Core Repositories shall function as satellites of the National
Core Repository.
(6) The holder of a mineral concession or any other agency authorised under the
second proviso to sub-section (1) of section 4 shall adhere to the procedure for
preservation and submission of cores as provided in the manual issued by the
Geological Survey of India from time to time and shall preserve the identified borehole
cores to be collected by the Geological Survey of India, after completion of all the
required studies at the time of submission of the final geological report.

64. Facilities for undertaking research or training.-Every holder of a prospecting
licence or a prospecting licence-cum-mining lease or a mining lease shall afford all
reasonable facilities to persons authorised by the authorised officer for the purpose of
undertaking research or training in matters relating to mining or geology.
65. Submission of records or reports regarding research in geology or mining.-(1)
Any person, institution or agency carrying on prospecting or mining operations related
to any research in geology or mining, shall inform the Controller General or the
Director, Atomic Minerals Directorate for Exploration and Research, as the case may
be, within a period of thirty days of commencement of such research related
operations, indicating briefly the aspects proposed to be covered under such research
together with the name and address of the person, institution, or agency carrying out
such research work and the expected duration of the research related operations.
(2) On completion of the said research work, a report describing the observations,
analysis and conclusions reached as a result of the said research work shall be
submitted to the Director General, Geological Survey of India for geology related
research and to the Chief Controller of Mines or the Director, Atomic Minerals
Directorate for Exploration and Research, as the case may be, for mining research
within thirty days of its completion.
(3) The authorities referred to in sub-rule (2) shall keep the information provided in
the receipt confidential, and if required, the authorised officer may utilise the said
information for general studies, planning or policy making purpose.
(4) The provisions of sub-rules (1) and (2) shall also apply mutatis mutandis to any
agency of the Central Government or State Government carrying out the research
work.
37

<!-- page 47 -->

66. Territorial jurisdiction of Controller of Mines and Regional Controller.- The
Controller General may by a notification in the Official Gazette, prescribe the limits of
the territorial jurisdiction of the Controller of Mines and the Regional Controller for
purposes of these rules:
Provided that the Director, Atomic Minerals Directorate for Exploration and
Research in respect of minerals specified in Part B of the First Schedule to the Act,
where the grade of such atomic minerals is equal to or above the threshold value limits
declared under Schedule-A of the Atomic Minerals Concession Rules, 2016, may by a
notification in the Official Gazette, prescribe the limits of the territorial jurisdiction of
the authorised officer of the Atomic Minerals Directorate for Exploration and Research
for the purposes of these rules.
67. Obligation to supply other information.– The holder of a mineral concession
shall furnish such information regarding his reconnaissance or prospecting operations
or mining operations or any matter connected therewith as the authorised officer may
require by an order in writing and the information shall be furnished within such time
as may be specified in the such order.
68. Provisions of these rules to be applicable to Central Government and State
Governments.–The Central Government, the State Governments or its agencies
carrying out prospecting or mining operations, as the case may be, without a mineral
concession shall be bound by all the provisions of these rules in the same manner as
they are applicable to holders of mineral concessions.
69. Exercise of powers.–(1) Any power granted under these rules to the Regional
Controller may be exercised by the Controller of Mines.
(2) The powers granted to the Controller of Mines can be exercised by Chief
Controller of Mines and the powers granted to the Chief Controller of Mines can be
exercised by the Controller General:
Provided that any power granted under these rules to an authorised officer of the
Atomic Minerals Directorate for Exploration and Research may be exercised by the
Director, Atomic Minerals Directorate for Exploration and Research, in respect of
minerals specified in Part B of the First Schedule to the Act where the grade of such
atomic minerals is equal to or above the threshold value limits declared under
Schedule-A of the Atomic Minerals Concession Rules, 2016.

70. Saving of Act 33 of 1962.–Nothing in these rules shall affect the provisions of the
Atomic Energy Act, 1962 ( 33 of 1962) and the rules made thereunder, in respect of
minerals specified in Part B of the First Schedule to the Act.
71. Review of format and manuals.- The Indian Bureau of Mines or the Director,
Atomic Minerals Directorate for Exploration and Research, as the case may be, shall
revise or update, every three years or earlier, if required, after consultation with
38

<!-- page 48 -->

stakeholders, the formats of the scheme of reconnaissance, scheme of prospecting,
mining plan and the mine closure plan provided by it.

CHAPTER XI
Geological Reports

72. Geological reports.- (1) Every agency authorised under the second proviso to
sub-section (1) of section 4, shall submit a geological report and all geo-scientific data
(geological, airborne geophysical, ground, geophysical and geochemical and any data
collected for geological investigation purpose) collected during the course of the
prospecting operations, to the Director General of the Geological Survey of India, the
Controller General and the State Government before the thirtieth day of June of every
year in respect of the work done during the previous year:
Provided that in respect of minerals specified in Part B of the First Schedule to the
Act, the agency shall submit the report to the Director, Atomic Minerals Directorate
for Exploration and Research and the State Government in a format provided by the
Atomic Minerals Directorate for Exploration and Research.
(2) The geological reports and geo-scientific data shall be submitted in hard copies
and in digital form every year reckoned from the date of commencement of operations
and shall include–
(a)

geological data relating to exploration, such as raw data with location, geological
map, structural data, sections, plans and anomaly maps;

(b)

geophysical data (ground and aero-geophysical) relating to prospecting fields or
engineering or ground water surveys, such as raw data with location, anomaly
maps, sections, plans, contour maps and logging details;

(c)

geochemical data relating to exploration, such as raw analytical data with
location, anomaly and contour maps and sections; and

(d)

detailed exploration results, style and nature of mineralisation, mineral resource
and mineral reserve estimates and grade, and the necessary supporting documents
relating to exploration results, mineral resources or mineral reserves of the area
shall form a part of the report.

(3) The geological reports shall be prepared in a format to be specified by the
Controller General or the Director, Atomic Minerals Directorate for Exploration and
Research, as the case may be, so as to enable a complete assessment of the exploration
progress and results and to ensure that the results of exploration are fully and clearly
recorded for mineral development in the future.
39

<!-- page 49 -->

(4) The geological reports under this Chapter shall be prepared by or under the
direction of, and signed by a geologist under whose supervision exploration was
carried out.

CHAPTER XII
Mining Regulation Portal

73. Mining regulation web portal.– The Indian Bureau of Mines, in consultation
with the State Governments, shall prepare a mining regulation web portal to bring
information together the different aspects of the regulatory functions being undertaken
by the Indian Bureau of Mines and the State Government or the authorised officer of
the Atomic Minerals Directorate for Exploration and Research, as the case may be, for
implementation and compliance of the provisions of these rules.
74. Recording of regulatory functions.– All aspects of regulatory functions being
undertaken by the Indian Bureau of Mines or the State Government or the authorised
officer of the Atomic Minerals Directorate for Exploration and Research, as the case
may be, for implementation and compliance of the provisions of these rules shall be
recorded in standard process sheets or templates developed for these purposes, and the
information in this regard shall be made available on the portal referred to in rule 73:
Provided that access to the commercial information provided in the said web
portal shall be so regulated that the information is accessible only by the holder of the
mineral concession concerned, the Controller General, the Central Government, the
State Government, the authorised officer and the administrator of the web portal.
75. Information source.–(1) Each information source shall have a dedicated area on
the page for displaying information (a portlet).
Explanation.–For the purposes of this rule, it is clarified that inspections carried out by
the Indian Bureau of Mines or the State Government or an authorised officer of the
Director, Atomic Minerals Directorate for Exploration and Research, as the case may
be, and the response of the mine owner or manager to the inspection shall be construed
as one information source.
(2) Identification of the different information sources, user categories, preparation of
the standard process sheets or templates, configuring and customizing the presentation
of the content and other details in this regard as well the role of the administrator for
addition of information to the portal or deletion from the portal shall be decided by the
Controller General in consultation with the Central Government.

40

<!-- page 50 -->

SCHEDULE
FORM-A
(See rule 7)
(Notice of commencement of Reconnaissance or prospecting operations)

IMPORTANT INSTRUCTIONS FOR FILLING THE FORM






This Form, duly filled in must reach the concerned authorities as prescribed within the rule,
within fifteen days of the commencement of Reconnaissance or prospecting operations by
online or Email.
This should be sent to the Regional Controller in whose territorial jurisdiction the mineral
concession falls as notified from time to time by the Controller General, Indian Bureau of
Mines, under rule 66 of the Mineral Conservation Development Rules, 2016.
The form should be digitally signed by the concerned person.
____________________________________________________________________

1. Type of Mineral Concession ---

Reconnaissance Permit
Prospecting Licence
Prospecting License-cum-Mining Lease

2. IBM Registration Number

3. Unique IBM Concession Number

Reconnaissance Permit
Prospecting License
Prospecting License-cum-Mining Lease

4. Name of the mineral or minerals for which Reconnaissance Permit or prospecting
license or prospecting license cum mining lease has been granted:
(Information will be system generated. Linked with Entry 5 and 6 of Form ‘K’.)
5. Name and address of the permit holder or licensee:
(Information will be system Generated. Linked with Entry 5 and 6 of Form ‘K’.)
6. Particulars of Mineral Concession
(Information will be system Generated. Linked with Entry 5 and 6 of Form ‘K’.)

41

<!-- page 51 -->

7. Location of the Mineral Concession
(Information will be system Generated. Linked with Entry 5 and 6 of Form ‘K’.)
8. Particulars of Geologist employed for the Reconnaissance Permit or Geologist and
Mining Engineer employed for the Prospecting Licenced area:
(i) Name and address:

(ii) E-mail address:

(iii) Phone Number and Mobile Number:

(iv) Qualification:

(v) Date of Appointment:

(vi) Nature of Appointment:

Whole Time

Part Time

9. Date of commencement of Reconnaissance Operation
or prospecting operations
Place:
Date:
Signature
Name in full:
Designation: Owner/Geologist/Mining Engineer

42

<!-- page 52 -->

FORM-B
[See rule 9(1), 9(3) and 9(4)]
(Progress Report of the Reconnaissance Operations or Prospecting Operations carried out for
the year ……………………)

IMPORTANT INSTRUCTIONS FOR FILLING THE FORM






This Form, duly filled in must reach the concerned authorities within forty five days after
expiration of twelve months from the date of execution of Reconnaissance Permit/
Prospecting license deed or the expiry of Reconnaissance permit/ prospecting licence or
prospecting license cum mining lease, whichever is earlier or within the period of thirty days
from the date of abandonment of Reconnaissance / prospecting operations by online or Email.
This should be sent to the Regional Controller in whose territorial jurisdiction the mineral
concession falls as notified from time to time by the Controller General, Indian Bureau of
Mines, under rule 66 of the Mineral Conservation Development Rules, 2016.
The form should be digitally signed by the concerned person.
____________________________________________________________________

1. Type of Mineral Concession ---

Reconnaissance Permit
Prospecting Licence
Prospecting License-cum-Mining Lease

2. IBM Registration Number

3. Unique IBM Concession Number

Reconnaissance Permit
Prospecting License
Prospecting License-cum-Mining Lease

4. Name of the mineral or minerals for which Reconnaissance Permit or prospecting
license or prospecting license cum mining lease has been granted:
(Information will be system Generated. Linked with Entry 5 and 6 of Form ‘K’.)

5. Name and address of the permit holder or licensee:
(Information will be system Generated. Linked with Entry 5 and 6 of Form ‘K’.)

43

<!-- page 53 -->

6. Particulars of Mineral Concession:
(Information will be system Generated. Linked with Entry 5 and 6 of Form ‘K’.)

7.

Location of the Mineral Concession:
(Information will be system Generated. Linked with Entry 5 and 6 of Form ‘K’.)

8. Status of reconnaissance / prospecting operation
Please tick-mark the boxes whichever is applicable

In Progress [ ]
Completed [ ]
Abandoned [ ]

9. If reconnaissance /prospecting operation
is completed or abandoned, date of such
completion or abandonment
10. Total surface area covered by reconnaissance / prospecting
work (hectares) as on date
11. Reconnaissance survey work done
(A brief description of the work involved along with particulars of the machines and
instruments used would be given against each of the following items)
(i) Regional Survey
_______________________________
(ii) Aerial/photo-geological work
______________________________
12. Geological Mapping including area covered and scale
(i) Geophysical
_______________________________
(ii) Geochemical
_______________________________
(iii) Test drilling : Number, area of influence
meterage and sampling
_________________________
(iv) Nature and structure of the ore body
(v) Analysis of the ores or minerals
13. Completion of prospecting work during the year:
14.

(a) Pitting

(i)Number of pits _________________
(ii) Depth (metres) Average _______________
Maximum _______________
Minimum _______________
(b) Trenching
(i)Number of trenches ____________________

44

_____________________________
_____________________________

<!-- page 54 -->

(ii) Length (metres)

Average ______________
Maximum ______________
Minimum ______________

(c) Drilling

Surface

(i)Number of boreholes completed
during the year.
(ii) Number of boreholes in progress,
if any
(iii)Total annual drilling (metres)
(d) Particulars of drilling machines:

Type

Underground

_____________

_____________

_____________

_____________

_____________

_____________

Make

Number of drills

Capacity

(e) Exploratory mining, if any:
(1)Number of levels
(2) Total development (metres)
(3) Mode of entry
(4) Quantity of ore produced
with grade

______________________________________________
______________________________________________
______________________________________________
______________________________________________

(f) Number of samples analysed:
(1) Main constituent (please specify)
(2) Complete analysis
15.

If abandoned

(i)
(ii)

Date of abandonment
Reasons for abandonment

____________________________________
______________________________________

_______________________________
_______________________________

Note: Please enclose a geological report describing the reconnaissance / prospecting operations
undertaken so far along with the detailed geological plans and sections showing locations of (a)
boreholes, (b) pits, (c) trenches, (d) shafts, (e) underground exploratory workings, (f) outcrops, (g) ore
zones, (h) faults, (i) folds and other geological features.
The Report shall contain in the borehole logs and interpretation and the inferences drawn as a result of
the study of the geology of the area and the interpretation of the borehole cores, pits, trenches, assay
data, reserves of ore and contain results of complete analysis of at least two representative samples of
ore and the blocks proposed for mining operations. The report shall also contain the results of any
beneficiation study carried out on the ores or minerals of the area.

Place:
Date:
Signature
Name in full:
Designation: Owner/Geologist/Mining Engineer

45

<!-- page 55 -->

FORM-C
(See rule 20, 29 and 49)
(Notice of intimation of opening/reopening of mine/change in the name of mine)

IMPORTANT INSTRUCTIONS FOR FILLING THE FORM






1.

This Form, duly filled in must reach the concerned authorities as prescribed within the rule,
within fifteen days of the opening or reopening and within thirty days in case of change in the
name of mine, by online or Email.
This should be sent to the Regional Controller in whose territorial jurisdiction the mineral
concession falls as notified from time to time by the Controller General, Indian Bureau of
Mines, under rule 66 of the Mineral Conservation Development Rules, 2016.
The form should be digitally signed by the concerned person.
____________________________________________________________________

IBM Registration Number

2. Mining Lease Code
3. Mine Code
4. Name of mine /Old name of mine (in case of change in name)
5. Name and address of the lessee/owner
(Information will be system generated. Linked with Entry 3 of Form ‘K’.)

6. Date of opening/reopening of mine
7. In case of reopening, date of discontinuation
8. Particulars of the Mining Lease (ML)
(Information will be system generated. Linked with Entry 4 of Form ‘K’)
9. Location of the Mining Lease
(Information will be system generated. Linked with Entry 4 of Form ‘K’)

46

<!-- page 56 -->

10. Name and address of previous owner
if any and the date of abandonment of Mine

Name

Address

E-mail

Mobile no.

E-mail

Mobile no.

11. Name and address of Agent of Mine
Name

Address

12. Particulars of Mining Engineer employed in the mine:
(Information will be system Generated. Linked with Entry 8 and 9 of Form ‘H’.)

13. Particulars of Geologist employed in the mine
(Information will be system Generated. Linked with Entry 8 and 9 of Form ‘H’.)

14. Particulars of Manager employed in the mine
(Information will be system Generated. Linked with Entry 8 and 9 of Form ‘H’.)

15. Letter No. and date through which the mining
plan was approved by the Indian Bureau of
Mines or State Government concerned

Place:
Date:
Signature
Name in full:
Designation: Owner/Agent/Mining Engineer/Manager

47

<!-- page 57 -->

FORM-D
[See rule 21(2)]
(Notice of intention of abandonment of mine or part of the mine)

IMPORTANT INSTRUCTIONS FOR FILLING THE FORM





1.

This Form, duly filled in must reach the concerned authorities as prescribed within the rule,
within ninety days of the of the date of intention of abandonment, by online or Email.
This should be sent to the Regional Controller in whose territorial jurisdiction the Mining
lease area falls as notified from time to time by the Controller General, Indian Bureau of
Mines, under rule 66 of the Mineral Conservation Development Rules, 2016.
The form should be digitally signed by the concerned person.
____________________________________________________________________

IBM Registration Number

2. Mining Lease Code
3. Mine Code
4. Name of mine
5. Name and address of the lessee/owner
(Information will be system generated. Linked with Entry 3 of Form ‘K’.)

6. Particulars of the Mining Lease (ML)
(Information will be system generated. Linked with Entry 4 of Form ‘K’)

7. Location of the Mining Lease
( Information will be system generated. Linked with Entry 4 of Form ‘K’)

48

<!-- page 58 -->

8. Letter No. and date through which the Final Mine Closure
plan was approved by the Indian Bureau of
Mines or State Government concerned

9. Date of abandonment

10. Reasons for abandonment

[Please tick whichever is applicable]

i) Lack of demand
ii) Exhaustion of ore/mineral
iii) Un-economic operations
iv) Unable to obtain forest clearance

11. Upto date Total Resources of Mineral(s) in Mining Lease area (in tonne) as per UNFC:

A) Mineral Reserve
i) Proved Reserve (111)

ii) Probable Reserve (121 and 122)

B) Remaining Resources

i) Feasibility Mineral Resources (211)

ii) Pre Feasibility Mineral Resources (221 and 222)

iii)Measure Mineral Resources (331)

49

<!-- page 59 -->

iv)Indicated Mineral Resources (332)

v)Inferred Mineral Resources (333)

vi)Reconnaissance Mineral Resources (334)
C) Total Resources (A + B) =………………… (tonnes)

12. Number of workers employed in the mine:

Male

Female

a) Company labour

b) Contract labour

c) Total

Place:
Date:
Signature
Name in full:
Designation: Owner/Agent/Mining Engineer/Manager

50

<!-- page 60 -->

FORM-E
[See rule 28(1) and 28(2)]
(Notice of temporary discontinuance of mine)

IMPORTANT INSTRUCTIONS FOR FILLING THE FORM






This Form, duly filled in must reach the concerned authorities as prescribed within the rule,
within one hundred and twenty days of temporary discontinuance of work in the mine, by
online or Email. If the discontinuance is due to natural calamity beyond the control of the
lessee or Government Orders, this notice shall be sent within fifteen days of such occurrence
by online or E mail.
This should be sent to the Regional Controller in whose territorial jurisdiction the Mining
lease area falls as notified from time to time by the Controller General, Indian Bureau of
Mines, under rule 66 of the Mineral Conservation Development Rules, 2016.
The form should be digitally signed by the concerned person.
____________________________________________________________________

1.

IBM Registration Number

2. Mining Lease Code
3. Mine Code
4. Name of mine
5. Name and address of the lessee/owner
(Information will be system generated. Linked with Entry 3 of Form ‘K’.)
6. Particulars of the Mining Lease (ML)
(Information will be system generated. Linked with Entry 4 of Form ‘K’)

7. Location of the Mining Lease
(Information will be system generated. Linked with Entry 4 of Form ‘K’)

51

<!-- page 61 -->

8. Date of temporary discontinuance
9. Reasons for temporary discontinuance

[Please tick whichever is applicable]

i) Lack of demand

ii) Non-availability of labour
iii) Rains

iv) Transport bottleneck
v) Strike/Lockout
vi) Operations becoming un-economic
vii) Other reasons (specify)
10. Probable date of re-opening of the mine

Place:
Date:
Signature
Name in full:
Designation: Owner/Agent/Mining Engineer/Manager

52

<!-- page 62 -->

FORM-F
[See rule 30(2)]
(Notice of commencement of stoping)
IMPORTANT INSTRUCTIONS FOR FILLING THE FORM






This Form, duly filled in must reach the concerned authorities as prescribed within the rule,
within sixty days before the commencement of stoping operations, by online or E mail.
This should be sent to the Regional Controller in whose territorial jurisdiction the Mining
lease area falls as notified from time to time by the Controller General, Indian Bureau of
Mines, under rule 66 of the Mineral Conservation Development Rules, 2016.
The form should be digitally signed by the concerned person.
Information in respect of items 8 and 9(a) should be accompanied by (i) underground
composite plan, (ii) longitudinal section, (iii) geological/assay plan of the levels at which
stoping is proposed including one level above and below, and (iv) transverse sections at
reasonable intervals for the portion covered under (iii) above.
____________________________________________________________________

1.

IBM Registration Number

2. Mining Lease Code
3. Mine Code
4. Name of mine

5. Name and address of the lessee/owner
(Information will be system generated. Linked with Entry 3 of Form ‘K’.)

6. Particulars of the Mining Lease (ML)
(Information will be system generated. Linked with Entry 4 of Form ‘K’)

7. Location of the Mining Lease
(Information will be system generated. Linked with Entry 4 of Form ‘K’)

53

<!-- page 63 -->

8.

Section/pit number
(This is applicable in cases where the main mine is divided into more than one
district/section/pit.)

9. Date on which it is proposed to commence stoping

10. Extent of development in the mine:
(a) Number of shafts/inclines/and its
width/depth/length

___________________________

(b) Maximum depth and development

_____________________

(c) Number of levels with their extent

____________________

(d) Total meterage of development

__________________

(e) Total number of blocks developed including
the total tonnage and grade (excluding blocks
already stoped out and already permitted for stoping)
____________________________
11. . Details of the blocks applied for stoping
(a) Number and size of each block,
their levels tonnage and grade
____________________________
(b) Method of stoping to be adopted –
(i)

(ii)

(iii)

(iv)

A description of the method with
stope preparation sequence of operation
appropriate drawings to illustrate the
and extraction

_____________________________

Rate of stoping contemplated
in each block (monthly)

____________________________

Estimated recovery from
each block

___________________________

Estimated dilution

____________________________

54

<!-- page 64 -->

(v)

Estimated tonnage and grade
of ore to be extracted
___________________________

12. Is this a first application for stoping for this mine?
If not, the following details may be furnished.
(i)

Date of previous application(s) for stoping

____________________________

(ii)

Date and reference of permission or
refusal by this department (mention
blocks and their levels)
__________________________________________

(iii)

Have all the blocks for which stoping
permission was granted, been stoped out?
If not, mention the specific blocks that are
remaining to be stoped out, indicating the state
of stoping operations therein:

13. Rate of development and programme of forming
Additional stope blocks simultaneously with the
Proposed stoping

_____________________________

___________________________

14. List of enclosures
__________________________________

Place:
Date:
Signature
Name in full:
Designation: Owner/Agent/Mining Engineer/Manager

55

<!-- page 65 -->

FORM F1
[See rule 45(5) (b) (i)]
For the month of ________20
MONTHLY RETURN
[To be used for minerals other than Copper, Gold, Lead, Pyrites, Tin, Tungsten, Zinc and precious
and semi-precious stones]

To

(i)

The Regional Controller of Mines
Indian Bureau of Mines
_________Region,
PIN:

(Please address to Regional Controller of Mines in whose territorial jurisdiction the mines falls as
notified from time to time by the Controller General, Indian Bureau of Mines under rule 62 of the
Mineral Conservation and Development Rules, 1988)

(ii) The State Government
PART – I
(General and Labour)
1. Details of the Mine:
(a) Registration number allotted by Indian Bureau of
Mines
(to give registration number of the Lessee/ Owner)
(b) Mine Code (allotted by Indian Bureau of Mines )
(c) Name of the Mineral
(d) Name of Mine
(e) Name(s) of other mineral(s),
if any, produced from the same mine
(f) Location of the Mine :
Village

56

<!-- page 66 -->

Post Office
Tahsil/Taluk
District
State
PIN Code
Fax no:

E-mail:

Phone no:

Mobile:

2. Name and address of Lessee/Owner (along with fax no. and e-mail):
Name of Lessee/Owner
Address
District
State
PIN Code
Fax no:

E-mail:

Phone No:

Mobile:

3. Details of Rent/ Royalty / Dead Rent/ DMF /NMET amount paid in the month
(i) Rent paid (₹)
(ii) Royalty paid (₹)
(iii) Dead Rent paid ( ₹)
(iv) Payment made to the DMF ( ₹)
(v) Payment made to the NMET ( ₹)
4. Details on working of mine:
(i) Number of days the mine worked:
(ii) Reasons for work stoppage in the mine during the
month (due to strike, lockout, heavy rain, nonavailability of labour, transport bottleneck, lack of
demand, uneconomic operations, etc.) and the
number of days of work stoppage for each reason
separately

57

Reasons

No of days

<!-- page 67 -->

5. Average Daily Employment and Total Salary/Wages paid #:

Work place

Direct
Male

Female

Contract
Male

Total Salary/Wages (₹)

Female

Direct

Contract

Below ground
Opencast
Above ground
Total
# To include all employees exclusive to the mine and attached factory, workshop or mineral dressing
plant at the mine site
PART-II (PRODUCTION, DESPATCHES AND STOCKS)
(To be submitted separately for each mineral)
(Unit of Quantity in Tonnes)
1. Type of ore produced:
(Applicable for Iron ore only; tick mark whichever is applicable)
(a) Hematite
(b) Magnetite
2. Production and Stocks of ROM ore at Mine-head
Category

Opening stock

Production

Closing stock

(a) Open Cast workings
(b) Underground Workings
(c) Dump workings

3(i) Grade-wise ROM ore despatches from mine head ($):
Grade of ROM@

Despatches from mine-head

Ex-mine Price (₹)

($): Applicable for iron ore and chromite only. For other minerals data of dispatches to be reported
in 3(ii)

58

<!-- page 68 -->

3(ii) Grade-wise Production, Dispatches, Stocks and Ex-mine prices:
Grades**

Opening stock at
mine- head

Production

Despatches
from
mine-head

Closing
stock at
mine-head

Ex-mine
price
(₹/Tonne)

3(iii) In case the mineral is being pulverized in own factory, please give the following particulars
(*):

Grade**

Total
quantity of
mineral
Pulverized
(in tonnes)

Total quantity of
pulverized mineral
produced
(for each mesh size)
Mesh size
Quantity
(tonne)

Total Quantity of pulverized mineral
sold during the month

Mesh size

Quantity
(tonne)

Ex-factory Sale
value (₹)

3(iv) Average cost of pulverization (*) : ₹ _______ per tonne.
(*): Not applicable for Iron ore, Manganese ore, Bauxite and Chromite

4. Details of deductions made from sale value for computation of Ex-mine price (₹/ Tonne)
Deduction claimed #

Amount
( in ₹/ Tonne)

a) Cost of transportation
(indicate loading station and distance from
mine in remarks)
b) Loading and unloading charges
c) Railway freight, if applicable
(indicate destination and distance)
d) Port handling charges/ export duty
(indicate name of port)
e) Charges for sampling and analysis
f) Rent for the plot at Stocking yard
g) Other charges
(specify clearly)
Total (a) to (g)

# Not applicable for captive dispatches and ex-mine sales

59

Remarks

<!-- page 69 -->

5. Sales/ Dispatches effected for Domestic Purposes and for Exports:
Grade
(^)

Nature of
Despatch
(indicate
whether
Domestic
Sale or
Domestic
Transfer or
Captive
consumption
or Export)

Registration
number as
allotted by
the Indian
Bureau of
Mines to the
buyer ##

For Domestic Purposes
Consignee Quantity
name ##

Sale
value
(₹)

Country

For export
Quantity

F.O.B
Value(₹)

(^): To indicate the grades of ores as mentioned below (see @ and **)
## To indicate separately if more than one buyer.
NOTE:- Mine owners are required to substantiate domestic sale value/ FOB value for each grade of
ore quoted above with copy of invoices (not to be submitted with the return; to be produced whenever
required).
6. Give reasons for increase/decrease in production/nil production, if any, during the month
compared to the previous month.
a)
b)
c)
7. Give reasons for increase/decrease in grade wise ex-mine price, if any, during the month
compared to the previous month.
a)
b)
c)
I certify that the information furnished above is correct and complete in all respects.

Place:
Date:

Signature
Name in full:
Designation: Owner/Agent/Mining Engineer/Manager

60

<!-- page 70 -->

@Grades of ROM ore dispatched:
MINERAL GRADES
Iron ore

a) Below 51% Fe ROM
b) 51% to below 55% Fe ROM
c) 55% to below 58% Fe ROM
d) 58% to below 60% Fe ROM
e) 60% to below 62% Fe ROM
f) 62% to below 65% Fe ROM
g) 65% and above Fe ROM

Chromite

a) Below 40% Cr2O3 ROM
b) 40% to below 52 % Cr2O3 ROM
c) 52% and above Cr2O3 ROM

**Grades of minerals to be reported in the above tables are as given below. (If separate grades
are not mentioned below, report the mineral name against grade):
MINERAL
Iron ore

GRADES
(i) Lumps:
a) Below 51% Fe
b) 51% to below 55% Fe
c) 55% to below 58% Fe
d) 58% to below 60% Fe
e) 60% to below 62% Fe
f) 62% to below 65% Fe
g) 65% and above Fe
(ii) Fines:
a) Below 51% Fe
b) 51% to below 55% Fe
c) 55% to below 58% Fe
d) 58% to below 60% Fe
e) 60% to below 62% Fe
f) 62% to below 65% Fe
g) 65% and above Fe
(iii) Concentrates
(iv) Calibrated Lump Ore (CLO)
(Quantity already reported in Lumps should not be reported
against CLO)
a) Below 62% Fe (CLO any size)

61

<!-- page 71 -->

b) 62% to below 65% Fe (5-18 mm size CLO)
c) 62% to below 65% Fe (10-40 mm size CLO)
d) 62% to below 65% Fe (CLO others)
e) 65% and above Fe (5-18 mm size CLO)
f) 65% and above Fe (10-40 mm size CLO)
g) 65% and above Fe (CLO others)
Manganese Ore

(i) Ore
a) Below 25% Mn
b) 25% to below 35% Mn
c) 35% to below 46% Mn
d) 46% and above Mn
e) Dioxide ore
(ii) Concentrates

Bauxite

Chromite

Asbestos
Fluorite/Fluorspar

(i) For use in alumina and aluminium extraction:(Please also furnish the actual averages of the ore falling
within the following ranges of grades):
a) Below 40% Al2O3
b) 40% to below 45% Al2O3
c) 45% to below 50% Al2O3
d) 50% to below 55% Al2O3
e) 55% to below 60% Al2O3
f) 60% and above Al2O3
(ii) For use other than alumina and aluminium metal extraction
a) Cement
b) Abrasive
c) Refractory
d) Chemical
(i) Lumps
a) Below 40% Cr2O3
b) 40% to below 52 % Cr2O3
c) 52% and above Cr2O3
(ii) Fines
a) Below 40% Cr2O3
b) 40% to below 52 % Cr2O3
c) 52% and above Cr2O3
(iii) Concentrates
a) Amphibole
b) Chrysotile
a) 80% and above CaF2
b) 70% to below 80% CaF2
c) 30% to below 70% CaF2
d) Below 30% CaF2

62

<!-- page 72 -->

Graphite

a) With 80% or more fixed carbon
b) With 40 % or more fixed carbon but less than 80% fixed
carbon
c) With 20% or more fixed carbon but less than 40% fixed carbon
d) With less than 20% fixed carbon

Kyanite
Limestone

Rock Phosphate/
Phosphorite

a) 40% and above Al2O3
b) Below 40% Al2O3
a) LD Grade (less than 1.5% silica content)
b) SMS
c) BF
d) Chemical
e) Cement
a) Above 30% P2O5
b) Above 25% to 30% P2O5
c) Above 20% to 25% P2O5
d) Upto 20% P2O5

63

<!-- page 73 -->

FORM F2
[See rule 45(5) (b) (ii)]
For the month of ________20
MONTHLY RETURN
[To be used for minerals Copper, Gold, Lead, Pyrites, Tin, Tungsten and Zinc]

To

(i)

The Regional Controller of Mines
Indian Bureau of Mines
_________Region,
PIN:

(Please address to Regional Controller of Mines in whose territorial jurisdiction the mines falls as
notified from time to time by the Controller General, Indian Bureau of Mines under rule 62 of the
Mineral Conservation and Development Rules, 1988)

(ii) The State Government
PART – I
(General and Labour)

1. Details of the Mine:
(a) Registration number allotted by Indian Bureau of
Mines
(to give registration number of the Lessee/ Owner)
(b) Mine Code (allotted by Indian Bureau of Mines )
(c) Name of the Mineral
(d) Name of Mine
(e) Name(s) of other mineral(s),
if any, produced from the same mine
(f) Location of the Mine :
Village

64

<!-- page 74 -->

Post Office
Tahsil/Taluk
District
State
PIN Code
Fax no:

E-mail:

Phone no:

Mobile:

2. Name and address of Lessee/Owner (along with fax no. and e-mail):
Name of Lessee/Owner
Address
District
State
PIN Code
Fax no:

E-mail:

Phone No:

Mobile:

3. Details of Rent/ Royalty / Dead Rent/ DMF /NMET amount paid in the month
(i) Rent paid (₹)
(ii) Royalty paid (₹)
(iii) Dead Rent paid ( ₹)
(iv) Payment made to the DMF ( ₹)
(v) Payment made to the NMET ( ₹)
4. Details on working of mine:
(i) Number of days the mine worked:
(ii) Reasons for work stoppage in the mine during the
month (due to strike, lockout, heavy rain, nonavailability of labour, transport bottleneck, lack
of demand, uneconomic operations, etc.) and the
number of days of work stoppage for each reason
separately

65

Reasons

No of
days

<!-- page 75 -->

5. Average Daily Employment and Total Salary/Wages paid #:
Work place

Direct
Male

Contract

Female

Male

Total Salary/Wages (₹)

Female

Direct

Contract

Below ground
Opencast
Above ground
Total
# To include all employees exclusive to the mine and attached factory, workshop or mineral dressing
plant at the mine site
PART-II (PRODUCTION, DESPATCHES AND STOCKS)
(To be submitted separately for each mineral)
(Unit of Quantity in Tonnes; indicate unit of quantity if not in tonnes)
1. Production and Stocks of ROM ore
Opening stocks
Quantity

Metal
content/
grade

Production
Quantity

Metal
content/
grade

Closing stocks
Quantity

Metal
content/
grade

A. From Underground
workings
i) From Development
ii) From Stoping
B. From Opencast
workings
Total

2. Ex-mine price of the ore produced (₹ per unit):

3. Recoveries at Concentrator/Mill/Plant:
Opening stocks of the Ore at

Ore received from the mine

Ore treated

concentrator/plant
Quantity

Metal content/
grade

Quantity

Metal content/
grade

66

Quantity

Metal content/
grade

<!-- page 76 -->

Concentrates * Obtained
Quantity

Metal
content/
grade

Tailings

Value
(₹)

Quantity

Closing stocks of concentrates
at the concentrator/plant
Quantity
Metal content/
grade

Metal
content/
grade

*In case of any leaching method adopted, give quantity recovered and grade contained separately.
4. Recovery at the Smelter/Mill/Plant:
Opening Stocks of the
concentrates at the
smelter /plant

Concentrates received
from concentrator/plant

Concentrates received
from
other sources
(specify)

Quantity

Quantity

Quantity

Metal
content/
grade

Concentrates treated

Quantity

Metal
content/
grade

Metal
content/
grade

Closing stocks of
concentrate at the
Smelter/Plant
Quantity
Metal
content/
grade

Metal
content/
grade

Metals(*) recovered
(specify)
Quantity

Grade

Concentrates sold
(if any)

Quantity

Metal
content/
grade

Other by-products, if any,
recovered

Value Quantity
(₹)

Grade

Value
(₹)

(*) Please give category-wise break-up viz. blister, fire refined copper, cathodes, electrolytic
copper wire bars, lead ingots, zinc cathodes, zinc dross, gold, tungsten etc.

5. Sales during the month:

Metal/
Product

Opening stocks of
Metals/Products
Quantity

Place of
sale

Grade

Metals/Products sold(@)
Quantity

Grade

Value(#)
(₹)

Note:
(#) Please give ex-plant sale value.
(@) Please give category-wise break-up of metals and other products sold.

67

Closing stocks of
Metals/Products
Quantity

Grade

<!-- page 77 -->

6. Details of deductions made from sale value for computation of Ex-mine price (₹/ Unit)

Deduction claimed #

Amount
( in ₹/ Unit)

Remarks

a) Cost of transportation
(indicate loading station and distance from
mine in remarks)
b) Loading and unloading charges
c) Railway freight, if applicable
(indicate destination and distance)
d) Port Handling charges/ export duty
(indicate name of port)
e) Charges for sampling and analysis
f) Rent for the plot at Stocking yard
g) Other charges
(specify clearly)
Total (a) to (g)
# Not applicable for captive dispatches and ex-mine sales
7. Sales/ Dispatches of ore and concentrates effected for Domestic Purposes and for Exports:

Grade
(ore/
Conc.)

Nature of
Despatch
(indicate
whether
Domestic
Sale or
Domestic
Transfer or
Captive
consumption
or Export)

Registration
number as
allotted by
the Indian
Bureau of
Mines to the
buyer ##

For Domestic Purposes
Consignee Quantity
name ##

Sale
value
(₹)

Country

For export
Quantity F.O.B
Value(₹)

## To indicate separately if more than one buyer.
NOTE: - Mine owners are required to substantiate domestic sale value/ FOB value for each grade
quoted above with copy of invoices (not to be submitted with the return; to be produced whenever
required).

68

<!-- page 78 -->

8. Give reasons for increase/decrease in production/nil production, if any, during the month
compared to the previous month.
a)
b)
c)
9. Give reasons for increase/decrease in grade wise ex-mine price, if any, during the month
compared to the previous month.
a)
b)
c)
I certify that the information furnished above is correct and complete in all respects.

Place:
Date:

Signature
Name in full:
Designation: Owner/Agent/Mining Engineer/Manager

69

<!-- page 79 -->

FORM F3
[See rule 45(5) (b) (iii)]
For the month of ________20
MONTHLY RETURN
[To be used for precious and semi-precious stones]
To

(i)

The Regional Controller of Mines
Indian Bureau of Mines
_________Region,
PIN:

(Please address to Regional Controller of Mines in whose territorial jurisdiction the mines falls as
notified from time to time by the Controller General, Indian Bureau of Mines under rule 62 of the
Mineral Conservation and Development Rules, 1988)

(ii) The State Government
PART – I
(General and Labour)

1. Details of the Mine:
(a) Registration number allotted by Indian Bureau of
Mines
(to give registration number of the Lessee/ Owner)
(b) Mine Code (allotted by Indian Bureau of Mines )
(c) Name of the Mineral
(d) Name of Mine
(e) Name(s) of other mineral(s),
if any, produced from the same mine
(f) Location of the Mine :
Village
Post Office
Tahsil/Taluk
District

70

<!-- page 80 -->

State
PIN Code
Fax no:

E-mail:

Phone no:

Mobile:

2. Name and address of Lessee/Owner (along with fax no. and e-mail):
Name of Lessee/Owner
Address
District
State
PIN Code
Fax no:

E-mail:

Phone No:

Mobile:

3. Details of Rent/ Royalty / Dead Rent/ DMF /NMET amount paid in the month
(i) Rent paid (₹)
(ii) Royalty paid (₹)
(iii) Dead Rent paid ( ₹)
(iv) Payment made to the DMF ( ₹)
(v) Payment made to the NMET ( ₹)
4. Details on working of mine:
(i) Number of days the mine worked:
(ii) Reasons for work stoppage in the mine during the
month (due to strike, lockout, heavy rain, nonavailability of labour, transport bottleneck, lack of
demand, uneconomic operations, etc.) and the
number of days of work stoppage for each reason
separately

71

Reasons

No. of days
