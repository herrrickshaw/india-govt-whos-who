---
doc_id: "a2c48ba2be817aaa"
source_url: "https://gmcnagpur.org/upload/tender/calibration.pdf"
ministry: "Government Medical College and Hospital Nagpur (MS), Maharashtra"
title: "Quotations"
date: ""
pages: 2
method: "tesseract:mar+hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "1edd3c79b932acb3"
---

<!-- page 1 -->

GMCNGP-01028/310/2026-GMC-NGP 1/2873014/2026
Quotation UPC Ref NO./Col/Pur/QuoUGMENGP-01029/310/2026
Immediate Office of the Dean,

Govt. Medical College, Nagpur.
Date :- 23/10 / 2026
To,

Sub :- Submission of e-quotation for calibration of instruments at Pathology and state VRDL under
Department of Microbiology, Govt. Medical College Nagpur.

The undersigned invited sealed quotation for the below on reverse as per enclosed statement for
the use of Medical college, Nagpur. on the following terms and conditions.

1) The prices quoted should be for delivery at college premises for local dealers and for Nagpur for

out siders. i

2) The prices quoted by inclusive of all taxes, duties payable like custom excise GST. The breakup of
the taxes should also be shown separately where necessary. The sales tax and registration No
should be quoted in your letters, Exemption of taxes, if on AF form etc be separately attached.

3) The serial no of the items should not be changed while quoting rates. You may dropped in item if not

interested.

4) Rates should be quoted strictly for the items specified in the list and for standard quality of goods.
Incase of alternate offer, the detailed specification. Name of manufacturer or make etc. must
invariable be stated, specification other than specified in the schedule may be liable for rejection
aven thought lowest.

5) The quotation submitted rates will be valid for the period for one year only from the date of
१९९९७8 nce.

6) Delivery period should be stated specifically like ready stock, two weeks/four weeks ete and should
be firm and supply of stores if ordered should be made with in the stipulated period Failures are
liable for delist from the further offers.

7) The quotation received after the due date will not be accepted. The quotation should be submitted in
the sealed cover. Unsealed quotation will not be accepted. The last date of receiving the
quotationis dt. 30/10 / 2026 at. 05:00 PM.

8) Supply of stores should be made in one installment unless otherwise ordered place meal supply will
not be accepted. Payment will be made within 4 to 8 weeks after receipt of full quantity and bill
in quadruplicates and only satisfactory report of working etc. or part payment will not be
accepted.

9) Quotation if asked with samples if not accompanies with sample will be liable for re rejection even

they are lowest sample should be sent with a liable attached quoting our ref. No of enquiry &
item No. etc.

10) The Dean, Govt. Medical College, Nagpur. Does not pledge himself to accept the lowest or any
quotation and reserve to himself right of acceptance of any quotation which suits to his
requirements.

11) Very Important :- In case you are not interested in quoting your rates in reply to this enquiry a line

in reply is a must failing are liable for desisting their names for further enquires is from our list
and no further request in this matter will be entertained.

12) Literature, instructions showing specifications working etc. may also be sent with quotations.

13) All the nomenclature, descriptions, make , pack size and rates should not be quoted with pencil or
ink pen, if found, will be rejected and will not be considered. All details mentioned in the
quotations must be printed or computerized typed :-

Q Scanned with OKEN Scanner

<!-- page 2 -->

GMCNGP-01029/310/2026-GMC-NGP W7292301472026
[me
Se
[Remi
[06 | Mini Centrifuge for PCR tubes [Remi
[Remi

D2
(व [icttonowerenem (Suncom ||
Vertical Ultra Deep Freezer -20C
3) MDF25V268E
काजा
=
[acini ऋएएएाशतननशनाा
[Wore
ee “000077|
i
[ni [ao2000
1) Eppendorf-02 2) Finepipette — 01
| * | 3)Westmed - 01
patrons 1111111]
ळ्या 7711
a [1 1111111111 |
1111010011 ल 111111 य]
|
ee १]
[Samsung
1 कया स्य...
कडला 11111र्‍र्‍र्‍ पा
Micro Pipette Ct
Digitally signed by
RA) NARENDRA GAJBHIYE
Date: 23-10-2026
15:56:29
(Dr. Raj Gajbhiye)
Dean,
Govt. Medical College,
Nagpur
(& Scanned with OKEN Scanner
