---
doc_id: "c47b0dbfbcbeb3fb"
source_url: "https://cdnbbsr.s3waas.gov.in/s369dafe8b58066478aea48f3d0f384820/uploads/2025/01/202501031925549504.pdf"
ministry: "Animal Husbandry Department, Maharashtra"
title: "Tender Notice_ Plasticware"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9307ba26a0890061"
---

<!-- page 1 -->

MAHARASHTRA STATE
OFFICE OF THE JOINT COMMISSIONER ANIMAL HUSBANDRY,
INSTITUTE OF VETERINARY BIOLOGICAL PRODUCTS, AUNDH, PUNE 411007
Address: Institute of Veterinary Biological Products, Aundh, Pune 411007

Email:jcivbp-mh@mah.gov.in

TENDER NOTICE
FOR RATE CONTRACT
FOR THE SUPPLY OF PLASTICWARES
Joint Commissioner of Animal Husbandry, Institute of Veterinary Biological Products,
Aundh, Pune-07 invites bidding in two envelope system from the Recognized Manufacturers /
Authorized Distributors for Supply of Plastic wares for the Veterinary Institutes of Animal
Husbandry Department, Government of Maharashtra for a period of one year (Extendable for one
year at a time with maximum two extensions on the basis of quality of Plastic wares supplied) from
the date of finalization of Tender as specified in the Tender Terms and Conditions.
Interested eligible Bidder may obtain further information of technical specifications,
required quantities and other terms and conditions applicable for procurement of above items from
the e-Tender website,https://mahatenders.gov.in.
The online e-tender Time Schedule (Key Dates) is displayed on the above e-tendering portal.
Tender form along with Terms & Conditions can be downloaded from above websites w.e.f. 27/12/2024
to 13/01/2025. The tender fee Rs. 18000(Form fee) + Rs. 3240 (18% GST) = Rs.21240.00 (Rs. Twenty
one thousand two hundred and fortyonly) and the EMD Rs. 180000/- (Rs. Onelakhs eighty thousand
only) payment shall be made online mode during the online tender process. The bidder can pay EMD
either for individual products or all the products together mentioned in Annexure-A& AnnexureB as per the choice.

(Dr. Y. A. Pathan)
Joint Commissioner of Animal Husbandry,
Institute of Veterinary Biological Products,
Aundh, Pune-07
OutwardNo.IVBP/Store section/e-Tender/Plasticware/ 3807/2024, Date: 27/12/2024
