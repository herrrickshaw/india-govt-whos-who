---
doc_id: "5f06bed3fccdafca"
source_url: "https://www.coeptech.ac.in/wp-content/uploads/2024/03/AMENDMENT-for-Quotation-Invitation-ESM-for-Campus.pdf"
ministry: "COEP Technological University, Pune, Maharashtra"
title: "AMENDMENT for Quotation-Invitation -ESM-for -Campus – last submission date 26/03/2024"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6829b0752ff5998d"
---

<!-- page 1 -->

Ref. No. COEP/Gathering/23-24/063-A

Date: 25/03/2024

AMENDMENT to Invitation of Quotation
To,
All possible vendors
Subject: Amendment for change of last date of submission for quotation invitation for the ESM
work for Campus decoration and refreshment from 26-03-2024 to 31-03-2024
Reference: No. COEP/Gathering/23-24/063 dated 19-03-2024
In respect of invitation of quotation with above reference number and dated 19-03-2024,
following amendment is authorized and issued.
READ AS
You are invited to submit your most
competitive quotation for the above-mentioned
subject as per the specification given below on
or before 26/03/2024 upto 12 noon.

INSTEAD OF
You are invited to submit your most
competitive quotation for the above-mentioned
subject as per the specification given below on
or before 25/03/2024 upto 12 noon.

Other content and terms and conditions of the said invitation of quotation remain unchanged.
.
Sd/
Director BOSD,
COEP Tech.
