---
doc_id: "a3f5ab33bbdee013"
source_url: "https://dbatu.ac.in/wp-content/uploads/2026/10/Notification-for-ACAP-Round-for-First-Year-M.-Pharm-2026-27-27.10.2026-1.pdf"
ministry: "Dr. Babasaheb Ambedkar Technological University, Maharashtra"
title: "Open in new tab"
date: ""
pages: 1
method: "tesseract:mar+hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "e8bffa2988676770"
---

<!-- page 1 -->

डॉ.बाबासाहेब आंबेडकर तंत्रशास्त्र विद्यापीठ , लोणेरे
* tes Dr. Babasaheb Ambedkar Technological University, Lonere
wey. विद्याविहार, लोणेरे-रायगड ४०२ १०३ (महाराष्ट्र) Vidyavihar, Lonere - Raigad 402 103 (Maharashtra)
> om Tel: (02140) 275142 ऋछछ Student Helpline: 02140 - 275212
Website: www.dbatu.ac.in, E-mail: registrar@dbatu.ac.in
__ ७ ७ नया का a a डड हमी नी...
DBATU/ACAP Admission/2026-27/4 20 Date — 24/10/2026
(ACAP/Institute Level Admission against vacancy of CAP A. ४. 2026-27)
It is hereby notified to all concerned candidates that the ACAP / Institute Level Admission
Round against the vacancies remaining after CAP for the Academic Year 2026-27 shall be
conducted by Dr. Babasaheb Ambedkar Technological University, Lonere, as per the
schedule given below.
Sr. No. Name of Program Date & Time
Date: 28/10/2026
M. Pharmacy. (First Year)
Time : 10.30 AM
ethan
SS
owe (Dr. S. M. Pore)
co २२९७ Teas हु TRAR
© wigs RES PARR
(s LONERE! a Dr, Babasaheb Ambedkar Technological University
3 ऱ्य Lonere - 402103
(३२७८. , Tal. Mangaon Dist. Raigad (Maharashtra)
ry
