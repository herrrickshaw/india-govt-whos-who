---
doc_id: "5aef854dd69cd9dd"
source_url: "https://cdn.s3waas.gov.in/s3ae0eb3eed39d2bcef4622b2499a05fe6/uploads/2020/03/2020032326.pdf"
ministry: "Ramban"
title: "Order for Closure of all schools and colleges"
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "14c1055e92c24bcd"
---

<!-- page 1 -->

od
GOVERNMENT OF JAMMU & KASHMIR
OFFICE OF THE DISTRICT MAGISTRATE RAMBAN
E-mail: dcramban-jk@nic.in Fax/Ph. 01998-26906, 266789
Sub:- Order under section 144 CrPC for closure of all Schools/Colleges in District
Ramban- regarding.
ORDER

Whereas, the prevailing health situation due to novel Coronavirus (COVID-19) has
given rise to serious concerns in India and in J&K as well; and

Whereas, COVID-19 has a pattern of transmission at a rapid rate in case prescribed
preventive protocols, like avoiding mass gatherings etc., are not strictly followed; and

Whereas, it is felt that students should not be sent to Schools/Colleges to avoid mass
gatherings; and

Whereas, section 144 of CrPC empowers the undersigned to issue certain
directions/orders in urgent cases of nuisances of apprehended danger when it is
considered that such direction is likely to prevent danger to human life, health or safety.

As such for reasons mentioned above, it is hereby ordered that the class work in all
educational institutions (Schools & Colleges) of District Ramban (Govt. and Private) shall
remain suspended with immediate effect. However, the staff shall remain present on duty.
Board and College/Universities examinations shall be held as per schedule.

This order shall remain in effect till 31st of March 2020. Since, it is not possible to
serve this order individually, it shall be circulated in Print, Electronic and Social Media for
information of all concerned.

Any violation of this order shall invite action under Indian 7 ‘od
‏ای اح‎ 74 68 i
Date:- }/-0%—2o2o0 «3 GN Sane

é ۵ \ TBI | ——
‏0ے‎ oy o
‏:6ت‎ 0 ۱ 11820
8 ey JO} Nazim ٠ an (KAS)}
empe ‏امت‎ ' 8 ie
Copy to the:
1. Divisional Commissioner, Jammu for information.
2. Senior Superintendent of Police, Ramban for information.
3. Sub-Divisional Magistrate, Gool/Banihal/Ramsoo for information & n/a.
4. Principal, Govt. Degree College, Ramban/Batote/Gool/Ukhral/Banihal for info. & n/a.
5. Chief Education Officer, Ramban for information & n/a.
6. Tehsildar, Ramban/Banihal/Gool/Ramsoo/Ukhral /Khari/Batote/Rajgarh for info. & n/a.
7. District Information Officer, Ramban for vide circulation of the Order.
8. All concerned for compliance.
