---
doc_id: "beeaec74ba196bba"
source_url: "https://smvdu.ac.in/wp-content/uploads/2023/06/27042018_Order-PDT-Training-at-IIM-Raipur-during-7-11-May2018.pdf"
ministry: "Shri Mata Vaishno Devi University, Katra, Jammu and Kashmir"
title: "Order-Deputing of 02 Nos. of Faculty members for Professional Development Trainings (PDTs) under TEQIP Phase-III at IIM Raipur"
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "8ccd13e7c22cfbbb"
---

<!-- page 1 -->

‎of orn Son eat 1۹73‏ ف۵۵
‎Shri Mata Vaishno Devi University‏ 4
‎a Kakryal, Katra-182320 (J&K)‏
‎ees 95.04, 2018‏
‎No: SMVDU/Adm./Estt./18/ 3 0 30- 39 Dated: 27 .04. 2018‏
‎ORDER‏
‎Sub: Deputing of 02 Nos. of! of Paculty members for Professional Development Trainings (PDTs) members for Professional Development Trainings (PDTs‏
‎under TEQIP Phase-IIl at IIM Raipur Phase-III at IIM Raipur‏
‎Sanction of the Competent Authority is hereby conveyed for deputing of the following‏
‎Faculty Members of SMVDU fo» Professional Development Trainings (PDTs) under TEQIP Phase-HII‏
‎during the following period ;‏
‎S. | Name & Designation of 1 Place of Posting Period of | Place/Venue of |‏
‎No. Faculty Member Training Training‏
‎Dr, Amit Kant Pandit School of Electronics &‏ | 1
‎Associate Professor Communication Engineering‏
‎to IIM Raipur‏ 07-05-2018
‎Dr. Manoj K Gupta School of Computer Science 11-05-2018‏ | 2
‎Associate Professor & Engineering‏
‎TA/DA shall be available to the : bove faculty members, out of funds available under TEQIP Phase — II],‏
‎for the aforesaid purpose‏
‎Further, the above Faculty members shall be considered on duty, during the above said period and shall‏
‎also submit their Evaluation/Grade sheets to Faculty I/c Examinations, before proceeding for the above‏
‎training programs. They shall also submit a report on the proceedings of the trainings alongwith their‏
‎respective attendance/participaticn certificates, if any, and joining reports respectively.‏
‎al‏
‎Copy to: :‏
‎Dean, FoE, SMVDU for nformation. 5‏ .1
‎Head, School of Computer Science & Engineering for information.‏ ,2
‎Head, School of Electronics & Communication Engineering for information. .‏ .3
‎Dr. Sumeet Gupta, TEQIP Co-ordinator, SMVDU for information.‏ .4
‎Finance Officer, SMVDUJ for information.‏ ,5
‎Faculty I/c Examinations for information.‏ .6
‎PS to VC, for the kind information of Hon’ble Vice Chancellor.‏ .7
‎Concerned _ 3‏ .8
‎Faculty I/e Website for ploading the same on University website.‏ .9
‎Personal files of the concerned.‏ .10
‎Order file‏ .11
