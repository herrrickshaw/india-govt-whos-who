---
doc_id: "13f848ffdef2abc8"
source_url: "https://cdn.s3waas.gov.in/s3884d247c6f65a96a7da4d1105d584ddd/uploads/2026/09/17903202123562.pdf"
ministry: "Baramulla"
title: "Appointment order of BHD Coordinators under Mission YUVA"
date: ""
pages: 3
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "e58cb9d6d683bd4a"
---

<!-- page 1 -->

کر
‎Government of Union Territory‏ ۱
‎y Of Jammu and Kashmi‏
‎OFFICE OF THE DISTRICT DEVELOPMENT COMMISSIONER‏ |
٦ر‏ کپ 9 ۷ئ ‎——_______BARAMULLA‏
‎Subject: A‏
‎heen an Order for Contractual Engagement of the positions of‏ 1
‎oordinators under Mission YUVA.‏
‎Order No.: L563‏
‎Dated: 24/09 / 2026‏
‎a In pursuance to the Mission YUVA Operational Guidelines issued vide No.‏
‎के /Plan/Mission YUVA/233/368-414 dated: 18-07-2025 its related amendments, and‏
‎ased on the recommendations of the District Selection Oversight Committee, Baramulla,‏
‎sanction is hereby accorded to the appointment of the following provisionally selected‏
‎candidates for contractual engagement under Mission YUVA against the Business Help‏
‎Desk (BHD) Coordinator positions, as indicated below:‏
‎Name of Father's oes Post‏
‎Candidate | Full Name Address District | alloted‏ اھ
‎Sheikh Alsafa colony,‏
‎Sh ‘‏
ات ‎kartar garh, sopore | Baramulla ८‏ مر
‎Hassan baramulla | cabal  म‏
‎Abdul Rashid | Nehalpora pattan | 1 BHD‏
‎Rashid Mir Baramulla jaramul'a | Coordinator‏
‎Saleem Shabeer j BHD‏
تا ‎et‏ ۸۴
‎Nature of Engagement‏ .1
‎The engagement shall be purely contractual and governed by the terms and‏
‎conditions stipulated in the Mission YUVA guidelines. It shall not confer any right or claim‏
‎for permanent absorption or continuation beyond the approved project period.‏
‎Contractual Duration and Renewal‏ .2
‎The initial period of engagement shall be eleven (11) months from the date of‏ «
‎joining.‏
‎Upon completion of the initial term, performance shall be reviewed based on‏ ¢
‎predefined Key Performance Indicators (KPIs) specified by Mission YUVA. रे‏
‎The contract may be renewed for a further period of eleven (11) months, subject‏ «
‎to satisfactory performance and approval from the competent authority, till the‏
‎project life of Mission YUVA.‏
‎Scanned with OKEN Scanner‏ 9

<!-- page 2 -->

3. Roles and Reporting:
Duties and reportin
5 aa 9 structure will ali 1 ‏ل1‎ :
Operational Guidelines Of Mission YUVA, align with guidelines laid down in the
i Terms and Conditions
» The selected Candida’
te shall report to the Assi i
Baramulla (member secretary Mission YUVA) along Director Employment, DE&CC
Original, within 07 (seven) days of issuanc rite 9 with following documents, in
formalities and verification of ‏کت‎ a is order for completion of joining
* Domicile Certificate, :
* Date of Birth
* All Qualifications Certificates.
* Experience Certificates and Sal i izati
lary Slips of last orga
* Undertaking, ry Slip: ganization/company
* Character Certificate issued by competent authority.
* Bank Account Details
* Pan Card/Aadhaar Card
2 Non-reporting within the stipulated time shall be deemed as unwillingness to join,
and the next eligible candidate from the approved waiting list shall be considered for
engagement.
3. The candidate shall execute a formal contractual agreement specifying:
¢ Terms of engagement and service conditions
¢ Specific roles, responsibilities, and deliverables
e Performance evaluation and reporting mechanisms
¢ Compensation structure and payment terms
e Disciplinary and termination provisions
4. The monthly consolidated remuneration shall be paid as per the norms prescribed in
the Mission YUVA guidelines for the respective post, subject to verification of all
documents and experience certificates.
5. The engagement shall be subject to verification of character, antecedents, and
authenticity of documents. i हि | हर
6. The appointee shall maintain the highest standards of integrity, discipline, an
confidentiality while discharging official duties. 7 ‏تم‎ ibs
: 7 tl ۲ 3 i 1۷۵۲0۲ ‏ا5‎
‎7. The vacancy, if any, arising due 0 non reporting of any candidate/mo
accommodated from the waiting list as per merit.
5. Termination of Contract
i ime under the following
The contractual. engagement may be terminated at any ti
conditions: jodi ations.
+ Non-performance or unsatisfactory performance as per ‏سید سا‎
ti c i ination, or any act of misconduct.
* Violation of code of conduct, दम मद ”
» Falsification or misrepresentation of do ۰
9 Scanned with OKEN Scanner

<!-- page 3 -->

‎Prolonged Unauthorized‏ . می
‎Engagement in aches absence beyond seven consecutive working days,‏ °
‎icti 1 oe .‏ 6 ; 1
‎involving political afflians = Conflicting with the objectives of Mission YUVA or‏
‎YUVA / Director ६‏ شس نہ
‎District Nodal Officer shall have th " mployment / SPV upon recommendation of the‏
‎BHD Personnel at any time ding e absolute authority to terminate the contract of any‏
‎contractual agreement uring the contract period, with appropriate notice as per the‏
‎All terms ۰+‏
‎operational a Conditions shall be governed as per Mission YUVA‏
‎@s for SBDUs and BHDs.‏
‎Sd/-‏
‎Deputy Commissioner,‏
‎Baramulla‏
‎No: 4D ty B/m-yuv 22‏
‎Dated: 94 999496.‏
‎Copy for information to the:‏
‎Secretary, Labour & Employment Department, J&K for information.‏ .1
‎Director Employment-cum-Mission Director, Mission YUVA, J&K.‏ .2
‎All Empanelment/Oversight Committee members for information.‏ .3
‎District Informatics Officer (NIC Baramulla) for information and with the instructions to‏ .4
‎upload the order on District Website.‏
‎Assistant Director Employment Baramulla for information and na.‏ .5
‎District Treasury Officer Baramulla for information.‏ .6
‎PA to DC Baramulla for kind information of Deputy Commissioner 8 I‏ .7
‎All Concerned candidates.‏ .8
‎Office record/file.‏ .9
‎Chief Planning Officer‏
‎Baramulla‏
‎Q Scanned with OKEN Scanner‏
