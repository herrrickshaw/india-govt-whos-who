---
doc_id: "fbe3dbf0a1cd8919"
source_url: "https://jkssb.nic.in/Pdf/supplementary_DV_22092026.pdf"
ministry: "Jammu and Kashmir Services Selection Board, Jammu and Kashmir"
title: "Notification regarding Supplementary Document Verification of candidates falling under consideration zone for the post of Prosthetic/Orthotic Technician, Junior Dental Technician, Junior Store Clerk, Sanitary Inspector, Junior Ophthalmic Technician, Junior Staff Nurse/Junior Male Nurse and Staff Nur"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "20a9d01ab5ade92a"
---

<!-- page 1 -->

GOVERNMENT OF JAMMUAND KASHMIR

JAMMU & KASHMIR SERVICES SELECTION BOARD

Muthi, Akhnoor Raod, Jammu/Zamzam Complex Rambagh Srinagar.
www.jkssb.nic.in

NOTIFICATION

Subject: Supplementary Document Verification of candidates falling under consideration

zone for the post of Prosthetic/Orthetic Technician Junior Dental Technician,

Junior Store Clerk, Sanitary Inspector, Junior Ophthalmic Technician, Junior Staff
Nurse/Junior Male Nurse and Staff Nurse Grade-II, Health and Medical Education
Department, advertised vide Advertisement Notification No. 07 of 2025 dated:
22.07.2025 under various Item Nos.- regarding.
Allsuch candidates who are falling under consideration zone and were called for

Document Verification vide Notification No. No.JKSSB-COEOEXAM(UT)/3/2026 (7909564)
dated: 10-09-2026, for the post of Prosthetic/Orthetic Technician Junior Dental

Technician, Junior Store Clerk, Sanitary Inspector, Junior Ophthalmic Technician, Junior

Staff Nurse/Junior Male Nurse and Staff Nurse Grade-II, Health and Medical Education
Department, advertised vide Advertisement Notification No. 07 of 2025 dated: 22.07.2025
under various Item Nos., but could not appear before the Document Verification

Committee(s) on 18-09-2026, due to various reasons, are hereby given last and final
opportunity to appear before the Document Verification Committee on 25.09.2026 from
11:00 AM to 04:00 PM at JKSSB, Central Office, Muthi, Akhnoor Road, Jammu (Jammu
Centre Based Candidates) and JKSSB, Central Office, Zam Zam Complex,
Rambagh,
Srinagar (Kashmir Centre Based Candidates), failing which no further claims in this
regard
shall be entertained at any stage.

22.642026

(Reyaz Ahmad Malik) JKAS
Controller of Examinations

J&K Services Selection Board

No.: JKSSB-COEOEXAM(UT)/26/2026-03

Copy tothe:

Dated:2-09-2026

1. Commissioner/Secretary to the Government, General Administration

Secretariat, J&K.

Department, Civil

2. Director, Information and Public Relations, J&k, with the request to
Notification in at-least two leading local newspapers of Jammu/Srinagar. publish this
3. All Members, J&K Services Selection Board.
4. Secretary, J&K Services Selection Board.
5. PA to the Chairman, J&K Services Selection Board for the information of
the Chairman.
6. I/c Website, J&K Services Selection Board.
