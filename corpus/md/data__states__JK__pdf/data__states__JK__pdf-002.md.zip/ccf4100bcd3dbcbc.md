---
doc_id: "ccf4100bcd3dbcbc"
source_url: "https://jkssb.nic.in/Pdf/Extension_Notice_08OF2026_09102026.pdf"
ministry: "Jammu and Kashmir Services Selection Board, Jammu and Kashmir"
title: "Notification regarding Extension in the last date for submission of Online Application Forms for UT/Divisional/District Cadre posts in various Department(s), advertised vide Notification No. 08 of 2026 dated 04.08.2026."
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fb492ce6aedde268"
---

<!-- page 1 -->

GOVERNMENT OF JAMMU AND KASHMIR
JAMMU AND KASHMIR SERVICES SELECTION BOARD
Muthi, Akhnoor Road, Jammu/ZamZam Complex, Rambagh, Srinagar

(www.jkssb.nic.in)

--------------------------------------------------------------------------------Subject: Extension in the last date for submission of Online Application Forms for
UT/Divisional/District Cadre posts in various Department(s), advertised
vide Notification No. 08 of 2026 dated 04.08.2026.
NOTICE
Whereas, the J&K Services Selection Board (JKSSB), vide Advertisement Notification
No. 08 of 2026 Dated: 04.08.2026, invited online applications from eligible candidates for
participating in the selection process for various UT/Divisional/District Cadre posts in various
Department(s); and
Whereas, the last date for submission of online application forms in this regard was
notified as 09.10.2026; and
Whereas, the Jammu & Kashmir Services Selection Board has received various
representations from the candidates for considering extension in the last date for filling of
application forms; and
Whereas, the matter has been examined and it has been decided to extend the last
date for submission of online application forms for the aforementioned posts.
Now therefore, the last date for submission of online application forms in respect of
UT/Divisional/District Cadre posts in various Department(s) advertised vide Notification No. 08 of
2026 Dated: 04.08.2026, shall be 24.10.2026, instead of 09.10.2026.
Note: Candidates are advised in their own interest, to submit online applications much before the

closing date and not to wait till the last date so as to avoid the possibility of disconnection/ Inability
or failure to login to the website on account of heavy load during the closing days.

Sd/(Khurshid Ahmad Sanai) JKAS,
Secretary,
J&K Services Selection Board.
No. JKSSB-PLAN/6/2025-03 (E-7661495)

Dated: 09.10.2026.
1

<!-- page 2 -->

Copy to the:
1. Financial Commissioner (Additional Chief Secretary), Agriculture Production Department,
Civil Secretariat, Jammu/Srinagar.
2. Commissioner/Secretary to Government, General Administration Department.
3. Commissioner/Secretary to the Government, Health and Medical Education Department.
4. Commissioner/Secretary to the Government, Higher Education Department.
5. Administrative Secretary to the Government, Labour and Employment Department.
6. Divisional Commissioner, Kashmir/Jammu.
7. Director Employment, J&K.
8. Director, Information and Public Relations, J&K for publishing this Notice in all leading
dailies of J&K for three consecutive days.
9. Additional Resident Commissioner, J&K Government, 5-Prithvi Raj Road, New Delhi.
10. Director, Door Darshan Kendra, Jammu / Srinagar for telecasting the substance of the
notice for three consecutive days in addition to the Rozgar Bulletin.
11. Director, Radio Kashmir Jammu/ Srinagar/Bhaderwah/Kupwara for airing this Notice on air
for three consecutive days in addition to the Rozgar Bulletin.
12. All Members, J&K Services Selection Board.
13. Controller of Examinations, J&K Services Selection Board.
14. Administrative Officer, J&K Services Selection Board, Srinagar/Jammu.
15. In-Charge, Planning Section, J&K Services Selection Board.
16. Private Secretary to the Chief Secretary, J&K.
17. PA to the Chairman, J&K Services Selection Board.
18. In-Charge Website, J&K Services Selection Board

2
