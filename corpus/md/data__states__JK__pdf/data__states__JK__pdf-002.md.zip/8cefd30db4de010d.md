---
doc_id: "8cefd30db4de010d"
source_url: "https://jakega.jk.gov.in/Resources/AI%20policy%20framework.pdf"
ministry: "Online Building Permission System and CLU Application Portal, Jammu & Kashmir"
title: "AI Framework"
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d1bfba2a2ffa5e8b"
---

<!-- page 1 -->

Jammy & Kashmir’s Artificial Intelligence Framework, 2023

Page 1 of 9

<!-- page 2 -->

JAMMU & KASHMIR’S ARTIFICAL INTELLIGENCE (AI) FRAMEWORK

Artificial Intelligence (AI), is becoming an integral part of every single facet
of our lives. Artificial Intelligence by definition is “the ability of a machine or
Computer system to copy human intelligence processes, learn from experiences,
adapt to new information and perform human-like activities.” For AI enabled
processes and machines, all the data is equivalent to what experiences and
information has been to humans.
The following key factors have enabled the growth and expansion of
Artificial Intelligence:
•

The volume of digital data

•

Ease of storing the data

•

Exponential improvement of computing power

It is estimated that the computing power needed to train AI is now rising
much faster than ever before. The computing power of systems used for man’s
first expedition to moon is at least 4 times less powerful than a current smart
phone. As the industries embark up on the journey to make Artificial Intelligence
an integral part of their operations, decision making and marketing, Government
will be playing a pivotal role. Governments are responsible for providing a
conducive ecosystem for research and innovation, companies, startups, training
organizations, regulatory bodies for a technology like Artificial Intelligence to
prosper.
Vision: Establish Jammu & Kashmir as a leader in Artificial Intelligence and
foster social innovation.
The Government of Jammu & Kashmir is committed to adopting emerging
technologies and it recognizes the central role that Artificial Intelligence plays in
building an enabling environment for emerging technologies. Jammu & Kashmir
has shown a phenomenal growth in IT services in last few years. J&K has been
ranked number one amongst all the Union Territories in the NeSDA ranking of
DARPG.

Page 2 of 9

<!-- page 3 -->

Aligning with the vision to be a front runner in emerging technologies, the
Government of Jammu & Kashmir in collaboration with all the stakeholders like
educational institutions, researchers, government departments, startups and other
organizations will ideate initiatives that will catalyze the adoption of Artificial
Intelligence in Jammu & Kashmir.

AI Framework
In an effort to position Jammu & Kashmir to achieve a prominent
position in use of AI, J&K Government proposes the following framework:

Key Pillars

1.

1.

Data Exchange Platform and HPAIC

2.

Skilling and Education

3.

Governance, Ethics and Privacy

4.

Research and Innovation

5.

Security in AI

Data Exchange Platform and HPAIC
• UT’s Open Data Exchange Platform: Jammu & Kashmir shall
formulate its Open Data Policy followed by the development of
Jammu & Kashmir’s Open Data Portal to host various datasets.
Collaboration across departments and research organizations is
important to increase the quality and volume of data that can be used
to train Artificial Intelligence algorithms. After building the core data
sets from government and implementing the data provider
certifications, a Data Exchange Platform will be operated by the
government where all the AI partners can upload relevant and useful
datasets. An Open Data Exchange Platform will increase the cross
collaboration across various stakeholders and will foster innovation in
the arena of Artificial Intelligence. For ease of use, data visualization
tools and data narratives will be enabled for this data. APIs will also
be developed to provide access to static and real time data.
• Creating Public Sector Datasets: Data availability is the primary
prerequisite for Artificial Intelligence. Specific data sets owned by
Page 3 of 9

<!-- page 4 -->

various government departments would be one of the most invaluable
datasets for all the stakeholders. Government of Jammu & Kashmir
will collaborate with educational and research institutes to identify
such relevant data sets and will provide them in the state’s open data
platform. Government aims to ensure that the datasets of the
identified focus areas are created and are available for public use in
due course.
• Collaboration with Corporates to Create Datasets: The AI of today
is heavily dependent on the collection, usage and processing of data.
In the process of collecting useful datasets, the government will
collaborate with research institutions for collecting data sets that can
be shared with a wider pool of innovators.
• Data Provider Certifications: Data plays a vital role in developing
AI services. But it is equally important to ensure that the datasets are
safe, ethical and of high-quality. Hence, the State will initiate a
Certification program for the data providers (Government, Research
institutions and Industry) which focuses on the theme of ethics for
shared data and would be as per the Data Privacy Law that is to be
enacted by the Government of India.
• Establishing a High-Performance AI Computing Facility:
Computers with accelerated hardware are capable of increasing the
speed of the system that governs Artificial Intelligence. With the
continuous increase in the volume of data, the requirement for HighPerformance AI Computing facilities is constantly increasing. Access
to High-Performance AI Computing (HPAIC) infrastructure is an
important prerequisite for AI.
IT Department to take up with IIT J&K, CDAC and other
institutes, to offer High-Performance AI Computing (HPAIC)
infrastructure as a shared facility to boost local AI-innovation
capacities of academia, SMEs, startups and for social impact
projects in Jammu & Kashmir.
2.

Skilling and Education
Page 4 of 9

<!-- page 5 -->

Special programs need to be ideated and initiatives planned to build
the AI oriented talent pool in Jammu & Kashmir.

3.

•

AI-focused up skilling:
Data labelling, annotation, preparation,
structuring and cleansing tasks account for more than 80% of the time
involved in most AI and machine-learning projects. Government of Jammu
& Kashmir will train BPOs and other similar workforce for data labelling
roles to capture this opportunity.

•

AI Startup Internship Program: UT will partner with
incubators/accelerators to offer Jammu & Kashmir’s college students the
opportunities to work with AI startups, and receive college credits on
successful completion of internship. The program would culminate with a
Hackathon-to foster innovation, applied learning and peer learning.

•

AI Talent Alignment: AI focused curriculum and faculty development
programs would be developed based on inputs given by AI product
companies, to bridge the skill-gap in the job market. These courses would
be delivered across the UT in partnership with skilling partners.

•

Foundation of AI for All: A set of courses which can be offered for free
would be posted on online platforms of UT. The UT would organize
webinars across Jammu & Kashmir universities, featuring pioneers of AI.
Governance, Ethics and Privacy
Availability and access to accurate data is the cornerstone for any
Artificial Intelligence related research and Artificial Intelligence becoming
an integral component of day to day life, we must ensure that data which is
used to run all the AI algorithms is trustworthy, fair and ethical.
Protecting the privacy of citizens of Jammu & Kashmir is of utmost
importance to the government of Jammu & Kashmir. Government envisions
taking all the necessary steps to ensure highest level of transparency.

• Artificial Intelligence Ethics Committee: The government shall ensure
that artificial intelligence and machine learning algorithms are as ethical as
they are intelligent. A Working Committee will be established to identify the
key AI ethical concerns - Accountability, Bias, Transparency, Privacy,
Security and Safety-and develop sector specific guidelines for AI use cases.
Page 5 of 9

<!-- page 6 -->

The Committee will be led by academicians from top institutes and consist
of representatives from government, industry and research bodies etc.
The Working Committee would prepare and release a set of advisory
guidelines, codes of practice, governance frameworks and will recommend
various mechanisms to operationalize the recommendations. This would
ensure ethical usage of data and bias-free decision-making algorithms to
safeguard the privacy of citizens. Companies operating using the data
published by government or affiliated authorities will be required to share a
compliance report detailing the ethical and appropriate usage of data.
• Guidelines for ethical usage of data : The UT will be developing
guidelines for data integrity and retention policies. Moreover, data security
measures applicable to the service including how data is collected using the
service will be securely stored and accessed. The UT government will be
defining its data governance guidelines, in alignment with the government
policies.
• Government AI Procurement Guidelines: In consultation with the AI
Ethics Working Committee, the government will adopt recommended AI
procurement guidelines. These may include encouraging the use of
explainable AI to ensure that AI decision-making (i.e. the decisions and/or
insights generated by AI) is as transparent as possible. The government may
also explore mechanisms to enable interpretability of the algorithms
internally and externally as a means of establishing accountability and
contestability.
• Training the user government agencies: Operational or service staff
must have enough knowledge or training on the solution to understand how
to use it. The training must include, but not be limited to: the capabilities and
limitations of the AI service, procedures to interpret and act on the output of
the service; and as applicable to the deployment context, understand where
human review is required for decisions that produce legal effects concerning
individuals.
• AI innovation domains: The UT will accelerate AI Innovation efforts in
domains like agriculture and allied sectors, education and skill development,
industry, health care, rural and urban development, power development, law
Page 6 of 9

<!-- page 7 -->

enforcement, mobility and improving citizen’s centric delivery of services.
4.

Research and Innovation
• Academic Collaboration:The UT will enter into partnerships with reputed
universities/research centers to facilitate cross learning - via exchange
programs for faculty and research students. Government of Jammu
& Kashmir will also rope in premier educational institutions in the state for
the same.
• Patenting Guidelines for AI – based Innovations:It is necessary to support
the startups/SMEs/innovators which come out with new Intellectual
Property. Many of the innovators don’t protect their own intellectual
property because of lack of awareness and process expertise. The
government will engage experts from techno-legal domain to educate
innovators about the importance and procedure of IPR filing.
• Government-priority Applied Research: Government may offer research
grants to academicians working in applied AI for focus areas of the UT.

5.

Security in AI
The importance of data security in AI systems is becoming
increasingly important. In Government, data security is a major concern on
account of substantial amount of sensitive information being handled. AI,
specifically generative AI relies heavily on data for training and decisionmaking, making it vulnerable to potential security risks.
Some major compelling reasons underlying the critical need for data
security in AI systems are data privacy, data tampering, deliberate attacks by
insiders, risks associated with mass adoption, AI-driven attacks etc.
The UT of J&K will put in place regulations and compliances that
shape data security in AI systems viz. data protection, data sovereignty &
localization, ethical AI use, auditing, accountability and cyber security
standards.
The UT will ensure adherence to principles for ensuring data security
in AI systems like encryption, data loss prevention (DLP), data
classification, tokenization, data masking and data-level access control in
Page 7 of 9

<!-- page 8 -->

accordance with national standards and guidelines issued by MeitY,
Government of India.
*****

Page 8 of 9

<!-- page 9 -->

Page 9 of 9
