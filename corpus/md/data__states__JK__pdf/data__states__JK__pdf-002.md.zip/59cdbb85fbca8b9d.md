---
doc_id: "59cdbb85fbca8b9d"
source_url: "https://fcsca.jk.gov.in/pdf/orders/2026/Order_2026_03.pdf"
ministry: "Department of Food, Civil Supplies & Consumer Affairs, Jammu & Kashmir"
title: "Grant of Anywhere LTC for the current block, 2024-25 in favour of Mr. Inder Jee Bhat, Junior Assistant, Food, Civil Supplies and Consumer Affairs Department, J&K."
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "05200bcb01f75592"
---

<!-- page 1 -->

|
Government of Jammu and Kashmir
Department of Food, Civil Supplies & Consumer Affairs
Civil Secretariat, J&K: Jammu
Subject:- 6:30۲ ۴ Anywhere LTC, for the Current block, 2024-25 in favour of Mr. Inder Jee
Bhat, Junior Assistant, Food, Civil Supplies and Consumer Affairs Department, JK,
Government Order No.03 -JK(FCS&CA) of 2026 8
Dated:/9 -01-2026
In pursuance of S.0 22 dated 3% of December, 2019, post-facto sanction is hereby
accorded to the grant of Anywhere LTC for the block year 2024-2027 w.e.f 05.01.2026 to
09.01.2026 in favour of Mr. Inder Jee Bhat, Junior Assistant, Department of FCS&CA to visit
Chandigarh along with his family members, subject to the following conditions:-
i. The claim is covered under (LTC) Rules, 2019.
li. The official or his dependents have not availed such concession earlier during
the LTC block 2024-27,
iii. Entry to this effect is recorded in the service book of the official by the DDO
iv. The dependency of the family members on the official is established under rules
by the DDO.
۷ Journey to Chandigarh is Performed by the shortest route.
vi. The entitlement is regulated by the concerned Drawing and Disbursing officer
under rules,
Further, five (05) days casual leave for Anywhere LTC for the block year 2024-
2027 w.e.f 05.01.2026 to 09.01.2026 is also sanctioned in favour of the official.
By order of Government of Jammu and Kashmir
Sd/- :
(Saurabh Bhagat) IAS
Commissioner/ Secretary to the Government,
No:- FCSCA-Estt/184/2024-09/(E-7585389) Dated:!9-01-2026
Copy to the:-
1, Joint Secretary (Jammu, Kashmir & Ladakh), Ministry of Home Affairs,
Government of India.
2, Director, Archives, Archeology and Museums, J&K, :
3. Director Finarice, Department of FCS&CA, J&K
4. Private Secretary to Commissioner/Secretary to the Government, Department of
FCS&CA, J&K
5. Mr, Inder Jee Bhat, Junior Assistant, Department of FCS&CA, J&K
6. Monday Returns File.
Ki Government Order file (w.3.s.c)/Stock file ۲ :
wings
ma ۲ ‏ابی‎ 5
हि Secretary to the Government
