---
doc_id: "cc0d25aae4cd54e7"
source_url: "https://jkssb.nic.in/Pdf/Syllabus_13OF2025_21102026.pdf"
ministry: "Jammu and Kashmir Services Selection Board, Jammu and Kashmir"
title: "Syllabus for the various posts advertised vide Notification No. 13 of 2025 dated 26.12.2025."
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "7bc1cd6b3f3c8e1e"
---

<!-- no text layer: pending OCR -->
