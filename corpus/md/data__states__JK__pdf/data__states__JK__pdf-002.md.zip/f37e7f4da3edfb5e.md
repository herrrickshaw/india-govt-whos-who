---
doc_id: "f37e7f4da3edfb5e"
source_url: "https://hme.jk.gov.in/assets/pdf/GO702.pdf"
ministry: "Health and Medical Education Department, Jammu and Kashmir"
title: "G.O. No.702 → Medical reimbursement claim in favour of Dr.Arjun Singh, Medical Officer, on account of treatment of Mr. Adhavan, his three -year -old son"
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "af76a5451b4b51e3"
---

<!-- page 1 -->

Government of Jammu and Kashmir
Health and Medical Education Department
Civil Secretariat, J&K.
* KOK OK OK
Subject:- Medical reimbursement claim in favour of Dr. Arjun Singh, Medical Officer,
on account of treatment of Mr Adhavan, his three-year-old son.
Reference:- Principal, Government Medical College, Dodas, letter No. GMC/Acctts/2026-
27/333-34 dated 15.05.2026.
Government Order No: +02 -JK (HME) of 2026
Dated: 1%-09-2026
Sanction is hereby accorded to the reimbursement of medical expenses
amounting to ¥%16,28,012/- (Rupees Sixteen Lakh Twenty-Eight Thousand
Twelve only) in favour of Dr. Arjun Singh, Medical Officer, incurred on the treatment of
his son Mr.Adhavan, subject to the following conditions:
1. Verification of the Referral Certificate issued by the competent Government hospital
/authority.
2. Verification of the Essentiality Certificate duly issued by the authorized Medical
Officer.
3. Verification of the original bills, vouchers, prescriptions, discharge summary and
other supporting documents.
4. The treatment/institution being recognized/approved under the applicable medical
reimbursement rules.
5. Reimbursement being restricted to the admissible amount as per the applicable
Government rules/rates, including AIIMS rates, wherever applicable.
By order of the Government of Jammu and Kashmir.
Sd/-
M.Raju(IAS)
Commissioner/Secretary to the Government
Health and Medical Education Department.
No.HME-Acct/244/2026-04-(CC- 7763440 ) Dated: 14 -09- 2026
Copy to the:
1. Principal Accountant General, J&K, Srinagar.
2. Financial Commissioner,(Additional Chief Secretary) Finance Department, J&K.
3. Joint Secretary (J&K), Ministry of Home Affairs, Government of India.
4. Principal, Government Medical College, Doda.
5. Concerned Treasury Officer.
6. Dr. Arjun Singh, Medical Officer.
7. Private Secretary to Commissioner/Secretary to the Government,Health and Medical
Education, Department,J&K.
8. Government Order file/ stock file. 0 0 if
je
Reyaz Ahmad oF
‏وت‎ Finance 4
