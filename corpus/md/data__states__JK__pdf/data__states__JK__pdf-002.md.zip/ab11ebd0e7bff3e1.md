---
doc_id: "ab11ebd0e7bff3e1"
source_url: "https://jkocmms.nic.in/SPCB_DOCUMENTS/gazetteofindia0001.pdf"
ministry: "Pollution Control Committee, Jammu and Kashmir"
title: "The Gazette of India."
date: ""
pages: 3
method: "tesseract:eng+urd+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "9913c1082f4c9fa5"
---

<!-- page 1 -->

5 / GoaretkeOfrtep 3|4۴
/
(रन [india pf
रजिस्ट्री सं” डी० एल०-3300499 Gia, _REGD.NO.D.1.-330459
0
(05 2)
311401 के
CAT
‏ات ہے‎
Che Gazette of 6٥9
¥
असाधारण
EXTRAORDINARY
भाग 1--खण्ड 3--उप-खण्ड (1)
PART Hl—Section 3—Suh-sootion (i)
प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY,
से, छठ)... _ नई दिल्ली, मंगलवार, मई 4, 20102बैशाख 18, 1932.
: No. 837) NEW _DELIIE, TUESDAY, MAY 4, 2010/VAISAKIIA 14, 1932
प्रयविरण और बन मंत्रालय रजिस्ट्रीकृत व्यौहारियों को ही बिक्रोत की
अधिसूचना ‏ک وی‎
‏سم کی‎ 4 नई, 3000 Gi) इंस प्रकार अंत ःस्थापित उप-नियम (,४1) के पश्चात्‌
का.आ. 1092(अ).--केन्द्रीय सरकार, पर्यावरण (संरक्षण) a रिप्पण अंतस्थापित किया जाएगा,
अधिनियम, 1986 (1986 का 29) की घारा 6, धारा 8 और घारा rR
25 द्वार प्रदत्त शक्तियों का प्रयोग करते हुए, बैटरी (प्रबंधन और 'टिप्पण :--भमायोजकों तथा मरम्मतकर्ताओं को
धालन) तियम, 2001 का संशोधन करने के लिए निम्नलिखित ऐसे दायितवों को परिधि से अपवर्णित किया गया हैं
नियम बनाती है, अर्थात्‌ :-. जो उप-खंड (1६), उप-खंड (६1४), उप-खंड (४)
(1). इल वियमों का संक्षिप्त नाम बैटरी (प्रबंधन और तथा (331) में विशिर्दिष्ट है
हथालन) संशोधन नियम, 2010 है । 4. उक्त नियमों के नियम 5 के स्थान घर निम्नलिखित नियम
(2). ये राजपञ़ में प्रकाशन को तारीख को प्रवृत्त होंगे।. ज जाएगा, अर्धात
2. बैटरी (प्रबंधन और हथालन) नियम, 2001 (जिसे इसमें “5, अयात कर्ताओं का रजिस्ट्रीकरण.--(3) अयातकर्ता
इसके पश्चात्‌ उक्त नियम कहा गया है) के नियम 3 में, खंड (च) प्ररूप । के अनुसार पांच वर्ष की अवधि के लिए केन्द्रीय
के स्थान पर निम्नलिखित खंड रखा जाएगा, अर्धात्‌ :-- प्रदूषण तियंत्रण चोर्ड के पास रजिस्टर करेगा और उक्त नियमों
"' (च) अपुंज उपभोक्ता से केद्रीय सरकार के रेल, के अनुसार अपेक्षित संख्या में प्रयुक्त बैटरियों क॑ संग्रहण में
रक्षा, दृरछचार, डाक तथा तार जैसे विभागों राज्य असफतत्ता, केन्द्रीय प्रदूषण नियंत्रण चोर्ड को एक प्रति सहित
सरकार के विभागों उपक्रमों, बो्डों तथा अन्य राज्य प्रदूषण नियंत्रण बोर्ड को समय पर अर्धकर्षिक विवरणियां
अभिकरणों या कंपनियों जैसे ऐसे उपभोक्ता अभिप्रेत अस्तुत न करने के लिए रहकरण, रजिस्ट्रोकरण के नवोकरण
हैं, जो प्रतिकर्ष एक सौ या एक सौ से अधिक का उपबंध अनुपालन प्रास्थिति के अनुसार होगा
चैटरियां क्रय करते हैं" । परन्तु आयातकर्ता प्रदस रजिस्ट्रीकरण तब. तक रद्द नहीं किया
3. उक्त नियमों के नियम 4 में जाएगा जब तक उसे सुक्ाई 'का युक्त युवत अवसर प्रदान
(3) उप-नियम (9) के पश्चात्‌ निम्नलिखित ‏سو‎ कहीं कर दिया गया हो;
अंतःस्थापित किया जाएगा अर्थात्‌ :-- (४) कोई अपील, केद्रीय प्रदूषण नियंत्रण बोर्ड क॑ सदस्य
“Cxii) यह सुनिश्चित करें कि नई बैटरियां केबल सचिव या केस्द्रीय प्रदूषण नियंत्रण बोर्ड द्वारा पदानिहित किसी |
0 0 शत
tt |

<!-- page 2 -->

a THE GAZETTE OF INDIA: EXTRAORDINARY __[Panr Sec. 3(i)]
आत्य अधिकारी द्वारा पारित किया गया रजिस्ट्रीकरण के निलस्बन Gi) ‏سس اي یبس سز اج‎
या रहकरण या इंकार किए जाने के किसी आदेश के विरुद्ध आयातकर्ता/प्रपुंज उपभोक्ता का नाम और पता प्रविष्टि
होगी; रखी जाएगी;
(४) अपील लिखित में होगी और उसके साथ उस आदेश की (॥) स्तम्भ 3 में विद्यमात प्रविष्टि में शब्द "बेची गई”
एक प्रति संलग्न की जाएगी जिसके विरुद्ध अपील की गई है शब्द के पश्चात्‌ “आयातकर्ता या उपभोक्ता"! शब्द
और यह आदेश पारित किए जाने की तारौख से तीस दिन की ना 27 = Ba ee
‏سی ڈیہ سے 0۱وت وم‎ (1४) और उससे at ae
है oan के स्थान पर निम्नलिखित प्ररूप और प्रविच्टियां रखी जाएगी
5. उक्त नियमों के नियम 7 में, खंड (५) के पश्चात _र्चातू :
निम्नलिखित खंड अंतःस्थापित किया जायेगा अर्थात्‌ : - a
“ (५४) (क) प्ररूप के अनुसार ब्यौरे प्रस्तुत करने के लिए देखें
2 ‏ات‎ ee . (fram 4 aft Frm 7 (vii) Sa)
एज्य प्रदूषण नियंत्रण वर्ष की hated
™“ eae i 7 ‏نہ‎ . ub व्यौहासियों के रजिस्ट्रोकरण के लिए प्ररूप
eee a eel ‏کچ َ "ھ2‎ [ज्यौहारियों द्वार राज्य प्रदूषण नियंत्रण बोर्ड/प्रदृषण नियंत्रण
संख्या राज्य प्रदूषण नियंत्रण बो्डों को समय पर अर्धवार्चिक समितियों के समझ प्रस्दुत किया जाए)
िवराणियां प्रस्तुत न करने क लिए रदकरण, सॉजस्ट्रीकरण कं... व्यौहारियों का नाम और पता,
जवीकरण का उपबंध अनुपालन प्रास्थिति के अनुसार होगा, om तथा फैक्स संख्या सहित
यदि तीस दिन की अवधि के मौतर आश्षेप नहीं किया जाता है 2 टिना/बैट संख्या*
तो रॉजिस्ट्रीकरण को रजिस्ट्रीकृत समझा जाएगा ' >यदि लागू हो (वर्तमान राज्य बिक्री कर नियमों के अनुसार, अनिवार्य
- परन्तु व्वौहारी को प्रदत्त रजिस्ट्रीकरण तब तक रद्द नहों किया. टित/वैट संख्या केवल तभी अपेक्षित है जब व्यौहारियों का वार्षिक |
जाएगा जब तक उसे सुनवाई का युक्ति युक्त अबसर प्रदान. आवर्त बिहित मूल्य से अधिक हो ) । है i
जहों कर दिया जाता; प्राधिकृत व्यक्ति के हस्ताक्षर ।
ae a a
(a) कोई अपील, राज्य प्रदूषण नियंत्रण बोर्ड के सदस्य
के iam the किसी तारीख |
सचिक या राज्य प्रदूषण नियंत्रण बोर्ड द्वार पदानिहित किसो |
cram [23-22/2005-एचएसएमडी ]
अन्य अधिकारी द्वारा पारित रजिस्ट्रीकरण क॑ निलम्बन या |
(कए जाने के किसी हि राजीव गौबा, संयुक्त सचिव
रहकाण या इंकार किए आदेश So
- ۰ जाने के किसी आदेश के ۰ ‏ہا:× ٭ ×ص: ود ٭ مو سے , ہے‎
fi संख्या नं. का.आ. 432 (अ) तारीख ।6 मई, 200। ‏جج‎
‎(ग) अपील लिखित में होगी और उसके साथ उस आदेश की ۸ ۱
एक प्रति संलग्न की जाएगी जिसके विरुद्ध अपील की गई है MINISTRY OF ENVIRONMENT AND FORESTS
और यह आदेश पारित किए जाने को तारीख से तीस दिन की NOTIFICATION
अवधि के भोतर को जाएगी । New Delhi, the 4th May. 2030
6. उक्त नियमों क॑ नियम 8 के खंड (1४) में निम्नलिखित S.0. 1002 (E).—In exercise of the powers conferred
खंड रखा जायेगा, अर्थात्‌ 2 ‏ان‎ 2 on ce Sov tonnen (Protection)
ve = ct, 1986 (29 of 1986), the Central Government hereby make
iv) sain a defeat aA wa, GH, AFT FE the Following rules to amend the Batteries (Management
धातु प्रतिफल से संबंधित सम्पूर्ण अभिलेख निरीक्षण हेतु and Handling) Rules, 2001 namely,—
प्रदूषण नियंत्रण बोर्ड को प्रस्तुत करने हेतु उपलब्ध कराना 1" 1. (1) These rules may be called Batteries
7. उक्त नियमों के नियम 9 के उप-नियम (3) में से संख्या (Management and Handling) Amendment Ruies, 2010.
120" Rea "90" रखा जायेगा। (2) They shail come into force on the date of their
#. उपयुक्त नियम के प्रकृप at publication in the Official Gazette.
tefl ‏ویے‎ 2. In the Baiteries (Management snd Handling)
> बैटरि aa ‏چ8‎ 3
| (9) ''नई बैटरियों के विक्रय और उपयोगी WEAF utes, 2001(hereinatter referred to as the said rules, in rule
‏بر‎ फाइल wee fer we, BEER 5. fur clause (1), the following clause shall be substituted,
शीर्षक के नीचे बिनिर्माता/संयोजक और मरम्मत करने namely, —
वालों'” शब्दों के स्थान पर “' बिनिर्माता/आयातकर्ता/प्रपुंज “(1 bulk consumer-means a consumer such as the |
उपभोक्ता "' शब्द रखें जाएंगे; Departments of Central Government like Railways,
‏تا‎

<!-- page 3 -->

۲٢ 1
| 1-खण्ड 3(॥) भारत का राजपत्र : असाधारण ___ खा 3
Defence. Telecom, Posts and Telegraph, the Board or any other officer designated by the State
Departments of State Government, the Undertakings, Pollution Control Board;
Boards and other agencies or companies who (c) the appeal shall be in writing and shall be
purchase hundred or more than hundred batteries accompanied with a copy of the order appealed
per annum;". against and shall be made within period of thirty
3. Inthe said rules, in rule 4,— days from the date of passing of the order”
(i after sub-rule (xi), the following sub-rule shall be 6. Inthe said rules, in rule 8 for clause (iv), following
inserted, namely.’-— clause shall be substituted, namely,——
“(xii) ensure that the new batteries shall be sold only “ (iv) make available all records relating to receipt of
to the registered dealers”; used batteries, sources, quantities and metal yield to
ii) after sub-rule (xii) as so inserted, the following be submitted to the State Pollution Contra! Board for
Note shall be inserted, namely." inspection."
“Note: The assemblers and reconditioners are 7. Jn the said rules, in rule 9, in sub-rule (3) for the
excluded from the purview of responsibilities a figures “120”, the figures “90” shall be substituted.
specified in sub-clauses (iv), (vii), (ix) and (xil).”. a ined einer -
: " :
be Oa inet Ae ‏۷ح‎ (0 under the heading relating to “Porm: for Filling
By eerie eres (ue imponer dul returns of sale of new batteries and collection of
‏مت‎ used batteries, for the words manufacturer
get registered as per Form | with the Central Pollution assembler/reconditioner”, the words “manufacturer:
Control Board for a period of five years and a importer! bulk consumer” shall be substituted;
provision of cancellation for failure in collection of
the required number of used batteries as per the said (iin column 1, forthe existing entry, the entry “Name
: rules, non-submission of timely half yearly returns and Address of the manufacturer/importer'bulk
tothe State Pollution Control Boards with a copy 10 ‏وووسٹیپواائیپس‎
‎the Central Pollution Control Board, renewal of the (iii) in column 3, in the existing entry. after the word
registration shall be a5 per the compliance status: “sold”, the words “importers or constkmers” shall be
Provided that the registration granted to the importer inserted,
shall not be cancelled unless he has been given a 9. In the said rules, for the Form IV and the entries,
reasonable opportunity of hearing; relating thereto, the following Form and entries shall be
(ii) an appeal shall lie against any order of suspension substituted, namely:—
‘or cancellation or refusal of registration passed by “FORMIV
the Member-Secretary of the Central Pollution {See Rules 4 and 7 (vif)]
Control Board or any other officer designated by the FORM FOR REGISTRATION OF DEALERS,
oral ‏سس وو و‎ {fo be submitted by dealers to the State Pollution
(Gi) the appeal shall be in writing and shall be Control BoardsPottution Contro! Committees)
accompanied with a copy of the order appealed ee
against and shall be made within period of thirty ‏سو ٹب رہ‎
days from the date of passing of the order.” me .
$. In the said rules, in rule 7, after clause (vi), the aan .
following clause shall be inserted, namely, — 2. TINVAT number
“(vii) (a) registration with State Pollution Control ‏مت ء‎
Board for five years and a provision of cancellation _, IRAPPLICABLE(ASPER CURRENT STATE SALE
for faiture in callection of the required number of TAX RULES, MANDATORY TIN/VAT NUMBER IS
used batteries as per the said rules, non-submission _- KEQUIRED ONLY IF THE ANNUAL TURNOVER OF THE
of timely half yearly returs to the Sine Pollution OEALER IS MORE THAN THE PRESCRIBED VALUE)
Control Boards, renewal of the registration shall be Signature of the authorized person
as per the compliance status, to submit details as per Place
Form IV, registration would be considered.as deemed Date
registered if not objected to within thirty days:
Provided that the registration granted to the dealer [No.23-222005-11SMD|
shall not be.cancelled unless he has been given a ee :
reasonable opportunity of hearing; . gy Gabba tee!
{Gyan apeal shall ieagainst any order ofsuspension Note:The principal ules were published in the Gazette
‘or cancellation or refusal of registration passed by of India, Extraordinary vide notification number
the Member-Secretary of the State Poilution Control S.0. 432 (B), dated the 16th May, 2001
Printed by the Manager, Government of India Pres, Ring Road, Mayapuri, New Deihi-1 10064
and Published by the Controller of Publiations, Deihi-110084
