---
doc_id: "dd634aa7fdf673dc"
source_url: "https://smvdu.ac.in/wp-content/uploads/2025/09/Green-Buildings-The-Key-to-a-Sustainable-and-Resilient-Future.pdf"
ministry: "Shri Mata Vaishno Devi University, Katra, Jammu and Kashmir"
title: "Notification: Design, Development and Optimization of Electric Vehicles for a Green Future"
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "488e25b8c5f2869c"
---

<!-- page 1 -->

AWD श्री माता वैष्णो देवी विश्वविद्यालय
‏سے‎ हे
‏سا اص ا‎ SHRI MATA VAISHNO DEVI UNIVERSITY
‏ٹہ‎ ब्रह्म Directorate of Quality Assurance
“es Kakryal, Katra-182320, Jammu & Kashmir
hy
SMVDU/DQA/2025/2.41 Dated: 16 ‘September,2025
NOTIFICATION
Subject: Organizing of Regional Seminar on “Green Buildings: The Key to a Sustainable and Resilient of Regional Seminar on “Green Buildings: The Key to a Sustainable and Resilient
Future” at SMVDU.
With reference to the joint proposal of Ar. Vinod Kumar, Assistant Professor, SoALD and Ar. Navin Gupta,
Assistant Professor, SoOALD duly recommended and forwarded by Head SoALD & Dean, FoE and as
approved by the Competent Authority, sanction is hereby accorded for the following:
a) Organizing of Regional Seminar on “Green Buildings: The Key to a Sustainable and Resilient
Future” scheduled w.e.f. 16" to 17 September, 2025 at SoALD, SMVDU.
b) Grant of financial assistance of Rs. 30,000/- from University funds to meet the expenses of
the said event.
c) Providing 01 no. of room at University Guest house with boarding and lodging facility to
resource person from 15" to 17" September, 2025 on payment basis.
d) Providing of Honorarium and TA/DA to resource person as per University rules.
e) Providing of Transport facility to resource person from 150 10 17 September, 2025 on
payment basis.
Further, the following faculty members are appointed as Coordinator, Co-Coordinator, Convener,
Organizing Secretary and Co-Organizing Secretary of the said event
1. Ar. Abhiney Gupta, Head SoALD Coordinator
2. Ar. Abhimanyu Sharma, Assistant Professor, SoALD Co- Coordinator
3. Ar. Vinod Kumar, Assistant Professor, SoALD Convener
4. Ar. Navin Gupta, Assistant Professor, SoALD Organizing Secretary
5. Ar. Anoop Sharma, Assistant Professor, SoALD Co-Organizing Secretary
6. Ar. Satyanshu Kumar, Assistant Professor, SoALD Co-Organizing Secretary
The Convener take feedback and submit a report on the proceedings (in the enclosed format) and
feedback analysis to office DQA within a week after the conduct of event in hardcopy as well as in
softcopy (office.dqa@smvdu.ac.in) for perusal and records.
This event shall have the unique no. SMVDU/RS/SOALD/2025/402 for future reference.
Sh,
‏ہی‎
‎Director, er 2
Copy to:
1. Dean, FoE, SMVDU for information.
2. Registrar, SMVDU for information.
3. Finance Officer, SMVDU for information.
4. All Concerned for information and compliance.
5. AR to VC, for kind information of the Hon’ble Vice Chancellor.
6. I/c Website, for uploading on University website.
7. Concerned file.
oc = eee Se
