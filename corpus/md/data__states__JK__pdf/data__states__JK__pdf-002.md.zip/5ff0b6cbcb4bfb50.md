---
doc_id: "5ff0b6cbcb4bfb50"
source_url: "https://swachh.jk.gov.in/mis/storage/app/public/iec/monthly-action-plans/6x3f3hJOGjt1uamn7d1ZMXZS4LYEvgJvNkhvni3l.pdf"
ministry: "Swachh Bharat Mission Urban 2.0, Jammu & Kashmir"
title: "Annexure A - IEC SWM Rules 2026.pdf"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "107417d9f5f79211"
---

<!-- page 1 -->

Implementation of Solid Waste Management Rules, 2026
1. Introduction
The Solid Waste Management (SWM) Rules, 2026, notified by the
Government of India under the provisions of the Environment (Protection)
Act, 1986, provide a comprehensive framework for scientific management
of municipal solid waste in urban areas. The Rules emphasize waste
minimization, mandatory source segregation, decentralized waste
processing, scientific collection, transportation and disposal of waste,
Extended Producer Responsibility (EPR), compliance by Bulk Waste
Generators (BWGs), prohibition of littering and open dumping, and strict
enforcement against the use of banned Single Use Plastic (SUP) items. The
Rules also assign clear responsibilities to Urban Local Bodies (ULBs), Bulk
Waste Generators, commercial establishments, institutions, and citizens
to ensure environmentally sound waste management and promote a
circular economy through the principles of Reduce, Reuse and Recycle
(3R).
This Action Plan has been prepared to facilitate implementation of the
Solid Waste Management Rules, 2026 across the Urban Local Bodies
(ULBs) of Jammu & Kashmir except of the ULBs involving in SANJY
2026 under Swachh Bharat Mission–Urban (SBM-U) 2.0. The proposed
IEC interventions focus on awareness generation, capacity building,
citizen participation and support to enforcement for achieving sustainable
solid waste management practices, source segregation, elimination of
littering and Single Use Plastic (SUP), and improved compliance by Bulk
Waste Generators (BWGs). The Action Plan also envisages the development
of model colonies demonstrating full compliance with the SWM Rules,
2026, thereby creating replicable examples of sustainable urban waste
management across the Union Territory.
2. Objectives
 Build awareness and technical capacity of Bulk Waste Generators
(BWGs).
 Promote source segregation and home composting.
 Support enforcement against littering and SUP usage.
 Develop one Model Colony in each ULB compliant with SWM Rules,
2026.

Page 1|2

<!-- page 2 -->

3. Activity Plan
S.
Activity Name
No.

1

Capacity Building
Sessions of BWGs
for
Implementation of
SWM Rules, 2026

2

Identification of
Defaulters for
Littering in Public
Spaces

3

Identification of
Shopkeepers
Using
SUP/Polythene
Bags

4

Model Colony in
Each ULB with
Compliance of
SWM Rules, 2026

Description

Responsibility

Swaaha:
 Awareness sessions
of BWGs.
ULBs:
 Coordination with
BWGs and
execution of the CB
Sessions.
Swaaha:
Identify habitual littering

Handholding of
offenders through field
ULBs.
surveys and submit verified
ULBs:
lists to the concerned ULBs  Deployment of
with a copy to the MD,
enforcement Team
SBM-U 2.0 for penalization.
along with the SEs
Survey markets to identify
Swaaha:
commercial establishments  Handholding of
using banned
ULBs.
ULBs:
SUP/polythene bags and
 Deployment of
submit lists to concerned
enforcement Team
ULBs with a copy to the
along with the SEs
MD, SBM-U 2.0.
Swaaha:

Awareness sessions
Develop one model
of HHS through
residential colony in every
Community
ULB demonstrating source
Mobilizers.
segregation, home
ULBs:
composting, zero littering
 Deployment of
and active citizen
Sanitary Staff and
participation.
D2D vehicle on daily
basis
Conduct structured training
sessions for BWGs covering
legal provisions, source
segregation, on-site waste
processing, record
maintenance and
compliance responsibilities.

4. Conclusion
The proposed IEC Action Plan provides a practical roadmap for
implementation of the Solid Waste Management Rules, 2026 across all 80
ULBs of Jammu & Kashmir. Through focused capacity building, behaviour
change communication, community mobilisation and support to
enforcement, the plan will enhance compliance, reduce environmental
violations and establish sustainable solid waste management systems.
Page 2|2
