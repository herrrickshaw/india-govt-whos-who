---
doc_id: "aec6d8bc41fb368e"
source_url: "https://gcwgandhinagar.com/pdf/NAAC/5.1.1c%20Policy%20documents.pdf"
ministry: "Government Women College, Gandhi Nagar, Jammu, Jammu and Kashmir"
title: "5.1.1c Policy docume..>"
date: ""
pages: 9
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "c4787f2c000495ca"
---

<!-- page 1 -->

۱ ७७
5६
GOVERNMENT COLLEGE FOR WOMEN
GANDHI NAGAR, JAMMU
KEY INDICATOR-S.1.1
OF | |

ह NAAC CRITERION-V
POLICY DOCUMENT

<!-- page 2 -->

<aty, Mobile: 094191 - 02359 OFFICE OF THE PRINCIPAL Tele & Fax ~ 0191 - 2435158
5 f £2% GOVT. COLLEGE FOR WOMEN GANDHI NAGAR, JAMMU ©
5 हल 5 Constituent College of Cluster University of Jammu Ss 3 S&S
ae E-mail: principal@acwgandhinagar.com ‏ق پ۹‎
ay ‏حی رو‎
“tea pune
SCHOLARSHIP
‏9-8-.ك‎ लि लिक की
hee Sine. aa 5
कि हा 2
‏ا‎
‎ory a ‏نے‎
‎Hp. per
‏ا وا‎ 1
‏0ب یٌؤزپ-]زر‎
‏و ویک ہی 4 ار‎ ٣ ‏بی . و‎
3 gis
| ? ‏لو ا‎
۲ 7 ‏مو کت‎ §
-_ و٦‎ a
1 है। | 770 | “
-
oo ‏و‎ “٠ ۴ ‏ظا‎

<!-- page 3 -->

Govt. College For Women, Gandhi Nagar, Jammu_
‘Scholarship Policy
Preamble:
Govt. College For Women, Gandhi Nagar, Jammu aspires to impart quality education, equity
and access to all the aspiring candidates irrespective of the class and background. In this
endeavor, it strives to offer financial assistance in the form of scholarships apart from
providing modern infrastructural facilities and other possible academic support for the
holistic growth of an individual.
Scope:
The scholarship policy/guidelines formulated are applicable to all the students enrolled in
various academic programmes offered by Govt. College For Women, Gandhi Nagar, Jammu
Committee:
An exclusive committee comprising of the duly constituted Scholarship Committee is
responsible for all the decisions related to scholarships.
Roles & Responsibilities of the Committee:
7 ~ Drafting and modifying of the Govt College For Women, Gandhi |
< Nagar, Jammu Scholarship Policy
“Taviting Applications for different catégories of institutional” |
scholarships ۱
‏جو تچ چچچچچچچچ سج ٛ ہچ سے چچچچد چےہے۔ ہے ہس۔۔ جم‎
\_ Age ee en ee
1
(
‏ےتے۴تأآے ہہ سس سس‎
‏جے‎
‎٠ ‏025ر‎ of ‏۴ك‎ sid i ota
Scholarships offered by Govt. College For Women, Gandhi Nagar, Jammu
Govt. College For Women, Gandhi Nagar, Jammu offers scholarships to undergraduate as
well as post graduate students. The award of these prizes and scholarships is done through a
duly constituted Scholarship Committee ie., scholarship, prize and Fee Concession
Committee. The list of various scholarships offered are as follows:

<!-- page 4 -->

List of various Scholarship Schemes offered by Central/State
Government Agencies
Ss. Name of Center/State | Relevant Brief Description | Target Implementin
No. the Scheme Scheme Ministry of Scheme with Group g
Eligibility Agency
Conditions
CSSS Center MHRD Students who have | Meritoriou | MHRD
[Central [Ministry of | secured aj|sstudents | [Ministry of
Sector Human percentage of 80% Human
Scheme of Resource or above in 12% Resource
Scholarship] Development of | standard are Development
India], eligible for this of India],
Govt. of India Scheme. Family Govt. of India
income should be
less than 8 lakhs.
2. Post-Matric Center/ Ministry of | Students having | Students | Social welfare
Scholarship State Social Justice | valid category | belonging | department
for 380 and certificate. Family | to SC | J&K)
[Scheduled Empowerment, | income upto Rs. | Category | through its
Caste] Govt. of India | 2.50 lacs per directorates
annum
3: Post Matric | Center/ State | Ministry of | Students having | Students | Social welfare
Scholarship Social Justice | valid category | belonging | department
for 0865 and certificate to OBC | 7
[Other Empowerment, | Family income | Category | through its
backward Govt. of India | upto Rs.2.50 lacs directorates
classes er annum
4. Post Matric | Center/State | Ministry of | Scholarship to | Students Social welfare
Scholarship Social Justice | EBC Students. | belonging | department
for EBCs and Parents income|to EBC | (J&K)
[Econimical Empowerment, | =0.75 lacs Category | through its
ly backward . Govt. of India directorates
classes
5 Post Matric | Center/State | Ministry of | Scholarship to PSP | Students | Social welfare
Scholarship Social Justice | students. Parents | belonging | department
Scheme for and income=2.50 lacs. | to PSP | (J&K)
PSP [Pahari Empowerment, category through
Speaking Govt. of India Pahari
students] Speaking
Board
‏9ے‎

<!-- page 5 -->

6. Scholarship Center Ministry of | Scholarship to the | Students Social welfare
for Minority Minority students belonging | belonging | directorates
Students Affairs, Govt. | to National. | to (J&K)

of India Minority National | through State
Communities after | Minority | Nodal Officer
Post-Matric level. | Communit | at Secretariat
The students are | ies level
provided
reimbursement of
fee/ other charges
depending upon
the academic
merit/economic
status, determined
by Govt. of India
annually

7 Post Matric | Center/State | Ministry of | Students belonging | Students Directorate of
Scholarship Tribal Affairs, | to ST Category belonging | Tribal
Scheme for Govt. of India Annual Family | to ST | Affairs J&K
ST income should not | Category

: [Scheduled exceed INR 2 lakh
Tribe] er annum
INSPIRE [ Center Ministry of | Meritorious Meritoriou | Department of
Innovation Science and | students with | s students | Science and
in Science Technology, aggregate marks Technology,
pursuit for Govt. of India | within top 1% of Govt. of India
inspired their Class 12"
research] examination of any
State/Central
board. हर
Student must be
pursuing courses in
Natural and Basic
Sciences
Baridar State Shri Mata Father of applicant | Children | Shri Mata
Vaishno Devi should be Baridar | of Baridar | Vaishno Devi
Shrine Board in Vaishno Devi Shrine Board
Shrine

10. Assistant State Department ‏۶۱ہ‎ The applicant must | Children Department of
Labour Labour, J&K be an active labour | of Labour | Labour, J&K
Commission card holder in | card

Union Territory of | holders ۰

Jammu and

Kashmir. |
The —_ applicant’s

child must __be

<!-- page 6 -->

pursuing education

in a_ recognized

institution in India.

The —_applicant’s

child must have

scored at least 60%

marks in the

previous academic

year.
MGNREGA Center Ministry of | Applicants Parent | Children | Department of
[Mahatma Rural must be part of a | of Rural
Gandhi Development, | rural household | registered | Development
National Govt. of India and must volunteer | laborer J&K
Rural for unskilled labor | under
Employmen work MNREGA
t Guarantee Scheme
Act]

<!-- page 7 -->

है S.No. Name of the Scholarships Government / Non Government
j
a
a
a

<!-- page 8 -->

Mobile: 094191 — 02359 OFFICE OF THE PRINCIPAL Tele & Fax— 0191 ~ 2435158
2 GOVT. COLLEGE FOR WOMEN GANDHI NAGAR, JAMMU SoS
< Constituent College of Cluster University of Jammu ‏پت‎ ©
E-mail: principal@gewgandhinagar.com So 3 SoS
७७६ 7
Financial Assistance to Needy Students
®@ College fee concessions are given to needy and deserving students on the basis of
their performance in the last examination taken. Students desirous of getting such
concession are required apply to the College office on the prescribed form.
®@ Scholarship for Scheduled Caste/Tribe students - Students belonging to scheduled castes,
scheduled tribes and other backward classes, recognized as such by the Government of
India, are awarded scholarship by their respective State Governments. Such students are
required to apply to the State Government concerned on forms prescribed by the respective
states through the Principal immediately after joining the College.
General Guidelines
® These scholarships are applicable to the undergraduate students.
@ The scholarships shall not be disbursed if there are no eligible applicants.
@ The decision of the committee in matters related to scholarship shall be final.
@ The finance section shall process the approved sanction of scholarship and ensure timely
disbursement of the scholarship.
@ The details of the scholarship shall be accounted periodically and duly audited.
@ Grievances if any shall be addressed by the Grievance Redressal of the college.
oa) nes
‏>ء)"‎ 6 got NNO .
2 ‏سی‎ 0۵
७60४: ar
PSPS nat 8

<!-- page 9 -->

APPLICATION FOR GRANT OF FINANCIAL AID FROM COLLEGE FOR GRANT OF FINANCIAL AID FROM COLLEGE
STUDENT AID FUND
To ‘
The Principal 4
Govt. College for Women .
Gandhi Nagar, Jammu.
Madam,
I beg to apply for grant of Financial Aid out of College Aid Fund for the year and
given below the necessary part:
1. Namewith Parentage  ْے.....ںہبلوسس۔‎
2. Community. —
3. Permanentaddress ‏نرہلےے‬._. ...۹ر‎ _#
4, Present address __ :
5. Class in which reading with Roll No. Class__ _Roll No.
6. Date of admission to the present class__ _ 7
7. Permanent resident of J&K State, Yes/No. ‏لے‎ _ — _
8. Name of Guardian if father is not alive _ Seman /
9. No. of earning members in the family along with their income. ----+-+-
10. immovable property owned & held by the “family to which the applicant
belongs _ ————
11. Rental value or income form property. - Ss
12. Parent/Guardians income. ee
13. Number of dependents ee ee 07
14, Scholarship sanctioned or financial aid obtain from other source
15, If applied for any other scholarship__ _.
L ~ Name of the Exam. Year | 1 RollNo. | |___Division __| “|
eT 7
|
| | | | |
L fo ‏لے۔‎
‎Date:
‎Yours faithfully,
Signature of the applicant
| solemnly declare that the particulars given below are correct.
Signature of the parenVguardian
| Certified from any Gazetted officer or the local M.L.A, > ing that data are correct to the best
his knowledge & oblige.
Particular stated above are correct smmended for the Aid from college student Aid Fund.
Siunature of the Gazette! Officer/M.L.A
(Stamp)
