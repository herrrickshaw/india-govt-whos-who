---
doc_id: "d1ef65ac153fbf0e"
source_url: "https://schooleducation.jk.gov.in/archievesData/564%20of%202017.pdf"
ministry: "Department of School Education, Jammu and Kashmir"
title: "Constitution of Committees to examine the functioning and grant of NOCs to ETT institutes in the State. Government Order No: 564-Edu of 2017 dated: 22/08/2017."
date: ""
pages: 2
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "c74e257af12d4ec6"
---

<!-- page 1 -->

edu-jk@nicin
Fax No: 0194-2450738 (S)
as 0191-2566504 (J)
ce “ty
oy
eS
GOVERNMENT OF JAMMU AND KASHMIR
SCHOOL EDUCATION DEPARTMENT,
CIVIL SECRETARIAT JAMMU/SRINAGAR
2K
Subject: Constitution of Committees to examine the functioning and grant of
NOCs to ETT institutes in the State.
Ref: 1. Judgment dated 31-7-2014 passed in LPAOW No. 77/2013 CMA No.
. 94/2012 clv APLPA No. 73/2013 LPAOW No. 78/2013 CMA No.
96/2013 titled Sant Memorial Institute of ETT and others alongwith
connected matter V/S State and others.
2. Order dated 02.08.2017 passed in CP (OW) No. 87/2017 in (OWP No.
02/2015) titled Ranjit Teachers Training Institute and others V/S State
and others.
Government Order No:.5 64 - Edu of 2017
Date dad -08 - 2017
In supersession of all previous orders, sanction is hereby accorded to the
constitution of two committee(s) for Kashmir Division and Jammu Division with the
following composition (s):-
Kashmir Division
4. Sh. Mohd. Shafi Khan - Principal District Judge (retired)
2. Sh. Mehboob Hussain - Joint Director(Trgs)/Principal
State Institute of Education, Srinagar
3. Mtr. Suriya Akhter - Joint Director (EE),
Directorate of Sch. Edu., Srinagar.
4. Sh. Abdul Ahad - OSD, (SSA) in Directorate of School
Education, Kashmir.
Jammu Division हि
+ Sh. Dev Raj Sharma - Principal District Judge (retired)
_ Sh. Mohammad Iqbal - Joint Director (Trgs)/Principal
2.8 i State Institute of Education, Jammu.
3, Choudhary Altaf - Field Advisor, State Institute of
: Education, Jammu.
4. Sh. Sudakar Chand - Principal, HSS, Harnia
Contd.......2

<!-- page 2 -->

नी
y 4 2
7 The mandate of the Committees Shall be strictly as directed by the the Hon'ble
Division Bench in the Judgment dated 31.07.2014 Passed in the case titled Sant
Memorial ETT Institutes and others VIS State and others,
The Committees Shall inspect all the ETT Institutes including institutes belonging
to the petitioners and all those which have obtained directions from the Hon'ble High
Court at Kashmir/Jammu for grant of NOCs in their favour.
The Committees shall submit its inspection report to the Administrative
Department for functioning and grant of NOCs in favour of ETT institutions in
accordance with the rules and orders passed by the Department from time to time
subject to the clearance from Crime Branch.
By Order of the Government of Jammu and Kashmir.
Sd/-
(Farooq Ahmad Shah)
Secretary to Government
School Education Department
No: Edu/Legal/J/Misc/205/201 7 08160:33 -08-2017
Copy to the:-
1. . Registrar, General, J&K High Court, Jammu
2.* Sh. Dev Raj Sharma, retired Principal District Judge, Jammu
3." Sh. Mohd. Shafi Khan, retired Principal District Judge, Srinagar.
4. Director School Education, Jammu/Kashmir for information.
5. OSD to Hon'ble Education Minister for information of Hon'ble Minister,
6. Sh. Ravinder Gupta, Additional Advocate General, Jammu for information and
necessary action.
7. Secretary, J&K State Board of School Education, Jammu to Provide the list of
ETT Institutes to the Committees.
8." Sh. Mohammad Iqbal, Joint Director (Trgs)/Principal,
State Institute of Education, Jammu.
9.- Sh. Mehboob Hussain, Joint Director(Trgs)/Principal,
State Institute of Education, Srinagar
10. Mtr. Suriya Akhter, Joint Director (EE), Directorate of Sch. Edu., Srinagar.
11.Choudhary Altaf, Field Advisor, State Institute of Education, Jammu.
12: Sh. Sudakar Chand, Principal, HSS, Harnia.
13:Sh. Abdul Ahad, OSD to Director School Education,
Kashmir. ۹
14>Under Secretary to Government (N), School Education Department for
information and necessary action. |
14.۰۲۷۰۸۰ Secretary to Secretary to Government, Department of Law, Justice &
Parliamentary Affairs for information of Secretary. ।
15. Pvt. Secy. to Secretary to Govt., School Edu. Deptt. for information of Secretary. |
16. Govt. Order file (w.3.s.c). .
17. Stock file. uw
Le r Ahmad)
Under Secretary to Government
: swe School Education Department
