---
doc_id: "aebe5c0f478baa23"
source_url: "https://www.jammuuniversity.ac.in/sites/default/files/Order-Circular2025-10/No-ITX-25-115%20FA%20Circular.pdf"
ministry: "University of Jammu, Jammu and Kashmir"
title: "Circular"
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "d118ff94b514ceaa"
---

<!-- page 1 -->

| oe : |
ei 13 ۱
‏ا کا‎
00 UNIVERSITY OF JAMMU
‘ (NAAC Accredited ‘A+’Grade University)
i et ——no nae" oe ः
हा i NO.ATX/25/
| 1 Dated: |£- ]0- 2014”
Circular
| ; .
‏اتا‎ It is hereby circulated: for the information to all the HODs,
bo Directors, Rectors. and -Controlling . Officers of the ‘various
po Campuses/Departments, who. are.involyed in any kind of selling and .
. purchasing of goods or providing or availing of services on behalf of
8 university, must ensure strict. compliance with the applicable provisions
F ef TDS (lax .Deducted at Source), TCS (Tax Collected at Source) and
’ ‘GST (Good and Service: Tax), For more clarification, you may refer to
; the official Income Tax Department website or contact Income Tax
|... Section.of the University.of Jammu, 7
De. be : : : ٦ We o®”
pot ۶ ٠ ५ | SE ccOunts Officer
Po Copy to; oo : ¢
bee 4. “Special Secretary to the Vice Chancellor, University-of Jammu.
eo igi 2enSreP.A tothe dean Academic Affairs/Dean Research Studies.
So ~ a, 3. Sr. P.Ato the Registrar/-Contraller of Examinations.
& "4. “Dean Student welfare/Provost (Boys/Girls)/Dean Student Placement
٠ ‏ال۸: :وت‎ २९८७०5/आएए०5, 0918 (क1॥2059$.. ‏کا‎
‎ّ ‏ا مز‎ ۲۵۰۳۵۲ 200۲۵ ITES&M to direct the concerned for uploading on the University Website.
का. 7 7, All Joint Registrars/Deputy Registrars. ‏تا‎
‎हा 23.'g, 2! All Heads of Teaching Departrnents.of University of Jammu.
‏جو ات 07ا00 0:023 0 ظا ۵۵۵ روا۱١/١ وو ا ات‎
‏ا‎ 10-176 6006091 Zorawar Singh Auditorium. oe 7
0. “75 11°1/C Director, Computer Center. ‏ای‎ : i et d
fo: <= A2aIncharge, Services.’ fey : Sass SD
7 : il ‏جا‎ ٦ 8 29०2.
: 13, Guard file ce Ae | ۵ wide 7
ro ae Rech
: : हु : 0 8
‘ : : 22 ۱
‏ار‎ ; :
| 890 ۰ : :
