---
doc_id: "898a9f8ebcf9dfe3"
source_url: "https://jkssb.nic.in/Pdf/AdmitCard_Notice_06102026.pdf"
ministry: "Jammu and Kashmir Services Selection Board, Jammu and Kashmir"
title: "Notification regarding Issuance of Admit Cards to the candidates for OMR Based Written Examination for the post of Female MPHW/Male Multipurpose Health Worker, Health & Medical Education Department, scheduled to be held on 11.10.2026."
date: ""
pages: 3
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "a4031d2bd974a4ae"
---

<!-- page 1 -->

GOVERNMENT OF JAMMU AND KASHMIR
JAMMU AND KASHMIR SERVICES SELECTION BOARD
Muthi, Akhnoor Road, Jammu/ZamZam Complex Rambagh, Srinagar
www.jkssb.nic.in
FORK RK KK
Notice
Subject: Issuance of Admit Cards to the candidates for OMR Based
Written Examination for the post of Female MPHW/Male
Multipurpose Health Worker, Health & Medical Education
Department scheduled to be held on 11.10.2026.

The Jammu and Kashmir Services Selection Board (JKSSB) is
conducting the OMR Based Written Examination for the post of Female
MPHW/Male Multipurpose Health Worker, Health & Medical
Education Department under Notification No. 07 of 2025 under item No’s
35-59 scheduled to be held on 11.10.2026.

Canuidates can download their Admit Cards from the JKSSB’s
Official website (www.jkssb.nic.in) w.e.f. 06.10.2026 using their
credentials. They must read the instructions contained therein, carefully.

However, in case, a candidate is not able to download his/her admit
card, he or she may represent before the board two days before the
Examination Date with a valid proof of having filled in Online application
form and online fee, failing which it shall be presumed that he/she is not
interested in appearing in the said examination and no claim whatsoever
shall be entertained.

Cancidates are advised to report to their respective
examination centres at least two (02) hours before the scheduled
examination time for Biometric/Facial Authentication.

Candidates are advised to take a print-out of the Admit Card
well in advance to avoid any last-minute rush. In case of any mismatch in
the photograph on the Admit Card, the candidate must immediately report
the matter to the Jammu and Kashmir Services Selection Board (JKSSB)
Central Office at Jammu or Srinagar, either in person or via email at
ssbjk-grievance@jk.gov.in. No such claim regarding photo mismatch
shall be entertained by the Centre Superintendent or the staff on duty on
the day of the examination.

Fe

<!-- page 2 -->

The candidature of candidates claiming eligibility by
misrepresentation/concealment of any material facts, impersonation,
fraud, etc. shall be liable for cancellation and disciplinary action, as
deemed appropriate.

The Board reserves the right to cancel the candidature of any
candidate at any stage at which he/she is found ineligible.

The candidates are also advised to be in touch with the
JKSSB’s Official Website (www.jkssb.nic.in) for the latest updates on
the examinations. Admit cards will not be sent by post.

Candidates shall have to submit their Admit Cards
back to the Invigilation staff duly signed by the candidate and
the concerned Invigilator after the completion of examination.
Stepwise procedure to download JKSSB E-Admit Card:-

i. To download E-Admit Card, first visit the official website of
JKSSB, i.e. www.jkssb.nic.in
ii. On the homepage, there will be a link to download E-Admit Card.
iii. Enter log-in credentials i.e., Username and Password.
iv. Enter the OTP received on your registered Email ID and Mobile
Number.
v. Download and print your JKSSB Admit Card.
vi. Candidate must bring the clear printed copy of E-Admit card on
the day of examination.
fe
Reyaz Ahmad k (JKAS)
Controller of Examinations
J&K Services Selection Board
No.JKSSB-COEOEXAM (UT)/03/2026-03 (7909564) Dated: 06.10.2026
Copy to the: -
1. Commissioner/Secretary to the Government, General Administration
Department, Civil Secretariat, J&K, Jammu for favour of information.
2. Director information, J&K Government, Jammu with the request to
get the said notice published in at least two leading newspapers of
Jammu/Srinagar.
3. Secretary, J&K Services Selection Board for information.

<!-- page 3 -->

4. Member (All), J&K Services Selection Board for
information.
5. Administrative Officer, Jammu/Srinagar for information and
necessary action.
6. P.A. to the Chairman, J&K Services Selection Board for information
of the Chairman.
7. I/c Website for uploading.
|
|
