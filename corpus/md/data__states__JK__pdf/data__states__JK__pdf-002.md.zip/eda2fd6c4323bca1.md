---
doc_id: "eda2fd6c4323bca1"
source_url: "https://hme.jk.gov.in/assets/pdf/GO721.pdf"
ministry: "Health and Medical Education Department, Jammu and Kashmir"
title: "G.O. No.721 → Compassionate appointment of Mr. Danish , S/o Gh. Ganesh Dass & Late Sudesh Kumari, Ex-Jr. Staff Nurse R/o H. No 131 , Near Shiv Mandir Pacci Dhakki District Jammu, J&K, Directorate of Health Services, Directorate of Health Services, Jammu , District Cadre Jammu under Jammu and Kashmir"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a8b4ba6c64f5fbd0"
---

<!-- page 1 -->

Government of Jammu & Kashmir

Health & Medical Education Department
Civil Secretariat, J&K.

x*x**

Subject:- Compassionate appointment of Mr. Danish, S/o Sh. Ganesh Dass & Late Sudesh

Kumari, Ex-lr. Staff Nurse R/o H.No. 731, Near Shiv Mandir Pacci
Dhakki District Jammu, J&K, Directorate of Health Services, Jammu, District Cadre

Jammu under Jammu & Kashmir Rehabilitation Assistance Scheme-2022.

Reference:-

i. Minutes of the meeting of Evaluation Designated Committee held on
27.Lt.2025 in Civil Secretariat, Jammu/Srinagar;

ii. Form No. 155097 dated 07.45.2026 received from Criminal Investigation
Department, J&K,

iii. General Administration Department O,M No. GAD-RASl2l2024-09-Part-(5)
(E-7618082) dated 24.04.2025.

Government Order No. nU -JK(HME) of 2026.
Dated:- tB .09.2026

In exercise of the powers conferred under Clause-3 of Jammu and Kashmir
Rehabilitation Assistance Scheme, 2022 notified vide S.O. 429 dated 6th September, 2022
read with S.O, 397 dated i6th of August, 2A24, sanction is hereby accorded to the temporary
appointment of Mr. Danish, S/o Sh. Ganesh Dass & Late Sudesh Kumari, Ex-Jr. Staff Nurse R/o
H.No. 131, Near Shiv Mandir Pacci Dhakki District Jammu, J&K, Directorate of Health Services,
Jammu, District Cadre Jammu as MTS in the Pay Level SL-1 (14800-47100).
The appointee shall report to the Director, Health Services, Jammu, within a period
of 7t days from the date of issuance of this Government Order, failing which he shall forfeit
her right to appointment and the same shall be deemed to have been cancelled ab-initio
without any further notice.

The appointment order shall be issued only after completion of all codal
formalities as envisaged under relevant rules and regulations as well as the appointee shall be
allowed to join only on the production of the following certificates (in original) to be verified
subsequently:-

a) Academic Qualification Certificates.
b) Date of Birth Certificate.

c) Health Certificate from the concerned Chief Medical Officer of the District.
d) Domicile Certificate.
e) All other relevant documents as are required under the l&K Rehabilitation Assistance
Scheme-2022.

The appointment of the appointee shall further be subject to the following
conditions:
i.

The applicant shall give an undertaking in writing as per format prescribed in the
Scheme that he shall maintain properly the other family members who were
dependent on the deceased and in case, it is proved subsequ"nt , at any time that

\""1
I

{.

<!-- page 2 -->

the family members are being neglected or are not being maintained properly by
him, appointee shall be terminated forthwith.

ii. Any claim for transfer of appointment to any other family member shall invaria bly be
rejected.

The appointee shall be adjusted against appropriate category to which he belongs. In
case the appointee fails to produce any valid category certificate, he shall be
adjusted against General category.
iv

That he shall give an undertaking in the shape of an Affidavit to the effect that if on
verification, her QualificationlDate of Birth/Category Certificates, if any, from the
concerned issuing authority are found to be fakelforged, the claim of the appointee
for appointment as Class- IV/Multitasking Staff (MTS) shall be deemed to have been
cancelled ab- initio and legal action as warranted under rules shall be initiated
against her.

V

That he shall give an undertaking in the shape of an Affidavit duly attested by the
Judicial Magistrate First Class, to the effect that the applicant is unemployed as on
date and none of the family members other than the applicant has taken benefit of
compassionate appointment under J&K Rehabilitation Assistance Scheme-2022. In
case, rt turns out that the applicant is already appointed or the benefit of
compassionate appointment under the Scheme has already been extended to the
family of the deceased, then the instant appointment shall be deemed to have been
withdrawn ab-initio without any further notice"

vi

That if the candidate has taken loan for self-employment from District Industries
Centre (DIC) I Employment Department, to be ascertained from the DIC and District
Employment & Counselling Centre of the domicile District, he shall relinquish the
proprietorship of unit/enterprise and also stakes, if any, in such self-employment
unit/enterprise before joining the Government service. He shall be required to repay
the entire loan liability in suitable EMIs to be worked out by the DDO concerned from
his salary. The DDO concerned shall obtain an affidavit from the concerned appointee
regarding both relinquishment of proprietorship and stakes, if any, in such a selfemployment unit/enterprise and recovery to be made and also personally monitor its
recovery.

vii. The salary of the appointee shall not be drawn and disbursed to him unless a
satisfactory report in respect of genuineness of Qualification/Date of Birth/Category
ceftificate, if any, is received from the concerned authorities.

viii. The appointee shall be on probation for a period of two years.
ix. The appointment of the candidate shall be governed by the "New pension Scheme"
as notified vide SRO-400 of 2009 dated 24.t2.20A9.

V\-

<!-- page 3 -->

X.

The appointment of the appointee shall be subject to outcome of writ petition(s), if
any, pending before competent Court of Law.

By order of the Government of Jammu & Kashmir.

sd/(M, Raju) IAS,
Com missioner/ Secreta ry to the Government,

Health & Medical Education Department.
No: HD-NG-J1L3512025-AZ (CC. No. 765A694)

Dated:-.18 .09.2026

Copy to the:i

t.

ii.

iii.
iv.
vi"

vii"

viii.
ix.
X.

xi.
xii.

Additional Chief Secretary to the Hon'ble Chief Minister, J&K.
Principal Secretary to the Hon'ble Lieutenant Governor, J&K.
Joint Secretary, (JK&L) Ministry of Home Affairs, Govt. of India.
Commissioner/Secretary to the Government, General Administration Department.
Director, Information, J&K.
Director Archives, Archaeology and Museums, J&K, Srinagar.
Director, Health Services, Jammu.
OSD with the Hon'ble Minister for Health & Medical Education.
Pvt. Secretary to Commissioner/Secretary to the Government, Health & Medical
Education Depaftment.
IIC website, Health & Medical Education Department.
Concerned.
Government order file (w.3.s.c)/stock file.

Ahmad),

Under Secreta

to th

rnment.
"Y
