---
doc_id: "bae1bab79b0845bf"
source_url: "https://gcwgandhinagar.com/pdf/NAAC/7.1.3%20a%20Policy%20document%20on%20Environment.pdf"
ministry: "Government Women College, Gandhi Nagar, Jammu, Jammu and Kashmir"
title: "7.1.3 a Policy docum..>"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b1f7de37de5480c0"
---

<!-- page 1 -->

PADMA SHRI PADMA SACHDEV
GOVT. COLLEGE FOR WOMEN GANDHINAGAR JAMMU
(A Constituent College of Cluster University of Jammu)
NAAC ACCREDITED, GRADE-A (2ND CYCLE)
Erstwhile Star College (DBT)

POLICY DOCUMENT ON ENVIRONMENT

INTERNAL QUALITY ASSURANCE CELL (IQAC)

<!-- page 2 -->

Contents
S.no

Title of document

Page no.

Policy Statement

01

Aims and Objectives

02 – 03

Scope

03

Action Plan

04 – 07

Vision – 2030

07 – 08

1.
2.
3.
4.
5.

Significance of Audit
6.

08

<!-- page 3 -->

POLICY STATEMENT

At GCW, Gandhi Nagar, we are committed to promote environmental
sustainability and minimizing our ecological footprint. We recognize that the
environment is a precious and finite resource, and it is our responsibility to protect
and preserve it for future generations. The College aims to maintain a green, clean,
and eco-friendly campus. It intends to encourage projects and initiatives on waste
management, water conservation, energy consumption reduction and climate
change mitigation.
The policy implies to explore the renewable energy resources to reduce the burden
and to find ways to switch to the sources that are energy efficient and renewable.
This transition to the renewable energy and to inexhaustible sources of energy will
maintain the interest of our planet and its inhabitants. This environment and energy
policy is applicable for all the components of the institution and to all its
stakeholders.
This policy will help us to realize our responsibilities and commitment to
conservation of natural resources about reducing air & water pollution and green
house gas emissions and to limit their usage. Waste Management Committee,
Environment and Green Audits are devoted to the cause of environmental
awareness, to undertake green initiatives and to conduct green literacy programs to
save energy and protect the environment.
The Policy designed to achieve these objectives for a better environment with the
involvement of students by undertaking different activities. The pattern of the
environment related activities and programs conducted in the college designed and
modulated in such a way that a clear and strong message is circulated amongst the
students and the society regarding management, protection and preservation of
environment and natural resources.

1

<!-- page 4 -->

AIMS & OBJECTIVES

• To protect and conserve the natural environment, including ecosystem,
biodiversity, and natural resources.
• To promote sustainable practices that balance social, economic, and
environmental considerations. This includes striving for long-term
environmental sustainability, reducing ecological foot prints, and supporting
the well-being of present and future generations.
• To prevent pollution and minimize the release of harmful substances into
the environment.
• Climate change mitigation and adaptation is a crucial objective of many
environmental policies which includes adopting renewable energy sources,
promoting energy efficiency, and implementing measures to adapt to the
impacts of climate change.
• To promote the efficient use of natural resources, such as water, energy, and
raw materials. The objective is to minimize waste generation, optimize
resource utilization, and encourage recycling.
• To ensure compliance with relevant environmental laws, regulations, and
standards which includes staying up to date with environmental
requirements, obtaining necessary permits, and reporting on environmental
performance.
• To raise awareness about environmental issues, promote sustainable
practices, and provide resources and education to enable stakeholders to
participate in environmental initiatives.
• An Environmental policy includes the objective for continuous
improvement in environmental performance. This involves setting targets,
monitoring progress, and implementing management systems to drive on
going environmental improvement within the organization.

2

<!-- page 5 -->

• To foster collaboration and partnerships with other organizations,
government agencies, NGOs, and community groups to collectively address
environmental challenges and achieve shared environmental goals.
• To develop a policy for e-governance with the intent to reduce the use of
paper.
• To implement the zero-tolerance policy on single use plastic in the
institution.
• To organize seminars/lectures on the initiatives that should be undertaken to
conserve energy and natural resources.
• To develop rain water harvesting and underground water management
system in the college.

SCOPE
In due recognition of an educational institution’s significant role in the creation
and maintenance of environmental consciousness in society, GCW, Gandhi Nagar
outlines the following initiatives and practices:
• Integrated Solid Waste Management involving waste prevention, recycling,
composting and safe disposal of dry waste, food waste, hazardous waste and
e-waste.
• A Plastic-Free Campus to be achieved through a strict ban on the use of
single-use plastic, in accordance with the government’s efforts to ban all
single-use plastic.
• To enhance the overall aesthetic appeal of the College premises and to
create a sense of belonging.
• To develop Rain Water Harvesting and Underground Water Management
System.
• Installation of Solar Panels, along with other energy efficient equipment’s
viz bulbs, tubes, etc.
3

<!-- page 6 -->

ACTION PLAN

The objectives should be realistic, time-bound, and relevant to the
organization's environmental priorities.
• Conduct Environmental Assessments:
To conduct thorough assessments to identify the organization's current
environmental performance, impacts, and areas for improvement. This will
be achieved by conducting energy audits, water footprint assessments,
waste audits, and carbon footprint assessments.
• Engage Stakeholders:
To involve key stakeholders such as students, alumni, and local
communities in the development and implementation of the action plan. It
can be achieved by seeking their inputs on different objectives and
initiatives, which will be aided with their participation and support.
• Establish Key Performance Indicators (KPIs):
Developing a set of KPIs to monitor and measure progress towards the
objectives. KPIs will include metrics such as energy consumption, water
Usage, waste generation, greenhouse gas emissions, and other relevant
environmental indicators.
• Identify Priority Areas and Specific Actions:
Identification of priority areas where significant environmental
improvements are required will be based on the assessment findings,
stakeholders’ feedback, and the organization's environmental impacts and
risks. The course of action will include assigning responsibilities, setting
timelines, and allocating resources for each action.

4

<!-- page 7 -->

These action plans will be put in place by implementing following basic
procedures:

Waste Management
• College will collaborate with the agencies / NGOs to manage the
recyclable waste generated in college at larger scale.
• The dustbins will be installed at different locations to manage solid waste
which will be further separated into biodegradable and non-biodegradable
categories.
• The college will follow the proper guideline for treatment and disposal of
biological and chemical wastes generated.
• The college will strictly adheres to plastic usage guidelines and has
already prohibited the use of single-use plastic in the campus like carrybags, glasses, spoons, plates, etc.
• The college shall develop a compost unit that makes compost from
canteen waste, leaves, grass, organic waste, and other sources.

Conservation and Management of
Water
• The college will develop operational Rain Water Harvesting units. The
water collected from the working unit will be discharged into the ground
water to raise the ground water table.
5

<!-- page 8 -->

• The water distribution system from the main water tank of the college will
be repaired so that water supply to different blocks may not be hindered.
• Regular inspection of taps for leaks or drainage will be done and repaired,
if required to avoid the loss of potable water.

GREEN INITIATIVES

• The college will initiate and participate in plantation drives both on and
off campus in near future to maintain the green cover and enhance the
ambience with the help of skilled gardeners and supervisors.
• To increase the oxygen levels in the campus, various varieties of
ornamental, medicinal and wild plant species will be planted during
plantation drives.
• Setting up of herbal garden in the college campus will definitely accelerate
the efforts of enhancing green cover.
• The college will follow the tradition of greeting all the guests and visitors
with assorted saplings of plant or herbs i.e. Green Welcome.
• A green and environmental audit shall be conducted to identify, quantify,
and an environmental sustainability framework in accordance with
applicable regulations, policies, and standards.
• The green habitat concept will be implemented in the college campus to
reduce energy consumption, improving the aesthetic appeal of buildings and
classrooms, and lowering carbon footprint.

6

<!-- page 9 -->

• The College will strive to be a paperless workplace in near future shifting
communication from paper to e-mail, whatsapp and other e-platforms.

ENERGY CONSUMPTION AND
CONSERVATION
• More Photovoltaic Solar Panels will be installed to light the college drive
way to fortify the process of energy conservation and the use of renewable
sources of energy.
• The college will adopt and promote energy-saving electrical appliances.

VISION - 2030

With the College's commitment for the cause of environmental protection,
we would like to take our current environmental initiatives to the next level
in future.
• The college is planning to expand the solar panel installation in the
campus and use renewable energy, reducing the burden on non-renewable
energy resources.
• The herbal garden of the college will be enriched with more varieties of
plants to enhance the oxygen level in the campus.
• Tree adoption drives will be promoted by NCC & NSS during which
students in teams or groups will adopt trees in the college and vicinity and
take care of them.
7

<!-- page 10 -->
