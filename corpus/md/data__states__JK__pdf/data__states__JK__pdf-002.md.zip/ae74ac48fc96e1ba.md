---
doc_id: "ae74ac48fc96e1ba"
source_url: "https://cdn.s3waas.gov.in/s3ae0eb3eed39d2bcef4622b2499a05fe6/uploads/2020/03/2020032381.pdf"
ministry: "Ramban"
title: "Order for Restriction movement of three wheeler and four wheeler"
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "2f1c5e3b1ffcc96d"
---

<!-- page 1 -->

6
GOVERNMENT OF JAMMU & KASHMIR
OFFICE OF THE DISTRICT MAGISTRATE RAMBAN
E-mail: dcramban-jk@nic.in Fax/Ph. 01998-266906, 266789
Sub:- Order under National Disaster Management Act, 2005-regarding.
ORDER
In continuation to the Order issued vide No. DCR/HQA/2583-2603
Dated 16-03-2020 and DCR/HQA/2610-25 dated 17-03-2020, it is hereby
further ordered that all the three/four Wheeler Autos shall also stop
operating in the jurisdiction of District Ramban with immediate effect till 31st
of March 2020.
Any violation of the Order will invite punitive action under relevant
provision of law.
No:-DCR/HQA/ ١ —
Date:- — [3 9०
a a (KAS),
District Magistrate,
0 Ramban
Copy to the: yar
1. Divisional Commissioner, Jammu for information.
2. Senior Superintendent of Police, Ramban for information and necessary
action.
3, Senior Superintendent of Police, Traffic (NH-44) Ramban for information and
necessary action.
4. Additional District Magistrate, Ramban for information and necessary action.
5. Sub-Divisional Magistrate, Gool/Banihal/Ramsoo for information & n/a.
6. Assistant Regional Transport Officer, Ramban for information & n/a.
7. Tehsildars, All for information & n/a.
8. SHO, All for information & n/a.
9. District Information Officer, Ramban for vide circulation of the Order.
10. Executive Officer, Municipal Committee, Ramban/Banihal/Batote for
information & n/a.
