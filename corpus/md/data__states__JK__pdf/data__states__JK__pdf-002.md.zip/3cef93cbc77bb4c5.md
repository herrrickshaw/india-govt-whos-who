---
doc_id: "3cef93cbc77bb4c5"
source_url: "https://sdasrinagar.jk.gov.in/Files/2cd3f92b-0df3-4cb6-a1ba-de74ceb51919/Alert/Appt_C_26052026_4516ea29-7851-4a55-91ad-ae209a47523e.pdf"
ministry: "Srinagar Development Authority, Jammu and Kashmir"
title: "Appointment of Complaint Officer in terms of transgender person (Protection of Right) Act 2019 & Rules thereof.; Dated: 26-5-2026"
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "30db075a1d2c90a3"
---

<!-- page 1 -->

pole SRINAGAR DEVELOPMENT AUTHORITY
SDA Bemina, Bye Pass Near SKIMS Medical College, Srinagar, Kashmir-190018
TEL: 0194-2493191, FAX: 0194-2493180, EMAIL: VCSDA-JK@ nic.in Web: www.sdasrinagar.jk.gov.in
Subject: Appointment of Complaint officer in terms of Transgender Persons
(Protection of Right) Act 2019 & Rules thereof
Order No: ‏و‎ /SDA of 2026
Dated: 27-/05/2026.
Sanction is hereby accorded to appointment of Mr Tariq Hussain Shamas,
I/C Assistant Town Planner, SDA as Complaint Officer in terms of section 11 of
Transgender Persons (Protection of Right) act of 2019 & rules thereof.
An 4 9
Neisoalve/ 849-49 Sd/-
‏ےم ا ےم کے ہددمم‎ 6 Shabir Hussain Bhat Kas)
٦ Vice chairman
Srinagar Dev. Authority.
Copy to:
01. Director Land Management SDA
02. Financial Advisor & CAO SDA
03. Pvt. Secretary to Commissioner Secretary to Government JKHUDD, for information of
Commissioner Secretary. This takes reference to No HUD-ADMOCod/16/2026
(7733403) dated: 15.05.2026.
04. Pvt Secretary to VC SDA for information of Vice Chairman.
05. Programmer SDA for uploading the same on website. ‏کی‎ ?
06. Mr Tariq Hussain Shamas, I/C ATP SDA for information and compliance,“
८22
‏اہی‎ 1
‏بعد‎ a “(۷
‏تم‎ ٠
۰ ‏بر‎ है 5 ‏اکم‎ v
٠ id Naseer ‏س0‎ (JKAS)
Secretary,
Srinagar Dev Authority.
