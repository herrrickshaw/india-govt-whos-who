---
doc_id: "33bbfebeb78f7e6e"
source_url: "https://www.cujammu.ac.in/media/homepage/tenders/180925_tendersec.pdf"
ministry: "Central University of Jammu, Jammu and Kashmir"
title: "Tender for Hiring Security Services for Central University of Jammu"
date: ""
pages: 29
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b894aae33d08d971"
---

<!-- page 1 -->

tEewdsanzh; fo'ofon~;ky;
Central University of Jammu
jk;k&lwpkuh ¼ckxyk½] ftyk lkack&181143] tEew ¼tEew ,oa d'ehj½
Rahya-Suchani(Bagla), District: Samba – 181143, Jammu (J&K)
No: CUJ/Security/2025/03

Date: 4th September, 2025

e-Tender No.: 03/2025
TENDER DOCUMENT
FOR
HIRING THE SECURITY SERVICES FROM THE REGISTERED AGENCY ON 24
HOURS (3 SHIFTS) BASIS THROUGH EX-SERVICEMEN / PARAMILITARY
PERSONNEL AND LADIES SECURITY GUARDS FOR THE UNIVERSITY
CAMPUSES

Last date and time to submit the bids

: 24.09.2025 by 03.00 p.m.

Date and time of opening of technical
bids at CampusRahya-Suchani (Bagla),
District Samba

: 25.09.2025 by 03.30 p.m.

Page 1 of 29

Central University of Jammu

<!-- page 2 -->

DEFINITIONS AND INTERPRETATIONS
The word and expressions beginning with capital letters and defined in this tender Agreement
shall, unless the context otherwise requires, have the meaning hereinafter respectively
assigned to them:
a) “Tender Document” means this document, together with all the Annexures
b) “Applicable Laws” near the laws and any other instrument having the force of laws in

India and Jammu and Kashmir (UT), as they may be issued and in force from time to time
“Authorized Personnel” i.e. any officer of the University duly authorized by Registrar.
“Arbitration” shall have the meaning set forth in relevant Clause of this tender document
“Effective Date” means the date on which this document comes into force
“Government” means the Government of India
“UT Government” means the Government of J&K
“INR. Re or Rs.” Means Indian Rupees
“Services” means the work to be performed as described in the Terms&conditions and
Reference hereto
j) “CUJ” means Central University of Jammu
k) “Approval” Means approval in writing by the designated office or competent authority of
the Employer
l) “ EMD” means Earnest money deposit
m) “Technical Proposal” means the technical part of the bid or application that includes
information/documents required for evaluating the technical eligibility of the bidder.
c)
d)
e)
f)
g)
h)
i)

TERMS AND CONDITIONS
1. Essential Documents: The format for submission of technical bid is as follows:
a) Covering letter / Declaration as per Annexure A
b) Earnest Money Deposit (EMD) in the form of NEFT/RTGS/Net-banking in
favour of “Registrar, Central University of Jammu”
c) The profile and other details of the firm as per Annexure B
d) The agency must be registered with the following statutory authority and also
furnish attested copies of the documents.
I.
a) Registration certificate under:
(i) Contract Labour (R&A) Act, 1970.
(ii) Employees State Insurance (ESI) Office.
(iii) Employees Provident Fund (EPF) Commissioner under the Provident
Fund Act or as per requirement by law
(iv) Income tax, GST, TIN and PAN number.
(v) Any other government authority as notified from time to time by
Central / State Government.
II.
Income tax return for 2022-23, 2023-24 and 2024-25 and GST for the
period ending March 2025.
III.
Copy of ESI / EPF payment for the financial year 2022-23, 2023-24 and
2024-25.
Page 2 of 29

Central University of Jammu

<!-- page 3 -->

IV.

Balance sheet audited by CA for 2022-23, 2023-24 and 2024-25.

2. Experience: The service provider must have minimum experience of 05 years of providing
security services to State / Central govt. educational / research organization. Certificate(s) /
Work Order / Letter of Intent by these organisations for having performed the work / service
good in the said State / Central govt. / educational / research organization must be attached.
The service provider shall provide the reference list of the organization with contact address.
The service provider must not have been blacklisted or debarred by any Government
Organization / PSU etc. The Service Provider may furnish an undertaking to this effect on its
letter head duly signed by authorized person of the firm / agency / Company.
3. The Service provider agency must have its registered office or well established office branch
in Jammu/Samba. (Proof of existence such as rent agreement or certificate of incorporation
etc. must be furnished).
4. The Agency shall hold a valid license from the competent authority under “the Private
Security Agencies Act 2005” as amended from time to time.
5. Availability of tender form: The Bidder shall download the Tender Enquiry Document from
the websites; www.cujammu.ac.in and https://eprocure.gov.in/cppp and shall not
tamper/modify it including downloaded Price Bid template in any manner. In case, the same is
found to be tempered/modified in any manner, Tender/Bid will be summarily rejected and EMD
would be forfeited.
6. Submission of tender: Bids shall be submitted through online mode only at
https://eprocure.gov.in/cppp. Bidding process is online. Technical Bid [filled in
Annexure-A duly signed & stamped, commercial terms & conditions, EMD, relevant
documents and Financial bid (indicating vehicle-wise price as mentioned in Annexure-B),
must be submitted/uploaded online only prior to bid closing date/time. Late tenders will not
be considered.
7. The bidder(s) are advised that they should regularly check the University website
www.cujammu.ac.in and https://eprocure.gov.in/cppp as any change in terms and
conditions, specification, date etc shall be notified on the University website
www.cujammu.ac.in and https://eprocure.gov.in/cppp only.
8. Intending
bidders
are
advised
to
visit
www.cujammu.ac.in
and
https://eprocure.gov.in/cppp only regularly till closing date of submission of bid, for any
corrigendum.
9. Earnest Money Deposit (EMD): The value of the Tender is approximately
Rs.3,40,00,000/- per annum . Hence, the Service provider shall furnish a Earnest Money
Deposit (EMD) in favour of “Central University of Jammu,” of an amount of Rs.10,20,000/(Rupees Ten lakh twenty thousand only) i.e. 3% of the tender value, at the time of
submission of Bid. EMD must be submitted through Net-banking/Debit/Credit card/
RTGS/NEFT @ https://eprocure.gov.in/cppp only.
Page 3 of 29
Central University of Jammu

<!-- page 4 -->

10. . The Service Provider may please note that no interest shall be payable by CUJ on security
deposit and earnest money deposit (EMD). The Service Provider / Agency shall be required to
submit the EMD details in the technical bid. The bid without EMD will be considered as non
responsive and shall be outrightly rejected. EMD of the unsuccessful Service Provider /
Agency shall be returned at the earliest after the expiry of final bid validity and latest by 30th
day after the award of the contract.
11. Bid security Declaration: In lieu of bid security (EMD), registered firms have to fill bid
security declaration accepting that they will not withdraw or modify their bids during
period of validity etc. If the bidders will modify their bids they will be suspended for a period
of three years.
12. Performance Guarantee: The EMD of the selected Service Provider agency will be refunded
without interest on receipt of Performance Security which is Rs 17,00,000/- (Seventeen Lakh
only) or 5 % of estimated tender value, whichever is less will be provided by the successful
bidder in the form of Bank Guarantee or FDR or DD from any Nationalized Bank.
Performance Security must be valid for at least two years and will be released without interest
after successful completion of the term of tender.
13. Turnover: The Service Provider / Agency must have an Annual Average Turnover of not less
than of Rs. 100 Crore each during the last three consecutive financial years 2022-23, 2023-24
and 2024-25 certified by a Chartered Accountant. The Service Provider / Agency should not
have incurred loss in any two years during the last three years as on 31.03.2025.
14. Conditions: University reserves the right to accept or reject any bid without assigning any
reason and reject all bids at any time, without thereby incurring any liability to the affected
Service Provider / Agency or Service Provider / Agency of the ground for such action.
University reserves the right to postpone or extend the date of receipt/ opening of rates /
Quotations or to withdraw the same, without assigning any reason thereof.
15. Tender without required documents, incomplete in any form will be rejected outright.
Conditional tenders will not be considered. Similarly Bids / Bidders quoting ‘Nil’ charges /
consideration shall be treated as unresponsive and will not be considered. Tender containing
false / misleading documents / information will be rejected and may also be liable for
consequences for submitting false information.
16. The Central Purchase Committee may consider any bid, if feels that certain required
documents are not enclosed inadvertently by the firm and the firm promises that the required
documents obtained before the closing date of the tender will be furnished within stipulated
time. The decision of the Vice Chancellor will be final in this regard.
17. In case of failure of Agency to comply with the provisions of the terms and conditions, the
Central University of Jammu reserves the right to award the contract to the next higher
Service Provider / Agency or outside agency and the difference of price will be recovered
from the defaulter agency who has been awarded the initial contract and this will be binding
on the Service Provider / Agency.
Page 4 of 29

Central University of Jammu

<!-- page 5 -->

18. The CUJ does not pledge itself to accept the lowest or any tender and reserve the right to
accept the whole or any part of the tender or portion of the tender offered and Service
Provider / Agency shall supply the same / execute the work at the rate quoted by them.
19. Whenever any claim for the payment of money arise out of or under this contract against the
contractor, the University shall be entitled to recover such sum by appropriating, in part or
whole the performance security or earnest money deposited by the contractor, when the
balance or the total sum to be recoverable, as the case may be, shall be deducted from any
sum then due or which at the time thereafter may become due to be recoverable under this and
any other contract with the purchaser. Should the sum not be sufficient to cover the full
amount recoverable, the contractor shall pay to the University on demand the remaining
balance due.
20. In case the last date happens to be holiday, the last date and opening of bids will be
undertaken on the next working day. The University reserve the right to extend / postpone the
last date and time of the tender without assigning any reason.
21. Each page of the tender should be signed by the owner or authorized signatory of Service
Provider / Agency and total number of the pages submitted should be mentioned. Authorized
Signatory must possess actual authority to submit the bid for which he / she has to essentially
submit Letter of Authority from the competent authority of the Firm / Agency failing which
his / her proposal shall be liable to summary rejection without prejudice to any other right of
CUJ under the law. The proposal shall be filled in by the applicant service provider neatly and
accurately.
22. Any corrections or overwriting would render the proposal invalid. Conditional offers/ offers
which are not in conformity to the prescribed document will be summarily rejected. The
tender document must be duly signed and numbered on every page including annexures.
23. The University shall scrutinize the documents furnished by the firm and shortlist the firms on
lowest quoted basis. The firms who have quoted as per the minimum wages order (central)
will be considered. Thereafter, before opening of financial bids, the committee may visit
actual places of work of firms / agencies to ascertain the actual performance of the firm at
field and recommend any firm starting from L-1 to L-2, L-3 etc after opening of financial bid.
If more than one Service Provider is found to be L-1, preference will be given to bidder
having more experience in providing outsourced security manpower in educational institute of
Govt. of India. The short listed tender along with the documents will be submitted to the
‘competent authority’ and upon approval by the ‘competent authority’ the successful Service
Provider / Agency will be intimated about the award of contract.
24. Term of Contract: The successful Service Provider / Agency on award of the contract should
execute an agreement on Rs. 100/- non judicial stamp paper, with Central University of
Jammu incorporating the terms and conditions. The successful Service Provider / Agency will
be defined as contractor in the said agreement. The contract will be valid initially for a period
Page 5 of 29

Central University of Jammu

<!-- page 6 -->

of one year and on satisfactory performance it may be further extended for (02) two more
years on year basis at the same rate on mutual consent basis. The contract may be terminated
by either party after giving written notice of not less than one month. The rates once accepted
by University shall remain unchanged throughout the period of initial contract of one year,
including any extended period at same rate and under same terms and conditions.
25. The terms and conditions contained in this tender notice shall form the part of contract
agreement to be entered into by the successful Service Provider / Agency.
26. Sub-contract: The agency shall not engage any sub-contractor or transfer the contract to any
other firm / person. In the event of the contractor contravening this condition, the Central
University of Jammu, shall be entitled to cancel the contract and forfeit security deposit and
may place the contract elsewhere on the contractor’s account at his risk and the contractor
shall be liable for any loss and damage, which the Central University of Jammu may sustain in
consequence or arising out of such replacing of the contract.
27. Execution of Contract: In case the agency fails to execute the job / declines the offer of
contract after or before signing the agreement or terminate the contract for whatsoever
reason(s) before completion of period of contract at their own accord, the CUJ shall have the
right to forfeit the EMD and Performance Guarantee deposited by the agency for the
execution of the contract for the remaining period through some other agency.
28. Legal Compliance: The contractor shall take due care to comply with the provision of the
Minimum Wages (Central) as per central govt rules, Contract Labour (Regulation &
Abolition) Act, 1970 including all other legal obligations, like Policy Changes proposed by
the Government or legal amendments from time to time, during the period of the contract. The
wages of the engaged person shall revised as and when the minimum wages (central) stands
revised by labour Commissioner (Central).
29. All existing statutory regulations both State & Central Governments shall be adhered to and
complied with by the contractor and all records maintained thereof should be available for
scrutiny by the University. The Contractor shall strictly comply with the terms and conditions
of the agreement which will be executed with the successful contractor. Failure by the
contractor to comply with such statutory requirements and / or the terms of the agreement
during the period of agreement of deficiency in services shall result in termination of the
contract and the performance guarantee deposit will be forfeited.
30. Workers management: Any personal engaged by the agency if found indulged / indulging in
any unlawful or such other activity against the bonafide interests of the University or such
activities will be immediately (within 120 minutes) disengaged by the Agency. Agency will
keep the University informed about legal/ police/ administrative action taken against such
outsource persons. Agency shall be solely responsible for the conduct and behavior of persons
deployed by the agency. To this effect the agency will have to put in place adequate
supervisory manpower and monitoring mechanism.

Page 6 of 29

Central University of Jammu

<!-- page 7 -->

31. The CUJ will not be responsible for any injury / loss of life of personnel deputed by the
agency which may take place during the course of their deployment. In case of any mishap
such as accident / incident, it is mandatory for the agency to take up and to follow-up with the
legal / police authorities at its own level to the logical end.
32. The decision of Central University of Jammu will be final in considering the security
personnel fit to be employed. The personnel engaged should be preferably below 45 years of
age but not more than 50 years and no child labour shall be engaged.
33. The contractor shall indemnify and shall keep this office indemnified against Acts of omission
or negligence, dishonesty or misconduct of the men / women engaged for the work and this
office shall not be liable to pay any damages or compensation to such person or to third party.
All damages caused by the personnel shall be charged to the contractor and recovered from its
dues / bills.
34. Payment of Monthly Bills: The billing cycle will be calendar month. The service provider
will be responsible for making the payment of wages directly through online transfer into
bank accounts of its workers by 7th of each month from his own resources and subsequently
raise the bill for reimbursement which will be verified by the actual attendance. The payment
of wages is not linked to the clearance of the bill by CUJ. The agency will submit bill with
following information and documents.
a) The wages of outsourced personnel have been credited to their Bank accounts
mentioning Bank account numbers and the details of payment. These details must be
uploaded by the Agency on its website. In case the Agency has no website the said
details must be sent by mail / hand to this office in hard copy.
b) ESI, EPF contribution, Service Tax, GST and other statutory dues paid for the month
of (previous month) deposited on date (copies of challans to be enclosed).
c) Undertaking that all statutory Labour Laws including Minimum Wages (Central) Act
is being compiled with as per the order issued by Labour Commissioner (Central) from
time to time, the wages will be revised accordingly.
35. Service Provider will quote charge rates per person per month on monthly basis and on per
call / day basis separately at financial Balance (Annexure D).
36. GST / other taxes, levies etc. at the rate applicable as per Govt of India rules shall be deducted
from monthly payment of Bill as per rule.
37. Payment to the Service Provider will be subject to provision of satisfactory service which may
be certified by the Officer detailed by the university. The Agency will make online payment
to the staff on a monthly basis by the 7th of each month. The Performance of the security staff
provided by the Service Provider will be reviewed periodically by a committee set up by
Competent Authority & CUJ reserves the right to ask for suitable replacement in the place of
Page 7 of 29

Central University of Jammu

<!-- page 8 -->

persons whose performance are not satisfactory. The Service Provider is bound to supply
suitable replacement within two days in such cases. In case the Service Provider fails to
supply suitable replacement within two days, a penalty of Rs. 5000/- (Rupees five thousand
only) per day thereafter will be levied by CUJ.
38. Deduction of statutory dues from the payments to the staff provided and timely remittance
thereof would be the sole responsibility of the Service Provider /Agency. If at any time it was
found that the service provider has paid less than minimum wages at any point of time or has
not remitted PF, ESI, EDLIetc, the University reserves the right to forfeit Performance
Security and disburse the dues out of the performance security. In such case, the service
provider / agency has to furnish fresh performance security of the requisite amount.
39. The Service Provider shall maintain / produce / the required records / documents as and when
called for by the appropriate authority, as well as to CUJ to enable it to verify that the Service
Provider is complying with statutory requirements with regard to GST, TDS, PF, ESI, EDLI
and other labour laws, from time to time.
40. Duties and Functions of Service Provider / Agency: In performing the terms and
conditions of the Contract, the Service Provider shall at all times act as an Independent
Service Provider. The contract does not in any way create a relationship of principal and agent
between CUJ and the Service Provider. The Service Provider shall not act or attempt or
represent itself as an agent of CUJ. It is clearly understood and accepted by both parties that
the Contract between the parties evidenced by it is on a Principal to Principal basis and
nothing herein contained shall be construed or understood as constituting either party hereto,
the agent or representative of the other, under any circumstances. The employees of the
Service Provider shall never, under any circumstances whatsoever, be entitled to claim
themselves to be the employees of the CUJ. There will no employer-employee relationship
between CUJ and the persons engaged by the Service Provider. The persons deployed by the
Agency shall neither claim nor shall be entitled to pay, perks and other facilities admissible to
contractual or regular employees of the CUJ during the currency or after expiry of the
contract. Service provider for its own benefit / record will submit an affidavit from the
outsourced employees to the effect that this employment offered by the Agency is purely of
temporary nature. Under no circumstances this employment will entitle the employee for
claims of Permanent employment, continuation or any other entitlements except mentioned in
the contract.
41. The Service Provider shall provide a substitute well in advance if there is any probability of
the functionary leaving the job due to his / her own personal reason. The payment in respect of
the overlapping period of the substitute shall be responsibility of the service provider.
42. Manpower will be supplied by the Service Provider as per actual requirement which may vary
on day to day or monthly basis (fresh requirement other than replacement), which will be
informed to the Service Provider. The Service Provider is bound to supply the required
manpower within a maximum of two days. In case the Service Provider fails to supply
manpower within two days, a penalty of Rs. 5000/- (Rupees five thousand only) per day
Page 8 of 29

Central University of Jammu

<!-- page 9 -->

thereafter will be levied by CUJ. In case of leave / absence of manpower/ weekly off, alternate
arrangement will be made by the Service Provider. Contractor will be fully responsible for
payment of wages to weekly off relievers/absent relievers.
43. Manpower Agency/Service agency will provide the names, addresses, aadhaar card and
photographs of the security guards/security supervisors to CUJ. The firm will be required to
submit the copy of pension payment order in respect of Ex-servicemen/Para military
personnel at the time of contract.
44. The engagement of outsourced manpower in no case confers any right for continuation,
extension of the contract, absorption or permanent employment in CUJ.
45. The personnel supplied by the Service Provider will be the employee of the Service Provider
and there will be no master-servant relationship between the CUJ and personnel deployed. All
the statutory liabilities and responsibilities will be that of the Service Provider and CUJ has no
legal responsibilities on the same.
46. The contractor shall be responsible for proper maintenance and upkeep of the uniforms, torch
and all other items. The service provider shall provide the following items at his own cost:
S/no. Manpower
1
Male Security
Guards/Supervisors

2

Female Security
Guards

Page 9 of 29

Uniform Particulars
Quantity
Half Sleeves shirt with name printed on 02 No.
the shirt
Full Sleeves Shirt with name printed on 02 No.
the shirt
Trousers
Belt with Black buckle with all
01 No.
attachments for holding, torch, Acrylic
lathi, and other security equipment
Sea Cap
02 No.
Lanyard with whistle
02 No.
Shoes
02 Pair
Socks
04 Pair
White T-shirt with CUJ logo
02 No.
Jersey
01 No.
Jacket (warm inner –water proof outer)
01 No.
Monkey Cap
02 No.
Rain coat
01 No.
Umbrella
01 No.
Danda
01 No.
Punjabi Suit-Salwar Light Blue colour
02Set
with navy blue dupatta
Shoes
02 Pair
Socks
04 Pair
Jersey
01 No.
Jacket (warm inner –water proof outer)
01 No.

Remarks
1 year
1 year
1 year
1 year

1 Year
1 Year
1 Year
1 Year
1 Year
1 Year
1 Year
1 Year
1 Year
1 Year
1 Year
1 year
1 Year
1 Year
1 Year
1 Year

Central University of Jammu

<!-- page 10 -->

3

Common

Rain coat
Umbrella
Walkie talkie
Search Light 1 Km Range
Binocular
Night vision Device
Bamboo Sticks 5 Feet
Acrylic sticks 4 Feet
Hand held metal detector
Door Frame Metal Detector
Cattle Catcher Vehicle

01 No.
01 No.
30 No.
30 No.
05 No.
20 No.
60 No.
60 No.
10 No.
05 No.
ORB

1 Year
1 Year
1 Year
1 Year
1 Year
1 Year
1 Year
1 Year
1 Year
1 Year

47. The contractor will not allow or permit his/their employees to participate in any trade union
activities or agitation in the premises of Central University of Jammu, violation of which may
result in the termination of the contract immediately.
48. The agency shall not replace the staff frequently without proper substitute and without prior
permission. In normal conditions security personnel will not be deployed for double duty.
However, in case of emergency/urgency, security personnel may be allowed for not more than
two continuous duties with proper written information to the office authorities.
49. The agency / contractor shall work under the overall supervision and direction of the officer
authorized by Central University of Jammu.
50. The charges of firm once accepted by this office shall remain unaltered throughout the period
of initial contract of one year, including any extended period at same rate and under same
terms and conditions. However, if the University changes its premises, increase the security
personnel for service, the same will be increased at the agreed rates and under same terms and
conditions.
51. In case of emergency and residual situations, the contractor has to make the personnel
available to cater for emergency services and urgent works entrusted by this office as and
when need arises.
52. The responsibility of payment of wages for the personnel deployed to carry out the contract
lies with the contractor and the University shall not entertain any representations, whatsoever
in this regard.
53. The Proprietor of the Agency or his authorized representative shall visit the Security office /
officials twice a week for review of the security system at the University campuses.
54. The security personnel working in the University at different posts shall cover the area
earmarked by the administration for patrolling. The premises include the covered area of the
building and outside space within the boundary of the building to be guarded by the security
Page 10 of 29
Central University of Jammu

<!-- page 11 -->

personnel.
55. The security personnel under the agency shall follow the instructions of the University from
time to time. The Security Agency will be under the administrative control of the University
and the Security personnel while performing the duties will be under supervising control of
First Party. The Security personnel shall perform the duties with utmost care and loyalty and
they neither develop undue familiarity nor join any union of the employees of Second Party.
The First Party shall be held responsible for the entire administration of security staff under
law for the time being in force.
56. In case, any statutory authority imposes any punishment like fines etc due to security lapses,
and if the University is made a party in such penal action, the University has the right to
retain the security deposit etc, until it is proved to the satisfaction of the University that such
penal actions are ceased. Such penal actions may also be a reason for termination of contract.
57. The security personnel at the University shall check and ensure that all the Departments /
Branch / Buildings are properly locked after the office hours.
58. No person who has been convicted by a competent court or who has been dismissed or
removed on grounds of misconduct or moral turpitude while serving in any of the armed
forces of the union, state police organizations, Central / State Governments or in any private
security agency shall be employed or engaged as a security guard or a supervisor. No person
who is facing criminal charges or being contemplated against him shall be deployed for watch
and ward in the University.
59. The agency should maintain strict discipline in dealing with the University employees and
should not act in any manner unbecoming of a security person.
60. The University shall not provide any accommodation for guards or other personnel deployed.
61. Any person who may be or has been employed or engaged as a security guard by the private
security agency shall not divulge to anyone other than the University authorities any
information acquired by him during such employment with respect to the work which he has
been assigned by such employer.
62. In case if it is required to engage guards on extra duty / overtime, it shall not exceed 100
hours or 1/3 of the salary, whichever is less per month per guard, subject to approval of the
University.
63. If the attendance falls short of contracted minimum number of persons, penalty @ Rs. 1000/(Rupees one thousand) per person per day shall be deducted from the bill. The amount so
deducted shall be final and no claim whatsoever will be entertained under any circumstances.
64. Any security guards / supervisors found without I.D. cards shall be treated as absent and shall
not be allowed in the campus.
Page 11 of 29

Central University of Jammu

<!-- page 12 -->

65. A penalty up to Rs. 5,000/- (Rupees Five thousand only) per instance will be imposed on the
agency, if:
i. Security Guard found in drunken position
ii. Security Staff misbehaves with any person
iii. Found slept
iv. Left the place (except in circumstances beyond his control)
v. Presence of Unauthorized vehicle in the Campus
vi. Presence of Unauthorized person in the campus
vii. Trespassing inside campus
viii. Found without gadgets like lathi, torch, walkie talkie, whistle etc.
ix. Any other act which as per the decision of the authority constitute an offence.
66. In all the three shifts, the security staff shall be properly dressed, possess whistle, lathi and
torch light etc. If any guard is not suited to the duty, the security agency must replace such
guard immediately.
67. The firm should ensure that the Security guards should be well versed in basic firefighting to
meet any eventuality.
68. The agency will provide Bolero/Jeep/Thar/multipurpose vehicle not older than 2 years for
day, night patrolling and other activities related to security services. The bidder must quote
vehicle charges inclusive.
69. Scope of work
1) To maintain 24 hours fool-proof security in 3 shifts system in the University campuses at
various posts, offices and at different campuses including Jammu and Nathatop, Udhampur.
2) The Agency shall restrict the entry of all unauthorized person in the University campuses.
3) The agency shall maintain all security registers such as in & out registers, Vehicle
Movement Register, Visitor’s Register, Material Register, Gate Pass Register etc.
4) The Agency shall check the Vendors’ passes carefully.
5) Any other security related duties assigned in the manner as provided from time to time by
the University.
6) The Agency shall maintain cordial relations with the University community.
7) The agency must produce original Bio-data / credentials of security personnel for
verification.
70. Job responsibility of the Agency
1) To make compliance to all

the

provisions

of

Labour

Laws

applicable.

2) The security Supervisor to submit day to day report of the happenings in the University
and give suggestions for strengthening the overall security.
3)
In case of any loss or theft of office property, equipments, furniture etc. attributable
to the negligence of the agency personnel, as decided by the CUJ, it shall be made good by the
agency and in the event of failure on their part to do so within a period of one month, the
same shall be made good by the event of performance guarantee and if the amount of loss or
damage exceeds the amount of performance guarantee, then the amount shall be recovered
Page 12 of 29

Central University of Jammu

<!-- page 13 -->

from the agency either out of the dues payable to the agency or through the court of law.
4)
The terms and conditions contained in this tender notice shall form part of and shall
be taken as if they were included in the contract agreement to be entered into by the
successful bidder.
71. STAFF REQUIREMENT
The required staff shall be provided by the Agency on outsourced basis. The wages will be paid
minimum wages as per Labour Commissioner (Central), Ministry of Labour and Employment,
GOI (presently order dated 28-03-2025) and the same will be revised from time to time as
revised by the Government of India order. All outsourced persons will be screened by the
University for Engagement Suitability.
The tentative requirement of staff is given below. The actual requirement may vary from
time to time. University reserves the right to add/delete the designations alongwith
increase/decrease the no(s) of manpower as per below table: S.No.

Designation(s)

Tentative
Requirement
1.
Security Supervisors
06
2.
Security guards
75
A) The agency should deploy energetic and trained security personnel between the age group of
18-50 and preferably Hindi/English/Dogri speakers.
B) Security staff should be minimum 10 th class pass or as per ESM norms.
C) Security staff female/civilian should be below the age of 45 year and have previous
experience of 2 years at security setup.
D) Security Supervisor should be of the rank of Subedar or equivalent or above.
E) The agency shall deploy atleast four Security guards who are ex-serviceman of
Defence/paramilitary forces of driver trade.
F) Security agency shall provide stray animal catcher in each shift in the strength of the security
staff. A penalty of Rs. 2000 per instance will be imposed on the agency if stray animals found
inside the campus.
G) Agency must provide trained fire fighters having valid certificate in fire and safety in each
shift.
H) Security personnel deployed will have to mandatory undergo security and safety related
programs, trainings and Sharmdhaans organised by the University.
I) The agency will ensure the physical fitness and discipline of the security staff deployed. Drill
and PT of the security staff deployed shall be conducted regularly by the agency and the
photograph to be provided with GPS enabled photo.
Page 13 of 29

Central University of Jammu

<!-- page 14 -->

J) Annual fire test of the armed security staff shall be conducted by the agency and its result to
be submitted to the security office, failing to do so extension will not be granted.
K) Physical efficiency test of all the ESM shall be conducted by the agency twice a year and it’s
resulted to be submitted to the security office.
72. Government orders/guidelines regarding tenders till date of submitting of bids shall be
applicable.
73. Disagreement: In case of any disagreement or dispute between the first party (i.e. Central
University of Jammu) and the second party (i.e. agency) arising out of or due to the terms and
conditions of contract agreement, Vice Chancellor, Central University of Jammu shall have the
discretion for settlement of such disputes by appointing a sole arbitrator according to the
arbitration and conciliation act,1996 and the award so made by an arbitrator shall be final and
binding on both the parties. Jurisdiction shall be Jammu only, for any dispute. The laws of India
and J&K laws are applicable. Sole arbitrator shall not be an employee of any of the party in this
agreement.

Registrar
Encl:
Annexure-A: Covering Letter
Annexure-B: Declaration Form
Annexure-C: Technical Bid
Annexure-D: Financial Bid
Annexure-E : Bid Security Declaration Form
Annexure-F: Documents to be provided after award of Contract

(1 page)
(1 page)
(1 page)
(1 page)
(1 page)
(1 page)

Schedule of e-Tender:
1
.
2
.

Published Date

3
.

Bid Submission Start Date

4
.

Bid Document Download End Date

5
.

Bid Submission End Date

Bid Document Download / Sale Start Date

Page 14 of 29

Central University of Jammu

<!-- page 15 -->

6
.

Bid Opening Date(Technical)

7
.

Tender process fee (online mode)

8
.

EMD (online mode)

Page 15 of 29

Central University of Jammu

<!-- page 16 -->

Annexure–A
SERVICE PROVIDER / AGENCY’S COVERING LETTER
(To be printed on Agency’s Letter Head and submitted in Technical Bid )
To
The Registrar
Central University of Jammu
Samba-181143
Sir,
Ref: Tender no:
After examining the conditions of contract and specifications described you in
Notice Inviting Tender, we the undersigned intend to offer our services for the work
shown in the scope of work and jurisdiction of contract as well as schedule of prices
attached herewith and made part of this.
We undertake that, if our bid is accepted, we shall provide the service s in
accordance with, time limits and terms & conditions stipulated in the tender documents. If
our bid is accepted, we shall submit the performance guarantee as per the conditions
mentioned in the contract. We agree to abide by this bid for a period of 90 days from the
date of bid opening and it shall remain binding upon us and may be accepted at any time
before the expiry of that period. Until a formal agreement is prepared and executed, this
bid together with its written acceptance thereof in the notification of award shall
constitute a binding contract between both the parties.
Bid is properly prepared, sealed and submitted so as to prevent any subsequent
alteration or replacement.
Dated this ………………...Day of

(The month and year)

Signature of Authorized Signatory ……………..….…………….………………..
In capacity of ……………………………………… Duly authorized to sign the bid for
and on behalf of………………………………

Page 16 of 29

Central University of Jammu

<!-- page 17 -->

Annexure B
DECLARATION BY THE SERVICE PROVIDER
(To be printed on Agency’s Letter Head and submitted in Technical Bid )
1. I,................................................................

Son

/

Daughter

/

Wife

of

Shri.............

....................................... Proprietor / Partner / Director / Authorized signatory of M/s.
.......................................... and competent to sign this Declaration and execute this tender
document on behalf of agency.
2. I have carefully read and understood all the terms and conditions of the tender and hereby
convey my acceptance of the same.
3. The information / documents furnished along with the above application are true and authentic
to the best of my knowledge and belief. I / We, am / are well aware of the fact that furnishing of
any false information / fabricated document would lead to rejection of my tender at any stage
besides liabilities towards prosecution under appropriate law.

Signature with date & seal of the agency

:

....................................

Name of the applicant

:

....................................

Designation

:

....................................

Page 17 of 29

Central University of Jammu

<!-- page 18 -->

Annexure–C

Sl.
No.
i
ii

iii

iv
v
vi

vii

Technical Bid
(To be filled by the agency and must be submitted to CUJ only with the technical bid)
Details (if yes, furnish number)
Particulars
Enclosure number
Name of the Firm / Agency:
Status of the Firm / Agency:
(Proprietorship / Partnership / Joint Stock
Co. etc)
Address:
a) Office:
b) Residence:
Telephone / Mobile No. / E-mail address /
Website address
Name of the Proprietor / Partner / Director
Documentary Proof of :
a) Valid Registration with State sale
tax authority, certificate No.
b) Proof of incorporation inception of
agency for supply of manpower /
valid labour license
c) EPF registration proof
d) ESI registration proof
e) TIN / PAN No.
f) Income tax return for 2022-23,
2023-24 & 2024-25
g) Balance sheet for 2022-23, 202324 & 2024-25
h) GST clearance certificate for the
period ending 31.03.2025
i) Experience
certificate
from
Government / Semi Govt. / PSU
where the agency has supplied a
group of more than 10 persons at a
time for housekeeping and general
services
j) Annual turnover for financial year
2022-23
k) Annual turnover for financial year
2023-24
l) Annual turnover for financial year
2024-25
Earnest Money Deposit (EMD) details
a) Amount of Earnest money
b) Name of the Drawer and Drawer
Bank
c) No. and Date of the Bank Draft
OR
Bid Security Declaration Form

M/s.

Yes / No
Yes / No

Yes / No
Yes / No
Yes / No
Yes / No
Yes / No
Yes / No
Yes / No

<!-- page 19 -->

viii

Technical evaluation criteria

A

Number of years
of incorporation

B

C

D

E

F
G

H

Relevant
experience in
providing
security services

Valid ISO
certification

Audit turn over
in the last three
financial years
( 2022-23, 202324 & 2024-25)

Number of years
of operation in
providing
security services

Marks

0 to 5 years

3 marks

More than 5 years
In centrally funded
institutes

5 marks
5 marks
for each
contract
3 marks
for each
contract
3 marks

In reputed
govt./semi Govt.
organizations
Holding for last 5
years
Holding more than 5
years
More than 50 crore
and less than 250
crore
More than 250 crore

0 to 5 years
More than 5 years

Self
score to
be filled
by the
bidder

Maximum
score

Score
validation
(by CUJ)

Enclosure
Number

5 marks
20 marks

10 marks

1 mark for
each year
5 marks

30 marks

10 marks
for each
financial
year
3 marks

10 marks

1 mark for
one year

National
presence
For the last three
Number of
years ( 2022-23,
similar works
2023-24 & 2024-25)
providing
security services
of 100 persons or
more
Training centre
facility
TOTAL

1 mark for
each state
1 mark for
each work

10 marks

5 marks

5 marks

10 marks

100
marks

Declaration: I hereby certify that the information furnished above is true and correct to the best of
my / our knowledge. I understand that in case any deviation is found in the above statement at any
stage, I / we will be blacklisted and will not have any dealing with the University in future.
Signature with date & seal of the agency
:
…………………………………………
Name of the Applicant

:

…………………………………………

Designation

:

…………………………………………..

<!-- page 20 -->

(a) Technical Bid Score: Technical Bid Score 'St' of the Bidder shall be derived as under
St= (Stm/SH)*100, where
St = Technical Bid Score
Stm = Score obtained by the concerned bidder
SH = Highest total Technical Bid marks amongst all Evaluated Bids.
(b) Evaluation of Financial Bids: Financial Bids of the Bidder, who is Technically Qualified, shall
be considered. The formula to determine the Scores for Financial Bids shall be as follows:Sf= (FL /F) *100, where
Sf = Financial Score
FL = Value of Lowest Commercial Bid
F = Price quoted in the Bid under consideration,
(c) Combined Evaluation of Technical & Financial Bids
The total Score of the Bidder will be determined under
Total Score (TS) = (0.70 x St) + (0.30 x Sf)
Notes:
(i)
(ii)
(iii)
(iv)
(v)
(vi)
(vii)

Weightage of Technical Evaluation: 70%
Weightage of Financial Evaluation: 30%
Total Weightage (Technical + Financial Evaluation = 100%)
60% of Maximum Marks are required in Technical Evaluation to Qualify for Financial
Evaluation.
Financial Bids will be opened only for those Firms Qualifying in Tech Evaluation
Work Order may be Awarded to the Highest Scorer, Overall (Technical + Financial
Evaluation).
In case two or more tenders are equal in marks, work will be awarded to the Service
Provider who has executed contracts of higher values. The decision of the Central
University of Jammu shall be final in this regard.

<!-- page 21 -->

Annexure–D
FINANCIAL BID
Quotation for security services for the Central University at Jammu city (class B city) and
University Campus at District Samba (class C city)
Amount quoted enclosure: (To be filled by the agency & to submit to CUJ along with Financial bid)
Minimum Wages (central) shall be paid by the firm as per the order issued by the Labour
Commissioner (central), Ministry of Labour and Employment, GOI (presently order dated 28-032025) and the same will be revised from time to time as revised by the Government of India order.
Rate in Rupees Rate in rupees
Rate in rupees
Wages details of
Per Security
Per Security
Per Security
Percentage
Security personnel
Supervisor per Guard with
guard without
month
arms per month arms per month
A

Basic Wages +VDA

B
C

12% of Basic +VDA
0.5% of Basic +VDA

M

EPF
Admin charges
Employees Death Life
Insurance
ESI
Total Cost per day/ head
Number of Security
Personnel per day
Total Cost per day
Monthly Charges for
Manpower
Service Charges of
Agencyincluding charges
for Patrolling Vehicle
(Bolero/Scorpio etc.)
with driver upto a limit
of 2000 km inclusive of
fuel and maintenance
Rate per Km exceeding
monthly limit
Monthly charges
including service charges
GST

N

Total Monthly Charges

Sum of L and M

D
E
F
G
H
I

J

K
L

0.5% of Basic +VDA
3.25% of Basic+VDA
Sum of Serial A to E

As per the order
of Labour
commissioner
(Central) in
force for watch
and ward

As per the order
of Labour
commissioner
(Central) in force
for watch and
ward

As per the order
of Labour
commissioner
(Central) in force
for watch and
ward

3

15

57

FxG
H x 30 days

% of I

Rate for 10 Km
Sum of I, J and K
As per rule

(in case of any ambiguity, amount of financial bid quoted in words shall be taken as final)
*If a person(s) is required on per call basis, payment per day will be made by adding Basic wages
and VDA
Signature with date & seal of the agency
Name of the Applicant
Designation

:
:
:

…………………………………………
…………………………………………
…………………………………………..

<!-- page 22 -->

Annexure-E
Bid Security Declaration
To
----------------------------------------------------------------Ref: Tender document No.......................... dated ...........................
We, the undersigned declare that: We know that the bid should be supported by a Bid Security Declaration
in accordance with your conditions.
We accept to automatically be suspended from being eligible for bidding in any contract in CUJ for a
period of 3 years from the date of opening of Bid. If we are in breach of our obligation(s) under the bid
conditions, because we:
After having been notified of the acceptance of our bid by the Contracting Authority within the period of
bid validity:
1) We failed or refused to furnish a Performance Security in accordance with the Condition of the Tender
Document of Tender No. OR
2) We failed or refused to sign the contract.
We know that this Bid-Securing Declaration will expire, if contract is not awarded to us, upon :
1) Our receipt of your notification to us of the name of the successful bidder or
2) Twenty –eight days after the expiration of our Bid or any extension to it
We know if we are a Joint Venture, Securing Declaration should be in the name of the JV submitting the
bid. If the JV is not legally constituted at the time of bidding, the Bid-Securing Declaration will be in the
name of all partners named in the JV agreement.
Dated this ________________ day of_______________________
For and on behalf of M/s._____________ Address :
Signature
Name
In the capacity of (DULY AUTHORISED TO SIGN THE BID)

<!-- page 23 -->

Annexure F
DOCUMENTS TO BE SUBMITTED BY THE SUCCESSFUL SERVICE PROVIDER
AFTER AWARD OF TENDER BUT BEFORE DEPLOYMENT OF MANPOWER

1.

List of Manpower shortlisted by service provider for deployment in CUJ containing
full details i.e. date of birth, marital status, address, educational qualification, photo ID
Card provided by the security service provider etc.

2.

Bio-data of all persons.

3.

Any other document considered relevant

<!-- page 24 -->

DRAFT SPECIMEN AGREEMENT
This Agreement is made on __________ by and between the Central University of Jammu,
(hereinafter to be referred as ‘CUJ’) a statutory body established under Central Universities Act, 2009
(Act no. 25 of 2009) read with Central Universities (Amendment) Act, 2009 (Act no. 38 of 2009),
having headquarters at Rahya-Suchani (Bagla), District Samba, Jammu, J&K-181143, & acting
through its Registrar, expression of which shall unless be excluded by or repugnant to the context be
deemed to include its successors-in-interest and assigns.
And
(name& address of the firm) (Hereinafter called
the ‘Firm’) which term shall include its authorized representatives, assignees etc.

Whereas the CUJ has invited tenders for hiring the security services from the registered agency on 24 hours
(3 shifts) basis through ex-servicemen / paramilitary personnel and ladies security guards for the university
campuses vide Tender No.............................. dated.....................to work at any of its campuses, hostels or
designated places.
Whereas the Firm has offered to provide the services at the rates mentioned in its financial bid no.....
dated......... as per terms and conditions mentioned in the said tender
Whereas the CUJ vide its award letter no........... dated.............. has accepted the offer made by the firm
attached as Annexure A.
NOW THEREFORE, IN CONSIDERATION OF THE PREMISES CUJ AND FIRM HAVE AGREED
TO REDUCE INTO WRITING THEIR AGREEMENT IN THE MANNER SET OUT THEREIN AS
FOLLOWS:
1.

This agreement shall come into force w.e.f. …………..(date)
and will remain
in force for a period for one year but can be terminated by CUJ by giving one calendar
months’ notice in writing of its intentions to terminate the Agreement. The Agreement
can be renewed, on mutually agreed terms for another term(s).

2.

The firm shall be responsible for providing security personnel at CUJ campuses, Hostels etc. as
per rate mentioned in the Award Letter.
The firm will provide full particulars of every worker deployed by it for providing the
services and get their character and antecedents verified from the Police Authorities.
All personnel posted at premises shall at all times and for all purposes be deemed to be
employees of the firm and the CUJ shall have no liability on this account in any manner.
That the Firm shall ensure that all persons deployed at CUJ premises are of good
character, well behaved and otherwise competent and qualified to perform the work for
which they are deployed.
The CUJ shall have the right to ask for the removal from its premises any personnel
considered by them to be incompetent, disorderly or any other reason and such person
shall not again be deployed without the consent of the CUJ.

3.
4.
5.

6.

<!-- page 25 -->

7.

8.

9.

10.

11.
12.
13.
14.
15.
16.
17.
18.
19.
20.

The firm will raise a bill only after making payment to the manpower i.e. on 7th of each
month and the payment will be released by the CUJ through RTGS / PFMS / IMPS /
NEFT to the firm subject to satisfactory performance / delivery of contracted job / work/
services. Copies of documents such as deposit challans along with list of persons
showing deposit of ESIC, EPF with the concerned agencies are also to be deposited with
the bill. The deduction of income tax from the bills of the Agency will be made at source
as per rates applicable from time to time.
The firm shall issue identity card to each of the workers engaged for entry into CUJ
premises and shall ensure the successful implementation of the terms and conditions of
the agreement. In case the Firm fails to perform any of the terms and conditions of this
agreement or commits any breach of the contract, CUJ may cancel the contract.
The Firm agrees to discharge all their legal obligations in respect of their workers in
respect of their wages and services conditions and shall also comply with all the rules and
regulations and provisions of law in force that may be applicable to them from time to
time, viz. obligations under Contract labour (Regulation & Abolition) Act. 1970,
workmen's Compensation Act, 1923, E.P.F., E.S.I. & M.P. Act, 1952 etc. Firm agrees to
indemnify and keep indemnified the CUJ on account of any failure to comply with the
obligations under various laws or damage to CUJ due to acts/omissions of Firm.
It is also agreed that under no circumstances, the volunteers and/or the
employees/workmen of the Firm shall be treated, regarded or considered or deemed to be
the employees of the CUJ and the Firm alone shall be responsible for their remuneration,
wages and other benefits etc. Firm shall indemnify and keep indemnified the CUJ against
any claim that it may have to meet towards the employees / workmen of the Firm. Firm's
employees / workmen shall have no claim to absorption / regularization and financial
benefits etc. that are admissible to regular employees in the office of CUJ.
The contract is subject to the conditions that the firm shall comply with all the laws and
byelaws of Central Govt. / State Govt. as applicable relating to this contract.
In case of any loss or damage to the property of the CUJ at which is attributable to the
firm, the full damages will be recovered from the firm as decided by CUJ.
The Firm shall not transfer its right or sub- contract to anyone else.
The Firm or its workers shall not misuse the premises allotted to them for any purpose
other than for which contract is awarded.
The Firm shall devote its full attention in service to ensure highest quality in all aspects
and discharge its obligations under the contract with trust, diligence and honesty.
Compensation to the workers in case of any accident, loss of life during discharge of their
duties shall be borne by the Firm and not by CUJ in any manner.
There will be surprise checking by an Officer. Shortcomings, if any, pointed out by
her/him shall be restored by the contractor within 24 hours of its bringing to his notice.
The firm shall provide a Co-ordinator for immediate interaction with the organisation.
The terms and conditions as stipulated in the tender documents and enclosed herewith,
shall be part of the agreement.
All clauses, terms and conditions of the tender shall form part of this agreement and
therefore attached as Annexure B

<!-- page 26 -->

In the event of any claim, dispute or controversy arising out of or in relation to this MoU, including
any dispute with respect to the existence or validity thereof, the interpretation thereof, the activities
performed hereunder or the breach of this MoU, the parties shall endeavour to settle the same
amicably by negotiation., Any claim, dispute or controversy which cannot be resolved by
negotiation, any Party may refer the claim/ dispute to be settled through the provisions of the J& K
Arbitration and Conciliation Act, 1997 and the rules made there under and any statutory
modification and re-enactment thereof shall be deemed to apply and to be incorporated in this MoU.

Authorised Signatory
(Name & Address of the firm)

Witnesses:

Registrar
Central University of Jammu

Witnesses:

1. ______________________________

1.______________________________

2. ______________________________

2. ______________________________

<!-- page 27 -->

Ttender for Security Services

PROFORMA FOR CHECKLIST DOCUMENTS
Reply

SN

Particular

1
2

Name of the Agency
Detail of Earnest Money Deposit
Amount………………………
DD No. ………………………..
Date……………………………..
Bank……………………………..
Date
of
Incorporation
or registration of
the Agency (Copy
of Registration Certificate)
Office address of the Agency including Phone No. of
Persons to
be contacted
Whether registered with all concerned govt.
auth.
ESI/EPF/Service Tax/ Labour Commr./S. Tax
etc.)
PAN Number of the Agency
(Copy to be enclosed)
GST Number
(Copy to be enclosed)
An Affidavit attested by Notary on a Stamp paper
of appropriate value to this effect, that company has
not been blacklisted or banned for their business
dealings with
Government Departments.

3

4

5

6
7
8

9

Experience in dealing with Educational Institutions.
(Copy of work order or relevant documents
to be enclosed).

10

List of other clients

Pg. no. of
Document

Signature of the authorized
signatory of the Service
Provider / Agency with seal
of the Firm
Page 27 of 29

Central University of Jammu

<!-- page 28 -->

Ttender for Security Services

INSTRUCTIONS TO BIDDERS FOR E-TENDER:
Special Instructions for e-Tender. Submission of online Bids is mandatory for this Tender.
For conducting electronic tendering, CUJ is using the portal https://eprocure.gov.in/cpppand
GEM Portal.
1.0 Tender Bidding Methodology:
The offer should be submitted through e-tendering mode in the website
https://eprocure.gov.in/cpppcontainingtwo e-bid viz. Technical and Financial Bid. The Bids
willbe uploaded along with all signed and scanned documents those are required for particular
tender.
.Digital Certificate:
It is mandatory for all the bidders to have class-III Digital Signature Certificate – Signing +
Encryption (in the name of person who will sign the Bid) from any of the licensed Certifying
Agency (Bidders can see the list of licensed CA’s from the link www.cca.gov.in) to participate in
e-tendering.
2.0 REGISTRATION:
i)
Bidders
to
enroll
on
the
e-Procurement
module
of
the
portal
http://eprocure.gov.in/eprocure/app by clicking on the link “Click here to Enroll”. Enrolment on
the CPP Portal is free of charge.
ii)
The bidders to choose a unique username and assign a password for their accounts.
Bidders are advised to register their valid email address and mobile numbers as part of the
registration process. These would be used for any communication from the CPP Portal.
iii)
Bidders to register upon enrolment their valid Digital Signature Certificate (Class II or
Class III Certificates with signing key usage) issued by any Certifying Authority recognized by
CCA India with their profile.
iv)
Only one valid DSC should be registered by a bidder. Please note that the bidders are
responsible to ensure that they do not lend their DSCs to others which may lead to misuse.
Foreign bidders are advised to refer “DSC details for Foreign Bidders” for Digital Signature
requirements on the portal.
v)
Bidder then logs in to the site by entering their user ID / password and the password of the
DSC / e Token.

Page 28 of 29

Central University of Jammu

<!-- page 29 -->

Ttender for Security Services

2.1 SEARCHING FOR TENDER DOCUMENTS:
vi)
Various built-in options are available in the CPP Portal to facilitate bidders to search
active tenders by several parameters. These parameters include Tender ID, organization, location,
date, value, etc.
vii)
There is also an option of advanced search for tenders, wherein the bidders may combine a
number of search parameters such as organization name, form of contract, location, date, other
keywords etc. to search for a tender published on the CPP Portal.
viii) Once the bidders have selected the tenders they are interested in; they may download the
required documents / tender schedules. These tenders can be moved to the respective ‘My
Tenders’ folder. This would enable the CPP Portal to intimate the bidders through SMS / e-mail in
case there is any corrigendum issued to the tender document.
ix)
The bidder should make a note of the unique Tender ID assigned to each tender; in case
they want to obtain any clarification / help from the Helpdesk.
3.

TENDER FEE & EARNEST MONEY DEPOSIT (EMD):

1.
The Bidder should submit Tender Fee of Rs 5900/- (Fifty-nine hundred only) – NonRefundable / Not-Exempted, by Net-banking / Debit / Credit card and proof/copy of the same
should be attached for reference.
Bank Details of Central University of Jammu
NAME OF THE ACCOUNT HOLDER: Registrar, Central University of Jammu
NAME OF BANK: THE JAMMU & KASHMIR BANK LTD.
BRANCH NAME: RAHYAA
ADDRESS OF BANK: Rahyaa Suchani, Samba
IFSC CODE: JAKA0RAHYAA
A/C NUMBER: 0345040500000002
The Technical Bid without Tender Fee & EMD would be considered as UNRESPONSIVE and
will not be accepted.
2. The Tender Fee and EMD shall be denominated in Indian Rupees only. No interest will be
payable to the bidders on the amount of the EMD.
For any query related to tender, may contact Security Officer, Sh. Balwan Singh – 9366530264.

Page 29 of 29

Central University of Jammu
