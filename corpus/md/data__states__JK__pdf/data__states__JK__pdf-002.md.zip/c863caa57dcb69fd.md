---
doc_id: "c863caa57dcb69fd"
source_url: "https://hme.jk.gov.in/assets/pdf/DFC.pdf"
ministry: "Health and Medical Education Department, Jammu and Kashmir"
title: "Notification Dated -29.09.2026 → Draft Jammu and Kashmir Drugs and Food Control (Subordinate) Service Recruitment Rules"
date: ""
pages: 13
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "4a84c20ee8234949"
---

<!-- page 1 -->

Qt,
BSED
Government of Jammu & Kashmir हे
Health & Medical Education Department
Civil Secretariat, J&K.
Subject:- Draft Jammu and Kashmir Drugs and Food Control
(Subordinate) Service Recruitment Rules.
Notification
Srinagar, The 29" of September, 2026
WHEREAS, Commissioner Food and Drugs Administration,
J&K vide Communication No. FADA-Tech/34/2022-05 dated 10.02.2026
has forwarded the Jammu and Kashmir Drugs and Food Control
(Subordinate) Service Recruitment Rules for finalization of the
Recruitment Rules;
AND WHEREAS, in order to finalize the draft Recruitment
Rules of the Food and Drugs Administration, J&K, the Director Finance,
Health and Medical Education Department, had convened a meeting of
the Committee constituted vide Government Order No. 01-JK(HME) of
2025 dated 01.01.2025 on 09.06.2026;
AND WHEREAS, the aforesaid committee after several
दर meetings and deliberations/consultations on the subject have finalized
the draft Jammu and Kashmir Drugs and Food Control (Subordinate)
Service Recruitment Rules;
Now, therefore, before placing the Jammu and Kashmir
Drugs and Food Control (Subordinate) Service Recruitment Rules to the
Standing Committee/ARI Trainings Department for
consideration/approval, the draft notification (recruitment rules)
alongwith Schedule "I" and "II" is hereby notified for inviting objections, if
any, from all the stakeholders. The objections, if any, should be
submitted to the Health and Medical Education Department within a
period of fifteen (15) days from the date of issuance of this notification.
After expiry of the said period, no objection in this regard shall ‏ہت‎ 9०
entertained. 2 ral
۰ Nae:
(Neha ‏سو‎ 5,
3 Deputy Secretary to th iment,
Health and Medical Education Department.
he ८9७
File No. HD-Drgs/52/2026-02 - (CC-7730962) ‏456ھ"‎
‎Copy to the:-
4. Additional Chief Secretary to Hon'ble Chief Minister, J&K.

<!-- page 2 -->

2. Principal Secretary to the Government, Finance Department J&K.
3. Principal Secretary to the Hon'ble Lieutenant Governor, J&K.
4. Joint Secretary (JK&L), Ministry of Home Affairs, GOI. 5
5. Commissioner/Secretary to the Government, General Administration
Department.
6. Commissioner, Foods and Drugs Control Administration, J&K.
7. Secretary to the Government, Dept. of Law, Justice and Parliamentary
Affairs.
8. Secretary to the Government, ARI, Trainings & Grievances
Department.
9. OSD to Hon'ble Minister for H&ME Department. ns
10. Director Archives, Archeology and Museums, J&K.
41. General Manager, Government Press, J&K.
412. Pvt. Secy. to the Chief Secretary UT of J&K.
13.P.S 0 Secretary to Govt., ۸۶ Department.
44. lic Website H&ME Department.
ot
7

<!-- page 3 -->

ier
Government of Jammu & Kashmir :
Health & Medical Education Department
Civil Secretariat, J&K.
‏جو وج‎
NOTIFICATION
Srinagar,the 20026
S.0. -In exercise of the powers conferred by proviso to Article 309 of the |
Constitution of India, the Lieutenant Governor hereby makes the following |
tules; namely: - |
1. Short title and commencement: -
(1) These rules may be called the Jammu and Kashmir Drug and Food
(Subordinate) Service Recruitment Rules, =
(2) They-shall come into force from the date of their publication in the
Official Gazette.
2. Definitions: -
(1) In these rules, unless the context otherwise requires: -
a) "Administrative Department" means the Health and Medical Education
Department;
b) "Board" means the Jammu and Kashmir Service Selection Board;
c) "Cadre" means the cadre of the service;
d) "Government" means the Government of Jammu and Kashmir;
8) “Head of the Department" means the Head of Department holding the
administrative control of the service;
f) “Member of the Service" means a person appointed to a post in the
Service under the provisions of these rules;
g) "Post" means a permanent post carrying a definite time scale sanctioned
by the competent authority;
h) "Rules" means the Jammu and Kashmir Drug and Food (Subordinate)
Service Recruitment Rules, ;
i) "Schedule" means the Schedule annexed to these rules;
}) "Service" means the Jammu and Kashmir Drug and Food (Subordinate)
Service;
k) "Union Territory" means the Union Territory of Jammu and Kashmir;
|) Words and expressions used in these rules but not defined, shall
have the same meaning as are assigned to them respectively in
the Jammu and Kashmir Civil Services (Classification, Control and
Appeal) Rules, 1956/Jammu and Kashmir Civil Service
Regulations, 1956, as the case may be.
3. Constitution of service: -
(1) From the date of commencement of these rules, there shall be constituted
the Jammu and Kashmir Drug and Food (Subordinate) Service.
A
oY ‏رس‎ oe

<!-- page 4 -->

के (2) The Government may, at the commencement of these rules, appoint
to the service any person who at the commencement of these rules
is holding in a substantive capacity any post in the cadre of the
service:
Provided that for the purposes of initial constitution of service,
the person holding any post in a substantive capacity to which
he/she was appointed by the competent authority under rules
included in the cadre of the service in its sanctioned scale of
pay shall be deemed to have been appointed to the service
under these rules if he/she is fully qualified to hold the post
under these rules unless he/she opts otherwise within 15 |
days from the commencement of these rules.
Explanation:" The word "holding" means a person holding a post included in
the cadre of the Jammu and Kashmir Drug and Food
(Subordinate) Service in its sanctioned scale of pay on
regular basis under order of the competent authority and will :
not cover the person holding a post on ex-cadre/deputation
basis or on adhoc basis or in a stop-gap arrangement"

4. Strength and composition of the Service: -

(1) The authorized permanent and temporary strength of the cadre and
the nature of the posts included therein shall be determined by the
Government, from time to time and shall at the initial constitution of
the service under these rules, be such as specified in Schedule -|
annexed to these rules:

Provided that the Government may create temporary posts
in the cadre of the service for specified period or purpose as
may be considered necessary from time to time.

(2) The Government shall, at the interval of every five years or at such
other intervals as may be necessary, re-examine the strength and
composition of the cadre of the service and make such alterations
therein as it deems fit.

5. Qualification and Method of Recruitment: -

(1) No person shall be eligible for appointment or promotion to any post in
any class or category or grade in the service unless he/she
possesses the qualification as laid down in Schedule-IIl and fulfils
other requirements of recruitment as provided in the rules and orders
for time being in force.

(2) First appointment to a service may be made: -

(a) by direct recruitment; or

(b) by promotion; or

(c) Partly by (a) and partly by (b) in the ratio and in the manner mentioned

against each post in Schedule-ll:

Provided that all the posts under direct recruitment shall be
filled through the Board as per the rules/orders of the
Government issued for the purpose.

P ۳ ah
‏ا‎
‎0
‏تو کت کی کر کا پھر ھا بک ھت یی تد داد ولک مد کک ا ا ا رود کو ہے ےہ ہب یں ہچ‎ “0: ८: “567 2

<!-- page 5 -->

: Provided that all the posts to be filled by promotion shall be
filled through Departmental Promotion Committee.
(3) The Department shall refer vacancies in the direct/promotion quota to the
Board and Departmental Promotion Committee as the case may be, in terms
of SRO 166 dated 14.06.2005.
6. Probation: -

(1) Probation of persons appointed to the service, by direct recruitment
shall be regulated in terms of the Jammu and Kashmir Probationer
(Condition of Service, Pay and Allowances) and Fixation of Tenure
Rules, 2020 and in all other cases under the Provisions of J&K Civil
Services (Classification, Control and Appeal) Rules, 1956.

(2) The pay of a person appointed to the service under these rules
through direct recruitment shall be regularized as per the provisions
of J&K Probationer (Conditions of Service, Pay and Allowance) and
Fixation of Tenure Rules, 2020 and in all other cases under J&K
Civil Service Regulations 1956.

7. Reservation in appointments: - While making appointments either by

direct recruitment or by promotion, reservation shall be made in accordance

with the rules and orders issued from time to time for members of Scheduled

Caste / Scheduled Tribes/ Backward Classes or any other category or Class

of persons under the provisions of the Jammu and Kashmir Reservation Act,

2004 and the rules made thereunder.

8. Training and Departmental Examinations: - Persons appointed to the

service by competitive examination shall be required to undergo such training

from time to time during the course of probation and to pass such |
departmental from examination during the period of probation as the |
Government may prescribe time to time:

Provided that the Government may exempt either wholly or partly
from such training or departmental examination persons, who
have passed a departmental examination or undergone
training declared by Government to be equivalent to a
departmental examination or training prescribed under these
rules.

9. Eligibility of Government Servants for Direct Recruitment:- A person
already in the Government service may apply through proper channel for
direct recruitment to a vacant post in any particular class or category in the
service if he/she possesses the educational and other qualifications
prescribed for recruitment to such class or category of posts. The upper age
limit of such Government servant shall be as provided in the general rules:
Provided that in the case of a post which requires a higher degree
of specialization and or experience, the Government may
prescribe higher age limit.
10. Maintenance of Seniority Lists: - Seniority of the members of the service
shall be regulated under the Jammu and Kashmir Civil Services
(Classification, Control and Appeal) Rules, 1956. The Administrative
db Ot
SA

<!-- page 6 -->

: Department shall maintain an up to date and final seniority list of the members
of the service.
11. Residuary matters: - With regard to matters not specifically covered by
these rules, the members of the service shall be governed by the Rules/
regulations and orders applicable to the Union Territory Civil Services in
general.
12, Interpretation: - If any question arises relating to the interpretation of
these rules, the matter shall be referred to the Administrative Department
whose decision thereon shall be final and binding.
13. Repeal and Savings: -

(1) All rules corresponding to these rules and in force immediately
before the commencement of these rules are hereby repealed.

(2) Notwithstanding such repeal, any appointment order made or action
taken under the provisions of the rules so repealed shall be deemed
to have been made or taken under the corresponding provisions of
these rules.

By order of Government of Jammu and Kashmir.
Sdi-
(M. Raju) [AS
Commissioner/ Secretary to Government,
Health & Medical Education Department.
No: HD-Drgs/52/2026-02 Dated:- . 09.2026,
Copy to the: -
1. Additional Chief Secretary to Hon'ble Chief Minister, J&K.
2. Principal Secretary to the Government, Finance Department J&K.
3. Principal Secretary to the Hon'ble Lieutenant Governor, J&K.
4. Joint Secretary (JK&L), Ministry of Home Affairs,GOI.
5. Commissioner/Secretary to the Government, General Administration

Department. ۱

6. Commissioner, Foods and Drugs Control Administration, J&K. ۱
7. Secretary to the Government, Dept. of Law, Justice and Parliamentary
Affairs.
8. Secretary to the Government, ARI, Trainings & Grievances Department.
9. OSD to Hon'ble Minister for H&ME Department.
10. Director Archieves, Archeology and Museums, J&K.
11 General Manager, Government Press, J&K
12, Pvt. Secy. to the Chief Secretary UTof J&K.
13: P.S to Secretary to Govt., H&ME Department.
14. Ic Website H&ME Department. ‏اف‎
‎0

<!-- page 7 -->

Proposed Schedule-!
ER]
[ERA Rood तप नल
2. [Assistant Food Analyst___———(Level-6E (36900-113500) | 6 ٦
‏ےا‎ [Senior Laboratory Technician __[Level-6D (35800-113200) | 56 ||
Bases)
5 [Laboratory Technician (Level-6(35400-112400) [| 8
‏ص6‎
‎22:7
‎fees (Drug Wing mere ene ‏و‎ See 1
H [Senior Scientific Officer _—‘(Level-6F (40800-12920) | 2
22
321 |
‏21م‎ |
5227 |
6 [Laboratory Technician 6 (Level-6(35400-172400) | 4 ١
862
9 Laboratory Assistant _—=—S—(Level-4(25500-81100) _1١. 8 ‏لے‎
‎215801080407 30
Plumber ._ . .._  _ ا٦۷۵4)25900-81100(_‎ _ ٍ ٤ ‏ا‎
‎139 _ ‏_(9۷94)25508-81100ا__ __. _. - ۷۹۲۰ ٥ا8 ەدا6ا‎ | 1 7!
विज 0) तनाव वा 26319 22 ‏ھت کت‎ ۱
1222
2 [Assistant Accounts Officer ————(Level-7(44900-142400) | ___ ٤ _[
3 विशाण 3088 Stenographer____—(Level-7(44900-142400) कक नई |
hk _[LegalAssistant ___ 2०७४-50 55866413200) | 2
5 [Accountant ___ ‏۷۵۸68ئ1‎ )35600-112800(___١___ ٤ .__ ٦
6 |HeadAssistant _____ 1ئ۷۷١68‎ )35600-112800(__١__ ‏ج‎ |
‏اسم‎
‎paces
‎Sree
‎29-2102 |
۸۸۷۸٣٢8۵۴۳۷ 5818 ___  .._ ..
12277671
ae ed 4098-7
we ore
wx
TS aaa ers ‏ےھ وو ا وھ رھ کم سے و‎ 118

<!-- page 8 -->

Proposed Schedule-Il
ICateg [Designa |Pay level |No. of |Minimum qualification(Method of Recruitment
۷ tion of posts required for direct
he post recruitment.
[sama ood Wing! =| see | Ss ‏ا‎ Sa eae ee
Bachelor's or Master's|
ior Doctorate degree in|
[Food Technology o
Dairy Technology 0
Biotechnology or _— Oil
echnology 0 9۷
Food weed 101 gricultural Science o ‏رک ا‎
Safety 129200) eterinary Sciences o हे
Officer Bio-Chemistry ٥
Microbiology
lor Chemistry or Medicin
le from 3 recognized|
7 University.

100% by promotion from |
ae Class-Ill& ۱۷ having a |
‏کون نت‎ Bae least three years of servic |
nalyst 113500) las such (at the ratio 3:1, 7

respectively)

100% by promotion from

IClass-V having at leas

hree years of service as|

uch and possess at leas’
Senior _|Level-6D Bachelors Degree in
lLaboratory((35800- hemistry or Biochemist
echnicia 113200) lor Biotechnology or Food|
In Safety or Food!

echnology, Food &

Nutrition from a universi

established in India by law.

eval: 100% by promotion from
۷ Microbiolo 6B(35600- Class-VI, having three
ist 412800) | ears of service as such o}
by deputation.
Lee ७ |
echnicia (35400- Il having at least thre
In 1142400 lyears of service as such.
2 Bachelors or Masters}
Junior evel-5 Degree in Microbiology|100% by
Microbiolo (29200- lor food Microbiologyidirect recruitment.
ist 192300) om 8 ‏1۷۲ا‎
‎lestablished in India by|
7 02 ‏یبلق‎

<!-- page 9 -->

law >1
Bachelor's Degreeli) 80% by direct
in chemistry onrecruitment.
Biochemistry onli) 20% by promotion from|
Biotechnology or Dairyithe Class -IX, Category A
Chemistry or(Ministerial Posts) at leas’
griculture Science orfive years of service in
(3514 Biotechnology or Foodi|Laboratory as such and
Laboratory| (25500- 30 or Foodpossessing qualification a:
ssistant 81100) echnology, Food &10+2 with science.
Nutrition or Dia
echnology or Oil
‘echnology ٥
eterinary Science} |
rom a university, |
established in Inida 9! |
llaw. |
riiq Wing messes | pecs |p ee ee ee eres | |
Senior |Level-6F 100% by promotion from |
ieee: ||
Officer 1 1 10 hree years of service a:
uch.
Instrume 100% by promotion from
Int eats 2 Class-Ill, Category (8)
echnici 443500) lnaving at least three years}
30 f service as such.
Degree in Pharmacy of
Pharmaceutical
Drugs (89५०-60 ciences or Medicine|
: Control {(35800- 79 ith specialization inji00% by direct
Officer 113200) Clinical ~Pharmacologyrecruitment.
lor Microbiology from 3
University established|
in India by law.
1)20% by direc
recruitment.
(ii)80% by promotion from|
Senior _iClass IV & V having a
Laborato |Level-6D Brees Degree =i least three years of servic
armacy from aj केक
ry )35800- 7 University established@> such (at the ratio 1:2,
echnici |113200) in India ey 0 espectively) and
lan . possessing qualification a:
Degree in Pharmacy o
Microbiology.
See |
logist 35600- \Class-VI_having at_feas'
vA Qa
xX ye
हे

<!-- page 10 -->

112800) hree years of service a
uch or by deputation.
Laborato i 100% by promotion from
ry aoe i Class-VIl Category A
echnici naving at least three years)
112400) ‏و‎
‎30 f service as such.
Bachelors or Masters)
Junior |Level-5 Degree in Microbiology'100% by direct
Microbiol|(29200- 2 rom a Universityjrecruitment.
logist 92300) established in India b
law.
: i) 80% by direc!
recruitment.
li) 20% by promotion fro!
Bachelors Degree iniClass -IX, Category A
| ’ Laborato oe Pharmacy from aj(Ministerial Posts) at leas’
| ssistant\81100) University establishedfive years of service in
| in India by law. Laboratory as such and)
possessing qualification a
10+2 with science.
Minimum Matric and|
._. ٥۷۵۱4 Maximum 10+2 ۹۶ by direc!
٣88 25500- 1 Certificate course  injrecruitment.
7 81100( electrician trade from|
ITI.
Minimum Matric and
cas 184 Maximum 10+2 with100% by direct
7 ‏کے‎ ni (25500- {1 Certificate course  injrecruitment.
‏ت7‎ 72 81100) refrigeration & था :
conditioning trade from|
ITI.
lL evel-4 Minimum Matric and
Maximum 10+2 ۸ by direct
| Plumber ace 2 Certificate course  injrecruitment.
) Plumber trade from ITI.
8 ا۷٥4‎ Bachelors Degree in| .
E ‏اج‎ 25500- Science with Chemistry|100% by direct
80 81100 las One of the subjects. |recruitment.
100% by direct
‏ا نے‎ 1 Minimum Matric pass recruitment.
‘aker (63200) Maximum 10+2
ee ee ee
wy! CA
wx
