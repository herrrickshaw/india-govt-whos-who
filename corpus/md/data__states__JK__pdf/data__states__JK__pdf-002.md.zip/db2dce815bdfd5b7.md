---
doc_id: "db2dce815bdfd5b7"
source_url: "https://jkssb.nic.in/Pdf/Syllabus_constable_ARMED_IRP_SDRF_21102026.pdf"
ministry: "Jammu and Kashmir Services Selection Board, Jammu and Kashmir"
title: "Syllabus for the post of Constable (Armed/IRP and SDRF) in J&K Police, Home Department, advertised vide Notification No. 14 of 2025 dated 31.12.2025."
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1c9dfbe0aa6b8eb7"
---

<!-- page 1 -->

<!-- page 2 -->

Syllabus for Written Test for the post of Constables
(ARMED/IRP/SDRF)
Police/Armed/IRP/SDRF)
(Executive
Marks: 100

No. of Questions: 100
Time: 02:00 Hours

S.No.

Subject/Topic

Total number of

1.

General English

questions
25

2.
3.
4.

5.

General Knowledge and current affairs (India)

25

Numerical and Reasoning Ability

25

General Knowledge with special reference to J&K

Basic Concepts of Computers
Total

DETAILED SYLLABUS
1. GENERAL ENGLISH
Articles

Clauses
Pronouns

Homonyms/ homophones
Tenses

Clauses

Punctuation

30/09/2024.

Synonyms and antonyms
Analogies
Idioms and Phrases
Uses of prepositions

10
15
100

<!-- page 3 -->

2. GENERAL KNOWLEDGE AND CURRENT AFFAIRS (INDIA)

Important dates in Indian History/Freedom Struggle, different dates and

events

First in world (Adventure, Sports, Discoveries).

First in India (Adventure, Sports, Discoveries)
Popular names of Personalities (Religion, Politics, Scientific discoveries,
Geographical, Sports, History)
The Newspaper world (Current Dailies & Weeklies of India)
-

Books & Authors

-

General

Famous Places in India

Languages

Capitals & Currencies
United Nations Organizations - Veto Powers, No. of Countries
Members Principal organs and their functions
SAARC, ASEAN

Everyday Science
World famous Awards

-

as

its

(1. in Science)
(2. in Literature)
(3. in Sports)

National Awards

The world of Sports
Climate & Crops in India

(1. in Science)
(2. in Literature)
(3. in Sports)

Constitution of India (Formation, Fundamental rights, Directive Principles).
Democratic institutions
Forms of Government

Political & Physical divisions of world & India
Important rivers & Lakes in India
Current Events of National and International Level
30/09/2024.

Agriculture in

economic

development

development; Industrialization and economic

Centrally Sponsored Schemes-Guidelines and Objectives

Indian Foreign Trade

<!-- page 4 -->

3. GENERAL KNOWLEDGE WITH SPECIAL REFERENCE TO J&K

Abbreviations, Important dates, popular names of personalities and their
achievements/Contribution (National and International)

Weather, Climate, Crops, Means of Transport Important power projects and
their impact on J&K Economy

Rivers and Lakes

Important Tourist Destinations
Historical places of the J&K and their importance

History of J&K
RTI Act

-

Indus Water Treaty and its impact on economy
Agriculture in Economic Development, industrialization and economic
Development.
Current events of Local, National and International Importance.

4. NUMERICAL AND REASONING ABILITY

The candidates will be tested primarily on the fundamental mathematical concepts
and application oriented reasoning. The broad areas will include the following:
Basic Arithmetic:

Number System

Percentage

Average

Profit & Loss

Ratio & Proportion

Speed, Distance and Time

Mathematical reasoning
Basic Algebra
Mensuration
Decimal Fractions

му

Simple and Compound Interest
Trigonometry
Simplification

30/09/2024.

Reasoning ability:

Number series

Letter series

Coding decoding
Direction sense

<!-- page 5 -->

Blood relations
Statements and conclusions

Logical Reasoning
Mental Reasoning
Sequential output tracing

Assertions and reasons

Arithmetical Operations
5. BASIC CONCEPTS OF COMPUTERS

The candidates' understanding of the concepts of computers and its application will
be tested and it will broadly cover the following:

Computer terminology

Hardware and Software

Input and Output Devices
MS word and MS Excel

30/09/2024

Storage and Operating systems
Safety and Security
E-mail and Internet Usage
Search Engines
