---
doc_id: "aaf68bb976deda0f"
source_url: "https://schedujammu.nic.in/orders_circulars/DSEJ-23-03-2022(1).PDF"
ministry: "Directorate of School Education Jammu, Jammu and Kashmir"
title: "DDO Powers of Headmasters- District Rajouri."
date: ""
pages: 2
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "89e5c5883ed0a631"
---

<!-- page 1 -->

۹ E-maill: dse.jammu@jk.gov.in
Website: www.schedujammu.nic.in
Ph./Fax No:191-2598439
Government of Jammu and Kashmir
Directorate of School Education Jammu
Muthi Camp,Jammu-181205
Sub: Delegation of Drawing and Disbursing powers of Headmasters.
Ref: CEO Rajouri’s No. CEOR/Gaz/49986-87 dated. 16-03-2022
ORDER NO./335 DSEJ of 2022
Dated 2 3- 03-2022
As recommended by the Chief Education Officer, Rajouri vide letter under
reference, the following Officers are hereby authorized to draw the salary
and other bills of following Headmasters shown against each on stop-gap
arrangement basis till the posts are filled substantively by the competent
authority.
Name of the Schools whose | Name of Officer authorized
DDO Powers is to be authorized | to exercise the DDO powers
1 HS Budhal Principal HSS Budhal
HS Gabber
HS Dhok Kangri ~ | Principal HSS Bajabain
HS Sakri ‏و‎ ZEO Peeri a,
‏سا‎
‏و‎ Ravi Shankar Sharma) JKAS
: D> Director School Education Ae
2% Jammu.
NO: DSEJ/Gaz/ 5/I2Z2_-§/ Dated. 2. 7-909-2Da22
Copy to the
1. Principal Secretary to Govt., School Education Deptt, Civil Secretariat,
Jammu for favour of information.
2. C.E.0O Rajouri for information and necessary action.
3. Principal HSS Budhal / Bajabain for information and necessary action.
4. ZEO Peeri for information and necessary action. |
5. Headmaster HS for information and necessary action.
6. Treasury Officer concerned for information and necessary action.
7. 1/C computer Section for uploading of this order in the official website. |

<!-- page 2 -->

ا ا وی ‎eae‏ 2 سس وہ ا
انح ‎हे‏ پا وی ا ‎sea‏ او * 3
‎wasn ote Be pes By‏ و میا1 بر وا 0
‎लन‏ .یی ‎ii‏ پل و راو کت و یی موا ‎है मल अप ees‏ یں
‎हा pore Tae gee‏ ا او سو کت ات ا ما ری
‎iss aaa ۰‏ سی ‎Ee 20 ra a te EA Sian‏
‎मर‏ 1 سا ‎ar‏ ا میں کاو ود وی ا ‎ae ee‏
۱ی ات ےا و وت کے کو = ‎हे ae‏
ہے و ا ‎Gos cag Tse. te ARS‏ تہ :
یں 5 ‎ae cee Se eas‏ یت ‎Fee Miia,‏ کت ا ا 0اا ا ا ا ا
‎ला‏ و ‎ee ae REEL s oy et Ste‏
7 جج یا ‎ee ee "0+090 २९‏ ےت رش
کا لج جا ‎ear ee “ett Foal e mackie‏ کی کی کا پت یہ نات بی ایم پوت کی ا
مو تی ےت 3 ای ‎है!‏ ین ا وو میں کی ا ا جج ا کا ‎ee‏ ۔
جن ا وا وہ ہا لس نے ‎iS epee ue fa‏ کے ‎aie‏ ا ‎ae oe tes pee ee Teh‏
‎ae pete cee Bes a a‏ لت ‎ee ee a ee ee ae‏
‎Bt eee oie PM 2285 ee Ae 205 कक oat ee 3‏
۶۶0 مہ" و ع2 کیل و کا ا او
ھا یر ھا دس سر و ‎Sea ae‏ >< ور او بے ان پا ہی 11% کا کس اہو ھت ری ۔ ‎fe‏
‎SD pee Saeed af oe eee‏ کت رن و کی کے ‎cl ei ee Th ete a ees ee‏ ا و
‎ees‏ کت کے ور ‎fear सम Mate Moe Dea ae‏
2ھ ‎٠‏ ہج 6 می سک تا
‎SS coco cr aks‏ ا او و ا چک ‎es = [uted‏ کے زی 8 1 :10104 5 7
‎ic Guat nest oa‏ ا ‎PON sigan eae... es kde aes Ber)‏
او ےج ‎eS‏ ا ںا ا ‎et hae mR ices 7 | Se Rae‏
و ‎ee‏ و 60 ‎हज‏ مر کو کے فو ‎a,‏ ا ‎ee‏ و
‎ee ae 5 = ie ag Naeem ts :‏ 523
‎कप 1‏ وا انیس ون بے کی ویک یا یں کے یا ‎“Speer‏ 2 65
بی ‎ae ee ee‏ و ون ‎i eer io‏
ات کو و ‎Pepe‏ ا و ا یک ‎٦‏ یت
‎oui‏ 358 ا و وی و ‎है age. pees Sak ele‏ +
وت ا ا ا اپ و ا ‎८ 41.3 scsi waa ed be‏ 38 کے ‎Es‏
‎ea acta eae gare, a‏ ا ‎ea ee‏ را رر ‎ia‏
‎ie‏ 3 و وو رت ‎eee eee‏ بر یں سس
ارہ ‎SS Se ee eee Path हे 0 ली ae ee‏
‎ane bs‏ ا یی یہ ‎Bis geet‏ ہک ںہ ‎fas Es‏ و او
اوت ‎ee Se a आम‏ تی ‎f Shae Se eens ee eras‏
و "تھے جج اک اوہ کے ا کا ‎मल‏ ار او ا ۱
‎ee‏ ا ‎Be‏ کا و مر وک وا ھی
وی یی دی سی مر می شی و جو ا 22 2 کیا جو کات ا ‎soci‏
‎Se‏ ا ا راک نت وی اچ وی می ا ا کے وو ا و و
و کے 7 ‎ae gi ee eee See है‏ ا ار ا تہ : ‎oe oS le ae‏ ا ‎ea‏
‎ee‏ و تق ا و ا وک ہا اک ا ا کا
ا وھ یا موی ‎ee EERO yh es ee oy te‏
الا ایی و واج 20000 ا کی کک کر ا و ای ات سک وک وی مھ
ا مو اک ا ےک ا کا ھت اڈ 7528 اھ
راو ‎NS ne ee‏ کل کک کک اک 2
‎۷٣‏ سہ ہب جا وق سے ہے ا و وت
1 رد ےو ےت ےڈ
> کر ین کا تک 5 ‎ae See ee toe wh‏ ا کا مت کا
6 و ہے ہو ور , ہی وا کک چا 7وت کے
ہے چھکھہ ودک کس نیہ شا ہا ۴
7 کے ا ا سیک ھت پت ہے ما کے و 50222 یا جوا
ای کی ےپ روا تہ او وو سو ‎Be‏ کی ‎(हक पर erie‏ کچھ سے و کی او کے
کر ‎POS EAH Oe oe‏ کے
‎न पार ea ce 5, 35 eu ८‏ ا ا سز | # ‎ca eee ELS‏ اک یش یق ‎Boe‏
‎See‏ اس و ای ا وت سا وک یل ریہ ام وا ا
ا مہ رر کا ا رک و ےر ا کو ‎ee‏ ا پک
‎a ns‏ یی او ‎eee‏ 2 0 کسر ‎ens Serie‏ سن ھی ,8 ور ‎८2 किला‏ کک پا رو رع او
‎BS‏ کک یی لو تی ا کا جا لک می ‎oe‏ یا ‎ee जि‏ ا 9
اج مود رک ‎ea‏ ا کی ہے کر ہے ‎fat eS eM na ee SS‏
‎ee en eee ae 00‏ دم ا و ا ا ای ا کت
مت ےا ہیں سید و = ‎ie LS ciate ea ae 322 7 i ae‏
کک کک ا او ا ات سر یی مھ ا اکا ا
‎hs 7‏ مود مو ال یر دیو ‎Dene roger eae कक ra Se‏ کت وی ا سا ری ےا
6 و سو ‎i Peers te‏ چک دای پا جج ‎or Sy ae‏ و ‎Sc Re ee oe SO‏ ا و اش یہی دی
کاو ‎per‏ کی ‎ae i Se‏ 2 ۷ػ
‎ee Se pe game ao 2 ena, ise aa ame pe ee Bete‏
وم ور کو ا ا ‎ee Sats ee See tease anes ABE‏ یج ‎SOS: A‏
میں ا کو یی ہی مو کا نو نار اوھ ار ہے در سو دا ‎Se eee‏ روک کی ہو 28و یں کہ
‎ee‏ ا اچ پا میں سرت ‎Beate ee Wipes‏ جم شا 323 ‎जार‏ و سو ہد کہ ہت
‎si eee + payee Siete aa‏ ای بی ا یی ‎NR‏ عو وی ‎ae‏ اہ کت وی
‎et Rg ee 7 = i ae‏ کا ا ا ا ا 2 ‎eee see‏
‎जे (capes‏ ا لی ہے ا ور ‎क्र‏ نمی تک او کیو یچ فی و پ2 کے وی انا
‎yt ae a ut ioe‏ انج جا ‎ee‏ :
‎we ८ Se oe =‏ یں کے او کا کے ای ےک ھا پاپ میں یا ایا ا ما و ات ا ہیں کرای ہا ھپ ےک او درو ‎है‏
‎es‏ وک ای ا ا ا و ‎eS‏ ہے موک ‎te‏ ا و کل 7
‎Be Oo ces Fi ego he Sari ie ee‏ یا ا ےش نہ وی یگ
‎ee ee 8 i 00 ne Bo ae ee कर‏ و ا
‎Se a ene Ree iia ae oe ee‏ کت چا ‎४८ 7 is‏ 7
می ‎Tae eee foe उमा Pik Pigs Bae Sige ie ae ae Ante‏ ہو ود اد ‎eerie aes‏
‎eae prep oh oe‏ و ای کا کن ‎ee‏
‎oe‏ ری کا ا ا کک ‎eS‏
‏و و چا ور ھی شا ای اکا ای ہے .- .. .3:5 :09 ات کی موا کھت 8
