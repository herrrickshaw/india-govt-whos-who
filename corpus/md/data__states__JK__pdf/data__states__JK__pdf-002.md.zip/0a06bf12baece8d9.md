---
doc_id: "0a06bf12baece8d9"
source_url: "https://fcsca.jk.gov.in/pdf/orders/2026/Notification_EnforcementRules2026.pdf"
ministry: "Department of Food, Civil Supplies & Consumer Affairs, Jammu & Kashmir"
title: "Notification S. O.- 215 Dated 05/08/2026"
date: ""
pages: 52
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "03e5e795b0d6c9f7"
---

<!-- page 1 -->

Government of Jammu and Kashmir
Department of Food, Civil Supplies & Consumer Affairs
Civil Secretariat, J&K
Notification
Srinagar, the 05 of August, 2026.

=
s.0.> 2 :- Whereas, draft rules namely the Jammu and Kashmir Legal Metrology
(Enforcement) Rules, 2026 were notified vide notification $.0-131 of 2026 Dated 30%
of April, 2026 and published in the Jammu and Kashmir Official Gazette, extra ordinary,
Vol. 139 dated 30-04-2026, as required under section 53 of the Legal Metrology Act,
2009, for inviting objection(s)/suggestion(s) from the persons likely to be affected
thereby within a period of 07 days from the date of the publication of the said
notification in the Official Gazette;

AND WHEREAS, no suggestions/objections have been received within the
aforesaid stipulated period.

Now, therefore, in exercise of the powers conferred by section 53 of the Legal
Metrology Act, 2009, the Lieutenant Governor, Union Territory of Jammu and Kashmir
hereby makes the following rules; namely:-

CHAPTER- I
PRELIMINARY
1, Short title and commencement:—

(1) These rules may be called the Jammu and Kashmir Legal Metrology
(Enforcement) Rules, 2026;

)۵( These rules shall extend to the whole of Union Territory of Jammu and
Kashmir.

)3( These rules shall come into force from the date of their publication in the
official gazette.

2. Definitions.— In these rules, unless the context otherwise requires :-

(a) "Act" means the Legal Metrology Act, 2009;

(b) "Government" means the Government of Union Territory of Jammu and
Kashmir;

(c) "Registering Authority" means Controller, Legal Metrology, J&K, is the
Authority to issue registration under the Act and the rules made
thereunder;

(d) "Reference Standards Laboratory" means a laboratory set up by the
Central Government under the Act, where Reference Standards,
Secondary Standards and Working Standards are maintained;

(e) "Schedule" means a schedule appended to these rules;

(f) "Words and expressions" used in these rules and not defined but

<!-- page 2 -->

defined in the Act shall have the meaning as assigned to them in the Act.
ऊँ Reference Standards.— The Reference Standards shall be kept at such
place, manner and in such custody as prescribed under the Legal Metrology

(National Standards) Rules, 2011.

4. Secondary Standards.—

(1). Every Secondary Standards shall be verified at any of the Reference
Standards Laboratories, in such manner and at such periodical intervals
as may be prescribed under the rules and shall, if found on such
verification to conform to the Standards established by or under that Act,
be stamped by Reference Standard Laboratory or a certificate of
verification will be issued by that laboratory.

(2) The Secondary Standards shall be kept at such place, and under such
custody as the Controller may direct.

5. Working Standards.—

(1) Every Working Standard shall be verified either at any of the Reference
Standards Laboratories or at any of the Secondary Standards Laboratories
maintained by the Government, in such manner and at such periodical
intervals as may be prescribed under the rules and shall, if found on such
verification to conform to the Standards established by or under the Act,
be stamped or certificate of verification will be issued by that laboratory,
as the case may be.

(2) | The Working Standards shall be kept in the custody of Legal Metrology
Officer.

6. Secondary Standard Balances.—

(1) A set of Secondary Standard balances shall be maintained at every place
where Secondary Standard Weights are kept.

(2) | The number, types and specifications of such balances shall be such as
may be prescribed under the Legal Metrology (General) Rules, 2011.

(3) | Every Secondary Standard balance shall be verified at least once within a
period of twelve months and shall be adjusted, if necessary, to make it
correct within the limits of sensitivity and other metrological qualities
prescribed under the Act, by the Reference Standards Laboratory.

7. Working Standard Balances.—

(1) A set of Working Standard balances shall be maintained at every place
where Working Standard Weights are kept.

(2) The number, types and specifications of such balances shall be such as
may be prescribed under the Legal Metrology (General) Rules, 2011.

(3) ६५९५ Working Standard balance shall be verified at least once within a
period of twelve months and shall be adjusted, if necessary, to make it
correct within the limits of sensitivity and other metrological qualities
prescribed under the Legal Metrology (General) Rules, 2011, at any of the
places where Secondary Standards are maintained by the Government.

8. Physical characteristics, configuration, constructional details of
=

<!-- page 3 -->

Weights and Measures.— Every Weight or Measure used or intended to be

used in any transaction or for protection shall conform as regards physical

characteristics, configuration, constructional details, materials, performance,
tolerances and such other details, to the specifications prescribed under the Act

or the Legal Metrology (General) Rules, 2011.

9. Use of Bullion Weights, Carat Weights etc.—

(1) No Weight other than a Bullion Weight shall be used in any transaction in
bullion including precious metals, pearls, ornaments or other articles made
of gold or silver.

(2) No weight other than a carat weight shall be used in any transaction in
precious stones.

(3) Only beam scale of class A or class B category or a non automatic weighing
instrument of high accuracy class (class II) or special accuracy class (class
I) having facility of dual displays, with verification interval of 1 mg or less
than 1mg, shall be used in any transaction referred to in sub-rules (1) and
(2).

10. | Use of Weights only or Measures only or number only in certain cases.—
Except in the cases of commodities specified in Schedule-I, the declaration of
quantity in every transaction, dealing or contract, or tor protection shall be in
terms of the unit of—

(a) weight, if the commodity is solid, semi-solid, viscous or a mixture of solid
and liquid;

(b) — length, if the commodity is sold by linear measure,

(c) area, if the commodity is sold by area measure,

(d) volume, if the commodity is liquid or is sold by cubic measure; or

(e) number, if the commodity is sold by number.

11: Registration of Manufacturer, Repairer and Dealer of weights and
measures etc.—

(1) — Every manufacturer or repairer of, or dealer in, weight or measure shall
make an application, through online portal or other means as may be
prescribed by the Controller, for the issue of a registration to the Controller
Legal Metrology, or such officer as may be authorized by him in this behalf,
in the appropriate form set out in Schedule-II.

Provided that, no registration to repair shall be required by a
manufacturer to repair the Weight and Measure manufactured by him
and used in Jammu and Kashmir, however, the manufacturer has to
inform in advance to the concerned Legal Metrology Officer about the
repairing.

(2) Every registration issued to a manufacturer, repairer or dealer shall be
in the appropriate form set out in Schedule-III.

(3) Every registration to a manufacturer, repairer, or dealer shall be issued
automatically, based on self-declaration without inspection, through

९१ (२ &

<!-- page 4 -->

online portal or other means as may be prescribed by the Controller
from time to time, after verification of documents and on payment of
fee as specified in the Schedule-IV.

(4) The fee payable for the alteration of a registration certificate or for the
issue of a duplicate registration certificate shall be as specified in
5-50۰

(5). The Controller or such other officer as may be authorized by him in this
behalf, shall maintain a register of registered manufacturers, dealers
and repairers in the form set out in Schedule-V.

(6) | Every manufacturer/repairer/dealer registered under the Act and these
rules shall maintain such workshop/equipment/tools/registers etc, as
the case may be, as per the terms and conditions of the registration.

(7) A registration certificate issued under this Act shall neither be saleable
nor transferable.

12. Suspension and cancellation of registration granted.—

(1) | The Controller, or such other officer as may be authorized by him in
this behalf, if he has any reasonable cause to believe that the holder of
any registration issued, renewed or continued under this Act has made
any statement in, or in relation to, any application for the issue, renewal
or continuance of the registration, which is in correct or false in any
material particular or has contravened any provision of the Act or any
rule or order made thereunder, suspend such registration, pending the
completion of any inquiry against the holder of such registration.

Provided that no such registration shall be suspended unless the
holder thereof has been given a reasonable opportunity of showing cause
against the proposed action;

Provided further that where the inquiry referred to in this sub-section
is not completed within three months from the date of suspension of a
registration, such suspension shall, on the expiry of the period aforesaid,
stand vacated.

(2) The Controller, or such other officer as may be authorized by him in this
behalf, if he is satisfied, after making such inquiry as he may think fit, that
the holder of a registration has made a false or incorrect statement of the
nature referred to in sub-rule (1) or has contravened any law or order
referred to in that sub-section, cancel such registration;

Provided that no such registration shall be cancelled unless the
holder thereof has been given a reasonable opportunity of showing cause
against the proposed action;

(3) | Every person whose registration has been suspended shall, immediately
after such suspension, stop functioning as registered person/firm and shall
not resume activities/business unless the order of such suspension is
revoked.

(4). Every registered person/firm whose registration has been suspended or

१ (९ ७.

<!-- page 5 -->

cancelled shall, after such suspension, or cancellation, as the case may
be, surrender such registration certificate to the issuing authority.

(5) Every registered person/firm whose registration has been cancelled shall,
within a period of thirty days from the date of such cancellation, or within
such further period, not exceeding three months from such date, as the
Controller or such other officer authorized by him on behalf may, on
sufficient cause being shown, allow or dispose of the weights or measures
which were in his possession, custody or control on the date of such
cancellation and in the event of his failure to do so, the Controller or any
other officer authorized by him, in writing, in this behalf, may seize and
dispose of the same and distribute the proceeds thereof in such manner
as may be prescribed.

13. Records to be maintained by manufacturers, etc.— Every manufacturer or
repairer of, or dealer in weight or measure, registered under the Act and these
rules shall maintain records and registers in the appropriate form set out in
Schedule-VI and also submit such reports/returns as may be required by the
Controller or such officer as may be authorized by him in this behalf.

14. Periodical interval for the verification of weights or measures —

)1( Every weight or measure used or intended to be used in any transaction
or for protection shall be verified and stamped by the Legal Metrology
Officer on receipt of such fee as specified in the Schedule-VII and shall be
re-verified and stamped at periodical intervals.

(2) The period of re-verification shall be as prescribed under the Legal
Metrology (General) Rules, 2011.

(3) Notwithstanding anything contained in sub-rule (2), every weight or
measure which has been verified and stamped in-situ shall, if it is
dismantled and reinstalled before the date on which the verification is due,
be duly re-verified and stamped on payment of the prescribed fee, before
being put into use.

(4) Notwithstanding anything contained in sub-rule (1), every weight or
measure which has been verified and stamped shall, if it is repaired before
the date on which the verification is due, be duly re-verified and stamped
on payment of the prescribed fee, before being put to use.

15. Verification and Inspection of Weights or Measures.—

(1) Every person using any weight or measure in any transaction or for
protection shall present such weight or measure for verification/re-
verification, at the office of the Legal Metrology Officer or at such other
place as the Legal Metrology Officer may specify in this behalf on or before
the date on which the verification falls due:

Provided that where any weight or measure is such that it cannot,
or should not be moved from its location, the person using such weight or
measure shall report to the Legal Metrology Officer at least thirty days in
advance of the date on which the verification falls due.

a Se

<!-- page 6 -->

(2) Where any weight or measure is such that it cannot, or should not be
moved from its location, Legal Metrology Officer shall take necessary steps
for the verification of such weight or measure at the place of its location.

(3) For the verification of weight or measure referred to in sub-rule (2), the
user shall provide such facilities as may be specified by Controller.

(4) ۲۷۰۲۷ weight or measure presented for verification shall be complete in
itself.

(5) | Every weight or measure shall be verified in a clean condition and if
necessary, the Legal Metrology Officer shall require the owner or user to
make necessary arrangements for the purpose.

(6) | ALegal Metrology Officer may visit as frequently as possible every premise
within the local limits of his jurisdiction to inspect and test any weight or
measure which is being or is intended or likely to be used in any
transaction or for protection and for this purpose, he/she may use test
weight/measure or working standard weight/measure.

(7) ٣٢٢ Legal Metrology Officer shall obliterate the stamp on any weight or
measure, if it is found during inspection that :—

(a) Any weight or measure which being due for re-verification has not
been submitted for such re-verification.

(b) any weight or measure which does not conform to the Standards
established by or under the Act.

Provided that where Legal Metrology Officer is of opinion that the
defect or error in such weight or measure is not such as to require
immediate obliteration of the stamp, he shall inform the user, of the defect
or error found in the weight or measure and call upon user to remove the
defect or error within such time, not exceeding eight days and shall-

(i) if user fails to remove the defect or error within that period,
obliterate the stamp; or

(ii) if the defect or error is so removed as to make the weight or
measure conform to the standards established by or under the Act,
verify and stamp such weight or measure.

Explanation—The obliteration of the stamp on any weight or measure shall

not take away or abridge the power of the legal metrology officer to seize

such weight and measure in accordance with the provisions of the Act.

16. Stamping of weights or measures.—

(1) | The Legal Metrology Officer Shall stamp every weight or measure, if after
testing and verification, he is satisfied that such weight or measure
conforms to the standards established by or under the Act, with a stamp
of uniform design, issued by the Controller, which shall indicate the
number allotted for administrative purpose to the Legal Metrology Officer
by whom it is stamped:

Provided that if by reason of the size or nature of any weight or

- 9 (७
\\\G

<!-- page 7 -->

measure it is not desirable or practicable to put a stamp thereon, the Legal
Metrology Officer shall take such action as may be directed by the
Controller by a general or a special order in writing.

(2) | The Legal Metrology Officer shall also mark the year and its quarter of

stamping on every verified weight or measure except when the size or
nature of such weight or measure makes it impracticable.
Explanation— A year shall be deemed to consist of four quarters of which
first quarter shall be of the months of January, February and March which
shall be marked as A; second quarter shall be of the months of April, May
and June which shall be marked as B; third quarter shall be of the months
of July, August and September which shall be marked as C and fourth
quarter shall be of the months of October, November and December which
Shall be marked as D.

(3) On completion of verification and stamping of any weight or measure, the
Legal Metrology Officer shall issue a certificate of verification in the form
set out in Schedule-VIII.

(4) Where a certificate of verification is lost or destroyed, the holder of the
certificate of verification shall forthwith apply to the concerned Legal
Metrology Officer for the issue of a duplicate certificate of verification.
Every such application for the issue of a duplicate certificate shall be
accompanied by a fee of rupees fifty.

(5) On receipt of an application under sub-rule (4), the Legal Metrology Officer
shall issue to the applicant a duplicate copy of the certificate of verification
marked ‘DUPLICATE’.

17 Fee for verification. —
(1) Fee payable for verification and stamping of weight or measure at the
office or camp office of the Legal Metrology Officer shall be as specified in
Schedule-VII.
(2) _ If, at the request of the user of weight or measure, verification is done at
any premises other than the office or camp office of the Legal Metrology
Officer, an additional fee shall be charged at half the rate specified in the
Schedule-VII and the user of the weight or measure shall pay the
expenses incurred by the Legal Metrology Officer for visiting the premises
including the cost of transporting and handling the Working Standard and
other equipment subject to a minimum of rupees two hundreds:
Provided that no additional fee shall be charged for verification and

stamping of weights and measures in-situ of:-

(i) vehicle tanks for petroleum products and other liquids, Meter for
Liquids Other than Water (Fuel Dispenser, Liquid Petroleum Gas,
Milk Dispensers), Compressed Natural Gas Dispensers, Non-
automatic Weighing Instruments like weighbridges, platform
machines, crane scale, Automatic Gravimetric Filling Instruments,
Automatic Rail-weighbridge, Discontinuous Totalizing Automatic
Weighing Instruments, and such other weight or measure which

(२७

<!-- page 8 -->

cannot, and should not be moved from its location;

(ii) | Weight or measure in the premises of manufacturer or dealer of
such weight or measure.

(3) If a weight or measure is presented to the Legal Metrology Officer for re-
verification after expiry of the validity of the stamp, an additional fee at
half the rates specified in Schedule-VII shall be payable for every quarter
of the year or part thereof:

Provided that no additional fees shall be charged, if prior intimation
in writing is provided to the Controller or any authorized Officer in this
behalf, for non-usage of such instrument with valid reasons thereof:

Provided further also that, if the re-verification of weight and
measure work could not be under taken before expiry due to closure or
suspension of works, any server or portal issue, natural calamities or other
unavoidable circumstances, the controller may relax such additional fees
to such extent in such areas as he/she may by special order directs.

(4) _ Full fee shall be payable for re-stamping any weight or measure held in
stock with manufacturer or dealer within the period specified in rule 14
from the date on which it was last stamped, provided that the original
stamp was not obliterated.

(5) A weight or measure which on verification/inspection is found to be
incorrect shall be returned to the person concerned for adjustment
informing him, in a proforma specified by the Controller, of the defects
found in the weight or measure, and calling upon him to remove the
defects within a period not exceeding seven days. When the necessary
adjustment has been carried out, such weight or measure shall be verified
on payment of the fees specified in schedule-VII and if found correct shall
be sealed and stamped.

18. Collection of fees and deposit into the Treasury.—

(1) Before commencing the work of verification, the Legal Metrology Officer
shall inform the person concerned of the fees payable by him under these
rules and shall receive the same and issue a receipt in the form approved
by the Controller.

(2) All other payments to be received by the Legal Metrology Officer under
these rules shall receive and issue a receipt, in the form approved by the
Controller.

19. Disposal of seized weights, measures, etc.—

(1) Any un-verified weight or measure shall be returned to the person from
whom such weight or measure was seized if that person gets the same
verified and stamped within thirty days of the return on payment of the
prescribed fee including the additional fee payable for undertaking re-
verification after the expiry of the validity of the stamp.

(2) Any weight or measure or document or thing or goods seized and detained
under sections 15 of the Act, which is to be the subject of proceedings in
a court shall be secured under his/her custody and if required, be

‎(Ne‏ ہے
‎\EG‏

<!-- page 9 -->

produced by the Legal Metrology Officer before the court and shall after
conclusion of the proceedings, be taken possession of by the such Officer
and dealt with in accordance with the orders of the court:

Provided that in the absence of the orders of the court, weight or
measure or document or thing or goods shall be dealt with as the
Controller may by special order direct and the material thereof shall be
sold and the proceeds credited to the Government.

(3) If any goods, seized under sections 15 of the Act are subject to speedy or
natural decay, the Legal Metrology Officer shall have the goods weighed
or measured on a verified weighing or measuring instrument available with
him or nearest to the place of offense and enter the actual weight or
measure of the goods in a form specified under schedule-IX and shall
obtain the signature of the trader or his agent or such other person who
has committed the offense. The goods in question shall be returned to the
trader or the purchaser, as the case may be:

Provided that if the trader or his agent or the other person (who
has committed the offence) refuses to sign the form, the Legal Metrology
Officer shall obtain the signature of not less than two persons present at
the time of such refusal by the trader or his agent or other person. In case
goods are returned to the trader, he shall give an undertaking that he
shall not sell the defective goods without rectifying the defects thereon.

(4) | Where the goods seized under sub-section (1) of Section 15 of the Act are
contained in a package and the package is false or does not conform to
the provisions of the Act or any rules made there under and the goods in
such package are subject to speedy or natural decay, the Legal Metrology
Officer so far as may be, may dispose of the goods in such package in
accordance with the provisions of sub-rule (3):

Provided that the Controller shall be the final authority to decide
whether the goods seized and detained are subject to speedy or natural
decay.

(5) | Where the goods seized under sub-section (1) of Section 15 of the Act are .
not subject to speedy, or natural decay, the Legal Metrology Officer may
retain the package for the purpose of prosecution under the Act after
giving the trader or his agent or the other person (who has committed the
offence) a notice of such seizure.

(6) The goods referred under sub-rule (4) & (5) which are not to be the
subject of proceedings in a court, shall after the expiry of sixty days of its
seizure, be so dealt with as the Controller may by special order direct.

20. Validity of Weights or Measures duly stamped.—

(1) A weight or measure which is, or is deemed to be duly verified and
stamped under these rules shall be deemed to conform to the standards
established by or under the Act at every place within Jammu & Kashmir in
which It is stamped unless it is found on inspection or verification that such

» Xe

<!-- page 10 -->

weight or measure has ceased to conform to the standards established by
or under the Act.

(2) No weight or measure which is, or is deemed to be duly verified and
stamped under the Act shall require to be re-stamped merely by reason
of the fact that it is being used at any place within the Jammu & Kashmir
other than the place at which it was originally verified and stamped:

Provided that where a verified weight and measure is dismantled
and re-installed at a different place, such weight or measure shall not be
put into use unless it has been duly re-verified and stamped,
notwithstanding that periodical re-verification of such weight or measure
has not become due.

(3) | Where a verified weight or measure has been repaired, whether by a
registered repairer or by the person owning and possessing the same,
such weight or measure shall not be put into use unless it has been duly
re-verified and stamped, notwithstanding that periodical re-verification of
such weight or measure has not become due.

21. Qualification of Legal Metrology Officer.— The qualification of Legal
Metrology Officer shall be as specified in the Legal Metrology (General) Rules,
2011.

22. Provision for supply of Working/Secondary Standards, equipment, etc.
to the Legal Metrology Officer.—

)1( Every Legal Metrology Officer shall be provided with Working/Secondary
Standards weights, Working/Secondary Standard balances, and such
other equipment including weighing and measuring devices as may be
approved by the Controller from time to time.

(2) Every Legal Metrology Officer shall be provided with such dies, punches,
paper seal/sticker and such other equipment as may be necessary for
affixing the verification stamp, the design and number of which are to be
approved by the Controller.

(3) Legal Metrology Officer shall be provided with obliteration stamp for
obliterating stamps on weights and measures.

23. Provisions relating to use of weights, measures etc.—

(1) Every person using a beam scale in any transactions in his premises shall
suspend the same to a stand or to a chain by a hook:

Provided that this sub-rule shall not apply to itinerant vendors.

)2( Every weight or measure shall be used in a clean condition and in proper
lighting arrangement clearly visible to the consumer.

(3) To ensure a proper check of the accuracy of a weighing instrument, the
user shall keep at the site of each weighing instrument duly verified and
stamped weights equal to one-tenth of the capacity of the instrument or
maximum up to one tonne capacity of weight and consumer can also
check the accuracy of the weighing aN :

हे ‏۳م‎ ۹2
oe
