---
doc_id: "89a9a1a84ce1aeac"
source_url: "https://www.jammuuniversity.ac.in/sites/default/files/Order-Circular2025-07/Central%20Purchase%20Committee%2025-26.pdf"
ministry: "University of Jammu, Jammu and Kashmir"
title: "Circular"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0f9b610c6a91f5e0"
---

<!-- page 1 -->

UNIVERSIW OF JAMMU

CIRCULAR

It is hereby circuloted for the informotion of olf thot the members of
Centrol purchose Commiltee for the Finonciol Yeor 2025-26 is os under ond
thus oll purchose proposols to be ploced in CPC must corry nomes of new

Centrol Purchose Committee Members:
. Registror
2. Director, CDOE
3. Heod, Deportment of ZoologY
of Chemistry
, 4. Heod, Deportment
5. Director, The Business School
6. Officer lnchorge (Finonce)

-Convener
-Member
-Member
- Member
- Member
- Member

(with powers to co-oPt)
7. Director, Centre for lT & Monogement
8. A.R (Services)

- Speciol lnvitee
- SecretorY

'l

No.Fin./2 o2s-26t 3 6

Doted:2;j

I ootzozs

$' 3 I 0*

ihonce)

V-\r*wW'w

Copy to:

l. SS io VC for kind informotion of the Hon'ble Vice-Choncellor pleose.

2. Sr. pA to DAA/DRS/Dp&D/DCD/Registror/ coE ond All Rectors/ Directors/
HODs/ Officers of the University, for kind informotion pleose.

3. Director lT, for uplooding on www.jommuuniversily.oc.in under the
'Finonce Wing' Link
4. Guord File.
