---
doc_id: "b9f5db60faf7b3e8"
source_url: "https://smvdu.ac.in/wp-content/uploads/2023/06/20-12-2017HardwareTequip.pdf"
ministry: "Shri Mata Vaishno Devi University, Katra, Jammu and Kashmir"
title: "TEQIP : Purchase order [Hardware for Video Recording]"
date: ""
pages: 4
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "eb96ad2ac46a9a93"
---

<!-- page 1 -->

ean?
t
PURCHASE ORDER
a
Reference No: TEQIP-II1/2017/mvdu/Shopping/6
Date of Issue: 20-Dec-2017
eee ‏سے ______س[س_‎
Subject: Hardware for Video Recording for smart class
room
——————— ‏۔۱ سض ضسح‫ےٹآأسےصىضمصصصىظأطأؾطهىىتت--‎
Purchaser: Shri Mata Vaishno Devi University, Katra
‏سے : سےےے | سج -٣محس- ‪طططکےىککٌژٌجژٌؾٌسمسسےمےےٹےمممم66‪ آ تمصهەهصصےمےسى-ى  ےے ے تسا‎
Supplier Name: DIGITECH MEDIA PRODUCTS PVT LTD,
Block — E, Gali No.6, House No. 115£, Sangam Vihar
Near Satyam Public School NEW DELHI -, New Delhi,
New Delhi, 110062
‏ليس_ے لے ےا‎  |_”‫” ‏ہ ۔۔ےے_ممممُممے۔کےسےکشسم مم ے ےس ص_ے ۔۔'کط-۔_دکگ‎
With reference to our correspondence, Shri Mata Vaishno Devi University, Katra is pleased to
award this detailed Purchase Order to DIGITECH MEDIA PRODUCTS PVT LTD, for supply of items as
per the details given below at a total cost of 4899750.00 (<In words>):
Quantity | Unit Cost (Rs.) | Total Cost (Rs.) | Delivery Period
anal Harware for video recording Pe | 979950 4899750 | 45
|
a
Scanned by CamScanner

<!-- page 2 -->

Scanned by CamScanner

<!-- page 3 -->

‘eR CR |
Signature
Date
Address
Annexure |
1 Toa
| | ey ‏کے‎
‎۱ Harware for | Make of Recording and Streaming Unit (Media Encoder) for Video Conferencing System -
i video REPUTED BRAND MAKE, OEM SHOULD BE ISO CERTIFIED Model of Recording and Streaming
हर recording Unit (Media Encoder) for Video Conferencing System - ALL IN ONE RECORDER to record, stream,
i webcast and play back in real time with capability of 4 FHD video sources with S inches built in
7 display device available in streaming device . Three full HD, PTZ camera of Sony/lumens/Hitachi
۱ "| or equivalent make all camera should be controlled by single joy stick controller. digital zoom
٦ 12X, manualzoom10X THE VENDOR SHOULD SUBMIT OEM AUTHORISATION FOR SPECIFIC BID.
i Country of origin of Recording and Streaming Unit (Media Encoder) for Video Conferencing
pir, System - preferably singapore/usa/ Compulsory Registration as per order MeitY with Bureau of
a ٦ Indian Standards(BIS) for this item - YES Unique Registration Number issued by BIS - NA Duration
‏.ا‎ of continuous streaming - Non Stop Hours Supported live-streaming formats - MP-4/H.264
uN Recording format - MP 4 Supported on-demand formats - MPEG-4/H.264 Video inputs - SDI
‏.لا‎ Video formats - MP4 Audio inputs - digital audio &#x28;AES/EBU&#x29; inputs Ethernet ports -
tr ' 7 10/100/1000 Mbps Available hard disk space - 4000 GB GB RAM - 16GB GB Type of Processor of
‏.۴:س‎ the aplliance /server - RTSP live streaming, multicast, VOD Additional ports - USB 3.0 Duration of
‏ارہ‎ continuous Recording - 8 Hour Hours Standard form factor - 1 rack units &#x28;RUs&Hx29;
i 7 Maximum Window Size - 1 Gigabit RJ-45 interface, support live ‘streaming, on demand and so on
‏اہ‎ | | Maximum Bit Rate( Full HD ) - 1 to 2Mbps Number of Simultaneous Output Streams - 4
|_| | Mandato UL/CE certification - Yes UL/CE certificate Number (Furnished when demanded by
3 ns 5 ۳ ۲ 7 ٦
‏کر پک‎
9००५ ‏ا کر‎ हा
ie ‏ا‎
‎1 ‏ا مات‎ है
५ ‏پگ“‎ 3 है
‏و 6ا‎
i a 1 |
nie
0
Scanned by CamScanner

<!-- page 4 -->

OO ‏ص 2 ص2‎ ص__23۴.۴.۱.۰1.۰۸ص۔۔0۔٤‎ जज
Scanned by CamScanner
