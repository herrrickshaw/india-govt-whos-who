---
doc_id: "cfd175c2fee789ad"
source_url: "https://jkocmms.nic.in/SPCB_DOCUMENTS/j&knotification0001.pdf"
ministry: "Pollution Control Committee, Jammu and Kashmir"
title: "Notification For J&K State Pollution Control Board."
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "8db2a1383f204f9a"
---

<!-- page 1 -->

v4 .
7
है ‏ہ۸‎
‏اپ ھا‎ की ٦ GOVERNMENT OF JAMMU SND KASHMIR 0۸'80
fhe 7 NL STATE POLLUTION CONTROL BOARD porpice
Oe SRINAGAR, aah
fig, OMe ‏ہے‎
‎Sa : 0-0 1७२८ ‏کر‎
‏فو‎ Nottication Ne KYL AS
en He Dated AS IS; 2095
‏جن‎ हें In exercise of powers vest:d in the Boas ander Water (eventos & Cont ol of
2 >۔۲۱۱01:۱٥٦(‎ ۸۵۱ 17۰+ & Air (Prevention & Control of Pollution) Act 1981, the ccnsent
at mechanism in J & I Pollution Control Hoaul shalt henceforth be as under, as app oved ”
_ of) Sby the Board in its 20" Board mecting held on 11" Of March 2008
VS ae Validity of Consent
‏چپ و‎ Red Category One year.
= मु Orange Category Vayu year
Green Category 101٠٦٢۸
oe The valida conse shall be fora peried of one, two and three full year: trom,
4 “the date of issue fer . Orangeand (एल categories respectively, instead of fin ‏اٹ‎
‎“year? However any entrepreneur can seck the consent to establish for lesser period the -
- “establishment of the unit is likely ‏ص‎ tale lesser period than appricabie to his case inder
x Orange & Green categories stated above .
eR -
eB : ers rE
oe ; FEE STRUCTURE ह । -
‏وی نے‎ Be + ‏یں تپ‎
‏کے کت‎ . न . .
a OST Fee-structure is accordingly changed and shall hence forth he as per An ۰٤۷
५... Happended hereto Consent Foe stl howe ‏می‎ Proportions sos the validity. 0 the
ua ‘consent to establish in case the enteprenecis secka the cesses bo ctablish fora esser
2... Lperind under Orange & Green categories sited ibe ¢ हि
‏ئن‎ Fee deposited in the cases where conseni is not granted roy various reasons shall
{not be accounted for subsequent 5 vars. as tha ahncunt denogited ts presumed to have been
“2 SE S’spent on ficid inspections, examination avd processing, the case ete हु
पु This issues in super session of all previons orders ou the subject with i 'तीताएं
: effect
3 i uy
Member Secrek y
a : f 7: ‏ذ-23د2 /کھ/ نما‎ 72 oz ose
oh ‏ساط مہ مث‎ 2 6-OS-.
‏0ج‎ “Copy to the:- : ‏ںہ‎
‎a 1. Commissioner Seeretary to 'त्सपावाएा, - Industries & Con nerce 7
‏ان‎ ~ Department for informarini . ' ;
\ ‏کس‎ Dad ex Directar Induste es, iasittt ‏۱دا ۔‎ the 11011:11, .
‏کے‎ 3.2 Managing Direct, SUXCD , far ‏:زاون مسر‎
‏ہکوج‎ 1-۰۰٠ ‏کمتور7ص 11ہ‎ ا2۳۷٣.‎ (1۱۱۳۴ 1۰۰:0
‏کہ چپ‎ ड़ Regional Director , व वाला oe uvorrrarion gue सो पाता!
‏ہے وکا ہن‎ 0. Regional Director, SPCR. Mesh for ‏جحشرجھ طبر‎ end circulation. ;
‏.ہہ کو ا‎ J
‏ا 27 ' سام نر‎
‏کس‎ FR ‏متا‎ 1
‏کو - س۷ ھا کا‎ ८.2८ 9८1 ४५
‏ا‎ 7 . «Let () ۲٢
‏ر۴۰۸:. ۸۱1 کے‎ 5
tayo ‏ال‎ ?
Coby a
es ۲ :
पी : हि /
‏پا‎ न 7 2 yf
J ‏اج‎
‎ve ‏سا‎
‎a 4
eee
