---
doc_id: "24bf9fd2fba779bc"
source_url: "https://maavaishnodevi.org/sites/default/files/2023-10/SMVDIMEEEeT04976.pdf"
ministry: "Shri Mata Vaishno Devi Shrine Board, Jammu and Kashmir"
title: "Click here to download complete tender notice"
date: ""
pages: 51
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7b1422050dd3ce8c"
---

<!-- page 1 -->

OFFICE OF THE CHIEF EXECUTIVE OFFICER, SHRI MATA VAISHNO DEVI SHRINE BOARD,
Central Office, Jammu Road, Katra (J&K) – 182301 (Ph.: 01991-232189, Fax: 01991-201705)
E-mail: dyceov@maavaishnodevi.net, xensmvdime@maavaishnodevi.net

e-NIT No. SMVDIME/EE/e-T/04/976 Dated: 20.09.2021
For and on behalf of the Chairman SMVD Shrine Board, Katra, the Chief Executive Officer, SMVD Shrine
Board, Katra, invites sealed item rate bids through E-Tendering from reputed and experienced contractors/
Firms registered with J&K U.T. Government / Central Government for the followings work: S. No.

Description of work

1.

Construction of Ayushman
Bharat Wards in the Premises
of SMVDIME, Kakryal, Katra.

Estimated
Cost
(in Lac)

EMD 2%
(in lacs)

Stipulated
Completion

Time

of

Rs. 123.00

Rs. 2.50

04 calendar months from the
date of Award.

The e-NIT consisting of qualifying information, eligibility criteria, specifications, bill of quantities, (B.O.Q),
set of Terms & Conditions of contract
and other details can be seen/downloaded from
http://jktenders.gov.in and / or SMVDSB website www.maavaishnodevi.org as per following timelines:Publishing Date
Download Start Date
Bid Submission Start Date
Bid Submission End Date (Online)
Date of Opening of Technical Bid (Online)
Date of Opening of Financial Bid (Online)

:
:
:
:
:
:

20.09.2021 at 04:00 PM
20.09.2021 at 04:00 PM
21.09.2021 at 10:00 AM
10.10.2021 at 03:00 PM
11.10.2021 at 11:30 AM
Shall be intimated to the Technically Qualified
Bidders

The e-Tender must be uploaded with stipulated amount of earnest money which can be deposited in the
official account of Shri Mata Vaishno Devi Shrine Board Branch J&K Bank Katra, Account No.
0235040500001804, IFSC-JAKA0KATTRA through RTGS/NEFT or it can be in the shape of
CDR/FDR/TDR0 drawn from Nationalized/Scheduled schedule bank pledge to CAO of Shri Mata
Vaishno Devi Shrine Board. The bidder shall mention UTR No. in the prescribed Financial Bid Form.
The Tender Fee of Rs. 5,000/- (Non-Refundable) shall be deposited in the official account of Shri
Mata Vaishno Devi Shrine Board Branch J&K Bank Katra, Account No. 0235040500001804, IFSC JAKA0KATTRA through RTGS/NEFT. The bidder shall mention UTR No. in the prescribed Financial Bid
Form.
OR
The scanned copy of the EMD and Tender Fee shall be uploaded online along with the other documents
and the original copy shall have to be deposited within 07 days or before the issuance of LOA, whichever
is earlier.
Complete bidding process shall be done online on E-Tender Portal www.jktenders.gov.in.
The tenders should be submitted strictly in accordance with the provisions of the detailed E-NIT. No
Proposal will be accepted in physical form unless & until it is submitted online as per the terms &
conditions of the NIT.

Sd/
(Vishavjeet Singh), KAS
Dy. Chief Executive Officer
Shri Mata Vaishno Devi Shrine Board, Katra

Page 1 of 51

<!-- page 2 -->

BRIEF INDRODUCTION
The Holy Shrine of Shri Mata Vaishno Devi, located at an altitude of 5200 ft. in the Reasi
district of Jammu & Kashmir, is among the most popular pilgrimages of our country. Shri
Mata Vaishno Devi Shrine Board (SMVDSB) set up as an Autonomous Organization,
through a Statute in 1986, is chaired by His Excellency the Lt. Governor of U.T. of
Jammu & Kashmir. The main objective of the Board is to provide for the better
management, administration and governance of Shri Mata Vaishno Devi Shrine.
The Shrine Board, since its inception, has continuously strived hard to provide all
possible facilities to the devotees visiting the Holy Shrine. Efforts are on to further
improve the facilities for visiting pilgrims, in order to make the pilgrimage a safe,
comfortable and pleasurable experience. As a part of health facilities, Shri Mata Vaishno
Devi Shrine Board has setup a Multispeciality Hospital at Kakryal at an approx. distance
of 08 Kms. from the Holy Town of Katra, which is at present manage by the Narayana
Health, an Indian chain of multispeciality hospitals, under the overall supervision of
SMVDSB.
As a part of Health Care Facilities, the Govt. of India has launched Ayushman Bharat
Yojna in 2018 and extended the Sehat Health Insurance scheme under Ayushman
Bharat in U.T. of J&K. The most important feature of this Scheme is that every citizen of
Jammu and Kashmir despite their financial status will be covered under SEHAT Health
Insurance Scheme and the government will bear the expenses of treatment of the citizen
up to Rs.5.00 lakh. Recently, the Govt. has also empaneled, Shri Mata Vaishno Devi
Narayana Superspeciality Hospital Katra for providing the benefits under the scheme to
all the beneficiaries. In order to extend the Medical Facilities to the beneficiaries under
Ayush Bharat Scheme, a space has been identified at Ground Floor of the existing
Shopping Complex at SMVDIME for creation of an Ayushman Bharat Ward having 41
beds, 03 Nos. Isolation rooms (Air Lock) including Oxygen Bank, Record Room, Store,
Medical / Nurse Chain\, reception / Billing, Waiting Area and separate toilet for Male /
Female.

*****-----*****

Page 2 of 51

<!-- page 3 -->

INSTRUCTION TO BIDDERS REGARDING E-TENDERING PROCESS- SECTION-1
1.1
1.2

1.3
1.4
1.5
1.6

1.7
1.8
1.9
1.10
1.11

1.12

1.13

1.14
1.15
1.16

1.17

The interested bidder can download the E-NIT / bidding document from the
website www.jktenders.gov.in / official website www.maavaishnodevi.org.
To participate in bidding process, bidders have to get (DSC) “Digital Signature
Certificate” as per information Technology Act-2000, to participate in online
bidding process. This certificate will be required for digitally signing the bid.
Bidders can get above mentioned digital certificate from any approved vendor.
The Bidder, who already possess valid (DSC) Digital Signature Certificates, need
not to procure new Digital Signature Certificate.
The Technical Bids shall be opened online.
Financial Bid of technically qualified bidders shall be opened online, the date and
time shall be communicated to them separately.
The bidders have to submit their bids online in electronic format with Digital
Signature. The bids cannot be uploaded without Digital Signature. No Proposal
will be accepted in physical form.
Bids will be opened online as per scheduled time mentioned in the E-NIT
document.
Before submission of online bids, bidders must ensure that scanned copies of all
the necessary documents have been attached with bid.
The SMVDSB will not be responsible for any delay in online submission of bids
whatsoever reasons may be.
All the required information for bid must be filled and submitted online.
Bidders should submit the scanned copies of receipt of cost of tender documents
& EMD as specified in the tender documents through email before the opening of
technical bid.
Bidders are advised to use “My Documents” area in their user on
http://jktenders.gov.in, e-tendering portal to store important documents like
Balance sheet, GST Registration Certificate, Tax Clearance Certificate, IT
certificate, Manufactures authorization and other related documents etc., and
attach these certificates as Non-Statutory documents while submitting their bids.
Bidders are advised not to make any change in BOQ (Bill of Quantities) contents
or its name. In no case they should attempt to create similar BOQ manually. The
BOQ downloaded should be used for filling the item rate as prescribed and it
should be saved with the same as it contains.
Bidders are advised to scan their documents at 100 DPI (Dots per Inch)
resolutions with Black and White, PDF / Scan properly.
The guidelines for submission of bid online can be downloaded from the website
http://www.jktenders.gov.in and www.maavaishnodevi.org.
The tenderer should carefully study the E-NIT document and prepare his tender
with consideration of all provisions of the document. They should fully acquaint
themselves with site conditions and all other factors which may influence
preparation of his tender.
Bidder should be ready with the Original Copies of documents, EMD as uploaded
online as specified in the tender documents. The original copies of documents,
Page 3 of 51

<!-- page 4 -->

1.18

1.19

1.20

1.21

1.22
1.23

EMD and relevant documents be submitted to the tender inviting authority within
seven days after opening of financial bid, in the event of non-compliance the
Bidder will be rejected and the bidder will not be allowed to participate in any
further/future tendering process in the Division for a period of One year.
The Original Documents, submitted by L-1 should be same as uploaded on-line
(scanned copies) otherwise the allotment will not be issued, the tenders will be
cancelled and the bidders will not be allowed to participate in any further/future
tendering process in the Division for a period of One year.
The detail of cost of documents, EMD specified in the tender documents should
be the same as submitted online (Scanned copies) otherwise bid will not be
accepted.
The successful Bidder/Contractor should ensure that the awarded work be started
within 07 days of Letter of Award. The Letter of Award will send through E-Mail to
the Contractor by the Authority or it can be collected from the Office Chief
Executive Officer, SMVDSB, Katra.
If the Contractor fails to start the work within 07 days of issuance of LOA. It shall
be revoked without any notices to the contractor/firm. In such an event the
security deposit of the Contractor shall be forfeited. SMVDSB reserves the right to
offer the work to L2 at the approved rates or it can be retendered.
The Contractor shall have to take e-photographs of each work before execution,
during execution and after completion of work.
The Contractor has to pay for all the Quality Test Checks under taken by
Engineer-In-Charge of SMVDSB.

*****--------*****

Page 4 of 51

<!-- page 5 -->

DETAILED TERMS AND CONDITIONS - SECTION 2
2.1

Eligibility Criteria (Part-I): The Part-I shall contain the complete documents as
per Annexure- “A” to meet the eligibility criteria as per the following credentials: -

2.1.1

The Bidder must be Firm/Company/Proprietary ship firm registered under
appropriate authorities (attested copies of the relevant registration certificates
including certificate of incorporation to be attached).

2.1.2

Each bidder shall submit only one bid against eNIT. The Bidder submitting
multiple bids shall be out rightly rejected.

2.1.3

The Bidders should mention their complete name, address and core business in
the tender. If the authorized person is signing the documents he must be legally
authorized.

2.1.4

Detail of Technical and Non-Technical manpower to be deployed must be
attached. The technical manpower should have adequate qualification/experience
in the relevant field. The Project Manager/ Resident Engineer shall be Graduate in
Civil/Mechanical Engineering with minimum 5 years of experience. (the details
are to be attached as per the Annexure- “B”).

2.1.5

The Agency shall be a profitable entity and shall not have incurred losses in any of
the last 03 consecutive financial years (2018-19, 2019-20, 2020-21) and the firm
shall have average annual financial turnover atleast 30% of the estimated cost of
related work during the last 05 years, ending 31st March of the previous financial
year. (attested copies of Audited Balance Sheets & Profit & Loss statement,
duly certified by the Chartered Accountant, are to be attached by the
Bidder).

2.1.6

The bidders shall have professional experience in execution of similar work with
any of the Central Govt. / State Govt. / PSUs / Reputed Organizations. The parties
uploading bidder must have executed the similar nature of works in following
manners: (i)
(ii)
(iii)

Atleast one work of similar nature of the value of 80% of the estimated cost
of during the last 05 years; OR
Atleast two works of similar nature of the value of 50% of the estimated
cost of during the last 05 years; OR
Atleast three works of similar nature of the value of 40% of the estimated
cost of during the last 05 years.
(Attested copies of the documentary proof including the relevant Letter of
Award(s) and Completion Certificates including value of work done in
support of the above requisite criteria must be submitted by the tenderer, in
absence of which the bid shall not be considered).
Page 5 of 51

<!-- page 6 -->

2.1.7

The Bidder shall submit the detail of equipment or components required for the
construction of Ayushman Bharat Ward. (Bidder shall also certify the
acquisition of the same i.e. owned, lease or hire etc.)

2.1.8

The bidders shall have to give an undertaking to the effect that the Firm has not
been black listed / holiday listed anytime in the past by any Country / Semi
Government Agency/PSU/State Govt./Central Govt./Autonomous Bodies/MNCs
etc., duly attested by Judicial / Executive Magistrate / Notary. Each participating
bidders shall have to undertake that all document attached herewith are true and
in the event of any illegally noticed at any stage, the LOA shall be revoked,
security deposit forfeited. The remaining work shall be got executed at the risk
and cost of the firm besides debarring it for future participation in tender process
of SMVDSB for five years.

2.1.9

A Solvency Certificate from the banker of Bidder to be submitted for credit
worthiness of the firm.

2.2

GENERAL CONDITIONS

2.2.1 A sum of Rs.2.50 Lacs (Rupees Two Lac Fifty Thousand only) as Earnest Money
Deposit (EMD) can either be deposited in the official account of Shri Mata Vaishno
Devi Shrine Board Branch J&K Bank Katra, Account No. 0235040500001804,
IFSC: JAKA0KATTRA through RTGS/NEFT or it can be in the shape of
CDR/FDR/TDR drawn from Nationalized/Schedule Bank duly pledged to Chief
Accounts Officer, SMVDSB. The tender not accompanied with Earnest Money
deposit shall be rejected. EMD of successful tenderer shall be released on
submission of PBG @5% of the estimated cost, whereas, the Earnest Money
deposit of unsuccessful tenderer(s) will be released after the Notice/Letter of
Award of work is issued in favor of successful tenderer.
2.2.2 The tenderer shall submit the Bid online in electronic format with Digital Signature
in Two Bid format: the first part as “TECHNICAL BID” which shall contain all
relevant techno/commercial details notified through e-NIT. The financial Bid shall
be submitted separately in Part II as “FINANCIAL BID”.

2.2.3 The tenderer shall not be entitled, during the period of validity of their tender, to
revoke or withdraw their tenders or vary or modify any of the condition originally
contained in the E-Tender. In case of a tenderer revoking or withdrawing his
tender or varying any term in regard thereof, the SMVDSB shall forfeit his Earnest
Money submitted with his E-Tender.
2.2.4 The Shrine Board reserves the right to reject, accept or prefer any E-Tender in
part or full without assigning any reason whatsoever at any stage and also
reserves the right to re-invite the E-Tender at his sole discretion.
Page 6 of 51

<!-- page 7 -->

2.2.5 The SMVDSB i.e. SMVDSB reserve the right to negotiate the quoted rates, terms
and conditions with the lowest tenderer or any other tenderers to ascertain the
suitability of the acceptable offer.
2.2.6

The Validity of the E-Tender shall be 120 days from the last date of submission of
E-Tendering.

2.2.7

All disputes arising out in any way connected with this contract shall be deemed to
have arisen at Jammu/Katra and only courts in Jammu/Katra/Reasi shall have
jurisdiction to determine the same.

2.2.8

All the above conditions of e-NIT and all the correspondence relevant to the
contract shall form the part the contract.

2.2.9

The tenderers should quote their rates with the total both in figures and words.
Amounts quoted in words shall be deemed to be correct in case of cuttings and
overwriting.
*****--------*****

Page 7 of 51

<!-- page 8 -->

INSTRUCTIONS FOR TENDERERS – SECTION-3

3.1

Before tendering, the Tenderers in their own interest are advised to visit site to
acquaint about the condition of site, its surroundings, terrain, climate, availability
of labour, power, water, communication facilities etc.

3.2

Time is the essence of the contract and the works shall be completed within the
time schedule as indicated in the Appendix to the form of Tender.

3.3

(i)
The tenderer shall complete the annexure(s), Forms of Tender, Schedules
and Bill of Quantities and information called for therein, and shall sign with date,
duly stamped with company’s seal on each page of the tender documents.
(ii)
The Tender shall contain full address, Telephone Nos., Fax No. and e-mail
address for communication.

3.4

Quoted Rates shall be entered in ink, both in figures and words without
overwriting and in the event of any discrepancy between the two, rates entered in
words shall only be considered accurate. Cuttings, over writings must be avoided
if absolutely unavoidable should be initialed and stamped.

3.5

All documents of the tender are to be read in conjunction with each other and
rates quoted by the tenderer shall take this aspect into consideration.

3.6

The Tender must accompany the following information and documents
mandatory:
a)

A detailed construction program in the form of a Bar-Chart showing the
Tenderer’s proposed sequence of operations together with the estimated
times for each activity, including construction/manufacture, delivery, erection
and commissioning to ensure adherence to the overall completion period, as
indicated in the document.

b)

Full details of methodology or scheme which the Contractor proposes to use
for the construction or for any other purpose is required to be submitted. The
scheme should be elaborated in detail, so as to enable SMVDSB to assess
the adequacy of the construction plans for executing at site included in the
scope of the work at optimum cost strictly within the time frame envisaged by
Shrine Board for completion of these works. Mode of transportation for
material and machinery & equipment needs to be submitted in the
methodology. In the items where general specifications are being provided
and similar product has been allowed, methodology should clearly cover as
to which product would be used against respective item. Failure of contractor
to furnish these details or indicating only sketchy details of construction
methodology which do not provide sufficient information for assessing the
Page 8 of 51

<!-- page 9 -->

soundness of the construction planning would automatically lead to rejection
of his tender.
c)

The Tenderer’s proposals for supervising the work including the CVs of the
various grades of technical supervisory personnel/other staff proposed to be
deployed for the construction period.

d)

Information in respect of following aspects:
(i)
Details of business & technical organization.

e)

(ii)

Financial resources.

(iii)

Past experience in performing work similar in nature and magnitude
including mention of the status of completion of project/arbitration etc.

True copy of latest Income Tax and GST Clearance Certificates and license
under Labour Regulations issued by the competent authorities in favor of the
Contractor.

3.7

Tenders received without Earnest Money Deposit (EMD) & Tender cost will not be
accepted and shall be out rightly rejected.

3.8

The successful tenderer shall not be entitled to any compensation for any loss
suffered on account of delays, in commencing or executing the work, whatever the
cause of delays may be, including delays arising out of modifications to the work
entrusted to tenderer or in any sub-contract connected therewith or delays in
awarding contracts for other trades of the project or in commencement of
completion of such works or in procuring Government controlled or other building
materials or in obtaining water and power connections for construction purposes
or for any claim in respect thereof. The SMVDSB does not accept liability for any
sum towards loss of overheads and profits of the contractor besides the tender
amount, subject to such variations as are provided for herein.

3.9

The SMVDSB reserves the right to adjust arithmetical or other errors in any
Tender in the way, which he considers suitable. Any adjustments so made by the
SMVDSB shall be stated to the Tenderer if the Employer shall make an offer to
accept the tender.

3.10

The SMVDSB does not bind himself to accept the lowest or any tender and has
the right to refuse or accept any Tender without assigning any reason. The
SMVDSB reserve right to re-invite the Tender without assigning any reasons. The
SMVDSB/SMVDSB reserves the right to negotiate the quoted rates, terms and
conditions with the lowest tender or any of the other tenderers to ascertain the
suitability of the acceptable offer and no claim or objection on this account will be
entertained.

Page 9 of 51

<!-- page 10 -->

3.11

The successful tenderer shall be liable to pay the turnover tax or such other taxes
on the work under the contract as and when levied by the UT/central Government
Authorities and the Employer shall not entertain any such claims, whatsoever in
this respect. He shall have to comply all the statutory compliance.

*****-----*****

Page 10 of 51

<!-- page 11 -->

GENERAL CONDITIONS OF CONTRACT – SECTION-4
4.1

Definitions & Interpretations
In the contract (as herein under defined) unless, it is otherwise repugnant to the
text, the definition of the following words and expressions shall have the meaning
hereunder assigned except otherwise specified:
i)

“Site” means the lands and other places on, under, in, or through which the
works are to be executed or carried out and any other lands or places
provided by the SMVDSB for the purpose of the works together with such
other places as may be specifically designated in the contract as forming
part of the site.

ii)

The expression “work” or “works” shall unless there be something either in
the subject or context repugnant to such construction be construed and
taken to mean the works to be executed in accordance with the contract or
parts thereof as the case may be and shall include all additional, altered or
substituted works as required for the performance of the contract.

iii)

“Drawings” means the drawings referred to in the documents and any
modification of such drawings approved in writing by the SMVDSB and such
other drawings as may from time to time be furnished or approved in writing
by the SMVDSB / Consultant.

iv)

“Bill of Quantities “means the schedule of quantities or items, materials &
Rates, Summaries, etc. as finally accepted.

v)

“Specification” means the specifications of approved standard as specified
in the tender document.

vi)

“Contract” means this agreement and all documents which form part thereof
and / or annexed thereto and all amendments thereto made in accordance
with the provisions hereof based on Notice Inviting Tenders, the sealed
Quotations and the Tender documents including the Tender, General
conditions of the contract, specifications, designs & drawings, priced
schedule & priced Bill of quantities and schedule of rates and
acceptance thereof, read in conjunction and complementary to one and
other.

vii)

“Contract Price” or “Contract Value” or “Contract Sum” means the sum set
out hereto as the total value of the contract and shall be subject to additions
and / or deductions and rebated in accordance with the provision herein
contained.

Page 11 of 51

<!-- page 12 -->

viii)

“SMVDSB” means Shri Mata Vaishno Devi Shrine Board, Katra Jammu
(J&K) through the Chief Executive Officer, SMVD Shrine Board, Katra
(J&K).

ix)

“Engineer” means Engineer-In-charge or his authorized representatives or
such other firm / persons, as shall be nominated by the SMVDSB.

x)

“Contractor” means who is awarded contract to perform the work in
accordance with the contract and includes the contractor’s personnel,
representatives, successors and permitted assigns.

xi)

“Permanent Works” shall mean the works which are of a permanent nature
and are not Temporary works.

xii)

“Temporary works,” means all temporary works of every kind required in or
about the execution, completion or maintenance of the works.

xiii)

“Materials” means the materials, apparatus, equipment, fittings, fixtures and
other things for incorporation in the works.

xiv)

“Defect Liability Period” shall mean the period of 365 (one-year) days
calculated from the date of successful completion of the work, solely to the
satisfaction of Engineer-In-charge, SMVDSB.

xv)

“Market Rate” means the rate as decided by the SMVDSB, on the basis of
cost of materials inclusive of any taxes, duty, Octroi or such statutes in force
at the time of work and cost of labour at site where the work is to be
executed plus the percentage to cover all overheads and profit.

xvi)

“Approved” means approved in writing; “approval” means approval in
writing.

xvii)

“Month” means calendar month

xviii) “Week” means seven consecutive calendar days.

4.2

xix)

“Day” means a calendar day beginning and ending at midnight

xx)

“Virtual Completion” means the date when installation is sufficiently
completed in accordance with the contract documents as modified by any
change or variation orders agreed to by the parties, so that the SMVDSB
can occupy the project for the use it was intended.

Extent of Contract: - The contract comprises the construction, completion and
maintenance of the works during the period of defect liability period and except in
so far as the contract otherwise provides, the provision of all labour, materials,
Page 12 of 51

<!-- page 13 -->

constructional plant, temporary works and everything whether of a temporary or
permanent nature required in and for such construction, completion and
maintenance so far as the necessity for providing the same is specified in or
reasonably to be inferred from the contract.
4.3
4.3.1

Rates and Taxes:
The rates shall be quoted inclusive of all taxes (including GST), duties, levies,
fees or charges. All the said taxes, duties, levies, fees and charges shall be the
Contractor’s responsibility and SMVDSB shall not be required to pay any
additional or extra amount whatsoever on the account. However, difference in
rates due to upward / downward revision in GST, if any, till completion of the work,
shall be considered on the submission of documentary proof and subject to
satisfaction of Client.

4.3.2

Escalation of rates: The rates quoted by the firm shall remain firm during the
entire Contract Period. No escalation in rates on any account eventually foreseen
or unforeseen shall be paid during the Contract Period. However, in case of any
variation of quantities, the Contractor shall have to execute the additional
quantities at the same rate as quoted in the Financial Bid.

4.3.3

Correction of Arithmetic Errors in Financial Bids: The Bid Evaluation
Committee shall correct arithmetical errors in substantially responsive Bids, on the
following basis, namely: -

4.3.3.1

If there is a discrepancy between the unit price and the total price that is obtained
by multiplying the unit price and quantity, the unit price shall prevail and the total
price shall be corrected;

4.3.3.2

If there is an error in a total corresponding to the addition or subtraction of
subtotals, the subtotals shall prevail and the total shall be corrected; and

4.3.3.3

If there is a discrepancy between words and figures, the amount in words shall
prevail, unless the amount expressed in words is related to an arithmetic error, in
which case the amount in figures shall prevail subject to clause (a) and (b) above.

4.4

Award of Work: After completion of the tender evaluation process, the work will
be awarded to the successful bidder / contractor as per the provisions of the
Contract, the letter of award will be send through email to the contractor by the
authority or it can be collected from the office of the Chief Executive Officer,
SMVDSB, Central Office, Katra. The successful Bidder / Contractor shall ensure
that the awarded work be started within 07 days of the issuance of the Letter of
Award (LOA), otherwise, the competent authority may consider alternate
arrangements as per the Clause 1.21 of the Instruction to Bidder

4.5

Time Frame: The time frame for completion of the work shall be four (04) months,
reckoned from the date of issuance of Letter of Award (LOA).

Page 13 of 51

<!-- page 14 -->

4.6
4.6.1

Contract Agreement
Within 30 days after the issue of letter of Letter of Award, the contractor shall have
to enter into a written deed of agreement incorporating all the terms and conditions
as embodied in the Tender Documents or modified subsequently in writing and
those contained in the letter of acceptance, with the SMVDSB.

4.6.2

The following documents shall be deemed to form and be read and construed a
part of the Contract Agreement:
a. The said Tender and Appendix.
b. Form of Tender
c. Conditions of Contract.
d. Letter of acceptance.
e. Contract price.
f. Priced Bill of Quantities as accepted.
g. Specifications.
h. Drawings.
i. Other additional documents as exchanged in correspondence on the subject

4.7

Documents Mutually Explanatory: - Except if and to the extent otherwise
provided by the contract, the provisions of the conditions of contract shall prevail
over those of any other document forming Part of the contract. Subject to the
foregoing, the several documents forming the contract are to be taken as mutually
explanatory of one another but in case of ambiguities or discrepancies, the same
shall be explained and adjusted by the Engineer-In-Charge who shall thereupon
issue to the contractor instructions directing in what manner the work is to be
carried out.

4.8
4.8.1

Payment Terms & Security Deposit:
The payments on account of running bill shall be made against the submission of
Tax Invoice for the completed work supported with joint measurement sheets and
MB book, duly certified by the Engineer-in-Charge of SMVDSB.

4.8.2

An amount @5% (Five percent) shall be deducted from each of the running
account bills of the contractor and retained as Security Deposit.

4.8.3

The Security Deposit will be released against the receipt of BG of equivalent
amount after the successful completion of the work. However, the Security
Deposit, as a whole, along with PBG will be released after the successful
completion of the Defect Liability Period (DLP) and after adjustment of SMVDSB’s
dues / outstanding or liquidated damages, if any, on the certification of EngineerIn-charge.

4.8.4

Defect Liability Period Certificate (DLP): The contract shall not be considered as
completed until a Final Completion Certificate at the end of DLP has been signed
by the Engineer-In-charge with a copy to the contractor stating that the works have
been completed and maintained during the Defect Liability Period by the contractor
to his full satisfaction. The Completion Certificate shall be given by the EngineerPage 14 of 51

<!-- page 15 -->

In-charge within twenty-eight (28) days after the expiration of the Defect Liability
Period.
4.8.5

Defect Liability Period: The contractor shall maintain (free of cost) the whole of
permanent works in a thoroughly sound, substantial efficient and perfect condition
during the Defect Liability Period of 365 days, after the date of completion of the
whole or part of works, as certified by the Engineer-In-Charge, remedying at his
own cost and to the satisfaction of the Engineer, any defects which may become
apparent, prior to or during this Defects-Liability period, arising out of defective
materials and/or workmanship or default, neglect or omission of the contractor
notwithstanding, that the SMVDSB has used portions of the works before the
whole of the works were completed, during the Defect Liability Period.

4.8.6 Performance Bank Guarantee (PBG): - The successful contractor shall have to
deposit with SMVDSB ‘PBG’ for the due and faithful performance of the contract
for a sum equal to 5% (five percent) of the accepted tender value. Such Bank
Guarantee shall be drawn from day Nationalized/Schedule Bank in India on the
prescribed format. The Bank Guarantee shall be furnished within 07 days from the
date of Letter of Award (LOA) and shall be valid until expiry of the Defect Liability
Period (DLP) of 365 days reckoned from the date of issue of Completion Certificate
of the work. In case of failure, the competent authority reserves the right to
terminate/cancel the contract besides fore feature of EMD. The PBG shall
construed as a part of overall Security Deposit.
4.9
4.9.1

Contractor’s General Responsibilities
The contractor shall, subject to the provisions of the contract, and with due care
and diligence, execute, complete and maintain the works and provide all labour
incl. Supervision, materials, constructional plant and all other things, whether of a
temporary or permanent nature, required in and for such execution, completion
and maintenance.

4.9.2

The contractor shall carry out and complete and maintain the works in accordance
with good engineering practices to the entire satisfaction of the Engineer-In-Charge
of deputed by SMVDSB for the purpose.

4.9.3

Safety of Site Operations: The Contractor shall take full responsibility for the
safety, stability and adequacy of all site operations and methods of construction
including all temporary works, provided that the contractor shall not be responsible,
except as may be expressly provided in the contract, for the design of the
permanent works. The contractor shall take all necessary precautionary/accidental
prevention measures to avoid inconvenience to the pilgrims. However, details
thereof shall be submitted to Engineer-in-charge of Shrine Board prior to the
execution of work and decision shall be taken by Shrine Board after analyzing the
safety aspects and site conditions and this shall be binding on the contractor and
no claim shall be entertained on this account in any form.

Page 15 of 51

<!-- page 16 -->

4.10

Sub-Letting: Except where otherwise expressly provided in this contract, the
contractor shall not sub-let the whole or any part of the work. If at any stage it
comes to the notice of SMVDSB that the work has been sub-leted, SMVDSB shall
be within its right to cancel the contract without notice. In such event the remaining
work shall be got executed at the risk and responsibility of contractor. The
expenditure so incurred in execution of remaining uncompleted work, the same
shall recovered by encashing PBG.

4.11 Technical Specification:
4.11.1 All the civil works shall be carried out as per the technical specifications given in
the tender and as per the relevant codes/CPWD guidelines.
4.11.2 All the materials shall be inspected /tested by the Technical team of SMVDSB to
ensure the quality.
4.11.3 Regular test samples shall be sent for quality checks to the authorized
Laboratories/institutions through SMVDSB’s representative. The running bills shall
only be certified by the Engineer-in-charge after getting the quality test certificates,
if any, relevant of the portion of work pertaining to the running bill. Expenditure in
quality tests shall be borne by the Executing Agency.
4.12

Work to be to the satisfaction of SMVDSB / Consultant / Engineer-In-Charge

4.12.1 The contractor shall execute, complete and maintain the works in strict Accordance
with the condition of e-NIT to the satisfaction of the Engineer-In-Charge of
SMVDSB.
4.12.2 Remedy for Bad Work: If it shall appear to the SMVDSB Engineer-In-Charge that
any work has been executed with unsound, imperfect or unskillful workmanship or
with materials of any inferior description, or that any materials or articles provided
by him for the execution of work are unsound or of a quality inferior to that
contracted for, or otherwise not in accordance with the contract, the contractor
shall on demand in writing from the Engineer-In-Charge forthwith rectify and
remove and reconstruct the work, so specified in whole or in part as the case may
require, at his own risk and cost. In the event of failure, the Engineer-In-Charge
may rectify or remove and re-execute part or whole of the work with new materials
after dismantling the rejected works at risk and cost the contractor.
4.13

Setting Out: The contractor shall be responsible for the true and proper setting out
of the works in relation to original points, lines and levels of reference given by the
Engineer and mentioned in the drawings and for the correctness (subject as above
mentioned) of the position, levels, dimensions and alignment of all parts of the
works and for the provision of all necessary instruments, appliances and labour in
connection therewith. The checking of any setting out or of any line or level by the
Engineer or the Engineer’s representative shall not in any way relieve the
contractor of his responsibility for the correctness thereof.

Page 16 of 51

<!-- page 17 -->

4.14

Watch & Ward & Lighting: The contractor shall in connection with the works
provide and maintain at his own cost adequate lights, guards, fencing, warning
signs and watch & ward staff when and where necessary or required by the
Engineer or Engineer’s representative or by duly constituted authority for the
protection of the works or for the safety and convenience of the public or others.

4.15

Care & Protection of Works: From the commencement to the certified
completion of the whole of works, the contractor shall take full responsibility for
the care thereof and of all Temporary works and in case any damage, loss or
injury shall happen to the works or to any part thereof or to any Temporary
works from any cause whatsoever (save and except the excepted risks as
defined in conditions of the contract) the contractor shall at his own cost repair
and make good the same so that at completion, the works shall be in good order
and condition and in conformity to every respect with the requirements of the
contract and the SMVDSB/Engineer’s instructions. In the event of any such
damage, loss or injury happens from any of the excepted risks, the contractor
shall, if and to the extent required by the Engineer, repair and make good the same
as aforesaid at the cost of the Contractor. The contractor shall also be liable for
any damage to the works occasioned by him including his sub -contractors
in the course of any operations carried out by him for the purpose of completing
any outstanding work and complying with his obligations. The contractor shall
indemnify the SMVDSB from all risks on this account.

4.16

Compliance with statutes, regulations, etc.: The contractor shall be solely
responsible for the engagement of manpower, labour, insurance and compliance of
the labour regulations, safety, health, environment, sanitary and other regulations
as applicable in UT of J&K / Central Govt. The contractor shall conform to, in all
respects, with the provisions of any such statute, ordinance or law as aforesaid
and the regulation or Bye-Laws of any local or other duly constituted authority
prevailing, which may be applicable to the works or to any Temporary works and
with such rules and regulations of public bodies and companies as aforesaid and
shall keep the SMVDSB indemnified against all penalties and liability of every kind
for breach of any such statute, ordinance or law, regulation or bye-law. Provided
always that the SMVDSB will repay or allow to the contractor all such sums as the
Engineer shall certify to have been properly payable and paid by the contractor in
respect of such fees, after due verification of the documents.

4.17

Patents Rights & Royalties: The contractor shall save harmless and indemnify
the SMVDSB from and against all claims and proceedings for or on account of
infringement of any patent rights, design trade mark or name or other protected
rights in respect of any constructional Plant, Machine work or material used for or
in connection with the works or Temporary works or any of them and from against
all claims, demand, proceedings, damages, costs, charges and expenses
whatsoever in respect thereof or in relation thereto. The contractor shall pay all
tonnage and other royalties, rent and other payments or compensation (if any) for
getting stones, sand gravel, clay or other materials required for the works or
Temporary works or any of them.
Page 17 of 51

<!-- page 18 -->

4.18

Supply of Plant, Materials & Labour at site of work: The contractor shall at his
own expense supply and provide all the constructional plant, tools & equipment,
temporary works, materials both for temporary and for permanent works, labour
(skilled & unskilled and including the supervision thereof), transport to or from the
site and in and about the works and other things of every kind required for the
construction, completion and maintenance of works. The makes and brands of
various construction materials are specified in the list of approved makes.

4.19

Clearance of Site on completion: On the completion of the works, the contractor
shall clear away and remove from the site all constructional plant, surplus
materials, rubbish and temporary works of every kind and leave the whole of the
site and works clean and in a workman like condition to the full satisfaction of the
SMVDSB not later than one month from the virtual completion of the works.

4.20

Quality of Materials & Workmanship: All materials and workmanship shall be the
best of the respective kinds described in the contract and in accordance with the
SMVDSB/Engineer-In-Charge instructions and shall be subjected from time to time
to such tests as the SMVDSB/Engineer-In-Charge may direct at the place of
manufacture or fabrication or on the site or at all or any of such places. The
contractor shall upon the instructions of the Engineer-In-Charge furnish him with
documentation to prove that the materials & goods comply with the requirements of
contract and for requirement stated above. The Engineer-In-Charge may issue
instructions in regard to removal of material from site or any work, if these are not
in accordance with the contract. The contractor shall provide such assistance
instruments, machinery, labour and materials as are normally required for
examining, measuring and testing and work and the quality, weight or quantity of
any materials before incorporation in the works for testing as may be selected and
required by the Engineer/Engineer’s representative. All materials brought to site for
use on work shall conform to relevant Indian Standard Code published by Bureau
of Indian Standards.

4.21

Examination of work before covering up: No work shall be covered up or put
out of view without the approval of the Engineer-In-Charge and the contractor shall
afford full opportunity for the Engineer-In-Charge to examine and measure any
work which is about to be covered up or put out of view and to examine
foundations before permanent work in placed thereon.

4.22

Possession of Site for Construction: The SMVDSB, will with the Engineer-InCharge written order to commence the works, give to the contractor possession of
so much of the site as may be required to enable the contractor to commence and
proceed with the construction programme.

4.23

Power, Water & Other Facilities: The contractor shall be responsible for creating
providing within the scope of work all facilities necessary for the performance of the
work including (but not limited to) water, electrical power, electrical power through
generator, transportation, labour tools, construction equipment.
Page 18 of 51

<!-- page 19 -->

4.24

Certificate of Completion: The period of contract shall be four calendar months
reckoned from the date of issuance of LOA, the works shall be deemed to have
been duly completed when the Engineer-In-Charge certifies in writing that the
works have been completed in all respects by the contractor.

4.25

Insurance: Any accidental or incidental occurrence during the course of execution
shall be entirely liability of the contractor. The contractor has to observe due care
and caution as not cause damage to life/honour/property or cause mishap,
nuisance. The insurance cover of the team members working for the project shall
be responsibility of the contractor.

4.26 Variations
4.26.1 If the SMVDSB/Engineer-In-Charge may make any variation in quality or quantity
of the works or any part thereof that may in his opinion be necessary, then the
Engineer / SMVDSB shall have power to order the contractor to carry out the same
and in any of the following:
(a) Increase or decrease the quantity of any work included in the contract
(b) Omit any such work
(c) Change the character or quality or kind of any such work
(d) Change the levels lines position and dimensions of any part of the works and
(e) Execute additional work of any kind necessary for the completion of the works
and no such variation shall in any way vitiate or invalidate the contract but the
value (if any) of all such approved variations shall be taken into account in
ascertaining the amount of the contract price.
4.26.2 Extra item: In case, the item does not exist in any section of the BOQ, the same
will be paid on the basis of analysis of the rates based on the actual market rates
of various inputs with 10% of overhead charges & contractor’s profit.
4.26.3 Valuation of variation: The limit of variation in the contract including extra items
shall be 20% over and above the Contract Value. No escalation cost will be
provided for this variation.
4.27

Plants etc. not to be removed: No constructional Plant Temporary works or
materials or any part thereof shall be removed from the site without the written
consent of the SMVDSB which consent shall not be unreasonably withheld where
the same is no longer immediately required for the purpose of completion of the
works. The SMVDSB will permit the contractor the exclusive use of all such
constructional plant, temporary works and materials in and for the completion of
the works until the happening of any event which gives right to the SMVDSB to
exclude the contractor from the site and proceed with the completion of the works.

4.28 Works to be measured
4.28.1 The SMVDSB/Engineer shall except as otherwise stated ascertain and determine
by measurement the quantity and value of work done in accordance with the
contract. He shall, when he requires any part or parts of the works to be measured
Page 19 of 51

<!-- page 20 -->

give notice to the contractor’s authorized agent or representative who shall
forthwith attend or send a qualified agent to assist the Engineer or the Engineer’s
Representative in checking such measurements & other substantiations of the Bill
submitted by the contractor and shall furnish all particulars required by either of
them. Should the contractor not attend or neglect or omit to send such agent then
the measurement made by the Engineer or approved by him shall be taken to be
the correct measurement of the work and shall be conclusive and binding on the
contractor.
4.28.2 Unless otherwise described in the schedule of quantities, the method of
measurement shall be as described in method of measurement of building and civil
engineering works (IS 1200 Part I to XXV) latest edition of Bureau of Indian
Standards.
4.29

Payment in Event of Frustration: In the event of the contract being frustrated
whether by war or otherwise, howsoever, the sum payable by the SMVDSB, to the
contractor in respect of the works executed shall be the same as that which would
have been payable hereof if the contract had been terminated under the provisions
of conditions of the contract.

4.30 Serving of Notices
4.30.1 On Contractor: Any notice to be given to the Contractor, under the terms of the
contract shall be served by sending the same by registered post to or leaving the
same at the contractor’s Principal place of business (or in the event of the
contractor being a company to or at its Registered Office).
4.30.2 On SMVDSB: Any notice to be given to the SMVDSB, under the terms of the
contract, shall be served by sending the same by Registered post to or leaving the
same at the office of the Chief Executive Officer, SMVDSB, Katra.
4.31

Dimensions and Levels: All dimensions and levels shown on the drawings shall
be verified by the contractor on the site and he will be held responsible for the
accuracy and maintenance of all dimensions and levels. Figured dimensions are in
all cases to be accepted and no dimension shall be scaled. Large-scale details
shall take precedence over small-scale drawings. In case of discrepancy the
contractor shall ask for clarification from the Engineer’s Representative before
proceeding with the work.

4.32

Site Instruction Book: The Engineer’s Representative shall maintain a site
instruction book on the site in which he or his authorized representative’s remarks,
instructions, decisions and other essential details, of the work shall be recorded.
The contractor shall regularly note the contents of this book and initial it signifying
his having done so and take immediate action on the same.

4.33

Progress Report: The contractor shall submit monthly progress reports indicating
status of each activity planned for the period under consideration and summary of
each completed and planned activity and the anticipated starting date for the
activities planned but not in progress, schedule of materials including the
Page 20 of 51

<!-- page 21 -->

details of materials received and expected time of arrival of other materials as
ordered and such other details affecting the programme and progress of the work
to the Engineer’s Representative in a form as required by him which shall also
include reasonable number of progress photographs of the works.
4.34

Extension of Time: No extension of time specified for the completion of work shall
be granted or claimed by the contractor as matter of right. However, the time for
completion of the works in the event of any authorized deviations or additional
work resulting in additional cost over the contract sum, shall be extended, if
requested by the contractor, in the proportion in which the cost of the altered,
additional or substituted work bears to the original contract sums plus any
additional time, which the ‘SMVDSB’ may consider reasonable on the
recommendations of the Engineer-In-Charge. Similarly, in the event of deletion of
some items, the time for completion for the work shall be reduced in the proportion
of altered cost to the original contract sum.

4.34.1 If the work be delayed by:
(a) Force Majeure, or
(b) Serious loss or damage by fire, or
(c) Civil commotion, local combination of workmen, strike or lockout, affecting
any of the trades employed on the work, or
(d) Any other cause, which in the absolute discretion of the SMVDSB is beyond
the contractor’s control.
Then upon the happening of any such event causing delay, the contractor shall
immediately give notice thereof in writing to the SMVDSB/Engineer, but shall
nevertheless use constantly his best endeavors to prevent or make good the delay
and shall take all possible steps to the satisfaction of the ‘Engineer’ to proceed with
the works.
Request for extension of time, shall be made by the contractor in writing no later
than fourteen days of the happening of the event causing delay, the contractor may
also, if practicable, indicate in such a request, the period for which extension is
desired.
In any such case, the ‘SMVDSB’ on the recommendations of the Engineer may
give a reasonable extension of time for completion of the work, which shall be
communicated to the contractor by the Engineer. Any extension of completion
period shall not entitle the contractor to any other monetary gain or claim.
The term “Force Majeure” in the contract shall mean civil war, tidal waves, fire,
major floods, earthquake (above 7 magnitudes on Richter Scale) damage from
Aircraft, nuclear fission, riots (other than among the contractor’s employees),
lighting and other causes over which the contractor has no control and as accepted
by the SMVDSB whose decision shall be binding and final.
This will not entitle the contractor to any claims for the increase in rates / cost of
the contract.
Page 21 of 51

<!-- page 22 -->

4.35

Remedy on contractor’s failure to remove defective work: If the contractor
shall fail to carry out any such work as aforesaid required by the Engineer-InCharge SMVDSB, shall be entitled to carry out such work by his own
workmen or by other contractors and if such work which in the opinion of the
SMVDSB, the Contractor was liable to do at his own expense under the
contract, then all expenses consequent thereon or incidental thereto shall be
recoverable from the contractor by the SMVDSB and shall be deducted by the
SMVDSB from any payment due or that becomes due to the contractor or from the
bank guarantee/security deposit submitted by the contractor.

4.36

Liquidated Damages: If the contractor fails to complete the works within the
stipulated period for completion of work, the contractor will be liable to pay to the
SMVDSB as liquidated damages / penalty for delay @ 0.5% percent per week of
the unfinished work value subject to a maximum of 10% (ten percent) of the
unfinished work value.

4.37

The contractor shall be paid at contract rates full amounts for works executed at
site and in addition a reasonable amount as certified by the Engineer-In-Charge for
the items hereunder mentioned which could not be utilized on the work to the full
extent because of the foreclosure.

4.38

TERMINATION OF THE CONTRACT IN FULL OR IN PART:
(a) If the contractor:
(i) at any time makes default in proceeding with the works with due diligence
and continues to do so even 15 days after a notice in writing from the
Engineer-In-Charge; or
(ii)

Commits defaults in complying with any of the terms and conditions

(iii) of the contract and does not remedy it within 15 days after a notice in
writing is given to him in that behalf by the Engineer; or
(iv) fails to complete the works or any part of the work on or before the date
of completion and does not complete them within the period specified in
notice give in writing in that behalf by the Engineer; or
(v)

has obtained a contract with the SMVDSB as a result of ring tendering or
other non-bonafide methods of competitive tendering; or

(vi) The SMVDSB shall cancel the contract by a written notice to the
contractor and the contractor shall have no claim on any sort on this
account.
(b) The SMVDSB shall on such cancellation have powers to:
(i) Take possession of the site and any materials, constructional plants,
implements, stores, etc. thereon, and make out a list of such material in
presence of the representative of the contractor who shall have to be
present on one (01) day notice and in case of non-compliance of the
notice measurements taken by the SMVDSB rep. shall be considered as
Page 22 of 51

<!-- page 23 -->

final and contractor will have no claim of any sort regarding this.
(ii)

Carry out the incomplete work by any means at the risks and cost of the
contractor.

(iii) On termination of the contract in full or in part, the Engineer shall
determine what amount, if any, is recoverable from the contractor for
completion of the works or in case the works or part of the works not to
be completed, the loss or damage suffered by SMVDSB. In determining
this amount, credit shall be given to the contractor for the value of the
work executed by him up to the time of cancellation, the value of the
contractor’s materials taken over and incorporated in the work, and use of
machinery belonging to the contractor.
(iv) Any excess expenditure incurred or to be incurred by the SMVDSB in
completing the works or part of the works or the excess loss or damage
suffered or may be suffered by the SMVDSB as aforesaid after allowing
such credit shall be recovered from any amount due to the contractor on
any account, and if such amount is not sufficient, the contractor shall be
called upon in writing to pay the same, within 30 days of the notice given
to that effect by the ‘Engineer’.
(v)

If the contractor shall fail to pay the required sum within the aforesaid
period of 30 days, the SMVDSB shall have the right to sell any or all of
the contractor’s unused materials, constructional plant, implements,
temporary buildings; etc. and apply the proceeds of sale thereof towards
the satisfaction of any sums due from the contractor under the contract
and in accordance with the provisions thereof.

(vi) Any sums in excess of the amounts due to the SMVDSB and unsold
materials constructional plant, etc. shall be returned to the contractor,
provided always that if cost or anticipated cost of completion by the
SMVDSB, of the works is less than the amount which the contractor
would have been paid had he completed the works, such benefit shall not
accrue to the contractor.
4.39 SMVDSB to be indemnified: The contractor shall at all times indemnify the
SMVDSB against all claims, damages or compensation under the provision of
Payment of Wages Act, Minimum Wages Act, SMVDSB’s Liability Act, Industrial
Disputes Act, and the Maternity Benefit Act or any modifications thereof or any
other law relating thereto and rules made there under from time to time or as a
consequences of any accident or injury to any workmen or other persons in or
about the works whether in the employment of the contractor or not, save and
except where such accident or injury has resulted from any act of the SMVDSB
their agents or servants, and also against all costs, charges and expenses of any
suit action or proceedings arising out of such accident or injury and against all sum
or sums which may with the consent of the contractor be paid to compromise or
Page 23 of 51

<!-- page 24 -->

compound any such claim. Without limiting his obligations and liabilities as above
provided the contractor shall insure against all claims, damages or compensation
payable under the workmen’s compensation Act, 1923 or any modification thereof
or any other law relating thereto. All the aforesaid insurance policies shall provide
that they shall not be cancelled till the Engineer has agreed to their cancellation.
The contractor shall prove to the Engineer or his authorized representatives from
time to time that he has taken out all the insurance policies referred to above and
has paid the necessary premia for keeping the policies alive till the expiry of the
Defects Liability Period.
4.40

Settlement of Disputes: The instructions, decision, opinion, certificate or
evaluation of the Engineer, with respect of or any of the matter regarding which the
decision of the Engineer is stated to be as final or conclusive or binding in these
conditions of the contract or specifications or in the Bill of Quantities forming part of
the contract, shall be final conclusive and binding on the parties hereto and shall
not be subject to be appealed. Such matters hereinafter shall not be subject to be
appealed. Such matters hereinafter shall be referred to as “excepted matters”. The
decision of the “SMVDSB” in any and all matters shall be final and binding on both
the parties in the agreement.

4.41

Arbitration: Any dispute or difference whatsoever arising between the parties out
of or relating to the execution, interpretation, application, meaning, scope,
operation or effect of the contract or the validity or the breach thereof, shall be first
tried for amicable settlement through consultation / discussion between the parties.
Any unsettled disputes whatsoever arising between the parties thereof relating to
the work shall be resolved as per the provisions of Arbitration and Conciliation Act
applicable to the Jammu & Kashmir (J&K).

4.42

Jurisdiction: All legal disputes arise in connection with the Contract shall be
subject to the jurisdiction of Courts at Katra (J&K, India).

*****-----*****

Page 24 of 51

<!-- page 25 -->

SPECIAL CONDITIONS OF THE CONTRACT – SECTION-5
These special conditions will supersede the General Conditions of Contract
wherever these provisions are at variance with them.
5.1

Water & Power Supply: The contractor shall be responsible for providing within
the scope of work all facilities necessary for the performance of the work including
(but not limited to) water, electrical power, electrical power through generator,
transportation, labour tools, construction equipment and machinery, access and
right(s) of way to or about the job site(s). However, the SMVDSB may provide the
power connection at location but cost of power consumed shall be paid by
contractor. A free of cost water point shall also be provided by SMVDSB at the
location. The SMVDSB shall also provide open space for storage purposes,
wherever feasible. Any temporary structure may be built by the Contractor in the
space provided during construction.

5.2

Accommodation: During the visit of the technical experts of contractor,
accommodation shall be provided by the SMVDSB on the payment basis.
However, accommodation for day to day needs shall be temporarily constructed
by the contractor on the space provided by the shrine board for the purpose.

5.3

Amendment of Tender Document: - Before the deadline for submission of
tenders, the Tender Document may be modified by SMVDSB by issue of
addenda/corrigenda. Any addendum/corrigendum issued shall be part of the
Tender Documents and shall be uploaded in the official website of Shri Mata
Vaishno Devi Shrine Board (SMVDSB).

5.4

Scaffolding: - Suitable scaffoldings should be provided at the site where
necessary and while working at heights necessary precautions should be taken.
For this particular site rope access works with a PPE (personal protection
equipment), according to the IRATA (Industrial Rope Access Trade Association)
guidelines is necessary and an alternative to scaffolding.

5.5

Safety Equipment: - When workers are working on the rope they should have a
PPE according to the IRATA guidelines.

5.6

Plant and Equipment: - The Minimum Requirement of key Plant and Equipment to
be deployed in the Project during execution needs to be specified. The bidder shall
be required to submit the list of all his available equipment together with an
undertaking in the form of an affidavit stating that the bidder shall mobilize the all
key equipment listed above and another complete set(s) of minimum key
equipment required. In the event of contract award, of his obligation to provide
sufficient equipment to construct and complete the Works in accordance with the
Contract

Page 25 of 51

<!-- page 26 -->

5.7

Personnel - Technical Staff to be Deployed in the Project: Requirement of
Technical Staff to be deployed in the Project, the Bidder shall demonstrate the
availability of qualified key persons (details to be attached).
*****------*****

Page 26 of 51

<!-- page 27 -->

ANNEXURE- “A”
(AS PER CLAUSE 2.1 OF DETAILED TERMS & CONDITIONS OF CONTRACT - SECTION-2)

Name of the Bidder: _________________________________
S. No. Technical Documents
1.
2.

3.

4.

5.

6.

Enclosed (Yes / No)
with page number

Copy of Tender Fee & EMD as prescribed in the eNIT.
The Bidder must be Firm/Company/Proprietary ship firm
registered under appropriate authorities (attested copies of
the relevant registration certificates including certificate
of incorporation as per Clause 2.1.1 of Section 2)
The Bidders should mention their complete name, address
and core business in the tender. If the authorized person is
signing the documents he must be legally authorized
(attested copies of the relevant certificates as per
Clause 2.1.3 of Section 2)
Detail of Technical and Non-Technical manpower to be
deployed must be attached. The technical manpower should
have adequate qualification/experience in the relevant field.
The Project Manager/ Resident Engineer shall be Graduate
in Civil/Mechanical Engineering with minimum 5 years of
experience. (the details are to be attached as per the
Annexure-“B”).
The Agency shall be a profitable entity and shall not have
incurred losses in any of the last 03 consecutive financial
years (2018-19, 2019-20, 2020-21) and the firm shall have
average annual financial turnover atleast 30% of the
estimated cost of related work during the last 05 years,
ending 31st March of the previous financial year (attested
copies of Audited Balance Sheets & Profit & Loss
statement, duly certified by the Chartered Accountant,
are to be attached by the Bidder as per Clause 2.1.5)
The bidders shall have professional experience in execution
of similar work with any of the Central Govt. / State Govt. /
PSUs/Reputed Organizations. The parties uploading bidder
must have executed the similar nature of works in following
manners: (i) Atleast one work of similar nature of the value of 80% of
the estimated cost of during the last 05 years; OR
(ii) Atleast two works of similar nature of the value of 50%
of the estimated cost of during the last 05 years; OR
(iii) Atleast three works of similar nature of the value of 40%
of the estimated cost of during the last 05 years.
(Attested copies of the documentary proof including the
relevant Letter of Award(s) and Completion Certificates
including value of work done in support of the above
requisite criteria must be submitted by the tenderer, in
Page 27 of 51

<!-- page 28 -->

7.

8.

9.

absence of which the bid shall not be considered) as per
Clause 2.1.6 of Section 2).
The Bidder shall submit the detail of equipment or
components required for the construction of Ayushman
Bharat Ward. (Bidder shall also certify the acquisition of
the same i.e. owned, lease or hire etc. as per Clause
2.1.7 of Section 2)
The bidders shall have to give an undertaking to the effect
that the Firm has not been black listed / holiday listed
anytime in the past by any Country / Semi Government
Agency/PSU/State
Govt./Central
Govt./Autonomous
Bodies/MNCs etc., duly attested by Judicial / Executive
Magistrate / Notary. Each participating bidders shall have to
undertake that all document attached herewith are true and
in the event of any illegally noticed at any stage, the LOA
shall be revoked, security deposit forfeited. The remaining
work shall be got executed at the risk and cost of the firm
besides debarring it for future participation in tender process
of SMVDSB for five years. (Undertaking to be attached as
per Clause 2.1.8 of Section 2)
A Solvency Certificate from the banker of Bidder to be
submitted for credit worthiness of the firm (Certificate to be
attached as per Clause 2.1.9 of Section 2)

It is to certify that all the documents enclosed with the Annexure- “A” are complete in all
respect, self-attested, sequential and numbered.
Yours faithfully,

Authorized Signatory ______________________
Name of the Bidder ________________________
Address: _________________________________
_________________________________
Email: ___________________________________
Mobile No.: _______________________________

Page 28 of 51

<!-- page 29 -->

ANNEXURE- “B”
CERTIFICATE CONFIRMING THE AVAILABILITY OF STAFF/MANPOWER
This is to certify that I/We shall deploy the essential staff/manpower as specified in the
tender, if I/We am/are awarded the work of _________________ (name of work) as per the
details indicated below I/We agree that the staff/manpower indicated below is the minimum
essential for the project execution and in addition to these, other staff/manpower necessary to
complete the work successfully and in time, shall also be deployed by me/us.

Position

Name

Qualification

Years of Experience

Seal and Signature of the Bidder

Page 29 of 51

<!-- page 30 -->

ANNEXURE-"C"
PRICE BID - PART-I (Civil Works)
Bill of Quantities for the Construction of Ayushman Bharat Wards in the premises of
SMVDIME, Kakryal.
S.No
1

2

3

4

5

6

7

8

9

Description

Unit

Qty

Cum

47.30

Cum

63.39

Cum

19.6

Cum

35.35

providing and laying in position cement concrete
in 1:4:8 (1cement:4 Coarse Sand :8 Crushed
Stone Aggregate 40 mm nominal size) excluding
cost of centering and shuttering for all works up
to plinth level, including all leads and lifts
complete.

Cum

54.9

providing and
laying Reinforced cement
concrete (1:1:2) 1cement:1coarse sand: 2
graded stone aggregate 20mm nominal size in
walls (any thickness) including attached
pilasters, butteresses, beams, column, slab etc
upto floor five level excluding the cost of
centering shuttering, finishing and reinforcement
including all leads & lifts complete.

Cum

6.41

Qntl

7.37

Cum

162.8

Sqm

285.6

Dismantling brick work in cement/lime upto 35
cm thickness including stacking of serviceable
material and disposal of u/s material within a
lead of 100 mtrs (as directed by Engineerincharge)
Dismantling of glazed/vetrified tile up to 15 cm
thick including stacking serviceable material and
disposal of material up to 100 mtrs (as directed
by Engineer-incharge).
Dismantling of plain cement concrete more than
15 cm thick including stacking serviceable
material and disposal of material up to 100
mtrs.(as directed by Engineer-incharge)
a) Earthwork in bulk excavation in all kinds of
soil by mechanical means (hydraulic excavator)
over areas exceeding 30 cm in depth, 1.5 mts in
width as well as 10 sqm on plan including
disposal of excavated soil upto a lead of 1 km
(As directed by the Engineer-Incharge).

providing and laying reinforcement for RCC work
including straightening, cutting, bending, placing
in position and binding including cost of binding
wires and all leads & lifts complete. (upto floor
five level)
providing brick work with common burnt clay
F.P.S (non modular) bricks of class designation
75 for all floor levels and for mounty, machine
room, etc. in cement mortar 1:6 (1 Cement : 6
Coarse Sand) including all leads & lifts complete.
providing brick masonary half brick masonry with
F.P.S bricks of class designation 75 for all floor
levels including laying of RCC bands (M15) with
nominal reinforcement at every one mtr. height
of masonary in cement mortar 1:4 (1cement :4
coarse sand), including all leads & lifts complete.

Page 30 of 51

Rates to be
Quoted (Rs.)

Amount (Rs.)

<!-- page 31 -->

10

11

Providing and fixing of formwork of timber
plankings, steel plates. Plyboard sheets etc so
as to give rough finish inclduing centering,
shuttering, strutting, propping complete upto all
levels and removal & stacking of the same,
complete job.(including cost of shuttering, T&P
& Sundries.) complete in all respects.

Sqm

82.92

15 mm cement plaster in1:6 (1 cement : 6 fine
sand) on rough side of single/half brick walls
(internal plastering) including cutting grooves in
junction between RCC and brick masonary at all
floor levels including all leads & lifts complete
including cost of material.

Sqm

2162

12

Applying white cement based putty of average
thickness 2mm of approved brand and
manufacture, over the plastered wall surface
(internal & external) to prepare the surface even
and smooth complete at all floors levels
including all leads & lifts complete including cost
of material.
a) Internal Surface

Sqm

2298

13

Finishing wall with premium acrylic smooth
interior paint with silicone additives of required
shade on New work (two or more coats applied
@ 1.43 ltr/10sqm over and including base coat
of water proofing cement paint applied @
2.20kg/10sqm) at all floor levels complete. As
per the shades as directed by Engineer-incharge including cost of material.

Sqm

2298

Providing and laying glazed/polished vitrified
floor tiles in sizes of 600x600mm (or any size)
(as per required thickness) in the pattern as
approved by Engineer-Incharge laid on 20mm
thick cement mortar 1:4 (1 cement : 4 coarse
sand) including grouting the joints with white
cement and matching pigment etc. complete at
all floor levels including all leads & lifts
complete.

Sqm

1704

Sq.m

758.4

Sq.m

80.49

Sq.m

9.54

No.

6

No.

7

14

15

Providing and Fixing of gypsum board false
ceiling of papproved make of gyproc of equla
make).
1.Gypsum False Ceiling
2. Modular Grid Tile 600 MM X 600 MM- False
Ceiling
3. Calcium Siliocate Tile 600 MM X 600 MM =

B)

Plumbing & Sanitary works.

16

Providing and fixing WC cum Bathroom
fitting
complete
including
laying
of
PVC/CPVC/PPR/CI/ GI/Composite Pipes and
fittings inside the periphery of Toilet, fitting of
taps, washbasin, washbasin mixer, European
seat cistern, shower, towel rail,towel ring, looking
glass, glass shelf and soap dish, geyser,
gratings, angle valve etc and testing of the
system complete.
Proving and Fixing Bathroom fitting complete
including laying of C.I/P.V.C and G.I/PPR pipes
and fitting inside the periphery of bathroom fitting
of tap, towel rail and grating and testing of the
system complete.

17

Page 31 of 51

<!-- page 32 -->

18

19

20

21
22
23

24

25

Providing and fixing Salem stainless steel A ISI
304(18/8) Kitchen sink as per I.S. 13983 with
C.I. brackets and stainless steel plug 40mm incl.
Pvc flexible waste pipe, waste fittings, C.P. brass
coupling and C.P. Brass grating with hole of
required dia incl. Painting of fittings and
brackets, cutting and making good the walls
wherever required.
Kitchen sink without drainboard 610x460 mm
bowl depth 200 mm

No.

4

Providing and
fixing 3 layer PP-R (Poly
propylene Random copolymer) popes SDR 7.4
UV stablized and anti-microbial fusion welded,
having thermal stability for hot and cold water
supply including all PP-R plain and brass
threaded Polypropylene random fittings I/C fixing
the pipe with clamps at 1.00m spacing. This
includes cost of cutting chases and making good
the same including testing of joints complete as
per direction of Engineer-in-charge (concealed
work including cutting chases and making good
the walls etc) and External Work.
PN-16 pipe, 25mm OD

RM

55

PN-16 pipe, 40mm OD

RM

60

PN-16 pipe, 50mm OD

RM

110

PN-16 pipe, 75mm OD

RM

40

No.

20

No.

6

No.

6

No.

4

Providing and fixing C.P. brass angle valve for
basin mixer and geyser points of approved
quality conforming to IS:8931 a) 15 mm nominal
bore.
Providing and fixing of C.P. Brass soap dish of
approved quality with ISI mark.
Providing and fixing of C.P. brass Towel ring of
medium size.
Providing and fixing, testing & commissioning of
C.P. brass wall mounted sink mixer with C.P.
wall flange, overhead swinging spout complete
as required and making good all necessary wall
cutting / chasing complete as per direction of
Engineer in Charge.
Providing and fixing, Testing & Commissioning
of full way lever operated PPR Ball Valves
tested to a high pressure rating (at all floors).
25mm OD

No.

10

40mm OD

No

8

50 mm OD

No

6

Providing and fixing on surface/ wall face
UPVC rain and sewer pipes conforming to IS:
Type A including jointing with leaving 10 mm gap
for thermal expansion (i) single socketed pipes
along with all required fittings like tees, bends,
crosses with or without access doors jointed with
approved solvent cement as per manufacturer's
recommendations, fixed to walls and ceilings
with clamps complete including cutting and
making good the walls and ceilings where
required complete asper direction of Engineer in
Charge.
110 mm outer dia ( 6 KG PRESSURE/ cm2)

RMT

80

Page 32 of 51

<!-- page 33 -->

26

27

28

29

30

31
32

33

34

Providing and fixing on surface/ wall face UPVC
rain and sewer pipes conforming to IS: Type A
including jointing with leaving 10 mm gap for
thermal expansion (i) single socketed pipes
along with all required fittings like tees, bends,
crosses with or without access doors jointed with
approved solvent cement as per manufacturer's
recommendations, fixed to walls and ceilings
with clamps complete including cutting and
making good the walls and ceilings where
required complete asper direction of Engineer in
Charge.
200 mm outer dia ( 6 KG PRESSURE/ cm2)

RMT

70

Providing and fixing, jointing and testing of
UPVC NANI Traps formed out of bore 'P' trap
with 50 mm water seal, setting in 1:2:4 mix
cement concrete block or clamping to the wall or
suspending with the ceiling including cutting and
making good the walls and floors wherever
required.
110 mm inlet and 110 mm outlet.

No.

12

110 mm inlet and 110 mm outlet.

No.

15

Making of Main holes of different sizes including
brickwork, plaster, fixing of covers, making of
gola complete job including floating cost of neat
cement up to septic tank.

No.

15

Earthwork excavation is trenches for foundation
of pipes cables etc. not exceeding 1.5 m in
width and for shafts, wells, cesspits and the like
exceeding 10 m2 on plain including dressing the
sides and ramming of bottoms, lifts up to 1.5
mtr. including getting out the excavated soil and
disposal of surplus excavated soil as directed
within lead o 50 mtr.

cum

38

Refilling of the excavated earth in trenches,
plinth sides of foundation etc .

cum

30

Providing and laying in position cement concrete
in 1:4:8 (1cement:4 Coarse Sand :8 Crushed
Stone Aggregate 40 mm nominal size) excluding
cost of centering and shuttering for all works up
to plinth level, including all leads and lifts
complete.

Cum

15

Sqm

140

Sft

104

Providing and fixing, jointing and testing of
UPVC Bend
setting in 1:2:4 mix cement
concrete block or clamping to the wall or
suspending with the ceiling including cutting and
making good the walls and floors wherever
required (at all floors).

Providing and laying plain cement concrete
flooring 40 mm thick in 1:2:4 mix (1 cement:2
Coarse Sand: 4 Crushed Stone Aggregate 20
mm nominal size) without a floating coat of neat
cement slurry at all floor levels including all
leads & lifts complete.
Providing and fixing of form work of Timber
Planking steel plates etc. including centering
shuttering strutting and propping etc upto floor
two level and incl. removing of the same.

Page 33 of 51

<!-- page 34 -->

35

Making of Khuddas for the insertion of PVC
pipes through the brick work, PCC, RCC and
repairing the same.
Total (Part-I):-

No.

12

I further affirm that I have read and fully understood the eNIT Document and agree to abide by all the terms
and conditions laid herein, which are being signed in token of my acceptance. In case, I fail to abide by the
conditions or to complete the contract to the entire satisfaction of the Shrine Board, I will be liable to the
penalties mentioned in the terms and conditions.

Yours faithfully,

Authorized Signatory ______________________
Name of the Bidder ________________________
Address: _________________________________
_________________________________
Email: ___________________________________
Mobile No.: _______________________________

Page 34 of 51

<!-- page 35 -->

ANNEXURE-"D"
PRICE BID - PART-II (Aluminium Works)
NAME
OF
WORK

BOQ FOR PROVIDING AND FIXING OF ALUMINIUM/WOODEN DOORS AND WINDOWS FOR
AYUSHMANN BHARAT EMPANEL WARDS AT SMVDNSH , KAKRYAL KATRA

S.NO.

ITEM

UNITS

NOS.

LENGTH

BREADTH

QTY

1

ALUMINIUM TRACK
125 X 40 MM AND
FRAME SECTION OF
30 X 50 MM SIZE ,
POWDER
COATED
WINDOWS
WITH
6MM THICK GLASS
W1

SQM

3

1.5

1.2

5.4

V1

SQM

4

1.5

0.9

5.4

TOTAL AMOUNT = (1)=
2

10.8

ALUMINIUM
FIXED
POWDER
COATED
WINDOWS 50 X 63.5
MM
WITH
6MM
THICK GLASS
FW

SQM

10

1.5

1.2

TOTAL AMOUNT = (2)=
3

18

SAAL WOOD DOOR
FRAME/CHOWKHAT
62.5 X 125 MM WITH
PAINT
FD (FIRE DOOR)

RM

2

5.4

10.8

D1

RM

5

6

30

D2

RM

1

5.7

5.7

D3

RM

6

5.55

33.3

D4

RM

1

5.33

5.33

D4a

RM

1

5.4

5.4

D5

RM

8

5.2

41.6

D5a

RM

2

5.2

10.4

D5b

RM

5

5.2

26

D6

RM

10

5

50

TOTAL AMOUNT = (3)=
4

18

WOODEN
FLUSH
DOOR 34MM THICK
WITH
APPROVED
LAMINATE
FINISH
ON BOTH SIDES
WITH
(GLASS
VISION
PANNEL
350MM X 750MM OF
6MM
THICK)
ON
OPENABLE DOORS
AND (FIRE RATED
GLASS
ON
FIRE
DOORS)
Page 35 of 51

218.53

RATE
(Rs.)

AMOUNT
(Rs.)

<!-- page 36 -->

4.a

FD (FIRE DOOR)

SQM

2

1.2

2.1

TOTAL AMOUNT = (4.a)=
4.b

5.04

D1

SQM

5

1.8

2.1

18.9

D2

SQM

1

1.5

2.1

3.15

D3

SQM

6

1.35

2.1

17.01

D4

SQM

1

1.13

2.1

2.373

D4a

SQM

1

1.2

2.1

2.52

D5

SQM

8

1

2.1

16.8

D5a

SQM

2

1

2.1

4.2

D5b

SQM

5

1

2.1

10.5

D6

SQM

10

0.8

2.1

16.8

TOTAL AMOUNT = (4.b)=
5

5.04

92.253

WOODEN BEEDING
30 X 8 MM ON DOOR
FRAME/CHOWKHAT
TO COVER JOINTS
BETEEN THE FRAME
AND WALL
FD (FIRE DOOR)

RM

2

5.4

10.8

D1

RM

5

6

30

D2

RM

1

5.7

5.7

D3

RM

6

5.55

33.3

D4

RM

1

5.33

5.33

D4a

RM

1

5.4

5.4

D5

RM

8

5.2

41.6

D5a

RM

2

5.2

10.4

D5b

RM

5

5.2

26

D6

RM

10

5

50

TOTAL AMOUNT=(5)=

218.53

6
a)

HARDWARE
HANDLE/BAR

UNIT
PAIR

NOS.
51

PCS.
106

QTY
51

b)

PCS

41

41

41

c)

LOCK(DEADLATCH
LOCK)
DOOR CLOSER

PCS

51

53

53

d)

HINGES

PCS

204

204

204

e)

PCS

10

10

10

f)

KICK PLATE (D1
ONLY)
DOOR STOPPER

PCS

34

36

36

g)

TOWER BOLT

PCS

53

51

53

h)

DORMA BB4330 SS
BALL BEARING BUT
HINGE 100 X 75 X
3MM(FOR
FIRE
DOOR)

PCS

8

8

8

i)

PUSH
BAR
(FOR
FIRE DOOR)
DORMA CLOSER TS
68 WITH STANDARD
ARM SILVER FINISH
(FOR FIRE DOOR)

PCS

2

2

2

PCS

2

2

2

j)

Page 36 of 51

RATE

AMOUNT

<!-- page 37 -->

k)

l)

SCHOTT
FIRE
RATED
CLEAR
GLASS W200 X H300
(FOR FIRE DOOR)
GUARDIAN SS 304
GRADE
PULL
HANDLE ph1250 CTC
250 19MM DIA BLACK
(FOR FIRE DOOR)

PCS

2

2

2

PCS

2

2

2

TOTAL AMOUNT OF HARDWARE= (6)=
Total (Part-II):
I further affirm that I have read and fully understood the eNIT Document and agree to abide by all the terms
and conditions laid herein, which are being signed in token of my acceptance. In case, I fail to abide by the
conditions or to complete the contract to the entire satisfaction of the Shrine Board, I will be liable to the
penalties mentioned in the terms and conditions.

Yours faithfully,

Authorized Signatory ______________________
Name of the Bidder ________________________
Address: _________________________________
_________________________________
Email: ___________________________________
Mobile No.: _______________________________

Page 37 of 51

<!-- page 38 -->

ANNEXURE-"E"
PRICE BID - PART-III (Electrification Works)
Advertised BOQ for Electrification of Ayushman Bharat Ward at SMVDNSH, Kakryal
S.No.
Part-A
A
A1

Description

Unit.

Supply, installation, testing and
commissioning
M.V.DISTRIBUTION BOARDS
Supply, installation, testing and commissioning of
M. V. Distribution Boards suitable for 415V, 3
phase, 4 wire, 50Hz distribution system. The
panel shall be free standing, floor mounting, sheet
metal enclosed, flush front with aluminium
busbars, separate earth bus shall be provided
throughout the length of the panel. The incoming
and the outgoing feeder breakers, switch fuse
units, change over switches, indicating lamps,
meters etc. shall be accommodated in a modular
multitier arrangement. A minimum of 400mm
clearance shall be given from the floor level to the
bottom most termination point. The painting shall
be done inconformity with IS code.
Adequate size cable alley shall be provided all
round the panel and at the back for easy bending
and terminations. The outgoing feeders inside the
panel shall be connected through solid busbars.
Flexible cable links are not acceptable. Busbars
shall be provided with PVC heat shrinkable
sleeves or heat resistant insulated paint. The
panels shall be suitable for cable entry from
top/bottom. The copper earth strip of adequate
size in 2runs shall run throughout the perimeter of
the bottom of the panel. The panel shall be
fabricated only after the approval of fabrication
drawings by the consultant. All indoor panels
should be of IP42 and all outdoor panels should
be of IP55 protection and with lockable
arrangement. The rates include all civil works like
foundation, grouting etc.,
Fabrication of panels: The shell of the enclosure
shall be of 12 SWG CRCA sheet for outdoor
panels & 14 SWG CRCA sheet for indoor type
panels and internal compartments / barriers of 16
SWG CRCA sheet, MS supports are to be
provided to suit the mounting of switchgear and
components. The enclosure for outdoor panels
shall be duly painted with 2 coats of primer with 2
coats of enamel spray paint. The enclosure for
indoor panels shall be duly painted with 2 coats of
powder coating of a required shade.
1. The Panel shall be fully as per the requirement
of CEIG /EB
2. Auxiliary contactor to be provided along with
auto-manual switch where ever required.
3. All Breakers both Incoming & Outgoing shall
have LED 'ON / OFF / TRIP' indications
without fail.
4. CTs shall be with dual ratio and cast resin type
only.
5. For Capacitors earthing shall be provided.
6. Circuit Breakers shall confirm IS 13947-2/IEC
947-2
Page 38 of 51

Qty.

Rate
(Rs.)

Amount
(Rs.)

<!-- page 39 -->

7. All doors to have double rubber gasket with
shutter assembly & door seating frame.
8. All AC feeders will have time delays of 0-60
Seconds with timers.
9. The current density for AL busbars shall be 0.8
only.
10. The current density for CU busbars shall be
1.25 only.
11. All UPS outgoing panels shall have neutral
busbars double the size of phase.
12. TP means three pole
13. TPN means 4 pole breaker with 50% neutral
14. 4P means Four Pole breaker with 100%
neutral
15. Unless specified as 3.5 pole breaker, 4 pole
means 4 pole ONLY.
16. All breakers to have breaker manufacturer's
factory made Spreaders.
17. All breakers to have breaker manufacturer's
factory made Separators.
18. In any case Aluminium bus bars should not be
connected directly to the breaker without
spreaders.
19. The control wiring has to be in Troughs of
appropriate
size
20. Irrespective of the Capacity all breakers shall
be connected to the breakers using Bus bars
only. Cables of any make will never be accepted.
21. All vertical bus bars in bus bar alley shall have
bottom supports.
22. Panel earthing strip should come out vertically
on top or bottom of the panel depending on the
cable entry.
23. Earthing bus shall be coated to give a look of
tin.
24. Door earthings shall be provided for all doors.
25. Base frame shall be with each panel. The size
will be equal to each section.
26. Bi-metallic tape / washers to be used where
ever copper & Aluminium are joined.
27. All test certificates must be provided
immediately after commissioning.
28. SAFETY CERTIFICATE FOR THE PANELS
SHALL BE PRODUCED FROM CEIG.
29. Approval shall be taken for all panel including
interlocking schemes proposed before fabrication.
30. Gland earthing to be considered for all Cable
terminations.
31. Transparent Acrylic sheets to be used for
panel safety coverings
Please refer SLD for panel details
1

Change over panel
Indoor type - IP55
Incoming: Cable
Outgoing: Cable
Cable Entry: Bottom
Page 39 of 51

<!-- page 40 -->

Cable Exit: Bottom
Panel comprises of
a

One (1) - Incoming feeder having

2

One (1) - 125Amps, 4P, Automatic change over
switch
One (1) - 125A, TP+NL, 25kA, MCCB with
overload, short circuit and earth leakage
protection, with accessories as required. (Thermal
based Release)
Block Main Panel
Indoor type - IP43
Incoming: Cable
Outgoing: Cable
Cable Entry: Top
Cable Exit: Top
Panel comprises of

2.1

Incoming feeders

a

One (1) - Incoming feeder having for EB side
One (1) - 125A, 4P, 25kA, MCCB with overload,
short circuit and earth leakage protection, with
accessories as required. (Thermal based
Release)
One (1) No. CBCT earth leakage relay(1-8A)
One(1) -set phase indicating lamps with MCB /
fuses
One(1) -set ON/OFF/TRIP indicating lamps with
fuses.
Three (3) – 150/5A,10VA, Cl 1.0 CTs for MFM
(Multi-function Meter)
One(1) - Digital multi-function meter capable of
reading kVA, kW, kWh, power factor, voltage and
Amp rating.
Three (3) – 150/5A,10VA, Cl 1.0 CTs for APFCR
One (1) - APFCR relay

2.2

One(1) - Surge Protection Device with fuses or
MCB's and wirings.
One (1) - Set 3 phase, 4wire, 50Hz, 415V, 125A,
25kA, Aluminium bus bars and Neutral Link for all
outgoings.
Outgoing feeders

a

Four (4) - outgoing feeders each having

b

One (1) – 63A, 4P, 10kA, MCB ('D'-curve)
b

Eight (8) - outgoing feeders each having
One (1) – 40A, 4P, 10kA, MCB ('D'-curve)

c

Five (5) - outgoing feeders each having
One (1) – 25A, 4P, 10kA, MCB ('D'-curve)

d

Two (2) - outgoing feeder having
One (1) – 40A, DP, 10kA, MCB ('D'-curve)

e

Two (2) - outgoing feeder having
One (1) – 25A, 4P, 10kA, MCB ('C/D'-curve)

f

One (1) - outgoing feeder having
One (1) – 40A, 4P, 10kA, MCB ('C/D'-curve)
One (1) - 24x7 Timer with contactor for street
lighting
Page 40 of 51

<!-- page 41 -->

g

One (1) - Outgoing feeder having

i)

One (1) - sub incomer of
One (1) - 63A, 4P, 10kA, MCCB with overload,
short circuit and earth leakage protection, with
accessories as required. (Thermal based
Release)
Three (3) – 75/5A,10VA, Cl 1.0 CTs for Ammeter

ii)

One(1) - 0-75A Ammeter with selector switch and
other accessories
One (1) - sub busbar
63A, TP, 10kA, Al Busbar

iii)

Three (3) - outgoing feeders each having
One (1) - 32A, TP, 10kA, 'C'-curve MCB

iv)

One (1) - 32A, TP contactor, capacitor switching
duty, coil voltage 1ph, 240V, 50Hz.
One (1) - 5kVAr capacitor with internal wiring and
protective devices.
Two (2) - outgoing feeders each having
One (1) - 25A, TP, 10kA, 'C'-curve MCB
One (1) - 25A, TP contactor, capacitor switching
duty, coil voltage 1ph, 240V, 50Hz.
One (1) - 3kVAr capacitor with internal wiring and
protective devices.
Panel as above

3

NO

1

NO

2

Lift Panel
Indoor type - IP43
Incoming: Cable
Outgoing: Cable
Cable Entry: Top
Cable Exit: Top
Panel comprises of

3.1

Incoming feeders

a

One (1) - Incoming feeder having
One (1) – 40A, 4P, 10kA, MCB ('D'-curve)
One(1) -set phase indicating lamps with MCB

3.2

Outgoing feeders

a

One (1) - outgoing feeder having
One (1) – 25A, 4P,10kA, MCB, 'D'-Curve
One (1) – 25A, 4P, 200mA, ELCB

b

Two (2) - outgoing feeders each having
One (1) – 25A, DP,10kA, MCB, 'D'-Curve

b

One (1) - outgoing feeder having
One (1) – 25A, DP,10kA, MCB, 'D'-Curve with
metal clod socket
Panel as above

A2

DISTRIBUTION BOARDS
Supply, installation, testing and commissioning of
500V distribution Boards (single/double door
type) as per the following specification.
i) Copper busbar together with tapped neutral bar
for individual phases
ii) Copper earth strip with tapping for EEC
Page 41 of 51

<!-- page 42 -->

iii) Busbar mounting MCB's individually lockable in
off position
iv) Interconnections and earthing

4

v) Sheet steel enclosure(self-extinguishing with
non toxity & non-opaque smoke - V0 deg) suitable
for recessed or surface mounting with lockable
doors.
vi) Phase to Phase barriers in case of 3 Phase
Boards
vii)Necessary support frame & painting, labelling,
phase indicating lamps with fuses etc.
viii)The Switching material should be fully Metallic
with trip free mechanism & the metal part should
be galvanic coating.
ix)Required Al trunking from the ceiling to the DB
to carry R,Y,B Phase wires individually as
required in a open able trunking.
x) All SPN SB's should be single door and all TPN
DB's should be double door
7-segment TPN DB's
6-WAY TPN DB As per SLD
DB comprises:

a

Incomer having
One (1) – 40A, 4P,10kA, MCB - 'C'-Curve

b

Three (3) - Sub incoming feeders each having
One (1) – 32A, DP, 100mA, ELCB

c

Eighteen (18) - Outgoing feeders each having
One (1) – 10/20A, SP, 10kA, MCB - 'C'-Curve
DB as above

5

NO

1

NO

1

NO

1

7-segment TPN DB's
8-WAY TPN DB As per SLD
DB comprises:

a

Incomer having
One (1) – 40A, 4P,10kA, MCB - 'C'-Curve

b

Three (3) - Sub incoming feeders each having
One (1) – 32A, DP, 100mA, ELCB

c

Twenty Four (24) - Outgoing feeders each having
One (1) – 10/20A, SP, 10kA, MCB - 'C'-Curve
DB as above

6

7-segment TPN DB's
12-WAY TPN DB As per SLD
DB comprises:

a

Incomer having
One (1) – 63A, 4P,10kA, MCB - 'D'-Curve

b

Three (3) - Sub incoming feeders each having
One (1) – 40A, DP, 100mA, ELCB

c

Thirty six (36) - Outgoing feeders each having
One (1) – 10/20A, SP, 10kA, MCB - 'C'-Curve
DB as above

7

VTPN (Vertical TPN MCB) DB's
12-WAY VTPN DB As per SLD
DB comprises:
Page 42 of 51

<!-- page 43 -->

a

Incomer having
One (1) – 63A, 4P,10kA, MCB - 'C'-Curve

b

Ten (10) - Outgoing feeders each having
One (1) – 20/25/32A, TP, 10kA, MCB - 'C'-Curve

c

Six (6) - Outgoing feeders each having
One (1) – 20/25/32A, SP, 10kA, MCB - 'C'-Curve
DB as above

A3

NO

1

No

1

No

6

ISOLATORS
Design,
supply,
installation,
testing
and
commissioning of following, MCB/MCCB isolator
box, wall mounted (surface) as per drawings and
specifications and as required with metal
enclosure. The metal box shall be of sheet steel
enclosure suitable for single phase or three phase
MCBs/MCCBs. All wires inside shall be
terminated using copper end terminations. All
isolator box shall be IP43 protected for indoor
applications and IP%^ for outdoor applications.
63A, 4P, 10kA, MCB ('D'-curve) in a metal
enclosure (IP-56)
16A/20A/25A/32A, 4P, 10kA, MCB ('D'-curve) in a
metal enclosure (IP-43)

Total =
B
1

3.1

EARTHING SYSTEM
Supply, installation, testing and commissioning of
GI Pipe in Pipe earthing as per IS 3043-1987 with
80mm dia-Outer pipe and 40mm dia-Inner pipe,
pipe electrode (length 3M) made out of mild steel
tubes and hot dip galvanized with 100 micron
coating outside and 300micron coating inside
filled with high conductive and corrosion resistant
crystalline mixture. The earth pit shall be filled
with backfilled compound (having good enhancing
material) as per standard practices and
specifications.
(Maintenance free copper
earthing)
Supply, installation, testing and commissioning of
Cu Pipe in Pipe Chemical earthing as per IS 3043
with 50mm Dia Outer Pipe, and 30mm Dia Inner
Pipe, both of thickness 2mm, 3M length
Electrolytic Copper Earthing Electrodes. The
earth pit shall be filled with sufficient quantity Ultra
High conductive backfill compound with
necessary accessories like lockable Pit cover and
Copper inspection plate etc, complete as required
as per standard practices and specifications.
(Maintenance free copper earthing)
Providing and laying earthing conductors of GI
strip/wire including necessary accessories,
clamping to walls, cables etc. as required and
interconnection between lengths
as per
specifications and as per good installation
practice. The rate shall include all supports,
accessories and hardware necessary for proper
installation.
25 x 6mm G.I strip.

3.2

25 x 3mm G.I strip.

2

3

Page 43 of 51

No

10

No

1

Rm

200

Rm

250

<!-- page 44 -->

4

4.1

Providing and laying earthing conductors of
copper
strip/wire
including
necessary
accessories, clamping to walls, cables etc. as
required and interconnection between lengths as
per specifications and as per good installation
practice. The rate shall include all supports,
accessories and hardware necessary for proper
installation.
8SWG PVC insulated Cu Wire

Rm

200

4.2

10SWG PVC insulated Cu Wire

Rm

200
Total =

C
1

1.1

M.V.CABLES
Supply, laying, testing and commissioning of
heavy duty power cable of 1100V grade XLPE
cable having Aluminium conductor, extruded
Flame retardant PVC outer sheathing steel
wire/tape armoured / unarmoured indoor or
outdoor. The cables shall be laid in concrete
trenches or buried directly underground or on
cable trays. The concrete trenches will be
measured separate. The cost of the cable trays or
ladders, excavation and back filling of trenches
will be measured separate. the unit cost of the
cable shall include clamps, fasteners etc. as
required for proper installation.
3 1/2C x 150 sq. mm, Al. Ar. XLPE Cable

Rm

350

1.2

3 1/2C x 95 sq. mm, Al. Ar. XLPE Cable

Rm

30

1.3

4C x 16 sq. mm, Al. Ar. XLPE Cable

Rm

50

1.4

4C x 10 sq. mm, Al. Ar. XLPE Cable

Rm

180

2

2.1

Providing & Install cable terminations for the
above cables including single / double
compression type chrome plated brass glands
and lugs (crimping type), PVC taping as required
and all accessories complete. (Upto 50sq.mm
single compression & above 50sq.mm double
compression Glands)
3 1/2C x 150 sq. mm, Al. Ar. XLPE Cable

No.

8

2.2

3 1/2C x 95 sq. mm, Al. Ar. XLPE Cable

No.

6

2.3

4C x 16 sq. mm,Al. Ar. XLPE Cable

No.

8

2.4

4C x 10 sq. mm, Al. Ar. XLPE Cable

No.

10

3

3.1

Supply, laying, testing and commissioning of
heavy duty power cable of 1100V grade XLPE
cable having Copper conductor, extruded Flame
retardant PVC outer sheathing steel wire/tape
armoured / unarmoured indoor or outdoor. The
cables shall be laid in concrete trenches or buried
directly underground or on cable trays. The
concrete trenches will be measured separate. The
cost of the cable trays or ladders, excavation and
back filling of trenches will be measured separate.
the unit cost of the cable shall include clamps,
fasteners etc. as required for proper installation.
4C x 10 sq. mm, Cu. Ar. XLPE Cable

Rm

120

3.2

4C x 4 sq. mm, Cu. Ar. XLPE Cable

Rm

200

3.3

3C x 6 sq. mm, Cu. Cable

Rm

160

3.4

3C x 4 sq. mm, Cu. Cable

Rm

160

Page 44 of 51

<!-- page 45 -->

4

4.1

Providing & Install cable terminations for the
above cables including single / double
compression type chrome plated brass glands
and lugs (crimping type), PVC taping as required
and all accessories complete. (Upto 50sq.mm
single compression & above 50sq.m
4C x 10 sq. mm, Cu. Ar. XLPE Cable

No.

6

4.2

4C x 4 sq. mm, Cu. Ar. XLPE Cable

No.

16

4.3

3C x 6 sq .mm, Cu. Cable

No.

6

4.4

3C x 4 sq. mm, Cu. Cable

No.

6

5

Supply, and installation of Perforated type powder
coated with approved colour from architect cable
trays with all its necessary accessories and
supporting frames etc, complete as required as
per site condition. Rate includes the 2Runs 25x3
GI Flat along this.
200mm wide tray(with 25x6mm MS angle &
20x4mm MS flats)
300mm wide tray(with 25x6mm MS angle &
20x4mm MS flats)
Supplying and fixing raceways of following sizes
made of 1.6 mm thick Pregalvanised sheet
complete with cover. The race way will be fixed to
wall / ceiling/columns/floor with necessary
interconnections, GI hardware to make the
installation complete, including minor civil works,
including mounting clamps. (Floor Raceway)
150 x 40mm Single Compartment Raceway

Rm

20

Rm

20

Mtrs.

10

7.1

Supplying and fixing raceways of following sizes
made of 2 mm thick PVC raceway complete with
cover. The race way will be fixed to wall /
ceiling/columns/floor
with
necessary
interconnections, all hardware to make the
installation complete, including minor civil works,
including mounting clamps.
150 x 40mm Single Compartment Raceway

Mtrs.

10

7.2

100 x 40mm Single Compartment Raceway

Mtrs.

10

7.3

50 x 40mm Single Compartment Raceway

Mtrs.

10

8

Supply & Installation of MS Flat supports with 2
coats of red oxide primer and 2 coats of paint of
approved colour and with all necessary
accessories as per site.

kg

80

5.1
5.2
6

6.1
7

Total =
D
1

WIRING SYSTEM (ALL WIRES SHOULD BE
FRLS &CONDUITS SHOULD BE FRLS)
POINT WIRING
Provide all materials, accessories, labour etc. for
wiring for lights, ceiling fans, exhaust fans, 6A
sockets (where 6A sockets are connected to the
lighting circuit) using 1.5sqmm PVC insulated
stranded copper conductor FRLS wires of 650V
grade drawn through 2mm thick FRLS PVC
including supply and laying of conduits and its
accessories concealed in the slab/wall, surface
mounted/ above false ceiling using PVC
pull/junction boxes, light outlet boxes, G.I.Switch
outlet boxes, switch plates, 6A/16A one or two
way switches, 6A switched socket etc., including
testing and commissioning complete. The rate for
point wiring shall include wiring from first
switch point and then looping between the
Page 45 of 51

<!-- page 46 -->

1.1
1.2
1.3
1.4
1.5

1.6

1.7

1.8

1.9

2

2.1
3
4

points and switches. The rate shall also include
the cost of providing 1no. 1.5sqmm PVC insulated
copper conductor FRLS wire(earth wire) to
connect all lights, switches sockets etc.
(3Rx2.5Sq.mm Cu wires) (Front plate should be
white colour for Raw Power and black colour
for UPS)
One (1) light point controlled by a 6A modular
type switch
One (1) light point controlled by two(2) no. 2 Way
6A modular type switches
Set of two (2) light points controlled by a 6A
modular type switch
Set of three (3) light points controlled by a 6A
modular type switch
Wiring for 6A socket outlet connected to lighting
circuit and providing 6A shuttered type five pin
socket outlet with switch, G.I box etc. (Dependent
point where the socket is within 1metre from
any other control switch/switches)
Wiring for 6A socket outlet connected to lighting /
power circuit and providing 6A shuttered type five
pin socket outlet with switch, G.I box etc.
(Independent socket)
Wiring for 2Nos 6A socket outlet connected to
lighting / power circuit and providing 2nos 6A
shuttered type five pin socket outlet with separate
switches, G.I box etc.
Wiring for 6A socket outlet connected to lighting /
power circuit and providing 6A shuttered type five
pin socket outlet with switch, G.I box etc. Switch &
sockets are at different location FOR EXHAUST
FAN & WALL FAN ALSO
Ceiling fan point controlled by a 6A Modular key
type switch. The rate shall include providing a
2module stepped electronic fan regulator, G.I.box,
fan hook etc.
LIGHTING CIRCUIT MAIN
Providing all materials, accessories and labour for
wiring with conduits and accessories for light / fan
circuit main using FRLS PVC insulated stranded
copper conductor wires of 650V grade drawn
through 2mm thick FRLS PVC conduit using
necessary conduit accessories, G.I fish wire etc.
The rate shall include the cost of providing PVC
insulated stranded copper conductor FRLS earth
wire in each conduit along with other circuit main
wires.
2 x 2.5sqmm + 1 x 1.5sqmm(earth) wires in
20mm dia 2mm thick FRLS PVC conduit
POINT WIRING WITH MS CONDUIT (SURFACE
MOUNTED INSIDE THE LIFT SHAFT)
POWER CIRCUIT MAIN
Providing all materials, accessories and labour for
wiring with 2mm thick FRLS PVC conduit and
accessories for wiring 6A sockets, 6/16A sockets,
16/20A sockets single phase sockets using PVC
insulated stranded copper conductor FRLS wires
of 650V grade drawn through heavy gauge rigid
PVC
conduit
using
necessary
conduit
accessories, PVC pull / junction boxes, G.I fish
wire etc. The wiring cost shall include cost of
wires, conduit and its accessories and FRLS
Page 46 of 51

No

150

No

13

No

4

No

2

No

10

No

10

No

10

No

2

No

60

Rm

900

<!-- page 47 -->

4.1
5
5.1

5.2

5.3

earth wire. (The G.I outlet box and the socket will
be measured separate).
2 x 4.0sqmm + 1x 2.5sqmm (earth) wires in
25mm dia 2mm thick FRLS PVC conduit.
POWER RECEPTACLES
Supply and installation of 6/16A, 5pin,
combination type shuttered switched socket outlet
with indicator lamp and G.I outlet box and
moulded plastic cover plate as required including
termination of wires.
Supply and installation of 6/16A, 5pin,
combination type shuttered switched socket outlet
with indicator lamp and G.I outlet box and
moulded plastic cover plate as required including
termination of wires. Sockets & switches are at
different location for AC and Geyser.
Supply and installation of 2Nos of 6/16A, 5pin,
combination type shuttered switched socket outlet
with indicator lamp and G.I outlet box and
moulded plastic cover plate as required including
termination of wires

Rm

2100

No

40

No

12

No

130

Total =
E
1

1.2
1.3
1.4
2

3

3.1

TELEPHONE SYSTEM
Supply and laying of 2mm thick FRLS PVC
conduit with all necessary accessories like bends,
collars, junction boxes, pull boxes, fish wire
concealed /Surface mounting complete as
required.,
32mm dia conduit
25mm dia conduit
20mm dia conduit
Supply and Installation of telephone socket outlet
points (RJ11 jack) with MS box, plate concealed
etc., all complete as required.
Supply and laying of outdoor multiplier 0.51mm
dia annealed copper conductor of armoured PVC
insulated and jelly filled telephone wires in the
existing
pipe/conduits etc., all complete as
required.
10 Pair cable

Rmt.
Rmt.
Rmt.
Nos.

200
250
150
18

Rmt.

20

4

Supply and laying of indoors multiplier 0.51mm
dia annealed copper conductor of unarmoured
PVC insulated a telephone wires in the existing
raceways/conduits/ etc., all complete as required.

4.1
4.2
4.3
5

Rmt.
Rmt.
Rmt.

10
20
600

5.1

20 Pair cable
10 Pair cable
2 Pair cable
Supply and installation of Telephone tag block
(TJB) with KRONE terminal connectors, G.I.J.B
as
specified
and
complete
with
all
interconnections
and
jumper
connections
between the
two Tag blocks on all floors
complete as required.,
20Pair TJB

Nos.

1

5.2

10Pair TJB

Nos.

1

F
1

T.V. SYSTEM
Supply and laying of RG 11U tined copper coaxial cable with polythene insulation and overall
PVC sheathed from various splitters to various
tap offs in the existing raceway/conduits etc., all

Total =

Page 47 of 51

Rmt.

100

<!-- page 48 -->

complete as required. Rate including splitter
boxes.

2

3

Supply and laying of RG 6U tined copper co-axial
cable with polythene insulation and overall PVC
sheathed from antenna to control room and from
control room to various floors splitter boxes in the
existing pipe/conduits etc., all complete as
required. Rate including splitter boxes.
Supply and Installation of TV socket outlet with
interconnection of outlet. The cover plate of TV
antenna socket outlet in a suitable box.

Rmt.

100

Nos

6

Total =
G

NETWORK AND CCTV SYSTEMS

1

Supply and installation of data socket (RJ 45)
outlet points with MS box, plate concealed etc., all
complete as required.
Supply, Laying and testing, of the network cable
confirming to TIA/EIA standards, in the existing
conduit/raceways, rate shall include
all the
required items complete as required .,
CAT 6 cable (quantity considered for CCTV, wifi,
Data outlets and Nurse call system)
Supply and installation of 48 port Jack Panel with
fully loaded - AMP
Supply installation and termination of 12U racks
with all complete accessories
Supply installation and termination of 6U racks
with all complete accessories
Supply and installation of EPABX suitable for 5incoming and 20-outgoing and expandable
provision in future and the rate includes all
accessories hardware and software.

2

3
4
5
6

Nos.

20

Rmt

2300

No

1

Nos.

1

Nos.

1

Nos.

1

Total =
H

PA / MUSIC SYSTEM

1

Supply and laying of 2Cx1.0 sq.mm speaker
wires with all accessories in existing conduit
pipes.
Supply, installation and commissioning of 6Watts
wall mounted speaker
Supply, installation and commissioning of
240Watts amplifier with USB provision, 3.5 jack
provision to connect PC, MIC and mobile phones.
Supply includes the MIC also. Rate includes the
installation and required mounting accessories.

2
3

Rmt.

200

Nos.

10

Nos.

1

Total =
I

LIGHT FIXTURES

1

Installation, testing and commissioning of
following type of light fixtures as per drawings and
specifications with all other accessories such as
connectors supporting rods / frames, anchor
fasteners, necessary hardware etc., complete
with all accessories to complete the installation as
required. THD of electronic ballast & Light fixtures
should be less than 10%.
9/11W LED circular type recess mounted light
fitting with acrylic diffuser
13/15W LED circular type recess mounted light
fitting with acrylic diffuser

1.1
1.2

Page 48 of 51

No

15

No

5

<!-- page 49 -->

1.3

No

2

No

8

No

110

No

32

No

2

No

10

1.9

20W, LED surface Type 4-Feet Light with acrylic
diffuser
32W, LED square type (2x2) recess mounted
direct /indirect down light with integrated frame &
full opal acrylic diffuser.
1 x 20W, Surface mounted patti type 4-feet LED
Light fixture
1 x 10W, Surface mounted patti type 2-feet LED
Light fixture
1 x 20W, Surface mounted patti type 4-feet LED
Light fixture for mirror light.
1 x 12W, LED Type Bulk Head Light with steel
wire gaurd for Lift well lighting.
1200mm sweep ceiling fan

No

58

1.10

300mm sweep exhaust fan

No

2

1.4

1.5
1.6
1.7
1.8

Total =
J

MISCELLANEOUS ITEMS

1

Providing and fixing in position the best quality
danger boards of approved shape and
size
as specified
by
the
local electrical
authorities written in English and local language.
Providing and fixing in
position 1.8m x 0.9m,
15mm thick 11kV grade, rubber
mat of
approved make and as required by authorities

No

1

No

1

Supply and installation of checker plates for
electrical and communication ducts
Supply & Installation of MS 2-Module Back Box
(Switch) in wall as surface /recessed mounted for
Nurse call system. The rate includes the chipping
and fixing with all necessary accessories.

Sq.mtrs

2

No

20

2

3
4

Total =
Total Cost Part-A =
Part-B
I

LIGHT FIXTURES

1

Supply, Installation, Testing & Commissioning of
following type of light fixtures as per drawings and
specifications with all other accessories such as
connectors supporting rods / frames, anchor
fasteners, necessary hardware etc., complete
with all accessories to complete the installation as
required. THD of electronic ballast & Light fixtures
should be less than 10%.
9/11W LED circular type recess mounted light
fitting with acrylic diffuser
13/15W LED circular type recess mounted light
fitting with acrylic diffuser
20W, LED surface Type 4-Feet Light with acrylic
diffuser
32W, LED square type (2x2) recess mounted
direct /indirect down light with integrated frame &
full opal acrylic diffuser.
1 x 20W, Surface mounted patti type 4-feet LED
Light fixture
1 x 10W, Surface mounted patti type 2-feet LED
Light fixture
1 x 20W, Surface mounted patti type 4-feet LED
Light fixture for mirror light.
1 x 12W, LED Type Bulk Head Light with steel
wire guard for Lift well lighting.

1.1
1.2
1.3
1.4

1.5
1.6
1.7
1.8

Page 49 of 51

No

15

No

5

No

2

No

8

No

110

No

32

No

2

No

10

<!-- page 50 -->

1.9

1200mm sweep ceiling fan

No

58

1.10

300mm sweep exhaust fan

No

2
Total =

II
1

2

3
4

5

NETWORK AND CCTV SYSTEMS
Supply, Installation, Testing and Commissioning
of 3.2 MP lP lR Dome indoor camera with voice
recording.
Supply, Installation, Testing and Commissioning
of 3.2 MP lP lR Varifocal Bullet outdoor camera
with voice recording.
Supply, Installation, Testing and Commissioning
of 16 Ch NVR with 4 SATA
Supply, Installation, Testing and Commissioning 4
TB Surveillance HDD (Hard Disk) (Storage
capacity shall be minimum lMonth)
Supply and installation of 16 port POE with fully
loaded - AMP

Nos.

4

Nos.

2

Nos.

1

Nos.

1

No

1
Total =

III
1

15kVA UPS, IGBT based with isolation
transformer
Design, manufacture, supply, installation, testing
and commissioning of 15kVA, IGBT based UPS
with isolation transformer as detailed in technical
specifications with connectivity between the UPS
and the battery etc., complete as required. 3
phase in & 3 Phase out / 3 phase in & single
phase out, with built-in active anti-harmonic filter,
(internal cabling if any) for reducing input current
to < 5% and improve PF to 0.95. The same shall
be suitable for parallel redundant configuration.
ONLY.RS 485 Mod bus to be provided for the
integration The rate shall include the cost of
wiring between battery terminals and UPS with
necessary mounting arrangements, hardware etc
complete. Phase sequencer to be included.

Set

1

UPS MAKE: APC / EMERSON / NUMERIC /
SOCOMEC, Schneider.
BATTERY MAKE : AMARARAJA / EXIDE /
AMRON
Total =
IV

NURSE CALLING SYSTEM BOQ

1

Supply and Installation of Micro controller based
Indication wall Mount
panel With the following facilities and expandable
in future. The panels
shall be inter linked such a way if any floor panel
can give alarm to the
other floor panel. The rate shall include the Nurse
Response Monitor
Software, installation, Communication Device with
GPS Modem.
• LED Display
• Reset switch
• Relay logic switch
• Voice recording module
• Mute switch
• Battery management circuit
• Wall mounting type enclosure
• RS 485 networking chord
• Code Blue Feature
NCRM
Page 50 of 51

<!-- page 51 -->

1.1
1.2
1.3
2

3

3

4

+
GSM
Set 1 2,50,000 - 2,50,000.00 - 2,50,000.00
1.1
Suitable for Emergency &
Suitable for 9 Beds with Wall / Table Mounting
Panel.
Suitable for 8 Beds + 2Toilets with Wall / Table
Mounting Panel.
Suitable for 6 Beds + 14Toilets with Wall / Table
Mounting Panel.
Supply and Installation of Call unit with Switches
& code blue like
• Membrane Type Call Switches with bell indicator
• LED Indicator
• Membrane Type Reset Switch
• Compatible for hand held call unit
Mounted On Standard electrical 2 module plate
near the Bed
Supply and Installation of Hand held Call unit with
switches & code blue like
• Membrane type call switch with bell indication
• Sleek ABS Plastic moulded enclosure
• Flexible chord with connector for easy
installation
Supply and Installation of Call Indicator mounted
outside the room mounted on standard electrical
2 module plate
Supply and Installation of Pull Card for Bath room
/ toilets

Nos

3

Nos

1

Nos

1

Nos

41

Nos

41

Nos

8

Nos

16
Total =
Total Part- A + B =

TOTAL OF ANNEXURE-"C" PART-I (Civil Works):
TOTAL OF ANNEXURE-"D" PART-II (Aluminium Works):
TOTAL OF ANNEXURE-"E" PART-III (Electrical Works):
GRAND TOTAL (PART-I + II + III):
I further affirm that I have read and fully understood the eNIT Document and agree to abide by all the terms
and conditions laid herein, which are being signed in token of my acceptance. In case, I fail to abide by the
conditions or to complete the contract to the entire satisfaction of the Shrine Board, I will be liable to the
penalties mentioned in the terms and conditions.

Yours faithfully,

Authorized Signatory ______________________
Name of the Bidder ________________________
Address: _________________________________
_________________________________
Email: ___________________________________
Mobile No.: _______________________________

Page 51 of 51
