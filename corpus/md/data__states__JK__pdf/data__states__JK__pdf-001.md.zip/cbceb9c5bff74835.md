---
doc_id: "cbceb9c5bff74835"
source_url: "https://cdn.s3waas.gov.in/s31141938ba2c2b13f5505d7c424ebae5f/uploads/2026/10/17934438069473.pdf"
ministry: "Budgam"
title: "Extension in last date of filling of offline application form for engagement as Krishi Udyami (KU)/Agriculture Entrepreneur in different Panchayats of District Budgam under HADP Phase-II issued vide Notification No. 09 of 2026-27 dated 23-10-2026."
date: ""
pages: 12
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "9fe6fb6ef3ec7a64"
---

<!-- page 1 -->

۱ ‏حکومتِ جموں وکشمیں از دفتر چیف ایگریکلچر آفیسر ضلع بڈگام‎
DEPARTMENT OF AGRICULTURE & FARMERS WELAFRE
OFFICE OF THE CHIEF AGRICULTURE OFFICER, DISTRICT BUDGAM
PUBLIC NOTICE

Sub.: Extension fn fast date of fiffing of offfine appfication form

for engagement as Krishi Udyami (KU)/Agriculture Entrepreneur

in different Panchayats of District Budgam under HADP Phase-II

issued vide Notification No. 09 of 2026-27 dated 23-10-

2026.

Whereas, this Office invited applications from eligible candidates
vide Advertisement Notice No. 09 of 2026-27 dated 23-10-2026 for the
purpose specified in the aforementioned advertisement; and

Whereas, the last date for submission of applications along with
all requisite documents was fixed as 30-10-2026; and

Whereas, this Office has received a poor response to the aforesaid
advertisement, the matter has been examined and it has been decided
to extend the last date for submission of applications in order to provide
an additional opportunity to eligible candidates to apply.

Now, therefore, in view of the above, the last date for submission
of applications pursuant to Advertisement Notice No. 09 of 2026-27
dated 23-10-2026, endorsed vide No. CAOB/Plan/2026-27/11653-
59 dated 23-10-2026, is hereby extended from 23-10-2026 to 95-
11-2026. All other terms and conditions of the He advertisement
shall remain unchanged.

۳۳ اء٢٢۲٢‎ 0۲8۰٥٠
8۰
No. CAOB/Plan/2026-27/ ‏-۸۵72ھ/‎ 6/ Dated 0-2026.
Copy to the:-
1. District Development Commissioner Budgam fe our of his kind
information.
| 2. Director of Agriculture, Kashmir for favour of information.
3. Joint Director Information Kashmir for favour of information. He is
| requested to give wide publication in the leading news-papers in
English/ Urdu/ Hindi.
| 4. Chief Planning Officer Budgam for information.

5. District Informatics Officer, NIC Budgam for information and with the
request to upload the Public Notice & advertisement notice on the
official website of District Budgam.

6. Sub-Divisional Agriculture Officer Chadoora/Beerwah/ Khansahib/
Budgam for information and with the directions to ensure wide
publicity of the above mentioined advertisement in concerned
panchayts and submit geo-tagged pics of the same to this Office.

<!-- page 2 -->

حکومت جموں و کشمس از دفس چیف ایگریکلچر آفیسرء ضلع ہڈگام
‎DEPARTMENT OF AGRICULTURE & FARMERS WELAFRE‏
‎OFFICE OF THE CHIEF AGRICULTURE OFFICER, DISTRICT BUDGAM‏
‎Re- Advertisement Notice‏
‎Subject: Re- Advertisement Notice for Engagement of Krishi Udyamis (KU)/ Agricultural‏
‎Entrepreneur in District Budgam under Holistic Agriculture Development‏
‎Program.‏
‎Re-Advertisement Notification ic OF CAOB of 2026-27‏
‎Dated: 739), /10/2026‏
‎Applications on prescribed format are invited from eligible candidates for‏
‎engagement as Krishi Udyamis (KUs) in various vacant pre-identified Panchayat/cluster Levet‏
‎Kisan Khidmat Ghars in District Budgam under HADP Phase II for a period of two years‏
‎(extensible) subject to terms and conditions laid down in contract agreement & Govt. Orders‏
‎received from time to time.‏
‎A. KEY DETAILS:‏
‎Position ____[Krishi Udyami (KU) (Agricultural Entrepreneur)‏
‎Vacant pre-identified panchayat Level Kisan Khidmat Gha‏ 04(
‎lof District Budgam- Please see Annexure (1) for full details‏
‎agement initially for a period of 2 years, with the possibility of‏
‎uration nnual extensions subject to the satisfactory performance of‏
‎the PLE.‏
‎jualification iploma* in Agriculture & Allied Fields or Graduation in Science,‏
‎BSc), Graduation** in Agriculture and Allied Fields. (BSc/BVSc,‏
‎Additionat preference wilt be given to candidates possessing‏
‎ipost-graduation (science/agri & allied) & computer**‏
‎diplomas /certifications.‏
‎Diploma courses: Diploma in Agriculture, Horticulture,‏
‎leterinary Sciences, Forestry, Fisheries, Sericulture, Agri.‏
‎Engineering, BHT, BAT from government recogniz‏
‎institution‏
‎kkAgri Allied courses: BSc in Agriculture, Horticulture,‏
‎Forestry, Fisheries, Sericulture; B. Tech in Agricultur‏
‎gineering, BVSc & AH from a Government recogniz‏
‎institution‏
‎Diploma/Certification course in computers of 3 or more‏ **
‎months duration from a government recognised institutio‏
‎Please see selection criteria (E) for full details‏
‎lob profile perate Kissan Khidmat Ghars (KKGs) under the Holistic‏
‎९ riculture Development Programme in Jammu &Kashmir as‏
‎lper details mentioned at (F‏
:
‎basis. Full details of KKG operations can be viewed at (G‏
‎st date for recei‏ 7
‎complete 30-10-2026 (upto 4:30 PM)‏ —
‎scanned with OKEN Scanner‏ ©

<!-- page 3 -->

B. GENERAL TERMS & CONDITIONS:

1. Detailed information including application form can be obtained from office of CAO
Budgam or downloaded from official websites of District Budgam
(https:/ /budgam.nic.in/)

Il. Candidate must have the requisite qualification for the post applied.

Tl. Age should be between 21 and 45 years as of the last date of submission.

ly. The Candidate must submit an affidavit attested by a Ist Class Magistrate

that he/she will make available secure space comprising of two rooms /
shops, (approximately 750 to 800 Sq. Ft.) at a feasibly located within the
concerned Panchayat on his/her own for which no rent shall be claimed by
the candidate.
Vv.  Self-attested photocopies of the following documents must be attached with the

application form:

a. Date of birth certificate (Matriculation certificate).

b. Marks certificate of all qualifying examinations.

c. Domicile Certificate.

@. Character certificate issued by the competent authority

Vi. Completed application forms should be submitted to the office of
the Deputy Commissioner Budgam in person or through registered post.

Vil. Any postal delay shall not be the responsibility of the APD/advertising authority.

Vill. Incomplete applications will be summarily rejected without further notice.

1X. Origirial docuirierits stiall Have to be préserited duririg the verification process.

C. OTHER TERMS AND CONDITIONS FOR KRISHI UDYAMIS (KUS):

1. The selected KU shall enter in to an agreement with the APD and shall have to
deposit a refundable security amount of Rs 10,000 (Rupees ten thousand only) in
the form of Fixed Deposit Receipt from any scheduled commercial bank and
will not claim up to 02 years even if I discontinue as KU.

I. Nature of Engagement: The selected KU will work on a franchise-franchisee basis,
the operation of Kisan Khidmat Ghars (KKGs) at the panchayat level will be carried
out by KUs under the support and framework provided by the Agriculture
Production Department with the aim of fostering entrepreneurship, local
empowerment, and the effective delivery of agricultural services in the Union
Territory of Jammu & Kashmir.

I. No Right to Regular Appointment: KUs are not entitled to claim any regular
appointment under the Scheme at any point of time.

Iv. Asset Ownership and Maintenance: Assets provided by the department for KKGs
shall remain the exclusive property of the department. KUs will function as
custodians of the infrastructure and facilities, being responsible for their
maintenance and security.

v. Management under Supervision: KKGs shall be managed by KUs under the
supervision of a Designated APD Officer from the respective locality, ensuring
alignment with departmental goals and guidelines.

VL Training and Fee Entitlement: KUs shall be provided with requisite training to
enhance their skills. They will be entitled to a payment of fees out of contingency
for participating in such training sessions and programs.

Vil. Input License Provision: The Directorate of Agriculture shall provide/facilitate
Entrepreneurs with the requisite input licenses, ensuring compliance with
regulatory standards.

vill. ‘Nodal Agency for Establishment and Administration: The Mission Director HADP
shall act as the nodal agency responsible for the establishment and administration
of KKGs, overseeing their effective functioning.

© scanned with OKEN Scanner

<!-- page 4 -->

IX. Technological Support: Development Departments and Krishi Vigyan Kendras
(KVKs) shall provide regular technology support to KUs, ensuring they stay abreast
of the latest advancements in agricultural technology. SKUAST cyber extension
hub shall be integrated with the KKG software ecosystem for continuous and
sustainable technology backup.

X. Facilitation of Linkages: The Agriculture Production Department/Mission
Directorate HADP shall facilitate the linkage of KKGs with input companies and
financial institutions by entering into Memorandums of Understanding (MOUs)
with these institutions, fostering collaborative efforts.

XI. Extension of Functions: Village/panchayat level workers of Agriculture and allied
departments shall extend their functions through KKGs, enhancing the reach and
impact of agricultural services.

XI. Service Charges and Compliance: KUs shall charge nominal service charges and
adhere to all requisite norms for extending services. A rate card for service
charges shall be issued by the Mission Director HADP from time to time. Weekly
reporting to Panchayat, Block, and Line departments is mandatory.

XI. Succession Plan on Disengagement: In the event of a KU leaving the assignment
or being disengaged, the functioning of KKG will directly come under the control
of the designated APD Officer for the said KKG, till the process of engaging new

KU is completed.

XIV. Agreement Termination Conditions:

a. The Agreement may be terminated by both parties (KU & APD) with a 3-month
prior notice. KUs, however, must provide an undertaking to stay in the agreement
for a minimum of two years. In the case of exit before two years by the KU, the
security amount of INR 10,000 (Rupees Ten thousand) will be forfeited. This is in
addition to the 3-month prior notice.

b. For all purposes, the Designated APD Officer will be the overall custodian of the
entire KKG setup, including monitoring of services rendered and assets.

Xv. Flexibility in Terms & Conditions: All the conditions mentioned in the
advertisement notice shall constitute the terms and conditions of the agreement.

However, APD reserves the right to change or add any other condition at the time
of signing of the agreement.

D. OBJECTIVES, FUNCTIONS & SCOPE OF KISAN KHIDMAT GHARS

The Holistic Agriculture Development Program is a 5-year transformative
initiative aimed at revolutionizing agricultural practices in the Union Territory of
Jammu & Kashmir. Under this visionary program, the establishment of Kisan
Khidmat Ghars (KKGs) represents a crucial step towards enhancing agricultural
outreach and providing comprehensive services to farmers at the grassroots level.
The KKGs, as part of the Innovative Extension Project, serve as one-stop service
centers strategically located at the panchayat level. These centers act as focal
points for the dissemination of information, advisory services, and the delivery of
agricultural schemes directly to farmers' doorsteps. The primary goal is to bridge
the gap between farmers and essential resources, ensuring timely access to
quality inputs, information, and support.

a. Objectives
© scanned with OKEN Scanner

<!-- page 5 -->

In order to address the significant gap in the extension worker-to-farmer
contact ratio in Jammu & Kashmir, it is proposed to establish 2000 "Kisan
Khidmat Ghars" at the panchayat level. These Ghars will act as ground-level
Convergence points for all services under the agriculture and allied sector. The
key objectives include:

i. Serving as a one-stop service center for agriculture and allied services at
the panchayat level.

ii, Extending all schemes and services by the agriculture and allied
department to the farmer's doorstep.

iii. Delivering ICT-driven dissemination of relevant advisory and information.

iv. Ensuring the timely availability of quality agri-inputs to farmers at
predefined prices.

v. Creating 2000 Krishi Udyamis (KUs) by providing self-employment
Opportunities to youth across the UT.

vi. Each Kisan Khidmat Ghar is envisaged to have "multi-functional kiosks
installed with a software interface," supporting KUs in delivering multiple
services and acting as intermediaries between the government and the
farmers. Similar to the common service centers (CSCs) model, KUs will
charge nominal fees for all services provided at Kisan Khidmat Ghars.

b. Functions of Kisan Khidmat Ghars:

Key services to be delivered by Kisan Khidmat Ghars include:

i. Farmer Registration for Schemes & Services: Application for HADP & CSS
schemes, Crop Insurance, etc., and creation of a unique farmer profile
with necessary documentation and specific information during registration.

ii. Sale of Farm Inputs: Sale of seeds, fertilizers, pesticides, and other farm
inputs at the panchayat level through market linkages provided by APD.

iii. Booking of Farm Machinery: Booking of farm machinery from the nearest
custom hiring centre (CHCs) and KVKs.

iv. Sale of Produce: Support to farmers in selling produce on e-marketing
Portals like e-NAM

v. Static & Dynamic Advisory: Integration of static guides on crop
management, disease management, post-harvest management, etc.,
developed by SKUAST, and real-time updates on weather forecasting,
agro-advisory, market intelligence, etc.

vi. Consultation with Experts from KVK: Real-time consultation with experts
from KVKs on different areas of expertise through video conferencing.

vii. Linkages to Line Departments: Integration of an information directory
and contact mechanism for all relevant service providers under the
agriculture and allied sectors, including AHELP workers, Krishi Mitras,
FPOs in the region, ambulance services, veterinarians, etc.

viii. Delivery of Decision Support System: Providing personalized insights to
registered farmers on optimizing crop planning, resource allocation, crop
Management .&.operationat processes through a decision support system.

10 OKEN Scanner

<!-- page 6 -->

ix. Farmer Education Programs: Conducting educational programs for
farmers to enhance their knowledge and skills in modern agricultural
practices, sustainable farming, and the adoption of advanced
technologies.

x. Soil Health Management: Implementing soil health management
practices, including soil testing services, nutrient management, and
recommendations for improving soil fertility.

xi. Integrated Pest Management (IPM): Offering guidance on integrated pest
management strategies, pest identification, and eco-friendly approaches
to pest control.

xiz, Livestock Services: Providing information and support for livestock
management, veterinary services, and animal husbandry practices.

xiii, Awareness Campaigns: Initiating and conducting awareness campaigns
on various government initiatives, agricultural best practices, and
schemes.

xiv. Government Scheme Facilitation: Assisting farmers in understanding and
availing themselves of various government schemes, subsidies, and
financial assistance programs.

xv. Data Collection and Reporting: Collecting essential data related to
agriculture, farmer profiles, and service utilization, and submitting regular
reports to the Agriculture Production Department.

xvi. Collaborative Initiatives: Facilitating collaborative initiatives with local
agricultural research institutions, universities, and other stakeholders to
bring cutting-edge technologies and practices to the grassroots level.

xvii, Continuous Learning: Keeping abreast of advancements in agriculture,
attending training programs, and continuously upgrading knowledge to
provide up-to-date information and services.

xviii. Community Engagement: Actively engaging with the local community,
encouraging participation in agriculturat activities, and fostering a sense
of community responsibility.

xix. Conflict Resolution: Resolving any conflicts or issues that may arise within
the community related to agricultural practices or the functioning of Kisan
Khidmat Ghars.

c. Scope of Kisan Khidmat Ghars:

The scope of Kisan Khidmat Ghars extends to providing comprehensive
support and services to farmers, promoting sustainable agricultural
practices, and contributing to the overall development of the agricultural
sector in the Union Territory of Jammu & Kashmir. Fhe program aims to
create a robust and farmer-friendly ecosystem that empowers both farmers
and Krishi Udyamis, ensuring the prosperity and growth of the agriculture
community.
© scanned with OKEN Scanner

<!-- page 7 -->

E. PROCEDURE AND CRITERIA FOR SELECTION OF PLE
The following procedure and criteria shall be adopted for the recruitment of Krishi
Udyamis (KUs):
i, Application Submission:
Interested candidates are required to submit their applications as per
prescribed format (Annexure A). Applications must be submitted on or before
the specified deadline. Any postal delay shall nof be the responsibility of the
APD/recruitment authority.
ii. _ Eligibility Criteria:
Candidates must meet the eligibility criteria outlined in the official notification,
including educational qualifications, age limits, and any other specified
requirements.
iii, | Selection Process:
Ha selection of KUs will be based entirely on a point-based system, as detailed
low:
(Desciplon  ۔.۔.۰ ‏.۔‎
‎कक
‎Diploma in Agri./BHT/BAT etc*
Post-Graduation (Science/Agri & Allied)
* Diploma courses: Diploma in Agriculture, Horticulture, Veterinary Sciences,
Forestry, Fisheries, Sericulture, Agri. Engineering, BHT, BAT from government
recognised institution.
**Agri Allied courses: BSc in Agriculture, Horticulture, Forestry, Fisheries,
Sericulture; B. Tech in Agriculture Engineering, BVSc & AH from a Government
recognized institution.
*** Diploma/Certification course in computers of 3 or more months duration from
a government recognized institution
The highest-scoring candidates meeting the eligibility criteria will be considered
for the position.
iv. Document Verification:
Shortlisted candidates will be required to undergo document verification. Original
certificates, mark sheets, and other essential documents must be presented for
verification.
vy. Publication of List of Selected Candidates:
The list of selected candidates, subject to document verification, will be published
on the official websites of the District and the Agriculture Production Department.
yi. Engagement Duration:
Successful candidates will be engaged initially for a period of two years, with the
possibility of annuat extensions based-on satisfactory performance and continuation
of scheme.
© scanned with OKEN Scanner

<!-- page 8 -->

vii. Agreement Signing:
Selected candidates will be required to sign a Agreement with the Agriculture
Production Department, outlining the terms of engagement and responsibilities.

viii, Declaration:

Applicants must submit a declaration (Annexure B) affirming the accuracy of the

information provided in the application.

F. JOB PROFILE

a) Job Summary:
The role of establishing and managing Kisan Khidmat Ghars (KKGs) at the
panchayat level is undertaken by the Krishi Udyami (PLE) in collaboration with APD.
Responsibilities encompass the provision of agricultural services, dissemination of
information, and serving as a liaison between farmers and various government
departments.

b) Key Responsibilities:

i. Kisan Khidmat Ghars Establishment: KUs are responsible for establishing and
managing KKGs in the designated panchayat, ensuring the availability of
operational facilities.

ii, _Agri-input Sales Handling: KUs oversee the sale of recommended agricultural
inputs, including seeds, fertilizers, and pesticides, ensuring farmers have access
to quality inputs.

iii, Development Departments Liaison: KUs facilitate communication between
farmers and relevant development departments, fostering collaboration and
ensuring seamtess delivery of services.

iv. Application Processes Facilitation: KUs assist farmers in the application
processes for various schemes and services, including schemes under the
Holistic Agriculture Development Program (HADP), Centrally Sponsored
Schemes (CSS), and crop insurance.

v. Advisory Services Provision: KUs provide interactive advisory services to
farmers on crops, diseases, inputs, and weather through multi-functional kiosks,
enhancing farmers' knowledge and decision-making.

vi. Utilization of Digital Portals: KUs manage the utilization of digital portals
created by the Agriculture Production Department, facilitating processes such
as booking inputs & custom hiring services and connecting with marketing
channels to streamline agricultural activities. They shall also help in enrollment
& training of farmers on the Daksh Kisan portal.

vii, | B2B and B2C Marketing Management: KUs play a crucial role in facilitating the
marketing of farmers’ produce through business-to-business (B2B) and
business-to- consumer (B2C) channels, contributing to the economic well-being
of farmers.

viii. Infrastructure Maintenance: KUs maintain an inventory of KKG infrastructure,
ensuring the proper functioning of facilities and equipment.

ix. Record Keeping and Reporting: KUs are responsible for maintaining functional
records of KKG activities and submitting regular reports, contributing to
effective monitoring and evaluation.

G. REMUNERATIVE MODEL FOR KRISHI UDYAMIS (KUs):

The Krishi Udyamis (KUs) engaged in the Holistic Agriculture Development
Program will have a structured earning model designed to ensure fair
compensation for their efforts and contributions. The primary sources of income
for KUs are as follows:
© scanned with OKEN Scanner

<!-- page 9 -->

a) Service Charges:
KUs are entitled to earn by charging a fee for the various services they provide
through the KKGs. These service charges may include facilitating applications,
providing advisory services, assisting in marketing farmers’ produce, and other
services outlined in the program. The rates for these services shall be notified
by Mission Director HADP from time to time.
b) Input Sales Commission:
KUs will receive a commission for the sale of recommended agricultural inputs,
such as seeds, fertilizers, and pesticides. This commission is a percentage of the
sales made through the KKGs. Necessary licenses for the same shall be
provided/facilitated by the APD.
० Business-to-Business (B2B) and Business-to-Consumer (B2C) Marketing
Commission:
KUs involved in facilitating the marketing of farmers’ produce through B2B and
B2C channels will receive a commission based on the successful transactions.
d) Contingency Fee for Training:
KUs will be entitled to payment of a contingency fee for any training sessions or
programs they undergo as part of their professional development.
It is essential to note that the earning potential of KUs is directly linked to
the efficient and effective operation of KKGs, the volume of services
provided, and the successful facilitation of various agricultural processes.
The program aims to create a sustainable and rewarding income structure
for KUS, aligning their success with the overall progress of agricultural
development in the Union Territory of Jammu & Kashmir.
Sd/-
Chief Agriculture Officer
ypudgam
No. CAOB/Plan/2026-27/ ॥52- 5५% Dated : 23 .10.2026
Copy to the:

1. District Development Commissioner Budgam for favour of his kind information.

2. Director of Agriculture, Agriculture Production Department Jammu for favour
of information.

3. Joint Director Information Kashmir for favour of information. He is requested
to give wide publication in the leading news-papers in English/ Urdu/ Hindi.

4. Chief Planning Officer Budgam for information. This is in reference to his
communication No. DDCB/KKG/5881-82 dated 08-11-2024.

5. District Informatics Officer, NIC Budgam for information and with the request
to upload the advertisement notice along with application form on the official
website of District Budgam.

6. Information Officer Directorate of Agriculture Kashmir for information &
necessary action.

7. District Information officer Budgam for information and with the request to
publish the advertisement notice in the leading newspapers in English/Hindi
and social media platforms and uploading the noti District Web portal.

Chief eee
0۷
© scanned with OKEN Scanner

<!-- page 10 -->

Annexure A - Application Form
Application Form for Krishi Udyami (Agricultural Entrepreneur) Affix latest
passport size
1. Name of the applicant: --- ‏سسسسسس سس‎ photograph with
white background
2. Parentage _ .. ‏ہسہسہسشےٹکے سس‎
3. ۵٥13۷8۲ 8001160 661: س٦۲7٣ ‏ہس‎
‎4. ۱۲6900۲80016881 ‏-سسسسیسسسسسے.۹.....-‎
‏کے اس‎ 10 हा SS ‏ےھ‎
‎5. ٥٥۲۱۱۵۸۵۵۸۲ 38٥01٥59 ‏ہہ ہہ سے ؛(00011916)‎
6. Aadhaar no:
7. Contact no.; ‏ہے بیس سسشسششں .۹ں‎
8. Email:
9. Bate of Birth: ‏.ہے سس ے.۔ے۔س۔شسسسسش4۹۱۹8ں.‎
10. Highest Education Qualification _____———
11. Gender.
12. Age as on last date of submission (years, months & days)___—
13. Qualification Details:
۳ No. Qualification Year of Board / | Subjects Marks &
passing University Percentage
‏ےچ‎
‎ee ‏لے‎
‎_ ‏ہے ا اک سے چا ہس سس‎
ee ee ‏_ا‎  ہا‎
ICT know-how
(Degree/ Diploma/
Certificate Course)
14. Any other Qualification/ Experience/ achievement relevant to job
na
‏متسسسسسچشچچششش'ش'_ےہ ہہ سں سے‎
a
TO ‏سے - ..ٹٹٹسٹتٹتٹ  سے‎
Signature of the Applicant
© scanned with OKEN Scanner
