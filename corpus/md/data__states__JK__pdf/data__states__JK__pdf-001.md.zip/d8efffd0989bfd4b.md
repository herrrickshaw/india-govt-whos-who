---
doc_id: "d8efffd0989bfd4b"
source_url: "https://cdn.s3waas.gov.in/s3dc6a70712a252123c40d2adba6a11d84/uploads/2024/01/2024012530.pdf"
ministry: "Doda"
title: "Circular of final Seniority list of Patwaries of Revenue Department District Cadre Doda as it stood on 01-07-2023"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "aaa6861e7c9a9e96"
---

<!-- page 1 -->

Tele No.:- 01996-233230,233529, (0)
Fax No.:- 01996-233231(0)

GOVERNMENT OF JAMMU & KASHMIR

OFFICE OF THE DEPUTY COMMISSIONER, DODA
Sub.-Circulation of final Seniority list of Patwaries of Revenue Department District Cadre Doda
as it stood on 01-07-2023.

Notification
Whereas, vide this office notification No. 3089-3115/SQ Dated:-12-09-2023, a tentative seniority
bor Patwaries of Revenue Department District Cadre Doda was circulated among all the Concerned

ratwaries through their concerned controlling officers/DDOs and through print media for filing

Ojections if any, with regard to their placement in the said tentative seniority list within 15 days period

from the date of its

circulation, and

Whereas, in response to above tentative seniority list, this office received representations/

Qojections from Sh. Zalim Singh, Sh. Mohd Siraj Maneer and Sh. Mohd Ilyas Patwaries figuring at
enal No. 11,12,16 respectively of the said tentative seniority list, wherein they have requested to fix

their seniority as per merit of select list; and

Whereas, from the perusal of select list of Patwaries, t has been found/observed by this office

that the previous Seniority list of Patwaries have not been prepared as per their merit obtained in the
select list; and
Whereas, the select listslappointment orders of all the Patwaries of Revenue Department,
District Cadre Doda have been scrutinized by this office and accordingly the final seniority list has
been prepared and all the Patwaries have been placed at the appropriate Serial numbers in the final

seniority list as per merit of select lists.

Therefore, as per rule 24 of classification control &Appeal Rules 1956 the final seniority list of

Patwaries as it stood on 01-07-2023 of Revenue Department District Cadre Doda annexed as
"Annexure-A" is hereby issued/circulated for information to all the concerned Patwaries of Revenue

Department District Doda.
Issued with the approval of Deputy Commissioner, Doda.

No S17-5)06 /sQ
Dated )5/01/2024

mar(JKAS)
Asststapt Commissioner (Rev),
Copy to the:

KDoda

1. Financial Commissioner Revenue, J&K Jammu for favour of kind information.
2

Divisional Commissioner Jammu for favour of kind information.

3. Addl. Deputy Commissioner, Doda/Bhaderwah for favour of information.
4. Sub Divisional Magistrate Thathri/Gandoh/Assar for information.

5. All Tehsildars of District Doda.
6. District Information Officer Doda, with the request to publish the notification in two daily
leading
newspapers.

7. District informatics Officer (NIC).Doda, with the request to upload the notification alongwith Final
8

seniority list on official website/lweb portal of this office.
Revenue official whatsapp group.

9. Notice board of this office.
10. Office files for record.

<!-- page 2 -->

(Annexure-A)
Final Seniority list of Patwaries in respectc of District
which
2Category
to Doda as it Stood on 01-07-2023.

Patwari

appointment
the
appointment
ofDate i order
ofPlace
Present

Qualification
appointed
Academic
Name of
Patwari

1.

Mohasin

Parentage

3
4

Shaista Bano

(full

OT
e.

DOB

S.No.
(

Address)

Bashir Ahmad

Bashir Sheikh Sheikh
2

Address

Astan Bala,

18-10-1984

PG

28-02-2011

01

I& FC

70.64

17-03-1980

PG

28-02-2011

03

P/H Berreru

65.64

OM/R PG

03-03-2011

01

P/H Jakhyas

65.41

18-03-2011

NA

P/H Roat

63.79

Select list of
candidates for the

OM/R Graduate03-03-2011

02

P/H Doda

63.66

(Rev. Deptt) Distt

03

O/P Tehsil

62.48

Office
Bhaderwah
I& FC

Cadre Doda
pursuant to Advt.
Notice No. 05 of

62.45

2007 Dated
31.12.2007 Item
No. 79

P/H

62.11

Kishtwar

Abdul

Village Nagar

Rehman

Tehsil Bhaderwah
19-01-1976

Yasir

Abdul

Village Chakka,

Nadeem

Qayoom

Tehsil Bhaderwah

Mohd Alyas

Ghulam
Hussain

Tehsil Nowshera

Zalim Singh

Mela Ram

Village Goha Tehsil 25-03-1985

Mohd Siraj

Abdul
Shakoor

Haveli Mohalla

Ganai

Bhaderwah

Village Dandeser

BA

04-01-1981

OM/

M.A,

OSC

M.Phil

post of Patwari

District Rajouri
5

Marmat
6.

Maneer
7.

8.

Abdul Sataar

Village Kulhand

Hussain

Bhat

Tarag

Noor Mohd

Tehsil Bharath
Bagla
Village Changa,

Rather

Tehsil Bhalessa

Hussain

9.

Tarig Hussain

Mangta Shan

BA
12-01-1985

OM

Graduate 03-03-2011

Bhaderwah, Tehsil

Shoket

(Gandoh)
Village Shuryan

Remarks
ifany

posting

the

Residential

in
Secured
Points
Selection
list

11-06-1982

B.A

28-02-2011

05

OM/R PG

28-02-2011

06

OM/R
BA

17-04-1971

Kahaljugasar

BA

26-01-1988

OM

10+2

28-02-2011

07

0/P Tehsil Assar

62.07

(Pernote)
Dashnan Tehsil

(

<!-- page 3 -->

Doda

10.

Malik Behzad
Ali

11.

Village Malik

Malik

Mohalla Bharath

P/H Shamthi

61.95

06

Kulgam

61.59

Graduate 03-03-2011

09

P/H Jangalwar

61.58

01-04-1982

RBA

Graduate 28-02-2011

04-04-1978

OM

PG

03-03-2011

01-01-1983

RBA

09

Tehsil Bharath
Bagla

Tanveer

Mohd Ishaq

Mohd lgbal

Nizam-Ud-Din
Wani

Ahmed Wani

12.

Ghulam Qadir

Village Kelam
Tehsil Devsar

District Kulgam
Wani

Village
Mulwarwan,Tehsil

TehsilThathri

Warwan District

13.

Asif lgbal

Kishtwar
Mohd lgbal
Dev

St.No.29 Near
Green Model
Hr.Sec.School

13-02-1984

OM

PG

28-02-2011

08

JDA

61.48

01-02-1982

ST

PG

28-02-2011

10

P/H Chinta

61.26

16-01-1972

SC

PG

03-03-2011

08

P/H Udhyanpur

57.77

30-12-1985

ST

B.A

16-01-2013

NA

P/H Assar

54.42

28-04-1972

OM/R PG

28-02-2011

11

P/H Ludna

68.89

Kishtwar
14.

Zakir Hussain

Mohd Azam

Village
Thanamang Tehsil
Darhal District

Rajouri
15.

Jaswant

Bhagat Ram

Singh
16

Mohd IshfagUI-Haq

17.

Abdul Karim

Village Chanti
Paine,Tehsil

Sher Mohd

Bhalessa(Gandoh)
Village Dhanwan,
Tehsil Kalakot,
District Rajouri

Mohd Akram

Village Kalihand

Lohar

Tehsil Doda

BA

Select list of candidate

for the post of Patwari
Distt Cadre Doda
pursuant to Advt.
Notice No. 01 of 2008
Dated 22.04.2008 Item
No. 006

<!-- page 4 -->

Seniority list of BOPEE Patwaries in respect of District Doda (as per the nisie of the Law / General Administration
Department)on the basis of merit of passing of Patwariexamination from the RevaaTraining institute Jammu.
Aous ON
Name of
Patwari

18.

Reyaz Ahmed

Parentage

Dillawer Khan

19. Mohd Idrees

Kherat Mohd Butt

20. Zakir Hussain

Mohd Ramzan

21.

Nadeem
Ahmed

Ghulam Qadir

22.

Manoj Kumar

Panchi Ram

23.

Shahid
Hussain

Ghulam Mohd

24.

Ayaz Ahmed

25.
26.

Towqeer Riaz
Malik

Adil HuSsain

Residential Address (full

Address)
Village Tantly, Tehsil
Gandoh
Village BhastiTehsil &
District Doda

Village Changa, Tehsil

Bhalessa (Gandoh)

Village Phagsoo,Tehsil

Phagsoo

Village Persholla, Tehsil
Mohalla

Village Panjgraine, Tehsil
Bhalla

Village Beli-ChinaraTehsil
Chilli-Pingal
Village Tilogra, Tehsil
Riaz Ahmed Malik
Mohd Hanief

Ganie

Chilli-Pingal

Ghulam Hussain
Khan

Village Dal-khankote,

Tehsil Mohalla

DOB

10-12-2013

368

P/H Chilli

PG

10-12-2013

349

P/H Dessa

RBA

M.A

10-12-2013

345

P/H Bhella

29-07-1989

RBA

PG

10-12-2013

336

P/H Kharangal

15-11-1988

RBA/SC

B.A,B.Ed 10-12-2013

326

P/H Gandoh

03-02-1989

RBA

M.A, B.Ed 10-12-2013

324

P/H Manthla

03-04-1990

RBA

M.A

10-12-2013

322

P/H Dudwar

04-04-1989

OM

M.A

03-02-2014

320

P/HKhellani

07-02-1990

RBA

B.A

10-12-2013

319

22-04-1984

RBA

M.A

13-04-1989

OM

01-04-1987

P/H Malhori
P/H Kandhote

27.

28.

Mohd Sagib

Mohd Rafig

Tahir Nagash

Mohd Sharief Per

Per

Village Gatha Tehsil
Bhaderwah

Village Arnora (Ghat)
Tehsil Doda

presently
25-07-1988

OM

04-04-1985

OM

B.SC, LLB 10-12-2013
M.Sc,
B.Ed

10-12-2013

318

315

attached in
DC Office
Doda

O/PDC Office
Doda

<!-- page 5 -->

Kishore Kumar Surjeet Singh

29.

Liagat Hussain Din Mohd

30.

31.

Hamid Akhtar

Mohd Ramzan

32.

Shah Din

Abdul Subhan

33.

Khadim
Hussain

Teg Ali

34.

Dharmanter
Singh

Daya Krishen

35.

Tahir HuSsain

Shams-Ud-Din
Hakeem

36. Sunil Kumar

37.

Abdul Hamid
Dev

Shiv Ram

Mahmdoo Dev

Village Dhumandha,Tehsil
Bhaderwah

Village Challer Bhatyas
Tehsil Gandoh

Village Udyanpur Tehsil

Bharath-Bagla
Village Budhli, Tehsil

Chilly-Pingal
Village Dhadkaie, Tehsil
Gandoh

Village Bharti Tehsil
Bhaleesa (Gandoh)

Village Arnora (Ghat),
Tehsil Doda

Village Puneja Tehsil
Chiralla

Village Rotipadrana, Tehsil
Doda

ST

B.A

10-12-2013

312

P/H Bharath

17-01-1973 RBA

B.A

10-12-2013

309

P/H Gajoth

03-12-1986

OM

MA

10-12-2013

306

P/H Jatheli

01-11-1985

RBA

PG

10-12-2013

295

P/HKilhotran

03-11-1990

ST

B.A

10-12-2013

293

P/H Malanoo

15-07-1982

RBA

PG

10-12-2013

289

P/H Udrana

15-12-1985

OM/OSC

M.A,

10-12-2013

289

Tehsil
Bhaderwah

04-07-1982

SC

10-12-2013

286

P/H Bajja

31-03-1990

P/H Bheja
M.Ed
PG

Regional
Survey & Land
08-02-1990

RBA

B.A

10-12-2013

286

Record

Chenab Valley
Doda

38.
39.

Ganesh Singh
Ravinder

Lachman Singh
Mansa Ram

Kumar

P/H

Village Himote, Tehsil
Bhaderwah

11-07-1975

Ex-man

Village (Dhonsa-Pani)

13-10-1984

SC

30-03-1982

RBA

Nagar Tehsil Bhaderwah

Graduate 10-12-2013

280

Khellani, Bhall

M.A,

10-12-2013

280

P/H Nagar

10-12-2013

260

O/P Pranoo

B.Ed

Village Puneja, Tehsil
40.

Shabina

Mohd Qasim

Bhaderwah A/P

Banoo

Shah

Sudhmahdev Tehsil Chenani
District Udhampur

M.A,
B.Ed.

<!-- page 6 -->

Senioritylist of 2019 Batch of Patwaries appointed under SRO 202 dated: 30-06-2015 through
JKSSB
41.

Shameem
Ahmed

42.

Pawan Singh

43.

Aquib Nazir

Village Goha Tehsil

74/100

P/H Charota

70.83/100

P/H Mohalla

06-05-2019

70.16/100

Trown,Tehsil

B.Sc.

03-05-2019

69/100

P/HPanchie

OM/RBA

B.A

12-06-2019

68.66/100

P/HBudhli

01-03-1990

OM

B.Sc

26-04-2019

68.16/100

P/H Bhagwah

Village Beoli Tehsil Doda

25-09-1992

OM/RBA

B.SC

26-04-2019

68.16/100

|& FC

Gh. Rasool Sie

Village Shiva Tehsil Doda

10-08-1990

OM/RBA

B.Sc.

29-04-2019

67.83/100

o/P DC Office

Abdul Gani Batt

Mohallah Dandian Ward
No.11 Tehsil Doda

02-02-1992

OM/RBA

B.Sc.

02-05-2019

67.66/100

Village Roat Tehsil Marmat

07-11-1990

OM/RBA

B.Tech in
CSE

29-04-2019

67.50/100

01-01-1991

OM/RBA

B.A

02-05-2019

67.33/100 P/H Jodhpur

Ab. Jabar

15-06-1986

OM/RBA

B.A

14-06-2019

10-11-1983

OM

B.SC.

26-04-2019

26-03-1993

OM

B.A

18-03-1989

OM/RBA

01-04-1993

Marmat

Thakar

Village Arnora Ghat Tehsil

Singh

Doda

Nazir Ahmed

Village Gatha Udrana
Tehsil Bhaderwah

P/H

44

Aagib lgbal

45. Haroon Rashid
46.

Sunil Singh

47.

Zia UI Khanji

48.

Danish Rasool

49.

Arjaman Gani
Batt

50. Tanveer Ahmed

51.

Nisar Ahmed

Mohd lgbal Qazi
Mohd Shafi

Suresh Kumar

Saidullah Khanji

Akhtar Hussain
Wani

Mohammad

Ramzan

Mohalia Havelli Nagar
Bhaderwah

Village SotiDudwar Tehsil
Gandoh (Bhallessa)

Village Derka Malothi
Tehsil Bhalla

Doda

Doda

o/P Naibat
Dali-Kuluhand

P/H Sungli

Village Chaliwan Gadethar
Tehsil
Gundna

<!-- page 7 -->

52.
53.

Amir Zaffar

Mohd Yaseen

Zafferullah Sofi

Mohalla Faridia Tehsil

Mohd Ashrif Mir

Village Soura Bhalla Tehsil

Doda

11-05-1990

OM

B.SC

24-04-2019

67.33/100 P/H Malwana

01-03-1989

OM/RBA

B.A

02-05-2019

66.33/100

03-05-1992

OM

B.SC

26-04-2019

66.33/100 P/H Mangota

OM/RBA

B.Sc

29-04-2019

66.33/100

P/H Arnora

10-03-1990

RBA

B.A

10-05-2019

66/100

P/H Manwah

24-12-1993

RBA

B.A

26-04-2019

65.83/100

P/H Kansoo

RBA

B.A

26-04-2019

65.66/100 P/H Dhareveri

Bhalla

54.

Khalid Bashir

Bashir Ahmed

Village Paryote Jangalwar

55.

Ilyas Ahmed

Mohd Rafeeq

Village Roat Tehsil Marmat 24-10-1994

56.

57.

Yasir Hussain

Khursheed

Village Chakka Tehsil

Mir

Ahmed Mir

Bhaderwah

Mohd Hanief Batt

Village Kilhotran Tehsil
Gandoh (Bhallessa)

Mohd Din Sheikh

Village Gundow Bhatyas
Tehsil Chilly-Pingal

Mohd Younis
Batt

58. Naiz Ali Sheikh
59. Tanveer Ahmad
60.

Imtiaz Ahmed

61.

Mohd Shafi

62.

Piyar Singh

Abdul

Latief

Perhan00
Gh. Hassan Shah
Qasim Din

Sher Chand

63. Narender Singh

Dewan Chand

64. Mahinder Singh

Raj Singh

Mohd Ashrif

Mohd Issa

Bhagat

65.

Tehsil Doda

Bhagat

29-12-1990

P/H Shiva

Village Khunoo Tehsil
Bharat Bagla

01-01-1995

RBA

B.SC.

26-04-2019

65.66/100

P/H Behota

Village Bhroon Bijarni
Tehsil Bhagwah

01-02-1990

RBA

B.A

08-05-2019

65.66/100

P/H Dhandal

Village Dhadkai Tehsil
Gandoh(Bhallessa)

05-07-1993

ST

B.A

27-04-2019

60.33/100 P/H Gadether

14-02-1993

SC

B.A

02-05-2019

58/100

P/H Bhalara

15-03-1991

SC

B.A

27-04-2019

56.16/100

P/H Jagota

27-10-1991

OM/RBA

B Sc.

24-09-2019

65.33/100

P/H Joura

18-08-1991

ST

B.A

07-08-2020

55.33/100

P/HChakka

Village Badanoo Tehsil

Thathri
Village Samaie Tehsl
Gandoh (Bhallessa)

R/ovillage Manoie Bhatyas
TehsilGandoh (Bhallessa)

R/o Village Shingni Tehsil
Gandoh (Bhallessa)
