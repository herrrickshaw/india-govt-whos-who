---
doc_id: "b0bc8f5d43ce9c8a"
source_url: "https://cdn.s3waas.gov.in/s3c5ff2543b53f4cc0ad3819a36752467b/uploads/2026/06/17804846112901.pdf"
ministry: "Reasi"
title: "Denotification of land measuring 02 Kanal 06 Marlas situated at village Mahore Bypass-I, Tehsil Mahore Notified under Section 21 of the Right to Fair Compensation and Transparency in Land Acquisition, Rehabilitation and Resettlement Act, 2013."
date: ""
pages: 3
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "fd81de3ee0dcc0dc"
---

<!-- page 1 -->

Government of Jammu & Kashmir
OFFICE OF THE COLLECTOR LAND ACQUISITION
(SUB DIVISIONAL MAGISTRATE) MAHORE (REASI)
Phone/ Fax No: 01999- 222211 ae Email: mahore-sdm@jk.gov.in
Subject: - Denotification of land measuring 02 Kanal 06 Marlas situated at village Mahore Bypass-I, Tehsil Mahore Notified under Section 21 of the Right to
Fair Compensation and Transparency in Land Acquisition, Rehabilitation and Resettlement Act, 2013.

Whereas Officer Commanding 110 RCC (GREF) C/o 56 APO had placed an indent vide No. 2010/LA/BMG/Indent/87/E2 dated: 09-01-2020 for acquisition of land for public Kindly
referred to the subject citied above. It is submitted that The Ministry of Defence, Government of India has taken up the "Construction/Up gradation of Budhal-Mahore-Gool (BMG)
road to NHDL specifications at village Mahore Bypass-I, Tehsil Mahore, District Reasi in the UT of J&K and in pursuance of which Officer Commanding 110 RCC (GREF) C/o 56 APO
had placed an indent vide No. 2010/LA/BMG/Indent/87/E2 dated: 09-01-2020 for acquisition of land for public purpose namely "Construction/Up gradation of Budhal-Mahore-Gool
(BMG) road to NHDL specifications "at village Mahore Bypass-I, Tehsil Mahore, District Reasi;

Whereas, on the identification of the indenting department revenue papers and map of land measuring 102 Kanal 09 Marlas local situated at village Mahore Bypass-I, Tehsil
Mahore District Reasi were got prepared by the field staff of Revenue Department through Tehsildar Mahore;

Whereas, after receipt of SIA exemption for the competent authority preliminary notification under section 11 of the of the (RFCTLARR) Act, 2013 was issued by this
Collectorate vide No: CLA/SDM/2022-23/90-106 dated: 27-05-2022;

Whereas, the Appropriate authority i.e Deputy Commissioner Reasi was pleased to issue deceleration under section 19 of the Right to Fair Compensation and Transparency
in Land Acquisition, Rehabilitation and Resettlement Act, 2013 for land measuring 102 Kanal 09 Marlas local situated at village Mahore Bypass-I, Tehsil Mahore, District Reasi vide
notification No. 10 DC (Rsi) of 2024 dated: 12-11-2024 issued under endorsement No. DC/Rsi/SQ/24-25/2724-31 Dated: 12-11-2024;

Whereas, this Collectorate issued notification under section 21 of the of the (RFCTLARR) Act, 2013 vide No. CLA/SDM/M/2024-25/471-86 Dated: 20-11-2024 asking all the
stakeholders/land owners/interested persons to file their objections/attend this office either in person or through an authorized agent or advocate within 35 days from the date of
publication of the notice i.e. on or before 21-12-2024 during office hours to state their respective interests in the land, the amount, particulars of their claims to the compensation
for such interests and to the measurement of land, if any;

Whereas, the notice was given wide publicity by publishing the same in the Government gazette, official website of the district, newspapers and also published the same on
the notice Board of Collector Office, Office of Tehsildar Mahore, Panchayat Ghar, Patwar Khana and other prominent places as per the provisions laid down in the RFCTLARR Act
2013. In response to which no of objection/claims were received in this Collectorate in response to the above quoted notification dated: 20-11-2024;

Whereas, this Collectorate was ready for the issuance of Draft Award for the village Mahore Bypass-I, Tehsil Mahore, however the indenting Department vide letter No.

Col LasaonenqubatfinysaT/E2 dated: 07-09-2024 had requested for descoping of some land/area at KM 45.150 to 45.380 and requested this Collectorate to wait till further request;
{Sub Divisional Magistrate)
Mahore

<!-- page 2 -->

Whereas, Officer Commanding, 110 RCC, Budhal vide his office letter No.800/EPC/PKG-1/71/E8 Dated 11-11-2025 again requested this collectorate to declare the final award
of village Mahore Bypass-I by excluding the De-scoped areas;

Whereas, during this period the stipulated one-year time for issuance of award got expired on 12-11-2025 as per section 25 of the Act reproduced as under: -

"The Collector shall make an award within a period of twelve months form the date of publication of declaration under section 19 and if no award is
made within that period, the entire proceedings for the acquisition of the land shall lapse: Provided that the appropriate Government shall have the power to
extend the period of twelve months if in needs opinion, circumstances exist Justifying the same: Provided further that any such decision to extend the period
Shall be recorded in writing and the same shall be notified and be uploaded on the website of the authority concerned".

In view of the above and in order to avoid further loss to the State exchequer on account of interest, this collectorate vide letter No. CLA/SDM/M/2025-26/409-411 Dated:-
10-12-2025 had requested to District Collector, Reasi to extend the time period for the issuance of draft/final Award in respect of village Mahore Bypass-I, District Reasi for another
six months enabling this collectorate to proceed further in the matter. In response to which, District Collector Reasi was pleased to extend the time period for other six-months
w.e.f. 28-01-2026 for issuance of final award of village Mahore Bypass-I.

Whereas, this collectorate vide letter No. CLA/SDM/M/2025-26/ 488-90 Dated: - 06-01-2026 has requested to District Collector, Reasi for accord of approval for De-notification of land
measuring 02 Kanal and 06 Marlas as mentioned above notified under section 11, section 19 and section 21 of the Right to Fair Compensation and Transparency in Land Acquisition, Rehabilitation
and Resettlement Act 2013.In response to which, District Collector, Reasi, vide letter No. DC/Rsi/SQ/26-27/110-11(E-7596931) Dated: - 06-04-2026 accorded. approval for de-notification of land
measuring 02 Kanal and 06 Marlas notified under section 11, 19 and 21 of the Right to Fair Compensation and Transparency in Land Acquisition, Rehabilitation and Resettlement Act 2013.

Therefore, land notified under 21 of the Right to Fair Compensation and Transparency in Land Acquisition, Rehabilitation and Resettlement Act 2013 mentioned in item
No. 01 and 02 issued vide this collectorate office letter No: CLA/SDM/M/2024-25/471-86 dated 20-11-2024 is hereby de-notified under section 93 of the Right to Fair
Compensation and Transparency in Land Acquisition, Rehabilitation and Resettlement Act 2013.

Detailed particular of De-notified land is as under:

Location of | Name of the land | Name of | Name of | Khasra No. | De-notified Area 7 Trees
Areas Owners cultivators occupant
be ‏اتا‎ | NonvFruits [Type | Pint
De- : : (Sqft)
notification [Ne | Variety hed
1. Ghulam Mohd, Mohd | Self-Cultivation | Ghulam Mohd Co- 1296/425/2 | O01 05 GMB Nil Nil
KM 45+150 to Ramzan sons and Mst. sharer through his min
454380 Azizi Wd/o son Mohd Bashir,
’ Mohamedou equal Mohd Ashraf
Share Hajam R/o Deh
۷
Collector Lpnd Acauisition
(Sub Divisiowal Magistrate}
Mahore

<!-- page 3 -->

2. Fe P| In possession of | 1296/425/2 wi | Nil Nil
Bhar Din, Sajjad | min
Ahmed Sons of
Mohd Ramzan Co-
sharer
00 ‏8ا‎
‎Shaft Ur uisition
colledewD-Abyheignaiahagistrato)
(Sub Divisional Magisonte)
Mahore
No: CLA/SDM/M/2026-27/"F2.- 3 °F Dated:- ‏+ا)۵- ج]‎ ०2.6
Copy to the;
1. Financial Commissioner (Rev) J&K, Jammu for favour of kind information.
2. Principal Secretary to Government, Revenue Department, Civil Secretariat, J&K, Jammu for favour of kind information.
3. Divisional Commissioner, Jammu for favour of kind information.
4. District Collector (Deputy Commissioner), Reasi for kind information.
5. Joint Director Information, Jammu for publication in two daily leading newspapers having largest circulation in the said locality of which at least one shall be in the regional language.
6. Manager Government Press Jammu with the request to publish in the original Gazette.
7. Officer Commanding, 110 RCC, C/o 56 APO, GREF, Budhal for information.
8. Divisional Forest Officer, Dharmari for information.
9. Executive Engineer PWD Sub Division Mahore for information.
10. District Informatics Officer, NIC, Reasi, with the request to upload the notification on the official website of the district.
11. District information Officer, Reasi for publication in the local newspaper.
12. Tehsildar Mahore with the directions to serve upon the notices to owners/interested person and a copy of the same be also pasted on the conspicuous places and original be returned to this
Collectorate after due service for record.
13. Block Development Officer, Mahore with the direction to serve the notifications to Gram Sabah and past the same on Panchayat Ghar (s) of the Village.
14. Notice Board O/o Deputy Commissioner, SDM Mahore and Tehsildar Mahore.
15. Office Copy.
