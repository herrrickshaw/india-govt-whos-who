---
doc_id: "1cf66fab0cf9ebda"
source_url: "https://skuastjammu.ac.in/admin/backend/news/1787819694bid-canteen.pdf.pdf"
ministry: "Sher-e-Kashmir University of Agricultural Sciences and Technology of Jammu (SKUAST-Jammu), Jammu and Kashmir"
title: "GeM Bid/tender document for canteen"
date: ""
pages: 17
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "0b75ed721203d517"
---

<!-- page 1 -->

|
Fe
ہ٦‎ GeM Var fas 0/814 Number: GEM/2026/B/7902156
| Government Azadi, Reale /Dated: 24-08-2026
+f” e Marketplace ™"t Mahotsav
बिड दस्तावेज़ / 816 Document
के रू aro कि छा गा
fas खुलने की तारीख/समय /छा6 09७09 30:
Date/Time 03-09-2026 13:30:00
fas tener duer (aq gt & ata 4)/Bid Offer
Validity (From End Date)
7 Sher-e-kashmir University Of Agricultural Sciences And
eos atest
‏ج3 ہہ‎ & sas Ray Contact details of | HOD Email id :buycon129.suast}.jk@gembuyer.in
Grievance redressal Buyer Email id: dswskuastj@gmail.com
Canteen Service - Best Price on Fixed Menu Rate Model -
Vegetarian; Breakfast, Lunch, Dinner, Snacks, Beverages;
वस्तु बैणी' Atom Category Inside Building Premises (exclusive for employees/ patients/
in house personnel)
बिडर का न्यूनतम ऑसत वार्षिक टर्नओवर (३ वर्षों का)
/Minimum Average Annual Turnover of the
bidder (For 3 Years)
उन्हीं/समान सेवा के लिए अपेक्षित विगत अनुभव के
at/Years of Past Experience Required for [3 Year(s)
same/similar service
इसी तरह की सैवाओं का पिछला आवश्यक ×۳ ۴/۶۵۴ ‏ہے,۱‎
‎Experience of Similar Services required
i
वर्षों के अनुभव एवं टर्नओवर से एमएसई को छूट प्रास है /
MSE Relaxation for Years Of Experience Yes | Complete
and Turnover
स्टार्टअप के लिए अनुभव के वर्षों और टर्नओवर से छूट प्रदान
1 nf & /Startup Relaxation for Years of
Experience and Turnover
119
-

<!-- page 2 -->

fas faaror/Bid Details <i +20 :
Experience Criteria,Bidder Turnover,Certificate (Ri 7
in ATC) ti perience ||
far 8 WA aU aeAaa/Document required _| *in case any bidder is seeking exemption ‏ا ا‎ his
from seller Turnover Criteria, the supporting docume ‏م‎ tion bY
eligibility for exemption must be uploaded for evalua’
the buyer
क्या आप निविदाकारों द्वारा अपलोड किए गए दस्तावेज़ों को
निविदा निविदाकारों को दिखाना Yes (Documents submitted as part of a clarification or
‏0د‎ representation during the tender/bid process will also be
wet Fr Fast ‏ما ہ٭‎ you want to show displayed to other participated bidders after log in)
documents uploaded by bidders to all
bidders participated in bid?
बिड लगाने की समय सीमा स्वतः नहीं बढ़ाने के लिए
आवश्यक बिड की teat! / Minimum number of  |३
bids required to disable automatic bid
extension
दिनों की संख्या, जिनके लिए बिड़ लगाने करी समय-सौमा
wag areti / Number of days for which Bid
would be auto-extended
ऑटो एक्सटेंशन अधिकतम कितनी बार किया जाना है। /
Number of Auto Extension count
Bel कोन ona
fa awa करत किप्णाप Quaiication Rule
Bes oye
तकनीकी मूल्यांकन × ‏حا‎ तकनीकी स्पष्टीकरण हेतु
‏پد‎ WaT /Time allowed for Technical
Clarifications during technical evaluation
अनुमानित निविदा मूल्य (सभी करों सहित) भारतीय रुपये में
/ Estimated Bid Value in INR (Inclusive of all | 2000000
taxes)
Payments shall be made to the Seller within 30 days of
issue of service delivery acceptance certificate (SDAC) and
on-line submission of bills (This is in supersession of 10 days
time as provided in clause 12 of GeM GTC)
So
fe -.. ..___ے۴١ ‏ا[‎
‎hed
‎$varét 933۳/۶۸۵ ‏ان5۷‎
‏سٗ سے‎ ——= ane ‏.سے‎ =
saga) Fa/Advisory Bank || State Bank of India
| ‏اہم ۱9/۸۸۵ ۴۰ . . سعہ۸ ٥ہ ۵ہ‎ 0०७००... ऱ |
an

<!-- page 3 -->

|: ©
‘ dtyarah PEROT /ePBG Detail ,
= i
21511177/8 ٤ ٠ ‏۔۰ئ۳‎ ... |
‏سے‎ a
(a). pa laidback at a च्छुक बिडर को संबंधित कैटेगरी के लिए बिड़ के साथ वैध समर्थित दस्तावेज़ प्रस्तुत करने है। एमएसई
केटेगरी के अंतर्गत केवल वस्तुओं के लिए विनिर्मत्ा तथा सेवाओं के लिए सेवा प्रदाता ईएमडी से छूट के पात्र हैं। व्यापारियों को इस नौति के दायरे से. |"
ae 9 7 SI/EMD EXEMPTION: The bidder seeking EMD exemption, must submit the valid supporting document
for the relevant category as per GeM GTC with the bid. Under MSE category, only manufacturers for goods and
Service Providers for Services are eligible for exemption from EMD. Traders are excluded from the purview of this
Policy.
‏ا ض۱ × 0د 7× ٭دد ×× ہد ڈسخ ردص‎ Tare a cer a ett aries / EMD & Performance security should be
in favour of Beneficiary, wherever it is applicable.
(०).$एमडी और संपादन जमानत ai ‏الو‎ & car a eet ariel / Earnest Money Deposit (EMD) shall also be accepted by
the buyer in the form of a surety bond.
ware /Beneficiary :
Comptroller 4०11 3 7
REGISTRAR OFFICE, Higher Education Department Jammu and Kashmir, Sher-e-Kashmir University of Agricultural
Sciences and Technology of Jammu,
(Comptroller, Skuast-jammu)
बोली विभाजन ary aét fear aar/ Bid splitting not applied.
_एमआईआई अनुपालन/॥भ॥ (0009८
‏مسحسسسے سی‎ छू _ . |]
waves wiz aiza/MSE Purchase Preference
775 जल
1. If the bidder is a Micro or Small Enterprise as per latest orders issued by Ministry of MSME, the bidder shall be
relaxed from the eligibility criteria of "Experience Criteria" as defined above subject to meeting of quality and
technical specifications, The bidder seeking Relaxation from Experience Criteria, shall upload the supporting
documents to prove his eligibility for Relaxation.
2. If the bidder is a Micro or Small Enterprise (MSE) as per latest orders issued by Ministry of MSME, the bidder
shall be relaxed from the eligibility criteria of "Bidder Turnover" as defined above subject to meeting of quality
and technical specifications. If the bidder itself is MSE OEM of the offered products, it would be relaxed from the
“OEM Average Turnover” criteria also subject to meeting of quality and technical specifications. The bidder
seeking Relaxation from Turnover, shall upload the supporting documents to prove his eligibility for Relaxation.
3. The minimum average annual financial turnover of the bidder during the last three years, ending on 31st
March of the previous financial year, should be as indicated above in the bid document. Documentary evidence in
the form of certified Audited Balance Sheets of relevant periods or a certificate from the Chartered Accountant /
Cost Accountant indicating the turnover details for the relevant period shall be uploaded with the bid, In case the
date of constitution / incorporation of the bidder is less than 3-year-old, the average turnover in respect of the
completed financial years after the date of constitution shall be taken into account for this criteria.
4. Years of Past Experience required: The bidder must have experience for number of years as indicated above in
bid document (ending month of March prior to the bid opening) of providing similar type of services to any
Central / State Govt Organization / PSU. Copies of relevant contracts / orders to be uploaded along with bid in
support of having provided services during each of the Financial year.
5. Estimated Bid Value indicated above is being declared solely for the purpose of guidance on EMD amount and
for determining the Eligibility Criteria related to Turn Over, Past Performance and Project / Past Experience etc.
319

<!-- page 4 -->

ave a
; i ۲
This has no relevance or bearing on the price to be quoted by the bidders and is also not sone | 20255 of nd
impact on bid participation. Also this is not going to be used as a criteria in determine, ۲٥35 blenes> a
quoted prices which would be determined by the buyer based on its own assessment of reasona
based on competitive prices received in Bid / RA process. Services
6. Past Experience of Similar Services: The bidder must have successfully executed/complersé a of Mai |
over the last three years i.e. the current financial year and the last three financial years(ending
prior to the bid opening): -
1. Three similar completed services costing not less than the amount equal to 40% (forty percent) of the
estimated cost; or ti
2. Two similar completed services costing not less than the amount equal to 50% (fifty percent) of the estimated
cost; or
3. One similar completed service costing not less than the amount equal to 80% (eighty percent) of the estimated
cost.
7. Reverse Auction would be conducted amongst all the technically qualified bidders except the Highest quoting
bidder, The technically qualified Highest Quoting bidder will not be allowed to participate in RA. However, H-1
will also be allowed to participate in RA in following cases:
i. If number of technically qualified bidders are only 2 or 3. हे ith
ii, If Buyer has chosen to split the bid amongst N sellers, and H1 bid is coming within N.
iii, In case Primary product of only one OEM is left in contention for participation in RA on elimination of H-1.
iv. If L-1 is non-MSE and H-1 is eligible MSE and H-1 price is coming within price band of 15% of Non-MSE L-1
V. If L-1 Is non-Mil and H-1 is eligible Mil and H-1 price is coming within price band of 20% of Non-Mil L-1
एक्सेल में अपलोड किए जाने की आवश्यकता /६८८९॥ 0जा०्यत Required :
MENU - 4787552427 52
‏5د‎ atraar /aierena %21/Additional Qualification/Data Required
Scope of Work:1787552587.pdf
Menu Items:1787552679.pdt
Canteen Service - Best Price On Fixed Menu Rate Model - Vegetarian; Breakfast,
Lunch, Dinner, Snacks, Beverages; Inside Building Premises (exclusive For Employees/
Patients/ In House Personnel) ( 1)
तकनीकी विशिष्टियाँ Technical Specifications
| ‏تحت تھا‎ | Specification ۰... ‏988ح‎ ۰۱.۴.۳1 Values
— EES =
| icre ee —<—s——C(CiCSSCisidCS / Core
[TypeofDit si Vegetarian
[TypeofMeal si of Meal [Breakfast Lunch. Dinner, Snacks.Beverages ۱.۱ . Lunch , Dinner , Snacks , Beverages
——— ےلا۰٢‎ as tayo ess exe even ‏سص۸ہ ضسر‎ |
Inside Building Premises (exclusive for employees/ patients/ in house
| [ryvercanteen space | of Canteen Space personnel)
[Electricity Charges | [Tobe provided by Service Provider be provided by Service Provider
[Cooking Gas Charges | Gas Charges [Tobe provided by Service Provider si be provided by Service Provider
[watercharges  ..× Charges _ [Tobe provided by Service Provider ___........[ provided by Service Provider
[BasicFurniture .________.. [Tobe provided tyeuyer | be provided by Buyer
Se: | Operational Days ina ‏چچ ری ردن_‌ در سا سس سے‎ daysa week
week 8 ‏ال۔_‎ [fete pedal Seven ea _ ‏سے‎
‎| [Cooking Equipments | Equipments | To be provided by Service Provider
419

<!-- page 5 -->

= See
\ Essential Crockery To be provided by Service Provider
([conteenstat | Canteen Staff To be provided by Service Provider
——————$————— ==—— es
\\ Distribution/ Serving Style From single point - (canteen establishment)
| Uniform for Canteen Staff To be provided by Service Provider
۱ Display Shelf To be provided by Service Provider
Smart Vending Machines Not Required
[Raw Material ۱| _| To be provided by Service Provider
| कराकर ‏اعد فا وس سا ا اب‎ AE
[एडओऑन /849०॥(५)
|
[canteen stat Time __
‏وسس یدع‎
dar wa fretta =e 4ea/Minimum Floor Price defined by Buyer
dear द्वारा निर्धारित न्यूनतम मूल्य॥भा।॥रगाजा। #10ण शां८छ
defined by Buyer
अतिरिक्त विशिष्टि areata /Additional Specification Documents
CC eee OT ——"'"'"'"“
with Rater aartt /Consignees/Reporting Officer and Quantity
‏ےت‎ So
| heal परेषिती/रिपोर्टिंग ۱ अतिरिक्त आवश्यकता
°. after’ /Consignee Ual/Address ‏سی‎ | oc
Reporting/Officer ‏وم‎
‏٭‎ ٥۱۱۵ا‎ 0
Space (In Sqft) :
2000
« Total No of
Employees/
‏حے‎ Individuals/ Footfall
Iniversity of Agricultural Project / to be served per
1 Sudhakar Dwivedi |} Sciences and Technology of | Lumpsum day : 300
Jammu Main Campus- Chatha, | Based Monthly License
Jammu (J&K) Fee : 10000
۱ Duration in Months
४ 24
Working Days in 2
Month 2
axe

<!-- page 6 -->

ific Terms and डर ;
केता द्वारा जोड़ी गई बिड की विशेष wt/Buyer Added Bid Spec
1, Generic 3 a
intity or Contract duration up r
OPTION CLAUSE 50% : The buyer can increase or decrease the अर आओ the contrac
to 50 percent at the time of issue of the contract. However, once हे Bidders are bound to accept the
quantity or contract duration can only be increased up to 50 percent.
revised quantity or duration. 1 t
For ‏کوشا‎ caved contracts, the buyer may increase the scope of work and contract value up to
50 percent with the consent of the service provider
2. Certificates
Bidder's offer is liable to be rejected if they don't upload any of the certificates / documents sought in the
Bid document, ATC and Corrigendum if any,
3. Buyer Added Bid Specific ATC
Buyer Added text based ATC clauses
* PAN Card
*  Aadhaar Card
* Valid GST Registration Certificate,
* ४००७ FSSAI License/Registration Certificate applicable to the nature of cateri
ng/canteen services.
* Experience Certificates/Work Orders for catering/canteen/mess/food service
work executed during the last three (03) years,
*  Non-Blacklisting Affidavit declaring that the bidder/firm has not been blackli
sted, debarred or otherwise Prohibited by any Government Department, PSU
, Autonomous Body, University or other Government organization.
* Acceptance Letter/Declaration confirming unconditional acceptance of all th
e Terms & Conditions, Scope of Work, Menu, Specifications and other provisi
ons of the Tender Document,
+ Latest Income Tax Return (ITR) filed by the bidder/firm, along with relevant
acknowledgement,
+ Average Annual Turnover of not less than Rs. 40,00 lakh.
6/9
‏قڑ ...ینس ے‎

<!-- page 7 -->

| ‘2
/\ TERMS & CONDITIONS - UNIVERSITY CANTEEN

1. Contract Period: The contract shall remain valid for the period mentioned in the bid/tender.

2. Performance: The contractor shall ensure uninterrupted, efficient and satisfactory canteen services th

roughout the contract period without any unauthorized closure.

3, Licence Fee: The license fee mentioned in the bid shall be deposited first week of every month.

4, Security Deposit: The successful bidder shall deposit Rs. 1,00,000/- (Rupees One Lakh only)
in favour of the Comptroller, SKUAST-jammu., The Security Deposit shall be liable to be forfeited
, wholly or partly, in case of any breach, violation, non-compliance or unsatisfactory performan
ce of the contract, without prejudice to any other action as per the terms of the contract.

5, Food Quality: Only fresh, hygienic and nutritious meals and refreshments shall be prepared and serve

d, Sale or reuse of stale, adulterated or expired food items is strictly prohibited.

6. Raw Materials: Only branded and FSSAl-compliant edible oil, flour, rice, pulses, spices, milk and other

ingredients shall be used. The University may verify purchase records at any time.

7. Menu & Rates: Only the University-approved vegetarian menu shall be served and no item shall be
sold above the approved rates.

8. Working Hours: The canteen shall remain operational daily from 08:00 AM to 08:00 PM.

9. Staff: The contractor shall deploy adequate, trained and uniformed staff with identity cards. All staff sh
all undergo Police Verification before deployment and copies shall be submitted to the University.

10, Medical Fitness: All employees shall be medically fit, maintain personal hygiene and wear clean unif
orms, gloves and head covers wherever required.

11. Cleaning & Hygiene: The kitchen, dining area, utensils, counters and equipment shall be cleaned an
d sanitized regularly.

12, RO Drinking Water: Safe and purified RO drinking water shall be made available to students, staff a
nd visitors at all times. The RO system shall be serviced periodically.

13. Storage: Food materials shall be stored hygienically with proper refrigeration and protection from con
tamination.

14, Waste Management: Wet and dry waste shall be segregated separately. No littering, dumping or bu
ming of waste shall be permitted inside the campus. The contractor shall ensure disposal of waste outside
the University campus only at authorized disposal sites.

15. Pest Control: Periodic pest and rodent control shall be carried out without affecting food safety.

16. Digital Payments: UPI, cash and other digital payment facilities shall be available.

17. Complaint Register: Complaint and suggestion registers shall be maintained and grievances resolve
d promptly.

18. Inspection: The Food Inspection Committee shall conduct random inspection of the canteen at any ti
me, Any deficiencies found shall be rectified immediately by the Contractor,

19. Food Sampling: Food samples may be collected for quality testing whenever required.

20. Records: Proper records relating to purchase, stock, attendance, cleaning and maintenance shall be
maintained.

21, Fire Safety: Adequate fire extinguishers, first-aid facilities and LPG safety measures shall be maintai
ned.

22. Utilities: Electricity and water shall be used judiciously and wastage shall be avoided. .

719

<!-- page 8 -->

Sd ‏کی_- جہےڈچجرر  سچ تے رو و ششو رت سٹو‎ OO
23. University Property: Any loss or damage caused to University property shall be made good BY है
ontractor,

24, Statutory Compliance: The contractor shall comply with FSSAI, GST, Labour Laws, EPF, ESI and ‏جس‎
‎her applicable laws.
25. Prohibited Items: Sale or consumption of tobacco, alcohol, intoxicants and banned substances sha
be strictly prohibited. ;
26. Subletting: The contract shall not be assigned or sublet under any condition
27. ty: The University may impose penalties for overcharging, poor quality, unhygienic conditions or
breach of any condition.
28. Termination: The contract may be terminated for persistent default, misconduct or viojation of tende
r conditions,
29. Dispute Resolution: All disputes shall be subject to the jurisdiction of Jammu.
30. University Rights: The University reserves the right to inspect, modify menu/timings, impose penalti
es and accept or reject any bid without assigning any reason.
‏01/.٭٭×٭‎ ٤7
The Additional Terms and Conditions (ATC) have been incorporated by the Buyer after approval of their
Competent Authority. The Buyer ,is solely responsible for the impact of these Clauses on the bidding process, its
outcome, and consequences thereof including any restriction arising in the bidding process due to these ATCs
and including the modification of technical specifications and / or terms and conditions governing the bid.All
representations / grievances pertaining to the ATC clauses shall be raised with the buyer organization directly
and not with GeM. If any of the clause(s) is/are incorporated by the Buyer regarding the following, the bid &
resultant contract shall be treated as null & void. Further, GeM reserves the right, at its sole discretion, to cancel
the bid forthwith, without issuance of any prior notice or intimation :-

1. Publishing Custom / BOQ bids for items for which regular GeM categories are available (unless such
Custom / BOQ item is bunched with the major regular product Category Item).

2, Mandating procurement of / from’specific Brand / Make / Model / Manufacturer / Dealer except in case of
Single Bid / Proprietary Article Certificate (PAC) Buying.

3, Inclusion of disqualification criteria related to suspension of seller / service provider, where such
suspension period has already expired.

4. Mandating submission of documents (other than EMD and signed Integrity Pact - which can be submitted
within 5 days of bid opening) in physical form as a pre-requisite to qualify bidders.

5. Publishing bids on GeM for procurement of works.

6. Procurement of Goods by creating a Service bid on GeM & vice-versa.

7. Seeking sample with bid or approval of samples during bid evaluation process. However, trial / sample, as
the case may be, shall be permitted in cases where trial / sample are allowed as per approved and
published procurement policy of the Buyers’ controlling Ministry / Department / State / Public Sector
Enterprises Headquarters. If there is any violation of trial / sample clause with regard to approved policy
of the Buyers’ Ministry / Department / State / Public Sector Enterprises Headquarters, then this is to be
determined and redressed by the concerned Buyer Organisation only.

8. Seeking experience from specific organization / department / institute only or fram foreign / export
experience,

9. Creating bid for items from incorrect categories.

10. Reference of conditions published on any external site or reference to external documents/clauses.

11. Asking for any Tender fee / Bid Participation fee, as the case may be.

12. Buyer added ATC Clauses which are in contravention of clauses defined in bid detail section, including
specifications, EMD Detail, ePBG Detail and Mil and MSE Purchase Preference sections of the bid, unless
otherwise allowed by the applicable GeM GTC.

13. Any ATC clause in contravention with GeM GTC Clause 4 (xiii) (h) will be invalid, In case of multiple L1
bidders against a service bid, the buyer shall place the Contract by selection of a bidder amongst the L-1

8/9

<!-- page 9 -->

خ۴
‎through a Random Algorithm executed by GeM system.‏ =

14. \na Category based bid, adding additional items, through buyer added, additional scope of work/
additional terms and conditions/or any other document. If buyer needs more items along with the main
item, the same must be added through bunching category based items or by bunching custom catalogues
o os 3800 with the main category based item, the same must not be done through ATC or Scope
of Work.

Further, if any seller has any objection/grievance against these additional clauses or otherwise on any aspect of

this bid, they can raise their representation against the same by using the Representation window provided in

the bid details field in Seller dashboard after logging in as a seller. Buyer is duty bound to reply to all such

representations and would not be allowed to open bids if he fails to reply to such representations.

All GeM Sellers/Service Providers shall ensure full compliance with all applicable labour laws,

including the provisions, rules, schemes and guidelines under the four Labour Codes i.e. the Code
on Wages, 2019; the Industrial Relations Code, 2020; the Occupational Safety, Health and Working
Conditions Code, 2020; and the Code on Social Security, 2020 as and when notified and brought into
force by the Government of India.

For all provisions of the Labour Codes that are pending operationalisation through rules, schemes or
notifications, the corresponding provisions of the pre-existing labour enactments (such as The
Minimum Wages Act, 1948, The Payment of Wages Act, 1936, The Payment of Bonus Act, 1965, The
Equal Remuneration Act, 1976, The Payment of Gratuity Act, 1972, etc. and relevant State Rules)
shall continue to remain applicable.

The Seller/ Service Providers shall, therefore, be responsible for ensuring compliance under:

* a notified and enforceable provisions of the new Labour Codes as mentioned hereinabove;
* All operative provisions of the erstwhile Labour Laws until their complete substitution.

All obligations relating to wages, social security, safety, working conditions, industrial relations etc.
and any other statutory requirements shall be strictly met by the Seller/ Service Provider. Any non-
compliance shall constitute a breach of the contract and shall entitle the Buyer to take appropriate
action in accordance with the contract and applicable law.

This Bid is governed by the General Terms and Conditions, conditions stipulated in Bid and Service
Level Agreement specific to the Service, as the case may be, as provided in the Marketplace.
However, in case of Service, if any condition specified In General Terms and Conditions Is
contradicted by the conditions stipulated in Service Level Agreement specific to said Service, then it
will over-ride the conditions in the General Terms and Conditions.

This Bid is governed by the ‏ےت‎ नियम और gci/General Terms and Conditions. conditions stipulated in Bid and
Service Level Agreement specific to this Service as provided in the Marketplace. However in case if any condition
specified in ۱۱777 ‏ہ8‎ at ed/General Terms and Conditions is contradicted by the conditions stipulated in
Service Level Agreement, then it will over ride the conditions in the General Terms and Conditions.
जैम की सामान्य शर्तों के खंड 26 के संदर्भ में भारत कै साथ भूमि सीमा साझा करले वाले देश के ब्रिडर से खरीद पर प्रतिबंध के संबंध में
आरत कै साथ अभ्रूमि सीमा साझा करने वाले देश का कोई भी बिडर इस निविदा मैं बिड देने के लिए तभी पात्र होगा जब वह बिड देने वाला
सक्षम प्राधिकारी के पास पंजीकृत हो।बिड मैं भाग लेते समय बिड़र को इसका अनुपालन करना होगा और कोई भी गलत घोषणा किए जाने
व इसका अनुपालन न करने पर अनुबंध को तत्काल समाप्त करने और क्वनून के अनुसार आगे की कानूनी कार्रवाई का आधार होगा | terms
of GeM GTC clause 26 regarding Restrictions on procurement from # ७४567 01 8 ८०७०॥०१ which shares a land border with india, any bidder from a country which shares a
land border with India will be efigible to bid in this tender only If the bidder is registered with the Competent Authority, While participating in bid, Bidder fas ta undertake
compliance of this and any false declaration and non-compliance of this would be # ground for Mmmediate termination of the contract end further tegal action in
accordance with the laws,

---q-wara/Thank You---
919

<!-- page 10 -->

Ne)
.
۱ Canteen Menu
/ Sr. Item Minimum Quantity / Weight / Unit Rate
| fe. | Volume Quoted by
| | Bidder (?)
1. Tea _ 150 ml | Per Cup |
2. | Coffee (Milk) _ 150 ml | Per Cup
13. Black Coffee 150 mi = [ Per Cupp _t
4, GreenTea "150 ml 2 | Per Cup ٠
5, Lemon Tea 150 ml {Pe Ci }
6, | Milk Shakes 250 ml_ pe /ए7“7ः
‏ما‎ 250 ml हे नल |
‏و‎ Milk ۱. ‏ع۱209‎ ee एफ
9, Fresh Lemon Water _| 200 ml [Bee
10, | Sweet Lassi 007 __ ‏]ھا گا‎
वी. Salted Lassi__ 200 mi ——— a
12. | Fruit Chat _ 196 (250 8) ——T Per Piste [ -
113. | Poori chana = ‏کت۱20‎ = +e ‏لے ول‎
114, [Simple Maggi___| 1 Plate (150 ‏(ع‎ (Maggi Noodles) _—__— ‏.ا کت‎
“5. | Onion & Tomato Maggi 1 lat (150g) Gag ‏للہا‎ + Onion Per |
___ |e Temato) ‏۔_. .لے مس یتو‎
‏ےا‎ Veg Poha 250 g (Poha 150 g + 100 g Onion + Per Plate |
"| Potato + Green Peas + Peanuts) _ ‏ہے لا سے‎ —
‘7. Samosa = ‏ہے تفص اس وہ‎ —__|PerPiate |. ‏لب‎
‎वह Aloo Tiklc with chana | 2 Pieces (120 g each) = | Per Plate ._ ‏_۔‎ _
(19. Bread Pakora |2 slices (50-60 8), Besan coating: 50 | Per Piece
| 60 g, Potato stuffing & spices: 30-40 2 | =
20. | Veg Cutlet 1100 g (2 pes) Half Plate ___|
21. Bread Butter |2 bread slices (approximately 50-70 g) | 2 Slices
‏سد کر‎ een orm ‏۳ئ‎ | + butter ache __}
22. | Bread Jam 2 bread slices (approximately 50-70 g) |2Slices ۹‫
ee + Jam ‏1پ تپ‎
‏کت بے سس ہے کسی سج‎ 200 ¢) PerPlate |
‘2A Prin hCard 1 Ho. 50 Sandwich | 4 Triangular Pieces (200 g) _ Per Plate ۱
25. ‏بت‎ 9 1 No. (250 g) (Paratha + Curd+ Pickle) | Per Plate 7"
| + Pickle |
‏ہے۔ ہے سے‎ (Paratha + Curd+ Pickle) |PerPlate |
. _ Curd & Pickle | 2 Ye |
‏۔‎ Mix Vegetable Paratha | 1 No. (250 a + Curd+ Pick 1
‏سااللسسسشممسساسسیتا ےت تہ ھا‎ |
28. Paneer Paratha Se Se ae ———
ao ee | eee
| 25 | Pisin Rice 300 g (Cooked Rice) PullPlate ۱
oe ‏.سد سوب‎
۰ wit (Kadi ‏ہے ےےل سس ٹس‎
236 ‏إ____ِ۔۔‎ 2008 02۶ Cooked Rice) |Full Plate 1
‏حر ھت کہ وہ‎ 2छ82४+0प७०४+0०्णवव्वस़्ल [|
33. Rajma with Rice 300 g (Cooked Rice + Cooked Raima) एप छत ..]्.ः
‏اٹ سض‎ ee (Cooked Rice + Cooked Rajma) | Full Plate |
34. | Rajma with Rice | 200 g (Rice + Cooked Rajma) ‏سٹھتا_۔‎ |
35. [Veg Pulao __ 300g (Cooked Vez Pulao) ۰ {Pull Pate | 77
