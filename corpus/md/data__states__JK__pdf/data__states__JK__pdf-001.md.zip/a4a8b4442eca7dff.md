---
doc_id: "a4a8b4442eca7dff"
source_url: "https://jkpolice.gov.in/WebImages/WELFAREORDERNO.3512OF2023.pdf"
ministry: "Jammu and Kashmir Police, Jammu and Kashmir"
title: "Grant of Welfare Loan/Relief"
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "e5a4232f6b17b069"
---

<!-- page 1 -->

- 0 /281/2023-33- & )
1853/2023 iy
POLICE HEADQUARTERS ®24J&K JAMMU | SRINAGAR
Phone/ Fax No. 0194-2443033 (Sgr) Website: www.jkpolice.gov.in

0191-2450026 (jmu) Email: phajk@jkpolice.gov.in
Subject: - Grant of Welfare LoaniRelief.

ORDER NO: 2S 12 OF 2023
DATED: 1% / {~~ -2023

Sanction is hereby accorded to the grant of welfare loan of Rs.3,00,000/- (Rupees
three lakh only) & welfare relief of Rs.50,000/- (Rupees fifty thousand only) out of Central Police
Welfare Fund in favour of Ct. Muzamil Ahmad No.1681/PL, PID No. EXK156072 of District
Police Pulwama to meet the expenses in connection with treatment of his minor daughter,
suffering from a chronic disease ( Liver cirrhosis)

The amount of welfare loan shall be recovered @ Rs.10,000/- per month from the
loanee by concerned DDO and will remit the same to AIG of Police (Welfare) PHQ J&K on monthly
basis.

Sd/-
(R.R. Swain}IPS
Director Generat of Police,
J&K Jammu.
No, AIG(W)-LR-e-281/2023
Copy to the: -
1. IGP Kashmir Zone, Srinagar for favour of information.
2. SSP Pulwama for necessary action. This has reference to his office letter No.GBW-
1/2023/25916 dated 05.12.2023
3. in-charge Acctts. (Welfare) PHQ for necessary action. He will ensure timely release of Rs.3.50
lakh for early disbursement to the beneficiary.
4. OBN/Master File. Signed by
Abhishek Mahajan
Date: 15-12-2023 14:06:53
AIG of Police (Welfare)
For Director General of Police,
J&K Jammu.
