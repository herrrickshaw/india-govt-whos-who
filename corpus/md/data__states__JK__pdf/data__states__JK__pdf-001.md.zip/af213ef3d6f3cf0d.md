---
doc_id: "af213ef3d6f3cf0d"
source_url: "https://cdn.s3waas.gov.in/s3ae0eb3eed39d2bcef4622b2499a05fe6/uploads/2021/04/2021042425.pdf"
ministry: "Ramban"
title: "Imposition of Restriction under order 144 Cr.P.C. from 08:00pm on 24.04.2021 to 06:00 am on 26.04.2021"
date: ""
pages: 2
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "a73cb38b788e6b77"
---

<!-- page 1 -->

GOVERNMENT OF JAMMU & KASHMIR
OFFICE OF CHAIRPERSON, DISTRICT DISASTER MANAGMENT AUTHORITY
(DISTRICT MAGISTRATE), RAMBAN
Sub: Measures to prevent spread of Coronavirus - Imposition of of
restrictions under Section 144 Cr.P.C in the District thereot thereof.
ORDER

Whereas, necessary precautions regarding prevention and control of
Coronavirus (COVID-19) infection have already been undertaken by the
District Administration in coordination with Police and Health Departments,
and

Whereas, COVID-19 has pattern of transmission at rapid rate, in case
prescribed prevention protocols, including mass gathering and unnecessary
movement etc, are not strictly followed; and

Whereas, following issue of advisories by the Health authorities to
prevent the spread of COVID-19 pandemic and break the transmission
chain of the virus in the district, it has become necessary to enforce certain
restrictions.

Now, therefore in view of the above-mentioned facts and in the
interest of safety and well-being of the general public at large, I,
Mussarat Islam, KAS, District Magistrate and Chairperson, District
Disaster Management Authority, Ramban, in exercise of the powers
vested in me under Section 144 Cr.P.C, Section 34 of National Disaster

Cee Management Act, 2005 and in accordance with Section 2 of the Epidemic
22: Diseases Act, 1897, do hereby impose complete ban on movement of
~ individuals for all non-essential activities from 8.00 pm on 24.04.2021
(Saturday) to 6.00 am on 26.04.2021 (Monday) in the territorial jurisdiction
of District Ramban. However, essential/ emergency services/ movement/
work and scheduled marriages up to permissible gathering norms shall

remain exempted, subject to production of wedding cards/ ID cards etc.

Furthermore, in continuation to the Government Order No.21-
JK(DMRRR) of 2021, dated 18.04.2021, the Technical Training Institutions
falling under the Department of Skill Development/ Technical Education in
the territorial jurisdiction of District Ramban shall remain closed on
campus/ in person education till 15.05.2021. Online education shall be the
mode of teaching.

Besides, during the closure of educational institutions (schools/
colleges/ technical education institutions), attendance of the staff in person
shall be restricted to 50% only. Heads of the Institutions shall devise roster
to ensure implementation of this order.

ca Ciel a errr rename ted
Scanned with CamScanner

<!-- page 2 -->

The gathering limit as ordered vide earlier Government Order No.21-
JK (DMRRR) of 2021, dated 18.04.2021, shall continue to remain in force.
Superintendent of Police, Ramban, shall ensure overall enforcement
of the above orders in letter & spirit.
Any violation of this order shall invite action under Indian Penal
Code/ Disaster Management Act, 2005 and Epidemic Diseases Act, 1897.
Issued today on 24" day of April, 2021 under my seal and
signature.
No:DCR/COVID-19/3311-30
Dated: 24.04.2021 3
Cea
Sarg oa) 2
‏آم2 بای ہاے‎
Mussarat Islam,
Chairperson, District Disaster Management Authority
(District Magistrate),
Ramban
Copy to:
1. Chief Secretary, J&K, Civil Secretariat, Jammu, for information.
2. Principal Secretary to the Government, Home Department, Civil
Secretariat, Jammu.
3. Divisional Commissioner, Jammu, for information.
4. Inspector General of Police, Jammu, for information.
5. Senior Superintendent of Police, Traffic (NHW), Ramban for
information & necessary action.
6. Superintendent of Police, Ramban, for information & necessary
action.
7. Additional District Magistrate, Ramban, for information and necessary
action.
8. Assistant Commissioner, (Revenue), Ramban, for information.
9. SDM, Banihal/ Gool/ Ramsoo for information and n/a.
10.Chief Medical Officer, Ramban, for information.
11.Tehsildar (All), District Ramban, for information & n/a.
12.SHO Police station (All), District Ramban for info. & n/a
13. District Information Officer, Ramban for vide circulation of the Order
in print & electronic media.
14.DIO, NIC, Ramban for placing a copy of this order on the Official
Website of the District.
Scanned with CamScanner
