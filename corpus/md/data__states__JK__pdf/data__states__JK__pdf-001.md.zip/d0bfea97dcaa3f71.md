---
doc_id: "d0bfea97dcaa3f71"
source_url: "https://fcsca.jk.gov.in/pdf/orders/eCompendium_2023.pdf"
ministry: "Department of Food, Civil Supplies & Consumer Affairs, Jammu & Kashmir"
title: "e-compendium of the achievements"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "da20a49afda7f3ad"
---

<!-- page 1 -->

e-compendium

of the achievements

DEPARTMENT OF FOOD, CIVIL SUPPLIES AND CONSUMER AFFAIRS, J&K.

<!-- page 2 -->

COVERAGE UNDER PUBLIC DISTRIBUTION SYSTEM
IMPROVING EFFICIENCY

The Department of Food, Civil
Supplies & Consumer Affairs is
providing free and subsidized food
grains to 25 lac households,
comprising 98 lac beneficiaries.
66,56, 907 beneficiaries , covered
under NFSA, are provided free food
grains while 31,55,292 beneficiaries
are provided food grains at highly
subsidized rate in NPHH group.

The Department through
reforms and technology
interventions has aspired to
make Public Distribution
System credible, transparent
and convenient for the
beneficiaries.

Additionally, the Department
has also been providing
additional top-up, upto 10 Kgs
per month, to Priority
Househelds under Prime
Minister's Food
Supplementation for Priority
Households Scheme .

Distribution of 100% fortified
rice across all the districts of
Jammu and Kashmir has
started from October, 2023,
under NFSA.

Effective statutory
mechanisms have been
put in place to take care
of PDS operations for
larger public good.

After establishing a State
Consumer Commission and ten
District Consumer
Commissions, e-daakhil has
been launched to help the
consumers to file complaints in
an online mode in various
Consumer Commissions.

DEPARTMENT OF FOOD, CIVIL SUPPLIES AND CONSUMER AFFAIRS, J&K.

<!-- page 3 -->

EFFICIENT PUBLIC DISTRIBUTION SYSTEM
ELIMINATING LEAKAGE AND IMPROVING TRANSPARENCY AND EFFICIENCY

Aadhaar Seeding
Beneficiary level

100%
Ration Card level

100%

All 6735 sale
centers
automated.

6,413
out of 6735
PoS devices
converted to
online status.

94%
of PDS
transactions
made online and
food grains are
drawn by the
beneficiaries
through aadhaar
authentication.

(All Categories)

ONORC Scheme
implemented

70,105
ONORC and

20,54,307
portability
transactions made
till now.

Prime Minister's Food Supplementation for Priority Households
Scheme launched to further augment food requirements of Priority
Households.
DEPARTMENT OF FOOD, CIVIL SUPPLIES AND CONSUMER AFFAIRS, J&K.

More than 1 Million
deletions made under
De-duplication Exercise.
89427 genuine
households added to
PDS.

<!-- page 4 -->

STATUS OF PDS REFORMS IN J&K
STRIVING TO BE EFFICIENT THROUGH TECHNOLOGY INTERVENTIONS
1.

Digitization
of Ration Cards/ Beneficiaries.

100%

2.

Adhaar seeding status
of Ration Cards & Beneficiaries at all levels.

100%

3.

Automation
of Fair Price Shops (installation of ePoS devices)

100%

4.

Tracking
of Supply Chain Management of foodgrains

97%

5.

Aadhaar/OTP authenticated transactions

94%

DEPARTMENT OF FOOD, CIVIL SUPPLIES AND CONSUMER AFFAIRS, J&K.

<!-- page 5 -->

EFFORTS AT A GLANCE
FOR CONVENIENCE OF BENEFICIARIES
98 lakhs beneficiaries
(25 lakh households)

1.

Total Coverage under PDS

2.

No. of ration cards added under NFSA

3.

No. of POS devices working in Online mode

4.

ONORC transactions

70,105

5.

Portability transactions

20,54,307

6.

Nominee policy availed by households

9346

7.

Bogus/duplicate beneficiaries removed

Above 1 Million

DEPARTMENT OF FOOD, CIVIL SUPPLIES AND CONSUMER AFFAIRS, J&K.

89427
(4051 – AAY, 85376 – PHH)

6413 out of 6735
