---
doc_id: "fd7ff8f4acd19cd6"
source_url: "https://cdn.s3waas.gov.in/s302a32ad2669e6fe298e607fe7cc0e1a0/uploads/2019/01/2019012324.pdf"
ministry: "Kupwara"
title: "LaQshya- Labour Room Quality Improvement Initiative Guideline (3 MB)"
date: ""
pages: 60
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6203c9456938ce39"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

HEALTH M
O
ISSI N

NATION

AL

<!-- page 4 -->

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

<!-- page 12 -->

<!-- page 13 -->

<!-- page 14 -->

<!-- page 15 -->

<!-- page 16 -->

<!-- page 17 -->

Table of Contents

1. Introduction ............................................................................................................................................1
2. Goal ..........................................................................................................................................................3
3. Strategies ..................................................................................................................................................4
4. Scope ........................................................................................................................................................5
5. Institutional Arrangement .....................................................................................................................6
6. Targets ......................................................................................................................................................9
7. Interventions .........................................................................................................................................11
8. Phasing of Activities ............................................................................................................................15
9. Certification, Incentives & Branding .................................................................................................18
10. Financial Arrangements .......................................................................................................................19
11. Roles & Responsibilities ......................................................................................................................20
12. Monitoring and Reporting ..................................................................................................................21
Annexures .....................................................................................................................................................22
Annexure ‘A’ ..........................................................................................................................................22
Annexure ‘B’..........................................................................................................................................23
Annexure ‘C’..........................................................................................................................................24
Annexure ‘D’ .........................................................................................................................................26
List of Abbreviations ...........................................................................................................................34
List of Contributors .............................................................................................................................36

LaQshya - Labour Room Quality Improvement Initiative | 2017 xv

<!-- page 18 -->

<!-- page 19 -->

1

Introduction

After launch of the National Health Mission
(NHM), there has been substantial increase
in the number of institutional deliveries.
However, this increase in the numbers has not
resulted into commensurate improvements
in the key maternal and new-born health
indicators. It is estimated that approximately
46% maternal deaths, over 40% stillbirths and
40% newborn deaths take place on the day of
the delivery.
A transformational change in the processes
related to the care during the delivery, which
essentially relates to intrapartum and immediate
postpartum care, is required to achieve tangible
results within short period of time. Prerequisite
of such approach would also hinge upon the
health system’s preparedness for prompt
identification and management of maternal
and newborn complications. Delivery of
such transformed care would not only need
availability of adequate infrastructure, functional
& calibrated equipment, drugs & supplies &
HR, but also meticulous adherence to clinical
protocols by the service providers at the health
facilities.
Pregnant women are often meted out rude
and uncourteous treatment at the health

facilities. Respectful maternity care1 not only
contributes in ensuring positive outcomes for
the mothers and newborns, but also supports
cognitive development of the babies later in
the life. Curtailing period of the labour by use
of oxytocic drugs adversely impacts natural
secretion of hormones and physiological
mechanism that contribute to the cognitive
development. Determinants impacting health
and well-being of mothers & newborns during
the intrapartum & immediate post-partum
period are shown in Annexure ‘A’.
Do’s and don’ts in the labour rooms as
given in Table 1 are expected to support
improved outcome for the maternal and
newborn health.
For improving the quality of care at Public
Health Facilities, Quality Assurance Standards for
District Hospitals, Community Health Centres,
Primary Health Centre and Urban-Primary
Health Centres have been drafted, and their
implementation has been operationalised through
the National Quality Assurance Programme.
1

Respectful care includes respect for women’s autonomy,
dignity, feelings, privacy, choices, freedom from ill treatment &
coercion and consideration for personal preferences including
option for companionship during the maternity care.

LaQshya - Labour Room Quality Improvement Initiative | 2017

1

<!-- page 20 -->

Table 1: Do’s & Don’ts of Labour Room
Do’s
y Providing privacy

to pregnant
women during the
intrapartum period,
by way of separate
labour room or
at least a private
cubicle
y Presence of birth

companion during
the labour
y Freedom to choose a

Don’ts
y Induction and

augmentation of
labour without
sound clinical
indications
y Any verbal or

physical abuse of
the pregnant women
y Insisting on

conventional
lithotomy position
for the delivery

comfortable position
y Immediate clamping
during birthing
and cutting of the
(squatting, standing,
umbilical cord
etc.)
y Separating baby
y Adherence to
from the mother
Clinical protocols
for routine care &
for management of
procedure
labour
y ‘Out of Pocket
y Use of Labour beds
Expenditures
instead of tables
(OOPE) on
y Place baby on
drugs, diagnostics,
mother’s abdomen
including demand
by the staff for
y Initiation of Breast
gratuitous payment
feeding within one
by families for
hour of birth
celebration of the
baby’s birth.
While states are in the process of implementing
Quality Management System using National
Quality Assurance Standards (NQAS) to
obtain certification of the health facilities, the
process takes substantial time and effort. While

2 LaQshya - Labour Room Quality Improvement Initiative | 2017

the states should continue to work towards
achieving full NQAS certification of the health
facilities, LaQshya Guidelines are intended for
achieving improvements in the intra-partum
and immediate post-partum care, which are
take place in the labour room and maternity
operation theatre.
Implementation of these guidelines is expected
to result into delivery of respectful and zerodefect care to all pregnant women and newborns,
and such improvement is incentivised.
The states are also expected to accelerate
efforts for upgradation of conventional labour
rooms as per norms given in ‘Guidelines for
Standardisation of Labour Rooms at Delivery
Points’, and establish HDUs as per norms given
in the ‘Guidelines for Obstetric HDUs and
ICUs’.
Medical College Hospitals handle substantial
maternal and newborn caseloads, besides
imparting teaching and training the doctors,
specialists, nurses and para-medical staff.
This initiative will also be implemented in all
Government Medical Colleges (MCs) besides
District Hospitals (DHs), and high delivery load
CHCs and SDHs.
These guidelines are meant to help the
States’ NHM Directors, Medical Education
Departments, Heads of Department of
Obstetrics & Gynaecology in Medical
Colleges, District Health Officials, Medical
Superintendents, In-charge of Gynaecology
departments and teams engaged in the
maternity care.

<!-- page 21 -->

Goal

Reduce preventable maternal and newborn
mortality, morbidity and stillbirths associated
with the care around delivery in Labour room
and Maternity OT and ensure respectful
maternity care.

Objectives
1. To reduce maternal and newborn
mortality & morbidity due to APH, PPH,
retained placenta, preterm, preeclampsia
& eclampsia, obstructed labour, puerperal
sepsis, newborn asphyxia, and sepsis, etc.

2
2. To improve Quality of care during the
delivery and immediate post-partum
care, stabilization of complications
and ensure timely referrals, and
enable an effective two-way follow-up
system.
3. To
enhance
satisfaction
of
beneficiaries visiting the health
facilities and provide Respectful
Maternity Care (RMC) to all pregnant
women attending the public health
facility.

LaQshya - Labour Room Quality Improvement Initiative | 2017

3

<!-- page 22 -->

3

Strategies

1. Reorganizing/aligning Labour room
& Maternity Operation Theatre layout
and workflow as per ‘Labour Room
Standardization
Guidelines’
and
‘Maternal & Newborn Health Toolkit’
issued by the Ministry of Health &
Family Welfare, Government of India.
2. Ensuring that at least all government
medical college hospitals and high case-

4 LaQshya - Labour Room Quality Improvement Initiative | 2017

load district hospitals have dedicated
obstetric HDUs as per GoI MOHFW
Guidelines, for managing complicated
pregnancies that require life-saving
critical care.
3. Ensuring strict adherence to clinical
protocols for management and
stabilization of the complications before
referral to higher centres.

<!-- page 23 -->

Scope

Following facilities would be taken under
LaQshya initiative on priority:
y All government medical college hospitals.

4
y All designated FRUs and high case load

CHCs with over 100 deliveries/60 (per
month) in hills and desert areas.

y All District Hospitals & equivalent health

facilities.

LaQshya - Labour Room Quality Improvement Initiative | 2017

5

<!-- page 24 -->

5 Institutional Arrangement
Under the National Health Mission, the States
have been supported in creating Institutional
framework for the Quality Assurance - State
Quality Assurance Committee (SQAC), District
Quality Assurance Committee (DQAC),
and Quality Team at the facility level. These
committees will also support implementation
of LaQshya interventions. For specific technical
activities and program management, special
purpose groups have been suggested, and these
groups will be working towards achievement
of specific targets and program milestones
in close coordination with relevant structures

within the QA organizational framework.
Outlines of Institutional arrangement under
LaQshya is given in Figure 1.

(a) National Level
y National Mentoring Group would include

members of the Programme Divisions,
IEC Division, NHSRC, NIHFW, AIIMS,
and Medical Colleges, Nursing collages,
Schools of Public Health, Professional
Associations, Hospital Planners, IT
professionals, Development Partners,

Figure 1: Institutional Arrangement under NQAP & LaQshya
Level

Quality Structure

Quality Drivers

National Level

CQSC

National
Mentoring Group

State Level

SQAC

State
Mentoring Group

District Level

DQAC

Coaching Team

Facility Level

Quality Team

Quality Circle (LR & OT)

6 LaQshya - Labour Room Quality Improvement Initiative | 2017

<!-- page 25 -->

Empanelled external assessors & eminent
professionals.

Responsibilities
i.

Responsibilities

Periodic visit to the states, and to a
sample of the health facilities.

ii. Orientation and training.
iii. Standardization of skill based training
programs.
iv. Development of
material.
v.

IEC & resource

Monitoring & evaluation.

vi. Recommend mid-course correction.
vii. Video conference with the QC teams and
review of the MDSR/Maternal Near
Miss review and NMR/Stillbirth review
programmes.

(b) State Level
State NHM, Departments of Health and
Medical Education would jointly create
institutional arrangement for seamless flow of
support and removal of the bottle-necks, if any
for implementation of this initiative.
Mentoring Group – State
Mission Director would constitute the
State mentoring group, consisting of
programme officers, suitable faculty
of AIIMS and other eminent National
Institutions and medical education
department, State Nodal Officers for
Quality, IEC, procurement, infrastructure,

y State

State Level Development Partners and
eminent professionals.

i.

Visit to the facilities and ‘on-site’ support
for under performing facilities.

ii. Training & mentoring of the coaching
teams.
iii. Customisation and approval of SOPs &
Work-instructions.
iv. Performance monitoring.
v.

Mobilisation of State level support
including providing inputs for the State
PIP.

vi. Presentation of Status report to the
SQAC.
vii. Identification of innovations
promoting their replication.

and

viii. Undertake MDSR & CDR.
ix. Assessment and modification of the
referral directories prepared by the
districts.
x. Tracking & reporting of Indicators.

(c) District Level
Coaching Team- An external multidisciplinary
team, responsible for mentoring one or more
labour rooms, would comprise of District
family welfare officer/RCHO (equivalent),
district/divisional quality consultants, nursing
instructors/mentors from the functional skill

LaQshya - Labour Room Quality Improvement Initiative | 2017

7

<!-- page 26 -->

labs, faculty of nearest medical colleges and
representatives of professional associations
and development partners. The coaching team
in districts with medical college could include
one or more retired faculty members as a coach
for medical college labour rooms and operation
theatre. In the early phases, one coaching team
could mentor four or five districts since training
every district coaching team in a short span of
time may not be possible. All coaching teams
must be trained in skills lab/Dakshata, so that
they are proficient mentors.

ix. Peer assessment & support for the NQAS
Certification.

(d) Facility Level
y Quality Circle : Quality circles are informal

groups of the staff in each department that
works closely to improve the QOC there.
For example, Quality circle in a labour
room would involve of Gynaecologist,
Paediatrician, Matrons and Nursing Staff &
Support Staff. In the Operational theatre,
anaesthetist would also be a member of the
Quality circle. The Quality Circles will work
in coordination with facility level quality
team headed by the Medical Superintendent
or facility incharge.

Responsibilities
i.

Mentoring of the Quality circles, Support
for the campaign and its monitoring.

ii. Periodic Internal review Monthly visits
of coaching/support teams for hand
holding, problem solving, and verifying
reported quality indicators.
iii. To provide ‘hands-on’ training on clinical
protocols.
iv. Hand-hold the quality improvement
process.
v.

Monitoring of availability of point
of care diagnostic services and blood
transfusion services.

Responsibilities
i.

Ensuring Adherence to Protocols &
Clinical guidelines.

ii. Assessment of Labour room & operation
theatre using the NQAS Departmental
Check-lists.
iii. Prioritisation and Action planning for
closure of gaps as per ‘Maternal and
Newborn Health Toolkit’ and ‘Guidelines
for Standardisation of Labour Rooms at
Delivery Points’.

vi. OSCE based assessment of the staff.

iv. Management of ‘Campaign’/‘Rapid
Improvement Cycle’.

vii. Development of referral directory.

v.

viii. Sample verification of the indicators.

8 LaQshya - Labour Room Quality Improvement Initiative | 2017

Collation of data elements, required for
monitoring Indicators.

<!-- page 27 -->

6

Targets

Immediate (0-4 Months)
1. 80% of the selected Labour rooms &
Maternity OTs assess their quality and
staff competence using defined NQAS
checklists and OSCE.
2. 80% of Labour rooms & Maternity OTs
have setup functional quality circles and
facility level quality teams.

Short Term (up to 8 Months)
1. 80% of Labour Room and OT Quality
Circles are oriented to latest labour room
protocols, quality improvement processes
and respectful maternity care (RMC).
2. 50% of deliveries take place in presence
of the Birth Companions.
3. 60% of deliveries conducted using
safe birth checklist and Safe Surgery
Checklist in Labour Room & Maternity
OT respectively.
4. 60% of the deliveries are conducted
using real-time par to graph.
5. 30% increase in Breast Feeding within
one hour of delivery.

6. 80% labour rooms and Maternity OTs
take microbiological samples from
defined areas every month.
7. 30% reduction in surgical site infection
ratein r/o planned surgery in the
Maternity OT.

Intermediate Term
(Up to 12 Months)
1. 30% increase in antenatal corticosteroid
administration in case of preterm labour.
2. 30% reduction in pre-eclampsia,
eclampsia& PIH related mortality.
3. 30% reduction in APH/PPH related
mortality.
4. 20% reduction in new-born asphyxia
related admissions in SNCUs for inborn
deliveries.
5. 20% reduction in newborn sepsis rate in
SNCUs for inborn deliveries.
6. 20% reduction in Stillbirth rate.
7. 80% of all beneficiaries are either satisfied
or highly satisfied.

LaQshya - Labour Room Quality Improvement Initiative | 2017

9

<!-- page 28 -->

8. 60% of the labour rooms are reorganized
as per ‘Guidelines for Standardisation of
Labour Rooms at Delivery Points’.
9. 80% of labour rooms have staffing as
per defined norms.
10. 100% compliance to administration of
Oxytocin, immediately after birth.
11. 30% improvement in OSCE scores of
labour room staff.
12. 100% Maternal death, Neonatal
Death audit and clinical discussion
on near miss/maternal and neonatal
complications.

10 LaQshya - Labour Room Quality Improvement Initiative | 2017

13. 80% Labour Room and OTs are
reporting zero stock-outs of drugs and
consumables.

Long Term (up to 18 Months)
1. 60% of labour rooms achieve quality
certification against the NQAS.
2. 50% of labour rooms are linked to
Obstetrics HDU/ICU.
3. 15% improvement in short term &
Intermediate targets.
After 18 months, this initiative would be
continued through sustained mentoring.

<!-- page 29 -->

7

Interventions

Key approach under this initiative is
breakthrough improvement using business
process re-engineering concepts. This would
require substantial reorganization of labour
room structure (Infrastructure, HR, and Drugs
& Equipment) and processes. Summary of
interventions is given in Figure 2.

a) Upgrading the infrastructure as per norm
& realistic case-load.

Structural improvement will include the
following :

d) Strengthening the supply chain system
of drugs & consumables for ensuring

b) Human Resource augmentation and skill
upgradation.
c) Ensuring availability of adequate functional
& calibrated equipment, as per need.

Figure 2: Components of QOC Improvement in Labour Room
Assessment

Baseline
Assessment
(using Guidelines
for LR
Standardisation,
MNH Toolkit &
NQAS)

Improvement
Dimensions

Structural
Improvement

Enablers

Labour Room
Standardisation
Human Resource
Strengthing

Quality Circles
Process
Improvement

Outcome

Rapid
Improvement
Cycles-Campaign

Labour Room
Certification
Improved
Maternal health
stillbirth &
Newborn Health
Indicators

LaQshya - Labour Room Quality Improvement Initiative | 2017 11

<!-- page 30 -->

their availability in the labour room and
OT as per need.
Process improvement will include :
a) Assessment and Triage
b) Management of Labour including Active
Management of Third stage of labour.
c) Management of complications and HighRisk Pregnancies.
d) Management of referral services.
e) Perioperative processes for C-Section.

2. Ensuring skill assessment of all
staff of LR & Maternal OT through
OSCE (Objective Structured Clinical
Examination) testing as per Dakshata
guidelines for delivery of ‘zero-defect’
quality obstetric and newborn care.
Enhance proficiency of labour room and
operation theatre staff for management
of the complications through skill-lab
training, simulations and drills. Ensuring
that staff working in the labour room
and maternity OT are not shifted from
maternity duty to other departments/
wards frequently.

g) Management of required support
services for the Labour room, Maternity
OT & HDU.

3. Sensitising care-providers for delivery
of respectful maternity care and close
monitoring of language, behaviour and
conduct of the labour room, OT &
HDU Staff.

h) Sensitisation of the Staff on RMC and
its monitoring.

4. Creating an enabling environment for
natural birthing process.

It would be ensured that quality circles at the
departments and support groups (Quality team
& coaching team) work in harmony for solving
the problems and take all possible actions for
the closure of gaps.

5. Implementation of Clinical Guidelines,
Labour Room Clinical Pathways, Referral
Protocols, safe birth checklist (in labour
room and Obstetric OT) and surgical
safety check-list.

Interventions

6. Ensuring round the clock availability of
Blood transfusion services, diagnostic
services, drugs & consumables.

f)

Newborn care and resuscitation.

1. Ensuring availability of optimal and
skilled human resources as per case-load
and prevalent norms through rational
deployment and skill upgradation.
Suggested HR for the labour room is
given in Annexure ‘B’.
12 LaQshya - Labour Room Quality Improvement Initiative | 2017

7. Ensuring availability of triage area and
functional newborn care area.
8. Ensuring systematic facility-level audit
of all cases of maternal/neonatal
deaths, stillbirth, and maternal near

<!-- page 31 -->

miss etc. including with their mentor
teams through clinical discussions,
peer reviews in teaching institutes,
Videoconference, or other distance
mode mechanisms for continuous
improvement and learning.
9. Operationalisation of ‘C’ Section audit
and corrective & preventive actions for
ensuring that ‘C’ Sections are undertaken
judiciously in those cases having robust
clinical indications.
10. Instituting an ongoing system of
capturing of beneficiaries’ independent
feedback through mechanism ‘MeraAspataal’ or manual recording, or
Grievance Redressal Help Desk and
take action to address concerns,
for continual enhancement in their
satisfaction.
11. Ensuring availability of essential support
services such as 24x7 running water,
electricity, housekeeping, linen and
laundry, security, equipment maintenance,
laboratory services, dietary services,
BMW management, etc.
12. Use of digital technology for record
keeping & monitoring for maternity wing
(MIS), including use of E partograph.
Piloting of technology for managing
care, such as Computer on Wheel,
Computerised Physician Order Entry.
13. Use aggressive IEC, user friendly training
material and IT-enabled tools. Facilitating
branding of all high case load facilities

meeting quality standards to improve
visibility and awareness.
14. Using Quality tools for prioritisation,
and gap closure such as Plan Do Check
Act (PDCA), Root Cause Analysis,
Run Charts, Pareto chart and Mistake
Proofing for achieving desired targets.
15. Rapid Improvement Events - Six cycles
of two months each as defined below
will need to be rigorously supervised and
ensured. This will enable competency
in all critical skills needed. For each
area, a targeted campaign would be
launched for a two month duration,
with the first month for the roll-out,
followed by sustaining such efforts
during the subsequent month (Period
for one event – 2 months). Suggested
list of the themes for campaigns is given
below :
a) Cycle 1: Real-time Partograph
generation including shift to electronic
partograph & usage of safe birth
check-list & surgical safety check-list
and strengthening documentation
practices for generating robust data for
driving improvement.
b) Cycle 2: Presence of Birth companion
during delivery, respectful maternity
care and enhancement of patients’
satisfaction.
c) Cycle 3: Assessment, Triage and timely
management of complications including
strengthening of referral protocols.
LaQshya - Labour Room Quality Improvement Initiative | 2017 13

<!-- page 32 -->

d) Cycle 4: Management of Labour as per
protocols including AMTSL & rational
use of Oxytocin.

including management of birth asphyxia
and timely initiation of breast feeding as
well as KMC for preterm newborn.

e) Cycle 5: Essential and emergency
care of Newborn & Pre-term babies

f) Cycle 6: Infection Prevention including
Biomedical Waste Management.

14 LaQshya - Labour Room Quality Improvement Initiative | 2017

<!-- page 33 -->

8

Phasing of Activities

Activities under LaQshya are divided into four
phases, as shown in Figure 3.

a. Preparatory Phase - 2 Months
This will include
i.

Launch and dissemination of
scheme.

the

ii. Identification of members for National
mentoring group and operationalisation
of the group.

iii. National level orientation workshop of
national resource team and state nodal
officers.
iv. Issue of the instructions to the State and
district stakeholders.
v.

Formation of state mentoring group.

vi. Identification and listing of facilities to
be included in the initiative.
vii. State level ToT of the Quality Coaches.
viii. Formation of Quality circles at the labour
rooms and Operation Theatres.

Figure 3: Summary of Activities

Preparatory Phase
2 Months
$Dissemination
$TeFormation
$Orientation
$ #s

Assessment Phase
2 Months
$t
$#
$ 
$Re 

Improvement Phase
12 Months
$  ov
#
$ 
 ovement
$Te!

Evaluation Phase
2 Months
$Ev 
hievements
$ #rtn
$"ards

LaQshya - Labour Room Quality Improvement Initiative | 2017 15

<!-- page 34 -->

ix. Assigning
partners.

states

to

development

b. Assessment Phase 2 Months

ix. Training of the staff in recording of
data elements for monitoring of the
indicators and implementation of Quality
Management System.
x. Ensuring availability of drugs & supplies.

Orientation of Quality Circles on Quality
Improvement and Clinical Protocols.

xi. Development of resource package for
monthly campaigns.

ii. Assessment of the Labour Rooms &
Maternity OT against National Quality
Standards.

xii. Initiation of Patients’ satisfaction survey
among all patients reporting in the labour
room & operation theatre.

iii. Planning for expansion of Labour rooms
as per ‘Guidelines for Standardisation of
Labour Rooms at Delivery Points’ and
upgradation the Maternity OT.

xiii. Development of IT platform for the
initiative or integration with existing IT
platform.

i.

iv. Preparation of time bound action plan,
based on the identified gaps.
v.

Planning for creation of Obstetrics HDU
as per recommendations of ‘Guidelines
for Obstetrics HDU & ICU’.

vi. Collation of requirements and resource
allocation through the PIP process under
the NHM.
vii. Mapping of referral facilities (type of
facility, distance & travel time, contact
details, availability of services including
facility for the blood transfusion,
availability of other specialities such
as Physician, Surgeon, Pathology &
Biochemistry lab & Ultrasound facility,
nearest tertiary care institution).
viii. Ensuring availability of updated version
of clinical protocols for end users and
training of labour room & OT staff.
16 LaQshya - Labour Room Quality Improvement Initiative | 2017

c. Improvement Phase 12 Months
i.

Launch of rapid improvement cycles.
Each cycle includes one month of
improvement and subsequent month of
consolidation and sustenance.

ii. Ensuring adherence to clinical protocols
& peer-mentoring.
iii. Establish Standard Operating Procedures
for labour rooms& maternity OT.
iv. Quality Circle understands the issues
regarding selected theme of alternate
month and will try to improve the
processes using quality improvement
methodology (Plan – DO – Check –Act)
cycle, and sustain them (Figure 4).
v.

Preparatory visit, followed by monthly
visits – Visits in the second month of

<!-- page 35 -->

Figure 4: PDCA Cycle & Enabling Activities
Training

IT Tools

HR

Quality Tools

Labour Room Quality Circle

Improvement
Theme

Plan

Assessment
Orientation
Action Plan
(MR)

Check Do

Last Week

1st Week

Act

Act
Check

Plan

Act
Check

Do

2nd Week

Plan
Do

Evaluation
Feedback
Sustainability
(MR)

3rd Week

Meeting
Quality
Objectives

4th Week

Labour Room Quality Circle
Evaluation

IEC/WI

each improvement cycle would be in last
week for performance review through
objective indicators. Support for the
forthcoming campaign would also be
extended during this visit.
vi. Documentation and photography of the
improvement.
vii. Observation and assessment of
processes, refresher & hands-on training,
demonstrations and hand-holding.

Supplies Mistake Proofing

deployment & skill upgradation in the
labour room & OT will go in parallel.
xi. Concurrent evaluation of quality
indicators by SQAC and MH Division/
NHSRC and feedback to quality circles.
xii. Analysis of Patients’ feedback and taking
actions for addressing the beneficiaries’
concerns.

d. Evaluation Phase - 2 Months

viii. IEC campaign for each improvement
cycle – This includes reading material/
brochure on the theme, short videos,
presentations, etc. disseminated through
social media/dedicated IT platform.

i.

Evaluation of the quality objectives and
indicators.

ii.

External Assessment & Quality certification
of labour rooms & Maternity OT.

ix. Collection and reporting of indicators
linked with quality objectives of
each cycle from quality circle to State
Mentoring Group & SQAC.

iii. Awards to best performing quality circles
and Coaching Teams.

x. Structural augmentation including rearranging the layout & human resource

v.

iv. National level
achievements.

dissemination

of

Development of Strategy for sustenance
and scaling-up.

LaQshya - Labour Room Quality Improvement Initiative | 2017 17

<!-- page 36 -->

9 Certification, Incentives & Branding
a. Quality Certification: The Labour Room
& Maternity OT Checklists developed
for NQAS, will be used as tools for the
assessment and certification. The external
assessment and certification will be done by
external assessors empanelled with NHSRC.
Certification will be valid for 3 years subject
to annual verification of the scores by the
State Quality Assurance Committee.

LaQshya facilities should endeavour to
introduce ‘Mera-Aspataal’ ICT based feedback
system. As an interim measure, feedback from
the beneficiaries may be taken manually.

b. Incentivisation: The teams in the Labour
rooms and Maternity OT’s at Medical Colleges,
District Hospitals and SDH/CHCs could be
given incentives of Rs. 6 Lakhs, 3 Lakhs and
2 Lakhs (for each department) respectively on
achievement of following criteria:

c. Branding : The achievement of quality
benchmarks should be used for branding of
the QoC at the health facility. This will give
sense of pride to the staff as well as provide
confidence to the community that they
are getting quality care at public hospitals.
The departments may be provided badges
(LaQshya Medal) based on the quality score,
achieved in the state level assessment.

This incentive is recognition of the good work
done by the quality circles and facility’s quality
team. This amount can be used as cash incentive
to the staff and also for the welfare activities.

y

Quality Certification of Labour Room
and/or OT as per protocol under the
NQAS.

y

Attainment of at least of 75% of
commensurate facility level targets and
its verification by the SQAC. List of
such verifiable indicators the facility,
its source and means of verification is
given in Annexure ‘C’.

Platinum Badge : Achieving more than
90% Score.

80% of the beneficiaries are either
satisfied or highly satisfied (or
Equivalent score > 4 on Likert scale).

These badges should be worn by the care
providers as well as prominently displayed at
relevant places in the hospitals.

y

18 LaQshya - Labour Room Quality Improvement Initiative | 2017

Gold Badge : Achieving More than 80% Score.
Silver Badge : Achieving more than 70% Score.

<!-- page 37 -->

Financial Arrangements

Based on Gap analysis, the state may budget
the resource requirements and request for
allocation of the funds in relevant financial
heads through the NHM PIPs. The PIP would
include proposals for strengthening the Labour
rooms & maternity OTs in the government
medical colleges as well.

10

Suggested activities for the budgetary support is
given in Box 1.
There will also be resource requirements for
organising trainings, assessment, mobility
support and other incidental expenses. The
State may request for allocation of the resources
through PIP under NHM.

Box 1. Suggestive List of Activities for support under the NHM
y

Restructuring & upgradation of labour room as per Labour Room Standardisation Guidelines

y

Upgradation of Maternity OT as per case load

y

Procurement of Equipment and Furniture

y

Creation of Obstetrics’ High Dependency Unit

y

Services of planning/architectural consultants

y

Additional qualified staff for labour room and OTs

y

IT Equipment and software

y

Signage, IEC, Displays etc.

y

Hiring of professionals (individuals and/or organisations) for preparation and execution of
improvement plans

y

Training support

y

Support under the JSSK

y

Health Innovations

LaQshya - Labour Room Quality Improvement Initiative | 2017 19

<!-- page 38 -->

11 Roles & Responsibilities
The initiative will be coordinated by the
Maternal Health Division and supported
by the Child Health Division and NHSRC.
Maternal Health Division will facilitate
preparation of resource package for the
labour room reorganization & standardization
and improvement in Quality of Care
(QOC), coordinate with the states &UT’s
for smooth roll out of the initiative, collate
quality scores and indicators, ensure synergy
with the development partners, review PIP
proposals for labour room & maternity OT
upgradation, creation of obstetric HDU
and staff augmentation. NHSRC would
coordinate quality certification activities
under this initiative, undertake documentation
of best & replicable practices for crosslearning and provide necessary support for
successful implementation of the programme.
Development partners may synergize their
activities for supporting the roll-out of the
scheme in their priority States, support
National& State Mentoring Groups, and
support development of technical resource
material as required.
A small project management unit may be
established with full time program managers
20 LaQshya - Labour Room Quality Improvement Initiative | 2017

and consultants at the national level for
coordination and intense monitoring of
activities in the States. This unit will keep track
of the scheduled activities, collate and analyse
the indictors, coordinate with the national
mentors and facilitate the training programs.
This unit will report to Deputy Commissioner
I/C
Maternal
Health
and
Advisor
QI NHSRC.
In the States, Maternal Health Program officer/
State Quality Assurance Nodal Officer may be
designated as nodal officer for implementation
of the initiative. Coordination with the
Medical Colleges through Medical Education
Department would be critical. Based on the
number of facilities under this initiative in first
phase, the states may hire a full-time project
manager.
At the district level, Maternal Health Nodal
officer & Nodal Officer for Quality Assurance
will be responsible for this implementing the
activities.
Details of activities, required to be undertaken
by different stakeholders are given in
Annexure ‘D’.

<!-- page 39 -->

Monitoring and Reporting

Under the LaQshya initiative, multiple
interventions are envisaged to be undertaken
within the stipulated time frame and impact of
interventions is required to be simultaneously
measured through verifiable indicators in real
time. Therefore, efficient reporting of status of
activities and achievement of targets are critical
for the success of initiative.
A dedicated data entry module and dashboard
may be created in this purpose. Many of these
indicators are already reported through HMIS,
Labour room, HIS and SNCU online system.

12

The data for these indictors can be directly pulled
from the respective systems. All indicators need
to be reported by facility on monthly basis after
verification from respective coaching teams.
Monitoring of the program activities
such as assessment, labour room & OT
reorganization, progress on establishing
HDU, trainings, visits of coaching teams etc.
Will be done through a dedicated web based
tracking system. This website will also host all
relevant guidelines, resource material, updates
and progress reports.

LaQshya - Labour Room Quality Improvement Initiative | 2017 21

<!-- page 40 -->

Annexures

Annexure ‘A’
Promoting Respectful Maternity Care & Cognitive Development of Baby
Comfortable
Position during Birthing

Birth
Companion

Encourage mothers to Walk,
Move around and Change
position during Labour

Educating Birth
companio

Avoid Direct Pushing

Coordinating Care

Let mother choose position
of comfort for birthing

Preventing Baby
swapping & theft

Modern Birthing
Furniture
Adequate circulation
area for moving
Washing Hands
and Drinking Water
Orientation of Care
Providers regarding
Birthing Position

Emotional Support
Assisting mother
for personal needs
Helping in Early
Initiation of breast
feeding
Helping shifting of
Mother & baby

Avoiding
Stress
Timely arrival to avoid
emergency stress
Positive interaction
with the care provider
Proper Triaging
on arrival
Assuring Mother that
Birth is a Natural Process
Avoiding Stress
triggering terms
Sensitizing LR team
to Respect the Natural
Process of Labour
Avoid Frequent
Vaginal Examination
Promotes cognitive
development of babies

Do not separate mother
and baby for routine care

Avoid Induction
of Labour

LDR Concept

No use of radiant
warmer for routine care

Avoid Augmentation
of Labour

Avoid Bright Lights

No Uneccassary refrerral
to SNCU/NBSU

Avoid Epidural and
Painkillers

Avoid Noise

Keeping the baby on the
mothers abdomen

Use of Safe Birth
Checklist

Avoid unnecessary
Movement of
Caregivers

Delayed Cord Clamping

Use of Partograph

Cleanliness &
Hygiene

Early initiation of
breast feeding

Avoid Unnecessary
C-Section

Shifting Mother & child
together towards/SNCU

Bonding of
Mother and Child

Allow healthy pregnancy
to continue till at
least 39 Weeks

Natural Progression
of Labour

22 LaQshya - Labour Room Quality Improvement Initiative | 2017

Soothing colours
and Music
Visual Privacy

Care Environment

<!-- page 41 -->

Annexure ‘B’
Recommended Minimum Human Resource for the Labour Rooms
Human Resource exclusively for Labour Room
All the labour rooms, whether newly constructed or re-rganized from an existing labour room,
should have Human Resources (HR) in adequate numbers strictly, as per the recommendations
given below. If needed, redeployment or hiring of new staff should be done. HR posted in the
labour room should not be rotated outside the labour room.
CHC/AH/SDH/DH/Medical Colleges
No. of
Staff Nurse Staff Nurse
Deliveries (with LDR) (without
(per month)
LDR)
100 – 200
In LDR
8
facility
there
should be 4
200- 500
12
staff nurses
per LDR
unit (1 for
each shift
and 1 back
up)
>500
16

MO

Housekeeping

DEO

Guard

4 MO, 1 OBG/ EmoC,
1 Anaesthetist/ LSAS,
1Pediatrician
1 OBG (Mandatory) + 4 OBG/
EmoC
+1 Anaesthetist
+ 4 LSAS
+ 1 Paediatrician
+ 4 MO
3 OBG (Mandatory) + 4 EmoC
+1 Anaesthetist
+ 4 LSAS
+ 1 Paediatrician
+ 4 MO

4

1

4

8

1

6

12

1

8

PHC
MO
1-2

Staff Nurse/ ANM
4 ANM/ Staff nurses

Housekeeping
Round the clock Services

Guard
Round the clock
services

*All normal deliveries in labour room in the district hospital should be conducted by staff nurses. OBG, EmoC trained MO, and
anaesthetists should also be available on call always.

LaQshya - Labour Room Quality Improvement Initiative | 2017 23

<!-- page 42 -->

Annexure ‘C’
Facility Level Targets for Incentives
S. No

Indicator

Source

Means of Verification

1.

Facility has assessed Labour Room and
OT using NQAS checklist and reported
Baseline Quality Scores and indicators

Collated &
Reports verified by SQAC
Reported by DQAC

2.

Facility has set Quality Team at facility
level and Quality Circles in Labour Room
& Maternity OTs

Collated &
Reports Verified by SQAC
Reported by DQAC

3.

Facility has oriented the Labour room and Collated &
Reports Verified by SQAC
Maternity OT staff on LR protocols, RMC Reported by DQAC
& QI

4.

At least 90% of deliveries are attended by
a birth companion

5.

At least 90% deliveries are conducted
Reported by Facility Verified by Coaching Team
using safe birth and Safe Surgery checklist
during facility visit
in Labour Room and Maternity OT
SQAC verification on sample
basis

6.

Partograph is generated using real-time
information in at least 90% deliveries in
Labour Rooms

7.

Achieved 80% percentage or more
HMIS
breastfeeding within 1 hour or at least 30%
increment from baseline.

Verified by Coaching Team
during facility visit
SQAC verification on sample
basis

8.

Achieved 0% neonatal asphyxia rate in
SNCU online (DH)
Labour Room or at least reduction of 20% Reported by facility
from baseline
(Where SNCU
online is not
available)

Verified by Coaching Team
during facility visit
SQAC verification on sample
basis

9.

Achieved 0% neonatal sepsis rate in-born SNCU online (DH)
babies or at least reduction of 20% from Reported by facility
baseline
(Where SNCU
online is not
available)

Verified by Coaching Team
during facility visit
SQAC verification on sample
basis

24 LaQshya - Labour Room Quality Improvement Initiative | 2017

Reported by Facility Verified by Coaching Team
during facility visit
SQAC verification on sample
basis

Reported by Facility Verified by Coaching Team
during facility visit
SQAC verification on sample
basis

<!-- page 43 -->

S. No

Indicator

Source

10.

Achieved 5% or less Surgical Site
infection Rate in Maternity OT or at least
reduction of 30% from baseline

Facility Report /
HMIS

Verified by Coaching Team /
DQAC

11.

Achieved 80% or more antenatal
corticosteroid administration rate in case
in preterm labour or at least increment of
30% from baseline

SNCU online (DH)
Reported by facility
(Where SNCU
online is not
available)

Verified by Coaching Team
during facility visit
SQAC verification on sample
basis

12.

No case of pre-eclampsia, eclampsia
& PIH related mortality or at least 25%
reduction from baseline

Facility Report

Verified by Coaching Team
during facility visit
SQAC verification on sample
basis

13.

No case of APH/PPH related mortality or Facility Report
at least 25% reduction from baseline

Verified by Coaching Team
during facility visit SQAC
verification on sample basis

14.

Facility Labour Room is reorganised as
labour room standardization guidelines

DQAC onsite
verification report

Report Verified by SQAC

15.

Facility Labour room has staffing as per
defined norms in annexure B

DQAC onsite
verification report

Report verified by SQAC

16.

100% of Women, administered Oxytocin,
immediately after birth.

Facility Report

Verified by Coaching Teams

17.

80%and more OSCE scores or at least
increment of 30% from baseline

Facility Report

Verified by Coaching Team

18.

Facility conducts referral audit on Monthly Facility Report
basis

Verified by Coaching Team

19.

Facility conducts Maternal death, Neonatal Facility report
death and near-miss on monthly basis

Verified by Coaching Team

20.

Facility report zero stock outs in Labour
Room & Maternity OT

Verified by Coaching Teams

Facility Report

Means of Verification

LaQshya - Labour Room Quality Improvement Initiative | 2017 25

<!-- page 44 -->

Annexure ‘D’
Detailed Action Plan for LaQshya Initiative
National Level

State Level

Institutions MH Division, CH
Directorate, NHM,
Division, NHSRC
SQAC/ SQAU, State
and National Partners level partners

District Level
DQAC,
DQAC

Primary
DC Maternal Health, Program Officer, MH District Nodal
RespMoHFW
State Nodal Officer
officers for Maternal
onsibility Health / RCH
Support
Teams

Project Management State Quality
District Quality
Unit, QI Division
Assurance Units
Assurance Unit
NHSRC,
Child Health Program
Child Health Division Officers

Quality
Drivers

National Mentoring
Group

State Mentoring
Group

Coaching Teams

Facility Level
Quality Team

Labour Room & OT
Incharges/ HOD
Obs&Gynae.

Quality Circle

Preparatory Phase
1st Month

National Level
Launch
Issue of Instructions
to the states & UTs

Dissemination of
LaQshya Guidelines
to target facilities

Listing of eligible
Formation of Quality
facilities and reporting Circles
to the state
One meeting of

Identification and
Identification and
selection for the
selection of State
Identification and
Coaching Teams
Mentoring
Group
selection of National
Mentoring Group
Identification and
members
orientation of District
level officers
Finalization of
Assessment Checklist Formation of State
(NQAS)
Mentoring Group,
Orientation
workshop for
National Mentors
and Key State
Officials (Two
Batches)

Finalisation of list
of facilities & district
nodal officers
Communication of
contact details to GoI

Preparation of Initial Coordination meeting
– NHM, Medical
IEC package
Education, Medical
Creation of special
Colleges, Medical
task group for
Directorate
‘LaQshya’

26 LaQshya - Labour Room Quality Improvement Initiative | 2017

quality team with
quality circle to
discuss LaQshya
guidelines and Future
plan
Ensuring Quality
Circle has hard copy
of LaQshya, Labour
Room Standardization

<!-- page 45 -->

National Level

State Level

District Level
DQAC,

Facility Level

First meeting of
DQAC with the
coaching team to
discuss future plan

Assessment of
Labour rooms &
Maternity OT using
NQAS Check-lists

Issuing guidelines for Recruitment of HR
strengthening referral (Existing Vacancies)
system
Developing a
standardising
branding for the
program
2nd Month Finalization of Initial IEC campaign
Resource package
through press,
Orientation workshop electronic media
for National Mentors Orientation of
(2 batch)
coaching teams, state
mentoring group and
Launch of IEC
representatives of
campaign
Medical Colleges by
Assigning National
National mentor in
Mentors for states
optimal size group
and facilities

Preparation of visit
roster of coaching
teams
Familiarisation
of guidelines and
required activities

Preparation of visit
roster of National
Mentors
Finalisation of
IT platform and
Instructions
Assessment Phase
3rd Month

Preparation of
resource package for
Rapid Improvement
for first two
improvement cycle
Visit of National
Mentors to facilities
as per roster
Launch of IT
platform and
Instructions

Mobilisation of
coaching teams for
peer assessment

Joint visit of Mentors Gap analysis
and coaching team
Reporting of HR
and structural
Peer Assessment of
requirements to state
Empanelling
Labour Room and
architects/planning
Maternity OT by
Collection of baseline
consultants for labour Coaching team
indicators
room redesign
Verifying the baseline Orientation of
Coordinating visits of Indicators
Quality Circles for
National Mentors
Quality Improvement
and Clinical Protocols

LaQshya - Labour Room Quality Improvement Initiative | 2017 27

<!-- page 46 -->

National Level
4th Month

State Level

District Level
DQAC,

Facility Level

Visit of National
mentors to facilities
as per roster

Collation of Resource Joint visit of
Preparation of Time
Requirements from
National mentors and bound Action Plan
facility
Coaching Teams
Initial Reorganization
Soft Launch of IT
Proposal for financial Handholding Quality of Labour Rooms
platform for Labour allocation (including circles in preparing
Reallocation of
room
resource requirement action plans
Human Resource
for
Medical
Colleges)
Finalization of
Collection of baseline
submitted through
Resource and
indicators
the NHM PIP
IEC package for
Mapping of referral
Improvement Cycle 1 (Supplementary)
facilities
Planning for creation
Approval of State
of obstetrics HDU
Ensuring availability
PIPs & release of
as
per
MoHFW
of updated versions
funds
guidelines
clinical protocols
Initiation of patient
satisfaction surveys
Improvement Phase

5th Month
Improvement
Cycle 1

Launch on
Improvement
Cycle “Realtime Partograph
generation & usage
of safe birth checklist”

Ensuring formats for Visit to assigned
standardized Labour facilities for onsite
Room case sheet
training and
including partograph handholding of
and safe birth
quality circle for use
checklist is distributed of

Identifying gaps
and opportunity for
improvements in use
of safe birth checklist
and partograph

Monitoring of
coaching teams

Standardized Labour
room case sheets

Planning for visits

Real Time use of
Partograph

Introduction of
Digital partographs
in selected medical
colleges

Facilitating
implementation of IT Real time use of safe
platform
birth checklist
Initiation of ‘gapclosure’ action
Hiring of approved
HR (Supplementary
PIP)

Assuring that
all deliveries are
conducted with help
of safe birth checklist
and partograph
Ensuring use of case
sheets and labour
room registers.
Entry of data in IT
SYSTEM

28 LaQshya - Labour Room Quality Improvement Initiative | 2017

<!-- page 47 -->

6th Month

National Level

State Level

District Level
DQAC,

Facility Level

Collating and
analysing state wise
progress

Collating & analysing
the progress,
Improvements and
Indicators,

Handholding the
Quality Circle for
sustaining the efforts

Standardizing and
sustaining the
improvement gained
in Cycle 1

Assisting states not
making expected
progress
Visit of National
Mentors to sample
facilities

Focusing on the
facilities not making
expected progress
including onsite visit
if necessary

Verifying the
indicators
Assessment of staff
competence and
processes

Reporting the
Indicators
Initiate project on
‘lean labour room’
in selected medical
colleges & DHs

Finalization of
Resource package and
material for next cycle
7th Month
Improvement
Cycle 2

Launch of
Improvement Cycle
on Birth Companion,
Respectful care &
satisfaction

State level orientation
of Labour Room In
charges and coaching
teams with for Birth
Companion and
respect full

IEC campaign on
IEC campaign in
importance of Birth
Local Media and
Companion and
Press for promoting
respectful care to
Birth Companion
enable natural birthing
Implementing patient
process
feedback system in
Dissemination of
labour rooms
Resource package
on respectful care
and natural birthing
process

Facility visit for
on-site training and
handholding the
quality circle for
Birth Companion,
respectful care and
Natural birthing
process

Collating and
analysing state wise
progress

Ensuring all the
deliveries are
conducted with active
support of birth
companion
Implementing the
protocols for Natural
Birthing Process
Maintaining the full
privacy through three
side curtains or LDR
cubicles
Taking feedback
for Mothers and
attendants

Video Conferencing
by National Mentors
with their respective
Coaching Teams and
Quality Circles
8th Month

Counselling
attendants for roles as
Birth Companion

Assisting states
Collating & analysing
having made expected the progress,
Improvements and
progress
Indicators,

Standardizing and
sustaining the
improvements gained
in Cycle 1 & 2

LaQshya - Labour Room Quality Improvement Initiative | 2017 29

<!-- page 48 -->

National Level

State Level

District Level
DQAC,

Visit of National
Mentors to sample
facilities

Focusing on the
facilities not making

Handholding the
Quality Circle for
sustaining the efforts
of Cycle 1 and 2

Finalization of
Expected progress
Resource package and including onsite visit
material for next cycle if necessary

9th Month
Improvement
Cycle 3

Launch of
Improvement Cycle
Labour Management
Protocols including
AMTSL, Oxytocin
Issue of guidelines
for C-Section Audit
Dissemination of
Resource package
on Labour Room
Protocols
Video Conferencing
by National Mentors
with their respective
Coaching Teams and
Quality Circles

Verifying the
indicators

Dissemination of
C-Section Audit
guidelines

Ensure augmentation
and induction
practices are restricted
unless these are
indicated
All staff is trained,
skilled and confident
in labour protocols
including AMTSL
Do’s and Don’ts are
clearly communicated
and adhered

Arranging refresher
trainings on labour
room protocols
through existing
program such as
Dakshata and skill
labs.

30 LaQshya - Labour Room Quality Improvement Initiative | 2017

Reporting the
Indicators

Assessment of
processes and staff
competence and
onsite rectification
if any

Ensuring labour room Facility visit for
onsite training
protocols including
AMTSL and rational and handholding
use of oxytocin have for labour room
been disseminated to protocols
all labour rooms

10th Month Collating and analysing Collating & analysing
state wise progress
the progress,
Improvements and
Assisting states not
Indicators,
making expected
progress
Focusing on the
Visit of National
facilities not making
Mentors to sample
expected progress
facilities
including onsite visit
if necessary
Finalization of
Resource package and
material for next cycle

Facility Level

Handholding the
Quality Circle for
sustaining the efforts
of Cycle 1 and 2, 3
&4
Verifying the
indicators
Assessment of
processes and staff
competence and
onsite rectification
if any

Standardizing
and sustain the
improvement gained
in Cycle 1, 2 & 3
Reporting the
Indicators

<!-- page 49 -->

National Level
11th Month Launch of
ImpImprovement Cycle
rovement on Assessment Triage
Cycle 4
and management of
complication
Dissemination of
Resource package
Video Conferencing
by National Mentors
with their respective
Coaching Teams and
Quality Circles

State Level
Ensuring protocols
for management of
assessment, triage
and management of
complications has
been disseminated
Arranging refresher
training of Labour
Room In charges/
Coaching teams if
necessary through
existing program such
as Dakshata and Skill
Labs

12th Month Collating and analysing Collating & analysing
state wise progress
the progress,
Improvements and
Assisting states not
Indicators,
making expected
progress
Focusing on the
Visit of National
Mentors to sample
facilities

Finalization of
Resource package and
material for next cycle
13th Month Launch of
ImpImprovement Cycle
rovement on Newborn Care,
Cycle 5
Resuscitation and
Breast feeding
Launch of IEC
campaign on Breast
feeding

facilities not making
expected progress
including onsite visit
if necessary

Ensuring Newborn
care and resuscitation
protocols are
disseminated to all
labour rooms
Arranging booster
training of Labour
room charges/
Coaching teams if
necessary through
existing program such
as Dakshata and Skill
Labs

District Level
DQAC,

Facility Level

Facility visit for
onsite training and
handholding for
implementation of
assessment, triage
and management
of complication
protocols

Earmarking the Triage
area in labour room
Implementing the
triage processes
Ensuring that initial
assessment of each
pregnant mother has
been done as per
labour room case sheet
Ensuring management
of complication
protocols are displayed
in labour room
Ensuring staff is well
trained and skilled
for management
complication protocols

Handholding the
Quality Circle for
sustaining the efforts
of Cycle 1, 2, 3 & 4

Standardizing
and sustain the
improvement gained
in Cycle 1, 2, 3 & 4

Verifying the
indicators

Reporting the
Indicators

Assessment of
processes and staff
competence and
onsite rectification
if any
Facility visit for
on-site training
and handholding
for Newborn care
& resuscitation.
Breastfeeding and care
of Low birth weight

Ensuring newborn
care and resuscitation
protocols are
displayed
Staff is trained, skilled
and confident
Equipment and
supplies are available

LaQshya - Labour Room Quality Improvement Initiative | 2017 31

<!-- page 50 -->

National Level
Dissemination of
resource package

State Level
Ensuing equipment
and supplies for
newborn care to
labour rooms

14th Month Collating and analysing Collating & analysing
state wise progress
the progress,
Improvements and
Assisting states not
Indicators,
making expected
progress
Visit of National
Mentors to sample
facilities
Finalization of
Resource package and
material for next cycle
15th Month Launch of
ImpImprovement
rovement Cycle on Infection
Cycle 6
Prevention and Waste
management
Dissemination of
Resource Package on
infection control

Focusing on the
facilities not making
expected progress
including onsite visit
if necessary

Visit of National
Mentors to sample
facilities

Focusing on the
facilities not making
expected progress
including onsite visit
if necessary

32 LaQshya - Labour Room Quality Improvement Initiative | 2017

Facility Level
Breastfeeding is
promoted and
ensured within one
hour of birth

Handholding the
Quality Circle for
sustaining the efforts
of Cycle 1 and 2, 3,
4&5
Verifying the
indicators

Standardizing
and sustain the
improvement gained
in Cycle 1, 2, 3, 4, & 5
Reporting the
Indicators

Assessment of
processes and staff
competence and onsite
rectification if any

Ensuring Infection
Facility visit for
Control protocols are on-site training
disseminated to all
and handholding
labour rooms
for Infection
prevention and waste
Arranging booster
management
training of Labour
Room In charges/
Coaching teams if
necessary through
existing program such
as Dakshata and Skill
Labs
Ensuring supplies for
infection control and
waste management
are in place

16th Month Collating and analysing Collating & analysing
state wise progress
the progress,
Improvements and
Assisting states not
Indicators,
making expected
progress

District Level
DQAC,

Ensuring Hand
Hygiene and personal
protection practices
Ensuring waste is
disposed as per BMW
rules 2016
Ensuring sterilized
instrument and
supplies are available
for delivery and
newborn care
Ensuring staff is
trained and skilled for
infection control and
Waste Management

Handholding the
Quality Circle for
sustaining the efforts
of Cycle 1, 2, 3, 4, 5
&6

Standardizing
and sustain the
improvement gained
in Cycle 1, 2, 3 & 4, &
5&6

Verifying the
indicators

Reporting the
Indicators

<!-- page 51 -->

National Level

State Level

District Level
DQAC,

Facility Level

Assessment of
processes and staff
competence and onsite
rectification if any
Evaluation Phase
17th Month Collating and
evaluation of overall
performance on
Quality Indicators

Collating the quality
scores

Assigning Assessors
external certification

External Assessment
of Labour rooms
coring more than
70% score for awards

18th Month Award of Quality
Certification

Sending Request for
Quality Certification

Second round of
peer assessment
by coaching teams
against NQAS
standards

Awards at state level Branding of Labour
winners and coaching Rooms
teams

Applying for Labour
Room Quality
Certification

Branding of Labour
rooms

National Level
Felicitation of Award Branding of Labour
Winners
rooms
Dissemination of
Achievements
Roll out for program
for next phase

y If Labour rooms are ready they can apply for the NQAS certification early.
y Actions for closure of structural and HR gaps will be initiated simultaneously. State and facility

incharges should ensure that Labour Room preferably in LDR format with requisite equipment
and HR are ready within one year of commencement of this initiative.
y Rapid Improvement Cycles have been planned to emphasize and improve critical processes

through more focused campaign mode. Focusing on one issue doesn’t mean that other issues
will not be addressed in that window period. Critical gaps should be addressed as and when
required. Improved practices and performance gained during one campaign should be sustained
during the subsequent cycles.
y Indicators will be reported on monthly basis in the first week of next month.

LaQshya - Labour Room Quality Improvement Initiative | 2017 33

<!-- page 52 -->

List of Abbreviations
AIIMS

All India Institute of Medical Sciences

AMTSL

Active Management of Third Stage of Labour

CDR

Child Death review

CHC

Community Health Centres

CQSC

Central Quality Supervisory Committee

DH

District Hospitals

DQAC

District Quality Assurance Committee

DQAU

District Quality Assurance Unit

EmOC

Emergency Obstetric Care

FRU

First Referral Units

HDU

High Dependency Unit

IEC

Information Education Communication

IT

Information Technology

JSSK

Janani Shishu Suraksha Karyakram

LDR

Labour Delivery Recovery

LR

Labour Room

LSAS

Life Saving Anaesthetic Skills

MC

Medical College

MDSR

Maternal Death Surveillance & Review

MH

Maternal Health

MoHFW

Ministry of Health & Family Welfare

NHM

National Health Mission

NHSRC

National Health Systems Resource Centre

NIHFW

National Institute of Health & Family Welfare

NMR

Neonatal Mortality Review

NPMU

National Programme Management Unit

NQAS

National Quality Assurance Standards

OBG/Obs & Gynae.

Obstetrics & Gynaecology

OSCE

Objective Structured Clinical Examination

OT

Operation Theatre

PDCA

Plan Do Check Act

34 LaQshya - Labour Room Quality Improvement Initiative | 2017

<!-- page 53 -->

PHC

Primary Health Centres

PIP

Program Implementation Plan

QC

Quality Circle

QOC

Quality of Care

RCH

Reproductive & Child Health

RIC

Rapid Improvement Events

SDH

Sub Divisional Hospital

SQAC

State Quality Assurance Committee

SQAU

State Quality Assurance Unit

LaQshya - Labour Room Quality Improvement Initiative | 2017 35

<!-- page 54 -->

List of Contributors
1.

Mr Manoj Jhalani

Additional Secretary & Mission Director NHM, MoHFW

2.

Ms Vandana Gurnani

Joint Secretary (RCH) MoHFW

3.

Dr Manohar Agnani

Joint Secretary (Policy) MoHFW

4.

Dr Ajay Khera

Deputy Commissioner I/C CH & AH

5.

Dr Dinesh Baswal

Deputy Commissioner I/C MH

6.

Dr P K Prabhakar

Deputy Commissioner, Child Health

7.

Dr Sumita Ghosh

Deputy Commissioner, Maternal Health

8.

Dr Rajani Ved

Executive Director, NHSRC

9.

Dr Arun Kumar Singh

National Advisor, RBSK

10.

Dr J N Srivastava

Advisor, Quality Improvement, NHSRC

11.

Dr Himanshu Bhushan

Advisor, Public Health Administration, NHSRC

12.

Dr Archana Mishra

Deputy Director, Maternal Health, Madhya Pradesh

13.

Dr Neelima Singh

Indian Institute of Health and Family Welfare, Telangana

14.

Dr Nikhil Prakash

Senior Consultant, Quality Improvement, NHSRC

15.

Dr Parminder Gautam

Senior Consultant, Quality Improvement, NHSRC

16.

Dr Deepika Sharma

Consultant, Quality Improvement, NHSRC

17.

Dr Jagjeet Singh

Consultant, Quality Improvement, NHSRC

18.

Dr Namit Singh Tomar

Consultant, Quality Improvement, NHSRC

19.

Dr Salima Bhatia

Lead Consultant, Maternal Health Division, MoHFW

20.

Dr Hariprakash Hadial

Lead Consultant, Maternal Health Division, MoHFW

21.

Dr Narender Goswami

Consultant, Maternal Health Division, MoHFW

22.

Ms. Jenita Khwairakpam

Consultant, Maternal Health Division, MoHFW

23.

Dr Jyoti Singh Baghel

Consultant, Maternal Health Division, MoHFW

24.

Dr Aishwarya Sodhi

Consultant, Maternal Health Division, MoHFW

25.

Dr Amrita John

Consultant, Maternal Health Division, MoHFW

26.

Ms. Pooja Chitre

Consultant, Maternal Health Division, MoHFW

27.

Dr Amit Shah

USAID

28.

Dr. Sachin Gupta

USAID

29.

Dr Anuradha Jain

USAID

36 LaQshya - Labour Room Quality Improvement Initiative | 2017

<!-- page 55 -->

30.

Dr Usha Kiran Tarigopula

BMGF

31.

Dr Mrunal Shetye

BMGF

32.

Dr Leila Varkey

C3/WRAI

33.

Dr Kasonde Mwinga

WHO

34.

Dr Paul P Francis

WHO

35.

Dr Amrita Kansal

WHO

36.

Dr Ritu Agrawal

LSTM

37.

Dr Bulbul Sood

Jhpiego

38.

Dr Neeraj Agarwal

Jhpiego

39.

Dr Vikas Yadav

Jhpiego

40.

Dr Deepti Singh

Jhpiego

41.

Dr Yaron Wolman

UNICEF

42.

Dr Gagan Gupta

UNICEF

43.

Dr Asheber Gaym

UNICEF

44.

Dr Apurva Ratnu

UNICEF

45.

Dr Rajeev Gera

IPE Global

46.

Dr Gunjan Taneja

IPE Global

47.

Dr Devina Bajpayee

IPE Global

48.

Dr Rakesh Parashar

IPE Global

49.

Dr Tarun Singh Sodha

IPE Global

50.

Dr Ajit Sudke

Access Health International

LaQshya - Labour Room Quality Improvement Initiative | 2017 37

<!-- page 56 -->

Notes

<!-- page 57 -->

Notes

<!-- page 58 -->

Notes

<!-- page 59 -->

<!-- page 60 -->

42 LaQshya - Labour Room Quality Improvement Initiative | 2017
