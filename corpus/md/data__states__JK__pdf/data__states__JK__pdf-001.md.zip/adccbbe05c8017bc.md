---
doc_id: "adccbbe05c8017bc"
source_url: "https://skuastjammu.ac.in/admin/backend/news/1789639660ideathons-jkcip.pdf.pdf"
ministry: "Sher-e-Kashmir University of Agricultural Sciences and Technology of Jammu (SKUAST-Jammu), Jammu and Kashmir"
title: "Tender regarding organising of 7 No. Ideathons and Bootcamps under JKCIP, SKUAST Jammu"
date: ""
pages: 36
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "271e05e1164e8672"
---

<!-- page 1 -->

Request for
Bids
Procurement of Goods and
Related Services
National Competitive Bidding
(NCB)
1st Edition
December 2020

[project name]
[procurement title] - Ref. No: [insert reference number]

3

<!-- page 2 -->

Sher-e-Kashmir
University of Agricultural Sciences and Technology of Jammu
Nodal Office, JKCIP, Block No.7, Main Campus, Chatha-Jammu (J&K)-180009

Request for Bids
for
Organizing of Ideathons and Bootcamps in
Different Districts of Jammu Province, UT of
Jammu and Kashmir

Ref No: AWPB-2026-27
Dated: 14.05.2026

[project name]
[procurement title] - Ref. No: [insert reference number]

4

<!-- page 3 -->

Foreword
This bidding document has been prepared by Nodal Officer, JKCIP, SKUAST Jammu and is
based on the standard procurement document for national competitive bidding issued by IFAD
on www.ifad.org/project-procurement. This bidding document is to be used for the procurement
of goods and related services using the national competitive bidding method in accordance with
the IFAD Project Procurement Guidelines and the IFAD Procurement Handbook for projects
financed by IFAD.
IFAD does not guarantee the completeness, accuracy or translation, if applicable, or any other
aspect in connection with the content of this document.

[project name]
[procurement title] - Ref. No: [insert reference number]

5

<!-- page 4 -->

Section I. Invitation for Bids
No: AUJ/AEABM/JKCIP/26-27/F-92(10)/790

Jammu, India
Dated: 08-09-2026

Re: Organizing of Ideathons and Bootcamps in Different Districts of Jammu Province,
UT of Jammu and Kashmir
The Sher-e-Kashmir University of Agricultural Sciences and Technology of Jammu has
received financing from the International Fund for Agricultural Development (IFAD and intends
to apply a part of the proceeds of the financing to this purchase. The use of any IFAD financing
shall be subject to IFAD’s approval, pursuant to the terms and conditions of the financing
agreement, as well as IFAD’s rules, policies and procedures. IFAD and its officials, agents and
employees shall be held harmless from and against all suits, proceedings, claims, demands,
losses and liability of any kind or nature brought by any party in connection with Jammu and
Kashmir Competitiveness Improvement in Agriculture and Allied Sectors Project (JKCIP).
1. The Jammu and Kashmir Competitiveness Improvement in Agriculture and Allied Sectors
Project (JKCIP), SKUAST Jammu contributes to a sustained increase in the incomes of
the rural households by improving the competitiveness and climate resilience of farming
operations.
2. This invitation for bids (IFB) follows the general procurement notice that will be uploaded
on Government-e-Marketing (GeM) portal on 09.09.2026.
3. The purchaser now invites sealed bids from eligible entities (bidders) for the provision of
Organizing of 7 (seven) No. Ideathons and Bootcamps in Different Districts of
Jammu Province of UT of Jammu and Kashmir. More details on these goods and
related services are provided in the Price Schedule for Goods and Services Offered
from within the Purchaser’s Country. The purpose of organizing of Bootcamps is to
make the college students aware of the objectives of the JKCIP Project and to encourage
them to come up with new ideas for start-up business.
4. Bidding will be conducted using the national competitive bidding (NCB) method, the
evaluation procedure for which is described in this bidding document, in accordance with
the IFAD Procurement Handbook which is provided at www.ifad.org/project-procurement.
The NCB process, as described, will include a review and verification of qualifications and
past performance, including a reference check, prior to the contract award.
5. Bidders interested shall log onto the GeM Portal for submission of their bids as per
schedule mentioned therein. Bidding documents uploaded on the GeM portal can be
downloaded by logging on to the GeM portal. Bids must be uploaded on the GeM portal as
per scheduled date and time.
6. Bidders should be aware that the bids will be accepted on GeM portal only. under any
circumstance and will be returned unopened at the written request and cost of the bidder.
All bids must be accompanied by a bid security or bid-securing declaration (as required) in
the manner and amount specified in the bid data sheet.
Yours sincerely,
Sd/(Dr,Pawan Kumar Sharma)
Nodal officer, JKCIP
Ist. Floor, Block No.7, SKUAST-J
Main Campus, Chatha, Jammu J&K- 180009.
Tel: +919419192958, E-mail: jkcip@skuastj.org.
Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

6

<!-- page 5 -->

Section:II. -Instructions to Bidders
A. Introduction
1. Scope of Bid

1.1 The purchaser has issued an invitation for bids on GeM portal for
the procurement of goods and related services as specified in Section IV.
Bid Form and Price Schedule. The name and identification number of the
contract is specified in the bid data sheet (BDS).
1.2 The purchaser of the purchaser’s country identified in the BDS, is
not bound to accept any bid, and reserves the right to cancel the
procurement at any time prior to contract award, without thereby incurring
any liability to any bidder.
1.3 The contract award will be completed within 6 (weeks) from the
date of issue of the award.

2. Source of
Funds

2.1 The borrower or recipient (hereinafter called “the borrower”)
specified in the BDS has received a financing from the International Fund
for Agricultural Development (“the Fund”) and intends to apply a portion of
the proceeds of this loan/grant to eligible payments under this contract.
Payment by IFAD will be made only at the request of borrower and upon
approval by IFAD, and will be subject, in all respects, to the terms and
conditions of the financing agreement. The financing agreement prohibits
withdrawal from the loan and/or grant account for the purpose of any
payment to persons or entities, or any payment prohibited by a decision of
the United Nations Security Council taken under Chapter VII of the Charter
of the United Nations.

3. Prohibited
Practices

3.1 The Fund requires that all beneficiaries of IFAD funding, including
the purchaser and any bidders, implementing partners, service providers,
suppliers, sub-suppliers, contractors, sub-contractors, consultants, subconsultants, and any of their agents (whether declared or not) and
personnel observe the highest standards of ethics during the procurement
and execution of such contracts, and comply with IFAD’s Policy on
Preventing Fraud and Corruption in its Activities and Operations, revised
on 12 December 2018.
3.2 For the purposes of these provisions, and consistent with IFAD’s
Anticorruption Policy, the terms set forth below are defined as follows, and
sometimes referred to collectively as “prohibited practices”:
a) “corrupt practice” is the offering, giving, receiving, or soliciting,
directly or indirectly, of anything of value in order to improperly
influence the actions of another party;
b) “fraudulent practice” is any act or omission, including a
misrepresentation, that knowingly or recklessly misleads, or

Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

7

<!-- page 6 -->

attempts to mislead, a party in order to obtain a financial or other
benefit or to avoid an obligation;
c) “collusive practice” is an arrangement between two or more
parties designed to achieve an improper purpose, including
improperly influencing the actions of another party;
d) “coercive practice” is impairing or harming, or threatening to
impair or harm, directly or indirectly, any party or the property of
any party, to improperly influence the actions of that or another
party;
e) “obstructive practice” is (i) deliberately destroying, falsifying,
altering or concealing evidence that may be material to an
investigation by the Fund or making false statements to
investigators in order to materially impede an investigation by
the Fund; (ii) threatening, harassing or intimidating any party in
order to prevent that party from disclosing its knowledge of
matters relevant to an investigation by the Fund or from
pursuing such an investigation; and/or (iii) the commission of
any act intended to materially impede the exercise of the Fund’s
contractual rights of audit, inspection and access to information.
3.3 The Fund will deny approval of a proposed contract award if it
determines that the firm or individual recommended for award, or any of
its personnel or agents, or its sub-consultants, sub-contractors, service
providers, suppliers, sub-suppliers and/or any of their personnel or agents,
has, directly or indirectly, engaged in any of the prohibited practices in
connection with an IFAD-financed and/or IFAD-managed activity or
operation, including in competing for the contract.
3.4 In accordance with IFAD’s Anticorruption Policy, the Fund has the
right to sanction firms and individuals, including by declaring them
ineligible, either indefinitely or for a stated period of time, to participate in
any IFAD-financed and/or IFAD-managed activity or operation. This may
include ineligibility to: (i) be awarded or otherwise benefit from any IFADfinanced contract, financially or in any other manner; (ii) be a nominated
sub-contractor, consultant, manufacturer, supplier, sub-supplier, agent or
service provider of an otherwise eligible firm being awarded an IFADfinanced contract; and (iii) receive the proceeds of any loan or grant
provided by the Fund.1 The Fund also has the right to unilaterally
recognize debarments by any of the International Financial Institutions that
are members to the Agreement for Mutual Enforcement of Debarment
Decisions if such debarments meet the requirements for mutual
recognition under the Agreement for Mutual Enforcement of Debarment
Decisions.
1 For the avoidance of doubt, a sanctioned party’s ineligibility to be awarded a contract shall include, without

limitation, (i) applying for pre-qualification, expressing interest in a consultancy, and bidding, either directly or as
a nominated sub-contractor, nominated consultant, nominated manufacturer or supplier, or nominated service
provider, in respect of such contract, and (ii) entering into an addendum or amendment introducing a material
modification to any existing contract.
Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

8

<!-- page 7 -->

3.5 In addition, the Fund has the right to, at any time, declare a misprocurement and/or the ineligibility of any expenditures associated with a
procurement process or contract if it determines that prohibited practices
occurred in connection with this procurement process or contract and that
the borrower/recipient has not taken timely and appropriate action,
satisfactory to the Fund, to address such practices when they occur.
3.6 Bidders, suppliers, consultants, contractors, and their subcontractors, sub-consultants, service providers, suppliers, agents and
personnel, are required to fully cooperate with any investigation conducted
by the Fund into possible prohibited practices, including by making
personnel available for interviews and by providing full access to any and
all accounts, premises, documents and records (including electronic
records) relating to the relevant IFAD-financed and/or IFAD-managed
operation or activity and to have such accounts, premises, records and
documents audited and/or inspected 2 by auditors and/or investigators
appointed by the Fund.
3.7 The bidder is obliged to disclose relevant prior sanctions and
criminal convictions and any commissions or fees paid or are to be paid to
any agents or other party in connection with this procurement process or
the execution of the contract.
3.8 The bidder shall keep all records and documents, including
electronic records, relating to this procurement process available for a
minimum of three (3) years after notification of completion of the process
or, in case the bidder is awarded the contract, execution of the contract.

2 Inspections include all fact-finding activities deemed relevant by the Fund to address allegations or other

indications of possible prohibited practices. Such fact-finding activities may include, but are not limited to:
accessing and examining a firm's or individual's financial records and information, and making copies thereof as
relevant; accessing and examining any other documents, data or information (whether in hard copy or electronic
format) deemed relevant for the investigation or audit, and making copies thereof as relevant; interviewing staff
and other relevant individuals; performing physical inspections and site visits; and obtaining third party
verifications of information. It is the responsibility of the firm or individual under inspection to ensure effective
compliance with their duty to cooperate vis-à-vis any potential local laws or regulations or other potentially
conflicting obligations.

Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

9

<!-- page 8 -->

4. Sexual
Harassment,
Sexual
Exploitation
and Abuse

4.1 The Fund requires that all beneficiaries of IFAD Funding, including
the purchaser and any bidders, implementing partners, service providers,
suppliers, sub-suppliers, contractors, sub-contractors, consultants, subconsultants, and any of their agents (whether declared or not) and
personnel comply with IFAD's Policy on Preventing and Responding to
Sexual Harassment, Sexual Exploitation and Abuse. For the purpose of
this provision, and consistent with IFAD’s Policy on Preventing and
Responding to Sexual Harassment, Sexual Exploitation and Abuse as it
may be amended from time to time, the terms set forth below are defined
as follows:
a) Sexual harassment means “any unwelcome sexual advance,
request for sexual favour or other verbal, non-verbal or physical
conduct of a sexual nature that unreasonably interferes with
work, alters or is made a condition of employment, or creates
an intimidating, hostile or offensive work environment.
b) Sexual exploitation and abuse means any actual or attempted
abuse of a position of vulnerability, differential power, or trust,
for sexual purposes, including, but not limited to, profiting
monetarily, socially or politically from the sexual exploitation of
others (sexual exploitation); the actual or threatened physical
intrusion of a sexual nature, whether by force or under unequal
or coercive conditions (sexual abuse).
4.2 Purchasers, suppliers and bidders shall take all appropriate
measures to prevent and prohibit sexual harassment and sexual
exploitation and abuse on the part of their personnel and subcontractors
or anyone else directly or indirectly employed by them or any of
subcontractors in the performance of the contract. Purchasers, suppliers
and bidders shall immediately report to the purchaser or IFAD any
incidents of sexual harassment and sexual exploitation and abuse arising
out of or in connection with the performance of the contract or prior to its
execution, including convictions, disciplinary measures, sanctions or
investigations. The purchaser may take appropriate measures, including
the termination of the contract, on the basis of proven acts of sexual
harassment, sexual exploitation and abuse arising out of or in connection
with the performance of the contract.
4.3 The bidder or supplier is required to disclose any relevant prior
sanctions, convictions, disciplinary measures or criminal records.

5. Money
laundering
and Terrorist
Financing

5.1 The Fund requires that all beneficiaries of IFAD funding or funds
administered by IFAD, including the purchaser, any bidders, implementing
partners, service providers and suppliers, observe the highest standards
of integrity during the procurement and execution of such contracts, and
commit to combat money laundering and terrorism financing consistent
with IFAD’s Anti-Money Laundering and Countering the Financing of
Terrorism Policy.

Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

10

<!-- page 9 -->

6. SECAP
Performance
Standards

6.1 The resulting contract will be implemented in a manner consistent
with IFAD’s Social, Environmental and Climate Assessment Procedures
(SECAP), available on https://www.ifad.org/en/secap.

7. Eligible
Bidders and
Conflict of
Interest

7.1 This invitation for bids is open to all suppliers from eligible source
countries except as provided hereinafter.
7.2 Any eligible entity may bid independently or in a joint venture (JV).
In the case where a bidder is or proposes to be a JV
a) all members shall be jointly and severally liable for the execution
of the contract; and

Conflict of Interest

b) the JV shall nominate a representative who will have the
authority to conduct all business for and on behalf of any and all
the members of the JV.
7.3 A bidder shall not have any actual, potential or reasonably perceived
conflict of interest. A bidder shall declare in the bid submission form any
actual, potential or reasonably perceived interest, regardless of its nature,
that affects, may affect, or might reasonably be perceived by others to
affect, impartiality in any matter relevant to the procurement process,
including the selection process and the execution of the contract. A bidder
with an actual, potential or reasonably perceived conflict of interest shall
be disqualified, unless otherwise explicitly approved by the Fund. The
purchaser requires that the bidder and the supplier hold the project’s
interests as paramount at all times, strictly avoiding any actual, potential
or reasonably perceived conflicts of interest, including actual, potential or
reasonably perceived conflicts with other assignments or their own
personal and/or corporate interests, and act without any consideration for
any other ongoing or future work. Without limitation on the generality of
the foregoing, a bidder or supplier, including all parties constituting the
bidder or supplier and their respective personnel and affiliates, as well as
any subcontractors for any part of the contract, including related services,
and their respective personnel and affiliates, may be considered to have
an actual, potential or reasonably perceived conflict of interest and
disqualified or terminated if they:
a) have, may have or might reasonably appear to have at least one
controlling partner in common with one or more other parties in
the process contemplated by this bidding document or the
execution of the contract; or
b) have, may have or might reasonably appear to have the same
legal representative as another bidder for purposes of this bid
or execution of the contract; or
c) have, may have or might reasonably appear to have a
relationship, directly or through common third parties, that puts
them in a position to have access to undue or undisclosed

Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

11

<!-- page 10 -->

information about or influence over the bid process and the
execution of the contract, or influence the decisions of the
purchaser regarding the selection process for this procurement
or during the execution of the contract; or
d) participate, may participate or might reasonably appear to
participate in more than one bid in this process; participation by
a bidder in more than one bid shall result in the disqualification
of all bids in which the party is involved; however, this provision
does not limit the inclusion of the same subcontractor in more
than one bid; or
e) are themselves, may be or might reasonably appear to be, or
have, may have or might reasonably appear to have a business
or family relationship with, a member of the purchaser’s board
of directors or its personnel, the Fund or its personnel, or any
other individual was, has been or might reasonably be directly
or indirectly involved in any part of (i) the preparation of this
bidding document, (ii) the selection process for this
procurement, or (iii) execution of the contract, unless the actual,
potential or reasonably-perceived conflict stemming from this
relationship has been explicitly authorized by the Fund.
7.4 A bidder that has been engaged by the purchaser to provide goods,
works or services for a project, its personnel and any of its affiliates, shall
be disqualified from providing consulting services related to those goods,
works or services. Conversely, a bidder hired to provide consulting
services for the preparation or implementation of a project, its personnel
and any of its affiliates, shall be disqualified from subsequently providing
goods, works or non-consulting services resulting from or directly related
to such consulting services for such preparation or implementation.
7.5 A bidder and the supplier shall have an obligation to disclose any
situation of actual, potential or perceived conflict of interest that impacts,
may impact, or might reasonably appear to be perceived by others to
impact, their capacity to serve the best interest of the purchaser. Failure
to properly disclose any of said situations may lead to appropriate actions,
including the disqualification of the bidder, the termination of the Contract
and any other as appropriate under the IFAD Policy on Preventing Fraud
and Corruption in its Projects and Operations.
7.6 A bidder or supplier, all parties constituting the bidder or supplier,
and any subcontractors for any part of the Contract, including related
services, and their respective personnel and affiliates, will not be any
person or entity under a declaration of ineligibility by the Fund for having
engaged in prohibited practices as contemplated by ITB clause 3 above.
The Fund also has the right to unilaterally recognize debarments by any
of the International Financial Institutions that are members of the
Agreement for Mutual Enforcement of Debarment Decisions if such
debarments meet the requirements for mutual recognition under the
Agreement for Mutual Enforcement of Debarment Decisions.

Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

12

<!-- page 11 -->

7.7 A bidder or supplier, all parties constituting the bidder or supplier,
and any subcontractors for any part of the contract, including related
services, and their respective personnel and affiliates not otherwise made
ineligible for a reason described in this ITB Clause 7 will nonetheless be
excluded if:
a) as a matter of law or official regulation, the Government
prohibits commercial relations with the country of the bidder or
Supplier (including any Associates, Subcontractors and any
respective affiliates) provided that the Fund is satisfied that such
exclusion does not preclude effective competition for the supply
of goods or the contracting of works or services required; or
b) by an act of compliance with a decision of the United Nations
Security Council taken under Chapter VII of the Charter of the
United Nations, the Government prohibits the issuance of a
payment.
8. Eligible Goods 8.1 All goods and related services to be supplied under the contract shall
and Services have their origin in eligible sources.
9. Cost of Bidding 9.1 The bidder shall bear all costs associated with the preparation and
submission of its bid, and the purchaser will in no case be responsible or
liable for those costs, regardless of the conduct or outcome of the bidding
process.
B. The bidding documents
10. Content of
Bidding
Documents

10.1 The goods required, bidding procedures, and contract terms are
prescribed in the bidding documents. In addition to the invitation for bids,
the bidding documents include:
a) instructions to bidders (ITB)
b) bid data sheet (BDS)
c) schedule of requirements
d) bidding forms
e) technical specifications
f) general conditions of contract (GCC)
g) contract forms
10.2 The bidder is expected to examine all instructions, forms, terms,
and specifications in the bidding documents. Failure to provide all
information required by the bidding documents or to submit a bid that is
not substantially responsive to the bidding documents in every respect
will be at the bidder’s risk and may result in the rejection of its bid.

Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

13

<!-- page 12 -->

11. Clarification of 11.1 A prospective bidder requiring any clarification of this bidding
Bidding
document shall contact the purchaser in writing, by email or fax at the
Documents
purchaser’s address indicated in the BDS. The purchaser will respond
to any request for clarification, provided that such a request is received
no later than three days before the last date of bid submission.
12. Amendment of 12.1 At any time prior to the deadline for submission of bids, the
Bidding
purchaser may amend this bidding document by issuing addenda.
Documents
12.2 To give prospective bidders reasonable time in which to take an
addendum into account in preparing their bids, the purchaser may extend
the deadline for the submission of bids at its sole discretion.
C. Preparation and submission of bids
13. Language of Bid 13.1 The bid prepared by the bidder, as well as all correspondence and
documents relating to the bid exchanged by the bidder and the
purchaser, shall be written in the language specified in the BDS.
Supporting documents and printed literature furnished by the bidder may
be in another language provided they are accompanied by an accurate
translation of the relevant passages into English, in which case, for
purposes of interpretation of the bid, the translation shall govern.
14. Documents
Constituting
the Bid

14.1 The bid prepared by the bidder shall comprise the following
components:
a) a bid form and a price schedule completed in accordance with
ITB clauses 16.5.
b) documentary evidence established in accordance with ITB
clause 18 that the bidder is eligible to bid and is qualified to
perform the contract if its bid is accepted;
c) documentary evidence established in accordance with ITB
clause 18 that the goods and ancillary services to be supplied
by the bidder are eligible goods and services and conform to
the bidding documents; and
d) bid security or bid-securing
accordance with ITB clause 20.

declaration

furnished

in

15. Bid Form

15.1 The bidder shall complete, sign and stamp the bid form and the
appropriate price schedule furnished in the bidding documents, indicating
the goods to be supplied, a brief description of the goods, their country of
origin, quantity, and prices.

16. Bid Prices

16.1 The bidder shall indicate on the appropriate total bid price of the
goods and services, it proposes to supply under the contract.

Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

14

<!-- page 13 -->

17. Currencies
of Bid

17.1 The currency(ies) of the bid shall be specified in the BDS. For
evaluation and comparison purposes, the currency of the bids shall be
INR.

18. Documents
Establishing
Bidder’s
Eligibility and
Qualification

18.1 Pursuant to ITB clause 18, the bidder shall furnish, as part of its bid,
documents establishing the bidder’s eligibility to bid and its qualifications
to perform the contract if its bid is accepted.
18.2 The documentary evidence of the bidder’s eligibility to bid shall
establish to the purchaser’s satisfaction that the bidder, at the time of
submission of its bid, is from an eligible country as defined in the BDS.
18.3 The documentary evidence of the bidder’s qualifications to perform
the contract if its bid is accepted shall be established to the purchaser’s
satisfaction:
a) that, in the case of a bidder offering to supply goods and
services under the contract which the bidder did not
manufacture or otherwise produce, the bidder has been duly
authorized by the goods’ manufacturer or producer to supply the
goods in the purchaser’s country unless otherwise specified in
the BDS;
b) that the bidder has the financial, technical, and production /after
sales service capability necessary to perform the contract as
stipulated in the BDS;
c) that the bidder meets the qualification criteria listed in the BDS.

19. Documents
Establishing
Goods’
Eligibility and
Conformity to
Bidding
Documents

19.1 The documentary evidence of conformity of the goods and services
to the bidding documents may be in the form of literature, drawings, and
data, and shall consist of:

20. Bid Security

20.1 The bidder shall furnish, as part of its bid, either a bid security or a
bid-securing declaration, as specified in the BDS.

a) an item-by-item commentary on the purchaser’s technical
specifications demonstrating substantial responsiveness of the
goods and services to those specifications, or a statement of
deviations and exceptions to the provisions of the technical
specifications.

20.2 If a bid security is required, it shall be in the amount and currency
specified in the BDS, and shall be in one of the following forms:
a) In the shape of CDR/ FDR pledged in favour of the Comptroller,
SKUAST Jammu and valid for thirty (30) days beyond the
validity of the bid.
20.3 Any bid not secured in accordance with this ITB clause 20 will be
rejected by the purchaser as non-responsive.

Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

15

<!-- page 14 -->

20.4 Upon receipt of the signed contract agreement and a valid
performance security, the purchaser shall return the bid securities of
unsuccessful bidders.
20.5 The successful bidder’s bid security will be discharged upon the
bidder signing the contract and furnishing the performance security
equivalent to 5% of the contract value.
20.6 The bid security may be forfeited:
a) if a bidder:
(i) withdraws its bid during the period of bid validity specified by
the bidder on the bid form, or
b) in the case of a successful bidder, if the bidder fails:
(i) to sign the contract; or
(ii) to furnish performance security.
21. Bid Validity

21.1 Bids shall remain valid for the period specified in the BDS after the
date of bid submission prescribed by the purchaser, pursuant to ITB
clause 21. A bid valid for a shorter period shall be rejected by the
purchaser as non-responsive.
21.2 In exceptional circumstances, the purchaser may solicit the bidder’s
consent to an extension of the period of validity. The request and the
responses thereto shall be made in writing.

22. Format and
22.1 Any interlineations, erasures or overwriting shall be valid only if they
Signing of Bid are initialed by the person or persons signing the bid.
22.2 The bidder shall furnish information as described in the form or bid
on commissions or gratuities, if any, paid or to be paid to agents relating
to this bid, and to contract execution if the bidder is awarded the contract.

D. Submission of bids
23. Sealing and
Marking of
Bids

23.1 The bidder shall upload the bid on the Government-e-Marketing
(GeM) portal as per scheduled date and time.

24. Deadline for
Submission
of Bids

24.1 Bids must be uploaded on GeM portal by the time and date specified
in the BDS.

Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

16

<!-- page 15 -->

E. Opening and evaluation of bids
25. Opening of
Bids by the
Purchaser

25.1 The purchaser will open all bids on the GeM portal subject to healthy
competition.

26. Clarification
of Bids

26.1 During evaluation of the bids, the purchaser may, at its discretion,
ask the bidder for clarification of its bid. The request for clarification and
the response shall be in writing, and no change in the prices or substance
of the bid shall be sought, offered, or permitted.

27. Preliminary
Examination

27.1 The purchaser will examine the bids to determine whether they are
complete, whether any computational errors have been made, whether
required sureties have been furnished, whether the documents have been
properly signed, and whether the bids are generally in order.
27.2 The purchaser may waive any minor informality, nonconformity, or
irregularity in a bid which does not constitute a material deviation, provided
such waiver does not prejudice or affect the relative ranking of any bidder.
27.3 Prior to the detailed evaluation, pursuant to ITB clause 28, the
purchaser will determine the substantial responsiveness of each bid to the
bidding documents. For purposes of these clauses, a substantially
responsive bid is one that conforms to all the terms and conditions of the
bidding documents without material deviations. Deviations from, or
objections or reservations to critical provisions, such as those concerning
bid security (ITB clause 20), applicable law (GCC clause 34), and taxes
and duties (GCC clause 36), will be deemed to be a material deviation.
The purchaser’s determination of a bid’s responsiveness is to be based
on the contents of the bid itself without recourse to extrinsic evidence.
27.4 If a bid is not substantially responsive, it will be rejected by the
purchaser and may not subsequently be made responsive by the bidder
by correction of the nonconformity.

28. Evaluation and 28.1 The purchaser will evaluate and compare the bids which have been
Comparison of determined to be substantially responsive, pursuant to ITB clause 28.
Bids
28.2 The purchaser shall then apply the bid evaluation criteria, if any, as
indicated in the BDS and thereafter compare the evaluated prices of all
substantially responsive bids.
29. Abnormally
Low Bids

29.1 An abnormally low bid is one where the bid price, in combination
with other constituent elements of the bid, appears unreasonably low to
the extent that the bid price raises material concerns with the purchaser
as to the capability of the bidder to perform the contract for the offered bid
price.

Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

17

<!-- page 16 -->

29.2 In the event of identification of a potentially abnormally low bid, the
purchaser shall seek written clarification from the bidder, including a
detailed price analysis of its bid price in relation to the subject matter of
the contract, scope, delivery schedule, allocation of risks and
responsibilities and any other requirements of the bidding document.
29.3 After evaluation of the price analysis, in the event that the purchaser
determines that the bidder has failed to demonstrate its capability to
perform the contract for the offered bid price, the purchaser shall reject the
bid.
30. Contacting the 30.1 From the time of bid opening to the time of contract award, if any
Purchaser
bidder wishes to contact the purchaser on any matter related to the bid, it
should do so in writing.
30.2 Any effort by a bidder to influence the purchaser in its decisions on
bid evaluation, bid comparison, or contract award may result in the
rejection of the bid.

F. Award of contract
31. PostQualification

31.1 In the absence of pre-qualification, the purchaser will
determine to its satisfaction whether the bidder that is selected as
having submitted the lowest priced responsive bid is qualified to
perform the contract satisfactorily, in accordance with the criteria
listed in ITB clause 18.3.
31.2 The determination will take into account the bidder’s financial,
technical, and production capabilities. it will be based upon an
examination of the documentary evidence of the bidder’s
qualifications submitted by the bidder, pursuant to ITB clause 18.3,
as well as such other information as the purchaser deems necessary
and appropriate.
31.3 An affirmative determination will be a prerequisite for award of
the contract to the bidder. A negative determination will result in
rejection of the bidder’s bid, in which event the purchaser will proceed
to the next lowest evaluated bid to make a similar determination of
that bidder’s capabilities to perform satisfactorily.

32. Award Criteria 32.1 The purchaser shall award the contract to the successful
bidder whose bid has been determined to be substantially responsive
and has been determined to be the bid offering the best value for
money as per the stipulated bid evaluation criteria, provided further
that the bidder is determined to be qualified to perform the contract
satisfactorily.

Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

18

<!-- page 17 -->

33. Purchaser’s
Right to Vary
Quantities at
Time of Award

33.1 The purchaser reserves the right at the time of contract award
to increase or decrease, by the percentage indicated in the BDS, the
quantity of goods and related services originally specified in the
schedule of requirements without any change in unit price or other
terms and conditions.

34. Purchaser’s
34.1 The purchaser reserves the right to accept or reject any bid,
Right to Accept and to annul the bidding process and reject all bids at any time prior
Any Bid and to to contract award, without thereby incurring any liability to the
Reject Any or affected bidder or bidders.
All Bids
35. Notice of
Intention to
Award

35.1 Prior to the expiration of the period of bid validity, the purchaser
shall send the notice of intent to award to the successful bidder. the
notice of intent to award shall include a statement that the purchaser
shall issue formal notification of award and a draft contract
agreement after expiration of the period for filing a bid protest by
unsuccessful bidders and the resolution of any bid protests and or
appeals that are submitted thereof. Delivery of the notice of intent to
award shall not constitute the formation of a contract between
the purchaser and the successful bidder and no legal or equitable
rights shall be created through the delivery of the notice of intent to
award.
35.2 At the same time when it issues the notice of intent to award,
the purchaser shall also notify, in writing, all other bidders of the
results of the bidding. The purchaser shall promptly respond in
writing to any unsuccessful bidder who, after receiving notification of
the bid evaluation results, makes a written request for a debriefing,
or submits a formal protest as provided in the IFAD Procurement
Handbook.

36. Bid Protests

36.1 Bidders may protest the results of a procurement only in
accordance with the rules and within the time periods established in
the module M of the IFAD Procurement Handbook. In case the time
periods/deadlines for submitting a protest under the borrower’s
national procurement system differ from those stipulated in the IFAD
Procurement Handbook, the borrower’s regulation shall apply.

37. Notification of 37.1 Upon expiration of the period for timely filing and the resolution
Award
of any bid protests (and appeals, as applicable) and prior to the
expiration of the period of bid validity, the purchaser will notify the
successful bidder in writing by registered letter that its bid has been
accepted through a notification of award letter.
37.2 Until a formal contract is prepared and executed, the
notification of award shall constitute a binding contract.
37.3 Upon the successful bidder’s furnishing of the performance
security, the purchaser will promptly notify the name of the winning

Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

19

<!-- page 18 -->

bidder to each unsuccessful bidder and will discharge its bid security,
pursuant to ITB clause 20.

38. Signing of
Contract

38.1 At the same time as the purchaser notifies the successful
bidder that its bid has been accepted, the purchaser will send the
bidder the contract form provided in the bidding documents,
incorporating all agreements between the parties.
38.2 Within fourteen (14) days of receipt of the contract form, the
successful bidder shall sign and date the contract and return it to the
purchaser.

39. Performance
Security

39.1 Within fourteen (14) days of the receipt of notification of award
from the purchaser, the successful bidder shall furnish the performance
security equivalent to 5% of the contract value in accordance with the
conditions of contract, as per the performance security form provided in
the bidding documents, or in another form acceptable to the purchaser.
Failure of the successful bidder to comply with the requirements shall
constitute sufficient grounds for the annulment of the award and
forfeiture of the bid security, in which event the purchaser may make
the award to the next lowest evaluated bidder or call for new bids
after getting IFAD’s no objection whenever applicable.

Section II. Instructions to Bidders
[procurement title] - Ref. No: [insert reference number]

20

<!-- page 19 -->

Section III. Bid Data Sheet (BDS)
The following specific data for the goods to be procured shall complement, supplement, or
amend the provisions in the instructions to bidders (ITB). Whenever there is a conflict, the
provisions herein shall prevail over those in ITB.
Introduction
ITB clause 1.1

Name of purchaser/procuring entity: Nodal Officer, JKCIP, SKUAST
Jammu

ITB clause 1.1

The procurement number is: AUJ/AEABM/JKCIP/26-27/F-92(10)/790 [

ITB clause 1.1

Procurement description: Organizing of 7 Nos. Ideathons and
Bootcamps in different districts of Jammu Province of UT of J&K. The
contract awarded shall be completed within 6 (six) weeks from the
issue of award of contract.

ITB clause 1.2

Purchaser country: India

ITB clause 2.1

The borrower is: Nodal Officer, JKCIP, SKUAST Jammu
Total amount of financing: Rs.14.00 lakhs
The name of the project is: JKCIP, SKUAST Jammu.
The bidding documents

ITB clause 11.1

The purchaser’s address is: Block No.7, Ist Floor, SKUAST-J, Main
Campus, Chatha, Jammu, J&K-180009.
The purchaser shall respond to all requests for clarifications received
by three days before the last date for submission of bids.

ITB clause 11.2

A pre-bid conference will not be held.
Preparation and submission of bids

ITB clause 13.1

The bid must be submitted in the following language:English

ITB clause 16.5

The prices quoted by the bidder shall be lumpsum for one Bootcamp
and also total for 7 No. Bootcamps

ITB clause 17.1

The currency of the bid shall be as follows: INR
The currency(ies) of the payment shall be as follows: INR
The currency that shall be used for bid evaluation and
comparison is: INR.
The basis for conversion shall be: NA

ITB clause 18.2

At the present time firms, goods and services from the following
countries are excluded from this bidding process: NA

ITB clause 18.3 (a)

A manufacturer’s authorization not required.

Section III. Bid Data Sheet (BDS)
[procurement title] - Ref. No: [insert reference number]

21

<!-- page 20 -->

ITB clause 18.3 (b)

The required documentary evidence to be submitted by the bidder to
confirm its qualifications to perform the contract is as follows
i. Minimum level of experience in similar business: 3 years.
ii. GST Certificate and
iii. PAN Card.

ITB clause 18.3 (d)

Other required documentary evidence to be submitted by the bidder
to confirm its qualifications to perform the contract is as follows:
i. Business registration certificates;

ITB clause 19.1 (b)

NA

ITB clause 20.1 &
20.2

A bid-securing declaration is not required to be submitted with a bid.
A bid security is required to be submitted with a bid.
The amount of bid security shall be not less than Rs.28000/- (Rupees
twenty eight thousands only) in the shape of CDR/FDR pledged in
favour of the Comptroller, SKUAST Jammu.

ITB clause 21.1

The period of bid validity shall be 90 days days after the date for
submission of bids.

ITB clause 22.1

In addition to the original of the bid, the number of copies
required: NA.

ITB clause 23.1 (b)

The address for submission of bids is: On GeM portal

ITB clause 23.2 (c)

Invitation for bids title and procurement number:

ITB clause 24.1

Deadline for submission of bids is

ITB clause 25.1

The opening of bids shall take place online on GeM portal.

ITB clause 28.2

Evaluation will be based upon: As advertised.
and:

hours on

(date).

Bids will be evaluated for each item and the contract will comprise
the item(s) awarded to the successful bidder.
The bid evaluation will be in accordance with best value for money
bid evaluation criteria:
The award criteria shall be based on the Lowest Evaluated Cost.
Contract award
ITB clause 33.1

The percentage for quantity may increase or decrease upto 25%
percent.

Section III. Bid Data Sheet (BDS)
[procurement title] - Ref. No: [insert reference number]

22

<!-- page 21 -->

Section IV. Bidding Forms
1. Bid Form and Price Schedule
Date:
Procurement no:
We, the undersigned, declare that:
1. We have examined and have no reservations to the bidding document, including addenda
thereto issued in accordance with the instructions to bidders.
2. We offer to supply in conformity with the bidding document and in accordance with the delivery
schedules specified in Section V. Schedule of Requirements referenced above.
3. The total price of our bid, excluding any discounts offered in paragraph 4 below is: [insert the
total bid price in words and figures, including the various amounts and respective currencies].
4. The discounts offered and the methodology for their application are:


Discounts: If our bid is accepted, the following discounts shall apply. [Specify in
detail each discount offered and the specific item of the schedule of requirements
to which it applies.]



Methodology of application of the discounts: The discounts shall be applied using
the following: [Specify in detail the method that shall be used to apply the discount
in the case when the procurement is subdivided into lots.]

5. Our bid shall be valid from the date fixed for the bid submission deadline in accordance with
ITB sub-clause 24.1 through the period of time established in accordance with ITB sub-clause
21.1, and it shall remain binding upon us and may be accepted at any time before the expiration
of that period.
6. If our bid is accepted, we commit to obtain a performance security in accordance with GCC
clause 10. and as described in ITB clause 39 for the due performance of the contract.
7. We, including any subcontractors or sub-suppliers for any part of the contract, have
nationalities from eligible countries [Insert the nationality of the bidder, including that of all
parties that comprise the bidder, if the bidder is a joint venture, and the nationality of each
subcontractor and supplier].
8. Our firm, its associates, including any subcontractors or suppliers for any part of the contract,
have not been declared ineligible by the Fund and have not been subject to sanctions or
debarments under the laws or official regulations of the purchaser’s country or not been subject
to a debarment recognized under the Agreement for Mutual Enforcement of Debarment

Section IV. Bidding Forms
[procurement title] - Ref. No: [insert reference number]

23

<!-- page 22 -->

Decisions (the "Cross-Debarment Agreement")3 in accordance with ITB clause 4, beyond those
declared in paragraph 13 of this bid submission form.
9. We acknowledge and accept the IFAD Revised Policy on Preventing Fraud and Corruption
in its Activities and Operations. We certify that neither our firm nor any person acting for us
or on our behalf has engaged in any prohibited practices as provided in ITB clause 3.
Further, we acknowledge and understand our obligation to report to anticorruption@ifad.org
any allegation of prohibited practice that comes to our attention during the selection process
or the contract execution. As part of this, we certify that:
(a) The prices in this bid have been arrived at independently, without any
consultation, communication, or agreement with any other party, including
another bidder or competitor, or for the purpose of restricting competition, relating
to:
(i) those prices;
(ii) the intention to submit an offer; or
(iii) the methods or factors used to calculate the prices offered.
(b) The prices in this bid have not been and will not be knowingly disclosed by us,
directly or indirectly, to any other bidder or competitor before bid opening unless
otherwise explicitly required by law; and
(c) No attempt has been made or will be made by us to induce any other bidder to
submit or not to submit an offer for the purpose of restricting competition.
10. We acknowledge and accept the IFAD Policy on Preventing and Responding to Sexual
Harassment, Sexual Exploitation and Abuse. We certify that neither our firm nor any person
acting for us or on our behalf has engaged in any sexual harassment, sexual exploitation or
abuse, as provided in ITB Clause 4. Further, we acknowledge and understand our obligation
to report to ethicsoffice@ifad.org any allegation of sexual harassment, sexual exploitation and
abuse that comes to our attention during the selection process or the contract execution.
11. The following commissions, gratuities, or fees have been paid or are to be paid with respect to
the bid process: [Insert complete name of each recipient, its full address, the reason for which
each commission or gratuity was paid and the amount and currency of each such commission
or gratuity].
Name of recipient

Address

Reason

Amount

(If none has been paid or is to be paid, indicate “none.”)
12. We declare that neither the bidder nor any of its directors, partners, proprietors, key personnel,
agents, sub-consultants, sub-contractors, consortium and joint venture partners have any
actual, potential or perceived conflict of interest as defined in ITB Clause 7.3 regarding this bid
process or the execution of the contract. [Insert if needed: “other than the following:” and
3 The Cross-Debarment Agreement was entered into by the World Bank Group, the Inter-American

Development Bank, the African Development Bank, the Asian Development Bank and the European Bank for
Reconstruction and Development, additional information may be located at: http://crossdebarment.org/.
Section IV. Bidding Forms
[procurement title] - Ref. No: [insert reference number]

24

<!-- page 23 -->

provide a detailed account of the actual, potential or perceived conflict]. We understand that
we have an ongoing disclosure obligation on such actual, potential or perceived conflicts of
interest and shall promptly inform the purchaser and the Fund, should any such actual, potential
or perceived conflicts of interest arise at any stage of the procurement process or contract
execution.
13. The following criminal convictions, administrative sanctions (including debarments) and/or
temporary suspensions have been imposed on the bidder and/or any of its directors,
partners, proprietors, key personnel, agents, sub-consultants, sub-contractors, consortium
and joint venture partners:
Nature of the
measure (i.e.,
criminal conviction,
administrative
sanction or
temporary
suspension)

Imposed by

Name of party
convicted,
sanctioned or
suspended
(and
relationship to
bidder)

Grounds for the
measure (i.e., fraud
in procurement or
corruption in contract
execution)

Date and
time
(duration)
of
measure

If no criminal convictions, administrative sanctions or temporary suspensions have been
imposed, indicate “none”.
14. We acknowledge and understand that we shall promptly inform the purchaser about any
material change regarding the information provided in this bid form.
15. We further understand that the failure to properly disclose any of information in connection with
this bid form may lead to appropriate actions, including our disqualification as bidders, the
termination of the contract and any other as appropriate under the IFAD Policy on Preventing
Fraud and Corruption in its Projects and Operations.
16. We understand that this bid, together with your written acceptance thereof included in your
Notification of Award, shall only constitute a binding contract between the firm and the
purchaser subject to the preparation and execution of the appropriate contract.
17. We understand that you are not bound to accept the lowest evaluated bid or any other bid that
you may receive.
18. We further certify to have read, understood and agreed to be bound by the Privacy Policy of
IFAD (accessible at https://www.ifad.org/en/privacy).
Signed:
[Print name]
In the capacity of:
Duly authorized to sign on behalf of:
Section IV. Bidding Forms
[procurement title] - Ref. No: [insert reference number]

25

<!-- page 24 -->

Requirement and Price Schedule for Goods & Services Offered from within the
Purchaser’s Country
Name of bidder
. Procurement No.
_. Page _ of _.
Supply of Materials & Event Management Services for 7 (seven) Bootcamps of 2-Days
each across 7 Districts of Jammu Province of UT of J&K
Key Event Parameters:
Target Districts (07 Locations): Jammu, Kathua, Samba, Udhampur, Reasi, Ramban, and Doda
Event Duration: 02 Days per District (Total 14 Event Days / 07 Events)
Standard Batch Size: 60 Participants per District Bootcamp
Total Audience Covered: 420 Participants across all 7 districts

Bill of Quantities (BOQ) & Technical Specifications
S.
No.

Particulars /
Description

1

Participant Bags

2

Certificates

3

Writing Pens

4

Notepads

5

Flyers /
Handouts/
Pumphlets

6

Flex Banner

7

Standee

8

Badges / ID
Cards

9

Bouquet

10
11

Memento /
Trophy (Big)
Memento /
Trophy (Small)

12

Refreshments
(Tea & Snacks)

13

Refreshment
(Lunch)

14

Transport (Taxi)

Technical Specifications

High-density synthetic polyester fabric
(min. 200–230 GSM), inner
waterproof PVC coating, approx. 18” x
12” x 6” (~20L capacity)
A4 size, premium multi-color printing
on heavy cardstock / art paper
Blue gel point pen (standard quality
branded)
Spiral binding, 50 inner pages (72
GSM ruled paper), 150 GSM glazed
printed cover both sides, size 9”x6”
A4 size, full-color printed on glossy
paper
Size: 3 ft x 6 ft, high-quality full-color
flex printing
Size: 3 ft x 6 ft, roll-up standee with
full-color printing and aluminum frame
Paper-based, size 3.5” x 3”, with neck
lanyard and plastic sleeve/clip
Medium size arrangement with fresh
natural flowers
Size: 12 inches height, customized
logo & event printing
Size: 8 inches height, customized
logo & event printing
Tea/Coffee served with light snacks
(Biscuits etc.) — 2 times/day for 2
days
Standard Veg Buffet Lunch (Dal, Rice,
Sabzi, Roti, Salad & Sweets) — 1
time/day for 2 days
Sedan vehicle (e.g., Dzire/Etios) for
3–4 resource persons (To and Fro,
full-day availability for 2 days)

Section IV. Bidding Forms
[procurement title] - Ref. No: [insert reference number]

Qty per
Event (2
Days)

60 Nos.

Price
quote per
Event
(2 days)
Lumpsum
Price
Quote for
One Event

60 Nos.
60 Nos.
60 Nos.

Total Qty
(07 Events)

420 Nos.

420 Nos.
Rs.
(Rupees
)

Total
Price
quote for
7 Event
Total
Lumpsum
Price Q
Quote for 7
(seven)
Events

420 Nos.
Rs.
420 Nos.
(Rupees
)

60 Nos.

420 Nos.

1 No.

7 Nos.

1 No.

7 Nos.

60 Nos.

420 Nos.

2 Nos.

14 Nos.

3 Nos.

21 Nos.

6 Nos.

42 Nos.

60 Persons
x 2 Days
(120 pax)
60 Persons
x 2 Days
(120 pax)
1 Vehicle x
2 Days
(2 VehDays)

840 ManDays total
840 ManDays total
14 VehicleDays total
(7 Sedan
Vehicles)

26

<!-- page 25 -->

2. Bid Security Form

Whereas [name of the bidder] (hereinafter called “the Bidder”) has submitted its bid dated
[date of submission of bid] for the supply of [name and/or description of the goods]
(hereinafter called “the Bid”).
KNOW ALL PEOPLE by these presents that WE [name of bank] of [name of country], having
our registered office at [address of bank] (hereinafter called “the Bank”), are bound unto
[name of purchaser] (hereinafter called “the Purchaser”) in the sum of [amount] for which
payment well and truly to be made to the said Purchaser, the Bank binds itself, its
successors, and assigns by these presents. Sealed with the common seal of the said bank
this day of
20

.

The conditions of this obligation are:
1. If the Bidder
(a) withdraws its Bid during the period of bid validity specified by the Bidder on the bid
form; or
(b) does not accept the correction of errors in accordance with the instructions to bidders;
or
2. If the Bidder, having been notified of the acceptance of its Bid by the Purchaser during the
period of bid validity:
(a) fails or refuses to execute the contract form, if required; or
(b) fails or refuses to furnish the performance security, in accordance with the instructions
to bidders;
we undertake to pay to the Purchaser up to the above amount upon receipt of its first written
demand, without the Purchaser having to substantiate its demand, provided that in its
demand the Purchaser will note that the amount claimed by it is due to it, owing to the
occurrence of one or both of the two conditions, specifying the occurred condition or
conditions.This guarantee is enforceable and executable in the Purchaser’s country.
This guarantee will remain in force up to and including thirty (30) days after the period of bid
validity, and any demand in respect thereof should reach the Bank not later than the above
date.

[signature of the bank]

Section IV. Bidding Forms
[procurement title] - Ref. No: [insert reference number]

27

<!-- page 26 -->

Section VII. Contract
Contract Agreement
THIS AGREEMENT made the
day of
20
between
[name of purchaser] of the purchaser’s country (hereinafter called “the purchaser”) of
the one part and [name of supplier] of [city and country of supplier] (hereinafter
called “the supplier”) of the other part:
WHEREAS the purchaser invited bids for certain goods and ancillary services, viz.,
[brief description of goods and services] and has accepted a bid by the supplier for
the supply of those goods and services in the sum of [contract price in words and
figures] (hereinafter called “the contract price”).
NOW THIS AGREEMENT WITNESSETH AS FOLLOWS:
1. In this agreement words and expressions shall have the same meanings as
are respectively assigned to them in the conditions of contract referred to.
2. The following documents shall be deemed to form and be read and construed
as part of this agreement, viz.:
(a)
the purchaser’s notification of award.
(b)
(c)
(d)
(e)

the bid form;
the general conditions of contract (GCC)
the self-certification form
the specification (including schedule of requirements and technical
specifications) including price schedules.

(f)

any other document listed in GCC as forming part of the contract

3. In consideration of the payments to be made by the purchaser to the supplier
as hereinafter mentioned, the supplier hereby covenants with the purchaser to
provide the goods and services and to remedy defects therein in conformity in
all respects with the provisions of the contract.
4. The purchaser hereby covenants to pay the supplier in consideration of the
provision of the goods and services and the remedying of defects therein, the
contract price or such other sum as may become payable under the provisions
of the contract at the times and in the manner prescribed by the contract.
IN WITNESS whereof the parties hereto have caused this agreement to be executed
in accordance with their respective laws the day and year first above written.

Signed, sealed, delivered by
purchaser)

the

(for the

Signed, sealed, delivered by
supplier)

the

(for the

Section VII. Contract
[procurement title] - Ref. No: [insert reference number]

28

<!-- page 27 -->

Section VII (A). General Conditions of Contract
General Conditions of Contract

1. Definitions 1.1 In this contract, the following terms shall be interpreted as
indicated:
a) “Fund” means
Development.

the

International

Fund

for

Agricultural

b) “The contract” means the agreement entered into between the
purchaser and the supplier, as recorded in the contract form
signed by the parties, including all attachments and
appendices thereto and all documents incorporated by
reference therein.
c) “The contract price” means the price payable to the supplier
under the contract for the full and proper performance of its
contractual obligations.
d) “The goods” means all of the equipment, machinery,
commodities and/or other materials which the supplier is
required to supply to the purchaser under the contract.
e) “The services” means those services ancillary to the supply of
the goods, such as transportation and insurance, and any other
incidental services, such as installation, commissioning,
provision of technical assistance, training, and other such
obligations of the supplier covered under the contract.
f) “GCC” means the General Conditions of Contract contained in
this section.
g) “SCC” means the Special Conditions of Contract.
h) “The purchaser” means the entity purchasing the goods, as
named in the SCC.
i) “The purchaser’s country” is the purchaser’s country.
j) “The supplier” means the individual or firm supplying the goods
and services under this contract and named in SCC.
k) “The Project Site”, where applicable, means the place or
places named in the SCC.
l) “Day” means calendar day.
2. Application

2.1 These GCC shall apply to the extent that they are not superseded
by provisions of other parts of the contract.

Section VII. Contract
[procurement title] - Ref. No: [insert reference number]

29

<!-- page 28 -->

3. Country of
Origin

3.1 All goods and services supplied under the contract shall have
their origin in eligible countries and territories, as further elaborated in
the SCC.
3.2 For purposes of this clause, “origin” means the place where the
goods were mined, grown, or produced, or from which the services are
supplied. goods are produced when, through manufacturing,
processing, or substantial and major assembly of components, a
commercially recognized new product results that is substantially
different in basic characteristics or in purpose or utility from its
components. The origin of goods and services is distinct from the
nationality of the supplier.

4. Prohibited
Practices

4.1 The Fund requires that all beneficiaries of IFAD funding, including
the purchaser and any bidders, implementing partners, service providers,
suppliers, sub-suppliers, contractors, sub-contractors, consultants, subconsultants, and any of their agents (whether declared or not) and
personnel observe the highest standards of ethics during the
procurement and execution of such contracts, and comply with IFAD’s
Policy on Preventing Fraud and Corruption in its Activities and
Operations, revised on 12 December 2018 and attached as Section VIII
of this document (EB 2018/125/R.6, hereinafter “IFAD’s Anti-Corruption
Policy”).
4.2 For the purposes of these provisions, and consistent with IFAD’s
Anticorruption Policy, the terms set forth below are defined as follows,
and sometimes referred to collectively as “Prohibited Practices”:
a) “corrupt practice” is the offering, giving, receiving, or soliciting,
directly or indirectly, of anything of value in order to improperly
influence the actions of another party;
b) “fraudulent practice” is any act or omission, including a
misrepresentation, that knowingly or recklessly misleads, or
attempts to mislead, a party in order to obtain a financial or
other benefit or to avoid an obligation;
c) “collusive practice” is an arrangement between two or more
parties designed to achieve an improper purpose, including
improperly influencing the actions of another party;
d) “coercive practice” is impairing or harming, or threatening to
impair or harm, directly or indirectly, any party or the property
of any party, to improperly influence the actions of that or
another party;
e) “obstructive practice” is (i) deliberately destroying, falsifying,
altering or concealing evidence that may be material to an
investigation by the Fund or making false statements to
investigators in order to materially impede an investigation by
the Fund; (ii) threatening, harassing or intimidating any party in
order to prevent that party from disclosing its knowledge of

Section VII. Contract
[procurement title] - Ref. No: [insert reference number]

30

<!-- page 29 -->

matters relevant to an investigation by the Fund or from
pursuing such an investigation; and/or (iii) the commission of
any act intended to materially impede the exercise of the
Fund’s contractual rights of audit, inspection and access to
information.
4.3 The Fund will deny approval of a proposed contract award if it
determines that the firm or individual recommended for award, or any of
its personnel or agents, or its sub-consultants, sub-contractors, service
providers, suppliers, sub-suppliers and/or any of their personnel or
agents, has, directly or indirectly, engaged in any of the prohibited
practices in connection with an IFAD-financed and/or IFAD-managed
activity or operation, including in competing for the contract.
4.4 In accordance with IFAD’s Anticorruption Policy, the Fund has the
right to sanction firms and individuals, including by declaring them
ineligible, either indefinitely or for a stated period of time, to participate in
any IFAD-financed and/or IFAD-managed activity or operation. This may
include ineligibility to: (i) be awarded or otherwise benefit from any IFADfinanced contract, financially or in any other manner; (ii) be a nominated
sub-contractor, consultant, manufacturer, supplier, sub-supplier, agent or
service provider of an otherwise eligible firm being awarded an IFADfinanced contract; and (iii) receive the proceeds of any loan or grant
provided by the Fund. (iv)The Fund also has the right to unilaterally
recognize debarments by any of the International Financial Institutions
that are members to the Agreement for Mutual Enforcement of
Debarment Decisions if such debarments meet the requirements for
mutual recognition under the Agreement for Mutual Enforcement of
Debarment Decisions.
4.5 In addition, the Fund has the right to, at any time, declare a misprocurement and/or the ineligibility of any expenditures associated with a
procurement process or contract if it determines that prohibited practices
occurred in connection with this procurement process or contract and that
the borrower/recipient has not taken timely and appropriate action,
satisfactory to the Fund, to address such practices when they occur.
4.6 The supplier will take appropriate measures to inform potential subcontractors, sub-consultants, suppliers, agents and any of its personnel
of their obligations under IFAD’s Anticorruption Policy and require their
compliance with this policy in connection with their involvement in
competing for, or executing, this contract.
4.7 Bidders, suppliers, consultants, contractors, and their subcontractors, sub-consultants, service providers, suppliers, agents and
personnel, are required to fully cooperate with any investigation
conducted by the Fund into possible prohibited practices, including by
making personnel available for interviews and by providing full access to
any and all accounts, premises, documents and records (including
electronic records) relating to the relevant IFAD-financed and/or IFADmanaged operation or activity and to have such accounts, premises,
Section VII. Contract
[procurement title] - Ref. No: [insert reference number]

31

<!-- page 30 -->

records and documents audited and/or inspected4 by auditors and/or
investigators appointed by the Fund.
4.8 The supplier is obliged to disclose relevant prior sanctions and
criminal convictions and any commissions or fees paid or are to be paid
to any agents or other party in connection with this procurement process
or the execution of the contract.
4.9 If the Fund determines that the supplier, or any of its subcontractors, sub-consultants, suppliers, personnel or any agent or affiliate
of any of them has, directly or indirectly, engaged in prohibited practices
in connection with an IFAD-financed or IFAD-managed activity or
operation, including in competing for, or executing, this contract, the
purchaser may, by written notice, immediately terminate the supplier’s
employment under the contract and the provisions of GCC 27 shall apply.
4.10 The bidder shall keep all records and documents, including
electronic records, relating to this procurement process available for a
minimum of three (3) years after notification of completion of the process
or, in case the bidder is awarded the contract, execution of the contract.
5. Sexual
Harassment,
Sexual
Exploitation
and Abuse

5.1 The Fund requires that all beneficiaries of IFAD Funding, including
the purchaser and any bidders, implementing partners, service providers,
suppliers, sub-suppliers, contractors, sub-contractors, consultants, subconsultants, and any of their agents (whether declared or not) and
personnel comply with IFAD's Policy on Preventing and Responding to
Sexual Harassment, Sexual Exploitation and Abuse. Purchasers,
suppliers and bidders shall take all appropriate measures to prevent and
prohibit sexual harassment and sexual exploitation and abuse on the part
of their personnel and subcontractors or anyone else directly or indirectly
employed by them or any of subcontractors in the performance of the
contract. Purchasers, suppliers and bidders shall immediately report to
the purchaser or IFAD any incidents of sexual harassment and sexual
exploitation and abuse arising out of or in connection with the
performance of the contract or prior to its execution, including
convictions, disciplinary measures, sanctions or investigations. The
purchaser may take measures, including immediate termination of the
contract, against the supplier, its personnel or any subcontractors, if at
any time the purchaser becomes aware of proven acts of sexual
harassment, sexual exploitation and abuse by the supplier and/or its
personnel, directly or through an agent, in competing for, or in
performance of, this contract.

4

Inspections include all fact-finding activities deemed relevant by the Fund to address allegations or
other indications of possible Prohibited Practices. Such fact-finding activities may include, but are not
limited to: accessing and examining a firm's or individual's financial records and information, and
making copies thereof as relevant; accessing and examining any other documents, data or
information (whether in hard copy or electronic format) deemed relevant for the investigation or audit,
and making copies thereof as relevant; interviewing staff and other relevant individuals; performing
physical inspections and site visits; and obtaining third party verifications of information. It is the
responsibility of the firm or individual under inspection to ensure effective compliance with their duty to
cooperate vis-à-vis any potential local laws or regulations or other potentially conflicting obligations.
Section VII. Contract
[procurement title] - Ref. No: [insert reference number]

32

<!-- page 31 -->

6. SECAP
Performance
Standards

6.1 The contract shall be implemented in a manner consistent with
IFAD’s Social, Environmental and Climate Assessment Procedures
(SECAP), available on https://www.ifad.org/en/secap.

7. Standards

7.1 The goods supplied under this contract shall conform to the
standards mentioned in the technical specifications, and, when no
applicable standard is mentioned, to the authoritative standards
appropriate to the goods’ country of origin. Such standards shall be the
latest issued by the concerned institution.

8. Use of Contract8.1 The supplier shall not, without the purchaser’s prior written consent,
Documents anddisclose the contract, or any provision thereof, or any specification, plan,
Information
drawing, pattern, sample, or information furnished by or on behalf of the
purchaser in connection therewith, to any person other than a person
employed by the supplier in the performance of the contract. Disclosure
to any such employed person shall be made in confidence and shall
extend only so far as may be necessary for purposes of such
performance.
8.2 The supplier shall not, without the purchaser’s prior written consent,
make use of any document or information enumerated in GCC clause 8.1
except for purposes of performing the contract.
8.3 Any document enumerated in GCC clause 8.1, other than the
contract itself, shall remain the property of the purchaser and shall be
returned (all copies) to the purchaser on completion of the supplier’s
performance under the contract if so required by the purchaser.

9. Patent Rights

9.1 The supplier shall indemnify the purchaser against all third-party
claims of infringement of patent, trademark, or industrial design rights
arising from use of the goods or any part thereof in the purchaser’s
country.

10.Performance
Security

10.1 Within fourteen (14) days of receipt of the notification of contract
award, the successful bidder shall furnish to the purchaser the
performance security equivalent to 5% of the contract value.
10.2 The proceeds of the performance security shall be payable to the
purchaser as compensation for any loss resulting from the supplier’s
failure to complete its obligations under the contract.
10.3 The performance security shall be denominated in the currency of
this contract and shall be in one of the following forms:
a) a bank guarantee or an irrevocable letter of credit issued by a
reputable bank located in the purchaser’s country or abroad,

Section VII. Contract
[procurement title] - Ref. No: [insert reference number]

33

<!-- page 32 -->

acceptable to the purchaser, in the form provided in the bidding
documents or another form acceptable to the purchaser; or
b) a cashier’s or certified check.
10.4 The performance security will be discharged by the purchaser and
returned to the supplier not later than thirty (30) days following the date
of completion of the supplier’s performance obligations under the
contract, including any warranty obligations, unless otherwise specifiedn
SCC.
11. Inspections
and Tests

11.1 The purchaser or its representative shall have the right to inspect
and/or to test the goods to confirm their conformity to the contract
specifications at no extra cost to the purchaser.
11.2 The inspections and tests may be conducted at the discretion of the
purchaser.
11.3 Should any inspected or tested goods fail to conform to the
Specifications, the purchaser may reject the goods, and the supplier shall
either replace the rejected goods or make alterations necessary to meet
specification requirements free of cost to the purchaser.
11.4 The purchaser’s right to inspect, test and, where necessary, reject
the goods after the goods’ arrival at the purchaser’s destination.

12.Packing

12.1 The supplier shall provide such packing of the goods as is required
to prevent their damage or deterioration during transit to their final
destination.

13.Delivery and
Documents

13.1 Delivery of the goods and services shall be made by the supplier in
accordance with the terms of requirements.

14.Transportation 14.1 The transport of the goods to the destination or such other named
place of destination shall be arranged and paid for by the supplier and the
cost thereof shall be included in the contract price.
15.Incidental
Services

15.1 The supplier may be required to provide any additional services if
required.

16. Prices

16.1 Prices charged by the supplier for goods and services delivered and
services performed under the contract shall not vary from the prices
quoted by the supplier in its bid.

17.Change Orders 17.1 The purchaser may at any time, by a written order given to the
supplier make changes within the general scope of the contract in any one
or more of the following:
a) the place of delivery; and/or
b) the related services to be provided by the supplier.
Section VII. Contract
[procurement title] - Ref. No: [insert reference number]

34

<!-- page 33 -->

18.Contract
Amendments

18.1 No variation in or modification of the terms of the contract shall be
made except by written amendment signed by the parties.

19.Assignment

19.1 The supplier shall not assign, as a whole or in part, its obligations to
perform under this contract, except with the purchaser’s prior written
consent.

20.Subcontract

20.1 The supplier shall notify the purchaser in writing of all subcontracts
awarded under this contract if not already specified in the bid. Such
notification, in the original bid or later, shall not relieve the supplier from
any liability or obligation under the contract.

21.Delays in the
Supplier’s
Performance

21.1 Delivery of the goods and performance of services shall be made by
the supplier in accordance with the time schedule prescribed by the
purchaser in the schedule of requirements.

22.Liquidated
Damages

22.1 Subject to GCC clause 25, if the supplier fails to deliver any or all of
the goods or to perform the services within the period(s) specified in the
contract, the purchaser shall, without prejudice to its other remedies under
the contract, deduct from the contract price, as liquidated damages, a sum
equivalent to the percentage specified in the SCC of the delivered price
of the delayed goods or unperformed services for each week or part
thereof of delay until actual delivery or performance, up to a maximum
deduction of the percentage specified in the SCC. Once the maximum is
reached, the purchaser may consider termination of the contract pursuant
to GCC clause 27.

23.Termination for 23.1 The purchaser, without prejudice to any other remedy for breach of
Default
contract, by written notice of default sent to the supplier, may terminate
this contract in whole or in part:
a) if the supplier fails to deliver any or all of the goods and services
within the period(s) specified in the contract, or within any
extension thereof granted by the purchaser.
b) if the supplier fails to perform any other obligation(s) under the
contract; or
23.2 In the event the purchaser terminates the contract in whole or in part,
pursuant to GCC clause 27.1, the purchaser may procure, upon such
terms and in such manner as it deems appropriate, goods or services
similar to those undelivered, and the supplier shall be liable to the
purchaser for any excess costs for such similar goods or services.
However, the supplier shall continue performance of the contract to the
extent not terminated.

Section VII. Contract
[procurement title] - Ref. No: [insert reference number]

35

<!-- page 34 -->

24. Force Majeure 24.1 Notwithstanding the provisions of GCC clauses 25, 26, and 27, the
supplier shall not be liable for forfeiture of its performance security,
liquidated damages, or termination for default if and to the extent that its
delay in performance or other failure to perform its obligations under the
contract is the result of an event of force majeure.
24.2 For purposes of this clause, “force majeure” means an event beyond
the control of the supplier and not involving the supplier’s fault or
negligence and not foreseeable. Such events may include, but are not
restricted to, acts of the purchaser in its sovereign capacity, wars or
revolutions, fires, floods, epidemics, quarantine restrictions, and freight
embargoes.
24.3 If a force majeure situation arises, the supplier shall promptly notify
the purchaser in writing of such condition and the cause thereof. Unless
otherwise directed by the purchaser in writing, the supplier shall continue
to perform its obligations under the contract as far as is reasonably
practical, and shall seek all reasonable alternative means for performance
not prevented by the force majeure event.

25.Termination for 25.1 The purchaser may at any time terminate the contract by giving
Insolvency
written notice to the supplier if the supplier becomes bankrupt or otherwise
insolvent. In this event, termination will be without compensation to the
supplier, provided that such termination will not prejudice or affect any right
of action or remedy which has accrued or will accrue thereafter to the
purchaser.
26.Termination for 26.1 The purchaser, by written notice sent to the supplier, may terminate
Convenience the contract, in whole or in part, at any time for its convenience. The notice
of termination shall specify that termination is for the purchaser’s
convenience, the extent to which performance of the supplier under the
contract is terminated, and the date upon which such termination becomes
effective.
26.2 The goods that are complete and ready for shipment within thirty (30)
days after the supplier’s receipt of notice of termination shall be accepted
by the purchaser at the contract terms and prices. For the remaining
goods, the purchaser may elect:
a) to have any portion completed and delivered at the contract
terms and prices; and/or
b) to cancel the remainder and pay to the supplier an agreed
amount for partially completed goods and services and for
materials and parts previously procured by the supplier.
27.Settlement of
Disputes

27.1 If any dispute or difference of any kind whatsoever shall arise
between the purchaser and the supplier in connection with or arising out

Section VII. Contract
[procurement title] - Ref. No: [insert reference number]

36

<!-- page 35 -->

of the contract, the parties shall make every effort to resolve amicably such
dispute or difference by mutual consultation.
27.2 If, after thirty (30) days, the parties have failed to resolve their dispute
or difference by such mutual consultation, then either the purchaser or the
supplier may give notice to the other party of its intention to commence
arbitration, as hereinafter provided, as to the matter in dispute, and no
arbitration in respect of this matter may be commenced unless such notice
is given.
a) Any dispute or difference in respect of which a notice of intention
to commence arbitration has been given in accordance with this
clause shall be finally settled by arbitration. Arbitration may be
commenced prior to or after delivery of the goods under the
contract.
b) Arbitration proceedings shall be conducted in accordance with
the rules of procedure specified in the SCC.
27.3 Notwithstanding any reference to arbitration herein:
a) the parties shall continue to perform their respective obligations
under the contract unless they otherwise agree; and
b) the purchaser shall pay the supplier any monies due to the
supplier.
28.Limitation of
Liability

28.1 Except in cases of criminal negligence or willful misconduct, and in
the case of infringement pursuant to GCC clause 9,
a) the supplier shall not be liable to the purchaser, whether in
contract, tort, or otherwise, for any indirect or consequential loss
or damage, loss of use, loss of production, or loss of profits or
interest costs, provided that this exclusion shall not apply to any
obligation of the supplier to pay liquidated damages to the
purchaser; and
b) the aggregate liability of the supplier to the purchaser, whether
under the contract, in tort or otherwise, shall not exceed the total
contract price, provided that this limitation shall not apply to the
cost of repairing or replacing defective equipment.

29.Governing
Language

29.1 The contract shall be written in the language specified in the SCC.

30.Applicable Law 30.1 The contract shall be interpreted in accordance with the laws of the
purchaser’s country.

Section VII. Contract
[procurement title] - Ref. No: [insert reference number]

37

<!-- page 36 -->

31.Notices

31.1 Any notice given by one party to the other pursuant to this contract
shall be sent to the other party in writing to the address specified in GCC.
31.2 A notice shall be effective when delivered or on the notice’s effective
date, whichever is later.

32.Payment

32.1 100% within 30 days after successful completion of all 7 (seven)
events.

33.Taxes and
Duties

33.1 A foreign supplier shall be entirely responsible for all taxes, stamp
duties, license fees, and other such levies imposed outside the purchaser’s
country.
33.2 A local supplier shall be entirely responsible for all taxes, duties,
license fees, etc., incurred until delivery of the contracted goods to the
purchaser.
Sd/Nodal Officer
JKCIP, SKUAST Jammu

Section VII. Contract
[procurement title] - Ref. No: [insert reference number]

38
