---
doc_id: "c7b0abc3bfbc62c7"
source_url: "https://jkocmms.nic.in/SPCB_DOCUMENTS/circularinstructions0001.pdf"
ministry: "Pollution Control Committee, Jammu and Kashmir"
title: "Circular Instructions."
date: ""
pages: 2
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "04609333c55d0255"
---

<!-- page 1 -->

j |

7 Office of the Regional Director State Pollution Contro! Board eos Fre ٦

Jammu Ci WISWUCH OX).
on Cisculosd” pelf-
CIRCULAR INSTRUCTIONS
Subject: Receipt of Sch-1 / case for consent to establish / operate, operate-renewal / Form-l (HWA)
| All the District officers urider the control of Regional office are directed to receive the complete
cases only for consent to establish / operate / operate-renewal / Hazardous Waste Authorization to avoid
delay in processing for completion of shortcomings by the unit holder. In no case the incomplete cases be
received at District offices. The following documents are required to be mandatorily checked at the time of
receipt of cases in District offices for further submission to the Regional office :-
(A) Consent to Establish :- ह
1° Application’ form (Sch-1, Form-1 Hwa) duly filled in and signed by the Proprietor / authorized
representative)
ii. Detailed Project report which includes the details of raw material, product to be manufactured,
proposed PCD details, capital cast of unit (land, building and plant machinery)
i Location plan giving details of site and surrounding features,
iv Building plan giving details and sites proposed for pollution control devices.
۷ Permission from licensing authority
vi In case unit using ground water, the NOC from Central Ground Water Board needs to be
enclosed.

vii, Land papers of the unit.

De vill In case unit tg_be established outside Industrial area, NOC from nearby local residents (an
‏ھعولےہ‎ affidavit), BDO, Education, Health department, Forest department (DFO) for stone crusher / brick
Uap! oper kilns as per siting criteria of SPCB.

Agus’ Ik Consent fée as per norms
‏سو‎ (ie x. In case of expansion / enhancement in capacity, copy of DIC assessment and toll exemption

cat format be enclosed

‎‘Three sets of complete case‏ آ× ایا
‎sock (B) Documents to be submitted for renewal of Consent to Operate :-‏

‎AA 7 (}) Application form (Sch-1, Form-1 nwa) duly fiiled in and signed by the Proprietor / authorized‏ ک0

‎oo representative alongwith with three sets of all the relevant documents)
या (ii) SMR copy [done from approved laboratory by MOEF / CPCB / SPCB]
क्र (iii) Renewal fee as per prescribed rates in vogue.

‎J: (iv) Latest DIC assessment topy. हे
“A (v) Copy of the last consent issued.
a ۷
4 (vi) Details of previous notices issued by the Board
Amun 3
_——~_ "It is enjoined upon all the District officers to ensure that receipt is issued on receipt of application
with complete case with legible and attested copies of enclosures, ۰
‏ہت‎ =
4 \ 2 ‏کے کے‎
i ‏ہر‎ Fel.
; peste ‘tor ۶
No SPCB/RD-J/ 7५३७ -१७9 Sfate Pollution Control Board 1
Dt:- 23-12-2008 (Jammu
: als
Copy to x ः
1. All the District officers of Jammu region for information and necessary action
2 2. Section Officer (Conseng Section), Regional office Jammu for information and to ensure that
‏۲م‎ incomplete cases with rdspect to the documents mentioned above are not received in Regional
Tt office. He will further ensure that papers / documents / reply received from the unit holder are not
attached with case file without proper receipt and direction from competent authority.
1.५

<!-- page 2 -->

« /
(~
GOVERNMENT OF JAMMU & KASHMIR
J&k STATE POLLUTION CONTROL BOARD
Sheikh-ul-Alam Campus, Rajbagh, Stinagar -190 008
Tele/FAX:- 0-194-251 1163
CIRCULAR
I is informed to Regional Directors PCB Jammu/Kashmir, Nodal Officer
Leh/Kargil and all the District Officers of Pollution Control Board Jammu & Kashmir
that Poultry Farms having capacity upto 2000 binds per Cyele for rearing of Poultry
हे birds are exempted ftom obtaining Consent from the Board being a smaill scale farming
: activity not requiring use of machinery and equipment.
oh ‏,ا‎ However they will adopt all the proper measures to control the Pollution. ie
‏سے‎ eye? 1 ۲ हे 2 ٔ
aes Wee} sulopt the Deep Burial System for disposal of dead birds and composting system for
2ٰ٤ qusete [. disposing Organic Waste generated from the Poultry Farm
०. ‏تک‎ |
Sa - Lilies,
ro : is 0
‏ا رن‎ 2۵ ुलाकफल ‏ا امن‎
\ ۱ th |
۱ 10:-80 171700071 8703-3 ‏6وت‎ Date:- 20. &
ch a,
Copy to following for information and necessary aetion:-
‘Regional Director PCB Jammu/Kashmir. ॥
2. _ Divisional Forest Officer, Nodal Officer, SPCB, Leh/Kargil
3. All District Officers of PCB.
4. P-A. 10 Chairman for information to the worthy Chairman, SPCB
st :
on ‏کو(‎
‎हि ‏ج27 کچھ ۳۴۶ مم إفء!۹ 70 ا ہے‎ 4
S218 ( आम |
of . J-to ref +: Ay 2, ‏مد‎ Ss I
6 Ce 1 © ALL Kishase Pfr &
1 7۰۰
2a fe ‏ت7‎ of romeahten ‏بے‎ Led 7
g ely On / |
fat ۱
KL
7 Ce
JEE (Ate) ५४ 116 (71
“| De lena
dl. ‏اہ‎ IR G 2.
i } pros A te bey
‏وہ کے‎ ۱ |
हि i J
224 |201> a OG OK Gorn u
