---
doc_id: "1cabcf9de40da949"
source_url: "https://www.cujammu.ac.in/static/homepage/cells/eoc/guidelines2012-17.pdf"
ministry: "Central University of Jammu, Jammu and Kashmir"
title: "Guidelines"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "52fc0ec013d6c928"
---

<!-- page 1 -->

Guidelines
for
Scheme of Equal Opportunity Centre for Colleges
XII Plan (2012-2017)

University Grants Commission
Bahadurshah Zafar Marg
New Delhi – 110 002
UGC Website:

www.ugc.ac.in

<!-- page 2 -->

Equal Opportunity Centre in Colleges.
1. Introduction
India is a country of diversity. It is a hub of different religions, castes and cultures. However,
the Indian society is characterized by a highly entrenched system of social stratification. It is
these social inequalities that created the barriers of denial of access to materials, cultural and
educational resources to the disadvantaged groups of society. These disadvantaged groups are
SCs, STs, women, OBC (non-creamy layer), minorities and physically challenged persons. It
is clear from the demographic factors that a large section of population of our country is still
disadvantaged and marginalized.
Rigid compartmentalized caste system forced SCs to be socially deprived to render services
without any claim on returns. The deprivation of dignity, identity and rights resulted in their
dehumanization and humiliation. The toils and tears of STs were not very different from
those of SCs. The STs were isolated, neglected and exploited. Both SCs and STs continue to
suffer from social disabilities even today.
Women, victims of the past traditions and customs of the Indian society, were considered to
be unequal and inferior. Even today women are being oppressed. Since gender disparity is
known to lead to serious social imbalance, it is essential to neutralize these distortions of the
past. The minorities cluding Muslims, Sikhs,
Christians, Buddhists and others, collectively constitute about 19% of the Indian population.
The recent report of the Prime Minister’s High Level Committee on the social, economic and
educational status of the Muslim community of India has clearly indicated that the Muslim
community exhibits deficits and deprivation in practically all dimensions of development.
The same may be true with some variation in case of the other minorities. The physically
challenged persons deserve due place and attention in the demographic setup of the nation.
To ensure the same, the Parliament has passed the Act called the Person with Disabilities
(Equal opportunities, Protection of Right and Full Participation) Act 1995.
On achieving independence, the nation took a conscious decision to undo the social and
historic wrongs. For eradication of social disparities, various provisions were made in the
Indian Constitution. Our Constitution enshrined democratization as one of the main
objectives of education and anticipated the democratic expansion of education to serve social
and economic upward mobility.
The Indian education system seems to have been oriented only to meet the requirement of
one-third of the population, ignoring the interest of the rest. Indeed, historically education
was confined to certain sections of the society and did exclude large sections of the
population, making it highly undemocratic in matters of access. This exclusion in education
created ever expanding disparities that adversely affected the disadvantaged groups of the
society.
Since higher education is a tool for social and economic equality, the UGC has been
addressing national concerns of access, equality, while ensuring the standard of quality and
relevance of education by implementing policies of the Government of India and promoting
several schemes

<!-- page 3 -->

and programmes for the disadvantaged groups that would help in eliminating social
disparities.
India is potentially rich in human resources. To harvest the same and make the present
education system inclusive, the degree of democratization of higher education has to be
increased to a large extent. Further colleges should become more responsive to the needs and
constraints of the disadvantaged social groups. Therefore, the UGC has planned to establish
Equal Opportunity Centres in colleges.

2. Aims and Objectives
To oversee the effective implementation of policies and programmes for disadvantaged
groups, to provide guidance and counselling with respect to academic, financial, social and
other matters and to enhance the diversity within the campus.

3. Functions
i.
To ensure equity and equal opportunity to the community at large in the college and
bring about social inclusion.
ii.
To enhance the diversity among the students, teaching and non-teaching staff
population and at the same time eliminate the perception of discrimination.
iii.
To create a socially congenial atmosphere for academic interaction and for the growth
of healthy interpersonal relationships among the students coming from various social
backgrounds.
iv.
To make efforts to sensitize the academic community regarding the problems
associated with social exclusion as well as aspirations of the marginalized
communities.
v.
To help individuals or a group of students belonging to the disadvantaged section of
society to contain the problems related to discrimination.
vi.
To look into the grievances of the weaker sectionof society and suggest amicable
solution to their problems.
vii.
To disseminate the information related to schemes and programmes for the welfare of
the socially weaker section as well as notifications/memoranda, office orders of the
Government, or other related agencies/organizations issued from time to time.
viii.
To prepare barrier free formalities/procedures for admission/ registration of students
belonging to the disadvantaged groups of society.
ix.
To establish coordination with the Government and other agencies/organizations to
mobilize academic and financial resources to provide assistance to students of the
disadvantaged groups.
x.
To organize periodic meetings to monitor the progress of different schemes. 28
xi.
To adopt measures to ensure due share of utilization by SC/ST in admissions,
recruitments (teaching and non-teaching posts) and to improve their performances.
xii.
To sensitize the college on the problems of SC/ST and other disadvantaged groups.
4. Advisory Committee
There shall be an Advisory Committee with the Principal as Chairperson and three other
members including an Adviser, to review the implementation of various schemes and
programmes for the welfare of the disadvantaged and marginalized groups of the society and

<!-- page 4 -->

other related activities undertaken by the college as well as implementation of reservation
policy in admission and recruitment for SC, ST, PH, OBC (non-creamy layer) and others, if
any. The Committee should meet at least once in four months and action taken on decisions
are to be reviewed in the subsequent meetings. The Principal shall nominate one of the
teachers, who has an innate interest in the welfare of the disadvantaged social groups, as an
Adviser
(a) The Adviser in the college shall:
i.

ii.
iii.

iv.

oversee/monitor various welfare schemes/ programmes sponsored by the Government
of India/State Government, UGC or any agency/ organization as well as those devised
by the college/affiliating university for the disadvantaged groups for their effective
implementation
be responsible for the effective functioning of SC/ST Cell and other such
Cells/Centres dealing with the problems of different socially disadvantaged groups.
convene the meetings of incharge of other Committees/Programmes dealing with
social issues such as Gender Sensitization Committee against sexual harassment
(GSCASH), National Service Schemes (NSS) etc. to review their activities.
The Advisor shall submit the progress/review report to the Principal. The
Coordinators of SC/ST Cell, Remedial Coaching and other schemes/ Women’s Study
Centre, Population Education Cell etc. shall be closely associated with the Equal
Opportunity Centre. 29

5. Eligibility Conditions
Assistance under this scheme will be provided to all Colleges which have been included
under Sections 2(f) and 12B of the UGC Act, 1956.
6. Nature of Assistance
The UGC shall provide financial assistance to meet contingency expenditure, expenditure for
organizing meetings and honorarium to the Advisor, as given below:
1) Assistance to the Postgraduate Colleges and Undergraduate Colleges to the tune of
Rs.50, 000/- and Rs.30,000/- per annum respectively. The honorarium for the Advisor
shall be at the rate of Rs.1000/- per month.
2) Rs.25, 000/- per annum to organize a short-term course on positive discrimination of SC
and ST for national development at the beginning of every academic session for newly
enrolled students. At the end of the programme, the students may be asked to write a
summary of what they have learnt and a certificate may be issued to them.
7. Procedure of Release of Grant
The first year’s grant will be released after approval. The release of further grant would be
based on the utilization of earlier grant.

<!-- page 5 -->

PROFORMA ‐II
UNIVERSITY GRANTS COMMISSION
New Delhi
PRESCIBED FORMAT FOR GETTING FINANCIAL ASSISTANCE FOR EQUAL OPPORTUNITY CENTRE OF COLLEGES
DURING XII PLAN PERIOD.
1.

Name of the College : …………………………………….

2.

Address of the College : …………………………………….
Phone No. …………………Fax No. …………………………E‐Mail ……………………………….

3.

Name of the University its Affiliated to : ………………………………………

4.

Whether the College falls under Section 2(f) and 12(B) of the UGC Act : ………………………………………..

5.

Whether the College is Located under SC/ST/Minority concentrated District.

6. Whether receiving Non‐plan/
Plan Grant from UGC/State Govt. : ………………………………………..
(please indicate)
7. Bank Details :
1.
Name of Account Holder With Complete
Contact Address, Telephone Number and Email.
2.
3.

Bank Name
Branch Name With Complete
TelePhone Number And Email

4.
5.

Whether The Branch is Computerised?
Whether the Branch is RTGS Enabled? If Yes,
Then What is the Branch’s IFSC Code
Whether the Branch Also NEFT Enabled?
Type of Bank Account (SB/Current/Cash
Credit)
Complete Bank Account Number (Latest)
MICR Code of Bank

6.
7.
8.
9.

Address,

8. Need and justification of the proposal
(Please attach separate sheet giving full justification)
Signature:

Principal
With Seal

<!-- page 6 -->

Statement of Expenditure
Proforma for statement of expenditure incurred under the scheme of introduction of
Equal Opportunity Centre in Colleges.
1. Name of the Colleges________________________
2. Number and dated UGC approval: No. F. ________________ dated__________
3. Period to which the accounts related: w.e.f_______________ to_____________
4. Details of actual expenditure incurred.
Items

Allocation
Approved

Expenditure
Incurred

1. Honorarium to the advisor.
2. Organizing Meetings.
3. Contingency.
4. Organize short term courses.

Signature:

Principal
(Seal)

<!-- page 7 -->

UTILIZATION CERTIFICATE

Certified
that
the
grant
(Rupees________________________)
to_____________________

of

by University Grants Commission
No.___________ dated __________________ towards

Rs._________
Sanctioned
vide

its

letter

has been utilized
for the purpose for which it was sanctioned and in accordance with the terms
and conditions as laid down by the Commission. The university/college has
also utilized the amount of Rs. ________
as interest earned on the University Grants Commission grant.
If, as a result of check or audit objection, some irregularity is noticed at a later
stage, action will be taken to refund or regularize the objected amount.

Signature:
______________Signature:
___________

______________

Registrar/Principal
Auditor

Chartered

(Finance Officer)

Signature:

Accountant/Govt.

(Seal)_______________ (Seal) _______________ (Seal) ___________________
