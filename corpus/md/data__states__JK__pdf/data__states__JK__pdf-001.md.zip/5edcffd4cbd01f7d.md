---
doc_id: "5edcffd4cbd01f7d"
source_url: "https://www.bhadarwahheavens.com/pdf/e-19.pdf"
ministry: "Bhadarwah Development Authority (J&K Tourism), Jammu and Kashmir"
title: "e-NIT No:19 of 10/2022-23 Dated:03-10-2022 (E-tendering)."
date: ""
pages: 70
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c19c163a45a3042c"
---

<!-- page 1 -->

Government of Jammu & Kashmir

OFFICE OF THE CHIEF EXECUTIVE OFFICER
BHADARWAH DEVELOPMENT AUTHORITY
(Short Term) NOTICE INVITING TENDERS

e-NIT No:19 of 10/2022-23 Dated:03-10-2022 (E-tendering).
(Double Cover System)

5

6

7

@2% of
Adv.
Cost

18
Months

Position of AAA
Position of Tech. sanction

=
=

Class of Contractor

Time & Date of Opening of
tender (Technical Bid)

4
10,000/-

8
“A “Class

19-10-2022

Advertised Cost

2
Construction of 100 bedded hostel block in
RCC framed structure and providing water
supply and sanitary fittings of Jawahar
Institute of Mountaineering and Winter
Sports at Nalthi Bhadarwah.

Earnest Money
(In Lacs)

3
353.95

Cost of Tender Doc.
(in Rs)

Time allowed
for completion

1
1

Name of Work

S.No

For and on behalf of the Lt. Governor of Jammu and Kashmir UT, the Chief Executive Engineer
Bhadarwah Dev. Authority invites tenders by e-tendering mode on %age rates from approved and eligible
Contractors/Firms registered with J&K UT. CPWD, MES & Railways for the following works:-

Accorded
Accorded

1.

Date of Issue of Tender Notice

2.

Period of downloading of bidding documents

3.

Date, Time and place of pre-bid meeting

4.
5.

Bid submission Start Date
Bid Submission End Date

03-10-2022
From 03-10-2022,4:30 P.M to 17-10-2022,
4.00 P.M

03-10-2022 From 06.00 P.M
17-10-2022 up to 4.00 P.M
Only successful bidder who is declared as L1
6. Submission of hard copy of tender documents
should submit the hard copy after opening of
financial bids
19-10-2022 at 12.00 A.M in the Office of the
7. Date & time of opening of Technical Bids (Online)
Superintending Engineer PWD (R&B) Circle, Doda
To be notified after technical bid evaluation is
8. Date & time of opening of Financial Bids (Online)
completed
1.The Bidding documents Consisting of qualifying information, eligibility criteria, specifications, Drawings, bill of
quantities (B.O.Q), Set of terms and conditions of contract and other details can be seen/downloaded from the
departmental website www.jktenders.gov.in as per below schedule:
Note: *Cost of Bidding Document to be fixed by the tender inviting authority.

The bidders who have already participate the bidding, process of above said work their
tender cost & CDR shall remain same.

<!-- page 2 -->

1.

Bids must be uploaded along with Scanned coy of cost of Tender Document in shape of Bank receipt
favouring Chief

Executive

Officer, Bhadarwah Development

Authority indicating name of work by

depositing the requisite amount in Bhadarwah Development Authority‘s bank Account No 0030040100023389
at J&K Bank Main Branch Bhadarwah, IFSC Code NO. JAKAOBHADR. Scanned copy of the earnest money
/ bid security in shape of CDR / FDR pledged to Chief

Executive

Officer, Bhadarwah Development

Authority will also be required to be uploaded along with.(The date of Bank

reciept, earnest

money/bid security should be between the date of start of bid and bid submission end date)
The Bank Guarantee should be valid for 45 days beyond bid validity. The Qualification of Bidder
a)

Scanned copy of Registration Card duly renewed for the current financial year 2022-23 with Cell No, e-Mail and
Correspondence address.

b)

Affidavit for Correctness of information submitted with the Bid.

c)

Bidder shall furnish proof of latest returns in GST-3/GSTR-3B. (Preceding

Two Months i.e. June & July

2022).
d)

Copy of PAN card issued by the Income TAX Authority.

e)

The Cost of tender documents should be submitted by the bidder in shape of Treasury Challan/ Receipt having
the name of work, e_NIT No. and name of the Contractor mentioned and upload the same.

f)

Scanned copy of Earnest Money in shape of CDR/FDR @ 2% of Advt. cost from any Nationalized /Scheduled
Bank pledge to the Chief Executive Officer, Bhadarwah Dev. Authority.

g)

If at any point of time it is found that the contractor/bidder has submitted fake/fictitious/forged document for
competing or securing contract in the tendering process, then his bid security/performance security/deposits lying
with the Department/work done payment, if any shall be forfeited besides he shall also be put in black list.

h)

The bidders are directed to upload the copy of card verification issued by the SSP Crime Branch Jammu in case
of Kashmir based registration card.

i)

As per Chief Engineer PW (R&B) Department Jammu’s Circular No.CEJ/DB/6119-22 dated.18-09-2020 “ In case
of Macadamization

works, the qualification criteria for General Class Contractors, who are not registered Hot

Mix Plant Holders shall have to upload an undertaking on affidavit duly attested by the 1st Class Magistrate
stating that the work of Macadamization shall be executed by the successful General class Contractor/ Bidder,
exclusively by using paver finisher and the mixed aggregate shall be brought from the Hot Mix Plant existing in
nearby vicinity, thus over ruling the previous circular issued by this office vide No. CEJ/PS/Master/6482-95
dated 01-06-2019”. (Deleted)
j). “A, B & C” Class Civil Contractor may participate in E-Tendering for Macadamization work subject to condition that
they will upload an agreement deed with any Hot Mix Plant Holder (HMPO) form whom the materials shall be
procured. (As per circular issued vide Chief Engineer PW(R&B) Dept. Jammu’s No. CEJ/DB/2042-67 dated 0405-2021 & Corrigendum No. CEJ/DB/2115-39 dated. 06-05-2021. (Deleted)
k)
l)

Financial turn over, year-wise ,achieved on execution of civil engineering works for the last five years i ,e 201718 to 2021-22 duly certified by the Chartered Accountant.
Completion Certificate of having executed and completed or substantially completed successfully during the last
five years duly issued by an officer not below the rank of Executive Engineer or equivalent.

1.

After opening of the tender if the rates quoted by the lowest bidder is found to be high and
value of work is more than the advertised, he /she is advised to negotiate his/her quoted
rates with the department/ offer his/her consent within three days after opening of the
tenders, failing which the work shall be put to fresh tender.

1.1.

The Cost of tender documents should original instruments in respect of cost of documents, Bid
Security/ earnest money

and relevant documents of L1 bidder will be required to be submitted

to the Chief Executive Officer, Bhadarwah Dev. Authority within three days of opening of financial
bids on-line. No separate intimation about opening of financial bids will be sent by this office / by
the tender opening authority. In case the original documents are not submitted by the L-1 bidder

<!-- page 3 -->

within three days after opening of financial bid, the tender will be cancelled and the bidder will
not be allowed to participate in any further / future tendering process in the Authority for
a period of One year.
1.2.

The date and time of opening of Financial-Bids will be notified on Web Site www. jktenders.gov.in
and conveyed to the bidders automatically through an e-mail message on their e-mail address /
SMS on their registered mobile number. The Financial-bids of Responsive bidders shall be
opened online in the Superintending Engineer PWD (R&B) Circle Doda.

2.

Bidders can resubmit/withdraw the bids as specified.

3.

The bids for the work shall remain valid for a period of 120 days from the date of opening of
Technical bids.

4.

The bidder shall be disqualified from bidding for any contract with this office for a period of 02 Years from the
date of notification, If:-

a)

Any bidder/ tenderer withdraws his bid/ tender during the period of bid validity or makes any
modifications in the terms and conditions of the bid.

b)

Failure of Successful bidder to furnish the required performance security within specified time
period issue of letter of intent.

c)

In case contractor fails to execute the agreement within 07 days after fixation of contract.

5.

Instruction to bidders regarding e-tendering process.

6.1

Bidders are advised to download bid submission manual from the “Downloads” option as well as from
“Bidders Manual Kit” on website www.jktenders.gov.into acquaint bid submission process.

6.2.

To participate in bidding process, bidders have to get ‘Digital Signature Certificate (DSC)’ as per
Information Technology Act-2000. Bidders can get digital certificate from any approved vendors.

6.3.

The bidders have to submit their bids online in electronic format with digital Signature. No
financial bid will be accepted in physical form.

6.4.

Bids will be opened online as per time schedule mentioned in Para-2.

6.5.

Bidders must ensure to upload scanned copy of all necessary documents mentioned in NIT and
SBD with technical bid online. Besides, documents related to Technical bid be submitted
physically before date of opening of technical bid separately sealed and marked.

Note: - Scan all the documents on 100 dpi with black and white option.
6.

The department will not be responsible for delay in online submission due to any reasons.

7.

Bidders may contact office of the Chief Engineer PWD (R&B) Deptt. Jammu or concerned
Executive Engineer for any guidance for getting DSC or any other relevant details in respect of
e-tendering process.

8.

Bidders are advised not to make any change in BOQ (Bill of Quantities) contents. In no case they
should attempt to create similar BOQ manually. The BOQ downloaded should be used for filling
the item rate inclusive of all taxes and it should be saved with the same name as it contains.

9.

The %age rate method requires the bidder to quote a percentage above/below/at par of the
schedule of rates applicable/ as mentioned in the advertised BOQ. The percentage quoted by the
bidder shall be deemed to include price escalation and all taxes upto completion of work.
Deduction on account of taxes shall be made from bills of the contractor on gross amount of the
bill as per the rates prevailing at the time of recovery.

<!-- page 4 -->

10.

Bidders are advised to use “My Documents” area in their user on R&B e-Tendering portal to store
such documents as are required.

11.

Defect Liability Period:

the Defect liability Period be calculated from date of certified

completion of work and the period shall be 01 year.
The defects noticed in the work during execution or D.L.P shall be corrected by the contractor
within the length of time specified by the Engineer. If the contractor does not correct the
defects pertaining to D.L.P to the satisfaction of the Engineer within the time specified , the
Engineer will assess the cost of having the defects corrected and contractor will pay this amount
on correction of defects
12.

All key construction material (i.e, cement, steel, bitumen, pipes etc) shall have to be arranged by
the contractor strictly as per specifications with the approval of Engineer-in-charge.

13.

Qualification criteria for the work and other terms and conditions are contained in the bidding
document available on website.

14.

As per Chief Engineer PW(R&B) Dept. Jammu’s Circular No. CEJ/TS/23320-46 dated 31-12-2021
“to obtain Earnest Money Deposit (2% of the Advertised cost of the tender) form all the bidders
in shape of CDR/FDR before evaluation of technical bids. The EMD of successful bidder shall be
released after completion of the Defect Liability Period of the work.

15.

Unbalanced bids: the successful bidder L1 shall have to deposit

an additional performance

security in shape of CDR/FDR/BG before award of contract in case the bid of the lowest
bidder is found to be unbalanced and following scale shall be apply thereto:Sl. No

Percentage of unbalanced bid viz-a-viz.
advertised cost

Additional performance Security to
be deposited on quoted bid by L1

1

Upto and including 15% below

Nil

2

>15% upto and including 20% below

5%

3

>20% upto and including 25% below

10%

4

>25% upto and including 30% below

15%

5

>30% below

20%

The additional performance security shall be released only after successful completion of work .
16.

The earnest money in favour of unsuccessful bidder shall be released only after submission of Bank reciept.

17.

The design mix formula shall have to be got approved from the concerned Executive Engineer/Nodal Officer
before the start of work.

18.

Restoration of work: - On completion of contract the contractor shall be responsible to remove all un-sued
material and restore all work in its original position at his own cost.

19.

The contractor is bound to adhere to traffic regulation as is applicable from time to time and ensure
arrangements of smooth regulation of traffic during execution of work. Labour for Traffic control/watch
and ward as per necessity at site shall be supplied by the firm and nothing extra shall be paid in this behalf
by the Department.

20.

No payment shall be made without the required test from the PWD lab for density test as well as bitumen
quality test.

21.

Performance Security:
A) Within 07 (Seven) Days after the date of receipt of the letter of Acceptance, the successful
bidder/contractor shall deliver to the Employer/concerned authority, a performance security in any of

<!-- page 5 -->

the required forms for an amount of equivalent to 3% of value of contract and additional performance
security in the shape of CDR/FDR/BG for the unbalanced bid.
B) If the Performance Security is provided by the successful bidder in the form of a bank guarantee, it
shall be issued by either (a) at the Bidder’s option, by a Nationalized / Scheduled Indian Bank or (b) by a
foreign bank located in India and acceptable to the Employer.
22.

Failure of the successful bidder to comply with the requirements of Clause 21 (A) of e-NIT, the work shall
be allotted to 2nd lowest bidder at the rates of L1 or put to fresh tenders after forfeiting the bid security
@ 2% of successful bidder.

23.

The performance security shall be provided to the Employer not later than the date specified in the Letter
of Acceptance and shall be issued in an amount and form and by a bank or acceptable to the employer, and
denominated in Indian Rupees. The performance security shall be valid until a date 28 days from the date of
expiry of Defects Liability Period.

24.

As per Chief Engineer PW (R&B) Department Jammu’s Circular No. CEJ/PS/M/719 dated 22-09-2020, no
bidder will be allowed to withdraw his bid once he participated in the tendering process what so ever case
may be.

25.

If the Performance Security is provided by the successful bidder in the form of a bank guarantee, it shall
be issued by either (a) at the Bidder’s option, by a Nationalized / Scheduled Indian Bank or (b) by a foreign
bank located in India and acceptable to the Employer.

26.

As per J&K PWD Engineering Manual-2020, the qualification criteria for similar nature / Financial

Turnover should be strictly followed as under:S.
No

Particulars

Amount

Financial Turnover

Similar Nature

1

Civil Works

Upto ` 250.00 Lacs

Nil

Nil

2

All Civil Works

Above 250.00 Lacs

As per Chief Engineer
PW(R&B) Dept. Jammu’s
Corrigendum
No.
CEJ/TS/23445 dated.
01-01-2022,
the
applicant/participant/
bidder
should
have
achieved
a
minimum
annual value of civil
works of at least 50% of
the value of proposed
contract carried out in
any of the years (last
five years 2017-18 to
2021-22)
The
information supplied in
this connection should
be duly certified by a
Chartered
Accountant
and be duly supported by
TDS and Income Tax
Returns for the last five
years

Having
satisfactorily
completed
or
substantially
completed, at least
one contract of
similar nature of
work
of
any
Govt./Semi
Govt.
department during
the last five years
(building works of
at least 80% of the
value of proposed
contract
during
the last five years.
(Certificate to this
effect to be issued
by an officer not
below the rank of
Executive Engineer
or equivalent.

27. As per Chief Engineer PW(R&B) Dept Jammu’s Circular No. CEJ/DB/1700-1725 dated 27-04-2021
“The rectification of damages in riding surface during the Defect Liability Period shall be responsibility
of the Contractor”.
(i)
The tar to be used for Macadamization works shall be procured only from refineries only as
per the circular of MORTH dated August 24 th, 2018.
(ii)
The Defects Liability period shall be governed as per the circular of MORTH dated April 12 th
2012.

<!-- page 6 -->

28. “Adoption of J&K PWD Engineering Manual 2020” vide Chief Engineer PW(R&B) Dept.Jammu’s Circular
No. CEJ/ADM/124 of 2021 dated. 02-06-2021.
29. As per Chief Engineer PW(R&B) Dept. Jammu’s Circular No.CEJ/TS/20631-77 dated.09-12-2021:I)

II)

For Road/ Bridge works: as per clause 4.4(A) and 2.2 (A), Chapter 20 of PWD Engineering Manual 2020,
in case of Road/ Bridge works under MORTH, NABARD, and state sector, the guidelines as circulated
by MoRTH shall apply which states that One similar completed work costing no less than the amount
equal to 25% of the estimated cost( Advertised cost). (Deleted)
For Building works: as per clause 4.4(b) and 2.2.1 clasue chapter 20 of PWD Engineering Manual 2020
the guidelines as circulated for building works should be either of the following:
a) One similar completed work costing not less than the amount equal to 80% of the estimated cost (
Advertised cost) or;
b) Two similar completed work costing not less than the amount equal to 50% of the estimated cost (
Advertised cost) or;
c) Three similar completed work costing not less than the amount equal to 40% of the estimated cost (
Advertised cost).

Note : Definition of “Similar work” should be clearly defined. The completion certificate of
similar work should be of same nature as that of advertised work.
30. 10% of the tendered cost has kept for maintenance of road during Defect Liability Period ( Fixed)
Separately in NIT/Bid Documents for the purpose of “Routine Maintenance of road including
pavement, road side cross drainages including surface drains to the required standard to keep the
entire road surface and structure in defect free conditions during the entire Defect Liability period
which begins from the completion date of work.
31. The normal deposit of 10% shall be released as under:- 50% of the normal deposit shall be released
only after successful completion of 2nd year duly certified by the concerned Executive Engineer and
the balance 50% after successful completion of 3rd year duly certified by the concerned Executive
Engineer.
Contract Conditions; (deleted)
Rates quoted by the contractor shall be inclusive of cost of 5 year maintenance and an amount equal
to 10% of the total bid cost shall be retained by this office in addition to normal deposit. The same
shall be paid as per the following schedule.
i)

1.00% of the bid cost after satisfactory completion of maintenance work for the 1st Year

ii)

1.50% of the bid cost after satisfactory completion of maintenance work for the 2nd Year

iii) 2.00% of the bid cost after satisfactory completion of maintenance work for the 3rd Year

Deleted

iv) 2.50% of the bid cost after satisfactory completion of maintenance work for the 4th Year

v) 3.00% of the bid cost after satisfactory completion of maintenance work for the 5th Year .
32. Performance security shall be released only after the successful completion of Defect liability period.
(Deleted)
33. For the authentication of date of start of work, it shall be mandatory to upload geo-tagged
photographs of the start of work at the beginning and also at the time of completion of the work and
shall also be enclosed at the time of submission of work done claims for the work.
NOTE :
i)

The key construction materials like Cement, Tor Steel, Bitumen of required grade

(VG -10), etc. shall

be arranged/purchased by the Contractor/Firm on his own for the above said work and the quality of these
materials arranged/purchased by the Contractor/Firm shall have to be verified/passed by the concerned
Asstt. Executive Engineer before start of the work and during the currency of the work. The approved
brands of Cement/Tor Steel are as under :-

ii)

Cement of Ambuja, ACC, Birla Plus, JP Buland, Bangur, Ultratech or equivalent brand as
approved by the concerned Asstt. Executive Engineer.

iii)

Tor steel of SAIL, TATA TISCON, Rashtriya Ispat or equivalent brand as approved by the concerned
Asstt. Executive Engineer.

<!-- page 7 -->

No:
BDA/XEN/2022-23/827-41
Dated: 03-10-2022
(Er. Rajinder Kumar)
Executive Engineer
Bhadarwah Dev. Authority
Copy to the:-

1.
2.
3.
4.
5.
6.
7-8
9
10.
11-12
13-15

Secretary to Government Department of Tourism, Civil Secretariat Jammu/Srinagar.
Chief Engineer PW (R&B) Jammu
District Dev. Commissioner Doda.
Superintending Engineer PWD R&B Circle Doda.
Chief Executive Officer, Bhadarwah Dev. Authority.
Principal Jawahar Institute of Mountaineering and Winter Sports Nunwan Phalgam.
Executive Engineer PWD(R&B)Bhadarwah/Doda.
Executive Engineer PMGSY Division Doda.
Asstt. Executive Engineer Bhadarwah Dev. Authority.
President Contractor Association Bhadarwah/Doda.
Draftsman/Notice Board/Office file.

<!-- page 8 -->

SECTION

-1

INSTRUCTIONS TO BIDDERS

SECTION

-2

QUALIFICATION INFORMATION

SECTION

– 3

GENERAL CONDITIONS OF CONTRACT

SECTION

-4

SPECIAL CONDITIONS OF CONTRACT

SECTION

– 5

CONTRACT DATA

SECTION

-6

TECHINCAL SPECIFICATION

SECTION

-7

BILL OF QUANTITY BOQ (enclosed)

SECTION

– 8

SECURITIES AND OTHER FORMS

SECTION

- 9

DRAWINGs

SECTION 1:
INSTRUCTIONS TO BIDDERS (ITB)
A

Table of Clauses
General

1
2
3
4
5
6
7

Scope of Bid
Source of Founds
Eligible Bidders
Qualification of Bidder
One Bid per Bidder
Cost of bidding
Site visit

B
8

Bidding Documents
Content of Bidding Documents
Clarification of Bidding
Documents

9

20
21

Deadline for Submission of Bids
Modification & Withdrawal of Bids.

E

Bid Opening and Evaluation

22
23
24

Bid opening
Process to be confidential
Clarification of bids

25

Examination of Bids and Determination of
Responsiveness.

<!-- page 9 -->

10

Amendment of Bidding
Documents
Preparation of Bids

26

Evaluation and Comparison of Financial Bids.

27

Award of Contract

28

Employer’s Right to Accept any Bid and to Reject
any or all Bids.

29

Notification of Award and Signing of Agreement.

30
31
32
33

Performance security.
Advance Payment.
Dispute review Expert.
Corrupt or Fraudulent practices.

C
11
12
13
14
15
16
17
D
18

Language of Bid
Documents Comprising the Bid
Bid Prices
Currencies of Bid and
Bid Validity
Bid Security
Alternative Proposals by
Bidders.
Submission of Bids
Bidding through e-tendering
Electronic submission of bids

19

SECTION-1
INSTRUCTION TO BIDDERS

A.

GENERAL

1. Scope of Bid
1.1
The Employer (named in Appendix to ITB) invites bids for the construction of works (as defined
in these documents and referred to as “the works”) detailed in the table given in the ITB. The
bidders may submit bids for any or all of the works detailed in the table given in the ITB.
1.2
The successful bidder will be expected to complete the Works by intended completion date
specified in the Contract data.
1.3
Throughout these bidding documents, the terms “bid” and “tender” and their derivatives
(bidder/tender, bid/tender, bidding/tendering etc.) are synonymous.
2.
Source of Funds

<!-- page 10 -->

2.1
3.
3.1

The expenditure on the budget will be met from the budget of Govt. of India. .
Eligible Bidders
This Invitation for Bids is open to all Bidders (Individual/Joint Venture). Joint venture bidding

is allowed for the works costing Rs.15.00 Crores and above in J&K State.(to be read
with clause 2.11 of section 2 –qualification information.)
3.2

3.3
4.
4.1

4.2

All Bidders shall provide in Section-2, Forms of Bid and Qualification
Information, a statement that the Bidder is neither associated nor has been associated directly
or indirectly, with the consultant or any other entity that has prepared the design, specifications
and other documents for the project or being proposed as Project Manager for the Contract. A
firm that has been engaged by the Employer to provide consulting services for the preparation or
supervision of the work, and any of its affiliates shall not be eligible to bid.
Bidders from Joint Venture are allowed as per 3.1 and as per clause 2.11 of
Section- 2 (qualification Information).
Qualification of the Bidder (Technical Bid Qualification)
All Bidders shall provide in Section-2, Forms of Bid and Qualification Information, preliminary
description of the proposed work method and schedule, including drawings and charts, as
necessary. The proposed methodology should include programme of construction backed with
equipment planning and deployment duly supported with broad calculation and quality assurance
procedures along with Quality Assurance Plan(QAP), proposed to be adopted justifying their
capability of execution and completion of work as per technical specifications, within stipulated
period of completion.
in the event that prequalification of quotation bidders has been under taken, only bids for
prequalified bidders will be considered for award of contract,. The qualification bidders should
submit with their bids any information updating their original prequalification application’s
application or alternatively confirm in their bids that the originally submitted prequalification
remains essentially correct as of date of bid submission. The update of confirmation should be
provided in section 2 a copy of the original prequalification application and letter of
prequalification should also be furnished. With the updated information, the bidder must continue
to be qualified in accordance with the criteria laid down in the prequalification document. All
bidders shall also furnish the following the information in Section2.

4.3 GENERAL CONDITIONS
All the bidders shall include the following information and documents with their bids in
Section -3 Qualification Information unless otherwise stated in Appendix to ITB.
a)
Copies of original documents defining the constitution or legal status. Place of registration, and
principal place of business; written power of attorney of the signatory of the Bid to commit the
Bidder
b)
Scanned copy of Registration Card duly renewed for the current financial year 2022-23
c)
Affidavit for Correctness of information submitted with the Bid.
d)
Bidder shall furnish proof of latest returns in GST-3/GSTR-3B (Preceding Two Months)
e)
Copy of PAN card issued by the Income TAX Authority.
f)
The Cost of tender documents should be submitted by the bidder in shape of Bank reciept
having the name of work, e_NIT No. and name of the Contractor mentioned and upload the same.
.g)
h)

Scanned copy of Earnest Money in shape of CDR/FDR @ 2% of Advt. cost from any Nationalized
/Scheduled Bank pledge to the tender opening authority.
Financial turn over, year-wise ,achieved on execution of civil engineering works for the last five
years i ,e 2017-18 to 2021-22 duly certified by the Chartered Accountant

<!-- page 11 -->

j)

Completion Certificate of having executed and completed or substantially completed successfully
single wok of similar nature as defined under clause 4.6 (A-ii)of qualification criteria in any Govt. or
Semi- Govt Department during the last five years duly issued by an officer not below the rank of
Executive Engineer or equivalent.
k)
The bidder shall also furnish details
of other civil works of similar nature executed and
completed in any Govt. or Semi Govt. department during the last 5 years .and details of works
underway or contractually committed; and clients who may be contacted for further information
on those contracts;
l) Reports on financial standing of the bidder such as profit and loss statement ,balance sheet and
auditors report for the last five years and supported with ITR and TDS for the last five years.
m)
Major items of construction equipment proposed to carry out the Contract;
n)
Qualifications and experience of key site management and technical personnel proposed for
contract;
o)
Evidence of access to line(S) of credit and availability of other financial resources facilities (10%
of contract value), certified by the Bankers (Not more than 3 months old).
p)
Undertaking that the bidder will be able to invest a minimum cash up to 25% of contract value of
work, during implementation of work..
q)
Authority to seek references from the Bidder’s bankers;
r)
Information regarding any litigation, current or during the last five years, in which the Bidder is
involved, the parties concerned, and disputed amount.
s)
Power of attorney.
t)
The proposed methodology and programme of construction, backed with equipment planning and
deployment, duly supported with broad calculations and quality control procedures proposed to be
adopted, justifying their capability of execution and completion of the work as per technical
specifications within the stipulated period of completion as per milestones. The bidder shall
prepare the QAP (Quality Assurance Plan) as per the manual /guidelines available on the
departmental website.(refer Clause 4.1 &4.2 of ITB)

.
4.4 Bids for joint venture are accepted for the works valuing Rs.15.00 Crore and

4.5

above .(to be
Information.)

read with clause 2.11& 2.12 of section -2 –Qualification

Base year and Enhancement factors.:The base year shall be taken as (particular year to be mentioned)
Following enhancement factors will be used only for determination of available bid capacity for
the cost of works executed and the financial figures arrived thereof to a common base value for
works completed in India. No escalation factor is allowed for similar nature of work.
Year before
Multiplying factor
one
1.08
two
1.17
three
1.26
four
1.36
five
1.47
Applicant should indicate actual figures of costs and amount for the works executed by them
without accounting for the above mentioned factors.

<!-- page 12 -->

In case the financial figures and value of completed works are in foreign currency, the above
enhanced multiplying factors will not be applied,. Instead, current market exchange rate (State
Bank of India BC selling rate as on the last date of submission of the bid) will be applied for the
purpose of conservation of amount in foreign currency into Indian rupees.

(4.6)A: To qualify for the award of contract ,each bidder should have in the last
five years:
(i) All Civil Works upto Rs. 250.00 lacs Nil similar nature.

Achieved a minimum average financial turnover on execution of Civil Engineering works ( defined
as billing for works in progress or completed in all classes of Civil Engineering construction works
only) during any three out of the last five financial years 2017-18 to 2021-22 not less than
50% of the proposed contract /contracts applied. The information supplied in this connection
should be duly certified by a Chartered Accountant and be duly supported by TDS and Income
Tax Returns for the last five years.
(ii) Having satisfactorily completed or substantially completed, at least one contract of similar nature
of work of any Govt./Semi Govt. department during the last five years (road and /or bridge
works -as the case may be )of at least 25% of the value of proposed contract during the last five
years.(Certificate to this effect to be issued by an officer not below the rank of Executive
Engineer or equivalent.). No escalation factor is allowed for similar nature of work.
The work may have been executed by the Applicant as prime contractor or as a member of joint
venture. In case a project has been executed by a joint venture, weightage towards experience of
the project would be given to each joint venture partner in proportion to their participation in the
joint venture.
Substantially completed works means those works which are at least 90% completed as on the
date of submission of bid (i.e. gross value of work done up to the last date of submission is 90% or
more of the original contract price) and continuing satisfactorily.
For this a certificate from employer shall be submitted along with the application
incorporating clearly the name of the work, contract value, billing amount, date of
commencement of works, actual date of completion of work, satisfactory performance of the
contractor and any other relevant information.
The certificate should be furnished as per format shown in qualification information section2 clause no:-1.3.1 supported with allotment which shall also be uploaded.

NOTE: The requirement in respect of clause 4.6A(i) (Financial Turnover) shall be
50% of advertised cost of the work for all such works with estimated value less than
40.00 crores to 1.00 Crore while in case of works valuing 40.00 crores and above
the requirement shall be 40% of advertised cost of the particular work. Similarly
the requirement in respect of clause 4.6 –A-ii(similar nature of work)it shall be 50%
of advertised cost of work for all such works valuing less than 40.00 crores and for
the works with estimated value of Rs.40.00 crores and above it shall be 40% of the
advertised cost of the particular work

4.6 (B) Each bidder should further demonstrate:
(a)
Availability (either owned or leased or by procurement) of the for key and critical equipment for
this work as per Annexure –I below.
(To be included for bids valued over/above Rs.5.00 Cr).
Based on the studies, carried out by the Engineer, the minimum suggested major equipment to
attain the completion of works in accordance with the prescribed construction schedule are shown
in the Annexure-I below:-

<!-- page 13 -->

LIST OF KEY PLANT & EQUIPMENT TO BE DEPLOYED ON CONTRACT WORK
S.no Type of Equipment
Maximum Age
Work valuing
Above 15
As on 01-10up to 15 crores
crores
2017
UptoRs.30.00
Crore.
1
Tipper Trucks
5-7
3
5
2
Motor Grader
5
1
1
3
Dozer
5
1
1
4
Front end Loader
5
1
1
5
Smooth Wheeled Roller
5
1
2
6
Vibratory Roller
5
1
1
7
Hot Mix Plant with Electronic Controls
5
1
1
(Minimum 4060 TPH Capacity)
8
Paver Finisher with Electronic Sensor
5
1
1
9
Water Tanker
5
1
1
10
Bitumen Sprayer
5-7
1
1
11
Cold Milling Machine
5
1
1
12

Tandem Roller

5

1

1

The Bidders should, however, undertake their own studies and furnish with their bid, a detailed
construction planning and methodology supported with layout and necessary drawings and calculations
(detailed) as stated in clause 12 of ITB to allow the employer to review their proposal. The numbers,
types and capacities of each plant/equipment shall be shown in the proposals along with the cycle time
for each operation for the given production capacity to match the requirements.
(b) Availability for this work of personnel with adequate experience as required as per
Annexure-II.
LIST OF KEY PERSONNEL TO BE DEPLOYED ON CONTRACT WORK
S.NO PERSONAL
QUALIFICATION
Up to 15 crores
15 crores above Up
to Rs.30.00 Crore.
1
Project Manager
B.E Civil +10Years Exp
1
1 No
2

Site Engineer

3

Plant Engineer

4

Quantity Surveyor

Or Diploma in Civil with 15
years experience
B.E Civil +3Years Exp
Or
Diploma with 7 years
experience
B.E Mech. + 3 Years Exp.
Or
Dip. Mech.+ 7 Years Exp.
B.E Civil. + 7 Years Exp.
Or
Dip. Civil.+ 10Years Exp.

1

2 No

1

1 No

1

1 No

<!-- page 14 -->

5

Soil & Material
Engineer

B.E Civil. + 7 Years Exp.
Or
Dip. Civil.+ 10Years Exp.

1

1 No

6

Survey Engineer

B.E Civil+5 years Exp.
Or
Dip. Civil + 8 years Exp.

1

1 No

(c)Liquid assets and/ or availability of credit facilities of no less than amount indicated in Appendix to
ITB (credit lines / letter of credit certificates from banks for meeting the funds requirement etc.
usually the equivalent of the estimated cash flow for three months in peak construction period)
4.6(C) To qualify for a package of contracts made up of this and other contracts for

4.7

which bids are invited in the ITB, the bidders must demonstrate having experience
and resources sufficient to meet the aggregate of the qualifying criteria for the
individual contracts.

Bidders who meet the minimum qualification criteria will be qualified only if their available bid
capacity is more than the total estimated cost of the works. The available bid capacity will be
calculated as under: Assessed

Available Bid capacity = (AxNxM-B)
A=

Maximum value of civil engineering works executed in any one year during the last five years (

N=

updated to the current price level @8 percent a year ) taking into account the completed
as well as works in the progress
Number of years prescribed for completion of the works for which bids are invited =

M
B=

4.8
i.
ii.
iii.
5.
5.1
6.
6.1
7.
7.1

=M factor shall have a value of 2.5
Value (updated to the current price level of the year indicated in appendix) of existing
commencements and ongoing works to be completed during the next 03 years (period of
completion of the works for which bids are invited)
Note: The statements showing the value of existing commitments and on-going works as well
as the stipulated period of completion remaining for each of the works listed should be
countersigned by the Engineer in charge, not below the rank of an Executive Engineer or
equivalent. The certificate should be furnished as per format shown in qualification
information (Section-2) .
Even though the Applicants meet the above qualifying criteria, they are subject to be disqualified
if they have:
Made misleading or false representations in the forms, statements and attachments submitted;
and / or
Record of poor performance such as abandoning the works not properly completed the contract inordinate
delays in completion, litigation history or financial failure etc and /or
Participated in the previously bidding for the same works and had quoted unreasonably high bid prices and
could not furnish rational justification to employer
One Bid per Bidder
Each Bidder shall submit only one bid for one work. A Bidder who submits more than one bid for one
work will cause the proposals with the Bidder’s participation to be disqualified.
Cost of Bidding Document
The Bidder shall bear all costs associated with the preparation and submission of his bid and the Employer
will in no case be responsible or liable for those costs.
Site Visit
The Bidder, at the Bidder’s own responsibility and risk is encouraged to visit and examine the Site of
Works and its surroundings and obtain all information that may be necessary for preparing the Bid and

<!-- page 15 -->

entering into a contract for construction of the Works. The costs of visiting the Site shall be at the
Bidder’s own expense.

B. BIDDING DOCUMENTS
8.
8.1

Content of Bidding Documents
The set of Bidding documents comprises the documents listed below and Addenda issued in
accordance with Clause 10 of ITB.
1. Notice Inviting Tender
2. Instructions to Bidders
3. Qualification Information
4. Conditions of Contract (Part-I General Conditions of Contract, and Contract data; part II
Special Conditions of Contract).
5. Specifications
6. Drawings
7. Bill of Quantities
8. Form of Bid
9. Form of Acceptance, Form of Agreement, Issue of Notice to Proceed with the work
10. Forms of Securities and Form of Unconditional Bank Guarantee.

8.2

The bid document is available online on the website http://www.jktenders.gov.in.
The bid document can be downloaded free of cost, however, the bidder is
required to submit Demand Draft towards cost of bid document in favour of the
name given in the Bid Data Sheet.
8.3
The bidder is expected to examine carefully all Instruction, Conditions of Contract, Contract
Data, Forms, Terms, Technical Specifications, Bill of Quantities, Annexes and Drawings in the Bid
Document. Failure to comply with the requirements of bid submission will be at the bidder’s own
risk. Pursuant to clause 26 hereof bids which are not substantially responsive to the requirements
of the bidding documents shall be rejected.
9.
Clarification of Bidding Documents
9.1
The electronic bidding system provides for online clarification. A prospective bidder requiring any
clarification of the bidding document may notify online the authority inviting the bid .The
authority inviting the bid will respond to any request(s) for clarification received earlier than 10
days prior to the dead line for submission of bids. Description of clarification sought and the
response of the authority inviting the bid will be uploaded for information of the public or other
bidders without identifying the source of request for clarification.
9.2
Pre-bid Meeting
9.2.1 The bidder or his official representative is invited to attend a pre-bid meeting, which will take
place at the address, venue, time and date as indicated in NIT.
9.2.2 The purpose of the meeting will be to clarify issues and to answer questions on any matter that
may be raised at that stage.
9.2.3 The bidder is requested to submit any questions in writing or by cable to reach the employer not
later than two days before the meeting.
9.2.4 Minutes of the meeting, including the text of the questions raised (without

<!-- page 16 -->

Identifying the source of enquiry) and the responses given will be transmitted without delay to all
bidders. Any modification of the bidding documents listed in Sub-Clause 8.1which may become
necessary as a result of the pre-bid meeting shall be uploaded and bidder shall be automatically
informed through messaging/mail through jktenders.gov.in.
9.2.5 Non-attendance at the pre-bid meeting will not be a cause for disqualification of
a bidder.
10.
Amendment of Bidding Documents
10.1
Before the deadline for submission of bids, the Employer may modify the bidding
documents
by issuing online corrigendum. The corrigendum will appear on the web page of the
website www. Jktenders.gov.in under the “Latest Corrigendum” and e-mail notification is also
automatically sent to those bidders who have moved this tender to their “My tenders” area.
10.2 Any addendum thus issued shall be part of the bidding documents and shall be
deemed to have been communicated to all the bidders who have moved this tender to their “My
Tenders” area. In case any addendum/ Corrigendum, the system will automatically send e-mail to
all bidders who have downloaded the bidding document.
10.3 To give prospective bidders reasonable time in which to take an addendum into
account in preparing their bids, the Employer shall extend, as necessary, the deadline for
submission of bids, in accordance with Clause 20.2 of ITB.

C. PREPARATION OF BIDS

11.
11.1

Language of the Bid
All documents relating to the bid shall be in English language.

12.

Document Comprising the Bid

12.1

The bid to be uploaded by the bidder as Volume V of Bid document (Refer Clause 8.1) shall be in
two separate parts.
Part I shall be named “Technical Bid” and shall comprise.
i)
Bid Security and Bid document fee in the form as specified in Section 8
ii)
Qualification Information and supporting documents as specified in Section 2.
iii)
Certificates, undertaking, affidavits in section 2.
iv)
Any other information pursuant to clause 4.0 of these instructions.
v)
Undertaking that, the bid shall remain valid for the period of 120 days after the deadline of date
of opening of technical bids mentioned in the NIT.
vi)
Acceptance/non- acceptance of dispute review expert
Part-II of the bid shall be named as “ Financial Bid” “and shall comprise
(i)
Form of Bid as specified in Section 6.
(ii)
Priced Bill of Quantities for items specified in Section 7.
12.2(a)
The documents and details mentioned in clause 12.1 Part I, financial Turnover for the last five
financial years supported with all other documents as required as per NIT and SBD must be uploaded by the
bidder with his technical bid online on website www.jktenders.gov.in.
Bidders must ensure to upload scanned copy of all necessary documents mentioned in NIT and SBD with
technical bid. Besides, documents related to Technical bid be submitted physically before date of opening of
technical bid

<!-- page 17 -->

(b). Submission of Original Documents: The bidders are required to submit (i)
original Treasury Challan/ Receipt towards the cost of bidding
document(ii)original bid security in approved form and (iii)original affidavit
regarding correctness of information furnished with the bid as per the
provisions of clause -4 of ITB (iv)and any other document if required as per
the conditions of the bidding document with the office specified in the
bidding document Only successful bidder who is declared as L1 should submit
the hard copy after opening of financial bids.
12.3

Following documents, which are not submitted with the Bid, will be deemed to be part of the Bid
separately sealed and marked
Section
Particulars
1
Notice Inviting Tender
2
Instruction to Bidders(ITB)
3-4
Conditions of Contract
5
Contract Data
6
Specifications
9

Drawings

13. Bid Prices:
13.1
The Contract shall be for the whole Works, as described in Clause 1.1 of ITB, based on the
priced Bill of Quantities submitted by the Bidder online.
13.2 The Bidder shall make online entries to fill the Item Rates in Bill of Quantities.
Item Rate Method requires the bidder to quote rates and prices for all items of the Works
described in the Bill of Quantities. The items for which no rate or price is entered by the
Bidder will not be paid for by the Employer when executed and shall be deemed covered by
the other rates and prices in the Bill of Quantities. Upon numerical entry, the amount in words
would automatically appear and upon entry of rates in items of work, total bid price would
automatically be calculated by the system and would be displayed.
Percentage Rate method requires the bidder to quote a percentage above/below /at par of
the schedule of rates applicable/as mentioned in the advertised BOQ.
13.3 All duties, taxes and other levies payable by the Contractor under the contractor, or for any
other cause including GST, shall be included in the rates, price and the total bid price submitted
by the Bidder.
13.4 The rates & prices quoted by the bidder shall be fixed for the duration of the contract and shall
not be subject to adjustment or any account.
14.

Currencies of Bid and Payment

14.1

The unit rates and the prices shall be quoted by the bidder entirely in Indian Rupees. All
payments shall be made in Indian Rupees.

15.

Bid Validity

<!-- page 18 -->

15.1

Bids shall remain valid for a period not less than 120 days (One hundred twenty days) after the
deadline date for opening of Technical bids as specified in NIT. A bid valid for a shorter period
shall be rejected by the Employer as non-responsive. In case of discrepancy in bid validity period
between that given in the undertaking pursuant to Clause 12.1 (v) and the Form of Bid submitted
by the Bidder, the latter shall be deemed to stand corrected in accordance with the former and
the Bidder has to provide for any additional security that is required.

15.2

In exceptional circumstances, prior to expiry of the original time limit, the Employer may request
that the bidders may extend the period of validity for a specified additional period. The request
and the bidders’ responses shall be made in writing or by cable. A bidder may refuse the request
without forfeiting his Bid security. A bidder agreeing to the request will not be required or
permitted to modify his bid except as provided in 15.3 hereinafter, but will be required to extend
the validity of his Bid security for a period of the extension, and in compliance with Clause 16 in
all respects.

15.3

Bid evaluation will be based on the bid prices without taking into consideration the above
correction.

16.

Bid Security

16.1

The bidder shall furnish as part of his Bid, a Bid Security in the amount as shown in Column 5 of
the table of (NIT) for this particular work. This bid security shall be in favour of employer as
named in Appendix and may be in one of the following forms:
a. Deposit-at-call Receipt from any scheduled Indian Bank or a foreign Bank
located in India and approved by the Reserve Bank of India.
b. Bank Guarantee from any scheduled Indian bank, in the format given in Volume
c. Fixed Deposit Receipt, issued by any Scheduled Indian Bank or a foreign Bank
approved by the Reserve Bank of India.

16.2

Bank Guarantee (and other instruments having fixed validity) issued, as surety for the bid shall be
valid for 45 days beyond the validity of the bid.

16.3

Any bid not accompanied by an acceptable Bid Security and not secured as indicated in SubClauses16.1 and 16.2 above shall be rejected by the Employer as non-responsive.

16.4

The Bid Security of the unsuccessful bidder will be returned within 28 days of the end of the bid
validity period specified in sub-clause 15.1.

16.5

The Bid Security of the Successful bidder will be discharged when the bidder has signed the
Agreement and furnished the required Performance Security.

16.6

The Bid Security may be forfeited
a) If the Bidder withdraws the bid after bid opening during the period of bid
validity;
b) In the case of a successful Bidder, if the Bidder fails within the specified
time limit to
i) Sign the Agreement and/or
ii) Furnish the required Performance Security

<!-- page 19 -->

17.

Alternative Proposal by Bidders

17.1

Bidders shall submit offers that fully comply with the requirements of the bidding documents,
including the condition of contract (including mobilization advance or time for completion), basic
technical design as indicated in the Drawings and Specifications. Conditional offer or alternative
offers will not be considered further in the process of tender evaluation.

Online Submission of Bids
18. Bidding through E-Tendering System:
18.1 The bidding under this contract is electronic bid submission through website
www.jktenders.gov.in. Detailed guidelines for viewing bids and submission of online bids are given
on the website. The Invitation for Bids under Bhadarwah Dev. Authority published on this website
i.e bhadarwahheavens.com. Any citizen or prospective bidder can log on to this website and view
the Invitation for Bids and can
view the details of works for which bids are invited. The
prospective bidder can submit bids on line; however, the bidder is required to have
enrolment/registration in the website and should have valid Digital Signature Certificate (DSC)
in the form of smart card/e- token. The DSC can be obtained from any authorised certifying
agencies. The bidder should register in the web sitewww.jktenders.gov.in using the relevant option
available.
Then the Digital Signature registration has to be done with the e-token, after logging into the
site. After this, the bidder can
login the site through the secured log in by entering the
password of the e-token and the user id/ password chosen during registration. After getting the
bid schedules, the Bidder should go through them carefully and then submit the documents as
asked, otherwise, the bid will be rejected.
18.2 The completed bid comprising of documents indicated in ITB clause 12, should be
Uploaded on the website given above through e-tendering along with scanned copies of requisite
certificates as
are mentioned in different sections in the bidding document and scanned copies of
the Bid Document, Demand Draft and Bid Security in approved form.
18.3 The bidder shall furnish information as described in the Form of Bid on Commissions or gratuities, if
any, paid or to be paid to agents relating to the Bid, and to contract execution if the bidder is awarded
the contract.
19. Electronic Submission of Bids:
19.1 The bidder shall submit online two separate files. Part I, marked as Part I: Technical Qualification
Part and Part II; marked as Part II: Technical- Financial Part. The above files will have markings as
given in the Bid Data Sheet. The contents of the Technical Qualification and Technical Financial bid shall
be as specified in clause 12 of the ITB. All the documents are required to be signed digitally by the
bidder. After electronic on line bid submission, the system generates a unique bid identification number
which is time stamped. This shall be treated as acknowledgement of bid submission.
20. Deadline for Submission of Bids
20.1 Complete Bids in two parts as per clause 19 above must be submitted by the Bidder
online not later than the date and time indicated in the Appendix to ITB.
20.2 The Employer may extend the deadline for submission of bids by issuing an
amendment in accordance with Clause 10.3 of ITB. In such case all rights and obligations of the
Employer and the bidders previously subject to the original deadline will then be subject to the new
deadline.

<!-- page 20 -->

21. Modification/ Withdrawal/Late Bids
21.1 The electronic bidding system would not allow any late submission of bids after due
date and time as per server time.
21.2 Bidders may modify their bids by uploading their request for modification before
the deadline for submission of bids. For this, the bidder need not make any additional payment
towards the cost of tender document. For bid modification and consequential re-submission, the
bidder is not required
to withdraw his bid submitted earlier. The last modified bid submitted
by the bidder within the bid submission time shall be considered as the bid. For this purpose,
modification/withdrawal by other means will not be accepted. In online system of bid submission,
the modification and consequential-submission of bids is allowed any number of times. The bidders
may withdraw his bid by uploading their request before the deadline for submission of bids;
however, if the bid is withdrawn, the re-submission of the bid is not allowed.
21.3 No bid shall be modified or withdrawn after the deadline of submission of bids.
21.4 Withdrawal or modification of a bid between the deadline for submission of bids
and the expiration of the original period of bid validity specified in clause 15.1 above or as extended
pursuant to Clause 15.2 may result in the forfeiture of the Bid Security pursuant to Clause 16.
22. Bid Opening and Evaluation
22.1 The Employer inviting the bids or its authorised representative will open the bids online and this
could be viewed by the bidders also online. In the event of the specified date for the Opening of bids
being declared a holiday for the Employer, the Bids will be opened at the appointed time and location on
the next working day.
22.2 The file containing the Part-I of the bid will be opened first.
22.3 In all cases, the amount of Bid Security, cost of bid documents, and the validity of the bid shall be
scrutinized. Thereafter, the bidders’ names and such other details as the Employer may consider
appropriate, will be notified as Part-I bid opening summary by the Authority inviting bids at the
online opening. A separate electronic summary of the opening is generated and kept on-line.
22.4 The Employer will also prepare minutes of the Bid opening, including the information disclosed in
accordance with Clause 22.3 of ITB and upload the same for viewing online.
22.5 Evaluation of Part-I of bids with respect to Bid Security, qualification information and other
information furnished in Part I of the bid in pursuant to Clause 12.1 of ITB, shall be taken up and
completed within five working days of the date of bid opening, and a list will be drawn up of the
qualified bidders whose Part- II of bids are eligible for opening.
22.6 The result of Technical evaluation shall be made public on jktenders.gov.in site following which
there will be a period of two working days during which any bidder may submit objections if any in
writing to the tender receiving authority which shall be considered for resolution before financial
bid opening.
22.7 The Employer shall inform the bidders, who have qualified technical evaluation, of the date, time of
online opening of financial bids. If the specified date of opening of financial bid is changed, in the
event of the specified date being declared a holiday for the
Employer, the bids will be opened at
the appointed time and location on the next working day.
22.8 Financial bids of only those bidders will be opened online, who have qualified in
Technical
Evaluation. The bidders’ names, the Bid prices, the total amount of each bid, and such other details
as the Employer may consider appropriate will be notified online by the Employer at the time of bid
opening.

<!-- page 21 -->

22.9 The Employer shall prepare the minutes of the online opening of Financial Bids and upload the same
for viewing online.
23.

Process to be confidential

23.1

Information relating to the examination, clarification, evaluation and comparison of Bids and
recommendations for the award of a contract shall not be disclosed to Bidders or any other
persons not officially concerned with such process until the award to the successful Bidder has
been announced. Any effort by a bidder to influence the Employer’s processing of bids or award
decision may result in the rejection of his bid.
24.
Clarification of Bids and contacting the Employer:No Bidder shall contact the Employer on any matter relating to its bid from the time of the bid
opening to the time the contract is awarded. If the bidder wishes to bring additional information to
the notice of the Employer, it should do so in writing.

24.1

Any attempt by the bidder to influence the Employer’s bid evaluation, bid Comparisonor contract
award decision may result in the rejection of his bid.

25

Examination of Bids and Determination of Responsiveness

25.1

During the detailed evaluation of “Technical Bids” the Employer will determine whether each Bid
(a) meets the eligibility criteria defined in Clause 3 and 4, (b) has been properly signed; (c) is
accompanied by the required securities and; (d) is substantially responsive to the requirements of
the Bidding documents. During the detailed evaluation of the ‘Financial Bid’ the responsiveness of
the Bids will be further determined with respect to the remaining bid conditions i.e. priced Bill of
Quantities, technical specifications and drawings.

25.2

A substantially responsive “Financial Bid” is one, which conforms to all the terms, conditions and
specifications of the Bidding documents, without material deviation or reservation. A material
deviation or reservation is one (i) which affects in any substantial way the scope, quality or
performance of the works: (ii) which limits in any substantial way inconsistent with the bidding
documents the Employer’s rights or the bidders obligations under the contract, or (iii) whose
rectification would affect unfairly the competitive position of other bidders presenting
substantially responsive bids.

25.3

If a “Financial Bid” is not substantially responsive it will be rejected by the Employer and may not
subsequently be made responsive by correction or withdrawal of the non-conforming deviation or
reservation.

26

Evaluation and Comparison of Financial Bids

26.1

The Employer will evaluate and compare only the bids determined to be substantially responsive in
accordance with Sub-Clause 25.2.

26.2

In evaluating the bids, the Employer will determine for each bid the Evaluated Bid price adjusting
the Bid price through making an appropriate adjustment for any other acceptable variation,
deviations, and price modifications offered in accordance with sub-clause 21 of ITB.

<!-- page 22 -->

26.3

The Employer reserves the right to accept or reject any variation or deviation. Variations and
deviations, and other factors which are in excess of the requirements of the bidding documents
or otherwise result in unsolicited benefits for the Employer shall not be taken into account in Bid
evaluation.

26.4

If the Bid of the successful Bidder is seriously unbalanced in relation to the Engineer’s estimate
of the cost of the Works to be performed under the Contract( i. e, 15% below than Advertised
cost), the Employer/Contract awarding authority may require the bidder to produce detailed
price analyses for any or all items of the Bill of Quantities, to demonstrate the internal
consistency of those prices with the construction methods and schedule proposed. After
evaluation of the price analyses, the Employer may require that the amount of the performance
security set forth in clause 30 of ITB be increased at the expense of the successful bidder to
a level sufficient to protect the Employer against financial loss in the event of default of the
successful bidder under the Contract.

26.5

A Bid which contains several items in the Bill of Quantities which are unrealistically priced low
and which cannot be substantiated satisfactorily by the bidder may be rejected as nonresponsive.

F. AWARD OF CONTRACT
27
27.1

Award Criteria
Subject to Clause 28, the Employer will award the Contract to the Bidder whose Bid has been
determined.
(i)
To be substantially responsive to the Bidding documents and who has offered the lowest
Evaluated Bid Price, provided that such bidder has been determined to be (a) eligible in
Accordance with the provisions of clause 3 of ITB and (b) qualified in accordance with the
Provisions of clause 4 of ITB; and
(ii)
To be within the available Bid Capacity adjusted to account for his bid price which is
evaluated the lowest in any of the packages opened earlier than the one under
consideration.

<!-- page 23 -->

28

Employer’s right to accept any Bid and Reject any or all Bids

28.1

Not withstanding Clause 27 the Employer reserves the right to accept or reject any bid and
to cancel the bidding process and reject all bids, at any time prior to award of Contract,
without thereby incurring any liability to the affected bidder or bidders or any obligations
to inform the affected bidder or bidders of the grounds for the Employer’s action.

29

Notification of Award and signing of Agreement

29.1 The Bidder whose Bid has been accepted will be notified of the award by the Employer prior to
expiration of bid validity period by cable, telex or facsimile confirmed by registered letter. This letter
(hereinafter and in the Conditions of Contract called “the Letter of Acceptance”) will state the sum that
the Employer will pay the contractor in consideration of the execution, completion and maintenance of
the Works by the Contractor as prescribed by the Contract. (herein after and in the Contract called
“the Contract Price”).
29.2

The notification of award will constitute the formation of the Contract subject only to the
furnishing of a performance security in accordance with provision of clause 30 of ITB.

29.3

The Agreement will incorporate all agreements between the Employer and the successful Bidder. It
will be signed by the Employer and the successful Bidder after the Performance Security is furnished .

29.4

Upon the furnishing by the successful bidder the performance security, the Employer will
promptly notify the other bidders that their bids have been unsuccessful.

30

Performance Security

30.1

Within 21 (twenty one) days after the date of receipt of the Letter of Acceptance, the
successful bidder/contractor shall deliver to the Employer/concerned authority, a Performance
Security in any of the required forms for an amount equivalent to 3% of contract price plus
additional security for unbalanced bid(if required ) in accordance with clause 26.4 of ITB

30.2

If the Performance Security is provided by the successful bidder in the form of a bank
guarantee, it shall be issued by either (a) at the Bidder’s option, by a Nationalized / Scheduled
Indian Bank or (b) by a foreign bank located in India and acceptable to the Employer.

30.3

Failure of the successful bidder to comply with the requirements of Sub-Clause 30.1 of ITB
shall constitute sufficient grounds for cancellation of the award and forfeiture of the Bid
Security.

31

No Advance Payment whatsoever shall be made by the department to the
Contractor.

<!-- page 24 -->

32

Dispute Review Expert:

The Employer proposes that (Name of the proposed Dispute Review Expert as indicated in the
Appendix to ITB)to be appointed as Dispute Review Expert under the contract at a daily fee as indicated
in Appendix plus reimbursable expenses .If the bidder disagrees with this proposal, the bidder should so
state in the bid. If ,in the letter of Acceptance ,the Employer has not agreed on the appointment of the
Dispute Review Expert, the Dispute Review Expert shall be appointed by the Council of Indian Road
Congress at the request of either party.
33

Corrupt or Fraudulent Practices

33.1

The Employer will reject a proposal for award if it determines that the Bidder recommended for
award has engaged in corrupt or fraudulent practices in competing for the contract in question
and will declare the firm ineligible, either indefinitely or for a stated period of time, to be
awarded a contract with National Highways Authority of India / State PWD and any other
agencies, if it at any time determines that the firm has engaged in corrupt or fraudulent
practices in competing for the contractor, or in execution.

33.2

Further more, Bidders shall be aware of the provisions stated in Clause 53.2 of the Conditions
of Contract.

APPENDIX TO ITB
Clause Reference With respect to Section –I.
1. Name of Employer: Chief Executive Officer, Bhadarwah Dev. Authority.
2. The last five years

(Particular years to be mentioned)

[C1.4.6]

3. The average annual financial turn of any three years out of last five years is 50%of Adv. Cost
5.
6.

supported with TDS & Income Tax Return[C1 4.6A(i)]

Liquid assets and/or availability of credit facilities is10% of Adv. Cost [C1.4.3(i) of ITB]
Price level of the financial year
[C1.4.6 &4.8]

<!-- page 25 -->

7.

The technical bid will be opened in the office of Superintending Engineer PWD (R&B) Circle
Doda
8. The CDR//FDR in favour of Chief Executive Officer, Bhadarwah Dev. Authority
Payable at Bhadarwah C1.30 OF ITB]
9. Dispute Review Expert;_____________
Clause 32 OF ITB and 23 of GCC
10 (a): Performance Security shall be valid until a date 28 days after the expiry of Defect
Liability Period of 01 year after intended date of completion.
11 (b) Additional performance security for unbalanced bid shall be (as decided by the employer) of
contract value valid for 45 days plus intended date of completion.
12.

Base year :( particular year to be mentioned)
No escalation factor is allowed for similar nature of work.
S.No
1
2
3
4
5

Year before
one
two
three
four
five

Multiplying factor
1.08
1.17
1.26
1.36
1.47

Escalation factors are for working out available bid capacity only (for the cost of works executed
and financial figures arrived thereof to a common base value for works completed in India).

<!-- page 26 -->

QUALIFICATION INFORMATION

Section-2
QUALIFICATION INFORMATION
Notes on Form of Qualification Information
The information to be filled in by the bidders in the following pages will be used to
purposes of post- qualification as provided for in clause 4 of the instructions to
Bidders. This information will not be incorporated in the contract. Attach additional
pages as necessary.

<!-- page 27 -->

1.
1.1

For Individual Bidders
constitution or legal status of Bidder

(attach copy)

Place of registration
Principal place of business
Power of attorney of signatory of Bid
1.2

1.3.

Financial Turn over achieved
on
execution of civil works for the last
five years duly certified by Chartered
Accountant and supported with TDS,
ITR, Profit and Loss statement and
Balance sheet.**

(Rs. in lakhs)
Year 2017-18
Year 2018-19
Year 2019-20
Year 2020-21
Year 2021-22

Work performed as prime contractor (in the same name & style) on construction works of similar
nature over the last five years. Attach certificate issued by an officer not below the rank of
Executive Engineer or equivalent.

Project
Name

Name of
the
employer
*

Description
of work

1.4

Work performed as sub-contractor (in the same name & style duly supported
with an authority letter regarding approval of sub-contract by the competent
authority) on construction works of similar nature over the last five years.
Attach certificate issued by an officer not below the rank of Executive
Engineer or equivalent.

Project
Name

Name of
the
employer
*

Description
of work

Contract
No

Contract
No

Value of
contract (Rs
in crore)

Value of
contract (Rs
in crore)

Date of
issue of
work
Order

Date of
issue of
work
Order

Stipulated
Period
completion

Stipulated
Period
completion

of

of

Actual date
of
completion
*

Actual date
of
completion
*

Remarks
explaining
reasons for delay &
work completed

Remarks
explaining
reasons for delay &
work completed

**** A certificate of performance evaluation of all such works/commitments in hand on the part of the
bidder issued by the concerned Chief Engineer/Superintending Engineer/Executive Engineer to the

<!-- page 28 -->

affirmation that the contractual obligations are being performed satisfactorily without compromise on
quality parameters and time lines.
1.5
(a) Achieved a minimum average financial turnover on execution of Civil Engineering works (
defined as billing for works in progress or completed in all classes of Civil Engineering
construction works only) during any three out of the last five financial years ( 2017-18 to
2021-22) not less than 50% of the proposed contract /contracts applied. The information
supplied in this connection should be duly certified by a Chartered Accountant and be duly
supported by TDS and Income Tax Returns for the last five years.

.

(b)

Having satisfactorily completed or substantially completed at least one contract of similar
nature of work of any Govt./Semi Govt. department during the last five years (road and
/or bridge works of at least 25% of the value of proposed contract during the last five
years.(Certificate to this effect to be issued by an officer not below the rank of Executive
Engineer or equivalent.). No escalation factor is allowed for similar nature of work.

The work may have been executed by the Applicant as prime contractor or as a member of joint
venture In case a project has been executed by a joint venture, weightage towards experience of
the project would be given to each joint venture in proportion to their participation in the joint
venture.
Substantially completed works means those works which are at least 90%completed as on the
date of submission (i.e. gross value of work done up to the last date of submission is 90% or more
of the original contract price) and continuing satisfactorily.
For these a certificate from employer shall be submitted along with the application incorporating
clearly the name of the work, contract value, billing amount, date of commencement of works,
satisfactory performance of the contractor and any other relevant information.
1.6 Information on Bid capacity (works for which bids have been submitted and Works which are yet to
be completed) as on the date of this bid.
Existing commitments and ongoing construction works:Description
of work

1

Place &
State

2

Contract No.
& date

Name &
address of
Employer

Value of
contract (Rs
in lakhs)

3

4

5

Stipulated
Period
completion

6

of

Value
of
works
remaining to
be
completed
(Rs. in lakhs)

Anticipated date of
completion

7

8

Enclose certificate(s) issued by an officer not below the rank of Executive Engineer or equivalent
1.7 Availability of Major items of Contractor’s equipment proposed for carrying out
the Works. List all information requested below. Refer also to Clause 4.3(f) and
4.6(B) a of the Instructions to Bidders.
Item of
Description,
Condition (new,
Owned, leased
Equipment
make, and age
good, poor) and
(from whom?) or to
(years), and
number available
be purchased.

<!-- page 29 -->

capacity

1.8

1.9

1.10

Financial reports for the last five years: balance sheets, profit and loss statements, auditors
reports, etc. List below and attach copies.
_________________________________________________________________________
_________________________________________________________________________
________________________________________________
Name, address, and telephone, telex, and facsimile numbers of banks that may provide references
if contacted by the Employer.
_________________________________________________________________________
_________________________________________________________________________
_________________________________
Information on current litigation in which the Bidder is involved.
Name
of
party(s)

other Cause of dispute

Litigation
where Amount involved (Rs.
(Court/arbitration)
In lakh)

1.11

Proposed work method and schedule. The Bidder should attach descriptions,
Drawings and charts as necessary to comply with the requirements of the Bidding documents. [
Refer ITB Clause 12

1.12

Applicants who meet the minimum qualification criteria will be qualified only if
there available bid capacity at the expected time of bidding is more than the total estimate cost
of the works. The available bid capacity will be calculated as under:-

Available Bid capacity = (AxNxM-B)
A=

N=
B=

M=

Maximum value of civil engineering works executed in any one year during the last five years (
updated to the current price level of the year indicated in appendix ) taking into account the
completed into as well as works in the progress;
Number of years prescribed for completion of the works for which bids are invited = ______
Value (updated to the current price level of the year indicated in appendix ) of existing
commencements and ongoing works to be completed during the next 03 years (period of
completion of the works for which bids are invited)

This factor shall have a value

of 2.5

Information on Bid Capacity (works for which bids have been submitted and works which are yet
to be completed) as on the date of this bid.
The item of work for which data is requested should tally with that specified in ITB clause 4.6

1.13

Qualification and experience of technical/key personnel required for administration and
execution of the Contract [ Ref. Clause 4.6 (B) (b)]. Attach biographical data. Refer also to
sub Clause 4.3 (h) of instructions to Bidders and Sub Clause 8.1 of the Conditions of Contract.

<!-- page 30 -->

Position

Name

Qualification

Year of Experience
(General )

Years of experience
in similar nature of
work

Attach copies of certificates on possession of valid license for executing water supply/ sanitary work/
building electrification works [ Reference Clause 4.3 ]
1.14

Evidence of access to financial resources to meet the qualification requirements:
cash in hand, lines of credit, etc. List them below and attach copies of supports
documents.

1.15

Quality Assurance Programme.(to be framed in accordance with the requirements /guide
lines/manual uploaded on departmental website.

2.Additional Requirements
2.1
Bidders should provide any additional information required to fulfil the requirements of Clause 4
of the Instructions to the Bidders, if applicable.
(i)
Affidavit on correctness of information.
(ii)
Undertakings
___________________________________________________________________________
2.2. Qualification Criteria:2.2. Qualification will be based on applicants meeting all the following minimum pass/fail criteria
regarding the applicants general and particular experience, personal and equipment capabilities, and
financial position, as demonstrated by the applicants responses in the forms attached to the letter
of applications (specified requirements for joint ventures are given below). Subcontractors
experience and resources shall not be taken into account in determining the applicant’s compliance
with the qualifying criteria.
To qualify for more than one contract, the applicant must demonstrate having experience and
resources sufficient to meet the aggregate of the qualification criteria for each contract given in
paragraphs 2.5, 2.6, 2.7 & 2.8 below.
2.3.Base year and escalation = (particular base year to be mentioned)

<!-- page 31 -->

Following escalation factors will be used for working out the available bid capacity only for the
cost of works executed and financial figures arrived thereof to a common base value for works
completed in India.
No escalation factor is allowed for similar nature of work.

Year before
One
Two
Three
Four
Five

Multiply factor
1.08
1.17
1.26
1.36
1.47

Applicant should indicate actual figures of costs and amount for the works executed by
them without accounting for the above mentioned factors.
In case the financial figures and value of completed works are in foreign currency, the above
enhanced multiplying factors will not be applied,. Instead, current market exchange rate (State
Bank of India BC selling rate as on the last date of submission of the bid) will be applied for the
purpose of conservation of amount in foreign currency into Indian rupees .
2.4
The applicant should have:(a ) Achieved a minimum average financial turnover on execution of Civil Engineering works (
defined as billing for works in progress or completed in all classes of Civil Engineering
construction works only) during any three out of the last five financial years (2014-15 to
2018-19) not less than 50% of the proposed contract /contracts applied. The information
supplied in this connection should be duly certified by a Chartered Accountant and be duly
supported by TDS and Income Tax Returns for the last five years.
(b)

Having satisfactorily completed or substantially completed at least one contract of similar
nature of work of any Govt./Semi Govt. department during the last five years (road and
/or road work at least 25% of the value of proposed contract during
the last five
years.(Certificate to this effect to be issued by an officer not below the rank of Executive
Engineer or equivalent.). No escalation factor is allowed for similar nature of work.
The work may have been executed by the Applicant as prime contractor or as a member of joint
venture or subcontractor. As a subcontractor, he should have acquired the experience of
execution of all major items of works under the proposed contract In case a project has been
executed by a joint venture, weightage towards experience of the project would be given to each
joint venture in proportion to their participation in the joint venture.
Substantially completed works means those works which are at least 90%completed as on the
date of submission (i.e. gross value of work done up to the last date of submission is 90% or more
of the original contract price) and continuing satisfactorily.
For these a certificate from employer shall be submitted along with the application incorporating
clearly the name of the work, contract value, billing amount, date of commencement of works,
satisfactory performance of the contractor and any other relevant information.

2.5. LIST OF KEY PERSONNEL TO BE DEPLOYED ON CONTRACT WORK
The applicant must have suitably qualified personnel to fill the following positions. The applicant
will supply information on a prime candidate and an alternate for each position, both of whom
should meet the experience requirements specified below:

<!-- page 32 -->

B.E Civil +10Years Exp
Or Diploma in Civil with 15
years experience
B.E Civil +3Years Exp
Or
Diploma with 7 years
experience
B.E Mech. + 3 Years Exp.
Or
Dip. Mech.+ 7 Years Exp.

1

15 crores above Up
to Rs.30.00 Crore.
1 No

1

2 No

1

1 No

Quantity Surveyor

B.E Civil. + 7 Years Exp.
Or
Dip. Civil.+ 10Years Exp.

1

1 No

5

Soil & Material
Engineer

B.E Civil. + 7 Years Exp.
Or
Dip. Civil.+ 10Years Exp.

1

1 No

6

Survey Engineer

B.E Civil+5 years Exp.
Or
Dip. Civil + 8 years Exp.

1

1 No

S.NO

PERSONAL

1

Project Manager

2

Site Engineer

3

Plant Engineer

4

QUALIFICATION

Up to 15 crores

The applicant should own or should have assured ownership to the following key items of
equipment, in full working order, and must demonstrate that, based on known commitments; they will be
available for use in the proposed contract.
LIST OF KEY PLANT & EQUIPMENT TO BE DEPLOYED ON CONTRACTWORK
S.no Type of Equipment
Maximum Age
Work valuing
Above 15
As on 01-10up to 15 crores
crores
2017
UptoRs.30.00
Crore.
1
Tipper Trucks
5-7
3
5
2
Motor Grader
5
1
1
3
Dozer
5
1
1
4
Front end Loader
5
1
1
5
Smooth Wheeled Roller
5
1
2
6
Vibratory Roller
5
1
1
7
Hot Mix Plant with Electronic Controls
5
1
(Minimum 4060 TPH Capacity)
8
Paver Finisher with Electronic Sensor
5
1
1
9
Water Tanker
5
1
1
10
Bitumen Sprayer
5-7
1
1
11
Cold Milling Machine
5
1
1
12

Tandem Roller

5

1

1

<!-- page 33 -->

Note: The tender inviting authority if necessary, shall make additions/alterations in respect of
Machinery/ Equipments and technical personnel depending upon the magnitude and nature of
work.
2.7. Financial Position:The applicant should demonstrate that he has excess to, or has available, liquid assets (aggregate
Of working capital, cash in hand and uncommitted Bank Guarantee’s) and / or credit facilities of not
less than 10% of the value of the contract/ contracts applied for (construction cash-flow may be
taken as 10% of the estimated value of contract / contracts).
2.8. The audited balance sheets for the last five years should be submitted, which must demonstrate the
soundness of the applicant’s financial position, showing long term profitability including and
estimated financial projection for the next two years. If necessary, the employer will make inquires
with the applicant’s bankers.
2.9. Litigation History:The Applicant should provide accurate information on any litigation or arbitration resulting from
contracts completed or under execution by him over the last five years. A consistent of awards against
the applicant or any partner of a joint venture may result in failure of the applicant.

2.10.Bid Capacity:-Applicants who meet the minimum qualification criteria will be qualified only if
there available bid capacity at the expected time of bidding is more than the total estimate cost of the
works. The available bid capacity will be calculated as under:-

Available Bid capacity = (AxNxM-B)
A=

Maximum value of civil engineering works executed in any one year during the last five years (
updated to the current price level of the year indicated in appendix ) taking into account the
completed into as well as works in the progress;
N=
Number of years prescribed for completion of the works for which bids are invited = ..........
B=
Value (updated to the current price level of the year indicated in appendix ) of existing
commencements and on-going works to be completed during the next 03 years (period of
completion of the works for which bids are invited)
M= 2.5
Note: The statements showing the value of existing commitments and on-going works as well as the
stipulated period of completion remaining for each of the works listed should be
countersigned by the Engineer in charge, not below the rank of an Executive Engineer or
equivalent.

2.11.Joint Venture:- (Applicable for the works costing Rs.15.00 Crores and above in J&K
State).If the bidder is a Joint Venture ,the partners would be limited to three
(including lead partner).Joint Venture firm shall be jointly and severally responsible
for completion of the project.
2.12 Joint Venture must fulfil the following minimum qualification requirement:i)The lead partner shall meet not less than 50% of qualification criteria given in
sub-clause
4.6(A-i)and 4.6(A-ii)of ITB of this bidding document.
ii) Each of the remaining partners shall meet not less than 25% of all the qualification criteria
given in sub-clause 4.6(A-i)and 4.6A(ii) of I.T.B of this bidding document.
iii)

The Joint Venture must also collectively satisfy the subject of the Criteria of clause 4.6(Ai)and 4.6(A-ii)of ITB for this purpose the relevant figures for each of the partners shall be
added together to arrive at the Joint Venture total

<!-- page 34 -->

capacity which shall be 100% or more.
iv) In the event that the Employer has caused to disqualify under clause 4.7 of ITB all of the
Joint Venture partners will be disqualified.
v) Joint Venture applicants shall provide a certified copy of the Joint Venture agreement in
demonstration of the partners undertaking joint and several liabilities for the performance of
any contract entered into before award of work.
vi)The available bid capacity of the J.V as required under clause 4.6 of ITB will be applied for
the each partner to the extent of his proposed participation in the execution of the work .The
total Bid Capacity available shall be more than estimated contract value.

Provisions Required to be Included in the Joint Venture Agreement
If the application is made by a Joint Venture of two or more firms ,the evidence of clear
mandate ( i ,e in the form of respective Board Resolution duly authenticated by competent
authority)by such two or more firms willing to form Joint Venture among themselves for
the specified projects should accompany duly recognising their respective authorised
signatories signing for and on behalf of respective firms for the purpose of forming the
Joint Venture .A certified copy of the power of attorney to the authorised
representatives, signed by legally authorised signatories of all the firms of the Joint
Venture shall accompany the application. The JV Agreement shall need to be submitted
consisting but not limited to the following provisions.
a) Name, Style and Project(s) specified JV with Head Office address
b) Extent (or Equity) for participation of each party in the JV
c) Commitment of each party to furnish the Bond money (i, e Bid security , performance
security) to the extent of his participation in the JV.
d) Responsibility of each Partner of JV (in terms of Physical and Financial involvement)
e) Working Capital arrangement.
f) Operation of separate Bank Account in the name of JV to be operated by both the
partners.
g) Provision for cure in case non-performance of responsibility by any party of the J.V
h) Provision that NEITHER party of the JV shall be allowed to sign, pledge
,sell or
otherwise dispose of all or part of its respective interests in JV to any party including
existing partner(s) of the JV .The Employer derives right for any consequent action
(including blacklisting )against any or all JV partners in case of any breach in this regard
.
i) Management Structure of JV with details.
j) Lead Partner to be identified who shall be empowered by the JV to incur liabilities on
behalf of JV.
k) Parties/firms committing themselves to the Employer for jointly and severally
responsible for the intended works.
l) The Power Of Attorney shall be duly notarized.
m) Any other relevant details.

<!-- page 35 -->

GENERAL CONDITIONS OF CONTRACT
Section-3

<!-- page 36 -->

GENERAL CONDITIONS OF CONTRACT
A. GENERAL
1.
Definitions
1.1
Terms which are defined in the Contract Data are not also defined in the Conditions of Contract
but keep their defined meanings. Capital initials are used to identify defined terms. The
Adjudicator (synonymous with Dispute Review Expert) is the person appointed jointly by the
employer and the Contractor to resolve disputes in the first instance, as provided for in Clauses
24 and 25. The name of the adjudicator is defined in the contract Data.
Bill of Quantities means the priced and completed Bill of Quantities forming part of the Bid.
The Completion Date is the date of completion of the Works as Certified by the Engineer in
accordance with the clause 49.
The Contract is the contract between the Employer and the Contractor to execute, complete and
maintain the Works. It consists of the documents listed in Clause 2.3below.
The Contract Data defines the documents and other information which comprise the Contract.
The Contractor is a person or corporation body whose Bid to carry out the works has been
accepted by the Employer.
The Contractor’s Bid is the completed Bidding document submitted by the contractor to the
Employer and includes Technical & Financial -Bids.
The Contract Price is the price stated in the Letter of Acceptance and thereafter as adjusted in
accordance with the provision of the Contract.
Days are calendar days; months are calendar months. A Defect is any part of the works not
completed in accordance with the Contract.
The Defects Liability Period is the period named in the Contract Data and calculated from the
Completion Date.
The Employer is the party who will employ the Contractor to carry out the Works.
The Engineer is the person named in the Contract Data (or any other competent person appointed
and notified to the contractor to act in replacement of the Engineer) who is responsible for
supervising the Contractor, administering the Contract, certifying payments due to the
Contractor, issuing and valuing Variations to the Contract, awarding extension of time, and valuing
the Compensation events.
Equipment is the Contractor’s machinery and vehicles brought temporarily to the Site to
construction the works.
The Initial Contract Price is the Contract Price Listed in the Employer’s Letter of Acceptance.
The Intended Completion Date is the date on which it is intended that the Contractor shall
complete the works. The Intended Completion Date is specified in the Contract Data. The
Intended Completion Date may be revised only by the engineer by issuing an extension of time.
Materials are all supplies, including consumables, used by the contractor for incorporation in the
Works.
Plant is any integral part of the Works, which is to have a mechanical, electrical, electronic, or
chemical or biological function.
The Site is the area defined as such in the contract Data.
Site Investigation Reports are those which were included in the Bidding documents and are
factual interpretative reports about the surface and sub-surface conditions at the site.
Specification means the Specification of the works included in the contract and any modification
or addition made or approved by the Engineer.

<!-- page 37 -->

The Start Date is given in the Contract Data. It is the data when the Contractor shall commence
execution of the works. It does not necessarily coincide with any of the Site possession dates.
A Subcontractor is a person or corporate body who has a contract with the contractor to carry
out a part of the work in the contract, which includes works on the Site.
Temporary Works are works designed, constructed, installed, and removed by the Contractor
which are needed for construction or installation of the works.
The Works are what the Contract requires the contractor to construct, install, and turnover to
the Employer, as defined in the contract Data.
2. Interpretation
2.1. In interpreting these conditions of Contract, singular also means plural, male
also means female or neuter, and the other way around. Heading have no significance. Words
have their normal meaning under the language of the Contract unless specifically defined. The
Engineer will provide instructions clarifying queries about the Conditions of contract.
2.2. If sectional completion is specified in the contract Data, references in the
conditions of contract to the works, the completion Date, and the Intended Completion Date
apply to any Section of the works (other than references to the completion date and
Intended Completion date for the whole of the works).
2.3.The documents forming the Contract shall be interpreted in the following
order of priority:
(a) Agreement
(b) Letter of Acceptance, notice to proceed with the works
(c) Contractor’s Bid
(d) Contract Data
(e) Conditions of Contract including Special Conditions of Contract
(f) Specifications
(g) Drawings
(h) Bill of quantities and
(i) Any other document listed in the Contract Data as forming part of the
Contract.

3.1
4.
4.1
5.
5.1

3. Language and Law
The language of the Contract and the law governing the Contract are stated in the contract Data.
Engineer’s Decisions
Except where otherwise specifically stated, the Engineer will decide contractual matters between
the Employer and the Contractor in the role representing the Employer.
Delegation
The engineer may delegate any of his duties and responsibilities to other people except to
the Dispute Review Expert after notifying the Contractor and may cancel
any delegation after notifying the Contractor.

6.

Communications

6.1

Communications between parties, which are referred to in the conditions, are effective only when
in writing. A notice shall be effective only when it is delivered (in terms of Indian Contract Act

<!-- page 38 -->

7.

Other Contractors
The Contractor shall cooperate and share the Site with other contractors, public authorities,
utilities, and the Employer between the dates given in the Schedule of other Contractors. The
Contractor shall as referred to in the Contract Date, also provide facilities, and services for
them as described in the Schedule. The employer may modify the schedule of other contractors
and shall notify the contractor of any such modification.

8

Personnel

8.1

The Contractor shall employ the key personnel named in the Schedule of Key Personnel as
referred to in the Contract Data to carry out the function stated in the Schedule or other
personnel approved by the Engineer. The Engineer will approve any proposed replacement of key
personnel only if their qualifications, abilities, and relevant experiences are substantially equal to
or better than those of the personnel listed in the Schedule.

8.2

If the Engineer asks the Contractor to remove a person who is a member of the Contractor’s
staff or his work force stating the reasons the contractor shall ensure that the person leaves the
Site within seven days and has no further connection with the working the Contract.

9.

Employer’s and Contractor’s Risks

9.1

The Employer carries the risks which this Contract states are Employer’s risks, and the
Contractor carries the risks which this contract states are Contractor’s risks.

10.

Employer’s Risks

10.1

The Employer is responsible for the excepted risks which are (a) in so far as they directly affect
the execution of the works in the Employer’s country, the risks of war, hostilities, invasion, act of
foreign enemies, rebellion, revolution, insurrection or military or usurped power, civil war, riot
commotion or disorder (unless restricted to the Contractor’s employee’s), and contamination from
any nuclear fuel or nuclear waste or radioactive toxic explosive, or (b)
a cause due solely to the design of the works, other than the Contractor’s design.

11.

Contractor’s Risks

11.1

All risks of loss of or damage to physical property and of personal injury and death which arise
during and in consequence of the performance of the contract other than the excepted risks are
the responsibility of the Contractor.

12.
12.1.

Insurance
The Contractor shall provide, in the joint names of the Employer and the Contractor, insurance
cover from the start date to the end of the Defects Liability Period, in the amounts and
deductibles stated in the contract Data for the following events which are due to the
Contractor’s risks:
a) loss of or damage to the works, Plant and Materials;

<!-- page 39 -->

b) loss of or damage to Equipment;
c) loss of or damage of property (except the works, Plant, Materials and
Equipment) in connection with the Contract; and
d) Personal injury or death.
12.2 Policy and certificates for insurance shall be delivered by the Contractor to the engineer for the
Engineer’s approval before the Start Date. All such insurance shall provided for compensation to
be payable in the types and proportions of currencies required to rectify the loss or damage
incurred.
12.3. If the Contractor does not provide any of the policies and certificates required, the Employer
may affect the insurance which the contractor should have provided and recover the premiums
the Employer has paid from payments otherwise due to the Contractor or, if no payment is due,
the payment of the premiums shall be a debt due.
12.4. Alterations to the terms of insurance shall not be made without the approval of
the Engineer.
12.5. Both parties shall comply with any conditions of the insurance policies.
13.
13.1

Site Investigation Reports
The Contractor, in preparing the Bid, shall rely on any site Investigation Reports referred to in
the Contract Data, supplemented by any information available to the Bidder.

14.

Queries about the Contract Data

14.1

The Engineer will clarify queries on the Contract Data.

15.
15.1

Contractor to Construct the Works
The Contractor shall construct and install the works in accordance with the Specifications and
Drawings.

16.
16.1

The Works to be completed by the Intended Completion Date
The Contractor may commence execution of the Works on the Start Date and shall carryout the
Works in accordance with the programme submitted by the Contractor, as updated with the
approval of the Engineer, and complete them by the Intended Completion Date.

17.
17.1

Approval by the Engineer
The Contractor shall submit specifications and Drawings showing the proposed Temporary Works
to the Engineer, who is to approve them if they comply with the Specifications and Drawings.

17.2

The Contractor shall be responsible for design of Temporary Works.

17.3

The Engineer’s approval shall not alter the Contractor’s responsibility for design of the
Temporary Works.

17.4

The contractor shall obtain approval of third parties to the design of the Temporary Works
Where required.
All Drawings prepared by the Contractor for the execution of the temporary works, are subject
to prior approval by the Engineer before their use.

17.5

<!-- page 40 -->

18.
18.1

Safety
The Contractor shall be responsible for the safety of all activities on the Site.

19.

Discoveries

19.1

Anything of historical or other interest or of significant value unexpectedly discovered on the
Site is the property of the Employer. The contractor is to notify the Engineer of such discoveries
and carry out the Engineer’s instructions for dealing with them.

20.

Possession of the Site

20.1

The Employer shall provide adequate Site to the Contractor to start and carry out his
construction activity.

21.

Access to the Site

21.1

The Contractor shall allow the Engineer and any person authorized by the Engineer access to the
Site, to any place where work in connection with the Contract is being carried out or is intended
to be carried out and to any place where materials or plant are being manufactured / fabricated /
assembled for the works.

22.

Instructions

22.1

The Contractor shall carry out all instructions of the Engineer, which comply with the applicable
where the site is located.

22.2

The Contractor shall permit the Employer to inspect the Contractor’s accounts and records
relating to the performance of the Contractor and to have them audited by auditors appointed by
the Employer, if so required by the Employer.

23. DISPUTE S:
23.1:if the contractor believes that the decision taken by the Engineer was either outside the
authority give to the Engineer by the contract or that the decision was wrongly taken, the decision shall
be referred to the Dispute Review Expert within 14 days of the notification of Engineer’s decision.
24.Arbitration:
24.1:The Arbitration shall be conducted in accordance with the Arbitration procedure stated in the
Special Conditions of the Contract.
25. Replacement of Dispute Review Expert:
25.1: Should the Dispute Review Expert resign or die, or should the Employer and the Contractor agree
that the Dispute Review Expert is not fulfilling his functions in accordance with the provisions of the
contract; a new Dispute Review Expert will be jointly appointed by the Employer and the Contractor. In
case of disagreement between the Employer and the Contractor, within 30 days, the Dispute Review
Expert shall be designated by the appointing authority designated in the Contract Data at the request of
either party, within 14 days of receipt of such request.

<!-- page 41 -->

B- TIME CONTROL

26.

Programme

26.1

Within the time stated in the Contract Data the Contractor shall submit to the Engineer for
approval a Program showing the general methods, arrangements, order, and timing for all the
activities in the works along with monthly cash flow forecast.

26.2

An update of the Programme shall be a program showing the actual progress achieved on each
activity and the effect of the progress achieved on each activity and the effect of the progress
achieved on the timing of the remaining work including any changes to the sequence of the
activities.

26.3

The Contractor shall submit to the Engineer, for approval, an updated Program at intervals no
longer than the period stated in the Contract Data. If the Contractor does not submit an updated
Programme within this period, the Engineer may withhold the amount stated in the Contract Data
from the next payment certificate and continue to withhold this amount until the next payment
after the date on which the overdue Programme has been submitted.

26.4

The Engineer’s approval of the Programme shall not alter the Contractor’s obligations. The
Contractor may revise the Programme and submit it to the Engineer again at anytime. A revised
Programme is to show the effect of Variations and Compensation Events.

27.

Extension of the Intended Completion Date

27.1

The Engineer shall extend the Intended Completion Date if a Compensation Event occurs or a
Variation is issued which makes it impossible for Completion to be achieved by the Intended
Completion Date without the Contractor taking steps to accelerate the remaining work and which
would cause the Contractor to incur additional cost.

27.2

The Engineer shall decide whether and by how much to extend the Intended Completion Date
within 35 days of the Contractor asking the Engineer for a decision upon the effect of a
Compensation Event or Variation and submitting full supporting information. If the Contractor has
failed to give early warning of a delay or has failed to cooperate in dealing with a delay, the delay
by this failure shall not be considered in assessing the new Intended Completion Date.

27.3

The Engineer shall within 14 days of receiving full justification from the contractor for extension
of Intended completion date refer to the employer his decision. The employer shall in not more
than 21 days communicate to the Engineer the acceptance or otherwise of the engineer’s decision.

28.

Delays Ordered by the Engineer

28.1

The Engineer may instruct the Contractor to delay the start or progress of any activity within
the Works.

29

Management Meetings

<!-- page 42 -->

29.1

Either the Engineer or the Contractor may require the other to attend a management meeting.
The business of a management meeting shall be to review the plans for remaining work and to deal
with matters raised in accordance with the early warning procedure.

29.2

The Engineer shall record the business of management meetings and is to provide copies of this
record to those attending the meeting and to the Employer. The responsibility of the parties for
actions to be taken is to be decided by the Engineer either at the management meeting or after
the management meeting and stated in writing to all who attended the meeting.

30.

Early Warning

30.1

The Contractor is to warn the Engineer at the earliest opportunity of specific likely future events
or circumstances that may adversely affect the quality of the work, increases the Contract Price
or delay the execution of works. The Engineer may require the Contractor to provide an estimate
of the expected effect of the future event or circumstance on the Contract Price and Completion
Date. The estimate is to be Provide by the Contractor as soon as reasonably possible.

30.2

The Contractor shall cooperate with the Engineer in making and considering proposal for how the
effect of such an event or circumstance can be avoided or reduced by anyone involved in the work
and in carrying out any resulting instruction of the Engineer.
A.

QUALITY CONTROL

31. Quality Assurance Programme (For Works Valuing Rs.10.00
crores and Above)
The Contractor shall prepare and submit a quality control pla n/mechanism
(Quality Assurance Plan” or “QAP”) and make all necessary arrangements to ensure
its compliance. Having regard to the requirement of the project, Quality assurance
plan shall be devised by taking into consideration the quality assurance manual/
guide which is available on the web site of PW(R&B) Department of Chief Engineer(s)
Jammu/ Kashmir; this manual or guide can also be availed from the office of Chief
Engineer Jammu/ Kashmir; District Superintending Engineers and Executive
Engineers.
While submitting the bid, the bidder along with other documents shall submit Quality
Assurance Plan (QAP)as per the clause 4.1 and 4.3(p)of ITB .However a final QAP
shall be framed by the successful bidder after the allotment of work. The Engineer –in
charge shall convey its comments to the contractor within a period of 21 days of
receipt of the QAP after the allotment of work, stating the modifications, and the
contractor shall incorporate those in the QAP to the extent required for conforming
with the provisions of Quality Assurance manual/guide ,which shall be approved by
the competent authority and treated as inseparable part of agreement to be signed
between the contractor and the department.

32. Tests

<!-- page 43 -->

32.1
If the Engineer-in-Charge instructs the contractor to carry out a test not specified in the specification to check whether
any work has a defect and the test Confirms the defect, then the contractor shall have to pay for the tests and the
defective work shall have to be dismantled and reconstructed in accordance to the IRC/MOST/BIS/CPWD/NBO
Specifications as applicable.
The Engineer in-charge of site shall ensure / will certify that the lab has been established & tests performed. The
The contractor will furnish documentary proof of procurement of materials like cement, steel and other equipments and
goods to the engineer in-charge. This will include original vouchers for all quantities in lieu of purchase of materials/
equipments etc from the original manufacturer or authorized dealer/distributor to the satisfaction of engineer in-charge
for ascertaining genuineness of materials. Attested copy of such material shall be submitted along with the bills.
No extra payment on account of quality control measures shall be paid to the contractor
33. Identifying Defects
33.1 The Engineer shall check the Contractor’s work and notify the Contractor of any Defects that are
found. Such checking shall not affect the Contractor’s responsibilities. The Engineer may instruct
the Contractor to search for a Defect and to uncover and test any work at site.

34.

Correction of Defects

34.1

The Engineer shall give notice to the Contractor of any Defects before the end of the Defects
Liability Period, which begins at Completion and is defined in the Contract Data. The Defects
Liability Period shall be extended for as long as Defects remain to be corrected.

34.2

Every time notice of a Defect is given, the Contractor shall correct the notified Defect within
the length of time specified by the Engineer’s notice.

35.

Uncorrected Defects

35.1

If the Contractor has not corrected a Defect within the time specified in the Engineer’s notice,
the Engineer will assess the cost of having the Defect corrected, and the Contractor will pay this
amount.

D. COST CONTROL
36.

Bill of Quantities

36.1

The Bill of Quantities shall contain items for the Construction, Installation, testing, and
commissioning work to be done by the Contractor.

36.2

The Bill of Quantities is used to calculate the Contract Price. The Contractor is paid for the
quantity of the work done at the rate in the Bill of Quantities for each item.

36.3. Cash Flow forecasts
36.4 When the Programme is updated, the contractor is to provide the Engineer with an updated cash
flow forecast.

<!-- page 44 -->

37.

Payment Certificate

371

The Contractor shall submit to the Engineer monthly statements of the estimated value of the
work completed less the cumulative amount certified previously.

37.2

The Engineer shall check the Contractor’s monthly statement within 14 days and certify the
amount to be paid to the Contractor after taking into account any credit or debit the month in
question in respect of materials for the works in the relevant amounts.

37.3

The value of work executed shall be determined by the Engineer.

37.4

The value of work executed shall comprise the value of the quantities of the items in the Bill of
quantities completed.
The value of work executed shall include the valuation of variations and Compensation Events.

37.5
37.6

The Engineer may exclude any item certified in a previous certificate or reduce the proportion of
any item previously certified in any certificate in the light of later information.

38.

Payments

38.1

Payments shall be adjusted for deductions for advance payments, retention, other recoveries in
terms of the contract and taxes, at source, as applicable under the law.

38.2

Items of the works for which no rate or price has been entered in will not be paid for by the
Employer and shall be deemed covered by other rates and prices in the Contract.

39.

Tax

39.1

The rates quoted by the Contractor shall be deemed to be inclusive of all taxes including
GST(SGST AND CGST) that the Contractor will have to pay for the performance of this Contract
up to the completion. The Employer will perform such duties in regard to the deduction of such
taxes at source as per applicable law from time to time.

40.

Currencies

40.1

All Payments shall be made in Indian Rupees.

41.
41.1

Price Adjustment
The rates quoted by the contract shall be deemed to include price escalation upto completion of
project.

42.

Retention

<!-- page 45 -->

42.1

The Employer shall retain from each payment due to the Contractor the proportion stated in the
Contract Data until Completion of the whole of the Works.

42.2

On Completion of the whole of the Works half the total amount retained is repaid to the
Contractor and half when the Defects Liability Period has passed and the Engineer has certified
that all Defects notified by the Engineer to the Contractor before the end of this period have
been corrected.

43.3

On completion of the whole works the contractor may substitute retention money with an “on
demand” Bank guarantee.

44.

Liquidated Damages:
44.1:In the event of failure on part of the Contractor to achieve timely completion of the
project including any extension of time granted under clause 27,he shall ,without prejudice to
any other right or remedy available under the law to the Employer on account of such breach,
pay as agreed Liquidated Damages to the Employer and not by way of penalty in a sum
calculated at the rate per week or part thereof as stated in the Contract Data .For the period
that the completion date is later then the intended completion date ,Liquidated Damages at the
same rate shall be withheld if the Contractor fails to achieve the Mile Stones prescribed in
the Contract Data .However, in case the Contractor achieves the next mile stone ,the amount
of the Liquidated Damages already withheld shall be restored to the Contractor by adjustment
in the payment certificate. Both the parties expressly agree that the total amount of
Liquidated Damages shall not exceed 10% of initial contract price and that the Liquidated
Damages payable by the Contractor are mutually agreed genuine pre-estimated loss and
without any proof of actual damage likely to be suffered and incurred by the Employer, and
the Employer is entitled to receive the same and are not by way of penalty .
The Employer may, without prejudice to any other method of recovery, deduct the amount
of such damages from any sum due ,or to become due to the Contractor or from performance
security or any other dues from Government or Semi-Government body within the State.
The payment or deduction of such damages shall not relieve the Contractor from his
obligations to complete the works, or from any other of his duties ,obligations or
responsibilities under the contract.
The Contractor shall use and continue to use his best endeavours to avoid or reduce
further delay to the works ,or any other relevant stages .
44.2. If the intended completion date is extended after Liquidated Damages have been
paid, the Engineer shall correct any such payment of Liquidated Damages by the Contractor by
adjusting the next payment certificate.
44.3: It is agreed by the contractor that the decision of the Employer as to the
Liquidated Damages payable by the Contractor under this clause shall be final and binding,

45.

BONUS – The bidder who has successfully completed three CRF works within the
prescribed time over the last five years shall be rewarded with the multiplying
factor of 2.75 instead of 2.5 for ascertaining the available bid capacity of the bidder
during the technical evaluation of his bid. The bidder to this effect shall furnish the

<!-- page 46 -->

completion certificates of works issued by an officer not below the rank of
Executive Engineer or equivalent.

46.

Secured Advance

No secured advance shall be payable to the contractor .
47.

Securities

47.1

The Performance Security (including additional security for unbalanced bids) shall be provide to
the Employer no later than the date specified in the Letter of Acceptance and shall be issued in
an amount and form and by a bank or surety acceptable to the Employer, and denominated in
Indian Rupees. The performance Security shall be valid until a date 28 days from the date of
expiry of Defects Liability Period and the additional security for unbalanced bids shall be valid
until a date 28 days from the date of issue of the certificate of completion.

48.

Cost of Repairs

48.1

Loss or damage to the Works or Materials to be incorporated in the works between the start
date and the end of the Defects Correction period shall be remedied by the contractor at the
contractor’s cost, if the loss or damage arises from the contractor’s acts or omissions.
E. FINISHING THE CONTRACT

49

Completion

49.1

The Contractor shall request the Engineer to issue a CERTIFICATE OF COMPLETION of the
works and the Engineer will do so upon deciding that the Work is completed.

50.

Taking Over

50.1

The Employer shall take over the Site and the works within seven days of the Engineer issuing a
certificate of Completion.

51.

Final Account

51.1

The Contractor shall supply to the Engineer a detailed account of the total amount that the
Contractor considers payable under the Contract before the end of the Defects Liability Period.
The Engineer shall issue a Defect Liability Certificate and certify any final payment that is due
to the Contractor within 56 days of receiving the Contractor’s accounts if it is correct and
complete. If it is not, the Engineer shall issue within 56 a schedule that states the scope of the
corrections or additions that are necessary. If the Final Account is still unsatisfactory after it
has been resubmitted, the Engineer shall decide on the amount payable to the Contactor and issue
a payment certificate, within 56 days of receiving the Contractor’s revised account.

52.

Operating and Maintenance Manuals

<!-- page 47 -->

52.1

If “as built” Drawings and/or operating and maintenance manuals are required, the Contractor
shall supply them by the dates stated in the Contract Data.

52.2

If the Contractor does not supply the Drawings and/or manuals by the dates stated in the
Contract Data, or they do not receive the Engineer’s approval, the Engineer’s approval, the
Engineer shall withhold the amount stated in the Contract Data from payment due to the
Contractor.

53.

Termination

53.1

The Employer may terminate the contract if the contractor causes a fundamental breach of the
Contract.

53.2

Fundamental breaches of Contract include, but shall not be limited to the following:
(a)
The Contractor stops work for 28 days when no stoppage of work is shown on the current
programme and the stoppage has not been authorized by the Engineer;
(b)
The contractor is declared bankrupt or goes into liquidation other than for approved
reconstruction or amalgamation;;
c)
If the contractor fails to deploy machinery and equipment or personnel as specified in the
Contract Data or Appendix to ITB at the appropriate time.
(d)
The Engineer gives Notice that failure to correct a particular Defect is fundamental
breach of Contract and the Contractor fails to correct it within a reasonable period of
time determined by the Engineer;
(e)
The Contractor does not maintain a security, which is required;
(f)
The Contractor has delayed the completion of works by the number of days for which the
maximum amount of liquidated damages becomes payable as defined in the Contract data;
and
(g)
If the Contractor, in the judgment of the Employer has engaged in corrupt or fraudulent
practices in competing for or in the executing the Contract.

For the purpose of this paragraph: “corrupt practice” means the offering, giving, receiving or soliciting
of anything of value to influence the action of a public official in the procurement process or in contract
execution. “Fraudulent practice” means a misrepresentation of facts in order to influence a procurement
process or the execution of a contract to the detriment of the Borrower, and includes collusive practice
amount Bidders (prior to or after bid submission) designed to establish bid prices at artificial noncompetitive levels and to deprive the Borrower of the benefits of free and open competition”.
53.3

When the Employer gives notice of a breach of contract to the contractor for a cause other
than those listed under Sub Clause 53 above, the Engineer shall decide whether the breach is
fundamental or not.

53.4

Notwithstanding the above, the Employer may terminate the Contract for convenience.

53.5

If the Contract is terminated the Contractor shall stop work immediately, make the Site safe and
secure and leave the site without shifting any equipment as soon as reasonably possible.

54.

Payment upon Termination

<!-- page 48 -->

54.1

54.2

If the Contract is terminated because of a fundamental breach of Contract by the Contractor,
the Engineer shall issue a certificate for the value of the work done less Liquidated damages,
advance payments received up to the date of the issue of the certificate, less other recoveries
due in terms of the contract, less taxes due to be deducted at source as per applicable law and
less the percentage to apply to the work not completed as indicated in the Contract Data. . If
the amount due to the Employer exceeds any payment due to the Contractor the difference shall
be a debt payable to the Employer.
If the Contract is terminated at the Employer’s convenience or because of a fundamental breach
of Contract by the Employer, the Engineer shall issue a certificate for the value of the work
done, the reasonable cost of removal of Equipment, repatriation of the Contractor’s personnel
employed solely on the Works, and the Contractor’s costs of protecting and securing the Works
less other recoveries due in terms of the contract and less taxes due to be deducted at sources
as per applicable law.

55.
55.1

Property
All materials on the Site, Plant, Equipment, Temporary Works and Works are deemed to be the
property of the Employer, if the Contract is terminated because of a Contractor’s defaulted.

56.

Release from Performance

56.1

If the Contract is frustrated by the outbreak of war or by any other event entirely outside the
control of either the Employer or the Contractor the Engineer shall certify that the Contract has
been frustrated. The Contractor shall make the Site safe and stop work as quickly as possible
after receiving this certificate and shall be paid for all work carried out before receiving it and
for any work carried out afterwards to which commitment was made.
Death or permanent invalidity of the contractor: the contractor shall indicate nominee for the
contract at the time of signing of the agreement. If the contractor dies during currency of the
contractor or becomes permanently incapacitated, and his/her nominee are not willing to complete
the contract, the contract shall be closed without levying any damages/compensation.
However, if the nominee expresses his/her intention to complete, the balance work and the
competent authority is satisfied about the competence of nominee, then the competent authority
shall enter into a fresh agreement for the remaining work strictly on the same terms & conditions
under which the contract was initially awarded.

56.2

<!-- page 49 -->

SPECIAL CONDITIONS OF CONTRACT

SECTION-4
4. SPECIAL CONDITIONS OF CONTRACT
1. LABOUR

<!-- page 50 -->

The contractor shall, unless otherwise provided in the contract, make his own arrangements for
the engagement of all staff and labour, local or other, and for their payment, housing, feeding and
transport.
The Contractor shall, if required by the Engineer, deliver to the Engineer a return in detail, in
such form and at such intervals as the Engineer may prescribe, showing the staff and the numbers of
the several classes of labour from time to time employed by the Contractor on the site and such there
information as the Engineer may require.
2.
COMPLIANCE WITH LABOUR REGULATIONS
During continuance of the contract, the contractor and his sub-contractors shall abide at all times by all
existing labour enactments and rules made there under, regulation, notifications and bye laws of the
State or Central Government of local authority and any other labour law(including rules), regulations, bye
laws that may be passed or notification that may be issued under any labour law in future either by the
State or Central Government or the local authority. Salient features of some of the major labour laws
that are applicable to construction industry are given below. The Contractor shall keep the employer
indemnified in case any action is taken against the Employer by the competent authority on account of
contravention of any of the provisions of any Act or rules made there under, regulations or notifications
including amendments. If the Employer is caused to pay or reimburse, such amounts as may be necessary
to cause or observe, or for non-observance of the provisions stipulated in the
notifications/byelaws/Acts/Rules/regulations including amendments, if any, on the part of the
contractor, the engineer/employer shall have the right to deduct any money due to the contractor
including his amount of performance security. The employer/engineer shall also have right to recover
from the contractor any sum required or estimated to be required for making good the loss or damage
suffered by the employer. The employer of the contractor and the Sub-Contractor in no case shall be
treated as the employees of the employer at any point of time.
SALIENT FEATURES OF SOME MAJOR LABOUR LAWS APPLICABLE TOESTABLISHMENTS
ENGAGED IN BUILDING AND OTHER CONSTRUCTIONWORK.
a)
b)

c)

d)
e)

Workmen Compensation Act 1923: The Act provides for compensation in case of injury by
accident arising out of and during the course of employment.
Payment of Gratuity Act 1972: Gratuity is payable to an employee under the Act on satisfaction
of certain conditions on separation if an employee has completed 5 years service or more or on
death the rate of 15 days wages for every completed year of service. The Act is applicable to all
establishments employing 10 or more employees.
Employees P.F. and Miscellaneous Provision Act 1952: The Act Provides for monthly
contributions by the employer plus workers @ 10% or 8.33%. The benefits payable under the Act
are: (i) Pension or family pension on retirement or death, as the case may be.(ii) Deposit linked
insurance on the death in harness of the worker. (iii) Payment of P.F. accumulation on
retirement/death etc.
Maternity Benefit Act 1951: The Act provides for leave and some other benefits to women
employees in case of confinement or miscarriage etc.
Contract Labour (Regulation & Abolition) Act 1970: The Act provides for certain welfare
measures to be provided by the Contractor to contract labour and in case the contractor fails to
provide, the same are required to be provided, by the principal employer by law. The principal
employer is required to take certificate of registration and the contractor is required to take
license from the designated officer. The Act is applicable to the establishments or contractor of
principal employer if they employ 20 or more contract labour.

<!-- page 51 -->

f)

g)
h)

i)

j)

k)

l)

m)

n)

o)

Minimum Wages Act 1948: The employer is supposed to pay not less than the minimum wages
fixed by appropriate government as per provisions of the Act if the employment is a scheduled
employment. Construction of buildings, roads, and runways are scheduled employments.
Payment of Wages Act 1936: It lays down as to by what date the wages are to be paid, when it
will be paid and what deductions can be made from the wages of the workers.
Equal Remuneration Act 1979: The Act provides for payment of equal wages for work of equal
nature to Male and Female workers and for not making discrimination against Female employees in
the matters of transfers, training and promotions etc.
Payment of Bonus Act 1965: The Act is applicable to all establishments employing 20or more
employees. The Act provides for payments of annual bonus subject to minimum of 8.33% of wages
and maximum of 20% of wages to employees drawing Rs.3500/- per month or less. The bonus to
be paid to employees getting Rs. 2500/- per month or above upto 3500/- per month shall be
worked out by taking wages as Rs.2500/- per month only. The Act does not apply to certain
establishments. The newly setup establishments are exempted for five years in certain
circumstances. Some of the State Governments have reduced the employment size from 20 to 10
for the purpose of applicability of this Act.
Industrial Disputes Act 1947: The Act lays down the machinery and procedure for resolution of
Industrial disputes, in what situations a strike or lock-out become illegal and what are the
requirements for laying off or retrenching the employees or closing down the establishment.
Industrial Employment (Standing Orders) Act 1946: It is applicable to all establishments
employing 100 or more workmen (employment size reduced by some of the State and Central
Government to 50). The Act provides for laying down rules governing conditions of employment by
the employer on matters provided in the Act and get the same certified by the designated
Authority.
Trade Unions Act 1926: The Act lays down the procedure for registration of trade unions of
workmen and employers. The Trade Unions registered under the Act have been given certain
immunities from civil and criminal liabilities.
Child Labour (Prohibition & Regulation) Act 1986: The Act prohibits employment of children
below 14 years of age in certain occupations and processes and provides for regulation of
employment of children in all other occupations and processes. Employment of Child Labour is
prohibited in Building and Construction Industry.
Inter-State Migrant workmen’s (Regulation of Employment & Conditions of
Service) Act 1979: The Act is applicable to an establishment, which employs 5 or more interstate migrant workmen through an intermediary (who has recruited workmen in one state for
employment in the establishment situated in another state). The Inter-State migrant workmen, in
an establishment to which this Act becomes applicable, are required to be provided certain
facilities such as housing, medical aid, travelling expenses from home upto the establishment and
back, etc.
The Building and Other Construction workers (Regulation of Employment and Conditions of
Service) Act 1996 and the Cess Act of 1996: All the establishments who carry on any building
or other construction work and employs 10 or more workers are covered under this Act. All such
establishments are required to pay cess at the rate not exceeding 2% of the cost of construction
as may be modified by the Government. The employer of the establishment is required to provide
safety measures at the Building or construction work and other welfare measures, such as
Canteens, First-Aid facilities, Ambulance, Housing accommodation for workers near the work
place etc. The Employer to whom the Act applies has to obtain a registration certificate from the
Registering Officer appointed by the Government.

<!-- page 52 -->

p)

Factories Act 1948: The Act lays down the procedure for approval at plans before setting up a
factory, health and safety provisions, welfare provisions, working hours, annual earned leave and
rendering information regarding accidents or dangerous occurrences to designated authorities. It
is applicable to premises employing 10 persons or more with aid of power or 20 or more persons
without the aid of power engaged in manufacturing process.
ARBITRATION(GCC CLAUSE 24 and 25)

The procedure for Arbitration will be as follows:
Any Dispute or difference arising between the department and contractor shall be dealt in
accordance with J&K Arbitration Act in vogue.
(a)In case of Dispute or difference arising between the Employer and a domestic contractor
relating to any matter arising out of or connected with the agreement ,such disputes or
difference shall be settled in accordance with the Arbitration and Conciliation Act 1996.The
parties shall make efforts to agree on a sole Arbitrator and only if such an attempt does not
succeed then the Arbitral Tribunal consisting of 3 Arbitrators one each to be appointed by the
Employer and the contractor and the third Arbitrator to be chosen by the two Arbitrators so
appointed by the parties to act as presiding Arbitrator ,shall be considered. ,In case of failure of
the two Arbitrators appointed by he parties to reach upon a consensus within a period of 30 days
from the appointment of the Arbitrator appointed subsequently ,the Presiding Arbitrator shall be
appointed by the Council ,Indian Road Congress.
b)The Arbitral Tribunal shall consist of three Arbitrators one each to be appointed by the
Employer and the Contractor. The third Arbitrator shall be chosen by he two Arbitrators so
appointed by the parties, and shall act as Presiding Arbitrator. In case of failure of the two
Arbitrators appointed by the parties to reach upon a consensus within a period of 30 days from
the appointment of the Arbitrator appointed subsequently, the Presiding Arbitrator shall be
appointed by the Council, Indian Road Congress.
c) If one of the parties fails to appoint the Arbitrator in pursuance of sub-clause (a) and (b)above
within 30 days after receipt of notice of appointment of its Arbitrator by the other party ,then
the Council of Indian Road Congress shall appoint the Arbitrator. A certified copy of the order of
the Council of Indian Road Congress making such appointment shall be furnished to each of he
parties .
d) Arbitration proceedings shall be held at Srinagar/Jammu ,India and the language of the
arbitration proceeding and that of all documents and communications between the parties shall be
English.
e) The decision of he majority of Arbitrators shall be final and binding upon both the parties .The
cost and expenses of Arbitration proceedings will be paid as determined by the Arbitral Tribunal.
However, the expenses incurred by each party in connection with preparation ,presentation etc.
of its proceedings as also the fee and expenses paid to the Arbitrator appointed by such party or
on its behalf shall be borne by each party itself.
f) Performance under the contract shall continue during the arbitration proceedings and payments
due to the contractor by he owners shall not be withheld, unless they are he subject matter of
the arbitration proceedings.

<!-- page 53 -->

CONTRACT DATA

SECTION – 5
CONTRACT DATA
Items marked “N/A” do not apply in this contract.
1.
The Employer is
Name: Chief Executive Officer, Bhadarwah Dev. Authority.
Address: TRC Sarna Bhadarwah
Name of authorized representative Superintending Engineer PWD (R&B) Circle Doda

[Cl.1.1]

<!-- page 54 -->

2.
The Engineer is Superintending Engineer PWD (R&B) Circle Doda
Name of authorized Representative:
3.
The Dispute Review as per Arbitration (GCC) Clause 25.
4.
The defects liability period is 01 Year from the actual date of completion [Cl.1.1 & 35]
5.
The start date shall be seven days from the date of issue of the notice to proceed
[Cl.1.1] with the work.
6.
The intended completion date for the whole of the works is 24 Months Calendar Months after
[Cl.1.1,16 &27 of G.C.C]start of work with the following milestones.
Milestone dates : [Cl.2.2 & 49.1]
A.Milestone to be achieved during the contract period.
i.
1/8th of the value of entire contract upto 1/4th of the period allowed for completion of
construction.
ii.
3/8th of the value of entire contract upto ½ of the period allowed for completion of
construction.
iii.
3/4th of the value of entire contract upto 3/4th of the period allowed for completion of
contraction.
iv.
Rest of the work within the remaining time period.
B. Amount of liquidated damages for delay in completion of work------ For whole of work 1% of the initial
contract price, rounded off to the
nearest thousand, per week.
C. Maximum limit of liquidated damages for delay in completion 10% of the initial contract price
of work
rounded off to the nearest
thousand
7.

The site is located in District Ramban

[Cl.1.1]

8.

The name and identification number of the contract is: Improvement/Up-gradation of _____________
[Cl.1.1]

9.

The works consist of Improvement/Up-gradation of ______________________________________________________
.The work shall, inter-alia, include the following as specified or as directed.
[Cl.1.1]

(A) Road works
Site clearance; setting out and layout; widening of existing carriageway and strengthening including
camber correction; construction of new road/ parallel service road ; bituminous pavement
remodelling/construction of junctions, intersections, bus bays, lay byes; supplying and placing of drainage
channels, flumes, guards post and guard other related items; construction/ extension of cross drainage
works bridges, approaches and other related stones; road markings, road signs and kilometre/hector
meter stones; protective works for roads/ bridges; all aspects of quality assurance of various
components of the works; rectification of the defects in the completed works during the Defects
liability period; submission of “As built” drawings and any other related documents; and other item of
work as may be required to be carriage out for completing the works in accordance with the drawings
and provisions of the ensure safety.
(B) Bridge works

<!-- page 55 -->

Site clearance; setting out, provision of foundations, piers, abutments and bearings; pre-stressed
/reinforced cement concrete superstructure; wearing coat, hand railings expansion joints approach slabs,
drainage spouts/ down take pipes arrangements for fixing light posts, water mains, utilities etc; provision
of suitably designed protective works; providing wing/ return walls; provision of road markings, road
signs etc; all aspects of quality assurance; clearing the site and handing over the works on completion;
rectification of the defects during the Defects Liability Period and submission of “As- built” drawings
and other related documents; and other items of work as may be required to be carried out for
completing the works in accordance with the drawings and the provisions of the contract and to Insure
safety.
C) Other Items
Any other items as required fulfilling all contractual obligations as per the [Cl.1.1] of ITB
Bid documents.
The following documents also from part of the contract: [Cl.2.3(i) of GCC]
Specification of Roads and Bridges (4th edition)
1.
The law which applies to the contract is law of Union of India [Cl.3.1 of GCC]
2.
The language of the contract documents is English. [Cl.3.1 of GCC]
3.
The Schedule of other contractors [Cl 7 of GCC]
4.
The schedule of key personnel [Cl.4.6(B) of Section-I]
5.
The minimum insurance cover for physical property, injury and death is Rs. 5 lakhs per occurrence
with the number of occurrences limited to four. After each occurrence, contractor will pay
additional premium necessary to make insurance valid for four Occurrences always.[Cl..12 of GCC]
6.
Site investigation report [Cl..13 of GCC]
7.
The Site Possession Dates shall be same as date of letter to proceed
With the work [Cl.19 of GCC]
8.
Fees and types of reimbursable expenses to be paid to the Dispute Review Expert (As per clause
23 of GCC)
9.
Appointing Authority for the Dispute Review Expert – To be nominated in the Bidding document)
(As per clause 23 of GCC)
10.
The period for submission of the programme for approval of Engineer shall be [Cl.26 of GCC]
21 days from the issue of Letter of Acceptance.
11.
The period between Programme updates shall be 30 days. [Cl.26 of GCC]
12
The amount to be withheld for late submission of an updated programme shall be Rs._____
(____ lacs).[Cl.26 of GCC]
13.
The currency of the contract is Indian Rupees. [Cl..40 of GCC]
14.
The formula (e) for adjustment of price are : (Not Applicable)
15.
The proportion of payments retained (retention money) shall be 6% .
from each bill subject to a maximum of 5% of final contract price.
16
Bonus for early completion of whole
of the works

17.

Shall be As per clause 45 OF GCC

The Securities shall be for the following minimum amounts equivalent as a percentage of the
Contract Price: Performance Security for 5 percent of contract price plus __%(to be decided
after evaluation of the bid) as additional security on account of un-balanced bid in terms of ITB
Clause 26.4

<!-- page 56 -->

18

The standard form of Performance Security acceptable to the Employer shall be CDR/FDR or an
unconditional Bank Guarantee of the type as presented in Section 8 of the Bidding Documents.

19.
20

The Schedule of Operating and Maintenance Manuals ______________ Not Applicable .
The date by which “as-built” drawings (in scale as directed) in 2 sets are required is Within 28
days of issue of certificate of completion of whole or section of the work, as the case may be.
The amount to be withheld for failing to supply “as built” drawings by the data required Rs.2% of
contract value.

21

22.

The following event shall constitute fundamental breach of contract. “The Contractor has
Contravened Clause 9 of GCC.” [Cl.53 of GCC]

24.

The percentage to apply to the value of the work not completed representing the
Employer’s additional cost for completing the Works shall be 20 percent [.Cl.54 of GCC]

<!-- page 57 -->

TECHINCAL SPECIFICATION

Specification for Road & Bridge works, MORT&H (4th Revision) with latest amendments
thereto and relevant
IRC specifications shall be followed in execution of the project.

BILL OF QUANTITIES (BOQ)

<!-- page 58 -->

Uploaded on website www.jktenders.gov.in
Under tender Notice No. 07

SECURITIES AND OTHER FORMS

<!-- page 59 -->

Annexure-I

SECTION –8
SECURITIES AND OTHER FORMS
Original
BID SECURITY( BANK GUARNTEE)
WHEREAS ______________________________________[Name of Bidder] (hereinafter called “the
Bidder”) has submitted his bid dated _______________[Date] for the Construction
of_______________________________ (Name of Contract hereinafter called “the Bid”).KNOW ALL
PEOPLE
by
these
presents
that
We
___________________[Name
of
Bank]
of
_________________________________________________[Name
of
Country]having
our
registered office at _________________________________(hereinafter called “the Bank”)are
bound unto the _________________________________________Name of Employer](hereinafter
called “the Employer”)in the sum of______________________________________________* for

<!-- page 60 -->

which payment well and truly to be made to the said Employer the Bank binds himself, his successors and
assigns by these presents.
SEALED with the Common Seal of the said bank this _________day of ______20_____. THE
CONDITIONS of this obligation are:
1)

If after Bid opening the bidder withdraws his Bid during the period of bid validity specified in
the Form of Bid.
OR

2)

If the Bidder having been notified of the acceptance of his Bid by the Employer during the
period of Bid validity:
a)

Fails or refuses to execute the Form of Agreement in accordance with the Instructions to
Bidders, if required ;
or

b)

Fails or refuses to furnish the Performance Security, in accordance with the Instruction
to Bidders,
or
Does not accept the correction of the Bid price pursuant to Clause 27.We undertake to
pay to the Employer up to the above amount upon receipt of his first written demand,
without the Employer having to substantiate his demand, provided that in his demand the
Employer will note that the amount claimed by him is due to him owing to the occurrence of
one or both of the two conditions, specifying the occurred condition or conditions.

c)

This Guarantee will remain in force up to and including the date ………………….**days after the end of the
validity period of the bid stated in the Instructions to Bidders or as it may be extended by the
Employer, notice of which extension(s) to the Bank is hereby waived. Any demand in respect of this
Guarantee should reach the Bank not later than the above date.
DATE ___________________________ SIGNATURE _____________________________
WITNESS _______________________ SEAL___________________________
[Signature, Name, and Address]
*
The Bidder should insert the amount of the guarantee in words and figures denominated in
Indian Rupees. This figure should be the same as shown in Clause 16.1 of the Instructions to
Bidders.
*
45 days after the end of the validity period of the Bid. Date should be inserted by the Employer
before the bidding documents are issued.

<!-- page 61 -->

Annexure-II

(BID Validity)

UNDERTAKING
1. The undersigned do hereby undertake that our firm M/s_______________________
____________________________ agree to abide by this bid
for a period ______________________________ days for the date fixed for receiving the
same and it shall be binding on us and may be accepted at any time before the expiration of
that period.

____________________________________
(Signed by an Authorized Officer of the Firm)
___________________________________

<!-- page 62 -->

Title of Officer
____________________________________
Time of firm
____________________________________
Date

Annexure-III

(Credit facility)
SAMPLE FORMAT FOR EVIDENCE OF ACCESS TO OR
AVAILABILITY OF CREDIT FACILITIES
(CLAUSE 4.2 (I) OF ITB)
BANK CERTIFICATE
This is to certify that M/s._______________________________________________ is a
reputed company with a good financial standing.
If the contract for the work, namely __________________________________________ is
awarded to the above firm, we shall be able to provide overdraft/ credit facilities to the extent of Rs.
____________________ to meet their working capital requirements for executing the above contract
during the contract period.

<!-- page 63 -->

(Signature)
Name of Bank
Address of the Bank

Annexure-IV

1.

AFFIDAVIT on correctness of Information furnished with the Bid.
I, the undersigned, do hereby certify that all the statements made in the required attachments
are true and correct.
2.The undersigned also hereby certifies that neither our firm
M/s_______________________________________________ have abandoned any work on
National Highways in India /any other work of state Government or central Govt. nor any contract
awarded to us for such works have been rescinded, during last five years prior to the date of this
bid.

1

That our firm has not been black listed or debarred in any state or central Govt. department
.Neither our firm has any history of litigations.

2

In case the contract for the work is awarded in our favour we shall invest a minimum cash up to
25% of value of the contract during the implementation of work.

<!-- page 64 -->

3

We authorise the department to seek references from our bankers
Name of bank is _______________Branch ______________Account No.________________

3.

The undersigned hereby authorize (s) and request (s) any bank, person, firm or
Corporation to furnish pertinent information deemed necessary and requested by the Department
to verify this statement or regarding my (our) competence and general reputation.

4.

The undersigned understand and agrees that further qualifying information may be requested,
and agrees to furnish any such information at the request of the Department/Project
implementing agency.

WE solemnly affirm that the information give in the bid is correct to the best of my knowledge and
belief and nothing of any sort has been concealed.
Note: Affidavit to be notarized.

____________________________________
(Signed by an Authorized Officer of the Firm)
___________________
Title of Officer
___________________
Name of Firm

DATE

Annexure-V
PERFORMANCE BANK GUARANTEE
To,
.............................................. [Name of Employer]
……………………………………………[ address of Employer]
……………………………………………………………..….
WHEREAS _________________________________________________[name and address of
Contractor] (hereinafter called “the Contractor”) has undertaken, in pursuance of Contract
No.______________dated__________ to execute _________ _________ ______[name of Contract
and brief description of Works] (hereinafter called “the Contract”);AND WHEREAS it has been
stipulated by you in the said Contract that the Contractor shall furnish you with a Bank Guarantee by a
Nationalized/Scheduled bank of India for the sum specified therein as security for compliance with his
obligations in accordance with the Contract.
AND WHEREAS we have agreed to give the Contractor such a Bank Guarantee.
NOW THEREFORE we hereby affirm that we are the guarantor and responsible to you on behalf
of the Contractor, up to a total of Rs.____________________ [amount of guarantee] (Rupees
*______________ ________________________), such sum being payable in the types and
proportions of currencies in which the Contract Price is payable, and we undertake to pay you, upon your
first written demand and without cavil or argument, any sum or sums within the limits

<!-- page 65 -->

of_________________ [amount of guarantee] as aforesaid without your needing to prove or to show
grounds or reasons for your demand for the sum specified therein. We hereby waive the necessity of
your demanding the said debt from the Contractor before presenting us with the demand.
We further agree that no change or addition to or other modification of the terms of the Contract
or of the Works to be performed there under or of any of the Contract documents which may be made
between you and the Contractor shall in any way release us from any liability under this guarantee, and
we hereby waive notice of any such change, addition or modification.
This guarantee shall be valid until 28 days from the date of expiry of the Defects Liability
Period.
Signature and seal of the guarantor________________________
Name and Designation _________________________________
Name of the Bank______________________________________
Address______________________________________________
Date_________________________________________________
__________________________________________________________________________
*
An amount shall be inserted by the Guarantor, representing the percentage the contract price
specified in the contract including additional security for unbalanced Bids. If any and
denominated in Indian Rupees.

Annexure-VI

UNDERTAKING
The

undersigned

to

hereby

undertake

that

our

firm

M/s

_________________________________ would invest minimum cash up to 25% of the value of the
work during implementation of the Contract.

______________________________
(Signed by an Authorized Officer of the Firm)
___________________

<!-- page 66 -->

Title of Officer
___________________
Name of Firm
________________
DATE

Annexure-VII
Letter of Acceptance
(Letterhead paper of the Employer)
…………………………… (Date )
To:
___________________________ ( Name and address of the contractor)
___________________________
___________________________

Dear Sirs,
This is to notify that your Bid dated___________________ for execution: completion and
maintenance of the ____________________________(name of the contract and identification
number,

as

given

in

the

Instruction

to

Bidders)for

the

Contract

Price

of

Rs.___________(Rupees_______________________________(__________________) (amount is
words and figures as corrected and modified in accordance with the Instruction to Bidders1 is her by
accepted by our agency

<!-- page 67 -->

We accept/do not accept that _______________ be appointed as the Adjudicator2. You are
hereby requested to furnish Performance Security, in the form detailed in Para 34.1 of ITB for an
amount for an amount equivalent to Rs._______________ within 21 days of the receipt of this letter of
acceptance valid up to 28 days from date of expiry of the Defects Liability Period i.e up
to______________ and sign the contract failing which action as stated in clause 34.3 of “Instructions
to Bidders” will be taken.
.

Yours faithfully

Authorized signatory
(Name & title of signatory
(Name of Agency)

1.

2.

Delete “corrected and” or “and modified” if only one of these actions, Delete as corrected and
modified in accordance with the Instructions to Bidders, if corrections or modifications have not
been affected.
To be used only if the contractor disagrees in his Bid with the Adjudicator proposed by the
Employer in the“Instructions to Bidders”.

Annexure-VIII
Issue of Notice to proceed with the work
(Letterhead of the Employer)
(Date)_____________
To,
___________________________ (Name and address of the Contractor)
___________________________
___________________________
___________________________
Dear Sirs,
Pursuant to your furnishing the requisite performance security as stipulated in ITB clause 34.1
and signing of the contract for the construction of ____________________________________at a
Bid Price of Rs._______________________________________________________________

You are hereby instructed to proceed with the execution of the said works in accordance with
the contract documents.

<!-- page 68 -->

Yours faithfully,

(Signature, name and title of
signatory authorized to sign
on behalf of Employer)

Agreement Form

Annexure-IX

Agreement
This agreement made the ____________________day of _______________________. between
___________________________________________________________________________
____________________________________________________________(name and address of
Employer) (hereinafter called “the Employer)” and______________ __ _ _ ___________________
__________________ ______________________ ________ ________________ _______
______________________________________________________________________________
____________(name and address of Contractor) (hereinafter called “the Contractor” of the other
part).
Whereas the Employer is desirous that the Contractor execute____________________
______________ _____________ ________________________ ______________________
____________________________________________________________________________
________ (name and identification number of Contract) (hereinafter called “the Works”) and the
Employer has accepted the Bid by the Contractor for the execution and completion of such Works and
the remedying of any defects therein, at a contract price of Rs._____________________________

<!-- page 69 -->

NOW THIS AGREEMENT WITNESSETH as follows:
1.
In this Agreement, words and expression shall have the same meanings as are respectively
assigned to them in the Conditions of Contract hereinafter referred to, and they shall be deemed
to form and be read and constructed as part of this Agreement.
2.

3.

4.

In consideration of the payments to be made by the Employer to the Contractor as hereinafter
mentioned, the Contractor hereby covenants with the Employer to execute and complete the
works and remedy any defects therein conformity in all aspects with the provisions of the
Contract.
The Employer hereby covenants to pay the Contractor in consideration of the execution and
completion of the Works and the remedying the defects wherein the Contract price or such other
sum as may become payable under the provisions of the Contract at the times and in the manner
prescribed by the Contract.
The following documents shall be deemed to form and be read and constructed as part of this
Agreement viz:
i) Letter of Acceptance
ii) Notice to proceed with the works:
iii) Contractor’s Bid;
iv) Contract Data:
v) Conditions of Contract : Special Conditions of Contract;
vi) Additional condition:
vii) Drawings:
viii) Bill of quantities and
ix) Any other document listed in the Contract Data as forming part of the contract.

In witnessed whereof the parties there to have caused this Agreement to be executed the day and year
first before written.

The Common Seal of .......................................................................................................
was hereunto affixed in the presence of:

Signed, Sealed and Delivered by the said
.........................................................................................................................................................
........................................................................................................................................................

in the presence of:
Binding Signature of Employer.......................................................................................................
Binding Signature of Contractor.....................................................................................................

<!-- page 70 -->
