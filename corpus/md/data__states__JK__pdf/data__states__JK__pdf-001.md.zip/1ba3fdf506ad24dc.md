---
doc_id: "1ba3fdf506ad24dc"
source_url: "https://cdn.s3waas.gov.in/s3d34ab169b70c9dcd35e62896010cd9ff/uploads/2026/02/17707947935326.pdf"
ministry: "Shopian"
title: "Appointment Order for Contractual Engagement for the positions of SBDU/BHDS under Mission YUVA."
date: ""
pages: 5
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "5052fa05e4707e20"
---

<!-- page 1 -->

Government of Jammu & Kashmir
OFFICE OF THE DEPUTY COMMISSIONER SHOPIAN
Phone: 01933-260987 Fax: 01933-261910 Email:- dmshopian-jizegmail.com

eee ‏کی‎

Subject: Appointment Order for Contractual Engagement for the positions of SEDU/BHDs
under Mission YUVA.
ORDER

In pursuance of Mission YUVA Operational Guidelines issued vide No.
ED/Plan/Mission YUVA/233/368-414 dated 18-07-2025 and the amended guidelines
providing relaxation of criteria as approved in the Minutes of the Apex Committee
Meeting of Mission YUVA held on 23.10.2025, vide No. PS/L&E/2025/ dated
15.11.2025 and on the basis of the notification issued vide No. ADDC/SPN/2025-26/792
dated 24.11.2025 and DDCS/PA/25/3885-88 dated 09.12.2025, regarding temporary
engagement of personnel for SBDU and BHD positions under Mission YUVA, it is hereby
notified as follows: :

A total of 265 applications were received through the online platform of Mission 5
YUVA, out of which 111 candidates were shortlisted through the Automatic Scrutiny :
Mechanism developed by the Office of the Mission Director, Mission YUVA. Subsequently, =
a meeting of oversight committee was held on 15-01-2025, to scrutinize the applications -
and verify credentials in detail, wherein 22 applications found eligible as per the criteria -
advertised. :

Thereafter, this office issued an Interview Notification vide No. DDCS/PA/25- 7
26/1441-46 dated 16.01.2026, and interviews were conducted on 22-01-2026 at the
DC Office Shopian vide no: DECCS/YUVA/2025-26/346-50 dated: 16-01-2025. Out of
the 22 shortlisted candidates, 19 candidates appeared before the Interview Committee. ۱

Now, based on the guidelines applicable, the composite merit secured by the
candidates and the preference exercised by them at the time of the application, the selection
list of 12 candidates for SBDU and BHDs post for temporary contractual engagement
under Mi ٦ YUVA is enclosed as Annexure-A, along with the waiting list as Annexure-
B: %

Se

<!-- page 2 -->

Annexure-A
Selection List for the posts of SBDU/BHDs _ 000
total | Post for |
8. Name Father's Name Address District | points | Temporary |
No | Engagement |
OO ‏سکس سس سس سے سس سس‎ कफ ‏کک‎ |
. . | |
1 Rayees Ahmad Abdul Rashid Melhura Shopian | 61.48 | SBDU Lead |
Hajam. Hajam. Wachi ।
hi ۹ | |
٠ $ Abdul Rashid Kanipora $ | BHD Lead |
2 | Umair Rashid Sheikh Shopian Shopian | 60.28 | (Shopian) |
i |
Sualiha Near New . 3 BHD Lead |
۰ Zeeshan Assadullah Dalal Bus Stand Shopian | 53.66 (Zainpora) |
|
| BHD |
4 | Basila Rafiq Mohd Rafiq Memanoee Shopian | 51.21 | Coordinator |
Ganie Shopian Shopian |
Mohammad 5 |
Opposite
5 |ifrah Mansoor | Mansoor Kuchay | New Bus Shopian | 50.79 oe a ee
Stand |
5 BHD |
Shahid Reyaz _ | Reyaz Ahmad Ratnipora | shopian | 49.58 | Coordinator |
Naik Shopian Zainpora) |
SBDU
Shadab कं के Enterprise |
7 Uzma Jan Ab Qayoom Bhat Rarewa Shopian | 49.33 Development |
xpert |
: SBDU
Mudasir : Pooju 7 keti |
Hussain Ab Rashid Khan Berthipora Shopian | 49.20 न |
‏سے‎ a = | Mir Pora ‏سح حک۹ؾٗگککاٛکسک_‎ SSI
._ | Near Jamia SEDU |
Muneeb Yousuf | Mohd Yousuf Mir Masjid Kulgam 48.48 | Financial |
Bachroo Expert |
1
‏بے‎ BHD |
10 ‏تس‎ aban a et ad Bunpora Anantnag | 48.20 | Coordinator |
(Zainpora)
id Ri Riyaz Ahmad Bongam हे BHD 7 |
11 | Umaid Riyaz Malik Shopian Shopian | 47.03 ‏وا‎ |
a
Sayer Ahmad Mohammad Chatripora 2 SBDU |
32 | ttoo Yousuf Itoo Shopian Shopian (46.90 | Coordinator _|
\y Ae

<!-- page 3 -->

‎Annexure- B‏ مم
‎Waiting List for the posts of SBDU/BHDs ;‏
‎Ss. Father's Hee Total |‏
‎No Name Neste Address District | points Preferences |‏
‎SBDU Lead |‏ .1 5 2
‎S¥ed Hamid Ul "| Syed Ab hanapora | srinagar | 45.90 | 2. BHD Lead‏ ||{
‎Hussnain Hamid Srinagar 3. SBDU Coordinator‏
‎Imran Gh Rasool Buchoo 1. SBDU Lead‏
‎Mohammad Kh Kokernag Anantnag | 45.85 | 2. BHD Lead‏ | 2
‎Khan कु Anantnag 3. BHD Coordinator‏
‎Malik 1. SBDU Coordinator |‏
‎Gh Qadir 2 2. BHD Coordinator |‏ 5
‎Shopian [45.84 | 3’ sppu Financial |‏ کت ‎S$ |Rabia Gulzar | Gatoo‏
‎Shopian Expert |‏
‎Gadri |‏
‎Mohammad 1. SBDU Lead‏ و و
‎Shopian | 45.79 | 2. BHD Lead‏ کے ونم ‎Amin‏ سس 4
‎ana Wachkoo oo 3. BHD Coordinator |‏
‎Shopian |‏
‎Mubark Zawoora 1. SBDU Lead‏ 7 8
‎a Ahmed Badherhama | Shopian | 45.26 | 2. BHD Lead‏ 7 5
‎an Khan Shopian . 3. BHD Coordinator‏
‎SBDU Lead |‏ .1
‎Umer Qayoom लत Shen an Shopian | 42.28 | 2.BHD Coordinator |‏
‎SBDU Coordinator |‏ .3 0 ا
|
‎Showket Ali | Nanil 1. BHD Coordinator |‏
‎ow] 2 Coordin:‏
‎$BDU Coordinator‏ .2 ۴
‎ungan Showkse Banday Anantnag Anantnag | 42.19 3. SBDU Marketing | '‏ | 7
‎Expert |‏
‎WY 1‏
|

<!-- page 4 -->

1. Nature of Engagement:

* The engagement shall be purely contractual and governed strictly by the Mission YUVA
Operational Guidelines. The appointment shall not confer any right to permanent
absorption or continuation beyond the approved project period.

2. Duration of Contract and Renewal:
» The initial engagement period shall be 11 months from the date of joining.
» Performance shall be reviewed as per predefined KPIs of Mission YUVA.
> Renewal for an additional 11 months may be granted based on satisfactory
performance and approval of the competent authority, and availability within the
project life cycle.
3. Roles and Reporting:

* The engaged personnel shall perform duties and report as prescribed under the

Mission YUVA Operational Guidelines.
4. Terms and Conditions:

* The selected candidates shall report to the office of Assistant Director Employment,
DE&CC Shopian (Member Secretary Mission YUVA) within 07 days from the date of
issuance of this order, along with the following original documents for verification and
completion of joining formalities:

> Domicile Certificate

> Date of Birth Certificate

> All Qualification Certificates

> Experience Certificates

> Undertaking

» Character Certificate issued by competent authority

* Failure to report within the stipulated’ time shall be treated as unwillingness to join,
and the next eligible candidate from the waiting list shall be considered.

* The selectee shall execute a contractual agreement outlining:

> Terms of engagement and service conditions
> Roles, responsibilities, and deliverables
> Performance evaluation parameters
> Compensation and payment terms
> Disciplinary and termination clauses
“ Monthly consolidated remuneration shall be paid as per Mission YUVA norms,
subject to verification of all documents. का
‏ےث‎ Engagement shall be subject to verification of character, antecedents, and document
authenticity.
“ The appointee shall maintain utmost integrity, discipline, and confidentiality in
official duties.
,
WY
4

<!-- page 5 -->

5. Termination of Contract:
The contract may be terminated at any time under the following circumstances:
» Poor performance or failure to meet KPIs
» Misconduct, indiscipline, or violation of code of conduct
» Submission of false or misleading documents
» Unauthorized absence exceeding seven consecutive working days
» Activities inconsistent with the objectives of Mission YUVA or involving political
affiliations
The CEO Mission YUVA / Director Employment / SPV, on the recommendation of the District
Nodal Officer, may terminate the services of any SBDU/BHD personnel at any time during the
contract period, with appropriate notice as per the contractual agreement.
All other terms and conditions shall continue to be governed strictly as per the
Operational Guidelines of Mission YUVA applicable to SBDU and BHD engagements.
fo Me,
‏.ےگ سر‎
De ag ommissioner
۱ ‏سا‎
‎o> “Ah 1 ‏ارے‎
‎71:۵22 (2//2005-26 ///४8/-98 Datea:~4'f 702/2026
Copy to the:
1. Secretary, Labour & Employment Department, J&K for information.
2. Director Employment-cum-Mission Director, Mission YUVA, J&K.
3. Additional District Development, Commissioner (Nodal Officer Mission YUVA), Shopian
for favour of information.
4. Additional Deputy Commissioner, Shopian for information.
5. Sub-Divisional Magistrate, Zainpora for information.
6. Assistant Director Employment, Shopian for information & n fa.
7. District Information Officer Shopian for information and with the request to publish
the list for wide publicity in 03 leading dailies.
8. District Informatics Officer (NIC), Shopian for information and with the request to
upload the list on District Website.
