---
doc_id: "77dfc3eeea2eb5c4"
source_url: "https://www.gpfwjammu.edu.in/notifications/250416-extn-notice.pdf"
ministry: "Government Polytechnic for Women Jammu, Jammu and Kashmir"
title: "Extension Notice"
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "f2017dba099b492f"
---

<!-- page 1 -->

221 पके 0
a GOVT. POLYTECHNIC FOR WOMEN
, (©) Lower Shiv Nagar Near, AG’s office Jammu-180001 ‏جم‎
‏اد‎ राजकीय महिला पॉलिटेक्निक G2
Er. Neelanjana Manwati शिवनगर (एजीकार्यालयके पास) जम्मू १०
Principal Contact Numbers: 0191-2955320, 2957937
Website: www.gpfwjammu.edu.in | Email: gpfwjammu@gmail.com, gpfwj@rediffmail.com
SS SSS SS SS]
Sub: Extension Notice of Hostel Mess.
EXTENSION NOTICE
The last date for submission of bids for hostel mess services floated on Gem
portal Vide bid notice no. 01 of 2025 dated: 01-04-2025 is extended upto 22-04-
2025 due to insufficient response.
yor Nonte ee
heer. Neelanjana Mand ati) ۰
incipal
Govt. Polytechnic for Women
Jammu
No: WPJ/F-149//3/—/3¢
Dated: ‏ئا‎ 5
Copy to the:-
1. Director, Skill Development Department, J&K for kind information.
2. Joint Director, information Department Jammu for information.
3. I/c committee members for information
4. Hostel Committee for information.
5, Accountant for information.
6. Office file.
