---
doc_id: "95c5eadbd2ccfeaa"
source_url: "https://skuastjammu.ac.in/newsite/pdf/anti-ragging.pdf"
ministry: "Sher-e-Kashmir University of Agricultural Sciences and Technology of Jammu (SKUAST-Jammu), Jammu and Kashmir"
title: "Anti-ragging policy and a helpline"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4d9ff649945f2b7c"
---

<!-- page 1 -->

NATIONAL RAGGING PREVENTION PROGRAMME

National Anti-Ragging Helpline
24x7 Toll Free
1800-180-5522
helpline@antiragging.in| www.antiragging.in

UGC Monitoring Agency
Centre for Youth (C4Y)
antiragging@c4yindia.org | www.c4yindia.org

Contact Details of the Anti-Ragging Committee and Squad

Anti-Ragging Committee (ARC)
Type

Person Name

HEI-ARC Dr. B.N. Tripathi
HEI-ARC

Dr. Rajinder
Peshin

HEI-ARC Dr. Anil Kumar

HEI-ARC

Dr. Sudhakar
Dwivedi

Designation

Mobile

Email

Chairman

0191-2263714 vcofficeskuastj@gmail.com

Member

9419205774

directoreducation@skuastj.org

Member

8825087701

deanfoa.skuastjammu@gmail.co
m

Member/Nodal
9469212589
Officer

dsw@skuastj.org

<!-- page 2 -->

Anti-Ragging Squad (ARS)
Type

Person Name

Designation

HEI-ARS Dr. Anil Kumar
Chairman
HEI-ARS Dr. Sudhakar Dwivedi Member
HEI-ARS Dr. Meenakshi Gupta Member
Dr. Subhash Chander
HEI-ARS
Member
Kashyap
Mr. Patwinder Pal
HEI-ARS
Member
Sidhu
Mr. Udhay Partap
HEI-ARS
Member
Singh
HEI-ARS Dr. Rajesh Katoch
Chairman
HEI-ARS Dr. Sudhakar Dwivedi Member
HEI-ARS Dr. Sharad Kumar
Member
HEI-ARS Mr. Amit Baloria
Member
HEI-ARS Mr. Saksham Gupta Member
HEI-ARS Dr. S.E. H. Rizvi
Chairman
HEI-ARS Dr. Sudhakar Dwivedi Member
HEI-ARS Dr. Moni Gupta
Member
Dr. Bhav Kumar
HEI-ARS
Member
Sinha
HEI-ARS Mr. Nishant Jasrotia Member
HEI-ARS Ms. Parveen Kumari Member
HEI-ARS Dr. Jasvinder Soodan Chairman
HEI-ARS Dr. Sudhakar Dwivedi Member
HEI-ARS Ms. Jasleen Kaur
Member
HEI-ARS Ms. Sabahu Noor
Member
HEI-ARS Mr. Shivam
Member
HEI-ARS Ms. Ridhima Dogra Member
HEI-ARS Dr. Sushil Sharma
Chairman
HEI-ARS Dr. Sudhakar Dwivedi Member
HEI-ARS Dr. J.P. Singh
Member
Dr. Sushmita M.
HEI-ARS
Member
Dadhich

Mobile

Email

8825087701 deanfoa.skuastjammu@gmail.com
9469212589 dsw@skuastj.org
9419785352 meenakg13@gmail.com
7051103674 sck2412@gmail.com
9103776193 patwinderpalkaursidhu@gmail.com
6005255171 uday123@gmail.com
6005735358 deanfvsc@gmail.com
9469212589 dsw@skuastj.org
9697201450 drsharadkumar@gmail.com
9797315857 amitbal42@gmail.com
6005297645 sakshamgupta45@gmail.com
9419138953 deanfbsc@gmail.com
9469212589 dsw@skuastj.org
7889634568 moniguptaskuast@gmail.com
9419394006 bksinha55@gmail.com
9858602963 nishantjasrotia699@gmail.com
9103776193 parveenkumari656@gmail.com
9419233374 deanfdt@skuastj.org
9469212589 dsw@skuastj.org
9797645926 jasleenkour36@gmail.com
9469210976 noorshr@gmail.com
9797645926 shivam64gh@gmail.com
9419133731 ridhimadogra21@gmail.com
9419230487 deanfoae@skuastj.org
9469212589 dsw@skuastj.org
9419174460 drjpsingh@gmail.com
9419193794 sushmita.iitd@gmail.com

<!-- page 3 -->

Type
HEI-ARS
HEI-ARS
HEI-ARS
HEI-ARS
HEI-ARS
HEI-ARS
HEI-ARS
HEI-ARS

Person Name

Designation

Mr. Sheikh Aadil
Member
Mushtaq
Mr. Himanshu Kalsia Member
Dr. Vikas Tandon
Chairman
Dr. Sudhakar Dwivedi Member
Dr. Sandeep Chopra Member
Dr. Meenakshi Gupta Member
Mr. Harish Kumar
Member
Mr. Unmeet Singh
Member

Mobile

Email

700632079 sheikhadil@gmail.com
9622565459 himanshu48@gmail.com
9419155273 deanfohfskuastj@gmail.com
9469212589 dsw@skuastj.org
9419280313 sandeepchopra43@gmail.com
9419785352 meenakg13@gmail.com
9015377656 harishkum6y@gmail.com
8082809707 unmeetsingh7@gmail.com

RAGGING IS A CRIMINAL OFFENCE AND THE CULPRITS WILL ATTRACT
PUNITIVE ACTION AS MENTIONED IN THE UGC REGULATIONS
(www.antiragging.in/assets/pdfannexure/Annexure-I.pdf)

www.ugc.ac.in
