---
doc_id: "69da6221fbfbd5ce"
source_url: "https://www.jammuuniversity.ac.in/sites/default/files/Order-Circular2026-06/Circular_0.pdf"
ministry: "University of Jammu, Jammu and Kashmir"
title: "Circular"
date: ""
pages: 6
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "00c3ed2f6c8bb48e"
---

<!-- page 1 -->

७७१४७
(८ ET ٦ CT ٦
[oo BUDGET SECTION |
8 Cy, T F
oP UNIVERSITY OF JAMMU
CIRCULAR

It is circulated for information and strict compliance of all concerned that the Finance
Department, Government of Jammu & Kashmir vide Government Order No. 198-F of 2026
dated 22.05.2026 has issued instructions regarding observance of austerity measures and
economy in expenditure during the financial year 2026-27.

Accordingly, it has been decided that the instructions/austerity measures contained in the
aforesaid Government Order shall also be observed by all the Teaching Departments, Offsite
Campuses, Directorates, Centres, Branches and other offices of the University in letter and spirit

. s0 as to ensure fiscal discipline, prudent financial management and optimum utilization of
available resources:

All Heads of the Departments/Branches/Directorates/ Offsite Campuses and Controlling
Officers are, therefore, requested to strictly adhere to the instructions contained in the enclosed
Government Order while incurring expenditure under their respective budget allocations and
further not to press for any new fresh financial commitments on items, schemes or proposals
which are not provided for in the approved Budget Estimates for FY 2026-27. बे

JO ‏سس‎
‎T £
recistRak’‘ / >
Encl: a/a 0 & Te
3 ‏اح‎
‎8٢٤-0٦ ۷

No: Budget/2026-26/ :
Dated: ‏ضف‎ ١|٥٥ ror
Copy to:

1. Special Secretary to the Vice-Chancellor for kind information of the Hon'ble Vice-Chancellor please. 7

2. Dean Research Studies/Dean Academic Affairs/Dean Planning & Development for information please.

3. Ree ae ea of Examinations/Finance Officer/Director, CDC/Director, DDE/Director,

DIQA/Directot, Centre for IT Enabled Services & Emerging Technologies for information please.

4. All Rectors/Directors of the Offsite Campuses of the University

5. All Heads/Directors of the Teaching Departments of the University

6. Dean Students Welfare/Chief Proctor/Proctor/Provost (Boys/Girls Hostel)/Dean Students Placement/

Ve Librarian (Dhanvantri Library)

7, We Administrator, General Zorawar Singh Auditorium

8. Vc Computer Centre/Coordinator Campuses

9, Programme Coordinator (NSS)

10. All Wardens of University Hostels

1], All Deputy Registrars/Assistant Registrars

12. Chief Accounts Officer

13. XEN Vc Media Cell 7

14, Medical Officer, University Health Centre

15, Chief Security Officer

16. Manager, Guest House

17. President, JUTA/JUOWA/JUNTEU/JUNGEU

18. All Sections/Guard File

<!-- page 2 -->

vc
ae Government of Jammu and Kashmir
y \4 : Finance Department
‏ڑا‎ (Budget Division)
Wes Civil Secretariat, Jammu /Kashmir
7 ‏تاد کہ بر‎
: Subject: Expenditure Rationalization — Economy and Austerity
Measures for Rationalization of Expenditure.
पा Government Order No: - 198 F of 2026
; Dated: 22, 05. 2026
Sanction is hereby accorded to the rationalization of expenditure for fiscal
a8 prudence and economy during the current financial year 2026-27 with
۹ immediate effect as per the following guidelines/measures for austerity and
a rationalization of expenditure:
۰ 1. Seminars and Conferences.
i. Utmost economy shall be observed in organizing conferences,
5 seminars, workshops, training programmes, and similar events. Such
& activities shall be undertaken only where absolutely necessary and
x after exploring virtual alternatives.
۶ ii. Holding of exhibitions, fairs, seminars, conferences, and workshops
ake outside the Union Territory of Jammu & Kashmir is strongly
0 discouraged.
‏بد‎ iii, | There shall be a complete ban on holding meetings and conferences
A in private hotels and commercial venues. Government buildings,
* conference halls, and other available Government infrastructure shall
है invariably be utilized for such purposes.
iv. Expenditure on ceremonial events, commemorative functions,
excessive branding, souvenir printing, promotional materials, and
है non-essential publicity activities shall be minimized. Departments shall
prioritize digital dissemination over printed publicity material to the
extent possible. . है
. 2. Purchase of Vehicles.

i. Purchase of new vehicles is strictly discouraged. Exceptional cases
involving critical operational requirements may be considered only
with the concurrence of the Finance Department and subject to
replacement against condemned vehicles with 20% reduction in
fleet strength.

है ii. Departments shall ensure that condemned vehicles are auctioned
and the auction proceeds deposited as Miscellaneous Revenue
before submission of any proposal for replacement vehicles,
7 0
‏دی یں ا ہے2‎

<!-- page 3 -->

1
0 Pa
ie ‏تر‎
‎۴

os 8

1

t iii, | Departments shall ensure optimal utilization and pooling of
2 available Government vehicles and avoid deployment of vehicles
| beyond functional necessity so as to promote economy in fuel

consumption and maintenance expenditure.
3. Domestic and International Travel.

i. International travel shall not be permitted unless specific approval
is obtained from the Finance Department.

il. Departments shall make effective use of Video Conferencing and
virtual platforms for meetings, consultations, and reviews so as to
minimize avoidable travel expenditure. However, within the
country, all officers shall travel only by Economy Class irrespective
of entitlement If need arises.

4. Fuel and Energy Conservation.

i Unnecessary use of official vehicles, generators, air-conditioning
systems, lighting, and other energy-consuming equipment shall be
avoided.

li. Offices shall ensure optimum utilization of transport arrangements
and reduction in avoidable movement of official vehicles.

ii. Travel within the UT shall be preferred by road or rail for all
officers/officials.

iv. Contingent expenditure shall be restricted strictly to unavoidable
operational requirements and all discretionary expenditure shall be
minimized.

v. Director(s) Finance/Financial Advisor(s) and CAO/AO(s) shall
periodically review expenditure under POL and electricity charges
to ensure strict economy.

5. Restriction on Hiring of Office Accommodation/Furniture and

Fixtures. रे

i, No new office accommodation shall be hired without prior
concurrence of the Finance Department and certification by the
concerned Department regarding non-availability of suitable
Government accommodation.

fi. No furniture shall be procured except in case of newly established
offices and only with the concurrence of the Finance Department.

ii, 00 dilapidated furniture shall be identified for disposal through
public auction and the proceeds deposited as Miscellaneous
Revenue.

6. Digital-First Governance.
Departments shall adopt a digital-first approach in official
functioning. Physical meetings, printing of bulky documents,
CE Scanned with OKEN Scanner

<!-- page 4 -->

4 a physical circulation of files, and avoidable paper consumption shall
‏0ه‎ be minimized through maximum use of e-Office, Video
res Conferencing, and digital communication platforms.

7. Holding of Official Functions.

; There shall be a complete ban on official dinners, lunches,
receptions, and similar hospitality functions except those hosted by
the Hon’ble Lieutenant Governor and Hon'ble Chief Minister.

8. Regulation of Posts, Outsourcing and Consultancy

Engagements.

. ٤ No new posts.shall be created.

ii. Filling up of regular posts shall be undertaken only through the
prescribed recruitment agencies, viz., Jammu and Kashmir Services
Selection Board / Jammu and Kashmir Public Service Commission
and with concurrence of the Finance Department. Departments
shall identify posts remaining vacant for more than two years for
surrender. Such posts shall not ordinarily be revived except under

- rare and unavoidable circumstances and with prior clearance from
the Finance Department.

iii, | Engagement of consultants, outsourcing agencies, and contractual
support services shall be undertaken only after careful assessment
of functional necessity and availability of in-house capacity. No new
PMU creations shall be undertaken by any department.

g. Local Fund Utilization.

i. The Local Funds available with various Departments, Universities,
Authorities, Boards, Corporations, and Agencies shall also be
governed by these austerity measures.

ii. Strict compliance with GFR provisions, CVC guidelines, e-tendering
procedures, GeM-based procurement norms, technical sanctions,
and administrative approvals shall be ensured in all cases.

10. Non-Priority Items of Work under Capex Budget.
Non-priority works and activities under the Capex Budget place
avoidable pressure on scarce fiscal resources and may lead to
unproductive expenditure. Accordingly, budget releases through
BEAMS shall not be permitted for non-priority new works and
activities such as repair, renovation, and upgradation of residential
quarters/office buildings, token provisions, lump-sum provisions, है
and similar non-essential works provided under BE 2026-27,
unless specifically approved by the Finance Department.

11. Fresh Financial Commitments.

CB Scanned with OKEN Scanner

<!-- page 5 -->

/ No fresh financial commitments shalt be made on items, schemes,
ot proposals which are not provided for in the approved Budget
Estimates for FY 2026-27.
4 12, Exceptional Cases.
Any relaxation or deviation from the above austerity measures shall
require prior approval of the Finance Department.
13. Compliance.

i. Administrative Secretaries shall be personally responsible for
ensuring strict compliance with the austerity measures outlined
above.

ji. Director(s) Finance/Financial Advisor(s) shall scrupulously assist
their respective Departments in enforcing these measures and shall
also submit periodic compliance reports to the Finance
Department.

By order of the Government of Jammu & Kashmir.
50/
(Shailendra Kumar), IAS,
Financial Commissioner (ACS),

Finance Department.
No.FD-BDGTOGEN/18/2021-03-(34200) Dated: 22.05.2026
Copy to the:-
1. Ld. Advocate General, Jammu & Kashmir High Court, Jammu/Srinagar.
2. All Financial Commissioners (Additional Chief Secretaries).
3, Director General of Police, Jammu & Kashmir.
4, Principal Secretary to Hon'ble Lieutenant Governor.
5, Joint Secretary (140), Ministry of Home Affairs, Government of India.
6. All Principal Secretaries/ Commissioner Secretaries/ Administrative
Secretaries.
7. Principal Accountant General (A&E), Jammu & Kashmir Srinagar/ Jammu.
8. Principal Resident Commissioner, 5-Prithvi Raj, New Delhi.
9, Chief Electoral Officer, Jammu & Kashmir.
10. Director General, 78 Institute of Management, Public Administration and
Rural Development.
11. Divisional Commissioner Kashmir/Jammu.
12. Chairperson, Jammu & Kashmir Special Tribunal.
13. Registrar General, Jammu & Kashmir High Court, Srinagar/ Jammu.

©. Scanned with OKEN Scanner

<!-- page 6 -->

/
6

14. All District Development Commissioners.

15. Director Anti-Corruption Bureau, Jammu & Kashmir. 4

ae Director General, Accounts & Treasuries/ Funds Organization/ Resources/

‘odes/ Audit & Inspection/ Local Fund Audit & Pensions/ Budget.

17. Director General, Development Expenditure Division-1, Finance Department.

18. All Heads of Departments/ Managing Directors/ Chief Executive Officers of

State PSU's/ Autonomous Bodies/Societies.

19. Registrars, all Universities of Union Territory of Jammu & Kashmir.

20. Director Information, Jammu & Kashmir.

21, Director Archives, Archaeology and museums, Jarnmu & Kashmir.

22, Secretary, Jammu & Kashmir Public Service Commission.

23. Secretary, Jammu & Kashmir Service Selection Board.

24, Secretary, Jammu & Kashmir Legislative Assembly.

25. Director Estates, Jammu/Kashmir.

26. Director, Development. Expenditure Division-II, Finance Department

27. Director, Resources/ Accounts & Treasuries, Jammu/Kashmir.

28. Director/Principal, North Zonal Accountancy Training Institute, Jammu.

29, All Director(s) Finance/ Financial Advisors & CAOs.

30. All Director(s) Planning/ Joint Director(s) Planning.

31. SIO, NIC, Civil Secretariat, J&K

32. Principal Accountancy Training School Srinagar.

33. Joint Director, Jammu & Kashmir Funds Organization, Srinagar/ Jammu.

34, All Treasury Officers, Jammu & Kashmir /New Delhi.

35. General Manager, Government Press, Jammu/Srinagar.

36. OSD/Private Secretary to Hon'ble Chief Minister.

37. Private Secretaries to all Hon‘ble Ministers.

38. Private Secretary to Hon'ble. Advisor to Hon‘ble Chief Minister.

39, Private Secretary to Chief Secretary, Jammu & Kashmir.

40. Private Secretary to Additional Chief Secretary to the Government, Finance

Department.

41, All Officers/AAOs/Section Officers of Finance Department.

42. 1/C Website, Finance Department (www. jakfinance.jk.gov.in).

43. I/C Website, GAD (www. jkgad.nic.in).

44, Record file (W2scs). :
ial
(Dr Si A. Wani) JKAS
Deputy Director (Budget)
Finance Department
