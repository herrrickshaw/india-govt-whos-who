---
doc_id: "4f2c2cfed367ebad"
source_url: "https://hme.jk.gov.in/assets/pdf/GO744.pdf"
ministry: "Health and Medical Education Department, Jammu and Kashmir"
title: "G.O. No.744 → Declaration of Services as Quasi Permanent"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "56365e2819e300b4"
---

<!-- page 1 -->

Govemment of Jammu& Kashmir
Health & Medical Education Department
Civil Secretariat, J&K.

Subject: Declaration of Services as Quasi Permanent.

Government Order No.y4-JK (HME) of 2026
Dated. 06.10.2026

Civil,
In terms of Rule 3(1) and 3-A(1) of the Jammu and Kashmir Vol-II
IX of J&K CSR
Services (Temporary Service) Rules 1961, Schedule
Medical
Sanction is hereby accorded to the declaration the services of following
Officers of Directorate of Ayush, J&K, as Quasi Permanent:
S.
Present Place of Posting
Name & Designation
No.
AHWC Seswan, LDistrict Kathua
Dr. Sanjeet Kumar, Medical Oficer
1
Dr. Tariq Ahmad Ganie, Medical
AAM Bayari, District Bandipora
2
Officer

Dr. Riyaz Ahmad Dar (Retired),

3

Medical Officer

Dr. Roopsi Gupta, Medical Officer
Dr.Om Prakash, Medical Officer

4

Dr. Nikhil Mahajan, Medical Officer
Dr. Vimal Sharma, Medical Officer

6

Dr. Sanjay Kumar Koul, Medical

8

Officer

Dr. Punam Kurhan, Medical Officer
10
11
12

Dr. JarnailSingh, Medical Officer
Dr. Nusrat Kawoosa, Medical Officer
Dr. Mohammad Jamal Bhat, Medical
Officer

14

Dr. Mona Prasher, Medical Officer
Dr. Ajay Kumar Dass, Medical

15

Dr. Ruhail John, Medical Officer

13

Officer

16

Dr. Syed Abdul Shakoor, Medical

17

Dr. Mohammad Amin Kawa, Medical

Officer

Officer

AAM Ayush Tilgam, Baramulla
Govt. AHWC Nanga, District Samba
Govt. AHWCMalikote, Reasi
Govt. AHWC, District Samba
Govt. AYUSH HWCBagyldera,
Poonch
Govt. A YUSHHWC Rajpura,
District Samba

Nagrota Preyta, District Kathua
Govt. AYUSH H&WC Kuthar,
Jammu

AAM Ayush Shalimar, Srinagar

AYUSH Unit, SMHS Hospital,

Srinagar

AAM Ayush Ghagwal, District
Samba

AYUSH AMM Bajja Chairalla,

District Doda

AAM Ayush Palpora, Srinagar

AYUSH Govt. Unani Hospital,
Shalteng, Srinagar

AAM Ayush Kehnoosa, Bandipora

<!-- page 2 -->

18
19

Dr. Shabir Ahmad Bhat, Medical
Offcer

AYUSH Unit, SDH Handwara

Officer

Jammu

AAM Ayush Shahbad Bahufort,

Dr. Sarika Raj Kumari, Medical

By Order of Government of Jammu and Kashmir.
Sd/

(M. Raju), IAS
Commissioner/Secretary to the Government,

Dated:-06.10.2026

NO: HD-Ism/38/2026-02 (E-7729132)

Copy to the:
1. Accountant General, J&K, Srinagar.
2. Joint Secretary (JKL), Ministry of Home Affairs, Government of India.
3. Director, Archives, Archaeology and Museum Department, J&K.
4. Director Finance, Health and Medical Bducation Department.

5. OSD to Hon'ble Minister for Health and Medical Bducation Department.
6. Director Ayush, J&K.

7. Private Secretary to Commissioner/Secretary to the Government, Health
and Medical Education Department.

8. Concerned officers.

9. Incharge website.
10.Govt. Order file (w.2.s.c).

(AnilKmar Chandail)JKAS,
Additional Secretary to the Government,

Health and Meical Education Department.
