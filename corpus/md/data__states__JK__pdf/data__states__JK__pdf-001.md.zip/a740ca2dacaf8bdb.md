---
doc_id: "a740ca2dacaf8bdb"
source_url: "https://cdn.s3waas.gov.in/s3ae0eb3eed39d2bcef4622b2499a05fe6/uploads/2020/08/2020082428.pdf"
ministry: "Ramban"
title: "Order regarding Opening of religious places"
date: ""
pages: 2
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "504384e7bdeedb2f"
---

<!-- page 1 -->

٤ 1807
८५: Rion
‏ےمم‎
‎0۴ 0) ‏جم"‎
‎© My ۵ 2 ७
py Bla ®
RAMBA\ =/ *
a Aan
GOVERNMENT OF JAMMU & KASHMIR nbs
OFFICE OF CHAIRPERSON DISTRICT DISASTER MANAGMENT
AUTHORITY (DISTRICT MAGISTRATE) RAMBAN
Sub; COVID-19 Management- Opening of religious places/places of worshipthereof
ORDER
Whereas, COVID-19 has been declared as global pandemic by World Health Organization
(WHO) affecting several Countries of the world including India;
Whereas, guidelines was issued by the Government of UT of J&K on lockdown measures
and all the religious places/places of worship were closed due to the pandemic COVID-19
Whereas, as per SOP issued Vide Government Order No: 75-JK (DMRRR) of 2020 dated.
41.08.2020 under which the Government has allowed to open religious places/places of
worship subject to various conditions.
Now, therefore in view of the above mentioned facts and in the interest of safety and well
being of general public al large, | Nazim Zai Khan, KAS District Magistrate Ramban in
exercise of the powers vested in me under Section 144 Cr.P.C, Section 34 of National
Disaster Management Act, 2005 and in accordance with Section 2 of the Epidemic Diseases
Act, 1897 do hereby allow to open the religious places/places of worship in territorial
jurisdiction of District Ramban except in conlainment/Red Zones declared by this office
subject to the following conditions:

a. That organizations managing the affairs of various places of worship are mandatorily
required to sel up COVID-19 safety committees which may consists of their
volunteers/Sevadars/employees These committees shall be required to ensure
adherence to the SOP at all times.

b. Persons above 60 year of age persons with co-morbidities pregnant women and
children below the age of 10 years are restricted to visit religious places/places of
worship.

c. All devotees are required to maintain distance of six feel from each other in these
places at all times even when queuing up for entry and exil.

d. All the devotees are to be allowed entry only if they are using face covers/masks.

e. Only asymptomatic persons would be allowed entry into the premises.

f. Touching of statue, Idols, Holy Books etc should not be permitted

9. ‏اعد‎ offerings like sprinkling of Holy water, Prasad etc should not be allowed.

h. Installation and use of AarogyaSethu App shall be mandatory for all visitors.

i. Sanitization of premises should be done on regular basis.

J. Common prayer mats/Durres should not be used and whi i

og ٥٥٥۵۷٢ ۲
‏کی )ا‎ shall carry their own individual mats which shall be taken along. 165
\
0 yo. —— a
De a Email: derambanjx@nie.in > ‏۔--۔۔۔س‎
‎0800 Fax/Ph. 01998-266906, 266789
Scanned with CamScanner

<!-- page 2 -->

k. Instructions laid down in Govt Order No: 75-JK (DDMRRR) of 2020 dated:
11.08.2020 shall be obeyed in letter and spirit.
This order shall remain in-force with effect from 24.08.2020 till further orders.
In view of the emergent nature of the order, it is not possible to serve it individually and is
addressed to the public of Ramban District in general. It shal be circulated in print, electronic
and social media and through the medium of loud speakers for information of all concerned.
Any violation of this order shall invite action under Indiat Penal Code/Disaster Management
Act, 2005 and Epidemic Diseases Act, 1897.
Issued under my seal and signature today on 24.08.2020 ‏.سے‎
‎۱ ‏سے سے‎
No: DCR/COVID-19/2147-57 Nba P| Do
Date: 24.08.2020 Aas > 0 04
G 5 820+: 30 au
2 1 ) o\Chairperson District 0 t Management Authority
Sp a trict Magistrate Ramban
Copy to: * 6७४ JQ
‏ج ر یہہ‎
‏سن و تقد‎ *
2. Divisional ٥970031 , Jammu for information.
3. IGP, Jammu.
4. Senior Superintendent of Police, Ramban for information & necessary action.
5. Senior Superintendent of Police, Traffic Ramban for information & necessary action.
6. Additional District Magistrate Ramban
7. Assistant Commissioner Revenue Ramban
8. Sub-Divisional Magistrate, Gool/Banihal/Ramsoo for information & necessary action.
9. Tehsiidar, Ramban/Banihal/Gool/Ramsoo/Ukhral/Khari/Batote/Rajgarh for info. & n/a
410. SHO, Ramban/Banihal/Ramsoo/Batote/Gool/Chanderkote/Dharamkund for info. &
nla
11. District Information Officer, Ramban for vide circulation of the Order
42. DIO NIC Ramban for placing a copy of this order on Official Website of District
Scanned with CamScanner
