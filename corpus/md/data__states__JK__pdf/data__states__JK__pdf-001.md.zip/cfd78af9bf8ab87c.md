---
doc_id: "cfd78af9bf8ab87c"
source_url: "https://jknis.dpiit.gov.in/Document/Guidelines.pdf"
ministry: "New Central Sector Scheme for Industrial Development, Jammu and Kashmir"
title: "Registration"
date: ""
pages: 27
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "23af5a9bd772b256"
---

<!-- page 1 -->

1 (1 )/2020-SSS

Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry & Internal Trade
(Special Scheme Section)

*****
Udyog Bhawan, New Delhi
Dated: 01st April, 2021

To
Principal Secretary (l&C)
Govt. of Jam.mu & Kashmir,
Civil Secretariat,
Jammu-180004 (J&K.)
Subject: General Operational Guidelines for Registration of Units under New Central Sector
Scheme for Industrial Development of Jam.mu & Kashmir- regarding.
Sir,
I am directed to forward herewith General Operational Guidelines for Registration of
Units under New Central Sector Scheme for Industrial Development of Jam.mu & Kashmir.
2. It is requested that the Guidelines may be uploaded on website of the UT Govt. of J&K along
with wide circulation in the public domain.
3. The Home Page of the Scheme Portal is expected to be hosted in the today evening, however
Login and submitting application on the portal shall be available within couple of days.
4. This issues with the approval of Secretary, DPIIT (Chairman, Steering Committee).

Yours faithfully
~ 1t1}J.,

_,DI//;

c:~c-:=s ,-r/4,...,/-i:'"'

(Ganesh H. Nikhare) 1
Under Secretary to Govt of India
Tel No. 23062823
Email: ganesh.nikhare19@gov.in
Copy to:
1. Director of Industries (Jammu), Directorate of Industries & Commerce, 1st Floor, Udyog
Bhawan, Rail Head Complex, Jammu-180012.
2. Director oflndustries (Kashmir), Directorate of Industries & Commerce, Sanat Ghar, Bemina
Srinagar-190014.
3. General Manager, JKDFC, Ground floor, Udyog Bhawan, Jam.mu (J&K)-180004.
4. NIC, DPIIT with the request to upload it on the portal of the scheme (jknis.dipp.gov.in) and
DPIIT website.

<!-- page 2 -->

F. No.1(1)/2020-SSS
GENERAL OPERTATION GUIDELINES FOR REGISTRATION OF UNITS UNDER
NEW CENTRAL SECTOR SCHEME FOR INDUSTRIAL DEVELOPMENT OF
JAMMU & KASHMIR

These guidelines are issued and should be read with the notification issued vide
F.No.1(1)2020-SSS dated 19.02.2021 for Central Sector Scheme for Industrial Development
of Jammu & Kashmir.
1- Registration under the Scheme shall commence from 01.04.2021 and will continue till
30.09.2024.
2- All application for registration shall be disposed of by 31.03.2025 unless otherwise
extended.
3- The applicant unit willing to avail incentive(s) under the scheme has to apply for
registration through online portal jknis.dipp.gov.in in the forms enclosed at Annexure I
along with the following documents :
(i) Detailed project Report as per the Annexure II
(ii) Land documents (Revenue paper regarding owner ship/rent deed duly registered by
the registering authority/lease deed in case of Govt. land)
(iii) Bank loan sanction letter.
(iv) Appraisal Report from the bank/financial institution showing the appraised cost of
building, plant and machinery, miscellaneous fixed assets etc.
(v) Appraisal Report from Jammu & Kashmir Development Finance Corporation
Limited(JKDFC) in case of self-financed units.
(vi) Certificate from CA for fixed assets of the unit regarding investment already made
in the project in case of units which are under implementation or have to commence
commercial production/operation.
(vii) Consent/NOC from State Pollution Control Board to establish and manufacture the
finished product( s) or run unit.
(viii) Certificate of mandatory/obligatory registration/approval from concerned
department as applicable.
(ix) Copy of Incorporation Certificate in respect of firm and unit.
(x) Certificate from CA stating detail of all the owner(s)/director(s)/partner(s)
(xi) CopyofPAN.
(xii) Copy of GSTIN certificate.
(xiii) Copy oflast GST return filed as applicable.
(xiv) Udyam Registration/EM II
4- Merely submitting application for registration will not entitle any applicant for
registration under the scheme. The following shall be taken into consideration for
granting registration to the unit under the scheme:
(i) Application submitted through on-line portal with all the details required therein
along with all the documents with their correctnes~
1

<!-- page 3 -->

(ii) Detailed Project Report, Bank Appraisal Report.
(iii) Eligibility of unit as per the provision contained in the notification dated 19.2.2021
of the scheme.
(iv) Fixed Financial Assets, availability of land, required power connection, adequate
required infrastructure to run the unit, source of finance, employment generation
potential and sustainability to run unit.
(v) Submission ofrequired documents from the authorized authority to run the unit.
(vi) Unit should not be blacklisted by any authority under the law or bankrupt or
declared NP A.
(vii) Any other information/documents required by the registering authority.
5- No unit will have the right to register under this scheme or claim the benefits unless it is
specifically approved by the registering authority. The following committees are
designated for approval of grant of registration of the unit under the scheme:

A. Secretary Level Committee (For Investment in P&M/Build.ing & other durable
physical Assets up to Rs. 500 Cr.)
s.
Designation
Role
No.
1.
2.

Administrative Secretary to the Government,
I&C Department, J &K
Director I&C, J ammu

Chairman
Member Secretary
(Jammu)

3. Director I&C, Kashmir

Member Secretary
(Kashmir)

4.
5.
6.
7.

Member
Member

Managing Director, JKDFC
Director Planning, I&C Department
Director Finance, I&C Department
Representative from the concerned Administrative
Department not below the rank of Addl. Secretary
(in case of Service Sector Units)

Member
Member

B. Chief Secretary Level Committee (For Investment in P&M/Build.ing & other

durable physical Assets more than Rs. 500 Cr.)
Designation

s.
No.
1.

Chief Secretary, J &K

2. Administrative Secretary to the Government,

Role
Chairman
Member Secretary

I&C Department, J &K

3. Administrative secretary of Concerned Department
4.

(in case of Service Sector Unit)
Director I&C, J ammu

5.

Director I&C, Kashmir

6.

Managing Director JKDFC

Member
Member
Member
Member
2

<!-- page 4 -->

6- Heritage property not in use before 1.04.2021 is restored thereafter for commercial or
hospitality or tourism services on commercial basis will also be considered as new unit as
per the following eligibility conditions:
i. Heritage property under the scheme shall include those recognized/defined as under:

a. Monuments notified under ASI
b. Monuments notified by the State Government under Ancient Monuments
Preservation (Amendment) Act, 2010.
c. Heritage sites notified under The Jam.m u & Kashmir Heritage Conservation and
Preservation Act, 2010.
d. Heritage Monuments listed by recognized Agencies such as UNESCO, INT ACH
(Indian National Trust for Art and Cultural Heritage) etc.

ii. Its restoration/conservation/preservation should have been done on the basis of a
conservation plan prepared/vetted by INTACH, J&K or a qualified conservation body
duly notified by the UT.
7- Zone A and Zone B for the purpose of this scheme as defined by UT Govt. of J&K shall
be as per Annexure m.

8- (i) If any unit is availing or has availed any incentive envisaged in this scheme, from
other scheme(s) of Government of India, it will not be eligible for those incentives under
this scheme. However, it will be eligible for other incentive(s) under this scheme.
(ii) If any unit applied for similar incentive from other scheme( s) of Government of India,
it has to opt to receive such incentive only from any one of the schemes.
9- Details of core and non-core segment in Plant & Machinery for manufacture and
construction of building and other durable physical assets in service sector is enclosed at
AnnexureIV

10- Eligible building and physical durable assets of service sector under the scheme shall be
as per Annexure V
11- The details of application and documents uploaded for registration shall be verified after
site visit of the unit (Premises) and examination of the documents by the concerned DIC.
After checking the eligibility of the applicant unit as per the scheme notification dated
19.02.2021, the General Manager, DIC (concerned) shall recommend the application for
registration to Directorate of Industries & Commerce ( concerned) along with the online
certificate that the unit does not fall in negative list in case of Manufacturing units and
service activity falls in positive list in case of Service Sector Unit as defined in
notification no. F. No. 1(1)/2020-SSS dated 19th February 2021 and the unit fulfils all
criteria as per the scheme notification. The applications received on the portal at

-

3

<!-- page 5 -->

Directorate Level recommended by General Manager, DIC (concerned) shall be placed
before the designated committees for approval of grant of registration.
12- The beneficiary of this scheme has to furnish an undertaking to abide by the terms and
conditions of the scheme.

4

<!-- page 6 -->

Annexure-1
1) Organization's Detail

"PANNo

"GSTNo

' GST R_ogilb'ation Date

~

------

2) Owner(s)/Partner(s)/Director(s) Detail

Add Column

v

Add,..,.

O!NIOPINNO

l\loblleNum~r

PAN No.

(ex: mynameOYexample.com

3)

Detail of Unit against which application is to be submitted

'UOnltNome

'Typ,tofE••• -

INew Unft

vJ

{ M1nufac:tur1no

'Olsl,i<I

aJ

·- RBI ~loldlg°'9--.Nome

I

Sl:ate Bank of Tndia

4)

"Udyaml IEM No

.

_ _,,..,._

Thfs' portiOn ~haN rt!maln bl.lnk 1n Application form
TNs portion shall rematn btan" tn Appllc.at1on form

• llank IFSCCod9

.., J

Confirmation for availing Incentives from other schemes of Govt of India

Vo, No

Add Colunm
St.otus of -und1< ti. Sc:home

••• .,. of5chem<t

OWoer Ministry/ Department of the Scheme

5

<!-- page 7 -->

5)

Additional Detail of Unit based on selection of Type of Establishment and Sectorabove. Only

relevant options from option a to f will be visible.
5.a) For Existing Manufacturing Unit

O•• of co~ol c:ommardal productiaft

,,
Flrnshed Produ°'s)

Annu.i Produa10n ~

.

jftl

PrOduction V.alue in Rs

5.b) For Existing Service Unit

,,.

.

Add Column

I

Tourism &. HO$Pit.>Nty St1 v

j

5.c) Existing Manufacturing Unit for Substantial Expansion

GSTNo

Eq,edodO...olcom ••••• ...,., •• ,o1_ ~ .,lhe- ,,.,.
OST

11:J,
~ - L.ood(KW)

,

.

NomoolProduct

6

<!-- page 8 -->

5.d) Existing Service Unit for Substantial Expansion

[EJdoling Power load (KW)

[

il

I

II

,, ~

.

I[

Addllonat P- load Requaed for o,cpenolofl (l(W)

l

Add COiumn

Name of S•rvfce Rendtred

[ Tourism & Hosottatlty 5., v

j

Existing MIJU.t Valuo of
servf<.e Rend<!red (Rs)

Proposed An,..,.r Valuo of
SeNoco tn be Rendered (Rs)

5.e) New Manufacturing Unit

llffiJ'

·-;. ·--·

....J

Add.Column
Productn,,me

An- production {MT)

Value of produce (Rs)

S.f) New Service Unit

,I

Add Column

I

Tburlsm & HOSl)ltaOty Se< v

I

AMual Value of Sl!nll<e (Rs)

7

<!-- page 9 -->

6)

Detail of fixed capital Investment based on applicability

--c,...••.... --!""'."'":~

kfr-5'

,Jr

M&X >~4¼%5/W II

&I

I

I' -{

Tomi

7) Source of Finance and Employment Generation Detail based on Applicability based on
applicability

r~ OffHltall <.Ontribwoi,

~~--·--· .

==rn

--_

_.

=
~

]

1

-

=

8

<!-- page 10 -->

8)

Scheme Eligibility based on data entered above and further detail required for relevant
schemes to be entered

__ .,._,.._,..,_toal'PI,·
Capital lnllOSlmont ln<ffllM (00 CBpllal lnterestSUIMntlan (OS) Goods & s..Mcu Tax Unlcod lna,ntM, (Gmn Wortc:t,,g Caplt.11 Jnlf:rest SUbllentfon (WCIS)

--------__
--..-----_

--

--·
--·
-- ,,._ _
AM 'I NL.lltt

,...

__ . " ""'_I . -,...-.-io, . . _ . •

I

__
I

I

I

I

--"'""""'_.,

_

_.,

,

__ __,
•..

. . , . ,., . . . •

-- - .•...• ,, •.• 20,,1,,_ .• __ ,.,_,..,_,., __ .,""'llnauril

__.,_ _

r- - forc:onmldlonol--

I

,'

=1

I

I

p__
-- _-. _~""-_
I

__

I

~1

I

.

.

•..

I

I ..
,,,_

..

~_

blo......,.,_

I

___ ...,.Dllk20f91or-oldutablo.-r-l-~-····20,,1

_tl

1

I

Acluat~--01 lk.2019io,_•• __

..

~ - lo, __ .,......,._ ,_ .,

o,o,.20191af-ofbotilg

I

I

I

l

J

-

J

•.•.• ...,.. •.••

-·--·'°'"'''"'_ .. __

l

pl,y,lcal_,.,_

A.dull lnvbtmtnlffla ~01 00019fot ~of ORI* phy*-' _,...pmand sh::e 01 o, 2019 for

l

'

9

<!-- page 11 -->

_ U nt,

- .Uotz

""'-- - - -01042011

-1.lntl

=

-

MlaMSfli!ICt

"

ff

-

r:r~Sttl!<t
(~1:eserect: __

V

_,ZJpCodt

~

'----------------------.--------------------------•...•---PrinclpallOon"""""'-

1

- Of ••••• - ••••••••• _

I """

I

Choice

v

j

-LIM1

-..u..2
loanM10untUMdlw,rva.,M11n1o1 ••••• p1,w-,d~---·104,2119

I

l

-

R~ loM..,...in ••••

[

l

TOIM..wrtllld1t1111..iM*"11(R~loitllil!Nnor7y••• ~ it!IM)

J

I

---_., __
- -----

- Of ••••••

lf111tCl,olce

Oaa.oiunc:1 on

-Uotl

~-... I

vl

-I.NZ

LOWIM,ountvMdfcw~~lluilditt, ~ ofCMlll6t..,.... •••• Mdhi'linMlllllonllnce
01042019

1•••• ....__..,

- .,.._.. _

_ I.lot,

- -- - ••••• ,1002019

~.

---

V

•• ,,

)

-IZlpCodt

•

I

10

<!-- page 12 -->

_
_.,_
., _ .

N_.,

! Fl;.,. °""'"

ed_

~I

Mnftl.Jofl

,,_.,,_ __...,,,tlNZOff

I

. ..

I

,_. ,. .._,.,_ . . ....,_ ~-,nd---·

01 OA.2019

"""""°"-Po,tlil/llpCodo

_lOO,.ofolglble_ •• _

Name of !ending bril n,glotlf9d RBI O!ganlzOdon

AddrH>Une1

AdcnnUne2

Please select

..,,

Please Select

TN< porllOn shall '"""''" blonkln Appllcotoon tonn

POSIII / Zip Code

11

<!-- page 13 -->

A d u o J-

.-we 01042019 lorp«ICllf8fflOnlol-pln& lnilc/llNry-

Ptopooed .,......,. forp,ocun1mef11of-plont&maclllnoty llemsfor-lllionololdsllng lri

A-I investment mode NICO 01 04 2019 forp,_ol _.,.... &

..-Y

k- lof oxpa,iaion of OJoietjng "'111

--- ••••• 010420191orp_., __ phystal_

----- 1inco 01.04 2019 lor.._ol_phyllcal_ u,r_...,.

Of 04 2019)

ln""""""1tmede for-o1buidng. p,ocuremen1 & lnalolelion ol..._ pbplcol-in ile

•"°"'1l uni

---medtolnce 01 04.2D19lor_ol_ bullding ""-""""

I

I

-,......_olnce010420191or,,__.,,_ •••_phyaic:al_lor__,

[

)

----llince01.G420191or.-.oldu,_....,__pn,and_
01 04.2019 laf opanaion

12

<!-- page 14 -->

9)

Required documents to be uploaded.

N- of lending bln4c/- RBI reglslered ln9ll!u!lon

I

First Choice

v

I

-.Une1

0I

Addran LIM 2

~""".:I
Pie= Sele<t

v

Loan,_,,,. ,_,or~ol-P""tlnd ~since DI 04.2019

------..•

Slate

Please Select

Totol aslfmmd.,.._ amau,t~esldullloan"""""

[

or 7,-awltileYerlo leas)

PO!lal /ZJp Code

J

N- of lending.,....,_ reglotered lmltiMlon
[ FIM Cl\olco

"

l

Address line 1

13

<!-- page 15 -->

Annexure II
Proiect Report:

The Applicant must submit a Detailed Project Report (DPR) online along with the
application. The detailed project report must consist of the following points:
a)
Promoter's background
b)
Details of product to be manufactured/ services rendered and its marketing potential
c)
Land area applied for and tentative break-up of possible areas
d)
Layout plan
e)
Implementation schedule
f)
Product process flowchart
g)
Projected Cash flow statements
h)
Total investment detail including investment in Plant & Machinery (in case of
Manufacturing Sector), Building & Other Physical Durable Assets (in case of service
sector), Requirement of Working Capital
i)
Detail of plant & machinery /construction of building and durable assets required by
the unit.
j)
Sources of Finance for the Project
k)
Projected Employment Detail
1)
Power requirement
m)
Water requirement
n)
All statutory clearances, such as environmental clearance etc.

14

<!-- page 16 -->

Annexurem

Zone Classification
District wise break-up of Blocks in Zone A & B of Jammu and Kashmir:
Districts wise Break up of Blocks in Zone A & B of Jammu Division
SNo
Districts
Zone A
ZoneB
I.
Assar
II.
Bhaderwah,Bhagwah
m.
Bhalessa(Gandoh)
IV.
Bhalla,Changa
V.
Chilli Pingal
VI.
Chiralla
VII.
Dali Udhayanpur
1.
Doda
NIL
vm. Doda
IX.
Gundana
X.
Jakyas
XI.
Kahra
XII.
Kastigarh
xm. Khalleni
XIV. Marmat
xv. Thathri
I.
Akhnoor
II.
Bhalwal Brahmana
m. Arnia
IV. Dansal
I. Bishnah
V. Khour
II. Marh
VI. Mathwar
ill. Satwari
VII. MairaMandrian
2.
Jammu
IV. Nagrota
vm. Manda! Phallain
V. R.S. Pura
IX. KharahBalli
VI. Miran Sahib
X.
Pargwal
XI. Chowki Choura
XII. Samwan
xm. Suchetgarh
XIV. Bhalwal
I.
Bani
II.
Duggan
III.
Bhasohli
I. Hiranagar
3
Kathua
IV. LohaiMalhar
II. Kathua
V.
Baggan
VI. Bhoond
VII. Duggain
15

<!-- page 17 -->

VTII. Billawar
IX.
Mahanpur
X.
DingaAmb

4

Kishtwar

NIL

5

Poonch

NIL

6

Rajouri

NIL

XI. Mandli
XII. · Keerian
XIII. Bamoti
XIV. Marheen
xv. NagrotaGujroo
XVI. Dhar Mahanpur
XVII. Nagri
I.
Bunjwah
II. Dachan
III. Drabshalla
IV. Inderwal
V. Kishtwar
VI. Marwah
VII. Mughal Maidan
VID. Nagsani
IX. Padder
X.
Palmar
XI. Thakrai
XII. Trigam
XIII. Warwan
I.
Balakote
II. Bufliaz
III. Lasana
IV. Loran
V. Mandi
VI. Mankote
VII. Mendhar
vm. Nangali Sahib SaiBaba
IX. Poonch
X.
Sathra
XI. Surankote
I.
Budhal
n. Dangri
ill. Darhal
IV. Doongi
V. Kalakote
VI. Khawas
vn. Lamberi
VIIl. Manjakote
IX.
Moughla
X.
Nowshera
16

<!-- page 18 -->

XI. Panjgrain
:x n. Planger
xm. Qila Darhal
XIV. Rajnagar

,

7

Ramban

NIL

8

Reasi

I. Katra

9

Samba

10

Udhampur

I. Bari Brahmana
II. Samba
III. Vijaypur
IV. Purmandal

I. Udhampur

XV. Rajouri
XVI. Seri
xvn.Siot
xvm. Sunderbani
XIX. Thanamandi
I.
Banihal
II. Batote
III. Gandhri
IV. Gool
V. Gundi Dharam
VI. Khari
VII. Rajgarh
VIII. Ramban
IX. Ramsoo
X. Sangaldan
XI. Ukhral
I.
Amas
II. Bamagh
III. Chasana
IV. Guiab Garb
V. JijBagli
VI. Mahore
VII. Panthal
VIII. Pouni
IX. Reasi
X. ThakraKote
XI. Thuroo
I. Sumb
II. Nud
III. Rajpura
IV.Ramgarh
V. Ghagwal
I.
Chanunta
II.
Chenani
III. Dudu
IV. Ghordhi
V. Jaganoo
VI. Khoon
VII. Kulwanta
VIII. Latti
17

<!-- page 19 -->

IX.
X.
XI.
XII.

Majalta
Moungri
Narsoo
Panchari
xrn. Parli Dhar
XN. Ramnagar
XV. Sewna
XVI.Tikkri

Districts wise Break up of Blocks in Zone A & B of Kashmir Division
SNo

1.

Districts

Anantnag

Zone A

I.
II.
III.

2

Bandipore

NIL

3

Baramulla

I.
II.

Anantnag
Bijibehara
Sagam

Baramulla
Tangmarg

ZoneB
I.
II.
III.
IV.
V.
VI.
VII.
VIII.
IX.
X.
XI.
XII.
XIII.

Achabal
Breng
Chattergul
Dachnipora
Hiller Shahabad
Khoveripora
Larnoo
Phalgam
Qazigund Partly
Shahabad
Shangus
Verinag
Vessu

I.
Aloosa
II.
Arin
III.
Baktoor
IV.
Bandipore
V.
Banokoot
VI.
Ganastan
VII.
Gurez
VIII. Hajin
IX.
Naidkhai
X.
Nowgam
XI.
Sumbal
XII.
Tulial
I.
Bijhama
II.
Boniyar
III.
ChandilW anigam
IV.
Hardaboora
V.
Kangroosa
VI.
Khaipora
vn. KhoreSherabad
VIII. Kunzer
18

<!-- page 20 -->

IX.

Lalpora

X.
XI.
XII.
XIII.
XIV.

4

Budgam

I. Budgam

5

Ganderbal

I.
II.

6

Kulgam

NIL

Ganderbal
Gund

Nadihal
Narwav
Noorkhah
Parenpillan
Pattan
xv. Rafiabad
XVI. Rohama
XVII. Sangrama
XVIII. Singhpora
XIX. Sopore
xx. Tujjar Sharief
XXI. Uri
XXII. Wagoora
XXIII. Wailoo
XXIV. Zaingeer
I.
B.K.Pora
II.
Beerwah
III.
Chadoora
IV.
Charisharief
Khag
V.
VI.
Khan-Sahib
VII.
Nagam
VIII.
Narbal
IX.
Pakherpora
X.
Pamewa
XI.
Rathsun
XII.
S.K. Pora
XIII.
Soibugh
)(JV.
Sukhnag (Hard Panzoo)
Surasyar
xv.
Waterhail
~I.
Kangan
I.
II.
Lar
III.
Safapora
IV.
Sherpathr
V.
Wakura
Behibagh
I.
II.
D.H.Pora
D.K.Marg
III.
IV.
Devsar
V.
Frisal
VI.
Kulgam
VII.
Kund
~
19

<!-- page 21 -->

VIII.
IX.
X.

7

Kupwara

NIL

Pulwama

I.
II.

Shopian

NIL

8

9

Pulwama
Pampore

Menzgam
Pahloo

Pombay
XI.
Quamoh
I.
Drugmulla
II.
Handwara
Ill.
Herri Qadirabad
IV.
Hyhama
V.
Kalarooch
VI.
Keran
VII.
Kralpora
VIII. Kuligam
IX.
Kupwara
X.
Lalpora
XI.
Langate
XII.
Machil
XIII. Magam
XIV. Mawar
xv. Qalamabad
XVI. Meelyaal
XVII. Natnussa
XVIII. Qaziabad
XIX. Rajwar
xx. Ramhal
XXI. Reddi Chowkibal
XXII. Sogam
XXIII. Tangdar
XXIV. Teethwal
XXV. Trathpora
XXVI. Trehgam
XXVII. Wavoora
I.
Arpal
II.
Awantipora
III.
Dadsura
IV.
Kakapora
V.
Keller
VI.
Litter
VII. Newa
VIII. Shadimarg
IX.
Tral
I.
Chitrigam
II.
Herman
III.
Imamsahib
IV.
Kanji Ullar
20

<!-- page 22 -->

10

Srinagar

V.
VI.
VII.
VIII.
IX.

Kaprin
Keller
Ramnagri
Shopian
Zainpora

I.

Srinagar

I.

Harwan

II.

Eidgah
Hazratbal
Qamarwari

II.

Khonmoh

m.
IV.

Note: Municipal Committees shall form part of the nearest Block.

21

<!-- page 23 -->

AnnexureIV
A-ELIGIBLE PLANT & MACHINERY OF MANUFACTURING SECTOR
The core components of Plant and machinery for manufacturing industry will include the
cost of mother production equipment essential for carrying out manufacturing activities
and will be eligible for availing incentives.
11. Non-Core Components are those which will not be eligible to avail any incentives under
this scheme. Following items are covered under non-core category:
a) Loading and unloading charges.
b) Sheds/ buildings for Plant & Machinery.
c) Miscellaneous fixed assets such as DG sets, Excavation/ Mining equipment, handling
equipment excluding EOT cranes, electrical components
d) Working Capital including Raw Material and other consumable stores.
e) Commissioning cost.
f) Captive Power Plants except solar power plants for captive use.
g) Storage equipment.
h) Weigh bridge, Laboratory testing equipment.
i) DG Set
1.

B-

CORE COMPONENTS OF BUILDING AND EQUIPMENT FOR SERVICE
INDUSTRY

The core components of Building & Other Durable Physical Assets for service industry will
include the cost of construction of building and other durable physical assets essential for
carrying out the service activities and will be eligible to avail incentives under this scheme.
The core components of Building and Equipment for service industry will include:
i. Cost of Building and other durable physical assets (excluding taxes and duties) which
are essential for carrying out Service activities.
11. Cost of durable assets will include fittings, fixtures and fixed assets that are needed to
render Service (e.g. HVAC system, Cooling Towers, Sewage Treatment Plant, etc.)
111. Electrical components necessary for plant operation on the plant side from where
meter is installed up to the equipment point (i.e. H.T. Motors, L.T. Motors, Switch
Boards, Panel Boards, Switchgears).
1v. Captive Solar Plant/Panels for utilization of the generated power within the unit shall
be considered as Core component under Plant & Machinery, if no incentive has been
availed under any other scheme of the government.
v. New building

22

<!-- page 24 -->

C.

NON-CORE COMPONENTS OF BUILDING AND EQUIPMENT FOR SERVICE
INDUSTRY

The non-core components of service industry are those which will not be eligible to avail
incentives under this scheme. This will include cost of Land, consumables, disposables or any
other item charged to revenue.
D. ILLUSTRATIVE LIST OF BUILDING AND EQUIPMENT FOR SERVICE
INDUSTRY
I. Building & Equipment for Tourism & Hospitality Services
1.

In case of hotels, resorts, eco-resorts and wellness resorts, the investment in
following fixed durable assets shall be considered:
1. Filtration plant for swimming pool.
2. Water purification plant.
3. Hot water boiler and room heating equipment (fixed)
4. Water softening plant
5. Fume extraction and ventilation plant.
6. Air conditioning plant.
7. Cold Storage equipment.
8. Laundry equipment.
9. Cooler and refrigeration equipment.
10. Bakery equipment
11. Sewage disposal plant
12. Electrical installations
13. Tents for camping
14. Kitchen equipment, cooking range, dish washer, working table.
15. Fire- fighting equipment (fixed)
16. Telephone equipment/exchange.
17. Lifts and escalators
18. Safe deposit lockers
19. Tube wells along with pumping sets and lines within the campus
20. Goods carrier exclusively needed for the hotel.
21. Projectors and other equipment's for conference hall (fixed).
22. Lighting equipment.
23. Adventure and water sports equipments.
ii.
In the case of Houseboats, the entire houseboat project along with its fitting
and furnishing should be treated as building and physical durable assets.

23

<!-- page 25 -->

Annexure V
ELIGIBLE
SECTOR

BUILDING AND

PHYSICAL

DURABLE ASSETS

OF SERVICE

A. Eligible Units under the respective Service Sectors' head
1. Tourism & Hospitality Services (including health & wellness tourism)

i.

11.

iii.

All units in the tourism and hospitality sector registered with Tourism
department excluding
a.
Homestays/ Bread and Breakfast
b.
Transport services not being used for tourism related activities
All such units will have to avail requisite licenses of registration from the
relevant competent authority for running the commercial operations of
Tourism & Hospitality Services.
Tourism & Hospitality Services will include all the services meant to cater
functions, Meetings, Incentives, Conferences & Exhibitions.

2. Promoting Film Tourism (including film cities, studios)
i. All units promoting film tourism registered with Tourism department and
Department of Information and Public Relations.
ii. All such units will have to avail requisite licenses of registration from the relevant
competent authority for running the commercial operations
iii. Promotion of Film Tourism will include renting of equipment for film shooting
iv. Promotion of Film Tourism will include Theaters, Cineplex, Single Screen
theatres, Multiplexes
3. Ropeways, Entertainment Parks and Rides
i. All units in the Ropeways, Entertainment Parks and Rides must be registered with
Tourism Department
11.

All such units will have to avail requisite licenses of registration from the relevant
competent authority for running the commercial operations of Ropeways,
Entertainment Parks and Rides.

iii. Ropeways, Entertainment Parks and Rides must be used for promotion of tourism
for public and commercial use only.
4. Heritage Property Restoration Services
i. All units arising out ofrestoration of heritage property recognized/ defined as
under:
a. Monuments notified under ASI
b. Monuments notified by the State Government under Ancient Monuments
Preservation (Amendment) Act, 2010.
c. Heritage sites notified under The Jammu & Kashmir Heritage Conservation and
Preservation Act, 2010.
d. Heritage Monuments that are under the management of different religious
Trusts such as WaqfBoard, Gurdwara, temple trust etc.
24

<!-- page 26 -->

e. Heritage Monuments listed by recognized Agencies such as UNESCO,
INTACH (Indian National Trust for Art and Cultural Heritage) etc.
ii. The heritage building so restored and being utilized for commercial purposes shall
be entitled to avail benefits applicable to new units.
iii. Core components of Heritage Property Restoration Services will only cover civil/
construction works of the heritage property involved.
iv. All such units will have to avail requisite licenses of registration from the
relevant competent authority for running the commercial operations
5. Healthcare Services

i.
All units in the Healthcare Services registered with Health department
excluding
a.
Clinics with only OPD facility
b.
Chemist Shops
c.
Canteens
d.
Gymnasium
e.
Hospitals & Clinics with less than 25 beds
11.
All such units will have to avail requisite licenses of registration from the
relevant competent authority for running the commercial operations of
Healthcare services.
111.
Healthcare Services must directly be linked to the healthcare of the patients.
iv. Healthcare Services will include Hospitals, Diagnostic Labs, AYUSH Centres.
6. IT & ITeS Services
i.
All units in the IT &ITeS Services must be registered with Concerned DIC.
ii.
IT & ITeS Services must include all services which require use of computers
to offer IT/ITeS related services only.
7. Maintenance and Repair Services
i.
All units in the Maintenance and Repair Services registered with concerned
DIC excluding.
a. Sale/ Trading of goods in the premises.
11.
Must include purely servicing and maintenance activities and excludes sale of
goods.
8. Freight Terminals, Logistics Parks & Warehousing (including Cold Store
Services)
i.
All units in the Freight Terminals, Logistics Parks & Warehousing must be
registered with concerned DIC.
11.
All such units will have to avail licenses of registration from the relevant
competent authority for running the commercial operations of Freight
Terminals, Logistics Parks & Warehousing.
~
25

<!-- page 27 -->

iii.

9.

Freight Terminals, Logistics Parks & Warehousing shall also include CA
stores.

Testing, R&D, Analysis & Certification services
i.
All units in the Testing, R&D, Analysis & Certification services must be
registered with concerned DIC.
11.
All such units will have to avail licenses of registration from the relevant
competent authority for running the commercial operations of Testing, R&D,
Analysis & Certification services .

10. Educational & Skill Development Services
i.
All units in the Educational & Skill Development Services registered with
concerned Education Department excluding
a.
Coaching Centres
b.
Tuition Centres
c.
Schools /Colleges (Arts and Science)
11.
All such units will have to avail licenses of registration from the relevant
competent authority for running the commercial operations of Educational &
Skill Development Services.
111.
All such Educational & Skill Development Services which are affiliated with
National/ State Board.

26
