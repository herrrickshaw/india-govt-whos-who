---
doc_id: "fad054a0aff87fd8"
source_url: "https://www.bhaderwahcampus.in/BCAadmission/admission2026.pdf"
ministry: "Bhaderwah Campus, University of Jammu, Jammu and Kashmir"
title: "Admission Notification 2026-27.     Dated: 11. 05. 2026"
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "3be1185f3eb1e1a7"
---

<!-- page 1 -->

BADERWAH CAMPUS, UNIVERSITY OF JAMMU
ADMISSION NOTIFICATION — UG & FIVE-YEAR INTEGRATED UG-PG PROGRAMMES (NEP-2020)
ACADEMIC SESSION 2026-27
Applications are hereby invited from eligible candidates for Online/Offline registration to various Undergraduate
(UG) and Five-Year Integrated UG-PG Programmes offered at Bhaderwah Campus, University of Jammu for the
Academic Session 2026-27.
ADMISSION TIMELINE PROGRAMMES OFFERED
Undergraduate (UG) Programmes
‏(6لا) 88۸ ٭‎
1. Commencement of * BCA(UG)
5 ti 11 May 2026
Registration ۲ * B.Com (UG)
# Laat Date the Registration alae Five-Year Integrated UG-PG Programmes leading to
P.G Program in following subjects
3. Issuance of First Admission '
List 25 May 2026 ۰ Sociology
* Economics
* Geography
MODE OF REGISTRATION ‏یلست و‎
Online: Visit www.bhaderwahcampus.in 1 ‏ات‎ 150० ۷
Offline: Visit the office of the Academic Coordinator, ‏ےہ سا اہ‎ ( )
۰ 5٥39611601 ‏2۸ذ۲80/‎
‎Bhaderwah Campus. :
* Computer Science
* Education
ELIGIBILITY CRITERIA
* 10+2 with 50% Marks (General) | 10+2 with 45% Marks for SC/ST candidates
* 50% seats reserved for JUET (30% JUET Score + 70% Academic Merit)
* 50% seats reserved for 10+2 Merit
HOW TO APPLY DOCUMENTS REQUIRED CONTACT INFORMATION
7006217471 Office of the Academic
Coordinator
1 ; 6005777304 I/C Head, Dept of
Candidates may register through: + 40th Marks Card ‏میا فا‎ 0۲|
: ‏ا‎ ۱ * 12th Marks Card 8825081793 I/C Head, Dept of CS & IT
8ٰ 7871 * Aadhaar Card 7006597225 I/C Head, Dept of English
+ Offline Mode: Visit the office of the rtifi if
an icc 1 * Category Certificate (if any) 8825030700 I/C Head, Dept of
cademic Coordinator, Bhaderwah + Passport Se Photoaranhe Economics
Campus. eS grap 7006555081 1/C Head, Dept of
Geography
7006018669 ERO, Bhaderwah Campus
12225 ‏7ج‎
‎हि \ 0 S For Details Visit No. BC/JU/ACD/2026/74
2 एलप शा ae \ www.bhaderwahcampus.in Date. 11/05/2026
Bhaderwah Campus, University of .
Jammu
