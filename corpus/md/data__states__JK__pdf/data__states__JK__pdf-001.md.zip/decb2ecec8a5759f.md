---
doc_id: "decb2ecec8a5759f"
source_url: "https://cdn.s3waas.gov.in/s3884d247c6f65a96a7da4d1105d584ddd/uploads/2020/05/2020081094.pdf"
ministry: "Baramulla"
title: "Order CrPC144-Dated- 08-08-2020"
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "7dde8b7d77dcc129"
---

<!-- page 1 -->

yf
۱ 6۵
‏و‎ GOVT OF JAMMU AND KASHMIR
2) Office of the District Magistrate Baramulla
1 No: 0087 30220 20
४ 00-08-2020
SubjectCOVID-19 containment _measures-casing of restrictions in District
ORDER

In partial modification of this office order No. 09/DMB(PS) of 2020 dated
03-08-2020 the following relaxation in restrictions in District Baramulla shall be
from 10-08-2020 to 13-08-2020:-

_ 1. All shops/ business establishments in the District including main towns of
Baramulla, Sopore, Pattan, Kunzer, Tangmarg, Kreeri, Wagoora, Uri,
Watergam, Rohama and Dangiwacha shall remain open on odd/even
formula basis and as per the SOPs SOPs issued vide this office order No.
DMB/Covid19/2300-2311 dated 20-06-2020 and guidelines issued from time
to time.

2. There shall be complete restrictions on movement of public transport
including Sumo, Taveeras, passenger vans etc and only authorized private
vehicles, vehicles carrying essential goods and construction material for ‏ا‎
‎Government works shall be allowed to move within the District and SRTC
buses designated on routes shall ply as per the orders issued by Transport
Commissioner.

3. Sr. Superintendent of Police Baramulla/ Sopore, concerned SDMs,
Tehsildars/ Naib Tehsildars (Executive Magistrate 1 Class)/ Duty
Magistrates, SDPOs and SHOs shall ensure strict implementation of SOPs. _

>
‏سی‎ ۳
District Magistrate, f
Baramulla.
Copy to the:-
1. Chief Secretary J&K Srinagar for information.
2. Divisional Commissioner, Kashmir information.
3. Sr. Superintendent of Police Baramulla/ Sopore... '
4. Addl. Deputy Commissioner Sopore... ۱ i
5. Sub Divisional Magistrate Uri/ Pattan/ Gulmarg... :
6. All Tehsildars of Baramulla District... ४
‏سسی‎ 10 10۸٥۸۵18100 ‏0ص۵‎ 089 |
۲
|
Scanned vith Camscamer
