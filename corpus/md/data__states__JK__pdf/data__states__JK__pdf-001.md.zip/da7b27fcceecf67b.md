---
doc_id: "da7b27fcceecf67b"
source_url: "https://smvdu.ac.in/wp-content/uploads/2025/06/Reconstitution-of-ICC-2025_compressed.pdf"
ministry: "Shri Mata Vaishno Devi University, Katra, Jammu and Kashmir"
title: "Notification of ICC – 2025"
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "6d1f556a812d649e"
---

<!-- page 1 -->

0 श्री माता वैष्णो देवी विश्वविद्यालय
: ۰ SHRI MATA VAISHNO DEVI UNIVERSITY
i Kakryal, Katra-182320, Jammu & Kashmir
Recognized under Section 2(f) & 12(B) of the UGC Act, 1956
विज्ञान बडा registrar@smvdu.ac.in
Ref. No.: SMVDU/AA/25//2-2-4 Date: 05 [05 | 05 , 5
NOTIFICATION
Subject: Re-Constitution of Internal Complaint Committee (ICC) of SMVDU.
Ref: Notification issued vide no. SMVDU/AA/24/122, dated: 30" April, 2024.
As proposed by the Presiding Officer, ICC and as approved by the Competent Authority,
the Internal Complaint Committee (ICC) of SMVDU is hereby reconstituted as under:
Presiding Officer
1. Dr. Kakali Majumdar, Professor, SoE
Two Faculty Members
2. Dr. Rajeev Kumar, Assistant Professor, SOME
3. Dr. Archana Purwar, Associate Professor, SOCSE
Two Non Teaching Employees
4. Mr. Rajesh Sharma, Dy. Registrar, R&D Wing
5, Mrs. Ritu Sharma, Office Assistant, Establishment Wing
Three Student Members
6. Ms. Tanya Sharma, Entry No. 22BME024
7. Mr. Akshay Raj, Entry No. 23BME004
8. Ms. Suyasha Andotra, Entry No. 23BEC060
Member from amongst non-government organizations or associations or a person associations or a person
familiar with the issues committed to the cause of women of women
9. Advocate Kiran Thakur
The term of office of the members of the ICC shall be for a period of three years from the
date of their nomination to the Committee. The one-third of the members of ICC may
change every year.
This issues with the approval of the Competent Authority. (2
Registrar
Copy to:
1. All Deans/ HoD’s/ Section Heads, for information and circulation among all faculty
members, staff members & students.
2. All concerned, for information.
3. AR (VC Office), for kind information of the Hon'ble Vice Chancellor.
4. |/c Website, for information and uploading of same on the University Website.
5. Concerned File.
