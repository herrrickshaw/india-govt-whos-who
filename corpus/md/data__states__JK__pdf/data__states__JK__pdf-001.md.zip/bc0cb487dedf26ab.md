---
doc_id: "bc0cb487dedf26ab"
source_url: "https://www.kashmiruniversity.net/events/11190.pdf"
ministry: "University of Kashmir, Jammu and Kashmir"
title: "Notification regarding Interviews for Apprentice Engagement (2026–27); Dated:  30-10-2026"
date: ""
pages: 1
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "89275aceb775429d"
---

<!-- page 1 -->

CG Office of the Dean, School of Engineering
५. ‏پا‎
‎* एड ay University Gnesi
3 Cx, . University of Kashmir, Srinagar
कर SS (OOAAC Accredited Grade-A**)
Srinagar-190006 ISLK (India)
Interview Notice
Engagement of Apprentices for the Year 2026-27
(Under Apprentices (Amendment) Act, 1973)
In continuation of the Re-Advertisement notice issued for engagement of gh Soper for the year 2026-
27 vide notification No.F(Re-Advertisement-Apprentice)loT/KU/26 dated 19™ of October 2026 under the
provisions of the Apprentices (Amendment) Act, 1973. ‘All eligible candidates who have applied for
‘Apprenticeship through the NATS portal and have submitted hard copies of their application forms are
informed that their interviews shall be held on 02.11.2026 at 10:30 AM in the Office Chamber of the
Dean, School of Engineering, Institute of Technology, Zakura Campus.
Instructions to Candidates:
1 Candidates shall bring the following documents in original along with one set of self-attested Xerox
copy:
a. Degree Certificates and Marks Sheets of qualifying examinations.
b. Date of Birth Certificate
c. Category Certificate (if applicable).
d. Valid Government issued Photo Identity Proof (Aadhar Card).
2. Candidates must report at least 30 minutes before the scheduled time.
3. No TA/DA shall be admissible for appearing in the interview.
4. Mere appearance in the interview shall not entitle a candidate to engagement. The final selection shall
be strictly on merit and in accordance with the Apprentices (Amendment) Act, 1973.
5, Candidates who have undergone apprentice training are not eligible.
Dean, ‏ک2ا‎
‎Universpy of
‘No (lterviow Schedule-ApprenticeoT/KU26
Dated: 29.10.2026 ol ye Wide
ale
