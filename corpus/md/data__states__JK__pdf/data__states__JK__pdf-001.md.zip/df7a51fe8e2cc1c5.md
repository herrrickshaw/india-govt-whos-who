---
doc_id: "df7a51fe8e2cc1c5"
source_url: "https://cdn.s3waas.gov.in/s384117275be999ff55a987b9381e01f96/uploads/2025/01/2025010823-1.pdf"
ministry: "Divisional Commissioner Jammu, Jammu and Kashmir"
title: "Physical Progress report of Bunkers in respect of Border Districts of Jammu Division As on 30.06.2021"
date: ""
pages: 2
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "f805087e0bb01f49"
---

<!-- page 1 -->

4 ec
Union Territory of Jammu & Kashmir.
Office of the Divisional Commissioner, Jammu
(Rail Head Complex, Jammu).
(0191-2478991, 2478999, Fax-2478997, e-mail: divcomjammu@gmail.com)

Principal Secretary to the Govt.
Home Department,
J&K Civil Secretariat, Srinagar’
No: 902/Divcom/P&S/96-Bunkers/ 2) 62~ 2/!% Dated: July_ i> 2021.
Subject: Physical Progress Report of Bunkers in respect of Border

Districts of Jammu Division as on 30° of June, 2021.
Sir,

On the apropos subject, | am directed to submit the physical progress
for construction of Bunkers in Border Districtgof Jammu Division for the month
of June, 2021 as received from respective District Development
Commissionsers of border Districts of Jammu Division for favour of kind
information please.

Yours faithfully, हे
۰
‏کی‎ Encl 0 leaype.
we ; Nas
Deputy Director,
Oe Divisional Commissioner,
: ‏ت۹‎ . Jammu
CC for information to the: aN VA ३
1) Deputy Commissioner, Jammu a
2) Deputy Commissioner, Kathua.
3) Deputy Commissioner, Samba.
4) Deputy Commissioner, Rajouri.
5) Deputy Commissioner, Poonch.

<!-- page 2 -->

2 |
2
|
| ‏ے‎
‎2
‎हे ढ a| 8. हे
ale ia 8. 2ٰ a| § i 3|
ae 3 है 5 s s छः 9
‏کت ڑج ہج‎ S © s ‏ج8‎ 2 3 ;
ؤ٤٦‎ = 5 = g
‏ہا تج‎ || = = = हे ٍ
9. | 0 =] 2 7 ,
° 2 3 g
516 हि 2 JI
* हे डे = 2 2|
816 = 2 ‏پا ا 8 اج اجاۓے‎ ۴
‏تس‎ = = Is x/ 3 g| g iE
ie 2| 2 ‏ھ2‎ da
5 ®
8 ‏6ہ کے‎ o 33
BIS ‏ا اون ےر ہہ‎
280 ‏3و8‎ a|2 a §
& ۵ :
= 2 |& SES 3/5 g| 2 |
= Z|
: &
=
۶
9
= iS 3
= “ Ji
ND = 2 A:
2 8 . 2
: 7 : हा ‏وت‎
‎o li
‏اآغ‎
‎=| 9
‏اچ‎ a
2 5
g| 2
=
‏یی‎ ھ٤‎ 5
8 & 3 Nl @
‏اد ]ھا ھ‎ 88 = Hi
51816 ile
2 fi
8६1५
Ele
3| 8
w
3
= डे ले हर *
mtn : s
e
| 5
‏ہے‎
‎5
‎۱ . न « :
- 2 ‏اج اس‎ a : 8 न ४
& जि 1 1 8 8 g :
31 ० |
S| = |
a
=|
oO] 3
| छठे = ni] ow 9) &
९७ ‏ہے ٭٥ه|س ىآ ۔‎ ala gi 8
3 R/S si gle ele ii
a ols
5 |
|
=
=k aioe ia |
= 2
= ‏واج با ڈ اق‎ 2| ٤2
3 & 8) 2/8 8 :
= s 8
