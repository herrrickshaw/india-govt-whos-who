---
doc_id: "eab5273dcdaf05d9"
source_url: "https://cdn.s3waas.gov.in/s3ae0eb3eed39d2bcef4622b2499a05fe6/uploads/2020/08/2020081099.pdf"
ministry: "Ramban"
title: "All Orders Related to Restriction Under Section 144"
date: ""
pages: 29
method: "tesseract:eng+urd+hin"
script: "LATIN"
needs_ocr: false
sha1: "cd3162372efff808"
---

<!-- page 1 -->

f= OF JAMMU 8 ८ TEE
५ CE OF CHAIRPERSON DISTRICT DISASTER MANAGEMENT OMMI
(DISTRICT MAGISTRATE) RAMBAN
‏سس ے س سرت >> .ٹس‎
‏سے‎ 01998-266906, 266789 89
all: deramban-|k@nic.in Fax/Ph. 01998-266 06, 2667
sub: COVID-19 Management-Restrictions thereof. 0 ‏وت‎
‎٠
‎Ref: Govt Order No:61-JK(DMRRR) of 2020 dated: 07.06.2020 Q J ४ (८22
ol Go 9
ORDER No:DCR/COVID-19/1920-31 4) ‏جا‎ oO
۰
Dated: 08.06.2020 Mba
1 Whereas, COVID-19 has been declared as global pandemic by World Health Organization (WHO)
affecting several Countries of the world including India;
Whereas, the advisories issued by the Health Authorities to prevent the spread of (०५४०-19
pandemic and break the transmission chain of the virus, it is necessary to enforce certain
restrictions in order to control the spread of the virus in the District;
Whereas, the Novel Corona virus (COVID-19) has an alarming rate of spread and is considered
highly contagious thereby necessitating the enforcement of certain restrictions for maintaining,
social distancing among the masses in order to control the spread of virus in the District;
Now, therefore in view of the above mentioned facts and in the interest of safety and well being of
general public at large, | Nazim Zai Khan, KAS District Magistrate Ramban in exercise of the
powers vested in me under Section 144 Cr.PC, Section 34 of National Disaster Management Act,
2005 and in accordance with Section 2 of the Epidemic Diseases Act, 1897 do hereby order to
impose following restrictions within the territorial limits of District Ramban with immediate effect;

1- No person shall venture out of his home and shall leave their home only in case of urgency.
However, in no case more than three or more persons shall assemble at any public place in
the towns/villages of the District.

2- All the establishment except those providing essential commodities/Services having valid
pass from the competent authority as notified Vide Govt Order No: 60-FCS&CA of 2020
dated: 02.03.2020 shall remain shut down from 01.06.2020 to 08.06.2020

3- No movement across Mohallas/Town shall be allowed for purchase of essential
commodities and all have to endeavor for getting essential commodities from the nearby

५ ‏پ و‎ in the locality/Mohala strictly adhering to social distance norms.

: Ne ‏ا‎ movement, assembly, gathering or procession of any nature including
religious, social, political or ritualistic involving three or more than three persons shall be

५ ‏لس‎ the District Including towns and villages.

- No public or private transport shall ply in the District ex ٠

cept 5
items from 08.06.2020 till further orders only with Ere ‏6ا‎ carrying essential
office. Proper permits/passes issued by this

6- Further any order(s) Issued with rega
2 gard to declara
Zones and restrictions thereof shall remain In corn a Contalnment/Red Zones/buffer
area: ce In the areas envisaged in the respective
WL
Scanned with CamScanner

<!-- page 2 -->

‎these instructions shall not apply to Govt vehicles, ambulances and Govt staff‏ سر
‎Ived in the efforts against COVID-19 and staff of essential emergency services with due‏
‎asses/ identity Cards.‏
‎provided that the above order shall not apply to Police or Paramilitary persons oF any other‏
‎Govt Servants on official duties for management of essential services with proper \D/Passes.‏
‎This order shall remain in-force from 08.06.2020 till further orders.‏
‎In view of the emergent nature of the order, it is being passed ex-parte and addressed to‏
‎the public in general. It shall be circulated in print, electronic, social media and through the‏
‎medium of loud speakers for information of all concerned.‏
‎Any violation of this order shall invite action under Indian Penal Code/Disaster Management‏
‎Act, 2005 and Epidemic Diseases Act, 1897‏
‎Issued under my seal and signature today on 08.06.2020 aS‏
‎Nae‏ )@
میا 8 ‎कं‏
‎Nazim@g AS)‏ می ,£ ‎५‏
‎ते Chairperson‏ :4 9
‎BS /८ District Disaster Management Committee‏ \*
. . . نہد
‎Om 7 | (District Magistrate)‏
‎“7७960 Ramban‏ *
‎Copy to the:-‏
‎Chief Secretary J&K for favour of information‏ .1
‎Divisional Commissioner, Jammu for information.‏ .2
‎IGP, Jammu for favour of information‏ .3
‎Senior Superintendent of Police, Ramban for information and n/a‏ .4
‎Senior Superintendent of Police, Traf¥c Ramban for information and n/a‏ ,5
‎Additional District Magistrate Ramban for information and n/a‏ .6
‎Assistant Commissioner Revenue Ramban for information and n/a‏ .7
‎Sub-Divisional Magistrate, Gool/Banihal/Ramsoo for information and n/a‏ .8
‎Tehsildar, Ramban/Banihal/Gool/Ramsoo/Ukhral/Khari/Batote/Rajgarh for information é‏ .9
‎n/a‏
‎SHO, Ramban/Banihal/Ramsoo/Batote/Gool/Chanderkote/Dharamkund for information‏ .10
‎and n/a‏
‎District Information Officer, Ramban for information and n/a‏ .11
‎Office record.‏ .12
‎Scanned with CamScanner‏

<!-- page 3 -->

GOVERNMENT OF JAMMU & KASHMIR
OFFICE OF THE DISTRICT MAGISTRATE RAMBAN
3 Cll rate nO NE 5 ‏سے م__۔۔‎
Sub: Prohibition on movements -imposition of Restriction - thereof
ORDER

Whereas, COVID-19 has been declared as global pandemic by World Health Organization
(WHO) affecting several Countries of the world including India;

Whereas, Orders/instructions have been issued from time to time by this office with regard
to subject captioned above for checking the further transmission of virus and breaking of chain in
spreading;

Whereas, as per the advisories issued by the Health Authorities to prevent the spread of
COVID-19 pandemic and break the transmission chain of the virus, it is necessary to enforce certain
restrictions in order to control the spread of the virus in the District;

Whereas, one COVID-19 positive case has been detected hailing from Village Thopal of
Tehsil Batote and as such there is apprehension of community transmission of the Corona Virus.

Now, therefore, in continuation to this office Order No: DCR/COVID-19/1881-93 dated
19.05.2020 and in view of the above mentioned facts as well as in the interest of safety and well
being of genera! public at large, | Nazim Zai Khan, KAS District Magistrate, Ramban in exercise of
the powers vested in me under Section 144 Cr.PC , National Disaster Management Act,2005 and
Epidemic Diseases Act, 1897 do hereby order as follows:

1. That Villages Thopal of Tehsil Batote is declared as Containment/Red Zones
2. That the sursounding Villages of the aforesaid Villages are declared as Buffer Zones
3. There shall be no inward or outward movement of any person from Containment Zone and
people shall stay in their homes and there shall be complete lockdown in the Tehsil Banihal.
4. There shall be no vehicular movement in village Thopal of Batote except the vehicles carrying
essential commodities on Highway of Jammu Doda.
5. Assistant Commissioner Revenue Ramban and Tehsildar Batote shall ensure supply of
essential commodities as per laid down protocol to the people of the said villages.
6. Any person(s)/Group(s)/Institution(s) found violating directions contained herein this order
shall be booked under the provisions of relevant Act/rules/law
The Senior Superintendent of Police Ramban shall ensure the implementation of this
Order in letter and Spirit.
Issued today the 30 of May, 2020 under my seal and signature.
‏سے‎
‎1०: 00१/८0४०/19/ /<€ # ए- 5/ Mek ८ Ma) OS —_—
Dated: 30.05.2020 G ‏رس‎ NG. aati are
۶ ‏و‎ A ५
al ye ۵ 2
۵ ‏۸ا23 صنعدلہ ار کی‎ (KAS),
٠8ایس ‏رر‎ District Magistrate,
Copy to the: Sore Ramban
1. Chief Secretary J&K for favour of information
2. Divisional Commissioner, Jammu for favour of information.
3. IGP, Jammu for favour of information.
4. Senior Superintendent of Police, Ramban for information and n/a
5. Senior Superintendent of Police, Traffic Ramban for information and n/a
6. Additional District Magistrate Ramban for information
7-Tehsildar Batote for information and n/a
PoeGiitu Witll wd

<!-- page 4 -->

68 ch 8 Us |
‏کیہ‎ 2
‏ےڈ ری‎
bq
A ff GOVERNMENT OF JAMMU & KASHMIR OF JAMMU & KASHMIR ٣ ‏سر‎ ۶
OFFICE OF THE DISTRICT MAGISTRATE RAMBAN Namba

E-mail: deramban-ik@nicin pane 01008965506 कक deramban-jk@nic.in Fax/Ph. 01998-266906, 266789

Sub: COVID-19 Management-Restrictions thereof,

Ref: Govt Order No:55-JK(DMRRR) of 2020 dated: 19.05.2020

ORDER
Whereas, COVID-19 has been declared as global pandemic by World Health Organization (WHO)
affecting several Countries of the world including India;
Whereas, the advisories issued by the Health Authorities to prevent the spread of COVID-19
Pandemic and break the transmission chain of the virus, it is necessary to enforce certain
restrictions in order to control the spread of the virus in the District;
Whereas, the Novel Corona virus (COVID-19) has an alarming rate of spread and is considered
highly contagious thereby necessitating the enforcement of certain restrictions for maintaining
social distancing among the masses in order to control the spread of virus in the District;
Now, therefore in view of the above mentioned facts and in the interest of safety and well being of
general public at large, | Nazim Zai Khan, KAS District Magistrate Ramban in exercise of the
powers vested in me under Section 144 Cr.PC, Section 34 of National Disaster Management Act,
2005 and in accordance with Section 2 of the Epidemic Diseases Act, 1897 do hereby order to
impose following restrictions within the territorial limits of District Ramban with immediate effect;
1-_No person shall venture out of his home and shall leave their home only in case of urgency.
However, in no case more than three or more Persons shall assemble at any public place in
the towns/villages of the District.

2- All the establishment except those providing essential commodities/Services having valid
pass from the competent authority as notified Vide Govt Order No: 60-FCS&CA of 2020
dated: 02.03.2020 shall remain shut down from 20.05.2020 till further orders.

3- No movement across Mohallas/Town shall be allowed for purchase of essential
commodities and all have to endeavor for getting essential commodities from the nearby
shops in the locality/Mohala strictly adhering to social distance norms.

4- No public/Private movement, assembly, gathering or Procession of any nature including
religious, social, political or ritualistic involving three or more than three persons shall be
allowed in the District including towns and villages,

5- No public or private transport shall ply in the District except goods vehicle carrying essential
items from 20.05.2020 to till further orders with Proper permits/passes issued by this office,

6- Further any order(s) issued with regard to declaration of Containment/Red Zones/buffer
Zones and restrictions thereof shall remain in force in the areas envisaged in the respective
area..

PoGili~uw 108 wal

<!-- page 5 -->

\
However, these instructions shall not apply to Govt vehicles, ambulances and Govt staff
invoived in the efforts against COVID-19 and staff of essential emergency services with due
passes/ Identity Cards.
Provided that the above order shall not apply to Police or Paramilitary persons or any other
Govt Servants on official duties for management of essential services with proper ID/Passes.
This order shall remain in-force from 20.05.2020 till further orders.
In view of the emergent nature of the order, it is being passed ex-parte and addressed to
{ the public in general. It shall be circulated in print, electronic, social media and through the
j medium of loud speakers for information of all concerned.
Any violation of this order shail invite action under Indian Penal Code/Disaster Management
Act, 2005 and Epidemic Diseases Act, 1897
| Issued under my seal and signature today on 19.05.2020
No: DcR/CovID/19/JO8/ ~F PAGED, ‏سے‎
‏سس ار‎ Gis
Dated: 19.05.2020 ‏گی‎ हक
‏رب‎ ९2४९७ ९५७ ‏ا‎
‏س2 جس وڈ تمہ‎ :
‏7ت‎ Nazitfredi 1)) 1105(7
‏ےر سے۹‎ District Magistrate,
‏ا ہیں‎ Ramban
Copy to the:- ee
| 1. Chief Secretary J&K
2. Divisional Commissioner, Jammu for information.
3. IGP, Jammu.
1. Senior Superintendent of Police, Ramban.
2. Senior Superintendent of Police, Traffic Ramban.
4. Additional District Magistrate Ramban.
5. Assistant Commissioner Revenue Ramban.
6. Sub-Divisional Magistrate, Gool/Banihal/Ramsoo,
7. Tehsildar, Ramban/Banihal/Gool/Ramsoo/Ukhral/Khari/Batote/Rajgarh
8. SHO, Ramban/Banihal/Ramsoo/Batote/Gool/Chanderkote/Dharamkund
9. District Information Officer, Ramban
10. Office record.
P=2/2
TAMING Wit wal

<!-- page 6 -->

\)
x
@) 86 7
‏مکی چو ہر‎
pee ‏رر مس جممجشر سو‎ 00 0 0 ٢ 3
* है! AS ‏ھ5‎
‎GOVERNMENT OF JAMMU & KASHMIR ‏مین‎ ۰
OFFICE OF THE DISTRICT MAGISTRATE ۸۸ Sonn
‏صضفصڈے- -ٹ-ظ۸ظسسس‎ तन... ‏ہے‎
‎E-mail: deramban-jk@nic.in Fax/Ph. 01998-266906, 266789
Sub: COVID-19 Management-Restrictions thereof,
Ref: UT Government of J&K Order No: 53-JK(DMRRR) of 2020 Dated: 17.05.2020
ORDER
Whereas, COVID-19 has been declared as global pandemic by World Health Organization (WHO)
affecting several Countries of the world including India;
Whereas, the advisories issued by the Health Authorities to prevent the spread of COVID-19
pandemic and break the transmission chain of the virus, it is necessary to enforce certain
restrictions in order to control the spread of the virus in the District;
Whereas, the Novel Corona virus (COVID-19) has an alarming rate of spread and is considered
highly contagious thereby necessitating the enforcement of certain restrictions for maintaining
social distancing among the masses in order to control the spread of virus in the District;
Now, therefore in view of the above mentioned facts and in the interest of safety and well being of
general public at large, | Nazim Zai Khan, KAS District Magistrate Ramban in exercise of the
powers vested in me under Section 144 Cr.PC, Section 34 of National Disaster Management Act,
2005 and in accordance with Section 2 of the Epidemic Diseases Act, 1897 do hereby order to
impose following restrictions within the territorial limits of District Ramban with immediate effect;

1-_ No person shall venture out of his home and shall leave their home only in case of urgency.
However, in no case more than three or more persons shall assemble at any public place in
the towns/villages of the District.

2- All the establishment except those providing essential commodities/Services having valid
pass from the competent authority as notified Vide Govt Order No: 60-FCS&CA of 2020
dated: 02.03.2020 shall remain shut down for 18.05.2020 & 19.05.2020

3- No movement across Mohallas/Town shall be allowed for purchase of essential
commodities and all have to endeavor for getting essential commodities from the nearby
shops in the focality/Mohala strictly adhering to social distance norms.

4- No public/Private movement, assembly, gathering or procession of any nature including
religious, social, political or ritualistic involving three or more than three persons shall be
allowed in the District including towns and villages.

5- No public or private transport shall ply in the District except goods vehicle carrying essential
items w.e.f. 18.05.2020 till 19.05.2020 with proper permits/passes issued by this office.

6- Further any order(s) issued with regard to declaration of Containment/Red Zones/buffer
Zones and restrictions thereof shall remain in force in the areas envisaged in the respective
area..

ہے ہے ہے مم ےسےٹ ٹے ےس ےم تس یسررسٹشس شس

١س‎ P=1/2
TCAMUCH WItEE wall

<!-- page 7 -->

ا 0 و 0ل و ڈو کک 1> کک
‎٠‏
‏۹
‎However, these instructions shall not apply to Govt vehicles, ambulances and Govt staff‏
‎involved in the efforts against COVID-19 and staff of essential emergency services with due‏
‎passes/ Identity Cards.‏
‎Provided that the above Order shall not apply to Police or Paramilitary persons or any other‏
‎Govt Servants on official duties for management of essential services with proper ID/Passes,‏
‎This order shall remain in-force for 18.05.2020. & 19.05.2020‏
‎In view of the emergent nature of the order, it is being passed ex-parte and addressed to‏
‎the public in general, It shall be circulated in print, electronic, social media and through the‏
‎medium of loud speakers for information of all concerned.‏
‎Any violation of this order shall invite action under Indian Penal Code/Disaster Management‏
‎Act, 2005 and Epidemic Diseases Act, 1897‏
‎Issued under my seal and signature today on 17.05.2020‏
7ت ہیں
‎No: DCR/COVID/19/ / 7-60 -/ 7&0. > 7 7 ae‏
‎Dated: 17.05.2020 ۰ 7 ae NG aie‏
مر ۱ا0 یا :
‎Naditif2ai Khan (KAS),‏ 7 ر0 7
‎oa wad oA District Magistrate,‏
‎ey + Re Ramban‏ ‘
‎mt‏
‎Copy to the:- aa‏
‎Chief Secretary J&K‏ .1
‎Divisional Commissioner, Jammu for information.‏ .2
‎IGP, Jammu.‏ .3
‎Senior Superintendent of Police, Ramban.‏ .1
‎Senior Superintendent of Police, Traffic Ramban.‏ .2
‎Additional District Magistrate Ramban.‏ .4
‎Assistant Commissioner Revenue Ramban.‏ .5
‎Sub-Divisional Magistrate, Gool/Banihal/Ramsoo.‏ .6
‎Tehsildar, Ramban/Banihal/Gool/Ramsoo/Ukhral/Khari/Batote/Rajgarh‏ .7
‎SHO, Ramban/Banihal/Ramsoo/Batote/Gool/Chanderkote/Dharamkund‏ .8
‎District Information Officer, Ramban‏ .9
‎Office record.‏ .10
‎P=2/2‏
‎bikie eee “८ PLAICE Wit wal‏

<!-- page 8 -->

٢
GOVERNMENT OF JAMMU & KASHMIR |
Sub: Prohibition on movements -imposition of Restriction - thereof
ORDER
८ Whereas, COVID-19 has been declared as global pandemic by World Health Organization
(WHO) affecting several Countries of the world including India;

Whereas, Orders/instructions have been issued from time to time by this office with regard
to subject captioned above for checking the further transmission of virus and breaking of chain in
spreading;

Whereas, as per the advisories issued by the Health Authorities to prevent the spread of
COVID-19 pandemic and break the transmission chain of the virus, it is necessary to enforce certain
restrictions in order to control the spread of the virus in the District;

Now, therefore, in continuation to this office Order No: DCR/COVID-19/1041-46 dated
04.05.2020 and in view of the above mentioned facts as well as in the interest of safety and well
being of general public at large, | Nazim Zai Khan, KAS District Magistrate, Ramban in exercise of
the powers vested in me under Section 144 Cr.PC , National Disaster Management Act,2005 and
Epidemic Diseases Act, 1897 do hereby order as follows:

1. That Villages viz Gundtethar and Tethar of Tehsil Banihal are declared as Containment/Red
Zones

2. That the surrounding Villages of the aforesaid Villages are declared as Buffer Zones

3. There shall be no inward or outward movement of any person from Containment Zone and
people shall stay in their homes and there shall be complete lockdown in the Tehsil Banihal.

4. There shall be no vehicular movement in village Gund and Gund Tehtar Except the vehicles
carrying essential commodities on NH-44

5. SDM Banihal/Tehsildar Banihal/SHO Banihal shall ensure supply of essential commodities as
per laid down protocol to the people of the said villages

6. Any person(s)/Group(s)/Institution(s) found violating directions contained herein this order
shall be booked under the provisions of relevant Act/rules/law हु

The Senior Superintendent of Police Ramban shall ensure the implementation of this

Order in letter and Spirit.

Issued today the 16 of May, 2020 under my seal and signature.

No: pcr/covin/19/ /669—/6 8a 2 5 ‏ےیک‎
‎Dated: 16.05.2020 OY wx ۷۸
‘ ‏ا‎ 2 nazifR@an RAT thas),
a "is Le District Magistrate,
330 Ramban
Copy for information to the 2
1. Chief Secretary J&K
2, Divisional Commissioner, Jammu .
3. IGP, Jammu.
Copy for information and n/a to the:
1. Senior Superintendent of Police, Ramban.
2, Senior Supesintendent of Police, Traffic Ramban.
3. Additional District Magistrate Ramban,
4, Assistant Commissioner Revenue Ramban.
5, Sub-Divisional Magistrate, Gool/Banihal/Ramsoo.
6. Tehsildar,Ramban/Banihal/Gool/Ramsoo/Ukhral/Khari/Batote/Rajgarh
7, SHO,Ramban/Banihal/Ramsoo/Batote/Gool/Chanderkote/Dharamkund
8, District Information Officer, Ramban
9. Office record.
TeAMlicu wit wal

<!-- page 9 -->

A ۱
3 GOVERNMENT OF JAMMU & KASHMIR
8 OFFICE OF THE DISTRICT MAGISTRATE RAMBAN
Sub: Prohibition on movements from 7.00 PM to 7.00 AM-imposition of Curfew- thereof
ORDER
|

Whereas, COVID-19 has been declared as global pandemic by World Health Organization
(WHO) affecting several Countries of the world including India:

Whereas, as per the advisories issued by the Health Authorities to prevent the spread of
COVID-19 pandemic and break the transmission chain of the virus, it is necessary to enforce
certain restrictions in order to control the spread of the virus in the District.

Now, therefore in continuation to this office Order No: DCR/COVID-19/1041-46 dated:
04.05.2020 and in view of the above mentioned facts as well as in the interest of safety and well
being of general public at large, 1 Nazim Zai Khan, KAS District Magistrate Ramban in exercise of
the powers vested in me under Section 34 of National Disaster Management Act, 2005 and
Epidemic Diseases Act, 1897 do hereby impose Curfew under Section 144 of Criminal Procedure
Code in the territorial jurisdiction of District Ramban from 7.00 PM to 7.00 AM every day with
immediate effect till further orders.

The Senior Superintendent of Police Ramban shall ensure the implementation of this Order
in letter and Spirit.

Issued today the 4" of May, 2020 under my seal and signature.
. —_—_”
No: DcR/coviD/19/ J oF 7 - //O® G ists OE
Dated: 04.05.2020 AC (ig) T,
‘ss 0 Is 2~
= ‏ا تب‎ ५9
Q Sip a Nazim Zai Khan (KAS),
7 ‏ہج‎ 2 District Magistrate,
& --7 ite

Copy for information to the ‏دفو دفو 0ا‎

1. Chief Secretary J&K

2. Divisional Commissioner, Jammu for information.

3. IGP, Jammu.

Copy for information and n/a to the:

1. Senior Superintendent of Police, Ramban.

2. Senior Superintendent of Police, Traffic Ramban.

3. Additional District Magistrate Ramban.

4. Assistant Commissioner Revenue Ramban.

5. Sub-Divisional Magistrate, Gool/Banihal/Ramsoo.

6. Tehsildar,Ramban/Banihal/Gool/Ramsoo/Ukhral/Khari/Batote/Rajgarh

7. SHO,Ramban/Banihal/Ramsoo/Batote/Gool/Chanderkote/Dharamkund

8. District Information Officer, Ramban

9. Office record.

TLAMicu wiul wal

<!-- page 10 -->

GOVERNMENT OF JAMMU & KASHMIR
OFFICE OF THE DISTRICT MAGISTRATE RAMBAN
Ss E-mail: deramban-jk@nic.in Fax/Ph, 01998-266906, 266789
6 Mag?
Sub: COVID-19 Management. Restrictions thereof. ८९५ 2 SA
Ref: This Office Order No: DCR/COVID-10/212-27 Dated: 15.04.2020 [.2/ 2(7 ९१%
۴ 7
ORDER op a

Whereas, COVID-19 has been declared as global pandemic by World Health
Organization (WHO) affecting several Countries of the world including India:

Whereas, the advisories issued by the Health Authorities to prevent the
spread of COVID-19 pandemic and break the transmission chain of the virus, it is
necessary to enforce certain restrictions in order to control the spread of the virus
in the District.

Now, therefore in view of the above mentioned facts and in the interest of
safety and well being of general public at large. | Nazim Zai Khan, KAS District
Magistrate Ramban in exercise of the powers vested in me under Section 144
Cr.PC, Section 34 of National Disaster Management Act, 2005 and Epidemic
Diseases Act, 1897 do hereby order impose following restrictions within the
territorial limits of District Ramban with immediate effect;

1- No person shall venture out of his home and shall leave their home only in
case of urgency. However, in no case more than three or more persons shall
assemble at any public place in the towns/villages of the District.

2- All the establishment except those providing essential commodities/Services
having valid pass from the competent authority as notified Vide Govt Order
No: 60-FCS&CA of 2020 dated: 02.03.2020 shall remain shut down w.e.f
04.05.2020 till 17.05.2020.

3- No movement across Mohallas/Town shall be allowed for purchase of
essential commodities and all have to endeavor for getting essential
commodities from the nearby shops in the locality/Mohala strictly adhering
to social distance norms.

4- No public/Private movement, assembly, gathering or procession of any
nature including religious, social, political or ritualistic involving three or
more than three persons shall be allowed in the District including towns and
villages.

5- No public or private transport shall ply in the District except goods vehicle
carrying essential items w.e.f. 04.05.2020 till 17.05.2020 with proper
permits/passes issued by this office. :

However, these instructions shall not apply to Govt vehicles, ambulances
and Govt staff involved in the efforts against COVID-19 and staff of essential
emergency services with due passes/ Identity Cards.

TLCAMICA With wal
