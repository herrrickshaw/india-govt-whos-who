---
doc_id: "bda7a5b6b40de2e0"
source_url: "https://www.cujammu.ac.in/media/homepage/notifications/UNIV/280825_Adobe_Scan_Sep_19__2024__2__1567_1755062484.pdf"
ministry: "Central University of Jammu, Jammu and Kashmir"
title: "Constitution of Committee of Directorate of Physical Education, CU Jammu ..."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "00830e033f4329e8"
---

<!-- page 1 -->

Central University of Jammu
Rahya - Suchani (Bagla), District: Samba

181143. Jammu (J&K)

13 September, 2024

HOA: CUJIAdmin/War.Comm/2019/593

3rfegeHR0G/ Notification 76 I2024
Ref: CUJIAdmin/Var.Comm/2019/89 dated 21.01.2021

pleased to nominate
The Competent Authority is

following as office bearers for

to their own duties for
of Physical Education, in addition
whichever is earlier:
SI.
No
1.

Prof. Vandana Sharma

Director Physical Education (/C)
Assistant Director Physical

Education

Dr. Neerendra Kumar

Assistant Director Physical

Education

Dr. R. Sudhakar

Associate Professor, Department of CSIT

3.

Associate Professor, Department of NSS
Dr. Kiran

4

Assistant

Professor,

Department

Educational Studies

Sh. Jai BhawaniSingh
Assistant Professor, Department of PPPA

5

a period of twO years or till further

orders,

Name & Designation
Professor, Department of English

2.

Directorate

Assistant Director Physical Education
of

Assistant Director Physical Education

committee members (Director and
The services rendered by previous
on record.
are highly appreciated and placed

This issues with the approval of the

Assistant Directors)

Competent Authority

130924
(9t. (3) qIAT
SHCT: registrar@cujammu.ac.in
qT9: 91-8082197957
All Members
ufaferft
1

P.S. to HVC

2
3

Registrar Office
Finance Wing
