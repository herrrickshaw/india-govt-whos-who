---
doc_id: "b6d1a4af3fd02c5f"
source_url: "https://it.delhi.gov.in/sites/default/files/IT/circulars-orders/ilovepdf_merged_2_1.pdf"
ministry: "Information Technology Department, Delhi"
title: "Download"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1d784b224af6ae3f"
---

<!-- page 1 -->

G-19RR/2/2025-CCU-INFORMATION TECHNOLOGY DEPARTMENT

I/172818/2026

GOVERNMENT OF THE NCT OF DELHI
INFORMATION TECHNOLOGY DEPARTMENT
(CADRE CONTROL UNIT)
th
9 LEVEL, B-WING, DELHI SECRETARIAT, NEW DELHI-110002
__________________________________________________________________
No.G-19RR/2/2025-CCU-ITD/E-240452/
DATED:
CIRCULAR
It is brought to the notice of all the concerned Departments of GNCT of Delhi
that the notiﬁcation of Recruitment Rules, 2026 for the post of IT Assistant Grade
‘D’, Department of Information of Technology, Govt. of NCT of Delhi has been
published by the General Administrative Department, GNCT of Delhi in the Delhi
State Gazette (Extraordinary) vide Notiﬁcation No. F. No. G-19RR/2/2025-CCUITD/E-240452/5913 dated 16.07.2026 (copy enclosed).
This issues with the approval of the competent authority.

(Devendra Sharma)
Deputy Secretary (IT)
To,
All the ACSs/Pr. Secretaries/Secretaries/HoDs/
all Local Bodies/Boards/Commissions, Govt. of NCT of Delhi.
No. G-19RR/2/2025-CCU-ITD/E-240452/

DATED:

Copy for information to:
1. Joint Director/HOO, IT Department
2. PS to Secretary (IT), IT Department
3. PA to Special Secretary (IT), IT Department
4. Website in-charge to upload the circular on the website of IT Department.
5. Guard file.
(Devendra Sharma)
Deputy Secretary (IT)

<!-- page 2 -->

रजिस्ट्री सं. डी.एल.- 33002/99

REGD. No. D. L.-33002/99

भारत सरकार
GOVERNMENT OF INDIA

xxxGIDHxxx
एस.जी.-डी.एल.-अ.-27072026-274825
xxxGIDExxx
SG-DL-E-27072026-274825

असाधारण
EXTRAORDINARY

प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 196]

दिल्ली, बृहस्ट्पजतवार, िुलाई 16, 2026/आषाढ 25, 1948

[रा.रा.रा.क्षे.दि. सं. 122

No. 196]

DELHI, THURSDAY, JULY 16, 2026/ASHADHA 25, 1948

[N. C. T. D. No. 122

भाग IV
PART IV

राष्ट्रीय रािधानी राज्य क्षेत्र दिल्ली सरकार
GOVERNMENT OF THE NATIONAL CAPITAL TERRITORY OF DELHI

lwpuk izkS|ksfxdh foHkkx
अजधसूचना
दिल्ली, 16 िुलाई, 2026
फा. सं. th&19 HkrhZ fu;e@2@2025&lhlh;w&vkbZVhMh@bZ&240452
@5913-—x`g ea=ky;] Hkkjr ljdkj dh
fnukad 24 flracj] 1968 dh vf/klwpuk Qk0 la0 24@78@68 Mh,p ¼,l½ ds lkFk ifBr lafo/kku ds vuqPNsn 309 ds ijUrqd }kjk
iznÙk “kfDr;ksa dk iz;ksx djrs gq, rFkk fnukad 04-01-2007 dh vf/klwpuk Qk0 la0 12¼1½@2006@vkbZVhlh@125&31 ds }kjk vf/klwfpr vkbZVh
lgk;d xzsM ^Mh* ds in gsrq HkrhZ fu;eksa ds vf/kØe.k es]a ,sls vf/kØe.k ls iwoZ dh xbZ ;k foyksi dh tkus okyh ckrksa dks NksM+dj]
jk’Vªh; jkt/kkuh {ks= fnYyh ds mijkT;iky ,rn~}kjk lwpuk izkS|ksfxdh foHkkx] jk’Vªh; jkt/kkuh {ks= fnYyh ljdkj esa vkbZVh lgk;d
xzsM&^Mh* ds in dh fu;qfDr gsrq HkrhZ i)fr ,oa vko“;d ;ksX;rk dks fofu;fer djus ds fy, fuEufyf[kr fu;e cukrs gSa] vFkkZr%~ &

1- laf{kIr 'kh"kZd ,oa izkjaHk%&
¼i½ bu fu;e dks vkbZVh lgk;d xzsM ^Mh*] lwpuk izkS|ksfxdh foHkkx] jk’Vªh; jkt/kkuh {ks=
fnYyh ljdkj HkrhZ fu;ekoyh] 2026 dgk tk,A
¼ii) ;s fnYyh jkti= esa vius izdk'ku dh frfFk ls ykxw gksx
a As
2- vuqiz;ksx%&
;s fu;e bu fu;eksa ds lkFk layXu vuqlp
w h ds dkWye la0 1 esa fofufnZ’V inksa ds fy, ykxw gksx
a As
3- inksa dh la[;k] oxhZdj.k rFkk osru eSfVªDl esa Lrj%&
mDr inksa dh la[;k] mudk oxhZdj.k rFkk mlls layXu
osru eSfVªDl esa Lrj vuqlp
w h ds dkWye 2 ls 4 esa ;FkkfofufnZ"V gksaxAs
5466 DG/2026

(1)

<!-- page 3 -->

2

DELHI GAZETTE : EXTRAORDINARY

PART IV]

4 HkrhZ i)fr] vk;q lhek] vU; ;ksX;rk,a bR;kfn%&
mDr inksa dh HkrhZ i)fr] vk;q lhek] ;ksX;rk ,oa blls lacaf/kr
vU; ekeys mDr vuqlp
w h ds dkWye la0 5 ls 11 esa ;FkkfofufnZ"V gksx
a As
5- v;ksX;rk%&
,slk dksbZ Hkh O;fDr]
¼d½ tks fdlh O;fDr ds thfor ifr@iRuh ds gksrs gq, fookg djrk gS ;k fookg dk vuqca/k djrk gS] vFkok
¼[k½ tks ,d thfor ifr@iRuh ds gksrs gq, fdlh O;fDr ls fookg dj pqdk gS ;k fookg vuqca/k dj pqdk gS( og mDr
fdlh in ij fu;qfDr gsrq ik= ugha gksxkA
“krZ ;g gS fd ;fn lwpuk izkS|ksfxdh foHkkx larq’V gS fd ,slk fookg ,sls O;fDr ,oa fookg ds vU; i{kdkj ij ykxw
O;fDrxr dkuwu ds varxZr vuqer gS vkSj ,slk djus ds fy, vk/kkj gSa] rks og fdlh Hkh ,sls mEehnokj dks bl fofu;eu ds izorZu
dh NwV ns ldrk gSA
6- f'kfFky djus dh ' kfDr%&
tgka ljdkj dk ;g er gks fd ,slk djuk vko';d vFkok lehphu gS] rks og dkj.kksa dks
fyf[kr esa vfHkys[kc) djrs gq,] vkns'k }kjk O;fDr;ksa ds fdlh oxZ ;k Js.kh ds laca/k esa bu fu;e ds fdlh mica/k dks
NwV ns ldrh gSA
7- cpko%&
bu fu;e esa Hkkjr ljdkj }kjk bl lac/a k esa le;&le; ij tkjh fd, x, vkns'kksa ds vuqlkj vuqlfw pr
tkfr;ks]a vuqlfw pr tutkfr;ks]a vU; fiNM+k oxksa]Z HkwriwoZ lSfudksa rFkk vU; fo'ks"k oxksaZ ds O;fDr;ksa ds fy, micaf/kr fd,
tkus okys visf{kr vkj{k.k] vk;q&lhek esa NwV vkSj vU; fj;k;rksa ij dksbZ izHkko ugha iM+x
s kA
vuqyXud&I
jk’Vªh; jkt/kkuh {ks= fnYyh ljdkj esa 7osa lhihlh ds osrueku Lrj 6 ¼#i;s 35400&112400½ esa vkbZVh lgk;d xzsM ^Mh* ds in gsrq
HkrhZ fu;e
12-

inuke
inksa dh la[;k

%
%

vkbZVh lgk;d xzsM&^Mh*
35* ¼2026½
*blesa ifjorZu dk;ZHkkj ij fuHkZj
foHkkx dk uke
O;kikj ,oa dj foHkkx
izf'k{k.k ,oa rduhdh f'k{kk foHkkx
jktLo foHkkx
ifjogu foHkkx
dsna hz ; dkjkxkj
vFkZ'kkL= ,oa lkaf[;dh funs'kky;
LokLF; ,oa ifjokj dY;k.k foHkkx
jkstxkj funs'kky;
foRr ctV ¼lk0iz“kk0fo0½
f'k{kk foHkkx ,oa lac) dk;kZy;
[kkn~; vkiwfrZ ,oa miHkksDrk ekeys
eq[; fuokZpu dk;kZy;] pquko
iz/kku ys[kk dk;kZy;
yksd fuekZ.k foHkkx
Je foHkkx
fnYyh v/khuLFk lsok p;u cksMZ
fnYyh iqfyl
fon~;qr foHkkx rFkk lac) dk;kZy;
dqy

3-

oxhZdj.k

%

Lohd`r
la[;kcy
7
5
3
3
2
2
2
1
1
1
1
1
1
1
1
1
1
1
35

lkekU; dsUnzh; lsok] lewg&^[k*] vjktif=r] vfyfidh;

<!-- page 4 -->

[PART IV

45678-

910-

11-

12-

13-

3

DELHI GAZETTE : EXTRAORDINARY

is cSaM rFkk xzsM is@osrueku
% osru eSfVªDl esa Lrj&6 ¼#i;s 35400&112400@&½
D;k p;u in gS vFkok xSj p;u in
% p;u
lh/kh HkrhZ okys mEehnokjksa ds fy, vk;q
% ykxw ugha
lhek
lh/kh HkrhZ okys mEehnokjksa ls visf{kr% ykxw ugha
'kSf{kd rFkk vU; ;ksX;rk,Wa
D;k lh/kh HkrhZ okys mEehnokjksa ds fy,
% ykxw ugha
fu/kkZfjr 'kSf{kd ;ksX;rk ,oa vk;q lhek
inksUufr okys mEehnokjksa ij Hkh ykxw
gksxhA
ijhoh{kk dh vof/k] ;fn dksbZ gks
% nks o’kZ
HkrhZ dh i)fr lh/kh HkrhZ }kjk ;k
% 100 izfr'kr inksUufr }kjk
inksUufr }kjk ;k
izfrfu;qfDr@vkesyu
}kjk rFkk fofHkUu i)fr;ksa }kjk Hkjs tkus
okys fjDr inksa dk izfr'kr
;fn inksUufr @ izfrfu;qfDr @ vkesyu % inksUufr %
}kjk HkrhZ gksuh gks rks xzsM ftuls
xzsM essa Ng o’kksaZ dh fu;fer lsok lfgr osru eSfVªDl ds Lrj&5 ¼#i;s
29200&92300@&½ esa vkbZVh lgk;d xzsM ^ch* esa lsA
inksUufr@izfrfu;qfDr@ vkesyu fd;k
tkuk gS
Vhi%ftu dfu"B vf/kdkfj;ksa us viuh vgZd@ik=rk lsok iwjh dj yh
gS( os inksUufr ds fy, fopkj.kh; gSA muds ofj"B vf/kdkjh Hkh
inksUufr ds fy, fopkj.kh; gksx
a (s c'krZsa fd visf{kr vgZd@ik=rk lsok
,slh visf{kr vgZd@ik=rk lsok ls U;wu u gks] vk/ks ls vf/kd gks vFkok
nks ¼02½ o"kZ] buesa ls tks Hkh de gks rFkk mUgksaus vkxkeh mPp xzsM ij
inksUufr ds fy, viuh ifjoh{kk vof/k vius dfu"B vf/kdkfj;ksa ds
lkFk lQyrkiwod
Z iwjh dj yh gks]s ftUgksua s ,slh vgZd@ik=rk lsok
igys gh iwjh dj yh gSA
;fn dksbZ foHkkxh; inksUufr lfefr gks] % ^^lewg ^[k* foHkkxh; inksUufr lfefr ¼Mhihlh½@foHkkxh;
rks bldh lajpuk D;k gS\
LFkk;hdj.k lfefr ¼Mhlhlh½
1- iz/kku Lkfpo @lfpo ¼VhVhbZ½] jk"Vªh; jkt/kkuh {ks= fnYyh
ljdkj &
v/;{k
2- laCkaf/kr foHkkx ds iz'kklfud lfpo ¼vkbZVh½] jk"Vªh; jkt/kkuh
{ks= fnYyh ljdkj & lnL;
3- fo'ks’k@vij Lkfpo ¼LokLF; ,oa ifjokj dY;k.k½] jk"Vªh;
jkt/kkuh {ks= fnYyh ljdkj & lnL;
Vhi%;fn foHkkxh; inksUUkfr lfefr@foHkkxh; LFkk;hdj.k lfefr dk
vf/klwfpr v/;{k foHkkxh; inksUufr lfefr ds fdlh Hkh vU; lnL; ls
dfu’B gS] rks foHkkxh; inksUUkfr lfefr@foHkkxh; LFkk;hdj.k lfefr
dk ofj’Bre lnL; v/;{k ds :i esa dk;Z djsxkA**
os ifjfLFkfr;ka ftuesa HkrhZ ds fy, la?k % ^^la?k yksd lsok vk;ksx ls ijke'kZ fy;k tkuk vko';d ugha gSA**
yksd lsok vk;ksx dk ijke'kZ fy;k tkuk
gSA
राष्ट्रीय रािधानी क्षेत्र दिल्ली के उपराज्यपाल के
आिेि तथा उनके नाम पर
vkuUn dqekj frokjh] fo'ks’k Lkfpo ¼vkbZ0Vh0½

<!-- page 5 -->

4

DELHI GAZETTE : EXTRAORDINARY

PART IV]

INFORMATION TECHNOLOGY DEPARTMENT

NOTIFICATION
Delhi, the 16th July, 2026
F. No. G-19RR/2/2025-CCU-ITD/E-240452/5913.—In exercise of powers conferred by the proviso to
article 309 of the Constitution read with Govt. of India, Ministry of Home affairs Notification No. F.24/78/68 DH(S)
dated 24th September, 1968 and in supersession of the Recruitment Rules for the post of IT Assistant Grade
‘D’ notified vide No. F. 12 (1)/2006/ITC/125-31 dated 04.01.2007, except respects things done or omitted to be done
before such supersession, the Lt. Governor of National Capital Territory of Delhi, is pleased to make the following
rules regulating the method of recruitment and qualification necessary for appointment to the post of IT Assistant
Grade- ‘D’ in the Department of Information Technology, Govt. of National Capital Territory of Delhi namely:
1. Short title and commencement:—(i) These Rules may be called the IT Assistant Grade D’, Department
of Information Technology, Govt. of NCT of Delhi, Recruitment Rules 2026.
(ii) These shall come into force on the date of their publication in the Delhi Gazette.
2. Application: These rules shall apply to the posts specified in Column No. 1 of the Schedule annexed to
these rules.
3. Number of posts, classification and level in pay matrix: The number of said posts, their classification
and level in the pay matrix attached thereto shall be as specified in Column 2 to 4 of the schedule.

4. Method of recruitment, age limit, other qualification etc.: The method of recruitment, age limit,
qualification and other matters relating to the said post shall be as specified in Column No. 5 to 11 of the
said schedule.
5. Disqualifications: -No person
(a) Who has entered into or contracted marriage with a person having a spouse living; or
(b) Who having a spouse living, has entered into or contracted a marriage with any person shall be eligible
for appointment to any of the said posts.
Provided that the Department of Information Technology may, if satisfied that such marriage is permissible
under the personal law applicable to such persons and the other party to the marriage and that there are other grounds
for so doing, exempt any person from the operation of this regulation.
6. Power to relax: Where the Government is of the opinion that it is necessary or expedient so to do, it may,
by order, and for reasons to be recorded in writing, relax any of the provisions of these rules with respect
to any class or category of persons.
7. Saving: Nothing in these rules shall affect reservations, relaxation of age limit and other concessions
required to be provided for the Scheduled Castes, the Scheduled Tribes, Other Backward Classes, ExServicemen and other special categories of persons in accordance with orders issued by the Govt. of India
from time to time, in this regard.
ANNEXURE-I
Recruitment Rules for the post of IT Assistant Grade ‘D’ in the Pay Scale of Rs. 35400-112400 Level- 6 of 7th
CPC in the Govt. of NCT of Delhi
1.
2.

Name of Post
Number of Post

IT Assistant Grade ‘D’
35* (2026)
*Subject to variation dependent on workload"

Name of Department
Department of Trade &
Taxes Deptt.
Department of Training
and Technical Education
Revenue Department

Sanctioned Strength
7
5
3

<!-- page 6 -->

[PART IV

3.

Classification

4.
5.
6.
7.

Pay Band and Grade Pay/Pay Scale
Whether Selection Post or non-selection post
Age limit for direct recruits
Educational and other qualifications required for
direct recruits
Whether age and educational qualifications
prescribed for direct recruits will apply in the case
of promotees
Period of Probation, if any
Method of recruitment whether by direct
recruitment or be promotion or by
deputation/absorption and percentage of the
vacancies to be filled by various methods
In case of recruitment by promotion/ deputation/
absorption grades from which promotion/
deputation /absorption to be made

8.

9.
10.

11.

5

DELHI GAZETTE : EXTRAORDINARY
Transport Department

3

Central Jail
Dte. of Economics &
Statistics
Department of Health &
Family Welfare
Dte. of Employment
Finance Budget (GAD)
Education Department and
Allied Offices
Food Supplies &
Consumer Affairs
Chief Electoral Office
Election
Principal Account Office
Public Work Department
Labour Department
DSSSB
Delhi Police
Power Department and
Allied Offices
TOTAL

2
2
2
1
1
1
1
1
1
1
1
1
1
1
35

General Central Service Group ‘B’ Non-Gazetted Non
Ministerial
Level- 6 (Rs. 35400-112400) in the Pay Matrix
Selection
Not Applicable
Not Applicable
Not Applicable

Two Years
100% by Promotion.

Promotion:
From IT Assistant Grade ‘B’ in Level 5 Rs. 2920092300/- in the pay matrix with six years regular
service in the grade.

Note: Where juniors who have completed their
qualifying/ eligibility service are being considered for
promotion, their seniors would also be considered
provided they are not short of the requisite qualifying/
eligibility service by more than half of such
qualifying/ eligibility service or two years, whichever
is less, and have successfully completed probation
period for promotion to the next higher grade along
with their juniors who have already completed such
qualifying/ eligibility service.

<!-- page 7 -->

6
12.

13.

DELHI GAZETTE : EXTRAORDINARY
If a Departmental Promotion Committee exists
what is its composition

Circumstances in which Union Public Service
Commission to be consulted in making recruitment

PART IV]

"Group 'B' Departmental Promotion Committee
(DPC)/Departmental
Confirmation
Committee
(DCC)
1. Principal Secretary/Secretary TTE), Govt. of NCT
of Delhi-Chairman.
2. Administrative Secretary (IT) Department
Concerned, Govt. of NCT of Delhi-Member.
3. Special /Addl. Secretary (Health and Family
Welfare), Govt. of NCT of Delhi-Member.
Note: Senior most member of the Departmental
Promotion Committee/Departmental Confirmation
Committee shall act as Chairperson in case the
notified Chairperson of the Departmental Promotion
Committee/Departmental Confirmation Committee
happens to be junior to another member of the
Departmental Promotion Committee.”
"Consultation with UPSC is not Necessary"

By Order and in the Name of the Lt. Governor
of the National Capital Territory of Delhi,
ANAND KUMAR TIWARI, Special Secy. (IT)

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

VINOD
KUMAR

Digitally signed by
VINOD KUMAR
Date: 2026.07.27
13:58:36 +05'30'
