---
doc_id: "d7ba6662eaf29faf"
source_url: "https://home.delhi.gov.in/sites/default/files/home/circulars-orders/notification_w.r.t._designated_places_under_sec_265_bnss_2023.pdf"
ministry: "Home Department, Delhi"
title: "Download"
date: ""
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "31f3c548df3c3733"
---

<!-- page 1 -->

(To be ublishedin Delhl(Garete Eatra(Orllnary- Part IV)
(G0VERNMENT OF NATIONAL, CAPITAL, TERRITORY OF DELIIT

MOME(GENRRAL.) DEPARTMENT

S"LRVEL. 'A'WING, IDELIIISECRETARIAT
Nu F.97/2024Mom(o

20S3-2o7|

Dnted: the |7h of July 2024

NOUELCATLO N
In evenis ofthe powers oonfemd by Govenment of Indin, Ministry of llome Affairs vide Notification No.
S.0. 250E)dated 2Sth Junc 2024, the Lt. Ciovennor, of Ntional Capital Territory of Delhi is
pleased to
ntify that:
() the niication vide F. No,
9/71/2024Nlomc(G)/|487-|502 dntcd 3d July 2024 having some mis
incoporated placcs stands withdrawn with immediate cllect;

(1) the placs as mentioned in Schedule below shall be the "Designatcd
Placcs'" for the purposes of second
proviso O sub-section (3) of Section 265, second proviso to sub-scction (2) of Section 266
and Section 308
ofthe Bharatiya Nagarik Suraksha Sanbita, 2023 (Act 46 of

2023):

SCHEDULE

Name of the organization/|Location of Video
onferencing
iastitution.
Places
Delhi High Court

Rooms/ Designated

Video Conferencing Rooms established at Delhi High
Court and Districts Courts with the approval
of High

Court of Delhi

Forensic Science Laboratory,1. Video Conferencing
Room/Office Room of Forensic
of National
Science Laboratory, GNCTD, Sector-14, Madhuban
Capital Teritory of Delhi
Govemment

Chowk, Rohini, New Delhi-110085

2. Office

Room of Regional

Forensic

Laboratory, GNCTD, NDMC Flats, 7h Science
Floor,
Yashwant Palace, Chanakyapuri, New Delhi-110021.

3. Office Room at VEERA Centre, Plot

P.S.P.
Arear-2, Sector-23 Extension, Rohini,No.21,
New Delhi
110086.

<!-- page 2 -->

yaitmen of Moaltlh ant
Panily Wellar, t
of Natkonnl (npitalivennent
leniony
of hi

Vhleo Cvnferemlng Remn of Lok Naynk Ilospital,
Jawabornl Nehnn Mnry, vear Dellhi Gnte, New Dellhi
IO002

Vkleu (onferenelng l n of Gun Tey Mabulur
lopital, Iaharpur Roul, o| Eoclave, Dibhad
Gnnden, New Delll- |0095

1 Vileo(onferenvlng llmm of abu Snlieh Amnbedkar

Ilopltal, Seelor 6, obinl, New Dellhl-0085
Vlleo'onferenelngRoon of lndirm Gnndhi blospilal,
Sector 9, Dwatkn, New Delli-||0077
S, Video Cunferenclng Room of Deen Daynl Upadl1yay
4.

llospilal, Slabced Mamynl Pandey Mury, Nanak Pura,
llari Nugr, New Delhi-10064

6. Video ('onferencing koom of Acharyu Shri Bikshu
Ilospital, lntel Rond, B-block, Moti Nagar, Ngw
Dellhi-||0015

7. Video Conferencing Room of Babu Jagiivan Rarn
Hospital, Sant Ravidas Nagar Main Road, Bhalswa,

Jahangir Puri, New Delhi- 10033.
8. Vidco Conferencing Room of Bhagwan Mahavir

IHospital, 4/5, Guru Harkishan Marg, Pitampura, New
Delhi-110034.

9. Video Con•erencing Room of Burari Hospital, Burari
Rd, Kaushik Enclavc, Shankarpura, Burari, New
Delhi- 110084.

10. Video Conferencing Room of Chacha Nehru Bal
Chikistalaya, Gecta Colony, New Delhi - 10031.
11. Video Conferencing Room of Guru Gobind Singh
Govt. Hospital, Pockct A, Raghubir Nagar Tagore

Garden Extension, New Delhi-110027.
12. Video Conferencing Room of Jag Pravesh Chandra

Hospital, Panduk Shila Marg, Shastri Park, Shahdara,
New Delhi-110053.
13. Video Conferencing Room of Lal Bahadur Shastri
Hospital, Mayur Vihar Phasc-lI, Khichripur, New
Delhi-110091.

14. Video Conferencing Room of Maharishi Val1niki

Hospital, Pooth Khurd, New Delhi-1 10039
1S. Video Conferencing Room of RTRM Hospital,
Jafarpur, New Delhi-110073.
16. Video Conferencing Room of Satyawadi Raja
Harish
Chandra Hospital, Plot No. 30, Sec-7A, Narcla, New
Delhi-110040.

17. Video Conferencing Room of Sanjay
Gandhi
Memorial Hospital, X-Block, MangolPuri, New
Delhi-110083

<!-- page 3 -->

I8 VAleu Cnferenc ing Rom of Deep Chand Bandhu
Hopital, Ahod Vihar. Phase IV, Kokin ala Bagh.
New Delhi-10092

9 V'slv Conferenc ing Rom of Dr. Hedgew ar
Anghya Sansthan, Karkardooma. New Delhi
I0002.
20 V'ieo Conferens ing Room of . Madan Motan
Maliya Hospital, Behind Main Marhet Malviya
Nagar, New Delhi.- 110017

21.ViJeo Conferencing Room of Shri Dada Dev Matri
Avum Shishu Chikitsalay a. Dabri. New Delhi
I10045

<!-- page 4 -->

aehall eomnlytothe ligh Courtot

4 Dthi Irisons,
Govemment
f Nationnl ('apital Tenitory

e

I Vilen Conferencing Roon of Central Jail No.I,

Dhi

)

Tihar at tle oflce of Superintendent, Central
Jail No., Tihar, Ianak Iuri, New Delhi-|10064.
Vileo ('onferencing Room of Central ailNo.2,

ihar at the oflice of Superintendent, Central

Jail No.2, ilhar, Janak Puri, New Delhi-| 10064.
J. Vilen('onlerencing Reom of Central Jail No.3,
Tihar at tlie oflec of Superintendent, Central
Jail No.J, Tihar, Janak Puri, New elhi-10064.

4. Vileo Contercncing Roum of Central JailNo.4,

Tilar at lhe oflice of Supcrintcndent, Central
Jail Nu.4, Tihur, Janak Puri, Ncw Delhi-|l0064.

Vileo Conferencing Roon of Central JailNo.5,
Tilhar at the oflicc of Supcrintendent, Central
Juil No.5, Tihar, Junuk Puri, Ncw Delhi-10064.
6. Video Confercncing Room of Central Jail No.6,
Tihar at thc oflice of Supcrintendent, Central
Jail No.6, Tihar, Janak Puri, New Delhi-110064.
7. Video Conferencing Room of Central Jail No.7,

Tihar at the ofice of Superintendent, Central
JailNo.7, Tihar, Janak Puri, New Delhi-110064.
8. Video Conferencing Room of Central Jail
No.8/9, Tihar at the office of Superintendent,
Central Jail No.8/9, Tihar, Janak Puri, New
Delhi-110064.
9

Video Conferencing Room of Central Jail
No.10, Rohini at the office of Superintendent,

Central Jail No.10, Rohini, Sec.-19, New Delhi
110085.

10. Video Conferencing Room of Central Jail

No.11, Mandoli at the office of Superintendent,
Central Jail No.l1, Mandoli, Harsh Vihar, New
Delhi-110093.

11. Video Conferencing Room of Central Jail
No.12, Mandoli at the ofice of Superintendent,
Central Jail No.12, Mandoli, Harsh Vihar, New
Delhi-110093.
12. Video Conferencing Room of Central Jail

No.13, Mandoli at the office of Superintendent,

Central Jail No.13, Mandoli, Harsh Vihar, New
Delhi-110093.

13. Video Conferencing Room of Central Jail
No.14, Mandoli at the office of Superintendent,

Central Jail No.14, Mandoli, Harsh Vihar, New
Delhi-110093.

14. Video Conferencing Room of Central Jail

No.15, Mandoli at the ofice of Superintendent,
Central Jail No.Is, Mandoli, Harsh Vihar, New
Delhi-110093.

15. Video Conferencing Room of Central Jail
No.16, Mandoliat the office of Superintendent,

Central Jail No. 16, Mandoli, Harsh Vihar, New
Delhi-110093.

<!-- page 5 -->

partnnent of

Reveue,

(Governmcnt

Nationnl

of

I. Video Conferencing Room/OMice Room at Office
of

('npital leritory ofDelhi

Divisional

Commissioncr,

Revenue

Department, ONC"TD, 5, Shamnath Marg, Prema

Kunl, C'lvil Lincs, New Delhi-||0054

2, Vileo ('onferenclng Room/)fice Room at Office

of District Magistratc, North, Alipur, New Delhi
I10036

J, Vileo('onferencing Room/)Mice Room at Office
of Distriet Mugistrnte, North West, Kanjhawala,
New Dellhl- 10081.
4. Vldeo ('onlerencing Room/Officc Room at Office
of District Mugistrute, Central, 14 Darya Cianj.
New Delli-|10002

$. Video (Confercncing Room/Office Room at Office
of District Magistrate, West, Plot no.-03, Shivaji
Placc, Raja Gurden, Ncw Delhi-1 10027
6. Vidco Con•ercncing Room/0ffice Room at Office
of District Magistrate, New Delhi, 12/1, Jam
Nagar, IHouse, NewDelhi-| 10011|
7. Video Conferencing Room/Office Room at Office

of District Magistrate, South, Mehrauli, Badarpur

Road, Saket, New Delhi-1 10017.

8. Video Conferencing Room/Office Room at Ofice

of District Magistrate, South East, Old Gargi
College Building, Lajpat Nagar-IV, New Delhi

110024

9.

Video Conferencing Room/Office Room at Office

of District Magistrate, South West, Kapashera,

New Delhi-110037.

10. Video Conferencing Room/Office Room at Office

of District Magistrate, North East, Weayer's

Complex, Nand Nagri, New Delhi-110093.

11. Video Conferencing Room/Office Roomn at Office
of District Magistrate, East, LM Bundh, Shastri
Nagar, Geeta Colony, New Delhi-110031
12. Video Conferencing Room/Office Room at Office
of District Magistrate, Shahdara, LM Band Road,

Bunkar Complex, Nand Nagri, Opp. Gagan
Cinema, New Delhi-110093

6

Delhi

Secretariat, NIC

Conference Room at Delhi Secretariat, Government
Government of National of National
Capital
of Delhi,
|CapitalTerritory of Delhi ITO, Vikram Nagar,Territory
New Delhi-I10002Sachivalaya Road,
New
Delhi
Municipal Video Conferencing Room, New Delhi
Council (NDMC)
Municipal
Council, Palika Kendra,
|New Delhi-110001 Sansad Marg, Connaught Place,

<!-- page 6 -->

Moniclal (ont

o vileo (Cmferclng Rowm, Ole of (onmivimer ol
Munleiml Cupratlon ol Delhl,Dr. S.P.M.Clvic ('entre,
Minto Rend, New Delll-\0002

(ii) the Vilv ('ntewing tacllitles atcdesiguated place* alallcomply to the liplh ('urtof Dellhi
kulesfor
Vilo ntenning i ((nts, 021, Aneled hon time to tlme.
1his noiticatim shallvwne into fonve hom the lale of ls pulbllcntion in the

oflicinl avelte.

lBy order and lu the Me of lhe la. (Governor of National

Capital
Territory of Delbl

(RAJAN BIIATNAGAR)
Dy. Secretary (lfome)
Ilome Department
No. F.9/71/20241lome(G) 2053- 204|
Daled the 17h of July2024
Copy fonw arded to the following for infornalion andnccessary action:
1.

Registrar General, Supreme Court of' India, New Delhi
Registrar General, Delhi lHigh Court, New Dellhi
3. Principal District &Sessions Judge (llqs), Tis Hazari courts, Delhi
4
Secretary, Govt.of India, Ministry of Home Afairs, New Delhi
S. Sccrctary, Govt. of India,
Ministry of Law, Justice &Legal Afairs, New Delhi
6 Sccretary to Hon'ble LG, Delhi
7
Sccretary to Hon'ble Minister (Home), Govt. of NCTof Dellhi.
8
Director, Intelligence Burcau, Govt. of India, New Delhi.
9
Director Central Burcauof
CGO complex, NewDclhi.
10. Director, NCRB, M/o IHomeInvestigation,
Affairs, East Block, R.K. Puram, Ncw Delhi.
1|. Additional Sccrelary (UT), M/o Hone AMairs, North
Block, Ncw Delhi.
12. Commissioncr of Police, DelhiPolice.
13. Director Gencral (Prisons), Delhi Prisons, Delhi.
14. Principal Sccretary (Revcnue Department), Government of National
Capital Territory of Delhi
15. Principal Secrelary (General Administration
Depart1nent),
of National Capital Terrilory of
Government
Delhi
16. Sccretary (Law), Govt, of NCTof Delhi.
17. Dircctor, Prosecution Department, Govt. of NCT of Delhi.
18. StalToflicer to Chief Secretary, GNCT of Delhi.
19. PA to Additional Chief Secretary (l lome), GNCT of Delhi.
2

(RAJAN BIIATNAGAR)
Dy. Secretary (llome)

Ilome Department

<!-- page 7 -->

frater :

OO 9/71/2024/J0fno)/2 o53-2.0"]1

) BOO 9/71 /2024/To(Io)/1487-1602 feis 3 yl 2024 1 aayg

erY 46) 3¥ gr 265 t By-RT (3)

HR YRGE, RI 266 6T

2

HEg

, Rigv, fcoc-110085

21, LgHA. yfu-2, teeT-23 (HÈIA,

<!-- page 8 -->

3

a-110095

vMfau

fal-110005

fo-110077
g

,

Rll-110064

Rofl-110015

ERfOYI¬ 4Í,
o-ofT , 4/5,
taHye, foc-110034
9

ftol- 110084

110031

110027

110053

fausye,
14

feof-110091

<!-- page 9 -->

AT, GYIY, T fecofl-110073

lacr-7, TreI, T of - 110040

o-110052
foef-1100032

feoef HrR, SIA, TÉ ftor-110045
4

feocf-110064

f¢or-110064

foril-110064

f-110064

fo-110064

<!-- page 10 -->

le-110004
3renercs
7. vlea ote ta 7 fers it frert
Rel-110064

forll-110064

10,

tac19,

ol-110085

Rorft-110093
12, sIci,

fER,

jqr 14, 4sf,

fAgR,

fot-110093

fo-110093
o-110093
15, 4sI, g

faot-110093

foit-110093
5.

fzoel-110054
2

fER,

<!-- page 11 -->

Reel-110030
VN-qRqn
3, Trafery ret fre

Rurta,

HAr/Tfu
ftoc-110002

14

Rof-110027

12/1,GITH TIR, BIGH,

fot-110001

Is, HIO, toci-110039

8. 5raferuftrell f ,

fery-d

fo-110024

10

11

I/Itcis

12.

6.

H,
8.

fcocf-110001

,

<!-- page 12 -->

BLR 9/71/2024/jo(HTo)/2053-207|
