---
doc_id: "eddf13da8ee9887d"
source_url: "https://www.edudel.nic.in/tenders_new/tender_dbtb_dt_07082023b.PDF"
ministry: "Education Department, Delhi"
title: "E-TENDER NOTICE: Composing, DTP, Printing and Supply of Support Material for the Student of DoE / Autonomous Bodies for Class IX and XI for the Academic Session 2023-24 and 2024-25 on 1+1 basis with Mutual Consent @ DBTB"
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "0108d27283eb5533"
---

<!-- no text layer: pending OCR -->
