---
doc_id: "f8f1ad8de7ce445e"
source_url: "https://forest.delhi.gov.in/sites/default/files/forest.delhi.gov.in/tender/f.96._galibpur_0.pdf"
ministry: "Forest Department, Delhi"
title: "Tender Document"
date: ""
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "66fcda578ac2b956"
---

<!-- page 1 -->

GOVT. OFNCT OF DELHI
OF FOREST AND WILD
LIFE
OF THE
OFFICEDEPARTMENT

DEPUTY

CONSERVATOR
FORESTS
WEST FOREST
DIVISION
MANDIR LANE, NEWDELHI 110060
OF

EMAIL: defwest.gnctd@gov.in

TENDER APPLICA TION FORM
lla /G 20

response

Land/2023-24
mentioned below for the

to

/.

Dated

the

Tender Notice No. F.(1YDCF(W)/Land/Galibpur 4.64

I/We do hercby offer the rate against the item of work
"E- TENDER FOR SUPPLY AND
CREATION OF 8282 NUMBERS OF
BAMBO0 PLANTATION
WEST FOREST DIVISION, (BAMBUSETUM)OF AT GALIBPUR VILLAGE AREA UNDEK
DEPARTMENT FORESTS & WILDLIFE, GNCT OF

DELHI"

Last date for submission/receipt of tenders(s)
e-tendering in
will be opencd online
01:00 PM and
by the Tender Committee through
in the presence of 04.01.20211at
tenders or their authorized
representatives who wish to be present on the same day i.e. 04.01.202Mat 03:00
PM in the office of the
Deputy Conscrvator of Forests, West Forest Division,
of
Department
Forest
&
NCT of Delhi. In case of any holiday on the day of
Wildlife, Government of
opening, the e-tender will be opened
on the next
working day at the same time.

Dy. Conservator of Forests
West Forest Division

Department of Forests & Wildlife
Govt. ofNCT of Delhi

Mandir Lane, New Delhi-110060

Page 1 of

<!-- page 2 -->

GOVT, OF NCT OF DELIII

DEPARTMENT OF FOREST AND WILDLIFE
OFFICE OF TIIE DEPUTY CONSERVATIR OF FOREST
WEST FOREST DIVISION

MANDIRLANE, NEW DELIILHO060
EMAIIL: defwest.gnetd@gov.in

ENDER APPLICAUON EORM
In

response

F(1)/DCFW)Land/Ganbpur 4.64 lla G 20 Land/2023-2|/

Ih

No

Notice

Tender

Datvl

UWe do berehy offer the rate against thC ei

work mentioned below lor the "E- TENDER FOR SIPPLV AND CEATON 08 8282 NUMBERS OF

BA MS

PLANTATION (BAMBUSETUM) AT GALIBPUR VULACE AREA UNDED WESI OREST DIVISION" or pem

mentioned below:

GOVT. OF NCT OF DELII

DEPARTMENT OFFOREST AND WILDLIFE

OFFICE OF THE DEPUTY CONSERVATR OF FOREST
WEST FOREST DIVISION

MANDIR LANE, NEW DELIII-T10060
ESTIMATE

NAME OF WORK: E-TENDER FOR SUPPLY ANID CREATION OF
8282
OF BAMBO0 PLANTATION
(BAMBUSETUM) AT GALIBPUR VILLAGE AREA UNDER WEST FORESTNUMBERS
DIVISION
S.No.
DSR
Items Description/Particulars
Unit
Rateper unit Amount
Quantity
Code
1

A/R

Arundenaria hirsute Munro

82

Nos.

82

Nos.

(Rhizome Based of Minimum IFeet Height
in a polybag)
2

A/R

Arundanariaracemosa
(Rhizome Based of Minimum IFeet Height
in a polybag)

3

A/R

B.cacharensis

Nos.

(Rhizome Based of Minimum 1lFeet
Height)
4

A/R

B.manipurensis

82

Nos.

82

Nos.

(Rhizome Based of Minimum lFeet Height
in a polybag)
5

6

A/R

A/R

Bambusaassamica

(Rhizome Based of Minimum IFeet Height
in a polybag)

3

Bambusaatra

82

Nos.

(Rhizome Based of Minimum lFeet Height in

apolybag)
7

A/R

Nos.

Bambusaauriculata

(Rhizome Based of Minimum IFeet Height
in a polybag)
A/R

Bambusabalcoa

82

Nos.

82

Nos.

(Rhizome Based of Minimum IFeet Height
in a polybag)
9

A/R

Bambusacopelandi

(Rhizome Based of Minimum Ieet lHeight
in a polybag)

Page 2of

<!-- page 3 -->

10

A/R

Bambusaglaucophylla

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

(Rhizonme Based of MininnumlFeet lleight
in a polybag)
A/R

Bambusaheterostachya

(Rhizome Based of Mininum llFeet Height
in a polybag)
AR

12

Bambusajaintiana
(Rhizome Based of Minimunm |Fcet Height

in a poly bag)
13

AR

Bambusamastersii

(Rhizome Based of Minimum IFect Height
in a polybag)
14

A/R

Bambusamizoramiana

(Rhizome Based of Minimum IFeet Height
in a polybag)
15

A/R

Bambusaoliveriana

(Rhizome Based of Minimum 1Feet Height
16

A/R

in a polybag)
Bambusapsudo Palladium
(Rhizome Based of MinimumlFeet Height

in a polybag)
17

A/R

D.latiflorus

(Rhizome Based of Minimum lFeet Height
in a polybag)
A/R

D.manipureanus
(Rhizome Based of Minimum lFeet Height
in a polybag)

19

A/R

D.sikkimensis

(Rhizome Based of Minimum IFeet Height

20

A/R

in a poly bag)
Dendrocalamusgigantius

(Rhizome Based of Minimum lFeet Height
in a polybag)
21

A/R

Dendrocalamushamiltonii

(Rhizomne Based of Minimum IFeet Height
in a poly bag)
22

A/R

Dendrocalamushook eri

(Rhizomne Based of Minimum IlFeet leight

in a polybag)

Page 3 of

<!-- page 4 -->

A/R

23

Dendrocalamuspatellaris

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

(Rhizome Based of Minimum IFeet Height
in a poly bag)
AR

24

Bambusa sp.

(Rhizome Based of Minimum lFeet Height
ina polybag)
A/R

25

Diachloacompactiflora
(Rhizome Based of Minimum IFeet Height
in a polybag)

26

A/R

Dinochloagracilis
(Rhizome Based of Minimum 1Feet Height

in a polybag)
27

A/R

Dinochloaindica

(Rhizome Based of Minimum lFeet Height
in a polybag)
28

A/R

Dendrocalamushookeri, munro

(Rhizome Based of Minimum IFeet Height
in a polybag
29

A/R

Dinochloamclellandi

(Rhizome Based of MinimumlFeet Hleight
in a polybag)
30

A/R

Dinochloacompactiflora

(Rhizome Based of Minimum IFeet Height
in a polybag)
31

A/R

Drapanostachyumkha sianum( Munro)
Majundar

(Rhizome Based of Minimum lFect Height
in a polybag)
32

A/R

Gigantochloaalbociliata
(Rhizome Based of Minimum 1Feet Height in

a polybag)
33

A/R

Gigantochloaatroviolacca
(Rhizome Based of Minimum 1Feet Height
in a polybag)

34

A/R

Gigantochloamacrostachys

(Rhizome Based of Minimum lFeet Height
in a polybag)
35

A/R

Gigantochloapseudoarundanacca

(Rhizome Based of Minimum lFeet Height
in a polybag)

Page 4 of

<!-- page 5 -->

36

A/R

Gigantochloarostrata

82

Nos.

(Rhizone Bascd of Mininum |Feet lleight
in a polybag)
37

AR

Guadusangustifolia

82

Nos

AR

(Rhizome Bascd of Minimun |Feet leight
ina poly bag)
Melocannaarundna

82

Nos

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

(Rhizomc Based ofMinimunn |Feet lleight

in apolybag)
AR

Neomierocalamuspraini
(Rhizome Based of Minimum IFeet Height

40

AR

in a polybag)
Oxytentheraabyssinica

(Rhizome Based of Minimum lFeet Height
in a polybag)
41

AR

Phyllostachysa ssamica
(Rhizome Based of Minimum IFeet Height
in a polybag)

A/R

Phylostachysbambusoides
(Rhizome Based of Minimum lFeet Height
in a polybag)

43

A/R

Phylostachysnigra

(Rhizome Based of Minimum lFeet Height
in a polybag)
44

A/R

S.munroi

(Rhizome Based of Minimum1Feet Height

ina polybag)
45

A/R

S.pallidum

3|
82

Nos.

82

Nos.

82

Nos.

82

Nos.

(Rhizome Based of Minimum IFeet Height
in a polybag)
16

A/R

S.polymorphum
(Rhizome Based of Minimum lFeet Ileight

in a polybag)
47

A/R

Schizostachyumcapitalam
(Rhizome Based of Minimum|Feet Ileight

48

A/R

in a polybag)
Schizostachyumpoclymorphum

(Rhizome Based of Mininun lFet lleight
in a polybag)

Page 5 of

<!-- page 6 -->

82

Nos.

82

Nos.

82

Nos.

lleipht

Minimum
1Feet

polybag)

ain

Based
of(Rhizome

Chimonobambusacallosa

A/R

polybag)
Ileight

IFectMinimum

gigantcan

polybag)
MinimumI

ain

Based
of(Rhizome

var.bambos Bambusa

Height
ain

A/R

82

Nos.

82

Nos.

82

Nos.

32

Nos.

82

Nos.

82

Nos.

82

Nos.

82 Thinaundinareahookeriaana

Nos.

Height

A/R

polybag)
Based
of(Rhizome

1Feet
Minimum

82

Nos.

58

ain

57

A/R

lFeetMinimum

59

ain

A/R

polybag)
Based
of(Rhizome

1FeetMinimum

Thamnocalamusfalconeri

polybag)
Height

in
a

Based
of(Rhizome

Thamnocalamusaristatus

A/R

polybag)
Height

FeetMinimum 1

56

ain

Based
of(Rhizome

SinaundinareaFalcata

A/R

polybag)

Height

FeetMinimumlI

55

ain

Based
of(Rhizome

Sinarundinariamicrophylla
Height

A/R

polybag)
Based
of(Rhizome

1FeetMinimum

54

ain

Sinarundinariaintrmedia

Height

A/R

polybag)
Based
of(Rhizome

IFeetMinimum

polybag)
Based
of(Rhizome

lFeetMinimum

IFeetMinimum

53

ain

Snarundinariahookeriana

Height

ain

Sinarundanaria
falcata

A/R

52

A/R

polybag)
Height

51

ain

Based
of(Rhizome

Schizostacyummunroi

polybag)
Height

60

Feet

Based
of(Rhizome

Thrysostachysoliveri
Height

82

Nos.

Fcet
Minimum I

ain

A/R

50

Based
of(Rhizome

Schizostachyum-fuchsianum

49

A/R

<!-- page 7 -->

62

A/R

Bambusa bambos

82

Nos.

8

Nos

82

Nos

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

(Rhizome Based ol Minimum |Feet Height
in a poly bag)
63

AR

Bambusanutans
(Rhizone Based of Minimum lFect |leight
in apolybag)

AR

Bambusapaleda
(Rhizome Based ofMinimum |Fcet lleight
in a poly bag)

AR

Bambusapolymorpha
(Rhizome Based of Miimunm |l'cet Hcight
in a polybag)

AR

Bambusatulda

(Rhizome Based of Minimum lFeet Height
in a polybag)
67

AR

Bambusa vulgaris
(Rhizome Based of Minimum lFeet Height

in a polybag)
68

AR

Bambusa vulgaris green
(Rhizome Based of Minimum1Feet Height

in a polybag)
69

AR

Dendrocalamuscalostachyus

(Rhizome Based of Minimum1Feet Height
in a polybag)
70

A/R

Dendrocalamuslongispathus

(Rhizome Based of Minimum lFeet Height
in a polybag)
71

AR

Dendrocalamusmembranaceus

(Rhizome Based of Minimum 1Feet Height
in a polybag)
72

AR

Dendrocalamusstrictus

(Rhizome Based of MinimumlFeet Height
in a polybag)
73

A/R

Phyllostachysmannii
(Rhizome Based of Minimum |Feet |leight
in a polybag)

74

AR

S. sharmac

(Rhizome Based of Minimun |Feet |eipht
in a polybag)

Page 7 of

<!-- page 8 -->

75

A/R

S.griffithiana

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

(Rhizome Based of MinimumIFeet Height
in a polybag
76

A/R

S.hookeriana

(Rhizome Based of Minimum IFeet Height
77

A/R

in a polybag)
S.rolloana

(Rhizome Based of Minimum lFect Height
in a polybag)
78

A/R

Schizostachyumgriffithii
(Rhizome Based of Minimum lFeet Height
in a polybag)

79

A/R

Schizostachyumhel feri (Munro)

(Rhizome Based of Minimum lFeet Height
in a polybag)
80

A/R

Schizosta chyumpergrecile
(Rhizome Based of Minimum lFeet Height
in a polybag)

81

A/R

Thrysostachysregia
(Rhizome Based of Minimum lFeet Height
in a polybag)

82

A/R

Bambusalongispiculata
(Rhizome Based of Minimum l Feet Height

in a polybag)
83

A/R

Bambusa striata

(Rhizome Based of Minimum lFeet Height
in a polybag )
84

A/R

Bambusateres

(Rhizome Based of Minimum lFeet Height
in a polybag)
85

A/R

Bambusoideae bamboo grass
(Rhizome Based of Minimum lFeet Height
in a polybag)

86

A/R

Gigantochl oamacrostachys
(Rhizome Based of Minimum lFeet Height in

polybag)
87

A/R

M. Bambusoides

(Rhizome Based ofMinimum IFeet Height

in a polybag)

Page 8 of

<!-- page 9 -->

88

AR

Meloclamusindicus

82

Nos,

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

82

Nos.

83

Nos.

82

Nos.

(Rhizone Based ofMinimum IFeet leight
in a polybag)
89

A/R

Schizostachyumdullooa

(Rhizonne Based of MinimumlFeetlleight
in a polybag)
90

A/R

Sczostachvumdalloa

(Rhizome Based ofMinimum lFeet Height

in a polybag)
91

AR

Sinarundinariaclegans
(Rhizome Based of Minimum lIFeet Height
in apolybag)

92

A/R

Bambusa multiplex

(Rhizome Based of Minimum lFeet Height
in a polybag)
93

A/R

Bambusawamin

(Rhizome Based of Minimum I Fcet Height
in a polybag)
94

A/R

Melocannaarundina

(Rhizome Based of Minimunm lFeet Height
in a polybag)
95

WR

Melocannabeccifera

(Rhizome Based of Minimum lFeet Height
in a polybag)
96

A/R

Sinaaruduneriamaling

(Rhizome Based of Minimum IFeet Height
in a polybag)
97

A/R

Bambusa vulgaris vitata

(Rhizome Based of Minimum lFeet Height

in apolybag)
98

A/R

Bambusa vulgaris stariata
(Rhizome Based of Minimum IFeet Ileight

in a polybag)
99

A/R

Dendrocalamusbrandisii

(Rhizome Based of Minimum|Feet |Icight
in a polybag)
100

A/R

Phylostachysaurca

(Rhizome Based of Minimum lFeet llcight
in a polybag)

Page 9 of

<!-- page 10 -->

101

A/R

Sczostachyumcapetalum

82

Nos.

468.7612

Per Cum

19557

Sqm

8282

Each

8282

Each

(Rhizome Bascd of Minimum IFeet Height
in a polybag)
102

2.25

Supply and stacking of welldecayed cattle
manure at site including royalty and carriage
complete (Cattle manure measured in stacks
will reduced by 8% for payment) 0.0566

103

2.31

cum. Per (approx 2 kg per pit) per plant.
Clearing jungle including uprooting of rank
vegetation, grass. brush wood, trces and
saplings of girth up to 15 cm measured at a

height of 30cm above ground level and
104

2.14.3

removal of rubbish up to a distance of 50 m
outside the periphery of the area cleared.
Digging pits of size 60 cm diameter and 60

cm deep in ordinary soil Using augers/hand
held equipment (No excavators or similar

machinery shallbe used for digging) and
refilling the same with the excavated earth
mixed with manure in the ratio of 2:1 by
volume (2 parts of stacked volume of earth

after reduction by 20% :1 part of stacked
volume of manure after reduction by 8%)
flooding with water, dressing including
removal of rubbish and surplus earth, if any,
with all leads and lifts (Cost of manure or

105

2.57.1

extra good carth if needed to be paid for
separately.)
Plantation of Trees, Shrubs, and Hedge at
site i/c watering andremoval of unserviceable
material's as per direction of officer in

charge (excluding cast of plant & water)
Trees Plant

Total

<!-- page 11 -->

TERIS &CONDIUONS OE TIE EIENDER
Tender invited for the work of
-rENDKR kOR SUPPIY AND CREATION OF 8282
NUM BERS OF BAMBOO
TL.NTATTON (BAMBUSETUM) AT GALIBPUR VIILACE AREA
UNIDER WEST FOREST
-

DIVISION" Department of
Torest and Wildite, GNCTD, Wes 'orest Division
Maudir Iane New Delhi - 10060, through etendering. The successtul
tenderer/bidder shall be requircd to eNCcute the work as specitlicd in the lender Application Fon within 10 days'
time from the date of

communication of the approval otthc Competcnt Autho ity
S

peT

arket rate including loading unloadino and

ranspotation charocs estimated cost is Rs. 2,21,44,015/- (Rupees Two Crores
Twenty One Lakhs Forty Four
Thousands and Fifteen Only).
T'artieipalion n he online bid shall amomt to bidder's accenlance of tlhe terms and
conditions ol the tender.

Tne bidder shall submit on or before the date eiven in the Noticc Invitiug e-1Tender, the

online in the prescribed format given in

Technical Bid and the Financial Bid

e-Tenderingsite.

1. The Technical Bid should consist ofthe

following documents:

BidSecuriy/Earnest Mney Deposit. lor an amount of Rs. 11,07,201/- (Rupees Eleven Lakhs Seven Thousand
Two Hundred and One Only) i.e.,5% ofEstimated cost Rs. 2,21,44,015/-

in the form of an Account Payee

Demand Dratt/ FDR ftom any commercial Bank in favour of DDO, DCF (West), payable at Delhi. The EMD in
original shall be submitted in the Office of DCF (West) Dairy& Dispatch Counter on or before the closing date
and time mentioned on the e procurement portal.

Scanned copy of registration/Association with Government/Autonomous

Bodies for Horticulture/Forestry works.
Experience
1. Self-attested scanned copy

of experience of having successfully completed supply of trees species or

undertaking similar nature of work inthe past in any state in India.
2.

The bidder must have the experience of developing at least two bambusetums in India.

Turnoyer
Self-attested scanned copy of the last three years, ending 31st March of the previous financial year should be at least
30% of the estimated (gross) value of the work (duly audited by Chartered Accountant) on annual basis. If any

particular tenderer has achieved this yearly turnover up to the date of receipt of application in the finished part of the
ongoing financial year, the same also be taken into account to meet the requirement. This is to be certified by the
Chartered Accountant quoting his membership number and date upto which his certificate of practice is valid.

SolyencY
Self-attested scanned copy of financial solvency of 10% of the cost of the work as shown in the tender

documents issued by any Commercial Bank and theAverage annual financial turnover (gross) of sinilar nature ot
work

Self-attested copy of PAN Card under Income Tax Act along with last threeYears income tax returns tiled with

Income Tax Deptt.,

Self-attested copies of GST registration number.
An undertaking to the effect that the contractor/agency lhas not been blacklistedby any Govt. Department in eariier
0ccasiOns.

Scanned copyofsigned terms and condition by contractor.

Tenderer/Bidder must submit copies of all documents required throughonline
5.

Tenderer/Bidder shall quote the rates in the prescribed lorm for Price Bid oiven in E. Tendering site against this tender On

stgie

responsibility basis such that the Tender price covers contractor's all obligations and liabilities in complianee to act tules ol the

land. Thc rates and prices quoted by the Bidder shall be inclusive ofall Taxes.

The tenderer/Bidder is expected to examine all instruetions Eorms Ters and Conditions in the Tender document

participation in this e-tender. The validity of tender will be 0l vear lor award aller approval.

i

Page 11 of 13

<!-- page 12 -->

7. In case the tenderer/Bidder has any doubt about the meaning of anytbing contained in the tender document, he shall seck
clarification from the ofliece of the DCF(WEST), Mandir Lane, New Dclhi-10060,

Tlhe successliul tenderer/bidder shall eveeute an agreement witlh (DCF WIES) sOon aler deposit of 5% of the tendered value as
Performance Guatantee within 10 days w.cf the date of aceeptance of the oller in the fotm of IDemand Drat/tixcd Deposit
Recept having a val1dity of06 months w.e.f the ate of acceptanceof the ofler,drawn on any of the Commercial 1Banks payable at

Delhi, in làvour of D.C.F. (WEST), payable at Delhi

The authorized representatives/Purchase Committee of this oflice/ Denartmenl will opcn
the'Technical IBid in thc presenCe

o tnC

Tenderer/Bidders Or their representatives who choose lo atlend at the apponted place and time. The Oualilication for the technical
bid shall be based on the online receipt of all the documents required& listed above
clause in (4)& (5) on or belorc the closiy datC
and time of bidding mentioned on the e
procurement portal.
10

Financial Bids/Price Bids of only the technically qualificd bidders willbe onencd for evaluation in the
prescnce of qual1ticd bidderS
who choose to be present at the tinme of opening of Financial Bids.
Rates shall be compared on the basis of total cost for all the items taken together for

approved Technical bid.

12

The Offers of tenders not accompanied by documentary proof or do not meet the
cligibility criteria as mentioncd above shall not be
considered. Canvassing or negotiation, dircct or indirect, would render the tender liable for exclusion from
consideration.

13.

The Dy. Conservator of Forests (West Division) reserves the right to
accept or rejcct any or cancel any or all the

tenders without

assigning any reason thereof.
14

The Department of Forests& Wildlife, Govt. of N.CT. of Delhi, is not bound to
accept the lowest ratc/cost or any bid and may at
any time by notice in writing to the bidder(s) terminate the tendering process.

15

Department of Forests & Wildlife, Govt. of N.C.T. of Delhi. is at liberty to accept rates quoted for one item and rejcct other or mav
accept gross valuc of complete tender on the recommendation ofCommittec existing for the purposc.

16. The Department of Forests & Wildlife, Govt. of N.C.T. of Delhi, may terminate the work order if it is found that the contractor is

black listed on the previous occasions by any of the Governmcnt Departments/Institutions/Local Bodies/Municipalities/Public

Sector Undertakings ctc.
7

The successful Tenderer/Bidder shall ensure full comliance with Tax laws of India with regard to the work order(s) and sthall be
solcly responsible for the same.

18

The successful bidder will comply all the rules & regulations of the land with latest circular/orders issued by various Governnment
Departments applicable to the work and bidder will besolely responsible.

19

Failure of the successful tenderer/bidder to comply with the requirements of above clauses shall constitute sulticient grounds for
the annulment of the work order and forfeiture of Bid Security/Performance Security

20

The Quantity of supply of items may increase or decrcase as per actual requirement. The successtul bidder will have to suppls the
above mentioned quantity of plants and as per supply order issucd by this office/department.

21. Duly completed books of accounts/documents should be produced as and when required by the departnent.
22

Theratesquoted by thetenderer shall remain valid for one year from the date of opening of Finaneial Bid and the Department shall
not be responsible for payment of any extra payment on account ofescalation olcosts during the said period.

23

The payment will bc relcased to the suceessful tender/bidder afler award of work order following agreement for the supply of' plants
by the Department on complction of satisfactory supply of plants as detailed in B0Q, supply order wise, on verification of the
actual supply executed by the tenderer, by DCF (West)a fter dedueting Income Tax or any other Tax or duties as liable as per the

prevailing Ac/Rules and the instructions/guidelines issued by the Ciovernmen/Departments from time totime.
Page 12 of 13

<!-- page 13 -->

24

n ne Cvent of non-cxccution of the
work. the Security Denosit shall be
3

forfeited with thc Government and the balance wolh,

o SOT CxCCuted at the risk and cost of the tenderer hy rescinding the
contract for the reasons to be rccorded by DCE

(WEST) in writing.
25

arent shallnot be responsible for payment ofany compensation on account of any loss caused to the tenderer due to
supervening impossibilities.

natural calamities or other
26.

e ouactor Shall not construct any Dcrmancnt structure at the site of work and shall have no right on the land or asset OJ Le

Government.
27. In nocircumstances, the contractor wouldbe allowed to sublet the works in part or whole ofthe contract, assigned to them.
28.

Any dispute or difference arising out of this contract will be resolved through joint discussion of the author ized representati Ves or
he concerned parties. However, if the disputes are not resolved by the joint discussions. then the matter will be referred for

adjudicationto asoleArbitrator appointed by the HOD,Department of Forests &Wildlife, GNCTD.
29.

The award of thc sole Arbitrator shall be final and binding on all the parties. The arbitration proceedings shall be governed by the

Indian Arbitration and Conciliation Act, 1996 as amended from time to time.
30

The cost of Arbitration shall be borne by the respective parties in equal proportions. During the pendency of the arbitration
procecding and currency of contract, neither party shall be entitled to suspend the work/service to which the dispute relates on
account of the arbitration and payment to the contractor shall continue to be made in the terms of the contract. Arbitration

proceedings will be held at Delhi/New Delhi only.
31.

All disputes arising out of the execution of the agreement shall be subject to the jurisdictionofthe Court at Delhi only.

Signature of the Contractor or His Authorized Nominee
Mobile No.

E-mail Address
