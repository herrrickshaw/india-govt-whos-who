---
doc_id: "41c8afebc0a8f3a2"
source_url: "https://hjbhabhaiti.delhi.gov.in/sites/default/files/hjbhabhaiti/tender/gem-bidding-8945415.pdf"
ministry: "Dr. H.J. Bhabha ITI Khichripur, Mayur Vihar, Delhi"
title: "Tender Document"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9310e7f4bf4da047"
---

<!-- page 1 -->

बड सं या/Bid Number : GEM/2026/B/7203534
दनांक /Dated: 09-02-2026

बड द तावेज़ / Bid Document

बड ववरण/
ववरण/ Bid Details
बड बंद होने क तार ख/
ख/समय /Bid End Date/Time

27-02-2026 20:00:00

बड खुलने क तार ख/
ख/समय /Bid Opening
Date/Time

27-02-2026 20:30:00

बड पेशकश वैधता (बं
(बंद होने क तार ख से) /Bid Offer
Validity (From End Date)

65 (Days)

मं ालय/
ालय/रा य का नाम /Ministry/State Name

Delhi

वभाग का नाम/Department
नाम
Name

Training And Technical Education Department Delhi

संगठन का नाम /Organisation Name

N/a

कायालय का नाम /Office Name

Hj Bhabha Govt Iti Mayur Vihar Phase 1 Delhi 91

कुल मा ा/Total
ा
Quantity

1

व तु

PORM

ण
े ी /Item Category

GeMARPTS म खोजी गई
ं स / Searched
Strings used in GeMARPTS

PORM

GeMARPTS म खोजा गया प रणाम / Searched
Result generated in GeMARPTS

Category not available on GeM for the text string uploaded
by the buyer

अिधसूचना के िलए चयिनत ासंिगक े णयाँ / Relevant
Categories selected for notification

Insert Carbide
Span Bolt and Nut
PVC Insulated (Heavy Duty) Electric Cables (V2 ) ISI
Marked to IS 1554 ( Part 2)

बडर का यूनतम औसत वा षक टनओवर (3 वष का)
का)
/Minimum Average Annual Turnover of the
bidder (For 3 Years)

16 Lakh (s)

मूल उपकरण िनमाता का औसत टनओवर (गत
(गत 3 वष
का)
का) /OEM Average Turnover (Last 3 Years)
उ ह ं/समान सेवा के िलए अपे

100 Lakh (s)

त वगत अनुभव के

वष/Years
वष
of Past Experience Required for
same/similar service

3 Year (s)

एमएसएमई के िलए अनुभव के वष और टनओवर से छूट दान
क गई है /MSE Relaxation for Years of
Experience and Turnover

No

टाटअप के िलए अनुभव के वष और टनओवर से छूट दान
क गई है /Startup Relaxation for Years of
Experience and Turnover

No

1/7

<!-- page 2 -->

बड ववरण/
ववरण/ Bid Details

व े ता से मांगे गए द तावेज़/Document required
from seller

या आप िन वदाकार

Experience Criteria,Past Performance,Bidder
Turnover,Certificate (Requested in ATC),OEM Authorization
Certificate,OEM Annual Turnover
*In case any bidder is seeking exemption from Experience /
Turnover Criteria, the supporting documents to prove his
eligibility for exemption must be uploaded for evaluation by
the buyer

ारा अपलोड कए गए द तावेज़ को

िन वदा म भाग लेने वाले सभी िन वदाकार को दखाना
चाहते ह? संदभ मेनू है /Do you want to show
documents uploaded by bidders to all
bidders participated in bid?
बड लगाने क समय सीमा

No

वतः नह ं बढ़ाने के िलए

आव यक बड क सं या।
या। / Minimum number of
bids required to disable automatic bid
extension

3

दन क सं या,
या, जनके िलए बड लगाने क समयसमय-सीमा
बढ़ाई जाएगी।
जाएगी। / Number of days for which Bid

3

would be auto--extended
ऑटो ए सटशन अिधकतम कतनी बार कया जाना है । /
Number of Auto Extension count
वगत

दशन /Past Performance

बड से रवस नीलामी स

3

50 %

य कया/Bid
कया
to RA enabled Yes

रवस नीलामी यो यता िनयम/RA
िनयम
Qualiﬁcation Rule

50% Lowest Priced Technically Qualified Bidders

बड का

Two Packet Bid

कार/Type
कार
of Bid

तकनीक मू यांकन के दौरान तकनीक

प ीकरण हे तु

अनुमत समय /Time allowed for Technical
Clarifications during technical evaluation

2 Days

िनर ण आव यक (सू
सूचीब िनर ण ािधकरण /जे
जेम के साथ
पूव पंजीकृ त एजिसय ारा)/Inspection
ारा
Required (By
Empanelled Inspection Authority / Agencies
pre-registered with GeM)

No

Payment Timelines

Payments shall be made to the Seller within 45 days of
issue of consignee receipt-cum-acceptance certificate
(CRAC) and on-line submission of bills (This is in
supersession of 10 days time as provided in clause 12 of
GeM GTC)

मू यांकन प ित/Evaluation
ित
Method

Total value wise evaluation

म य थता खंड /Arbitration Clause

No

सुलह खंड /Mediation Clause

No

ईएमड

ववरण/EMD
ववरण
Detail

एडवाईजर बक/Advisory Bank

State Bank of India

2/7

<!-- page 3 -->

ईएमड रािश/EMD Amount

103000

ईपीबीजी ववरण /ePBG Detail
एडवाइजर बक/Advisory Bank

State Bank of India

ईपीबीजी

5.00

ितशत (%)/ePBG Percentage(%)

ईपीबीजी क आव यक अविध (माह) /Duration of ePBG
required (Months).

6

(a). जेम क शत के अनुसार ईएमड छूट के इ छुक बडर को संबंिधत केटे गर के िलए बड के साथ वैध समिथत द तावेज़ तुत करने है । एमएसई
केटे गर के अंतगत केवल व तुओं के िलए विनमाता तथा सेवाओं के िलए सेवा दाता ईएमड से छूट के पा ह। यापा रय को इस नीित के दायरे से
बाहर रखा गया है ।/EMD EXEMPTION: The bidder seeking EMD exemption, must submit the valid supporting document
for the relevant category as per GeM GTC with the bid. Under MSE category, only manufacturers for goods and
Service Providers for Services are eligible for exemption from EMD. Traders are excluded from the purview of this
Policy.
(b).ईएमड और संपादन जमानत रािश, जहां यह लागू होती है , लाभाथ के प
in favour of Beneficiary, wherever it is applicable.

म होनी चा हए। / EMD & Performance securityshould be

लाभाथ /Beneficiary :
PRINCIPAL
HJ BHABHA GOVT ITI MAYUR VIHAR PHASE 1 DELHI 91, Training and Technical Education Department Delhi, N/A,
(Principal Iti Mayur Vihar)
बोली वभाजन लागू नह ं कया गया/ Bid splitting not applied.
एमएसई खर द वर यता/MSE
यता
Purchase Preference
एमएसई खर द वर यता/MSE Purchase Preference

No

एमआईआई खर द वर यता/MII
यता
Purchase Preference
एमआईआई खर द वर यता/MII Purchase Preference

No

1. The minimum average annual financial turnover of the bidder during the last three years, ending on 31st
March of the previous financial year, should be as indicated above in the bid document. Documentary evidence in
the form of certified Audited Balance Sheets of relevant periods or a certificate from the Chartered Accountant /
Cost Accountant indicating the turnover details for the relevant period shall be uploaded with the bid. In case the
date of constitution / incorporation of the bidder is less than 3-year-old, the average turnover in respect of the
completed financial years after the date of constitution shall be taken into account for this criteria.
2. Experience Criteria: In respect of the filter applied for experience criteria, the Bidder or its OEM of the product
offered in the bid {themselves or through reseller(s)} should have regularly, manufactured and supplied same or
similar Category Products to any Central / State Govt Organization / PSU for number of Financial years as
indicated above in the bid document before the bid opening date. Copies of relevant contracts and delivery
acceptance certificates like CRAC to be submitted along with bid in support of having supplied some quantity
during each of the Financial year. In case of bunch bids, the category of primary product having highest value
should meet this criterion.
3. OEM Turn Over Criteria: The minimum average annual financial turnover of the OEM of the offered product
during the last three years, ending on 31st March of the previous financial year, should be as indicated in the bid

3/7

<!-- page 4 -->

document. Documentary evidence in the form of certified Audited Balance Sheets of relevant periods or a
certificate from the Chartered Accountant / Cost Accountant indicating the turnover details for the relevant period
shall be uploaded with the bid. In case the date of constitution / incorporation of the OEM is less than 3 year old,
the average turnover in respect of the completed financial years after the date of constitution shall be taken into
account for this criteria.
4. Past Performance: The Bidder or its OEM {themselves or through re-seller(s)} should have supplied same or
similar Category Products for 50% of bid quantity, in at least one of the last three Financial years before the bid
opening date to any Central / State Govt Organization / PSU. Copies of relevant contracts (proving supply of
cumulative order quantity in any one financial year) to be submitted along with bid in support of quantity
supplied in the relevant Financial year. In case of bunch bids, the category related to primary product having
highest bid value should meet this criterion.
5. Reverse Auction would be conducted amongst first 50% of the technically qualified bidders arranged in the
order of prices from lowest to highest. Number of sellers eligible for participating in RA would be rounded off to
next higher integer value if number of technically qualified bidders is odd (e.g. if 7 bids are technically qualified,
then RA will be conducted amongst L-1 to L-4). In case number of technically qualified bidders are 2 or 3, RA will
be between all without any elimination. If Buyer has chosen to split the bid amongst N sellers, then minimum N
sellers would be taken to RA round. In case Primary products of only one OEM are left in contention for
participation in RA based on lowest 50% bidders qualifying for RA, the number of sellers qualifying for RA would
be increased to get at least products of one more OEM (directly participated or through its reseller) if available.
Further, if bid(s) of any seller(s) eligible for MSE preference is / are coming within price band of 15% of Non MSE
L-1 or if bid of any seller(s) eligible for Make in India preference is / are coming within price band of 20% of non
MII L-1, then such MSE / Make in India seller shall also be allowed to participate in the RA process.

PORM ( 1 set )
तकनीक

विश याँ /Technical Specifications

े ता विश द तावेज़ /Buyer
Specification Document

Download

परे षती/
षती/ रपो टग अिधकार तथा मा ा/Consignees/Reporting
ा
Officer and Quantity

.सं. /S.N
o.

1

परे षती/
षती/ रपो टग
अिधकार /Consignee
Reporting/Officer
Jitender Singh

े ता

ारा जोड़ गई बड क

पता/Address
पता

110091,HJ BHABHA GOVT ITI
PHASE 1 MAYUR VIHAR DELHI

मा ा /Quantity

1

डलीवर के दन/Delivery
दन
Days

15

वशेष शत /Buyer Added Bid Specific Terms and Conditions

1. Provisions for workmen compensation, insurance, public liability, property damage, insurance etc. to be
ensured by the contractor. Also, safety measures prescribed for working in Extra High Voltage & use of
personnel protective equipment must be adhered to.
2. Generic
Data Sheet of the product(s) offered in the bid, are to be uploaded along with the bid documents. Buyers
can match and verify the Data Sheet with the product specifications offered. In case of any unexplained
mismatch of technical parameters, the bid is liable for rejection.
3. Certificates

4/7

<!-- page 5 -->

Bidder's offer is liable to be rejected if they don't upload any of the certificates / documents sought in the
Bid document, ATC and Corrigendum if any.
4. Certificates
ISO 9001: The bidder or the OEM of the offered products must have ISO 9001 certification.
5. Forms of EMD and PBG
Bidders can also submit the EMD with Fixed Deposit Receipt made out or pledged in the name of A/C
PRINCIPAL ITI MAYUR VIHAR
. The bank should certify on it that the deposit can be withdrawn only on the demand or with the sanction
of the pledgee. For release of EMD, the FDR will be released in the favour of the bidder by the Buyer after
making endorsement on the back of the FDR duly signed and stamped along with covering letter. Bidder
has to upload scanned copy/ proof of the FDR along with bid and has to ensure delivery of hardcopy to the
Buyer within 5 days of Bid End date/ Bid Opening date
6. Forms of EMD and PBG
Successful Bidder can submit the Performance Security in the form of Fixed Deposit Receipt also (besides
PBG which is allowed as per GeM GTC). FDR should be made out or pledged in the name of
PRINCIPAL ITI MAYUR VIHAR
A/C (Name of the Seller). The bank should certify on it that the deposit can be withdrawn only on the
demand or with the sanction of the pledgee. For release of Security Deposit, the FDR will be released in
favour of bidder by the Buyer after making endorsement on the back of the FDR duly signed and stamped
along with covering letter. Successful Bidder has to upload scanned copy of the FDR document in place of
PBG and has to ensure delivery of hard copy of Original FDR to the Buyer within 15 days of award of
contract.
7. Financial Criteria
NET WORTH: Net Worth of the OEM should be positive as per the last audited financial statement.
8. Rate Contract
Bidder's offer is liable to be rejected if they dont upload any of the certificates / documents sought in the
Bid document, ATC and Corrigendum if any.
9. Buyer Added Bid Specific ATC
Buyer uploaded ATC document Click here to view the file .
10. Turnover
Bidder Turn Over Criteria: The minimum average annual financial turnover of the bidder during the last
three years, ending on 31st March of the previous financial year, should be as indicated in the bid
document. Documentary evidence in the form of certified Audited Balance Sheets of relevant periods or a
certificate from the Chartered Accountant / Cost Accountant indicating the turnover details for the
relevant period shall be uploaded with the bid. In case the date of constitution / incorporation of the
bidder is less than 3 year old, the average turnover in respect of the completed financial years after the
date of constitution shall be taken into account for this criteria.
11. Turnover
OEM Turn Over Criteria: The minimum average annual financial turnover of the OEM of the offered product
during the last three years, ending on 31st March of the previous financial year, should be as indicated in
the bid document. Documentary evidence in the form of certified Audited Balance Sheets of relevant
periods or a certificate from the Chartered Accountant / Cost Accountant indicating the turnover details for
the relevant period shall be uploaded with the bid. In case the date of constitution / incorporation of the
OEM is less than 3 year old, the average turnover in respect of the completed financial years after the
date of constitution shall be taken into account for this criteria. In case of bunch bids, the OEM of

5/7

<!-- page 6 -->

CATEGORY RELATED TO primary product having highest bid value should meet this criterion.
12. Service & Support
Escalation Matrix For Service Support : Bidder/OEM must provide Escalation Matrix of Telephone Numbers
for Service Support.
13. Service & Support
Dedicated /toll Free Telephone No. for Service Support : BIDDER/OEM must have Dedicated/toll Free
Telephone No. for Service Support.
14. Past Project Experience
Proof for Past Experience and Project Experience clause: For fulfilling the experience criteria any
one of the following documents may be considered as valid proof for meeting the experience criteria:a.
Contract copy along with Invoice(s) with self-certification by the bidder that service/supplies against the
invoices have been executed.b. Execution certificate by client with contract value.c. Any other document
in support of contract execution like Third Party Inspection release note, etc.Proof for Past Experience and
Project Experience clause: For fulfilling the experience criteria any one of the following documents may be
considered as valid proof for meeting the experience criteria:a. Contract copy along with Invoice(s) with
self-certification by the bidder that service/supplies against the invoices have been executed.b. Execution
certificate by client with contract value.c. Any other document in support of contract execution like Third
Party Inspection release note, etc.
15. Generic
Actual delivery (and Installation & Commissioning (if covered in scope of supply)) is to be done at
following address
ITI
MAYUR
VIHAR
DELHI
DELHI-110091
.

अ वीकरण/Disclaimer
The additional terms and conditions have been incorporated by the Buyer after approval of the Competent
Authority in Buyer Organization, whereby Buyer organization is solely responsible for the impact of these clauses
on the bidding process, its outcome, and consequences thereof including any eccentricity / restriction arising in
the bidding process due to these ATCs and due to modification of technical specifications and / or terms and
conditions governing the bid. If any clause(s) is / are incorporated by the Buyer regarding following, the bid and
resultant contracts shall be treated as null and void and such bids may be cancelled by GeM at any stage of
bidding process without any notice:1. Definition of Class I and Class II suppliers in the bid not in line with the extant Order / Office Memorandum
issued by DPIIT in this regard.
2. Seeking EMD submission from bidder(s), including via Additional Terms & Conditions, in contravention to
exemption provided to such sellers under GeM GTC.
3. Publishing Custom / BOQ bids for items for which regular GeM categories are available without any
Category item bunched with it.
4. Creating BoQ bid for single item.
5. Mentioning specific Brand or Make or Model or Manufacturer or Dealer name.
6. Mandating submission of documents in physical form as a pre-requisite to qualify bidders.
7. Floating / creation of work contracts as Custom Bids in Services.
8. Seeking sample with bid or approval of samples during bid evaluation process. (However, in bids for
attached categories, trials are allowed as per approved procurement policy of the buyer nodal Ministries)
9. Mandating foreign / international certifications even in case of existence of Indian Standards without

6/7

<!-- page 7 -->

specifying equivalent Indian Certification / standards.
10. Seeking experience from specific organization / department / institute only or from foreign / export
experience.
11. Creating bid for items from irrelevant categories.
12. Incorporating any clause against the MSME policy and Preference to Make in India Policy.
13. Reference of conditions published on any external site or reference to external documents/clauses.
14. Asking for any Tender fee / Bid Participation fee / Auction fee in case of Bids / Forward Auction, as the
case may be.
15. Buyer added ATC Clauses which are in contravention of clauses defined by buyer in system generated bid
template as indicated above in the Bid Details section, EMD Detail, ePBG Detail and MII and MSE Purchase
Preference sections of the bid, unless otherwise allowed by GeM GTC.
16. In a category based bid, adding additional items, through buyer added additional scope of work/ additional
terms and conditions/or any other document. If buyer needs more items along with the main item, the
same must be added through bunching category based items or by bunching custom catalogs or
bunching a BoQ with the main category based item, the same must not be done through ATC or Scope of
Work.
Further, if any seller has any objection/grievance against these additional clauses or otherwise on any aspect of
this bid, they can raise their representation against the same by using the Representation window provided in
the bid details field in Seller dashboard after logging in as a seller within 4 days of bid publication on GeM. Buyer
is duty bound to reply to all such representations and would not be allowed to open bids if he fails to reply to
such representations.

All GeM Sellers/Service Providers shall ensure full compliance with all applicable labour laws,
including the provisions, rules, schemes and guidelines under the four Labour Codes i.e. the Code
on Wages, 2019; the Industrial Relations Code, 2020; the Occupational Safety, Health and Working
Conditions Code, 2020; and the Code on Social Security, 2020 as and when notified and brought into
force by the Government of India.
For all provisions of the Labour Codes that are pending operationalisation through rules, schemes or
notifications, the corresponding provisions of the pre-existing labour enactments (such as The
Minimum Wages Act, 1948, The Payment of Wages Act, 1936, The Payment of Bonus Act, 1965, The
Equal Remuneration Act, 1976, The Payment of Gratuity Act, 1972, etc. and relevant State Rules)
shall continue to remain applicable.
The Seller/ Service Providers shall, therefore, be responsible for ensuring compliance under:
All notified and enforceable provisions of the new Labour Codes as mentioned hereinabove;
and
All operative provisions of the erstwhile Labour Laws until their complete substitution.
All obligations relating to wages, social security, safety, working conditions, industrial relations etc.
and any other statutory requirements shall be strictly met by the Seller/ Service Provider. Any noncompliance shall constitute a breach of the contract and shall entitle the Buyer to take appropriate
action in accordance with the contract and applicable law.
यह बड सामा य शत के अंतगत भी शािसत है /This Bid is also governed by the General Terms and Conditions
जेम क सामा य शत के खंड 26 के संदभ म भारत के साथ भूिम सीमा साझा करने वाले दे श के बडर से खर द पर
भारत के साथ भूिम सीमा साझा करने वाले दे श का कोई भी बडर इस िन वदा म बड दे ने के िलए तभी पा
स म

ितबंध के संबंध म

होगा जब वह बड दे ने वाला

ािधकार के पास पंजीकृ त हो। बड म भाग लेते समय बडर को इसका अनुपालन करना होगा और कोई भी गलत घोषणा कए जाने

व इसका अनुपालन न करने पर अनुबंध को त काल समा

करने और कानून के अनुसार आगे क कानूनी कारवाई का आधार होगा।/In terms

of GeM GTC clause 26 regarding Restrictions on procurement from a bidder of a country which shares a land border with India, any bidder from a country which shares a
land border with India will be eligible to bid in this tender only if the bidder is registered with the Competent Authority. While participating in bid, Bidder has to undertake
compliance of this and any false declaration and non-compliance of this would be a ground for immediate termination of the contract and further legal action in
accordance with the laws.

---ध यवाद /Thank You---

7/7
