---
doc_id: "abd5a5d42b8fbcde"
source_url: "https://ncc.delhi.gov.in/sites/default/files/ncc/circulars-orders/rr_driver.pdf"
ministry: "Directorate of National Cadet Corps, Delhi"
title: "Download"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d2a473b43402e1d1"
---

<!-- page 1 -->

(

L TER RIT OR Y OF DE LHI
GO VER NM ENT OF NAT ION AL CA Pl"A
ME NT
NAT ION AL CAD ET CO }!~S DEP ART
.NE W DE LHI -11 008 9.
NCC BHA WA N, RO HIN I SEC TOR --19
AIL: aos tate ncc @gm ail.c om
TEL EPH ON E NO. 011 -20 873 212 E-M
3 / I la\
No.F.9(92 )AO -NC C/E x-C adre /HV D /202

• Dated: ,,~r lr

PUBLIC NOTICE
seek s
ent of National Capital Terr itor y o( Delhi
National Cadet Corps Dep artm ent, Gov ernm
nary
Ordi
cle)
ruitm ent Rules of Driv er (Heavy Mot or Vehi
view s/co mm ents on the encl osed draf t Rec
up-' B'
, Non-Ministerial pos t and Special Grad e Gro
etted
-Gaz
Non
'
p-'C
Grou
e-I,
Grad
and
e-II
Grade, Grad
ired und ~r the
Dep artm ent from all stak eho lder s as requ
Non-Gazetted, Non-Ministerial post of this
Dep artm ent,
8-Es tt.(R R) date d 13.1 0.20 15 and Serv ices
Para-2 of DoPT's OM No.AB-14017 /61/ 200
s/20 21/S -IV/676 -680 date d: 06/0 4/20 21.
Gov t of NCT of Delhi Circular No.F .2(1 )/RR
icat ed to
draf t Rec ruitm ent Rules may be com mun
d
esai
afor
on
ents
mm
s/co
view
The
2.
il.co m
of Delhi thro ugh ema il to aost aten cc@ gma
NCT
of
.
Govt
ent,
artm
Dep
s
Corp
et
Cad
National
o~.J.0.11/.'JJ:Ji.r
with in 30 days of this public notice i.e. by ...

Dep uty Dir ecto r Gen era l, NCC

-\iffl&ll~~/CMDE
To
All Stakeholders.

~1114"1 '3tf &Jt51rl~~i$/Officiating DOG
Pl4~11(1~ (~)/ NCC Ote {DelbiJ
~~

m

i

ing, Delh
of Info rma tion Technology, 9th Level 'B'-W
Copy t~: System A~alyst, Dep ~rtm ent
Noti ce on the web site of NCC
0002, with the requ est to uplo ad this Pub lic
Secretariat, New Delhi-11
Department, Govt. of NCT of Delhi.

I

<!-- page 2 -->

I
VEHICLE)
POST OF DRIVER (HEAVY MOTOR
RECRUITMENT RULES FOR THE
HI
ARTMENT, GNCT OF DEL
ORDINARY GRADE IN R/O NCC DEP

SCHEDULE
----------~
-·-- - · - - - - - - -Dep
artm ent
Jces
--ed by Serv

.- - __!~E?Vi~fc~ns agre
Column No.
- - - - - - - - - Dr Iver f~ea vy Motor Vehicle) Ord inar y Grade
~
1:-Name of the Pos t
1
- - - - - - - - - - - - r - - -06 * (20 2] J
1---+---------ad.

)

J

I

2

Number of Post

3

Classification

work-lo
*Subject to variation dep end ent on
ial, Non-Gazetted, Group
ister
-Min
Non
ice,
Serv
General Central

.

-----------

4

5
16

'C'.

---·--- ----

Pay Level in the Pay Matrix

Whe ther Selection or Non Selection
Age limi t for Direct Rec ruits

.

post.

---------1
-------------

Level-2
(Rs. 19,900-63,200/-)
in the Pay Matrix.
Not Applicable

18-25 years*
upto 40 year s in acco rdan ce
(Relaxable for gov ernm ent serv ants
ed by the Central
with the inst ruct ions or orde rs issu
Government.)
ing the age limi t shaJJ be as
Note:- The crucial date for dete rmin
.
Aut hori ty.
adve rtise d by DSSSB /Co mpe tent
the
,
tion
peti
Gom
n
Ope
all-India
*In case of pos t bein g filled up by
.
rs
yea
27
and
r
age limit ~ou ld be betw een 18 yea

__ ___
__ __ __ __ __ __ __ __ired__
Essential:
for

.___

7

I

I
I

requ
Educational & othe r qualifications
dire ct recr uitm ent

.
1. Pass in 10th stan dard .
icle)
Veh
or
nse (He avy Mot
2. Possession of a Valid Driving Lice
/
for aJI type s of vehicle.
be
ld
shou
te
dida
can
ism (the
3. Knowledge of Mot or mec han
vehicle).
in
cts
defe
or
min
ove
rem
able to
for at leas t thre e year s.
Car
4. Experience of Driving a Mot or
e Gua rd/C ivil
Hom
as
ice
Desirable:_ Thre e yea rs' serv

Volu ntee rs.
at the discretion of the
Note 1: Qualifications are relaxable
idates otherwise well
cand
of
Competent Authority in the case
qualified.
able at the

g experience is relax
Note 2: The qualification(s) regardin
ority in the ca~e of candicmtes
discretion of the Competent Auth
Scheduled Tribes if at any stage of
belonging to Scheduled Castes or
is of the opinion that sufficient
selection the Competent Authority
e communities possessing the
number of candidates from thes
/
y to be available to fiW up the
requisite experience are not likel
1
-----------ca nc r reJ~!:y_e_d_fo_r_t_h_em_.- -

I

--- --- -J _. :va
----:;:; --t -:~ -:- --- --- --onal Qualifications
8
cati
Edu
&
age
Whether
Not Applicable.
apply in case of
prescribed for dire ct recr uits will
Promotees.
Two yea rs for dire ct recr uits .
19
_ _ _ _ _J__ _ _ _ _ _
,:P;:er:iio~d~o:.:f_:.P~r~ob~a~t~io~n~,1~·f~a~ny~_ _ _
10 1 Merhod of Recruitment whe ther by Direct
lO
by
or
by Direct Recruitment.
Prom otio n
by
Recruitment or
Dept1lat,on/ Absorption failing which
• & perc enta ge of the
utation/a bsorpt1on
Dep
. .
---~
hod s
-- - - - - - - - - - - - - - - - - - --!~ can ~es to be fiJJed by various met

L

<!-- page 3 -->

(
l1~ In case of Recruitment by Prom otion /
Deputation/ absorption, grade s from which
Prom otion /depu tation /
absorption to be made.

Depu tation /Absorption:
nment or Union
Officers of the Central Gove rnmen t/Stat e Gover
Territories:
basis in the pare'nt
(a)(i) Holding analogous post on a regula r
•
cadre or depar tment

j

Or
in Level-1 (18,000(ii) From amon gst Group C emplo yees
of regul ar service
years
three
with
x
Matri
56,90 0/-) in Pay
in the of~ice where \
le
vehic
having driving license of heavy moto r
yees m Lev.el-1 \
emplo
C
Group
from
which
failing
vacancy arises
of regul ar
years
three
with
x
(18,0 00-56 ,900/- ) in Pay Matri
territo ries
t/UT
rnmen
Gove
e
t/Stat
rnmen
Gove
al
service m Centr
ard to be 1
stand
priate
appro
of
subject to passing of the trade test
D.
GNCT
t,
rtmen
Depa
port
condu cted by Trans

I

and
as presc ribed in
(b) posse ssing the qualification and exper ience
Column no.7

I

ing the perio d of
Note 1: The perio d of deput ation includ

diatel y prece ding
deput ation in anoth er ex-ca dre post held imme
other
some
or
same
the
in
appoi ntmen t
this
Gove rnme nt shall
al
Centr
the
of
nt
artme
n/Dep
izatio
organ
ordin arily not exceed three years .

I
I

If a DPC exists what is its Comp ositio n

13

lted in
Circumstances in which U.P.S.C. to be consu
t
itmen
makin Recru

\

\J
e

s

I

I

nt • by
The maxim um age limit for aRpo intme
on the
as
Years
56
ding
Excee
Not
be
shall
deput ation /abso rption
closin date of recei t of a lication.
Group 'C' DCC (for consi derin g confi rmati on):
n
1. Addi. Direc tor General, NCC- Chairperso
2. Dy. Direc tor General, NCC - Mem ber
re)-Member
3. Spl. Director/ADDI. Direc tor (Social Welfa
ber
Mem
)(GAD
tary
Secre
4. Dy.
rtmen tal Confi rmati on
Note: Senio r most mem ber of t~e Depa
in case the notifi ed
n
perso
Chair
as
Comm ittee shall act
irmat ion Comm ittee
Chair perso n of the Depa rtmen tal Conf
of the Depa rtmen tal
happe ns to be junio r to anoth er mem ber
Confi rmati on Comm ittee
ission is not
Consu ltatio n with Union Publi c Servi ce Comm
sar
neces
Note

12

)

2:

rnor
By order and in the Name of the Lt. Gove
Delhi
of
tory
Terri
al
Natio nal Capit

(BRIG. ATULYA BAMZAI)
D00/HOO,NCC

J

<!-- page 4 -->

I

I

Y MOTOR VEHICLE)
RECRUITMENT RULES FOR THE POST OF DRIVER (HEAV
GRADE-II IN R/O NCC DEPARTMENT, GNCT OF DELHI
~fil!J J.LE
Column No.

1
2

Name of the Post
Number of Post

3

Classification
Pay Level in the Pay Matrix

4

Provis ions agreed by Servic es Depar tment
Driver (Heavy Motor Vehicle) Grade-JI
05 * (2023)
*i.iubje ct to variati on depend ent on work-l oad.
'C'.,
- Ge~cra)(:entr~I-S~rvi~e, Non-Ministerial, Non-Gazetted, Group
- - - -Level-4

(Rs. 25,500 -81,10 0/-)
in the Pay Matrix.
Non- Selection
Whether Selection or Non selecti on post.
-----------------i
;=-::= :=---- -'----- t------ -- - · - - - 5
;:~~;:
:-::-::-:-;:~::--Not Applicable.
._:_~
ts
Recrui
- 6 Age limit for Direct
Not Applicable.
onal & other qualification
7 Educati
required for direct Recruits.
Whether Age & Educational
8
Not Applicable.
Qualifications prescri bed for direct
recruits will apply in case of Promo tees.
Not Applicable.
Period of Probation, if any
9
10 Method of Recrui tment wheth er by direct
recruitment or by promo tion or by
By promo tion.
Deputation/absorption & percen tage of
the vacancies to be filled by variou s
methods
Promo tion
Promo tion /
level-2 (Rs.
I 11 In case of recruit ment Bygrades
Driver (Heavy Motor Vehicle) Ordina ry Grade in the pay
from
Deputation/ absorp tion,
and subjec t
grade
the
in
service
r
19,900-63,200) with 8 years of regula
which promo tion/de putatio n/
condu cted
be
to
rd
standa
riate
approp
of
est
to the passing of the trade-t
absorption to be made.
I
.
GNCTD
ment,
by Transp ort Depart
Note:service 1
Where juniors who have comple ted their qualify ing/eli gibility
be
also
would
s
senior
their
tion,
are being consid ered for promo
ing/
qualify
ite
requis
the
of
short
not
are
they
ed
consid ered provid
ing/ eligibility
eligibility service by more than half of such qualify
compl eted
sfully
succes
service, or two years, whiche ver is less, and have
with
along
grade
higher
next
the
to
their probat ion period for promo tion
lity
eligibi
ing/
qualify
such
eted
compl
y
alread
.
their juniors who have
.
service
Group-'C' DPC for consid ering promo tion:12 If a DPC exists, what is its compo sition
1. Additional Directo r General, NCC - Chairperson.
- Memb er.
Dy. Directo r General, NCC
2.
\.Yelfare)
(Social
or
- Memb er.
Spl. Direct or/ Addi. Direct
3.
er.
Memb
(GAD)
4. Dy. Secret ary
Comm ittee
Note: Senior most memb er of the Depar tmenta l Promo tion
of the
erson
Chairp
d
notifie
the
case
in
erson
shall act as Chairp
r
anothe
to
Depart mental Promo tion Comm ittee happe ns to be junior
ittee.
Comm
memb er of the Depart mental Promo tion
13
Circumsta nces in which U.P.S.C. to be
not necessar_y
Consultatio11 with Union Public Servic e Comm ission is ___
consulted in making recruit ment
___
-- ---- ___ ___ ___ ___ ___ .
I

i

___)

By order and in the Name of the Lt. Gover nor
Nation al Capital Territo ry ,of D~lhi

(BRIG . ATUL YA BAMZ AIJ
DDG/ HOO ,NCC

<!-- page 5 -->

I

(
Y MOTOR VEHICLE)
RECRUITMENT RULES FOR THE POST OF DRIVER (HEAV
DELHI
OF
GNCT
NT,
RTME
GRADE-I IN R/0 NCC DEPA
SCHEDULE
Post
Driver (Heavv Motor Vehicle) Grade-I
1 Name of the
i..--Post
of
r
06* (2023)
Numbe
2
_____ ,i,_?_!~~ject to variation depend ent on workload.
'C'.
Classification
Gcnl'rnl Ccnrral)~c,:_yice, Non-Ministerial, Non-Gazetted, Group
3
Level-5
Pay Level in the Pay Matrix
4
(Rs. 29,200 -92,30 0/-)
in the Pay Matrix.
Non- Selection
post.
on
Selecti
Non
or
on
Selecti
er
Wheth
5
Applicable
Not
ts
Recrui
Direct
for
limit
Age
6
-- - -~- -able
Applic
Not
ed
Educational & other qualification requir
7
for Direct Recruits.
,
Wheth er Age & Educat ional Qualifications
8
Not Applicable
prescr ibed for direct recruit s will apply in
case of Promo tees.
Not Applicable
Period of Probat ion, if anv
9
'
direct
by
10 Metho d of Recrui tment wheth er
by
or
tion
Promo
by
recruit ment or
By promo tion
Deput ation/a bsorpt ion & percen tage of the
vacanc ies to be filled bv variou s metho ds
Promo tion:11 In case of recrui tment by Promo tion /
-81,10 0 in I
which
Driver (Heavy Motor Vehicle) Grade-II in Level-4 Rs. 25,500
from
grades
Deput ation/ absorp tion
Subje.ct I
and
grade
the
in
the pay matnx with 5 years of regula r service
promo tion/d eputat ion/
ted
conduc
be
to
rd
absorp tion to be made.
to the passin g of the trade test of approp riate standa
I
by Transp ort Department, GNCTD.

~

~

.

I

7

Il
I

I

I

.I
I
I

Note:-

12

If a DPC exists, what is its compo sition

I
I

I
13

Circumstances in which UPSC
consulted in making recrui tment

to

y,servk e
Where juniors who have compl eted their qualify ing/eli gibilit
also be
would
are being consid ered for promo tion, their senior s
qualify ing/
consid ered provid ed they are not short of the requis ite
eligibiltty
eligibility service by more than half of such qualify ing/
eted
compl
sfully
succes
have
and
less,
is
service or two years, whiche ver
with
along
grade
higher
next
probat ion period for promo tion to the
eligibility
their juniors who have alread y compl eted such qualify ing/
service.
Group-'C' DPC for consid ering promo tion:I
1. Additional Direct or General, NCC - Chairp erson .
- Memb er.
Dy. Direct or General, NCC
2.
-·Mem ber.
Spl. Direct or/ Addi. Direct or (Social Welfar e)
3.
er
Memb
Dy. Secret ary (GAD)4.
tion Comm ittee
Note: Senior most memb er of the Dep~r tmenta l Promo
erson. of ~he
d
Chairp
notifie
in
the
case
erson
Chairp
shall act as
to anothe r
junior
be
to
ns
happe
ittee
Comm
tion
Depart mental Promo
memb er of the Depar tmenta l Promo tion Comm ittee
be
necess ary
Consu ltation with Union Public Servic e Comm ission is not

I

? I

I

s
f
t

.

By order and in the Name of the Lt. Govern or
Nation al Capital Territo ry of Delhi

(BRIG . ATULYA BAMZAI)
DDG /HOO , NCC

r

<!-- page 6 -->

r

I
,_

I

1
2

i--

....-

RECRUITMENT RULES FOR THE POST OF DRIVER (HEAVY MOTOR VEHICLE)
SPECIAL GRADE IN R/O NCC DEPARTMENT, GNCT OF DELHI

SHEDULE
Name of the Post
Number of Post
Classification
Pay Level in the Pay Matrix

3
4

....-

-s
6

7
8
I

19

10

I 11

Whether Selection or Non Selection post.
Age limit for Direct Recruits
Educational & other qualification required
for direct recruits.
Whether Age & Educational Qualifications
prescribed for direct recruits will apply in
case of Promotees.
Period of Probation, if any
Method of recruitment whether by direct
recruitment or by promotion or by
Deputation/a bsorption and percentage of
the vacancies to be filled by various
methods
In case of recruitment By Promotion/
Deputation/ absorption, grades from which
promotion/deputation/
absorption to be made.

Driver (Heavy Motor Vehicle) Special Grade
.
01* (2023)
1
__ Subject to variation deoendent on work-load.
C~eneral Central Servke, Non-Ministerial, Non-Gazetted, Group 'B'.

- ------·-

Level-6
(Rs. 35,400-1,12,4 00/-)
in the Pay Matrix.
Selection
Not Applicable
Not Applicable

.

.
,

.

Not Applicable

.

Not Applicable

.
By Promotion

I

I

Promotion:-

0 in
Driver (Heavy Motor Vehicle) Grade-I in Level-5 Rs. 29,200-92,30
the pay matrix having 06 years regular service in the grade ,and
subject to passing of the trade test of appropriate 'standard to be
conducted by the Transport Department, GNCTD.
Note:-

I

Where juniors who have completed their qualifying/ eligibility' service
are being considered for promotion, their seniors would also be
considered provided they are not short of the requisite qualifying/
eligibility service by more than half of such qualifying/ eligibility
service or two years, whichever is less, and have successfully
completed probation period for promotion to the next higher grade
along with their juniors who have already completed such qualifying/ I
J

12

If a DPC exists, what is its Composition

eligibility service.
Group-'8' DPC for considering promotion:I. Principal Secretary/Secretary (Labour), Govt. of NCT of DelhiChairperson
2. Additional Director General, NCC - Member.
3. Special Secretary / Addi. Secretary (TTE) - Member.
4. Dy. Director General, NCC - Member.
Note: Senior most member of the Departmenta l Promotion
Committee shall act as Chairperson in case the notified Chairperson of
the Departmental Promotion Committee happens to be junior to
another member of the Departmenta l Promotion Committee.

I

I

>

I
13

Circumstances in which U.P.S.C. to be
consulted in making Recruitment

Consultation with Union Public Service Commission is not necessary
---

--

By order and in the Name of the Lt. Governor

National Capital Territory of Delhi

(BRIG. ATULYA BAMZAI)
DDG/HOO ,NCC
