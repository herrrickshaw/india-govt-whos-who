---
doc_id: "abe20ee51c0fd9c9"
source_url: "https://forest.delhi.gov.in/sites/default/files/forest.delhi.gov.in/tender/short_terms_notice_inviting_quotations_from_the_authorized_firmsdealersupplier_for_supply_and_installation_of_video_conferencing_system_in_the_department_of_forest_wildlife_gnctd.pdf"
ministry: "Forest Department, Delhi"
title: "Tender Document"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "532ae0bfb2787eb1"
---

<!-- page 1 -->

sc a “GOVT. OF NCT OF DELHI |
DEPARTMENT OF FORESTS & WILDLIFE,
A-BLOCK, 2%” FLOOR, VIKAS BHAWAN, IP ESTATE, NEW DELHI-0002
M
F.No.4(62)/CF/HQ/Store/Video-Conference/202I-22/ 2834» UY Dated 29%)
SHORT TERM NOTICE INVITING SEALED QUOTATION TERM NOTICE INVITING SEALED QUOTATION
Notice inviting quotations (NIQ) is hereby issued for inviting quotations from the authorized
firms/dealer/supplier for Supply and Installation of Video Conferencing System in the Department of Forest &
Wildlife, GNCTD. The details are as under: :
. No eee es [Unit Qty. Rate stimate Cost
INR) INR)
Philips PSEO600 Pro 4k wired PTZ Camera with
7 हा voice tracking Pes ol
2: hilips PSE0SOl Smart Meeting Wireless Pes ol
“onference Microphone and Speakerphone
installation Charges as .
4
(*rate should be in the format” Rate/cost of item/work+ GST as applicable”)
The quotation and documents ‘should be sent in sealed cover in favour of the Department of Forest’s and
Wildlife, Govt. of NCT of Delhi”, हे
The quotation shoitld reach in this office latest by'02:00 PM on or before dated . 2Slo x] Zlovext
working day in case of Govt. Holiday) and the same will be opened on the same day at 02:30 PM by the Purchase
Committee. The rate should be quoted and GST should be indicating separately as per the’ prevailing GST Laws.
Quotation received after stipulated date and time will not be accepted/entertained and summarily will be rejected, in
case any dispute, the decision of the APCCF/HOD, A-Block, 2" Floor, Vikas Bhawan, IP Estate; New Delhi-
0002 should be final and binding.
TERMS & CONDITIONS OF THE NIQ & CONDITIONS OF THE Ni 2 i
l. Submission of quotation shall amount to bidder’s acceptance of the terms and conditions of the tender by
the bidder,
2. Mode of payment would be subject to satisfactory completion of work/supply and its verification.
3. Bidder shall quote the rates against this NIQ ona ‘single responsibility’ basis (“Rate/Cost of item/work+
GST as applicable”) so that the quotation price covers contractor’ all obligations and liabilities. The rates
and prices quoted by the Bidder shall be inclusive of all Charges/Taxes, The rate quoted shall be responsive
and the same should be inclusive of all statutory obligations.
4. The bidder should be from NCR and should be registered with/Trade & Taxes Department, Govt. of NCT
: of Delhi and should quote their GST Registration No, allotted by the Department of Trade & Taxes, Govt.
of NCT of Delhi, and PAN No, allotted by the Income Tax Department, Govt. of India.
5. The Dy. Conservator of Forests (HQ) reserves the right to accept and reject any or cancel any or all the
tenders/quotations without assigning any reasons therefore,
6. The rates quoted by the firm/agency shall remain valid for the entire period of current Financial Year i.e,
upto 3.03.2025 for the subject work and the Department shall not be responsible for payment of any extra .
on account of escalation of costs during the said period, हर

<!-- page 2 -->

/ at a. हे
5 व, The department shall not,be responsible for payment of any compensation on account of any loss caused to
the bidder/tender/quotation due to natural calamities or other supervening impossibilities.
8. The firm/agency abide by the provisions made under the labour laws/GST and other relevant Statutes as
applicable in execution of the work and shall be responsible for making good/payment of compensation, if
any, to any workman or material during execution of the contract.
9, In case of any dispute arising out of the execution of the term & condition of this short term quotation or
part thereof, the decision of the DCF (HQ), Govt. of NCT of Delhi shall be final and binding on both the
parties. In the event of the disputes still remaining unresolved, the appeal shall rest with the PCCF/HOD,
Dept. of Forests & Wildlife, Govt, of NCT of Delhi, whose decision shall be final and binding on both the
parties. i
0. All disputes arising out of the execution of the agreement shall be subject to the jurisdiction of the Court at
Delhi. : : :
: . (Jabestin A. IFS)
5 Deputy Conservator of Forests (HQ)
_ F.No.4(62)/CF/HQ/Store/Video-Conference/202-22/ २४४१६ ५५ ».ऐबवाल्व £2३| gyn है
Copy to:
l. The PA to APCCF/HOD, Department of Forests & Wildlife, GNCTD. t
2. The DCF (HQ)-Chairman-Purchase Committee, Department of Forests & Wildlife, GNCTD.
3. The Sr. Account Officer, Department of Forests & Wildlife, GNCTD. :
4.- The Store In-Charge, Department of Forests & Wildlife, GNCTD.
\_5-Programmer, Department of Forests & Wildlife, GNCTD with request to upload it on the Forest
website in Public Interest. रे हु
6. HQ-Notice Board for the notice of firms/agencies/workshops interested.
' . —Arvab ost :
: 2>0४(202%
fi (Jabestin A. IFS)
2 Deputy Conservator of Forests (HQ)
