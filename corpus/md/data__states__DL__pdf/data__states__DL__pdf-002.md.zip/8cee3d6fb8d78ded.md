---
doc_id: "8cee3d6fb8d78ded"
source_url: "https://dsssb.delhi.gov.in/sites/default/files/DSSSB/circulars-orders/notice_no_1667.pdf"
ministry: "Delhi Subordinate Services Selection Board"
title: "Download"
date: ""
pages: 4
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "d075a3f4e7a96a55"
---

<!-- page 1 -->

095558-0९॥002/3/2026-5६८४-०६॥ SUBORDINATE SERVICES SELECTION BOARD (05558) \787250/2026
| Pa oe | GOVERNMENT OF NCT OF DELHI
| ae | DELHI SUBORDINATE SERVICES SELECTION BOARD
rl rl a FC-8, INSTITUTIONAL AREA, KARKARDOOMA, DELHI-92
SSSB-CCI0C2T73/2026/2I23-273 ated: 22/70/2026
Result Notice No. 667
Post Name:- Bailiff under Post Code 25/25 in Registrar Cooperative
Societies

. The DSSSB vide its vacancy notice/Advertisement No. 02/25 dated 3/07/2025 with
closing date 6/09/2025 had advertised 44 vacancies [UR-07, OBD(D)-04, SC-02, Ews-
0i, PwBD Cat(a)-0, ESM-0t & SP-04] for the Post of Bailiff under Post Code
25/25 in Registrar Cooperative Societies.

2. The online written examination One Tier (General) for recruitment in respect of this post
was conducted on 27.02.2026 & 22.02.2026.

3. The Normalized marks obtained by 4923 candidates who appeared in Tier-I written
examination were uploaded on OARS and duly informed to the candidates through
DSSSB website vide Notice No.i640 dated 6/07/2026. Out 4923 , 58 qualified
candidates were shortlisted to upload documents in e-dossier module on OARS from
20/07/2026 to 03/08/2026 subject to attaining minimum qualifying marks and
correctness of the information furnished by the candidates in their online application
form.

4. The final result has been processed as Per merit in their respective category. As per the
Board’s resolution dated 4/07/2022, no scrutiny of documents uploaded in the e-
dossiers and of the other terms and conditions of recruitment notified by the
Board in the advertisement of the said post code has been done by the Board. The
eligibility as per Recruitment Rules and other terms and conditions as specified in the
advertisement no. 02/25 and relaxations as per rules in respect of educational
qualifications, experience, other certificates shall be scrutinized/verified by the User
Department for determining eligibility of the candidate for the Post code 25/25 as on
cutoff date 6/09/2025 before issuance of offer of appointment to the post.

5. The candidates having following roll numbers in Tier | exam are hereby provisionally
Nominated for the post of Bailiff under Post Code 25/25 in Registrar Cooperative
Societies, subject to fulfilling all conditions of eligibility and also correctness of the
information furnished by the candidates in their online application forms and e-dossiers:-

UR Category: 05
2502520008204]25025270000734]250257270007897]/25025727 0000455/250257270006785
OBC Category: 03
250252002835[25025727 004250|2502527004299)
SC Category: 02
25025277005666/250252700i674)
EWS Category: 04
'250257270006055]
PwBD CAT (a) Category: - 0(UR)
'250257209000774|
ESM Sub category: = 04(UR)
[2502527 004209)
0
Ook
ae bo

<!-- page 2 -->

095५558-0८॥0८2/3/20२6-5६८४३-०६ भा SUBORDINATE SERVICES SELECTION BOARD (DSSSB) (7487280/2026
SP Sub category: - 04 (OBC)

6. The provisional nomination of the above 4 candidates (UR-05, OBC-03, SC-02, EWs-
04, PWBD Cat (a)- 04 (UR), ESM- 04(UR) & SP- 04(OBC)] shall be further subject to
thorough verification of candidature of the candidate by the User Department including
the identity of the candidate.

7. The provisionally nomination of the above candidates shall further be subject to
genuineness of the documents on the basis of which they have claimed to have fulfilled
all the eligibility conditions as prescribed in the RRs and terms and conditions of the
advertisement inviting application and subject to thorough verification of their identity
with reference to their photographs, signature/handwriting, etc. on the application form,
admission certificate, etc. The Candidature of the above candidates are liable to be
cancelled by the User Department in case the candidates are found not to be fulfilling the
terms and conditions of the advertisement inviting applications for the said post code.
The Competent Authority of the Department concerned shall issue the appointment letter
to the candidates after being satisfied about their eligibility as laid down in the

recruitment rules and after verification of the correctness of the information furnished in
the application form and the documents related to Educational Qualification, Age and
other essential certificates.

8. The User Department shall also check the eligibility of the reservation benefit, if any.
Further, if applicable, the User Department shall verify the genuineness of the caste
Certificate furnished by the candidate prior to issuing offer of appointment to the
candidates. The Competent Authority of the User Department shall arrange to verify the
correctness of the information/documents as furnished in the e-dossier vis-a-vis the
original documents. User Department is requested to ascertain the scrutiny/correctness
of the same at their own level before issuing the offer of appointment to the provisionally
nominated candidates. Further, the appointing authority shall verify and satisfy itself
about the authenticity of documents/certificates and essential qualification for the post
before finally appointing the candidate. The User Department is also requested to
rectify/correct, in case, any minor/clerical error/deficiency noticed in the documents of the
candidate at their own level.

9. Itis stated that the User Department shall verify the genuineness of the caste certificate
furnished by the candidate in the light of Notification No. 3602/22-93-Estt. (SCT) dated
08/09/993 issued by DOPT and other instructions/guidelines issued from time to time
by the competent authorities prior to issuance of offer of appointment to the candidate. {t
is further stated that, prior to appointment , the User Department must satisfy, itself, that
the above candidates are fulfilling the necessary criteria as prescribed for entitlement of
OBC (Delhi) certificate as specified in various Orders/Guidelines/Circulars including
order dated 07/03/20i7 issued by Revenue Department, GNCTD after thorough
verification of caste certificate

0. The User Department shall also get the SC/ST/OBC/EWS/PWBD certificates veritied
from the issuing authority before his /her appointment.

. In case of EWS candidates, it may also be verified that the validity of EWS Certificate
should be as per DoPT OM No. 36039//204 9-ESTT(Res) dated 3/0/209 and other
instructions/guidelines issued from time to time by the competent authorities.

42. The Competent Authority of the Department concerned shall issue the appointment
letters to the candidates after being satisfied about their eligibility as laid down in the
Recruitment Rules and after verification of the correctness of the information furnished in
the application form and the documents related to education qualification, age and other
essential certificates as per Government of India instructions issued in this regards vide
MHA OM No. 2/29/54-RPS, 9/44/54.

3. The User Department shall ensure that the appointment made is in conformity with
DOPT guidelines and instructions of Govt. issued from time to time.

<!-- page 3 -->

05558-0८॥0८३2/३/2०२6-5६८२-०६ भा SUBORDINATE SERVICES SELECTION BOARD (05558) /487250/2026

4. Mere inclusion of the name of candidate in the result notice does not confer any right
upon the candidate over the post unless the appointing authority is satisfied after such
enquiry as may be considered necessary that the candidate is suitable in all respect for

appointment to the Post.
5. The category wise Normalized Cut off marks scored by the last provisionally nominated

candidate are as under:-

andidate provisionally nominates 05+ a 0 | । | | | | | | |
<<...
ESM

ormalized cut of marks of the last | | 9 | | |] || | | 22 ey 08 | |

aoe ॥। ॥॥॥॥ हि 8

lof 200)

WAITING PANEL LIST
6. Seven candidates [URWL-0, OBCWL-04 , SCWL-0I, EWSWL-04, PwBD_Cat(a)WL-04,
ESMWL-0I and SPWL-04] are hereby provisionally nominated as waitlisted candidate
for the Post of Bailiff under Post Code 25/25 in Registrar Cooperative
Societies.
[ORWL-07 7
SCWLo7_——]
EWSWL0T |
JESMWL-OF
7. The category wise Prorated cut off marks scored by the above mentioned Last selected
waitlist candidates are as under:
JURWE [OBCO)WEISCWL TEWSWL[PWED_Catla)WL[ESMWLSPWL]
lormalized cul of taarks of ।९|
last provisionally nominated| 74.43 }7.72} 75.86 470.00
r=] re frelon] rum [५६७७०

8. The User Department, being Cadre Controlling/Appointing Authority, shall strictly
follow the merit based ranking of the candidate in the main list and the waiting list.

49. The User Department, at its own level, will utilize the Waiting List only after
exhausting the main list and after affording sufficient opportunity to the
provisionally nominated candidates as per the extant guidelines issued by the
GNCTD/DoP&T.

20. The candidates in the Waiting Panel or the Balance Reserve Panel shall have no
claim or right for appointment per se against the vacancies notified for the
recruitment. They can only get the offer of appointment only in the event any
vacancies (category-wise) arising due to non-acceptance of the offer of
appointment, not joining the post after acceptance of appointment, resignation
after joining, etc within one year of validity of panel.

2i. While operating the waiting panel list, the User Department shall strictly follow
instructions issued vide DoP&T OM No. 3602/2/96-Estt. (Res) dated 02/07/997,
3604//98-Estt. (Res) dated 04/07/I998 and 43074/4/208-Estt, (Res) dated
04/04/208 regarding shifting of candidates from respective reserve categories to

a { uv
ye Qe

<!-- page 4 -->

05558-0८॥0९2/3/2०२6-५६८४-०६४॥ SUBORDINATE SERVICES SELECTION BOARD (DSSSB) ॥/787250/2026
the un-reserve category.

22. The User Department shall Operate the waiting panel up to the number of
vacancies notified under each category by the DSSSB in its advertisement and not
beyond it even by taking any type of relaxation from any authority as it shall render
the excess appointment void and illegal Ab initio.

23. The recruitment process for the Post of Bailiff under Post Code 25/25 in
Registrar Cooperative Societies has been closed. Further, the Main Result
list/Waiting panel of the candidates shall be valid up to 24/40/2027 i.e. one year
from the date of declaration of this main result.

24. The waiting panel is valid for a period of 4 year from the date of declaration of
main result for filling up the vacancies arising due to non-acceptance of the offer of
appointment, not joining the post after acceptance of appointment, resignation
after joining, etc within one year of validity of panel.

25. As soon as validity period of the waiting panel expires and /or number of notified
vacancies are filled up hence waiting panel becomes redundant, the User
Department shall return the cancelled and unutilized dossiers to DSSSB with
complete details/ statistics forthwith.

26. While every care has been taken in preparing the result, the DSSSB reserves the
right to rectify errors and omissions, if any detected at any stage.

27. Wherever the Court has directed to not declare result without leave of the court
such cases will be dealt separately, if falling in main result/proposed 20% waiting
panel list. The user department shall decide such cases subject to outcome of
court case(s).

28. The result is subject to the outcome of the court cases, if any, है jing in various
courts related to this post. ९. हर"

This issues with the approval of the Competent Authority. oe

DEPUTY ne SE DsssB
Ol
DSSSB-CCIl0C2/3/2026/223-232 Dated: 22/0/2026
Copy forwarded for information to:

. Jt. Secretary to Lt. Governor of Delhi, LG Secretariat, Dethi.

2. OSD to Chief Secretary of Delhi, Delhi Secretariat, Delhi.

3. Assistant Registrar (Admin), O/o Registrar Cooperative Societies, Old Court Building,
Parliament Street, GNCTD, New Delhi-0004 through P & P Branch.

4. Dy. Secretary (P&P), DSSSB

5. PS to Chairperson, DSSSB.

6. PS to Member, DSSSB.

7. PS to COE, DSSSB.

8. PS to Secretary, DSSSB.

9. SO (Plg.), Planning Branch, DSSSB

0. Dy. Director/System Analyst, IT Branch to upload Notice on the website of the Board.
