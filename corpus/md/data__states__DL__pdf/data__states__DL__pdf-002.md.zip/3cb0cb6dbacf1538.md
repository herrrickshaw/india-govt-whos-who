---
doc_id: "3cb0cb6dbacf1538"
source_url: "https://it.delhi.gov.in/sites/default/files/IT/circulars-orders/security_audit.pdf"
ministry: "Information Technology Department, Delhi"
title: "Download"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "2d3b84b7769e95a8"
---

<!-- page 1 -->

Government of NCT of Delhi हे
| Information Technology Departmen Maced
\@ gth न नि व के B-Wing, Delhi Secretariat, 420 027 पद गइ््म्ड a
ea:
॥ हर क2209-0(0९65)/5९0/ I7)/CD-93058/8 8a-T446 2
‘ 2 5 , 7 rtments
All Acs/Pr. Secretaries Secretaries/HoD's of Delhi Govt. Depa
et iCTD- Reg.
subject: Security Audit of Digital Infrastructure of departments of GN’ g
Madam/Sir,
| Security audit of Digital Infrastructure of the department is an important Se
cyber Security enhancement measures. In this regard, may please refer to this office ei
issued vide 42/2/20/9-0//0९65)/520/072/८0-299058///74-07 dated 28/03/2023 hae
conducting of Security Audit of the IT applications developed for the Departments of G
through CERT-In empaneled agency (Copy enclosed).
Dy It is requested that the departments may utilize the services of these experts for
conducting the security audit of the web portal/ applications. For this purpose, Department
shall apply online for security audit through ’ URL:
https://degs.org.in/SecurityServices.html . The process of sending the IT application
for security audit is given below:-
(a) To provide testing/staging URL of the application for security audit along with
credentials of each user of all types of roles in the application.
(b) Contact details & mail-id of officer/officials of concerned department for
communication.
(c) The security audit will be conducted by the audit team and if any vulnerability is
found then same will be conveyed/mailed to the concerned department.
a Concerned departments has to remove the vulnerability and inform the audit
(e) The application will again be checked b i i i
- - y audit team and this
continue till all the vulnerabilities are removed. proc, Will
(f) Security Audit Certificate will be issued/mailed to department.
3 It is reiterated that it is
their applications conducted at ane a ea eee ccety oudit of
architecture. Further, a nominal fee of Rs. 0 Saar ee 's change in code or in
charged from the Departments. RPO Plus GST applicable per audit will be 0
a ith yee”
This issues with the approval of competent authority. yee”
Encl: (tor (Dec)
ncl:A/a Director
Copy for information to:
l. SO to Chief Secretary/Chairm
2. PS to Pr. Secretary (IT)/ CEO (Deas)
3. PS to Spl. Secretary (IT)/ MS (DeGs)
