---
doc_id: "0571ffd3dcaa43ee"
source_url: "https://development.delhi.gov.in/sites/default/files/development/circulars-orders/tender_notice.pdf"
ministry: "Development Department, Delhi"
title: "Download"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f616479c2d09ce22"
---

<!-- page 1 -->

\

/

HUSBANDRY UNIT
T, GNCT OF DELHI
EN
TM
R
A
EP
D
T
EN
PM
DEVELO
RI, DELHI-1-10054
ZA
A
H
S
TI
I,
A
H
IT
M
L
RG, NEAR PU
ZORAWAR SINGH MA
89 01 74
T E L .N O .2 38 90 31 8, 23
ov@gmail.com
ig
lh
de
ah
or
ct
re
di
:ID
Mail
TOR: ANIMAL
l:C
IR
D
E
TH
F
O
E
IC
FF
O

ine/2025-26/ ~ ~ i
No.F.12(87)/AHD/Medic
& I BR/INCi/ DEV. (HQ)
R
),
Q
(H
or
ct
/4 e Dy. Dire
D iJ iy f\Jo .. .f..~,e,<?..... ,
t,
en
tm
ar
ep
D
t
en
Developm
Govt. of NCT of Delhi,
€ .J o - 7 -- -< c, ~ J '
,
J1
ad
D
Ro
ill
H
er
nd
U
9,
5/
Delhi-110054.
ement tender notice.
Sub: Publicity of e-procur
• •

• • • I I

•

• • • •, • • •

,

• • • • •

". )
Admn. Branch Dev. (t ·t
,,.
...... •
Dy. N"'....... ..
.::::Dat-t .......... L.¼l :-:,.1.1:S

b '11. ............

Sir,

vide Tender I.D No.
e
sit
eb
w
t
en
em
ur
oc
d on Delhi e-pr
ary Medicines from
rin
te
Ve
of
t
en
em
A tender was publishe
ur
oc
Pr
rding
dated 09-07-2025 rega
1
1_
24
75
_2
D
H
N
_A
25
20
6 on rate contract basis.
-2
25
20
ar
ye
e
th
r
fo
s
m
manufacturers I fir
d Tender Documents
an
e
tic
no
er
nd
te
t
en
em
copies of e-procur
ent GNCT of Delhi.
It is requested that the
tm
ar
ep
D
t
en
m
op
el
ev
D
on website of
may please be uploaded
English & Hindi
Encl: 1. Tender Notice in
2. Tender Documents

~ - l- '£

(Dr. Satyavir Singh)
Director (AH)

<!-- page 2 -->

OFFICE OF THE DIRECTOR: ANIMAL HUSBANDRY UNIT
DEVELOPMENT DEPARTMENT, GNCT OF DELHI
ZORAWAR SINGH MARG, NEAR PUL MITHAI, TIS HAZARI, DELHI-1100
54
TEL.NO.23890318,23890174
Mail ID:- directorahdelhigov@gmail.com

No.F.12(87)/AHD/Medicine/2025-26/

Date

E-Procurement Tender Notice

Animal Husbandry unit of Development Deptt, Govt. of Delhi is inviting tender
s through
E- Procurement of Procurement of Veterinary Medicines from manufacturer
s / firms for the year
2025-26 on rate contract basis. Only those bidders can apply who have valid
registration with
the application service provider of NIC, Delhi State Centre. Tende
r Enquiry I.D No.
2025_ANHD_275241_1 dated 09-07-2025
Last date/time for downloading of tender through e- 31-07-2025
at 3:00 PM
procurement solution.
Last date/time for submission/ receipt of tender through e- 31-07-2025
at 3:00 PM
procurement solution.
Last date/time for submission of Original EMO in physical 31-07-2025
at 3:00 PM
form in the office of Director, Animal Husbandry, Govt. of
NCT of Delhi.
Last date/time for submission of samples of medicines to the 31-07-2025 at 3:00
PM
In charge, V.O. Central Store, Veterinary Hospital Campus,
Palam.
Date and time of opening of Technical bids (online) by the 31-07-2025
at 3:30 PM
technical committee in the office of Director, Animal
Husbandry, Govt. of NCT of Delhi.
Date and time of opening of Financial bid (online) in the
office of Director, Animal Husbandry, Govt. of NCT of Delhi.
Will be informed later

The details are available on the home page of https://govtprocuremen
t.delhi.gov.in

~~-).,0 -,.,s-

Director (AH)

J

<!-- page 3 -->

l

-----cf>l~faq Pi&!(lcf>, QS{IQlet'1 ~ ' fclcf>lij ~'ijl l'J,

W ij~cf>I~

"11~,q~ ~
~

I

"IIT'f, f;rct;c ~

i

~-

~ ' W- 11o os4
~~: 238 903 18, 238 901 74
No. F.12(87)/AHD/Medicine/2025-26/

Dated:

f-~~G PIRlql ~~'11

1

l-~l~ 1{l4c ~m ;, t m~ ~
~:

~-~l ~l{~ ·c ~m ;, t m~ ~

·~~:

~

Plfct~I 61'3 ..kl16

cm cf>I •

31-07-2025 cf>T -

3:00

~(fq >

P1fct~1 '5fm mtm ta cf)B ct>1
31-07-2025 cf>T -

~i
(EMD) "'11ctcr> ~
-q Pl~~lcf>, 4S{l4lci1, Q1~2l W
tHct>I'< t ct>IQf~q -q '3lm cf)B cf>I Jflcfli ~:

,~~tti t ~

~,
~
Rlf<¼>~i' ~ , ~
~, ~
RlF<¼>ctil~Q 4~tH, 41~~ cf>1'3lmq)Bcf>1 Jfl cfl i~~
:

31-07-2025 cf>T -

~cHOI https://qovtprocurement.delhi.qov.in
t ~~

3:00

~(fq >

31-07-2025 cf>T -

3:00

~(fq >

acf>4lct>1 ~
cpl 3111~1~1 J~£11c1 acf>~ct>1 ~~RI g:m Pl~~lcf>,
31-07-2025 cf>T q~q1~1, Q1~~ W tHct>H t ct>IQf~q-q:
~
fct-d)q ~
cpl dtl1~1~1 J~£11c1 Pl~~lcf>, 4S{l4lci1, Q1~2l W
tHct>I'< t ct>IQf~q ll:

3:00

~(fq >

3:30

~-q ~fc pq i GIIQ~II

'CR 1-fi '34~ ~ ti

~~ :vv r
"q~o ff

f.'l4~1ct> cq~1~1)
