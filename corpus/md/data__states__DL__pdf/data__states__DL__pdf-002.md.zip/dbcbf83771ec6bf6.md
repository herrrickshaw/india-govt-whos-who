---
doc_id: "dbcbf83771ec6bf6"
source_url: "https://environment.delhi.gov.in/sites/default/files/environment/tender/tenderdoc_3.pdf"
ministry: "Enviornment Department, Delhi"
title: "Tender Document"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d46c797ac4799314"
---

<!-- page 1 -->

GOVT. OF NCT OF DELHI
HORTICULTURE UNIT
DEPARTMENT OF ENVIRONMENT AND FORESTS
OFFICE OF THE DIRECTOR HORTICULTURE
11TH FLOOR, MSO BUILDING , ITO, NEW DELHI-110002, (Ph.:- 011 – 23317559)
No.F.58(52)/DH/TG/2021-22/391

Dated:10.05.2022

NOTICE INVITING E-TENDER FOR “SUPPLY OF DIY KITS FOR INTRODUCTION TO
URBAN FARMING 2022-23”

Online tenders are invited in a two bid system from reputed, experienced agencies &bonafide
eligible tenderers registered in Delhi by the Horticulture Unit, GNCTD, 11th Floor, MSO Building, ITO
through e-tendering.
The first requirement to participate in e-tender is to have digital signature and the registration of
tenderers with Delhi Govt. E-procurement. For any assistance regarding e-tendering process, the
intending tenderer may contact at Help Desk 11th Floor, M.S.O. Building, I.T.O, Delhi-02 or call on 01123317559 during working day/hour ( Monday - Friday, 09:30 AM to 06:00 PM).
Last date for submission/receipt of tenders(s) through e-tendering is 31/05/2022 at 12:00 Noon
and will be opened online by the Tender Committee in the presence of tenderers or their authorized
representatives who wish to be present on the same day i.e. 31/05/2022 at 14.00Hrs. in the office of the
Director, Horticulture, 11th Floor, MSO Building Government of NCT of Delhi. In case of any holiday on
the day of opening, the e-tender will be opened on the next working day at the same time.

Sd/Director, Horticulture,
11th Floor, MSO Building,ITO
New Delhi

Page 1 of 7

<!-- page 2 -->

Copy to:
1. The Principal Secretary (E&F), Department Of Environment, Forests &Wildlife, 6th-Level, CWing, Delhi Secretariat, I.P. Estate, New Delhi – 110002, for kind information.
2. The Secretary to Hon’ble Minister (E&F), 8th-Level, A-Wing Delhi Secretariat, I.P. Estate, New
Delhi – 110002, for kind information.
3. The Dy. Controller of Accounts (Env.), Delhi Secretariat, Delhi -110002, with the request to
kindly be present at the time of opening on the scheduled date and time.
4. Programmer, Department of Environment, Level 6, Delhi Secretariat with the request to upload it
on Environment Department website in public interest.
5. Notice Board O/o The Director (Horticulture).

Sd/Director, Horticulture,
11th Floor, MSO Building,ITO
New Delhi.

Page 2 of 7

<!-- page 3 -->

GOVT. OF NCT OF DELHI
HORTICULTURE UNIT
DEPARTMENT OF ENVIRONMENT AND FORESTS
OFFICE OF THE DIRECTOR HORTICULTURE
11TH FLOOR, MSO BUILDING , ITO, NEW DELHI-110002, (Ph.:- 011 – 23317559)
TENDER APPLICATION

FORM

In response to the Tender Notice No.F.58(52)/DH/TG/2021-22/391 Dated 10/05/2022, I/We do
hereby offer the rate against the item of work mentioned below for “SUPPLY OF DIY KITS FOR

INTRODUCTION TO URBAN FARMING 2022-23” .
Each kit may consist of the following items
i. Vegetable seeds 10 types (5-25 grams each depending upon species)
ii. Biofertilizers 3 types (100 grams each)
iii. Organic manure 1 kg
iv. Information booklet regarding cultivation of the seeds in the kit
v. All components should be packed in a bag with the Name of the Scheme and Department
printed on it.
Sl.No

Name of Item

Total
Quantity

1

DIY kits

10,000

Introduction to Urban
Farming

(5000 summer kits and
5000 winter kits)

Rate per kit
inclusive of GST/
taxes etc. (Rs.)

Total amount
(in Rs.)

Page 3 of 7

<!-- page 4 -->

TERMS & CONDITIONS OF THE E- TENDER
1. E- Tenders invited for the work of the “SUPPLY OF DIY KITS FOR INTRODUCTION TO
URBAN FARMING 2022-23”, by the Director, Horticulture Unit, Department of Environment,
GNCTD, 11th Floor, MSO Building, ITO,New Delhi through e-tendering in a two bid system.The
successful tenderer/bidder shall be required to execute the work as specified in the Tender Application
Form within 7days time from the date of communication of the approval of the Competent Authority.
2.

Estimated cost is Rs.60,00,000/- (Rupees Sixty Lakhs only)

3.

Participation in the online bid shall amount to bidder’s acceptance of the terms and conditions of
the tender.
The bidder shall submit on or before the date given in the Notice Inviting e-Tender, the
Technical Bid and the Financial Bid online in the prescribed format given in e-Tendering
site.

4. The Technical Bid should consist of the following documents:a.

b.
c.
d.
e.
f.
g.

h.
i.
j.

Bid Security (Earnest Money Deposit) for an amount of Rs.1,80,000/- (Rupees One
Lakh Eighty Thousand only) in the form of an Account Payee Demand Draft/FDR
from any Commercial Bank in favour of DDO, Horticulture Unit, payable at Delhi.
The EMD in original shall be submitted in the office of Horticulture Unit, at Diary
Dispatch counter on or before the closing date and time i.e 31.05.2022 up to 12:00
Noon for approval of Purchase Committee as part of the Technical bid.
Scanned copy of registration/Association with Government/Autonomous bodies in
India for works related to supply of horticulture mini-kits/kits.
Self attested copy of PAN Card under Income Tax Act. along with last three years
income tax returns filed with Income Tax Deptt.,
Self attested copies of GST registration number.
An undertaking to the effect that the contractor/agency has not been blacklisted by
any Govt. Department in earlier occasions.
Scanned copy of signed terms and condition by contractor.
Undertaking on Rs. 100/- stamp paper that you would not claim any arrear on
account of increase in minimum wages, if any, and would yourself bear the burden of
payment of increased wages to your labours
Proof of ownership of farms producing breeder seeds and foundation seeds to ensure
purity of seeds supplied
Proof of ownership of quality control labs
Proof of ownership of seed drying and cleaning facilities

Tenderer/Bidder must submit copies of all documents required through online.
5. Tenderer/Bidder shall quote the rates in the prescribed form for Price Bid given in E-Tendering site
Page 4 of 7

<!-- page 5 -->

against this tender on a ‘single responsibility’ basis such that the Tender price covers contractor’s
all obligations and liabilities. The rates and prices quoted by the Bidder shall be inclusive of all
Taxes.
6. The tenderer/Bidder is expected to examine all instructions, Forms, Terms and Conditions in the
Tender document before participation in this e-tender. The validity of tender will be 12 months for
award after approval. The validity of the tender can be extended if approved by Principal
Secretary(E&F), GNCTD.
7. In case the tenderer/Bidder has any doubt about the meaning of anything contained in the tender
document, he shall seek clarification from the office of the Director, Horticulture Department of
Environment,GNCTD, 11th Floor, MSO Building, ITO,New Delhi
8. Bid securities (EMD) of the unsuccessful tenderer/bidder will be returned to them at the earliest.
Bid security of the successful bidder shall be returned on receipt of 8% Performance
Security/Security Deposit in the Department. Bid Security shall be forfeited if the Tenderer/Bidder
withdraws his bid during the period of tender validity. Bid Security shall also be liable to be
forfeited if the successful bidder fails to furnish the required Performance Security within the time
frame specified by the Department.
9. The successful tenderer/bidder shall execute an agreement with Horticulture Unit soon after
deposit of 8% of the tendered value as Performance Guarantee within 10 days w.e.f. the date of
acceptance of the offer in the form of Demand Draft/Fixed Deposit Receipt having a validity of 7.5
years w.e.f. the date of acceptance of the offer, drawn on any of the Commercial Banks payable at
Delhi, in favour of Horticulture Unit, payable at Delhi.
10. The authorized representatives/Purchase Committee of this office/ Department will open the
Technical Bid in the presence of the Tenderer/Bidders or their representatives who choose to attend
at the appointed place and time. The Qualification for the technical bid shall be based on the online
receipt of all the documents required & listed above clause in (4) & (5) on or before the closing
date and time of bidding i.e 31/05/2022.up to 12.00 Noon.
11. a) Financial Bids/Price Bids of only the technically qualified bidders will be opened for evaluation
in the presence of qualified bidders who choose to be present at the time of opening of Financial
Bids.
b) Rates shall be compared on the basis of total cost for all the items taken together for approved
Technical bid.
+
12. The Offers of tenders not accompanied by documentary proof or do not meet the eligibility criteria
as mentioned above shall not be considered. Canvassing or negotiation, direct or indirect, would
render the tender liable for exclusion from consideration.
13. The kits shall be supplied to Horticulture Assistant, Dwarka Nursery, Horticulture Unit, Department
of Environment, GNCTD.Each kit may consist of the following items
i. Vegetable seeds 10 types (5-25 grams each depending upon species)
ii. Biofertilizers 3 types (100 grams each)
iii. Organic manure 1 kg
iv. Information booklet regarding cultivation of the seeds in the kit
Page 5 of 7

<!-- page 6 -->

v. All components should be packed in a bag with the Name of the Scheme and Department
printed on it.
14. The Director, Horticulture Unit reserves the right to accept or reject any or cancel any or all the
tenders without assigning any reason thereof.
15.

(a) The Horticulture Unit, Department of Environment Govt. of N.C.T. of Delhi, is not bound to
accept the lowest rate/cost or any bid and may at any time by notice in writing to the bidder(s)
terminate the tendering process.
b) Horticulture Unit, Department of Environment Govt. of N.C.T. of Delhi, is at liberty to accept
rates quoted for one item and reject other or may accept gross value of complete tender on the
recommendation of Committee existing for the purpose.

16. The Horticulture Unit, Department of Environment Govt. of N.C.T. of Delhi, may terminate the
work order if it is found that the contractor is black listed on the previous occasions by any of the
Government Departments/Institutions/Local Bodies/Municipalities/Public Sector Undertakings etc.
17. a) The successful Tenderer/Bidder shall ensure full compliance with Tax laws of India with regard
to the work order(s) and shall be solely responsible for the same.
b) The successful bidder will comply all the rules & regulations of the land with latest
circular/orders issued by various Government Departments applicable to the work and bidder will
be solely responsible.
c) Failure of the successful tenderer/bidder to comply with the requirements of above clauses shall
constitute sufficient grounds for the annulment of the work order and forfeiture of Bid
Security/Performance Security.
d) Duly completed books of accounts/documents should be produced as and when required by the
department.
18. In the event of non-execution of the work, the Security Deposit shall be forfeited with the
Government and the balance work, if any, shall be got executed at the risk and cost of the tenderer
by rescinding the contract for the reasons to be recorded by Horticulture Unit in writing.
19. The department shall not be responsible for payment of any compensation on account of any loss
caused to the tenderer due to natural calamities or other supervening impossibilities.
20.

The contractor shall not construct any permanent structure at the site of work and shall have no
right on the land or asset of the Government.

21.

The contractor shall abide by the provisions made under the Labour Laws and other relevant
Statutes as applicable in execution of the work and shall be responsible for making good/ payment
of compensation, if any, to any workman or material during execution of the contract.

22. In no circumstances, the contractor would be allowed to sublet the works in part or whole of the
contract, assigned to them.
23. a) Any dispute or difference arising out of this contract will be resolved through joint discussion of
the authorized representatives of the concerned parties. However, if the disputes are not resolved by
Page 6 of 7

<!-- page 7 -->

the joint discussions, then the matter will be referred for adjudication to a sole Arbitrator appointed
by the HOD, Horticulture Unit, Department of Environment GNCTD.
b) The award of the sole Arbitrator shall be final and binding on all the parties. The arbitration
proceeding’s shall be governed by the Indian Arbitration and Conciliation Act, 1996 as amended from
time to time.
c) The cost of Arbitration shall be borne by the respective parties in equal proportions. During the
pendency of the arbitration proceeding and currency of contract, neither party shall be entitled to
suspend the work/service to which the dispute relates on account of the arbitration and payment to the
contractor shall continue to be made in the terms of the contract. Arbitration proceedings will be held
at Delhi/New Delhi only.
24. All disputes arising out of the execution of the agreement shall be subject to the jurisdiction of the
Court at Delhi only.
25. The Rates shall be compared on the basis of total cost inclusive of all the items taken together for
approved technical bid.
26. Horticulture Unit is at liberty to increase or decrease the quantity mentioned. Items mentioned may be
dropped also keeping in view the requirement of stores/service components at the site/field at the time
of placing the work order.
27. Actual number of total kits may increase or decrease by 25% of total kits in which case work order
may be issued/ modified at the same rate of quoted rate.
28.

All material/service inputs for the above mentioned works shall be provided by the successful
tenderer/contractor,

29.

The quantity mentioned above may increase or decrease as per requirements and Govt.
policies/decisions.

Deposit at Call/Bank Draft bearing No. ___________________ dated ____________ issued by
_____________________ Bank, ____________________________________ for an amount of Rs.
……………………………………../ (Rs. ………………………………………………….. only) drawn
in favour of Horticulture Unit, Department of Environment, GNCTD, 11th Floor, MSO Building,
ITO,New Delhitowards EMD, is enclosed.

SIGNATURE OF………………………………………………..
THE NAME OF BIDDER ………………………………………
ADDRESS………………………………………………………
TEL. NO./MOBILE NO…………………………………………
E-MAIL ADDRESS……………………………………………..

Page 7 of 7
