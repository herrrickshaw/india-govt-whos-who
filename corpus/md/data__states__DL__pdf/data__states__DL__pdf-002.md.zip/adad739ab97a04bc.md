---
doc_id: "adad739ab97a04bc"
source_url: "https://damb.delhi.gov.in/sites/default/files/inline-files/election_schedule_of_fpemc.pdf"
ministry: "Directorate of Agricultural Marketing, Delhi"
title: "Notification regarding Schedule of Electionof Fish, Poultry & Egg Marketing Committee, Gazipur, Delhi"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "e960452a6c1609a5"
---

<!-- page 1 -->

जे
(TO BE PUBLISHED IN PART-IV OF DELHI GAZZETTE EXTRA ORDINARY)
शत GOVERNMENT OF NATIONAL CAPITAL TERRITORY OF Delhi
(DEVELOPMENT DEPARTMENT)
DIRECTORATE OF AGRICULTURAL MARKETING
49, SHAM NATH MARG, OLD SECTT., Delhi-i 0054.
FAX NO. 238i8298, E-MAIL ADDRESS dagri@sansad.nic.in
No.F. 8(26)/200I-DAM/MR/Pt.-II/ |7¢° Dated: (7:08 09
NOTIFICATION
No. F. 8(26)/200I-DAM/MR‘/Pt.-II/ In exercise of the powers conferred
under rule 23(I) of Delhi Agricultural Produce Marketing (Election) Rules 2000, I, V.P.
Rao, Director (Agricultural Marketing), Government of National Capital Territory of
Delhi hereby notify the schedule for election for filling up of the vacancies in the Fish,
Poultry & Egg Marketing Committee, Gazipur, Delhi and for re-constituting the
Marketing Committee :-
l Two members of FP&EMC, Gazipur, Delhi from licenced Traders and
Commission Agents enlisted as electors there. =
2 One member of FP&EMC, Gazipur, Delhi from licenced Weighmen and
Measurers enlisted as electors there.
Sh. Vijay Kumar Sharma, DANICS Officer of Govt. of Delhi presently posted as
Dy. Director (AM), 49, Sham Nath Marg (Behind Old Sectt.), Delhi — 0054, Office
Telephone No. 238i830I (Res. Tel. No. 23653575) has been appointed as Returning
Officer for the above election which is scheduled as per programme given below: -
Last date for making nominations* Si 24.08.2009
Date for scrutiny of nominations 25.08.2009
Last date for withdrawal of candidature 27.08.2009
4. | Date of poll and time and hour 7.09.2009
from 8.00 a.m. to 4,00 p.m.
5. | The date before which the election shall 24.09.2009
be completed
The working hours of the Election Office of the Returning Officer will be .00
a.m. to 3.00 p.m. on all working days.
* An affidavit regarding not having disqualifications, as per Rule 2 of Delhi
Agricultural Produce Marketing (Election) Rules, 2000 should be attached with the
nomination paper alongwith “No Dues Certificate” from the Secretary of the APMC
concerned in the prescribed language.
By i
(V.P. RAG
Director (Agri. Mktg.)/
Spl. Secy. (Development)
Tel. No. 238i860I
