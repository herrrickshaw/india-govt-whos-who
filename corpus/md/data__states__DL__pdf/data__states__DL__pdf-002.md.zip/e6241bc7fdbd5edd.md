---
doc_id: "e6241bc7fdbd5edd"
source_url: "https://tte.delhi.gov.in/sites/default/files/tte.delhi.gov.in/tender/4428_0001_compressed_0.pdf"
ministry: "Directorate of Training and Technical Education, Delhi"
title: "Tender Document"
date: ""
pages: 11
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "72f770364f1c285d"
---

<!-- page 1 -->

भू sa G ae fas dear/Bid Number: GEM/2025/8/6722333
¥ / * eM vw we दिनांक /Dated: 0I-I0-2025
<> cMarketptace भा
fis oraast / Bid Document
बिड बंद होने की तारीख/समय /छांप End Date/Time | 2-0-2025 5:00:00
fas खुलने की तारीख/समय /Bid Opening 44-20-2025 5:30:00
Date/Time
fas पेशकश वैधता (बंद होने की तारीख से)/छात 067 60 (Days)
Validity (From End Date}
Training And Technical Education Department Delhi
eo 7झ/_7ोक
ariieret at arst/Office Name Dtte
‘Het AT/Total Quantity 4
aeq Avil /item Category High End Laptop - Notebook (Q2)
बिडर का न्यूनतम औसत वार्षिक टर्नओवर (3 वर्षों का)
/Minimum Average Annual Turnover of the | 3 Lakh (s)
bidder {For 3 Years)
मूल उपकरण निर्भाता का औसत्त टर्नओवर (गत 3 वर्षो 3 Lakh (6)
%I)/OEM Average Turnover (Last 3 Years)
उन्हीं/समान सेवा के लिए अपेक्षित विगत अनुभव के.
aiyYears of Past Experience Required for 3 Year (s)
same/similar service
वर्षो के अनुभव एवं टर्नओवर से एमएसई को छूट प्राप्त है /
MSE Exemption for Years Of Experience Yes | Complete
and Turnover
स्टार्टअप के लिए अनुभव के वर्षो और टर्नओवर से कूट प्रदान
rg $ /Startup Exemption for Years of
Experience and Turnover
Experience Criteria,Past Performance,Bidder
Turnover, Certificate (Requested in ATC),OEM Authorization
nit Certificate,OEM Annual Turnover,Additional Doc I
feeber & at IT waris/Document required (Requested in ATC)
from seller *In case any bidder is seeking exemption from Experience /
Turnover Criteria, the supporting documents to prove his
eligibility for exemption must be uploaded for evaluation by
९ ] ५ the buyer
ve
6 22
l4
९) any phere up gaol.
_ लत wan
DD (ET)
al

<!-- page 2 -->

कया आप निविदाकारों क्वरा अपलोड किए गए दस्तावेज़ों को
मिविदा में आग लेने वाले सभी निविदाकारों को दिखाना
‘Ued 2 east aq #/Do you want to show
documents uploaded by bidders to all
bidders participated in bid?
बिड लगाने की समय सीमा स्वतः नहीं बल्चने के लिए
amaers fs & deat / Minimum number of 3
bids required to disable automatic bid
extension
दिनों की संख्या, जिनके लिए बिड लगाने की रामय-सीमा
‘Weg srt] 7 Number of days for which Bid |7
would be auto-extended
ऑटो एक्सटेंशन अधिकतम कितनी बार किया जाना है। /
Number of Auto Extension count
रिवर्स ftorett zitvzrar fa/RA Qualification Rule | 50% Lowest Priced Technically Qualified Bidders
fas a Wear /Type of Bid Two Packet Bid
तकनीकी मूल्यांकन के दौरान तकनीकी स्पष्टीकरण हेतु
Hqat WT /Time allowed for Technical 2 Days
Clarifications during technical evaluation
निरीक्षण आवश्यक (सूचीबद्द निरीक्षण प्राधिकरण /जेम के साथ
पूर्व पंजीकृत एजेंसियों द्वारा )|॥59७८७०७ ए९वपराढत (By
Empanelled Inspection Authority / Agencies
pre-registered with GeM)
मूल्यांकन daie/ Evaluation Method Total value wise evaluation
faeaxor/EMD Detail
fie ay as einen Lia कम ० ५-० प्रा ब गाप5 mt न ा॑॑एएए७एएएछआ pei ety teen
fs aoe fe ्“7““77-7] Gai/Advisory Bank State Bank of India
jhe 77 चलना ch i
|| $एमडी WRVEMD Amount [000 SS
guhist far /ePBG Detail
pees eee feet temayang त a fies 5-5८ se
Usargent den/Advisory Bank State Bank of India
[sae प्रतिशत cxi7ePaG Pereentager%) ufelert (%)/ePBG Percentage(%) jo  ts—‘“SsSSSSCS@ |
2

<!-- page 3 -->

Ra Ss ho na aa जल
| ईपीबीजी की आवश्यक अवधि Garg) /Duration of ePBG | 62
i required (Months),
(a). जेम की शर्तों के अनुसार ईएमडी ei बिडर को संबंधित क्रेटेगरी के ल्लिए बिड के साथ वैध समर्थित दस्तावेज़ प्रस्तुत करते है। एमएसई
कैटेगरी के अंतर्गत केवत्न वस्तुओं के लिए तथा सेवाओं के लिए सेवा प्रदाता ईएमडी से छूट के पात हैं। व्यापारियों को इस नीति के दायरे से
@ex Taq TT SVEMD EXEMPTION: The bidder seeking EMD exemption, must submit the valid supporting document
for the relevant category as per GeM GTC with the bid. Under MSE category, only manufacturers for goods and
Service Providers for Services are eligible for exemption from EMD, Traders are excluded from the purview of this
Policy.
(0).ईएमडी और संपादन जमानत राशि, जश्न यह लागू होती है, लाभार्थी के पक्ष में होनी चाहिए। / 6५0 & Performance secul rityshould be
in favour of Beneficiary, wherever It is applicable.
wari /Beneficiary :
DD
Dtte, Training and Technical Education Department Delhi, N/A,
(Ddo)
UIN Number NCTGC245P
बोली विभाजन लागू नहीं किया गया/ 90 5|॥60709 700 990॥९0.
एमएसई खरीद वरीयता॥थ55 ?फ५-८ट।85७ 772८७
साई ete trace rucraserreteence [Moi ‘waite aeeTAN/MSE Purchase Preference we .' है
waangang Wite aeyer/Mil Purchase Preference
007 गा जन, खरीद बरीयता/॥५॥ ?७/८॥३५९६ Preference [mo No
, If the bidder is a Micro or Small Enterprise as per latest orders issued by Ministry of MSME, the bidder shall be
exempted from the eligibility criteria of "Experience Criteria" as defined above subject to meeting of quality and
technical specifications. The bidder seeking exemption from Experience Criteria, shall upload the supporting
documents to prove his eligibility for exemption.
2. If the bidder is a Micro or Small Enterprise (MSE) as per latest orders issued by Ministry of MSME, the bidder
shall be exempted from the eligibility criteria of "Bidder Turnover" as defined above subject to meeting of quality
and technical specifications. If the bidder itself is MSE OEM of the offered products, it would be exempted from
the "OEM Average Turnover” criteria also subject to meeting of quality and technical specifications, The bidder
seeking exemption from Turnover, shall upload the supporting documents to prove his eligibility for exemption.
3. The minimum average annual financial turnover of the bidder during the last three years, ending on 3lst
March of the previous financial year, should be as indicated above in the bid document. Documentary evidence in
the form of certified Audited Balance Sheets of relevant periods or a certificate from the Chartered Accountant /
Cost Accountant indicating the turnover details for the relevant period shall be uploaded with the bid. In case the
date of constitution / incorporation of the bidder is less than 3-year-old, the average turnover in respect of the
completed financial years after the date of constitution shall be taken into account for this criteria,
4, Experience Criteria: In respect of the filter applied for experience criteria, the Bidder or its OEM of the product
offered in the bid {themselves or through reseller(s)} should have regularly, manufactured and supplied same or
similar Category Products to any Central / State Govt Organization / PSU for number of Financial years as
indicated above In the bid document before the bid opening date. Copies of relevant contracts and del ivery
acceptance certificates like CRAC to be submitted along with bid In support of having supplied some quantity
during each of the Financial year, tn case of bunch bids, the category of primary product having highest value
should meet this criterion,
5. OEM Turn Over Criteria: The minimum average annual financial turnover of the OEM of the offered product
during the last three years, ending on 3ist March of the previous financial year, should be as indicated in the bid

alr

<!-- page 4 -->

document. Documentary evidence in the form of certified Audited Balance Sheets of relevant periods or a
certificate from the Chartered Accountant / Cost Accountant indicating the turnover details for the relevant
shall be uploaded with the bid, In case the date of constitution / incorporation of the OEM is less than 3 year old,
the average turnover in respect of the completed financial years after the date of constitution shall be taken into
account for this criteria.
6. Past Performance: The Bidder or its OEM {themselves or through re-seller(s)} should have supplied same or
similar Category Products for 50% of bid quantity, in at least one of the last three Financial years before the bid
opening date to any Central / State Govt Organization / PSU. Coptes of relevant contracts (proving supply of
cumulative order quantity in any one financial year) to be submitted along with bid in support of quantity
supplied in the relevant Financial year. In case of bunch bids, the category related to primary product having
highest bid value should meet this criterion,
7, Reverse Auction would be conducted amongst first 50% of the technically qualified bidders arranged in the
order of prices from lowest to highest, Number of sellers eligible for participating in RA would be rounded off to
next higher Integer value if number of technically qualified bidders is odd (e.g, if 7 bids are technically qualified,
then RA will be conducted amongst L-2 to L-4), In case number of technically qualified bidders are 2 or 3, RA will
be between all without any elimination. If Buyer has chosen to split the bid amongst N sellers, then minimum N
sellers would be taken to RA round, In case Primary products of only one OEM are left in contention for
participation in RA based on lowest 50% bidders qualifying for RA, the number of seilers qualifying for RA would
be increased to get at least products of one more OEM (directly participated or through its reseller) if available.
Further, if bid(s) of any seller(s) etigible for MSE preference is / are coming within price band of 5% of Non MSE
L-l or if bid of any seller(s) eligible for Make in India preference is / are coming within price band of 20% of non
MiItL-2, then such MSE / Make in India seller shall also be allowed to participate in the RA process.
Pre Bid Detail(s)
मुल्य भिन्‍नता खंड दस्तावेज़॥७-छव. | त-बिड स्थान॥१6-छात एश्लाप०
Date and Time
03-0-2025 6:00:00 Conference room DTTE(HQ)
High End Laptop - Notebook ( 4 pieces )
तकनीकी विशिष्टियाँ ‘Technical Specifications
Sain dew fae a sep / As per GeM Category Specification
| narnia बराक | @ at /Specification [Be 8 Re ae id Reaurement & foe sMRAH IPT WET /Bid Requirement
| | espectcaton |
Name i (Allowed Values)
- Processor (७ ण ७, Processor Number | हि Ryze 7 S750 ariel Core i7-32680, For Ryzen 7 5825U or intel Core i7-l265U, For
| ॥ Higher Processor Or higher
|
|
।
ah

<!-- page 5 -->

हे
ie faa! Specification | | Sera eine का art /Specification [Be # Bees a Renamer कै लिए आवश्यक अनुमत मूल्य /छात Requirement
| _| Name (Allowed Values)
$e Ee SS
| Higher Processor Number Not Applicable as Base Processor is Selected, AMD
i Ryzen 7 7730U, AMD Ryzen 7 PRO 7730U, AMD !
i Ryzen 7 7735U, AMD Ryzen 7 PRO 7735U, AMD |
| y | Ryzen 7 8840U, AMD Ryzen 7 8840HS, AMD Ryzen7 |
I 3 i 7840U, AMD Ryzen 7 PRO 7840U, AMD Ryzen 7
| | 7840HS, AMD Ryzen 7 PRO 7840HS, AMD Ryzen 9 धर
॥| i | 7940HS, AMD Ryzen 9 PRO 7940H5S, Intel Core i7- है
i 4) 355U, Intel Core i7-365U, Intel Core 7 50U, Intel |
| १ । Core Ultra 7 55U, Inte! Core Ultra 5 25U, Intel Core
i | Ultra 7 265U, Intel Core i7-280P, Intel Core Ultra 5 4
।| ॥ 225H, Inte! Core i7-I2650H, Intel Core Ultra 5 35H,
i jj !ntel Core i7-3620H, Intel Core Ultra 7 55H, Intel
| 4 Core Ultra 7 65H, Intel Core i7-3700H, Intel Core i9- i
| 32900॥, ॥68| (08 [3 9 85H, Intel Core i7-
| i] L3650HX, Intel Core i7-3700HX, Intel Core i7-
‘ | L4650HX, Intel Core 7 250U, Intel Core Ultra 5 2250,
| ‘Intel Core Ultra 5 235U, Intel Core Ultra 7 255U, Intel
|
| Core Ultra 5 236V, Intel Core Ultra 5 226V, intel Core
Ultra 5 238V, Intel Core Ultra 7 265, intel Core Ultra
i | | 7 266V, Intel Core Ultra 7 268V, Intel core ultra 7
 255H Or higher i
—— System, cess pp ety System (Factory ! [arsenate Wiser ome atl Professional, Window Home, DOS or
'|Pre-Loaded) 4 equivalent, Linux, Window STF (Shape the Future) '
a TRAM size (GB) chk लत नत अनार न पन3+-ननपन«+ञ3«+-+- ६८८८. 5 ना
[Memory RAM Size (GB) '|26, 32 Or higher
| “| ॥ Basia) Size (in cm) - | [PSS हट 24.8 in 3008 oases (० 38.07 (१4 ॥ (० 4,99 In), 38.08 to 40,62 (35
‘4 Diagonal In to 5.99 In), 40.63 to 43.6 (I6 In to 6,99 In)
किक 7 [argo rae ore = [2 20m ens
| Storage Capacity of Storage Drive 4024, 2048, 4096
, (in GB)
Additional हजार High End Laptop - Notebook { 4 pieces )
== Saas | Specification Parameter |__ Bid Requirement (lowed Values) Requirement (Allowed Values)
| Name |
| aj Make 2.Processor |
(2250 00॥ नम \ Sa, 2.Intel Core 7/AMD Ryzen 7 3.Minimum 2th Generation for
‘ Generation 4.Graphics Type Intel or equivalent (generation or series) for other Processors. 4.Integrated
Lee 5. 5 years 6.3.3 inch to 5.6 inch 7. Windows Professional /Linux/Any
Spee ize ZOperating other OS based on Linux Kernel. &.6 GB 9, DVD RW 40,5 Years 22, 256 GB
System 8.RAM Size 9.Optical tolTB
Drive (Optional) 0,Battery 4 ॥
५४क॥७70/ 74,7009॥ 550 ८३७/४८५७ '
* Bidders offering must also comply with the additional specification parameters mentioned above.
Wve /Ratiéer arent cer wra/Consignees/Reporting Officer and Quantity
sr

<!-- page 6 -->

frm ता Pe a //रिपोर्टिंग शा rs me r serene | —
के परेषित्ती/ गा ॥
॥ क्र.सं./5.| डिलीवरी के Deli
| PIS | steed sconsignee wav/Address arat /Quantity | Pte के a very
. Reporting/Officer | |
b fa ier | = co 3 एक] हु ४ ]| :
। थे 440088,णा६, धए MAYA RAM i |
॥7 | Arvind Kumar MARG, PITAMPURA 4 कह ।
Special terms and conditions-Version:5 effective from 28-07-2025 for category High End Laptop -
Notebook
i;
oS >> -_
@ category has been created in accordance with the Model Technical Specification
issued by the Ministry of Electronics and Information Technology (MeitY) vide letter
Ino, W-43/4/2020-IPHW dated I9th August 2024, and is based on the parameters
defined therein, The specifications applicable to this category are as per the Meity
Model Technical Specification dated 9th August 2024, Accordingly, buyers shall not
specify or mandate any particular processor, processor brand, or manufacturer in the
Additional Terms and Conditions (ATC). In this context, reference may also be made
to Clause 2(e) of the GeM General Terms and Conditions (GTC), which inter alia
states: "The Specifications shall identify the key parameters defining the products
with all necessary validations related to configuration, type of data, restrictions,
range / allowed values, allowed units etc. Sellers as well as Buyers while offering /
buying the Goods / services shall have to comply with the validation rules /
restrictions provided for in the Category Specification. Buyers / Sellers cannot add
parameters and / or drop down values not provided for in category Specification." in
lview of the above, buyers are not permitted to amend or modify any technical
specification through the Additional Terms and Conditions, and must ensure full
compliance with the predefined category specifications
A unique device serial number shall be provided by the seller at the time of supply,
which Is mentioned on the Product. The buyer/consignee shalt be able to verify the
Product Verification [complete product details, including configuration, through the OEM website. The
lbuyer/consignee should be able to perform these verifications without needing to
_ _. create an account on the OEM website, oe _.
Bill

<!-- page 7 -->

3, पाश९€[5॥080७/शाशशाए (9६ धीढ 0हो५ त the Laptop be a device
of Microsoft or hold a valid authorisation from Microsoft

2. Microsoft OS may be sourced directly from Microsoft by OEMs holding device
partner status, and those not holding device partner status may source from
authorized distributors, i.e., Ingram/Reddington and their authorized channel
partners,

3. Buyers may ensure that the authorisation from Microsoft shall not be made a
mandatory requirement in bids,

4. If supplies are made as per brands of OEMs who are global device partners,
then the serial number of the machine supplied can be used to check the
details of the product from the website of the OEM.

5. In the case of local device partners of Microsoft, OS details such as the digital
key number should be produced with supplies, and the buyer may verify them
fram Microsoft.

न 6. In case of other OEMs who are sourcing from authorized distributors of
Operating System Microsoft, Reddington, or Ingram, a copy of the Invoice which contains the
relevant serial number of Windows OS shall be submitted with supplies, and
the buyer/consignee can verify the same from the OS server website or by
telephone, or both.

7. In respect of verification of OS, the consignee shall take necessary steps at the
time of acceptance. For device partner machines, buyers can check the Laptop!
OEM website to verify the OS by entering the PC's serial number and part code
number. For entities that are not device partners and source OS from
distributors’ networks, they may verify the serlal number through the Microsoft]
website or by telephone, or both.

8, In case the product offered is with a DOS or Linux operating system, such
verification of OS shalt not be applicable.

9. Buyer shall request for Windows Hardware Compatibility Certificate for window
operating system to ensure the supply hardware Is compatible with Windows
ee, Operating system 0... _. | =

Storage Retention Buyer may add their requirement of retention of securely store all Hard Disk Drives

(HDDs) or Solid-State Drives (SSDs) used in the Laptop-Notebook under ATC clause.

Requirement of Buyers are advised to note that incorporating a condition stipulating an OEM logo on

IOEM logo the motherboard is restrictive and may not be incorporated Into the bids.

Intel and AMD Processors are added as per Model Technical Specification of Laptop -

Processors Notebook issued by Ministry of Electronics and Information Technology (MeitY-IPHW

Division) W-43/4/2020 dated 9 Aug 2024 ws
i. The buyer may ensure that as soon as supplies are received, a request for a
warranty certificate is made, along with logging into the OEM website/call
center to verify the certificate.

Warranty 2, The product in GeM marketplace (Direct Purchase & L purchase) comes with
@ minimum standard on site warranty of one year. In case the selier has
standard warranty more than one year, the same may be mentioned in the
catalogue (including in the model name) and in such case higher warranty
offered shall prevail/supersede the minimum one year warranty. ee os

OM related to Mil,

Local content and |Buyers are requested to refer to various OMs pertaining to DPIIT and MeitY, as issued

Meity advice on from time to time, while making procurement and follow relevant provisions as

Model technical applicable.

specifications — oo De

wi

<!-- page 8 -->

Before generating the Consignee Receipt and Acceptance Certificate {CRAC), the
consignee may inspect the system condition and verify that it complies with the
agreed specifications and configurations. In the case of a large number of units to be
procured, then the buyer may opt for bidding and accordingly stipulate conditions
regarding installation, inspection by consignees/inspection agency. Consignees who
receive the supplies should be vigilant and should complete checking to ensure that
there is no scope for the supply of refurbished products. At the time of receiving
supplies, the consignee may adhere to the following to ensure that any discrepancies,
Check points during|in supplies can be flagged, taken into account, and reflected while generating the
(Acceptance of ICRAC:
Supplies
|. Packing should be checked properly

Il, A warranty certificate from the OEM should be Insisted upon and checked,

iii, Instruction manuals and the OS installed should be checked.

iv. The machine serial number should atso be checked through settings and can
be verified fram the OEM website. The above points are for guidance, and the
buyer/consignee may take steps considered suitable by them for checking at
the consignee end before acceptance of systems,

रे v. An escalation matrix for customer grievance redressal shall be insisted upon
by the buyer from the seller at the time of delivery.
Battery Backup Buyer may check/validate battery backup time with appropriate benchmark,
For Sellers
\The OEM shall share the OEM website link with the buyer at the time of delivery. The
OEM Website offered model details/configuration should be available on their website, A unique
Link/Part No for device serial number shall also be provided at the time of supply, which is also
product verification {mentioned on the product, The buyer/consignee shall be able to verify the complete
product details, including configuration, through the shared OEM website link.
\Changing or Seller must refrain from changing or altering the configuration of the factory pre-
faltering the loaded machine. The machine should be delivered to the Consignee in its original,
configuration factory-approved configuration. _. _ —_—
he seller shall furnish a valid warranty Certificate/fag from the OEM to the
Warranty purchaser, guaranteeing the product's coverage under the specified warranty terms.
The warranty certificate should be verifiable through the OEM website/customer care
center,
compliance of With effect from ,4.23, as per the E-waste rules 2022, EPR registration is mandatory
lextended for manufacturing entities. Therefore, all OEMs shall hold valid EPR registration, and
roducerts the registration number should be reflected in the catalog Parameter, OEMs shall
P है ensure compliance with all responsibilities as per EPR registration applicable from
responsibility i 7
me to time, _ es —_
Eons ' OEMs shall have to ensure compliance with the mandatory/statutory requirements as
Seer ts as [Per the Government of india Notifications issued from time to time for hardware and
applicable software: Senponents,iasiehallcable _ _ |
it shall be the responsibility of OEMs to ensure that supplies are made with genuine
Operating System joperating systems.
an Stet ag fas fy dw at/Buyer Added Bid Specific Terms and Conditions
i. Generic
OPTION CLAUSE; The Purchaser reserves the tight to increase or decrease the quantity to be ordered up
to 25 percent of bid quantity at the time of placement of contract. The purchaser also reserves the right to
increase the ordered quantity up to 25% of the contracted quantity during the currency of the contract at
the contracted rates, The delivery period of quantity shall commence from the last date of original
delivery order and in cases where option clause is exercised during the extended delivery period the
additional time shalt commence from the last date of extended delivery period. The additional delivery
afl

<!-- page 9 -->

time shall be (Increased quantity + Original quantity) x Original delivery period (in days), subject to
minimum of 30 days. If the original delivery period is less than 30 days, the additional time equals the
original delivery period. The Purchaser may extend this calculated delivery duration up to the original
delivery period while exercising the option clause, Bidders must comply with these terms.

2. Provisions for workmen compensation, insurance, public liability, property damage, insurance etc. to be
ensured by the contractor, Also, safety measures prescribed for working in Extra High Voltage & use of
personnel protective equipment must be adhered to.

3. Generic
Bidder financial standing: The bidder should not be under liquidation, court receivership or similar
proceedings, should not be bankrupt. Bidder to upload undertaking to this effect with bid,

4, Generic
Bidders are advised to check applicable GST on their own before quoting. Buyer will not take any
responsiblity in this regards. GST reimbursement will be as per actuals or as per applicable rates
{whichever is lower), subject to the maximum of quoted GST %.

5. Generic
Malicious Code Certificate:
The seller should upload following certificate in the bid;-
(a) This is to certify that the Hardware and the Software being offered, as part of the contract, does not
contain Embedded Malicious code that would activate procedures to :-
(i) Inhibit the desires and designed function of the equipment.
(ii) Cause physical damage to the user or equipment during the exploitation,
(ili) Tap information resident or transient in the equipment/network.
(b) The firm will be considered to be in breach of the Procurement contract, in case physical damage, loss
of information or infringements retated to copyright and Intellectual Property Right (IPRs) are caused due
to activation of any such maticious code in embedded software,
6, Generic
While generating invoice in GeM portal, the seller must upload scanned copy of GST Invoice and the
screenshot of GST portal confirming payment of GST.
7. Forms of EMD and PBG
Bidders can also submit the EMD with Fixed Deposit Receipt made out or pledged in the name of AC
ODO DTTE
« The bank should certify on it that the deposit can be withdrawn only on the demand or with the sanction
of the pledgee. For release of EMD, the FDR will be released in the favour of the bidder by the Buyer after
making endorsement on the back of the FDR duly signed and stamped along with covering letter. Bidder
has to upload scanned copy/ proof of the FOR along with bid and has to ensure delivery of hardcopy to the
Buyer within 5 days of Bid End date/ Bid Opening date
8. Certificates
Bidder's offer is liable to be rejected if they don't upload any of the certificates / documents sought in the
Bid document, ATC and Corrigendum if any.
9, Buyer Added Bid Specific ATC
Buyer Added text based ATC clauses
+ Buyer must be registered at Dethi address
+ The original hard copy EMD of Rs, 5,600/- in the form of Demand Draft/ FD/Bank Guarantee from
gl

<!-- page 10 -->

any of the scheduled banks drawn in favor of “ DDO,DTTE(HQ)” is required to be submitted on or befo

re the closing date and time of e-submission of online ९-०५ (० Planning branch ,TTE (HQ), failing which

the bids will not be considered

* Bidder should have MSME Certificate and same should be uploaded.

+ Bidder should upload copy of GST Returns for Last three Financial Years (2022-23, 23-24, 24-25).

+ Bidder Turn over Certificate duly certified by CA for last 3 financial years (2022-23, 23-24, 24-25).

* Onsite Warranty should be 5 Year,

* MAF for offering Brand must be uploaded.
| isclaimer
The additional terms and conditions have been incorporated by the Buyer after approval of the Competent
Authority in Buyer Organization, whereby Buyer erganization is solely responsible for the impact of these clauses
on the bidding process, its outcome, and consequences thereof including any eccentricity / restriction arising in
the bidding process due to these ATCs and due to modification of technical specifications and / or terms and
conditions governing the bid, If any clause(s) is / are incorporated by the Buyer regarding following, the bid and
resultant contracts shall be treated as null and void and such bids may be cancelled by GeM at any stage of
bidding process without any notice:

. Definition of Class | and Class II suppliers in the bid not in line with the extant Order / Office Memorandum
issued by DPIIT in this regard.

2. Seeking EMD submission from bidder(s), including via Additional Terms & Conditions, in contravention to
exemption provided to such sellers under GeM GTC.

3. Publishing Custom / BOQ bids for items for which regular GeM categories are available without any
Category Item bunched with it.

4. Creating BoQ bid for single item,

5, Mentioning specific Brand or Make or Model or Manufacturer or Dealer name.

6, Mandating submission of documents in physical form as a pre-requisite to qualify bidders.

7. Floating / creation of work contracts as Custom Bids in Services,

8. Seeking sample with bid or approval of samples during bid evaluation process. (However, in bids for
attached categories, trials are allowed as per approved procurement policy of the buyer nodal Ministries)

9. Mandating foreign / international certifications even in case of existence of Indian Standards without
specifying equivalent indian Certification / standards.

40, Seeking experience from specific organization / department / institute only or from foreign / export
experience.

LL. Creating bid for items from irrelevant categories.

42, Incorporating any clause against the MSME policy and Preference to Make in India Policy.

3, Reference of conditions published on any external site or reference to external documents/clauses.

4. Asking for any Tender fee / Bid Participation fee / Auction fee in case of Bids / Forward Auction, as the
case may be.

5. Buyer added ATC Clauses which are in contravention of clauses defined by buyer in system generated bid
template as indicated above in the Bid Details section, EMD Detail, ePBG Detail and MIl and MSE Purchase
Preference sections of the bid, unless otherwise allowed by GeM GTC.

6. Inacategory based bid, adding additional items, through buyer added additional scope of work/ |
terms and conditions/or any other document. If buyer needs more items along with the main item, the
same must be added through bunching category based items or by bunching custom catalogs or
bunching a BoQ with the main category based item, the same must not be done through ATC or Scope of
Work.

Further, if any seller has any objection/grievance against these additional clauses or otherwise on any aspect of

this bid, they can raise their representation against the same by using the Representation window provided in

the bid details field in Seller dashboard after logging in as a seller within 4 days of bid publication on GeM, Buyer
30/77
