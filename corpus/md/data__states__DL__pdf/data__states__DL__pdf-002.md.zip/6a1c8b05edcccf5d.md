---
doc_id: "6a1c8b05edcccf5d"
source_url: "https://colart.delhi.gov.in/sites/default/files/circulars-orders/appointment_of_sh._dinesh_gupta_as_part_time_member_of_public_grievance_commission.pdf"
ministry: "College of Art, Delhi"
title: "Download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bc684700f752d270"
---

<!-- page 1 -->

"'m!~

GOVERNMeNT" Of INOlA

~

f.\, lt4.0RDI.;v.N\'

lllfil<!il• it ll&irFml
l'U HI I.SII FJ) O'r' AlJT IIORITV

n

~. '4PqfiiQII, Wfm : , lOIVlA'l<lVI 13, 193.l

IJCI)

rtn. i~li

[Tl.ltTI.i!.R:. ">T. m

OEU IJ, Ti illltSO \Y AL'GliSf -1. !OlioS \RVAK.\ IJ. 1933

f'ILCT.O M. 112

'11'1-1\

PART-IV
~ mrtiT'il rpq

m. ~ T!l'ifil\

COVER.~~I ENT OF THE /'i<\TIOi'IAL C\.I"ITAI n:RJUTOR\ ' Of I>EUII

~~~

Lt Gowm<><. Nutloo~lC.Iflinll Tcnitul) of!Jdhi i< rk-a~t
IO J\Pl"'illt Sf1 Dutc<h GUJ-'13 M I'IUl·Tim< ~lo:.ml~r. T'uhlk
CI!IC'II.lliC(~ <'amm~ti"O. Ci<wcmtnenll'lf NAti~n.l C"J'tiAI
lcrrtllll) ofl)dhl for n fu!1hctperft>4 nr Me )<ar. u.btct\
'" thl! tcnn• and condiloon~ a> <o~t~ulottd tn :h~ •l>o~
rdtm:d R~oluuun5

~fti '{U~I0:
~

~~:tOll

~ tlll. ll!Olrl()Ool 'R"if90-10·92091"fl'.-'1'1$1
~ iA ~ l1T'I'1f ;J; fi:':wli ZS•9·1~7 if~
'!iF.:! 'm J IIJ l}4•';l 'i '1il ft'!Tlli )11-7·1991'> ~ ~
~ '11. _. ,1.11'1-l·iPj ~ ~ milflfflll!l. ~imm; ~
;J; U7 'I{ T ;;q. U11 ( i ) '!!; ~ if. ~ 11111\l'ii ~ 1'
'WIIq4JP.

Sit nm~h Guru millI hnld thr nflicc C<~n pertud of
t>ac~enrup lo1·8·2012

lt 1ft, l :l/01. 100MI.1;l' 8870·9i>39 -.:fl.~
1P11il'il ~ ~ lm!i1f 1f; k-lr.f; !S 9 11)'11 ;o; ~

~ f:"ll! 'J"'l ~ ~ "" lf>i 3Pff'l Iii f>;nr_,

~ 'fi ~ 1 l4·9HI ~ ~ fl{'i1il; ln-7 19'1~ ,.; ~

~ trofm~ 'lt~l1111li; llj"!', i<1fM•1•·11

f:r:'IJr"J 3il'll!ll •

11!PlJ '1i1 J '14 94-~"i ..; ~'QTI -rmfllll t~' 11: ~ ~
i; 1R ~ .,.; O'l· l:'f.l ( i) i; Yopn"' q '11$ 'J'TilFii ~.-.lF

~ ia ~ ~ -~ 31<1161•4...

f.1!'fll ~ f I

~ ,.; rPl

'J\1 ~ ~ ~ ~ 'iJ'l ~f\ai ~~ H
;R; 3l'A 'i': ..,

ori m ,

3Q>.J;q IF.'I, '.ir'llf1 f.l7rt ~ ""1 t;.f; 1{1j

*

.;•.o 1!

""F•'' ""'

~ ~"f;;f ~ ii qoq1f1i(ifi~ ?l1il ~
~ ;;ITCll! ~lWli'f t,'-!1 ~- ~ ~41+1fll1
~ !i; '1'"1 'I ~- ~'fit'~ i I

Al)i\IINIS'mATl'\'F RFFOR.\1~ Df..P.o~.RT/11 ENT

,;;,m f:mlll;lll'l. 1[11'"" ;A mrl•l ~ f-lit. rr-~
)0 ·7-20 ';rn; wr-i 'l'f'fl: 1l'il wilt

NOTIFICATIOl'iS

Odht,lhc -llh \ugDSl. 2011

w.:r'l nliA\ m f'!'Ri ~ 3Q'l....,IM

1\o. F. llJM0041ARi9()..10·920Q•C.-In vunu:mcc
e>rsub·duow: (i) ofGlQUS\:0 f\ o(Pl!ngnph '2 o(Vo\'muntnt
o( Non<'nnl C11riml Tcrfllol) of !XIItl R<lolulatun
No F ·1'14 '9-I·AR dll!C!d :!S-'J-1997 11$ 3111o:n.ltd •nJc

"' ~ ~ il'll

m 'll'l 'R,

u ~ 1!'l. "!¢. ll'll'! ~

kcsolutt<>n No F J I~ '94-;\R d~tcd Jl). 7 1998. the
l9U 001~11

or :x"''fiz '<I' fi:nt

Ill
