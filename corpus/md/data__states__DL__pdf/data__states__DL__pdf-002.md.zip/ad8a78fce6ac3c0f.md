---
doc_id: "ad8a78fce6ac3c0f"
source_url: "https://gad.delhi.gov.in/sites/default/files/gad/circulars-orders/img20250428_12110578.pdf"
ministry: "General Administration Department, Delhi"
title: "Download"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "d91637ebe809b93f"
---

<!-- page 1 -->

GOVERNMENT OF NCT OF DELHI
GENERAL ADMINISTRATION DEPARTMENT

LEVEL Il: A-WING: DELHI SECRETARIAT: NEW DELHI

F.No. 0/982/2024/GAD/Admn./ | ७५३ Dated: 25.04.2025
CIRCULAR

Sub: Regarding timelines for submission of Annual Performance Assessment
Report (APAR) in respect of Adhoc DANICS/DASS/Steno Cadre in GNCTD for the
year 2024-25.

The e-SPARROW project for the online generation of APARs for the GNCTD SS &
Steno Cadre for the assessment year 2024-25 is now live. The blank APAR forms of
officers/officials who have submitted the required information to GAD have ‘been
generated. .

In this regard, please find enclosed the timeline for the preparation and completion
of APARs for the reporting year 2024-25 (Annexure-lil). It is requested that the
prescribed timelines be strictly adhered to.

Furthermore, officers/officials ‘who have not yet submitted the required information
are kindly requested to submit it to their respective dealing assistants in GAD (Admn.) on
or before 28.04.2025. nn

This may be accorded TOP PRIORITY. Ss

कप > ws
हु — (Pradeep Taya!)
मु Joint Secretary(GAD)

_ Encl: As above.

To,

4) PS to Additional Chief Secretary(GAD), Delhi Secretariat.

2) Deputy Secretary-!,II (GAD), Delhi Secretariat.

3) All Section Officers, GAD.

4) DPA (GAD) with the request to upload the circular on GAD website.

5) Guard File

<!-- page 2 -->

J |
Ti ; Annexure-IIT |
Time schedule for preparation/completion of Annual Performance Assessment Report
5 —________(Reporting Year- Financial Year)
Activity Date by Auto Forward
हि which to be है |
completed है |
\. | Distribution of blank APAR forms to all] OI April : |
concemed (i.e, to Officer to be |
Reported Upon where self-appraisal has |
to be given and to Reporting Officers /
where self-appraisal is not to be given).
2, |Submission of — self-appraisal to] [559 6" May
Reporting Officer by Officer Reported
Upon (where applicable’
Officer to Reviewing Officer. ‘
4. | APAR to be completed by Reviewing|  3* July 0I* August
Officer and to be sent to Administration 2 का
रु or CR Section / Cell or Accepting i
Authority, wherever provided
i wherever provided कं :
6. | (a) Disclosure to the Officer Reported | 0* September
a Upon where there is no Accepting
| Authority ;
6 ’ (b) Disclosure to the Officer Reported | 5" September |
i Upon where there is Accepting |
। | Authorit
e ‘Ee Submission of representation, if any, on |
APAR, by Officer Reported Upon disclosure of APAR
: Forwarding of representation to the
competent authority |
t (a) where there is no Accepting | 2I* September
: Authority for APAR
: (b) where there is Accepting Authority 06" October .
: for APAR
Disposal of representation by the
४ competent authori of receipt of representation
i i0. {Communication of the decision of the | I5™ November |
i competent authority on the
representation by the APAR Cell
; ]. |End of entire APAR process, after | 30" November
‘ which the APAR will be finally taken on :
record
er ACE Scanner
ey
