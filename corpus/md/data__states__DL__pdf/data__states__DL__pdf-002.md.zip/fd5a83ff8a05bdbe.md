---
doc_id: "fd5a83ff8a05bdbe"
source_url: "https://gad.delhi.gov.in/sites/default/files/gad/circulars-orders/sports_order.pdf"
ministry: "General Administration Department, Delhi"
title: "Download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "29dcae89fb570337"
---

<!-- page 1 -->

GOVERNMENT OF N.C.T. OF DELHI

GENERAL ADMINISTRATIONDEPARTMENT (SPORTS BRANCH)

LEVEL-II, A WING, DELHISECRETARIAT
NEW DELHI-110002

Dated: 2yu25

E. No. 18/53/2023/Sports/GAD/Admn./Ptf-/48224
ORDER

Sub: Selection Trials of Lawn Tennis(Men & Women) for the year 2025-26.
Ref;- (i) GAD CircularE. No. 18/53/2023/Sports/GAD/Admn./Ptf-/45809 dated 04.I1.2025 &
(i) GAD Circular F.No. 18/53/2023/Sports/GAD/Admn./Ptf-1/ 46968 dated 13.11.2025.

In reference to abovesaid Circulars, it is informed that the trials for selecting the final team
of Lawn Tennis for participation in All India Civil Services Lawn Tennis (Men and Women)

Tournament 2025-26 scheduled to be held in Gujarat w.e.f. 16.12.2025 to 22.12.2025, will be
held as per the following schedule:
SI.
No.
1.

Game

Venue

Lawn Tennis Thyagraj Sports
Complex, INA

Team Composition
Men

07

Date/Time of Trials

29.11.2025 (Saturday)

at 09.00 A.M.

(incl.Veteran)
Women

05

Veteran Women

02

The final trials shall be made strictly on the basis of instructions issued by the Central

Civil Services and Sports Board, Government of India vide letter dated 19.11.2025 (copy
enclosed).

(Pradeep Tayal)
Joint Secretary (Sports)

F. No. 18/53/2023/Sports/GAD/Admn./Ptf-I/48224

Dated: a4|ulaoas

Copy forwarded for information and necessary action:
i. AllHead of Departments concerned, Govt. of NCT of Delhi.
2. The Dy. Director of Education (Sports), Dte. of Education, Govt. of NCT of Delhi,
Chhatarsaal Stadium, Delhi.

3. The Administrato, Thyagraj Stadium, INA, Delhi.
4. Website of the department.
5. GuardFile.

(Pradeep Tayal)
Joint Secretary (Sports)
