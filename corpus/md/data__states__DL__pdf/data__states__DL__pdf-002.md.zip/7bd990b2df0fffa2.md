---
doc_id: "7bd990b2df0fffa2"
source_url: "https://dscsc.delhi.gov.in/sites/default/files/dscsc/tender/sealed_quotations_are_invited_for_renovation_works_of_office_at_ghevra_godown_delhi._submission_date_upto_9.12.2011_by_2.30_p.m.pdf"
ministry: "Delhi State Civil Supplies Corporation Limited (DSCSC)"
title: "Tender Document"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "142a51f0db3a64aa"
---

<!-- page 1 -->

NOTICE INVITING QUOTATION
Sealed quotation are invited from contractors/firms registered with DSCSC CPWD,
PWD, DDA, DSIIDC, DAMB, DTTDC, NDMC, MCD FOR RENOVATION WORKS
OF OFFICE AT GHEVRA, DELHI.
The estimated cost is Rs. 43574/-. The tender documents can be downloaded from
DSCSC’s website www.dscsc.delhigovt.nic.in.
Sealed quotation duly filled up alongwith earnest money of Rs. 871/- in the form of
DD/Payorder in favour of DSCSC Ltd. payable at Delhi may be submitted to 2.30
PM on 9.12.2011 and the same shall be opened on 9.12.2011 at 3.00 PM in the
presence of tenderer or their authorised representative who like to be present.
CMD, DSCSC reserve the right to accept or reject any/all quotations without
assigning any reason whatsoever

(K.K. NIGAM)
SR. MANAGER (ESTATE)

1

<!-- page 2 -->

PARTICULAR OF TENDERER/QUOTATIONER
1) NAME OF THE APPLICANT FIRM
(In full and in block letters)
2) Address (In Block Letters)
Pin code
Phone nos.
3) Constitution of the firm Whether
proprietor or Partnership or Cooperative
society or Company.
Details of proprietor or partners or
Directors i.e. their address, Telephone
numbers, (Attested copies of partnership
Deed. Form A & Form B to be enclosed)
4) Whether registered in DSCSC,
CPWD,PWD, DDA, DSIIDC,DAMB,
DTTDC, NDMC, MCD
5) Service tax Registration No.
Name as per service tax registration
certificate
6) DVAT Registration No.
Name as per DVAT Certificate

:
:

:

:

:

7) Permanent Account No.

............

............

............

8) Whether any partner/proprietor firm
convicted by any court of law. if so give
details.
9) Name of work
:
10) The amount of earnest money
deposited in favour of DSCSC Ltd in
shape of DD/Pay order no, date & the
schedule bank on which drawn.
DECLARATION
1)
The particulars furnished above are true to the best of my/our knowledge and belief &
no material fact has been concealed therein and I/We understand that concealment of material
facts shall entitle the Corporation to take penal action including blacklisting/debarring the
applicant from participating in tender of the Corporation for a period upto 5 years.
2)
I /We shall not withdraw the rates quoted by me/us during the tender process.. In the
event of work awarded to me/us and in case failure to execute the work, the corporation shall
be entitled to forfeit earnest money deposited by me/us. & the Corporation shall also be
entitled to get the work done from any other contractor at my/own risk & cost.
(Signature of applicant)

Name.......................
(In full ) & status

2

<!-- page 3 -->

Conditions
1.
Contractors/firms should be registered with Service Tax Deptt. and DVAT Deptt. for works
contract.
2.

The Contractor will submit requisite earnest money i.e Rs. 871/- alongwith tender.

3.

TDS/DVAT and other taxes will be deducted from
prevailing rates/rules etc.

4.

The work shall be completed within a period of 20 days after award of work.

5.

The Corporation will impose penalty @ Rs.500 per day, if the work is delayed beyond the
stipulated period. However the Contractor may request Co. Secy-cum-AGM for extension of
period if the reasons are genuine..

6.

10% Security will be deducted from the contractor’s bill & the same will be released after
defect liability period of 2 (Two) months from the date of completion of work.

7.

The contractor shall take all precautions and safety measures for all workers /labourers etc.
which are to be engaged by the Contractor for execution of said work.

the bill of Contractor as per

8.
The work shall be executed with high degree of workmanship & confirm to the approved
norms, standard and specification for the materials and workman ship.
9.

The required work shall be carried out on continuous basis while the normal functions of the
corporation’s at site will continue as usual till the works are carried out.

10.

The payment will be made to contractor after completion of work. However management of the
Corporation may consider running payment

11.

The rates of items of work shall be applicable for all height and depth otherwise
specified in the item.

12.

The contractor shall be responsible to arrange T & P and water etc required for execution of
work. No payment shall be made to the contractor for damage caused by rains or other
natural calamities or riots during execution of work and no claim on this account will be
entertained/admissible

13.

The CMD, DSCSC Ltd. reserves the right to reject any or all the tenders without assigning any
reason whatsoever.

3

<!-- page 4 -->

ANNEXURE ‘A’
Sr.
No.
1.

2.
3.
4.
5.
6.
7.
8.

Name of work

Estimated Cost Earnest money
(Rs.)
Providing & fixing wooden Rs. 1,28727/- Rs.2575/cabin for office use at Gajipur
Delhi.
Renovation works of office at Rs. 43,574/Rs.871/Ghevra, Delhi
Renovation works of office at Rs. 58,511/Rs.1170/Narela, Delhi
Renovation works of office at Rs. 37,998/Rs.760/Naraina, Delhi
Renovation works of office at Rs. 4,521/Rs.90/Okhla, Delhi
Renovation works of office at Rs. 28545/Rs.571/Shakti Nagar, Delhi
Renovation works of office at Rs. 33105/Rs.662/CTO PUSA, Delhi
Renovation works of office at Rs. 5974/Rs.119/Siraspur, Delhi

Time of
completion
20 days

20 days
20 days
20 days
7 days
20 days
20 days
7 days

( K. K. NIGAM )
SR. MANAGER (ESTATE)

4

<!-- page 5 -->

NAME OF WORK:- RENOVATION WORKS OF OFFICE SITUATED AT F.C.I’S.
GODOWN, GHEVRA, DELHI

Description of Work

Unit

Quantity

Removing dry or oil bound
distemper, water proofing cement
paint and the preparing the
surface
smooth
including
necessary repairs to scratches
etc. complete.
Distempering with oil bound
washable distemper of approved
brand and manufacture to give an
even shade New work (two or
more coats) over including priming
coat with cement primer.
Painting with synthetic enamel
paint of approved brand and
manufacture of required color to
give an even shade (old work)
Finishing walls with water
proofing cement paint of required
shade old work (one or more
coats applied @ 2.20 kg/10) over
priming coat of primer applied @
0.80 litrs/10 Sqm complete
including coat of Priming coat.
Painting with synthetic enamel
paint of approved brand and
manufacture of required color to
give an even shade. Two or more
coats on new work over an under
coaat of suitable shade with
ordinary paint of approved brand
and manufacture.
Providing wood work in frames of
false ceiling, partitions etc. sawn
and put up in position.
Sal wood
Providing and fixing ISI marked
flush door shutters conforming to
IS: 22.02 (Part-I) decorative type,
core of block board construction
with frame of 1st class hard
wood and well matched teak 3 ply
veneering with vertical grains or
cross bands and face veneers on
both faces of shutters.
35mm thick including ISI marked
Stainless Steel butt hinges with
necessary screw.
Providing and fixing plywood 6
mm thick one side decorative
veneer conforming jto IS: 1328
(type-1) for paint lining / cladding
over wooden frames with
necessary screws, priming coat
unexposed surface with:
Decorative veneer facings of

Sqm.

170

Sqm.

170

Sqm.

20

Sqm.

46

Sqm.

18

Cum.

0.13

Sqm.

1.95

Sqm.

16

S.No

1.

2.

3.

4.

5.

6.

7.

8.

5

Rate

Amount

Remarks

<!-- page 6 -->

approved manufacture.

9.

10.

11.

12.

13.

14.

15.

16.

Providing and fixing glass panes,
with wooden fillets wherever
necessary:
Float glass panes of thickness 5.5
mm
Providing and fixing ISI marked
oxidized M.S. pressed butt hinges
with necessary screws etc.
complete.
100X58X1.90 mm
Providing and fixing aluminium
tower bolts ISI marked anodized
(anodic coating not less than grade
AC 10 as per IS : 1868)
transparent or dyed to required
colour or shade with necessary
screws etc. complete:
150X10 mm
Providing and fixing aluminium
handles ISI marked anodized
(anodic coating not less than grade
AC 10 as per IS : 1868)
transparent or dyed to required
colour or shade with necessary
screws etc. complete :
100 mm
Providing and fixing aluminium
hanging floor stopper ISI marked
anodized (anodic coating not less
than grade AC 10 as per is : 1868
transparent or dyed to required
colour and shade with necessary
screws etc. complete.
Twin rubber stopper
Providing and fixing bright finished
brass 100 mm mortice latch and
lock with 6 levers and a pair of
lever handles with necessary
screws etc. complete (best make
of approved quantity).
Providing and fixing 2nd class teak
wood lipping/moulded beading or
taj beading of size 18X5mm fixed
with
wooden
adhesive
or
approved quality and screws/nails
on the edges of the pre-laminated
particle board as per direction of
Engineer-incharge.
Providing and laying Ceramic
glazed floor tiles 300X300 mm
(thickness to be specified by the
manufacturer) of 1st quality
conforming to IS: 15622 of
approved make in colours such as
white, lvory, Grey, Fume Red
Brown, laid on 20 mm thick
Cement Mortar 1:4 (1 Cement : 4
Coarse sand) including pointing
the joints with white cement and

Sqm.

4.48

EACH

4

EACH

4

EACH

2

EACH

1

.

EACH

1

Metr
e

20

Sqm.

21

6

<!-- page 7 -->

matching pigment etc. complete.

17.

Providing and fixing IS : 3564
marked aluminium die cast body
tubular type universal hydraulic
door closer with necessary
accessories and screws etc.
complete.

EACH

7

1
