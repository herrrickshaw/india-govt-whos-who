---
doc_id: "cee8b4f5c1d700ea"
source_url: "https://bocw.delhi.gov.in/sites/default/files/bocw/circulars-orders/notification_regarding_constitution_of_delhi_building_and_other_construction_workers_welfare_board_dated_02-09-2002.pdf"
ministry: "Delhi Building and Other Construction Workers Welfare Board"
title: "Download"
date: ""
pages: 3
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "79def43b5f188959"
---

<!-- page 1 -->

ow, i - . a
‘ vo
Me he
कहे (2O BE PUBLISHED IN THE DELHI GAZETTE EXTRA ORDINARY PART IV)
GOVERNMENT OF NATIONAL CAPITAL TERRITORY OF DELHI |
~ (LABOUR DEPARTMENT) ule |
i, SHAM NATH MARG, DELHT-[40 054
NOLLFICATION
No.DLCICLABCW/02/ ५१५ Dated the 2"Eeeoimpgyen
No,DLC/CLA/BCW/02/....... In exercise of the powers COnfered -by Section 8 (i) of the i
Building and Other Construction Workers’ (Regulation of Employment and Conditions of Service) | i
Act, 996 (No.27 of 996) read with the notification No.U-020/l/2000-UTL dated 4.07,2000 i
issued by the Ministry of Home Affairs, Govt. of India, the Hon’ble Lt. Governor of Delhi is \
picased to constitute the Delhi Building and Other Construction Workers’ Welfaze Board with the |
following members with immediate effect for a period of three years. t
( J Minister of Labour, Chairman
Government of National Capital t
: — Territory of Delhi.
;
26 The Joint Dirccior, Member |
३ O/0.DG (LW), / Hy
Ministry of Labour, है int
Jaisalmer Howse, Man Singh Road,
New Delhi. ~\ 3
The Vabour Commissioner & Chief Member oor
Inspector of Inspections of Building and ‘
Construction, Government of Delhi, |
5, Sham Nath Marg, _ ;
Delhi-i0 054.
Y The Deputy Secretary (E-l) (Finance), Member iy
Finance Department, -
Government of Delhi,
Delhi Secretariat, |!
Playcrs Building, ’ है हक
LP. Esiate, New Deihi-2. sy ee fi
Y The Deputy Secretary (Law & Justice), Member oo
Department of Law, Justice & Legislative Affairs, हे है
Delhi Seeretariat, LP. Estate,
New Delhi-2. i
ee The Joint Labour Commissioner (Legal), am Member हे
Labour Department, Government of De!
5, Sham Nath Marg, Delhi-54.
‘ (Contd,..2) *
es | (9
ee |

<!-- page 2 -->

|
YU 4 \ C | i
-2-
/ |
Jy The Chief Inspector of Factories, Member a i
T.abour Nepartment, Government of NCT of Nelhi, हर a
5, Sham Nath Marg, Delhi-54. पर | हु :
4
REPRESENTATIVES OF EMPLOYERS ; ‘i
it
af The Superintending Engineer (Planning & - Member | vil | i
Administration) PWD, Zone-IIl, 6" floor, ae i!
MSO building, LP. Estate, ५. i)
New Delhi-2. : . i
Y The Commissioner (Personnel), DDA, Member al : i
: B-Block, Ground Hloor, Vikas Sadan, INA, "gas psa j
New Delhi. ५ |
# eth
है। Sanjeev Kumar Vashisth, Member {°° ०२ '
23/l, Gaulam Nagar, . me * i
New Delhi-49.
डर t
uf Captain Jitender Singh Mann, Member nt
Village Holambi Khurd, ° i
Delhi-0 082. 4
a
हक
2. Sh.Subhash Bhatnagar, President, Member a
Nirman Mazdoor Panchayat, :
Sangam, Delhi.
3.  Sh.Charan Singh Yadav, Member :
CA-37C, Shalimar Bagh,
Delhi.
uy Sh. Narender Kumar, Member है ee:
Village Rang Puri, “ -
Delhi-37.
I5.  Sh,Umesh Agarwal, . Member
2789, Pepal Mahadev,
Hauz Khazi, Delhi-6. पर
ह ~ (Contd...3)
$
i—— &

<!-- page 3 -->

eee
is
a i
w Ze
4 l6. Sh. Naveneet Gaur, Member रे
25, Neemri Colony, ita
Delhi-52. i i
BY ORDER AND IN THE NAME OF THE
LT.GOVERNOR OF THE NATIONAL CAPITAL i
TERRITORY OF DELHI |
s \ i. :
(KR. SA’ ५) रा
; UNDER SECRET. ‘ea ABOUR) Ee
"GOVE. OF N.C OF DELHI |
“  NoDLCicLaBewir 696 Dated the Diep - 2002 s
Copy forwarded for information to :- | i
l. The Deputy Secretary (GAD) (in duplicate) for publication in Delhi Extra ordinary f
: Gazette, Part-IV of today. : |
2 The Joint Dircctor, Govt. of India, Ministry of Labour, Jaisalmer Housc, Man Singh K
Road, New Delhi. \
3. The Secretary to the Lt. Governor, Govt, of NOT of Delhi, Delhi. हु i
4. The Secretary to the Chief Minister, Government of Delhi, Delhi. ae
5, The Secretary to the Labour Minister, Gowmnment of Delhi, Delhi. | \ t
6. The Chief Secretary, Govt, of NCT of Delhi, Delhi. ke
7. The Secretary (L & J), Govt. of NCT of Delhi, Delhi. ie
8. The Deputy Sccrctary (Law, Justice & LA), Department of Law, Justice & LA, Govi. of © i
NCYI of Dethi, Dethi Secretariat, Delhi. |
9, The Labour Commissioner, Government of NCT of Dethi, 5, Sham Nath Marg, Delhi- |
54. ; i
‘ l0. The Joint Labour Commissioner, Government of NCT of Delhi, 5, Sham Nath Marg, 4}!
Delhi-S4. SS Se ae
W The Chief Inspector of Factories, Tabour Department, Government of NCT of Nethi, 5, * | i
Sham Nath Marg, Delhi-54. =i
जे All Members concerned for information. हर : |
3. The Assistant Director (P & S), Labour Department, Government!of NCT of Delhi, 5, i
Sham Nath Marg, Delhi-5é, ~ 3 on By
I4. — Librariar/Guard File, : |
GR. her Y) ;
UNDER SECRETAR| roe (OUR) ‘
का. ठ0ण.कपए फायर =e
@
कि लक
