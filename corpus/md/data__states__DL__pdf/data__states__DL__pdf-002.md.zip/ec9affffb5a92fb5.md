---
doc_id: "ec9affffb5a92fb5"
source_url: "https://drugs.delhi.gov.in/sites/default/files/drugs/circulars-orders/fdc_prohibited.pdf"
ministry: "Drugs Control Department, Delhi"
title: "Download"
date: ""
pages: 158
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "feabab32fee87d85"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-21082024-256531
xxxGIDHxxx
CG-DL-E-21082024-256531
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 3125]
No. 3125]

नई दिल्ली, सोमवार, अगस्ट्त 12, 2024/ श्रावण 21, 1946
NEW DELHI, MONDAY, AUGUST 12, 2024/ SHRAVANA 21, 1946

स्ट्वास्ट््य और पररवार कल्याण मंत्रालय
(स्ट्वास्ट््य और पररवार कल्याण जवभाग)
अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3285(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक एमाइलेि+ प्रोटीि+ ग्लूकोमाइलेि+
पेजटटनेि+ अल्फा गैलट
े टोजसडेि+ लैटटेि+ बीटा- ग्लूकोनेि+ सेल्यूलि
े + लाइपेि + ब्रोमेलन
ै + िाइलेनि
े + हेजमके ल्यूलि
े +
माल्ट डायस्ट्टेि+ इनवटेि+ पपेन औषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात् एफ़डीसी कहा गया है) के
उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है।
अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के
जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार
के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क
के अधीन प्रजतषेध करने की जसफाररि की िाती है”;

5117 GI/2024

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने
पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करते
हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए एमाइलेि+ प्रोटीि+ ग्लूकोमाइलेि+ पेजटटनेि+ अल्फा
गैलट
े टोजसडेि+ लैटटेि+ बीटा- ग्लूकोनेस+ सेल्यूलि
े + लाइपेि + ब्रोमेलन
ै + िाइलानेि+ हेजमके ल्यूलि
े + माल्ट
डायस्ट्टेि+ इनवटेि+ पपेन औषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
MINISTRY OF HEALTH AND FAMILY WELFARE
(Department of Health and Family Welfare)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3285(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Amylase + Protease + Glucoamylase + Pectinase + Alpha
Galactosidase + Lactase + Beta-Gluconase + Cellulase + Lipase + Bromelain + Xylanase + Hemicellulase +
Malt diastase + Invertase + Papain is likely to involve risk to human beings whereas safer alternatives to the said
drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Amylase + Protease + Glucoamylase + Pectinase + Alpha Galactosidase + Lactase + Beta-Gluconase +
Cellulase + Lipase + Bromelain + Xylanase + Hemicellulase + Malt diastase + Invertase + Papain with
immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3286(अ).— कें द्रीय सरकार का यह जनयत समाधान हो िाने पर दक एंटीमनी पोटैजियम टारेट+सूखा
फे रस सल्फे ट औषजध की जनयत खुराक संयोिन (जिसे इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को
िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है।

<!-- page 3 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

3

अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के
जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार
के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन न्यायसंगत नहीं है। इसजलए, के वल धारा 26क
के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और िबदक उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान
हो िाने पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए एंटीमनी पोटैजियम टारेट + सूखा फे रस सल्फे ट औषजध के
जवक्रय के जलए जवजनमाकण, जवक्रय को तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3286(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Antimony Potassium Tartrate + Dried Ferrous Sulphate is
likely to involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Antimony Potassium Tartrate + Dried Ferrous Sulphate with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3287(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक बेनफोरटयामाइन+ जसलीमाररन+एलऑर्नकजथन एल-एस्ट्पाटेट+सोजडयम सेलन
े ाइट+फोजलक एजसड+पाइररडोजटसन हाइड्रोटलोराइड औषजध की जनयत खुराक
संयोिन (जिसे इसमें इसके पश्चात् एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है उक्त
औषजध के सुरजित जवकल्प उपलब्ध हैं;
और कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है।
अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार
के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क
के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने
पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करते
हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए बेनफोरटयामाइन+ जसलीमाररन+एल-ऑर्नकजथन एलएस्ट्पाटेट+सोजडयम सेलन
े ाइट+ फोजलक एजसड+ पाइररडोजटसन हाइड्रोटलोराइड औषजध के जनजित खुराक संयोिन के
जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3287(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Benfotiamine + Silymarin + L-Ornithine L-aspartate +
Sodium Selenite + Folic acid + Pyridoxine hydrochloride is likely to involve risk to human beings whereas safer
alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Benfotiamine + Silymarin + L-Ornithine L-aspartate + Sodium Selenite + Folic acid + Pyridoxine
hydrochloride with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3288(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक जबस्ट्मथ अमोजनयम साइरेट + पपैन औषजध
की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात् एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की
संभावना है उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है।

<!-- page 5 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

5

अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के
जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार
के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क
के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जबस्ट्मथ अमोजनयम साइरेट+ पपैन औषजध के जनजित
खुराक संयोिन के जवक्रय के जलए जवजनमाकण, जवक्रय तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3288(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Bismuth Ammonium Citrate + Papain is likely to involve risk
to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Bismuth Ammonium Citrate + Papain with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3289(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक साइप्रोहेप्टाडाइन एचसीएल + थायजमन
एचसीएल+राइबोफ्लेजवन+पाइररडोजटसन एचसीएल+जनयाजसनमाइड औषजध की जनयत खुराक संयोिन (जिसे इसमें
इसके पश्चात् एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है उक्त औषजध के सुरजित
जवकल्प उपलब्ध हैं;
और कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की गई थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है।
अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार
के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क
के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए साइप्रोहेप्टाडाइन एचसीएल+थायजमन
एचसीएल+राइबोफ्लेजवन+पाइररडोजटसन एचसीएल+जनयाजसनमाइड औषजध के जनजित खुराक संयोिन के जवक्रय के जलए
जवजनमाकण, जवक्रय पर तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3289(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Cyproheptadine HCl + Thiamine HCl + Riboflavine +
Pyridoxine HCl + Niacinamide is likely to involve risk to human beings whereas safer alternatives to the said drug
are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Cyproheptadine HCl + Thiamine HCl + Riboflavine + Pyridoxine HCl + Niacinamide with immediate
effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3290(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक साइप्रोहेप्टाडाइन हाइड्रोटलोराइड+रा
इकोजलन साइरेट+थायजमन हाइड्रोटलोराइड+राइबोफ्लेजवन+पाइररडोजटसन हाइड्रोटलोराइड औषजध की जनयत खुराक
संयोिन (जिसे इसमें इसके पश्चात् एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है उक्त
औषजध के सुरजित जवकल्प उपलब्ध हैं;
और कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;

<!-- page 7 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

7

और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है।
अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के
जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार
के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क
के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए साइप्रोहेप्टाडाइन हाइड्रोटलोराइड+राइकोजलन
साइरेट+थायजमन हाइड्रोटलोराइड+राइबोफ्लेजवन+पाइररडोजटसन हाइड्रोटलोराइड िवा के जनजित खुराक संयोिन के
जवक्रय के जलए जवजनमाकण, जवक्रय पर तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3290(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Cyproheptadine Hydrochloride + Tricholine Citrate +
Thiamine Hydrochloride + Riboflavine + Pyridoxine Hydrochloride is likely to involve risk to human beings
whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Cyproheptadine Hydrochloride + Tricholine Citrate + Thiamine Hydrochloride + Riboflavine +
Pyridoxine Hydrochloride with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3291(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक रबेप्रािोल सोजडयम (एंटेररक कोटेड
टैबलेट के रूप में) + जटलजडजनयम ब्रोमाइड+ डायसाइटलोमाइन एचसीएल+ टलोर्डकयािेपॉटसाइड औषजध की जनयत
खुराक संयोिन (जिसे इसमें इसके पश्चात् एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है
उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

और कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है।
अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के
जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार
के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन न्यायसंगत नहीं है। इसजलए, के वल धारा 26क
के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्र सरकार का यह समाधान हो िाने
पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करते
हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए रबेप्रािोल सोजडयम (एंटेररक कोटेड टैबलेट के रूप में)+
जटलजडजनयम ब्रोमाइड+ डायसाइटलोमाइन एचसीएल+ टलोर्डकयािेपॉटसाइड औषजध के जनजित खुराक संयोिन के जवक्रय
के जलए जवजनमाकण, जवक्रय पर तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3291(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Rabeprazole Sodium (As enteric coated tablet) + Clidinium
Bromide + Dicyclomine HCl + Chlordiazepoxide is likely to involve risk to human beings whereas safer
alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Rabeprazole Sodium (As enteric coated tablet) + Clidinium Bromide + Dicyclomine HCl +
Chlordiazepoxide with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3292(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक फं गल डायस्ट्टेस+पपैन+ नटस वोजमका
टटंचर+इलायची टटंचर+कै जसइन हाइड्रोलाइज्ड+अल्कोहल औषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात्
एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;

<!-- page 9 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

9

और कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है।
अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के
जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार
के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क
के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने
पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करते
हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए फं गल डायस्ट्टेस + पपैन + नटस वोजमका टटंचर + इलायची
टटंचर + कै जसइन हाइड्रोलाइज्ड + अल्कोहल औषजध के जनजित खुराक संयोिन के जवक्रय के जलए जवजनमाकण, जवक्रय पर
तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3292(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Fungal Diastase + Papain + Nux vomica Tincture +
Cardamom Tincture + Casein Hydrolysed + Alcohol is likely to involve risk to human beings whereas safer
alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Fungal Diastase + Papain + Nux vomica Tincture + Cardamom Tincture + Casein Hydrolysed +
Alcohol with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3293(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक मेफेनैजमक एजसड+ पैराजसटामोल इं िट
े िन
औषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात् एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने
की संभावना है उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

और कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है।
अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के
जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार
के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क
के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए मेफेनैजमक एजसड+ पैराजसटामोल इं िट
े िन औषजध के जनजित
खुराक संयोिन के जवक्रय के जलए जवजनमाकण, जवक्रय पर तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3293(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Mefenamic Acid + Paracetamol Injection is likely to involve
risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Mefenamic Acid + Paracetamol Injection with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3294(अ).— औषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात् एफ़डीसी कहा गया है) के
उपयोग से मनुष्यों को िोजखम होने की संभावना है उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;

<!-- page 11 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

11

और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है।
अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के
जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार
के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क
के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने
पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करते
हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए ओमेप्राजोल मैग्नीजियम + डायसाइटलोमाइन एचसीएल िवा के
जनजित खुराक संयोिन के जवक्रय के जलए जवजनमाकण, जवक्रय पर तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3294(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Omeprazole Magnesium + Dicyclomine HCl is likely
to involve risk to human beings whereas safer alternatives to the said drug are available;

And whereas, the matter was examined by an Expert Committee appointed by the Central
Government and the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended
that “there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve
risk to human beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or
distribution of this FDC under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind
of regulation or restriction to allow for any use in patients is not justifiable. Therefore, only prohibition
under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the
Central Government is satisfied that it is necessary and expedient in public interest to prohibit the
manufacture for sale, sale and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act,
1940 (23 of 1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution
for human use of drug FDC of Omeprazole Omeprazole Magnesium + Dicyclomine HCl with immediate
effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3295(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक एस-एडेनोजसल मेजथयोनीन
+मेटाडॉजटसन+उसोडॉटसीकोजलकएजसड बीपी+एल-जमथाइलफोलेट कै जल्ियम ईटयू. एल-जमथाइलफोलेट+कोलीन
जबटारेट+जसलीमाररन+एल-ऑर्नकजथन एल-एस्ट्पाटेट+इनोजसटोल+ टॉररन औषजध की जनयत खुराक संयोिन (जिसे इसमें

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

इसके पश्चात् एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है उक्त औषजध के सुरजित
जवकल्प उपलब्ध हैं;
और कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है।
अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के
जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार
के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क
के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए एस-एडेनोजसल मेजथयोनीन+ मेटाडॉजटसन+
उसोडॉटसीकोजलकएजसड
बीपी
+
एल-जमथाइलफोलेट
कै जल्ियम
ईटयू.
एल-जमथाइलफोलेट+कोलीन
जबटारेट+जसलीमाररन+एल-ऑर्नकजथन एल-एस्ट्पाटेट+ इनोजसटोल+टॉररन औषजध के जनजित खुराक संयोिन के जवक्रय के
जलए जवजनमाकण, जवक्रय पर तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3295(E).— Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of S-adenosyl methionine + Metadoxine + Ursodeoxycholicacid
BP + L-Methylfolate Calcium eq. to L-Methylfolate + Choline bitartratee + Silymarin + L-ornithine Laspartate + Inositol + Taurine is likely to involve risk to human beings whereas safer alternatives to the said drug
are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
S-adenosyl methionine + Metadoxine + Ursodeoxycholicacid BP + L-Methylfolate Calcium eq. to
L-Methylfolate + Choline bitartratee + Silymarin + L-ornithine L-aspartate + Inositol + Taurine with
immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 13 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

13

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3296(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक जसलीमाररन+जथयाजमन मोनोजनरेट+
राइबोफ्लेजवन+पाइररडोजटसन एचसीएल+जनयाजसनामाइड+कै जल्ियम पैंटोथेनटे + जवटाजमन बी12 औषजध की जनयत
खुराक संयोिन (जिसे इसमें इसके पश्चात् एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है
उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है।
अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के
जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार
के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क
के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जसलीमाररन+जथयाजमन मोनोजनरेट + राइबोफ्लेजवन +
पाइररडोजटसन एचसीएल+जनयाजसनामाइड+कै जल्ियम पैंटोथेनटे + जवटाजमन बी12 की जनजित खुराक संयोिन औषजध के
जवक्रय के जलए जवजनमाकण, जवक्रय पर तुरंत प्रभाव से प्रजतषेध करती है
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3296(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Silymarin + Thiamine Mononitrate + Riboflavin + Pyridoxine
HCl + Niacinamide + Calcium pantothenate + Vitamin B12 is likely to involve risk to human beings whereas safer
alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Silymarin + Thiamine Mononitrate + Riboflavin+ Pyridoxine HCl + Niacinamide + Calcium
pantothenate + Vitamin B12 with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3297(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक जसलीमाररन+ पाइररडोजटसन

एचसीएल+सायनोकोबालाजमन+जनयाजसनमाइड+फोजलक एजसड औषजध की जनयत खुराक संयोिन (जिसे इसमें
इसके पश्चात् एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है उक्त औषजध के
सुरजित जवकल्प उपलब्ध हैं;
और कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त
जविेषज्ञ सजमजत ने इस एफडीसी को तकक हीन माना था;
और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक
“इस एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो
सकता है। अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस
एफडीसी के जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए,
रोजगयों में दकसी भी प्रकार के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन
न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्र सरकार का यह समाधान
हो िाने पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण
को प्रजतजषद्ध करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा
26क द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जसलीमाररन+ पाइररडोजटसन
एचसीएल+सायनोकोबालाजमन+जनयाजसनमाइड+फोजलक एजसड की जनजित खुराक संयोिन औषजध के जवक्रय
के जलए जवजनमाकण, जवक्रय पर तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3297(E).— Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Silymarin + Pyridoxine HCl + Cyanocobalamin + Niacinamide
+ Folic Acid is likely to involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Silymarin + Pyridoxine HCl + Cyanocobalamin + Niacinamide + Folic Acid with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 15 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

15

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3298(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक जसलीमाररन+जवटाजमन बी6 + जवटाजमन
बी12+जनयाजसनामाइड+फोजलक एजसड+राइकोजलन साइरेट औषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात्
एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है।
अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के
जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार
के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबकधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क
के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्र सरकार का यह समाधान हो िाने
पर दक िेि में उक्त औषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करते
हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जसलीमाररन+जवटाजमन बी6+जवटाजमन
बी12+जनयाजसनामाइड+फोजलक एजसड+राइकोजलन साइरेट औषजध के जनजित खुराक संयोिन के जवक्रय के जलए
जवजनमाकण, जवक्रय पर तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3298(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Silymarin + Vitamin B6 + Vitamin B12 + Niacinamide + Folic
acid + Tricholine Citrate is likely to involve risk to human beings whereas safer alternatives to the said drug are
available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Silymarin + Vitamin B6 + Vitamin B12 + Niacinamide + Folic acid + Tricholine Citrate with immediate
effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 16 -->

16

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3299(अ).— के न्द्रीय सरकार का यह समाधान हो िाने पर दक सोजडयम साइरेट + साइररक एजसड
मोनोहाइड्रेट, इलायची तेल, िीरा तेल, िालचीनी तेल, लौंग का तेल, अिरक का तेल + अल्कोहल के स्ट्वाि वाला ओषजध
जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की
संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से सोजडयम साइरेट + साइररक एजसड
मोनोहाइड्रेट, इलायची तेल, िीरा तेल, िालचीनी तेल, लौंग का तेल, अिरक का तेल + अल्कोहल के स्ट्वाि वाली ओषजध
के जवक्रय के जलए जवजनमाकण, जवक्रय को प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3299(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Sodium Citrate + Citric Acid Monohydrate Flavored with
Cardamom Oil, Caraway Oil, Cinnamon Oil, Clove Oil, Ginger Oil + Alcohol is likely to involve risk to human
beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Sodium Citrate + Citric Acid Monohydrate Flavored with Cardamom Oil, Caraway Oil, Cinnamon Oil, Clove
Oil, Ginger Oil + Alcohol with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 17 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

17

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3300(अ).— के न्द्रीय सरकार का यह समाधान हो िाने पर दक सुक्रालफे ट + एटसेलोफे नाक ओषजध की
जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की
संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से सुक्रालफे ट + एटसेलोफे नाक ओषजध के जवक्रय के
जलए जवजनमाकण, जवक्रय को और जवतरण प्रजतजषद्ध करती है
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3300(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Sucralfate + Acelofenac is likely to involve risk to human beings
whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Sucralfate + Acelofenac with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 18 -->

18

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3301(अ).—के न्द्रीय सरकार का यह समाधान हो िाने पर दक सुक्रालफे ट + डोमपररडोन + डाइमेजथकोन
ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने
की संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से सुक्रालफे ट + डोमपररडोन + डाइमेजथकोन
ओषजध के जवक्रय के जलए जवजनमाकण,और जवतरण जवक्रय को तुरंन्त प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3301(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Sucralfate + Domperidone + Dimethicone is likely to involve
risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Sucralfate + Domperidone + Dimethicone with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 19 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

19

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3302(अ).— के न्द्रीय सरकार का यह समाधान हो िाने पर दक सुक्रालफे ट + डोमपररडोन ओषजध की
जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की
संभावना है िबदक उक्त िवा के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से सुक्रालफे ट + डोमपररडोन ओषजध के जवक्रय के
जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3302(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Sucralfate + Domperidone is likely to involve risk to human
beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Sucralfate + Domperidone with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 20 -->

20

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3303(अ).—के न्द्रीय सरकार का यह समाधान हो िाने पर दक टटंचर इपेकाकु आन्हा + टटंचर

अिेजनया + कै म्फोरे टेड ओजपयम टटंचर + अमोजनया की सुगजं धत आत्मा + टलोरोफॉमक + अल्कोहल ओषजध की
जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने
की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त
जविेषज्ञ सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो
सकता है। अत: व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस
एफडीसी के जवजनमाकण, जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए,
रोजगयों में दकसी भी प्रकार के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन
न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह
समाधान हो िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और
जवतरण को प्रजतजषिध करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा
26क द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से टटंचर इपेकाकु आन्हा +
टटंचर अिेजनया + कै म्फोरेटेड ओजपयम टटंचर + अमोजनया की सुगजं धत आत्मा + टलोरोफॉमक + अल्कोहल
ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3303(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Tincture Ipecacuanha + Tincture Urgenia + Camphorated
Opium Tincture + Aromatic Spirit of Ammonia + Chloroform + Alcohol is likely to involve risk to human beings
whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Tincture Ipecacuanha + Tincture Urgenia + Camphorated Opium Tincture + Aromatic Spirit of
Ammonia + Chloroform + Alcohol with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 21 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

21

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3304(अ).— के न्द्रीय सरकार का यह समाधान हो िाने पर दक उसोडॉजटसकोजलक एजसड + मेटफॉर्मकन
एचसीएल ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को
िोजखम होने की संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से उसोडॉजटसकोजलक एजसड + मेटफॉर्मकन
एचसीएल ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3304(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Ursodeoxycholic Acid + Metformin HCl is likely to involve risk
to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government
and the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the
Central Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for
sale, sale and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940
(23 of 1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of
drug FDC of Ursodeoxycholic Acid + Metformin HCl with immediate effect.

[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 22 -->

22

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3305(अ).— के न्द्रीय सरकार का यह समाधान हो िाने पर दक वीक जिंिर टटंचर + अमोजनया की
सुगजं धत भावना + पेपरजमंट जस्ट्पररट + टलोरोफॉमक + सोजडयम बाइकाबोनेट + यौजगक इलायची + अल्कोहल ओषजध की
जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की
संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से वीक जिंिर टटंचर + अमोजनया की सुगजं धत
भावना + पेपरजमंट जस्ट्पररट + टलोरोफॉमक + सोजडयम बाइकाबोनेट + यौजगक इलायची + अल्कोहल ओषजध के जवक्रय के
जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3305(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Weak Ginger tincture + Aromatic Spirit of Ammonia +
Peppermint Spirit + Chloroform + Sodium Bicarbonate + Compound Cardamom + Alcohol is likely to involve
risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Weak Ginger tincture + Aromatic Spirit of Ammonia + Peppermint Spirit +Chloroform +Sodium
Bicarbonate +Compound Cardamom + Alcohol with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 23 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

23

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3306(अ).— के न्द्रीय सरकार का यह समाधान हो िाने पर दक सुक्रालफे ट + पैंटोप्रािोल सोजडयम +
जिंक ग्लूकोनेट + लाइट मैग्नीजियम काबोनेट ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा
गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से सुक्रालफे ट + पैंटोप्रािोल सोजडयम + जिंक
ग्लूकोनेट + लाइट मैग्नीजियम काबोनेट ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3306(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Sucralfate + Pantoprazole Sodium + Zinc Gluconate + Light
Magnesium Carbonate is likely to involve risk to human beings whereas safer alternatives to the said drug are
available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Sucralfate + Pantoprazole Sodium + Zinc Gluconate + Light Magnesium Carbonate with immediate
effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 24 -->

24

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3307(अ).—के न्द्रीय सरकार का यह समाधान हो िाने पर दक एलो + जवटाजमन ई साबुन की जनयत
खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है
िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से एलो + जवटाजमन ई साबुन ओषजध के जवक्रय के
जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3307(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Aloe + Vitamin E Soap is likely to involve risk to human beings
whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Aloe + Vitamin E Soap with immediate effect.

[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 25 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

25

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3308(अ).— के न्द्रीय सरकार का यह समाधान हो िाने पर दक पोजवडोन आयोडीन मेरोजनडािोल +
एलो ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को
िोजखम होने की संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से पोजवडोन आयोडीन मेरोजनडािोल + एलो
ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3308(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Povidone Iodine+ Metronidazole + Aloe is likely to involve risk
to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Povidone Iodine + Metronidazole + Aloe with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 26 -->

26

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3309(अ).— के न्द्रीय सरकार का यह समाधान हो िाने पर दक एजेजलक एजसड + टी री ऑयल +
सैजलजसजलक एजसड + एलांटोइन + जिंक ऑटसाइड + एलोवेरा + िोिोबा ऑयल + जवटाजमन ई + सोप नूडल्स जनयत
खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है
िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए एजेजलक एजसड + टी री ऑयल + सैजलजसजलक एजसड +
एलांटोइन + जिंक ऑटसाइड + एलोवेरा + िोिोबा ऑयल + जवटाजमन ई + सोप नूडल्स के जवक्रय के जलए जवजनमाकण,
जवक्रय और जवतरण को तुरंन्त प्रभाव प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3309(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Azelaic acid + Tea Tree Oil + Salicylic acid + Allantoin + Zinc
oxide + Aloe vera + Jojoba oil + Vitamin E + Soap noodles is likely to involve risk to human beings whereas safer
alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Azelaic acid + Tea Tree Oil + Salicylic acid + Allantoin + Zinc oxide + Aloe vera + Jojoba oil + Vitamin
E + Soap noodles with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 27 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

27

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3310(अ).— के न्द्रीय सरकार का यह समाधान हो िाने पर दक एजजथ्रोमाइजसन + एडापेलीन जनयत
खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है
िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से एजजथ्रोमाइजसन + एडापेलीन ओषजध के जवक्रय
के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3310(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Azithromycin + Adapalene is likely to involve risk to human
beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Azithromycin + Adapalene with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 28 -->

28

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3311(अ).—के न्द्रीय सरकार का यह समाधान हो िाने पर है दक कै लामाइन + एलो + एलांटोइन
ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने
की संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से कै लामाइन + एलो + एलांटोइन ओषजध के
जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3311(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Calamine + Aloes + Allantoin is likely to involve risk to human
beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Calamine + Aloes + Allantoin with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 29 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

29

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3312(अ).—के न्द्रीय सरकार का यह समाधान हो िाने पर दक कै लामाइन + जडफे नहाइड्रामाइन
हाइड्रोटलोराइड + एलो + जग्लसरीन + कपूर ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा
गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से कै लामाइन + जडफे नहाइड्रामाइन
हाइड्रोटलोराइड + एलो + जग्लसरीन + कपूर ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3312(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Calamine + Diphenhydramine Hydrochloride + Aloe +
Glycerine + Camphor is likely to involve risk to human beings whereas safer alternatives to the said drug are
available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Calamine + Diphenhydramine Hydrochloride + Aloe + Glycerine + Camphor with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 30 -->

30

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3313(अ).— के न्द्रीय सरकार का यह समाधान हो िाने पर दक टलोरफे जनजसन + जिंक ऑटसाइड +
स्ट्टाचक ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को
िोजखम होने की संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से टलोरफे जनजसन + जिंक ऑटसाइड + स्ट्टाचक
ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3313(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Chlorphenesin + Zinc oxide + Starch is likely to involve risk to
human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Chlorphenesin + Zinc oxide + Starch with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 31 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

31

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3314(अ).— के न्द्रीय सरकार का यह समाधान हो िाने पर दक जटलंडामाइजसन फॉस्ट्फेट + जिंक एसीटेट
ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पश्चात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने
की संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, के न्द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की दक “इस एफडीसी
में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत: व्यापक
िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण, जवक्रय या
जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग की
अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, के न्द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषिध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, के न्द्रीय सरकार, औषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए मानव उपयोग के जलए तुरंन्त प्रभाव से जटलंडामाइजसन फॉस्ट्फे ट + जिंक एसीटेट
ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3314(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Clindamycin Phosphate + Zinc acetate is likely to involve risk
to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Clindamycin Phosphate + Zinc acetate with immediate effect.

[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 32 -->

32

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3315(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक गामा बेंिीन हेटसाटलोराइड + बेंजोके न
ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने
की संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है। इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए गामा बेंिीन हेटसाटलोराइड + बेंजोके न ओषजध के जवक्रय
के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3315(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Gamma Benzene Hexachloride + Benzocaine is likely to
involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Gamma Benzene Hexachloride + Benzocaine with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 33 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

33

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3316(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर ग्लूकोसामाइन हाइड्रोटलोराइड + डायसेररन
+ मेन्थॉल + कै म्फर + कै प्साइजसन ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है) के
उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है। इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त ओषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए ग्लूकोसामाइन हाइड्रोटलोराइड + डायसेररन + मेन्थॉल +
कै म्फर + कै प्साइजसन ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3316(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of
Glucosamine hydrochloride + Diacerein + Menthol +
Camphor + Capsaicin is likely to involve risk to human beings whereas safer alternatives to the said drug are
available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Glucosamine hydrochloride + Diacerein + Menthol + Camphor + Capsaicin with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 34 -->

34

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3317(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर हाइड्रोटसीदिनोन 2.0%w/w + ऑटटाइल
मेथोटसीजसनामेट 5.0% w/w + ऑटसीबेनजोन 30% w/w ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात
एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प
उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए हाइड्रोटसीदिनोन 2.0%w/w + ऑटटाइल मेथोटसीजसनामेट
5.0% w/w + ऑटसीबेनजोन 30% w/w ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से
प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3317(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Hydroxyquinone 2.0%w/w + Octyl Methoxycinnamate 5.0%
w/w + Oxybenzone 30 % w/w is likely to involve risk to human beings whereas safer alternatives to the said drug are
available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Hydroxyquinone 2.0%w/w + Octyl Methoxycinnamate 5.0% w/w + Oxybenzone 30 % w/w with
immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 35 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

35

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3318(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर के टोकोनाजोल + जिंक पाइररजथयोन + डीपैन्थेनॉल + टी री ऑयल + एलोज ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है) के
उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए के टोकोनाजोल + जिंक पाइररजथयोन + डी-पैन्थेनॉल + टी री
ऑयल + एलोज ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3318(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Ketoconazole +Zinc Pyrithione +D-Panthenol +Tea Tree Oil
+Aloes is likely to involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Ketoconazole +Zinc Pyrithione +D-Panthenol +Tea Tree Oil +Aloes with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 36 -->

36

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3319(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर के टोकोनाजोल + एलोवेरा + जवटाजमन ए
एसीटेट ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को
िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए के टोकोनाजोल + एलोवेरा + जवटाजमन ए एसीटेट ओषजध
के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3319(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Ketoconazole +Aloe vera+ Vitamin A Acetate is likely to
involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23
of 1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of
drug FDC of Ketoconazole +Aloe vera+ Vitamin A Acetate with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 37 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

37

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3320(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर के टोकोनाजोल + एलो + िेडपीटीओ ओषजध
की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की
संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए के टोकोनाजोल + एलो + िेडपीटीओ ओषजध के जवक्रय के
जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3320(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Ketoconazole +Aloes + ZPTO is likely to involve risk to human
beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23
of 1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of
drug FDC of Ketoconazole +Aloes + ZPTO with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 38 -->

38

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3321(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर कोजिक एजसड + आबुरक टन + ऑजटटनॉटसेट +
जवटाजमन ई + मलबेरी ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है) के उपयोग से
मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए कोजिक एजसड + आबुरक टन + ऑजटटनॉटसेट + जवटाजमन ई
+ मलबेरी ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3321(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Kojic Acid +Arbutin +Octinoxate +Vitamin E + Mulberry is
likely to involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Kojic Acid +Arbutin +Octinoxate +Vitamin E + Mulberry with immediate effect.

[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 39 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

39

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3322(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर लोनोजटसकै म + कै प्साइजसन + मेन्थॉल +
कपूर ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है) के उपयोग से ओषजध मनुष्यों को
िोजखम होने की संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है। इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए लोनोजटसकै म + कै प्साइजसन + मेन्थॉल + कपूर ओषजध के
जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3322(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Lornoxicam +capsaicin +menthol+ camphor is likely to involve
risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Lornoxicam + capsaicin + menthol + camphor with immediate effect.

[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 40 -->

40

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3323(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर लोनोजटसकै म + जथयोकोलजचकोसाइड +
ओजलयम जलनी + मेन्थॉल + जमथाइल सैजलजसलेट ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी
कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए लोनोजटसकै म + जथयोकोलजचकोसाइड + ओजलयम जलनी
+ मेन्थॉल + जमथाइल सैजलजसलेट ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध
करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3323(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Lornoxicam + Thiocolchicoside +Oleum Lini +Menthol +
Methyl salicylate is likely to involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Lornoxicam + Thiocolchicoside +Oleum Lini +Menthol + Methyl salicylate with immediate effect.

[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 41 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

41

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3324(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर मेन्थॉल + एलोवेरा टॉजपकल स्ट्प्रे ओषजध की
जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की
संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है। इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए मेन्थॉल + एलोवेरा टॉजपकल ओषजध के जवक्रय के जलए
जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3324(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Menthol + Aloe vera Topical Spray is likely to involve risk to
human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Menthol + Aloe vera Topical Spray with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 42 -->

42

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3325(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर मेन्थॉल + जलग्नोके न एचसीएल + एलोवेरा
िेल + टलोररमेजोल + जडफे नहाइड्रामाइन ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया
है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है। इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध िाने पर तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह
समाधान हो िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण
को प्रजतषेध करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए मेन्थॉल + जलग्नोके न एचसीएल + एलोवेरा िेल +
टलोररमेजोल + जडफे नहाइड्रामाइन ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध
करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3325(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Menthol +Lignocaine HCl +Aloe vera gel +Clotrimazole
+Diphenhydramine is likely to involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Menthol + Lignocaine HCl+Aloe vera gel + Clotrimazole + Diphenhydramine with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 43 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

43

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3326(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर माइक्रोनाजोल नाइरेट + िेंटामाइजसन +
फ्लुओजसनोलोन एसीटोनाइड + जिंक सल्फे ट ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा
गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए माइक्रोनाजोल नाइरेट + िेंटामाइजसन + फ्लुओजसनोलोन
एसीटोनाइड + जिंक सल्फे ट ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती
है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)

NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3326(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Miconazole nitrate + Gentamicin + Fluocinolone Acetonide
+Zinc Sulphate is likely to involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Miconazole nitrate + Gentamicin + Fluocinolone Acetonide +Zinc Sulphate with immediate effect.

[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 44 -->

44

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3327(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर माइक्रोनाजोल +रटजनडाजोल ओषजध की
जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की
संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है। इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने
पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए
इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए माइक्रोनाजोल +रटजनडाजोल ओषजध के जवक्रय के जलए
जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3327(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Miconazole +Tinidazole is likely to involve risk to human beings
whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Miconazole +Tinidazole with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 45 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

45

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3328(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर जमनोजटसजडल + अमीनेजटसल + अल्कोहल
ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने
की संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है। इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जमनोजटसजडल +अमीनेजटसल + अल्कोहल ओषजध के जवक्रय के
जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3328(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Minoxidil +Aminexil+ Alcohol is likely to involve risk to human
beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Minoxidil +Aminexil + Alcohol with immediate effect.

[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 46 -->

46

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3329(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर जमनोजटसजडल + एजेजलक एजसड + सॉ
पाल्मेटो ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को
िोजखम होने की संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है। इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने
पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए
इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जमनोजटसजडल + एजेजलक एजसड + सॉ पाल्मेटो ओषजध के
जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3329(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Minoxidil +Azelaic acid + saw palmetto is likely to involve risk
to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Minoxidil +Azelaic acid + saw palmetto with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 47 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

47

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3330(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक जमनोजटसजडल +अमीनेजटसल ओषजध के
जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने की
संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जमनोजटसजडल +अमीनेजटसल ओषजध के जवक्रय के जलए
जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3330(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Minoxidil +Aminexil is likely to involve risk to human beings
whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Minoxidil +Aminexil with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 48 -->

48

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3331(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक पाइन छाल का अकक + कोजिक एजसड +
सोजडयम एस्ट्कॉर्बकल फॉस्ट्फे ट ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग
से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए पाइन छाल का अकक + कोजिक एजसड + सोजडयम एस्ट्कॉर्बकल
फॉस्ट्फे ट ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3331 (E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Pine Bark extract+ Kojic acid +Sodium Ascorbyl Phosphate is
likely to involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and the
said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that “there
is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human beings.
Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC under
section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow for any
use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Pine Bark extract + Kojic acid + Sodium Ascorbyl Phosphate with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 49 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

49

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3332(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक पोजवडोन आयोडीन + रटजनडाजोल +
जिंक सल्फे ट ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को
िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए पोजवडोन आयोडीन +रटजनडाजोल + जिंक सल्फे ट ओषजध
के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3332(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Povidone Iodine +Tinidazole +Zinc sulphate is likely to involve
risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Povidone Iodine + Tinidazole + Zinc sulphate with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 50 -->

50

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3333(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक पोजवडोन आयोडीन + ऑर्नकडाजोल +
डेटसपेंथन
े ॉल ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को
िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए पोजवडोन आयोडीन + ऑर्नकडाजोल + डेटसपेंथन
े ॉल
ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3333(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Povidone Iodine + Ornidazole + Dexpanthenol is likely to
involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Povidone Iodine + Ornidazole + Dexpanthenol with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 51 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

51

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3334(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक सैजलजसजलक एजसड + एलोवेरा +
एलांटोइन + डी-पैन्थेनॉल ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से
मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए सैजलजसजलक एजसड + एलोवेरा + एलांटोइन + डीपैन्थेनॉल ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3334(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Salicyclic acid +Aloe vera+ Allantoin +D-Panthenol is likely to
involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Salicyclic acid + Aloe vera + Allantoin + D-Panthenol with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 52 -->

52

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3335(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक जसल्वर सल्फाजडयाजजन + टलोरहेजटसजडन
ग्लूकोनेट घोल + एलांटोइन + एलोवेरा िेल + जवटाजमन ई एसीटेट ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके
पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित
जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जसल्वर सल्फाजडयाजजन + टलोरहेजटसजडन ग्लूकोनेट घोल
+ एलांटोइन + एलोवेरा िेल + जवटाजमन ई एसीटेट ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत
प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3335(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Silver sulphadiazine +Chlorhexidine Gluconate solution
+Allantoin + Aloe vera gel +Vitamin E acetate is likely to involve risk to human beings whereas safer alternatives
to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Silver sulphadiazine +Chlorhexidine Gluconate solution +Allantoin + Aloe vera gel +Vitamin E acetate with
immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 53 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

53

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3336(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक सोजडयम सैजलजसलेट + जिंक ग्लूकोनेट +
पाइररडोजटसन एचसीएल ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से
मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए सोजडयम सैजलजसलेट + जिंक ग्लूकोनेट + पाइररडोजटसन
एचसीएल ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3336(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Sodium salicylate + Zinc gluconate + Pyridoxine HCl is likely
to involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Sodium salicylate + Zinc gluconate + Pyridoxine HCl with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 54 -->

54

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3337(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक टेरासाइकजलन + कोजलजस्ट्टन सल्फे ट
ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने
की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए टेरासाइकजलन + कोजलजस्ट्टन सल्फे ट ओषजध के जवक्रय के जलए
जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3337(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Tetracycline + Colistin Sulphate is likely to involve risk to
human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Tetracycline + Colistin Sulphate with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 55 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

55

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3338(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक टलोमीफीन + यूबाइडके रे नोन ओषजध के
जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने की
संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए टलोमीफीन + यूबाइडके रे नोन ओषजध के जवक्रय के जलए
जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3338(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Clomiphene +Ubidecarenone is likely to involve risk to human
beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Clomiphene + Ubidecarenone with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 56 -->

56

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3339(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक टलोमीफीन साइरेट + एस्ट्राजडयोल
वैलरे े ट का कॉजम्बदकट ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से
मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए टलोमीफीन साइरेट + एस्ट्राजडयोल वैलरे े ट का कॉजम्बदकट
ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3339(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Combikit of Clomiphene Citrate + Estradiol Valerate is likely
to involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Combikit Clomiphene Citrate + Estradiol Valerate with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 57 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

57

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3340(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक फ्लेवॉटसेट एचसीएल + ओफ़्लॉटसाजसन
ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने
की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए फ्लेवॉटसेट एचसीएल +ओफ़्लॉटसाजसन ओषजध के जवक्रय
के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3340(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Flavoxate HCl +Ofloxacin is likely to involve risk to human
beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Flavoxate HCl + Ofloxacin with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 58 -->

58

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3341(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक टलोमीफीन साइरेट +एनएजसटाइलजसस्ट्टीन ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से
मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के टलोमीफीन साइरेट +एन-एजसटाइलजसस्ट्टीन ओषजध के जवक्रय
के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3341(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Clomiphene Citrate +N-Acetylcysteine is likely to involve risk
to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Clomiphene Citrate + N-Acetylcysteine with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 59 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

59

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3342(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक इवजनंग जप्रमरोज तेल + कॉड जलवर आयल
ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने
की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए इवजनंग जप्रमरोज तेल + कॉड जलवर आयल ओषजध के
जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3342(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Evening Primerose Oil +Cod liver oil is likely to involve risk to
human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Evening Primerose Oil +Cod liver oil with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 60 -->

60

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3343(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक जसल्डेनादफल साइरेट + पापावेररन +
एल-आर्िकजनन ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों
को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जसल्डेनादफल साइरेट + पापावेररन + एल-आर्िकजनन
ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3343(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Sildenafil Citrate +Papaverine +L-Arginine is likely to involve
risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Sildenafil Citrate +Papaverine +L-Arginine with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 61 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

61

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3344(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक रैनट
े सैजमक एजसड + मेफेनैजमक एजसड +
जवटाजमन के 1 ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को
िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अंत:
व्यापक िनजहत में, औषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने पर
दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध करते हुए इसे
जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अंत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए रैनट
े सैजमक एजसड +मेफेनैजमक एजसड +जवटाजमन के 1
ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3344(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Tranexamic acid +Mefenamic acid + Vitamin K1 is likely to
involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Tranexamic acid + Mefenamic acid + Vitamin K1 with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 62 -->

62

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3345(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक डाइवलप्रोएटस सोजडयम +
ऑटसकाबाकजप
े ाइन ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से
मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िनजहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए डाइवलप्रोएटस सोजडयम + ऑटसकाबाकजप
े ाइन ओषजध के
जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3345(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Divalproex Sodium +Oxcarbazepine is likely to involve risk to
human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Divalproex Sodium +Oxcarbazepine with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 63 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

63

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3346(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक डाइवलप्रोएटस सोजडयम + लेवजे तरसेटम
ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने
की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए डाइवलप्रोएटस सोजडयम +लेवजे तरसेटम ओषजध के जवक्रय के
जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3346(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Divalproex Sodium + Levetiracitam is likely to involve risk to
human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Divalproex Sodium +Levetiracitam with immediate effect
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 64 -->

64

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3347(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक एगोटामाइन टारेट + कै फीन +
पैराजसटामोल + प्रोटलोरपेरजजन मैलटे ओषजध के जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है )
की उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए एगोटामाइन टारेट + कै फीन + पैराजसटामोल +
प्रोटलोरपेरजजन मैलटे के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3347(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Ergotamine tartrate +Caffeine + Paracetamol
+Prochlorperazine maleate is likely to involve risk to human beings whereas safer alternatives to the said drug are
available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Ergotamine tartrate + Caffeine + Paracetamol + Prochlorperazine maleate with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 65 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

65

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3348(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक जपरासेटम + जिन्कगो जबलोबा अकक +
जवनपोसेरटन ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को
िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
जनषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जपरासेटम + जिन्कगो जबलोबा अकक + जवनपोसेरटन ओषजध
के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3348(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Piracetam + Ginkgo biloba extracts + Vinpocetin is likely to
involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Piracetam + Ginkgo biloba extracts + Vinpocetin with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 66 -->

66

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3349(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक जिन्कगो जबलोबा + जमथाइलकोबालाजमन
ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने
की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जिन्कगो जबलोबा + जमथाइलकोबालाजमन ओषजध के
जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3349 (E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Ginkgo biloba + methylcobalamin is likely to involve risk to
human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Ginkgo biloba + methylcobalamin with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 67 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

67

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3350(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक जिन्कगो जबलोबा + जमथाइलकोबालाजमन
+ अल्फा जलपोइक एजसड + पाइररडोजटसन एचसीएल ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात
एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प
उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतजषद्ध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जिन्कगो जबलोबा + जमथाइलकोबालाजमन +अल्फा जलपोइक
एजसड + पाइररडोजटसन एचसीएल ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध
करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3350(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Ginkgo biloba + methylcobalamin + Alpha lipoic acid
+Pyridoxine HCl is likely to involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Ginkgo biloba + methylcobalamin + Alpha lipoic acid + Pyridoxine HCl with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 68 -->

68

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3351(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक जिनसेंग अकक + जिन्कगो जबलोबा का
सूखा अकक ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को
िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जिनसेंग अकक + जिन्कगो जबलोबा का सूखा अकक ओषजध के
जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3351(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Ginseng Extract +Dried extract of Ginkgo Biloba is likely to
involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Ginseng Extract + Dried extract of Ginkgo Biloba with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 69 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

69

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3352(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक मेजटलजजन एचसीएल + पेराजसटामोल +
कै फीन ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को
िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए मेजटलजजन एचसीएल + पेराजसटामोल + कै फीन ओषजध के
जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3352(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Meclizine HCl+ Paracetamol + Caffeine is likely to involve risk
to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Meclizine HCl+ Paracetamol + Caffeine with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 70 -->

70

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3353(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक जनकरगोजलन + जवनपोसेटीन ओषजध की
जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने की
संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतषेध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए जनकरगोजलन + जवनपोसेटीन ओषजध के जवक्रय के जलए
जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3353(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Nicergoline + Vinpocetine is likely to involve risk to human
beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Nicergoline + Vinpocetine with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 71 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

71

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3354(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक गामा जलनोलेजनक एजसड +
जमथाइलकोबालाजमन ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से
मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए गामा जलनोलेजनक एजसड + जमथाइलकोबालाजमन ओषजध
के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3354(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Gamma Linolenic Acid + Methylcobalamin is likely to involve
risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Gamma Linolenic Acid + Methylcobalamin with immediate effect
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 72 -->

72

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3355(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक बेटलोमीथासोन जडप्रोजपयोनेट +
जनयोमाइजसन सल्फे ट + टलोररमेजोल + जलग्नोके न एचसीएल ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात
एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प
उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए बेटलोमीथासोन जडप्रोजपयोनेट + जनयोमाइजसन सल्फे ट +
टलोररमेजोल + जलग्नोके न एचसीएल ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध
करती है
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3355(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Beclomethasone Dipropionate + Neomycin Sulphate +
Clotrimazole + Lignocaine HCl is likely to involve risk to human beings whereas safer alternatives to the said drug
are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Beclomethasone Dipropionate + Neomycin Sulphate + Clotrimazole + Lignocaine HCl with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 73 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

73

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3356(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक बोररक एजसड + दफनाइलफ्राइन

एचसीएल + नेफजोजलन नाइरेट + मेन्थॉल + कै म्फर ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात
एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित
जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त
जविेषज्ञ सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक
“इस एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो
सकता हैं। अत: व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस
एफडीसी के जवजनमाकण, जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए,
रोजगयों में दकसी भी प्रकार के उपयोग की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन
न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह
समाधान हो िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और
जवतरण को प्रजतजषद्ध करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा
26क द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए दक बोररक एजसड + दफनाइलफ्राइन
एचसीएल + नेफजोजलन नाइरेट + मेन्थॉल + कै म्फर ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण
को तुरंत प्रभाव से प्रजतषेध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3356(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Boric acid+ Phenylephrine HCl + Naphazoline Nitrate +
Menthol + Camphor is likely to involve risk to human beings whereas safer alternatives to the said drug are
available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Boric acid+ Phenylephrine HCl + Naphazoline Nitrate + Menthol + Camphor with immediate effect
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 74 -->

74

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3357(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर
दक नेफाजोजलन एचसीएल +
टलोरफे जनरामाइन मैलटे + जिंक सल्फे ट + हाइड्रोटसी प्रोपाइल जमथाइल सेलल
ु ोि ओषजध की जनयत खुराक संयोिन (जिसे
इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के
सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए नेफाजोजलन एचसीएल + टलोरफे जनरामाइन मैलटे + जिंक
सल्फे ट + हाइड्रोटसी प्रोपाइल जमथाइल सेलल
ु ोि ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव
से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3357(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Naphazoline HCl + Chlorpheniramine Maleate + Zinc
Sulphate + Hydroxy Propyl Methyl Cellulose is likely to involve risk to human beings whereas safer alternatives to
the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Naphazoline HCl + Chlorpheniramine Maleate + Zinc Sulphate + Hydroxy Propyl Methyl Cellulose with
immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 75 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

75

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3358(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर
दक नेफ़ाजोजलन एचसीएल +
टलोरफे जनरामाइन मैलटे + सोजडयम टलोराइड + जिंक सल्फे ट + हाइड्रॉटसी प्रोपाइल जमथाइल सेलल
ु ोज ओषजध की
जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने की
संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने
पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करते
हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए नेफ़ाजोजलन एचसीएल + टलोरफे जनरामाइन मैलटे +
सोजडयम टलोराइड + जिंक सल्फे ट + हाइड्रॉटसी प्रोपाइल जमथाइल सेलल
ु ोज ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय
और जवतरण को तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3358(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Chlorpheniramine Maleate + Naphazoline HCl + Zinc
Sulphate + Sodium Chloride + Hydroxy Propyl Methyl Cellulose is likely to involve risk to human beings whereas
safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Chlorpheniramine Maleate + Naphazoline HCl + Zinc Sulphate + Sodium Chloride + Hydroxy Propyl Methyl
Cellulose with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 76 -->

76

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3359(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक टलोरफे जनरामाइन मैलटे + नेफ़ाजोजलन
एचसीएल + हाइड्रॉटसी प्रोपाइल जमथाइल सेलल
ु ोज ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी
कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतषेध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए टलोरफे जनरामाइन मैलटे + नेफ़ाजोजलन एचसीएल +
हाइड्रॉटसी प्रोपाइल जमथाइल सेलल
ु ोज ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से
प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3359(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Chlorpheniramine Maleate + Naphazoline HCl + Hydroxy
Propyl Methyl Cellulose is likely to involve risk to human beings whereas safer alternatives to the said drug are
available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Chlorpheniramine Maleate + Naphazoline HCl + Hydroxy Propyl Methyl Cellulose with immediate
effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 77 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

77

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3360(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक टलोरफे जनरामाइन मैलटे + सोजडयम
टलोराइड + बोररक एजसड + टेराहाइड्रोजोजलन एचसीएल ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात
एफ़डीसी कहा गया है ) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक उक्त औषजध के सुरजित जवकल्प
उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, औषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता हैं। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाले दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है । इसजलए, के वल धारा 26क के अधीन
प्रजतषेध करने की जसफाररि की िाती है”;
और उक्त औषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो
िाने पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध
करते हुए इसे जवजनयजमत करना िन जहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के टलोरफे जनरामाइन मैलटे + सोजडयम टलोराइड + बोररक
एजसड + टेराहाइड्रोजोजलन एचसीएल ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को तुरंत प्रभाव से
प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3360(E).— Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Chlorpheniramine Maleate + Sodium Chloride + Boric Acid +
Tetrahydrozoline HCl is likely to involve risk to human beings whereas safer alternatives to the said drug are
available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Chlorpheniramine Maleate + Sodium Chloride + Boric Acid + Tetrahydrozoline HCl with immediate
effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 78 -->

78

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3361(अ).— कें द्रीय सरकार का यह समाधान हो िाने पर दक टलोरफे जनरामाइन मैलटे +
दफनाइलफ्राइन एचसीएल + एंटीपायररन िवा के जनजित खुराक संयोिन (जिसे तिनुपरांत एफ़डीसी के रूप में िाना
िायेगा) के उपयोग से मनुष्यों को खतरा होने की संभावना है दक उक्त िवा के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, ओषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण ,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाला दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है। इसजलए, के वल धारा 26क के अधीन
प्रजतषेध की जसफाररि की िाती है”;
और उक्त ओषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने
पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करते
हुए इसे जवजनयजमत करना िनजहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क
द्वारा प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए टलोरफे जनरामाइन मैलटे + दफनाइलफ्राइन एचसीएल +
एंटीपायररन ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3361(E).— Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Chlorpheniramine Maleate + Phenylephrine HCl + Antipyrine
is likely to involve risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Chlorpheniramine Maleate + Phenylephrine HCl + Antipyrine with immediate effect.

[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 79 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

79

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3362(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक के टोरोलैक रोमेथामाइन +
टलोरफे जनरामाइन मैलटे + दफनाइलफ्राइन एचसीएल + हाइड्रॉटसी प्रोपाइल जमथाइल सेलल
ु ोि ओषजध की जनयत खुराक
संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने की संभावना है िबदक
उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, ओषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण ,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाला दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है। इसजलए, के वल धारा 26क के अधीन
प्रजतषेध की जसफाररि की िाती है”;
और उक्त ओषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने
पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करते
हुए इसे जवजनयजमत करना िनजहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए के टोरोलैक रोमेथामाइन + टलोरफे जनरामाइन मैलटे +
दफनाइलफ्राइन एचसीएल + हाइड्रॉटसी प्रोपाइल जमथाइल सेलल
ु ोि ओषजध के जवक्रय के जलए जवजनमाकण, जवक्रय और
जवतरण तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3362(E).—Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Ketorolac Tromethamine + Chlorpheniramine Maleate +
Phenylephrine HCl + Hydroxy Propyl Methyl Cellulose is likely to involve risk to human beings whereas safer
alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of 1940),
the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug FDC of
Ketorolac Tromethamine + Chlorpheniramine Maleate + Phenylephrine HCl + Hydroxy Propyl Methyl
Cellulose with immediate effect.
[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)

<!-- page 80 -->

80

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

अजधसूचना
नई दिल्ली, 2 अगस्ट्त, 2024
का.आ. 3363(अ).—कें द्रीय सरकार का यह समाधान हो िाने पर दक के टोरोलैक रोमेथामाइन + फ्लोरोमेथोलोन
ओषजध की जनयत खुराक संयोिन (जिसे इसमें इसके पिात एफ़डीसी कहा गया है) के उपयोग से मनुष्यों को िोजखम होने
की संभावना है िबदक उक्त ओषजध के सुरजित जवकल्प उपलब्ध हैं;
और, कें द्रीय सरकार द्वारा जनयुक्त एक जविेषज्ञ सजमजत द्वारा इस मामले की िांच की गई थी और उक्त जविेषज्ञ
सजमजत ने इस एफडीसी को तकक हीन माना था;
और, ओषजध तकनीकी सलाहकार बोडक ने भी उक्त एफडीसी की िांच की थी और जसफाररि की थी दक “इस
एफडीसी में अंतर्वकष्ट अवयवों का कोई जचदकत्सीय औजचत्य नहीं है। इस एफडीसी से मनुष्यों को िोजखम हो सकता है। अत:
व्यापक िनजहत में, ओषजध और प्रसाधन सामग्री अजधजनयम 1940 की धारा 26क के अधीन इस एफडीसी के जवजनमाकण ,
जवक्रय या जवतरण को प्रजतजषद्ध करना आवश्यक है। उपरोक्त को ध्यान में रखते हुए, रोजगयों में दकसी भी प्रकार के उपयोग
की अनुमजत िेने वाला दकसी भी प्रकार का जवजनयमन या जनबंधन न्यायसंगत नहीं है। इसजलए, के वल धारा 26क के अधीन
प्रजतषेध की जसफाररि की िाती है”;
और उक्त ओषजध तकनीकी सलाहकार बोडक की जसफाररिों के आधार पर, कें द्रीय सरकार का यह समाधान हो िाने
पर दक िेि में उक्त ओषजध के मानव उपयोग के जलए जवक्रय के जलए जवजनमाकण, जवक्रय और जवतरण को प्रजतजषद्ध करते
हुए इसे जवजनयजमत करना िनजहत में आवश्यक और समीचीन है;
अत: अब, कें द्रीय सरकार, ओषजध और प्रसाधन सामग्री अजधजनयम, 1940 (1940 का 23) की धारा 26क द्वारा
प्रित्त िजक्तयों का प्रयोग करते हुए, मानव उपयोग के जलए के टोरोलैक रोमेथामाइन + फ्लोरोमेथोलोन ओषजध के जवक्रय के
जलए जवजनमाकण, जवक्रय और जवतरण तुरंत प्रभाव से प्रजतजषद्ध करती है।
[फा. सं. एटस-11035/53/2014-डीएफ़टयूसी (भाग-IV)]
रािीव वधावन, सलाहकार (लागत)
NOTIFICATION
New Delhi, the 2nd August, 2024
S.O. 3363(E).— Whereas, the Central Government is satisfied that the use of the drug Fixed Dose
Combination (hereinafter to be referred as FDC) of Ketorolac Tromethamine + Flurometholone is likely to involve
risk to human beings whereas safer alternatives to the said drug are available;
And whereas, the matter was examined by an Expert Committee appointed by the Central Government and
the said Expert Committee considered this FDC as irrational;
And whereas, the Drugs Technical Advisory Board also examined the said FDC and recommended that
“there is no therapeutic justification for the ingredients contained in this FDC. The FDC may involve risk to human
beings. Hence in the larger public interest, it is necessary to prohibit the manufacture, sale or distribution of this FDC
under section 26 A of Drugs and Cosmetics Act 1940. In view of above, any kind of regulation or restriction to allow
for any use in patients is not justifiable. Therefore, only prohibition under section 26A is recommended”;
And whereas on the basis of the recommendations of the said Drugs Technical Advisory Board, the Central
Government is satisfied that it is necessary and expedient in public interest to prohibit the manufacture for sale, sale
and distribution for human use of the said drug in the country;
Now, therefore, in exercise of powers conferred by section 26A of the Drugs and Cosmetics Act, 1940 (23 of
1940), the Central Government hereby prohibits the manufacture for sale, sale and distribution for human use of drug
FDC of Ketorolac Tromethamine + Flurometholone with immediate effect.

[F. No. X-11035/53/2014-DFQC (Part-IV)]
RAJIV WADHAWAN, Advisor (Cost)
