---
doc_id: "a97b36ed344ecdeb"
source_url: "https://environment.delhi.gov.in/sites/default/files/%20environment/corrigendum/2022_dpgs_222034_1_1.pdf"
ministry: "Enviornment Department, Delhi"
title: "(Bid Doc.)"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9bed7b87d9a8f6db"
---

<!-- page 1 -->

eTendering System Government of NCT of Delhi

Page 1 of 3

eTendering System Government of NCT of Delhi
Tender Details
Date : 11-May-2022 03:49 PM
Print

Basic Details
Organisation Chain

Delhi Parks and Gardens Society

Tender Reference
Number

F.58(52)/DH/TG/2021-22/391

Tender ID

2022_DPGS_222034_1

Tender Type

Open Tender

Form of contract

Supply

Tender Category

Goods

No. of Covers

2

General Technical
Evaluation Allowed

No

ItemWise Technical
Evaluation Allowed

No

Payment Mode

Offline

Is Multi Currency Allowed For
No
BOQ

Is Multi Currency
Allowed For Fee

No

Allow Two Stage Bidding

No

Payment Instruments

Cover Details, No. Of Covers - 2

Offline S.NoInstrument Type

Cover
Cover
No

1

Demand Draft

2

FDR
1

Document Type

Description

Fee/PreQual/Technical .pdf

Copy Of Bid
Security (Earnest
Money Deposit)
for an amount of
Rs.180000

.pdf

Scanned copy of
registration as
per tender
document

.pdf

Self attested copy
of PAN Card
under Income
Tax Act. along
with last three
years income tax
returns.

.pdf

Self attested
copies of GST
registration
number.

.pdf

An undertaking to
the effect that
the
contractor/agency
has not been
blacklisted by any
Govt. Deptt

.pdf

Scanned copy of
signed terms and
condition by
contractor

.pdf

Undertaking on
Rs. 100/- stamp
paper as per
tender document

.pdf

https://govtprocurement.delhi.gov.in/nicgep/app?component=%24DirectLink&page=Publi... 5/11/2022

<!-- page 2 -->

eTendering System Government of NCT of Delhi

Page 2 of 3

Proof of
ownership of
farms producing
breeder seeds
and foundation
seeds to ensure
purity of seeds.

2

Tender Fee Details, [Total Fee in ₹ * - 0.00]
Tender Fee in ₹

0.00

Fee Payable To

Nil

Tender Fee
Exemption
Allowed

No

Fee Payable At

Finance

.pdf

Proof of
ownership of
quality control
labs

.pdf

Proof of
ownership of
seed drying and
cleaning facilities

.xls

Price Bid

EMD Fee Details
EMD Amount in ₹

1,80,000

EMD through
No
BG/ST or EMD
Exemption Allowed

EMD Fee Type

fixed

EMD Percentage

EMD Payable To

DDO,
EMD Payable At
Horticulture
Unit

Nil

NA
Delhi

Click to view modification history

Work /Item(s)
Title

SUPPLY OF DIY KITS FOR INTRODUCTION TO URBAN FARMING 2022-23

Work Description

SUPPLY OF DIY KITS FOR INTRODUCTION TO URBAN FARMING 2022-23

Pre Qualification
Details

Please refer Tender documents.

Independent External NA
Monitor/Remarks
Show Tender Value in Yes
Public Domain
Tender Value in ₹

60,00,000

Product Category

Miscellaneous Sub category
Goods

NA

Contract Type

Tender

Bid Validity(Days)

90

Period Of Work(Days) 365

Location

As per
tender
document

Pincode

110002

Pre Bid Meeting Place NA

Pre Bid Meeting
Address

NA

Pre Bid Meeting Date NA

Should Allow NDA
Tender

No

Allow Preferential
Bidder

No

11-May-2022 05:00 PM

Bid Opening Place

Office of the
Director,Horticulture,11th
Floor,MSO

Critical Dates
Publish Date

Bid Opening Date

31-May-2022 02:00 PM

Document Download / Sale Start 11-May-2022 05:00 PM
Date

Document Download / Sale End
Date

31-May-2022 12:00 PM

Clarification Start Date

NA

Clarification End Date

NA

Bid Submission Start Date

11-May-2022 05:00 PM

Bid Submission End Date

31-May-2022 12:00 PM

https://govtprocurement.delhi.gov.in/nicgep/app?component=%24DirectLink&page=Publi... 5/11/2022

<!-- page 3 -->

eTendering System Government of NCT of Delhi

Page 3 of 3

Tender Documents
NIT
Document

S.No Document Name

Description

1

NIT

Work Item
Documents

Tendernotice_1.pdf

Document
Size (in KB)
120.98

S.No Document Type

Document Name

Description

1
2

TenderDoc.pdf
BOQ_286495.xls

Tender Document
Price Bid

Tender Documents
BOQ

Document
Size (in KB)
677.92
285.00

Bid Openers List
S.No
1.
2.
3.

Bid Opener Login Id
rameshku0192@gmail.com
kuldeepetender@gmail.com
meena.ravindra6286@gmail.com

Bid Opener Name
Ramesh Kumar
Kuldeep Kumar
Ravindra Kumar Meena

Certificate Name
RAMESH KUMAR
KULDEEP KUMAR
RAVINDRA KUMAR MEENA

Tender Properties
Auto Tendering
Process allowed

No

Show Technical bid status

Yes

Show Finance bid
status
BoQ Comparative Chart
model
BoQ Comparative Chart
Rank Type

Yes

Show Bids Details

Yes

Normal

BoQ Compartive chart decimal places

3

L

Form Based BoQ

No

Tender Inviting Authority
Name

Director, Horticulture

Address

11th Floor, MSO Building,ITO New Delhi

Tender Creator Details
Created By

Kuldeep Kumar

Designation

Horticulture Assistant

Created Date

11-May-2022 03:41 PM

https://govtprocurement.delhi.gov.in/nicgep/app?component=%24DirectLink&page=Publi... 5/11/2022
