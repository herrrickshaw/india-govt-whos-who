---
doc_id: "f3bef738a8eebe6e"
source_url: "https://artandculture.delhi.gov.in/sites/default/files/Art%20and%20Culture/circulars-orders/reg._comments_of_stakeholders_for_amendemnt_of_rrs_for_the_post_of_technical_assistant_hindi_in_the_department_of_acl_gnctd_1.pdf"
ministry: "Art, Culture and Language Department, Delhi"
title: "Download"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "14fe0e22503921a1"
---

<!-- page 1 -->

Art, Culture &amp; Language Department
Government of NCT of Delhi
6th Level, C-Wing, Delhi Secretariat
New Delhi -110002

F. No. 13(168)/2022/ ACL ^"f 6

Dated

The Department is in process of the framing of RRs for the post of Technical Assistant (Hindi} sanctioned in Department of Delhi Archives
and Department of ACL GovL of NCT of Delhi under consultation with Services Department Thefollowing draft RRs has been proposed:
Col.

Title

Revised provisions proposed

No.

1

2

1.

Name of the post

Technical Assistant (Hindi)

2.

Number of post

06*(2023)

3

*Subject to variation dependent on workload.
Note:
05 posts in ACL department
01 posts in Department of Delhi Archives
3.

Classification

General Central Service, Group-B, Non Ministerial, Non-Gazetted

4.

Pay Level in the Pay Matrix

Level-6
(Rs. 35400-112400)

5.

Whether Selection post or Non-

Not Applicable

Selection post
6.

Age Limit for direct recruits

Not Exceeding 30 Years.
Note 1: Relaxable for Government Servant up to five years in accordance with the
instructions or orders issued by the Central Government.
Note 2: The crucial date for determining the age-limit shall be as advertised by the
DSSSB/Competent Authority.

7.

Educational and other Qualification
required for Direct Recruits

Essential Qualification:
(i) Master's degree of a recognized University in Hindi with English as a compulsory or
elective subject or as a medium of examination at degree level;

OR
Master's degree of a recognized University in English with Hindi as a compulsory or
elective subject or as the medium of examination at degree level;
OR
Master's degree of a recognized University in any subject other than Hindi or English, with
Hindi Medium and English as a compulsory or elective subject or as the medium of a
examination at the degree level;
OR
Master's degree of a recognized University in any subject other than Hindi or English with
English medium and Hindi as a compulsory or elective subject or as medium of
examination at degree level;

(OR)
Master's degree of a recognized University in any subject other than Hindi or English with
Hindi and English as a compulsory or elective subjects or either of the two as a medium of
examination and the other as a compulsory or elective subject at degree level; and
(ii) Possessing a recognized Diploma or Certificate course in translation from Hindi to
English and vice versa or two years' experience of translation work from Hindi to English
and vice-versa in the Central or State Government, including Government of India
Undertaking.

<!-- page 2 -->

Note 1: Qualifications are relaxable at the discretion of the Competent Authority/ DSSSB,
for reasons to be recorded in writing, in case of candidates otherwise well qualified.
Note 2 : The qualification regarding experience is relaxable at the discretion of the
Competent Authority/ DSSSB, for reasons to be recorded in writing, in the case of
candidates belonging to Scheduled Castes or Scheduled Tribes, if at any stage of selection
the Competent Authority or the Staff Selection Commission is of the opinion that sufficient
number of candidates from these communities possessing the requisite experience are not
likely to be available to fill up the posts reserved for them.
s.

Whether age and Educational
Qualification prescribed for direct
recruits will apply in the case of

Not Applicable

promotees
9.

10.

Period of probation, if any

Two years

Method of Recruitment whether by

By direct recruitment

direct recruitment or by promotion
or by Deputation/absorption &
percentage of the posts to be filled
by various methods.

11.

In case of Recruitment by
Promotion/deputation/absorption,
grades from which Promotion/

Note : Vacancies caused by the incumbent being away on deputation or long illness or
study leave or under other circumstances for a duration of one year or more may be filled
on deputation basis from officers of Central Government holding analogous posts on
regular basis and possessing the qualifications prescribed for direct recruits under Col 7.
Not applicable

deputation/ absorption to be made
12.

If a Departmental Promotion

Departmental Confirmation Committee:

Committee exists, what is its

1. Financial Commissioner, Government of NCT of Delhi: Chairperson

composition

2. Administrative Secretary of the Department of Art, Culture & Languages, Government of
National Capital Territory of Delhi: Member
3. Special/Additional Secretary (GAD), Government of National Capital Territory of Delhi:
Member
Note : Senior most member of the Departmental Confirmation Committee shall act as
Chairperson in case the notified Chairman of the Departmental Confirmation Committee
happens to be junior to another member of the Departmental Confirmation Committee.

13.

Circumstances in which UPSC is to
be consulted in making recruitment

Not Applicable

All the stakeholders are requested to submit their comments/suggestion within one month of uploading of the draft RRs on the wei^ite of the
Department

Ji
(Sanjay Kumar Garg)

OSD(ACL|
