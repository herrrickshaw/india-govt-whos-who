---
doc_id: "4adf2bab5b659bfd"
source_url: "https://hjbhabhaiti.delhi.gov.in/sites/default/files/hjbhabhaiti/circulars-orders/cts_mains_schedule_2026_rev_2.pdf"
ministry: "Dr. H.J. Bhabha ITI Khichripur, Mayur Vihar, Delhi"
title: "Download"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "dc73569e824688ef"
---

<!-- page 1 -->

No.MSDE-18011/08/CTS/CTS/Dec-21/2021-TTC

I/26164/2026

File No. MSDE-18011/08/CTS/CTS/Dec-21/2021-TTC
(FTS no. E-44186)
भारत सरकार
कौशल विकास और उद्यमशीलता मत्रं ालय
प्रवशक्षण महाविदेशालय
कौशल भवन, सातवााँ तल
न्यू मोती बाग, नई दिल्ली-110023
दिनाांक: As digitally signed

To,
i. All the Directors/Commissioners of the States/UTs (Dealing with Craftsmen Training Scheme)
ii. All the Regional Directors, RDSDE & Principals, NSTIs

Subject: Revised (2.0) Tentative Schedule of CTS Mains Examination for Sessions 2024-26 (2nd
Year of two-year course), 2025- 27 (1st Year of two-year course) and 2025-26 (one-year course and
six months course (batch II)) for Regular and Private Trainees -reg.

Sir/Madam,
The revised tentative schedule for Craftsmen Training Scheme (CTS) All India Trade Test- 2026
(Mains Examinations) for the sessions 2024-26(2nd Year of two-year course), 2025-27(1st Year of twoyear course) and 2025-26 (one-year course and six months courses (batch II)) for regular and private
trainees is as follows:

S No Activity

Start Date

End Date

Action by

Trainee Eligibility and Exam Fees Activity Schedule
1

Formative Assessment Marks Upload

20-May-2026 18-Jun-2026

ITI

2

Attendance Upload

3

Practical Exam Fee Status Update

20-May-2026 20-Jun-2026

ITI

4

CBT Exam Fee Submission

20-May-2026 18-Jun-2026

ITI/Trainee

Practical Examination and OJT/Project Activity Schedule
5

Practical Exam Center Mapping

20-May-2026 22-Jun-2026

State

6

Practical Examiner Mapping and Approval

20-May-2026 02-Aug-2026

Nodal ITI

7

Practical Hall Ticket Download

23-Jun-2026

10-Jul-2026

Trainee/ITI

8

Practical Examinations

06-Jul-2026

10-Jul-2026

State

9

Practical Exam Mark Entry by Examiners

06-Jul -2026

14-Jul-2026

Examiner

10

06-Jul -2026

02-Aug-2026

Nodal ITI

11

Entered Practical Exam Mark Approval by
Nodal ITI
Entered Practical Exam Mark Approval by State

06-Jul -2026

03-Aug-2026

State

12

OJT*/Project Marks Entry

06-Jul-2026

03-Aug-2026

ITI
Page 1 of 3

<!-- page 2 -->

No.MSDE-18011/08/CTS/CTS/Dec-21/2021-TTC

I/26164/2026

S No Activity

Start Date

End Date

Action by
State &
Exam
Agency
Trainee/ITI

CBT Examination Activity Schedule
13

CBT Exam Center Mapping

19-Jun-2026

01-Jul-2026

14

CBT Hall ticket Download

03-Jul-2026

03-Aug-2026

15

CBT Exams

09-Jul-2026

03-Aug-2026 DGT

15

Result publication

16

Examination Grievance Registration

10-Aug-2026
17-Aug-2026

31-Aug-2026

DGT
Trainees

* Timeline for industry registration and mapping of candidate to industry on SIDH portal for On the Job
Training (OJT) by the ITIs will be communicated in due course of time.
2. For trainees, whose mandatory learning hours of 1200 hours +150 hours (OJT/Project work) is completed
before the last date of training session (i.e. 16 June 2026), eligibility creation and fee payment can be made
even prior to the last date of the training session.
3. Day wise schedule of practical examination is attached at Annexure A.

(स्वादत सेठी) / (Swati Sethi)
परीक्षा दनयांत्रक / दनिेशक, डीजीटी /Controller of Examination / Director, DGT

Copy to:
1. Sr.PPS to the Secretary, MSDE
2. PSO to DG/SS, DGT
3. DDG (HQ), DDG(East), DDG(South), DGT
4. Director, CD Section
5. Executive Director, NIMI
6. SIDH Team, NSDC
7. M/s DEXIT Global Limited

(दवदित दसांह) / (Vidit Singh)
उप दनिेशक/Dy. Director
व्यवसाय परीक्षण दवभाग, डीजीटी, कौशल भवन / TT Cell, DGT, Kaushal Bhawan
Page 2 of 3

<!-- page 3 -->

No.MSDE-18011/08/CTS/CTS/Dec-21/2021-TTC

I/26164/2026

Annexure-A
All INDIA TRAE TEST UNDER CRAFTSMEN TRAINING SCHEME (CTS) FOR ENGINEERING
& NON- ENGINEERING TRADES

Schedule of Practical Examination to Be Held in the Month July 2026

Date

Day

ANNUAL EXAMINATION
CTS/DST EXAMINATION

Time
Year

06.07.2026 Monday
I
Tuesday
07.07.2026
Wednesday 9:30
08.07.2026
AM
To II
09.07.2026 Thursday 6:00
PM
10.07.2026 Friday

Trade Duration
TRADE PRACTICAL: - for trainees of 1st year of two-year trades,
06 months (batch II) and 01-year trades admitted in 2025 session

TRADE PRACTICAL: - for trainees of 2 nd year of two-year trades
admitted in 2024.

(Lunch Break from 01.00 PM TO 01.30 PM)

Page 3 of 3
