---
doc_id: "be0b2791dedc9ff4"
source_url: "https://finance.delhi.gov.in/sites/default/files/Finance/circulars-orders/127_28102024_968_1.pdf"
ministry: "Finance Department, Delhi"
title: "Download"
date: ""
pages: 3
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "1299aa873b54effc"
---

<!-- page 1 -->

=
|
| हु MOST IMMEDIATE
No.F/6/5/2024/HRD/CCU/oAr/T¢F-IbP
GOVERNMENT OF NATIONAL CAPITAL TERRITORY OF DELHI
FINANCE DEPARTMENT
| HUMAN RESOURCE DIVISION: CADRE CONTROL UNIT |
| ‘A’ Wing, 4" Level, Delhi Secretariat
| IP. Estate, New Delhi-0002
2 |
! : Dated: 23-/o—2ohy |
To
| The Head of Department concerned,
Government of NCT of Delhi,
Delhi/ New Delhi.
Sub: Providing of Integrity Certificate/Vigilance Certificate and Work & Conduct
Report of the officials who have cleared Common AAO Examination, for |
! Promotion as Assistant Accounts Officer on regular basis - reg. |
|
| Sir / Madam,
The following officials, who have cleared Common Assistant Accounts |
Officers Examination (Part - I and Part - II) and working in your Department (as !।
per the record of this department), are under consideration for promotion as ।
Assistant Accounts Officer on regular basis:-
Sl. Name of the | Designation Date of | Department (as per
No. | official (as per record of | Birth record of this
S/Sh./Ms. this department department
AAO (Adhoc 09.0.97[ 70 | |;
09.0.97 [| |
3. Jitender Kumar | Jr. Assistant 4.08.977 | LNH
Pandiya _|
Mohan Chander 4.08.976 | GIPMER
Joshi
5. Abhijeet Kumar Sr. Assistant 02.0.i980 | DTTE
Ranjan
32.0.i988 [FaS /|/० ० ऑआ | .
| [8. | Arjun Singh 6..986 | DC(NE) |
Arun Kumar Sr. Assistant 02.02.983 | Industries
Yadav |
Asha Rani Arora _| Sr. Assistant 05.05980 [छाहू.... | |
Chanchal Kumar _| Sr. Assistant 04.02.979
2. | Chandra Kant 08.i.4986 [PAO __|
| Sr. Assistant | 42.0.I986 [FSLSCSC=*d
|Education |
[PrAQ |
Gulshan Bharti Sr. Assistant 26.08.984 | DSSSB
D.E.O. Grade-B 25.09.980 |DTTE _
|
“ |
|

<!-- page 2 -->

| ह —
Jay Shankar Sr. Assistant Delhi Prisons
|
[ceEO /
|
॥ Gandharva
[पट | |
|
| Education |
Mann
! [MAMC | ।
| Education | | ।
| Education || | ।
Assistant
Industries
[Planning |
| Education | |
|Sr Assistant [22.0.i986 |T@FC |
|
[NHMC
[SGMH  /।
/BIRMH अइअओ |
2 It is, therefore, requested to kindly arrange to furnish the Integrity
Certificate, Departmental Vigilance, Work & Conduct Certificate and duly filled
Bio-data in the enclosed performa, in respect of these officers, to this office |
immediately, for taking further necessary action.
You) ty faithfully, |
! Encl: As above an a |
~<A
any ।
~(L.D. JOSHI) |
CONTROLLER OF ACCOUNTS (FD)
kn y to:
कि of Finance Department.
|
|
|
|

<!-- page 3 -->

}
eS BIO DATA
i | Name of the Official
(in Capital Letters) |
Present Designation
Date of Birth |
| 4 | Seniority Number
|
| | Martial Status
7 | a) Present Residential Address हे | |
| |
b) Permanent Address
| 8] Mobile Number of official
Qualification Educational: |
Professional: |
(2 | Category (SC/ST/General)
Whether PwBD
Date of Joining of Govt Service |
Details of previous postings from the date of initial appointment in GNCTD
|__[Department Designation [| From |]
BP &£/./ | कफ क |
|
pf
|
pO
Vv
pT |
pT
Stamp & Signature of Head of Office/Authorized Officer
|
|
- ।
