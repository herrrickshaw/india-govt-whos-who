---
doc_id: "fda66baf5752cd3a"
source_url: "https://dgehs.delhi.gov.in/sites/default/files/DGHS/tender/h1n1misc1527.pdf"
ministry: "Directorate General of Health Services, Delhi"
title: "Tender Document"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a2d511915bc27d51"
---

<!-- page 1 -->

CENTRAL PROCUREMENT AGENCY
TENDER ENQUIRY DOCUMENT

FOR PROCUREMENT OF MISC ITEMS FOR
H1N1 MANAGEMENT
BY

CENTRAL PROCUREMENT AGENCY
UNDER

DIRECTORATE OF HEALTH SERVICES
GOVT OF NCT OF DELHI

TENDER NO. 1527

Central Procurement Agency:
F-17, SWASTHYA SEWA NIDESHALAYA BHAWAN
KARKARDOOMA, DELHI-110032
TEL No 22307706, 22307738;
Fax: 91-11-22305863, Email: cpa.dhs@gmail.com

<!-- page 2 -->

CENTRAL PROCUREMENT AGENCY
Directorate of Health Services, GNCTD

F-17, KARKARDOOMA, DELHI-110032, GNCTD
Central Procurement Agency is the nodal agency for procurement of all items
required by health facilities under GNCTD.
CPA invites bids from interested bidders at e-procurement site of Govt. of NCT of
Delhi (https://govtprocurement.delhi.gov.in) for procurement of items given in
annexure-L.
The details of terms and condition of this bid invitation are as under:
This is a limited tender enquiry.
Bidder’s eligibility:
Firms intending to participate in the tender (hereafter called bidders) should first ensure that
they fulfil all the eligibility criteria given as under:
2.1 Should be a licensed Indian manufacturer / importer or their authorized distributor, ready to
supply the tendered quantity, if awarded.
a. For Drug items – should have license from respective Drug authority..
b. For Non Drug items : (i) Indian manufacturers should have license from Director of
Industries, Min of commerce or NSIC. Such bidders should be registered with central
excise department which shall be applicable to all manufacturers except those having
their manufacturing plant in notified SEZ. (ii) Import License
A manufacturer/importer can authorize only one distributor for a particular item. However
a distributor can have authorization from multiple manufacturers.
To be an authorised distributor of a manufacturer, it should have an authorisation letter
from the manufacturer and a Memorandum of Understanding(MOU) to deal in its
products.
A manufacturer can submit his bid directly and supply through a local distributor
(registered with DVAT) also.
2.2 Should have manufacturing & marketing experience (marketing experience, if an importer)
of last two years for the product quoted.
2.3 Should not be under conviction for manufacturing/supplying sub-standard drugs/items or on
any other grounds under Drugs & Cosmetics Act or rules framed there under. The firm /
company / corporation and any of its Directors/ Proprietor/ Partner/ authorized signatories
should not be convicted / or a criminal case filed against or pending in any court of India by
any department of the government under Prevention of Corruption Act or for cheating /
defrauding government / embezzlement of government fund or for any criminal conspiracy
in the said matter. This shall be applicable to manufacturer/importer and distributor together
irrespective of bidder status.
2.4 Should not be currently blacklisted, debarred or deregistered for forgery, misrepresentation
or supplying “Not of Standard Quality” product(s) for which the bid is being submitted, by
any govt. /autonomous body/ institution, hospital in India. This shall be applicable to
manufacturer/importer and distributor together irrespective of bidder status.
2.5 Be ready to supply item(s) as per the specification given in the tender document, and not

<!-- page 3 -->

their substitute.
2.6 Should submit required EMD in prescribed form unless exempted by any Govt. order.
2.7 Should be willing to supply goods with sale invoice issued in Delhi. The bidder or its local
supplier shall need to be registered subsequent to signing of agreement, with the Delhi VAT
Department, if not yet registered, and submit a valid TAX Identification Number issued by
Delhi VAT with the invoices at the time of supply. Payment for the goods supplied
shall be made to the bidder or its authorised distributor supplying the goods.
3.
Documents
Comprising 3.1. EMD of Rs.100000/- in form of FDR or Bank Guarantee favouring Director Health Services,
GNCTD, from any Indian Commercial bank and valid for 6 months from tender publication date,
the Bid
shall be sent to the address of Tender Inviting Authority by speedpost, before the due date and
time mentioned above. Tender Inviting Authority (TIA) will not be responsible in any way for postal
delay. A bidder may choose to submit this physically in an envelope containing the EMD duly
superscripted with the tender no., bidder details, in the tender box specially kept for this purpose in
th
the office of TIA at 5 Floor, CPA, DHS, F-17, Karkardooma, Delhi-110032, GNCTD on the day of
the opening of the tender, before the date and time of opening of bids.

3.2 The Bidder should submit (upload) the following documents via e-tender as part of technical
bid. (All the documents submitted should be self attested and stamped by the Bidder before
scanning and named before uploading at the e-procurement site. Original documents may
be required to be produced when demanded).
3.2.1 Earnest Money Deposit, from manufacturer/importer/authorised distributor. Scanned
copy shall be uploaded, original to be deposited, as detailed above. (to be named
EMD)
3.2.2 Registration certificate: with Registrar of Company under Company Act / proprietorship
certificate / partnership deed along with details as Annexure M, in r/o manufacturer/importer (to
be named REG)
3.2.3

A valid Drug License (wherever applicable) issued by the Licensing authority
concerned, for the tendered item conforming to the relevant Pharmacopeia/
specification for the item, valid on the date of tender opening. For drug items, this shall
be of both manufacturer/importer as well as distributor.
For non drug items, license of the manufacturer from Director of Industries/ Min of
commerce or NSIC should be enclosed. For imported items IEC (Import Export Code)
and bill of entry for the quoted products needs to be submitted. (To be named LIC)

3.3.4 The instruments such as power of attorney, resolution of board etc., authorizing an officer
of the Bidder and verifying his signature, duly signed by the Authorized signatory of
the Company/Firm along with any govt issued photo-identity document of the authorised
signatory like, passport, driving license, Aadhar card etc. Only such authorized officer of
the Bidder should sign the tender documents and digitally sign the tender document at
the time of uploading. If others digital signature has been used it should be duly
authorised. Any bid uploaded by an unauthorised digital signature is liable to be
rejected. (to be named AUT)
3.3.5

Manufacturing & Marketing experience of manufacturer and marketing experience of
importer for last two years, issued by its statutory auditor(chartered accountant), for the

<!-- page 4 -->

product(s) quoted.(to be named MKT)
3.3.6

For items covered under Drug & Cosmetic Act, a Non-conviction Certificate issued to
both manufacturer/importer and distributor, by the Licensing Authority within 12 months
prior to the date of publishing of tender document or after the publishing, certifying that the
firm/company is not currently convicted.(to be named NCC)

3.3.7

Existing VAT/ Sales tax registration certificate of manufacturer/importer/authorised
distributor (to be named VAT)

3.3.8

Undertaking (as in the proforma given in Annexure-U), to be submitted both by
manufacturer/importer and its distributor. (to be named UND)

3.3.9

deleted

3.3.10

Central Excise Registration certificate of Indian Manufacturer, or exemption certificate
from Central Excise Department, as required in para 2.1 above. (to be named EXC)

3.3.11 BIS, FDA, CE certificates etc where ever applicable.(to be named CER)
3.3.12 Distributor Authorisation Certificate and MOU between manufacturer /importer and
distributor(DIS)
3.3.13 Bidders should submit samples of the item quoted for technical evaluation to CPA,
Directorate of Health Services, F-17, Karkardooma, New Delhi-32 on or before the last
date and time of submission of the bid.
Two samples for each item along with product catalogue should be packed and
sealed separately with a tag containing name of the bidder, tender enquiry no., item
code no. and submitted to CPA. The details may be written on the item packing with
indelible ink. If there are different sizes of an item as different codes, sample may be
submitted for any one size (code). For items costing more than Rs.5000/- per unit, only
one unit or brochure needs to be submitted. Costly items shall be returned to the bidder
or adjusted with the supply after finalization of the tender. Wherever required, brochure
should accompany the samples. CPA shall issue a receipt of the submission of the
samples
If a bidder does not find a slot for uploading a document at e-procurement site, it can submit
it in any other slot along with other documents.
It is the duty of distributor, if the bid is submitted by an authorised distributor, to
verify that the manufacturer he represents qualifies the bidders eligibility criteria in
respect of non conviction, blacklisting and criminal liability criteria. If at any time
during evaluation or running of contract, it is detected that the manufacturer itself
does not qualify or did not qualify at the time of bidding, the bid shall not be
considered or if had been considered, then the contract of that item(s) terminated
immediately and it shall be considered a concealment of fact on the part of the bidder
with penalty of forfeiture of EMD or performance security of that item(s).
3.7.

PRICE BID

3.7.1. The Bidder shall fill in the BOQ given at the eprocurement site as per the
Annexure-R for the items quoted.
3.7.2

The rate quoted in BOQ (Annexure-R) should be for a unit and for the given

<!-- page 5 -->

specification. The Bidder is not permitted to change/alter specification or unit size in the
BOQ.

Tender submission:
Bids have to be submitted at the e-procurement site given above and no document is
required to be submitted in physical form except EMD which shall have to be
submitted on or before the date and time of submission of the bid.
Bid Evaluation:This is a short enquiry/ limited tender. The price bids of all the bidders who have
submitted valid EMD shall be opened. The documents required for compliance of the
bidder’s eligibility then shall be checked. The lowest priced bid which complies with a
required bidder’s eligibility shall be considered L1 and qualified. Its rate shall be
presented before Special Purchase Committee (SPC) for evaluation. For this the
documents uploaded only at the e-procurement site shall be considered and no other
documents shall be admissible later on. However clarification regarding any of the
uploaded documents may be sought from the bidder if required. All bidders are
requested to upload documents complete with enclosure/attachement/annexure.
Terms of Supply & Payments:
Items may have to be supplied to DHS central store, F17, Karkardooma, Delhi and
as per the specification given in this bid document. The quantity asked in the tender
document may increase as per actual consumption.
Each batch of supply may be got tested by CPA in any of the empanel lab for quality
analysis, the payment of which shall be borne by supplier. The rate of testing a
sample can be ascertained from CPA. Vaccines are not tested, if there is a report
from Govt Lab, Kasauli. Supplier has to submit an in-house test report with the
consignment for the supplied item.
It shall be stamped “DELHI GOVT SUPPLY, NOT FOR SALE” with indelible ink on
each unit wherever practically possible.
25% of the order is to be supplied within 7 days of issue of supply order, rest within
20 days of the issue of supply order, otherwise a penalty of 0.5 % per day subject to
maximum of 15%. The payment shall be made within 45 days, preferably 30 days, of
the receipt of goods as per terms and condition of the bid. Bills in triplicate shall be
made in favour of CPA-DHS, Delhi.
Penalty
EMD shall be forfeited if a bidder withdraws from the bid or fails to supply the
ordered item within the delivery period.
Price Bid:

<!-- page 6 -->

It shall be submitted on line, in the BOQ provided at e-procurement site.
Rate quoted shall be inclusive of vat, octroi, packing, cartage, delivery etc.
CPA shall not pay any amount over and above the quoted rate, the quoted price
which shall not be more than MRP of that item.

Format of BG for EMD:
BANK GUARANTEE FORMAT FOR FURNISHING EMD
Whereas …………………………………………………………………………………
(hereinafter called the “tenderer”) has submitted their offer
dated………………………………….……………………… for the supply of
………………………………………………………………………………..
(hereinafter called the “tender”) against the purchaser’s tender
enquiry No. …………………………………………….. KNOW ALL MEN by these presents that WE
……………………………………………. of …………………………………………….. having our
registered office at ……………………………………………………………. are bound unto
…………………. (hereinafter called the “Purchaser) in the sum of
…………………………………………………………………………………… for which payment will and
truly to be made to the said Purchaser, the Bank binds itself, its successors and assigns by these
presents. Sealed with the Common Seal of the said Bank this…………… day of …………….20……
THE CONDITIONS OF THIS OBLIGATION ARE:
(1)
If the tenderer withdraws or amends, impairs or derogates from the tender in any respect
within the period of validity of this tender.
(2)
If the tenderer having been notified of the acceptance of his tender by the Purchaser during
the period of its validity:a) If the tenderer fails to furnish the Performance Security for the due performance of the
contract.
b) Fails or refuses to accept/execute the contract.
WE undertake to pay the Purchaser up to the above amount upon receipt of its first written demand,
without the Purchaser having to substantiate its demand, provided that in its demand the Purchaser
will note that the amount claimed by it is due to it owing to the occurrence of one or both the two
conditions, specifying the occurred condition or conditions.
This guarantee will remain in force upto and including 45 days after the period of tender validity and
any demand in respect thereof should reach the Bank not later than the above date.
…………………………….
(Signature of the authorized officer of the Bank)
………………………………………………………….
………………………………………………………….
Name and designation of the officer
………………………………………………………….
Seal, name & address of the Bank and address of the Branch

<!-- page 7 -->

Annexure U

On Rs100 Stamp Paper
UNDERTAKING

I ……………………………… S/o ………………………………………………. resident of
……………………………… …………………..........................................do solemnly affirm:-

That I am the Director/proprietor / partner/authorized signatory (tick the appropriate one) of
M/s. ………………………………………………situated at ……………………….

That my/our firm/company/corporation has participated in tender no. ________________of
CPA, Directorate of Health Services, NCT of Delhi, Karkardooma, Delhi -110032 and I am
executing this Undertaking for myself and on behalf of my/our firm/company/corporation.

That our firm / company / corporation or its Directors / Proprietor / Partner / authorized
signatories including the authorised distributor through which supply shall be made to CPA,
has not been convicted / or a criminal case filed against us or pending in any court of India
by any department of the government under Prevention of Corruption Act or for cheating /
defrauding government / embezzlement of government fund or for any criminal conspiracy in
the said matters.

That our firm/company/corporation/authorised distributor through which supply shall be
made to CPA is not be currently under conviction for manufacturing/supplying sub-standard
drugs or on any other grounds under Drugs & Cosmetics Act or rules framed there under

That I have read the terms and conditions of the tender and I agree to abide by these terms
and conditions and other guidelines issued in this regard. I fulfil the prescribed bidder
eligibility criteria and have submitted bid for item(s) as specified in the tender document and
have not quoted for a substitute item.

That the information given by me in this tender form is true and correct to the best of my
knowledge and belief and the rates quoted are not higher than the rates quoted to other
Govt. / Semi Govt. / Autonomous / Public Sector Hospitals / Institutions / Organisations
situated in Delhi in the same financial year.

<!-- page 8 -->

That I have already submitted the bid online through e-procurement platform and the price
quoted by me is not more than that notified by any govt notification for that particular item(s).

That my authorized distributor supplying to CPA or I have not been deregistered or black
listed by any govt. /autonomous institution, hospital or body in India for an item which is
being quoted here by me in this tender or for participating in bid altogether.

Our firm / company / corporation details are:
a) Nature of firm (Public Ltd, Pvt Ltd, Proprietary, Partnership etc):
b) Authority with which it is registered :
c) Registered Address:
d) Address of correspondence:

e) Phone: Landline:
f) Fax:
g) email *:

Mobile

Date:

Office seal

Signature

Name
Designation

Signature
Name of Proprietor / Partner/Authorized Signatory of bidder
With firm’s rubber stamp
Verification
I pledge and solemnly affirm that the information submitted above is true to the best of my
knowledge and belief.
Place ……………………..
Date

<!-- page 9 -->

Annexure L

List of items with specification:

S.
No.

Name Item

1.

PPE Kit (For Men & Women
staff, 50% quantity each)

Specifications





Each PPE Kit Contain




2.

Gown with Zipper
Hood
Shoe cower
Face Mask
Protective Glass

Hand Sanitizer
(Hygienic and Surgical
Hand disinfectant) 50%
items should be with a wall
hanging unit for ease of
use.

Item Code

N1H1
Misc01

Complete cover
protection
Non-toxic
Environmental
friendly

Units required



5000 kits

Protection cover for workers
in Influenza outbreak.
Comfortable

to

wear

and

protection.
Non- toxic.
Environment Friendly
500ml bottle with
pump dispenser
Each 100gms should contain:


o
o
o

N1H1
Misc02

50000
bottles

2 proponal IP
:45gms
1 propanol IP
:30gms
Ethyl–Hexadecyldimethyl
ammoniumethylsulfat
e
:0.2gms

Broad Spectrum antimicrobial
hand

disinfectant

effective

against Bacteria, HBV, HIV,
H1N1,

H5N1

and

SARS

viruses.
3.

N-95 Mask
(N-95 Respirators)

NIOSH,USA 42CFR84

N1H1

20000

Approved

Misc03

pieces

Filtering mask of class N-95
intended to protect from the
risks from inhalation from
transmissible infectious
agents by air (SARS, H1N1,

<!-- page 10 -->

avian flu).
Low Breathing Resistance.
Easy to use.
Comfortable and durable
design.
Superior level of filtration.
Meets WHO guideline for
protection against infectious
4

Surgical Mask

diseases
Unit size: packet of 10 masks

N1H1
Misc04

Should be ISI marked or CE
certified or FDA approved
Mask should be manufactured
from non woven poly prop
fabric.
It should be of 3 ply
construction.
The mask should have 99%
Bacteria filteration efficiency
(BFE).
The mask should be heat
sealed and no stitching to keep
three layers together.
It should be provided with an
adjustable nose clip.
There should be a string each
at all the four corners of the
mask, the length of string
should be 40 cm.

25 lac units
