---
doc_id: "bda3a74c7f97b8de"
source_url: "https://health.delhi.gov.in/sites/default/files/Health/tender/ni2_189.pdf"
ministry: "Health and Family Welfare, Delhi"
title: "Tender Document"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a82117b81e3e3b2c"
---

<!-- page 1 -->

il
\

j

--~-i
!

'

l

J

:
OFFICE OF THE MEDICAL DIRECTOR
DEEN DAYAL UPADHYAY HOSPITAL GOVT. OF NCT OF D~LHI
:•
HARi NAGAR, NEW DELHI - 110064

LI
F-12/6-C/4137/BLO
00 BANK/PUR/DDUH/2023-24,~/) 'J)
:
•

I

Dated:

.!

i
/tJ -2,5,,JA}
/Ci 1
• _,... t.

I

NOTICE REGARDING PROCUREMENT OF ITEMS ON PAC-166 BY 'DDU HO~PITAL
i

~ •items are as
• um.ue
The DDU Hospi·taI •intents to procure the under mentioned consumables items. The rdetails
•
.
follows:!
Sr.
No

Description

Demand By

•

•

Ji

Quantity re~ulred

;,.

1

..\.,

30l20 tips 9r 32 Box
•l
•
•
of Sx192 tip~
5 X 192 tips
Tips ~i-2 bpx of
2
Conductive disposable tips: 1100 ul box of HOD Blood Bank 1920
tips '
Sx192
5 X 192 tips
any interest
The notice being uploaded on website of H & FW department GNCT(? for inyiting
y basis as
/objections/information/representation/quotation regarding the proposed procurement on; proprietar
)
mentioned above on following terms and conditions.

Conductive disposable tips: 300 ul box of HOD Blood Bank

1

1.
2.
3.

'
Each packet of item should be marked as "DOU HOSPITAL SUPPLY, and "NOT FOR SALE."
_;
n/sam~le.
specificatio
approved
the
with
accordance
in
strictly
Supply should be made
3PM on
Full delivery should be made to the concerned store of this Hospital during working days b/wJJ AM,to

'

j
F.O.R. destination basis within.
items.
-35 d~ys from the date of the issue of the supply order in the case of Indian
-90 days from the date of the issue of the supply order in the case of imported items.
subject to
I.
FOR DELAYED SUPPLY-A penalty of 0.5% of the value of delayed supply per working days will be imposed
supply.
delayed
the
of
maximum of 10% of the total value

7

the~r cor:nmunication to
within lO days of uploading
Medical Director, DDU Hospital, Hari Nagar New Delhi-110064 through central dairy
st
of mcbnth then interested
day
1
on
website
HFW
on
uploaded
of this notice on website.(For example if Notice
th
DDUffl by ·10 day of the
of
Dia~
Central
firms can submit their communication to Medical Director through
•
month).

A~y ·individual /firm who wish to represent against above proposal procurement may su_bmit

procurem ent
In case no representation are received within 10 days of uploading of this notic~. The prQpos~d
:
shall be processed as per applicable rules.
This is issued with prior approval of Medical Director, DDU Hospital.

KUMAR
lDR.A
(""RCHASE OFFICER-I)
1 -

'I

I

...!

t'

.
I

'
