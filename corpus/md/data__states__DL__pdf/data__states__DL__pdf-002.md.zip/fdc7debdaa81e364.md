---
doc_id: "fdc7debdaa81e364"
source_url: "https://drkp.delhi.gov.in/sites/default/files/drkp/circulars-orders/circular_scert_training_tgt_computer_science_2024_diet_rkp.pdf"
ministry: "DIET, R K Puram, New Delhi"
title: "Download"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "27fdef29200e0a74"
---

<!-- page 1 -->

State Council of Educational Research and Training
(An autonomous body under Department of Education, Govt. of NCT f Delhi)

Varun Marg, Defence Colony, New Delhi 110024
https://scert.delhi.gov.in, Email- insetcellscert@gmail.com

F 3(2)/ /ET/ICT in Education/SCERT/2024-25/ 3826-34

Date:05.08.2024

Circular
Subject: Two-days Capacity Building Programme for TGT Computer Science of the
Directorate of Education.

SCERT Delhi is committed to equipping TGT Computer Science teachers with the necessary
skills and knowledge to effectively incorporate ICT in education. In today's rapidly evolving
educational landscape, integrating Information and Communication Technology (ICT) into
teaching practices is crucial for fostering a dynamic and engaging learning environment. This
training program is a significant step towards enhancing the skills and competencies of TGT
Computer Science teachers in Delhi. By equipping them with the knowledge and tools to
effectively integrate ICT in education, SCERT Delhi is ensuring that teachers are well-prepared
to meet the demands of modern education and create a more engaging and effective learning
environment for their students.
In this regard, to equip the teachers with the necessary skills and practical knowledge to effectively
implement the new skills and competencies in their classrooms, two days capacity building
programme on addressing technological reconditions of NEP 2020, world of AI, Information
Literacy and the right of users in digital world has been schedule for Computer Science TGTs of
Directorate of Education Delhi.

The program details are as under:
The training is to be organized in three cycles as mentioned below:
Cycle1:
Date: 8th -9th August, 2024

Cycle 2:
Date: 12th -13th August, 2024

Cycle 3:
Date: 21st -22nd August, 2024

Venue: 6 Different Venues (List Venue: 6 Different Venues
(List Attached)
Attached)

Venue: 6 Different Venues
(List Attached)

Time: 8:30 am to 3:30 pm

Time: 8:30 am to 3:30 pm

Time: 8:30am to 3:30 pm

<!-- page 2 -->

All venues in-charges are hereby requested to ensure the availability of projector or Kyan and
speakers in the room required according to number of participants in your venue. If things required
are not available, you are requested to arrange from neighbour schools.
All Computer Science TGTs are hereby informed to attend the training positively and also it is
mandatory to bring their Tab/Laptop.
List of all the participants (Cycle and Venue wise) is attached as Annexure- II and the list of resource
persons as Annexure -I with this circular.
Both the Annexures are available on the following link:
Annexure-I:
https://drive.google.com/file/d/1OS3CQJ6dpDMS3CiU_Vm1EAgLRFEGh-w8/view?usp=sharing
Annexure- II: https://drive.google.com/file/d/1NWeKi8hwCHLSXz2STcpWSbxDVcnXHwT/view?usp=sharing

This issue with the prior approval of the competent authority.

(Dr. Nahar Singh)
Joint Director, SCERT

F 3(2)/ET/ICT in Education/SCERT/2024-25/3826-34

Date: 05.08.2024

Copy to:
1. PS to Secretary Education, GNCTD 2.
PS to Director Education, GNCTD
3.
PS to Director, SCERT Delhi.
4.
Additional DE (Schools), DoE
5.
All RDE's/ DDE's (Districts and Zones), DoE
6.
Dr. Sapna Yadav, Nodal Officer, ICT in Education, SCERT Delhi
7.
Nodal officer, INSET Cell, SCERT
8.
OS (IT to upload on MIS)
9.
WIM, SCERT
10. Guard file

(Dr. Nahar Singh)
Joint Director, SCERT

<!-- page 3 -->

ANNEXURE -I
Following Resource Persons are deputed to this training
S.No.

Name

Designation

Employee Id School/ Institution/
Organisation

Cycle 3: 21st – 22nd August, 2024
1

Preeti Dalal

Lecturer Computer Science 20192944

2

Vinay Gahlot

Lecturer Computer Science 20210016

3

Rohit Ahlawat

Lecturer Computer Science 20192841

4

Ruby Rana

Lecturer computer science

5

Ankita Mogha

Lecturer Computer Science 20220784

6

Deepanshu

Lecturer Computer Science 20192765

Govt co ed at sec school sec 2
Dwarka 1821029
Rajkiya Pratibha Vikas Vidyalaya,
Dwarka Sector-19
GBSSS-Hastsal, District-West
B,New Delhi-110059
Sarvodaya Bal Vidyalaya, Ashok
Nagar
Delhi Model Virtual School, Lajpat
Nagar, New Delhi
SOE, SEC 23 Rohini

7

Sachin Kumar

Lecturer Computer Science 20192824

SBV - Burari

8

Dr. Naveen Gupta

Head, ICT Department

9

Vandana Gupta

PGT Computer Science

St. Mark's Sr. Sec. Public School,
Meera Bagh
Sanatan Dharam Public School

10

Sony Prakash

PGT Computer Science

20197074

SKV Bulbuli Khana Asaf Ali Road

11

Anuj Kumar Dagar

PGT Computer Science

20192849

GSV, Jaffarpur Kalan

12

Ritu Dawar

PGT Computer Science

1863830

13

Sunny Dagar

PGT Computer Science

20192839

14

Vijay Kumar Prajapati

TGT Computer Science

20180669

15

Rahul Bhatia

TGT Computer Science

20180417

Ryan International School Sector25
Rohini
GBSSS No. 3 Najafgarh New Delhi
110043
GBSSS Hastsal, Hastsal Uttam
Nagar Delhi 110059
SOE Sec-23 Rohini Delhi

16

Parveen Kumar

TGT Computer Science

20180587

17

Tarun

TGT Computer Science

20221173

18

Anil Mor

TGT Computer Science

20180044

19

Sapna Chaudhary

TGT Computer Science

20180046

Govt Co-Ed Sen Sec School, Kewal
Park, Azadpur, Delhi
Govt Co-Ed Secondary School,
Saraswati Garden, 1B Block,
Ramesh Nagar, New Delhi - 110015
Delhi Model Virtual School, Lajpat
Nagar
RSKV, Surajmal Vihar, Delhi

20

Dr. Murari Jha

TGT Social Ccience

20102554

SV-3, sector-7, R.K Puram, 1719022

20197636

<!-- page 4 -->

ANNEXURE - II
Participants List : TGT Computer Science Teachers for 2 Day Training on ICT in Education
Coordinating DIET

R K Puram

Date

21st-22nd August, 2024

Cycle/Phase

3

Batch

1

Venue

Govt. Sarvodaya Co-Ed SSS, Sector - 6, R.K. Puram, Delhi

Coordinator

Ms. Tanu Sharma - 7060905100

S.No.

Districtnam
e

1

South West
A

19

20180472 VIRENDRA

M

2

South West
A

19

20221147

SAMEER SUBBA

M

3

South West
A

19

20180642

VARUN KUMAR

M

4

South West
A

19

OM PRAKSH
20221104
MEENA

5

South West
A

19

20221151 SANGEETA

F

6

South West
A

19

20180195

RENU

F

7

South West
A

19

20224457

SAPNA
GAHLOT

F

8

South West
A

20180621

TAPAN
KUMAR
RATHI

9

South West
A

19

20180797

GOVIND SAINI

M

10

South West
A

19

20180167

SHWETA GUPTA

F

11

South West
A

19

20183085

12

South West
A

19

13

South West
A

14

South West
A

19

20181178

VIVEK
KUMAR
VINAY
KUMAR
KHARE

15

South West
A

19

20180339

PAWAN TOKAS

16

South West
A

19

20180539 ANJALI RAI

Zone

19

19

Empid

Empname

KARTIKEYA
GUPTA
HIMANSHU
SINGH
20180057
SENGAR

20180682

Gender Designation

M

M

M

M

M

M

M

F

TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE

Schoolid Schoolname

1719001

1719001

R.K. Puram,
Sector 12-SV
(Jose Marti)
R.K. Puram,
Sector 12-SV
(Jose Marti)
R.K. Puram, Sector 7,
No.3-SV

1719022

1719022

1719029

1719029

1719030

R.K. Puram, Sector 7,
No.
3-SV
Sarojini
Nagar, No.1SKV
Sarojini
Nagar, No.1SKV
R.K. Puram,
Sector 4GGSSS
R.K.Puram, Sector-6,
Govt. S.(Coed) SSS

1719070
R.K.Puram, Sector-6,
Govt. S.(Coed) SSS
1719070

1719073

1719101

1719104

Moti Bagh ISKV
Laxmi Bai
Nagar(Co-Ed)
-SSS
R. K. Puram, Sec5(Co-Ed)
-GSSS
Moti Bagh-II,
Nanakpura(Co-Ed)SV

1719105

1719125

1719125

1719130

Munirka,
Sarvodaya
(Co-ed) SSS
Munirka,
Sarvodaya
(Co-ed) SSS
R.K. Puram, Sector13 G
(Co-ed)SV

<!-- page 5 -->

17

South West
A

20180566

SINTOO
KUMAR

20

M

18

South West
A

20

20180316

MANOJ KUMAR

M

19

South West
A

20

MADHUKHA
20180239 R NARAYAN

20

South West
A

20

20181104

ANURAG SINGH

M

M

TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE

21

South West
A

20

20180001

22

South West
A

20

20180390

DHIRAJ
TANWAR
SUSHEEL
KUMAR
MEENA

23

South West
A

20

20181694

MANISH
KHOIWAL

M

24

South West
A

20

20222426

POOJA MEENA

F

TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE

25

South West
A

20181616

SUMIT
KUMAR

M

TGT
COMPUTER
SCIENCE

26

South West
A

27

South West
A

28

20

M

M

20181144

ANTESH
TANWAR

20

20180474

NITIN
RAWAT

M

South West
A

20

20180404

DEEPAK
KUMAR

M

29

South West
A

20

20225143

AMIT
CHOLIA

M

30

South West
A

20

20221077

KOMAL
MEENA

F

31

South West
A

20

20180165

32

South West
A

20

20181812

33

South West
A

20

20222414

DEEPAK
KUMARI
RAHUL
KUMAR
MEENA
KULDEEP
KUMAR
JAIN

34

South West
A

20

20234320

YUGSHAKTI

F

35

South West
A

20

20221185

YOGRAJ
MEENA

M

36

South West
A

20

20180898

PANKAJ
KUMAR

M

37

South West
A

20

20180863

RINKU

M

20

F

F

M

M

1720001

1720002

Delhi Cantt.SBV
Naraina SBV
Mehram
Nagar-S(Coed)V

1720003

1720005

1720008

1720010

1720014

1720014

1720015

TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE

Pusa, IARI, 2nd
ShiftGBSSS
Janak Puri,
Block D, No.
2-GBSSS1720008
Naraina GBSSS
Janak Puri,
Block D, No.
1-SKV
Janak Puri,
Block D, No.
1-SKV
Inderpuri,
Budh Nagar,
F- Block- S
(Co-ed)V

1720015

Inderpuri,
Budh Nagar,
F- Block- S
(Co-ed)V
Inderpuri,
Budh Nagar,
F- Block- S
(Co-ed)V

1720017

Pusa, IARISKV

1720017

Pusa, IARISKV

1720015

1720021

Delhi Cantt.SKV
Janak Puri,
Block D, No.
2-GGSSS

1720022

Naraina-SKV

1720022

Naraina-SKV

1720022

Naraina-SKV

1720024

Vasant
Vihar, SV

1720024

Vasant
Vihar, SV

1720027

Janak Puri,
Block D-SBV

1720018

<!-- page 6 -->

38

South West
A

20

HARVINDER
20180469
SINGH

39

South West
A

20

20180521

ROHIT
YADAV

M

40

South West
A

20

20181386

ANUPAM
MEHRANIYA

M

41

South West
A

20

20181366

INDERPAL
SINGH

M

42

South West
A

20

20182503

MAHENDRA
MEENA

M

43

South West
A

20

20180271

MOHIT
PANWAR

M

44

South West
A

20

20180300

TARUNA
KUMARI

F

45

South West
A

20

20181530

SUNITA
YADAV

F

TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE

46

South West
A

20180308

POOJA
DABAS

F

TGT
COMPUTER
SCIENCE

1720032

47

South West
A

20182490

SWEETY
YADAV

F

TGT
COMPUTER
SCIENCE

1720032

48

South West
A

20222431

RAKESH
KUMAR
MEENA

M

TGT
COMPUTER
SCIENCE

1720032

20

20

20

M

20222441

SANDEEP
KUMAR
MEENA

M

20

20181550

KANIKA
SHARMA

F

South West
A

20

20180942

52

South West
A

20

20180277

MUKESH
KUMARI
SATYVEER
SINGH
YADAV

53

South West
A

20181174

PANKAJ
LAKHANEY

54

South West
A

20226356

MANISH
KUMAR

55

South West
A

20221159

SHIVRAJ
MEENA

49

South West
A

20

50

South West
A

51

20

20

20

1720027

Janak Puri,
Block D-SBV

1720028

RajokariGBSSS

1720028

RajokariGBSSS

1720029

Mahipal
PurGBSSS

1720029

Mahipal
PurGBSSS

1720029

Mahipal
PurGBSSS

1720030

RajokariSKV

1720030

M

TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE
TGT
COMPUTER
SCIENCE

M

TGT
COMPUTER
SCIENCE

1720121

M

TGT
COMPUTER
SCIENCE

1720121

M

TGT
COMPUTER
SCIENCE

1720174

F

1720032

RajokariSKV
Mahipal PurShaheed
Major Ashok
Sehrawat
SKV
Mahipal PurShaheed
Major Ashok
Sehrawat
SKV
Mahipal PurShaheed
Major Ashok
Sehrawat
SKV

Mahipal PurShaheed
Major Ashok
Sehrawat SKV

1720033

GhitorniSKV

1720033

GhitorniSKV

1720034

GhitorniGBSSS
Inder Puri,
Shahid
Captain Amit
Verma Govt.
Sarvodaya
(Co-ed)
Vidyalaya
Inder Puri,
Shahid
Captain Amit
Verma Govt.
Sarvodaya
(Co-ed)
Vidyalaya
Vasant
Vihar, C-4,G

<!-- page 7 -->

(Coed)SS1720174

56

South West
A

20

20221161

SONALI

F

TGT
COMPUTER
SCIENCE

1720181

Vasant Kunj,
D-BlockSarvodaya
(Co-ed) Sr.
Sec. School
