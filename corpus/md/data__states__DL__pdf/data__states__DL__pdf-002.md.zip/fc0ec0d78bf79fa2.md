---
doc_id: "fc0ec0d78bf79fa2"
source_url: "https://health.delhi.gov.in/sites/default/files/Health/tender/ni1_384.pdf"
ministry: "Health and Family Welfare, Delhi"
title: "Tender Document"
date: ""
pages: 5
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "bc95de78ddac9477"
---

<!-- page 1 -->

" |
GEM GOVT. OF NCT OF DELHI
हे (५४ | A) DEPTT.OF HEALTH & FAMILY WALFARE
नै JAG PRAVESH CHANDRA HOSPITAL
"| JJ SHASTRI PARK, DELHI - 0053
९७७ ‘PH,042-2204453,042-22560006 Fax-04-2464455 2 ++_-+-+
४०.४5 (6)/_रकश्॥7ए0॥/2026-27 000 Dated: l6- / 0 28
?७७॥९३०७४८९॥९४५५॥६ 90०एशाशाए ण ९८४ ॥40॥6 ९०उपए दस्त of ecg machine consumables on
| proprietary items
Subject: - procurement of Consumables for ECG Machine consumables on Proprie\2ry of Consumables for ECG Machine consumables on proprieta
basis for casualty department.
Make: Manufactured by essential medical on proprietary basis for department of Caualty at Jag
Pravesh Chandra Hospital Shastri Park, Delhi-0053, inviting comments thereon.
This hospital is in process of eccg machine consumables model-Mquip on proprietary basis for
department of Radiology at Jag Pravesh Chandra Hospital Shastri Park, Delhi-0053 from M/s
Essential medicals through M/s Mars corp. Copy of the quotation of the reagents/ consumables
submitted by M/s Mars corp is attached for information to submit objections, comments if any, by any
manufacturer/Individual regarding proprietary nature of the items within 03 days in the office of the
Medical Superintendent Jag Pravesh Chandra Hospital Shastri Park, Delhi - 0053 through central
diary from the date of uploading of the notice, failing which it will be presumed that any other
vendor/manufacturer have no comments to offer and case will be decided on merit.
In case no representations are received within 3 days of uploading of this notice, the proposed
procurement shall be processed as per applicable rules
This is issued with the prior approval of the Medical superintendent. we
DR. MANOJ KUMAR
PURCHASE OFFICER

<!-- page 2 -->

— Peer eee ee eee errr eee eee a
\ Following di wl
foi oe “el
rw o ON
| N Ks
| ee Chandra Hospital | Vi ‘A x S
astri leu ¥ 2 A aN
Diary hea हे है
086....../..0#-.० ;
nella .
|
| | | Quotation Nox MCJPCHI6.2743.  प्प््जननऋत
| QUOTATION Dated:- 3.0.2026 |
Peers eee
To, —_ WW आम
The Medical Superintendent
| Jag Pravesh Chandra Hospital |
Shastri Park, Delhi- {0053 |
(se | Deccan Qty Unit PRICE | Total Price |
No (IN INR) | |
| |
| |
0|. | ECG Cable consisting of following item |5628.00 |5628.00
a. ECG Cables for |2 Channel: - 0! nos. |
| | b. ECG Bulb Electrodes: - 06 nos.
| c. Clamp Limb:- 04 nos. a oe
02 ECG Paper Roll 400.00 | 400.00
Terms and conditions: -
e Taxes 7 GST extra as applicable
« Delivery 7 |5-30 days from receipt of Purchase Order.
e GST : O7AAYFM909!K IZ8
¢ The rate quoted is lowest and not supplying below this price to any other hospital.
Thanking you,
Yours truly,
‘ours truly, "a छः
For MARS Corporation (६ Kok
ko. ns
i (2
श् (0४2! हा
Auth sig toy
C a पं _
Corporation — ;
ll ee MARSCo— a@sTIN : 07 i
बनता i ni-70052
oa apt Bagh, Chowiki No.02, Delhi!" coun

<!-- page 3 -->

ale
Dated:- |3.0.2026
To,
The Medical Superintendent
Jag Pravesh Chandra Hospital
Shastri Park, Delhi-| |0053
Sub:- Lowest Rate Certificate against ‘
quotati का
dts ।3.0.2026 ion no:- MC/JPCH/26-27/43
Dear Sir,
We hereby certify that the quoted prices of Consumables Item for 2 Channel ECG Machi
lowest from any other govt. Hospitals/institute in same specification. achine are
Thanks & Regards
For MARS Corporation
See Ras
oo 9 Go 2 हा
Cg
Auth 7Sigtatory
ee
208, Garg Plaza, L.S.C. Gulabi GSTIN F
HB Bagh, Chowki No.02, Delhi- : OTAAYFM909IK(28
Ph . 0-4705239, Mob.: 97457702, 850000580, E-mail a. a
हू ee orp@gmail.com /
I

<!-- page 4 -->

®
‘ (5
कै +
‘Maquip 6 ) (
70 WHOM IT MAY CONCERN /
DATE: 43.20.2026
Ref No- MANF/AUTH/04/26-2
To, हा
The Medical Superintendent
Jag Parvesh Chandra Hospital
Delhi
SUBJECT: Manufacturer’s Authorization for ECG Machine and Consumables - Model:
CARDIO-I2C, Make: MQUIP
Dear Sir/Madam,
We, Essential Medical, a reputed manufacturer of ECG Machines and their consumable items, hereby
authorize MARS CORPORATION, having its office at 208, Garg Plaza, LSC, Gulabi Bagh, Chowki
No. 2, North West Delhi, Delhi "रा 40052, to undertake the sale, supply, installation, servicing, and after-
sales support of our products, including the ECG Machine, Model: CARDIO-2C, Make: MQUIP, and
its related consumables, within the Delhi & NCR region.
We confirm that MARS CORPORATION is authorized to represent and deal in our products for the above-
mentioned territory and to provide the necessary service and support as required.
Thanking You and Assuring You Our Best Service at All Times
Yours truly
For ESSENTIAL MEDICAL
ca MO
xy NO)
| DEBE is
oO 4६
AUTH f 'DSIGNATORY
ESSENTIAL MEDICAL
Registered Address: Contacts: - GST No.07AA\
202, 2™ Floor Garg Plaza, Sales: +9-989947400. Web: का mg नमन
Sindhora Kalan Service: +9-7827274387 E-mail: sales emedi .
फ़क्काना0052 + sales.emedical@gmail.com
I

<!-- page 5 -->

Q ®)
(९२ ै।
ree ¢ +)
। “4
| PROPRIETARY ARTICLE CERTIFICATE (PAC) “min
| PRIETARY ARTICLE CERTIFICATE (PAC
To, : / 7 /
The Medical Superintendent
Jag Pravesh Chandra Hospital
Delhi
/ Subject: Proprietary Article Certificate (PAC)
Description of Goods: ECG Machine and its Consumables
Model: CARDIO-I2C
Make: MQUIP
Dear Sir,
This is to certify that all accessories, spare parts, and consumables required for our ECG Machine, Model:
CARDIO-I2C, Make: MQUIP, are proprietary in nature and are specifically designed for use with the
above-mentioned equipment.
The use of non-original or locally available parts may result in improper compatibility, inaccurate
performance, and variations in test results, and may also cause damage to the equipment. Therefore, we
strongly recommend using only genuine and original accessories, sparc parts, and consumables supplied
or approved by the manufacturer to ensure the proper functioning, accuracy, reliability, and longevity of
the equipment.
This certificate is issued for submission to Jag Pravesh Chandra Hospital, Delhi, for official purposes.
Thanking You and Assuring You Our Best Service at All Times
Yours truly
For ESSENTIAL MEDICAL
(aa wa | bey 4
ee 8
iy .
ol DERHL IS. :
a
AU’ 'D SIGNATORY
NE
ESSENTIAL MEDICAL
nee aria nay aetna - GST No.07AAGFE08I7KIZI
2 loor Garg 2 +9-989947400 Web: www.mquip.in
Sindhora Kalan Service: +9-7827274387 E-mail: sales.emedi i
mail: ॥( iL.
Dethi-t20052 sales.emedical@gmail.com
