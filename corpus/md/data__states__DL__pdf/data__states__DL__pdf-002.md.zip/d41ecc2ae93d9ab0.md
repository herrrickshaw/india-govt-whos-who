---
doc_id: "d41ecc2ae93d9ab0"
source_url: "https://shmch.delhi.gov.in/sites/default/files/shmch/circulars-orders/biomedical_waste_report_oct_2022.pdf"
ministry: "Dr. B. R. Sur Homeopathic Medical College, Hospital and Research Centre, Delhi"
title: "Download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2e47b49a0b266231"
---

<!-- page 1 -->

GOVERNMENT OF NATIONAL CAPITAL TERRITORY OF DELHI
Dr. B. R. SUR HOMOEOPATHIC MEDICAL COLEGE, HOSPITAL

&RESEARCH CENTRE

DLap Mo- Qooo

NANAK PURA, MOTI BAGH, NEW DELHI-I 10021.

Dobe16)22

Ph. No. 011-24105298, Fax no. 011-24105299,

Biomedical waste

April 2022

to June 2022
April 2022 to June 2022

Quantum of waste generated

Total
Kg

January

Februaryy

March

(In kg)

2022(in Kg)

(In kg)

Nil

Nil

Nil

Nil

Soiled waste

5.35

19.655

24.3

49.305

Expired or Discarded medicine

Nil

Nil

Nil

Nil

Discarded linen, mattresses,

Nil

Nil

Nil

Nil

Month
Incinerable (Yellow) Human
Anatomical waste

beddings contaminated with blood
or body fluid

4.325

18.1

26.87

540.655

517.46

502.41

1560.525

Total waste Yellow category

550.45

541.44

544.81

1636.70

Autoclavable/Microwavable (Red)

38.85

28.315

33.965

101.13

Sharps (White)

Nil

0.215

Puncture proof container Blue

25.77

24.13

25.95

75.85

615.07

594.10

605.255

1814.425

Microbiology, Biotechnology and

4.445

other chemical laboratory waste

Chemical Liquid waste: Floor washing,

leaning, housekeeping and disinfecting

activities

0.745

0.53

marking
Total

Nursing Officer

Nodal Officer(BMW)

Principalue
Dr. B. R. Sur

Homocop.tic edical Colieye

Hospital &R:cerch Centre
Directorate of l.8.. 2 Homoeopathy
Covi. of Delhi

Nanak Pura, Moti Ranh, Wou DIhi.11nn
