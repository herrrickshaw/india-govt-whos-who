---
doc_id: "acec1e6d35c69da2"
source_url: "https://health.delhi.gov.in/sites/default/files/Health/tender/ni4_46.pdf"
ministry: "Health and Family Welfare, Delhi"
title: "Tender Document"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "eb42b985efba59ab"
---

<!-- page 1 -->

=>
SF ¥ a Ge M oe fas dea /Bid te 68५/2026/8/8068677
६ के » cramer Azadi 7  /Dated: 23-0-2026
i रा e Marketplace Amrit Mahotsav
fas atarast / Bid Document
fas faaxot/Bid Details
बिड बंद होने की तारीख/समय /Bid End Date/Time | 07--2026 :00:00
बिड खुलने की तारीख/समय /Bid Opening 08-4-2026 :00:00
Date/Time
| | fas Garner dear (de eter Hr atta @)/Bid Offer |, 4 (Days)
Validity (From End Date)
fast a arat/Department Name Health And Family Welfare Department Delhi .
arated a arat/Office Name ; Indira Gandhi Hospital Sector 9 Dwarka
शिकायत निवारण & dad fray Contact details of | HOD Email id :manipadma.rabha@gov.in
Grievance redressal Buyer Email id: anil.k.nagar@nic.in
Hel Arat/Total Quantity j269
