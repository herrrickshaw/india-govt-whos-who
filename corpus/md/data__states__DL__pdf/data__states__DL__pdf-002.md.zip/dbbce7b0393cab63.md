---
doc_id: "dbbce7b0393cab63"
source_url: "https://fsd.delhi.gov.in/sites/default/files/FS/tender/18.tenderdocumentcards.pdf"
ministry: "Food Supplies and Consumer Affairs Department, Delhi"
title: "Tender Document"
date: ""
pages: 43
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "92777dcda31937d8"
---

<!-- page 1 -->

Request For Proposal (RFP)
For Selection of Agency
For
Supply and Personalization
of
Plastic Ration Cards
(as part of National Food Security Act 2013 Implementation in NCT of Delhi)

Tender no.: 2014_FSCAD_54051_1
Date of Issue: 28-02-2014
Issued by:
Department of Food and Supplies
Government of National Capital Territory (NCT) of Delhi

<!-- page 2 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Glossary
1.

DD

Demand Draft

2.

EMD

Earnest Money Deposit

3.

GFR

General Financial Rules

4.

GoI

Government of India

5.

INR

Indian National Rupees

6.

LoI

Letter of Intent

7.

NCT

National Capital Territory

8.

PBG

Performance Bank Guarantee

9.

PoA

Power of Attorney

10.

RFP

Request for Proposal

11.

RoC

Registrar of Companies

12.

SI

System Integrator

13.

SLA

Service Level Agreement

14.

SOW

Scope of Work

15.

UAT

User Acceptance Test

Ver 1.1

Page 2 of 43

<!-- page 3 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Terms and Legends used in this document
Symbol / Terms

Meaning

<< >>

Text to be filled in by the bidder in response to this document

Department

Department of Food and Supplies, Government of National Capital
Territory of Delhi, the “owner” of the project under which this RFP
document is being issued

Smart Ration Card

A non-chip based plastic card meeting the requirements mentioned in
this RFP
A chip / non-chip based plastic card

Smart card / Non smart
card
Preparation of Smart
Ration Cards

Bidder

Ver 1.1

Means Supply and Personalization of Smart Ration Cards. Department
will provide the data for personalization.
Personalization is the process of printing (dynamic / variable) user data
on supplied card ; a supplied card is one that the has been provided by
the vendor with pre-printed (requisite) static information
Any firm or group of firms (called consortium) offering the solution,
service(s) and /or materials as required in the RFP.

Page 3 of 43

<!-- page 4 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Table of Contents
1

Important Information.......................................................................................................... 5

2

Request for Proposal – Preparation of Smart Ration Cards ..................................................... 6
2.1

Fact Sheet................................................................................................................................ 6

2.2

Request for Proposal- Invitation to bid................................................................................... 8

2.3

Structure of the RFP ................................................................................................................ 8

2.4

Background Information ......................................................................................................... 9

2.5

Instructions to the Bidders.................................................................................................... 11

2.6

Criteria for Evaluation ........................................................................................................... 18

2.7

Appointment of Agency .................................................................................................... 2120

2.8

Scope of Work ................................................................................................................... 2322

2.9

Service Level Agreement....................................................................................................... 24

2.10

Quality Testing and Certification ...................................................................................... 2524

2.11

Payment Schedules ........................................................................................................... 2625

2.12

Acceptance Criterion......................................................................................................... 2625

2.13

Fraud and Corrupt Practices ............................................................................................. 2625

2.14

Conflict of Interest ................................................................................................................ 27

AppendixI: Technical Bid Templates ............................................................................................. 3029
Appendix II: Financial Proposal Template ..................................................................................... 3837
Appendix III: Template for Performance Bank Guarantee ........................................................... 4140
Appendix IV: Template for Contract Agreement .......................................................................... 4342

Ver 1.1

Page 4 of 43

<!-- page 5 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

1 Important Information
S. No.

Particular

Details

1.

Start date of downloading of RFP document

28 Feb 2014

2.

Last date for Submission of Pre-Bid Queries

09 Mar 2014

3.

Pre-Bid Conference

4.

Start date for submission of Bid documents

14 Mar 2014

5.

Last date for downloading of RFP document

31 Mar 2014

6.

Last date for submission of Bid documents

31 Mar 2014

7.

Date and time for opening of Technical bids

02 Apr 2014, 11.30 AM

8.

Date and time for opening of Commercial bids

Will be intimated later

Ver 1.1

12 Mar 2014, 02.30PM

Page 5 of 43

<!-- page 6 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

2 Request for Proposal – Preparation of Smart Ration Cards
2.1 Fact Sheet
Clause Reference
Section 2.6.3

Topic
The method of selection is: Cost Based Selection

Section 2.5.4.3

e-Tendering process will be followed by the Department.
RFP can be
Downloaded from the website : https://govtprocurement.delhi.gov.in
This document can be downloaded free of cost.

Section 2.5.4.4

Earnest Money Deposit of amount INR 10 (Ten) Lakhs by
Account Payee Demand Draft or Banker’s Cheque in favour of
“Commissioner, Food & Supplies” payable at “Delhi” from any of the
nationalized Banks
OR
Bank Guarantee as mentioned in Appendix I (Form 3)
EMD should remain valid for 45days after the Bid Validity period (i.e. Bid Validity
period + 45 days).
The bidders are required to submit the EMD at the following address :
Commissioner,
Department of Food & Supplies,
K-Block, Vikas Bhavan,
I.P. Estate, New Delhi-110002
Tel. No. : 011 – 23378759, 011 – 23379263
E-mail: ac2fs.delhi@nic.in

Section 2.5.3.1

Ver 1.1

A pre-Bid meeting/conference will be held in the office of the Commissioner,
Department of Food & Supplies, on the date and time as mentioned in section 1
The name, address, and telephone numbers of the Nodal Officer is:
Additional Commissioner,
Department of Food& Supplies,
Government of National Capital Territory of Delhi,
K-Block, Vikas Bhavan,
I.P. Estate, New Delhi-110002
Tel. No. : 011 - 23370070
011 - 23379311
E-mail: ac2fs.delhi@nic.in

Page 6 of 43

<!-- page 7 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Clause Reference

Topic
All the queries should be received on or before the last date of Submission of Queries
as mentioned in section 1, through email.

Section 2.5.5.2

Proposals should be submitted in the following language(s): English

Section 2.11

Taxes: As applicable

Section 2.5.7.2

Bid validity Period
Proposals must remain valid for 180 days after the last date of Proposal
Submission as mentioned in section 1

Section 2.5.4.5

Bidders must upload to the department’s website:
The original documents need to be color scanned (of good quality
resolution) in PDF format and grouped together to generate the Technical
and Financial Proposal document files and uploaded under relevant sections
on the department’s website.
Bidder should submit the finished sample Smart Ration cards using the processes that
they intend to use during production at the following address :
Commissioner,
Department of Food & Supplies,
K-Block, Vikas Bhavan,
I.P. Estate, New Delhi-110002
Tel. No. : 011 – 23378759, 011 - 23379263
Each sample card should have the name of the bidder printed on the back of the card
(for identification purpose) at an appropriate location.

Section 2.5.5.3

Proposal should be uploaded at the following website :
https://govtprocurement.delhi.gov.in.

Section 2.5.5.4

Proposals must be submitted no later than the last date of Proposal Submission as
mentioned in section 1.

Section 2.8

Department shall provide the art work to be used for static information printing. The
art work can be accessed (along with this RFP) at the website:
https://govtprocurement.delhi.gov.in.

Section 2.4.1

Contract Period
Any contract that may result from this Government procurement will be
issued for a term of 5 (five) years (“the Term”).

Section 2.7.5

Validity of Performance Bank Guarantee
Performance Bank Guarantee must remain valid for 60 days after

Ver 1.1

Page 7 of 43

<!-- page 8 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Clause Reference

Topic
completion of Contract Period.

Appendix IV:

Draft Contract Agreement
can be downloaded along with this RFP document from the website :
https://govtprocurement.delhi.gov.in

2.2 Request for Proposal- Invitation to bid
Tenders are invited from eligible, reputed, qualified firms with sound technical and financial capabilities
for preparation (supply and personalization) of Smart Ration Cards as detailed out in the Scope of Work
under Section 2.8of this Request for Proposal (RFP) Document. This invitation to bid is open to all
Bidders meeting the minimum eligibility criteria as mentioned in Section 2.6.1 of this RFP Document.

2.3 Structure of the RFP
This RFP document for the project of Preparation of Smart Ration Cards for the Department comprise of
the following.
i.

Instructions on the Bid process for the purpose of responding to this RFP. This broadly covers:
a. General instructions for bidding process
b. Bid evaluation process including the parameters for Technical evaluation and
commercial evaluation to facilitate Department in determining bidder’s suitability as the
implementation partner
c. Payment schedule
d. Commercial bid and other formats

ii.

Functional and Technical Requirements of the project. The contents of the document broadly cover
the following areas:
a. About the project and its objectives
b. Scope of work for the Implementation Partner
c. Functional and Technical requirements

Ver 1.1

Page 8 of 43

<!-- page 9 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

d. Project Schedule
e. Service levels for the implementation partner
The bidder is expected to respond to the requirements as completely and in as much relevant detail
as possible, and focus on demonstrating bidder’s suitability to become the implementation partner
of Department.
iii.

Master Service Agreement (MSA), Service Level Agreement (SLA) and Non-DisclosureAgreement
provided at Appendix IV.

The bidders are expected to examine all instructions, forms, terms, Project requirements and other
information in the RFP documents. Failure to furnish all information required as mentioned in the RFP
documents or submission of a proposal not substantially responsive to the RFP documents in every
respect will be at the Bidder's risk and may result in rejection of the proposal.

2.4 Background Information
2.4.1

Basic Information

a)

Department invites responses (“Tenders”) to this Request for Proposals (“RFP”) from Agencies (“Bidders”)
for the provision of Services as described in Section 2.8 of this RFP, “Scope of Work”.
b) Any contract that may result from this Government procurement competition will be issued for a term as
mentioned in the Fact Sheet.
c) The Department reserves the right to extend the Term for a period or periods of up to 1 (one) year with a
maximum of 2, such extension or extensions shall be on the same terms and conditions, subject to the
Department’s obligations at law.
d) Proposals must be received not later than time, date and venue mentioned in the Fact Sheet. Proposals
that are received late WILL NOT be considered in this procurement process.

2.4.2

Project Background

Public Distribution System in the country is one of the important social safety-net program to ensure
food security for all in a scenario of self-sufficiency. Under Public Distribution System, Central Govt.
procures and supplies specified essential commodities to Govt. of NCT of Delhi at fixed Central Issue
Prices. PDS in Delhi is confined to two cereals, wheat and rice, and two other essential commodities viz.
sugar and kerosene oil. In Delhi, PDS comprises of a network of 2482 Fair Price Shops & 2356 Kerosene
Oil Depots catering to an active base of 17.76 lakh ration card holders across all strata of the population.
Department of Food and Supplies is one of the important Departments of the Government of National
Capital Territory (NCT) of Delhi. The main objectives of the Department are to effectively implement the
Public Distribution System (PDS) and be responsive to the needs of the citizens and programs of the
Ver 1.1

Page 9 of 43

<!-- page 10 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

government of NCT of Delhi. The PDS will now follow the newly launched National Food Security
program. Under the Department there are 9 Assistant Commissioner Offices and 70 Circle offices. It is
envisaged that Delhi will be the first State in the country to implement the National Food Security Act
2013 wherein around 73.5 lakh people (about 44% of total population) in Delhi will be covered under
the food security Act
To achieve end to end Computerization of Public Distribution System in Delhi, “ePDS” portal was
launched in July 2011. This introduced a large degree of transparency in the Public Distribution System
as it brought about availability of online information regarding availability of stock at Fair Price Shops,
allocations and entitlements even though this drive did not cover the computerization of the Fair Price
Shops. Thus the Department of Food & Supplies has been using Information Technology (IT) solutions,
though not end to end, to better manage its internal and external stakeholders (citizens) by
implementing various IT initiatives. The following challenges still need to be addressed:
a)

Non Availability of ‘near real-time’ information about the operations at the Fair Price Shops to both
internal stakeholders and citizens
b) The ration card holder data consists of duplicate and spurious users
c) Categorization of ration card holders is outdated and not as per the latest gazette notifications including
those specified in the Food Security Act 2013

A need has been felt by the department to put in place a comprehensive IT solution to meet the above
challenges.
This RFP document addresses the need to provide Smart Ration cards to the beneficiaries across Delhi.
This is an important pre-requisite to develop and implement the planned comprehensive IT solution.

2.4.3

Key Information

Objectives
a) To replace the current paper based ration cards with Smart Ration Cards.
b) To select an agency which can supply and personalize Smart Ration Cards as detailed out in the Scope of Work
under Section 2.8 of this RFP Document.

Dependencies
a)

The ‘seeding’ of Aadhaar numbers in the current ePDS system is being undertaken as of writing this RFP
document. Availability of complete beneficiary data for personalization is dependent on this activity.
b) Availability of digitized ePDS beneficiary data to the vendor

Stakeholder Details
Following important stakeholders have been identified:
a) IT department, Government of NCT of Delhi
b) State NIC cell
Ver 1.1

Page 10 of 43

<!-- page 11 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

c)
d)
e)
f)

Beneficiaries
Circle Offices of the Department
FPS owners
Smart Ration Card vendor

2.4.4

About the Department

Information about the Department can be obtained at the following web site: http://fs.delhigovt.nic.in

2.5 Instructions to the Bidders
2.5.1
a)

General

While every effort has been made to provide comprehensive and accurate background information and
requirements and specifications, Bidders must form their own conclusions about the solution needed to
meet the requirements. Bidders and recipients of this RFP may wish to consult their own legal advisers in
relation to this RFP.

b) All information supplied by Bidders may be treated as contractually binding on the Bidders, on successful
award of the assignment by the Department on the basis of this RFP.
c)

No commitment of any kind, contractual or otherwise shall exist unless and until a formal written contract
has been executed by or on behalf of the Department. Any notification of preferred bidder status by the
Department shall not give rise to any enforceable rights by the Bidder. The Department may cancel this
public procurement at any time prior to a formal written contract being executed by or on behalf of the
Department.

d) This RFP supersedes and replaces any previous public documentation & communications, and Bidders
should place no reliance on such communications.
e)

Department may terminate the RFP process at any time and without assigning any reason. Department
makes no commitments, express or implied, that this process will result in a business transaction with
anyone.

f)

This RFP does not constitute an offer by the Department. The bidder's participation in this process may
result in the Department selecting the bidder to engage towards execution of the contract.

2.5.2

Ver 1.1

Compliant Proposals/ Completeness of Response

Page 11 of 43

<!-- page 12 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

a)

Bidders are advised to study all instructions, forms, terms, requirements and other information in the RFP
documents carefully. Submission of the bid shall be deemed to have been done after careful study and
examination of the RFP document with full understanding of its implications.

b) Failure to comply with the requirements of this paragraph may render the Proposal non-compliant and
the Proposal may be rejected. Bidders must:
i.
Include all documentation specified in this RFP;
ii.
Follow the format of this RFP and respond to each element in the order as set out in this RFP
iii.
Comply with all requirements as set out within this RFP.

2.5.3

Pre-Bid Meeting & Clarifications

2.5.3.1 Pre-bid Conference
a.

Department may hold a pre-bid meeting with the prospective bidders. Refer Fact Sheet for details.
The Bidders will have to ensure that their queries for Pre-Bid meeting should reach the designated officer
on or before the Date mentioned in the Fact Sheet.

b.

The queries should necessarily be submitted in the following format:
S. No.

RFP Document Reference(s)
(Section & Page Number(s))

Content of RFP requiring
Clarification(s)

Points of clarification

1.
2.
3.
4.
5.
6.
c.

Department shall not be responsible for ensuring that the bidders’ queries have been received by them.
Any requests for clarifications post the indicated date and time may not be entertained by the
Department.

2.5.3.2 Responses to Pre-Bid Queries and Issue of Corrigendum
a.

b.

Ver 1.1

The Department will endeavor to provide timely response to all queries. However, Department makes no
representation or warranty as to the completeness or accuracy of any response made in good faith, nor
does Department undertake to answer all the queries that have been posed by the bidders.
At any time prior to the last date for receipt of bids, Department may, for any reason, whether at its own
initiative or in response to a clarification requested by a prospective Bidder, modify the RFP Document by
a corrigendum.

Page 12 of 43

<!-- page 13 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

c.
d.
e.

The Corrigendum (if any) & clarifications to the queries from all bidders will be posted on the website
:https://govtprocurement.delhi.gov.in.
Any such corrigendum shall be deemed to be incorporated into this RFP.
In order to provide prospective Bidders reasonable time for taking the corrigendum into account,
Department may, at its discretion, extend the last date for the receipt of Proposals.

2.5.4

Key Requirements of the Bid

2.5.4.1 Consortiums

a. More than one firm can form a consortium to participate in the tender. But one company
cannot be member of more than one consortium participating in the tender.
b. The consortium of firms should be duly constituted as per the instrument/agreement
evidencing the formation of consortium, nominating the lead bidder who shall be responsible
for receiving notices and communications on behalf of the consortium, but shall not include the
subsidiary, step down subsidiary, associate, Joint Venture of any of the firms.
c. Consortium should abide by the following:
i.
ii.
iii.
iv.
v.

The lead bidder is liable for the entire scope of work and risks involved thereof
Liability of non-lead bidder(s) is for the scope of work for which they are responsible along with
the lead bidder (the lead bidder still carries the liability for the entire scope of work)
Any change in the consortium member at a later date will not be allowed
Provide clarity on the roles and responsibility of each member of the consortium
All the members are part of the contractual arrangement between themselves before submitting
the bid

2.5.4.2 Sub-contracting

Sub-contracting / outsourcing shall not be allowed.

2.5.4.3 RFP Document

e-Tendering process will be followed by the Department. The bidder can download the RFP document
from the website provided in the Fact sheet.

2.5.4.4 Earnest Money Deposit (EMD)
a.

Bidders (except those who are registered with the Central Purchase Organisation, National Small
Industries Corporation (NSIC) or this Department) shall submit along with their Bids, EMD of said amount
as mentioned in the Fact sheet.

Ver 1.1

Page 13 of 43

<!-- page 14 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

b.
c.
d.
e.
f.

EMD of all unsuccessful bidders would be refunded by Department within 30 days after the award of the
contract to the successful bidder.
The EMD of successful bidder would be returned upon submission of Performance Bank Guarantee as per
the format provided in Appendix III : Form 7.
The EMD amount is interest free and will be refundable to the unsuccessful bidders without any accrued
interest on it.
The bid / proposal submitted without EMD, will be summarily rejected.
The EMD may be forfeited:
•

If a bidder withdraws its bid during the period of bid validity.

•

In case of a successful bidder, if the bidder fails to sign the contract in accordance with this RFP.

2.5.4.5 Submission of Proposals

a. The bidders should submit their responses as per the format given in this RFP in the manner
mentioned in the Fact sheet.
b. The Technical and Commercial Proposal should be uploaded at the website mentioned in the
fact sheet.
c. The documents to be submitted as part of the Technical proposal are stated in Appendix I: Form
1. The original documents need to be color scanned, resolution being at least 200-dpi,in PDF
format and grouped together into one file for uploading as ‘Technical Proposal’. Bidders to
ensure that the scan copies are of good quality and that the prints generated from these scans
are clear / legible.
d. The documents to be submitted as part of the Financial proposal are stated in Appendix II: Form
6. The original documents need to be color scanned, resolution being at least 200-dpi,in PDF
format and grouped together into one file for uploading as ‘Financial Proposal’. Bidders to
ensure that the scan copies are of good quality and that the prints generated from these scans
are clear / legible.
e. Please note that prices should not be indicated in the Technical Proposal but should only be
indicated in the Commercial Proposal.
f. As part of the Technical Proposal, bidder shall submit 10 finished sample Smart Ration cards
using the processes that they intend to use during production. The art work (as provided by the
Department)for Static information is available at the website given in the factsheet. Bidder may
use dummy information for Personalization. Each sample card should have the name of the
bidder printed on the back of the card (for identification purpose) at an appropriate location.
g. All the pages of the proposal must be sequentially numbered and must contain the list of
contents with page numbers. Any deficiency in the documentation may result in the rejection of
the Bid.
h. The proposal/bid shall contain no interlineations or overwriting, except as necessary to correct
errors made by the bidder itself. Any such corrections must be initialed by the person (or
persons) who sign(s) the proposals.
i. All pages of the bid, shall be initialed and stamped by the person or persons who sign the bid.

Ver 1.1

Page 14 of 43

<!-- page 15 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

2.5.4.6 Authentication of Bids

A Proposal should be accompanied by a power-of-attorney in the name of the signatory of the Proposal.
The selected bidder shall indicate the authorized signatories who can discuss and correspond with the
Department. The bidder shall provide proof of signature identification for the above purposes as
required by the Department.

2.5.4.7 Confidentiality

The bidder must undertake that they shall hold in trust any information received by them, under the
Contract/Agreement, and the strictest of confidence shall be maintained in respect of such information.
The bidder has also to agree:
a)

To maintain and use the information only for the purposes as per the contract/Agreement and only as
permitted by the Department.
b) To make copies as specifically authorized by the prior written consent of the Department and with the
same confidential or proprietary notices as may be printed or displayed on the original;
c) To restrict access and disclosure of Information to their employees, agents, strictly on a "need to know"
basis, to maintain confidentiality of the Information disclosed to them in accordance with this Clause and
d) To treat all information as Confidential Information

The successful bidder shall also sign a Non-disclosure Agreement with the department.

2.5.5

Preparation and Submission of Proposal

2.5.5.1 Proposal Preparation Costs

The bidder shall be responsible for all costs incurred in connection with participation in the RFP process,
including, but not limited to, costs incurred in conduct of informative and other diligence activities,
participation in meetings/discussions/presentations, preparation of proposal, in providing any additional
information required by Department to facilitate the evaluation process, and in negotiating a definitive
contract or all such activities related to the bid process.
Department will in no case be responsible or liable for those costs, regardless of the conduct or outcome
of the bidding process.

2.5.5.2 Language

The Proposal should be filled by the Bidder in the language mentioned in the Fact sheet. If any
supporting documents submitted are in any language other than the said language, translation of the

Ver 1.1

Page 15 of 43

<!-- page 16 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

same in the said language is to be duly attested by the Bidders. For purposes of interpretation of the
Proposal, the said translation shall govern.

2.5.5.3 Venue & Deadline for Submission of Proposals

Proposals, in its complete form in all respects as specified in the RFP, must be uploaded at the
Department’s website as mentioned in the Fact sheet.

2.5.5.4 Late Bids
a.
b.
c.

Department shall not be responsible for any delay or non-receipt/ non-delivery of the documents. No
further correspondence on the subject will be entertained.
The bids submitted by telex/fax/post/e-mail etc. shall not be considered. No correspondence will be
entertained on this matter.
Department reserves the right to modify and amend any of the above-stipulated condition/criterion
depending upon project priorities vis-à-vis urgent commitments.

2.5.6

Deviations

The bidder may not provide any deviation / non-compliance to the contents of the RFP document. Any
deviation /non-compliance may lead to rejection.

2.5.7
a.
b.

c.

d.
e.
f.

Evaluation Process

Department will constitute a Proposal Evaluation Committee to evaluate the responses of the bidders
The Proposal Evaluation Committee constituted by the Department shall evaluate the responses to the
RFP and all supporting documents / documentary evidence. Inability to submit requisite supporting
documents / documentary evidence, may lead to rejection.
The decision of the Proposal Evaluation Committee in the evaluation of responses to the RFP shall be
final. No correspondence will be entertained outside the process of negotiation/ discussion with the
Committee.
The Proposal Evaluation Committee may ask for meetings with the Bidders to seek clarifications on their
proposals.
The Proposal Evaluation Committee reserves the right to reject any or all proposals on the basis of any
deviations.
Each of the responses shall be evaluated as per the criterions and requirements specified in this RFP.

2.5.7.1 Tender Opening

Ver 1.1

Page 16 of 43

<!-- page 17 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

The submitted Proposals will be opened by an officer authorized by Department, in the presence of such
of those Bidders or their representatives who may be present at the time of opening.
The representatives of the bidders should be advised to carry the identity card or a letter of authority
from the tendering firms to identify their bonafides for attending the opening of the proposal.

2.5.7.2 Bid Validity

The offer submitted by the Bidders should be valid for the period mentioned in the Fact sheet.
Department holds the rights to reject a Bid that is valid for a period shorter than the specified period as
non-responsive, without any correspondence.
Department may solicit the Bidder’s consent to an extension of the validity period. The request and the
response thereto shall be made in writing. Extension of validity period by the Bidder should be
unconditional and irrevocable. The EMD provided shall also be suitably extended by the bidder. A bidder
acceding to the request will neither be required nor be permitted to modify its Bid. A bidder may refuse
the request (to extend the validity period) without forfeiting its EMD. In any case, the EMD of the
bidders shall be returned after completion of the process.

2.5.7.3 Tender Evaluation

a. Initial Bid scrutiny will be held and incomplete details as given below will be treated as nonresponsive, if Proposals :
• Are not submitted in as specified in the RFP document
• Received without the Letter of Authorization (Power of Attorney)
• Are found with suppression of details
• With incomplete information, subjective, conditional offers and partial offers submitted
• Submitted without the documents requested in the checklist
• Have non-compliance of any of the clauses stipulated in the RFP
• With lesser validity period
b. All responsive Bids will be considered for further processing as below.
Department will prepare a list of responsive bidders, who comply with all the Terms and
Conditions of the Tender. All eligible bids will be considered for further evaluation by a
Committee according to the Evaluation process define in this RFP document. The decision of the
Committee will be final in this regard.

Ver 1.1

Page 17 of 43

<!-- page 18 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

2.6 Criteria for Evaluation
2.6.1

Technical Qualification Criteria

Bidders who meet the below given eligibility requirements and score minimum technical marks would
be considered as qualified to move to the next stage of Financial evaluations.

S.
No.

Eligibility
Requirement

Specific Requirements

Documents Required

1.

Nature of
Work
Turnover

Bidder’s Annual Sales Turnover (global / India
based) generated from services related to
preparation (supply and personalization) of
smart cards / non smart cards during each of
the last three financial years (as per the last
published/audited Balance sheets), should be at
least INR 10 (ten) crores. However, a total
turnover (10 crores) of the company in which at
least 5 (Five) crores turnover should be in the
manufacturing and supply of Plastic Cards or
Smart Cards

Extracts from the
published/audited Balance sheet
and Profit & Loss;

2.

3.

Net Worth

Technical
Capability

Turnover shall mean and include the value of
sale of Goods & Services by a firm or consortium
of firms taken together involved in the activity
of preparation (supply and personalization) of
smart cards / non smart cards, but shall not
include turnover of subsidiary, step down
subsidiary, associate, Joint Venture of any of the
bidders
Positive during each of the last three financial
years (as per the last published/audited Balance
sheets)
Bidder must have successfully completed at
least the following numbers of project(s)of
value specified herein :
ne project of similar nature supplying
15(fifteen) lakh cards or more; OR
wo projects of similar nature supplying
10 (ten) lakh cards or more; OR

If
Consortium
- Clause to
be satisfied
by

OR

Certificate from the statutory
auditor

Certificate from the statutory
auditor
Completion Certificates from the
client;
OR
Purchase / Work Order + Self
Certificate of Completion
(Certified by the Statutory
Auditor); OR
Purchase / Work Order + Phase
Completion Certificate from the
client

Any of the
Consortium
members

Lead Bidder

Any of the
Consortium
members

Ver 1.1

Page 18 of 43

<!-- page 19 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

S.
No.

Eligibility
Requirement

Specific Requirements

Documents Required

If
Consortium
- Clause to
be satisfied
by

hree projects of similar nature supplying
06 (six) lakh cards or more

Definitions:
roject of Similar Nature means a
project for preparation (supply and
Personalization)of smart cards / nonsmart cards
roject can be in government or nongovernment sector
4.

5.

Consortiums

Legal Entity

Firms participating as a consortium should have
entered into a legal agreement to form the
consortium before bidding that is valid for at
least 5 years

Duly registered or Notarised
Agreement / Instrument
between the firms to form a
consortium

Should be Company registered under
Companies Act, 1956
Registered with the Indian Service Tax
Authorities and local Sales tax/Value added tax
Authorities (as applicable)

-

Should have been operating for the last three
years providing services related to preparation
(supply and personalization) of smart cards /
non smart cards
In case of consortium, the lead bidder should
satisfy the above stated conditions in this
clause)
6.

7.

Blacklisting

Visual
Inspection of
Submitted
sample cards

Ver 1.1

The bidder should not be blacklisted or banned
by any Government / Government Department
/ Government Agency / PSU / Banks for corrupt
or fraudulent practices or non-delivery or nonperformance in last 3 years
The sample cards submitted by the bidder in the
response to the bid should be as per the process
that the bidder intends to use during
production.

-

Certificate of incorporation
copy of Service Tax and sales
Tax/ Value added tax
registration
-

Each of the
Consortium
members

Acknowledged Income Tax
returns

Affidavit or A Self-Certified
letter

A Self-Certified letter stating that
the samples provided are as per
requirements and that the
samples have been submitted to
the Department

Each of the
Consortium
members

-

Page 19 of 43

<!-- page 20 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

2.6.2

Technical Scoring Model

S.
No

Criteria

Basis for valuation

1.

The Bidder should have a per
day manufacturing capacity of
50,000 plastic cards (for Static
Data)

More than 50,000: 10 marks

Work experience with any
Indian Government
departments / Indian PSUs /
Banks in the last 3 years to
supply and personalize smart /
non-smart cards. Each project
should be for supply of atleast 6
lakh cards.
Total Work experience capacity
of supplying and
personalization of smart / nonsmart cards in the last 3 years

More than 2 projects : 10
1 -2 projects: 5
No projects: 0

10

More than 30 lakh cards: 20
20- 30 lakh cards: 15
10 - 20 lakh cards: 10
5 - 10 lakh cards: 5

20

Quality Certifications

ISO 9001:2008 : 10

10

2.

3.

4.

Max Marks

10

30,000 - 50,000 : 5 marks
Less than 30,000 : 2 marks

Supporting

Valid Industrial
Certificate, Factory
License or
Self-Certificate for
Installed capacity
of production
(Certified by a
Statutory auditor)
Filled Project
Citation (Form 5)

If Consortium Clause to be
satisfied by

Any of the
Consortium
members

Any of the
Consortium
members

Other Internationally
acceptable industry standard
certification: 5

Purchase / Work
Order &
completion
Certificate issued
by the client
Copy of
Certificates

Any of the
Consortium
members

Any of the
Consortium
members

No certificate: 0
5.

Visual Inspection of Submitted
sample cards

Good : 10
Normal: 5

10

-

-

Bidders, whose bids are responsive, who score at least 60% in the defined technical scoring mechanism
would be considered technically qualified. Price Bids of such technically qualified bidders alone shall
further be opened.

Ver 1.1

Page 20 of 43

<!-- page 21 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

2.6.3

Commercial Bid Evaluation

a. The Financial Bids of technically qualified bidders will be opened on the prescribed date in the presence of
bidder representatives.
b. The Bidder, who has submitted the lowest Commercial bid, shall be selected as the L1 and shall be called
for further process leading to the award of the assignment
c. Only fixed price financial bids indicating total price for all the deliverables and services specified in this bid
document will be considered.
d. The bid price will include all taxes and levies and shall be in Indian Rupees and mentioned separately.
e. Any conditional bid would be rejected.
f. Errors & Rectification: Arithmetical errors will be rectified on the following basis: “If there is a discrepancy
between the unit price and the total price that is obtained by multiplying the unit price and quantity, the
unit price shall prevail and the total price shall be corrected. If there is a discrepancy between words and
figures, the amount in words will prevail”.

2.7 Appointment of Agency
2.7.1

Award Criteria

Department will award the Contract to the successful bidder(s) whose proposal has been determined to
be substantially responsive and has been determined as the most responsive bids as per the process
outlined above.

2.7.2

Right to Accept Any Proposal and To Reject Any or All Proposal(s)

Department reserves the right to accept or reject any proposal, and to annul the tendering process /
Public procurement process and reject all proposals at any time prior to award of contract, without
thereby incurring any liability to the affected bidder or bidders or any obligation to inform the affected
bidder or bidders of the grounds for Department action.
2.7.3

Notification of Award

Prior to the expiration of the validity period, Department will notify the successful bidder in writing or by
fax or email, that its proposal has been accepted. In case the tendering process / public procurement
process has not been completed within the stipulated period, Department, may like to request the
bidders to extend the validity period of the bid.
The notification of award will constitute the formation of the contract. Upon the successful bidder's
furnishing of Performance Bank Guarantee, Department will notify each unsuccessful bidder and return
their EMD.

Ver 1.1

Page 21 of 43

<!-- page 22 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

2.7.4

Contract Finalization and Award

The Department shall reserve the right to negotiate with the bidder(s) whose proposal has been ranked
best value bid on the basis of Technical and Commercial Evaluation to the proposed Project, as per the
guidance provided by CVC.
On this basis the draft MSA would be finalized for award & signing.

2.7.5

Performance Bank Guarantee

The Department will require the selected bidder to provide a Performance Bank Guarantee, within 15
days from the Notification of award, for a value equivalent to 10% of the total cost of ownership. The
Performance Guarantee should be valid as mentioned in the Fact sheet. The selected bidder shall be
responsible for extending the validity date and claim period of the Performance Guarantee as and when
it is due on account of non-completion of the project. In case the selected bidder fails to submit
performance guarantee within the time stipulated, the Department at its discretion may cancel the
order placed on the selected bidder without giving any notice. Department shall invoke the performance
guarantee in case the selected Vendor fails to discharge their contractual obligations during the contract
period or Department incurs any loss due to Vendor’s negligence in carrying out the project
implementation as per the agreed terms & conditions.

2.7.6

Signing of Contract

After the Department notifies the successful bidder that its proposal has been accepted, Department
shall enter into a contract, incorporating all clauses, pre-bid clarifications and the proposal of the bidder
between Department and the successful bidder. The draft MSA is provided at Appendix IV.

2.7.7

Failure to Agree with the Terms and Conditions of the RFP

Failure of the successful bidder to agree with the draft MSA and Terms & Conditions of the RFP shall
constitute sufficient grounds for the annulment of the award, in which event Department may award
the contract to the next best value bidder or call for new proposals from the interested bidders.
In such a case, the Department shall invoke the Performance Bank Guarantee of the successful bidder.

Ver 1.1

Page 22 of 43

<!-- page 23 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

2.8 Scope of Work
Broad Scope of Work
The broad scope of work of the successful bidder is fully responsible:
a)

To manufacture smart ration cards with static information and personalize the card based on the data
provided by the Department. Appropriate paper jackets will also have to be provided. The design layout of
the Smart Ration card will be as specified by the Department. Department shall provide appropriate soft
copy of the image files in either Adobe Illustrator (.ai) / Corel draw (.cdr) format.
b) To package (in cartons) the finished cards along with the jackets into FPS wise groups for each circle.
c) To deliver the circle wise packaged cartons to the Assistant Commissioner of each circle.
d) To deliver approximately 14 lakh personalized cards during the contract period. Also provision for an
additional (approximately) 10% cards, on the same rate quoted in the proposal, for ongoing maintenance
related activity during the contract period.
e) For Bulk card personalization: During the contract period, the Department will inform the bidder (from
time to time) about the quantity of personalized cards to be delivered (circle wise). This quantity can vary
and is at the discretion of the department. However the Department shall endeavor to give a substantial
quantity in each request. It is envisaged by the Department that the most of this work is to be completed
in 6 – 7 months.
f) For Ongoing ‘Maintenance’ card personalization: During the contract period, the bidder will have to
supply finished cards as per the needs of the Department. Maintenance shall mean creation of new cards
due to any reason that is not attributable to the vendor.

Detailed Scope of Work
Technical specifications for the Smart Ration Cards, Printing and Card Jackets are as given below:
A. Material and Size of the Cards
i.
ii.
B.

The Smart Ration Card shall be made of PolyVinyl Chloride(PVC) and of 760 microns thickness.
The card should be CR-80type adhering to ISO/IEC 7810 standards.

Quality of the Cards
i.
The finished cards shall be compatible to personalization using appropriate good quality printing
process.
ii.
Quality of the Smart Ration Cards should be guaranteed for five years (after delivery to the
Department)meeting the below specifications:
Non-peeling of the overlays on use
Non-breakage due to the card material becoming brittle
Non-leakage, non-smudging, non-erasure of the text and Image
iii.
The finished cards should of excellent quality meeting the quality test standards as mentioned in
section 2.11 of this document. Department may test samples from the supplied lots from a third
party agency.

Ver 1.1

Page 23 of 43

<!-- page 24 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

C.

Printing
i.
Static information and Personalization printing should be done using appropriate good quality
printing technology

D. Card Jackets
i.
The card jacket shall be plain green colored envelope (GSM 200 Art paper, laminated)
E.

Data to be printed on the Cards
i.
Department shall provide the art work to be used for static information printing. The art work can be
accessed at the website as given in the factsheet. The bidder is responsible to adhere to the
specifications of the art work.
ii.
Personalization information details:

Front Side:
-

Ration Card No.
Category of Ration Card (if applicable)
Name of Head of the Family
Address
Photo of Head of the Family
FPS Shop No.
FPS Shop Firm name
Circle number
2D Bar code

The 2D bar code is to be generated by the bidder – information to be contained are the
Names and Aadhaar numbers of family members.
Back Side:
F.

Names of family members
Hologram (supplied by Department)

Delivery of Cards
i.
The vendor shall group the printed Smart Ration Cards FPS wise and generate a (packing) list
containing the details of beneficiaries for each FPS.
ii.
The FPS wise card lots shall then be grouped for a circle and packed in cartons.
iii.
A copy of the Packing lists and proof of delivery shall be sent to the department along with the
invoice.

2.9 Service Level Agreement
a)

Vendor should deliver the personalized cards as per the following schedule during the contract period:
Lot Size

Delivery Schedule

(as informed by Department)

Upto 10,000
Ver 1.1

07 days
Page 24 of 43

<!-- page 25 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Lot Size

Delivery Schedule

(as informed by Department)

10,000 to 100,000
100,000 to 250,000
> 250,000

15 days
20 days
30 days

In case of delay in delivery of cards a penalty @ 0.5% of the value of the proportionate quantity will be
deducted per day.
E.g., Vendor has received a request to supply 100,000 cards and has only delivered 90,000 cards within the
stipulated delivery schedule. Vendor takes 6 additional days to supply the remaining 10,000 cards. Then he is
liable to pay a penalty of Rs 0.5% of (value of 10,000 cards) * 6.
b) The card printing quality should be equal to or better than the sample submitted by the bidder during bid
response. In case the quality is not upto the mark, the Vendor shall have to reprint the same without any
additional charges.
c)

The errors in card printing not attributable to Department shall be treated as an error and the Vendor shall
have to reprint the same without any additional charges.

d) Any variation in printing of Data/Photo and other particulars shall be treated as errors and the Vendor shall be
solely responsible. In case of error in data printed on cards i.e. variation between card information and
database, the following penalty shall be applicable:

Error Rate
(per 1000 cards)
<= 10 %
>10 %

Deductions from Payment
(per erroneous card)
2%
10 %

Reprinting of Cards
Reprint of erroneous cards
Reprint of erroneous cards

2.10 Quality Testing and Certification
Bidder shall ensure that the supplied finished cards should be of excellent quality such that they adhere
the test procedures as laid out in ISO 10373-1. At a minimum the following test clauses may be noted:
ISO 10373-1 Test
clause
5.1
5.3
5.5
5.6
5.7
5.8
5.15
5.16

Ver 1.1

Property
Card warpage
Peel Strength
Card Dimensional stability with respect to temperature
Adhesion and blocking
Bending stiffness
Dynamic bending stress
Resistance to heat
Surface distortions & raised areas

Page 25 of 43

<!-- page 26 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

2.11 Payment Schedules
The Bidder will be paid on the actual number of accepted Cards (by the Department). Refer section
2.12 for definition of ‘accepted’ cards.
Milestone
No of accepted cards supplied in a
quarter

Billable Fee
Contracted price per card * no
of accepted cards

2.12 Acceptance Criterion
Delivered cards that meet all specifications as mentioned in this RFP shall only be accepted.

2.13 Fraud and Corrupt Practices
a.

The Bidders/Bidders and their respective officers, employees, agents and advisers shall observe the
highest standard of ethics during the Selection Process. Notwithstanding anything to the contrary
contained in this RFP, the Department shall reject a Proposal without being liable in any manner
whatsoever to the Bidder, if it determines that the Bidder has, directly or indirectly or through an agent,
engaged in corrupt practice, fraudulent practice, coercive practice, undesirable practice or restrictive
practice (collectively the “Prohibited Practices”) in the Selection Process. In such an event, the
Department shall, without prejudice to its any other rights or remedies, forfeit and appropriate the EMD
or Performance Bank Guarantee, as the case may be, as mutually agreed genuine pre-estimated
compensation and damages payable to the Authority for, inter alia, time, cost and effort of the Authority,
in regard to the RFP, including consideration and evaluation of such Bidder’s Proposal.

b.

Without prejudice to the rights of the Department under Clause above and the rights and remedies which
the Department may have under the LOI or the Agreement, if an Bidder or Systems Implementation
Agency, as the case may be, is found by the Authority to have directly or indirectly or through an agent,
engaged or indulged in any corrupt practice, fraudulent practice, coercive practice, undesirable practice or
restrictive practice during the Selection Process, or after the issue of the LOI or the execution of the
Agreement, such Bidder or Systems Implementation Agency shall not be eligible to participate in any
tender or RFP issued by the Department during a period of 2 (two) years from the date such Bidder or
Systems Implementation Agency, as the case may be, is found by the Department to have directly or
through an agent, engaged or indulged in any corrupt practice, fraudulent practice, coercive practice,
undesirable practice or restrictive practice, as the case may be.

c.

For the purposes of this Section, the following terms shall have the meaning hereinafter respectively
assigned to them:

Ver 1.1

Page 26 of 43

<!-- page 27 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

i.

“corrupt practice” means (i) the offering, giving, receiving, or soliciting, directly or indirectly, of
anything of value to influence the action of any person connected with the Selection Process (for
avoidance of doubt, offering of employment to or employing or engaging in any manner
whatsoever, directly or indirectly, any official of the Department who is or has been associated in
any manner, directly or indirectly with the Selection Process or the LOI or has dealt with matters
concerning the Agreement or arising there from, before or after the execution thereof, at any
time prior to the expiry of one year from the date such official resigns or retires from or
otherwise ceases to be in the service of the Department, shall be deemed to constitute
influencing the actions of a person connected with the Selection Process); or (ii) save as provided
herein, engaging in any manner whatsoever, whether during the Selection Process or after the
issue of the LOA or after the execution of the Agreement, as the case may be, any person in
respect of any matter relating to the Project or the LOA or the Agreement, who at any time has
been or is a legal, financial or technical consultant/ adviser of the Department in relation to any
matter concerning the Project;

ii.

“fraudulent practice” means a misrepresentation or omission of facts or disclosure of incomplete
facts, in order to influence the Selection Process;

iii.

“coercive practice” means impairing or harming or threatening to impair or harm, directly or
indirectly, any persons or property to influence any person’s participation or action in the
Selection Process;

iv.

“undesirable practice” means (i) establishing contact with any person connected with or
employed or engaged by Department with the objective of canvassing, lobbying or in any
manner influencing or attempting to influence the Selection Process; or (ii) having a Conflict of
Interest; and

v.

“restrictive practice” means forming a cartel or arriving at any understanding or arrangement
among Bidders with the objective of restricting or manipulating a full and fair competition in the
Selection Process.

2.14 Conflict of Interest
a.

b.

Ver 1.1

A bidder shall not have a conflict of interest that may affect the Selection Process or the delivery (the
“Conflict of Interest”). Any Bidder found to have a Conflict of Interest shall be disqualified. In the event of
disqualification, the Department shall forfeit and appropriate the EMD, if available, as mutually agreed
genuine pre-estimated compensation and damages payable to the Department for, inter alia, the time,
cost and effort of the Department including consideration of such Bidder’s Proposal, without prejudice to
any other right or remedy that may be available to the Department hereunder or otherwise.
The Department requires that the Implementation Agency provides solutions which at all times hold the
Department’s interests paramount, avoid conflicts with other assignments or its own interests, and act

Page 27 of 43

<!-- page 28 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

c.

Ver 1.1

without any consideration for future work. The Implementation Agency shall not accept or engage in any
assignment that would be in conflict with its prior or current obligations to other clients, or that may place
it in a position of not being able to carry out the assignment in the best interests of the Department.
Without limiting the generality of the above, an Bidder shall be deemed to have a Conflict of Interest
affecting the Selection Process, if:
i.
the Bidder, its consortium member (the “Member”) or Associates (or any constituent thereof)
and any other Bidder, its consortium member or Associate (or any constituent thereof) have
common controlling shareholders or other ownership interest; provided that this disqualification
shall not apply in cases where the direct or indirect shareholding or ownership interest of an
Bidder, its Member or Associate (or any shareholder thereof having a shareholding of more than
5 per cent of the paid up and subscribed share capital of such Bidder, Member or Associate, as the
case may be) in the other Bidder, its consortium member or Associate is less than 5% (five per
cent)of the subscribed and paid up equity share capital thereof. For the purposes of this Clause,
indirect shareholding held through one or more intermediate persons shall be computed as
follows:
− where any intermediary controlled by a person through management control or
otherwise, the entire shareholding held by such controlled intermediary in any other
person (the “Subject Person”) shall be taken into account for computing the
shareholding of such controlling person in the Subject Person; where a person does
not exercise control over an intermediary, which has shareholding in the Subject
Person, the computation of indirect shareholding of such person in the Subject
Person shall be undertaken on
− a proportionate basis; provided, however, that no such shareholding shall be reckoned
under this Sub-clause if the shareholding of such person in the intermediary is less
than 26% (twenty six per cent) of the subscribed and paidup equity shareholding of
such intermediary; or
ii.
a constituent of such Bidder is also a constituent of another Bidder; or
iii.
such Bidder or its Associate receives or has received any direct or indirect subsidy or grant from
any other Bidder or its Associate; or
iv.
such Bidder has the same legal representative for purposes of this Application as any other
Bidder; or
v.
such Bidder has a relationship with another Bidder, directly or through common third parties,
that puts them in a position to have access to each others’ information about, or to influence the
Application of either or each of the other Bidder; or
vi.
there is a conflict among this and other Implementation/Turnkey solution assignments of the
Bidder(including its personnel and other members, if any) and any subsidiaries or entities
controlled by such Bidder or having common controlling shareholders. The duties of the
Implementation Agency will depend on the circumstances of each case. While providing solutions
to the Department for this particular assignment, the Implementation Agency shall not take up
any assignment that by its nature will result in conflict with the present assignment; or
vii.
A firm hired to provide Integration/Turnkey solutions for the implementation of a project, and its
Members or Associates, will be disqualified from subsequently providing goods or works or
services related to the same project;

Page 28 of 43

<!-- page 29 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

d.

An Bidder eventually appointed to implement solutions for this Project, its Associates, affiliates and the
Financial Expert, shall be disqualified from subsequently providing goods or works or services related to
the construction and operation of the same Project and any breach of this obligation shall be construed as
Conflict of Interest; provided that the restriction herein shall not apply after a period of 12 months from
the completion of this assignment; provided further that this restriction shall not apply to software
solutions delivered to the Department in continuation of this systems implementation or to any
subsequent systems implementation executed for the Department in accordance with the rules of the
Department.

Ver 1.1

Page 29 of 43

<!-- page 30 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Appendix I: Technical Bid Templates
The bidders are expected to respond to the RFP using the forms given in this section and all documents
supporting Technical Evaluation Criteria.

Technical Proposal shall comprise of documents mentioned in the following forms:
Form 1: Compliance Sheet for Technical Proposal
Form 2: Particulars of the Bidder
Form 3: Bank Guarantee for Earnest Money Deposit
Form 4: Letter of Proposal
Form 5: Project Citation

Ver 1.1

Page 30 of 43

<!-- page 31 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Form 1: Compliance Sheet for Technical Proposal

The Technical proposal should comprise of the documents mentioned in this compliance sheet along
with these forms. The original documents and these forms need to be scanned and grouped together
into one file for uploading as ‘Technical Proposal’. Bidders to ensure that the scan copies are of good
quality and that the prints generated from these scans are clear / legible.
For Technical Eligibility Requirements
Basic Requirement

Required

Provided

1.

Power of Attorney

Yes / No

2.

Particulars of the
Bidders
Earnest
Money
Deposit
Nature
of
Work
Turnover

Scan Copy of Power of Attorney in the
name of the Authorized signatory
Scan Copy of Form 2

3.
4.

5.

Net Worth

6.

Technical Capability

7.

Consortiums

8.

Legal Entity

9.

Blacklisting

10.

Sample Smart Ration
Cards

Ver 1.1

Scan Copy of EMD
Original submitted to the department
Scan Copy of
Extracts from the published/audited
Balance sheet and Profit & Loss
OR
Certificate from the statutory auditor
Scan Copy of Certificate from the
statutory auditor
Scan Copy of
Completion Certificates from the
client;
OR
Purchase / Work Order + Self
Certificate of Completion (Certified by
the Statutory Auditor); OR
Purchase / Work Order + Phase
Completion Certificate from the client
Scan Copy of
Duly registered Agreement /
Instrument between the firms to form
a consortium
Scan Copy of
-Certificates of incorporation
- Copy of Service Tax and sales Tax
registration
- Acknowledged Income Tax returns
Scan Copy of
Affidavit
Scan Copy of
Self-Certified letter stating that the
samples provided are as per
requirements and that the samples

Reference
Number

&

Page

Yes / No
Yes / No
Yes / No

Yes / No
Yes / No

Yes / No

Yes / No

Yes / No
Yes / No

Page 31 of 43

<!-- page 32 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Basic Requirement

Required

Provided

Reference
Number

&

Page

have been submitted to the
Department

For Technical Evaluation

Specific Requirements

1. Covering Letter for Technical Proposal
2. The Bidder’s per day manufacturing
capacity of plastic cards (with Static
Data)

3. Work experience with any Indian
Government departments / Indian
PSUs / Banks in the last 3 years to
supply and personalize smart / nonsmart cards
4. Total Work experience capacity of
supplying and personalization of smart
/ non-smart cards in the last 3 years
5. Quality Certifications

Ver 1.1

Documents Required

Compliance

Scan copy of
Form 4
Scan copy of
Valid Industrial Certificate, Factory
License and Self-Certificate for
Installed capacity of production
(Certified by a Statutory authority)
Scan copy of
Filled Project Citation (Form 5)

Yes / No

Scan copy of
Purchase / Work Order & completion
Certificate issued by the client
Scan copy of
Copy of Certificates

Yes / No

Reference &
Page
Number

Yes / No

Yes / No

Yes / No

Page 32 of 43

<!-- page 33 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Form 2: Particulars of the Bidder
SI
No.

Information Sought

A

Name and address of the bidding
Company

B

Incorporation status of the firm
(public limited / private limited, etc.)

C

Year of Establishment

D

Date of registration

E

ROC Reference No.

F

Details of company registration

G

Details of registration with
appropriate authorities for service tax

H

Name, Address, email, Phone nos.
and Mobile Number of Contact
Person

Ver 1.1

Details to be Furnished

Page 33 of 43

<!-- page 34 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Form 3: Bank Guarantee for Earnest Money Deposit

To,
Secretary-Cum-Commissioner,
Department of Food & Supplies,
K-Block, Vikas Bhavan,
I.P. Estate, New Delhi-110002
Tel. No. : 011 – 23378759, 011 - 23379263
Whereas <<Name of the bidder>> (hereinafter called 'the Bidder') has submitted the bid for Submission
of RFP #<<RFP Number>> dated<<Date>> for <<Name of the assignment>>(hereinafter called "the Bid")
to the Department of Food & Supplies, Government of NCT of Delhi.
Know all Men by these presents that we <<>> having our office at <<Address>>(hereinafter called "the
Bank") are bound unto the Department of Food & Supplies, Government of NCT of Delhi(hereinafter
called "the Purchaser") in the sum of Rs. <<Amount in figures>>(Rupees<<Amount in words>> only) for
which payment well and truly to be made to the said Purchaser, the Bank binds itself, its successors and
assigns by these presents. Sealed with the Common Seal of the said Bank this <<Date>>
The conditions of this obligation are:
1. If the Bidder having its bid withdrawn during the period of bid validity specified by the Bidder on the
Bid Form; or
2. If the Bidder, having been notified of the acceptance of its bid by the Purchaser during the period of
validity of bid
(a) Withdraws his participation from the bid during the period of validity of bid document; or
(b) Fails or refuses to participate in the subsequent Tender process after having been short
listed;
We undertake to pay to the Purchaser up to the above amount upon receipt of its first written demand,
without the Purchaser having to substantiate its demand, provided that in its demand the Purchaser will
note that the amount claimed by it is due to it owing to the occurrence of one or both of the two
conditions, specifying the occurred condition or conditions.

Ver 1.1

Page 34 of 43

<!-- page 35 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

This guarantee will remain in force up to <<insert date>> and including <<extra time over and above
mandated in the RFP>> from the last date of submission and any demand in respect thereof should
reach the Bank not later than the above date.

NOTHWITHSTANDING ANYTHING CONTAINED HEREIN:
I. Our liability under this Bank Guarantee shall not exceed Rs. <<Amount in figures>> (Rupees
<<Amount in words>> only)
II. This Bank Guarantee shall be valid upto<<insert date>>)
III. It is condition of our liability for payment of the guaranteed amount or any part thereof arising
under this Bank Guarantee that we receive a valid written claim or demand for payment under
this Bank Guarantee on or before <<insert date>>) failing which our liability under the guarantee
will automatically cease.
(Authorized Signatory of the Bank)
Seal:

Date:

Ver 1.1

Page 35 of 43

<!-- page 36 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Form 4: Letter of Technical Proposal

To:
<Location, Date>
Secretary-Cum-Commissioner,
Department of Food & Supplies,
K-Block, Vikas Bhavan,
I.P. Estate, New Delhi-110002
Tel. No. : 011 – 23378759, 011 - 23379263
Subject: Submission of the Technical bid for <Name of the assignment>
Dear Sir/Madam,
We, the undersigned, offer to provide the services to the Department on <Name of the engagement>
with your Request for Proposal dated <insert date> and our Proposal. We are hereby submitting our
Proposal, which includes this Technical bid and the Financial Bid.
We hereby declare that all the information and statements made in this Technical bid are true and
accept that any misinterpretation contained in it may lead to our disqualification.
We undertake, if our Proposal is accepted, to initiate the Implementation services related to the
assignment not later than the date indicated in Fact Sheet.
We agree to abide by all the terms and conditions of the RFP document. We would hold the terms of
our bid valid for < ………….> days.
We understand you are not bound to accept any Proposal you receive.
Yours sincerely,
Authorized Signature [In full and initials]:
Name and Title of Signatory:
Name of Firm:
Address:
Location: _____________________________________Date: ___________________________
_____________________________________________________________________________

Ver 1.1

Page 36 of 43

<!-- page 37 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Form5: Project Citation Format

Relevant project experience
General Information
Name of the project
Client for which the project was executed
Name and contact details of the client
Project Details
Description of the project
Scope of services
Defined Service levels as per contract
Technologies used
Outcomes of the project
Other Details
Total cost of the project
Total cost of the services provided by the respondent
Duration of the project (no. of months, start date,
completion date, current status)
Other Relevant Information
Letter from the client to indicate the successful
completion of the projects
Copy of Purchase / Work Order

Ver 1.1

Page 37 of 43

<!-- page 38 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Appendix II: Financial Proposal Template
Form 6: Financial Proposal

To:
<Location, Date>
Secretary-Cum-Commissioner,
Department of Food & Supplies,
K-Block, Vikas Bhavan,
I.P. Estate, New Delhi-110002
Tel. No. : 011 – 23378759, 011 - 23379263
Subject: Submission of the Financial bid for <Provide Name of the Implementation Assignment>
Dear Sir/Madam,
We, the undersigned, offer to provide the Implementation services for <<Title of
Implementation Services>> in accordance with your Request for Proposal dated <<Date>> and our
Proposal (Technical and Financial Proposals). Our Financial Proposal is for the sum of <<Amount in words
and figures>>per Smart Ration card(the breakup is provided below as required by this RFP). This
amount is inclusive of all charges such as packing, freight and forwarding, transit insurance, local
transportation charges etc.
All applicable taxes are also separately mentioned in the financial proposal.

S. No.

Item

Unit Price
(per card in INR)

Applicable Taxes
(per card in INR)

Supply of Smart Ration Card with
a)

Static information as per
specifications of the RFP (A)
Personalization of Smart Ration

b)
c)

Card (B)
Card Jacket (C)

Total Price (=A+B+C ) per card :
Total Price in figures:
a)

Ver 1.1

The quoted prices shall be inclusive of all charges such as packing, freight and forwarding, transit
insurance, local transportation charges etc.
Page 38 of 43

<!-- page 39 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

b) Bidder’s submitted quote shall be valid throughout the Contract period.

1. PRICE AND VALIDITY


All the prices mentioned in our Tender are in accordance with the terms as specified in the RFP
documents. All the prices and other terms and conditions of this Bid are valid up to the bid
validity period.



We hereby confirm that our prices include all taxes. However, all the taxes are quoted
separately under relevant sections.



We understand that the actual payment would be made as per the existing tax rates during the
time of payment.



We understand that on award of contract, the quoted prices will be valid for the contract
period.

2. UNIT RATES
We have indicated in the relevant forms enclosed, the unit rates for the purpose of on account of
payment as well as for price adjustment in case of any increase to / decrease from the scope of work
under the contract.
3. DEVIATIONS
We declare that all the services shall be performed strictly in accordance with the Tender documents
irrespective of whatever has been stated to the contrary anywhere else in our bid.
Further we agree that additional conditions, if any, found in the Tender documents shall not be given
effect to.
4. TENDER PRICING
We further confirm that the prices stated in our bid are in accordance with your Instruction to Bidders
included in Tender documents.
5. QUALIFYING DATA
We confirm having submitted the information as required by you in your Instruction to Bidders. In
case you require any other further information/documentary proof in this regard before evaluation of
our Tender, we agree to furnish the same in time to your satisfaction.
Ver 1.1

Page 39 of 43

<!-- page 40 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

6. BID PRICE
We declare that our Bid Price is for the entire scope of the work as specified in Section No. 2.8.
7. PERFORMANCE BANK GUARANTEE
We hereby declare that in case the contract is awarded to us, we shall submit the Performance Bank
Guarantee as specified in the Appendix III of this RFP document.
Our Financial Proposal shall be binding upon us subject to the modifications resulting from Contract
negotiations.
We understand you are not bound to accept any Proposal you receive.
We hereby declare that our Tender is made in good faith, without collusion or fraud and the information
contained in the Tender is true and correct to the best of our knowledge and belief.
We understand that our Tender is binding on us and that you are not bound to accept a Tender you
receive.
Thanking you,

We remain,

Yours sincerely,

Authorized Signature:
Name and Title of Signatory:
Name of Firm:
Address:

Ver 1.1

Page 40 of 43

<!-- page 41 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Appendix III: Template for Performance Bank Guarantee
Form7: Performance Bank Guarantee

PERFORMANCE SECURITY:
Secretary-Cum-Commissioner,
Department of Food & Supplies,
K-Block, Vikas Bhavan,
I.P. Estate, New Delhi-110002
Tel. No. : 011 – 23378759, 011 - 23379263
Whereas, <<name of the supplier and address>>(hereinafter called “the bidder”) has undertaken, in
pursuance of contract no. <Insert Contract No.> dated. <Date> to provide Implementation services for
<<name of the assignment>> to Department of Food & Supplies, Government of NCT of Delhi
(hereinafter called “the beneficiary”)
And whereas it has been stipulated by bidder in the said contract that the bidder shall furnish you with
a bank guarantee by a recognized bank for the sum specified therein as security for compliance with its
obligations in accordance with the contract;
And whereas we, <Name of Bank> a banking company incorporated and having its head /registered
office at <Address of Registered Office> and having one of its office at <Address of Local Office>have
agreed to give the supplier such a bank guarantee.
Now, therefore, we hereby affirm that we are guarantors and responsible to you, on behalf of the
bidder, up to a total of Rs.<Insert Value>(Rupees <Insert Value in Words> only) and we undertake to
pay you, upon your first written demand declaring the supplier to be in default under the contract and
without cavil or argument, any sum or sums within the limits of Rs.<Insert Value>(Rupees<Insert Value
in Words> only) as aforesaid, without your needing to prove or to show grounds or reasons for your
demand or the sum specified therein.
We hereby waive the necessity of your demanding the said debt from the bidder before presenting us
with the demand.
We further agree that no change or addition to or other modification of the terms of the contract to be
performed there under or of any of the contract documents which may be made between you and the
Ver 1.1

Page 41 of 43

<!-- page 42 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Bidder shall in any way release us from any liability under this guarantee and we hereby waive notice of
any such change, addition or modification.
This Guarantee shall be valid until <<Insert Date>>)
Notwithstanding anything contained herein:
I. Our liability under this bank guarantee shall not exceed Rs.<Insert Value>(Rupees <Insert Value in
Words> only).
II. This bank guarantee shall be valid up to <Insert Expiry Date>)
III. It is condition of our liability for payment of the guaranteed amount or any part thereof arising
under this bank guarantee that we receive a valid written claim or demand for payment under this
bank guarantee on or before <Insert Expiry Date>) failing which our liability under the guarantee
will automatically cease.

Ver 1.1

Page 42 of 43

<!-- page 43 -->

Delhi Food & Supplies - RFP for Preparation of Smart Ration Cards

Appendix IV: Template for Contract Agreement
The contract agreement is a separate document that can be downloaded as mentioned in the factsheet.

Ver 1.1

Page 43 of 43
