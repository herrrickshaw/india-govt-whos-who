---
doc_id: "7dd4a40a8ab45add"
source_url: "https://dlwb.delhi.gov.in/sites/default/files/dlwb/tender/docscanner_22-apr-2026_4-15_pm.pdf"
ministry: "Delhi Labour Welfare Board"
title: "Tender Document"
date: ""
pages: 5
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "359234405b3dce67"
---

<!-- page 1 -->

® GOVERNMENT OF NATIONAL CAPITAL TERRITORY OF DELHI
DELHI LABOUR WELFARE BOARD
IST FLOOR, EMPLOYMENT EXCHANGE BUILDING, KIRBY PLACE
DELHI CANTT, NEW DELHI-I00I0
Email ID:dlwb-we@delhi.gov.in
a
Tender Notice
F.I2(I 8)/DLWB/CA/2009/ °25 pate:92o4/or6 o4/) orb
Sub: Contract for Audit of Financial Statements, filing of Statutory returns of Annual
Return of Income Tax/Monthly Returns applicable under Goods and Services
Tax/Quarterly returns of TDS in respect of Delhi Labour Welfare Board, GNCT
of Delhi.
Delhi Labour Welfare Board, Govt. of NCT of Delhi intends to engage an agency for Audit of
its Financial Statements for the Financial year 20I7-8 to 2024-25 and onwards, filing of
statutory returns of Income Tax/GST/TDS ete. for FY 2026-27 and onwards and correction of
returns (if any) in respect of Delhi Labour Welfare Board, GNCT of Delhi. The Scope of work
is as follows: -
Ol Auditing of the Financial Statements for period FY 20I7-] 8 to FY 2024-25 &
onwards.
Filing of Annual Income Tax Returns, FY 20I7-8 to FY 2024-25 & onwards.
Filing of Quarterly TDS Returns for Salary and Non-Salary deductees.
| | Filing of Monthly Returns for Goods and Services Tax for Delhi GSTIN
05 Filing correction returns in case of default notices issued by Income Tax
Department for TDS returns filed.
ye

<!-- page 2 -->

e Last Date & Time for Submission: - 2" May 2026 at 03:00 PM.
Date/Time for opening of bids: - |3" May 2026 on 02:00 PM.
The rates shall be quoted in the following format: -
|
ol Auditing of the Financial Statements for period Rates per annum plus taxes,
FY 20I7-I8 to FY 2024-25 & onwards. if any
02 Filing of Annual Income Tax Returns, FY 20I7- | Rates per annum plus taxes,
I8 to FY 2024-25 & onwards. if any
03 Filing of Quarterly TDS Returns for Salary and Rate per correction return
Non-Salary deductees. including taxes, if any
04 Filing of Monthly Returns for Goods and Rate per correction return
Services Tax for Delhi GSTIN including taxes, if any
05 Filing correction returns in case of default notices | Rates per Reply and hearing
issued by Income Tax Department for TDS plus taxes, if any
returns filed.
At any time prior to the deadline for submission of bids, the Competent Authority may, for any
reason, whether on its own initiative or in response to a clarification requested by a prospective
bidder, modify the bid by amendment. Such amendments shall form an integral part of the bid,
and it shall amount to an amendment of the relevant clause of the Quotation.
After the acceptance of the bid the successful bidder has to undertake the job specified in the
quotations under the overall supervision and guidance of the Competent Authority of Delhi
Labour Welfare Board, GNCTD.
Since the job to be awarded involves adherence to the time limits prescribed under the Income-
tax Act, 96/2025 and the Rules framed thereunder, the successful bidder shall make
reasonable and diligent efforts to adhere to such time limits and complete the work assigned
within the prescribed statutory timelines.
Ns" bot पर
wr ye

<!-- page 3 -->

ie
In the event of any delay or default in filing of returns or adherence to statutory timelines, the
same shall be promptly brought to the notice of the Competent Authority, along with reasons
and corrective measures proposed.
However, persistent or material non-performance attributable solely to the bidder may be dealt
with in accordance with the relevant termination provisions contained in the Terms and
Conditions annexed to the quotation.
The bids will be opened in the presence of the representatives of the bidders, if any. Requests
for postponement will not be entertained. The Competent Authority reserves the right to
accept/reject any or all bids either in part or in full without assigning any reason thereof.

The bids shall be sent in sealed cover super scribed “Bid for the Scope of work” by
Post/Speed Post/Registered Post or dropped in the tender drop box at the C/o Welfare
Commissioner, Delhi Labour Welfare Board, | st Floor, Employment Exchange Building, Kirby
Place, Delhi Cantt, Delhi-00 0. The bids shall be addressed to the “Welfare Commissioner,
Delhi Labour Welfare Board, I*t Floor, Employment Exchange Building, Kirby Place, Delhi
Cantt, Delhi-000.

The detailed Terms & Conditions are enclosed herewith. yi’

(26
कफ
Welfare Commissioner (DLWB)
S »”
Ww

<!-- page 4 -->

¢ TERMS & CONDITIONS
l. All data relating to Income Tax (quarterly/annual return) shall be uploaded by the firm
carefully and on time. Soft and hard copies of the data sheet shall be provided to the
Delhi Labour Welfare Board in time.
2. Timely filing of e-TDS return with the Income Tax Department by the firm and
providing the soft and hard copies to the Delhi Labour Welfare Board, after filing the
| returns.
3. All the data and matters relating to TDS/e-TDS during the period of contract shall be
carefully handled by the firm.
4. No advance payment or part payment would be made. The payments will be made only
after filing often necessary returns and submission of proof to the Competent Authority.
The details of the bank account including NEFT shall be provided for the purpose of
processing the final bill.

5. The offer should be valid for at least 5 days from the date of opening of the bid.

6. Ifrequired, Delhi Labour Welfare Board may ask any bidder(s) to give any additional
documents(s)/proof to prove its competence in the field.

7. The bidder should have valid Pan card and minimum three years’ experience of having
successfully executed similar work in the Government Department/PSU etc. Self-
attested copies of work orders and Pan card be also enclosed.

8. Contract Period: The offered rates should be valid for a period of one year and would
be extendable for further two years on the same terms & conditions.

9. The rates shall be quoted strictly as per the spec ifications mentioned in the quotation/bid
notice. The rates for the work/items shall be quoted and the bids for any one work/item
only will be summarily rejected.

0. The applicable rates of taxes and duties, wherever chargeable shall be clearly indicated.

ll. The work would be completed within the time schedule specified by the income Tax
Authority.

2. The Acceptance of the bid would rest with the Competent Authority, who does not bind
itself to accept the lowest quotation and reserves the right to reject or partially accept

any or all the quotations received without assigning any reason.

3. Quotations must be clearly written or typed. Any interpolation or over writing will be
summarily rejected.

0 Loc ve
cor DY ८
2 ८

<!-- page 5 -->

® 4. Termination for default. The Competent Authority may, without prejudice to any other
remedy for breach of contract, by written notice of default sent to the successful bidder,
terminate the Contract in whole or part:

i, If the successful bidder fails to complete all or any of the work within the period
specified by the Income Tax Authority or within any extension thereof granted
by the Competent Authority: or

ii. If the successful bidder fails to perform any other obligations(s) under the
contract.

iii. If the successful bidder, in the judgment of the Competent Authority has
engaged in corrupt or fraudulent practices in competing for or in executing the
Contract.

5. Corrupt and fraudulent practices: The Bidders/Contractors under this contract shall
observe the highest standard of ethics during the procurement and execution of this
contract. They shall not indulge in any ‘Corrupt practice’ of offering, giving, receiving
or soliciting anything of value to influence the action ofa public official in the execution
of the contract. They shall not adopt any ‘Fraudulent practice’ like misrepresentation
of any fact(s) in order to influence the tender process or the execution of the contract to
the detriment of the Department, which includes any collusive practice among the
Bidders (prior to or after bid submission) so as to deprive the Department of the benefits
of free and open competition.

6. The Competent Authority would reject a proposal for award of work if it is found that
the Bidder recommended for award of the contract has engaged in corrupt or fraudulent
practices in competing for the contract in question.

7. Dispute, if any, will be subject to jurisdiction of NCT of Delhi.

Esa Ww
Wl
2
Welfare Commissioner (DLWB)
oe
ay
