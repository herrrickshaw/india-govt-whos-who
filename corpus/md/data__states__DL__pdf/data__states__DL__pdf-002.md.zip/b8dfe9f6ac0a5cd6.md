---
doc_id: "b8dfe9f6ac0a5cd6"
source_url: "https://forest.delhi.gov.in/sites/default/files/forest.delhi.gov.in/tender/b_0001.pdf"
ministry: "Forest Department, Delhi"
title: "Tender Document"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cba9444a4dc52ceb"
---

<!-- page 1 -->

\

ej

al
-JP

FAWL-K,,’1/2023-Tree Cell-FOREST AND WILDLIFE DEPARTMENT

1/78914/2023

GOW. OF NCT OF DELHI
DEPARTMENT OF FORESTS & WILDLIFE
OFFICE OF THE PRINCIPAL CHIEF CONSERVATOR OF FORESTS
A-BLOCK, 2ND FLOOR, VIKAS BHAWAN, IP ESTATE, NEW DELHI-110002
FAWL.K/1/2023-Tree Cell-FOREST AND WILDLIFE DEPARTMENT/

Dated C,q –g .- aS

32-\r- Il

SHORT TERM NOTICE INVITING QOUTATIONS
Notice inviting quotations (NIQ) is hereby issued for inviting quotationsfor hiring

of 19 Nos. of Laptops for office use in the Department of Forests & Wildlife,
Govt. of NCT of Delhi. The details of Work are as under:

Qty.ISpecification

of 19
Nos. of Laptop:
Hiring

for a period o
03 months

llth Generation Intel® Core’"
i3 processor.
Windows II Home.
39.6 cm (15.6) diagonal, FHD
(1920 x 1080)
Intel® UHD Graphics.
8 GB DDR4-3200 MHz RAM (1
8 GB), 512 SSD Hard Drivb

[Rate

quoted b
the
vendo
all
(Including
charges/taxes)

(*rate should be in the format” Rate/cost of
The quotation and documents should be send in sealed cover marked as "hiring of
19 Laptops"'' in Department of Forest’s and Wildlife, attached with the office Hon’ble
Minister (E&F), Govt. of NCT of Delhi. I n /lb.e quotation should reach in this office latest
by 02:00 PM on or before dated 3..1.$.J.Xo7J. (Next working day in case of Govt.
Holiday) and the same will be opened on the same day at 02:30 PM by the Purchase
Committee. The rate should be quoted and GST should be indicate separately as per the
prevailing GST Laws. Quotation received after stipulated date and time will not be
accepted/entertained and summarily will be rejected, in case any dispute, the decision of
the PCCF/HOD, A-Block, 2nd Floor, Vikas Bhawan, IP Estate, New Delhi-110002 should be
final and binding.

TERMS & CONDITIONS OF THE NIa
1.
Submission of quotation shall amount to bidder’s acceptance of the terms
and conditions of the tender by the bidder.
2.
Mode of payment would be subject to' satisfactory completion of
work/supply and its verification.
3.
Bidder shall quote the rates against this NIQ on a 'single responsibility’
basis (“Rate/Cost of item/work+ GST as applicable") so that the quotation price
covers contractor’ all obligations and liabilities. The rates and prices quoted by the
Bidder shall be inclusive of all Charges/Taxes. The rate quoted shall be responsive
and the same should be inclusive of all statutory obligations.
4.
The bidder should be from NCR and should ,be registered with/Trade &
Taxes Department, Govt. of NCT of Delhi and should quote their GST Registration
No, allotted by the Department of Trade & Taxes, Govt. of NCT of Delhi, and PAN
No. allotted by the income Tax Department, Govt. of India.
5.
The Dy. Conservator of Forests (HQ) reserves the right to accept and reject
any or cancel any or all the tenders/quotations without assigning any reasons

<!-- page 2 -->

\

gT

FAWL-K,'1,'’2023-Tree Cell-FOREST AND WILDLIFE DEPARTMENT
1/78914,'2023

therefore

6.

The rates quoted by the firm/agency shall remain valid for the entire period

of current Financial Year i.e. upto 31.03.2024 for the subject work and the

Department shall not be responsible for payment of any extra on account of
escalation of costs during the said period.
7.
The department shall not be responsible for payment of any compensation
on account of any loss caused to the bidder/tender/quotation due to natural
calamities or other supervening impossibilities.
8.
The firm/agency abide by the provisions made under the labour laws/GST
and other relevant Statutes as applicable in execution of the work and shall be
responsible for making good/payment of compensation, if any, to any workman or
material during execution of the contract.
9.
In case of any dispute arising out of the execution of the term & condition
of this short term quotation or part thereof, the decision of the DCF (HQ), Govt. of
NCT of Delhi shall be final and binding on both the parties. In the event of the
disputes still remaining unresolved, the appeal shall rest with the PCCF/HOD, Dept.
of Forests & Wildlife, GNCTD of Delhi whose decision shall be final and binding on
both the parties.
10.
The bidder/successful firm shall be liable to upkeep and maintenance of
Laptops during the currency of contract/work.
11. All disputes arising out of the execution of the agreement shall K"\bject
to the jurisdiction of the Court at Delhi.
( J

(Amit Anand)
DY. CONSERVATOR OF FOREST (P&M)
FAWL-K/1,/20:3-Tree Cell-FOREST AND WILDLIFE DEPARTMENT/

Dated OCI _ CB _ Lq>

II-lg

- \a\

Copy to:

L,_ Ihe DCF (HQ)-Chairman-Purchase Committee, Department of Forests & Wildlife,
2.' Sr. Accounts Officer, Department of Forests & Wildlife, GNCTD.

3.’
The Section Officer (Store)/ Store In-Charge, Departm Rt of Forests & Wildlif6-,
GNCTD.
4. Programmer, Department of Forests & Wildlife, GNCTD with request to upload it
on the Forest website in Public Interest.
5

HQ-Notice Board for the notice of firms/agencies/workshops interested.

(Amit Anand)
DY. CONSERVATOR OF FOREST (P&M)
