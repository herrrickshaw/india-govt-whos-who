---
doc_id: "c16a2ffaf7a90ce2"
source_url: "https://dlwb.delhi.gov.in/sites/default/files/dlwb/circulars-orders/dsidc_icsil_1.pdf"
ministry: "Delhi Labour Welfare Board"
title: "Download"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "37a23eb48a3f11dd"
---

<!-- page 1 -->

OFFICE OF THE COMMISSIONER OF INDUSTRIES
GOVERNMENT OF NCT OF DELHI
UDYOG SADAN, 419, FIE, PATPARGANJ INDUSTRIAL AREA: DELHI.
Dated: 08th December, 2015

No. FC.1/DCI/2015/4155 to 4164
CIRCULAR
Subject:-

Empanelment of M/s ICSIL for hiring of contractual manpower in
different Departments of Govt. of NCT of Delhi

This will be applicable to: ­

•

All Governmen t Department under Government of NCT of Delhi

•

All Autonomous Bodies / Local Bodies under Government of NCT of Delhi

•

All PSUs under Government of NCT of Delhi

The Government of National Capital Territory of Delhi h as considered the proposal of
Ernpanelment of M/S Intelli gent Communication Systems India Ltd . (ICSIL) for hiring of all
type of contractual manpower for various Departments of Govt. of NCT and approved vide
Cabinet Decision No . 2215 dated 29.09.2015 that
i)

The ICSIL should be continued as empanelled agency at the same rate (i.e 10% )
as service charges of ICSIL for Govt. of NCT of Delhi to provide all types of
contractual manpower at various levels to the Departments of Govt. of NCT of
Delhi as per their r equirements as a mode of outsourcing.

ii)

F'urthe1' <:m advance of six (6) months against Bank Guarantee should be paid to
ICSIL for timely payment to the contractual m.:mpower.

Guidelines for providing all type of Contractual Manpower

As per approval Departments of Govt. of NCT of Delh i are allowed to outsource
contractu al manpower from M/s ICSIL directly without in viting Tender

2. ICSIL ensures supply of quality of manpower to various departments.
3. ICSIL will provide manpower purely on conrractual basis.
4 . ICSIL will provide the re quired mcmpower al the location in Delhi/New Delhi and

NCR as specified by the Department concerned.

-

5 . ICSIL will provide the manpower that possess the prescribed minimum qualifi cation,
knowledge and skill as desired by the Department acquire outsource manpower.
6 . ICSIL may change/ replace / transfer any outsource contractual ill '>Tpower
consultation with Department, if feasible, wherever necessitate.

tn

7. ICSIL shall always keep the credentials of the deployed outsource manpower with

them and fqrnished the same details/inform a tion whenever demanded by the
De partment.
lof2

<!-- page 2 -->

'
8. Attendance of the outsource manpower shall be provided by the Department to lCSIL
by the 2 11 c1 day of the following month.

9. ICSIL will ensure that the payment of Wages/Salary be release to the outsource
manpower latest by 7 1h of following month subject to release of funds by the
Departrnenl in advance .
10.Department will made payment of the Salary / Wages of the outsource manpower
alongwilh service charges of ICSIL, PF, ESI, Service Tax, etc. or any other Govt.
levies applicable, based on the attendance certificate to ICSIL every month.
11. ICSIL will provide the outsource manpower on the basis of rates of wages determine
in consultation with Indenting Department concerned keeping in view the formula
devised by the Finance Department, Govt. of NCT of Delhi vide Office Memorandum
dated 30 - 12-2011 i.e minimum of the Pay Band+ Grade Pay+ DA of the respective
post. And, in any case shall not be less than the rates of wages circulated time to
time by the Labour Department under the Minimum Wages Act 1948 in the Govt. of
NCT of Delhi .
12. Wherever 11ature oU_ob demand high skilled professional manpower with or without
experig_!}_Ce ar~st Superviso1y manpower, the rates of wages will be determine in
consult§.!i.Qn \.~iJJ;:i.__the Indenting Department conce!:ned on the basis of prey_gi)ing
rates for rhe__similar j ob in different department. Further, 5% annual increase v.ri.11 be
given to ; 1]] Profess ionals which will affect the ICSIL charges, PF , ESI and Service Tax
~]Jich ~_iJL_l1avc Lo be borne by Department.
13.All statutory obli g;1ti ons viz PF/ ESI including filing of returns etc. are being fulfilled
by ICSIL
14.ICSIL ensu rec> p;.1yrn ent of requisite contractual runount as provided by Departments
through E:~-;~; (Llcc Lronic Clearing System) . No undue deductions shall be made by
made by lCSfL at the time of disbursal of contractual mnount to the manpower.

~J(A.K. Madan)
No. FC.l/DCI/2 0 15/-1-155 to 4164

Dy. Commissioner Industries (DSIIDC)
Ph:22157017
comind(ii)nic. in
Dated: Q8th December, 2015

Copy to:

-

1 All Pr. S ccrc:l<-:ric::> /Se cretaries / HOD Govt . of NCT of Delhi
2 . Chairman iv1D's I of PSU 's Govt . of NCT of Delhi

3.7_

J.

1_1_~ead_ o f·· L n.c:1! Fndies Auto~-o-·mous Bodies / Corp~rations ?ovt. of NCT of Delhi
,fl"." All Secretaries to U1c J:ion ble Mimsters, Delhi Secretariat, GNCI D
5. OS D to Chief Sccrclary, Delhi Secretariat, GNCTD
6. PS to Pr . ~)c crt tary lo Chief Minister, Delhi Secretariat, GNCTD
7. SIO (NJC ) , D c ilti Se cretariat, GNTCD
8. PS to SccrcLary to l io n'ble L.G., Raj Niwas, GNCTD
9. Man agi11,~ Dir,.<:, ,:. ICS IL
10 .Gu ard File I Dc:i 1i c;ovt. Website
