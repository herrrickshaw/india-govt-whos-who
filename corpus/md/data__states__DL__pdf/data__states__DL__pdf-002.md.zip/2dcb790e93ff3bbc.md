---
doc_id: "2dcb790e93ff3bbc"
source_url: "https://publicity.delhi.gov.in/sites/default/files/publicity/press_releases/letter_and_policy_memo_for_cm_delhi_final_letterhead.pdf"
ministry: "Directorate of Information & Publicity, Delhi"
title: "Download"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "870b28455a2e57c5"
---

<!-- page 1 -->

Honourable Chief Minister Arvind Kejriwal
State of Delhi
Delhi
India
25 January, 2017
Honourable Chief Minister,
I am writing today in my capacity as Chair of The Elders, an organisation of independent global
leaders founded by Nelson Mandela. The Elders offer their collective experience to promote
peace, justice and human rights worldwide.
The Elders are keen to raise with you an issue of great international importance, which we
understand is also a top priority for your government: Universal Health Coverage (UHC). As you
may know, UHC is one of the key targets within the new health Sustainable Development Goal. It
is achieved when everybody receives the healthcare they need without suffering financial
hardship.
Last May, The Elders launched a new initiative to encourage countries to reach UHC as we are
convinced that providing universal healthcare, free at the point of delivery, is one of the most
important drivers of development. We are aware that your administration has implemented a
series of health reforms consistent with the UHC goal. In particular, you have scaled up the
provision of universal free health services, most notably in providing free primary healthcare
services through your new Mohalla Clinics. We understand that this initiative is proving very
successful and we commend you on this impressive achievement.
In the hope that this may be of assistance, we respectfully attach here a memorandum reflecting
on your health reforms to date and suggesting some areas where you may wish to develop your
programme. Were you to implement these policies, we believe you could further extend health
coverage in Delhi and provide further important lessons for other Indian states embarking on their
UHC journeys.
From experience elsewhere, including in some of our own countries, the Elders believe that a bold
move to advance UHC could bring tremendous health and economic benefits to the people of
India. It would also, of course, be likely to prove extremely popular.

<!-- page 2 -->

In case you require further information or wish to discuss the matter with The Elders, we would be
delighted to hear from you.
Please accept, Honourable Chief Minister, the assurances of my highest consideration and esteem.

Kofi Annan
Chair, The Elders

<!-- page 3 -->

Universal Health Coverage (UHC) Policy Memorandum
From The Elders to the Honourable Chief Minister of Delhi, Arvind Kejriwal
Delhi State Government Pioneering UHC Reforms in India
January 2017
1. India has made slow progress towards UHC but some states (including Delhi) are implementing
impressive health reforms
India has made good progress in improving some key health indicators in recent years and has achieved
some significant successes, particularly in tackling infectious diseases, for example in eradicating polio.
However, the country has made much slower progress in achieving universal health coverage (UHC)
whereby everybody receives the quality health services they need without suffering financial hardship.
In fact India has the largest population in the world without effective health coverage around one billion Indians are at risk of financial hardship due to healthcare costs and in 2011 it was
estimated that 60 million people were plunged below the poverty line due to their health expenditures. 1
Facing high financial barriers to healthcare, many people are under-consuming essential health services,
which represents a threat to their health and well-being. This also poses a threat to national health security
due to the increased risk of the spread of infectious diseases, for example tuberculosis, including drug
resistant TB.
The root cause of India’s relatively low levels of health coverage (both in terms of service coverage and
financial protection) remains its chronically low levels of public financing for health. The graph below shows
that public health expenditure in 2014 accounted for around 1.4% of GDP or around $21 per capita. This
level of public health spending is one of the lowest rates in Asia. In the absence of adequate public
financing, the Indian people frequently have to finance services directly themselves, mostly in the form of
out-of-pocket payments, which account for 62% of total health expenditure. This is more than treble the
20% maximum level recommended by the World Health Organisation (WHO).

As per the Indian Constitution, the primary responsibility for health service provision and health financing
lies with the county’s 29 state governments, giving them scope to plan and implement their own health
reform programmes.
1 http://www.thelancet.com/journals/lancet/article/PIIS0140-6736(12)61489-5/fulltext

<!-- page 4 -->

The state government of Delhi has been implementing ambitious health reforms in the capital since 2015.
These reforms have involved providing universal access to free publicly financed health services across the
state, including specialist services at tertiary level facilities and free services throughout the city’s hospitals
and polyclinics – including an expanded package of free medicines and diagnostic services.
But it is perhaps the Delhi state government’s primary healthcare (PHC) reforms that have been most
impressive. In just over a year, the government has opened 106 Mohalla clinics in poor areas of the city,
which are staffed by a doctor and provide a wide range of free diagnostic tests and medicines – totally free
of charge for anybody choosing to access them. As a recent article in the Lancet shows, these clinics have
treated over 1.5 million people in just over seven months. 2
2. Delhi’s Mohalla Clinics may prove to be a good model to scale up UHC in India
The utilisation of the Mohalla Clinics represents a large increase in the consumption of cost-effective
primary healthcare by the population without people incurring financial costs. This development therefore
appears to be a significant step towards increasing effective health coverage in Delhi. In addition, this
approach, focussing on universal coverage of free publicly financed PHC services, closely matches the UHC
strategy recommended by India’s High Level Expert Group on UHC which reported to the previous federal
government in 2011. 3 It is also consistent with the UHC policy position advocated by the Elders. 4
Many key health stakeholders in India are therefore very excited about the Mohalla Clinic programme and
its potential to become a model for scaling up coverage in other states. To confirm whether this would be
an appropriate strategy, it will be important to undertake an evaluation of the programme and document
key lessons from its implementation. This would help inform ongoing reforms in Delhi and help other states
plan their own PHC-driven UHC strategies. In terms of specific next steps the following policy actions may
be advisable:
i.
Undertake a formal evaluation of the Mohalla Clinics programme
The Delhi state government should commission a thorough independent evaluation of the Mohalla Clinic
programme, using UHC-related performance measures of service coverage and financial protection. As well
as looking at the effectiveness of the programme, this research could investigate the efficiency of this
strategy and whether these services are equitable in meeting the needs of the poor and vulnerable in Delhi.
Given the importance of documenting and sharing lessons from this programme to inform other UHC
reforms in India, it is recommended that this research be undertaken as a matter of urgency.
ii.
Improve management information systems in the Mohalla Clinics programme
Understandably, the immediate priority of the state government has been to rapidly increase the supply of
services to the population with an emphasis on inputs, such as health facilities, frontline health staff,
medicines and diagnostic services. However, it would appear that information systems to computerise
patient records, manage the services and monitor performance have not kept pace with these
developments.
Therefore to improve the efficient running of the programme, it is recommended that the government
invest in cost-effective information systems that will capture vital patient data, as well as facility based
data. Collating this information across the city will also be important in monitoring the performance of
whole programme and informing the evaluation proposed above.
iii.
Scale up the provision of preventive services and community based services
To date, the major emphasis of the Mohalla Clinics has been to attract patients by promoting the
availability of free curative services with a focus on diagnostic tests and curative treatments – in particular
medicines. With so much health seeking behaviour being driven by the availability of affordable medicines
and tests, this has been a sensible strategy to increase demand.
2 http://www.thelancet.com/pdfs/journals/lancet/PIIS0140-6736(16)32513-2.pdf
3 http://planningcommission.nic.in/reports/genrep/rep_uhc0812.pdf

4 http://theelders.org/sites/default/files/final-uhc-position-paper-for-web.pdf

<!-- page 5 -->

However, PHC is more than treating illnesses - it should also involve services to prevent people falling sick.
Therefore as the Delhi government plans to scale up the Mohalla Clinic programme, it may wish to give
greater attention to preventive services in the benefit package. This might include providing outreach
services using community health workers trained in health promotion activities who could also identify
vulnerable people needing medical services at the Mohalla Clinics and at higher level health facilities.
3. The benefits of scaling up the Mohalla Clinic Programme
Given the initial encouraging results of the Mohalla Clinics and the fact that this model is built on sound
scientific evidence of the merits of cost-effective PHC services, there is a very good case for scaling up these
services across Delhi and other Indian states. It is encouraging that this latter process is already underway,
with a number of state governments already visiting Delhi to research the implementation of these
services.
The potential benefits of scaling up the provision of PHC services from Mohalla Clinics in Delhi and indeed
in other states include:
Health Benefits
• Achieving full population coverage of a package of quality services (focussed on PHC services) would
improve key health outcomes, such as increasing life expectancy and reducing child and maternal
mortality rates.
• There would also be a reduction in health inequalities across different population groups, for example
between the rich and the poor and between different areas of the city.
• Accelerating progress towards universal coverage of PHC services would be the best way to strengthen
health security in Delhi. Ensuring that all people utilize health services to prevent and treat illness is the
best way to protect the population against infectious diseases such as TB, HIV, Malaria, Ebola, SARS,
MERS and new strains of influenza.
• Guaranteeing the entire population access to free essential medicines would reduce risks associated
with antimicrobial resistance (a global health priority debated at last year’s United Nations General
Assembly).
Economic Benefits
• Accelerating UHC reforms would deliver significant economic returns to Delhi by stimulating economic
growth. A Lancet Commission chaired by the Harvard economist Larry Summers estimated that that the
economic returns to investing in health will be at least 10 times the outlay of public spending. These
findings have been endorsed by 267 of the world’s leading economists in the Economists’ Declaration
on UHC. 5
• By providing financial protection against healthcare costs, UHC would reduce the high incidence of
people in Delhi being plunged into poverty due to ill health
• Implementing rapid, popular UHC reforms could assist the Government of Delhi to implement other
important economic policies that may prove less popular with the electorate – for example, in reducing
subsidies on other goods and services or increasing taxes.
Political Benefits
• UHC reforms have consistently been shown to increase the popularity of political leaders that have
extended publicly financed healthcare to their people. 6 These leaders have recognized that effective
health coverage is a fundamental need for everyone. People appreciate accessing health services they
could not previously afford; they also value the security of not being exposed to financial risk when
becoming sick. These benefits can be delivered to the population relatively quickly and certainly within
a leader’s term of office.
• By using public health financing mechanisms to reduce health and economic inequalities, UHC reforms
would help build social solidarity amongst the population and this also helps build trust in the state.
5 http://www.thelancet.com/journals/lancet/article/PIIS0140-6736(15)00242-1/abstract

6 https://www.chathamhouse.org/expert/comment/universal-health-coverage-potent-vote-winner
