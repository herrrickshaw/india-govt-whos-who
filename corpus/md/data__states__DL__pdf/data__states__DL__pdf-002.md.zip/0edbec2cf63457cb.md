---
doc_id: "0edbec2cf63457cb"
source_url: "https://environment.delhi.gov.in/sites/default/files/environment/tender/nit_7_procurement_of_plants_of_bamboo_and_nursery_inputs.pdf"
ministry: "Enviornment Department, Delhi"
title: "Tender Document"
date: ""
pages: 7
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "b807637259451f79"
---

<!-- page 1 -->

DELHI PARKS AND GARDENS SOCIETY
Department of Environment, Govt. of NCT of Delhi
6% Level, C-Wing, Delhi Secretariat, IP Estate, New Delhi-0002
No.F. 4(06)/DPGS/Nursery/2024-25/ U0? Dated: 63 63 ॥ 2-७2.57
NOTICE INVITING TENDER
Chief Executive Officer, Delhi Parks and Gardens Society invites item rate e- tenders
of the following NIT on two bids system from approved and eligible contractors/firms registered
with CPWD, PWD, MES, Railways dealing with Horticulture works.:-
S.No. | NIT No. Name of work Estimated EMD Duration
cost (in Rs.) | amount
(in Rs.)
4. O7/DPGS / e-| Procurement of plants of | 44,58,525/- 90,000/- (5 days
tender / 2024-25 | Bamboo vulgaris species,
good earth, organic and
inorganic manure,
Insecticide etc. at DPGS
Nursery
4. Last date & time of submission of tenders: 24.03.2025 (2.00 PM)
2. Date & Time of opening of Technical bids. : 24.03.2025 (3.00 PM)
3. The financial bids will be opened after finalization of technical bids.
All are requested to make it convenient to attend the meeting. a 0
a
Chief Executive Officer
Delhi Parks and Gardens Society
In original, EMD in the form of F.D.R. only, should be deposited in the office of Chief
Executive Officer Delhi Parks and Gardens Society, Environment Department, GNCTD, 6t,
Level, C-Wing, Delhi Secretariat, IP Estate, New Delhi 70002 latest by 24.03.2025 upto .00
AM.
The general terms & conditions and other details can be had from the website http :
/govtprocurement.delhi.gov.in and http: // dpgs.delhigovt.nic.in.
Chief Executive Officer
Delhi Parks & Gardens Society

<!-- page 2 -->

DELHI PARKS AND GARDENS SOCIETY
Department of Environment, Govt. of NCT of Delhi
6" Level, C-Wing, Delhi Secretariat, IP Estate, New Delhi-0002
General Terms & General Terms & Conditions
szeneral terms & Conditions

4. The Item Rate e-tenders are invites on two bids system from approved and eligible

contractors/firms registered with CPWD, PWD, MES, and Railways dealing with
Horticulture works.

The enlistment order of the contractor should be valid on the date of submission of e-
tender (certificate thereof be uploaded).

The work is estimated to Rs. 44, 58,525- (Rupees Forty four lakhs fifty eight thousand
five hundred twenty five only).

This estimate, however, is given merely as rough guide.

2. Intending tenderer is eligible to submit the offer provided he has definite proof from the
appropriate authority ( Issued by the officer not below the rank of Class-II gazetted in
Government Departments only ) which shall be to the satisfaction of the competent
authority, having Satisfactorily completed similar works of magnitude having three
similar completed works each of value not less than Rs. 20 lakhs or two similar
completed works each of value not less than Rs.27 lakhs or one similar completed
work of value not less than Rs.36 lakhs in last 7 years ending last day of the month
Previous to the one in which the tenders are invited (certificate thereof be uploaded).

3. Similar nature of works mean only supply of plant saplings and other nursery
inputs only.

4. The tenderer would undertake and confirm that eligible similar work (s) has/have not
been got executed through another contractor on “back to back basis”. The
undertaking should be on non-judicial e-stamp paper of Rs. 00/- ( duly notarized) .
Further that, if such a violation comes to the notice of the Department, then the
tenderer shall be debarred for tendering in future also, if such violation comes to the
notice of the Department before start of work, C.E.O., DPGS shall be free to forfeit the
entire amount of Earnest Money/Performance guarantee deposited. .

5. EMD (Earnest Money Deposit) of Rs. 90,000/- (Rupees Ninety thousand) only as
instrument of EMD in the form of Fixed Deposit Receipt (FDR) only of a scheduled
Bank, pledged in favour of “Chief Executive Officer, Delhi Parks and Gardens
Society” payable at New Delhi” shall be scanned and uploaded to the e-tendering
website within the period of tender submission and original should be deposited in the
Office of C.E.O., DPGS latest by 24.03.2025 up to .00 AM.

6. No interest is payable on this Bid Security.

7. The following documents should to be uploaded by the tenderer:-
|. Scanned copy of execution of similar nature of works, issued by Government

Departments only.
ll. Scanned copy of PAN card.
lll. Scanned copy of GST No with up to date filed return.
IV. Scanned copy of ITR filed of last three financial years ( 202-22, 2022-23 and 2023-
24).

V. Scanned copy of valid enlistment order.

VI. Scanned copy of non-execution of works through another contractor on “back to

back basis” on non-judicial stamp paper of Rs.i00/-( duly Notarized)

VII. Scanned copy of instrument of EMD.

<!-- page 3 -->

VIll. Scanned copy of undertaking that the seedlings to be supplied will be true to the
variety and if found any discrepancy in future, | will be held responsible. The
undertaking should be on non-judicial stamp paper of Rs. 00/-.(duly Notarized).

IX. Scanned copy of valid Insecticide License issued by Licensing Authority of State
Government.
8. The earnest money shall be forfeited in following conditions:-
|. if any stage, any of the information / declaration given by the bidder is found
false.
Il. In case of any laps / default in honouring the terms and conditions at any stage
after submitting the e-tender.
lll. If a bidder withdraws his bid during the period of bid validity specified in the
tender’s terms and conditions.
IV. In case of final selection of bidder, if he falls to furnish contract performance
Security in accordance with terms and conditions of the e-tender.

9. Online tender documents submitted by intending bidders shall be opened only of those
bidders whose Earnest Money Deposited physically and other documents found in
order.

0. The technical bids will be opened through online, first on the same day i.e.
24.03.2025 at 03:00 PM by the Tender Evaluation Committee / purchase committee
in the chamber of C.E.O., DPGS, Department of Environment, Govt. of NCT of Delhi,
6" Level, C-Wing, Delhi Secretariat, |.P. Estate, New Delhi — 0002. In case the
holiday is declared by the Govt. on the day of opening of the etender, the etender will
be opened on the next working day. The financial bids will be opened of whose bidders
whose documents scanned and uploaded are found in order. The financial bids will be
opened after finalization of technical bids by the TEC/Purchase Committee.

4. The contractor whose tender is accepted will be required to furnish performance
guarantee @ 5% of the tendered amount within the period to be notified. This
guarantee shall be in the form of Fixed Deposit Receipt (FDR) only of a Schedule Bank.
The period for furnishing Performance Guarantee can be extended up to 05 days with
a penalty of 5% per day of the PG amount. In case the contractor fails to deposit the
said performance guarantee within the notified period including the extended period (if
any), the earnest money deposited (EMD) by the contractor shall be forfeited
automatically without any notice to the contractor. The performance security would
remain with Department till notified period for supply of material plus 60 days after
completion of works. No interest shall payable on the performance security.

72. Intending tenderers are advised to inspect and examine the sites and its surroundings
and satisfy themselves before submitting their etender as to the nature of ground and
subsoil the form and nature of the site, the means of access to site.

3. The competent authority does not bind itself to accept the lowest or any other etender
and reserve to itself the authority to reject any or all the tenders received without
assigning any reason.

4. All etenders in which any of the prescribed condition is not fulfilled or any condition
including that of conditional rebate is put forth by the bidders, shall be summarily
rejected.

5. Canvassing whether directly or indirectly in connection with etenders is strictly
prohibited and the tenders submitted by the contractor who resort to canvassing will
be liable for rejection.

6. The competent authority reserves the right of accept the whole or any part of the
etender and the tenderer shall be bound to perform the same at the rates quoted.

7. The etender for the work shall remain open for acceptance for a period of 90 days from
the date of opening of bids. If any tenderer withdraw his tenders before the said period
or issue of letter of acceptance whichever is earlier, or makes any modifications in the

<!-- page 4 -->

terms and conditions of the tender which are not acceptable to the Department, then
the govt. shall without prejudice to any other right or remedy, be at liberty to forfeit the

z earnest money. Further the tenderer shall not be allowed to participate in the re-
tendering process of the work.

8. This notice inviting tender shall form a part of the contract document. The successful
tenderer on acceptance of his tender by the Accepting Authority shall start the work at
once and sign the agreement. Further, the successful tenderer will submit the e-stamp
of Rs. 00/- under Delhi Jurisdiction for executing the formal agreement.

9. The time allowed for supply of material in schedule is 5 days from the date of award
of work or handing over the site, whichever is later. The successful bidder shall bind to
submit the information in writing for commencement of work at site. The successful
bidder is bind to supply the material in whole of NCT of Delhi. हु

20. Compensation for late work beyond stipulated period will be charged @ % of tendered
amount per day. In case delay continues beyond one-week period of stipulated time
of completion, the contract can be rescinded and balance work shall be got done
through another agency at the risk and cost of the defaulter.

24.The Agency shall be responsible under the obligation to adhere all statutory

requirements of Labour Laws including weekly off, provident fund, Service Tax and
other relevant Laws applicable from time to time, in NCT of Delhi.

22. The Agency/ Contractor should ensure the implementation of Delhi Cabinet Decision
No. 2323 dated 4.03.206 on payment to the contractual/ outsource workers. The
minimum wages fixed by Labour Department, Govt. of NCT of Delhi should be credited
in the Bank accounts of contractual employees up to 7" day of every month. The
Agency should have to pay minimum wages and other statutory benefits to the
contractual workers.

23. The rates will be firm during the contract period. No escalation whatsoever shall be
paid. .

24. The Department shall not be responsible for payment of any compensation on account
of any loss caused to the tenderer, due to natural calamities or other supervening
impossibilities.

25. Payment of bills shall be made after ascertaining quantity, quality, specification, and
compliance of conditions as stipulated in the agreement.

26. The rates shall be inclusive of all applicable taxes, cartage, loading & unloading at site
and nothing will be paid extra in this regard.

27. The work shall be awarded to the tenderer who emerges L-/ item wise or on aggregate
basis in the best interest of the Government.

28. The bidder or their authorized representative, at the time, of opening the technical /
financial bids, may remain present, if they so desire. The bidders representative who
remain present, sign the attendance sheet in token of having attended the proceedings

29. The rates quoted by the bidder shall remain valid for a period of one year from the date
of award of work. This office shall not be held responsible for payment of any extra
payment on account of escalation of costs/ increase in minimum wages etc, during the
period.

30. Appellate authority shall be Pr. Secretary (E & F), Legal dispute if any, will be subject
to Delhi Jurisdiction.

<!-- page 5 -->

34. The quantity in the schedule can be altered at any time, it can be reduced or increased
by 25%, as per actual requirement and subject to availability of funds.

32. In no circumstances, the successful bidder would be allowed to sublet the work in part
or whole of the contract assigned to them.

33. Any dispute or difference arising out of this contract will be resolved through joint
discussion of the authorized representative of the concerned parties. However, if the
disputes are not resolved by joint discussion, then the matter will be referred for
adjudication to a sole Arbitrator appointed by the concerned HOD, Department of
Environment, and GNDTD.

34. The award of the sole Arbitrator shall be final and binding on all parties. The arbitration
proceedings shall be governed by the Indian arbitration and Conciliation Act, 996 as
amended form time to time.

35. The cost of arbitration shall be borne by the respective parties in equal proportions.
During the pendency of the arbitration proceeding and currency of contract, neither
Party shall be entitled to suspend the work/ service to which dispute relates on account
of the arbitration and payment to the contractor shall continue to be made in the terms
of the contract. Arbitration proceedings will be held at Delhi/ New Delhi only.

36. The procurement of items in the schedule is subject to availability of funds and it can
be reduced or increased at any time.

37. This notice inviting etender form a part of the contract document. The successful
tenderer on acceptance of his tender by the Accepting Authority shall within 03 days
from the stipulated date of start of the work, sign the agreement. The successful bidder
will submit the e-stamp of Rs. 00/- for executing the agreement.

38. The tender can be withdrawn at any time without assigning any reason. The L-4
agency bound to supply the.material strictly follow the specifications in the schedule of
quantity

“की et
(Chief Executive Officer)
Delhi Parks and Gardens Society

<!-- page 6 -->

Annexure-A
PN] Online documents Required/Uploaded
Scanned copy of execution of similar nature of works, Issued by Government
Departments only. Condition No. 7(i)
| | Scanned copy of PAN card. condition No.7(ii) ह
| | Scanned copy of GST No with up to date filed return. condition No.7 (iii)
Scanned copy of ITR filed of last three years ( 202-22, 2022-23 and 2023-24).
Condition No. 7 (iv ) हा
| Scanned copy of valid enlistment order condition No. 7(v)
Scanned copy of non-execution of work through another contractor on “back to
back basis on non-judicial stamp paper of Rs.i00/-.( duly Notarized). Condition
No. 7(vi)
7. "
Scanned copy of instrument of EMD. Condition No. 7(vii)
Scanned copy of undertaking that the seedlings to be supplied will be true to the
variety and if found any discrepancy in future, | will be held responsible. The
undertaking should be on non-judicial stamp paper of Rs. 00/ ( duly Notarized)
Condition No.7(viii) .
Scanned copy of valid Insecticide License issued by Licensing Authority of State
Government. Condition No. 7(ix) *
| Pet
(Chief Executive Officer)
Delhi Parks and Gardens Society

<!-- page 7 -->

Schedule of quantity:- ( NIT-7)

S.No. | Name of item हे Quantity Rate in | Amount
Rs. in Rs.
each incld.
incld. GST
GST

q; Supply of seedling of Bamboo vulgaris species 42000

having 6 feet to 7 feet height with 3-4 suckers/
sticks, well grown, healthy, and free from disease
in 0 inch x 2 inch bags.
2. Supply and stacking of good earth at site of work
ie. royalty and carriage up to site of work
including all lead and lifts. (Good measured in cum. | 4000
stacks will be reduced by 20% for payment.( lead .
taken up 20 kms.@ Rs.8.9 per km../ cum.) (
Item No. 2.2 of DSR 2048) .
3. Supplying and stacking well decayed cattle
manure at site including royalty and carriage up
to 20 kms. Lead complete (cattle manure 500
measured in stacks will reduced by 8% for
payment) (lead up to 20 kms..) ( Item No. 2.25 of
DSR-208)
4. Supply of insecticide | Lit. 20
(cypermethrin) in 5 lits. Packing, ISI mark of
slandered company. :
| |
mark.
| | |'
slandered company.
= लिया
company.
कं momen te [||
standard company.
|
material. :
Ts
TT |
material. *
slandered quality. _(As per sample’
44 ‘Supply of degradable polythen bags of different | P/Kg. | 000
sizes for propagation of plants in the nursery (As | *
per sample’
material.
' a a
kg. packing
material for spreading on Nursery paths.
| ली |/|/|/( __ (  ईऋ| |
हे (के to
ey
(Chief Executive Officer)
Delhi Parks and Gardens Society
