---
doc_id: "bbda0f7f5f7f8edb"
source_url: "https://dsssb.delhi.gov.in/sites/default/files/DSSSB/circulars-orders/notice_no_1666.pdf"
ministry: "Delhi Subordinate Services Selection Board"
title: "Download"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "fe9128d5303f8483"
---

<!-- page 1 -->

95558-0८॥0९2/3/2026-58८४-0६ भा SUBORDINATE SERVICES SELECTION BOARD (DSSSB) I7987252/2026
ge Pane रे GOVERNMENT OF NCT OF DELHI
| we SANS DELHI SUBORDINATE SERVICES SELECTION BOARD
a FC-48, INSTITUTIONAL AREA, KARKARDOOMA, DELHI-92
File No. DSSSB-CCII0C2/3/2026/26-222 Dated: 22/0/2026
Rejection Notice No. 7666
Post Name: - Bailiff under Post Code 25/25 in Registrar Cooperative
Societies
. The shortlisted candidates for the Post of Bailiff under Post Code 25/25 in Registrar
Cooperative Societies were given opportunity from 20/07/2026 to 03/08/2026 vide
Notice No.i640 dated 7/07/2026 to up-load the documents in the e-dossier link
activated on OARS Module. The candidature of following candidates having roll number
of Tier-I exam is rejected as they have not submitted the e-dossier during the scheduled
period:
|250257 274000555250253 शव 66659 ०2565ड्गञञ्ञा 002984[250257270005558256257श्ञतठ65625
2502572005898565डञ66क्षा a समन: |
2. This issue with the approval of the Chairperson, DSSSB. [ Q
४0%
DEPUTY SECRETARY, DSSSB
Deputy Secretary (P&P), DSSSB ae
File No. DSSSB-CCM0C27/3/2026/27I6-222 Dated: 22/40/2026 ———— lo. 05555-टटाएटशाडइ26265श्ञा6-झ्ञ३्ढ Dated: 22/70/2026
Copy forwarded for information to:
7. Assistant Registrar (Admin), O/o Registrar Cooperative Societies, Old Court Building,
Parliament Street, GNCTD, New Delhi-40004 through P & P Branch.
2. PS to Chairperson, DSSSB.
3. PS to Member, DSSSB
4. PS to Secretary, DSSSB
5. PS to COE, DSSSB
6. Assistant Director, IT Branch with the request to upload on the website of the Board,
7. Reception Office/Notice Board/Guard File.
