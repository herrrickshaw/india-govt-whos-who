---
doc_id: "2ee3f6b1d7ecc6ae"
source_url: "https://ard.delhi.gov.in/sites/default/files/Administrative%20Reforms/circulars-orders/order_no._09-11.pdf"
ministry: "Administrative Reforms Department, Delhi"
title: "Download"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "182559a39a897c8c"
---

<!-- page 1 -->

GOVT. OF NCT oF DELHI
ADMINISTRATIVE REFORMS DEPARTMENT
‘7th LEVEL, ¢ WING, I.P. ESTATE,
DELHI SECRETARIAT, NEW DELHI-!0002
Email-arupdate@nic.in
F.9/3/202/AR)o} | Dated:o2}| 2%
To
i). The Asstt. Director (Staff & Estt.), Department of Posts, India, O/o the Chief
, Post Master General, Delhi Circle, Meghdoot Bhawan, New Delhi-000].
(i), The Deputy Secretary, O/o the Lokayukta, Govt. of NCT of Delhi, G-Block,

Vikas Bhawan, I.P. Estate, New Delhi- 20002.

(iii). The Deputy Secretary, Health & Family Welfare Department, Govt. of NCT of

Delhi, 9t* Level, A-Wing, Delhi Secretariat, I.P. Estate, New Delhi-0002.
Sub: Interactive session with the applicants for the post of Research Assistants

on deputation basis in Administrative Reforms Department.
Sir/Madam,

I am directed to inform you that an interactive session with the following
applicants, who have applied for the post of Research Assistant, in Administrative
Reforms Department, on deputation basis, is scheduled to be conducted in the
O/o. the Additional Chief Secretary(A.R.), 274 Level, A-Wing, Delhi Secretariat, I.P.
Estate, New Delhi-0002, on 03.0.2023 at 2:00 P.M.:-

Name of E applicant | Post held & Deptt.
No. with DOB (Sh./Ms.) = = ee
Ruchi Aggarwal Postal Assistant, Circle Office, Deptt. Of
20.0.985) Posts, Meghdoot Bhawan_
a Rupali Khurana Shorting Assistant, New Delhi Shorting
9,07.989 Division, Deptt. Of Posts, Meghdoot Bhawan
Nidhi Manchanda Shorting Assistant, New Delhi Shorting
* | (05.09.980) ___| Division, Deptt. Of Posts, Meghdoot Bhawan
Dharmendra Kumar Sr. Assistant, Office of Lokayukta, G-Block,
| Singh (5.07.986) Vikas Bhawan, I.P. Estate, New Delhi
Amit Kumar Sr. Assistant, Health Department, 9% Level,
| (05.03.982) __| A-Wing, Delhi Secretariat
Shalu Devi (0.02.987) | Sr. Assistant, Health Department, GNCT of
el a _—.__| Delhi, 9th Level, A-Wing, Delhi Secretariat _

It is therefore requested to grant permission/directions to the above
applicants so that they could appear in the said session on the scheduled date
and time accordingly.

eee
ens 5200
ate =) es (SANGITA VASHISHTH)

‘Se Ee, SECTION OFFICER (AR)
“आप, मई Ph:0!-23392483

आ ४८ -. ६५ 49 oa 0

॥ ee it

॥ द
]
