---
doc_id: "2cacdd7a59b8e5cd"
source_url: "https://archaeology.delhi.gov.in/sites/default/files/archaeology/circulars-orders/orintal_assistant_rr.pdf"
ministry: "Archaeology Department, Delhi"
title: "Download"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "07b5d73f8d7c52dc"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33002/99

REGD. No. D. L.-33002/99

भारत सरकार
GOVERNMENT OF INDIA

xxxGIDHxxx
एस.जी.-डी.एल.-अ.-12072024-255368
xxxGIDExxx
SG-DL-E-12072024-255368

असाधारण
EXTRAORDINARY

प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 178]

दिल्ली, बुधवार, िुलाई 10, 2024/आषाढ 19, 1946

[रा.रा.रा.क्षे.दि. सं. 96

No. 178]

DELHI, WEDNESDAY, JULY 10, 2024/ASHADHA 19, 1946

[N. C. T. D. No. 96

भाग IV
PART IV

राष्ट्रीय रािधानी राज्य क्षेत्र दिल्ली सरकार
GOVERNMENT OF THE NATIONAL CAPITAL TERRITORY OF DELHI

iqjkrRo foHkkx
vf/klwpuk
fnYyh] 10 tqykbZ] 2024
Qk-la- 2¼5½@LFkk-@iqjk-@2023@1202—x`g ea=ky;] Hkkjr ljdkj dh fnukad 13 tqykbZ] 1959 dh
vf/klwpuk la0Qk0 27@59&,pvkbZ,e¼i½ ds lkFk ifBr Hkkjr ds lafo/kku ds vuqPNsn 309 ds ijUrqd }kjk iznÙk
“kfDr;ksa dk iz;ksx djrs gq, rFkk fnukad 21@02@1978 dh vf/klwpuk la0Qk0 2¼64½@77&,l-II }kjk izdkf”kr
bl ljdkj dh vf/klwpuk ds vf/kØe.k esa] ,sls vf/kØe.k ls iwoZ dh xbZ ;k foyksi dh tkus okys ckrksa dks
NksM+dj] jk’Vªh; jkt/kkuh {ks= fnYyh ds mijkT;iky ,rn~ }kjk iqjkRro foHkkx] jk’Vªh; jkt/kkuh {ks= fnYyh
ljdkj esa ^vksfj,aVy lgk;d* ds in dh HkrhZ i)fr dks fofu;fer djus ds fy;s fuEufyf[kr fu;e cukrs gSa]
vFkkZr~%&
1-

laf{kIr 'kh"kZd ,oa izkjaHk &
¼d½ bu fu;eksa dks iqjkrRo foHkkx] vksfj,aVy lgk;d HkrhZ fu;ekoyh] 2024 dgk tk,A
¼[k½ ;s fnYyh jkti= esa vius izdk'ku dh frfFk ls ykxw gksx
a sA

4150 DG/2024

(1)

<!-- page 2 -->

2

DELHI GAZETTE : EXTRAORDINARY

PART IV]

2-

inksa dh la[;k] mudk oxhZdj.k rFkk osru eSfVªDl esa Lrj & mDr inksa dh la[;k] mudk oxhZdj.k rFkk
osru eSfVªDl esa Lrj bu fu;eksa ds lkFk layXu vuqlwph ds dkWye ¼2½ ls ¼4½ esa ;FkkfofufnZ"V gksx
a sA

3-

HkrhZ i)fr] vk;q lhek] ;ksX;rk bR;kfn & mDr in dh HkrhZ i)fr] vk;q lhek] ;ksX;rk,a ,oa blls
lacfa /kr vU; ekeys mDr vuqlwph ds dkWye ¼5½ ls ¼11½ esa ;FkkfofufnZ"V gksaxsA

4-

v;ksX;rk & ,slk dksbZ Hkh O;fDr] &
¼d½ tks fdlh O;fDr ds thfor ifr@iRuh ds gksrs gq, fookg djrk gS ;k fookg dk vuqca/k djrk gS]
;k
¼[k½ tks ,d thfor ifr@iRuh ds gksrs gq, fdlh O;fDr ls fookg dj pqdk gS ;k fookg vuqca/k dj
pqdk gS] og mDr in ij fu;qfDr dk ik= ugha gksxkA
“krZ ;g gS fd ;fn ljdkj larq’V gS fd ,slk fookg ,sls O;fDr ,oa fookg ds vU; i{kdkj ij
ykxw O;fDrxr dkuwu ds varxZr vuqer gS vkSj bl ckr ls larq’V gks tkus ij fd ,slk djus ds fy;s
fo”ks’k vk/kkj gS@gSa] fdlh Hkh ,sls mEehnokj dks bl fu;e ds izorZu dh NwV ns ldsxkA

5-

f'kfFky djus dh 'kfDr & tgka ljdkj dk ;g er gks fd ,slk djuk vko';d vFkok lehphu gS] rks
og dkj.kksa dks vfHkfyf[kr djrs gq, rFkk l{ke izkf/kdkjh ds ijke”kZ ls] vkns'k }kjk O;fDr;ksa ds fdlh
Js.kh ;k oxZ ds lac/a k esa bu fu;eksa ds mica/k esa ls fdlh dks Hkh f'kfFky dj ldrh gSA

6-

cpko & bu fu;eksa esa Hkkjr ljdkj }kjk bl laca/k esa le;&le; ij tkjh fd, x, vkns'kksa ds vuqlkj
vuqlwfpr tkfr;ksa] vuqlwfpr tutkfr;ksa] vU; fiNM+k oxksZa] HkwriwoZ lSfudksa vkSj vU; fo'ks"k oxksZa ds
O;fDr;ksa ds fy;s micfU/kr fd;s tkus okys visf{kr vkj{k.k] vk;q lhek esa NwV vkSj vU; fj;k;rksa ij
dksbZ izHkko ugha iM+x
s kA
vuqlwph

12-

inuke
inksa dh la[;k

3456-

oxhZdj.k
osru eSfVªDl esa Lrj
D;k p;u in gS@ xSj p;u in
lh/kh HkrhZ okys mEehnokjksa ds fy, vk;q
lhek

7-

% vksfj,aVy lgk;d
% 01* ¼2024½
*blesa ifjorZu dk;ZHkkj ij fuHkZj gSA
% lkekU; dsUnzh; lsok] lewg ^x*] vjktif=r] vfyfidh;
% Lrj&4 ¼25500&81100@&#i;s½
% ykxw ugha
% 18&25* o’kZ ds chp
¼dsUnz ljdkj }kjk tkjh vuqn's kksa ;k vkns'kksa ds vuqlkj
foHkkxh; mEehnokjksa ds fy;s Åijh vk;q&lhek esa 40 o"kZ
rd f”kfFkyuh;½

uksV % vk;q lhek fu/kkZj.k ds fy, fu.kkZ;d frfFk l{ke
izkf/kdkjh }kjk ;Fkk foKkfir gksxhA
*;fn vf[ky Hkkjrh; [kqyh izfr;ksfxrk }kjk in Hkjs tkus
gSa] rks vk;q lhek 18&27 o’kZ ds chp gksxhA
lh/kh HkrhZ okys mEehnokjksa ls visf{kr % vfuok;Z %&
'kSf{kd rFkk vU; ;ksX;rk,Wa
1- fdlh ekU;rk izkIr cksMZ ls ,sfPNd fo’k; ds :i esa
mnwZ@Qkjlh@vjch lfgr mPprj ek/;fed ;k
led{k mRrh.kZA
2- ekU;rk izkIr enjlk cksMZ ls ekSyoh] Qt+y ;k eqa”kh
dkfey ;k eqa”kh Q+kft+y ikB~;ØeA
uksV % vU;Fkk lq;ksX; mEehnokjksa ds ekeys esa fyf[kr esa

<!-- page 3 -->

[PART IV

8-

910-

11-

12-

DELHI GAZETTE : EXTRAORDINARY

3

dkj.kksa dks vfHkys[kc) djrs gq, ;ksX;rk,a l{ke izkf/kdkjh
ds foosd ij f'kfFkyuh; gSA
D;k lh/kh HkrhZ okys mEehnokjksa ds fy, % ykxw ugha
fu/kkZfjr 'kSf{kd ;ksX;rk ,oa vk;q lhek
inksUufr okys mEehnokjksa ij Hkh ykxw
gksxhA
ifjoh{kk dh vof/k] ;fn dksbZ gks
% lh/kh HkrhZ gsrq nks o’kZ
HkrhZ dh i)fr lh/kh HkrhZ }kjk ;k % izfrfu;qfDr ¼vYidkfyd lafonk lfgr½ }kjk ftlds u gksus
inksUufr }kjk ;k izfrfu;qfDr@
ij lh/kh HkrhZ }kjk A
vkesyu }kjk fofHkUu i)fr;ksa ls Hkjs
tkus okys fjDr inksa dk izfr'kr
;fn inksUufr @ izfrfu;qfDr @ % izfrfu;qfDr ¼vYidkfyd lafonk lfgr½%&
vkesyu }kjk HkrhZ gksuh gks] rks xzsM
dsUnz ljdkj@jkT; ljdkj@la?k jkT; {ks= iz”kklu@
ftuls inksUufr @ izfrfu;qfDr @
lkoZtfud {ks= ds miØe@ lkafof/kd vFkok Lok;Ùk
vkesyu fd;k tkuk gS
fudk;@ekU;rk izkIr fo”ofo|ky;ksa@ekU;rk izkIr
vuqla/kku laLFkkuksa ds fuEufyf[kr vf/kdkjh%&
d- ¼1½ ewy laoxZ@foHkkx esa fu;fer vk/kkj ij le:i
in/kkj.k djus okys( vFkok
¼2½ ewy laoxZ@foHkkx esa osru eSfVªDl ds Lrj&3 esa vFkok
led{k ds inksa esa fu;fer vk/kkj ij fu;qfDr ds mijkar
iznku dh xbZ xzM
s esa ik¡p o"kZ dh lsok lfgrA
vFkok
¼3½ ewy laoxZ@foHkkx esa osru eSfVªDl ds Lrj&2 esa vFkok
led{k ds inksa esa fu;fer vk/kkj ij fu;qfDr ds mijkar
iznku dh xbZ xzM
s esa vkB o"kZ dh lsok lfgrA
rFkk
¼[k½ dkWye la[;k 7 esa of.kZr 'kSf{kd ;ksX;rk,¡ j[kus okysA
uksV % ¼izfrfu;qfDr dh vof/k esa dsUnz ljdkj ds mlh ;k
fdlh vU; laxBu@foHkkx esa bl fu;qfDr ls rqjUr
iwoZ/kkfjr fdlh vU; xSj laoxZ in esa izfrfu;qfDr dh vof/k
Hkh lfEefyr gS] ;g lkekU;r% rhu o"kksZa ls vf/kd ugha
gksxhA izfrfu;qfDr ¼vYidkfyd lafonk lfgr½ }kjk fu;qfDr
gsrq vf/kdre vk;q&lhek vkosnu izkfIr dh vfUre frfFk dks
NIiu ¼56½ o"kksZa ls vf/kd ugha gksxhA½
;fn dksbZ foHkkxh; inksUufr lfefr gks % Lkewg ^x* foHkkxh; LFkk;hdj.k lfefr &
rks bldh lajpuk D;k gS\
1- iz/kku lfpo@lfpo ¼ÅtkZ½] jk"Vªh; jkt/kkuh {ks=
fnYyh ljdkj& v/;{k
2- lfpo ¼dyk] laLd`fr ,oa Hkk’kk@iqjkRkRo½] jk"Vªh;
jkt/kkuh {ks= fnYyh ljdkj& lnL;
3- mi&lfpo ¼foRr½] jk"Vªh; jkt/kkuh {ks= fnYyh
ljdkj& lnL;
uksV % ;fn lfefr dk vf/klwfpr v/;{k lfefr ds fdlh Hkh
vU; lnL; ls dfu’B gS] rks LFkk;hdj.k ds fopkjkFkZ
foHkkxh; LFkk;hdj.k lfefr dk ofj’Bre lnL; v/;{k ds
:i esa dk;Z djsxkA

<!-- page 4 -->

4

13-

DELHI GAZETTE : EXTRAORDINARY

os ifjfLFkfr;ka ftuesa HkrhZ ds fy, la?k
yksd lsok vk;ksx dk ijke'kZ fy;k
tkuk gSA

PART IV]

la?k yksd lsok vk;ksx dk ijke'kZ fy;k tkuk vko”;d ugha
gSA

jk"Vªh; jkt/kkuh {ks= fnYyh ds mijkT;iky
ds vkns'k ls rFkk muds uke ij,
pks[kk jke xxZ] lfpo ¼dyk] laLd`fr ,oa Hkk’kk½

DEPARTMENT OF ARCHAEOLOGY
NOTIFICATION
Delhi, the 10th July, 2024
F. No. 2(5)/Estt./Archy./2023/1202—In exercise of the powers conferred by the proviso to Article 309 of
the Constitution of India, read with Government of India, Ministry of Home Affairs notification number F.27/59Him(i) dated the 13th July, 1959 and in supersession of the notification of this Government, published vide notification
No. F.2(64)/77-S.II dated 21/02/1978 except as respects things done or omitted to be done before such supersession,
the Lieutenant Governor of the National Capital Territory of Delhi is pleased to make the following rules regulating
the method of recruitment to the post of ‘Oriental Assistant’ in the Department of Archaeology, Government of
National Capital Territory of Delhi, namely:1.

Short Title and Commencement.
(1)These rules may called the Department of Archaeology, Oriental Assistant Recruitment Rules, 2024.
(2) They shall come into force on the date of their publication in the Delhi Gazette.

2.

Number of Posts, its classification and level in pay matrix.
The number of the said post, its classification and level in pay matrix attached thereto shall be as
specified in column (2) to (4) of the Schedule annexed to these rules.

3.

Method of recruitment, age limit, qualification etc.
The method of recruitment, age limit, qualifications and other matters relating to the said post, shall be
as specified in the columns (5) to (11) of the said Schedule.

4.

Disqualifications.
No persons, (a) Who has entered into or contracted marriage with a person having a spouse living; or
(b) Who having a spouse living, has entered into or contracted a marriage with any person,
shall be eligible for appointment to the said post:

Provided that the Government may, if satisfied that such marriage is permissible under the personal
law applicable to such person and the other party to the marriage and that there are other grounds for so
doing, exempt any person from the operation of this rule.
5.

Power to relax.

Where the Government is of the opinion that it is necessary or expedient to do so, it may, by order, for
reasons to be recorded in writing, and in consultation with the Competent Authority, relax any of the
provisions of these rules with respect to any class or category of persons.
6.

Saving.

Nothing in these rules shall affect reservations, relaxation of age limit and other concessions required to be
provided for the Scheduled Castes, the Scheduled Tribes, Other Backward Classes, Ex-Servicemen and other
special categories of persons in accordance with orders issued by Government of India from time to time, in
this regard.

<!-- page 5 -->

[PART IV

DELHI GAZETTE : EXTRAORDINARY

5

SCHEDULE
1.

Name of Post.

Oriental Assistant

2.

Number of Posts.

01 * (2024)
*Subject to variation dependent on workload

3.

Classification.

General Central Service, Group C, Non-Gazetted, Non
Ministerial

4.

Pay Level in the Pay Matrix.

Level–4 (Rs. 25500-81100)

5.

Whether Selection Post / Non -Selection
Post.

Not applicable

6.

Age limits for Direct Recruits.

Between 18 - 25* years
(The upper age limit is relaxable for departmental
candidate upto 40 years in accordance with the
instructions or orders issued by the Central Government.)
Note: The crucial date for determining the age limit shall
be as advertised by Competent Authority.
*In case of post being filled up by All-India Open
Competition, the age limit would be between 18 years and
27 years.

7.

Educational and other qualification
required for direct recruits.

Essential :
1.

Senior Secondary or equivalent pass with Urdu /
Persian / Arabic as an elective subject from a
recognized Board.

2.

Maulvi, Fazal or Munshi Kamil or Munshi Fazil
Course from recognized Madarsa Board.

Note: Qualifications are relaxable at the discretion of the
Competent Authority, for reasons to be recorded in
writing, in the case of candidates otherwise well qualified.
8.

Whether
age
and
educational
qualification prescribed for Direct
Recruitment will apply in the case of
promotees.

Not applicable

9.

Period of Probation if any.

Two years for direct recruit.

10.

Method of Recruitment.

By deputation (ISTC) failing which by direct recruitment.

11.

In
case
of
re cruitment
by
promotion/deputation/
absorption
grades
from
which
promotion/
deputation/ absorption to be made.

Deputation (ISTC) :
Officers from the Central Government / State
Governments / Union Territory Administration / Public
Sector Undertakings / Statutory or Autonomous Bodies /
Recognized Universities / Recognized Research Institutes:
(a) (i) holding analogous posts on regular basis in the
parent cadre/ department; or
(ii) with 5 years’ service in the grade rendered after
appointment thereto on a regular basis in posts in Level-3
in the Pay Matrix or equivalent in the parent cadre/
department;
OR
(iii) with 8 years’ service in the grade rendered after
appointment thereto on a regular basis in posts in Level-2
in the Pay Matrix or equivalent in the parent
cadre/department.

<!-- page 6 -->

6

DELHI GAZETTE : EXTRAORDINARY

PART IV]

AND
(b) possessing the educational qualifications detailed in
column No. 7.
Note:-(Period of deputation including period of
deputation in another ex-cadre post held immediately
preceding this appointment in the same or some other
organization/ department of the Central government shall
ordinarily not to exceed three years. The maximum age
limit for appointment by deputation (including short-term
contract) shall not exceeding 56 years, as on the closing
date of receipt of application).
12.

If a Departmental Promotion Committee
exists, what is its composition.

Group C Departmental Confirmation Committee:
1. Principal Secretary/ Secretary (Power), GNCT of
Delhi: Chairperson
2. Secretary (ACL/Archaeology), GNCT of Delhi: Member
3. Deputy Secretary (Finance), GNCT of Delhi: Member
Note: Senior most member of the Departmental
Confirmation Committee for considering confirmation
shall act as Chairperson in case the notified chairperson of
the Committee happens to be junior to another member of
the Committee.

13.

Circumstances in which UPSC to be
consulted in making recruitment.

Consultation with UPSC is not necessary.

By Order and in The Name of Lt. Governor
National Capital Territory of Delhi,
CHOKHA RAM GARG, Secy. (ACL)

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. SARVESH
SRIVASTAVA

Digitally signed by SARVESH KUMAR
SRIVASTAVA
Date: 2024.07.12 18:59:52 +05'30'
