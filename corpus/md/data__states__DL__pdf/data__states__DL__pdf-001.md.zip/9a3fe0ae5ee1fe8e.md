---
doc_id: "9a3fe0ae5ee1fe8e"
source_url: "https://ait.delhi.gov.in/sites/default/files/inline-files/tender_notice.pdf"
ministry: "Ambedkar Institute of Advanced Communication Technologies & Research, Delhi"
title: "Tender for Canteen"
date: ""
pages: 9
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "d2a621987ce319c7"
---

<!-- page 1 -->

कि oii
fi {
\
Page l of 9
AMBEDKAR INSTITUTE OF ADVANCED COMMUNICATION TECHNOLOGIES AND RESEARCH है
GOVERNMENT OF NCT OF DELHI :
GEETA COLONY, DELHI-0032
TENDER NOTICE है
॥०.7.377)/0/८&8/0९९॥/203-34/। 5 3 १- ) ६३९ Dated:- 6°) | | 0) yo
Sealed quotations are invited for running a canteen at Ambedkar Institute of Advanced
Communication Technologies and Research, Geeta Colony, Delhi-003! for its staff and students. The
period of contract will be twelve months from actual date of start, Tenders must be submitted in sealed.
envelope super scribed “Tender for Canteen” and must reach the office of the Principal, Ambedkar
Institute of Advanced Communication Technologies and Research, Geeta Colony, Delhi-003 by 2k:bIS ४
है up to 2:00 p.m. Tender submitted after due date will not be accepted on any account. The tenders
must be signed and contain the following details:- .
4. Name
2. Address Proof हि
3. An undertaking that terms and conditions as laid down by the Institute shall be acceptable to
the tenderer.
4. Bid money shall not be less than Rs. 28,600/- (Twenty eight thousand and six hundred only)
per quarter. *
5. Rate list duly signed by the contractor.
6. Certificate showing experience of atleast one year.
7. Security deposit of Rs. 2,440/- in the form of F.D.R. ‘s for a period of ”” year in favour of
Principal, Ambedkar Institute of Advanced Communication Technologies and Research, Geeta
Colony, Delhi-0032.
ड़ Tender will be opened on Roster te at 3:00p.m. Tenderers may send their authorized
representative at the time of opening of tenders. .
8. Principal, Ambedkar Institute of Advanced Communication Technologies and Research, Geeta
Colony, Delhi-0032 reserves the right to accept or reject any tender without assigning any
reasons.
Copy forwarded to: है
3. Director, DTTE, Pitampura, Delhi-88 for information please.

<!-- page 2 -->

ye *
‘ है.
f Page 2 of 9
j :
/ 2. Principals of Polytechnics/ITIs/NSIT/COP with the request for giving due publicity.
' 3. Notice Board of Principal, Ambedkar | nstitute of Advanced Communication Technologies
and Research, Geeta Colony, Delhi-20034.
YX एम : Delhi Govt. web site. wt
gol wr?
PRINCIPAL
‘ AIACT&R

<!-- page 3 -->

/ >
dpi: Page 3 of 9
{ / अंडे:
| AMBEDKAR INSTITUTE OF ADVANCED COMMUNICATION
TECHNOLOGIES AND RESEARCH . i
GEETA COLONY, DELHI-003
TERMS & CONDITIONS FOR RUNNING A COLLEGE CANTEEN FOR
_STUDENTS /STAFF IN AIACT&R

4. The_contract shall be initially for a.period of_one year subject to the satisfactory
performance of the contractor from the date of award of the contract but it can be
extended for another period of one year on the basis of on the same terms and
conditions and by the recommendation of the Canteen Committee. In case of
unsatisfactory performance the contract can be terminated without notice. The
decision of Principal shall be final and binding on the Contractor.

2. The rates of the items to be sold in the canteen shall be displayed on the notice board of
the canteen. The Contractor has to use Coupons of different denominations in different
color/billing machines for payment. Strict adherence to first come first serve basis will
be followed.

‘ 3, In case the Contractor is found charging more than the approved rates, the College is
fully empowered to terminate the contract with immediate effect with forfeiture of the
Security Deposit.

3.4The food and drinks sold in the canteen shall be as per the annexure | of this document.

4, Besides supplying food in the canteen and faculty lounge the contractor will have to :
cater for small and big parties in the college during examinations, conferences,
seminars, etc. at the rates approved by the Canteen Committee.

5. The quality of food supplied in the canteen shall be like home made food. Quality
should at no cost decrease in order to make more profit e.g. bad quality raw material,
too much water in curries and other methods used by dishonest contractors.

6. The gas based cooking will be essential and the Contractor will bear the cost and will
arrange gas refilling on his own.

‘ 7. The Contractor shall employ sufficient Staff for proper functioning of the Canteen.
Sufficient furniture, Utensils and canteen equipments required for running the canteen,
including RO filter and water coolers etc. are to be arranged by the contractor. The

<!-- page 4 -->

;
jj he) py ra
ey Hag
j/ 7 Page 4 of 9
| jf contractor shall make arrangement for keeping all eatable in glassed cover showcases
/ away from flies and insects. {

8. The Contractor shall assess the quantum of business on his own. The Institute does not
guarantee a minimum amount of business.

9. Any dues against a customer on the part of the Contractor shall not be the responsibility
of the College.

0. Only sale of cooked food and readymade food (bakery) and all brands of soft drinks,
lassi, curd and flavored milk will be allowed. Selling and consumption of alcoholic drinks
is strictly prohibited.

2. It shall also be the responsibility of the Contractor to provide soap towel etc. at the
wash basin in the canteen at his own cost.

है 42. ॥#6 (णाएउ८0ा ५3|॥| ठ/गाह९ 79४ 79ंशा॥| ॥8 शी९6 0, 886, ॥॥ 20 0067 97000८५
required for the canteen of best quality.

3. The Contractor shall be held solely responsible if any food item is found adulterated or a
case of food-poisoning is reported.

24. In case the Contractor desires to introduce any new item for sale in the canteen, he will
take prior permission from the competent authority and will also get the rates fixed.
The Principal reserves the right to reject or accept such a proposal.

5. The Contractor will have to present himself before the Principal or his representative
Member of the canteen Committee as and when called for.

6. The number of cooks and bearers should be adequate to provide, Clean and provide
efficient service. The Contractor shall provide the staff with clean uniform with caps to
bearers and cooks employed by him. Each category of workers should have a different
uniform and a name plate.

. 7. The canteen staff shall be medically examined once a year by the hospital. Any
medicine curative/preventive can be procured from Community Medicine department.
i8. The work in the canteen will be supervised and checked by the food Inspector/medical
officer on the matter of hygiene in canteen/quality of food being served by the
Principal/Canteen Committee.

<!-- page 5 -->

eatin: -
7७ ~
j '
jo f
{ / Page 5 of 9
/
V/ 9. The premises of the canteen shall-be used for running the canteen. The contractor may
4 install a photocopier in the canteen for commercial purpose in the interest of students,
but rate of Photocopy should not more than Rs. /- per copy. Use of Canteen purpose
for residential purpose, or as a warehouse is strictly prohibited. .
[ 20. For the breech of any terms and conditions of the deed, the Principal, will be fully
empowered to impose penalty to the extent of Rs. 0,000/- (Rupees Ten thousand only)
for each default or forfeit the security money or both besides termination of the
| ~~ contract” ee erste Hr नन+-++- करके मेन++*“+++ ० मी ay
2. If the Contractor wants to discontinue the license, he shall have to give a minimum
three month’s notice with enough justified reasons acceptable to the Principal. In case
he quits without the required notice, his security deposit will be forfeited. He will still
have to return the items issued to him in good working order failing which he will be
required to pay for the items.
22. The security deposit shall be released on furnishing usual “NO DUES CERTIFICATE” from
the authority on completion of the contract
23. The Contractor shall not bring or cook any item of pork, beef (Cow, buffalo) meat, Non-
Vegetarian dishes prepared from chicken, goat and fish etc.
24. Any damage to Govt. Property during the contract period will have to be recovered from
the Contractor.
25. The Contractor shall have to make arrangement to serve cold water at his own cost, if
any water cooler breaks down or there is a power failure.
26. Addition or alteration/modification in physical structure of the space provided is not
permissible in any manner without valid written order from Principal.
27. Subletting of any kind in any form is not permitted. If found, action will be taken as
deemed fit and proper.
28. The Contractor is not allowed to award, allot sell or mortgage the license to any other
person in any manner whatsoever.
29. The Principal shall be at the liberty to terminate the agreement and forfeit the security
deposit in case the Contractor commits any breach of any term or condition contained
in the contract.

<!-- page 6 -->

jf
yj Page 6 of 9
हैँ. } 30. The stamp duty and expenses if any payable under the law in respect of this deed shall

J be borne by the licensee, on Non-judicial paper of Rs. 00/- for Agreement.

32. The Contractor shall have to furnish the list of employees to be appointed by him in
each shift for running the canteen. The employees shall carry identity cards duly
countersigned by the authorized person affixed with photograph given by the
Contractor. :

32. The I-Card so issued shall have to be produced on demand by the Principal or any other
officer authorized by him. The expenditure on this shall be borne by the licensee.

. 33. In case a worker leaves the employment of the contractor or is removed by him, the
contractor will inform the Principal or his representative in writing. The particulars of
any new employee will also have to be intimated to the authorities as specified by the
college.

34. The Contractor shall abide by the municipal laws and other authorized bodies pertaining
to sale of food, drink and other eatables and shall also obtain the necessary license from
the competent authority as may be required under the law.

35. Disposal of waste material, cleanliness of the canteen, maintenance of the items issued
to him will be done by the contractor himself.

36. The contractor will have to install a Sub-Meter and pay the electricity charges on actual
consumption to the authorities towards Electricity.

37. Security money will be the Rent Amount for a month in the form of F.D.R. in favour of
the Principal, AIACT&R will have to be deposited by the Contractor in advance before
taking possession of the canteen premises, however security money will be hiked by

. 0% every year/extension.

38. Employment of child labour (below the age of 48) is totally prohibited. It is the
responsibility of the caterer to comply with all the statutory requirement of labour law
and other connected laws in force.

39. The caterer shall be responsible for the proper conduct and behavior of the employees
engaged. The caterer along with his co-workers has to behave politely with users. If it is
found that any worker has misbehaved with any of the users, the caterer has to take
action as suggested by the Principal, AIACT&R.

<!-- page 7 -->

j
y 3 Page 7 of 9
f 3 40. Liabilty/responsibility in case of any accident causing injury/death to cafeteria workers or any of
i the staff shall be of the caterer. The Institute shall not be responsible by any means in such ~s
¥ + cases, iy 4 ॥ बः
५ een " - . he ab
f 4. The caterer shall not employ any worker whose track record is not good. He should not have
involved in any crime/offence/police case.

42. Since the services include food and eatables, the provisions of Prevention of Food Adulteration
Act, 954 are binding on the caterer. i

43. Application for allotment of canteen must be accompanied with:-

i) PAN No. /Proof of last three years (20-2, 202-3 & 203-4) Income Tax Return filed - -

ii) Security Money in the form of F.D.R. of Rs. ,440/- (At the time of awarding the contract)

iii) The tenderer must have an experience certificate for running canteen satisfactory at least

two years.
है 44, Undertaking for strict compliance with the prescribed rates for different items and terms&
condition of the tender duly agreed and accepted.

45. The Contractor shall submit his complete Bio-Data with attested copy of his Educational
Certificates duly attested by the Gazetted Officer.

46. In case of any dispute, the matter will be decided by the arbitrator appointed by the Principal
and the discussion of the Principal will be final and binding upon the Contractor.

47. Subject to acceptance of the terms & conditions laid down in the contract, the lowest rates
quoted will be considered as suitable for awarding the contract based on the average rates
quoted. .

48. The Contractor shall keep the canteen open from 8:30 A.M. to 6:00 P.M. for the students and
staff, The canteen shall not be closed on any working day of the Institute without permission of
the Principal/Canteen Committee. Also it has to be operational on all holiday for any purpose of
the Institute as per the advice of the Canteen Committee /Principal.

49. The contractor will provide his own furniture, etc. which shall be sufficient for the minimum
hundred fifty students and staff members at a time.

50. The service from canteen to staff room/Principal’s room and Office of the institute will be
managed by the contractor. No supply of eatable and drinks etc. is allowed in classrooms.

54. Contractor will pay minimum wages as per minimum wages Act 948 revised from time to time
by Govt. of NCT of Delhi vide their orders in terms of category of workforce employed by
him/her.

<!-- page 8 -->

# हु PO een Ee
re गा
4 =k < alall a (A, hi ii AA A a # ४४४ PAH p
' ; ‘Pender Cost: Rs. 00/- (Rs.one Hundred only} Tender No
M og ' 7०8९ 9०३0
हे शक के १
f ह . Annexure-} ©
' LIST OF ITEMS TO BE SOLD IN THE CANTEEN
S.NO. apa 3 ITEMS RATE (EACH) |
a ae ft tongs |
Bin. 2 TEA (ONE CUP) jun cus oe ५६ 6.00 ae
2 COFFEE NESCAFE HOT 300 _ — el
MINERAL WATER BOTTLE as per MRP(Branded) | MRP.
4 SAMOSA, 2 NO. (70 gms.) | 8.00 a
_ 5 ___| BREAD PAKORA 4. NO. (80 gms.) | 3000 iS
(6 _6 __| BUTTER SANDWICH (TWO SLICE) (SOgms.) |= 70.00 |
[7 VEGETABLE SANDWICH (TWO SLICE) (50gms.) | 45.00
[8 JAM SANDWICH (TWO SLICE) (50 gms.) | 2.00 _|
9 __| PATTIES (VEGETARIAN).(400 gms.) 42.00 _ |
PARANTHA (ALOO) (50 gms.) 5.00
: . 22] PARANTHA (PLAIN) (50 gms.) 20.00
/42__| PARANTHA (GOBHI) (50 gms.) [| 7500...
[33 —[eamou feesan Suny LADDU (BESAN / BUND!) se a BOD td
i | —— 0 RICE PLATE WITH SABZI _ है 30.00 _ -
45. | SAMBHAR VADA _ 25.00 |
[6 | PLAIN DOSA WITH SAMBHAR & CHATNI 3000 | :
|7____DOSA (MASALA) WITH SAMBHAR & CHATNI | aes 35.00 __
ee _IDLI (PER PLATE) WITH SAMBHAR & SAUCE 25.00
49 | LUNCH (RICE HALF PLATE, DAL, 4 CHAPATI, 50.00 |
|__| SABZI RAITA) | a on
20 | RAJMA -RICE(PER PLATE) 30.00,
[OORT 34 व रमन |
|22___ RAITA (KATORI STANDARD SIZE) ee 30.00 _ |
(23 | TWO BHATURE WITH CHOLE 30.00 |
(24 | CHOWMEIN (FULL PLATE) — [4000
25_| CHOWMEIN (HALF PLATE) — 28.00 |
26° _| Packed Food, Soft drinks, Lassi, Curd & Flavored गा M.R.P.
ff A a  ऊल#/ऋ###्ऑ्ऑस्‍इऑइऑू्उ् |
4 L27__| Pastry (70gm) 20.00
\

<!-- page 9 -->

a —_—$——————$—$————$————$ aL
: fender Cost: Rs. 700/- {(Rs.one Hundred re .
ay Page 30 ०40
y UNDERTAKING FOR THE PAYMENT OF CONTRACT BID MONEY FOR RUNNING THE CANTEEN .
AT AMBEDKAR INSTITUTE OF ADVANCED COMMUNICATION TECHNOLOGIES AND RESEARH,
GEETA COLONY, DELHI-0032.
_ FORA PERIOD OF TWELVE MONTHS _ _ a in
I — the tender
agree to pay in the principal Rs.
«RS कि Only) as contract bid
money for running the canteen for total period of twelve months.
| if awarded, the contract bid money will be deposited within two working days. The rate list duly
accepted by me is also enclosed. Terms and condition mentioned in the tender notice are
if acceptable to me. Electricity charges will be paid by me, on quartely basis on rates as per the
terms and conditions.
Signatures of the tenderer.
Name (in bloc letters)
Address ते
Telephone No.
(Photocopy of proof of address to be attached)
Enclosures: -
- ) Proof of address
: है 2) Proof of experience
3) Terms and condition of the contract duly signed by tender
4) Rate list, duly accepted and signed by the tenderer. :
5) Security deposit as per tender document,in form of D.D. .
Witness:
i) Signature. ii) Signature हे
Name Name :
Address. Address _ _ हि
