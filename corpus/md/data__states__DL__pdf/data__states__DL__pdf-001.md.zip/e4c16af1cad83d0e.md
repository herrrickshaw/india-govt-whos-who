---
doc_id: "e4c16af1cad83d0e"
source_url: "https://ard.delhi.gov.in/sites/default/files/ARD/circulars-orders/public_notice_767.pdf"
ministry: "Administrative Reforms Department, Delhi"
title: "Download"
date: ""
pages: 4
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "56a216c0ad4232b0"
---

<!-- page 1 -->

GOVERNMENT OF NATIONAL CAPITAL TERRITORY OF DELHI
ADMINISTRATIVE REFORMS DEPARTMENT
7TH LEVEL, ‘C’ ~ WING, DELHI SECRETARIAT,
I.P.ESTATE, NEW DELHI-770002
email: grupdate@nic.in Fax: 2339262
ess SSS जी ल््ि्िऊज््जूज्जज जान +
Fl 9/78/AR/Admn/2022/-F 6%. Dated: os)o3)2024,
Public Notice on draft Recruitment Rules for the post of ‘Staff Car Driver (Ordinary
Grade)’ in Administrative Reforms Deparment, GNCTD.
In compliance with Services Department's Circular No. F.2()/RRs/202/S-IV/676- 680
dated: 06.04.202I, draft Recruitment Rules for the post of 'Staff Car Driver (Ordinary
Grade)’ in Administrative Reforms Department, GNCTD is annexed
The stakeholders, if interested in making any objections/comments or suggestions on the
draft Recruitment Rules may do so in writing, within a period of 30 days from the date of
publication of draft Recruitment Rules to Section Officer (Admn.),Administrative Reforms
Department 7th Level, ‘C’ — Wing, Delhi Secretariat, I.P.Estate, New Delhi-l0002 or at
email address: arupdate@nic.in.
Dy. Secretary (AR)
DEPUTY SECRETARY/HOO
Administrative Reforms Department
Govt. of N.C.T. Dalhi
7'h Level, C-Wing, Delhi Secretariat,
New Delhi-440002 |
|

<!-- page 2 -->

छे
DRAFT
GOVERNMENT OF NATIONAL CAPITAL TERRITORY OF DELHI
ADMINISTRATIVE REFORMS DEPARTMENT
7TH LEVEL, ‘C’ - WING, DELHI SECRETARIAT,
I.P.ESTATE, NEW DELHI-70002
email : arupdate@nic.in Fax: 2339262]
NOTIFICATION
Dated the___
F.9/78/AR/Admn/2022 :- In exercise of the powers conferred by proviso to article 309 of
the Constitution read with Government of India, Ministry of Home Affairs, notification No. 27/59-
Him (i) dated I3th July 959 the Lt. Governor of the National capital Territory of Delhi, after prior
consultation with the Services Department, Government of National Capital Territory of Delhi for
Group C Posts, is pleased to make recruitment rules for the post of ‘Staff Car Driver, Ordinary grade’
in the Administrative Reforms Department, Government of National Capital Territory of Delhi,
namely:-

il. Short title and commencement:- (i) These rules may be called ‘The Administrative Reforms

Department Driver, Ordinary Grade Recruitment Rules 2024’.
(ii) They shall come into force from the post of their publication in the Delhi Gazette.

2. Number of Posts, classification and Level in the pay matrix:- The number of the said post,
its classification and Level in the Pay Matrix attached thereto, shall be as specified in columns
(2) to (4) of the Schedule annexed to these rules.

3. Method of recruitment, Age limit and Qualification , etc:- The method of recruitment of the
said post, age limit, qualifications and other matter concerned therewith ,shall be as specified
in the columns (5) to (3) of the said Schedule.

4. Disqualification:- No person,

a) Who has entered into or contracted a marriage with a person having a spouse living; or
b) Who having a spouse living, has entered into or contracted a marriage with any person;
shall be eligible for appointment to the said post:

Provided that the Government may, if satisfied that such marriage is permissible
under the personnel law applicable to such persons and the other party to the marriage
and that there are other grounds for doing so, exempt any person form the operation of
this rule.

5. Power to relax:- Where the Government of National Territory of Delhi is of the opinion that it
is necessary or expedient to do so, it may, by order and for reasons to be recorded in writing,
relax any of the provisions of these rules with respect of any class or category of persons.

6. Saving:- Nothing in these rules shall affect reservations, relaxation of age limit and other
concessions required to be provided for the Schedules Castes, Schedules Tribes, Ex-
Servicemen and other special categories of persons in accordance with the orders issued by the
Government of National Capital Territory of Delhi from time to time in this regard.

<!-- page 3 -->

आठ ४४०५५ —
ws creo
se,8255 2
es _se s
~getta ¢ lg
53838 a 2 fe
SQet.o 3 |=
Sl°ESEs LE [<
223338228) |Z
SERLES EE |S
aoa te § daolz
8 ८० 5 2
a 8 a a 25 oN te भे Ss e
5 हैं 25 ० दर sts PESLZH EL ELL S
ce as 3s कर कट
g 8 BE . af SES Be 2g
= = 82 5 x se EP, ste Fess
§ o oS 6 of HIZoEPE, FEB
€ है ge 2 o 2828 egerrsegtse
2, oa OB es vs_s 5
a2 2 2 «6 s ese of BScd wes
3 5 8 Be gpesesseeer
x2 SS. wp a CEs FRESE Z2 4s
53 we Bede 8. B8s pee DETER SS 8
ae pe e232 Ee 2B Sok ES ESP B25
oe a> Bees कक EES SeVeeRZ2"-4 582
og Ss wei ™s ¢$2 "62 SQHEQCS ys ax
32 6 8० 8g$u.2 Ee 42488 eetl’sse 7,8
aS as Secs 2 598 Siz 845 8285
ब हुक 2328 eS e228 छह 55854
दर ease Pesse €> 8S Sr essysce eae
gs esspssee gi Ess Sek eae, 3288
23 छत लक करे = So ERS He FES
22 SESSS2Sbee G8 Sse . ZSEBS nes EF
35 BREZZSERS ESET TSR एव के BoSSpnesoe.
ae SSLEM CEOS Eee obese 2,88 SPSL ebES
ag SSESES ELSE SZESEL SAS SARE Seeege 5
SELSSCECLAFOZAR SSS ZASsbduezetos
5० 2 aa
eo Ex BS
as ae om
o uo cy
Ag Sf «=
os 5 Ge
+e yt £8
2 fe 7 ye
ar Se is
a5 we a9
£3 Po 3
3 £2 »
25 तिल हक पु
=. Sic
g5 ES $x
52 3a 3
3 2 ere 3a B¢
= z =3 7A S
3 eo eS
रे 5 BB 2B =
> 2 Bz apn PE
5 3 2 829 $5 8०
है SoZ 9
3 ड़ & 325 | आठ °&
3 z > 288 e2 25
Z| 3 x sé Ze Sea
3 : m we 85 पे
5 a QE oe s
fal + <= ca a °S see
rm] 3 = = @ 39 2० °§s8
>| = E g 289 ES 928
हट E ns S gee
a 34 5 e 228 8 €88
a % & S58 ga 20
a g Ss 23s SS sé
of a €8a0 Zn ¥ SS
al &
a
2 6
5 %
Z| g
| a
5
Fe $2
4 8 8,
| 2 2
S| vs 3
| as §
<3 BY
58 a
3 £
3
24 a
= 2 o
= wn] Z
a
o Ba 2
Z “see
g हे
Sex कक
a5 sscet
Bus BREE
as & om |, नव | 55
2
= a4
= 2,82
g gece
BSS
5 C4E5
S Boies
g S225
a gees
sé
0 OBE
=
3 Soe
5 Ses हे
2 apEZ &
Ee yBSso =
ze 5220७55
a asresgbs
Ss ra Re
5 8
i 8
है है है विद
a2 SEZs
aa =|4026

<!-- page 4 -->

_ ee ae
3 33 858
fo veo
Ze ,
ee oe हर Z€
vf =
eoa2 ze जद
कण as ५9६१ a
Bett 5 ag BB
EESe @ ~ = <
Ss = Qo = a
S£255 ० = ob
2 इह a 8 g&
ELEz2 a Ze Zs
ESF EG ls 23 OBE
SES 8 9/.|/3 53 a
536 8 ga/2 3: ae
 & >
5 । Gee o§ है
€ 5 Sess a =
¥ 3 5 888) नि 2
2 z 3 BER e S =
प्र डे aaog 3S ‘3
3 न 3 88 6 3 E
2 £ 3 S8s& Zz 3
3 5 3 aos <
= o B 5 आते हैं 2
g. Cc 2 S220 =
5 ee oop, & 5 88.5 ड़
ए डिक = SsBESO 5
= Bg 5 gO k 5
es 5 aA peeadg 5
2 EB S 8 8 e040 5
g a2 g 8 B& a S
ड़ न्‍्5 A 4g BO 4ea2 5
e. €5 >> छूट हक मे 5
2 3 3
Es Ss f 33 Sese ०
as gg Sg EY geaca #
z4 g8 5 Be स्व 4
ze ae g,88 Fai
me So a Gas
85 aa = PAS 68° 8S
£ lB. a 2O8 eV os
Ee oP #252 Bsg08
So “5 2382 23558
az ag Be oO gEeey
a8 2% aor gE ets gs
sa £5 > @F E888
=e Os oS eC ZIu 0 FE,
Us keke ००००४ =aee
Ygeesee 83538 8 हड्दह ४ 6.5
की Hees 3ER2525
e 3 D e 6 ag a e.
38 SCZ ESS yo SPZ75 88588
ee SSERSoES ese ee BEEZ Be
58 BET RSRZE . Shegy SEAESS
ges BS. GEG EE 3c oviak 588०-88
बल ठड्डिं 5१805 5 £ alsa sREBE?
3h OS 8,8°7S5 & पल S28 E ow
83 85:55 58 95872 8 «55:38 ' 5. ते मत, 5
22 SQIS28S25 § siess SaSsag
नह Seen ken & ~S8en Spee es
SS 2536 छू ae 8 & Us
oa GStssOc2 8 2eB43S5 wxERgSZe
TSize esa lse 8 BSSeBe¢e SEP ae
as peeee se, 2 SS ag5E BB5ene2
Ss SeSeS S85 &€ ot eezae BPELERS
es zeyrePSe हु "pS%R3R SEZERS
28 eeaRSESF 4 ०5४2६ S SEES
eu SEtCeESSs हें उद5 585३ Bu vs oS
Ex SSemens% 2 Sever =§seEL eae
2s B28 25935 ~ B@sgseue Et Seas
ag ApPBSSsS2G FS FeSSSS F743
के EGEPL GES ४ SEF B £85280
ae BogS mee है इंच हिल BRVEES
ze EBeSeEBe Se € SFESSE FSF EGE mw
pay EM o, SMES क * ys 42578 Dog ees
Zs StS ESeEERST SF yee ees ger cay
is Bett, cip है. PSRLSES SCRvs ag
ce Se5C ees 2G F 2A25e50 ghES HS
E¢ e425 28552 § E2SSES SEOs
ge aT Cae f t + छू es ‘eo. oy
ge है कीट 2४ घष्केद् दा S°ESELe
= SEP E2548 = छू हु. 2 8 Qf 20.2
sé SSgsss*e2 & Bytes eRe EZe
a | & ao} 5 EB? ¢ 5 g ons
3. Se Ses=G-2 B SEeeee RZECE LS
se क्र wa oS « GE 5 दा
g38 Zee2en28Ge 2 Sge3S se egFn
£8 4885 क.5.285%5 F 25805 5 BLES
£8 AxTOOUGOIE OQ FEELS SS ZERSERS
3 2
we 3 2
iy 6 = 2
5 2 BS &
3s 2) z
ape a 3
Baga 6 &
Bigs 3
Scie 3 a
gaa ot “
38
a2 2a 5 हु
SSE & =
4024 S Ss
gie2 | (4 g
S525 हु a
ES29 3g
Hepes 6. g
563 E 8
552 z 8
flee | le, =,
oa eo et 5
82585 856 Bo
38हिडहड 22 86
S2see¢3] (86 ES
Sbece | हैह <8
हल 5
ay oa o€
BEssgsineg L£§
eat es
a# BE
oS sg 3
se 88 8
38 ar
ES e326
S2e BE LE
ae Arewsé6 6
4
