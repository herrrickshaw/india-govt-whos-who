---
doc_id: "4ba5bb7fa2c4da34"
source_url: "https://development.delhi.gov.in/sites/default/files/development/circulars-orders/order_dated_01.03.2024_regarding_screening_committee_for_vcims_portal.pdf"
ministry: "Development Department, Delhi"
title: "Download"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "d6a381a9489271e1"
---

<!-- page 1 -->

/ caper coe ascaraai या
oa ee ela oer ibe c's ee ee ee a 4
{ DEVELOPMENTE |
GOVT. OF N.C. Tees" ७६
5/9, UNDER HILL ROA uy e 054
F. No.38(232)/Appointment. VNO/Vig. /Dev.HQ/2022/ Dated:
ORDER
Consequent upon introduction of an online portal w.r.t. Vigilance Complaint
Information Management System (VCIMS) by the Hon’ble Lt. Governor, Delhi’ on 2.09.2023
and in terms of the instructions contained in Memorandum No. F.
0l/ 5/DOV/Admn/2022/Pt-file/ |2379-2383, dated 26/0/2023 issued by Directorate of
Vigilance, GNCT of Delhi (copy enclosed) for disposal & action on vigilance related complaints
in Administration of Union Territory NCT of Delhi, a Screening Committee comprising of
following officers is constituted in this department to examine and recommend action on such
complaints so received through the online complaint portal (VCIMS): -
l. Deputy Director (HQ)/Vigilance, Development Department
2. Section Officer (HQ)/Vigilance, Development Department
3. AAO (HQ), Development Department
The aforesaid Committee shall meet on weekly basis or at appropriate intervals as
decided by the Competent Authority.
Further, in terms of DOV Memorandum, dated 26.0.2023, no vigilance complaints in
physical mode shall be received or acted upon by this department after issuance of this order.
f
This issues with the approval of Competent Authority. \ At
(PAY i CHOPRA)
DEPUTY DIRECTOR (HQ)
F, No.38(232)/ Appointment. VNO/Vig. /Dev-HQ/2022/ Q 7 Dated: © | - ay
११6 ॥- 9 7९२०२ ५
Copy for information & necessary action to: -

, PA to Development Commissioner

2. PA to Special Development Commissioner

3. Deputy Director (HQ)/Vigilance, Development Department

4. Section Officer (HQ)/Vigilance, Development Department :

5. DCA (HQ)

6. AAO (HQ)

7. Incharge- Receipt & Issue Branch, Development Department (HQ) with the instructions
not to receive physical vigilance related complaint and to inform the concerned to
submit online complaint on VCIMS portal of Delhi Government as launched by Hon'ble
Lt. Governor, Delhi

AE System Analyst with the request to upload this order on the official website i his
department. {

9. Guard file \ \

V\I
(PAWAN CHOPRA)
DEPUTY DIRECTOR (HQ)

\

,
Sy de ser! (रे
७
6 गण - दर हे
