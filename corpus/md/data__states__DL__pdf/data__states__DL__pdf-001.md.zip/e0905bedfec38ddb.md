---
doc_id: "e0905bedfec38ddb"
source_url: "https://damb.delhi.gov.in/sites/default/files/inline-files/notification_mni_azadpur.pdf"
ministry: "Directorate of Agricultural Marketing, Delhi"
title: "Notification of MNI Azadpur"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "4fe322a282cde3ea"
---

<!-- page 1 -->

(TO BE PUBLISHED IN PART-IV OF THE DELHI GAZETTE EXTRA ORDINARY) 5
OVERNMENT OF NATIONAL CAPITAL TERRITORY OF DELHI
कु (DEVELOPMENT DEPARTMENT)

DIRECTORATE OF AGRICULTURAL MARKETING

49, ALIPUR ROAD, OLD SECTT., DELHII0 054
No.F.8/35/2003/DAM/MR/(i)/& 2 Dated: 7" January, 2004

NOTIFICATION

No.F.8/35/2003/DAM/MR/(I)- Whereas the Fruit and Vegetable Market,
Azadpur, Delhi is one of the biggest fruit and vegetable markets of Asia which has
handled a total arrival of fruits and vegetables of the order of 44 lakh tonnes in 2002-03
and more than 90% of the arrivals were from outside Delhi and other States comprising
the states of Jammu & Kashmir and Himachal Pradesh with respect to apples,
Maharashtra with respect to bananas and Uttar Pradesh with respect to mangoes and in
relation to vegetables, the states of Uttar Pradesh and Punjab with respect to potatoes, 4
Rajasthan and Maharashtra with respect to onions and Madhya Pradesh and
Maharashtra with respect to tomatoes; and whereas it influences prices at the national
level as more than 40 lakh tonnes of fruits and vegetables is received from as many as
5 States from all parts of India which Is indicative _ of the attractiveness of the prices
obtaining in the Fruit and Vegetable Market at Azadpur, Delhi;

AND WHEREAS the term of office of the Market Committee constituted under .
section 36 of the Delhi Agricultural Produce Marketing Regulation Act 998 (Delhi Act 7
of 999).. ४०७७ ॥०७०४४ण |0,7,4/47/82/00५॥07/५07/5079 (80०6 29.2.2000 ॥85
expired on 28.2.2003;

AND WHEREAS the Government of National Capital Territory of Delhi is satisfied
that on account of the ~stional importance of marketing of agricultural produce at the
Fruits and Vegetable M..<et, Azadpur, Delhi, it is expedient to ensure the efficient
regulation of the marketing of the sald agricultural produce by declaring / establishing it
as @ special market, known as “Market of National of Importance";

NOW THEERFORE on overall consideration of all facts, the Lt. Governor of the
Natinal Capital Territory of Delhi is pleased to declare / establish the Fruit and Vegetable
Wholesale Market, Azadpur, Delhi as a Market of National Importance in terms of the
provisions of sub-section (2) of section 26 of the Delhi Agricultural Produce Marketing
(Regulation) Act, 998 (Delhi Act 7 of 999).

The market area, yards / sub yards of Agricultural Produce Marketing
Committee (Market of National Importance) Azadpur, Delhi would be the same as of the
Agricultural Produce Marketing Committee, Azadpur, Delhi and all items of agricultural
produce would be the same as already declared in the Schedule of items of Agricultural
Produce Marketing Committee, Azadpur, Delhi.

By order and in the name of
४ The Lt. Governor of the National Capital
Territory of Dethi
a
(XK, MAHTO)
Special Secretary (Development)

<!-- page 2 -->

[दिल्ली असाधारण गजट के भाग-4 में प्रंकाशित किये जाने के लिए [
राष्ट्रीय राजघानी क्षेत्र दिल्‍ली सरकार GB
( विकास किम है
कृषि विपणन 5
49, अलीपुर रोड़, पुराना सचिवालय, दिल्ली - 54
सं0. फा. 8/35/2003/कू .वि.नि./एम. आर . (।) 85 दिनाक: 07 जनवरी, 2004
om
am. Fr fer. आर
i ES एवं er 7 = दिल्‍ली, एशिया की सबसे बड़ी फल एवं
रुब्जी गण्डियों में से एक है, जिसमें वर्ष 2002-03 में लगभग 4। लाख टन फल और सब्जियों
की आवक थी और उसमें से 90 प्रति0 से अधिक आवक दिल्ली से बाहर की थी जिसमें सेब,
जम्मु-कश्मीर और हिमाचल प्रदेश राज्यों से, केला महाराष्ट्र से, आम उत्तर प्रदेश से तथा सब्जियां
आलू, उत्तर प्रदेश एवं पंजाब से, प्याज राजस्थान एवं महाराष्ट्र से, टमाटर मध्य प्रदेश एवं
महाराष्ट्र से आया;और जैसाकि फल एंवं सब्जी मण्डी, आजाद पुर, दिल्ली, में भारत के सभी भागों
के लगभग ।5 राज्यों से 40 लाख टन फल एवं सब्जी प्राप्त होती है और यहां इनके प्रचलित
भाव, इस बात का .ब्ोतक कि ये राष्ट्रीय स्तर पर अपना मूल्य' प्रभाव डालते हैं;
और जैसा कि कृषि उपज विपणन समिति, आजाद पुर, दिल्‍ली, की विपणन समिति का
गठन, दिल्ली कृषि उपज विपणन (विनियमन) अधिनियम, ।998 (दिल्ली अधिनियग संख्या" 7, ॥999)
की घारा 36 के अंतर्गत अधिसूचना सं0. 4/47/82/डीएएम/एमआर/खण्ड - 3/5079 . दिनांक
29.42.2000 aI Prat wi और उसका कार्यकाल दिनांक 28.॥2.2003 को समाप्त हो
गया है; ; may
और जैसा कि राष्ट्रीय राजधानी क्षेत्र दिल्‍ली सरकार, इस बात से संतुष्ट है कि फल एवं
“शब्जी भण्डी, आजाद पुर, दिल्ली, भें कृषि उत्पाद के विपणन के राष्ट्रीय महत्व को देखते हुए,
इन कृषि उत्पादों के विपण्न के सक्षम विनियमन को सुरक्षित करने हेतु इसे एक विशेष मण्डी,
जिस्ले'राष्ट्रीय महत्व की मण्डी' के रुप में घोषित/स्थापित करना आवश्यक समझती है;
अतः अब सभी तथ्यों को ध्यान में रखते हुए, राष्ट्रीय राजधानी क्षेत्र दिल्‍ली के उपराज्यपाल,
aed feed git ser fama (विनियमन) अधिनियम, i998 [दिल्ली अधिनियम संख्या
7, \999} a धारा 26 की उप घारा (2) के अंतर्गत फल एवं सब्जी गण्डी, आजादपुर, दिल्ली,
को एक राष्ट्रीय महत्व की मण्डी के रुप में घोषित/स्थापित करते हैं ।
कृषि उपज ब्रिपणन समिति (राष्ट्रीय महत्व की मण्डी[ आजाद पुर, दिल्ली का मण्डी
क्षेत्र याई/सब याई वही, होगा जो कृषि उपज विपणन समिति, आजाद पुर, दिल्‍ली, का था और
इसकी कृषि उपज की सभी वस्तुएं वही होंगी जो कृषि उपज भण्डी समिति, आजाद पुर दिल्ली,
की अनुसूचि में पहले से घोषित हैं । ५ xo
राष्ट्रीय राजधानी क्षेत्र दिल्ली के उपराज्यपाल
: के आदेश से तथा sa aa
or ae है
| Sone
{eas gar aed}
विशेष सचिव (विकास)
