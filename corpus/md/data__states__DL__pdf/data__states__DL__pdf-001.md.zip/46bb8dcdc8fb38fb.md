---
doc_id: "46bb8dcdc8fb38fb"
source_url: "https://excise.delhi.gov.in/sites/default/files/Excise/tender/gem-bidding-6106066.pdf"
ministry: "Excise, Entertainment & Luxury Tax Department, Delhi"
title: "Tender Document"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2baa44bc05d5adbb"
---

<!-- page 1 -->

Bid Number/बोली

मांक ( बड सं या) :
GEM/2024/B/4675347
Dated/ दनांक : 23-02-2024

Bid Document/ बड द तावेज़
Bid Details/ बड ववरण
Bid End Date/Time/ बड बंद होने क तार ख/समय
Bid Opening Date/Time/ बड खुलने क

04-03-2024 20:00:00
04-03-2024 20:30:00

तार ख/समय
Bid Offer Validity (From End Date)/ बड पेशकश
वैधता (बंद होने क तार ख से)

90 (Days)

Ministry/State Name/मं ालय/रा य का नाम

Delhi

Department Name/ वभाग का नाम

Excise Entertainment & Luxury Tax Department Delhi

Organisation Name/संगठन का नाम

N/a

Office Name/कायालय का नाम

Head Office

Total Quantity/कुल मा ा

1

Item Category/मद केटे गर

IBM Control Desk Authorized User Annual SW Subscription &
Support Renewal (Q3)

Minimum Average Annual Turnover of the
bidder (For 3 Years)/ बडर का यूनतम औसत

80 Lakh (s)

वा षक टनओवर (3 वष का)
OEM Average Turnover (Last 3 Years)/मूल
उपकरण िनमाता का औसत टनओवर (गत 3 वष का)
Years of Past Experience Required for
same/similar service/उ ह ं/समान सेवाओं के िलए
अपे

80 Lakh (s)

3 Year (s)

त वगत अनुभव के वष

MSE Exemption for Years Of
Experience/अनुभव के वष से एमएसई छूट/ and
Turnover/टनओवर के िलए एमएसई को छूट

ा

Yes

है

Startup Exemption for Years Of
Experience/अनुभव के वष से टाटअप छूट/ and
Turnover/ टनओवर के िलए

टाटअप को छूट

ा

Yes
है

1/6

<!-- page 2 -->

Bid Details/ बड ववरण

Document required from seller/ व े ता से मांगे
गए द तावेज़

Past Performance/ वगत

दशन

Bid to RA enabled/ बड से रवस नीलामी स
Type of Bid/ बड का

Experience Criteria,Past Performance,Bidder
Turnover,Certificate (Requested in ATC),OEM Authorization
Certificate,OEM Annual Turnover,Additional Doc 1
(Requested in ATC),Additional Doc 2 (Requested in
ATC),Additional Doc 3 (Requested in ATC),Additional Doc 4
(Requested in ATC),Compliance of BoQ specification and
supporting document
*In case any bidder is seeking exemption from Experience /
Turnover Criteria, the supporting documents to prove his
eligibility for exemption must be uploaded for evaluation by
the buyer
50 %

य कया No

कार

Two Packet Bid

Time allowed for Technical Clarifications
during technical evaluation/तकनीक मू यांकन के 2 Days
दौरान तकनीक प ीकरण हे तु अनुमत समय
Inspection Required (By Empanelled
Inspection Authority / Agencies preregistered with GeM)

No

Evaluation Method/मू यांकन प ित

Total value wise evaluation

EMD Detail/ईएमड

ववरण

Advisory Bank/एडवाईजर बक

State Bank of India

EMD Amount/ईएमड रािश

390000

ePBG Detail/ईपीबीजी ववरण
Advisory Bank/एडवाइजर बक
ePBG Percentage(%)/ईपीबीजी

State Bank of India
ितशत (%)

Duration of ePBG required (Months)/ईपीबीजी क
अपे

त अविध (मह ने).

5.00
15

(a). EMD EXEMPTION: The bidder seeking EMD exemption, must submit the valid supporting document for the
relevant category as per GeM GTC with the bid. Under MSE category, only manufacturers for goods and Service
Providers for Services are eligible for exemption from EMD. Traders are excluded from the purview of this
Policy./जेम क शत के अनुसार ईएमड छूट के इ छुक बडर को संबंिधत केटे गर के िलए बड के साथ वैध समिथत द तावेज़ तुत करने है ।
एमएसई केटे गर के अंतगत केवल व तुओं के िलए विनमाता तथा सेवाओं के िलए सेवा दाता ईएमड से छूट के पा ह। यापा रय को इस नीित के
दायरे से बाहर रखा गया है ।
(b). EMD & Performance security should be in favour of Beneﬁciary, wherever it is applicable./ईएमड और संपादन
जमानत रािश, जहां यह लागू होती है , लाभाथ के प म होनी चा हए।

2/6

<!-- page 3 -->

Beneficiary/लाभाथ :
Commissioner Excise
Head Office, Excise Entertainment & Luxury Tax Department Delhi, N/A,
(Commissioner Excise)

Splitting/ वभाजन
Bid splitting not applied/बोली वभाजन लागू नह ं कया गया.
MSE Purchase Preference/एमएसई खर द वर यता
MSE Purchase Preference/एमएसई खर द वर यता

No

MII Purchase Preference/एमआईआई खर द वर यता
MII Purchase Preference/एमआईआई खर द वर यता

No

1. If the bidder is a Micro or Small Enterprise as per latest definitions under MSME rules, the bidder shall be
exempted from the requirement of "Bidder Turnover" criteria and "Experience Criteria" subject to meeting of
quality and technical specifications. If the bidder is OEM of the offered products, it would be exempted from the
"OEM Average Turnover" criteria also subject to meeting of quality and technical specifications. In case any
bidder is seeking exemption from Turnover / Experience Criteria, the supporting documents to prove his eligibility
for exemption must be uploaded for evaluation by the buyer.
2. If the bidder is a Startup, the bidder shall be exempted from the requirement of "Bidder Turnover" criteria and
"Experience Criteria" subject to their meeting of quality and technical specifications. If the bidder is OEM of the
offered products, it would be exempted from the "OEM Average Turnover" criteria also subject to meeting of
quality and technical specifications. In case any bidder is seeking exemption from Turnover / Experience Criteria,
the supporting documents to prove his eligibility for exemption must be uploaded for evaluation by the buyer.
3. The minimum average annual financial turnover of the bidder during the last three years, ending on 31st
March of the previous financial year, should be as indicated above in the bid document. Documentary evidence in
the form of certified Audited Balance Sheets of relevant periods or a certificate from the Chartered Accountant /
Cost Accountant indicating the turnover details for the relevant period shall be uploaded with the bid. In case the
date of constitution / incorporation of the bidder is less than 3-year-old, the average turnover in respect of the
completed financial years after the date of constitution shall be taken into account for this criteria.
4. Experience Criteria: In respect of the filter applied for experience criteria, the Bidder or its OEM {themselves or
through reseller(s)} should have regularly, manufactured and supplied same or similar Category Products to any
Central / State Govt Organization / PSU / Public Listed Company for number of Financial years as indicated above
in the bid document before the bid opening date. Copies of relevant contracts to be submitted along with bid in
support of having supplied some quantity during each of the Financial year. In case of bunch bids, the category of
primary product having highest value should meet this criterion.
5. OEM Turn Over Criteria: The minimum average annual financial turnover of the OEM of the offered product
during the last three years, ending on 31st March of the previous financial year, should be as indicated in the bid
document. Documentary evidence in the form of certified Audited Balance Sheets of relevant periods or a
certificate from the Chartered Accountant / Cost Accountant indicating the turnover details for the relevant period
shall be uploaded with the bid. In case the date of constitution / incorporation of the OEM is less than 3 year old,
the average turnover in respect of the completed financial years after the date of constitution shall be taken into
account for this criteria.
6. Past Performance: The Bidder or its OEM {themselves or through re-seller(s)} should have supplied same or
similar Category Products for 50% of bid quantity, in at least one of the last three Financial years before the bid
opening date to any Central / State Govt Organization / PSU / Public Listed Company. Copies of relevant
contracts (proving supply of cumulative order quantity in any one financial year) to be submitted along with bid
in support of quantity supplied in the relevant Financial year. In case of bunch bids, the category related to
primary product having highest bid value should meet this criterion.

3/6

<!-- page 4 -->

IBM Control Desk Authorized User Annual SW Subscription & Support Renewal ( 1
pieces )
Technical Specifications/तकनीक

विश याँ

Buyer Specification
Document/ े ता विश

Download

द तावेज़

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

1

Consignee
Reporting/Officer/
परे षती/ रपो टग

Address/पता

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
Ajay Kumar Gahlot

110002,L&N block,vikas
bhawan,ip estate ITo

Buyer Added Bid Specific Terms and Conditions/ े ता

ारा जोड़ गई बड क

वशेष शत

1. Generic
OPTION CLAUSE: The Purchaser reserves the right to increase or decrease the quantity to be ordered up
to 25 percent of bid quantity at the time of placement of contract. The purchaser also reserves the right to
increase the ordered quantity by up to 25% of the contracted quantity during the currency of the
contract at the contracted rates. Bidders are bound to accept the orders accordingly.
2. Provisions for workmen compensation, insurance, public liability, property damage, insurance etc. to be
ensured by the contractor. Also, safety measures prescribed for working in Extra High Voltage & use of
personnel protective equipment must be adhered to.
3. Buyer Added Bid Specific ATC
Buyer Added text based ATC clauses
1)
Certificate of Incorporation and Articles of Association of the participants in case of Company/ limi
ted liability partnership agreement in case of LLP/Income Tax Assessment order in case of Proprietorship.
2)

Firm registration, participant must have registered under service tax registration certificate.

3)

Authorized partner of M/s IBM for supply of IBM software.

4)
A self-certified letter by the authorized signatory of the bidder that the bidder has not been blackl
isted by any Central/ state government (Central/ State Government and Public Sector) or under a declarati
on of ineligibility for corrupt or fraudulent practices as on bid submission date, must be submitted on origi
nal letter head of the bidder with signature and stamp.
5)

The bidder should have an operational office in Delhi or NCR.

6)
The estimated project cost of renewal of software licenses may around 1.95 cr. Accordingly, the
performance guarantees of Rs. 9,75,000/- shall be obtained from the vendor as per latest provisions of GF
R (OM no. F.1/2/2023-PPD datd 03.04.2023 issued by the Ministry of Finance, GOI).

4/6

<!-- page 5 -->

7)
TD.

The renewal of the license should be in the name of Excise, Entt. & Luxury Tax Department, GNC

8)
IBM active support should be available back to back for the above products supplied by the succ
essful bidder in the contract and supporting documents for the same should be provided for releasing of re
spective payments.

9)
.

The bidder should extend necessary onsite support as and when it is required by the Department

10)
Updates/Subscription services: The product update/subscription services should be provided to th
e Department with rights to IBM product upgrades, maintenance releases and patches released during the
ATS period.
11)
Product Support: IBM product support services to be offered to the department for direct access v
ia both the telephone and the web to IBM skilled staff of technical analysts for problem resolution, bug rep
orting, and technical guidance on a 24x7 basis. This service should be provided through telephone, e-mail
and direct connection to IBM web interface without any limitation.
12)
The bidder has to extend support and carry out all the installation/re-installation and configuratio
n/re-configuration and integration, if required, as per the requirements of application.
13)
t.

The selected bidder should implement the required patches/ updates at no cost to the Departmen

.
4. Buyer Added Bid Specific ATC
Buyer uploaded ATC document Click here to view the file .

Disclaimer/अ वीकरण
The additional terms and conditions have been incorporated by the Buyer after approval of the Competent
Authority in Buyer Organization, whereby Buyer organization is solely responsible for the impact of these clauses
on the bidding process, its outcome, and consequences thereof including any eccentricity / restriction arising in
the bidding process due to these ATCs and due to modification of technical specifications and / or terms and
conditions governing the bid. Any clause(s) incorporated by the Buyer regarding following shall be treated as
null and void and would not be considered as part of bid:1. Definition of Class I and Class II suppliers in the bid not in line with the extant Order / Office Memorandum
issued by DPIIT in this regard.
2. Seeking EMD submission from bidder(s), including via Additional Terms & Conditions, in contravention to
exemption provided to such sellers under GeM GTC.
3. Publishing Custom / BOQ bids for items for which regular GeM categories are available without any
Category item bunched with it.
4. Creating BoQ bid for single item.
5. Mentioning specific Brand or Make or Model or Manufacturer or Dealer name.
6. Mandating submission of documents in physical form as a pre-requisite to qualify bidders.
7. Floating / creation of work contracts as Custom Bids in Services.
8. Seeking sample with bid or approval of samples during bid evaluation process.
9. Mandating foreign / international certifications even in case of existence of Indian Standards without
specifying equivalent Indian Certification / standards.
10. Seeking experience from specific organization / department / institute only or from foreign / export
experience.
11. Creating bid for items from irrelevant categories.
12. Incorporating any clause against the MSME policy and Preference to Make in India Policy.
13. Reference of conditions published on any external site or reference to external documents/clauses.

5/6

<!-- page 6 -->

14. Asking for any Tender fee / Bid Participation fee / Auction fee in case of Bids / Forward Auction, as the
case may be.
Further, if any seller has any objection/grievance against these additional clauses or otherwise on any aspect of
this bid, they can raise their representation against the same by using the Representation window provided in
the bid details field in Seller dashboard after logging in as a seller within 4 days of bid publication on GeM. Buyer
is duty bound to reply to all such representations and would not be allowed to open bids if he fails to reply to
such representations.

This Bid is also governed by the General Terms and Conditions/ यह बड सामा य शत के अंतगत भी शािसत है
In terms of GeM GTC clause 26 regarding Restrictions on procurement from a bidder of a country which shares a land border with India, any bidder from a country which
shares a land border with India will be eligible to bid in this tender only if the bidder is registered with the Competent Authority. While participating in bid, Bidder has to
undertake compliance of this and any false declaration and non-compliance of this would be a ground for immediate termination of the contract and further legal action
in accordance with the laws./ जेम

पर

क सामा य शत के खंड 26 के संदभ म भारत के साथ भूिम सीमा साझा करने वाले दे श के बडर से खर द

ितबंध के संबंध म भारत के साथ भूिम सीमा साझा करने वाले दे श का कोई भी बडर इस िन वदा म बड दे ने के िलए तभी पा

जब वह बड दे ने वाला स म

होगा

ािधकार के पास पंजीकृ त हो। बड म भाग लेते समय बडर को इसका अनुपालन करना होगा और कोई भी

गलत घोषणा कए जाने व इसका अनुपालन न करने पर अनुबंध को त काल समा

करने और कानून के अनुसार आगे क कानूनी कारवाई

का आधार होगा।

---Thank You/ ध यवाद---

6/6
