---
doc_id: "bedc767cdf75e33f"
source_url: "https://forest.delhi.gov.in/sites/default/files/forest.delhi.gov.in/tender/tender_1.pdf"
ministry: "Forest Department, Delhi"
title: "Tender Document"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "04f8f79aa49b9b1e"
---

<!-- page 1 -->

GOVT. OF NCT OF DELHI
DEPARTMENT OF FORESTS & WILDLIFE
OFFICE OF THE PRINCIPAL CHIEF CONSERVATOR OF FORESTS
2ND FLOOR, VIKAS BHAWAN, IP ESTATE, NEW DELHI-110002
A-BLOCK,
Charging System/2022-23/
SHORT TERM

II 191 —90

Dated

NOTICE INVITING QOUTATIONS

Notice inviting quotations (NIQ) is hereby issued for inviting quotations from the
authorized firms/dealer/supplier for work for installation of Charging System for charging
of Electric Vehicle at ITO Nursery, Department of Forests & Wildlife, Govt. of
NCT Of Delhi. The details of Work are as under:

Sr.

Total
Qty./Unit Rate
in INR Estimated

Work Details

Cost

(INR)

1.
2.

3.

electrical

supply MCB 01 nos.
hea
du
Board 4 011 200 am
Electrical 63 amp. Power supply 04 nos.
MCB (Main Circuit Board) for
char in su I unit
MCB (Main Circuit Board) panel 01 nos.

Main power

box for electrical
•unction

4.

5.

6.

power supply

Copper 2 Core PVC Wire 65 mtr
cable main supply to charging hub
station
10 mm Electrical thimble patti 40 pcs
copper for ower suppl •unction
Main MCB (Main Circuit Board) 63 03 nos.
Am 04 ole •unction box
08
thimble patti copper 20 pcs
mm
electrical
supply
for
power
10 mm

.

7.

•unction

8.

Main supply
fittin

9.

10.

electrical

installation

PVC pipe 50 mtr

10 mm silver thimble patti for 20 pcs
I to •unction
electrical su
electrical
supply 01 time
Main

labour
char es

power
installation
junctioning

(*rate should be in the format"

Rate/cost

of item/work+ GST as applicable")

The quotation and documents should be sent in sealed cover
Department of Forest's and Wildlife, Govt. of NCT of Delhi"

Ln..(Next

in

favour of the

working day in case of Govt. Holiday) and the same will be opened
on the same day at 02:30 PM by the Purchase Committee. The rate should be quoted and
GST should be indicate separately as per the prevailing GST Laws. Quotation received
after stipulated date and time will not be accepted/entertained and summarily will be
rejected, in case any dispute, the decision of the PCCF/HOD, A-Block, 2nd Floor, Vikas

<!-- page 2 -->

Bhawan, IP Estate, New Delhi-110002 should be final and binding.
TERMS & CONDITIONS OF THE NIQ
Submission of quotation shall amount to bidder's acceptance of the terms and
conditions of the tender by the bidder.
2. Mode of payment would be subject to satisfactory completion of work/supply and
1.

its verification.

Bidder shall quote the rates against this NIQ on a 'single responsibility' basis
("Rate/Cost of item/work+ GST as applicable") so that the quotation price covers
contractor' all obligations and liabilities. The rates and prices quoted by the Bidder
shall be inclusive of all Charges/Taxes. The rate quoted shall be responsive and the
same should be inclusive of all statutory obligations.
4. The bidder should be from NCR and should be registered with/Trade & Taxes
Department, Govt. of NCT of Delhi and should quote their GST Registration No,
allotted by the Department of Trade & Taxes, Govt. of NCT of Delhi, and PAN No.
allotted by the Income Tax Department, Govt. of India.
5. The Dy. Conservator of Forests (HQ) reserves the right to accept and reject
any or
3.

6.

7.

cancel any or all the tenders/quotations without assigning any reasons therefore.
The rates quoted by the firm/agency shall remain valid for the entire period of
current Financial Year i.e. upto 31.03.2023 for the subject work and the
Department shall not be responsible for payment of any extra on account of
escalation of costs during the said period.

The department shall not be responsible for payment of any compensation on
account of any loss caused to the bidder/tender/quotation due to natural calamities
or other supervening impossibilities.
8. The firm/agency abide by the provisions made under the labour laws/GST and other
relevant Statutes as applicable in execution of the work and shall be responsible for
making good/payment of compensation, if any, to any workman or material during

execution of the contract.
case of any dispute arising out of the execution of the term & condition of this
short term quotation or part thereof, the decision of the DCF (HQ), Govt. of NCT of
Delhi shall be final and binding on both the parties. In the event of the disputes still
remaining unresolved, the appeal shall rest with the PCCF/HOD, Dept. of Forests &
Wildlife, GNCTD of Delhi whose decision shall be final and binding
on both the
parties.
10. All disputes arising out of the execution of the
agreement shall be s bj ct to the
Delhi.
of
the
jurisdiction
Court at
9. In

(Abhinav Kumar)

DY. CONSERVATOR OF FOREST (HQ
Charging System/2022-23/

LIDS") —9 0

Dated

1.9

Copy to:
1. The DCF (HQ)-Chairman-Purchase Committee,

Department of Forests & Wildlife,

GNCTD.
2. The Store In-Charge, Department of Forests & Wildlife, GNCTD.
3.
Programmer, Department of Forests & Wildlife, GNCTD with request to upload it
on the Forest website in Public Interest.
4. HQ-Notice Board for the notice of firms/agencies/workshops interested.

(Abhinav Kumar)

DY. CONSERVATOR OF FOREST (HQ)
