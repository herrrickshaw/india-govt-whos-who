---
doc_id: "f0edfae83eca8f57"
source_url: "https://colart.delhi.gov.in/sites/default/files/Colart/circulars-orders/dfa_result.pdf"
ministry: "College of Art, Delhi"
title: "Diploma (DFA)"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "d38a545700b1879c"
---

<!-- page 1 -->

os GOVERNMENT OF NATIONAL CAPITAL TERRITORY ©F SELHI
: COLLEGE OF ART, 20-22 TILAK MARG, NEW DELHI
कि OS SEL eee ee eee NEN | | | | | || झआझआझआझआझआ|आयआ३॥३/३$३$३$३$आ० ०9०9/ऑ/ऑस्‍ऑू्ऋ्ऋ्फऑ॒झऔख
Final Result of BFA Painting (DFA)
Sr. No. Candidate | Father’s Name Category Gender COA Total Remarks
Name | (450) .
|
fh धर ae
(2 2/87
Prof. (Dr.) Sanjeev Kumar
Principal/HOD
