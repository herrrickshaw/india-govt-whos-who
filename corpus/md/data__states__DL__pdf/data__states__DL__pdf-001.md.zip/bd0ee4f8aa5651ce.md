---
doc_id: "bd0ee4f8aa5651ce"
source_url: "https://ifc.delhi.gov.in/sites/default/files/ifc/tender/niqcdxix2210.pdf"
ministry: "Irrigation and Flood Control Department, Delhi"
title: "Tender Document"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "aa436eae7986acc5"
---

<!-- page 1 -->

OFFICE OF THE ASSISTANT ENGINEER-III CIVIL DIVISION NO. XIX,
GOVT. OF NCT OF DELHI IRRIGATION AND FLOOD CONTROL DEPARTMENT
BASAIDARAPUR OFFICE COMPLEX, OPPOSITE E.S.I HOSPITAL, DELHI- 27.
No. AE-III/CD-XIX/NIQ/2025-26// 92 Dated: 22/ lo /2¢
NOTICE INVITING QUOTATION
Sealed quotations are invited on behalf of President of India from by the Executive Engineer, Civil
Division-XIX, I&FC Department, Govt. of NCT of Delhi, Basaidarapur, Delhi-0027 for the following work,
so as to the undersigned on or before 27.0.2026 by 03.00 PM.
The quotation shall be opened on same day at 03:30 PM
Name of work: Development of Surajmal Park at Chhawla island on Najafgarh Drain, Delhi.
Sub work: Providing detailed Structural & Architectural Design & Drawing, preparation
of detailed estimate including proof checking for the work - Development of
Surajmal Park at Chhawla island on Najafgarh Drain, Delhi.
Sl. | Item Qty. | Unit | Rate Amount
No.
l. | Providing detailed Structural & Architectural | | JOB
Design & Drawing, preparation of detailed
estimate including proof checking for the work -
Development of Surajmal Park at Chhawla island
on Najafgarh Drain, Delhi, including | soil
investigation, preparation of detailed architectural
drawings, structural design and drawing including
all plumbing, electrical, furniture and any other
fitting details complete in all aspects with detailed
item-wise estimate for each and every item
including carrying out changes as required during
the execution period.
l. The intending firm shall submit following documents duly attested along with application failing
which their application shall not be considered for issue of quotation documents.
Certificate of Registration of GST
Copy of PAN card.
2. Undersigned reserves right to reject/cancel application without assigning any reasons.
3. The work is of urgent nature and to be completed within i.e. l5 days only.
ASSISTANT See
No. AE-III/CD-XIX/NIQ/2025-26/ Dated:
Copy to:
l. Executive Engineer/CD-XIX for information and necessary action.
ASSISTANT ENGINEER-III
