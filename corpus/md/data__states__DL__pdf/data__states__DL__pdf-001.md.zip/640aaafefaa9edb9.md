---
doc_id: "640aaafefaa9edb9"
source_url: "https://excise.delhi.gov.in/sites/default/files/Excise/tender/e-tender_cl.pdf"
ministry: "Excise, Entertainment & Luxury Tax Department, Delhi"
title: "Tender Document"
date: ""
pages: 46
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "80d8bffefecbaac5"
---

<!-- page 1 -->

EXCISE
ENTT. &
LUXU RY TAX
DE PARTMENT
GNCTD

Page 'lof46

<!-- page 2 -->

TENDER ISSUING DATE: 28.01.2026

Tentler lssuitt rAu thoritv

Page 2of46

<!-- page 3 -->

DISCLAIMER
Tax,
This TENDER is not an offer by Department of Excise, Entertainment and Luxury
proposals/e-bids from
Govemment of NCT of Delhi but an invitation to receive electronic
Act, 2010
interested and eligible distilleries/bottling plant under Rule 48 of Delhi Excise
not
for supply of country Liquor in NCT of Delhi. Mere participation in the e-tender shall
imply that the bidder will be a license holder and the award of license obligations
whatsoever shall not arise from the Tender process.

This e-tender is being issued with no financial commitment and Department of Excise,
ciange
Entertainment and Luxury Tax reseryes the right to withdraw the e-tender and
or vary any part thereof or foreclose the same at any stage'

Page 3of46

<!-- page 4 -->

Abbreviations

1

DD

Demand Draft

DSC

Digital Signature Certificate

EMD
Government of National Capital Territory of Delhi

4.
5.

L-1

Lowest

6.

lndian Standards

7.

Letter of acceptance of the tender

8.

Maximum Retail Price
NCT

National Capital Territory

NIC

National lnformatics Center

NIT

Notice lnviting Tender

12.

PAN

Permanent Account Number

13.

WAP

Weighted Average Price

IP

lmport Permit

TP

Transport Permit

ENA

Extra Neutral Alcohol

9.

16.

Page 4of46

<!-- page 5 -->

-

Cateoories of licenses

-

S.No.

i

orm

1

L-3

2

L-33

rses

License for wholesale supPlY of Country Liquor
NCT of Delhi

Page 5of46

<!-- page 6 -->

NOTI CE INVITIN G TENDE R (NIT)
Tender Reference No.: Exc-AO13/5l2O25lCL tTendel2126-27

W: B'l1frb

The Department of Excise is going for e-tendering for procurement of country Liquor
NCf of Oetni. Tenders in piescribed format, are invited from working distilleries or
grant of three.or. more
bottling plant duly licensed by central or a state Government for
ti""n.ir' in the form of L-3 under Rule 48 of Delhi Excise Rules, 2010 for wholesale
(L€) in bottles
suppiv ot countrv Liquor of 50 degree under proof (U.P.) to retail vends
-of
period
1d April' 2026
from
the
7ib'#f , SZS.r .nO iAO mt in the ratio of
to 31.t'March, 2027.The EMD details and timeline of lnvitation for e-bids are as under:
in

llilduring

Excise Commissione

T delhi.gov.in
Govt. of t{CT of Delhl

DEPARTMENT OF EXCISE,
ENTERTAINMEN
& LUXURY TAX,L & N BLOCK, VIKAS
BHAWAN, I.P.ESTATE, NEWDELHI-1 I OOO?
Phone:0'l 1 -23378370, 23370868
E-Mail: dcexciselat]nicldot]in

Grant of license (L€) for wholesale supply of country Liquor in NCT of Delhi for
lhe year 2026'27

Earnest Money DePosit (EMD)

Demand draft or pay order issued by Scheduled
Commercial Bank for Rs. 30,00,0001 (Rupees
Thirty Lakh only) drawn in favor of Excise
eamest money'
Commissioner, Delhi
alongwith receipt of physically depositing the
same in the Excise Department.

as

This EMD will be refunded if the applicant does
not win the bid. lf the applicant does not accept

the license after winning the bid within the
stipulated time frame, the EMD amount shall
stand forfeited.

I

The EMD is payable through demand draft issued
by a Scheduled Commercial bank in favor of
Excise Commissioner, GNGTD.
Scanned copy of the demand draft as the case
shall be uploaded on e-procurement portal by the
bidder.

Page 6of46

<!-- page 7 -->

Date of Publishin of the
e-Bid Submi ssion Start Date and
Time
e-Bid Submission End Date and
Time
Technical qualification b id
opening date and time

Financial bid oPen ing date and
Time

Website for downloading the
Tender Document, Conigendum's,
Addendums etc.
Contact person
name and
contact details

28.01.2026
28.01.2026
18.02.2026 (uPto 1'l:

AM )

't8.o2.2026, 12:00 Noon

To be intimated later on
lnterested candidates can download the tender
Document from:
n
hi.
re
fl
(Excise/
G. M.
ISS
ioner
Comm
Name: Assistant
(Excise)
Address: Department of Excise, Entertainment
and Luxury Tax, L & N Block, Vikas Bhawan'
l.P. Estate, NewDelhi-1 1 0002.

Phone No.: 011- 23378089
ln case, a pa rti cr pa nt la S to depos it o ngt n a co pv of dem an d d raft ssued by
Sched u led Com m ercial ban k ln fa vor of Exci se Com m ISS one r G NCTD for 225
payable at De thi AS the case m ay be o n or before 1 R 02 .2026 up to 1 1 00 AM b id
tha parti c pa nt sh al be rejected

All the tenderers are requested to have digitral certificate and get themselves reg.islered
with the application service provider of NlC. The application service provider of rulQ q1
be contacied for registration, training (if required) on any working day between 9.30 AM
to 6.00PM at:
HELP DESK
e-tendering SYstem
6thFloor, C-Wing, Vikas Bhawan-ll
(Near Metcalfe House), Civil Lines,

DELHI-1100tr
(Monday-Friday 9.30 AM to 6.00 PM)
Telephone No-01 1 -23813523

Page 7of46

<!-- page 8 -->

1. INTRODUCTION
l'tTheDepartmentofExciseisgoingfore-tenderingforprocurementofCountry
LiquorinNCTofDelhi.Tendersinprescribedformat,areinvitedfromoperational
distilleriesorbottlingplants,dulylicensesbyCentraloraStateGovemment,for
grantofthreeormorelicensesintheformofL.3underRule43ofDelhiExcise
proof (U'P')
iules, 2010 for wholesale supply of Country Liquor of 50 degree under

toretailvends(L-8)inbottlesofT50ml,3T5mlandlS0mlintheratioof3:4:3
duringtheperlodfromldApril,2025to3l3tMarch,2O2T'TheholdersofanL-3
licenseshallalsoberequiredtoobtainalicenseintheformofL.33forthebonded
warehouse.

of NCT of Delhi
'1.2 The licensing period may be extended by the Govemment
(hereinafterreferredtoasthe.Government')initssolediscretionforaperiodnot
exceeding three months beyond 31'03'2027 ' However' in extraordinary
the licensing
circumstalnces, the Govemmeni may in its sole discretion' extend
periodforanotherthreemonthsbeyond30.06.202T.Thelicensee(s)Shallhaveto
pay pro-rata license fee in respect of such extended period' if any'
1.3

to the provisions
Licenses in Form L-3 and L-33 for the said period shall be subject
the
of the Delhi Excise Act, 2009 (hereinafter refened to as the 'said Act") and

Rulesframedandordersissuedthereunder.TheseTermsandConditions,unless
orders
repugnant to the express provisions of the said Act and Rules made and
orders
and
made
issued thereunder, shall be in addition to the said Act and Rules
to liquor'
issued thereunder and any other law in force in the NCT of Delhi relating

ApplicantsareadvisedtoacquaintthemselveswiththeprovisionsofthesaidAct'
Ruies made and orders issued thereunder, before submitting their tenders

since

theyaredeemedtobeincorporatedinthistenderasiftheywereexpresslySetout
herein.
financial
for grant of license for wholesale supply of country liquor in NCT of Delhi

and
1.4 The Government is floating this 2 cover tender having technical bid

bid

through e-tendering process with the annual license fees'
1.5

is
The total quantity of country liquor to be supplied by the holders of L-3 Licensees
50
expected to be 300 Iakh liters subject to variation upto plus or minus 25o/o o',f
the
degree under pr*f (Up) ordinary spiced caramel coloured country liquor during

licensingperiod'lncase,thelicensingperiodislessthan.l2months,theannual
quantitmentioned above will be allocated on monthly pro-rata basis. The licensees
will be iequired to sell country liquor to the L-8 vends owned by Delhi Tourism and
&
Transportation Development Corporation (DTTDC), Delhi State lndustrial
lnfrastructure Development corporation (DSllDC), Delhi state civil Supply
Ltd
corporation (DSCSC) and Delhi consumers co-operative wholesale store
Page 8of46

<!-- page 9 -->

L{

license (retail
(DCC\ /S), or any other organization which may be holder of
liquor (L-8
vends of Country liquor). The present number of retail vends of Country
ot oelhi is 83, which may vary during the licensing period. The
licensees) in
the
holders oi L-3 licensees shall not be entitled to any compensation or relief on
ground that a particular number of retail vends were not established or operated'

Hit

TheWeightedAveragePrice(WAP)ofthecountryliquorinthelastfiveyearsisas

1.6

under:-

Licensing year

Weighted Average Price (WAP) per case/09
lite r in Rs.

I

20t'7-18

287.00

2

20t8-l9

307.00

J

20t9-70

4

2020-21

5

202t-22

6

2022-23
2023-24
2024-25

307.00/302.00
3s9.00/348.00
37s.00
411.00

S.

No

I

'7

8

451 .00

00

2.oVERvIEwoFELIGIBILITYREQUIREMENTFoRPARTICIPATIoNIN
TENDER/ HOLD LICENSE IN FORM OF L-3

2.lAlicenseinformL-3andL-33shallonlybegrantedtoaD|ST|LLERYora
BOTTLING PLANT, duly licensed by the Central or a State Govemment'

of country
2.2 The applicant should have minimum experience of manufacturing/bottling
liquor previous three years (i,e.2o22-23,2023-24 & 2024.25,), duly authenticated by
plant is
the concerned Excise Authorities of the State in which the Distillery/Bottling
situated
2.3 Tenders from only those entities shall be considered who are eligible

for holding

to
license under Section 13 of the Delhi Excise Act, 2009. Applicants are advised
provisions in this
refer to Section 13 of the said Act and acquaint themselves with its
regard
the
2.4 Tenders will not be accepted from persons who are restricted under Rule 23 of
Delhi Excise Rules, 2010 which are deemed to be incorporated herein'
2.5 No person, his partners, afiiliate companies, agents, employees, or dependent
members of his family shall be eligible, jointly or severally to hold alongwith L-3/ L-33
License, licences of the following categories.

L4, L-5, L-8,L-22,L-25,L-26, L-34' L-35' and another L-3 licence'

Page 9of46

<!-- page 10 -->

3 TERMS AND CONDITIONS FOR GRANT OF WHOLESALE SUPPLY OF
couNTRY LIQUOR (LA) LrcENSE

L-3/33 licenses for the wholesale supply of 50 degree under proof country Liquor to
NCT of Delhi shall be granted by inviting tenders in the enclosed form (Annexure'l)
for the ration 3 : 4 : 3 in respect of size of bottles of 750 ml, 375 ml and 180 ml
respectively. The Terms and conditions for the grant of wholesale license for supply

of Country Liquor ln GNCT of Delhi are summarized as under:

3.I LICENSE FEE
3.1.1 The fee payable in respect of L-3 and L'33 licenses shall be as underi

(i) L-3 (for wholesale license of Country Liquor) : Rs. 7,00,0001 (Rupees Seven
Lakh only) for the entire licensing period.
(ii) L-33 (for Bonded Warehouse license ol Country Liquor):- Rs' 1,00,000/- (Rupees
One Lakh only) for the entire licensing period.

3.2 GRANT OFLICENCE:'
3.2.1 L-3/L-33 licenses for the wholesale supply of 50 degree under proof country.Liquor
to NCT of Delhi shall be granted by inviting tenders in the enclosed form
(Annqxue4l for the ratio I : l: g in respect of size of bottles of 750 ml, 375 ml and
180 ml resPectivelY.

g.2.2 All the application for the grant of L-3 license shall be subject to the. acceptance by
the competent Authority who may accept or reject any application without assigning
any reason. The licensing authority shall be under no obligation to grant any licence
for which application has been made.
3.2.3 lf on scrutiny, any application is found incomplete, vague, confusing or -not as- per
Terms and iondiiions, the same shall be summarily rejected and the decision of the
Commissioner Excise shall be final'

3.3 TENDER PROCESS FOR GRANT OF GRANT OF WHOLESLAE SUPPLY OF
COUNTRY LIQUoR LICENSE (La):-

3.3.1 License for wholesale supply of country Liquor in NCT of Delhi will be allotted
through a two cover e-tender process comprising of Technical qualification and
Financial bid.
Page 10of46

<!-- page 11 -->

Staqe -1 Technical Evaluation of b

rs: -

All the bids received on e-procurement portal of NCT of Delhi for wholesale

supply of country liquor in NCT of Delhi for the year 2026-27 , shall be evaluated by
Technical Evaluation committee in accordance with the documents sought in clause
3.4.2 0f the tender document. Thereafter, the tenders found in order shall be allowed
to participate in financial bid.
- 2 : Financia I Evalu ation of bidders:-

(As per
provided in (Annexure-V) will be opened in the presence of participating

(i) (a) All the Financial bids received on e-procurement portal of NCT of Delhi

iro-forma

bidders/Authorized Representatives of the bidders'

(b)costSheetofeachsizeofWeightedAveragePrice(WAP)soughtalongwith
supporting documents of various cost components viz' ENA purchase invoices'

providing
Transport receipts, Glass bottles purchase invoices etc. (as per pro-forma
in (Annexure-Vl) to be uploaded in Financial bid cover.

(ii)ToensurethatthesupplyofcountryliquorinDelhiisnotdependentonanyone

supplier, it shall be ensured that no tenderer gets quota more than 33% of the total
quota i.e. 300 lakh liters. However, the tenderers, who have offered to supply less
than 1O% of the total quantity, will not be entertained'
(iii) (a) The bidder quoting minimum WAP per case will be treated L-1'
(b) The L-1 bidder shall be offered 33% annual supply quota'

(c)OnacceptanceofaquotaspecifiedbytheL'lbidder,remainingannual
supply quota shall be offered to other bidders in the following manner:All the bidders have to matc+t the lowest bidder's WAP'
ln case any of the bidders does not accept the L-1 bidder's quoted

1.
2.
3.
4.

WAP, it's bid will not be considered.
After allocating the quota to the L-1 bidder, remaining bidders
agreeing to supply at the L-1 rate, shall be offered the balance
quota in the equal proportions bases on their individual production
capacitY.

ln case, any bidders is only willing to supply lesser percentage of

quota, its remaining share shall be offered to other willing bidders in
equal ProPortion.

(iv) (a) ln case more than one bidder (s) quotes the same lowest wAP per case, the
Page I 1of46

<!-- page 12 -->

bidder offering to supply higher percentage supply quota shall be treated as L-1

(b).lncase,morethanonebidder(s)quotesthesamelowestWAPandoffersto
supply same percentage of supply quota, the L-1 shall be decided through conduct
lottery.

of

Negotiations with the successful bidder:'
(v)(a)TheGovemmentmayappointaCommitteetonegotiatewiththetenderers
rates and quantities to be supplied with the purpose of obtaining country liquor

at the

lowestpossiblerates.TheCommitteemaydoso,subjecttoverificationofthe
capacityofthetenderertosupplythecountryliquor,basedonproductioncapacity
and past performance i'e. fulfillment of supply orders placed by the Excise
be
Departrnent during the previous licensing period(s)' The Committee shall
of rates
required to short list the tenderers for negotiations, in the ascending order
(to
quoted; upto a point where 100% of the quantity of country liquor required is met

becomputedonthebasisofquantityquotedinthetenderbythetenderers).only
SuchShort-listedtenderersshallbecalledfornegotiationsbeforetheCommiftee.
rates and
Negotiations with such short-listed tenderers would be both on the
quantities which they can supply. Based on the final rates quoted by each' after
tenderer
such negotiations in ascending order (and quantities finally offered by the
after negotiation), the Committee shall recommend placing of orders on such
is met' To
tenderers upto the point where '100% requirement of the country liquor
any one
ensure that the supply of country liquor in Delhi is not dependent on
the
supplier, it shall be ensured that no tenderer gets orders for more than 33% of
than 10% of
total supplies. However, the tenderers, who have offered to supply less

totalquantity,willnotbeentertained.Notwithstandingtheabove,ifatanypointof
time, the negotiation committee feels that in the interest of getting the desired
quantityofcountryliquoratthebeslprices,itrequirestonegotiatewithoneormore
of the other tenderers as well, it may do so for reasons to be recorded in writing.

(b)lncase,anyofthetenderers,whosetenderisacceptedforaspecificproportionof
the total supply required, is not in a position to supply the entire portion of supplies
of
allotted to him for any reason whatsoever, then the Government in the interest
maintenance of supplies, may vary the proportion of allotment made to the other
Page 12of46

<!-- page 13 -->

Supplie(S)withthe@nsentofsuchothersupplier(s)totheextentof20%ofthe
total requirement on the same rates as already approved'

9.4. PROCEDURE TO APPLY:3,4.lTheapplicantapplyingforgrantofL.3licenseshallparticipateine.tenderprocesson
e-procurement portal of GNCT of Delhi'

3-4.2Theapplicantshallberequiredtosubmitthefollowingdocumentsalongwiththe
application:a. Demand draft or pay order issued by Scheduled Commercial

Bank for Rs'

3O,OO,OOO/.(RupeesThirtyLakhonly)drawninfavorofExciseCommissioner'
same in
Delhi as eamest money, alongwith receipt of physically depositing the
the Excise Department.

.No Dues Certificate" in favor of the tenderer issued by the Dy. Commissioner
(Excise), GNCT of Delhi after the date of issuance of this tender notice'
b.

c.Anaffidavitdeclaringthattheinformationgiveninthetenderformistrueand
correct and that no fact has been concealed there from'

d.Trueattestedcopyofvaliddistillerylicenseorbottlingplantlicenseissuedby
theExciseAuthorityoftheStateinwhichtheDistillery/BottlingplanUunitis
situated.
e. Document showing permitted installed capacity for the manufacturing
quantity
country liquor. The installed capacity should be g!4!mum two'times the

of

ofcountryliquorproposedtobesuppliedtoDelhiinthetenderdocumentofthe
tenderer.

f."NoDuesandCrcdibititfcertificateregardingpastperformanceofproduction
and supply from the Excise Authorities of the state in which the Distillery/Bottling
planuunit is situated.

g.ConsentoftheExciseAuthoritiesoftheStatewhereDistillery/Bottlingplantis
;ituated for supply of country Liquor from their state to the National capital
Territory of Delhi in which the capacity of the Distillery/Bottling plant should be
clearly mentioned.
h. A statement indicating the maximum quantity of Country Liquor that
supplied to Delhi by the tenderer from each of its units'
i. "No Dues Ceftificate' from the GST Department of GNCT of Delhi'

Page 13of46

can be

<!-- page 14 -->

j.AnaffidavitdeclaringnoviolationofC/ause2.SoftheTenderdocument.

k'Anafiidavitwithregardtoqualificationsforgrantoflicenseasprescribed
under Section 13 of the Delhi Excise Act,2009.

l. Duly filed Annexure'l
m. Aftested copy of Permanent Account Number

(PAN) card in case of

proprietorship firm/ partnership firm/Limited Liability Partnership (LLP)/Company
incorporated under the Companies Act, 1956.

(tender shall contain
it is
the names of all the partners & no such tender shall be entertained unless
partnership deed
signed by all the partners and is accompanied by copy of the
Registered
ou-ly attested by Gazetted fficer), Registration certificate in case of
be'
may
case
Company/Limited Liability Partnership (LLP) firm etc' as the
n. Copy of the partnership deed in case of partnership form

o. Copy of Attomey executed in favor of Agent.

p'Copyofnotification/orderofExciseAuthorityconcemedinrespectofExport
pass fee and bottling fee.
q. The duly filled checklist as per Annexure{vi Pre-qualification criteria shall be

uploaded along with the documents/undertakings.
r. Price Bid.

s. All pages of the documents submitted by the bidder shall be signed by the
authoizedsignatoryandshallatsobeaffixedwiththeapplicantentity,sstamp.
t. The registered bidder shall also be required to sign, scan and upload all
of this tender document acknowledging the following:-

pages

(i) The bidder accepts all the lerms and conditions as per the tender
document and shall be bound to comply with the same'

(ii)BidderorhisassociateiSfamiliarwithandunderstandsthee.tender
process on website and has the technical knowledge and human
resources to participate in e-tender process.
(iii) Bidder has access to hardware and internet connectivity for
participating in e-tender process'

(iv) The onus of online application and submission of genuine, stipulated
documents during registration lies on the bidder.
(v) ln case of any grievances arising in course of the e-tendering process,
the Bidders shall abide by the decision of the Excise Commissioner'
Page 14of46

<!-- page 15 -->

3.5 EARNEST MONEY DEPOS]T.
(EMD) of
3.5.1 The Bidder shall fumish, as part of his bid, an Earnest Money Deposit
by a
Rs. 30,00,000/- (Rupees Thirty Lakh only) by means of demand draft issued
for 225
scheduled commercial bank in favour of Excise commissioner, GNCTD
days payable at Delhi.

(i)IhesaidDemandDnftshoutdbeissuedfromtheapplicantbiddefsbank
a,ccount only. Scanned copy of the Demand Draft as the case may be'

shall be
The
uploaded by the bidder as part of the eligibility/participation requirement.
physical copy of the receipt of deposit of EMD through Demand Drafi' as the case

maybe,shallbedepositedbythebidderinthecountryLiquorBranch,Excise
Department before the prescribed date and time, No bidder is exempted from
furnishingthesaidEMD.ThecurrencyoftheEMDshallbelndianRupees(lNR)
only.Further,incaseofvalidityofDemandDraftsubmittedasEMDexpiresand
procedures
tendef is still to be awarded in respect of the bidders, the following
shall be followed:-

l.DemandDraftsubmittedwithavalidityofthreemonthsfromthedateof
issuance,shallbesubsequently,revalidatedandre-submittedbythebidder.
The cost of such revalidation shall be borne by the applicant bidder'
No
3.5.2. Bids received without the EMD shall be rejected outright as non-responsive.
further communication from the bidder, in this regard, shall be entertained by
Department of Excise.

3.5.3 No interest shall be payable by Department of Excise for the sum deposited as
EMD.

3.5.4 The EMD shall be forfeited in the following cases:
(i) Any information submitted by the bidder is found to be inconecUforged'

(ii) lf bid is withdrawn during the validity period or any extension agreed by
Department of Excise and Bidder thereof.
(iii) lf the bid is modified in a manner not acceptable to Department of Excise after
opening of the bid.
(iv) lf the bidder tries to influence the evaluation process'

3.5.5 ln case of unsuccessful bidder, earnest money deposited will be released on
request from the bidder on a date subsequent to the grant of license to the
successful bidder.

Page 15of46

<!-- page 16 -->

3.6. RIGHTS OF DEPARTMENT OF EXCISE lN REGARD TO e'TENDER
3.6.1 lf on scrutiny, any application is found incomplete, vague, confusing or

not as per

TermsandConditions,thesameshallbesummarilyrejectedandthedecisionof
the Commissioner Excise shall be final.

3.6.2TheGovernmentreseryestherighttoacceptorrejectanyoralltenders'including
thelowestonewithoutincurringanyliabilitywhatsoever.Nolicenseeortenderer
shall be entitled to any compensation or relief on the ground of any delay or nonI

grant of license for any reason whatsoever.
3.6.3 After a tenderer is declared successful, if it refuses to accept the supply order,

or, if

afteracceptingsupplyorder,itfailstomakesuppliesforanyreasonwhatsoever'
the earnest money deposited by such tenderer shall be liable to be forfeited.

I

3.6.4 The Govemment may require a tenderer whose tender is accepted for supply of
any portion of the total required supply of country liquor to execute a written
agreement at his own cost with the Government for the Licensing Period and shall
also take all requisite action to complete all formalities required for the grant of a
licence within seven days calculated from the day on which he is asked to do so,
and if he does not do so, all deposits made by him shall stand forfeited to the
Government and he shall not be entitled to any compensation and the licence
may be re{endered or granted in any other manner.

3.7. SALE HOURS & DRY DAYS :'
3.7..1 No liquor shall be sold on the days notified as 'Dry Days',as per the

provisions of
Rule 52 of the Delhi Excise Rules, 2010. The working hours of the Bonded
warehouse and the working hours of the retail vends of country liquor will be such
as may be specified by the Excise Commissioner, Delhi from time to time' The
holders of L-3 license will not be entitled to any compensation or any other relief
due to any increase in the number of 'Dry Days' or due to any change in the
working hours of the Bonded warehouses and/ or retail vends during the course of
the Licensing Period. The business premises of a licensee shall be kept closed on
all dry days: PROVIDED that the Assistant Commissioner may, by order in writing
permit a licensee to deposit liquor in his premises, or to open the premises for any
work other than sale, on a dry day on prescribed fee.

Page 16of46

<!-- page 17 -->

3.8. PERFORMANCE SECURITY DEPOSIT:3.8.1EachL-3/L-33licenseeshallsubmitsecuritydepositas"Performancesecuritv",
which will be 7o/o of I he amo unt of contract awarded to the L-.3 license.
lllustration:
lf an L-3 licencee has been awarded 10% of the quota i.e. t0% of 300
then his performance security amount will be as follows:

(i)
(ii)
(iii)

lakhs litres

Licence granted quota of 10% for the year : Approx' 03'33 lakh cases
'X'
Approved Rate per case after finalization of Tender proceedings:
*
Performance Security = 'X' " 03'33 lakh 7%

in the
3.8.2 This aforesaid performance security shall be deposited with the Government
shape of Fixed Deposit Receipt from a scheduled commercial Bank at Delhi/

NewDelhi.Further,alongwithperformancesecurity,apersonalbondalongwith
suretyoftheSameamountwillalsobesubmifted.Theformatofpersonalbondis
annexed herewith at Annexure I

3.9 OTHER CONDITION OF THE LICENSE:3.9.1 The holders of L-3 license shall supply ordinary spiced caramel coloured country
liquor of the strength 50 degree under proof meeting all the requirements of
Rule 7 of the Delhi Excise Rules 2010. Further, the country liquor So supplied
should be ENA based, and

(a) The Country liquor supplied by the licensee must be fit for human
consumption and strictly adhere to the specifications referred to in this
tender document.
(b) the country liquor must be duly ce(ified by the competent laboratory of
the stale in whose territory the distillery / bottling plant of the licensee
is located failing which no further import permits shall be issued by the
Government; and

(c) The country liquor imported by the licensee into NCT of Delhi shall be
subjected to tests and analysis to be conducted by the Govemment
and no supply to retail L4 vends shall be made if the test reports
indicate that the liquor is not potable or flt for human consumption'

Page 17of46

<!-- page 18 -->

of

supplies released from Bonded
(d) The payment on account
Warehouse which have been received safe and sound at the retail
vends will be made by DTTDC, DSllDC, DSCSC' DCCWS and/or
other holder (s) of L€ license.

3.9.2 (a) The supply of country liquor shall be procured in Glass boftles only'
ml and
The size of bottles for the supply of country liquor shall be 750 ml' 375
180 ml as Per details given below:
750 ml - 30o/o of the total supply in bottles (by volume);
375 ml - 40% of the total supply in bottles (by volume);
180 ml - 30% of the total supply in bottles (by volume);

tnotherwords,theratioofbottlesofTSOml,3TSmlandls0mlshallbe!!i3,.
quote the
(b)
Quotation of price in Bottles The tenderers are required to
'to*".trat"fortheSupplyof12countryliquorbottlesofT50mleach(9bulk

-

litre)andaSeparaterate,ifany,forthesupplyof24countryliquorbottlesof
375 ml each (9 bulk litre) and separate rate, if any' for the supply of
rate shall
50 country liquor bottles of 180 ml each (9 bulk liter). The tendered
production,
be all inclusive and shall inter.alia include all component of cost of
bottling, labeling, freight, export pass fee and duties, taxes, etc but should
not include 'local transportation charges' as per Rule 66 (4) (b) of the Delhi
Excise Rules, 2010.

(c) Local transportation charges will be allowed @ Rs'2'50 per case to the L-3
licenses. The same shall be charged by L-3 licensees from the L-8 Licensees
in addition to the wholesale price'

(d) The tenders for the purpose of comparison will be ananged in ascending
order on the basis of 'Weighted Average Price' as calculated below:
ITENDERED
3'OENDERED 4'(TENDERED
gBL
gBL
PRICE FOR 9 BL
PRICE FOR
PRICE FOR
COUNTRY
COUNTRY OF
OF COUNTRY
++OF
LIQUOR IN LIQUOR IN LIOUOR IN
BOTTLES OF BOTTLES OF BOTTLES OF
180m1')
375m1.)
75oml)
10

Page 18of46

<!-- page 19 -->

lllustration

bottles of 750 ml'
Suppose the tendered price for the supply of country liquor in
375 ml and 't 80 ml per case of 9 L is 'x', 'y' , and 'z' respectively'
Then, Weighted average price of country liquor = (3x+4y+3zy't 0

3.9.3

Specification of Boftles:of country liquor shall be transparent'
1ij. Tne Uotttes that will be used for supply
Uncolouredandofpuccaglassmanufacturedonfullyautomaticmachine,bearingno

markingwhatsoever,andshallbeasperRule69(1)&69(2)oftheDelhiExciseRules
size i.e same height for

ZO1O. ine bottles shall be glass bottles of standard uniform

each quantity i.e. 750 ml, 375 ml & 180 ml'.

The height of the bottle shall be

Quarts: 27 cm with a variation ofl 0.25 cm
Pints: 19 cm with a variation of !0.25 cm
Nips: 15 cm with a variation of L 0.25 cm

(ii)Nocountryliquorinbottlesotherthanthoseconformingtospecifications
describedinClause3.g.3(i)aboveshallbeacceptedunderanycircumstances,
except with the prior written permission of Excise Commissioner and deduction
from the Licensee,S bills of such amount as the Excise commissioner may
specify, shall be made and the decision of Excise Commissioner in regard to
such deduction shall be final and binding on the licensee'

(iii) The decision of Excise commissioner as to whether or not any bottles

conform to the above mentioned specifications shall be final and binding on the
licensee.

(iv)lqBEl-S
The label on each bottle of country liquor shall be as per the provisions of the

Rule69(3)oftheDelhiExciseRules,2010,andshaltalsobearthenameof
Printer and number of labels printed.
(v)
1D&2DSe rialized Bar Code
'lO & 2D serialized Bar Code on Cases
Th e licensee shall be required to affix
an d Botfles respectively which will be procured by the licensees at their own cost'

Further, 15 paise per barcode downloaded from the Excise Central Data Centre
(for all i.e. Quarts, Pints, Nips and Cases) excluding Service Taxi GST will be
of
recovered from the licensees by the Department. Thus, for a case consisting
Page 19of46

<!-- page 20 -->

quarts, pints and nips the cost of bar codes will work out as Rs' 1.95' Rs' 3'75
and Rs. 7.65 per case respectively.

The licensee shall provide necessary lT infrastructure in regard to scanning of
EALs for doing retail sale.

Further, the cost of bar code generation/affixation and other related costs
including service tax/GST shall be borne by the Licensee.

(vi) ADEOUATE ARRANGEMENTS TO RUN EXCISE eABKARI PORTAL
BASED ON 2D

The licensees are required to make the arrangement of the following in
Bonded Warehouse to run Excise Department 'eAbkari portal'.
Operating System, Anti Virus (with
Latest Specs Desktop with Win
latest patches).
UPS for adequate capacity to support equipment in case of power

'll

(i)

(ii)

shutdown.
(iii)

High speed Broadband lnternet Access with Wi-fi enablement in the

(iv)
(v)
(vi)

operating area
Laser/lnkjet printer
Bar Code Printer
Adequate Number of Hand Held Terminals (HHTs) as per specifications*

S.No

Activity
l

Parameters

lP Receiving for a < = 500 cases per hour
window of 4 hours

1

HHTs
req u ired
1

(2.00pm to 6.00 pm)

-l

I

I

I

I

>500and<=1000

2

>1000and<='1500

3

>1500and<=2000

4

>2000and<=2500

5

>2500and<=3000

6

>3000and<=3500

7

>3500and<=4000

8

Page 20of46

<!-- page 21 -->

TP Dispatch for a < = 250 Case
window of 2 hours

2

1

(1'l:00m to 1:00 pm)

>250and<=500

2

>500and<=750

e

>750and<=1000

4

>1000 and <= 1250

t

>1250and<=1500

6

>1500 and <= 1750

7

>1750and<=2000

8

>2000 and <=2250

o

>2250and<=2500

10

>2500 and <=2750

11

>2750and<=3000

12

>3000and<=3250

13

>3250 and < =3 500

14

>3500and<=3750

15

>3750and<=4000

16

>4000 and <= 4250

17

>4250and<=4500

'18

>4500 and <= 47 50

19

>4750and <= 5000

20

I

I
I
I

I
I
I

I
I

I

(vii) Consumables as per specs, paper, labels, ink, etc as per specmcation*
(viii) Adequate Number of Trained Manpower to manage simultaneous
operations

(ix) DesKop for Excise lnspector at BWH with Broadband lnternet Access'
':- Specification and details of models in case of HHTs and paper, labels, ink etc
may be obtained from the Department.
Page 21of46

<!-- page 22 -->

(vii)

CARTONS

The country liquor of prescribed specifications shall be duly bottled,
corked and sealed and shall be transported after being duly packed in New
Cartons of 5 Dlv card board to the bonded warehouse of the licensee. ln no
case old, used or damaged cartons of different brands will be used for the
purpose of packing. Each carton packed as one case shall contain exactly 12
bottles of 750 mlot24 bottles of 375 ml or50 bottles of 180 ml

(viii) Country Liquor shall not be accepted under any circumstance in cartons
other than those specified in clause 3.9.3 (vii) except in cases where prior
written approval of the Excise Commissioner has been obtained for other type of
cartons. However, permission will be granted by the Excise Commissioner
subject to payment of such amount as the Excise Commissioner may deem fit.
Decision of the Excise Commissioner in this regard, shall be final and binding on
the licensee.
lses mention ed in ooint 3.9. 3 above will attract a Denaltv.
An V violation of the
to be decided b v the Dv. Commissioner (Excisel in order to act as a deterrent.

3.9.4 The licensed premises for establishment of Bonded Warehouse for storage of
country liquor shall fulfill all the requirements as laid down in Rule 86 of the Delhi
Excise Rules, 2010. ln addition to the requirements specified there, it should
have two openings, proper electrical fittings and adequate fire safety
equipment's/arrangements as prescribed by the Delhi Fire Service. The licensed
premises shall also be insured against fire and other natural hazards

4.

SCEHDULE OF IMPORT PERMITS

4.1

The licensee shall import potable country liquor manufactured in its
distillery/bottling plant into the National Capital Territory of Delhi on payment of
duty or on execution of a Bond on a non-judicial stamp paper of Rs.100/- in
respect of allocation for each month. The bond submitted should clearly
indemnify the Government against any loss of duty in excess of what is permitted
in Rule 100 of Delhi Excise Rules,2010 with reference to monthly allocation.
The format of the bond is annexed herewith at Annexure lll. The licensee shall
supply country liquor for retail vends. The licensee shall, however, store it in the
Bonded Warehouse till the instructions of its delivery to different vends is given
by the Deputy Commissioner (Excise) from time to time.

Page 22d146

<!-- page 23 -->

4.2 (a) The Deputy Commissioner (Excise) will sanction monthly allocation of country
liquor and on the basis of this sanction, G.M. (Excise) will issue monthly
allocation letter in accordance with the supply ratio determined in terms of Clause
3.2.1 specifying the date(s) by which particular quantity shall be supplied and the
licensee shall supply the quantity so ordered every month. The allocation letters
for a particular month shall normally be issued by 20h day of the preceding
month by G.M. (Excise). However, in order to meet any unforeseen demand, an
additional order upto fifteen days requirement may be placed with the approval of
Excise Commissioner at any time. The licensee shall arrange the supplies as per
the lmport Permits issued, which will generally be in such a way that atleast 25%
of the monthly requirement reaches the Bonded Warehouse by the 7th day of the
month, 50% by the 15h day of the month, 75% by lhe 22d day of the month and
' the entire requirement reaches the Bonded Warehouse before the normal closing
hours of the Bonded Warehouse on the last day of the month.
(b) No import permit (lP) for import of country liquor into Delhi shall be valid after
the date of its expiry, provided that the Deputy Commissioner (Excise) may
extend the period of validity thereof, on payment of fee as hereinafter provided, if
extension is applied owing to delay in transit of a consignment or for any other
sufficient reason. Further, the revalidation fee as aforesaid shall be in addition to
the penalty payable under clause (c) for default in weekly supply.
Period of Delay

NoI
1

2.

4

Revalidation Fee
Payable

Delay of one day in transit of a consignment (consignment
reaching after the normal closing hours of the BWH on the
last date of validity of lPs shall be treated as one day delay)

Rs.'10/- per case

Delay of two days

Rs.15/- per case

Delay beyond two days

Rs.20/- per case

Revalidation of unexecuted permits

Rs.50/- per case

(c) lf the licensee fails to make supply of the quantity of country liquor required
to be supplied by the stipulated date as specified in Clause (a) above, he shall be
liable to pay a penalty for the defaulted quantity Rs.50l- per case of country liquor.
ln case of failure to pay penalty as aforesaid, the same shall be recovered out of
the security deposit of the licensee or from the payment due to him from the L-8
licensees. However, if the supply has been defaulted due to reasons beyond the
control of the licensee then the Deputy Commissioner (Excise) will be at liberty to
waive off the revalidation fee and the penalty to be imposed. The decision of the
Deputy Commissioner (Excise) as to whether the reasons for default were beyond
Page 23of46

<!-- page 24 -->

the control of the licensee will be final and binding on the licensee.
4.3

Each licensee shall always keep such minimum bufier stock of country liquor at a
time at the Bonded Warehouse as may be prescribed by the Excise
Commissioner. The licensee shall build up buffer stock to the e)dent of 50% of
the first month's supply order of the country liquor within one month of the grant of
the licence. Failure to maintain the buffer stock shall make the licensee liable to
pay a penalty upto Rs.0.50 per case per day for the days the licensee had failed
to maintain the buffer stock. However, if the licensee does not maintain the buffer
stock because of certain e)itra orders placed by the Government for supplies to
retail vends, he shall not be liable to pay any penalty because of non-maintenance
of the buffer stock. lf the licensee fails to maintain the buffer stock then the
supplies to retail vends shall also be reduced in the same proportion by which he
has failed to maintiain the buffer stock.

4.4

The payment on account of supplies released from Bonded Warehouse which
have been received safe and sound at the retail vends will be made by DTTDC,
DSllDC, DSCSC, DCCWS and/or other holder (s) of L-8 license, if any, at the
wholesale rate plus local transportation charges as approved by the Government.

4.5 The truck(s) utilized by the licensee for transport of the country liquor from his
distillery to the Bonded Warehouse shall not be utilized for delivery of country
liquor from Bonded Warehouse to the retail vends. ln other words, the fleet of
vehicles utilized for movement of country liquor from the distillery to bonded
warehouse shall be entirely different from the fleet of vehicles used for movement
of country liquor from bonded warehouse to retail vends.

4.6 lf the licensee or his employee(s), agent(s), servant(s), etc. infringe(s) or cause(s)
or permit(s) any person to infringe any of the conditions of the licence, the
competent authority may revoke and determine the licence. The licence is also
liable to be revoked and determined, if the licensee furnishes or discovered to
have furnished any wrong information or makes any misrepresentation of facts at
any stage.
5

PROHIBITION:-

5.1

ln pursuance of the Directive Principles of State Policy relating to Prohibition
contained in Article 47 of the Constitution of lndia, the Government may issue
orders and directions from time to time and such orders and directions shall be
binding on the licensee and no compensation shall be payable on this account.
The licensee shall in the meantime, abide by the following Prohibition measures:

(i)

The licensee shall not display any neon or glow sign in and around the
Page 24ot46

<!-- page 25 -->

licensed premises to attract the customers.

(ii) The licensee shall display a notice board prominently in front of the
licensed premises declaring that'DRINKING OF LIQUOR lS INJURIOUS
TO HEALTH"

(iii) All persons employed by the licensee in the licensed premises shall be
required to possess photo identity cards issued under the signature of the
Dy. Commissioner (Excise) and the employees shall be required to
produce the identity cards on demand by the Excise Officer not below the
rank of Sub-inspector.

(iv) The licensee shall strictly abide by the provisions of Rule 26 to 31 of Delhi
Excise Rules,2010 and shall not keep, publish, display and distribute or
sell any advertisement material, which directly or indirectly promotes the
sale or consumption of liquor.
6
6.'r

PENALTY PROVISIONS:lf the quantity ordered by the Deputy Commissioner (Excise) on monthly basis,
whether in part or in while, is not supplied by the licensee at the last date by
which the supplies should have been made for three consecutive months in the
tender year, the licensee is liable for payment of penalty andior face action
as per the below mentioned manner:S. No.

1

Penalty/Action

Percentage of default from total
monthly allocatlon (in last three
months)

Revalidation fee of Rs. 50 per case

Upto 10 %

and/or Penalty of Rs. 50 per case.
2

Revalidation fee of Rs. 75 per case

11-25 0/o

and/or Penalty of Rs. 75 ger case.
I

3

I

More than 25o/o ol lhe allocation for last

Revalidation fee of Rs. 100 per case

three months

and/or Penalty of Rs. 100 per case

I

4

I

5

More than 25o/o ol lha allocation for three Revalidation fee of Rs. 110 per case
months (1st quarteo and suc@ssive and/or Penalty of Rs. '110 per case
defaults for next three months (in 2d and/or Suspension/Cancellalion of the
quarter)

license.

Variable defaults in last three months

Average default in percentage of last
three months shall be calculated and
case shall be processed as mentioned
above.

Page 25of46

<!-- page 26 -->

Further, in addition to above, if the penalty imposed by Dy. Commissioner
(Excise) as mentioned above is not paid by the licensee, penal action prescribed
under the Delhi Excise Act, 2009 and Rules and orders issued thereunder for
violation of the provisions of the said Act and Rules like issuance ot Recovery
Notice to DM concemed, Excise Black llstlng etc. shall be initiated against the
I

licensee. The decision of Dy. Commissioner (Excise) as to whether the cause of

I

defaulUfailure was on account of good or sufficient reasons shall be final and
binding on the licensee.

6.2

The licensee shall have to pay the breakage duty in regard of breakage in a
month by vhof the succeeding month. Ihe default in payment of breakage duty
will aftract interest as per clause 6.3 (y'. Any default will aftract additional penalty,

as decided by the Dy. Commissioner (Excise), which can be maximum upto 5
times of default in the breakage duty.

6.3

(i) The licensee shall pay simple interest at the rate of l27o oer annum on the
amount due from the date next following the day on which such payment become

due from him under Section 30 of the said Act until the date on which such
payment is actually made or such amount is actually recovered whatever may be

the reason for the delay in the payment or recovery.

(ii) The licensee shall not be entitled to any interest or any other relief or
compensation, on ac@unt of any delay in the payment of any amounl due to him
by the Departmenucorporation or the Government.

7

PROCEDURE FOR LEFTOVER STOCK:-

7.1

lf at the end of the licensing year, the licensee has country liquor stock in his
bonded warehouse, which are allowed to be sold through retail vends in the new
licensing year a.e. 2027-28, the payment in respect of these stocks shall be made
at the wholesale rale of 2027 -28 or 2026-27, whichever is ,ower. However, the
local transportation charges mentioned in Clause 3.9.2 (c) will remain the same.

Page 26of46

<!-- page 27 -->

I
8.1

8.2

MISCELLANEOUS TERMS AND CONDITIONS:Notwithstanding anything contained/provided herein above, the Government
keeping in view the public interest and revenues may give directions or pass
orders in connection with any matter pertaining to the terms and conditions, and
the directions so given or orders so passed in this regard shall be final and
binding on the tendere(sylicensee(s).
ln the event of any failure on part of the licensee to observe any of the terms and
conditions, the security deposits made by the licensee in respect of the L-3
Licence shall stand forfeited, to the extent as may be decided by the Excise
Commissioner.
DISPUTE RESOLUTION:-

8.3

(i) Any disputes arising out of this tender shall be governed as per Delhi Excise
Act, 2009 and Delhi Excise Rules framed thereunder and Terms and Conditions
and other orders/ directions issued by the Department of Excise from time to time
and shall be subject to jurisdiction of Courts of NCT of Delhi.

(ii) All disputes and differences arising out of or in any way touching or
concerning this indenture (except those decisions whereof is othenrise provided
for herein before or in the Delhi Excise Act,2009 or rules framed or orders issued
thereunder) shall be referred to the sole arbitration of any person nominated by
the Govemment. There will be no objection to any such appointment that the
arbitrator is a Government servant. The award of the arbitrator so appointed
shall be final and binding on the parties.

(ii) No proceedings shall initiate in court of law before the conclusion of such
arbitration proceedings.
8.4

The Government reserves the right for mid-term review and accordingly change
the percentage of quota fixed for the licensee(s) as well as change the ratio of
quarts, pints and nips on the basis of inputs from the stake-holders, which
includes Department of Excise, L-3 licensees and Corporations (L€ licensees) or
any other organization holding L-8 licenses, if any. The decision of the
Commissioner of Excise in the matter will be final and binding on all the stakeholders.

8.5

The grant of L-3/L-33 licence shall be subject to provisions of the Delhi Excise
Act 2009, rules framed and notification/orders issued there under and
acceptance of these terms and conditions as a whole. The provisions of the
Delhi Excise Act, 2009, the Delhi Excise Rules, 2010 and all notifications'
Page 27ot46

<!-- page 28 -->

instructions and orders issued thereunder shall be deemed to form integral and
inseparable part of the tender document as if they were expressively set out in
the tender documents itsetf. Tenderers are advised to access department
website in order to acquaint themselves with the act and rules.

9 PREPARATION AND SUBMISSION OF BIDS lN A TWO COVER TENDER:9.1 Language of Bid: The bid document prepared by bidder, as well as all

correspondence and documents relating to the e-Bid exchanged by the bidder
and Department of Excise shall be written in English only.

9.2

e-Bid Currency: The prices quoted in the financial bid shall be in lndian Rupees
only. Financial bid in any currency other than lndian Rupees (lNR) shall be
treated as non-responsive and hence shall be rejected.

9.3 Submission of e-Bid:
9.3.1 The bid submission module of Delhi e-tender procurement website
<<hftos://oovtorocu ment.delhi.oov.in>> enables the bidders to submit the eBid online in response to the E-Tender published by the Department of Excise.
9.3.2 Bid submission can be done only from the bid submission start date and time till
the bid submission end date and time given in the E-TENDER. Bidder should
start the bid submission process well in advance so that they can submit their
e-Bids in time.

9.3.3 The bidder should submit their e-Bid considering the server time displayed in
thee-tender website <<https://qovtDrocu ment.delhi.qov.in>>. This server time is
the time by which the e-Bid submission activity will be allowed till the permissible
time on the lasUend date of submission indicated in the e-Bid schedule.
9.3.4 Once the e-Bid submission date and time is over, the bidder cannot submit his
e-Bid. For delay in submission of e-Bid due to any reasons, the bidder shall only
be held responsible.
9.3.5 The bidder must follow the following instructions for submission of their e-Bid:

i)

For participating in e-Bid through the e-Bidding system, it is necessary for
the bidder to be the registered user of the e-tender website
<<https://oovtorocurement.delhi.oov.in>>. The bidder must obtain a user
login lD and password by registering himself with Delhi Government eprocurement portal/e-tender website if he has not done so previously for
registration.

ii)
I

ln addition to the normal registration, the bidder must register with his/her
the e-Bidding system and
digital signature certificate (DSC)
to
carry
out his/her e-Bid submission
subsequently he/she will be allowed

in

Page 28of46

<!-- page 29 -->

activities. Registering the digital signature certificate (DSC) is a one-time
activity. Before proceeding to register his/her DSC, the bidder should
firstlog on to the e-Bidding system using the user login option on the
homepage with the login ld and password with which he/she has
registered.

iii) For successful registration of DSC on e-tender website
<<httos://oovtprocurem >the bidder must ensure that
he/she should possess class-2/class-3 DSC issued by any certifying
authorities approved by controller of certifying authorities, Govemment of
lndia, as the e-tender website<<https://oovtorocurement.delhi.qov.in>>is
presently accepting DSC issued by these authorities only. The Bidder
can obtain user login lD and perform DSC registration exercise given
above even before the e-Bid submission date starts. The DEPARTMENT
OF EXCISE shall not be held responsible if the Bidder tries to submit
his/her e-Bid at the moment before end date of submission but could not
submit due to DSC registration problem.

iv) The bidder is advised to familiarize himself with all the processes and
procedure for submission of the e-bids by going through the relevant
rta L
nt.delhi.
.tn
sections onh sJ/ o

9.3.6 Deadline for submission of e-Bid : E-Bid (Pre- qualification, Technical and
Financial) must be submitted by the bidder at e-tender website
<<httpsJ/govtprocurement.delhi.gov.in>> not later than the time specified on the
the e-procurement
prescribed date (as the server time displayed
extend
this deadline for
may,
at
its
discretion,
Excise
website).Department of
submission of e-Bid by issuing and publishing a corrigendum on Department of
Excise's website and e-tender website, in such case all rights and obligations of
the Department of Excise and the bidders previously subject to the deadline will

I

in

thereafler be subject to the deadline as e).tended.

I

10

LATE BID

10.1

The server time indicated in the bid management window on the e-tender
rocurement.d hi.oov.in >>will be the time by which the ewebsite<<https://
Bid submission activity will be allowed till the permissible date and time
scheduled ln the e-Bid.

10.2 Once the e-Bid submission date and time is over, the Bidder cannot submit
his/her e-Bid. Bidder must start the bid submission well in advance so that the
submission process passes off smoothly. The Bidder will only be held
responsible if his/her e-Bid is not submitted in time due to any of his/her
problems/faults, for whatsoever reason, during e-Bid submission process.

Page 29of46

<!-- page 30 -->

11 WITHDRAWAL OF E-BID
11.1 At any point of time, a Bidder can withdraw his/her e-Bid submitted online before
the bid submission end date and time as per the procedure laid down on Delhi eprocurement portal<<httos://oovtorocurement.delhi.qov.in>>.However, the
participation fee in such cases shall be forfeited.

11.2 No e-Bid shall be withdrawn in the interval between the deadline for submission

of e-Bids and the expiration of period of e- bid validity. withdrawal of an e-Bid
during this interval may result in the forfeiting of EMD.

12 RIGHTS OF DEPARTMENT OF EXCISE IN REGARD TO E.BIDDING
12.1 Notwithstanding anything contained in this e-Bid, Department of Excise
reserves the right to accept or reject any Bid and to annul the Selection Process
and reject all Bids, at any time without any liability or any obligation for such
acceptance, rejection or annulment and without assigning any reason thereof'

12.1 The Department of Excise reserves the right to reject any Bid, if:

i. At any time, any misrepresentation is made or uncovered, or
ii. The Bidder does not provide, within the time specified by Department of
Excise, the supplementary information sought by Department of Excise for
evaluation of the e-Bid.

.12.2 Such misrepresentation/improper response may lead to the disqualification of
the Bidder.

13 PERIOD OF VALIDITY OF E.BID
13..1 e-Bid shall remain valid for 180 days from the bid submission due date/end date
as prescribed by the Department of Excise. An e-Bid valid for a shorter period
shall be rejected by the Department of Excise as non-responsive.

13.2 ln exceptional circumstances, Department of Excise may solicit the Bidde/s
consent to an extension of the period of e-Bid validity. The request and the
response there to shall be made in writing .A Bidder may refuse the request
without forfeiting its e-Bid security. A Bidder granting the reguest will not be
required nor permitted to modify its e-Bid'
13.3

Department of Excise will make its best effort to evaluate the bids and grant the
license within this period. lf Departrnent of Excise wishes to extend the validity
period of the bids, the Bidders who do not agree, Department of Excise shall
have the right not to e)dend the validity of their bids'
Page 30of46

<!-- page 31 -->

14 AMENDMENTS lN e-TENDER DOCUMENT
'14.1 Department of Excise may, in its absolute discretion, but without being under any
obligation to do so, update, amend or supplement the information in this eTENDER document.

14.2 Al any time prior to the deadline for submission of the bids, Department of Excise
may amend the e-TENDER document by issuing addendum/corrigendum without
notifying any Bidder or without giving any reason. Any addendum issued shall be
part of the bidding document and shall be communicated by the Department of
Excise on Department of Excise website and e-procuremenU e-tender websites.
ln case of issuing addendum/ corrigendum, the last date of bid submission may
be extended by Department of Excise, if felt necessary.

14.3 Prospective Bidders shall promptly acknowledge such addendum/ corrigendum
thereof, in writing via email or fax. Department of Excise will bear no
responsibility or liability arising out of non-receipt of the same in time or otherwise
by the Bidder.

14.4 the Bidders are requested to refrain from requesting extension of time on any
grounds since the same will not be entertained by Department of Excise.

14.5 No clarification obtained through verbal communication by the Bidder with any
employee of Department of Excise will be deemed as addendum/corrigendum to
this e tender document. The Bidder acting on such a verbal communication will
do so at his own risk and Department of Excise shall bear no responsibility for
any outcome arising out of this.

15 COMPLIANCE WITH MANDATORY REQUIREMENTS
All bids will be reviewed for compliance with the mandatory requirements as
contained within the e-tender. Bids deemed non-responsive will be eliminated
from further consideration.

16 TERMS AND CONDITIONS OF BIDDERS
'16.1 Any terms and conditions of the Bidder will not be acceptable at any stage of
bidding process.

16.2 Any terms and conditions of the Bidders mentioned in the bid will not be
considered as a part of their bids and/or license.

Page 31of46

<!-- page 32 -->

E-m
-

17 DEVIATIONS IN TERMS AND CONDITIONS OF TENDER
17.1 No deviations in the terms and conditions as laid out in the e-tender will be
accepted.
17

.2 The Evaluation Committee overseeing the tender reserves the right to waive
minor irregularities.

17.3 Bidders are advised to exercise adequate care in quotlng the prices. No
modification/conection in the bids will be entertained after the bid submission
date.

I

I

Page 32of46

<!-- page 33 -->

Annexure.I
GOVERNME NT OF NATIONAL CAP ITAL TERRITORY OF DELHI
OFFICE OF TH E COMMISSIONER OF EX CISE. ENTERTAINM ENT & LUXURY TAX
L&NBLO CK. VIKAS BHAWAN, I.P. ESTATE, NEW DELHI-I1OOO2

TENDER FORM FOR OPERATING LICENCE IN FORM L-3 FOR SUPPLY

OF ORDINARY SPICED CARAMEL COLOURED 50 DEGREE UNDER
PROOF COUNTRY LIQUOR IN BOTTLES OF 750 ML., 375 ML. AND 180
ML DURING THE YEAR 2026.27

0 1 .04.2026 to 31.03.2027

I

Page 33of46

<!-- page 34 -->

l.

Name of the tenderer / Distillery/ Bottling
Plant (in block letters)

2

Address (in block letters)

I

I

State whether the Tenderer is:

3.

A body incorporated under the Indian

(a)

Companies Act: or

A society registered under Cooperative

(b)

Society Act or under Societies

Registration Act: or

I

(c)

A partnership concem or

(d)

A sole proprietorship

(e)

Name and address of the individual
who shall act as an agent on behalf or
the tenderer and his relationship with
company or the society. (Please
enclose a power of attomey executed
in favour ofthe agent.)

to

Afliliated company
any other
tenderer in this bid or not (Yes.4.,lo)
Ifa tenderer is a body incorporated under the Indian Companies Act or a Society registered under
the Co-operative Societies Act or under the Societies Registration Act, please enclose an attested
true copy of the registered Memorandum and Articles of Association (latest). Ifthe tenderer is a
partnership firm, please enclose a registered partnership deed or registered bye-laws, as the case
may be. Further, the tenderer is required to state :
(a)
Names and addresses
the
(f)

4

of

Managing Director and Directors of
company/President and Secretary of
the Society.

Name and address of the individual

(b)
I

I

who shall act as an agent on behalfof
the tenderer and his relationship with
the company or the society. (Please
enclose a power of attomey executed
in favour ofthe agent.)

Page 34of46

<!-- page 35 -->

(c)

Registration number of

the

Company/Co-operative Society (An
attested true copy of the rcgistr-ation
ce(ificate to be enclosed.)

If the tenderer is a sole proprietor firm or a

5

partnership concern, state the name/names
of the proprietor/partners comprising the
firm alongwith their addresses and the name

ofthe authorized agent with his address and
telephone numbers (please enclose a copy
of the attomey executed in the favour of the
agent. The tender document shall be signed
by all the partners in case of partnership
firms)
Does the tenderer has a branch office in
Delhi. If so, state its address and telephone
number and the name and address of the

6.

persons managing it.
7

l'

Location of the distillery/bottling

plant owned by the tenderer
alongwith the complete address,
name of Police Station. District and
State.

I

b)

State date of establishment of
distillery/bottling plant and grant of
the licence thereof (Enclose an
attested true copy of the distillery
licence/bottling plant license)

c)

Name of Distiller/Unit (s)/bottling
plant owned by the tenderer where
the ordinary spiced caramel coloured

country liquor will

be

manufactured./bottled and brought to
the Bonded Ware House in Delhi
(give complete address, particulars,
etc. ofeach of the uni s
Name:
l.
Police Station
Distt. & State
ll.
Name:
Police Station

Disft. & State
I

ll.

lv.

Name:
Police Station
Distr. & state
Name:
Page 35of46

<!-- page 36 -->

I

I

I

Police Station

I

d

Distt. & State
State date of establishment of the Unit(s) and grant of the licence thereof (enclose an
attested true copy in respect of each ofthe Unit(s) owned by the tenderer)
Name of
Date of Estsblishment

Unit

l.

ll.

lll.
lv.
e

Important Telephone Nos. of the distilleryfunit(s/bottling plant owned by the tenderer
Name of
Telephone Number (s)

Unit

I

ll.
I

Ill.
lv.

8

TOTAL CAPACITY
Installed Capacity (IC) of the distillery or bottling Plant and Actual Production (AP) of
country liquor during the last five years duly authenticated by the Excise Commissioner of
the State in which the unit is situated (Please specift in Kilolitre)
2017-18
IC.
AP-

IC.
IC2020-2t
IC2021-22
IC2022-23
IC2023-24
IC.
2024-75
IC.
Daily Boftling Capacity :

APAPAP.
AP.
AP.
AP.
AP-

2018-19

2019-20

B

Page 36of46

<!-- page 37 -->

The present strenglh oflabour force employed in the distillery

C

(l) Skilled
(2) Unskilled
(3) Casual
D

Quality control facilities and equipment available and insta lled in the distillery
enclose annexure with details.)

E

Enclose documents/proof in support of above data ( A to D)

(ifnecessary

Brand Name

9
I

750 ml
l:tsmt
GTII{ Details
Case GTIN
Bottle GTIN
Global Trade Identification Number
GTIN :

l0

a

I

l80ml

Whether any quantitative restriction has been placed by the Competent Authority (Excise)
in the production of country liquor by the distiltery/Units owned by the tenderer. If so,
whether it can be relaxed. Indicate the quantitative restriction distilleryAJnit(s) wise in
words as well as in figures
Relaxation
Distillery/lJnit(s) Quantitative
Name
S.
Restrictions
No. Bottling Plant

of

I

2
3

4

TOTAL
B

Indicate the quantity in percentage of total supply that the tenderer is willing to make at the
rate

him

S.

Name of Distillery/Unit(s)

No.

Bottling Plant

Approximate quantity per month for ioport into the
Bonded Ware House at Delhi (in

Q![$ as well as

in bulk li ter in words as well as in figures

I

2
3

4

TOTAL
C

Indicate the export pass fee levied by lhe state(s), UT(s) from where the country liquor
would be imported into the National Capital Territory of Delhi as on the date of submission
of tender (Enclose relevant copies of the notificatiorVorders of the Excise Authority
concerned in respect of export pass fee)
DistilteryAJnit(s) Export pass fee per bulk liter (in figures as well as
Name
S.
in words)
No Bottling Plant are located

of

I
2

Page 37of46

<!-- page 38 -->

J

4

il

Whether anv pe nal/ administrative proc eedings were taken against the Managemen t o f the
disti lery/U nl ( s ) bottling plants owned by the tenderer by any court or administra tlve
department for acts of om sslon and/or commlsslon If so, gr ve the parti culars and resu It
thereof. A No Obiection Certificate from the concemed State Govemment for ex port of
5 0 degree under proo country lquor to Delh should be enc losed

a

f

Whether levy and recovery of any Excise R evenue by the exporting State or by the
National Capital Tenitory of Delhi is under stay of court? If so, fumish the particulars.

b

I

t2

Name of the Bank, number and date of bank draft for deposit of earnest money of Rs.30,00,000/(Rupees Thirty lacs onlY)

l3

PAN No. (attach copy of PAN Card) :

lAVe have carefully read the tender notice and the terms and conditions and the provisions of the Delhi
Excise Act,2009 as in force in the National Capital Territo ry of Delhi and rules made thereunder for
ywe accept the same and are bound by them'
the grant of licence in form L-33 and L-3.

NAME AND SIGNATURE OF THE
TENDERER WITH SEAL OF THE
DISTILLERY/BOTTLING PLANT
PLACE:
D-ATE:

Page 38of46

<!-- page 39 -->

Annexure-II
Personal Bond with SuretY Bond
(To be executed by the successful tenderer)

Resd. Office at
is a successful tenderer under Ru le 48 of

Whereas IWs

Delhi Sxcise Rules,20l0 for a license in form L-3lL-33 for the year 2026'27

(O1.04.2026 ro

31.03.2027).

And whereas the aforesaid fWt
!T
o/o quota for the supply of country Liquor into the National capital
been offered
i"r.itory ot Oett iS. which we are required to fumish a personal bond with surety bond for

of

sum
o
(rupees
io, t fn@alities

Rs'_-

binding.ourselves
required for granting a license in

form l--g7L-33 within seven days from the date of communication ofoffer'

Now, therefore, the aforesaid lvl/
known as the tenderer) and

Director/S ecretary/Proprietor/Partner (hercinafter known as the surety) herebY
themselves jointly and severally to the President of India and agree that the aforesaid
for grant of a
tenderer shall take all the requisite action to complete a ll formalities required
terms and
and
licence in Form L-3lL-33 and observe all the provlslons of the Act, Rules

bind

conditi ons and that if he does not do so, without prejudice to any other actlon
of lndia
perTrnssl ble under law, all deposits made by him shall stand forfeited to the President
upees
and that a further sum of Rs.
shall also stand forfeited to the President of India.

as ls

It is also declared that this bond is given under the orders of the govemment for the
performance ofan act in which the public are interested.
WITNESS:
1.

S

Name and address of the tenderer
Stamp ofthe Ftm represented by the tenderer.

2

S

Name of Surety with complete address

Page 39of46

<!-- page 40 -->

Annexure -III

INDEMNITY BOND

Bonded

attomey of lvlls

I,

inafler
Warehouse situated at
India
a
sum
of
of
called the obtigator), hereby enter into the bond to the President

to be

(Rupees

Rs.

paid to the President oflndia.

Signed this

daY

of

month

of

vear.

The above bounder obligor having their license in Form L-3lL-33 is being permitted to

-

2026-27.

Now the condition of this written bond or obligation is such that the obligator shall, in the
event of loss suffered by the Govemment (in respect of which the decision of the
Govemment or the authority appointed for the purpose shall be final and binding on the
obligator) as a result ofany iirCumstance, foreseen or unforeseen, leading to non-realization
of Eicise revenue, pay to the Govemment the non-realized amount ofduty/excise revenue.
And these presents also witness that the liability of the obligator hereunder shall not be
impaired or / discharged by reason ofany forbearance, act or omission of the Government or
foi any time being granted or indulgence shown by the Govemment, (or by reason of any
changi in the consiinrtion ofthe obligator in cases where the obligator is not an lndividual).
In witness thereof the obligator has set his hand/has caused these presents executed by its
authorized representative, on the day, month and year above written.
WITNESS:
'1.

Sig[aturc of the Attomey
I

Accepted by me on the above date

Against I.P.
2

No._

Dated
for

Page 40of46

to

valid upto
cases

-

_

<!-- page 41 -->

An nexure-lV

Checklist of Bldder Ellgibility Grlteria
Checklist for Eligibility Criteria
(to be filled up by the bidder)
Sl.No.
1.

Speclfic

Basic
Requirement

Duly

filled

applicant details
as per

Annexure-l

Requlrem_ents
The applicant shall fill
all the basic details

Documents required Ps. YES/NO
No.
to be uploaded
Scanned copy of the

Duly filled applicant

per the details as per
information sought. Annexure-l
Further, the duly

as

fllled Tender Form

shall be signed and

stamped on each

page as

2.

EMD

deposition/submissio Order cum demand
n of

3

EMD

draft
Receipt.

Dues Scanned copy of No-

No Dues Certilicate Up to date No
Certificate in favor
in favor of the
the tenderer/bidder
tenderer/bidder
issued by Dy.
issued by Dy.

of DueS Certificate.

Commissioner
(Excise), GNCT of
Delhi.

4

an

acceptance of Terms
and Conditions of the
tender
of Scanned copy of Pay
Proof

Commissioner
(Excise), GNCT of

Delhi.
The duly filled Tender Scanned copy of
form shall be signed affidavit declaring that
declaring that the
information given in and stamped on each the information given
page as
tender form
in the tender form
(Annexure-l) is true acceptance of terms (Annexure-l) is true
and conditions of
and conect.
and conect.

An affidavit

an

5

o

True Attested copy
of valid distillery
license or bottling
plant license.

the
of
and

tender.
True attested copy
Scanned copy of true
valid distillery
attested copy of valid
bottling plant license distillery and bottling
showing the validity plant license.
of the license.

Document showing Document showing Scan copy of
permitted installed permitted installed document showing
capacity for the capacity (in cases) permitted installed
manufacture of for the manufacture capacity for the
Country Liquor
of Country Liquor manufacture of
Country Liquor
Page 41of46

<!-- page 42 -->

7

Statement indicating
Statement
indicating the actual the actual produc'tion

production and and suppty of
supply of Country Country Uquor (in
Liquor during the cases) during the last
last 03 years i.e. 03 years i.e. 2O222022-23,2023-24 &
23,2023-24 & 20242024-25.

8.

No Dues

and

Credibility
Certificate

?5.

No Dues and

Credibility C€rtificate
past
past performance ol
regarding
performance
of production and
production
and
from
from
supply
Excise
concemed
Excise
concerned
Authorities, where
Authorities
Distillery or bottling
plcqt iAsilullsd ___
q
Consent of Excise Scanned copy ot
Authorities of the Consent letter of
Stato where Excise Authorities of
Distillery/Bottling
State where
plant is situated
Distillery/Bottllng
plqlllis qilC?ted __
Statement indicating
10 Statement
indicating the
maximum
maximum quantity quantity of Country
of Country Liquor Liquor that can be
that can be supplied to GNCT of
supplied to GNCT Oelhi
of Delhi
11. No Dues Certificate Up to date No Duos
from the Trade and Certificate from the
Taxes Department, Trade and Taxes
GNCT of Delhi
Department, GNCT
of Delhi

regarding

supply

the

the

Scanned copy of the
document indicating
the actual production
and supply of Country
Liquor (in cases)
during the last 03
years i.e. 2022-23,
2023-24 &2024-25.
Scanned copy of No
Dues and Credibility
Certificate regarding
past performance of
production and supply
from concerned
Excise Authorities

Scanned copy of
Consent letter of

Excise Authorities of

the State where

Distillery/Bottling plant
is .situaled

Scanned

the maximum quantity
of Country Liquor that
can be supplied to
GNCT of Delhi
Scanned copy of Up

to date No Dues
Certificate from the
Trade and Taxes

Department, GNCT of
Delhi

12

Affidavit declaring an amOavtt AGdaring SAnned

-iopf - oi

no violation of no violation of Clause affidavit declaring no
Clause 2.5 of the 2.5 of the tender violation of Clause 2.5
tender document document for supply of the tender
for supply of of Country Liquor in document for supply
Country Liquor in lhe year 2O2*25

of Country Liquor in

lhe year 2024-25

13

copy

statement indicating

PAN

Copy of

PAN

Card/PAN number

. lhe yeat 2024-25.
Scanned copy of valid
PAN Card of applicant

Page 42c146

<!-- page 43 -->

14

Partnership deed
in case of
partnership firm
(tender shall
contain the names
of all the partners
and the
partnership deed
shall be duly
signed by all the
partners and No
such tender shall
be entertained
unless it is signed
by all the partners
and is

accompanied by
copy of the
partnership deed
duly attested by
Gazetted ofiicer),
Registration
certificate in case
of Registered

Partnership deed in
gase of partnership
firm (tender shall
,contain the names of
all the partners and
the partnership deed
shall be duly signed
by all the partners and
No such tender shall
be entertained unless
it is signed by all the
partners and is

accompanied by copy
of the partnership
deed duly attested by
Gazetted ofiicer),
Registration certificate
in case of Registered
Company/Limited
Liability Partnership
(LLP) firm etc., as the

15.

16

17.

Registered

Company/Limited

case may be duly
attested by Gazetted
Officer

True copy of
Registration

Scanned copy of true
copy of Registration

certificate of
Distilleryi Bottling
Plant

certificate of
Distillery/Bottling Plant

Attorney executed
in favor of Agent

Copy of Attomey

Scanned copy of
Attomey executed in
favor of Agent.

Notificatiory'order

Copy of

of Excise Authority
concerned in
respect of Export

Notification/order of
Excise Authority
concemed in respect
of Export Pass Fee

Pass Fee and

Boli1glqe_,
18

partnership deed in
case of partnership
firm (tender shall
contain the names of
all the partners and
the partnership deed
shall be duly signed
by all the partners and
No such tender shall
be entertained unless
it is signed by all the
partners and is
accompanied by copy
of the partnership
deed duly attested by
Gazetted
officer),Registration
certificate in case of
Liability Parhership
(LLP) firm etc., as the

case may be.

Company/Limited
Liability
Partnership (LLP)
firm etc., as the
case may be.
Registration
Certificate of
Distillery/Bottling
Plant

Scanned copy

An afiidavit with
regard to
qualification for
grant of license as
prescribed under
Section 13 of the

executed in favor of
Agent.

Ctq Bet[!4gfee _
Copy of afiidavit with
regard to
q ualifications for
grant of license as
prescribed under
Section 13 of the

Scanned copy of
Notification/order of
Excise Authority
@ncerned in respect
of Export Pass Fee

9{'! E9ttl!!s@
Scanned copy of
affidavit with regard to
qualifications for grant
of license as

prescribed under
Section 13 of Delhi

Page 43of46

<!-- page 44 -->

Delhi Excise

2009.

Act, Delhi Excise Act,

Excise Act,2009

2009

Page 44of46

<!-- page 45 -->

Annexure-V
Tender lnviting Authority :Excise Commissioner ,GNCT of Delhi
Name of License :e-Tender for grant of wholesale license for supply of Country Liquor in
NCT of Delhi for the ar 2026-27

Tender lD: 2026_EXC 285731-1
To be filled by the Bidder

Name of the Bidder/ Bidding Firm
pany:

PAEE$HEDUTE
(rh I s B OQ te m pl ate m US t not be modified/replaced by t he b idd e r and the same sh o u d
be u pl oad ed after fi I I ng the re leva n t co I u m n s el se the b d I s I a b le to b e rej ected for th IS
te nd e I B d de rs a IE a I lowed to enter th e B id der N a me a nd V a I u e S o n )
Quantity

Item

Description

No

Price per 9 BL (Bulk
Liter) of 50 degree

Total

Amount

Arnounl

(in Rs.)

(in Words)

equal to (3x+/+Y+32)/'10=
Rs. P.

I

1

Basic Rate (in figures) to be
entered by the Biddel
(Weighted Average Price)
(please sec clause 3.9.2 (d)
illustration thereot of the
tender document which ls

1.00

xxx

xxx

xxx

xxx

under prool (U.P.)

ordinary spiced
caramel coloured
country llquor in
bottles ot slze 750 ml,
375 mland 180 ml.

Total in Figures
Quoted Rate inwords

(lNR Zero only)

Page 45of46

<!-- page 46 -->

Annexure-Vl
(To be uoloaded in Financial bid cover)

Costing-Sheet with Glass Bottles (per case)
(in Rs.)

Particulars

Glass Bottles
Weighted Average
Price (WAP)
(in Rs.)

Country Liquor 50 degree under proof (U.P.) (2026-27)
Pints (375 ml) Nips (180 ml)
Quarts (750

ml)
Spirits (ENA) cost
D.M. Waterff lavour/Colour

I
I

Glass Bottles
Pilfer Proof Caps
Labels
5 ply Carton Box
Barcode

I

I

I

Labour

I
I

Factory Expenses
Freight (Delhi)

I

I

Warehouse Expenses

Expon Fee

I

Total

Page 46of46
