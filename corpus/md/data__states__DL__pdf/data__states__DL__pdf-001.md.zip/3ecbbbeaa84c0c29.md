---
doc_id: "3ecbbbeaa84c0c29"
source_url: "https://publicity.delhi.gov.in/sites/default/files/publicity/tender/nit.pdf"
ministry: "Directorate of Information & Publicity, Delhi"
title: "Tender Document"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8646756ff9afd3ad"
---

<!-- page 1 -->

F.No. 16(6)/2015-16/DM/DIP
TENDER FOR PUBLICATION OF TRILINGUAL MAGAZINES
DIRECTORATE OF INFORMATION AND PUBLICITY
GOVERNMENT OF NCT OF DELHI
BLOCK NO.IX, OLD SECRETARIAT, DELHI-110054
NOTICE INVITING TENDER FOR PUBLISHING AND DISTRIBUTION OF TRILINGUAL MONTHLY MAGAZINE
“DILLI ”
Last Date and Time of Bid submission

:

12/05/2016

12.00 PM

Technical Bid Opening Date and Time

:

12/05/2016

12.05. PM

Financial Bid Opening Date and Time

:

To be notified later

The Directorate of Information and Publicity, GNCTD intends to publish its Trilingual Monthly Magazine
(Hindi, Punjabi and Urdu) Dilli Masik carrying the articles, photos and information on various
activities/initiatives, schemes of Government of Delhi by a reputed and professional publishing house on
a turnkey basis. The agency/firm should have experience not less than three years of publishing
dispatching and distribution of Monthly/fortnightly/quarterly magazines or newspapers.
It is mandatory that the firm will have to submit online scanned copies of cover pages of at least five
published issues, dispatched and distributed among the readers.
Responsibilities of Agency/firm ……………
The M/s will have to distribute the magazines across Delhi in Schools, Hospitals, Dispensaries, Delhi
Public Libraries, Higher Educational Institutes, Residence/Office of Public representatives, Departments,
and other places as suggested by Directorate. The firm will have to quote single rate for publishing and
distribution of magazines and no extra payment will be paid to the publisher for distribution.
The firm will be responsible to disseminate the PDF of each issue of magazine at least 10 lakhs people of
Delhi by email under the intimation to this Directorate.
The agency/firms will have to quote separate rate for per page translation in Hindi, Urdu and Punjabi,
however, the work will be awarded on the basis of gross rate for publication of magazine.
CORRIGENDUM IN RESPECT OF THIS TENDER, IF ANY, SHALL BE UPLOADED ONLY ON THE ABOVEMENTIONED WEBSITE AND SHALL NOT BE ADVERTISED IN THE NEWSPAPER.
1. Scope of work
i)

Subject to over all supervision and control by the Directorate of Information and Publicity,
GNCTD, the scope of services to be provided will include:

ii)

Designing, providing images, production and publishing of a Trilingual Monthly Magazine in
Hindi, Punjabi and Urdu languages for an initial period of one year, to be extended by one
another year on the basis of performance.

iii)

To Dispatch/distribute the magazine as per the mailing list to be provided by the DIP,
Government of NCT of Delhi.

<!-- page 2 -->

2. In rendering the required services as per the scope of work, the publisher will be required:
(i) Subject to Directorate of Information and Publicity’s overall supervision and control
(ii) The Publisher will be responsible for the timely printing & dispatching the magazine across Delhi or
as suggested by Directorate.
(iii) To provide all such services as may be reasonably required by the Directorate of Information and
Publicity for the production and publishing of the magazine.
(iv) To enter into contracts with the suppliers of services and materials as it shall consider fit, including
(but not limited to) suppliers of color separations, paper, printing, translation and typesetting services,
at its own expense.
(v) To submit the final draft of the content for every issue of Hindi, Punjabi-Urdu magazine final to the
Directorate of Information and Publicity on its own. The DIP will not pay any extra payment.
(vi) To submit as the Directorate/any other place indicated by the Directorate, all printed copies for
physical verification of printed quantity and quality, before dispatch and distribution.

Validity of tender: 90 days.
Period of tender validity: May 2016 to April 2017 (One years). Extendable for another one year.
The tender is available along with the terms and conditions at https://govtprocurement.delhi.gov.in. No
tender form shall be sold by the Directorate. All the renderer should apply online before the last Date
and Time.
The publisher who intends to participate in this tender are required to obtain Digital Signature
Certificates. All the bidders must go through the terms and conditions of the tender before uploading
the tender and for registration query contact at this address 6th Floor, C-Wing, Vikas Bhawan-II, Civil
Lines-110054. Phone: 011-23813523/1800 2337313 (Monday-Friday, 09:30 A.M. to 06:00 P.M.).

<!-- page 3 -->

SPECIFICATIONS FOR TRILINGUAL MAGAZINE:
S. No.

Particulars

Specifications

1.

Size of the Magazine

2.

Overall size :
Print area :
Language

8 ½ X 10 ¾ inches
7 ½ X 9 ¾ inches minimum average
Hindi-Punjabi-Urdu (Trilingual)

3.
4.

Frequency
Number of copies

Monthly
7000

5.

Number of pages

56+4= 60 ( 56 text pages and 4 cover pages)
28 inner pages each for Hindi and 28 inner pages for Punjabi-Urdu
+
04 cover (Hindi and Punjabi-Urdu Trilingual Magazine)

Text pages
Cover
6.

7.
8.
9.
10.
11.

Paper to be used
Text Pages
Cover
Colour
Binding
Printing Process
Designing and
translation Work
Translation work in two
languages

Envelops
1.
Paper envelop

2.

Number of Envelops

90 GSM Indian Art Paper
235 GSM Art Card gloss paper
four
Centre Stitch
Offset
The composition of content for magazine in Hindi, Urdu and
Punjabi
i)
Translation of content in Urdu
ii)
Translation of content in Punjabi
28 pages in Hindi 14 Pages each in Urdu and Punjabi languages

The envelops will be made of 120 gsm supper print paper as per
size of the Trilingual Magazine with inside thermal lamination and
the name and address of the Directorate are to be printed on the
top of envelop.
7000

<!-- page 4 -->

TERMS AND CONDITIONS
1. The bidders shall upload online the duly filled in Performa only in PDF format as per the details
provided in the enclosed annexure and all relevant document and technical information except
the Financial Bid which shall be received online only. The publishers should register with Tender
Information System of Government of NCT of Delhi for online tender submission at Delhi
Secretariat, I.P. Estate, New Delhi-110002.
2. The Publisher will bear the responsibility to print the sticker of names and addresses to be
pasted on paper envelopes. If the competent authority of Directorate is willing to make any
addition and deletion in the list of recipients, the publisher will have to follow the same. As per
the instruction of the Directorate, the publisher will have to provide the number of printed
stickers required.
3. The bidder whose tender is accepted, will be required to furnish performance guarantee@ 10%
of the tendered amount within 10 days of the issue of letter. In case the bidder fails to deposit
the said performance guarantee within the stipulated time, the earnest money deposited by the
bidder shall be forfeited automatically without any notice.
4. The publishing house/company would be bound to publish the material forwarded to it by the
DIP.
5. The publisher will have to quote one rate for publication of 12 issues of the Magazine. The gross
rate for publication and dispatching of the magazines will be accepted only.
6. The publisher should have an average annual turnover of not less than Rs. 30 lakhs for last three
financial years.
7. The publishing house/company will be responsible for all expenses incurred by it in rendering
the required service without any liability to the Directorate.
8. In case the Bidder fails to dispatching/delivering Magazine within the scheduled validity period,
the Directorate shall reserve the right to procure these item from the next approved bidder or
from open market and the loss to the government on account of excess expenditure incurred
will be charged from the publisher who shall deposit the total amount of loss incurred to the
DDO of the Directorate and deposit TR-5 receipt in branch with necessary details. For repeated
non-supplies the firm Bid Security/Performance Guarantee shall be forfeited and shall be liable
to be black listed.
9. No upward price revision would be acceptable whatsoever after opening of tender. It would be
acceptable only in cases where the Government changes its policies, rates etc. for which
necessary notification/clarification to this effect has been issued by the Government. Moreover,
Director reserves the right to accept or reject any such offer in this regard and final decision
whatsoever will be binding on all.
10. The publisher would be responsible for any error and penalty would be imposed if any
discrepancy is found.

<!-- page 5 -->

11. The Bid Security in respect of accepted tender shall be released only after the expiry of the
validity of tender, as it shall be held as security deposit for the due fulfillment of the contractual
obligation. For rejected tenders, Bid Security shall be returned within 90 days after finalization
of the tenders.
12. Any attempt on the part of printer, after he/she has submitted the tender, to secure any
interest or to influence the acceptance of a particular tender shall be viewed as a
disqualification and tender shall be rejected straight away.
13. The payment will be made against pre-receipt bills in triplicate along with the printed challan
copy bearing a unique no.
14. The Director, Information and Publicity, New Delhi has exclusive powers to accept or reject any
or all tenders, and/or to cancel the supply order at any time without assigning any reasons. All
disputes shall be subject to Delhi jurisdiction.
15. All the bidders shall have also to undertake that no Vigilance case/CBI case pending against
them or their Principals or they have been blacklisted or debarred by any Government
Department or Institution for supplying inferior quality goods or for malpractices.
16. In the event of any dispute arising in connection with the interpretation of any clause in the
terms and condition of the tender/ agreement, or otherwise the matter shall be referred to the
Arbitrator appointed by the Secretary (PR), Government of NCT of Delhi. The court at Delhi/
New Delhi shall have the jurisdiction in connection with any dispute/ litigation arising out of this
tender.
17. The documents submitted by the Bidder must be self attested by the proprietor/partner or
authorized signatory himself/herself and properly numbered.
18. No documents/certificate will be accepted after the Closing Date & Time of the tender.
19. The material (hard/soft) provided by the Directorate in Hindi and English to the
Publisher/Agency/Firm, the Publisher/Agency/Firm will bear the responsibility of translating the
material in to Hindi, Urdu and Punjabi at his own cost. The Directorate would not pay any extra
cost for translation.

<!-- page 6 -->

TECHNICAL BID

(a) This cover will contain the Earnest Money Deposit (EMD)/Bid Security of D.D. of Rs. 1, 00,000/(Rupees One lakh only) in favour of ‘DDO, Directorate of Information and Publicity, GNCTD’
valid up to 45 days from the date of opening of the tender. The EMD should be refunded to the
successful bidder on receipt of Performance security.
FINANCIAL BID
(a) In this cover, the bidder shall upload the rate of the items/services rendered for which the firm
has uploaded/submitted in the technical bid along with other details as specified in the
Performa for Financial Bid in PDF format.
(b) No hard copy of the financial bid shall be submitted by the bidder otherwise the tender shall be
straightway rejected.
(c) The Rate should be quoted as per annexure-II duly signed along-with the stamp of the bidder.
(b) The Bidder must upload their financial bids in Indian Currency only (INR), as per prescribed
Performa in Annexure-II, both in words and figures separately in PDF format. The firms/printers
shall have to quote the rates inclusive of Service Tax/VAT/Taxes as applicable.

<!-- page 7 -->

ANNEXURE-I
Name of the Firm/Bidder if applicable________________________
Contact No._______________E-maili.d.________________ Fax No. ________________

1.
2.
3.
4.
5.
6.
7.

8.
9.

Details of documents to be submitted by bidder
Yes/No
Bid Security (also known as Earnest Money Deposit,)
Name of the Bank/date and its validity Amount of Bid Security
Income tax filing proof and PAN No. Submit self-attested copy of filing
income tax return for last three years.
VAT: Submit self attested copy of TIN number
Three years experience certificate of publishing/dispatching magazines
across Delhi/India among recipient.
Self Undertaking: to abide by the terms and conditions of tender, dully
signed and stamped by the Bidder.
EMD issued before closing date & time of the Tender.
Self undertaking to the effect that no vigilance case/CBI case is pending
against the bidder and that they have not been blacklisted or debarred
by any Government Department or Institute for supplying inferior
quality goods or for malpractices.
Scanned cover pages of 05 issues/publications published and
distributed by the publisher during the last three years.
The publisher should have an average annual turnover of not less than
Rs. 30 lakhs for last three financial years.

SIGNATURE AND STAMP OF THE BIDDER
OFFICE ADDRESS
TELEPHONE NUMBER

:
:
:

Page number

<!-- page 8 -->

ANNEXURE-II
Financial Bid for “DELHI MASIK” TRILINGUAL MONTHLY MAGAZINE

Name of the work

Qty.

THE PRINTING AND DISPATCHING OF
TRILINGUAL (HINDI-PUNJABI-URDU)
MAGAZINE (56 PAGES+4 COVER)
ACROSS DELHI.

7000

Unit Rate Per Total Amount (in Rs.)
Unit
Inclusive of Taxes
(i) service Tax
(ii) Vat
No.

ENVELOP OF 120 GSM SUPPER PRINT
PAPER WITH INSIDE THERMAL
LAMINATION.
PER PAGE TRANSLATION AND TYPING
IN URDU
PER PAGE TRANSLATION AND TYPING
IN PUNJABI
PER PAGE TRANSLATION AND TYPING
IN HINDI
RATE FOR DISTRIBUTION OF MAGAZINE
Net Amount

Gross cost

The rate would be adjudged on the basis of L-1 of gross total of the financial bid above.

SIGNATURE and stamp of the BIDDER
OFFICE ADDRESS
TELEPHONE NUMBER

:
:
