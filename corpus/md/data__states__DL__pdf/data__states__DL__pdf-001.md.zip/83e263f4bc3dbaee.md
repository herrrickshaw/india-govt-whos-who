---
doc_id: "83e263f4bc3dbaee"
source_url: "https://gad.delhi.gov.in/sites/default/files/gad/circulars-orders/interdepartmental_circular_gad_1.pdf"
ministry: "General Administration Department, Delhi"
title: "Download"
date: ""
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "eb3fc105ed159761"
---

<!-- page 1 -->

GOvERNMEr`IT OF N.c.T. OF DHLHI
GENERAL ADMINISTRATION DEPARTMEI`IT: SPORTS BRANCII

a

LEVEL-[L A#SEH+HH#gRETARIAT
F.18/04#023/GAD/Admn/Sports/ ioq

Datedr ac I a 5120 a3

CIRCULAR

Sub:- o%::i##:EL::G[o[nv:Eee#;n#ofs±rd Tou-ent 2023-24 for the
Attention is invited to this office Circular no. 98 dated 09.052023 & 103 dated
23.052023 regarding organization of Inter-Departmental Sports, Tournameut 2023-24 for the
officers/officials of Goverrment of NCT of Delhi.

In this regard, the following dapatments of GNCTD are requrested to form their own
teans for Cricket and TugcofLwar at their own level and send the entries to this office by the
stipulated date.
1 .Home Departmeiit
2.FinanceDepartment
3.Public Works Department

4Art, Outue & Language
The officers/officials working in the O/o Chief Minister, Ministers and Chief Secretary
shall be considered in the team formation of GAD.

In view of the above, the officers/officials physically working in General Administration
Departmerty O/o The Chief Minister; Ministers and The Chief Secretary, Delhi who are desirous
to participate in the selection trials of Cricket or Tngrof-War are requested to contact Sports
Branch, GAD for registering their names for team selection latest bv 06.06.2023 quesday)

~#pfro

positively.

Deputy Secretary (GAD)

F.18/04/2023/GAD/Admn/Sports/ /oq

Dated: 8i6|o5-laoi3

Copy forwarded for information and necessary action:All HODs of Home, Finance, PWD & ACL Deptts., Govt. ofNCT of Delhi.
Website of the department.
Guard File.

t?(:..

f#T#
Deputy Secretary (GAI))

<!-- page 2 -->

GOVERNMENT OF N.C.T. OF DELHI
'GENERAL ADMINISTRATION
DEPARTRENT: SPORTS BRANCH

LEVEL-II, A WING, DELHI SECRETARIAT
NEWDELln-ii0002
F.18/04/2023/GAD/Admn/Sports/ I o3

Dated: 23.05.2023

To,

All Additional Chief Secretaries/ Pr. Secretaries/ Secretaries/
Heads of the Departments/ Autonomous Bodies,
Govt. of NCT of Delhi

Delhi / New Delhi

Sub:- Organisation of Inter- Det)artmental St]orts Tourlnament 2023-24 for the
officers /officials of Government of NCT of Delhi.
Beg This office earlier circular no. F.18/04/2023/GAD/Admn/Sports/ 98 dated O9th May
2023.

Sir/Madam
Kindly refer to the matter on the subject cited above. In this connection, please

find enclosed herewith the following details relating to the tournament:
1. Guidelines for Inter-Departmental Sports Tournament 2023-2024;

2. Rules and Regulations for Inter-Departmental Sports Tournament 2023-2024;
3. Registration form for submission of entries.

You are requested to bring the contents of the above documents into the knowledge
of all the officers/officials of your department for further necessary action at their end.

D eputy secretary (Sports)
Encl. As Above
Copy for information and necessary action to:1.

Secretary to the Minister (GAD), Govt. of NCT of Delhi, 7th level, A wing, Delhi Secretariat,
New Delhi.

2.

The Dy. Director of Education (Sports), Dte. Of Education, Govt. of NCT of Delhi,

Chhatrasal Stadium, New Delhi with the request to kindly book Thyagraj Stadium &
Bharat Nagar Cricket Ground for organising the Inter-Departmental Sports tournaments
2023-24 w.e.f.loth July to 16th July 2023.
3.

Pps toACS (GAD), Govt. ofNCTofDelhi.

4.

Website of the department,

5.

Guardfile.

EREiiH

'
(Pradeep Tayal)
Deputy Secretary (Sports)

<!-- page 3 -->

Guldel]nes for Inter-D`epartmental Sports Tournament 20Z3-.20Z4
being organized bv General Administration Deuartment. Govt. of NCT
6jDe_lhi _
1) The General Administration Department is organising Athletics, Badminton and Table

Tennis under various age categories (Men and Women); Cricket (Men) and Tug-of-War (Men

and worn?n) events.
2) These games will be organised w.erf.loth Tulv 2023 to 16th lulv 2023.

3) The Athletics, Badminton, Table Tennis and Tugrof-War events will take place at Thyagraj
Stadium, near INA, New Delhi. Cricket matches will be played, primarily, at Bharat Nagar
Cricket Ground, near Laxmi Bai College, Ashok Vihar, Delhi -110052. If need arises, then the

matches can also be played at Vikas Purl Cricket Ground and ]heel Khurenja Cricket Ground.

4) Tentatively, the reporting time for Athletics.and Tugrof-War events will be at 6.00 pin
whereas the reporting time for Badminton and Table Tennis activities will be at 3.00pm. The

exact timings will be made available once the exact schedule / fixtures are drawn.

5) The Cricket matches will be played in the morning as well as in the evening. For moming

match, the reporting time will be at 7.00 am whereas the reporting time for evening match

win be at 3.00pm
6) The schedule of events/fixtures will be made available in due course once the entries are
received from the officers/officials in respect of individual events and from various

departments in respect of team games.
7) One player is allowed to participate in only one game out of Athletics, Badminton & Table

Tennis and upto 2 events in that game under his/her own age category. Besides this, one
player of a particular department will participate only in one team game. A player who
intends to participate in individual game is also eligible to participate in team game provided
he/she is selected by the department concerned in its team.
8) The doubles' partner in Badminton and Table Tennis should be from the same department

and of the same age group.
9) All the participants will be provided Participation Certificates.

10)AIl the wirmers; runners' up and 3rd place holder will be awarded cash prize of Rs. 5,100/-;
Rs. 3,100/-& Rs. 2,100/- each respectively in all the games.

11)The entries are to be submitted by the individual players, in the prescribed proforma, only in
respect of Athletics; Badminton and Table Tennis whereas the entries in respect of team

games of Cricket and Tug-of-War will be sent by the department concerned on their letter
head indicating maine; designation; place of posting etc. of the concerned player. The entries
in respect of Cricket and Tug-of-war will be submitted by the departments only after

obtaining the prior approval of their respective Competent Authority. The departmeut will
also nominate a nodal officer in respect of each team game for proper liaisoning and
coordination.

crfu tr 1

<!-- page 4 -->

-i12)If any department wishes to nominate its Cricket teams more than the allotted quota, then it

should intimate General Administration Department, latest bv 15.062023 positively.

o

However, the decision on participation of extra teams beyond the allotted quota will be with
General Administration Department.
13)The department concerned will declare its captain of the respective team at the time of

submission of entry with the liberty to change the name of the captain at least 24 hours prior
to the match scheduled.
14) Each player is required to participate in proper uniform of that game. The uniform as well as

playing equipments will be arranged by the player/department itself at his / her own level
except Shuttle Cocks. TT balls and Cricket balls.

15)The General Administration Department will provide coloured dresses to the finalists of the

cricket team as well as to the officers' team for day / night T-20 match.

16)Each player will ensure himself/herself that he/she is physically fit to participate in these
games. General Administration Department will not be responsible for any untoward
incident or injury arising due to this Inter-Departmental Sports tournament 2023-24.
17)Each player will maintain proper decorum and discipline while participating in this

tournament.
18)Any misbehaviour; indiscipline or any kind of breach will lead to disqualification of the

player from these games including barring of his participation in any kind of games for the
next 3 years.
19)In those departments, where the retirement age is beyond 60 years, such players will
participate in the last age category of respective games.
20) General Administration Department reserves the rights to alter/relax/modify/add/delete

any rule or clause of the respective games in the interest of players without assigning any
reasons thereof.
21)The decision of th.e General Administration Department for these games win be final and

binding upon the players.
22)The players participating in these tournaments will be treated "On Duty" on the actual day of

his / her event.
23)Neither any TA/DA nor any compensatory off will be allowed on account of participation in

these games.
24) Last date of submission of complete registration forms in respect of Athletics, Badminton &
T.T. will be 26.6.2023 whereas the last date of submission of entries in respect of Cricket
and Tug-of-War is 04.7,2023. The entries received in sports cell of General Administration

Department beyond the stipulated date will not be entertained.
25)The entries in respect of Athletics; Badminton & T.T. will be entertained only if they are

submitted in prescribed proforma. The entries in any other form or on plain paper will not
be entertained.

26)All the participants should carry original identity card, mandatorily, at the venue at the time
of participation.

27)There shall be minimum three participants in an event for conducting that event.
28) Referees/Umpire's decision shall be final and binding on the participants.

fr

cch tr3

<!-- page 5 -->

-329) ELtry form ls enclosed with these gulde]lnes.

+

30) Any information regarding change of venue/dates/cancellation etc about the Inter
e

Departmental sports Tournament 2023-24 will be available on the official website of
General Administration Department, Govt. of NCT of Delhi.

\en

<!-- page 6 -->

Rules and Regulations for Inter-Departmental Sports TQurqamept
2023-2024 being organized bv General Administration Depart_ment,
vt. of NCT ofDelhi
BADMINTON:

1. All players are required to participate in proper dress code meant for Badminton discipline.

2. All the matches upto pro-quarter final stage will be played with the plastic shuttlecocks,
preferably Mavis brand which will be provided by General Administration Department.
3. All the matches from quarter finals onwards will be played with feather shuttlecock which
will be provided by General Administration Department.
4. All the matches upto pre-quarter finals will comprise of set of 15 points ea`ch and best of

three sets.
5. All the matches from quarter finals onwards will comprise of set of 21 points each and best
of 3 sets.

6. The players are required to bring their own racqu`ets, shoes etc. at their own cost to

participate in these games. It is.mandatory to wear non-marking badminton shoes to enter
the courts
7. The decision of the Tournament Committee will be final on all points of facts, the Chief
Referee will be the sole in-charge of all technical issues on point of law.

8. Every player has to report at least 30 minutes before the scheduled time of the match,
otherwise walkover will be given to the opponent. ,
9. All the losing semi,- finalists in all the age categories will be adjudged 3rd place holder and

will be conferred cash prize of Rs. 2,100/-each.

10. The General Administration Department may consider giving consolation prizes in any age

category to any number of players at its own level. The decision of General Administration
Department will be final and binding upon all the players and Departments.

11. No food or eatables are allowed inside the arena before and after the match.
TABLE TENNIS:

1. All players are required to participate in proper dress code meant for TT discipline.

2. All the matches will be played with the 3 star ball which will be provided by General

Administration D epartment.
3. Ail thematches will comprise of set of 11 points each and best of five sets.

4. The players are required to bring their own racquets; shoes etc. at their own cost to

participate in these games.

It is mandatory to wear non-marking TT shoes to enter the

courts.

5. The decision of the Tournament Committee will be final on all points of facts, the Chief
Referee will be the sole in-charge of all technical issues on point of law.

6. Every player has to report at least 30 minutes before the scheduled time of the match,
otherwise walkover will be given to the opponent.

cal` . (Th 2-

<!-- page 7 -->

-2-7. All the losing semi- finalists in all the age categories will be adjudged 3rd place holder and

will be conferred cash prize of Rs. 2,100/-each.

68.caT:getoTLAy:::::::::::::,:;:rs=;:t:y,::¥d;rect;:¥:n:fo]Ga:ti;oen£¥:;;:::::ti:::
Department will be final and binding upon all the players and Departments.
9. No food or eatables are allowed inside the arena before and after the match.
ATHLETICS:

1. All players are required to participate in proper dress code meant for Athletics discipline.

2. All the events will take place at synthetic athletics turf of Thyagraj Stadium in the evening.

Hence, the players are expected to arrange proper shoes before participation so as to avoid
any loss to the Government property.
3. The decision of the Tournament Committee will be final on all points of facts, the Chief
Referee will be the sole inngharge of all technical issues on point of law.

4. Every player has to report at least 30 minutes before the scheduled time of the event,
otherwise the player will be disqualified from participating in the event.
5. Since the summer season is at peak in the month of July; so the players are advised to get

themselves medically checked and ensure that they are fit to participate in athletics events.

If needed, they should carry their own energy drink or any other glucose water for
hydration.
CRICKET:

1. All players are required to participate in proper dress code meaut for Cricket discipline.

2. The matches win take place in the morning as well as in the evening as per the schedule
which will be finalised in due course.

3. An the matches will be of T-20 format. For morning match, the reporting time of both the
teams will be at 7.00am whereas the reporting time for evening match will be at 3.00pm.
For final match, the reporting time will be 5.00pm as it is scheduled as Day/Night match.
4. All the matches upto semi-final stage will be played with the Red ball whereas the final

match will be played with white ball.
5. For participating in Cricket matches, spikes shoes are not allowed.

6. The Cricket playing kit as well as wears to the finalist teams and to the team of the officers'
will be provided by General Administration Department for playing final match of the

tournament. The Cricket playing kit will be taken back from the teams once the matches are
over. The decision of the Tournament Committee will be final on all points of facts, the Chief

Umpire will be the sole in-charge of all technical issues on point of law.

7. Every player has to report at least 30 minutes before the scheduled time of the match,

otherwise walkover will be given to the opponent.
8. The General Administration Department may consider giving consolation prizes to any

number of players at its own level The decision of General Administration Department will

cnd tr3
#bindinguponalltheplayersandDeparrments

<!-- page 8 -->

-3TugofWar:
01.Theteamwillcompriseof10playerseach.Howeveronly8playerswillplayatatime.
2. Maximum combined weight for 8 players in men category will be 680 kg.

3. Maximum combined weight for 8 players in women category will be 560 kg.

4. The players are allowed to participate in general sports shoes without spikes.
5. The match will be decided on best of three pull each.

`

7
``

,

`~-`.,

1lL-

<!-- page 9 -->

#ffiGTfalE;E¥GFEORE+AIR,RDiE:±=inTMETN[NTO#DEFARRTiREsri#TE##NI
'T ick anv one game and max. two eventst
Athletics

I loom
I 200m
I 400m
I 800m

Badminton

Table Tennis
Singles

I

Doubles

I

singles

I

Doubles

|Walk5Km
I.

Nane & Designation:

2.

Gender:

Latest Passport
size color

3.

Place of posting (complete address):

photo to be
fixed

4.

D.O.B. as per office record:

5.

Ageasonol.07.2023:

6.

MobileNo.

7.

E-mailld:

I undertake that I am medically fit to participate in the Inter Departmental Sports Tournament
2023-24, and I shall be solely responsible in the event of any accident or injury during the
said Tournament. I shall abide by all rules and regulations of the said Tournament.

(Signature of the Applicant)

It is certified that the above mentioned officei./offlcial is a regular employee of Govt. of NCT
of Delhi and is allowed by this department to participate in the Inter Departmental Sports
Tounament 2023-24.

Signature of Head of Office
(with seal)

Nape:
Department:
Dated:
1. The registration form, in original shall be submitted in Sports Cell, GAD, 2nd Level, Delhi
Secretariat latest by 26.06.2023 positively.

2. The entry for Cricket and Tug of War shall be forwarded by respective Departments only latest by
04.07.2023.

3. An individual can participate in only one game i.e. Athletics/ Badminton/T.T. and upto two events in
that game.
4. No change will be allowed after submission of registration form.
5. Attach a co
of I.D. card issued b the`De artment.

<!-- page 10 -->

GOVBRNMENT OF N.C.T. OF I}BLH]

GENERAL ADMINISTl`^TloN I)EP^RTMF.NTi SPORTS BRANCH
LEVEi,-II, A wlNc,, DnLill sncRETARIAT

``j

Nnw I]nLIIi-I ioiio2

Dated:09utMay2o23

at 8ro4rao23/GAD/Admusporrs/ q 8

grRcuLAR
Sub:-

nnisntion or
omcers/omcinls ol` Gov€rnmont Or NCT Of Dclil!.

The Geneml Administration Department intends to orgmize Inter-Departmend Sports

focTOTj:,th3.o£3h::£o:S:,tjE:gjceen:::ill:::::§{ij:::i:;::jEj:E:¥&£E£Z:;:¥;E3:£§
Eife023 as I.er the details given below:SI. no,

Game

ii.

iii.

Venuecrentative)

Age cntegorics

Singles

i. below40 years

(Men & Women)
Doubles**(Men&Women)

ii..40-50 yearsiii.50-60years

Table
Temis*

Singles .

i. below 40 years
ii. 40-50 yearsiii.50-60year

Athletics

loom

Badminton*

i.

Evcn's

(Men & Women)
Doubles**(Men&Women)

Ttryagraj Stadium

Tdyagraj Stadium
20-30 years,
• 3040 years,40-50years,50-55years and55-60years.

(Men & Women)

200m

(Men & Women)

20-30 years,
30-40 years,40-50years,50-55years and55-60years.

ThyagrQj Stadium\\
400m

(Men & Women)

(Men & Women)

20-30 years,
30-40 years and40-50years

Walk 5 Kin

40-50 years.

(Men & Women)

50-55 years and55-60years.

League/ Knock out
Basis (Men)

Open age. Team
comprising of 14

800m

¥,¥I",.

Cricket (T-20)
iv.

Tug.of war

Knock out basis

(Men& Women)
V.

20-30 years,
30.40 years,40-50years,50-55years and55-60years.

players.

.

Open

age.

comprising

Tea

Bhunt Nagar Groun dl\\
/ Vikas Puri / Jhee
Khurenia
Thyagraj Stadium

of

players

cud, tr i

<!-- page 11 -->

f

*In Badminton and Tal>|e Termis, separate mntches will be played, for officials nd officers, in
©

the age category of50-60 yerLrs only..

** The doubles partners inould be from the snmc department and of the same age category.

The rules and regulntious, brondly, of the lntendepartment{il sports Tournament 2023J24 are as
under:-

a) The duredon of the proposed tourmment (except cricket) shall be one weck. The matches
shall stan from 03:00 PM onwards (except Athletics events). All.Athletics events will take
place afror 6.00pm in floodlights. The exact schedule of the games will t]e released in due
course.
b) is`, 2nd and 3rd position holders shall be rewarded with cash prizes of RS.5,100/-;

RSJ,loo/-& Rs2,loo/-respectively and a merit certificate. The cash award shall be

given to all the team members in case of a team event and to both the players in doutles
matches.

c) In cricket, consolation prizes shall be. given in the fom of Man of the match (Only for
final); Man of the series; best batsman; best bowler; best all rounder; best fielder etc.

d) An event shall be organized only if there are minimum three entries in that event.
e) A player can participate only in one game of his/ her choice and maximum of two events
in the specific nge category of that game (except Cricket and Tug of war). He / cue wnl
have to give a declaration to this eifect while submitting his / her entry.
`

D#o]€}|[,°uTy,dgoe23fi:rdeterminingageforpariiofpationintheabovesaldtourmmentsshali

•

g) Only the regular employees of GNCTD shall be allowed to oarticinate in the e`)ents`
ipcludjng the regular employees of GNCTD on deputation in other Autonomous bodies of
Govt. ofNCT of Delhi.

h) Cricket event:
i. The final match of the Cricket Tournament shall be organized as day / nicht T-20
match.

ii. GAD shall select & field three teams including one tear to be fomed for the
gazetted officers of those departments of GNCTD where the strength Of deparment
is less or where there is no possibility to select a whole team of 14 players.
iii. The Directorate of Education is allowed to field upto five terms from their
respective regions (one team per region) and Revenue department is allowed to fleld
upto three .teams. All other departments may field only one team of their respective

department.

Cdrtr}

-2-

<!-- page 12 -->

i
{8
All Herds ofthc Depnrtmcnts/Offices ne rcqucstcd to bring the contents of this circ`ilar
into the knowledge of their respec(iv.c officers / omcials; cncourzige them to par(icipate in the
said tourmment and subsequently allow them (o |iariicipntc in the tourmmcnt. As rcBards the

team games of Cricket and Tug of War, the dcpnriments arc rcqucstcd to send their willingness
]g!±L±±:js.P6.2023 to GAD, Dellli Sccretariut 8t "spaaife»jc. J«".

The department of the officer/official who desires to participntc in the above events shall
be considered from the department where the officer/official is physically `rorking as on 15th

Jue 2023.
Sh. Bhaskar Priyadarshi; Sh. Vivck Misha and Sh. Atul Makker, Section Officers Of
GAD are the coordinating officers for the said toumnment.

The detailed schedule of events and other guidelines relating to the above said

tournarnent will follow in due course. Entries for participation in this tournament will be imuted

A*tyffi:#

through a prescribed proforma which will be ciroulated shortly.

This issues with the prior approval of Competent

F.18/04/2023/GAD/Admn/Sports/P8

Dated: 09th March 2023

Copy'forwardedforinfomationandnecessaryaction:1. All Additional Chief Secretaries / Pr. Secretaries / Secretaries AIeads of the Departments /
Autonomous Bodies, Govt. ofNCT of Delhi.

2. Secretry to the Minister (GAD), Govt. of NOT of Delhi, 7th level, A wig, Delhi
Secretariat, New Delhi.
3. The Dy. Director of Education .(Sports). Dte. Of Education, Govt. Of NCT Of Den,
Chhatarsaal Stadium, New Delhi.
4. PPS to ACS (GAD), Govt. ofNCT of Delhi.
5. Website of the department.

6. Curd File.
n=

¢radeep Tnyal)

Deputy Secretary (GAD)

-3-
