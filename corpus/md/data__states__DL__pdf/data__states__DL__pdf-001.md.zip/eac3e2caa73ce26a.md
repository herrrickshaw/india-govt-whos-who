---
doc_id: "eac3e2caa73ce26a"
source_url: "https://prosecution.delhi.gov.in/sites/default/files/Prosecution/tender/repair.pdf"
ministry: "Directorate of Prosecution, Delhi"
title: "Tender Document"
date: ""
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "69943d7320b94890"
---

<!-- page 1 -->

File No. F2(856)/DOP/ADMN/2022 (Computer No. 142645)

1254076/2023/ADMN_DOP

Bid Number/बोली

मांक ( बड सं या) :
GEM/2023/B/3309451
Dated/ दनांक : 27-03-2023

Bid Document/ बड द तावेज़
Bid Details/ बड ववरण
Bid End Date/Time/ बड बंद होने क तार ख/समय
Bid Opening Date/Time/ बड खुलने क

10-04-2023 17:00:00
10-04-2023 17:30:00

तार ख/समय
Bid Offer Validity (From End Date)/ बड पेशकश
वैधता (बंद होने क तार ख से)

30 (Days)

Ministry/State Name/मं ालय/रा य का नाम

Delhi

Department Name/ वभाग का नाम

Home Department Delhi

Organisation Name/संगठन का नाम

Directorate Of Prosecution Government Of Nct Of Delhi

Office Name/कायालय का नाम

1st Floor, Tis Hazari Court Complex, Delhi-110054

Total Quantity/कुल मा ा

14

Item Category/मद केटे गर

Servicing of Samsung ML-2161 Printer , Servicing of Brother
HL-L6200DW Printer , Servicing of Canon MF244DW Printer ,
Logic Card of Brother HL-L6200DW Printer , Logic Card of
Canon MF244DW Printer , Drum of Brother HL-L6200DW
Printer , Drum of Canon MF244DW Printer , Drum and Roller
of Samsung ML-2161 Printer , Fuser Assemble Set of
Brother HL-L6200DW Printer , Fuser Assemble Set of Canon
MF244DW Printer , Fuser Assemble Set of Samsung ML2161 Printer , Servicing of HP Scanjet 7500 Flatbed Scanner
, ADF Hinge Assembly for HP Scanjet 7500 Flatbed Scanner ,
ADF Roller Kit for HP Scanjet 7500 Flatbed Scanner

BOQ Title/बीओ यू शीषक

Repair of printers and scanners

Years of Past Experience Required for
same/similar service/उ ह ं/समान सेवाओं के िलए

1 Year (s)

अपे

त वगत अनुभव के वष

MSE Exemption for Years Of Experience/वष
के अनुभव के िलए एमएसई को छूट

ा

है

Startup Exemption for Years Of Experience/
वष के अनुभव के िलए टाटअप को छूट ा है
Document required from seller/ व े ता से मांगे
गए द तावेज़
Bid to RA enabled/ बड से रवस नीलामी स

Yes

Yes
Experience Criteria
*In case any bidder is seeking exemption from Experience /
Turnover Criteria, the supporting documents to prove his
eligibility for exemption must be uploaded for evaluation by
the buyer

य कया No

1
Generated from eOffice by SANJAY KUMAR, System Analyst (SA), SYSTEM ANALYST, DIRECTORATE OF PROSECUTION on 31/03/2023 02:55 PM

1 / 12

<!-- page 2 -->

File No. F2(856)/DOP/ADMN/2022 (Computer No. 142645)

1254076/2023/ADMN_DOP

Bid Details/ बड ववरण
Type of Bid/ बड का

कार

Primary product category

Two Packet Bid
Servicing of Brother HL-L6200DW Printer

Time allowed for Technical Clarifications
during technical evaluation/तकनीक मू यांकन के 2 Days
दौरान तकनीक प ीकरण हे तु अनुमत समय
Evaluation Method/मू यांकन प ित

EMD Detail/ईएमड

Total value wise evaluation

ववरण

Required/आव यकता

No

ePBG Detail/ईपीबीजी ववरण
Required/आव यकता

No

Splitting/ वभाजन
Bid splitting not applied/बोली वभाजन लागू नह ं कया गया.
MSE Purchase Preference/एमएसई खर द वर यता
MSE Purchase Preference/एमएसई खर द वर यता

No

MII Purchase Preference/एमआईआई खर द वर यता
MII Purchase Preference/एमआईआई खर द वर यता

No

1. If the bidder is a Micro or Small Enterprise as per latest definitions under MSME rules, the bidder shall be
exempted from the requirement of "Bidder Turnover" criteria and "Experience Criteria" subject to meeting of
quality and technical specifications. If the bidder is OEM of the offered products, it would be exempted from the
"OEM Average Turnover" criteria also subject to meeting of quality and technical specifications. In case any
bidder is seeking exemption from Turnover / Experience Criteria, the supporting documents to prove his eligibility
for exemption must be uploaded for evaluation by the buyer.
2. If the bidder is a Startup, the bidder shall be exempted from the requirement of "Bidder Turnover" criteria and
"Experience Criteria" subject to their meeting of quality and technical specifications. If the bidder is OEM of the
offered products, it would be exempted from the "OEM Average Turnover" criteria also subject to meeting of
quality and technical specifications. In case any bidder is seeking exemption from Turnover / Experience Criteria,
the supporting documents to prove his eligibility for exemption must be uploaded for evaluation by the buyer.
3. Experience Criteria: In respect of the filter applied for experience criteria, the Bidder or its OEM {themselves or
through reseller(s)} should have regularly, manufactured and supplied same or similar Category Products to any
Central / State Govt Organization / PSU / Public Listed Company for number of Financial years as indicated above
in the bid document before the bid opening date. Copies of relevant contracts to be submitted along with bid in
support of having supplied some quantity during each of the Financial year. In case of bunch bids, the category of
primary product having highest value should meet this criterion.

2
Generated from eOffice by SANJAY KUMAR, System Analyst (SA), SYSTEM ANALYST, DIRECTORATE OF PROSECUTION on 31/03/2023 02:55 PM

2 / 12

<!-- page 3 -->

File No. F2(856)/DOP/ADMN/2022 (Computer No. 142645)

1254076/2023/ADMN_DOP

4. Estimated Bid Value indicated above is being declared solely for the purpose of guidance on EMD amount and
for determining the Eligibility Criteria related to Turn Over, Past Performance and Project / Past Experience etc.
This has no relevance or bearing on the price to be quoted by the bidders and is also not going to have any
impact on bid participation. Also this is not going to be used as a criteria in determining reasonableness of
quoted prices which would be determined by the buyer based on its own assessment of reasonableness and
based on competitive prices received in Bid / RA process.

Servicing Of Samsung ML-2161 Printer
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

1

Consignee
Reporting/Officer/
परे षती/ रपो टग

Address/पता

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

Servicing Of Brother HL-L6200DW Printer
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

3
Generated from eOffice by SANJAY KUMAR, System Analyst (SA), SYSTEM ANALYST, DIRECTORATE OF PROSECUTION on 31/03/2023 02:55 PM

3 / 12

<!-- page 4 -->

File No. F2(856)/DOP/ADMN/2022 (Computer No. 142645)

1254076/2023/ADMN_DOP

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

Consignee
Reporting/Officer/
परे षती/ रपो टग

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

1

Address/पता

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

Servicing Of Canon MF244DW Printer
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

1

Consignee
Reporting/Officer/
परे षती/ रपो टग

Address/पता

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

Logic Card Of Brother HL-L6200DW Printer
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

4
Generated from eOffice by SANJAY KUMAR, System Analyst (SA), SYSTEM ANALYST, DIRECTORATE OF PROSECUTION on 31/03/2023 02:55 PM

4 / 12

<!-- page 5 -->

File No. F2(856)/DOP/ADMN/2022 (Computer No. 142645)

1254076/2023/ADMN_DOP

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

Consignee
Reporting/Officer/
परे षती/ रपो टग

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

1

Address/पता

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

Logic Card Of Canon MF244DW Printer
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

Consignee
Reporting/Officer/
परे षती/ रपो टग

Address/पता

अिधकार

Quantity/मा ा

Delivery Days/ डलीवर के
दन

5
Generated from eOffice by SANJAY KUMAR, System Analyst (SA), SYSTEM ANALYST, DIRECTORATE OF PROSECUTION on 31/03/2023 02:55 PM

5 / 12

<!-- page 6 -->

File No. F2(856)/DOP/ADMN/2022 (Computer No. 142645)

1254076/2023/ADMN_DOP

S.No./ .
सं.

Consignee
Reporting/Officer/
परे षती/ रपो टग

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

1

Address/पता

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

Drum Of Brother HL-L6200DW Printer
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

1

Consignee
Reporting/Officer/

Address/पता

परे षती/ रपो टग

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

Drum Of Canon MF244DW Printer
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

6
Generated from eOffice by SANJAY KUMAR, System Analyst (SA), SYSTEM ANALYST, DIRECTORATE OF PROSECUTION on 31/03/2023 02:55 PM

6 / 12

<!-- page 7 -->

File No. F2(856)/DOP/ADMN/2022 (Computer No. 142645)

1254076/2023/ADMN_DOP

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

Consignee
Reporting/Officer/
परे षती/ रपो टग

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

1

Address/पता

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

Drum And Roller Of Samsung ML-2161 Printer
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

1

Consignee
Reporting/Officer/
परे षती/ रपो टग

Address/पता

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

Fuser Assemble Set Of Brother HL-L6200DW Printer
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

7
Generated from eOffice by SANJAY KUMAR, System Analyst (SA), SYSTEM ANALYST, DIRECTORATE OF PROSECUTION on 31/03/2023 02:55 PM

7 / 12

<!-- page 8 -->

File No. F2(856)/DOP/ADMN/2022 (Computer No. 142645)

1254076/2023/ADMN_DOP

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

Consignee
Reporting/Officer/
परे षती/ रपो टग

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

1

Address/पता

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

Fuser Assemble Set Of Canon MF244DW Printer
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

Consignee
Reporting/Officer/
परे षती/ रपो टग

Address/पता

अिधकार

Quantity/मा ा

Delivery Days/ डलीवर के
दन

8
Generated from eOffice by SANJAY KUMAR, System Analyst (SA), SYSTEM ANALYST, DIRECTORATE OF PROSECUTION on 31/03/2023 02:55 PM

8 / 12

<!-- page 9 -->

File No. F2(856)/DOP/ADMN/2022 (Computer No. 142645)

1254076/2023/ADMN_DOP

S.No./ .
सं.

Consignee
Reporting/Officer/
परे षती/ रपो टग

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

1

Address/पता

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

Fuser Assemble Set Of Samsung ML-2161 Printer
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

1

Consignee
Reporting/Officer/
परे षती/ रपो टग

Address/पता

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

Servicing Of HP Scanjet 7500 Flatbed Scanner
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

9
Generated from eOffice by SANJAY KUMAR, System Analyst (SA), SYSTEM ANALYST, DIRECTORATE OF PROSECUTION on 31/03/2023 02:55 PM

9 / 12

<!-- page 10 -->

File No. F2(856)/DOP/ADMN/2022 (Computer No. 142645)

1254076/2023/ADMN_DOP

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

Consignee
Reporting/Officer/
परे षती/ रपो टग

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

1

Address/पता

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

ADF Hinge Assembly For HP Scanjet 7500 Flatbed Scanner
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

1

Consignee
Reporting/Officer/
परे षती/ रपो टग

Address/पता

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

ADF Roller Kit For HP Scanjet 7500 Flatbed Scanner
Brand Type/ ांड का कार
Technical Specifications/तकनीक

Unbranded
विश याँ

10
Generated from eOffice by SANJAY KUMAR, System Analyst (SA), SYSTEM ANALYST, DIRECTORATE OF PROSECUTION on 31/03/2023 02:55 PM

10 / 12

<!-- page 11 -->

File No. F2(856)/DOP/ADMN/2022 (Computer No. 142645)

1254076/2023/ADMN_DOP

Specification Document

View File

BOQ Detail Document

View File

Advisory-Please refer attached BOQ document for detailed consignee list and delivery period.

Consignees/Reporting Officer/परे षती/ रपो टग अिधकार and/ तथा Quantity/मा ा

S.No./ .
सं.

1

Consignee
Reporting/Officer/
परे षती/ रपो टग

Address/पता

Quantity/मा ा

Delivery Days/ डलीवर के
दन

1

15

अिधकार
MOHAMMAD AHMAD
KHAN

110054,Room Number 172 Tis
Hazari Court First Floor Delhi
110054

Buyer Added Bid Specific Terms and Conditions/ े ता

ारा जोड़ गई बड क

वशेष शत

1. Generic
OPTION CLAUSE: The Purchaser reserves the right to increase or decrease the quantity to be ordered up
to 25 percent of bid quantity at the time of placement of contract. The purchaser also reserves the right to
increase the ordered quantity by up to 25% of the contracted quantity during the currency of the
contract at the contracted rates. Bidders are bound to accept the orders accordingly.
2. Provisions for workmen compensation, insurance, public liability, property damage, insurance etc. to be
ensured by the contractor. Also, safety measures prescribed for working in Extra High Voltage & use of
personnel protective equipment must be adhered to.

Disclaimer/अ वीकरण
The additional terms and conditions have been incorporated by the Buyer after approval of the Competent
Authority in Buyer Organization, whereby Buyer organization is solely responsible for the impact of these clauses
on the bidding process, its outcome, and consequences thereof including any eccentricity / restriction arising in
the bidding process due to these ATCs and due to modification of technical specifications and / or terms and
conditions governing the bid. Any clause(s) incorporated by the Buyer regarding following shall be treated as
null and void and would not be considered as part of bid:1. Definition of Class I and Class II suppliers in the bid not in line with the extant Order / Office Memorandum
issued by DPIIT in this regard.
2. Seeking EMD submission from bidder(s), including via Additional Terms & Conditions, in contravention to
exemption provided to such sellers under GeM GTC.
3. Publishing Custom / BOQ bids for items for which regular GeM categories are available without any
Category item bunched with it.

11
Generated from eOffice by SANJAY KUMAR, System Analyst (SA), SYSTEM ANALYST, DIRECTORATE OF PROSECUTION on 31/03/2023 02:55 PM

11 / 12

<!-- page 12 -->

File No. F2(856)/DOP/ADMN/2022 (Computer No. 142645)

1254076/2023/ADMN_DOP

4. Creating BoQ bid for single item.
5. Mentioning specific Brand or Make or Model or Manufacturer or Dealer name.
6. Mandating submission of documents in physical form as a pre-requisite to qualify bidders.
7. Floating / creation of work contracts as Custom Bids in Services.
8. Seeking sample with bid or approval of samples during bid evaluation process.
9. Mandating foreign / international certifications even in case of existence of Indian Standards without
specifying equivalent Indian Certification / standards.
10. Seeking experience from specific organization / department / institute only or from foreign / export
experience.
11. Creating bid for items from irrelevant categories.
12. Incorporating any clause against the MSME policy and Preference to Make in India Policy.
13. Reference of conditions published on any external site or reference to external documents/clauses.
14. Asking for any Tender fee / Bid Participation fee / Auction fee in case of Bids / Forward Auction, as the
case may be.
Further, if any seller has any objection/grievance against these additional clauses or otherwise on any aspect of
this bid, they can raise their representation against the same by using the Representation window provided in
the bid details field in Seller dashboard after logging in as a seller within 4 days of bid publication on GeM. Buyer
is duty bound to reply to all such representations and would not be allowed to open bids if he fails to reply to
such representations.

This Bid is also governed by the General Terms and Conditions/ यह बड सामा य शत के अंतगत भी शािसत है
In terms of GeM GTC clause 26 regarding Restrictions on procurement from a bidder of a country which shares a land border with India, any bidder from a country which
shares a land border with India will be eligible to bid in this tender only if the bidder is registered with the Competent Authority. While participating in bid, Bidder has to
undertake compliance of this and any false declaration and non-compliance of this would be a ground for immediate termination of the contract and further legal action
in accordance with the laws./ जेम

पर

क सामा य शत के खंड 26 के संदभ म भारत के साथ भूिम सीमा साझा करने वाले दे श के बडर से खर द

ितबंध के संबंध म भारत के साथ भूिम सीमा साझा करने वाले दे श का कोई भी बडर इस िन वदा म बड दे ने के िलए तभी पा

जब वह बड दे ने वाला स म

होगा

ािधकार के पास पंजीकृ त हो। बड म भाग लेते समय बडर को इसका अनुपालन करना होगा और कोई भी

गलत घोषणा कए जाने व इसका अनुपालन न करने पर अनुबंध को त काल समा

करने और कानून के अनुसार आगे क कानूनी कारवाई

का आधार होगा।

---Thank You/ ध यवाद---

12
Generated from eOffice by SANJAY KUMAR, System Analyst (SA), SYSTEM ANALYST, DIRECTORATE OF PROSECUTION on 31/03/2023 02:55 PM

12 / 12
