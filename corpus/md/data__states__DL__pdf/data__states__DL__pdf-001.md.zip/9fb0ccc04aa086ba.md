---
doc_id: "9fb0ccc04aa086ba"
source_url: "https://archaeology.delhi.gov.in/sites/default/files/archaeology/tender/kos_minar_monument_tender.pdf"
ministry: "Archaeology Department, Delhi"
title: "Tender Document"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "16956ef103f79840"
---

<!-- page 1 -->

F.No.5(05)2025/Archy/ 1343

DEPARTMENT OF ARCHAEOLOGY

(Government of NCT of Delhi)
VIKAS BHAWAN-II, 2" Floor, B-Block.
M.G. Road, Civil Lines, Delhi-|10054.

Dated: 18 lo+|25

NOTICE INVITING TENDER

Percentage Rate Tender is invited by the Head of Office, Department of Archaeology, Government of

EwXeocutrikn

NCT of Delhi, 2nd floor, B-Block, Vikas Bhawan-II, M.G. Road, Civil Lines, Delhi-54 from approved and
eligible contractors/Agency for the following work:

FECost4s.t5i9m.5a4t3e/d- EMF9a.or1n9esy/-t

S.

Name of Work

for
Duration

Last date &

time for

No.

receiving

Tender Opening
Date & Time

Tender with

Minor Conservation and Development works at
Kos Minar Monument near Northern Gateway,

60Days

Documents

1 August

Badarpur, Delhi

1 August

2025

2025

03:00 pm

04:30 pm

The Tender will be opened in the presence of members of Departmental Tender Committee and bidders

who may wish to be present there. The Bid shall. be considered valid of only those contractors/agencies who will
submit the attested copies of the following documents along with Tender document:
1.

Valid PANCard.
Registration under GST.
MSME certificate.

Partnership Deed in case of partnership firm.
V

Experience of Similar Archaeological/Heritage conservation works being executed by the Agency or
through consortium during the last three years along with supporting documents.

vi. Undertaking on Rs. 100/- e-stamp paper stating that the Terms & Conditions have been completely
understood and agreed.

Along with the above mentioned Documents, the Contractor/Agency should also has to submit Earnest Money

Deposit (EMD) amounting Rs. 9,191/- (Rs. Nine Thousand One Hundred Ninety One Only) in the form of
Demand Draf/ Pay Order/ FDR in favour of DDO, Department of Archaeology, Government of NCT of Delhi,
with the submission of Tender.

Note: No exemption in EMD given to Agencies under MSME.

Encl: Schedule of Oty with terms & conditions.

<!-- page 2 -->

SCHEDULE OF QUANTITIES
Name of Work: Minor Conservation and Development works at Kos Minar Monument near Northern
Gateway., Badarpur, Delhi
SI.
No.

Name of the Items

Rate

Amount

7.95cum

F801.00

T6,368

depth but exceeding 1.5 min width as wellas 10sqm on plan
including getting out disposal of excavated earth upto 50 m 48.45sqm

F130.13

6,305

17.28sqm

F182.00

3.145

0.75cum

F1,160.64

7870

Providing hard quartzite stone random rubble masonry plain
work teething with existing old masonry as per original pattern

0.38cum

F|4.607.50

5,551

for pointing work and placing of debris upto a 50m lead for

27.60sqm

F72.61

2,004

Pointing of raked out joints of R.R. masonry by using Lime
mortar 1:1:1(1 Lime: 1Coarse sand: 1Surkhi) mixing with

27.60sqm

F709.00

Z19,568

0.66cum

FI1,641.55

7.683

28.80sqm

F1,224.50

E35,266

53.68sqm

211.5I

|1354

Dismantling

Lime

concrete

manually

Area/

from

the

area

surrounding the monument including disposal of material

Quantity

within 50 metres lead.
Earth work in surface excavation not exceeding 30 cm in

and lift 1.5 m, as directed by Engineer-in-charge: All kinds of
soil.

Taking out old decayed and damaged/pulverised plaster
manually including raking of joints &cleaning of the surface
of wall masonary and placing of debris upto a 50 m lead for
further disposal.
4

Demolishing stone rubble masonry manually/ by mechanical

means including stacking of serviceable material and disposal

of unserviceable material within 50 metres lead as per direction
of Engineer-in-charge :ln lime mortar

5

with mortar in ratio 1:1:1 (1 Lime: 1 Surkhi: 1Coarse sand)
including Gur/sheera & Belgiri.
Raking out joints of R. R. masonary for preparing the surface

6.

further disposal.
7.

1/3rd Brick zeera, Gur & Belgiri.
8.

9.

Lime concrete 50mm for coping on parapet / top of boundary
walls (1 lime: 1sand: 2 brick aggregate/ brick zeera 5 to 1Omm
nominal size).
Replastering on the interior or exterior of the monument upto a

height of 7m above ground level in two coats with Ist coat

30mm thick mixed withl/3 brick zeera 5 to 10 mm nominal

size & 2nd coat 20Omm thick in lime mortar 1:1:1 (1 Lime: 1
Surkhi: 1Coarse sand) mixed with Gur'sheera &belgiri.

Clcaning the sand stone surface and removing dirt, dust, bird

dropping. grease, oil, algae, fungus, monkey beats, vegatable
growth etc., including providing, applying and washing the
surface with Liquid Ammonia Chemical of 5 % solution and

other Chemical cleaning agent as approved by Achaeological
Survey of India/ engineer-in-charge, of approved brand and

manufacturer, with the help of required scrubbers and also

cleaning with machine operated water jet mixed with desired

quantity of fine silica where ever reqired, without causing any

scratchingldamage to the stone surface aqnd finally washing

the surface with clean water with the help of pressure jet

machine, complete in all respect, including taking all
precautions to safeguard ventilators, windows, doors etc. by

suitable covering so as to avoid any damage to the
building/structure, all as per direction of

Engineer-in

charge(T he rate in inclusive of all materials &labours involved

except scaffolding).

<!-- page 3 -->

Providing and applying antifungal wash treatment using 3%
solution of sodium pentachlorophenate, of reputed brand and
manutacturer, on cleaned sand stone surface at desired

82.48sqm

F78.07

Z6.439

82.48sqm

F110.14

F9,084

3.65cum

F8,407.50

30.687

36.45sqm

F3.907.00

Z1,42,410

including cutting, hoisting , using structural steel etc. as

251.49kg

F172.98

43,503

more coats on new work over an under coat of suitable shade

9.00sqm

5226.75

2,041

44.55sqm

F103.03

74,590

59.35sqm

$338.99

20,119

1000.00kg

F5.66

5,660

locations as per direction of Engineer-in-charge(The rate is
inclusive of all materials & labours involved except

12

scaffolding)
Applying breathable, non-reactive, antifungal,and water
repellant

Silane/

Silaxane

chemical

as

approved

by

Archaeological Survay of India/ Engineer-in -Charge, of

approved brand and manufacture, diluted with solvent mineral

Turpentine oil in the ratio of 1:12(one part of approved

chemicai: 12 part of Turpentine oil), on the existing sand stone

masonary surface with two or more coats to give uniform
application of chemical on the surface, all complete as per

direction of Engineer -in -charge( The rate is inclusive all
materials & labours involved except scaffolding).

13

Providing 100mm thick lime concrete base by using 40% lime

mortar 1:1:1 (1 Lime: 1Surkhi: I Coarse sand) mixed with
Brick Agg. 40mm nominal size.
/4

Stone flooring by using D.Q.Stone av.l5Omm thick on the
compacted dressed ground surface filling the joints minimum
25mm uniformly wide with lime mortar 1:1:1 (1lime: 1Surkhi:
lcoarse sand) including pointing the joints of D.Q.Stone floor
with basic lime mortar mix with 40% brick zeera Av. 10mm

nominal size and mixing with gur Belgiri.
15

16

Steel work welded

in built up sections / framed work

required for m.s. grill, gates and similar works etc.
Painting with synthetic enamel paint of approved brand and
manufacture of reqired colour to give an even shade: Two or

withordinary paint of approved brand and manufacture

17

Painting with synthetic enamel paint of approved brand and

manufacture of reqired colour to give an even shade: One or
more coats on old work.
8

Providing and fixing double scaffolding systemn (cup lock
type) on the exterior side of building/structure, upto 25 metre

height, above ground level, including additional rows of

Scaffolding in stepped manner as per requirement of site, made
with 40mm dia M.S. tube, placed 1.5 metre centre to centre,

horizontal & vertical tubes joint with cup & lock system with
M.S. Tubes. M.S. tube challis, M.S. clamps and staircase

system in the scaffolding for working platform etc. and
maintaining it in a serviceable condition for execution of work

of cleaning and/ or pointing and/ or applying chemical and
removing it thereafter. The scaffolding system shall be

stiffened with bracings, runners, connecting with the building
etc, wherever required, if feasible, for inspection of work at
required locations with essential safety features for the
workmen etc., complete as per directions and approval of

Engineer-in-charge. Note:- (|) The elevational area of the

scaffolding shall be measured for payment purpose.(2) The
payment will be made once only for execution of all items for

such works.
19

Dismantling steel work in built up sections in angles, tees, flats
and channels including all gusset plates, bolts,nuts, cutting

rivets, welding etc. including dimembering and stacking within

50 metres lead.

<!-- page 4 -->

20

21

Disposal of malba similar unserviceable, dismantled or waste
material
by mechanical transport including loading.

transporting. unloading to approved municipal dumping
ground for lead upto 10 km for all lits, complete as per
directions of Engineer-in-Charge.
Providing and fixing stainless steel ( Grade 304) 3.5 thick sheet
Signboard engraved and colour cotted with axonobel outdoor
ty pe paint or braille signage or cultural sign board including all
fixing screw ete all complet as per the detailed drawing and

32.44sqm

F495.18

16,064

| No.

F50,000.00

Z50,000

21.00 mtr

F376.62

7909

direction of engineer in charge

Providing and tixing concertina coil fencing with punched tape

concertina coil 600 mm dia 10 metre openable length ( total

length 90 m), having 50 nos rounds per 6 metre length, upto 3
mheight of wall with existing angle iron 'Y shaped placed 2.4
m or 3.00 m apart and with 9 horizontal R.B.T, reinforced

barbed wire, stud tied with GJ. staples and GJ. clips to retain
horizontal, including necessary bolts or G.I. barbed wire tied to

angle iron, allcomplete as per direction of Engineer-in-charge,
with reinforced barbed tape(R.B.T.) / Spring core (2.5mm
thick) wire of high tensile strength of 165 kg/ sq.mm with tape

(0.52 mm thick) and weight 43.478 gm/ metre (cost of M.S.

angle, C.C. blocks shall be paid separately)
24

4,36,62 |/

Total(A )
Contingency @1% on A

74,366/

Z18,556/

Add ESIC and ERF @ 4.25%

TOTAL

4,59,543/

((Rupees Four Lakh Fifty Nine Thousand Five Hundred Forty Three only )
(To be filled by the Agency)

Rate quoted by the Agency i.e. percentage above/below (In figure):
(In Words):
Signature of the bidder:

Name of the Agency:
Mobile No.:

Email ld:
Corresponding Address:

%

<!-- page 5 -->

CRMS &CONDTIONS:
The work should be done strictlvy following the archacological/Heritage conservation principles and in accordancc with the

specifications given in the schedule of Quantities.

The C'ontractor Agency should have expericnce of similar works cxecuted by them during the last Three years following Three similar

completed works cach of value not less than 40% of Estimated Cost of the Tender or Two similar completed works cach of value not

less
than 60"o of Estimated Cost of the Tender or One similar completed work of valuc not less than 80% of Estimated Cost of the
Tender.
I1 the perccntages quoted by two or more Contraclors/ Agencies are found same, then priority would be given to the Contractor/Agency
with the higher Turnover done during last Three years.
Ihe Percentage Rate in the Tender should be quoted in words and figures. No over writing / cutting will be accepted.
6.

Ihe quoted rate must be valid for one year from the date of award of the work order; nothing extra shall be paid by the Department.
Tender received after due date and time or delayed due to postal service after closing time will be summarily rejected and the

department will not be responsible for this.

Secretary (ACL) reserves the right to reject any or all the tenders at any stage without assigning any rcason.

The work must be completed within the time frame of 60days from the date of award of work failing which a penalty equal to 0.05°% of

the Quoted cost per day subject to a maximum 5% of the Quoted cost will be imposed shall be recovered trom payments
9,

ducperfomance security. However, for delay due to reasons beyond the control of Agency, suitable extension of time will be given by
Deparment on submission of the same by the Agency.

The item rates are inclusive of GST, Water charges, Labour Cess and Contractors Profit.

10. Water is to be arranged by agency. No T& P shall be provided by the Department.

It is advisable that Contractor should visit the site positively before submitting Tender so as to be acquainted with the nature/condition

o1 the work to be executed and how the materials will have to be stored, stacked at site or else. No material whatsoever will be supplied

hy the Department. The agency will also be responsible for the safety and security ofthe material and T&P.

12. Debarred blacklisted agencies shall not be permitted to submit Tender.

13. Being work of ancient nature, at some instance it may require modifications or alterations in certain items of works for which
Contractor will have to ensure the execution to the satisfaction of the department within the sanctioned rates until Department finds it
necessary to be included for payment at different rates.
14 In case poor quality of work is being done, the same will be treated as negligence on the part of the contractor and hence will have to

make good the same at his/her own cost tothe satisfaction of the Department.
15. The material bought to site by the Contractor /Firm should be strictly as per specifications given in the Items of Schedule of Quantities.
In absence of which. Contractor will have to exchange it with good quality material at his own risk and cost.

Originality in designs on the structure should be maintained strictly.
17. The Contractor shall take all precautions to avoid all accidents by exhibiting necessary caution boards day and night as safety measures.

He shall be responsible for all damages and accident caused due to negligence on his part.

18. The work may be having typical shapes, curves, ete. Special care will be required to maintain line, level and finish. No claim by the
contractor whatsoever on shape and nature of the work shall be entertained subsequently.

19. In case of any mishaps/accidents occurred during the discharge of duties by the labourers, the compensation liability will solely rest
with the Contractor and no compensation will be paid by the Department.
20. in case of Disruption in work. CPWD guidelines would be followed.

21. All disagreements. disputes, differences that may arise between the Department and the Contractor, and, which cannot be resolved

through mutual negotiations. shallbe referred to an Arbitrator appointed in accordance with the provisions of relevant Indian Law as
the case may be. The venue of the proceedings and arbitration shall be Delhi.
22
After award of work, within7days the Bidder should submit 5% of the Tendered amount as Performance Security (P.S) valid upto

2months from the date of completion of work in the forn of Demand Draft/ Pay Order/ FDR in favour of DDO, Department of
Archaeology,GNCTD payable at Delhiwhich willbe returned only after successful completion of work.
23. Over
10%from
fromthecvery
bill wilbe deducted as Sécurity Deposit (S.D) which will be released ater the maintenance period of six (6) months is
recorded completion date of work, if no defects are noticed in work during that period. If any defect is found, the S.D will
be released only after such defects are rectified by Contractor/Agency on their cost to the satisfaction of the Department.
24. Payment of ESIC/EPF will be reimbursed as per the actual paid by the Contractor in the welfare of labour & original documents should
be submitted to Department along with the Tax invoice.

25.

The Firmm must submit an undertaking on Rs. 100/- e-stamp paper with effect that the Terms & Conditions mentioned above have been
completely understood by them and they are agreed.

(Sanjay Kumar Garg)

Dy. Director (Archives) /HOO (Archaeology)

F.No.5 (05 )2025/Archy/

Dated:

Copy to- Departmental Website and Notice Board.

(Sanjay Kumar Garg)
Dy. Director (Archives) / HO0 (Archaeology)
