---
doc_id: "1cf908dea052bcbc"
source_url: "https://delhijalboard.delhi.gov.in/sites/default/files/Jalboard/generic_multiple_files/instructional_order_sw.pdf"
ministry: "Jal Board Department, Delhi"
title: "Download"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "c785a16ff02349f5"
---

<!-- page 1 -->

£ a DELHI JAL BOARD, GOVT. OF N.C.T. OF DELHI

} DEPUTY DIRECTOR(LABOUR WELFARE),

‘B’ BLD.,VARUNALAYA, KAROL BAGH,

Word NEW DELHI-05.

— E.Mail.I.D. lwodib@gmail.com

Ph.No.&23678380&8]&82 Extn.-253, 254

Office Order No:-3 Date:- 3.2.2023

INSTRUCTIONAL ORDER

Following Judgement of Hon’ble Supreme Court dated 20.0.2023 in the

matter of Dr. Balram Singh vs. Union of India & Ors. is hereby endorsed for strict
compliance by all Concerned of Delhi Jal Board.

l. To ensure that the compensation for sewer death is increased (given that the
previous amount fixed, i.e., Rs. I0 lakhs) was made applicable from 993. The
current equivalent of that amount is Rs. 30 lakhs. This shall be the amount to
be paid by the concerned agencies. In other words, compensation for sewer
death shall be Rs. 30 lakhs. In the event, dependents of any victim have not
been paid such amount, the above amount shall be payable to them.
Furthermore, this shall be the amount to be hereafter paid as compensation.

2. Likewise, in the case of sewer victims suffering disabilities, depending upon
the severity of disabilities, compensation shall be disbursed. However, the
minimum compensation shall not be less than Rs. 0 lakhs. If the disability is
permanent, and renders the victim economically helpless, the compensation
shall not be less than Rs. 20 lakhs.

This issues with the approval of Competent Authority. eH
(Yash Pal Gera)
Dy. Director (LW)
AlLDDO’s
No. DJB/DD(LW)/S.Death/2023/D - S444 te 55.262. Date:- 3.2.2023
Copy to:-

l. PA to Vice Chairman, DJB :- for kind information

2. PS to CEO, DJB :- for kind information

3. PS to CVO, DJB :- for kind information

4. All Members/Secretary, DJB/All Directors

5. Incharge (EDP) — for uploading the same on DJB website. Reo Sf

Dy. Director (LW)
