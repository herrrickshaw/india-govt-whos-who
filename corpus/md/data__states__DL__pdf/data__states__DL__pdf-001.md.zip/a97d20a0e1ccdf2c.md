---
doc_id: "a97d20a0e1ccdf2c"
source_url: "https://dbnn.delhi.gov.in/sites/default/files/dbnn/circulars-orders/nit_djb_plumbing_work_diet_dilshad.pdf"
ministry: "DIET, Bhola Nath Nagar, Shahdara, Delhi"
title: "Download"
date: ""
pages: 8
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "e322b03d4bd2a1c6"
---

<!-- page 1 -->

STATE COUNCIL OF EDUCATIONAL RESEARCH & TRAINING (SCERT), DELHI
DISTRICT INSTITUTE OF EDUCATION AND TRAINING (DIET)
J&K Block, Dilshad Garden, [26|॥--॥ 0095
NOTICE INVITING TENDER (NIT)
NIT No.: 2 Date: 08/09/2026
Subject: Notice Inviting Tender for providing DJB water supply and sewer connection
at DIET, J&K Block, Dilshad Garden, Delhi-I0095
Sealed tenders are hereby invited from eligible and duly authorised/licensed Delhi Jal
Board (DJB) plumbers/contractors for execution of the work of providing/connecting DIB
water supply and sewer connection to the premises of District Institute of Education and
‘Training (DIET), J&K Block, Dilshad Garden, Delhi-I0095, as per the specifications,
quantities, terms and conditions contained in this NIT.
l. Name of Work
Providing DJB water supply and sewer connection, including necessary plumbing,
materials, excavation, laying, jointing, testing and restoration at DIET, J&K Block,
Dilshad Garden, Delhi-I0095,
2, Scope of Work
The work shall include, but shall not necessarily be limited to, the following
l. Connecting the DJB water supply line from the nearest available DJB water line to the
DIET premises,
2. Connecting the water supply to the Underground Reservoir (UGR) at the Pump
House.
3. Providing the required water connection to both washrooms of the Multipurpose
Hall/House.
4. Carrying out the required sewer connection from the nearest available DJB sewer line
to the DIET premises.
5. Providing all necessary pipes, fittings, joints, valves, bends, connectors and other
materials required for proper and functional completion of the work
6. Excavation, laying, jointing, testing, filling and restoration of the excavated portion.
7. Proper protection of underground water-supply pipes, including concrete protection
wherever considered necessary, to prevent damage during subsequent excavation or
civil works
8 Providing and installing necessary water pumps/motors and associated fittings
wherever included in the approved estimate/BOQ,
9. Providing a DJB-approved water meter and other necessary fittings as required.
l0. Testing and commissioning of the entire water and sewer connection before handing
over the completed work. \
PRINCIPAL
District Institute of Education & Training (NE)
(SCERT, GNCT of Dathi)
J& K Peckal, Dashad Garden, Deihi-/0005

<!-- page 2 -->

Tar
l], Rectification, at the contractor's own cost, of any leakage, defective jointing, improper
installation or other defect attributable to defective workmanship or material

The work shall be executed in a technically sound and workmanlike manner and in

accordance with applicable DJB requirements and accepted plumbing practices.

3. Estimated Cost of Work

The estimated cost of the work is % 2,50,000 (Rupees Two Lakh Fifty Thousand only),

including/excluding GST as specified in the Schedule of Quantities.

The bidder shall quote rates for the complete work/items as prescribed in the BOQ.

4. Earnest Money Deposit (EMD)

EMD of 2_ shall be deposited in the form prescribed in the tender document.

The EMD shall be dealt with in accordance with the applicable provisions of GFR, 207 and
prevailing Government instructions.

Bidders claiming exemption from EMD, if admissible under applicable Government orders,
shall submit valid documentary proof along with their bid.

5. Performance Security

The successful bidder shall furnish Performance Security at the rate and in the manner
prescribed under the applicable GFR, 207/procurement guidelines and the tender conditions.
The Performance Security shall remain valid for the prescribed period and shall be liable to
forfeiture in accordance with the terms of the contract in case of failure to fulfil contractual
obligations.
6. Eligibility of Bidders
The bidder must:

l. Possess a valid DJB licence/authorisation for undertaking the proposed water
supply/sewer connection/plumbing work.

2. Submit documentary proof of valid DJB authorisation/licence.

3. Have adequate experience and technical capability for execution of similar works.

4. Have adequate manpower, tools, equipment and resources required for completion of
the work.

5. Comply with all applicable statutory requirements, including labour, safety, taxation
and other applicable laws.

6. Not have been blacklisted/debarred by DJB, Government Departments, Government
agencies, PSUs or any other competent authority as on the date of submission of the
tender.

7. Submit a self-declaration to this effect along with the bid.

7. Site Inspection \
PRINCIPAL
Disvict institute ot Eaucation & Training (NE)
(SCERT, GNCT of Daihi)
J & K Pocket, Ditshad Garden, Delhi-70095

<!-- page 3 -->

Bidders are advised to inspect the site and acquaint themselves fully with the site conditions,
existing services, access arrangements, location of DJB water/sewer lines and the nature and
extent of work before submitting their bids.
No claim arising subsequently on account of ignorance of site conditions shall ordinarily be
entertained.
Site: DIET, J&K Block, Dilshad Garden, Delhi-0095.
8. Schedule of Quantities / Indicative Materials
The major materials/items required for the work shall include but not limited to, as applicable
to the approved BOQ:
=e Specification | __—‘[Approx. Quantity
PF Pe

38 [Half Set va [iN |
a
ee

बा Fe

| Fd

[Female FTAEIbow [a"* I" ft
a

fa re

[| Clamp वि > w™s—<i«‘CSCSC*dWA required =|

fst हि खा

हि वन

I

छाक्कील arate . uF rat है 5 7०4०9 हक
ISCERT, GNCT gt Dain’)
4३ © Poukei, Disiad Garden, Derr: * “9096

<!-- page 4 -->

9 pvc Sowven 90 _
20. |icPvC Solvent 250 ह्वए
22 [0० एणचाए Branded, ।.5 घए
: I
ee
25 {40 kg, branded 20 packets
26 Sand/Dust As required [AsperROQ | s per BOQ \
विन लक Zero Concrete As per BOQ
sage
[Miscellaneous items||As required at site
Note: The above quantities are based on the requirements indicated in the existing quotation.
notice and shall be treated as tentative until verified and incorporated in the approved detailed
estimate/BOQ.
9. Labour
The bidder shall quote separately for labour/execution for: है

|. Water-line work; and

2. Sewer-line work.
All labour, supervision, tools, equipment, transportation and incidental expenses required for
satisfactory completion of the work shall be deemed to be included in the quoted rates unless
specifically provided otherwise in the BOQ.
0. Completion Period
The entire work shall be completed within 07 (seven) days from the date of issue of the Work
Order, or within such other period as may be specified in the Work Order.
The contractor shall complete the work, including testing and restoration, within the stipulated
period. The original proposal also contemplated completion within one week.
l. Tender Submission
‘The tender shall be submitted in the prescribed format along with duly filled and signed BOQ
» valid DJB licence/authorisation; GST registration, wherever a ile casa PAN; detaj

PRINCIPAL
District Institute of Education & Training (NE)
(SCERT, GNCT of Delhi)
eee J &K Pocket, Ditshad Garden, Delhi-0095

<!-- page 5 -->

similar works executed, EMD, wherever applicable; declaration regarding non-
blacklisting/debarment; acceptance of all terms and conditions of the NIT, and any other
document specifically required in the tender document.
2. Last Date and Time for Submission
Last date: |]/09/2026, Time: |0:00AM
Place: Office of the Principal, DIET, J&K Block, Dilshad Garden, Delhi—!0095
Tenders received after the prescribed date and time shall not ordinarily be considered.
3. Opening of Tender
The tenders shall be opened on: Date: | /09/2026 , Time: 2:00AM
Venue: Office of the Principal, DIET, J&K Block, Dilshad Garden, Delhi-!0095. |
]4. एरश्रोपश्नांणा ० वशावेशा$
The tenders shall be examined in accordance with the applicable procurement rules and the
tender conditions.
The evaluation shall include:
e eligibility and validity of DJB licence/authorisation;
* completeness of tender documents;
* technical suitability:
* experience and capability;
* compliance with specifications;
e financial bid/rates; and
« reasonableness of the quoted rates.
The contract shall ordinarily be awarded to the lowest evaluated responsive and technically
qualified bidder (L-), subject to determination of reasonableness of rates and approval of the
competent authority.
Lowest quotation shall not by itself confer an automatic right to award of work where the bidder
fails to meet the prescribed eligibility, technical or other tender requirements.
5. Taxes and GST
The bidder shall clearly indicate whether GST and other applicable taxes are included in or
excluded from the quoted rates.
GST shall be dealt with in accordance with applicable law and Government instructions.
6. Quality of Materials and Workmanship
All materials shall be of approved/appropriate quality and suitable for the intended purpose.
The underground water-supply pipes shall be adequately protected wherever required. The
work shall be inspected by the authorised officer/committee of DIET. Any defective work,
PRINCIPAL
Distiet Inotitute of Education & Traini (NE)
(SCERT, GNCT of Delhi)
A em Ao. Meth ETANAK

<!-- page 6 -->

leakage, improper jointing or substandard workmanship detected during execution of within
the applicable defect-liability period shall be rectified by the contractor at his/her own cost
7. Safety and Protection of Existing Services
The contractor shall take all necessary safety precautions during execution. Care shall be taken
to avoid damage to, existing building structures, roads and pavements; drains; electrical
installations; water lines; sewer lines; and other underground/overhead services. Any damage
caused due to negligence of the contractor shall be repaired at the contractor's own cost. These
requirements are consistent with the conditions contained in the existing quotation notice.
8. Payment
Payment shall be released only after:

l. satisfactory completion of the work;

2. testing and commissioning;

३. verification/measurement of the work;

4. certification by the authorised officer/committee;

5. submission of proper bill and supporting documents; and

6. compliance with all applicable financial and tax requirements.
No advance payment shall be admissible unless specifically permitted/approved under the
applicable rules and tender conditions
9. No Splitting of Work
The entire requirement relating to the proposed DJB water and sewer connection shall be
treated as one composite requirement for determining the applicable procurement procedure
and financial powers. The work shall not be split inte artificial components with the objective
of avoiding the procurement procedure or financial sanction applicable to the total estimated
value. This is also consistent with the principle in Rule 37 of GFR, 207, under which a group
of works forming one project is to be considered as one work for approval and sanction
purposes.
20. Procurement Procedure
The procurement shall be undertaken strictly in accordance with the applicable provisions of
GFR, 207, the Manual for Procurement of Works, Second Edition, 2025, applicable
SCERT/GNCTD financial rules and instructions, and the Delegation of Financial Powers
applicable to the competent authority.
Where the estimated value falls within the threshold for Limited Tender Enquiry, the tender
shall be invited from the appropriate eligible/enlisted contractors in accordance with the
applicable procedure. The 2025 Works Manual provides LTE as the default mode for works up
to 70 lakh and prescribes competition among appropriate contractors. Where the estimated
value or circumstances require another procurement mode, —— appropriate_mode shall be
adopted instead. वर

Disinet s.cutun 0000!
(SCERT, GNCT of Deity
J &K Pocket, Dishad Garden, Detni-4{0085

<!-- page 7 -->

24, Administrative Approval and Expenditure Sanction
‘This NIT shall be issued/processed only after obtaining the requisite Administrative
Approval, Expenditure Sanction and approval of the competent authority, and after
ensuring availability of funds, as applicable.
No work shall be commenced, and no liability shall be incurred before completion of the
mandatory pre-requisites under the applicable financial rules. Rule |36 of GFR, 20 \7
specifically requires administrative approval, expenditure sanction, sanctioned
designestimate, funds, proper tender processing and issue of work order before
commencement of works
22, Right of Acceptance/Rejection
The competent authority reserves the right to accept or reject any or all tenders, wholly or
partly, in accordance with the applicable rules, without assigning any reason, subject to the
principles of transparency, fairness and reasonableness governing public procurement.
23. Cancellation of Tender
The competent authority reserves the right to cancel the tender process at any stage before
award of work, in accordance with applicable rules, if circumstances so warrant.
24, Dispute Resolution
Any dispute arising out of the contract shall be dealt with in accordance with the dispute-
resolution provisions incorporated in the final contract/work order and applicable
Government instructions.
25. General Conditions
!. The contractor shall comply with all applicable DJB norms and requirements.
2. All statutory permissions/approvals required from DJB or other competent authorities
shall be obtained as applicable.
3. The contractor shall arrange all labour, tools, equipment, materials and transportation
necessary for completion of the work.
4. The contractor shall maintain proper safety precautions at the work site
5. The contractor shall not subcontract the work without prior written permission of the
competent authority.
6. The work shall be executed under the supervision of the authorised officer/committee.
7. Measurements shall be recorded and verified before payment.
8. No payment shall be made for defective or unapproved work/material.
9. The contractor shall leave the site clean and restore all excavated portions to the
satisfaction of DIET.
rea eS रे
monies “CF ot Dell)
08800 ० (SCERT. GNcT ot ‘ ethi-t0085
va bocket, Dashad 6308"

<!-- page 8 -->

I0. The contractor shall comply with all applicable labour, tax, safety and statutory
requirements. eo
Principal
District Institute of Education and Training (DIET)
J&K Block, Dilshad Garden
Priiic:bkQ095
4 . Adit Institute of Education & Training (Ne
‘opy to: san (SCERT, GNCT of Deihi)
l. Notice Board, DIET, J&K Block, Dilshad Garden. Garr te,
2. Concerned Committee constituted for shifting of DIET.
3. SCERT Website/appropriate e-procurement portal, as applicable.
4. Office Record.
|,
