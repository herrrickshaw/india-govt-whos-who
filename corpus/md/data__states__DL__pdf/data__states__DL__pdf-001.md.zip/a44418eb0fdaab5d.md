---
doc_id: "a44418eb0fdaab5d"
source_url: "https://drn.delhi.gov.in/sites/default/files/drn/circulars-orders/10-dietpinkbook-1989.pdf"
ministry: "DIET, Rajinder Nagar, New Delhi"
title: "Download"
date: ""
pages: 125
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "aa83f0be648e3871"
---

<!-- page 1 -->

DISTRICT INSTITUTES
OF
EDUCATION A N D TRAINING

GUIDELINES

GOVERNMENT O F INDIA
MINISTRY OF HUM AN RESOURCE DEVELOPMENT
(DEPARTMENT OF EDUCATION)
NEW DELH I
NOVEMBER, 19&9

<!-- page 2 -->

0 7 ' /
I f j ft "

^T^HS 3 t3 R I ^

3 1 1 • " 'TT*
N a tio n 4 i (« a ' ts i J ; W .ir io n a l
P U u » i« 4 •-«* 1 '■ >«i.-*.*«>.'»»tion

sf

y.

5 ° ^

'UC ^KY

L

<!-- page 3 -->

PREFACE

After the adoption of the National Policy on Education 1986, a Centrally
Sponsored Scheme for Restructuring and Reorganisation of Teacher Education
is being implemented since October, 1987 . One of its components is establish­
ment of District Institutes of Education and Training (D IETs). Draft guidelines
for this component t^ere got prepared through Educational Consultants India
Limited (Ed. CIL), and were circulated to States and Union Territories in
October, 1987. That document, together with certain subsequent circulars, has
formed the basis for implementation of the DIET Scheme so far. Need for
bringing out a more comprehensive set of guidelines for DIETs has been felt
for quite some time now. The present document has been prepared to fulfil
this need.
The first lot of DIETs were sanctioned in February-March, 1988. By and
large, it is only now that these are getting operationalized. As further experience
is gained, guidelines for DIETs would also continue to evolve.
The present document has been prepared in close collaboration with NCERT,
N1EPA and the Directorate of Adult Education, and we a re. very grateful to
them for their immense help in this exercise.

New Delhi
November 1. 1989

Prof. J. S. RAJPUT
Joint Educational Adviser
Government of India
Ministry of Human Resource Development
Department of Education

<!-- page 4 -->

<!-- page 5 -->

TABLE OI< CONTENTS
O

h apter

Page

Part I : DIET The Concept
I .

District Institutes o f E ducation a n d T raining : T heir C ontext, M ission and R ole

21.

D istrict Institutes o f E ducation a n d T raining :

35.

G uidelines for Program m es a n d Activities

.

.

Functions and Suggested S tructure .
.

.

.

.
.

.

.

.

.

1

.

.

.

.

.

.

.

8

.

19

.

PART IT : DIETs—Implementing the Concept
4k

E stablishm ent o f

D istrict Institutes o f

E ducation a n d T raining :

5i.

Perspective P lanning, Project fo rm u la tio n and S anction

.

<S>.

O perationalising D IE T s :

.•

77.

M onitoring and Review

Project Im plem entation
.

.

.

.

.

.

.

M ain
.

.

Features o f the Schemes

.

.

.

.

.

.

33

.

37

.

43

.............................................................................
.

.

.

.

.

.

.

48

.

Annexes
A'ininex

1

AVanex

2

N P E /N L M Strategy in th e A rea o f E lem entary a n d A dult E ducation, a n d DIETs, R ole in th a t C ontext .
(1) N P E

and

PO A

o n T eacher E d u catio n /D IE T s

.

(2) C entrally Sponsored Scheme o f T eacher E d u catio n

.

.
.

.
.

.
.

.
.

.
.

.

.

56

.

.

56

.

.

.

.

58

district w hich satisfies criteria given in p a ra 2 .6 . 1 .

.

.

60

AVnnex

3

Resum e o f Im plem entation o f Im p o rtan t Initiativ es in E lem entary and A dult E du catio n

AVnnex

4

N orm s for a D IE T to be set up in

a

.

53

A \nnex

5

Some suggestions re g ard in g T ran sactio n M ethodology for the Pre-Service T eacher E ducation C ourse

.

62

AVnnex

6

E xtracts from C h a p te r V III (“ the C ase for In-Service E d u catio n ") o f th e R ep o rt o f the N a tio n a l C o m #
m ission o n T eachers-I ........................................................................................................................... ...........

63"

C onditions for R ecognition o f E lem entary T each er E ducation Institu tio n s prep ared by the N C T E C om ­
m ittee o n E lem entary T eacher E du catio n
........................................................

71

73

AVnnex

7

AVnnex

8

A nnual R ecurring Budget o f a typical D IE T established as per norm s given in A nnex 4

AVnnex

9

F orm at

for

S tatu s

R eport o f

existing

E lem entary

.

.

Teacher E d u ca tio n Institu tio n s

Avnnex 10

F o rrm t for prep arin g S tate/U T level Perspective Plan for E lem entary

A n n e x 11

F o rm a t for p reparing D IE T project proposals

Ainmex 12

G uidelines re g ird in g R ecruitm ent Procedures, Eligibility Criteria and C adre M anagem ent

Avnnex 13

Suggested Physical N orm s for the

AVnnex 14

Suggestions for Effecting Econom y in C onstruction o f D IET Buildings

AVnnex 15

Some G eneral G uildelines regarding Selection o f Books for D IET Libraries

.

.

Teacher E du catio n
.

.

.

.

.

.
.

.

75

.

.

80

.

93

.
.

.

97

buildings o f a D IET established a s per norm s given in Annex 4

.

104

(iii)

.

.

.
.

.

.
.

.

.

.

.

.

107
114

<!-- page 6 -->

<!-- page 7 -->

PART-I—DIET : THE CONCEPT

Clnaipter 1 District Instiiutcs of Education and Training : Their Context, Mission and Role
Chutpter 2 District Institutes of Education and Training : Functions and Suggested Structure
Chn.pter 3 Guidelines for Prog ammes and Activities

(v)

<!-- page 8 -->

<!-- page 9 -->

CHAPTER 1

DISTRICT INSTITUTES OF EDUCATION A N D
TRAINING—THEIR CONTEXT, MISSION A N D
ROLE
1.1 Introduction
Universalisation of elementary education and eradi­
cation of adult illiteracy have been two of the most
imjportant and basic goals of educational development
in India since independance. Part IV of our Consti­
tution lays down the Directive Principles of State
Policy. Article 41 under this Part says that “the
State shall, within the limits of its economic capacity
and development, make effective provision for secur­
ing the right t o ...........e d u c a tio n ..............Article
45 under the same Part, which deals with “provision
for free and compulsory education for children”,
rcaids as follows :—
“The State shall endeavour to provide, within a
period of 10 years from the commencement of
this Constitution, for free and compulsory edu­
cation for all children until they complete the
age of 14 years.”
The country has, since independence, made con­
siderable progress in the areas of elementary educa­
tion and literacy. Literacy percentage improved from
16-7% in 1951 to 36.2% in 1981, but we still h^ye
a Hong way to go before we achieve universal literacy
There is also wide disparity between sexes, and
among various other kinds of groups, in this regard.
Foir example, literacy percentage among men in 1981
wa;s 46.9% but for women was only 28.8% . There
weire also wide inter-State variations, with Kerala
hawing literacy rate of 70.7% , and Arunachal Pradessh 20.8% . Women’s literacy varied from 65.7%
in Kerala to just about 11 % in Rajasthan and Aruna­
chal Pradesh. Even as late as in 1987-88, the gross
enrolment ratio of girls in the 6 to 11 years age
group was about 82% for the country as a whole,
and was as low as around 50% in the States of UP
and Rajasthan. The incidence of drop-outs at the
primary stage of education is also high— only an esti­
m ated 32.35% children complete 5 years of educa
tiom by the time they attain about 11 years of age.
Even within the primary stage, drop-outs are prob­
ably highest in the first two or three years and these
early droup-outs tend to soon lapse into illiteracy.
2— 551Edu/89

1.2 NPE on the Goal of Universalisation
In may, 1986, Parliament adopted a new National
Policy on Education (NPE) and in August, 1986
approved a detailed Programme of Action (POA ) for
its implementation. The NPE states the goals of
universalisation of elementary education (U E E ), and
of eradication of illiteracy, in the following terms :—
“A RESOLVE
5.12............... It shall be ensured that all chil­
dren who attain the age of about 11 years bv
1990 will have had five years of schooling, or
its equivalent through the non-formal stream.
Likewise, by 1995 all children will be provided
free and compulsory education upto 14 years of
age.”
*

*

*

“4 .1 2 ............... The whole nation must pledge
itself to the eradication of illiteracy, particularly
in the 15— 35 age group........... The mass lite­
racy programme would include, in addition to
literacy, functional knowledge and skills and
also awareness among learners about the socio­
economic reality and the possibility to change
it.”
The N PE also envisages a national system of edu­
cation, two of whose features are :—
(i) It will be based on a national curricular
framework comprising a common core and
other components that would be flexible,
The common core will aim to promote
national identity and other essential Values
like scientific temper, egalitarianism, demo­
cracy, socialism, secularism, protection of
the environment, small family norm, etc.
(ii) Laying down of minimum levels of learning
for each stage of education.
The above statements are specially significant for
elementary education, and have also certain relevance
for adult education.

<!-- page 10 -->

2

It is also important to note the inter-relationship
between the twiji goals of UEE and universal adult
literacy. Literate parents send their children to pri­
mary schools more readily, their children are less
likely to drop-out and their achievement in school is
higher. Progress in adult education would there­
fore help achieve U EE which, in turn, would reduce
the size of the adult illiteracy problem. The two toge­
ther thus form a virtuous circle.
1.3 Goal of Universalisation—meaning
1.3.1
The universalisation goal—whether of ele­
mentary education or adult literacy—has two aspects,
namely :— (i) universal enrolment and retention of
children/persons in the relevent age group in the ele­
mentary school/non formal education/adult educa­
tion system and their regular attendance, and (ii) uni­
versal attainment by them of at least the specified
minimum levels of learning, with due stress on the
inculcation of essential values.
The above two components could be termed as
the numerical and qualitative aspects of the universa­
lisation goal— the latter being the ultimate end, and
the former the means to achieve that end.
1.3.2 Universalisation in the context of Elementary
Education
In the case of universalisation of primary/elemen­
tary education (U P E /U E E ), it is important that
children attain prescribed minimum levels by a cer­
tain specified age. The U P E /U E E goal could be
stated in specific terms as follows :—
UPE
To ensure that every child, by the time he/she
attains a specified age, achieves at least the
minimum levels of learning prescribed for the
primary stage of education.
UEE
To ensure that every child, by the time he/she
attains the age of about 14 years, achieves at
least the minimum levels of learning prescribed
for the upper primary stage of education.
The NPE (para 5.12) stipulates the ‘specified
age’ in the context of UPE as 11 years. How­
ever, the POA (para 12, Chapter II) says that
“for some years to come, we should have no ob­
jection so long as children complete five years
of education, or its equivalent through the nonformal stream, by the time they complete about
14 years of age”.

1.3.3 Universalisation in the context of Adult Educa­
tion
In May, 1988, a National Literacy Mission (NLM)
was formally launched to tackle the problem of illite­
racy in a time-boupd manner. In 1991, there will
be an estimated 116 million illiterates in the country
in the 15-35 age group. The Mission seeks to
impart ‘functional literacy’ to 80 million of these, by
1995. It proposes to do this, ipter alia, by consolida­
ting and further building upon various programmes
of Adult Education.
Functional literacy’ for the Mission’s purpose has
been defined as :—
—

Literacy and numeracy;

—■ Acquiring skills to improve economic status
and general well-being;
—

Becoming aware of the cause of deprivation
and moving towards its amelioration through
organisation and participation in the pro­
cess of development;

—

Imbibing essential values like national inte­
gration, women’s equality, conservation of
environment, small family norm, etc.

Thus the NLM target also has the same two-nume­
rical and qualitative-dimensions.
1.4.1 Goal of Qualitative Improvement
1.4.1
U EE and universal adult literacy (specially in
the 15-35 age group) have to be our most important
immediate goals in the area of elementary and adult
education respectively since we are still very far even
from these basic goals.
A t the same time, however,
the perspective beyond universalisation has to be kept
in view as well. NPE says that the new thrust in ele­
mentary education will emphasize, beside universal
enrolment and retention, “a substantial improvement
in the quality of education”. The first indicator of
this improvement in quality would, of course, be uni­
versal attainment of minimum level which is already
reflected in the universalisation goal. Ultimately how­
ever, the qualitative improvement goal is an openended one, and is perhaps best reflected in Article
51A of the Constitution which lists as one of the
fundamental duties of every citizen of India :

“to strive towards excellence in all spheres of
individual apd collective activity so that the
nation constantly rises to higher levels of en­
deavour and achievement”.

<!-- page 11 -->

Thus, besides UEJB, pursuit of excellence has to
Ihe other guiding principle in the area of elementary
pocation. Even in the case of Adult Education,
■pig, and NLM do not merely visualize imparting of
■actional literacy, but aim at promoting life-lon^ and
|ifltin uing education.
1,4.2
In the light of what has been stated above.
jw r goals in the areas of elementary and adult educa|jnn could tie summarised as follows :—
(i) Universal attaiiuncnt of minimum levels ot
learning with due stress on value education,
and
(ii) Pursuit of excellence-'life-long and
nuting education.

eonti

i l i Strategy
To achieve the above objectives, the following
Irlnris of inputs would be required in the systems of
Elementary Education (including Non-Formal E d u ­
cation) and Adult Education :—
(i) Financc and physical resources (e.g. build­
ing and equipment)
(ii) Full involvement of the community
(iii) Planning and management
(iv) Appropriate curricula, text books and peda­
gogical inputs
(v) Suitable strategics (including incentives) for
learners from disadvantaged groups so as to
provide them equal educational opportunity
in real terms
(vi) Dedicated and competent teachers and ins
tructors
(vii) Suitable academic and resource support to
the teachers/instructors which would com­
prise :—
(a ) Training, guidance and advice,
(b) Development of locally relevant teach
ing—learning material and teaching
aids,
(c) Evaluation, and
(d) Field studies, action research and ex­
perimentation for tackling specific local
problems encountered in
achieving
goals.
The NPE, POA and NLM envisage comprehensive
strategies byway of providing the above inputs, in
order to achieve the objectives stated in para 1.4.2.

Various elements of these strategies
Annex. 1.

are

listed in

1.6 DIETs : An Introduction
While all the inputs listed in the preceding p ara­
graph are crucial, the last two are especially so
About teachers, the Education Commission (1964—
66) had observed that “of all the factors that influence
the quality of education........... the quality, competence
and character of teachers are undoubtedly the most
significant” . But these in turn depend substantially
on the quality of training and other support provided
to them. The importance of the last input mentioned
in the preceding para— viz. academic and resource
support— can therefore hardly be over-emphasized.
Until the adoption of the NPE, this support in the
area of elementary education was being provided
largely at the national and State levels only—by insti­
tutions like NCERT, NIEPA and SCERTs. Likewise
in the area of adult education, this support was being
provided by the Central Directorate of Adult Educa­
tion at the national level, and by State Resource
Centres (SRCs) at the State level. Below the State
level, there were elementary teacher education insti­
tutions but their activities were confind mostly to
pre-service teacher education. The physical, human
and academic resources of most of the institutions
were inadequate even for this limited role. They also
tended to adopt teaching practices which were not in
consonance with the ones they prescribed to pros­
pective teachers. There were certain larger problems
as well e.g. courses of study being out-dated.
By the time of adoption of the NPE, elementary
and adult education systems were already too vast
to be adequately supported by national and State level
agencies alone. The NPE implied their further ex­
pansion as also considerable qualitative improvement.
Provision of support to them in a decentralised manner
had therefore become imperative. The N PE and
POA accordingly envisaged addition of a third—
district level— tier to the support system in the shape
of District Institutes of Education and Trafalng
(D IETs). With this, expectation would be of wider
quantitative coverage as well as qualitatively tetter
support as these Institutes would be closer • to the
field, and therefore more alive to its problems and
needs. Extracts from NPE and POA which throw
light on the functions envisaged for the DIETs may
be seen in Annex. 2.
Pursuant to the provisions of NPE on teacher edu­
cation, a Centrally Sponsored Scheme of Restruc­
turing and Reorganisation of Teacher Education was
approved in October, 1987. One of the five compo­
nents of the Scheme was establishment of DIETs.

<!-- page 12 -->

1

Certain details about the Scheme may be seen in
Annex. 2. Draft guidelines for implementing the
DIET component were circulated to States in October,
1987, and have, together with certain subsequent cir­
culars, formed the basis for its implementation so far.
Till October, 1989, Central assistance had been sanc­
tioned under the Scheme for setting up a total of 216
DIETs in the country.
Annex. 3 gives a resume of progress of other
important initiatives in the area of Elementary and
Adult Education, as on 31-3-89,
The present document purports, to consolidate,
amplify and revise the existing guidelines in regard to
DIETs. With this, all earlier guidelines on the sub­
ject would stand superseded.
1.7 DIETs : Mission and Role
1.7.1 Mission

With the background given in the preceding sec­
tions, a DIET’s Mission could be briefly stated in the
following terms :—
“To provide academic and resource support (vide
para 1.5) at the grass-roots level for the success
of the various strategies and programmes being
undertaken in the areas of elementary and adult
education, with special reference to the following
objectives :—
Elementary Education : —
IJniversalisation of primary/elementary education.
Idiilt Education

As far as the first aspect is concerned, efforts will
he made to provide to DIETs all necessary physical
and- manpower resources. But it will be for them to
harness these and other available resources in the best
possible manner, so as to achieve and promote excel­
lence.
In this context, DIETs will also have a very impor­
tant pace-setting role to play. They will be expected
to become models for other educational institutions in
the district in terms of meticulous, efficient and effec­
tive planning and execution of functions, harmonious
and creative organisational climate, maintenance of a
clean and attractive campus, etc.
1.7.3 DIETs : Part of a Larger Desigu
It would be clear from para 1.5 and Annex. 1 that
DIETs are a part of a larger strategy to achieve
national goals in the areas of Elementary and Aduli
Education. Various components of the strategy are
inter-dependent and mutually reinforcing. Annex. 1
also outlines DIETs’ role in the context of the other
components. DIETs cannot therefore afford to view
themselves in isolation, and must faithfully discharge
their role of supplementing and complementing other
parallel initiatives.
1.8 DIETs : Transactional Philosophy
1.8.1

A D IET will have 3 main functions, viz.

(i) training (both of induction level as well as
continuing varieties)
(ii) resource support (extension/guidance, deve­
lopment of materials, aids, evaluation tools,
etc.,) and
(iii) action research.

NLM targets in regard to functional literacy
the 15— 35 age group.

in

The above is a general mission statement.
It will have to be translated into specific goals for
the DIET, so as to suit the needs of individual
states and districts, and will be ultimately opera­
tionalised through specific performance norms
set for individual DIETs. ,
1.7.2 D IE T , . Pace-setting Role

Pursuit of excellence would have to inform all acti­
vities of the DIETs. in which context, it will have two
inter-related aspects :—
(i) Excellence in the Institute’s own work, and
(ii) Helping the elementary and adult education,
systems in the district, in achieving excel­
lence.

This Section discusses the basic approach anil
philosophy to be followed in undertaking these func­
tions, especially training.
1.8.2 Basic Transactional Approach for the D IE T s:
Placing the Learner a t the Centre
The N PE and POA plead for adoption of a ChildCentred approach in elementary education. The rele­
vant portion of N PE reads :
“CHILD-CENTRED APPROACH
5.6 A warm welcoming and encouraging
approach, in which all concerned share a solici­
tude for the needs of the child, is the best moti­
vation for the child to attend school and learn.
A child-centred and activity-based process of
learning should be adopted at the primary
stage........................

<!-- page 13 -->

P m 14 of Chapter II of the POA states that "by
Elementary Education child-centred, we would
be Introducing a long-awaited reform in the system,
■flu most important aspect of this reform will be to
mA a education a joyful, innovative and satisfying
turning activity, rather tHan a system of rote and
a i r l e s s , authoritarian instruction”.
In the case of Adult Education Programmes also,
it is clear that functional literacy should be imparted
to adults in a participative, learner-active mode.
The above statements contained in the NPE and
POA have profound implications for programmes of
teacher education and training of instructors of adult
and non-formal education. The child or learnercentred approach necessitates a fundamental change
in the m anner of curriculum transaction. The
nhallenge is an especially daunting one in view of
the special characteristics of our system— high pupilteacher ratio, multi-grade teaching, in-adequate physi­
cal facilities, and so on. The role of the teacher/
instructor would now be no longer one of transmitting
readymade knowledge to the learner but, instead, that
of a designer and facilitator of learning experiences,
a manager of instruction and learning resources, and
an active contributor to the all-round development of
the learner.
All programmes of pre-service and in-service
teacher education and of training of A E /N FE per­
sonnel in the D IET would be so designed as to train
the teacher/instructor in transacting curriculum, keep­
ing the learner at the centre of the teaching-learning
process. If the D IET is to achieve this, it follows
that it will have to transact its own programmes in
the same learner-centred mode which it would expect
of to trainees. This basic approach would imbue
the transaction of all programmes in a DIET. Some
of the implications of this would be as follows ; —
—

—

Good work done by trainees will be duly
recognised, encouraged, displayed and publi­
cised.

—

The DIET will itself adopt the attitude of a
“life-long learner” rather than that of an
oracle or know-all. It will receive as much
from the ‘field’ as it would endeavour to
give to it. The district will serve as the
‘school’ for its learning experiences, while
it may carve out one or two special areas
as its lab. areas’ (Please see sections 2.4
and 3.5).

1.8.3 DIETs : Special Target Groups
The concept a National System of Education
implies that, upto a given level, all students, irrespec­
tive of caste, creed, location or sex, have access to
education of a comparable quality”, says the NPE.
It goes on to say that “to promote equality, it will be
necessary to provide for equal opportunity to all not
only in access, but also in the condition for success”.
This is quite the essence of the universalisation task,
and means that needs of educationally disadvantaged
groups would have to be given maximum attention.
The largest such groups are :—
(i) Girls and women
(ii) Scheduled Castes aud Scheduled Tribes
(iii) Minorities
(iv) The handicapped, and
(v) Other educationally disadvantaged groups
e.g. working children, slum-dwellers, inhabi­
tants of hilly, desert and other inaccessible
areas, etc.
It follows that DIETs also, in all aspects of their
work, would have to give primary attention to promo­
tion of education of the above groups.
1.9 DIETs : Autonomy and Accountability

Programmes will be need-based. Even with­
in a group of trainees/participants, inc
dual differences and needs will be identi
and catered to.

Para 10.1 of the N PE says that “an overhaul of
the system of planning and management of education
will receive priority” . It also says that in this pro­
cess, two of the "guiding considerations” will be :—

—■ Trainees will be enabled to experim
discover, learn, practise and innovate
themselves, rather than being lectured
Learning activities will be suitably organised,
in individual and group modes.

(i) “decentralisation and the creation of a spirit
of autonomy for educational institutions” ,
and

—

Maximum possible use will "be made of the
local environment in the learning process.
Curricula and learning activities will be
suitably related to it.

(ii) “establishing the principle of accountability
in relation to given objectives and norms”.
In view of the above, DIETs would need to be
given adequate functional
autonomy— academic,
administrative and financial—and would at the same
time be accountable vis-a-vis clearly laid down objec­

<!-- page 14 -->

<■
tives and norms. They would be institutions of the
State Government or UT Administration, and will
therefore be ultimately answerable to them. The State
Govemment/UT Administration may exercise it^
supervisory functions through the SCERT and SRC.
However, the immediate accountability of the DIET
will be to the District Board of Education (DBE).
which, according to the NPE, is to be created to
manage education upto the higher secondary level
The DBE will set specific goals (in the long, medium
and short term) and performance norms for the DIET.
It will do so in consultation with the Institute, and
keeping in view general norms and guidelines laid
down at the national and State levels. It will also
review the Institute’s performance vis-a-vis such goals
and norms on an ongoing basis. Till DBEs are set
up, State Governments may designate SCERT/SRC
or some other suitable educational authority to per­
form the DBE’s functions vis-a-vis DIETs.
M O DLETs : Linkages

Not merely will every DIET establish a close and
continuing dialogue with ‘the field’ (i.e. with elemen­
tary schools, school complexes, teachers, head masters,
school supervisors, Instructors/Supervisors/Project
Officers of AE and NFE, and with District level
officers in these three sectors), but will also establish
dose linkagw with organisations and institutions at
the national, State, Divisional and District levels whose
objectives and interests converge with its own. Some
of these institutions would be as follows :—
A t the Divisional level :
NGOs, institutions of higher education, secondary
teacher education institutions, DRDA, local
Radio Station (wherever applicable), etc.
A t the Divisional level :
University Deptt, of Education, Institution of
Advanced Study in Education (IA SE)*, NGOs
and other concerned organisations and institu­
tions.
A t the State level :
SCERT, SIET, SRC for Adult Education, NGOs
A t the National lev e l:
NCERT (including its Regional College within
whose jurisdiction the state falls), NIEPA, Centre
for Cultural Resources and Training (CCR T),
Directorate of Adult Education, Central Institute
of Indian Languages, Mysore, Kendriya Hindi
♦Please see Annex. 3.

Sansthan, Agra, other premier organisations!
institutions and NGOs working in the area <|
elementary and adult education, etc.
In specific terms, the linkages would be established
through a meaningful and continuous dialogue if
which institutions share problems,
experience!
achievements, information and resources. The DIE*
may also work as an agency for implementing soni
of the programmes and activities of national and statf
level organisations.
1.11 DIETs to be Non-Vocation, Mainly
tial Institutions

Resides!

Organisation of in-service programmes for teachei
and training programmmes for A E /N FE personnel
would be one of D IET’s main functions. This acf
tivity would go on throughout the year, but woul
peak during school vacations because that is whej
the Institute’s resources would be free from the work
load of pre-service training, and also because th:
would cause minimum dislocation in schools. Theri
fore, DIETs will be non-vacation institutions— thef
personnel would have to be classified as ;non-vacatioi
staff’, and given consequential benefits as per Statf
Govts, rules.
s
i

DIETs would also be expected to provide ress
dential facilities to as many of their trainees as maf
be possible within the resources available for con!
struction of hostels. In utilising available hostel
accommodation, first priority shall be
given t(
trainees other than per-service trainees. The latiei
shall be accommodated to the extent possible afte
accommodation needs of all other training program
mes (e.g. in-service programmes for teachers, trai
ning programmes for A E /N FE personnel, etc.
have been met.
1.12 Guidelines in this document—Largely
cative

Indie,

As i,n the case of the earlier guidelines, the inten
don in this document too is not to lay down a rigt
set of guidelines for the whole country. These guide
lines should be- treated, in the main, as indicative
rather than prescriptive, and State Government woul
be expected to implement the programme of DIET
with such local variations and adaptations as may b
necessary in their respective contexts. At severs
places in this document, alternatives and flexibility
have also been specifically indicated. In some area
however, these guidelines would have to be applie
more rigidly, e.g. in regard to total number of post:
pre-conditions to be fulfilled by State Governmeni
for getting assistance, and matters dealt with in p;ir
1.11 supra.

<!-- page 15 -->

I | f t'on'l,ail',,n Volumes iu these Guidelines
an attempt has been made in this document
a gpf n out the areas of work, functions and activities
M W TRT at considerable length, these can be fully
ppreciaicd and worked out only i£ these Guidelines
re read in conjunction with certain other important
Jiicimients. Some of these are as follows :—
f1 ) NPE

(2) POA
|3 ) “Teacher Education Curriculum : A Frame­
work” published by the NCTE (presently
being revised)
§1) “National Curriculum lor Elementary and
Secondary Education : A Framework"
{revised version) published by the NCER r
in April, 1988.
|S ) “Work Experience in School Education :
Guidelines” published by the \ ( T R I in
July, 1087.

1 6 ) Centrally Sponsored Schemes of Operation

Blackboard, Non-Formul Education, Im­
provement in Science Education, Educacalional Technology, Environmental Orien­
tation to Education, and Integrated Educa­
tion for Disabled Children.
(7) N1EPA Guidelines on
School Complexes and
ning.

School Mapping,
Institutional Plan­

8) The ‘National Literacy Mission’ document
and the Scheme of ‘Jan Shikshan Nilayams’,
published by the Ministry of Human Re­
source Development (Department of Edu­
cation).
<9) Suggested Lists of Recommended Books
and Equipment for DIETs, prepared by
NCFRT.

<!-- page 16 -->

CHAPTER 2

DISTRICT INSTITUTES' OF EDUCATION A N D
TRAINING : FUNCTIONS A N D SUGGESTED
STRUCTURE
2.1 Functions of a DIET
The context, mission and role of the DIETs have
been discussed in the preceding Chapter, Their func­
tions, as spelt out in the POA, have been quoted in,
Annex 2. These could be re-slated as follows :—
(1) Training and
target groups :—
(i)

orientation

of the

following

Elementary school teachers (both pre-ser­
vice and in-service education),

(ii) Head Masters, Heads of School Complexes
and officers of Education Department upto
Block level
(iii) Instructors and supervisors of Non-formal
and Adult Education (induction level and
continuing education)
(iv) Members of DBE and Village Education
Committees (V E C s), Community leaders,
youth and other volunteers who wish to
work as educational activities.
(v) Resource persons who will conduct suit­
able programmes for the target groups men
tioned at (i) and (iii) above, at centres
other than the DIE T.
(2 ) Academic and resource support to the elemen­
tary' and adult education systems in the district in
other ways e.g. by (i) extension activities and inter­
action with the field, (ii) provision of services o f a
resource and learning centre for teachers and instruc­
tors, (iii) development of locally relevant materials
teaching aids, evaluation tools etc., and (iv) serving
as an evaluation centre for elementary schools and
programmes of N FE /A E .
(3 ) Action research and experimentation to deal
with specific problems of the district in achieving the
objectives in the areas of elementary and adult
education.
2.2 Structure of a DIET : Certain general considera­
tions
Looking to the above functions, a DIET would
need to have staff strength in the following areas :
(1 ) Foundations of Education and Pedagogy,

(2 ) The subjects
stages :— namely
(i)

taught

at

the

ElementJ

Languages taught at the elementary level
the district (these may be two, three
even four, depending on the number
languages which are introduced in a Stsg
at the elementary stage, and factors Iii
bilingual character of a district)

(ii) Mathematics
(iii) Environmental Studies— Social Science
(iv) Environmental Studies— Science

(v) Work Experience
(vi) Art Education
(vii) Health and Physical Education
( 3 ) Non-Formal Education

(4) Adult Education
(5 ) Curriculum, Material Development and Evalj
ation
(6 ) In-service Programmes, Field Interaction aq
innovation Coordination
(7 ) Planning and Management
(8 ) Educational Technology
2.3 Organisational

structure of a

DIET : A suj

gested model
A DIET may have academics in the above specil
lisms with or without their being organised or group*
into formations iike Depaitments/Branches/Units
Wings.
A Branch-wise structure however, seeii
desirable as it would make for a managable span o:
control for the Principal, and generally greater opera
tional convenience. While several alternative organ!
sational models could be thought of, on such mods!
is being suggested here not the least for histories
reasons, viz., that a similar model was recommendej
in the Draft Guidelines according to which the Scherra
of DIETs has been implemented since October, 198?
The model now suggested would comprise the follow
ing seven academic branches :—
( I ) Pre-service Teacher Education Brancf
(P ST E )— consisting of faculty members ii

<!-- page 17 -->

9

the “Foundations” area as well as in various
school subjects (excluding work Experi­
ence).
(2 ) Work Experience (W E) Branch
(3) District Resource Unit (DRU) for Adult
and Non-Formal Education
(4) In-Service Programmes, Field Interaction
and
Innovation Coordination
(IFIC )
Branch
(5 ) Curriculum, Material Development
Evaluation (CMDE) Branch

and

(6 ) Educational Technology (ET) Branch
(7 ) Planning and Management (P&M) Branch.
A s a general observation, it needs to be immediate­
ly clarified that most programmes and activities of,
a D IE T would involve more than one branches, and
the nomenclature of branches given above, indicates
principal nodal responsibility, and not total responsi­
bility. This would become clear pom a perusal of
the table given in path 2.4.1 infra.
In addition to the above academic branches, there
would have to be an Administration Section to pro­
vide necessary administrative support. Since DIETs
would be expected to organise in-service programmes
on a large scale, every DIET would need to have

separate hostels for men and women. These hostels
should be able to meet fully the residential require­
ments of training programmes for Adult Education/
Non-Formal Education personnel, and in-service
training programmes for teachers, and should in
addition, provide hostel accomodation to as many
pre-service trainees as possible, within the financial
norms of the Scheme. The DIET would also have
a library which would be rich in professional books
and journals, and a part-time clinic.
Each Branch may be headed by a person who
would be generally designated as a Senior Lecturer,
with necessary number of Lecturers to support him,
depending on the functions and work-load of the
Branch. However, wherever a D IET has a fullfledged DRU (please see para 2.6.2), its head will
be designated as a Vice-Principal, instead of Sr.
Lecturer.
2.4 Functions and structure of individual academic
Branches and other Units in the above model
2.4.1 Academic Branches
For the organisational model suggested in the pre­
ceding paragraph, functions and structure of indivi­
dual academic Branches have been described below in
a tabular form.

DIETS : ACADEMIC BRANCHES—FUNCTIONS & STRUCTURE
Branch

1. Pre-service
Teacher Education
(PSTE) Branch

3—55IEdu/89

Functions

Staffing pattern

(2)

(3)

1. To ssrve as th<5 notal branch for the following
(i) Organising pre-service course for elementary school
teachers (including admissions, instruction and
evaluation) and to provide academic inputs into such
course is the subjects represented in the Branch (as
given in col. 3).

Sr. Lecturer
Lecturers

1 (will have a specia­
lisation in
child
Psychology)
8 (No. is subject to
the remark against
‘Languages’ below)

(ii) propagation of (a) learner centred education and (b)
education for personality development (including value
and culture education), through training, extension,
preparation of suitable teaching aids, action research
etc.

Subject-wise break-up of Lecturers would
be as follows
Languages
2 (The No. may be
3 or 4 depending on
the
circumstances

(iii) All general matters concerning teaching methodology
(e.g. multi grade teaching, peer group tutoring etc.)
and specific matters concerning teaching methodology
of the school NFE subjects represented in the Branch.

of the State/Distt.
as mentioned in
para 2.2(2) above).
Foundation of
Education

(iv) Provision of Psychological Counselling and guidance
services to schools and NFE/AE Centres of the
district.

M aths
Science

(v) All matters relating to learning by Children of
. Disadvantaged Groups (e.g. special remedial
instruction for first generation learners).
(vi) Education of children with major handicaps and other
mild (physical and mental) handicaps.

Social Science/
Studies

<!-- page 18 -->

10
( 2)
(vii) Education of the Gifted.
Art Education
1
•
2. To conduct such in-service programmes (for elementary
1.
teachers) whose content relates exclusively or predominantly Phy. Education
to the subjects represented in the Branch, or to its other
Lab. Asstt.
1
areas of nodal responsibility listed at (ii)-(vii) under (1)
Note : In thj area of Art Edu. the DIET
above.
will need faculty strength in visual as well
as performing arts. If the Lect. in Art
Education has expertise in only one of the
3. To provide inputs into programmes/activities of all
two areas, a resource Person may be
other Branches of the Institute, to the extent of subjects/
areas represented/handled in the Branch. Such programmes
engaged in the other area, on part-time
basis, (see para 2.4.3).
would include:—
(i) In-service programmes for elementary teachers
(ii) Training programmes for NFE and AE personnel.
(ii) Development of locally relevant curricula, teachinglearning material, low-cost teaching aids, testing
and evaluation tools/techniques, etc.
(iv) Field Interaction (including extension) activities
(Please see section 3.4 for details).
(v) Action research, especially in ways to improve
learning by children of disadvantaged groups, and
in education of the gifted.
4. Maintenance of Science Lab., Psjichology equipment,
Resource Room for Education of Disabled Children,
Rooms for Art Education, and of equipment and
facilities for Sports and Physical Education.
5. Promotion of and support to co-curricular activities in
areas related to the substantive work of the Branch, e.g,
debates and elocution, literature, Science Fairs, Visual
and Performing Arts, Sports and Physical Education
competitions, Yoga, Hobbies etc.
2. Work Experience
(WE) Branch

1. To identify locally relevant WE areas, and in cooperation
Sr. Lecturer
with concerned nodal branches, to develop sample curricular .Lecturer
units, teaching-learning material, low-cost teaching aids
WE Teacher/
and evaluation tools/techniques in such areas (Examples
Draft
locally relevant areas would be spinning/weaving/
Instructor (for
a specialised
dyeing, bamboo work, bee-keeping, chatai-making, etc.)

"1

1

.1

[

1
.

!

2. To help educational authorities and elementary schools/
NFE/AE Centres in planned introduction of Work
Experience activities in such schools/centres.

craft/trade/
horticulture etc

3. As back-up to (2) above, to conduct appropriate in­
service programmes for teachers in the areas of WE.

Service of crafts men, gardener etc. may
be engaged on part-time basis.

4. To provide WE-related inputs into all other programmes
and activities of the Institute e.g. pre-serviced and in­
service programmes for teachers, training programmes for
NFE/AE personnel, Field Interaction (including Extension)
activities, Action Research, etc.
5. To organise activities for cleanliness, upkeep and develop­
ment of the Institute campus—roads, playgrounds, lawns,
gardens, etc.—and its surroundings, and for basic maintenance
of Institute furniture and other properties.
6. To organise community service activities and study visits
to work centres as part of training programmes, and to
promote such activities on extra-curricular, basis...........

|
J

<!-- page 19 -->

11
( 1)

_____________________ (2)______________________

(3)

7. To maintain Workshop/Farm/Garden for WE activities
8. To promote work-related hobbies among trainees of
the Institute.
3. Distt. Resource
Unit (DRU) for
AE/NFE

1. To assist educational authorities in planning and
coordination of training programmes for AE/NFE
personal throughout the distt., and to provide
necessary support to such programmes organised
outside the DIET.
2. To serve as the nodal branch for organising

V ice-Principal

or
1
Sr. Lecturer
(depending on whether
both, or for only one
of them. IP. see para 2.6.2)

•

(i) programmes of induction training and continuing
education for instructors and supervisors/preraks of
NFE/AE to be organised in the DIET (Programmes
for preraks of AE will be done in conjunction with
the SRC)

Lecturer NFE 2
Lecturer AE 2
Clerks
2

(PI. see para 2.6.2
for alternative
scenarios)

(ii) Orientation programmes for resource persons of the
following kinds
(a) Those who would conduct programmes mentioned
in (i) at other centres in the district (i.e. outside
the DIET) e.g. personnel from NYK, NFE/AE
projects, NGOs, etc. and

If DRU has 2 clerks,
ona of them will be a
Steno-typist attached
to the Vice-Principal

(b) resource persons for the successful implementation
of AE/NFE programmes as a whole e.g. extension
functionaries of Development Oeptts., community
leaders, retired teachers, ex-servicemen, NSS
Volunteers, ICDS functionaries, other involved
in Mass Programme of Functional Literacy
(MPFL), etc.

The DRU will draw liberally on the support
of functionaries of Development Deptts.,
educational activists etc., as resource per­
sons, for conducting its programmes.

3. To provide instructional inputs into (i) core areas of
the above programmes e.g. need philosophy, objectives,
methodology, evaluation, problems, etc. in NFE/AE, and
(ii) teaching of such individual subjects/areas as the staff
may have necessary background in, especially teaching of
language, arithmetic and functional skills
4. To evaluate and monitor the quality and efficacy of train­
ing programmes for NFE/AE personnel held in and out­
side the DIET, and to strive for their continuous improve­
ment
5. To maintain a data-base on all NFE/AE personnel who
undergo training at the Institute, and to organise follow
up activities pursuant to such training
6. To under take with the help of other concerned branches,
the following activities vis-a-vis curriculum, basic and
post-literacy teaching-learning material, low cost teaching
and evaluation tools for AE/NFE :
(i) Adaptation of existing curricular units, teachinglearning materials etc. to suit local requirements
(ii) Development of new locally relevant items including
in widely spoken dialects of the distt.
7. To undertake field interaction (including extension) work
vis-a-vis the AE/NFE projects and centres in the district,
and to act as the referral unit for academic problems thrown
up by the field in the areas of AE/NFE
8. To help the DBE and AE/NFE authorities in organising
media support for the AE/NFE programmes (including by
harnessing traditional media).

<!-- page 20 -->

i2

9. To undertake action research in all areas relevant for nuk­
ing NFE/AE more effective—in 'collaboration with other
branches, to the extent necessary
10. To provide AE/NFE related inputs into all programmes
of the Institute not listed above, especially pre-service
and inservice education programmes for teachers
4. In -servics program m is , Field In te r­
a c tio n a n d In n o v a ­
tio n C o o rd in atio n
(IF IC ) B ranch.

1. To assist educational authorities in planning and coordina­
tion of itmrvjee education programmes for elementary
teaehsrs throughout the district, and to plan and coordnate such programmes held in the DIET, Pursuant to this,
the Branch would—
(i) identify training needs of elementary teachers in the
district, and prepare a perspective plan for meeting
such needs,
(ii) prepare: an annual calendar of all programmes to be
held in the DIET, and
(iii) help concerned authorities in preparing an annual
calendar of inservice programmes to be held outside
the DIET.
2. To serve as the nodal branch for organising—
(i) all those in-service education programmes for teachers
and H;ad masters, at the Institute, whose content does
not relate exclusively or pre-dominantly to any one
Branch i.e. programmes of a relatively general/omnibus
nature (e.g. the ‘main’ programmes referred to in
para 3.3.3)
(ii) orientation programmes for resource persons who
would conduct in-service programmes for teachers
at other centres in t he district (i.e. outside the DIET)
(iii) in-ssrvice education programmes for teachers in the
distance/distance-cum-contact-modes (A part from
programmer that the DIET may organise in these modes,
on its own, it may also serve as a district level study
cente for such programmes which may be organised,
say, at the state level. IFIC Branch will serve as the
nodal Branch for this purpose as well)
3. To evaluate and monitor the quality and efficacy of in­
service programmes held in and outside the DIET, and to
strive for their continuous improvement
4. To maintain a data-base on all persons, except NFE/AE
personnel, who undergo training at the institute, and to
organise foliow-uPj activites pursuant to such training,
through correspondence, visits, transmission of printed
material, etc
5. To serve as a reference and resource centres for teachers
who wish to continue their education
(>. To act as the nodal branch for all action research, and
field interaction (including extension) activities of the
Institute which would include, inter alia :—
(i) Coordination of in-house action research activities
and dissemination of its results
(ii) Acting as a clcarning house for information on results
of all studies, research, innovation, etc. in the area of
Elementary Education—wherever undertaken
(iii) Publication of a periodic newsletter and an institute
journal to be sent to every elementary school/NFE/AE
centre in the district.

Sr. L ic tu rcr
L :c t u « r
Cl ir k

—1

—1

<!-- page 21 -->

2

t

3

1. T o ad o p t existing item s a n d develop new item s o f the
S r. L ectu rer
—1
follow ing kinds so th a t th ey suit local circum stances, a n d
L ecturer
—1
can be used in e le n u n ta ry e d u ca tio n a n d elem entary teach er O f the tw o sta ff m em bers o n e sh o u ld
e ducation program m es :
have b a ckground in S cien ce/M ath e-

! , ESWriCUlum, M aterial

Development and
Evaluation (C M D E )
BSMch

(i) C u rricu lar u a it s —N jw , loj.illy relevant u iits co u U
be d eveloped fo r th e d istt. in various subjects to su p p letn jn t the generally prescribed cu rricula. S u c h u n its
m ay p e rta in to t< pics lik e local geography, folklore,
legend, custom s, forests, flora a n d fau n a, fairs a n d
festivals, dem ography, geology, m inerals, a g ric u ltu re ,
industry, service 'o c c u p a tio n s , folk a rt, h a n d ic ra fts,
com m unities a n d tribes, in stitu tio n s etc.

tm t i c s a n d j t h e o th e r in S ocial Science/
H u m a n tie s.

(ii) T ea ch in g le a rn in g fo r g e n era l a b well a s lo cally
developed c u rric u la r u n its—specially p rim ers for classes
I a n d II in trib al languages in districts having su b s ta n ­
tial trib a l p o p u latio n —
(iii) T echniques a n d guid elin es for c o n tin u o u s a n d sum m ative lea rn er-e v alu a tio n
(iv ) T ests, questio n /item banks, ra tin g scales, o b serv atio n
schedules, guidelines fo r diagnostic testing/rem edial
program m es talent identification p ro c e d u re s e tc .
M eet o f t he a d o p ta tio n /d ev e lo p m e n t w ork as above
w ould be d< n e th ro u g h w o rk sh o p s involving o th e r
concerned faculty, in stitu tio n s, experts, teachers and
instructors.
2. T o help the D R U in developm ent w ork as above for A dult
a n d n o ti-fo rm al E d u ca tio n .
3. T o u ndertake testin g o n sam ple basis to assess ach iev em en t
levels am ong learners, especially w ith reference t o M in .
levels P re sc rib ed fo r th e p r im a ry a n d u p p e r st£ g e a n d fo r
a d u lt learn ers u n d e r N L M .
4. T o help e d u ca lio n a l au th o ritie s a n d e le m e n ta ry school/
N F E /A E C e n tre s in im plem enting a reliable and valid
system o f lea rn er evaluation.
5. T o c onduct w orkshops for the ad ap tatio n /d e v e lo p m e n t
w ork m entio n ed in ( I ) above, as also in-service p rogram m es
relatin g to C M D E .
6. T o pro v id e C M D E —lela te d in p u ts into all o th er p ro g ra ­
m m es/activities o f the in stitu te , e.g. pre-service a n d inservice program m es for teachers, train in g progam m es for
N F E /A E personnel, Field in te r -a c tio n (in c lu d in g E x te n ­
sion) activities, A ction R esearch, etc.

1 Bducation.il
Technology
(ET) Branch

1.

T o develop in c o lla b o ra tio n w ith co n ce rn ed staff o f the
— D IE T and o th e r resource persons, sim ple, effective and
low -cost teaching aid s fo r various subjects/areas relevant
to elem entary edu catio n a n d elem eneary tea ch e r ed u catio n
C -c h a rts diagram s, m odels, photographs, slides, au d io
tapes, play-scripts, songs etc.

2.

To help the D R U in developing low cost teaching aid s as
a bove., for A dult a n d N o n -F o rm a l E ducation.

3.

T o m aintain the follow ing :
(i) All A . V. equipm ent o f the Institute,
(ii)

C om puter L a b .,

(iii)

A display a re a for good, low cost teaching aids developeded in house as well as elsew here, and

(iv)

A lib ra ry o f e d u ca tio n a l v id e o /a u d io cassettes an d ,
if the In stitu te h a s a tilm projector o f film s.

Sr. L ecturer
L ecturer
T echnician

—1
—I
—1

<!-- page 22 -->

14

4. To lend slides, cassettes and films to institutions having
playing/projection facilities, and to borrow them from
others Resource Centres.
5. To liaso with nearby Radio station for arranging educa­
tional .broadcasts suitable for elementary school children
AE/NFE learners, teachers/instructors etc. of the district.
6. To conduct appropriate in-service programmes for teachers
in the area of ET, with special emphasis on:...
(i) Effective utilisation of educational broadcasts, tele­
castes, cassettes and aids, and
(ii) Development of simple, low cost teaching aids.
7. To conduct workshops for the development work mentioned
in (1) above.
8. To provide ET-related inputs into all other programmes/
activities of the Institute e.g. pre-service and in-service
programmes for teachers, training programmes for NFE/
AE personnel, Field Interaction (including Extension)
activities, Material Development, Action Research etc.
P lan n in g & M an ag em en t (P & M ) B ranch

1.

To maintain an appropriate data-base for the district which
may be required for various planning exercises aimed at the
UPE/UEE/NLM goals and for monitoring progress
towards these goals.

2. To conduct studies with a view to giving policy advice to
educational planners/administrators/DBE regarding UEE/
NLM. Some of the important areas for such studies
would be :
(i) Enrolment, retention and regularity of attendance
of children and adult learners (especially females,
SC/ST, minorities, handicapped, slum-dwellers and
other disadvantaged groups)
various factors
affecting these.
(ii) Effect of various interventions (includingincentives)
on the above.
(iii) Community’s perception of and participation in the
process of basic education.
(iv) Development of norms, criteria and techniques for
evaluation of Institutions (Schools and AE/NFE
Centres) of the district.
One or two
educationally
backward
pockets of the district, which may be with-in easy
reach from the District will be specially chosen
for conducting above studies as well as a lot
of action research activities. These may be called the
‘Lab. area* of the DIET. However, while a lot of
studies and action research will be concentrated in the
lab. area, they would not be necessarily confined to
this area, and other suitable areas would also be
chosen depending on the nature of work involved.
j To provide technical assistance to educational authorities
in (i) school mapping, (ii) Micro-planning for UPE/AUEE
in an area specific and target group specific manner, (iii)
formation and activiti'»n of school complexes, (iv) institu­
tional planning for school complexes, schools etc., and
(v) Institutional evaluation.
4. To serve as the nodal branch in relation to all programmes
of community involvement in basic education, and in parti­
cular, to conduct orientation programmes for members
of DBE, VECs, community leaders, youth and other
voluntary educational workers.

Sr. Lecturer
Lecturer
Statistician

<!-- page 23 -->

15

5. T o conduct a p p ro p ria te program m es fo r H ead M asters,
H eads o f School Com plexes a n d Block level educational
functionaries in P & M , covering area? like leadership,
m otivation, involving the com m unity, educational ad
m inistration, finance a n d accounting , office procedure,
planning fi>r U F E /U E H , institutional planning etc.
6.

T o appraise the efficacy o f vario u s program m es o f educa­
tio n a l developm ent im plem ented in th e district especially
vis-a-vis the o b jec tiv e s c f U P E /U E E and N L M .
T o act a s th e nodel branch for preparing quin-quennial and
an n u al institutional plans a n d an n u al self evaluation reports
fo r the DTET, and for liasing w ith th e D B E .

S.

T o p rovide P & M related inputs in to all o th er program m es/
activities o f the institute e.g. pre-service and in-scrvice p ro ­
gram m es for te a c h e is , tia in in g p ro g ram m es fo r N F E '
A E personnel, Field Interactio n (including E xtension)
activities,A ction Research etc. w ith special reference to ihe
areas listed u n d e r (J) ab o v e.

2,4(J Library* A dm. Section, Hostel and Clinic
The library staff will comprise :—
Librarian— 1
Clerk— 1
!h e Principal may place a senior faculity member
jjng interest in library development and manageil, in overall charge of the library to guide and
its work.
The Administration Section which will provide adninistrative support to the entire Institute will comOffice Supdt.— 1
Accountant— 1
Clerks— 5 (including one for the hostel)
Q ass IV staff— 6
The IFIC Branch, the DRU and the Library will
have their own clerical staff. They will therefore not
normally depend on the Admn. Section for clerical
support.
The Principal may appoint, from among faculty
members, a common Warden for both hostels, or
separate Warden for Men’s and Women’s hostels, as
may be convenient. The W arden(s) will be responsi­
ble f&r the smooth functioning of the hostels.
"Hie Principal may also, in his discretion, appoint
the Branch Heads to assist him in the work
to the Admn. Section, in addition to heading
jter’s own Branch. The Principal will also
ilk steno/P.A.

The Institute Clinic will be manned by a Part-time
Medical Officer. It will treat ordinary ailments of
trainees and Institute staff, and provide first aid and
common medicines.
2.4.3. Consultants/Resource Persons
Apart from the regular stall members indicated in
the previous two paragraphs, a DIET would need
to engage consultants/resource persons for short dura­
tions, to meet its manpower requirements. The table
in para 2.4.1 indicates some of the areas where these
persons may be needed. There may be several others.
To meet this requirement, a DIET will be competent
to engage consultants/resource persons for appropriate
durations normally not exceeding three months. They
may be engaged for a total of upto 50 man months
in a year, with honorarium not exceeding Rs. 3000
per man month. State Govts, would lay down norms
and guidelines for engaging consultants/resource per­
sons, fixing their honoraria, etc.
2.5 DIET : Physical Facilities
A DIET with the kind of functions and structure
spelt out above would also need to have adequate
physical facilities on the following lines :—
(i) An institute campus of adequate area, pre­
ferably 10 acres.
(ii) Buildings :
(a) Institute
Building : with
roughly
10,000 sq. ft. carpet area* (details
may be seen in Annex 13)

S^arpet area’ here is meant the total built-up area of a building minus (i) area of circulation spaces
verandahs, corridors, staircase, foyer etc.), and (ii) area under walls,

<!-- page 24 -->

16

(b) Hostel : separate hostels for men and
women with a capacity of 150 to 200
seats.
(c) Staff Quarters : for at least five staff
members viz Principal, two faculty
members one or both of whom would
function as hostel warden(s) and two
class IV employees.
(iii) The following other facilities :—
(a) Library and reading room
(b) Methods laboratories for Physical and
and Life Sciences.
(c) Equipment for psychology experiments,
Social Studies & Language teaching.
(d) A work-shed and garden/farm for work
experience activities.
(e) Equipment for Education in Visual
Performing Arts.

&

(f) Playgrounds and equipment for Physi­
cal Education and Sports.
(g) Audio-visual aids.
(h) Computer Room.
(i) Equipment for education of the handi­
capped.
(j) Special materials and equipment rele­
vant for Adult and Non-Formal Educa­
tion.
Annex. 4 summarises the organisational structure,
staffing pattern and physical norms detailed in para
2.4 and 2.5.
2.6 Relating the D IE T s structure to the characteris­
tics of the district
2.6.1
Having suggested an organisational structure
and required physical facilities for a D IE T in paras
2.4, 2.5 and Annex-4. it needs to be stressed that it
will not hold uniformly for all districts in the country.
For reasons adumbrated, later, the above structure
would be advisable for a district where the following
circumstances obtain :—
(i) Elementary teacher population of 2,500 or
more,
(ii) Number of AE and NFE Centres should be
200 each or more, and
(iii) Non-availability of a reputed non-govern­
ment organisation (NGO) which could be
expected to perform the functions of a Dis­
trict Resource Unit for A E /N F E better than
a DRU that might be set up as a part of
the DIET.

Wherever one or more of the above circumstances
do not obtain, the DIET may have a smaller structure
than the one envisaged above.
2.6.2 DRU : Alternative Scenarios
Generally, a DRU for A E /N FE would be warran­
ted where there are at least 200 centres each of A E /
NFE. In district of non-educationally backward States,
by and large, the N FE programme is either very
small or non-existent. In such cases, the DRU will
be for adult education only. Even then, for a DRU
for AE to be set up, there should be at least 200
AE Centres running in the district.
In several districts, there are agencies like Nehru
Yuwak Kendras, University Deptt. or other NGOs
which have done; good work over the years in the
area of providing training and resource support to
AE/N FE. For such districts, the State Govern­
ment would have to take a considered decision
whether it would be better to assign the responsibility
of the DRU to such an NGO, or to create a new one
as a part' of the DIET. It is also possible that an
NGO may have expertise in only one of the two
areas i.e. AE or NFE. In such an event, there would
be on objection if it performs the functions of a DRU
in the area of its expertise, and the DRU for the
other is created as a part of the DIET. In short,
assuming the numbers of A E /N FE Centres in a dis­
trict warrant a DRU for AE as well as NFE, the
following possibilities would e x ist:—
(i) DRU for both A E and N FE being a part of
the DIET.
(ii) DRU for one (A E or NFE) being a part of
the DIET but functions of the DRU for the
other (N FE/A E) being handled by an
organisation other than the DIET.
(Hi) DRU for AE as well as N FE being outside
the DIET—either a single agency working
as a composite unit, or two different agen­
cies working as DRUs for A E and NFE
respectively.
To the extent that a DRU (a composite one or for
AE or N FE alone) will be outside the DIET, it would
not be funded under the Teacher Education Scheme.
Its funding will be done under the scheme of AE/
NFE/M ahila Samakhya, in accordance with guide­
lines formulated under respective schemes.
The table in paragraph 2.4 gives the staffing pattern,
inter alia, for a composite DRU to be created in the
DTET. However, as mentioned above, a D IE T may
also have a part DRU i.e. either for AE or NFE

<!-- page 25 -->

IV

alone. In such an event, the staffing pattern
DRU will be as follows :—■

of a

cal barriers, etc., it is not practicable to
club a “small” district with the D IET of an
adjoining district, some other suitable solu­
tion may be devised, looking to local
circumstances.

Even when a composite or part DRU is outside the
DIET, such a DRU and the DIET will be expected to
function in close collaboration, especially if the two
are located at the same place. In the latter event,
there can be considerable sharing of staff and other
resources between them.

(ii) Where the elementary teacher population of
a district is more than 1000, but less than
2,500, while an independent D IET may be
set up, it may have a ‘telescoped’ structure,
the extent of ‘telescoping’ depending, inter
alia, on how much less the elementary
teacher population is compared to the thres­
hold figure of 2,500. The PSTE Branch
would not, of course, be affected in any such
telescoping exercise, since it is, so to speak,
the core branch of the Institute. But in­
dependent existance of one or more of the
following other branches could be done
away with, by not having a Sr. Lecturer for
them, and by placing their Lecturer as a
member of the PSTE Branch itself :—

Sr. Lecturer— 1
Lecturer—2
Clerk— 1

2.6.3 Relationship between elementary
teacher
population of the district and DIET structure
As stated in para 2.6.1, a DIET may have, besides
the DRU, six academic branches, if the elementary
teacher population of the district is 2,500 or more. It
may be recalled here that, according to the Fifth All
India Educational Survey, elementary teacher popula­
tion in the country, as on 30-9-1986, was 27.9 lakhs
which yields an average per district population of
about 6,200. Thus, most of the districts in the coun­
try have considerably more than the above threshold
population of 2,500. Yet, there are a considerable
number of districts in the North East, Kashmir,
Sikkim and some of the Union Territories whose ele­
mentary teacher population is less than 2,500.

(a) Work Experience Branch
(b) Curriculum, Material Development and
Evaluation Branch
(c) In-service Programmes, Field Inter­
action and Innovation Coordination
Branch.

A D IET is an expensive institution to create and
maintain in non-recurring as well as recurring terms.
It has therefore, to be ensured that it has enough
clientele to justify the investments it requires. It is
accordingly recommended t h a t :—

Besides the above, while P&M and ET Branches
could possibly remain as distinct entities, even these
could do with one instead of two faculty positions.
With the above kind of telescoping of the academic
structure, there would be a corresponding curtailment
in the staff of the Administration Section and in the
size of the required building and other physical
facilities as well.

(i) A separate DIET may not generally be
established for districts having less than
1000 elementary teacher population. Such
districts may be served, as far as possible by
a D IET set up for an adjoining, larger dis­
trict, or by one which is set up for a cluster
of two or more such “small” districts. How­
ever, if for reasons of remoteness, geographiName of Branch

1. Teacher Education

In its most truncated form—which would perhaps
apply to a district with just about 1000 elementary
teachers— a DIET (minus the DRU) may have the
following structure :—
No. of
posts

Category of posts

.

.

.

.

Senior Lecturer
Lecturers

.
.

.
.

.
.

1
11

Remarks

Eight as in'the'PSTE
Branch of a normal DIET,
and one each for work corres­
ponding to WE, 1FIC and
CMDE -Branches.

2. Educational Technology
4 —551 Edu/89

.

.

• Lecturer

<!-- page 26 -->

18

1
Planning & Management

_

2
.

.

.

Lecturer

'" 3"

-

.

.

.

l

Administration.................................... Superintendent
Librarian
.
Accountant .
Clerks .
.
Lab. Assistant
Peons .
.

.
.
.

•
.
.

l
l
l
3

A DIET of the above kind would also have physi­
cal facilities on a considerably less scale— especially
in terms of the size of the Institute build'ng and hostel.
F or example, an 80-seater hostel may suffice for its
purposes.
2.7 Special status of the DRU in the D IET
Wherever a DRU— composite, or for only A E or
NFE— is created as part of a DIET, it will enjoy con­
siderable functional autonomy within the Institute.
This is also to some extent reflected in the organisa­
tional structure suggested in this Chapter, in the
following manner :—
(i) If the D IET has a composite DRU, its head
will be designated as Vice Principal rather
than as Senior Lecturer.
(ii) The DRU will have its
ministerial staff.

own

nucleus

of

Although the Vice Principal/Sr. Lecturer incharge
of DRU will be administratively accountable to the
Principal, and through him to the District Board of
Education, the DRU will also establish direct linkages
with various national, State and district level organi­
sations concerned with AE and NFE. Also, as far as
A E and NFE are concerned, the DRU will not merely
conduct induction training programmes, but will also
carry out most of the functions which the IFIC
Branch would perform vis-a-vis elementary schools,
in the areas of continuing education and field inter­
action (e.g. identification of training needs, perspective
planning, organisation and conduct of programmes,
etc.). However, the DRU’s programmes would have
to fit into the overall annual calendar of programmes
which the IFIC Branch would prepare for the DIET
as a whole, so that physical and manpower resources
of the Institute are utilised in a well coordinated
manner.
'
2.8 Coordination among various branches/sections/
Units of the DIET
Though a branchwise organisational structure has
been recommended in this chapter, it needs to be

.

.

.

.

1

.

.

4

4

emphasised that branches have been envisaged purely
for practical convenience. In the ultimate analysis,
the DIET as a whole, will have a single set of goals
and performance norms, and the entire staff of the
Institute will be collectively responsible for achieving
them. It follows that, far from being watertight com­
partments, all constituent branches, etc. of a D IET
will have to work closely, as parts of a well-integrated,
organic whole. There will be full sharing of man­
power and material resources available to each branch,
and equally, sharing of responsibilities. Since ‘depart­
mentalism’ is a common tendency, all faculty members
of a D IET would need to be oriented right from the
start to view themselves as partners in a common
endeavour. The coordination function of the Princi­
pal will also be a very important one, in this context.
2.9 Alternative Structures
Section 2.3 and 2.4 give details of one organisational
model for the DIET. This model is not, however,
unique, and it is possible to think of minor as well as
major variations on it. For example a minor varia­
tion could be that, retaining the same branches, the
Lecturer in A rt Education could be placed in the
Work Experience Branch rather than in PSTE Brapch
because he has as much in common with the former
as with the latter.
As for major variations, models fundamentally
different from the above one could also be designed—
with a different grouping of disciplines resulting in a
larger or smaller number of constituent units. It is
also possible to think of a model where there are no
branches or units at all, and the D IET functions as an
entity without any sub-units.
It would be for State Governments to decide, keep­
ing in view their respective systems, circumstances,
experiences, etc. as to which would be the best model
for their DIETs. However, whichever model is
adopted, its details would need to be worked out as
elaborately as has been attempted in Section 2.4, and
in particular, all the functions envisaged therein for
various branches would have to be taken care of.

<!-- page 27 -->

CHAPTER 3

GUIDELINES FOR PROGRAMMES AND ACTIVITIES
3.1 Introduction : Main programmes and activities
which would be organised in a DIET could be listed
as foEows :—
(i) Pre-Service Teacher Education Programme.
(ii) In-Service Programmes of Elementary Tea­
chers, Headmasters, Heads of School Com­
plexes, and officers of Education Department
upto block level.
(iii) Field Interaction (including Extension work).
(iv) Training programmes for personnel of adult
and non-formal education.
„
(v) Workshops for development of curricula,
teaching learning material, testing and eva­
luation tools and techniques, low cost teach­
ing aids, etc.
(vi) Orientation programmes for members of
DBE, VECs, community leaders, youth and
other educational activities.
(vii) Field studies, action research and
mentation.

experi­

This chapter attempts to lay down certain broad
guidelines for some of the above programmes and acti­
vities as they would be expected to be conducted in
the DIETs.
3.2 Pre-Service Teacher Education Programme
3.2.1 All or most matters relating to this programme
are regulated by the concerned examining body, e.g.
the State Board of Examinations/Secondary Educa­
tion, etc. The present non-statutory NCTE had, in
1978, brought out a document entitled “Teacher Edu­
cation Curriculum : A Framework” which, inter alia,
laid down guidelines regarding admission criteria, con­
tent, structure and evaluation system for the Pre­
Service Teacher Education Programme as well. Im­
plementation of this Framework in various states has
been uneven. Now, with the adoption of NPE, 1986,
fresh guidelines in this regard have become necessary.
N C TE has now, for some time, been working on a
new framework. Once the NCTE becomes statutory
and approves a new framework for pre-service teacher
education that would have to be followed, with
necessary local adaptations and adjustments, through­

out the country. Till this happens, organisation of the
pre-service teacher education course would continue
to be regulated by the State Boards for DIETs as for
other ETEIs in the State. In other words, DIETs and
other ETEIs in a state will offer contentwise, the same
programme since there has, of necessity, to be a com­
mon syllabus, terminal evaluation etc. for all pre­
service trainees in a State. But the transaction of the
programme would be expected to be qualitatively much
richer in the DIETs.
3.2.2
Subject to the above, the following guidelines
are laid down in connection with the pre-services pro­
gramme to be organised ip DIETs. Many of these
would probably get sub-sumed in the new framework
which NCTE would lay down. Until that happens,
these may be followed to the extent possible within
the system prevailing in individual States.
(i) Minimum academic qualification for admis­
sion should be higher secondary (12th).
The course should be of two years’ dura­
tion with about 220 working days in each
year. Semester system may preferably be
followed.
(ii) Annual intake in a two-year program m e
may be generally kept at 40, but may vary
between 30 and 50 depending on the State’s /
district’s requirement of trained teachers.
In States/districts where there is already a
large backlog of trained unemployed elemen­
tary teachers, the intake may be kept at 30.
On the other hand, in States/districts where
there is a shortage of trained teachers and/
or a large backlog of untrained teachers, it
may be kept at 50. In States where the pre­
service course is of one-year duration, till
they switch to a two-year course, the intake
may be double the figure suggested above
for a two-year course.
(iii) The following principles should govern
admissions into the pre-service course :—
*
(a ) The admission procedure should be as
objective as possible, with no room for
arbitrariness.
(b ) There would be reservations for can­
didates belonging to SCs and STs.

<!-- page 28 -->

20

(c) Para 13(C) of Chapter X X III of the
POA says that “Spatial requirement will
be an important consideration in admis­
sion to teacher training institutions”.
Accordingly, appropriate weightage
should be given, while evaluating candi­
dates’ suitability for admission, to their
having lived and studied in rural areas/
tribal areas/other difficult areas.
(d) Other things being equal, preference
should be given to women candidates.
(e) Apart from the scholastic achievements
of the candidates, due weightage should
also be given to the following attri­
butes :—
Ability to readily relate to and com­
municate with children, achievements
in sports and physical activities espe­
cially yoga, participation in NCC,
NSS and various extra curricular
activities, creativity, commitment for
social upliftment, general awareness,
etc.
(iv) In the pre-service course, as in other pro­
grammes, use of the lecture method will be
limited to the minimum. The process will
be learner—active/participative rather than
being of one-way communication. The pro­
cess of learning for the trainees will consist
as much as possible of modes like investi­
gations, case-studies, problem solving, roleplay, project work, self-study, field visits,
demonstrations, group work, tutorials, and
other activities. Audio-visual aids like video
and audio cassettes, telecasts/broadcasts,
films, slides, transparencies etc. as well as
low-cost aids will be liberally used to make
learning as lively as possible. Training
methodology will, in general, be so devised
as to carefully eliminate ‘spoon-feeding’ and
help trainees discover, learn and practice for
themselves.
(v) Individual differences within the trainee
will be carefully noted, and individualized
attention paid to trainee’s learning needs.
(vi) Apart from practice teaching
in schools,
trainees will be exposed to teaching in NFE
centres also.
(vii) Working with the communitywill
be an
important component of the pre-service
course, and as part of this, every trainee will
be expected to impart functional literacy to
a suitable number of adult illiterates, also.

All trainees would thus have had exposure
to Noil-Formal as well as Adult Education.
(viii) Apart from the terminal examinations to be
conducted by the State Board, there will be
continuous and comprehensive internal eva­
luation by the Institute. Its aim will be
diagnostic and remedial to help trainees
develop both professionally and as indivi­
duals.
(ix) An annual educational excursion of suitable
duration (generally outside the state) w il
be an integral part of the programme.
*
Some more suggestions regarding transac­
tional methodology for the PSTE course are
given in Annex 5.
3.3 In-Service Programmes for Elementary Teachers
3.3.1 Objectives
According to the Fifth All India Educational Sur­
vey, about 87% of the teachers in the country work­
ing at the elementary stage were trained i.e. they had
undergone a pre-service training course. However,
their coverage under programme of in-service educa­
tion has so far been extremely limited. A teacher may
serve for anything upto 40 years. During this long
period, requirements of his profession change continously, influenced by changes in policy, priorities,
technology, society and the world at large. Conti­
nuous in-service education of teachers is necessary to
keep them abreast of the changes taking place in their
professional environment and to develop their skills
and attitudes in the light of their changing role.
The objectives of providing in-service and conti­
nuing education to teachers could be summarized as
follows :
(i) To develop in every teacher, as far as possi­
ble, knowledge, skills and attitudes which
may be necessary for him to function as a
competent professional; and to implement
the main components of educational policy,
and
(ii) To afford teachers, opportunities of profes­
sional growth suited to their individual back­
ground, aptitude, talent and choice.
The “main components” referred to in (i) above, in
the context of NPE, 1986, as far as elementary tea­
chers are concerned, would be substantially those
listed in Sections 1 and 2 of A nnex 1.
3.3.2 In-Service Edncation of Teachers : Formulation
of a Feasible P a tto n
Ideally, decisions about ways of providing in-service
education to teachers in a cost-effective manner should

<!-- page 29 -->

21
be taken based on findings of appropriate research,
keeping in view the objectives and relevant policy areas
referred to in the preceding paragraph. However,
research in this area so far, aspecially in the context
of the NPE, is not quite adequate. It is hoped that
the NCTE will examine the matter in depth and pro­
mote appropriate research in this area so that costeffective patterns of in-service education of teachers
could be evolved in a local-specific manner. For the
present, formulation of a desirable pattern of in-service
education has to be attempted on the basis of available
expert opinion, and considerations of feasibility. The
latter is, in any case, a very important aspect. For
example, considerations of training needs and quality
may dictate that every teacher should say, annually
undergo one-weak training in the contact mode. But
in view of the number teachers, logistic problems and
constraints of financial, institutional and other re­
sources, it may simply not be possible to provide train­
ing on such a pattern. There may, therefore, be no
alternative but to organise training of a duration and
frequency which may be feasible within the available
resources, and to tailor its content so as to fit within
such restricted duration by devices such as prioritisa­
tion, condensation, etc.

desirable and feasible for
go :—

The Education Commission had, in its report sub­
mitted in June, 1966, recommended that “there is need
for the organisation of a large scale, systematic and
coordinated programme of in-service education so that
every teacher would be able to receive at least two or
three months of in-service education in every five years
of service.” The National Commission on TeachersI (N CT-I), in its report submitted in March, 1986,
had recommended that “attendance at an in-service
training course be made mandatory for every teacher
at least once in five years”, and that the average
length of such a course may be two weeks. The NCTI had also, in addition, recommended a variety of
other methods for providing in-service education to
teachers. Relevant portions of Chapter V III ( “The
Case for In-Service Education” ) of the above report
may be seen at Annex-6.

3.3.3 Programmes in the contact mode :

The report of NCT-I pre-dated the NPE, 1986. In
view of the ambitious goals of qualitative improve­
ment and universalisation stated in the NPE, a single
training course of two weeks, once in five years, may
prove quite inadequate to achieve the objectives listed
in para 3.3.1. On the other hand, looking to the
enormous number of teachers, recommendation of the
Education Commission in regard to duration may also
be difficult to implement. On balance, a pattern like
the following could perhaps be suggested as being

every teacher to under­

(i) Training in the contact mode of a minimum
duration of two weeks (preferably, three to
five weeks) over a five-year cycle—through
a single contact programme, or more than
one, shorter programmes as may be found
feasible and effective;
(ii) Regular professional meetings during the
academic session at the school complex/
teacher centre level. At these meetings :—
(a) teachers could receive in-service educa­
tion messages through audio-visual aids
and through inter-action with resource
persons and peer group, and
(b) messages conveyed through contact,
audio-visual and other modes could be
followed up, validated and reinforced
through demonstrations, sharing of
experiences, etc.
(iii) Professional support through the print and
audio-visual media.
Logjstic

Some of the issues in this regard would be :—
(i) Training in the contact mode of what total
duration would be feasible if it is to be
provided to every teacher of the district/
State, with a frequency like once in five
years ?
(ii) Should the above training be imparted in a
single, relatively omnibus course or in
several, shorter specialized courses ?
While answers to the above questions would vary
from district to district and State to State (depending
on factors like elementary teacher population, number
of untrained/underqualified teachers, available finan­
cial, institutional and manpower resources etc.), for
most districts, the following may possibly turn out to
be the most appropriate answer, combining the factors
of resource constraint and need for quality and com­
prehensiveness :—
(i) Duration of training in the contact mode may
be two to three weeks,
(ii) For ease of logistics, the above training may
be generally provided in a single, relatively
omnibus programme once in five years,

<!-- page 30 -->

22
rather than in more than one, shorter pro­
grammes; and
(iii) Since the DIET would be the best-equipped
training institution in the district, the above
course, when conducted in the DIETs, may
be of three weeks’ duration, and when con­
ducted elsewhere in the district, could be
of a more condensed nature and of two
weeks’ duration, if resources do not permit
a three week course all over.
In the rest of this document, we shall refer to the
above, relatively omnibus quinquennial in-service pro­
gramme as the ‘main’ in-service programme for ele­
mentary teachers.

Though, logistically, the ‘main’ programme may be­
come the chief modality as far as training in the con­
tact mode is concerned, the D IET would, at the same
time, also have to organise, depending on local cir­
cumstances and needs, a number of shorter, themespecific programmes in areas such as the following :—
(i) Education of first generation learners, includ­
ing supplementary remedial instruction for
them and teaching Classes I and II in tribal
languages for teachers serving in tribal
areas,
(ii) Education of children with motor handicaps
and other mild handicaps,
(iii) Education of the gifted,

The suggested duration of three weeks for the
‘main’ programme to be conducted in DIETs is not
to be taken rigidly. For example, if a target group
consists of underqualified teachers, programme of a
longer duration may have to be designed for them.
On the other hand, if the elementary teacher popula­
tion in a district is very high, and possibilities of orga­
nising programmes at other centres are limited, the
‘main’ programme even in a DIET may have to be
restricted to two weeks, in the interest of wider
coverage.
Assuming that two ‘main’ programmes can go on
simultaneously in a DIET at least during vacation
months and one programme (with appropriate gap)
during the rest of the year, a DIET may be able to
conduct an estimated 12-14 ‘main’ programmes in a
year. If the average number of participants in such
programmes is 40-45, a DIET would be able to cover
about 500-600 elementary teachers in a year or about
2500-3000 in a five-year cycle. It follows that if the
elementary teacher population in a district is over
3,000 and every teacher is to be covered through a
‘main’ programme once in five years, such programmes
would have to be conducted, in addition to the DIET,
at an appropriate number of other centres also, in the
district. (Examples of ‘other’ centres where this pro­
gramme could be conducted, under the D IET’s over­
all guidance, would be other institutions of pre­
service/in-service training, higher secondary schools
lead schools of school complexes, etc.). If, on the
other hand, the elementary teacher population in a dis­
trict is below, say, 2500, the resources of a fullfledged DIET would tend to be under-utilized as far as
in-service training of elementary teachers is concerned.
This is the reason why 2,500 has been taken as a
threshold elementary teacher population, below which
a truncated structure has been suggested for the DIET
in para 2.6.3.

(iv) Micro-planning and monitoring progress to­
wards, U PE/U EE,
(v) Courses in the teaching of individual or
groups of school subjects i.e. Languages,
Mathematics, Science, Social Sciences, Work
Experience, A rt Education and Health &
Physical Education,
(vi) Educational Technology (especially deve­
lopment of low-cost, improvised teaching
aids, and effective use of AV aids),
(vii) Minimum levels of learning,
(viii) Continuous and comprehensive learner eva­
luation,
(ix) Diagnostic testing and remedial teaching,
(x) Multi-grade teaching,
(xi) Institutional planning,
(xii) Personality development, value and cultural
education,
(xiii) Implementation of revised curricula and use
of revised textbooks, etc.,
(xiv) Yoga and Physical culture,
(xv) Organisation of extra-curricular activities.
The choice of such programmes to be conducted in
a year, and the duration, content, etc. of each of them
would need to be decided locally, keeping in view such
guidelines as may be laid down at the national or State
level.
Headmasters, Heads of school complexes and offi­
cers of Education Department working up to the

<!-- page 31 -->

23

block level would be another target group for in-ser­
vice training who, though numerically much smaller,
would be extremely important in view of their key
role in educational reorganisation. The DIET would
also have to conduct appropriate training programmes
for them. Efforts may be made to cover members of
these target groups with the following frequency :—
Headmasters

: Once every three years

Head of School
Complexes

: Once every two years

would, inter-alia, include programmes
of the following kinds :—

(a) ‘Main’
chers.

programmes for primary tea­

(b) ‘Main’ programmes for upper primary
teachers— if necessary, different pro­
grammes for teachers of different disci­
plines e.g. Language, Science, Social
Studies, etc.
(c) ‘Main’ programmes for headmasters.

Block level officers of
: Annually
Education Department

3.3.4 In-Service Programmes
Guidelines

dar

(d) Shorter, theme-specific programmes for
the above target groups.
:

Certain

General

The following general guidelines would be kept in
view in organisation of in-service programmes in the
DIET :—
(i) The starting point should be the identifica­
tion of in-service training needs of elemen­
tary school teachers of the district— short­
term, medium-term and long-term, and
for different groups e.g. primary teachers,
upper primary teachers belonging to diffe­
rent disciplines, underqualified teachers, un­
trained teachers, teachers of minoritv insti­
tutions, teachers serving in tribal areas, tea­
chers belonging to various seniority—
brackets, etc.

(e) Training programmes for heads of
school complexes and block Education
Officers.
(f) T rainW programmes for resource per­
sons who would conduct “main” or
other nvoprammes at centres other
than DTET.
(g) Induction training programmes for A E f
NFE personnel.
(h) Annual refresher training programmes
for A E/N FE personnel.
(i) Orientation programmes for members
of DBE, VECs, community leaders,
youth and other educational activists.
(j) Workshops for development of locally
relevant curricular units, teaching-lear­
ning material, teaching aids, testing
and evaluation tools, etc.

(ii) Based on the above, a plan should be pre­
pared for a five-year period working out
how the above needs can be best met with
the available resources. There would be
distinct advantages in finalizing this plan im­
mediately after the national & state level
Five Year Plans are finalized, so that it
takes full account of the policies, priorities
and programmes spelt out in the latter.
This plan should clearly indicate the extent
to which responsibility for in-service train­
ing will be shared between the DIET, and
the other institutions in the district.

(iv) Since the “main” programmes would form
the focus of in-service training activitv. cer­
tain euidel'nes for them would be evolved
at the national and state levels. Based on
these, everv DTET would design its own
set of “main” programmes looking to local
needs. Such programmes would tend to
have a common core, along with other
components which would be tailored to
meet the specific needs of the individuals
district/target group.

(iii) Based on the above, a calendar of all pro­
grammes (training, orientation, workshops,
etc.) to be conducted in a D IET over one
academic year, should be prepared bv the
IFIC Branch at least three months before
the commencement of the year. This calen­

(v) The DIET will send its annual calendar of
programmes as sooji as it is readv, to the
District Education Officer (DEO) and
managements of non-Government schools.
The DEO /Managements will cause teachers
to be sponsored for individual programmes,

<!-- page 32 -->

24
iii such a manner that the list oi teachers
sponsored for a particular programme will
reach the D IET at least three months be­
fore its commencement. Teachers who
have less than three years to go for retire­
ment, and trained teachers, who have join­
ed service less than three years ago, may
generally not be sponsored, especially if the
elementary teacher population of a district
exceeds 3000.
(vi) Intake in a “main” programme may be kept
at 40— 45, and “over-sponsoring” m^v be
done to a suitable extenti to take care of
last minute changes, drop-outs, etc.

training inputs which are in the nature of
simple information (as opposed to skiliq
or major concepts) may be transmitted
largely through printed material sent to trai­
nees in advance, rather than in the face-toface modality.
(xii) Participants should be treated not merely as
trainees but also as resource persons for the
programme, and their experiences should
be fully utilized to enrich the programme.
(xiii) For every programme, a two-pronged eva­
luation exercise should be conducted as
follows :—
(a) Participant Evaluation :

(vii) For every programme to be organised in a
DIET, a faculty member will be designat­
ed as the Course Director. He would usual­
ly be from the Branch which has nodal res­
ponsibility for that particular category of
programmes.
(viii) As soon as the D IET receives nominations!
for a programme, it will send to every de­
puted teacher the following :—
(a) A basic outline of the course—its ob­
jectives, content and methodology,
(b) Relevant printed material,
(c) A questionnaire to elicit information
about the participapt’s professional
background, strengths, training needs,
and expectations from the course, and
(d) Joining instructions.
(ix) The DIET should insist on receipt of the
filled-out questionnaries at least a month
before the commencement of the oroeramme. The information so received should
be quickly analysed to ascertain partici­
pants’ needs profile, and the non-core part
of the programme as also the methodology
for the ‘core’ part should be designed ac­
cordingly.
(x) Objectives/expected outcomes of every pro­
gramme should be clearly spelt out in terms
of trainees’ knowledge and skill levels, and
attitudes which it seeks to develop. The pro­
gramme should be carefully designed so
that it actually leads to the expected out­
comes.
(xi) In regard to training methodology, state­
ments contained in sub-paras (Jv) and (v)
of para 3.2.2 would apply. In addition,

The modality for this should as far as
possible be self-evaluation. A t the'end of
every sizeable module, participants may be
given a short problem, exercise or test, fol­
lowed by supply of standard answers, so
that they could assess their level of learning
for themselves. A similar exercise could be
conducted at the end of the programme as
well. The purpose of this whole evaluation
process should be diagnostic and remedial.
Low performance should not have adverse
consequences for the trainee, but should
lead to more intensive follow-up in such
cases by the DIET. This whole approach—
that the evaluation exercise is meant only
to professionally help the trainees,
and
would not adversely affect them in any way
should be clearly explained to them,
so that they cooperate fully, and benefit
from it.
(b) Programmes and Faculty Evaluation :
Every participant should also be given a
well-designed questionnaire to elicit his
assessment and suggestions about the effec­
tiveness of the programme and the faculty
associated with it. Feedback so received
should be quickly analysed and utilized to
improve future programmes.
In addition to the above written exercise
in evaluation, at least one session on the
last day of the programme should be devot­
ed to a free and frank exchange of views
on the programme’s effectiveness and level
of participation. In case of programmes of
longer than one week’s duration, the Course
Director should also hold informal sessions
with participants at the end of every week
in order to get regular feedback.

<!-- page 33 -->

25

3.3.5

In-service Education of Teachers : Other Moda­
lities

Programmes ofl in-service education in the contact
mode have been discussed in the preceding two paras.
However, the contact mode is expensive apd has limi­
tations in terms of numerical coverage. As mentioned
in para 3.3.3. in district having over 3000 elementary
teacher population, DIETs’ efforts would have to be
supplemented through ‘main’ programmes organised
at other centres as well. However, in districts where
teacher population is very high and/or possibility of
conducting training programmes at other centres is
limited, alternative strategies on the lines indicated
below would have to be adopted :—
1. The ‘cut-off period’ of three years mention­
ed in sub-para (v) of para 3.3.4 may be in­
creased upto five years.
2. The DIET may aim at covering— through its
own ‘main programmes— say, two teachers
from every elementary school, of whom one
would be the Head Master.
3. A School Complex and/or School-based pro­
gramme of in-service education may be orga­
nised especially for the benefit of teachers
who cannot be covered in contact program­
mes. Teachers trained at the DIET as at
(2) above could serve as resource persons in
such a programme, besides others e.g. facul­
ty from the D IET and other teacher educa­
tion institutions, Higher Secondary Schools,
Block Education Officer, etc. The D IET and
the DEO together would need to work out
details of such a programme looking to local
circumstances, and the DIET would have
to provide full academic and resource sup­
port in its implementation.
'
4. The D IET may also produce and distribute
appropriate printed modules and self-learning
packages to enable elementary teachers to
learn on their own, as well as in School/
School-complex-based
manner
described
above. Operationalising (3) and (4) above
would, need a good deal of innovativeness and
careful planning and execution.
5. As a D IET gains experience and competence
in conducting in-service education of teachers
in the distance mode, it could work towards
changing the modality of the ‘main’ and other
programmes from 100% contact to a distance-cum-contact mode. With this, the dura­
tion of the ‘contact’ would get reduced, and
greater numerical coverage would become
5 —551 Edu/89

possible. However, such a switch-cover would
have considerable academic and organisational
implications, which would have to be taken
care of.
Even where all elementary teachers of a district can
be covered in the contact mode once in five years,
modalities indicated at (3) and (4) above would
still be useful by way of supplementing training in
the contact mode.
3.4 Field Interaction (including Extension) activities
3.4.1
One of the main shortcomings of existing
Elementary Teacher Education Institutions (ETEIs)
has been their generally low level of contact with the
field i.e. with schools, teachers, N F E /A E Centres
and their instructors. This perhaps was partly due
to non-fostering of an appropriate culture, and partly
due to lack of necessary wherc-withal in the ETEIs.
The NPE and POA clearly dictate an end to this situ­
ation of isolation. Therefore, from the start, a funda­
mentally different culture will need to be fostered in
the DIET so that it maintains the closest possible cpntact with the field. Activities taken up in pursu­
ance of this may be described as ‘Field Interaction’
activities, and would be one of the chief modalities
of providing resource and learning support to elemen­
tary schools and A E/N FE Centres. In specific terms,
field interaction would have the following main
aims :—
(i) Identification of the practical problems
being faced in the field so as to devise ways
of tackling them,
(ii) Obtaining information about worthwhile ex­
periences, innovations, success stories, etc.
and
(iii) Provision of academic guidance, advice ex­
tension and resource support to the field
(including sharing of resources).
For purpose of convenience,
activities may be classified into :—

field

interaction

(i) extension work, and
(ii) other activities.
These are briefly discussed below.
3.4.2
Extension: By “extension” is meant dis­
semination among educational workers (teachers,
instructors etc.) of all information and messages
which need to be disseminated for effective imple­
mentation of policies, programmes and interventions
in various areas of a DIET’s concern. Such informa­

<!-- page 34 -->

26

tion/messages could relate, inter-alia, to the
ing matters :—

follow­

of the Institute who may be interested in this
work.

(i) New Policy decisions, programmes and ini­
tiatives.

(iii) Production of pamphlets, brochures, research
abstracts, etc. and their distribution among
school complexes/schools/AE and N FE
Centres.

(ii) Results of new research studies, experi­
ments and techniques developed, e.g. for
improving enrolment, retention, attainment
levels, etc.
(iii) Any other matters of professional interest
to the teacher/instructor.
Dissemination of information as above in the dis­
trict would be primarily the responsibility of the
DIET. One way in which information will be so dis­
seminated would be the in-service education pro­
grammes which the D IET would organise. How­
ever, as we have seen, the frequency with which a
teacher would attend such a programme may be no
more than once in five years. It would, therefore,
be imperative to organise extension work in several
other ways so that necessary information and mes­
sages reach the grassroots educational workers in a
regular and timely manner. Some of these modalities
could b e :—
(i) Periodic meetings/seminars/conferences of
block level functionaries and heads of
school complexes so that they could, in
turn, disseminate information/messages in
monthly meetings of heads of schools/
school complexes/teachers/supervisors/ins­
tructors.
These meetings/seminars, etc.
would be distinct from training programmes
for these functionaries referred to in para
3.1 and 3.3.3, and may be of one, two or
three days’ duration. Their frequency could
be quarterly for block level functionaries and
six monthly or annually for heads of school
complexes.
(ii) Publication of a newsletter and an institute
journal to be sent to every school/NFE
Centre/AE Centre in the district. The news­
letter may be published quarterly. The
institute journal may be published annually
to begin with. Later, as it gets established,
it could be brought out bi-ajonually. The
newsletter will contain useful information
in capsule form while the journal may pub­
lish full-fledged articles, reports, action re­
search papers, etc.
While the publication of newsletter/journal
would be the responsibility of the IFIC
Branch and its Senior Lecturer may act as
editor for both of them, their editorial board
may comprise a suitable number of other
faculty members as also pre-service trainees

(iv) Circulation of video and audio cassettes,
slides and various other teaching aids among
schools/school complexes/projects and cent­
res of A E/N FE.
(v) A systematic programme of visits by DIET
faculty to school complex meetings/individual schools/AE and NFE centres, and of
bringing Head Masters/teachers/instructors
to the DIET for exposure to new ideas, in­
formation and materials.
3.4.3 Other Field Interaction activities
The term “extension” normally denotes a one-way
process where the extension agency imparts and the
field agency receives. However, the DIET will be
expected to go well beyond this. The thousands of
teachers and personnel of A E /N F E scattered in the
field are perhaps the best source for obtaining infor­
mation on practical problems being experienced and
worthwhile innovations being done in the field in, the
area of elementary and adult education. DIETs will,
therefore, have to try and tap this resource maximally
in its endeavour to carry out its mission. For this, its
interaction with the field would have to be as “twoway” as possible.
The modalities listed at (i) and (v) in the preced­
ing paragraph are already of a two-way nature i.e.
they would be used as much for extension as for elicit­
ing problems and experiences from the field. Follow­
ing are certain other suggested modalities for the latter
purpose :—
(i) Encouraging
School
complexes/Schoolsteachers/NFE/AE personnel to address their
professional/academic
problems
to the
DIET—in writing as well as in meetings.
All such problems would be received in the
nodal branch—i.e. the IFIC Branch in the
case of Elementary Schools & the DRU in
the case of A E /N FE—which would then
refer them, depending on their nature, to
the concerned branch. The latter will con­
vey its comments/advice to the institution/
person concerned after such study, examina­
tion, action research, etc. as may be neces­
sary.
(ii) Encouraging teachers, instructors, etc. to
write papers/articles about their experiences

<!-- page 35 -->

27

and view on topics of professional interest.
Papers of good quality could be published
in the DIET’s journal or forwarded for pub­
lication to a State/national level journal.
Some prizes could also be awarded to per­
sons contributing papers of good quality.
(iii) Every D IET would identify field workers of
high calibre, competence and commitment.
They would then be regularly invited to the
DIET and used as resource persons in rele­
vant programmes. A few of these may also
be brought as visiting fellows/research fel­
lows/research associates for relatively longer
durations (normally exceeding three months)
and may be paid from the budget provision
available for payment to consultants (Annex
8)
(iv) Each member of the faculty of a DIET will
be expected to take a few classes/sessions
every week— or at least every fortnight—in
an Elementary School, A E Centre or NFE
centre. His functioning as a "practitioner’
in this manner will substantially enrich him
as a ‘trainer’ (PI. also see Annex 12, para
6 . 1. 1).
lt;5 Action Research
Field studies, action research and experimentation
to be conducted by the DIETs would be aimed pri­
marily at tackling specific local problems that may
be encountered in achieving the goals of U PE /U E E /
NLM. As already stated, the target groups which
need maximum attention for achieving these goals are
gris/women, SCs/Sts, educationally backward mino­
rities an other groups, slum dwellers, working children,
inhabitants of inaccessible areas, and children/adults
with physical and mental handicaps. Action research
activity will, therefore, aim primarily at
(i) Studing problems in their enrolment, reten­
tion and learning and ways of tackling these
problems,
(ii) Relating learning to the local
and

environment,

(iii) Try-out of specific approaches, techniques,
and materials developed by the D IET to
tackle the above problems.
■; Action research may be concentrated primarily in
the ‘Lab areas’ referred to under ‘Planning and
Management Branch’ in para 2.4.1.
The DIET will
also identify and systematically study success stories
in the district with a view to further field-testing them
and disseminating their messages.

Action research activities of a DIET will be parti­
cipatory in nature-fully involving, as the case may be,
learners, tcchers/schools, A E/N FE personnel and
various agencies involved in implementation of edu­
cational development programmes in the district.
Action research activities which do not invole largo
resources in terms of money and manpower may be
freely undertaken by faculty members according to
their choice, consistent with their other duties. But
activities involving substantial resources would need
to be taken up in the project mode.
Projects for undertaking studies and action research
will be formulated by concerned faculty members of
the Institute based on preliminary studies,
available
data, problems thrown up by the field, etc. All such
proposals will be considered by a sub-committee of
the Programme Advisory Committee (PAC) of the
Institute (see para 3.7.2. below) which may be called
the Sub-Committee on Studies and Action Research
(SSAR). It may include one representative of the
SCERT, one member of a nearby University Depart­
ment of Education or CTE/IASE, the Principal of the
DIET the District level Officers in charge of Element­
ary, Non-Formal and Adult Education, and two or
three presons from the district who may be known
for their achievements in educational innovation and
research (Persons of the last category could be co­
opted if they are not already members of the PAC).
Project proposals will need to be considered and ap­
proved/sanctioned by this Sub-Committee before they
are taken, up for execution or posted to a funding
agency for assistance. On completion of the project,
the concerned team will submit its report to the SSAR,
which will evaluate it and decide on further action
e.g. try-outs on a large scale, general dissemination,
remitting back to the team for further investigations,
etc.
The Senior Lecturer of the IFIC Branch would
serve as the Member Secretary of SSAR, and his
Branch would provide it secretariat support.
As mentioned in Annex 8 and in Note 2 at its end,
there will be a nuclear provision in a D IET’s own
recurring budget for undertaking action research pro­
jects but it will also tap other schemes and sources
which fund such projects. In the case of the latter
type of projects (funded from outside the DIET
Scheme), the D IET will have to follow the guidelines
of the relevant scheme/agency, as well.
Experimentation and innovation in DIETs will be
actively promoted and encouraged by all concerned—
by the SCERT, SRC, other supporting institutions,
DBE, the Principal and Branch Heads.

<!-- page 36 -->

28
3.6 Training Programmes for NFE & AE Personnel
3.6.1 Logistics
The present policy is to provide induction and an­
nual refresher training to AE & NFE instructors
according to the following pattern ~

The Central Directorate of Adult Education and
SRCs would separately issue detailed guidelines re­
garding training programmes for AE personnel. Like­
wise, the Ministry of Human Resource Development/
NCERT and SCERT, would do so for training of
NFE personnel.
3 .7 Institutional Planning for the D IET : Quinquen­

C ategory o f

Instructors

D u ra tio n

of

nial & Annual Exercises

-------------------------- ------------------------------ -Induction T rg.

A nnual R efresher
Trg.

1.

NFE

30 days

20

days

2.

AE

21 day;>

10

days

Workload of training of the above personnel in a
distt. in a particular year would depend on several
factors, and would have substantial distt.-to -distt. and
year-to-year variations. Some of these factors would
be :—
(i) No. of existing instructors/supervisors.
(ii) No. of fresh
instructors/supervisors ap­
pointed in a particular
year on account
of:—
(a) attrition of existing staff, and
(b) opening of new centres/projects.
In general, the over-all training responsibility for
a distt. would have to be shared among the DRU,
A E /N FE projects, NYK, and other capable organisa­
tions, with the DRU playing a nodal role. The ex­
tent to which actual training responsibility will be
borne by the D R U/DIET and by other agencies,
would depend, inter-alia, on :—
(i) Quantum of workload (which in turn would
be determined by factors such as those
stated above).
(ii) Operational case and trainees’ convenience,
and
(iii) Capability of other agencies to conduct such
training.
3.6.2 General Guidelines regarding training program­
mes for AE and NFE Personnel
Much of what has been stated in para 3.3.4 in
the context of in-service programmes for teachers
would apply mutatis-mutandis, to training program­
mes for AE and NFE personnel.
However, the
target group in the latter being of a very different
kind, there will be several distinguishing feature as
well. Above all, the content and methodology of
these programmes would have to be kept as simple
and direct as possible.

3.7.1
To achieve its mission with the available
resources, the DIET will have to plan its program­
mes and activities in a meticulous and integrated
manner both over long-and short-terms. Towards
this end, every DIET will prepare quinquennial and
annual institutional plans which will serve as blue
prints for all its programmes and activities over the
five-year/one year period. These planning exercises
may be done in the following manner :—
(i) The mission of a DIET has been spelt out
in general terms in Chapter 1. Keeping this
in view, specific goals and performance
norms would need to be set for every DIET
—both for
medium-and-short terms—
which may serve as its beacon light. This
task of goal/norm setting will be done by
the District Board of Education in consul­
tation with the DIET and other relevant
agencies. While doing so, it will keep in
mind various Central and State level guide­
lines, and the specific circumstances and
problems of the district.
(ii) Based on the above, the DIET will prepare
its five year and annual institutional plans.
Both these kinds of planning exercises will
involve working out how goals/norms set
by the DBE can be best achieved with
available resources. There would be dis­
tinct advantages in formulating the five
year plan immediately after the national and
State level five year plans are finalised so
that it takes full account of the policies,
priorities and programmes spelt out in the
latter.
(iii) Items (i)—(iii) under para 3.3.4 give certain
guidelines about the manner in which the
IFIC Branch should prepare its five year
and annual plans of programmes and acti­
vities. All other branches/units
of the
DIET will also be expected to do five year
and annual planning exercises for their
respective areas of responsibility, in a simi­
lar manner, keeping in view the goals/
norms referred to in (i) above.
(iv) Based on plans prepared by individual
branches/units,
draft five year/annual

<!-- page 37 -->

29

institutional plans for the Institute as a
whole should be prepared. These draft
plans should be discussed first in a meeting
of the DIET faculty. After a broad con­
sensus is reached at this forum, the draft
plans should next go to the Programme
Advisory Committee (PAC)
(see para
3.7.2. below). After taking into account
the advice and guidance of the PAC, the
plans should be finalised, and their copies
sent to the DBE, SCERT and SRC.
(v) The annual institutional plan may be pre­
pared academic year-wise. It should be
finalised at least three months before the
commencement of the year. The calendar
of programmes referred to in para 3.3.4
(iii) will be finalised after the preparation
of the annual institutional plan is complet­
ed as above, and would fully dovetail with
the latter. NIEPA will circulate detailed
guidelines for quinquennial and annual in­
stitutional planning to be done by DIETs.
Nodal responsibility for this work within the
DIET will rest with the Planning and Man­
agement Branch, which will discharge it in
close coordination with the IFIC Branch.
3.7.2 Programme Advisory Committee (PAC)
Every D IET will have a Programme Advisory
Committee which will advise and guide the Institute
in the planning and conduct of its entire range of
programme and activities. The Committee may have
the following composition :—
(1) Principal, DIET : Convener
(2) One representative each from all agencies
with which the DIET would have linkage
e.g. :
(i) District Board of Education (represenatative to be chosen from among the
Board’s non-official members)
(ii) SCERT, SIET and SRC
(iii) Nearest University Department of
Education.
(iv) Nearest CTE or IASE, and in the
absence of these, any other good
secondary teacher education institu­
tion located nearby.
(v) District Educational Officer*.
(vi) District level officers in-charfge of AE,
NFE and Women & Child Develop­
ment.
(vii) CEO, DRDA.

(viii) Station Director of the local Radio
Station (wherever applicable).
(ix) District
Officer.

Information

and

Publicity

(x) In case a DRU is wholly or partly out­
side the DIET, the head of such DRU.
(xi) Coordinator, Nehru Yuwak Kendra.
(xii) NGOs in the district working in the
area of elementary/adult education.
(3) Representatives of client group and staff :
(i) Two students of the pre-service teacher
education course.
(ii) One elementry teacher, one Head
Master and one Instructor or Super­
visor each of AE and NFE who may
have undergone in-service training in
the institution in the last one year.
(iii) Three representatives of the faculty of
the institution of whom one would be
Vice-Principal/Senior Lecturer
in­
charge of DRU, one other Senior
Lecturer and one Lecturer.
(4) Others :
(i) Two eminent educationists/teacher educa­
tors/teachers, with a substantial record of
service, who may be interested in associat­
ing themselves with and contributing to the
activities of the DIET.
(ii) Two other eminent citizens of the district
whose association with the DIET may be of
benefit to the institution.
Functions of the PAC vis-a-vis preparation of five
year and annual institutional plans of the DIET have
been indicated in the preceding paragraph (3.7.1).
Meetings of the PAC may be held at least twice a
year. It may set up Sub-Committees: to go into
various categories of programmes conducted by the
DIET e.g. teacher education, AE, NFE, field interac­
tion, action research, etc. The Sub-Committees may
co-opt in their work experts and other concerned per­
sons who may not necessarily be members of the PAC.
Functions of the Sub-Committee on Studies and
Action Research (SSAR) have been dealt with in
para 3.5.
3.8 Co-curricular activities
While DIETs will be organised a large number of
formaly structured, curriculum-related training and

rhioughout this document, ‘District Education Officer* means the senior-most officer responsible for school education in
the district, by whotever designation called.

<!-- page 38 -->

30
other programmes, they would also be expected to
organise a wide range of co-curricular activities in
which faculty members and trainees (especially pre­
service trainees) would participate on a voluntary
basis, depending on their individual interest. Though
these activities would be outside regular curricular
programmes, they would play an important role in
enriching life on the campus.
Pre-service trainees would be the main beneficia­
ries of these activities, since they are the ones who
would be at the Institute for long durations, but par­
ticipants of in-service programmes would also find
many of these activities interesting and useful.
Co-curricular activities will be expected to be or­
ganised chiefly through clubs and societies formed for
the purpose. Each such club/society would have one
or two staff associates/advisers, and trainees would
enrol as members of such clubs/societies depending
on their interest. Office bearers of each club/society
would be chosen from amongst such trainee members

in accordance with rules Which the Institute may frame
for the purpose. Following are some of the areas for
which clubs/societies could be constituted :
(1) Debates and elocution
(2) Literary activities
(3) Hiking and mountaineering
(4) History and Archaeology
(5) Currept Affairs
(6) Fine arts
(7) Music, Dance and Drama
(8) Environment
(9) Science
(10) Hobbies
(11) Athletics/Gymnestics/Aquatics
(12) Various games and other sports
(13) Yoga/Judo/K erate
(14) Social Service
.(15) Scouting and guiding

<!-- page 39 -->

PART—II

DIETs : IMPLEMENTING THE CONCEPT

3hafptcr 4 Establishment of District Institutes of Education and Training M am—Features of the Scheme.
Ohaipter 5 Perceptive Planning, Project Formulation and Sanction.
Ohaipter 6 Operationalising DIETs : Project Implementation
C h a p te r 7 Monitoring and Review

31-32

<!-- page 40 -->

<!-- page 41 -->

CHAPTER 4

ESTABLISHMENT OF DISTRICT INSTITUTES OF
EDUCATION A N D TRAINING - MAIN FEATURES
OF THE SCHEME
4.1 In Part I, an attempt has been made to con­
ceptualize the D IET in some detail. This, the second
part of the document deals with the realisation of that
concept i.e. with the mechanics of setting up the kind
of DIETs described in Part I.

(b) In every district for which Central as­
sistance is sanctioned the State Government/UT Administration will esta­
blish/operationalise the Institute in a
time-bound manner.

4.2 As stated in para 1.6 and Annex 2, a Centrally
Sponsored Scheme of Re-structuring and Re-organisa­
tion of Teacher Education is being implemented since
October, 1987, in pursuance of the NPE. One of the
components of the Scheme is to set up about 400
DIETs in the country. Till October 1989, Central
assistance had been sanctioned under the scheme for
setting up 216 DIETs.

(Depending on whether a DIET will be set
■up by upgrading an existing Government
ETEI, or established de novo, the project
may be called an ‘upgradation’ or ‘new’
project.)
4.4.

4.3 Main Features of the DIET Scheme*
Following are the main features
Scheme :

of

the

Tackling of certain institutional and manpower
problems in Elementary Teacher Education :
Pre-condition for Central assistance

4.4.1 ifae problems :
The teacher education scenario in the country is
beset with several problems, which vary from State to
State. Some of the problems are :—
(i) Mushroom growth fn the number of ‘sub­
standard’ and ‘malpractising’ institutions,
and
(ii) Serious mismatch between the demand and
supply of trained teachers (and in some
States, even of qualified teachers)— often
manifesting itself, variously, as large back­
logs of
(a) underqualified and/or untrained, serv­
ing teachers, and
(b) trained, unemployed teachers.
4.4.2 ‘Sub-standard’ and Malpractising’ Institutions:
Criteria
.

DIET

(i) DIETs will be set up by the concerned
State Governments, and Union Territory
Admns., with Central assistance.
(ii) In districts which have Government Ele­
mentary Teacher Education Institutions
(E T E Is), one of such institutions will be
developed/upgraded as a DIET. If a
district has no Government ETEI but its
size warrants a DIET (please see para
2.6.3), it will be set up in such a district,
de novo.
(iii) Central assistance will be provided to State
(Governments/UT Admns. for establishing
DIETs as above on project basis, subject to
the latter fulfilling certain conditions spelt
out in paras 4.4 and 4.5, and in accordance
with norms given in para 4.6. Some of the
implications of giving assistance on project
basis are :—
(a) Proposals for establishing DIETs will
be prepared separately for each dis­
trict, keeping in view its specific cir­
cumstances and needs, status of the
institution to be upgraded (wherever
applicable), etc.

‘Sub-standard’ Institutions :
Annex 7 gives conditions for recognition of ETEIs,
as suggested by the NCTE Committee on Elementary
Teacher Education. If an institution is considerably
below these norms, and the body running it is unwill­
ing or incapable of making necessary improvements in
it within a reasonable period, it would be classified as
a ‘sub-standard’ institution.
‘Malpractising’ Institution :—
If as a result of an audit inspection or any other
kind of check or appraisal, an institution is found to

♦ E v en th o u g h , strictly speaking, D IE T is one o f the five com ponents o f the C entrally Sponsored Scheme o f T eacher E d u ca tio n , it
has its e lf b e en referred to as a Scheme in the rest o f this docum ent, for the sake o f convenience.

6—551 Edu/89

M

<!-- page 42 -->

34

have indulged in a serious breach of any law, code,
statute, rule, regulation, orders or conditions of recog­
nition/affiliation applicable to it, with private gain as
the motive, it may be classified as a ‘malpractising’
institution. Such malpractices would include :—
(i) Charging of captiation fee, or other
of fees on an exorbitant scale,

kind

(ii) Selection of trainees on improper or unfair
basis, and exceeding sanctioned intake,
(iii) Malpractices in the conduct of examinations,
(iv) Payment of lesser amounts to staff than their
declared emoluments,
(v) Other financial irregularities, and commerci­
alisation of teacher Education.
4.4.3 Action Required
Mere establishment of DIETs will not go very far
in improving teacher quality if the maladies describ­
ed in para 4.4.1 are allowed to persist. Therefore, for
a State/U T to be eligible for Central assistance under
the DIET Scheme, it will have to fulfil the following
pre-conditions :—
(i) All existing ETEIs should be surveyed and
appraised and those found to be sub-stand­
ard or engaged in malpractices should be
phased out in a time-bound manner,
through steps like de-recognition, disaffilia­
tion, withdrawal of grants, etc.
(ii) If the State has a large backlog of under­
qualified and/or untrained teachers, it should
launch a time-bound action plan to liqui­
date such backlog, and to stop further re­
cruitment of such teachers. Exception may
however be made to the extent necessary
for remote pockets facing a problem of non­
availability of qualified/trained candidates
willing to serve there.
(iii) (a) If a State is left with a substantial sur­
plus in pre-service training capacity even
after the excercise at (i) above it should
suitably reduce such capacity further. This
may be done for example, by converting a
part of pre-service into in-service training
capacity, reducing intake in pre-service
courses, and if necessary, closing down some
more relatively under-provided institutions.
(b) If, on the other hand, a State has a
serious default in pre-service training
capacity, it should augment it by in­
creasing seats in existing institutions,
opening new institutions etc. (How­
ever, seats in DIETs should be kept
within the limits seven in Annex 4,

so that the pre-service function does
not interfere with the Institute’s capa­
bilities to discharge its other assigned
functions).
In sum, every State/U T will have to take steps
to bring about a rough balance between demand and
supply of trained elementary, teachers, within a rea­
sonable timeframe.
4.5 Role of State Governments/UT Administrations :
Certain other aspects.
A part from the responsibility envisaged in para
4.4.3 above, following are certain other matters for
which State Govts./UT Admns. will have to assume
responsibility under the Scheme :—
(i) Making available adequate land for the
DIET campus— in case acquisition becomes
necessary, it will have to be done out of
States’/U T s’ own resources.
(ii) For DIETs sanctioned in the VII Plan period,
to bear liability for all recurring expenditure,
as from 1-4-90, on a scale suitable for such
Institutes (which would include, besides ex­
penditure on staff, adequate provision for
maintenance of buildings, replenishment of
equipment/books, other contingencies, and
for conduct of programmes, on an appro­
priate scale)
(iii) Even during the VII Plan period, to bear
recurring liability to the following extent :—
(a) upto the level of its committed liability
prior to upgradation,
(b) For the in-service programmes to be
conducted in the DIETs, Central Govt,
would pay for (a) contingent expendi­
ture (e.g. stationery, course material,
etc.), and (b) board of the outstation
participants coming from Govt, and
semi-Govt. institutions @ Rs. 20/- per
day per person, and for working lunch
for the local participants of the same
category. Outstation participants would
also be entitled to free lodging in the
hostel. However, expenses on account
of the participants’ TA (including cost
of local travel) and out-of-pocket allow­
ance (at the rate applicable where free
board and lodge are provided) as also
the liability for their compensatory
leave, would have to be borne by the
State
Govts./UT Admn./employer
concerned.
(iv) Ensuring that necessary improvements are
carried out in ETEIs which are identified

<!-- page 43 -->

neither for upgradation into DIETs nor for
being phased out in terms of Section 4.4
(in other words, which are to be retained
as such) so that they broadly come uptothe
norms given in Annex 7.

need-based manner, and competing requirements suit­
ably prioritised, so that above averages are achieved.
In the case of hilly districts some relaxation in the
above average norms for civil works would be avail­
able.

(v) Ensuring that elementary teachers, head­
masters, A E /N FE personnel, etc. are syste­
matically sponsored for the in-service training
programmes conducted in the DIETs.

Under ‘Civil Works’, Central
assistance will be
available, in ‘upgradation’ cases for the following items
also, within the above overall norm of Rs. 40 lakhs :
(i) Special Repairs and Alterations/Re-model­
ling in existing buildings provided this leads
to overall economy through reduced need
for new construction, and

(vi) Ensuring that alternative arrangements are
made for adequate in-sei'vice training of
teachers, and for training of A E /N F E per­
sonnel, to the extent this cannot be done in
the DIETs due to the problem of numbers.
State Govts./UT Administrations will be eligible for
Central assistance under the DIET scheme, subject to
their giving a clear commitment to bear responsibility
for the above items.
4.6 Norms of Central assistance
4.6.1 Non-Recurring Items
‘Average norms’ of Central assistance for DIET
oroject for non-recurring items would be as follows :—
Category of Project

1. ’Upgradation'
Project
2. 'New' projects

Average Norms of Ceitral Assis­
tance
(Rupees in lakh)
for Civil
Works

fos Equipment

Total

40.0

10 0

50.0

64.0

13 0

77.0

(ii) Augmentation of basic facilities on the cam­
pus, like water supply, electrification, etc.,
in case these are considered inadequate look­
ing to the D IET’s needs.
Within the norms of Rs. 40 lakhs, outlay for the
above two items will normally be kept within Rs. 5
lakhs.
While it is not possible to indicate further break­
up of the normative amounts given above for ‘upgrada­
tion’ cases— due to wide variations in the circumstan­
ces of such cases— this can be done for ‘new’ cases
because of their broad similarity. The rough break-up
for such cases may be taken to be as follows :—
A.

Civil Work') :
Institute Build'iig
150 se tte r hostel
5 staff q u itte rs

Rs.

TOTAL :

The above norms are by way of an average— to be
achieved across various projects of each category, for
a State/UT. Projects will have to be planned in a

Rs>.
Rs

26 lakhs
32 lakhs
6 lakhs

Rs.

64 lakhs

The above amounts are inclusive of all costs asso­
ciated with construction e.g. internal and external
electrification, water supply, sanitation, service roads,
fencing, etc.

E Q U IP M E N T :

Norms of Central assistance for a ‘new project’
(In lakhs)
--------------- — - ----- ------------------------------- ----------------Furniture
Equipment
Total

Category of equipment

1
1.

2

Library books, furniture & equipment.

0.84
(for furniture equipment)

3

4

1.66
(for books)

2.5

2. Methods Labs. :
(a) Psychology
. . .
.
(b) Science & mathematics
.
.
3. Social Studies and Language Teaching.

0 27
—

0.07
1.21
0.1

0.07
1.48
0.1

4.

0.05

0.12

0.17

Work Experience

.

.

.

.

Remarks
5

It is presumed that
all new building to
be constructed will
have
built-in
almirahs/cupboards/
shelves/chests/black
boards and these
would also be built,
as far as possible,

<!-- page 44 -->

.

0. 1
—

0.23
0.3

0.33
0.3

7. Educational Technology .
.
.
8. C o m p u t e r s .....................................
9. Education of the Handicapped
.

0.08
0.05
—

1.14
1.65
0.4

1.22
1.7
0.4

..............................................
10. DRU
11. Furniture and equipment for classroom,
staff rooms and office
.
■
■
12. 150 seater hostel
.
.
.
.

—

0.13

0.13

1.75
—

0.45

2.2
2. 4

5. Art Education
.
.
.
.
6. Physical Education & Sports .

TOTAL

.....................................

4.6.2 Recurring items
As per details given in Annex-8, a fully operational
DIET, set up in accordance with norms given in Annex
4, is expected to have an annual recurring budget
of Rs. 24.4 lakhs towards staff emoluments, contin­

--

into the
existing
buildings (as part of
Special
Repairs1
Remodelling), so as
to minimise the need
to separately pur­
chase these items.

13.0

gencies and programmes (except those funded under
other schemes like AE, NFE, etc.). Central assis­
tance will be available till 31-3-1990 upto this ex­
tent, reduced by the level of State Government’s com­
mitted expenditure on the concerned ETEI prior to
its upgradation.

<!-- page 45 -->

CHAPTER 5

PERSPECTIVE PLANNING, PROJECT FORMULATION
AND SANCTION
5.1 Constitution of a Task Force

5.2 Decoments to be prepared by the Task Force

From what has been said in the previous chapters,
it is clear that meeting the prescribed pre-conditions
and preparing district-wise project proposals would be
a detailed exercise requiring considerable work by
way of data collection, analysis, and perspective/pro­
ject planning, taking care of the needs of elementary
schools as well as N FE and AE sectors. In order
that this is properly done, it is recommended that every
State G ovt./U T Admn. constitute a Task Force for
the purpose, which may have the following composi­
tion :—

5.2.1
When proposals are to be formulated under
the DIET scheme for a State/UT for the first time,
the task force will prepare :—
(1) A Perspective Plan for Elementary Teach­
er Education in the format given in Annex
10, and
(2) Project proposals for setting up individual
DIETs as per para 5.4(8) below.
In the subsequent years, the Task Force will pre­
pare only documents mentioned at (2) above.

(i) An officer of the State Govt, in the Educa­
tion Department not below the rank of
Deputy Secretary.

5.2.2 The Perspective Plan
The Perspective Plan will essentially give an over­
view of the existing status of Elementary Teacher Edu­
cation system in the State/UT and indicate how the
State G ovt./\JT Admn. proposes to go about improv­
ing it in a planned and time-bound manner. It will,
inter alia, give the following information :

(ii) Representatives of the SCERT and the
State Resource Centre for Adult Education;
(iii) Representatives of the Directorates adminis­
tratively dealing with Elementary Education,
Teacher Education, Non-formal Education
and Adult Education (not below the rank of
Joint Directors);

(a) Estimated demand and supply of trained ele­
mentary teachers in the State
(b) Identification of sub-standard and malpractising ETEIs

(iv) Seniprmost Finance Officer in the State Edu­
cation Department, or in the Directorate
dealing with Teacher Education, or in the
SCERT;

(c) Action Plan for implementing steps outlined
in para 4.4.3
(d) Present system of pre-service Elementary
Teacher Education and measures proposed
to be taken to improve it (e.g. in terms of
eligibility criteria, course duration, admis­
sion procedure, syllabus, examination sys­
tem, etc.)

(v) State level officer-in-charge of planning in
the Education Deartment;
(vi) Field Adviser, NCERT;
(vii) One or two specialists in the area of Ele­
mentary Teacher Education to be nominat­
ed by the State Govt.;

(e) M anner in which in-service training needs of
elementary teachers (including Head Mast­
ers), and training needs of AE and NFE
personnel are proposed to be met, and the
manner in which this responsibility will be
shared between DIETs and other institu­
tions.

(viii) An Engineer of the Design Wing of the
State PWD, not below the rank of an Exe­
cutive Engineer;
(ix)
The District Education Officer* may be co­
opted as a member whenever the Task Force
tours or considers proposals related to a
(f)
DIET model proposed to be adopted in the
particular district.
_____
State— in terms of organisational structure,
*P1. see footnote in para 3.7.2.
37

<!-- page 46 -->

38

criteria for recruitment of faculty, physical
facilities, academic features, etc.
(g) A phased programme for establishment of
DIETs, including identification of agencies
which will carry out various tasks e.g. build­
ing construction, procurement of equipment,
recruitment and training of staff, develop­
ment of various programmes to be conduct­
ed in DIETs, etc.
5.2.3 Project proposals
Proposals for setting up individual DIETs will con­
tain, inter alia, the following information :—
(a ) Estimation of the size and nature of the
DIET’s target group in the district (Elemen­
tary Teachers, A E /N FE personnel, etc.)
(b) Changes necessary, if any, in the design of
the DIET to be set up in the district, keep­
ing in view (a) above, and other relevant
factors e.g. availability of a suitable NGO
for functioning as DRU, bi- or tri-lingual
character of the district, etc.
(c) Size of outlay required for setting up the
DIET—for buildings and equipment,
(d > Any other district-specific information
significance.

of

5.3 Steps in Perspective Planning
To prepare the Perspective Plan referred to in the
previous section, the Task Force should proceed as
follows :—
(1 ) Survey and Appraisal of existing ETEIs
All existing ETEIs of the State should be apprais­
ed by the Task Force in the following manner :—
(i) A status report should be obtained from
all of them, in the format given in Annex
9 through the District Education Officer who
will scrutinise and verify its contents.
(ii) At least one member (preferably two) of
the Task Force should visit every unaided
ETEI, and personally verify its status. As
for the remaining ETEIs (Govt, and aided),
a reasonable proportion of them should be
similarly visited by members/sub-groups of
the Task Force for the same purpose.
(iii) On the basis of the above survey, the Task
Force should identify sub-standard and mal­
practising ETEIs, and send a detailed report
to the State Govt, recommending their closure.

(2) Backlog of Untrained and Underqualified
chers
.

Tea­

The Task Force should ascertain figures of un­
trained and underqualified teachers in the State, if
any, prepare a time-bound action plan for liquidating
their backlog (in a maximum of, say, five years), and
submit it for State Govt.’s approval. Financial imp­
lications of the Plan should be clearly spelt out, and
it should be so prepared that recruitment of untrained/
under-qualified candidates, if being done in the State,
also comes to an end simultaneously with, or earlier
than the liquidation of the backlog.
(3) Serious Mis-match between Demand and Supply
of Trained Teachers
The Task Force will estimate the demand of trained
elementary teachers in the State over the next five
years, and compare it with the output of ETEIs that
will remain after closures, if any, pursuant to (1)
above. Backlog of trained, unemployed teachers in
the State, if any, will also be kept in view. Looking
to all these factors, if a serious surplus or deficit is
foivid in the elementary teacher training capacity in
the State, the Task Force will recommend action to
the State Govt, on the lines suggested in para
4.4.3 (iii).
(4) Model of the D IET to be followed in the State
The Task Force will carefully examine the suitabi­
lity for the State, of the organisational model for
DIETs recommended in Chapter 2, and recommend
what model should be followed in the State. While
doing so, it will also examine the guidelines for per­
sonnel policy given in para 6.2.4.2 and Annex 12 and
recommend with what modifications, if any, these
should be. followed in the State.
(5) Identification of construction agency
The Task Force will tentatively identify the agency
or agencies which will construct DIET buildings in
various districts of the State e.g. PWD, Housing
Board, Construction Corporation, etc. The agencies
should be so chosen that they are able to execute civil
works quickly, economically and of good standard.
(6) Obtaining State Govt’s orders on items (1 )(5) above
The Task Force will send a consolidated report to
the State Govt, containing its recommendations on
items ( 1 ) —(5) above, and obtain the latter’s specific
orders on each item so that the pre-copditions for
Central assistance spelt out in the previous chapter
are satisfied. Orders on (2 ) should be accompanied
by necessary financial commitment, as also on (3) if

<!-- page 47 -->

39

it involves opening new ETEIs (which will be neces­
sary in the deficit situation).
(7) Preparation of Perspective Plan
After State Govt’s orders are obtained as above, the
Task Force will prepare a Perspective Plan for Ele­
mentary Teacher Education for the State, in the format
given in Annex 10, incorporating the said orders. The
Plan will clearly indicate districts for which separate
DIETs will not be set up keeping in view the criteria
given in para 2.6.3, and the nearby district to whose
DIET each such district will be attached.
5.4 Steps in formulation of project proposals
The Central Govt, will communicate each year to
State Govt, number of D IET projects that should be
prepared for that particular year. Normally, all dis­
tricts of a state may be expected to be covered over a
three year period. The Task Force will prepare pro­
posals for the indicated number of projects in the
format given in Annex 11. For doing this, it will pro­
ceed as follows :—
(1) Selection of districts :
Districts for setting up DIETs will be chosen by
the Task Force keeping in view (a) guidelines, if
any, laid down by the Central Govt, while indicating
the number of projects for the year, and (b ) guidlines or directives of the State Govt. In States
having tribal sub-plan districts, a proportionate num­
ber of such districts should be included in the pro­
posals every year.
(2) Locating the D IE T in the selected districts :
If a district has only one Government ETEI, it
would normally select itself for upgradation into a
DIET. If, however, it is running in a rented build­
ing, adequate land should be acquired for constructing
a new DIET campus, preferably at the same place, so
as to cause minimum dislocation.
If a district has two or more Government ETEIs,
the one with the best physical infrastructure and aca­
demic record should be chosen for upgradation. The
former criterion will ensure that financial require­
ments for upgradation cases, remain within the norms
laid down in para 4.6.
If a district has no Government ETEI at all, loca­
tion of the D IET should be decided based on factors
"ifke centrality, ready availability of adequate land,
and availability of existing buildings with the State
Education Deptt. where the D IET could start func­
tioning without waitipg for new buildings to come up.
(3) Visit to the E T E I chosen for upgradation/place
chosen for locating ‘new’ D IET
The Task Force will divide itself into a suitable
number of sub-groups, and a sub-group will visit each

district selected for establishment of a DIET in the
year. Apart from district headquarters, the sub-group
will visit the ETEI chosen for upgradation or, as the
case may be, the place chosen for establishment of a
new’ DIET. During these visits, the sub-groups will
hold extensive discussions with the DEO, district level
officers in charge of AE and NFE, staff of the ETEI
concerned, other experts, and engineers of the cons­
truction agency chosen for the particular district. The
sub-group will also carefully study the existing status
of the ETE I and devise ways of developing it into a
DIET (or of setting up a ‘new’ DIET) in the most
economical manner possible.
(4) Deciding about the D R V :
Based on the principles outlined in para 2.6.2,
the Task Force will decide which districts need a
DRU for AE and NFE both, which need a Unit for
only one of them, and which, if any, do not need
it at all. Next, the Task Force will take stock of
the NGOs available in the districts which need a
DRU, and identify those districts where the function
of the DRU should be assigned—for AE and NFE
both, or for one of them— to a suitable NGO, and
those where the DRU will have to be created wholly
ot partly as a vmit of the DIET.
(5) Decisions regarding other changes necessary in
the D IET model for individual districts
While the Task Force would have obtained— as per
para 5.3— State Govt.’s orders on the DIET model to
be followed in the State in general, it will study the
profiles of the chosen districts and decide the exact
decision which should be followed for each individual
districts. Such a design may be identical with the
general one, or may have some variations due to fac­
tors like bilingual character, relatively low elementary
teacher population, etc. (Please see para 2.6.3).
(6) Determination of financial outlays
recurring Central assistance

for

Non­

As already stated, cost of land acquisition, if any,
has to be borne by the State Govt. The next crucial
step in the project formulation exercise is to work out
outlays for civil works and equipment necessary to
upgrade the chosen Govt. ETEI into a DIET, or for
establishing a ‘new’ DIET. This may be done in the
following manner :—
A. Civil Works :
In an ‘upgradation’ case, outlay for civil works will
be for the following items :—
(i) Augmentation, to the extent necessary, of
basic amenities e.g. water supply, sewerage,
service roads, campus electrification, etc.

<!-- page 48 -->

40

(ii) Special repairs and Alterations/Re-modell­
ing in the existing building to enhance its
safety, life-span and utilisation (Alteration/
Re-modelling could be by way of enclosing
verandahs, partitioning large halls etc.)
(iii) New Construction : (ii) should be so plan­
ned that it minimises the need for new cons­
truction, and is cost-effective. New cons­
truction should be planned to the extent
still necessary after this, keeping in view
the financial norms. Annex 13 suggests de­
tailed physical norms for the complete
buildings on a DIET campus to be set up in
a district which fulfils all the conditions
given in para 2.6.1. These should be suit­
a b ly adapted and used for planning new
construction. In upgradation cases, norms
so adapted for a ‘new’ campus should be
treated as a reference level, the endeavour
being to bring the existing institution upto
such level. For example, suppose a Task
Force decides that a complete D IET build­
ing should have 10,000 sq. ft. of carpet
area, and the carpet area of an existing
'
ETEI building is as follows :—
Existing carpet area
Addl. Carpet area which would
become available by enclosing a
large verandah, and re-doin^ tha
badly danugei ceiling of
a
hall
TOTAL

: 6000 sq. ft.

: 1000 oq. ft.
7000 s . ft.

In such a case, new construction to the extent of
about 3000 sq. ft. of carpet area may be planned. Of
course, the size and details of the new building will
have to be decided not in this crude arithmetical
fashion, but by working out the additional spaces
necessary (e.g. classrooms, office rooms, library, labs)
keeping in view those already available.
Planning the buildings in a ‘new’ case is simpler ex­
cept that it would still haveto be done with care and
skill so as to managewithin the prescribed financial
norm.
Having decided the physical parameters as above,
rough/preliminary/Stage I cost estimates should be
got drawn up by the construction agency concerned.
Components of additional construction should be care­
fully prioritised, so that the less important ones could
be omitted, if necessary, so as to conform to the finan­
cial norms. Size of the additional hostel building
would in particular have to be decided keeping the
financial norm in view. For example, an institution
may have a 50 seater hostel, and it may be desirable

to add a 150 seater hostel, but if financial norms per­
mit addition of only a 100 seater hostel, planning will
be done accordingly.
B. Equipment
NCERT has circulated in August, 1988 and Febru­
ary, 1989 suggested lists of books and configuration
of equipment, respectively, for a ‘new’ DIET. The
Task Force should study these with reference to the
systems of elementary school education, NFE, AE
and Elementary Teacher Education prevailing in the
State, and decide what these lists should be for the
State, and what their financial implications would be.
Experts in concerned areas should be associated in
this work.
In ‘upgradation’ cases, equipment (including
books) requirements of each institution should be
ascertained with reference to the above lists/configu­
rations prepared by the Task Force, keeping in view
items which the institution already has. Financial
implications of meeting such requirements should be
worked out. In ‘new’ cases, of course, everything
will have to be provided with corresponding financial
requirements.
Based on the exercise indicated at (A ) and (B)
above item-wise required outlays for each project
should be filled up in the format given in Annex 11.
Outlays should be proposed in a need-based manner
and not mechanically as per the norm given in para
4.6.1. For example, outlay for upgrading an already
well-provided institution may be as low as Rs. 20
lakhs, and that for a poorly provided institution as
high as Rs. 60 lakhs. It should, however, be ensur­
ed that the average across all projects of the State con­
forms to the norms given in para 4.6.1.
(7) Indication of a Realistic Time-Frame for Project
Implementation
The next chapter describes various facets of, and
steps involved in implementing DIET projects. The
Task Force should work out a broad time-frame in
which various project activities would be completed—
roughly on the pattern of a PERT chart. Such an
exercise may be done separately for the two categories
of projects viz. ‘new’ and ‘upgradation’, if both kinds
of projects are being proposed in a particular year^;
Generally, the time-frame would be common for all
projects of the same category, but if in certain cases,
a different time-frame is necessary due to their pecu­
liar circumstances, this should be clearly indicated.
(8) Preparation of complete project document
Based on the exercise indicated above, the Task
Force will finalise the documentation for the DIET

<!-- page 49 -->

projects proposed in the year.
comprise :—

The documents

will

(i) Institutional Status Reports in Annex 9;
(ii) Project proposals in Annex 11 [which
would include time estimation referred to in
(7) above].
(iii) Preliminary cost estimates prepared by the
construction agency for the civil works pro­
posed under each project, in support of
indicated outlays; and
(iv) A project-wise descriptive note giving spe­
cial features of the district/existing institu­
tion/project proposal, and justifying choices
and priorities made while formulating the
project.
5.5 Submission of Perspective Plan and Project pro­
posals to the State and Central Governments
After completing the exercise outlined in paras 5.3
and 5.4 above, the Task Force will submit its pers­
pective Plan and project proposals to the State Govt.,
which will specifically approve the former, after care­
ful scrutiny. The Perspective Plan will be counter­
signed by the State Education Secretary in token of
the State Govt.’s approval of its contents. The State
Govt, will also see that project proposals are general­
ly in order. Thereafter, it will forward the Plan and
Project documents to the Ministry, to enable it to
scrutinise them.
5.6 Approval of proposals : State Level Empowered
Committee (SLEC)
Each State/U T will constitute an Empowered Com­
mittee to consider and approve proposals prepared
by the Task Force for establishment of DIET. The
Committee should include everyone from the State
and Centred Governments whose concurrence would
be needed to accord final sanction to the proposals in
both Governments. It may be headed by the senior
most officer of the State Government whose participa­
tion may be necessary from that angle— this officer
may be the Chief Secretary, Additional Chief Secre­
tary, Development Commissioner or the State Educa­
tion Secretary. Other members of the SLEC would
include :—
(1) Secretary to the State Govt, in the Educa­
tion Department (and in Adult Education
Department where this is not a part of
Education Deptt.).
(2) Representatives of the State Departments of
Planning, Finance and (in States with a
substantial tribal population) Tribal Wel­
fare/Development, not below the rank of
Joint Secretaries, and of PWD not below
the rank of a Chief Engineer.
7 —551 Edu/89

(3) Commr/Director of Elementary Education.
(4) Director(s) of Adult and Non-Formal Edu­
cation.
(5) Director of SCERT and SRC.

'

(6) One specialist each in the areas of (i) Ele­
mentary Education/Elementary Teacher Edu­
cation and (ii) Adult Education to be nomi­
nated by the State Govt.
(7) Representative of NCERT and NIEPA.
(8) Representative of the Ministry of Human
Resource Development (Department of Edu­
cation).
(9) Representative of the Integrated Finance
Division, Ministry of Human Resource De­
velopment (Department of Education).
The SLEC will not approve any proposals unless
at least one representative of the Ministry is present
in its meeting. It will first examine the Perspective
Plan, and satisfy itself, inter alia, that (i) the pre­
conditions spelt out in paras 4.4 and 4.5 have been
met, and (ii) appropriate decisions have been taken
regarding organisational structure, personnel policy,
etc. for the DIETs to be set up. It will then examine
the project proposals, and approve them with such
modifications regarding proposed outlays, staffing pat­
tern, etc. as it may deem fit.
The Chairman will get agreed minutes of the meet­
ing drawn up quickly, and circulate them, after ap­
proval, to all concerned.
5.7 Action alter SLEC approval : Release of Instal­
ments of Central Assistance
5.7.2 Assistance for Recurring Items
Based on the agreed/approved minutes of the SLEC,
the Ministry will issue a formal order approving estab­
lishment of recommended DIETs, and indicating for
each DIET, the outlays and staffing pattern, finally
approved for Central assistance. Through this sanc­
tion letter, the Ministry will also release the first in­
stalment of non-recurring assistance to the extent
shown below :—
For civil works : 50% of the approved outlay
For equipment : Full approved outlay
except that for (i) hostel equip­
ment, and (ii) computers
The remaining amount out of the total approved
outlay will be released as second instalment after State
Govt, confirms at least 75% utilisation of the first in­
stalment for each of the two items, and corresponding
physical progress. It should also by then have got

<!-- page 50 -->

42

necessary training imparted to some core staff mem­
bers in use of computers.
5.7.2 Assistance for Recurring Items
Assistance for Recurring Items will usually be re­
leased once for a financial year. The first such assis­
tance for a group of sanctioned projects will normally
be released on receipt of confirmation from the State
Government that it has created posts for the DIETs
concerned, and the work of filling them up is under­

way. The State Govt, will make a demand for re­
curring assistance early in the financial year, based
on realistic estimates of the likely expenditure on re­
curring items during the year. After scrutinising these
and adjusting pre-upgradation level of recurring ex­
penditure as reported in Annex 9 and otherwise, the
Ministry will release appropriate assistance for recur­
ring itmes. Releases in subsequent years will be made
after adjusting outstanding balances, if any, from the
previous year.

<!-- page 51 -->

CHAPTER 6

OPERATIONALISING D IE T s: PROJECT
IMPLEMENTATION
6.2.3
Staffing of DIETs would consist of the fol­
lowing four steps :—
(i) Adoption of a proper personnel (incl, re­
cruitment) policy and formalising it through
suitable recruitment and service rules,
(ii) Creation of posts,
(iii) Recruitment in accordance with the above
rules, and
(iv) Arranging for suitable induction training and
continuing education of the DIET faculty.

6.1 Main components of project implementation
Execution of projects by State Govemments/UT
Administrations will begin with the receipt of the sanc­
tion letter from the Ministry referred to in para 5.7.1,
through which would also be released the first instal­
ment of Central assistance for non-recurring items.
Implementaion of D IET projects will consist mainly
of the following three groups of activities :—
(1) Staffing (particularly Recruitment and train­
ing of staff).
(2) Civil works, and

6.2.4 Settling a recruitment/cadre policy and framing
of rules

(3) Procurement of equipment.

6.2.4.1 Policy Issues requiring decision
To staff DIETs, policy decisions would be required
at the State Government level in regard to the follow­
ing matters, among others :—
6.2 Staffing
(a) Determination of Levels and pay scales of
6.2.1
Effectiveness of the DIETs would hinge, above
various posts in the DIETs.
all, on proper personnel policies being followed. It
(b) Devising recruitment procedures,
would have to be ensured that men and women of
(c) Determination of eligibility criteria to be
aptitude, merit, enthusiasm and dedication are inducted
followed in making recruitments to various
into them, and are provided ample opportunities of
posts,
professional growth, creative work and career advance­
(d) Formation of a suitable cadre for the DIET
ment.
faculty, and its management (e.g. career
6.2.2 Personnel Policy : Objectives
planning).
The basic objectives of the personnel policy in re­
6.2.4.2. Certain Guidelines regarding above matters
gard to DIETs could be defined as follows :—
Various key posts in the DIETs are recommended
(i) Recruitment of persons having necessary
to be created at the following levels and in corres­
qualifications, experience, aptitude, commitponding pay scales :—
•
ment, dynamism, etc.
Certain general guidelines regarding project imple­
mentation— and especially the above three groups of
activities—are given below :

Name of post in the DIET

(ii) To ensure that persons once inducted into
these institutions are allowed a stable tenure
in the teacher education-cum-educational
research (T E /E R ) stream.

1. Principal

Recommended

level

Deputy Director of the state
Education Department.
2. Vice-Principal
An appropriate level between
(I) and (3) .
?. Sr. Lecturer
Principal of a hightr secondary
School.
4. Lecturer
Lecturer/PG
Teacher ot a
Higher Secondary School.
5. Statistician; Technician; Levels at which these posts
Work
Experience are created in other comparable
Teacher/Office Supdt./ institutions/organisations in the
Librarian
State Govt.

(iii) To ensure that their emoluments and ser­
vice conditions are attractive enough for
them to want to make a career out of T E /
ER, and to work with motivation and zeal,
and
(iv) To make arrangements for their continuous
professional development.
43

<!-- page 52 -->

44

Certain detailed guidelines in regard to matters
listed at (b ), (c) and (d) in the previous para have
been given in Annex 12. It has already been men­
tioned in para 1.11 that personnel working in DIETs
shall be non-vacation staff.
6.2.4.3 Framing of Rules
At the stage of preparation and approval of per­
spective plan, State Government would already have
decided certain broad issues in regard to the above
matters. As soon as SLEC approves the first lot of
projects, it (the State Government) should move to
work out full details of the recruitment and cadre
policy, based on the above guidelines, and formalise
its decisions in the shape of recruitment and service
rules for the DIET faculty.
6.2.5 Post creation
Creation of posts usually takes considerable time
particularly because Finance Departments tend to
look rather closely at such proposals. Therefore, as
soon as a sanction order is received and levels and
pay scales of posts have been decided, the State
Education Department should move to get posts
created. In upgradation cases, some posts would
already be in existence. These would get subsumed
in the new pattern—through adjustment, upgradation,
etc. as ma> be necessary. (However, persons occu­
pying academic posts in the pre-upgradation institu­
tion will not automatically get selected to serve in the
DIETs. Indeed, all academic posts in the DIETs
will be filled up only through persons who satisfy
eligibility criteria given in recruitment rules framed
in the light of Annex 12.
Creation of posts for DIETs would require pro­
vision in the State budget/supplementary budget.
The State Education Department should move to get
this done immediately on receipt of the Ministry’s
sanction letter. If, however, formulation of the next
budget/supplementary budget is quite some time
away, it should, instead of waiting for that, get posts
created by obtaining an advance from the contingency
fund of the State.

may not immediately be possible because of the time
involved in completing formalities connected with
the drafting and approval of rules. Therefore, once
eligibility criteria and recruitment produres have been,
in the main, settled, the State Education Department
may make emergency appointments to academic posts
in the DIETs sanctioned in the first lot, without wait­
ing for completion of the formalities of notifying rules.
Even such emergency appointments should, however,
be made in accordance with the same criteria as1 are
proposed to be incorporated in the rules, and
will be subject to regularisation on adoption of such
rules.
6.2.7 Training of DIET faculty
The DIET faculty would require suitable orientation
at the induction stage followed by continuing educa­
tion through suitable refresher and other programmes.
The induction training, in turn, will consist of two
parts, viz :—
(i) T raining in those aspects of a D IET’S work
with which all faculty members should be
well-versed, and
(ii) Specialised training related to the specific area
in which each faculty member would work in
the DIET.
Logistics and content of the above training program­
mes would be worked out by concerned national and
State level agencies e.g. NCERT, NIEPA and the Cent­
ral Directorate of Adult Education at the national
level, and SCERT and SRC at the State level. These
institutions will also themselves run a number of train­
ing programmes for the DIET faculty—NCERT would
do so mainly in its Regional Colleges—but besides
them, selected University Departments of Education
and premier institutions specialising in areas like
Science Education, Language Education. Educational
Technology, etc. will also be utilised for this purpose.
Basic approach in regard to content, logistics, etc.
of induction tr aining and continuing education of DIET
faculty is being worked out, and appropriate commu­
nications on these aspects will be sent to State Govts,
in due course.
6.3 Civil Works

6.2.6 Recruitment
As soon as key decisions regarding post creation
and recruitment procedure are taken, steps should be
initiated to fill up posts in accordance with the settled
procedure. In the first year of implementation of the
Scheme, recruitment in accordance with notified rules

The steps involved in execution of civil works would
be as follows :—
(i) Determination for each project (by senior
officers of the State Education Department,
in consultation with those of the construction
agency) the exact works which need to be

<!-- page 53 -->

45

executed, keeping in view the outlay approved
by the Central Government for the purpose,
i.e.
(a) Augmentation of basic amenities
(b) Special repairs of the existing buildings,
(c) Alterations and minor additions in the
existing buildings, and
(d) New works to be taken up by way of
Institute building, hostel and staff quar­
ters.
The norms given in Annex 13 (or their locally
adopted version) would serve as the referenceframe for this exercise. In other words, deficiencies
vis-a-vis above norms would be identified and priori­
tised, and works will be planned to rectify them—
within the approved outlays.
(ii) The physical parameters of the works to
be taken up having been settled as above,
the construction agency will prepare detail­
ed plans and estimates for them. Care will
be taken to ensure that estimates remain
within the outlay indicated for civil works in
the sanction letter.
In both (i) and (ii) above, all possible
steps will be taken to effect economy—for
example, by following the suggestions and
guidelines contained in Annex 14.
iii) Action will then be taken to accord techni­
cal sanction and administrative approval for
the works according to above plans/esti­
mates at a competent level. Before this,
action would have been taken for necessary
provision in the budget/obtaining advance
from contingency fund.
(iv) The construction agency will then proceed
to invite tenders, award work and get it exe­
cuted. As soon as 75% of the first instal­
ment for civil works is spent, the construc­
tion agency will report the fact to the State
Education Department, to enable it to claim
second instalment from the Central Govern­
ment.
6.4 Procurement of Equipment
This will involve the following steps :—
(i) Developing standard list of books and equip­
ment configuration which every D IET should
have.

NCERT has circulated a suggested list of
library books and journals for DIETs in
August, 1988 and of other equipment in
February, 1989. (Certain general guidelines
regarding selection of library books are given
in Annex. 15 also). Based on these, the
SCERT should develop its own detailed
lists/configurations for supply to the DIETs
of the State. To do this, it should consti­
tute small groups of experts for various areas
e.g. Science and Mathematics, Languages,
Social Studies, Work Experience, Art Edu­
cation, Health and Physical Education, AE,
NFE, CFDE, Teacher Education, UEE,
Planning and Management, research and in­
novation, Educational Technology, Compu­
ters, etc. Based on the recommendations of
these individual groups, a small group of
senior experts should take an overall view
and finalise lists/configurations keeping in
mind the financial norms.
(ii) Determination of institution-wise deficiencies
vis-a-vis above standard lists
Standard lists etc. having been develop­
ed as above, the SCERT should then, pro­
ceed to identify detailed institution-wise re­
quirements of books and equipment, keeping
in view things already available with them.
These would then constitute the preliminary
“shopping list” or the list of books and equip­
ment which need to be procured.
These
should be roughly costed and it should be
ensured, by necessary prioritisation, that
outlay approved by the Ministry for equip­
ment is not exceeded.
(iii) Once the institution-wise “shopping list” is
finalised as above, those items which can be
procured from pre-identified suppliers (i.e.
who are on the permanently approved list
of the State Government), may be procured
from such suppliers (examples are State
Electronics Corporations, State Small Indus­
tries Corporations, Central Jails, etc.). For
the remaining items, tenders/quotations may
be floated. Screening of tenders/quotations
should be done by a high level purchase
committee, and supply orders given based
on its racommendations.
It should be ensured that equipment is supplied on
time, and of the best possible quality. Suppliers’ bills
should be finally settled only after a thorough quality
check of the items supplied to institutions.

<!-- page 54 -->

46

6.5 Conduct of in-service programmes for teachers
and trainii^r programmes for A E /N FE personnel

managed. Some guidelines in this regard are being
given below.

In all upgradation cases, the pre-service course for
teachers would already have been running in the
institution. One of the main indicators of the opera­
tionalisation of an institution as a D IET would there­
fore be commencement by it of conduct of in-service
programmes for elementary teachers and training pro­
grammes for A E /N F E personnel. An Institute may
begin such programmes as soon as its core faculty is
posted and receives initial orientation, and neces­
sary equipment has arrived. Commencement of pro­
grammes' need not normally wait f o rtlie completion
of additional buildings being constructed since this
may take a long time. Instead, efforts should be
made to manage with available buildings. Of course,
full operationalisation of the DIET—as evidenced
by the full range of activities on the expected scale—
would happen only after all three groups of project
activities— viz., civil works, supply of equipment and
posting and training of staff—have been fully com­
pleted.

6.6.2

Certain general guidelines have already been given
in Chapter 3 in regard to organisation of the above
kinds of programmes.
The NCERT, NIEPA,
SCERT, SRC, etc. would in particular, need to deve­
lop the following, for D IET’s guidance and use in the
conduct of above programmes :—
(i) Exemplar course designs for the ‘main’
programmes for elementary teachers/Head­
masters and training programmes for A E/
N FE personnel.
(ii) Detailed guidelines regarding transaction
methodology meant for Course Directors and
their colleagues in the conduct of the pro­
grammes.
(iii) Written modules, suggested reading lists and
other exemplar teaching-learning materials
for the above programmes.
It would be desirable for the SCERT and SRC to
commence work along above lines for the ‘main’ pro­
gramme as soon as sanction letter is received. Deve­
lopment of these programmes and their trial run could
then be expected to get over by the time the DIETs
are staffed. The DIET faculty could then be trained
in the conduct of such programmes, and could com­
mence running these programmes itself.
6.6 Management of DIET Library and Hostel
6.6.1
The library and hostel of a D IET are two
important units, and would need to be efficiently

Library
(1 ) A DIET library should be run on Open
Access System Le. its members should have
free access to the book-stacks so that they
can consult or browse through any book oi
their choice at any time during library
hours.
(2) The library should remain open longer then
the normal Institute hours so that trainees
can use it even beyond regular hours. It
would be desirable if it could also remain
open on Sundays and public holidays.

(3) To facilitate (2 ) above, some special allow­
ance may be paid to library staff and/or
some needy preservice trainees may be en­
gaged to man the library beyond Institute
hours, on payment basis. For this purpose,
a panel of interested and needy students
could be prepared and they could be given
basic training in library working.
(4) Certain guidelines regarding selection and
procurement of books and journals for the
D IET library at the project stage are given
in Annex 15.
(5) For smooth and efficient functioning of the
Institute library, after its initial setting up
at the project stage, a Library Advisory
committee may be set up with the follow­
ing composition :—
1. Principal
2. Vico-Principal and all
Lecturers

: Chairman
Sr.

3. Two Lecturers to benominated by the Principal

: Members
:

,,

4. Two pre-service trainees to be :
nominated by the Principal

,,

5. Two

”

experts in rthe area 'of :
Library Science/Book Promo­
tion/Elementary Teacher Educat'on/AE/NFE.

6. Librarian

: Secretary

The committee may take decisions regarding all
important matters concerning the library including
procedure for selection and purchase of new books,
selection of journals for subscription, optimal utilisa­
tion of the library budget and resources, etc.
6.6.3 Hostel
(1) As already stated, every DIET will have
separate hQstels for men and women. The

<!-- page 55 -->

47

capacities of these hostels will be decided
mainly keeping in view the ratio of men
and women among various groups of trai­
nees who would be coming to the Institute.
(2) The Principal may appoint either a com­
mon warden for both hostels or separate
wardens— as may be found locally suitable—
from among the faculty members. In case
of separate wardens, the one for women’s
hostel may as far as possible, be a lady.
(3) While servicing the residential part of the
hostel will be the responsibility of the Insti­

tute staff, all recurring expenses in connec­
tion with the mess (including remuneration
to cook, etc.) will be borne by trainees. In
case of pre-service trainees, they will bear
it themselves, while payment for other trai­
nees will come from the funds provided for
the conduct of the relevant programmes. The
Institute will only provide furniture and
utensils for use in the mess.
(4) The hostel mess may be run either by the
students as a cooperative, or through a con­
tractor, as may be found locally convenient.

<!-- page 56 -->

CHAPTER 7

MONITORING A N D REVIEW
7.1
From what has been said in the foregoing
chapters, it would be clear that implementing DIET
Scheme is a complex task. No institution of this kind
have existed before, and bringing into existence such
novel and sophisticated institutions', on the scale en­
visaged, is going to be quite a challenge. Several
groups of activities involving diverse agencies have to
be coordinated to set up DIETs in an efficient and
timely manner. Unless the implementation of the
scheme is closely monitored and reviewed at various
levels, there would be a strong possibility of things
going away. As already stated, it is the responsibi­
lity of the State Govemment/UT Administration to
ensure that the Scheme is suitably implemented. The
following mechanisms are recommended for proper
monitoring and review of the implementation of the
Scheme.

7.3 Monitoring and Review by the SLEC
In every meeting of the SLEC which takes place
after the first lot of a State’s projects have been sanc­
tioned, the committee will, before transacting other
business, first review progress of implementation of
the following :—
(i) Action plans prepared in pursuance of paras
4.4.3 and 4.5 of these guidelines, and
(ii) Sanctioned projects.
Whenever the SLEC notices slippages in regard to
the above it will give suitable directions for their
rectification. It will approve new proposals only
after satisfying itself that pace of implementation of
(i) and (ii) above is satisfactory.

7.2 State level Steering-cum-Monitoring Committees
7 .4 Machinery at the DIEX| level

Once projects for establishment of DIETs get
sanctioned, a suitable machinery for steering and
monitoring and review of the implementation of the
tormg the working of the newly set-up DIETs will be
necessary at the State-level.

A t the level of every sanctioned DIET, a committee
may be set-up as follows for sorting out field level
problems in operationalising the D IET :—

For this purpose, State Governments/UT Admns.
may set-up a Committee comprising the following
m em bers:—

(ii) District Education Officer* and District
level officers incharge of AE & NFE.

(1) State Education Secretary
.

Chairman

(i) Principal and Vice-Principal of the DIET

agency

doing

The above Committee should meet at least
quarter.

every

(3) Commissioner/Director of Education
(4) Director(s) of Adult and Non-Formal Edu­
cation

7.5 Periodic Reporting System

(2) Representative of the State
Finance Department

(5) Directors of SCERT and SRC
(6> Senior State level Officers of agencies en­
trusted with construction work for various
DIET projects

(iii) Executive Engineer of the
construction work.

For proper monitoring of the Scheme and of pro­
jects at the State and national levels, relevant infor­
mation would need to flow periodically from the
DIETs to the State, and from the State to the Central
level.

(7) Field Adviser, NCERT.
The above Committee should meet at least every
quarter, and more frequently, if necessary, to dis­
charge its assigned work.
♦Please see footnote in para 3 . 7 . 2.

State Govts, will send monthly and quarterly pro­
gress reports on implementation of the scheme to the
Ministry in three forms circulated vide Ministry’s d.o.

<!-- page 57 -->

49
letter No. F.1-2/88-TE (Desk), dated 29-8-88.
brief particulars are as follows :—

The

Monthly Progress Report (M PR) in Form I
This report will be only regarding ‘Start-up’ activi­
ties and would consist of two parts :—
Part 1
Activities common for all projects, and
Part 2
Project— Specific activities
Copies of relevant documents mentioned in the
Form, when first issued/developed, must be enclosed
with the progress report for the relevant month.
Submission of either part of this monthly return
may be discontinued as soon as activities listed there­
in have been completed for all projects.
Quarterly Progress Report (Q PR) in Forms II & III
Form II
Quarterly Progress Report of expenditure and physi­
cal progress in three parts :—
Part 1 : Expenditure
P art 2 : Civil Works and Staffing, and
Part 3 : Conduct of Programmes
Form III
Quarterly statement of academic staff in position.
Both M PR and QPR are to be sent by the State
1 Education Department addressed to the Joint Secre­
tary/Joint Educational Adviser (Elementary Educa­
tion) in the Ministry, by name, and copies of all of
them should be endorsed to the Head, Department of
Teacher Education, Special Education and Extension
Services, NCERT, also by name. Due dates for
receipt of these reports in the M inistry/NCERT would
be as follows :
MPR : By the 15th of the following month
QPR : Within a month of close of the quarter
being reported on
The above formats are common for D IET and
C TE/IA SE components of the Teacher Education
Scheme. D ata in regard to both components should
be filled up in them and sent together rather than
separately.

—JJI Edu/8?

While reporting expenditure, it should be borne in
mind that mere advance release of certain amounts by
the State Education Department to a construction or
supplier agency (e.g. PWD, Construction Corporation,
Small Industries Corporation, etc.) should not be
treated as ‘expenditure’. An amount should be treated
as ‘expenditure’ for reporting purposes only when it
has actually been spent by the agency concerned in
turn, and corresponding physical progress has taken
place—whether by way of construction, supply of
equipment or otherwise.
7.6 Evaluation
7.6.1 Animal Self-evaluation
As stated in para 3.7.1, the District Board of Educa­
tion will fix specific goals and performance norms—
quantitative as well as qualitative for the DIET, and
the latter will prepare quinquennial and annual insti­
tutional plans to achieve these. Annual plans may be
prepared academic year-wise.
At the end of the academic year, the DIET will
conduct a self-evaluation exercise to determine how far
it succeeded in achieving its norms/targets fixed for the
year. Based on this exercise, it will prepare a self­
evaluation report and submit it to the District Board
of Education, SCERT and SRC. The DBE will
annually review the performance of the DIET on the
basis of this report and will give the Institute such
guidance and directives as it considers appropriate.
The SCERT and SRC will also similarly review the
DIET’S performance in the areas of elementary and
adult education respectively, and convey their advice
and guidance to the DIET.
Besides the above annual review exercise, the DBE,
SCERT and SRC may also obtain periodic reports
regarding progress of its activities vis-a-vis the Annual
Institutional plan.
7.6.2 External Evaluation
Central and State Governments, NCERT and
SCERT may from time to time get performance of
selected number of DIETs evaluated by a competent
external agency with a view to evaluating their strengths
and weaknesses, and taking suitable action to make
them more effective instruments in the achievement of
their mission.

<!-- page 58 -->

<!-- page 59 -->

ANNEXES

<!-- page 60 -->

<!-- page 61 -->

Annex 1
NPE/NLM STRATEGY IN THE AREAS OF
ELEMENTARY AND ADULT EDUCATION,
AND DIETS’ ROLE IN THAT CONTEXT
(for classes I and II) and in minority
languages,
(e) Special attention to children of dis­
advantaged groups in the process of
micro-planning, and
(f) Suitable training of teachers (especially
primary teachers) for integrated edu­
cation of children with motor handicaps
and other mild handicaps, and provision
of special residential schools for seve­
rely handicapped children,

UEE : The Strategy
The strategy for UEE as spelt out in the NPE and
POA, has the following main elements :—
(i) Strengthening and expansion of the system
of early childhood care and education,
(ii) Adoption of a child-centred and
based process of learning at the
stage,

activityprimary

(iii) Provision of primary schools in all habita­
tions with a certain minimum population,

(viii) Laying down of minimum levels of learning
for the primary and upper primary stage and
working towards their universal attainment,

(iv) Universal provision of essential facilities in
primary schools— including at least two all­
weather classrooms, two teachers one of
whom would be a woman, and essential
equipment—under the programme of Opera­
tion Blackboard (O B),

(ix) Continuous and comprehensive learner eva­
luation,
(x) Revision of curricula, textbooks and other
teaching-learning material so as to bring
them in line with the national system of edu­
cation, the national core curriculum and
minimum levels of learning— at the same
time, making them locally relevant,

(v) A large and systematic programme of nonformal education for school drop-outs,
children from habitations without schools,
working children and girls who cannot attend
whole day schools,
(vi) Micro-planning (i.e. local level planning to
ensure that every child in the relevant age
group regularly attends a primary school or
an NFE Centre), and involving the com­
munity in the educational process, especially
in programmes of school improvement,

(xi) Use of educational technology for qualitative
improvement,
(xii) Implementation of a meaningful system for
monitoring progress towards the goals of
UPE/UEE,
(xiii) Reorganisation of the system of planning and
management of education with special refe­
rence to :—
(a) Decentralisation and accountability,
(b) Full involvement of the community
(especially women) and non-govern­
mental organisations (NGOs), and
(c) Promotion of School Complexes,

(vii) Special measures for U PE /U E E among
children of disadvantaged groups (e.g. girls,
Scheduled Castes, Scheduled Tribes, Minorides and handicapped children), which
would include :—
(a) Location of schools/NFE
their habitations,

Centres

in

(b) Provision of incentives like scholarships,
uniforms, books, etc.

(xiv) Strengthening of the teacher education system
and a large programme of in-service and
continuing education of elementary school
teachers and N FE personnel—through
DIETs and school complexes— so that they
are enabled, inter alia, “to meet the thrusts
envisaged” in the NPE.

(c) Supplementary remedical instruction for
as also otherwise special attention to the
needs of first generation learners,
(d) Development of good quality instruc­
tional materials in tribal languages
S3

<!-- page 62 -->

04
Teachers and N FE Instructors will be the persons
who will actually implement the interventions listed at
(ii) and (iv)— (xii) above— wholly in some cases and
substantially in others. Since most of these interven­
tions would be new, teachers/NFE personnel would
need to be adequately trained for them. Besides, there
is the ever-present need for continuing education and
professional renewal of teachers. It is in this context
that DIETs have been envisaged in the NPE— they
would be the institutions which would provide total
training and resource support to elementary school
teachers and N FE personnel to enable them to meet
the above NPE thrusts towards the goal of N U PE/
UEE, and generally to better discharge their changing
professional role.
2. Other important interventions envisaged
NPE, relevant to Elementary Education

in

the

The preceding paragraph lists the components of
the strategy visualized in NPE and POA towards the
universalisation goal. This strategy has planning as
well as academic/scholastic components. Besides
these, the NPE also envisages certain other important
thrusts in the area of elementary education. The key
is to be found in Part II of the Policy document
entitled “The Essence and Role of Education”, whose
relevant portion reads as follows ;—
“2.2 Education has an acculturating role. It
refines sensitivities and perceptions that contribute
to national cohesion, a scientific temper and
independence of mind and spirit—thus furthering
the goals of socialism, secularism and democracy
enshrined in our Constitution”.
Pursuant to the above goal, the NPE also envisages
the following interventions :—
(i) Adoption of a national system of education
with, inter alia, the following features :—
(a) It would be based on the principles
enshrined in the Constitution;
(b) It would ensure availability of education
of comparable quality to all students
upto a given level;
(c) Adoption of a common educational
structure in terms of the length of
various stages of education; and
(d) Adoption of a national curricular frame­
work which would contain a common
core alongwith other components that
are flexible.
(ii) Enrichment of the cultural content of the
curricula and process or education, and

(iii) “Readjustments in the curricula in order to
make education a forceful tool for the culti­
vation of social and moral values”, “values
oriented towards the unity and integration of
our people” and for curbing negative tenden­
cies in our society.
It goes without saying that interventions of the
above kind would also need suitable inputs into ele­
mentary teacher education and training of N FE per­
sonnel. DIETs would be expected to provide this
input at the district level.
3. National Literacy Mission ( NLM)
The NLM objective is to impart functional literacy
to 80 million illiterates in the 15— 35 age group by
1995 of yhom 30 million are to be covered by 1990
arid the remaining 50 million, by 1995. Meaning of
“Functipnal literacy” for purposes of the Mission
has been given in para 1.3.3.
The NLM strategy comprises the
ments :—

following

ele­

(i) Securing people’s participation through me­
dia campaigns, Village Educaion Com­
mittees, Jatthas, and training and develop­
ment of committed youth to function as
literacy personnel/educational activities,
(ii) Increasing
cies,

involvement of voluntary agen­

(iii) Improvement of ongoing programmes, like
Rural Functional Literacy Projects (RFLPs)
and State Adult Education Programme
(SAEP) through measures like improved
supervision, instruction in the local spoken
language, introduction of techno-pedagogi­
cal/inputs, better training of A E personnel,
increased number of women instructors etc.,
(iv) Launching of a mass movement for literacy
involving educational institutions, teachers,
students, youth, defence personnel,
em­
ployers, trade unions, etc.,
(v) Institutionalisation of post-literacy, continu­
ing education especially through establish­
ment of Jana Shikshan Nilayams (JSNs),
(vi) Development of good quality learning mate­
rial, not mearly in the regional languages
but also in widely used dialects, and ensur­
ing their early availability,
(vii) Universalising outreach so as to cover
parts of the country,

all

(viii) Undertaking of Teachnology Demonstration
in 40 districts! with a yiew to extending its
worth-while results throughout the country,

<!-- page 63 -->

55

(ix) Establishment of suitable Mission manage­
ment system at different levels, and
(x) Proper monitoring and evaluation.
The NLM document lays down the mission
management structure at the project, district, State
and national levels. It visualises a District Resource
Unit for Adult/Non-Formal Education (which would
generally be a part of DIETs) as a part of the dis­
trict level structure. The relevant portion of the
document reads as follows :—
"District level
At the district level the District Board of Edu­
cation (DBE) will be responsible for overall
planning and administration of all educational
programmes. District Resource Unit (DRU) as
a part of D IET will provide technical resource
support to the DBEs.
Functions of DBE
—
—

Planning of eradication of illiteracy in
whole district
spatial allocation of responsibility among

—
—

the various agencies implementing the pro­
gramme
Overall guidance to DRU
Ensuring coordination of all programmes of!
adult education undertaken bv different
agencies

Functions of DRU
—
—

Provide technical assistance to DBE
Train AE and NFE functionaries at the
district level
— Orient the functionaries of development de­
partments and other concerned agencies
— Material preparation for basic and post­
literacy programmes
—■ Mobilize media support
— Evaluation”
Thus the DIET/DRU occupies an important place
in the NLM strategy as well. However, as discussed
in Chapter 2, the approach in regard to DRU being
a part of the DIET will be flexible.

<!-- page 64 -->

Annex. 2
(1) NPE AND POA ON TEACHER EDUCATION/
DIETs.
(2) CENTRAL SPONSORED SCHEME OF TEA-.
CHER EDUCATION.
1. NPE and POA on Teacher Education /D IETs
1.1 National Policy on Education, 1986 (NPE)
On the subject of Teacher Education,
states as follows :—

the* N PE

“TEACH ER EDUCATION
9.4 Teacher Education is a continuous pro­
cess, and its pre-service and in-service compo­
nents are inseparable. As the first step, the sys­
tem of teacher education will be overhauled.
9.5 The new programmes of teacher educa­
tion will emphasize continuing education and *be
need for teachers to meet the thrusts envisaged
in this Policy.
9.6 District Institutes of Education and Train­
ing (D IET) will be established with the capabi­
lity to organise pre-service and in-service courses
for elementary school teachers and for the per­
sonnel working in non-formal and adult educa­
tion. As DIETs get established, sub-standard
institutions will be phased out. Selected Secon­
dary Teacher Training Colleges will be upgrad­
ed to complement the work of State Councils
of Educational Research and Training. The Na­
tional Council of Teacher Education will be pro­
vided the necessary resources and capability to
accredit institutions of teacher education and
provide guidance
regarding
curricula and
methods.
Networking arrangements will be
created between institutions of teacher education
and university departments of education.”
1.2 Programme of Action ( POA)
Chapter X X III [“Teachers and their Training”] of
the Programme of Action (PAO) prepared to im­
plement the NPE has this to say on the subject of
Elementary Teacher Education and DIETs :—
“ 16. Keeping in view the central place of
teacher education, NPE calls for its overhaul as
the first step towards educational reorganisation.
Giving particular importance to the training of
elementary school teachers, it is envisaged that

selected institutions would be developed as Dis­
trict Institutes o{ Education and Training
(D IET) both for pre-service and in-service
courses of elementary school teachers and for
continued education of the personnel working in
non-formal and adult education programme” .
Paras 18 and 20 of-the above Chapter
“functions of a DIET” would indude :—
—
—

—

—

—
—
—

—
—

say

that
_

Pre-service and in-service education of
teacher for the formal school system.
Induction level and continuing education of
Non-formal and Adult Education Instruc­
tors and Supervisors.
Training and orientation of heads of insti­
tutions in institutional planning and managemen and micro-level planning.
Orientation of community leaders, func­
tionaries of voluntary organisations and
other influencing school level education.
Academic support to school complexes and
District Boards of Education.
Action research and experimentation work.
Serving as evaluation centre for primary and
upper primary schools as well as Non-Formal and Adult Education Programme.
Provision of services/ of a resource and
learning, centre for teachers and instructors.
Consultancy and advice, for example to
DBE’s.

2. The Centrally
Education

Sponsored

Scheme

of

Teacher

In pursuance of the statements contained in the
NPE and POA on the subject of teacher education, a
Centrally Sponsored Scheme of Restructuring and
Reorganisation of Teacher Education has been taken
up during the Seventh Plan period, with the follow­
ing five components :—
0 ) Mass orientation ofi about five lakh school
teachers annually to make them aware of
their role in the context of the new PoUcV

<!-- page 65 -->

5/

thrusts, and to improve their professional
competence,
(ii) Setting up of about 400 DIETs,
(iii) Strengthening of about 250 Secondary
Teacher Education Institutions (STEIs)—>
about 50 of them as Institutions of
Advanced Study in Education (IASEs) and
the remaining 200 as Colleges of Teacher
Education (C TEs),
(iv) Strengthening of SCERTs, and
(v) Establishment and strengthening of Univer­
sity Departments of Education through the
UGC.
The programme of Mass Orientation of School
Teachers (MOST) was commenced immediately after
adoption of the N PE in May, 1986. About 13.5
lakh teachers were covered under it during the three
years— 1986, 1987 and 1988. The 1989 round had
also been completed in most States by September,
1989. An important feature of this round was that
for primary teachers working in blocks covered under
OB, a special programme was implemented in this
round, geared towards child-centred education and
use of materials supplied to primary schools under
OB.

9 —551 Edu/89

Government of India approved the remaining four
components of the Scheme in October, 1987. Draft
Guidelines for implementing the component of DIETs
were got prepared through the Educational Consul­
tants India Limited (Ed. Cil), and were circulated to
all States and Union Territories in October, 1987.
These, together with certain supplementary guidelines
circulated later, have formed the basis for implemen­
tation of the DIET programme so far. During 1987­
88 and 1988-89, first instalment of Central assistance
for non-recurring items was sanctioned for 101 and
114 DIETs respectively. During 1989-90, upto Sep­
tember, 1989, this had been sanctioned for one
more DIET. Thus, upto September, 1989, Central
assistance had been sanctioned under the Teacher
Education Scheme for setting up a total of 216 DIETs
in the country.
Under the third component of the Scheme, Draft
Guidelines were got prepared again through Ed. CIL
and circulated in December, 1987. Till September,
1989, first instalment of Central assistance had been
sanctioned for setting up 22 CTEs and 10 IASEs
(total 32).
Implementation of the last two components of the
Scheme is expected to commence later.

<!-- page 66 -->

Annex 3
RESUME O F IMPLEMENTATION OF
IMPORTANT INITIATIVES IN ELEMENTARY
AND ADULT EDUCATION
material in local languages. The scheme
covered about 6000 Elementary Schools in
17 States and 2 UTs of the country as on
31-3-89.

I. Elementary Education
Apart from DIETs, the following major centrally
assisted schemes were launched during the V II Plan
period, pursuant to the NPE, in the Elementary Edu­
cation sector :—

6. Environmental Orientation to School Educa­
tion—The Scheme includes revision of
curricula to make it locale-specific, prepara­
tion of corresponding instructional material
and orientation of teachers, etc. 25 projects
had been sanctioned under the scheme upto
the end of 1988-89 in 13 States and 2 UTs.
The area covered by a project varies from
a group of districts to a group of blocks.

1. Operation Black Board— The scheme has
been briefly described in para 1.2.4. It started
in 1987-88, and central assistance had been
sanctioned upto 31-3-89 for covering roughly
48% of the total Primary Schools in the
country.
2. Non-Formal Education— Though the Scheme
had started in the VI Plan period, it was
revised and enlarged in 1987-88. Approxi­
mately 2.41 lakhs NFE Centres were running
in 13 States and 2 UTs, at the end of 1988­
80. Of these centres, 2.20 lakh were being
run by State Governments and 0.21 lakh by
NGOs.

The above Scheme will generally continue
in the VIII Plan, with modifications, wherever
necessary. Besides, a number of other initia­
tives are ailso likely to begin iii the V III
Plan— for example, in the airea of micro­
planning.
II. Adult Education

3. Educational Technology— It
aims, inter
alia, at supply of colour TV sets (CTVs) to
1 lakh Primary Schools (and Upper Primary
Schools with Primary Sections) and radiocum-cassette players (RCPs) to all Primary
Schools of the country. Upto 31-3-89. cen­
tral assistance had been sanctioned for supply
of CTVs and RCPs to about 22,000 and
1,05,000 schools respectively.

In the area of Adult Education, NLM is a compre­
hensive mission which includes ongoing programmes
as well as several new initiatives. Following were
some of its important achievements at the end of
1988-89 :—
(i) National
Literacy
Mission
Authority
(NLMA) was set up at the Central level,
and State Literacy Mission Authorities
(SLMAs) were set up in 17 States/UTs.

4. Improvement of Science Education—Tn Upper
Primary, Secondary and Higher Secondary
Schools. In regard to Upper Primary Schools,
the School Scheme envisages provision of
Integrated Science Kits (ISKs) to all Govern­
ment and Government-aided Schools, and
training of their teachers. Till 31-3-89,
Central assistance had been sanctioned for
supply of ISKs to about 35,000 upper prima-ry
schools.

(ii) Financial pattern under the Schemes of
Rural Functional Literacy Projects (RFLPs)
and Strengthening of State/District level
administartive
structures
was
revised.
Revised pattern for better academic and
technical resource support was adopted by
all SRCs.
(iii) About 90 lakh adults were enrolled in 2.91
lakh AE Centres across the country.

5. Integrated Education of Disabled Children—
This Scheme includes training of general
teachers, heads of institutions and administra­
tors, and production o f t a b l e instructional

(iv) Several special campaigns/pilot project
launched for total illiteracy eradication in
specific areas,
58

<!-- page 67 -->

5^

(v) 21,058 Jana Shikshan Nilayams (JSNs)
sanctioned to provide facilities of post­
literacy and continuing education. Suit­
able titles being developed for supply to
JSNs.

The Mission will also be further strengthened
the VIII Plan.

(vi) Key techno-pedagogic inputs (e.g. im­
proved plastic blackboards, solar power
packs, chalks, slates, etc.) being developed
through collaborating agencies. Rapid liter­

DIETs will have to provide training, resource and
action research support in the implementation of all
the above Scheme/initiatives/mission, at the district
level.

acy learning technique developed, and going
into try-out phase.
in

<!-- page 68 -->

Annex 4
NORMS FO R A DIET TO Bfe SET UP IN A DISTRICT WHICH SATISFIES CRITERIA
GIVEN IN PARA 2:6:1
PART 1: STAFFING PATTERN WITH SUGGESTED ORGANISATIONAL STRUCTURE
Principal—1
Steno to Principal—1
Number of posts

Branch/Unit/Section

1. PSTE
2. WE
•
•
3. DRU for AE/NFE
4. IFIC
•
5. CMDE
•
6. ET
•
7. P&M
•
8. Library
•
9. Admn. Section

.
.

•

.
.

•
•

.
,
■
..

.

Class IV

Total

1. Lab. Asstt.
—
2 (1 Stenotypiit.
1 clerk)
1 Clerk
—
—
—
1 Clerk
1 Accountant
5 Clerks (including
one fon tosteY)

—
—
—

10
3
7

—
—
—
—
—
6

3
2
3
3
2
13

11

6
46
+1 Principal
1 Steno

Lecturers

Statistician/
OS/Librarian/
Technician/
WE Teacher

Accountant/
Clerks/Lab. Asstt.

1
1
1

8
1
4

—
WE Teacher
—

. 1
. 1
.
1
. 1
. —
. —

1
1
1
1
—
—

—
—
1 Technician
1 Statistician
1 Librarian
1 OS

ViceP.'incipal/
Sr.
Lecturer
.
.

17

1 Vict-PPL
6 Lecturers

Total 48
Note

1. For further details of the above structuie, please sec section 2.4
2. In addition to the above full-time posts :
(a) consultants resource persons may be engaged for upto 50 man months in a year, i maximum of Rs. 300 per man month.
(b) a part-time Medical Officer will be engaged for the clinic
PART 2 :

PHYSICAL FACILITIES

1. Campus Area : Preferably 10 acres
2. Buildings: (i) Institute Building—A building having at least accommodation indicated under Priority I in Annex, 11. Approx.
Carpet Area 10,000 sq. ft.
(ii) Hostels—Separate hostels for men and women with total capacity of 150*200 seats.
(iii) Staff Quarters—At least five -for the Principal, two faculty members (on* or both of whom would serve as hostel
warden) and two class IV employees.
3. Library and Reading Room:
(i) Library:
With about 10,000 books (in various subjects listed in Annex, 15)
(ii) Reading Room: Subscribing to at least ten professional journals besides a suitable number of general periodicals, and news*
papers.

4.
Furniture, Equipment andMaterials
following :

for

the

(i) Science Labs.
(ii) Psychology, Social Studies and Languages
(iii) Work Experience

(iv) Education in Visual and Performing Arts
(v) Physical Education and Sports
(vi) Education of the Handicapped
(vii) Adult and Non-formal Education
(viii) Classrooms, Staff Rooms and Office

<!-- page 69 -->

6i
(ix) Hostel
(x) Educational Technology (including 2 colour
TV sets, 1 VCR, 2 Overhead Projectors
with Screen, One manual Slide Projector,
three Audio Cassette Players, one Two-inone, Public Address System, and video/
audio cassettes. Desirable items would be
a 16 mm Film Projector with a collection
of 16 mm films, and an Epidiascope)
(xi) Computer Lab. (consisting mainly of 3 PCs
XT and 2 PCs with peripherals and One
Dot Matrix Printer)
(xii) An Intercom System for the Institute, and
Two Telephones.
For full details of suggested books and
equipment, please see lists circulated by
NCERT in August, 1988 and February,
1989.
PART 3 : PROGRAMMES
A. Per-service Teacher Education Course :
Anuual Intake :30—50 (in case of a two-year
course)
60—100 (in case of a one-year
course)
B. Other training/orientation programmes, workshops, ctc.
(i) ‘Main, Programmes for
About 12- 14 in a year,
elementary teachers (about 3 with an intake of 40—45
weeks’ duration)
per programme
(ii) Shorter programmes for
Elementary Teachers

Suitable number

(iii) Programmes for Head Masters, Heads of School Com­
plexes and Block level
officers

Suitable number

(iv) Induction and Refresher
Programmes for AE/NFE
personnel

,,

(v) Programmes for Resource
Persons who would conduct training programmes
for teachers and AE/NFE
personnel, elsewhere

,,

(vi) Orientation programmes
for members of DBE/
VECs, community lea­
ders, youth, etc.

,,

(vii) Workshops for development of curricular units,
teaching learning material,
tests and evaluation tools,
teaching aids, etc.

,,

(viii) Meetings, conferences,
seminars, etc.

,,

C. Field Interaction (incl. Extension)
Activities
(i) Publications :
■Newsletter

-Q u arterly

Institute Journal—Annually to begin with.
Frequency may be increased
to half-yearly in course of
time.
(ii) Other Field Interaction activities as indicated in
Chapter 3.
D. Field Studies/Action
Research/Experimentation
indicated in Chapter 3.

as

<!-- page 70 -->

Annex 5
SOME SUGGESTIONS REGARDING TRANSACTION METHODOLOGY
FOR TH E PRE-SERVICE TEACHER EDUCATION COURSE
(c) Formulation of problems and tasks by the
student teachers can also be conceived as a
strategy for curriculum transaction.

(a) Discussions, symposia, group work, projects,
investigations, etc. are the methods and
techniques recommended in connection with
activity based teaching. It will be in the
fitness of things if the DIET faculty make
adequate use of these methods in their
teaching.

(d) Provision of practical experience is very
supportive to learning. For example, the
student teachers taking up Adult or NonFormal Education may be required to visit
and work in such centres, and those taking
up Guidance and Counselling may work
with students having some adjustment pro­
blems.

(b) Investigatory projects and activities can
prove very useful in teaching. These are
likely to lead to the development of research
skills, attainment of concepts and develop­
ment of attitudinal make-up. Preparation
of case studies, administration and inter­
pretation of psychological tests, field sur­
veys, interview with drop-outs, delinquents,
truants, backward children, etc., collection
of additional materials related to the pres­
cribed courses from newspapers and
journals, are a few examples of such pro­
jects.

(e) The student teachers may be required to
practise teaching in simulated conditions,
viz., before their classmates or before their
teacher educator. They may also be re­
quired to attempt a few micro-lessons with
a view to practising some important skills
of training. Immediate feedback helps the
trainee to modify his teaching behaviour.

62

<!-- page 71 -->

Annex 4
NORMS FOR A DIET TO BE SET UP iN A DISTRICT WHICH SATISFIES CRITERIA
GIVEN IN PARA 2:6:1
PART 1: STAFFING PATTERN WITH SUGGESTED ORGANISATIONAL STRUCTURE
Principal—1
Steno to Principal—1
Number of posts

Branch/Unit/Section
ViceP.-incipal/
Sr.
Lecturer

Lacturers

Statistician/
OS/Librarian/
Technician/

•
•
■
•

8. Library

.

Class IV

Total

WE Teacher
1. Lab. Aastt.

1. PSTE
•
2. WE
•
3. DRU for AE/NFE
4. IFIC
5. CMDE
6. ET
7. P&M

Accountant/
Clerks/Lab. Asstt.

10

WE Teacher

3
7

2 (1 Stenotypiit.
1 clerk)
1 Clerk

3
2

1 Technician
1 Statistician
1 Librarian
1 OS

9. Admn. Section

1 Vict-PPL
6 Lecturers

17

5

3
3
1 Clerk
1 Accountant
5 Clerks (including
on# ton
11

2

6

13

6

46

+1 Principal
1 Steno

Total 48
Note : 1. For further details of the above structute, please sec section 2.4
2. In addition to the above full-time posts :
(a) consultants resource persons may be engaged for upto 50 man months in a year, @ maximum of Rs. 300 per man month.
(b) a part-time Medical Officer will be engaged for the clinic
PART 2 :

PHYSICAL FACILITIES

1. Campus Area : Preferably 10 acres
2. Buildings: (i) Institute Building—A building having at least accommodation indicated under Priority I in Annex. 11. Approx.
Carpet Area 10,000 sq. ft.
(ii) Hostels—Separate hostels for men and women with total capacity of 150*200 seats.
(i ii) Staff Quarters—At least five-for the Principal, two faculty members (on* or both of wliom would serve as hostel
warden) and two class IV employees.
3. Library and Reading Room:
(i) Library:

With about 10,000 books (in various subjects listed in Annex, 15)

(ii) Reading Room:
papers.

Subscribing to at least ten professional journals besides a suitable number of general periodicals, and news*

4.
Furniture, Equipment and
following :

Materials

for the

(iv) Education in Visual and Performing Arts
(v) Physical Education and Sports

(i) Scicnce Labs.
(ii) Psychology, Social Studies and Languages
(iii) Work Experience

(vi) Education of the Handicapped
(vii) Adult and Non-formal Education
(viii) Classrooms, Staff Rooms and Office
<*)

<!-- page 72 -->

Annex 6

EXTRACTS FROM CHAPTER VIII (“THE CASE
FOR INSERVICE EDUCATION” ) OF THE
REPORT OF THE NATIONAL COMMISSION QN
TEACHERS— I, SUBMITTED IN MARCH, 19£5

Need for In-service
8.01 While the case for a radical improvement of
the quality of pre-service education of teachers has
been dealt with so far and cannot be denied its
importance, that of providing for a continual and
comprehensive programme of in-service education
cannot be emphasised enough. With the explosion
in knowledge, the revolution in the world of the
media, with contemporary issues demanding urgent
attention with values getting eroded, the need for
helping teachers to keep abreast of things cannot be
questioned.
8.02 As early as 1949 the University Education
Commission stressed the urgent need for the institu­
tion of inservice courses and observed : “It is extra­
ordinary that our school teachers learn whatever
subject they teachj before reaching the age of 24 or
25 and that their further education is left to experience,
which in most cases, is another name for stagnation.
We must realise that experience needs to be supple­
mented by experiment before reaching its fullness and
that a teacher to keep alive and fresh should become
a learner from time to time”. This view has been
further supported by the commissions that have
followed. Yet we are constrained to observe that we
have not made significant progress in mounting a
comprehensive programme during the last three
decades.
❖
*
*
*
*
The Magnitude of the Problem
8.08
In order to plan ahead and develop a com­
prehensive strategy the magnitude of the problem of
Inservice Education of Teachers (INSET) has to be
appreciated. According to figures available for 1981­
82, the number of teachers working at the different
stages were as follows :—
Primary
Middle
Secondary
Hr. Secondary
Hr. Secondary
(old scheme)

:
:
:
:

13,65,431
8,46,772
6,76,437
1,98,778

;

66,400

The total teacher force, therefore, amounts to a little
more than above 3 million. It is unfortunate that
their continual further Iearing and upgradation has not
become part of the work ethos of the teaching profes­
sion. We have not made it obligatory for every
teacher to undergo inservice training as part of his pro­
fessional growth. The SIEs and SCERTs which are
the main agents at the State level find the resources
available to them very limited for this purpose.
Present Inadequacies
8.09 There is today an absence of clear cut policies
and priorities for inservice education. There has been
no systematic identification of needs. The content and
quality of programmes offered are generally poor.
Strategies for training are vague and half-hearted. Not
much emphasis appears to have been placed on solv­
ing the practical problems of teachers or meeting their
educational needs. Inservice courses rarely result in
the development of a corpus of instructional material
that can be used by participants and other teachers.
Hardly any use is made of new media and technolo­
gies. Administrative support for innovations is lack­
ing as headmasters and superiors are not often involved
in programmes where teachers are being trained in the
use of new methodologies. The phenomenon of rou­
tine transfers finds trained personnel not placed in
positions where they should use their training maxi­
mally. There is, therefore urgent need for a thorough
overhaul of inservice education must be given top
priority. Its quantitative expansion must be plan­
ned most carefully. No good programmes should
suffer for lack of funds.
The New Thrusts
8.10 What should be the new thrusts? How do we
go about his enormous task? These are the questions
that we must address ourselves to.
Identification of Needs
8.11 In the first place, the needs of teachers have to
be identified at institutional and other levels and such
inservice education arranged as will directly meet

<!-- page 73 -->

64

those needs. They may have to be remedial in nature,
as for example, updating the teacher’s knowledge in
physics or geography; they may suggest new ways of
dealing with classroom problems, as for example, deal­
ing with multiple levels of attainment in a class or us­
ing a new media like the television; or they may have
to sensitize the teacher to new areas impinging upon
modem life, as for example, population explosion, en­
vironmental hazards, deforestation, alternate source of
energy, proliferation of nuclear weapons and so on.
Identification of teachers’ needs and meeting them
directly is of the first importance. For this the
SCERTs/SIEs at State levels and the RCEs and the
NCERT/N IEPA at the Centre should evolve a mechansim by which their feed-back from the school and
the training institute and college is constantly made
available. The SCERTs may initiate News Letters
announcing areas of inservice they would be taking
up during one academic term and inviting suggestions
from institutions for further needs. It should be the
function of the school Inspector to enquire into the
inservice education availed of by each teacher, reasons
for not availing of any and to insist on the continual
education of the teacher being part of his service con­
ditions.
Planning ahead of time
8.12 Programmes should be planned thoroughly
well ahead of time. We tend to be careless and slip­
shod in whatever we do. To be thorough and meticu­
lous in planning for a course being attended by a group
of teachers is to show them the respect and conside­
ration that is due to them. Papers have to be prepared
by resource persons well ahead of time, reading lists
and other materials mailed to participants before the
course to stimulate thinking. Every detail should be
attended to so that the teacher comes well prepared
with the proper mind-set to benefit by the course, short
or long. Conference and workshops should be busi­
ness like and the tone has to be set from the first hour
eschewing all fan fare.
8.13 One practice follriwd by the Kendriya Vidyalaya Sangathan in the organisation of their summer
training courses for teachers of all categories has come
to our notice as worthy of consideration. In the first
place the directors and resource persons of each
course are selected very carefully on the strength of
their academic and professional competence, organisa­
tional and communicational skills. These resource
persons are provided an opportunity to meet together
for a planning session of not less than 3 days well be­
fore the beginning of the course. At this session the
objectives, the course content and methodologies are
worked out in detail with help from experts of the
NCERT and other concerned agencies.

Choice of Resource Persons
8.14 The choice of resource persons is important.
Expertise and proven skills alone should matter. The
systems should be flexible enough to allow the co­
operation of experts from various field outside educ­
ation like industry, agriculture, science, technology,
management and the like. Media specialists have a
particularly important role to play today. Also uni­
versity professors, educational experts, outstanding tea­
cher educators and teachers should be maximally uti­
lised as resource persons. From our dialogues with
teachers in the country we are convinced that we have
everywhere many dedicated teachers with excellent
records of service. Their co-operation in conducting
inservice programmes should be welcomed for they can
give the much-needed practical wisdom in bringing
about change.
Changes in Methodologies
8.15 Methodologies adopted for inservice education
call for closer scrutiny. The resource persons selec­
ted should meet prior to the actual course as sugges­
ted at 8.09 above and plan the details most thoroughly.
Every course should be in the nature of a workshop
demanding hard work and include the preparation of
instructional and other material that can be used by
the teacher when he goes back to school. No inser­
vice course should be of such a general nature that
teachers feel it is a waste of their time and energies.
Practices that have been successful should be shared
and class room methodologies that have failed discus­
sed. Attention should be given to solving the teachers’
problems satisfactorily. New ideas from other count­
ries could b evaluated and an openness of mind en­
couraged. The quality of inservice courses should be
such as will themselves generate sustained interest for
further improvement in the teachers’ work.
Use of Educational Technology
8.16 The use of educational technology in a big
,way could revolutionise inservice courses. The days’
of lengthy lectures and note-taking thereon are over.
With the boom in audio-visual media it should now
be possible to use a wide range of educational techno­
logy. A multi-media approach is useful. Teachers’
interest could be eyoked more purposefully by the
use of audio and video cassettes on any subjects. The
visual in particular makes a deep education : radio
and television, film strips and the epidiascope; taperecorder, audio and video-cassettes; the overhead pro­
jector and the 8 mm. or 16 mm. film projector; the
computer. The times demand of an educated person
a modicum of literacy in the technical field, in the use
of his hands and the tools of technology. In these

<!-- page 74 -->

A 6 - S T E P MODEL FOR INSERVICE
EDUCATION

2

3

Selection of
Problem / Problem
Area

Course
Preparation

6

5

4

1. Choice of problem/problem area can Involve field survey, study of
literature, consultation, group discussion, etc.
2. Necessary for evaluation.
3. Success of the programme will depend greatly on the suitability
of the course Faculty.
'
4. Will involve among other things : (») definition of goals/objectives
related to 2; (ii) definition of tasks/activities to be arranged; and
(iii) choice of methodology Including preparation of instructional
materials.
5. Will involve the preparation of the course programme and daily
time table.
6, Can involve use of questionnaires, interviews and other tools
relevant to assessing .the relevance and effectiveness of the course.

Fig. 4
Edu/89

65

<!-- page 75 -->

66

courses teachers must get acquainted with the hard­
ware, their servicing and maintenance. These are es­
sential skills to be learnt by every teacher and teacher
educator and should not be overlooked. In organis­
ing courses with the use of media, resource persons
in charge of a course should draw in media men and
other entrepreneurs now available in many cities who
would be only too happy to help.
Preparing Software
8.17 We are of the view that in the next couple of
plans priority must be given to the production of indi­
genous software in addition to the acquisition and
installation of hardware in the school system. The
dangers involved in supporting software from abroad
are too obvious to merit any detailed discussion. It
should be our objective to develop 'software suitable
for rural audience and capable of conveying relevant
education including science and capable of promoting
a scientific temper in the society. It should also be
our objective to revolutionise classroom methodologies
by increased use of educational technology and multi­
media including audio video cassettes etc. in the school
system. Teachers must, therefore, be involved in the
preparation of software and the work as part of a
team. For example, it 19 time we prepare film/videos
of classroop methodologies used by our most talent­
ed teachers right in the Indian Society by making au­
diovisuals of their actual lessons. Also software pro­
duction would be supported considerably in quality if
due note is taken of research findings. For example,
in one project conducted by the Homi Bhabha Centre
for Science Education to improve scholastic achieve­
ment of Scheduled Caste students, trivial obstacles in
language visualisation and in understanding the rules
of the game prevent concept formation. It was also
found that once these difficulties were identified, very
inexpensive remedial measures could be generated and
that the programme led to a substantial improvement
of their scholastic performance. In yet another pro­
ject in non-formal education for school drop-outs it
was found that science could be imparted even before
the acquisition of literacy and that the natural inte­
rest of the pupils in S & T could in fact be used to
motivate them to acquire and retain literacy.
8.18 Commendable experience in the preparation
of local specific materials and in developing other pro­
grammes of local relevance for adults, women and
children are reported from several groups of people
exploring new avenues for a breakthrough. But suffi­
cient pooled information is not available about the
useful work being done by such groups. We feel it
vould be worthwhile finding ways and means of learn­
ing from this type of field experence also.

Evaluation and Follow-up
8.19 The evaluation and follow-up of inservice
courses is absolutely necessary and should be integral
to the course. The evaluation of the success of a pro­
gramme undertaken by teachers must be done towards
the end of the course in a frank and free atmosphere
without fear or favour. The mere use of check lists
and questionnaires is of limited value unless properly
analysed and used for feedback.
8.20 We recommend that attendance at an inser­
vice training course be made mandatory for every
teacher alteast once in five years. In the USA, tea­
chers, we understand, are required, to complete cer­
tain formal courses in order to move to higher scales
of pay. In the USSR teachers are required to attend
a course related to their work one day per week for
one full year after three years of service and there­
after every five years.
❖

❖

*

$

*

Other Strategies
School Strategies
8.22 In-service strategies must be imaginative, bold
and varied. Workshops, seminars and training courses
belong to one type of approach. There are others.

8.23 The most effective among them are the ser­
vices organised through the school complex. The idea
of the school complex was originally put forward by]
the Kothari Commission 1964— 66. The intention is]
to link the primary and secondary schools with a view]
to pooling resources and improving the educational]
process. The experience gained in Bihar, Tamil Nadu,]
Haryana, Rajasthan and Maharashtra are reported to]
be very happy,
’
8.24 Noteworthy of mention is the rapport-based
programme of school improvement initiated in the
year 1977-78 in Maharashtra. First it was introduc­
ed on a small scale in complexes of 9 schools includ­
ing one rural secondary schools in Char Holi, a vil­
lage 20 km. from Pune. A t present the programme
has extended to 1800 school complexes.
8.25 A seven-point strategy of school improve­
ment is reported : (i) grading of the school (ii) pre­
paration (iii) implementation of institutional plans
(iv) enlisting community cooperation for school im­
provement (v) encouraging teachers to do self­
evaluation (vi) establishing rapport among school
teachers, staff, pupils, local leaders and the con*
munity (vii) periodically evaluating the performance
of the complexes. The Headmaster of a school grade!
his own school on the scale A to E using a tooi
prepared by the SIE. This is to identify deficienciei
and set the priorities for improvement. Out of 180(

<!-- page 76 -->

67

complexes 1200 had been adopted by one or the other
of the officers of the Education Department including
the Director of Education. Some tangible achieve­
ments they have had are : marked increase in enrol­
ment particularly at the age of 6+, in average attend­
ance, in transfer rate, S.S.C. result institutional
planning,
home
assignment, self-evaluation by
‘cachers.
8.26 We have dwelt upon this experience at some
length because the development in a big way of
school complexes is likely to yield tangible results at
the grass-root levels. The requisites are : (i) full
support of the administration, (ii) detailed planning
by Headmasters and Teachers, (iii) enlisting cooosration from the community.
Teachers’ Centres
8.27 An experiment with the establishment of
Teachers’ Centres has been tried successfully, it is
reported, in Delhi and other metropolitan towns. A
Teachers’ Centre is a meeting place for teachers
located in a school that has resources that it would
like to share with others. At the centre, teachers
may meet when free in the evenings or during week­
ends to borrow books, to prepare teaching aids, in­
dividually or in groups or to borrow some new
materials for teaching. It is a forum where work­
shops of very practical nature are organised for
teachers of all faculties and of all levels ; it pools in
the talent of all teachers of various schools who act
as recource personnel for the centre’s workshops
and it arranges book fairs where publishers would
exhibit their latest publications for sale. Since the
entire initiative at the centre rests with the heads
and teachers themselves, this is a move to be
welcomed.
A Project on Single Teacher Schools
8.28 In Gujarat, in order to help 7000 single
teacher schools, a three-phased project was taken
up. In the first phase a survey was taken up to in­
vestigate the specific problems of single teacher
school along with on tlie spot study. In second
phase those teachers were oriented for multiple class
teaching and a schedule was prepared and published
to help them. In third phase, in order to help the
teachers and students, auto-instructional program­
mes in arithmetic and language were prepared by
S.I.E, and ten copies of programme were given to
each school. It was felt that programmed learning
method really helps these teachers in occupying the
children of other classes in study while the teacher
teaches students of any one particular class.

School Level IN SA T Programmes
8.29 Another mode of inservice education for
teachers is the one that can be held at the institutional
level. The whole staff of a school plans its inservice
training after identifying its needs, drafting resource
persons from within and outside the school and after
preparing the necessary materials. Such orientation
held voluntarily by the staff on Saturdays as is being
tried with success in some private-managed schools,
or during week-ends or vacations and at the com­
mencement of school terms has much to commend
itself for it is need-based, has sufficient motivation
and can be evaluated continually Needless to say it
requires a committed kind of leadership on the part
of the head and a congenial atmosphere of freedom
of discussion in the school to enable it to become an
ongoing programme.
Use of Mobile Units
8.30 Experience in Nepal and some other Asian
countries point to the efficacy of using mobile units
of inservice education for making regular visits to
rural and remote areas. It is always not possible
for rural teachers to avail of inservice programmes
held in cities or small suburban areas because of the
distance and also because rural schools can hardly
spare teachers during term-time being highly under­
staffed. Besides, these expriences have local relevance
when conducted in the locality. These mobile
vans are well equipped with teaching aids and other
instructional materials. The resource persons would
be expected to help rural teachers solve specific prob­
lems, develop low cost educational aids with locally
available resources, help teachers learn the use of
radio sets or audio cassettes operated on battery, if
electricity is not available. The effort should be to
reach remote areas of the country.
Correspondence Courses
8.31 The continuing education of teachers and
teacher educators can also benefit enormously by a
fuller and more intensive use of distance education
techniques.
Correspondence-cum-contact
courses
could gradually become part of the system for in­
service education. Need based correspondence lessons
with provision for regular feed back could be taken
by teachers who are earnest about upgrading them­
selves and may lead to certificates or diplomas. They
could relate to a discussion of the special needs of
the primary child and, at the other end, of the ado­
lescent, or offer advanced courses in the content of
a subject like mathematics or history etc.; or open
up new vistas for teachers in areas of current re­
levance like the special problems of women and

<!-- page 77 -->

68

children who are out of school, of backward classes
and tribal areas or of the handicapped or gifted.
Well-defined correspondence lessons could supple­
ment the work of other inservice courses.
Experience with Media
8.32 The Radio : Mention should be made of the
experiences of the Centre for Educational Tchnologv
of the NCERT with the assistance of the Govern­
ment of Rajasthan in conducting a series of radio
programmes for primary school children in Rajasthan
in the learning of the mother tongue (Hindis
during 1975-76. The radio was used for the im­
provement of listening skills and for language deve
lopment, specially the enhancement of vocabulary.
The programme covered 500 schools from 15
Panchayat Samitis from 2 districts. The radio pro­
grammes were supplemented by specially prepared
materials for teaching, reading and writing. In the
training programme teachers were given a thorough
grounding in the use of the media.This was a
first
effort but is reported to point out the very valuable
contribution the radio cau make in enriching learn­
ing at school and should be, we feel, exploited fully
because of its added advantages. Existing transmis­
sion facilities for tadio broadcasting cover almost
90% of the geographical area of the country
and
95% of the population.
9.33 A report from Tamil Nadu indicates the suc­
cessful use of a
correspondence-cum-broadcast
course for Tamil teachers. Realising the need for
developing among teachers habits of correct speech
and writing the SCERT launched upon
such a
course for Tamil teachers handling several classes.
This has been done in collaboration with the
Central Institute of Indian Languages. Mysore, and
the All-India Radio, Madras. In 1983-84, about
15,000 teachers of standard VII were covered.
8.34 We understand that
district-level inservict*
centres are being set up by the Central Institute of
English and Foreign Languages in collaboration with
State Governments for the improvement of standards
of English. Since one of the main problems is likelv
to be the harnessing of competent staff for running
these courses, the use of broadcasting and other
media including video-audio cassettes
could be
explored.
The Television
8.35 We learn from discussion with educators and
media experts that a fund of experience has been
gained from the SITE programme (Satellite Televi­
sion Experiment Programme) of 1975-76 through

which TV programmes were conducted with the help
of ATS-6.
Through this,
children in village
primary schools received 2 2 i minutes program­
me on each school day. The programmes were
planned for the entire primary school i.e. children of
classes 1-5 covering 2400 villages in Madhya
Pradesh, Bihar,
Andhra Pradesh,
Orissa and
Rajasthan. Approximately 50% of the programmes
were produced in the specially set up Base Produc­
tion Centres in Delhi, Cuttack and Hyderabad in
Hindi, Oriya and Telugu. Another 50% were science
programmes produced by ISRO. TEeT software thus
developed were relayed through the Space Appli­
cation Centre, Ahmedabad. Some 50,000 primary
school teachers were trained through SITE pro­
grammes on how to teach science using multi-media.

8.36
The second major experience in the wid
use of technology is that of INSAT 1 which covers
the entire country now. Their programmes were
produced in Delhi but can be picked up anywhere in
the country where there are T.V. relay stations.
Among the insights reported to have been gained
through these two programmes are the following:—■
(i) Programmes for children are the toughest
to prepare. They have to be both areaspecific and audience-specific. For the pre­
school of ages 3-6 we need to portray
programmes that bring them a lot of fun
and joy through games, local folk tales, j
local puppets, rhymes etc. Programme j
about the culture of the environment co j
well. They can be used for creating general j
awareness regarding health,
sanitation,
customs, folk culture,
superstitions and
the advent of
scientific thinking Ex­
perience from Orissa has shown increase in
retention capacity at school on account of
media usage.
(ii) Experience has also indicated the need for
a team approach to software preparation.
To ensure effectiveness the team should
comprise a media specialist, a
subject
specialist who may be a teacher, a social
scientist and an engineer/technician where
needed.
(iii) It has also been noticed that it is far better to
train the local teacher/or the animator
who is often the village dropout and given
him the maximum help to improve his con­
fidence than to bring in people from the
outside who are not familiar with the
place.

<!-- page 78 -->

69

8.37 The great advantage in using such media is.
ci course, the fact that large numbers of teachers
'Jid children can be reached shortening what would
vormally have taken a decade in person to person
programmes as ordinarily organised.
The Computer
8.38 Recently we have ushered in the computer
age in education by installing computers in 250
schools and programmes are to train teachers both
iin their use and in preparing software. We hope
ihere will be built in into the system a process of
systematic evaluation and feedback so that within a
few years we may gain by the experience of these
schools.
8.39 We are aware that it has been pointed out
•hat the average rural school does not even have
medieval technology like black board and chalk and
unless this situation is remedied it would be futile to
install new technology. We are of the view that the
arguments in favour of acquiring new technology are
not all negative and based on fear of losing a race.
The new technology is intrinsic to national develop­
ment, economic, social and cultural. So arguments
suggesting clearing the backlog before doing any
thing new would not be tenable.
Some Key Areas for Inservice Education
8.40 From an examination of the tpye of courses
being generally run at different places a few areas
rhat need strengthening suggest themselves :
Develop Reference and Study Skilb in School
Students : Teachers need training on how these studv
skills may be developed in- their pupils, if the kind
of passive learning that goes on in our schools must
stop. Our pupils must learn independent studv
Iiabits which include items like : using a dictionary
and an encyclopaedia; reading maps and diagrams;
note-taking skills ; note-making, drawing conclusions
etc. Two to three-week courses for teachers parti­
cularly at the middle and high school levels will be
useful.
Production of Textual and Related Materials
8.41 The textbooks, pupils are made to use at all
levels, are far from satisfactory. They are hardly
attractive or well-produced or well-illustrated. Lingui­
stically the greatest problem pupils face is that
fhe language used is far above their understanding
level in subjects like Social Sciences, Mathematics,
General Science etc. Writing for children is a speci­
alised task and calls for imaginative treatment
in the hands of a talented author and linguistic vett­
ing with the help of teachers. Supportive materials
such as curriculum guides, graded work-sheets.

unit-tests have also to be provided the bulk in aU
the languages. In addition teachers also need special
reading materials of a higher order to help them
keep abreast of their subjects and of contemporary
issues so that they can meet the minds of bright
children adequately. A journal giving information
on teaching methods and educational innovation and
including extracts from specialist journals, digests of
books or articles and other enrichment materials for
teachers could be instituted and supplied to school
complexes. We suggest the State Department of
Education give urgent attention to this and to im ­
proving the textbooks being used now by organising
expert meetings at various levels. The NCERT we
expect, will provide help and guidance.
Enriching Co-curricular Activities at Schools
8.42 Teachers lack skills of many kinds. One is
in teaching crafts. Help needs to be taken from
institutes like the; Bal Bhavans and from local crafts­
men in training teachers in the use of their hands
for creating things of artistic merit.
8.43 The area of creative dramatics is also a
neglected one. Here we do not refer to the skills
involved in producing a play for an occasion but the
use of drama as a means of creative expression
through improvisions in relation to children’s experi­
ences in every day life.
This leads to free ex­
pression, imaginative play, script writing of their
own and finally the staging of the play. They ate
extremely useful as aids to language learning and in
imbibing values through perception of happenings
in daily life. Institutes like the National School of
Drama at the centre and various other voluntary
groups could help organise creative-drama work­
shops for teachers.
Encouraging Advanced Studies
support : Often it happens that in a concern for the
support : Often it happens that in a concern for the
improvement of the average standards, the outstanding
work done by a good many of our teachers is misled.
What they need most is a change in the climate of the
school, an atmosphere conducive to educational re­
search and enquiry. The Headmaster or Principal.- the
Inspector or District Education Officer ought to iden­
tify talent and where it is evident relax regulations and
given sufficient support to experimental and innovative
efforts and back them up even if a mistake is made.
The nurturing of talent requires understanding and
exposure to new avenues. Such teachers could be
given study leave and sent to advanced centres of
learning for furthering their professional competence.
The experience of the Homi Bhabha Centre for Science
Education at the Tata Institu e of Fundamenla!

<!-- page 79 -->

70

Research is relevant in this respect. The Centre has
constituted in collaboration with the Government of
Maharashtra visiting fellowships to enable practising
school teachers to obtain study leave for one year and
devote this period for pursuing educational research
at the Centre. We feel that all institutes of higher
learning should come forward with similar schemes and
set aside a small portion of their budget to provide edu­
cational opportunities to practising school teachers.
The Matter of Incentives
8.45 The matter of offering incentives is also impor­
tant. We arg of the view that certificates could be given
to participants indicating clearly the basic learnings
acquired. While the intrinsic rewards of one’s own
personal education and growth cannot be denied and
form the bed-rock of job satisfaction there is a place
also for instituting further incentives to teachers.
8.46 The teacher would feel motivated to attend
these Courses if they are organised on the basis of a
Credit system. For example, a teacher who attends a
particular course one summer in, say, “the use of tech­
nology in education” or developing a curriculum guide
in a particular subject etc. may be given a credit for
the units studied as fixed by the Course Committee.
With the addition of more Credits acquired by attend­
ing further weekend courses or through a Correspond­
ence Course a teacher may be considered eligible for
the award of a Certificate or a Diploma. This evid­
ence of a desire for professional growth may, in turn,
be a factor in the teacher’s favour when he is being
considered for a higiher post or for a foreign sc h o la r­
ship or higiher studies. We suggest that this be ex­
plored further by State Departments of Education.
8.47 We also feel that young teachers who have
evinced keenness in their professional growth, in work­

ing for the community, in striving to achieve national
goals should be identified and considered for State and
National awards.
Agencies for Imervice Education
8.48 Among the agencies that need to be supported
are the SIEs and SCERTs at the State level many of
whom are doing commendable work. Funds have
to be earmarked liberally for these institutes to conduct
a massive programme of inservice education. Their
own staff structure needs to be reviewed and streng­
thened to include subjects specialists and experienced
educational personnel well-versed in classroom prac­
tices. Outstanding teachers ought to be seconded to
these Institutes for 2-3 years to help in promoting a
climate of change and innovation. We recommend
also the teachers attending these courses should be
treated on duty and funds be made available to meet
their travel expenses and daily allowances.
The Role of the Regional Colleges
8.49 The role of the Regional Colleges of Educa­
tion in the field of inservice education to the States of
the Region cannot be over emphasized. Considering the
kind of resources of men and materials they have at
their command, we feel they should be fully involved
in promtoing quality in the State system. Of particular
relevance are the programmes we would expect them
to conduct for teacher educators at elementary and
secondary levels and for the resource and training per­
sonnel of the SCERTs/SIEs etc. in every State. We
would also expect them to interact with University De­
partments of Education and be fully involved in en­
couraging innovative programmes of in-service and pre­
service education. They should take a leadership role
in advancing the use of educational technology as
media of teaching and learning.

<!-- page 80 -->

ANNEXURE 7

CONDITIONS FOR RECOGNITION OF ELEMEN­
TARY TEACHER EDUCATION INSTITUTIONS
PREPARED BY TH E NCTE COMMITTEE ON
ELEMENTARY TEACHER EDUCATION
Aiea No. 1 Physical Facilities
Aspects :
1. Healthy surroundings for the location of the
institution.
2. L and............... 5 acres (Perferably more, if
agriculture is one of the work experiences);
3. Area of the institution building (including as­
sembly hall, a reading room, work experience
facilities with due allowance for walls, pass­
ages, sanitary blocks, e tc. . . . ) about 6,000
sq. ft.
4. Staff quarters Types I, II, III and I V ) ...........
At least for 50 percent of the staff.
5. Hostels for Trainees : Dormitory accommoda­
tion for all the trainees together with necessary
facilities.
6. Furniture, equipment and appliances
(i) Adequate furniture and office equipment in­
cluding furniture for library and reading
room.
(ii) Teaching appliances, audio-visual aids, edu­
cational material for young children and
equipment for art, music, games and sports,
etc.
(iii) Equipment and material for work experi­
ence.
(iv) Laboratory equipment (for science, geo­
graphy, home science, etc.)
A iea No. 2. Teaching and other Staff
Teaching Staff
(a) Teaching Staff including principal and mem­
bers qualified to teach art, music, physical
education and work experience ............... 8
full-time members.
One additional staff member for every addi­
tional student-strength of 12.
The minimum qualifications of teaching staff
members other than those for art, music and
physical education should be M.A., B.Ed.,
with specialisation in elementary education
and experience of teaching/administration in
elementary schools.

(b) Non-teaching Staff
(i) Librarian ..............................................i
(ii) Clerk .......................................................i
(iii) Class IV staff ....................2 (both for the
college and the hostels)
(iv) Part-time Medical O fficer........................ 1
(v) Hostel Warden one for enrolment upto 100;
one assistant warden for every additional
enrolment of 100 in hostels. Separate war­
dens for hostels for male and female students.
Area No. 3 : Library Holdings
(i) A minimum of 1500 titles including text­
books and reference books (at least ten
copies of frequently used textbooks may be
purchased for the library).
(ii) Periodicals (at least 10 educational journals
may be subscribed by each institution).
(iii) Newspapers.
Area No, 4 : Teacher pupil ratio....................1 : 12
Area No. 5 : Stipends for Trainees............... stipends
may be given to trainees belonging to SC/ST and other
under-privileged groups of community on considera­
tion of income.
Area No. 6 : Scholarships for trainees...........pro­
vision may be made of awarding scholarships to at
least 10% of the students on the basis of their rank
in the centralised admission test, if the procedure of
centralised admission has been introduced by the State
Government or any other tests/interview devised by
the institution itself for purpose of admission.
Area No. 7 : Provision for tutorials........... tutorials
may be arranged regularly in each institution.
Area No. 8 : Finance...........(applicable to private
institutions only).
(i) Building fund(applicable to institutions
which do not have their own building suitable
for the purpose at the time of applying for
recognition).( Rs. 1 lakh to be kept
in a Nationalised scheduled bank).
(ii) Reserve F und........... Rs. 25000/- or an
amount equivalent to salary of staff for three
71
