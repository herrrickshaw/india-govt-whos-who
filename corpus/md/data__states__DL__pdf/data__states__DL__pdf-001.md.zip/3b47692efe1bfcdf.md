---
doc_id: "3b47692efe1bfcdf"
source_url: "https://higheredn.delhi.gov.in/sites/default/files/Higher%20Education/tender/1764_1.pdf"
ministry: "Directorate of Higher Education, Delhi"
title: "Tender Document"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "cc09bc9f427a8e01"
---

<!-- page 1 -->

छ
GOVERNMENT OF NATIONAL CAPITAL TERRITORY OF DELHt
DIRECTORATE OF HIGHER EDUCATION
BTE, BLOCK, TTE COMPLEX, MUNI MAYA RAM MARG,
PITAMPURA, DELHI-0034.
a HMSTTIEE eS _,—_— Email iD: Baise SSS ____
DHE-2(49)/06-07/ 72 G3 -J2E3 Dated: oy 2%
TENDER NOTICE
Subiect: Disposal of old and condemned Government vehicies.
4. Directorate of Higher Education, Government of NCT of Delhi is proposing to dispose off two
condemned Staff Cars on “as is where is basis” Details of the said vehicles are as under:-
5. Registration No. | Model es — ro Reserve Price (in Rs} |
No. | | : i
NG.  व्--- -ज--+ 7: + 3 फफ्ाउतत्न-++- नल
+ | DL 70C 0007 | 2040 i TATA INDIGO 27,000/- !
| !
2 DL IC एक छत... ANIBASSADOR FT| 37,000
a a a ------_3__--्््््स््य
2. Accoriinely, sealed quotations are invited for the disposal of the aforesaid vehicles on the terms
and corciiions mentioned below. Person/Firms, who are interested to buy the above mentioned
vehicle(s) may submit their highest quotations in the enclosed proforma in a sealed cover
acdressed to the undersigned fatest by 03:00 P.M. on or before 07 March. 2023 in ine Tender Box
in Roam No-6. Directorate of Higher Education, Government of NCT of Delhi, BTE Block. TTE
Comp:ex, Muni Maya Ram Marg, Pitampura, New Deihi-470034.
3. The veliicies are available for inspection from 47:00 AM to 03:00 PM on all working days.
4. Ho bidding firm/person will be aliowed to withdraw its bid after opening of the bids.
5. The auction of the said vehicles will be governed by the following conditions:-
(@) The bidders are required to pzy Earnest Money of Rs. 5,000/- (Rupees Five Thousand
Only) for each vehicle in the form of Demand Draft drawn in favour of DDO, Directorate of
Higher Education. Delhi.
(t) Quotations received without Demand Draft towards Earnest Money will not be considered
and shall be rejected.
है ५(८/) {c} The successful pidder will ke required to deposit the balance bid amount by means of
| HE Demand Draft drawn in favour of DDO, Directorate of Higher Education, Dethi within three
—gpfoa}n023 working days of the intimation about the successful biacer.
(c} The delivery of the sold vehicle will be given only to the successful H-7 bidder after
submission of documentary evidence in support of residential status (Voter ID,
Aadhar Card etc., in case of individual and Registraticn Cerificate etc in case of
firm.

<!-- page 2 -->

न ४ (2) The auctioned vehicle wi! be removed by the successful bidder within three
e working days of depositing the bid amount at his own expenses from the location
of the vehicle.

(f) The vehicle will be disposed off on “as is where is basis” and no guarantee for its
worthiness or quality will be given by the Department.

(9) The successful bidder wilt also be responsible for getting Registration Certificate
of the Vehicle transferred in his name at his own cost expeditiously. The office will
not be responsible for any lapse on his part in this regard.

(h) The successful bidder will not be allowed to withdraw their bids, failing which the
Earnest Money will be forfeited.

(i) EMD of unsuccessful tender shall be returned within two weeks of the award of
contract to successful bidder.

(j) The Competent Authority reserves the right to accept or reject any/all of the
quotations without assigning any reason.

(0 Proforma for offering rate for disposal of condemned vehicle is enclosed as
“Annexure-A”. i

Wy
hy Meena}
Administrative Officer (Higher Education)
Copy fa:-
२2 आठ Analyst to upload the Notice on Departmental website.
2. Notice Board.
