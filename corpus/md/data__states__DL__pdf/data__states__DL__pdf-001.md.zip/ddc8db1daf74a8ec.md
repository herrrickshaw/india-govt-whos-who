---
doc_id: "ddc8db1daf74a8ec"
source_url: "https://artandculture.delhi.gov.in/sites/default/files/Art%20and%20Culture/tender/tableau_2021.pdf"
ministry: "Art, Culture and Language Department, Delhi"
title: "Tender Document"
date: ""
pages: 11
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "eb2698dcf2501afe"
---

<!-- page 1 -->

Sahitya Kala Parishad
Department of Art, Culture & Languages
(Government of NCT of Delhi)

TENDER NOTICE
Sahitya Kala Parishad, Department of Art, Culture & Languages,
Government of NCT of Delhi invites tenders from experienced parties to
conceptualize, design, fabricate and display a Tableau of Delhi
Government during the Republic Day Parade, 202 on the theme
“Redevelopment of Shahjahanabad”. The financial costs including

all taxes shall not exceed Rs.25.00 lakhs (Rupees twenty five lakhs).
The bidder must have been responsible for a tableau that participated in
at least one Republic Day Parade at Rajpath, New Delhi during the last
three years. Only the agencies having its office in Delhi and can provide
staff based in Delhi shall be considered. Other eligibility conditions and
the tender documents can be obtained from the website of Sahitya Kala
Parishad http://skpdelhi.in and Department of Art, Culture &
Languages _http://artandculture.delhigovt.nic.in/wps/wem/
connect/DoIT_Art/art+culturetand+language/home.
Eligible parties are requested to send their sealed bids in an envelopes
containing technical and financial bids in two separate envelopes to
Secretary, Sahitya Kala Parishad, 78-A, Satsang Vihar Marg, Spl.
Institutional Area, New Delhi-0067. The last date for submission of
the bid is 4:00 p.m. on 02--2020.

Secretary
Tel. 04-26867636 Sahitya Kala Parishad

<!-- page 2 -->

साहित्य कला परिषद्‌
कला, संस्कृति एवं भाषा विभाग
(राष्ट्रीय राजधानी क्षेत्र दिल्‍ली सरकार)
निविदा सूचना
साहित्य कला परिषद्‌, कला और संस्कृति विभाग, राष्ट्रीय राजधानी क्षेत्र दिल्‍ली
सरकार, अनुभवी दलों से वर्ष 202 की गणतंत्र दिवस परेड में दिल्‍ली की झाँकी की
संकल्पना, डिजाइन एवं निर्माण करने के लिए शाहजहानाबाद का पुनर्विकास विषय
पर निविदाएं आमंत्रित कर रहा है। झाँकी की वित्तीय लागत सभी करों सहित रु.25
लाख (रुपये पच्चीस लाख) से अधिक नहीं होनी चाहिए।
निविदाकर्ता वाला गत्‌ तीन वर्षों में कम से कम एक वर्ष गणतंत्र दिवस परेड, राजपथ,
नई दिल्‍ली में एक झाँकी प्रस्तुत करने की जिम्मेदारी ले चुका हो | केवल उन्हीं एजेंसियों
पर विचार किया जाएगा जो दिल्ली में स्थापित हो और दिल्ली में स्थित स्टाफ उपलब्ध
करा सकती हैं। अन्य पात्रता की शर्तें और टेंडर दस्तावेज साहित्य कला परिषद्‌
http://skpdelhi.in vd oot wepfa vd arr far w daege
http://artandculture.delhigovt.nic.in/wps/wem/connect/
DolT_Art/art+culture+and+ language/home © ura fey oT wad
हैं।
पात्र दलों से अनुरोध है कि अपनी सील बन्द निविदाएं को दो अलग-अलग लिफाफों में
तकनीकी और वित्तीय निविदा सचिव, साहित्य कला परिषद्‌, 48-ए, सत्संग विहार मार्ग,
स्पे. इंस्टीट्यूशनल एरिया, नई दिल्‍ली-40067 को भेजें। निविदाएं जमा करने की
sifers ferfr 02—44-2020 UTE 4:00 बजे तक है|
सचिव
GRATE: 04-26867636 साहित्य कला परिषद्‌

<!-- page 3 -->

Re 3
TENDER DOCUMENT
Terms and Conditions/Guidelines for submission of proposals

The bidder has to comply with the guidelines in respect of tableau as specified by the

Ministry of Defence from time to time. ‘The Annexure-II contains some of guidelines of the

Ministry of Defence available with the Parishad.

The proposal should contain the following:

\) Packet-I (sealed and to be superscribed “Technical Bid”):

(a) First envelope superscribed “Technical Bid” should contain particulars
regarding eligibility criteria and treatment of the theme viz. (i) experience of
conceptualization of theme, fabrication and display of Tableaux for Republic
Day at the National Level (ii) experience of conceptualization of theme,
fabrication and display of tableaux in other events of repute (iii) details of
expericnce of creative personnel like visualizers or concept directors,
fabricators etc. (iv) details of prizes won, (v)registration of the agency with the
competent authority for GST and (vi) Details of annual turn over for the last
three years, certified by the Chartered Accountant (vii) Particulars of latest
PAN/TIN No, (viii) the treatment suggested for the theme of Government of
NCT of Delhi’s tableau selected for this year’s Parade. Besides a narrative
explanation, the treatment should contain drawings and designs explaining the
manner in which the theme can be presented. The agencies can present more
than one design for the theme.

(b) Earnest money deposit (EMD) in the form of demand drafi from a scheduled
bank for Rs.50,000/- drawn in favour of “Sahitya Kala Parishad”.

2) Packet-II (to be sealed and superscribed “Financial Bid”):
Financial bid should contain the consolidated cost of tableau i.e. from
conceptualization till the presentation of tableau on the Republic Day, along with
break-up of expenses for its dismantling, removal of material and other expenses
whatsoever ( inclusive of all taxes). The name of the agency, address, telephone no.,
fax no. and e-mail shall be printed on the cover of both the packets. Both the
envelopes (Bid-l and I) shall be placed inside outer sealed cover which shall be
addressed to the Secretary, Sahitya Kala Parishad, 8-A, Satsang Vihar Marg, Spl.

Institutional Area, New Delhi-I0067.

Selection Process:

Selection committee will evaluate technical bids and based on the assessment of technical
bids, may shortlist upto 4 proposals/bids. The technical evaluation will be on the aggregate of
70% marks. Technical assessment will be based on creative ideas, treatment of theme/subject
and its presentation in the form of drawings and designs etc. On the basis of technical
assessment the financial Bid of the shortlisted agencies only will be opened. Financial
evaluation will carry a weightage of 30% marks.

The bidders shall ensure that design / drawing in the powerpoint presentation and hard copy
submitted in the technical bid are exactly same. A certificate shall be submitted to this effect
at the time of presentation.

<!-- page 4 -->

“> However, Secretary, Sahitya Kala Parishad reserves the right to select any agency on the

strength of technical bid.
Evaluation Criteria:
The aggregate of marks, after adding the scores from the technical and financial evaluation
will determine the outcome and the work will be awarded to the Agency which gets the
highest aggregate marks.
Composite Score of the Bidders for Production of tableau shall be worked out as under:

= =f | Weight Weighted Score

जा ऋफोािओ रो : कर x

| Financial Score for those TT रा न हु

found eligible in 30%

Technical Bid ods -

Composite Score of the Bidder - (X+Y)
The Bidder who has secured the highest Composite Score shall be declared the Preferred
Bidder subject to the satisfaction of the Competent Authority/Secretary, Sahitya Kala
Parishad.
The eligible and interested agencies are requested to submit their technical and financial bids
latest by 4:00 p.m. on 2"! November, 200 at the office of the Sahitya Kala Parishad, I8-A,
Satsang Vihar Marg, Spl. Institutional Area, New Delhi-0067. The eligible bidders shall
give their presentations of their drawing and designs etc. on the selected theme of the tableau
“Redevelopment of Shahjahanabad” before the selection committee in the office of the
Secretary, Department of Art, Culture and Languages at ‘C’ Wing, 9" Level, Delhi
Secretariat on the date and time, which will be communicated later.
Tender/proposals received after the fixed time and date will not be entertained.
Performance and security deposit:
Successful agency has to deposit the performance Guarantee for 0% of the total Value of the
contract in the form of Account Payee Demand Draft or Fixed Deposit Receipt or Bank
Guarantee from a Nationalized Bank. The performance security should remain valid for a
period of 60 days beyond the date of completion of all contractual obligations of the
supplier/agency.
Scope of work:
The work has to be undertaken on a turnkey basis and will include all aspects of : Fabrication
of tableau i.e. from conceptualization, making of designs, modification of designs from time
to time as per the requirement and instructions, presentation of the designs before the
selection committee of the Department of ACL and Ministry of Defence, fabrication of the
models, modifications thereof as per the requirements and instructions, presentation of the
model before the Department of Art, Culture & Languages and Ministry of Defence and upon
selection of the model, fabrication of the actual tableau as per the requirement, specification,
time schedule and instructions issued by the Department of ACL and Ministry of Defence.

<!-- page 5 -->

4 Providing of suitable/appropriate composition of music etc, arrangement of artists and actual
pre-recording of the music for use in the tableau.

Presentation and display of tableau during the Republic Day Parade, full dress rehearsal and

other rehearsals to be decided by Ministry of Defence and maintenance of required service at

the time of presentation during the event.

The turnkey project would also include any other work that may have direct or indirect

bearing with the fabrication and presentation of the tableau and may facilitate the project in

any manner viz. printing of tableaux brochures, PR with print & electronic media etc.

Information related to the theme and relevant inputs as required will be made available by the

Sahitya Kala Parishad.

The Secretary, Sahitya Kala Parishad reserves the right to modify, change, accept or reject

the work in totality or any part there of or cancel the project at any stage without assigning

any reason.

‘The copyright of the work shall vest with the Department of ACL and it would have rights on

the awards won, if any.

‘Time Frame: हु

i) The agency selected for the execution of the job has to complete the tableau as per the
deadlines and time schedules fixed by the Sahitya Kala Parishad/ Department of ACL
for completion of the various stages of the work and would have to adhere to any time
schedule to be fixed so as to enable this Office to fine-tune the processes involved in
fabrication as per requirement from time to time before the display.

ii) The designated officer of Department will have the right to make necessary
modifications/alterations in the layout till the last moment in order to ensure that a
quality product is finally put on display.

iii) Failure to meet the time schedules will invite a penalty @I% of the contract value per
day of delay.

iv) After the event is over the party/agency shall be responsible for dismantling and
removing the materials as per the prescribed time schedule of the Ministry of Defence
and shall be liable to pay any demurrage that might be imposed by Ministry of
Defence for non-compliance of dismantling schedule.

v) The dismantling and removal of the material have to be done by the agency at its own
cost and hence of the same may be factored in the financial quote.

Terms of payment:

Payment shall be made to the agency as per the following schedule:

* 30% of the total contract value shall be released after completion of the work up to the

preparation of the structure (including the woodwork).

<!-- page 6 -->

ON vw 30% of the total contract price shall be paid after completion of the Tableau to the
satisfaction of the Sahitya Kala Parishad.

. The balance 40% shall be paid after submission of the final bill after necessary
measurements, certification etc. and satisfactory completion and display of the tableau
as detailed in the scope of the work.

. Deduction at source for income tax or any other tax as applicable shall be made as per
rules.

. Sahitya Kala Parishad shall not be liable for any default of payment by the agency to
the parties involved or engaged by it for this project.

. No payment shall be payable in case the design / proposals are rejected by the
Ministry of Defence at any stage.

2
[lege
~~ (tarleen Kaur/IAS)
Secretary
Sahitya Kala Parishad

<!-- page 7 -->

हे ANNEXURE-I
Sahitya Kala Parishad
Govt. of N.C.T. of Delhi
APPLICATION FORM FOR CONCEPTUALIZATION AND FABRICATION AND
DISPLAY OF TABLEAUX DURING REPUBLIC DAY PARADE-202I
(Please use additional sheets / annexures, if required)
2 | Office address (with
telephone/mobile & e-mail):
3 | Details of the creative personnel
with their bio-data and address in
Delhi ee
4 (i) | Experience in the area of
conceptualization fabrication and
display of Republic Day tableaux at
National/State level, (detailing the
ears, organization and theme
ii) | Experience in fabrication and
display of tableaux in other major
events, if any (detailing the years,
organization and theme)
Photographs/CDs of carlier work: |. श
Awards won (with details including
copies of the certificates)
7 | Certified copies of the Annual
Statements of Accounts certified by
Chartered Accountants indicating
the turn-over of the agency for the
last three financial years.
Particulars of the latest:
PAN
TAN / TIN
GST No.
Documentary proof of issues as
mentioned in the Tender Notice.
Date : Signature of Proprietor/
Authorized Signatory

<!-- page 8 -->

५७ ANNEXURE-IE
Guidelines for preparation of Tableaux proposals for participation in the
Republic Day Parade-202I:

l, Theme of the Tableau:
Redevelopment of Shahjahanabad
2. Selection Process:
6) The tableaux proposals received from various organizations/ agencies are
evaluated in a series of meetings of the Expert Committee consisting of prominent
persons in the field of art, culture, painting, sculpture, music, architecture,
choreography etc. In the first phase of selection, the sketch/design proposals are
scrutinized and suggestions, if considered necessary, are given to carry out
modifications in the sketch/design. Once the sketches/designs are approved by the
Committee, the participants are asked to come up with three dimensional models of
their proposals. However, entering into the model stage it does not mean selection.
The models are thereafter examined by the Committee for final selection depending
upon various considerations. Not more than one tableau from an organization
participates in the Parade.
Adequate time is given to the concerned agencies to make arrangements for attending
the meetings of the Expert Committee. Non-attendance in any meeting means
withdrawal and concerned agency will not be invited in subsequent meetings, All cost
for attending the meetings is to be borne by the concerned agency. All interactions
with the members of the Committee will be made by the official representative of
the organization concerned. The artists/ designers, etc. may accompany the official
representative to suitably take note of the suggestions given by the Committee to
carry out modifications in their respective sketch/design/model. They will, however,
not directly interact with the members of the Expert Committee unless they are
specifically authorized by the Committee to do so to explain any specific point.
(ii) | This Ministry does not prescribe any firm/fabricator for design &
construction of tableau for participating in Republic Day Parade. The State / UT
/ Ministry / Department may engage / appoint any firm / fabricator for this
purpose on their own, However, to maintain quality and avoid monotony in look
/ design of the tableaux, it is suggested that concerned State / UT / Ministry /
Department may consider to evolve suitable mechanism so that the firm /
fabricator engaged / appointed for the purpose may not be involved in designing
/ fabricating multiple tableaux for the Parade.
(iii) It is highlighted that selection of Tableaux passes different stages starting from
initial appreciation of sketch / design and the themes brought forward by the States /
UTs / Ministries / Departments followed by a three dimensional model which
culminates into the selection of the actual model by Expert Committee through a
series of interactions where all aspects of the tableaux are discussed threadbare, The
selection depends upon a combination of factors including but not limited to visual
appeal, impact on the masses, idea / theme of the tableaux, degree of detailing
involved in the tableaux, music accompanying the tableaux etc. The selection process
normally extends over six to seven rounds of meetings on different days with some

<!-- page 9 -->

७ elimination and short listing at each stage. Only the shortlisted States / UTs/Ministries
/ Departments in any given round of selection are informed about the next round of
selection. Mere advancement from one stage to another does not entitle any
participating State / UT / Ministry / Department for movement to another further
round or the final selection, till it is confirmed. In the event of final selection also,
there may be a possibility of a particular tableaux not being able to participate in the
final parade, if it has not been created in terms of the final approved version during
selection rounds.

3y Preparation of Sketch / Design:

The sketch / design (preferably in graph) on a scale of I°:!” should be simple,

colourful, easy to comprehend and should avoid statistical data and unnecessary

details. It should be able to convey whatever it presents, by itself and should not
require any explanation, writing or elaboration. Writing or use of logos on tableaux
is not allowed except the name of States/UTs presenting which is allowed in

Hindi in the front, in English on the back and in Regional language on the sides

of the tableau. Similarly, in case of Ministries/ Departments and other agencies,

name of the Ministry/Department/ organization is to be given in Hindi in the
front and in English on the back. Designs in virtual reality in the form of CD
showing the various components displayed from different angles, can also be
presented.

4. Preparation of models:

After the approval of the proposed sketch/design by the Expert Committee in its

preliminary meetings, three dimensional model of the proposed tableau would be

prepared on the lines of the suggestions given by the Committee for further inspection.

Final approval for participation would be accorded only after the models of the

tableaux are finally selected by the Committee.

5, Points to be kept in view while drawing up the proposal:

(i) One tractor and one trailer, upon which a tableau would be fabricated,
would be provided by the Ministry of Defence free of charges.

(ii) No additional tractor, trailer or other types of vehicles would be allowed
to be used in the tableau. This aspect should be kept in mind while preparing
the designs of the tableau proposals to be presented before the Central Expert
Committee.

(iii) There is no objection to the use of vehicles other than tractor and trailers for
fabrication of tableaux to give them a different look. But these vehicles will
have to be arranged by the sponsoring authorities themselves. Under no
circumstance, the total number of vehicles used in a tableau or the total
number of distinguishable mobile components of a tableau would be more
than two.

(iv) As far as possible, there should be some movements, sound and animation on
the tableaux.

(vy) The number of performers on the trailer would not be more than 0
persons. No performer is permitted to be on the tractor component of the
tableau. Attractive ground element however can be considered on a
limited number of tableaux only if it goes with the theme. These

<!-- page 10 -->

हि conditions are subject to modifications by MOD depending on the
requirement of the tableau.

(vi) In case of tableaux on cultural, historical/traditional themes, the colours,
design, costumes, materials etc. used should be authentic to present local
flavour. The performers on the float or on ground should also look to be
authentic in case any cultural or traditional event is being depicted.

(vii) The sketch should clearly depict as to how the tractor pulling the tableau will
be used as a part of the theme. Camouflaging the tractor should be in harmony
with the main theme of the tableau. There should be a gap of about 6-7 feet
between the tractor and the trailer and/or between two trailers for turning or
maneuvering. This should be taken into account while designing the tableau.

(viii) In case, a tableau is proposed to be integrated with a folk dance, it should be
ensured that the selected dance is a genuine folk dance and the costumes and
musical instruments are traditional and authentic. The tableau and the dance
should also have thematic unity. The strength of the dance party, excluding
those who are to perform on the tableau, should not exceed 25 persons. The
video clippings of the dance may also be sent along with the proposals.

(ix) State / UT may preferably engage artists performing on or along the
tableau of the State / UT belonging to the concerned State / UT only, who
would have a natural flair for the performance considering the criticality
of the event. Bonafide of artists engaged by the State / UT / Ministry /
Department may be ascertained by the authorised government official of
the concerned State / UT / Ministry / Department before deputing the
artists' team to Rashtriya Rangshala Camp.

(x) It is also suggested that State / UT / Ministry / Department may evolve
their mechanism to ensure that the agency deployed for design /
fabrication of the tableau remains associated with the job till finality to
enable incorporating the originally conceived design along with the inputs
of the Expert Committee from time to time.

6. Dimensions:
While preparing the sketches and subsequently, three dimensional models, the
following approximate dimensions of the trailers and tractors, which will be supplied
to them for the fabrication of the tableau, may be kept in view.
Trailer
Length ४ आह
Width # | 8
Height $ (APR?
Load carrying capacity :  0 tons

The length, breadth and height of a single tableau should not exceed 45°, 4° and 6”

(from the ground level) respectively. If it is proposed to use any other vehicles

under own arrangements, particulars thereof should be indicated in the proposal.
