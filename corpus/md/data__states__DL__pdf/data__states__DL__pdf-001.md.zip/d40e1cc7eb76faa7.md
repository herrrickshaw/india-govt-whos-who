---
doc_id: "d40e1cc7eb76faa7"
source_url: "https://ard.delhi.gov.in/sites/default/files/IT/circulars-orders/order_0.pdf"
ministry: "Administrative Reforms Department, Delhi"
title: "Download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0aad982490c507a5"
---

<!-- page 1 -->

OOR,

DRECTORATE G;ENLRAL, (OF IIEALTIISERVICES
(}:CONOMICALLYWEAKIER SECTION)
110092
IDGD BU,DIN: S-L SCO0L BIL,0CK, SILAKARPUR, DELIIIImail: lreetienteellgmail.cum

Datcd:

No. F.13(g04)/DGus/uQ/EWS/2025/ 13
ORDER

vide

No.

Mecting circulatcd
Committec. in
wherein it bas been deciled by the Special
I:("06)GUSiQ1EWS023/%8%-60
(C) No.
('uurt dated 02.09.2025 nnd 31.I0.2025 in WP
coplance nithtlhe orders o the Jlon'ble Jioh
clgible
and SI01/024, that the income criterion for
SN0l7 and CM Applications No. 08S/2024
Tdentificd
treatment from
Il'eaker Seetion(:WS) for availing
|ents belonging lo the F'conomically
Private llospitals has been reviscl.
Twenty
Crom Rs. 2, 20,000/- (Rupces Two Lakh
Accordingly. the income limit has been cnhanced
Thousand only) to Rs. $. 00.000/- (Rupees Five l.akh only) per annum.
Hospitals are
and Nodal OTicers of the ldentificd Private
In this regnrd. all Medical Superintendents
eligible
already convcycd concerning the treatment of
herchy directed to strictly adhere to the instructions
henceforth.
per annum shall be followed
Thc revised income criterion of Rs. 5.00,000/-

Please

lind

enelosed

herewith

the

Mives

EWS patients.

All concerned are requested to ensurc compliance with

the

the above dircctions and non compliance of the

above order slhall be viewed seriouslv.

(Dr. Vatsala Aggarval)

Na, F.I131q1h/pGHSAHQIEWS2025/13- I9

Director General of Health Services
Dated:

Copy forwarded to the following for information and nccessary action:
1. OSD 1o JHon'ble Minister of llealth, Delhi Sect., 1.P.Estate New Dellhi.
2 PS to Secretary. IH&FW Departnent, Delli Sectt. I.P.Fstatc New Dellhi.
3. PA to Spl. Seeretary. I1&T'W Department, Dellhi Sect. 1.P.Estate New Delbi

4. PS to AIMedical DireetorfSuperintendent Dellhi(Govt, of llospital GNCTD.
5. AlIMedieal Supdı/Nodal(O1icer of tdentifiedd Private I lospitals.

6. lLiaison ()fficer, ofall ldentilicd Privite llospitals.
7. PA to Medical Supdt. Nursing Ilome Cell, 1)GIS, Shakarpur Delhi.

(Dr. Vasala Aggarwal)

Director ieneral otlealth Services
