---
doc_id: "cfffb5def0611abb"
source_url: "https://publicity.delhi.gov.in/sites/default/files/publicity/our-services-files/equal_opportunity_policy_for_persons_with_disabilites.pdf"
ministry: "Directorate of Information & Publicity, Delhi"
title: ""
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "276f251c18158989"
---

<!-- page 1 -->

DIRECTORATE OF INFORMATION & PUBLICITY
Va BLOCK NO-9, OLD SECRETARIAT, DLEHI-0054

EQUAL OPPORTUNITY POLICY FOR PERSONS WITH DISABILITIES

The Government of India has enacted the Rights of Persons with Disabilities (RPwD) Act,
206, w.e.f. 9" April 20i7 and has also notified the Rights of Persons with Disabilities Rules,
207 dated 5.06.20i7. Section 2() of RPwD Act 20i6 states that every establishment shall
notify its Equal Opportunity Policy, detailing measures proposed to be taken by it in pursuance of
the provision of this Chapter in the manner as may be prescribed by the Central Government.
Further, Section 2(2) of said Act provides that every establishment shall register a copy of the
said policy with the Chief Commissioner or the State Commissioner, as the case may be.

Rule 8 of Right of Persons with Disabilities Rules, 207 and Rule 2 of Delhi Right of
Persons with Disabilities rules, 20i8 stipulate the manner of publication of “Equal Opportunity
Policy” as follows:-

l. Every establishment shall publish its Equal opportunity policy for Persons with

Disabilities.

2. The Establishment shall display the Equal opportunity Policy preferably on their
website, failing which, at conspicuous places in their premises.

3. The Equal Opportunity Policy of a private establishment having twenty or more
employees and the government establishment shall, inter alia, Wontain following,
namely:-

a. Facility and amenity to be provide to the persons with disabilities to enable them
to effectively discharge their duties in the establishment;

b. List of posts identified suitable for persons with disabilities in the establishment;

c. The manner of selection of persons with disabilities for various posts, post-
recruitment and pre-promotion training, preference in transfer and posting, special
leave, preference in allotment of residential accommodation, if any, and other
facilities.

d. Provisions for assistive devices, barrier free accessibility and other provisions for
persons with disabilities.

e. Appointment of Liaison Officer by the establishment to look after the recruitment
of persons with disabilities and provisions of facilities and amenities for such
employees.

In compliance of the aforesaid provisions, the Directorate of Information & Publicity,
Government of NCT of Delhi frames the following Equal Opportunity Policy for persons with
Disabilities:-

Policy Statement:-

The Directorate of Information & Publicity, Government of NCT of Delhi is committed
towards eliminating all forms of unlawful discrimination (which includes direct discrimination,
indirect discrimination) and harassment of persons with disabilities.

waite
Administration
Dte. of Information & Publicity
Govt. of NCT of Delhi

<!-- page 2 -->

a. Facilities and amenities to be provided to the persons with disabilities to
7 enable them to effectively discharge their duties in the establishment:- This
department aims to ensure that our physical and digital infrastructure (building, furniture,
facilities and services in the building) adheres to the accessibility standards as prescribed by the
Government of India. The Department also aims to revamp its existing buildine’. to ensure strict
compliance with the RPwD Act 2046. Provision of ramps, grab bars and wider doorways to enable
access to building and workplaces, tactile paths and wheelchair accordingly, web accessibility,
parking facility, accessible toilets etc.
b. List of posts identified suitable for persons with disabilities in the
establishment:- The Directorate of Information & Publicity shall prepare a list of the identified
posts in all groups- A, B and C for persons with disabilities.
८. The manner of selection of persons with disabilities for various posts, post-
recruitment and pre-promotion training, preference in transfer and posting, special
leave, preference in allotment of residential accommodation, if any, and other
facilities:- In all such matters, including reservation applicable in respect of Persons with
Disabilities, the Directorate of Information & Publicity follows the relevant OMs/instructions etc.
issued by the Government from time to time. Any information shared by जा employee on
disabilities/medical condition shall be kept confidential.
d. Provisions for assistive devices, barrier-free accessibility and other provisions
for persons with disabilities:- Department shall ensure that all the required
assistance/facilities required by the persons with disabilities is provided/arranged in its office
premises.
e Appointment of Liaison officer by the department to look after the recruitment
of persons with disabilities and provisions of facilities and amenities for such
employees:- A Gazetted Officer will act as Liaison officer. The Liaison officer shall be
responsible for:-
is Implementing the action plan for making the work place and IT systems accessible for the
people with disabilities by Liaising with the concerned officer.
ii. Ensuring that all employees are aware of the Equal Opportunity Policy and know their
duties and rights in relation to the Equal Opportunity Policy.
iii. The Liaison officer to monitor the work environment to ensure that it is free from
discrimination, harassment and encourages inclusion and respect for others.

The above policy covers full time/part time persons with disabilities employees. It also
covers those employees who acquire disability during service. Review of policy shall be
undertaken at regular intervals.

saci drain
Admi jo a
Dte. of Information & Publicity
Govt. of NCT of Delhi
