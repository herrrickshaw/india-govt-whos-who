---
doc_id: "dbf39a48e2deb0d3"
source_url: "https://it.delhi.gov.in/sites/default/files/IT/marquee-files/esam_order_08_05_2026.pdf"
ministry: "Information Technology Department, Delhi"
title: "implementation of eSAM Portal for end-to-end asset tracking and management"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "fcac5da64e8ac383"
---

<!-- page 1 -->

।
Int Government of NCT of Delhi
9" Level हि a Technology Department
» B-Wing, pen Secretariat, New Delhi-l0002
File Non Els PONE SENTATION 7 ace FOTN GOV.
‘ im Yok ~ aa peomeenoeamilranacsccns
/ €-8F Date osfr/ ore
ORDER
Subject: tmplementatio!
a n of eSA
and management M Portal for end-to-end asset tracking
ine ba (e-System for Asset Management) is a web-based application
eveloped by National Informatics Centre, Karnataka, to streamline and
automate asset management across government departments. As decided, the
system is being adopted by the Government of NCT of Delhi
2. The eSAM portal shall function as the single authoritative source for the
complete lifecycle management of all physical and digital assets, including:
+ All newly procured assets shall be recorded in the system immediately
upon receipt.
- Real-time tracking of assignment of assets to concerned employees or
departments shall be ensured.
+ Proper and formal documentation of decommissioning, recycling, or
disposal shall be maintained within the portal.
+ It facilitates comprehensive tracking of assets including inventory and
stock management from procurement (entry) to disposal (exit)—through
a centralized digital platform.
3. A comprehensive training session on the eSAM system has already been
imparted to all Officers/officials of Dept. of IT, GNCTD on 5.04.2026. The
sessicn covered system functionalities and operational procedures and
credentials were shared.
4. It has been observed that, despite the implementation of the eSAM platform,
asset tracking at different stages is still not fully streamlined in the
Department. Therefore, to improve transparency. accountability, and
efficiency. it is directed that all assets must be managed only through the
eSAM Portal with effect from 0.05.2026.
5. All designated Officers/Officials shall ensure that thei profiles are duly
updated in the eSAM portal and that valid user credentials (User ID and
Password) have been obtained.
6. The Store in-charge shall undertake a thorough reconciliation of the existing
physical inventory with departmental records of employees to ensure accuracy
and eliminate discrepancies. 3
Pays Lol?
se
i
CE Scanned with OKEN Scanner

<!-- page 2 -->

|
7. For continued guidance, detailed user manuals pertaining to various eSAM
लग are available = on ~—the_~—s- Department's __ website:
i वि लिन लग न कक In case of any technical issues or clarifications,
2 Cials may contact to Sh. Kapil Kumar (Technical Officer), Dept. of IT,
NCTD,
/ All Officers/Officials are hereby di
4 i The y directed ta e e ict a
‘ above instructions in letter and spirit. 3 विधान गीली बी लिडा दल 29 28
ye”
/ (K.Murugan)
Joint Director (IT)
To:
All Officers/Officials, IT Department, GNCTD
Copy for Information to:
, PS to Secretary (IT), Dept. of IT, GNCTD.
2. PS to Special Secretary (IT), Dept. of IT, GNCTD.
3. Guard File.
Page 2 of 2
i
CE Scanned with OKEN Scanner
