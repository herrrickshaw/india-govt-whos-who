---
doc_id: "9ef409a4dfbfe12d"
source_url: "https://employment.delhi.gov.in/sites/default/files/employment/circulars-orders/recruitment_rules_for_the_post_of_joint_director_employment_1.pdf"
ministry: "Directorate of Employment, Delhi"
title: "Download"
date: ""
pages: 7
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "4a3b488a47f4c77a"
---

<!-- page 1 -->

.
p>
¥¢- . s
oe
: . ¢
ee - १ py cee a ,,..: ay ” Tite Geek pin yte : vee op . .
‘opp gt phere «८52: eth: ¢ my ET 8 ft : ov: yy rt 24 “४ ८3:२८
४7. ६६ ४-००  ईड OLE ake - & 5६:६३. ERS BASE te BAT FE, geil bee (45 3 हि iO: $f & 3 it () rf ‘4 ig
a ), 0,80६... "जन he आा ः te kent 522... 222 22,02४ ME the ”.
rh, ८०५ 2 f |; ० ; 0 | ् ” | जन ८
COVER MME T OF INDIA
Lg 3 BEGG 7: Coe ६४ ६./5/5
EBs.
४७% ८5 ..-
४ 54%. क्या Me ' ei ee ke, ef 9.
% 2" 4 64% 8 26 8 ६.
ae CM oi ४2८८८८६८८८०८८८८०८४४:४४४ ue, hy x tog ee ४७८४ ous eee
es हां ॥ ५७ a ae 22268 a ५७७४६४७
ae COR EN aS 440॥02077//000/00८7:2447/227707:%0/7707/600: crane (fil hae ye: Rpt KB Bers Me gO CP OCT ROTTED CEE IG sr Hye p LUNN ciel हि
ही se On 77722: 6406. 0226. 7: हक ८ 64% 42% In a a ° EANIEO ARATE ly
t a MM MZ BES SE GE 24070 620 tetera ete: § Hee आया 4
५ oo be: ae $ Fi | ge ye 5 eres ५८८० §6 :: ee ae ; । .. ४०.7 अर क्र 7 हु ;
7 45% Be AS siti 4 ५ . 4 eo i, on i Hi 4८ ee) 3 aan i ora i 3 "
ae: eee os (x ae. «6 2992 46% se, 4 wa x % ५३ ud 2422 ae te x § we हद:
ge Be ape. . Siar i, 2 & eee 4 8. es 44% कि: प्र ; [| 7
4 7 cee 2g ros १. aR ae $ i 2: eee डे PEt gota eae 6 "4 : ee “ iH :
a 3 eee y Se “¢ fete a 228. 22782 72 an 5 के. aa tz. Livy 2:72:: 224 + ge ¥ हु हि 7 Af
4 ५ 4 ; 3 Z 2 f be A 4 4 4८ 4458 : as 4 Pes ६] है ‘et 4 33525 q 400 2 $ ¢ -
ame 00% 7 Canoe spaces श्र 2५ eS 4 ; . POEL Ee 2 8 . हि 7 ४ 5 ह
98 EOD SEE Cie Sy ¥ हर Lancia Sesser saan te ee ; :
BALA HEE mies मिड: मलरअलिक पक igi 2 ४
iia & ah , : हि ५०७० 4
jo 4) , BE 48 é ae:
मर 422 22" ms STE
22220: 2722 28822 tees BE aS ( 4 y हे a 2p
22% 2284 हि £:2:22 2 ears २ a oy en, 25. , 202 aot
40 ge Pans en: “a 22 ay 4 “se rere ५६६४४ कद SAAT Bra te ees ike ae
Se Oe aes = hy Bhs By pg % ihe 28986 a a i Bae
ey, 8/7 ae a yh y 620. «४४ 22228 6५2240008 Ph. eee Le oy aes
£ ४222 “42225 ay EEE Ra “2222 22207/76 ४:22 oe Barnet
eo 6 ay ey 2 Mee ay
2 कडक का, कक 244
25४45 £४६ 6 ६
by £ ga Ag Bap 7 $ $y 4 Be ५
है. & $ #5 / 5 5 / 59%, Ba 8 TED
x, कक +
क्क्ष्क्ट एक लडटका ess epee
ALi aay th ORG ESF
BES ie 5 ; Sn, 44 $F ; % #£eE 4 4 i 4 t j ¢ j ; j Ge
j LEBER BEES A 5 4 Y¥ 3% 40 i 3 | 4 9. 5 4
44 oped Loveaproenmorertgy STESETT SET et Me tm 4.4 Mag ar a ney के + + :
4 a a At LY eS 3 ke £4 4५ £4 BS t 4 ४5 ४ ६; , /& ३2. ¢ rr. aa Sat Boy : 3 weg ETE ye eS ye t Rt
fh PLOT # {SAGA EE | ERE OS 24, BGS CATIA BU Te AG POPE PL, we ईंट EE 8४8४५
रु प्र » 2८4३६ 42४ ३५ “~ f et i ye ey 4 ७:2७ 5: हु नजर i eh ge OBE ty og 6G i . 4k RG ; ahs a Le . , “ a
No DELHL PRIDAY. NOVEAIBER Df UATE RARTIBRA 20. (986 ONC GR 5. 4
Mega, 8 AGS SPEARS SE. SEG OLR ROUTER ML PEER AB EE ORE PAE On 8g ba a Ewes
: . i . Lo 8, if, ;
Seer i %
So FT 3
Beg ई 4३-०० 3 %
Bn a BOE 33°
PAR BEG .
POR BL Doe 4
oe eeepeneee bebe denned cbt ONE senvesenenbsense Seas
ws tr “4, f: +
~papye se छा TREN or sweanpeaennagrae — ste therwnsy Gp siscaseastcatighe “abl ap opennenpeage fe
a gt 4g5 रे हा ८645. है . 2, Sf. “a te etn F Rap i te
PULTE, IV ITP AP EO FE ate
” % है
: $ श्र er #ऋ ५ % 4 ५: %: " “oy Ye PRET ७: a a ४ ४ +n Bae EB जे 5: ३2% 83 ६ ४ 4 ६४% ६ ४५ 4४ mE Es
;  # 4६ AG ge ey rg f. i & E: 4 3% 2% 4 F go! i? g 4% % $°E EF EB E 4 522 ५ .. £% ६ ४ B44
iat PEE AIE eT COP VRE MATIOO™M AL £APTTAL LEMBIIGR YS Of Leb it
4, 7 Oo 5
GOSRETER 22 5४552:
PAE 445 ६ / ह ५5. 8 25% £ ४4
re,
99% ore Lee COLE
ALTE GIST:
FETE GAO EE:
BA
abe ety pi weitere Uae!
3B *'¢ stg" ney eee s7 Figen 5 Swine wag pee pty Coteepoy oer हट (४ < veg ‘4 an pete tee hs toe atte a ate totes . ; os tate es .
so. mag. 4 Che e t ४2 जी DEBT E, f 4६ 7 Orr: हि ५79 ५ wehbe fu. ol roe nen’ QO Oty et bet हू आन 7a OS . - oe .
op 5K ooo 7G SE fm ET ower ¢ é kde i ASPB on Fh Ye Peg, ae Ee ee OF ie ei Broa cap. 3d ee. aio Es
oe es : te me न
get ote ae prying . cee ee oe "१.७७ ७००००००००५ Daeg ८०; ५ नह "८३-०७: ca 2७७००. cayenne tcp eee ye woe cere epee one eed .
Cpe pee eed bgt pri TEs ४ ee fe Se SET Ute PELE 4 $ LEE FS भाई का VRIES iicrye, 2 2 DOCS est 4 ST eG ee ed hog. thot eet’ fo. or? Do Pro. bas
Eh CALE PEAMTH sti tegi faa 6 ORD Bitton cad i 24%, ४६ ४ hie +3 ng ii tt ett lave it P OTF we DR दाईड FE pee 2: rr a 4 + Avice
vil fet wtay ochre tubeygye ge Pars og 6४ (3४ ४ थूक पर hte seme pegs pte oes ty Soa |» RE stuce BG ४१ ब्रा दी कह... हाट: frye pte pees kt प्रा
ः है *. जद wha GS | ye “4 2! aot 24६८४ ४: 5.4 ३; *, न: eof fb, fF Bec eh ls be by 23 eee by १५ pipes Fed vey wae Snes gine, fF wee as
Dobe wt ay os Lach. Se ogeger tas ee ete eng Ki “44 wget yp aqepele' eree he wr eyes: bps tae: "०००७००००५०- जज 4 9 ७८२ 55०; a eas Lye , ,., ५५ .
a Sade gdb Ge brane Pas td aa Ag Wiastreg ett gee fa, eee Ayr wa elghgiteh wiry get pe ee EE med efit gy eg vocefa Fag pete p 56,
wp? " : हु
Dp le: COE UN bE bd ‘ Lo ie prep ता: degrees th > दाह हाफ yoy “y% foes gy ४272 3 हाफ ट eye cree gc 5 nigh ey ey ७३ ४४४4 ees 3. % Lot eo Br ..7 : : a eo oe
a की एक 2797 55.4 pele: RIS CR Te कद Reger चर Laue SPE | oe a A व 6 आल 72 व दा दि ता हट Pott
titer ph cnt ws sees é हु 5०५३५ ६ ४६.०८ yh wut
जा A कि2 25 एयर गा फटा
: pee 245 ५7% be eevee cto Quarggeyegey
: ४ 5224 3.(75 था £4 <h> yeed PPLE . ..
7 wi 4g 2 UKE wor ०, 5 5. ; ५४ 7.
. ye bp gees कलम yt -्ड y pephegerpe cio acde alecreppeen 04 en peety cow ge dae
, 0 oP PePSpy? up VRTeTYe PPePeryce, SRrZpeR? TPO QPS tet Pep cd pe ie
+ nee ge ote cere peee ree ge ote Speen The note tees ay wane ndgee न्यूज न गढ़ .. sear Peed os. ८ न्‍्ञ ope jack tga corte >
5 vopen Puree y creo crea gh eevee ee peeeoerrey Petar ep GESPYFSP? ait eer
a wee ATED दा OM ERD TED GaSe! eet Py ES MUTE किए :
oy दाल हर्ट: wre "yy पी के *% as LITE cape op pte Spa hep 0 togt cee ४ ib epee gees cegetyegy ey tet ae cee. . Seen
रो “EA: 023 3 ५ हे nid : 44 “ES f 3 टी a mite i % x t दर 4 $e. t : wy fetes: 4, te ५6० oi tly : sft : bok ag we age OF: : Looe RS oe yt ४६.४:९१ fay ee wo er * iia , roe
vz : peters ज्प्ड़ ५ हल ड: ५४ न नए लफ्रीन yn voce wentys vena मी] Coe 4 ae i 3 ee Ne ee Wate tee tees Boos ~ sigtteine
Sa TPS, UD पाए हालात अनार ता ESTATE है ईई LA} PURE O PAP OES pe |
न eg agers ee sere conte: डूब किक द sgregey "फट कक See tp अजनबी अनकीक जल डर 4 अन्‍्टडओी 20 pe ge था, कटे . 2,
4 ४2 ९” ६ hal she ६४ 24 १ «4. “ 5; 4 #549 4.404! ४८ ६४.८ 4: Ny vee wa iy { La TL cf nf ot? e 54... met - 4: fg “pede tt sada bs 4 be 4! penta न oop ie get. Bia 3?
earn et (testing nuwtapsapanrnatin, अर trnelibinrerereen fen tee Fp Benne Bing bye Beg gee :
gb gb: Pyle APE ES Fe ee eS : tee OE Poet टू cen eo et ge oe eer :ः
erty a ए पट: शा 5५ a ee के पड 53 78, ३३ है LG 4- gfe PO tw wy Ft
‘5, a’ . vt
हि ne किए हा उन "कक ds घर tap glare
> AEE j 3 4 i Poser obysi fh war रे ई
ee: wep ty belle eee peed fee दूर Feelin दूत ge beeen Bosley Gy Tyee, Gly e's पु Sey
i a ee oo geaetath <eGe edt Ft दा det A PELS AL MP REET /औ सा: डा eit
bop ca $ cp upeets edly ny bac eg guecebeelly सब्र — copyemly gry bee og इक ee tatge bee theoeee : ८ a a ee ee
fog, Poaper ve TOS UTeT GR ERE PU) TIPO Medy USD Vp uE SERA SU Buel”
. :. boas “soy Doo: no
ton 2 Fig rete ye ef 4
a i a ck Sr a i) Pop
‘
kL

<!-- page 2 -->

-”
mo 2 DELHT GAZETTE: EXTRAORDINARY PPAR i IN |
~“ दल  ल््क्क्नल्न्का्््न््थ््श्य््यरखअ>अ्यथ्््् भस्म फट: फ:ि॥्रड्झाश: जल किए ः |
ae Ga ua पर नियुक्ति के लिये अयोग्य होगा !
उपबंध हैं कि सरकार यदि इस बात से संतुष्ट है कि ऐसा विवाह ऐसे व्यक्ति या अच्य ad पर लागू व्यक्तिगत |
कानून क॑ अन्तर्गत अनुमति योग्य है तथा ऐसा करने के अन्य आधार हैं तब किसी व्यक्ति का इस नियम क॑ प्रचालन से :
छूट प्रदान की जा सकती है। | |
5. छूट प्रदान करने की शक्ति -- जहां सरकार का मत है कि ऐसा करना आवश्यक या समीचीन है ता वह आदश द्वार!
तथा कारणों को लिखित में अभिलेखबद्ध करते हुए व्यक्तियों के किसी वर्ग या श्रेणी के संबंध गे हमे नियमा के सपबंधी से
छूट प्रदान कर सकता है।
86. बचाव :- इन नियर्मा में कोई भी बात इस सबंध में सरकार द्वारा समय-समय पर जारी आदेशों के उनुसार [re
जाति तथा अनुसूचित जनजाति तथा अन्य विशेष व्यक्तियों के वर्गों के लिये अपक्षित, आयु सीमा में छूट a aid Pacae!
को प्रभावित नहीं करेगी।
| 7, निरस्त :- दिनांक 20.04.4977 की अधिसूचना संख्या रौज0 7s Gar
| अनुसूची
रोजगार निदेशालय, दिल्‍ली सरकार में संयुक्त निदेशक (रोजगार) के पद के भर्ती नियम
: Ae 6 ava पद हैया | अभ्यार्थियों के... अम्मीदवारों से.
| 2 2 | Ras fae arg सीमा arate Sera तथा । द
| ; | i पद . अन्य योग्यताएं |
| निदेशक | सामान्य केन्द्रीय . is600 -39T00 । : |
TW wey, 455... सेवा wonfae ery ag aa Be | | '
req |. 5600 /- रूपए |; ! |
| । परिवर्तन... | , ! ;
| | कार्यभार पर । | | | |
! : ; ; ; :
aT aiden of  आर्ती की पढाति ER ef a OR afar
.. भर्ती वाले... gait, aff सीधी भर्ती द्वार. प्रतिनियुक्ति /समावेशन हारा की fauna agente | जिनमे मती के
उम्मीदवारों के .. ag et Fagen ap है तो व गेड Bere सनिति हा तो. ! मिए em ae
fea | राय ' पदोन्‍नति » प्रतिनियक्ति /»समावेशन |. इसकी संरचना... रोका आयोग
! शैक्षिक ।, 6 प्रतिनियुवित / किया जाना है: aap ४ aT trey!
rae | | समावेशन द्वारा ; : हुए जाना है.
oar सीमा. | विभिन्‍न पद्धतियों | :
ue ae wR GA वाल ' : |
Sega ay | fea gel an | | : |
warp |. प्रतिशत ' :
an ad) gerald ae [vera द्वारा... wala Te edi : प्रत्यक अवसर
| | प्रत्याशियों के | जिसके न होने; उपक्षेत्रीय रोजगार अधिकारी के विभागीय पदोन्‍नति ae संघ लोक...
| लिए दो वर्ष | पर प्रतिनियक्ति | पद पर नियमिल आधार पर । समिति पदोन्नति / सेवा आयाग र॑
| | are | नियक्ति के gra de a a हेतु विचार करने | परामर्श |
, | | ' गई 7 वर्ष की सेवा निहित da | Bo faa) | आवश्यक है;
' | 2 aye 2 में 4660 रु? के प्रेष्ठ | '
| । | aqaa afte a300-5a800 Yo Wt Ga आफ साया. :
| | | वतमान वाले उपक्षत्रीय शेजमार , ऑवोग के अध्यक्ष. |
| : 2 अधिकारी | Tea अध्यक्ष. |
: | । 6 (2 Te सचिव | | |
| , ' ' Aan जिन कनि'्ठ अधिकारियों ' रष्ट्राय साजधानी : |
' । | | ने अपनी अर्ह्ृक , पायता सेवा gt | सदस्य |
| | । 7 (कर ली है वे पदोन्नति के लिए FPR |

<!-- page 3 -->

-
a”
yeu 3३ * “ f “VAPETPE + BRMTR A Sr able ‘eS ३
- PARE EN] DELHT GAZETTE : EXTRAORDINARY .
- ee ee een Prk An LAR RRA AR OIA OLEES ELTON DEH OREO EEA SNIP RPAS PIG POOP NA OERE ROE EEEEEODE ED DED DEDEDE APDCOEPOODLEEEE NCH EDTIEE EEE DIED DEE ILE POSE EAOEEEEEL SEED TEE ONCE R EEC EERLLE EN ATERRYE AECL EEL RE RRLR SEE BALES LESIONS ES SE हल डललजिडिलडलडिडटरनट नर न नन्‍+ MEDIO COOPCLC LACT TERS IASON TAA EEAERR ETE TREE EEE OTE! Pere Ren raminninmeremee:
seer e reer rehab TANS Sb MAPAIEE IA CURRIN OO HOT EER S895 OF ADA PRPAPNRAD OE cenenandenernended MO OPODDA pbbbe bbb ene RDD Ce bbb eat AAA DADEOE TOLL BARRDDD ODETTE RNC! OOM RATEO TIEITISEBELEOP EEE ROTO EE PEESPPLEE DT OORERE EE LORIETE LEED EROOLE ME FOE URS AEE EEE EDEL ED AEOLEDT ERED ETAL EL ERLY LE ELOISE LLL LE OLS EE NO pees s comer eeenn sr tee “gunner EET MOOSE MOM DEAE,
| । iia 2) 4 GRE |B. निदेशक | |
: } » . हि " " . न - :
i f 34 £3 BT Be २००३ ४ 5 ६2 (7७4४४ श्र लिए i i
| | अधिकारी भी परदोन्‍नति को fee | plore) सचित | ।
! ; | > , 4 a , . 7
i i 4 #73«.:/% + ४ है २ j न ey “pe carapeagye Kz i ७ जज पओश ।. डक ty “epecdigs | ‘
| | ' / ' विधारणीय हाथ बशते कक उनका | TUT) thei ,
' ; flame 4 orf arse ary’ ferenyeyy oF Ley arr eerreyy fee |
TOT आधाक्षत Stith “UPS aT | VISTA BPR | |
: i ; i | १
: i : ई >> ०० सी कई 4 sir we 202००. / जब चड्डी eg liperpe ३. 4.४ hr» sepegery ag F
: 2 ; | ऐसी अपेक्षित अहक crear सदा | दिल्‍ली NESE | |
| 7 है ° : ;
: ; i to करी ५-2 ar a. -.- सन ah 2 RTE Iy i
2 | (oh) SS का आध॑ Hy ब्टूल जी ४ सच i
‘ : 5 $ ve : : :
i i i 4 peg ge speech yee cr ny poy | : ‘
Al ny RP ay ay ae हा हर ;
i § ; हे ५ 2 : : t
; ; 3 3 acernesg pool yr eee rarer 5 "०2% व्यू $ : i
i p eeB re MPTP उम्र! पड Oe j :
: ; | $ : :
: $ जब आई 7. gt Bete peda og न ey yf :
। : TART का लिए pa UIT । 2
: i , न j any ~ nd :
: : i type f . >>कधका कि. | कट ay ५2००० ४५०० fe | : :
: | | (rare) ap, astra arferepiftal | | :
: : ६ 3 § ; :
* : i : के “yee SEB RTS grocer ee ceper eg hele पट । i
। ' | को साथ सफलतापूर्वक पूरी कर । ल्‍
: : 3 , es i : :
i i 43% ७ 57४५ 7५ +! fy दफा ; ;
: i stele te मर नहर पक; ०८४ % he /०' #] : : :
| ; | OF Fe Pustegsr® | i PES iPod Es Px i : ; :
ः : bat phy oy geadeoug gees peng: तक S| :
; ः | Hane? age Sarre weet ह#ी ै ः
ः i : . i i :
i Ppp yey ely ey i
: 2 CUE ie otf शा; ढ ; ह
; ; Ow i
! i : : ः
ः ः ; ः 5 yf . ; i ;
t 3 : i va Xx ‘ot 4 “4 Seg Wee A 42 Povey i yy! y ५४५ Be eye 4 i न
ः ; ep प्रतिनियाक्सल freer |
न i : ne . . हि on, : :
: : i wo "०४७ 4०:३०. og: y engty ty eeceny oF Beppe | :
; घर सात के प्रयोजन का लाए ;
: [ ; रा st np Conga ल्‍ ( ह
: j i oe 2..०४,५५०५८ ० fe 2 - ay! RT 3 3 .
: POLO 0086 GSR Frente |
i ; 5 z : :
: : . £. ....30......८५... ¥ { clipe cig eee aerppe व agin! i
| : : ; कान्ट्रार वेतन आयाम PF ; ा
: : i ई. ,0.८..५०--७- egy cap ay ated 42३: cep gee Coney!
| ः ः ORR UG Grete cern ।
3 5 : wet i ;
| 7 । | बहन Wve op, prey Re ;
i i i 5 ° ‘ : ;
i i yg veel Scag! oye hte Sip कपल, :
| । । use fee gira) giv ल्‍
| i नियमित आधार पर की गई सेचा :
: ४ ; . . : ‘
; i t } $7 Sg hoe. eolpeenapeees ery )२--८-२ डा i
i । | ae तिथि वेतन आयोग क्री. । |
| | |  सस्तृतियों पर आधारित लागू. '
' ' ; OWES Te 0 धघलसमझान #े का ः
पृ ‘ : wis ; किक sage ane lyctw- yp taeg song. canehy. pees gta eget Oy न्ज्ड्ज हो oT i
| i 2 : ong Gar मान ली जाएगी। जहां | |
i + i i : है . : i
५ £ : i : . edhe Ee 4.9... +#३- yt oped ow : j
| ः ः | ag cmp went wep २ अधिक |
| । । ye छा fg Fg 2
; ! Oe उतलमा नल Sled Wop ag मे |
: : : : ह i i .
; ; i फ्रेश sessayage sstepinipeenge कि ५३... जज Soe | i
i 2 किया जा घका हैं, और जहा थ॑ | '
: : ; : ve . . + है :
: : ६ नाम छः fore seerrege 4 geapsanmpete आओ | i
| ; ; लाभ उस उन OO ee | ।
: i i : ; i i
: ; § s apy : can, oh tm, 5 3 z 3
: £ i 5 4 whe. ter . AT nf oy ये gx 4 heap : :
| , fea ही विस्तारित हैं जिसक | । ल्‍
; i : ; 84, \ * कप ४ i ; ;
; | i | लिया ge we dan 6 wea | :
fone, >> " ef med :
3 i लक toe Tey ४8४7 wag “oy LTT IT ary ४ : :
। | | | किसी प्रकार RH sows का | 2
: । । | बिना स्मधान्य प्रतिस्थापनल - . :
ps कं ः ः
: | । | Prraie) te 3:
| ! | | इिटासम:।) TB । | ह
। ! po ः
5 न्‍ ; | :
ः ; प्रतिनि यु Pex | |
i i %६ CSTR थी, ; ; ;
: ठ peep / रा: eae & संद | | ;
; : ; ल्ह्शालजडड ००००० » by न fantty pang ! i i
: pe Pe Sa ap लिम्स लिरियित ; ; ;
ः ; i ee £50 ro sor ee . i j ‘
| । | आधकार!: |
. ड़ : 3 ४ t
5 i K 4 i cn wep Chopper ॥४ i |
| 2 के है) मूल danse में, । '
: 3 ; j oe a ’ i :
: } i j £25 enpeep yop nce हल fF oe cr ~ % eeeyor, ove | 3 :
2 | नियमित अधार पर समरूष पद | |
' ः ! | 2 रे fogs eee I :
2 । | | भार | बाल ae ; |
3 2 SHR 2 FO magn 6G wp bs | :
| ः ः ; me ह
: ‘ : = “ >> 2७ ५ - ate ot ०१ ME . ey 3 met oye : : ५
; । FS BO G300—B4B00 MH
; ः $ अमल A traits आधार tre ः :
; ; क्‍ | Eyes #3: ng cenpmegengtrne bey vie | i i
i | | | इस नियवित के उघरांत te में | ' |
ः : ई 8, 0७ करन ona पी peeey स्‌ fia ५: ; ;
| ः | | apr owed Og बच का सता साल्ल। | ः ठ
: ( ! beat deep oye ओके करो बडे | पक coer | ः i
| ! । हिंद) राजागार सेवाओं थे 3 संध का | 2 j
i pA? i i
. ; : ६ * s, i i
: १ i. { ami tatenne ap yet segeqeenatty : ; :
. | ई  अजकात ge Or
: i ; i wt . . om : ; |
i i toh, 70 के “ye आल तक लत 3 ;
2 ई ः ; रस aye) oo Cie ,
: : | too, 3077 aa ¥ थक £-->- pyrene १ | जटिल. 2 i E
द । । | अधिकारी जो कि परदाननात का . ।
* : : gE हि : : j
. : i $e gs श्र * ccseeces ae fete he ) hs bey : : §
: ; 3 १९६ ८: 5 e . vy ve आक Seer + : :
: ै i i fa पी आखला कह हैं ते प्रताजशाक्त : : ;
! हि ; “* कि - . eee of : :
[ : Pope PO yy dn re oe tas लड़ा सी i
| न्‍ | वर नियाक्त हट विधारणाय नहा | ४
) , |
5 a
;
j
woes - a ons ,जर22०0०००००४+४५०-००००००००००------न्नननन्न्ब्नबलब गन = मी टडड हल हर नल चल
हा
ee ee

<!-- page 4 -->

| oo
4 DELHE GAZETTE: EXTRAORDINARY * (PARE TY
, | वाले भी पदोन्नति द्वारा मियुक्ति : | |
द | | | eq विचारणीय नहीं होगा) ; | ' |
| | | | (प्रतिनियुक्ति की अवधि cea) | क्‍ |
: / : | उसी या केन्द्र सरकार के किसी | : | :
। ' ' | अन्य समठन /विभाग ने इस | । / ४
द : | : faa से त्रचत पूर्वधारित किसी | | ,
i | ! अन्य गैर संद्ग पद में ! | ।
| | :  प्रतिनियुक्षि की अवधि भी. | | |
| ( : | सम्मिलित है सामान्यत, तीन वर्षों | ' :
| ; |  प्रतिनियुक्ति पर स्थानान्तरण द्वारा | | |
| : | | नियुक्ति हेतु अधिकतम आयु सीमा | |
: | ' | आवेदन प्राप्ति की अन्तिम तारीख | !
: | | ap) gtr 56) वर्षा से अधिक | |
| | | : नहीं होंगी | ' |
: । : टीपए.-- परदोन्‍नति के लिये न्यूनतम i । |
2 । : | अहक संबा की गणना के प्रयोजन i | क्‍
। 2 के rh orjtzcog से पहले |
| | । ' किसी अधिकारी द्वारा नियमित । '
ल्‍ : । ! आधार पर की गई सेवा जिस |
| : 6 तिथि से छले. केन्द्रीय. वैसन | |
। : | | आयोग की. yeaa पर | क्‍
ः : । / आधारित संशोधित da २ ल्‍ | |
| | | आयोग की संस्तुतियों पर !
| |  आपारित लाश way os | : क्‍
| | 3 Of qaqa में की गई हवा मान | |
क्‍ । : ली. जाएगी। जहा पर ge :
| ok । | emia ove 8 afte | :
: । : aqme oar विलय साझ | : |
। । । ag yarn सहित एक ग्रेड में | ल्‍ |
: | ' an उस / उन पद #& पदों के. i |
| ल्‍ : | लिये ही विस्तारित हैं फिसके | ।
' 2 ! | लिये यह ग्रेड पे “वेतनमान किसी : i |
| | | | Gp के अपम्रेहशन की खिना [ ।
। | : | सामान्य प्रतिस्थापन rapa) :
i ८ Lb ogbeg OF.
जिलंदा area, agua gia SITS
DIRECTORATE OF EMPLOYMENT
NOTIFICATION
| Declhithe 2ist November, 20d
| No. F. 6 (35) /EMP, (Ada. ARRS.A07/47238.-—in vaersise of Ulo pawer conferred ba the prevssc Ca airtien: SOY ol
the Constitution tead with the Government of India, Ministry of Home Affairs (Department of Persanuci and
Administrative Reforms) OM No, AB. i4087/)2/87-Fst ORR). dated [8.04 }988. the Ct Qoverner of the National .
Capital Territory of Delhi, hereby makes the Following rules regulating the method of recruitment io the post of foie
Director (Employment) in the Directorate of Employment, GNCT of Delhi.
.
en
गण

<!-- page 5 -->

wer ‘
; ह PART LV] DELHE GAZETTE > EXTRAORDIMARY )
i vinoe ueeeacnscdenssecsiverneisiasanss.desmeansnsesnetasasestiesennenasensdsestsis4stiapesuprermansiessvenvansancagesssesseabestIAIHVOHIIAnEs40WbAALESDCUDLIVISSICGLEIRAA!SPOCAAEDRUUDLECDOLCOPTTACUADTLLLL SIDE POLED OCEPOHITEAETSES TAAL DOUDSASSAMIAMERELOAADYSALTMEDDDELNIOLAMMLLS00OG# CHEE AOUCPDDDDAADBORCOLEES DACCPOOMIETL ENS IEA UEEC EATERS TTT ४० है.................... ० लहर हिटलर हर टजलट रन *
i Lene deC PARE PUN EN Uda AAA EESPAMED OAALED LAREDO ORDEAL FEL EDS EEE EEEEAERA RET EE MD AE READDBAELL BLED DARL OORT A pmnebe DOE REL OR ARRRRS ALO ns ree EEEEOEEEDADRERE | GEL LEDLIOOLEE TOE ED. EF UREA AEOE EET E Bae १ *+१ 200२० *०जजूल Pappa date rDAAPDPPPPL ELE EEEELLRELEBPLP OE PORE = BEE EE ORR ORE CELL LDDD AL DOD OLLIE कक २३7 +२०२7:::५१३३३३३/८2क्‍//2:/4 2:::::4::2725 NAMA LL LALOR LIOR COPA AE AABA DAL ADL LEO POODEEEEAEERL Abt EELELIDE ORL T ELL EO ODEO RG Hs
5
3
2
i. short tithe and commencement.
’ yyy, ee to, nee 4 $ e $s 3 ६२०८५ ४5 $ ,», ००» & & 4 2० aan bege. en ४ .,.,५ ७०८ 9८,७०७ ०४ २ ५ £ 5. कह ८६६ 255 ४ /3३ ४३ ४ 4० ६५३४ ¢ 4%?
i These rules may be called the Directorate of tangloyment. Joint Director Chipman) RAS PULUTACTIL
Rules, 2077.
ft Phe rene sh ahi ecyyrien G3ttee Reyer saith vad fips i fipgaysy fines /(६०३2५४.- vate i wae ets Fs; biveaticors ite Pediat { pe aceE tao
हु is. j Pe’ EEtEE COTTER PLO POPS WEP ae iagtae ZPCRE.} Lie? cede Ob ECS BPs ube ab sCary PLE GPE sateen,
a Number of Posts, Classification and scale of paye~ The number of ihe said posts they Classiicaben anu ine
cogent cad २५०५५ 066% ache: ५८2३३ /५ ० ७. ; ६. 20 Eee S sgt nm colirins ५ ., है 4५ aE th © ५
| scale of pay attached thereto shall be as specified in columns (2) to (4) of the RRs.
“4 2 3 ४ £ Pe | ५३५ ‘ : x 4 "Fh, go 2 : tr “५ ct +i . ee ४३६३५" rie * a eyes et ‘ * < S
3, Method of recruitment, age ~limit , qualification, etc. -—ine method of recrummeni to ine Said posts,
ALY: by $ t . 42%; ४ +43 ह a . che Yet } re 93.9 ३ ae a ar 4 ibe “८ $ १ iy ong § j 6 ree OPE + iS & ५ pg ‘ 4235४ £ ५ आम “4 है पा (
ARC 8, QUAL TIC ATION and other matters connected therewith, shail he as srt ied iy columns (4) t0 (73 J of the
; tinged ff 2 .
sad RES,
& ‘ is ४६47: : NE OE ae
4, Disqualifications.——No person |
a: W fy 4s has en er aed १ rics OP Com Lract i. 5 OITIGRE Aa ६४ Pix ce pygerrua ary Petey ETEED TE OSGTSCR LE Oia? 5402 १३३५४ 327
eae if, ks OP Wha i FL4t §32 REFERS j “se nA cA $4 ti f ६4:४६. as ht i ak i 2074 “४ 2६ ह 4६६5 % ६ £5 be *t : CBG a 4 j ¥ SE $$, 435
fe, 3 ‘ My १९६ i 4 - 4१८४ 8 ME ae et ES rh ; iar ‘ 25 ४4 by tex goeat ey ag | 4 £ : ५ हि tates yd gaet oy eee rr "Sober ae : i Sp See POL ETS a Vee } j ; “pe a’ : i “3 : ri it Feud
2% 3 A ६44 7 Vhs Se a 9६% १5६५६: 44६ 4 + se é 48s 4.4 ६59. ? 574; het? २६ RE RELE SAL GUA] Of 44२८7: ४ 544 ६६ $. | HL L 8 phe i ee $y é. PELE 53 { “4. hae kei sh. 582८६
"२ ७३३०-७५ | ४५4 ३०४६ ar; ,5 ४६ 3 "425८
APOOHVUTICTL LO Una sdigs POST.
j Beane dined thyere tines £ lesergarasgepegeinh ree! TE neg 8 है that wick uniareiagse 3४ 2४४४३ ६ ८० ३ १७६ ४? dase tiie FOPEr ET: tones oS FAP | ३22 हऊ
Provided teat (he Crovernmicnl fags. PP Ralisiive Tidal such iar fake TS PCP LSo One under Ue personal hS38 GOP Cao
: woul abe ७०५८४३०८- ८ age ५, ४६... , ४6 इट६ ६६ bn उकड उन्‍इ3 2) 2033 amck that there oe tet bee ngs aod « ye gen begat: छा ae
| PSLRA [37% 388 2874 ine other pea PE y if) Le STGITIAge area thal there are other RPO FiGS for so Goute JOXom pt ans
| persed from: the opemiion of bus fe.
>». Power toa relax. Where the government is of the apmion that.it 8 mocessary or expedient 20 to CH GL TY DS
| arder and for reasons fo be rece ded in ow HIN, reiax Any CH TC PYayvisiOons OP THESE Viubies WHY Pespercl Tou Glass
OP UMICHLOPy OF Persoatys.
है (१, Saving. Nothing in these rules shall allect reservations, roluxaben OF क्र: limit and other concosstor आप
iy idee? $e ¢ phan agrees tig ie! 4 eregah gen tee ब225 विस 4 ६ ६ ६ ghey: <; 3४४४३ (८7 bocce २7५ ene 2५94 ८ ३8884 87 4६० pad Peer errs pe 22220 3/; ३१ /४८६० taEEEE ; i 2
६५१ 8 १४४) ४ एव 9 2 ६7४92 0४ castes, ine seheduie tribes and othe APC COLO ROTIOS 5. EPS OS EPP AL! dance AEE Tc
- ४०, ६५०३ dt ४३,४४६ १०५५ - ef ५५३३ ०००४) ६ ५५ ५५४१२ ue pts cemtes Gay tigwrar ies Fea weeeeopee
order festive dd ys the Central Government tran tutie to tuvic in ins roger ih
eH DULE
4 RECRULIMENT RULES FOR THE POST OF JOINT DIRECTOR (EMPLOYM ENT}
| Name ot PNol gh | (lhaseivication Pay band A | Wheth i Age bimil | | ueational ः
| Post | Post | /tyade pay! | Selection or » for direct oF & oiner :
| | 2 ः | Pay | MO Scanian Speeds | (dualdivauorn |
| ' ः | : sealde i Passi pfu ।
ः ; : : Lp Boyes i
i i ; ; 8. FRM) SALEWCE
। ! ; : | recruits |
‘ ete. geveve. बल टिकट हट कीट कक क्‍क्‍7क्‍777 गए हिट i 7777 oe wet ole हि दा 000 शा विश प्र हढ०वववव्नणननन००० ० 4
| i : हि i 3 i of : हा ; £ i :
है weg cee ceceees cee eens -.०००००००००-००-- जलन जलन नितिन लललियिततिजिधनिनिलिलिललनल ललित िननीनिनानननननग inne BAAN Mt CT है "गढउगर३म2०2०००९००००००००३०००००००० ०» दे ५ >> >त० census रे : Lee . . cee etree
Sot ae PR geaeebenee ; 8% f 3 bos प्र ० > 3 2३० + ; ee % : Mt sks uh tray : %, ४ : ta 4 .
| dom Director oe: CHOS group a PER. s Gl : he 7 : ey
(Employment) | gazeled PRS. LSQU0. | ह ।
2] वा | ' .. 3968 हक | | 2
; tO Varah | ँ ; Bay Bettis | . ः
odepouventon | ः ! : [ ।
en ee : ; i ; ः i ;
ना es ee ee न ERRRARE TEPER TA SRNR OAR NSONAARRR ete eee Nene aN RR OE et cee RS ceeeeteea tte हाल 8 get sores tetae eee
» OAM * be “> : { ‘ $ ८६४० A i 7 i gn . : + ke % पर ng gs oo : i pas 3 : “os धर पु sy : . react gE eR a 48४८" रु : ;
Whether | Period Method ofrectt. | In case of recit bs if a PO east » CTs aaces |
Age & bagi OF prety, | Whether by » PPOMOUIOTY Ue Pan alion: | What is HS :. 4 $ 75, ६3 ः
| : जएडएापकएी वा ans | Dread | Absorption grades | COrnpostion PS |
Re dea | | Beoti ap by i frormiowhich promotions : un is .
PONTE ।ं | ROO | deputation/absorptien to : ESTO
पर Dyk) U8 : ६ हक! ६४% depulalion by Tue : : ui Hak irs :
मर bo: a £ 3. ७: ७... ७, ३४, i Sages ey ;
oan thar case, | absorplion & % : ; PRCA, |
PreNtees: OL HME VACanCies | ; :
: : z : ‘
: i Dog Eo at tty, } i 5 .
: ै tt oe titted ; ै ै
; | । | by various 4 : 2
: ! ि | orathods । ; | :
[eee ee “४५, १००५ «» fae se eg "जन न हनन न लिन निरलटिलर नर 6 हा हि १ तह फटलललडडन >रलिटललिन तलब रह नहर हब हित हद जड़ हि टच चल न्‍ 77777 77080 TS AA ES गन न wee eeenenne greene eee ® tobe . का है. 42444 साडल#वटू
Os | Qo i । Hy : ha 3 |
: if +$ ४ ५ .: .७४५४१४५ “yg ot wages zs ~ 3 7 G ¢ +, ti Gj TF Swe t ge eNO Late ० 4 ‘ht 2१:६५ १४ at 7
| ONA 2 years for | By promotion ; Promotion aroun “a LPC Chor) Govan |
। | यश एश६ ५ वितिताए जीत 9. 5 किन सका 00796 ७78. conser” | छत 5७ |
. | deputation _ officer in the scale of pay of Rs. promotion) oneeessary On |
beeen ee eee eee parece ५ 9, ot ceccecuesseeeecererenehornssens cacsebeamemrramegeprehdeedctie WPbbAeLeLEEALEE AMER ALLSANDAERE SABA eA“ AbD heh nedmrn eI EE UREN ERENT हट ११११० ००८०११५१ ४५०१४ ७. हड 7३४४४ ४४अटडलडडडलडलिडशज 5 eerveacSbepevesaccece ress cepececeteedmee dears care ee Wie A ter Reap Re eee ha ed DE Rite Ammen abbE bt ata esse senses . os हज HTee trees cere nee
2 >. i ate “yf } . .
: | é ‘ § co 22...” ff f we hom
5 éo¢
: 5 £
: "00७०० कफ पक लिावशकापन नकल तप चलन पलपल 2232002000.3......0७00५,०००००३०-५७०७०००००७७_्यहपक बटाकाददादातदरवरतरलगवकलबपचदकलककका कप द पहन लि विद पदकिताललि रन टन 3......५.५५..५०००७७७/००००२नवदरवकत लक ब्रज ५ कनमरनाजजन्‍भाजरगरनन पजरलरनगर सर लिन न धन जि जन लए धज थ५ लग टिरललरननिचिशनिनननल ना नि -
a
ee. ee ee «७ न छऋषषौणं € नााएणऋेेऋखआख ेें ऋे ़ऋे़़एणडएछण

<!-- page 6 -->

; yoo: : है
ः , | -—
: 6 DELHE GAZETTE: EXTRAORUOINARY [PARE LY
; 5  अ्््य््व््व्य्न्व्श्््ध््््य्य्य्य्््र््््प्य्् वल् ्च्प्च्च्य्ल्टल््््य््््य्ख्््ख्य्््ख््म्््््ख्य््््् ःखख्य्ख्य्य्य््य््शत्स्स््ट्टटएएफस्‍ि८५८:-््फ्फे:य्क््स््ल्््््ज् लत
i an)

; । : ; G300-34800 with grade pay of) = 8A OCCASION ।
i : f “
| | i Rs. 4606 in PR-2 with 7 years) 2. Chaumen/member | |
| : service in the grade rendered) of UPSC | -Chaummun | ह
| | after appomimen! thereto on: : ।
: : | regular basis. (2. Chief Seerciary. |
| 2 “Nete to: where juniors whol Govt, of NOT of. ।
/ | । : | have completed their, Delhi ~Meraber | :
| | । ' qualifving/elipibility service are 2, DAPector : 2
: j $ : ” » i . f Pn + sos : :
। | | being considered for promotion, (Employment) ' |
: i j : ४ - ,
| | | छाए seriors would alsa be | SECT ALY ;
' ल्‍ | considered for promotion, they; Gimployment: Gow ।
: ‘ 4८ : j हु .
. 7 | | are not shon of the requisite) of NOT of Dein: | :
: | । |  qualifving/ cligibility service by) Member | |
| : j ‘more than halt wok | | |
| | | | ifving/eligibility service: or. | |
2 । ै | iwo years whichever ms hess, and: ' ह :
} । ; | hase ucgessfully  corpleted : :
i ! j : , “ . : : :
: | " ः | the [भ5 24.6 फिट एफ. | i
2 " ः -premotion to the nexi higher: ' i
; ह | | । grade alongwith their junio: | 2 |
' | | who have already completed । 2
| : | । ; हक) qualifying/eligibility | | ा |
; ः : | Note 2: for the purpose of: : .
न्‍ । : | computing minimum qualifying | | |
। | ! ः service for promotion. Phe: । |
है ल्‍ ' ः । service rendered on a regular: ' '
हर . | / basis by an offfcer prior to: । |
है | : | 4.2006 the dave from which: |
i ' । | the revised pay structure based | | |
: : । | on the recommendations of the | | ;
* | ; । "pay commission. । | |
है | । |“ Deputation । । |
है : Oo । Officers under the Central Site: | |
| : । । ev fy fan hy holding '
; | क्‍ | analawous $3 ४३ & regular | |
; | क्‍ : | basis a the paren: | |
४ 3 ल्‍ 7 | cadresdepartment, 0: ' | |
। 2 2 : GD) with 3 years service in ihe: ह
| | । ः i grade rendered aller, |
re | । ः । appointment thereto on regular. : |
| ; ' ' कद in the scaie of pay of |
| । | Rs, 9300-34800 with grade pay | । 2
: i 5 : | t ‘ ;
ट : | ; oof Rs. 3400 in the PBed इस | ' ह
। ' : ः — equivale: i h parent | | । |
ह ' | cadre/depariment; and ; |
: ; : { . , : : ;
: ः | (it) Having 3 vears expericnee | i :
हू : | 3 in employment services, । : |
| । ः (ithe departmental officers in| | ै
: . | । | The feeder category who are in| । !
: | | ट direct Hine of promotion will | |
; : | | net be | Eligible छि | | |
4 : | consideration for upprointment | : |
है | ! | oon deputation similarly, |
है | । । : | depuiationists shall not be | |
* ' : : éligible for consideration for | | |
R : : : ‘ . $ : :
: | | : 8॥४ताह्ा॥ओ by promilion). : :
है | | ट (period of deputation including | | ः ह
हे | क्‍ | —pedied of deputation in another | 2
थे । । _ex-eadre postheld immediately re
® :

<!-- page 7 -->

=
nad .
; 4. | ४388 ६3) ४) 8 / 3. = DOR Fa pw S4LPE ade a te ee a
moe : ५६ eo é go. रत § 3 ge Ka ba LR Ga EE «5६ #र्द ६ :
Raw | > Mg Be UE LE EG «bene 2, EEE, . रन 4 45%, / ६५ 4 £ f SEAR ४2 4, ¢ $
३१४ 7४ क्र ईद # हु. 4१4, ater sl rsirstpeiad ogee.
४ रु BORER GEP EE LDPE ३ BALIN AEE SEPEtatTEE FFE :
5 P4 ot FD a >> oa ue Lage oe “3१३५८ ०४ ’ ;
ifie SAE TPE Lad APE ER ee i
. gE ERI Kt i “Prk t j Shs fe ty Oey aged (६ ४४४५६ oy 2 रा | ला :
. REE sett RES Gab S TIT Naa ES CEEG RSE RED Abas :
eee co . .
: a . हि 5 . a : :
Doe Sako EO. 4 sehen dd "७ ३७, 4 4. यु ' :
. : i*% + is Z ee aT wear e bt PEP sta eecag ria, :
. : RESTA tree E 5 I shi LabaabieegP iby: ;
. :
: 4 दर Oe
: 6 ee yf ४८४ sh ate pegle ss Mptemees ४०४० ०२४०५, 2 3४०. .> : :
: ; : Karl Lge ese RNA EERE YEE 5४४82 : . :
+ 3 ’ i :
| AYPANM ETE ४:34 reget rt doye :
: DR EESA A ESEELEETS na BA eseesad a  : . :
: : : Sy : tens > + : “ पर ; .
. . : ‘ ay ¢ 5४422 5८.० mae eb. “Gab eee ०४ ०: Gernayy ‘ :
i ः 7 SR EREMGETILELI EPIL | Fre RPO PELELGRETS PEE *
: . ‘ 2 4 4 दर
: ‘ £ :
: है ः 4५ | Pape Pie's bogeys ES ड़ vy 4 $ 5 2३२ कर Fob pocpeene ot * *
: ऑर्डर 4 $2 0, 87072 ६ Rte res Plas Es ५, ८ ८११४५ : ः
: y ’ 4 ‘ :
af पर : Lowe “ g * .
‘24 Day i eens 44:9०" १५३६८: een ton धर ‘
ke ६353 LEER at babs irri ciate LEP ;
: दर . है ep t gs : ret tt ५22२5 4 : : , «5.94 २०2 ५+४६ ; ः :
‘ Lee tee Fgh Let LES EPL IA eth} gBes :.
है ye . 4 2 + $ . 4 ६८ 4 be * ४५० ३७०५०. . , . Le,
: z 2 2 gba Per gh hse pale ty: : :
:. , 48358 5 £633 44 44... ३. 4.६ pas nt wap:
3 ‘ .
DK peat tab ype ६०६६ 2 La deve c sbeebs cee :
: ४१775 ५ 7२४४८ ५६०४५ २ Ly PegyegiraZ ists;
if he Posey Ps tae ett £ 53; piesa eh ५ 88: : :
: £ £ छा 24579 beaut the caore teas
PORE Teh ee ga aa es SET, 4: 45४ 5, £ # ६5 $.७
: है अल १0८३3, , व 5 #॥+ ४4३ 0३. 9-७. ४०७ +७ ३ -
: ; PEER Ae Pad 4 oF on ERE ELE GE i tensive LES :
: wage . Looe ee .
Ser gab bare res 2227. ०६ tg beighy,
meh RFE EGRESS fit £4 £६ bk a ae ARTES,
: t fob. $6.4 See .....५ ५५०६५; ०१ wha, .
; (६4६४ इस trap adioch the
. है : {G3 4%, tee Be By 3, May Te wea RS SO RAI BL fot he :
. ४. हम pag ad rent ie ई224 5८ ३ ६/८35% ७०४, ३६, cd ry ry
/ : : : ६ USED TMED GSEP iO LEER? Seba EE :
: : ; Bie :
> oad , fied go‘ Eos ' . + tees 3 oe
2. 2४ (२ 7५:४५ pee 20:७८ ४४५४३ 273 ८३२८४ ६ # 4,५८४:
:. 4६2+9 4, eats रु 45 Daw ASP ep tk, t iad wan bhi; :
: : . 3 4 ++ ४ 24 * :
: : Beige ज्कि, 3०४४९ 8३५२३ २० ३८.०० ट - ५ 45 ६४: ६ “he
beady aE TE ake Late gas CG ‘sEteiit कु
: ; : ? ५ ५८४ % fy 3 : 4 ः i
: 2 : Cb tee ZS go ४ 3 WERE Dg tee see yy 4,-०१9"८. +८ २ :
: i 2 ake esed fer fab ‘EE ५ ५,5. TEES ie Lhe :
‘ * bo 3 3: ५ :
: : . : iM Bb terete ate ery cts ga ett ty :
: , GPE 5535, RESEDA te aE Ee Ee Shi cake,
. : , See “ae! :
. ; + . 5 “* :
: है Rey eee ४0. कह 758 7. beep yom cd 3
. wake SpE YY 55४5२ ३३, eR TLE ES bea ke
२३३३ Grn radesmurticricd adie of thee
: | कट: ४६54६ FM EEE Ea CERGLEL EE Fotos LOE Ltt.
Denese PEA BEL Le atletpe ots wegryt ५४ ४५,३८०:
ह दिए RGR PRT TOE Taha ६, ६ ६, 4. 4 7), ५5 ae a,
. i a 3 .
: : ft 4 . :
: Lo 2b:s gst ats: शव ल्‍ शत Praysetcycee of pee ete peo
DRE ERD 8.६ 35% 8 88 828, ५४६४४ ate 48:73: 4 ' *
. sae :
. :. 2752223% Seeger $33५०,, :/४५ 23 ५४ ८२४ gow gdor i380: :
: : : dphelif ता रत Pa ep REL pew chit 423 :
: : पृ :
. Vasa oe Le great rege, bee Lage at ot . :
Eds PEELS? GPE GSP Tp 85, wis bei b bh
(OLE RRE DLE Sg ६११४२ ६88 724 ६282. 02.2 7.  /%क ६३६: a  !#ु : :
:. $. $ ६६5: j f £3 2? 73 waa’ pelb eB Fe. i> wae Re . है
: ~ ae : “ + ’
. ८ Da ad . a: gh lo Le. tg ae
i “594५2 RROD ee ct gore ah Pee ge aT eal tags
. : i ughin3 eV ERIS Eigie qe Prat 2 ft ६5 १25६ ६
: :. ५.०६ ६५ ३०:८८ 52328. nae FRY ३25७ ४०१३ ७३ fesse
’ te Ds bh EEL seedy ६87 ६:55. peau ५४ / १६2; *
. Lek be ; »% ."० ४ ४१.५ + |; we
४१६५3 ६707६ ५ 5 55485. bak
a : :
. : gee a 2. ८ १“ ५ $<? Bae i ftg% Cte a0 gery as :
‘ gota & ee BED aa? tet ote eb s St teas :
: i जि z - 5 ; 4 :
: ; PEO ME Ek tet eee pein do csgecg tye 4 ६722४ ३६45 ना पर
DER PERG ELST TEL ०. 68868 GREP Pecue dh ८5६ bes :
. : j * tee . हे :
हु 47 25६:७ ३८३ vies 4० Yt :
. D ORSDPRLE cbhaceh cas fat. :
Pe goa Sb rt & wt 4 5% A Lh sf oy: ad ‘
bE Eg be ५४८६ bay *% “Ete PE Ms eee Se १३७६३. 2 3 4795 4, ८:४6 2 39. Mees Vie yt eh aged,
a ar a a i ० « $2 ४, ५ Ss peu Pe © TREE 4 १ ६8... है j wet Rk Ft ? re i +t}
, .
5
z
i
4 Pecpttyrch bay thee RA ar age yee ही ०२९, . कफ ereseeet ko ben her TB egg Pr realy 44 2४५३ ME yeyy igs Fy anee Eo toad be 3 ४६5८,
Ks PUCRPLU GT PP “Tig RPRADOT fosthaccrriint cet पाए ress. Miia Boach Aday thePish a, PRAIA PE bre PPC posed
FS . wt . छः प्र :
a ३ ४३. ६.: . ६ Le +3 a tt ४! ४५ 33 ; ४. ag ! :०३/६५८ ४
is ४20५४ ६3:४५ ६७ +/: ty. bh. wit * bigeye ged a2 beh p cepts cetae : १.०१) ,  + ::३/४०. .
of miigd t ११३ ईद हद 25 वि, | aRPELVeipuy 7? 2 WESTER E HES ob dytiliie : GUIS
|
'
7
Bt
bs
ys.
Bee
a
