---
doc_id: "cecf54be1ed1b2b8"
source_url: "https://dfs.delhi.gov.in/sites/default/files/Dfs/circulars-orders/form-u_0.pdf"
ministry: "Department of Delhi Fire Service"
title: "Download"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ec33af041700522c"
---

<!-- page 1 -->

FORM ‘U’
[See rule 35(2)]
APPLICATION FOR REGISTRATION/EMPENELLMENT TO ACT AS FIRE SAFETY
AUDITOR
To

……………………………
……………………………
……………………………
……………………………

Photograph of
the Applicant

Sub: Application for registration as well as empanelment to act as Fire Safety
Auditor.
The undersigned hereby applies for grant of or renewal of registration as well as
empanelment to fulfill the requirement of DFS Rules (Amendment)-2025to act as a
Fire Safety Auditor in any building or part thereof. The particulars regarding the
Agency are given below:
Personal Attributes
Table-1
1. Full Name of the Applicant (In capital letters)
2. Whether Fire Safety Auditor will be a Proprietary
Concern or an Association of persons such as a Firm or
Company, etc.
3. Registration No. of Firm or Company (Copies of
Registration Certificate, article of Association or
another relevant document appended.
4. Address

5. If the Fire Safety Auditor will be:
a) Proprietary concern, the name, qualifications and
address of the person operating the same.
b) A firm or company, names, qualifications and
addresses of each of the partners, or as the case may
be, Directors.
6. Office address from where the Agency will act as a Fire
Safety Auditor
7. Bank Account Details to receive the remuneration

1.
2.

Technical Qualification and Experience
Table-2
Level for which registration is applied for
Personnel with the Agencya. Supervisory staff, name,
addresses of each.
b. Other employees-names,
addresses of each.

qualifications

and

qualifications

and

<!-- page 2 -->

2

3.

4.

1.

2.
3.
4.
5.

6.

Details of work with regard to fire Prevention and life
safety measures, if any, undertaken and executed
previously.
a. Name or nature of work.
b. Whether the work executed or still in progress and
remains to be executed.
(Note -Original or attested copies of Certificate of
verification of above details)
Technical qualifications
and experience of the
promoter or partners of directors and dealing
technical officers or employees of or with the
applicant.
Professional Attributes
Table-3
Whether enlisted with any other department or
Organization in any other State. If so, in which
category.
a. Has the applicant or his partners or Directors been
blacklisted in the past by any Government
Department/ organization/other State?
b. Has the applicant applied for registration elsewhere
in his name or in the name of partner, Director or
firm or company? If so, whether the application is
rejected? Give particulars.
Whether the applicant has produced up to date
Income tax certificate.
Amount of indemnity for professional work as Fire
Safety Auditor and date of its validity
Transaction ID/details for the fee remitted to act as
Fire Safety Auditor with Authority
If the application is for renewal of the existing
registration, the details old registration number and
the period of its validity.
Whether, the registration to act as Fire Safety Auditor
granted
anytime
previously
has
been
cancelled/blacklisted; and if so, reasons therefor:
Check List and Undertaking
Table-4

1.

2.
3.
4.

5.

Attested copy of partnership deed and power of attorney
or articles of association and memorandum of association
or undertaking in case the individual is the sole
proprietor of the firm.
Attested copies of education qualifications to act a Fire
Safety Auditor.
Certificate regarding experience to act a Fire Safety Auditor.
Certificates regarding satisfactory completion of works
carried out for the required experience period.

YES/NO

Attested passport size photographs of partners or directors
or individual proprietor and also of the professionals.

YES/NO

YES/NO
YES/NO
YES/NO

<!-- page 3 -->

6.

Undertaking, stating that his/her firm is not blacklisted by
any of the departments of the State Government, local
authority or any board or corporation or organization
owned or controlled by the State Government or any other
State Government.
7. Address proof of office/branch in NCT of Delhi.
8. List of technical staff with their qualifications
9. Copy of indemnity for professional work as Fire Safety
Auditor
10. Any other information and/or documents as may be
required in the form ‘U’.

YES/NO

YES/NO
YES/NO
YES/NO
YES/NO

I/We hereby solemnly declare that all the information and record provided in
form ‘U’ is true to the best of my/our knowledge.
I/We hereby certify that I/We have not been and will not get myself or ourselves
registered as Fire Safety Auditor in the department under more than one name.
*[My previous registration number in Delhi Fire Services ............................ for
level… .......... ]
*Strike-off, if not applicable
Thanking you,

Yours faithfully

[Signature, Name and Address of the Applicant(s)]

CHAND
MEENA
