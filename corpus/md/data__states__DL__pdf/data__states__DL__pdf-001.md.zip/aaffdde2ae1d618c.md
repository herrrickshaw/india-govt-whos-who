---
doc_id: "aaffdde2ae1d618c"
source_url: "https://delhiarchives.delhi.gov.in/sites/default/files/archives/circulars-orders/notice_dated_17082026_0001.pdf"
ministry: "Delhi Archives Department, Delhi"
title: "Download"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "cc7a3ef1e5754ca6"
---

<!-- page 1 -->

EE —— a कक पिन
DA? 39/2026-Records-DELHi ARCHIVES 77344372026
| DEPARTMENT OF DELHI ARCHIVES.
a GOVERNMENT OF NCT OF DELHI
5 8-A, SATSANG VIHAR MARG,
SPL. INSTITUTIONAL AREA, NEW DELHI-0067
= E-mail- ddarchives@nic.in
Portas सात PHONE NO. :-265356il, 26962800
F. No. DA/39/2026-Records/ {+3444 Dated: | 7 los 26
NOTICE
Closure of Office to the Public on 47"'" August, 2026
This is to inform all that the office shall remain closed to the public on 477 August,
2026 (Monday) on account of the “Har Ghar Tiranga” Event being organised in the
office premises.
The inconvenience caused to the public is regretted.
This issues with prior approval of the Secretary (ACL).
q (Geetika Singh
Head of Office (Archives)
F. No. DA/39/2026-Records/ Dated:
Copy for information to:
4. The Secretary (ACL), Department of Art, Culture & Languages, GNCTD.
2. The Director (Archives), Department of Delhi Archives, GNCTD.
3. Administration Branch of the Department.
4. Website of the Department.
5. Notice Board.
6. Record Keepers.
7. Security Guards.
(Geetika Singh
ZF of Office (Archives)
Digitally signed by
Geetika Singh
Date: 2-08-2026
6:8:58
