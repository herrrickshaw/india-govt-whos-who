---
doc_id: "f9d5c4ceeef00cd8"
source_url: "https://ard.delhi.gov.in/sites/default/files/ARD/circulars-orders/gazette_notification_of_rr_of_mts_1.pdf"
ministry: "Administrative Reforms Department, Delhi"
title: "Download"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5b6ccf2f409dda57"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33002/99

REGD. No. D. L.-33002/99

भारत सरकार
GOVERNMENT OF INDIA

xxxGIDHxxx
एस.जी.-डी.एल.-अ.-11072024-255342
xxxGIDExxx
SG-DL-E-11072024-255342

असाधारण
EXTRAORDINARY

प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 179]

दिल्ली, बुधवार, िुलाई 10, 2024/आषाढ 19, 1946

[रा.रा.रा.क्षे.दि. सं. 97

No. 179]

DELHI, WEDNESDAY, JULY 10, 2024/ASHADHA 19, 1946

[N. C. T. D. No. 97

भाग IV
PART IV

राष्ट्रीय रािधानी राज्य क्षेत्र दिल्ली सरकार
GOVERNMENT OF THE NATIONAL CAPITAL TERRITORY OF DELHI

iz'kklfud lq/kkj foHkkx
vf/klwpuk
fnYyh] 8 िुलाई, 2024
Qk0la0 19@79@iz'kk0 lq/kk0@iz'kk0@2022@1919&x`g ea=ky;] Hkkjr ljdkj dh fnukad 13 tqykbZ]
1959 dh vf/klwpuk la0 27@59&,pvkbZ,e ¼i½ ds lkFk ifBr lafo/kku ds vuqPNsn 309 ds ijUrqd }kjk iznŸk
'kfDr;ksa dk iz;ksx djrs gq, jk’Vªh; jkt/kkuh {ks= fnYyh ds mijkT;iky] lewg ^x* in gsrq lsok,a foHkkx] jk’Vªh;
jkt/kkuh {ks= fnYyh ljdkj ds iwoZ ijke”kZ ls] ,rn~ }kjk iz'kklfud lq/kkj foHkkx] jk’Vªh; jkt/kkuh {ks= fnYyh
ljdkj esa ^eYVh VkfLdax LVkQ ¼,eVh,l½* ds in gsrq HkrhZ fu;e cukrs gSa] vFkkZr~ %&
1-

laf{kIr 'kh"kZd ,oa izkjaHk %& ¼i½ bu fu;eksa dks ^iz'kklfud lq/kkj foHkkx eYVh VkfLdax LVkQ ¼,eVh,l½
HkrhZ fu;ekoyh] 2024* dgk tk,A
¼ii½ ;s fnYyh jkti= esa vius izdk'ku ds i”pkr~ ls izHkkoh gkasxsA

4151 DG/2024

(1)

<!-- page 2 -->

2

DELHI GAZETTE : EXTRAORDINARY

PART IV]

2-

inksa dh la[;k] oxhZdj.k rFkk osru eSfVªDl esa Lrj %&mDr inksa dh la[;k] mudk oxhZdj.k rFkk osru
eSfVªDl esa Lrj bu fu;eksa ds lkFk layXu vuqlwph ds dkWye ¼2½ ls ¼4½ esa ;FkkfofufnZ"V gksx
a sA

3-

HkrhZ i)fr] vk;q lhek] ;ksX;rk bR;kfn %& mDr inksa dh HkrhZ i)fr] vk;q lhek] ;ksX;rk,a ,oa blls
lacfa /kr vU; ekeys mDr vuqlwph ds dkWye ¼5½ ls ¼13½ esa ;FkkfofufnZ"V gksaxsA

4-

v;ksX;rk %& og O;fDr]
¼d½

ftlus ,sls O;fDr ls ftldk ifr ;k ftldh iRuh thfor gS] fookg fd;k gS ;k fookg dh
lafonk dh gS( vFkok

¼[k½

tks ,d thfor ifr@iRuh ds gksrs gq, fdlh O;fDr ls fookg dj pqdk gS ;k fookg lafonk dj
pqdk gS] og mDr in ij fu;qfDr dk ik= ugha gksxkA

“krZ ;g gS fd ;fn ljdkj larq’V gS fd ,slk fookg ,sls O;fDr ,oa fookg ds vU; i{k ij ykxw
O;fDrxr dkuwu ds varxZr vuqer gS vkSj ,slk djus ds fy;s vU; vk/kkj gSa] rks og fdlh ,sls O;fDRk
dks bl fu;e ds izorZu dh NwV ns ldrh gSA
5f'kfFky djus dh 'kfDr %& tgka jk’Vªh; jkt/kkuh {ks= fnYyh ljdkj dk ;g er gks fd ,slk djuk
vko';d vFkok lehphu gS] rks og dkj.kksa dks fyf[kr esa vfHkys[kc) djrs gq,] vkns'k }kjk] O;fDr;ksa ds fdlh
oxZ ;k Js.kh ds laca/k esa bu fu;eksa ds fdlh mica/k dks NwV ns ldrh gSA
6cpko %& bu fu;eksa esa jk’Vªh; jkt/kkuh {ks= fnYyh ljdkj }kjk bl lac/a k esa le;&le; ij tkjh fd,
x, vkns'kksa ds vuqlkj vuqlwfpr tkfr;ksa] vuqlwfpr tutkfr;ksa] HkwriwoZ lSfud rFkk vU; fo'ks"k oxksZa ds
O;fDr;ksa ds fy, micfU/kr fd, tkus okys visf{kr vkj{k.k] vk;q&lhek esa NwV vkSj vU; fj;k;rksa ij
dksbZ izHkko ugha iM+x
s kA
vuqlwph
eYVh VkfLdax LVkQ ¼,eVh,l½ ds in gsrq
1-

inuke

2-

inksa dh la[;k

3456-

% eYVh VkfLdax LVkQ ¼,eVh,l½

% 03*¼2024½
* ¼ifjorZu dk;ZHkkj ij fuHkZj½
oxhZdj.k
% lkekU; dsUnzh; lsok] lewg ^x*] vjktif=r] vfyfidh;
osru eSfVªDl esa Lrj
% osru eSfVªDl esa Lrj &1 ¼#i;s 18000&56900½
D;k p;u in gS vFkok xSj p;u in
% ykxw ugha
lh/kh HkrhZ okys mEehnokjksa ds fy, vk;q % 18&25* o"kZ ds chp
lhek
¼dsUnz ljdkj }kjk tkjh vuqn's kksa ;k vkns'kksa ds vuqlkj
foHkkxh; mEehnokjksa ds fy;s Åijh vk;q&lhek 40 o"kZ rd
f”kfFkyuh;A½
Vhi%& vk;q lhek fu/kkZj.k ds fy, fu.kkZ;d frfFk le{k
izkf/kdkjh }kjk ;Fkk foKkfir gksxhA
*;fn vf[ky Hkkjrh; [kqyh izfr;ksfxrk }kjk inksa dks Hkjk
tkuk gSa] rks vk;q lhek 18&27 o’kZ ds chp gksxhA

7-

lh/kh HkrhZ okys mEehnokjksa ls visf{kr % vfuok;Z %&
'kSf{kd rFkk vU; ;ksX;rk,a

<!-- page 3 -->

[PART IV

3

DELHI GAZETTE : EXTRAORDINARY

ekU;rk&izkIr cksMZ@fo”ofo|ky; ls eSfVªdqys”ku vFkok
led{k mÙkh.kZA
8-

D;k lh/kh HkrhZ okys mEehnokjksa ds fy, % ykxw ugha
fu/kkZfjr 'kSf{kd ;ksX;rk ,oa vk;q lhek
inksUufr okys mEehnokjksa ij Hkh ykxw
gksxhA

9-

ifjoh{kk dh vof/k] ;fn dksbZ gS

10-

HkrhZ dh i)fr] lh/kh HkrhZ }kjk ;k % 100 izfr”kr lh/kh HkrhZ }kjk
inksUufr }kjk ;k izfrfu;qfDr@
vkesyu }kjk rFkk fofHkUu i)fr;ksa ls
Hkjs tkus okys fjDr inksa dk izfr'kr

11-

;fn inksUufr@izfrfu;qfDr@ vkesyu
}kjk HkrhZ gksuh gks] rks xzsM ftuls
inksUufr@ izfrfu;qfDr@vkesyu fd;k
tkuk gS

12-

;fn dksbZ foHkkxh; inksUufr lfefr gks] % LFkk;hdj.k ds fopkjkFkZ lewg ^x* foHkkxh; LFkk;hdj.k
rks bldh lajpuk D;k gS\
lfefr
¼i½ iz/kku lfpo@lfpo ¼Je½ & v/;{k
¼ii½ foHkkxk/;{k & lnL;
¼iii½ mi&lfpo ¼lsok,a½ & lnL;

13-

% nks o"kZ

% ykxw ugha

Vhi %& ;fn foHkkxh; LFkk;hdj.k lfefr dk vf/klwfpr
v/;{k foHkkxh; LFkk;hdj.k lfefr ds fdlh Hkh vU; lnL;
ls dfu’B gS] rks foHkkxh; LFkk;hdj.k lfefr dk ofj’Bre
lnL; v/;{k ds :i esa dk;Z djsxkA
os ifjfLFkfr;ka ftuesa HkrhZ ds fy, la?k % ykxw ugha
yksd lsok vk;ksx dk ijke'kZ fy;k
tkuk gSA

jk"Vªh; jkt/kkuh {ks= fnYyh ds mijkT;iky
ds vkns'k ls rFkk muds uke ij]
vk'kh’k dqekj] mi&lfpo

<!-- page 4 -->

4

DELHI GAZETTE : EXTRAORDINARY

PART IV]

ADMINISTRATIVE REFORMS DEPARTMENT
NOTIFICATION
Delhi, the 8th July, 2024
F. 19/79/AR/Admn/2022/1919:-In exercise of the powers conferred by proviso to article 309 of the Constitution
read with Government of India, Ministry of Home Affairs, notification No. 27/59-Him (i) dated 13th July 1959 the Lt.
Governor of the National capital Territory of Delhi, after prior consultation with the Services Department,
Government of National Capital Territory of Delhi for Group C Posts, is pleased to make recruitment rules for the
post of ‘Multi Tasking Staff (MTS)’ in the Administrative Reforms Department, Government of National Capital
Territory of Delhi, namely:1.

Short title and commencement:- (i) These rules may be called ‘The Administrative Reforms Department
Multi Tasking Staff (MTS) Recruitment Rules 2024’.
(ii) They shall come into force from the post of their publication in the Delhi Gazette.

2.

Number of Posts, classification and Level in the pay matrix:- The number of the said post, its classification
and Level in the Pay Matrix attached thereto, shall be as specified in columns (2) to (4) of the Schedule
annexed to these rules.

3.

Method of recruitment, Age limit and Qualification , etc:- The method of recruitment of the said post, age
limit, qualifications and other matter concerned therewith ,shall be as specified in the columns (5) to (13) of
the said Schedule.

4.

Disqualification:- No person,
a)

Who has entered into or contracted a marriage with a person having a spouse living; or

b) Who having a spouse living, has entered into or contracted a marriage with any person;
shall be eligible for appointment to the said post:
Provided that the Government may, if satisfied that such marriage is permissible under the personnel
law applicable to such persons and the other party to the marriage and that there are other grounds for
doing so, exempt any person form the operation of this rule.
5.

Power to relax:- Where the Government of National Territory of Delhi is of the opinion that it is necessary or
expedient to do so, it may, by order and for reasons to be recorded in writing, relax any of the provisions of
these rules with respect of any class or category of persons.

6.

Saving:- Nothing in these rules shall affect reservations, relaxation of age limit and other concessions required
to be provided for the Schedules Castes, Schedules Tribes, Ex-Servicemen and other special categories of
persons in accordance with the orders issued by the Government of National Capital Territory of Delhi from
time to time in this regard.

SCHEDULE
For the Post of Multi Tasking Staff (MTS)

Name
of Post

Number
of Post

Classification

Pay Level
in the pay
matrix

Whether
Selection
post or
nonselection
post

Age limit for
direct recruits

Educational and
other
qualifications
required for
direct recruits

1
Multi
Tasking
Staff
(MTS)

2
03*
(2024)
*(Subject
to
variation

3
General
Central
Service,Group
“C” NonGazetted

4
Level-1
(Rs.1800056900) of
Pay
Matrix,

5
Not
Applicable

6
Between 1825* years
(The upper
age-limit is
relaxable for

7
Essential:Matriculation or
equivalent pass
from recognized

Whether age
and
educational
qualifications
prescribed
for
direct
recruits will
apply in the
case
of
promotees.
8
Not
Applicable

<!-- page 5 -->

[PART IV

5

DELHI GAZETTE : EXTRAORDINARY
dependent
on
workload)

NonMinisterial

departmental
candidate
upto 40 years
in accordance
with
the
instructions
or
orders
issued by the
Central
Government).

Board/University

Note:
The
crucial date
for
determining
the age limit
shall be as
advertised
Competent
Authority.
*In case of
post
being
filled up by
allIndia
Open
Competition,
the age limit
would
be
between 18
years and 27
years.

Period of
probation,
if any

9
Two
years

Method of recruitment
whether by direct
recruitment or by
promotion or by
deputation/ absorption
and percentage of the
vacancies to be filled by
various methods
10
100%
By
Direct
Recruitment

In case of recruitment by
promotion/deputation/
absorption grades from
which promotion/
deputation/ absorption to
be made

If a Departmental Promotion
Committee exists what is its
composition

Circumstances in
which Union
Public Service
Commission to be
consulted in
making
recruitment

11
Not applicable

12
Group
‘C’
considering
consisting of:

13
Not Applicable

DCC
for
promotion

(i) Principal Secretary/
Secretary (Labour) Chairperson
(ii) Head of Department Member
(iii) Dy. Secretary (Services)Member

Note: Senior most member
of
the
Departmental
Confirmation
Committee

<!-- page 6 -->

6

DELHI GAZETTE : EXTRAORDINARY

PART IV]

shall act as Chairperson in
case the notified Chairman
of
the
Department
Confirmation
Committee
happens to be junior to
another
member
of
Department
Confirmation
Committee.

By Order and in The Name of Lt. Governor
National Capital Territory of Delhi
ASHISH KUMAR, Dy. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. SARVESH
KUMAR
SRIVASTAVA

Digitally signed by
SARVESH KUMAR
SRIVASTAVA
Date: 2024.07.11 20:55:55
+05'30'
