---
doc_id: "8a3dc10bedcbe94c"
source_url: "https://punjabcooperation.punjab.gov.in/sites/default/files/documents/CGF-guidelines-amendments.pdf"
ministry: "Co-operative Department, Punjab"
title: "View Document"
date: ""
pages: 6
method: "tesseract:pan+eng"
script: "GURMUKHI"
needs_ocr: false
sha1: "75e3e772b47eb01c"
---

<!-- page 1 -->

SIMMS LT ਜੀ ਐਫ . 1੧1 'ਲਿਤੀ ੧੧2 282੧9

ਵਲੋ deerme, ਸਹਿਕਾਰੀ ਸਭਾਵਾ, bara. ਚੋਡੀਗੜ੍ਹ।

SF | ਸਮੂਹ ਪ੍ਰਬਧ ਨਿਰਦੇਸਕ . ਅਪਕਸ ਸਹਿਕਾਗੀ ਸਸਥਾਵਾ . Sata

ਬਯੁਕਤ ਰਜਿਸਟਰਾਰ thu ਤੱਜਿਸਟਰਾਡ_ ਸਹਾਇਕ ਜੱਜਿਸਟਠਾਰ ਸੰਠਖਾਰੀ ਮਕਾਵਾ
ਵਿਸ਼ਾ ਸਹਿਕਾਰੀ ਸਭਾਦਾ ਦੇ ਲਾਗਾ ਦੀ ਵੰਡ ਕਰਨ aut ਅਤ ਉਨ੍ਹਾ ਏ ਖਾਈਲਾ= ਅਨਸਕ
ਰਜਿਸਟਰਾਰ, ਸਗਿਕਾਰੀ ਸਭਾਵਾਂ ਦੀ ਪੁਵਾਨਗੀ ਸਬੰਧੀ ਸਪੱਸਟੀਕਰਨ!

we wag

ਇਸ ਦਫਤਰ ਦੇ ਪੜਰ ਨੌ ਰਿਣ.ਸੀ.ਏ Lm ਜੀ ਐਫ “5੪1 ਮਿਤੀ 2 !1 07 ਦੀ ਲਾਤਾਰਤਾ
ਵਿੱਚ ਸ਼ਚਿਤ ਕੀਤਾ ਜਾਦਾ ਹੇ ਕਿ ਸਹਿਕਾਤੀ ਸਭਾਵਾਂ ਦੀਆ ਬਿਲਡਿੰਗਾਂ ਅਤੇ ਇਨਫਰਾਸਟਫਕਤਰ ਦਾ
ਫਚਨਾ ਲਈ Sst ਦੀ ਲੌੜ ਨੂੰ ਮੱਖ ਰਖਦੇ ਹੋਏ ਅੰਗ ਲਈ ਸਾਲ 2608 09 F ਮੁਨਾਫੇ ਦੀ Sz ਹੇਠ fair
ਅਨੁਸਾਰ ਕੀਤੀ ਜਾਇਆ ਕਰੇ।

। ਰਿਜ਼ਰਵ oe 33%

2 ਐਗਰੀਕਲਚਰ ਸਟੇਬਲਾਈਜੋਸ਼ਨ ਫੇਡ iss (ਪੰਜਾਬ ਰਾਜ ਸਹਿਕਾਰੀ ਬੈਕ , ਕੇਂਦਰੀ
ਸਹਿਕਾਰੀ ਸਭਾਵਾ , ਅਰਬਨ ਸਹਿਕਾਜੀ
ਥਰਿਢੇਟ ਸਭਾਵਾ।

੧ ਸੈਡ ਐਡ ਡਾਉਟਫੱਲ ae ਫੋਡ ੨੦੨ (ਪੰਜਾਬ ਰਾਜ ਸਹਿਕਾਰੀ ਖ਼ਜ਼ੀਬਾੜੀ
ਖਤੀਸਾੜੀ ਵਿਕਾਸ ਬੈਂਕਾ .

a4 ਮਿਲਕਫੋੱਡ ਅਤੇ ਮਿਲਕ ਯੂਨੀਅਨ”

4 ਇਮਪਲਾਈਜ ਬੇਨੀਵਿਟ os lls (ਕੋਵਲ ਪੰਜਾਬ ਰਾਜ ਸਹਿਕਾਰੀ ਖੇਤੀ
ਖਤੀ ਵਿਕਾਸ ਬੈਂਕਾਂ ਲਈ;

₹__ ਕਆਪ੍ਰੋਟਿਵ ਡਿਵੈਲਪਮੈਂਟ ea ie ।ਨੈਟ ਪਰੋਫਿਟ ਵਿਚੋਂ 105 ਘਟਾਉਣ

6, ਬਿਲਡਿੰਗ ਐਂਡ ਇਨਫਰਾਸਟਕਜ਼ਰ 12% ਸਮੂਹ ਸਹਿਕਾਰੀ ਸਭਾਵਾਂ ਲਈ

ਡਿਵੈਲਪਮੈਂਟ ਰੈਡ

7. ਪੈਨਸਨ ਫੋਲ 2% ਕੇਵਲ (ਪੋਜਾਬ ਰਾਜ ਸਹਿਕਾਰੀ ਬੋਂਕ
ਅਤੇ ਕੈਂਦਗੀ ਸਹਿਕਾਰੀ ਬੈਂਕ;

੪ ਕਾਮਨ ਗੁਂਲ ਵੇਡ - 3s feu ਫੰਡ ਸਹਿਕਾਰੀ ਸਭਾਵਾਂ ਵੱਲ

-------------------%

<!-- page 2 -->

a
ਅਧੀਨ ਰੱਖੇ ਗਏ ਫੋਡਾ ਨੂੰ ਪਭਾਵਿਤ
ਨਾ ਕਰਦੇ ge ਕਾਇਮ ਛੀਤਾ
ਜਾਵੇਗਾ। ਇਸ ਦੀ eae ਨਾਲ ਨੱਥੀ

7 ਗਾਈਡਲਾਈਨਜ਼ (ਅਨੁਲੱਗ ਉ”
ਅਨੁਸਾਰ ਕੀਤੀ ਜਾਵੇਗੀ।
% ਪ੍ਰਾਇਮਰੀ ਕੋਆਪ ਸਭਾਵਾਂ ਵਿਕਾਸ ਫੈਲ is inter ਅਤੇ ਕੱਦਗੀ ਸ਼ਹਿਕਾਰੀ
ਸਭਾਵਾਂ?
és ਵਿੱਚ ਅਣ ਅਖਤਿਆਰੀ ਮੰਦਾਂ
ਨਾ ਕਰਦੇ ਹੋਏ ਕਾਇਮ ਕੀਤਾ
ਜਾਵੇਗਾ। ਇਹ és ਹੇਠ fou Ger
ਲਈ ਵਰਤਿਆ ਜਾ ਸਕੇਗਾ।
.ਉ- ਮੁੱਢਲੀਆਂ ਸਹਿਕਾਰੀ ਸਭਾਵਾਂ ਨੂੰ uges ਅਤੇ ਢਾਂਚਾ ਗੁਹਿਸੜ ਕਰਨਾ।
%; ਮੁੱਢਲੀਆਂ ਸਹਿਕਾਰੀ ਸਭਾਵਾਂ ਵਿੱਚ ਅਸੇਤੁਲਨ ure ਕਰਨਾ।
ot ਮੁੱਢਲੀਆਂ ਸਹਿਕਾਰੀ ਸਭਾਵਾਂ ਦੀ ਆਮਦਨ ਵਾਲੀਆਂ ਗਤੀਵਿਧੀਆਂ ਲਾਗੂ ਖਹਨਾ ਅਤੇ ਉਨ੍ਹਾ
ਦੇ ਮੈਂਬਰਾਂ ਦੇ ਹਿੱਤ ਦੇ ਮਾਪਦੇਡ ਅਪਣਾਉਣ ਵਿੱਚ ਸਹਾਇਤਾ ਕਰਨਾ।
ਸ_ ਉਕਤ ਉਦੇਸ਼ਾਂ ਦੀ ਪ੍ਰਾਪਤੀ ਨਾਲ ਸਬੋਧਤ ਫੈਸਲਾਕੁੰਨ ਕਦਮ ਚੁੱਕਣ ਬਾਰੇ।
੭ ਕੋਆਪ ਐਜੂਗੋਸ਼ਨ ਫੰਡ ' ਪੋਜਾਬ ਸਹਿਕਾਰੀ ਸਤਾਵਾ ਰੂਲਜ 1963 ਦੇ ਰੁਲ 36 ਮੁੜਾਬਿਖ TS
Aa ਸਭਾਵਾਂ ਦੀਆਂ ਕਿਸਮਾਂ 7 ` ਮੁਨਾਫੇ ਦਾ ਵੱਧ ਭੋਂ ਵੱਧ ਰੋਟ
1 ਪ੍ਰਾਇਮਰੀ ਸਹਿਕਾਰੀ ਸਭਾਵਾਂ ਮੁਨਾਵੇ ਦਾ 2% ਜਾਂ ਵੱਧ ਤੋਂ ਵੱਧ
2000/- ਰੁਪਏ
॥ ਕੇਂਦਰੀ ਸਹਿਕਾਰੀ ਬੈਂਕ, ਸਹਿਕਾਰੀ ਜ਼ੱਧ ਮੁਨਾਫੇ ਦਾ 2% ਜਾਂ ਵੱਧ ਤੋਂ ਵੱਧ
ਸ਼ੂਗਰ ਮਿਲਜ, ਸਹਿਕਾਰੀ 1.00 ਲੱਖ ਰੁਪਏ
ਮਿਲਗ ਯੂਨੀਅਨਜ਼ ਅਤੇ ਸਹਿਕਾਰੀ
੍‌ ਸਧਿੰਨਿੰਗ ਮਿਲਜ਼।
੧ ਹੋਰ ਰੈਂਦਰੀ ਸਹਿਕਾਰੀ ਸਭਾਵਾਂ ਸਮੇਤ ਸੁੱਧ ਮੁਨਾਫੇ ਦਾ 2% ਜਾਂ ਵੱਧ ਤੋਂ ਵੱਧ
ਪ੍ਰਾਇਮਰੀ ਸਹਿਕਾਰੀ 0.50 ਲੱਖ ਰੁਪਏ
ਖੇਤੀਬਾੜੀ ਵਿਕਾਸ ਬੈਕਜ ਅਤੇ ਸਹਿਕਾਰੀ ਮਾਰਕੀਟਿੰਗ ਸਭਾਵਾਂ ।
er
੯

<!-- page 3 -->

AUST WT WO HAS BS eT ਝ
ਵਧ . ੨੭ ਲਪ ਰਪਏ
fay ਸਹਿਕਾਰੀ ਸਾ © ਲਾਭ ਦੀ Sa ਕਰਨ ਸਮ -ਵਮਫਾਤ Od Sl ਵਡ HU ਖਾਓ
.. ਦੀਆਂ ਜਬੋਧਤ wane ਨੂੰ ਧਿਆਨ ਵਿੱਚ Time ਜਾਵੇਗਾ। ਇਸ ਤੇ 'ਖੇਨ ਛੱਡ ਨੂੰ eee TES
seer qa arg ਹੌਰ ਫੰਡਾਂ ਦਾਂ ਮੋਜਰਾ ਨੰ ਲਾਫ ਅਸ ਫਾਜ ਨੂ&'-੧ਜਾਐਂਣਤਾ ਅਨਾਰ glam ਦਾ
Hari iD
ਉਪਰਕ= ਸਪੱਸਟੀਕਰਣ ਇਸ ਤੇ ਪਹਿਲ` ਜਾਰੀ ਸਮ mt fea ਹਦਾਇਤਾਂ ਨੂੰ ਰਦਾ ਕਰਦ ਹਏ
ਦਾਸ ਟਾਜ ਸਾਂਹਕਾਰੀ ਸਕਾਵਾ ਰੁਲਜ 146? ਦੇ ਰੂਲ 15 ਅਧੀਨ ਜਾਰ! ਕੀੜੀ ae ਪੜੀ ਜਾਵ . ਇਹ
ਵੀ ਚਿਤ ata ਜਾਦਾ ਹੈ ਕਿ ਜਗਣ ਉਪਰੋਕਤ ਅਨਸਰ ਲਾਭ ਦੀ ਵੇਡ ਕੀਤੀ ਜਾਦੀ ਹ ਤਾਂ ਰਜਿਸਟਰਾਰ.
sige gh ਸਭਾਵਾਂ, ਮੋਜਾਬ ਦੀ ਅਗੋਤਰੀ ਪ੍ਰਵਾਨਗੀ ਦਾ! ਲੜ ਨਹੀ ਕਵਲ cs ਉਪਰੇਤ ਹੀ ਸਹਿਤ
ਜੀਤ। ਜਾਣਾ ਜਾਵੀ ਹੋਵੇਗਾ!
Fat -
ਵਧੀਕ ਰਜਿਸਟਰਾਰ “ਤਿਣ
ਵਾ atures ਸਹਿਕਾਰੀ ਸਭਾਵਾਂ . ਪਜਾਬ . ਚੋਡੀਗੜ੍ਹ '
(ਅਨ.ਲੰਗ- ਚੋ)
Gudelines for creation/reguiation “and utibzation of The Punjab State
Cooperative Societies Common Good Fund
the Puryab Stale Geoperatwe Soueles Common 43008 Func wms !੦
17,900 fut for the good of generat public which may include ਹੈ ਰੋਮ 7੬04 lo
pour mruical rebef aad the furtherance of any sbect of general oubiic :40(% 0੧੦੦੧
ਗਜ ਭਮ0੯॥ ੧੧ the quakty and infrastructure ‘af education in the Stale in vursut of
pringapa’ ot coaoerations.e “concern for community” and 0੦੬5 7੧੦੧ include purposes
which ridle to rehgious teaching/preaching or workshop Following wing guidelines:
chat! be tollawed for creation, regulation and uub7alron of the lund by Ine cooperalive
੫੬੧65 al various levels primary, secondary and apex levels
Onjectyes of the Fund.
Yee objectives of tne fund shal! be
1 lo provide for and tacihtate the development of education (only through
. Government Institutions as per policy of the Government and prioritias laid
down by Punjab Education Development Board established as per Punjab
State Education Develoament Act, 1998} relief to the poor, medical relef and
furtherance uf ary ੦੦੦੮1 of general public ullity wnich shall rot inciude any
purpose which relates exclusively ੧੦ religious teachingrpreaching oF warkshop
ECS

<!-- page 4 -->

੬ ਦ----------”
ny To undertake any olher step as are atcoenta 6੪ ੨ adecre bine Achievement
x of the aforesaid objectives L
Creation_and Uitization of the Fund:
4 \n oursuil of the principal of Cooperation namely “concern tor Community" ail
* Apex, Central and Primary level Coopetalive Societies shall create the
‘Common Good Fund" as per byelaws of tne socimty and mstruchons of the
RCS. Punjab issued by him from time to ume ° 3
9! The fund shall be utilized only within the terntorial junsdictian of the society.
However, the fund may be utilized out of territorial jurisdiction of ੩ sociely for
specific pubtic ulility objectives for reasons to be recorded in writing and with
the prior approval of Ihe RCS.
te Tne tune snall be ੫੧੪੬੧ by the society through as BODManaging Committee!
Admmnistrator!Sub-Commitlees as may be established under ine bye laws of
the someues
vy) Forthe purpose of development of education infrastructure, specific allocation
Irom the tund shali be made as per instructions of RCS
Maintenance of Account.of the Fund i
0 The fund maintained by any sociely shall be deposited ' the Central .
Cooperative Banks and the Punjab State Coop Bank in an arcount of (he ae
sai society specially designated for the purpose -`=
ni Annual Account of the fund shall be piaced betare ihe General Body in annual
general meeting of the society .
0 ‘The general provisions of (he Punjab Cooperative Societies Act shail apply
85 per delegation thereof to the officer of the Department of Cooperation ਰਹ
Punjab for implementation of the above guidelines.
॥ in case any difficully/hardship anses in giving effect to these guidelines, the
matter may be reterrad to RCS for clarification or modification as the case '
may be
ae ;

<!-- page 5 -->

Office of Registrar, Cooperative Societies, Punjab
੬ {Credit-1 Branch)
To
1 Alt Managing Directers,
Apex Cooperative institutions in Punjad
2 Ali Managing Directors/District Managers.
1 Centra! Cooperative Banks Ltd. in Punjab.
1
No. ResiCredit-liCA-3/CDF/ 12
Dated 23-41-15
Sub: Amendments in the guidelines for Creation! Regulation and
utilization of Common Good Fund.
This is with reference to this office letter No. Credit/CA1/956
dated 20-12-1999 and No RCS/Credit/CA-1/815 dated 02-12-2003.
in exercise of powers under Rule 45 of the Punjab Cooperative
Societies (੧੫੧੩੩, 4963 and in order to ensure better utilization of the

Common Gocd Fund, the Registrar, Cooperative Sacieties. Punjab has

decided to revise the objectives of the Common Good Fund. The revised

objectives shall be as under:-

Objectives of mon Good Fund: -

A fi) To provide for the development of education (only through
Government Institutions as per policy of the Government and
priorities laid down by Punjab Education Development Board
established as per Punjab State Education Development Act 1998).
relief to the poor, medical relief and furtherance of any object of
general public utility which shall not include any purpose which
relates exclusively to religious teaching / preaching or worship.

uy) 72 provide for the development of member societies for meeting their
Joan imbalances OF Josses oF strengthening their Primary Vikas Fund
or assisting them for meeting their objectives in any other manner,

ui) ] To provide for development / up-gradation of infrastructure in the
Primary Agricultural Cooperative Societies/ Multipurpose Agricultural
Cooperative Societies;

<!-- page 6 -->

y Provided further that only apex cooperative institutions shall be
1 competent fo provide funds under this clause to Societies which are
: not their members;
੪੪) Te provide for relief to the poor and to victims of natural calamities
etc. through the Prime Minister Relief Fund or the Chief Minister
Relief Fund.
4 v) To provide for any other purposes as are incidental or conducive to
| the achievement of the aforesaid objectives.
i B. No funds for the above mentioned objectives shal/ be allocated
| without the sanction of the Board of Directors of the society and
| approval of the Registrar, Cooperative Societies, Punjab or any
officer authorized by him.
The amended objectives shall supersede any previous orders issued
by this office on this subject
; This is being issued with the approval of the egistrar, Cooperative
Societies, Punjab Chandigarh. ॥ ੧੫੭ yas
Additional Registrar (Credit),
For Registrar, Cooperative Societies, Punjab.
Chandigarh.
Endst. No. RCS/Credit-1/CA-3/CDF/ 4 Dated: 23-115
Copy of the above is forwarded to following for information &
necessary action,
1 All Additional Registrars, Cooperative Societies in H.0.
2. All Joint Registrar, Cooperative Societies in field & H.O.
3 All Deputy Registrar, Cooperative Societies in Punjab are directred to
inform the al! Cooperative Societies under their jurisdiction
4. AllAssistant Registrar, Cooperative Societies, Punjab. ,-
5. All Superintendent in H.O bk adds
a =
Additional Registrat (Credit),
For Registrar, Cooperative Societies, Punjab,
Chandigarh.
