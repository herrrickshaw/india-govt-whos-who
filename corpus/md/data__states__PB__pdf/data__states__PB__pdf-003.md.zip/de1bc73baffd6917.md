---
doc_id: "de1bc73baffd6917"
source_url: "https://punjabmedicalcouncil.in/pmc/wp-content/uploads/2021/11/1595575505pdf_.pdf"
ministry: "Punjab Medical Council, Punjab"
title: "Guidelines for Advertisement w.e.f. 01.02.2020"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "77e936d3648edd96"
---

<!-- page 1 -->

PUBLIC NOTICE
FOR DOCTORS AND HOSPITALS
REGARDING GUIDELINES FOR ADVERTISEMENTS

(w.e.f. 01-02-2020)
Drafted by the Ethical Committee & approved by the Executive Committee
Punjab Medical Council on 22.01.2020
Punjab Medical Council is dedicated to ensure quality medical care for the people of Punjab.
It has adopted The Indian Medical Council (Professional Conduct, Etiquette and Ethics)
Regulation 2002 (as amended upto 2016). Some of the registered medical practitioners
indulge in wrong practices of giving unethical advertisements in the Press/ Media which can
invite disciplinary action.
Punjab Medical Council issues the following guidelines within the framework of IMC
Regulations 2002 (as amended up to 2016) which should be strictly observed for giving
advertisements by the Doctors/ Nursing Homes/ Hospitals/ Clinics/ Pathology Labs/
Diagnostic Centres/ Health Care Institutions in the State of Punjab:
GUIDELINES FOR ADVERTISEMENTS
(Under Indian Medical Council (Professional conduct, Etiquette and Ethics) Regulation,
2002 as amended up to 2016)
A)

For Medical practitioners u/s 6.1, & 7.11 of the Code
(Advertisement to be given once only on occurrence of the occasion)

1)
2)
3)
4)
5)
6)
7)
8)
9)
10)

On starting practice.
On change of type of practice.
On changing address.
On temporary absence from duty.
On resumption of another practice.
On succeeding to another practice.
Public declaration of charge.
Acquiring new equipment or starting a new procedure or operation.
The advertisement is the press shall not be more than 15cm x 10cm.
Doctors are permitted to give lectures/ talks of mass Awareness on public health and
diseases on Television, Radio and Social Media under his/ her name but without
giving his/ her address. There should be no request to consult the particular doctor/
hospital. It should conform to section 7.11 of the code which is reproduced below.

Page 1 of 5

<!-- page 2 -->

11)

Doctors can issue health education and general information pamphlets/ brochures to
the patients visiting their clinic/ hospital but these should not contain guarantee of cure
or superiority over others or unsubstantiated claims or misleading information.
Greetings to fellow citizen on National days and festivals are allowed by Doctors as a
citizen in News Papers or electronic media. However, it should not contain more than
the greetings and the name of Doctor, it should not look like a professional
advertisement.
For Example:

12)

Happy Independence Day
(------Dr. ABC-----)

B) For Hospitals/ Nursing Homes u/s 7.2
1

The advertisement by Hospitals
(A) In Print or Electronic Media should contain only:
i. Name of Hospital.
ii. Facilities and Services provided.
iii. Charges.
iv. Timings.
(B) The advertisement shall not carry name or the photograph of the
Doctors.
(C) Size not more than 25x15 cm.
(D) Frequency: (How Many Times?) Once a month only
(E)
The advertisement on electronic media shall not be of more than 45
seconds and can be given Once in a month only.
(F)
No Private Interview for personal glorification
2. Advertisement should not contain:
(A) Any guarantee of the treatment.
(B) Claim of superiority on others or try to run down others.
(C) Unsubstantiated claims in cure/ diagnosis.
(D) Any misleading information.
3. In no way it should appear that the material in the advertisements, in one way or the
other seems to solicit patients.
4. Hoardings of any size along the roadside or on building other than hospital premises
are not allowed in State of Punjab & other States. Hoardings on hospital premises
should not obstruct the traffic in anyway.

Page 2 of 5

<!-- page 3 -->

5. Advertisements in the form of Strips on the Cable, Television or social media
cannot be given.
6. Any talk or Article on hospital should not seem to be soliciting patients. It should only
make general public aware about the facilities and services being provided by the
hospital without claiming any superiority over others or guarantee to the treatment/
Cure.
7. Own Websites are allowed and should contain information about the doctors,
facilities, services provided, charges, Equipment and departments only. It should only
make general public aware about the above without claiming any superiority over
others or guarantee of treatment/Cure.
8. Advertisement in the professional journals & Association related event is allowed.
9. Information regarding Medical camps can be displayed by way of pamphlets, banners,
hoardings or advertised in press/ electronic media maximum 2 times before the camp.
It should contain only name of the doctors, hospital name, services to be provided,
date, timings and venue of the camp. If doctors in these camps are coming from
outside state Punjab, they have to procure temporary registration in advance from
Punjab Medical Council.
10. In case, health awareness or education material is circulated or displayed publicly by
way of pamphlets/ Banners/ hoardings the name of the Hospitals/ Doctors doing so
should not be more than 1/ 10 of the area of the matter or board/ banner or paper and
should be displayed at bottom.
11. Hospitals can issue pamphlets, information brochures to the patients visiting the
hospitals but these should not contain guarantee of cure or superiority over others or
unsubstantiated claims or misleading information.

Various sections of The Indian Medical Council (Professional Conduct, Etiquette and
Ethics Regulations 2002 as amended upto 2016) referred to above are reproduced below:
Section: - 6.1
6.1.1: - Soliciting of patients directly or indirectly, by a physician, by a group of physicians
or by institutions or organizations is unethical. A physician shall not make use of him/her (or
his/her name) as subject of any form conjunction with others which is of such a character as
to invite attention to him or to his professional position, skill, qualification, achievements,
attainments, specialties, appointments, associations, affiliations or honours and/or of such
character as would ordinarily result in his self-aggrandisement A physician shall not give to
any person, whether for compensation or otherwise, any approval, recommendation,
endorsement, certificate, report or statement with respect of any drug, medicine, nostrum
remedy, surgical, or therapeutic article, apparatus or appliance or any commercial product

Page 3 of 5

<!-- page 4 -->

or article with respect of any property, quality or use thereof or any test, demonstration or
trial thereof, for use in connection with his name, signature, or photograph in any form or
manner of advertising through any mode nor shall be boast of cases, operations, cures or
remedies or permit the publication of report thereof through any mode. A medical
practitioner is however permitted to make a formal announcement in press regarding the
following: (1) On starting practice.
(2) On change of type of practice.
(3) On changing address,
(4) On temporary absence from duty.
(5) On resumption of another practice.
(6) On succeeding to another practice.
(7) Public declaration of charges.
6.1.2: - Printing of self-photograph or any such material of publicity in the letter head or on
sign board of the consulting room or any such clinical establishment shall be regarded as
acts of self-advertisement and unethical conduct on the part of the physician. However,
printing of sketches, diagrams, picture of human system shall not be treated as unethical.
Section: - 7 Misconduct:
7.11. Physician should not contribute to the lay press articles and give interviews
regarding diseases and treatments which may have the effect of advertising himself or
soliciting practices; but is open to write to the lay press under his own name on matters of
public health, hygienic living or to deliver public lectures, give talks on the radio/TV/internet
chat for the same purpose and send announcement of the same to lay press
7.12. An institution run by a physician for a particular purpose such as a maternity home,
nursing home, private hospital, rehabilitation centre or any type of training institution, etc.,
may be advertised in the lay press, but such advertisements should not contain anything more
than the name of the Institution, type of patients admitted, type of training and other facilities
offered and the fees.
Medical practitioners registered with Punjab Medical Council and hospitals in state of Punjab
are required to follow the above guidelines in case of advertisements strictly. Any violation
which will come to the notice of Punjab Medical Council will invite disciplinary action.

Page 4 of 5

<!-- page 5 -->

In case of violation of above guidelines, suo motu action will be taken by the Punjab
Medical Council against the erring doctor/ hospital, without asking any prior
clarification/explanation.
All the Registered Medical Practitioners and Hospitals are further advised to update and
apprise themselves of the various guidelines and advisories by or under:
(A)
(B)
(C)
(D)
(E)
(F)
(G)

Medical Council of India / National Medical Commission / State Medical
Council
Indian Medical Council (Professional conduct, Etiquette and Ethics)
Regulations
Drugs & Cosmetics Act
Drugs and Magic Remedies (Objectionable Advertisements) Act & Rules
Advertising Standards Council of India (Advisories)
Ministry of Information and Broadcasting, India (Codes, Guidelines and
Policies)
Cable Television Networks (Regulation) Act & Rules (Programme &
Advertising Codes)

Registrar
Punjab Medical Council
Mohali

Page 5 of 5
