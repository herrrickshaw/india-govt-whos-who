---
doc_id: "1bae0290aaf56eaf"
source_url: "https://pserc.punjab.gov.in/pages/notification144.pdf"
ministry: "Punjab State Electricity Regulatory Commission (PSERC), Punjab"
title: "Notification No. 144"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c9f5fca5dad5fdaa"
---

<!-- page 1 -->

Regd. No. CHD/00922018-2020

R.sd. No. l'tw/CH_22

Funisb (Ssuernment

(5azsfte

EXTRAORDINARY
P,t b tish e d b! Autho rit!

ffi

]ton*. t**sDAY' DECEMB ER 5' 2o t' t

oo*g!1yIry
COMMISSION

PI'NJAB STA'TE ELECTNCITY REGI'LATORY
MARG CHANDIGARH'I6OOI8
SITE NO.3, SECTOR I8.A. MADI{YA
NOTIFICATTON
The 5rh Decenbcr' 2019

of the Powers conferred
No. PSERC/Secy/Regu'l44Jn cxercise

by sub-section (6) of Scciion 42 of

thcE|cctricityAct'2oo3rcadwithPunjabstateElectricityRegulatoryCommission(Forurn,ndombudsnan)
corninitsi@ is Pleascd to

punjab srarc Electricity Regutatory
to timc, thc
Rcgulations, 2016 amcndcd ftorn timc
and conditions:Electricity' Punjab on rhe following terms
lppoiflt Er. Ourinderj Singh as Ombudsman'
lh' charge which
of tuee vears from Ue dale of his ralong
Thc appoirorc shall bc for a P€nod
70
penoa of fi !e ve ars subl'cr to age limit of

I

rnav Uc cxmacd rv rrrc com#sron

upro

"

maximum

ycars.

2.Hc{,illbepaidA6rcdremunerationofRs,l'oo,oooi.(oDelac)permoDthandRs.l0,000/by ihc Commission(tco thousand) Pcr Bonlh lowads Transpon

Allowaocc as prcsqibcd

3. His ofEce shtll be located at 66 KV Crid Sub'sotion'

Plot no A-2' ln'lusEial fuea Phrse-l'

Nagar (Mohali)'

4. Before assuminS charge' he *ill subscribe ro fie oath

of offlce and s€crccy bcforc Churperson'

PSERC.

.
*

SA S

$an 03 monlhs in writing

(o dEcofitrBissiorl

5. Hc may rElinquish hisoffccby giving a notic! of noilcss
Eledricity
be as specified in the Punjab Stale
6 The other terms and cotdi[otls of his aPpointmenl shall
fmm time to time'
*a Otu'a"'""1 n"g'lations'20 16 as amended
ncgutatory Cod'trtusid dsd/-

(PARNEET MAHAL SURI)
Sccretary' PSERC

1921 n2'20t9/Pb'

Goi P'as' SA S- Na$r
(6540)

)O{
