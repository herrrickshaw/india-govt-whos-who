---
doc_id: "b63ced3bdae9871c"
source_url: "https://cdn.s3waas.gov.in/s3d07e70efcfab08731a97e7b91be644de/uploads/2022/02/2022021962.pdf"
ministry: "Sri Muktsar Sahib"
title: "Order regarding declaration of dry day"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ea3715983fb24457"
---

<!-- page 1 -->

JaH saa: O

/aH/2022

Ed/e 3 Ta E

Frat Hgot di The Representation ofthe People Act, 1951

FaHG 135 HT

"

No spirituous, fermented or intoxicating liquors or other substances of a like
shall be sold. given or distributed at a hotel, eating house, tavern, shop or any other place, public or
prrvale, within a polling area during the period of forty-eight hours ending with the hour fixed for he
conclusion of the poll for any election in that polling area."

nalure

FTtE TaHta Mae 1914 e urer 54 m The Representation ofthe People Act. 1951 è Ras
Te eT frst 18.02.2022

f-Bt 10/03/2022

ATH 05:00

20.02.2022

ifsar y s ie aa m

Tfuadi

fap
fa Hftnaiz,
fra iaa saT:81-12oMH.È.AH.At-1

fA3T-2-222

.
.

H ITTT MEHT, UHTA, TStarg

.
4.

3tedaza HOG YtSA, ATT, S3tag

.

afHHOT, fesmyT Ha%, fëõHYII

6.
1.
8.

9.
10.

fH a

HTa MEHT, Ht HaIHT HtUa/at.Mët.6., A7.Mët.Ht., H HasHT HfJa

11

12
13.
14.

15.
16.
17.

foeaföar MEHO, HT HaSHT HfJ8Me/ftiearT/öit

3foHtesera, Ht yaSHT HfUH/HGZ/tafesaT
Hfoa/HöE/faesHT/AE/EMI/Èe/at

5Tea 3foATMerT Ht HaSHT

18.

fargr AfAHedz,

f
