---
doc_id: "e9cba9ed6f5b492c"
source_url: "https://www.peda.gov.in/media/pdf/PWRDA_Memo.pdf"
ministry: "Punjab Energy Development Agencies (PEDA), Punjab"
title: "> Ensuring the Construction of borewell / tubewell by Power-operated Drilling Rig permitted by PWRDA.'-'FOR STRICT COMPLIANCE OF GUIDELINES MENTIONED HEREIN'"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "01a8a795dd75c602"
---

<!-- page 1 -->

PWRDA-PWRDOGENUT5/2023.O/o SECRE TRARY-PWRDA.Part(1 )

' t 1812992024

{mrn64r*rfwrUra-A ,.#9+.
.6*\
'ts.rte. *: l{e.ls2, itF& {eiF, ror

Prrrrb W.tcr R.grh6or &

Wcf Sirc rwr,.gnndrorg

email- sccatrry.pwrd@punj0. gov'in

D(TctopD.rt ArltorltY.

s.c.o 149-152- 3'{ Floor, Scclor 17€'
chDdigrt

ke.a rz-*, CdrrS

*

To
I

All lhc Administrativc Sccrclsries in the State ofpunjab

l All thc llcad of Dcpartmcnl in rhc State of punjab
:r

.t

All thc Divisional Comrnissioncrs in thc Slale of punjab
All thc Dcput) Commissioncrs in rhc slale of punjab

Mcmo No. 22 t8I8/PWRDA-PWRD0GENUT
Darcd. Chandi8arh

o-7. o5. ) ora,l

Subjcct EnsurinB the construction of borcwcll/tubcry€ll

SaO:.j/ I I

11qq f 2o>t4

by powcr-operalcd Drilling B.ig pcrmitkd !y pwRDA

Re8ulstion 8nd Dcvclopmcnt Authority (PWRDA)

:-It*l_Yatcr
.no uonservation

'

hss isrrcd ttrc punjeb Groundwar€r Exbaction

Dir.rtion, 2023 whlch havc comc inro cffcct from 01.02.2023.

2. As pc. the paEgraph 3.7 sub-parEgraph (A)

of the Directions, 2023i

'No Pota'-et'operoted drilling rig fioll be
operated tot erplorotion of groundvoter or lor establlshing
mNIDinS, augmcnling or i,',po'ing
ony grouiworer' extrution irucnres in rtte ttare, wi @!l
P.rmission of he Auhot y.n

apply to lhe Authority for pqmission
to opcmre a powcr.opcratcd driling rig in srare of punjEb
1.-T.1t^l:
was JI.12.2023 $hich has
sincc bccn extendci till 30.06.20.24.

4' It is thus requcslcd lo ensur lhrr all lhc_bor.wclls/tubcwells
J0.06.2024 are drillcd ont) by po\rcr_opcrctcd

5. This is for lour informarion and firthcr

bcing consructld in your &pairncnt sftrr

Huing riSs ;;in; pc;;;i",

"l-pwnoa

.

ncc.cssar] action

Copy to:-

l#&gnt'^,

)2
/
Sc,cretary

'trtnc]': chicf Enginelr/ carals, Dcpsrtsncnt of watcr Rcsourcs, punjab, sccror 18,

2. Suprintcnding Enginecr, Groundwabr Managcmcnt
Circ., Drparbncnt o[Watcr Resourc.s, purjab, Wa&r
Rcsourccs Bhawar\ Secror 6t, SAS Nag8r.
