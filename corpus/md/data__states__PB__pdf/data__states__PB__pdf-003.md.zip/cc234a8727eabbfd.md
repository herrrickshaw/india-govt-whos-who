---
doc_id: "cc234a8727eabbfd"
source_url: "https://pserc.punjab.gov.in/pages/VC-68-2025-04.pdf"
ministry: "Punjab State Electricity Regulatory Commission (PSERC), Punjab"
title: "Vacancy circular for the post of Director Tariff in PSERC 68/2025/04"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "14032ee7f9630a5d"
---

<!-- page 1 -->

For Website

VACANCY CIRCULAR
Recruitment Notice Reference No.68/2025104

Applications are invited from eligible persons for filling up the post of Director/Tariff
on deputation/contract basis. The detail of qualifications, qualifying service and nature of
experience prescribed for this post as per Punjab State Electricity Regulatory Commission
(Appointment & Service conditions of Employees) Regulations, 2015, amended from time to
time is as under :Post

Eligibiliry Criteria

Director/

a) Minimum Educational Oualilication:

Tariff

Degree in Electrical/Mechanical/Electronics

(01 post)

& Communication/

L.lectronics and Instrumentalion Engineering.

b) QccI&!!sS9E!!e,
Serving/Retired OIficers ofthe Central/State Government or PSU under
State/Central Govemment, having experience ofworking on the post of
Chief Engineer or its equivalent in the scale of Rs. 1,48,800-Rs.
2,! 8,600 on regular basis.

OR
Serving/Retired O{frcers ofthe Central/State Govemment or PsU under
State/Central Govemment with minimum 4 years' experience of
working on the post of Superintending Engineer or its equivalent in the
scale ofRs. 123100- 209600 on regular basis.

.

OR
year's
experience
of working in power sector out of
Minimum twenty
which at least three year's experience in a senior assignment relating to
electricity laws, regulatory/commercial affairs and other activities
relevant to the working ofthe Commission.

c) Nature of Experiencel
Familiarity with electricity laws, regulatory affairs and latest
development in the power sector. Preference shall be given to
candidates with exposure in matters relating to tariff determination,
techno-economic appraisal of power projects/schemes, open access,
demand side management, power system planning, operation,
distribution and other activities relevant to the working of the
Commission.

<!-- page 2 -->

I
Pay, Allowances and other terms & conditions
The eligibility criteria, pay, allowances and other terms & conditions ofthe service for

the post of Director/Tariff will be as per Punjab State Electricity Regulatory Commission
(Appointment & Service conditions ofEmployees) Regulations, 2015, as amended from time to
time, available on Commission's website www.pserc.punjab.gov.in, under 'Regulations' tab.
The selection will be made by the competent authority on the recommendation of the
Screening-cum-Selection Committee of PSERC keeping in view the suitability for the post on
the basis ofqualifications, qualifoing service ahd nature ofexperience.
The term of appointment shall be as per the Regulations. For the candidates, applying
on deputation, the parent Departsnent will fotward the applications of eligible and interested

candidates after due verification and whose services can be spared in the event of their
selection, along with bio-data & ACRS for the last five years and information regarding
pending and decided vigilance, disciplinary cases. An advance copy in the prescribed proforma
must also be sent by the candidate applying on deputation. The candidates applying on contract
should submit the applications in the prescribed proforma complete in all respect and supported
by self-attested copies of all certificates related to educational qualification, quali&ing service,
and nature of experience.

Applications should reach to the Secretary, PSERC on ot tetore 91.tl6..lzoz\

g;

@'Applicationswi|lgetrejectedifnotreceivedintime
and ifnot supported by documentary proof.

PROFORMA OF APPLICATION
Name ofthe post applied for
Name oIthe App1icanl ...............................

self

S/o D/o W/o............

attested

Date oIBirthi...........

passpon size

Present Address wilh telephone no..............

photograph

Permanent Address with altemate telephone no..........................

here

Email lD: ...............
Name of Office/Department where presently employed.............
Present post held..r....
Date ofappointment to the present post.........
Present Grade pay & scale ofpay/lumpsum amount....................
Educational qua1ificarions............................
Nature ofexperience:

Details ofEmployment: (Enclose a separate sheet duly authenticated by your signature,
the separate space below is insufficient)

il

<!-- page 3 -->

Name
of the
oIIice/
Orgn.

Post
held

Nature
of From-To
appointment
(Dates)
whether regular,
ad-hoc, deputation,
contract etc.

* The age ofthe candidate should not be more
application for the post on contract.

Scale of pay and Nature of
basic pay & GPi experience
Lumpsum amount

than 62 years on the last date of receiving

Signature of the Candidate

H\r

SEtrIETfi- .
