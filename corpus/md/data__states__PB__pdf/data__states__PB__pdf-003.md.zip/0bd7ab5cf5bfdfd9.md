---
doc_id: "0bd7ab5cf5bfdfd9"
source_url: "https://pilbs.punjab.gov.in/media/documents/tender_patient_kitchen_dietary_services.pdf"
ministry: "Punjab Institute of Liver & Biliary Sciences"
title: ""
date: ""
pages: 1
method: "tesseract:pan+eng"
script: "LATIN"
needs_ocr: false
sha1: "0e4d9741a5e9575b"
---

<!-- page 1 -->

FORMATING FOR SUBMITTING TO DPROs
(Annexure-1)
ae Name of Department Directorate of Medical Education and
Research, Punjab
2. Name of the Office Punjab Institute of Liver 810 Biliary
Sciences, Phase 3131, Sector-60, S.A.S.
Nagar, Mohali
3. Name and Designation of Nodal Officer Dr. Virendra Singh, Director, Punjab
Institute of Liver and Biliary Sciences,
Mohali.
ey Contact No. of Nodal Officer 9417030923
ਤੀ 0172-2998300
Email ID of the office dir.pilbs@punjab.gov.in
punjabilbs@gmail.com
EEGs Website of the Department/Office https://pilbs. punjab.gov.in/
Name of Work/Notice/Tender Tender for Purchase of Patient Kitchen
Dietary Services for hospital at Punjab
Institute of Liver and Biliary Sciences,
_ Phase-3B1, Sector-60, S.A.S. Nagar, Mohali.
Haz Opening Dated of Bid Submission 06/05/2026
Closing date of Bid of Submission 19/05/2026
aS Amount of EMD (in Rs. i 21,000/-
Remarks (eg, Excluded newspapers) [Sid
੪ prestst.
ਰੇ 0000)
xa Bary SH
nth oh LE and yaa ਉਨੀ?
141 rot 60. ‘
signature @fthe Competent Authority
6੬ scanned with OKEN Scanner
