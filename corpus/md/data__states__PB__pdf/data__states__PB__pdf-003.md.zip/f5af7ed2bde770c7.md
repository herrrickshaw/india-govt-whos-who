---
doc_id: "f5af7ed2bde770c7"
source_url: "https://armedpolice.punjab.gov.in/wp-content/uploads/2025/05/STANDING-ORDER-2-OF-2021-CT.pdf"
ministry: "State Armed Police, Punjab"
title: "STANDING ORDER 2 OF 2021 CT."
date: ""
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bdc8ab0f21bdab7c"
---

<!-- page 1 -->

RECRUITMENT FOR THE POST OF POLICE CONSTABLE IN CADRES OF
DISTRICT POLICE AND ARMED POLICE OF PUNJAB POLICE.
STANDING ORDER NO. 02 of 2021
(issued under Sec. 4(d) and Sec. 45(g) of Punjab Police Act 2007)
1.

AIMS AND OBJECTS
This Standing Order is being issued to lay down the criteria, procedure and
detailed guidelines for recruitment to the post of Constable in the District Police
and Armed Police of Punjab Police (except recruitment against 3% posts
reserved for sportspersons) in an objective, fair and transparent manner. This
Standing Order shall govern the entire process of recruitment from the issue of
advertisement to final selection under the overall regulatory framework laid down
by the Punjab Police Act, 2007 and Punjab Police Rules, 1934.

2.

CONSTITUTION OF RECRUITMENT BOARDS
The recruitment shall be carried out through a Single Solution Provider
(hereinafter referred to as the Solution Provider) engaged for providing end-toend services for recruitment of police personnel in Punjab Police Department
under the supervision of Chairman, State Level Police Recruitment Boards
(hereinafter referred to as the Central Recruitment Boards) duly constituted by
the Director General of Police, Punjab, which will exercise overall supervision
over the entire recruitment process.
A short advertisement shall be published in the leading print and
electronic media, and a detailed advertisement shall be uploaded on the Punjab
Police website/portal created for recruitment.

3.

CONSTITUTION OF RECRUITMENT SUB-BOARDS
Requisite number of Sub-board(s) may be constituted by the respective Central
Recruitment Boards, with the approval of the Director General of Police, Punjab
for assisting in the process of selection for recruitment. The Chairpersons of the
Recruitment Sub-Boards may associate such number of GOs and NGOs/EPOs,
as deemed necessary, for the purpose of conduct of the recruitment process at
the Sub-Board Level.

4.

RESERVATION POLICY
Punjab

Government

instructions

regarding

reservations

for

Scheduled

Castes/Scheduled Tribes, Backward Classes, Ex-Servicemen (including lineal
descendant of Ex-Servicemen, where applicable), Women, Wards of Freedom
Fighters, Wards of Punjab Police Personnel and Economically Weaker Sections
(EWS) shall be strictly followed during the recruitment process and the Central
Recruitment Board will ensure that the guidelines laid down on the
Reservation Policy by the State Government are complied with.
-1-

<!-- page 2 -->

4.1

RESERVATION

FOR

SCHEDULED

CASTES

AND

BACKWARD

CLASSES
The reservation for Scheduled Castes and Backward Classes shall be
implemented in accordance with the Punjab Scheduled Castes and
Backward Classes (Reservation in Services) Act, 2006 as amended from
time to time and existing instructions of the Punjab Government.
4.2

RESERVATION FOR ECONOMICALLY WEAKER SECTIONS (EWS)
Reservation for Economically Weaker Sections shall be provided in
accordance with the Punjab Government instructions issued by the
Department of Social Justice, Empowerment & Minorities (Reservation
Cell) vide letters No. 1/3/2019-RC1/120 dated 28.05.2019 and No.
1/3/2019-RC1/700 dated 30.10.2020.

4.3

RESERVATION FOR EX-SERVICEMEN
Reservation for Ex-servicemen or wife or dependent child of an Exserviceman or grandchild of a Gallantry Award Winner shall be provided in
accordance with the Punjab Recruitment of Ex-servicemen Rules, 1982,
as amended from time to time.
Note 1: Reservation under Ex-serviceman category shall only be
available for residents of Punjab.
Note2:

The personnel of Central Armed Police Forces (BSF, CRPF,
ITBP, CISF, SSB etc.) are not eligible to be considered under the
Ex-Servicemen category.

Note3: The candidates desirous of availing benefit as Ex-Servicemen or
as the lineal descendants of Ex-Servicemen, as prescribed under
the Punjab Recruitment of Ex-Servicemen Rules, 1982 as
amended from time to time, shall submit a certificate issued by
the concerned District Defence Services Welfare office.
Note 4: Wife or dependent child of an Ex-Serviceman shall be required to
qualify the Physical Measurement and Physical Screening Test
as per parameters prescribed for candidates, who are not exservicemen; and score the minimum pass marks in the Written
Examination for his/her category.
4.4

RESERVATION FOR WOMEN
Reservation for women shall be implemented in accordance with the
Punjab Government, Department of Social Security, Women and Child
Development

(Social

Security

Branch)

notification

No.
-2-

<!-- page 3 -->

G.S.R.87/Const./Arts 309 and 15/2020 dated 21.10.20. This reservation
shall be horizontal and compartmentalized.
4.5

RESERVATION FOR WARDS OF FREEDOM FIGHTERS
In accordance with the notification No. 7(135)-3PII-83/5728 dated
03.03.1983, No. 7(135)-3PII-83/5824 dated 19.05.1988 and letter No.
16/57/97-8P3/Spl.;583 dated 27.11.2000 issued by General Administration
Department of the Government of Punjab, the son, daughter, grandson
and granddaughter (paternal and maternal) of Freedom Fighters or
Wards of those Freedom Fighters will be eligible for reservation, who have
either been granted a Freedom Fighters pension from the Punjab
Government or have been awarded Tamra Patras for their contribution
during pre-independence freedom movements.
The Deputy Commissioner of the concerned District will be the only
competent authority to provide an eligibility certificate regarding son,
daughter, grandson, granddaughter or wards of Freedom Fighters as per
extant Government instructions.
Note: Reservation for Wards of Freedom Fighters shall be available only
for the wards of those Freedom Fighters, who are residents of
Punjab.

4.6

RESERVATION FOR WARDS OF POLICE PERSONNEL
As per the Punjab Government order No. 1/1/2017-3DC/1588894/1 dated
03.10.2019, 4% vacancies are to be reserved for Persons With Disabilities.
The State Government has, however, granted exemption to the Police
Department from recruitment of Persons With Disabilities.
The Department of Home Affairs & Justice, Government of Punjab, vide
No. 1(211)94-2H(I)/10176 dated 11.6.1996, has further granted approval
for filling 2% posts for Wards of Police Personnel in lieu of Persons With
Disabilities. The remaining 2% of the posts shall be considered in the open
category (against the general roster points).

5.

ELIGIBILITY CRITERIA
5.1

CITIZENSHIP
The candidate must be a citizen of India. He/she must not have obtained
the citizenship/permanent residency/green card of any other country.

-3-

<!-- page 4 -->

5.2

AGE
The minimum age for the above mentioned recruitment shall be 18 years
and the maximum age shall be 28 years as on 1 January, 2021 subject
to relaxation in upper age limit as follows:
a)

Relaxation up to five (5) years in the prescribed upper age limit shall
be available to the candidates belonging to the Scheduled Castes
and Backward Classes, who are residents of Punjab. As such,
maximum age for such candidates shall be 33 years as on January
1, 2021.

b)

Ex-servicemen, who are residents of Punjab, shall be allowed to
deduct the period of his service in the Armed Forces of the Union
from his actual age, and if the resultant age does not exceed the
maximum age limit prescribed for direct appointment to such a
vacancy in the Service Rules concerned by more than three years,
he/she shall be deemed to satisfy the condition regarding age limit.

c)

Relaxation up to five (5) years in the prescribed upper age limit has
been granted to candidates, who are serving regular employees of
Punjab Government or of other State or Central Government. As
such, maximum age for such candidates shall be 33 years as on
January 1, 2021. However, there shall be no relaxation for such
candidates in any other parameters relating to educational
qualifications, Physical Measurement Test and Physical Screening
Test.

5.3

EDUCATIONAL QUALIFICATIONS
a)

The minimum educational qualifications for recruitment to the post
of Constable in District police and Armed police shall be 10+2 from
a recognized Education Board/University or Institution.

b)

Apart from the above mentioned qualifications, all candidates must
have passed Matriculation examination with Punjabi as one of the
compulsory or elective subjects or any other equivalent examination
in Punjabi language specified by the Punjab Government.

c)

Ward of Defence Service Personnel, who is a bona fide resident of
Punjab State, is appointed by direct appointment, he shall have to
pass

an

examination

of

Punjabi

language

equivalent

to

Matriculation Standard or he shall have to qualify a test conducted
by the Language Wing of the Department of Education of the
-4-

<!-- page 5 -->

Punjab Government within a period of two years from the date of
his appointment.
d)

The

candidate

must

have

attained

the

above

mentioned

educational qualifications on or before the closing date for
submission of the application for recruitment.
e)

A

candidate

has

to

upload

the

certificates

regarding

educational qualifications and Reservation if any along with
the application form
5.4

SERVING GOVERNMENT EMPLOYEES
Candidates already employed with the Government can also apply for the
recruitment after getting an NOC from the Head of Department/Office
concerned. However, if the NOC is not available at the time of filling of the
Application Form, then the candidate shall have to give a declaration to the
effect that she/he shall produce the same in original at the time of
document scrutiny before the physical measurement.

5.5

PHYSICAL STANDARDS
The minimum physical standards shall be as follows:

Cadre

6.

Minimum Height required
Male

Female

District

5’ 7” (5 feet 7 inches)

5’ 2” (5 feet 2 inches)

Armed

5’ 7” (5 feet 7 inches)

5’ 2” (5 feet 2 inches)

SELECTION PROCESS
The recruitment for filling up the vacancies in the two cadres, mentioned above,
shall be carried out through a Common Application Form (CAF) and Common
written test (OMR based) process followed by Physical Measurement Test (PMT)
and Physical Screening Test (PST) with specified qualifying parameters. All the
candidates shall be required to indicate their choice of cadres, in order of
preference, in the Application Form, provided they meet the eligibility criteria. In
case a candidate applies for only one cadre she/he shall be considered only for
posts in that cadre and not for posts in any other cadre. The preference indicated
in the application submitted by the candidate shall be final and cannot be
changed. The allocation of selected candidates to different cadres shall be on the
basis of their respective merit and the indicated preference of cadre against
category-wise vacancies subject to their fulfilling the requisite eligibility criteria.
-5-

<!-- page 6 -->

The selection process shall be a 2 (two) stage process consisting of the
following:


Stage 1:

A common written Test (OMR) would be conducted for District
Police Cadre and Armed Police Cadre by the “Solution Provider”
under the supervision of the Central Recruitment Board.
The Question Papers would be set by the “Solution Provider”
based on the syllabus and model question paper provided by the
Central Recruitment Board for getting the written test conducted
through the “Solution Provider” under supervision of the Central
Recruitment Board.
The Central Recruitment Board would decide the number of
questions and the ratio of questions with varying difficulty level in
question paper for written Exam (OMR).
The written Exam (OMR) shall have objective type questions with
multiple choice answers. The number of questions and duration
of exam would be decided by the Central Recruitment Board.
The questions shall carry fixed marks to be decided by the
Central Recruitment Board and the candidates shall be awarded
such fixed marks for each correct answer.
The Central Recruitment Board shall fix the specifications of the
OMR sheet, including the unique serial number, size, thickness,
GSM value, color coding, pattern and quality of the sheet. It is
clarified that this list is illustrative and not exhaustive and the
Central Recruitment Board may include other parameter(s) in the
list of specification.
Written Test shall be the sole criteria for assessing the merit of
the candidates, and the merit shall be determined by the marks
secured by each candidate in the Written Test.

6.1.2. Normalization - As Common written test (OMR) would be
conducted on different dates, with different sets of questions, for
different sets of participants, normalization of scores shall be carried
out using the Mean Standard Deviation method using the following
formula:
Normalization mark of jth candidate in the ith Shift 𝑴𝒊𝒋 is given by
𝒈

𝑴𝒊𝒋 =

𝒈

𝑴𝒕 − 𝑴𝒒

𝑴𝒕𝒊 − 𝑴𝒊𝒒

𝒈𝒎

𝑴𝒊𝒋 − 𝑴𝒊𝒒 + 𝑴𝒒

𝑴𝒊𝒋 = is the actual marks obtained by the jth candidate in ith shift.
-6-

<!-- page 7 -->

𝒈

𝑴𝒕 = is the average marks of the top 0.1% of the candidates
considering all shifts (number of candidates will be rounded-up).
𝒈

𝑴𝒒 = is the sum of mean and standard deviation marks of the
candidates in the paper considering all shifts.
𝑴𝒕𝒊= is the average marks of the top 0.1% of the candidates in the
ith shift (number of candidates will be rounded-up).
𝑴𝒊𝒒 = is the sum of mean marks and standard deviation of the ith
shift
𝒈𝒎

𝑴𝒒 = is the sum of the mean marks of candidates in the shift
having maximum mean and standard deviation of marks of
candidates in the examination considering all shifts.
Calculation of marks will be up to 5 places of decimal
6.1.3. Minimum Marks - After normalization is carried out by Solution
Provider in the above-mentioned manner, candidates belonging to
Scheduled Caste, Backward Class, Economically Weaker Section
and Ex-servicemen categories shall be required to score a minimum
of 25% marks and candidates belonging to other categories shall be
required to score a minimum of 30% marks, in written test, to be
eligible to be considered for the next stage of the selection process.
6.1.4

Answer Key and Seeking of Objections - Upon completion of
the last session of the Written Test process, the Answer Key shall
be provided, by the Solution Provider, to the candidates on the
recruitment portal on the last day after the last sitting of the
written test. Candidates will be given 72 hours to raise objections
to the answer key. A nominal fee of rupees 50/- shall be charged
per objection. The fee shall be refunded if the objection is
sustained.

6.2

STAGE 2 - DOCUMENT SCRUTINY, PHYSICAL MEASUREMENT TEST
AND PHYSICAL SCREENING TEST
Sufficient number of candidates shall be shortlisted and called for Stage 2
on the basis of merit determined by the aggregate/cumulative marks
obtained in written Papers (OMR) of the following normalization and after
factoring in reservation for various categories.
Stage 2 of the selection process consisting of Document Scrutiny, Physical
Measurement Test and Physical Screening Test shall be conducted by the
Solution provider at place(s) and dates designated by the respective
Central Recruitment Boards.
6.2.1. DOCUMENT SCRUTINY
Candidates called for Stage 2 of the selection process shall be
required to report for document scrutiny on the designated date(s),
-7-

<!-- page 8 -->

time and place as mentioned in the Admit Card to be issued by the
Solution Provider. Details of the same would be uploaded on the
recruitment portal. Candidates shall be required to bring the
following certificates in original along with one self-attested copy of
each document:
a)

Matriculation certificate for proof of age.

b)

10+2 certificate from a recognized Education Board/University
or Institution.

c)

Proof of having passed Punjabi at Matriculation level.

d)

No

Objection

Certificate

(NOC)

from

the

Head

of

Department/Office concerned, in case of candidates, who are
serving Government employees.
e)

Reservation Certificate (If available)

Note: The candidates, whose documents uploaded with the
application form match with the original presented on the spot, shall
be eligible to undergo the Physical Measurement Test. In case the
document(s) do not match with the original or a candidate unable
to produce original certificate, the candidature shall be cancelled
and may render the candidate liable for legal action.
6.2.2. Physical Measurement Test (PMT)
All shortlisted candidates, whose uploaded documents are found to
match with the originals produced, shall undergo Physical
Measurement Test, which shall be qualifying in nature.
6.2.3. Physical Screening Test (PST)
Candidates fulfilling the prescribed minimum height criteria shall be
eligible for the PST, which shall be qualifying in nature, and shall
comprise of the following events:
i.For District Police and Armed Police cadres
Candidate
For Male Candidates
(excluding ExServicemen)

Events in the Physical Screening Test
(a) 1600 meters run to be completed in 6

minutes 30 seconds (only one chance).
(b) Long Jump 3.80 meters (3 chances).
(c) High Jump 1.10 meters (3 chances).

For Male Candidates
Ex-Servicemen of age
less than and equal to 35
years

(a) 1400 meters walk and run to be completed

For Male Candidates
Ex-Servicemen of age
more than 35 years

(a) 1400 meters walk and run to be completed
in 12 minutes (only one chance).

in 09 minutes (only one chance).
(b) 10 full squats (only one chance)

(b) 10 full squats (only one chance)
-8-

<!-- page 9 -->

For Female Candidates
(excluding

(a) 800 meters run to be completed in 4 and 30
seconds minutes (only one chance).

Ex-servicemen)

(b) Long Jump 3.00 meters (3 chances).
(c) High Jump 0.95 meters (3 chances).

For Female Candidates
Ex-Servicemen of age
less than and equal to 35
years

(a) 800 meters run to be completed in 5:00
minutes (only one chance).

For Female Candidates
Ex-Servicemen of age
more than 35 years

(a) 800 meters run to be completed in 06
minutes (only one chance).

(b) Long Jump 2.75 meters (3 chances).
(c) High Jump 0.90 meters (3 chances).

Note1: Candidates shall be required to qualify all the events for the
particular category to which he/she belongs. Failure to qualify any one
event for that particular category shall disqualify the candidate.
Note2: Physical Measurement standards and events for Physical
Screening Test with respect to the wife or dependent child of an ExServiceman shall be same as that for candidates, who are not exservicemen.
Note 3: A candidate, who has applied for recruitment to posts in cadres
with different Physical Screening parameters, shall be required to appear
in two different Physical Screening Tests to be conducted on two different
dates subject to her/his fulfilling other eligibility requirements. Candidates
shall be required to qualify all events of the Physical Screening Test meant
for a particular cadre, as mentioned above, on the assigned date.
Note 4: Candidates may note that random testing shall be undertaken to
rule out the use of performance enhancing drugs. Candidates randomly
selected for such test(s) shall have to provide the required biological
sample as instructed. Refusal to provide such biological sample would
disqualify a candidate and make him/her ineligible for selection.
6.2.4. Appeals Relating To Physical Measurement Test and Physical
Screening Test
Candidates may appeal against the result of the Physical
Measurement Test and/or Physical Screening Test, if they so
desire, to the Chairperson of the Central Recruitment Board or the
Appellate Authority as designated by the Chairperson Central
Recruitment Board, at the Physical Measurement and Physical
Screening Test venue on that very day.
The decision of the Chairperson or the designated Appellate
Authority, as the case may be, shall be final and no further appeal
or representation in this regard shall be entertained. The
-9-

<!-- page 10 -->

Chairperson, or the designated Appellate Authority, as the case
may be, shall record the decision and the reasons thereof, in writing
for each case of appeal separately.
7.

Selection List (s)
a) From amongst the candidates found successful in the written test, PMT
and PST, Selection list of each category of candidates, as per order of
marks obtained in the written test, shall be prepared, keeping in view
the reservation policy.

8.

MERIT LISTS
(a)

Separate cadre-wise merit lists shall be prepared by the Solution Provider,
keeping in view the available vacancies in respective cadres, after
factoring in the prescribed reservations for different categories, on the
basis of aggregate/cumulative marks obtained in written test following
normalization (as mentioned in para 6.1.2).

(b)

In case of applicants scoring the same aggregate marks in the written test,
the following criteria shall be adopted to determine inter-se merit:
i.

The candidate senior in age shall be placed higher in the merit list.

ii.

In the event of candidates scoring equal marks in the written tests and
having same date of birth, then their relative merit in the Preliminary
Merit List shall be prepared on the basis of the percentage of Marks
obtained in the 10+2 examination and the candidate having higher
Percentage marks in the 10+2 examination shall be placed higher in
the merit in the Preliminary Merit list.

iii.

In the event of candidates scoring equal marks in the written tests and
having same date of birth and having same percentage of marks
obtained in the 10+2, the candidates shall be placed in the
Preliminary Merit list in the alphabetical order of ‘First Name’.

(c)

There shall be no waiting list.

(d)

Solution Provider shall provide the cadre-wise Merit Lists, prepared in the
above mentioned manner, to the Chairpersons of the respective Central
Recruitment Boards.

(e)

The Central Recruitment Boards shall finalize the list of selected
Candidates to be recommended for recruitment after following the roster
as per the Government instructions regarding reservation for different
categories, except sportspersons.

-10-

<!-- page 11 -->

9.

DECLARATION OF FINAL RESULT
The respective Central Recruitment Boards shall submit cadre-wise Merit Lists to
the Director General of Police, Punjab, for approval. The final cadre-wise results
of the selection process shall be uploaded after approval on the recruitment
portal and the Punjab Police official website www.punjabpolice.gov.in

10. RECEIPT OF RECRUITMENT DATA BY CENTRAL RECRUITMENT BOARD
The Solution Provider shall hand over the recruitment data to the Central
Recruitment Board or any authority duly authorized by the Central Recruitment
Board, within 15 days upon the completion of the recruitment process. The data
shall be properly indexed and structured and shall be provided in duplicate, on
separate hard disk drives.
11.

PROVISIONAL SELECTION
The selection at this stage of the recruitment process shall be provisional, and
shall be subject to the following mandatory clearances:
i.

Medical examination

ii.

Character and antecedent verification,

iii.

Verification of educational qualification Certificates from the concerned
Boards/Universities, and

iv.

Verification of Certificates for claiming reservation for various categories
from respective issuing authority.

12. MEDICAL EXAMINATION
i.

Before the enlistment, by the competent authority in the respective cadre
of Punjab Police, the candidates shall have to be medically examined and
certified physically fit for service by the Civil Surgeon/Medical Board.

ii.

The Medical will be done as per the provisions of Annexure # 12.16 of
Punjab Police Rules, 1934 and shall also include a substance abuse test.

iii.

A certificate in the prescribed form signed by the Civil Surgeon personally
is an essential qualification for enrollment, as provided in Rule 12.16 of
Punjab Police Rules, 1934. No relaxation whatsoever shall be granted in
any of the prescribed parameters of the Medical Examination under any
circumstances.

iv.

Decision of Medical Board will be final. Nothing against its decision.

v.

The Solution Provider shall enable biometric verification of all the
candidates called for Medical Examination at the time of reporting for the
same.

vi.

The candidate found unsuccessful in Medical Examination shall be
declared unfit and will not be enlisted.
-11-

<!-- page 12 -->

13.

VERIFICATION OF CHARACTER AND ANTECEDENTS
a)

The verification of character and antecedents of the provisionally selected
candidates shall be undertaken as laid down in the Punjab Police Act
2007, Punjab Police Rules, 1934 (as amended from time to time), other
relevant Rules, Government Instructions and the judgments delivered by
the Hon’ble Supreme Court of India and Hon’ble High Court of Punjab &
Haryana in this regard by following the prescribed procedures through the
concerned competent authorities.

b)

The Hon’ble Supreme Court of India has, in case of Delhi Administration
vs Sushil Kumar (1996), held that “the verification of character and
antecedents is one of the important criteria to test whether the selected
candidate is suitable to a post under the State… What would be relevant is
the conduct or character of the candidate to be appointed to the Police
Service.”

c)

The selection of the candidate shall be subject to the verification of his/her
antecedents in the Verification Process and if anything adverse is found
against the candidate during the verification process, his/her candidature
shall be summarily rejected and no claim, whatsoever, shall be entertained
in this regard thereafter.

d)

Where the appointing authority upon verification of character and
antecedents of the candidate recommended for appointment comes to
know that criminal proceedings against a candidate is in progress and the
status of the case is reported to be either under investigation or challenged
or cancelled or sent untraced or withdrawn or under trial or has either been
convicted or acquitted or the candidate has preferred appeal against the
order of the court; the appointing authority upon verification shall deal with
the cases of candidates reported to have criminal cases registered against
them and to the matters connected therewith as stated hereinafter:
(i)

Candidate found to have been convicted for an offence involving
moral turpitude or punishable with imprisonment for three years or
more, shall not be considered for appointment;

(ii)

Candidate against whom charges have been framed for offence(s)
involving moral turpitude or which is punishable with imprisonment
of three years or more, shall also not be considered for
appointment;

(iii)

Candidate who has been acquitted in offence(s) related to
sovereignty of the State or national integrity i.e. spying against
national interest/waging war against the State/act of terrorism/
communal disturbance/smuggling of arms, ammunition or Narcotic
Drugs & Psychotropic Substances or counterfeit currency etc.
-12-

<!-- page 13 -->

besides heinous crimes e.g. murder, rape, dacoity, robbery,
kidnapping for ransom, acid attacks, human trafficking, Protection
of Children from Sexual Offences Act, 2012 or Prevention of
Corruption Act, 1988 etc., ‘on technical grounds’ i.e. where, in the
opinion of the Court the material prosecution witnesses have either
been killed or have died or remained untraced or turned hostile or
won over and the candidate has been acquitted on account of
aforementioned circumstances; such candidates shall not be
considered for appointment.
(iv) If it is ever revealed that a candidate had got appointment either by
concealment of facts or by furnishing false or wrong information or
by submitting fake or forged document/certificate, he/she shall be
summarily discharged from the service by the appointing authority
from the date of appointment, i.e., without holding a regular
disciplinary proceeding, treating him ineligible for service and salary
paid to him may also ordered to be recovered.
14.

VERIFICATION OF CERTIFICATES

14.1

Verification of educational qualification certificates shall be got conducted
from the concerned Universities/Institutions/Boards.

14.2

Verification of Certificates for claiming reservation for Scheduled Castes,
Backward Classes, Economically Weaker Sections (EWS), Wards of
Freedom Fighters, Wards of Punjab Police Personnel and Ex-Servicemen,
shall be got conducted from the concerned department/unit or organization
as the case may be.

14.3

In case any of the above mentioned certificates, submitted/produced by
the candidate, is found to be fake/forged, his/her candidature shall stand
cancelled and render the candidate liable for legal action.

15.

JOINING AND PERIOD OF PROBATION
15.1

The candidates selected, in the above-mentioned manner, shall be given
an offer of appointment by the competent authority indicating the timeframe for joining.

15.2

The selected candidates, after joining, shall be on Probation, in
accordance with the Rules and instructions, as applicable.

16.

UNFILLED VACANCIES
In case a vacancy remains unfilled on account of disqualification of
selected candidates in medical examination/character and antecedents
-13-

<!-- page 14 -->

verification/verification of education/reservation certificates or due to non
joining of selected candidate(s) or on account of any other reason, after the
above mentioned process, such vacancies shall be carried over to next
selection.
17.

INTER-SE SENIORITY
The inter-se seniority of the candidates selected to a particular cadre within a
batch shall be prepared on the basis of their relative position in the Merit List, as
mentioned in Para above.

18.

PLACE OF DUTY
(a)

Recruited candidate(s) can be posted/deployed anywhere in Punjab, India
or abroad.

(b)

Since some of the vacancies of Constables are based in the State
Headquarters in Chandigarh/SAS Nagar, newly recruited Constables can
be posted in Chandigarh/SAS Nagar.

(c)

As per Section 4(b) of the Punjab Police Act, 2007 transfer of a member of
one cadre to another cadre shall not be allowed.

(d)

The posting and deployment of recruited Constables shall be subject to
various Rules, Policies and instructions issued/laid down by the Punjab
Government/Punjab Police from time to time, including the:-

i.

Initial Placement/Range/District Allocation

ii.

Posting and Transfer Policy and

iii.

Tenure Policy

as regards the officials of various cadres of Punjab Police with aim to ensure
efficiency, transparency, fair dealing, accountability in public dealing and police
functioning.
19.

REGULATION OF SERVICE CONDITIONS
19.1

Services of the selected candidates shall be governed by the Punjab
Police Act, 2007, Punjab Police Rules, 1934 as amended from time to
time, and other relevant Rules/orders of the State Government and
Standing Orders/Instructions issued by the Director General of Police,
Punjab.

19.2

The Punjab Police reserves the right to regulate the service conditions of
the candidates joining the Punjab Police through this recruitment process.

-14-

<!-- page 15 -->

20.

APPLICATION FEE:
The fee applicable to candidates belonging to different categories shall be as
follows:
Category

Application
Fee
(Rs)
400

Examination
Fee
(Rs)
600

Total
(Rs)

Ex-Servicemen(ESM) of Punjab
state only Lineal Descendants of
ESM

400

0

400

SC of all the States and Backward
Classes of Punjab State only

400

150

550

Economically Weaker
Sections(EWS)

400

150

550

General

Note-1 :

1000

SC candidates belonging to other states are required to fill their
category as General Category. They are entitled only to fee
concession but not entitled to avail reservation.

Note-2:

The Application fee shall be deposited online alongwith the
Application form, via Net Banking, Debit/Credit Card Payment and
other popular Payment Wallets such as Paytm, PhonePe, etc.
The Application Form fee once deposited shall not be refunded
under any circumstances.

21.

ONLINE APPLICATION PROCEDURE
There shall be a Common Application Form (CAF) for recruitment to the post of
Constable in the District police and Armed police cadre of Punjab police.
I. Applications

must

only

be

submitted

in

the

online

mode

on

https://iur.ls/punjabpolicerecruitment2021 Candidates would be first required
to fill a Registration form followed by the Application Form, which in turn would
be linked to the fee payment gateway.
II. Candidates desirous of applying for posts in more than one cadre shall,
subject to their fulfilling of the eligibility requirements for cadre(s) applied for,
be required to indicate their choice of cadres in order of preference in the
application form. The choice given in the application, submitted by the
candidate, shall be final and cannot be changed later at any stage, under any
circumstances.
III. Candidate shall only be considered for posts in cadres for which he/she has
given her/his preference. In case a candidate has applied for only one cadre
he/she shall be considered only for posts in that cadre and not for posts in any
other cadre.

-15-

<!-- page 16 -->

IV. Applicants are advised to read the instructions, as given in the recruitment
portal, carefully, before filling–up the application form. Incomplete application
shall be rejected outright and no correspondence shall be entertained in this
regard.
V. The applicants are advised to fill all details, including their correct and active
email address and mobile number, in the online application.
VI. Applicants must ensure that they have access to good internet facility with
reasonable speed and facility to ensure proper completion of application
process including online payment of fee.
VII. Before starting to fill-up the online application form, candidates must keep the
following

information/documents

ready

(including

scanned

copies

of

documents to be uploaded) as the candidates would be required to upload the
requisite documents, as applicable, in the online Application Form:

Personal details



Valid and active E-mail ID



Valid and active mobile number for receiving SMSs



One ID proof (Passport, Voter I-card, Driving License, PAN card)



Matriculation certificate for proof of age



Details/certificates pertaining to requisite educational qualifications
including that for Punjabi language



Certificates issued by the Competent Authority for claiming benefit of
reservation, if applicable.



Online payment Facility such as internet banking, debit/credit card etc.



Scanned recent (not older than 3 months) passport size photo against
white background (maximum 50-200 KB size in JPEG format). The
photograph should be as per the guidelines given in the website
www.passportindia.gov.in .



Scanned signatures (maximum 50-200 KB in JPEG format)

VIII. Candidates should fill all details, including the category, correctly in online
application form and submit the same only after ensuring that all the
particulars/ details correctly reflected in it. No request for any change in the
online application form, after it is submitted, shall be entertained.
IX. Candidate is required to declare her/his home district while filling up the
application form.
X. The candidates are advised to retain printed/ hardcopies of their online
application form and produce the same as and when required.
XI. All candidates, who apply for advertised posts shall be considered
‘provisionally eligible’ for appearing in the competitive exam. Acceptance of
applications at this stage and allotment of Roll Numbers would not indicate
acceptance of candidature, since there is no scrutiny of documents before the
Written Test.
-16-

<!-- page 17 -->

XII. The scrutiny of application forms shall be done after the conduct of the
examination. The candidature of applicants, who are found not meeting the
eligibility criteria, will be rejected during or after the scrutiny process.
XIII. Any attempt on the part of a candidate to obtain support for his candidature by
any unfair means will render him/her liable for disqualification and legal action.
XIV. Candidates already employed with the Government applying for this
recruitment, will be required to get a No Objection Certificate (NOC) from the
Head of Department/ Office concerned. If, however, the NOC is not available
at the time of filling up of the Application Form, the candidate shall have to
give a declaration to the effect that he/she shall produce the same in original
at the time of document verification.
XV. Candidates are advised, in their own interest, to submit online applications
well before the closing date and not to wait till the last date to avoid any
rush/server load on the website on the last days. The Board will not be
responsible for the candidates not being able to submit their applications
within the last date on account of the aforesaid reasons or for any other
reason beyond the control of the Recruitment Board.
XVI. In case a candidate submits more than one application, only the latest
application submitted by the candidate shall be considered.
XVII. In case the candidate experiences any difficulty in downloading the Admit
card, then he/she may contact the Helpline for assistance. Unique
Registration ID may be kept handy while contacting the Helpline.
XVIII. While filling the Common Application Form (CAF), the candidates would be
required to give an undertaking regarding the genuineness of their
candidature and correctness of the information provided by them in CAF.
Submission of wrong information by the candidate may invite legal action.
XIX. Last date and time for submission of online applications will be as prescribed
in the advertisement.
22.

HELPLINE/ TOLL FREE NUMBER FOR QUERIES AND CLARIFICATIONS
A dedicated toll free number helpline shall be made functional by the Solution
Provider, to help candidates applying for recruitment.
This Standing Order shall supersede all the previous Standing Orders for direct
recruitment of Constables (except recruitment against 3% posts reserved for
Sports person), in District Police Cadre and Armed Cadre of Punjab Police and
shall remain

in force till such time that a fresh Standing Order is

issued

replacing this Standing Order.
Sd/(Dinkar Gupta, IPS)
Director General of Police,
Punjab

-17-
