---
doc_id: "53aeb1bf3e9e7fca"
source_url: "https://punjabcooperation.punjab.gov.in/sites/default/files/documents/Nazool-lands-Rules-1956.pdf"
ministry: "Co-operative Department, Punjab"
title: "View Document"
date: ""
pages: 15
method: "tesseract:pan+eng"
script: "LATIN"
needs_ocr: false
sha1: "e00c843bae41f8e5"
---

<!-- page 1 -->

IE NAZOOL LANDS (TRANSFER) RULES, 1956
1 “hort title: These rules may be called the Nazool Lands (Transfer) Rules, 1956
2 Definitions: in these nutes - ੧੩) Co-operative Society means a society formed for
the purpose of Cooperative farming and regigtered under the Cooperative Societies Act,
O12) Central Act No. 71 6( 1912), as in force in the State :
gine “fumils" means 2 male person and his dependants who live in one house
dst bave & COMMON ੧੧੦੧੧ 5
(੨) "Landlesy feanily" means family not owning any agricultural !and other than
the land used or-meant to be used as a bara, compost pit or the site of a house :
idl) “Nazoal land” means : (i) The land situated bevond ੧੯੮ miles of the
hunicipal limits. which has escheated to the State Government and has not already been
uppropriated by the State Government for any purpose.
(ii) such other land as the State Government may make available for
heli transterred under these rules :
(ws “Emit af Nazoul lund” means: (0 where land belongs to one kind, three
ates of 0੧੪0 land or six acres of unirrigated land or nine acres of banjar land:
(ip where land belongs to more than one kind. the acreage calculated
੧1੨ 110੧੧ proportion.
a ‘Transfer of Nazoal lands: (a) In a village where 1੧੩੦੦ land available is less
than 10 acres and is being leased to members of Scheduled Castes, it may be allotted to
the present lessees individually upto the limit of a unit of Nazool land (6 acres of
unirrigated or 9 acres of Bar.;vr Land) provided they do not own any land of their own.
11052 who own some land, they may be allowed such area as would make up the unit of
Nazoot land as defined in the rules, when added to their own land, and the rest may be
"ied to others.
1੧) hn the villages where Nazool land available is 10 acres or more, the
Scheduled Castes land owning Cooperative Societies may be formed by the heads of

<!-- page 2 -->

schedules! Castes families in accordance with these rules and the Nazool land may be
jig “Hou . ੧੧ them. In a village where no Cooperative Societies of the members of the
ਨ S ੫੪੩ Castes had been formed by the 16" May 1964, the land should be allotted to
Vides chedule Caste members instead of Schedule Caste Cooperative Societies.
-carding to these Rules. For this purpose. members of Scheduled Castes who are already
cultivating such lands are ੧੦ be preferred. In case there is more than one claimant for the

same piece of land. the allotment will be made by drawing lots.

In the matter of alioumemt of Nazool land under sub-rules (a) and (b) above, the
lis-Servicemen Schedule Caste members shall be given preference over other Schedule
Castes including Schedule Castes Harijans cultivating Nazool land.

(ec) ੧੧੩੦੦ land already under self cultivation of landless persons of
Backward Classes may be allotted to them, like members of Scheduled Castes in the
niainet prescribed at (a) and (9) above.

10।` In the village where agricultaral Nazool land has net been allotted and for

which no chyible persons are available for allounent under Clauses (a). (6) or (c) above.

should be sold in restricted auction, according to the procedure prescribed in Annexure
‘A’ amongst the Scheduled Castes who are dependant on agriculture and do not own
more than 10 acres of land. A member of the Scheduled Castes who owns less than 10
acres of land will be allowed to bid only to the extent that ihe land for which the bid is
yiven, together with the land owned by him does not exceed 10 acres.

(e)? A landless person dependant on agriculture who is a member of the
Scheduled Caste and resides in a village in which the land of fered for sale is situated shall
once be permittee te participate in the auction. Provided that if after the proceedings of
jeatticted auction sale as above more land is available for sale in the village, a landless
dependant on agriculture who is a member of the Scheduled Castes and resides in the
_ ther village of the same Patwar Cirele shall be permitted to participate in the auction of
the lund provided further, that if afier the auction of the land as here-in-before laid down
੨੧ more land is available for sale, a landless person dependant on agriculture who is a

<!-- page 3 -->

SSS
ਸਾ a ਲੇ
| Ve
| ember of the Scheduled Castes and resides in other village of the same Kanungo circle
5 3881 be permitted to participate in the auction.
3A Mortgaged Nazool lands: - In the case of Nazool ands mortgaged with possession
the mortgagers rights be transferred to the Cooperative Society of Scheduled Castes,
ਦੇ ਜਿਦ the Jand is 10 acres or more and to the individual members of Scheduled Castes
where ig jess than 10 acres, in the manner prescribed in rule 3 (a) and '$੧ and the
morrgayers should pay the entire mortgage amount which would be deemed as equal to
ihe sul price of the land, in cases where mortgage money exceeds the price to be charged
4s Government under mules. Where the mortgage amount is fess than the price to be
charged according to the rules. the difference between the two amounts should be paid ta
ihe Government and the mortgage money to the mortgagees.
38° Auction of trees : The tees standing on the Nazool lands transferred under ihese
rules should be sold by public auction by the Tehsildar concerned in consultation with the
allottces concerned and the sale proceeds should be credited to the accounts of the
allottees towards the payment of price of land to the Government. The trees standing on
\lazool lands not yet allotted to anyone, should be sold by public auction by the Tehsildar
concerned and the sale proceeds should be credited into the Government Treasury under
lhe appropriate head of account.
4. Heads of the families to form cooperative societies : (1) The heads of
Scheduled Caste fandless families in a village may form themselves into a cooperative
੨੬੧੯੧ .
Provided that the land owning head of a Scheduled caste family may also become
0 member on surrendering his land to the cooperative society on such terms and
- nditions as may be mutually agreed upon between him and the cooperative society.
(2) Where any dispute arises as to who is the head of a scheduled caste family.
it shall be decided by the Collector of the District.
€. ਹਰ Hag ਉ
ਸੰ CA ਪਰਾਣੀ ਜਾਂ ਨੰ ੪
ਹਿਤ ਜਿਸ ਦਾ ee ot we - ਜਾਂ ਪਰਾਣੀਆਂ ਨੂੰ ਠਾਂਮੜਦ _=੩=੦ “ - ” -

<!-- page 4 -->

_—
At
ay Any person aggrieved by the decision of the Collector under sub rule (2)
may. within fiftees days of the decision, appeal to the Commissioner. whose decision
i shall be final.
3. Transfer of Nazoot land to Cvoperative Societies: -(1) As soon as a cooperative
eociety has been formed in a village, the nazool land in that village shall be transferred to
Provided that if units of nazool land in the village exceed the number of members
of the cooperanye Society only as many units of ੧82੦੦! Jand as there are members. shall
be wransferred lo the cooperative society.
Provided further that when the excess 15 00੧ more than two units of nazool land.
the entire ੧870 land in the village shall be aansterred to the cooperative society of the
village
Q) The nazool land which remains in excess under sub-mule (1) shall be
wanslerred to the cooperative society or societies. of the nearest village or villages in
which units of 03200! iand are less than the number of members.
6. Reversion in the event of dissolution: If at any time. before the payment of the
Jast instalment of price 4 cooperative society to which nazool 1800 has been transferred is
dissolved. the nazool land shall revert (0 the State Government on payment by the State
Higvernment of the amount already realized by it towards the price.
7. Bur on alienation : No Cooperative Society or the individual member of Scheduled |
Castes, as the case may be, shal! alienate oF sell or morlgs the Nazool Land and such
alienate op Sell. of moans i
land shall go down only in inheritance’: :
\
Provided that a Co-operative Society or & member of & Scheduled Castes to whom ;
such Jand has been transferred under these rules may temporarily alienate such land in
favour of the Punjab Scheduled Castes Land Development and Finance Corporation and
Scheduled Banks for securing & Joan with a view 10 improving this land rovided the
i

<!-- page 5 -->

— eee eee eee
sient of 0੩3 59 alienated shall not exceed the proportion of the tand for which price has | eo
8. Price : The price © be paid by Co-operative societyindividual allottee® for the
Nagool land to be transferred to 1੫ shall be:
(੫ Where such 18੧੧2 is assessed to ੧੪੦ revenue, 90 times the land revenue
(including rates and cesses) payable for such land : oF
(6) Where such land is not assessed tO jand revenue. 90 times the jand revenue
(including rates and cesses) payable for the lowest class of Jand in the
; villages oF
।
| (ey Rs 2O/- per acre :
1
| whichever is less.
।
' Provided that where ninety times the and revenue of the best quality of
, nazoot land in ਵੇ village exceeds ੧੮੦ ੧00੬2 rupees Pet acre. the price of other qualities
af nazool 1੪005 in that village inferior to the best quality shall be yeduced in the same
proportion. below two hundred rupees. aS the land revenue of such inferior ।ਗ bears ੧
the land revenue assessed on the best quality.
9%, Tnstalments: The price of the nazool jand transferred under these rules shall be
payable in twenty equal six monthly instalments. The first instalment shall be payable
along with the land revenue falling due in respect of the ੧੩੭੦੦) land next after its
tanstor, and thereafter each subsequent instalment shal} be likewise payable with the
land revenue.
0-੩". Recovery of Installments: (i) the arrears of instalments due under these rules
shall be recoverable as arrears of Jand revenue.

<!-- page 6 -->

9 “-
(੧) In case a Cooperative Society/individual member consistently makes
ofar (in making payment of two instalments of price of nazool land, the Collector may
é
ye nv the case and cancel the allotment of land to the Co-operative Society / individual
. ਨਵ whereupon the land shal! revert te Government.
Lilly he co-operative society individual member concerned may file an appeal to
the Commissiane: against the Collector's order within sixty days of the date of that order.
and the Commissioners order passed in appeal shall be tinal.
16. Application for transfer: (1) A cooperative society/individual member eligible mat
vader these rules for obtaining nazool land shall apply. in form ‘A! appended to these । ਪਕਾ
;``. to the Collector of the District in which the Nazool iand to be transferred 15
situated.
(2) On receipt of an application ੬ਇ sub-rule (1), the Collector may make or
cause to be made such inquiries as he may 08908 a for the purpose of verifying the claim
of the co-operative society/individual member.
13) |! the Collector is sadsfied as to the gemumeness of the claim of the
cooperative Socictyindividual member, he shal! take further steps for transferring the
vane in favour of the society “ individual! member in accordance with these rules.
(4) An order of transfer shall be issued by the Collector in favour of the Co-
iperative Society ‘individual member.
11. Certificate of transfer : (1) As soon as the last instalment of price has been paid
੧੯ the Cooperative Society/individual member in whose favour the wansfer has been
made under the rules. the Collector shall grant to it or to him under his signatures and seal
a certificate of transfer in form "B’ appended to these rules.
(I-A y Jn respect of land which is 5610 in restricted auction vide 101 3 ¢d) and the
cale has been confined by the authority competent 10 sanction sale, the District Collector
shatl put the person declared to be purchaser into possession of the property sold after
t. va tsa Qu varsd aractee + -- ੪. «

<!-- page 7 -->

1%੧
, : ।ਗੋਦ% ol 105੯ instalment ol the bid amount. The sale certificate conferring the
syapriclary rights in ths case shall be issued on compietion of the payment of all
¥ istalments and any other dues in respect of this land by the Collector under his
signatures and seal in the form 'B-1' appended ੧੦ theses rules.
(2) A copy of the certificate of transfer duly signed by the Collector shall be
retained on the file.
12. Records : A duplicate record of all receipts of money and the details of the co-
operauve society/individual member from whom price is to be recovered and also of the
instalments when they tall due shall be kept both in the Tehsi) concerned and the
Collector's office
13. Registers : _ =. register ot the Cooperative societies/individual member to
sine whom land is transferred under these rules and a register of such officers at such
ohice ar places shall be maintained in such form as the Financial Comnussioner may
direct
id. Appeai/Revision: Save as otherwise provided in these Rules, an appeal shall be
from an original order of Collector as follows. namely:
(a) to the Commissioner when the order is made by a Collector:
(b) to the Financial Commissioner, Revenue when the order 15 made by a
Cornmissioner:
Provided that
wa When the original order is confirmed on first appeal a further appeal shall
not lie.

<!-- page 8 -->

17?
ਡੇ
“i When any such order is modified or reversed on appeal by the
ਇੱ Commissioner, the order made by the Financial Commissioner, Revenue
on further appeal, if any. to him shall be final:
(੧) if no appeal lies to the Financial Commissioner. Revenue in any case, the
parly aggrieved by the order of the Commissioner may file the revision
before the Financial Commissioner, Revenue whose order passed thereon
shall be final.
144 Limitation for appeal/revision : Save as otherwise provided in these Rules. the
1੧੮੧੧ of limitation for an appealirevision under the foregoing Rule ।4 shall run from the
dare of the order appealed against and shall be as follows that is lO Say +
(a) When the appeal lies to the Commissioner sixty days:
(b) When the appeal/revision lies to the Financial Commissioner — ninety
days.
15. Nazool houses or house sites : Nazool houses or sites shal be evaluated by the
Deouty Commissioner on the basis of average market value in the locality and proposals
supmiitted to Geverament for their disposal keeping in view the location of the house or
the site. and the requirements of the various persons or institutions who could utilize the
property

<!-- page 9 -->

AMENDMENTS :
# | Wide notification No 526] -70171/-67/3992. dated 55796”
2 Rule 3(d)(e) added vide Notification No. 1426/31-LR-1L/3610. dated
196/85
2 Ipserted vide notification No. /890-8-7772:362/. dated 931972
4 amended vide notification No. 14:2/90-LR-HV4468, dated 18/3/91
° Word individual allottee inserted vide Notification No. 326)-JNUTI-
47/3569, dated 26/7/67
®  tdded vide Notification No, JS/57/ 1835. dated 8/5/1957
ਨ Rule 11 J-4) added vide Notification No. 14/268 1/LR-HL/861 0,
dared 19/6/85)
Substituted vide Notification No. 7807-3(1)-69/5361. dated 2/12/69
੧ Substituted vide Notification No. 8395-0(111)-69/137 i, dated
27/2/1970

<!-- page 10 -->

_ ~ 7 =~ ਜਾ ੧੧7 ਦਾ
i)?
ANNEXURE '੨'"
r PROCEDURE FOR SALE OF LAND THROUGH OPEN AUCTION
1. Approval of competent authority: When inferior evacuec land, evacuce
agricultural land. Nazool and Provincial Government land are to be disposed of through
wpen auction according to the conditions laid down in policy, approval of competent
authority in each cuse as laid down in the Punjab Financial Rules, Vol. I, may please to
be obtained before the sale is confirmed.
2. Procedure for sale through open auction: When it is decided to sell any piece of
land through open auction, then the following directions should be followed °
(1 Fixation of Reserve Price : Every auction of the land under these
instructions shall be subject to a reserve price fixed in respect of the land. In case ot sale
af inferior ewacuee land, Nazool (escheated) land situated within the Municipal limits.
aid upto ੧੧੦ miles beyond these limuts and evacuee agricultural land situated within 5
miles of the Indo-Pak Border, a reserve price shall be fixed at the current market price to
he determined atter taking into account the average price of land of similar kind in the
village or locality concemed during the last one year as per registered sale deeds, the
location of the land and other relevant factors. Where adequate No. of transactions of
land of the kind being sold had not taken place in the village/locality concerned during
the Jast one year the average price of transactions for the previous year or for the
neighboring village/locality may be taken into consideration, as may be considered to be
appropriate in a particular case. When the reserve price works out to Rs. 10 lacs or below,
it may be approved by the District : Collector; or when it exceeds Rs. 10 lacs but is upto
Rs. 50 lacs by the Divisional Commissioner and when it exceeds Rs. $0 lacs the
Financial Commissioner, Revenue,

(0) Reserve price for restricted auction : In case of sale of agricultural Nazool
(excheated) land ir, rural areas which cannot be allotted and for which no eligible persons
are available for its allotment under the Nazool Land (Transfer) Rules, 1956 and which
have. therefore. to be sold in restricted auction as laid im paragraph 7 of this Department
\> ayo under reference, the reserve price shall be 75 percent of the current market price to
be determined in accordance with the procedure laid down in sub-paragraph (i) above.
