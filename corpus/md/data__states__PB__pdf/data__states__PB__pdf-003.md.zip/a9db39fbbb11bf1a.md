---
doc_id: "a9db39fbbb11bf1a"
source_url: "https://www.peda.gov.in/media/NIT-CBG-policy.pdf"
ministry: "Punjab Energy Development Agencies (PEDA), Punjab"
title: "Public Notice - Open House Public Hearing on draft CBG policy 2026"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "dd1515ea01fa278f"
---

<!-- page 1 -->

PUNJAB ENERGY DEVELOPMENT AGENCY (PEDA)
PUBLIC NOTICE
OPEN HOUSE PUBLIC HEARING ON DRAFT CBG POLICY-2026
PEDA invites comments, suggestions and feedback from the public, industrialists, CBG
developers, investors and other stakeholders on, Draft Punjab CBG Policy. An Open House
Public Hearing will be held as under:
Date:
Time:

01.09.2026
11:30 A.M.

Venue:

Auditorium, PEDA, Plot No. 1-2, Sector 33-D, Chandigarh

The Draft CBG Policy is available on www.peda.gov.in. Stakeholders are requested to
participate and provide their valuable suggestions.
Chief Executive Officer
