---
doc_id: "ba0837d82aebec6b"
source_url: "https://pilbs.punjab.gov.in/media/documents/Punjab_Institute_of_Liver_and_Biliary_Sciences_Ethics_Committee_Order.pdf"
ministry: "Punjab Institute of Liver & Biliary Sciences"
title: ""
date: ""
pages: 1
method: "tesseract:pan+eng"
script: "LATIN"
needs_ocr: false
sha1: "ebab5cd56ef3128d"
---

<!-- page 1 -->

Punj .
Punjab Institute of Liver & Biliary Sciences
(Phase: 3B1, Sector-60, S.A.S Nagar, Mohali)
fue ORDER
ustitution Ethies Commit
aie ittce for Punjab Institute iver 4 iliary Sciences.
Mohali is hereby constituted as follows nstitute of Liver and Biliary Sciences,
S. | Position --- ਜ = = --------੧ ੨
Ral BS In Name Affiliation
1. | Chaiman ee ਜਿਲ ਇਤ nee
Chairman Prof. Kartar Singh Ex Professor, Department of
Gastroenterology
| Postgraduate Institute of Medical |
> |Menba Education & Research, Chandigarh _|
. | Member Prof. Lakshmi Narayana Professor, Department of
Secretary Yaddanapudi Anaesthesia
Punjab Institute of Liver and Biliary
3 Sciences, Mohali _
> | Member Dr. S. K. Sinha Professor. Department of "|
Clinician Gastroenterology
Postgraduate Institute of Medical
Education & Research, Chandigarh _
4. | Member Dr. Manpreet Dhaliwal ‘Assistant Professor of Molecular |
Basic Immunology |
| Medical
Scientist Pediatric Clinical Immunology &
Rheumatology, Department of
Paediatrics, Advanced Paediatrics |
Centre |
Postgraduate Institute of Medical |
Education & Research oi
5. | Member Justice B.S. Walia High court of Punjab & Haryana |
___| Legal Expert ਹੀ
6. | Member Dr. Swarn Singh Dhaliwal Ex-Member District Consumer
Redressal Forum and Public Utility
Social Services Commission
Activist ਕਤ a e ee ee eee
Treet ary Soo
੯ ੍‌ ah fary S ,
: ੧੧0੩੪ UNEP a PUN
uscd Sao Bt ਹਆ
phase 38) ੮
੭1੧੨.
Ende wo Pleas} enya Date . 21੧੨੧
Cos ve
॥ i a (੦੫੦੦੦ welts
© fu fle’
Scanned by {J Camera Scanner
