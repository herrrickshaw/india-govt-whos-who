---
doc_id: "def05c09e249faeb"
source_url: "https://cpcb.nic.in/uploads/hwmd/Guidelines_Handling_Processing_and_Recycling_ELV_11.03.2019.pdf"
ministry: "Punjab Pollution Control Board (PPCB), Punjab"
title: "Click to view"
date: ""
pages: 41
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5a3ad39451f54245"
---

<!-- page 1 -->

Guidelines for Environmentally Sound
Facilities for Handling, Processing and
Recycling of End-of- Life Vehicles (ELV)

January, 2019

Central Pollution Control Board
(Ministry of Environment, Forest & Climate Change, Government of India)

Parivesh Bhawan, East Arjun Nagar,
Shahdara, Delhi – 110032

<!-- page 2 -->

INDEX
Section

Description of Item

Page No.

1

Background

1

2

Introduction

2

3

ELV recycling activities: Environmentally sound depollution, dismantling, shredding, material recovery and
disposal of ELVs

4

4

Environment Policy- sustainable development includes
waste management

8

5

Rules under Environment (Protection) Act 1986 having
relevant provisions for regulatory framework applicable
for ELVs

8

6

Industry standard: Automotive Industry Standards (AIS:
129) on ELVs

10

7

Collection and handling of ELVs

10

8

ELV collection & dismantling centers

11

9

Handling, storage and transportation of ELVs

12

10

Environmentally sound de-pollution of ELVs

15

11

Environmentally sound dismantling and segregation

20

12

Environmentally sound Shredding and separation and
processing of residues

22

13

Technologies for the ELV recycling process

24

14

Requirements for setting up of ELV recycling facility

28

15.

Management of various wastes generated during
de-pollution, dismantling and shredding of ELVs

31

List of Figures
1

Stages of Environmentally Sound Management of ELV

4

2

De-pollution process

16

4

Typical ELV processing

24

<!-- page 3 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

1.0

BACKGROUND

End-of- Life Vehicle (ELV) is a motor vehicle that has been abandoned, or is
intended to be managed for the purposes of resource recovery. The
management of ELVs includes collection, handling, transportation, storage,
processing and channelizing materials or waste generated during
processing to appropriate recycling or waste disposal facilities respectively.
Such activities, if not carried out in environmentally sound manner, have
significant potential of impact on human health and environment and,
therefore, require environmentally sound management of the same.
Anticipating substantial increase in number of ELVs in coming years, CPCB
in the year 2016 prepared “Guidelines for the Environmentally Sound
Management of ELVs in India”. The said guidelines outline handling,
storage and transportation of ELVs; environmentally sound de-pollution of
ELVs; environmentally sound dismantling & segregation; Environmentally
sound Shredding & separation and processing of residues, and; ELV
recycling facility and technologies for the ELV recycling process besides
guidance on policy framework for ELVs in India.
Taking up issues of pollution caused during the scrapping of vehicles at
Mayapuri, Delhi, the Hon’ble National Green Tribunal, Principal Bench,
New Delhi, (in the matter of Original Application No. 996 of 2018; News
items published in The Times of India Authored by Paras Singh Titled “In
factory setting, Mayapuri’s scrapping through”) highlighted the need for
proper scrapping policy and guidelines for scrap handling, processing and
disposal and passed the following orders:
“… 5. Accordingly, we direct constitution of a Joint Committee headed by
Secretary, Ministry of Road Transport, Government of India with
representatives from CPCB, MoEF&CC and Delhi Government to examine the
matter and to prepare an appropriate scrapping policy. Such policy be
prepared by concerned Authorities within three months. The nodal agency for
this purpose will be the Secretary, Ministry of Road Transport.
5. A copy of this order be sent to the Secretary Ministry of Road Transport,
Government of India by e-mail for further follow up action. The first meeting of
the Committee may be convened, as far as possible, within one month from
today.
6. The report prepared may be furnished to this Tribunal on or before 31st
March, 2019 by e-mail at ngt.filing@gmail.com. The report received may be put
up for consideration before the NGT.
7. We further direct the Chief Secretary, Delhi, to take steps and prepare an
action plan for shifting the scrapyards from busy localities of Delhi to other
appropriate locations, within three months. After the scrap is shifted to a
1|Page

<!-- page 4 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

suitable location, the same may be handled, processed and disposed of as
per the guidelines of CPCB. Such guidelines may be issued by 31.01.2019,
by the CPCB
8. The Chief Secretary, Delhi and CPCB may also furnish their separate report
with regard to the action taken to this Tribunal on or before 31.03.2019.…”
In order to prepare guidelines on handling, processing and disposal of ELVs
in compliance with said orders of the Hon’ble Tribunal, CPCB reviewed the
said “Guidelines for the Environmentally Sound Management of ELVs in
India” prepared in 2016. A consultation meeting was also held by CPCB on
January 02, 2019, to seek suggestions/comments
from various
stakeholders such as Associations of Mayapuri; Automotive Component
Manufacturers Association of India (ACMA); Society of Indian Automobile
Manufacturers (SIAM), Ministry of Heavy Industries and Public Enterprises
(MoHI&PE); Ministry of Steel; Ministry of Environment, Forest & Climate
Change (MOEF&CC); Steel Research & Technology Mission of India
(SRTMI); National Automotive Testing and R&D Infrastructure Project
(NATRiP),; GIZ-India, Mahindra Groups; Tata Steel; Maruti Suzuki; Honda
Cars India Ltd, Toyota Tsusho India Pvt. Ltd (TTIPL).
These guidelines are in continuation of the aforesaid CPCB guidelines
prepared in 2016 considering comments received from the above
stakeholders. Procedures and facilities required in dismantling of ELVs
have been outlined in these guidelines along with various requirements
under environmental regulations. These guidelines would be helpful in
setting up and operation of ELVs management facilities in environmentally
sound management manner.

2.0

INTRODUCTION

ELVs are broadly divided into Natural ELVs and pre-mature ELVs. Natural
ELVs refer to those vehicles that have come to the end-of-life due to wear
and tear. Premature ELVs refer to those vehicles that have come to end-oflife due to unnatural reasons such as an accident, fire, flood or vandalism
damage (ASM 2015).
The global ELV generation is estimated to be 40 million ELV/ year; this
accounts for 4% of total global automobile ownership. (Sakai et al. 2013). It
is estimated that the number of vehicles to become ELV will be 2,18,95,439
by 2025. (CPCB report “Analysis of ELV sector in India”, 2015).
ELVs are known to contain hazardous substances including waste oil,
lubricants, lead acid batteries, lamps, electronic components, air bags, etc.
The recovery of these materials is of concerns: firstly, their recovery is often
2|Page

<!-- page 5 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

harmful to the health of the scrap recovery workers; and secondly, they
cause environmental contamination if improperly dismantled or disposed.
At present, nearly all of the automobile scrap yards in India are managed by
the semi-formal sector. Semi-formal recyclers use crude methods to recover
materials and are poorly organized among each other and with other
stakeholders of the ELV value chain.
ELVs contain large quantities of metal and other materials that, if salvaged
or recycled properly can be effectively fed back into the economy. This
reduces the environmental impacts arising from mining of primary
materials.
Secondary metals are processed using simple technologies requiring less
energy in comparison to the primary processing of metals. This further
reduces environmental impacts of resource use.
The reuse and recycling of vehicles provides an important opportunity for
transforming the resource use of societies. In India, up to 70% of a vehicle
are dismantled and directly reused or sold to other manufacturers’.
In the recycling process both ferrous and non-ferrous metals are recovered
and directed to reuse. It has been estimated that passenger cars contain
about 70% steel and 7-8% aluminum. The rest 20-25% is plastic, rubber,
glass etc., which are also recyclable recycling one ton of steel conserves
1,134 kg of iron ore, 635 kg of coal and 54.4 kg of limestone (Sakai et al.,
2013; Steel Recycling Institute 2014).
Finite resources are unlikely to fulfill the world economy’s increasing
demand for raw materials – unless production and consumption patterns
around the world become more resource efficient and sustainable. An
obvious symptom of increasingly scarce raw materials is rising prices.
Copper prices for instance have seen a significant increase over the past
years. These developments set additional incentives for ELV recycling, as
improved ELV recycling can contribute to increasing the amount of
recyclable material as well as to reduce waste volumes (Chen et al. 2010).
Metals (eg. copper, aluminum, etc) are mined; excessive extraction of
primary materials harms the ecosystem services that are vital for human
wellbeing. In order to avoid these issues, it is necessary to find ways how to
“create more with less” (European Commission 2015a) and reduce negative
environmental and social impacts throughout the life cycle of resources.
There are several challenges to be dealt regarding increasing the efficiency
and sustainability of ELV recycling in India as some of the wastes are
economically valuable materials. This matter is of larger concerns due to (a)
the growing demand for vehicles and (b) anticipated huge growth of ELVs.
3|Page

<!-- page 6 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

The resources present in these ELVs are significant and to address the
existing regulations for the channeling of hazardous and other wastes
include the Hazardous and Other Wastes (Management and Transboundary
Movement) Rules, 2016; Batteries (Management and Handling) Rules, 2001;
E-Waste Management Rules, 2016; Solid Waste Management Rules, 2016
and Plastic Waste Management Rules, 2016.

3.0 ELV recycling activities: Environmentally sound de-pollution,
dismantling, shredding, material recovery and disposal of ELVs
The environmentally sound recycling process of ELVs comprises four major
stages and is depicted below:
Vehicles in use –ELV-last owner ELV

Stage-1

De-Pollution
Remove Battery, Fluids, Tyres, Airbag

Reuse/Reprocessing
(Batteries, Fluids, Fuel)

Stage-2

Dismantling
Remove Parts/Materials

Reuse/Recycling
(Parts/Materials)

Stage-3

Shredding
Shred Vehicle, Reclaim Metals

Recovery/Recycling)
(Ferrous Metals)

Stage-4

Treatment
of Light ASR

Treatment
of Heavy ASR

Recovery/Recycling)
(ASR to Secondary Solid Fuels,
Energy, etc.)

Landfill Residue

Figure 1: Stages of Environmentally Sound Management of ELV
1. De-pollution: The recycling of ELV process starts at the dismantling or
treatment facility where it is first de-polluted and then dismantled
(sometimes these two steps are summarized as “dismantling”). De4|Page

<!-- page 7 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

pollution includes removing hazardous components and substances
such as the battery, fuel, other fluids, airbags and any parts
containing mercury. As the removed materials are hazardous in
nature such as explosive/ corrosive/etc., de-pollution must follow
strict health and safety rules and contamination of the environment
must be prevented. This includes storing hazardous components and
materials separately and providing adequate training for employees.
(UK DEFRA 2011).
2. Dismantling: Once the vehicle has been de-polluted it is then
dismantled. This process involves segregating and collecting recyclable
and reusable components, including engines, tyres, bumpers, and
other parts. The degree of mechanization of the dismantling process
depends on the costs of labour and availability of large scale
technology (Tian and Chen 2014). The recovered components and
fluids are sold for reuse in other vehicles (motor parts, batteries, fuel,
etc.) or for further recycling (tires, valuable metals, carpets, etc.).
According to experiences from the EU and Japan the car hulks weigh
approximately 55–70% of their original weight after dismantling (Sakai
et al. 2014).
3. All waste water that is produced during the de-pollution and
dismantling processes must be treated. Resulting waste material is
sent to incinerators for energy recovery or to landfills for disposal.
(Chen et al. 2010)
4. Shredding / Automotive shredder residue (ASR):
a. ASR is a highly heterogeneous mixture of residual ferrous and nonferrous metals (5–23%), plastics (20–49%), rubber (3–38%), textile
and fibre material (4–45%), wood (2–5%), and glass (2–18%). Some
of these components can be further processed: heavy ASRs are
molten for the recovery of valuable non-ferrous metals such as
aluminium and copper; combustible materials are used to make
fuel substitutes; etc. However, these components are difficult to
separate from other materials such as ash and heavy metals.
Therefore, it is more common to either use ASR for energy recovery
or to send them directly to landfills.
b. According to experiences from the EU and Japan the car hulks
weigh approximately 55–70% of their original weight after
dismantling (Sakai et al. 2014). The remaining hulk of the vehicle is
crushed so that it can be transported in a compact and costeffective form to the shredder facility. There it is broken up into fistsized pieces by large shredders. The shredded material is then
separated into ferrous metals for material recovery as well as nonferrous metals (heavy automotive shredder residue (ASR)) and other
materials (light ASR). The separation process is realized by complex
machinery such as magnetic separators, air classifiers, infrared

5|Page

<!-- page 8 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

systems, etc. (Sakai et al. 2014; ARS et al. n.d.). Processing scrap
in smelters usually produces secondary metal.
c. Several countries have high targets for the recycling rates of ELVs,
the recycling of ASR thus becomes increasingly important.
5. ELV recycling facilities within the overall ELV recycling chain, the
management of ASR is one of the most problematic steps and requires
further technological advances. (Vermeulen et al. 2011)
i.

In EU, the recycling of ELVs is organized under an Extended
Producer
Responsibility
Scheme,
according
to
which
manufacturers are responsible for increasing recyclability of
vehicles, disseminating information on recycling procedures and
providing free take-back of ELVs. (Sakai et al. 2013).

ii.

The EU ELV Directive determines that by 2015 all member
states have to reuse, recycle or recover 95% of an ELV by
weight. Out of this, energy recovery must not exceed 10%. The
EU ELV Directive obliges all member states to ensure that all
ELVs are transferred to authorized treatment facilities
(European Parliament and Council of the EU 2000). In 2006, a
total of 8,000 authorized ELV dismantlers operated within the
EU-25 territory, complemented by 232 shredding facilities. At
the same time, there remained a considerable number of illegal
treatment facilities, particularly in those countries that did not
have a sound ELV recycling system. Successful countermeasures include a national campaign launched by the UK
Environment Agency in April 2008 that reduced the number of
illegal ELV and scrap metal sites by 50% within one year. (EU
2010), With regard to ASR recycling the EU attempted to reduce
the amount and hazardousness of ASR by intensive
dismantling; another strategy is post-shredder treatment.

iii.

In Germany, dismantling facilities are responsible for depolluting as well as dismantling of ELVs. In 2014, there existed
approximately 1300 registered dismantling facilities (UBA 2014).
They are under strict obligations with respect to organizing the
process. These requirements relate to the dismantler’s
structure, equipment and operation, as well as to its
documentation procedures. Additionally, dismantling facilities
need to pass an annual certification by an external expert.
Shredding is realized by shredding facilities which have to
comply with similar obligations. (Kohlmeyer 2012)

iv.

In Japan, vehicle manufacturers and importers are required by
law to take back and recycle air bags and ASR, and to ensure
sound treatment of fluorocarbons. The recycling rates for air
bags and ASR are 85% and 70%, respectively. The costs of

6|Page

<!-- page 9 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

recycling the mentioned components are borne by vehicle users
who, at the moment of buying a new car or handing in an old
car, are required to pay a recycling fee. Collection of refrigerant
gases is mandatory as well and falls under the responsibility of
refrigerant gas processors. However, no recycling rate was
determined for these gases. (Sakai et al., 2013; Wang and Chen
2013) The processing of other components or liquids is done
voluntarily by dismantling and shredding facilities. In 2007,
5000 dismantling and recycling operators and 140 shredding
plants were registered. There exists no recycling rate for the
overall weight of the ELV. (Chen et al. 2010)
v.

In Korea, ELV recycling is done by the dismantling and
shredding facilities. For 2015 and onwards, a material and
energy recovery of ELVs of 95% was determined. This includes a
maximum energy recovery rate of 10%. (Serona et al. 2010)
ASRs are land-filled or incinerated (Sakai et al. 2013).

vi.

In Taiwan, ELV recycling is realized by dismantling and
recycling operators. In 2009, there were 303 recycling operators
and five shredding and sorting plants. These operators work
along three different business streams: a) trading of scrap metal
and reusable parts, b) trading of spare parts after the
dismantling process, and c) export of ELVs and used cars. ASRs
are disposed of in waste processors, incinerators or landfills.
(Chen et al. 2010)

vii.

In China, ELV recycling is realized by dismantling facilities. The
reuse of five major vehicle assemblies (i.e. engines, steering,
transmissions, axles and frames) is currently allowed only for
selected pilot facilities. (Wang and Chen 2013) By the year 2017
the recycling rate of ELVs should reach at least 85% (Sakai et
al. 2013).

viii.

In the U.S. ELV recycling is voluntary and driven only by the
economics of recycling. However, all steps of ELV recycling are
subject to monitoring under environmental law (Sakai et al.
2013). While the processing of most components is organized in
a de-centralized manner by the different actors of the ELV
recycling chain, there exist nationwide efforts for the collection
and recycling two particular contaminants, namely mercury
switches and vehicle tyres. With respect to mercury switches, a
broad coalition of federal, state, industry and environmental
non-profit partners in 2006 have created the National Vehicle
Mercury Switch Recovery Program (NVMSRP). The return of
switches under the NVMRSP is rewarded financially, through a
fund set up voluntarily by steel and auto manufacturers (U.S.
Environmental Protection Agency 2013). ASR that results from
ELV processing is land-filled.

7|Page

<!-- page 10 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

4.0

Environment Policy- sustainable development includes waste
management
The National Environmental Policy 2006 (NEP) focuses on sustainable
development and the need to facilitate the reuse / recovery/ recycling
of necessary material (resourceful) from waste, thereby contributing to
the conservation of natural resources and the reduction of wastes
destined for final disposal.
Eventually environmentally sound management (ESM) of all wastes
needs to be ensured. NEP encourages legal recognition and
strengthening of the informal waste sectors to be integrated into the
mainstream waste management activities.
Considering the large recycle potential of ELVs, these should be
recycled properly to recover valuable natural resources in an
environmentally sound manner. At present there is no separate policy
or law or regulation governing the management of ELVs. However, the
environmental compliances for recycling activities could be in
accordance with the prevailing laws such as The Water (Prevention &
Control of Pollution) Act, 1974, (The Water Act), The Air (Prevention
and Control of Pollution) Act, 1981 (Air Act) and the Environment
(Protection) Act, 1986 (EP Act) and the rules made there-under.

5.0 Rules under Environment (Protection) Act 1986 having relevant
provisions for regulatory framework applicable for ELVs
1. The wastes generated during environmentally sound recycling
process of ELVs shall be managed in accordance with the various
Rules notified by the Ministry of Environment, Forests and Climate
Change under the Environment (Protection) Act, 1986. These rules
have been notified in order to provide statutory provisions for
regulating the handling and management of wastes without causing
any adverse effects on environment and human health. The Rules
are implemented through the State Government and State Pollution
Control Boards or the Pollution Control Committees of the Union
Territories. The following waste regulations have been notified by the
Ministry that are applicable for the management and recycling of
ELVs:

a)

The Hazardous and Other Wastes (Management
Transboundary Movement) Rules, 2016.

b)

The Solid Waste Management Rules, 2016.

c)

The E-Waste Management Rules, 2016.

8|Page

and

<!-- page 11 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

d)

The Plastic Waste Management Rules, 2016.

e)

The Ozone Depleting Substances (Regulation and Control)
Rules, 2000.

All the above rules address environmental issues concerning waste
management (recycling or disposal). The different rules cover
industrial wastes, urban waste as well as post- consumer waste.
2. The concept of recyclability of wastes and regulating recycling activity
has been introduced in all these rules with the goal to increase the
recovery of resources thereby reducing the waste destined for
disposal. Some of these rules include provision for the
registration/authorisation of recyclers which have the capability to
recycle wastes using environmentally sound technologies (ESTs).
3. The hazardous substances and hazardous fluids present in ELVs such
as waste oil, transmission fluid, coolant fluid, brake fluid, power
steering fluid, hydraulic fluid, gear oil, lead acid batteries and other
materials arising from de-pollution shall be recycled or disposed of in
accordance with the Hazardous and Other Wastes (Management and
Transboundary Movement) Rules, 2016. In addition to these
substances, the hazardous solid wastes such as air filter, oil filter,
brake shoe, asbestos in clutch discs, etc. are required to be disposed
of in accordance with these Rules. Any recycling of these hazardous
wastes recovered from the ELVs shall be carried out only by the
registered recyclers notified under these rules. The residues
containing hazardous substances arising from both manufacturing
and recycling activities have to be disposed of in an environmentally
sound manner and the disposal procedures shall be decided on the
basis of the constituents present in the waste. All hazardous wastes
generated from the ELVs shall be disposed of in accordance with the
requirements under the Hazardous and Other Wastes (Management
and Transboundary Movement) Rules, 2016.

4. In compliance with the requirements under the Montreal Protocol the
Ozone Depleting Substances (Regulation and Control) Rules, 2000
have been notified. These rules provide a control on the production,
consumption, export and import of the 95 Ozone Depleting
Substances listed in the Schedule 1 of these rules. All refrigerants
containing ODS recovered from ELVs should be disposed off in
accordance with these rules.
5. The plastic waste which can be recycled shall be channelized to
registered plastic waste recycler in accordance with the Plastic Waste
Management Rules, 2016.
6. The collection, recovery and disposal of the solid waste shall be in
9|Page

<!-- page 12 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

accordance with the Solid Waste Management Rules, 2016.

7. Similarly, all electronic parts are to be treated and disposed of in
accordance with the E-Waste Management Rules, 2016 to channel ewaste for recycling to registered recyclers.
6.0 Industry standard: Automotive Industry Standards (AIS: 129) on
ELVs
The Automotive Research Association of India (ARAI) along with the
Society for Indian Automobile Association (SIAM) and the Automotive
Industry Standards Committee (AISC) under the Ministry of Road
Transport & Highways have developed 'Automotive Industry
Standards (AIS): AIS 129 addresses End-of-Life Vehicles' (ELVs)
which were notified in July 2015 by MoRTH. The main objective was
to enable automobile recycling to become an organized sector activity
and to prescribe minimal operational standards for automobile
recycling in-line with the European Directives of 2000 and 2005.

7.0

Collection and handling of ELVs
1. There is the need to develop a collection and channelization
mechanism for ELVs from the source of its generation for recycling
and recovery in an environmentally sound manner. The ELV
collection system needs to be established to facilitate the movement
of ELV in a regulated manner from its origin to the final destination
for recycling, treatment and disposal. The stages involved in the
process include establishing collection channels, setting up ELV
collection & deposition facilities, providing financial mechanisms for
collection, and organizing handling and storage.

2. Collection channels: There exist different collection channels for ELVs.
Bulk generators or fleet owners such as public transport and tourist
agencies (government and private) or offices (government and private)
adopt different modes of disposal of ELVs depending upon the number
of vehicles and their conditions. Bulk amounts of ELVs are usually
auctioned off by public agencies. The buyer is the highest bidder and
resale of automobile parts. The other mechanism that prevails is the
replacement of old and used vehicles by new ones through dealers or
the manufacturers.
Many automobile companies and bulk generators of ELVs carry out
regular sales of used vehicles which are conducted by private
agencies. The buyers may be individuals who intend to further use the
vehicle or auto scrap dealers or dismantlers. The Original Equipment
Manufacturers (OEM) also sell their manufacturing defects (parts) to
10 | P a g e

<!-- page 13 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

auto scrap dealers or dismantlers in the semi-formal sector.
Sometimes OEMs recall the vehicles with manufacturing defects and
rectify the same themselves or may also put the defective components
and equipment back into their own system by rectifying these.
Individual owners channel ELVs through sale or exchange of old
vehicles while buying new ones. In case of accidents and fire there are
also cases of vehicles abandoned on the road sides from which parts
and components are stolen.
Based on these common practices the ELV collection channels should
close the gaps in the recycling loop and prevent the loss of potentially
valuable material. In order to provide efficient collection systems for
ELVs, the actors in the collection channels are to assess the materials
for reuse and recycling in order to prevent improper recycling
practices in the backyard recycling units. Effective collection channels
would further enhance the availability of material for recycling and
make the tracking of material and material components possible.

8.0

ELV collection & dismantling centres
1) In view of the large size and volume of automobile scrap the
collection facility may need to be set up in large areas where the
various types of ELVs could be handled. ELVs in India would
include the small two and three wheelers, cars, large buses, trucks
and trailers. Depending upon the area available, different locations
to be assigned for different types of ELVs.
2) Take back could be provided by Collection and Dismantling
Centers. These may be created by upgrading existing vehicle
service centers, scrap yards or recycling workshops in co-operation
with vehicle producers. In a collective system, producers may setup
joint collection centers or collectively sign contracts with existing
ELV recyclers to organize the collection on their behalf. In an
individual collection each producer may have to set up his / her
own collection facility or sign individual contracts with collectors.
3) Generally, the collection system needs to fulfill the criteria of an
adequate area of coverage for collection. It is advisable to consider
a 50 km radius around a take back facility. Collection points or
centers can be established in designated places where ELVs are
collected. Such collection points could also be linked to a
centralized collection center where these could be stored and later
sent to dismantling/recycling plants.
4) The ELV collector shall provide information as per the
application/format prescribed by the Central Government, the
moment disposed vehicles transaction is completed with the de-

11 | P a g e

<!-- page 14 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

polluter/ dismantler/recyclers.
5) The person involved in dismantling of ELV shall ensure that the
vehicle has been declared as ELV (alongwith destruction
certificate) and the registration of the vehicle has been cancelled
as per Section 55 of the Motor Vehicle Rules, 1989.Such person
shall apply for de-registration of the ELV in Form 20 A as per
Rule 47a of Central Motor Vehicle Rules, 1989 to the
registration authority.
6) It shall be ensured that ELVs dismantled at dismantling facility
comply with Rules/guidelines/policy of Central Government or
Government of State/UT where such facility is located.

9.0

Handling, storage and transportation of ELVs
1) Handling : ELVs are often large in size (for example trucks and
buses) and require machines to handle them. Any vehicle that
reaches end-of-life needs to be lifted using cranes and towed to the
destination. At the Collection and Dismantling Centers facilities
cranes / lifting equipment would be required to move ELVs within
the unit. Adequate handling equipment should be required for any
ELV collection, treatment and recycling facility.
In accordance with AIS PART-1 para. 4.2.5 any person(s)
operating Collection Centre(s) and Dismantling Centre(s) shall
store the ELV (even temporarily) and treat in accordance with
Annex A without endangering human health and without using
processes or methods which could harm environment. ELVs
should be stored in a way that protects their value and protects
the surrounding environment. ELVs contain hazardous fluids
and other components that can pollute the soil, water, and air.
For example, when leaking fluids soak into the ground they
contaminate the upper soil layers as well as the underlying
groundwater. Likewise, storm water runoff from rainfall and
snowmelt can be contaminated if it comes in contact with greasy,
oily parts, or flows over contaminated soils or through puddles of
vehicle fluids. Contaminated storm water runoff can spread
pollution on one's property and onto neighbors' property. If
refrigerants (such as Freon) are allowed to escape from air
conditioning units in ELVs, they can spread to the upper
atmosphere and destroy parts of the earth's protective ozone
layer. In addition to storing ELVs in an environmentally
protective manner, there are good reasons to also store these
vehicles in an orderly, tidy manner. Organizing the vehicle
storage area helps to keep track of one's inventory and thus to
find a desired vehicle faster. Moreover, leaks and other potential

12 | P a g e

<!-- page 15 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

problems can be detected and dealt with more rapidly. (N.H.
Green Yards BMP 2008).
The collection/dismantling/de-polluting/shredding facility shall
take all the steps to :

a) contain contaminants and prevent accidents and limit their
consequences on human beings and the environment; and
b) provide persons working in the site with appropriate training,
equipment and the information necessary to ensure their
safety.
2) Storage : Pre-conditions for storing ELVs

a) ELVs shall not be stored until the fuel, oil, antifreeze, and other
fluids are completely drained, and the fuel tank, radiator, and
other fluid containing parts have been removed. (Ensure that
fluids do not leak or drip onto the ground.)
b) A written record shall be kept of the vehicles stored.
c) In order to prepare vehicles for storage a routine shall be
established; this helps in knowing the condition of every
vehicle stored.
3) An ELV shall not be stored without removing the battery, additional
salient points on storage of ELVs :

i.

ELVs shall be stored in dry areas where there is no water
logging or water will not be flowing under the vehicle during rain
or snow melt periods.

ii.

ELVs shall be stored on impermeable surfaces, such as concrete
or other feasible ground sealing.

iii. Storage areas shall be provided for spillage collection, decanting
and degreasing;
iv. Storage facilities shall be provided for dismantled spare parts,
including impermeable storage for oil contaminated spare parts;
v.

Appropriate containers shall be provided for storage of
batteries (irrespective of whether electrolyte neutralisation is
conducted on site or elsewhere), filters and PCB / PCTcontaining condensers;

vi. Storage tanks shall be provided for the segregated storage of
ELV fluids;
vii. Equipment shall be provided for the treatment of water,
13 | P a g e

<!-- page 16 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

including rainwater in
environmental regulations;

compliance

with

health

and

viii. Used tyres shall be stored appropriately, including the
prevention of fire hazards and excessive stockpiling.
ix. If engines or greasy parts are exposed, they shall be covered
with a tarpaulin or other covering to prevent rain.
x.

ELVs shall not be stored in the flood hazard zone or in wetlands.

xi. ELVs shall not be stored along or over property boundaries,
public rights-of-way, or easements.
xii. Authorization needs to be obtained from the concerned
authorities for the storage of junk vehicles
xiii. The boundaries of the vehicle storage area shall be demarcated
with a site drawing.
xiv. Vandals and other unauthorized persons shall be kept away
from entering the vehicle storage area. If necessary, a fence
shall be erected and "no trespassing" signs shall be posted.
xv. ELVS shall be parked in rows, with enough aisle space between
the rows to allow individual vehicles to be inspected and
removed as needed.
xvi. ELVs shall be stored in an upright position and shall not be
stacked or piled on top of each other.
xvii. An inventory of the ELVs shall be maintained with detailed
record of the make, model, and year of each vehicle, the date the
vehicle arrived. The record shall be maintained on date of
inspection for leaks, and any other relevant information needed
to control the flow of the inventory.
xviii. The storage area shall be inspected regularly to ensure that
there are no problems; a record shall be kept of the inspections.
4) Transportation of ELVs need specialized vehicles with a provision to
lift and load the ELVs. If there are large numbers of ELVs it becomes
economical to have dedicated vehicles for transportation. In case of
small numbers it may be feasible to use public carriers. Large
vehicles and lifts are also required for the onsite movement of ELVs.
5) The sites for ELV treatment and storage shall be designated and need to
be prepared both for storage and treatment. These areas shall be
provided with the following:
14 | P a g e

<!-- page 17 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

a. Impermeable surfaces for designated areas;
b. Spillage collection facilities;
c. Decanters and cleanser degreasers;
d. Equipment for the treatment of water, including rainwater;
e. Designated storage areas for dismantled spare parts;
f. Impermeable storage areas for oil contaminated spare parts.
g. Tanks/containers for segregated storage of fluids - such as
fuel, motor oil, gearbox oil, transmission oil, Hydraulic fluid,
cooling liquids, antifreeze, brake fluids, air conditioning
fluids and other fluids.
h. Equipment and tanks/cylinders for safe de gassing and
storage of gases and safe storage for pyrotechnics from air
bags, ACs etc.
i. Appropriate Areas / containers for storage of solids, batteries,
oil filters Unless crushed, PCB/PCT containing condensers,
other hazardous components used tyres (prevent fire hazard
due to excessive stockpiling)
10.0 Environmentally sound de-pollution of ELVs
1) According to AIS PART-1 para. 4.2.6 any person(s) operating
Collection Centre(s) and Dismantling Centre(s) shall carry out
operations for de-pollution of end-of-life vehicles as mentioned in
Annex A as soon as possible. Further, handling, storage and
transportation of ELVs during the de-pollution activity shall be
as per Section 15 given below.
The processes involved in de-pollution of the vehicle are important
as the ELV is made free from the liquid and hazardous substances
and the further processing becomes safe. De-pollution activities
should be carried out using appropriate equipment that is
specifically designed for carrying out the required de-pollution
operations. Most of it is used in automobile service centres and
workshops and is commercially available. Such equipment is
usually pneumatically operated. The use of such equipment
ensures that a high level of de-pollution (removal, as far as
reasonably practicable, of most fluids contained in the ELV) can be
achieved in a relatively short timeframe (20-30 minutes per ELV). In
case that a de-pollution in a completely mechanized system is not
possible alternative methods of manual operations could be used,
ensuring the same levels of de-pollution without compromising on
health and safety requirements. Since the Indian semi-formal sector
is based in manual operations an assessment of the risks involved
15 | P a g e

<!-- page 18 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

in using such methods of de-pollution must be carried out. Based
on this assessment adequate measures, necessary to comply with
relevant health and safety legislation/ regulation, must be put in
place. If alternative methods are used it should ensure the same
level of de-pollution.

2) The de-pollution or decontamination operations comprise of a
number of steps according to which the ELVs are to be treated
(see figure 2). The steps are based on the materials contained in
the ELV. There are certain minimum standard practices that need
to be followed. Additionally, vehicle specific requirements are
given by automobile manufacturers.

Figure 2: De-pollution process
3) The sequence of the operations is given in the table below where it
is also indicated whether an individual operation is best conducted
from above (A) or below (B) the ELV. The specific sequence of
operations, however, may be evolved as per the requirement of the
ELV and equipment available at the treatment facility. The
objective should be to completely de-pollute / De-contaminate the
ELV before it can be passed on to further treatment, i.e. shredding
and material recovery. At least 20 minutes should be given for
gravity draining of the engine oil.

16 | P a g e

<!-- page 19 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

Table 1: De-pollution sequence
Operation

De-pollution Sequence

A. Before Lifting the vehicle
Remove Battery
Remove fuel filter cap & oil filler
Set heater to maximum
Remove wheels and tyres and separate balance
weights
Remove any parts identified as containing mercury

A
A
A
A
A

B. Lift the vehicle on de-pollution frame or lifting device
Degas air conditioning unit (if fitted)
A
Drain engine oil and remove oil filter for crushing
B
or disposal
Drain transmission oil, including rear differential
B
Drain coolant
B
Drain brake fluid
B
Remove catalyst (if fitted)
B
Drain washer bottle
A
Drain brake/clutch reservoir(s)
A
Drain power steering reservoir (if fitted)
A
Drain fuel tank
B
Drain shock absorbers or remove suspension fluid
B
Replace drain plugs/fit plastic stoppers
B
C. Remove vehicle from de-pollution frame or lifting device
Deploy airbags and other pyrotechnics in-situ (if
A
fitted and able to conduct this operation)
Remove air bags and other pyrotechnics (if fitted,
A
and cannot be deployed in-situ)

For the removal of hazardous substances certain rules have to be complied
with. Some of the basic steps have been given below based on the common
hazardous materials that are likely to be present in all vehicles
4) Hazardous substances (fluids)
Hazardous substances (fluids) such as engine oil, gear oil,
transmission fluid, hydraulic fluid, brake fluid, power steering fluid,
coolant fluid, present automobiles need to be de-contaminated while
processing ELVs as per the norms prescribed in the relevant
regulations and guidelines.
a. Waste oils
i. Used and waste oils shall be sent to registered recycling or re17 | P a g e

<!-- page 20 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

refining unit.
ii. If uncontaminated, these shall be sent for burning for
energy recovery.
b. Transmission oil
i. Transmission oil contained in gearboxes can be gravity drained
through the drain plug. Drilling a hole in the bottom of the
gearbox shall drain those without drain plug.
ii. In rear axle differentials of rear wheel drive vehicles, the drain
plug shall be drilled or differential flange shall be loosened to
allow the oil to drain.
iii. Oil shall be collected in a container and stored and then sent
for disposal.
iv. The power steering fluid has to be extracted from both reservoir
and connecting hose using similar equipment for reservoir and
by piercing the hose and sucking out the fluid or cutting.
v. Transmission oil/fluids shall be managed like used oil by direct
reuse or re- refining in registered recycling units, or by burning
it for energy recovery.
vi. Transmission fluid must not be disposed in a storm drain,
septic tank, on the ground, the sewer system or dumpster.
c. Brake fluids & cleaners
i. Brake fluid is typically contaminated with chlorinated solvents
from brake cleaners.
ii. Brake fluid shall be collected in a separate container marked,
"Hazardous Waste - Brake Fluid".
iii. Brake fluid must not be burned for energy recovery.
iv. Brake fluid must not be disposed of in a storm drain, septic
tank, on the ground, sewer system or dumpster.
v. Brake and carburetor cleaner shall be closed when not in use.
vi. Brake/carburetor cleaners must not be mixed with other
solvents, like solvents from parts washers.
vii.Spent cleaners and solvents shall be disposed of as hazardous
waste.
d. Fuel and fuel filters
i. Fuel shall be removed from fuel tanks by siphoning or suction
as soon as the vehicle enters the facility.
ii. Fuel reusability shall be determined - it shall be labeled
"Reusable Gas (or Fuel)" if reusable; if the fuel is not reusable
it shall be labeled as "Hazardous Waste - Gas (or Fuel)"
iii. All fuel shall be stored in closed, leak proof containers.
iv. Reusable fuel shall be used at the facility or given away.
v. Fuel must not be mixed with any other waste streams.
vi. Excess fuel shall be drained from filters into a proper fuel
container.
vii. Used fuel filters shall be kept in a separate fireproof container
marked "Hazardous Waste Fuel Filters Only". Fuel filters shall
be treated as hazardous waste and disposed of as required.
(Florida Department of Environmental Protection 1999)
18 | P a g e

<!-- page 21 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

e. Coolant (Antifreeze)
Coolant can be gravity drained removing the bottom hose from the
radiator or using suction and a minimum of 10 litres is collected
and reused.
5) Hazardous substances (solids).
a. Lead acid batteries present in the automobiles are one of the major
sources of toxic and hazardous substances. They contain
sulphuric acid that is corrosive and lead plates that are highly
toxic.
i.

Lead-acid Batteries shall be removed and tested for reusability.

ii.

Leaking batteries shall be drained and acid stored in
containers safely.

iii.

Intact or drained batteries shall be stored indoors avoiding
heat and rain.

iv.

Batteries shall be sent for recycling in registered recycling
units.

v.

Battery terminal metal parts sold as scrap for recycling shall
contain acid which causes pollution

b. Air filter contains foam and ferrous parts that pose a potential
hazard if burnt in case it cannot be directly used.
c. Oil filter contains filter paper and residual oil which is toxic when
burnt, it also contains metallic parts which is sold by scrap dealers
d. Hot tank solutions and sludge from cleaning ELVs (and ELV parts)
in auto recycling units could be a major issue as it shall be
contaminated with the process effluents and residues. These need
to be treated as hazardous wastes.
e. Mercury switch shall contain mercury, copper and brass that
makes it attractive to recycle.
f. Brake shoe clutch plates/discs contain asbestos that is
carcinogenic and hazardous to human health. Asbestos are
crushed with the vehicle and are not removed for reuse in
vehicle recycling. If brake shoes and clutches are not removed,
asbestos particles shall become airborne while shredding.
Sometimes these are stripped and dumped on ground. The best
way is to limit exposure and health damage by providing proper
controls to contain brake dust and prevent its release in the air:
i.

19 | P a g e

Brakes or clutches must not be cleaned with air hoses, dry
brushes, wet brushes, rags, garden hose, liquid squirt bottles,
solvent spray or ordinary shop vacuums.

<!-- page 22 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)
ii.

Brake shoes or clutches shall be removed using specially designed
low pressure spray equipment that wets down brake or clutch
dust and properly catches the runoff to help prevent asbestos from
being released.

iii.

It is not recommended to eat in asbestos work areas. It is
recommended to wash hands before eating.

iv.

Before going home clean clothes shall be put on. Asbestos
particles can become embedded in clothing and carried into the
house.

g. Rubber parts are usually sent for recycling in furnaces as they have
the potential to emit toxic fumes.
h. Glass parts, essentially the windshield and other glasses fitted in
the doors, are toughened glass with a PVC sheet pressed between
the two layers of glass. If the glass is intact it can be reused.
Recycling options are limited and it can only be recycled into
construction aggregate. If the PVC is removed, then it can be
recycled like normal glass. If recycling automotive glass is not an
option, it shall be handled as solid waste.
i.

Electronic parts are fitted in modern cars. Such electronic waste
shall be disposed of in accordance with the E Waste Management
Rules, 2016.

j.

Refrigerant gases present in ELVs need to be removed before
processing ELVs as these have the potential to cause adverse effects
on environment and health. The two types of refrigerant that are
used in vehicle air conditioning systems are R12 and R134a. The
type of refrigerant is marked on the vehicle. The refrigerant must be
removed using specialist equipment which allows airtight operations
in order to avoid any gas leakage, and two collection cylinders are
required; one for R12 (a CFC) and one for R134a (an HFC).

k. Airbags contained in most of the modern vehicles contain explosives
and shall be handled in accordance with the handling and
deployment procedure prescribed by the manufacturer.
l.

Catalyst: All modern vehicles contain catalytic converters in the
exhaust for both diesel and petrol vehicles. These catalysts contain
precious and rare metals which are valuable for recycling.

11.0 Environmentally sound dismantling & segregation
1) In the next step, the de -polluted and decontaminated ELVs are
dismantled to separate different parts of the vehicle into their
20 | P a g e

<!-- page 23 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

components so that these could be segregated for further processing.
Dismantling is one of the important steps in the processing of ELVs. The
dismantling process could be manual or mechanical depending upon the
type, size of the vehicle and numbers being handled. Small vehicles can
be easily dismantled and manual dismantling is preferred. The larger
vehicles that are not easy to handle manually can be dismantled using
machines or are subject to mechanical dismantling. Manual dismantling
helps to identify and remove parts that can be reused.
2) Some common components of automobiles during recycling are:
(Automotive Recyclers Association 2014)

i. Engines and transmission systems removed from vehicles can
often be directly reused; they shall be stored under a permanent
roof on an impervious surface, or in an outdoor covered,
weatherproof container.
ii. Engines and transmissions that can be re-manufactured and/or
recycled shall be stored under a permanent roof on an impervious
surface, or in an outdoor covered, weatherproof container or on an
impervious surface that drains to an oil water separator or
equivalent treatment device.
3) In line with AIS PART-1 Para 4.2.8 any person(s) operating Collection
Centre(s) and Dismantling Centre(s) shall not sell the components
mentioned in clause 4.2.8.1 and 4.2.8.2 below to any person(s) for
reuse in the after sales market and shall dispose of in an
environmentally friendly manner.

i. Para 4.2.8.1 In the case of M1 category vehicles: i) all airbags
including cushions, pyrotechnic actuators, electronic control units
and sensors ii) automatic or non- automatic seat belt assemblies,
including webbings, buckles, retractors, pyrotechnic actuators iii)
seats (only in case where safety belt anchorage and / or airbags are
incorporated in the seat) iv) steering lock assemblies acting on the
steering column v) immobilizers, including transponders and
electronic control units vi) emission after treatment systems (e.g.
catalytic converters, particulate filters) vii) keys and lock
components viii) sections of bodywork bearing the vehicle
identification number ix) electronic brake components. AIS-129
4/48
ii. Para 4.2.8.2 In the case of Ll and L2 category vehicles: i) Steering
lock assemblies acting on the steering column ii) Immobilizers,
including transponders and electronic control units iii) Emission
after treatment systems (e.g. catalytic convertor, particulate filters)
iv) Keys and lock components v) Sections of bodywork bearing the
21 | P a g e

<!-- page 24 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

vehicle identification number vi) Engine parts bearing the engine
number vii) Electronic brake components viii) Suspension system ix)
Any item other than those recommended for reuse by the vehicle
manufacturer in the dismantling information.

12.

Environmentally sound
processing of residues

Shredding

and

separation

and

After de-pollution and dismantling of ELV, the remaining structure
of ELV i.e. hulk shall be shredded in the shredder. Such shredding
facility may be installed at the premise where de-pollution and
dismantling activities are carried out or the hulk may be sent to a
common shredding facility. Common shredding facility may
complement numbers of facilities who carry out de-pollution and
dismantling of ELVs. However, hulks may be treated as hazardous
waste, unless it is established that the same do not qualify for
hazardous waste, and, therefore, various provisions of HOWM
Rules, 2016, with regard to storage, transportation, record
maintenance, etc. would be applicable.

1) When an ELV is shredded, the residue is usually separated into
four fractions: ferrous metals (using magnetic separation), nonferrous metals (using mechanical separation), heavy shredder
residue and the light fraction, which is separated by air suction.
Ferrous metals are not being processed further, and arc
considered ready.
2) After dismantling and recovering parts from the ELV, the
remaining part is known as car hulk. This hulk is compressed and
flattened and sent to a shredder for scrap metal recovery. The
shredder essentially pulverizes. the vehicle into fine sized pieces of
materials, which are then sent by conveyors for separation using
magnetic separation, eddy current, laser and infrared systems
(depending on the availability of the systems). Shredding and
separation plants are capital intensive and technically complex.
The metal recovered from these plants becomes raw material
feedstock for steel mills, electric arc furnaces, aluminum and
other nonferrous metal smelters to manufacture a variety of
products, including new vehicles -(Recycle Guide 2014). The
automobile recycling rate is almost 100% and is the most recycled
commodity.
3) Along with ELVs, shredders may also process ether metal rich
scrap, such as construction scrap and waste, large end-of-life
appliances such as white goods. During the shredding process,
the vehicle is broken down into much smaller pieces, and the
metals are extracted. Both ferrous metals - iron and steel - and
22 | P a g e

<!-- page 25 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

non-ferrous metals, such as copper, zinc and aluminum, are
recovered. Ferrous metals make up about 70% of a vehicle, while
non- ferrous metals make up about 6%. These are separated
using magnetic separators. The amount of recyclable material
that is removed from an ELV via shredding is generally
calculated to be about 75% by weight. By far the greatest share
(by weight) of recycled material is the scrap metal.

4) Treatment of automobile shredder residue (ASR): The final
processing of ELV by shredding generates many fractions and a
residue also known as automobile shredder residue (ASR)
containing a variety of materials that could not be recovered by
any of the processes employed. This residue has been a major
concern in many countries and a lot of research has been going
on to assess how this residue could be used. The two fractions
identified in ASR are the light fraction representing 10-24% of
the weight of the original vehicle and the heavy fraction
representing 2-8% of previous vehicle weight. A gross estimate
of ASR generated from ELV recycling in relation to the original
vehicle weight is 15-17%. Initially ASR was being land filled.
Recent findings show that the light fraction of ASR could be
used for energy production while only the heavy fraction needs
to be land filled. In Japan mixed ASR is used for thermal energy
production. Today it is still being debated whether some
amount of ASR needs disposal.
The schematic diagram shown below has been presented in an
international comparative study on ELV recycling systems (Sakai et
al. 2013). It depicts the steps required for a systematic recycling
process but also indicates the percentage recovery rates of
resources at different stages in the ELV recycling process.
The de-pollution removes 3-5% of weight, dismantling 5-35% of
weight, and remaining car hulk is about 60-90% of the previous car
weight. The ferrous metal share after shredding is 35-65% while the
non-ferrous share is 1-5%. Substantial amounts of non-ferrous parts
enter into heavy ASR fraction (2-8%) while the light fraction of ASR is
around 10-24%.

23 | P a g e

<!-- page 26 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

Figure 3: Typical ELV processing

13.0 Technologies for the ELV recycling process
The technologies required in the recycling process of ELVs are
presented below:
a. Technologies for de-pollution, dismantling and segregation
i.

For the lifting of vehicles during the de-pollution process
the recycling facility needs a de-pollution frame or lifting
device.

ii.

Pneumatic tools and electrical screwdrivers are required
for detaching the parts to be recycled from the ELV.

b. Technologies for shredding: Dry/moist shredding: Vehicle hulks are
fed to the shredder/hammer mill with varying amounts of water. In
case of dry shredding, extensive dust is sucked from the shredder by
suction air streams. For moist shredding a small amount of water is
sprayed into the shredder to eliminate airborne dust emissions from
the shredder and from the product transfer points (Gesing 2006).
24 | P a g e

<!-- page 27 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

Most shredders worldwide process ELVs alongside other consumer
products including white goods, light iron and metallic
manufacturing and construction waste (Forton et al. 2005).
c. Technologies for processing residues - Segregation of light ASR
Air classifiers, cyclone separators: After shredding, all material is
injected into a chamber which normally contains a column of rising
air. Light ASR, fluff and dust is lifted up by the air drag and
removed by cyclone separators. There exist various types of
classifiers that can separate particles of different sizes and weight
classes. Air classification can be repeated until material is sorted to
a satisfactory degree (Christensen 2011).
d. Technologies for processing residues - Segregation of ferrous
metal fractions: Magnetic separators: Once light material has
been separated, the remaining residue is transported to magnet
separators / drum magnets for segregation of ferrous metals.
Magnetic separation can be repeated until material is sorted to a
satisfactory degree. This could be beneficial if, for example, small
ferrous particles were covered and held back by other non-ferrous
materials during the first magnetic separation process (Forton et al.
2005).
e. Technologies for processing residues - Segregation of non-ferrous
metal fractions:
i.

Eddy-current separators (ECS): In the next step, non-ferrous
metals (aluminum, copper, zinc, etc.) are separated from nonmetal materials using eddy-current separators (ECS). The ECS is
installed at the end of a conveyer belt and creates a magnetic field
to throw conducting metals forward from the belt into a product
bin, while non-metals simply fall off the belt (Mastermag, n.d.).
Modern ECS can also eliminate small arts of ferrous metals left
from the sorting with magnetic separators (Cogelme, n.d.). The
separation process can be repeated until material is sorted to a
satisfactory degree.

ii.

Heavy media separation / sink-and-float separation: Another
technology for segregation of non-ferrous metals is by heavy media
separation, also called sink-and-float separation. Material is
introduced into a heavy medium mixture of water and very fine
and dense powder). Denser particles will sink, while lighter
particles will float on top of the medium (Encyclopaedia Britannica
Online). Compared to ECS, wet separation methods have the major
disadvantage of having long wait times for settling and drying.
Furthermore, they produce large amounts of waste water (Lee
2012).

25 | P a g e

<!-- page 28 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

f. Other technologies
There exist other technologies for separating metals from specific
non-metal materials. For example, polymers can be removed using
electrostatic separators (Lee 2012).
i.

ii.

Sorting of non-ferrous metal fractions: Sensor-based/manual
color sorting: Non-ferrous metals are then sorted by color.
Sensors based on color recognition can be applied to
differentiate copper and brass (red/yellow particles) from
aluminum/ magnesium (white/grey particles). Color sorting of
different nonferrous metals can also be done by hand
(Margarido et al. 2014).
Sorting of ASR - Air classifiers, cycle separators: Non-metal
residues (glass, fibre, rubber, plastics, dirt, etc) can again be
separated into light and heavy fractions using air classifiers.

g. Technologies for treatment of segregated materials
After the shredding and separation process, there are the ferrous
metal, non-ferrous metal, and light and heavy ASR fraction. The
ferrous and non-ferrous metal fractions are commonly treated in
metal smelters. There are different options for treating the ASR
fractions.
i. Thermal treatment: ASR has a calorific value of 14 - 30
MJ/kg rendering it a valuable energy source. However,
high
chlorine content, brominated flame retardants, ash content and
high heavy metal concentrations make it difficult to actually use it
as fuel (UNIDO et al. 2012). In addition, it has varying moisture
content (Jody et al. 2010). To limit the amount of hazardous
substances released from burning ASR, it may be co- incinerated
in Municipal Solid Waste (MSW) incineration plants not exceeding
a certain share in the fuel (in Switzerland the ASR fraction may
not exceed 5 %, in Sweden up to 20 % were co-incinerated in
MSW incinerators). Testing the flue gas emissions showed that
the flue gas emission composition did not change significantly.
However, concentrations of heavy metals increased in boiler and
fly ash (UNIDO et al. 2012).
ii. Another option is to improve the quality of the ASR. By removing the

finest fraction of the ASR through screens, shaker tables, rotary
drums or float/sink separation techniques the ASR fuel quality can
be improved. Removing PVC from the ASR can lower the chlorine
concentration of ASR. Density separation with a bath density of
1,100 - 1,200 kg/m3 can remove up to two-thirds of chlorinated
plastics from the ASR (UNIDO et al. 2012).

26 | P a g e

<!-- page 29 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)
iii. Although ASR could be used as a fuel for cement kilns, tests using

50 % of ASR as fuel in the kilns had a negative effect on clinker as
the concentrations of heavy metals in the material increased
significantly. In addition, more ash is formed, clogging of the fuel
injection zone happens and increased concentrations of hazardous
elements are found in the kiln dust (UNIDO et al. 2012).

h. Metal recovery: For recovering metals from the recycling process, the
obtained materials can be treated in different smelters. Ferrous metal
junks can be fed into electric arc or blast furnaces (Kumar and
Sutherland, 2008). The different metal fractions can be treated in copper
or integrated smelters. As integrated smelters are high-tech installations
only 5 - 10 smelters fit to adequately and environmentally-sound treat
the ELV fractions exist, among them smelters in Belgium, Canada,
Germany, Japan and Sweden (UNIDO et al. 2012). Light residues from a
car shredder can be treated in secondary aluminum smelters (UNIDO et
al. 2012).
i.

Chemical recycling: There is the option of converting the organic
content of ASR to liquid and gaseous fuels via pyrolysis or gasification
(Jody et al. 2010). Through chemical recycling processes, materials
such as monomers, lighty hydrocarbons, liquid and gaseous fuels
could be extracted from the hydrocarbon- based fraction. The main
sources of such products will be plastics and rubber. Processes that
may be employed for chemical recycling include most prominently
pyrolysis and gasification. Other processes are hydrolysis, selective
dissolution, hydrogenation, and de-polymerization (Jody et al. 2010).
Pyrolysis is the thermal decomposition of organic materials (such as
wood, coal, plastics, tires) to produce fuels and chemicals (Jody et al.
2010). Gasification is a process that converts the organic component of
a material in a gaseous mixture of CO, H2 and CO2 and reduced
metals. Gasification reactors commonly used are moving bed, fluidized
bed and entrained flow reactors (Jody et al. 2010).

j.

Plastics recovery:
Technologies that could be used to separate
plastics from the ASR are heavy media separation, froth flotation,
jigging, cryogenic grinding, use of magnets, air knives and vibrating
tables (Forton et al. 2006). Plastics would have to be separated in
different types to be reused (Forton et al. 2006). As the thermoplastics
content in the plastics fraction in ASR is rather high (70 - 80 %) it can
be recovered, heated and remolded in products such as park benches,
lamp posts, road side furniture, etc. Separation technologies that
could be used for this task include water elutriators and gravity
separators (Jody et al. 2010). Conventional MSW recycling separators
could be adjusted for the application to ASR (Jody et al. 2010).

27 | P a g e

<!-- page 30 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

k.

Incorporation into other materials: ASR can also be recycled or stored
by including it in composite, concrete or asphalt (UNIDO et al. 2012).

l.

Land-filling: Land-filling of the ASR is still the most common treatment
approach for this fraction as the other technologies described above are
either too expensive or have significant negative environmental impacts.

14.0 Requirements for setting up of ELV recycling facility
1. The establishment of an ELV recycling facility to be based on the
guidelines published, best practices adopted and regulatory
requirements in India for establishing and operating "Recycling and
Disposal Facilities". Such facilities shall only be set up by the formal,
formalized or organized sector. The activities presently taking place
in the semi-formal sector need to be integrated. They shall provide a
support and channelization system for the integrated facilities that
are to be established. With th e increasing vehicular
population a suitable infrastructure for large scale operations is
needed to deal with a large number of vehicles. This would facilitate
semi-formal sector into the main stream of the ELV management
activities and ensure environmental compliance. The proposed
mechanism for the ELV recycling facility is only an illustrative model
and may need upgradation as we progress.

2. E L V Facility and operation requirements: In order to
provide an infrastructure for recycling ELVs there is a need to
identify large areas of land where adequate space is available for
storage, handling, and recycling of ELVs. ELVs requiring treatment
range from small two wheelers to large trucks and trailers. It may be
possible to have different facilities for different types of vehicles
but one major facility in every region catering to a number of
States would be advantageous. However, the interstate
movement would need to be streamlined.
3. Procedures for Setting up & Management of ELV recycling
facilities
Steps required for setting up ELV recycling facility are the
following:

i.

A license shall be obtained to set up the ELV recycling
industry from the appropriate authorities.
ii. Land shall be produced in an industrial estate/area to set up the
facility. Requisite layout and design approvals shall be obtained
from the concerned SPCB/PCC.
iii. In accordance with AIS PART-1 para. 4.2.4 any person(s) operating
28 | P a g e

<!-- page 31 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

Collection Centre(s) and Dismantling Centre(s) shall fulfill the
minimum requirements in accordance with Annex A.
iv. Environmental Clearances (EC), wherever applicable, shall
be obtained based on the scale of operations as prescribed
in the Environmental Clearance notification dated 14
September 2006.
v. An Environmental Management Plan (EMP) shall be prepared
and put in place.
vi. Facility shall obtain consents under the Water Pollution
(Control & Prevention) Act, 1974 and Air Pollution (Control
& Prevention) Act, 1981 from the concerned SPCB/PCC.
vii. Facility shall have authorization under HOWM Rules, 2016, from
the concerned SPCB/PCC for handling, storage, packaging,
transportation of hazardous to authorized recyclers and treatment
and disposal facility operators. The facility shall have membership
or agreement with authorized recyclers and treatment and disposal
facility operators. Further, authorization under Solid Waste
Management Rules, 2016 and Plastic Waste Management Rules,
2016 shall also be obtained for management of solid waste and
plastic
waste
generated
during
de-pollution/dismantling
/shredding activity.
viii. Requisite methodologies shall be planned for acceptance of
ELVs and distribution of destruction certificates (at the end of
destruction of ELVs) among the stakeholders in accordance with
guidelines or policy prescribed by the concerned Transport
Department.
ix. Facility shall have a written plan describing the facility's risk
management objectives for environmental performance and
compliance and its plans for attaining these objectives based on a
"plan-do-check-act" continual improvement model.
x. Regular evaluation of Environment, Health and Safety (EH&S)
objectives and monitoring of progress toward achievement of these
objectives shall be conducted and documented in the facility.
xi. Facilities shall take sufficient measures to safeguard occupational
and environmental health and safety. Such measures may be
indicated by local, state, national and international regulations
agreements, principles and standards, as well as by industry
standards and guidelines.
xii. The guidelines of CPCB for storage and transportation of
hazardous waste shall also be compiled with.
xiii. Training & Capacity Building for employees at different levels.
xiv.Environment, Health & Safety (E H & S)

a. An up-to-date, written hazardous materials identification and
management plan to address the specific hazardous materials
29 | P a g e

<!-- page 32 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

that would be handled.

b. Where materials are shredded or heated, appropriate
measures to protect workers, the general public and the
environment from hazardous dusts and emissions.
c. An up-to-date, written plan for reporting and responding to
exceptional pollutant releases, including emergencies such as
accidents, spills, fires, and explosions.
d. Liability insurance for pollutant releases, accidents and other
emergencies.
e. Completion of an EH&S audit, preferably by a recognized
independent auditor, on an annual basis.
xv. Facility to have a regularly implemented and documented
monitoring and recordkeeping program that tracks key process
parameters, compliance with relevant safety procedures, effluents
and emissions, and incoming, stored and outgoing materials and
wastes.
xvi. Facility to have an adequate plan for closure and shall be updated
periodically and financial guarantees shall ensure that the
necessary measures are undertaken upon definite cessation of
activities to prevent any environmental damage and return the site
of operation to a satisfactory state, as required by the applicable
laws and regulations.
xvii. Finally, as laid out in AIS PART-1 para. 4.2.12 any person(s)
operating Collection Centre(s) and Dismantling Centre(s) may
accredit their centers/units as per ISO 14001 (Environmental
Management System)

4. Registration and authorization of Recyclers processing ELVs
Basic requirements to be eligible for recycling ELVs are as follows:

a. The ELV recyclers and their facilities shall have authorization from
the respective State Pollution Control Board
b. In Accordance with AIS PART-1 para. 4.2.1 any person(s)
operating Collection Centre(s) and Dismantling Centre(s)
shall obtain an authorization in accordance with the
procedures prescribed in AIS PART-1 para. 5 "Procedure for
authorization by Government certifying agency" from the
concerned Government Certifying Agency (see Annex B) or as per
procedures prescribed by the concerned Govt. agency.
c. Only registered and authorized recyclers shall be allowed to recycle.
30 | P a g e

<!-- page 33 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

ELVs Recycling shall be carried out using environmentally sound
technologies and as per this document, 'Guidelines for
Environmentally Sound Facilities for Handling, Processing and
Recycling of End-of- Life Vehicles (ELV)”.

15.0 Management of various wastes generated during de-pollution,
dismantling and shredding of ELVs
Besides obtaining useful scraps which can be channelized for reuse or
recycling; de-pollution, dismantling and shredding of ELVs will
generate light and heavy fractions ASR and several categories of
wastes such as hazardous wastes, E-wastes, Solid wastes and plastic
wastes which requires to be managed in an environmentally sound
manner in compliance with provisions stipulated under Hazardous
and Other Wastes (Management and Transboundary Movement) Rules,
2016; E-Waste Management Rules, 2016; Solid Waste Management
Rules, 2016 and Plastic Waste Management Rules, 2016, respectively.
The light ASR and heavy fractions ASR may be considered as
hazardous wastes and in case authorized resource/energy recovery
facilities are not available, the same shall be disposed in authorized
common hazardous waste treatment, storage and disposal facility
(TSDF) where the same may be imparted incineration or secured
landfilling depending upon characteristics of the ASR.

(a) Management of Hazardous Wastes
Various
hazardous
waste
generated
during
depollution/dismantling/shredding of ELVs such as Used Oil, Waste Oil,
Transmission oil, brake fluid, coolant fluid, lead acid batteries, brake
shoe, clutch plates, ASR, etc. requires to be managed in accordance
with provisions stipulated under the Hazardous and other Wastes
(Management and Transboundary Movement) Rules, 2016.
i.

Application made to SPCB/PCC for grant of authorization for handling,
generation, collection, storage, transportation, packaging, offering for
sale, transfer, disposal, etc. under Rule 6 of the said Rules shall
clearly mention categories of hazardous waste, their quantity, method
of recycling/recovery/disposal, etc. which shall be carefully be
examined by the SPCB/PCC. Upon assessment of the same and
verification during inspection by SPCB/PCC, authorization for
management of hazardous waste may be granted by SPCB/PCC
stipulating categories of hazardous waste, their quantity, method of
recycling/recovery/disposal, etc. and other conditions as prescribed
under Form 2 of the said Rules.

31 | P a g e

<!-- page 34 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

ii.

The storage period of hazardous wastes shall be in accordance with
the Rule 8 of the Hazardous & Other wastes (Management and
Transboundary Movement) Rules 2016.

iii.

The wastes generated during the de-pollution/dismantling/shredding
activity shall be stored under a dedicated covered storage shed.

iv.

Proper slope with collection pits be provided in the storage area so as
to collect the spills/leakages.

v.

The de-polluting/dismantling/shredding facility shall ensure that
wastes are packaged in a manner suitable for safe handling, storage
and transportation. The labelling on packaging shall be readily visible
and material used for packaging shall withstand physical and climatic
conditions.

vi.

Labelling of the hazardous waste container shall be in accordance with
the provisions laid down under the HOWM Rules, 2016 and shall
include the information with regard to waste type, the origin (name,
address, telephone number of sender), hazardous property (e.g.
flammable), and the symbol for the hazardous property (e.g. the red
square with flame symbol).

vii.

Drums containing wastes stored in the storage area should be labeled
properly indicating mainly type, quantity, characteristics, source and
date of storing etc.

viii.

The collection center/de-polluting/dismantling/shredding facility shall
ensure that the wastes generated during dismantling be sent or sold to
an authorised collection center/ recycler/utilizer or authorised
disposal facility, as case may be.

ix.

The de-polluting/ dismantling/shredding facility shall maintain a
record of wastes managed by him as per the format given in Form 3 of
the said Rules and prepare and submit to the State Pollution Control
Board, an annual return containing the details specified in Form 4 on
or before the 30th day of June following the financial year to which
that return relates in accordance with the said Rules.

x.

Handing over of the hazardous waste to the authorised actual user
shall be only after making the entry into the passbook of the
authorised recycler/utiliser. Further, such authorised recycler/utiliser
shall also maintain records of wastes purchased in a passbook issued
by the State Pollution Control Board/Pollution Control Committee
along with the authorization.

32 | P a g e

<!-- page 35 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

xi.

The transport of hazardous waste containers shall be in accordance
with the provisions of the Hazardous and Other Wastes (Management
and Transboundary Movement) Rules, 2016 and the rules made by the
Central Government under the Motor Vehicle Act, 1988 and other
guidelines issued from time to time.

xii.

Manifest System shall be followed for movement of wastes. The flow of
manifest document (which contains details of waste description &
quantity, senders, transporters, receivers, acknowledgements by
transporters and senders, etc.) as prescribed under the Hazardous and
Other Wastes (Management and Transboundary Movement) Rules,
2016, are as below:
Purpose
Copy number
colour code
(1)
Copy 1 (White)
Copy 2 (Yellow)

Copy 3 (Pink)

Copy 4 (Orange)
Copy 5 (Green)
Copy 6 (Blue)
Copy 7 (Grey)

with
(2)
To be forwarded by the sender to the State
Pollution Control Board after signing all the
seven copies.
To be retained by the sender after taking
signature on it from the transporter and the
rest of the five signed copies to be carried by
the transporter.
To be retained by the receiver (actual user
or treatment storage and disposal facility
operator) after receiving the waste and the
remaining four copies are to be duly signed
by the receiver.
To be handed over to the transporter by the
receiver after accepting waste.
To be sent by the receiver to the State
Pollution Control Board.
To be sent by the receiver to the sender.
To be sent by the receiver to the State
Pollution Control Board of the sender in
case the sender is in another State.

(b) Management of Ozone depleting substances
The refrigerant gases used in vehicle air conditioning systems may
contain ozone depleting substances and may require to be regulated as
per Ozone Depleting Substances (Regulation and Control Rules), 2000,
or other policies/directions issued by Central Govt. from time to time.
The collected refrigerant gases shall be channelized for recovery/reuse
33 | P a g e

<!-- page 36 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

to such registered recovery/reuse facility, as applicable. In case such
recovery/reuse is not feasible or available, the same shall be destroyed
in destruction facility recognized by Central Government or the
appropriate authority, as applicable.
(c)

Management of E-Wastes
Air conditioners, display unit, circuit board, music system, etc., which
are not in usable condition, shall be treated as E-waste during depollution/dismantling/shredding of ELVs. Such E-wastes shall be
channelized to dismantlers/recyclers authorized under the E-Waste
Management Rules, 2016. Records of such E-wastes generation and
storage
shall
be
maintained
along
with
authorized
dismantlers/recyclers to whom the same have been channelized.
Manifest system for transportation of such E-wastes as prescribed
under the said Rules shall be followed. Further, Annual Returns be
submitted to the concerned SPCB/PCC by 30th June following the
financial year to which that return relates, as stipulated under the
said Rules.

(d)

Management of Plastic Wastes
The
plastic
waste
generated
during
depollution/dismantling/shredding of ELVs shall be channelized to
registered recyclers authorized under the Plastic Waste Management
Rules, 2016. Records of such plastic waste generation and storage
shall be maintained along with registered recyclers to whom the same
have been channelized. Further, Annual Returns be submitted to
the concerned SPCB/PCC by 30th April of every year, as stipulated
under the said Rules.

(e)

Management of Solid Wastes
The solid wastes, which are not hazardous, shall be segregated, stored
and the segregated waste be handover to authorized waste pickers or
waste collectors in accordance with Solid Waste Management Rules,
2016. Records of such solid waste generation and storage shall be
maintained along with authorised waste pickers to whom the same
have been channelized. Further, Annual Returns be submitted to the
concerned SPCB/PCC by 30th April of every year, as stipulated under
the said Rules.

34 | P a g e

<!-- page 37 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

AIS-129

ANNEX-A
MINIMUM TECHNICAL REQUIREMENTS FOR COLLECTION AND DISMANTLING
CENTRE
A.1

Sites for storage (including temporary storage) of End-of-Life Vehicles prior to
their dismantling
The Collection and Dismantling Centers shall have:

A.1.1

impermeable surfaces like concrete flooring, etc for appropriate areas (including areas
where vehicles are stored prior to de-pollution as necessary) with the provision of spillage
collection facilities, decanters and cleanser-degreasers.

A.2

Sites for dismantling
The Collection and Dismantling centers shall have:

A.2.1

impermeable surfaces like concrete, etc for appropriate areas with the provision of
spillage collection facilities, decanters and cleanser-degreasers,

A.2.2

appropriate storage for dismantled spare parts, including impermeable storage for oilcontaminated spare parts,

A.2.3

appropriate containers for storage of batteries (with electrolyte neutralization on
site or elsewhere), and filters/ PCB/PCT-containing condensers (if applicable),

A.2.4

appropriate storage tanks for the segregated storage of End -of-Life Vehicle fluids: fuel,
motor oil, gearbox oil, transmission oil, hydraulic oil, cooling liquids, antifreeze, brake fluids,
air-conditioning system fluids and any other fluid contained in the End-of-Life Vehicle,

A.2.5

appropriate storage for used tyres, including the prevention of fire hazards and excessive
stockpiling.

A.3

Dismantling operations for de-pollution of End-of-Life Vehicles:
The Collection and Dismantling centers shall possess the equipments and facilities
required for:

A.3.1

removal of batteries,

A.3.2

removal of liquefied gas tanks,

A.3.3

neutralization of potential explosive components, (e.g. air bags),

A.3.4

removal and separate collection and storage of fuel, motor oil, transmission oil,
gearbox oil, hydraulic oil, cooling liquids, antifreeze, brake fluids, air -conditioning
system fluids and any other fluid contained in the end-of-life vehicle, unless they are
necessary for the re-use of the parts concerned,

35 | P a g e

<!-- page 38 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)
AIS-129
A.3.5

removal, as far as feasible, of all components identified as containing heavy metals as
identified in Annex A of AIS-129 : Part - 2 A.

A.4

Dismantling operations in order to promote recycling:
The Collection and Dismantling Centers shall possess the equipments and facilities
required for:

A.4.1

removal of catalysts, to facilitate further extraction of noble metals by recyclers.

A.4.2

removal of metal comp onents containing copp er, aluminum and magnesium in
such a way that they can be effectively recycled as materials, if the End -of-Life Vehicle is
not going to be treated in a shredder.

A.4.3

removal of tyres and large plastic components (bumpers, dashboard, fluid containers,
etc) in such a way that they can be effectively recycled as materials.
Note: removal of large plastic components is recommended only if they can be
dismantled and recycled in an economical and profitable manner.

A.4.4

removal of glass in such a way that it can be effectively recycled as materials.
Note: removal of glass is recommended only if the glass can be dismantled and
recycled in an economical and profitable manner.

A.5

Storage operations shall be carried out to avoid damage to components containing
fluids or to recoverable components and reusable parts.

A.6

Recommended Tools & Equipment for Pre -treatments (Draining and Dismantling):
Shredder/ Bailing press for compacting / any suitable device
AC gas Recovery unit
Vehicle Lift
Auto Shear machine for cutting catalytic converter
Air Bag Deployment unit
Filter wrench/ Oil Filter Removal Tool
Wheel Popper
Piercing equipment for damper oil
Suction equipment for fluid
Bleeding system for brake fluid
Dedicated fluid collection container
Hydraulic tube cutter
Pneumatic saw
Portable power tool
Draining Tray
Pry bar/Spanner/Ratchet/ Mallet
Screw driver/Slot screwdriver/ Impact screwdriver

36 | P a g e

<!-- page 39 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)
Cutter/cutting pliers/ Special Plier
Center Punch & bag (for glass breakage & collection)
Windshield removal tool
Pneumatic air gun Water supply

37 | P a g e

<!-- page 40 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

AIS-129

ANNEX-B
FORM —1
(See clause 5.1)
APPLICATION FOR OBTAINING AUTHORIZATION FOR
COLLECTION AND DISMANTLING OF END-OF-LIFE VEHICLE

From:
To
The Government Certifying Agency
…………………………………………..
……………………………………………

Sir,
I/We hereby apply for authorization/renewal of authorization under CMVR, Rules 1989 for
collection and dismantling of End-of-Life Vehicle.
To be filled in by Applicant
1. (a) Name and full address, telephone nos. e-mail and other contact details of the unit :
(b) In case of renewal of authorization previous authorization no. and date
2. (a) Total capital invested on the project :
(b) Year of commencement:
(c) Date of grant of the Consent to Establish:
(d) Date of grant of the Consent to Operate:
(e) Mode of storage within the plant:
(f) Method of dismantling and disposal:
(g) Installed capacity of the plant:

38 | P a g e

<!-- page 41 -->

Guidelines for Environmentally Sound Facilities for Handling, Processing and Recycling of
End-of- Life Vehicles (ELV)

3. Detailed proposal of the facility (to be attached) to include:
(i)

Location of site (provide map)…………

(ii)

Details of processing technology…………

(iii)

Quantity of waste to be processed per day …………

(iv)

Site clearance (from local authority, if any)………………..

(v)

Method of disposal of residues (details to be given)…………..

(vi)

Quantity of ELV to be processed or disposed per day………..

( v i i ) Methodology and operational details…………….
(viii) Measures to be taken for prevention and control of environmental
pollution including dismantling of leachates .........................................
(ix) Investment on Project and expected returns……….
(x) Measures taken for safety of workers working in the plant……….

Place: ___________ Signature ______________
(Name __________________ )
Date: __________
Designation: ___________

39 | P a g e
