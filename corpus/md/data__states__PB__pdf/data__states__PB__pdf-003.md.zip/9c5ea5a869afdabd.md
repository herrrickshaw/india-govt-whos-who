---
doc_id: "9c5ea5a869afdabd"
source_url: "https://pbsports.punjab.gov.in/pdf/tender-regarding-purchase-of-sports-equipments-for-the-fy-2024-25.pdf"
ministry: "Department of Sports, Punjab"
title: "Tender regarding Purchase of Sports Equipments for the FY 2024-25"
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "dc51c64be5febb0f"
---

<!-- no text layer: pending OCR -->
