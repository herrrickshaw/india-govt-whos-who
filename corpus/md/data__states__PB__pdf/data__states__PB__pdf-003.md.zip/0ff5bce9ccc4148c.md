---
doc_id: "0ff5bce9ccc4148c"
source_url: "http://gmada.gov.in/sites/default/files/Pre%20Bid.pdf"
ministry: "Greater Mohali Area Development Authority (GMADA), Mohali, Punjab"
title: "Reply of Prebid Queries of Tender for Digitization Georeferencing Superimposition of Layout Plans Revenue based Plans Etc and development of GIS System for properties falling under the jurisdiction of PUDA and all other authorities."
date: ""
pages: 9
method: "tesseract:pan+eng"
script: "LATIN"
needs_ocr: false
sha1: "96e90a8d4475dc29"
---

<!-- page 1 -->

| |
i RFP Page Amendment
1 Clause ਸਿ RFP Clause Detail Sought/Suggestion
No
Bidder should have completed
5.1.2 Similar work in i Request you to consider As per RFP
1 Point Government/Large private : similar work at 1 location
No3 organization at 3 Locations in
i last five years
| Bidder should have completed ੪
\ Siz Similar work in Government/ Request you to consider As per REP
| Polnt Large private organization at 3 | ongoing projects also
noe Locations in last five years
Request you to clarify
। whether the cost will be Rates quoted in
Hi with taxes or without taxes BOQ are inclusive
3 5.1 13 Financial Bid Evaluation Format because Section 5.10 says pase
with taxes and BOQ says
without taxes
Any GIS Application will
need a WMS or WFS
service to create the
application. The Service can
be created using open
source software like
GeoServer etc. Request you
Section to clarify that COTS based
7 Scope ane GIS web based software ARC GIS server
Development and customization a
of work 21 of web based GIS software will be needed or the licenses shall be
Point application will be borne by PUDA
7.1 (B) developed on open source
software only. If you
already have any web
based GIS software then let
us know in advance. Do
you have ArcGIS Server or
Apollo Server licenses with
j you in your department
i Request you to clarify
a Section regarding the RDBMS :
ਨੂ 7 Scope Software. Do you have any Presently Oracle is
ਲੂ 5 of work 21 Development and customization RDBMS software or it will used. But bidder is
= Point of web based GIS software be supplied by the Vendor? free to use open
: 7.1 (B) Do we need to develop the | Source software
application on an open like Postgree etc.
source RDBMS Software
Request you to Provide the
details Of use cases or
applications which need to
secon ਜੰਗੀਰ for the PUDA | Citizen portal,
co} n i
of Rea Customized Geospatial Instance | We also re i ita ਦਿ
ਦੇ for PUDA users aquest you to Portal is for users
Point Provide the information to update
7.1 (XVI) rae the integration touch | information in
p ਜਿ Sor no Of application | software
which will be integrated
[ with the developed web
based Gis, application,
ਤਮ”
_—E——————————— ਜੱ ੰ ਤੱ ੧੧੧੧

<!-- page 2 -->

y Section
ਉਰ ਰਾ Customized Geospatial Instance
ਵਿ of work nol | for Citizen users As per bid
Point aa document
7.1 (XVI)
Property
F Management
Section ਹੂ Module, e-clu
7Scope | Point Integration of portals with GIS portal, e-licensing,
ofwork | nod | ੪੦੦੪ web application unauthorized
she 7 colonies portal,
ਹੂ 08025 and etc,
We would, therefore
request PUDA to please
delete/amend the EMD/Bid
Earnest Money Deposit (EMD) Security provision as
2 5 through online mode: Rs. mentioned in the Tender As per RFP
2,00,0001- (Rs. Two lacs Only) documents and exempt us
from submission of the
EMD / Bid Security against
the Tender/RFQ.
We would, therefore
5.13 15 | Performance security ਵਿ de As per RFP
clause as: |
The Successful bidder shall
furnish PBG to PUDA
11 valuing@ 3% of the value As per RFP
of the concerned contract
| as performance security.
Carrying out door to door
household survey of properties
and linking of Data with GIS Maps
t along with Geo Tagging of
| Photos, Map Updating, Utility F : between 3 toS
। Mapping (Roads, Water, Sewer, Kindly provide the number photographs. Final
i 322 (7.1 23. | Electric Poles, Landmarks etc.), of photographs to be geo figure shall be
' Geo-referencing, Base Map tagged for each property. conveyed to
। Creation, super-imposition of successful bidder.
Layout Plans and integration of
Revenue based Plans/Master
Plans €੧੦., integration of already
existing portal.
ie
|
foot (ਮਰਨ
ਵਿ ਜਿ ਜਿ

<!-- page 3 -->

ਨੇ
7
Carrying out door to door
household survey of properties The live software
and linking of Data with GIS Maps module of the
along with Geo Tagging of drawing Is always
Photos, Map Updating, Utility of 1:1 scale.
Mapping (Roads, Water, Sewer, _| Kindly provide the Scale on However, the
13 |7;1 21 | Electric Poles, Landmarks ete.), which Base Map Is to be scale for final
Gee-referencing, Base Map prepared. output will
Creation, super-imposition of depend on area of
Layout Plans and Integration of the
Revenue based Plans/Master map/drawings.
Plans ੧੧੮, integration of already
existing portal.
ਤਤ
7੧੦0੬ b. Development & customization
“4 ae 21 | as per requirement of client. Web ਆਬ ਸਿਵ same as 51. 9
2 based GIS application shall
Introduc Scope?
tlon provide at least following
features but not limited -
Satellite imagery
a, Carrying out door to door shall be procured
household survey of properties by PUDA. In case
and linking of Data with GIS Maps bidder purchase
7.Scope along with Geo Tagging of on behalf of PUDA
Photos, Map Updating, Utility '
of Is required satellite payment shall be
Work, Mapping (Roads, Water, Sewer, imagery/imagery at made to bidder on
15 71 i 21 | Electric Poles, Landmarks etc,), lution i (੪੩ basig |
. Geo-referencing, Base Map appropriate resolution is actual ਜਾ In
Introduc Creati 7 being provided by PUDA? _ | case of bidder
tion reation, super-imposition of purchase the
Layout Plans and integration of ਸੰ
Revenue based Plans/Master lll Ta ਜਾਨਾ
Plans etc., integration of already of image must be
existing portal. in the name of the
client
7.Scope
of Some of base map services
Work are paid services, Is PUDA
16 71 7 xii, Base-maps would separately procure | Same assn.15
Introduc subscription licenses for
tion the same.
The administrators should have
the facility to configure Bhuvan,
= ਨਿਆਂ If, the Sena for the PUDA seeks
ਸਜ ਸਿਤ ie pate for minimum 10 years
then use this data as base-maps ae of cubsenption
In the application
sp"
bon 6 NADA
ਲਿਗ ਨਸਲ ਕਸ TS ਅਗਮ ਕਲਿਕ ਜਲਦ ਲਗ ਲਲਿਕਗਜਿਜ ਕਾਲ ਦਲ ਰਲ ਰਾ ਜੀ Sane ਲਗ ਸਰਲ ਜਦ ਸਕਲ

<!-- page 4 -->

pes
J Development of Web
y 7.Scope Based GIS Requires GIS Source code for
of Server based software to Web base solution
Work xvi, Customized Functional be deployed on the ੪ mobile
। 18 71 ਨ 25 | Requirements for GUI. IPR of the | servers. We understand application, web
। introduc software shall lie with PUDA. that source code of any services or any.
standard product license other application
wu supplied for GIS server to developed
be provided - Please clarify
Does the ‘point p and q'
7.Scope means server hardware
of - and software required for
19 wore ria i Customized ਜਾ testing the software is in As per RFP
med, Requirements for GUI the scope of vendor and
Introduc need to be deployed at '
noe PUDA Bhawan?
p. Service provider shall use its
own staging environment
(Software & Hardware whichever
is required) for |
development/testing of software,
creation of base map, GEO ਸੂ Please clarify. As per RFP
tagging mapping of data, testing
etc. at its own cost. After
validation & verification of
data/software service provider
will shift the data from staging
environment to live environment
q. Staging environment should be
created in PUDA Bhawan by the
21 service provider. Without client's As per RFP
permission it should not be
shifted from PUDA Bhawan.
As per Govt of India Office
Memorandum No.
F/9/4/2020-PPD dated
12th Nov 2020,
Performance Security
reduced from 5-10% to 3%
of the value of contract.
22 «| 5.13 15 | Performance Security We requést you ta revise As per RFP
Performance Security
clause suitably.We request
you to suitably revise the
Performance Security
clause of the RFP
Document.
As per Govt of India Office
5.2 Memorandum No.
Earnest F/9/4/2020-PPD dated
23 Money 10 Earnest Money Deposit (Rs. 12th Nov 2020, no
Deposit 2,00,000) Provisions regarding Bid As per RFP
(EMD) Security should be kept in
the Bid documents in
6 future and only provision
ay
Lon, (ਉਨ
ee

<!-- page 5 -->

y for Bid Security Declaration
should be kept in the Bid
Documents. We request
you to review and revise
the Tender conditions.Also
as per Ministry of Micro
Small & Medium
Enterprises, New Delhi vide
Gazette Notification dated
23.03.2012 MSME/ NSIC
registered companies are
exempted from purchasing
Tender document and
submission of EMD. We
request for revision of
Tender Fee and EMD
criteria as per above
circulars
vi
pocume Cost of Tender Document and As per RFP
Control Mode of payment
Shet
We believe that Execution
time of ED+4 weeks is too
short for Development/
Testing/ Implementation/
Customization of Web
based GIS Application and On the request of
Mobile Application & bidders ED+8
integrate it with existing weeks for
applications.We need Development/
atleast 8-12 weeks for testing/
9. Design & Development of implementation/
Paymen Execution time Web based 615 Application customization of
tTerms and Mobile Application as Web based GIS
per PUDA requirements, Application and
we request to provide us Mobile
atleast 12 weeks for Application &
completion of integrate it with
Development/ Testing/ existing
Implementation/ applications
Customization of Web
based GIS Application and
Mobile Application &
integrate it with existing
applications.
Fe Kind i |
Instructi The bidder should have ade
ons to successfully completed “Similar | should have successfull
bidders Work” in government/ large completed “Similar W ਨ
5.1 (3) Page | private organizations which in government i
Eligibilit | No.8 | involved providing “Similar organisations which As per RFP
y/ Pre- Work” at more than 3 locations involved providing “Simi!
| Qualific during the last 5 years ending Work” at more tee “onl
\\ saa 31.03.2020 locations during the last 10
years ending 31.03.2020.
LAY
$ \\
ਹਾਂ, Gwar

<!-- page 6 -->

Instruct Kindly consider the
F ons to Bidder should have minimum following: Bidder should
4 bidders annual average turnover of Rs.25 | Nave minimum annual
7 5.1 (4) Page | lakhs from similar work only in average turnover of Rs.25 As per RFP
[ 27 | etigibilit | No.9 | the last 3 financial years for lakhs from (ਨ
y/ Pre- which bidder’s accounts has been ਗੀ nes ae which
Qualific audited. bidder’s accounts has been
Seen audited.
Criteria
Kindly clarify on Scope of
aeons ; application and what all
of Work Development of Mobile , features need to be ਦੀ peeSns
28 7A Page Application or departmental integrated along with it. Be
Introduc | No.24 | users and citizens as per Kindly also increase the
tion requirement of the client time for this stage to
Point c. minimum 4 months
1. Kindly clarify whether
you need a specific
technology (JAVA, -NET,
SAP etc.) for portal
7.Scope development.2. Kindly It is clarifies that
of Work specify the level of proper integration
7A Page | Integration of portals with the integration required is required. No
Introduc | No.24 | GIS based Web Application whether only links need to hyperlinks are
sion be provided or re-coding | allowed.
Pointd the entire old system with
new.3. Kindly specify the in
which platforms earlier
portals were developed.
Development/ Implementation of
ae Web based GIS Application, So, we request you to
ae Page | Mobile Application & Integration | kindly reconsider the
s Point No.27 | of the same with existing penalty clauses and time of
4 applications. Within 4 weeks project stages.
fi Penalty Rs.50 per day
As per RFP
Service providers will carry out
ਵਿ door to door survey and linkin, We j
31 | and Page | 4001 Gis Minimum 350 acres in ਜਿ
Penaltie | No.27 ina | remove penalty clause for | As per RFP
5 Point 5 week Penalty of 20% of quoted the same.
amount per acre
8. SLA
and Page Availability of application 99.95%
Penaltie | (੧ 97 | availability Will attract penalty of We request you to kindly
s °-27 | ੧6.500 per hour of downtime remove penalty clause. As per RFP
Point 6.
alle
Bor (9962

<!-- page 7 -->

Kindly consider following
4 payment schedule
S.No, Activity
% of payment
1 Inception report
and concept development
20%
91 Development/ Implementation of | 2 Development of
General Page Web based GIS Application, portal Is an activity itself
33 | 9.1.1, ace Mobile Application & Integration | 20% As per RFP
Point "| of the same with existing 3 Development of |
no.A applications.Payment Milestone | mobile app is another
20%
4 Servers and hosting
are third main activity
20%5 Maintenance and
fixation bugs &
Implementation in
different Authorities 20%
ਤਿਨ
Kindly also consider: In
case of any delay in
: roviding data and ਭਰ
Miscella Delay in approval / providing (ਗਨ from It is ensured that
neous data from client side client side, no penalty data should be
: rovided to
should be imposed on pre rs
ਰੰ service provider
service provider. within time.
Through this tender, PUDA
invites proposals from interested
bidders (Service Providers for
carrying out door to door As defined in the
household survey of properties REP all the
and linking of data with GIS maps properties data to
along with Geo Tagging of be captured.
Photos, Map updating, Utility Please confirm the data to | Tentative 15-20
4.1.2 7 _ | Mapping (Roads, Water, Sewer, | 0੪ collected during the | fields shall be
Electric Poles, Landmarks etc.) door-to-door survey. captured during
Geo-referencing, Base Map house hold
Creation, super-imposition of survey. Exact
Layout Plans and integration of fields shall be with
Revenue based Plans/ Master successful bidder
Plans etc.) to carry out the work i
for a period of one year & further
provides maintenance for a
period of three years.
B. Carrying out door to door
household survey (Ground
truthing) of properties and
linking of Data with GIS Maps At present PUDA
along with Geo Tagging of Pl has property
Photos, Map Updating, Utility lease confirm the ਰਹ management
Mapping (Roads, Water, Sewer, ਸਜ of data in digital | Module, Licensing
Electric Poles, Landmarks etc.), atabase format with Colony module, e-
Geo-referencing, Base Map PUDA, clu module,
Creation, super-imposition of Building Plan
Layout Plans and integration of approval module
Revenue based Plans/ Master
Plans etc.) to carry out the work,
ante
ly, (੨੧25

<!-- page 8 -->

The bidder should certify that Abidder will |
j ie have not offered lesser price provide |
37 | 5.10.1 14 or any of the line items to any An undertaking should be undertaking, In |
a Bovernment/ semi-government | submitted by bidder as a case of false
organization of Centre of any proof to PUDA undertaking EMD |
] State (of same specification as in /oank Guarantee | |
7 the tender) of bidder will be
4 forfeited.
0. Development & Customization | Please confirm on which
of Web based GIS application for | platform the Web based
departmental users and citizen as | GIS application to be
7A 21 | per requirement of client. Web developed for PUDA, The ie aly
based GIS application shall COTS software will be
provide at least following provided by PUDA for
features but not limited. desktop and server level.
Layout plans of
i : Old UEs are In
ਹੈ 0
39 1736) ਮਤਿ re alte ae avallabllity of raster 68੧0 | Yer are in soft
ਜਰ with PUDA. format ( Autocad
ਤੂ format)
a ee
x. Browse the catalogue: The
authorised user can drill-through
the catalogue of published spatial
data of PUDA properties and
others grouped by the type
(imagery, raster, vector and
ae 22 related business data etc). Who will be providing the | came assn 15
300) Cataloguing and publishing ofall | imagery?
geospatial data available with
PUDA which are shp, jpg/tif, geo
tagged photographs and others.
All imagery, vector and related
business data (pdf, doc, mov,
jpeg, etc)
xiv. Searching and Query features
facility based on j. User will have 7 i
7.1 (b) option to perform searched on al providing the Same as sn 15
just imagery or just vectors or 8
both.
xv, Other GIS features ।, Change ਜੀ
7.1 (b) detection of PUDA properties ti ae providing the Same as SN 15
using temporal satellite images agery
xv. Customized Functional
Requirement of GUI g. Migration | Please provide more details
7.1 (b) of data from the existing system _| on the existing GIS server Same as SN 4
to GIS server is the responsibility | system.
of the service provider.
xv. Customized Functional Boras confirm the name of
Requirement of 60। 1. Testing of a 105 & Android.
7.1 (b) Mobile Application (on all yas ities the term Same as RFP
platform) lies with the Service a i platforms” if the IOS
(- Provider. ndroid fulfill the
requirement.
qr
5
Mp Gewese ee ane a

<!-- page 9 -->

We understand that Gis | ©! software
= i Functional software platform for platform for
ਜਾ ਗਰਮਾ of GUI h. The application hosting would (044 ਨ Id be
7.1 (b) 7 ing 0 Gis web-based be provided by PUDA and ਇੰ cada
application in the State Data bidder to deploy the provided by PUDS
centre Punjab, the charges developed application on bie cape ie
regarding the same will be borne | the same as per RFP ਨੱਸ aa
by PUDA. requirement. Please soe ts as per
clarify? clients need.
The bid evaluation will be carried i
੧ Bid evaluation to be carried | 2, ਨ
t Bid evaluation to
5.9.1 13 ਉਤ sues ਲਾ 35 out in three stages but in y ibe ‘
J. under ੪ Pre-qualification/ tender document be carried out in
eligibility evaluation A mentioned only two stages. Wome ee
* Financial bids evaluation
| ਨਾ
the, 6 RADA
