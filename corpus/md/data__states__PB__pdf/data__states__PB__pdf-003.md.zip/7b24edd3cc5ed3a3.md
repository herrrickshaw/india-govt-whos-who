---
doc_id: "7b24edd3cc5ed3a3"
source_url: "https://forest.punjab.gov.in/media/documents/Notification_village_chak_allah_baksh_0001-1.pdf"
ministry: "Forests and Wildlife Preservation Department, Punjab"
title: "ਸੂਚਨਾ - ਚੱਕ ਅੱਲ੍ਹਾ ਬਕੇਸ਼ 236 (ਹੁਸ਼ਿਆਰਪੁਰ)"
date: ""
pages: 2
method: "tesseract:pan+eng"
script: "LATIN"
needs_ocr: false
sha1: "91b14fafc7f34998"
---

<!-- page 1 -->

PUNJAB GOVERNMENT
DEPARTMENT OF FORESTS & WILDLIFE PRESERVATION
(FOREST BRANCH)
NOTIFICATION
No. DFWLP-39/1/2024-FB/ 502%
Chandigarh, Dated the 2(- ੭
In exercise of Powers conferred by section 29 of Indian Forest Act, 1927
and all other powers enabling him in this behalf the Governor of Punjab is pleased
to declare the land Under the ownership of the Government of Punjab in Village
Chak Allah Bakhsh, H.B. No. 236, Tehsil Mukerian, District Hoshiarpur,
described in the schedule below to be "Protected Forest" and that the provisions
of chapter-IV and other sections, including Section- 68 of the said Act shall be
applicable to them:-
SCHEDULE
Village | Description Area
With H.B. । of Khasra (K-M)
No. No.
1. | Hoshiarpur |Mukerian Chak Allah | 8//60/1 39-14
Bakesh-236
Total (K-M 39-14
[Total in Hectarel2.008 (Hectare
Whereas by this notification the land mentioned in the Schedule above is
hereby declared as "Protected Forest" under Section 29 of the Indian Forest
Act, 1927. Now therefore, the Governor of Punjab in exercise of the powers
conferred by Section 30 of the said act is pleased: -
a) _ 710 declare all trees standing in or upon these lands to be reserved from the
date of publication of this notification and
b) To prohibit from the same date the quarrying of stones/sand or burning of
lime or Charcoal or the collection or subjection to any manufacturing process or
removal of any forest produce in any such forest, and the breaking up or clearing
of land for cultivation, for building, for herding cattle or for any other purpose, of
any land in any such forests. ੧”)
ec

<!-- page 2 -->

Whereas by this notification land mentioned in Schedule in the said notification
has already been declared as "Protected Forest" under Section 29 of Indian
Forest Act, 1927. Now therefore, in exercise of the powers conferred by Section
32 and 33 of the said Act, the Governor of Punjab is pleased to make the following
rules applicable to all areas comprised in the aforesaid notification:-

RULES
1, No person shall
a. Cut, fell girdle, lop tap any tree, strips of the bark or leaves from, purpose
what-so-ever or remove any forest produce without the prior permission of
the Divisional Forest Officer, Dasuya.
b. Herd, pasture, graze or retain any cattle on the said land.
ce. Cut or remove the grass, kahi, kana without the prior permission of the
Divisional Forest Officer, Dasuya. The grass will be cut above ground level
with sickle only.
d. Clear or break up land for cultivation or for other purpose.
e. Set fire to grass, trees, timber or Kindle a fire on the land.
f. Hunt, shoot, fishing, poison water and set traps on the said land.
2. The income from compounding of offences against the rule under section 68
of the Indian Forest Act, 1927, shall be credit to the State Government.
Chandigarh, ਦਿ
Dated 26.03.2024 oa
(Krishan Kumar IAS)
Financial Commissioner
Forest and Wildlife Preservation
No. DFWLP-39/1/2024-FB/°5930-33
Dated the = 26/64/2024... w+
A copy is forwarded to the following for information and necessary action
to:-

1. The Controller Printing and Stationery, SAS Nagar, Punjab with one spare
Copy. It is requested that notification may be published in the next issue of
the Government Gazette and 100 copies of the same may be sent to this
Department.

2. Principal Chief Conservator of Forests (107), Punjab, Sector-68, Forest
Complex, Sahibzada Ajit Singh Nagar.

3. Divisional Forest Officer, Dasuya.

4. Deputy Commissioner, Hoshiarpur, ki (੧
.....
Financial Commissioner
Forest and Wildlife Preservation
EEE ਨ | ੧੦੦
