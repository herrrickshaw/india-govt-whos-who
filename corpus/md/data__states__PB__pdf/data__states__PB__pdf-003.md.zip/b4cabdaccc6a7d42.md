---
doc_id: "b4cabdaccc6a7d42"
source_url: "https://vigilancebureau.punjab.gov.in/uploads/notifications/order_290322.pdf"
ministry: "Vigilance Bureau, Punjab"
title: "Order dated 29.03.2022"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "558c397b4cf8fe60"
---

<!-- page 1 -->

ffiEE frgA, ?ing

Vigilance Bureau, Punjab
Vigilance Bhawan, Sector 68, S.A.S.Nagar

fufr&E ds6, l-*a< og, fiq.t.)er.-drd

Phone:221'7100-200 (Control Room & FAX)

da zzntoo-zoo (*.+6 g'H,ll} adFl
ORDER

The Punjab Government has started anti-corruption action line helpline
9501200200 on March 23, 2022, wherein the Government has exhorted people to

repot / post audio / video recordings of transactions relating to demand / acceptance
of illegal gratiflcation by public servants. The details pertaining to this anU-corrupUon
action line needs to be disseminated to common people. The punjab Government has
already given advertisements in news papers for publicity of this anti-corruption action
Iine.

2.

A large number of people visit website of Vigilance Bureau, punjab.

Hence, details of anti-corruption action line should be hosted on website of vigilance
Bureau, Punjab to ensure widespread publicity of this anti-corruption action line.

3.

It is, also directed that boards showing details of this anti-corruption

action line should be displayed at prominent locations outside offices and sub-units of
Vigilance Bureau working under your supervision, so that people visiting these offlces
may be made aware about this anti-corruption action line.

No.

B?L2-48,

uftfu

Chief Director,
Vigilance Bureau, Punjab.

/VB/S-3, dated
A copy of the above is forwarded to the following for meticulous
compliance of these orders:
1.
The Director, Vigilance Bureau, Punjab.
2.
The Addl. Director General of Police-cum-Director, EOW, Vigilance Bureau, Punjab.
3,
The Joint Director, Admn, Vigilance Bureau, Punjab..
4.
The Joint Director, Crime, Vigilance Bureau, Punjab.
5.
The Joint Director, Complaint Cell, Vigllance Bureau, Punjab.
The Joint Director, IVC, Vigilance Bureau, Punjab.
6.
7.
The loint Director, Prosecution, Vigilance Bureau, Punjab.
B.
The AIG/ Vigilance Bureau, Flying Squad, Punjab.
9.
The AIG/ Vigilance Bureau, EOW, Punjab.
10. The Sr. Supdts. of Police, Vigilance Bureau, Range Amritsar.
11. The Sr. Supdts. of Police, Vigilance Bureau, Range Jalandhar.
72. The Sr. Supdts. of Police, Vigilance Bureau, Range Ludhiana.
13. The Sr. Supdts. of Police, Vigilance Bureau, Range Patiala.
t4. The Sr. Supdts. of Police, Vigilance Bureau, Range Ferozepur.
15. The Sr. Supdts. of Police, Vigilance Bureau, Range Bathinda.
16. The Sr. Supdts. of Police, Vigilance Bureau, EOW, Ludhiana.
t7. -77?e Sa ,fuHho. ,* fto'ce, Viil./a.ttee Salea eo-{ al*4. e".,tc

4t .f. n ,t /J.d^/.-

Chief Director,
Vigilance Bureau, Punjab.

.A
