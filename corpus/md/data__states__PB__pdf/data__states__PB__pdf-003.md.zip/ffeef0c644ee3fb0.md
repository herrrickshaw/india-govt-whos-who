---
doc_id: "ffeef0c644ee3fb0"
source_url: "https://cdn.s3waas.gov.in/s3e2c0be24560d78c5e599c2a9c9d0bbd2/uploads/2022/04/2022042125.pdf"
ministry: "Rupnagar"
title: "– In view of increasing number of COVID cases – Advisory regarding wearing of masks Dated 21-04-2022"
date: ""
pages: 2
method: "tesseract:pan+eng"
script: "LATIN"
needs_ocr: false
sha1: "95b0e2d3aa1df8ac"
---

<!-- page 1 -->

`-. esa ਡਿਪਟੀ ਕਮਿਸ਼ਨਰ, ਰੁਪਨਗਰ
ਰ੍ OFFICE OF THE DEPUTY COMMISSIONER, RUPNAGAR
(1* FLOOR, MINI SECRETARIAT, RUPNAGAR)
Phone No. 01881-221157, Email: madcropar@gmail.com
ਪਿੱਠ ਅੰਕਣ ਨੰਬਰ[2:177-2,5%4 ਫਸ ਮਿਤੀ:-21.04,2022
Subject:- Advisory regarding wearing of masks.
ਇਸ ਦਾ ਇਕ ਉਤਾਰਾ:-
੮ 2). ਸਿਵਲ ਸਰਜਨ, ਰੂਪਨਗਰ
4). ਜਿਲ੍ਹਾ ਲੋਕ ਸੰਪਰਕ ਅਫਸਰ, ਰੂਪਨਗਰ 4 ਸ੍ਰੀ ਅਨੰਦਪੁਰ ਸਾਹਿਬ
5). ਪੀਏ.ਟੂਡੀ.ਸੀ/ ਸਟੈਨੋਗ੍ਰਾਫਰ ਟੂ ਏ.ਡੀ.ਸੀ. Ay ਸਹਾਇਕ ਕਮਿਸ਼ਨਰ (ਜ) ਰੂਪਨਗਰ ਨੂੰ ਮਾਨਯੋਗ ਮੁੱਖ ਸਕੱਤਰ
. 7/56/2020/2H4/2035-2036, ਮਿਤੀ 21.04.2022 ਰਾਹੀਂ ਜਾਰੀ ਹੋਏ ਹੁਕਮਾਂ ਦੀ ਕਾਪੀ ਸੂਚਨਾਂ ਤੇ ਲੋੜੀਦੀ
ਕਾਰਵਾਈ ਕਰਨ ਹਿੱਤ ਭੇਜੀ ਜਾਂਦੀ ਹੈ।
ਹਨਰ (ਜ)
|
Scanned with CamScanner

<!-- page 2 -->

we
ya
~
i by
As
« s Government of Punjab
ਚੰ ਦਰ epartment of Home Affairs & Justice
(Home - 4 Branch)
To An
1. AllJhe Diylgional Commissioners and
the Deputy Commissioners in the State
2, _ Allthe Zonal GPs, Commissioners of Police,
DIGs and SSPs in the State
No. 7/56/2020/2H4/2035-2036
Dated, Chandigarh the 21 April, 2022.
Subject: Advisory regarding wearing of masks.
1. In view of increasing number of COVID cases in some of the States
and UTs, all the residents of the State of Punjab are hereby advised to wear face
masks at the crowded places.
2. Wearing of masks should be specially ensured in the closed
environments like:-
¢ Public Transports like Buses, Trains, Aircrafts, Taxi etc.
¢ Cinema Halls, Shopping Malls, Departmental Stores etc.
¢ Classrooms, Office-rooms, indoor gatherings etc.
Anurag Verma, IAS
Principal Secretary to Government of Punjab
Department of Home Affairs & Justice
CC:
1. PS/ICM
2. PS/Dy.CM
3. PS/CS
4. All administrative Secretaries/Registrar- Punjab & Haryana High
Court
5. DGP Punjab
6. ADGP-Law & Order
Scanned with CamScanner
