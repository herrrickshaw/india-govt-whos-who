---
doc_id: "a27651cdebedd9c8"
source_url: "https://ppcb.punjab.gov.in/media/documents/ELV_Rules_2025.pdf"
ministry: "Punjab Pollution Control Board (PPCB), Punjab"
title: ""
date: ""
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2dd317e8e83c464e"
---

<!-- page 1 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

21

MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE
NOTIFICATION
New Delhi, the 6th January, 2025
S.O. 98(E).—WHEREAS the Draft End-of-Life Vehicles (Management) Rules, 2024 was published in the
Gazette of India, Extraordinary, Part II, section 3, sub-section (ii), vide S.O. 367 (E) dated 30 th January, 2024 inviting
objections and suggestions from all persons before the expiry of sixty days from the date on which copies of the
Gazette containing the said draft provisions were made available to the public;
And, WHEREAS the Gazette containing the draft of rules were made available to the public on the 30th
January, 2024;
And, WHEREAS all the objections and suggestions received have been duly considered by the Central
Government;
NOW, THEREFORE, in exercise of the powers conferred by sub-section (1), clause (v) and clause (vii) of
sub-section (2) of section 3, sub-section (1), clause (c) and clause (d) of sub-section (2) of section 6, section 8, clause
(b) of sub-section (2) of section 25 of the Environment (Protection) Act, 1986 (29 of 1986) read with clauses (ii) and
(x) of sub-rule (1) and clause (d) of sub-rule (3) of rule 5 the Environment (Protection) Rules, 1986, the Central
Government hereby makes the following rules, namely:1. Short title and commencement. – (1) These rules may be called the Environment Protection (End-of-Life
Vehicles) Rules, 2025.
(2) They shall come into force from 1st day of April, 2025.
2. Application. – (1) These rules shall apply to, –
(a) the producer, registered owner of vehicles, bulk consumers, Registered Vehicle Scrapping
Facility, collection centres, automated testing stations and entities involved in testing of vehicles, handling,
processing and scrapping of End-of-Life vehicles, but shall not apply to:
(i)

waste batteries covered under the Battery Waste Management Rules, 2022;

(ii) plastic packaging as covered under the Plastic Waste Management Rules, 2016;
(iii) waste tyres and used oil as covered under Hazardous and Other Wastes (Management and
Transboundary Movement) Rules, 2016;
(iv) E-waste as covered under E-Waste (Management) Rules, 2022.
(b) all types of vehicles defined in clause (28) of section 2 of the Motor Vehicles Act, 1988 (59 of
1988), and includes an electric vehicle, battery operated vehicle, e-rikshaw or e-cart, but shall not apply to:
(i) agricultural tractor;
(ii) agricultural trailer;
(iii) combine harvester; and
(iv) power tiller.
3. Definitions. – (1) In these rules, unless the context otherwise requires, –
(a)

“Act” means the Environment (Protection) Act, 1986 (29 of 1986);

(b)

“automated testing station” shall have the meanings assigned to them in sub-section 2 of section 56
of the Motor Vehicles Act, 1988 (59 of 1988);

(c)

“bulk consumer” means consumer having ownership of more than one hundred vehicles, and
includes a State transport undertakings as defined in the clause (42) of section 2 of the Motor
Vehicles Act, 1988 (59 of 1988);

<!-- page 2 -->

22

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(d)

“Central Board” means the Central Pollution Control Board constituted under sub-section (1) of
section 3 of the Water (Prevention and Control of Pollution) Act, 1974 (6 of 1974);

(e)

“centralised online portal” means an online portal developed and maintained under sub-rule (1) of
rule 16;

(f)

“Collection Centre” shall have the meanings assigned to them in clause (e) of sub-rule (1) of rule 3
of the Motor Vehicles (Registration and Functions of Vehicle Scrapping Facility) Rules, 2021;

(g)

“disposal” means any activity which does not lead to reuse, recovery, recycling or refurbishing and
include physico-chemical or biological treatment or deposition in secured landfill;

(h)

“environmentally sound management manner” means the handling and disposal of End-of-Life
vehicle in such a manner that protects human health and environment against any adverse effects,
which may result from any substance contained in the End-of-Life vehicle;

(i)

“End-of-Life vehicle” shall have the meanings assigned to them in clause (f) of sub-rule (1) of rule 3
of the Motor Vehicles (Registration and Functions of Vehicles Scrapping Facility) Rules, 2021;

(j)

“Extended Producer Responsibility” means responsibility of a producer for scrapping of the End-ofLife vehicle in environmentally sound manner;

(k)

“Extended Producer Responsibility certificate” means a certificate issued under rule 9 by the Central
Board;

(l)

“facility” means any place used for the collection, storage, segregation, recycling or refurbishing, or
disposal of End-of-Life vehicles;

(m)

“Form” means a Form appended to these rules;

(n)

“hazardous waste” shall have the meanings assigned to them in clause (17) of sub-rule (1) of rule 3
of the Hazardous and Other Wastes (Management and Transboundary Movement) Rules, 2016.

(o)

“manufacturer” means a person who is engaged in the manufacture of motor vehicles;

(p)

“non-transport vehicle” shall have the meanings assigned to them in clause (h) of rule 2 of the
Central Motor Vehicles Rules, 1989;

(q)

“producer” means an entity who is engaged in:
(i) manufacture or assembly and sale of vehicles under its own brand; or
(ii) sale of vehicles under its own brand produced by other manufacturers or suppliers; or
(iii) import of vehicles.

(r)

“registered owner” means a person in whose name a vehicle stands registered, and where such
person is a minor, the guardian of such minor;

(s)

“recycler” means an entity engaged in recycling of any materials of End-of-Life vehicles;

(t)

“recycling” means any process by which waste materials are converted into products and raw
materials;

(u)

“refurbisher” means entity engaged in refurbishing of materials of End-of-Life vehicles;

(v)

“Registered Vehicle Scrapping Facility” shall have the meanings assigned to them in clause (k) of
sub-rule (1) of rule 3 of the Motor Vehicles (Registration and Functions of Vehicle Scrapping
Facility) Rules, 2021;

(w)

“Schedule” means Schedule appended to these rules;

<!-- page 3 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

23

(x) “State Board" means the State Pollution Control Board constituted under section 4 of Water
(Prevention and Control of Pollution) Act, 1974 (6 of 1974) and includes in relation to Union
territory, the Pollution Control Committee;
(y)

“storage” means storage of End-of-Life vehicles, including its components or parts;

(z)

“transport vehicle” shall have the meanings assigned to them in clause (47) of section 2 of the Motor
Vehicles Act, 1988;

(za) “treatment” means any activity after the End-of-Life vehicle has been handed over for depollution,
dismantling, shearing, shredding, recovery or preparation for disposal of the shredder wastes, and
any other operation carried out for the recovery or recycling or disposal of the End-of-Life vehicle
and its components;
(zb) “vehicle” shall have the meanings assigned to them in clause (28) of section 2 of the Motor Vehicles
Act, 1988 (59 of 1988), and includes an electric vehicle, battery operated vehicle, e-rikshaw or ecart.
(2) Words and expressions used but not defined in these rules shall have the same meanings as defined in the
Environment (Protection) Act, 1986, the Motor Vehicles Act, 1988 and the Central Motor Vehicles Rules, 1989.
4. Responsibilities of producer – (1) Every producer must,(i)

fulfil the obligation of Extended Producer Responsibility for the vehicles that the producer has
introduced or introduces in the domestic market, including vehicles put to self-use to ensure the
scrapping targets as specified in the Schedule;

(ii)

meet the scrapping targets of End-of-Life vehicles as mentioned in the Schedule for vehicles the
producer has introduced or introduces in the domestic market;

(iii)

take necessary measures to encourage End-of-Life vehicles are deposited at the Registered Vehicle
Scrapping Facility or designated Collection Centres;

(iv) fulfil the Extended Producer Responsibility either through purchase of Extended Producer
Responsibility certificate generated by its own Registered Vehicle Scrapping Facility or by any entity
having Registered Vehicle Scrapping Facility;
(v)

deploy any schemes such as buy back scheme, deposit refund scheme or any other, and designate any
other entity to fulfil the obligation of Extended Producer Responsibility;

(vi)

obtain registration as a producer from Central Board through centralised online portal;

(vii)

furnish annual returns in Form 1 on centralised online portal to Central Board by 30th June for the
previous financial year(a)

in respect of the information regarding the number and type of the vehicles (transport or nontransport) and the weight of steel used in vehicles placed in the market, including vehicles put to
self-use in previous financial year;

(b) in respect of fulfilment of Extended Producer Responsibility obligations during the previous
financial year;
(viii) declare its Extended Producer Responsibility obligations for the current year by 30th April of the same
year to the Central Board;
(ix) inform the Central Board of any changes to the information contained in the Extended Producer
Responsibility registration or obligation and of any permanent cessation as regards to the making
available on the market of the vehicles referred to in the Extended Producer Responsibility obligation;
(x) bring to the notice of the Central Board or State Board of any violations or non-compliance or violation
of the provisions of these rules by any entity involved in handling and management of End-of-Life
vehicles;

<!-- page 4 -->

24

THE GAZETTE OF INDIA : EXTRAORDINARY
(xi)

[PART II—SEC. 3(ii)]

take measures to comply with the provisions of AIS-129, as published by the Central Government
under Central Motor Vehicles Rules, 1989.

(2)
A producer shall not engage in any manner with any entity not registered under these rules for scrapping
of the End-of-Life vehicles or for fulfilling its Extended Producer Responsibility under these rules.
(3)

A producer may engage any registered entity to fulfil its Extended Producer Responsibility under these

rules.
(4)
Every producer shall take measures for sustainable production of vehicles including in accordance
with the guidelines issued by the Central Board.
(5)
Every producer must make necessary arrangements to receive the End-of-Life vehicle from the
registered owner at any designated Collection Centre, including its sales outlet and shall upload such list of
designated Collection Centre, sales outlet on its website and at a conspicuous place of its sales outlets and service
centres. List of such designated collection centres shall be furnished to Central Board on centralised online portal.
(6)
In case the producer stops its operations, the producer must comply with its Extended Producer
Responsibility in respect of vehicles already made available in the market till closure of operations, in accordance
with these rules.
(7) Every producer shall organise awareness campaigns and encourage customers by offering incentives to
safe deposit of End-of-Life vehicles at the Registered Vehicle Scrapping Facility or the designated Collection Centre.
5. Responsibilities of registered owner and bulk consumer – (1) Every registered owner and bulk consumer
must ensure that the vehicle is tested in accordance with the section 56 of the Motor Vehicles Act, 1988 and rule 52
of the Central Motor Vehicles Rules, 1989.
(2) When a vehicle becomes an End-of-Life vehicle as per the Motor Vehicles (Registration and Functions of
Vehicles Scrapping Facility) Rules, 2021, the registered owner or bulk consumer must deposit the End-of-Life
vehicle at any of the producer’s designated sales outlet or designated Collection Centre or Registered Vehicle
Scrapping Facility within a period of one hundred and eighty days from the date the vehicle becomes the End-of-Life
vehicle.
(3) No person shall keep in possession any End-of-Life vehicle beyond the period specified in sub-rule (2).
(4) A bulk consumer must obtain registration on the centralised online portal from the State Board.
(5) A bulk consumer must file an annual return in Form 2 on or before 30th June for the previous financial
year on the centralised online portal about the details of vehicles it owns or possesses and the End-of-Life vehicles
deposited at producer’s designated sales outlet or designated Collection Centre or Registered Vehicle Scrapping
Facility for scrapping of such End-of-Life vehicle.
6. Responsibilities of Collection Centre- (1) Every Collection Centre must collect and store End-of-Life
vehicles and send them to Registered Vehicle Scrapping Facility.
(2) Every Collection Centre shall handle the End-of-Life Vehicles in an environmentally sound manner and
send them to Registered Vehicle Scrapping Facility.
(3) The Collection Centre shall maintain the records of the End-of-Life vehicle received by it and sent to the
Registered Vehicle Scrapping Facility and the manner in which such vehicle is handled.
7. Responsibilities of automated testing station. – (1) An automated testing station shall upload the details
of all vehicles declared unfit under rule 182 of the Central Motor Vehicles Rules, 1989, on the centralised online
portal either directly or through linking of the electronic portal set up by the Central Government under sub-rule (1)
of rule 181 of the said rules.
8. Responsibilities of Registered Vehicle Scrapping Facility.– (1) A Registered Vehicle Scrapping Facility
shall undertake the following activities relating to scrapping of End-of-Life vehicles in an environmentally sound
manner, namely:-

<!-- page 5 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

25

(i)

treatment (de-pollution, collection of liquids, gases, catalyst, mercury containing parts, batteries and
hazardous waste);

(ii)

dismantling (segregation and separation of various types of wastes);

(iii) safe storage of various categories of wastes in separate bins;
(iv) recycling and refurbishment of materials (plastic, metals, tyres, catalytic converters, magnets, batteries
and e-waste) on its own or through authorized recyclers or refurbishers.
(2)

A Registered Vehicle Scrapping Facility shall(a)

receive unfit vehicles or End-of-Life vehicles for scrapping and must carry out treatment,
depolluting, dismantling, segregation and scrapping activities in accordance with the provisions
of the relevant laws.

(b) send all the recovered and segregated materials from End-of-Life vehicles to the registered
recyclers or refurbishers, co-processors for recycling and reuse of components or materials, in
case of not having recycling or refurbishing facility;
(c)

send all non-recyclable or non-refurbishable materials and non-utilizable hazardous materials to
Common Hazardous Waste Treatment, Storage and Disposal Facility authorised under Hazardous
and Other Wastes (Management and Transboundary Movement) Rules, 2016;

(d) exchange the Extended Producer Responsibility certificates upon processing of every End-ofLife vehicle based on the quantity of steel from the End-of-Life vehicles on the centralized online
portal for issuance of Extended Producer Responsibility certificates by Central Board for
purchase by the producers;
(e)

maintain records of receipt of End-of-Life vehicle, weight of various types of waste materials
generated and handed over to authorized recyclers or refurbishers or treatment facilities and
disposal facilities;

(f)

make an application in Form 5 to concerned State Board and obtain registration for operation or
Registered Vehicle Scrapping Facility.

(3) A Registered Vehicle Scrapping Facility shall file quarterly returns on the centralised online portal to State
Board in Form 3 on weight of End-of-Life vehicles received and weight of materials (category-wise) recycled or
refurbished or sent for recycling or refurbishing, processing, and Common Hazardous Waste Treatment, Storage and
Disposal Facilities by 30th day of the next month of the previous quarter, and keep a record.
9. Extended Producer Responsibility certificate. – (1) The Central Board shall issue the Extended
Producer Responsibility certificate through the centralised online portal in favour of the Registered Vehicle Scrapping
Facility. Central Board will develop mechanism for such exchange on the centralised online portal.
(2) An Extended Producer Responsibility certificate shall be generated on basis of the weight of steel
recovered from the End-of-Life vehicles processed at the Registered Vehicle Scrapping Facility or other steel scrap
materials related to automobile sector processed at Registered Vehicle Scrapping Facility in accordance with the
Motor Vehicles (Registration and Functions of Vehicle Scrapping Facility) Rules, 2021.
(3) An Extended Producer Responsibility certificate generated by the Registered Vehicle Scrapping Facility
can be purchased by a producer through the centralised online portal to meet the Extended Producer Responsibility
obligations under these rules.
(4) The following formula shall be used to estimate the Extended Producer Responsibility certificate for the
Registered Vehicle Scrapping Facility, namely:Extended Producer Responsibility certificate (in kg) = weight of the steel scrap generated (in kg) at Registered
Vehicle Scrapping Facility:
Provided that the Extended Producer Responsibility certificate shall be generated subject to the accounting
of recycling and refurbishing of all other End-of-Life vehicle materials and environmentally sound disposal of nonrecoverable or non-recyclable or non-refurbishable hazardous materials out of the total weight of the End-of-Life
vehicle.

<!-- page 6 -->

26

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(5) A Producer can purchase Extended Producer Responsibility certificate limited to its Extended Producer
Responsibility obligation of current year plus any leftover obligation of preceding years.
(6) An Extended Producer Responsibility certificates purchased by the Producer shall be automatically adjusted
against their obligations under these rules.
(7) Priority in adjustment shall be given to the earlier obligation or obligation of the preceding years.
(8) An Extended Producer Responsibility certificate used by the producer to meet its Extended Producer
Responsibility obligations shall not be exchanged again.
(9) An Extended Producer Responsibility certificate purchased by the producer is not transferrable to any other
producer.
(10) All such transactions relating to purchase and adjustment of Extended Producer Responsibility certificate
shall be recorded and submitted by the Registered Vehicle Scrapping Facilities on the centralised online portal and
shall be included in its quarterly returns.
(11) An Extended Producer Responsibility certificate generated by the Registered Vehicle Scrapping Facilities
shall be valid for a period of five years for meeting the obligations of producer under these rules.
10. Registration and suspension or cancellation.- (1) A producer shall make an application in Form 4 for
registration to the Central Board.
(2) A Registered Vehicle Scrapping Facility and bulk consumer shall make an application in Form 5 and
Form 6, respectively, for registration, to the State Board.
(3) On receipt of the application, the Central Board or the State Board shall register the producer or the
Registered Vehicle Scrapping Facility or the bulk consumer and issue a certificate of registration in Form 7 and
Form 8 within fifteen days, respectively.
(4) The registration certificate granted under sub-rule (3) shall be valid until it is suspended or cancelled
under these rules.
(5) The Central Board may, after giving the producer an opportunity of being heard, suspend or cancel the
registration of a producer, in case of violation or non-compliance of any provisions of these rules by the producer.
(6) The producer aggrieved by the suspension or cancellation of the registration under sub-rule (5) may
prefer an appeal stating therein the grounds of such appeal and accompanied with a copy of the order appealed against
to the Central Government within forty-five days of such suspension or cancellation.
(7) The Central Government may authorise an officer of the Central Government not below the rank of a
Joint Secretary to the Government of India to hear and dispose of the appeal filed under sub-rule (6) within a period of
forty-five days from the date of its receipt.
(8) The State Board may, after giving the Registered Vehicle Scrapping Facility or bulk consumer an
opportunity of being heard, suspend or cancel the registration of a Registered Vehicle Scrapping Facility or bulk
consumer, in case of violation or non-compliance of any provisions of these rules by the Registered Vehicle Scrapping
Facility or bulk consumer.
(9) The Registered Vehicle Scrapping Facility or bulk consumer aggrieved by the suspension or cancellation
of the registration under sub-rule (8) may prefer an appeal stating therein the grounds of such appeal and accompanied
with a copy of the order appealed against to the State Government within forty-five days of such suspension or
cancellation.
(10) The State Government may authorise an officer of the State Government not below the rank of Secretary
to that Government to hear and dispose of the appeal filed under sub-rule (9) within a period of forty-five days from
the date of receipt.
11. Powers of Central Government to relax. – The Central Government, may by order, and for reason to be
recorded in writing, relax any specified period within which a return is to be filed by the producer or Registered
Vehicle Scrapping Facility or bulk consumer under these rules.

<!-- page 7 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

27

12. Responsibilities of Central Board. – (1) Central Board shall register the producer through the centralized
online portal within fifteen days from the submission of the application for such registration under these rules.
(2) The registration shall be valid until it is cancelled or withdrawn by the Central Board.
(3) On receipt of the application for registration, it shall be deemed to have been done if not objected to by
the Central Board within fifteen days.
(4) The Central Board shall develop and maintain the centralised online portal for the purposes of these rules.
(5) The centralised online portal shall be linked with the electronic portal set up by the Central Government
under sub-rule (1) of rule 181 of the Motor Vehicles Rules, 1989.
(6) The Central Board shall undertake or cause to be undertaken by an authorised agency the periodic
inspection and audit of the producer to ensure that such facility is complying with the requirement under the
provisions of these rules.
(7) The Central Board may undertake or cause to be undertaken by an authorised agency the periodic
inspection and audit of the Registered Vehicle Scrapping facility, including information from Goods and Services Tax
Network portal, to ensure that such facility is complying with the requirement under the provisions of these rules.
(8) The Central Board, or the State Board if directed by the Central Board, may take necessary actions against
violations or for non-fulfilment of obligations under these rules against a producer or Registered Vehicle Scrapping
Facility or any other person under the provisions of the Act.
(9) The Central Board shall issue guidelines for handling, processing and recycling or refurbishing of materials
of End-of-Life vehicles in environmentally sound manner and for implementation of these rules.
(10) The Central Board shall compile and publish the data received every year from the State Boards on the
centralised online portal within a period of sixty days from the receipt of such data.
(11) The Central Board shall publish the list of producers who have failed to meet their Extended Producer
Responsibility targets and obligations on an annual basis on the centralised online portal by 31st August every year.
(12) The Central Board shall forward the Extended Producer Responsibility targets and annual returns of
producers to the Central Government through the centralised online portal by 31 st August every year.
(13) The Central Board shall prepare an annual report containing information which, inter alia, includes the
Extended Producer Responsibility targets of producers and their fulfilment, scrapping of End-of-Life vehicles, and
generation and exchange of the Extended Producer Responsibility certificates and furnish to the Central Government
through the centralised online portal by 31 st August every year.
(14) The Central Board shall fix the highest and lowest price for the Extended Producer Responsibility
certificates which shall be equal to one hundred percent. and thirty per cent., respectively of the Environmental
Compensation leviable on the obligated entities for non-fulfilment of Extended Producer Responsibility obligations,
between which producers may purchase Extended Producer Responsibility certificates from Registered Vehicle
Scrapping Facility through the centralised online portal.
(15) Central Board shall issue guidelines for authorisation of agencies for establishment of electronic
platform for trade of Extended Producer Responsibility certificates. The number of electronic platform may be
restricted keeping in view volume of trade of Extended Producer Responsibility certificates.
(16) The operation of electronic platform (s), so established under sub-rule (15) for exchange of Extended
Producer Responsibility certificates between obligated entities, shall be as per guidelines issued by Central Board with
the approval of Central Government.
(17) Central Board may determine the fee for processing of applications for registration as well as returns for
producers, Registered Vehicle Scrapping facilities with the approval of the Central Government.
13. Measures by State Government. – (1) The State Government and the Union territory Administration
shall take steps to ensure that adequate number of Registered Vehicle Scrapping Facilities and automated testing

<!-- page 8 -->

28

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

stations are established in the respective State and Union territory in accordance with the Central Motor Vehicle
Rules, 1989 and the Motor Vehicles (Registration and Functions of Vehicle Scrapping Facility) Rules, 2021.
(2) State Government and Union territory Administration will organise awareness campaigns and encourage
and incentivise customers to engage in safe deposition of End-of-Life vehicles at the Registered Vehicle Scrapping
Facility or the designated Collection Centre.
14. Responsibilities of State Board. – (1) The State Board shall register the Registered Vehicle Scrapping
Facility and bulk consumer electronically on the centralized online portal within fifteen days from the submission of
the application for such registration under these rules.
(2) The registration shall be valid until it is cancelled or withdrawn by the State Board.
(3) On receipt of the application for registration, it shall be deemed to be have done if not objected by the
State Board within fifteen days.
(4) In case the information provided by Registered Vehicle Scrapping Facility or bulk consumer is found to be
false, the State Board shall suspend or cancel the registration up to a period of five years, after giving reasonable
opportunity of being heard and in addition take actions in accordance with the provisions of the Act.
(5) The State Board shall compile and forward the quarterly reports submitted by Registered Vehicle
Scrapping Facility and annual reports in case of bulk consumer to Central Board and publish it on the centralised
online portal within a period of thirty days from the date of filing of return.
(6) The State Board shall ensure a regular dialogue between relevant stakeholders involved in the fulfilment
of obligations under these rules.
(7) The State Board shall submit an annual report to Central Board by 30th August every year, regarding
implementation of these rules.
(8) The State Board shall undertake periodic inspection and audit, or cause to be inspected by an authorised
agency, of the Registered Vehicle Scrapping Facility to ensure the compliance of these rules and may take necessary
actions against violations or for non-fulfilment of obligations under these rules against a Registered Vehicle
Scrapping Facility or bulk consumer or any other person under the provisions of the Act.
15. Environmental Compensation. – (1) Where any producer, Registered Vehicle Scrapping Facility and
bulk consumer fails to comply with the provisions relating to handling and scrapping of End-of-Life vehicles in
environmentally sound manner under these rules, thereby causing loss, damage or injury to environment or public
health, he shall be liable to pay environmental compensation which may be equal to such loss, damage or injury in
accordance with the guidelines issued by the Central Board.
(2) No environmental compensation shall be imposed under this rule without giving the producer, Registered
Vehicle Scrapping Facility or bulk consumer, an opportunity of being heard in this matter.
(3) Environmental compensation under sub-rule (1) shall be imposed by the Central Board in respect of
obligations of producer, and by the State Board in respect of obligations of Registered Vehicle Scrapping Facility
and bulk consumer.
(4) Where producer or Registered Vehicle Scrapping Facility or bulk consumer subsequently complies with
the obligations, the amount of environmental compensation paid by him may be returned to him, if the obligation is
complied(a)

within one year, 75% of the environmental compensation;

(b)

within two years, 60% of the environmental compensation; and

(c)

within three years, 40% of the environmental compensation.

(5) The environmental compensation paid under this rule shall be kept in a separate account maintained by the
Central Board or State Board, as the case may be.

<!-- page 9 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

29

(6) The amount of environmental compensation paid under this rule shall be utilised for restoration of loss,
damage or injury caused to environment or public health through environmentally sound management including
collection, handling, scrapping and recycling of the End-of-Life vehicles and remediation or removal of
contamination occurred due to unscientific management of End-of-Life vehicles.
16. Centralised Online Portal. – (1) The Central Board shall establish a centralised online portal within six
months of publication of these rules for the registration and filing returns by producers and bulk consumer, and for
registration of Registered Vehicle Scrapping Facility and filing returns in respect of End- of-Life Vehicles and for
fulfilment of obligations under these rules.
(2) The Central Board shall ensure that the data on the receipt of the End-of-Life vehicles and the various
types of waste materials generated by Registered Vehicle Scrapping Facility is reflected all the times on the
centralised online portal.
(3) The centralised online portal must facilitate producers and Registered Vehicle Scrapping Facilities to
exchange Extended Producer Responsibility certificates for fulfilment of Extended Producer Responsibility
obligations of producers.
(4) The State Board shall use the centralized online portal for registration of Registered Vehicle Scrapping
Facility and bulk consumer, and for filing of returns by Registered Vehicle Scrapping Facility and bulk consumer.
(5) The centralised online portal shall be single point data repository with respect to all the activities,
including orders issued, under these rules.
(6) The producer may facilitate the development of the centralised online portal.
17.
Implementation Committee. – (1) The Central Government may constitute a committee under
chairpersonship of Chairman of the Central Board for effective implementation of these rules.
(2) The committee shall monitor the implementation of these rules.
(3) The committee shall take such measures as may be necessary for effective implementation of these rules.
(4) The committee shall guide and supervise the development and operation of the centralised online portal.
(5) The committee shall meet at least once in six months and submit its report to the Central Government.
(6) The committee shall consist of the representatives from Ministry of Road Transport and Highways,
Ministry of Steel, Bureau of Indian Standards, State Boards, National Environmental Engineering Research Institute,
stakeholders representing producers, recyclers and scrapping facilities and any other stakeholder, as the Central
Government may nominate.
(7) The chairperson of the committee may invite to its meetings any person or other organisations as in his or her
opinion may be useful to the deliberations of the committee.
SCHEDULE
[see rule 4 (1)(i)]
TARGETS FOR EXTENDED PRODUCER RESPONSIBILITY
1. In case of any producer introducing vehicle in the market, the Extended Producer Responsibility targets
shall be applicable for different categories of vehicle, based on the average life of the vehicle mentioned in the Tables
below for the respective categories of vehicle.
2. The Extended Producer Responsibility targets comprise of scrapping of steel used in vehicles as
mentioned in the Tables below.
3. The scrapping of End-of-Life vehicles means scrapping of steel from End-of-Life vehicles.
4. Extended Producer Responsibility targets for batteries will be as under Battery Waste Management Rules,
2022.
5. Extended Producer Responsibility for waste tyres and used oil will be as under the Hazardous and Other
Wastes (Management and Transboundary Movement) Rules, 2016.

<!-- page 10 -->

30

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

6. Extended Producer Responsibility targets for the producer shall be specific to the type of vehicle (transport
vehicle and non-transport vehicle).
7. The producers shall meet their Extended Producer Responsibility obligations through the Extended
Producer Responsibility certificates made available by Registered Vehicle Scrapping Facilities through centralized
portal. In case of non-availability of Extended Producer Responsibility certificates with Registered Vehicle Scrapping
Facilities, the producer shall have the responsibility of collection as well.
TABLE
(i) For non-transport vehicles:
Extended Producer
Responsibility target for
Financial Year

Extended Producer Responsibility target
(Weight)

(1)

(2)

2025-26

Minimum 8% of the steel used in vehicles in 2005-06

2026-27

Minimum 8% of the steel used in vehicles in 2006-07

2027-28

Minimum 8% of the steel used in vehicles in 2007-08

2028-29

Minimum 8% of the steel used in vehicles in 2008-09

2029-30

Minimum 8% of the steel used in vehicles in 2009-10

2030-31

Minimum 13% of the steel used in vehicles in 2010-11

2031-32

Minimum 13% of the steel used in vehicles in 2011-

2032-33

Minimum 13% of the steel used in vehicles in 2012-13

2023-34

Minimum 13% of the steel used in vehicles in 2013-14

2034-35

Minimum 13% of the steel used in vehicles in 2014-15

2035-36

Minimum 18% of the steel used in vehicles in 2015-16

2036-37

Minimum 18% of the steel used in vehicles in 2016-17

2037-38

Minimum 18% of the steel used in vehicles in 2017-18

2038-39

Minimum 18% of the steel used in vehicles in 2018-19

2039-40 and onwards

Minimum 18% of the steel used in vehicles in 2019-20 for 2039-40 and
for subsequent years, of the steel used in vehicles 20 years ago

Note: 30% of the Extended Producer Responsibility targets, of any year, may be carried forward to the subsequent
four years for its Extended Producer Responsibility target compliance.

<!-- page 11 -->

[भाग II—खण्ड 3(ii)]
(ii)

भारत का रािपत्र : असाधारण

31

For transport vehicles:

Extended Producer
Responsibility target
for Financial Year
(1)

Extended Producer Responsibility target
(Weight)
(2)

2025-26

Min 8% of the steel used in vehicles in 2010-11

2026-27

Min 8% of the steel used in vehicles in 2011-12

2027-28

Min 8% of the steel used in vehicles in 2012-13

2028-29

Min 8% of the steel used in vehicles in 2013-14

2029-30

Min 8% of the steel used in vehicles in 2014-15

2030-31

Min 13% of the steel used in vehicles in 2015-16

2031-32

Min 13% of the steel used in vehicles in 2016-17

2032-33

Min 13% of the steel used in vehicles in 2017-18

2023-34

Min 13% of the steel used in vehicles in 2018-19

2034-35

Min 13% of the steel used in vehicles in 2019-20

2035-36

Min 18% of the steel used in vehicles in 2020-21

2036-37

Min 18% of the steel used in vehicles in 2021-22

2037-38

Min 18% of the steel used in vehicles in 2022-23

2038-39

Min 18% of the steel used in vehicles in 2023-24

2039-40 and onwards

Min 18% of the steel used in vehicles in 2024-25 for 2039-40 and for subsequent years, of
the steel used in vehicles 15 years ago

Note: 30% of the Extended Producer Responsibility targets, of any year, may be carried forward to the subsequent
four years for its Extended Producer Responsibility target compliance.
FORM 1
[see rule 4(1)(vii)]
ANNUAL RETURN BY THE PRODUCER
[under the Environment Protection (End-of-Life Vehicles) Rules, 2025]
1

Name of producer:

2

Registered address of producer, website address
and contact details:

3

Name of the authorised person and full address
with e-mail, landline telephone number and
mobile number

4

GST No.

5

TIN No.

<!-- page 12 -->

32

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

6.
Details of vehicles placed in the market of the year on which Extended Producer Responsibility target is
calculated as per the Table given below:
Serial Financial
Number Year
(1)

(2)

Type

(3)

1

2 Wheeler
(non-transport)

2

3 Wheeler
(non-transport)

3

4 Wheeler
(-non-transport)

4

2 Wheeler
(transport)

5

3 Wheeler
(transport)

6

4 Wheeler
(transport)

Brand
name

No. of
vehicles

Total
Weight

(4)

(5)

(6)

Weight of steel in
the vehicles
(7)

7.
Details of Extended Producer Responsibility obligation(s) and the End-of-Life vehicles collected and recycled
for which the return is being filed:

a.

Extended Producer Responsibility obligation:

b.

Weight of steel from End-of-Life vehicles/ other steel scrap materials related to automobile sector processed
at Registered Vehicle Scrapping Facility:

8.

Details of Registered Vehicle Scrapping Facility-wise Extended Producer Responsibility certificates

Note.- Extended Producer Responsibility target compliance includes vehicles put to self-use by producers
Date:
Place:
Signature of the authorised person:

<!-- page 13 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

33

FORM 2
[see rule 5(5)]
ANNUAL RETURN BY BULK CONSUMER
[under the Environment Protection (End-of-Life Vehicles) Rules, 2025]

1. Name of Registered bulk consumer:
2. Registered address of bulk consumer, website address and contact details:
3. Name of the authorised person(s) and full address with e-mail, landline telephone number and mobile
number:

4. Details of vehicles registered and End-of-Life vehicles deposited at Registered Vehicle Scrapping Facility, in
case of bulk consumer:
i.

Number of vehicles registered (2 wheeler, 3 wheeler, 4 wheeler and transport or nontransport):

ii.

Number of vehicles which have completed age of ten years in case of diesel and fifteen years
in case of petrol or CNG or electric vehicles:

iii.

Number of fit vehicles:

iv.

Number of unfit or End-of-Life vehicles:

v.

Number and details of End-of-Life vehicles deposited at Registered Vehicle Scrapping
Facility

Place:
Date:
Signature of the authorised person:

FORM 3
[see rule 8(3)]
QUARTERLY RETURNS
BY REGISTERED VEHICLE SCRAPPING FACILITY
[under the Environment Protection (End-of-Life Vehicles) Rules, 2025]
1.

Name of Registered Vehicle Scrapping Facility:

2.

Registered address of Registered Vehicle Scrapping Facility, website address and contact details:

3.

Name of the authorised person(s) and full address with e-mail, landline telephone number and mobile
number:

4.

Capacity of Registered Vehicle Scrapping Facility in terms of no. of vehicles per annum:

5.

Details of numbers of vehicles received and scrapped during the financial year of which the return is being
filed:

<!-- page 14 -->

34

THE GAZETTE OF INDIA : EXTRAORDINARY
SI Type
No.

No. of End-of-Life
vehicles received

No. of End-of-Life
vehicles scrapped

(3)

(4)

(1)
(2)
1 2 Wheeler
(nontransport)
2 2 Wheeler
(transport)
3

4
5

6

[PART II—SEC. 3(ii)]

Total weight of the Total weight of steel
vehicles scrapped
scrap generated

(5)

(6)

3 Wheeler
(nontransport)
3 Wheeler
(transport)
4 Wheeler
(nontransport)
4 Wheeler
(transport)

6.

Details and number of Extended Producer Responsibility certificates generated and exchanged:

7.

Details of the recovered and recyclable or refurbishable materials sent to the registered recycler or refurbisher
including that of recycled or refurbished at Registered Vehicle Scrapping Facility during the financial year of
which the return is being filed:

Serial
Particulars
Quantity
Number
(1)
(2)
(3)
1
Recovered waste tyres sent to the registered
recyclers/refurbishers
2
Recovered e-waste sent to the registered
recyclers/refurbishers
3
Recovered battery waste sent to the registered
recyclers/refurbishers
4
Recovered plastic waste sent to the registered
recyclers/refurbishers
5
Recovered used oil sent to the registered
recyclers/refurbishers
6
Other recovered/recycled/refurbished materials
8.

Name(s) of registered
recycler(s)/refurbisher(s)
(4)

Details of the hazardous and non-recyclable/non-refurbishable materials sent to Common Hazardous Waste
Treatment, Storage and Disposal Facility during the financial year of which the return is being filed:

Particulars

(1)
Recovered hazardous materials

Details with
quantity
(2)

Name(s) of registered Common Hazardous
Waste Treatment, Storage and Disposal
Facility
(3)

<!-- page 15 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण
FORM 4
[See rule 10(1)]
APPLICATION FOR REGISTRATION BY A PRODUCER
[under the Environment Protection (End-of-Life Vehicles) Rules, 2025]

1

Name of producer

2

Registered address of producer, website
address and contact details

3

Name of the authorised person and full
address with e-mail, landline telephone
number and mobile number

4

GST No.

5

TIN No.

6.

Details of vehicles manufactured

Place:
Date:
Signature of the authorised person

FORM 5
[see rule 10(2)]
BY REGISTERED VEHICLE SCRAPPING FACILITY
[under the Environment Protection (End-of-Life Vehicles) Rules, 2025]
1.

Name of the Registered Vehicle Scrapping Facility

2.

Registered address and website address

3.

Phone No. (landline and mobile)

4.

Email ID

5.

Authorised person(s) name

6.

Authorised person(s) email ID

7.

Authorised

8.

GST Number

9.

Consent Validity

person(s) mobile number

a.

Under the Air (Prevention and Control of
Pollution) Act, 1981, valid up to -----

b.

Under the Water (Prevention And Control
Of Pollution) Act, 1974, valid up to ---

10.

Validity of authorisation under rule 6 of the Hazardous Valid up to -----------Wastes (Management and Handling) Rules, 2016

11.

Validity of certification of registration with District Valid up to -------------Industries Centre

35

<!-- page 16 -->

36

THE GAZETTE OF INDIA : EXTRAORDINARY

12.

Details of the categories of waste recycled/refurbished
in the unit/sent to registered entities for reuse,
recycling and refurbishing

13.

Capacity of the Registered Vehicle Scrapping Facility
in no. of vehicles per annum

[PART II—SEC. 3(ii)]

a.

Installed

b.

Operating (details of last three years)

Place:
Date:
Signature of the authorised person
FORM 6
[see rule 10(2)]
BY BULK CONSUMER
[under the Environment Protection (End-of-Life Vehicles) Rules, 2025]
1.

Name of the organisation

2.

Registered address and website address

3.

Phone No.

4.

Email ID

5.

Authorised person(s) name

6.

Authorised person(s) email ID

7.

Authorised

8.

Details of notification in regard to establishment of State
Transport Undertaking under the Road Transport
Corporation Act, 1950 or registration and its validity under
Companies Act, 2013, as applicable (enclose a copy)

9.

Number and details of vehicles registered or in the possession
of the said organisation

person(s) mobile number

Type of
Vehicle

2
Wheeler

3
Wheeler

4
Wheeler

Transport
Nontransport
Total
Grand
total

Place:
Date:
Signature of the authorised person

<!-- page 17 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

37

FORM 7
[see rule 10(3)]
FORMAT FOR CERTIFICATE OF REGISTRATION OF PRODUCER
CENTRAL POLLUTION CONTROL BOARD
CERTIFICATE OF REGISTRATION OF PRODUCER
[under the Environment Protection (End-of-Life Vehicles) Rules, 2025]
Ref.: Your application number for registration

Date:

Registration No.: ……………….
M/s--------------------------- is hereby granted one-time registration as producer of End-of-Life vehicles in respect of
End-of-Life vehicles as per the provisions of Environment Protection (End-of-Life Vehicles) Rules, 2025. Any
violation of the provisions of the Environment Protection (End-of-Life Vehicles) Rules, 2025 will attract the penal
provision of the Environment (Protection) Act, 1986 (29 of 1986).
(Member Secretary)
Central Pollution Control Board
Date:
Place:

FORM 8
[see rule 10 (3)]
FORMAT FOR REGISTRATION OF REGISTERED VEHICLE SCRAPPING FACILITY OR BULK
CONSUMER
STATE POLLUTION CONTROL BOARD
CERTIFICATE OF REGISTRATION OF REGISTERED VEHICLE SCRAPPING FACILITY OR BULK
CONSUMER
[under the Environment Protection (End-of-Life Vehicles) Rules, 2025]

Ref.: Your application number for registration
Date:
Registration No.: ……………….
M/s ------------------------ is hereby granted one-time registration for Registered Vehicle Scrapping Facility or bulk
consumer in respect of End-of-Life vehicles as per the provisions of Environment Protection (End-of-Life Vehicles)
Rules, 2025. Any violation of the provisions of the Environment Protection (End-of-Life Vehicles) Rules, 2025 will
attract the penal provision of the Environment (Protection) Act, 1986 (29 of 1986).
(Member Secretary)
State Pollution Control Board
Date:
Place:
[F. No. 23/55/2021-HSM]
VED PRAKASH MISHRA, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
