---
doc_id: "a3cfaefc0d8bd1a5"
source_url: "https://pspcl.in/admin/Tenders/DraftTransferPolicytobeuploaded.pdf"
ministry: "Punjab State Power Corporation Limited (PSPCL), Punjab"
title: "ਪਾਵਰਕਾਮ (PSPCL) ਤੋਂ ਟ੍ਰਾਂਸਕੋ (PSTCL) ਵਿੱਚ ਅਧਿਕਾਰੀਆਂ/ਕਰਮਚਾਰੀਆਂ ਦੀ ਟਰਾਂਸਫਰ ਅਤੇ ਪੱਕੇ ਤੋਰ ਤੇ absorption ਲਈ “Transfer Scheme for Punjab State Electricity Board” ਅਧੀਨ ਅਤੇ ਮਾਨਯੋਗ ਪੰਜਾਬ ਅਤੇ ਹਰਿਆਣਾ ਹਾਈ ਕੋਰਟ ਦੁਆਰਾ CWP-12018-2025 ਤੇ ਕੁਨੈਕਟੇਡ ਕੇਸਾਂ ਵਿੱਚ ਮਿਤੀ 22.12.2025 ਨੂੰ ਕੀਤੇ ਗਏ ਹੁਕਮਾਂ ਦੇ ਸਨਮੁੱਖ ਪਾਲਿਸੀ ਸਬੰਧੀ।"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "374c6ab1e93f32ce"
---

<!-- page 1 -->

GOVERNMENT OF PUNJAB
DEPARTMENT OF POWER
(ENERGY BRANCH)
Draft Notification
Government of Punjab, Department of Power (Energy Branch) vide Notification No.
ENRG/11/152/2025-EV3/2707-2716, dated 23.10.2025 has constituted a Committee
under Clause 6(12) of the “Punjab Power Sector Reforms Transfer Scheme, 2010” issued
vide Notification No. 1/9/08/EB(PR)/196, dated 16.04.2010 to finalize the transfer of
personnel from Powercom to Transco and permanent absorption of such personnel in
Transco under the terms and conditions mentioned in the said scheme.
2.
As per orders passed by Hon’ble Punjab & Haryana High Court on 22.12.2025 in
CWP-12018-2025 and recommendations/minutes of meeting received from the Committee
on 01.01.2026, following policy is framed for the above said purpose:A.

Eligibility for Permanent Absorption:
a) Any officer/official of PSPCL who is presently working in PSTCL on secondment
and has completed one year of secondment period in PSTCL at any post,
whether continuous or in parts, at the time of notification of this Policy, shall be
eligible to exercise a one-time option for permanent absorption in PSTCL within
a period of one month from the date of notification of the policy.
b) Any officer/official of PSPCL who is presently working in PSTCL on secondment
who has not yet completed one year of service in PSTCL, shall be eligible to
exercise a one-time option for permanent absorption in PSTCL within a period
of one month of his/her becoming eligible. This option is only available to the
PSPCL employees working in PSTCL at the time of notification of this scheme.
c) Upon expiry of the option period, the service records of officers/officials who
have opted for absorption shall stand transferred to PSTCL. Once the option is
exercised, it shall not be revoked.
d) The employees of PSPCL who do not exercise this option shall continue to
remain on deputation to PSTCL as per organization requirement for a minimum
period of one year.

B.

Impact on Promotions and Safeguards
The absorption of PSPCL officers/officials shall not adversely affect the promotional
prospects of regular PSTCL cadre employees. All posts of PSTCL will be fully
available for promotion to PSTCL cadres employes. In case any PSPCL employee who
has opted for absorption in PSTCL, specific post will be created in his/her cadre or
his/her promotion cadre as ex-cadre post, if required, as a measure personal to
him/her by upgrading or downgrading a vacant post so that promotional avenue of
any PSTCL employee may not get blocked.
Example-1:- The total cadre strength for Sr. XEN in PSTCL is 88 posts and presently
21 Sr. XEN of PSPCL are on secondment to PSTCL, 63 PSTCL cadre officer are
working and 04 posts are vacant. In case, 10 AEEs of PSTCL cadre become eligible in
the coming months for promotion to Sr. XEN they may get promoted if eligible and
corresponding number of PSPCL Sr. XEN will be adjusted by upgrading same
number of posts of AEEs of PSTCL.
Example-2:- In case 10 Sr. XEN of PSPCL opt for absorption into PSTCL and 04
become eligible for promotion to SE in coming years, they may be promoted as SE by
creating ex-cadre posts (by upgrading same number of posts)

<!-- page 2 -->

This scheme may be initially published in PSTCL/PSPCL website for getting
objections/suggestions, if any, from all stakeholders within a period of 15 days. The
scheme will be compulsorily circulated to all the petitioners of six number CWPs.
Thereafter, the committee will deliberate the objections / suggestions if any, and will
recommend a final draft. The objections/suggestions, if any, shall be received in the
office of CE/HR of PSPCL.
This safeguard is considered essential to prevent future litigation, maintain parity
and industrial harmony and ensure compliance with the Tripartite Agreement and
the Punjab Power Sector Reforms Transfer Scheme, 2010.

Dated: Chandigarh
the 12th January, 2026

Sd/DR. BASANT GARG,
Secretary to Government of Punjab,
Department of Power.
