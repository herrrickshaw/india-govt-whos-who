---
doc_id: "7bd63afaa36d20ec"
source_url: "https://punjabmedicalcouncil.in/pmc/wp-content/uploads/2021/11/1632611325add-issueNotification-Regarding-Election-of-Punjab-Medical-Council-.pdf"
ministry: "Punjab Medical Council, Punjab"
title: "Elected Member of Punjab Medical Council"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "728f0da18a26162b"
---

<!-- page 1 -->

GOVERNMENT OF PUNJAB
DEPARTMENT OF MEDICAL EDUCATION & RESEARCH
Room No. 415, 4th Floor, Punjab Civil Secretariat-2, Sector-9, Chandigarh
(HEALTH - Ill BRANCH)
NOTIFICATION
No. 6/27/2016-3MER3/ 6056

Dated, Chandigarh the;12/09/2018

Subject:- Regarding election of members of The Punjab Medical
Council under Clause (1) (c) of section 5 of The Punjab
Medical Registration Act, 1916 & The Punjab Medical
Registration (Amendment) Act, 2010

In exercise of the powers conferred by Clause (1) (c) of section 5
of The Punjab Medical Registration Act, 1916 & The Punjab Medical
Registration (Amendment) Act, 2010, the Governor of Punjab is pleased to
elect the following members of the Punjab Medical Council:Sr.No.
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.

Name
Dr Gurpreet Singh Gill
Dr. Gurmej Singh Gill @ Gurmej Singh
Dr. Jasmine Kaur
Dr. Surinder Pal Singh
Dr. Vijay Kumar
Dr. Girish Sahni
Dr. Karamvir Goyal
Dr. Amarbir Singh
Dr. Pritpal Singh
Dr. Janak Raj Singla

Regn. No.
35745
17436
28920
21105
27767
27223
22333
23442
26568
26845

2.

Their appointment shall be subject to provisions of The Punjab Medical
Registration Act, 1916 & The Punjab Medical Registration
(Amendment) Act, 2010 and they shall continue the office as a
pleasure of State Government.

3.

Their continuation as a member of the Council shall be subject to such
terms and conditions as may be prescribed from time to time.

4.

During their tenure as a member they will not indulge in any act which
may be detrimental to the interest of Council and State Government.

5.

There must not be anything adverse against these members on the
date of taking over as member of Council.

Dated, Chandigarh
the : I (-09-0,90q

SATISH CHANDRA, IAS
Additional Chief Secretary, Government of Punjab,
Deptt. of Medical Education & Research.

Endst. No. 6/27/2016-3MER-III/ 6057
Dated,Chandigarh,the:12/09/2018
A copy alongwith spare copy of is forwarded to the Controller,
Printing and Stationary Department, Punjab, Chandigarh with the request that
this notification may please be got published in the next issue of the Punjab

<!-- page 2 -->

Government Gazette (Extra-ordinary) and one hundred copies of the same
(without endorsement) supplied to this department for official ule.
P,..-r-orej I r(
(Punam Bhardwaj)
Under Secretary Medical education & Research
Endst. No. 6/27/2016-3MER-I11/6058-63
Dated, Chandigarh, the: 12/09/2018
A copy is forwarded to the following for information & necessary
action:1.
The Secretary to the Government of India, Ministry of Health & Family
Welfare, Nirman Bhawan, New Delhi.
2.
The Secretary, Medical Council of India, Pocket- 14 , Sector
8,
Dwarka Phase -1, New Delhi — 110077.
3.
Director, Research & Medical Education, Punjab, Chandigarh.
4.
Director, Health & Family Welfare, Punjab, Chandigarh.
5.
Registrar, Punjab Medical Council, Chandigarh.
6.
All concerned members.
uv-n_.9-mm
rL 9 I
(Punam Bhardwaj)
Under Secretary Medical Education & Research
Internal Distributions :
1 PS/MERM
2. PS/ACMSMER
3. SSS/USMER
