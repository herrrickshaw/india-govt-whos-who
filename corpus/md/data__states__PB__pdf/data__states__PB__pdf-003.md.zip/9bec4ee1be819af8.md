---
doc_id: "9bec4ee1be819af8"
source_url: "https://www.peda.gov.in/media/NIT204.pdf"
ministry: "Punjab Energy Development Agencies (PEDA), Punjab"
title: "E-Tender notice no. PEDA/2026-27/05"
date: ""
pages: 1
method: "tesseract:pan+eng"
script: "LATIN"
needs_ocr: false
sha1: "781ecaaedcbd8c0e"
---

<!-- page 1 -->

Government of Punjab ; 3 i
: |
Punjab Enorgy Development Agency ਤਰ 4
E-TENDER NOTICE NO. PEDA/2026-27/,.09....... |
Punjab Energy Development Agency (PEDA) Invites online bids. from prospective ce 4
bidders regarding Rate Contract for Design, Supply, Installation & Commissioning: `: 4
along with 7 years comprehensive warranty & 7 years Annual Maintenance of 12811 oe]
LED Based 3,00,000 nos. Solar Street Lighting Systems in the stale of Punjab with |
scope of work as mentioned in DNIT
Closing Date & Time for Submission of e-bids - 11.05.2026 upto 4.00 PM st
Date & Time for Opening of Technical e-bids - 12.05.2026 al 11.00 AM SA
For more details, logon to - https Heproc.punjab.gov.in/
Note: : 3
ਨ 1 Corrigendunv/ Addendum/ Corrections, if any % 6੬ published on the above
€ mentioned website and no separate notices shall be issued ;
2. PEDA reserve the right to accept or reject any or all the tenders without ;
assigning any reason thereof. (੬੨%< |
੍ ਰਾ DIRECTOR
