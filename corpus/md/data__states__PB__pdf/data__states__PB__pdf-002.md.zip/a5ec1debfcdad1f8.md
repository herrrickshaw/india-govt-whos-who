---
doc_id: "a5ec1debfcdad1f8"
source_url: "https://www.pepsurtc.com/wp-content/uploads/2026/07/Tendernotice_1-8-1.pdf"
ministry: "Pepsu Road Transport Corporation, Patiala, Punjab"
title: "view download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "38dbe34d3ecb5637"
---

<!-- page 1 -->

e-TENDER NOTICE
(For uploading on website only)
e-Tender No.: PRTC/XEN/2K26/95

Dated: 08-07-2026

Online e-Tenders on “Percentage Rate Basis” based on BOQ/DNIT amount are
hereby invited for the work mentioned below, from eligible Labour & Construction Cooperative Societies and contractors enlisted with PWD (B&R), PUDA, Central/State
Government Departments or PSUs for the appropriate class and category.
Sr.
No.
1

Name of Work

Estimated
Cost

EMD

Providing and Laying Plain Cement
Concrete Pavement on Main
Loading Platform, Entry & Exist for ₹ 240.70 lakh ₹ 4.81 lakh
Buses at PRTC Bus Stand Talwandi
Sabo
Note:- Actual amount will be as per loaded DNIT/ BOQ.

Bid Submission Start
Date & Time
13-07-2026
11:30 AM

Bid Submission
End Date & Time
03-08-2026
05:00 PM

Time
Limit
6 Months

Technical Bid Opening
Date, Time & Place
04-08-2026, 11:30 AM
PRTC Head Office, Nabha Road, Patiala

The Detailed Notice Inviting Tender (DNIT)/ Bill of Quantities (BOQ) can be
viewed/downloaded from the website https://eproc.punjab.gov.in.
For participating in the above e-Tender, interested Bidders/Firms shall get
themselves registered on https://eproc.punjab.gov.in and obtain a user ID & password.
A Class-3 Digital Signature Certificate (DSC) is mandatory to participate in the eTendering process. For any clarification/difficulty regarding the e-Tendering process,
please contact the ITI Help Desk at 0172-2970263, 0172-2970284 (Monday to Friday) &
+91 6284884511 (Saturday/Sunday). EMD, Tender Fee & Tender Processing Fee shall be
paid through e-Payment mode only. No other mode of payment shall be accepted.
The Managing Director, PRTC reserves the right to accept or reject any or all
bids, either in whole or in part, without assigning any reason whatsoever. Any
Corrigendum/Addendum issued in respect of this e-Tender shall be published only on
https://eproc.punjab.gov.in.
---Sd/--Executive Engineer (CW),
P.R.T.C.
Patiala
Signature Not
Verified
Digitally signed by Jatinder Pal Singh Grewal
Date: 2026.07.14 08:51:17 IST
Location: Punjab-PB
