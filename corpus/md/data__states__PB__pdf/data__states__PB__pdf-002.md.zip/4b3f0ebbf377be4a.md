---
doc_id: "4b3f0ebbf377be4a"
source_url: "https://decc.punjab.gov.in/wp-content/uploads/2019/08/Order-dated-31.08.2018.pdf"
ministry: "Directorate of Environment and Climate Change, Punjab"
title: "Order dated 31.08.2018"
date: ""
pages: 20
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "83d09b454fe27344"
---

<!-- page 1 -->

Revised Order
Corrected on: 31.08.2018
BEFORE THE NATIONAL GREEN TRIBUNAL
PRINCIPAL BENCH
NEW DELHI
O.A. No. 606/2018
In the matter of:
Compliance of Municipal Solid Waste Management Rules, 2016
ORDER
1. Municipal Solid Waste (MSW) remains one of the most serious
challenges for environment protection. Deficiencies in proper
management of solid waste have resulted in outbreak of
serious diseases in the past and have such potential in future.
The issue has been highlighted and considered at all
concerned levels and has also been subject matter of decisions
of Courts.1
2. This Tribunal also considered the matter pursuant to order of
the Hon’ble Supreme Court transferring the pending Writ
Petition to this Tribunal.2

3. The revised Rules3 have been framed in the year 2016 but
implementation remains a problem. Under the Rules, 2016 a
report is compiled every year. In the recent annual report4
prepared in April, 2018, serious deficiencies have been found
1Dr. B.L Wadhera vs. Union of India [1996(2) SCC 594], Almitra H. Patel and Ors. vs. Union of India & Ors.

(1998) 2 SCC 416, Almitra H. Patel and Anr. vs. Union of India (2004) 13 SCC 538, Municipal Corporation
Vs. BVG India Ltd (2018) 5 SCC 462
2Order dated 22.12.2016 in O.A. No. 199 of 2014 in the matter of Mrs. Almitra H. Patel and Anr. vs. Union
of India & Ors.
3Solid Waste Management Rules, 2016 replacing earlier Rules.
4Consolidated Annual Report for the year 2016-2017 prepared by CPCB.
http://cpcb.nic.in/openpdffile.php?id=UmVwb3J0RmlsZXMvNjE0XzE1MjYzMDE0ODhfbWVkaWFwaG90
bzEyMzg3LnBkZg==

1

<!-- page 2 -->

in the reports of most of the States, inspite of the Rules being
in operation for the last two years.
4. In the order of this Tribunal dated 22.12.20165, directions
were issued for implementation of the Rules, 2016. Direction
was issued for the action plan to be prepared in terms of the
Rules, 2016 within four weeks. Action under Rule 6(b) and 15
of the Rules, 2016 was directed to be taken by January, 2017
which was to be complied by 01.07.2017. It was directed that
failure would result in action under Section 15 of the
Environment (Protection) Act, 1986 i.e. prosecution of the
concerned authority. Directions were also issued for creating
buffer zone around the plants and landfill sites. Further
directions were to comply with the various other provisions of
the Rules, 2016.

5. The State Level Advisory Bodies envisaged by the Rules were
to function as Monitoring Committees (Direction No. 27 in the
Tribunal’s

order

Environment,

dated

Forest

22.12.2016).6

and

Climate

The

Ministry

of

Change

has

the

responsibility to monitor the implementation.7 The Ministry of
Housing and Urban Affairs (earlier known as the Ministry of
Urban Development, hereinafter referred to as ‘MoHUA’) is to
coordinate with States and Union Territories.8 There are duties
of other Ministries and authorities.9 The matter of overseeing
5Supra note 2, O.A. No. 199 of 2014 Mrs. Almitra H. Patel and Anr. vs. Union of India & Ors.
6

supra note 2

7Rule 5, Solid Waste Management Rules, 2016
8Rule 6, Solid Waste Management Rules, 2016

9Rule 7 to 16, Solid Waste Management Rules, 2016

2

<!-- page 3 -->

compliance of various directions remains pending.

This

Tribunal is faced with frequent grievances against noncompliance of the statutory rules with the photographic
evidence of heaps of garbage lying on the streets showing utter
failure on the part of the municipal bodies in performing their
duties.

While coercive measures like prosecution and fixing

accountability of the authorities for their failure is a different
issue, the Tribunal considered it proper to have interaction
with the stakeholders to evolve a mechanism for execution of
orders already passed by the Tribunal particularly the order
dated 22.12.2016.10
6. On 23-07-2018, a meeting was organized through CPCB
wherein the experts gave their presentations of successful
models adopted for MSW management at some places. It was
then decided that after the said models are circulated to the
States and Union Territories, an interaction be held with them
through video conference.

7. Following issues were circulated to the States and UTs to
facilitate interaction:
i) Whether State-wise Action Plan with timelines and
budgetary support/provision for management of MSW
has been prepared?
ii) Whether each city/town/urban local body is covered
under the said Plan and individual Action Plan has
timelines with budgetary provisions?

10

supra note 2.

3

<!-- page 4 -->

iii) What time has been fixed to completely comply with the
provisions of the Rules, 2016?
iv) What are the main constraints of non-compliance of
Rules, 2016?
8. Meetings were held with all the States and Union Territories
on 02.08.2018, 07.08.2018, 08.08.2018, 13.08.2018 and
20.08.2018 on the aforesaid matter. At the conclusion of the
interaction with the States and Union Territories, it was
decided and declared that certain binding directions need to
be issued by the Tribunal by forming Apex Level, Regional
Level and State Level Committees to oversee the steps taken
for implementation of the Rules, 2016

and the directions

issued by the Tribunal and give a report to this Tribunal at the
end of the quarter.

The Committees may have interaction

individually with the Statutory Authorities and the Urban
Local Bodies. Accordingly, we are recording this order. The
Registry may register these proceedings as a fresh Original
Application.
9. Interaction showed that with few exceptions, the States and
Union Territories are no where near compliance of the Rules,
2016 inspite of the directions issued by this Tribunal. Even
action plans have yet not been prepared in all the States more
than two years after the Rules, 2016 have been in operation
and in spite of binding directions in the Judgment of this
Tribunal vide order dated 22.12.2016.11

11

supra note 2

4

<!-- page 5 -->

10. Accordingly,

the

Chairman,

CPCB

present

during

the

interaction suggested that such action plans may now be
submitted latest by 31.10.2018, after looking into the
successful models which may be improvised as per the local
needs. Action plans be executed in the outer deadline of
31.12.2019. The same should be overseen by the Principal
Secretaries of Urban Development and Rural Development.
There should be periodic monitoring at least once in three
months.
11. The MoHUA expressed the view that some of the handicaps
put forward by some of the States and the Union Territories
are non-existent.

The States and Union Territories do not

appear to have considered the guidelines12/ advisories13/
protocols14 etc. circulated to them by the said Ministry. The
same are also available on the website of the Ministry.
12. It is observed that even as per some of proposed plans only 50
to 75 % of the waste produced will be managed by the wasteto-energy plants or waste-to-compost plants or through
integrated waste management plants. The rest 25-50% of the
current waste will continue to be dumped in the existing
dumping grounds or in the new dumping sites. Most of the
States have not taken into account the incremental growth in
the waste generation in future in the cities which are growing
12

http://164.100.228.143:8080/sbm/content/writereaddata/Bulk%20Waste%20Generator%20Book.pdf

13http://164.100.228.143:8080/sbm/content/writereaddata/Advisory%20on%20decentralised%20compos

ting.pdf ,
http://164.100.228.143:8080/sbm/content/writereaddata/Waste%20to%20Wealth_2%20Oct.pdf
14http://164.100.228.143:8080/sbm/content/writereaddata/Star%20Rating%20for%20Garbage%20Free%
20Cities%20-%20Flyer.pdf

5

<!-- page 6 -->

exponentially. This will only add to the waste dumps which
have already assumed alarming proportions. Moreover, most
of the states have no plans to deal with the legacy waste which
have already become virtual mountains in some of the cities
causing environmental disasters. Only plans which some of
the States have made is to cap the legacy waste except for the
State of Goa (which has an integrated waste processing and
management facility), which may be contrary to the Solid
Waste Management Rules, 2016. None of the states have even
considered bio-mining, as specified in clause J of Schedule I,
as one of the options. What is required to be done is to see if
some of the successful models like Indore, Ambikapur, Goa
and Udupi can be replicated in their States, if necessary with
few modifications and adoption to suit their conditions.
Capping of waste directly without adhering to clause J of
Schedule I to the Solid Waste Management Rules, 2016 is a
matter of grave concern, having regard to the serious pollution
potential of legacy waste in the form of leachate and emissions
of harmful gases if not treated scientifically. All the States and
Union Territories across the board ought to deal with the
legacy waste in accordance with the procedure laid down in
clause J of Schedule I to the Solid Waste Management Rules,
2016. For convenience, the said clause is reproduced below:
“J. Closure and Rehabilitation of Old DumpsSolid waste dumps which have reached their full
capacity or those which will not receive additional
waste after setting up of new and properly designed

6

<!-- page 7 -->

landfills should be closed and rehabilitated by
examining the following options:
(i)

Reduction of waste by bio mining and waste
processing followed by placement of residues in new
landfills or capping as in (ii) below.

(ii) Capping with solid waste cover or solid waste cover
enhanced with geomembrane to enable collection and
flaring / utilisation of greenhouse gases.
(iii)

Capping as in (ii) above with additional measures (in
alluvial and other coarse grained soils) such as cutoff walls and extraction wells for pumping and
treating contaminated ground water.

(iv)

Any other method suitable for reducing environmental
impact to acceptable level.

13. It has also been observed that most of the States have no
plans to deal with solid wastes in rural areas and hilly terrains
effectively. We know that many rural centres are rapidly
turning into urban conglomerates and if their solid wastes are
not managed urgently we would be inviting several diseases
with disastrous consequences. In these areas the most
convenient method adopted is to burn or dump the waste
haphazardly and throw them on the hill slopes.

What is

required to be done is to come out with integrated plans on
scientific lines to manage the solid waste which may vary from
place to place. For this purpose, it is necessary that a detailed
study and consultation with the experts is initiated in right
earnest without further delay. It is absolutely mandatory that
every state follows Solid Waste Management Rules, 2016 in
letter and spirit.

7

<!-- page 8 -->

14. Tabular chart furnished by the MoHUA suggesting solution to the
problems presented during the interactions is as follows:
S.No. Problems faced
by the
States/Union
Territories
1. Handling mixed
waste

2.

Land Acquisition

3.

Financial
constraints

4.

Lack of capacity

5.

Non-Recyclable
Dry Waste
Processing

Solution suggested by the MoHUA

Segregate waste at source and
recover/recycle to the extent feasible
at different stages. Preferred options:
 50%
wet
waste
compost/
biomethanization
 30% Dry waste– Recycling
 15% Dry waste– Combustible
 5% Inert waste- Landfill
Decentralized processing should be
encouraged coupled with source
segregation
 Collect user fee
 Levy penalty for polluters
 Bulk Waste Generators rules be
complied
 Hire services of experts
 Take help of MoHUA/CPCB
 Maximum of non recyclable dry
waste should be used in Cement
Plants.
 Low value plastic should be used in
road construction.

15. Though, we find that the Rules, 2016 provide for review and
monitoring mechanism as well as time lines and accountability
of the different authorities, the same has not been worked
satisfactorily in most of the places. The Tribunal directed
compliance of the Rules, 2016 but on ground level the problem
continues. Without in any manner disturbing the statutory
mechanism, it is necessary to lay down a Tribunal monitored
mechanism in exercise of its authority to execute the orders of
the Tribunal.

8

<!-- page 9 -->

16. The MoHUA has suggested need for Performance Audit as
follows:
“Performance Audit
 Central
Public Health and Environmental Engineering
organization (CPHEEO), technical wing of MoHUA, can extend
technical support in performance audit. CPHEEO can also be a
member of the core technical committee constituted by NGT for
supervising such performance audits.
 Initially performance audit to be conducted for 500 ULBs with
population of 1 lakh and above.
 Fees/expenses to be raised by ULBs through various means
including levying a surcharge/cess over property tax.”
The parameters suggested are as follows:
Key
Parameters/
Indicators

1

2

3

Description of Parameters/Indicators
for physical evaluation
Door to door collection of segregated
solid waste from all households including
slums
and
informal
settlements,
Door to Door
commercial, institutional and other nonCollection
residential premises.
Transportation in covered vehicles to
processing or disposal facilities
Segregation of waste by households into
Source
Biodegradable,
non-biodegradable,
Segregation
domestic hazardous.
 Installation of Twin-bin/ segregated
litter bins in commercial & public
areas at every 50-100 meters.
Litter Bins &
 Installation of Waste storage bins in
Waste Storage
strategic locations across the city, as
Bins
per requirement (Unless Binless)
 Elimination of Garbage Vulnerable
Points .
Installation of Transfer Stations instead
of secondary storage bins in cities with
population above 5 lakhs.

4

Transfer
Stations

5

 Compartmentalization of vehicles for
the collection of different fractions of
waste.
Separate
 Use of GPS in collection and
transportation
transportation vehicles to be made
mandatory at least in cities with
population above 5 lakh along with
9

<!-- page 10 -->

6

7

8

9
10
11

12

13

14

15

16
17

the publication of route map.
 All public and commercial areas to
Public
have twice daily sweeping, including
Sweeping
night sweeping and residential areas
to have daily sweeping.
Waste
 Separate
space
for
segregation,
Processing
storage, decentralised processing of
 Wet Waste
solid waste to be demarcated
 Dry Waste
 Establishing
systems
for
home/decentralised and centralised
 MRF
composting
Facility
 Setting up of MRF Facilities.
 Setting up common or regional
sanitary landfills by all local bodies for
Scientific
the disposal of permitted waste under
Landfill
the rules
 Systems for the treatment of legacy
waste to be established.
Ensure separate storage, collection and
C&D Waste
transportation of construction and
demolition wastes.
Implementation of ban on plastics below
Plastic Waste <50 microns thickness and single use
plastics.
Bulk Waste
Bulk waste generators to set up
Generators
decentralized waste processing facilities
(BWGs)
as per SWM Rules, 2016.
Mandatory arrangements have to be
made by cement plants to collect and use
RDF
RDF, from the RDF plants, located within
200 kms.
Preventing
Installation of suitable mechanisms such
solid waste
as screen mesh, grill, nets, etc. in water
from entering bodies such as nallahs, drains, to arrest
into water
solid waste from entering into water
bodies
bodies.
Waste Generators paying user fee for
User Fees
solid waste management, as specified in
the bye-laws of the local bodies.
Prescribe criteria for levying of spot fine
for persons who litters or fails to comply
Penalty
with the provisions of these rules and
provision
delegate powers to officers or local bodies
to levy spot fines as per the byelaws
framed.
Frame
bye-laws
incorporating
the
Notification of
provisions of MSW Rules, 2016 and
Bye Laws
ensuring timely implementation.
Citizen
Grievance
Resolution of complaints on Swachhata
Redressal
App within SLA.

10

<!-- page 11 -->

18

Monitoring
mechanism

States/ULBs to update month wise
targets/action plans on the online MIS.

17. We accordingly, propose to direct constitution of an Apex
Monitoring Committee, Regional Monitoring Committees and
State Level Committees to oversee the steps to be taken to give
effect to the directions of this Tribunal so that if necessary,
further action can be taken in the matter.

18. The role of the Apex Monitoring Committee will be to interact
with the concerned Ministries and the Regional Monitoring
Committees. The Apex Monitoring Committee may formulate
guidelines/directions which may be useful to the Regional
Monitoring Committees and the States/Union Territories. The
Apex Monitoring Committee may meet preferably every month
to take stock of the situation. Outstation members/invitees
may participate by video conferencing unless their presence is
considered necessary.

The Apex Monitoring Committee may

have meeting with all the Regional Monitoring Committees at
least once in a month for two days to take stock of the progress
and fix new targets. The report may be given to the Tribunal by
e-mail once in a quarter. The Apex Monitoring Committee may
have its website for dissemination of such information as may
be necessary and also to enable public participation. The
Committee may function for a period of one year subject to any
further order.
The constitution of the Apex Monitoring Committee will be as
follows:

11

<!-- page 12 -->

1.

Hon’ble Mr. Justice D.K. Jain,
Former Judge, Supreme Court of
India, Former President, NCDRC,
Former
Chairman,
Law
Commission of India.
Chairman,
Central
Pollution
Control Board
Jt. Secretary of Ministry of
Environment, Forest & CC
Jt. Secretary & Mission Director,
Swachh Bharat Mission,
Ministry of Housing & Urban
Affairs, Govt. of India

2.
3.
4.

Chairman

Member
Member
Member Secretary

The Apex Monitoring Committee will have the following
Special Invitees:
1.

Principal Secretary, Urban Development, Govt. of Goa

2.

Ms. Ritu Sain, IAS
Addl. Resident Commissioner, Govt. of Chattisgarh,
Chattisgarh

3.

Dr. Asad Wari, Team Leader, SBM, Indore Municipal
Corporation, Indore, M.P

4.

Shri C. Srinivasan,
Vellore, TN, Project Director-SLRM
The MoHUA will provide all logistic and secretarial

support

along

with

functional

Secretariat

to

the

Apex

Monitoring Committee. The Committee may operate from
Delhi.

The Apex Monitoring Committee can also use the

conference facilities available with the National Green Tribunal
(Principal Bench). The Chairman and the special invitees who
are either retired or private professionals of the Committee
may be provided remuneration in consultation with them.
19. The Regional Monitoring Committees shall ensure effective
implementation of the Rules, 2016.

12

The Regional Monitoring

<!-- page 13 -->

Committees shall also ensure that mixing of bio-medical waste
with municipal solid waste does not take place and bio- medical
waste and processed in accordance with The Bio-Medical Waste
Management Rules, 2016. The Regional Monitoring Committees
may meet preferably once in every week or longer intervals as
per requirements. Out station members may participate by
video conferencing unless physical presence is required. They
may interact with Apex Monitoring Committee at suitable
intervals. The Regional Monitoring Committees may also have
inter se interaction as and when necessary.
Monitoring

Committees

may

have

The Regional

interactions

with

the

concerned States at regular intervals. The Regional Monitoring
Committees may also consider having their website for the
same purpose with the same objective as the Apex Monitoring
Committee.

The

Regional

Monitoring

Committees

if

feel

appropriate can solicit the service of the Special Invitees of the
Apex Monitoring Committee and others whom they think can
contribute to the cause of monitoring of the Rules, 2016. The
Regional

Monitoring

Committees

may

specially

consider

compliance of the mandate of the Rules, 2016 at or around
railway platform, railway tracks, bus stands or other places
frequented by public. The Ministry of Railway may appoint
Nodal Officers at Central, Zonal or other levels having specific
responsibility of compliance of the Rules, 2016. The Regional
Monitoring Committees may interact with such officers at
appropriate intervals.

The report may be given to the Apex

Monitoring Committee twice in a quarter.
13

Initially, a report

<!-- page 14 -->

may also be sent to the Tribunal by the Regional Monitoring
Committees after three months of their working. The Regional
Monitoring Committees will be paid remuneration and such
logistic

support

Development,

as

required

Government

of

by

Department

Punjab,

Madhya

of

Urban

Pradesh,

Maharashtra, Tamil Nadu and West Bengal for Northern Zone,
Central Zone, Western Zone, South Zone and Eastern Zone
respectively. The States will be entitled to recover proportionate
expenses from the member States and Union Territories in the
respective zones All the States are advised to maintain the
parity with regard to the remuneration of Chairperson of the
Regional Monitoring Committees. The Committees may function
for a period of one year subject to any further order.
20. The constitution of the Regional Monitoring Committees will be
as follows:
North Zone – Chandigarh-Delhi
1.
2.

Mrs. Rajwant Sandhu, IAS,
Chairperson
Former Secretary, GoI & Former Member,
CAT
Principal Secretary of Urban Development, Member
Government of Punjab, Punjab
Secretary

3.

Principal
Secretaries
of
Urban Members
Development of Government of Jammu &
Kashmir, Himachal Pradesh, Haryana,
Uttarakhand, NCT Delhi, Uttar Pradesh,
Union Territory, Chandigarh

4.

Member Secretaries of State PCBs/PCCs Members
of Jammu & Kashmir, Himachal Pradesh,
Haryana, Punjab, Uttarakhand, NCT
Delhi, Uttar Pradesh, Union Territory,
Chandigarh

5

Representative of Central Pollution Control Member
Board (CPCB).

14

<!-- page 15 -->

1.
2.

Eastern Zone-Kolkata
Hon’ble Mr. Justice Jayanta Kumar Chairman
Biswas
Former Judge, Calcutta High Court
Principal
Secretary,
Urban Member
Development, Government of West Secretary
Bengal, Kolkata, West Bengal.

3.

Principal
Secretaries
of
Urban Members
Development of State of Bihar,
Jharkhand,
Odisha,
Arunachal
Pradesh, Assam, Tripura, Manipur,
Meghalaya,
Mizoram,
Nagaland,
Sikkim

4.

Member Secretaries of PCBs/PCCs of Members
Bihar, Jharkhand, Odisha, Arunachal
Pradesh, Assam, Tripura, Manipur,
Meghalaya,
Mizoram,
Nagaland,
Sikkim

5.

Representative of CPCB

1.
2.

Member

Western Zone – Mumbai-Pune
Hon’ble Mr. Justice J.P Devadhar
Chairman
Former Judge, Bombay High Court
Principal
Secretary,
Urban Member
Development,
Government
of Secretary
Maharashtra

3.

Principal
Secretaries
of
Urban Members
Development of Govt. of Gujarat, Goa,
Daman & Diu, Dadra and Nagar
Haveli

4.

Member
Secretaries
of
State Members
PCBs/PCCs of Maharashtra, Gujarat,
Goa, Daman & Diu, Dadra and Nagar
Haveli

5.

Representative of Central Pollution Member
Control Board

15

<!-- page 16 -->

1.

Central Zone – Bhopal
Hon’ble Mr. Justice K.K.Trivedi

Chairman

Former Judge, Madhya Pradesh High
Court
2.

Principal
Secretaries
of
Urban Member
Development Government of Madhya Secretary
Pradesh, Bhopal. Madhya Pradesh.

3.

Principal Secretary of Urban Development, Member
Government of Chattisgarh and Rajasthan

4.

Member Secretaries of Madhya Pradesh, Members
Rajasthan and Chattisgarh State Pollution
Control Boards

5.

Representative
Control Board.

of

Central

Pollution Member

Southern Zone-Chennai
1.

2.

Hon’ble Mr. Justice P.Jyothimani
Chairman
Former Judge Madras High Court
Former Judicial Member, NGT, Southern
Bench, Chennai
Principal Secretary, Urban Development, Member
Government of Tamil Nadu
Secretary

3.

Principal
Secretaries
of
Urban Members
Development of Government of Karnataka,
Kerala,
Andhra
Pradesh,
Telangana
Puducherry, Andaman & Nicobar Islands,
Lakshadweep Islands.

4.

Member Secretaries of PCBs/PCCs of Members
Tamil Nadu, Karnataka, Kerala, Andhra
Pradesh, Telangana and Puducherry,
Andaman
&
Nicobar
Islands,
Lakshadweep Islands.

5.

Representative of CPCB

Member

21. There will also be State Level Committees headed by Secretary
of the Urban Development Department with Secretary of the
Environment Department as Members. The representatives

16

<!-- page 17 -->

from the Central Pollution Control Board and State Pollution
Control Boards would assist the State Level Committees. The
State Level Committees may have interactions with the Local
Bodies preferably once in two weeks.

The Local Bodies may

furnish report to the State Committees twice a month.

The

State Committees will take a call on technical and policy issues
in accordance with the Rules, 2016 consistent with directions
of Apex and Regional Monitoring Committees. The Local Bodies
may be required to have suitable nodal officers of particular
level having regard to the nature of work.
Bodies,

committees

headed

by

senior

For bigger Local
officials

may

be

constituted. Public involvement may be encouraged and status
of Municipal Solid Waste be put in public domain. The State
Level Committees may also function for a period of one year
subject to any further order. The report may be given to the
Regional Monitoring Committees on monthly basis.

22. The Tribunal is of the view that instead of every Local Body
individually floating tenders for different services, standards
and technical specifications of available services may be
specified by the Department of Urban Development and
adopted by Local Bodies. Such services may be hired on laid
down standard norms to save time. However, this aspect may
be finally gone into by the Committees.

17

<!-- page 18 -->

23. The Tribunal is also of the view that the best practices may be
compiled including setting up of Control Rooms where citizens
can upload photos of garbage which may be looked into by an
accountable person specified by the Local Bodies at the Local
Level and by State Bodies at the State Level. Such information
may be made available by the States on the website of the
State Committees and if possible on the websites of Local
Bodies also. The mechanism of citizens giving and receiving
information may be considered. The Committees may also
consider, wherever viable, guidelines for using CCTV cameras
already installed or installation of fresh CCTV cameras
wherever necessary at dumping or other suitable sites and
footage of CCTV Cameras may be viewed at regular basis by
suitable authorities.

All garbage collection van may be GPS

enabled to monitor its regular collection and performance
audit may be considered and guidelines laid down.

24. Subject to any further orders of this Tribunal, the Committees
will be at liberty to give directions for execution of orders of this
Tribunal to any authority. The Committees may resume their
work within one month from today. The Apex Monitoring
Committee may furnish quarterly reports of its work to the
Tribunal.

25. The concerned Ministries at the Centre shall render full support
and cooperation to the Apex Monitoring Committee to ensure its
effective functioning.

Similarly, the Chief Secretaries and
18

<!-- page 19 -->

Advisors of each of the States and Union Territories respectively
shall also render such support and cooperation to the Regional
Monitoring Committees.
26. This order will not in any manner affect the directions issued
by the Hon’ble Supreme Court in SMW (C) No(s) 1/ 2015[In Re:
Outrage as Parents End Life After Child’s Dengue] with regard
to garbage disposal in Delhi or otherwise. This order is being
passed only for giving effect to the Rules, 2016 and the preexisting orders of the Tribunal.

27. List the matter after receipt of first such report(s) from the Apex
Monitoring Committee and the Regional Monitoring Committees
for consideration of the reports. It is also ordered that the video
conferencing with all the members of the Apex Monitoring
Committee, Regional Monitoring Committees and stakeholders,
Urban

Development

Department

of

the

States

shall

be

organized once in every six months so as to take stock of the
progress made during the period. Next such video conferencing
would be held on 29th April, 2019.

........................................,CP
Adarsh Kumar Goel

........................................,JM
Dr. Jawad Rahim

........................................,JM
Raghuvendra S. Rathore

19

<!-- page 20 -->

........................................,JM
S.P.Wangdi

........................................,EM
Dr. Satyawan Singh Garbyal

........................................,EM
Dr. Nagin Nanda
Dated: 20.08.2018.

20
