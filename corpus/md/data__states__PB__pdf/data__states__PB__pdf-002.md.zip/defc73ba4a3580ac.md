---
doc_id: "defc73ba4a3580ac"
source_url: "https://pbsports.punjab.gov.in/pdf/application-form-for-appointment-of-outstanding-sports-persons-of-punjab-as-junior-coach-coach-deputy-director.pdf"
ministry: "Department of Sports, Punjab"
title: "Application form for appointment of Outstanding Sports Persons of Punjab as Junior Coach/ Coach./ Deputy Director"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "540ba21ab62d9c11"
---

<!-- page 1 -->

Application form for appointment

ofOutstanding Sports Persons of Punjab
as Junior Coach/ Coach/ Deputy Director

Supporting
Document to be

attached

Name

Date of Birth

Matriculation /
Birth Certificate

Aadhar

Aadhar (Copy)

Domicile

Copy of Domicile

Mobile Phone
Number

E- mail

Sport
Highest
Achievement Level
at which you

Certificate and

Gradation
Certificate

represented

Punjab
Date of Event|
Event

Event Organised
By
Certificates and
Gradation
Certificates

Attach list of upto
your 10 best 10
achievements

Icertify that the particulars given above are correct to the best of my
knowledge and belief

Signature and Name

1
