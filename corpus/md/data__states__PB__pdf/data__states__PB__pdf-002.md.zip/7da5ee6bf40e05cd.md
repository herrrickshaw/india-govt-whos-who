---
doc_id: "7da5ee6bf40e05cd"
source_url: "https://forest.punjab.gov.in/media/documents/Notification_Village_Bhani_Mirza_Khan_1-1.pdf"
ministry: "Forests and Wildlife Preservation Department, Punjab"
title: "ਸੂਚਨਾ - ਭਾਨੀ ਮਿਰਜ਼ਾ ਖਾਨ/498 (ਹੁਸ਼ਿਆਰਪੁਰ)"
date: ""
pages: 5
method: "tesseract:pan+eng"
script: "LATIN"
needs_ocr: false
sha1: "f996ffac820fd1f9"
---

<!-- page 1 -->

GOVERNMENT OF PUNJAB
DEPARTMENT OF FORESTS & WILDLIFE PRESERVATION
(FOREST BRANCH)
NOTIFICATION
No. DFWLP-39/2/2024-FB/ SO S?-
Chandigarh, Dated the 226 “੧੫
In exercise of the powers conferred by Section 29 of Indian Forest Act 1927 and
all other powers enabling him in this behalf, the Governor of Punjab is pleased to declare
the land under the ownership of the Government of Punjab in Village. Bhani Mirza Khan
Hadbast No. 498, Teh. Dasuya, District Hoshiarpur, described in the schedule below to
be "Protected Forest" and that the provisions of Chapter-IV and other Sections,
including Section-68 of the said Act shall be applicable to them:-
SCHEDULE
Tehsil |Village/H.B.] Descriptionof [____&੬੩_ |
No. KhasraNo. | Kanal | Marla |
Hoshiarpur Bhani Mirza
Khan/498
Ea ee
Eee Ee ee
Bae ed ee
ea ee ee |
eee ae
oe ae ee
2//18 18
8 0
Eze Oe ee
ਇਨ | at et | 0
2//21 Bes] OF
Eee a ਉਤ
eee Be ee
Eee Ee
0
31009. es Ce
ਇਟ 1[ i ce [e 87a SEO
En a Be ee
ESE ee ee ee
[1150 EOS Oa
[evapo 0 | 8. el
23.
[020 fs 818 [RO
[2a fds 7 4 ਉਤ
8 oS |
g 0
0
12//9 8 (0
ਤਣ
[spay ੮੪412 One|

<!-- page 2 -->

12//12 8 0
Se Eee Ee
ਦਿ ea
as ee a 0
Erie ee 0
[੨0007 8 Re
Beh eee 8 0
12198 Be
220 ਨ
ਲਿੰਕ ਇਤ ਤੀ
eee pee Eee 0
teas Bae ee
ਭਿੰਨਤਾ ਸਿਤ BO a
[203 1 (੪ 84 ore
| 2 ੭13/(6 21 ee ee
Ea en ਸਤੀ Be
ae ਮੀ 8 0
ae ae ਤਕ ਮਿਨੀ
| 23110 8੨0
[੧4310 2੮84 0
ਇਮ ਤਤ ਤਿਹ ਤਤ ਨੀ
ae eee ee Ee
[2 3/14 S| 8 ee ea
ਇੰਕ 1 ਛਤਰ ome
Eat ines ee ਤਿ0੩
eet ie Eee ee

| [13101 Ser eee
ਇਤਰ ee eel
Eee cies ee 0
ee ee a eee
[੨1404 ee
[੪੪ ee Ee
Ee eee ee
ਗਿ ls ace ਤਤ
[੨4080 6. ਨ
Re oe 8: ਨ ੪0
ee 040
[ ੨੨ 1400 0561 ee |
[ 74006 242 ਨ 8 ਕਿ
alee 1 ee
eae eee

Fs eee Ge ਮਲਸੂ
a 7 ਜਤ ee
[1881੩ ੨0੬੬੬
[੨ 1007. 8੭੭ | Oa
ਇਰਾਨ ਤੀ 0
16

ਵਿ 86੫

<!-- page 3 -->

16//12 3 4
[ਜਤ ਤੀ
Pieper ਬਨ |
eee ee ee
[page ਨ
er ਸ਼ ae ਜਨ ਨ
ਦਿਤੀ eee ਅਨ
[ਟਰ ਤੀ ਐਡ
ਚ ਤੀ
ee |e
ਭਰਨ 777 es. bee
ely ea eee
[= ed bee oe

| (er pre ea
es es
[ਤੀ ਤਾ
aes Be
Cn ae ee ee |
Eo ee ee
i oe
Ec coe ee
ee ee ee
se |
ਇਹਨ es ee
Ba eee ee
at Oe ee ਦਾ
(scam) es | eee
Mi eee
Bey ee |
ਤੀ
aap | ਤਕ 57 2
Bsus
se ee
“1
ਛਲ ee
ਰੀ
En eee
ees ee
he ee ee
a a ee ee
me Ge ee
“ਆ
ਮਦ ਤੀ ਨੀ
ਛਿਣ ਨਾ ਤਰਜ ਨ ਕਸ
ਜੀ ਆ]
“ਦੋ res ney
ra oe ਤਰ ਬਿ 2.
ਤੀ
ਆ ਤਨ ਜੀ
“ਜੀ.
ਹੀ
(ie tee |
ce Be ਰਨ ਲਗ
ਭਲ? ਤਤ ਹਲ ਨਨ
a eae
Ee eee
ee ee

eee eee

<!-- page 4 -->

26//23 7 10
Eee eee ee
26//25 1] 8: ero
27/15
27/16
2814 ਉਤ 49 4 ਦੀ
| 78 ਹੀ 8 4 0
28//6-..। 2੭੩ ੭੪੦0੬
28172... . 2 ੮8. Ore
28//15
ਉਨ ਲੀ.
2902 ੩. | _ 024
29//3-. 1੩. fos)
| 29//4 4. Ney 7s ਵਿ
29//7
20/78 ੨43 8: ROSE
ae Be oe
poypio ni ||) 8: = ੬0 ੩੬
ae ee eee
ee ee - 40066
29105 47 68 44088
29//14
29//46. ੪ 02
29/19 | Be Oe
29002 404
29//22
29//23 sis 6 0
30/3 0. 6 ਉਸ
[ਤਾ ਗਦਾ 2 7੦ਅ॥ਅ. 1345 | 336.
Grand Total in Acres; 166 Acre 2 Kanal
16 Marle
Whereas by this notification the land mentioned in the Schedule above is hereby
declared as "Protected Forest" under Section 29 of the Indian Forest Act, 1927. Now
therefore, the Governor of Punjab in exercise of the powers conferred by Section 30 of
the said act is pleased:-
a. To declare all trees standing in or upon these lands to be reserved from the date
of publication of this notification and
b. To prohibit from the same date the quarrying of stones/sand or burning of lime or
Charcoal or the collection or subjection to any manufacturing process or removal
of any forest produce in any such forest produce in any such forest, and the
breaking up or clearing of land for cultivation, for building, for herding cattle or for
any other purpose, of any land in any such forests.

Whereas by this notification land mentioned in Schedule in the said notification has
already been declared as "Protected Forest" under Section 29 of Indian Forest Act,
1927. Now therefore, in exercise of the powers conferred by Section 32 and 33 of the
said Act, the Governor of Punjab is pleased to make the following rules applicable to all
areas comprised in the aforesaid notification:-

RULES
1. No person shall: ੧੨੧
as
੧". 20੦ ਨ" ' ਦਰ, ਹਾ ਪਾਨ ਕਰਕ

<!-- page 5 -->

a. Cut, fell, girdle, lop, tap any tree, strips of the bark or leaves from, purpose what-
so-ever or remove any forest produce without the previous permission of Divisional
Forest Officer, Dasuya.

b. Herd, pasture, graze or retain any cattle on the said land.

c. Cut or remove the grass, kahi, kana, without the prior permission of the Divisional
Forest Officer, Dasuya. The grass will be cut above ground level with sickle only.

d. Clear or break up land for cultivation or for any other purpose.

e. Set fire to grass, trees, timber or kindle a fire on the land.

£. Hunt, shoot, fishing, poison Water and set traps on the said land.

2. The income from compounding of offences against the rules under section 68 of the Indian
Forest Act, 1927 shall be credited to the State Government.
Chandigarh, TS
Dated the 26.03.2024 aS
| (Krishan Kumar IAS)
Financial Commissioner
Forest and Wildlife Preservation
| Endst. No. DFWLP-39/2/2024-FB/ SOS3-S6
Datedthe _;੦-%- ay
A copy is forwarded to the following for information and necessary action to:-

1. The Controller Printing and Stationery, SAS Nagar, Punjab with one spare copy. It is
requested that notification may be published in the next issue of the Government Gazette
and 100 copies of the same may be sent to this Department.

2. Principal Chief Conservator of Forests (HoFF), Punjab, Sector-68, Forest Complex,
Sahibzada Ajit Singh Nagar.

3. Divisional Forest Officer, Dasuya.

4. Deputy Commissioner, Hoshiarpur.

a
Financial Commissioner
Forest and Wildlife Preservation
