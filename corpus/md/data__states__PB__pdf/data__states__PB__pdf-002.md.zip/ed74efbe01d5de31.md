---
doc_id: "ed74efbe01d5de31"
source_url: "http://www.ihmbti.com/wp-content/uploads/2024/10/Corregendum-for-Non-Veg-items.pdf"
ministry: "Institute of Hotel Management Catering Technology and Applied Nutrition, Bathinda, Punjab"
title: "Corrigendum for Non- Veg"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5c6e64a4321a4a47"
---

<!-- page 1 -->

Letter No. IHM/BTI/2024/2028
Date: 28.10.2024

CORRIGENDUM
The Last date of receipt of sealed tenders of supply of Non-Veg items for
a period of 1st of January 2025 to 31st of December 2026 is hereby extended
upto 06th November 2024 (Upto 02:00PM) due to Administration Reasons.

Principal
IHM Bathinda
