---
doc_id: "8c8a20cdf9f42fbc"
source_url: "https://punjabagro.gov.in/wp-content/uploads/2026/09/RFP-Tender-AD-29.09.2026.pdf"
ministry: "Punjab Agro Industries Corporation Limited (PAIC), Punjab"
title: "Notice"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "579de468e31555f5"
---

<!-- page 1 -->

PUNJAB AGRI EXPORT CORPORATION LTD.

A Punjab State Government Undertaking
Plot No. 2A, Sector 28A, Madhya Marg
Chandigarh 160002
Phone-+91-172-5074210-15 & 5073140
Email: anubha.garg28@punjab.gov.in

Request For Proposal (RFP) For Renewal of Group
Mediclaim Policy
Punjab Agri Export Corporation Limited (PAGREXCO) invites sealed proposals for the
renewal of the Group Mediclaim Insurance Policy for its employees for the policy year
2026–27 from Public/Private Sector General Insurance Companies or Standalone
Health Insurance Companies registered with IRDAI, either directly or through IRDAIlicensed Insurance Brokers with a minimum of 05 years' experience in the field of
Health Insurance in India. Proposals submitted through an Insurance Broker must
clearly specify the name of the Insurance Company being represented. No payment
or any other fee shall be payable by PAGREXCO to the Insurance Broker.
Last date for submission of proposals at above mentioned address is by 13.10.2026
upto 10:00 A.M.
For detailed RFP log onto: www.punjabagro.gov.in
Note: Corrigendum(s), if any shall be published on the above website only.
CIN No. U51909CH1997SGC019321

Managing Director
