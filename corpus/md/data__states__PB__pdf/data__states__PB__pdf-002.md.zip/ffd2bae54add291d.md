---
doc_id: "ffd2bae54add291d"
source_url: "https://taxation.punjab.gov.in/attachments/attachment0_1753170616_3e29a63048a66558.pdf"
ministry: "Excise and Taxation Department, Punjab"
title: "Appointment of Nodal officer for the provisions of the Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal ), Act 2013"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9f2a2a9bdfea6830"
---

<!-- page 1 -->

Directorate of Social Security and Women & Child Development, Punjab

SRCW/POSH/2025/35715-64 fHSt: 07/05/2025

3G 5:

HoHH Sexual Harassment of Women at

Workplace (Prevention, Prohibition and Redressal), 2013

HóH

3fJ3 POSHAct, 2013 5

detcpta @punjab.gov.in
+91- 7889337323

fs: 17.07.2025
B: -1-2025/ y95-18

2. Directorate of Social Security and Women &Child Development, Punjab 5JO
ö: SRCW/POSH/2025/35715-64fHSt: 07/05/2025

3J

HHI

4. jHs HO¬3 a yse3, 4 afMHÖJ JH Ad, YfEST HUA
Social Security and Women & Child Development, Punjab

3Directorate of

J Mst: 07/05/2025

<!-- page 2 -->

Directorate of Social Security and Women .&
Child Development, PunjD
S.C.O. No. 102-103 Sector 34- A,
Chandicarh. Phone: 0172-2602120

Email-Id: srewpunjab@gmail.com

To

All the Heads of the

Govermment of Punjab.Departments
No. /SRCWPOSH2025/

S15

Dated, Chandigarh o/os/>)5-6 7
Sub:

Order dated 03.12.2024 of Hon'ble Supreme Court io M.A Dy. No. 22553 of
2023 in Civil Appeal No. 2482 of 2014 titled Aureliano Feraandes vs State of
Goa and Ors regarding compliance of the provisions of the Sexual

Harassment of Women at Workplace (Prevention, Probibition 2nd

Redressal), 2013.

In compliance of order dated 22.04.202 and 03.J2.2024 of Honble Suprene

Court,
as mentioned in the subject cited bove (enclosed), the following steps are reaqure e
taken by all he Heads of the Departments under the Seyual Harzssment of Women at Workplace
(Prevention, Prohibition and Redressal), 2013:
I. Nodal officer is required to be designated in each Department for the

implemenation ot

the POSH Act, 2013.
htps/shebox.wcd.gov.in') portal n2s

2. The Sexual Harassment electronic Box (SHe-Box

shall also indicate the name 2nd designaion
been instituted by the Govemnent, the same
of the nodal officer for each Departnent.
phone etc.) under POSH
information of Nodal Officer (Name, Designation, email,

3. The

Department's website.

Act, 2013 is also required to be uploaded on
having 10or more
districts and BIlocks level), which are
4. Departments/offices (at State/
Commitee (1CCs) under
constituted Intermal Complaints
employees are required to be
uploaded on She-Box
information of the same shll be
the POSH Act, 2013 and the
leter No. 11/51 2015-1
India. In this regard, vide
of
Govemment
of
portal
been issued
Govemment of Punjab has
WCD/ll60739/1-14,

dated 07.02.2018,

(enclosed). To constitute

ICCs

districtsblocks, District Programmne

Oficers (DPOs)
approached.

be
2013 under this Department may
Act,
POSH
Officers,
Nodal
cum District
Hon'ble Supreme Court
would be submitted in
affidavit
compliance
It is stated that a
direct the concemed
You are requested to kindly
by the State of Punjab.

of India by 09.05.2025

your Department under

to share the

the infommation through

Nodal Officer of
information of designated

in the prescribed
attached

also share
proforma (enclosed) and

user ID and password
herewith., Thereafter,

(nitps://shebox.wcd.gov.in)

portal to upload the

POSH Act,2013

would be shared to login

google sheet

on SHe-Box

information of constituted ICCs.

Dated, Chandigarh
informatiod:"/2

Eudst.No./ SRCWPOSH2025/3S 165-84 following for kind
to the
above is fonvarded
ACopy of theSecuritv and Women &Child Development, Punjab
Punjab.
Child Development,
I PS to SCS, of Social
&
Women
Security and
2. PA to Director, of Social

3.

All the DPOs with the directivesto

take necessary

action.

Dirfctor
