---
doc_id: "eed1fdbb696d44ef"
source_url: "https://agri.punjab.gov.in/uploads/attachment/Acts/Notification_of_Licensing_Authorities.pdf"
ministry: "Agriculture and Farmer Welfare Department, Punjab"
title: "Notification of Licensing Authorities"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "c6750e821d5588c2"
---

<!-- no text layer: pending OCR -->
