---
doc_id: "76fc82bdbde6ca7e"
source_url: "https://decc.punjab.gov.in/wp-content/uploads/2019/06/16.01.2019.pdf"
ministry: "Directorate of Environment and Climate Change, Punjab"
title: "Order dated 16.01.2019"
date: ""
pages: 27
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7860bb244d9393ad"
---

<!-- page 1 -->

Corrected Copy
Item No. 01

Court No. 1
BEFORE THE NATIONAL GREEN TRIBUNAL
PRINCIPAL BENCH, NEW DELHI
Original Application No. 606/2018

Compliance of Municipal Solid Waste Management Rules, 2016
Date of hearing: 16.01.2019
CORAM:

HON’BLE MR. JUSTICE ADARSH KUMAR GOEL, CHAIRPERSON
HON’BLE MR. JUSTICE S.P. WANGDI, JUDICIAL MEMBER
HON’BLE MR. JUSTICE K. RAMAKRISHNAN, JUDICIAL MEMBER
HON’BLE DR. NAGIN NANDA, EXPERT MEMBER

For Applicant(s):
For Respondent (s):

Mr. Rajkumar, Advocate for CPCB

ORDER
S.No.
I.
II.
III.
IV.
V.

CONTENTS
Preface
Proceedings Before this Tribunal
Consideration of Reports of Committees
Directions on the Reports of the Committees
Deliberation

VI.
VII.

Directions
Further Proceedings and Conclusion

PARA No.
1-2
3-10
11-17
18
19-26
27-38
39-47

I.

PREFACE

1.

The issue for consideration is the compliance of the Solid Waste Management
Rules, 2016 (hereinafter referred to as SWM Rules) in continuation of orders
earlier passed on the subject.

2.

Twenty-three years back, the problem of MSW was mentioned by
Hon’ble Supreme Court as follows:

“Historic city of Delhi- the capital of India- is one of the
most polluted cities in the world.
responsible

for

pollution

control

The authorities,
and

environment

protection, have not been able to provide clean and healthy
environment to the residents of Delhi. The ambient air is so
much polluted that it is difficult to breath. More and more
1

<!-- page 2 -->

Delhites are suffering from respiratory diseases and throat
infections. River Yamuna- the main source of drinking water
supply is the free dumping place for untreated sewage and
industrial waste. Apart from air and water pollution, the city
is virtually an open dustbin. Garbage strewn all over Delhi
is a common sight. The Municipal Corporation of Delhi (the
MCD) constituted under the Delhi Municipal Corporation Act,
1957 (Delhi Act) and the New Delhi Municipal Council (the
NDMC) constituted under the new Delhi Municipal Council
Act, 1994 (New Delhi Act) are wholly remiss in the discharge
of their duties under law. It is no doubt correct that rapid
industrial development, urbanization and regular flow of
persons from rural to urban areas have made major
contribution towards environmental degradation but at the
same time the authorities-entrusted with the work of
pollution control cannot be permitted to sit back with folded
hands on the pretext that they have no financial or other
means to control pollution and protect the environment.” *
After twenty-three years, situation has become worse.

‘Swachh Bharat

Abhiyan’, a noble initiate notwithstanding.

II

PROCEEDINGS BEFORE THIS TRIBUNAL

3.

The matter was taken up by this Tribunal vide order dated 22.12.2016 in

Almitra Patel & Anr. v. Union of India & Ors., O.A.No. 199/2014. Proceedings
before this Tribunal arose out of a Petition under the Article 32 of the
Constitution filed before the Hon’ble Supreme Court of India seeking directions
for steps to improve the system of collection, storage, transportation, disposal
treatment and re-cycling of municipal solid waste. The said Petition was
transferred to this Tribunal from Hon’ble Supreme Court of India.

After

consideration of the problem of waste disposal in the country and reports of
various Committees, it was observed that though rules on the subject have
been revised and notified on 08.04.2016, enforcement remained a challenge.
The Tribunal noted that the timeline of steps to be taken within one year under
2
*Dr. B.L Wadhera v. UOI & (1996) 2 SCC 594

<!-- page 3 -->

Rule 22 had already expired without the stipulated action being taken. The
landfills had gone beyond the permissible heights and were a health hazard.
Waste was to be processed in the manner laid down under the rules by
preparing appropriate action plans. Accordingly, directions were issued to all
the States and UTs to enforce and implement the rules and to prepare action
plans relating to management and disposal of waste and to take other steps
as mandated under the Rules.

4.

Inspite of the above, the Annual Report prepared by the CPCB in April, 2018,
showed serious deficiencies in compliance of the rules in most of the States.
Apart from the Report of the CPCB, non-compliance of the Rules could be seen
from frequent grievances being brought before the Tribunal with the
photographic evidence of heaps of garbage lying on the streets seeking
coercive measures against the statutory authorities for their failures. As per
certain studies, the magnitude of problem is India generates over 150,000
tonnes of municipal solid waste (MSW) per day, with Mumbai being the world’s
fifth most wasteful city. Yet, only 83% of waste is collected and less than 30%
is treated. According to the World Bank, India’s daily waste generations will
reach 377,000 tonnes by 2025.1. Unless problem is tackled, its impact on
health and lives of citizens can be devastating. It is high time that stern
measures are taken not only by those in-charge of administering law
themselves but also by educating and involving the public at large.

5.

The Tribunal thought it appropriate to have interaction with the stakeholders
to evolve a mechanism for execution of order already passed in Almitra Patel

& Anr. v. Union of India & Ors., O.A. No. 199/2014 to consider the following
issues:

1

https://www.livemint.com/Opinion/V2CgeiUq89kl1k2fDwJXML/Swachh-Bharats-waste-managementproblem.html

3

<!-- page 4 -->

i.

Whether State-wise Action Plan with timelines and budgetary
support/provision for management of MSW has been prepared?

ii.

Whether each city/town/urban local body is covered under the said Plan
and individual Action Plan has timelines with budgetary provisions?

iii.

What time has been fixed to completely comply with the provisions of
the Rules, 2016?

iv.

6.

What are the main constraints of non-compliance of Rules, 2016?

Accordingly, meetings were held between 02.8.2018 to 20.08.2018 with all the
States and UTs which showed that there was substantial non-compliance of
the Rules and judgment of the Tribunal in Almitra Patel (supra).Execution of
orders of NGT impacting environment generally, though significant, remains a
challenge. Merely passing of orders, without their execution defeats the object
for which NGT has been set up. Section 25 of the Act confers power of
executing court. Mode of execution is laid down in CPC (Section 51), i.e.,
arrest and detention, appointment of a receiver or in such manner as nature
of relief may require. There are provisions for prosecution, including of heads
of departments of the Government. On ‘Polluter Pays’ principle, damages can
be recovered not only from the polluters but also from the State functionaries
who collude with the polluters. The PCBs and the States have not been fully
successful in their performance of duties to protect environment, as noted in
judgement of Hon’ble Supreme Court as well as this Tribunal2. We thus thought
of constituting committees with the involvement of former High Court Judges
or senior bureaucrats as a machinery for effective execution of orders of the
Tribunal having bearing on public health.

7.

Accordingly, the Tribunal, while directing that the action plan be submitted
latest by 31.10.2018 after looking into the successful models and executing it

2

Aryavart Foundation v. M/s Vapi Green Enviro Ltd. & Ors, O. A. No.95/2018

4

<!-- page 5 -->

latest by 31.12.2019 which may be overseen by the Principal Secretaries of
Urban Development and Rural Development, constituted the Apex Monitoring
Committee (AMC), Regional Monitoring Committees (RMCs), State Level
Committees (SLCs) and directed nomination of Nodal Officers at the level of
the Local Bodies and Committees for bigger Local Bodies. The role of the RMCs,
as per para 19 of the order, required regular meetings to monitor taking
necessary steps, including compliance of SWM Rules, 2016 including at or
around railway platforms, railway tracks, bus stands or other places frequented
by public. The RMCs were directed to ensure that mixing up of bio-medical
waste and municipal solid waste does not take place and that bio-medical
waste is processed as per the Bio-Medical Waste Management Rules, 2016.
The role of State level Committees was specified in para 21 to have interaction
with the Local Bodies once in two weeks and to consider the reports of the
Local Bodies which were to be given twice a month. The Committees are to
complete the task within one year. In para 23, it was directed that guidelines
be issued for using CCTV cameras at dumping or other sites and to have
garbage collection vans fitted with GPS. The Tribunal also observed that public
involvement may be encouraged and the status of waste management be put
in public domain including health impacts associated with unscientific disposal.
The State Level Committees were to give reports to the Regional Level
Committees which were to oversee the compliance of the Rules including
preparation and implementation of Action Plans.
8.

It was observed that either no Action Plans had been prepared as required
under the Rules or the plans prepared proposed only 50% to 75% waste
disposal as per Rules. There were no plans for rural areas and hilly terrains.
The result was accumulation of legacy waste in the form of huge dumps of
garbage and unscientific disposal of waste, impacting the public health,
degrading forests and water bodies, apart from causing air pollution.3 Albeit,

3

https://swachhindia.ndtv.com/nearing-35-years-ahmedabads-pirana-landfill-is-infamous-for-its-garbage-mountainsand-frequent-fires-11855/- accumulation of waste at Pirana landfill site, Ahemdabad, causing frequent fire,

5

<!-- page 6 -->

in certain places efforts are successful to deal with legacy waste 4, most States
are grappling with the issue.

Such successful model may be replicated

suitably. Accordingly, it was required that integrated plans are prepared on
scientific lines to manage the solid waste after detailed study and consultation
with the experts. It was also necessary that every State and Union Territory
follows the SWM Rules in letter and spirit. There was need for monitoring of
the steps required to be taken under the Rules as well as the binding earlier
directions of this Tribunal and the Hon’ble Supreme Court.

Need for

performance audit was also noted.
9.

The Tribunal also dealt with the issue of compliance of SWM and associated
Rules on railway tracks and railway platforms in Saloni Singh & Ors. v. Union

of India & Ors., and directed constitution of teams of responsible officers by
the Railway Administration to take steps by framing suitable action plans,
removing encroachments and undertaking landscape of vacated land parcel.5
10.

Certain minor modifications have been made in the said order on two-three
occasions to deal with the issues which arose out of implementation of the
order dated 20.08.2018 such as honorarium/remuneration, providing logistics
and modifications in the manning of the Committees etc6.

https://www.indiatoday.in/education-today/gk-current-affairs/story/ghazipur-garbage-dump-delhi-largest-landfillsite-1329240-2018-09-01- accumulation of waste at Gazipur dumping site.
4
http://www.xaam.in/2019/01/indore-ias-officer-clears-13-lakh-tons.html
5
O.A. No. 141/2014 order dated 01.10.2018
6
(i) Order dated 19.09.2018 in O.A. No. 606/2018: on composition of Eastern Reginal Monitoring Committee
to include West Bengal State Pollution Control Board and providing remuneration/honorarium for Chairpersons
of the Committees.
(ii) Order dated 12.10.2018 in O.A. No. 606/2018: redefining composition of Northern Reginal Monitoring and
constituting a separate Committee for the State of U.P. under the Chairmanship of Justice D.P. Singh
(iii) Order dated 30.10.2018 in O.A. No. 606/2018: directing that the Principal Secretary, Municipal
Administration and Water Supply Department, Government of Tamil Nadu will be the Member – Secretary of
the Monitoring Committee for the Southern Region instead of Principal Secretary, Urban Development, Tamil
Nadu. The Tribunal further emphasized that each village, town and a city of State should have Action Plan
management of Municipal Solid Waste, Bio-medical waste, Plastics waste and Construction and Demolition
waste as per the respective rules in a time- bound manner. Further, Urban Development Department of the
State of Madhya Pradesh was directed to facilitate the working of the Central Regional Monitoring Committee.
(iv) Order dated 20.11.2018 in O.A. No. 606/2018: noting that Central Regional Monitoring Committee has
begun its functioning.

6

<!-- page 7 -->

III.

CONSIDERATION OF REPORTS OF COMMITTEES

11.

The matter has been put up for consideration of reports received from Apex
and Regional Monitoring Committees. We have perused the reports of the U.P.
Solid Waste Management Monitoring Committee dated 25.10.2018 which deals
with the general issue; report dated 30.11.2018 which deals with the issue of
solid waste management in King George Medical University, Lucknow; report
dated 17.11.2018 deals with regard to compliance of the Rules by Baba Raghav
Das (BRD) Medical College, Gorakhpur and the report dated 24.12.2018 with
regard to the Kumbh Mela.

12.

We have perused the ‘preliminary’ report of the Apex Monitoring Committee
dated 03.12.2018, the report of the Regional Monitoring Committees from
Southern Zone dated 10.11.2018, report dated 13.11.2018 from Central Zone
Regional Monitoring Committee, the report dated 15.11.2018 from the
Northern Zone Regional Monitoring Committee and the report dated
04.12.2018 from Eastern Zone Regional Monitoring Committee. The same are
taken on record. Copies of the above reports be forwarded to the CPCB for
coordination in accordance with Rule 14 of the SWM Rules, 2016. The CPCB
may furnish comments and action taken report to this Tribunal within one
month by e-mail at ngt.filing@gmail.com.

13.

Before we consider the reports from the UP Committee, it may be appropriate
to mention that an administrative interaction was held on 04.12.2018 by all
the Members of the Tribunal with the Chairpersons of Apex and Regional
Monitoring Committees. The progress did not appear to be significant. The
impression is fortified by perusing the reports received so far. It is clear that
inspite of five months after comprehensive review was undertaken by the
7

<!-- page 8 -->

Tribunal and orders were passed, the compliance of order of the Tribunal dated
22.12.2016 in Almitra Patel (supra) remains a challenge.7 Orders of Tribunal
showing serious failure in complying with the Rules include the following- (i)

Venkatesh & Ors. v. Union of India & Ors.8, (ii) Ankita Sinha v. State of
Maharashtra & Ors.9, (iii) Rakesh Kashyap v. State of Himachal Pradesh &
Ors.10 (iv) Sukhdev Vihar Resident’s Welfare Association v. State of Delhi &
Ors.11 The above are only illustrative of the grave situation being faced. In view
of this, we propose to consider some modifications for more effective results.
14.

We now refer to the reports from the UP Committee. In the report dated
30.11.2018, the recommendations have been made for the following action:

“1. KGMU be saddled with compensatory cost of Rs. 10 lakh which
may be deposited in Ayushman Yojana fund, ear-marked for BPL
citizens to provide them free treatment.
2. KGMU be directed to strictly comply with the BMW Rules-2016 and
the biomedical wastes categories, their segregation, collection,
treatment, processing and disposal options be done as per
Schedule I of the BMW Rules 2016 and accordingly take
appropriate actions within a period of three months.
3. KGMU be directed to be compliant with Rule 4(g), BMW Rules 2016
and provide training to all its health care workers and others,
involved in handling of bio medical waste at the time of induction
and thereafter at least once every year and the details of training
programmes conducted, number of personnel trained and number
of personnel not undergone any training shall be provided in the
Annual Report.
4. Untreated human anatomical waste, animal anatomical waste,
soiled waste and biotechnology waste shall not be stored beyond
a period of forty-eight hours as mandated under Rules 8 of BMW
Rules 2016.
5. KGMU administration be directed to provide personal protective
equipments (PPE) to all the staff engaged in bio-medical waste.
6. KGMU should obtain water and air consent from the UPPCB.
7. KGMU be directed to install STP and ETP immediately, say within
four months. 8. KGMU be directed to carry out all routine tests,
validation tests, spore tests as per Schedule-II of BMW Rules-2016
forthwith.”
7
8

Mrs. Almitra H. Patel v. U.O.I, O.A. No. 199/2014 Judgement dated 22.12.2016

O.A.No. 711 of 2018, order dated 22.10.2018- Illegal dumping of solid waste at Balagur, Bengaluru. BBMP
was directed to deposit Rs. 5 Crores as environmental compensation for damage to the environment.
9
O.A. No. 510/2018 order dated 30.10.2018- Municipal Solid Waste dumping site at Deonar, Mumbai was not
complying with SWM Rules, 2016. Tribunal directed Municipal Corporation, Greater Mumbai to deposit Rs. 5
Crores as environmental compensation with CPCB for restitution of environment.
10
O.A. No. 189/2017, order dated 27.08.2018- Municipal Corporation, Theog, Shimla illegally permitted
dumping of solid waste of forest land. The Tribunal directed shifting of the site and directed Municipal
Corporation to pay an amount of Rs. 5 lakhs as environmental compensation.
11
O.A. No. 640/2018 order dated 27.09.2018: Tribunal directed that if the project proponents fail to maintain
the standards, even after carrying out the deficiencies noticed in the joint inspection Report, CPCB may
recommend the amount of environmental damage required to be paid by them.

8

<!-- page 9 -->

15.

The report dated 17.11.2018 with regard to compliance of the Rules by Baba
Raghav Das Medical College, Gorakhpur, proposes following directions:

“(i)

Admission of children between upto the age of 10 or 15 years
brought for treatment in BRD Medical College, Gorakhpur be
stopped forthwith for two months, subject, however, to the
compliance of the provisions of Bio-Medical Waste (Management
and Handling) Rules, 2016. In emergency cases, only those
children brought in critical conditions be admitted for treatment,
provided the facility for their treatment is not available in other
hospitals, private or government.
(ii) The BRD Medical College, Gorakhpur and the Government of UP
be directed to provide infrastructure for disposal of bio-medical
waste strictly in accordance to the Rules of 2016 (supra) within
two months.
(iii) Cost of rupees five crores or more, as the Hon'ble NGT may in the
facts and circumstances deem appropriate, be imposed on the
BRD Medical College and the amount of cost so recovered be
reimbursed amongst the bereaved families whose children died
during the past two years i.e. after the date of notification and
coming into force the Rules of 2016. The Medical College must
be having the addresses of such families, recorded at the time of
admission of their children. Certain portion of said cost be
recovered from the salaries of Principal and those officers/officials
of the Medical College, who are responsible for non-compliance
of the Rules of 2016. The District Magistrate, Gorakhpur may
supervise the whole process.
(iv) The Medical Council of India be directed to send its team to
inspect the BRD Medical College, Gorakhpur and submit report to
take appropriate action in the matter and to maintain the
standard of medical education in the College. On the basis of the
said report and the recommendations, necessary infrastructure
be developed and admission of the patients be regulated.”

16.

In report dated 24.12.2018 with regard to Kumbh Mela, following
recommendations have been made:

“17. We request the Hon'ble NGT to permit the use of fund with UPPCB
under environmental compensation corpus to a limited extent
under strict supervision of Monitoring Committee and the
Principal Secretary, Urban Development for advertisement
through posters, audio-visuals, handbills and electronic media,
etc in whole of the State of UP in case the Government suffers
from financial crunch.
Shri Anurag Yadav, Secretary, Urban Development appears to
have got very positive approach and helping in nature. He
undertakes that he and his Government shall enforce the
decisions taken hereinabove, not only during Kumbh Mela but as
far as possible, all over the State. We appreciate the zeal and
workaholic nature of Shri Anurag Yadav, IAS, Secretary, Urban
Development. The decision taken and reproduced hereinabove in
the meeting of the Monitoring Committee may be looked into and
9

<!-- page 10 -->

in case the Hon'ble NGT pleases, the same may be approved for
future course of action and make it binding on the State
Government and its authorities.
It is further requested that in case Hon'ble NGT pleases, alike
posters may be prepared in all the States in regional/local
language by Chairmen, Monitoring Committees and its soft copy
be forwarded to Kumbh Mela Adhikari, State Monitoring
Committee/Secretary, Urban Development UP so that posters in
different languages may be pasted in Kumbh Mela to educate the
people visiting there.”

17.

We do not propose to take the above reports to the logical end straightaway
in these proceedings. The recommendations involve administrative action at
the level of Health Department and Urban Development Department of the
State. It also involves exercise of statutory powers by the SPCBs. The issues
may be first dealt with by concerned administrative and statutory authorities.

IV

DIRECTIONS ON THE REPORTS OF THE COMMITTEES

18.

Accordingly, recommendations in the reports will stand disposed of with
following directions:
(i)

The report dated 30.11.2018 with regard to King George Medical
University be forwarded forthwith to the Principal Secretary, Health
Department, Principal Secretary, Urban Development Department, Uttar
Pradesh Pollution Control Board (UPPCB) and the CPCB for being
appropriately dealt with.

(ia)

The Principal Secretaries, Health Department and Urban Development
Department, Uttar Pradesh may take such steps as are in their domain
and furnish their action taken reports within one month by e-mail at
ngt.filing@gmail.com.

(ib)

The UPPCB may exercise powers inter-alia under Rule 16 of the SWM
Rules, 2016, the Water (Prevention and Control of Pollution) Act,1974
and the Air (Prevention and Control of Pollution) Act, 1981 and apart

10

<!-- page 11 -->

from other steps, determine and recover the amount of damage after
following due procedure. Pending such consideration, we direct King
George Medical University to deposit interim compensation of Rs. 10
Lakhs with the UPPCB. The UPPCB may spend the amount for
restoration of the environment and to help the victims of diseases,
wherever necessary and also conduct appropriate health impact study
and furnish action taken report to this Tribunal within one month by email at ngt.filing@gmail.com.
(ic)

The CPCB may coordinate the matter in terms of Rule 14 of the SWM
Rules, 2016 and furnish action taken report to this Tribunal within one
month by e-mail at ngt.filing@gmail.com.

(ii)

Similarly, report dated 17.11.2018 with regard to Baba Raghav Das
(BRD) Medical College may be sent to the above authorities for taking
similar action.

(iia)

The

Principal

Secretaries,

Health

Department

Development

Department,

Uttar

Pradesh

and

may

the

Urban

consider

the

recommendations and take appropriate action in their domain and
furnish their respective reports within one month by e-mail at
ngt.filing@gmail.com.
(iib)

The UPPCB may exercise of powers inter-alia under Rule 16 of the SWM
Rules, 2016, the Water (Prevention and Control of Pollution) Act,1974
and the Air (Prevention and Control of Pollution) Act, 1981 and apart
from other steps, determine and recover the amount of damage after
following due procedure. Pending such consideration, Baba Raghav Das
(BRD) Medical College, Gorakhpur may deposit interim compensation of
Rs. 1 Crore with the SPCB. The SPCB may spend the amount for
restoration of the environment as well as to help the victims of diseases
as may be found viable, after conducting appropriate health impact
11

<!-- page 12 -->

study and furnish an action taken report to this Tribunal within one
month by e-mail at ngt.filing@gmail.com.

(iic)

The CPCB may coordinate the matter in terms of Rule 14 of the SWM
Rules, 2016 and furnish action taken report to this Tribunal within one
month by e-mail at ngt.filing@gmail.com.

(iii)

The report dated 24.12.2018 may be forwarded to the Kumbh Mela
authority. The UPPCB may permit part use of environmental
compensation corpus available with it in the manner suggested by the
Committee, subject to concurrence of the Committee and the Principal
Secretary of the Urban Development, Uttar Pradesh. Copies of the
report be sent to the Principal Secretary, Urban Development
Department, the UPPCB and the CPCB and they may furnish their action
taken reports to this Tribunal within one month by e-mail at
ngt.filing@gmail.com, in the manner mentioned earlier in direction (i)
and (ii).

V.
19.

DELIBERATION
As per order dated 20.08.2018, action plans were to be submitted latest by
31.10.2018 and executed by 31.12.2019. Rule 22 of the SWM Rules
provides timelines in this regard which are as follows:
Sl.
No.

Activity

(1)
1.

(2)
Identification of suitable sites for setting up solid
waste processing facilities
Identification of suitable sites for setting up
common regional sanitary landfill facilities for
suitable clusters of local authorities under 0.5
million population and for setting up common
regional sanitary landfill facilities or stand alone
sanitary landfill facilities by all local authorities
having a population of 0.5 million or more
Procurement of suitable sites for setting up solid
waste processing facility and sanitary landfill
facilities

2.

3.

Time limit from the
date of notification
of rules
(3)
1 year
1 year

2 years

12

<!-- page 13 -->

4.

5.
6.
7.
8.
9.

10

11.

20.

Enforcing waste generators to practice segregation
of bio degradable, recyclable, combustible, sanitary
waste domestic hazardous and inert solid wastes at
source
Ensure door to door collection of segregated waste
and its transportation in covered vehicles to
processing or disposal facilities.
ensure separate storage, collection and
transportation of construction and demolition
wastes
setting up solid waste processing facilities by all
Local Bodies having 100000 or more population
Setting up solid waste processing facilities by Local
Bodies and census towns below 100000 population.
setting up common or stand alone sanitary landfills
by or for all Local Bodies having 0.5 million or more
population for the disposal of only such residual
wastes from the processing facilities as well as
untreatable inert wastes as permitted under the
Rules
setting up common or regional sanitary landfills by
all Local Bodies and census towns under 0.5 million
population for the disposal of permitted waste
under the rules
bio-remediation or capping of old and abandoned
dump sites

2 years

2 years
2 years
2 years
3 years
3 years

3 years

5 years

”

Timelines of two years have expired as rules came into force on
08.04.2016. Timeline of three years is going to expire on 08.04.2019.
However, for bio-remediation, timelines of five years has been provided.
On ‘Polluter Pays’ principle, the polluters must be required to pay damages
by the concerned authorities. Failure to do so may render the authorities
also liable to pay damages as has been directed in several orders of this
Tribunal.12 Performance Guarantee may also be required if there is no
improvement.13

21.

The issue of solid waste management is of paramount importance for
protection of environment. Failure to address this issue in a satisfactory
manner, impacts air pollution as well as water pollution. It is partly on that

All India Lokadhikar Sangathan vs. Govt of NCT Delhi & Anr, E.A No. 11/2017, Date of Order 16.10.2018;
Sobha Singh vs. State of Punjab & Ors. O.A. No. 916/2018, Date of Order 14.11.2018; Threat to life arising
out of coal mining in south Garo Hills district v. State of Meghalaya & Ors. O.A No. 110 (THC)/2012, Date of
Order 04.01.2019; Ms. Ankita Sinha vs. State of Maharashtra & Ors. O.A. No. 510/2018, Date of Order
30.10.2018, Sudarsan Das vs. State of West Bengal & Ors. O.A. No. 173/2018, Date of Order 04.09.2018;
Court on its Own Motion vs. State of Karnataka, O.A. No. 125/2017, Date of Order 06.12.2018.
12

13

Ibid.

13

<!-- page 14 -->

account that the statistics mentioned in certain studies paint dismal picture
of environment in terms of number of deaths and diseases. These studies
have already been referred by this Tribunal in certain orders, including the
recent order dated 04.01.2019 in Threat to life arising out of coal mining in

south Garo Hills district v. State of Meghalaya & Ors

(O.A No. 110

(THC)/2012)14. It was observed:
“28. It is a matter of serious concern that compliance of
environment norms is not satisfactory and result is large scale
deaths and diseases and serious damage to air, water and
earth. As per CPCB report, 351 river stretches in the country
are polluted, 102 cities are classified as non-attainment cities
in terms of ambient air quality, there are 100 industrial
clusters. There is wide gap in compliance of statutory rules for
waste disposal, which issues are subject matter of proceedings
before this Tribunal.
29. The above shows that in-spite of statutory framework and
binding legal precedents and orders, violation of law is
rampant. Stern approach is, thus, required against the
polluters as well as statutory authorities conniving or colluding
with the polluters. The statutory authorities are trustees of the
people and if their failure results in harm to the citizens or to
the environment, the Court/Tribunal has to adopt strict
approach to make them accountable so that such action acts
as deterrent to prevent further harm”.15

O.A. No. 110 (THC)/2012-Threat to life arising out of coal mining in south Garo Hills district v. State of

14

Meghalaya & Ors.
15

(a). O.A. No. 673/2018, News item published in ‘The Hindu’ authored by Shri Jacob Koshy Titled “More river
stretches are now critically polluted: CPCB” dated 20.09.2018: wherein the Tribunal issued directions to
prepare and implement Action Plans to rejuvenate and restore the 351 polluted river stretches. (b) Original
Application No. 681/2018, News Item Published in “The Times of India’ Authored by Shri Vishwa Mohan
Titled “NCAP with Multiple timelines to Clear Air in 102 Cities to be released around August 15” dated
08.10.2018: wherein the Tribunal directed Action Plans to be prepared for the 102 non-attained cities to
bring the standards of air quality within the prescribed norms. (c) Original Application No. 1038/2018, News
item published in “The Asian Age” Authored by Sanjay Kaw Titled “CPCB to rank industrial units on pollution
levels” dated 13.12.2018: wherein the Tribunal directed preparation of time bound Action Plans to ensure
that all industrial clusters comply with the parameters laid down in Air (Prevention and Control of Pollution)
Act, 1981 and the Water (Prevention and Control of Pollution) Act, 1974. (d) Original Application No.
606/2018, Compliance of Municipal Solid Waste Management Rules, 2016 dated 31.08.2018: wherein the
Tribunal constituted Apex and Regional Monitoring Committees for effective implementation of MSW Rules,
2016.

14

<!-- page 15 -->

22.

Vide order dated 11.01.2019 in Aryavart Foundation v. M/s Vapi Green

Enviro Ltd. & Ors (Original Application No.95/2018)16 it was observed:
“It is well acknowledged that there is serious threat to the
environment in this country. Studies show huge number
of pollution related deaths and diseases. Any violation of
laid down environmental norms has to be seriously viewed
and sternly dealt with.”17
23.

Again vide order dated 11.01.2019 in “News Item Published In ‘The Times

of India’ Authored by Shri. Vishwa Mohan Titled “NCAP with Multiple
Timelines to Clear Air in 102 Cities to be released around August 15”
(Original Application No. 681/2018)18 it was observed:
“According to a survey, 15,000 persons died prematurely
in Delhi in the year 2016. Delhi was ranked as third in the
list of cities reporting most deaths due to air pollution.
Premature deaths in Mumbai, Kolkata, Bangalore and
Chennai are reported to be between 5,000-10,000 in
2016.” 19

24.

Concept of sustainable development which guides this Tribunal under
Section 20 of the NGT Act, 2010 cannot be upheld unless the above issues
of massive degradation of environment are handled on war footing.
Directions have been issued by this Tribunal to prepare action plans for
restoration of 351 polluted river stretches, restoration of air quality in 102
“non-attainment cities”, restoration of environment in 100 critically polluted

16

Aryavart Foundation v. M/s Vapi Green Enviro Ltd. & Ors, O.A. No.95/2018
https://niti.gov.in/writereaddata/files/new_initiatives/presentation-on-CWMI.pdf- India ranks 120th in 122
countries in Water Quality Index as per Niti Ayog Report, https://www.thehindu.com/sci-tech/energyandenvironment/india-ranked-no-1-in-pollution-related-deaths-report/article19887858.ece- Most pollutionlinked deaths occur in India, https://www.hindustantimes.com/india-news/delhi-world-s-most-polluted-citymumbaiworse-than-beijing-who/story-m4JFTO63r7x4Ti8ZbHF7mM.html- Delhi’s most polluted city, Mumbai
worse
than
Beijing
as
per
WHO;
http://www.un.org/waterforlifedecade/pdf/global_drinking_water_quality_index.pdf- WHO Water Quality
Index
18
News Item published in ‘The Times of India’ Authored by Shri. Vishwa Mohan Titled “NCAP with Multiple
Timelines to Clear Air in 102 Cities to be released around August 15” O.A. No. 681/2018http://www.greentribunal.gov.in/DisplayFile.aspx
19
https://www.ndtv.com/delhi-news/delhis-air-pollution-has-caused-of-death-of-15-000people-study1883022.
17

15

<!-- page 16 -->

industrial clusters and compliance of directions of SWM Rules, 2016 apart
from the directions for effective regulations of sand mining20, regulation of
ground water21.
25.

The above directions with regard to polluted rivers, polluted air, polluted
industrial clusters and issues of illegal sand mining are also inter-linked with
compliance of SWM Rules, 2016 as also with Hazardous and Other Wastes
Management Rules, 2016, Bio-medical Wastes Management Rules, 2016,
Construction and Demolition Wastes Management Rules, 2016 and Plastics
Wastes Management Rules, 2016, E-waste (Management) Rules, 2016 etc.
A holistic view is required to be taken. All factors degrading environment
need to be addressed in an integral manner. This is to be guided by the
principle of ‘Sustainable Development’. This requires coordination with
several authorities of a State. Such coordination, having regard to serious
impact on health and environment must be coordinated at the highest level
periodically. This requires involvement of Chief Secretaries/Administrators
of all the States and UTs. We have noted in several orders that compliance
is a serious issue and satisfactory progress is not being achieved.22

26.

As noted earlier in para 13, it may be appropriate to mention that an
administrative interaction was held on 04.12.2018 by all the members of the
Tribunal with the Chairpersons of Apex and Regional Monitoring Committees.
The progress did not appear to be significant. The impression is fortified by
perusing the reports so far received. It is clear that inspite of five months after
comprehensive review was undertaken by the Tribunal and orders were
passed, the compliance of order of the Tribunal dated 22.12.2016 in Almitra

Patel (supra) remains a challenge. The pattern of Committees needs

Sudarsan Das vs. State of West Bengal & Ors. O.A. No. 173/2018 Order dated 04.09.2018
Shailesh Singh vs. Hotel Holiday Regency, Moradabad & Ors. O.A. No. 176/2015, order dated 3.1.2019
22
Aryavart Foundation v. M/s Vapi Green Enviro Ltd. & Ors O.A. No.95/2018
20
21

16

<!-- page 17 -->

modification. Coordination at Regional level does not appear to be as effective
as expected.

VI. DIRECTIONS

27.

Instead of having Regional Monitoring Committees constituted vide order
dated 20.08.2018, the State Level Committees may function in the modified
form as is being now directed. Chairpersons of the Regional Committees may
continue to be the Chairpersons of the particular State/UT Committee as
mentioned below.

Other Members may be the officers of the particular

respective State.

28.

In this respect, following directions/clarifications are issued:
i.

For all the States and UTs, the Member Secretaries of the PCBs/PCCs
will be the Member Secretaries of the Committees, other members being
Secretaries, Urban Development/Local Bodies/Local Self-Government,
Environment, Rural Development Health and representatives of CPCB,
wherever office of CPCB exists or representative is nominated by CPCB.
Logistics and honorarium will be provided by the respective SPCB/PCCs
which can be met out from Environment Compensation funds on the
basis of ‘Polluter Pays’ principle or otherwise. If SPCBs/PCCs do not have
requisite funds to provide logistic support, CPCB will provide funds to
SPCBs/PCCs. In case of any difficulty, CPCB may coordinate any such
issues. The honorarium will be paid as per order of the Tribunal in this
matter dated 19.09.201823 and in Amresh Singh v. Union of India &

Ors.24 Where the Chairperson is receiving remuneration/honorarium in
23

See order dated 198.9.2018 of this Tribunal in O.A No. 606/2018 to the effect that the non-official
Chairperson will be pa9id consolidated amount equal to basic pay of the post held by the incumbent. A former
Judge of Hon’ble Supreme Court will be entitled to Rs. 2.50 Lakhs per month. A former Judge of the High Court
will be paid Rs. 2.25 Lakhs per month. On same pattern, remuneration may be fixed for any other retired
Member.
24
a. E.A. No.32/2016 order dated 15.11.2018- Clarifying that while the State may provide the logistics and
other facilities, the financial aspects may be taken care of by the State Pollution Control Boards/Committees.
The financial aspects will include the remuneration or other incidental expenses which may be increased with

17

<!-- page 18 -->

one Committee constituted by the NGT, he may not receive
extra/double remuneration but may be provided requisite logistics as
may be required. The Committees may work tentatively for six months
or as may be found necessary.

ii.

Chairpersons will be as follows:

S.No.

State/UT

Chairperson

1

Andhra Pradesh

Justice B. Seshasayana Reddy, former
Judge, Andhra Pradesh High Court

2

Assam

Mr. Ranjit Shekhar Mooshahary, IPS
former Governor of Meghalaya

3

Bihar

Justice Samarendra Pratap Singh, former
Judge, Patna High Court

4

Chhattisgarh

Justice Dhirendra Mishra, Former Judge,
High Court of Chhatisgarh

5

Gujarat

Justice Babulal Chandulal Patel, former
Chief Justice, High Court of Delhi and
former Judge of Gujarat High Court.

6

Haryana

Justice Pritam Pal, former Judge, High
court of Punjab and Haryana*

7

Himachal Pradesh

Mrs. Rajwant Sandhu, former Chief
Secretary of Himachal Pradesh *

8

Jammu & Kashmir

Justice Janak Raj Kotwal, former Judge,
High Court of Jammu & Kashmir.*

9

Jharkhand

Justice Ramesh Kumar Merathia, former
Judge, High Court of Jharkhand.*

10

Karnataka

Justice Subhash B. Adi, former Judge,
High Court of Karnataka.

11

Kerala

Justice A.V Ramakrishna Pillai, former
Judge, High Court of Kerala

12

Madhya Pradesh

Justice K.K Trivedi, former Judge, High
Court of Madhya Pradesh.

a view to effectively execute the directions of this Tribunal. Such expenses may include secretarial assistance,
travel as well as cost incurred for any technical assistance.
b. Apart from remuneration, all actual expenses incurred in taking assistance for secretarial working will be
reimbursed by concerned PCB as already directed vide order dated 17.12.2018 E.A. No.32/2016, Amresh Singh

v. Union of India & Ors.

18

<!-- page 19 -->

29.

13

Maharashtra

Justice J.P Devadhar, former Judge, High
Court of Bombay.*

14

Manipur

Mr. Jarnail Singh, Ex-Chief Secretary,
Manipur.

15

Odisha

Justice P.K. Mohanty, former Judge,
Odisha High Court.

16

Punjab

Justice Pritam Pal, former Judge, High
court of Punjab and Haryana*

17

Rajasthan

Justice Deepak Maheswari, former Judge,
Rajasthan High Court

18

Sikkim

Justice A.P Subba, former Judge, High
Court of Sikkim.

19

Tamil Nadu

Justice P. Jyothimani, former Judge,
Madras High Court, former Judicial
Member, NGT.

20

Telangana

Justice C.V. Ramulu,
Andhra High Court.

21

Uttar Pradesh

Justice Devi Prasad Singh, former Judge,
High Court of Allahabad. *

22

Uttarakhand

Justice U.C Dhyani, former Judge, High
Court of Uttarakhand. *

23

West Bengal

Justice J.K Biswas, former Judge, High
Court of Calcutta.*25

former

Judge

In other States/UTs, the Chief Secretaries/Administrators will be the
Chairpersons, other members and Member Secretaries being same as
mentioned earlier. The Committees may hold their first meeting positively
before 15.02.2019 and thereafter hold meetings periodically as may be
found necessary as per direction of the Chairperson of the Committee.

30.

The Committee constituted under Rule 5,12 & 23 of the SWM Rules, 2016
will continue to work in tandem with the State Level Committees and the

25

*Already appointed in other Committees of NGT
19

<!-- page 20 -->

frequency of their meeting will be jointly worked out by the State Level
Committee and the Committees constituted under the SWM Rule.

31.

The CPCB may prepare Standard Operating Procedure (SOP) for
implementation of Clause (J) to the Schedule-I of the SWM Rules, 2016
relating to Bio-mining and disposal of legacy waste within one month after
considering successful modes, to be customized according to local
conditions and circulate the same to the SPCBs and PCCs who in-turn may
communicate to the Chief Secretary for implementation. CPCB will also
convey these guidelines to MoHUA, Apex and State Level Committees and
coordinate with them as per Rule 14 of SWM Rules.

32.

The District Collectors under Rule 12

of SWM Rules, 2016 may meet

monthly and forward the report to State Urban Development Department
and send copy to the State Level Committee. The Committees may get
report from District Collector once a month.

33.

The Apex Monitoring Committee may interact with the State Committees in
such manner as may be found necessary and give its report to this Tribunal
once in a quarter. Apex Monitoring Committee may interact with the State
Level Committees atleast once in a month. Chairpersons of the State Level
Committee will be at liberty to visit the District Collector and other local
authorities.

34.

The expression ‘remuneration’ used in earlier orders will stand substituted
by ‘honorarium’.

35.

Every State/UT may constitute a Special Task Force (STF) in every District
having four members one each nominated by District Magistrate,
Superintendent of Police, Regional Officer of the State Pollution Control
Boards in concerned Districts and one person to be nominated by the
20

<!-- page 21 -->

Chairman of the District Legal Services Authority (DLSA) for awareness
about the SWM Rules, 2016 by involving educational, religious and social
organizations including local Eco-clubs. The involvement of DLSA would be
subject to the approval of the National Legal Services Authority which is
the apex body under the Legal Services Authorities Act, 1987 by an
appropriate administrative order. This will apply to order of the Tribunal in

Stench Grips Mansa’s Sacred Ghaggar River (Suo-Moto Case) and Yogendra
Kumar26, News item published in ‘The Hindu’ authored by Shri Jacob Koshy
Titled “More river stretches are now critically polluted: CPCB” 27, Court on
its own Motion v. NCT, Delhi & Ors.28 and M.C.Mehta v. Union of India &
Ors.29

36.

It has been repeatedly laid down by the Hon’ble Supreme Court that
Information, Education and Communication (IEC) programmes can go a
long way for protection of the environment.

Such program can be

successful if network of Legal Services Authorities and Educational
Institutions at every level is involved.

This is possible only if such

instructions are issued on the administrative side by the NALSA and
concerned Education Departments of the States. We request concerned
authorities to take appropriate steps in view of the judgments of the
Hon’ble Supreme Court in M.C. Mehta v. Union of India & Ors.30 and In Re:

Noise Pollution and Article 144 of the Constitution of India 31 Ministry of
Health and Ministry of Railways in coordination with MoEF&CC may be
involved in awareness programmes. Solid waste management issue
impacts in a big way. Various departments of the Government, particularly
Railway, Health and Defence. MoEF&CC may coordinate with the concerned

26

O.A. No. 138/2016 order dated 27.08.2018
O.A.No. 673/2018, order dated 20.09.2018
28
Suo Moto Application No. 290/2017, order dated 24.10.2018
29
O.A. No. 200/2014 order dated 29.11.2018
30
(2004)1 SCC 571
31
(2005)5 SCC 733
27

21

<!-- page 22 -->

Ministries in IEC programmes and furnish an Action Taken Report by email
at ngt.filing@gmail.com.

37.

We also make it clear that the rule of law has to be upheld. This Tribunal
has laid down that the State itself is liable to pay compensation for its failure
to perform duties in upholding environmental norms and can also be held
liable for paying damages which may be recovered from the polluters and
the erring officers.32

38.

We have already noted that ‘Polluter Pays’ principle can be applied by every
regulatory authority and compensation can be and must be recovered from
every polluter and the amount which is to be recovered spent for the
restoration of the environment.33 On the pattern of order dated
19.12.201834, the compensation for damage to the environment will be
payable by each of the States/ UTs at the rate of Rs. One Crore per month
for each of the Priority- I and Priority- II stretches, Rs. 50 lacs per month
for stretches in Priority- III and Rs. 25 lacs per month each for Priority- IV
and Priority- V stretches. The Tribunal may have to consider direction to
require compensation to be paid for damage to the environment on
monthly basis with incremental scale for the delay in compliance of the
Rules. This aspect will be considered in the light of progress achieved by

Aryavart Foundation v. M/s Vapi Green Enviro Ltd. & Ors (O.A. No.95/2018) order dated 11.01.2019wherein this Tribunal reiterated that ‘Polluter Pays’ principle is ingrained in the environmental jurisprudence
of the country as well as statutory mandate under Section 20 of the NGT Act, 2010.; Threat to life arising
out of coal mining in south Garo Hills district v. State of Meghalaya & Ors (O.A No. 110 (THC)/2012) order
dated 04.01.2019- wherein this Tribunal held that it is necessary that the state machinery is required to
compensate for their negligence and failure which may act as deterrent against the officers who neglected
their basic duty of protecting the environment or colluded with the polluters and law violators. This is
required not only as a part of principle of ‘polluter pays’ which applies not only to actual polluters but also
to those who collude with polluters or enable pollution to be caused and also for the negligence of public
duties, adversely affecting the citizens.
33
Threat to life arising out of coal mining in south Garo Hills district v. State of Meghalaya & Ors O.A. No.
110(THC)/2012
34
News Item published in “The Hindu” authored by Shri Jacob Koshy Titled “More river stretches are now
critically polluted: CPCB (O.A. No. 673/2018) vide order dated 19.12.2018- wherein this Tribunal held that
compensation for damage to the environment will be payable by each of the States/ UTs at the rate of Rs.
One Crore per month for each of the Priority- I and Priority- II stretches, Rs. 50 lacs per month for stretches
in Priority- III and Rs. 25 lacs per month each for Priority- IV and Priority- V stretches.
32

22

<!-- page 23 -->

the concerned States/UTs as may be shown from the reports furnished to
this Tribunal by the Chief Secretaries or otherwise. On this aspect, CPCB,
MoEF & CC and the Apex Committee may furnish their views on the subject
within one month at ngt.filing@gmail.com.

VII.

39.

FURTHER PROCEEDINGS AND CONCLUSION

Accordingly, we direct the Chief Secretaries/Administrators of all States and
UTs to review the progress on all the above issues and for the purpose,
hold first meeting within one month from today. After the Chief Secretaries
have monitored the matters, the Status Reports of compliance and
immediate future plans may be presented/filed before this Tribunal. For
this purpose, we direct the Chief Secretaries to remain present in person
along with their reports on different dates mentioned below starting from
1st March, 2019 at 2:00 P.M:
S.No.

State/UT

Date of Meeting

1

Jammu & Kashmir

01.03.2019

2

Himachal Pradesh

05.03.2019

3

Haryana

06.03.2019

4

Punjab

07.03.2019

5

Uttarakhand

08.03.2019

6

NCT Delhi

11.03.2019

7

Uttar Pradesh

12.03.2019

8

Chandigarh

13.03.2019

9

West Bengal

14.03.2019

10

Bihar

15.03.2019

11

Jharkhand

25.03.2019

12

Odisha

26.03.2019

13

Arunachal Pradesh

27.03.2019

14

Assam

28.03.2019
23

<!-- page 24 -->

40.

15

Tripura

29.03.2019

16

Manipur

01.04.2019

17

Meghalaya

02.04.2019

18

Mizoram

03.04.2019

19

Nagaland

04.04.2019

20

Sikkim

05.04.2019

21

Maharashtra

08.04.2019

22

Gujarat

09.04.2019

23

Goa

10.04.2019

24

Daman & Diu

11.04.2019

25

Dadra and Nagar Haveli

12.04.2019

26

Madhya Pradesh

15.04.2019

27

Rajasthan

16.04.2019

28

Chattisgarh

22.04.2019

29

Tamil Nadu

23.04.2019

30

Karnataka

24.04.2019

31

Kerala

25.04.2019

32

Andhra Pradesh

26.04.2019

33

Telangana

29.04.2019

34

Puducherry

30.04.2019

35

Andaman & Nicobar Islands

01.05.2019

36

Lakshadweep Islands

02.05.2019

The Chief Secretaries may acquaint and keep themselves ready on the
following points:
a. Status of compliance of SWM Rule, 2016, Plastic Waste
Management Rules, 2016 and Bio-Medical Waste Management
Rules, 2016 in their respective areas.
b. Status of functioning of Committees constituted by this order.
c. Status of the Action Plan in compliance vide order dated
20.09.2018 in the News Item published in “The Hindu” authored

24

<!-- page 25 -->

by Shri Jacob Koshy Titled “More river stretches are now critically
polluted: CPCB (Original Application No. 673/2018).
d. Status of functioning of Committees constituted in News Item
Published in “The Times of India’ Authored by Shri Vishwa Mohan Titled
“NCAP with Multiple timelines to Clear Air in 102 Cities to be released
around August 15” dated 08.10.2018

e. Status of Action Plan with regard to identification of polluted
industrial clusters in O.A. No. 1038/2018, News item published in
“The Asian Age” Authored by Sanjay Kaw Titled “CPCB to rank
industrial units on pollution levels” dated 13.12.2018.

f. Status of the work in compliance of the directions passed in O.A.
No. 173 of 2018, Sudarsan Das v. State of West Bengal & Ors. Order
dated 04.09.2018.

g. Total amount collected from erring industries on the basis of ‘Polluter
Pays’ principle, ‘Precautionary principle’ and details of utilization of
funds collected.

h. Status of the identification and development of Model Cities and
Towns in the State in the first phase which can be replicated later
for other cities and towns of the State.

41.

It is made clear that Chief Secretaries may not delegate the above function
and the requirement of appearance before this Tribunal to anyone else.
However, it will be open to them to change the date, by advance intimation
by email at NGT website i.e. ngt.filing@gmail.com, to adjust their
convenience.

42.

The States will also display on their respective websites and the websites
of the Pollution Control Boards/Committees the progress made on each of
the above issues, consistent with directions in some of the earlier order,
including the order dated 19.12.2018 in News item published in “The

25

<!-- page 26 -->

Hindu” authored by Shri Jacob Koshy Titled “More river stretches are now
critically polluted: CPCB (Original Application No. 673/2018).

43.

MoEF & CC may coordinate with the concerned organizations/association
of industries to indicate a programme to reduce the quantum of waste by
appropriate strategies including use of less packaging material keeping in
mind such initiatives elsewhere.

44.

The Chief Secretaries of the States and UTs may ensure that all the drains
(big or small) are tapped with appropriate measures (wire nets etc.) and
no municipal solid and plastic waste is allowed to reach our river systems,
lakes, water bodies, ponds, marsh lands and wetlands etc.

45.

We are also of the view in accordance with the Rule 14 of the Rules, the
CPCB may assign an officer to coordinate with the Committees constituted
under this order or other orders where the Committees are headed by the
former Judges and senior bureaucrats. Since Dr. A.B. Akolkar, former
Member Secretary, CPCB has been associated with such coordination and
the CPCB has engaged his services, he may continue to be engaged for the
purpose and provided requisite logistics to carry out his duties.

46.

List for further consideration on above dates and thereafter on July 10,
2019.

Adarsh Kumar Goel, CP

26

<!-- page 27 -->

S.P. Wangdi, JM

K. Ramakrishnan, JM

Dr. Nagin Nanda, EM
January 16, 2019
Original Application No. 606/2018
AK

27
