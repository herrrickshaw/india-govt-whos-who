---
doc_id: "56cb5e1fd2da6dd7"
source_url: "https://pbsports.punjab.gov.in/pdf/corrigendum-2-regarding-purchase-of-sports-equipment.pdf"
ministry: "Department of Sports, Punjab"
title: "Corrigendum-2 Regarding Purchase of Sports Equipment"
date: ""
pages: 2
method: "tesseract:pan+eng"
script: "GURMUKHI"
needs_ocr: false
sha1: "4df92ea751b952a3"
---

<!-- page 1 -->

Sports Department, Punjab
Yuva Bhawan, Sector 42-A, Chandigarh
Corrigendum-2
Name of the work:- Purchase of Sports Equipment.
Tender ID:- 2024_DOS_127430_1
Regarding the extension of the date of opening of technical bids for the
tender issued by the department for the purchase of sports goods
during the session of the year 2024-25.
The technical bid for the tender, issued by the department for the purchase
of sports equipment during the session of the year 2024-25 which was
scheduled to be opened on 07.10.2024 at 3.30 PM at the Head Office, is
extended by 15 days due to administrative reasons. The technical bid of
the above said tender will now be opened at the Head Office on
22.10.2024 at 3.30 PM.
oar, Sports,
Punjab
C8 camscanner

<!-- page 2 -->

ਖੇਡ ਵਿਭਾਗ, ਪੰਜਾਬ
We ਭਵਨ, ਸੈਕਟਰ-42 ਏ, ਚੰਡੀਗੜ੍ਹ
ਕੋਰੀਜੰਡਮ-2
ਟੈਂਡਰ ਦਾ ਵੇਰਵਾ- ਖੋਡਾਂ ਦੇ ਸਮਾਨ ਦੀ ਖਰੀਦ ਕਰਨ ਸਬੰਧੀ।
ਟੈਂਡਰ ਆਈ.ਡੀ.- 2024 1106 _127430 1
ਸਾਲ 2024-25 ਦੇ ਸੈਸ਼ਨ ਦੌਰਾਨ ਵਿਭਾਗ ਵੱਲੋਂ ਖੇਡ ਸਮਾਨ ਦੀ ਖਰੀਦ ਕਰਨ ਸਬੰਧੀ ਲਗਾਏ ਗਏ ਟੈਂਡਰ ਦੀ
ਟੈਕਨੀਕਲ fis ਖੋਲ ਦੀ ਮਿਤੀ ਵਿੱਚ ਵਾਧਾ ਕਰਨ ਸਬੰਧੀ।
ਵਿਭਾਗ ਵੱਲੋਂ ਸਾਲ 202੫-25 ਦੇ ਸੈਸ਼ਨ ਦੌਰਾਨ ਖੇਡਾਂ ਦੇ ਸਮਾਨ ਦੀ ਖਰੀਦ ਕਰਨ ਲਈ ਲਗਾਏ
ਗਏ ਟੈਂਡਰ ਦੀ ਟੈਕਨੀਕਲ fis ਜੋ ਕਿ ਮਿਤੀ 07.10.2020 ਨੂੰ ਬਾਅਦ ਦੁਪਿਹਰ 3.30 ਵਜੋ ਮੁੱਖ ਦਫਤਰ ਵਿਖੋ
ਖੇਲੀ ਜਾਈ ਸੀ, ਜਿਸ ਵਿੱਚ ਪ੍ਰਬੰਧਕੀ ਕਾਰਡਾਂ ਕਰਕੇ 15 ਦਿਨਾਂ ਦਾ ਹੋਰ ਵਾਧਾ ਕੀਤਾ ਜਾਦਾ ਹੈ। ਇਸ ਲਈ gE ਇਸ
ਟੈਂਡਰ ਦੀ ਤਕਨੀਕੀ fs ਮਿਤੀ 22.10.20%੫ ਨੂੰ ਬਾਅਦ ਦੁਪਿਹਰ 3.3੦ ਵਜੇ ਮੁੱਖ ਦਫਤਰ ਵਿਖੇ ਖੋਲੀ ਜਾਵੇਗੀ।
wa Sate
ਪੰਜਾਬ
C8 camscanner
