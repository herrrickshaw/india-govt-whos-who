---
doc_id: "ddfae931c59f2e6d"
source_url: "https://ssgpurch.puchd.ac.in/includes/noticeboard/2025/20250722012724-importantinstructionsforcandidates.pdf?2026"
ministry: "Punjab University, P.U. Swami Sarvanand Giri Regional Centre, Punjab"
title: "Counseling schedule : PUMEET/PULEET 2025 and important instructions for candidates"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bc539bf3b91b5368"
---

<!-- page 1 -->

Important Information and Instructions for Candidates:
1. All

qualified

candidates

of

PUMEET-2025/PULEET-2025

are

provisionally eligible for the counseling and should report for counseling
as mentioned below. Any candidate reporting late on given date and time
for the counseling will have no claim on the seats already filled. However,
the candidate may be given a choice to opt from the available unfilled seats.
2. A counselling fee of Rs 1500/- (Fifteen hundred only) (Non-refundable)

will be charged via Demand Draft as per the Prospectus PUMEET2025/PULEET-2025. The demand draft should be in the favor of the
Chairman, JAC payable at Chandigarh. Counselling Fees once paid
will not be refunded. Those who attend first counselling and deposit
DD of Rs 1500/- need not pay counselling fee for 2nd round. However,
those who are attending for the first time will have to bring the
demand draft of Rs. 1500/-.
3. An admission fee of Rs 45000/- (Forty five thousand only) will be

charged via Demand Draft as per the Prospectus of PUMEET2025/PULEET-2025.The demand draft should be in the favor of the
Chairman, JAC, payable at Chandigarh .
4. A sum of Rs. 50,000/- (Fifty thousand only) as Migration Fee shall be

charged from the PUMEET-2025 candidate who is migrating from
Institutes/Universities other than Panjab University, Chandigarh. The
demand draft should be in the favor of the Registrar, Panjab University,
Chandigarh payable at Chandigarh.
5. Any candidate who wants to apply under Sports Category and Defense

category seats in any participating institute/department, must submit the
admission form/scrutiny form along with all the supporting documents in
the office of Director UIET, Panjab University, Chandigarh, by 25-072025 up to 4:00 pm. Sports trials for admission to UIET, Panjab
University Chandigarh, UIET, PUSSGRC Hoshiarpur, & Dr SSBUICET,
Panjab University Chandigarh shall be held on 29/07/2025 (tentative) in
the Panjab University sports ground. Candidates should report at 9.00 AM
(sharp) on 29.07.2025 (tentative) at Panjab University Jawahar Lal Nehru
Complex Building (Gymnasium Hall), Sector-14, Chandigarh. Candidates

<!-- page 2 -->

seeking admission at CCET, Sector-26 Chandigarh under sports category
should submit Sports Gradation certificate for academic purposes by
Sports Department, Chandigarh Administration as per their Gradation
Policy. Only Candidates who apply under sports and defense categories
and submit the required documents in

hard copy by 25/7/2025 will be

eligible for consideration under these categories at the time of counseling.
6. Provisional Merit list of sports and defence category candidates will be

displayed on the PUMEET/PULEET website on 6/8/2025 (tentative).
7. All the certificates required for the counselling must be issued by a

Competent Authority. Provisional result of Diploma for PULEET
candidates) & 1st year result of B.E/B.TECH of PUMEET candidates
should be attested by Competent Authority (Head of Institute/ Controller
of Examinations).
8. All certificates should be issued on/before the date of counseling and

presented in original for verification.
9. Admissions will be made according to the guidelines as mentioned in the

Prospectus of PUMEET-2025/PULEET-2025, available at the website of
Panjab University, Chandigarh or Panjab University Handbook of
Information 2025 and merely attending the counseling
doesn’t guaranty the admission.
10. Seat matrix will be displayed for 1st round of PUMEET-2025 counseling

on 6/08/2025 & for PULEET on 10-08-2025 and on 13-8-2025 for the
second round on the UIET website/PUMEET website/ PULEET website.
URL: https://uiet.puchd.ac.in
11. Candidates having reappear at the time of reporting for counseling

are not eligible.
12. Attending counselling in person is compulsory.

<!-- page 3 -->

COUNSELING SCHDEULE
First Round (08-08-2025) Friday, PUMEET-2025:
Venue : Room no. 315, Academic Block –II,
UIET, Panjab University, Sector-25, Chandigarh
Category

Rank

Reporting
Time

All candidates

1 to 100

9:30 am

101 onwards

2.30 pm

First Round (11-08-2025) Monday, PULEET-2025:
Venue : Room no. 315, Academic Block –II,
UIET, Panjab University, Sector-25, Chandigarh
Category

Rank

Reporting Time

All candidates

1 to 100

9:30 am
101 onwards

2.30 pm

2nd Round (14-08-2025) Thursday, PUMEET & PULEET-2025:
Reporting time- 9:00 am (Open & Reserved category)
Venue : Room no. 315, Academic Block –II,
UIET, Panjab University, Sector-25, Chandigarh
Candidates

Category

Rank

Time

PUMEET candidates

Reserved candidates

1 to all

9:30 am to 10.30 am

PULEET candidates

Reserved candidates

1 to all

11:00 am to 12.00 pm

PUMEET candidates

OPEN category (DE-reservation of

1 to all

12:30 pm

1 to all

3.00 pm

1 to all

3.30 pm

vacant reserved seats, if any)
PULEET candidates

OPEN category (DE-reservation of
vacant reserved seats, if any)

PUMEET/PULEET

All candidates

candidates (all)

(DE-reservation of Quota)
