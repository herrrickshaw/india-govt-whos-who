---
doc_id: "0fd09dfa3c3d6cd4"
source_url: "https://ssgpurch.puchd.ac.in/includes/noticeboard/2026/20261030162707-document1233.pdf?2026"
ministry: "Punjab University, P.U. Swami Sarvanand Giri Regional Centre, Punjab"
title: "Office order regarding MST (UILS Hoshiarpur)"
date: ""
pages: 1
method: "tesseract:pan+eng"
script: "LATIN"
needs_ocr: false
sha1: "97e5f1170c4e57a8"
---

<!-- page 1 -->

UNIVERSITY INSTITUTE OF LEGAL STUDIES
PANJAB UNIVERSITY SWAMI SARVANAND GIRI REGIONAL CENTRE
UNA ROAD, BAJWARA, HOSHIARPUR
PH.:-01882-282617, 282618 FAX-01882-282221
Email id: chairpersonuils@pu.ac.in, Website:www.ssgpurch.puchd.ac.in
no\AR).eussGROLAW Dated. 2a) 10/2026
Office order
Itis notified to all faculty and students of UILS, PUSSGRC, Hoshiarpur that those students who
have,not given their MST in time they will contact with their concenrned subject teachers. And
faculty members will give time for MST to the students (own choice).
Further, MST sheets will be availble with Ms, Neeru Kalia, Clerk at UILS, PUSSGRC,
Hoshiarpur.
-.... &ਇ Sood «
16 ॥407€09॥ UILS,
ਟਨ €1 oshkEpur.
OsMarpur
Issued to: all faculty and students: for necessary action.
