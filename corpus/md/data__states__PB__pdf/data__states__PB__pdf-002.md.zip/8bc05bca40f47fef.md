---
doc_id: "8bc05bca40f47fef"
source_url: "https://ayboard.in/wp-content/uploads/2021/06/20160112042251_Service-rules-Appendix-A-B.pdf"
ministry: "Board of Ayurvedic and Unani Systems of Medicine, Punjab"
title: "Download"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "434630fe8f0497c8"
---

<!-- page 1 -->

8.

In the said rules, for Appendix "A", the following Appendix shall be substituted, namely:
"APPENDIX 'A'
(See rules 3 & 8)
Serial
No.

Designation of
the post

No. of
posts

Scale of pay

1
1

2
Registrar

3
1

4
(i) 15600 - 39100 + 6600
Grade Pay
(Initial pay Rs. 25250/+
Non-practising
Allowance);
(ii) After four years,
15600-39100 +
7400
Grade Pay;
+ Nonpractising Allowance);
(iii) After nine years,
15600-39100 + 7600
Grade Pay;
+ Nonpractising Allowance);
and
(iv) After fourteen years,
15600-39100 + 7800
Grade pay + Nonpractising Allowance);

2

Superintendent

1

(i) 10300-34800

+

Percentage of appointment by

4800

Direct
appointment
5
Hundred
percent

Promotion

--

Hundred

6
--

Qualifications and Experience for appointment by Direct
Promotion
appointment
7
Should possess a degree in
Ayurvedic
Systems
of
Medicine, from a recognised
university or institution, as the
case may be, and shall have
an administrative experience
for a period not less than five
years, as Registrar in any
Board of Ayurvedic and
Unani Systems of Medicine
duly established under the
relevant law in India, after
serving as an Ayurvedic
Medical Officer in Central or
State Government, for a
period of not less than
fourteen years:
Provided that he
should be a registered
Ayurvedic and Unani System
of Medicine practitioner (in
Part-I
of
the
Register
maintained under Punjab
Ayurvedic
and
Unani
Practitioner Act, 1963.)
-From

8
--

amongst

the

<!-- page 2 -->

3

Assistant

2

4

Accountant

1

5

Stenographer

1

6

Clerk-cumcashier

1

Grade Pay
(Initial pay Rs. 18250/and
(ii) After two years,
15600-39100 + 5400
Grade Pay;
(i) 10300-34800 + 4200
Grade Pay
(Initial Pay Rs.16290/-)
; and
After four years,
(ii) 10300-34800 + 4400
Grade Pay
(Initial Pay Rs. 17420/-)
(i) 10300-34800 + 4200
Grade Pay
(Initial Pay Rs. 16290/-)
; and
(ii) After four years,
10300-34800 + 4400
Grade Pay
(Initial Pay Rs. 17420/-)
(i) 10300-34800 + 4200
Grade Pay
(Initial Pay Rs.16290/-)
; and
(ii) After four years,
10300-34800 + 4400
Grade Pay
(Initial Pay Rs. 17420/-)
(i) 10300-34800 + 3200
Grade Pay
(Initial
Pay
Rs.
13500/- and Rs. 500/-,
as
Cash
handling

Percent

Accountant or Assistant or
Stenographer, as the case
may be, who have an
experience of working as
such for a minimum period
of nine years.
From amongst the Clerks
working in the Board, who
have an experience of
working as such for a
minimum period of nine
years.

--

Hundred
Percent

--

Hundred
Percent

--

From the Clerk-cum-cashier
working in the Board, who
have an experience of
working as such for a
minimum period of nine
years.

--

Hundred
Percent

--

From
the
Steno-typist
working in the Board, who
have an experience of
working as Steno typist as
such for a minimum period
of nine years.

Hundred
Percent

--

Should
possess
the
qualifications as prescribed in
the Punjab Civil Services
(General
and
Common
Conditions of Service) Rules,

--

<!-- page 3 -->

7

Steno typist

1

8

Clerk

4

9

Driver

1

10

Daftri

1

11

Peons

2

Allowance) ; and
(ii) After four years,
10300-34800 + 3600
Grade Pay
(Initial Pay Rs. 14430/and Rs. 500/-, as Cash
handling Allowance)
(i) 10300-34800 + 3200
Grade Pay
(Initial Pay Rs.13500/-) ;
and
(ii) After four years,
10300-34800 + 3600
Grade Pay
(Initial Pay Rs. 14430/-)
(i) 10300-34800 + 3200
Grade Pay
(Initial Pay Rs. 13500/-)
; and
(ii) After four years,
10300-34800 + 3600
Grade Pay
(Initial Pay Rs. 14430/-)
5910-20200 + 2400 Grade
Pay
(Initial Pay Rs. 9880/-)

1994.

Hundred
Percent

--

Should
possess
the
qualifications as prescribed in
the Punjab Civil Services
(General
and
Common
Conditions of Service) Rules,
1994.

--

Hundred
Percent

--

Should
possess
the
qualifications as prescribed in
the Punjab Civil Services
(General
and
Common
Conditions of Service) Rules,
1994.

--

Hundred
Percent

--

--

4900-10680 + 1800 Grade
Pay
(Initial Pay Rs. 7100/-)

Hundred
Percent

--

4900-10680 + 1650 Grade
Pay
(Initial Pay Rs. 6950/-)

Hundred
Percent

--

Should
possess
the
qualifications as prescribed in
the Punjab Civil (Secretariat
State Service) Class III Rules
1976.
Should
possess
the
qualifications as prescribed in
the Punjab State (Class IV)
Service Rules, 1963.
Should
possess
the
qualifications as prescribed in
the Punjab State (Class IV)

--

--

<!-- page 4 -->

9.

12

Chowkidar

1

4900-10680 + 1650 Grade
Pay
(Initial Pay Rs. 6950/-)

Hundred
Percent

--

13

Sweeper
(Part
Time)

1

At the rates fixed by the
Deputy
Commissioner
concerned from time to
time

Hundred
Percent

--

Service Rules, 1963.
Should
possess
the
qualifications as prescribed in
the Punjab State (Class IV)
Service Rules, 1963.
--

--

--

In the said rules, in "Appendix B", in clause 1, for the word "eight", the word “ten” shall be substituted

HUSSAN LAL,
Secretary to Government of Punjab,
Department of Medical Education and Research.
