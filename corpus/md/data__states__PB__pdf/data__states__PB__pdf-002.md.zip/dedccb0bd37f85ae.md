---
doc_id: "dedccb0bd37f85ae"
source_url: "https://vigilancebureau.punjab.gov.in/uploads/notifications/order26418.pdf"
ministry: "Vigilance Bureau, Punjab"
title: "Order dated 26.07.2022"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c20f71a77f6a7624"
---

<!-- page 1 -->

Vigilanc. Burea!. Punjab

fuft; :.=-. >;ac-an. +F.i.*F.Fdrd

Vigilance Bh8w8n,Srctor.58, SAS Na8ar

ad : rlr::-:: 'roo-2oo (;i"es gH rr€ +dH)

P.honc: 0l 72-221 7100-200 (Control Roon& F.x)

lFil{

t fd i# A H aF A }T}rfu3 tiaEfi gF e Firds
FFS t=t BR im * Fx'fr-r @ { ea-o Br e F}rds ryffi

fud ?tr6 es D{'flsvr

Drffi {t'ffi

d frs f{flT6 6S }fr6 # a. }re e'tre, 8c s6rd, ffieT fr.ge fd,E {d'61aT6
rer, ffi&E fu-ei'u'i's€ s'r6 a-ec Bufs frrr'f,'g' tr fso trs' =affi ryars ?
Drfod'E !-s-d Es r# tr
fes oS rrnr d defur ++ F,"1t fu at + ffi ifr Hq Ex'kr
1ba-a.s HiS a, i-rd gE aE f€ ffi a's-c *qi ge'a' FT fgs @ r+arc 6S iH
aifrDe frr€r A 3r B'F Fdfi Id-J Ec s6rd, ffi#F fr.ft riilE d ftsu a afr?rr fl?si. i
8c s6ro, ffi#E fu.gi fr.E tB'H H l-fi i qE AE Ft'fi ?-ss. fury. r'r&r

z.

ffi

fuO g-ent * F6-tr'6 rr.s-e a-c& q-at$ red m?r
g'fr/("F&F Er{'6), }rr'*.ut.r}F.,
gv s'Et*ro,
d;aa

ffit" Et, fmar

*6Wk3arganlx-s ffi 1/-'7 -22
$ud-<s e' q-src i.6 fuftorr f g€ g.dln A fi*6-ffi rro-e, E-sa ftrs

tfiT)?a

ile'?'-

4

ro.ft-a €rrla-as ra-co yfus, ).{.}rf.Eyc' firfids flaBi,faq
ro.fva ffiar}-aras rr-cs vfux, ffi#E fEqe, Ea, ri*'a
rofie-d ffiEt;r.d ffi-c6 LrfuE, furkr +s, ffiB"
frur
fgd-r Ets+d-.d LIFF6, ffiS" fr=Oi, rtrur

5

FEIEGI

r

2
3

6

't
8
9

r

ffi,

AiTgDT. T<;II6F I8EKI. q;ITE I

f,ias 'TIgdZTEi'
3'Etd-.d hrEr.*.fr rr],+R.4, ffi*x fseA, {Fsr
rJ.ea'exU-a-ao ra-eo rffun, ,fA itrrn-d +dE-d'E *d, ffiS" fugt',rja.gr
,iga-r B'E+d-cB Wfrfi'qB';, ffi#E fE.gn, {n'El
*#rrrs atrs'6 yfuF, HE'H frg'e, a'fi rrFchrro', i.* rfflfcn.d,
A irtq-d, ilfr ufurl'e,dfr ftifl:ta, A'fr Ef&r',
nh ftR.e.fiE a-ars nd rr:ry:x'u', Eifohi.e

A-*s s-#

r

10.

ll.
t3.
14.

t5.

flE.€'-g-LIH Brfu+dzd, HtfF ft€a, frrEr

*ro-g-a"Eta-ro, ffi&"

ffi, rirur

d-r<-g-8.f.*.fi, h{.){.Fr{r, ffi&n

ffi, faur

d-ra-z-Bud trnt*as rres ufus, ffi&n fuTo, faur
aua+i +srr., ffiilr ft€t, lfosr
a-sdx- r rx3 z

ffitt fu-Bi, ria's

r

Ea-eE-r ?E M#H +6/ffi#F q6a, lf*ur

(f,,,-u= u.., n+, ;1$f,n.,1.,*r..
FEmt STgoEreE/ArrrerH-,

EFi L{u dfr+dad,
f<-fr#p!$t, frur
