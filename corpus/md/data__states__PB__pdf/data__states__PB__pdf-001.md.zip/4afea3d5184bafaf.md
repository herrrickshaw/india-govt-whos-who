---
doc_id: "4afea3d5184bafaf"
source_url: "https://prbdb.punjab.gov.in/files/enl/appropriatemagnitude.pdf"
ministry: "Punjab Roads and Bridges Development Board (PRBDB), Punjab"
title: "Regarding decision on the definition of 'appropriate magnitude' to be specified in Clause 19 & 20 of Instruction of Enlistment"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "184481e9f417faeb"
---

<!-- page 1 -->

rhTE REIEI

fddHE

3 rr+-t

frn f€E
tt-t{

*d-JFr

)+A

f,+$,ti
fuH'

:E-47'

i09 Pt

e '-o3-

ono the definition

magnitude" to be

'word

e19, 20 of lnstructions

E

***iLi(

4TT6Pffi6 fHffi

w07314312023

H.t{& r:im Er€rF xffi6

rya{ eB

ffi dr0

iE ro*l i-B tnstructions of Entl

)15

19 vtr3 20

works of appropriate magnituder " S

3

red and executed

kd

tendering limit as
f6rrf'H'1Y al
