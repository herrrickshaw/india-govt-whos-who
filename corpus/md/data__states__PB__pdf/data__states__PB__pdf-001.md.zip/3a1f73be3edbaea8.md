---
doc_id: "3a1f73be3edbaea8"
source_url: "https://www.punjabmedicaleducation.org/PDF%202025/PMES%20Rules%202016%20upto%2029.05.2025.pdf"
ministry: "Medical Education and Research Department, Punjab"
title: "PMES Rules 2016"
date: ""
pages: 47
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "92df09c095cddd54"
---

<!-- page 1 -->

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

195

PART III
GOVERNMENT OF PUNJAB
DEPARTMENT OF MEDICAL EDUCATION AND RESEARCH
NOTIFICATION
The 14th March, 2016
No.GSR.16/Const./Art.309/2016.- In exercise of the powers conferred by the proviso
to article 309 of the Constitution of India, and all other powers enabling him in this behalf, the
Governor of Punjab is pleased to make the following rules regulating the recruitment and
conditions of Service of the persons appointed to the Punjab Medical Education (Group-A)
Service, namely:
RULES
1. Short title, commencement and application.- (1) These rules may be called the Punjab
Medical Education (Group -A) Service Rules, 2016.
(2) They shall come into force on and with effect from the date of their publication in
the Official Gazette .
(3) They shall apply to all the posts specified in Appendix ‘A’.
2.

Definitions .- In these rules, unless the context otherwise requires,(a)

“Appendix” means an Appendix appended to these rules ;

(b)

“Director “ means the Director Medical Education Research, Punjab ;

(c)

“Faculty” means teachers working in the Government Medical Colleges of the
State as Principals, Medical Superintendents, Professors, Associate Professors
and Assistant Professors;

(d)

“Government” means the Government of the State of Punjab in the Department
of Medical Education and Research ;

(e)

“Recognized Medical College” means any Medical College and Hospital recognized
by the Medical Council of India;

(f)

“Recognized University” means any university incorporated by law in any of the
States of India and recognized by Medical Council of India and/or University
Grants Commission; and

(g)

“Service” means the Punjab Medical Education (Group- A) Service.

3. Number and character of posts.- The Service shall comprise the posts mentioned in
Appendix ‘A’:

<!-- page 2 -->

196

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

Provided that nothing in these rules shall affect the inherent right of the Government to
add to or reduce the number of such posts or create new posts with different designations
and scales of pay, whether permanently or temporarily.
4. Appointing Authority.- All appointments to the posts in the Service shall be made by the
Government.
5
Pay of Members of the Service. - The members of the Service shall be entitled to such
scales of pay as may be authorized by the Government of Punjab in the Department of
Finance from time to time. The scales of pay at present in force in respect of the members
of the Service are given in Appendix ‘A’.
6. Method of appointment, qualification and experience.- (1) Appointment to the Service
shall be made in the manner as specified against that post in Appendix ‘B’ :
Provided that if no suitable candidate is available for appointment by promotion and by
direct appointment then appointment to the Service shall be made by transfer of a person
holding a similar or an identical post under the State Government or Government of India.
(2) No person shall be appointed to any post in the Service, unless he possesses the
educational qualification and experience, as specified against that post in Appendix ‘B’
(3) Appointment to the Service by promotion shall be made on the basis of seniority
cum- merit, but no person shall have any right to claim promotion on the basis of seniority
alone.
7. Knowledge of Punjabi language.- No person appointed to any post in the Service by
direct appointment shall be retained in the Service, unless he has passed an examination of
Punjabi language equivalent to Matriculation standard within a period of three years from
the date of his appointment to the Service.
8. Age.- (1) No person shall be appointed to any post in the Service by direct appointment
or by transfer, in case he is more than forty years of age in the case of Assistant Professor,
forty five years of age in the case of Associate Professor and fifty years of age in the case
of Professor:
Provided that the Government, may in special circumstances to be recorded in writing,
relax the upper age limit.
(2) In the case of in-service candidates (i.e. persons already in regular employment of
any department of Punjab Government/ any other State Government/ Government of India),
applying for direct appointment for any post in the Service, there shall be a relaxation of eight
years in the upper age limit.

<!-- page 3 -->

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

197

(3) In the case of Punjab Civil Medical Services candidates, the maximum age limit
for promotion to the post of Assistant Professor shall be fifty years.
(4) A person promoted to the post of Director shall work as such up to the age of
fifty eight years. Thereafter, he shall return back to his previous post.
9. Private Practice .- No member of the Service shall accept remuneration in any form
for providing any service from any source other than the State Government, Central
Government, under national programs or under academic exchange programs including
examination remuneration.
10. Discipline, punishment and appeal .- (1) In the matters of discipline, punishment and
appeal, members of the Service shall be governed by the Punjab Civil Services (Punishment
and Appeal) Rules, 1970, as amended from time to time.
(2) The authority empowered to impose penalties as specified in rule 5 of the Punjab
Civil Services (Punishment and Appeal) Rules, 1970, in respect of the members of the
Service shall be the Government.
11. Application of the Punjab Civil Services (General and Common Conditions of Service)
Rules, 1994.- (1) In respect of the matters which are not specifically provided in these rules,
the members of Service shall be governed by the provisions of the Punjab Civil Services
(General and Common Conditions of Service) Rules, 1994, as amended from time to time.
(2) The Punjab Civil Services (General and Common Conditions of Service) Rules, 1994,
at present in force, are contained in Appendix ‘C’.
12. Interpretation.- If any question arises as to the interpretation of the rules, the Government
in consultation with the Department of Personnel shall decide the same.
13. Repeal and saving.- The Punjab Medical Education Service (Class I) Rules, 1978 and
the Punjab Medical Education State Service (Class II) Rules, 1979 in so far as they are
applicable to the members of the Service are hereby repealed:
Provided that any order issued or any action taken under the rules so repealed, shall be
deemed to have been issued or taken under the corresponding provisions of these rules.

<!-- page 4 -->

198

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)
APPENDIX ‘A’
[See rules 1(3), 3 and 5]

Serial Designations of
No. the Posts

Temporary

No. of posts
Permanent

Total

Scale of Pay
(Pay Band +Grade Pay)

1

2

3

4

5

6

1

Director

-

1

1

37400-67000 +10000

2

Joint Director

1

-

1

37400-67000 +10000

3

Principal

2

-

2

37400-67000 +10000

4

Vice Principal

2

-

2

37400-67000 +10000

5

Medical Superintendent

2

-

2

37400-67000 +10000

6

Deputy Medical
Superintendent

2

-

2

37400-67000 +8900

7

Professor

40

114

154

37400-67000 +10000

8

Associate Professor

40

142

182

37400-67000 +8900

9

Assistant Professor

150

140

290

37400-67000 +8600

Note:-The details/bifurcation of the posts specified against serial nos.3 to 9 above are given
in Appendices ‘A-1’ to ‘A-5’.

<!-- page 5 -->

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

199

APPENDIX-‘A-1’
(See Note below Appendix-‘A’)
Serial Designation
No. of the post

Government Medical
College, Amritsar

Government Medical
College, Patiala

Permanent

Temporary

Permanent

Temporary

Total

1

Principal

-

1

-

1

2

2

Vice- Principal

-

1

-

1

2

<!-- page 6 -->

200

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)
APPENDIX-‘A-2’
(See Note below Appendix-‘A’)

Serial Designation
No. of the post

Government Medical
Government Medical
College Hospital, Amritsar College Hospital, Patiala
Permanent

Temporary

Permanent

Temporary

Total

1

Medical Superintendent -

1

-

1

2

2

Deputy Medical
Superintendent

1

-

1

2

-

<!-- page 7 -->

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

Serial Name of the
No. Department

201

APPENDIX-‘A-3’
(See Note below Appendix ‘A’)
Designation of the post:- Professor
Government
Government
Medical College,
Medical College,
Amritsar
Patiala
Permanent Temporary Total Permanent Temporary Total

1

2

3

4

5

6

7

8

1

Anatomy

2

-

2

2

-

2

2

Physiology

2

-

2

2

-

2

3

Biochemistry

1

1

2

1

1

2

4

Pathology

2

-

2

2

-

2

5

Microbiology

2

-

2

2

-

2

6

Pharmacology

2

-

2

2

-

2

7.

Forensic Medicine 1

-

1

1

-

1

8

Community
2
Medicine including
Public Health
General Medicine 6
General Surgery 6
Obstetrics and
4
Gynecology
Paediatrics
2
Tuberculosis and 2
Respiratory
Medicine/
Pulmonary
Medicine
Psychiatry
1
Dermatology,
2
Venereology and
Leprosy
Orthopaedics
2
Anaesthesiology 3
including
ICCU etc

1

3

2

1

3

1

6
6
5

6
6
5

-

6
6
5

1
-

3
2

3
2

-

3
2

1
-

2
2

2
2

-

2
2

2
2

4
5

4
2

3

4
5

9
10
11
12
13

14
15

16
17

<!-- page 8 -->

202

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

18

Radio-diagnosis

2

1

3

2

1

3

19

Radiotherapy

1

-

1

1

-

1

20

Oto-RhinoLaryngology

2

-

2

2

-

2

21

Ophthalmology

2

-

2

2

-

2

22

Nuclear Medicine -

1

1

-

1

1

23

Physical Medicine and Rehabilitation

1

1

-

1

1

24

Immuno
Haematology
and Blood
Transfusion

-

1

1

1

-

1

25

Hospital
Administration

-

1

1

-

1

1

26

Neonatalogy

-

1

1

-

1

1

27.

Cardiology

1

-

1

1

-

1

28.

Clinical Pathology -

1

1

1

-

1

29

Endocrinology

-

1

1

-

1

1

30

Medical
Gastroenterology

1

1

-

1

1

31

Medical Oncology -

1

1

-

1

1

32

Nephrology

-

1

1

-

1

1

33

Neurology

-

1

1

-

1

1

34

Cardio Vascular & 1
Thoracic Surgery

-

1

1

-

1

35

Urology

1

-

1

1

-

1

36

Neuro-Surgery

-

1

1

-

1

1

37

Paediatric Surgery 1

-

1

1

-

1

38

Plastic &
Reconstructive
surgery

1

-

1

1

-

1

39

Surgical Oncology -

1

1

-

1

1

Total

23

77

60

17

77

54

<!-- page 9 -->

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

203

APPENDIX-‘A-4’
(See Note below Appendix ‘A’)
Designation of the post:- Associate Professor
Serial Name of the
Government
Government
No. Department
Medical College,
Medical College,
Amritsar
Patiala
Permanent Temporary Total Permanent Temporary
1
1
2
3
4
5
6
7.
8

9
10
11
12
13

14
15

16
17

Total

2
3
Anatomy
3
Physiology
2
Biochemistry
1
Pathology
4
Microbiology
2
Pharmacology
2
Forensic Medicine 1
Community
2
Medicine
including Public
Health
General Medicine 6
General Surgery 6
Obstetrics and
4
Gynecology
Paediatrics
3
Tuberculosis and 2
Respiratory
Medicine/
Pulmonary
Medicine
Psychiatry
1
Dermatology,
1
Venereology and
Leprosy
Orthopaedics
3

4
1
1
1
1
1
1

5
3
3
2
5
3
2
2
3

6
3
3
2
5
2
2
2
2

7
1
1

8
3
3
2
5
3
2
2
3

1

6
6
5

6
6
5

-

6
6
5

-

3
2

3
2

-

3
2

2
1

3
2

3
1

1

3
2

1

4

4

-

4

Anaesthesiology
including
ICCU etc

1

5

4

1

5

4

<!-- page 10 -->

204

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

18

Radio-diagnosis

2

5

7

5

2

7

19

Radiotherapy

1

-

1

1

-

1

20

Oto-RhinoLaryngology

2

-

2

2

-

2

21

Ophthalmology

3

1

4

4

-

4

22

Nuclear Medicine -

1

1

-

1

1

23

Physical
Medicine and
Rehabilitation

-

1

1

-

1

1

24

Immuno
1
Haematology and
Blood
Transfusion

-

1

1

-

1

25

Hospital
Administration

-

1

1

-

1

1

26

Neonatalogy

1

-

1

1

-

1

27.

Cardiology

1

-

1

1

-

1

28.

Clinical Pathology 1

-

1

1

-

1

29

Endocrinology

-

1

1

-

1

1

30

Medical
Gastroenterology

1

1

-

1

1

31

Medical Oncology -

1

1

-

1

1

32

Nephrology

1

-

1

1

-

1

33

Neurology

1

-

1

1

-

1

34

Cardio Vascular & 1
Thoracic Surgery

-

1

1

-

1

35

Urology

1

-

1

1

-

1

36

Neuro-Surgery

-

1

1

-

1

1

37

Paediatric Surgery 1

-

1

1

-

1

38

Plastic &
Reconstructive
surgery

1

-

1

1

-

1

39

Surgical Oncology -

1

1

-

1

1

Total

26

91

77

14

91

65

<!-- page 11 -->

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

205

APPENDIX-‘A-5’
(See Note below Appendix ‘A’)
Designation of the post:- Assistant Professor
Serial Name of the
Government
Government
No. Department
Medical College,
Medical College,
Amritsar
Patiala
Permanent Temporary Total Permanent Temporary
1
1
2
3
4
5
6
7
8

9
10
11
12
13

14
15

16
17

2
3
Anatomy
Physiology
Biochemistry
Pathology
Microbiology
Pharmacology
Forensic Medicine 1
Community
5
Medicine including
Public Health
General Medicine 7
General Surgery 7
Obstetrics and
4
Gynecology
Paediatrics
4
Tuberculosis and 2
Respiratory
Medicine/
Pulmonary
Medicine
Psychiatry
2
Dermatology,
2
Venereology and
Leprosy
Orthopaedics
3
Anaesthesiology 5
including
ICCU etc

Total

4
4
4
4
4
4
3
1
-

5
4
4
4
4
4
3
2
5

6
2
5

7
4
4
4
4
4
3
-

8
4
4
4
4
4
3
2
5

2
2
4

9
9
8

9
9
4

4

9
9
8

2
1

6
3

5
3

1
-

6
3

3
1

5
3

3
2

2
1

5
3

5
5

8
10

5
6

3
4

8
10

<!-- page 12 -->

206
18
19
20
21
22
23
24

25
26
27.
28.
29
30
31
32
33
34
35
36
37
38

39

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

Radio-diagnosis 4
Radiotherapy
1
Oto-Rhino4
Laryngology
Ophthalmology
4
Nuclear Medicine Physical Medicine and Rehabilitation
Immuno
Haematology
and Blood
Transfusion
Hospital
Administration
Neonatalogy
1
Cardiology
1
Clinical Pathology Endocrinology
Medical
Gastroenterology
Medical
Oncology
Nephrology
1
Neurology
1
Cardio Vascular & 1
Thoracic Surgery
Urology
1
Neuro-Surgery
Paediatric Surgery 1
Plastic &
1
Reconstructive
surgery
Surgical Oncology Total
63

2
2
-

6
3
4

6
1
3

2
1

6
3
4

2
3

4
2
3

4
-

2
3

4
2
3

2

2

-

2

2

2

2

-

2

2

1
1
2
2
2

2
2
2
2
2

1
1
1
1

1
1
2
1
1

2
2
2
2
2

2

2

-

2

2

1
1
1

2
2
2

1
1
1

1
1
1

2
2
2

1
2
1
1

2
2
2
2

1
1
1

1
2
1
1

2
2
2
2

2
82

2
145

77

2
68

2
145

<!-- page 13 -->

(1)
1
2

Designations
of the posts

Percentage for appointment
by
Direct
Promotion
appointment
(2)
(3)
(4)
Director
Hundred
percent
Joint Director Hundred
percent

Principal

4

Vice Principal -

5

Medical
Superintendent
Deputy
Medical
Superintendent

6

-

Hundred
percent
Hundred
percent
Hundred
percent
Hundred
percent

-

-

-

(6)
From amongst the panel of
senior most Professors.
By inviting applications from
amongst the Professors and
Associate Professors who have
an experience of teaching for a
minimum period of eight years.
From amongst the panel of
senior most Professors.
From amongst the panel of
senior most Professors.
From amongst the panel of
senior most Professors.
From amongst the panel of
Associate Professors who have
an experience of teaching for a
minimum period of seven years.

207

3

(5)
-

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

Serial
No.

APPENDIX ‘B’
[See rule 6]
Method of appointment , qualification and experience for
appointment by
Direct appointment
Promotion

<!-- page 14 -->

Twenty five
percent

Seventy five
percent

8

Associate
Professor

Twenty five
percent

Seventy five
percent

From amongst the candidates,(i) who have an experience of
teaching for a minimum period of
ten years after completion of Post
Graduation, which shall include
three years experience as Reader/
Associate Professor in the
concerned specialty in a recognized
Post Graduate Medical College; and
(ii) who have four Research
Publications (published or accepted)
to their credit, including two
publications as Reader/Associate
Professor in PubMed. Excerpta
Medica/Embased Medica or Index
Medicus or Index Copernicus
or Scopus or Medline Journals.
From amongst the candidates,(i) who have an experience of
teaching for a minimum period of
seven years after completion of
Post Graduation, which shall include
four years experience as Assistant

From amongst the Associate
Professors,(i) who have an experience of
teaching for a minimum period
of three years in the concerned
subjects; and
(ii) who have four Research
Publications (published or
accepted) to their credit,
including two publications as
Reader/Associate Professor in
PubMed. or Excerpta Medica/
Embased Medica or Index
Medicus or Index Copernicus
or Scopus or Medline Journals.

From amongst the Assistant
Professors,(i) who have an experience of
working as such for a minimum
period of four years in the
concerned subjects; and

208

Professor

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

7

<!-- page 15 -->

Assistant
Professor

Twenty five
percent

Seventy five
percent

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

9

209

Professor in the concerned specialty (ii) who have two Research
in recognized Post Graduate
Publications (published or
Medical College; and
accepted) to their credit,
(ii) who have two Research
including two publications as
Publications (published or accepted) Assistant Professor in PubMed.
to their credit, including two
or Excerpta Medica/Embased
publications as Assistant Professor Medica or Index Medicus or
in PubMed. or Excerpta Medica/
Index Copernicus or Scopus or
Embased Medica or Index Medicus Medline Journals.
or Index Copernicus or Scopus or
Medline Journals.
From amongst the candidates who, By inviting applications from the
after completion of Post Graduation, members of the Punjab Civil
have an experience of teaching for Medical Services (PCMS) cadre
a minimum period of three years as who, after the completion of Post
Senior Resident/Registrar/Lecturer/ Graduation, have an experience
Demonstrator/ Tutor or equivalent or of teaching for a minimum
higher teaching faculty posts in the period of three years as Senior
concerned specialty in a recognized Resident/ Registrar/ Lecturer/
Post Graduate Medical College.
Demonstrator/ Tutor or
equivalent or higher teaching
faculty posts in the concerned
specialty in a recognized Post
Graduate Medical College.

<!-- page 16 -->

2)

4)

5)
6)
7)

8)
9)
Serial No.
1.

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

3)

The post of Joint Director shall be a tenure post for a period of two years. Similarly, the posts of Vice Principal and
Deputy Medical Superintendent shall also be tenure posts for a period of three years each.
No person shall be appointed to the Service by direct appointment or by promotion unless he has three years’
teaching experience in the concerned specialty as Senior Resident/ Lecturer/ Tutor/ Registrar/demonstrator after
completion of three years of Post Graduation in that specialty.
The relaxation of one year in teaching experience for appointment by promotion to the post of Assistant Professor
shall be given to in-service candidates who have done four years of regular rural service in Punjab.
The condition of experience of teaching for a minimum period of three years for appointment to the post of
Assistant Professor by direct appointment or by promotion shall not be applicable in the case of those candidates,
who have done super-specialty course.
A candidate who has done Diplomate of National Board (DNB), which fulfills the equivalence criteria of MCI for
MD/MS/ DM/MCh shall be considered to have met the requirement of post-graduation qualification.
The Non-Medical teachers presently working in the Department shall be eligible to be considered for promotion.
However, they shall not hold any administrative post.
Principals of Government Medical Colleges and Medical Superintendents of Government Medical College Hospitals
shall cease to be the Heads of Department. However, they shall be allowed to teach and practice in the department
and remain in-charge of a Unit.
Principal of a Government Medical College shall also be Dean of that College.
Minimum qualification for appointment into the Service by direct appointment or by promotion on a post in following
specialties shall be as under:Name of the Specialty
Minimum Qualification
Anatomy
M.S. (Anatomy)/ M.D.(Anatomy)

210

Note :- 1)

<!-- page 17 -->

9.
10.
11.
12.
13.
14.
15.

General Medicine
General Surgery
Obstetrics and Gynaecology
Pediatrics
Tuberculosis and Respiratory Medicine/
Pulmonary Medicine
Psychiatry
Dermatology, Venereology and Leprosy

16.
17.
18.
19.
20.

Orthopaedics
Anaesthesiology including ICU
Radio-diagnosis
Radiotherapy
Oto-Rhino- Laryngology

M.D. (Physiology)
M.D. (Biochemistry)
(Clinical Pathology shall be part of Pathology) M.D.(Pathology)
M.D.(Bacteriology)/ M.D.(Microbiology)
M.D.(Pharmacology)
M.D. (Forensic Medicine)
M.D.(Social & Preventive Medicine)/ MD (Community Medicine)/
MD (Preventive and Social Medicine)
M.D.(Medicine) M.D.(General Medicine)
M.S.(Surgery)/ M.S.(General Surgery)
M.D.(Obst. & Gynae.)/ M.S.(Obst. & Gynae.)
M.D.(Paediatrics)
M.D. (Tuberculosis)/ M.D.(TB & Respiratory Diseases)/ MD
(Pulmonary Medicine)/ M.D.(TB & Chest Diseases)
M.D.(Psychiatry)
M.D.(Dermatology & Venereology) M.D.(Dermatology)
M.D.(Dermatology, Venereology & Leprosy)
M.S. (Orthopaedics)
M.D. (Anaesthesiology)/ M.S. (Anaesthesiology)
M.D.(Radio-Diagnosis)/ M.D.(Radiology) / M.S. (Radiology)
M.D.(Radiotherapy)
M.S.(Oto-Rhino Laryngology) / MS (ENT)

211

Physiology
Biochemistry
Pathology/Clinical Pathology
Microbiology
Pharmacology
Forensic Medicine
Community Medicine including Public Health

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

2.
3.
4.
5.
6.
7.
8.

<!-- page 18 -->

23.

Physical Medicine and Rehabilitation

24.

Immuno Haematology and Blood Transfusion
(Department shall be called Transfusion
Medicine)

25.

Hospital Administration

26.

Neonatalogy

27.

Cardiology

M.S. (Ophthalmology)/M.D.(Ophthalmology)
M.D. (Nuclear Medicine) / M.D.(Radio-Therapy) with two
years experience in Nuclear Medicine in a recognised centre/
M.D.(Medicine) with DRM or DNM/M.D. (Radio- Diagnosis)
with two years experience in Nuclear Medicine in a advanced
teaching centre.
M.D.(P.M.R)/M.D.(Medicine) with Diploma in PMR/
M.S.(General Surgery)/ M.S.(Orthopaedics) with two years
special training in the Speciality of Physical Medicine and
Rehabilitation (Rehabilitation Medicine) or three years of
equivalent training approved in the subject in any approved
institution in India.
D.M.(Immunology) or M.D.(Immuno-haematology & Blood
Transfusion/ M.D. (Pathology)/ M.D. (Bacteriology)/
M.D.(Microbiology) with three years teaching experience or
special training in the Deptt. of Immuno-Haematology &
Blood Transfusion
M.D.(Health Administration)/ M.D.(Hospital Administration)/
M.D.(Community Health Administration)
D.M.(Neonatology)/ M.D.(Paediatrics) with three years
special training in Neonatology in an advance teaching centre.
D.M.(Cardiology)

212

Ophthalmology
Nuclear Medicine

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

21.
22.

<!-- page 19 -->

Endocrinology
Medical Gastroenterology
Medical Oncology

31.
32.
33.

Nephrology
Neurology
Cardio Vascular & Thoracic Surgery

34.
35.
36.
37.

Urology
Neuro-surgery
Paediatric Surgery
Plastic & Reconstructive Surgery

38.

Surgical Oncology

D.M.(Endocrinology)
D.M.( Medical Gastroenterology)/ D.M.(Gastroenterology)
D.M.(Medical Oncology)/ M.D.(Medicine) or M.D.
(Radio-therapy) or M.D. (Paediatrics) with three years special
training in Medical Oncology in an advance teaching centre.
D.M.(Nephrology)
D.M.(Neurology)
M.Ch.(Cardio Vascular & Thoracic Surgery)/ M.Ch.
(Cardiac Surgery)/
M.Ch.(Urology)
M.Ch.(Neuro-Surgery)
M.Ch.(Paediatric Surgery)
M.Ch.(Plastic & Reconstructive Surgery)/M.Ch.
(Plastic Surgery)
M.Ch.(Surgical Oncology/ Head and Neck Surgery/
Gynaecological Oncology) /M.S.(Surgery)/ or M.S.(E.N.T.) or
M.S.(Orthopaedics) or M.D.(Obst. & Gynae.) with three years
special training in Surgical Oncology in advanced teaching
cancer institute.

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

28.
29.
30.

213

<!-- page 20 -->

PUNJAB GOVT. GAZ. (EXTRA). AUGUST 11, 2020

363

(SRVN 20, 1942 SAKA)
PART III
GOVERNMENT OF PUNJAB
DEPARTMENT OF MEDICAL EDUCATION AND RESEARCH
NOTIFICATION
The 7th August, 2020
No. G.S.R. 53/Const./Art.309/Amd.(1)/2020.- In exercise of the
powers conferred by the proviso to Article 309 of the Constitution of India
and all other powers enabling him in this behalf, the Governor of Punjab is
pleased to make the following rules further to amend the Punjab Medical
Education (Group-A) Service Rules, 2016, namely:RULES
1.

(1) These rules may be called the Punjab Medical Education
(Group-A) Service (First Amendment) Rules, 2020.
(2) They shall come into force on and with effect from the date of
their publication in the Official Gazette.

2.

In the Punjab Medical Education (Group-A) Service Rules, 2016

(hereinafter referred to as the said rules), in Appendix 'B', under column
No. 6,(i)

in serial No. 2, for the words "eight years", the words "six years"
shall be substituted;

(ii) in serial No. 6, for the words "seven years", the words "five years"
shall be substituted; and
(iii) in serial No. 9, for the words "three years", the words "two years"
shall be substituted.

D.K. TIWARI,
Principal Secretary to Government of Punjab,
Department of Medical Education and Research.
2080/8-2020/Ph. Govt. Press, S.A.S. Nagar

<!-- page 21 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 12, 2021
(PAUSA 22, 1942 SAKA)

5

PART III
GOVERNMENT OF PUNJAB
DEPARTMENT OF MEDICAL EDUCATION AND RESEARCH
NOTIFICATION
The 8th January, 2021
No. G.S.R. 01/Const./Art.309/Amd.(2)/2021.–In exercise of the
powers conferred by the proviso to Article 309 of the Constitution of India and
all other powers enabling him in this behalf, the Governor of Punjab is pleased
to make the following rules further to amend the Punjab Medical Education
(Group-A) Service Rules, 2016, namely:RULES
1.

(1)

These rules may be called the Punjab Medical Education
(Group-A) Service (Amendment) Rules, 2021.

(2)

They shall come into force on and with effect from the date of their
publication in the Official Gazette.

2.
In the Punjab Medical Education (Group-A) Service Rules, 2016
(hereinafter referred to as the said rules), for the words "Medical Council of
India" or "MCI" wherever occurring, the word "National Medical Commission
or any Council or Board constituted by the Government of India" shall be
substituted.
3. In the said rules, in rule 2, for clauses (c), (f) and (g), the following
clauses shall be substituted, namely:"(c) “Faculty” means teachers working in the Government Medical
Colleges of the State as Director-Principals, Medical
Superintendents, Professors, Associate Professors and Assistant
Professors ;
(f)

“Recognized Post Graduate Medical College” for a speciality means
any Medical College with a recognized post graduate course in
that speciality ;

(g)

“Recognized University” means any university incorporated by law
in any of the States of India and recognized by the National Medical
Commission or any Council or Board constituted by the Government
of India and/ or University Grants Commission;

(h)

“Service” means the Punjab Medical Education (Group- A) Service;
and

<!-- page 22 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 12, 2021
(PAUSA 22, 1942 SAKA)
(i)

6

"Super speciality course" means Doctorate of Medicine (D.M) or
Master of Chirurgiae (M.Ch.) or equivalent from the recognized
Post Graduate Medical College."

4. In the said rules, in rule 6, for sub-rule (1), the following shall be substituted,
namely:"(1) Appointment to the Service shall be made in the manner as
specified against that post in Appendix ‘B’:
Provided that in case no suitable person is available for
promotion to any post in the Service, the same shall be filled up by
direct appointment :
Provided that if no suitable candidate is available for
appointment by promotion and by direct appointment then
appointment to the Service shall be made by deputation or transfer
of a person holding a similar or an identical post under the State
Government or Government of India."
5.

In the said rules, in rule 8, sub-rule (4) shall be omitted.

6. In the said rules, in rule 10, for sub-rule (2), the following shall be substituted,
namely:"(2) The authority empowered to impose penalties as specified in rule 5 of
the Punjab Civil Services (Punishment and Appeal) Rules, 1970, and
the appellate authority thereunder in respect of the members of service,
shall be as specified in Appendix B-1.
(3)

The authority competent to hear the appeal against an order as
specified under rule 15 of the Punjab Civil Services (Punishment
and Appeal) Rules, 1970, other than an order imposing any of the
penalties as mentioned in Appendix B-1, shall be as specified in
Appendix B-2."

7. In the said rules, in Appendix 'A', under column 2, in serial No. 3, for the
word "Principal", the words "Director-Principal" shall be substituted.
8. In the said rules, in Appendix 'A-1',- in serial No. 1, for the word "Principal",
the words "Director-Principal" shall be substituted.
9.

In the said rules, in Appendix 'B',—
(a)

under column 2,— in serial No. 3, for the word "Principal", the
words "Director-Principal" shall be substituted;

(b)

under column 6,—

<!-- page 23 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 12, 2021
(PAUSA 22, 1942 SAKA)
(i)

7

in serial No. 1, for the existing entry, the following entry shall
be substituted, namely:"From amongst the panel of five senior most Professors
who have an experience of working as Professor for a
minimum period of five years.";

(ii) in serial No. 3, for the existing entry, the following entry shall
be substituted, namely:"From amongst the panel of five senior most Professors
who have an experience of working as Professor for a
minimum period of five years.";
(iii) in serial No. 4, for the existing entry, the following entry shall
be substituted, namely:"From amongst the panel of five senior most Professors
who have an experience of working as Professor for a
minimum period of five years.";
(iv) in serial No. 5, for the existing entry, the following entry shall
be substituted, namely:"From amongst the panel of ten senior most Professors
with a recognized post graduate medical qualification
from a recognized university or institution with ten years
experience on administrative post.";
(v)

in serial No. 6, for the existing entry, the following entry shall
be substituted, namely:"From amongst the panel of ten senior most Associate
Professors who have an experience of teaching for a
minimum period of five years.";

(c)
" 7.

Professor

for serial numbers 7, 8 and 9 and the entries relating thereto, the
following shall be substituted, namely:–
Twenty-five Seventy-five From amongst the
From amongst the
per cent
per cent
candidates,–
Associate Professors,–
(i) who have an
experience of teaching
for a minimum period
of ten years after
completion of Post

(i) who have an
experience of teaching
for a minimum period of
three years in the
concerned subjects; and

<!-- page 24 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 12, 2021
(PAUSA 22, 1942 SAKA)
Graduation, which
shall include three
years experience as
Reader or Associate
Professor and four
years experience as
Assistant Professor
in the concerned
specialty in a
recognised Post
Graduate Medical
College and three
years as Senior
Resident or Registrar
or Lecturer or
Demonstrator or
Tutor or equivalent
or higher teaching
faculty posts in the
concerned specialty
in a recognized
Medical College;
and
(ii) who have four
Research
Publications
(published or
accepted) to their
credit, including two
publications as first
author or
corresponding author
as Reader or
Associate Professor
in PubMed or
Excerpta Medica or
Embased Medica or
Index Medicus
Journals.

8

(ii) who have four
Research Publications
(published or accepted) to
their credit, including two
publications as first
author or corresponding
author as Reader or
Associate Professor in
PubMed or Excerpta
Medica or Embased
Medica or Index Medicus
Journals.

<!-- page 25 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 12, 2021
(PAUSA 22, 1942 SAKA)
8.

Associate
Professor

Twenty-five
per cent

Seventy-five
per cent

9.

Assistant
Professor

Twenty-five
per cent

Seventy-five
per cent

9

From amongst the
From amongst the
candidates,–
Assistant Professors,–
(i) who have an
(i) who have an
experience of teaching
experience of working
for a minimum period
as such for a
of seven years after
minimum period of
completion of Post
four years in the
Graduation, which shall
concerned subjects;
include four years
and
experience as Assistant (ii)who have two
Professor in the
Research Publications
concerned specialty in
(published or
recognised Post
accepted) to their
Graduate Medical
credit, including two
College and three years
publications as first
as Senior Resident or
author or
Registrar or Lecturer or
corresponding author
Demonstrator or Tutor
as Assistant Professor
or equivalent or higher
in PubMed or
teaching faculty posts in
Excerpta Medica or
the concerned specialty
Embased Medica or
in a recognized Medical
Index Medicus
College; and
Journals.
(ii) who have two Research
Publications (published
or accepted) to their
credit, including two
publications as first
author or corresponding
author as Assistant
Professor in PubMed or
Excerpta Medica or
Embased Medica or
Index Medicus
Journals.
From amongst the
By inviting
candidates who, after
application from the
members of the Punjab
completion of Post

<!-- page 26 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 12, 2021
(PAUSA 22, 1942 SAKA)
Graduation, have an
experience of teaching
for a minimum period of
three years as Senior
Resident or Registrar or
Lecturer or Demonstrator
or Tutor or equivalent or
higher teaching faculty
posts in the concerned
specialty in a recognized
Medical College

10

Civil Medical Services
(PCMS) cadre who, after
the completion of Post
Graduation, have an
experience of teaching for
a minimum period of two
years as Senior Resident or
Registrar or Lecturer or
Demonstrator or Tutor or
equivalent or higher
teaching faculty posts in
the concerned specialty in
a recognized Medical
College."

10. In the said rules, in Appendix 'B', for Notes No. 2, 3,7, 8 and 9 thereunder,
the following shall be substituted, namely:"2) For the post of Professor and Associate Professor, experience
from a Recognised Post Graduate Medical College means
experience from the date of grant of letter of permission (L.O.P)
by Medical Council of India i.e. from the date of start of Post
Graduate Course. The experience from date of letter of permission
(L.O.P) shall still be counted even if the college is yet to get
recognition for a Post Graduate course.
3) The relaxation of one year in teaching experience for appointment
by promotion to the post of Assistant Professor shall be given to
in-service Punjab Civil Medical Services (PCMS) candidates who
have done four years of regular rural service in Punjab.
7) Director-Principals of Government Medical Colleges and Medical
Superintendents of Government Medical College Hospitals shall
cease to be the Heads of Department. However, they shall be
allowed to teach and practice in the department and remain incharge of a Unit.
8) Director-Principal of a Government Medical College shall also
be Dean of that College.
9) Administrative post or experience consists of experience on the
post of Director, Joint Director, Director-Principal, Medical
Superintendent, Head of the Department of a specialty, In-charge

<!-- page 27 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 12, 2021
(PAUSA 22, 1942 SAKA)

11

of a Clinical Unit, Deputy Medical Superintendent, Civil Surgeon,
Senior Medical Officer and above, District Medical Officer or
District Programme Officer.
10) Minimum qualification for appointment into the service by direct
appointment or by promotion on a post in the following specialties
shall be as under:-"
11. In the said rules, after Appendix 'B', the following Appendices shall be
added, namely:"APPENDIX B-1
{See rule 10(2)}
Serial Designation of the Nature of Penalty
No.
post

Punishing Authority

Appellate Authority

(1)
1.
2.
3.
4.
5.

(4)
Secretary Incharge
Secretary Incharge
Secretary Incharge
Secretary Incharge
Secretary Incharge

(5)
Minister Incharge
Minister Incharge
Minister Incharge
Minister Incharge
Minister Incharge

Secretary Incharge

Minister Incharge

Secretary Incharge
Secretary Incharge
Secretary Incharge

Minister Incharge
Minister Incharge
Minister Incharge

6.
7.
8.
9.

(2)
(3)
(i) Censure;
Director
(ii) withholding of
Joint Director
Director-Principal promotions;
(iii) recovery from pay
Vice Principal
of the whole or part of
Medical
any pecuniary loss
Superintendent
caused by him to the
Deputy Medical
Government by
Superintendent
negligence or breach of
Professor
orders;
Associate Professor (iv) withholding of
Assistant Professor increments of pay
without cumulative
effect;
(v) withholding of
increments of pay with
cumulative effect or
reduction to a lower
stage in the time-scale of
pay for a specified
period, with further
directions as to whether
or not the Government
employee will earn
increments of pay during

<!-- page 28 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 12, 2021
(PAUSA 22, 1942 SAKA)
the period of such
reduction and whether on
the expiry of such period,
the reduction will or will
not have the effect of
postponing the future
increments of pay;
(vi) reduction to a lower
time-scale of pay, grade,
post or service which
shall ordinarily be a bar to
the promotion of the
Government employee to
the time-scale of pay,
grade, post or service
from which he was
reduced with or without
further directions
regarding conditions of
restoration to the grade
or post or service from
which the Government
employee was reduced
and his seniority and pay
on such restoration to
that grade, post or
service;
(vii) compulsory
retirement;
(viii) removal from
service which shall not be
a disqualification for
future employment under
the Government;
(ix) dismissal from
service which shall
ordinarily be a
disqualification for future
employment under the
Government.

12

<!-- page 29 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 12, 2021
(PAUSA 22, 1942 SAKA)

13

"APPENDIX B-2
{See rule 10(3)}
Serial Designation of the Nature of Order
No.
post

Ordering Authority

Appellate Authority

(1)

(2)

(3)

(4)

(5)

1.

Director

Secretary Incharge

Minister Incharge

2.

Joint Director

Secretary Incharge

Minister Incharge

3.

Director-Principal

Secretary Incharge

Minister Incharge

4.

Vice Principal

As specified in rule 15 of
the Punjab Civil Services
(Punishment and Appeal)
Rules, 1970.

Secretary Incharge

Minister Incharge

5.

Medical
Superintendent

Secretary Incharge

Minister Incharge

6.

Deputy Medical
Superintendent

Secretary Incharge

Minister Incharge

7.

Professor

Secretary Incharge

Minister Incharge

8.

Associate Professor

Secretary Incharge

Minister Incharge

9.

Assistant Professor

Secretary Incharge

Minister Incharge

D.K. TIWARI,
Principal Secretary to Government of Punjab,
Department of Medical Education and Research.

2202/1-2021/Pb. Govt. Press, S.A.S. Nagar

<!-- page 30 -->

214

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)
APPENDIX- 'C'
(See rule 11)

THE PUNJAB CIVIL SERVICE (GENERAL AND COMMON
CONDITIONS OF SERVICES ) RULES, 1994.
GOVERNMENT OF PUNJAB
DEPARTMENT OF PERSONNEL AND ADMINISTRATIVE
REFORMS
(PERSONNEL POLICIES-I BRANCH)
Notification
The 4th May, 1994
No. G.S.R. 33/Const./Art. 309/94:- In exercise of the powers conferred by the proviso
of article 309 of the Constitution of India and all other powers enabling him in this behalf, the
Governor of Punjab is pleased to make the following rules regulating the recruitment and
general and common conditions of service of persons appointed to Class I, Class II and
Class III service in connection with the affairs of the State of Punjab namely:1.

Short title, commencement and application:-

(1)

These rules may be called the Punjab Civil Service (General and Common
Conditions of Services) Rules, 1994.

(2)

They shall come into force at once.

(3)

They shall apply to all the posts in Class III services in connection with the affairs
of the State of Punjab.

2.

Definitions:- In these rules , unless the context otherwise requires:-

(a)

“Appointing Authority” means an appointing authority specified as such in the
services Rules made under article 309 of the Constitution of India in respect of
any service or position connection with the affairs of the State of Punjab.

(c)

“Board” means the Subordinate services Selection Board, or any other authority
constituted to perform its functions;

(d)

“Commission” means the Punjab Public Service Commission.

(e)

“Direct Appointment” means an appointment made otherwise than by Promotion
or by transfer of a person already in the service of Government of India or of a
State Government.

(f)

“Government “means the Government of State of Punjab in the Department of
Personnel and Administrative reform.

<!-- page 31 -->

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)
(g)

215

“Recognized University or institution” means:(iii) Any university or institution incorporated by law in any of the State of India;
or

(iv) Any other university or institution which is declared by the Government to be
Recognized University or institution for the purpose of these rules.

3.

(h)

“Service” means any Class III service constituted in connection with the affairs
of the State of Punjab;

(i)

“Service Rules” means the Service Rules made under article 309 of the Constitution
of India regulating the recruitment and condition of service other than the general
and common condition of service of persons appointed to any service or post in
connection with the affairs of the State of Punjab.

Nationality, domicile and character of person appointed to the service:(1)

No person shall be appointed to the service unless he is :(a)

a Citizen of India; or

(b)

a Citizen of Nepal; or

(c)

a Subject of Bhutan; or

(d)

A Tibetan refugee who came over to India before the first day of January,
1962 with the intention of permanently settling in India ; or

(e)

a person of India origin who has migrated from Pakistan, Burma, Sri Lanka
and East African Countries of Kenya, Uganda and United Republic of
Tanzania (formerly Tanganyika and Zanzibar) Zambia, Malawi, Zaire, Ethiopia
and Vietnam with the intention of permanently settling in India;
Provided that a person belonging to any of the categories (b), (c), (d) and
(e) shall be a person in whose favor a certificate of eligibility has been given
by the Government of Punjab in the Department of Home Affairs and Justice;

(2)

A person in whose case a certificate of eligibility is necessary may be admitted to
an examination or interview conducted by the Commission of the Board, as the
case may be, on his furnishing proof that he has applied for the certificate but he
shall not be appointed for the service unless the necessary certificate is given to
him by the Government of Punjab in the Department of Home Affairs and Justice.

(3)

No person shall be recruited to the service by Direct Appointment unless he
produces:a.

A certificate of Character from the Principal academic officer of the
University, college, school or institution last attended, if any, and similar

<!-- page 32 -->

216

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)
certificates from two responsible persons not being his relatives, who are
well acquainted with him in his private life and are unconnected with his
university, college, school or institution; and
b.

4.

An affidavit to the effect that he was never convicted for any criminal
offence involving moral turpitude that he was never dismissed or removed
from service of any State Government or of Government of India or of any
Public Sector Undertaking.

Disqualification:- No person
a.

Who has entered into or contracted a marriage with a person having a spouse
living; or

b.

Who having a spouse living, has entered into or contracted a marriage with a
person shall be eligible for appointment to the services;

Provided that the Government, if satisfied that such marriage is permissible under the
personal law applicable to such person and the other party to the marriage and that there are
other grounds for so doing; exempt any person from the operation of this rule.
5.

Age:(1)

No person shall be recruited to the Service by direct appointment if he is less than
eighteen years or is more than thirty five years of age in the case of technical/
non-technical posts and the 1st day of January of the year immediately preceding
the last date fixed for submission of applications by the Commission or the Board,
as the case may be, or unless he is within such range of minimum and the maximum
age limits as may be specifically fixed by the Government from time to time.
Provided that where different lower and upper age limits have been specifically
prescribed for post in the service Rules, these limits shall be made applicable for
the appointment to such posts;
Provided further that the upper age limit may be relaxed up to forty five years in
the case of person already in the employment of the Punjab Government, other
State Government or the Government of India.
Provided further that in the case of candidates belonging to Scheduled caste or
other Backward Classes, the upper age limit shall be such as may be fixed by the
Government from time to time.

(2)

In the case of Ex- Servicemen, the upper age limit shall be such as has been
prescribed in the Punjab Recruitment of Ex- Servicemen Rules, 1982, as amended
from time to time.

<!-- page 33 -->

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)
(3)

6.

217

In the case of appointment on compassionate grounds on priority basis, the upper
age limit shall be such may be specifically fixed by the Government from time to
time.

Qualifications etc.:Subject to the provisions of these Rules the number and character of posts, method of
recruitment and educational qualifications and experience for appointment to a post or
posts in a service and the Departmental examination, if any shall be such as may be
specified in the Service Rules made for that Service.

7.

Probation:(1)

A person appointed to any post in the service shall remain on probation for a
period of two years, if recruited by direct appointment and one year, if appointed
otherwise:
Provided that—

(2)

(a)

Any period after such appointment spent on deputation on a corresponding
or a higher post shall count towards the period of probation;

(b)

In the case of appointment by transfer, any period of work on an equivalent
or higher post prior to appointment to the service, may in the discretion of
the appointing authority is allowed to count towards the period of probation;

(c)

Any period of officiating appointment to the service shall be reckoned as
period spent on probation; and

(d)

any kind of leave not exceeding six months during or at the end of period of
probation, shall be counted towards thee period of probation.

If, in the opinion of the appointing authority, the work or conduct of a person
during the period of probation is not satisfactory or if he has failed to pass the
departmental examination, if any prescribed in Service Rules within a period not
exceeding two and a half years from the date of appointment, it maya.

if such person is recruited by direct appointment dispense with his service,
or revert him to a post on which he held lien prior to his appointment to the
service by Direct appointment ; and

b.

if such person is appointed otherwise:
(i)

revert him to his former post; or

(ii)

deal with him in such other manner as the terms and conditions of the
previous appointment permit.

<!-- page 34 -->

218
(3)

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)
On the completion of the period of probation of a person, the appointing authority
may –
(a)

if the work and conduct has in its opinion been satisfactory(i)

confirm such person, from that date of his appointment or from the
date he completes his period of probation satisfactorily if, he is not
already confirmed ; or

(ii) declare that he has completed his probation satisfactorily if, he is already
confirmed ; or
(b)

if his work and conduct has not been in its opinion satisfactory, if he has
failed to pass the Departmental examination, if any, specified in the service
Rules(i)

dispense with his service if appointed by direct appointment, or if
appointed otherwise revert him to his former post, or deal with him in
such other manner as the time and conditions of his previous
appointment may permit ; or

(ii)

extend his period of probation and thereafter pass such order as it
could have passed on the expiry of the period of probation as specified
in sub-rule (1):
Provided that the total period of probation including extension, if any,
shall not exceed the years.

8.

Seniority:The seniority inter se of persons appointed to posts in each cadre of a service
shall be determined by the length of continuous service on such posts in that
cadre of the service;
Provided that in case of person recruited by direct appointment who join within
the period specified in the order of appointment or within such period as may be
extended from time to time by the appointing authority subject to a maximum of
four months from the date of order of appointment, the order of merit determined
by the commission or the Board, as the case may be, shall not be disturbed;
Provided further that in case a person is permitted to join the post after the expiry of
said period of four months in consultation with the Commission or the Board, as the
case may be, his Seniority shall be determined from the date of joins the post;
Provided further that in case any person of the next selection has joined a post in
the cadre of the concerned service before the persons referred to in the proceeding
proviso joins, the person so referred shall be placed below all the persons of the
next selection, who joins within the time specified in the first proviso;

<!-- page 35 -->

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

219

Provided further that in the case of two or more persons appointed on same date,
their seniority shall be determined as follows:(a)

a person appointed by direct appointment shall be senior to a person appointed
otherwise:

(b)

a person appointed by promotion shall be senior to person appointed by
transfer;

(c)

In the case of persons appointed by promotion or transfer , the seniority
shall be determined according to the seniority of such persons in appointments
from which they were promoted or transferred; and

(d)

In the case of persons appointed by transfer from different cadres, their
seniority shall be determined according to pay, preference being given to a
person who was drawing a higher rate of pay in his previous appointment;
and if the rates of pay drawn as also the same, then by their length of
service in these appointments and if the length of service also the same an
older person shall be senior to be younger person.

Note:- Seniority of persons appointed as purely provisional basis or on ad hoc
basis shall be determined as and when they are regularly appointed keeping in
view the dates of such regular appointments.
9.

Liability of members of service to transfer:A member of a service may be transferred to any post whether included in any other
service or not, on the same terms and conditions as are specified in rule 3.17 of the
Punjab Civil Service Rules, Volume I, Part I.

10. Liability to servo:A member of a service shall be liable to serve at any place, whether within or out of the
State of Punjab on being ordered so to do by the appointing authority.
11. Leave, Pension and other matters:In respect of pay, leave, pension and all other matters how expressly provided for in
these rules, a member of a service shall be governed by such rules and regulations and
may have been or may hereafter be adopted or made by the competent authority.
12. Discipline penalties and appeals:(1)

In the matter of discipline punishment and appeals a matter of service shall be
governed by the Punjab Civil Services (Punishment and Appeal) Rules 1970 as
amended from time.

(2)

The authority empowered to impose penalties specified in rule 5 of the Punjab
Civil Services (Punishment and Appeal) Rules 1970 and the appellate authority
there under in respect of the Government employee shall be such as may be

<!-- page 36 -->

220

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)
specified in the Service Rules.

13. Liability for vaccination and Re-vaccination:Every member of a service shall get himself vaccinated or re-vaccinated when Punjab
Government so directs by a special or general order.
14. Oath of allegiance:Every member of a service unless has already done so shall be required to take Oath
of allegiance to India and to the Constitution of India as by law established.
15. Minimum education and other Qualifications for appointment to the posts of
clerk:No post shall be appointed by direct appointment to a post of clerk under the Punjab
Government unless he(a)

is Matriculate in Second Division or has passed senior secondary Part-II
examination from a recognized university.

(b)

Qualifies a test in Punjabi type-writing to be conducted by the Board or by the
appointing authority at the speed of thirty words per minute.

16. Minimum education and other Qualifications for appointment to the posts of
Steno- typist Grade –II or Junior Scale Stenographer Grade-IINo. person shall be appointed by direct appointment to a post of a Steno GradeII or Junior Scale Stenographer Grade-II under the Punjab Government unless(a)

is Matriculate in Second Division or has passed senior secondary Part-II
examination from a recognized university or institution and;

(b)

Qualifies a test in Punjabi Stenography to be held by the Board or by the
appointing authority at a speed to be specified by the Government from time
to time.

17. Knowledge of Punjabi Language:No person shall be appointed to any post in any Service by direct appointment
unless he possesses knowledge of Punjabi Language of Matriculation standard
or its equivalent.
Provided that where a person is appointed on compassionate grounds on priority
basis under the instruction issued in this behalf by the Government, the person so
appointed will have to acquire knowledge of Punjabi language of Matriculation
standard or will have to qualify a test conducted by the Language Wing of the
Department of Education of the Punjab Government within six months from the
date of his appointment:
Provided future that where educational qualifications for a post in any service are

<!-- page 37 -->

PUNJAB GOVT. GAZ. (EXTRA), MARCH 15, 2016
(PHGN 25, 1937 SAKA)

221

lower than Matriculation, the knowledge of Punjabi language shall be lowered
accordingly.
18. Debarring for consideration for promotion of Government employee who
refuses to accept promotion:In the event of refusal to accept promotion by a member of a service he shall be
debarred by the appointing authority from consideration for promotion for all the
consecutive chance which may occur in future within a period of two years from the
date of such refusal to accept proposal;
Provided that in a case where the appointing authority is satisfied that a member of a
service has refused to accept promotion under the circumstances beyond his control, it
may exempt such a member for reasons to be recorded therefore in writing from the
operation of this rule.
19. Power to relax:Where the Government is of the opinion that it is necessary of expedient so to do, it
may, by order, for reasons to be recorded in writing, relax any of the provisions of these
rules with respect to any class of category of persons:
Provided that the provisions relating to educational qualifications and experience, if
any, shall not be relaxed.
20. Over riding effect:The provision of these rules shall have effect notwithstanding anything to the contrary
contained in any rules for the time being in force for regulating the recruitment and
conditions of service for appointment to Public service and posts in connection with the
affairs of the State.
21. Interpretation:If any question arises as to the interpretation of these rules, the Government shall
decide the same.
A.S. CHATHA,
CHIEF SECRETARY TO GOVERNMENT
PUNJAB.
HUSSAN LAL, IAS,
Secretary to Government of Punjab
Department of Medical Education and Research.
973/03-2016/Pb. Govt. Press, S.A.S. Nagar

<!-- page 38 -->

Regd. No. NW/CH-22

Regd. No. CHD/0092/2015-2017
Price : Rs 2.70

EXTRAORDINARY
Published by Authority
CHANDIGARH, TUESDAY, MARCH 15, 2016
(PHALGUNA 25, 1937 SAKA)
LEGISLATIVE SUPPLEMENT
Contents
Part - I

Pages

Acts
Nil

Part - II

Ordinances
Nil

Part - III

Part - IV

Delegated Legislation
1. Notification No.G.S.R.15/Const./Art.309/
2016, dated the 12th March, 2016,
containing the Punjab Dental Education
(Group-A) Service Rules, 2016.

.. 173-193

2. Notification No.G.S.R.16/Const./Art.309/
2016, dated the 14th March, 2016,
containing the Punjab Medical Education
(Group-A) Service Rules, 2016.

.. 195-221

Correction Slips, Republications and
Replacements
Nil

( xx )

<!-- page 39 -->

PUNJAB GOVT. GAZ.(EXTRA), MAY 29, 2025
(JYST 8, 1947 SAKA)
PART-III

No.G.S.R.38/Const./Art.309/Amd.(3)/2025.-

425

<!-- page 40 -->

PUNJAB GOVT. GAZ.(EXTRA), MAY 29, 2025
(JYST 8, 1947 SAKA)

425
426

<!-- page 41 -->

PUNJAB GOVT. GAZ.(EXTRA), MAY 29, 2025
(JYST 8, 1947 SAKA)

427

<!-- page 42 -->

PUNJAB GOVT. GAZ.(EXTRA), MAY 29, 2025
(JYST 8, 1947 SAKA)

427
428

<!-- page 43 -->

PUNJAB GOVT. GAZ.(EXTRA), MAY 29, 2025
(JYST 8, 1947 SAKA)

429

<!-- page 44 -->

PUNJAB GOVT. GAZ.(EXTRA), MAY 29, 2025
(JYST 8, 1947 SAKA)

429
430

<!-- page 45 -->

PUNJAB GOVT. GAZ.(EXTRA), MAY 29, 2025
(JYST 8, 1947 SAKA)

431

<!-- page 46 -->

PUNJAB GOVT. GAZ.(EXTRA), MAY 29, 2025
(JYST 8, 1947 SAKA)

431
432

<!-- page 47 -->

PUNJAB GOVT. GAZ.(EXTRA), MAY 29, 2025
(JYST 8, 1947 SAKA)

433
