---
doc_id: "c20c6b9ce78b0ced"
source_url: "https://punjabagro.gov.in/wp-content/uploads/2023/03/FPO-Policy-Punjab-Final_compressed-1.pdf"
ministry: "Punjab Agro Industries Corporation Limited (PAIC), Punjab"
title: "FPO policy(English)"
date: ""
pages: 9
method: "tesseract:pan+eng"
script: "LATIN"
needs_ocr: false
sha1: "29f7572c7a1cc5f5"
---

<!-- page 1 -->

GOVERNMENT OF PUNJAB
DEPARTMENT OF AGRICULTURE AND FARMERS WELFARE
(Agriculture-4 Branch)
Notification

No.25/24/15-Agri-4(2)/_S RO Chandigarh, dated: {4 [09 [222੦
Farmer Producers Organizations (FPOs)Policy for State of Punjab.

The farmers of Punjab especially small and marginal farmers are passing through
a tough time with limited resource availability, rising input prices, higher vulnerabilities
to climate and market risks. It is expected that in Punjab, small and marginal farmers
are going to increase in future as the land holding is further going to get fragmented.
The small land holding will make it difficult for farmers to carry out agricultural practices
economically. The challenge therefore is to identify sustainable solutions that are
efficient, environmentally friendly and at the same time inclusive in terms of addressing
the needs of the small and marginal farmers. Farmer Producer Organization (FPO) can
provide one such opportunity. FPOs aim at providing better income for the producers
through an organization of their own. Through aggregation, both in upstream and

‘ downstream areas, the primary producers can avail the benefits of economies of scale.

i. Vision
4.4. To create and develop professionally run member-owned Producer

Organizations in Punjab that become the leaders in the national markets, which

enable farmers to enhance productivity through: efficient, cost-effective and

sustainable resource use and realize higher returns for their produce by creating,

; delivering and communicating value to the customers, through collective action
supported by the government, and fruitful collaboration with different
stakeholders.

2. Mission

2.1 To promote sustainable, economically viable and self governing Farmer Producer ;
Organizations (FPOs) by providing experts handholding and resources - (policy
action, inputs, technical knowledge, financial resources, and infrastructure) - to
strengthen these FPOs.

2.2 To remove hurdles in enabling farmers to access the markets through their
FPOs, both as buyers and sellers.

2.3. To create an enabling policy environment for investments in FPOs to leverage ਕੇ
their collective production and marketing power. 004

1 we

<!-- page 2 -->

। 2.4 To improve marketing efficiencies and realize optimum price through collective
। bargaining inside as well as outside the mandis by use of the available modes,
। including digital ones such as the e-NAM or any other portal.
| 2.5 To provide that FPOs generate sufficient resources to meet expenses, and to
recover payments in respect of sale or agri-inputs to farmer members.

2.6 To promote FPOs as development institutions that play role of a buffer for
members and the village community for ensuring social and cultural upliftment
as well.

- 3. Scope and Coverage

3.1 The provisions of this policy will apply equally to FPOs already registered either
under the Companies Act or under Societies Registration Act, 1860 or under
various central and state cooperative society laws and those FPOs which will be
registered subsequent to the issue of this policy.

3.2 The main qualifying criterion for an FPO to attract benefits under this policy is
that it must be a body registered and administered by farmers and the
organization must be focused on activities in the agriculture and allied sectors.
Further, it is mandatory that FPO is registered with State Nodal Agency (SNA) 35
explained in this policy to avail various benefits.

4. The formation and development of FPOs will be actively encouraged and
supported by the Government of Punjab. The financial resources already
earmarked under various centrally sponsored and State-funded schemes shall be
leveraged to develop strong and viable FPOs.

The State shall undertake to make special budgetary provision in the
Department of Agriculture and Farmers Welfare for giving financial assistance to

: FPOs including the assistance for strengthening of State Nodal Agency. The
financial assistance shall also be given for creating common infrastructure
facilities for facilitating the effective, efficient and profitable functioning of the
FPOs.

5. FPOs and members

5.1 Farmers Producer Organization (FPO) is an organization which is promoted by :
the farmers and the same is registered as any one of the following:

1) Private Limited Company under Companies Act, 2013

2) 0000 Limited Company under Companies Act, 2013

3) Producer Company under Companies Act, 2013

4) Cooperative Society registered under Punjab Cooperative Societies Act, 1961

5) Society Registered under Societies Registration Act, 1860.

6) Punjab Cooperative Societies Act, 1961 (Punjab Act No. 25 of 1961).

Benefits to the societies shall be given under the policy, subject to the .
condition that no political/electoral interferences shall be made in the working of

<!-- page 3 -->

ral
FPO in any way. The interested parties can mandate under the self-supporting

Cooperatives Act.

5.2 It is to be noted that the FPOs are expected to be created through bottom up
approach. These FPOs should not add another layer of intermediaries in

agriculture. The objective of these organizations is to enhance net income of the
ਰ੍ producers and not the income of the FPO per se.

5.3 Community based/ area based/ product based or any other federation of
Farmers Producer Organizations (FPOs) having any legal form as explained in 5.1
above shall also considered as an FPO to avail benefits under this policy.

_ 5.4 To avail benefits under this policy, it shall be mandatory for any FPO to get itself
registered with SNA as explained further in this policy.

6. Activities of FPOs

6.1 7705 can take part in any component of agri-value chain or can act across the
complete value chain. The agri-value chain includes field/horticulture crops,
animal husbandry, animal/agriculture waste, and services such as hire-purchase
of machinery etc. The FPOs are free to take up one or more agricultural products
and/or services to deal in.

6,2 705 shall be on par with Cooperative Societies registered under Punjab
Cooperative Societies Act, 1961 and self-help groups/federations for all benefits

ਸੇ and facilities that are extended to member-owned institutions from time to time.

6.3 Licenses to FPOs shall be issued on priority to trade in inputs (seed, fertilizer,
farm machinery, pesticides etc.) for use of their members as well as routing the
supply of agricultural inputs through FPOs on par with cooperatives.

6.4 FPOs shall facilitate access to fair and remunerative markets including linking of

1 producer groups to marketing opportunities through market aggregators,
storage, processing and distribution. FPOs will be given priority and will be
treated at par with cooperatives & corporations.

6.5 FPOS are encouraged to act as producers of certified seed, saplings and other
planting material and production and marketing subsidies shall be extended to

: FPOs on par with cooperatives. ;

6.6 Direct sale of farm produce by FPOs shall be allowed at the farm gate, and
contract farming arrangements between FPOs and bulk buyers shall be
facilitated. ;

6.7 FPOs shall be allowed as procurement agents for MSP based procurement of
various crops for PDS (Public Distribution System). FPOs shall be allowed to act
as ‘arhtias ' in the 'mandis'. They shall be given preference over individuals and
other organizations. It may also act as a company representing farmers and have >
the right to help farmers for better price realization. 004

3 ਨੀ

<!-- page 4 -->

6.8 FPOs shall be allowed to act as implementing agencies for various agricultural
development programmes of centre/state government and other organizstions
: and the benefits under the Rashtriya Krishi Vikas Yojana (RKVY), National
Horticulture Mission (NHM), Agricultural Infrastructure Fund (AIF), Param Pragat

Krishi Vikas Yojna (PKVY) and other States & Government schemes.
6.9 In addition, an FPO can provide financial and business services for the welfare

of its member farmers. Some of the services are:

a) Financial Service: The FPO can provide loans for crops, purchase of
tractors & other required farm machinery, pump sets and other related
work required for agricultural/horticultural operations.

b) Input Supply Services: The FPO can provide low cost and quality inputs
to the member farmers and can also supply fertilizers, pesticides, seeds,
sprayers, and other required input(s).

()) Procurement and Packaging Services: The FPO can facilitate
procurement of agriculture produce from its members and make
arrangements for its storage and value addition along with packaging.

d) Marketing Services: The FPO can carry out the direct marketing after

ਰ procurement and make arrangements for logistics also. Further, FPO can
help its members to market agricultural produce and also try to find out
new markets for its member farmers.

e) Technical and Extension Services: The FPO can provide service of
advising best practices of farming to its members and can also follow the

; good agricultural practices (GAP) along with Farm Management Services.
Further, technical know how about post-harvest technologies and
management, and processing etc. can also be provided by FPOs to its
members.

Zs Institution for Promotion and Development of FPOs in Punjab:

7.1. Punjab Agri Export Corporation Limited (PAGREXCO) shall act as State
Nodal Agency (SNA) to function as a catalytic/facilitating agency to ;
promote agri-business activities through FPOs in Punjab. The benefits for
FPOs envisaged under this policy shall be extended only to those FPOs
who shall be registered.with SNA. The SNA shall.issue detailed guidelines

regarding the eligibility and process of registration of FPOs. The SNA shall
work towards encouraging the setting up of FPOs, identification of already
registered FPOs and could help FPOs to avail benefits under various
central government/state Govt schemes. SNA will act as a single window 5
institution for FPOs and shall facilitate the linkages with investors,
technology providers and markets. SNA will provide all-round support to Wt
FPOs and other entities engaged in promotion and development of FPOs ”"

4

<!-- page 5 -->

in Punjab. Further, it will also create sustainable linkages between FPOs
| and inputs suppliers, technology providers, extension and research
agencies, and marketing and processing players both in the public and
private sectors. SNA will work to build-in provision for providing marketing
. intelligence, empanelment/hiring of auditors, monitoring, evaluation and
14 other backup support services required by each FPO. SNA being a
Government of Punjab enterprise would act as a responsible entity for
promotion of FPOs in Punjab.
7.2 SNA shall endeavor to set up a mechanism for funding the activities of
registered FPOs by tying up with various financial institutions, NABARD
and govt. agency and others. In case, FPO qualifies, SNA shall facilitate to
get loans and advances against the infrastructure available with each FPO.
Loans/grants under various Government schemes available at the National
9 level/ State level, as well as from banks and other financial institutions,
| shall be made available to FPOs. SNA shall endeavor to set up a
mechanism for funding the activities of FPOs by tying up with existing
financial institutions, NABARD and other government agencies.
7.3 SNA shall appoint Resource Institutions (RIs). RI would include the
following:
= Line departments of Government of Punjab dealing in agriculture and
allied activities.
: State agricultural university and veterinary university.
੍ = Other state and central government agencies dealing with procurement,
processing and marketing of agricultural products/agricultural inputs.
These RIs shall mobilize farmers to create FPOs and will provide technical
support, training to members of FPO. RIs shall also create linkages with
investors, technology providers and markets, financial institutions and
others by adopting the FPOs. These Ris shall act as change agents in
the field to create viable and sustainable FPOs. The detailed guideline
regarding the process of selecting RIs and allocating the FPOs shall be
issued separately by SNA.
The main task of all ੧5 shall be:
. ਹੀ. ‘ to create awareness about the FPOs among the farmers, farm
women and youth of Punjab.
732 to help members to form FPOs. ,
733 to provide intensive training to the potential members of FPO ਪੋ
before the incorporation of an FPO. The further training after a
Ss

<!-- page 6 -->

ail
the incorporation for the members of FPO shall be imparted by
RI during the entire period of handholding.
7.3.4 to help the FPOs in taking the benefit of various schemes/
| policies of Union Government and that of the Government of
1 Punjab under various ministries/ departments.
| . 7.35 to handhold the FPOs for a period of 5 years by providing
technical, managerial and business skills to enable these FPOs
to grow and flourish and be on their own after the lapse of five
years period.

7.4 To carry out the above mentioned tasks, the ੧15 shall create a pool of
experts both in the technical as well as in the commercial/ business
areas. SNA shall appoint FPO Mittar for helping the FPOs in day to
day activities and for preparing and executing the business plan of

; FPOs. The FPO Mittar shall seek the help from various Rls and other
expert organizations/individuals depending upon the requirements
of FPOs. SNA shall monitor the activities of Rls and FPO Mittar at
regular intervals. SNA shall develop complete guidelines and metrics
for the selection, monitoring and evaluation of the working of Ris as
well as FPOs attached with these Rls. ;

7.5 To oversee the above mentioned tasks by SNA and Ris, a State Level
Committee (SLC) would be constituted under the Chairmanship of

: Additional Chief Secretary (Development), Punjab which includes the
੍ Officials from the following department/ organizations or its nominees:
॥ Vice Chancellor, Punjab Agricultural University, Ludhiana.
0. Vice Chancellor, GADVASU, Ludhiana.
iii. Secretary, Horticulture, Punjab. .
iv. Secretary, Agriculture, Punjab.
v. Managing Director, Punjab Agri Export Corporation.
vi. Secretary, Animal Husbandry, Punjab.
vii. Director, Horticulture, Punjab.
viii. Director, Agriculture, Punjab.
ix. Director, Dairy Development, Punjab.
x. Disector, Fisheries, Punjab.
xi. Registrar, Cooperative Societies, Punjab
Note: The chairman may co-opt any other official(s) as and when 7
: required.This committee shall nominate two representatives of FPOs as
members of the committee. This committee will review the work of the ਹੋ iad
SNA and also approve the Budget and other proposals of FPOs and RIs for -
promotion of FPOs.
6

<!-- page 7 -->

8 Financial Incentives
The financial support shall be given to FPOs, RIs as well as the SNA. The
details in respect of amount, duration, conditions and procedure shall be
laid down in a separate process document by the SNA which will be
/ approved by SLC.
My 8.1 Assistance for Awareness and Creation of FPOs
] State Nodal Agency (SNA) through RIs or on its own shall create
awareness among the farmers, women and youth to create FPOs to
: enhance their income. As this policy aims at creating volunteer based
organizations, this aspect shall form a significant part of the policy. The
SNA shall develop the networks with other institutions to carryout
awareness about FPOs.
8.2 Assistance to Conduct Diagnostic Study and to Prepare Business
Plan
The RI under the guidance of SNA shall carry out detailed diagnostic study
highlighting the market opportunities coupled with the strengths and
weaknesses of the FPOs. RI shall prepare the Business Plan for each FPO.
Grant shall be given to RIs for undertaking such activities as decided by
; SLC through SNA.
8.3 Assistance for Soft Interventions
The government shall endeavor to provide financial support to carry out
various soft interventions such as trainings (both technical and
managerial), demonstrations, sharing business opportunities, exposure
visits, trust building exercises etc for the FPO members as per the
suggested action plan based on the findings of diagnostic study by each
FPO. The same shall be approved by SLC.
8.4 Assistance for Hard Interventions
The government shall endeavor to provide financial assistance to create
infrastructure/common facilities’ centre as required by the FPOs as ,
identified in the diagnostic study. The limit for such intervention shall be
fixed and approved by SLC.
8.5 Incentives under Industrial Business Devo'cpment Policy
All incentives being made available under the Industrial Business
Development Policy, 2017 of Government of Punjab shall also be available
to registered FPOs.
9 Evaluation and Control 7
It is important that the performance metrics of FPOs are created and 4
ਨ measured at regular intervals so that these 705 become self-reliant. For
this, SNA shall create a mechanism to continuously develop such metrics ਕੱ
ਰਾ,

<!-- page 8 -->

for effective and efficient use of resources for promoting the welfare of
@ the small and marginal farmers.
/ 10 Process Guidelines
1. Punjab Agri Export Corporation Limited (PAGREXCO) shall be State Nodal

j Agency (SNA) for promotion of FPO in the State of Punjab.

1 2. State Level Committee (SLC) shall be the decision making body and will
approve the proposals for promotion of FPOs in Punjab. The same shall be
implemented through SNA.

3. SNA will issue detailed guidelines regarding the process of registration of
FPOs with SNA.
: 4. SNA shall appoint resource institutions for promotion of FPOs in the state.
SNA shall issue detailed guidelines regarding the process of appointing
RIs. SNA shall also issue detailed guidelines regarding performance
metrics of RIs and FPO Mittar to ensure promotion and development of
FPOs in the state.
5. SNA shall work as a single point of contact for FPOs' business
development and growth. It shall hire technical consultants, Chartered
Accountants (CA) and other experts to assist the FPOs. These will be
regularly monitored by SNA. It shall also assist the FPOs for fulfilling all
statutory compliances.
: 6. SNA shall endeavor to set up a mechanism for funding the activities of
FPOs by tying up with existing financial institutions, NABARD and other
government agencies. Funds may be provided by SFAC and under
Agriculture infrastructure Fund scheme of Government of India.
, 7. SNA will coordinate with various RIs for conducting training and facilitate
other required services from time to time.
8. SNA shall prepare annual budget for carrying out the activities under this
policy. On recommendation of SLC, the Department of Finance,
Government of Punjab shall Consider the proposal for release to the .
funds.
. 9. After the approval of SLC, the funds shall be released for various RIs by
SNA. .
10. SNA, in collaboration with SFAC, will create sustainable linkages between
੮05 and inputs suppliers, technology providers, extension and research
agencies and marketing and processing players, both in the public and
private sectors: .
i. By appointing FPOs as procurement agents for MSP operations for
various crops. ay
ae

<!-- page 9 -->

ii. By using FPOs as implementing agencies for various agricultural
/ development programmes, especially RKVY, NFSM, ATMA etc, and
| extending the benefits of Central and State funded programmes in
agriculture to members of FPOs on a ਗਲ basis.
| soa ai
Additional Chief Secretary (Development)
Chandigarh, dated:31-08-2020 Agriculture Farmers and Welfare department,
.__ Endst.No. 25/24/15-Agri-4(2)/_S 72 Chandigarh, dated: 1u]og | Dodo
A copy is forwarded to the Controller, Printing and Stationery Department,
Punjab Govt. Ordinary Gazette. It is requested that 50 copies of this notification may be
supplied to this Department for official use.
Joint Secretary Agriculture
Endst.No.25/24/2015-Agri4(2)/ S] Sr ਗਿ 14 Jeg bao
A copy is forwarded to the following for information and necessary action:-
1 Chief Principal Secretary/CM Punjab for the kind information of Hon'ble Chief
Minister Punjab.
2 Secretary, Department of Finance.
3 Principal Secretary, Higher Education Punjab.
4 Vice Chancellor, Punjab Agriculture University Ludhiana.
5 Vice Chancellor Guru Angad Dev veterinary and animal Husbandry University
Ludhiana.
6 Secretary, Horticulture, Punjab.
7 Secretary, Agriculture, Punjab.
8 Managing Director, Punjab Agro Industries Corporation, Chandigarh
; 9 Secretary, Animal Husbandry, Punjab.
10 Secretary Punjab Mandi Board, Mohali.
11 Director, Horticulture, Punjab, Khati Bhawan,Mohali
12 Director, Agriculture, Punjab,Khati Bhawan,Mohali
; 13 Director, Dairy Development, Punjab.
14 Director, Fisheries, Punjab. .
15 Registrar, Cooperative Societies, Punjab.
16 Chairman, Punjab Farmers Commission, Mohali.
17 Joint Secretary to the Govt. of India, Department of Agriculture & Farmers
Welfare (Agricultural Marketing Division), New Delhi.
18 The Chief Conservator of Soil Punjab ,S.C.O No-193-94 Chandigarh.
19 PS/Addl,Chief Secretary (Dev).
20 PA/Special Secretary Agriculture ੮
21. SSS/ Joint Secretary Agriculture
. Joint Secretary Agriculture
« ਊਂ”
