---
doc_id: "3dbf064c6dfafd74"
source_url: "https://www.pepsurtc.com/wp-content/uploads/2026/10/corrigendum75016nylon.pdf"
ministry: "Pepsu Road Transport Corporation, Patiala, Punjab"
title: "view download"
date: ""
pages: 1
method: "tesseract:pan+eng"
script: "LATIN"
needs_ocr: false
sha1: "47b0449677cc45ca"
---

<!-- page 1 -->

PEPSU ROAD TRANSPORT CORPORATION PATIALA
CORRIGENDUM
In continuation to the earlier tender notice No.
Purchase/2026/010 issued in the Dainik Savera, Ajit and
Hindustan Times on 29.09.2026 for supply of 7.50x16
Nylon Tyre, Tube and Flaps, the last date for submission of
the tender bid is hereby extended upto 21.10.2026 by 5:00
p.m. and the technical bid will be opened on 22.10.2026 at
11:00 a.m. If the Day/Date so fixed happens to be a Public
holiday the technical bid will be opened on the next
working day at the same time and the rest of the terms
and conditions as given in the tender document shall
remain the same.
(>

੪ ਤੀ icagortFardrase,

Pepsu Road Transport Corporation,
Patiala.
