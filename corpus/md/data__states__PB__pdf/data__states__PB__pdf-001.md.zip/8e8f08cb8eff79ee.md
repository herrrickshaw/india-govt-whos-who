---
doc_id: "8e8f08cb8eff79ee"
source_url: "https://punjabagro.gov.in/wp-content/uploads/2026/07/POSH-Policy.pdf"
ministry: "Punjab Agro Industries Corporation Limited (PAIC), Punjab"
title: "PAGREXCO POSH Policy"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "96afd75a2b3f01d3"
---

<!-- page 1 -->

PUNJAB AGRI EXPORT CORPORATION LIMITED (PAGREXCO)

Policy on Prevention, Prohibition and Redressal of Sexual Harassment
of Women at Workplace
(In accordance with the Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Act, 2013
and the Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Rules, 2013)

1. Short Title, Statutory Basis and Commencement
1.1 This Policy shall be called the “PAGREXCO Policy on Prevention of Sexual Harassment at Workplace
(POSH Policy)” and is framed under, and shall be read subject to, the Sexual Harassment of Women at
Workplace (Prevention, Prohibition and Redressal) Act, 2013 (“the Act”) and the Sexual Harassment of
Women at Workplace (Prevention, Prohibition and Redressal) Rules, 2013 (“the Rules”), as amended from
time to time.
1.2 In the event of any conflict between this Policy and the Act or the Rules, the provisions of the Act and the
Rules shall prevail. [Basis: Preamble & Sections 1–30 of the Act]

2. Definitions
2.1 “Aggrieved Woman” means, in relation to a workplace, a woman of any age, whether employed or not,
who alleges to have been subjected to any act of sexual harassment by the respondent. [Section 2(a)]
2.2 “Employee” means a person employed at a workplace for any work, whether on regular, temporary, ad
hoc or daily wage basis, either directly or through an agent, including a contractor, whether such employment
is on contract, part-time, probation, apprenticeship, and includes co-workers, contract workers, probationers,
trainees and interns, whether such terms of employment are express or implied. [Section 2(f)]
2.3 “Employer” means the head of the Corporation, or any person responsible for the management,
supervision and control of PAGREXCO, including any person discharging contractual obligations with respect
to its employees. [Section 2(g)]
2.4 “Respondent” means a person against whom the aggrieved woman has made a complaint. [Section 2(m)]
2.5 “Workplace” includes:
• Any department, organisation, undertaking, establishment, enterprise, institution, office, branch or unit

of PAGREXCO, whether established, owned, controlled or wholly or substantially financed by it;
• Any place visited by an employee arising out of or during the course of employment, including

transportation provided by PAGREXCO for undertaking such a journey; and
2.6 This Policy accordingly extends to the Head Office, Plants, Farms, Field Offices, Warehouses, official
travel and transportation, off-site meetings, training programmes, work-related social events, and, to the extent
conduct arises out of or is connected with employment, virtual/online work interactions.
2.7 “Sexual Harassment” includes any one or more of the following unwelcome acts or behaviour (whether
directly or by implication), namely:
• Physical contact and advances;
• A demand or request for sexual favours;
• Making sexually coloured remarks;

<!-- page 2 -->

• Showing pornography; or
• Any other unwelcome physical, verbal or non-verbal conduct of a sexual nature. [Section 2(n)]

2.8 Any of the following circumstances, if it occurs or is present in relation to, or connected with, any act or
behaviour of sexual harassment, may amount to sexual harassment:
• Implied or explicit promise of preferential treatment in employment;
• Implied or explicit threat of detrimental treatment in employment;
• Implied or explicit threat about present or future employment status;
• Interference with work or creating an intimidating, offensive or hostile work environment; and
• Humiliating treatment likely to affect health or safety. [Section 3(2)]

3. Objective
PAGREXCO is committed to providing a safe, secure and dignified working environment, free from sexual
harassment, to every woman, and adopts a zero-tolerance approach towards sexual harassment. This Policy
sets out the mechanism for prevention, prohibition and redressal of complaints of sexual harassment as
mandated by the Act.

4. Scope and Applicability
4.1 This Policy applies to every Aggrieved Woman, as defined in Clause 2.1 above, in relation to the
workplace(s) of PAGREXCO – including regular, temporary, ad hoc and daily-wage employees; employees
engaged through contractors or agencies; probationers, trainees, apprentices and interns; and any other woman,
whether or not she is an employee of PAGREXCO, who alleges an act of sexual harassment at a PAGREXCO
workplace as defined in Clause 2.5.
4.2 This Policy applies to the conduct of all employees of PAGREXCO, of every rank and designation, in
respect of complaints made against them by an Aggrieved Woman.

5. Internal Committee (IC)
5.1 PAGREXCO shall constitute an Internal Committee at its Head Office and at each office or branch/unit
where the number of employees is ten or more, by a written order of the Employer. [Section 4(1)]
5.2 Composition. The Internal Committee shall consist of:
• Presiding Officer: a woman employed at a senior level at the workplace, nominated from amongst the

employees;
• Not less than two Members: from amongst employees, preferably committed to the cause of women or

who have had experience in social work or have legal knowledge;
• One external Member: from a non-governmental organisation or association committed to the cause of

women, or a person familiar with issues relating to sexual harassment; and
• Not less than one-half of the total Members so nominated shall be women. [Section 4(2)]

<!-- page 3 -->

5.3 Where a Presiding Officer or any Member of the Internal Committee ceases to be an employee of
PAGREXCO, or otherwise ceases to hold office, a new Presiding Officer or Member shall be nominated in
her/his place in the same manner as the original nomination.
5.4 Tenure. The Presiding Officer and every Member of the Internal Committee shall hold office for a period
not exceeding three years from the date of their nomination, as may be specified by the Employer. On
completion of the term, the Internal Committee shall be reconstituted afresh in accordance with Clause 5.2.
[Section 4(3); Rule 4]

5.5 External Member – fee/allowance: The external Member shall be entitled to such fees or allowances for
holding the proceedings of the Internal Committee as may be prescribed by PAGREXCO, not exceeding the
limits prescribed under the Rules. [Rule 4]
5.6 Quorum: Presence of at least three Members, including the Presiding Officer and the external Member,
shall be required to hear and inquire into any complaint. [Rule 3(2), read with Section 4(2)]
5.7 Locations. PAGREXCO shall constitute a separate Internal Committee at each of its administrative
units/offices having ten or more employees, by written order of the Employer. Based on present staff strength,
PAGREXCO shall constitute three Internal Committees, as under: [Section 4(1)]
Location

Presiding Officer

Members

External Member

Head Office

Head HR & Compliances

Chief Finance Officer
DM – HR

Law Officer, PAIC

Abohar Plant

Head HR & Compliances

Plant Head, Abohar
AM – Admin

Law Officer, PAIC

Hoshiarpur Plant

Head HR & Compliances

Plant Head, Hoshiarpur
Estate Officer cum Admin

Law Officer, PAIC

6. Local Committee
6.1 In relation to any office or unit of PAGREXCO having fewer than ten employees, or where the complaint
is against the Employer himself, or where the Internal Committee is not constituted, the Aggrieved Woman
may file her complaint before the Local Committee constituted by the District Officer for the concerned district
under the Act. [Sections 5–6]
6.2 PAGREXCO shall extend full cooperation to the Local Committee and shall furnish such assistance,
information and facilities as may be required by it for conducting an inquiry.

7. Complaint Procedure
7.1 Who may complain: An Aggrieved Woman may make a written complaint of sexual harassment at the
workplace to the Internal Committee (or, where applicable, the Local Committee).
7.2 Where the Aggrieved Woman is unable to complain: Where the Aggrieved Woman is unable to make
a complaint on account of physical or mental incapacity, or death, or otherwise, her complaint may be made
by her legal heir or such other person as may be prescribed, including her relative or friend, a co-worker, an
officer of the National/State Commission for Women, or a person who has knowledge of the incident, with the
written consent of the Aggrieved Woman (or her legal heir, where applicable). [Section 9(2); Rule 6(2)]

<!-- page 4 -->

7.3 Time limit: The complaint shall be made within a period of three months from the date of the incident,
and in case of a series of incidents, within three months of the last incident. The Internal Committee may, for
reasons to be recorded in writing, extend this time limit by a further period not exceeding three months, if
satisfied that the circumstances prevented the Aggrieved Woman from filing the complaint within the original
period. [Section 9(1), proviso]
7.4 Manner of complaint: The complaint shall be made in writing. Where the Aggrieved Woman is unable
to make the complaint in writing, the Presiding Officer or any Member of the Internal Committee shall render
reasonable assistance to her for making the complaint in writing. The complaint shall be submitted in six
copies, along with supporting documents and the names and addresses of the witnesses, if any. [Rule 6(1)]
7.5 Assistance in filing: PAGREXCO and the Internal Committee shall render all reasonable assistance to the
Aggrieved Woman for filing the complaint, if she so desires.

8. Conciliation
8.1 The Internal Committee may, before initiating an inquiry and only at the written request of the Aggrieved
Woman, take steps to settle the matter between her and the Respondent through conciliation, provided that no
monetary settlement shall be made the basis of such conciliation. [Section 10(1)]
8.2 Where a settlement is arrived at through conciliation, the Internal Committee shall record the settlement so
arrived and forward it to the Employer to take action as specified in the recommendation. The Internal
Committee shall provide copies of the settlement to the Aggrieved Woman and the Respondent. Where a
settlement is reached under this Clause, no further inquiry shall be conducted. [Section 10(2)–(3)]

9. Inquiry Procedure
9.1 Where conciliation is not opted for, or fails, or the matter is not resolved, the Internal Committee shall
proceed to make an inquiry into the complaint in accordance with the service rules of PAGREXCO or, in the
absence of such rules, in such manner as prescribed under the Rules. [Section 11(1); Rule 7]
9.2 The Aggrieved Woman shall be given an opportunity to submit a copy of the complaint received, along
with supporting documents and the list of witnesses, to the Respondent within seven working days of receipt.
The Respondent shall file his reply along with his list of documents and witnesses within ten working days of
receipt.
9.3 During the course of the inquiry, either party may be assisted by a fellow employee, but not by a legal
practitioner, subject to the Internal Committee's discretion where the other party is represented by a legal
practitioner. [Rule 7(6)]
9.4 The Internal Committee shall have the same powers as are vested in a civil court under the Code of Civil
Procedure, 1908 when trying a suit, in respect of summoning and enforcing attendance of any person, requiring
discovery and production of documents, and any other matter as prescribed. [Section 11(3); Rule 7(3)]
9.5 Timeline: The inquiry shall be completed within a period of ninety days from the date of receipt of the
complaint. [Section 11(4)]
9.6 Interim relief: During the pendency of the inquiry, on a written request of the Aggrieved Woman, the
Internal Committee may recommend to the Employer to (a) transfer the Aggrieved Woman or the Respondent
to any other workplace; (b) grant leave to the Aggrieved Woman of up to a period of three months, in addition

<!-- page 5 -->

to leave otherwise entitled to her; or (c) grant such other relief as may be prescribed, including restraining the
Respondent from reporting on the work performance of the Aggrieved Woman. [Section 12; Rule 8]

10. Inquiry Report and Action
10.1 On completion of the inquiry, the Internal Committee shall provide a report of its findings to the Employer
within ten days of completion, and such report shall be made available to the concerned parties. [Section 13(1)]
10.2 Where the allegation is not proved: The Internal Committee shall recommend that no action be taken
against the Respondent. [Section 13(2)]
10.3 Where the allegation is proved: The Internal Committee shall recommend that PAGREXCO take action
for sexual harassment as a misconduct in accordance with the applicable service rules, and/or deduct from the
salary or wages of the Respondent such sum as it may consider appropriate to be paid to the Aggrieved Woman
or her legal heirs, having regard to the factors prescribed under Section 15 of the Act (including mental trauma,
loss in career opportunity, medical expenses incurred, income and financial status of the Respondent, and
feasibility of such payment in lump sum or instalments). [Section 13(3); Section 15]
10.4 Implementation: PAGREXCO shall act upon the recommendations of the Internal Committee within
sixty days of receipt of the report. [Section 13(4)]
10.5 Where the Employer fails to act on the recommendations, or where any party is aggrieved by the
recommendations, an appeal may be preferred before the Court or Tribunal in accordance with, and within the
period prescribed under, service rules, or, in the absence thereof, within ninety days of the recommendations.
[Section 18]

11. Action for False or Malicious Complaint
11.1 Where the Internal Committee arrives at a conclusion that the allegation against the Respondent is
malicious, or the Aggrieved Woman or any person making the complaint on her behalf has made the complaint
knowing it to be false, or has produced any forged or misleading document, it may recommend action against
the woman or the person who made the complaint in accordance with the applicable service rules. [Section
14(1)]

11.2 Safeguard: A mere inability to substantiate a complaint, or provide adequate proof, shall not by itself
attract action under this Clause against the complainant. A finding of malice may be arrived at only after an
inquiry, on the basis of evidence available. [Section 14(2)]

12. Confidentiality
12.1 The contents of the complaint, the identity and addresses of the Aggrieved Woman, Respondent and
witnesses, information relating to conciliation and inquiry proceedings, recommendations of the Internal
Committee, and the action taken, shall not be published, communicated or made known to the public, press or
media in any manner, provided that information may be disseminated regarding the justice secured to any
victim without disclosing the name, address, identity or particulars of the Aggrieved Woman, Respondent or
witnesses. [Section 16]

<!-- page 6 -->

12.2 Any breach of this confidentiality obligation shall be dealt with as misconduct in accordance with the
applicable service rules of PAGREXCO, and, in the absence of such service rules, in the manner prescribed
under the Rules. [Section 16, read with Rule 12]

13. Duties of the Employer
• Provide a safe working environment at the workplace;
• Display at a conspicuous place the penal consequences of sexual harassment and the composition of the

Internal Committee;
• Organise workshops and awareness programmes at regular intervals for sensitising employees and

Members of the Internal Committee;
• Provide necessary facilities to the Internal Committee for dealing with complaints and conducting

inquiries;
• Assist in securing the attendance of the Respondent and witnesses before the Internal Committee;
• Make available such information to the Internal Committee as it may require in relation to the inquiry;
• Provide assistance to the Aggrieved Woman, if she so chooses, to file a complaint under the Indian Penal

Code or any other applicable law;
• Treat sexual harassment as misconduct under the service rules and initiate action for such misconduct;
• Monitor the timely submission of reports by the Internal Committee. [Section 19]

14. Duties of Employees
• Maintain dignity and respect towards colleagues at the workplace and refrain from any act of sexual

harassment;
• Cooperate with the Internal Committee/Local Committee during the conciliation or inquiry process;
• Maintain confidentiality in accordance with Clause 12; and
• Participate in awareness and training programmes organised by PAGREXCO.

15. Protection Against Victimisation
PAGREXCO shall ensure that the Aggrieved Woman, witnesses, or any Member of the Internal Committee is
not subjected to victimisation on account of a complaint made, or evidence given, under this Policy. Interim
protective measures shall be provided in accordance with Clause 9.6 (Interim Relief) during the pendency of
an inquiry.

16. Annual Report and Statutory Disclosures
16.1 The Internal Committee shall prepare, in each calendar year, an annual report in the prescribed form and
submit the same to the Employer and to the District Officer. [Section 21; Rule 14]
16.2 The Employer shall include, in its report, the number of cases filed and disposed of under this Policy
during the year, as required to be disclosed under applicable law. [Section 22]

<!-- page 7 -->

17. Review and Amendment
This Policy shall be reviewed periodically, and in any event upon any amendment to the Act or the Rules or
upon issuance of statutory guidelines by the Government, so as to remain fully consistent with the law in force.

Declaration
Punjab Agri Export Corporation Limited reaffirms its commitment to a workplace where every employee is
treated with dignity, equality and respect, and to the prompt, fair and confidential redressal of complaints of
sexual harassment strictly in accordance with the Sexual Harassment of Women at Workplace (Prevention,
Prohibition and Redressal) Act, 2013 and the Rules made thereunder.
