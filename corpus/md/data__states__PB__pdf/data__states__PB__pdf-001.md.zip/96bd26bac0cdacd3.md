---
doc_id: "96bd26bac0cdacd3"
source_url: "https://cdn.s3waas.gov.in/s3c3992e9a68c5ae12bd18488bc579b30d/uploads/2022/11/2022112510.pdf"
ministry: "Amritsar"
title: "WODA Notification on restrictions imposed on area around the 2 Ammunition company (23 field ammunition depot) at Gaziwal Maini, Beas, District Amritsar (Dated-21-11-2022)"
date: ""
pages: 9
method: "tesseract:pan+eng"
script: "LATIN"
needs_ocr: false
sha1: "e2b373bb9fed5ff5"
---

<!-- page 1 -->

(੬
OFFICE OF :
DEPUTY COMMISSIONER, AMRITSAR । 24%;; ੧ ਕਾ <<.
(DRA(T) BRANCH) . bins 0 109, ਅੰਮ੍ਿਸਰ।
Email:- dc.asr@punjab.gov.i == (ਡੀ.ਆਰ-ਏ. ਦੀ. ਸਾਖ)
0183-2226262 (Camp Office)
To
Sub Divisional Magistrate,
Baba Bakala Sahib.
No.DRA(T)/2293 Dated: ali! aL
Sub: Regarding displaying the notice on notice Board.
In reference to subject cited above, by attaching Ministry of
Defence notification dated 22.09.2022 (copy attached) regarding imposing
restrictions under section 7 of Work of Defence Act, 1903 upon the use and
enjoyment of the land lying in the vicinity of 2 Ammunition Company (23 Field
Ammunition Depot) at Gaziwal Miani District Amritsar to kept said land free
from buildings and other constructions it is directed to display this Public
Notice along with the annexure on the notice board.
Annexure:
1) Public Notice.
2) Map to scale depicting khasra numbers as well.
3) Ministry of Defence Notification dated 22.09.2022.
0”
9
Deputy Commissioner,
Amelfsar.
Endst. No.DRA (T)/ 2294-229 Dated:24:} yJ22 4
A copy of the above is forwarded:
1) Commanding Officer, 2 Ammunition Company (23 Field Ammunition
Depot) Gaziwal Miani, Amritsar for information and necessary action.
2) DPRO, Amritsar to promulgate this Public Notice through publication in
newspapers and social media.
2) Naib Tehsildar, Beas to display this Public Notice along with the
: annexure on the notice board and through proclamation.
4) DIO, NIC to upload the display this Public Notice along with the
annexure on the official website.
22"
iia’
Deputy Commissioner,
geome
oC
Scanned with CamScanner

<!-- page 2 -->

ਗਨ -“
—
OFFICE OF = ਦਫਤਰ _
(0੧੪7) BRANCH) Ss eh (ਡੀ.ਆਰ.ਏ. ਟੀ. ਸ਼ਾਖਾ)
Email:- de.asr@punjab.gov.in ‘Cea Phone no:- 0183-2223551 (Office),
0183-2226262 (Camp Office)
PUBLIC NOTICE
As per section 3 of Works of Defence Act, 1903 (7 of 1903) the Ministry
of Defence, Govt. of India has declared vide CG-DL-E22092022-239002 dated
22 September 2022 in the Official Gazette that in supersession of the
notification of the Government of India, in Ministry of Defence, number $.R.O
154, dated the 6th October 2004, except as respects things done or omitted to be
done before such supersession, it is necessary to impose restrictions specified in
the clause (b) and ( 6) of section 7 of the said Act upon the use and enjoyment
of the land described in the Schedule herein, being land lying in the vicinity of 2
Ammunition Company (23 Field Ammunition Depot) at Gaziwal Miani in the
District of Amritsar, in the State of Punjab, in order that the said land may be
kept free from buildings and other constructions.
SCHEDULE
All the land comprised in the area lying between the outer boundary
showing OQD (Outside Quantity Distance) and inner boundary of the 2
Ammunition Company (23 Field Ammunition Depot ), situated at Ghaziwal
Miani in the district of Amritsar, State of Punjab, as per map to the scale and
Khasra numbers shown below of villages: Bal Sarai Khurad, Waraich, Budda
theh, Jalluwal, Dolonangal
Khasra No. - Village Bal Sarai Khurd
64//6 Min, 14 Min, 15, 16, 17, 18 Min, 22 Min, 23, 24, 25, 65//2/2/2, 3, 4, 5,
6/1, 6/2, 6/3, 7/1, 7/3, 8/3, 9/1/1, 9/1/2, 9/2, 10 Min, 11, 12, 13/2, 19, 20, 21,
22/1, 66/1 Min, 2 Min, 7 Min, 8 Min, 9, 10, 12/1, 13/2, 14, 15 Min. 16/1, 16/3,
Scanned with CamScanner

<!-- page 3 -->

/
/ V/A7, 18/1, 18/2, 21, 22, 23/1, 23/2, 23/3, 41/25, 6//5/1, 5/2, 6/1, 6/2, 7, 12, 13,
/ 14, 19, 20, 21, 7//5/1, 5/2, 6, 7, 13, 14, 18/1, 18/2, 22, 23, 10//5/1, 5/2, 6/1/1,
6/1/2, 6/2, 13/1, 13/2, 14/1, 14/2, 15, 16, 17, 18/1, 18/2, 21/1/1, 21/1/2, 21/1/3, !
` 21/2, 22, 23/1, 23/2, 24, 25, 1161/1, 1/2, 1/3, 1/4, 8, $, 10, 11, 12, 13/1, 13/2,
14, 17 Min, 18/1, 18/2, 19/1, 19/2, 20, 21/1, 21/2, 21/3, 22/1, 22/2, 23/1, 23/2/1,
23/2/2, 24/1, 24/2, 24/3 Min, 14//1, 2/1, 2/2, 3/1, 3/2, 3/3, 4 Min, 8/2, 9/1, 9/2,
10, 11, 12/1, 19/2 Min, 20, 21 Min, 15//1/1, 1/2, 2, 3, 4/1, 4/2, 5, 6/1, 6/2, 7, 8,
9, 10/1, 10/2, 10/3, 11, 12, 13, 14/1, 14/2, 14/3, 15/1, 15/2, 16/1, 16/2, 17 18/1,
18/2, 19/1, 19/2, 20/1, 20/2, 21/1, 21/2, 22/1, 22/2 23/1, 23/2, 23/3, 24, 25/1,
25/2, 26, 18//2, 3, 11, 12, 19, 20, 21, 22/1, 22/2, 19//16, 25, 24//4, 5, 6, 7/1,
15/2, 25//1, 2, 3, 8, 9, 10, 11, 12, 13, 14, 17, 18/1, 18/2, 19/1, 19/2, 20/1, 20/2,
21/2 Min, 22, 23, 24, 28//1/1, 1/2, 2/1, 2/2, 2/3, 2/4, 2/5, 3/1, 3/2, 4, 5/1, 6/2, 7
Min, 8/1, 8/2, 8/3, 9, 10, 11/1, 11/2, 12/1, 12/2, 13/1, 14/1, 18/1/2, 19/1/2/1,
19/1/2/3, 19/2/1/1, 19/2/1/2, 19/3/1/1, 19/3/1/2, 20/1, 20/3/1, 37/11, 20/1, 20/2,
20/3, 21, 38//2/2, 3/1, 3/2, 4, 5, 6/1, 6/2, 6/3, 7/1, 7/2, 8 Min, 14 Min, 15/1, 15/2,
16 Min, 25 Min, 51//1/2, 1/3 2/1, 2/2 9/3, 10/1 Min, 10/2 Min, 11 Min, 12, 13,
18/3 Min, 19 Min, 22/1 Min. 22/2/2, 23/1, 23/2, 27 60//3/1 Min
Khasra No.-Village Jalluwal
| 534, 541, 542 543, 544, 545, 546, 547, 548, 549, 550, 551, 615 Min, 617 Min,
618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 634 Min, 635, 641
Min, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656,
657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672,
673, 674, 675, 676, 683, 684, 685, 686, 687, 688, 689, 690/1, 761 Min, 762, 763
Min, 811 Min, 812 813, 814, 815, 816, 817 Min, 818, 819, 820, 821, 822, 823,
824 825, 826, 827, 828, 829, 830, 831
Khasra No.-Village Dolo Nangal
| 1416, 1417, 1418, 1429, 1430, 1432, 1433, 1434, 1435, 1436.
Scanned with CamScanner

<!-- page 4 -->

ਸਿ a
17/1, Te, aun Min, 19 Min, 20/1, 20/2, 20/3, 20/4, 21/1, 22/2, 23, 24 Min
25 Min, 81//1 Min, 10/1 Min, 82//3/1, 4/1, 5/2, 6/1, 84//1, 2/1, 10/2, 11/1, 118
20/2, 85//2/2, 3, 4, 5, 6,7,8, 9/1, 9/2 10/1, LI/I/, 11/1/2, 11/1/3, 11/2, 11/3, 12,
13, 14, ਲੇ 16/1, 17, 18, 19, 20/1, 20/2, 21/1, 21/2, 22, 23, 24, 25/1, 86/16 Min,
24/2 Min, 25/1, 25/2, 87//4, 5, 88//1, 2, 3, 4/1. 4/2, 4/3, 5/1, 5/2, 5/3, 6, 7/1, 7/2,
8, 14/1, 94/11/3
1//4, 5, 6, 7, 8, 13 Min, 14, 15, 16/1/1, 16/1/2, 16/2, 17/1, 17/2, 18, 19 Min, 22
Min, 23, 24, 25, 2//1, 9, 10, 11, 12, 13/1, 18/2, 19, 20/1, 20/2, 21/1, 21/2, 22,
4//20/2, 21/1, 5/25/1, 7/1, 2/1, 9/2, 10/1, 10/2, 10/3, 11/1, 19/2, 20, 21/1, 21/2,

22, 8/1, 2/1, 2/2, 3, 4, 5, 6, 7/1, 7/2, 8/1, 82, 9, 10, 11, 12, 13, 14, 15, 16, 17,
18, 19, 20, 21, 22, 23, 24/1, 24/2, 25, 9616/1 Min, 16/2 Min, 25 Min, 1275, 6,
15/1, 15/2, 15/3, 15/4, 15/5, 15/6, 15/7, 15/8, 15/9, 15/10, 15/11, 15/12, 15/13,
15/14, 15/15, 15/16, 15/17, 16, 25/1, 25/2, 13//1, 2/1, 2/2, 3, 4, 5, 6/1, 6/2, 7, 8
9, 10, 11/1, 11/2, 12, 13, 14, 15, 16/1, 16/2, 16/3, 17/1, 17/2, 18/1, 18/2, 19, 20,
21/1, 22, 23/1, 23/2, 24, 25, 26, 146171, 10/2, 11/1, 20/2, 21, 22/1, 16//S/1,
5/2/2, 61, 71, 141, 17/2, 17MM, 1/2, 10, 11/1, 11/2, 20/2, 18//20 Min,
19//16/2, 24/1, 25/1 Min, 21//1/1, 10/2, 22//1/1, 1/2, 2, 3, 4, 5, 6/1, 6/2, 7/1, 7/2,
8/1, 8/2, 9, 10, 11, 12/1, 12/2, 13, 14/1, 14/2, 15, 16, 17/1, 17/2, 18, 19, 20, 21,
22, 23, 24/1, 24/2, 25, 23//5, 6, 15/1, 15/2, 16, 25 Min, 25//5 Min, 26//1, 2, 3, 4,
5, 6, 7, 8/1, 8/2, 9/1, 9/2, 10 Min, 11 Min, 12, 13/1, 13/2, 14/1, 142, 15/1, 15/2,
15/3, 16, 17, 18, 22/2, 23/1, 23/2, 24, 25, 28//6/1, 6/2, 7, 13/2, 14, 15, 16, 17,
24, 25, 29//4/1, 4/2, 5 Min, 7/3, 8/1, 11, 13/2, 18/1 Min, 19/2, 20, 21 Min, 22/1
Min, 37//23, 38/1, 2, 9, 10, 11, 12, 19, 20, 21, 22, 3902 Min, 3, 4/1/1, 4/1/2,
4/2, 5, 6/1, 6/2, 71, 72, 8, 9, 13, 14, 15, 16, 17, 24, 25, 42//1/1, 1/2, 2/1/1,
2/112, 2/2, 9, 43/122, 3/1, 3/2, 3/3, 4, 5 Min, 6 Min, 7, 8 9, 13, 14/1, 14/2/1,
14/2/2, 14/3, 14/4, 15 Min, 16 Min, 17, 18, 19/1, 19/2, 21/1, 21/2, 22, 23, 24/1,
| 24/2, 24/3, 25 Min, 26, 51//1, 2, 3, 4, 5/1, 6/2, 7, 8, 9, 13, 14/1, 14/2, 15 Min, 17

~ Scanned with CamScanner

<!-- page 5 -->

And whereas as per sub section 2 of Section 3 of the Works of
Defence Act, 1903, the public notice of declaration published in official gazette
regarding the land given in the schedule above is to be made. Hence with
issuance of these orders the General Public is hereby informed that the use and |
enjoyment of land in the vicinity of 2 Ammunition Company (23 Field :
Ammunition Depot) at Gaziwal Miani as specified in clause (b) and ( c) of ਰ
section 7 of the said Act ibid has been restricted. |

The said restrictions shall come into force with effect from the Ist ਰ੍‌

day of November, 2022.

A sketch plan of the said land may be inspected in the office of the
undersigned in Room No. 130, DRA (T) Branch, First Floor, District
Administration Complex, Amritsar.

pe scale depicting khasra numbers as well.
2) Ministry of Defence Notification dated 22.09.2022.
(6੧੭੭
Deputy Commissidn 19
Amritsar.
Scanned with CamScanner

<!-- page 6 -->

|
ਕਿਲ ਜੰ. ਭੀ.ਬਜ- 3300499 REGD. No. D. L-s3004/00 |
eas) ਕਹ <%॥ ik
=— —_, d a
Che Gazette of India
ਯੀ.ਗੀ.-ਵੀ.ਬਜ.-ਗ.-22092022-239002
CG-DL-£-22092022-239002
ਭਜਧਪਟਗ
EXTRAORDINARY
'ਯਗ 11--ਬਚਭ 4
PART II—Seetion 4
ਬਬਿਕਗਕ ਜੇ ਜਕਗਗਿਰ
PUBLISHED BY AUTHORITY
aS
a 15) ਜਕੁੰ ਕਿਕਜੀ, ਕ੍ਰੁਵਧਰਿਕਕ, ਜ਼ਿਜ=ਕਟ 22, 2022/ TH 31, 1944
No. 15] NEW DELHI, THURSDAY, SEPTEMBER 22, 2022/BHADRA 31, 1944
-
cer ਸੰਗਜਧ
ਕਬਿਜ੍ਬਜ
a feet, 22 ਗਿਜਗਰਨ, 2022
aan. 15(a) adr acai, vat ਜੰਥਸੰ ਘਧਿਜਿਧਸ, 1903 (1903 ਕਗ 7) ਕੇ ਘਗ 3 ਜ਼ਗ ਚਕਜ
ਅਜਿਗੀਂ ਕਗ ਬਧੀਗ ara ਲੂ ਗੀ aI ਸਟਕਗ, car ਸੰਕਜਧ ਕੀ ਘਧਿਗੂਜਗ ਗੰ. ਕ.ਜਿ.ਯ. 154, ਜਹੀਸ਼ 6 ਯਜੂਸ਼,
2004 ਕੇ ਯਧਿਗੰਜ ਕਜਜੇ ge ਸਿਗਧ ਚਜ ਕਗਗੋਂ ਕੇ; ਗਿਟੋਂ ਨੇਸੇ ਮਪਿਜਗਗ ਸੇ ਧੂਕੰ ਕਿਧ ਜਧ ਜੈ ਗੇ eT ਕਰ ਜੀਚ ਪਿਸ ਗਧੇ
ਤੂ, ਬੀਧਗ ਕਜਜੀ ਦੈ ਗਿ ਤਜ ਘਧਿਜਿਧਸ ਕੀ ਜੂਸਜੀ ਸੌ ਕਗਿੰ gh, ਜੀ 2 ਗੀਜ are ਜੰਗਗੀ (23 fies ਗੀਜ are
ਥੀ are 7 ਕੋ ae (a) ae aE (ਗ) # ਕਿਜਿਰਿੰਟ ਜਿਕੰਧਗੀਂ ਕੇ afte ਕਕਜ ਭਕ੪ਧਕ ਗਸਭਜੀ ਨੈ ਜਪਿ ਤੁਜ aA ਕੀ
ਥਜੀਂ cite ਯਨਧ ਗੱਜਿਸੰਅ ਸੇ ਸੂਜ ਹਥ ਗ ਗੇ ।
2. ਤਜ ਜਿਕੰਪਜ 1 ਜਕੰਕ;, 2022 ਜੇ ਜਰੂਜ ਲਹਿ ।
3. ਰਲ ੂਸਿ ਕੀ ਲੰਜਜ ਧੀਬਜ Pe ਤਾਗਧੂਜ, ਕਸ਼ੂਜਸਟ ਕੋ; rier ਸੋਂ ਕਿਧ ਗ ਸਰਗ ਦੈ ।
age
ag ਸਟੀ aft, Sra ਗਜਬਿਬ ਕੇ; aay, ਜੰਗਕ Ter ਘਸੂਰਗਨ Fare ਸੋਂ ਗਯੀਗਜ਼ ਸਿਗਜੀ waters 2
ਜੀਗ ਕੀਟ ਅੰਜਵਿਕ ਸੀਸ ਕੇ ਕੀਬ ਇਪਜ ਐਜ ਸੇ ਜਿਜਕਨ ਕਜੀ 2
6341 012022 a
Scanned with CamScanner

<!-- page 7 -->

3
THE GAZETTE
/ GAZITE OF INDIA EXTRAORDINARY
11711 Ste ay
. |
”, he pan 4
[00੦0 |
ਈਂ 1
(1H. ਸੰ. 1233/ਹੁਰਸ7)/ਤੀ)/2022]
MINISTRY OF DEFENCE
NOTIFICATION
New Delhi, the 22nd September, 2022
S.R.O. 15 (I). —In exercise of the powers conferred by Section 3 of the Works of Defence
Act, 1903 (7 of 1903), and in supersession of the notification of the Government of India, in
Ministry of Defence, number S.R.O. 154, dated the 6" October 2004, except as respects things
done or omitted to be done before such supersession, the Central Government hereby declares that
it is necessary to impose restrictions specified in clauses (b) and (6) of section 7 of the said Act
upon the use and enjoyment of the land described in the Schedule herein, being land lying in the
vicinity of 2 Ammunition Company (23 Ficld Ammunition Depot) at Gaziwal Miani in the District
of Amritsar, in the State of Punjab, in order that the said land may be kept free from buildings and
other constructions.
2. The said restrictions shall come into force with effect from the 1" day of Novernber,2022
~*~ ee
3. A sketch plan of the said land may be inspected in the office of the Deputy Commissioner,
Amritsar.
SCHEDULE
All the land comprised in the arca lying between the outer boundary showing OQD
(Outside Quantity Distance) and inner boundary of the 2 Ammunition Company ( 23 Field
Ammunition Depot), situated at Ghaziwal Miani in the district of Amritsar, State of Punjab, as per
map to the scale.
Scanned with CamScanner

<!-- page 8 -->

[ਅਗ ave 4) ਜਰ ਕਗ ਗਕਧਕ : aa
ਹਾ ============-=--3
_ MAP TO THE SCALE
| |
|
ਭਾ ਰਿ wen ‘ |
|
Legend |
[ਲ. No. 1233/US(L)/D(L)/2022)}
RAKESH MITTAL, Jt. Secy.
Scanned with CamScanner

<!-- page 9 -->

੧੯੧”, ੧," ਉਵ 2” ea
. Ee By Nee ੬ sf
ਉਘੇ...“ ੧੦ ><-੧੯.'੪ '%" "2 ਚ
LAS AONE es ੧੬੧" ੧੫੧੧
ee TI OR OE Ne
"67 LM 11,714 Ct Nem UF ਦਾ
| cn aie Ott Ne ਇ2% Lucerne |
1 ਚ,“ 4///66777੧4/7%. LNG ioe Rene ra
CX DOIN NA f 2. Pe, Pe eter el
ਹੱ < ਨੂ ਹਉ! iff m4 Xe PWN Ooh we \e ੧
pe Ny Ub La 1 at ਨੀ Scien 4
Ve Nel RO*>, HI he ee a BRN EG BAS
os 7 an '".. 9੯0” 4 ੪" 99”,
9 coe Stet x Veber seme ‘|
EIN ESO NAA Oe Ee GN ARON
229੮. AGE as ee fe ਆ S|
੧੮ Pees eNO Nt ੯ ESA tod
. Won oes b He ot e 2 |
28 Ww ੯” ੬ Sey eee ੭੧, = ਸਿ eee 2੮
Xs 4 ੧੪੦. ੧੭੧੯੭ ee ਪਲ Oe " te
ONE IEA EN ee ੬0 ਚ, ਦਰਦ eM AN
(ਵੀ ਵਿ (੪੧੯, “ਡੇ. ERO ਪੀ Sane af
poe ੭੧੧ ? est Anes RSs Sa et ੬੧੯ Se
ਲ: .#2 ੧੧੧੦੧”, -ਡੰ₹੨.. 25. “੬੪ %- ੪੧੧
\ ee NAL NTL ER Nee ੮” oe "2੨੪ ਆ
ਮਦ ਨਾ Naot EAN TIE Nee NY io 0 %੯|
6 ° ANE DIN AY Ate ae ee Xe Nh
NOH SEIN Re
ogee INTL (7 €੧€...0(:੮%”, "੪
A ay SY \ $', Ne bee oe Ue ve
* fi MN PETER oi aN [eee et te
ਕਿ 6077੧“ LENT ₹੧੧%੦"$£”੦੧" ੧੦ ".#.;
SARA NIN GB ee ੧"' BN a ਆ
A NNN INO STON oOo oN
vad LED SISA Td de ve PN BOE Se oe Nay
"17047 AAD AAS * ਆ. N. ਸਰ
By eet, NE BEAT Te 0 9 (ae feet 9 ਦੇ
"੧੩੧7?" oe ਦਭ ਦਾ ‘
Scanned with CamScanner
