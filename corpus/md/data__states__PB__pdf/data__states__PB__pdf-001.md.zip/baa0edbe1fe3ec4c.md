---
doc_id: "baa0edbe1fe3ec4c"
source_url: "https://ipr.punjab.gov.in/media/documents/Final_Gazette_Report_-_2024-10-07T162606.190.pdf"
ministry: "Directorate of Information & Public Relation, Punjab"
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "22b910aff52914ae"
---

<!-- page 1 -->

15024

PUNJAB GOVT. GAZ. (EXTRA), OCTOBER 2, 2024 (ASVN 10, 1946 SAKA)

EXTRAORDINARY
Published by Authority
CHANDIGARH, WEDNESDAY, OCTOBER 2, 2024 (ASVINA 10, 1946 SAKA)
GOVERNMENT OF PUNJAB
DIRECTOR INFORMATION & PUBLIC RELATIONS
ADVERTISEMENT POLICY FOR WEBSITES 2022
NOTIFICATION
The 1st October, 2024
No. I/940838/2024.–ADVERTISEMENT POLICY FOR WEBSITES 2022 will be Extended for
One year from 8.10.2024 issued vide No. I/439348/2022, dated 7th October and Amended No. PR I/594156/
2023, dated 6th July, 2023. It may be amended at any time by the DIPR Punjab.
Chandigarh
The 1st October, 2024

MALWINDER SINGH JAGGI, IAS
Secretary to Government of Punjab
Information and Public Relations

4006/10-2024/Pb. Govt. Press, S.A.S. Nagar

( 15024 )
