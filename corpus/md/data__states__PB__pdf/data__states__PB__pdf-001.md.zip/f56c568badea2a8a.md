---
doc_id: "f56c568badea2a8a"
source_url: "https://ayboard.in/wp-content/uploads/2024/10/CME_Guidelines.pdf"
ministry: "Board of Ayurvedic and Unani Systems of Medicine, Punjab"
title: "CME Guidlines"
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0a298008eb0d9f3e"
---

<!-- page 1 -->

CONTINUOUS MEDICAL EDUCATION GUIDELINES

In compliance to the regulation Section 2 (d), 7 (8), 20 (14) of National Commission
for Indian System of Medicine (Ethics and Registration) Regulations, 2023, CME is to be
incorporated to secure credit points for renewal of registration. Medical Science is Dynamic
and there is no end of learning for a doctor. This is essence the Concept of continuing medical
education (CME). The main objective of CME is to upgrade knowledge and skill regularly and
ensure compliance with existing guidelines by registered ISM Practitioners under NCISM Act,
2020 and IMCC Act, 1970. This CME guideline provide a frame work for uniform, clear
and structured CME modules for both in -person conferences and online webinar,
electives as well as their implementation. This CME guidelines will ensure adequate
upgradation of knowledge along with the improved quality service of ISM Practitioners.
CME in the medical profession refers to the ongoing development of medical and nonmedical competencies, including professionalism, interpersonal, managerial, and
communication skills. CME training commences after the completion of basic medical
education. It continues throughout each doctor’s professional life. CME is learner-centered,
self-assessment-based, and holistic in nature. CME recognizes the need for the healthcare
professionals of ISM to develop all facets, which go beyond medical knowledge and skill; it
includes effective communication, evaluation of emerging evidence, the practice of ethics, the
application of law in healthcare, and an understanding of public health, health policy, and
health economics.
o

Continuous Medical Education (CME) credit points refer to the points allocated by the
Board of Ethics and Registration NCISM to ISM Practitioners for attending CME programs,
including Conference, Seminar, Workshop, Hands on Training, Publications in Peer Reviewed
journals, Pub Med, indexed in Scopus and Web of Science, Registered Patent, Publication of
Textbook, short courses including Fellowships & other programs authenticated by the Board
of Ethics and Registration NCISM.
Requirement.
S. No.
1.

Registration / Renewal
Whose registration renewal is due on
or before 28.02.2025

Credit Point
Exempted from CME Credit Points

2.

Whose registration renewal is due in
between 01.03.2025 to 28.02.2026

Shall obtain minimum 10 credit
points for the purpose of renewal

3.

Whose registration renewal is due in
between 01.03.2026 to 28.02.2027

Shall obtain minimum 20 credit
points for the purpose of renewal

4.

Whose registration renewal is due in
between 01.03.2027 to 28.02.2028

Shall obtain minimum 30 credit
points for the purpose of renewal

5.

Whose registration renewal is due in
between 01.03.2028 to 28.02.2029

Shall obtain minimum 40 credit
points for the purpose of renewal
1|P a ge

<!-- page 2 -->

6.

Whose registration renewal is due in
between 01.03.2029 to 28.02.2030 and
2030 onwards.

Shall obtain minimum 50 credit
points for the purpose of renewal

Following rules of CME and modalities for Approval and Implementation: Who can organize CME
o Board of Ethics and Registration, NCISM.
o State / UT ISM Councils after due approval from Board of Ethics and Registration.
o State level / National level, Organizations registered, audited and older than 10 years.
o Private institutions / Govt. institutions older than 25 years having highest NCISM
rating.
o State / Central Government organizations.
o The organization should have all the requisite and demonstrated ability to plan and
implement CME programs to cover the targeted group like General practitioners, &
Specialists, Medical Teachers etc. of ISM and Experienced in organizing CME.
All National/State level organizations conducting CME programmes in India at present should
approach the State ISM Councils / Board of Ethics and and Registration NCISM. On the receipt
of such request State ISM Councils / Board shall consider the following factors for being
granting permission for conducting CME programmes and shall award credit points:
o CME programmes meant for graduate should have a brief session on NCISM, Board of
Ethics and Registration, Regulation 2023, National Health Programs on relevant subject
along with adequate exposure to recent advances, changing modalities of treatment,
adequate knowledge about consumer protection and medical insurance laws, record keeping
and medical audit and to know initiatives in Ministry of AYUSH in General.
o The organizations should provide the schedule and transcripts of each C.M.E. activity.
o The transcript of each CME program must be relevant to updating the knowledge of the
medical practitioners by way of latest medical advances, National Health Program, and the
local needs of the Area/Zone/State.
o The resource personnel should be experienced enough in providing the CME programs.
o Organizations should make arrangement for advance publicity to the targeted group of
participants.
o The organization should undertake to publish handouts, bring out a brief of each CME and
also prepare a list of participants and sent it to Board of Ethics and Registration, NCISM
immediately after the CME program.
o The methodology of feedback evaluation program should be intimated in advance.
o The organization should evaluate CME to indicate the benefits to participants by way of
updating of knowledge, upgrading their ability and benefit to the patients.
Note: State Level means only state practitioners can participate, National Level means more
than 5 / multiple states participate, International Level means resource persons / participants of
more than 3 countries participants.
Responsibility of hosting institution:

2|P a ge

<!-- page 3 -->

o The discipline in which CME programs are to be conducted must be finalized by the
host institution/organization at least three months in advance.
o Proposal for the CME, along with a tentative date and program plan, must be submitted
to the State ISM Medical Council at least two months in advance.
o After receiving permission from Board of Ethics & Registration, National Commission
for Indian System of Medicine, the host institution/organization is responsible for
sending necessary invitations to both resource persons and participants, as well as
publicizing the program to ISM practitioners in the state.
o If the CME is residential, the host institution/organization must bear the necessary
arrangements for participants' accommodation.
o The host institution/organization must collect abstracts or manuscripts from all resource
persons well in advance of the program.
o After the program, a detailed feedback report, including participant evaluations, must
be sent to the State ISM Council and Board of Ethics & Registration, National
Commission for Indian System of Medicine.
o After the CME program, the host institution/organization must submit actual bills
(including GST) for expenses incurred in organizing the entire program to Board of
Ethics & Registration, National Commission for Indian System of Medicine.
Responsibility of State ISM Councils
o Forwarding the CME proposal for approval of Board of Ethics & Registration, National
Commission for Indian System of Medicine.
o Interaction between the host institution/organization and the Board of Ethics &
Registration, National Commission for Indian System of Medicine for CME program
finalization, problem resolution, etc.
o To send official invitations for the Board of Ethics & Registration, National
Commission for Indian System of Medicine. One observer from Board of Ethics and
Registration, NCISM will have to attend the program.
o To send announcements well in time for wide publicity and maximum program
participation.
o To collect the program proceedings, detailed program reports, and evaluation analysis
from the CME hosting organization.
o To supervise issue of certificates of participation to present ISM doctors and resource
person.
o The web portal of the Board of Ethics & Registration, National Commission for Indian
System of Medicine, is to be used for conducting CMEs.
o The ISM Council shall also maintain a register of both online and offline data, listing
the names of ISM doctors and their acquired credit points.
o To handle the large volume of work involved in approving institutions/organizations
conducting CME programs, maintaining records of CME programs attended annually
by registered medical practitioners, and coordinating with other State Medical
Councils/Board of Ethics & Registration, National Commission for Indian System of
Medicine, a separate section should be created within State ISM Councils.

3|P a ge

<!-- page 4 -->

o Foreign nationals or NRIs wishing to participate in a CME program must be registered
medical practitioners in accordance with the rules governing the registration of ISM
practitioners currently in force in the state/country.
Financial Assistance
o Practitioners must pay prescribed CME fees to the Board of Ethics & Registration,
National Commission for Indian System of Medicine. After coordinating with the
State ISM Council, the Board of Ethics & Registration, National Commission for
Indian System of Medicine will allocate funds to the concerned State ISM
Council/Organization/Institution for organizing CMEs.
o Board may allocate funds in advance of 50% to 75% of the collected fund for
particular CME or proposed expenditures to the organizer, in consultation with ISM
Councils and concerned organization.
o The remaining payment to the organization will be paid after submitting actual bill
including GST for expenses incurred organizing the entire program.
o Furthermore, the State ISM Council can also provide financial assistance.
Note: It is the discretionary power of Board of Ethics and Registration, National
Commission for Indian System of Medicine to decide the fees of every CME depending
on relevance, quality and proposed outcome for the benefit of ISM practitioners.
GUIDELINES FOR C.M.E APPROVAL
1. Credit points to be awarded will be at the sole discretion of the Board of Ethics &
Registration, National Commission for Indian System of Medicine and will depend on the
subject matter, the speaker’s status, and the quality of papers presented at the
CME/Conference.
2. Any professional organization, body, or institution intending to hold CMEs should apply
using the prescribed application form for the State ISM Council/Board of Ethics &
Registration, National Commission for Indian System of Medicine. The application must be
accompanied by the complete program of the CME/Conference, including the names,
designations, and countries of the speakers, as well as the subject of each speech and
proposed applicable fees. (Provided by prescribed format as Annexure)
3. In the application submitted to the State ISM Council/ Board of Ethics & Registration,
National Commission for Indian System of Medicine, the organization, body, or institution
intending to hold CMEs should specify the duration allotted to each speaker, along with their
topic, for the granting of credit points.

4. After verifying the credentials of the organization and program details, the State ISM
Council must forward the proposal to the Board of Ethics & Registration, National
Commission for Indian System of Medicine, accompanied by a recommendation or rejection
4|P a ge

<!-- page 5 -->

report. State ISM Councils, Associations, or Organizations shall issue certificates to
delegates who have attended the CME. Certificates should not be distributed on the first day
during CME/Conference registration. They should be distributed or awarded only after the
signature of the registrar, competent authority and observer of Board of Ethics and
Registration, National Commission for Indian System of Medicine. Attending ISM doctors
may also be given the option to download a soft copy of the certificate.
5. Associations/Organizations will be duty-bound to send the feedback of the delegates and a
list of the delegates who attended the CME/Conference.
6. No CME attendance certificates will be issued prior to the completion of the CME,
workshop, or conference.
7. One observer nominated by the Board of Ethics & Registration, National Commission for
Indian System of Medicine and one observer nominated by the state ISM council will attend
the CME as observers. Upon approval of the observers, CME-secured credit points will be
credited to the practitioner's account. Practitioners can access their CME credit point through
the portal.
8.

8. If any certificate issued by the State ISM Council/organization is found to be false, it is
subject to penalty/punishment under misconduct of the National Commission for Indian
System of Medicine – Board of Ethics and Registration, Regulation 2023.

GUIDLEINES FOR ISSUING CREDIT POINTS FOR CME/CONFERENCE
Guidelines for issuing credit hours for Published Medical text book/chapter in text
book/Research Papers in International & National Index Medical Journals and Participation in
International Conference/ CME’s/ Workshops.
Sr. No

Activity

Credit Points

1.

Guest Lecture of 60 minutes duration by foreign faculty
of international repute

5 POINTS

2.

3.

4.

5.

6.

CME/Workshop/State/National conference of minimum
3 working hours Duration

5 POINTS

CME/Workshop/State/National conference of minimum
6 working hours Duration.

10 POINTS

International CME/Workshop/Conference of minimum
3 working hours Duration

10 POINTS

International CME/Workshop/Conference of minimum
6 working hours Duration

20 POINTS

Certificates obtained after studying Online Medical
Education Module of minimum 3 working Hours to
below 6 working Hours

5 POINTS

5|P a ge

<!-- page 6 -->

7.

8.

9.

10.

11.

12.

Certificates obtained after studying Online Medical
Education Module of 6 working Hours and Above
Guest Speaker /Resource Person in international
Conference
Paper Presentation
Conferences.

(Oral/Poster)

in

International

10 POINTS

10 POINTS

10 POINTS

Participation in International Conference as Delegate for
half day CME/Workshop/Conferences

05 POINTS

Participation in International Conference as Delegate for
full day CME/Workshop/Conferences

10 POINTS

Registered Patent

50 POINTS

13.
HPR Certificate
14.
Elective
15.

Author/Editor of Published Medical Text Book as per

5 POINTS
10 POINTS
50 POINTS

Scale of NCISM
16.

Sr. No

Author of Chapter Published Medical Text Book

10 POINTS

Paper Published in International Indexed Journal

Credit Points

1.

Original Article

10 POINTS

2.

Case Report

10 POINTS

Sr. No.

Papers Published in National Indexed Journals

Credit Points

1

Original Article

10 POINTS

2

Case Report

10 POINTS

6|P a ge

<!-- page 7 -->

Note: The credit point mentioned here are proposed tentatively, further it is the purview
of Board of Ethics and Registration, National Commission for Indian System of Medicine
to decide credit points during scrutiny of the CME proposal on real time basis, based on
points like relevance, quality outcome, skill oriented and credibility of resource persons.
o ISM practitioners who are unable to participate in CMEs, workshops, or conferences are
encouraged to earn credit points through electives, which are online medical education
modules.
o There is no age exemption for attending CME/Workshop/Conference.
o ISM practitioners should participate in CME and produce credit points and certificates at
the time of renewal of their registration.
o Above 70 years are exempted from CME credit points.
Electives
o All elective modules, along with their respective guidelines, will be made available on the
Board of Ethics & Registration, National Commission for Indian System of Medicine Portal
from time to time.
o ISM practitioners have to select one elective per annum, which carries 10 credit points.

Electives for CME Credit Point.
With the changing times the way of learning is changing, all are preferring online
mode of learning owing to the convenience, flexibility and to get the benefit of
newer technologies. Considering the advantages of online learning electives are
introduced for ISM practitioners to provide opportunity to practitioner to get
clinical/surgical/treatment skills. They are exposed and oriented with various
inter-disciplinary knowledge and skills for carrier advancements according to their
interest. Moreover, also to secure CME credit points.
o The electives shall be conducted as online program.
o Course-structure: Course subject shall be incompliance with BoER, NCISM
guidelines. The course content will be oriented towards advancement in the
modality of treatment, research, technological advancement, clinical skills,
treatment skills, update rules/regulations/Acts. And recent initiatives.
o Each electives subject shall be of 15 hours duration and divided in three modules
each module shall have of 5hrs, 9hrs & 1hrs Each.
Each Elective: Three Modules of 5hrs, 9hrs & 1hrs Each.
Sr.
Component
Durations
Credits
No.
(Hours)
1. Teaching by Video/Audio
05 Hours 10 credit point for
attending program
2. Video Demonstration / Practice /
09 Hours
Guided Learning / Assignment
7|P a ge

<!-- page 8 -->

3. Assessment

01Hours

o Course-duration: 12 months, (01 year, one should complete elective within 12
months from the date of registration for program.)
o Elective shall be evaluated interns of attendance and assessment, on the basis of
evaluation credit points are allotted. Practitioner can earn maximum 10 credit
points by completing 15 hours Elective Module Program.
o Assessment shall be conducted at the end each Program.
o List of Elective subject shall be made available for all including ASUS
practitioners.
o Practitioners may opt one time only one elective as per their choice from specified
list.
o Apart from one mandatory elective for about 12 months, the practitioners have
freedom to choose and additional electives as per their interest, to have advanced
skills and knowledge. But only one program for 12 months is considered for
credits.
o Course Co-Ordinator shall mean the institution / organization /expert ASUS
physician / Surgeon with which MoUs done with NCISM. These are given task of
developing and delivering electives modules and program.
o Online elective programs shall be made available on Board of Ethics and
Registration platform with the Identified Course Co-Ordinator.
o The BoER, NCISM shall notify to the ASUS Practitioners on 1st January 2025 to
28th February 2025 every year, the list of online learning electives going to be
offered.
o It shall be ensured that the adequate facilities should be there with course CoOrdinator.
o The Course Co-Ordinator / Institute must designate a facilitator to guide the
students to out the course and to facilitate / conduct demonstration sessions / other
required facilities.
o The Course Co-Ordinator / Institute shall be responsible for evaluating ASUS
practitioners who have registered for the program. Evaluation should be based on
pre-defined norms and parameters in discussion with BoER, NCISM.
o After conduct of assessment BoER, NCISM / Course Co-Ordinator / allot credits
as per evaluation scheme announced.
o A separate online certificate shall be generated for each elective mentioning
credits, regarding successful completion of elective program certificate shall be
signed by President, BoER and Co-ordinating institute is issued online mode.
o Further after completion of program and getting certificate, 10 credit points will
be allocated to practitioner’s credit bank account. No any authority / institution /
organization shall refuse CME credit points for elective courses earned through
BoER, NCISM.
o Later he may go for another online elective program /if wants
8|P a ge

<!-- page 9 -->

o The Board of Ethics and Registration, NCISM shall constitute standing committee
to resolve any issues that may arise in the implementation of elective programs for
ASUS practitioners.
Course
ID

Disciplin
e

Elective
Course
Name

Course
CoOrdinator/Institute

Duration

Enrollmen
t
Start
Date

Enrollmen
t End Date

UG/
PG

Login

Tentative timelines – 1st March 2025 to 28th February 2026
Event
Start of Course
End Course
Open enrollment to course
Close enrollment to course

12 months (01year)
1st March 2025
28th February 2026
1st January 2025
28th February 2025

Prof. (Vaidya) Rakesh Sharma,
President, Board of Ethics and Registration,
NCISM, New Delhi

9|P a ge
