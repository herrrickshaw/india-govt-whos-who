---
doc_id: "f76dca4e81ff3b7d"
source_url: "https://finance.punjab.gov.in/uploads/21May2022\f6fd361b42fb94c24f07a0fea4608645.pdf"
ministry: "Finance Department, Punjab"
title: "Punjab Transparency in Public Procurement Rules, 2022"
date: ""
pages: 129
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a60bb20890fc6cf7"
---

<!-- page 1 -->

2

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

EXTRAORDINARY
Published by Authority
CHANDIGARH, FRIDAY, JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)
LEGISLATIVE SUPPLEMENT
Part - I
Part - II
Part - III

Part - IV

Contents
Acts
Nil
Ordinances
Nil
Delegated Legislation
Notification No. G.S.R. 02/P.A.12/2019/
S.60/ 2022, dated the 6th January, 2022,
containing the Punjab Transparency in
Public Procurement Rules, 2022.
Correction Slips, Republications and
Replacements
Nil
______

( iv )

Pages

.. 3-130

<!-- page 2 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

02

3

<!-- page 3 -->

4

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 4 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

5

<!-- page 5 -->

6

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 6 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

7

<!-- page 7 -->

8

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 8 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

9

<!-- page 9 -->

10

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 10 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

11

<!-- page 11 -->

12

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 12 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

13

<!-- page 13 -->

14

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 14 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

15

<!-- page 15 -->

16

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 16 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

17

<!-- page 17 -->

18

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 18 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

19

<!-- page 19 -->

20

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 20 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

21

<!-- page 21 -->

22

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 22 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

23

<!-- page 23 -->

24

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 24 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

25

<!-- page 25 -->

26

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 26 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

27

<!-- page 27 -->

28

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 28 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

29

<!-- page 29 -->

30

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 30 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

31

<!-- page 31 -->

32

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 32 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

33

<!-- page 33 -->

34

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 34 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

35

<!-- page 35 -->

36

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 36 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

37

(iv) Names of Bidders whose Bids were rejected and brief reasons
for their rejection
(v) Name of the winning Bidder, items contracted, the contract price
and delivery period.
11. Return of Bid Security. – (1) Bid Security of the bidders whose bid
is rejected in technical evaluation shall be returned upon the completion
of technical evaluation.
(2) Bid Security of all the remaining bidders except the L1 bidder/
successful bidder shall be returned upon the completion of financial
evaluation.
(3) Bid Security of the L1 bidder/successful bidder shall be returned
once the L1 bidder/successful bidder has signed the Contract and
furnished the required performance security or shall be adjusted against
the performance security or payment under contract, as the case may
be.

<!-- page 37 -->

38

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 38 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

39

<!-- page 39 -->

40

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 40 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

41

<!-- page 41 -->

42

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 42 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

43

<!-- page 43 -->

44

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 44 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

45

<!-- page 45 -->

46

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 46 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

47

<!-- page 47 -->

48

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 48 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

49

<!-- page 49 -->

50

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 50 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

51

<!-- page 51 -->

52

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 52 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

53

<!-- page 53 -->

54

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 54 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

55

<!-- page 55 -->

56

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 56 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

57

<!-- page 57 -->

58

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 58 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

59

<!-- page 59 -->

60

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 60 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

61

<!-- page 61 -->

62

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 62 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

63

<!-- page 63 -->

64

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 64 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

65

<!-- page 65 -->

66

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 66 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

67

<!-- page 67 -->

68

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 68 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

69

<!-- page 69 -->

70

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 70 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

71

<!-- page 71 -->

72

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 72 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

73

<!-- page 73 -->

74

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 74 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

75

<!-- page 75 -->

76

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 76 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

77

<!-- page 77 -->

78

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 78 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

79

<!-- page 79 -->

80

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

<!-- page 80 -->

PUNJAB GOVT. GAZ. (EXTRA), JANUARY 7, 2022
(PAUSA 17, 1943 SAKA)

81
