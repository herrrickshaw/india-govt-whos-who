---
doc_id: "bceba8a1ec3ccf0e"
source_url: "https://pspcl.in/Admin/Tenders/Ms_ECS_Industries26112025.pdf"
ministry: "Punjab State Power Corporation Limited (PSPCL), Punjab"
title: "M/s ECS Industries Private Limited, Vadodara declared as Defaulter Firm by PSPCL upto 02-03-2028"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a07a112dea6393db"
---

<!-- page 1 -->

i

n11

nZ014

PUNJAB STATE POWER CORPORATION

(Olo CE/TS,B-1,Shakti Vihar, Patiala)
Regd. Office: PSEB Head Ofice, The Mall Patiala-14700

Phone No. 0175-2301537,Fax No, 0175-2220143. Email : addlsecela2EAil.com

Corporate Identity Number U40109PB2010SGCO33813 :Website : yww.pspcl.inaV

To

CE/IT

PSPCL, Patiala

Memo No.o &5 DS-171/SS(D)-II
Subject:

Dated2 .11.25

Uploading the name of 'M/s ECS Industries Private Limited., Vadodara
as a Defaulter firm on the PSPCL Website.

With reference to subject cited above it is intimated that Purchase order No.
372 dt 03.03.25 was awarded to M/s ECS Industries Private Limited., (Formerly
known as
M/s Electrical Controls &Systems.) for Manufacture, Testing, Supply &delivery of
66KV
Potential Transformers against PSPCL Tender Specification No. 327/SS II(D).
Due to NIL' delivery of 66 kV PTs till the date of expiry of Contractual
Delivery Period, the firm was declared defaulter in line with PSPCL Purchase
Regulation
clause-10b-(x), vide this office memo no. 983 dt 09.10.25 (copy attached). Therefore, as
per the aforementioned clause, it is requested to upload the
name of the firm as defaulter
on website as per following details: 1.

Name of Firm

M/s ECS Industries Private Limited., (Formerly
known as M/s Electrical Controls & Systems.)

2.

Regd Office

Plot

No. 248/249A GIDC Industrial Estate,

Makarpura, Vadodara-390010, Gujarat
3

Works Address

Plot no. 1409 &1410, GIDC Industrial Estate

Waghodia, Vadodara-391760, Gujarat
4.

Item

defaulted
5

which Potential Transformer (all type, sizes and ratings)

Defaulter upto

DA: As Above

02.03.2028.

Diay io...n.
ASE/ CR4

Chief Engineer/I

M/SCADA

ASE/C %LH

Dairy No.

MICIS

Date..l)).A2S

Sunct!

PSPC!

PA

PATIAL

Dy. CE/T(A PM

Dy.CEISS(DesigD),
PSPCL, Patiala

<!-- page 2 -->

$ PUNJAB STATE POWER

CORPORATION LTD:

(Oo CE/S,B-1, Sbakti Vihar,Patiala)
Regd. Orlicc: PSEB Head oficc, The Mall Patiala-|47001,
T'hone No. D175-2301S37, Fax No. 0175-2220143, Email :
add/secell24gnail.com
Ote ldentity Number 40109PB201OSGCO33813:Website
www.pspcln
To

M/s ECS Industries Private
Limited.,
(Formerly kuown as M/s Electrical Controls &Systems.)
Plot No. 1409 & 1410. (GJLD,C, Industrial
Estate,

Waghodia, Vadodara-391760, Gujarat

Memo No.:483

/DS-171/SS(D)-II

Dalcde4.10.25

Subject: Purchase Order No. 372/Spec.327/SS(D)-II/DS-171 dt. 03.03.25
for the
supply of 49 nos. 66kV PTs
Dear Sirs,

This is with reference to this office Purchase Order No. 372/Spec.327/SS(D)
|WDS-17ldt. 03.03.25 for the supply of 49 nos, 66kV PTs. In this regard, it is intimated
that as per the Contractual Delivery Period (CDP) of the subject-cited PO. you were

required to supply the full ordered quantity up to 03.07.25. However, 'NIL' quantity of
66kV PTs (i.e., 0% of total ordered quantity) had been supplied to PSPCL, tillthe expiry
of the CDP.

The Sr. No. 13(b) of NIT Notes of Tender Enquiry No. 327/SS(D)-!l, which is
part of the subject-cited Purchase Order states as under -

"Any firm which at the time of opening of the Tender enquiry, falls in any of the

following categories, shallbe regarded as defaulter and shall not be eligible for
participation inany new Tender enquiry for a period of three years from the date
of issue of Purchase Order in which it has defaulted:
i) The Firm is adefuulter for the supply of 35% or more quantity on the dute of
expiry of the Contructual Delivery Period for the total ordered quantitv.
ii) The Firm is a defuulter for the supply of any quantity for more than 6 months

from the dute of expiry of the Contractual Delivery Period for the totul ordered
quantity.

Since upto overall expiry of CDP (03.07.25). NIL quantity of 66kV PTs have
been supplied against ordered quantity of 49 nos. 66kV PTs, as such you have defaulted for
Supply of 35% or more quantity on the date of expiry of the Contractual Delivery Period
for the total ordered quantity. Hence your firm shall be regarded as defaulter and shall

<!-- page 3 -->

no be eligible for participation in any new 'T'ender Enquiry of PSPCL
for the ordered
em (all types, sizcs and ratings) for a period of threc yers from the date
of issue of
the
subjcct-cited Purchase (Order i.c., up (o 02.03.2028.

This is lor your intornation, plese.
Dy.CESS(Design)
PSPCL, Patiala

CC:

Chiet Engincer/l'S, PSPCL. Patiala
(i) Chief Engincer/ Distribution
Projccts, PSPCL, Patiala
(i) Chief Engincer/MM,
PSPCL,
(iv) Chief Engineer/Hvdel Projects,Patiala
(V) Chief Engineer/T hernal Design,PSPCL, Patiala
(vi) Chief Engincer/GHTP, PSPCL, PSPCL, Patiala
Lehra Mohabbat
(vii) Chief

Engineer/GGSSTP,

Roopnagar
(Vim) Addl.SE/Works to CErTS,PSPCL,
PSPCL. Patiala for
action please.

information and further necessary
