---
doc_id: "17e4e0fa6b41cfbe"
source_url: "http://www.ihmbti.com/wp-content/uploads/2026/08/Corrigendum-for-Auction-for-CBT-centre-and-Verka-Milk-Booth.pdf"
ministry: "Institute of Hotel Management Catering Technology and Applied Nutrition, Bathinda, Punjab"
title: "Corrigendum for Auction for CBT Centre and Verka Milk Booth"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bdbde12b4e809d06"
---

<!-- page 1 -->

Letter No. IHM/BTI/2026/
Date: 20.08.2026

CORRIGENDUM
Sealed quotations were invited for Auction for CBT Centre and
Verka Milk Booth/Tuck Shop last date upto 20.08.2026. Due to less
response the last date for receipt of sealed quotations is hereby
extended upto 03.09.2026 (2.00 p.m.).

SD/Principal
IHM Bathinda

<!-- page 2 -->

Letter No. IHM/BTI/2025/
Date: 28.08.2025

CORRIGENDUM
Sealed quotations were invited for refilling of fire extinguishers
having last date upto 20.08.2025. Due to less response the last date for
receipt of sealed quotations is hereby extended upto 04.09.2025 (2.00
p.m.).

SD/Principal
IHM Bathinda

<!-- page 3 -->

Letter No. IHM/BTI/2025/1224
Date: 12.08.2025

CORRIGENDUM
Sealed quotations were invited for repair and renovation of
Electrical Appliances having last date upto 30.07.2025. Due to less
response the last date for receipt of sealed quotations is hereby
extended upto 20.08.2025 (2.00 p.m.).

SD/Principal
IHM Bathinda
