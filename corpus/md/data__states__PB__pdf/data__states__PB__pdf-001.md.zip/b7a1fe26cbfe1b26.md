---
doc_id: "b7a1fe26cbfe1b26"
source_url: "https://punjabcooperation.punjab.gov.in/sites/default/files/documents/Debi_Relief_Non_Agri_Policy_15032019.pdf"
ministry: "Co-operative Department, Punjab"
title: "Debit Relief Policy for Farm Labourers and Landless Farming Members March 2019"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1896a71666212059"
---

<!-- page 1 -->

Government of Punjab
Department of Cooperation
(Cooperation 1 Branch)

NOTIFICATION
No.29/59/2017-C-1 (4)/1436469

The March6, 2019

1. Introduction

The District Central Cooperati
ve Banks in the state of Pun
jab are providing
Consumption Loans to the far
m labourers and landless farmin
g membersofthe Primary
Agricultu

ral Cooperative Societies (PACS)

through PACS as per the direct

ions issued by
ies, Punjab. These loans are
to be repaid by the
borrowing members of PACS on
half yearly basis at Rabi and Kha
rif crops. However, over the years these loans have
not been repaid by them as they
are in severe debt trap
and povert
the Registrar Cooperative Societ

y.Government of Punjab has
provided debt relief to margin
al and small

farmers. Government of Punjab

farming members are no: covere

has decided that these farm lab

d under any Debt Relief Scheme

may also be given debt relief.

ourers and landless

of the Government,

In order to provide relief, the Gov
for Farm Labourers and Landless
Consumption Loan to these mem

t. of Punjab has formulated a Deb

tRelief Scheme

Farming Membersof PACS-2019whi

bers of the Primary Agricultural

advancedby District Central Cooper

ch will cover only

Cooperative Societies

ative Banks in the state of Punjab

Agricultural Cooperative Societ

ies.

through Primary

2. Scope of the Scheme

1. This scheme will cover consum
pti
Landless Farming liembers of the
the State by District Central Cooper

on loans disbursed to Farm Lab

ourers and

Primary Agricultural Cooperative

Societies in

ative Banks through PACS.

2. The Scheme will come in to for
ce fro

m the date of notification,

3. Definitions

1. Consumption Loanmeans a
sho

rt term loan advanced by the DCC
Bs through
PACS to the members of PACS fo
r consumption purposas as per
loan scheme

approved by RCS.

|

2. District Central Cooperative Ban
ks
Whoare carrying

(DCCBs) means central cooperative

on banking business and are regi
stered

Cooperative Societies Act 1961.

3. PACS means Primary Agricultural
Coo
Cooperative Societies Act 1961.

under Punjab

perative Societies registered under Pun

jab

4. Social Audit means scrutiny of genuin
ene
the general public.

banks

ss of beneficiaries under the schemeby

<!-- page 2 -->

4. Eligible Beneficiaries :

This scheme will cover consumption loans disbursed to Farm Labourers and
Landless Farming Membersof the Primary Agricultural Cooperative Societies in the
State by District Central Cooperative Banks through PACS. However, the relief
shall not be available to the member who is an employee/pensioner of
Government/Semi Government/Public Sector Undertaking of any State/Centre
Government and also to the member who is an income tax payee.|f an individual
has more than one account, the relief will be given for one account onlywhich has
higher outstanding amount subject to the maximum of Rs.25000/- asprincipal. The
accounts of the beneficiaries will be Aadhar seeded to avoid duplication.Any
member who hasobtained relief under any other debt relief scheme of the Govt.

“will not be eligible under this Scheme.

5. Eligible Amount:

Under the Debt Relief Scheme for Farm Labourers and Landless Farming

Members of PACS-2019, the amounteligible for debt relief shall comprise of
theprinciple amountunder consumption loans as on 31.03.2017 plus simple

interest @ 7% p.a. on the above outstanding amount, calculated upto the date of
notification of the Scheme.While calculating the interest, no penal interest shall be
charged by PACS to its members.
6. Implementation:

i.

Registrar Cooperative: Societies, Punjab, Chandigarh will issue the instructions
under Rule 45 of Punjab State Cooperative Societies Rules 1963 giving details for
implementation of the scheme at each level.

ii.

All the District Central Cooperative Banks (DCCBs)and their affiliated PACS shall
‘adoptthe notification in their institution/societies through a resolution passed by
their BOD/Managing Committee/Competent Authority.

ii.

Every PACS shali preparePACS wise separatelist of eligible members inthe
prescribed performa as per Annexure-A. These lists shall be approved by the
Managing Committee of the PACS by passing the resolution.

iv.

The PACS will obtain a Self Declaration Form as per Annexure-B from each
beneficiary /Legal Heirs or Guarantor (in death cases).

v.

The claim prepared by PACS as above shall be checked by the concerned

Inspector Cooperative Societies and Assistant Registrar Cooperative Societies as
per terms and conditions contained in the notification and shall be pre audited by

the department auditor.
vi.
lex

:

The Head Office of the concerned DCCB shall consolidate the claims received
from all the PACS through ARs Coop. Societies andsend the consolidated claim to

Head Office of Punjab State Cooperative Bank Ltd, Chandigarh.

<!-- page 3 -->

vii.

The PSCB will conipile the claim sent by all the DCCBs and sendthe same
to State Government through Office of RCS, Punjab for approval.

/

viii.

The amountof debt relief received from Government of Punjab will be sent

to the respective DCCBs by the Punjab State Cooperative Bank Ltd,
Chandigarh for onward transfer to the claimant Cooperative Society.
ix.

The accounting procedure to be adopted by DCCBs and concerned PACS is
appended as Annexure-C. All the DCCBs/PACS shall ensure to adopt the said
accounting procedurein their books of accounts.

ng

In case of death of the eligible member, his/her legal heirs, guarantor can apply
for debt relief along with the duly certified copy of Death Certificate issued by
appropriate authority.

xi

The beneficiary. availing the debtrelief shall be eligible to avail the fresh loan from
the PACS/DCCB after his/her outstanding amount|is repaid by proceeds from this
scheme.

xii.

PACS shall issue certificate of Waiver/Relief to the eligible beneficiaries after the
Waiver/Relief is made. A Specimen ofthis certificate is enclosed as per Annexure-

D.

a

xiii. -. The concerned DRCS shall be the Grievance Redressal Officer in the District. The

name and address .of the Grievance Redressal Officer of the PACS shall be
‘displayed in the notice board in each branch of DCCB/PACS.
xiv.

The Deputy Commissioner of concerned District shall supervise the Debt Relief

Scheme for Landless Labourers/Members of PACS-2019 in the District.

te Audit:

The books of account of everyPACSthat has granted debt waiver or debtrelief
under this scheme(including the books of accounts maintained at the branches) shall be
subject to an audit by the Chief Auditor Cooperative Societies in accordance with the laid
down procedures. In addition the slate Government may get any other special audit done
through any other source.
8. Monitoring:

There shall be constituted a State Level Committee consisting of the following to
; monitor and give clarifications, if any, for smooth implementation of the scheme:
ds
2
3
My

Additional Chief Secretary (Cooperation)-cum-FCC (Chairman).
Additional Chief Secretary (Development)/Secretary Agriculture.
Principal Secretary, Department of Finance or his representative not below
the rank of Joint Secretary.

4. ~ Registrar, Cooperative Societies, Punjab.
2.
Managing Director, Punjab State Cooperative Bank Ltd.
9. Social Audit:

For conducting social audit, the PACS shall display the list of eligible beneficiaries

at premises of PACS and concerned branch of DCCBs. Social Audit will be coordinated

<!-- page 4 -->

by a team consisting of concer
Manager of the DCGB: After

ned ARCS, Inspector, Coop Soc
ieties and Branch

conduct of social audit and fin

alization ofall objections
pared as per Annexure-A and
will be displayed at the
notice board of concerned bank
branch of DCCBs and PACS.
received, the final list will be pre

10.

Interpretation and power to

remove difficulties:

The Registrar, Cooperative Soc

ieties, Punjab shall resolve the

of interpretation of the Provis

ions of the Scheme, .in consul

Finance.

tation with the Department

- The Cooperative. Departmen
t will

Chandigarh, Dated:
6.3.2019

VISWAJEET KHANNA
Additional Chief Secretary
-CumFinancial Commissioner (Co
operation)

a

Tre tr OMNO

OAwWNh a

Endst No.29/59/2017*C-1 (4)/14
36469/1
A copy is forwarded to the follow
ing for
Principal Secretary to the Chief

ncipal Secretary, Finance, Pun

Secretary, Agriculture Punjab
Secretary, Mandi Board, Punjab

jab

“Regional Director, Reserve Ban

k of India, Cha

ndigarh.
Registrar Cooperative Societies,
Punjab.
Managing Director, Punjab State
Cooperative Bank Ltd, Chandigar
h.
Convener Stats Level Bankers Com
mittee, PNB, Chandigarh.
Director, Department of Institutiona
l Finance and Banking.
P.S/Cooperation & jails Minister
Punjab.
P.S/Additional Chief Secretary Coo
peration Punjab.
Tata Consultancy Services (T.C.S.),
Punjab Civil Secretariate.

Fea.

9/2

information and necessaryaction.

:

f Punjab.

Minister, Punjab.

Additional Chief Secretary Cooper
ation, Punjab.
Financial Commissioner, Revenu
e, Puniab.
Pri

A copy is forwardedto All Deputy

_

Chandigarh, Dated 06.3.2019
information and necessary action
:-

Chief Secretary to Governmento

Endst. No.29/59/2017*C-1(4)/143646

Endst. No.29/59/2017*C-1 (41/1436469/3

of

be the Nodal Department
to implement the

scheme in all respects.

5

doubts arising out

Joint Secretary Cooperati

Chandigarh, Dated 06.3.2019

Commissionersin the State of Pun

jab for

Joint Secretary eReen
<3 ¢

Chandigarh, Dated 06.3/2019

A copy, with a spare copy, is forwarded
to Controller, Printing & Stationary,
Punjab, Chandigarh, with the request
that the notification may bepublished
in the official
- Gazette of Punjab Government and
supply 50 copies of the printed notifica
tion to this
department.
ee
ee<3 « oat? z

Joint Secretary Cooperation :

<!-- page 5 -->

©

Sr No

1

Name of DCCB

2

4

4

Tehsil

5

5

Village

Name

a

of

Bank

Branch

6

7

Nameof
a
Society

8

Society Code
i
(in Bank CBS)

9

Name of the
oa
beneficiary

A

No.

B
Husband

(Shadow)

ank : Ic
Name

11

Father

10

12

PACS
account no.

13

Date of
advancement

14

t

31.03.2017

as on

outstanding

See

Principle

(Annexure-A)

I

iS

notification

nterest Ge
p.a. as per
line
sara

9

LIST OF FARM LABOURERS AND LAND LESS FARMING MEMBERS WHO HAVEOBTAINED SHORT TERM NON AGRICULTURAL (STNA) LOANS FROM PACS (ADVANCED BY COOPERATIVE BANKS)

‘

Distt

3

16

Total amount
(14+15)

17

Aadhar
Number

<!-- page 6 -->

Annexure-B

He-ulnet use
SHelot:

ofst

owteT

df

OR UesS/USOl

Al. ccs Sat

Ree Bids 6 GWU er Hag
a eeeALS HAA. des feu Olen UE Adad ot BSt HAST ws
aAHIS OHSAS Hust Ut aH TTS Aa - 2019 wet Jo fee mons AP

WHat adev/aget gt:-

1.

fea fr AS ae fe ARis/Ro/en fee BStest mis act 31

2.

fed fa H far et Aeordtreu Heodivustee Aaes visehha fey

sodt adt asevaget wis o dt fest faa fee Sons wee Ti
2,

feu fa Homies ag et stadt ai

4,

feo fea wos Una nears eS ast oa gOS Hoh unis AG Gast
(seat |

2

os UUs odt ‘atst FI

6.

(eet Aer oe 3 m3 F Cudas Ath a
Tw!

Weta
Sree:

: greta ots niet d fa AS eS A Sas Ae URS St ret 9, Os

fama Adt & PAS FI fen feu ae Se aes At go adt 31
fist

4S

WHeTaTg

<!-- page 7 -->

- ANNEXURE ‘C’
Accounting Procecure of STNA DebtRelief:

PSCB, HO:
_ Loan Waiver office account of PSCB

:

Dr.

Office A/c of DCCB for STNA DebtRelief

Cr.

DCCB Head Office Level:
Office A/c of DCCB for STNA DebtRelief
- With PSCB

Dr

Office A/c Branch of DCCB

Cr

DCCB Branch Office Level:

Office A/c Branchfor STNA Debt Relief

Dr

Loan waiver account of PACS at Branch*

Cr

Loan waiver account of PACS at Branch

Dr

Loan account of Member/PACS#

Cr

PACS Level:

Loan account of Branch in the books of PACS

Dr

Loan waiver account in the books of PACS

Cr

Loan waiver account in the books of PACS

Dr

‘Loan account of member in the books of PACS-

Cr

_ Note:

_ »

:

Separate loan waiver account at DCCB HO and at branch level will be
Opened.

*.-- At branch level, loan waiver account of each PACSwill be opened.
#--- Account of STNA member of PACS & loan accounts of PACS will be
simultaneously credited.

<!-- page 8 -->

t

2
4

a
ee2 ADas3'

gtdtnruert fen go |

,

ly aemeeimeeene Lehre

S'ds © HU! lene

pepsin sg
0 ai

oe

o.

“Laregezsiy*

;

aMnulce Fay cooe¥ Cooperative Bank

Gudas gerfest 3 nivis sHeta atsater d fa do fod Hag ct first 31 .3 .2017 Fa

Sugas AS 3 Ad ava feu dai feut gau ot Tes fest At:

VHppe/oto SG oe ee Psat OY OMe ected:
