---
doc_id: "8fcac70ca85e2ada"
source_url: "https://cdn.s3waas.gov.in/s3274ad4786c3abca69fa097b85867d9a4/uploads/2021/05/2021050337.pdf"
ministry: "Kapurthala"
title: "PDF       Order Regarding Covid-19 Restrictions by DC Kapurthala on dated 2-05-2021   Download Document     Opens downloadable PDF document"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9e95572c7b5977de"
---

<!-- page 1 -->

ਦਫ਼ਤਰ ਡਿਪਟੀ ਕਡਿਸ਼ਨਰ – ਕਿ - ਡ਼ਿਲ੍ਹਾ ਿੈਡਿਸਟਰੇਟ, ਕਪੂਰਥਲ੍ਾ
OFFICE OF THE DEPUTY COMMISSIONER – CUM DISTRICT MAGISTRATE, KAPURTHALA

ORDER:
This is in continuation of the Order of the undersigned, which was issued vide this office
Endst. No. 2836-2889/MA dated 01.05.2021.
In continuation of its letter bearing Memo No. 7/56/2020/2H4/2142 dated 30th April,
2021, vide which consolidated guidelines were issued in relation to the restrictions to be enforced
throughout the State of Punjab with effect from 1st May, 2021 till 15th May, 2021, the
Department of Home Affairs & Justice (Home-4 Branch), Government of Punjab, vide its letter
bearing Memo No. 7/56/2020/2H4/2143 dated 2nd May, 2021, has directed strict and meticulous
enforcement of additional restrictions, in addition to the restrictions imposed vide its abovereferred to letter dated 30th April, 2021, with effect from 2nd May, 2021 till 15th May, 2021.
Therefore, in pursuance of the above-said directions of the Government of Punjab issued
vide its above-mentioned letter dated 2nd May, 2021, and taking into account the prevailing
COVID-19 situation in District Kapurthala, I, Deepti Uppal, IAS, District Magistrate,
Kapurthala, by virtue of the powers vested in me under Section 144 of the Code of Criminal
Procedure (Cr. PC), 1973; Section 30 of Disaster Management Act, 2005, and Section 2 of
Epidemic Diseases Act, 1897, hereby, order the following additional restrictions for strict &
meticulous enforcement within the territorial jurisdiction of District Kapurthala with effect from
2nd May, 2021 till 15th May, 2021:
(i).

All Shops selling non-essential items to remain closed.
Essential Items include Chemist Shops and Shops dealing with supply of Essential
Goods, Milk, Bread, Vegetables, Fruits, Dairy and Poultry Products like Eggs, Meat,
Mobile Repair, etc.
No restriction on Laboratories, Nursing Homes, and other Medical Establishments.

(ii).

Nobody to enter the territorial limits of District Kapurthala, whether by Air, Rail or Road
without either:
(a).
Negative COVID Report not more than 72 Hours old, or;
(b).
Vaccination Certificate (at least one dose) over two (02) weeks old.

(iii).

All Government Offices as well as Banks will work at 50% strength other than those
where officials are involved in COVID-19 management. This office i.e. the office of
Deputy Commissioner, Kapurthala, can draft services of any Official for COVID-19
management and related duties.

(iv).

All Four (04)-Wheeler Passenger Vehicles, including Cars and Taxis, not allowed to seat
more than Two (02) Passengers. Vehicles carrying Patients to Hospitals are exempted. No
Pillion Riders on Scooters and Motorcycles except those belonging to the same family
and living in the same house.

(v).

No gathering of more than Ten (10) persons to be allowed, including for Weddings /
Cremations / Funerals.

(vi).

Villages will organize Thikri Pehras to ensure that “Night Curfew” and “Weekend
Curfew” Orders are complied with.

(vii).

Social Distancing to be maintained in Subzi Mandis, which would be open only to Fruit &
Vegetable Wholesalers.

Page 1 of 3

<!-- page 2 -->

(viii). Appeals to Kisan Unions and Religious leaders not to hold gatherings and restrict the
number of protesters to token presence at Toll Plazas, Petrol Pumps, Malls, etc.
(ix).

Religious Places to be closed at 6:00PM daily. No overcrowding at Gurdwaras, Mandirs,
Masjids, Churches, etc.

(x).

Strict Action will be taken against those hoarding Oxygen Cylinders by the District
Administration.

(xi).

RT-PCR Testing of Road and Street Vendors, such as Rehriwallas, etc. to be carried out
intensively.

(xii).

Daily Night Curfew from 6:00PM to 5:00AM, and Weekend Curfew from 6:00PM on
Friday up to 5:00AM on Monday throughout the District. No vehicle to ply except for
medical purposes, with Curfew Pass, which shall be issued by the respective SubDivisional Magistrates (SDMs).

(xiii). Number in Public Transport (Buses, Taxis, Autos) to be restricted to 50% of the capacity.
Transport and Civil Officials, along with Police Personnel, to constitute Flying Squads to
enforce.
(xiv). All Bars, Cinema Halls, Gyms, Spas, Swimming Pools, Coaching Centres, Sports
Complexes to remain closed.
(xv).

All Restaurants (including in Hotels), Cafes, Coffee Shops, Fast-Food Outlets, Dhabas,
etc. to remain closed for Dine-In and may function only for Take-Away. Home Delivery
allowed till 9:00PM. No seating inside Restaurants, Fast-Food Joints, Coffee Shops, etc.
to be allowed.

(xvi). All Weekly Markets (such as Apni Mandis) to be closed.
(xvii). There shall be a Complete Ban on all Social, Cultural or Sports gatherings and related
functions (including Government functions, such as Inaugurations, Foundation Stone
Laying Ceremonies, etc. prior permission has been obtained from DC Office).
(xviii). There shall be a Complete Ban across the District on all Political Gatherings. For any
gathering organized in violation of this Order, FIRs will be registered against the
Organizers and Participants, as well as against the Owners of the Venue and the Tent
Houses under the Disaster Management Act, 2005 and the Epidemic Diseases Act, 1897.
Such Venues shall also be sealed for the next Three (03) Months.
(xix). Persons who have attended large gatherings anywhere (Religious / Political / Social) to be
mandatorily Home Quarantined for Five (05) Days and Tested as per Protocol.
(xx).

All Educational Institutions i.e. Schools and Colleges to remain Closed, but the Teaching
and Non-Teaching Staff of Government Schools to attend duty.

(xxi). All the Medical and Nursing Colleges may continue to remain Open.
(xxii). All Recruitment Exams to be Postponed, unless it relates to the Recruitment of COVID19 Management-related Manpower.
(xxiii). All Private Offices, including Service Industry, such as offices of Architects, Chartered
Accountants (CAs), Insurance Companies, etc. allowed to “Work from Home” only.
(xxiv). In Government Offices – Health / Frontline Workers & Employees over forty-five (45)
years of age, who have not got at least One (01) Vaccine Dose in the last Fifteen (15)
Days or more, should be encouraged to take leave and stay home until then. Employees
under forty-five (45) years of age to be allowed only on the basis of Negative RT-PCR
not more than Five (05) Days old or else should take leave and stay home.
Page 2 of 3

<!-- page 3 -->

(xxv). Micro-Containment Zones in High Positivity Areas to be increased and strictly enforced.
Special Monitors to be designated for enforcement.
(xxvi). Grievance Redressal by all the Government Offices shall be preferred through Virtual /
Online Modes. Public dealings should be discouraged as far as possible, and allowed only
where deemed unavoidable. Revenue Department shall also endeavour to limit
appointments to public to bare minimum for execution of Conveyance Deeds for Sale &
Purchase of Properties.
All the extant directives of the Ministry of Home Affairs (MHA), Government of India;
Government of Punjab & District Administration, Kapurthala on COVID-appropriate behaviour
including Social Distancing norm of maintaining minimum six (06) feet distance (Do Gaz Ki
Doori), regulating crowds in marketplaces and public transport, and imposition of penalties
prescribed for violation of COVID-appropriate behaviour like wearing of face masks, spitting in
public places, etc. shall be strictly enforced.
This Order shall be applicable with effect from 2nd May, 2021 till 15th May, 2021.
Any violation of this Order shall be punishable under Sections 51 to 60 of Disaster
Management Act, 2005, besides legal action under Section 188 of Indian Penal Code (IPC),
1860.

Place: Kapurthala
Dated: 02.05.2021
Endst. No.

-Sd/(Deepti Uppal, IAS),
District Magistrate,
Kapurthala

2901 – 2954 / MA, Dated: 02.05.2021

A copy of the above is forwarded to the following for kind information:
1. Chief Secretary to Govt. Punjab, Chandigarh
2. Principal Secretary to Hon’ble CM, Punjab, Chandigarh
3. Commissioner, Jalandhar Division, Jalandhar
4. All the District Magistrates in the State of Punjab
5. Senior Superintendent of Police (SSP), Kapurthala
6. ADC (General), Kapurthala/Phagwara
7. ADC (Development) / DDPO, Kapurthala/ All the BDPOs in the District – To ensure that the
Thikri Pehras are organized in the Villages with immediate effect so that the “Night Curfew”
and “Weekend Curfew” Orders are complied with.
8. Commissioner, Municipal Corporation, Kapurthala/Phagwara
9. All SDMs in District Kapurthala – with further directions to issue Permissions for Marriage
Functions (as per Authorization issued vide Endst. No. 2490–2504/ MA dated 20.04.2021)
subject to compliance of the conditions notified in this Order, issue Curfew Passes and to
also ensure designation and deployment of Special Monitors for strict enforcement of these
restrictions in the High-Positivity Areas that are notified as Micro-Containment Zones.
10. Civil Surgeon, Kapurthala/Asst. Commissioner (Food Safety), Kapurthala
11. Asst. Excise & Taxation Commissioner (AETC), Kapurthala
12. Chief Agriculture Officer, Kapurthala
13. Dy. Director (Horticulture)/(Animal Husbandry)/(Fisheries), Kapurthala
14. District Food & Supplies Controller (DFSC) /District Mandi Officer (DMO), Kapurthala
15. GM, District Industries Centre (GM, DIC) / Asst. Labour Commissioner (ALC), Kapurthala
16. General Manager (GM), Pepsu Road Transport Corporation (PRTC), Kapurthala
17. District Mandi Officer (DMO), Kapurthala 18. District Education Officer (E)/(S), Kapurthala
19. District Welfare Officer (DWO) / District Social Security Officer (DSSO), Kapurthala
20. District Program Officer (DPO), Kapurthala
21. District Sports Officer (DSO), Kapurthala
22. PA to DM/ Steno to ADM/Steno to ADM/ Steno to AC (G)/ DRO, Kapurthala.

For District Magistrate,
Kapurthala
Page 3 of 3
