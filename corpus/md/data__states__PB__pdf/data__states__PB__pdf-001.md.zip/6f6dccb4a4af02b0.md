---
doc_id: "6f6dccb4a4af02b0"
source_url: "https://sha.punjab.gov.in/shapunjab/documents/genderspecificTender.pdf"
ministry: "Health and Family Welfare Department, Punjab"
title: "Download PDF"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "62c8366ed7e35261"
---

<!-- page 1 -->

RFP for selection of Insurance Company for the Implementation of MMSY in Punjab

Schedule 3(a.a): List of Sex Re-assignment Surgery (SRS)
The Government of India has launched AB-PMJAY- SMILE (Transgender Swasthya Suraksha)
scheme to extend comprehensive health care benefits to transgender. The Scheme covers treatment
based on MMSY health benefit package along with additional 50 specific packages related to Sex
Re-assignment Surgery (SRS). All transgender persons holding a certificate issued by the National
Portal for Transgender Persons shall be eligible to get benefits under this Scheme.

Sr.
No.

Specialty

AB PM - JAY
Procedure
Name

Package
rate

LOS

Gender
Affirmation
Surgery

Mammoplasty

87,000

5 Days

Gender
Affirmation
Surgery

Mastectomy

58,000

5 Days

Gender
Affirmation
Surgery

Orchiectomy

36,250

1 Day

1

2

3

Gender
Affirmation
Surgery

4

Gender
Affirmation
Surgery
5
Gender
Affirmation
Surgery
6

Modified
Penile
inversion
vaginoplastyalso includes
labiaplasty,
clitoroplasty,
penectomy,
Orchiectomy,
vestibuloplasty
and feminizing
urethroplasty.
Metaidoioplast
y and similar
procedures
with urethral
lengthening
and
scrotoplasty
Radial artery
forearm flap &
free flap
phalloplasty

1,45,000

1,08,750

2,53,750

Mandatory
Documents - Pre
Authorisation
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE

Mandatory
Documents - Claim
Processing
Detailed surgical
notes, detailed
Discharge summary

Detailed surgical
notes, detailed
Discharge summary

Detailed surgical
notes, detailed
Discharge summary

5 Days

Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE

Detailed surgical
notes, detailed
Discharge summary

3 Days

Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE

Detailed surgical
notes, detailed
Discharge summary

7 Days

Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE

Detailed surgical
notes, detailed
Discharge summary

Mukhya Mantri Sehat Yojana, State Health Agency, Department of Health and Family Welfare, Punjab
Page | 133

<!-- page 2 -->

RFP for selection of Insurance Company for the Implementation of MMSY in Punjab

Gender
Affirmation
Surgery

Anterolateral
thigh (ALT) &
similar
procedure

2,17,500

5 days

Gender
Reassignment

Implantation of
erectile

1,08,750

2 days

Gender
Reassignment

testicular
prostheses

72,500

2 days

7

8

9

Gender
Affirmation
Surgery
10

Gender
Reassignment

11

Open/LapHysterectomy,
salpingooophorectomy
and
vaginectomy
(Female to
male)
Hysterectomy+
Oophorectomy
+
vaginectomy+
perineal
closure+
Urethroplasty+
clitoral
transposition

1,08,750

2,53,750

Detailed surgical
notes, detailed
Discharge summary

Detailed surgical
notes, detailed
Discharge summary

Detailed surgical
notes, detailed
Discharge summary

5 Days

Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE

Detailed surgical
notes, detailed
Discharge summary

3 days

Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE

Detailed surgical
notes, detailed
Discharge summary

Gender
Reassignment

For male to
female patient

36,250

Day care
procedure

Gender
Reassignment

For female to
male patient

36,250

Day care
procedure

Gender
Reassignment

For female to
male patient

10,875

Day care
procedure

Gender
Reassignment

For male to
female patient

10,875

Day care
procedure

12

13

14

15

Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE

Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Mukhya Mantri Sehat Yojana, State Health Agency, Department of Health and Family Welfare, Punjab
Page | 134

<!-- page 3 -->

RFP for selection of Insurance Company for the Implementation of MMSY in Punjab

Gender
Reassignment

Male to female
only facial hair
removal per
year

3625/sett
ing

Day care
procedure

Gender
Reassignment

Forehead
feminization

1,74,000

3 days

Gender
Reassignment

Feminizing
Rhinoplasty

1,45,000

2 days

Gender
Reassignment

Cheek
feminization

1,81,250

2 days

Gender
Reassignment

Lip lift

36,250

Day care
procedure

Gender
Reassignment

Chin
feminization

1,45,000

2 days

Gender
Reassignment

Voice
Feminization
Surgery +
Adam's apple

1,45,000

Day care
procedure

Gender
Reassignment

lipofilling of
breast (upto 5
sitting)

91250/si
tting

2 days

Gender
Reassignment

lipofilling of
Large areas
(upto 3 sitting)

145000/s
itting

2 days

16

17

18

19

20

21

22

23

24

certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Mukhya Mantri Sehat Yojana, State Health Agency, Department of Health and Family Welfare, Punjab
Page | 135

<!-- page 4 -->

RFP for selection of Insurance Company for the Implementation of MMSY in Punjab

Gender
Reassignment

lipofilling of (
Small Areas)
(upto 3 sitting)

36250/si
tting

Day care
procedure

Gender
Reassignment

Chest
reconstruction

1,81,250

3 days

Gender
Reassignment

Facial bone
reduction

90,625

3 days

Gender
Reassignment

pectoral
implants

1,08,750

2 days

Gender
Reassignment

Voice Surgery
to obtain
deeper voice

1,08,750

Day care
procedure

Gender
Reassignment

liposuction
(Small area)

43,500

Day care
procedure

Gender
Reassignment

liposuction
(Medium area)

90,625

Day care
procedure

Gender
Reassignment

liposuction
(Large area)

1,45,000

2 days

Gender
Reassignment

Abdominoplast
y

2,17,500

3 days

Gender
Reassignment

vaginal dilation

50,750

Day care
procedure

25

26

27

28

29

30

31

32

33

34

Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary
Detailed medical
notes, detailed
Discharge summary

Mukhya Mantri Sehat Yojana, State Health Agency, Department of Health and Family Welfare, Punjab
Page | 136

<!-- page 5 -->

RFP for selection of Insurance Company for the Implementation of MMSY in Punjab

transgender
certificate issued by
MoSJE

Gender
Reassignment

Nipple grafts/
Tattooing

21,750

Day care
procedure

Gender
Reassignment

Thyroid
cartilage
reduction

72,500

Day care
procedure

Gender
Reassignment

Face-lift

1,81,250

3 days

Gender
Reassignment

Blepharoplasty
(rejuvenation
of the eyelid)

1,08,750

Day care
procedure

Gender
Reassignment

Double incision
breast
reduction

1,55,875

2 days

Gender
Reassignment

V line soft
tissue jaw
angle(massseter
reduction),
underchin lipo,
Buccal fat pad
removal

35

36

37

38

39

40

1,30,500

2 days

Gender
Reassignment

V line surgery
(bone
contouring)

1,45,000

2 days

Gender
Reassignment

Vulva
correction

72,500

Day care
procedure

Gender
Reassignment

Vaginal
Stenosis
correction
Yes (VAC
Mould) 20000

41

42

43

1,08,750

2 days

Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Mukhya Mantri Sehat Yojana, State Health Agency, Department of Health and Family Welfare, Punjab
Page | 137

<!-- page 6 -->

RFP for selection of Insurance Company for the Implementation of MMSY in Punjab

Gender
Reassignment

urethral
stenosis

36,250

2 days

Gender
Reassignment

urethral
stenosis

36,250

2 days

Gender
Reassignment

Sigmoido
Vaginoplasty

3,26,250

7 days

Gender
Reassignment

Peritoneal
Vaginoplasty

2,90,000

5 days

Gender
Reassignment

Hair Transplant
(Small)

54,375

day care
procedure

Gender
Reassignment

Hair Transplant
(Medium)

90,625

day care
procedure

Gender
Reassignment

Hair Transplant
(Large)

1,45,000

day care
procedure

44

45

46

47

48

49

50

certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE
Clinical Notes,
Consent copy, NOC
from patient,
transgender
certificate issued by
MoSJE

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Detailed medical
notes, detailed
Discharge summary

Note:
 Please refer https://sha.punjab.gov.in website for procedure-wise details.
 All Guidelines issued from time to time by the NHA/SHA shall be applicable.

Mukhya Mantri Sehat Yojana, State Health Agency, Department of Health and Family Welfare, Punjab
Page | 138
