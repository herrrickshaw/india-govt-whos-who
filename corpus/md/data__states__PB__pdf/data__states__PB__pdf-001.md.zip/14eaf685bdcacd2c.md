---
doc_id: "14eaf685bdcacd2c"
source_url: "https://nri.punjab.gov.in/media/documents/E-Sanad_Public_Instruction_2N4i9qq.pdf"
ministry: "NRI Affairs Department, Punjab"
title: "Click Here"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ef0b3ae391a5060a"
---

<!-- page 1 -->

Attestation/Countersigned of Documents through online mode:E-Sanad- The Project e-Sanad aims at providing a centralized platform for contactless and
paperless document verification/attestation/appostille service for Indian Citizens,
foreigners who have obtained documents from document issuing authorities (DIAs) in
India. These include all type of documents i.e personal, educational and commercial. The
project is being implemented in phased manner and proposed to extend the service to
Indian residing abroad. The system ensures that the foreign employers/other verification
agencies get digitally verified genuine documents.
Steps to be followed on e-Sanad Portal:1.The applicant will register and login in E-Sanad Portal, URL-https://esanad.nic.in or QR

2.Select for non pre-verfied documents.
3.Select document type as personal and the issuing authority state as Punjab.
4.Select the Deputy Commissioner office under which your residence falls as document
Issuing authority (DIA).
5.Fill the required details and upload the documents.
6.Then proceed to online payment for attestation/apostille.
7.E-Sanad Portal will generate its acknowledgment receipt after the successful payment.
8.To Check the application status, please visit https://esanad.nic.in/checkStatus.
Benefits of E-Sanad:1.Faceless, cashless and paperless service.
2.Electronic movement of documents among stakeholders.
3.Substantial time saving as compared to the old process.
4.Ease of life for Indian Citizens as they can access the functionality online and need not to
visit any office.
5.Real time status enquiry through unique ARN (Application Reference Number)
6.SMS/E-mail alerts to the applicants at each stage of processing.
