---
doc_id: "a3fc93e10f0dbc5a"
source_url: "https://ipr.punjab.gov.in/media/documents/Final_Gazette_Report_2.pdf"
ministry: "Directorate of Information & Public Relation, Punjab"
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9b5fdd32c766302f"
---

<!-- page 1 -->

6772

PUNJAB GOVT. GAZ. (EXTRA), SEPTEMBER 29, 2025 (ASVN 7, 1947 SAKA)

EXTRAORDINARY
Published by Authority
CHANDIGARH, WEDNESDAY, OCTOBER 1, 2025 (ASVINA 9, 1947 SAKA)
GOVERNMENT OF PUNJAB
DIRECTOR INFORMATION & PUBLIC RELATIONS
ADVERTISEMENT POLICY FOR WEBSITES 2022
NOTIFICATION
The 1st October, 2025
No. PR(EM)- I/1213697/2025.- ADVERTISEMENT POLICY FOR WEBSITES 2022 will be
Extended for One year from 8.10.2025 issued vide No. I/439348/2022, dated 7th October, 2022, First Amended
No.I/594156/2023, dated 6th July, 2023, Extended No. I/940838/2024, 1st October,2024, Second Amended
No. I/1062740/2025, 25th March, 2025 and Third Amended No. I/1094220/2025, 8th May,2025. It may be
amended at any time by the DIPR Punjab.

RAMVIR, IAS
Secretary to Government of Punjab
Information and Public Relations

Chandigarh
The 30th September, 2025

3517/10-2025/Pb. Govt. Press, S.A.S. Nagar

( 6807 )
