---
doc_id: "94db5ea4a43efd3c"
source_url: "https://emandikaran-pb.in/files/CafeTender.pdf"
ministry: "Punjab State Agricultural Marketing Board (Punjab Mandi Board, PSAMB), Punjab"
title: "Canteen corrigendum"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cd33c5e026ac2753"
---

<!-- page 1 -->

CORRIGENDUM
PUNJAB STATE AGRICULTURAL MARKETING BOARD
TENDER NOTICE FOR FOOD AND BEVERAGES (F&B) SERVICES
1.
2.
1.

Punjab Mandi Board invites sealed tenders from reputed, registered and licensed
professional companies to provide Food and Beverages Services for Kisan Bhawan, Sector 35
Chandigarh.
The time schedule of various activities to be carried out for awarding the contract of catering
services is listed below:
Food and Beverages (F&B) services at Kisan Bhawan, Sector 35
Name of Work
Chandigarh

2.

Earnest Money Deposit

Rs.1,00,000/-(Rupees One Lac only) by crossed Bank Draft / Banker’s Cheque
drawn in favour of MDF (Marketing Development Fund) .

3.

Security Deposit

Rs.3,00,000/-(Rupees Three Lac only) by way of a Security deposit

4.
5.

Date of issue of tender
Last date and time of receipt of
Tenders
Last date of enquiry

Tender will be available from 09.5.2026 to 25.05.2026
25.05.2026 upto 11.00 a.m.

6.
7.

Address at which the Tenders
are to be submitted in physical
form duly signed and stamp at
each page.
9. Date and time of opening of Bids
10. Place of opening Tenders

11.
12.
13
14

Penalty
Validity of Offer
Commencement of work
Corrigendum (if any)

15

Availability
of Tender
Document
For Tender related queries

16

3.
4.

5.
6.
7.
8.

14.05.2026
In hard copy at Punjab State Agricultural Marketing Board, Punjab Mandi
Bhawan, Sector 65 A, Phase 11, Sahibzada Ajit Singh Nagar, Punjab 160062.

25.05.2026 at 03.00 p.m.
Punjab State Agricultural Marketing Board, Committee Room No:117, Punjab
Mandi Bhawan, Sector 65 A, Phase 11, Sahibzada Ajit Singh Nagar, Punjab
160062.
As per Tender Clause
120 days from the date of opening the Tenders.
Within 30 days on the issuance of work order
Will be published on https://emandikaran-pb.in
Tender documents to be downloaded from https://emandikaran-pb.in
Contact Person Care Taker, Kisan Bhawan
E-mail :chiefop@punjab.gov.in
Mobile No 95011-99788

The tender shall be submitted in physical format with specified documents sealed in an
envelope of appropriate size endorsed on the outside face as under:
“F&B Services at Kisan Bhawan, Sector 35 Chandigarh,”
The envelope containing the tender documents as per instructions mentioned above shall be
deposited in the tender box available office of Care Taker, Punjab State Agricultural
Marketing Board, Punjab Mandi Bhawan, 1415/11, Jagatpura Bypass Rd, Sector 65 A, Phase
11, Tarf Kumbra, Sahibzada Ajit Singh Nagar, Punjab 160062
In case the date of opening of tenders is declared as a holiday, the tenders will be opened on
the next working day at the same time.
For complete details and formats of Bid documents please log on to website
https://emandikaran-pb.in.
Last date for receipt of Bids is 25.05.2026 at 11.00 a.m.
Punjab Mandi Board reserves the right to reject any/all Bids without assigning any reason
whatsoever

<!-- page 2 -->

Secretary
Punjab Mandi Board
