---
doc_id: "dbbac987cfa3a5c5"
source_url: "https://forest.punjab.gov.in/media/documents/Corrigendum_notification-converted_qgwl2hT.pdf"
ministry: "Forests and Wildlife Preservation Department, Punjab"
title: "ਕੋਰੀਜੈਨਡਮ"
date: ""
pages: 1
method: "tesseract:pan+eng"
script: "LATIN"
needs_ocr: false
sha1: "0cc15fa5622bf7b8"
---

<!-- page 1 -->

£ ia
% IW
ay (੮ * 9 ‘i
ਨ" a4” GOVERNMENT OF PUNJAB
ਣਾ DEPARTMENT OF FORESTS & WILDLIFE PRESERVATION
(FOREST BRANCH)
CORRIGENDUM :
No.39/11/2011-FT-3/72 ©) AU ੨1) dated: J “ Br Ded 6*
#)
cy In the first- para of Notification issued with. Punjab
ਰਾ ੨
<
ern Government 140.39/118/2002-11-11/1486 dated 03.02.2003 under section
e ੧ ae} 3, the words “Punjab Government Notification No.4811-Ft-V1/8163
we fs
° ੧. dated 09.06.1961” may be read as “Punjab Government Notification
No
% awe No.458__dated 23.09.2014 and Punjab Government Notification
No.6530-D-50/5727 dated 20.11.1950”.
ਵੀ Chandigarh, dated VISWAJEET KHANNA ;
7 02.03.2016 Financial Commissioner & Secretary
to Govt. of Punjab, Department of
ਵਿ Forests & Wildlife Preservation. :
indst. No.39/11/2011-FT-3/ dated
A copy with a spare copy of the Corrigendum is forwarded to
the Controller, Printing & Stationery, Punjab for publication of the same in
ਸੀ ` ੧2 official gazette of Punjab Government. He is also requested to. supply
20 copies of Corrigendum to this Department.
a
੮ Special Sccrétary to Govt. of Punjab,
Department of Forests & Wildlife
ਨ Preservation. ੪
Endst. No.39/11/2011-FT-3/ 7 ₹)% >| 2-2 dated F- 3°24
Latopy is forwarded to Principal Chief Conservator of Forests
(HoFF), Punjab for information and necessary action.
Special Secretary to Govt. of Punjab,
Department of Forests & Wildlife
Preservation. Je
