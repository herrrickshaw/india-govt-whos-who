---
doc_id: "c5bceec76181b3ed"
source_url: "https://pscst.punjab.gov.in/sites/default/files/documents/Notifications/PSCST_notificationforGoverning%20Body_20240803.pdf"
ministry: "Punjab State Council for Science and Technology, Punjab"
title: "Click here"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "236939c5a7f07c9e"
---

<!-- page 1 -->

GOVERNMENT OF PUNJAB
DEPARTMENT OF SCIENCE, TECHNOLOGY & ENVIRONMENT
(STE BRANCH)
NOTIFICATION
Dated Chd: 08/03/2024
No. STE-STEB010/307/2020-STE3/799261 The Governor of Punjab in exercise of the
powers conferred under Regulation 3.1.1., 3.1.2, 3.1.3, 3.1.4, 3.1.5 and 7 of the
Memorandum of Association & Rules and Regulations of Punjab State Council for
Science & Technology is pleased to reconstitute Governing Body of Punjab State
Council for Science & Technology consisting the following members. The terms of
Governing Body shall be for three years:1
2
3
4
5
6
7
8
9
10
11
12
13
14

Chief Minister, Government of Punjab
Minister for Finance, Punjab
Minister for Planning, Punjab
Minister for Industries, Punjab
Minister for Health & Family Welfare, Punjab
Minister for Agriculture, Punjab
Minister for Education & Higher Education, Punjab
Minister for Technical Education, Punjab
Minister for Labour, Punjab
Minister for Local Government, Punjab
Minister for Urban Development, Punjab
Minister for Power, Punjab
Chief Secretary to Govt. of Punjab
Administrative Secretary, Science Technology and
Environment
15 Administrative Secretary, Finance
16 Administrative Secretary, Planning
17 Administrative Secretary, Housing and Urban Development
18 Administrative Secretary, Health
19 Administrative Secretary, Technical Education
20 Administrative Secretary, Industries and Commerce
21 Administrative Secretary, Power
22 Administrative Secretary, Local Government
23 Administrative Secretary, Education
24 Administrative Secretary, Agriculture
25 Administrative Secretary, Animal Husbandry
26 VC, Punjab Agricultural University, Ludhiana
27 VC, Punjabi University, Patiala
28 VC, Guru Nanak Dev University, Amritsar
29 VC, Punjab University, Chandigarh.
Expert Members other than Ex-Officio Members
30 Executive Director, PSCST
31 Adviser & Head,
State Science, Technology Program Division, Department of
Science & Technology, Govt. of India, New Delhi.
32. Advisor/Director,
Ministry of Environment, Forest and Climate Change, Govt.
of India, Regional Office, Chandigarh.
33 Director,
National Innovation Foundation,Govt. of India.
34 Director,
Indian Institute of Technology (IIT), Ropar.
35 Vice Chancellor,
Sri Guru Angad Dev Veterinary and Animal
Sciences University, Ludhiana.

President
Vice President
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Member
Convener
Member

Member

Member
Member
Member

<!-- page 2 -->

36

Director,
Central Scientific Instrument Organization, Chandigarh
37 Director,
Institute of Nano Science & Technology, Mohali.
38 Chairman,
Punjab Pollution Control Board, Patiala.
39 Director,
Indian Institute of Science, Education & Research, Mohali.
40. Sh. Ravinder Singh Rawal,
H.No.B-1, 516, Gandhi Colony Road,
Old Rajpura, Distt. Patiala-140401
41. Sh. Naresh Garg,
H.No.1463, Sector 44-B, Chandigarh.

Member
Member
Member
Member
Member

Member

2.
All members of the Governing Body of PSCST other than ex-officio members
shall have tenure of membership for a period of three years.
3.
With regard to Sr.Nos.14 to 25 above, the term Secretary refers to the
Administrative Secretary of the department concerned, whether of the rank of Additional
Chief Secretary/ Financial Commissioner/ Principal Secretary or Secretary.
4.
Other terms & conditions, as specified in Memorandum of Association and Rules
& Regulations of PSCST, would remain the same.
Dated, Chandigarh
The:08/03/2024

Rahul Tiwari, IAS
Secretary to Govt. of Punjab
Department of Science,
Technology & Environment.

Endst No. STE-STEB010/307/2020-STE3/799261/1
Dated: 08.03.2024
A copy alongwith a spare copy is forwarded to the Controller, Printing and
Stationery, Punjab, Chandigarh with the request to publish this notification in the Punjab
Govt. Gazette (Ordinary) and to supply 50 copies thereof to this department for record.

Superintendent
Endst No.STE-STEB010/307/2020-STE3/799261/2-3
Dated: 08.03.2024
A copy is forwarded to the following for Information and necessary action:
1.
Principal Secretary to Chief Minister, Punjab for the kind information of Hon’ble
Chief Minister, Punjab
2.
Secretary to Chief Secretary, Punjab for kind information of worthy Chief
Secretary.

Superintendent
Endst No.STE-STEB010/307/2020-STE3/799261/4-5
Dated: 08.03.2024
1.
Executive Director, Punjab State Council for Science and Technology.
2.
All concerned.

Superintendent
