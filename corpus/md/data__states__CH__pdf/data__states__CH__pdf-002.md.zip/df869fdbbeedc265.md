---
doc_id: "df869fdbbeedc265"
source_url: "https://laws.puchd.ac.in/includes/noticeboard/2025/20250310124430-covocation72compressed.pdf?2026"
ministry: "Department of Laws, Panjab University, Chandigarh"
title: "72nd ANNUAL CONVOCATION, WEDNESDAY, MARCH 12TH, 2025 INSTRUCTIONS TO CANDIDATES"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c8f4f632f1ebc015"
---

<!-- page 1 -->

PANJAB UNIVERSITY
72nd ANNUAL CONVOCATION, WEDNESDAY, MARCH 12TH, 2025
INSTRUCTIONS TO CANDIDATES
I. Convocation for the conferment of the following degrees will be held on Wednesday, March
12, 2025 in the Panjab University Gymnasium Hall, at the University Campus, Sector-14, Chandigarh.
Candidates shall wear the academic costumes as specified in the table given below. The
Jackets will be available on hire before Rehearsal @ Rs. 120/- per set (for Rehearsal and Convocation)
alongwith a security of Rs. 1000/- (refundable on return) from the firm who put up his stalls near
the Gymnasium Hall.
Name of Examination
1. D.Sc., D.Litt. & Ph. D
2. All U.G. & P.G. Candidates

Colour of Jacket
Red
Saffron

Date & Time of Rehearsal
11.03.2025 at 10.00 AM Sharp
11.03.2025 at 10.00 AM Sharp

The general attire of the Candidates of the Annual Convocation to be worn with Phulkari
Jackets will be follows:BOYS

GIRLS

Western Wear: White
Formal Shirt with Beige Pants

Western Wear: White Formal
Shirt with Beige Pants
OR

Indian Wear: White/Off
White/Beige Kurta Pajama

Indian Wear: White/Off
White/Beige Salwar Suit/
Churidaar Suit/Sari

Turban: White/Off
White/Beige

Dupatta: White/Off White/
Beige

II.
Candidates who are eligible to obtain their degrees at the Convocation, shall conform to the following
conditions :
(a) The college candidates and those who have passed the examinations from University Departments shall obtain the identification card from the Chairman of the Department/Principal of the
concerned college and get it duly attested from him/her.
(b) Those who passed as private candidates or as late college students, shall bring the enclosed
identification card duly attested by any ‘A’ Class/Gazetted Officer.
A candidate who does not bring with him/her the Identification card with photograph duly
attested by the competent authority mentioned above and does not attend the Rehearsal at
10.00 a.m. on March 11, 2025 (Tuesday) will not be permitted to attend the Convocation
to be held on March 12, 2025 at 10.30 A.M.(Wednesday).
III. A candidate who is eligible for admission to the degree but does not intend to appear at the University
Annual Convocation in person can obtain his/her degree in accordance with the procedure laid down below :
(i) He/She shall give at least five days’ notice to the Registrar of his/her intended absence, and may
then be admitted to his/her degree at any subsequent University Annual Convocation provided
that he/she gives at least fifteen days’ notice to the Registrar of his/her intention to appear.
(ii) If the candidate fails to attend the Convocation, he/she may collect his/her Degree from their
respective college/department. Ph.D. candidates may collect their Degrees from thesis section
P.U. Chandigarh.
On receipt of such application the Vice Chancellor shall consider it and may declare the applicant to be
admitted to the degree in absence.
SPECIAL INSTRUCTIONS FOR THE CANDIDATES
1. Rehearsal Day March 11, 2025 (Tuesday) 10.00 A.M. Sharp
Convocation

March 12, 2025 (Wednesday) 10.30 A.M. Sharp

2. Candidates who are to receive the Degrees at the Convocation are requested to
(i)

be punctual for Rehearsal as well as for Convocation.

(ii) enter the Gymnasium Hall on Rehearsal/Convocation Day with their Jackets, from Entry No. 3.
of Gymnasium Hall.

<!-- page 2 -->

Occupy their seats (One Hour) before start of the Rehearsal
as well as (One Hour) before the start of Convocation.

(iii)
(iv)

observe silence and proper decorum while in the Gymnasium Hall.

(v)

remain in their seats, during Rehearsal and Convocation proceedings.

(vi)

see that they do not block the passage--either by standing or by walking to and fro.

(vii)

occupy correct seat. Note the Row No. and Seat No. allotted at the time of Rehearsal.

(viii)

ensure that they have signed the Roll call sheets at the time of the Rehearsal--otherwise
they will not get their Degrees at the Convocation.

(ix)

Briefcase, Camera, Umbrella, Handbag, Mobile, Water Bottle and Helmet etc. are not allowed
in the Gymnasium Hall. Kindly make your own arrangements for your belongings.

3. After receiving the Degrees, candidates will kindly bow to the Chancellor/Vice-Chancellor before
returning to their seats.
4. In case of any discrepancy in the Degree awarded, please see the Deputy Registrar (Exams.),
after the Convocation is over. The discrepancy need not be pointed out during the Convocation,
as that may cause unnecessary disturbance in the proceedings of the Convocation.
5. All the guests as well as candidates will please stand in their seats :
(i)

when the procession of Principals, Professors and Fellows along with the Chancellor/
Vice-Chancellor enters the Gymnasium and will keep standing till they have taken their
seats.

(ii)

when National Anthem is being recited.

(iii)

when the procession leaves the Gymnasium Hall, no one should leave until the procession has left
the Gymnasium Hall.

6. Candidates must not leave the Gymnasium Hall during the proceedings of Convocation.
Note :–For any information please contact on Tel. No. 0172-2534870, 2534869, 2541275 and
email:arrs@p.u.ac.in
Panjab University Alumni Association :7.

Life membership makes you a life member and in return you will get various facilities like swiming,
gym, shooting range, booking of rooms and lawns at Alumni House. Kindly bring Rs. 1500/- and
two passport size photographs.
SdPANJAB UNIVERSITY
Prof. Yajvender Pal Verma

CHANDIGARH-160014

REGISTRAR

Important :–– Candidates who have already received their Degrees in absentia are not permitted to attend the Convocation.
D.A.––1. Identification Card.
2. Parking Sticker No. 3

E2:\P.U.P. (404)–1200/03-03-2025

2
