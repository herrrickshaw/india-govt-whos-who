---
doc_id: "aef223e87bab89bf"
source_url: "https://gandhianstudies.puchd.ac.in/includes/noticeboard/2023/20230728095238-normsofpms2023-2024ofp.u14.7.2023.pdf?2026"
ministry: "Department of Gandhian and Peace Studies, Panjab University, Chandigarh"
title: "Norms/Guidelines of PMS of SC of Punjab(2023-2024)"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9488708f638a49f1"
---

<!-- page 1 -->

PANJAB UNIVERSITY, CHANDIGARH

From:
To
The Co-ordinator-cumAll the Teaching Departments of
P.U. and its Regional Centres,
Liaison Officer (SC/ST Cell),
Panjab University,
Panjab University, Chandigarh.
Chandigarh.
No. 201-300-SC/ST Cell
Dated: 14.7.2023
Subject: Norms/Guidelines regarding Post Matric Scholarship (PMS) Scheme
for SC students studying or taking admissions in Panjab University,
Chandigarh & its Regional Centers, for the academic session 20232024.
PMS Norms/ Guidelines for SC students of Punjab State only:
(i) For Normal courses: Tuition fee and other non-refundable
charges would not be charged, except refundable component
such as security etc., from the SC students belonging to
Punjab State studying or taking admission in normal courses,
at the time of admission (having annual family income equal to
or less than Rs. 2.50 lac and eligible for Post Matric
Scholarship Scheme). Eligible PMS SC students shall give
undertaking on affidavit as per (Annexure I) at the time of
admission.
(ii)

For Self-Financing Courses: Such students shall only deposit
25% of the fee of the first semester at the time of admission
with undertaking (Annexure I) and 25% of the fee at start of
second semester preferably before the last date decided by
competent body of the University.

Eligibility Criteria:
1. The student must SC category
2. He/she belong to Punjab state
3. The Annual income of the family is not above 2.50 lac per
annum.
4. Should have free ship card or registered for free ship card
before last date.
Contd…p/2

<!-- page 2 -->

-2Following points need to be taken care by SC student(s) at the
time of admission or before submission of hard copies of the
PMS forms:
1. The bank account of student be in active mode. Dormant bank
or parent bank account should not be used.
2. Bank account number of the student must be linked with the
Aadhaar Number.
3. Correct mobile number of the student be quoted and should not
be used or attached with other bank account.
4. In the case of merge of banks, updated /corrected IFSC code
must be mentioned on the Ambedkar Portal.
List of required documents for the PMS of Punjab state (SC
students):1. Original Income Certificate (for fresh students).
2. Photocopy of Income Certificate (for Renewal Students)
3. Residence Proof.
4. Self-certified photocopy of Caste Certificate
5. Self-certified photocopy of Aadhaar Card.
6. Self-certified copy of Bank account number with IFSC Code.
7. Previous year of passing certificate or DMC.
8. Undertaking/affidavit (Annexure-I)
Important Note:- The SC students of Punjab state have to apply on the
Dr. Ambedkar Scholarship Portal (www.scholarships.punjab.gov.in)
for free ship Card. Thereafter, fill online Post Matric Scholarship form
before due date on the above said Portal, which is mandatory for all
such students who wish to avail the benefit of reimbursement of claim
of fee paid by them at the time of admissions in the respective academic
session.
The Chairpersons/H.O.D. of all the Teaching Departments are
requested to get all the formalities completed by eligible students, and
hard copies of their Post Matric Scholarship forms along with
supporting documents duly checked, online verified, countersigned
(with office seal) and list of the SC students in the enclosed format
(Annexure-II) may be sent to the office of SC/ST Cell before due date as
announced by the respective state, for onwards submission to the
District Welfare Officer of the Punjab state.
Contd…p/3

<!-- page 3 -->

-3Chairperson/H.O.D. of each department must ensure that SC student
of Punjab who have been given benefit of PMS, during admission must
fill PMS scholarship form. Chairperson must depute suitable office
person to keep a record of such students along with supporting
documents to maintain the financial record and accountability of
such students.
Any SC student of Punjab who availed PMS benefit during
admission but failed to submit PMS on time OR whose PMS
scholarship has been rejected by welfare department of Punjab due
to any reason must pay the entire fee to continue the respective
course.
The fee would be reimbursed by the Welfare Department of Punjab
State Government directly into the bank account of the eligible SC
students. It is the duty of student to deposit receipt of the fee
paid by student to their respective department within in a
stipulated time as per undertaking given by candidate, failing
which late fee would be charged as per University norms.

Sd/Coordinator-cum-Liaison Officer
SC/ST Cell

<!-- page 4 -->

<!-- page 5 -->
