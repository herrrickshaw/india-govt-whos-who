---
doc_id: "de926ac3fc9d8be4"
source_url: "https://gandhianstudies.puchd.ac.in/includes/noticeboard/2020/20200617115755-phdvivavoceexaminationofms.saviti22ndjuneat10am.pdf?2026"
ministry: "Department of Gandhian and Peace Studies, Panjab University, Chandigarh"
title: "Notification of PhD Viva Voce Examiantion of Ms. Saviti on 22nd June at 10am via online mode"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b13577ab62925249"
---

<!-- page 1 -->

Department of Gandhian and Peace Studies
Panjab University, Chandigarh
Ref. No.: 334-345/GPS

Date: 17/06/2020

Regarding: Online Open Viva Voce Test and Presentation of Ph.D. Thesis
The presentation and open Viva-voce Test of Ms. Saviti will be conducted according
to the following schedule:
Title of the Ph.D. Thesis

Date

Venue

Time

“HUMAN RIGHTS OF 22.06.2020 Cisco WebEx
10:00 a.m.
TRIBALS: A CASE STUDY
Meeting ID: 156 917 4894
OF LAHAUL SPITI”
Password: 22gps2020
The direct link of the meeting is:
https://meetingsapac11.webex.com/meetingsapac11/j.php?MTID=m0249c1583b01b8704
9a7d42fe6d599e2
The Faculty members of the University Teaching Departments, Research Scholars,
Students and all those who are interested in the subject matter of the above thesis are
cordially invited to attend and participate in the discussions.
(Chairperson)
Copies to:
1. O.S.D., VCs Office for kind information of the Vice-Chancellor
2. The Dean of University Instruction, P.U., Chandigarh
3. The Registrar, Panjab University, Chandigarh
4. The Controller of Examinations, P.U., Chandigarh
5. The Deputy Registrar (Secrecy), P.U. Chandigarh
6. Chairpersons, Teaching Deptts. of P.U. for circulations among the members of the
faculties, Research Scholars and Students
7. The Director, Public Relations, P.U., Chandigarh
8. Faculty Members, Research Scholars and Students of the Department of Gandhian
and Peace Studies
9. Dr. Ashu Pasricha, Expert (As nominated by the Vice-Chancellor)
10. Dr. Manish Sharma, (Supervisor of the candidate)
11. Ms. Saviti the candidate
12. The External examiner of the candidate
