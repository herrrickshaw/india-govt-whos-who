---
doc_id: "fff78fac93fdd2a0"
source_url: "https://gandhianstudies.puchd.ac.in/includes/noticeboard/2022/20220512130656-interviewnoticefortheappointmentofguestfacultyinthedepartmentofgandhianandpeacestudies.pdf?2026"
ministry: "Department of Gandhian and Peace Studies, Panjab University, Chandigarh"
title: "Notice for the Walk-in-Interview for the Guest Faculty in the Department of Gandhian and Peace Studies"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "41e6b187597cfe67"
---

<!-- page 1 -->

DEPARTMENT OF GANDHIAN AND PEACE STUDIES
PANJAB UNIVERSITY, CHANDIGARH
(Estd. Under the Panjab University Act VII of 1947 – enacted by the Govt. of India)

Mobile No.- +91-9417454607
Intercom: 4183, 4188

Dr. Manish Sharma
Chairperson

www.gandhianstudies.puchd.ac.in
E-mail: gps@pu.ac.in
manish@pu.ac.in

Ref. No. 320/GPS

Date: 12/05/2022

WALK-IN INTERVIEW
The Walk-in-Interview for appointing one post of Guest Faculty to teach the Subject of M.A. in Gandhian
and Peace Studies for the Even Semester (Session 2021-2022) will be held on Thursday, 19 th May, 2022 in the
Office of Chairperson, Department of Gandhian and Peace Studies, Panjab University, Chandigarh, as per
schedule given below:
Date

Subject

Vacancy

19/05/2022

Gandhian
and
Peace Studies

01

Time
Reporting Time

:

01:00 p.m.

Documents Verification

:

01:30pm

Interviews

:

03:00 pm onwards

Essential Minimum Qualifications as per PU/UGC Norms:
1. Good academic record as defined by the concerned university/department with at least 55%marks (50%
marks for SC/ST/Physically & Visually Handicapped) or an equivalent grade in a point scale wherever
grading system is followed at the Master’s Degree level in the relevant subject i.e., Gandhian and Peace
Studies from a recognized Indian University, or an equivalent degree from an accredited foreign
university.
2. Besides fulfilling the Above Qualifications, the candidate must have cleared the National Eligibili ty Test
(NET) conducted by the UGC, CSIR or similar test accredited by the UGC like SLET/SET.
3. Notwithstanding Anything Contained in Sub-clauses (i) and (ii) candidates, who are, or have been
awarded Ph.D. Degree in accordance with the University Grants Commission (Minimum Standards and
Procedure for Award of Ph.D. Degree) Regulations, 2009, shall be exempted from the requirement of the
minimum eligibility condition of NET/SLET/SET/ as per Panjab University/UGC rules.
All the applicants are advised to bring their original certificates and other relevant documents for
verification along with the duly filled form giving the details at the time of interview. The application form
for the post of Assistant Professor is available at https://forms.puchd.ac.in/forms/20200122155429directrecruitmentassistantprofessorapplicationformasperugcregulation2018.pdf
No TA/DA will be paid for attending the interview.
The above assignment will be on lecture basis with a token honorarium of Rs. 1000/- per lecture with an
upper limit of Rs. 25000/- per month. The candidate shall have to give an undertaking that he/she will not
draw any fellowship/stipend or any financial assistance from any agency till they are teaching in the
department as a Guest Faculty. The candidates who are already availing JRF/PDF or any other scholarships
in the University are not entitled for the honorarium but they will be issued experience certificate for the
Guest Faculty or they have to resign from that Fellowship.

(Chairperson)
