---
doc_id: "fda3a99d3c9dcb5a"
source_url: "https://www.library.puchd.ac.in/includes/tenders/2010/20101111101934-sdeelect-earthing.pdf"
ministry: "A. C. Joshi Library, Panjab University, Chandigarh"
title: "Provision of Earthing for newly setup Laboratory"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ee3309cf654fb341"
---

<!-- page 1 -->

PANJAB UNIVERSITY
CONSTRUCTION OFFICE, CHANDIGARH
NOTICE INVITING QUOTATION
Sealed quotations item / percentage rate basis are invited from the Contractors on the approved list of
P.W.D. Building and Roads Branch/Central P.W.D. for the following works.
The quotations will be received by the undersigned in his office at 3.00 p.m. on 23.11.2010 and opened
at the 3.30 p.m. in the presence of the quotationers or their representatives who may like to be present at that
time.
Sr.
No.

Name of work

1.

Chargeable Head: - Infrastructure of P.U.R.S.E.

Provision of Earthing for newly setup Laboratory
(i.e. Central Facility Laboratory) on the first floor of
University Institute of Chemical Engineering &
in Panjab University Campus,
Technology
Sector-14, Chandigarh.
Conditions:
1.
2.

3.
4.
5.
6.
7.
8.

Estimated
Cost

Time
Limit

Rs.31,500/-

20 Days

The detailed Notice Inviting Quotation can be seen in the office of the undersigned at any time
during working hours.
The contractor having not done any work in the University should submit along with the his
request for the issue of quotations, a list of Works(duly attested by the department concerned)
done by him during the last three years indicating the amount and nature of works and time of
completion in each case.
Conditional Quotation will not be accepted.
Quote your rate both in words and figures in quotations.
Over-writing should be avoided.
No payment will be made for running bill amounting to less than Rs.1000/5% security will be deducted from the bill.
The quotation will be received in the office of Er. Kulwant Singh S.D.E. (Elect.) up to
3.00
p.m. P.U. does not take any responsibility for any postal delay in delivery by Registered/ Speed
Post or loss in transit of the tender form.

Sub Divisional Engineer (Elect),
P.U., Chandigarh.
