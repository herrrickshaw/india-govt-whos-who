---
doc_id: "c6cace61e9ca390b"
source_url: "https://chandigarh.gov.in/cadmin//uploads/1785132434_094ca315fd6823a6d643.pdf"
ministry: "Agriculture Department, Chandigarh"
title: "title_en'>Transfer Order regarding engagement of retirees as Section Officer (SAS) on contract basis"
date: ""
pages: 1
method: "tesseract:pan+hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "f0a9a22bbbd4c5b3"
---

<!-- page 1 -->

CHANDIGARH ADMINISTRATION =
FINANCE DEPARTMENT 4
(SAS ESTABLISHMENT BRANCH) 3
3" Floor, Chandigarh Secretariat, Sector 9, Chandigarh
ORDER
Consequent upon the engagement of retirees as Section Officer (SAS) on contract
basis in the Finance Department, Chandigarh Administration, the following transfers and postings are
hereby made amongst the officers, as under:
ee eT
Officer

1 |Sh. Ankit Arora, | Excise & | State Legal | He shall also look after the work of Prisons
Section Officer | Taxation Services | Department relieving Sh. Rajesh Gupta, AC
SAS Department} _Authorit F&A) from the additional charge. रह व

2 | $॥. Vinod Kumar - | Rents On Appointment against vacant post of
Kaushik, Section Organization | Section Officer (SAS) in the department.
Officer (on contract:

3 | Sh. Mukesh Chand, - Municipal | On Appointment against vacant post of
Section Officer (on Corporation | Section Officer (SAS) in the department.
contract

4 | Sh. Nirmal Singh, - | Municipal | Qn_Appointment_against vacant post Appointment against vacant post of
Section Officer (on | Corporation Section Officer (SAS) in the department.
contract |
Section Officer (on | | Taxation |to transfer of Sh. Ankit Arora, Section
contract | Officer.

Smt. Tarvinder Directorate | On Appointment against vacant post of
Guleria, Section of Finance & | Section Officer (SAS) in the department.
Officer (on contract, Accounts

7 | Sh. Rajesh Kumar, - Police On Appointment against vacant post of
Section Officer (on | Department | Section Officer (SAS) in the department.
contract | |
Sh. Bhupesh Mittal, | - Education | On Appointment against vacant post of
Section Officer (on Department | Section Officer (SAS) in the department.
contract
Smt. Shampa Das, - CCET On Appointment against _vacant_post of
Section Officer (on | (Degree | Section Officer (SAS) in the department.
contract !__ ४५५ | ਲੀ.

Apart from above, Sh. Rajesh Gupta, Assistant Controller (F&A) is hereby assigned the
charge of CITCO, Chandigarh in addition to his own duties.
DIPRAVA LAKRA, IAS
Chandigarh dated हु FINANCE SECRETARY,
the 09"" July 2026 CHANDIGARH ADMINISTRATION.
Endst. No. F&PO (1)-2026/ 158 6] Dated: 10-07-2026
A copy is forwarded to the following for information and necessary action:-

|. The Commissioner, Municipal Corporation Chandigarh.

||. _ The Excise & Taxation Commissioner, U.T., Chandigarh.

||. The Director General of Police, U.T., Chandigarh.

1੪. The Inspector General of Police, Prisons, U.T., Chandigarh.

V. The Director, Directorate of Finance and Accounts, U.T., Chandigarh.

1. _ The Director Information Technology, U.T., Chandigarh with the request to upload the orders
on the official website of the Chandigarh Administration under the tab “Administration- Order’s/
Notifications- Finance Department’.

Vil. The Director Higher Education, U.T., Chandigarh.

VII. The Managing Director, Chandigarh Child and Women Development Corporation.

IX. | The Chief General Manager, CITCO, Chandigarh.

X. | The Member Secretary, State Legal Services Authority, U.T., Chandigarh.

XI. The Principal, Chandigarh College of Engg. & Tech. (Degree Wing), Sector 26, Chandigarh.

XIl. — The Assistant Controller (F&A), Rents Organization, U.T., ee

XIll. All concerned officers.
5 ॥੧੭੧੯ ਰ੍
Finance & Planning Officer,
for Finance Secretary,
DAJNIL Chandigarh Administration
