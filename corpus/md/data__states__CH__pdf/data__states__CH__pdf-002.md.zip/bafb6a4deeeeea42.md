---
doc_id: "bafb6a4deeeeea42"
source_url: "https://geology.puchd.ac.in/includes/noticeboard/2026/20261021145450-jaaccircularex-indiadutyleavefrom02.11.2026to12.11.2026toprof.gurmeetkaur.pdf?2026"
ministry: "Department of Geology, Panjab University, Chandigarh"
title: "CIRCULAR JAAC 1.10.2026-Ex-India (duty leave) from 02.11.2026 to 12.11.2026 to Prof. Gurmeet Kaur"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a949254cb8db33b5"
---

<!-- page 1 -->

PANJAB UNIVERSITY, CHANDIGARH
(Estt. Under the Panjab University Act Vll of 1947- enacted by the Govt. of India)
1947

Department of Geology

Phone : 91-0172-2534235

INDIA

No. 1.10.2026

Panjab University, Chandigarh-160 014

Email: chairperson_geology@pu.ac.in

BY CIRCULATION

The Joint Administrative & Academic Committee (JAAC) of the Department is requested to
approve the following agenda by circulation:
Academic Committee -2026

Prof. Parampreet Kaur, Chairperson

Prof. Rajeev Patnaik
Prof. Ashu Khosla

Prof. Gurmeet Kaurh

Dr. B.P. Singh (
Dr. Seema Singh

Administrative Committee-2026

Prof. Parampreet Kaur, Chairperson
Prof. Rajeev Patnaik

Prof. Ashu Khosla

Prof. Gurmeet Kaur y
Dr. B. P. Singh e

Dr. Susanta Paikaray

Item No.l : The JAAC Committee of the Department of Geology recommends Ex-India (duty
leave) from 02.11.2026 to 12.11.2026 to Prof. Gurmeet Kaur for attending IUGS Geoheritage
2026 event (Portugal) and visit to UNESCO Site in Coimbra, Portugal (lnvitation attached) with
permission toprefix and suffix holidays i.e. Saturday and Sunday. The JAAcCommittee have

no objection for her above mentioned Ex-India (duty leave) and recommends the same as per

University rules.

(Prof. RajełyPanaik)

Secretary
Administrative Committee

(Dr. B.P. Singh)
Secretary

Academic Committee

(Prof. Parampreet Kaur)

Chairperson
