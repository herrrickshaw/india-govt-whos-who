---
doc_id: "99e7ebca752bdc7a"
source_url: "https://cdoe.puchd.ac.in/includes/noticeboard/2025/20250823155502-1.pdf?2026"
ministry: "Centre for Distance and Online Education, Panjab University, Chandigarh"
title: "Rules and Regulations of Examination"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "7ffaf7e05b9ca2fe"
---

<!-- no text layer: pending OCR -->
