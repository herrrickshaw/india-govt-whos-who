---
doc_id: "6dafedfb3b7e4050"
source_url: "https://laws.puchd.ac.in/includes/noticeboard/2025/20251108110209-20251107171724-officeorderno.703rdsdated07.11.2025.pdf?2026"
ministry: "Department of Laws, Panjab University, Chandigarh"
title: "Office Order"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "51029a721d6f9393"
---

<!-- page 1 -->

PANJAB UNIVERSITY, CHANDIGARH
No.: 703/R/DS
Date: 07.11.2025
OFFICE ORDER
Reference is invited to this Office Order No. 110-150/R/DS dated
30.04.2024, Public Notice-cum-Office Order No. D-R02/25/4542-4546 dated
01.04.2025 and Circular No. 57-160/R/DS dated 04.04.2025 whereby
instructions/advisories were issued to employees, students and stakeholders of
the University to carry and display identity cards on their person and to put
University Stickers on their vehicles.
The above Office Order/Public Notice-cum-Office Order/Circular is hereby
reiterated and it is further ordered that from 8th November, 2025, onwards the
entry to University Campuses for individuals not having University identity card
and vehicles not carrying University sticker would be prohibited. In addition,
protest, if any, will only be allowed by students/employees and not by any
outsider/s.
Sd/(Prof. Y P Verma)
Registrar
Issued to:
1. Heads of all Branches.
2. Chairperson, Directors and Coordinators of all Teaching Departments of
the University Campus.
3. Hostel Wardens of all Hostels located in the University Campus
4. Secretary to Vice Chancellor for kind information of the Vice Chancellor,
please.
5. Chief of University Security for necessary checking/compliance.
