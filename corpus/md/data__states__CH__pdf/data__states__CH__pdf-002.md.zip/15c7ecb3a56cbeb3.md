---
doc_id: "15c7ecb3a56cbeb3"
source_url: "https://puchd.ac.in/includes/documents/othercal/goi_2010.pdf"
ministry: "Panjab University, Chandigarh"
title: "Amendments 2"
date: ""
pages: 39
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "86199d7357e88b8c"
---

<!-- page 1 -->

The Secretary to the Government of India
Ministry of Human Resource Development
(Department of Education)
Shastri Bhawan
New Delhi
Dear Sir,
The
Senate
at
its
meeting
held
on
6.12.2009
(Para LXXVIII (Revised) has approved the amendments/additions/deletions
etc. of the following Regulations (as per copy attached) in anticipation
approval of Government of India/publication in the Government of
India Gazette. However, the addition in Regulation 24 (b) at page 33
Panjab University Calendar Volume I, 2007 mentioned under item No.
1 shall take effect from the date of approval of Government of India
and publication in the Government of India Gazette.
CALENDAR VOLUME I

ITEM 1
Addition to Regulation 24 (b) appearing at page 33 of Panjab
University Calendar, Volume I, 2007 shall take effect from the date of
approval of Government of India and publication in the Government of
India Gazette.
ITEM 2
Addition to Regulation 1.1 and deletion in Regulation 4 (Clause XII)
of Chapter II (A) (vi) ‘Board of Studies’, at pages 52-56 of Panjab University
Calendar, Volume I, 2007.
ITEM 3
Amendment in Regulation 1.3 relating to ‘Chapter VIII (A) Affiliated
Colleges ‘Conditions of Affiliation’ at page 157, Regulation 5.3 at page 159
and Regulations 23.1 and 23.2 of Chapter VIII(C) ‘Affiliated Colleges with
evening classes including conditions for such permission’ at page 165-166
of Panjab University Calendar, Volume I, 2007.

1

<!-- page 2 -->

CALENDAR VOLUME II

ITEM 4
Amendment in Regulation 1.1 for ‘Doctor of Philosophy in the
Faculty of Business Management & Commerce’ (effective from the year
2007) at page 369 of Panjab University Calendar, Volume II, 2007.
ITEM 5
Amendment in Regulation 1.2 for ‘Doctor of Philosophy in the
Faculty of Pharmaceutical Sciences’ (effective from the year 2007) at page
558 of Panjab University Calendar, Volume II, 2007.

ITEM 6
Amendment in Regulations 1, 5.1, 5.2, 5.3 and 12 for B.Sc. Nursing
(Post Basic) (w.e.f. the session July, 2005) at page 529-532 of Panjab
University Calendar, Volume II, 2007.
ITEM 7
Addition in Regulation 4.1 for ‘B.A./B.Sc. (General and Honours)
examinations’ (effective from the session 2005-06) at page 40 of Panjab
University Calendar, Volume II, 2007.
ITEM 8
Regulations for the Post-M.A. Diploma Courses in Professional
Counselling and Psychotherapy (One year – Annual System); and Post-M.A.
Diploma Courses in Psychological Testing (one year – Annual System).
(effective from the session 2007-08).
ITEM 9
Regulations for Advanced Diploma in Child Guidance and Family
Counselling (effective from the session 2007-08).
ITEM 10
Addition to Regulation 2.1 for M.Sc. (Honours School) (Annual
System) at page 117 of Panjab University Calendar Volume II, 2007
(effective from the session 2006-07).
ITEM 11
Addition of nomenclature of Postgraduate Diploma in Human Rights
and Duties (through Correspondence Studies) (effective from the session
2006-07) at page 312 of Panjab University Calendar, Volume II, 2007.

2

<!-- page 3 -->

ITEM 12
Regulations for MBA (Biotechnology) (Two-year) (Semester System)
(effective from the session 2007-08) at the Centre for Emerging Areas in
Science and Technology.
ITEM 13
Regulations for Master of Business Economics (M.B.E.) (Semester
System) (effective from the session 2006-07).
ITEM 14
Regulations for B.Sc. (Fashion Design) (effective from the session
2006).
ITEM 15
Introduction of Semester System in M.A. (Economics) in place of
Annual System in the Department of Economics, (effective from the
academic session of 2008-09).
ITEM 16
Amendment of Regulation 3.1 for B.C.A course at page 52 of Panjab
University Calendar, Volume II, 2007 (effective from the session 2008-09).
ITEM 17
Amendment of Regulation 3.1 for B.B.A course at page 332 of Panjab
University Calendar, Volume II, 2007 (effective from the session 2008-09).
ITEM 18
Amendment of Regulation 1(a) for Doctor of Philosophy in the Faculty
of Engineering & Technology at page 444 of Panjab University Calendar,
Volume II, 2007.
ITEM 19
Amendment of Regulation 1 for Degree of Doctor of Philosophy in the
Faculty of Law at page 402 of Panjab University Calendar, Volume II, 2007.
ITEM 20
Amendment of Regulation 1.1 for Ph.D. Degree in the Faculty of
Medical Sciences at page 508 of Panjab University Calendar, Volume II,
2007.
ITEM 21
Amendment of Regulation 1.2 for ‘Master of Arts (Education)’ at page
314 of Panjab University Calendar, Volume II, 2007.
3

<!-- page 4 -->

ITEM 22
Amendment of Regulation 2 for ‘Postgraduate Diploma in Fashion
Designing’ at page 107 of Panjab University Calendar, Volume II, 2007,
(effective from the session 2007-08).
ITEM 23
Amendment of Regulation 7 for M.C.A course at page 162 of Panjab
University Calendar, Volume II, 2007, (effective from the session 2008-09).
ITEM 24
Change in nomenclature of Bachelor of Physical Education
(B.P.Ed,) Four-Year Professional Programme to Bachelor of Physical
Education (B.P.Ed.) -a Four-Year Integrated Programme (effective from
the session 2008-09).
ITEM 25
Regulations for Postgraduate Diploma in Disaster Management
and Security (PGDDMS) (One-year Semester system) introduced at the
Centre for Defence & National Security Studies (effective from the academic
session 2008-09).
.......................
Copies of the relevant extracts from the minutes of the meeting of
Syndicate and Senate 4.12.2009 (Para 13) and (6.12.2009 (Para LXXVIII
Revised)
respectively
are
enclosed.
The
justification
of
the
amendments/additions/deletions in the Regulations is attached as per
Appendix (A). The changes in the proposed Regulation have been
under-lines (wherever possible).
I shall feel grateful, if you kindly obtain the sanction of the
Government of India in respect of the Regulations mentioned and
communicate to the undersigned at an early date.
Yours faithfully,
Sd/(S.S.Bari)
Registrar

Encl: as above.

Endst. No. ST-DRG/10/1457-58

Dated: 28.4.2010

Copy of the above letter along with two copies of amendments of
Regulations along with statement of modifications in the Regulations is
sent for consideration of amendments/additions/deletions of Regulations
to the Section Officer, University Grants Commission, Bahadur Shah Zafar
Marg, New Delhi.
Encl: As above.

Sd/-S.S. Bari
Registrar

4

<!-- page 5 -->

ITEM 1
Addition to Regulation 24 (b) appearing at page 33 of Panjab
University Calendar, Volume I, 2007.
PRESENT REGULATION
24.

PROPOSED REGULATION
24. No Change

In making Regulations under
Section 31 of the Panjab
University Act. 1947, the
following procedure shall be
followed:
(a) The
Syndicate
shall
consider all amendments
and draft regulations as
recommended
by
the
Regulations
Committee
and after making such
alternations
as
it
considers fit, shall submit
the same to the Senate.

(a) No Change

(b) The Senate shall consider
all amendments and draft
regulations
as
recommended
by
Syndicate and may make
such alterations as it
considers fit. The decision
of Senate along with the
proposed
amendments
and regulations shall be
forwarded
to
the
Government for sanction
and when their sanction
has been received, the
Common Seal shall be
affixed to the regulations.
The Regulations as finally
sanctioned
by
the
Government
shall
be
published
in
the
Government Gazette.

(b) No Change

However “(i) Panjab University
has
full
autonomy
in
academic matters for starting
new courses and ward of
degrees subject to the meeting
of norms and regulations
prescribed by the University
5

<!-- page 6 -->

Grants Commission and other
statutory professional bodies.
The University may take
appropriate decision in this
regard
after
obtaining
approval
from
their
Academic/Executive Council
as the case may be.
(ii) Panjab University can offer
any specified degree of the
University
Grants
commission, if it is approved
by the relevant statutory
professional body, provided no
financial liability falls on the
U.G.C.
ITEM 2
Addition to Regulation 1.1 at pages 52-56 and deletion in Regulation
4 (Clause XII) of Chapter II (A) (vi) ‘Board of Studies’, of Panjab University
Calendar, Volume I, 2007.
PRESENT REGULATION

PROPOSED REGULATION

1.1 There shall be two separate 1.1
Boards of Studies in the
following subjects: one for the
Under-graduate Studies for all
examinations up to B.A./B.Sc./
B.Com and B.A. (Honours) and
the other for Post-graduate
studies for all the M.A./M.Sc./
M.Com. examinations including
Post-graduate Diploma Courses
of one year duration excluding
M.Phil. and Honours School
Courses.
English, Hindi, Punjabi,
Sanskrit, Economics, History,
Political
Science
&
Civics,
Philosophy, Psychology, Public
Administration,
Sociology,
Botany,
Chemistry,
Mathematics, Zoology, Physics,
Statistics,
Geography
and
Commerce.
4. The Board of Studies in the
following
subjects
and
their
Conveners shall be nominated by
6

No Change

English,
Hindi,
Punjabi,
Sanskrit,
Economics,
History,
Political
Science
&
Civics,
Philosophy,
Psychology,
Public
Administration, Sociology, Botany,
Chemistry, Mathematics, Zoology,
Physics,
Statistics,
Geography,
Commerce and Arts & Fine Arts.
4. No Change

<!-- page 7 -->

the Syndicate:
I.
Arabic
II. Persian
III. Urdu
IV. Bengali
V. Tamil
VI. Sindhi
VII. French
VIII. German
IX. Russian & Slovak
X. Tibetan
XI. Music and Dance
XII. Arts & Fine Arts
XIII. to XLVIII

xxx

xxx

XII.
xxx

XIII.

Deleted
to XLVIII xxx xxx

xxx

ITEM 3
Amendment in Regulation 1.3 relating to ‘Chapter VIII (A) Affiliated
Colleges Conditions of Affiliation’ at page 157, Regulation 5.3 at page 159
and Regulations 23.1 and 23.2 of Chapter VIII(C) ‘Affiliated Colleges with
evening classes including conditions for such permission’ at page 165 of
Panjab University Calendar, Volume I, 2007.

1.3

PRESENT REGULATIONS
PROPOSED REGULATIONS
The last date by which the 1.3 No Change
applications should reach the
Registrar of the University shall be
October 1 of the year preceding the
one in which it is proposed to start
the College.
The following fee be fixed for
grant of affiliation to the
Colleges:
(i)

Fee for applications to be
received up to the last
date, i.e.

1st October of the
preceding year for
grant of affiliation,
and

Normal
fee as
prescribed
in the
rules.

(ii) for those received after the
due date but before 10th
January of the following
year, a penalty of Rs. 1
Lac (One Lac) be imposed
upon the College(s).
7

<!-- page 8 -->

5.3 The last date by which the 5.3
applications should reach the
Registrar of the University shall be
as under:

No change

(a) Extension of
affiliation for
a Science
subject-

: November 1 of
the year
preceding the
one in which it
is proposed to
start the
classes.

(a) No Change

(b) Extension of :
affiliation for
a subject other
than Science
subject-

November 1 of
the year
preceding the
one in which it
is proposed to
start the
classes in the
subject.

(b) No Change

Provided that the Syndicate may, No Change
for special reasons, entertain such
applications after the date, if it is
The following fee be fixed for
late not more than 15 days
grant of extension of affiliation to
the Colleges:
(i)

Fee for applications to be
received up to the last date
i.e.
1st November of the Normal
preceding year for fee as
grant of extension prescribed
of affiliation.
in the
rules.

(ii)

for those received after the
due date but before 10th
January of the following
year, a penalty of Rs.1 Lac
(One Lac) be imposed upon
the College(s).
23.1 Application for grant of permission 23.1 No Change
for the evening classes shall reach
the Registrar of the University by
October 1 of the year preceding the
one in which it is proposed to start
the evening classes. Provided that
the Syndicate may, for special
8

<!-- page 9 -->

reasons, entertain an application
after the prescribed date.
The following fee be fixed for
grant of affiliation to the
Colleges:
(i) Fee for applications to be
received up to the last
date i.e.
1st October of the Normal
preceding year for fee as
grant of affiliation, prescribed
and
in the
rules.
(ii) for those received after the
due date but before 10th
January of the following
year, a penalty of Rs.1 Lac
(One Lac) be imposed upon
the College(s).
23.2 The last date by which the 23.2 No Change
applications should reach the
Registrar of the University shall be
as under:
(a) No Change
(a) Extension of : November 1 of
affiliation for
the year
a Science
preceding the
subjectone in which it
is proposed to
start the
classes in the
subject.
(b) Extension of :
November 1 of
(b) No Change
affiliation for
the year
a subject other
preceding the
than Science
one in which it
subjectsis proposed to
start the
classes in the
subject.
Provided that the Syndicate may,
for special reasons, entertain such
applications after the date, if it is
late not more than 15 days.

No Change

The following fee be fixed for
grant of extension of affiliation to
the Colleges:
9

<!-- page 10 -->

(i) Fee for applications to be
received up to the last date
i.e.
1st November of the
preceding year for
grant of extension
of affiliation.

Normal
fee as
prescribed
in
rules
rules.

(ii) for those received after the
due date but before 10th
January of the following
year, a penalty of Rs.1 Lac
(One Lac) be imposed upon
the College(s).
ITEM 4
Amendment in Regulation 1.1 for ‘Doctor of Philosophy in the
Faculty of Business Management & Commerce’ (effective from the year
2007) at page 369 of Panjab University Calendar, Volume II, 2007.
PRESENT REGULATION
PROPOSED REGULATION
1.1 The enrolment to the Doctor of 1.1 The enrolment to the Doctor of
Philosophy
in
Faculty
of
Philosophy
in
Faculty
of
Business
Management
and
Business
Management
and
Commerce shall be open to a
Commerce shall be open to a
candidate who has obtained
candidate who has obtained
Master’s degree with not less
Master’s degree with not less
than 50 per cent marks in the
than 55 per cent marks in the
aggregate
from
Panjab
aggregate
from
Panjab
University or from any other
University or from any other
University (approved by the
University (approved by the
Academic Council) in anyone of
Academic Council) in anyone of
the following subjects:
the following subjects:
(i) to (iv) xxx

xxx

xxx

(i) to (iv) No Change

10

<!-- page 11 -->

ITEM 5
Amendment in Regulation 1.2 for ‘Doctor of Philosophy in the
Faculty of Pharmaceutical Sciences’ (effective from the year 2007)at page
558 of Panjab University Calendar, Volume II, 2007.
PRESENT REGULATION
PROPOSED REGULATION
1.1 A candidate for the degree of 1.1 A candidate for the degree of
Doctor of Philosophy in the
Doctor of Philosophy in the
Faculty
of
Pharmaceutical
Faculty
of
Pharmaceutical
Sciences shall have obtained
Sciences shall have obtained
from this University, the degree
from this University, the degree
of of Master
of
Pharmacy
in
Master
of
Pharmacy
in
Pharmaceutics, Pharmaceutical
Pharmaceutics, Pharmaceutical
Chemistry, Pharmacognosy or
Chemistry, Pharmacognosy or
Pharmacology.
Pharmacology
with
55%
marks.
1.2 The Faculty may, however, allow 1.2 No Change
a person to supplicate for Ph.D.
degree, if he has(a) Graduate in Pharmacy; and

(a)

No Change

(b) Obtained Master’s degree in
a subject related to the
disciplines
stated
in
Regulation 1.1 from another
University/ Institution.

(b) (i) Obtained Master’s degree
with 55% marks in a
subject
related
to
the
disciplines
stated
in
Regulation 1.1 from another
University/Institution.
(ii) the
GATE
qualified
candidates be exempted
from appearing in the
Entrance
Test
for
enrolment to Ph.D. in
Pharmaceutical Sciences.

11

<!-- page 12 -->

ITEM 6
Amendment in Regulations 1, 5.1, 5.2, 5.3 and 12 for B.Sc. Nursing
(Post Basic) (w.e.f. the session July, 2005) at page 529-532 of Panjab
University Calendar, Volume II, 2007.
PRESENT REGULATIONS
PROPOSED REGULATIONS
1. The duration of the course for 1. The duration of the course for the
the degree of B.Sc. Nursing (Post- degree of B.Sc. Nursing (Post-Basic)
Basic) shall be two years. The shall be two years. The examinations
course shall comprise of 4 shall be held in the month of
semesters viz.; First, Second, Third April/May of each year or on such
and Fourth. The examinations for other dates as may be fixed by the
the first and third semesters shall Syndicate. For failed candidates a
be held in the month of supplementary examination shall be
November/December each year or held
in
the
month
of
on such other dates as may be December/January or on such other
fixed by the Syndicate. The dates as may be fixed by the
examinations for the Second and Syndicate.
Fourth semesters shall be held in
April/May or on such other dates
A candidate who does not
as may be fixed by the Syndicate. qualify in all the subjects of First year
For
failed
candidates
a examinations
even
in
the
supplementary examination shall supplementary examinations shall
be held in the month of have
another
chance
of
August/September or on such re-appearing in the subjects along
other dates has may be fixed by with the second year examination.
the Syndicate.
A candidate who does not
qualify in all the subjects of First
and Second semester examination
even
in
the
supplementary
examinations shall have another
chance of re-appearing in the
subjects in which he has failed
along with the third semester
examination.
5.1
A candidate who having
attended the prescribed number of
lectures and practicals, fails to
pass or present himself for the
examination, may be allowed to
appear in the two consecutive
semester examinations. Provided
that a candidate who fails to
qualify in the first/third semester
examination shall be allowed to
continue his studies for the
second/fourth
semester
examination
and
to
appear
simultaneously in the first/third
and
second/fourth
semester
examinations, but his result of the

5.1 A candidate who having attended
the prescribed number of lectures
and practicals, fails to pass or
present himself for the examination,
may be allowed to appear in the two
consecutive semester examinations.
Provided that a candidate who fails to
qualify in the first year examination
shall be allowed to continue his
studies
for
the
second
year
examination, but his/her result of
the second year examination shall be
declared till he qualifies the first year
examination within the required
number of chances.
12

<!-- page 13 -->

second/fourth
semester
examination shall not be declared
till he qualifies the first /third
semester examination within the
required number of chances.
5.2
A candidate who fails in the
first examination (first and second
semester) examinations may be
admitted provisionally to the third
semester class and allowed to
appear in the remaining papers of
first and second semesters (as
allowed
by
Regulation
12)
alongwith the third semester
examination. The result of the
third semester examination shall
not be declared until he passes in
all the subjects of the first
examination. If the candidate does
not clear the first examination
within the number of chances
available to him, his result of third
semester examination shall be
cancelled.

5.2
A candidate who fails in the left
25% subject of first year examination
may be admitted provisionally to the
second year and allowed to appear in
the remaining papers of first year
examinations
(as
allowed
by
Regulation 12) alongwith the second
year examination. The candidate has
to obtained 20% marks either in
theory or practical examination for
getting the compartment in the
subject. The result of second year
examination shall not be declared
until he passes in all the subjects of
the first year examination. If the
candidate does not clear the first year
examination within the number of
chances available to him, his result of
second year examination shall be
cancelled, and the candidate shall
seek re-admission in the Ist year.
5.3 A candidate shall be permitted
to appear in the second year
examination along with reappear
subjects of Ist year.

5.3
A candidate will not be
permitted to appear in the fourth
semester examination until he has
passed in all the subjects of first
and
second
semester
examinations.
12.
A candidate who obtains 12. A candidate shall be given
pass marks in any subject shall be
provisional admission in 2nd year,
exempted from reappearing in that
which shall be finalized on
successful completion of the Ist
subject
provided
the
whole
semester examination is completed
year or at least 75% of the
within four consecutive chances
subjects. Candidate shall be
including the one in which the
allowed to take supplementary
candidate was due to appear for
examinations.
the first time. Such a candidate
will be allowed to join the next
semester class and will be allowed
to take examination in the reappear subject/s along with the
next semester examination. A
candidate who does not pass any
semester examination in full
within the prescribed period shall
neither be permitted to prosecute
his studies not allowed to appear
in the examination.
13

<!-- page 14 -->

ITEM 7
Addition in Regulation 4.1 for ‘B.A./B.Sc. (General and Honours)
examinations’ (effective from the session 2005-06) at page 40 of Panjab
University Calendar, Volume II, 2007.
PRESENT REGULATION
4.1
A person who has passed one
of the following examinations with
English as one of the subjects shall
be eligible to join the First Year class
of B.A. or B.Sc (General and
Honours ) degree course in college
affiliated to this University
(i)

(ii)

(iii)

4.1

PROPOSED REGULATION
No change

B.A./B.Sc./B.Com Part I (Old (i) No change
Scheme) Pre – Medical /Pre –
Engg./
Intermediate Arts/
Science/Agriculture
examination
of
Panjab
University;
the +2 examination under (ii) No change
10+2+3 system of education of
recognized
University/
Board/Council;
Shastri/Vishard
Any
other
examination (iii) Prak
recognized by the University
examination
with
as equivalent to (i) and (ii)
Compulsory English.
above.
(iv)

Any
other
examination
recognized by the University
as equivalent to (i), (ii)
and (iii) above.

ITEM 8
Regulations for the Post-M.A. Diploma Courses in Professional
Counselling and Psychotherapy (One year – Annual System); and PostM.A. Diploma Courses in Psychological Testing (one year – Annual
System). (effective from the session 2007-08).
1.

The duration of the course is one year (annual system). The
examination shall ordinarily be held in August on such dates as may
be fixed by the Syndicate from time to time.

2.

The minimum qualification for admission to this course is M.A.
(Psychology) 55% marks.

3.

The examination shall be open to a candidate who possesses the
qualification as laid down in Regulation 2 and produces the following
certificates signed by the Chairperson/Principal of the affiliated
colleges.
14

<!-- page 15 -->

a) of having been on the rolls of the Department/Colleges for the
course during the academic year preceding the examination.
b) of having obtained not less than 50% marks of the total
aggregate of the sessional work in the practical papers.
c) of having a good character.
d) of having attended not less than 75% lectures.
4.

The candidate should have attended at least 75% of the lectures
delivered in each subject in which he/she is to be examined and of
having obtained at least 35% marks in theory and practical
separately in each subject. The candidates are also required to fulfil
the condition of 75% attendance in the field work in addition to
submission of report of field work duly signed by the coordinator of
the institute where field work was undertaken.

5.

Deficiency in the required number of lectures may be condoned:
i)

ii)

6.

a)
b)

7.

a)

b)

upto 10% of the total lectures delivered by the Chairperson of
the Department/Principal of the college as the case may be
and;
upto additional 5% of the total lectures delivered, by the Dean
of University Instruction on the recommendations of the
Chairperson of the Department/Principal of the colleges as the
case may be.
The examination fee and enrolment fee shall be decided by the
Syndicate/Senate from time to time.
The amount of admission fee and other charges shall be as
decided by the Syndicate/Senate from time to time.
Minimum marks required to pass the examination shall be
35% in each theory paper and practical paper separately and
aggregate of 40% of all the marks.
The assessment of the projects will be external. The project not
duly signed by the teacher shall not be evaluated by the
external examiner.

8.

A student, who, having attended the prescribed number of lectures
does not appear in the examination or having appeared has failed,
may be permitted on the recommendation of the Chairperson of the
Department/Principal of the college to appear in the examination as
a late college student/within a period of 3 years of the completion of
the course.

9.

The medium of examination shall be English.

10.

The successful candidates shall be classified as under:
70% and above
:
Distinction
60% and above
:
First Division
50% and above
:
Second Division
Below 50%
:
Third Division
………………..
15

<!-- page 16 -->

ITEM 9
Regulations for Advanced Diploma in Child Guidance and Family
Counselling (effective from the session 2007-08).
1.1

The duration of the course of instruction for the Advanced Diploma
in Child Guidance and Family Counselling shall be one academic
year (nine months of teaching followed by three months of
internship/placement in agencies).

1.2

The examination shall ordinarily be held in the month of April or on
such dates as may be fixed by the Syndicate.

2.

The last date for receipt of examination/admission forms with and
without late fee will be fixed by the Syndicate.

3.

The admission to the course shall be open to the following
candidates:
Candidates having B.Sc. Home Science or B.A. with
Psychology/Education/Sociology/Home Science/Social Work as
one of the subjects with two years experience of working with
children; or
Graduate candidates having B.Ed. degree with one year
experience of working with children; or
Candidates having M.Sc./M.A. in Human Development and
Family
studies/Child
Development/Psychology/Education/
Sociology/Social Work.

4.1

Admission to the Diploma course will be on the basis of academic
qualification/experience, and interview with the candidate.

4.2

The distribution of marks for merit list will be as – 75% for the marks
achieved in academics, 10% for the interview, and 15% weightage for
additional higher qualifications (M.Phil., Ph.D.) in the related subject,
and experience of working with children.

5.

Candidates from other Universities seeking admission in the Diploma
shall submit migration certificate at the time of admission.

6.

Every student admitted to the diploma will be on the rolls of the
Department of Child Development, Government Home Science
College and shall pay fee(s) to the University as the Syndicate may
prescribe from time to time.

7.

The examination fee to be paid by the candidate shall be as
prescribed from time to time.

8.

Every candidate shall be examined in the subject as laid down in the
syllabus, prescribed from time to time.
16

<!-- page 17 -->

9.

The medium of examination shall be English.

10.

The candidate shall have 75% attendance in theory and 90%
attendance in Practical.

11.

The minimum number of marks required to pass the examinations
shall be 40% in theory and 50% in practical, with scope for one
percent as grace in each subject.

12.

One chance within six months of declaration of results will be given
to the candidate for improvement of performance/division.

13.

Successful candidates securing 60% or more of the aggregate
number of marks shall be placed in the first division, those who
secure 50% or more but less than 60% shall be placed in the second
division, and those who secure less than 50 percent shall be placed
in the third division.

14.

Four weeks after the termination of the examination or as soon
thereafter as possible, the Controller of Examinations shall publish a
list of candidates who have passed, showing the division in which
they have passed.

15.

Each successful candidate shall be granted an Advanced Diploma in
Child Guidance and Family Counselling showing the division in
which she/he has passed.

……………

17

<!-- page 18 -->

ITEM 10
Addition to Regulation 2.1 for M.Sc. (Honours School) (Annual
System) at page 117 of Panjab University Calendar Volume II, 2007
(effective from the session 2006-07).
PRESENT REGULATION
PROPOSED REGULATION
2.1 A person who has passed one 2.1 A person who has passed one of
of the following examinations
the following examinations in the
in the concerned subject may
concerned
subject
may
be
be admitted to the M.Sc.
admitted to the M.Sc. (Honours
(Honours School) course:
School) course:
(i) to (iv) xxx

xxx

xxx

(i) to (iv) No Change
(v)B.A./B.Sc.
(General)
with
Mathematics from the Colleges
affiliated to this University or
from other Universities as
recognized by this University on
the basis of marks obtained in
the Entrance Test to be
conducted
by
Panjab
University, Chandigarh and
merit in the qualifying degree
course with weightage
of
50:50.
The
criteria
for
determining the weightage of
qualifying examination will be
as per University Rules. These
students would be admitted in
M.Sc. (Honours School) in
Mathematics in addition to the
students of B.Sc. (Honours
School) in the subject of
Mathematics & B.Sc. (Honours
School) in the subject of
Mathematics & Computing of
the
Department
of
Mathematics,
Panjab
University, Chandigarh.

ITEM 11
Addition of nomenclature of Postgraduate Diploma in Human Rights
and Duties (through Correspondence Studies) (effective from the session
2006-07) at page 312 of Panjab University Calendar, Volume II, 2007. The
Rules and Regulations for Postgraduate Diploma in Human Rights and
Duties be the same as for other Postgraduate Diploma Courses.

18

<!-- page 19 -->

ITEM 12
Regulations for MBA (Biotechnology) (Two-year) (Semester
System) (effective from the session 2007-08) at the Centre for
Emerging Areas in Science and Technology.
1.
The duration of the course leading to the degree of Master of
Business Administration (M.B.A.) shall be two academic years. Each year
shall be divided into two semesters. The examination for the first and the
third semesters shall ordinarily be held in the month of December and for
the second and the fourth semesters in the month of April/May, or on such
dates as may be fixed by the Syndicate.
2.1 Every candidate shall pay his examination fee for each semester at
the time of admission to the course, along with other charges, i.e. tuition
fee etc.
2.2 The Head of University Business School shall forward to the
Controller of Examinations at least five weeks before the commencement of
the examination for each semester, a list of the students who have satisfied
the requirements of regulations and are qualified to appear in the
examination.
2.3 The last date for receipt of admission application form and fee with
and without late fee shall be as fixed by the Syndicate.
3.
The minimum qualification for admission to the first semester of the
course shall beA Bachelor’s or Master’s degree in Biological Sciences, i.e. Biology,
Botany, Microbiology, Zoology, Biochemistry, Biophysics, Genetics,
Pharmacy,
Biotechnology,
Veterinary
Sciences,
B.E/B.Tech,
(Biotechnology), B.Sc. (Bioinformatics), MBBS, BDS and BE (Informatics) of
a University recognized by the association of Indian Universities with not
less than 50% marks in the aggregate. Candidates appearing in the Final
Degree Examination are eligible to apply and can take the test
provisionally.
4.
Every candidate shall be examined in the subjects as laid down in
the syllabus prescribed from time to time.
50% marks in each paper excluding seminar, project and viva voce
shall be assigned for internal assessment.
Seminar, Project and Workshop will be assessed internally on 100%
basis. Viva voce shall be conducted jointly by the internal and external
examinations.
The Head of the University Business School shall forward these
marks on the basis of periodical tests, written assignment, case
discussions, Syndicate sessions, field trips etc., to the Controller of
19

<!-- page 20 -->

Examinations at least two weeks before the commencement of the
examination.
5.
The Head of the University Business School will preserve the records
on the basis of which the internal assessment awards have been prepared
for inspection, if needed by the University, up to six months from the date
of declaration of the results.
Project reports shall be submitted to the Head of the University
Business School at least ten days before the commencement of the
examination. Reports received after the prescribed date shall not be
accepted.
6.1 The First Semester examination shall be open to a regular student
who(i)

has been on the rolls of the University Business School
during one semester preceding the first semester
examination; and

(ii)

has attended not less than 75% of the lectures,
seminars, case discussion, Syndicate sessions, field
trips, project work etc., in each paper; a deficiency up to
10% may be condoned by the Head of the University
Business School.

6.2 The Second, Third or Fourth semester examinations shall be open to
a student who(i)

(ii)

(iii)

has been on the rolls of the University Business School
during one semester preceding the second, third, fourth,
fifth and sixth semester examination, as the case may be;
has attended not less than 75% of the lectures, seminars,
case discussion , Syndicate sessions, field trips, project
work etc., in each paper, a deficiency up to 10% may be
conducted by the Head of the University Business School;
and
has passed the first, second, third semester examinations
respectively or is covered under reappear Regulation 9,
below.

7.

The medium of instruction and examination shall be English.

8.1

The minimum number of marks to pass the examination in each
semester shall be(i)
35% in each paper in the University examination
separately as well as jointly with internal assessment.
(ii)
35% in seminar, project and viva voce.
(ii)

50% in the aggregate of (i) and (ii) above.

20

<!-- page 21 -->

8.2 Grace marks shall be given at the rate of 1% of the aggregate marks
of the University examination for each semester. A candidate may avail of
the grace marks either in the aggregate or in one or more papers as may be
to his advantage. Grace marks, shall, however be given only for passing the
examination or for earning the higher division and not for passing the
examination with distinction.
9.(a) A candidate who fails in the first or third semester but has secured at
least 35% marks separately as well as jointly with internal
assessment in not less than 50% of the papers prescribed for that
semester shall be permitted to continue his studies for the second
and the fourth semester respectively but he will be required 10
reappear in the next April/May examination in such paper i.e. which
he had failed in the December examination simultaneously with the
second or the fourth semester examination as the case may be.
A candidate on reappearing shall pay admission fee per paper in each
semester examination subject to a maximum fee as prescribed for the
examination concerned and the admission fee for reappear would be
in addition to the admission fee charged for other semester
examination, if any, in which he was appearing.
If he fails to pass the first or the third semester examination even
after the second attempt his result for the second or the fourth
semester examination, as the case may be, shall be cancelled and he
will be required to leave the course.
(b)

A candidate who fails in the second semester but had secured at
least 35% marks separately as well as jointly with internal
assessment in not less than 50% of the papers prescribed for that
semester shall be permitted to continue his studies in the third
semester but he will be required to reappear in such papers in which
he had failed in the April examination in a special examination to be
held in August but not before the expiry of six weeks from the date of
declaration of the April examination result. If he fails even in the
special examination, he shall be required to leave the course.

(c)

A candidate who fails in the fourth semester examination but had
secured at least 35% marks separately as well as jointly with internal
assessment in not less than 50% papers prescribed for that semester
shall be allowed to reappear in such papers in which he has failed in
the April examination in a special examination to be held in August
but not before the expiry of six weeks from the date of the declaration
of the result.
Explanation:- Fifty per cent of 5 papers will be taken as 2 and that
of 7 papers as 3 for purpose or exemption under this
regulation.

d)

A candidate who fails to clear the fourth semester examination even
in the special examination held in August shall be given one more
chance. He may appear either in December of the same year or in
21

<!-- page 22 -->

April examination next year in such papers in which he had failed in
the special examination held in August.
A candidate who is unable to clear the fourth semester examination
even after availing of the second chance as specified above shall be
required to leave the course.
(e)

If a candidate is required to reappear in a paper which is 100%
internal assessment, he will be given one more opportunity to
quality in that paper without attending a fresh course of lectures.
The work assignment may be determined by the Head of the
University Business School.

10. A candidate who fails in the First, Second, Third or Fourth semester
and is not covered under ‘Reappear’ Regulation 9 may be given one more
chance and allowed to appear in the next regular examination without
attending a fresh course of lectures but he will have to repeat the entire
examination.
If a candidate fails to pass in a semester examination even after the
second attempt he will be required to leave the course.
11. A candidate, who having passed the second semester examination,
discontinues his studies, may be permitted to join the 3rd semester within
two years of his passing the second semester examination.
12. The internal assessment awards of a candidate who fails in the
examination shall be carried forward to the next examination.
A candidate who fails in the examination may appear in the next
consecutive examination as an ex-student.
13. As soon as is possible after the termination of the examination, the
Controller of Examinations shall publish list of the candidates who have
passed.
14.

Successful candidates shall be classified as under:
(i)

Those who obtain 75% or more
:
of the total aggregate marks in
all the semester examination
taken together.
(ii) Those who obtain 60% or more
:
of the aggregate marks but less
than 75% marks in all the
semester examinations taken
together.
:
(iii) Those who obtain below 60% of
the aggregate marks in all the
semester examinations taken
together.
...........................
22

First Division with
Distinction

First Division

Second Division

<!-- page 23 -->

ITEM 13
Regulations for Master of Business Economics
(Semester System) (effective from the session 2006-07).

(M.B.E.)

1.

The duration of the course leading to the degree of Master of
Business Economics (MBE) shall be two academic years. Each year
shall be divided into two semesters. The examination for the first and
third semesters shall ordinarily be held in the month of
November/December and for the second and the fourth semesters in
the month of April/May, or on such dates as may be fixed by the
Syndicate.

2.1

Every candidate shall pay his examination fee for each Semester at
the time of admission to the course, along with other charges, i.e.,
tuition fee etc.

2.2

The Head of University Business School/Principal of the College shall
forward to the Controller of Examinations at least five weeks before
the commencement of the examination for each semester, a list of
the students who have satisfied the requirements of regulations and
are qualified to appear in the examination.

2.3

The last date for receipt of admission application form and fee with
and without late fee shall be fixed by the Syndicate.

3.

The minimum qualification for admission to the first semester of the
course shall bea)

(i)

(ii)

b)
4.

A Bachelor’s/Master’s degree in any discipline of
the University or a Degree of any other University
which has been recognized by the Syndicate as
equivalent thereto with not less than 50% marks
in the aggregate.
Or
pass in the final examination conducted by (a) The
Institute of Charted Accountants of India, (b) The
Institute of Cost and Works Accountants of India
and (c) The Institute of Company secretaries of
India.

The admission to this course shall be on the basis of a
Common Entrance Test

Every candidate shall be examined in the subjects as laid down in
the syllabus prescribed from time to time.
20% marks in each paper, excluding seminar, Project, workshop
and viva voce, shall be assigned for internal assessment.
Seminar, Project, workshop shall be assessed internally on 100%
basis, and viva voce shall be conducted jointly by the internal and
external examiners.
The Head/Principal of the college shall forward internal assessment
on the basis of periodical tests, written assignments, case
23

<!-- page 24 -->

discussions, syndicate sessions, field trips etc., to the Controller of
Examinations at least two weeks before the commencement of the
examination.
5.

The Head/Principal shall preserve the records on the basis of which
the internal assessment awards have been prepared for inspection
up to six months from the date of declaration of the results.
Project reports shall be submitted to the Head of University
Business School/Head of Department of Commerce/Economics of
the College at least ten days before the commencement of the
examination. Reports received after the prescribed date shall not be
accepted.

6.1

The First Semester examination shall be open to a regular student
who(a) has been on the rolls of the University Business
School/College during one semester preceding the first
semester examination; and
(b) has attended not less than 75% of the lectures, seminars,
case discussions, syndicate sessions, field trips, project
work etc., in each paper, a deficiency up to 10% may be
condoned by the Head/Principal.

6.2
The Second, Third and Fourth semester examination shall be open
to a student who(i) has been on the rolls of the University Business
School/College during one semester preceding the second,
third and fourth semester examination, as the case may
be;
(ii) has attended not less than 75% of lectures, seminars,
case discussions, syndicate sessions, field trips, project
work etc., in each paper, a deficiency up to 10% may be
condoned by the Head/Principal; and
(iii) has passed the first, second, third, semester examinations
respectively or is covered under reappear Regulation 9,
below.
7.

The medium of instruction and examination shall
be English.

8.1

The minimum number of marks to pass the examination in each
semester shall be(i)
(ii)
(iii)

35% in each paper in the University examination separately as
well as jointly with internal assessment;
35% in seminar, project, workshop, and viva voce; and
40% in the aggregate of (i) and (ii) above.

24

<!-- page 25 -->

8.2

Grace marks shall be given at the rate of one percent of the aggregate
marks of the University examination for each semester. A candidate
may avail himself/herself of the grace marks either in the aggregate
or in one or more papers as may be to his advantage. Grace marks
shall, however, be given only for passing the examination or for
earning the higher division and not for passing the examination with
distinction.

9.(i)

A candidate who fails in the first or third semester but has secured
at least 35% marks separately as well as jointly with internal
assessment in not less than 50% of the papers prescribed for that
semester shall be permitted to continue his studies for the second
and the fourth semester respectively but he will be required to
reappear in the next April/May examination in such paper(s), i.e. in
which he had failed in the November/December examination,
simultaneously with the second or fourth semester examination as
the case may be.
A candidate on reappearing shall pay examination fee per paper in
each semester examination subject to a maximum fee as prescribed
for the examination concerned and the examination fee for reappear
would be in addition to the examination fee charged for other
semester examination, if any, in which he is appearing.
If he fails to pass the first or third semester examination even after
the second attempt, his result for the second or fourth semester
examination shall be cancelled and he shall be required to leave the
course.

(ii)

A candidate who fails in the second semester but had secured at
least 35% marks separately as well as jointly with internal
assessment in not less than 50% of the papers prescribed for that
semester shall be permitted to continue his studies for the third
semester but he will be required to reappear
in the next
November/December in such paper(s) in which he had failed in the
April/May examination simultaneously, with the third semester
examination.
If he fails to pass the second semester examination even after the
second attempt, his result for the third semester examination shall
be cancelled and he shall be required to leave the course.

(iii) A candidate who fails in the fourth semester examination but had
secured at least 35% marks separately as well as jointly with internal
assessment in not less than 50% papers prescribed for that semester
shall be allowed to reappear in such paper(s) in which he has failed
in the April/May examination in a special examination to be held in
August but not before the expiry or six weeks from the date of the
declaration of the Result.

25

<!-- page 26 -->

Explanation:- fifty per cent of 5 papers will be taken as 2 and
that of 7 papers as 3 for purpose of exemption under this
Regulation.
iv)

A candidate who fails to clear the fourth semester examination even
in the special examination held in August shall be given one more
chance. He may appear either in November/December of the same
year or April/May examination next year in such papers in which
he had failed in the special examination held in August. A candidate
who still is not able to clear the fourth semester examination shall
be required to leave the course.

v)

If a candidate fails in Seminar, Project, workshop or Viva voce
examination, he will be given one more opportunity to qualify in
that paper without attending a fresh course of lectures. The work
assignment may be determined by the Chairman of University
Business School/Head, Department of Commerce of the College.

10.

A candidate who fails in the First, Second, Third or Fourth semester
and is not covered under ‘Reappear’ Regulation 9 shall be given one
more chance and allowed to appear in the next regular examination
without attending a fresh course of lectures but he will have to
repeat the entire examination. If a candidate fails to pass in a
semester examination, even after the second attempt he shall be
required to leave the course.

11.

A candidate, who having passed the second semester examination
discontinues studies, may be permitted to join the third semester
within two years of his passing the second semester examination.

12.

The internal assessment awards of a candidate who fails in the
examination shall be carried forward to the next examination.
A candidate who fails in the examination may appear in the next
consecutive examinations as ex-student.

13.

As soon as possible, after the termination of the examination, the
Controller of Examinations shall publish a list of the candidates
who have passed.

14.

Successful candidate shall be classified as under:
i)

Those who obtain 75% or more of the
total aggregate marks in all the
semester examinations taken together
ii) Those who obtain 60% or more of the
total aggregate marks but less than
75% marks in all the semester
examinations taken together
iii) Those who obtain 50% or more of the
total aggregate marks but less than
60% marks in all the semester
examinations taken together
iv) Those who obtain less than 50% of the
26

:

First division with
Distinction

:

First Division

:

Second Division

:

Third Division

<!-- page 27 -->

marks but not less than 40% marks in
all the semester examinations taken
together.
…………

27

<!-- page 28 -->

ITEM 14
Regulations for B.Sc. (Fashion Design) (effective from the
session 2006).
1.1

The duration of the course for the degree of B.Sc. (Fashion Design)
(Pass) shall be three years and the examination shall be held in three
parts, viz, Part –I at the end of the course of the First year, Part-II at
the end of the course of the second year and Part-III (Final) at the
end of the course of the third year.
These examinations shall ordinarily be held once a year in April on
such dates as are fixed by the Syndicate.
For candidates placed in compartment, a supplementary
examination shall ordinarily be held in the month of September on a
date fixed by the Syndicate.

1.2

The last date for receipt of admission form and fee without and with
late fee, as fixed by the Syndicate/Senate shall be notified by the
Controller of Examinations, to all the affiliated Colleges.

2.1.

Admission to First Year of B.Sc. (Fashion Design) shall be open to
candidates with at least 50% marks in 10+2 examination from
C.B.S.E./Punjab School Education Board or any other examination
recognized by the University as equivalent thereto.
The mode of admission shall be decided by the Syndicate from time
to time.

2.2.

A person who has passed the First Year (Part I) examination for the
degree of B.Sc. in Fashion Design of the Panjab University shall be
eligible to join the Second Year (Part II) class of B.Sc. (Fashion
Design).
A person who has passed B.Sc. (Fashion Design) Part-I examination
from another University whose B.Sc. (Fashion Design) (Part-I)
examination has been recognized as equivalent to B.Sc. (Fashion
Design) (Part-I) examination of this University, shall be eligible to join
B.Sc. (Fashion Design) Part II class at this University provided the
subjects passed in B.Sc. (Fashion Design) Part-I examination at the
other University were equivalent to be the same as are available at
this University The marks obtained in B.Sc. (Fashion Design)
(Part-I) examination of the other University shall be counted towards
division by increasing or reducing the marks obtained
proportionately in accordance with the maximum marks prescribed
for Part I examination by this University.

2.4

A person who has passed the Second Year (Part II) examination for
the degree of B.Sc. (Fashion Design) of the Panjab University shall be
eligible to join Part III (Final) class of B.Sc. (Fashion Design).

28

<!-- page 29 -->

3.1

The examination in Part-I/II/III, as the case may be, shall be open to
a student who(a)
has passed/completed the prescribed number of lectures not
less than one academic year previously the requisite
examination as laid down in Regulations 2.1 to 2.3 above.
(b)

Has his/her name submitted to the Controller of
Examinations, by the Principal of the College she/he has most
recently attended and produced the following certificates
signed by the Principal of the College;
(i)
(ii)
(iii)

(iv)

of good character;
of having been on the rolls of an affiliated college for
the academic year preceding the examination;
of having attended not less than 75% of the lectures
delivered and practicals held for each of the subjects
in which she/he is to be examined;
of having obtained at least 25% marks in the
aggregate of all the subjects to be calculated on the
combined results of two house examinations, the
first to be held in September and the second in
December.

Provided that a candidate must appear in Part –II/III examination
within three years of his/her passing part-I/II examination, as the
case may be.
3.2

A candidate who, having attended the prescribed number of lectures
and practicals, fails to pass or present herself/himself for the
examination may be allowed to appear in the examinations on
recommendations of the Principals, without attending a fresh course
of lectures etc. as a late college student, as follows:
First year within next two consecutive years.
Second year within next two consecutive years.
Third year within next three consecutive years.

4.

The Principal of a college is empowered to condone shortage in
attendance in lectures and practicals upto fifteen lectures in each of
the subjects and seven periods in each of the practicals.

5.

The amount of examination fee to be paid by a candidate for each
Part shall be prescribed by the Syndicate/Senate from time to time.

6.

The medium of instruction and examination shall be English.

7.

Every candidate shall be examined in the subjects and the syllabus
prescribed by the Senate.

8.

The minimum number of marks required to pass the examination
shall be:
(a)35% in each written paper and practical examination
separately;
29

<!-- page 30 -->

(b) 35% separately in theory and practiclas of each subject in the
Internal Assessment based on the class work, Home Work,
sessional records and house examinations;
(c) 40% of the aggregate of all subjects.
9.

The College shall submit to the University, on the prescribed
proforma, internal assessment marks at least 10 days before the
commencement of the examination.

10.1 A candidate who obtains 40% of the aggregate marks for the
examinations, but fails in one subject obtaining not less than 25%
marks in that subject, may be permitted to appear in the said subject
at the next supplementary examination to be held in the September of
the same year, and if he/she passes in the subject, he/she shall be
deemed to have passed the examination.
10.2 A candidate to whom the concession is granted shall be eligible to
join the next higher class provisionally but if she/he fails to qualify
in the compartment subject in the supplementary examination,
she/he shall be permitted to appear again in that subject along with
the examination for the next part in the next annual examination
and if he/she fails to qualify in the compartment subject even at the
second attempt, his/her result of part-II or Part –III as the case may
be, shall be cancelled. For the compartment subject of the next
annual examination he/she may appear as a regular student or as a
late College student.
10.3 A candidate who appears in the supplementary examination under
this Regulation shall(a)
(b)

be required to pay the examination fee as for the whole
examination, and
not be eligible for scholarship, prize or a medal.

11.1

As soon as possible after the examination, the Controller of
Examinations shall publish a list of candidates who have passed the
examination.

11.2

The successful candidates shall be classified, as under on the
aggregate of marks obtained in the Parts-I, II and (Final)
examination taken together.
(a) Those who obtain 60% or more of the
aggregate marks.

:

First Division

(b) Those who obtain 50% or more but
less than 60% of the aggregate marks.

:

Second Division

(c) Those who obtain less than 50% of
the aggregate marks.

:

Third Division

30

<!-- page 31 -->

11.3

Each successful candidate shall be awarded a degree showing the
division in which he/she has passed, provided he/she submits a
certificate to the effect that she/he had undergone Internship for a
minimum period of four weeks, showing the division in which
she/he has passed Marks obtained in each subject shall also be
supplied to each candidate.
………

ITEM 15
Introduction of Semester System in M.A. (Economics) in place of
Annual System in the Department of Economics, (effective from the
academic session of 2008-09). The Rules/Regulations for the above said
course would be the same as for other Semester System appearing at
page 90-94 of Panjab University Calendar Volume II, 2007.
ITEM 16
Amendment of Regulation 3.1 for B.C.A course at page 52 of Panjab
University Calendar, Volume II, 2007 (effective from the session 2008-09).
PRESENT REGULATION

PROPOSED REGULATION

3.1 A person who has passed one of 3.1
the following examinations shall
be eligible to join the first year
class of B.C.A. course.
(i)

(ii)

+2 examination in any
discipline with at least 50%
marks
and
passed
Mathematics as one of the
subject at Matriculation
level;
OR
Any
other examination
recognized by the Syndicate
as equivalent to (i).

(i)

No Change

No Change

OR
(ii)

No Change

(iii) The students who are
placed
under
compartment
at
+2
examination
in
the
Annual Examination and
cleared the compartment
examination up to the
last date of admission of
B.C.A. course in the
Colleges
be
allowed
admission as per merit
and other conditions for
admission
to
B.C.A.
course.
31

<!-- page 32 -->

ITEM 17
Amendment of Regulation 3.1 for B.B.A course at page 332 of Panjab
University Calendar, Volume II, 2007 (effective from the session 2008-09).
PRESENT REGULATION

PROPOSED REGULATION

3.1 The admission to the 1st year of 3.1
the course shall be open to a
person who has passed:(i) 10+2 examination from a
recognized
Board/University with at
least 50% marks.
OR
(ii) any other examination with
50% marks recognized by
the Syndicate as equivalent
to (i).

32

No Change

(i)

No Change
OR

(ii)

No Change

(iii) The students who are
placed
under
compartment
at
+2
examination
in
the
Annual Examination and
cleared
the
compartment
examination up to the
last date of admission of
B.B.A. course in the
Colleges
be
allowed
admission as per merit
and other conditions for
admission
to
B.B.A.
course.

<!-- page 33 -->

ITEM 18
Amendment of Regulation 1(a) for Doctor of Philosophy in the Faculty
of Engineering & Technology at page 444 of Panjab University Calendar,
Volume II, 2007.
PRESENT REGULATION

PROPOSED REGULATION

1. Every candidate for the degree of 1. Every candidate for the degree
of Doctor of Philosophy in
Doctor
of
Philosophy
in
Engineering
&
Technology
Engineering & Technology shall be
shall be required to:
required to:
(a) produce a certificate that he has
taken the Master of Engineering
degree of this University or
(subject to the sanction of the
research Board in Engineering) of
any other University, whose
degree is recognized as equivalent
to the Master of Engineering
degree of this University or has
passed any other equivalent
examination;

xxx

xxx

xxx

(a) produce a certificate that
he has taken the Master of
Engineering degree with
55%
marks
of
this
University or (subject to the
sanction of the research
Board in Engineering) of
any other University, whose
degree is recognized as
equivalent to the Master of
Engineering degree of this
University or has passed
any
other
equivalent
examination
xxx

xxx

xxx

ITEM 19
Amendment of Regulation 1 for Degree of Doctor of Philosophy in the
Faculty of Law at page 402 of Panjab University Calendar, Volume II, 2007.
PRESENT REGULATION

PROPOSED REGULATION

1. A candidate for the degree of Doctor 1. A candidate for the degree of
of Philosophy (Ph.D.) in the Faculty
Doctor of Philosophy (Ph.D.) in
of Law should have obtained
the Faculty of Law should have
Master’s degree in Law (securing
obtained Master’s degree in Law
ordinarily 50% marks) from the
(securing
ordinarily
55%
Panjab University or from any other
marks)
from
the
Panjab
University
whose
degree
is
University or from any other
recognised as equivalent to that of
University whose degree is
the Panjab University.
recognised as equivalent to that
of the Panjab University.
xxx
xxx
xxx
xxx
xxx
xxx

33

<!-- page 34 -->

ITEM 20
Amendment of Regulation 1.1 for Ph.D. Degree in the Faculty of
Medical Sciences at page 508 of Panjab University Calendar, Volume II,
2007.
PRESENT REGULATION
1.1.

PROPOSED REGULATION

A candidate for the degree of 1.1 A candidate for the degree of
doctor of Philosophy in the
doctor of Philosophy in the
Faculty of Medical Sciences
Faculty of Medical Sciences
with 55% marks shall have
shall have obtained from this
University, the degree of:obtained from this University,
the degree of:
(i)

Bachelor of Medicine and
Bachelor of Surgery for
Ph.D.
in
Medical
Subjects;
OR
(ii) Master of Pharmacy for
Ph.D.
in
Pharmacy
subjects;
(iii) M.Sc. in subjects such as
Microbiology, Pathology,
Pharmacology,
Biochemistry,
Bio-Physics,
physiology and Anatomy
or any subject approved
for the purpose by the
University;
(iv) M.D. or M.S. or M.R.C.P.
or F.R.C.S, as the case
may be for Ph.D. in
Clinical Sciences.

34

(i) to (iv) No Change

<!-- page 35 -->

ITEM 21
Amendment of Regulation 1.2 for ‘Master of Arts (Education)’ at page
314 of Panjab University Calendar, Volume II, 2007.
PRESENT REGULATION
PROPOSED REGULATION
No Change
1.2 A person who has passed one of 1.2
the following examinations from
this University or from any
other
University
whose
examination
has
been
recognized as equivalent to the
corresponding examination of
this University shall be eligible
to join the First Year (Part I)
class of the M.A. course.
(i) A graduate with Honours in
Education;
(ii)

(i) For Indian Nationals:
A
Graduate
in
any
discipline/stream with 50%
marks from recognized Indian
Universities with B.Ed.

A graduate (Pass) with at
least
45%
marks
in
Education;

OR

(iii) A graduate with Honours
in Philosophy or Sociology
or Psychology with 45%
marks in aggregate or
Postgraduate
in
these
subjects;

The students who have
studied
Education;
or
Philosophy; or Psychology; or
Sociology as an elective
subject or Honours course at
first or second degree level
with 50% marks.

(iv) A graduate with 50% marks
in aggregate in the subjects
other than the above;
(ii)
(v) A graduate with B.Ed.
(vi) Any
other
examination
recognized by the University
as equivalent to (i) to (v)
above.

35

A student having 50%
marks in the qualifying
examination or equivalent
grade
from
foreign
University having equivalent
graduate degree certified by
the Association of Indian
Universities (AIU).

<!-- page 36 -->

ITEM 22
Amendment of Regulation 2 for ‘Postgraduate Diploma in Fashion
Designing’ at page 107 of Panjab University Calendar, Volume II, 2007,
(effective from the session 2007-08).
PRESENT REGULATION
2.

PROPOSED REGULATION

A person who possesses one of 2.
the following qualifications shall
be eligible to join the course:
(i) B.Sc. Home science from the
Panjab University with at least
50% of the aggregate marks;
(ii) Any
other
examination
recognised by the Syndicate,
as equivalent to (i) with
clothing & Textiles (Practical)
as one of the subjects;
(iii)

B.A. with Home science as
one of the subjects (with
Clothing
&
Textiles
Parctical)

No Change

(i)

B.Sc. (Home Science);
OR

(ii)

B.A. (Honours) in
Home Science;
OR

(iii)

B.A. with Home
Science as one of the
Elective subject;
OR

36

(iv)

B.A.
with
Course
in
Designing;
OR

Add-onFashion

(v)

Graduate
in
any
stream with vocational
stream
in
Fashion
Designing
at
10+2
level;
OR

(vi)

Graduate
with
Diploma in Cutting
and Tailoring
from
I.T.I. & C.C.I.

<!-- page 37 -->

ITEM 23
Amendment of Regulation 7 for M.C.A course at page 162 of Panjab
University Calendar, Volume II, 2007, (effective from the session 2008-09).
PRESENT REGULATION
7.

PROPOSED REGULATION

The minimum percentage of 7. No Change
marks required to appear in
and pass the First, Second,
Third, Fourth, Fifth and Sixth
Semester examinations shall be
as follows in each case:(i) 40 percent in the internal
assessment part of every
subject separately of the
examination,
whether
theory
or
practical
(including project work,
etc.) as a prerequisite to
appear in the first, Second,
Third, fourth, fifth and
Sixth
semester
examinations, and

(i) 40 percent in the internal
assessment and University
examination (theory) part
of every subject separately
of
the
examination,
whether theory or practical
(including project work,
etc.) as a prerequisite to
appear in the First, Second,
Third, Fourth, Fifth and
Sixth
Semester
examinations; and

(ii) to (iii) xxx

(ii)

xxx

xxx

to (iii) No Change

ITEM 24
Change in nomenclature of Bachelor of Physical Education
(B.P.Ed,) Four-Year Professional Programme be changed to that of
Bachelor of Physical Education (B.P.Ed.)-a Four-Year Integrated
Programme (effective from the session 2008-09).

37

<!-- page 38 -->

ITEM 25
Regulations for Postgraduate Diploma in Disaster Management
and Security (PGDDMS) (One-year Semester system) introduced at the
Centre for Defence & National Security Studies (effective from the academic
session 2008-09).

1.1

The duration of the course shall be of two semesters/one academic
year.

1.2

The eligibility for admission to the course shall be as follows:
(a) Bachelor’s degree in any discipline of the Panjab University with
at least 50% marks.
(b) An examination of another University recognized by the Syndicate
as equivalent to (a) above.

1.3

A candidate shall be eligible for appearing in the examination if
he/she has attended at least 75% of the lectures delivered to the
class in theory, practical and project work separately.

1.4

A deficiency in the required number of lectures may be condoned as
given below:(i)
(ii)

Upto 10% by the Board of Control in Defence & Strategic
Studies
Upto 15% by the Dean of University Instruction on the
recommendation of the Board of Control in Defence & Strategic
Studies.

1.5

The tuition fee, examination fee and other charges to be paid by the
candidate of different categories shall be prescribed by the Syndicate
from time to time.

1.6

The medium of examination shall be English.

2.

The examination shall be held in accordance with the prescribed
syllabus.

3.

The minimum marks required to pass the examination shall be 40%
in every (i) theory paper (ii) project report and 45% in aggregate.

4.

The examination for the First Semester shall be held ordinarily in
December and for the Second Semester in May next year. The work
on the project report will run concurrently during the two
semesters.

5.

A candidate who fails in a particular semester shall be allowed to
reappear in the subsequent semester, with a maximum of two
consecutive chances for each semesters.
38

<!-- page 39 -->

6.

A candidate who fails in one or more theory and/or practicals shall
be allowed to reappear in the subsequent two consecutive
examinations/in the respective theory and/or practicals.

7.

Each candidate shall submit four copies of the project report on an
approved topic. The report is to be submitted on or before 30th April.
An extension upto a maximum of three months may be granted.

8.

The minimum number of marks required to pass the examination
shall be :
(a)
(b)
(c)

40% in theory paper
40% in dissertation
45% in aggregate of (a) & (b)

Successful candidates shall be classified into three divisions as
under:
(a) Those who obtain 60% or more
of the aggregate marks.
(b) Those who obtain 50% or more
but below 60% of the aggregate
marks.
(d) Those who obtain less than 50%
of the aggregate marks

: First Division
: Second Division

: Third Division

9.

Four weeks after the termination of the examination, or as soon as
possible, the Controller of Examinations shall publish the results of
the examination.

10.

Each successful candidate shall be granted a Postgraduate Diploma
showing the division.
.................

39
