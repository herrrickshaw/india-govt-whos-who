---
doc_id: "2bdba1995bdbe3c4"
source_url: "https://cdoe.puchd.ac.in/includes/noticeboard/2023/20230512170531-appointment.pdf?2026"
ministry: "Centre for Distance and Online Education, Panjab University, Chandigarh"
title: "Chairperson Appointment Letter"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ca7fbb32d96c8643"
---

<!-- page 1 -->

ROTATION OF HEADSHIP - TEACHING DEPARTMENTS

715

However, from amongst Associate Professor directly recruited on
the same day by the same Selection Committee, their turn for
designation as Chairman/Head shall be determined on the basis
of the ranking approved by the Senate.
(c)

2.2.

In case a Associate Professor in the Department is not available
the Chairperson/Head shall be designated, by rotation, from
amongst the Assistant Professor in the Department who have at
least 8 years' teaching experience as Assistant Professor in the
Department, according to length of service. The period of service
as temporary ad hoc Assistant Professor on a full-time basis in
the Department will be counted towards the requisite period of 8
years' teaching experience as Assistant Professor in the
Department. Provided that in exceptional circumstances, for
reasons to be recorded, the Vice-Chancellor in making
recommendations to the Syndicate on designation of a
Chairperson/Head, may deviate from the principle of length of
service or the stipulation of length of teaching experience as the
case may be.

(i)

No Professor, Associate Professor or Assistant Professor in a Department
shall be compelled to accept the offer of Chairmanship/Headship of
the Department.

(ii)

As and when the turn of a faculty member comes up for appointment
as Chairmanship/Headship, he will, have no right to have it postponed.

2.3. A person designated as Chairperson/Head of the Department shall hold office
as such for a period of three years and shall not be eligible for designation for the second
time till all the Professors/Associate Professor/Assistant Professor in the Department
have been designated as Chairperson/Head in accordance with Rule 2.1.
However, where no other Professor/Associate Professor/Assistant Professor is
available or eligible, the same person can be allowed to continue as Chairperson/Head
of the Department for a period of another three years or till the next person in the
Department becomes eligible, whichever is earlier.
Provided that a Chairperson/Head of a Department on attaining the age of
superannuation i.e. 60 years shall cease to hold office as such.
2.4. When Professors/Associate Professor/Assistant Professor in a Department
have been designated as Chairperson/Head for one term, in accordance with rule 2.1.,
the next Chairperson/Head of the Department shall be designated by rotation according
to the said rule 2.1.
2.5. (a)
In case a faculty member entitled for being designated as Chairperson/
Head in accordance with Rule 2.1. is one leave for a period of six months or more for
study, research or for any other purpose on the date his turn comes up for designation as
Chairperson/Head, the next eligible person on the rotation list will be designated
Chairperson/Head and the claim of such a faculty member to Chairmanship, will be

<!-- page 2 -->
