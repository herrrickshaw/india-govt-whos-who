---
doc_id: "a82f7452cfacdaba"
source_url: "https://www.library.puchd.ac.in/includes/noticeboard/2023/20231017141818-circularreg.drillbit.pdf?2026"
ministry: "A. C. Joshi Library, Panjab University, Chandigarh"
title: "Regarding DrillBit Plagiarism Software"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "85ea8557d0e3e87a"
---

<!-- page 1 -->

Dear Sir/Madam,
This is to inform you that INFLIBNET Centre is providing Drillbit-Extreme 'Plagiarism
Detection Software' to Higher Education Institutions (HEIs) under the ShodhShuddhi
Programme from 1st October 2023 onwards instead of ‘Ouriginal’(Urkund) Plagiarism Software.
In this context, new login ids and passwords are being issued to the Chairpersons/Directors/
Coordinators of all the Teaching Departments of Panjab University, Chandigarh.
All the faculty members, who are interested to get personal login for access to DrillBit
Plagiarism Software, may send their details, as under, to e-mail address librarian@pu.ac.in:1.
2.
3.
4.
5.

Name
Designation
Department
e-mail id
Mobile number

With regards

(Prof. Harsh Nayyar)
University Librarian
(Additional Charge)
