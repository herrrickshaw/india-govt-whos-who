---
doc_id: "adff2468c7c6f6fc"
source_url: "https://chdanimalhusbandry.gov.in/pdf/AHP2.pdf"
ministry: "Animal Husbandry and Fisheries Department, Chandigarh"
title: "Amendment in RR for the posts of Group C on central pattern"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fe686223e484575d"
---

<!-- page 1 -->

GOVERNMENT OF INDIA

Gazette

Chandigarh Abminístration
Publlshed by Authority

19, 1946

11, 2024 (ASVINA

CHANDIGARH, FRIDAY, OCTOBER

No. 142]

SAKA)

CHANDIGARHADMINISTRATION
DEPARTMENTOF ANIMAL HUSBANDRY
Notification

The 8h October:

exercise

No. VE-25/2024/10238.--In

1966,

Husbandry

&

S.0.

make the following

to

Field Investigator and

Veterinary

No. 3267,

of

the

dated

rules, regulating
in

Inspector

the Animal

Administration,

& Fisheries,Chandigarh
of

their

publication

in

Rules, 2024.

Recruitment

(Non-Ministerial)

(Group-C)

Department

the Official Gazette.

Application:
These

3.

is pleased

309

article

namely:

shall come into force on the date

(ii) They

to

proviso

may be called the Chandigarh
commencement: () These, rules

Husbandry

of Animal

2.

and

the

Home Affairs, Notification

of

Territory, Chandigarh

Chandigarh,

Fisheries Department,

Short title

Union

by

conferred

powers

"C posts i.e. Computor,

Group

to

of recruitment

the method

1

dministrator,

the

the

of India, Ministry

the Government

with
Constitution of India read
Ist November,

of

2024

rules

shall

apply

to

No.l

the posts specified in column

Number of posts, classification
The number of posts, their

of

the Schedule

annexed

to these rules.

and scale of pay:

classification

and

the scales of pay shall

be as specified in columns

2 to 4 of the said

Schedule.

age limit and qualification, etc:

Method of recruitment,

age

limit,

The method of recruitment to the said posts,
said Schedule.
be as specified in columns 5 to 13 of the
5,

Syuts

qualifications and

other matters connected

therewith

shall

person:

Disqualification:No

ea) who has etered into or contracted a marriage with

person

having

a spouse

living

å

4.

OR
170832 5

(b)

who,having

a spouse

for the appointment

living,

has entered

into

or contracted a marriage, with any person,

to the said posts:

(2201)
This

is Digitally Signed

Gazette. To verify,

https:llegazette.chd.gov.

in

visit

:

shall

be eligible

<!-- page 2 -->

2202

CHD. ADMN

Provided

that

permissible

the

SAKA)

of Chandigarh may, if satisfied that such
marriage
is
person and other party to the marriage and there
are other
exempt, any person from the opcration of this rule.
Territory

Law applicable

respect

Union

Administrator,

he may, by order,

so to do,

to such

Savings

Chandigarh is of the opinion
that it is necessary or
expedient
be recorded in writing, relax
any of the provisions
of these rules in

Territory,

for reasons

of any class or category

to

of persons.

:

Nothing in these rules
provided
categories
regard.

8.

11, 2024 (ASVN, 19, 1946

Power to relax
Where the

7.

Union

Administrator,

under the personal

grounds for so doing,
6.

GAZ.OCT.

shall

affect

reservations,
relaxation
of age limit and other
concessions requíred
to be
Scheduled Tribes, Other Backward
Classes,
of persons in
Ex-Servicemen and other special
accordance with the orders issued by
Central
Government from time to tíme in this

for

Scheduled Castes,

Repeal :

&

Department of Animal Husbandry
Fisheries
(Group-C) Recruitment Rules in
Computor, Field Investigator and
respect
of the posts of
Veterinary
Inspector
notified
vide notification
No. 163-UT-FII(12)-02/1437,
dated.20.02.2002,
No.VE/25/12/4583, dated
30.07:2012,
No.VE/25/14/3332, dated 11.07.2014
No.V-25/2022/87, dated 07.01.2022,
and
are hereby repealed

HARI KALLIKKAT, IAS,
Animal Husbandry,
Chandigarh Administration.
Secretary

Thls

Sgned Gazette, To
https:legazette.chdgov.n

is Digltally

verify,

visit

:

<!-- page 3 -->

CHD, ADMN GAZ. OCT, II, 2024 (ASVN, 19, 1946 SAKA)

2203

Annexure-I
1

Name of Post

2

No. of Posts

Computor
2* (2024)
* subject to variation
General

Classification

Non
4

5

Scale of Pay

Central

dependent

Services

on work load

Group-C'

Non-Gazetted

Ministerial

Pay Level-2 (Rs.19900-63200)

in

the pay matrix of

7

CPC.
Whether

selection

of post or Non-

Not applicable

selection

6

Age limit for direct

18 and 25 years.
(The upper age limit is relaxable for departrmental
candidate upto 40 years jnaccordance with the
Between

recruit.

or

instructions

orders

issued

by

the

Central

date for determining

the

age limit

governmenty
Note:

The crucial

shall

be the closing date

for

from

receipt of applications
and not closing date

candidates in India
prescribed for those in Assam; Meghalaya, Arunachal
Pradesh,
Mizoram,
Mânipur, Nagaland,
Tripura,
Sikkim, Ladakh , Lahaul.
Spiti
District
and Pangi
Sub-division of
Himachal
Pradesh,
Andaman
Nicobar Islands or Lakshadweep.

&

&

&

Educational
Other Qualifications
Required For Direct Recruitments

Bachelors
Degree from any, recognized Uniyersity
with Economics or Statistícs
or Mathematics as one of
the subjects and proficiency in operation of

Computer
(Word Processing and Spread Sheets) and a peed
of
35 WPM in English typewriting on
computer.
Note:

The

direct recruits
have to submit the
of Information Cmmunications
Technology
(ICT) Sills at the time of thei
appointment, as per
instructions .issued
by Chandigarh
Administration
vide. letter
No.
&
28/69-IH(12)/Pers.
Trg.
1019/17927, dated 25.11.2019.
Not applicable
ceftificate

8

Whether

age and

qualifications
direct

recruits

Educational
prescribed
for
will apply in case

of

9

Promnotees
Period of probation,if any

TWo years

10 Method of recruitment whether by
direct

promotion

recruitment
or

or

&%

by

(Successful
ompletion
of, mandatory
Induction
Training of at least two weeks
duration shall be the
pre-requisite
for completion of probation)
100% by Direct Recruitment failing which
by
deputation

by
the

deputation/absorption
of
vacancies to be filled bý various

methods

Thls is Digltally

Signed

Gazette.

To verify, visit :

htups:llegazette.chd.govin

<!-- page 4 -->

11

SAKA)

(ASVN, 19, 1946
CHD, ADMN GAZ.OCT. 11, 2024

2204

In

case

of

promotion
absorption
grades from
deputation/

By Deputation
by
the
of
/Officials

recruitment
deputation

Central

Government/State

Government/
which promotion/
be
to
absorption

Union Territories:
(a) Holding analogouspost

on a regular basís in the

parent cadre or department.

made

OR

(a)

Holding

post of LDC/Clerk

on regular

basís in

the Pay Level-2 (Rs. 19900-63200) in the parent
cadre or department.
(b)

Possessing
prescribed

the Qualification and experience
for direct recruitment under column

No.7
Note:-1 The period of deputation including the period
of deputation
in
another
ex - cadre
post held
immediately
preceding this appointmentin the same

or

some

other

organization

/ department

of the

Government
/State
Government/UT
Administration
shall
be as per the instructions /
guidelines issued by the Government from time to
Central

time.

2. The

maximum age

deputation
12

closing
If

Departmental
Committee
exists,
composition

Promotion

what

is

its

shall

limit

for

be Not exceeding

appointment

by

56 years as on

date of receipt of applications.

Departmental

Confirmation
(for confirmation):

Committee

1) Director Animal Husbandry: Chairman
2) Reprs. of Department of Personnel: Member
3) Reprs. of Social Welfare :Member
4) Reprs. of Regional Employment Officer :Member,
13 Circumstances

in which
consulted
in
recruitments
to

be

UPSC s

Not

applicable

making

This is Digitally Signed Gazette. To veri,
htups:esazette chdgov.in

visit.

<!-- page 5 -->

u CHD.

ADMN GAZ. OCT, I1, 2024 (ASVN. 19, 1946 SAKA)

2205

Annexure-I
1

Name of Post

Field

2

No. of Posts

1"(2024)

3

Classification

4

Scale of Pay

5

Whether

Investigator

*subject

to variation dependent

General

Central

on work load
Services Group-'C'
Non
Gazetted Non-Ministerial
Pay Level-4 (Rs.25500-81100) in the pay matrix

selection

of

post

of

CPC.
or Non-Non-Selection

7

selection

6

Age limit for direct recruit.

Between 18 and 25 years.
(The upper age limit is relaxable for departmental
candidate
upto 40 years in accordance with the
instructions
or
orders
issued
by the Central
government)

The crucial date for determining the age limit
be the closing date for receipt of applications
from candidates
in
India and not closing date
prescribed for those in Assam, Meghalaya, Arunachal
Pradesh,
Mizoram, Manipur,
Nagaland,
Tripura,
Sikkim, Ladakh,Lahaul&Spiti District and Pangi Sub
division
of Himachal
Pradesh, Andaman & Nicobar
Islands or Lakshadweep
Bachelor's Degree from any recognized
University
with Economics or Statistics or Mathematics
as one of
Note:
shall

7

Educational
Required

&

Other Qualifications
For Direct Recruitments

the subjects.

The

Note:

have to submit the
CommunicationsTechnology
at the time of their appointment,
as per
direct

recruits

of. Information

certificate

(ICT) Skills
instructions issued
vide
letter
No..

8

Whether age and
qualifications
direct

recruíts

Educational
prescribed
for
will apply in case

of Promotees
Period of probation, if any.

by Chandigarh
Administration
&
28/69-IH(12)/Pers.
Trg.
1019/17927;dated 25.11.2019.
Not applicable

Two years
(Successful completion of mndatory Induction
Training of at least two weeksduration shall be the
pre-requisite for completion of probation)

10 Method

recruitment
recruitment
or
promotion
of

direct

deputation/absorption
vacancies to be filled

whether by 100% by promotion failing which
or
"by which by Direct recruitment

by deputation failiog

by

& % of the
by various

methods
In

case
of
recruitment
by
promotion / deputation /
absorption grades from which
promotion
deputation
absorption to be made

By Rromotioni

From amongst the Computors having eight years
regular service in the cadre after appointment

thereto.

This is Digitally Signed

To verify,
chd gov.

Gazette.

htups:lesazetlle.

br

11

visit

:

<!-- page 6 -->

(ASVN,19,
CHD. ADMN GAZ. OCT, 11,2024

2206

1946 SAKA)

ICT skill course is mandatory at promotionas
issued
the
by
Chandigarh
&
No.
28/69-IH(12)/Pers.
vide letter
Administration
25.11.2019.
dated
Trg.-1019/17927,
Note:

instructions

per

Deputation

By

Government/State
of the Central
Government/Union Territories:
Holding analogous post on a regular basis in the
(a)
Officials/Officers

parent cadre or departrment.
(b)

the qualification and experience
for direct recruitment under column

Possessing
prescribed

No.7
including the period
another ex- cadre post held
immediately
preceding this appointment in the same
.or some other
organization/
department of the
Government
Central
Government/State
/UT
Administration
shall
be as per the instructions /
guidelines issued by the Government from time to
Note:-1
of

The period

deputation

of deputation

in

time.

2.

The maximum

deputation

shall

age limit for appointment by
be Not exceeding 56 years as on

closing date of receipt of applications.

12 If
Departmental
Promotion
Committee exists, what is its

Departmental Promotion
considering

Committee (for

Promotion): -

composition

1) Director Animal Husbandry:Chairman
2) Reprs. of Department of Personnel: Member
3) Reprs. of Social Welfare :Member
4) Reprs. of Regional Employment Officer :Member
Departmental Confirmation Committee
(DCC) (for confirmation):

1) Director Animal Husbandry:Chairman
2) Reprs, of Departmentof Personnel: Member
3) Reprs. of Soclal Welfare :Member
4) Reprs. of Regional Employment Officer :Member
13

Circumstances
in
which
to
be consulted
in
recruitments

UPSC

is

Not

Applicable

making

This is Digltally Signed

Gazeue.

To

htps:legazette.chd.gov.in

verifs,

vsit

:

<!-- page 7 -->

CHD. ADMN GAZ. OCT, 11,2024 (ASVN.

19, 1946 SAKA)

2207

Annexure-I
1

Name of Post

Veterinary Inspector

No. of Posts

16* (2024)
*Subject to variation dependent on work load

3

Classification

General

4

Scale of Pay

Pay Level-5 (Rs.29200-92300)
CPC.

Central
Services
Gazetted/Non-Ministerial

(Group-C

in

Non

the pay matrix of 7

Whether selection of post or Non- Not Applicable
selection

6

Between 18 and 25 years.
(The upper age limit is relaxable for departmental

Age limit for direct recruit.

candidate

upto

instructions

40 years

or

in

orders

accordance

issued

by

the

with

the

Central

government)
Note:

The crucial

shall

be the closing date

date for determining the age limit
for receipt of applications
from candidates in India and not closing
date
prescribed for those in Assam, Meghalaya, Arunachal
Pradesh,
Mizoram,
Manipur,
Nagaland,
Tripura,
Sikkim, Ladakh, Lahaul & Spiti District and Pangi Sub
division
of Himachal Pradesh, .Andaman & Nicobar
Islands or Lakshadweep.

7

Educational & Other Qualifications
Required For Direct Recruitments

10+2 with Physics, Chemistry & Biology.
possess diploma in Veterinary Science of
Two years duration from any University / Institution
recognised by.Central/State Government.
i)

Matric

or

ii) Should

have to submit the
Technology
Communications
of Information
certificate
as per
(ICT) Skills at the time of their appointment,
issued
instructions
by Chandigarh Administration
Trg.
N.
28/69-IH(12)/Pers.
vide
létter
1019/17927, dated 25.11.2019.
Note:

8

Whether

9

10

age

and

Educational

qualifications

prescribed

direct

will

recruits

The

direct

recruits

Not applicable

for

apply in case

of Promotees
Period

Two years

of probation,if any

mandatory Induction
(Successfulcompletion of
shall be the
of at least two weeks duration
Training
of
probation).
for completion
pre-requisite

by Direct
Method of récruitment whether by 100%
direct
or
deputaion
recruitment
by
promotion
or
by
deputation/absorption
&
of the
vacancies tó be filled by various

Recruitment faillng which by

%

methods
Gazette. To werif%, vsi
This is Digitally Slgned
https:egazette. chdgov.on

.

<!-- page 8 -->

11,2024 (ASVN, 19, 1946

CHD. ADMN GAZ.OCT.

2208

11| In

case

promotion
absorption
promotion/

of

by

recruitment

/deputation /

from
grades
deputation

which

absorption to be made

By

SAKA)

Deputation

oficials/Officers, of the Central
Government/ Union Territories: -

Government/State

(a)

Holding analogous post on a regular basis
parent cadre or department

(b)

Possessing
prescribed
No.7.

the

qualification

in

the

and

for direct recruitment

experience
under column

Note:-1 The period of deputation incduding the períod
of deputation
in
another
ex - cadre post held
preceding this appointment in the same
of the
other organization/ department
Government
/UT
Government/State
/
shall
be as per the instructions
Administration
immediately

or some
Centrat

guidelines issued
time.

2. The

by the Government from

maximum age limit

for

be Not exceeding

deputation
closing date of receipt of applications.
shall

12

Departmental
exists,
Committee
composition
If

Promotion

what

is

its

Yes, Departmental Confirmation
(DCC) for confirmation:

tíme

by
appointment
56 years as on

Committee

1) Director Animal Husbandry: Chairman
2) Reprs. of Department of Personnel: Member
3) Reprs. of Social Welfare :Member
4) Reprs. of Regional

13

Circumstances in
to
be consulted
recruitments

which
in

UPSC is
making

EmploymentOfficer

Not Applicable

This is Digitally Signed Gazette. To verify,
httpslegazette.chd,gov
in

visit

:

to

:Member
