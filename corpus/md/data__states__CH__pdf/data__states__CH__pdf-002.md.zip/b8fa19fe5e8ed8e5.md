---
doc_id: "b8fa19fe5e8ed8e5"
source_url: "https://chandigarh.gov.in/cadmin//uploads/1784091029_e3efd3c68c7ccaa78ce2.pdf"
ministry: "Agriculture Department, Chandigarh"
title: "title_en'>Final Gradation/Seniority List of Steno-typists of Chandigarh Administration appointed under Common Cadre (Direct Recruitment) as on 01012026"
date: ""
pages: 8
method: "tesseract:pan+hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "73d5c6272b59c099"
---

<!-- page 1 -->

HOME-B-11/27/2025-HOME-PandT-HOME \1116350/2026
No. 588075-IH(11)-2026/ [|€ 350
Chandigarh Administration
Department of Personnel
(Personnel-Il Branch)
Chandigarh, dated the 13/67/2026

To
All the concerned Heads of Departments,

Union Territory, Chandigarh
{As per list attached)

Subject: Final Gradation/ Seniority List of Steno-Typists of Chandigarh
Administration appointed under Common’ Cadre (Direct
Recruitment) as on 01.01.2026.

sok
Reference this Department's letter No. 588075-IH(11)-2026/69433 dated

18.03.2026 on the subject noted above.

2. Enclosed please find herewith Final Gradation/ Seniority List of Steno-Typists

of Chandigarh Administration appointed under Common Cadre (Direct Recruitment) as on

01.01.2026 for bringing the same to the notice of all the stakeholders posted in your

Department positively, with further request to keep a receipt/ record thereof for future

reference. erat

Sup: rsonnel-Il,
for Secretary Personnel,
Chandigarh Administration

Endst. No. 588075-IH(11)-2026/ | 16350 Dated: 13/o7/20¢

A copy along with a copy of Final Gradation/ Seniority List of Steno-Typists
. of Chandigarh Administration appointed under Common Cadre (Direct Recruitment) as on

01.01.2026 is forwarded to the Director Information Technology, Union Territory,

Chandigarh with the request to upload the same on the official website of Chandigarh

Administration.

"oak ੭6
Superi it Personnel-ll,
for Secretary Personnel,
Chandigarh Administration

<!-- page 2 -->

HOME-B-11/27/2025-HOME-PandT-HOME 1/16350/7026
Sr. | Name of the Department | Name and Father's Name of the official
No (S./Sh./Smt.)

T. [law 7, Ashish Kumar Verma S/o Sita Ram Verma
ii, Devvarat S/o Rupender
li’. Abhisham Ahuja S/o Raj Kamal Ahuja
Chandigarh Secretariat 7, Sukhpreet Kaur D/o Devinder Singh
ii, Hitan Bassi S/o Prem Chand
lif, Pallavi Thakur D/o Suraj Parkash
iv. Minny Madan D/o Balwant Madan
v. Himani D/o Jatinder Kumar
‘Sagar Verma S/o Rajesh Kumar
4,__| Education 7, Vinod Kumar S/o Mahipal
0. Gurleen Kaur D/o Sarvjeet Singh
iii. Isha D/o Durgesh Nandan
iv. Ravi Chauhan S/o Partap Singh Chauhan
v, _ Akshay S/o Surinder
i, Simran D/o Raj Kumar
ਭੁ. | Engineering 7, Rahul Kamboj S/o Krishan Ram
ii, Anu D/o Ranbir Singh
iii, Abhishek S/o Vinod Kumar
iv. Manpreet Kumar S/o Deen Dayal
v. Sandeep Kaur D/o Jasbir Singh
vi. Joginder Kaur D/o Santa Singh
| | Ritika Sachdeva D/o Ajit Sachdeva
Government College of Arts | Rishu Pruthi S/o Gulshan Kumar
Police 7, Ravi Kumar Singh S/o Raj Kishor Singh
ii, Bhag Chand Nayak S/o Rattan Lal Nayak
[> | Food & Supplies Piyush Sharma S/o Raghunath Sharma
Local Audit Sourav S/o Madan Lal
Statistical Cell ‘Suruchi Kohii Do Jasbir Singh
CCET (Degree Wing) ‘Ashish Kaushal S/o Mohan Lal Kaushal
13. | GMSH-16 i._Ritika Rani D/o Satpal
ii, Randeep Singh S/o Amrik Singh
14, | Chandigarh College of i. Sunil Vimal S/o Hari Singh
Architecture ii, Manju D/o Ramdhari
lii, Naran Verma S/o Rajesh Verma
Social Welfare Yash Kajal S/o Tek Chand
Priyanka Bhalwal D/o Suman Kumar
18. | DC Office 1. Vikram S/o Randhir Singh
ii, Poonam Rani D/o Ramotar
Public Relation Veenu D/o Harish Kumar
20. | GMCH i, Saraswati D/o Shyam Singh
ii, Hardik Jairath S/o Manoj Jairath
iii, Bharti Mehta D/o Krishan Mehta
iv. Geeta D/o Rajpal
v. Pravesh Jangra S/o Surender Jangra
vi. Neetu Pal D/o Ramkhilawan
vii. Sahil S/o Ramkarn
21. | Urban Planning (Architecture | Gita Devi D/o Krishan
Wing) Prabhjot Kaur D/o Harmohan Singh
੧0੮ [Prisons ‘| Hemant Chauhan S/o Partap Chauhan
24, | Urban Planning (Town Kanika D/o Gurmukh Singh
2७ Planning Win
x a Hospitality Kuldeep Parsad S/o Jagdish Parsad Naithani
\ Science & Technology ‘Suraj Singh S/o Shiv Pal Singh
Prince Jindal S/o Parshotam Jindal

<!-- page 3 -->

FINAL GRADATION/ SENIORITY LIST OF STENO-TYFISTS OF CHANDIGARH
ADMINISTRATION APPOINTED UNDER COMMON ___ CADRE __ (DIRECT PPOINTED UNDER MMON CADRE (DIRECT
RECRUITMENT) AS ON 01.01.2026
Name and Father's | Date of Whether SC/OBC/
Name of the official {a) Birth EWS/PH
(S/Sh/Smt.) lb) Entry into Govt. Service
०) Attainment ofage of 55
years
id) Compulsory Retirement
Ly Ashish Kumar Verma | a)07.12.1991 UR
S/oSita Ram Verma b)10.09.2015 (AN)
c) 07.12.2046 :
d)31.12.2051
2 Sukhpreet Kaur a)26.01.1993 UR
D/oDevinder Singh b)21.09.2016 (AN)
c)26.01.2048
d)31.01.2053
3. Sagar Verma a)22.06.1992 OBC
S/oRajesh Kumar b)29.09.2016 (AN)
੮)22.06.2047
0)30.06.2052
4. Saraswati a)22.06.1992 UR
D/o Shyam Singh b)29.09.2016 (AN)
੮)22.06.2047
d)30.06.2052
5. Ritika Sachdeva a)20.10.1990 UR
D/o AjitSachdeva b)22.09.2016 (AN)
੮)20.10.2045
d)31.10.2040
Rishu Pruthi a)05.08.1992 UR
S/oGulshan Kumar b)29.09.2016 (AN)
੮)05.08.2047
d)31.08.2052
te Amit Sharma a)14.09.1993 UR
S/o Meghnath b)30.09.2016 (AN)
Sharma c)14.09.2048
d)30.09.2053
Resigned- Lien till
18.11.2027
Ravi Kumar Singh a)06.09.1990 UR
S/oRaj Kishor Singh b)04.10.2016 (AN)
੮)06.09.2045
d)30.09.2050
Piyush Sharma a)05.10.1994 UR
WwW — ZF S/o Raghunath b)22.09.2016 (AN)
Sharma c)05.10.2049
A d)31.10.2054
10. Rahul Kamboj a)16.10.1991 . OBC
S/o Krishan Ram b)10.03.2017 (FN)
੮)16.10.2046
d)31.10.2051
Page 1 of 6

<!-- page 4 -->

FINAL GRADATION/ SENIORITY LIST OF STENO-TYPISTS OF CHANDIGARH GRADATION ENIORITY LIST OF STENO-TYPISTS OF CHANDIGARH
ADMINISTRATION APPOINTED UNDER __ COMMON _CADRE__ (DIRECT RATION APPOINTED UNDER COMMON CADRE DIRECT
RECRUITMENT) AS ON 01.01.2026
Name and Father's | Date of Whether SC/OBC/
Name of the official a) Birth EWS/PH
(S/Sh/Smt.) 9) Entry into Govt. Service
ic) Attainment ofage of 55
years
ld) Compulsory Retirement
fi. Vinod Kumar a)27.11.1995 OBC
S/o Mahipal b)14.03.2017 (AN)
¢)27.11.2050
d)30.11,2055
12. Anu a)24,05,.1992 UR
D/o Ranbir Singh b)22.09.2016 (AN)
੮)24.05.2047
d)31.05.2052
13. Sourav a)02.07.1989 OBC
S/o MadanLal b)07.03.2017 (AN)
c)02.07.2044
d)31.07.2049
14. Bhag Chand Nayak a)04.07.1993 UR
S/o Rattan LalNayak | b)09.03.2017 (FN)
੮)04.07.2048
d)31.07.2053
15. Suruchi Kohli a)28.08.1992 UR
D/o Jasbir Singh b)01.03.2017 (AN)
c)28.08.2047
d)31.08.2052
16. Ashish Kaushal a)01.09.1991 UR
S/o Mohan b)06.03.2017 (AN)
LalKaushal c)01.09.2046
d)30.09.2051
17. Ritika Rani a)03.11.1990 UR
D/o Satpal b)03.04.2017 (FN)
੮)03.11,2045
d)30.11.2050
18. Sunil Vimal a)22.10.1986 sc
S/o Hari Singh b)03.10.2016 (FN)
c)22.10.2041
d)31.10.2056
19. Abhishek a) 26.09.1992 UR
S/o Vinod Kumar b) 12.03.2021 (FN)
¢) 30.09.2047
d) 30.09.2052
20. Prince Jindal a) 15.06.1997 Ews
S/o Parshotam Jindal | b) 01.03.2021 AN) (on merit)
c) 30.06.2052
੧੭ 0) 30.06.2057
ਵਿ 21. Manju a) 31.03.1994 UR
D/o Ramdhari b) 31.03.2021(AN)
¢) 31.03.2049
d) 31.03.2054
Page 2 of 6

<!-- page 5 -->

FINAL GRADATION/ SENIORITY LIST OF STENO-TYPISTS OF CHANDIGARH
ADMINISTRATION APPOINTED UNDER COMMON ___CADRE __ (DIRECT
RECRUITMENT) AS ON 01.01.2026
Name and Father’s | Date of Whether SC/OBC/
Name of the official ja) Birth EWS/PH
. (S/Sh/Smt.) lb) Entry into Govt. Service
lc) Attainment ofage of 55
years
id) Compulsory Retirement
22. Hitan Bassi a) 07.12.1994 UR
S/o Prem Chand b) 01.03.2021(AN)
¢) 31.12.2049
d) 31.12.2054
23, Yash Kajal a) 30.08.1996 UR
S/o Tek Chand b) 03.03.2021(AN)
¢) 31.08.2051
d) 31.08.2056
24, Sakshi a) 10.12.1996 OBC
D/o Anil Kumar b)08.03.2021(AN) (on merit)
c) 31.12.2051
(Resigned- Lien till | d) 31.12.2056
08.08.2026)
25. Devvarat a) 05.12.1996 UR
S/o Rupender b) 01.03.2021(AN)
c) 31.12.2051
d) 31.12.2056
26. Pallavi Thakur a) 28.12.1997 UR
D/o SurajParkash b) 26.02.2021(AN)
c) 31.12.2052
d) 31.12.2057
27. Priyanka Bhalwal a) 17.05.1997 UR
D/o Suman Kumar b) 01.03.2021(AN)
c) 31.05.2052
d) 31.05.2057
28. Gurleen Kaur a) 05.01.1996 UR
. D/o Sarvjeet Singh b) 09.03.2021(AN)
c) 31.01.2051
d) 31.01.2056
29. Kapish a) 20.05.1996 UR
S/o Pawan Kumar b) 03.03.2021(AN)
c) 31.05.2051
d) 31.05.2056
30. Simran a) 05.11,1998 UR
D/o Raj Kumar b) 08.03.2021(AN)
ਨ c) 30.11.2053
d) 30.11.2058
Mp 31. Minny Madan a) 08.10.1993 EWS
D/o BalwantMadan b) 05.03.2021 (FN) (on merit)
०) 31.10.2048
may d) 31.10.2053
Page 3 of 6

<!-- page 6 -->

FINAL GRADATION/ SENIORITY LIST OF STENO-TYPISTS OF CHANDIGARH GRADATIO SENIORITY LIST OF STENO-TYPISTS OF CHANDIGARH
ADMINISTRATION APPOINTED _ UNDER__ COMMON __ CADRE _(DIRECT APPOINTED UNDER OMMON CADR' DIRECT
RECRUITMENT) AS ON 01.01.2026
Name and Father’s | Date of Whether SC/OBC/
Name of the official ja) Birth EWS/PH
(S/Sh/Smt.) lb) Entry into Govt. Service
Ic) Attainment ofage of 55
years
ld) Compulsory Retirement
32. Vikram a) 20.11.1996 UR
S/o Randhir Singh b) 25.03.2021(AN)
c) 30.11.2051
0) 30.11.2056
93, Veenu a) 12.11.1996 UR
D/o Harish Kumar b) 26.04.2021(AN)
c) 30.11.2051
d) 30.11.2056
34, Hardik Jairath a) 19.02.1997 UR
S/o Manojjairath b) 30.04.2021(AN)
c) 29.02.2052
d) 28.02.2057
35, 15੩ a) 02.09.1999 EWS
D/o Durgesh Nandan | b) 22.06.2021(AN)
c) 30.09.2054
d) 30.09.2059
36. Abhisham Ahuja a) 21.08.1998 EWws
S/o Raj Kamal Ahuja | b) 03.06.2021(AN)
c) 31.08.2053
d) 31.08.2058
37. Gita Devi a) 25.08.1995 OBC
D/o Krishan b) 22.03.2021 (FN)
c) 31.08.2050
d) 31.08.2055
38. Bharti Mehta a) 03.10.1995 EWS
D/o Krishan Mehta b) 15.03.2021(AN)
c) 31.10.2050
d) 31.10.2055
39, Ravi Chauhan a) 17.12.1998 SC
S/o Partap Singh b) 01.03.2021(AN)
Chauhan c) 31.12.2053
d) 31.12.2058
40. Randeep Singh a) 23.05.1997 sc
S/o Amrik Singh b) 03.03.2021(AN)
c) 31.05.2052
d) 31.05.2057
ye 41. Geeta a) 27.12.1996 OBC
੧੬ D/o Rajpal b) 05.03.2021 (FN)
c) 31.12.2051
d) 31.12.2056
Page 4 of 6

<!-- page 7 -->

FINAL GRADATION/ SENIORITY LIST OF STENO-TYPISTS OF CHANDIGARH
ADMINISTRATION _APPOINTED UNDER ८01000010 ८५0२८:  (णारहटा
RECRUITMENT) AS ON 01.01.2026
Name and Father’s | Date of Whether SC/OBC/
Name of the official 9) Birth EWS/PH
(S/Sh/Smt.) lb) Entry into Govt. Service
lc) Attainment ofage of 55
years
ld) Compulsory Retirement
42. Avinash a) 07.01.1998 OBC
S/o Om Prakash b) 08.03.2021(AN)
c) 31.01.2053
d) 31.01.2058
43. Himani a) 07.08.1994 5੮
D/o Jatinder Kumar b) 02.03.2021(AN)
c) 31.08.2049
d) 31.08.2054
44. Poonam Rani a) 02.02.1995 OBC
D/o Ramotar b) 03.03.2021(AN)
c) 28.02.2050
d) 28.02.2055
45. Hemant Chauhan a) 24.05.1996 sc
S/o PartapChauhan b) 02.03.2021(AN)
c) 31.05.2051
d) 31.05.2056
46. Prabhjot Kaur a) 29.08.1994 sc
D/o Harmohan Singh | b) 08.03.2021(AN)
c) 31.08.2049
d) 31.08.2054
47. Pravesh Jangra a) 18.02.1995 OBC
S/o SurenderJangra b) 09.03.2021(AN)
c) 28.02.2050
d) 28.02.2055
48. Naman Verma a) 14.02.1996 OBC
S/o Rajesh Verma b) 02.03.2021(AN)
c) 28.02.2051
d) 29.02.2056
Neetu Pal a) 05.04.1998 OBC
D/o Ramkhilawan b) 12.03.2021(AN) :
c) 30.04.2053
d) 30.04.2058
50. Manpreet Kumar a) 19.12.1997 OBC
S/o DeenDayal b) 21.05.2021 (FN)
c) 31.12.2052
We d) 31.12.2057
51. Akshay a) 02.03.1996 sc
Wate S/o Surinder b) 09.03.2021(AN)
०) 30.03.2051
d) 30.03.2056
Page 5 of6

<!-- page 8 -->

FINAL GRADATION/ SENIORITY LIST OF STENO-TYPISTS OF CHANDIGARH GRADATIO. SENIORI LIST OF STENO-TYPIS' OF CHANDIGARH
ADMINISTRATION APPOINTED UNDER COMMON __CADRE__(DIRECT APPOINTED UNDER COMMON CADRE (DIRECT
RECRUITMENT) AS ON 01.01.2026
Name and Father's | Date of Whether SC/OBC/
Name of the official ja) Birth EWS/PH
(S/Sh/Smt.) b) Entry into Govt. Service
lc) Attainment ofage of 55
years
id) Compulsory Retirement
52. Sahil a) 04.12.1996 OBC
S/o Ramkarn 0) 20.07.2021(AN)
¢c) 31.12.2051
d) 31.12.2056
53; Sandeep Kaur a) 13.03.1991 Sé
D/o Jasbir Singh b) 26.02.2021(AN)
5 ੮) 30.03.2046
d) 30.03.2051
54. 311੩ a) 09.11.1994 sc
D/o Gurmukh Singh b) 05.03.2021(AN)
c) 30.11.2049
d) 30.11.2054
55. Kuldeep Parsad a) 26.01.1992 UR
S/o Jagdish Parsad b) 28.01.2022(AN)
Naithani c) 31.01.2047
d) 31.01.2052
56. Suraj Singh a) 23.11.1994 UR
S/o Shiv Pal Singh b) 11.02.2022 (FN)
c) 30.11.2049
d) 30.11.2054
57. Joginder Kaur a) 02.01.1993 OBC
D/o Santa Singh b) 24.02.2022(AN)
c) 31.01.2048
d) 31.01.2053
re
Page 6 of 6
