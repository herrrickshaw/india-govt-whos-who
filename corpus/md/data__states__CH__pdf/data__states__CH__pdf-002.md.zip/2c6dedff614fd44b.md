---
doc_id: "2c6dedff614fd44b"
source_url: "https://puchd.ac.in/includes/documents/2022/hbi-2022-part-a.pdf"
ministry: "Panjab University, Chandigarh"
title: "Part A  - PU Profile, Campus offices, Important Dates, Academic Calendar, Rules of Admission, Sports guidelines"
date: ""
pages: 44
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5398a41a99f23ecd"
---

<!-- page 1 -->

FRONT PAGES

0

HANDBOOK OF INFORMATION 2022

Hon’ble Shri M. Venkaiah Naidu, Vice President of India and Chancellor, Panjab
University, Chandigarh

<!-- page 2 -->

FRONT PAGES

1

HANDBOOK OF INFORMATION 2022

Vice-Chancellor’s Message
Sticking to its Vedic motto, Tamso ma jyotirgamya, which means “From darkness,
lead me to light”, Panjab University, established in Lahore in 1860 and relocated to
Chandigarh after partition in the 1960s, has constantly been striving to make higher
education accessible to one and all. Since its inception, Panjab University has remained a
leading light in the field of education. It has established its reputation as one of the premier
institutions of teaching and research in higher education.
The university proudly boasts of 194 affiliated colleges, 6 constituent colleges and
4 regional Centres which cater to the educational needs of students belonging to different
parts of the country. It has contributed significantly to materializse the vision of Shikshit Bharat, Sashakt
Bharat (Educated India is Empowered India) by bringing education and placement opportunities to every
doorstep. Not only this, the University enjoys the privilege of having contributed one President, two Prime
Ministers to our country; two Nobel Laureates to the world of science and innumerable luminaries in the fields
of industry, entrepreneurship, arts, literature and culture.
The University has highly qualified faculty in their respective fields of expertise. A large number of
national and international conferences, seminars and workshops are organized by the University. Such events
provide a variety of experiences to the students and inculcate skills such as leadership and team spirit which
are helpful in their career. Our faculty members have been able to publish good quality research work in high
impact factor journals of repute. There is an active interaction between faculty and students in the campus,
ensuring overall development of the learners. Further, the campus is ICT enabled providing an e-learning and
e-connect environment, alongwith class coordination system as well as virtual classrooms.
Pursuing the holistic approach, the university offers courses that straddle the traditional and core
disciplines as well as professional and vocational education with a special emphasis on the Indian Philosophy
and Value system, as an education bereft of values is meaningless and not worthy of promotion. Education is
meant to inculcate the right values among students to produce socially sensitive citizens. Therefore, Panjab
University encourages not only curricular activities but also co-curricular, extra-curricular and extension
activities. Moreover, the courses offered in a variety of faculties including the Arts, Science, Languages, Laws,
Engineering, Commerce and Pharmaceutical Sciences and training imparted in a humane, socially inclusive
and academically competitive environment make Panjab University an ideal choice for students from all
disciplines and socio-economic and cultural backgrounds.
It is a matter of great pride that Panjab University has been ranked second in the prestigious ATAL
ranking of Institutions on Innovation Achievements (ARIIA)-2021 in the category of University & deemed to be
university (Govt. & Govt. Aided) (Technical), besides being accredited with “A” Grade with a score of 3.35 out
of 4 by NAAC. The University has been ranked the fourth best University in India by the US News- Best Global
University Rankings and 601-800th in the world in the Times Higher Education Ranking (2022). The credit for
all of the above goes in no small measure to our highly motivated and committed faculty.
The Panjab University Campus at Chandigarh accommodates 78 Teaching and Research Departments/
Institutes/ Centres besides four independent Chairs for research. The University School of Open Learning, a
multi-disciplinary department, caters to about 20,000 distance learners and offers about two dozen traditional
and job-oriented courses. The University has extended its influence by signing and maintaining more than a
hundred MoUs with other Universities and educational institutions spread across four continents. The
departments and the Centres of the University are encouraged to aim at an interdisciplinary collaboration
while evolving projects in order to enable better coordination between pure sciences and social sciences and
sharing of ideas working towards the betterment of the Nation.
Both Education and Industry are significant pillars of any economy and play a vital role in social
development. Therefore, at Panjab University, we encourage Academia-Industry Interface. Keeping this
mission in mind, the University has consolidated seven verticals; the Centre for Industry-Institute Partnership
Programme (CIIPP), Technology Enabling Centre (TEC), Centre for Skill Development and Entrepreneurship
(CSDE), Bio Nest, Centre for Policy Research, University Centre for Sophisticated Analytical Instrumentation
Facility (SAIF) and Design Innovation Centre and Institution Innovation Council (ICC).
Building meaningful relationships with students and alumni is important for the strategic growth and
advancement of higher education institutes. Though alumni typically move away from campus to pursue a
career, they can stay in touch and help in building a global professional network. Keeping this in view, Panjab
University remains in close touch with them through regular Alumni meets and collaborative programs.
Committed to implementing the latest National Education Policy (NEP), the university is striving to
incorporate the main elements of NEP in the traditional curriculum and at the same time working towards the
implementation of CBCS, incorporating the Indian Knowledge System and promoting multi-disciplinary in all
Under Graduate and Post Graduate Programmes, with multiple exit options. The vision behind implementing

<!-- page 3 -->

FRONT PAGES

2

HANDBOOK OF INFORMATION 2022

the Choice Based Credit System scheme is to bring our resources at par with the Global practices in terms of
academic standards and evaluation strategies while retaining structures of the present Under Graduate & Post
Graduate Programmes. The flexibility in the curriculum has been designed with industry-specific goals in mind
and ensures incorporating the latest knowledge whilst stimulating the creative minds of the students.
The students of Panjab University have excelled not only in studies but also in Sports. The university
has held the Maulana Abul Kalam Azad (MAKA) Trophy 15 times and has recently received MAKA Trophy
three times in a row. The university is committed not only to maintaining its position of eminence in the
country and also a place in global attention.
Indeed, the Panjab University remains committed to serving the cause of nation-building through its
academically enriching, research-oriented and socially inclusive endeavours. I hope that the Handbook of
Information 2022 will act as a guide to the students aspiring to materialize their dreams by gaining admission
to the departments and academic Centres of the University and its regional campuses. I wish all students
success in their effort!
(Raj Kumar)

<!-- page 4 -->

FRONT PAGES

3

HANDBOOK OF INFORMATION 2022

OFFICERS AND DEANS OF PANJAB UNIVERSITY
Vice Chancellor

Professor Raj Kumar

2541945

Dean of University Instruction

Professor Renu Vig

2541156

Dean, Research

Professor Sudhir Sharma

2540535

Registrar

Professor Yajvender Pal Verma

2541716

Controller of Examination

Professor Jagat Bhushan

2541825

Honorary Director, IQAC

Professor Sanjeev Sharma

2534074

Chief Vigilance Officer

Professor Rattan Singh

2534843

Finance & Development Officer

CA Vikram Nayyar

2541850

Dean Student Welfare

Professor Jagtar Singh

2541596

Dean Student Welfare (Women)

Professor Roopali Garg

2541596

Associate, Dean Student Welfare

Professor Ashok Kumar

2534488

Associate Director, IQAC

Professor Anuradha Sharma

2534074

Dean of International Students

Professor Deepti Gupta

2541873

Dean of Alumni Relations

Professor Anupama Sharma

2541881

Dean, College Development Council

Professor Anju Suri

2541943

Librarian

Dr. Jivesh Bansal

2534551

Director, Dr.A.P.J. Abdul Kalam, Computer Centre

Professor Sukhwinder Singh

2534077

Honorary Director, Human Resources Development Centre

Professor Manu Sharma

2541425

Chief Medical Officer

Dr. Rupinder Kaur

2534477

Director Public Relations

Dr. Gaurav Gaur

2541054

Chief of University Security

Mr. Vikram Singh

2434289

Director, Physical Education & Sports

Professor Prashant Gautam

2541042

Deputy Director, Physical Education & Sports

Dr. Dolly

2534035

Director Youth Welfare

Dr. Rohit Kumar Sharma

2784448

Co-ordinator Swach Bharat Abhiyan

Dr. Shivani Sharma

2534921

Co-ordinator SC/ST Cell

Professor Anil Kumar

2534012

<!-- page 5 -->

FRONT PAGES

4

HANDBOOK OF INFORMATION 2022

TABLE OF CONTENTS
PART A

Page No.

1.

Profile

9

2.

Campus Offices & Activities

13

3.

Important Instructions

24

4.

Important Dates for Admissions

25

5.

Academic Calendar

26-27

6.

Rules of Admission / Reservation / Additional Seats

28-34

7.

Eligibility Conditions

34

8.

Inter-changeability and transfer of seats

34

9.

Admission based on JEE & CAT

35

10.

Preparation of Merit Lists/ Normalization of Merit.

35

11.
12.

Promotion Rules for choice based credit system
Admission to M.A. Semester I on the basis of Master’s Degree in another subject

36
36

13.

Compartment Candidates

36

14.

Admission to M.A. 3rd semester for outside Candidates

36

15.

Weightages

37

16.

Additional weightages

37

17.

Resolving of Ties

38

18.

Counseling

38

19.

Preparation of Merit List / Waiting List

38

20.

Admission of candidates whose results are revised (re-evaluation)

39

21.

Revision of Merit & Placement of Applicants

39

22.

Rejection of incomplete Admission Forms

39

23.

Cancellation of seats / Admission

39

24.
25.

Admission for Late Applicant with High Merit (only in case of offline admission form)
Checking of Certificates

40
40

26.

Gap Year (s)

40

27.

Verification of SC/ST Certificate

40

28.

Medical Check-up

40

29.

Difference in the Interpretation

40

30.

Guidelines for admission to the Reserved Category of Sport

41-43

PART-B

I) FACULTY OF ARTS
Ancient Indian History, Culture & Archaeology
Email ID : chairperson_aihca@pu.ac.in
Visit : https://aihca.puchd.ac.in/index.php
2
University Institute of Emerging Areas in Social Sciences
i) Social Work
Email ID : csw@pu.ac.in
Visit : https://socialwork.puchd.ac.in/index.php
ii) Police Administration
Email ID : policeadministration@pu.ac.in
Visit : https://policeadministration.puchd.ac.in/index.php
iii) Human Rights and Duties
Email ID : chairpersonhrd@pu.ac.in
Visit : https://humanrights.puchd.ac.in/index.php
3
Defence & National Security Studies
Email ID : danss@pu.ac.in
Visit : https://defencestudies.puchd.ac.in/index.php
4
Economics
Email ID : ecochairperson@pu.ac.in
Visit : https://economics.puchd.ac.in/index.php
5
Gandhian and Peace Studies
Email ID : gps@pu.ac.in
Visit : https://gandhianstudies.puchd.ac.in/index.php
1

0172-2534629

1

0172-2534983

2

0172-2534024

3

0172-2534548

4

0172-2720199

6

0172-2779140

8

0172-2541940

10

<!-- page 6 -->

FRONT PAGES

6
7
8
9
10
11
12
13
14
15
16
17
18
19
II)
1
2
3

Geography
Email ID : geogdept@pu.ac.in
Visit : https://geography.puchd.ac.in/index.php
Guru Nanak Sikh Studies
Email ID : jaspalkaurkaang@pu.ac.in
Visit : https://gnss.puchd.ac.in
History
Email ID : history@pu.ac.in
Visit : https://history.puchd.ac.in/index.php
Institute of Social Sciences Education & Research
Email ID : isser@pu.ac.in, swarnjit.k@pu.ac.in
Visit : https://isser.puchd.ac.in/index.php
Library & Information Science
Email ID : dlis@pu.ac.in
Visit : https://libraryscience.puchd.ac.in/index.php
Philosophy
Email ID : phildept@pu.ac.in
Visit : https://philosophy.puchd.ac.in
Political Science
Email ID : pol_chair@pu.ac.in
Visit : https://politicalscience.puchd.ac.in
Psychology
Email ID : chairperson_psycho@pu.ac.in
Visit : https://psychology.puchd.ac.in
Public Administration
Email ID : chairpersonpublicadmn@pu.ac.in
Visit : https://publicadministration.puchd.ac.in/
Sociology
Email ID : pusociology@pu.ac.in
Visit : https://sociology.puchd.ac.in
School of Communication Studies
Email ID : scs@pu.ac.in
Visit : https://scs.puchd.ac.in
Women’s Studies & Development
Email ID : womenstudies@pu.ac.in
Visit : https://cwsd.puchd.ac.in
Centre for the Study of Social Exclusion and Inclusive Policy
Email ID : csseip@pu.ac.in
Visit : https://csseip.puchd.ac.in/
Interdisciplinary Centre for Swami Vivekananda Studies
Email ID : icsvs@pu.ac.in
Visit : https://icsvs.puchd.ac.in/
University Business School
Email : ubschair@pu.ac.in
Visit : https://ubs.puchd.ac.in
University Institute of Applied Management Sciences
Email : uiams@pu.ac.in
Visit : https://uiams@pu.ac.in
University Institute of Hotel and Tourism Management
Email : uihmt@pu.ac.in
Visit : https://uihtm.puchd.ac.in

FACULTY OF DESIGN AND FINE ARTS

1

Art History & Visual Arts
Email: chairman_ahva@pu.ac.in
Visit : https://ahva.puchd.ac.in
Indian Theatre
Email: indth@pu.ac.in
Visit: https://indiantheatre.puchd.ac.in
Music
Email: music@pu.ac.in
Visit: https://music.puchd.ac.in

3

HANDBOOK OF INFORMATION 2022

0172-2534258

11

0172-2534319

13

0172-2534626

14

0172-2534426

16

0172-2541866

18

0172-2541840

19

0172-2534755

20

0172-2534542

22

0172-2541885

23

0172-2770054

25

0172-2541982

26

0172-2534768

29

0172-2534753

32

-

32

0172-2541591

34

0172-2780125

41

0172-2541969

45

0172-2534190

50

0172-2541870

51

0172-2534341

52

0172-2779517

53

FACULTY OF BUSINESS MANAGEMENT AND COMMERCE

III)

2

5

IV)

FACULTY OF EDUCATION

1

Community Education and Disability Studies
Email ID : ceds@pu.ac.in
Visit : https://ceds.puchd.ac.in

<!-- page 7 -->

FRONT PAGES

2
3
4
5

6

Education
Email ID : education@pu.ac.in
Visit : https://education.puchd.ac.in
Institute of Education Technology and Vocational Education
Email ID : ietve@pu.ac.in
Visit : https://ietve.puchd.ac.in
Life Long Learning
Email ID : dlll@pu.ac.in
Visit : https://lifelonglearning.puchd.ac.in
Physical Education
Email ID : chairmanphysicaleducation@pu.ac.in
Visit : https://physicaleducation.puchd.ac.in

V)

FACULTY OF ENGINEERING AND TECHNOLOGY

1

University Institute of Engineering and Technology
Email ID: directoruiet@pu.ac.in
Visit: https://uiet.puchd.ac.in
Dr. S.S. Bhatnagar university Institute of Chemical Engineering & Technology
Email ID : dcet@pu.ac.in
Visit : https://uicet.puchd.ac.in
University Centre of Instrumentation and Microelectronics
Email ID : rsic@pu.ac.in
Visit: https://ucim.puchd.ac.in

2
3

VI)

FACULTY OF LANGUAGES

1

Department of Chinese and Tibetan
Email ID : chairperson_ctl@pu.ac.in
Visit : https://ctl.puchd.ac.in/
Dayanand Chair for Vedic Studies
Email ID : dcvs@pu.ac.in
Visit : https://dayanand.puchd.ac.in/
Department of English and Cultural Studies
Email ID : chairperson_english@pu.ac.in
Visit: https://english.puchd.ac.in/
Department of French & Francophone Studies
Email ID : chairfrench@pu.ac.in
Visit: https://french.puchd.ac.in/
Department of German
Email ID : chairgerman@pu.ac.in
Visit: https://german.puchd.ac.in/
Guru Ravi Dass Chair of Sant Sahitya Studies
Email ID :
Visit : http://grdcsss.puchd.ac.in/
Department of Hindi
Email ID : hindidep@pu.ac.in
Visit: https://hindi.puchd.ac.in/
School of Punjabi Studies
Email ID :
Visit: https://punjabi.puchd.ac.in
i) Punjabi
ii) Bhai Vir Singh Chair
iii) Seikh Baba Farid Chair
iv) Shiv Kumar Batalvi Chair Professorship
v) Punjabi Lexicography
Department of Russian
Email ID: russian@pu.ac.in
Visit: https://russian.puchd.ac.in/
Department of Sanskrit
Email ID: skt@pu.ac.in
Visit : https://sanskrit.puchd.ac.in/
Department of Urdu / Persian
Email ID: urdu@pu.ac.in
Visit: https://urdu.puchd.ac.in/
Vishveshvaranand Vishwa Bandhu Institute of Sanskrit and Indological Studies,
Hoshiarpur
Email ID: vvbis@pu.ac.in
Visit: https://vvbisis.puchd.ac.in/

2
3
4
5
6
7
8

9.
10.
11.
12.

HANDBOOK OF INFORMATION 2022

0172-2534601

54

0172-2534381

57

0172-2541359

59

0172-2541438

60

0172-2541242

63

0172-2534901

69

0172-2541065

76

0172-2534685

78

0172-2534666

79

0172-2534638

79

0172-2534681

81

0172-2534683

83

0172-2534337,
0172-2541887

83

0172-2534616

84

0172-2534653

85

0172-2534273

87

0172-2534646

88

0172-2534936

90

01882-221002

91

<!-- page 8 -->

FRONT PAGES

VII)

FACULTY OF LAWS

1.

Department of Laws
Email: lawsdept@pu.ac.in
Visit: https://laws.puchd.ac.in
University Institute of Legal Studies (UILS)
Email: director_uils@pu.ac.in
Visit: https://uils.puchd.ac.in

2.

VIII)

7

Dr. Harvansh Singh Judge Institute of Dental Sciences & Hospital
Email: ssdental2007@gmail.com
Visit: https://dental.puchd.ac.in

IX)

FACULTY OF PHARMACEUTICAL SCIENCES

1.

University Institute of Pharmaceutical Sciences
Email: chairperson.uips@pu.ac.in
Visit: https://uips.puchd.ac.in

X)

FACULTY OF SCIENCE

1.

Department of Anthropology
Email: anthro@pu.ac.in
Visit: https://anthropology.puchd.ac.in/
Department of Biochemistry
Email: biochem@pu.ac.in
Visit: https://biochemistry.puchd.ac.in/
Department of Biophysics
Email: chairpersonbiophysics@pu.ac.in
Visit: https://biophysics.puchd.ac.in/
Department of Biotechnology
Email: chairperson_biotech@pu.ac.in
Visit: https://biotechnology.puchd.ac.in/
Department of Botany
Email: chairman.botany@pu.ac.in
Visit: https://botany.puchd.ac.in/
Department of Chemistry
Email: chemdept@pu.ac.in
Visit: https://chemistry.puchd.ac.in/
Department of Computer Science & Applications
Email: chairpersondcsa@pu.ac.in
Visit: https://dcsa.puchd.ac.in/
Department of Environment Studies
Email: devs@pu.ac.in
Visit: https://devs.puchd.ac.in/
Department of Geology
Email: chairperson_geology@pu.ac.in
Visit: https://geology.puchd.ac.in/
Department of Institute of Forensic Science & Criminology
Email: ifsc@pu.ac.in
Visit: https://ifsc.puchd.ac.in/
Department of Mathematics
Email: casmath@pu.ac.in
Visit: https://maths.puchd.ac.in/
Department of Microbiology
Email: micro@pu.ac.in
Visit: https://microbiology.puchd.ac.in/
Department-cum-National Centre for Human Genome Studies & Research
Email: genome.human@pu.ac.in
Visit: https://humangenome.puchd.ac.in/
Department of Physics
Email: physics@pu.ac.in, rkpuri@pu.ac.in
Visit: https://physics.puchd.ac.in/
Department of Statistics
Email: chstats@pu.ac.in
Visit: https://statistics.puchd.ac.in/
Centre for Medical Physics
Email: medphys@pu.ac.in
Visit: https://medicalphysics.puchd.ac.in/

3
4
5
6
7
8
9
10
11
12
13
14
15
16

0172-2534157,
58

95

0172-2536105

97

0172-2534686

102

0172-2534101

105

0172-2541998

109

0172-2534131

110

0172- 2534119

113

0172- 2534085

115

0172- 2779510

116

0172-2534414

118

0172-2534063

123

0172-2783817

124

0172-2534235

125

0172-2534125

127

0172- 2534528

128

0172-2534140

132

0172-2534109

134

0172-2541741

135

0172-2541776

139

0172-2534591

140

FACULTY OF MEDICAL SCIENCE

1.

2.

HANDBOOK OF INFORMATION 2022

<!-- page 9 -->

FRONT PAGES

17
18
19
20
21
22
23
24

8

Department of Microbial Biotechnology
Email: chairdmbt@pu.ac.in
Visit: https://microbialbiotechnology.puchd.ac.in
Centre for Nano Science & Nano Technology
Email: aroras@pu.ac.in
Visit: https://physics.puchd.ac.in/nsnt/
Centre for Nuclear Medicine
Email: coordnucmed@pu.ac.in
Visit: https://nuclearmedicine.puchd.ac.in/
Centre for Public Health
Email: cphpu@pu.ac.in
Visit: https://publichealth.puchd.ac.in/
Centre for Stem Cell Tissue Engineering
Email: cste2008@pu.ac.in
Visit: https://stemcell.puchd.ac.in/
Centre for Systems Biology & Bioinformatics
Email: csbb2007@pu.ac.in
Visit: https://systembiology.puchd.ac.in/
Department of Zoology
Email: zoologychair@pu.ac.in
Visit: https://zoology.puchd.ac.in/
University Institute of Fashion Technology & Vocational Development
Email: uift@pu.ac.in
Visit: https://uift.puchd.ac.in/

XI)

MULTI FACULTY DEPARTMENTS

1.

Department of Evening Studies – MDRC
Email: chairperson_devs@pu.ac.in
Visit: https://des.puchd.ac.in/
University School of Open Learning
Email: usol@pu.ac.in
Visit: https://usol.puchd.ac.in
Panjab University Regional Centre, Sri Muktsar Sahib
Email: directorpurcmkt@pu.ac.in
Visit: http://purcm.puchd.ac.in
Panjab University Rural Centre, Kauni, Muktsar
Email: purckauni@pu.ac.in
Visit: http://purckauni.puchd.ac.in/
Panjab University Regional Centre, Ludhiana
Email: dirpurcldh@pu.ac.in
Visit: https://purcl.puchd.ac.in
UBS Regional Centre, Ludhiana
Email: dirpurcldh@pu.ac.in
Visit: https://purcl.puchd.ac.in
Panjab University Swami Sarvanand Giri Regional Centre, Hoshiarpur
Email: directorhsp@pu.ac.in
Visit: https://ssgpurch.puchd.ac.in

2.
3.
4.
5.
6.
7.

HANDBOOK OF INFORMATION 2022

0172-2536161

141

0172-2534148

142

0172-2534141

144

0172-2541441

145

0172-2534197

146

0172-2534603

146

0172-2534201

148

0172-2544086

150

0172-2782511

153

0172-2541143

159

01633-261489

161

01633-280280

162

01612-443830

164

01612-443830

165

01882-282221

167

PART-C
1.
2.
3.
4.
5.
6.
7.
8.
9.

Fee Structure
General Refund of Fee rules
Scholarships / Stipends
Attendance Rules
Fee Migration Form / transfer of fee
Sports Annexures
Specimens of Certificates of Reserved / Additional Seats
List of Fake Universities
Anti-Ragging

1
3
9
18
22
23-27
28-43
44
45

<!-- page 10 -->

FRONT PAGES

9

HANDBOOK OF INFORMATION 2022

Shaan-o-Shauqat
PANJAB UNIVERSITY ANTHEM

Tamso ma jyotirgamaya
Tamso ma jyotirgamaya
Tamso ma jyotirgamaya
Tamso ma jyotirgamaya
Panjab vishawvidyalaya
Teri shaan-o-shauqat sada rahe
Mann mein tera aadar maan
Aur mohabbat sada rahe
Panjab vishawvidyalaya
Teri shaan-o-shauqat sada rahe
Tu hai apna bhavishya vidhata
Pankh bina parwaaz sikhata
Jeevan pustak roz padhakar
Sahi galat ki samajh badhata
Jeevan pustak roz padhakar
Sahi galat ki samajh badhata
Teri jai ka shankh bajayein
Roshan tare ban jaayein
Vakhari teri shohrat
Teri shohrat sada sada rahe
Panjab vishawvidyalaya
Teri shaan-o-shauqat sada rahe
Panjab vishawvidyalaya
Teri shaan-o-shauqat sada rahe
Tamso ma jyotirgamaya
Tamso ma jyotirgamaya

<!-- page 11 -->

FRONT PAGES

10

HANDBOOK OF INFORMATION 2022

PANJAB UNIVERSITY- A PROFILE






Ranked 2nd in Atal Ranking of Institutions on Innovation Achievements (ARIIA)-2021 in category of University &
deemed to be University (Govt. & Govt. Aided) (Technical).
Ranked as 4th best university in India by the US News - Best Global University Rankings. The global rank of PU is 577.
Ranked 601-800 in the Times Higher Education World Ranking (2022).
Ranked 23rd in the university category and 38th in the overall institutions of Higher Education in India rankings by India
rankings (2021) by NIRF, MHRD, Government of India.
NAAC accredited A grade with a score of 3.35 out of 4 valid from 25/06/2015

Brief History and Profile of PU
Panjab University (PU) is one of the oldest Universities in India, initiated at Lahore in 1882. The PU has a long tradition of
pursuing high quality in teaching and research in science & technology, humanities, social sciences, performing arts and
sports. The University has provided excellence support in innovative academic programmes, promotes research,
scholarship, awards and incentives. The University is committed to attract and support the best students and faculty, who
excel at teaching and research. In independent India, Panjab University with its Campus at Chandigarh and nearly two
hundred colleges in Punjab and Chandigarh, has served various societal needs with distinction. The glorious traditions of
the University established during the period of more than 139 year of its long service to the nation since its inception are a
source of inspiration for the present generation of faculty members and students. By virtue of its history, experience,
achievements and philosophy, the Panjab University has a national character and it enjoys an international stature drawing
both faculty and students from all over the country and different parts of the globe. Its faculty includes some of the most
distinguished scientists and academicians. It continues to attract celebrated scholars at the campus. Over the years, the
reputation of the Panjab University has grown to emerge as an institution at the pinnacle in innovative teaching, research
and community outreach.
In Chandigarh, Panjab University Campus, a beautiful red sandstone campus was designed for University by Pierre
Jeanneret under the general guidance of Le Corbusier. The Panjab University was moved towards Chandigarh during 19581960, till the reorganisation of Punjab in 1966, the University had its regional centres at Rohtak, Shimla and Jalandhar. Its
affiliated colleges were located in the States of Punjab, Haryana and Himachal Pradesh and the Union Territory of
Chandigarh. With the re-organization of Punjab, the University became an Inter-State Body Corporate subsequent to the
creation of a separate Punjab and Haryana. Currently the Panjab University has affiliated colleges in the Union territory of
Chandigarh and some parts of Punjab.
The Panjab University Campus at Chandigarh accommodates 78 teaching and research departments/institutes/centres
besides four independent Chairs for research. The University School of Open Learning, a multi-disciplinary department,
caters to about 15,000 distance learners and offers more than two dozen traditional and job oriented courses. The
university has 200 affiliated and 6 constituent colleges spread over Punjab and Chandigarh besides Regional Centres at
Muktsar, Ludhiana, Hoshiarpur and Kauni. In addition, there is the Vishveshavaran and VishwaBandhu Institute of
Sanskrit and Indo logical Studies at Hoshiarpur.

The Campus

Panjab University is located in Sector 14 and Sector 25 of Chandigarh, spread across an area of almost 550 acres.
The layout of two campuses of the University has been conceived to meet the academic, administrative, sports/
recreational, residential and other requirements of a growing University. To make it self-contained, infrastructural
facilities like its own Shopping Centre, health Centre, Bank, Post office, Swimming Pool, Gymnasium, Sports Grounds,
Botanical Gardens, well maintained parks, Open Air Theatre, Guest Houses, faculty House, Seminar Complexes, Alumni
House, Community Centre and a School, have been provided. Besides these facilities, the University Campus has 8 hostels
for boys, 10 hostels for girls, a Working Women’s Hostel, one International Students Hostel and 2 Sports Hostels (one for
boys and one for girls).
A cluster of prominent buildings like the Gandhi Bhawan, the Fine Arts Museum, the University Library and the Student
centre from the hub of social interaction. The Gandhi Bhawan, Student Centre, the University Library and the University
Administrative Block are also considered part of the architectural heritage of Chandigarh, being examples of modernism in
architecture as it was interpreted by Le Corbusier and those who worked with him. The Fine Arts Museum, with its series
of small galleries arranged around a courtyard, each gallery having a hyperbolic parabolic roof (umbrella shaped), is not
only an 20 Nos. Five Storey T-III flats were constructed and handed over to the residents Lifts have been provided for the
convenience of the residents Power back-up has been provided for the smooth running of the lifts in case of power failure.
The Construction of following buildings were started during the last year:
1. Const. of two storeys of Girls Hostel No. 11 in PU South Campus, Sector-25.
2. New building for Human Resource Development Centre in P.U. South Campus, Sector-25.
3. Building for Centre for Academic Leadership and Education Management (CALEM) for Education Deptt. In P.U. South
Campus, Sector 25.

Internet and Communication Facilities

Dr. A.P.J. Abdul Kalam Computer Centre of the University provides Fibre Optic high speed network connectivity through
Gigabit technology to all the Departments, Centres, Hostels and Administrative Block. The Computer Centre is connected
through National Knowledge Network (NKN) and the National Mission of Education through Information and
Communication Technology (NMEICT) networks. All the hostels and Academic areas of Sector 14 and Sector 25 are
covered by Wi-Fi and students and staff can access it seamlessly. The Computer Centre is hosting all the servers (like
DNS, Mail, web Server) and providing facilities like online admissions and entrance tests.

<!-- page 12 -->

FRONT PAGES

11

HANDBOOK OF INFORMATION 2022

Other Facilitating Centres

Regional Sophisticated Instrumentation Centre, Energy Research Centre, Centre for the Study of Social Exclusion and
Inclusive Policy, Centre for IAS & Other Competitive Examinations, Centre for Industry Institute Partnership Programme,
Centre for Medical Physics, Centre for Study of Mid-West & central Asia, Centre for the Study of Geopolitics, and Centre for
Swami Vivekananda Studies are other facilitating centres providing services at the University.
The AC Joshi Library is housed in a centrally located 5 storeyed building with a seating capacity of 800 readers. It has
approximate 8 lakh collection of 1490 manuscripts. The library is fully computerized with facility of self-check in/checkout issue/ return of books. The Library is subscribing to 309 current periodicals including online and print journals etc.
The Library has subscribed to 19 e-resources including Science Direct, Scopus, IEEE, ACM Digital Library, Institute of
Physics, EBSCO, Proquest Dissertation & Thesis Abstracts, India-stat, etc. The library is also getting access to 15 databases
in different disciplines through e-shodh sindhu consortium of INFLIBNET. In totality, the Library is providing access to
about 15000 + core and peer reviewed on-line journals with links on the library website. The Library is providing e-library
services for the registered users of the University through which the faculty, researchers and students of Panjab University
can access thousands of e-journals, e-books and databases from anywhere 24x7. The e-library platform also provides
mobile e-library app (for both Android and ios) which is a multi-format, content delivery app.
The library has digitized and uploaded 7786 theses on the Shodhganga platform. The Library is one of the six national
document delivery centres of INFLIBNET for data information and also member of JCC for document delivery.
The AC Joshi Library implemented “earn while One Learn Scheme” which is now successfully implemented in the
University under which the students are working in the various departments and earning for their education.
The A.C. Joshi Library has a special facility on the ground floor for the visually impaired students, which provides PCs with
the JAWS and Zoom-Ex-software. Also it is equipped with the latest Horizon A3 Scanner Lex Software with English and
Hindi Voice pack and Hindi OCR to assist them in their studies.

PU Radio

Panjab University Community Radio Station (CRS)-Jyotirgamaya 91.2 MhZ. The community radio station of Panjab
University was inaugurated on 13th February, 2011 and is acting as a unifying agent amongst the university faculty,
students and also the community. The station offers 3 sessions of broadcasts every day for over 12 hours duration. The
radio programmes can be heard over a range of 10 Kms and the listenership base is on the rise.
The aim of setting up the CRS is to impart knowledge and information related to education, health and environment, social,
cultural and local issues and to provide a platform for dialogue and discussion amongst the community members, students
and faculty. Jyotirgamaya serves as a platform for awareness generation, education and experience sharing with the
community in the vicinity of the CRS. The students of the school, volunteers from other departments, interns and
community members, with active help of the faculty and staff, generate the content. Community participation in the CRS is
encouraged and the station takes measures, such as providing internship to students and training to interested members of
the public. The doors of the CRS are open for all residents of the communities
The Jyotirgamaya 91.2 has broadcast several program and campaigns during the pandemic to create awareness about the
COVID-19 scenario in collaborations with UNICEF, Health Ministry and Community Radio Association of India during 201922.
Jyotirgamaya is setting new benchmarks every day. “HamariBeti” run by PU CRS was awarded by the Public Relations
Council of India for its uniqueness. It has also been awarded a project from National Council for Science and Technology,
Gol, New Delhi with Punjab State Council of Science and Technology for production of radio programmes on Women’s
Health and Nutrition. The programme called ‘SehatkaVardaan, NaarikaSamman’ has covered 365 topics on women’s
health. The station was able to connect the community with experts from the fields of Medicine, Social Welfare, Nutrition,
and Administration.

Hostels

There are eighteen multi-storey hostels on the Campus. Eight of these are for boys and ten for girls. There is one Working
Women Hostel which is equipped with all modern facilities. There is also an International Hostel to accommodate
international faculty/students. Hostel seats are limited and are provided purely on merit basis to the Campus students.
Number of seats available is displayed on the University web site well before the start of admission. A Sports Hostel is also
there for visiting sports teams. One more hostel for girls particularly Research Scholar is being constructed. Proposal for
extension of one boys and one girls hostel is also forwarded to the Ministry of Social Justice & Empowerment.
The residents are required to observe the rules printed in the Handbook of Rules for Residents of the Panjab University
Hostels.

Health

Bhai Ghanaiya Ji Institute of Health’ provides primary health facilities to its employees including retirees, their dependent
children, parents and all students and hostel inmates of this University. The existing infrastructure has been thoroughly
upgraded. 24x7 emergency and ambulance services are available to all ‘c’ class employees and student community of
Panjab University even during lockdown due to Covid -19. The Institute has a fully equipped modern clinical laboratory,
latest computerized ECG machine, a fully-computerized 500mA X-Ray unit. All routine OPD and some specialists services
are available to all bonafide patients. Free medical camps and patient health awareness camp are organized round the
year.

Sports

The University has won the Maulana Abdul Kalam Azad Trophy for the session 2021 for excellence in games and sports at
International & All India Inter-University level Championship.
The University has playgrounds for all major sports. There is an air conditioned gymnasium hall, an international level
Swimming Pool, Diving Pool, all Weather Swimming Pool, 400m grassy Athletic Track (8 lanes), two cemented Basketball
courts with flood lights, four Volleyball courts, one Hockey ground, one Hockey Astroturf, two football grounds two KhoKho courts, two Kabaddi courts, three Softball grounds, Cricket grounds and five pitches, one Netball ground, one korfball

<!-- page 13 -->

FRONT PAGES

12

HANDBOOK OF INFORMATION 2022

ground, two Synthetic Lawn Tennis Courts, six grassy Lawn Tennis Courts, Outdoor Gymnastics Arena, Outdoor Boxing
Arena, Two Multipurpose hall for indoor games, Gym for Boys, Gym for Girls, Weight lifting hall, highly equipped
Physiotherapy Centre. An international standard 10 meter shooting range is also functional on PU Campus.

Achievements of Panjab University
•
•
•
•

•
•
•
•
•
•
•
•
•
•

Panjab University, Chandigarh has won Maulana Abul Kalam Azad(MAKA) Trophy for overall top performing
University in Inter University Tournaments for 3rd Year in a row which is also the hat trick for PU, from Sh. Ram Nath
Kovind Ji, Hon’ble President of India.
Dr. Harvansh Singh Judge Institute of Dental Sciences & Hospital, Panjab University, Chandigarh ranked 17th Best
amongst the Dental Colleges in the country and 10th Best amongst Government Dental Colleges all over India, by The
Week survey. In the India Today Ranking of best Dental Colleges the institute ranked 23rd.
In World University Rankings 2022 published by TIMES on 02.09.2021, Panjab University has been ranked 7th among
these 71 institutes and has secured 601-800 global rank.
University Institute of Pharmaceutical Sciences (UIPS), Panjab University, Chandigarh, has been ranked number 2
among the Pharmacy institutions across the Nation consecutively for the third time, since 2018. The ranking was
declared under National Institutional Ranking Framework (NIRF) organized by Ministry of Education (MoE),
Government of India.
Panjab University (PU) has bagged the 'First National Rank' in Innovation, Start-up and Entrepreneurship
Development among the government and aided (state-run and deemed) universities in the Atal Ranking of Institutions
on Innovation Achievements (ARIIA).
A seven-member student team from Design Innovation Centre(DIC), Panjab University has been funded Rs.5,50,000/by MHRD, Institution’s Innovation Council(IIC) for developing a Filament Extruder Machine START-UP.
Panjab University Alumni Association celebrated 75th Independence day by inaugurating the Green House at Alumni
house, Sector-25, Panjab University, for the controlled growth of exotic plants.
Five students of the Centre for Medical Physics, Panjab University, Chandigarh, have been selected as Radiation Safety
Officer, Class-I, (Gazetted) in the Department of Medical Education, Himachal Pradesh.
32 faculty scientists from various disciplines from Panjab University are included in the elite list of world top 2%
scientists as per the Stanford University, Stanford, California, USA
Panjab University got 1st position in Folk Dance of Boys (Jhoomar), 2nd Prize in Folk Song and 3rd prize in individual
folk dance (Kathak) in the Inter-Zonal Youth Festival held at A S College, Khanna, Punjab between December 14 to 19,
2021. Panjab University got 1st position.
Panjab University (PU), Chandigarh has been placed 1 st rank in Atal Ranking of Institutions on Innovation
Achievements (ARIIA)-2021 in category of University & Deemed to be University (Govt. & Govt. Aided) (Technical).
University Institute of Pharmaceutical Sciences (UIPS) PU secured second place amongst pharmacy instructions in the
country as per NIRF India Ranking 2021.
Panjab University under the National Institutional Ranking Framework 2021 was at 38 th rank among all the academic
institutions in the country and ranked 23rd the top 100 universities in India.
In a recently, released world ranking for 2021-2022 edition by “Centre for World Ranking University (CUWR)”, Panjab
University (PU) has been placed in the top 3.6% worldwide.

<!-- page 14 -->

FRONT PAGES

13

HANDBOOK OF INFORMATION 2022

CAMPUS OFFICES AND ACTIVITIES
DEAN OF UNIVERSITY INSTRUCTION
Professor Renu Vig, Dean of University Instruction

The office of Dean of University Instruction (DUI) works as a nodal centre to scrutinize, supervise and synergize academic
and administrative activities of teaching departments of Panjab University and its Regional Centres. The office coordinates and supervises various activities including admission of students to various University Departments, decides
applications for exemption from payment of tuition fee, submits to the Academic Council Time-Tables of all University
classes, arranges the accommodation of all University classes, oversees that discipline and routine of work in all University
classes in maintained, calls for and examiners proposals from affiliated colleges for permission to start Honours classes, coordinates wherever necessary, the work of the University teaching departments, sanctions casual leave to the members of
the teaching staff, operates the accounts of Amalgamated Fund allocated for academic activities of students, makes
arrangements for extension lectures and recommends to the Vice Chancellor delegates to the various conferences.

RESEARCH & DEVELOPMENT CELL
Professor Sudhir Kumar, Director, Research & Development Cell

Introduction
The National Education Policy (NEP) 2020 envisages the promotion of quality research within the Higher Education system.
Research and innovation are important aspects to enhance quality education by the Higher Education Institutions (HEIs).
Societal challenges of our country can only be addressed by having a strong and vibrant higher education ecosystem with
an emphasis on research, innovation, and technology development. The integration of Research, Innovation and
Technology Development is the foundation of Atma-Nirbhar Bharat (Self-reliant India). The establishment of Research and
Development Cell (RDC) in Panjab University, Chandigarh is aimed at enabling the attainment of targets of Atma-Nirbhar
Bharat and is expected to play a crucial role in catalyzing multidisciplinary / transdisciplinary and translational research
culture mandated in NEP 2020.
Vision
To put in place a robust mechanism for developing and strengthening the research ecosystem within the University in
consonance with the provisions of NEP-2020.
Mission

To create a congenial ecosystem for enhanced research productivity.

To promote collaboration across industry, government, community- based organizations, and agencies at the
local, national, and international levels.

To facilitate greater access to research through optimum utilization and mobilization of existing resources and
funding.
Objectives
1. To build an organizational / intra-institutional structure with role-based functions of RDC, formulate Research
Policy for the University, identify thrust areas of research, and form related cluster groups/ frontline teams /
consortia of researchers.
2. To help the University create Research Policies for recruitment of research personnel, procurement of equipment,
and financial management with sufficient autonomy to the Principal Investigator(s) and propagate research
outcomes to stakeholders and the public at large.
3. To put in place policies to promote researchers and innovators, identify potential collaborators from industry,
research organizations, academic institutions & other stakeholders for cooperation and synergistic partnerships.
4. To act as a mediator between researchers & relevant research funding agencies, provide guidance in preparation &
submission of project proposals and post-sanctioning of the grants to supervise adherence to timelines.
5. To create mechanism for coordination among other cells/centers dealing with University-Industry Inter Linkage,
Incubation, Innovation and Entrepreneurship Development and Intellectual Property Rights (IPR).
6. To develop an Institutional Research Information System through IQAC for sharing the status of ongoing/ completed
research projects/Programmes, expertise & resources, etc., making effective use of Information & Communication
Technology (ICT) for preparing the database of in-house experts to provide industrial consultancy and services.
7. To engage & optimally utilize the services of superannuated active faculty/scientists in research capacity building of
talented young minds and promote mobility of researchers across institutions and R&D Labs.
8. To serve as nodal center for ideation and conceptualization of research topics/themes, across the disciplines, by
organizing workshops and training programs and ensuring the integrity and ethical practices in research activities
including clearance of ethical committee wherever and whenever needed.
Functions
The establishment of the RDC would facilitate the creation of a research ecosystem for impactful and sustained research output.
The essential elements of such an ecosystem, viz., generation of knowledge and facilitation of research, innovation and technology
development for industrial & societal benefits, are addressed by human resource (researcher & faculty), intellectual capital
(knowledge & skills), governance (regulation & policies) and financial resources (funding & grants).

INTERNAL QUALITY ASSURANCE CELL
Professor Sanjeev Sharma, Director
Professor Anuradha Sharma, Associate Director
Ms. Monika Rani, System Administrator
Internal Quality Assurance Cell (IQAC) was established in Panjab University as a post-accreditation quality sustenance and
enhancement measure. IQAC submits data for Annual Quality Assurance Reports and Self-Study Report of Panjab

<!-- page 15 -->

FRONT PAGES

14

HANDBOOK OF INFORMATION 2022

University to NAAC. It also handles work of data submission to various National & International Ranking Agencies and
survey related activities of data collection, compilation and transmission to various agencies like UGC, MHRD etc. The data
is collected online from various departments and regional centers with the help of Intranet software (Information resource
Portal) and the compiled information is used for dissemination to various agencies. The portal is structured and designed
so as to fulfill information requirements of various NAAC parameters and other ranking frameworks. This software has
benefitted the university in terms of decreased time in quality data collection, analysis and compilation with increased
efficiency.
The various rankings (National/International) of the university such as Times Higher Education ranking, QS Ranking, India
Ranking (NIRF), Atal Ranking of Institutions on Innovation Achievements (ARIIA) etc. are also being handled by this cell.
All India Survey of Higher Education (AISHE) project of MHRD, through which the data of PU and its affiliated colleges is
uploaded every year on the AISHE Portal is one of the key activity of this cell.
IQAC has its mandate as stipulated by NAAC and consists of:
•
To develop a quality system for conscious, consistent and catalytic programmed action to improve the academic and
administrative performance of the University;
•
To promote measures for institutional functioning towards quality enhancement through internalization of quality
culture and institutionalization of best practices.

DEAN OF STUDENT WELFARE
Professor Jagtar Singh, Dean Student Welfare
Professor Roopali Garg, Dean Student Welfare (Women)
Professor Ashok Kumar, Associate Dean Student Welfare
The Dean Student Welfare (Men), Dean Student Welfare (Women) & Associate Dean Student Welfare look after the
functioning of the University hostels, conduct of election to the student bodies, planning and organizing of cultural, extracurricular activities, disburse cultural scholarships and financial assistance to campus students.
The Office of the DSW is located in the Student Centre. It has the following constituents to promote the general welfare of
the Campus students.
Panjab University Campus Students’ Council: Panjab University Campus Students’ Council is elected to promote healthy
corporate life, ensure maintenance of proper academic atmosphere and orderliness, help in allocation of Amalgamated
Fund for different authorized purposes and activities connected with student welfare and to assist in organizing various
cultural and sports functions on the Campus.
Campus Reporter: This is an annual multilingual publication for circulation amongst the students and the faculty on the
Campus. It aims at providing a forum for expression to the students and is published with their active cooperation. The
students are promoted to develop their literary skills.
Campus Representation in Cultural & Literary Competitions: The Campus teams are selected, trained to participate in
inter-College and inter-University Cultural and Literary competitions. The performance of these teams has been
outstanding and they have been annexing trophies and overall best awards for the last many years. Also organize Intercollege, Campus/zonal competitions, hiking and trekking expeditions, rock climbing, mountaineering and youth leadership
training camps.
Educational Tours: Subsidized educational tours are undertaken by students under different educational programmes.
Students Scholarships: The Office of the DSW is providing the following subsidies/financial assistance/scholarships to
the Campus students as per rules/terms & conditions laid-down by Panjab University:1. Need Based Assistance, Need-cum-Merit and Scholarships for Handicap Students: These scholarships are paid for
nine months a year to the students recommended by the Chairpersons as per conditions laid-down for the award
out of “Students Scholarship Fund”.
2. Sports Scholarships: This scholarship is awarded on the basis of the grading done by the Sports Department
based on the performance of the Campus students in various sports activities. This scholarship is paid for nine
months a year out of “Students Scholarship Fund”.
3. Extra-mural Activities Scholarship: This scholarship is paid out of the “Amalgamated Fund”. The performance of
the Campus students in various Extra-mural activities like debates, seminars, one-act play etc. is the deciding
factor for award of the scholarship. This scholarship is a fixed amount to be decided by the Vice-Chancellor on
the recommendations of the Committee.
4. Financial Assistance: Financial assistance is paid out of “Poor Students Welfare Fund” to the deserving P.U. Hostel
residents.
5. Food Subsidy: Food subsidy is also paid to the needy hostel residents. The recipients of food subsidy will do
some duty/work in the hostel as may be assigned by the Warden.
Student Centre: Student Centre is housed in an attractive cylindrical building almost at the Centre of the University
Campus. It has an indoor games section on the first floor, Placement Cell for the benefit of the Campus Students on the 2 nd
floor and houses a modern South India Cafeteria. The shops adjoining Student Centre are mainly run for the convenience
of Campus students. An ATM facility has also been provided at the Student Centre.
Hostels: There are eighteen multi-storey hostels on the Campus. Eight of these are for boys and ten for girls. There is one
Working Women Hostel which is equipped with all modern facilities. There is also an International Hostel to accommodate
international faculty/students. Hostel seats are limited and are provided purely on merit basis to the Campus students.
Number of seats available is displayed on the University web site well before the start of admission. A Sports Hostel is also
there for visiting sports teams. One more hostel for girls particularly Research Scholar is being constructed. Proposal for
extension of one boys and one girls hostel is also forwarded to the Ministry of Social Justice & Empowerment.

<!-- page 16 -->

FRONT PAGES

15

HANDBOOK OF INFORMATION 2022

The residents are required to observe the rules printed in the Handbook of Rules for Residents of the Panjab University
Hostels.

VIGILANCE CELL
Professor Rattan Singh, Chief Vigilance Officer (Additional Charge)
The Chief Vigilance Officer is to advice the Vice-Chancellor on vigilance complaints concerning the University offices, staff
and teaches as well as to ensure probity and integrity in public administration with following objectives:
1. To activate the vigilance machinery in the University for investigating complaints.
2. To sensitize the University community against corruption and corrupt practices
3. To strengthen preventive vigilance by streamlining procedures and
4. To provide the possibilities of corruption and encourage a culture of honesty and integrity
In line with the national-wide initiative of the Central Vigilance Commission, Vigilance Awareness Week is observed every
year by teaching faculty, non-teaching staff and students of the Panjab University. The Vigilance Cell is located in the
Administration Block of the Panjab University.

DEAN INTERNATIONAL STUDENTS
Professor Deepti Gupta, Dean International Students

The office of the Dean, International Students (DIS) looks after the welfare of the international students and maintains
liaison with university authorities and outside agencies. It maintains close liaison with the Indian Council for Cultural
Relations (ICCR) with regard to their Programmes for the International Students. It also coordinates with the Dean of
University Instruction, Dean of Student Welfare, Dean of Alumni Relations, as well as Principals of Affiliated Colleges in
Chandigarh with regard to the welfare of International students and maintain & links with International Alumni.
The office of the Dean of International Students facilitates the international students body in organizing their cultural
functions/sports etc. The office organizes various activities such as orientation-cum-cultural exposure programme, English
language and soft skills workshop, cultural and literary, lectures and activities, extra-curricular activities and at the end of
academic session plans annual-cum-farewell function, sensitization lectures, educational lectures including web-lectures &
webinars.
The students wishing to join any of the University Teaching Departments / Colleges affiliated to the Panjab University, for
the first time are required to obtain an eligibility / equivalence certificate. This certificate is issued by the Deputy Registrar
(General) Panjab University, Chandigarh. The request form for issuance of eligibility certificate is available at
https://forms.puchd.ac.in.
For any enquiry, contact the office of the Deputy Registrar (General) at telephone nos. +91-172-2540385, +91-172 2534857, +91-172 -2534862 and email: drgen@pu.ac.in
International students can approach this office for advice and assistance in finding a suitable hostel or residential
accommodation in Chandigarh. The students requiring expenditure certificate or assistance with their remittances are
advised to contact the office of DIS.
International students admitted to various Panjab University Teaching Departments / Local Affiliated Colleges are
required to pay ‘Foreign Students Welfare Fee’ as prescribed by Panjab University.
About 360 international students have been pursuing undergraduate, postgraduate courses and Doctoral Degree courses
at Panjab University and its local affiliated colleges. Seats are available for Non-Resident Indian (NRI) candidates. Foreign
Nationals sponsored by Government of India can seek admission if they are otherwise eligible.
Candidates provisionally selected for Post Graduate/Undergraduate admission shall be issued provisional admission
letters to facilitate their students visa process. The final admission would be based only on production of passport and
student Visa. All rules and regulations of Panjab University will apply to foreign students as well.
Note:
1. For further information, please visit the webpage http://dis.puchd.ac.in./. You may also email the office at
dis@pu.ac.in
2. The office can also be contacted at the following telephone numbers : +91-172-2541873 & 2534574

DEPARTMENT OF YOUTH WELFARE
Dr. Rohit Kumar Sharma, Director Youth Welfare
The Department of Youth Welfare, being an important part of the University, working for the overall development of the
students, was set up in 1958 under the Directorship of Dr. K. C. Anand as Founder Director and at present Dr. Rohit Kumar
Sharma is heading the department with an objective of nurturing the young minds and for their balanced growth and
development. The Department of Youth Welfare organizes a number of activities every year. As the department encourages
the young students to come forward and prove themselves by participating in various creative activities in the same way
the active participation of the students in these activities encourage the department to provide them more and more
opportunities for their overall development.
Keeping in view the above mentioned scenario the department organizes chain of activities as Youth Leadership Training,
Hiking Trekking & Rock climbing Camp, Panjab University Zonal Youth & Heritage Festival, Panjab University Inter Zonal
Youth & Heritage Festival, North Zone Inter University Youth Festival, All India Open National Youth Festival and All India
Inter University National Youth Festival. Department of Youth Welfare is successfully running Student Holiday Home
(Youth Hostel) Chandigarh to serve the students and teachers simultaneously Student Holiday Home at Dalhousie is also
being managed by the department.

<!-- page 17 -->

FRONT PAGES

16

HANDBOOK OF INFORMATION 2022

The Department is always aim at the holistic development of their students and endeavour to raise youth as responsible
citizens and perfect human beings. To keep their creative powers ignited and establishing their connection with the rich
cultural and heritage of Punjab. Youth Festivals has been organized every year.
Online Ten Days Youth Leadership Training Camp cum Workshop was organised from August 2 to 11, 2021 in which 449
students and 15 teachers participated from affiliated and constituent colleges. The theme of the workshop was ‘Inspire,
Engage and Enable’.
During the session 2021-22, to motivate our students after pandemic period, the Department of Youth Welfare took a step
to organize workshops, seminars, recreational competitions. About twenty thousand students from university campus,
affiliated and constituent colleges, have participated in Panjab University Zonal and Inter-Zonal Youth and Heritage
Festivals organized by the Department during the months of November and December 2021. “Love and Respect the Nature”
was the theme of Panjab University Youth Festivals conducted by the department in this session.
The 8th edition of the annual magazine of the department “Jawan Tarang” is almost ready to publish. This magazine has
been published since 2013 to provide ample opportunity to young students to express their emotions, opinion, dreams and
aspirations. It carries contributions in the form of creative writings, from the students of affiliated and constituent colleges
of the Panjab University along with the record of the various youth activities of the department.

DEPARTMENT OF NSS
Professor Ashwani Koul, Programme Coordinator

Today’s world is facing numerous challenges like the Covid Pandemic, rising population, Climate Disruption, Rising income
inequality, gender inequality and various forms of social injustice to name a few. NSS department gives a unique platform
to students to enhance their problem-solving capabilities and thus these volunteers can contribute immensely in dealing
with these societal and ecological issues. The idea is to nurture a sense of social and civic responsibility towards the
society. To ensure overall development of the students, NSS platform can help in imparting requisite leadership qualities
and democratic attitudes so as to ensure welfare of the society. According to Winston Churchill, British statesman who as
prime minister of the United Kingdom rallied British people during World War II and led the country from the brink of
defeat to victory, “We make a living by what we get, but we make a life by what we give.” Even Albert Einstein, a great
scientist who revolutionized our understanding of space, time, gravity, and the universe has once said, “Only a life lived for
others is a life worthwhile.” Therefore, NSS volunteers have the opportunity to live a meaningful life by adhering to this
principle of community service.
Panjab University has always led exemplarily and thus made a mark in society by accomplishing in all fronts including
academic, research and social and community level. We, at Panjab University focus on overall development of our students
by imparting value and quality education. The idea is to not only make our students ready for jobs but also exposing them
towards social and sustainable entrepreneurship so that they can serve the community along with their career, and can
become job creators too. The Department of NSS was established in 1969. It is a nodal agency to supervise and regulate
the regular activities in Panjab University Campus and its affiliated colleges. Presently more than 120 colleges affiliated to
Panjab University have regular NSS units. In Panjab University, there are 11 NSS Units having more than 1500 Volunteers).
Panjab University is supervising more than 27000 volunteers in its affiliated colleges.
The aim of Panjab University NSS department is to:1. Make education more relevant to the present situation to meet the felt needs of the community and supplement the
education of the university/college students by bringing them face to face with the rural situation.
2. Provide opportunities to the students to play their role in planning and executing development projects
which would not only help in creating durable community assets in rural areas and urban slums but also results in
the improvement of quality of life of the economically and socially weaker sections of the community.
3. Encourage students and non-students to work together along with the adults in rural areas.
4. Emphasise dignity of Labour and self-help and the need for combining physical work with intellectual pursuits.
5. Encourage youth to participate enthusiastically in the process of national development and promote national
integration through corporate living and cooperative action.
Achievements:
 Ms Aarti Yadav, NSS volunteer from IETVE, Panjab University has participated in RD parade and represented on
behalf of Chandigarh in the 73rd Republic Day Parade organized by Ministry of Defence that marched from
Rashtrapati Bhawan along the Rajpath, to India Gate and concluded at Red Fort.
 NSS volunteers of Panjab University won best contingent award in State Level Republic Day Parade on
26.01.2022.
 Sartaj Singh, NSS volunteer of department of Political Science was selected as best author in the Pradhan Mantri
Yuva Scheme, started to encourage young authors to write about the freedom fighters of the country.
 Two volunteers of NSS-PU, Ms. Ritika Verma of Department of Anthropology, PU and Sh. Mohd. Amzad of Post
Graduate Govt. College, sector 11 were awarded in virtual ceremony on 24 th September, 2021 by Ministry of
Youth Affairs and Sports, Government of India.
Highlights of the recent Activities:
NSS team of Panjab University is quite active and has made a distinction by its contribution especially during covid 19
pandemic times. It is pertinent to mention that even during lockdown period; the NSS department has consistently worked
and is contributing significantly at social front in all possible ways. NSS team has been very active in various initiatives of
virtual Covid-19 Awareness, Covid-Appropriate Behaviour, awareness of Covid-19 Vaccination, Road Safety Campaign,
Digital Yoga Demonstration and free distribution of food to construction labour working at Panjab University and many
more. Various Programs and activities like Swachh Bharat Internship, Ek Bharat Shreshth Bharat initiatives, celebration of
Azadi ka Amrit Mahotsav has been successfully undertaken. Tree plantations, blood donation camps and campus
landscaping and Cleanliness Drives are regular features of this team. The department aspires to undertake more field
activities spanning not only at university or regional level, rather will focus on initiating collaboration with various
International NGOs or consumer association for its various future activities. The department has adopted number of

<!-- page 18 -->

FRONT PAGES

17

HANDBOOK OF INFORMATION 2022

villages for its various activities, and keeps on organizing various camps, convenes awareness drives related to substance
use, social and sustainable entrepreneurship with a vision to nurture social entrepreneurship among its volunteers.
 NSS department has conducted Tobacco Awareness Campaign on 31.05.2022 under the Azadi ka Amrit Mahotsav
to commemorate the Anti-tobacco day.
 NSS department has conducted the Skit Play on the topic “Good touch & Bad touch” on 29.04.2022 under the
Azadi ka Amrit Mahotsav. The play was conducted under the guidance of Programme Officers Dr. Shankar Sehgal,
Dr. Naveen Kumar and Dr. Vivek Kumar.
 NSS department of Panjab University on the call of Chandigarh UT celebrated Iconic Week of Azadi Ka Amrit
Mahotsav at Panjab University from 06th March, 2022 to 13th March, 2022 wherein various activities like walk,
Cleanliness drives, Plantation drive, Cycle rally, and a session on Yogis techniques were carried out.
 To mark national anti-pollution day, NSS department has organized a cycle rally ‘Cyclothon’ on 05th December,
2021 to promote use of cycling for healthy lifestyle and to contribute to a sustainable and pollution free
environment.
 To mark World AIDS Day on 1st December,2021, NSS department has convened an awareness rally to make
people understand about the ill effects of the deadly virus, and refrain from the practices that lead to spread of
the virus.
 An online workshop on ‘Motivational and Integrated Amrita Meditation Technique’ was organized by NSS
department of Panjab University on 02-06-2021 with a view to increases concentration, focus and to cope up with
day to day stress.
Panjab University NSS Team:
Programme Coordinator
: Prof. Ashwani Koul
1.
2.
3.
4.
5.
6
7.
8.
9.
10.
11.

Dr. Naveen Kumar
Dr. Amita Verma
Dr. Anuj Kumar
Dr. Shankar Sehgal
Dr. Vivek Kapoor
Dr. Vivek Kumar
Dr. Rohit Kumar Sharma
Dr. Bharti Garg
Dr. Richa Sharma
Dr. Simran Preet
Dr. Lokesh Kumar

DIRECTORATE OF SPORTS
Prof. Prashant Kumar Gautam, Director Physical Education & Sports
Dr. Rakesh Malik, Deputy Director, Physical Education & Sports
The Director of Sports was set up in the year 1948 and is located in the Jawahar Lal Nehru Complex Building (Gymnasium
Hall). It guides, frames policy and co-ordinates the sports activities. Directorate of Sports functions under the overall
control and supervision of Director Physical Education & Sports.
The Gymnasium Hall caters to in-door games with international standard facilities and equipment for Badminton, TableTennis, Kabaddi (N.S), Weight Lifting, Gymnastics, Judo, Wushu, Kick Boxing & Wrestling and Taekwondo. A separate
fitness center for men and women and well equipped physiotherapy laboratory has also been established in the
gymnasium hall. A swimming pool of International dimensions and all weather Swimming Pool is available for Swimming
competitions. It also has hockey Astroturf and 10 meters Indoor shooting range of International Standard for competition
purpose.
Directorate of Sports has its own two sports hostels for Men & Women to accommodate the sports persons who come to
participate in the Inter College and Inter University competitions. These hostels have a three storey building to
accommodate about 200 Men and 300 Women players with eight official rooms.

Panjab University has won the prestigious Maulana Abdul Kalam Azad Trophy for the year 2021.

Players of all the teams representing Panjab University in the Inter University competitions are given sports kit (free of
cost) & DA during coaching camps as well as during the participation in the inter-university competitions to encourage
more participation in the sports competitions. Directorate of Sports always helps the Chandigarh Administration, U.T
Sports Department and other sports agencies in the conduct of National and International level competitions in various
games.
The outstanding sportspersons who bring laurels to University are given incentives and cash awards as following:
Sr.no. Name of the event
Gold Medal
Silver Medal Bronze Medal Participation
1
Olympic Games/Paralympics Games
4 Lac
3.5 Lac
3 Lac
2 Lac
2
World Cup/World Championship
4 Lac
3.5 Lac
3 Lac
2 Lac
(4 year Cycle)
3
World Cup/World Championship
3 Lac
2.5 Lac
2 Lac
(3 year Cycle)
4
World Cup/World Championship
2.5 Lac
2 Lac
1.5 Lac
(2 year Cycle)
5
World Cup/World Championship
2 Lac
1.5 Lac
1 Lac
(1 year Cycle)

<!-- page 19 -->

FRONT PAGES

6
7
8
9
10.
11.
12.
13.
14
15
16
17
18

19
20

18

Asian Games
Asian Cup/Asian Championship
(4 year Cycle)
Asian Cup/Asian Championship
(3 year Cycle)
Asian Cup/Asian Championship
(2 year Cycle)
Asian Cup/Asian Championship
(1 year Cycle)
Common Wealth Games
Common Wealth Championship
(4 year Cycle)
Common Wealth Championship
(3 year Cycle)
Common Wealth Championship
(2 year Cycle)
Common Wealth Championship
(1 year Cycle)
World University Games
(2 year Cycle)
World University Championship
National University Games (Inter
University
Games,
Championship/Khelo India University
Games (Team)
National University Games, Khelo
India University Games (Indv.)
Intra Zonal University Games/
Championship
(North
Zone
Championship)

HANDBOOK OF INFORMATION 2022

3.5 Lac
3.5 Lac

3 Lac
3 Lac

2.5 Lac
2.5 Lac

1 Lac
-

2.5 Lac

2 Lac

1.5 Lac

-

2 Lac

1.5 Lac

1 Lac

-

1.75 Lac

1.25 Lac

75,000/-

-

3.5 Lac
3.5 Lac

3 Lac
3 Lac

2.5 Lac
2.5 Lac

1 Lac
-

2.5 Lac

2 Lac

1.5 Lac

-

2 Lac

1.5 Lac

1 Lac

-

1.75 Lac

1.25 Lac

75,000/-

-

3 Lac

2.5 Lac

2 Lac

-

1.75 Lac
25,000/-

1.25 Lac
21,000/-

75,000/17,000/-

-

28,000/-

24,000/-

20,000/-

-

9000/-

7000/-

5000/-

-

Cash Award of New Record at National University Games, Khelo India University Games are as per the following criteria
Sr.no.
1
2
3

Position
Gold Medal
Silver Medal
Bronze Medal

Rates in Rs.
20,000/15,000/10,000/-

P.U. CAMPUS SPORTS

Prof. Prashant Gautam, Director, Physical Education & Sports
Dr. Dolly, Deputy Director, Physical Education & Sports

Panjab University Campus players participate every year in various International, National, State, Khelo India Games, All
India Inter University, Inter College, Inter Department and Inter Hostel Competitions and bring laurels for Panjab
University.
Sports Incentives
1. Provision of 5% seats for sports person in all the department of Panjab University.
2. Provision of Sports Kit, Refreshment and Scholarships for Panjab University Campus Sports Persons.
3. Special Incentive Schemes for the sports persons who are studying in P.U. Campus, as mentioned below.
Scheme No. (1) For International Level Achievements
Eligibility Criteria
A person getting any of the first three positions or represented India in the Olympic Games /Paralympics Games/World
Cups/ Championships/Asian Games/Asian Cups/Asian Championships/ Commonwealth Games/Commonwealth
Championships/ World University Games/ World University Championship are eligible for the Incentives mentioned as
given below:
Incentives for eligible candidates of scheme No. (1)
1. Free education (no fee will be charged except examination fees).
2. Free hostel accommodation shall be allotted and special seats will be reserved in hostels for above mentioned
category of sportspersons (No hostel fee or any other charges and exemption of mess and canteen charges maximum
up to Rs.3500/-only).
3. Free Swimming Pool, Gym, Tennis, Shooting and Physiotherapy facility.
Scheme No. (II) National & Inter-University level Achievements
Eligibility Criteria
A person getting any of the first three positions in the National University Games/Khelo India University Games, IntraZonal University Games/Championship, Inter-Zonal University Games/Championships are eligible for the incentives
mentioned in the incentives scheme (II) given below:Incentives for Eligible Candidates of Schemes (II)
1. Free education (No fee will be charged except full examination fees)

<!-- page 20 -->

FRONT PAGES

2.
3.

19

HANDBOOK OF INFORMATION 2022

Free hostel accommodation shall be allotted and special seats will be reserved in hostels for above mentioned
category of sportspersons (No hostel fee or any other charges except mess and canteen charges).
Free Swimming Pool, Gym and Physiotherapy facility.

Terms & Conditions of Sports Incentive Schemes
a) Special Incentive Scheme for the sports persons of P.U. Campus during their study in their respective departments
who bring laurels for Panjab University by their outstanding sports performance in those games and tournaments
which are considered for the calculation of marks awarded to each University for the purpose of awarding MAKA
Trophy.
b) Special Incentive Scheme subject to the submission of the Undertaking by the sports persons that he/she will
represent the Panjab University campus in the Inter College competitions and Panjab University in the
tournaments which are considered for the calculation of marks awarded to each University for the purpose of
awarding MAKA Trophy.
c) The Special Incentive Scheme will be applicable to sports persons of P.U. Campus, Chandigarh whose performance
falls under the current academic session subject to submission of undertaking that he/she will represent the
Panjab University Campus and P.U. team in the tournaments which are considered for the calculation of marks
awarded to each University for the purpose of awarding MAKA Trophy.
d) The Special Incentives scheme will also be applicable to those sport persons who intend to take admission in P.U.
Campus, Chandigarh. In these cases, their last session's performance will be considered as their eligibility criteria
for special incentives scheme in those games and tournaments which are considered for the calculation of marks
awarded to each University for the purpose of awarding MAKA Trophy.
e) The Special Incentives will be awarded only after the submission of concerned Certificate/s with undertaking of
their performance in those games and tournaments which are considered for the calculation of marks awarded to
each University for the purpose of awarding MAKA Trophy.
f) The period of achievements will be counted from 1st July to 30th June of the concerned session.
g) The incentives will be given to only those applicants who will submit the attested copies of their achievement
certificate/s in the office of the Campus Sports for P.U. Campus students before 30th June of the concerned session.
Special Provisions for P.U., Campus Sportspersons
 The sports person's leave for sports competition/coaching camps (including Journey days) recommended by the
Director, Phy. Edu. & Sports/ Dy. Director Phy. Edu. Campus sports for P.U. Campus Students in the games and
tournaments which are considered for the calculation of marks awarded to each University for the purpose of
awarding MAKA Trophy. During this leave period the concerned sports person shall be treated as present for the
assessment and for all other academic purposes.
 The Provision of special examination (sessional /internal/external including practical and theory examination) as
recommended by the Director Phy.Edu. & Sports/ Dy. Director Phy. Edu. Campus sports will be made for the sports
persons who miss the exams while participating and preparing for the sports events.
Sports Programmes
 Conduct of Inter Hostel (M & W) Tournaments.
 Conduct of Inter Department (M & W) Tournaments.
 Conduct of Annual Athletic Meet (M& W).
 Conduct of Annual Prize Distribution Function.
 Participation in Inter University and Inter college tournaments.

DR. A.P.J. ABDUL KALAM COMPUTER CENTRE
Professor Sukhwinder Singh, Director (Additional Charge)
Dr. A.P.J. Abdul Kalam Computer Centre administers and manages the Computer Network of entire campus (Sector14 and
Sector 25) of Panjab University which includes departments, institutes, centres& facilities, main administrative building,
hostels, main library, and the guest houses. Network Connectivity is also provided to the remote locations like security
cameras etc.
The Computer Centre is centrally air-conditioned having auxiliary power system to ensure un-interrupted operations for
24×7×365 days. Moreover, the equipment at Computer Centre is upgraded from time to time to ensure that the facilities
remain at par with the latest technologies. Computer Centre has modern facilities such as Wi-Fi Network, storage network,
powerful web servers, e-mail services, network security system, video conferencing facility etc. Centre provides support
services for online teaching, online meetings, webinars, conduct of online viva for Ph.D, and various other online events.
Wireless connectivity has been provided using more than 1100 access points in the entire campus. Internet connectivity is
supported by NKN WAN link. Computer Centre also provides computing services with software like MATLAB, Mathematica
etc. for the campus users and encourages the use of free and open source software like GNU/Linux distributions.
Computer Centre is extensively involved in automation through in-house development of software for online admissions,
online forms for entrance tests, wi-fi user’s management system, modules for management of university website by
individual departments/ centres on their own, etc. Computer Centre works in support of the vision and mission of the
University, to sustain and enhance the University’s excellence as an institution of higher learning.

A. C. JOSHI LIBRARY

Dr. Jivesh Bansal, Librarian
Panjab University Library is officially named as A.C. Joshi Library after an illustrious former Vice-Chancellor of Panjab
University, Prof. A.C. Joshi. It is one of the largest University libraries of the country. Housed in a five storey centrally airconditioned building in red stone, it has spacious reading halls and compact stack areas, with open access. With modular

<!-- page 21 -->

FRONT PAGES

20

HANDBOOK OF INFORMATION 2022

design, it is based on modern principles of architecture. The main reading halls of the Library, facing the Shivalik Hills,
provide a panoramic view of the natural surroundings.
Endowed with manuscripts on the one hand and online Databases on the other; periodical holdings going back to the
19thcentury on the one hand and reference material in multimedia on the other; textual and bibliographical material of the
pre-Independence period on the one hand and the online sources on the other, Panjab University Library presents a blend
of the old and the new under the same roof.
Facilities: The Library has a seating capacity for 650 readers. It is a fully computerized library with an integrated system
connected to the Campus network and possesses facilities like Wi-Fi, digital signage, photocopying, fax, e-mail, Internet,
Online Public Access Catalogue (OPAC), CD-ROM databases and on-line books and journals. Besides the two main reading
halls, there are separate areas for text books, theses and rare books, newspapers, and current periodicals. There is an Outer
Reading Hall for studying personal books in the Library that is open round the clock.
There is provision of 24 research carrels for faculty members engaged in serious research work and 90 lockers for
research scholars
OPAC: Along with Card Catalogue, the Library has in-house database of books, journals, thesis and other reading materials.
This database is accessible through Online Public Access Catalogue (OPAC) and Web-OPAC through Library website.
(http://library.puchd.ac.in).
Digital Library: The Library has a digital library which serves as an access point to all the on line academic resources. The
Digital Library is equipped with computers of latest configuration with the facility of CD-writing and print out of journal
articles. The Digital Library is augmenting the research activities of the research scholars and teachers. Besides this, the
Library has its own Reprographic Section.
Collection: The Library houses approx. 8 lac volumes, which include books, bound volumes of journals,
theses/dissertations, rare books, reports, government documents, back files of newspapers and a prized collection of 1492
manuscripts.
The Library is subscribing to 312 current periodicals, a number of which have on-line access along with the print versions.
The Library also has access to about 15000 + core and peer reviewed on-line journals and 14 bibliographical databases
from publishers & aggregators in different disciplines through e-shodhsindhu consortium of INFLIBNET. These eresources can be accessed through Campus network and Remote Access facility. Many on-line journals and miscellaneous
reference sources in the public domain are accessible through the Library Website-library.puchd.ac.in. The Library has
subscribed to 20 e-resources (2021) including Science Direct, Scopus, IEEE, ACM Digital Library, Institute of Physics,
EBSCO, Proquest Dissertation & Thesis Abstracts, Indiastat, Districts of India etc. with links on the website. A.C. Joshi
Library has started ‘Remote access facility’ to access all the e-resources including library catalogue. This can be accessed by
using e-library link from the library website. A-Z finder of all e-journals, e-resources and e-books is also provided in this
service. The library has also procured books in electronic format from reputed publishers.
Office/Division/Section
University Librarian
Deputy Librarian
(Collection Development & Admn.)
Deputy Librarian
(Readers’ Services)
Incharge Reference Section
Incharge Circulation Section
Incharge Technical Section
Incharge Acquisition Section
Incharge Special Collection/
Archival Section
Incharge Theses Section
Incharge Reference II/
Transfer Cell
Incharge Computer Room
Incharge Binding Section
Incharge Office

What is where (floor wise list)
Location
Contact Person
II Floor
Dr. Jivesh Bansal

Telephone(EPABX)
4551, 2548159

III Floor

Dr. Neeru Bhatia

4559

Gr. Floor

Dr. Neeraj Kumar Singh

4553

II Floor
I Floor
I Floor
III Floor
Gr Floor

Dr. Suman Sumi
Mrs. Leena Khullar
Ms. Mona Pall
Ms. Sunaina Khanna
Dr. Mritunjay Kumar

4561
4558
4564
4556
4579

Gr. Floor
III Floor

Dr. Nirupma Chohda
Mrs. Indu Dhawan

4579
4562

II Floor
Gr. Floor
IV Floor

Mr. Vinod Garg
Mr. Yogesh Kumar
Mr. Raj Kumar

4578
4557
4555

Timings: The Library is open from 8.00 a.m. to 10.00 p.m. on all days of the week throughout the year, barring national
holidays. However, the Outer Reading Hall is open 24x7. Books are issued and returned from 9.00 a.m. to 4.30 p.m.,
Monday to Friday. However, members can avail issue/return facility after normal working hours through RFID Self-check
and Book Drop System.
Membership: The membership of the Library is open to bonafide students of the University teaching departments, all
teaching and non-teaching staff of the University, fellows of the University, teachers of Colleges affiliated to the Panjab
University, eminent persons as Special Members, and institutional members under the Industry-Institute Partnership
Programme. The students can apply by filling the online membership form through the library website.
Readers’ Services: Personalized reference service is the hall mark of the Library. Library Orientation Programmes are
conducted in the beginning of each academic session for new entrants. A reader can approach any staff member for
assistance, though Reference Desks are located in each Reading Hall. Newly processed books are brought to the notice of
readers through weekly displays near the entrance of the Library. The Library also arranges books on inter-library loan to
and from other libraries on specific demand. For the purpose of resource sharing, the Library is a member of library
networks at the national level like Developing Library Network (DELNET) and Information & Library Network
(INFLIBNET) programme sponsored by UGC.

<!-- page 22 -->

FRONT PAGES

21

HANDBOOK OF INFORMATION 2022

Wi-Fi System: Library is Wi-Fi enabled to access online journals and data bases on laptops.
Digital Signage System: The A.C. Joshi library has Digital Signage System to keep the readers aware of addition of recent
titles in the library, services and facilities available to readers, information regarding examinations and other lectures and
events to be held in the University from time to time & general information.
JCCC: The Panjab University Library is one of the 22 libraries designated by INFLIBNET for providing inter-library loan
and document delivery services from the comprehensive collection of subscribed journals under its JCCC@UGC-INFONET
programme.
RFID Technology: The Library is equipped with the latest RFID Technology along with integrated Library Management
Software to facilitate efficient issue/return of books including self issue/return, better stacks management, inventory
control and an improved security system for books in the Library. There is a Drop Box facility at the entrance of the Library
to facilitate round the clock return of books. SMS alert for the users account is also available.
ETD: The Library has uploaded 7667 Ph.D. theses on Shodhganga Platform (Indian Repository of Theses).
Inter-Library Loan and Document Delivery Services: Library is member of DELNET (Developing Library Network)
which enables it to utilize the collections and services offered by DELNET as well as its member libraries spread across the
country and abroad. If a book or article from a journal required by a researcher is not available in the A C Joshi Library, ILL
request can be registered with the Reference Section in the A.C. Joshi Library and the same is procured on Inter-library
loan and is supplied to the user.
Facilities for the visually handicapped: A special room has been provided for the visually handicapped students of the
University on the ground floor of the library, with latest facilities like special Horizon A3 Scanner, Lex Software with
English and Hindi Voice pack and Hindi OCR. Computer access facility for the visually impaired students is also provided
through JAWS and Zoomex softwares.
Remote Access Facility: In line with its motive to serve its readers in the best way, during the lockdown period in April
2020, the Library started off-campus accessibility for all the e-resources being subscribed by the library to the faculty of
Panjab University Campus and its Regional Centres. A.C. Joshi Library launched e-library facility and provided ‘remote
login’ facility to all the faculty and students at University Campus and Regional Centres. This facility enabled the faculty to
access the resources from their home which could earlier be accessed only on the University Campus. The Library also
started ‘Single Window Search’ to all the e-resources including library catalogue (an all-inclusive search solution that
makes in depth search easy). Mobile e-library app (for both Android and iOS) is also provided for accessing this service,
which is a multi-format, content delivery app. Another added feature of the Panjab University e-library supported by
‘Knimbus’ is ‘Single Window Search’.

BHAI GHANAIYA JI INSTITUTE OF HEALTH
Dr. Rupinder Kaur, Chief Medical Officer

Bhai Ghanaiya Ji institute of Health’ provides primary health facilities to its employees including retirees, their dependent
children, parents and all students and hostel inmates of this University. The existing infrastructure has been thoroughly
upgraded. A washroom has been specifically done up for the differently-abled. The office has been automated which has
resulted in best space use.
We are serving the strong community of about 50,000 (fifty thousand) consisting of students, teachers, non- teaching
employees (both serving and retired), their dependents and the daily wagers, mess-workers, on contract employees,
university delegates, guests and visiting dignitaries etc. The number of patients visiting Health Centre is 350 per day on an
average including emergency cases.
Presently, BGJ Institute of Health is manned by Chief Medical Officer (One), Ex-Additional Chief Medical Officer (one), Full
Time Medical Officers on contract basis (three), Part Time Gynecologist (One), Part time Medical Specialist (One), Part
Time Yoga Instructor (One), Part Time Pediatrician (one), and Part Time Ayurvedic Medical Officer (one). All the doctor
except CMO (Dr. Rupinder Kaur) are on contract.
The supporting staff consists of Chief Pharmacist (Four), Pharmacists (Two), Sister Nurse (One), Multipurpose Health
Workers (Female Three), Dresser (one on regular basis and one on contract), Ward boy (One), Para Medical Attendants
(Four Regular and Two contractual), Laboratory Technicians three (two on regular basis and one on contract) Cleaners
(Four Regular and Two Contractual). Besides, the office is manned by Senior Assistant (One) and Clerk on Daily Wage Basis
(One).
Regular OPD:Morning shift8.30am to 12.30pm (Monday to Friday)
9am to 11am (Saturdays)
Evening shift:
5pm to 6pm (Monday to Friday)
Emergency OPD
12.30 pm – 5.30 pm
5.30 pm - 10 pm
But due to Covid-19 (coronavirus) , these timings are varying depending on the intensity of infection and are displayed on
notice board from time to time.
Ambulance Services: Ambulance service is available to all the patients 24x7. The Ambulance services FREE to all students
and class C employees and their dependents.
Medicines: All bonafide employees both teaching and non-teaching and their dependents and all students are provided
free medicines. Medicines are purchased directly from the Pharmaceutical Companies that are on the approved list of BGJ
Institute of Health. With this arrangement, we are able to save about 50% on the cost of medicines. About 30 chemist
shops / drug stores in the tri-city are offering a discount of 10% on branded medicines and 30% on generic medicines to
P.U. patient. This results in an approximate savings of about Rs 20, 00,000/-.
Diagnostic services:

<!-- page 23 -->

FRONT PAGES



22

HANDBOOK OF INFORMATION 2022

With the installation of highly sophisticated 500mA digitalized version of X-ray machine (Siemens) with a
mammographic compatible unit and with a CR system (Fuji) world class X-ray are being done. A total of 2530 Xrays have been done during this period of April 2019 to March 2020.

In a well-equipped Clinical Laboratory having semi-automatic analyzer all the routine tests in hematology,
serology, biochemistry and microbiology etc. are being performed.

ECGs are being done with 12 channels Schaller ECG machine in a separate ECG room. A total of 521 ECG have
been done during this period of April 2019 to March 2020.

Emergency and injection room is now equipped with Nebulizers, Oxygen, an emergency medicine cabinet with all
emergency drugs, injections etc.
Medical Entitlement Booklets: The process of issuing new and revalidating old medical entitlement cards in a continuous
process. This process results in weeding out a number of cards of non-entitled persons. Dependent children, parents,
spouses of women employees have also been extended free medical entitlement facilities including OPD consultation, in–
house available medicines, clinical investigations and Medical Reimbursement at par with male counterparts as per
Medical Entitlement rules. The facility of free OPD consultation and laboratory investigations has now been made available
to fellows and Ex- fellows. In order to further streamline the method of processing Medical Entitlement cards for which
new different types of proformas have been introduced. All the information is available on the PU website.
Chronic Diseases and their drugs distribution: A separate drug dispensing area is earmarked for patients of chronic
ailments e.g. Hypertension, Heart diseases, Diabetes, Epilepsy, Asthma and COPDs osteo Arthritis etc. The employees and
retirees have been benefited by this arrangement.
Revised National Tuberculosis Control Programme (RNTCP): The BGJ Institute of Health is an approved designated
centre for DOTS under Govt. of India RNTCP. All patients of Tuberculosis are provided anti-tuberculosis drugs as per latest
RNTCP guidelines free of cost.
Vector and Water Borne Diseases Surveillance Centre: With the collaboration of department of Health (National Vector
Borne Wing) Chandigarh Administration, we are running a complete surveillance unit of malaria and dengue other vector
borne diseases. Regular sprays and other preventive measures against malaria and other vector borne diseases are being
undertaken. All malaria positive patients are notified to the concerned higher health authority of Chandigarh (U.T.).
Revised National Tuberculosis Control Programme (RNTCP):The BGJ Institute of Health is an approved designated centre for DOTS under Govt. of Indian RNTCP. All patients of
Tuberculosis are provided anti-tuberculosis drugs as per latest RNTCP guidelines free of cost.
Communicable Diseases and their Monitoring: Special arrangements are made every year to monitor all communicable
diseases in coordination with the UT health services and to create awareness among both the employees and students. A
number of cases of conjunctivitis are also reported every year. Records of patients having symptoms like cough, cold and
fever are maintained separately to facilitate accurate monitoring. The staff of Institute of Health has been immunized
against Hepatitis-B.
Special provision for Senior Citizens: For the convenience of the superannuated employees of the University, a special
provision has been made to facilitate their out of turn registration, consultation and dispensing of Medicines in order to
provide them medical assistance with in minimum possible time frame. Since this Institute is already doing its best to go on
improving the available infrastructure for the benefit of all the patients with special focus on relatively with special need of
a section of society. To fulfill this objective room no 16 has been specially designated and completely refurbished for the
senior citizens and patients who has to get the investigations done after meal. Which is fully air conditioned equipped with
a small pantry, a library cabinet, dining table, drinking water facility, a microwave, a refrigerator and wooden flooring. For
above fund of Rupees two lacs have been donated to us, out of which one lac is donated by one of our very satisfied patient
and another Rupees one lac is approved by the honorable Vice-Chancellor of P.U.
Yoga Classes: Yoga classes are being conducted regularly under the supervision of a qualified Yoga- Instructor.
(i)
5pm to 6pm (BGJ Institute of Health Sector 14)
Monday to Friday
(ii)
6pm to 7pm (Community Centre, Sector 25)
Monday to Friday
Health Awareness lectures, Seminars and Workshops: Lectures by medical experts on various health related topics are
periodically held for awareness on health issues like Diabetic Neuropathy, Road safety, smoking hazards, alcohol abuse,
Asthma Day, Hypertension Day, and Hepatitis Day stress awareness etc. in order to keep staff of BGJ Institute of Health
abreast with the latest happenings in the medical sciences, interactive session cum demonstration with the help of power
point presentation on topics of Vector Borne Disease, hand hygiene etc. were conducted so that they can serve the
community in a better way.
Medical camps:- Medical camps are organized on Spirometry, Bone Mineral Density, Thyroid Function Test, Diabetes
detection camps and Hypertension in association with Pharma companies for the benefit of University community. Bone
densitometry, HbA 1c test were performed free of cost.
Reimbursement facilities: Reimbursement facilities are available to all the bonafide University employees and their
dependents (both serving and retiree) as per medical reimbursement rules of the University. Single window service has
been started for the quick, easy and hassle free reimbursement process. Packages for various medical ailments have been
implemented so that reimbursement procedures get further facilitated for patients not availing treatment at Govt.
Hospitals, GMCH- 32, PGIMER, Chd, AIIMS New Delhi etc. The reimbursements of bills are done at PGIMER Chd/ AIIMS
rates/ Panjab Govt. Medical Attendance rule. Online entry of Medical Reimbursement bills started w.e.f. April 2018 at BGJ
Institute of Health.
Vaccination for Covid-19: A total of 13,127 Covid-19 vaccinations have been done from March 2020 to Dec 2021. Portal
for entry of COVID +ve patients, dependants, contract made functional. In association with NVWBD & Chandigarh
Administration we tried our best to help COVID +ve patients and their contacts.
Back-Up Electricity facility: During the period of non- availability of electricity, back up facility has been established by
providing no maintenance inverters. This has result in smooth functioning of OPDs, clinical Laboratory Emergency services
during electricity shut down periods.

<!-- page 24 -->

FRONT PAGES

23

HANDBOOK OF INFORMATION 2022

Academic and Social Activities: The Medical doctors of the Institute of Health are regularly engaged as guest and
honorary faculty in the subjects of Medicine, Surgery, Sports Medicines and Exercise Physiology etc. They regularly
participate in continuing Medical Education/programmes throughout the year. They have delivered lectures on medicine,
Drugs, Alcohol and Substance Abuse, Health Concerns, Health and Teachers at Chandigarh Judicial Academy, Rajiv Gandhi
National Law University Patiala and Kendra sangthan (Union Ministry of Human Resource and Development) and
Department of various Department of Panjab University etc.
Visual Aids: A LCD 32 Inches with cable connection is functioning in the patients’ waiting area to telecast various health
related programmes of different TV channels including Door Darshan.
Library: Library equipped with latest medical books and journals.
Newspapers and Magazines: Newspapers and Magazines both in English and Hindi are being made available in the
patients waiting areas.
New facilities and additions:

Medicines, gadgets and equipments are being purchased.

For senior citizens ‘Rest Room cum Dining Room’ equipped with library is now functional.

For storing medicines at desirable room temperature and cool environment away from sunlight, the pharmacy
storage has been fully renovated.
Parking area: For the convenience of patients, old and enfeebled, senior citizens and physically challenged, more facilities
for parking of their transport has been provided.
In addition to this following measures are being taken: During Covid lockdown our OPD services were kept functional on rotational basis for all the staff members.
 Sanitizers have been installed at multiple places.
 The BGJ Institute of Health is following all norms as issued by the Ministry of Health and Family Welfare from time to
time.
 All OPD patients were attended by the staff during this period following the full Covid-19 protocols.
 Special lecture on respiratory diseases and precautions for Covid-19 were relayed online and talks on vaccination
were conducted.
 Various SOP’s for the benefit of employees and students are uploaded regularly.
 We are striving to address misconceptions among general public regarding Covid-19 and its vaccination.
 Vaccination centre for covid-189 for 18 years and above and 3rd preventive does has been started with vaccination of
13127 persons till 31st of Dec 2021.
 Wellness kits are distributed to Covid patients of Sec-14 and Sec-25 campus in association with GMSH-16, CH-22 &
GMCH-32.
 Air purifiers of molecule are installed for decreasing the chances of spread of Covid-19 infection.
 Portal for uploading of Covid cases is also installed in collaboration with the computer Centre, Panjab University.
 Tele-consultation has been started and slots allotted for various doctors during Covid period.
 Sessions for decreasing mental stress among healthcare staff are conducted from time to time.
 We ae assigning multiple roles to staff members in order to achieve near normal efficiency
 Oxygen concentrator installed.
 Reporting of communicable diseases on online ihip portal daily started as per Govt. protocol.
 Improvements in dressing room, laboratory by provision of better fully automatic equipment’s done.
Future Vision: We are in the process of installation of alternative source of energy (Solar Energy).
 To go for computerization of Medicines and patients records etc.
 Air conditioning of rest of the patient facility areas.
 Automatic fully computerized autoclave is in purchase process along with Oxygen concentrator.
 Upgradation of laboratory with automatic cell counter.
 Installation of audio visual system at senior citizens retiring room.
 Improvement of pharmacy room.
 Increase in number of oxygen concentrators.

<!-- page 25 -->

FRONT PAGES

24

HANDBOOK OF INFORMATION 2022

IMPORTANT INSTRUCTIONS
1 Candidates are advised to visit the website http://onlineadmissions.puchd.ac.in and https://ugadmissions.puchd.ac.in
for admission related Notices, Updates and various websites for admission purposes.
2 Candidates seeking admission to select courses offered by Teaching Departments and Regional Centres of Panjab
University shall fill online Admission Form, complete in all respects on or before the prescribed last date of submission
of Admission Form.
3 Candidates are advised to apply for admission irrespective of the fact whether the result of the lower examination or
Entrance Test has been declared or not. A candidate who does not apply till the last date, he/she will not be considered
for the admission. However, a candidate whose result of the lower examination or Entrance Test has not been declared
till the last date of submission of admission Form and who applies for admission will be allowed to participate in the
admission process after declaration of result.
4 Prescribed Fees, Funds and charges shall be payable by the candidates.
5 Once a candidate has been admitted to a course, his/her certificates/testimonials will be kept by the Department for
registration/ verification purposes. However, on written request of the candidate, certificates/testimonial can be given
back to the candidate for a reasonable period.
6 Candidates seeking refund of admission fee and other charges will have to follow General Refund of Fee Rules provided
in the Handbook of Information.
7 Under the Choice-Based Credit System obtaining 24 credits in a Generic Elective Course Subject in the full B.Sc. (Hons.)
course shall also be deemed sufficient to satisfy a requirement for admission to the M.Sc. course in the concerned
subject. However, the candidate has to fulfil other requirements as mentioned for respective M.Sc. Courses.
8 Students are expected to regularly attend classes / tutorials / practicals / field work etc. Rules regarding Condonation
of Shortage of Lectures are listed in Handbook of Information.
9 The confidential result of the examination shall be accepted for the purposes of admission.
10 A printed copy of the result download from official website of University/Board/Institute shall be considered only if it is
duly verified by the competent authority of the institute/college/university last attended. However, the candidate will
have to produce original DMC/Degree within 15 days from the date of admission.
11 The admission of the candidate will be cancelled and legal action will be taken if there is any concealment /
misrepresentation of information in Admission Form or in the attached certificates / undertakings / documents etc.
12 Admission to all the courses are governed by the Rules and Regulations for admission as approved by the relevant
bodies of the university from time to time.
13 No student shall be allowed to be on the rolls of two-degree programmes simultaneously.
14 Vacant seats in SC, ST, BC, Defence, Terrorist, Riots, Victim, Freedom Fighter, Sports and PwD categories will be
converted to General category (to be notified later on), subject to the condition that the waiting list of each Reserved
Category has been exhausted.
15 Admission of all such students who fail to attend at least 33% of the total lectures / tutorials / practicals etc. delivered /
held in each paper during the first ten working days from the start of teaching work shall be cancelled by the Board of
Control / Joint Admission Cell.
16 Each candidate applying for admission under Reserved category of Sports will take a print out of the online Admission
Form and submit self-attested photocopies of the relevant certificates and undertakings as per ‘Guidelines for
Admission to the Reserved Category of Sports’ to the office of the Campus Sports, (Gymnasium Building, Jawaharlal
Nehru Complex), PU Chandigarh on or before the last date of submission of Admission Form. If the candidate fails to
submit the Form complete in all respect in the office of the Campus Sports, his/her candidature under Sports Category
will be rejected.
*Fee to be charged for Online Application Form for Admission
Sr. No. Particulars
Fee to be charged (Rs.)
Candidate can apply for 4 courses only on one Admission Form
1.
For online application for admission to 1 course
300
2.
For online application for admission to 2 courses
400
3.
For online application for admission to 3 courses
500
4.
For online application for admission to 4 courses
600
Candidate intending to apply for more than 4 courses is
required to submit another Admission Form
Additional fee to be charged (Rs.)
1.
For online application for admission to 5th course
300
2.
For online application for admission to 6th course
400
3.
For online application for admission to 7th course
500
4.
For online application for admission to 8th course
600
Candidate intending to apply for more than 8 courses is required to submit yet another Admission
Form with the above mentioned additional fee per additional course
*50% concession to SC/ST/PwD candidate in Application Fee

<!-- page 26 -->

FRONT PAGES

25

HANDBOOK OF INFORMATION 2022

IMPORTANT DATES FOR ADMISSIONS
SESSION 2022-2023
1st year of Post-Graduate Degree Course / Under-Graduate Degree Courses / Certificate / Diploma / Advance
Diploma Courses [except BE courses and B.Sc (Hons.)/ B.Pharma courses under PU-CET (UG) / PUTHAT / UG
LAW and ongoing classes*]

I.

Description
Availability of Online Admission Form

UG
20.06.2022

PG
27.06.2022

II

Last date of Submission

15.07.2022

22.07.2022

III

Normal Admission (without late fees)

IV

Late admission with permission of the Chairperson (with late fees of
Rs. 1000/-)
Late Admission with permission of the V.C. (with late fees of
Rs.3000/-)

01.08.2022 to
10.08.2022
11.08.2022 to
31.08.2022
01.09.2022 to
30.09.2022

16.08.2022 to
26.08.2022
29.08.2022 to
09.09.2022
12.09.2022 to
07.10.2022

V

*Ongoing classes of 3rd / 5th / 7th / 9th semesters will start from 08.08.2022 (Monday). In case of ongoing classes, each
student whose result of the lower semester / class has not been declared, shall have to seek provisional admission with an
undertaking to the effect that his / her admission shall stand cancelled if he / she fails to meet the eligibility
requirement(s) for promotion to the next higher semester / class as per the rules and regulations of the course. Counting
of attendance for the purpose of calculation of shortage of lectures will be made from 08.08.2022. If such a candidate seeks
provisional admission after this date, his / her attendance will stand be counted from 08.08.2022 and not from the date on
which he / she seeks provisional admission. The candidate after the declaration of result of lower semester / class will
have to deposit the due fees within ten days of declaration of result in order to get his / her admission confirmed.
1.

All Teaching Departments / Regional Centres should strictly adhere to the dates of admissions as indicated above. In
any case, no admission shall be made before the dates of normal admission and after the last date(s), as specified
above.

2.

The Vice Chancellor may permit late admission up to the date specified in the above mentioned admission schedule
on payment of late fee of Rs. 3000/-. While recommending such applications for prior permission of the ViceChancellor, it may be ensured that the late fee has been remitted by the candidate and his / her request carries
Receipt No. and date.

3.

Prior permission of the Vice Chancellor is necessary for admission after the expiry of last date as indicated in point V
above. If such permission is not sought and the admission is made in anticipation of approval of the Vice Chancellor,
post facto permission shall not be given.

4.

Admission process will continue on all Saturdays and public holidays, if any, which fall during the days of normal
admission.

5.

All Teaching Department / Regional Centres should get Schedule of counselling-cum-admission approved from the
DUI in the prescribed format.

<!-- page 27 -->

FRONT PAGES

26

HANDBOOK OF INFORMATION 2022

The Academic Calendar to be followed by Teaching Departments / Regional Centres for 1st YEAR of UG
/ PG CLASSES having Semester System of Examination for the session 2022-2023.
Sr.
No.
1

From

Particulars
Semester
Vacation

Break

/

Summer

To

Under Graduate
01.07.2022
29.07.2022
(Friday)

(Friday)
29.07.2022

2

Admission Process

01.07.2022
(Friday)

(Friday)

3

Commencement of teaching for
1st year
Normal Admission for new Classes

01.08.2022

(Monday)

4
5

6

7
8
9
10

01.08.2022

10.08.2022

(Monday)

(Wednesday)

11.08.2022

31.08.2022

(Thursday)

(Wednesday)

01.09.2022

30.09.2022

(Thursday)

(Friday)

01.08.2022
(Monday)

01.12.2022
(Thursday)

End
Semester
Examinations
(Practical / Theory)

02.12.2022

31.12.2022

(Friday)

(Saturday)

Semester Vacation (Winter Break)

25.12.2022

31.12.2022

(Sunday)

(Saturday)

Late admission to be allowed by
the Chairperson of the University
Teaching Departments / Regional
Centres with late fee of
Rs.1000/- per student.
Late admission in the University
Teaching
department/Regional
Centres to be allowed by the
Vice-Chancellor with late fee of
Rs.3000/- per student.
Academic
Term-I
(Odd
semesters)

Academic
semesters)

Term-II

(Even

02.01.2023

10.05.2023

(Monday)

(Wednesday)
10.06.2023

11

End
Semester
Examinations
(Practical / Theory)

11.05.2023
(Thursday)

(Saturday)

12

Summer Vacation (tentative)

01.06.2023

02.07.2023

(Thursday)

(Sunday)

No. of
Days
29
29

From

To

Post Graduate
01.07.2022
29.07.2022
(Friday)

(Friday)

25.07.2022

18.08.2022

(Monday)

(Monday)

No. of
Days
29
22

16.08.2022 (Tuesday)
08

16.08.2022

26.08.2022

(Tuesday)

(Friday)

29.08.2022

09.09.2022

(Monday)

(Friday)

12.09.2022

07.10.2022

(Monday)

(Friday)

90

16.08.2022
(Tuesday)

14.12.2022
(Wednesday)

87

26

15.12.2022

07.01.2023

21

(Thursday)

(Saturday)

24.12.2022

31.12.2022

(Saturday)

(Saturday)

15

22

07
92

09.01.2023

17.05.2023

(Monday)

(Wednesday)

28

18.05.2023

10.06.2023

(Thursday)

(Saturday)

32

01.06.2023

02.07.2023

(Thursday)

(Sunday)

09
10

20

08
93

21
32

→

NOTE:

1

Adjustments, if any, in the Semester schedule of certain University teaching Departments and Regional Centres
may be allowed by the Dean of University Instruction in special cases.
Summer Vacation for the session 2021-22 has been rescheduled & from 01.07.2022 to 29.07.2022 (29 days)
instead of 25.07.2022 to 15.08.2022 (22 days).

2

<!-- page 28 -->

FRONT PAGES

27

HANDBOOK OF INFORMATION 2022

The Academic Calendar to be followed by Teaching Departments / Regional Centres for UG / PG
ONGOING CLASSES having Semester System of Examination for the session 2022-2023.
Sr.
No.
1

Particulars
Semester Break / Summer Vacation

From

To

No. of
Days

01.07.2022

29.07.2022

29

(Friday)

(Friday)
05.08.2022

2

Admission Process

01.08.2022
(Monday)

(Friday)

3

Commencement of teaching for ongoing Classes

08.08.2022

(Monday)

4

Normal Admission for ongoing classes

08.08.2022

12.08.2022

(Monday)

(Friday)

5

Late admission to be allowed by the Chairperson of the University
Teaching Departments / Regional Centres with late fee of Rs.1000/per student.

15.08.2022

31.08.2022

(Monday)

(Wednesday)

Late admission in the University Teaching department/Regional
Centres to be allowed by the Vice-Chancellor with late fee of
Rs.3000/- per student.

01.09.2022

30.09.2022

(Thursday)

(Friday)

7

Academic Term-I (Odd semesters)

08.08.2022
(Monday)

09.12.2022
(Friday)

90

8

End Semester Examinations

12.12.2022

07.01.2023

24

(Monday)

(Saturday)

9

Semester Vacation (Winter Break)

24.12.2022

31.12.2022

(Saturday)

(Saturday)

09.01.2023

12.05.2023

(Monday)

(Friday)

15.05.2023

10.06.2023

(Monday)

(Saturday)

01.06.2023

02.07.2023

(Thursday)

(Sunday)

6

10

11
12

a)
b)

Academic Term-II (Even semesters)

End Semester Examinations (Practical / Theory)
Summer Vacation (tentative)

05

05
13

22

08
90

24
32

NOTE:Adjustments, if any, in the Semester schedule of certain University Teaching Departments and Regional Centres
may be allowed by the Dean of University Instruction, in special cases.
Summer Vacations for the Session 2021-22 has been reschedule as 01.07.2022 to 29.07.2022 (29 days) instead
of 25.07.2022 to 15.08.2022 (22 days)

<!-- page 29 -->

FRONT PAGES

1.

28

HANDBOOK OF INFORMATION 2022

RULES OF ADMISSION FOR THE COURSES OFFERED BY UNIVERSITY TEACHING
DEPARTMENTS / CENTRES / INSTITUTES
General Rules

Admission to all courses offered by the Panjab University teaching Departments / Centres/ Institutes is governed by
the following rules:
a)

Wherever for admission, Bachelor’s Degree is the minimum requirement, it shall mean the first degree obtained
under 10+2+3 scheme. The first degree obtained under the old scheme (14-year course) till April, 1995 will be
treated at par with the first degree under 10+2+3 scheme for the purpose of admission to these courses.

b)

Every candidate must apply for the Reserved / Additional Category(ies) to which he/she belongs to, in the Admission
Form. All candidates will be considered in the General Category irrespective of the fact that they have claimed for
admission under Reserved/ Additional Categories. No candidate shall be considered for admission against any
Reserved Category (ies) for which he/she has not applied.

c)

All information relating to admission shall be uploaded on the Online Notice Board of the concerned department as
well as on the Physical Notice Board.

2.

Schedule of counselling / admission

a)

The date-wise schedule of counselling/admission shall be separately announced by the Department concerned,
with the approval of the Dean of University Instruction, which shall be strictly observed.

b)

This schedule shall contain the dates of posting the Tentative Merit List (which will be updated after seeking
objections, if any); Provisional Merit List; Aptitude Test, Group Discussion, Personnel Interview (wherever
applicable); Counselling. Information relating to point a) & b) shall be put on the Online Notice Board of the
department as well as Physical Notice Board.

d)

Merit List of Selected Candidates and those figuring in Waiting List in order of merit (duly approved by the Dean of
University Instruction) and the last date of deposit of fee will be put on Online Notice Board of the department as
well as Physical Notice Board.

3. Distribution of seats
3.1 Seats for General and Reserved Categories
The number of seats in each course offered in the Teaching Departments, as announced in the Admission Notice/s, shall be
strictly adhered to, except for such minor adjustment as may be necessary on account of rounding off fractions to
accommodate reservations, as given below:(A)

53.5% of the seats in each course shall be treated as belonging to the General Category.

(B)

46.5% seats shall be treated as belonging to the Reserved Category, as per details given below:
(i) 15% for candidate belonging to the Scheduled Castes.
(ii) 7.5% for candidates belonging to the Scheduled Tribes.
(iii) 5% for candidates belonging to the Backward Classes.
The above reservation shall be subject the following conditions:
(a) The number of students admitted on merit of General Category shall not be included in the number of seats
reserved;
(b) Members of Scheduled Castes/Tribes and Backward Classes shall be allowed a concession of 5% marks for
admission to the courses in which a certain percentage of minimum marks has been prescribed provided
they have obtained minimum pass marks prescribed by regulations;
(c) In case the seats earmarked of Scheduled Castes/Scheduled Tribes remain unfilled, a further relaxation in
marks may be given, in order of merit inter-se amongst the candidates themselves, so that all the reserved
seats are filled by candidates belonging to these categories. This, however, will not apply for MBBS
admission; and

<!-- page 30 -->

FRONT PAGES

29

HANDBOOK OF INFORMATION 2022

(d) A Scheduled Caste/ Scheduled Tribe person on migration from the State of his origin will not lose his status
as Scheduled Caste/Scheduled Tribe but he will be entitled to the concessions / benefits admissible to the
Scheduled Castes/Scheduled Tribes from the State of his origin and not form the State where he has
migrated. (Regulation 29.1, P.U Cal. Vol-I, 2007 page 168).
(iv) 5% seats will be horizontally reserved for persons or class of Persons with Disability (PwD)*out of which 1%
each shall be reserved for persons suffering from the disabilities specified under the RPWD 2016 Act:
1. Physical Disability
A. Locomotor disability
(a) Leprosy cured persons
(b) Cerebral palsy
(c) Dwarfism
(d) Muscular dystrophy
(e) Acid attack victims
B. Visual Impairment
(a) Blindness
(b) Low Vision
C. Hearing Impairment
(a) Deaf
(b) Hard of Hearing
D. Speech and language disability
2. Intellectual disability
(a) Specific learning disabilities
(b) Autism spectrum disorder
3. Mental behaviour (Mental Illness)
4. Disability caused due to
(a) Chronic neurological conditions due to:
(i) Multiple sclerosis
(ii) Parkinson's disease
(b) Blood Disorder
(i) Haemophilia
(ii) Thalassemia
(iii) Sickle cell disease
5. Multiple Disabilities (Deaf Blindness)
6. Any other category as may be notified by the Central Government (Annexure-the Schedule of RPWD
Act2016, page no. 33, 34, 35)
(a) If 5% of reservation of seats comes to 0.5 to 0.9, it shall be treated as one seat. However, if after
calculating seats on the basis of 5%, the number of seats is divisible by 5, equal distribution of
seats will be made for all the five categories. If after the division, any remainder is left, it shall be
distributed on the basis of inter-se merit amongst all the five categories. If the seats after
calculating on the basis of 5% comes to less than 5 it shall be distributed on the basis of inter-se
merit amongst all the five categories
(b) In the absence of availability of candidates in any of the categories, the seats shall be
interchanged inter-se.
(c) If seats reserved for Persons with Bench mark Disabilities remained unfilled, these shall be
treated in the sanctioned strength of seats for General Category.
Applicants under the Reserved Category of Persons with Bench mark Disabilities shall be allowed
a relaxation of 5% marks for calculation of merit in seeking admission to the courses in which a
certain percentage of minimum marks has been specified, provided they have obtained minimum
pass marks prescribed by the University regulations. The candidate under the Reserved Category
of Persons with Bench mark Disabilities shall be allowed an upper-age relaxation of 5 years for
admission, in the courses wherever upper age restriction is applicable.
A claimant who fraudulently avails or attempts to avail any benefit meant for persons with
benchmark disability shall be punishable with imprisonment for a term which may extend to 2
years or with fine which may extend to one lakh rupees or with both.
(v)

5% for candidates belonging to Sports Category.

___________________________________________________________________________________________________________________
* Claimant in this category should be capable of pursuing the course for which the admission is sought. The Persons with Benchmark Disability (as per section

2(r) of the Rights of Persons with Disabilities (RPWD) Act 2016 should have a minimum of 40% disability duly certified by the Medical Board of
District/State/UT/Medical Institution of National Importance. Such certificate shall be further certified by the Medical Board of the Panjab University Health
Centre.

<!-- page 31 -->

FRONT PAGES

30

HANDBOOK OF INFORMATION 2022

(vi) 5% for candidates belonging to Defence (for all the under-mentioned categories taken together) who fall in one
of following categories (which are given here in order of precedence):
1.

Son/Daughter/Spouse of such Defence Personnel and CAPF Personnel1 who died in action (only those who
were wholly dependent on such personnel shall be considered)

2.

Son/Daughter/Spouse as are wholly dependent on such Defence Personnel and CAPF Personnel who were
incapacitated2/died while in service.

3.

Defence and CAPF Personnel who were incapacitated while in service.

4.

Son/daughter/spouse of ex-servicemen3 who are wholly dependent on them.

5.

Son/daughter/spouse of serving Defence Personnel and CAPF who are wholly dependent on them.

6.

Ex-Servicemen

7.

Serving Defence personnel and CAPF personnel

Note:

Except in the case of admission to evening courses, categories 2, 4 and 5 under 2 (B) (VI) will not be
considered, since the term "wholly dependent" will exclude such persons as are 'employed' or 'selfemployed'.

(vii) 2% for Sons / Daughters / Husband / Wife / Brothers / Sisters of persons killed / incapacitated in November,
1984 riots and of persons killed / incapacitated in Terrorist Violence in Punjab and Chandigarh. A Certificate
from the District Magistrate to this effect must be submitted by the candidate. Migrant Card alone is not
enough.
(Vide Syndicate Para, dated 17 June, 2018)
Note: In case there will be nay amendment /change in the existing clause, the same shall be notified and
communicated to all concerned departments by the Deputy Registrar (Colleges).
(viii) 2% for the Children/Grandchildren of Freedom Fighters who have been sanctioned pension by Central/State
Govt. or awarded Tamra Patra by Government of India (Synd. Para 15 dated 30-5-1997) or those who have been
certified to be freedom fighters by the Centre/State Govts.
(ix) Any other statutory reservation as prescribed by the Govt. of India, if any.

_____________________________________________________________________________________________________________________________________________________________________________________________________________

1.

CAPF earlier known as Para-military forces, includes Assam Rifles(AR), Border Security Force(BSF), Central Industrial Security Force(CISF), Central Reserve Police
Force(CRPF), Indo Tibetan Border Police(ITBP), National Security Guard(NSG), Sashastra Seema Bal(SSB) etc.

2.
3.

Incapacitation will mean incapacitation leading to the discharge of the person by authorities concerned.
Ex-serviceman means a person who has served in any rank whether as a combatant or non-combatant in the regular Army, Navy and Air Force of the Indian Union or in
CAPF:
(i) Who retired from the service after earning his /her pensions; or
(ii) Who has been boarded knout of the service on medical grounds attributable to military service / CAPF or circumstance beyond his control and awarded medical or
other disability pension; or
(iii) Who has been released from the service as a result of reduction in establishment; or
(iv) Who has been released from the service after completing the specific period of engagement, (otherwise than at his own request, or by way of dismissal, or discharge
on account of misconduct or inefficiency) and has been given a gratuity.
Territorial Army Personnel of the following categories shall also be considered as ex-servicemen:
a) Pension holders for continuous embodied service;
b) Disabled Territorial Army Personnel with disability attributable to military service;
c) Gallantry award winners.

<!-- page 32 -->

FRONT PAGES

31

HANDBOOK OF INFORMATION 2022

3.2 Additional seats including NRI (non-convertible) –
The below listed additional seats (a) to (i) will not be available for the courses governed by the
regulatory agencies such as AICTE, NCTE, MCI, DCI, BCI, PCI, AERB etc.
a)

b)

c)

d)

e)

f)

g)

h)

Wards of Kashmiri Migrants and Kashmiri Pandit / Kashmiri Hindu families (non-migrants living in
Kashmir Valley)
(i)
Relaxation in cut-off percentage upto 10% subject to minimum eligibility requirement.
(ii)
Increase in intake capacity upto 5% course-work.
(iii)
Reservation of atleast one seat in merit quota in technical / professional institutions
(iv)
Waving off domicile requirements.
Note: Seats in the above listed courses are subject to the norms of Regulatory bodies.
Documents required:A candidate seeking admission against this seat is required to produce a certificate from an authorized
Government Officer (i.e. Relief Commissioner/ Deputy Commissioner of the concerned district/area) to the effect
that the candidate is a ward of Kashmiri displaced person.
Proof of current residence (such as Ration Card/Photo Identity Card issued by the Election Commissioner /
Driving License/Aadhaar Card/Passport etc.)
The admission of a candidate against this category shall be provisional subject to verification of his/her
abovementioned certificates by the competent authority.
(Vide Syndicate Para 4, dated 13.07.2020)
Wards of Martyrs/permanently disabled in Kargil War
Concession be given for admission to various courses in Educational Institutions only to those wards of
martyrs/permanent disabled (up to 80% leading to incapacitation) of Kargil war who have a valid certificate from
the Ministry of Defence to this effect and the same be entered in the pension Book of the family:
1) 1% seats with minimum of 1 seat in the Departments except in partially financed/self-financing courses.
2) Exemption in fee.
3) Exemption in hostel fee
2 Seats under Supernumerary Quota
A quota of 2 supernumerary seats for each college/institute approved by AICTE, under General and Engineering
streams would be provided, for which the students would compulsorily have to apply through the web portal of
AICTE. Admission of students under the supernumerary quota would be as per their option, subject to merit.
Centrally Funded Institutes/Colleges are NOT covered under the Supernumerary Quota.
One Girl Child out of the only two girl Children
Two additional seats per unit per course subject to maximum limit of four (4) out of the two girl children from the
session 2015-16 are created for admission to a given course in the Panjab University Teaching Departments,
Regional Centres provided they are otherwise eligible from all angles. The additional seats will be only for those
girl Children who are either a single girl child of her parents or one amongst the only two girl Children with no
male Child. The additional seat will be available to only one of the two girl children of a couple.
An undertaking to be obtained from the parents of the girl children declaring therein that the benefit of this
scheme is being claimed for only One Girl Child out of the two girl Children and the parents shall not claim the
same for the 2nd Girl child elsewhere in future.
Cancer / AIDS / Thalassemia:
One additional seat each for the student suffers from Cancer / AIDS / Thalassemia has been allowed for
admission in each course in the Panjab University Teaching Departments, Regional Centres subject to the
condition that the candidate seeking admission under each of these categories if otherwise eligible from all
angles. The claimant candidate will have to submit a certificate, as a proof from the National Medical Institute like
PGI, AIIMS etc., in support of his/her claims.
Two Seats for Rural Area Students
Only those candidates will be considered in this category, who have passed their Matriculation and +2
examination from those rural schools that do not fall in the area of the Municipal Corporation / Municipal
Committee / Small Town / Notified Area / Cantonment Area. A candidate claiming such benefit will have to
produce a certificate from the D.E.O./Principal of the concerned institute of the area certifying that the school
from where the candidate has passed the Matriculation and +2 examination, falls within the aforesaid rural area.
One seat for Border Area Student
The Border area students shall mean those candidates who have passed their Matriculation from a School
situated in Border Area and +2 from a School situated in any other area. A candidate claiming such benefit will
have to produce a certificate from the Tehsildar or the Principal / Headmaster / Head of the School certifying that
the School from where the candidate has passed the matriculation, falls within the aforesaid Border area.
One Seat for Youth Festival
In all the teaching courses (except the courses governed by AICTE / NCTE / BCI / MCI / DCI etc.) being run in the
Panjab University Campus including constituent colleges / regional centres / affiliated colleges, one additional
seats reserved per unit for those candidates who have excelled and out performed by their participation in the
Youth Festivals. The candidate availing the aforesaid facility must fulfil the eligibility condition for admission to
the particular course. For those courses to which the admission is to be done on the basis of entrance test, the
candidate must have passed the entrance test. The selection of such candidates for admission to various courses
at PU Campus/ regional centres /constituent colleges, will be made by the respective admission committees. For
recommending admission on the basis of youth festival participation, admission criterion will be fixed on the
basis of merit as mentioned below and upon the verification of the original certificates of those candidate, who :

<!-- page 33 -->

FRONT PAGES

A.

i)

32

HANDBOOK OF INFORMATION 2022

have presented an item in an international cultural festival approved by Punjab Govt. /Govt. of India /
Panjab University.
B. have got distinction in All India National Inter University Youth Festival organized by AIU / Govt. of India
C. have got distinction in North Zone Inter University Youth Festival organized by AIU.
D. have secured first/second/third position in Inter University Youth Festival organized by Govt. of Punjab/
any State or Central University.
E. have secured first/second / third position in Panjab University Inter Zonal Festival.
F. have secured first /second /third position in Panjab University Zonal festival
G. have secured first/second/ third position in state level competition of State School Education Board of
Punjab/Haryana / HP/ or CBSE/ICSE or any other recognised board
1. Category A is considered as highest category followed by B , C …. onwards.
2. Preference will be given to the candidate who represented Panjab University Chandigarh in A, B, C
and D category
3. Achievement(s) only during the preceding 3 years of the year of the admission will be considered
In case two or more candidate have equal position at equal level then:
i.
Position secured in an individual item shall be rated higher as compared to as a team.
ii.
The eligibility of the candidate for participation in university youth festivals, in future, may also be
considered.
iii.
Academic record may be considered in case of tie between two or more candidate.
In case of any ambiguity, the related certificates be got verified from the Department of Youth Welfare through
the concerned Chairperson / Principal / Head etc.
The candidate admitted on the basis of youth festival additional quota seats shall have to give an assurance to
the university authorities that during the duration of the course the candidate will participate in the activities
associated with his item and will not create any kind of indiscipline. The admission committee will assess the
participation of the candidate and in case the candidate does not fulfil the requirements, his admission may be
cancelled. However, exemption can be given because of a special reason like sickness or any other unavoidable
reason in inter varsity Youth Festivals, National Festivals and International Festivals.
Categorization of International/NRI Students
A foreign national may seek admission in any of the courses being offered by the University through the
International
Students Office under any of the following categoriesi) Candidates with nomination / sponsorship by any foreign State, Embassy or authority in India under a
Study in India / Exchange Programme, etc.
ii) Foreign nationals or their wards who are self-financed students (not seeking admission through a mode as
mentioned in (i) above).
iii) Non- resident Indians or their Wards (not seeking admission through a mode as mentioned in (i) above).
The definition of the terms, "Foreign Nationals, Non-resident Indians and Wards" be considered as under:1. Foreign Nationals: Foreign Nationals holding passports issued by foreign countries including people of Indian
origin who have acquired the nationality of foreign countries are included as foreign students. Provided any
subsequent changes in the definition as may be notified by the Government of India shall have the same latest
meaning respectively assigned to them. The other expressions not defined herein shall have the meaning as
may be assigned in any subsequent notification of the Government of India.
2. Non-resident Indians: A person shall be deemed to be Non-resident Indian for seeking admission in Panjab
University if he/she fulfils the criterion (as amended from time to time) for status of NRI under Income Tax
Act, 1961, in the year in which he/she seeks admission in Panjab University.
As per Income Tax Act, 1961 the present criterion for determination of status of NRI is as follows:'Non-resident Indian' is an individual who is a citizen of India or a person of Indian origin and who is not a
resident of India. Thus, in order to determine whether an Individual is a non-resident Indian or not, his
residential status is required to be determined under Section 6. As per Section 6 of the Income-tax Act, an
individual is said to be non-resident in India if he is not a resident in India and an individual is deemed to be
resident in India in any previous year if he satisfies any of the following conditions:(ii) If he is in India for a period of 182 days or more during the previous year; or
(iii) If he is in India for a period of 60 days or more during the previous year and 365 days or more during 4
years immediately preceding the previous year.
However, condition No. (ii) does not apply where an individual being citizen of India or a person of Indian
origin, who being outside India, comes on a visit to India during the previous year.
A person shall be deemed to be of Indian origin if he, or either of his parents or any of his parents or any of his
grand - parents, was born in undivided India.
3. Wards of Foreign Nationals and NRIs:
A Student who seeks admission as a ward of Foreign National or Non-resident Indian should be in a first
degree blood relationship with foreign national or Non-resident Indian. The term first degree blood
relationship includes:
(a)
spouse
(b)
children (natural/adopted/foster)
(c)
real brother and sister of father, i.e. real uncle and real aunt
(d)
real brother and sister of mother, i.e. real maternal uncle and maternal aunt
(e)
father and mother of father, i.e. grandfather and grandmother
(f)
father and mother of mother, i.e. maternal grandfather and maternal grandmother

<!-- page 34 -->

FRONT PAGES

33

HANDBOOK OF INFORMATION 2022

(g)
first degree-paternal and maternal cousins.
Eligibility and Admission Criterion:
(i) The students who will be admitted in a course against the NRI quota should have the basic qualification fixed
by the respective regulatory body i.e., Medical Council / Dental Council / Bar Council of India / Pharmacy
Council of India for admission in Medical / Dental / Law graduate / post graduate courses. The Rules of
respective Regulatory Bodies shall apply as amended from time to time.
(ii) NRI candidates seeking admission to any course will be required to produce the Test Scores of Scholastic
Aptitude Test-II (SAT-II) with permissible combination of subjects, conducted by the Education Testing
Service, Princeton, U.S.A., for admission to under graduate courses; Graduate Record Examination (General)
(GRE) from Princeton, U.S.A., or GMAT for admission to Post Graduate Courses. In the case of foreign nationals
(non-English speaking countries), TOEFL/IELTS Scores should also be produced. However, those who have
passed the qualifying examination from India, shall qualify the entrance test conducted for the said course(s)
or meet the eligibility requirement of the said course, to be eligible for admission.
For M.Pharm. Degree, non GPAT candidates with 55% marks in B.Pharm. is also eligible.
(iii) Admission to all Engineering courses against NRI quota in the University Institute of Engineering &
Technology (UIET), University Institute of Chemical Engineering & Technology (UICET) and P.U. Regional
Centre, Hoshiarpur shall also be admissible through Direct Admissions Students Abroad (DASA) w.e.f. the
academic session 2018-2019.
(iv) For admission University School of open learning USOL: Foreign Nationals working in the foreign missions in
India and their dependents residing with them, subject to the condition that before submitting their Admission
cum Examination Form, they are required to obtain Eligibility Certificate from the Registrar, Panjab University.
Foreign students who have passed B.A. / B.Com Part-I Examination from this University, shall be allowed to
complete the remaining parts of these courses through USOL even while staying in their respective countries,
subject to the number of chances available in the respective examinations as provided in the Regulations.
(v) NRI candidates shall compete amongst themselves for admission to various courses. Their inter-se merit shall
be determined on the basis of the score obtained in SAT-II, GRE, GMAT etc.
(vi) A candidate once admitted as NRI candidate in a Undergraduate course shall be covered under the definition of
NRI for subsequent admission to any course at Panjab University.
(vii) Candidates who take admission under the NRI quota and are promoted from Undergraduate to Postgraduate
course in the Hons. School framework (ongoing program) shall not be allowed to change their category.
(viii) A candidate admitted under NRI quota may change his/her admission to a vacant seat provided the candidate
falls within the merit of admitted candidates in General or Reserve Category and has also applied for the same.
(ix) NRI candidates shall have to comply with any other requirements prescribed by the Govt. of India and Panjab
University from time to time.
(x) For admission to B.P.Ed. and M.P.Ed. (Physical Education), a candidate will be required to undergo mandatory
Physical Efficiency Test. The scores of Physical Efficiency Test will be counted for determining merit.
(xi) Foreign Nationals and NRI candidates shall provide the following certificates / documents:a) The Foreign Nationals and NRI students wishing to join any of the University Teaching Departments at
Panjab University for the first time are required to obtain an eligibility certificate from the Deputy
Registrar (General), Panjab University, Chandigarh or Academic certificates of passing the qualifying or
equivalent examination approved by the Association of Indian Universities (AIU) / Commonwealth
Universities / International Association of Universities (IAU) as equivalent to the corresponding Indian
Degrees/ Certificates.
b) Test Score of Scholastic Aptitude Test II (SAT-II)/ GRE/GMAT/TOEFL/IELTS etc. (if the qualifying
examination is not passed from India).
c) The foreign students admitted are required to fill up Foreign Student Information system (FSIS) Form
complete in all respects, along with copies of passport and Visa and submit to the office of Dean
International Students, Panjab University, Chandigarh. This form is an urgent requirement of the Foreign
Registration Office (FRO), Sector-9, Chandigarh and the candidate has to report to the Foreign Registration
Office (FRO) within fourteen days of arrival in Chandigarh, with the number generated after the online
submission of this form. Foreign Students Information System (FSIS) is to be submitted by hand by the
candidate and the FSIS No. will be issued by this Office personally to the students
d) Foreign Students Welfare Fee @Rs.1500/- per student. Each NRI/Foreign Student is required to submit the
same in cash, which may be deposited with the ‘Extension Counter, State Bank of India, Administrative
Block, Panjab University, Chandigarh. Original Receipts of the fee deposited is to be submitted to the office
of the Dean International Students along with Registration Form (To be submitted after Confirmation of
Admission).
(xii) The seats of Foreign Nationals and NRI are “Inter-Changeable”. That is, if sufficient numbers of eligible
candidates are not available to fill up the seats of NRI, seats may be filled up from among the eligible candidates
belonging to Foreign Nationals, and vice-versa. The conversion of seats shall be done after second counselling
for NRI / Foreign National or after exhausting the waiting list of NRI / Foreign Nationals.
In case, the number of eligible Foreign Nationals seeking admission exceeds the number of seats available, the
Vice-Chancellor, Panjab University may be authorized to sanction additional seats to the Foreign Nationals only.
(xiii) Candidates belonging to NRI (for all the under mentioned categories taken together) who fall in one of the
following categories shall be admitted in the following order of precedence:
1. NRI candidates;
2. Wards of NRI candidates;

<!-- page 35 -->

FRONT PAGES

3.

34

HANDBOOK OF INFORMATION 2022

NRI candidates who have not appeared in the entrance Test. In case of regulatory body, if permitted by the
said regulatory body;
4. Wards of NRI candidates who have not appeared in the entrance Test. In case of regulatory body, if
permitted by the said regulatory body;
(xiv) Foreign Nationals/NRI candidates seeking admission to the concerned course are required to compete amongst
themselves for the seats for them by appearing in the Entrance Test (wherever applicable) if they are in India,
i.e., those living abroad at the time of entrance test will be exempted from the entrance test. However, those who
have passed the qualifying examination from India, will not be exempted from the Entrance Test.
Explanation for calculation of category-wise seats and rounding off of fraction:
While working out the percentage of seats in the Reserved Categories as given above, if the number arrived at,
contains a fraction, this shall be resolved as follows :If the fraction is 0.5 or more, it shall be rounded off to 1; if it is less than 0.5, it shall be ignored. This shall, however,
not affect the total number of seats in the General Category. To ensure this, if the total number of seats after making
this adjustment exceeds the prescribed number fixed for the course, the necessary additional seats shall be created
with the prior permission of the D.U.I./Vice-Chancellor. Such seats, if created, shall be treated as additional only for
the year in question.
Illustration: In a course which has 35 seats, the distribution of seats among the various Categories will be as
under:
General
SC
ST
BC
Sports
Defence
Persons
Riot/
Freedom
Total
with
Terrorist
Fighter
Disability
Victim
53.5%
15%
7.5%
5%
5%
5%
5%
2%
2%
19
5
3
2
2
2
2
1
1
37
The total number of seats is increased to 37 (as above), the 36thand 37thseats will be treated as an additional seat in
the course for that year only. The additional seat, if required to be created, shall be created only for the Reserved
Category and not for the General Category. Such additional seat, if remains unfilled, will not be converted to General
Category.
4. Eligibility Conditions
For admission under any of the categories, General or Reserved, as given above, a candidate must be eligible to seek
admission. Eligibility shall mean the candidate's possessing the minimum qualifications as laid down in the relevant
regulations contained in the Panjab University Calendar, Volume II, 2016 including amendments made therein from
time to time and in the Handbook of Information 2021-2022. For such courses admission to which is based wholly or
in part on an entrance test/aptitude test, eligibility shall also mean the candidate's having taken the test and
qualified it.
4.1 The following are not eligible for admission to M.A. courses in the Faculties of Arts and Languages:
a) If a student fails to pass M.A. Part/Semester-I or fails to appear in the examination even though he/she had
requisite attendance, he/she be not allowed to seek re-admission in the Department for M.A. Part/Semester-I
in the same subject. Such a student can appear in the same examination as a private candidate as prescribed
under the University regulations;
b) If a student fails to meet the prescribed attendance requirement, and is, therefore, debarred from sitting in the
examination, or does not on his/her own violation seek permission to sit in the examination he/she should be
deemed to have failed in the examination. Such a student be not allowed to seek re-admission in the same
Department;
c)
If a student fails to earn promotion to the M.A. Part-II or the next semester of M.A. for any of the reasons
specified in Paras (a) and (b) above for two successive years in the same or two different Departments, he/she
should be debarred from seeking admission in any Department in the Faculties of Arts and Languages for the
next two years;
d) In order to ensure the implementation of the above conditions, the columns given in the Admission Form,
seeking information from the applicant on the course(s) attended by him/her in the preceding three years,
must be filled by him/her.
If he/she leaves these columns blank, the Admission Form will be rendered invalid and if he/she makes misstatement or conceals relevant facts, his/her admission will be cancelled and legal action can be taken against
him/her.
5. Inter-Changeability and transfer of seats
a) In the Reserved categories given at (i) and (ii) under paragraph 3 (B), i.e. Scheduled Castes and Scheduled
Tribes, the seats shall be regarded as 'interchangeable'. That is to say, if sufficient number of eligible
candidates are not available to fill up the seats reserved for Scheduled Tribes, seats may be filled up from
among the eligible candidates belonging to the Scheduled Castes, and vice-versa.
b) The seats in the Reserved Categories (SC/ST/BC/SP/Def/PwD/TV/FF) which remain unfilled shall be
transferred to the General Category subject to the condition that the waiting list of each Reserved Category has
been exhausted on 12.09.2022 for UG courses and 12.10.2022 for PG courses.
Any seat created in the Reserved Categories because of rounding off fraction shall stand cancelled and shall not
be converted to General Category.
Note: The Departments where admission is based on Entrance Test/Aptitude Test, seats in reserved
categories be included in the General Category right from the beginning of admission in case there were no
candidate belonging to these categories having qualified the Entrance Test were available.

<!-- page 36 -->

FRONT PAGES

35

HANDBOOK OF INFORMATION 2022

c)
If a candidate gets admitted under Reserved Category and is also placed on the consolidated waiting list
of General Category and gets a General Category seat on merit, the seat shall be offered to him/her (subject to
the condition that the candidate of SC/ST/BC/PwD categories fulfill the minimum eligibility requirement of
General Category and must not have availed of relaxation in eligibility marks) and his / her Reserved Category
seat shall fall vacant and shall be offered in order of merit to the next candidate of the Reserved Category.
6. Admission based on JEE & CAT
a) The Entrance Test conducted by CBSE (JEE) Mains in 2021 for the following courses: B.E. (Chemical), B.E.
(Food Technology), B.E. (Biotechnology), B.E. (Electronics& Communication), B.E. (Computer Science
Engineering), B.E. (Information Technology), B.E. (Mechanical), B.E. (Electrical and Electronics) and Five year
Integrated Course B.E. with M.B.A.
b) Admission to M.B.A., M.B.A. (International Business) & M.B.A. (Human Resource) is based on CAT 2021 and
Group Discussion and Personal Interview.
c)
Departments may conduct a test (Aptitude / Entrance) as part of admission process with the prior permission
of the competent authority.
7. Preparation of Merit Lists / Normalisation of Marks
Admission to both the (General and Reserved) categories of seats shall be on the basis of merit within each category
and the merit list shall be prepared as per these Rules. The basis for preparation of the provisional merit list shall be
as follows:
Marks of other Universities will be normalized to 2400 marks which are 3 years aggregate marks of B.A./B.Sc. (Gen.)
of Panjab University. Similarly, marks obtained by the candidates in the relevant subject will be normalized to 600
marks which is the total of 3 years aggregate marks of B.A./B.Sc. (Gen.) of elective subjects of Panjab University. The
normalization procedure is explained below:a) The marks obtained by a candidate in B.A./B.Sc. will be normalized on the basis of an aggregate. For example, if
a student has scored 495 marks out of total of 900 marks in B.A./B.Sc., his normalized aggregate marks (out of
2400) would be :- 495 x 2400/900 = 1320 out of 2400
These marks will be denoted by X and called the Basic Merit Marks.
b) The marks in the relevant subject (i.e., the subject in which the admission is sought) will be normalized by
changing the marks allotted to the relevant subject to 600 in order to give advantage of the subject to a
candidate. For example, if a candidate has obtained 240 marks out of 300 in the relevant subject, then the
normalized marks in the subject would be : 240x 600/300 = 480 out of 600 These may be denoted by Y.
Some universities award B.A./B.Sc. degree on the basis of aggregate marks of B.A./B.Sc. 2nd and 3rd years. In
that case the aggregate marks and the marks of the relevant subject in which the applicant is seeking
admission, will be considered on the basis of marks obtained in B.A./B.Sc. 2nd and 3rd years only for
calculation of the basic merit marks and in the relevant subject.
In some cases, there could be students who have not studied the relevant subject, or the study of the subject is
too elementary to be equated with the standard of B.A./B.Sc. level of Panjab University in the subject in which
they are seeking admission in Post-graduate course. For such category of students Y is taken to be zero.
Candidates having passed B.A./B.Sc. from other universities with 4 elective subjects in addition to optional
subjects at B.A./B.Sc. level shall not be given any credit under Y, i.e. Y shall be taken to be zero
c)
(i) Candidates who have passed B.A./B.Sc./B.Com. with Hons. Either from Panjab University or from any
other University would be given 15% weightage of the basic merit marks X obtained for the purpose of
admission in Post-graduate course in the subject in which Honours examination was passed. Similar
weightage would be given to candidates who have passed B.A./B.Sc./B.Com. examination according to
Hons. Like system specializing in one subject in which the admission is sought for the P.G. course.
For the purpose of admission to LL.M. courses under Panjab University:
Candidates who have passed B.A.LL.B (Hons.), B.Com.LL.B (Hons.), BBA.LLB. (Hons.) and LL.B. (Hons.)
either from Panjab University or from any other University would be given 15% weightage of the basic
merit marks, if certificate / DMC / Degree of candidate specify Hons. as per BCI rules.
Explicitly this weightage would be denoted by Z and calculated as follows:
Z = X x 15/100
(ii) Candidates who have passed a Special Degree from another University will be treated at par with B.A.
Examination of Panjab University with Honours in the relevant subject provided the B.A. Special Degree
is recognized as equivalent to the corresponding B.A. with Honours Degree of Panjab University in the
relevant subject.
d) Where no test is required for admission, the final Merit marks of a candidate would be X+Y+Z+ other
weightages as prescribed at 12.1 and 12.2. Other weightages as prescribed at 16.1 and 16.2 would be
calculated on the basic merit marks X.
e) The process of calculation of percentile score for admission to B.Sc (Hons.) and B.Pharm. courses will be as
follows:
for the B.Sc. (Hons.) admissions, the final merit should be prepared on the basis of merit consisting of three
components (i) CET merit with weightage 75 %, (ii) 10+2 examination merit with weightage 25 %, and (iii)
over and above weightage of NCC, NSS, etc.
For preparing the combined merit of CET for the two streams of students with (i) Physics, Chemistry and
Mathematics combination and (ii) Physics, Chemistry and Biology combination, the two streams should be
evaluated independently. The final merit list for the admission to B.Sc. (Hons.) under the framework of
Honours System should be prepared by adding (i) CET percentile score with 75 % weightage, (ii) 10+2
examination marks with 25 % weightage, and (iii) over and above weightage of NCC, NSS, etc. in terms of
marks.

<!-- page 37 -->

FRONT PAGES

36

HANDBOOK OF INFORMATION 2022

The CET percentile score (P) for the qualified candidates from the two streams (i) and (ii) will be calculated
separately using the formula
where R is the rank of the candidate in the merit list of that stream and N is the total number of candidates
appeared in that stream. For example, if the number of candidates appearing in a stream (i) is 4000. For a
candidate ranking at 485th position in the merit of stream (i), the percentile score of the candidate will be
The final combined merit list for the two streams will be based on
Total merit marks = 0.75*P + 0.25*Q + weightages for other activities; where P is the CET percentile score, Q is
the percentage total marks in the PCB (Physics, Chemistry & Biology) or PCM (Physics, Chemistry &
Mathematics) subjects in the 10+2 or its equivalent examinations. For the courses where candidates with
PCM and PCB combinations are eligible for admission, the higher of the two will be taken for calculating the Q
component. Weightages for activities like NCC, NSS etc. as mentioned in the handbook of information, if any,
will be calculated on the above mentioned Q component. Total merit marks will be calculated up to third
decimal place. Any changes in the marks of the qualifying examination (10+2 class) or its equivalent
examination or other weightages in any case will simply change the total merit marks of that student and
merit list will be updated accordingly.
For admission to B.Sc. (Hons.) under the framework of Honours School System (CBCS) in mathematics where
the admission is based only on marks obtained in mathematics in CET, the marks obtained in CET in
Mathematics, called X1,, will be calculated out of 120. The total marks obtained in 10+2 examination (taking
all subjects into consideration) will be calculated out of 40 called Y1 (i.e. if T = total marks, M= Marks obtained
than Y1= (M/T) x 40, calculate to 2 decimal places. The merit for admission will be X1 + Y1 out of 160.
8.

Promotion Rules for Choice Based Credit System B.Sc. (Honours) under the Framework of Honours School
System (Semester System) being run at Panjab University Campus.
i A student who appears in an odd semester examinations or who was eligible to appear in the odd semester
examinations, but remains absent in any or all the papers of the said semester, shall move on to the next even
semester irrespective of his / her result in the said examination.
ii A student shall be promoted to successive next years, subject to the following conditions:
Class
Credit requirements
For promotion to B.Sc. (Hons.) 2nd year
80% of the total credits in B.Sc. (Hons.) 1st year
For promotion to B.Sc. (Hons.) 3rd year
80% of the total credits in B.Sc. (Hons.) 2nd year
st
For promotion to M.Sc (Hons.) 1 year
90% of the total credits of B.Sc. 1st, 2nd and 3rd years
For opting out of the course by taking 120 credits in the B.Sc. (Hons.) under the framework of
B.Sc. (General) Degree
Honours School System and having cleared all Generic Elective
courses
iii Students who do not fulfill the promotion criteria mentioned above shall be declared fail in the promotion
examination of the academic year concerned. However, he/she shall have the option to retain the marks in
the papers of his / her choice.
iv If a student has secured an aggregate of minimum 40% marks taking together all the papers in theory
examination (including internal assessment / project, wherever applicable) and practical examination
separately till the end of third year, i.e. upto the end of the 6 th semester, then she/he shall be awarded the
degree in which the student has been admitted.
v A candidate having obtained 120 credits in the B.Sc (Hons.) under the framework of Honours School System
and having cleared all Generic Elective courses may seek the award of B.Sc. (General) in case he / she wishes
to discontinue the Honours School System after completing three years of studies of the B.Sc. (Hons.). The
grading in the case of such candidates shall be determined by the Regulations as for the Honours School
students taking into account the best of 120 credits which he / she has obtained.
9. Admission to M.A. Semester-I on the basis of Master's Degree examination in another subject or in another
Faculty: If the eligibility is to be determined on the basis of M.A. Degree, then merit is to be determined on that
basis alone. Weightage will not be given for the relevant subject on the basis of marks obtained in Graduation.
10. Compartment Candidates
A candidate who has been placed under compartment in one subject in B.A. Third Year examination of this
University shall be allowed to join M.A. First Year (Semester System) class provisionally if he/she fulfils other
requirements and provided-(i) that the re-appear is not in the subject in which he /she is seeking admission in M.A.;
and (ii) If he/she fails to clear the compartment subject of the B.A. Third Year examination in the next two
consecutive chances immediately following the examination in which he/she was placed under compartment,
his/her provisional admission to M.A. First Year (First and Second Semesters) examination shall be cancelled.
(Amendment V Under Regulation 12 (P-93) Cal. Vol.II)

11. Admission to M.A. Semester-III for candidates who have passed their MA Semester I & II examination (other
than the regular students of Teaching Departments of Panjab University):
The vacant seats in each category shall be filled by the respective Board of Control on merit provided that any
candidate so admitted shall have secured marks in Semesters I & II not less than the marks of the last candidate in
the merit list of students promoted by the Department from M.A. Semester II to Semester III and the outside
candidate (other than the regular student of respective Department) having Reappear/Compartment will not be
considered for Admission to M.A. Semester-III.

<!-- page 38 -->

FRONT PAGES

37

HANDBOOK OF INFORMATION 2022

12.1. Weightages:
The following weightages shall be given, wherever applicable, on the normalized aggregate marks arrived at or on
academic weightage determined for qualifying examination for courses covered under the Entrance Test. However,
these weightages, for those courses which are purely based on Entrance test, shall not be applicable.
A. 15% Hons. Weightage be given to candidates who have passed B.A./B.Sc./B.Com with Hons. either from Panjab
University or from any other University.
B. 5% of the marks thus obtained by such candidates as have passed the qualifying examination from Panjab
University.
C. Up to a maximum of 4% for distinction in any or all of the following co-curricular activities, achieved in any of
the 3 years preceding to the year of admission (except for NCC for which the certificate once achieved is for
lifetime).
a) N.C.C.
The holders of N.C.C. A, B and C certificates shall be given the weightage in marks as under:
A : 1%
B : 2%
C : 3%
b) N.S.S.
The accreditation of A, B & C certificate & weightage 1%, 2% & 3% for NSS volunteers.
1. 'A' Certificate
1% of obtained Marks
Completed One year (120 hours) and Participated in Seven day and night camp. (one Camp)
2. 'B' Certificate
2% of obtained Marks
Completed Two years (240 hours) and Participated in Seven day and night camp. (two Camps)
3. 'C' Certificate
3% of obtained Marks
Completed Three years (360 hours) and Participated in Seven day and night camp. (three Camps)

c) Weightages to be given for participation / awards in skill in Teaching Competition (during B.Ed.) at Zonal, Inter
Zonal level for admission to Post Graduate courses in Education (M.Ed. / M.A.) as under:
Winner at Inter Zonal
First
Second
3.5%
3%
Winner at Zonal Level
First
Second
2%
1.5%
Participation at Zonel Level
0.5%

Third
2.5%
Third
1%

d) YOUTH WELFARE
i) Youth and Heritage Festival: (Maximum of 3%)
Level of the festival
First
Second / Third
Participation
International Festival (G.I.O. recognized, representing the
3.0%
2.5%
2.0%
University / recommended by the Youth Welfare
Department, P.U.
National Inter University / Inter State Festival
2.5%
2.0%
1.5%
North Zone / Punjab State / University Inter Zonal festival
2.0%
1.5%
1.0%
University Zonal Festival
1.0%
0.5%
ii) Youth Training Camps: 1% marks per camp (subject to maximum 3%)
Participation in Youth Training Camp
National Integration Camp
Youth Leadership Training Camp
Mountaineering
Hiking-Trekking Camp
Rock Climbing Camp
Students coming from other Universities shall also be considered at par for weightage as tabled above.
e) ADULT EDUCATION:
(1) For students who are running adult education centres:
(i) For making 10 students literate
Credit point = 0.35%
(ii) For making 15 students literate
Credit point = 0.65%
(iii) For making more than 15 students literate
Credit point = 1.00%
Norms of proficiency in literacy would be as laid down by the Directorate of Adult Education, Ministry of
Human Resource Development, (G.O.I.).
(2) For the student volunteers of mass involvement for functional literacy:
(i) For making 2 students literate
:
Credit point=0.35%
(ii) For making 4 students literate
:
Credit point=0.65%
(iii) For making more than 4 students literate
:
Credit point=1.00%
Persons claiming credit on this account will obtain the desired certificates from the Director, Centre for Adult
Continuing Education, Panjab University, Chandigarh. (Vide Syndicate Para 16, dated 16-5-1987)
D. Any other weightage approved by the D.U.I./Vice-Chancellor.
These weightages shall not be used for determining eligibility for admission as prescribed under the
Regulations of each course.
12.2. Additional weightages will be available to the following categories of candidates as indicated:
(i) M.P.Ed.

<!-- page 39 -->

FRONT PAGES

38

HANDBOOK OF INFORMATION 2022

a)

A person getting any of the first three positions in the Olympic / World Game/
Commonwealth Game/ World Cup Tournaments / Asian Games
b)
A person representing India in the above said games / Tournaments
c)
A person representing India in official test matches abroad and within the country
d)
1st position in All India Inter-University / Senior National approved games competition
conducted by the respective Federations
e)
2nd position in the above said competitions
f)
3rd position in the above said competitions
g)
1st position in Zonal Inter-University competitions
h)
2nd position in the above said competitions
i)
3rd position in the above said competitions
j)
A person representing University in the Inter-University / State in the Senior National
Competitions
(ii) B.P.Ed
a)

A person getting any of the first three positions in the Olympic / World Games /
Common wealth Game / World Cup Tournaments / Asian Games
b) A person representing India in the above said games / Tournaments
c) A person representing India in official test matches aboard and within the country
d) 1st position in All India Inter-University/Senior National approved Games /competition
conducted by the respective Federations
e) 2nd position in the above said competitions
f)
3rd position in the above said competitions
g) 1st position in the Zonal Inter-University competitions
h) 2nd position in the above said competitions
i)
3rd position in the above said competitions
j)
1st position in the Inter College/State approved Games/ competitions / participation in
Inter-University / Senior National Competitions
k) 2nd position in the above said competitions
l)
3rd position in the above said competitions
Note: Only one highest admissible position will be considered for giving Weightage listed above.

50 marks
40 marks
30 marks
20 marks
15 marks
10 marks
9 marks
8 marks
7 marks
6 marks

50 marks
40 marks
30 marks
20 marks
15 marks
10 marks
9 marks
8 marks
7 marks
6 marks
5 marks
4 marks

13. Resolving of ties:
In the case of a tie at any stage in the preparation of the merit list, candidates securing equal marks will be
bracketed together.
Their inter-se-merit will be determined according to the following criteria:
(i) A candidate getting higher percentage of marks in the qualifying examination shall rank higher in order of
merit.
(ii) That if the marks in qualifying examination are also the same then the candidates obtaining more marks in
the immediate lower examination, shall rank higher in order of merit.
(iii) That if two or more candidates secure equal marks in (i) & (ii) above, the candidate senior in age shall rank
higher in the order of merit.
Note: When the provisional lists of candidates (based on merit) are displayed on the Notice Board, the
Chairpersons shall mention the fact that this list is subject to change on account of improvement of result of the
qualifying examination wherever applicable. The new result must be presented at the time of interview/operating
of the waiting list.
14. COUNSELLING:
All the candidates whose names appear on the Provisional Merit List shall have to appear in person, on the notified
date(s) of Counselling, before the Board of Control of the subject concerned or a Committee of the Board of Control
constituted by the D.U.I/Vice-Chancellor. Physical presence in the counselling is mandatory for all the candidates
on the notified dates. All those candidates who attend the counselling are required to mark their attendance in each
counselling. Only those candidates who report and mark their attendance on the day(s) of counselling shall be
considered for admission during the filling up of vacant seats. The candidates must produce all the relevant
certificates (in original) for checking/ verification at the time of Counselling, failing which they will not be
considered for admission.
The requirement of marking of attendance does not apply to the counsellings of PU-CET (UG) and MDS. This
requirement does not apply even to all such counselling(s) which are jointly handled by partnering institutions who
will notify their own process of counselling.
15. Preparation of Merit List of Selected Candidates / Waiting List:
After interacting with the candidates in a counselling, comprising of General and all reserved categories, and
taking into account all the criteria of admission applicable (for instance, the scores, plus weightages, or the addition
of the score of Admission / Aptitude Test, Group Discussion, Personal Interview, wherever applicable) each
Department/Centre / Joint Admission Cell shall prepare the Merit List of Selected Candidates and Waiting List of
waitlisted candidates (category-wise) in order of merit (to be approved by the DUI). These lists shall be signed by
each member of the Board of Control/ Committee of the Board of Control/ Joint Admission Cell (approved by the
D.U.I.), certifying that these lists have been prepared in order of merit and the relevant rules and regulations as laid
down have been followed.
In case, the general category seats are declared vacant, the reserved category candidate shall be
accommodated on merit-basis against the vacant general category seats on priority as per the approved

<!-- page 40 -->

FRONT PAGES

39

HANDBOOK OF INFORMATION 2022

Waiting list, in accordance with the rules. This procedure shall be followed before declaring the vacant
seats for the next counselling.
The Department/Centre/Joint Admission Cell shall then send the following lists (in duplicate) for the DUI's
approval:
i.
Provisional Merit List of all candidates category-wise;
ii.
List of Merit List of Selected Candidates recommended for admission (category-wise) in the order of merit
and their Admission Forms;
iii. Waiting List carrying the names of the waitlisted candidates (category-wise) in the order of merit including
the names of the candidates who have been listed at the top of the Waiting List as Late Applicants, if any,
and the Admission Forms of the Reserved Categories;
iv.
Attendance of all the candidates taken at the time of counselling(s).
v.
The reserved category candidates who have availed relaxation in eligibility marks shall not be included in
the general merit list.
If a candidate, whose name is on the Provisional Merit List and is denied admission while a candidate below him is
selected, the reasons for admission being denied shall be recorded and such a case shall be brought explicitly to the
notice of D.U.I.
16. Admission of candidates whose result is revised as a consequence of re-evaluation or otherwise late
declaration of result, can be made only if:
i.
Seat is available;
ii.
Candidate is higher in merit than the candidate in Waiting List;
iii.
The request is made before the last date for late admission with the prior approval of the Vice-Chancellor
as already laid down.
The following Rule in the P.U. Cal. Vol. III, 2016 at page 489 will be followed in case of re-evaluation cases:
If as a result of re-evaluation, a candidate passes at the Exam., he/she shall be eligible to seek admission to the next
higher class within ten working days of the communication of re-evaluation result to him/her. His/her attendance
shall be counted from the date of his/her admission. However, no candidate would be granted admission on the
basis of revaluation result after 31st December of the academic session. In the case of admission to a course having
Semester Exam, the date will be October 15.
In case of ongoing classes, each student whose result of the lower semester/class has not been declared, shall have
to seek provisional admission with an undertaking to the effect that his/her admission shall stand cancelled if
he/she fails to meet the eligibility requirement(s) for promotion to the next higher semester/class as per the rules
and regulations of the course. The date of start of teaching of ongoing classes shall be notified by the Dean of
University Instruction and the counting of attendance for the purpose of calculation of shortage of lectures will be
made from the above-said notified date of start of teaching. If the candidate, whose result of lower semester/class
has not been declared, seeks the provisional admission after the start of teaching, his/her attendance will be
counted from the notified date of start of teaching and not from the date on which he/she seeks provisional
admission. The candidate after the declaration of result of lower semester/ class will have to deposit the due fees
within ten days of such declaration in order to get his/her admission confirmed.
(Syndicate Para No. xliii of 30.04.2017)
17. Revision of Merit and placement of applicants:
The requirements of Rule 17 for physical presence and marking of attendance in the counselling(s) will not be
applicable to a candidate whose result has been declared late. However, requirements of Rule 17 shall become
operative after this, i.e., the candidate will have to mark his/her attendance in the Counselling.
A candidate whose merit is revised consequent upon the late declaration of result after the conclusion of
counselling, and his/her revised merit falls among the selected candidates in the category-wise Merit List, his/her
name be placed at the top of the Waiting List. (Syndicate Para 40, dated 12-3-2005)
18. Rejection of incomplete Admission Form:
The Board of Control/Committee of Board of Control/Joint Admission Cell shall reject the Admission Form which it
regards as incomplete. Reasons for rejection must be recorded on the Admission Form.
19. Cancellation of Seat/Admission
Admission of all such students who fail to attend at least 33% of the total lectures delivered and practicals held in
all the papers during the first 10 working days from the start of teaching work in the course concerned shall be
cancelled by the Board of Control/Joint Admission Cell after following the procedure given below:
a) By the 12th day after the start of classes for a particular course, the names of those students who fail to attend
atleast 33% of the total lectures / tutorials / practicals etc. shall be put up on the Notice Board and online
Notice Board of the Department and also send a copy of the same to the office of the DUI. Within 4 days of the
date of such notice, a student who is short of attendance may give in writing the reasons for his absence from
the classes.
b) If a student does not submit an application in writing within the prescribed time as stated above, or the
reasons adduced by the student in his application are not found to be sufficient and justified in the opinion of
the Board of Control / Joint Admission Cell, his admission shall be cancelled.
c) All the seats thus falling vacant shall be filled strictly in the order of merit from the waiting list or through
subsequent counseling before the expiry of the last date fixed for admissions by the University.
d) When the admission of the student(s) is cancelled as stated above, the Department shall display on the Notice
Board and online Notice Board, the list of the person(s) next in the waiting list and make admissions
accordingly.
e) Approval of cancellation of admission and permission to fill up the cancelled seat(s) to be sought from the DUI

<!-- page 41 -->

FRONT PAGES

40

HANDBOOK OF INFORMATION 2022

Note: It is obligatory on the part of students to keep in touch with the Department concerned for the possibility
of the seats to fall vacant.
20. Admission for late applicant with high merit (only in case of offline Admission Form):
This Rule shall be applicable only to those courses where hardcopy of the Admission Form is to be submitted along
with the photocopies of testimonials in the concerned Department and the Admission Form is received after the last
date of submission but not later than the date(s) of first counselling. In such a case, Board of Control / Admission
Committee / Joint Admission Cell shall admit the late applicant in the General / Reserved / Additional Category
(with the prior approval of the DUI / Vice-Chancellor) but only if his/her merit falls in the merit of the first 25% of
the applicants appearing in Merit List of Selected Candidates.
21. Checking of Certificates:
All self-attested copies of the original certificates / testimonials submitted by the candidate alongwith the
Admission Form in support of the claims, shall be checked against the originals at the time of Group Discussion /
Personnel Interview / Counselling. For the marks obtained, the original certificates shall be ones issued by the
University /Board concerned only, and NOT by any Principal of a School/College. In case, a candidate happens to
have surrendered the original certificate to an institution/office, for admission or for re-evaluation etc. then the
candidate has to produce a certificate to the effect issued by the Institution in which such certificate (s) have been
deposited / acknowledgement slip confirming the deposit of original certificate(s) may be considered, after a
satisfactory explanation from the candidate in writing. Admissions based on such certificates shall be treated as
provisional.
The Character Certificate submitted by a candidate shall be from the Head of the Institution/ University Department
last attended irrespective of the gap in studies, if any.
A certificate/undertaking, submitted by the candidate in support of a claim, should be in the format given in the
Handbook of Information 2022-23 for admission purposes. A certificate/undertaking in a format other than the
prescribed one shall be rejected.
22. Certificate concerning gap year(s):
Candidates whose career reflects a gap of year(s) between passing of the last examination and the year in which
admission is being sought, they are required to furnish, at the time of application, an undertaking to the effect that
they were not involved in any offence/unlawful activities during the year(s) of gap. The Board of Control/Joint
Admission Committee shall satisfy that, during this gap period, the candidates were not involved in any
offence/unlawful activities.
23. Verification of SC/ST Certificates:
The admission of the SC/ST candidates producing the requisite certificates of being SC/ST for admission in various
courses at this University be made provisional subject to verification of the certificates from the issuing authority by
the Chairperson of the department concerned, as required in the UGC letter circulated by D.R. (Academic / Colleges)
vide his Endst. No. 5201-5350/Spl. Cell/SC/ST dated 30-9-1991.
24. Medical check-up:
A candidate selected for admission is required to submit a Medical Certificate of Physical Fitness as per the
proformas contained in Handbook of Information 2022-2023 / Prospectus released by a Department / Institute /
Centre for admission purposes. This certificate is a pre-requisite for the confirmation of the admission. Students
should approach the C.M.O.'s Office on the prescribed date(s) only after obtaining admission slip from the
Department and after paying the prescribed Medical Fee.
25. In the event of any difference in the interpretation between Handbook of Information & Rules of Admission
2022-2023 or various Prospectuses of admission published separately, the matter shall be referred to D.U.I.
/ V.C. whose decision shall be final.
Further, in preparation of the Merit List if there are cases which are not covered in these rules, the same may be
referred with factual details along with the recommendations of the Board of Control for consideration to the
D.U.I./V.C whose decision shall be final.

Dean of University Instruction

<!-- page 42 -->

FRONT PAGES

41

HANDBOOK OF INFORMATION 2022

GUIDELINES FOR ADMISSION TO THE RESERVED CATEGORY OF SPORTS

(Candidates are advised to visit website of Sports Department at www.sports.puchd.ac.in)
Five percent seats of the total number of seats in each course are reserved under this category. No benefit on the basis of
sports shall be given to candidates who did not apply for the admission under reserved category of sports.
1. Each candidate applying for admission in this category shall, along with the Admission Form, will submit following
documents to the concerned department and photocopy of one complete set of Admission Form, along with the all
relevant documents after paging all the documents, will submit in the office of Campus Sports, (Gymnasium Building),
P.U. Chandigarh before the last date of submission of form (upto 15.07.2022 for UG courses available at
https://ugadmissions.puchd.ac.in
and
upto
22.07.2022
for
PG
courses
available
at
https://onlineadmissions.puchd.ac.in). The candidate has to submit the form complete in all respect within the
stipulated date in the concerned department and in the Campus Sports Department.
a) Self-attested photocopies of sports certificates with photograph duly attested by the respective issuing
authority (i.e. National Federation of Concerned game/ State Association/ Head of the Institution of last
attended / self attested).
b) Self attested photocopies of Class 10th and Class 10+2 and Bachelor’s Detailed Marks Certificates.
c) Undertaking of the sports achievements (Annexure-I) and attendance in sports grounds (Annexure-II).
d) List of players of the team/ competitors of the concerned sports tournaments duly attested by the respective
issuing authority / Head of the Institution of last attended/ downloaded from concerned official website.
2. The DUI has the authority to cancel admission at any time, if it is found that the candidate has obtained such
admission on the basis of a false certificate or incorrect statement/record.
3. Candidates seeking admission under Sports category will be considered for admission only in the games / events /
sports which are included in the Olympic Games / Asian Games / Commonwealth games immediately preceding the
year of admission. Along with the games included in the above said tournaments, four games namely Chess, Cricket,
Kho-Kho and Yoga will also be considered as eligible sports disciplines for admission under reserved category of
Sports (Annexure-III).
4. Reservation under Sports Category is meant only for those active sports-person1 who would participate in the
Campus, University, State, National, International level Sports Tournaments. Such students will be considered for
admission only if:
i. Their achievement in sports relates to their activities in any of the four years immediately preceding the year of
admission2 (relaxable to 5 years in exceptional cases, on merit, for outstanding sportspersons3).
ii. They are otherwise also eligible for participation in Inter-College, Inter-University tournaments. Candidates
applying for sports quota must also be eligible on the basis of age to participate in the Inter University
Competitions representing Panjab University for the next one year of their course duration.
iii. The Candidate shall qualify in the Sports trials i.e. General Fitness test and Skill & Game Performance Test in the
concerned game. Dates of the trails will be notified later on. It is essential to qualify the General Fitness Test
as per the norms laid in (Annexure-IV) for appearing in Skill & Game Performance Test and it is essential to
qualify the Skill and Game Performance test to be eligible for verification of original sports certificates for
awarding marks. The Sports Merit will be prepared as per Annexure-V.
iv. No document including Undertaking etc. will be accepted after the last date of submission of Admission Form by
the Campus Sports Department. However, in case any sportsperson earns any achievement up to June 30, 2022,
he/she may submit supplementary copy of the document to the Campus Sports Department along with
additional Undertaking.
v. Sports Participation in the same game in two different competitions in two different academic sessions
(irrespective of the event) is essential for the candidates seeking admission under this category within the
prescribed period of four years i.e. from 1st July 2018 to 30th June 2022. The merit for admission in the Sports
Category will be purely on the basis of criteria given in Annexure-V. However, the minimum level of sports
participation to be considered for supporting certificates will be Inter school / Inter College /Regional/ Cluster
/District/ State Level Participations.
5.
A committee constituted by the Vice-Chancellor shall prepare the sports merit of applicants applying under reserved
category of Sports by screening the applications, conducting General Fitness Test, Skill & Game Performance Test and
verifying the original Merit / Participation Sports Certificates of the applicants as per norms incorporated in
1Means a person attending the grounds regularly so as to appear himself for participation in the Inter-College and Inter-University

Tournaments. However, his/her age fall within the age group which is eligible for participation in Inter-College/Inter-University
Competition.
2Preceding four years means from 1st July 2018 to 30th June 2022.
3Securing first three positions in All India University / Senior National Championships/ National Games / Participation in International
Competition (competitions/ tournaments which are mentioned in Annexure V) at senior or junior level recognized by Competent
Authority of the respective game as mentioned in Clause 14.

<!-- page 43 -->

FRONT PAGES

6.

7.

8.
9.

10.
11.

12.

13.

14.

15.

16.

17.
18.
19.

42

HANDBOOK OF INFORMATION 2022

Annexure -V. Only such applicants will be allowed to appear for the actual sports trials, whose application is found in
conformity with the requirement/ qualifications mentioned in the Guidelines by the Campus sports Department.
Candidates are to appear for sports trials in proper sports kit with all the original sports certificates and required
academic certificates.
The Campus Sports Department, Panjab University shall take an undertaking (Annexure-II) from the candidates that
they will attend the grounds regularly and must have 75% of attendance in the sports ground and would also
participate in the Inter-College, Inter-University, State, National and International sports tournaments, if selected.
Their admission would be liable to be cancelled if the terms of the undertaking thus given are not adhered to.
The order of precedence in the selection of candidates for admission will be as per Annexure-V.
i.
Applicant securing higher marks in sports merit will be placed / given higher preference.
ii.
If there is a tie within the same category, the tie shall be resolved by considering the 'academic merit’ i.e. as
per admission criteria of the concerned department and even then if there is tie, it will be resolved by the
seniority in age i.e. date of birth of the candidate and such tie will be resolved by the concerned Department in
which an applicant applied for admission.
Age category tournaments such as sub-junior, junior, youth, cadet etc. are vary from game to game. In this regard, P.U.
Admission Committee for sports will take the decision whether the performance of the players fall under junior/
youth category as per age criteria mentioned in Annexure-V.
It is mandatory to participate actively in all sports competitions, if selected, and at least 75% attendance in Panjab
University sports grounds is required to enable to sit in the examination for all the candidates admitted against
reserved category of sports. The attendance certificates shall be issued by the Campus Sports Department in favour of
each candidate whose attendance in sports grounds is at least 75% and admit card for examination shall be issued by
the Chairperson only on the production of such a certificate.
When a candidate is required to abstain from the Department for participation in Inter College / Inter University /
National / International / State Sports Tournaments, he/she shall give prior information to the Chairperson of the
concerned Department.
If a candidate admitted under the reserved category of Sports, remains absent from the grounds for regular practice
for a continuous period of seven days without leave, his/her names shall be struck off the rolls by the Chairperson of
the concerned Department on the recommendation of the Director Physical Education & Sports, Panjab University,
Chandigarh.
Deficiency of equal numbers of lectures (theory, practical, seminars and tutorials etc.) shall be condoned for
sportspersons for attending Coaching Camps and participation in various tournaments i.e. Inter Hostel and Inter
Department (Conducted by P.U. Campus Sports), Inter College, Inter District, State, Inter State, Inter University,
National and International level tournament.
In case a candidate does not attend the grounds for practice or does not participate in the P.U. Campus Sports
Activities including Campus Annual Athletic Meet, Inter College Competition, Inter University Tournaments on
medical grounds, the Medical Certificate issued only by the University Chief Medical Officer will be accepted.
NOTE:
In case a student remains present in the concerned Department for classes but absent in the grounds for
sports then his/her Medical Certificate will not be accepted and his/her admission shall liable to be cancelled.
In case there is one association / federation or more than one association / federation in any game the sports
certificates issued by those State Associations will be considered which are recognized by National Federation of the
concerned game for State level tournaments. Further, for International/ Inter state and National level competitions,
the certificates issued by only those National Federations of the concerned game will be considered which are duly
recognized by Ministry of Youth Affairs and Sports India and the recognized National Federation of the concerned
game must be recognized by International Federation of the concerned game for International tournament. In case
of Cricket, BCCI will be the competent authority. For International level competitions, the certificates issued by those
National Federation / International Sports Federation of the concerned game (e.g. FIBA, FIFA etc.) will be considered
which are duly recognized by concerned Country’s Olympic Association and Ministry of Sports. Such National
Olympic Association should be duly recognized by International Olympic Committee.
Certificate on Letter head will not be considered in normal course. The Certificates of the concerned tournament must
be signed by minimum two office bearers of concerned Association / Federation. However, if the certificates are not
issued by some sports Organization / Association in a particular game, those cases will be looked after separately by
the screening committee on the recommendation of Campus Sports Department.
The clause 4 (i) and (ii) will not be applicable for Arjuna Awardeee / Rajiv Khel Ratan Awardee / Padam Shree
Awardee / Olympians in any game/sports with the condition that if such a candidate is successful in getting
admission but barred for participation due to age bar then he/she will coach or groom a team of his expertise for at
least five hours a week without seeking any remuneration.
The admission of students under reserved category of sports will be provisional until the verification of sports
certificates from the concerned issuing authority.
No invitational / Memorial / Open /Prize Money League/ Ranking tournament will be considered for admission
under reserved category of sports. Further, marks will not be given for tournament which are held more than once a
year.
The sportspersons who have represented in the recognized competitions recognized by Ministry of Youth Affairs and
Sports, Olympic Games by International Olympic Committee, World Championship / World Cup by International
Sports Federations, Commonwealth Games by Commonwealth Games Federation, Asian Games by Olympic Council of
Asia, Asian Championships by International Sports Federations, South Asian Federation Games (SAF) by South Asian
Sports Council, Paralympic Games by International Paralympic Committee, World University Games By FISU/ Asian
University Games / Championship by AUSF (Asian University Sports Federation), University games by AIU, National
games and Championships by National Sports Federations of the concerned game recognized from Ministry of Youth
Affairs & Sports or Ministry itself, State Level Games by recognized State Sports Associations/ State Directorate of

<!-- page 44 -->

FRONT PAGES

43

HANDBOOK OF INFORMATION 2022

Education / School Boards and Inter College by concerned University will only be eligible for admission under
reserved category of sports in Panjab University, Chandigarh.
