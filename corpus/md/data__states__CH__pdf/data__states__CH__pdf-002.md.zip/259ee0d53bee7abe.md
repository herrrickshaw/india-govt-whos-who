---
doc_id: "259ee0d53bee7abe"
source_url: "https://purch.puchd.ac.in/includes/noticeboard/2025/20251001163801-handbookofhostelrules2025-26.pdf?2026"
ministry: "P.U. Swami Sarvanand Giri Regional Centre, Panjab University, Chandigarh"
title: "Handbook of Hostel Rules session 2025-26"
date: ""
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d31deac8bb08720d"
---

<!-- page 1 -->

MESSAGE
Panjab University SSG Regional centre, Hoshiarpur welcomes the students to the lush
green campus spread over 10.4 acres. The serenity of the campus goes a long way for the students
to focus on the goals for which they have taken admission to this campus.
A hostel inside the campus not only provides a comfortable stay to the residents but acts
as a platform to mingle with students of different streams in addition to their own stream. It is
a place where the horizons are widened and out of box thinking comes. The campus has hostel
facilities with capacity of 170 boys and 350 girls. We do promise to provide you a stress free
environment, an efficient guidance in a friendly manner and homely environment that makes one
feel at home while studying but it comes with a rider that you will show highest standards of
honesty, integrity and sincerity.
Wishing you the best of stay in PUSSGRC, Hoshiarpur.

(Dr. H. S. Bains)
Director

1

<!-- page 2 -->

HOSTELS ON THE CAMPUS
A hostel is a home away from home. Aware of the special needs and requirements of students,
who come from far-flung places to this centre of learning, the Panjab University Swami Sarvanand Giri
Regional Centre, Bajwara (Hoshiarpur) tries to provide them a safe, secure and affordable accommodation.
The University Hostels take pains to give its students a neat and clean environment and a comfortable
place to live in. There are Wardens and attendants on duty round the clock. Each hostel has a dining hall
and canteen, Wi-Fi facility several desert and water coolers, a visitors' lounge. The mess provides a
balanced diet at reasonable rates. The Common Room s fairly well equipped with current magazines,
journals and newspapers. There is provision for indoor games, a colour TV and music system.
Architecturally, the hostels are aesthetically laid out with plenty of open space and a lot of greenery. The
rooms are comfortable, fitted with fan, lights and hard furniture. Each wing of the hostel has several
verandahs and balconies.
Comforts are important but they are not enough. Man is a social animal and needs to interact with others.
The resident students re encouraged to participate in cultural and social activities. Colorful evenings of
song and dance are not unusual on the campus. Talent shows, dramatics and literary events are organized
from time to time. The inmates of a hostel are encouraged to live in harmony, like one big family, lending
each other a helping hand when required, mutually cooperating to make hostel life a rich and fruitful
experience.
There is no doubt that during these formative years in the hostel, life-long bonds are created and friendships
cemented. This is a time, which will stand out in the memory as a golden period. University experience is an
important milestone in an individual's life, the stepping-stone to an adult life of responsibility and care.
The hostels of Panjab University Swami Sarvanand Giri Regional Centre, Bajwara (Hoshiarpur) try to
provide an ideal atmosphere for a healthy, all round development of personality and a launching pad for a
glorious career ahead.
Living i n a hostel presupposes high degree of integrity, consciousness, cooperation, tolerance and hard
work for a bright future and good image of our institution.

2

<!-- page 3 -->

RULES FOR THE RESIDENT STUDENTS
(Effective from the Ist day of opening of the University after the summer
vacation)

General Rules
Admission
1.

All rights of admission to the University hostels are reserved with the Dean Student Welfare/
Director/Student Welfare Incharge Panjab University Swami Sarvanand Giri Regional Centre,
Bajwara , Hoshiarpur. No student can claim admission as a right.

2.

ORDERS/DECISIONSNOTIFIEDFROMTIMETOTIME, BYTHE DEANSTUDENTWELFARE/
DIRECTOR, PANJAB UNIVERSITY SWAMI SARVANAND GIRI REGIONAL CENTRE
(PUSSGRC), BAJWARA(HOSHIARPUR)/WARDEN, WILLBE BINDINGONTHE RESIDENTS.
Admission to the students in the University hostels will be made on the recommendation of the
Director, Panjab University Swami Sarvanand Giri Regional Centre, Bajwara (Hoshiarpur).The
students are required to submit to the department concerned the forms for admission to the
hostel within 3 days from the date of admission in the Department, for allocation of hostel
accommodation, after when his/her seat in the hostel shall stand forfeited and will be allotted to
the next student in the waiting list. The allocation of seats will be strictly on merit basis as per the
quota of seats allocated to each department of PUSSGRC.
Admission shall be sought afresh in the beginning of every academic session. A student may be
refused admission if his conduct during his/her earlier stay in any of the hostels was not satisfactory
or he/she was a defaulter.
Any student alleged to be involved in any misconduct/unlawful act/illegal activity will be
liable to be suspended from the University and on proving the commission of misconduct the
student shall be liable to be expelled from the University. The student aggrieved from the
decision of the University shall be entitled to appeal to a Standing Committee to be constituted
for the purpose by the Vice- Chancellor, of which a retired High Court Judge shall be the
Chairman.
Once a student has indulged himself in the misconduct in any manner, whatsoever, on the
University Campus and action taken against him, he shall not be entitled to admission in any
Department of the University. The Head of the Department shall ensure before granting admission
and shall give a certificate on the admission form to that effect.
Day Scholars and employees are not eligible for admission to the hostels.

3.

4.

5.

6.

7.
8.

An incorrect statement/address filled by the student in the hostel admission form would result in
immediate cancellation of admission and confiscation of securities.
9. (a) In case student has failed or not appeared in examination in the last academic session, he/she will
not be eligible for the hostel accommodation in the next year.
(b) An undergraduate student who is not promoted to the next class will not be eligible for hostel
accommodation.
(c) Students securing less than 50% marks will be given hostel accommodation, subject to its
availability.
10.
A person who is in employment, in profession or in any other whole-time occupation other than
in status for the course for which he has sought admission in the Panjab University Swami
Sarvanand Giri Regional Centre, Bajwara (Hoshiarpur) shall not be entitled for hostel
accommodation.
3

<!-- page 4 -->

11.

12.

Only a bonafide student will be permitted t o avail hostel facility and for that purpose the Warden
concerned will send quarterly list of the residents for verification by the Director, Panjab University
Swami Sarvanand Giri Regional Centre, Hoshiarpur.
The hostels (including messes/canteen and common room) shall remain closed during the summer
vacation for a period as specified by the D.S.W. The residents will vacate the hostels room within
three days of termination of their examination in case the room is still not vacated, it will be locked
by the hostel authorities till the possession of the rooms is hand over/ taken over and a minimum
fine of Rs. 1000/- shall be imposed in addition to payment of daily charges for stay without
permission from the Warden.

13 (a) Foreign students studying in Panjab University Swami Sarvanand Giri Regional Centre,
Bajwara (Hoshiarpur) and who are not in the final year may be allowed to stay in the hostel
during the summer vacation on continuation charges. Final Year foreign students may be
permitted to stay on payment of daily charges on the recommendation of Dean Foreign
Students.
(b) The residents of ongoing classes who are to undertake summer training/summer placements as a
part of their course requirement during the summer vacation can stay in the hostel on normal
room rent on production of a certificate to that effect from the Director, Panjab University Swami
Sarvanand Giri Regional Centre, Bajwara (Hoshiarpur). However, they will be required to seek
admission to the hostel afresh on the reopening after summer vacation as per the normal practice.
14.
15.
16.

17.

Residents shall see the Warden in the office during the fixed hours only. In case of emergency, the
Chowkidar/attendant on duty should be sent to the Warden's residence.
All bonafide students will be considered for Hostel accommodation only for the duration of their
respective courses of study.
LATE ADMISSION TO THE HOSTEL SHALL BE WITH THE PRIOR PERMISSION OF
THE DSW /SWI. LATE ADMISSION MEANS ANY ADMISSION AFTER THE LAST
DATE OF ADMISSION IN THE UNIVERSITY AS SPECIFIED BY THE UNIVERSITY
FROM TIME TO TIME.
For Ph.D. student's admission rules of P.U. Campus will be followed. All M.Phil/Ph.D students
seeking hostel accommodation shall be provided on sharing basis.

Responsibilities
18.
Living in a hostel pre -supposes a high degree of integrity and consciousness as a member of a
community. It entails a moral responsibility upon a resident to :
(i) see that no damage is done to the hostel property.
(ii) make every effort for peaceful co-existence maintaining the decorum.

19.

20.

(iii) observe all hostel rules meticulously in letter and spirit.
Any violation of rules and directions will be subject to strict disciplinary action, which in extreme
cases may lead to expulsion(s), forfeiture of the securities of such residents and his/her right to
future admission. All residents of hostels, in whatever capacity, they may be staying in the hostel
shall be bound to observe hostel rules and shall be liable to fine or other disciplinary action for
any violation of hostel rules similar to that of regular student residents.
Residents should be properly dressed while going to common room, dining hall or hostel office,
failing which it will be considered an offence and a fine may be imposed as decided by the
Warden.
Residents should not keep cash, jewellery, or other valuables in their rooms. The responsibility
for the safety of their belongingsincluding MOBILE SETS/DESKTOP/LAPTOP/AUDIO SYSTEM
will be entirely that of the residents. Residents are advised to take an insurance policy against
theft and fire. Use of strong and reliable lock is recommended.
4

<!-- page 5 -->

21.

Deadlock, interlock is not permitted. Any resident whose room is fitted with interlock shall be
fined Rs.1000/- and damages shall be recovered from the resident.
22.
If an outsider is found illegally living in the room of a resident, the resident shall be liable to (a)
expulsion from the hostel (b) forfeiture of securities (c) a fine of Rs. 1000/- (d) daily charges from
the date of illegal occupation of the room to be determined by the Warden (e) be debarred for
seeking admission in any of the University hostels and this will be communicated to his/her
parents/guardian.
23.
In case of non-payment of dues in time or violation of any hostel rule by a resident, the Warden
may get his/her room locked or opened for possession without any liability whatsoever. The
belongings shall be transferred to the store. If the dues are not cleared within 3 months of the
taking of possession of the room, the belongings may be auctioned and the proceeds adjusted
against the payment of the hostel.
24.
Every resident shall be responsible for the safety of furniture/other articles given to him/her.
Furniture is neither to be removed from one room to another nor be carelessly kept outside the
room to be exposed damaged. Anybody indulging in this practice will be liable to a disciplinary
action (including fine of minimum Rs 200/- per article). Replacement of a cot/chair/table etc shall
be done on payment of Rs. 200/- and a repair of almirah lock, bed box channel etc. during the
session will be done only on payment of Rs. 100/-.
25. (a) No vehicle without stickers, issued by the Warden should be permitted to be parked in the
hostels.
(b) The residents shall park their cycles/motor vehicles in the parking area of hostel on payment of
the prescribed parking fees. Defaulters will be fined a minimum amount of Rs. 500/- per default in
addition to normal charges. Four wheelers vehicles are not allowed in the Hostels.
(c) Registration number of cars and jeeps of the residents and of their guests must be entered in the
register with the Chowkidar of the hostel failing which a fine would be imposed.
26.
THE HOSTELWILL NOT BE RESPONSIBLE FOR ANY THEFT, DAMAGE AND LOSS OF A
CYCLE/SCOOTER/MOTOR-CYCLE/CAR/MOBILE SET /LAPTOP/DESKTOP/AUDIOSYSTEM.
THESE WILL BE POSSESSED BY THE RESIDENTS AT THEIR OWN RISK AND
RESPONSIBILITY. THE RESIDENTSAREADVISED TO GETTHEIRVECHICLES INSURED
AGAINST LOSS, THEFTANDFIRE.
27.
AS PER SUPREME COURT RULING SMOKING AT PUBLIC PLACES IS A PUNISHABLE
OFFENCE. Smoking is strictly prohibited in the hostels including Mess Canteen Areas. Defaulters
will be fined Rs.500/- per offence.
28.
In order to curb the drug menace in the hostels, those found indulging in taking intoxicants,
drugs and any such banned materials shall be expelled straightway from the hostel. They shall
not be given admission t o hostel in future.
29.
THE TELEPHONE I S MEANT FOR OFFICE USE ONLY. In case of emergencythe residents may
use the phone (on prescribed charges) after making proper entries in the register meant for the
purpose. Any resident misusing the telephone shall be fined upto Rs. 100/-.
30.
Acts of indiscipline, misbehavior, gambling, and use of intoxicants in the hostel premises including
rooms shall be severely dealt with. Aresident guilty of any of these shall be liable to expulsion or
a minimum fine of Rs. 500/- or both. Any resident found in possession of weapon shall be liable
to minimum fine of Rs. 2000/- and/or expulsion and the matter shall be reported to the police.
Further the Warden(s) may send the case of the residents who commits such an act for disciplinary
action to the Director, Panjab University S.S.G Regional Centre, Bajwara, and Hoshairpur.
NOTE: ALLROOMS(INCLUDINGALMIRAHSANDBELONGINGS)ARE OPENTOINSPECTION BY
THE WARDEN(S) AT ANYTIME O FTHE DAY.

5

<!-- page 6 -->

31.

Any student opening a room by breaking the hostel lock or seal or window-panes etc. shall be
liable to a minimum fine of Rs. 500/-. In case this kind of conduct is repeated, student (s) will be
liable for expulsion from the hostel and this will treated as a criminal offence.
32.
No roll number for any examination will be issued to the resident student unless he/she produces
a "No Objection Certificate "from his/her respective Hostel. The "No objection Certificate "is to
be procured prior to every University examination.
33.
Before leaving the hostel, every resident shall obtain clearance from the Warden and personally
hand over the charge of the room and hostel property to the Chowkidar on duty. The resident will
be fully responsible for any damage/loss of property. Repair charges for any damage to the
furniture will have to be paid by the resident along with a minimum penalty of Rs. 500/- for not
handing over the charge.
Committees
34.
For the proper democratic functioning of the hostels, several committees such as, Common Room
Committee, Mess Committee, Canteen Committee etc., will be formed in each hostel by 31st
August of the year. The committees will work closely in full cooperation and coordination with
the Warden to enhance the image of each hostel. These committees will also make new suggestions
to the administration for further improvement in the hostels and ensure the proper discipline and
decorum. Every hostel will have block prefects (one from each block of hostel) who will be
entrusted with the responsibility of ensuring cleanliness and up-keeping/maintenance of
infrastructure of the respective block.
Allotment
35. (a) Rooms will be allotted by the Warden according to the plan prepared by the SWI, Warden(s).
(b) All students will be provided hostel accommodation on sharing basis only.
(c) A resident cannot shift from his/her allotted room to another room within the hostel without the
permission of Warden, defaulters will be fined minimum Rs. 500/-.
(d) Resident shall keep the hostel identity card duly attested by Warden with them and will present
these on demands by authorities. The card should be carefully preserved as no duplicate card will
normally be issued. In case of loss it will be issued on payment of Rs 50/- Lamination of the hostel
Identity Card shall be done by the students to avoid misuse. The residents leaving the hostel at
the end of academic year or in the midsession must return the card to the office of Warden, failing
which the residents will have to pay Rs. 50/- before securities are refunded.
(e) Any person who is a defaulter of hostel dues shall not be eligible for hostel admission till he or
she produces no dues certificate from the concerned hostel warden.
Visitors and Guests
36. (a) Male visitors shall see residents of the Girls' hostel, if need be, only in the Visitors' Room during
specified hours.
(b) Female visitors shall not visit male residents in their rooms; they can visit them, if need be, in the
Guest Room upto 8 p.m.
(c) A register will be maintained at the reception of each hostel to regulate outsiders entry.
(d) As a rule guest and day scholars are not permitted to stay in the hostel. However charges for
one guest accommodated by the residents in his/her room for a maximum period of three days
in a month on guest charges i.e. Rs. 50/- per day. In case the guest is stayed in guest room, the
charges shall be Rs. 150/- per day.
(e) Any resident having a guest without prior permission of the Warden and proper
entry in guest register will be liable to minimum fine of Rs. 400/- and disciplinary
a c t i o n , in addition to the guest charges to be levied for duration of stay of the guest.

6

<!-- page 7 -->

(f) If any outsider is found staying without the prior permission o f the Warden/SWI, the Warden
concerned shall also be accountable for it.
(g) Any University Teacher may be permitted to stay in the hostel temporarily on payment of daily
charges by the DSW /SWI after due recommendation from the Director, Panjab University Swami
Sarvanand Giri Regional Centre, Bajwara (Hoshiarpur).
(h) In case of temporary allotment daily charges will be levied and refundable security equal to
amount of charge from regular students must be deposited with the Office
Attendanceand Leave
37. (a) For Boys Hostel: General
(i) Gates of Boys hostel will be closed at 10.30 p.m. and opened at 5.30 a.m. The resident will wait (if
the gate is closed) for the Chowkidar to come back from his round of the building.
(ii) All residents entering the hostel after 10.30 p.m. are to make due entries in the register maintained
(for late arrivals) with the Chowkidar of the hostel.
(iii) A resident shall, under all circumstances, inform the Warden about his/her absence from the
hostel. He/she shall sign the register maintained for this purpose.
(iv) Anystudent found absent from the hostel for more than two weeks without prior written permission
from Warden is liable to be punished, his/her hostel admission is cancelled along with a minimum
fine of Rs. 1000/(b) For Girls' Hostel:
Regional Campus Main Gate timings:
i)
ii)

Entry at the main gate is allowed till 7:00 pm.
Entryafter 7pm to 8:30 pm: Allowed only with the permission of Warden Girls Hostel PUSSGRC
Hoshiarpur.
iii) Entry after 8.30 pm to 9:30 pm: Allowed only with the permission of the Director, PUSSGRC
Hoshiarpur.
Girls Hostel Gate timings:
i) The residents can go outside the hostel (within campus only) upto 12:00 midnight with an
entry in the mobility register. However, the residents will be allowed to go outside hostel
(within campus) after 12:00 midnight only with the prior permission of the office.
ii) Home outing should not be less than 24 hours.
iii) Identity Card of the Hostel is mandatory for the residents while entering details in the mobility
register for late night exit/entry.
iv) For moment outside the hostel after 10.00 pm, the entry in the mobility register is must for all the
residents. Id resident do not make entry in mobility register, written warnings will be issued by the
concerned Warden. More than two defaults will lead to expulsion from hostels.
v) Attendance is must between 9.00 p.m. to 10.00 p.m. If a resident does not come for attendance,
written warnings will be issued by the concerned Warden for two times, after which defaulter will
be expelled from hostel.
vi) Guest entry must be made before 10.00 pm. No guest will be allowed to enter in the hostels after
10.00 p.m. Defaulters will have to pay fine as per rule.
vii) Entry (home and market outing) at Girls Hostel Main Gate is mandatory. Fine of Rs. 50/- for each
default.
viii) The following fines will be levied:

7

<!-- page 8 -->

1.

Late entries allowed in a month upto 07:30p.m.: 03
(Residents wi l l be required to intimate in writing to the warden concerned a b o u t the place
and people visited by them during the said time. This is to be complied with strictly and the
failure shall attract stringent action against the erring/defaulting students)

2.
3.
4.

Late entry Beyond 03 upto maximum 05 in a month:
Rs. 200/- per late entry.
Beyond 05 late entries in a month:
Rs. 250/- per late entry.
If persisted, it would attract disciplinary action and even expulsion from the hostel as per PU
norms.

General:
i) In view of routine hostel maintenance to be carried out, it is mandatory for the residents to vacate
hostel rooms during the summer vacations.
ii) Residents returning from the home must report themselves before the roll call time. Violators will
be fined as decided by the warden.
iii) Girl students taking admission in the hostel for the first time must be accompanied by their
parents.
iv) Resident must enter a valid contact number and address in the home going register before
proceeding on leave.
(vii) As per the orders of the Supreme Court of India, Ragging is strictly banned in educational
institutions. The students found indulged in ragging shall be expelled from the institute and the
hostel.
Food
38. (a) Ordinary residents will take food in the Hostel. The residents are required to take at least 15 diets
per month failing which a minimum charge of 15 diets is to be paid by them(10 diets is to be paid
to contractor and 5 diet towards the mess development fund). In the Messes where they are
residing. In exception cases the D.S.W/Warden may give permission for lodging only. Such
residents shall pay two diet charges per months (one each towards mess and canteen). As
amenity charges in addition to the usual fees.
(b) Each resident will contribute Rs 150/- per month as service charges in the mess and canteen
respectively. (* subject to introduction of labour law).
(c) Hostels have facilities for lunch and dinner as well as canteen services. A resident shall have
meals in the hostel mess/canteen only. It is mandatory for every resident to open their messes and
canteen accounts in respectively hostel at the time of taking hostel admission, defaulters will be
fined.
(d) Residents will not enter the cooking area.
(e) All complaints requiring immediate action of the Warden should be made in writing through a
member of the Mess/Canteen Committee.
(f) Each resident will contribute charges of two ordinary diets per month (along with the mess bill)
one towards food subsidy a n d one towards mes s development fund.
(g) Guests, with the permission of the Warden, may be served meals on a surcharge of Rs. 5 per diet.
Fifty per cent of the surcharge shall be deposited in the Mess Account and the remaining fifty per
cent shall be paid to the mess contractor. No resident is allowed to have more than 40 guest diets
in a month.
(h) It will be obligatory on the part of the residents to inform the contractors/Cooperative Mess
Secretary/Wardens beforehand if they want to miss a meal so as to avoid the wastage and loss.
A register for this purpose will be available with the contractor where in the residents should
enter the information about missing the meals. A resident who is absent without leave from the
warden may miss meals for not more than seven days in a month.

8

<!-- page 9 -->

(i)

Cooking in the rooms is strictly prohibited and defaulters will be fined a minimum of Rs. 250/each time for a default, in addition to the fine for use of a heater, if any, and its confiscation.
(j) No meals will be served in the rooms except in cases of illness or any other justified reason and
that too with the permission of the Warden. Residents as well as contractors will be fined
Rs. 100/- for violating this rule each time. Meals should be taken only in Dining Hall.
(k) Complaints, if any, against the conduct of the contractors/servants may be made by the
residents to the Warden in writing. No complaint about mess/canteen etc. shall be
entertained if the complainant himself/herself is a defaulter.
(l) A resident of the hostel cannot take his/her meals as a guest of another resident of the same
hostel.
(m) Messes, Canteens and Common Rooms will remain closed after 2.00 p.m. on the following days:
Republic Day
Holi
Independence Day
Inaugural Function Day
Dussehra
Gandhi Jayanti
Diwali
Guru Nanak Dev's Birthday
Christmas
Hostel Annual Day
Food Subsidy/Scholarships
39. (a) At the beginning of the session, applications will be invited from the needy and really deserving
resident students for the award of food subsidy.
(b) The concession will be discontinued if and when the recipient violates any of the hostel rules.
(c) The recipients of the concession will be bound to do some duty/work in the hostel as may be
assigned by the Warden.
(d) A resident who is defaulter or have record of misconduct in the university hostel is not eligible for
any kind of food subsidy/ financial assistance / scholarship.
Electricity
40. (a) The residents are not allowed to use more than one LED bulb/tube (upto 36 W). They must
switch off the light/fan or any other electronic appliance while going out of the room. The
defaulters will be fined a minimum of Rs. 100/- for each offence.
(b) Residents are not permitted to use or keep any kind of electrical/electronic appliances such as
air conditioners, induction cook tops, electric heaters, electric rods and table fans, TV etc in their
rooms. Defaulters will be fined of minimum of Rs. 1000- for each offence.
(c) Room cooler and Personal Computer may be used by the residents with the permission of
Warden on payment of Rs. 300/- p.m. & 75/- p.m, respectively for each component.
(d) Residents will not tamper with or damage the electrical and sanitary installations. The cost of
repairs/replacement due to any damage, done to them, will be realized from the residents in
addition to fine which may be imposed b y the Warden.
9

<!-- page 10 -->

41. (a) Hostel fees will be charged from all the residents semester wise in the following installments:
(i) First Semester
July to December
a) For new residents: On admission
b) For Regular/Enrolled residents: till 31st July
(ii) Second Semester (in January)
January to June
a) For all residents: upto 15th January
(b) Residents getting admission to hostel at any time during the month will be charged full fee for the
month, however, they will be charged 15 days if they leave after the termination of their University
annual examination before the middle of the month. All research scholars/ fellows getting a
fellowship will be treated at par with other students.
(c) Securities (Hostel Mess and Canteen) will be refunded to a resident only after he/she has cleared
all the dues and properly handed over the possession of the room. Securities will not be adjusted
against the bills. Application for refund of securities along with a certificate from the Chairperson
regarding the date of leaving the Department/last date of examination and the hostel identity card
will be submitted three days before the intended date of leaving the hostel (when his/her mess/
canteen accounts will be closed and he/she will eat on cash payment). If need be the Security
Cheques can be sent by post by the Hostel Office after deducting postal and service charges.
(d) The students who take admission i n the hostel but fail to take the possession of the room, the
room rent will be deducted upto the period he informs to the Warden in writing. He will be given
refundable securities after deducting the charges pertaining to the minimum diet and Mess/
Canteen Charges etc. as per rules.
(e) THESECURITIESWILLSTANDLAPSEDAFTERONEYEAR OFLEAVINGTHE HOSTEL.
Hostel, Mess and Canteen Dues and Fines
42.
Resolution of the Senate: All residents of the University Hostel shall be required to clear all
dues including the Hostel, mess and canteen charges on the 15th of every month, failing
which they shall be liable to disciplinary action. The Residents of the University Hostels shall
not be granted fee concession and/or paid monthly scholarship unless they clear their dues by
the date indicated above. Normally the fees will be collected without fine upto 15th of every
month. However, the students will have to pay Rs. 4/- per day for each bill in case of delay in
paying the mess/canteen charges and hostel charges after 15th. However, the total amount of fine
will not exceed the 100% of principal amount due to each bill. In case, dues are not cleared within
15 days from the last due date, the students shall be liable to pay fine of Rs. 6/- per day per bill till
the bills are paid.
For Online Hostel and Offline Mess Semester Charges: After due date of 1st and 2nd semester:
New/Regular/Enrolled students will have to pay fine of Rs. 4/- per day for 15 days. Further
students shall be liable to pay fine of Rs. 6/- per day from last due date.
43.
44.

45.

46.

IF THE LAST DATE OF PAYMENT IS A HOLIDAY, THEN THE FEE/CHARGES WILL BE
ACCEPTEDWITHOUT FINE ONTHE NEXTWORKING DAY.
If the total amount of mess and canteen dues from a resident exceeds the security deposits to
mess and canteen on the 20th of the month, he/she will not be eligible for mess and canteen
services after 21st of the month.
Admission of a resident who fails to pay the dues for two consecutive months shall stand
cancelled and possession of the room shall be taken by the Warden and belongings removed to
the store without any liability.
All residents are required to clear their hostel, mess, canteen and other dues and obtain a no-dues
certificate before they take their examination roll numbers and again all their dues must be cleared
10

<!-- page 11 -->

before they vacate the hostel, failing which their names will be forwarded to the Controller of
Examinations/Director, Panjab University Swami Sarvanand Giri Regional Centre, Bajwara
(Hoshiarpur) concerned for withholding the declaration of results/award of degree. Other
disciplinary action, including forfeiture o f their securities, m a y also be taken.
47.
Residents are required to pay hostel charges as printed in the Handbook of Rules.
Fees and charges for hostel residents in Panjab University Swami Sarvanand Giri Regional
Centre, Bajwara, Hoshiarpur are:
A. HOSTELFUNDCHARGES
SEMESTER-WISE
Rent (Not to be charged from SC/ST students)
Rs. 1200/- Per Semester
Water Charges
Rs. 360/- Per Semester
(If the bill is higher it will be distributed equally amongst the residents of
hostels)
Electricity Charges
Rs. 3000/- Per Semester
(If the bill is higher it will be distributed equally amongst the residents of
hostels)
Development Fund
Rs. 850/- Per Semester
Routine Hostel Maintenance Charges
Rs. 1300/- Per Semester
TOTAL
Rs. 6710/-Per Semester
MESSFUNDCHARGES
SEMESTER-WISE
Celebrations Funds
Foods Subsidy
Mess Canteen Servant Welfare Charges
Poor Student Welfare Fund (Hostel Residents)
TOTAL
GRANDTOTAL

Rs. 325/- Per Semester
Rs. 360/- Per Semester
Rs. 100/- Per Semester
Rs. 150/- Per Semester
Rs. 935/-Per Semester
Rs. 7645/-Per Semester

Note : : Rooms without washrooms: The Research Scholars getting fellowships should pay the hostel
charges either equivalent to the HRA claimed by them or as per approved rates of the said
hostel, whichever is higher.
B.
OPTIONALCHARGES
1:

Scooter/Motorcycle parking charges

Rs. 70 p.m.

Hostel residents are not to allowed to bring/keep vehicle i.e four wheelers in PUSSGRC
Hostels.
2: Additional Facility Charges
Desert cooler
Desktop
Internet Charges
For use of Electrical Kettle Charges
For use of Electrical Iron
For use of Hair Ironing/Hair Dryer Device

Rs. 300 p.m.
Rs. 75 p.m
Rs. 75 p.m
Rs. 75 p.m.
Rs. 75 p.m.
Rs. 50 p.m. each
11

<!-- page 12 -->

C.

D.

REFUNDABLESECURITIES
Hostel
Rs. 1000 (Refundable)
Mess/Canteen
Rs. 3000 (-do-)
(Note:- If the Mess/Canteen Bill of a resident exceed Rs. 2500 monthly, then the resident will have
to pay Rs. 4000/- as refundable security.)
FEES,FUNDSANDFINES(MINIMUM)FORRESIDENTSTUDENTSAREASPERDETAILED
BELOW: Price of Hand Book of Rules
Rs. 100/Daily Charges for foreign students staying during
Rs. 100/- per day plus other
vacations/temporary allotment/ex-students stay/outstation
applicable charges.
students coming for training/overstay of final year foreign
students
Fine for smoking
Rs. 500/Fine for possession of any weapon
Rs. 2000/Fine for any vehicle found parked inside the hostel building. Rs. 500/- per default
Guest charges maximum for 3 days (in resident's room only)
Rs. 50/- per day
Advance for being a member of Co-operative Mess
to be adjusted against last bill.
Surcharge on Guest diets
Group of students staying in hostel from outstation
Charges for enrolled research scholars not confirming
registration within two years pay

Rs. 1300/-

Rs. 5/- per diet
Rs. 50/- per head per night
Rs. 50 per day (1 to 3 months)
and Rs. 80 per day
(beyond 3 months)
Cloak room charges
Rs. 50/- per day for group of
4 students
For reissuing a time barred cheque to the residents.
Rs. 100/Note: 1. Any guest staying more than 15 days in the hostel will have to pay electricity charges in addition
to daily charges.
2. Twenty five per cent (25%) of Daily Charges will go in Development Fund of the Hostel.
Important Note:E.
The hostel rent will be charged as shown against each category:
Category of Students
Type of rent to be charged
1. Regular Campus Students
Normal Rate
2. (i) Registered/Enrolled Research Scholar: not
Normal Rate
entitled for House rent
(ii) Registered/Enrolled Research Scholars :
to pay the amount
Entitled for House rent
as per entitlement
F.
General Rules for maximum total period of stay in PUSSGRC Hostel/s:
The total maximum period of stay for any student in PUSSGRC hostel/s from the date of admission/
enrolment to the Department shall be as under:
1. LL.B.
3 Years
2. B.A. LL.B.(H.S.)
5 years

12

<!-- page 13 -->

3. B.E.
4 Years
4. MCA
2 Years
5. LLM
1 Year
Any further extension under extra ordinary circumstance will be maximum for one month at
special charges.
6. Ph.D. - Upto Four Years - (8 Semesters Charges): Normal Rent
Next 6 months* (one semester) - Normal Rent (JRF/SRF & Non JRF)
Next 6 months*(one semester) - Normal Rent (JRF/SRF) & Continuation Charges for Non JRF.
(*after 4 years recommendations of supervisor and approval of grant of extension in the Ph.D.
programme by the competent body/authority will be mandatory)
Ph.D students: More than 5 years stay will be considered as over-stay and will be charged @ Rs.
100 per day.
Eligible Blind Students for Degree and Post-Graduate Degree Courses shall be provided free
accommodation in the University Hostels, but they will have to pay mess/canteen charges and all
refundable securities.
For regular campus students, semester will mean from 1st July to 31st December, and 1st January
to 30th June & for Research Scholars, Semester will start from date of enrolment.
Research Scholars will be given provisional accommodation from date of approval by the
Department. However, they are required to submit enrolment letter within 6 months.
Each student is required to pay for full semester and part-payment is not allowed.
In case of delay in fellowship for Research Scholars, their fine will be waived-off to the extent of
100% by the DSW.

G.

H.
I.
J.
K.

IMPORTANT NOTES
Before you submit the form for admission to the hostel, make sure that:
1.
2.
3.
4.
5.
6.
7.
8.
9.

All columns have been filled with correct information.
You have 4 copies of your recent passport size photograph duly attested by the Chairperson of
your Department.
You have adequate funds to pay the dues.
You have stamped envelope bearing correct and complete address of your parents/guardian.
You have an attested copy of the marks obtained in the last University examination from your
Head of the Department/Institution (attestation c a n be got done on the Admission form).
You have read all the rules and regulations for the Hostel Residents.
Incomplete Form shall not be entertained. Entries in the form shall be verified. Wrong entries shall
lead to cancellation of Hostel Admission.
You have attached a copy of your residence proof.
Admission to the students in the University hostels will be made on the recommendation of the
Director, Panjab University Swami Sarvanand Giri Regional Centre, Bajwara (Hoshiarpur). The
students are required to submit to the department concerned the forms for admission to the
hostel at the time of admission for allocation of seats strictly on merit basis as per the quota of
seats allocated to them.
P.U.P (21)–250+4 Press./29-03-2022

13
