---
doc_id: "51fa608bcdbdce1f"
source_url: "https://gandhianstudies.puchd.ac.in/includes/noticeboard/2021/20211006121445-guidelinesforpms.pdf?2026"
ministry: "Department of Gandhian and Peace Studies, Panjab University, Chandigarh"
title: "Guidelines for online Post Matric Scholarship for Punjab 2021-22"
date: ""
pages: 1
method: "tesseract:pan+hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "3c3b3f21da54bdc2"
---

<!-- page 1 -->

डॉयरेक्टोरेट ੦." ar
सामाजिक न्याय, आधिकारिता एवं अल्प संख्यक विभाग #!|
एससीओ 7, फेज-1, एसएएस नगर
भारत सरकार द्वारा 209 6301੦ 8000|191#$ 10 118 5000॥709$ 0610709176 to Scheduled Castes for Stud-
185 ॥.॥1019 (2020-21 10 2025-26) तहत मार्च 2021 द्वारा जारी हिदायतों अनुसार डॉ. अंबेदकर पोर्टल पर +18869#07 | 4
(७४0 हेतु ऑनलाईन अप्लाई करने संबंधी
|
Post Matric Scholarships to the students belonging to Scheduled Castes for Studies in India |
(2020-21 (0 2025-26) अधीन पंजाब राज्य में बोनाफाईड अनुसूचित जाति के विद्यार्थी जिनके माता पिता / सरपरस्त की सालाना |
आय 2.50 लाख रुपये से कम हो, 10वीं के विभिन्न कोर्सो के लिए पंजाब एवं पंजाब के बाहर स्थित संस्थाओं में उच्च शिक्षा लेने के लिए |
वजीफे के योग्य हैं ।
» योग्य एससी विद्यार्थीयों से 71983।1 09/५ हेतु ऑनलाईन आवेदन प्राप्त करने के लिए कल्याण विभाग द्वारा वेबसाइट ४५४५५.
scholarships.punjab.gov.in % Staex siaea स्कॉलरशिप पोर्टल 31 अगस्त 2021 से चालू होंगी, जिसके अनुसार शैडयूल
का विवरण निम्न अनुसार है ।
ACTIVITY SCHEDULE 2021-22
1. |The Opening date for submission of Freeship Card by the Students 31.08.2021
Fresh & Renewal
2. |The last date for submission of Freeship Card by the Students (Fresh & | 30.09.2021 2
Renewal). =
3. |The last date for Tehsil Social Justice & Empowerment officers to verify | 08.10.2021
nd issue freeship card online
rs विधि :- |
« विद्यार्थियों द्वारा (1889110 010 हेतु अप्लाई करने ਯੇ पहले पोर्टल पर रजिस्टर्डर करने के लिए उसका आधार नं. होना जरुरी है ।
गलत आधार नं. पर विद्यार्थी पोर्टल पर रजिस्टर्ड नहीं कर सकता । ।
» योग्य एससी विद्यार्थी अपना वेरीफाईड &198७७॥|० 0७1४ पोर्टल पर डाउनलोड करने उपरांत जिस संस्थान में प्रवेश लेना है या पढ़ते |
हैं, में जमा करवाएंगें ।
| » संस्थाएं यह यकीनी बनाएंगी की जो विद्यार्थी ः18881॥17 091 कार्ड द्वारा दाखिला लेंगे, उन्हें बिना कोई फीस लिए प्रवेश देंगी एवं जिस
दिन विद्यार्थी दाखिला लेता है उसी समय पोर्टल पर स्कॉलरशिप हेतु विद्यार्थी से अप्लाई करवाना यकीनी बनाएंगी ।
दस्तावज :-
« विद्यार्थी ਛੁਹ ਜਿ੪੪90॥ 2810 ऑनलाईन अप्लाई करते समय फोटो, जाति सर्टिफिकेट तहसील द्वारा जारी आय सर्टिफिकेट (केवल |
फ्रैश विद्यार्थियों हेतु ) एवं पिछली क्लास के डीएमसी / डिग्री सर्टिफिकेट अपलोड किए जाएंगे ।
« Income declaration of self employed parents/guardians should be in the form of a certificate
issued by the Revenue Officer not below the rank of Tehsildar. Employed parents/guardians
are required to obtain income certificate from their employer. Employed parents/guardians
। | should obtain consolidated certificate from Revenue Officer for any other additional source of
|} — income
संपर्क :-
« यदि किसी विद्यार्थी को ऑनलाईन आवेदन करने में परेशानी आती है तो विद्यार्थी संस्थान में बने फैलीटेशन सेंटर में संपर्क कर सकते है |
या अपनी तहसील से संबधिंत तहसील सामाजिक न्याय एवं अधिकारिता अधिकारी के कार्यालय में संपर्क कर सकते हैं ।
ਟੋਲੀ] जो संस्थाएं डॉ. अबेंडकर पोर्टल पर रजिस्टर्ड नहीं है उन्हें लागू कर्ता विभाग द्वारा पोर्टल पर रजिस्टर्ड करने, अपने कोर्स एवं
Wa RR HS RA हेतु पोर्टल संस्थाओं लागू कर्ता विभाग हेतु भी खोला गया है ।
हस्ता/-
| डॉयरेक्टर
| सामाजिक न्याय, अधिकारिता एवं अल्प संख्यक विभाग
7250 पंजाब चंडीगढ़ फोन न. 0172-2273272
