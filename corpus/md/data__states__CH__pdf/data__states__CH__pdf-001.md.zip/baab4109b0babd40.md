---
doc_id: "baab4109b0babd40"
source_url: "https://laws.puchd.ac.in/includes/noticeboard/2023/20230808114253-p.u.ph.d.guidelines-2023.pdf?2026"
ministry: "Department of Laws, Panjab University, Chandigarh"
title: "Ph.D. Guidelines 2023"
date: ""
pages: 30
method: "tesseract:pan+hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "33cbe0058303c91c"
---

<!-- page 1 -->

PANJAB UNIVERSITY, CHANDIGARH-160014 (India)
(Estted. Under the Panjab University Act VII of 1947 enacted by the Govt. of India)
=e To
1. Dean of University Instruction
The Deputy Registrar (General) 2. Director, R&DC
Panjab University 3. All the Chairpersons/Directors/
Dewan Anand Kumar Hall Honorary Directors/Coordinators of
Chandigarh-160014 University Teaching Departments,
P.U.R.C., Hoshiarpur/Muktsar/
Ludhiana and P.U. Rural Centre,
Kauni, Sri Muktsar Sahib.
4. C.O.E.
5. D.R. Colleges
6. D.R. (Secrecy)
7. A.R. Fee Checking
8. A.R.(R&S
No.ST. ५५3९५3- ५5५3 Date: ੦੧੦੬13੦੩3 6੬ 1&6&੨
Dear Sir/Madam,

This is to inform you that the Syndicate dated 25.03.2023 vide Para 29 and
vide orders of Vice Chancellor dated 01.06.2023, in anticipation approval of
Syndicate/Senate, has approved Panjab University Ph.D. Guidelines-2023 (which
are conformity with UGC Minimum Standards and Procedures for the award of
Ph.D. degree) Regulation 2022. These Guidelines will be effective from the date of
the issuance of the circular.

This may kindly be notified to all concerned.

Yours faithfully
ਗਿ (General)
© scanned with CKEN Scanner

<!-- page 2 -->

© scanned with OKEN Scanner

<!-- page 3 -->

Panjab University Ph.D, Guidelines, 2023 in accordance with the U.G.C.
Minimum Standards and Procedure for award of Ph.D. degree Regulations
2022 published on 7th November, 2022.

No. F. No. 1-3/2021(QIP). — In’ exercise of the powers conferred by

clauses (f) and (g) of sub-section (1) of section 26 ofthe University Grants

Commission Act, 1956 (3 of 1956), and in supersession of the UGC

(Minimum Standards and Procedure for Awards of M.Phil. /Ph.D. Degree)

Regulations, 2016 and its amendments. The following Regulations have

been made by Panjab University taking into consideration the U.G.C.

Minimum Standards and Procedure for the award of Ph.D. degree

Regulations 2022 published on 7th November, 2022, namely: -

1, Short title. Application and Commencement. -

1.1. These guidelines may be called Panjab University (Minimum
Standards and Procedure for Award of Ph.D. Degree) Regulations,
2022.

1.2, They shall apply to Departments/Centres of Panjab University
including all regional centres and all affiliated/ Constituent colleges
of Panjab University.

1.3. They shall come into force with immediate effect and shall
supersede all other existing Regulations at Panjab University to
award the degree of Ph.D.

2. Definitions.-

2.1. In these Regulations, unless the context otherwise requires,-

a) “Act” means the University Grants Commission Act, 1956 (3
of 1956);

b) “Adjunct Faculty” means a_ part-time or contingent
instructor, but not full-time faculty member hired to teach
by a Higher Educational Institution;

०) “Cumulative Grade Point Average (CGPA)” means a measure
of the overall cumulative performance of a student over all
semesters. The CGPA is the ratio of total credit points
secured by a student in various courses in all semesters and
the sum of the total credits of all courses in all semesters. It
is expressed up to two decimal places;

d) “Credit” means the number of hours of instruction required
per week over the duration of a semester. A’ four-credit
course in a semester means four one-hour lectures per week,
with each one-hour lecture counted as one credit;

<< >- # a — = ke - - ਅਕਲ — . ——— Se ੯ <ਲ 68 7 ਕਦ ਦੇ or eae "a lPage
| ੬ का न्‍
© scanned with CKEN Scanner

<!-- page 4 -->

| ਰ 6

e) “College/Approved research centre (in constituent and
affiliated college)" means an institution engaged in higher
education and/or research, either established by a_
University as its constituent unit or is affiliated with it;

f) “Commission” means the University Grants Commission
established under Section 4 of the UGC Act1956;

g) “Course” means one of the specified units which go to
comprise a programme of study;

h) “Course Work” means courses of study prescribed by the
School/Department/ Centre to be undertaken by a student
registered for the Ph.D. Degree;

i) “Degree” means a degree awarded by a Higher Educational
Institution in accordance with the provisions of section 22 (3)
of the Act;

3) “External examiner” means an academician/researcher with
published research work who is not part of the Higher

Educational Institution (or its affiliated College/Approved
| research centre) where the Ph.D, scholar has registered for
ਰ੍ the Ph.D. programme;

k) “Foreign Educational Institution” means-{i) an institution
duly established or incorporated in its home country and
offering educational programmes at the undergraduate,
postgraduate and higher levels in its home country and (ii)

which offers programme(s) of study leading to the award of a
i ਵਿ degree through conventional face-to-face mode, but
[ =" excluding distance, online, ODL mode;
; ਨਮ ਦੇ "< 1) “Grade Point” means a numerical weight allotted to each
a ਰ੍ letter grade on a 10-point scale; °
| NY कं; m) “Guide/Research Supervisor” means an _  academician/
\ AN researcher recognized by Higher Educational Institution to
\ ਰ੍ ਸਿ supervise the Ph.D. scholar for his/her research;
| ਰਹ 5... 2) “Higher Educational Institution? means a university or
N के institution specified under clause 2 of Regulation 1 of these
\ \ - Regulations;
% ੦) “Interdigciplinary Research” means research conducted by a
| ਮੇ Ph.D. scholar in two or more academic disciplines;
p) \. “Open and ‘Distance Learning Mode” shall have the same
हे फल as defined under the UGC (Open and Distance
a ੧੧੧ 4 ਲਿਜਾ रा `_2173॥€
i: VV ‘i
N
fy ; न
© scanned with OKEN Scanner

<!-- page 5 -->

4
Learning Programmes and Online Programmes) Regulations
2020;

q) “Online Mode” shall have the same meaning as defined
under the UGC (Open and Distance Learning Programmes
and Online Programmes) Regulations 2020;

r) “Plagiarism” means the practice of taking someone else’s
work or idea and passing them as one’s own;

s) “Programme” means a higher education programme pursued
for a degree specified by the Commission under sub-section
(3) of section 22 of the Act;

t) “Prospectus” means any document, whether in print or
otherwise, issued for providing fair and transparent
information relating to a Higher Educational Institution and
programmes, to the general public (including to those
seeking admission in such Higher Educational Institutions)
by the Higher Educational Institutions;

u) “Research Proposal” means a brief write-up giving an outline
of the proposed research work which the Ph.D. scholar shall
submit along with the application for registration for Ph.D.
programme;

v) “University” means a Higher Educational institution
established or incorporated by or under a Central Act, a
Provincial Act, or a State Act, and shall include any
institution for higher education deemed to be a University
under Section 3 of the Act.

w) “Nodal department” means parental department in Panjab
University

2.2. Words and expressions used and not defined in these Regulations
but defined in Act and not consistent with these Regulations shall
have the meanings assigned to them in that Act.

3. Eligibility criteria for admission to the Ph.D. Programme..-

The following are eligible to seek admission to the Ph.D. programme:

3.1 Candidates who have completed:

i. A 1-year/2-semester master’s degree programme after a 4-
year/8-semester bachelor’s degree programme or a 2-year /4-
Semester master’s degree programme after a 3-year
bachelor’s degree programme or qualifications declared

५2 (7 , 3|Page
© stanned with OKEN Scanner

<!-- page 6 -->

(
equivalent to the master’s degree by the corresponding
statutory regulatory body, with at least 55% marks in
aggregate or its equivalent grade in a point scale wherever
grading system is followed
OR equivalent qualification from a foreign educational
institution accredited by an assessment and accreditation
agency which is approved, recognized or authorized by an
authority, established or incorporated under a law in its
home country or any other statutory authority in that
country to assess, accredit or assure quality and standards
of the educational institution.

ii. A relaxation of 5% marks or its equivalent grade may be
allowed for those belonging to SC/ST/OBC (non-creamy
layer) / Differently-Abled, Economically Weaker Section (EWS)
and other categories of candidates as per the decision of the
Commission from time to time.

iii, Provided that a candidate seeking admission after a 4-
year/8-semester bachelor’s degree programme should have a
minimum of 75% marks in aggregate or its equivalent grade
on a point scale wherever the grading system is followed. A
relaxation of 5% marks or its equivalent grade may be
allowed for those belonging to SC/ST/OBC (non-creamy
layer) / Differently-Abled, Economically Weaker Section (EWS)
and other categories of candidates as per the decision of the
Commission from time to time.

3.2 Candidates who have completed the M.Phil. programme with at
least 55% marks in aggregate or its equivalent grade in a point
scale wherever grading system is followed or equivalent
qualification from a foreign educational institution accredited by
an assessment and accreditation agency which is approved,
recognized or authorized by an authority, established or
incorporated under a law in its home country or any other
statutory authority in that country to assess, accredit or assure
quality and standards of educational institutions, shall be eligible
for admission to the Ph.D. programme. A relaxation of 5% marks
or its equivalent grade may be allowed for those belonging to
SC/ST/OBC (non-creamy layer)/Differently-Abled, Economically
Weaker Section (EWS) and other categories of candidates as per
the decision of the University Grant Commission from time to time.

Ww 4|Page
© scanned with CKEN Scanner

<!-- page 7 -->

4. Duration of the Programme.-

4.1. Ph.D. Programme shall be for a minimum duration of three (3)
years, including course work, and a maximum duration of six (6)
years from the date of admission to the Ph.D. programme.

4.2. A candidate need not seek any extension for submission of thesis
upto 6 years from the date of registration. After 6 years, a
maximum of two years extension be granted while giving the
justification. Extension may be granted by the Dean of University
Instruction on the recommendation of the Chairperson and the
concerned Supervisor. A fee of Rs. 35,000/- per year shall be levied
from such candidates. It is clarified that however, this fee will not
be charged from the persons with disability (more than 40%
disability).

4.3. The women candidates and Persons with Disability (more than
40% disability) may be allowed a relaxation of two years for Ph.D.
in the maximum duration of eight years. However, they will be
charged a fee of Rs. 35,000/- per year for this extension (beyond 8
years).

4.4 The women candidates may be provided Maternity Leave/Child
Care Leave in the entire duration of Ph.D. for up to 240 days.
These 240 days shall be inclusive of the maximum stipulated
period as defined in clause (4.3).

4.5. If a candidate fails to submit the thesis in 8 years for men and 10
years for women and Persons with Disability (stipulated period) as
per the above-mentioned clauses (4.2 & 4.3); his/her registration
will automatically stand cancelled.

5. Procedure for admission. -

5.1. Panjab University shall admit Ph.D. scholars through Entrance
Test conducted at the level of the University.

3, However, exemption from entrance test will be given to those
who have already cleared any of the National Test for the
eligibility of lectureship like UGC/CSIR NET including JRF,
GATE, CEED, GPAT, ICMR, ICAR, or any other prestigious
test for National level scholarship/ fellowship conducted by
Govt. of India.

ii. Direct awardees of National/International fellowship for
pursuing Ph.D. and working regular teachers of Panjab
University are exempted from the entrance test.

(£-- bi” 5|Page

© stanned with OKEN Scanner

<!-- page 8 -->

iii. The GATE/GPAT or any other national level test meant for
admission to Ph.D. be considered as per validity of score
card.

iv. Ph.D. Entrance Test of Panjab University for admission to
Ph.D. shall be valid for 3 years.

v. The Entrance Test syllabus shall consist of 50% of research
methodology and 50% shall be subject specific.

vi. Students who have secured 50% marks in the entrance test
are eligible to be called for the interview.

vii. A relaxation of 5% marks will be allowed in the entrance
examination for the candidates belonging to
SC/ST/OBC/ differently-abled category, Economically
Weaker Section (EWS), and other categories of candidates as
per the decision of the UGC from time to time.

viii. Panjab University may decide the number of eligible
students to be called for an interview based on the number
of Ph.D. seats available in the respective
departments/ approved research centres.

ix. Provided that for the selection of candidates a weightage of
70% for the Academic Performance Index and 30% for the.
performance in the interview/viva- voce shall be given (see
Annexure-I for Performa to construct merit for admission).

5.1.1. With regard to admission in Ph.D. for foreign students, the
following guidelines shall be followed:-

a. International/Foreign students who are being sponsored by
the government body such as the ICCR or MHRD or a
government agency of their own country, will be given direct
admission to Ph.D. subject to the approval of the concerned
department or centre.

b. International/Foreign students who have been studying in
India and are present in India at the time of the Ph.D. CET
will have to sit for the test and clear it in order to be
considered for enrolment.

€. The International/Foreign students who are not present in
India at the time of the Panjab University Ph.D. CET will
need to achieve at least band 5 in IELTS Academic or 60 in
TOEFL or 150-154 in GRE or 600 in GMAT. At the time of
filling the enrolment form the candidate must attach the

\Y iw, 6|Page

© scanned with CKEN Scanner

<!-- page 9 -->

\
score in any one of the above tests. However, all such
candidates will have to qualify in the interview.

5.2. Panjab University shall conduct entrance examination as a
qualifying examination for admission to Ph.D. once a year in the
month of July (With exemption of test to categories mentioned in
5.1(i) to 5.1(00). However, to facilitate admission of candidates
before the expiry of the validity of entrance examination/JRF offer
letter, the application for admission to Ph.D. shall be accepted
throughout the year. All accepted applications shall be processed
(as per 5S.1(ix)) for admission in three cycles in a year (i.e., in the
months of January, May and September). However, in case of
research fellows employed under any state/central/international
research projects, their applications for admission to Ph.D. shall be
processed throughout the year provided they fulfill eligibility
guidelines given in 5.1(ix)). In each admission cycle, afresh merit
list shall be prepared. Panjab University before initiating process of
admission in each admission cycle shall:-

5.2.1. decide through the Academic and Administrative
committees of the respective Departments and approved
research centres a predetermined and manageable number
Ph.D. scholars to be admitted during each admission cycle.
The number decided by Academic and Administrative
committees shall be depending on the number of available
Research Supervisors and other academic and physical
facilities available, keeping in mind the norms regarding the
scholar- teacher ratio (as indicated in Clause 6), laboratory,
library and such other facilities;

5.2.2. notify well in advance on the institutional website/through
advertisement in at least in two (2) national newspapers, of
which at least one (1) shall be in the regional language, the
number of seats for admission, subject/discipline-wise
distribution of available seats, criteria for admission,
procedure for admission, examination centre(s) where
entrance test(s) shall be conducted and all other relevant
information for the benefit of the candidates;

5.2.3. adhere to the National/State-level reservation policy, as
applicable taking cumulative number of seats in each
admission cycle during over a period of one year.

a) Every department would have to specify, well in

advance, for printing in Ph.D. Prospectus/posting on

. institutional website/printing in newspapers, the

number of seats available for registration to Ph.D.

| (2 7|Page
© scanned with CKEN Scanner

<!-- page 10 -->

|
programme in each admission cycle, irrespective of the
fact whether the Ph.D. Entrance Test for that
department/ subject is to be held or not in the month of
July.

b) The reservation of seats of SC/ST/BC/PWD candidates
will be department-wise and L-shaped roster would be
followed, i.e., if the number of seats in a given
admission cycle is less than 7, then the reservation will
be given in the next admission cycle when the 7th seat
(counting seats of both the admission cycles) becomes
available. Similarly, if cumulative number of seats in
first two cycles is less than 7, then the reservation will
be given in third cycle when 7 seat (counting seats of
all three admission cycles) becomes available. At the end
of year (i.e., all three cycles), if number of seats is less
than 7, then the reservation will be given in the next
year when the 7th seat (counting seats of last three and
1st cycle of the current years) becomes available.

c) The specialisation within the subject for giving
reservation will be decided by the department.
Reservation policy is to be followed for Ph.D. scholars
working as Project Fellows in various projects also.
Every Project In-charge / Principal Investigator would be
enjoined upon to ensure that n™ project fellow recruited
under him/her is from the reserved category enlisted for
reservation at the n position, e.g. every 7th project
fellow is for SC category and so on.

d) The registration of Ph.D. scholars should be thrice a
year (during January, May and September cycles) except
in those departments/approved research centres where
there is fixed number of seats advertised on annual
basis.

e) The registration shall be done in the months of January,
May, and September subject to availability of seats.

5.3. It is stipulated that each department of Panjab University,
including affiliated colleges/approved research centres will follow
admission criteria 5.1(ix) that shall be notified by the Institution,
keeping in view the guidelines/norms in this regard issued by the
UGC and other statutory bodies concerned, and taking into
account the reservation policy of the Central/State Government
from time to time.

੭ ਭਿ 8|Page
© scanned with CKEN Scanner
