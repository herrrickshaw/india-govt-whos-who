---
doc_id: "43bf78ace04ac9cf"
source_url: "https://purch.puchd.ac.in/includes/tenders/2015/20151119110604-canteenshoptender.pdf"
ministry: "P.U. Swami Sarvanand Giri Regional Centre, Panjab University, Chandigarh"
title: "FOR ALLOTMENT OF CANTEEN SHOP CONTRACT (FOR 3 YEARS)"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ab9b3ad3f079ce41"
---

<!-- page 1 -->

PANJAB UNIVERSITY, CHANDIGARH
PANJAB UNIVERSITY S.S.G. REGIONAL CENTRE,
BAJWARA, HOSHIARPUR
PH.:-01882-282618, 282617 FAX-01882-282221
CANTEEN SHOP TENDER
Sealed tenders are invited from interested parties/persons to run Canteen Shop in
the campus on lease basis for 3 years. The Tender documents containing detailed
Terms and Conditions may be obtained from the office of Director on payment
of Rs.1000/- in Cash or by sending a draft in favor of Director, PUSSGRC,
Hoshiarpur.

The

tender

can

also

be

downloaded

from

Website:

www.puchd.ac.in and www.ssgpurch.puchd.ac.in. The last date for the receipt
of tenders is 04/12/2015 up to 3:00 p.m.

Sd/Director

<!-- page 2 -->

PANJAB UNIVERSITY SWAMI SARVANAND GIRI REGIONAL CENTRE
UNA ROAD, BAJWARA, HOSHIARPUR (PB)
Ph. 01882-282617, 282618, Fax: 282221

PRICE-Rs. 1000/TENDER FOR ALLOTMENT OF CANTEEN SHOP CONTRACT (FOR 3 YEARS)

LAST DATE FOR RECEIPT OF TENDER:

04-12-2015 by 3:00 P.M.

NAME AND ADDRESS

___________________________
___________________________
___________________________
___________________________

TELEPHONE NUMBER, FAX

___________________________

EXPERIENCE TOTAL NO. OF EXPERIENCE

___________________________

LIST OF PRESENT ALLOTMENT (IF ANY)

___________________________

ALLOTMENT DETAILS:
(I)

(II)

In cash Rs. 1000/- (Amount deposited in State Bank of Patiala, PUSSGRC,
Bajwara,
Hoshiarpur
Account
No.
65143837044
vide
Scroll
No._______________
Dated _____________)
Rs.
1000/by
Demand
Draft
No.
___________________Dated
___________________)
Name of Bank:
________________________________________________________

Amount:
_____________________________________________________________

<!-- page 3 -->

PANJAB UNIVERSITY SWAMI SARVANAND GIRI REGIONAL CENTRE
UNA ROAD, BAJWARA, HOSHIARPUR (PB)
Ph. 01882-282617, 282618, Fax: 282221
TENDER FOR ALLOTMENT OF CANTEEN SHOP CONTRACT (FOR 3 YEARS)

FINANCIAL BID
Tender for Canteen Shop Contract (On lease for 3 Years)

Dated: ___________

BASE RENT

Rs. 3000/- Per Month

Mentioning the Rate of Monthly
Lease Money

Rs. ___________________________
(In words Rupees)
( __________________________________________ )

Signature________________________
Name: __________________________
Address: ________________________
________________________________
________________________________
________________________________
Date: ____________________________

<!-- page 4 -->

GENERAL RULES AND TERMS & CONDITIONS FOR
ALLOTMENT OF CANTEEN SHOP
1. That the lease will be created for a period of three years from the date of allotment.
2. That the above mentioned period of three years is only in respect of the agreed monthly
lease money and does not vest any other right in the lessee.
3. That the lease money shall be payable in advance by the lessee by the 7th of each calendar
month. In case the lessee fails to deposit the lease money by 7th of each calendar month,
he will have to pay interest @ 18% per annum compounds to the lessee.
4. That the lease money shall be payable in advance by the lessee by depositing the same
through Demand Draft/Banker’s cheques in favour of Registrar, Panjab University
payable at Chandigarh against valid receipt. In case the lessee fails to deposit the advance
lease money by the 7th of each calendar month, he will have to pay interest @ 18% per
annum compounds to the lessor.
5. That the lessee shall deposit equivalent to six months lease money as security and one
month advance rent through Demand Draft/Banker’s cheque in favour of Registrar,
Panjab University Chandigarh payable at Chandigarh before the commencement of the
lease with sureties of two persons acceptable to the Registrar, Panjab University. No
interest will be payable on the security amount.
6. That the lessee shall remain and enjoy on the leased premises on behalf of the lessor as
long as the lessor permits for running the trade of Canteen Shop only.
7. That the lessee shall abide by all the provision of the Capital of Punjab (Development and
regulation) Act 1952 along with the rules framed by the Syndicate of the Panjab
University from time to time on that behalf. Further, this lease is subject to the provisions
of the public premises (eviction of un-authorised occupants) Act. 1971.
8. That in case of any levy, cess, tax or any other liability imposed by any competent
authority, the same shall be paid by the lessee directly to the authority concerned without
any objection.
9. That the lessee shall not cause any damage to the premises will hand-over the premises in
the same condition as it has been leased to him and it will be his responsibility to keep the
premises in perfect condition.
10. That the maintenance of Canteen area allotted to you would be taken care of by the
University but the annual white washing, biennial paint or any other type of minor repairs
shall be carried out by the lessee at his own cost and expense.
11. That the lessee shall use the premises to carry on the trade of Canteen Shop only. The
lessee shall not put the premises to any other use including allied or ancillary trade
without the prior written consent of the lessor. Change of trade without such consent will
automatically amount to termination of this lease.
12. That the lessee shall not start additional trade.
13. That the lessee shall not make any addition or alternation of any type or otherwise in the
premises without obtaining prior written consent of the lessor. In case the addition or
alternation is permitted by the lessor, the same shall be carried out by the lessee at his
own cost and he will not be allowed to remove them at the termination of the lease.

<!-- page 5 -->

14. That the lessee shall keep the premises/shop and the surroundings neat and clean and shall
not be allowed to keep anything in the Varandah (in front of the shop) or the roof or the
open space. The Registrar or his representative may without any prior notice, order the
lifting of all such material on the un-authorised places and the same shall be forfeited or
released on payment of penalty to be determined by the Registrar. The Registrar or his
representative can check the encroachment by way of keeping articles/materials in the
Varandah and can impose fine @ Rs.500/- to Rs. 5000/- to this effect.
15. That the lessee shall not sublet or part with the premises or part thereof in any form
whatsoever (even in the form of partnership) to anyone.
16. That the lessee shall pay any other charges recoverable by the concerned departments of
the Administration & Municipal Corporation.
17. That in case the lessee vacates the shop/premises before the expiry of the agreed period,
the Registrar shall right to forfeit the security deposit.
18. That the lessee shall conspicuously display rate list as per the norms of the Chandigarh
Administration. In the largest interest of the consumer, apart from the officials of
Administration, the University shall have the power to monitor and ensure compliance
with law and to take suitable action.
19. That the lessee shall bear and pay the expenses for the execution and registration of the
lease-deed and deposit the original lease deed with the Estate Branch of the University.
20. That the advertisements displayed shall be according to the Punjab Govt. Control order
1954 and the benefits/income accruing there from shall vest in the lessor.
21. That the lessee shall not use any part of the lease premises for the purpose of residence.
The lease shall stand terminated if any part of the premises is found to be used by any one
for residence.
22. That the lessee declares that he is and will remain the sole owner of the business in the
premises afore mentioned and will not enter into partnership with any one without prior
written permission of the lessor. The lease will be terminated automatically if he inducts
another person as his partner in business.
23. That the Registrar or his nominees shall have access to the premises at all reasonable time
to inspect and see for himself that the agreed conditions are strictly adhered to by the
lessee.
24. The lessee shall pay the electricity charges as per actual consumption of the sub meter at
the commercial rate and water charges @ Rs. 600/- per month to the University. The
lessee shall install approved and calibrated sub-meter for electricity connection and Aqua
Guard for the purpose of Drinking water at his own cost.
25. That the lessee shall pay an increase of 5% of the agreed lease money every year.
26. That the lessee shall neither object nor obstruct the entry of the lessor on the leased
premises for inspection maintenance and taking over of the premises on the termination
of the lease under any of the clauses of this deed.
27. That the Registrar may allow purely temporary use (as putting up a tent) of the open
space by the lessee on payment as determined by the Registrar.
28. That the quantum of minor maintenance including cleanliness to be carried out by the
lessee will be decided by the Executive Engineer of the University whose decision will be
final and binding and the same shall be carried out by the lessee at his own cost and
expenses.

<!-- page 6 -->

29. That the lessee shall dispose of the garbage only at the prescribed garbage bins. The
Registrar may impose a fine up to Rs. 1,000/- (One thousand only) if the lessee is found
spoiling the cleanliness by throwing garbage at un-authorised places.
30. That the lessee shall not indulge in any such activity which will cause nuisance to others
or which is considered by the Registrar as not congenial to the campus atmosphere.
31. That the lessee shall not commit any act or omission which is detrimental to the interest
of the Panjab University in any manner. Indulgence in any such act or omission will
amount to automatic termination of this lease and forfeiture of security.
32. That the lessee shall get the lease deed registered from the competent authority at his own
cost and deposit the original lease deed with the Estate Branch of the University.
33. That in case the lessee commits breach of any of the above terms and conditions of the
lease deed the lease will stand terminated forthwith and the lessee will not be entitled to
the convenience of any notice of termination.
34. That the automatic termination of this lease on account of violation of any one of the
aforesaid clauses will make it obligatory for the lessee to vacate the premises voluntarily
within 10 days from the date of the violation, failing which lessee will be deemed to be
continuing illegally on the premises and in addition to other legal liabilities, the lessee
will be liable to pay a penalty equivalent to one month lease money for every day of the
illegal continuance on the premises.
35. That notwithstanding anything in the foregoing clauses of this deed, the lessee shall obey
and abide by all such orders/directions issued by the Government and the Panjab
University from time to time which are in the overall larger interest of the University
(lessor).
36. That the lease deed will be automatically terminated on the expiry of the period of three
years and lessee will hand over the vacant possession of the shop.
37. That is case the lessee ceases to occupy the premises for three months, the lease stand
terminated automatically.
All terms & conditions given in tender documents have been read by me/us & accepted.

Signature________________________
Name __________________________
Address ________________________
________________________________
________________________________
Date____________________________
