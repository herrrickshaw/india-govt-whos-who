---
doc_id: "ba961841ffad2bef"
source_url: "https://iqac.puchd.ac.in/docs/2022/20220627170043-annualgendersensitisationactionplan.pdf"
ministry: "Panjab University, Chandigarh"
title: "Policy document on Annual Gender Sensitisation Action Plan"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "aaeb0c10f488e280"
---

<!-- page 1 -->

Annurl Gende. SeNilisntion Aclion Pl!n
Parjab UnileNity. loclred in rhejoint cxpnal ol Punjab and Haryana, !iz. Ch.trdisanr has its
oatchmentarer in rhe Nohighly patiixrchal$xEs which have become infanous for atr adveue
sex rdlioxnd od,er lbrn$ofdhc.iminationagainsr womcn. Thcroolsolthese lie inapatiarchal

mindser which can lid must be changed rhough gender ensitkation.It is wilh this in mindlhat
the Panjab Univelsny CenderSensirhalon Action Ph. is tbrmrlared.

Ge.der sn snisation is not nerv to Panjab Unive^ily which becamehomero one ofthe fist iive

wonen\ st0dies Centes ser up by UGC wa! back in 1937. Elcf sincclhcn rhc Womcn s srudics
Cente hrs taken x le.d role in gender sedsithxtion Nnhin lhe campus as wcll 6 in thc

.o nnh.).nd la. beer.ordrrir sr rmercr.serde 'ersiri aior.prosErnnes
The Panjab UniveNity Action Pl,n fdr gender sensnharion is fnmed le€ping in mind rhar the
boundaries bel$eD rcademh rnd the cohdunit! are fluid wilh both intencting wilh and
impacliogeach other. The Unive6itycrnor isolab iaelfin ivory towers and borh ihpactand is
impacted by lhe conrmunity. Like$ke, no poLicy for serdef sensirkltion wilhin the University

willhaw any effect uDLesssuch gender sensitk'rion is aho conduored!tlhe conmunity^ociety
level. Funher, !here k.lhe recognirion that both males and females hsve lo be gender sensilked
for beiDg a female does not automatically make a pe6on gendeFsensitive. Keepinsthis in mind,

ihe Penjab UDiveNity AclioD Plan hus been lormulated with t*o $mnds lhat will trltimarly

i enwineand inpacr each oiher.
One G gendef sensitGation within the campus and rhe orhe. is gendef sensnisation iD the
comnunirt, Thc larter funher has two conponenrsrone pogramme oralnised by the UniveNity
lor lhe communit' and secoDd the focully as Resource PeNons in prcemmmes oqaDked by
other oryanisationvlNtitutes rvilh the objective of gendef sensitisllior.
It mu$ ako bc pointcdoutrhat ecndq scDsnisarion has to bc a conlin0ous process ior the Iask h

ncvcr complctc. Accordingly, lhc Action Platr olthe Univesity for gender seisilisation slull
continue tiofr year to year

^

the stakeholde^, and panidiFnts shall keep changing rvilh the

pftviods batch .f studenrs prssing out dnd new entranrs enteing the campus, ard so on

Morsvcr, sender sensitisation has lo be continuously reinlorccd, onc programne rvilL not
c|anse a deecly embedded mindset ard so conlinuous prosrsrnmes arc nccdcd.

<!-- page 2 -->

To orcKee tlc vorking ofthe gcnde.scnsitisxtion adion

Dritrj I nod conrnitrce ryoutd be

creal.d.onsisting oarho reprcsenrrtivcs f.on the DcDarrheni cuh

L€nrfe lbr Won.n
Studis, Centrc lor HuDan Riglts rn{i Dtrries, Dep.rrDrenr ol L.\vs, poptrt.rion
Rcscanh

Centro, D.prrtment orCohnuniiy Educrtion & Dhlbiri{,

UILS ,nd cenrre For Socjrl

wirh Ois backdrcp, rhe tahjrb Unive6ny A.riotr pld for€ender

sensris.tion js as ro ows:

tlithih tlu Ukifersiu: todrcinA the.fo o*ihtl prcgunne, p.riod)cutt!:

. Cendersensirisalionworkshopsfor:
o Srudenrs (i nct ud jng Hoslet Esjdenh)
o NCC&NSS
o Non,reachingnall
o Security peNonnel
o Fotrnhc ?s cnlplolces jnctudingpc.ns, g.fdeneB,clflreA.erc.
o Orher peisons working in the campus suc( !s nes/canEetr workeN and
conlractor,selc'

t Cerder sensilh.rioD proC,amne as ipan oflhe facuhy devcloprnent p.ogmnines.
rc.m couNcsj xs we as.efteshercouAcs orgahhed

.

rhort-

in re Unive.silr.

ANdfeness Foamnrmes on sextral hamsmenr otrvomcnVrmnsgendes

. Awarcness ptusranhes on mensr.trat heatth and hygjene as rve| ,s

ntrdio, fdr

Maic/lemaldhnsgc.Jer.

t TDining proeu'nmcs for soinetr enposerhent to erhance pani.jparion

of wom.n in

. Arvareness rros.aDmes on tegat rishls of rvomen and poticics retarcd

ro women &

!

Exh cuujcutar acrjvitcs ro pfonole awarenc$ abou,

scmef jssues such as debarcsj

<!-- page 3 -->

. Minidum ono.crivity on Cender SensiGarjon from anr ofrhese ro be orsanized tn cxch
o Webinatsenrilarlspediat lecture/ fosrcr n*ing/deb.re compctirion/ Oulrca.h
ac!i!iry / rvatkathoi/ mrrarhon/ spons comperitjon elc. aid submit rhe repon ro
nddatcomminee,

! Seladelcnce.clivilies rorthesirt $uderls.
Withhl tlp Conmrhit!: fhe tiltowing prolfxnnres ro be conducred b! rhe Unive^ny

wnhin

. GenderseDsitkalion ofpe$ons ar alt tevers in:

o Adm nislralion
t Gends Scnsnnar ion lAngan*ori worke 6 trd olhe. ICDS tunciionaries
o

a

. Thc idlensivc oukeach sctiliries for re gender sensnhaaon in the comnuniry byNss
r CeDdcrsensitnsrion prog€ms in rhe adopted vi lges otpanjab Unt!ersity.
t cender scnsnisarion of peNons invotred in jmptemenring schcm€s for woneD aDd
childreninclLdingChitdrighlsCohhiiree,lJBoard,andsoon.

Paiicipatiat b! the Depoinents i" con nu,i0 Ellorts:
SiCnifisnlly, thesc Programmes should be conducred under rhe banner ofa noda! coDmilee
coisistinsof rhe rcpfeenrarives iom rhe Depanmcnr cum Cenre for wofren Srudies,

Cenft |or
HtrmM Righs bd Durics, Depanmem df t_ass. poputlrion Re*arch Cenrre, Dep.nmcnr

of

Conmunnt Educarioi & Disabilnt, UILSand Cenlre For Sociat work.

<!-- page 4 -->

Panicipotio" b! lacahr in Codhuzit! EIlois:
PU Faculty lo acr

s csoue peEons in gender snsilhation prcsamnes.orghised by

the Adninisrdlion of Chandigarh and neighbouring aHs.

PU Facuht to panicipate actively in Comnirtes set up by vafiou Covennents and

Oryqisalions for implemdiarion of las and polici€s sDch as POSCO Act, JJ Act,
PCPNDT Act, and POSH Acr. er.

<=r4=)e2)-

@*'"n*-

lar.u.

\"""V
\

u%$

<!-- page 5 -->

/

7.1.1Merstrrqs initiat€d by the Prnlab Unjv€rsit tor thclronolion ofgendc.€qufty

a) Desdlibe the cunicular and co-curiculr snd extr cu nicurar acdvnies
equrly afd scnsirization and lhe f.ciliries available tor womeD on
nraximrd of500 sords).

nb

!our. .F

r
o
u1 br ke ulivelry ro! brirc vho t) or prn
'
promor neScnderecuriJ
dndsensiriarion.
a

l l;:

'

Thefollowing ou$s run by rhe Depl-on Centrc tbr Women,s Sludies

r r on

srr whdlty

r ! L! rfrlrqr !Lr-nj.x-n: *oh+.a0rc'/0.u!!::-!+Ll+
2020-l 2n2l-l odr??022Ott4i5Ol
!d] smen rudie\ n!jl:202t0,11501

*.^".d

The Cenke ror H rndn nigh's rnd D{r,es
D[ies has approximare]y

;:i,:jJ"T;:lffixl

hrhs://puchd.ac i'ti'r0hrdetsvttabtrVzl]z0/202008i

I 2

50 pocenr of lhc couses

t2:l.lt-

T.!!93!!rg+s!r!!l!!!!!c!q9!!cEys!q!42!2cl!bdp202203 I 43501
The CenrE lor Socirt Work stso rros muns rmuea on

li*?:il.'i:;.xl:: ;:i:i"c \ :e'r P b ! solio'oe L"e i,' md
hr nst/ou.hd.aL'n/i'rclude\

itlabdzl))t/202|tiI t5.14:-

s###+#s.,**l],ji'-!r>llrll20,r=
i\c.. di,ro'oe i'.o. d ...e
o,..n c 2t0 i;r..0:to. atro_
hro,.//o*l,drc ./ mlud6^\"..o,
ltab,v2()ts,20 til)a roii-t

socioloev.ndP20220ll4350l
hllpsr/puchd.rc.in/ircludes/s lhbf s 202n/202008t1t4502t-m.ahisLor

2 odf20220l 4lsol

h'rns//LuchJ rc in/'nctudc!$t ab,!202t/20) I I I I l2()8t I
1., n,,1.
.n.c. n< re,.. re,,c.ir ,,r,-,
.,
hu.s.//nf cr'd
rt trqluder$ tbbu!lor0 :ODos2t|2|6E
mder n{o\ ernatrceteadcEh,o20 | 9.20 pdn2o2-tttlJOr-

!

r

O,t

*l

20.t0-

!l:202203r4:r501

In addnion, a compulsort pape. has been intoduccd at rhe
undefgoduale telct on
Donestic Violencc and ChildAbNefrcm $e

<!-- page 6 -->

,./

Coahric a|Actieities:

' iil"":' ;U"l'":i# y'i:';j":;U:j{,i;:itit;i:r".:Xt"1,.
'';*Jlli :1t;T,1"":,i":,i.i;1,:

:1. ;,1,""j1,:;:t;' I

-,

I".iL.:j;

qn,i a . 1 ..,, e

(.;,

' I l;{l'^r }:Xli,lli#;;;'i::il;" :' :l;"'; :.:;:;;;l} ;,0", -"
l;

"

Exta-Cu ni cutat A.t irities :

: ;#tll,"' r;#iif { *:":i rxr :i:lnrh u.i

tr:
:ili*";_,
""* 1r,: 1l i: !.q H ;:j ; ff :" ti:l i;li.L:r ii,:;,1;i
t-";:':;;it:t ll. lli:t#,3.:t::ffT.:i;:?"ti:":l;"

denrtr--..,. 2'ro,,
D.x. ..,. 3 5:or oeen k. 1eo, q.,d.rl
!:' llad
,Toh'.r',. i'on .pc..trc t,.",r'o1
t-,e,prc1,.eo tor \or. 11 ,,e.n ol
r. .r'cry drr \.curiD:

J;lJ,'';Tiijl#3"Hil:il}:1o!oiorir' for Panilb uDivqsnv and a,riae nuDber

i.]i:l"11::ffir!i.'i.

it to,.y
b| 1il
0 !r T " I d{. pJ i.,t,rh
"li"i rr ._*""ti,,i}ll. .e.:;"ijf
."\ mrJ b" Jr
"o..,,
""0. ",

, i;;""'':iff I "::.;*.j'l;J:",i:i,l,Hi' .- " . ",. -".
- ';:1," i;i':;'.lti:: J.I,i:: L' dnd ,, r tr. o .. d
I
"'i.
,
prnlmq.
m

v

trqe ire reAUterpntke
rh< InrcrnJt c.mptrin,s Co,nm/;ec

o .",;:1,;il.,,*i;

;i ;:":;,';i -;l{pUCAsHr h,

''li,.l,,.'...en'e''

a.'ne,1 0..,,,

"

" lli: i"i li,,l :.lli;"i.lles:1oh'hea 1,r o,,.,e., 'red ,ud.,, !\e.,,c
" i"l :: l,r,' *,*",,t:l:;,:1,"' \"J i",-"..''"s,
hrn o.
"' r; ft'l*';l'"il
;ti ::; ;,ti:. i:1:.iJ::_: I il t;;;, ",*
"
"
hc Depr

:,ffi il ff iffi?t J::l; [i,ill"JJT$!;J]",",""t

:",[T:if f l,i;:""i

<!-- page 7 -->

"

F"ff;'":"il::,1j,1,ffi l; filill*

Hfl *::,";itsiff

rsm w,h &cj,nbs

t*rijlffi *** *ruliil*itni*

*

.ift}nu,}nftfi*.1ffi-.

<-*,-1t

D-rr

F$$i,1'-

"ffii-,' laoi*t'-"
\*ry
***r,r*- \

.

OJK
