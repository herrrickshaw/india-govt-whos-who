---
doc_id: "13cd4bb2bfc8c4da"
source_url: "https://www.library.puchd.ac.in/includes/tenders/2015/20150302093638-tenderlib.pdf"
ministry: "A. C. Joshi Library, Panjab University, Chandigarh"
title: "Digitization of theses and Implementation of Digital Document Management System at A C Joshi Library"
date: ""
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "57be56bf5a1bf5c6"
---

<!-- page 1 -->

Inviting Open Tender
A C JOSHI LIBRARY, PANJAB UNIVERSITY, CHANDIGARH – 160014
Subject: Request for Technical and Financial proposal for Digitization of theses and
Implementation of Digital Document Management System at A C Joshi Library, Panjab
University, Chandigarh
Sr.No. Description
1.
Name
2.
Tender Subject
3
4
5
6
7
8
9
10
11

Issue of tender
Submission of tender
Tender Submission
Tender Opening Date
(Technical bids)

28/02/2015
16/03/2015 till 3.00 p.m.

12
13

Place of Tender Opening
Address to Send Tender
Document
Contact
Details/Telephones

A C Joshi Library, Panjab University, Chandigarh
A C Joshi Library, Panjab University, Chandigarh

14




Tender Type
Tender Category
EMD/Bid Payable (INR)
EMD/Bid Security
payable to
Cost of the Tender
payable to

A C Joshi Library, Panjab University, Chandigarh
Digitization and Digital Document Management System (DMS) of
Theses at A C Joshi Library, Panjab University, Chandigarh
Open
Services/System
Rs. 70,000/- (Seventy Thousand Only)
In the form of TDR, in favour of “Registrar, Panjab University,
Chandigarh” from any Nationalized Bank.
Rs. 250/- (Non-Refundable) to be paid in the form of DD for the
cost of the Tender in favour of “Registrar, Panjab University,
Chandigarh” from any Nationalised Bank.
In person/post

The Technical bid shall be opened on 16/03/2015 at 3.30 p.m
The date and time for opening of the Price Bids shall be
intimated later after evaluation of the technical bid. In case
date of opening falls on day which is declared public holiday
the bids shall be opened on the following day at the same time.

1. Dr. Raj Kumar (University Librarian)
A C Joshi Library, PU, Chandigarh
Tele: 0172-2534551 Email:librarian@pu.ac.in
2. Mr. Vinod Garg, System Administrator
A C Joshi Library, PU, Chandigarh
Tele: 0172-2534578 Email: vinod@pu.ac.in

1. GENERAL TERMS AND CONDITIONS
 This invitation for bids is open to all firms, engaged in providing Digitization and
Digital Document Management System. 
 The Vendor to enclose Registration of their firm/Company. 
 Any effort by a bidder to influence the purchaser in the purchaser’s bid evaluation, bid
comparison or contract award decisions shall result in the rejection of the bidder’s bid
and also banning of business dealings with the bidder for a period of three years from
1

<!-- page 2 -->








































the date of such ban.
Tenderers must note carefully that any infringement of the specific requirements
contained therein may invalidate the tender. 
This tender form is not transferable. 
This tender form consists of pages 1 to 14 including Annexures. This tender form
alongwith covering letter should be returned to the Institute along with technical and
financial bids. No tender will be considered unless and until all documents are properly
signed. 
The tender must be accompanied with Earnest Money for Rs.70,000/- in a lump sum
amount in the form of TDR deposit valid for a period of one year from any scheduled
bank in the name of the, “Registrar Panjab University, Chandigarh” from any
Nationalised Bank. Earnest Money in any other form will not be accepted. 
Bids not accompanied by Earnest Money as stated above or less than the amount
stipulated above shall be summarily rejected. 
The successful tenderer shall be required to furnish a Contract Performance Guarantee
Bond in the shape of Bank Guarantee (as per Annexure “C”) or TDR (pledged in favour
of Registrar Panjab University, Chandigarh for an amount equivalent to 10% of the cost
of the Project. The Bank Guarantee or TDR should be valid for 30 months. The Bank
Guarantee for 10% of the contract value shall be submitted within a period of 30 days
after the placement of the Supply Order failing which the order will be liable to be
cancelled and the earnest money forfeited. 
The Institute would return the EMD to the successful tendering firm on the submission of
the Performance Bank Guarantee (PBG). 
The Institute does not pledge itself to accept the lowest, or any tender, and reserves to
itself the right of acceptance of the whole or any part of the tender, or portion of the
quantity offered, and the tenderers shall be required to supply the same at the rate quoted.
The University reserves to itself the right to accept or reject any or all the tenders without
assigning any reason thereof. 
Tenderers would state categorically whether they have fully trained technical/ staff for
digitization/Digital Document Management System and efficient after sales service and
provide details thereof. The tenderers should also provide the sufficient infrastructure
details. 
Tenderers would categorically confirm that they will give free “After Sales Services”
during warranty period for a period of 24 months from the date of installation,
satisfactory commissioning and handing over the project/ equipment; whether they have
fully trained technical staff for digitisation/ digital document management system and
efficient after sale service. 
The successful bidder will be required to enter into an Agreement with the university on a
non-judicial paper of Rs. 30.00 for the satisfactory execution of the project as defined
above as per specifications and terms and conditions listed in the document and agreed
upon. 
Your tender must reach this office not later than 3:00 p.m. on the date of opening of the
tender. Both the technical and financial bid should be kept in two separate sealed
envelopes and should super scribe “Technical Bid” and “Financial Bid” in bold letters. 
2

<!-- page 3 -->

































Tenders sent by hand delivery should be given to the Diarist in the A C Joshi Library, PU
not later than 3:00 p.m. on the due date.
The technical bids shall be opened at 3:30 p.m. on the date of opening of the tender.
You are at liberty to be present in person or through your authorized representative, at the
opening of the tender at the time and date as specified in the tender notice. The
representative should carry due authorization from the tenderer. Institute in its discretion
may not allow any representative, who does not carry authorization for being present in
bid opening. In the event of the day of receipt and opening of tender being a holiday for
the PUC, then due date of receipt/ opening of the tender will be the following working
day at the same hour. 
The successful tenderer will be required to undertake to provide at his cost technical
training upto 10 personnel involved in this project or any other staff as decided by the
University Librarian. 
The tender is liable to be ignored if complete information is not given therein. 
All corrections must be signed by the tenderer in full. 
The offers should be typed or written in ink. Offers in pencil shall be ignored. 
Any tender which is not made out in the proper form or is received late after specified
time shall not be considered. 
Offers with any price variation clauses shall not be accepted. 
Any conditional tender or any deviation from the terms and conditions of the tender
notice shall render the tender liable to rejection. 
Tender qualified by such vague and indefinite expression as ‘subject to immediate
acceptance’, subject to prior sale shall not be considered. 
E-mail/ Fax offers shall not be accepted. 
Only turnkey solution providers or their authorized sole distributors/ sole Agents are
entitled to submit their tenders in accordance with the technical specifications. All offers
other than those from the executor should be supported by an Authority letter from the
executor authorizing the firm to tender on their behalf and this Authority letter must
accompany the Technical Bid. Certificate or Photostat copy thereof to the effect that you
are the executor of the equipment/ authorized sole distributors or Agent for the executor
on whose behalf you are quoting must be included in the tender in the Technical bid.
Offers from executor/ their authorized distributor agent will only be considered. 
The courts at Chandigarh alone will have the jurisdiction to try any matter, dispute or
reference between the parties arising out of this Agreement/ contract. It is specifically
agreed that no court outside and other than Chandigarh court shall have jurisdiction in the
matter. 
Force Majure: If, at any time, during the continuance of the agreement, the performance
in whole or in part by either party of any obligation under the agreement shall be
prevented or delayed by reasons of any war, hostile acts of the enemy, civil commotion,
sabotage, fires, floods, explosions, epidemics, quarantine restrictions, strikes and lockouts and any statute, statute rules, regulations, orders or requisitions issued by any Govt.
Department or a competent authority or acts of God (hereinafter referred to as
eventualities), then provided notice of the happening of any such eventuality is given by
either party to the other within fifteen days from the date of occurrence thereon, neither
party shall, by reason of such eventualities be entitled to terminate this contract
agreement nor shall either party have any claim for damages against the other in respect
3

<!-- page 4 -->

of such non-performance or delay in performance
 During working hours the person can visit the A C Joshi Library to see the actual theses.
SCOPE OF WORK
The terms of reference are for “Digitization of theses and implementation of Digital
Document Management System at A C Joshi Library, Panjab University, Chandigarh”. Under
this project all PhD theses (8000 approximately) available in A C Joshi Library, Panjab
University, Chandigarh have to be digitized and archived. The PhD thesis amounting to
approximate 8000 theses which PUC would like to be transformed/ converted into the digital
format with intent to create digital archive by uploading on Intranet (PU Web Server )/Internet
based Digital Library Platform on Dspace/ Eprints/. Majority of them are in English language,
some of the theses in languages other than English i.e. Hindi, Sanskrit and other foreign
languages are also part of the collection. This digitization project is time bound and should be
completed within six months. If the project is not completed in time a penalty of 1% of the total
cost of the project will be imposed per week subject to the maximum of 10%. However, any
delay beyond the specified period due to genuine reasons can be condoned by the PUC.
TECHNICAL REQUIREMENTS
A THE ELIGIBILITY OF BIDDERS

















Please send tender offer in closed/sealed envelope addressed to: University Librarian,
A C Joshi Library, Panjab University, Chandigarh. Both the technical and financial bid
should be kept in two separate sealed envelopes and should super scribe “Technical Bid”
and “Financial Bid” in bold letters. TDR/EMD should also be kept in envelop and all
these documents would be kept in another sealed envelope. Financial bid will be opened
of those bidders who will successfully qualify in the Technical Bid part. The undersigned
reserves the right to reject, cancel any particular or all bid offers without assigning any
reason whatsoever. The decision of the competent authority shall be final and binding. 
Bid offer should be valid for 365 days from the date of opening of tender. 
The bidder should have past experience in digitization and digital document management
system or similar work with minimum single invoicing of Rs. 8 Lacs and above during
the last three years. These orders should be from any Government Departments /
Autonomous Bodies / Public Sector units/ reputed organisations. Provide documentary
proof i.e., copy of work orders & successful completion certificates as the documentary
or payment remittance as evidence. The Institute reserves the right to inspect such sites
and see actual performance of such systems. 
The agency should have handled scanning and all other related jobs specified in the
tender for University/ similar institution (Please provide documentary proof to this effect) 
Vendors have to make use of over head scanning system for scanning print theses
wherever applicable. 
The entire work shall be carried out under successful bidder’s custody and the successful
bidder should follow all safety regulations and take all measures to prevent damage/ loss
to the documents of the University. 
4

<!-- page 5 -->































Joint bids and outsourcing or subletting of any nature / third party would not be accepted. 
The vendor/agency should give an undertaking in the form of affidavit that it has not
been black listed by any Government/Autonomous/PSU type organizations, etc.. 
The bidder should submit the details of income tax registration & copy of PAN Card,
Sales Tax/VAT/Service Tax certificates. 
The sealed tenders along with an EMD of Rs 70,000/-(Rupees seventy thousand onlyRefundable) in form of TDR drawn on a nationalized Bank in favour of “Registrar,
Panjab University, Chandigarh ” duly super scribed as “Digitization of Theses at PUC”
should reach the undersigned up to 3:00 p.m. on 16/03/2015. 
The EMD amount deposited will not entail payment of any interest. 
The EMD of successful bidder will be refunded only on final acceptance of Performance
Bank Guarantee by the University. 
In case of extraordinary delay of the work the order may be cancelled. In case if the work
is not started for 45 days the order can be cancelled and university will forfeit the TDR/
encash the bank Guarantee. 
The rates so quoted should be in INR and inclusive of all taxes. 
In case the digitization work carried out is not according to the specifications mentioned
in the work order, the work will have to be redone within the stipulated time as decided
by the competent authority. 
The work will be accepted only after quality assurance tests/checks are carried out by the
competent authority. 
75% payment shall be made on completion of digitisation work and on uploading the
contents and making it accessible for retrieval. The remaining 25% payment will be made
after 3 months of successful running of the project. 
In the event of assigned work being carried out by the vendor not found satisfactory by
the University, the contract would be liable to be terminated and the University shall have
discretion to get the remaining work carried out from any other vendor at the cost of
tenderer besides forfeiting performance security. 
The payment will be made on actual no. of theses digitised. 
(University Librarian)

B Scanning of approx. 8000 theses
1.
2.
3.
4.
5.

The thesis to be converted in requisite format will be provided in hard bound volumes.
The output should provide in set of two microfilm/DVDs i.e. one will contain Raw TIFF
Images (includes Thumbnail Image of Covering Pages of each thesis) and other
enhanced, searchable PDF-A.
The output should be of acceptable readability, reasonable accuracy, consistent in term of
tone and color reproduction and use neutral common rendering for all images.
Sample images to be provided in different Modes (Black & White, Color, and Grey
Scale) along with the tender in DVD. Sample to be obtained along with tender. This will
be part of Technical Bid.
The scanner should have minimum of 600 dpi (dot per inch) optical responses or
resolutions with [Bit depths: Bit, not less than 8-bit Grayscale, or 24-bit Color (True
color)].
5

<!-- page 6 -->

6.

Image Enhancement – Basic Enhancement Raster cleaning, De-skew, De-Speckle
Cropping& hole removal etc., to be carried out on each image for optimum image clarity.
7.
The scanned images should be in TIFF format at early stage and final copy should be in
searchable PDF-A file format.
8.
The PDF files should be compressed.
9.
No cropping is allowed for Raw Image, the entire document has to be scanned for
maintaining original size and shape of the document.
10.
The scanning specifications for text support - the production of a scan that can be
reproduced as a legible at the same size as the original (at 1:1, the smallest significant
character should be legible).
11.
Cleanliness of Work Area, Digitization Equipment, and Originals like Scanners, platens,
and copy boards will have to be cleaned on a routine basis to eliminate the introduction of
extraneous dirt and dust to the digital images. Many old documents tend to be dirty and
will leave dirt in the work area and on scanning equipment.
12.
The final scanned copy in PDF-A should be legible, with completeness, image quality
(tonality and color), and the ability to reproduce pages in their correct (original)
sequence.
13.
Digital images should be created to a quality level that will facilitate OCR conversion to
a specified accuracy level. This should not, however, compromise the quality of the
images to meet the quality index.
14.
The digitized images to be converted to searchable PDF-A format, the layout of the page
should be retained.
15.
A file-naming scheme database - should be established prior to capture. The same will be
provided by A C Joshi Library, PUC.
16.
The master files containing final documents should be stored on DVD/microfilms. It has
been recommended that High Quality DVD should be used for storing the document
copy.
C) Metadata and Indexing of digitized materials; Capture and Create Metadata for each and
every thesis. The solution Provider must follow the following standards for metadata creation:
 Dublin Core 
 Open Archival Information Standards (OAI-PMH) 

(C)
Integrated Digital Document Management System (Including Installation,
Hardware/Software, etc.)









PUC requires Integrated Digital Document Management System for Uploading of
digitized theses along with metadata on Dspace /Eprints, at A C Joshi Library, PUC. 
All digitized images along with metadata would initially reside on the production server
and once they are quality assured by the PU library they would be transferred to the live
Integrated Digital Document Management System (IDDMS) server to be used for PUC
Intranet/Internet. 
The solution provider shall be requested to install IDDMS with all supporting
hardware/software and utilities along with some soft copy of theses already available at
PU library on PUC server before going for actual digitization work of theses. 
6

<!-- page 7 -->

Following are brief specifications of required IDDMS:
  Extensive meta-data creation using comprehensive data entry templates. 
 Institutional archives both open access and restricted access should be created from a
single interface. 

 Standard subject heading schemes like Library of congress, etc. 
  Server allowing metadata harvesting through OAI-PMH 
 Meta data standard Dublin Core should be used. 
 Allowing creating of users and user groups. 
 Should handle the devanagri script in Unicode. 
 Backup and restore script of database on a periodic basis. 
 Allows multiple user access levels and authorization of users depending on roles. 
  Provision for the users for submission of electronic theses/dissertations. 
  Full text searching. 
 The solution provider shall provide a tool within IDDMS for MIS reporting which
provides statistical reports/summary which can be used for performance analysis on
repository. 

 The IDDMS has a provision of Hierarchy to manage contents in a repository (i.e.,
communities, collections and items) 

 The IDDMS must have import and export data facility for communities, collections and
items. 

 The IDDMS must ensure that it provide faster search and retrieval where user can search
for any item via a simple and advance search and also have browsing option for different
fields like title, author, etc. 

 The IDDMS must have a facility for saving all searches so as to track the document usage
patterns. 

 Proposed software should be used by at least 20 Central / State Govt. Institutions for
hosting digital records on open internet. (Internet URL of repository of each reference to
be provided) 

 Availability of multiple solution support partners in India for proposed IDDMS solution. 
Viewer Specifications:
 Proposed IDDMS should come with inbuilt viewer for viewing the PDF files using
browsers on multiple platforms i.e. laptop / mobile / tablet etc. Viewer should support
multiple rendering technologies i.e. flash and HTML5 for easy display of contents on
new and old browsers. 

 Viewer should be intelligent enough to understand browser’s technology and display the
document in best suited technology. 

  It should be possible for users to make full text search on OCRed documents in viewer. 
 Proposed solution should have basic accessibility features like zoom in / out, go to page
etc. 

 It should be possible to do documents streaming for reduced wait time for document
viewing. 
 Solution should be capable of displaying document without providing option of
downloading the document on multiple platforms like Windows, Linux, Android, Apple
etc. 

7

<!-- page 8 -->














































Software should have faceted search mechanism, which breaks up search results into
multiple categories, typically showing counts for each, and allows the user to "drill
down" or further restrict their search results based on those facets. 
For making solution more user friendly and easy to use, proposed software should have
feature of predictive search i.e. software should provide suggestion when user start
keying the alphabets in certain fields for search. 
Proposed software should have out of the box mobile interface and responsive web
interface i.e. interface used for desktop should be compatible with small screen devices,
i.e. laptop, smart phone, tablet, etc. 
Proposed IDDMS should be compatible with all Brower, i.e., Internet explorer, Mozila
Firefox, Chrome, etc. 
Authentication: The mechanism whereby there is a provision in a system where
staff/user(s) can register in the system and create their account and system may also
securely identify their users. 
Authorization: The mechanism by which a system determines what level of access a
particular authenticated user should have to secure resources controlled by the system. 
The system should be user friendly and user can access the system by using any browser. 
The IDDMS has a provision of customization to accommodate the multidisciplinary and
organizational needs of large institutions and also supports large no. of digital formats. 
The IDDMS must have standard compliance (i.e. dublin core, MARC-21,etc.) 
Integrated Document Management Solution should support multiple file formats i.e.
PDF, MS Office, Audio/Video etc. 
Integrated Digital Document Management Solution supports bulk import & export of
data as XML and CSV format. 
Proposed solution provides context sensitive 'Help' Operation. 
Proposed solution should have approval mechanism before publishing any content on
solution. 
Simple and Advance search on metadata with Boolean operator. 
It should be possible for user to search a record in combination of full text search and
metadata. 
Institutional archives both Open access and restricted access should be created from a
single interface 
Allowing creation of Users, and User groups. 
Supports the movement of users between organizational units whereby their job roles
and/or their access rights may change. The System has within it the concepts of job roles,
and staff occupying those posts. In addition, the IDDMS must allow the definition of user
roles, and must allow one or more users to be associated with each role. 
Provides Comprehensive Statistics to evaluate the usage of the Repository 
Analytics: Provides Analytic reports/summary on use of various records basis
geographical location of users, month, city, country etc. for helping Panjab University to
understand user interest and future enhancement of repository. 
It should be possible to do documents streaming for reduced wait time for document
viewing. 

8

<!-- page 9 -->









There should be provision for making a record available to user without login in the
system 
Solution offering delivery of source code of solution to Panjab University and having no
restriction on user licenses should be preferred 
Ease of Access: The level of effort required in order finding, organizing access to use it is
very minimal by using various Browse options. 


D) Server Specifications

Processor: Quad Core Processor x 1 Nos.or higher. 
RAM: 16 GB 
Storage: 3 TB 
Keyboard, Mouse, Monitor 19” 
Software required with appropriate Operating System 
RDBMS: To be proposed and delivered by Bidder 

The tenderer should submit necessary brochure /details of server and necessary
software. 

E) Proposal Deliverables
The proposal should accompany the following:
• Detailed Work Plan Implementation
• Digitization Centre – Equipment specification
• Disaster Management Plan
• Digitization Processes and workflows
• Metadata Creation Technique
• Monthly / Periodic MIS reports
• Quality Control / Assurance Reports
• Documents Batch Submission/return Reports
• Technical and User Manuals to refer the Archived Data
• Post implementation Support.
• Particular of AMC after the warranty period.
• Any Specific need / Expectations from the PUC by vendor.










(F) Other Responsibilities of the executing Agency/Vendor
Besides scanning and digitizing the collection, maintaining records and generating
regular progress reports, the other major responsibilities of the vendor will be as under:
1.
Maintaining confidentiality about work
2.
Safe handling of theses used for scanning (as these are rare available as single copy and
cannot be recreated). While handling theses, proper care is to be taken, so vendor should
deploy only experienced scanning operators. In case of any negligence the vendor shall
be penalized.

9

<!-- page 10 -->

3.
4.
5.
6.
7.
8.

The agency shall be responsible for preparing the documents for scanning/digitization
purpose, i.e. cleaning of theses; remove dust, taking them out of shelves and putting them
back etc.
Theses rebinding /returning /refilling after scanning.
Handling and maintenance of the hardware installed by the agency will be the
responsibility of the agency/vendor.
In case of any damage to content, same should be informed to A C Joshi Library, Panjab
University, Chandigarh without delay by the agency.
The short listed vendor has to agree to maintain the back up for at least one year after the
completion of project.
The agency/vendor has to give undertaking that they will not use the digitized content of
8000 theses of PUC for any other purpose and also will not share this data with any
firm/company/organisation/institution, etc.

10

<!-- page 11 -->

Annexure – A
TECHNICAL BID
Please furnish the following information in this part so as to enable us to decide about the
qualification/eligibility. Necessary documents/certificates from the appropriate authority (self
attested) must be attached in support of statements. Bidder need to attach screenshot of each
IDDMS specification given in compliance in this tender. The vendor has to demonstrate the
complete solution before the committee up to their satisfaction as per the tender document, if
required by the committee.
Tender Reference No. ______________________________Dated __________________
1. Name & Address of the Applicant : _______________________________________
2. Tel Ph.

: _________________________________

3. Fax No.

: _________________________________

4. E-mail.

: _________________________________

5. Details of following:
Sr. No.

TDR No.

1

EMD (TDR)

2

Cost of Tender (DD)

Date of Issue

Issuing Bank

6. Performa for submitting the Technical Bid
i. Name of the Company:__________________________________________
ii. Address of the Company:__________________________________________
iii. Details of manpower, hardware/ software, etc as mentioned in the tender
documents to be deployed for completing the work in accordance with the time
schedule.
iv. Proposed Project Manager (along with his/her profile and work experience)
v. Attach documentary proof to support your claim for fulfilling the terms and
condition as mentioned in the tender, as and where applicable.

Name & Signature of the Authorized
Signatory of the Company

11

<!-- page 12 -->

Annexure – B
FINANCIAL BID
Tender Reference No. ______________________________Dated __________________
1. Name & Address of the Applicant : _______________________________________
2. Tel Ph.

: _________________________________

3. Fax No.

: _________________________________

4. E-mail.

: _________________________________

Performa for Financial Bid: (Rate should be quoted in lump sum inclusive of all taxes and
any other expenses for the following description of work)
Sr. No.

Digitization of Thesis
1

Unit

Description of Work

Price in Rs.
(inclusive of all taxes)

Per thesis

(Complete Scanned Solution as
per technical requirements of
tender document)
Metadata creation of each

2

Per thesis

Thesis as per Dublin Core
Standards AND Uploading of
digital thesis in IDDMS
Installation of Integrated

3

one

Digital Document Management
System including
HW/SW/Server)
Total

Name & Signature of the Authorized
Signatory of the Company
12

<!-- page 13 -->

ANNEXURE – ‘C”
(Undertaking from the Supplier on a Non-Judicial Stamp Paper of Rs. 5/- duly attested
by Notary)
PERFORMANCE BOND/ GUARANTEE
In consideration for the Registrar, Panjab University, Chandigarh (hereinafter called the
purchaser) having agreed to release the 100% payment of net contract value as per terms and
conditions of a concluded Contract No. ________________________ dated ________
(hereinafter called the ‘contract’) for supply of ___________________________________
(hereinafter called the goods and services) to us i.e. Messrs ___________________________
(hereinafter called ‘the supplier’) on submission of a Performance Bond to the satisfaction of the
purchaser for the due performance of the said contract.
We, Messrs ___________________________________________ (hereinafter called ‘the
Supplier’) hereby submit the TDR No. _________________________________ issued by
________________________________ (Name of the Bank) for Rs. _______________ pledged
in favour of Registrar, Panjab University, Chandigarh as Performance Bank Guarantee amount
and hereby irrevocably, unconditionally and absolutely undertake against any loss or damage
caused or suffered by the purchaser by reason of any failure of the supplier to perform or
omission or negligence to perform any part of its obligations to the satisfaction of the purchaser
in terms of the contract.
We, the Supplier, do hereby authorize Registrar, Panjab University, Chandigarh to forfeit this
Performance Guarantee amount/undertake to pay the amount due and payable under this
guarantee without any demur merely on a demand from the purchaser stating that the amount
claimed is due by way of loss or damage caused to or would be caused to or suffered by the
purchaser by reason of any breach by us of any of the terms and conditions contained in a said
contract or by reason of our failure or omission or negligence to perform the said contract or any
part thereof.
We, the Supplier, undertake to pay to the purchaser any amount so demanded by the purchaser,
notwithstanding.
(a)

(b)
(c)

any dispute or difference between the purchaser and the supplier or any other
person or between the supplier or any person or any suit or proceeding pending
before any court or tribunal or arbitrator relating thereto or
The validity irregularity or unenforceability of the contract or
any other circumstances which might otherwise constitute discharge of this
guarantee, including any act or omissions or commission on the part of the
13

<!-- page 14 -->

purchaser to enforce the obligations by the supplier or any other person for any
reason whatsoever.
Whether Supplier, further agree that the Performance Bond/ Guarantee herein contained shall be
continued one and remained full force and effect during the period that would be taken for the
performance of the said contract and that it shall continue to be enforceable till all the dues of the
purchaser under or by virtue of the said contract have been fully paid and its claims satisfied or
discharged of till the office of the Registrar, Panjab University, Chandigarh certifies that the
terms and conditions of the said contract have been fully and promptly carried out by us and
accordingly discharges this Performance Bond/ Guarantee.
We, the Supplier, further agree with the purchaser that the purchaser shall have the fullest liberty
without our consent and without affecting in any manner our obligations hereunder to vary any
of the terms and conditions of the said contract or to extend time of performance by us from time
to time or to postpone for any time or from time to time and of the powers exercisable by the
purchaser against us and forbear or enforce any of the terms and conditions relating to the said
contract and we shall not be relieved from our liability by reason of any such variation or
extension being granted to us or for any forbearance, act or omission on the part of the purchaser
or any indulgence by the purchaser to us or by any such matter or thing whatsoever which under
the law relating to sureties would, but for this provision, have effect of so relieving us.
This Performance Bond/ Guarantee will not be discharged due to the change in the constitution
of the Supplier.
We the Supplier, lastly undertake not to revoke this Performance Bond/ Guarantee except with
the previous consent of the purchaser in writing.
The disputes relating to this bank Performance Bond/ Guarantee shall be resolved as per the
terms and conditions of the contract.

Signature and seal of the Supplier

Place: ______________
Date: ______________

14
