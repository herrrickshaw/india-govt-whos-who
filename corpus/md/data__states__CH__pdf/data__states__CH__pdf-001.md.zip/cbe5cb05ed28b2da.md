---
doc_id: "cbe5cb05ed28b2da"
source_url: "https://cdnbbsr.s3waas.gov.in/s3dd28e50635038e9cf3a648c2dd17ad0a/uploads/2025/07/2025072579.pdf"
ministry: "Joint Admission Committee, Chandigarh"
title: "Corrigendum of Fees"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f5d811950ced796b"
---

<!-- page 1 -->

CORRIGENDUM
Total Approximate Fee of B.E. (2025-2026) (Yearly)
S. No.

B.E. (Chemical
Engineering)
₹ 35,175/-*
(1 instalment: ₹
27,775/-)

B.E. (Food
Technology)
₹ 35,175/-*
st
(1 instalment: ₹
27,775/-)

Integrated B.E.
(Chemical)-MBA
₹ 1,34,505/-*
st
(1 instalment: ₹ 83,770/-)

Course Fee for 1st

₹ 9,500/- (One time
fees)

₹ 9,500/- (One time
fees)

₹ 11,500/- (One time fees)

st

Year
(per annum)
Society Fees

*Fee subject to revision by Panjab University, Chandigarh from time to time
For hostel accommodation please visit on https://hms.puchd.ac.in/
